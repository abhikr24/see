# GuruFlow

Coaching-management app for India — one app, four roles, one student in many institutes.

**Status: foundation built. ~30% complete.** See `docs/WORK-DONE.md` for the
exact state and `docs/HANDOFF-PROMPT.md` for what to do next.

## Run it

```bash
npm install
cp .env.example .env          # add your Supabase URL + anon key
npm run typecheck
npm start
```

## Database

```bash
# In Supabase SQL editor, run in this order:
supabase/migrations/0001_init.sql
supabase/migrations/0002_rls.sql
supabase/seed.sql
supabase/demo/attach_users.sql   # after creating the demo auth users
```

## Where things live

| Path | What |
|---|---|
| `src/core/contracts/` | The backend interfaces. Read `ports.ts` first. |
| `src/core/config/providers.ts` | **The swap file.** One line chooses the backend. |
| `src/adapters/supabase/` | The only place that knows Postgres exists. |
| `src/components/ui/` | Design system primitives. |
| `src/lib/theme.ts` | Every colour, radius and shadow. |
| `app/` | Routes only, thin files. |
| `app/dev/` | Component gallery and contract check. |

## Docs

- `docs/GuruFlow-AI-Build-Pack.md` — the full 24-prompt build plan (the idea).
- `docs/WORK-DONE.md` — what is built, what is not, what is next.
- `docs/HANDOFF-PROMPT.md` — paste this to the next AI.
- `docs/ARCHITECTURE.md` — the layering rules in one page.
