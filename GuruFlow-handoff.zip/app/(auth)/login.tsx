import React from 'react';
import { Screen, Card, Text } from '@/components/ui';

export default function Login() {
  return (
    <Screen title="Welcome back" subtitle="Sign in to your coaching account">
      <Card>
        <Text variant="caption" c="#5A6684">
          Auth screens are built in prompt P4. This placeholder exists so the router resolves.
        </Text>
      </Card>
    </Screen>
  );
}
