import React from 'react';
import { Screen, Card, Text, Button } from '@/components/ui';
import { useSession, activeMembership } from '@/store/session';

export default function OwnerHome() {
  const s = useSession();
  const m = activeMembership(s);
  return (
    <Screen title="Home" subtitle={m?.org?.name ?? 'Your institute'}>
      <Card>
        <Text variant="title">Foundation is in place</Text>
        <Text variant="caption" c="#5A6684" style={{ marginTop: 6 }}>
          Design system, contracts, database and adapter are built.
          The dashboard arrives in prompt P7. See docs/WORK-DONE.md.
        </Text>
      </Card>
      <Button title="Design system check" variant="outline" onPress={() => {}} />
    </Screen>
  );
}
