import React from 'react';
import { Screen, Card, Text } from '@/components/ui';

export default function Pending() {
  return (
    <Screen title="Request sent" subtitle="Waiting for the institute to approve you">
      <Card>
        <Text variant="body">You will get access as soon as the institute approves your request.</Text>
      </Card>
    </Screen>
  );
}
