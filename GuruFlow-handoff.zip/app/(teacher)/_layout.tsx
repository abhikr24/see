import React from 'react';
import { View } from 'react-native';
import { Stack } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from '@/lib/theme';
import { TabBar } from '@/components/ui';
import { TABS } from '@/lib/nav';

export default function TeacherLayout() {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, paddingBottom: insets.bottom }}>
      <Stack screenOptions={{ headerShown: false }} />
      <TabBar tabs={TABS.teacher} />
    </View>
  );
}
