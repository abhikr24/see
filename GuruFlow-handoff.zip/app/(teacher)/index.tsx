import React from 'react';
import { Screen, Card, Text } from '@/components/ui';

export default function TeacherHome() {
  return (
    <Screen title="Home">
      <Card>
        <Text variant="title">Placeholder</Text>
        <Text variant="caption" c="#5A6684" style={{ marginTop: 6 }}>
          This role's screens are built in a later prompt. See docs/WORK-DONE.md.
        </Text>
      </Card>
    </Screen>
  );
}
