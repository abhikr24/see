import React from 'react';
import { View } from 'react-native';
import { Screen, Text, Button, Input, Card, Badge, Chip, Avatar, IconBox, Divider, ProgressBar, Ring, EmptyState, ErrorState, ListSkeleton, Skeleton } from '@/components/ui';
import { C } from '@/lib/theme';

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <View style={{ gap: 10, marginBottom: 8 }}>
    <Text variant="label" c={C.muted}>{title}</Text>
    {children}
    <Divider />
  </View>
);

export default function Components() {
  return (
    <Screen title="Design system" subtitle="Every primitive, every state">
      <Section title="Text">
        <Text variant="h1">Page title 34/800</Text>
        <Text variant="h2">Section 22/700</Text>
        <Text variant="title">Card title 17/700</Text>
        <Text variant="body">Body 15/500 — ₹1,24,500</Text>
        <Text variant="caption" c={C.secondary}>Secondary 13/500</Text>
        <Text variant="label" c={C.muted}>Label 11/600</Text>
      </Section>

      <Section title="Buttons">
        <Button title="Primary" />
        <Button title="Secondary" variant="secondary" />
        <Button title="Outline" variant="outline" />
        <Button title="Danger" variant="danger" />
        <Button title="Loading" loading />
        <Button title="Small" size="sm" full={false} />
      </Section>

      <Section title="Inputs">
        <Input label="Full name" placeholder="Aarav Sharma" />
        <Input label="Phone" placeholder="98765 43210" error="Enter a 10-digit number" />
        <Input label="Password" secure placeholder="••••••••" />
      </Section>

      <Section title="Cards & chips">
        <Card><Text variant="title">White card, 20 radius, hairline</Text></Card>
        <Card tint={C.accentSoft} flat><Text variant="caption">Tinted card — semantic only</Text></Card>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Chip label="All 240" active />
          <Chip label="Class 10-A" />
          <Chip label="Overdue" count={18} />
        </View>
        <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
          <Badge label="Paid" tone="teal" />
          <Badge label="Due ₹4,999" tone="danger" />
          <Badge label="Pending" tone="warning" />
          <Badge label="Draft" />
        </View>
      </Section>

      <Section title="Avatars & icons">
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Avatar name="Aarav Sharma" size={40} />
          <Avatar name="Ishita Bose" size={48} />
          <Avatar name="Kabir Singh" size={56} />
          <IconBox name="wallet-outline" tone="teal" />
          <IconBox name="book-outline" tone="accent" />
          <IconBox name="calendar-outline" tone="danger" />
        </View>
      </Section>

      <Section title="Data">
        <Ring value={92} size={120} label="attendance" />
        <ProgressBar value={76} />
        <ProgressBar value={42} tone="warning" />
        <Skeleton h={14} w="70%" />
        <Skeleton h={14} w="45%" />
      </Section>

      <Section title="States">
        <ListSkeleton rows={2} />
        <EmptyState icon="people-outline" title="No students yet" text="Add your first student to get started." actionLabel="Add student" onAction={() => {}} />
        <ErrorState message="Network unreachable." onRetry={() => {}} />
      </Section>
    </Screen>
  );
}
