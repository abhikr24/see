import React, { useCallback, useState } from 'react';
import { View } from 'react-native';
import { Screen, Card, Text, Button, Badge, Divider } from '@/components/ui';
import { C } from '@/lib/theme';
import { useBackend } from '@/core/backend';
import { useSession } from '@/store/session';

type Result = { name: string; ok: boolean; detail?: string };

const ORG = '00000000-0000-4000-8000-000000000001';
const BATCH = '00000000-0000-4000-8000-000000000201';

/**
 * Verifies that the active adapter implements every port method.
 * Run this after swapping backends — if it is green, the app works.
 */
export default function ContractCheck() {
  const b = useBackend();
  const orgId = useSession((s) => s.activeOrgId) ?? ORG;
  const [results, setResults] = useState<Result[]>([]);
  const [running, setRunning] = useState(false);

  const run = useCallback(async () => {
    setRunning(true);
    const out: Result[] = [];
    const t = async (name: string, fn: () => Promise<unknown>) => {
      try { await fn(); out.push({ name, ok: true }); }
      catch (e) { out.push({ name, ok: false, detail: (e as Error)?.message?.slice(0, 90) }); }
    };

    await t('auth.getSession', () => b.auth.getSession());
    await t('orgs.get', () => b.orgs.get(orgId));
    await t('orgs.search', () => b.orgs.search('sun'));
    await t('memberships.listMine', () => b.memberships.listMine());
    await t('students.list', () => b.students.list(orgId, { pageSize: 5 }));
    await t('batches.list', () => b.batches.list(orgId));
    await t('attendance.getSheet', () => b.attendance.getSheet(orgId, BATCH, new Date().toISOString().slice(0, 10)));
    await t('exams.list', () => b.exams.list(orgId));
    await t('fees.totals', () => b.fees.totals(orgId, 'Term 1'));
    await t('content.list', () => b.content.list(orgId));
    await t('content.storageUsed', () => b.content.storageUsed(orgId));
    await t('notices.list', () => b.notices.list(orgId));
    await t('notifications.unreadCount', () => b.notifications.unreadCount());
    await t('leave.list', () => b.leave.list(orgId));

    setResults(out);
    setRunning(false);
  }, [b, orgId]);

  const passed = results.filter((r) => r.ok).length;

  return (
    <Screen title="Contract check" subtitle="Every port method, against the live adapter">
      <Card>
        <Text variant="body">
          This screen proves the backend swap works. Run it after changing
          src/core/config/providers.ts.
        </Text>
        <View style={{ marginTop: 12 }}>
          <Button title={running ? 'Running…' : 'Run all checks'} loading={running} onPress={run} />
        </View>
      </Card>

      {results.length > 0 ? (
        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
            <Text variant="title">Results</Text>
            <Badge label={`${passed}/${results.length} passed`} tone={passed === results.length ? 'teal' : 'warning'} />
          </View>
          {results.map((r) => (
            <View key={r.name}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 }}>
                <Text variant="caption" style={{ flex: 1 }}>{r.name}</Text>
                <Text variant="caption" c={r.ok ? C.success : C.danger}>{r.ok ? 'pass' : 'fail'}</Text>
              </View>
              {r.detail ? <Text variant="caption" c={C.muted} style={{ marginBottom: 6 }}>{r.detail}</Text> : null}
              <Divider />
            </View>
          ))}
        </Card>
      ) : null}
    </Screen>
  );
}
