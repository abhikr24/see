import React, { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useRouter } from 'expo-router';
import { C } from '@/lib/theme';
import { useSession, allPending, activeRole } from '@/store/session';

/**
 * Route resolver. P3/P4 replace this with real auth bootstrapping;
 * for now it reads the persisted session and sends the user to the right group.
 */
export default function Index() {
  const router = useRouter();
  const state = useSession();

  useEffect(() => {
    if (!state.userId) { router.replace('/(auth)/login'); return; }
    if (allPending(state)) { router.replace('/(pending)'); return; }
    const role = activeRole(state);
    if (role === 'owner') router.replace('/(owner)');
    else if (role === 'teacher') router.replace('/(teacher)');
    else if (role === 'student') router.replace('/(student)');
    else if (role === 'parent') router.replace('/(parent)');
    else router.replace('/(auth)/login');
  }, [state.userId, state.memberships, state.activeOrgId]);

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}>
      <ActivityIndicator color={C.primary} />
    </View>
  );
}
