# Architecture

## The one rule

The UI never knows what database exists.

```
app/ + src/features/          ← screens. Call hooks. No SDK imports. Ever.
        │
        ▼
src/core/backend.tsx          ← useStudents(), useAttendanceSheet(), …
        │
        ▼
src/core/contracts/ports.ts   ← interfaces. The only vocabulary the app speaks.
        │
        ▼
src/adapters/supabase/        ← the only code that knows Postgres exists
        │
        ▼
src/core/config/providers.ts  ← ONE line chooses the live adapter
```

## Why this shape

Because the backend will change. Maybe to Firebase, maybe to a Node API, maybe
to a second vendor for a specific customer. With this shape, that is a folder
and one line — not a rewrite.

## Swapping the backend

1. `cp -r src/adapters/supabase src/adapters/yourvendor`
2. Rewrite each `*.repo.ts` internals, keeping every signature identical
3. Add env keys to `.env` and `src/core/config/env.ts`
4. Change one line in `src/core/config/providers.ts`
5. Run `/dev/contract-check` — all green means the app works

## Tenancy

```
profiles (no org_id)  ──┐
                        │
memberships ────────────┴── (user_id, org_id, role, status)
        │
        ├── status = pending  → sees only the waiting screen
        └── status = active   → sees their role's tabs
```

One user, many orgs, many roles. The active org lives in `src/store/session.ts`
and every repo method takes `orgId` as its first argument.

## Adding a feature (six steps)

1. Add the method to the right port in `src/core/contracts/ports.ts`
2. Implement it in `src/adapters/supabase/*.repo.ts`
3. Add a hook in `src/core/backend.tsx`
4. Create `src/features/<name>/` with screens + components
5. Add the route file under `app/`
6. Add a tab in `src/lib/nav.ts` if it needs one

No step touches another feature's files.
