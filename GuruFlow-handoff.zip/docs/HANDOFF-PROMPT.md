# Handoff prompt — paste this to the next AI

```
You are continuing an existing project called GuruFlow, a coaching-management
app for India (Expo + TypeScript + Supabase). A previous session built the
foundation. Your job is to continue, not to restart.

READ THESE FIRST, IN THIS ORDER
1. AGENTS.md                        — project rules, design system, seed data
2. docs/WORK-DONE.md                — exactly what is built, what is not, what is next
3. docs/ARCHITECTURE.md             — the layering rules
4. docs/GuruFlow-AI-Build-Pack.md   — the full 24-prompt plan (§6 is the prompts)
5. src/core/contracts/ports.ts      — the interfaces the whole app speaks

THEN WORK THE PLAN
The build pack defines prompts P1–P24. P1, P2 and P3 are complete.
Continue from P4. For each prompt:
  · read that prompt in §6 of the build pack
  · build only what it asks
  · run `npm run typecheck` and fix everything it reports
  · list what you changed and what I should test
  · do not start the next prompt until I say so

ABSOLUTE RULES
· The UI never imports a backend SDK. All data goes through the contracts.
  If you find yourself writing `supabase.from(...)` inside src/features or app/,
  stop — that belongs in an adapter.
· Never store org_id on profiles. Tenancy lives in memberships.
· Never hardcode a name, mark or amount in a component. Use seed data.
· Never invent a screen the prompt did not describe. No bonus features.
· No file over 300 lines. No business logic in a screen file.
· Design system values come only from src/lib/theme.ts.
· Before showing me a screen, run the premium test in AGENTS.md.

FIRST TASK
Run `npm install`, then `npm run typecheck`, then fix every error. Report the
list of errors and what you changed. Do not begin P4 until that is clean.
```

## Why this prompt works

- It tells the next AI **where the truth lives**, so it does not guess.
- It names the exact starting point (P4) so it does not redo finished work.
- It repeats the three rules that are easiest to break under pressure.
- It gives one small first task, so you see its quality before it writes 2,000 lines.
