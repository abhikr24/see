# Adapters

An adapter is one folder that implements the `Backend` interface from
`src/core/contracts/ports.ts`. It is the only place in the project allowed to
import a database SDK.

## Swapping the backend (about 10 minutes)

1. `cp -r src/adapters/supabase src/adapters/yourvendor`
2. Rewrite the internals of each `*.repo.ts`. Keep every signature identical.
3. Add your env keys to `.env` and `src/core/config/env.ts`.
4. Change one line in `src/core/config/providers.ts`.
5. Open `/dev/contract-check` and confirm every method passes.

If step 5 is green, the whole app runs on the new backend. No screen, hook or
contract file changes.

## Rules

- Never leak a row type or SDK type above this layer — map to domain types.
- Normalise every error to `AppError` with a correct code.
- Enforce `orgId` in the query even though RLS also enforces it.
