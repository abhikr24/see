import type { AuthPort, Session } from '@/core/contracts/ports';
import { AppError } from '@/core/contracts/errors';
import { supabase } from './client';

const toSession = (u: { id: string; email?: string | null; phone?: string | null } | null): Session | null =>
  u ? { userId: u.id, email: u.email ?? null, phone: u.phone ?? null } : null;

/** Digits-only phone → E.164. India default. */
const asPhone = (raw: string) => {
  const d = raw.replace(/\D/g, '');
  if (d.length === 10) return `+91${d}`;
  return raw.startsWith('+') ? raw : `+${d}`;
};

export const auth: AuthPort = {
  async signInWithPassword(identifier, password) {
    const isEmail = identifier.includes('@');
    const { data, error } = await supabase().auth.signInWithPassword(
      isEmail ? { email: identifier.trim(), password } : { phone: asPhone(identifier), password },
    );
    if (error) {
      throw new AppError(
        /invalid/i.test(error.message) ? 'unauthorized' : 'unknown',
        /invalid/i.test(error.message) ? 'Incorrect email, phone or password.' : error.message,
      );
    }
    const s = toSession(data.user);
    if (!s) throw new AppError('unknown', 'Sign in failed');
    return s;
  },
  async signInWithOtp(phone) {
    const { error } = await supabase().auth.signInWithOtp({ phone: asPhone(phone) });
    if (error) throw new AppError('unknown', error.message);
  },
  async verifyOtp(phone, token) {
    const { data, error } = await supabase().auth.verifyOtp({ phone: asPhone(phone), token, type: 'sms' });
    if (error) throw new AppError('unauthorized', 'That code is not correct.');
    const s = toSession(data.user);
    if (!s) throw new AppError('unknown', 'Verification failed');
    return s;
  },
  async signUp(name, email, password) {
    const { data, error } = await supabase().auth.signUp({
      email: email.trim(), password, options: { data: { full_name: name } },
    });
    if (error) throw new AppError(/exists/i.test(error.message) ? 'conflict' : 'unknown', error.message);
    const s = toSession(data.user);
    if (!s) throw new AppError('unauthorized', 'Check your email to confirm your account.');
    await supabase().from('profiles').upsert({ id: s.userId, full_name: name } as never);
    return s;
  },
  async signOut() {
    await supabase().auth.signOut();
  },
  async getSession() {
    const { data } = await supabase().auth.getSession();
    return toSession(data.session?.user ?? null);
  },
  onChange(cb) {
    const { data } = supabase().auth.onAuthStateChange((_e, session) => cb(toSession(session?.user ?? null)));
    return () => data.subscription.unsubscribe();
  },
};
