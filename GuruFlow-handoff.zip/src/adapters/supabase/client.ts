import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { AppError } from '@/core/contracts/errors';
import { env } from '@/core/config/env';

let _client: SupabaseClient | null = null;

export function supabase(): SupabaseClient {
  if (_client) return _client;
  if (!env.supabaseUrl || !env.supabaseAnonKey) {
    throw new AppError('unauthorized', 'Supabase is not configured. See .env.example.');
  }
  _client = createClient(env.supabaseUrl, env.supabaseAnonKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
  });
  return _client;
}

/** Map a PostgREST error onto our AppError codes. */
export function mapError(e: { code?: string; message?: string } | null): never {
  const code = e?.code ?? '';
  const msg = e?.message ?? 'Database error';
  if (code === 'PGRST116') throw new AppError('not_found', 'That record no longer exists.', e);
  if (code === '23505') throw new AppError('conflict', 'That already exists.', e);
  if (code === '42501' || /row-level security/i.test(msg)) throw new AppError('unauthorized', 'You do not have access to this.', e);
  if (code === '23514' || code === '23503') throw new AppError('validation', msg, e);
  if (/fetch|network|timeout/i.test(msg)) throw new AppError('network', 'Check your connection and try again.', e);
  throw new AppError('unknown', msg, e);
}

export const throwIf = (error: { code?: string; message?: string } | null) => { if (error) mapError(error); };

export const PAGE = 20;

export function pageRange(page = 0, pageSize = PAGE) {
  const from = page * pageSize;
  return { from, to: from + pageSize - 1 };
}
