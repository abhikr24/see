import type { Backend } from '@/core/contracts/ports';
import { auth } from './auth.adapter';
import { orgs, memberships, students, batches, attendance } from './repos.core';
import { exams, marks, fees, content, notices, notifications, leave } from './repos.learning';
import { storage } from './storage.adapter';
import { payment, video, realtime } from './misc.adapter';

export const supabaseAdapter: Backend = {
  auth, orgs, memberships, students, batches, attendance,
  exams, marks, fees, content, notices, notifications, leave,
  storage, payment, video, realtime,
};
