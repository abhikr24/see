import type {
  AppNotification, Attendance, Batch, ContentItem, Exam, FeePayment, FeePlan, Homework,
  LeaveRequest, Mark, Membership, Notice, Org, Student, Submission,
} from '@/core/contracts/models';

type Row = Record<string, any>;

export const toOrg = (r: Row): Org => ({
  id: r.id, name: r.name, code: r.code, city: r.city, state: r.state ?? null,
  board: r.board ?? null, logoUrl: r.logo_url ?? null, plan: r.plan, status: r.status,
});

export const toMembership = (r: Row): Membership => ({
  id: r.id, userId: r.user_id, orgId: r.org_id, role: r.role, status: r.status,
  createdAt: r.created_at, org: r.orgs ? toOrg(r.orgs) : undefined,
});

export const toBatch = (r: Row): Batch => ({
  id: r.id, orgId: r.org_id, name: r.name, subject: r.subject,
  teacherMembershipId: r.teacher_membership_id ?? null,
  teacherName: r.teacher_name ?? null,
  days: r.days ?? [], startTime: r.start_time ?? null, endTime: r.end_time ?? null,
  monthlyFee: Number(r.monthly_fee ?? 0), capacity: r.capacity ?? null,
  studentCount: r.student_count, attendancePct: r.attendance_pct, pendingFees: r.pending_fees,
});

export const toStudent = (r: Row): Student => ({
  id: r.id, orgId: r.org_id, batchId: r.batch_id ?? null, fullName: r.full_name,
  rollNo: r.roll_no ?? null, photoUrl: r.photo_url ?? null,
  parentName: r.parent_name ?? null, parentPhone: r.parent_phone ?? null,
  userId: r.user_id ?? null, parentUserId: r.parent_user_id ?? null, status: r.status,
  attendancePct: r.attendance_pct, feeDue: r.fee_due, absentToday: r.absent_today,
});

export const toAttendance = (r: Row): Attendance => ({
  id: r.id, orgId: r.org_id, batchId: r.batch_id, studentId: r.student_id,
  date: r.date, status: r.status, markedBy: r.marked_by ?? null,
});

export const toHomework = (r: Row): Homework => ({
  id: r.id, orgId: r.org_id, batchId: r.batch_id, subject: r.subject, title: r.title,
  description: r.description ?? null, dueAt: r.due_at, createdBy: r.created_by ?? null,
  submittedCount: r.submitted_count, totalCount: r.total_count,
});

export const toSubmission = (r: Row): Submission => ({
  id: r.id, homeworkId: r.homework_id, studentId: r.student_id,
  fileUrl: r.file_url ?? null, submittedAt: r.submitted_at, grade: r.grade ?? null,
});

export const toExam = (r: Row): Exam => ({
  id: r.id, orgId: r.org_id, batchId: r.batch_id, name: r.name, subject: r.subject,
  examDate: r.exam_date, maxMarks: Number(r.max_marks ?? 100),
  enteredCount: r.entered_count, totalCount: r.total_count,
});

export const toMark = (r: Row): Mark => ({
  id: r.id, examId: r.exam_id, studentId: r.student_id, marks: Number(r.marks ?? 0),
});

export const toContent = (r: Row): ContentItem => ({
  id: r.id, orgId: r.org_id, batchIds: r.batch_ids ?? [], type: r.type, title: r.title,
  url: r.url, storageKey: r.storage_key ?? null, durationSeconds: r.duration_seconds ?? null,
  thumbnailUrl: r.thumbnail_url ?? null, createdAt: r.created_at,
});

export const toFeePlan = (r: Row): FeePlan => ({
  id: r.id, orgId: r.org_id, batchId: r.batch_id ?? null, name: r.name,
  amount: Number(r.amount ?? 0), instalments: r.instalments ?? [],
});

export const toPayment = (r: Row): FeePayment => ({
  id: r.id, orgId: r.org_id, studentId: r.student_id, term: r.term,
  amount: Number(r.amount ?? 0), method: r.method, reference: r.reference ?? null,
  receiptNo: r.receipt_no, paidOn: r.paid_on, status: r.status,
  recordedBy: r.recorded_by ?? null,
});

export const toNotice = (r: Row): Notice => ({
  id: r.id, orgId: r.org_id, title: r.title, body: r.body, audience: r.audience ?? [],
  category: r.category, eventDate: r.event_date ?? null, createdBy: r.created_by ?? null,
  publishedAt: r.published_at,
});

export const toNotification = (r: Row): AppNotification => ({
  id: r.id, userId: r.user_id, orgId: r.org_id, title: r.title, body: r.body,
  type: r.type, isRead: !!r.is_read, createdAt: r.created_at,
});

export const toLeave = (r: Row): LeaveRequest => ({
  id: r.id, orgId: r.org_id, requesterId: r.requester_id, studentId: r.student_id ?? null,
  leaveType: r.leave_type, fromDate: r.from_date, toDate: r.to_date,
  reason: r.reason ?? null, status: r.status, decidedBy: r.decided_by ?? null,
  decidedAt: r.decided_at ?? null,
});
