import type { PaymentPort, VideoPort, RealtimePort } from '@/core/contracts/ports';
import { AppError } from '@/core/contracts/errors';
import { supabase } from './client';

/**
 * Payment and video are intentionally thin. Both are designed to be replaced
 * by a dedicated vendor adapter (Razorpay / Bunny) without touching UI.
 */
export const payment: PaymentPort = {
  async createIntent() {
    throw new AppError('unknown', 'Payments are not configured yet. See docs/WORK-DONE.md → Next steps.');
  },
};

export const video: VideoPort = {
  async playbackUrl(contentId) {
    const { data, error } = await supabase().from('content').select('url').eq('id', contentId).single();
    if (error || !data) throw new AppError('not_found', 'Content not found');
    return { url: (data as { url: string }).url };
  },
};

export const realtime: RealtimePort = {
  subscribe(topic, cb) {
    const channel = supabase()
      .channel(topic)
      .on('postgres_changes', { event: '*', schema: 'public', table: topic }, (payload) => cb(payload))
      .subscribe();
    return () => { void supabase().removeChannel(channel); };
  },
};
