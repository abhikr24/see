import type { OrgRepo, MembershipRepo, StudentRepo, BatchRepo, AttendanceRepo } from '@/core/contracts/ports';
import type { ListQuery } from '@/core/contracts/query';
import { AppError } from '@/core/contracts/errors';
import { supabase, throwIf, pageRange, mapError } from './client';
import { toOrg, toMembership, toStudent, toBatch, toAttendance } from './mappers';

const applySearch = <T extends { or: (f: string) => T }>(q: T, search: string | undefined, cols: string[]) =>
  search ? q.or(cols.map((c) => `${c}.ilike.%${search}%`).join(',')) : q;

export const orgs: OrgRepo = {
  async get(orgId) {
    const { data, error } = await supabase().from('orgs').select('*').eq('id', orgId).single();
    throwIf(error);
    if (!data) throw new AppError('not_found', 'Institute not found');
    return toOrg(data);
  },
  async getByCode(code) {
    const { data, error } = await supabase().from('orgs').select('*').ilike('code', code.trim()).maybeSingle();
    throwIf(error);
    return data ? toOrg(data) : null;
  },
  async search(term) {
    const { data, error } = await supabase().from('orgs')
      .select('*').or(`name.ilike.%${term}%,code.ilike.%{term}%`.replace('{term}', term)).limit(20);
    throwIf(error);
    return (data ?? []).map(toOrg);
  },
  async create(input) {
    const code = `${input.name.replace(/[^A-Za-z]/g, '').slice(0, 7).toUpperCase()}-${input.city.slice(0, 3).toUpperCase()}`;
    const { data, error } = await supabase().from('orgs').insert({
      name: input.name, code, city: input.city, state: input.state ?? null,
      board: input.board ?? null, logoUrl: input.logoUrl ?? null, plan: 'trial',
    } as never).select('*').single();
    throwIf(error);
    const org = toOrg(data!);
    // owner membership is created by the caller (memberships.requestJoin is not
    // suitable for owners, so we insert directly here).
    const { error: mErr } = await supabase().from('memberships').insert({
      user_id: input.ownerUserId, org_id: org.id, role: 'owner', status: 'active',
    } as never);
    throwIf(mErr);
    return org;
  },
  async update(orgId, patch) {
    const { data, error } = await supabase().from('orgs').update({
      ...(patch.name !== undefined ? { name: patch.name } : {}),
      ...(patch.city !== undefined ? { city: patch.city } : {}),
      ...(patch.board !== undefined ? { board: patch.board } : {}),
      ...(patch.logoUrl !== undefined ? { logo_url: patch.logoUrl } : {}),
    } as never).eq('id', orgId).select('*').single();
    throwIf(error);
    return toOrg(data!);
  },
};

export const memberships: MembershipRepo = {
  async listMine() {
    const { data: auth } = await supabase().auth.getUser();
    if (!auth.user) return [];
    const { data, error } = await supabase().from('memberships')
      .select('*, orgs(*)').eq('user_id', auth.user.id).order('created_at');
    throwIf(error);
    return (data ?? []).map(toMembership);
  },
  async listPending(orgId) {
    const { data, error } = await supabase().from('memberships')
      .select('*, profiles(full_name, phone)')
      .eq('org_id', orgId).eq('status', 'pending').order('created_at');
    throwIf(error);
    return (data ?? []).map((r: any) => ({
      ...toMembership(r),
      fullName: r.profiles?.full_name ?? 'Unknown',
      phone: r.profiles?.phone ?? null,
    }));
  },
  async requestJoin(orgId, userId) {
    const { data, error } = await supabase().from('memberships')
      .insert({ user_id: userId, org_id: orgId, role: 'student', status: 'pending' } as never)
      .select('*').single();
    throwIf(error);
    return toMembership(data!);
  },
  async approve(orgId, id) {
    const { error } = await supabase().from('memberships')
      .update({ status: 'active' } as never).eq('id', id).eq('org_id', orgId);
    throwIf(error);
  },
  async reject(orgId, id) {
    const { error } = await supabase().from('memberships')
      .update({ status: 'rejected' } as never).eq('id', id).eq('org_id', orgId);
    throwIf(error);
  },
  async approveAll(orgId) {
    const { data, error } = await supabase().from('memberships')
      .update({ status: 'active' } as never).eq('org_id', orgId).eq('status', 'pending').select('id');
    throwIf(error);
    return data?.length ?? 0;
  },
  async setRole(orgId, id, role) {
    const { error } = await supabase().from('memberships')
      .update({ role } as never).eq('id', id).eq('org_id', orgId);
    throwIf(error);
  },
};

export const students: StudentRepo = {
  async list(orgId, q: ListQuery = {}) {
    const { from, to } = pageRange(q.page ?? 0, q.pageSize ?? 20);
    let query = supabase().from('students')
      .select('*', { count: 'exact' }).eq('org_id', orgId);
    if (q.filters?.batchId) query = query.eq('batch_id', String(q.filters.batchId));
    query = applySearch(query as never, q.search, ['full_name', 'roll_no']) as never;
    query = query.order(q.sort?.field ?? 'roll_no', { ascending: (q.sort?.dir ?? 'asc') === 'asc' }).range(from, to);
    const { data, error, count } = await query;
    throwIf(error);
    const rows = (data ?? []).map(toStudent);
    const total = count ?? rows.length;
    return { rows, total, hasMore: from + rows.length < total };
  },
  async get(orgId, id) {
    const { data, error } = await supabase().from('students').select('*').eq('org_id', orgId).eq('id', id).single();
    throwIf(error);
    if (!data) throw new AppError('not_found', 'Student not found');
    return toStudent(data);
  },
  async create(orgId, input) {
    const { count } = await supabase().from('students').select('id', { count: 'exact', head: true }).eq('org_id', orgId);
    const { data: org } = await supabase().from('orgs').select('student_cap').eq('id', orgId).single();
    if (org && count !== null && count >= org.student_cap) {
      throw new AppError('conflict', 'plan_limit');
    }
    const { data, error } = await supabase().from('students').insert({
      org_id: orgId, batch_id: input.batchId, full_name: input.fullName, roll_no: input.rollNo,
      photo_url: input.photoUrl, parent_name: input.parentName, parent_phone: input.parentPhone,
    } as never).select('*').single();
    throwIf(error);
    return toStudent(data!);
  },
  async update(orgId, id, patch) {
    const { data, error } = await supabase().from('students').update({
      ...(patch.fullName !== undefined ? { full_name: patch.fullName } : {}),
      ...(patch.rollNo !== undefined ? { roll_no: patch.rollNo } : {}),
      ...(patch.batchId !== undefined ? { batch_id: patch.batchId } : {}),
      ...(patch.parentName !== undefined ? { parent_name: patch.parentName } : {}),
      ...(patch.parentPhone !== undefined ? { parent_phone: patch.parentPhone } : {}),
      ...(patch.photoUrl !== undefined ? { photo_url: patch.photoUrl } : {}),
    } as never).eq('org_id', orgId).eq('id', id).select('*').single();
    throwIf(error);
    return toStudent(data!);
  },
  async remove(orgId, id) {
    const { error } = await supabase().from('students').delete().eq('org_id', orgId).eq('id', id);
    throwIf(error);
  },
};

export const batches: BatchRepo = {
  async list(orgId, q: ListQuery = {}) {
    let query = supabase().from('batches').select('*').eq('org_id', orgId).order('name');
    if (q.filters?.archived !== undefined) query = query.eq('archived', q.filters.archived === 'true');
    const { data, error } = await query;
    throwIf(error);
    return (data ?? []).map(toBatch);
  },
  async get(orgId, id) {
    const { data, error } = await supabase().from('batches').select('*').eq('org_id', orgId).eq('id', id).single();
    throwIf(error);
    if (!data) throw new AppError('not_found', 'Batch not found');
    return toBatch(data);
  },
  async create(orgId, input) {
    const { data, error } = await supabase().from('batches').insert({
      org_id: orgId, name: input.name, subject: input.subject, days: input.days,
      start_time: input.startTime, end_time: input.endTime,
      monthly_fee: input.monthlyFee, capacity: input.capacity,
      teacher_membership_id: input.teacherMembershipId,
    } as never).select('*').single();
    throwIf(error);
    return toBatch(data!);
  },
  async update(orgId, id, patch) {
    const { data, error } = await supabase().from('batches').update({
      ...(patch.name !== undefined ? { name: patch.name } : {}),
      ...(patch.subject !== undefined ? { subject: patch.subject } : {}),
      ...(patch.days !== undefined ? { days: patch.days } : {}),
      ...(patch.startTime !== undefined ? { start_time: patch.startTime } : {}),
      ...(patch.endTime !== undefined ? { end_time: patch.endTime } : {}),
      ...(patch.monthlyFee !== undefined ? { monthly_fee: patch.monthlyFee } : {}),
      ...(patch.teacherMembershipId !== undefined ? { teacher_membership_id: patch.teacherMembershipId } : {}),
    } as never).eq('org_id', orgId).eq('id', id).select('*').single();
    throwIf(error);
    return toBatch(data!);
  },
  async remove(orgId, id) {
    const { error } = await supabase().from('batches').update({ archived: true } as never).eq('org_id', orgId).eq('id', id);
    throwIf(error);
  },
  async listForTeacher(orgId, membershipId) {
    const { data, error } = await supabase().from('batches').select('*')
      .eq('org_id', orgId).eq('teacher_membership_id', membershipId).eq('archived', false);
    throwIf(error);
    return (data ?? []).map(toBatch);
  },
};

export const attendance: AttendanceRepo = {
  async getSheet(orgId, batchId, date) {
    const { data, error } = await supabase().from('attendance').select('*')
      .eq('org_id', orgId).eq('batch_id', batchId).eq('date', date);
    throwIf(error);
    return (data ?? []).map(toAttendance);
  },
  async saveSheet(orgId, batchId, date, rows) {
    const { data: auth } = await supabase().auth.getUser();
    const payload = rows.map((r) => ({
      org_id: orgId, batch_id: batchId, student_id: r.studentId,
      date, status: r.status, marked_by: auth.user?.id ?? null,
    }));
    const { error } = await supabase().from('attendance')
      .upsert(payload as never, { onConflict: 'student_id,date' });
    throwIf(error);
  },
  async listForStudent(orgId, studentId, range) {
    const { data, error } = await supabase().from('attendance').select('*')
      .eq('org_id', orgId).eq('student_id', studentId)
      .gte('date', range.from).lte('date', range.to).order('date', { ascending: false });
    throwIf(error);
    return (data ?? []).map(toAttendance);
  },
  async monthlySummary(orgId, batchId, month) {
    const from = `${month}-01`;
    const { data, error } = await supabase().from('attendance').select('status')
      .eq('org_id', orgId).eq('batch_id', batchId).gte('date', from);
    throwIf(error);
    const rows = data ?? [];
    const present = rows.filter((r: any) => r.status === 'present').length;
    const late = rows.filter((r: any) => r.status === 'late').length;
    const absent = rows.filter((r: any) => r.status === 'absent').length;
    const total = present + late + absent;
    return { present, late, absent, pct: total ? Math.round(((present + late) / total) * 100) : 0 };
  },
};
