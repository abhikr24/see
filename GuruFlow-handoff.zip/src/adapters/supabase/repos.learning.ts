import type { ExamRepo, MarkRepo, FeeRepo, ContentRepo, NoticeRepo, NotificationRepo, LeaveRepo } from '@/core/contracts/ports';
import type { ListQuery } from '@/core/contracts/query';
import { AppError } from '@/core/contracts/errors';
import { supabase, throwIf } from './client';
import { toExam, toMark, toPayment, toContent, toNotice, toNotification, toLeave, toFeePlan } from './mappers';

export const exams: ExamRepo = {
  async list(orgId, q: ListQuery = {}) {
    const { data, error } = await supabase().from('exams').select('*')
      .eq('org_id', orgId).order('exam_date', { ascending: false });
    throwIf(error);
    return (data ?? []).map(toExam);
  },
  async get(orgId, id) {
    const { data, error } = await supabase().from('exams').select('*').eq('org_id', orgId).eq('id', id).single();
    throwIf(error);
    if (!data) throw new AppError('not_found', 'Exam not found');
    return toExam(data);
  },
  async create(orgId, input) {
    const { data, error } = await supabase().from('exams').insert({
      org_id: orgId, batch_id: input.batchId, name: input.name, subject: input.subject,
      exam_date: input.examDate, max_marks: input.maxMarks,
    } as never).select('*').single();
    throwIf(error);
    return toExam(data!);
  },
  async update(orgId, id, patch) {
    const { data, error } = await supabase().from('exams').update({
      ...(patch.name !== undefined ? { name: patch.name } : {}),
      ...(patch.examDate !== undefined ? { exam_date: patch.examDate } : {}),
      ...(patch.maxMarks !== undefined ? { max_marks: patch.maxMarks } : {}),
    } as never).eq('org_id', orgId).eq('id', id).select('*').single();
    throwIf(error);
    return toExam(data!);
  },
  async remove(orgId, id) {
    const { error } = await supabase().from('exams').delete().eq('org_id', orgId).eq('id', id);
    throwIf(error);
  },
  async getMarks(orgId, examId) {
    const { data, error } = await supabase().from('marks').select('*').eq('org_id', orgId).eq('exam_id', examId);
    throwIf(error);
    return (data ?? []).map(toMark);
  },
  async saveMarks(orgId, examId, rows) {
    const payload = rows.map((r) => ({ org_id: orgId, exam_id: examId, student_id: r.studentId, marks: r.marks }));
    const { error } = await supabase().from('marks').upsert(payload as never, { onConflict: 'exam_id,student_id' });
    throwIf(error);
  },
  async analysis(orgId, examId) {
    const exam = await exams.get(orgId, examId);
    const { data, error } = await supabase().from('marks')
      .select('marks, student_id, students(full_name)').eq('org_id', orgId).eq('exam_id', examId);
    throwIf(error);
    const rows = (data ?? []).map((r: any) => ({ marks: Number(r.marks), name: r.students?.full_name ?? '—', studentId: r.student_id }));
    const vals = rows.map((r) => (r.marks / exam.maxMarks) * 100);
    const avg = vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : 0;
    const top = [...rows].sort((a, b) => b.marks - a.marks).slice(0, 5)
      .map((r) => ({ studentId: r.studentId, name: r.name, marks: r.marks }));
    return {
      average: avg,
      highest: vals.length ? Math.round(Math.max(...vals)) : 0,
      lowest: vals.length ? Math.round(Math.min(...vals)) : 0,
      passRate: vals.length ? Math.round((vals.filter((v) => v >= 35).length / vals.length) * 100) : 0,
      top,
      subjectAvg: [{ subject: exam.subject, average: avg }],
    };
  },
};

export const marks: MarkRepo = {
  async listForStudent(orgId, studentId) {
    const { data, error } = await supabase().from('marks')
      .select('*, exams(name, subject, max_marks)')
      .eq('org_id', orgId).eq('student_id', studentId);
    throwIf(error);
    return (data ?? []).map((r: any) => ({
      ...toMark(r),
      examName: r.exams?.name ?? '—',
      subject: r.exams?.subject ?? '—',
      maxMarks: Number(r.exams?.max_marks ?? 100),
    }));
  },
};

export const fees: FeeRepo = {
  async getPlan(orgId, batchId) {
    const { data, error } = await supabase().from('fee_plans').select('*')
      .eq('org_id', orgId).eq('batch_id', batchId).maybeSingle();
    throwIf(error);
    return data ? toFeePlan(data) : null;
  },
  async savePlan(orgId, input) {
    const { data, error } = await supabase().from('fee_plans').upsert({
      org_id: orgId, batch_id: input.batchId, name: input.name,
      amount: input.amount, instalments: input.instalments,
    } as never, { onConflict: 'org_id,batch_id' }).select('*').single();
    throwIf(error);
    return toFeePlan(data!);
  },
  async listPayments(orgId, q: ListQuery = {}) {
    const { data, error } = await supabase().from('fee_payments').select('*')
      .eq('org_id', orgId).order('paid_on', { ascending: false }).limit(100);
    throwIf(error);
    return (data ?? []).map(toPayment);
  },
  async recordPayment(orgId, input) {
    const { count } = await supabase().from('fee_payments').select('id', { count: 'exact', head: true }).eq('org_id', orgId);
    const receiptNo = `SCB/26-27/${String((count ?? 0) + 1001).padStart(4, '0')}`;
    const { data, error } = await supabase().from('fee_payments').insert({
      org_id: orgId, student_id: input.studentId, term: input.term, amount: input.amount,
      method: input.method, reference: input.reference, receipt_no: receiptNo,
      paid_on: input.paidOn, status: input.status, recorded_by: input.recordedBy,
    } as never).select('*').single();
    throwIf(error);
    return toPayment(data!);
  },
  async totals(orgId, term) {
    const { data, error } = await supabase().from('fee_payments').select('amount, status, term').eq('org_id', orgId);
    throwIf(error);
    const rows = (data ?? []).filter((r: any) => r.term === term);
    const collected = rows.filter((r: any) => r.status === 'confirmed').reduce((a: number, r: any) => a + Number(r.amount), 0);
    const pending = rows.filter((r: any) => r.status === 'pending').reduce((a: number, r: any) => a + Number(r.amount), 0);
    const { data: st } = await supabase().from('students').select('id', { count: 'exact', head: true }).eq('org_id', orgId);
    void st;
    const expected = collected + pending;
    return { collected, pending, overdue: 0, expected };
  },
  async dueList(orgId, term) {
    const { data, error } = await supabase().from('students').select('*').eq('org_id', orgId);
    throwIf(error);
    const { data: pays } = await supabase().from('fee_payments').select('student_id, amount, status, term').eq('org_id', orgId).eq('term', term);
    const paid = new Map<string, number>();
    (pays ?? []).forEach((p: any) => { if (p.status === 'confirmed') paid.set(p.student_id, (paid.get(p.student_id) ?? 0) + Number(p.amount)); });
    const due = 4999;
    return (data ?? [])
      .map((s: any) => ({ ...s, due: Math.max(0, due - (paid.get(s.id) ?? 0)) }))
      .filter((s: any) => s.due > 0)
      .map((s: any) => ({
        id: s.id, orgId: s.org_id, batchId: s.batch_id, fullName: s.full_name, rollNo: s.roll_no,
        photoUrl: s.photo_url, parentName: s.parent_name, parentPhone: s.parent_phone,
        userId: s.user_id, parentUserId: s.parent_user_id, status: s.status,
        due: s.due, daysOverdue: 30,
      }));
  },
};

export const content: ContentRepo = {
  async list(orgId, q: ListQuery = {}) {
    const { data, error } = await supabase().from('content').select('*')
      .eq('org_id', orgId).order('created_at', { ascending: false }).limit(100);
    throwIf(error);
    return (data ?? []).map(toContent);
  },
  async create(orgId, input) {
    const { data, error } = await supabase().from('content').insert({
      org_id: orgId, batch_ids: input.batchIds, type: input.type, title: input.title,
      url: input.url, storage_key: input.storageKey, duration_seconds: input.durationSeconds,
      thumbnail_url: input.thumbnailUrl,
    } as never).select('*').single();
    throwIf(error);
    return toContent(data!);
  },
  async remove(orgId, id) {
    const { error } = await supabase().from('content').delete().eq('org_id', orgId).eq('id', id);
    throwIf(error);
  },
  async storageUsed(orgId) {
    const { data, error } = await supabase().from('content').select('size_bytes').eq('org_id', orgId);
    throwIf(error);
    const used = (data ?? []).reduce((a: number, r: any) => a + Number(r.size_bytes ?? 0), 0);
    return { usedBytes: used, limitBytes: 50 * 1024 * 1024 * 1024 };
  },
};

export const notices: NoticeRepo = {
  async list(orgId, q: ListQuery = {}) {
    const { data, error } = await supabase().from('notices').select('*')
      .eq('org_id', orgId).order('published_at', { ascending: false });
    throwIf(error);
    return (data ?? []).map(toNotice);
  },
  async create(orgId, input) {
    const { data, error } = await supabase().from('notices').insert({
      org_id: orgId, title: input.title, body: input.body, audience: input.audience,
      category: input.category, event_date: input.eventDate, created_by: input.createdBy,
    } as never).select('*').single();
    throwIf(error);
    return toNotice(data!);
  },
  async remove(orgId, id) {
    const { error } = await supabase().from('notices').delete().eq('org_id', orgId).eq('id', id);
    throwIf(error);
  },
};

export const notifications: NotificationRepo = {
  async listMine(q: ListQuery = {}) {
    const { data, error } = await supabase().from('notifications').select('*')
      .order('created_at', { ascending: false }).limit(100);
    throwIf(error);
    return (data ?? []).map(toNotification);
  },
  async markRead(id) {
    const { error } = await supabase().from('notifications').update({ is_read: true } as never).eq('id', id);
    throwIf(error);
  },
  async markAllRead() {
    const { error } = await supabase().from('notifications').update({ is_read: true } as never).eq('is_read', false);
    throwIf(error);
  },
  async unreadCount() {
    const { count, error } = await supabase().from('notifications').select('id', { count: 'exact', head: true }).eq('is_read', false);
    throwIf(error);
    return count ?? 0;
  },
  async create(orgId, userIds, payload) {
    const rows = userIds.map((user_id) => ({ org_id: orgId, user_id, ...payload }));
    if (!rows.length) return;
    const { error } = await supabase().from('notifications').insert(rows as never);
    throwIf(error);
  },
};

export const leave: LeaveRepo = {
  async list(orgId, q: ListQuery = {}) {
    const { data, error } = await supabase().from('leave_requests').select('*')
      .eq('org_id', orgId).order('created_at', { ascending: false });
    throwIf(error);
    return (data ?? []).map(toLeave);
  },
  async create(orgId, input) {
    const { data, error } = await supabase().from('leave_requests').insert({
      org_id: orgId, requester_id: input.requesterId, student_id: input.studentId,
      leave_type: input.leaveType, from_date: input.fromDate, to_date: input.toDate,
      reason: input.reason,
    } as never).select('*').single();
    throwIf(error);
    return toLeave(data!);
  },
  async decide(orgId, id, approved) {
    const { data: auth } = await supabase().auth.getUser();
    const { error } = await supabase().from('leave_requests').update({
      status: approved ? 'approved' : 'rejected',
      decided_by: auth.user?.id ?? null, decided_at: new Date().toISOString(),
    } as never).eq('org_id', orgId).eq('id', id);
    throwIf(error);
  },
};
