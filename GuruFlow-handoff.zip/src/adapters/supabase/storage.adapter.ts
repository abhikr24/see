import type { StoragePort } from '@/core/contracts/ports';
import { AppError } from '@/core/contracts/errors';
import { supabase } from './client';

/**
 * Default adapter writes to Supabase Storage.
 * To move to R2/Bunny later, implement this same interface in another adapter
 * and change one line in src/core/config/providers.ts.
 */
export const storage: StoragePort = {
  async upload(bucket, file, onProgress) {
    const key = `${Date.now()}-${file.name.replace(/\s+/g, '-')}`;
    onProgress?.(10);
    const res = await fetch(file.uri);
    const blob = await res.blob();
    onProgress?.(45);
    const { error } = await supabase().storage.from(bucket).upload(key, blob, {
      contentType: file.mime, upsert: false,
    });
    if (error) throw new AppError('unknown', error.message);
    onProgress?.(100);
    const { data } = supabase().storage.from(bucket).getPublicUrl(key);
    return { url: data.publicUrl, key };
  },
  async remove(bucket, key) {
    const { error } = await supabase().storage.from(bucket).remove([key]);
    if (error) throw new AppError('unknown', error.message);
  },
  async signedUrl(bucket, key, ttlSeconds) {
    const { data, error } = await supabase().storage.from(bucket).createSignedUrl(key, ttlSeconds);
    if (error) throw new AppError('unknown', error.message);
    return data.signedUrl;
  },
};
