import React from 'react';
import { Pressable, View, type ViewProps } from 'react-native';
import { C, R, SHADOW } from '@/lib/theme';

export interface CardProps extends ViewProps {
  onPress?: () => void;
  pad?: number;
  flat?: boolean;
  tint?: string;
  className?: string;
}

export function Card({ onPress, pad = 18, flat, tint, style, className, children, ...rest }: CardProps) {
  const body = (
    <View
      {...rest}
      className={className}
      style={[{
        backgroundColor: tint ?? C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: pad,
        ...(flat ? null : SHADOW),
      }, style]}
    >
      {children}
    </View>
  );
  if (!onPress) return body;
  return <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.92 : 1 })}>{body}</Pressable>;
}
