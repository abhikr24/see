import React from 'react';
import { View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C, GRADIENT, R, SHADOW } from '@/lib/theme';

export function GradientHeader({ children, style }: { children: React.ReactNode; style?: object }) {
  return (
    <LinearGradient
      colors={[GRADIENT[0], GRADIENT[1]]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[{ borderRadius: R.card, padding: 20, ...SHADOW }, style]}
    >
      {children}
    </LinearGradient>
  );
}

/** White card that overlaps the bottom edge of a hero header. */
export function OverlapCard({ children, style }: { children: React.ReactNode; style?: object }) {
  return (
    <View style={[{ backgroundColor: C.surface, borderRadius: R.card, borderWidth: 1, borderColor: C.hairline, padding: 18, marginTop: -22, marginHorizontal: 12, ...SHADOW }, style]}>
      {children}
    </View>
  );
}
