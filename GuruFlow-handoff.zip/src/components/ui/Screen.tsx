import React from 'react';
import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, LAYOUT } from '@/lib/theme';
import { Text } from './Text';

export interface ScreenProps {
  title?: string;
  subtitle?: string;
  right?: React.ReactNode;
  scroll?: boolean;
  padded?: boolean;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

export function Screen({ title, subtitle, right, scroll = true, padded = true, children, footer }: ScreenProps) {
  const head = title ? (
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16, gap: 12 }}>
      <View style={{ flex: 1 }}>
        <Text variant="h1">{title}</Text>
        {subtitle ? <Text variant="caption" c={C.secondary} style={{ marginTop: 4 }}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  ) : null;

  const body = (
    <View style={{ flex: 1, paddingHorizontal: padded ? LAYOUT.margin : 0 }}>
      {head}
      {scroll ? <ScrollView contentContainerStyle={{ paddingBottom: 32, gap: 16 }} showsVerticalScrollIndicator={false}>{children}</ScrollView> : children}
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
      {body}
      {footer ? <View style={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 12, paddingTop: 8 }}>{footer}</View> : null}
    </SafeAreaView>
  );
}
