import React from 'react';
import { Modal, Pressable, View } from 'react-native';
import { C, R } from '@/lib/theme';
import { Text } from './Text';

export function Sheet({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title?: string; children: React.ReactNode }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable onPress={onClose} style={{ flex: 1, backgroundColor: 'rgba(11,18,32,0.45)', justifyContent: 'flex-end' }}>
        <Pressable
          onPress={(e) => e.stopPropagation()}
          style={{
            backgroundColor: C.surface, borderTopLeftRadius: R.sheet, borderTopRightRadius: R.sheet,
            paddingHorizontal: 20, paddingBottom: 28, paddingTop: 10, maxHeight: '60%',
          }}
        >
          <View style={{ alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: C.hairline, marginBottom: 14 }} />
          {title ? <Text variant="h2" style={{ marginBottom: 14 }}>{title}</Text> : null}
          {children}
        </Pressable>
      </Pressable>
    </Modal>
  );
}
