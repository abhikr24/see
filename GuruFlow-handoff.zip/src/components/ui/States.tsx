import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C } from '@/lib/theme';
import { Text } from './Text';
import { Button } from './Button';

export function Skeleton({ h = 16, w = '100%', r = 8 }: { h?: number; w?: number | string; r?: number }) {
  return <View style={{ height: h, width: w as number, borderRadius: r, backgroundColor: C.track }} />;
}

export function ListSkeleton({ rows = 5, h = 68 }: { rows?: number; h?: number }) {
  return (
    <View style={{ gap: 12 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <View key={i} style={{ height: h, borderRadius: 20, backgroundColor: C.surface, borderWidth: 1, borderColor: C.hairline, padding: 14, flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.track }} />
          <View style={{ flex: 1, gap: 8 }}>
            <Skeleton h={12} w="55%" />
            <Skeleton h={10} w="35%" />
          </View>
        </View>
      ))}
    </View>
  );
}

export function EmptyState({ icon = 'file-tray-outline', title, text, actionLabel, onAction }: {
  icon?: keyof typeof Ionicons.glyphMap; title: string; text?: string; actionLabel?: string; onAction?: () => void;
}) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: 24, gap: 10 }}>
      <View style={{ width: 96, height: 96, borderRadius: 48, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center', marginBottom: 6 }}>
        <Ionicons name={icon} size={40} color={C.primary} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>{title}</Text>
      {text ? <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 260 }}>{text}</Text> : null}
      {actionLabel && onAction ? <View style={{ marginTop: 10 }}><Button title={actionLabel} onPress={onAction} size="md" full={false} /></View> : null}
    </View>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: 24, gap: 10 }}>
      <View style={{ width: 96, height: 96, borderRadius: 48, backgroundColor: C.dangerSoft, alignItems: 'center', justifyContent: 'center', marginBottom: 6 }}>
        <Ionicons name="alert-circle-outline" size={40} color={C.danger} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>Could not load this</Text>
      <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 260 }}>{message}</Text>
      {onRetry ? <View style={{ marginTop: 10 }}><Button title="Try again" onPress={onRetry} size="md" full={false} /></View> : null}
    </View>
  );
}
