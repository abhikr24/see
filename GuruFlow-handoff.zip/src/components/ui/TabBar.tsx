import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter, usePathname } from 'expo-router';
import { C, SHADOW } from '@/lib/theme';
import { Text } from './Text';
import type { TabDef } from '@/lib/nav';

export function TabBar({ tabs }: { tabs: TabDef[] }) {
  const router = useRouter();
  const pathname = usePathname();

  return (
    <View style={{
      flexDirection: 'row', backgroundColor: C.surface, borderRadius: 28,
      paddingVertical: 8, paddingHorizontal: 8, marginHorizontal: 12, marginBottom: 10,
      ...SHADOW,
    }}>
      {tabs.map((t) => {
        const active = pathname === t.route || (t.key === 'home' && pathname.endsWith(')'));
        return (
          <Pressable
            key={t.key}
            onPress={() => router.push(t.route as never)}
            style={{ flex: 1, alignItems: 'center', gap: 3, paddingVertical: 4 }}
          >
            <View style={{ width: 46, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: active ? C.navySoft : 'transparent' }}>
              <Ionicons name={(active ? t.iconActive : t.icon) as keyof typeof Ionicons.glyphMap} size={20} color={active ? C.primary : C.muted} />
            </View>
            <Text variant="label" weight={600} c={active ? C.primary : C.muted} style={{ fontSize: 9.5 }}>{t.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}
