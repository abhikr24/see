import React, { createContext, useContext } from 'react';
import { useMutation, useQuery, useQueryClient, type QueryKey } from '@tanstack/react-query';
import type { Backend } from './contracts/ports';
import type { ListQuery } from './contracts/query';
import { backend as activeBackend } from './config/providers';

const BackendContext = createContext<Backend>(activeBackend);
export const BackendProvider = ({ children, value }: { children: React.ReactNode; value?: Backend }) => (
  <BackendContext.Provider value={value ?? activeBackend}>{children}</BackendContext.Provider>
);
export const useBackend = (): Backend => useContext(BackendContext);

/** Shared query shape: every list hook returns the same fields. */
export interface QueryResult<T> {
  data: T | undefined;
  loading: boolean;
  error: Error | null;
  refetch: () => void;
}

function useDomainQuery<T>(key: QueryKey, fn: () => Promise<T>, enabled = true): QueryResult<T> {
  const q = useQuery<T, Error>({ queryKey: key, queryFn: fn, enabled, staleTime: 30_000 });
  return { data: q.data, loading: q.isLoading, error: q.error ?? null, refetch: q.refetch };
}

function useDomainMutation<TArgs, TResult>(fn: (a: TArgs) => Promise<TResult>, invalidate: QueryKey[]) {
  const qc = useQueryClient();
  return useMutation<TResult, Error, TArgs>({
    mutationFn: fn,
    onSuccess: () => invalidate.forEach((k) => qc.invalidateQueries({ queryKey: k })),
  });
}

// ─────────────────────────── students ───────────────────────────
export const studentKeys = {
  list: (orgId: string, q?: ListQuery) => ['students', orgId, q ?? {}] as const,
  one: (orgId: string, id: string) => ['student', orgId, id] as const,
};
export const useStudents = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(studentKeys.list(orgId, q), () => b.students.list(orgId, q), !!orgId);
};
export const useStudent = (orgId: string, id: string) => {
  const b = useBackend();
  return useDomainQuery(studentKeys.one(orgId, id), () => b.students.get(orgId, id), !!orgId && !!id);
};
export const useCreateStudent = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation((input: Parameters<Backend['students']['create']>[1]) => b.students.create(orgId, input), [['students', orgId]]);
};

// ─────────────────────────── batches ────────────────────────────
export const useBatches = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['batches', orgId, q ?? {}], () => b.batches.list(orgId, q), !!orgId);
};
export const useBatch = (orgId: string, id: string) => {
  const b = useBackend();
  return useDomainQuery(['batch', orgId, id], () => b.batches.get(orgId, id), !!orgId && !!id);
};

// ────────────────────────── attendance ──────────────────────────
export const useAttendanceSheet = (orgId: string, batchId: string, date: string) => {
  const b = useBackend();
  return useDomainQuery(['attendance', orgId, batchId, date], () => b.attendance.getSheet(orgId, batchId, date), !!batchId && !!date);
};
export const useSaveAttendance = (orgId: string, batchId: string, date: string) => {
  const b = useBackend();
  return useDomainMutation(
    (rows: Parameters<Backend['attendance']['saveSheet']>[3]) => b.attendance.saveSheet(orgId, batchId, date, rows),
    [['attendance', orgId, batchId, date]],
  );
};

// ──────────────────────────── exams ─────────────────────────────
export const useExams = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['exams', orgId, q ?? {}], () => b.exams.list(orgId, q), !!orgId);
};
export const useExamAnalysis = (orgId: string, examId: string) => {
  const b = useBackend();
  return useDomainQuery(['exam-analysis', orgId, examId], () => b.exams.analysis(orgId, examId), !!examId);
};
export const useMarksForStudent = (orgId: string, studentId: string) => {
  const b = useBackend();
  return useDomainQuery(['marks', orgId, studentId], () => b.marks.listForStudent(orgId, studentId), !!studentId);
};

// ───────────────────────────── fees ─────────────────────────────
export const useFeeTotals = (orgId: string, term: string) => {
  const b = useBackend();
  return useDomainQuery(['fee-totals', orgId, term], () => b.fees.totals(orgId, term), !!orgId);
};
export const usePayments = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['payments', orgId, q ?? {}], () => b.fees.listPayments(orgId, q), !!orgId);
};
export const useDueList = (orgId: string, term: string) => {
  const b = useBackend();
  return useDomainQuery(['dues', orgId, term], () => b.fees.dueList(orgId, term), !!orgId);
};

// ──────────────────────────── content ───────────────────────────
export const useContent = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['content', orgId, q ?? {}], () => b.content.list(orgId, q), !!orgId);
};

// ──────────────────────────── notices ───────────────────────────
export const useNotices = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['notices', orgId, q ?? {}], () => b.notices.list(orgId, q), !!orgId);
};

// ───────────────────────── notifications ────────────────────────
export const useNotifications = (q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['notifications', q ?? {}], () => b.notifications.listMine(q));
};
export const useUnreadCount = () => {
  const b = useBackend();
  return useDomainQuery(['notifications', 'unread'], () => b.notifications.unreadCount());
};

// ───────────────────────────── leave ────────────────────────────
export const useLeave = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(['leave', orgId, q ?? {}], () => b.leave.list(orgId, q), !!orgId);
};

// ──────────────────────────── members ───────────────────────────
export const useMyMemberships = () => {
  const b = useBackend();
  return useDomainQuery(['memberships', 'mine'], () => b.memberships.listMine());
};
export const usePendingMemberships = (orgId: string) => {
  const b = useBackend();
  return useDomainQuery(['memberships', 'pending', orgId], () => b.memberships.listPending(orgId), !!orgId);
};
