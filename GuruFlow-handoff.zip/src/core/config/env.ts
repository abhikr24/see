/**
 * One place that reads the environment. Validates loudly.
 * Swapping backends starts here and ends in providers.ts.
 */
const raw = {
  backend: process.env.EXPO_PUBLIC_BACKEND ?? 'supabase',
  supabaseUrl: (process.env.EXPO_PUBLIC_SUPABASE_URL ?? '').trim(),
  supabaseAnonKey: (process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '').trim(),
};

export const env = raw;

export type BackendName = 'supabase';

export function assertEnv(): void {
  const missing: string[] = [];
  if (raw.backend === 'supabase') {
    if (!raw.supabaseUrl) missing.push('EXPO_PUBLIC_SUPABASE_URL');
    if (!raw.supabaseAnonKey) missing.push('EXPO_PUBLIC_SUPABASE_ANON_KEY');
  }
  if (missing.length) {
    throw new Error(
      `Missing environment variables: ${missing.join(', ')}.\n` +
        'Copy .env.example to .env and fill them in. See docs/ADDING_A_BACKEND.md.',
    );
  }
}

export const hasEnv = (): boolean => {
  try { assertEnv(); return true; } catch { return false; }
};
