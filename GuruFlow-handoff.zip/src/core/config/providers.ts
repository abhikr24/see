/**
 * ═══════════════════════════════════════════════════════════════════
 *  THE SWAP FILE
 *  This is the only file in the project that names a backend vendor.
 *  To change backend: add src/adapters/<vendor>/, implement Backend,
 *  then change the single line below. Nothing else in the app moves.
 * ═══════════════════════════════════════════════════════════════════
 */
import type { Backend } from '@/core/contracts/ports';
import { supabaseAdapter } from '@/adapters/supabase';

export const backend: Backend = supabaseAdapter;
