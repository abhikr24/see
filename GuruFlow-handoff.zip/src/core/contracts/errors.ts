export type AppErrorCode =
  | 'unauthorized'
  | 'not_found'
  | 'conflict'
  | 'validation'
  | 'network'
  | 'unknown';

export class AppError extends Error {
  readonly code: AppErrorCode;
  readonly cause?: unknown;

  constructor(code: AppErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.cause = cause;
  }
}

export const isAppError = (e: unknown): e is AppError => e instanceof AppError;

/** Normalise anything thrown by an adapter into an AppError. */
export function toAppError(e: unknown, fallback: AppErrorCode = 'unknown'): AppError {
  if (isAppError(e)) return e;
  if (e instanceof Error) {
    const msg = e.message || 'Something went wrong';
    if (/network|fetch|timeout/i.test(msg)) return new AppError('network', 'Check your connection and try again.', e);
    return new AppError(fallback, msg, e);
  }
  return new AppError(fallback, 'Something went wrong', e);
}

/** Human-readable copy for each code — used by toasts. */
export const ERROR_COPY: Record<AppErrorCode, string> = {
  unauthorized: 'You do not have access to this.',
  not_found: 'That record no longer exists.',
  conflict: 'That already exists.',
  validation: 'Please check the details and try again.',
  network: 'You are offline. We will retry.',
  unknown: 'Something went wrong. Please try again.',
};
