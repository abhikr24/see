/**
 * Plain domain types. camelCase. No database shapes, no SDK types.
 * Nothing above the adapter layer may see a row type.
 */

export type Role = 'owner' | 'teacher' | 'student' | 'parent';
export type MembershipStatus = 'pending' | 'active' | 'rejected';
export type AttendanceStatus = 'present' | 'absent' | 'late';
export type PaymentStatus = 'pending' | 'confirmed' | 'rejected';
export type ContentType = 'video' | 'pdf' | 'link';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';
export type NotificationType = 'announcement' | 'homework' | 'fee' | 'exam' | 'leave' | 'attendance';

export interface Org {
  id: string;
  name: string;
  code: string;
  city: string;
  state: string | null;
  board: string | null;
  logoUrl: string | null;
  plan: string;
  status: string;
}

export interface Profile {
  id: string;
  fullName: string;
  phone: string | null;
  avatarUrl: string | null;
}

export interface Membership {
  id: string;
  userId: string;
  orgId: string;
  role: Role;
  status: MembershipStatus;
  org?: Org;
  createdAt: string;
}

export interface Batch {
  id: string;
  orgId: string;
  name: string;
  subject: string;
  teacherMembershipId: string | null;
  teacherName?: string | null;
  days: string[];
  startTime: string | null;
  endTime: string | null;
  monthlyFee: number;
  capacity: number | null;
  studentCount?: number;
  attendancePct?: number;
  pendingFees?: number;
}

export interface Student {
  id: string;
  orgId: string;
  batchId: string | null;
  fullName: string;
  rollNo: string | null;
  photoUrl: string | null;
  parentName: string | null;
  parentPhone: string | null;
  userId: string | null;
  parentUserId: string | null;
  status: string;
  attendancePct?: number;
  feeDue?: number;
  absentToday?: boolean;
}

export interface Attendance {
  id: string;
  orgId: string;
  batchId: string;
  studentId: string;
  date: string;
  status: AttendanceStatus;
  markedBy: string | null;
}

export interface Homework {
  id: string;
  orgId: string;
  batchId: string;
  subject: string;
  title: string;
  description: string | null;
  dueAt: string;
  createdBy: string | null;
  submittedCount?: number;
  totalCount?: number;
}

export interface Submission {
  id: string;
  homeworkId: string;
  studentId: string;
  fileUrl: string | null;
  submittedAt: string;
  grade: string | null;
}

export interface Exam {
  id: string;
  orgId: string;
  batchId: string;
  name: string;
  subject: string;
  examDate: string;
  maxMarks: number;
  enteredCount?: number;
  totalCount?: number;
}

export interface Mark {
  id: string;
  examId: string;
  studentId: string;
  marks: number;
}

export interface ContentItem {
  id: string;
  orgId: string;
  batchIds: string[];
  type: ContentType;
  title: string;
  url: string;
  storageKey: string | null;
  durationSeconds: number | null;
  thumbnailUrl: string | null;
  createdAt: string;
}

export interface FeePlan {
  id: string;
  orgId: string;
  batchId: string | null;
  name: string;
  amount: number;
  instalments: { label: string; dueDate: string; amount: number }[];
}

export interface FeePayment {
  id: string;
  orgId: string;
  studentId: string;
  term: string;
  amount: number;
  method: string;
  reference: string | null;
  receiptNo: string;
  paidOn: string;
  status: PaymentStatus;
  recordedBy: string | null;
}

export interface FeeTotals {
  collected: number;
  pending: number;
  overdue: number;
  expected: number;
}

export interface Notice {
  id: string;
  orgId: string;
  title: string;
  body: string;
  audience: string[];
  category: string;
  eventDate: string | null;
  createdBy: string | null;
  publishedAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  orgId: string;
  title: string;
  body: string;
  type: NotificationType;
  isRead: boolean;
  createdAt: string;
}

export interface LeaveRequest {
  id: string;
  orgId: string;
  requesterId: string;
  studentId: string | null;
  leaveType: string;
  fromDate: string;
  toDate: string;
  reason: string | null;
  status: LeaveStatus;
  decidedBy: string | null;
  decidedAt: string | null;
}
