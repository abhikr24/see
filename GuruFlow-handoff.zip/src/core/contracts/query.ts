export interface ListQuery {
  search?: string;
  filters?: Record<string, string | string[]>;
  sort?: { field: string; dir: 'asc' | 'desc' };
  page?: number;
  pageSize?: number;
}

export interface Paginated<T> {
  rows: T[];
  total: number;
  hasMore: boolean;
}

export const emptyPage = <T>(): Paginated<T> => ({ rows: [], total: 0, hasMore: false });
