import type { Role } from '@/core/contracts/models';

export interface TabDef {
  key: string;
  label: string;
  icon: string;
  iconActive: string;
  route: string;
}

/**
 * Tabs are config-driven. Adding a tab = one entry here + one route file.
 * Never hardcode tabs in JSX.
 */
export const TABS: Record<Role, TabDef[]> = {
  owner: [
    { key: 'home', label: 'Home', icon: 'home-outline', iconActive: 'home', route: '/(owner)' },
    { key: 'students', label: 'Students', icon: 'people-outline', iconActive: 'people', route: '/(owner)/students' },
    { key: 'batches', label: 'Batches', icon: 'albums-outline', iconActive: 'albums', route: '/(owner)/batches' },
    { key: 'fees', label: 'Fees', icon: 'wallet-outline', iconActive: 'wallet', route: '/(owner)/fees' },
    { key: 'more', label: 'More', icon: 'grid-outline', iconActive: 'grid', route: '/(owner)/more' },
  ],
  teacher: [
    { key: 'home', label: 'Home', icon: 'home-outline', iconActive: 'home', route: '/(teacher)' },
    { key: 'classes', label: 'Classes', icon: 'library-outline', iconActive: 'library', route: '/(teacher)/classes' },
    { key: 'homework', label: 'Homework', icon: 'book-outline', iconActive: 'book', route: '/(teacher)/homework' },
    { key: 'exams', label: 'Exams', icon: 'document-text-outline', iconActive: 'document-text', route: '/(teacher)/exams' },
    { key: 'more', label: 'More', icon: 'grid-outline', iconActive: 'grid', route: '/(teacher)/more' },
  ],
  student: [
    { key: 'home', label: 'Home', icon: 'home-outline', iconActive: 'home', route: '/(student)' },
    { key: 'attendance', label: 'Attendance', icon: 'calendar-outline', iconActive: 'calendar', route: '/(student)/attendance' },
    { key: 'homework', label: 'Homework', icon: 'book-outline', iconActive: 'book', route: '/(student)/homework' },
    { key: 'results', label: 'Results', icon: 'trophy-outline', iconActive: 'trophy', route: '/(student)/results' },
    { key: 'more', label: 'More', icon: 'grid-outline', iconActive: 'grid', route: '/(student)/more' },
  ],
  parent: [
    { key: 'home', label: 'Home', icon: 'home-outline', iconActive: 'home', route: '/(parent)' },
    { key: 'attendance', label: 'Attendance', icon: 'calendar-outline', iconActive: 'calendar', route: '/(parent)/attendance' },
    { key: 'fees', label: 'Fees', icon: 'wallet-outline', iconActive: 'wallet', route: '/(parent)/fees' },
    { key: 'notices', label: 'Notices', icon: 'megaphone-outline', iconActive: 'megaphone', route: '/(parent)/notices' },
    { key: 'more', label: 'More', icon: 'grid-outline', iconActive: 'grid', route: '/(parent)/more' },
  ],
};
