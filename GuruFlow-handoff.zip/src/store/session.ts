import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Membership, Role } from '@/core/contracts/models';

interface SessionState {
  userId: string | null;
  memberships: Membership[];
  activeOrgId: string | null;
  setUserId: (id: string | null) => void;
  setMemberships: (m: Membership[]) => void;
  switchOrg: (orgId: string) => void;
  reset: () => void;
}

export const useSession = create<SessionState>()(
  persist(
    (set, get) => ({
      userId: null,
      memberships: [],
      activeOrgId: null,
      setUserId: (id) => set({ userId: id }),
      setMemberships: (memberships) => {
        const active = memberships.filter((m) => m.status === 'active');
        const current = get().activeOrgId;
        const keep = current && active.some((m) => m.orgId === current) ? current : active[0]?.orgId ?? null;
        set({ memberships, activeOrgId: keep });
      },
      switchOrg: (orgId) => set({ activeOrgId: orgId }),
      reset: () => set({ userId: null, memberships: [], activeOrgId: null }),
    }),
    { name: 'guruflow-session', storage: createJSONStorage(() => AsyncStorage) },
  ),
);

export const activeMembership = (s: SessionState): Membership | undefined =>
  s.memberships.find((m) => m.orgId === s.activeOrgId && m.status === 'active');

export const activeRole = (s: SessionState): Role | null => activeMembership(s)?.role ?? null;

export const allPending = (s: SessionState): boolean =>
  s.memberships.length > 0 && s.memberships.every((m) => m.status === 'pending');
