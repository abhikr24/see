-- Attach demo auth users to the seeded institute.
-- STEP 1: create these users in Supabase → Authentication → Users (or let them sign up):
--   owner@sunrise.demo    / demo1234
--   teacher@sunrise.demo  / demo1234
--   student@sunrise.demo  / demo1234
--   parent@sunrise.demo   / demo1234
-- STEP 2: run this file. It links each auth user to the seeded org.

with o as (select id from public.orgs where code = 'SUNRISE-PAT')
insert into public.profiles (id, full_name, phone)
select id, raw_user_meta_data->>'full_name', phone from auth.users
on conflict (id) do nothing;

insert into public.memberships (user_id, org_id, role, status)
select u.id, o.id, 'owner', 'active' from auth.users u, public.orgs o
where u.email = 'owner@sunrise.demo' and o.code = 'SUNRISE-PAT'
on conflict (user_id, org_id) do nothing;

insert into public.memberships (user_id, org_id, role, status)
select u.id, o.id, 'teacher', 'active' from auth.users u, public.orgs o
where u.email = 'teacher@sunrise.demo' and o.code = 'SUNRISE-PAT'
on conflict (user_id, org_id) do nothing;

insert into public.memberships (user_id, org_id, role, status)
select u.id, o.id, 'student', 'active' from auth.users u, public.orgs o
where u.email = 'student@sunrise.demo' and o.code = 'SUNRISE-PAT'
on conflict (user_id, org_id) do nothing;

update public.students s
set user_id = u.id
from auth.users u
where u.email = 'student@sunrise.demo' and s.full_name = 'Aarav Sharma';

update public.students s
set parent_user_id = u.id
from auth.users u
where u.email = 'parent@sunrise.demo' and s.full_name = 'Aarav Sharma';

insert into public.memberships (user_id, org_id, role, status)
select u.id, o.id, 'parent', 'active' from auth.users u, public.orgs o
where u.email = 'parent@sunrise.demo' and o.code = 'SUNRISE-PAT'
on conflict (user_id, org_id) do nothing;
