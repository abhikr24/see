-- GuruFlow · 0001_init
create extension if not exists "pgcrypto";

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create type role_t as enum ('owner','teacher','student','parent');
create type membership_status_t as enum ('pending','active','rejected');
create type attendance_status_t as enum ('present','absent','late');
create type payment_status_t as enum ('pending','confirmed','rejected');
create type content_type_t as enum ('video','pdf','link');
create type leave_status_t as enum ('pending','approved','rejected');

create table public.orgs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  city text not null,
  state text,
  board text,
  logo_url text,
  plan text not null default 'trial',
  student_cap int not null default 300,
  storage_cap_bytes bigint not null default 53687091200,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.memberships (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  org_id uuid not null references public.orgs(id) on delete cascade,
  role role_t not null,
  status membership_status_t not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, org_id)
);

create table public.batches (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  name text not null,
  subject text not null,
  teacher_membership_id uuid references public.memberships(id) on delete set null,
  days text[] not null default '{}',
  start_time time,
  end_time time,
  monthly_fee numeric not null default 0,
  capacity int,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  batch_id uuid references public.batches(id) on delete set null,
  full_name text not null,
  roll_no text,
  photo_url text,
  parent_name text,
  parent_phone text,
  user_id uuid references auth.users(id) on delete set null,
  parent_user_id uuid references auth.users(id) on delete set null,
  status text not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  batch_id uuid not null references public.batches(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  date date not null,
  status attendance_status_t not null,
  marked_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, date)
);

create table public.homework (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  batch_id uuid not null references public.batches(id) on delete cascade,
  subject text not null,
  title text not null,
  description text,
  due_at timestamptz not null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.homework_submissions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  homework_id uuid not null references public.homework(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  file_url text,
  submitted_at timestamptz not null default now(),
  grade text,
  unique (homework_id, student_id)
);

create table public.exams (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  batch_id uuid not null references public.batches(id) on delete cascade,
  name text not null,
  subject text not null,
  exam_date date not null,
  max_marks numeric not null default 100,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.marks (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  marks numeric not null,
  unique (exam_id, student_id)
);

create table public.content (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  batch_ids uuid[] not null default '{}',
  type content_type_t not null,
  title text not null,
  url text not null,
  storage_key text,
  size_bytes bigint default 0,
  duration_seconds int,
  thumbnail_url text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.fee_plans (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  batch_id uuid references public.batches(id) on delete cascade,
  name text not null,
  amount numeric not null default 0,
  instalments jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.fee_payments (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  term text not null,
  amount numeric not null,
  method text not null default 'upi',
  reference text,
  receipt_no text not null,
  paid_on date not null default current_date,
  status payment_status_t not null default 'pending',
  recorded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.notices (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  title text not null,
  body text not null,
  audience text[] not null default '{}',
  category text not null default 'general',
  event_date date,
  created_by uuid references auth.users(id) on delete set null,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  type text not null default 'announcement',
  is_read boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.leave_requests (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  requester_id uuid not null references auth.users(id) on delete cascade,
  student_id uuid references public.students(id) on delete cascade,
  leave_type text not null,
  from_date date not null,
  to_date date not null,
  reason text,
  status leave_status_t not null default 'pending',
  decided_by uuid references auth.users(id) on delete set null,
  decided_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- updated_at triggers
do $$
declare t text;
begin
  foreach t in array array['orgs','profiles','memberships','batches','students','attendance',
    'homework','exams','content','fee_plans','fee_payments','notices','notifications','leave_requests']
  loop
    execute format('drop trigger if exists trg_%s_updated on public.%I', t, t);
    execute format('create trigger trg_%s_updated before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

create index idx_memberships_user on public.memberships(user_id, org_id);
create index idx_students_org_batch on public.students(org_id, batch_id);
create index idx_attendance_student_date on public.attendance(student_id, date);
create index idx_attendance_batch_date on public.attendance(batch_id, date);
create index idx_marks_exam on public.marks(exam_id);
create index idx_payments_student on public.fee_payments(student_id);
create index idx_notifications_user on public.notifications(user_id, is_read);
create index idx_content_org on public.content(org_id);
