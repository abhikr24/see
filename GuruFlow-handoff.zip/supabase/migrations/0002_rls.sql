-- GuruFlow · 0002_rls
-- Every table is org-scoped. A pending membership grants nothing.

create or replace function public.auth_org_ids()
returns setof uuid language sql stable security definer set search_path = public as $$
  select org_id from public.memberships
  where user_id = auth.uid() and status = 'active'
$$;

create or replace function public.has_role(org uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.memberships
    where user_id = auth.uid() and org_id = org and status = 'active'
      and role::text = any(roles)
  )
$$;

create or replace function public.my_student_ids()
returns setof uuid language sql stable security definer set search_path = public as $$
  select id from public.students
  where user_id = auth.uid() or parent_user_id = auth.uid()
$$;

-- A user may only claim owner when creating the org, and principal-type
-- escalation is blocked entirely: only an owner can change a role.
create or replace function public.membership_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (new.role is distinct from old.role or new.org_id is distinct from old.org_id
      or new.user_id is distinct from old.user_id) then
    if not public.has_role(old.org_id, array['owner']) then
      raise exception 'Only an institute owner can change a role';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_membership_guard on public.memberships;
create trigger trg_membership_guard before update on public.memberships
  for each row execute function public.membership_guard();

alter table public.orgs             enable row level security;
alter table public.profiles         enable row level security;
alter table public.memberships      enable row level security;
alter table public.batches          enable row level security;
alter table public.students         enable row level security;
alter table public.attendance       enable row level security;
alter table public.homework         enable row level security;
alter table public.homework_submissions enable row level security;
alter table public.exams            enable row level security;
alter table public.marks            enable row level security;
alter table public.content          enable row level security;
alter table public.fee_plans        enable row level security;
alter table public.fee_payments     enable row level security;
alter table public.notices          enable row level security;
alter table public.notifications    enable row level security;
alter table public.leave_requests   enable row level security;

-- ── orgs ────────────────────────────────────────────────────────────
-- readable by members (active) and by anyone searching by exact code
create policy orgs_read on public.orgs for select
  using (id in (select public.auth_org_ids())
         or exists (select 1 from public.memberships m
                    where m.org_id = orgs.id and m.user_id = auth.uid()));
create policy orgs_insert on public.orgs for insert to authenticated with check (true);
create policy orgs_update on public.orgs for update
  using (public.has_role(id, array['owner'])) with check (public.has_role(id, array['owner']));

-- ── profiles ────────────────────────────────────────────────────────
create policy profiles_self_read on public.profiles for select
  using (id = auth.uid()
         or exists (select 1 from public.memberships a
                    join public.memberships b on a.org_id = b.org_id
                    where a.user_id = auth.uid() and a.status='active'
                      and b.user_id = profiles.id and b.status='active'));
create policy profiles_self_write on public.profiles for insert to authenticated with check (id = auth.uid());
create policy profiles_self_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- ── memberships ─────────────────────────────────────────────────────
create policy memberships_read on public.memberships for select
  using (user_id = auth.uid() or org_id in (select public.auth_org_ids()));
create policy memberships_insert on public.memberships for insert to authenticated
  with check (user_id = auth.uid());
create policy memberships_owner_update on public.memberships for update
  using (public.has_role(org_id, array['owner'])) with check (public.has_role(org_id, array['owner']));
create policy memberships_owner_delete on public.memberships for delete
  using (public.has_role(org_id, array['owner']));

-- ── batches ─────────────────────────────────────────────────────────
create policy batches_read on public.batches for select
  using (org_id in (select public.auth_org_ids()));
create policy batches_write on public.batches for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── students ────────────────────────────────────────────────────────
create policy students_read on public.students for select
  using (org_id in (select public.auth_org_ids())
         and (public.has_role(org_id, array['owner','teacher'])
              or id in (select public.my_student_ids())));
create policy students_write on public.students for all
  using (public.has_role(org_id, array['owner']))
  with check (public.has_role(org_id, array['owner']));

-- ── attendance ──────────────────────────────────────────────────────
create policy attendance_read on public.attendance for select
  using (org_id in (select public.auth_org_ids())
         and (public.has_role(org_id, array['owner','teacher'])
              or student_id in (select public.my_student_ids())));
create policy attendance_write on public.attendance for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── homework ────────────────────────────────────────────────────────
create policy homework_read on public.homework for select
  using (org_id in (select public.auth_org_ids()));
create policy homework_write on public.homework for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

create policy submissions_read on public.homework_submissions for select
  using (org_id in (select public.auth_org_ids())
         and (public.has_role(org_id, array['owner','teacher'])
              or student_id in (select public.my_student_ids())));
create policy submissions_student_insert on public.homework_submissions for insert to authenticated
  with check (student_id in (select public.my_student_ids())
              and org_id in (select public.auth_org_ids()));
create policy submissions_teacher_update on public.homework_submissions for update
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── exams & marks ───────────────────────────────────────────────────
create policy exams_read on public.exams for select
  using (org_id in (select public.auth_org_ids()));
create policy exams_write on public.exams for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

create policy marks_read on public.marks for select
  using (org_id in (select public.auth_org_ids())
         and (public.has_role(org_id, array['owner','teacher'])
              or student_id in (select public.my_student_ids())));
create policy marks_write on public.marks for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── content ─────────────────────────────────────────────────────────
create policy content_read on public.content for select
  using (org_id in (select public.auth_org_ids()));
create policy content_write on public.content for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── fees ────────────────────────────────────────────────────────────
create policy fee_plans_read on public.fee_plans for select
  using (org_id in (select public.auth_org_ids()));
create policy fee_plans_write on public.fee_plans for all
  using (public.has_role(org_id, array['owner']))
  with check (public.has_role(org_id, array['owner']));

create policy payments_read on public.fee_payments for select
  using (org_id in (select public.auth_org_ids())
         and (public.has_role(org_id, array['owner'])
              or student_id in (select public.my_student_ids())));
create policy payments_owner_write on public.fee_payments for all
  using (public.has_role(org_id, array['owner']))
  with check (public.has_role(org_id, array['owner']));
-- a parent may only create a pending claim for their own child
create policy payments_parent_claim on public.fee_payments for insert to authenticated
  with check (status = 'pending'
              and student_id in (select public.my_student_ids())
              and org_id in (select public.auth_org_ids()));

-- ── notices ─────────────────────────────────────────────────────────
create policy notices_read on public.notices for select
  using (org_id in (select public.auth_org_ids()));
create policy notices_write on public.notices for all
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── notifications ───────────────────────────────────────────────────
create policy notif_own_read on public.notifications for select using (user_id = auth.uid());
create policy notif_own_update on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy notif_own_delete on public.notifications for delete using (user_id = auth.uid());
create policy notif_staff_insert on public.notifications for insert to authenticated
  with check (public.has_role(org_id, array['owner','teacher']));

-- ── leave ───────────────────────────────────────────────────────────
create policy leave_read on public.leave_requests for select
  using (org_id in (select public.auth_org_ids())
         and (requester_id = auth.uid()
              or public.has_role(org_id, array['owner','teacher'])));
create policy leave_insert on public.leave_requests for insert to authenticated
  with check (requester_id = auth.uid() and org_id in (select public.auth_org_ids()));
create policy leave_decide on public.leave_requests for update
  using (public.has_role(org_id, array['owner','teacher']))
  with check (public.has_role(org_id, array['owner','teacher']));
