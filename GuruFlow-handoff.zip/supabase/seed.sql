-- GuruFlow · seed.sql — the single source of truth for demo data.
-- Fixed UUIDs so screenshots and tests stay stable across reseeds.
-- Run AFTER 0001_init.sql and 0002_rls.sql.
-- NOTE: demo users are created separately — see supabase/demo/attach_users.sql

begin;

-- ── institute ───────────────────────────────────────────────────────
insert into public.orgs (id, name, code, city, state, board, plan, student_cap)
values ('00000000-0000-4000-8000-000000000001', 'Sunrise Coaching Classes', 'SUNRISE-PAT', 'Patna', 'Bihar', 'CBSE', 'coaching', 300)
on conflict (code) do nothing;

-- ── batches ─────────────────────────────────────────────────────────
insert into public.batches (id, org_id, name, subject, days, start_time, end_time, monthly_fee, capacity)
values
  ('00000000-0000-4000-8000-000000000201', '00000000-0000-4000-8000-000000000001', 'Class 10-A', 'Mathematics', '{Mon,Wed,Fri}', '16:00', '17:30', 1500, 50),
  ('00000000-0000-4000-8000-000000000202', '00000000-0000-4000-8000-000000000001', 'Class 10-B', 'Physics',     '{Tue,Thu,Sat}', '15:00', '16:30', 1500, 45),
  ('00000000-0000-4000-8000-000000000203', '00000000-0000-4000-8000-000000000001', 'NEET Batch', 'Biology',    '{Mon,Tue,Wed,Thu,Fri}', '18:00', '20:00', 3000, 60)
on conflict do nothing;

-- ── students (12 in Class 10-A) ─────────────────────────────────────
insert into public.students (id, org_id, batch_id, full_name, roll_no, parent_phone, status) values
  ('00000000-0000-4000-8000-000000000101', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Aarav Sharma', '14', '+91 9876543201', 'active'),
  ('00000000-0000-4000-8000-000000000102', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Ishita Bose', '15', '+91 9876543202', 'active'),
  ('00000000-0000-4000-8000-000000000103', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Kabir Singh', '16', '+91 9876543203', 'active'),
  ('00000000-0000-4000-8000-000000000104', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Ananya Gupta', '17', '+91 9876543204', 'active'),
  ('00000000-0000-4000-8000-000000000105', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Ritesh Mehta', '18', '+91 9876543205', 'active'),
  ('00000000-0000-4000-8000-000000000106', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Zoya Ahmed', '19', '+91 9876543206', 'active'),
  ('00000000-0000-4000-8000-000000000107', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Kabeer Singh', '20', '+91 9876543207', 'active'),
  ('00000000-0000-4000-8000-000000000108', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Diya Patel', '21', '+91 9876543208', 'active'),
  ('00000000-0000-4000-8000-000000000109', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Manav Sethi', '22', '+91 9876543209', 'active'),
  ('00000000-0000-4000-8000-000000000110', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Priya Menon', '23', '+91 9876543210', 'active'),
  ('00000000-0000-4000-8000-000000000111', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Rohan Das', '24', '+91 9876543211', 'active'),
  ('00000000-0000-4000-8000-000000000112', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Sara Khan', '25', '+91 9876543212', 'active')
on conflict do nothing;

-- ── attendance: last 10 school days, 46 present / 1 late / 3 absent pattern
--    (the app shows 92% — keep the ratio when you edit this)
insert into public.attendance (org_id, batch_id, student_id, date, status)
select s.org_id, s.batch_id, s.id, d::date,
       case
         when s.roll_no = '16' and d::date = current_date - 1 then 'absent'::attendance_status_t
         when s.roll_no = '19' and d::date = current_date - 2 then 'absent'::attendance_status_t
         when s.roll_no = '21' and d::date = current_date - 3 then 'absent'::attendance_status_t
         when s.roll_no = '14' and d::date = current_date - 4 then 'late'::attendance_status_t
         else 'present'::attendance_status_t
       end
from public.students s
cross join generate_series(current_date - 9, current_date, interval '1 day') d
where s.batch_id = '00000000-0000-4000-8000-000000000201'
on conflict (student_id, date) do nothing;

-- ── exam + marks (Unit Test 3) ──────────────────────────────────────
insert into public.exams (id, org_id, batch_id, name, subject, exam_date, max_marks)
values ('00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000201', 'Unit Test 3', 'Mathematics', current_date - 2, 100)
on conflict do nothing;

insert into public.marks (org_id, exam_id, student_id, marks) values
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000101', 86),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000102', 74),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000103', 62),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000104', 88),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000105', 55),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000106', 79),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000107', 41),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000108', 93),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000301', '00000000-0000-4000-8000-000000000109', 71)
on conflict do nothing;

-- ── fees: three terms, first two paid ───────────────────────────────
insert into public.fee_payments (org_id, student_id, term, amount, method, receipt_no, status) values
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000101', 'Term 1', 4999, 'upi', 'SUNRISE/26-27/0011', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000101', 'Term 2', 4999, 'upi', 'SUNRISE/26-27/0012', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000102', 'Term 1', 4999, 'upi', 'SUNRISE/26-27/0021', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000102', 'Term 2', 4999, 'upi', 'SUNRISE/26-27/0022', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000103', 'Term 1', 4999, 'upi', 'SUNRISE/26-27/0031', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000103', 'Term 2', 4999, 'upi', 'SUNRISE/26-27/0032', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000104', 'Term 1', 4999, 'upi', 'SUNRISE/26-27/0041', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000104', 'Term 2', 4999, 'upi', 'SUNRISE/26-27/0042', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000105', 'Term 1', 4999, 'upi', 'SUNRISE/26-27/0051', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000105', 'Term 2', 4999, 'upi', 'SUNRISE/26-27/0052', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000106', 'Term 1', 4999, 'upi', 'SUNRISE/26-27/0061', 'confirmed'),
  ('00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000106', 'Term 2', 4999, 'upi', 'SUNRISE/26-27/0062', 'confirmed')
on conflict do nothing;

-- ── notices ─────────────────────────────────────────────────────────
insert into public.notices (org_id, title, body, audience, category) values
  ('00000000-0000-4000-8000-000000000001', 'Unit test schedule — November', 'Unit Test 3 will be held on 12 Nov (Wed). Syllabus: Ch 5, 6 and 7. Duration 90 minutes.', '{students,parents}', 'academic'),
  ('00000000-0000-4000-8000-000000000001', 'Annual Sports Day', 'Annual Sports Day will be held on 15 Nov. All parents are invited.', '{students,parents}', 'events'),
  ('00000000-0000-4000-8000-000000000001', 'New library books', 'Twenty new reference books have arrived in the library. Visit and explore.', '{students,parents}', 'general'),
  ('00000000-0000-4000-8000-000000000001', 'Fee reminder — Term 3', 'Term 3 fee of ₹4,999 is due on 20 Nov. Please pay at the office or via UPI.', '{students,parents}', 'general');

commit;
