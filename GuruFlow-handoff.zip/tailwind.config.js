/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './src/**/*.{ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        canvas: '#F5F6FA',
        surface: '#FFFFFF',
        ink: '#0B1220',
        secondary: '#5A6684',
        muted: '#94A0BC',
        hairline: '#E7EBF5',
        primary: '#101B4C',
        accent: '#FF7A1A',
        accentSoft: '#FFF1E6',
        teal: '#0D9488',
        tealSoft: '#E4F7F4',
        success: '#16A34A',
        warning: '#F59E0B',
        danger: '#DC2626',
        dangerSoft: '#FEECEC',
        track: '#EFF2F8',
      },
      borderRadius: { card: '20px', btn: '16px', field: '14px' },
    },
  },
  plugins: [],
};
