# Mandatory Engineering Workflow

This repository is the Smart Photography Assistant workspace. `mobile/` is
the real React Native + Expo application; `tooling/preview/` (served through
the repo-root npm scripts) is coding-environment preview tooling only.

## Before Every Change

1. Read the user-supplied source links and the relevant unit specification.
2. Read `mobile/docs/progress-tracker.md` and the files that the unit depends on.
3. Search before creating: reuse, then extend, then create.
4. Compare documentation and code. If they conflict, stop and report the
   conflict; documentation wins unless the user approves otherwise.
5. Determine data, auth, offline, error, accessibility, theme and navigation
   effects before editing.

## Implementation Rules

- Implement only the requested, verified scope. Do not infer a missing spec.
- Preserve completed work unless a documented conflict requires correction.
- `mobile/app` and `mobile/src` use React Native components only: no DOM tags,
  CSS, React DOM, Next.js, browser storage or unguarded browser APIs.
- Unauthenticated V1 users browse read-only. Favorites, camera, capture,
  gallery, statistics and personal settings require authentication.
- Photos and camera frames never leave the device. Supabase stores auth and
  metadata only, with RLS on every table.
- External credentials live only in `mobile/.env`; missing credentials switch
  only the dependent feature to its documented demo fallback.
- Use shared design tokens, strict TypeScript, accessible touch targets,
  reduced-motion support and explicit loading/error/empty states.

## Completion Rules

1. Re-read changed files against the unit checklist.
2. Run mobile platform-purity checks, mobile TypeScript checks and the project
   build whenever the available tools permit.
3. Update `mobile/docs/progress-tracker.md` without deleting history.
4. State exactly what was verified and what remains unverified. Never report a
   preview build as proof that the Expo application builds.
