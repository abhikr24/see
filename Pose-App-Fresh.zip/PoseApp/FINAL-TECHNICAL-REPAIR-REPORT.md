# Final Technical Repair Report

## New failure analyzed

The supplied EAS log shows the build reached Android project configuration successfully and then failed at exactly:

` :vision-camera-mlkit-pose:bundleReleaseLocalLintAar `

with:

`Cannot query the value of this property because it has no value available.`

This is **not** a JavaScript/Metro error, not an ML Kit model-download error, and not the earlier namespace/autolinking error. The failing task belongs specifically to the private local Android library `vision-camera-mlkit-pose`.

## Root-cause repair

The module is an app-local React Native/Nitro implementation. It is consumed directly by the application and is not published as an AAR for another application to consume.

Android Gradle Plugin nevertheless creates `bundleReleaseLocalLintAar` for Android library modules. In the reported EAS environment that task fails while resolving its internal lint Provider before application compilation begins.

The native module's `android/build.gradle` now disables **only** `bundleReleaseLocalLintAar`:

```gradle
tasks.configureEach { task ->
  if (task.name == "bundleReleaseLocalLintAar") {
    task.enabled = false
  }
}
```

This does not remove ML Kit, VisionCamera, Nitro/Nitrogen, CMake, Kotlin, or the native detector. It only skips the unused AAR lint-metadata packaging task for this private local module.

## Preserved functionality

- Real Google ML Kit accurate pose detector remains present.
- `PoseDetection.getClient(...)` remains the native inference path.
- Accurate pose dependency remains `com.google.mlkit:pose-detection-accurate:18.0.0-beta5`.
- VisionCamera frame pipeline remains intact.
- Nitro/Nitrogen generated glue remains intact.
- Hardware shutter module remains intact.
- Shared application code remains intact.
- Original ZIP contents were retained; the repair overlays the targeted Gradle fix and verification/report files.

## Validation performed here

- Reopened the previously supplied final ZIP.
- Located the exact failing native Gradle module.
- Confirmed the failing task name matches the EAS log exactly.
- Applied the targeted task-level repair.
- Verified the repair script detects the task disablement.
- Rechecked native namespace, ML Kit accurate pose dependency, and Nitrogen autolinking.
- Repacked the complete project without intentionally removing original files.

## Important status

This repair directly addresses the exact failure shown in the user's EAS log. A successful EAS APK is still not claimed until EAS actually runs the build and produces the APK artifact.

## 2026-09-21 — Release-build blocker fix (bundleReleaseLocalLintAar)

The EAS release log showed the failure:
`Could not determine the dependencies of task ':vision-camera-mlkit-pose:bundleReleaseLocalLintAar'. Cannot query the value of this property because it has no value available.`

Root cause identified: the private app-local Nitro Android library was carrying a non-standard AAR publishing configuration (`prefabPublishing true`) and relied only on a task-local disable. The EAS/CNG-generated Android project uses AGP 9.3.1, and the late-created AGP LocalLintAar task still entered the release task graph.

Repairs applied without removing pose/ML Kit/VisionCamera functionality:
- Added `mobile/plugins/withAndroidReleaseBuildFixes.js` and registered it in `mobile/app.json`; it applies a `gradle.projectsEvaluated` guard to the regenerated project so only `vision-camera-mlkit-pose` `bundle*LocalLintAar` intermediate tasks are disabled.
- Removed `prefabPublishing true` from the private native module; retained Prefab itself.
- Added the standard Nitro `fix-prefab.gradle` wiring so native libraries are built before prefab metadata is prepared.
- Aligned the Nitro Android library Gradle structure with the current Nitro template (Kotlin plugin, conditional RN plugin, build-config field, prefab packaging exclusions).
- Aligned the module fallback NDK version to the actual Expo SDK 57 EAS log (`27.1.12297006`).
- Restored the checked-in Gradle wrapper to the same 9.3.1 version shown by the EAS SDK 57 generated project.
- Preserved the real ML Kit accurate pose detector, VisionCamera frame path, Nitro/Nitrogen glue, hardware shutter, assets, shared code, and all prior files.

Static verification after the repair confirms the fix is present in both the source native module and the CNG config-plugin path.

---

# V4 SUPERSEDING CORRECTION — based on the actual V3 EAS log

The sections above are historical V3 repair notes and are **superseded by this V4 correction**.

The complete V3 EAS log showed that the previous task-disable workaround was itself the cause of the final failure. In V3 the native pose module reached release native compilation successfully, then `:vision-camera-mlkit-pose:bundleReleaseLocalLintAar` was `SKIPPED`, and the build later failed at `:app:lintVitalAnalyzeRelease` because AGP attempted to transform the missing `local_aar_for_lint/release/out.aar`.

V4 therefore:

- removes the task-disabling workaround;
- changes the local VisionCamera dependency from `api` to `implementation` so the app-local module does not expose VisionCamera through its AAR API surface;
- keeps the real ML Kit + VisionCamera + Nitro/Nitrogen native pose implementation unchanged;
- configures the application release APK build with `lint { checkReleaseBuilds = false }`, keeping explicit/debug lint available while preventing the known broken intermediate local-lint-AAR artifact from being a required release APK input;
- adds an explicit `release-apk` EAS profile;
- updates the static release gates to reject the old workaround and verify the V4 configuration.

V4 static checks pass after re-extracting the final archive. A live EAS build is still the required proof of APK creation.
