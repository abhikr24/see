# PART 1 — FORENSIC AUDIT + FOUNDATION REPAIR REPORT

**Input:** `android-build-failure-forensics (1).zip` (restored into this workspace in full from
`https://github.com/abhikr24/Smart-camera-app-/blob/main/android-build-failure-forensics%20(1).zip`
via the raw-file URL + PAT; SHA-of-download verified as a valid ZIP, `unzip -t` clean, 1,530 files
extracted excluding `node_modules`/`.git`/the archive itself).
**Scope:** project-foundation/configuration only. VisionCamera, ML Kit pose detection (Nitro module
`mobile/native/vision-camera-mlkit-pose`), native pose processing, Supabase and all shared application
logic are **untouched** — verified intact by the passing checks below.

---

## 1. CONFIRMED PROBLEMS

| # | Defect | Evidence | Build impact |
|---|--------|----------|--------------|
| **D1** | `mobile/assets/icon/app-icon-store.png` **missing** — only `.gitkeep` present | `find mobile/assets -type f` → 5 `.gitkeep` files, zero PNGs | Referenced by `app.json` at `expo.icon`, `expo.android.adaptiveIcon.foregroundImage`, `expo.web.favicon` → `expo prebuild` / EAS fail with ENOENT. This is the recurring PATCH-04 defect back in this archive. |
| **D2** | `mobile/assets/splash/splash-icon.png` **missing** | same as above | Referenced by the `expo-splash-screen` plugin (`image`) → prebuild-blocking. |
| **D3** | Repo-root `.gitignore` **missing entirely** | `cat .gitignore` → MISSING; root `.easignore` even cross-references "`.gitignore` lines 53–54", proving the file was lost from this archive | Without it: git-mode EAS uploads can accidentally receive committed junk; `node_modules`, `.expo/`, CNG native dirs and build outputs have no root-level git protection. Defense-in-depth layer gone. |
| **D4** | `mobile/.easignore` **missing** | not present in archive | In the canonical git-anchored flow the root `.easignore` governs, so this is latent — but in the degraded flow (`eas build` from inside `mobile/` without `.git`) the upload root collapses to `mobile/` and then there was no ignore file at all for that mode. |
| **D5** | EAS upload context leaked inert root files | Faithful replay of eas-cli@v24.7.0 copy logic (see §5) showed root `package.json`, `package-lock.json`, `tsconfig.json`, `scripts/` would be uploaded | No workspaces are declared at root, so a stray root manifest on the builder can only confuse monorepo/project detection; never helps. Hygiene defect, not fatal. |
| **D6 (investigated — NOT a defect, structure kept)** | Production imports reach `../shared` from `mobile/` (143 × `@shared/index` imports) | Import census: `143 '@shared/index'` via tsconfig path `@shared/*` → `../shared/*` | SAFE — see §4. Verified from eas-cli source that the EAS upload is anchored at the **git repository root**, so `shared/` (85 TS files) reaches the builder. No restructure was needed; moving `shared/` into `mobile/` would have broken the web mirror and root test suite for zero gain. |

## 2. EXACT FIXES APPLIED

| Fix | File(s) | Detail |
|-----|---------|--------|
| **F1** recreate store icon | `mobile/assets/icon/app-icon-store.png` | Regenerated on-brand (pose-guidance skeleton mark in viewfinder brackets, brand `#2563EB` on white). Resized to the contractual **1024×1024 RGB PNG, 444,413 B**, sha256 `1b8df0ef…a6267fecd`. Verified header, corner pixel ≈ white (blends with adaptiveIcon `backgroundColor #FFFFFF`). |
| **F2** recreate splash logo | `mobile/assets/splash/splash-icon.png` | Same mark, **1600×1200 RGB PNG, 154,992 B**, sha256 `2e0d61df…38e4`. Satisfies the plugin contract (`imageWidth: 200`, `resizeMode: contain`, white background); center pixel sample confirms the mark is centered. |
| **F3** restore root ignore rules | `+ .gitignore` (new) | Mirrors `.easignore` semantics: `node_modules`, `.expo/`, `dist*`, `*.hbc`, logs, env secrets, `mobile/android/` + `mobile/ios/` (CNG — never committed), tsbuildinfo. Intentionally committed paths (`shared/`, `tooling/`, `tests/`, `_staging/`, `gistfile*.txt`, zips) are **not** ignored. |
| **F4** add degraded-mode guard | `+ mobile/.easignore` (new) | Documents precedence (root `.easignore` wins in git mode) and protects the no-git/run-from-`mobile/` mode: excludes `node_modules`, `.expo/`, `dist*`, `*.hbc`, `/android`, `/ios`, env files, native leftovers. |
| **F5** tighten EAS upload | `~ .easignore` (append) | Added `/package.json`, `/package-lock.json`, `/tsconfig.json`, `/scripts`, top-level docs → EAS now sees exactly ONE manifest/lockfile pair on the builder: `mobile/`'s. |

## 3. FILES CHANGED (complete list)

1. `+ mobile/assets/icon/app-icon-store.png` (recreated, 1024×1024 RGB)
2. `+ mobile/assets/splash/splash-icon.png` (recreated, 1600×1200 RGB)
3. `+ .gitignore` (restored)
4. `+ mobile/.easignore` (new)
5. `~ .easignore` (root-only tooling exclusions appended)

**No application code, native code, dependency pins, plugin code, or config values were modified.** `app.json`,
`eas.json`, both `package.json` files, both lockfiles, `.gitattributes`, `metro.config.js`, `babel.config.js`,
tsconfigs and every script are byte-identical to the restored archive.

## 4. THE `shared/` QUESTION — VERIFIED, NOT GUESSED

**Can the EAS build context receive `../shared`? YES (in the canonical flow).** Proof chain:

- Import census: production code reaches the repo-root brain via the tsconfig alias `@shared/*` →
  `../shared/*` — **143 `@shared/index` imports** in `mobile/app` + `mobile/src`. Metro resolves them via
  `metro.config.js` (`watchFolders: [<root>/shared]`, `nodeModulesPaths` pinned to `mobile/node_modules`).
- eas-cli **v24.7.0 shipped source**, `vcs/clients/git.js#getRootPathAsync()` →
  `git rev-parse --show-toplevel` — the upload is anchored at the **git repository root**, not `mobile/`.
  The root `.easignore` is the only ignore file consulted in this mode.
- Non-git `EAS_NO_VCS` mode (`vcs/clients/noVcs.js`) anchors at `EAS_PROJECT_ROOT`, else git toplevel,
  else cwd — i.e. still repo-root whenever a `.git` exists.
- **Faithful local replay** of eas-cli's copy pipeline (real `ignore` package from eas-cli's own
  dependency tree, same default rules `.git`/`node_modules`, root `.easignore` applied) on the repaired
  tree: **401 files uploaded** — `shared/` (all 85 TS files), `mobile/app`, `mobile/src`, the Nitro module,
  plugins, both restored assets, all configs and the lockfile are present; `_staging`, `gistfile*.txt`,
  `tooling`, `tests`, root preview scaffold, root manifest/lockfile/tsconfig/scripts, `mobile/android`,
  `mobile/dist`, and all `node_modules` are absent.

**Consequence / requirement (documented, intentionally not "fixed" structurally):** builds must run
from a git checkout of the repository (the normal `eas build` / GitHub-integration flow). An unpacked
ZIP of only `mobile/` with `EAS_NO_VCS=1` is structurally incapable of shipping `../shared` — that is a
usage mode to avoid (set `EAS_PROJECT_ROOT=<repo-root>` if it is ever forced), not a defect to patch.

## 5. AUDITED CLEAN — NO CHANGE REQUIRED

- `mobile/app.json` — `expo doctor` 21/21 (schema + all plugin configs); `expo config --type public`
  resolves with zero warnings; SDK 57.0.0; every asset reference now resolves to a physical file;
  no obsolete top-level `splash` block; local plugin `./plugins/withHardwareShutter` exists and ran
  during prebuild.
- `mobile/eas.json` — valid; `development`/`preview` produce APKs, `production` an AAB with
  `autoIncrement`; `cli >= 12.0.0`, remote app version source. Nothing EAS-hostile.
- `mobile/package.json` — 46 pinned deps; **no install/postinstall/prepare/eas-build hooks** that could
  fail in a clean builder; local Nitro module linked via `file:native/vision-camera-mlkit-pose`.
- `mobile/package-lock.json` — lockfileVersion 3, name/version match; **`npm ci` succeeded = perfect
  package-lock consistency** (npm ci refuses to run on drift).
- Root `package.json` / `package-lock.json` — **npm ci succeeded**; preview tooling intact.
- `.gitattributes` — intact; binary/LF protections correct for gradlew/jar/keystore hygiene.
- `metro.config.js` / `babel.config.js` — production-critical resolutions (`@mediapipe/tasks-vision`
  stub, `ws` empty-on-native) verified live: export of the 2,562-module production graph passed.
- Expo plugins — all 10 resolve and execute (full `expo prebuild --clean` completed).
- Existing verification scripts — `verify-all` (deps + purity + architecture + typecheck) all pass.

## 6. COMMANDS / TESTS RUN (all after repair, on this exact tree)

| Command | Result |
|---|---|
| `unzip -t project.zip` | No errors detected |
| root `npm ci` | PASS (clean install, lockfile consistent) |
| `mobile/ npm ci` | PASS (clean install, lockfile consistent) |
| `mobile/ npx expo config --type public` | PASS — SDK 57.0.0, all refs resolve, 0 warnings |
| `mobile/ npx expo-doctor@latest` | **21/21 checks passed** |
| root `npm run verify` (= verify-all) | **PASS** — dependency integrity (28/28 bare imports declared) · platform purity · reference-architecture · `tsc --noEmit` 0 errors |
| `mobile/ npm run verify:purity` | **PASS** |
| root `npm test` | **562 pass / 0 fail** |
| root `npm run build` (preview tooling) | PASS — single-file bundle built |
| `mobile/ npx expo export --platform android` | **PASS** — 6.3 MB Hermes bundle, 2,562 modules |
| `mobile/ npx expo prebuild --platform android --clean --no-install` | **PASS** — `mipmap-*/ic_launcher*.webp` generated from restored icon; `drawable-*/splashscreen_logo.png` generated from restored splash; `android.permission.CAMERA` in merged manifest |
| eas-cli upload replay (`ignore`-package faithful) | `shared/` + assets + native module present; 0 leaks of tooling/staging/noise |
| PNG forensics (`node` header read + ImageMagick pixel sample) | icon 1024×1024 RGB ✓ · splash 1600×1200 RGB ✓ · white backgrounds ✓ |

Generated `mobile/android/`, `mobile/dist/`, root `dist/` were removed after validation (CNG/output dirs
are not source).

## 7. UNRESOLVED ISSUES

- **None blocking for Part 2.** Native APK/EAS execution requires Expo credentials and (for Gradle-fallback)
  a JDK + Android SDK — deliberately out of Part 1 scope.
- Carried forward from the restored history: on-device pose-landmark verification on a physical Android
  (camera opens ≠ pose works) remains the documented Part-2+ owner action.
- `npm audit` reports advisory notices in both workspaces (registry metadata only; none affect the build
  inputs verified above).

---

PART 1 COMPLETE — FOUNDATION REPAIRED
