# PoseAssist V6 — Easy APK Build Guide

## 1. Extract
Right-click the ZIP → **Extract All**.

Inside the extracted folder you must see:

```text
mobile
shared
```

If `shared` is missing, stop.

---

## 2. Create `.env`
Open the `mobile` folder.

Open PowerShell in this folder and copy-paste:

```powershell
Copy-Item .env.example .env
```

Open `.env`:

```powershell
notepad .env
```

Paste your existing 3 values:

```text
EXPO_PUBLIC_SUPABASE_URL=YOUR_EXISTING_VALUE
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_EXISTING_VALUE
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=YOUR_EXISTING_VALUE
```

Save → close Notepad.

---

## 3. Install packages locally
Still inside `mobile`:

```powershell
npm ci
```

Wait until it finishes.

---

## 4. Set up Git
Move to the folder containing **both** `mobile` and `shared`:

```powershell
cd ..
```

Run:

```powershell
git init
```

Then:

```powershell
git add .
git commit -m "PoseAssist V6 build"
```

Go back to `mobile`:

```powershell
cd mobile
```

Do **not** run `eas build:configure` — `eas.json` is already included.

---

## 5. Build the real phone APK
Copy-paste this exact command:

```powershell
eas build --platform android --profile release-apk
```

### During the build
- Let it run.
- You may minimize PowerShell.
- Do not close it until EAS says the build has been submitted/running on EAS.
- Then you can check the build in the browser.

---

## 6. When the build succeeds
Open the APK link on your Android phone.

Install it.

Then test:

```text
☐ Login
☐ Google sign-in
☐ Explore
☐ Open pose
☐ Reference image
☐ Favorite / unfavorite
☐ Camera opens
☐ Live pose detection works
☐ Hardware shutter works
☐ Delete Account
```

### Important
Do **not** judge live native pose detection using Expo Go. Test that feature in the installed APK.

### If the build fails
Do not change files first.
Copy the entire **Run gradlew** error and send it exactly as EAS shows it.
