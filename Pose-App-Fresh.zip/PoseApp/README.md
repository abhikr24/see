# Smart Photography Assistant — Workspace

AI pose-guidance camera app. **React Native + Expo SDK 57 + TypeScript
strict** — Android, iOS and Web from one codebase.

## Repository layout (read this first)

```
mobile/   ← THE APP. This is the product. React Native + Expo SDK 57 +
            Expo Router + Metro ONLY. Production web target = Expo Web
            (react-native-web via Metro, `expo export --platform web`).
            Run it: cd mobile && npm install && npx expo start
shared/   ← THE BRAIN. Platform-neutral TypeScript (design tokens, types,
            constants, pose catalog, ML math) consumed by the app.
            No RN, no DOM — pure TS with zero bare imports.
tooling/
  preview/← PREVIEW-ONLY coding-environment tooling. A small Vite +
            React-DOM page that mirrors app progress in a browser so you
            can watch builds while working here. ⚠ NOT THE APP. NOT
            production. Never bundled: Metro watches mobile/ + shared/ only.
            Fully documented in tooling/preview/README.md and independently
            removable — production works identically without it.
docs/     ← (none at root) — project docs live in mobile/docs/
```

If you are here to run or ship the app: **`mobile/` is the only folder that
matters.** Everything else is workspace tooling around it.

The repo-root `package.json` exists only because this coding environment
runs `npm run build` at the repository root and serves `dist/index.html`;
it hosts the preview tooling's scripts and preview-only dependencies. It
contains zero production code, and production must never resolve packages
from it (enforced: `metro.config.js` resolver paths + hardened
`mobile/scripts/verify-deps.mjs`).

## The app, in one paragraph

Pick a reference pose from a curated library (400 poses, 12 categories).
MediaPipe tracks your body on-device (33 landmarks) and guides you into the
pose with a live silhouette-contour overlay, match %, voice + visual
guidance. Capture manually, by gesture, or automatically at high match.
Photos stay on your device — always.

## Golden rules (enforced by machine checks)

1. `mobile/` and `shared/` contain zero HTML tags, zero CSS files, zero
   react-dom/Next.js/react-router imports, zero unguarded browser APIs.
   Browser APIs are allowed inside `tooling/preview/` ONLY.
2. Design tokens only — `shared/theme/` is the single source of truth for
   color/spacing/radius/type across every platform.
3. Photos live on-device only; the backend receives metadata, never images.
4. MediaPipe runs on-device only; no camera frame ever leaves the phone.
5. Unauthenticated users browse read-only; camera/favorites/stats need auth.

## Setup

| What | Where | Time |
|---|---|---|
| Run the app | `mobile/README.md` | 3 commands |
| Connect real backend (Supabase) | `mobile/ENV-SETUP.md` | 2 minutes, paste 2 values |
| Preview tooling details | `tooling/preview/README.md` | read-only |

## Commands

```bash
# Production (the app)
cd mobile && npm install && npx expo start        # dev server (native + web)
cd mobile && npm run typecheck                    # strict TS
cd mobile && node scripts/verify-all.mjs          # deps + purity + typecheck
cd mobile && CI=1 npx expo export --platform web  # production web build
eas build -p android                              # native builds via EAS

# Coding-environment preview tooling (NOT the app)
npm run build    # builds tooling/preview → dist/index.html (gitignored)
npm run dev      # local dev server of the preview mirror
```

## Verification & progress

27 implementation units plus a Phase-1 remediation (Expo SDK 52→57 migration,
preview-tooling isolation, dependency-boundary hardening), tracked in
`mobile/docs/progress-tracker.md`. The canonical pre-handoff gate is
`node mobile/scripts/verify-all.mjs` — never report a preview build as proof
that the Expo application builds.
