# PoseAssist V10 — Senior Engineering Audit

## Decisive failure from the V9 attempt

The EAS command did not reach an Android cloud build. It stopped on the user's Windows machine before upload/build because the EAS CLI could not resolve Expo's API hostname:

```text
request to https://api.expo.dev/graphql failed, reason: getaddrinfo ENOTFOUND api.expo.dev
Error: GraphQL request failed.
```

`ENOTFOUND` here is a DNS/name-resolution failure. There is no Gradle, Android, ML Kit, React Native, or APK-build failure in this run.

Expo's EAS CLI must communicate with Expo's service to start/manage a cloud build, so this cannot be repaired purely inside application source code.

## Additional configuration issue observed in the same output

The CLI reported:

```text
No environment variables with visibility "Plain text" and "Sensitive" found for the "preview" environment on EAS.
```

The local `.env` file was excluded from the EAS upload. That is correct for privacy, but it means the three `EXPO_PUBLIC_*` application configuration values also need to exist in the EAS `preview` environment for the cloud build/runtime bundle.

## V10 changes

1. Added `expo.extra.eas.projectId` with the already-linked project ID shown by the user's successful EAS project lookup.
2. Added `expo.owner` for explicit account/project metadata.
3. Set `release-apk.environment` explicitly to `preview`.
4. Added `npm run eas:preflight` to check DNS and HTTPS reachability of `api.expo.dev` before an EAS build is attempted.
5. Added `npm run eas:sync-public-env` to copy the three existing local `EXPO_PUBLIC_*` values into the EAS `preview` environment. The values are client-side/public configuration, not a service-role credential.
6. Replaced the V9 build guide with a short, deterministic sequence: extract → `.env` → install → Git → network preflight → EAS public env sync → APK build.

## Preserved

No existing V9 archive entry was removed. The native pose implementation, ML Kit, VisionCamera, Nitro/Nitrogen, Skia, hardware shutter, app routes, shared code, assets, and previous build fixes remain unchanged except for the explicit configuration additions needed above.

## Verification performed

- V9 archive extracted.
- V10 modified in place from that extraction.
- All V9 paths compared against V10: no V9 path was removed.
- `app.json`, `eas.json`, and `package.json` parse successfully.
- New Node scripts syntax-check successfully.
- V10 build profile still requests an Android APK.
- V10 still preserves the `release-apk` Gradle/architecture/runtime build fixes from V9.

## Important limitation

A ZIP cannot repair a computer/router/DNS problem that prevents `api.expo.dev` from resolving. The preflight is intentionally included so the user can identify this before consuming another build attempt.
