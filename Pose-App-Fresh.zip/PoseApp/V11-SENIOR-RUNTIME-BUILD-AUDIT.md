# PoseAssist V11 — Senior Runtime + Build Audit

Date: 2026-09-23
Base: `smart-camera-FINAL-TECHNICAL-COMPLETE-V10.zip`

## Executive result

V10 had two separate classes of risk:

1. **Build/environment failures** already fixed in earlier versions (Gradle lint-AAR failure, Prefab transform concurrency, four-ABI APK size, EAS DNS preflight).
2. **Cold-start runtime risk** that could leave the app visually stuck on the branded startup logo or crash before the first screen rendered.

V11 is a targeted hardening release for the second class while preserving the V10 Android/EAS build fixes.

## What the V10 archive actually contained

The original V10 project used `react-native-mmkv` 3.x (`package.json` range `^3.1.0`, lockfile resolved `3.3.3`) and created the MMKV native instance at module import time. The original theme store also used Zustand `persist` with the MMKV adapter, and several first-run UI files imported the very large `@shared/index` barrel.

That barrel exports the pose catalog, reference/ML modules, coaching, voice, camera logic, and other application domains. This meant the Welcome/Onboarding/Permissions route could pull a much larger JavaScript graph than the first screen actually needed.

The original V10 `storage.ts` also had a top-level runtime import of `react-native-mmkv` and created `new MMKV(...)` during module initialization.

These are concrete code-level cold-start hazards. They do not prove the device crash was caused by one single line, but they are precisely the kind of native/storage/graph work that can produce startup stalls or native initialization failures.

## V11 repairs

### 1. MMKV migration + lazy native initialization

- `react-native-mmkv` is pinned to **4.3.2**.
- MMKV V4 uses Nitro and the official API is `createMMKV(...)`; `remove(...)` replaces `delete(...)`.
- The native module is now loaded only when storage is first used.
- Expo Go/web use the in-memory adapter.
- The native MMKV instance uses `recoveryStrategy: 'recover-on-error'`.
- Existing synchronous storage callers keep the same `StorageAdapter` facade, so feature code did not need a broad rewrite.

The official MMKV V4 migration guide confirms the Nitro rewrite, the `createMMKV()` API, and the `remove()` API. urlMMKV V4 upgrade guidehttps://github.com/mrousavy/react-native-mmkv/blob/main/docs/V4_UPGRADE_GUIDE.md

### 2. Theme persistence no longer initializes native storage during cold boot

- Removed Zustand `persist(...)` from the theme store.
- The first render starts with `system` mode.
- Theme persistence/hydration is deferred to the main tab shell.
- Theme writes still persist through the same storage facade.

### 3. First-run UI no longer imports the large shared barrel

The following boot/onboarding components were changed to import only the exact modules they need:

- theme tokens
- onboarding copy
- app constants
- type definitions

They no longer import `@shared/index`.

This is important because `shared/index.ts` exports large feature/data domains including the pose catalog and ML/reference/coaching/voice modules.

### 4. Reanimated removed from the initial button/indicator path

- First-run `AppButton` uses React Native `Animated.spring`.
- Onboarding `PageIndicator` uses React Native `Animated.timing`.
- Reanimated remains available for the camera and later feature screens; it was not removed from the app.

This reduces native animation initialization pressure during the first launch.

### 5. Permission flow remains real but starts lighter

- Android camera permission uses `PermissionsAndroid`.
- Media Library is dynamically imported.
- Camera and gallery permission probes are sequenced instead of initialized simultaneously.
- Expo Go is handled as an unsupported native host rather than being allowed to throw.
- Permission failures are converted to UI state instead of unhandled promise failures.

### 6. Root/auth initialization remains deferred

- Root layout does not statically import or initialize the auth store.
- The tab shell initializes auth after the main app route is available.
- The direct `/auth` route initializes auth locally for deep-link/direct-entry cases.
- Offline/snackbar overlays remain lazy and are delayed further after boot.

### 7. Release build environment is explicit

The existing V10 build repairs were preserved:

- arm64-only phone APK
- compressed native libraries
- Gradle serialization (`parallel=false`, workers=1)
- EAS cache disabled for release APK
- native release-lint workaround from V4 preserved
- explicit `release-apk` profile
- SDK 57 image
- `NODE_ENV=production`

## Cold-start graph verification

A static graph audit was added and run against four entry points:

- root index
- Welcome
- Onboarding
- Permissions

V11 result:

- root: 5 project modules, no heavy native graph
- Welcome: 11 project modules, no heavy native graph
- Onboarding: 16 project modules, no heavy native graph
- Permissions: 19 project modules, no heavy native graph

The graph gate rejects static reachability of MMKV, Reanimated, VisionCamera, Skia, Supabase, the pose catalog, the shared barrel, or the native pose runtime from those initial routes. Dynamic imports used intentionally at runtime are not treated as static cold-start dependencies.

## Archive integrity

Compared with the extracted V10 archive:

- V10 files: 1,788
- V11 files: 1,792
- V10 files missing from V11: **0**
- New files: 4
- Existing files intentionally changed: 27

No V10 file was deleted.

## Validation performed

`npm run verify:release` passed all of these:

- platform purity
- MMKV V4 runtime safety
- cold-start graph gate
- reference architecture
- dependency completeness
- release static readiness
- V8 boot gate
- V9 runtime release gate

## Important proof boundary

This report does **not** claim that a physical Android phone was tested inside this environment. The final proof still requires one real EAS build and one real-device launch.

The goal of V11 is to remove the concrete cold-start hazards found in the V10 source and preserve the native Android build fixes that already produced an APK.
