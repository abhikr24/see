# V12 Changes

1. Native ML Kit pose library load failure can no longer crash the whole Android process during package initialization; pose degrades to unavailable.
2. Root cold boot no longer initializes Google fonts.
3. Boot-state FileSystem is dynamically imported.
4. Native splash is no longer globally locked by `preventAutoHideAsync()`.
5. Added earliest JS startup error capture.
6. Updated the final installable verifier for the BootGate architecture and included it in the release verification chain.
