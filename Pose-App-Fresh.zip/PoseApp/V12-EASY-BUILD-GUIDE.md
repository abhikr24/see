# PoseAssist V12 — Easy APK Build

1. Extract the ZIP.
2. Open PowerShell in `mobile`.
3. Create `.env` from `.env.example` and put in the same 3 public values used in V11.
4. Run:

```powershell
npm ci
```

5. Approve Skia if npm asks:

```powershell
npm approve-scripts @shopify/react-native-skia
```

6. Verify:

```powershell
npm run verify:release
```

7. Check EAS connection:

```powershell
npm run eas:preflight
```

8. Sync the public variables:

```powershell
npm run eas:sync-public-env
```

9. Build the APK:

```powershell
eas build --platform android --profile release-apk --non-interactive
```

Install the resulting APK on the phone and open PoseAssist from the Android home screen.

V12 specifically hardens cold start and native pose-library failure handling. Full physical-device proof is still required after this build.
