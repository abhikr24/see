# PoseAssist V12 — Physical-Device Root-Cause Fix

## Evidence used

This repair is based on the real Android/React Native log captured from the installed APK on a physical phone:

- `E/ReactNativeJS: TypeError: undefined is not a function`
- component location: `RootLayout`
- native crash: `com.facebook.react.common.JavascriptException: TypeError: undefined is not a function`
- repeated immediately during app startup

## Root cause

`mobile/app/_layout.tsx` called `useColorScheme()` from inside `RootLayout`, but V12 imported `useColorScheme` from the `react` package.

`useColorScheme` is a React Native hook and must be imported from `react-native`.

Therefore the bundled value was `undefined`, and this line in `RootLayout`:

```ts
const scheme = useColorScheme();
```

executed as a call to `undefined`, producing exactly the observed runtime error:

```text
TypeError: undefined is not a function
```

## Fix applied

Changed only the root layout import boundary:

- removed `useColorScheme` from the `react` import
- added `useColorScheme` to the `react-native` import

No camera, pose engine, ML Kit, Supabase, authentication, navigation, or feature behavior was changed.

## Validation performed

After the fix, the V12 static release gates were rerun successfully:

- purity gate
- MMKV V4 runtime safety gate
- cold-start graph gate
- reference architecture gate
- dependency completeness gate
- release readiness gate
- V8 boot gate
- V9 runtime release gate
- final installable APK gate

A full new EAS/Gradle build and second physical-device run could not be performed in this environment, so the source fix is validated statically but the final proof still requires a new APK build and one launch on the same phone.
