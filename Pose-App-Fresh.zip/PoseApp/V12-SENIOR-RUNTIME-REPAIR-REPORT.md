# PoseAssist V12 — Senior Runtime Repair Report

Base: `smart-camera-FINAL-TECHNICAL-COMPLETE-V11.zip`
Status: **SOURCE-LEVEL REPAIR + STATIC VALIDATION**

## User-reported failure

The release APK installs successfully, then startup can show the PoseAssist/blue camera splash, followed by `Something went wrong` and/or Android reporting that the app is not responding.

## Concrete V11 risks found

### 1. Native pose package was allowed to crash the whole process
`VisionCameraMlkitPosePackage` executed `System.loadLibrary("VisionCameraMlkitPose")` from a companion-object initializer. The generated Nitrogen loader rethrows a native-load error. This meant one optional pose-feature native failure could abort the Android process during React Native package initialization, before the user reached the first screen.

**V12 fix:** catch the native-load failure at the package boundary and continue startup. The pose feature can then report itself unavailable through the existing guarded JS loader instead of taking down the application.

### 2. V11 root layout still initialized font registration during cold boot
The root layout imported `@expo-google-fonts/inter` and called `useFonts()` on every cold start, even though the first boot screen does not require font registration to choose the route.

**V12 fix:** remove font initialization from the root layout. Fonts are warmed asynchronously after the lightweight boot gate renders, and startup does not wait for them.

### 3. V11 cold-start boot state still statically imported Expo FileSystem
The cold-start boot-state module imported `expo-file-system/legacy` at module load. The actual read was asynchronous, but the native module was still part of the initial evaluation graph.

**V12 fix:** dynamically import Expo FileSystem only when the boot-state read/write actually runs.

### 4. V11 could hold the native splash indefinitely after a pre-React/startup failure
The root layout called `SplashScreen.preventAutoHideAsync()` at module load. If startup failed before `BootGateScreen` could render, the native splash could remain the visible surface while the underlying React process was unhealthy.

**V12 fix:** remove the global splash lock. The boot gate still calls `hideAsync()` defensively after its first React render, but native startup is no longer dependent on a JS promise calling `preventAutoHideAsync()`.

### 5. V11 had an early-error blind spot
The global JS error handler was dynamically installed from a root effect, after root module evaluation and rendering had already started.

**V12 fix:** add a dependency-free earliest JS error capture module before the root layout imports. It preserves the previous React Native handler and records the last error in `globalThis.__POSEASSIST_EARLY_ERROR__`. This is diagnostic hardening, not a substitute for native ANR traces.

### 6. V11's final installable verifier was stale
The verifier still expected the old SplashScreen direct root route even though V11 intentionally uses `BootGateScreen`.

**V12 fix:** verifier now checks for the actual BootGate architecture and is included in `verify:release`.

## What was deliberately NOT changed

- VisionCamera remains the real camera stack.
- Native ML Kit accurate pose detection remains the real pose engine.
- Nitro/Nitrogen remains in place.
- MMKV V4 remains available and lazily initialized by the app storage facade.
- The  arm64-only release APK policy remains unchanged.
- The existing Expo/EAS/Gradle repairs remain unchanged.
- No JS/synthetic pose fallback was introduced.

## Validation boundary

Static Node-based project gates were rerun in this environment. A complete dependency install and real Android/EAS build were not completed here because dependency installation timed out in the available execution window. Therefore this report does **not** claim physical-device or APK runtime verification.

The V12 changes specifically target concrete startup failure surfaces found by source inspection, especially the custom native pose package's process-level failure behavior.
