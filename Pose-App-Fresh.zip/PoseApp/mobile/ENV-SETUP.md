# Environment Setup & Supabase Swap Guide

`.env` is the single source of truth for public client configuration, but a
real production launch also requires a one-time Supabase schema run and store
build/signing configuration. No source-code edits are needed after those steps.

## Quick Start (Demo Mode — works immediately)

```bash
# From the repository root:
npm install
cd mobile
npx expo start
```

- Scan the QR code with **Expo Go** (Android) or the Camera app (iOS).
- Press `w` to open the **web** version in your browser.

Development Demo Mode gives you demo auth and local-only favorites. It is
enabled only while `__DEV__` is true. A production binary with missing
credentials fails closed; it never shows mock accounts or mock cloud data.

The bundled pose catalog works offline, but currently contains branded
illustrations rather than licensed reference photographs. Native real-time
MediaPipe also remains a release blocker; see `RELEASE-READINESS.md`.

> Expo Go note: the app detects Expo Go and falls back to in-memory cache
> for local storage. Nothing breaks; persistence activates automatically in
> a dev/production build (`npx expo run:android` / `run:ios` or EAS Build),
> which is where MMKV (native) loads. No code change required.

## Swap to Real Supabase (2 minutes)

### Step 1 — Create the project
1. Go to https://supabase.com → **New Project**.
2. Copy your **Project URL** and **anon public** key (Settings → API).

### Step 2 — Create tables
1. Supabase Dashboard → **SQL Editor**.
2. Paste and run `supabase_tables.sql` from the `mobile/` folder.
3. This creates `profiles` + `favorites` **with Row Level Security** on every
   table (architecture invariant, no exceptions).

### Step 3 — Configure environment
1. `cp .env.example .env`
2. Paste your values:
```
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```
3. Restart: `npx expo start --clear`

The app detects both variables automatically. Auth, profile metadata and
favorites then use the real Supabase client. In development only, removing
the values returns those specific backend features to demo mode. Production
never falls back to demo.

Real mode uses one persisted Supabase client for authentication, profiles,
and favorite metadata. Email sign-in requires an 8-character password.
Favorites are account-only in V1; signed-out users can browse but cannot save.

### Step 4 — Google Auth (optional)
1. Supabase Dashboard → Authentication → Providers → Google → Enable.
2. Paste a Google OAuth **Client ID + Secret** (Google Cloud Console → APIs &
   Services → Credentials).
3. Add `smartphotography://auth` and the final Expo/web callback URLs to the
   Supabase Auth redirect allow-list.
4. Android: configure the production signing SHA-1 where Google requires it.
   iOS: configure bundle ID `com.smartphotography.assistant`.

## Variable Reference

| Variable | Needed for | Where to find it |
|---|---|---|
| `EXPO_PUBLIC_SUPABASE_URL` | Real backend | Supabase → Settings → API → Project URL |
| `EXPO_PUBLIC_SUPABASE_ANON_KEY` | Real backend | Same page → "anon public" key |
| `EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID` | Enables Google sign-in client flow (optional) | Google Cloud Console → Credentials |

## Rules that never change
- Photos are stored **on-device only** — Supabase receives metadata, never image files.
- RLS is enabled on every Supabase table — never expose a `service_role` key to the app.
- Development demo/real switching is automatic. Production fails closed when
  backend config is missing and never impersonates real data.

## Values and setup outside `.env`

- Run `supabase_tables.sql` once in Supabase SQL Editor.
- Enable Email auth in Supabase; set confirmation rules to your policy.
- Optional Google auth: provider Client ID + **secret live in Supabase
  Dashboard**, not in this app or `.env`.
- EAS/store release: run `eas init`, configure Android/iOS signing credentials,
  and create the final EAS project association.
- Test an Android and iOS development build on physical devices before store
  submission. Expo Go uses session-only memory storage because MMKV is native.
