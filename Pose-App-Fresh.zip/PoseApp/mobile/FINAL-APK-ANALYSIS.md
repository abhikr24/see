# Final APK analysis and repair record

## A. 280 MB APK: actual reason

The EAS Gradle log showed native CMake work for all four Android ABIs: `arm64-v8a`, `armeabi-v7a`, `x86`, and `x86_64`. Expo documents those four as the default React Native architecture set. A direct-install APK that contains native `.so` libraries for all four architectures can therefore be much larger than the source ZIP.

This is not a contradiction: the source ZIP contains mostly text/source files and compressible assets, while the APK contains compiled native machine code. The same native library may exist four times, once per ABI.

The installable phone APK is now constrained to `arm64-v8a`, which is the architecture intended for the user's physical modern Android phone. The generated build is also configured to compress native `.so` files inside the APK.

## B. Black `Unmatched Route` screen: actual reason

The screenshot showed the app's custom scheme as `smartphotography:///` on the Unmatched Route screen. That means Android successfully launched the app, but Expo Router received an empty/bare native path that it did not resolve to the application's intended startup screen.

Repairs:
- `/` now directly renders the existing splash/startup screen; there is no first-frame `/ -> /splash` redirect race.
- `+native-intent.tsx` converts bare/empty initial native paths back to `/`.
- `+not-found.tsx` catches an invalid native URL and redirects back to `/` instead of leaving the user stranded.
- Root `anchor: 'index'` is declared for stable routing/deep-link behavior.

Expo's current documentation says the first `index.tsx` is the `/` route and `+native-intent` can rewrite arbitrary native launch/deep-link paths before they are matched. Deep links use the app's configured custom scheme. 

## C. Blue `Something went wrong` screen

The exact blue wording is the familiar Expo Go/development-loader error surface seen when a development app cannot load its JavaScript project. It should not be part of a self-contained release APK. The canonical `release-apk` profile now explicitly sets `developmentClient: false` and `:app:assembleRelease`, so it cannot intentionally request a dev client.

Do not run `npx expo start` as part of installing/running the final release APK. The release APK must start from its embedded production bundle.

## D. Native Gradle/APK fixes retained

The exact V3 release failure was traced to the native pose module's skipped `bundleReleaseLocalLintAar` output being consumed later by `:app:lintVitalAnalyzeRelease`. The current release path no longer disables the producer task. Instead the application release lint gate is not part of the APK assembly path, preventing the missing intermediate `out.aar` from blocking the APK.

The real pose implementation remains:
VisionCamera -> Nitro/Nitrogen -> custom native pose module -> Google ML Kit accurate pose detector.

## E. Preservation guarantee for this repair

The new archive was compared with the V4 archive actually used for the successful APK build.

- Existing V4 archive entries removed: 0
- New repair files added: 5
- Existing application/native/router/shared files were not deleted.

## F. Correct EAS command

`npx eas-cli build --platform android --profile release-apk`

The resulting artifact should be an installable release `.apk` for the phone, without a Metro/Expo-Go runtime dependency.
