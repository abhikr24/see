# PoseAssist V11 — Easy APK Build

## 1. Extract

Extract the ZIP.

You should see:

```text
smart-camera-FINAL-TECHNICAL-COMPLETE-V11
├── mobile
└── shared
```

Open PowerShell inside `mobile`.

---

## 2. Create `.env`

```powershell
copy .env.example .env
```

Open `mobile\.env` and enter your existing 3 values:

```text
EXPO_PUBLIC_SUPABASE_URL=YOUR_VALUE
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_VALUE
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=YOUR_VALUE
```

Save the file.

---

## 3. Install the exact locked packages

```powershell
npm ci
```

Then approve Skia's native install script:

```powershell
npm approve-scripts @shopify/react-native-skia
```

---

## 4. Set up Git

Move to the folder containing both `mobile` and `shared`:

```powershell
cd ..
```

```powershell
git init
```

```powershell
git add .
```

```powershell
git commit -m "PoseAssist V11"
```

Back to `mobile`:

```powershell
cd mobile
```

---

## 5. Check the project before using EAS

```powershell
npm run verify:release
```

You want:

```text
V11 RUNTIME SAFETY GATE: PASS
COLD START GRAPH GATE: PASS
RELEASE STATIC GATE PASSED
V9 RUNTIME RELEASE GATE: PASS
```

---

## 6. Check internet access to Expo

```powershell
npm run eas:preflight
```

You must get:

```text
EAS preflight PASSED.
```

If you get `ENOTFOUND api.expo.dev`, do not start the build. Fix the internet/DNS first.

---

## 7. Put the 3 public variables on EAS

```powershell
npm run eas:sync-public-env
```

You should see:

```text
EAS preview environment variables are configured.
```

---

## 8. Build the APK

```powershell
eas build --platform android --profile release-apk --non-interactive
```

Use **`release-apk`** exactly.

Do not change it to `preview`.

Keep PowerShell open until EAS says the build was submitted.

After that, you can minimize the terminal.

---

## 9. Install the APK

When EAS says the build is finished:

1. Open the APK link on your Android phone.
2. Download the APK.
3. Install it.
4. Open **PoseAssist from the Android home screen**.

Do not use Expo Go for the final native test.

---

## 10. Test in this order

### A. Startup

```text
[ ] App opens past the PoseAssist startup screen
[ ] Welcome screen appears
```

### B. First run

```text
[ ] Get Started opens onboarding
[ ] Next works
[ ] Continue opens Permissions
```

### C. Permissions

```text
[ ] Camera permission dialog works
[ ] Gallery permission dialog works
[ ] Continue works after camera permission
```

### D. Main app

```text
[ ] Home opens
[ ] Explore opens
[ ] Favorites/profile works
```

### E. Native camera

```text
[ ] Camera opens
[ ] Live camera preview works
[ ] Pose detection starts
[ ] Pose guidance appears
[ ] Photo capture works
[ ] Hardware shutter works where supported
```

---

## Important

Do not run `npm install` again after `npm ci` unless you are intentionally changing dependencies.

Do not use Expo Go to judge the real VisionCamera/ML Kit result.
