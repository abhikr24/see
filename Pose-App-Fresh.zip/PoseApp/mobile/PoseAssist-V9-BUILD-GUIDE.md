# PoseAssist V9 — Easy APK Build

## 1. Extract

Extract the ZIP.

You must see:

```text
mobile
shared
```

If `shared` is missing, stop.

## 2. Open PowerShell in `mobile`

Open the `mobile` folder → right-click → **Open in Terminal**.

### Make `.env`

```powershell
copy .env.example .env
```

Open `.env` and fill these 3 lines with your existing values:

```text
EXPO_PUBLIC_SUPABASE_URL=...
EXPO_PUBLIC_SUPABASE_ANON_KEY=...
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=...
```

Save.

## 3. Install exactly from the lockfile

```powershell
npm ci
```

If npm reports the Skia install-script approval again:

```powershell
npm approve-scripts @shopify/react-native-skia
```

Then run:

```powershell
npm ci
```

## 4. Set up Git once for this fresh copy

Move to the folder containing both `mobile` and `shared`:

```powershell
cd ..
```

```powershell
git init
```

Create `.gitattributes`:

```powershell
notepad .gitattributes
```

Put this inside:

```text
*.jar binary
```

Save and close Notepad.

Then:

```powershell
git add .
```

```powershell
git commit -m "PoseAssist V9 APK build"
```

Go back into mobile:

```powershell
cd mobile
```

## 5. Build the real phone APK

Run exactly this:

```powershell
eas build --platform android --profile release-apk
```

Do **not** use `preview` for this build.

## 6. After EAS says the build succeeded

Open the APK link on your Android phone.

Install the APK.

Then open **PoseAssist from the phone's app icon**.

Do not launch the installed APK through Expo Go.

## 7. Test in this order

```text
1. App opens past PoseAssist startup screen
2. Get Started works
3. Next / Continue works
4. Camera permission works
5. Gallery permission works
6. Main app opens
7. Camera tab opens
8. Live pose detection starts
9. Take photo works
10. Explore / Favorites / Auth work
```

## If the build fails

Do not change files.

Copy the complete **Run gradlew** error and send it back.
