# PoseAssist V10 — Build Failure Analysis

## What failed in the previous V9 attempt

The previous command never reached an EAS cloud Android build.

The decisive error was:

```text
request to https://api.expo.dev/graphql failed, reason: getaddrinfo ENOTFOUND api.expo.dev
Error: GraphQL request failed.
```

That is a DNS/network lookup failure on the computer running EAS CLI. It is not an Android/Gradle/native-code failure.

## V10 changes

1. Added `extra.eas.projectId` with the already-linked EAS project ID so EAS does not need to rediscover the project interactively.
2. Added `owner` to `app.json` for explicit project ownership metadata.
3. Set `release-apk.environment` explicitly to `preview`; Expo uses `preview` by default for internal-distribution builds when no environment is specified, but this removes ambiguity.
4. Added `npm run eas:preflight` to test DNS + HTTPS access to `api.expo.dev` before starting EAS.
5. Replaced the build guide with a short copy/paste workflow and a clear network-error branch.

## Important limitation

No ZIP can repair a broken local DNS/network connection to `api.expo.dev`. EAS CLI must reach Expo's service before the cloud build can be submitted. The V10 preflight makes this failure visible before wasting another build attempt.
