# PoseAssist V6 — Build Fix Report

## Actual V5 failure
The EAS log shows four native `configureCMakeRelWithDebInfo[arm64-v8a]` tasks failing together. All four fail while Android Prefab transforms two shared AARs (`androidx.cursoradapter:cursoradapter:1.0.0` and `com.facebook.fresco:imagepipeline-base:3.6.0`). The common fatal exception is:

`java.util.LinkedHashMap$Entry cannot be cast to java.util.HashMap$TreeNode`

This is not a pose-detector source error and not an ML Kit API error. The same transform is failing across multiple native modules at once, which points to concurrent Gradle/Prefab transform execution rather than four unrelated libraries being broken.

## V6 repair
1. Serialize Gradle project execution (`org.gradle.parallel=false`).
2. Limit the Gradle worker pool to one worker (`org.gradle.workers.max=1`).
3. Override EAS Build's default `-Dorg.gradle.parallel=true` via the `release-apk` profile's `GRADLE_OPTS`, so the EAS worker cannot re-enable parallel execution.
4. Disable EAS build-cache restore for this profile.
5. Add an `eas-build-pre-install` hook that clears only Gradle transform caches on the EAS builder before dependencies are installed. It does not delete project files.
6. Pin the Android builder to the Expo `sdk-57` image (Java 17 / NDK 27.1.12297006), matching the current SDK 57 environment.

## Preserved
- VisionCamera
- ML Kit accurate pose detection
- Nitro/Nitrogen
- Worklets
- Skia
- hardware shutter
- Supabase/backend features
- arm64-only APK policy
- release APK lint fix

## Why this is preferable to changing Gradle versions
The current Expo SDK 57 / React Native 0.86.3 stack uses Gradle 9.3.1 in this project. Android's current AGP 9.1 compatibility table lists Gradle 9.3.1 as the default for AGP 9.1, while Expo's SDK 57 build image is JDK 17. We therefore avoid an unnecessary toolchain migration and target the actual V5 failure mechanism first.
