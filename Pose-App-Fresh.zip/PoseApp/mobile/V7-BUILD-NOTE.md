# V7 BUILD NOTE

Use the existing V6/V7 `release-apk` profile for the real APK.

After installing the APK, launch **PoseAssist from the phone home screen**.
Do not use Expo Go to test camera/ML/media permissions.

Expo Go is supported only for non-native UI sanity checks; the app now shows a clear note there instead of attempting unsupported native permission requests.
