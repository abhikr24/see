# PoseAssist V7 Runtime Repair Report

Base: Smart Camera V6 archive

## Findings from runtime/code audit

1. The first-launch path synchronously serialized all 400 bundled poses to MMKV during startup, even though the same catalog is already bundled and no production code reads that stored snapshot. This could make startup feel frozen on slower devices.
2. The camera permission seam looked for a `VisionCamera` export shape that is not the public permission API used by current VisionCamera releases. Android now uses `PermissionsAndroid` for the OS permission request; VisionCamera still owns the camera itself.
3. Expo Go can throw when full Android media-library access is requested. Permission requests are now guarded and explicitly request only the declared `photo` permission in real builds. Expo Go is detected and does not attempt to grant PoseAssist native permissions.
4. The live camera component was passing the string `facing` to `<Camera device={...}>` instead of the actual device object returned by `useCameraDevice`. That would have been a camera-screen runtime failure after permission was granted.
5. Startup now has a 2.5 s watchdog that falls back to `/welcome` rather than leaving the user indefinitely on the branded splash.

## Preserved features

VisionCamera, Nitro/Nitrogen, Worklets, Skia, ML Kit accurate pose detection, real-time native frame pipeline, hardware shutter, Supabase/auth, gallery, onboarding, and existing routes remain present.

No existing project file from V6 was intentionally deleted.
