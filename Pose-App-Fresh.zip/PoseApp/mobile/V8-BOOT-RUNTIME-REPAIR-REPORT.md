# PoseAssist V8 — Boot Runtime Repair Report

Base: Smart Camera FINAL TECHNICAL COMPLETE V7.

## Problem addressed
The V7 APK built successfully but could remain indefinitely on the React
splash/branding screen on physical Android devices. The previous V7 boot
path still combined a feature-heavy root tree, synchronous MMKV access in
the first navigation decision, a Reanimated splash component, and a
non-lazy tabs navigator that could mount the camera/native graph early.

## Repairs
1. Added an async, bounded boot-state file using the existing
   `expo-file-system/legacy` dependency. Cold-start routing never waits on
   synchronous MMKV.
2. Added a 900 ms boot-state read timeout. Timeout falls back to `/welcome`.
3. Replaced the animated/theme-heavy first React splash with a dependency-
   light `BootGateScreen` using only core React Native primitives + the
   existing app icon asset.
4. Added a 1.4 s navigation watchdog to `/welcome` so boot cannot stay on
   the gate indefinitely if any route decision fails.
5. Mirrored onboarding/permission completion into the async boot-state file;
   existing MMKV flags remain as a compatibility mirror.
6. Deferred auth restoration and non-essential global UI until after initial
   interactions.
7. Removed the unnecessary root-router anchor setting.
8. Changed the tab navigator to lazy mounting so the camera/ML native tree
   is not mounted during first app commit.

## Preserved
VisionCamera, ML Kit accurate pose, Nitro/Nitrogen, Worklets, Skia,
hardware shutter, Supabase, onboarding screens, permissions, Explore,
Favorites, Gallery, Profile, and the release APK build fixes remain intact.

## Verification performed
- All V7 archive entries preserved; only intentional edits/additions.
- Root boot files inspected after extraction.
- No remaining direct MMKV read in `runStartup`.
- `BootGateScreen` contains bounded fallback navigation.
- Tabs navigator uses lazy mounting.
- Native pose package and V7 build-fix files remain present.
