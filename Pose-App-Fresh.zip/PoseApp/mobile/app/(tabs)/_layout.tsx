/**
 * Unit 02 — App shell: 5-tab bottom navigation.
 * Home · Explore · Camera · Gallery · Profile
 *  - Custom AppTabBar (top corners radius xl=20, subtle elevation)
 *  - Tab state preserved across switches (lazy: false)
 *  - Smooth fade transitions between tabs
 */
import { useEffect } from 'react';
import { Tabs } from 'expo-router';
import { useAppTheme } from '@/core/theme';
import { AppTabBar } from '@/shared/components/navigation/AppTabBar';

function ThemeBootstrap() {
  useEffect(() => {
    void import('@/shared/stores/themeStore').then(({ hydrateThemeStore }) => {
      void hydrateThemeStore();
    });
  }, []);
  return null;
}

function AuthBootstrap() {
  useEffect(() => {
    let cancelled = false;
    void import('@/shared/stores/authStore').then(async ({ useAuthStore }) => {
      if (cancelled) return;
      try {
        await useAuthStore.getState().initialize();
      } catch {
        // Auth restore is recoverable; the shell remains usable as a guest.
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);
  return null;
}

export default function TabsLayout() {
  const theme = useAppTheme();
  return (
    <>
      <ThemeBootstrap />
      <AuthBootstrap />
      <Tabs
      tabBar={(props) => <AppTabBar {...props} />}
      screenOptions={{
        headerShown: false,
        // Mount tabs on demand. This keeps the heavy camera/native ML tree out of
        // the initial app commit and prevents cold-start work on unfocused tabs.
        lazy: true,
        freezeOnBlur: false,
        // Disable native tab transitions for Android Fabric cold-start stability.
        // The physical-device log shows continuous topTransitionProgress/topAttached/topDetached churn.
        animation: 'none',
        sceneStyle: { backgroundColor: theme.colors.background },
      }}
    >
      <Tabs.Screen name="home" options={{ title: 'Home' }} />
      <Tabs.Screen name="explore" options={{ title: 'Explore' }} />
      <Tabs.Screen name="camera" options={{ title: 'Camera' }} />
      <Tabs.Screen name="gallery" options={{ title: 'Gallery' }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
      </Tabs>
    </>
  );
}
