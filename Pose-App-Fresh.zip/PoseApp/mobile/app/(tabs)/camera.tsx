/**
 * Camera tab — Unit 12 (replaces the Unit 02 placeholder).
 * State 1: NoPoseState. State 2: live CameraView + controls, JIT mounted,
 * released on blur/background. Auth invariant: guests are gated with
 * AuthRequiredView (camera is an authenticated feature in V1).
 * Also accepts ?poseId= from "Use This Pose" entry points (Unit 09/10).
 * Pure React Native — zero DOM elements, zero web APIs.
 */
import { AuthRequiredView } from '@/features/auth/presentation/components/AuthRequiredView';
import { CameraTab } from '@/features/camera/presentation/screens/CameraTab';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function CameraTabRoute() {
  return (
    <AuthRequiredView
      feature="Camera"
      description="Live guidance and capture are private account features. Pose detection stays entirely on-device."
    >
      <ErrorBoundary context="Camera" fallbackMessage="The camera screen could not be displayed.">
        <CameraTab />
      </ErrorBoundary>
    </AuthRequiredView>
  );
}
