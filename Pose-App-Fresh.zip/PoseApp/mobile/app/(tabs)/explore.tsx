/**
 * Explore tab — Unit 08 (replaces the Unit 02 placeholder).
 * Search bar (history LRU 10) · featured + category collections ·
 * 2-col pose grid over the bundled 400-pose catalog · pose detail sheet
 * with "Use This Pose" (recents LRU 4 + auth gate + camera handoff).
 * Pure React Native — zero DOM elements, zero web APIs.
 */
import { ExploreScreen } from '@/features/explore/presentation/screens/ExploreScreen';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function ExploreTab() {
  return (
    <ErrorBoundary context="Explore" fallbackMessage="The pose library could not be displayed.">
      <ExploreScreen />
    </ErrorBoundary>
  );
}
