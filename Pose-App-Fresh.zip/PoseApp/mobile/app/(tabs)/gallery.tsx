/**
 * Gallery tab — Unit 14 complete.
 * Device-only grouped photo grid, pose history, full preview and recovery.
 * Photos live on the device only — never uploaded (architecture invariant).
 */
import { AuthRequiredView } from '@/features/auth/presentation/components/AuthRequiredView';
import { GalleryTab as GalleryScreen } from '@/features/gallery/presentation/screens/GalleryTab';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function GalleryTab() {
  return (
    <AuthRequiredView
      feature="Gallery"
      description="Your captures and pose history are personal features. Photos remain on this device."
    >
      <ErrorBoundary context="Gallery" fallbackMessage="The local Gallery could not be displayed.">
        <GalleryScreen />
      </ErrorBoundary>
    </AuthRequiredView>
  );
}
