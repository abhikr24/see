/**
 * Home tab — Unit 07 (replaces the Unit 02 placeholder).
 * Greeting header · hero card (Start Camera / Continue last pose) ·
 * recent poses shelf (LRU 4) · quick navigation.
 * Pure React Native — zero DOM elements, zero web APIs.
 */
import { HomeScreen } from '@/features/home/presentation/screens/HomeScreen';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function HomeTab() {
  return (
    <ErrorBoundary context="Home" fallbackMessage="The Home dashboard could not be prepared.">
      <HomeScreen />
    </ErrorBoundary>
  );
}
