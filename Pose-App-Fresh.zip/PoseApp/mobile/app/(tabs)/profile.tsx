/**
 * Route: /(tabs)/profile — Unit 19 (Profile Tab).
 * Complete profile dashboard: avatar, statistics, favorites grid, storage controls,
 * theme selection, display name editing, guest CTA, and authentication management.
 */
import React from 'react';
import { ProfileScreen } from '@/features/profile/presentation/screens/ProfileScreen';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function ProfileRoute() {
  return (
    <ErrorBoundary context="Profile" fallbackMessage="Your profile could not be displayed.">
      <ProfileScreen />
    </ErrorBoundary>
  );
}
