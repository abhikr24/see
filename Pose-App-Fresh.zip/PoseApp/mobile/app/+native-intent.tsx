/**
 * Native launch/deep-link normalizer.
 *
 * Android may launch the app with the bare custom scheme (for example
 * `smartphotography:///`). That URL is not an application screen; it simply
 * means "open the app". Expo Router normally handles links automatically,
 * but a malformed/empty native path can otherwise land on its Unmatched Route
 * screen before JavaScript navigation starts.
 */
export function redirectSystemPath({ path, initial }: { path: string; initial: boolean }) {
  if (!initial) return path;

  try {
    const normalized = String(path ?? '').trim();
    const withoutLeadingSlashes = normalized.replace(/^\/+/, '');

    // Bare/empty native launch paths should always use the real app entry.
    if (
      normalized === '' ||
      normalized === '/' ||
      normalized === '///' ||
      withoutLeadingSlashes === '' ||
      normalized === 'smartphotography:///' ||
      normalized === 'smartphotography://'
    ) {
      return '/';
    }

    return normalized;
  } catch {
    // Never let native intent parsing prevent the application from starting.
    return '/';
  }
}

