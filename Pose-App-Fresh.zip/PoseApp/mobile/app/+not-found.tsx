/**
 * Safety net for malformed/legacy native links.
 * A bad incoming URL must never leave the user stranded on Expo Router's
 * default Unmatched Route page. Returning to the app entry is safer.
 */
import { Redirect } from 'expo-router';

export default function NotFound() {
  return <Redirect href="/" />;
}
