/**
 * Root layout — intentionally lightweight during cold boot.
 *
 * The initial route must be able to render before theme persistence, auth
 * restoration, network banners, or other feature-heavy stores are loaded.
 * Fonts can warm in parallel; the first screen no longer waits for them.
 */
import 'react-native-gesture-handler';
import '@/core/bootstrap/earlyErrorCapture';
import React, { Component, Suspense, lazy, useEffect, useState, type ErrorInfo, type ReactNode } from 'react';
import { Pressable, Text, View, useColorScheme } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClientProvider } from '@tanstack/react-query';
import { darkColors, lightColors } from '@shared/theme/colors';
import { APP_SHORT_NAME } from '@shared/constants/app';
import { queryClient } from '@/core/network/queryClient';

const OfflineBanner = lazy(async () => {
  const mod = await import('@/shared/components/OfflineBanner');
  return { default: mod.OfflineBanner };
});

const GlobalSnackBar = lazy(async () => {
  const mod = await import('@/shared/components/SuccessSnackBar');
  return { default: mod.GlobalSnackBar };
});


interface RootErrorBoundaryState {
  readonly hasError: boolean;
}

class RootErrorBoundary extends Component<{ readonly children: ReactNode }, RootErrorBoundaryState> {
  state: RootErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): RootErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    void import('@/core/error/errorHandler')
      .then(({ errorHandler }) => {
        errorHandler.handle(error, 'Root');
        if (info.componentStack) {
          // The global error handler already recorded the component error.
        }
      })
      .catch(() => undefined);
  }

  private retry = (): void => {
    this.setState({ hasError: false });
  };

  render(): ReactNode {
    if (!this.state.hasError) return this.props.children;
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          padding: 32,
          backgroundColor: lightColors.background,
        }}
      >
        {/* Keep the recovery surface dependency-light. */}
        <View style={{ alignItems: 'center', gap: 12 }}>
          <View
            style={{
              width: 72,
              height: 72,
              borderRadius: 36,
              backgroundColor: lightColors.primaryLight,
            }}
          />
          <AppBootText text={`${APP_SHORT_NAME} needs to recover.`} />
          <AppBootButton title="Retry" onPress={this.retry} />
        </View>
      </View>
    );
  }
}

function AppBootText({ text }: { readonly text: string }) {
  return <Text style={{ fontSize: 20, fontWeight: '700', color: lightColors.shadowColor }}>{text}</Text>;
}

function AppBootButton({ title, onPress }: { readonly title: string; readonly onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={{ paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, backgroundColor: lightColors.primary }}
    >
      <Text style={{ color: lightColors.textOnPrimary, fontSize: 16, fontWeight: '600' }}>{title}</Text>
    </Pressable>
  );
}

export default function RootLayout() {
  const scheme = useColorScheme();
  const colors = scheme === 'dark' ? darkColors : lightColors;
  const [postBootReady, setPostBootReady] = useState(false);

  useEffect(() => {
    // Start global error capture without pulling the full error stack into the
    // initial module graph before the first route is rendered.
    let disposeGlobalHandler: (() => void) | null = null;
    let cancelled = false;

    void import('@/core/error/errorHandler')
      .then(({ installGlobalErrorHandler }) => {
        if (cancelled) return;
        disposeGlobalHandler = installGlobalErrorHandler();
      })
      .catch(() => undefined);

    const overlayTimer = setTimeout(() => {
      if (!cancelled) setPostBootReady(true);
    }, 3000);


    return () => {
      cancelled = true;
      clearTimeout(overlayTimer);
      disposeGlobalHandler?.();
    };
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <SafeAreaProvider>
          <View style={{ flex: 1, backgroundColor: colors.background }}>
            <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
            <RootErrorBoundary>
              <View style={{ flex: 1 }}>
                {/*
                 * IMPORTANT: keep the navigator host at a stable React child
                 * position for the lifetime of the root. The previous V12 code
                 * conditionally inserted OfflineBanner BEFORE this View after
                 * a 3s timer. React then reconciled the old Stack host as a
                 * different sibling, which could tear down/recreate the native
                 * Stack/Screens tree mid-session. The physical-device log showed
                 * the resulting `instanceHandle is null` + repeated
                 * topAttached/topDetached/topTransitionProgress events and a
                 * white screen. The banner is now an absolute overlay so it
                 * never changes the navigator host position or layout.
                 */}
                <View style={{ flex: 1 }}>
                  <Stack
                    screenOptions={{
                      headerShown: false,
                      // Physical-device logs show continuous native Stack/Screens transition churn
                      // (`topAttached`/`topDetached`/`topTransitionProgress`) while the UI is white.
                      // Keep navigation behavior intact but remove native transition animations so
                      // Android Fabric cannot get trapped in a transition lifecycle loop at cold boot.
                      animation: 'none',
                      contentStyle: { backgroundColor: colors.background },
                    }}
                  >
                    <Stack.Screen name="splash" />
                    <Stack.Screen name="welcome" />
                    <Stack.Screen name="onboarding" />
                    <Stack.Screen name="permissions" />
                    <Stack.Screen name="auth" options={{ presentation: 'modal' }} />
                    <Stack.Screen name="auth/reset-password" />
                    <Stack.Screen name="delete-account" />
                    <Stack.Screen name="search" />
                    <Stack.Screen name="pose/[id]" />
                    <Stack.Screen name="settings" />
                    <Stack.Screen name="settings/privacy" />
                    <Stack.Screen name="settings/terms" />
                    <Stack.Screen name="settings/about" />
                    <Stack.Screen name="camera/preview" />
                    <Stack.Screen name="gallery/photo/[id]" />
                    <Stack.Screen name="(tabs)" />
                  </Stack>
                </View>
                {postBootReady && (
                  <View
                    pointerEvents="box-none"
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      zIndex: 100,
                    }}
                  >
                    <Suspense fallback={null}>
                      <OfflineBanner />
                    </Suspense>
                  </View>
                )}
              </View>
            </RootErrorBoundary>
            {postBootReady && (
              <Suspense fallback={null}>
                <GlobalSnackBar />
              </Suspense>
            )}
          </View>
        </SafeAreaProvider>
      </QueryClientProvider>
    </GestureHandlerRootView>
  );
}
