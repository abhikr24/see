/**
 * Route: /auth — Unit 06 (modal). Supports /auth?mode=sign-up deep links so
 * "Create Account" entries land directly in account-creation mode. The full
 * screen (form · email-confirmation · already-signed-in states) lives in
 * features/auth/presentation/screens/AuthScreen.tsx; the session-exit policy
 * that fixed the Create-Account regression lives in shared/auth/authFlow.ts.
 */
import React, { useEffect } from 'react';
import { AuthScreen } from '@/features/auth/presentation/screens/AuthScreen';

function AuthRouteBootstrap() {
  useEffect(() => {
    let cancelled = false;
    void import('@/shared/stores/authStore').then(async ({ useAuthStore }) => {
      if (cancelled) return;
      try {
        await useAuthStore.getState().initialize();
      } catch {
        // Auth screen handles failed restore as unauthenticated.
      }
    });
    return () => { cancelled = true; };
  }, []);
  return null;
}

export default function AuthRoute() {
  return (
    <>
      <AuthRouteBootstrap />
      <AuthScreen />
    </>
  );
}
