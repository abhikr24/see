/**
 * Route: /auth/reset-password — B2 password recovery (request + reset).
 * Also the deep-link target named by PASSWORD_RESET_ROUTE: Supabase
 * recovery emails return the user here; the screen surfaces the request
 * form, a live recovery session, or an honest expired-link state.
 */
import React from 'react';
import { ResetPasswordScreen } from '@/features/auth/presentation/screens/ResetPasswordScreen';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function ResetPasswordRoute() {
  return (
    <ErrorBoundary context="ResetPassword" fallbackMessage="The password reset flow could not be displayed.">
      <ResetPasswordScreen />
    </ErrorBoundary>
  );
}
