/** Route: /camera/preview — Unit 13 captured-photo review. */
import { useLocalSearchParams } from 'expo-router';
import {
  FILTER_INTENSITY_DEFAULT,
  clampFilterId,
  clampFilterIntensity,
} from '@shared/index';
import { PreviewScreen } from '@/features/camera/presentation/screens/PreviewScreen';
import { AuthRequiredView } from '@/features/auth/presentation/components/AuthRequiredView';

function first(value: string | string[] | undefined): string | null {
  if (typeof value === 'string' && value.length > 0) return value;
  if (Array.isArray(value) && value[0]) return value[0];
  return null;
}

export default function CameraPreviewRoute() {
  const params = useLocalSearchParams<{
    uri?: string | string[];
    poseId?: string | string[];
    filterUsed?: string | string[];
    /** LOOKS — the strength the look was baked in at, as a string param. */
    filterIntensity?: string | string[];
  }>();
  const uri = first(params.uri) ?? '';
  const poseId = first(params.poseId);
  /* One validator, in shared/, instead of a local copy of the id list that
     could fall out of step with the strip and the pipeline. */
  const filterUsed = clampFilterId(first(params.filterUsed));
  const rawIntensity = first(params.filterIntensity);
  const filterIntensity =
    rawIntensity === null
      ? FILTER_INTENSITY_DEFAULT
      : clampFilterIntensity(Number.parseInt(rawIntensity, 10));

  return (
    <AuthRequiredView
      feature="Photo Preview"
      description="Captured photos are private account features and remain on this device."
    >
      <PreviewScreen
        uri={uri}
        poseId={poseId}
        filterUsed={filterUsed}
        filterIntensity={filterIntensity}
      />
    </AuthRequiredView>
  );
}
