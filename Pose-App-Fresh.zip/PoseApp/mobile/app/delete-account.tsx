/**
 * Route: /delete-account — B1 account deletion (Apple 5.1.1(v) / Google
 * Play in-app deletion requirement). Reachable from Profile → Delete
 * Account; the screen itself holds the two-step serious flow.
 */
import React from 'react';
import { DeleteAccountScreen } from '@/features/auth/presentation/screens/DeleteAccountScreen';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function DeleteAccountRoute() {
  return (
    <ErrorBoundary context="DeleteAccount" fallbackMessage="Account deletion could not be displayed.">
      <DeleteAccountScreen />
    </ErrorBoundary>
  );
}
