/** Route: /gallery/photo/[id] — Unit 14 saved-photo preview. */
import { useLocalSearchParams } from 'expo-router';
import { AuthRequiredView } from '@/features/auth/presentation/components/AuthRequiredView';
import { GalleryPhotoPreviewScreen } from '@/features/gallery/presentation/screens/GalleryPhotoPreviewScreen';

function normalizeId(value: string | string[] | undefined): string | null {
  if (typeof value === 'string' && value.length > 0) return value;
  if (Array.isArray(value) && value[0]) return value[0];
  return null;
}

export default function GalleryPhotoRoute() {
  const params = useLocalSearchParams<{ id?: string | string[] }>();
  return (
    <AuthRequiredView feature="Photo Preview" description="Saved captures are private, device-only account features.">
      <GalleryPhotoPreviewScreen photoId={normalizeId(params.id)} />
    </AuthRequiredView>
  );
}
