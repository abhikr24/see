/** Stable native entry point. The heavy feature graph is not part of the first screen. */
import { BootGateScreen } from '@/features/onboarding/presentation/screens/BootGateScreen';

export default function Index() {
  return <BootGateScreen />;
}
