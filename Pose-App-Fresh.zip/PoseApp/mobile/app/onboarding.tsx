/**
 * Route: /onboarding — Unit 03 (3 slides → Skip/Next/Continue → /permissions).
 */
import { OnboardingScreen } from '@/features/onboarding/presentation/screens/OnboardingScreen';

export default function OnboardingRoute() {
  return <OnboardingScreen />;
}
