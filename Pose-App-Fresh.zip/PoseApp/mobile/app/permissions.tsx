/**
 * Route: /permissions — Unit 04 (camera + gallery, recovery, never notifications).
 */
import { PermissionsScreen } from '@/features/onboarding/presentation/screens/PermissionsScreen';

export default function PermissionsRoute() {
  return <PermissionsScreen />;
}
