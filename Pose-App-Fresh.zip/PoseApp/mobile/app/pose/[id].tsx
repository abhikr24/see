/**
 * Route: /pose/[id] - Unit 10 (pose detail).
 * Deep-linkable (scheme smartphotography://pose/<id>). The route file only
 * normalizes the param and delegates to the controller + screen; unknown
 * ids render the screen's built-in not-found state instead of crashing.
 */
import { useLocalSearchParams } from 'expo-router';
import {
  normalizePoseIdParam,
  usePoseDetailController,
} from '@/features/poses/presentation/hooks/usePoseDetailController';
import { PoseDetailScreen } from '@/features/poses/presentation/screens/PoseDetailScreen';

export default function PoseDetailRoute() {
  const params = useLocalSearchParams<{ id?: string | string[] }>();
  const poseId = normalizePoseIdParam(params.id);
  const controller = usePoseDetailController(poseId);
  return <PoseDetailScreen controller={controller} />;
}
