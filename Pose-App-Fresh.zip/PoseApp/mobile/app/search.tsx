import { SearchScreen } from '@/features/search/presentation/screens/SearchScreen';

export default function SearchRoute() {
  return <SearchScreen />;
}
