/**
 * Route: /settings — Unit 20 (Camera & Capture Preferences).
 */
import React from 'react';
import { SettingsScreen } from '@/features/settings/presentation/screens/SettingsScreen';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export default function SettingsRoute() {
  return (
    <ErrorBoundary context="Settings" fallbackMessage="Settings could not be displayed.">
      <SettingsScreen />
    </ErrorBoundary>
  );
}
