/**
 * Route: /settings/about — Unit 21 (About).
 * App icon, name, version and a short product description.
 */
import React from 'react';
import { SettingsInfoScreen } from '@/features/settings/presentation/screens/SettingsInfoScreen';

export default function AboutRoute() {
  return <SettingsInfoScreen page="about" />;
}
