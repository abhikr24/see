/**
 * Route: /settings/privacy — Unit 21 (Privacy Policy).
 * States the on-device photo/ML invariants in plain language.
 */
import React from 'react';
import { SettingsInfoScreen } from '@/features/settings/presentation/screens/SettingsInfoScreen';

export default function PrivacyPolicyRoute() {
  return <SettingsInfoScreen page="privacy" />;
}
