/**
 * Route: /settings/terms — Unit 21 (Terms of Service).
 */
import React from 'react';
import { SettingsInfoScreen } from '@/features/settings/presentation/screens/SettingsInfoScreen';

export default function TermsOfServiceRoute() {
  return <SettingsInfoScreen page="terms" />;
}
