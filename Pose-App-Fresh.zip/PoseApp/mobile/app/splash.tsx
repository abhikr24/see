/** Legacy route: always return to the real `/` boot gate. */
import { Redirect } from 'expo-router';

export default function SplashRoute() {
  return <Redirect href="/" />;
}
