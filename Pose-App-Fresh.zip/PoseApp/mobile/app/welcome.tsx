/**
 * Route: /welcome — Unit 03.
 */
import { WelcomeScreen } from '@/features/onboarding/presentation/screens/WelcomeScreen';

export default function WelcomeRoute() {
  return <WelcomeScreen />;
}
