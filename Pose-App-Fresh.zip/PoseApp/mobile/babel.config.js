module.exports = function (api) {
  api.cache(true);
  return {
    // babel-preset-expo automatically injects the Reanimated/Worklets Babel
    // plugin when react-native-reanimated is installed (Expo SDK 54+ / RN
    // Reanimated 4). Declaring 'react-native-reanimated/plugin' manually is
    // removed on purpose — that module path no longer exists in Reanimated 4
    // and double-registering the plugin breaks the transform.
    presets: ['babel-preset-expo'],
  };
};
