# A1 — Native Real-Time Pose Pipeline (frame-driven, ML Kit + VisionCamera)

Status: ARCHITECTURALLY REAL-TIME · code complete in-repo · native build NOT
compiled in this coding session (no Android SDK / Xcode here) · physical
device NOT verified. See §J for exact verification status.

## 1. Root cause audit (phases 1–2, evidence-driven)

Frozen pipeline BEFORE this change:

```
CameraView (expo-camera ~57, native preview only)
  ↓ setInterval(66 ms) in CameraTab.tsx ("pump")
captureMlFrame() = cameraRef.takePictureAsync({ quality: 0.1, base64: true, skipProcessing: true })
  ↓ full JPEG encode + base64 encode of a real still photo, ~5–20 Hz attempted
temp file on disk (deleted after each frame — churn)
  ↓
poseDetectorService.detect(createPhotoFrame(data:image/jpeg;base64,…))
  ↓ @mediapipe/tasks-vision (WASM) — can NEVER execute on Hermes (no
    WebAssembly in the stock RN JS runtime), so on-device init always failed
    → status 'unavailable'; on web Metro it resolves to a stub that throws.
```

Per-stage verdict:

| Stage | Where | Per camera frame? | Expensive conversion | Verdict |
|---|---|---|---|---|
| Preview | native (expo av) | n/a (preview only) | – | REPLACED (expo-camera has no frame API) |
| Frame acquisition | JS, `takePictureAsync` loop | NO — still photos | JPEG+base64+file I/O per frame | REPLACED by native frame output |
| Image conversion | JS string / data URI | n/a | base64→decoder | REMOVED from live path |
| Pose detector | JS/WASM MediaPipe | attempted | decode per frame | ISOLATED → superseded on native by ML Kit Nitro plugin |
| Raw landmarks | normalized x/y/z + visibility | – | – | CONTRACT PRESERVED (PoseLandmark) |
| Normalization/analysis/coaching/speech | shared/ + poseAnalysisEngine | per result | none | PRESERVED, untouched |

The counter-performance facts: every 66 ms the pump asked the camera HAL for a
complete JPEG still (full ISP pipeline + JPEG encoder), base64-encoded it,
wrote/linked a temp file, then attempted WASM inference that could not run —
100% waste on device. Exactly the A1 issue: photo-sampling masquerading as
live ML. Expo camera's own docs confirm it exposes no per-frame callback; the
old code even said so in its header comment.

## 2. Research summary (phase 2 — stack locked to THIS repo)

Stack in repo: Expo SDK ~57 · RN 0.86.3 · React 19.2.3 · react-native-worklets
0.10.1 (already installed, unused — provisioned for this exact migration) ·
Skia 2.6.2 · Expo Router ~57 · Metro (see metro.config.js).

Evaluated against the Sep-2026 registry:

- **expo-camera ~57** — no frame callback/frame processor. Cannot satisfy A1
  architecturally. REJECTED for the live path (preview+capture engine too,
  because two camera engines are forbidden by the dependency rule).
- **react-native-vision-camera 5.2.3 (Nitro)** — native `useFrameOutput`
  delivering `Frame` HybridObjects synchronously on a detached camera thread
  ("worklet"), explicit `frame.dispose()`, built-in `onFrameDropped`
  backpressure signal, yuv pixelFormat (ML Kit native input), targetResolution
  for ML, orientation + isMirrored flags designed to be passed to ML
  libraries, `usePhotoOutput.capturePhotoToFile`, zoom/torch/flash/focus
  controller parity. Requirement RN 0.86+ matches. CHOSEN (single production
  camera engine).
- **Detector options for frames:**
  - `@mediapipe/tasks-vision` (WASM/JS) — cannot run on Hermes at all; keeping
    it would preserve the root cause. REJECTED for native (kept only as the
    inert legacy/web module; CameraTab no longer uses it).
  - `react-native-vision-camera-mlkit@2.0.1` — production-quality v5 Nitro
    plugin, but v2 ships OCR + barcode only ("pose is post-v2 roadmap").
    REJECTED as a dependency, USED as the structural template for our plugin.
  - `react-native-mediapipe@0.6.0`, `vision-camera-v4-pose-detection` forks —
    VC4/worklets-core era (2024), incompatible with VC5. REJECTED.
  - `react-native-fast-tflite@3.0.1` (Nitro) — would require re-implementing
    BlazePose tensor decoding/anchors in JS: accuracy risk, maintenance cost.
    REJECTED.
  - **Google ML Kit Pose Detection (accurate, bundled model)** behind a LOCAL
    Nitro frame-processor plugin — maintained native SDK, offline/bundled
    weights, 33-landmark BlazePose topology identical to the existing
    `PoseLandmark` contract (indices 0 nose … 32 rightFootIndex), per-landmark
    in-frame likelihood ↔ our `visibility`, z depth ↔ our `z`. CHOSEN.

## 3. Architecture (after)

```
VisionCamera <Camera> (native preview + photo output) SAME single engine
  └─ CameraFrameOutput (yuv, target 640×480, camera thread)
       │  worklet: detectPose(frame) → frame.dispose()   ← native thread,
       │  Google ML Kit pose-detection-accurate, no JPEG/base64/file I/O
       ▼
NativePoseFrame { width,height,timestampMs, landmarks[] raw upright px,
                  orientation, isMirrored }
       │  runOnJS (33 landmarks ≈ tiny payload)
       ▼
poseFrameScheduler (pure shared/): latest-frame-wins, single-flight,
  drop accounting, staleness bound (result ≤ 350 ms old or discarded)
       ▼
adaptNativePoseFrame (pure shared/): px→0..1 normalize, clamp,
  mirror x'=1−x when isMirrored (front camera overlay agreement),
  likelihood→visibility, z passthrough, 33-count validation
       ▼
readonly PoseLandmark[] | null   ← EXISTING CONTRACT
       ▼
poseAnalysisEngine → decisionToCoachingState → speech planner / UI
  (UNTOUCHED mathematics)
```

User PHOTO CAPTURE stays a separate path: `usePhotoOutput.capturePhotoToFile`
→ existing brightness/aspect/filter pipeline (Skia) → gallery. NO shared code
with the ML frame path anymore (no temp JPEGs for ML, ever).

The pose math consumes `PoseLandmark[]` exactly as before — it cannot tell
whether landmarks came from ML Kit, the preview mock, or test fixtures. That
was the explicit design goal (seam: `shared/ml/poseFrameTransform.ts` +
`poseFramePolicy.ts`; runtime: `mobile/src/core/ml/poseFrameRuntime.ts`;
camera glue: `usePoseFrameOutput` authoring inside `CameraPreview`).

## 4. Performance design (continuous-use policy)

- Camera frames: whatever rate the session negotiates (30 fps typical).
  `CameraFrameOutput` targets 640×480 yuv (preview-sized buffers) — inference
  input is decoupled from preview resolution; preview stays full quality.
- Inference: SYNCHRONOUS on the frame thread, at most one detector instance;
  when inference is slower than frame delivery VisionCamera DROPS frames
  natively and reports via `onFrameDropped` (bounded by construction — no
  queue can ever form: the worklet owns the thread).
- Bridge: one `runOnJS` per PROCESSED frame only (dropped frames cost zero
  JS). On the JS side the scheduler is latest-frame-wins with single-flight
 : while the previous result is still being consumed (engine/coaching/TTS is
  sync, so consumption is one microtask) nothing can pile up; a result older
  than `POSE_RESULT_MAX_STALENESS_MS` (350 ms) is discarded as stale — no
  700 ms-old guidance.
- Hand/gesture model: unchanged policy — it only runs when its (JS/WASM)
  model is ready; on native today it reports 'unavailable' exactly as before
  (scoped fallback). Its future native replacement is ONE more plugin method
  on the same plugin boundary (documented there).
- Lifecycle: plugin created on camera-ready+ML-gate-open; released on
  unmount/blur/background/facing-switch; dispose() is idempotent; a single
  failed inference is counted and skipped, 8 consecutive failures park the
  feature (same policy as the old service).
- Orchestration ON/OFF switches follow the existing `mlGateOpen` definition
  (pose pinned · permission · mounted · focused · foreground · capture idle).

## 5. Mirroring & orientation (rule-11/12 contract)

- Detector input: frame.orientation passed straight into ML Kit (its native
  rotationDegrees) — landmarks come back in UPRIGHT image space.
- Adapter normalizes by the UPRIGHT dims (plugin returns dims already swapped
  for 90/270 so JS never guesses).
- Front camera: VisionCamera reports isMirrored=true when the preview is
  mirrored but the buffer is not; the adapter applies x→1−x AFTER
  normalization, so overlay coordinates always match what the user sees.
- LEFT/RIGHT SEMANTICS: ML Kit labels are person-relative (the person's
  anatomical left wrist is always leftWrist), independent of mirroring — the
  adapter therefore never renames joints. Tests cover: user-raises-left-hand
  in a mirrored front frame keeps leftWrist = leftWrist with x mirrored to the
  user's screen side.
- No hardcoded 1080×1920/0° anywhere: dims arrive per frame with the result.

## 6. Fallback behaviour (no hidden disasters)

nativePosePlugin.createPoseDetector() can return null when: Expo Go (native
module absent), plugin pod/gradle not built, ML Kit model download corrupt.
Then: feature marked 'unavailable' (scoped to live guidance only), ONE
AppLogger line, camera keeps 100% of capture UI. It NEVER falls back to
takePictureAsync sampling — that path is deleted.

## 7. Files (new ✚ / changed ✎ / removed ✗)

See §D of the handoff report / progress tracker A1 entry for the full list and
rationale. The protected inventory (pose math, coaching, speech, capture UX,
filters, editor, auth, settings) is untouched: grep for their test suites —
all 477 reference tests still pass unchanged.

## 8. Native build requirements (honest)

Expo Go CANNOT run this (native frame processors). Required:
`npx expo prebuild` (or EAS Build) producing a dev client that contains:
react-native-vision-camera@5.2.3 + react-native-vision-camera-worklets@5.2.3
(+ react-native-worklets, react-native-nitro-modules, react-native-nitro-image)
+ the local plugin `vision-camera-mlkit-pose` with
`com.google.mlkit:pose-detection-accurate:16.0.0-beta5` (Android, BUNDLED
model — offline) / `GoogleMLKit/PoseDetectionAccurate` pod (iOS ≥ 15.1).
Android minSdk 24 (VisionCamera requirement). Camera permission string lives
in app.json (`[react-native-vision-camera/expo-plugin]` + mlkit plugin).

## 9. Tests (all local, all passing)

- tests/camera/poseFrameTransform.test.ts — normalization, clamp, mirror×front,
  L/R semantics under mirror, upright-swap parity, visibility mapping,
  short/garbage frame rejection.
- tests/camera/poseFramePolicy.test.ts — latest-frame-wins, NO unbounded
  queue (drop accounting), single-flight, stale-result discard, teardown,
  facing-switch epoch invalidation.
- Full existing suite: unchanged, green (see run output in tracker).

## 10. Known limitations / future replacement points

- Hand (five-finger) detection still uses the WASM hand landmarker →
  unavailable in the native build today (same as before this change — no
  regression; pose guidance itself is now REAL). Replacement seam: one extra
  method on vision-camera-mlkit-pose (MediaPipe Hand Landmarker via LiteRT or
  a future ML Kit hand API).
- `poseDetectorService.ts` (WASM) was unreferenced by the camera screen and is
  now REMOVED (PATCH-02) as dead legacy code. The legacy web stub
  (mediapipeWebUnsupported.ts / metro.config.js redirect) is RETAINED, but only
  to serve the still-live WASM hand landmarker. Any future web preview of the
  NATIVE app shell still resolves 'unavailable'.
- Physical-device FPS/latency numbers are NOT claimed: requires a device run
  (instrumentation exists: poseFrameRuntime metrics — framesIn, inferred,
  droppedByScheduler, droppedByPipeline, staleDiscarded, avgInferenceMs).
