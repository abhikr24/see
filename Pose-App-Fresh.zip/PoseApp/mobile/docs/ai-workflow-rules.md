# AI Workflow Rules

These rules implement the user's permanent instruction to read, reason, then
execute like a senior engineer.

## Required Sequence

1. **Read** the relevant unit plan, architecture, UI guidance, current progress
   tracker and affected source files.
2. **Think** through dependencies, invariants, failure states and conflicts.
3. **Summarize** the understood scope before implementation. A direct user
   instruction to build a named unit authorizes that verified unit only.
4. **Execute** the smallest complete production implementation. No adjacent
   speculative features and no throwaway stubs presented as real behavior.
5. **Verify** the actual Expo tree separately from the browser preview.
6. **Record** the outcome and unresolved items in the progress tracker.

## Stop Conditions

Stop and tell the user before coding when:

- the required source section cannot be read;
- two source documents conflict;
- the change would violate on-device photo/ML processing, auth access rules,
  RLS, the locked stack or React Native platform purity;
- credentials or assets are required and no safe per-feature fallback exists.

Never silently guess around a stop condition.
