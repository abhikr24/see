# Camera Controls & Brightness — audit + implementation record

Scope of this session: **camera controls** and **brightness / exposure
control** only. Pose analysis, MediaPipe, the reference-pose system, semantic
coaching, TTS, instruction language, gesture / auto / manual capture,
countdown, permissions, save, gallery, filters, preview, accessibility and
navigation were read but **not modified** except where a control had to be
passed through them.

---

## 1. Audit of the camera capability that existed on arrival

Verified against the code in this tree **and** against the actually-installed
`expo-camera@57.0.5` type surface (`node_modules/expo-camera/build/Camera.types.d.ts`),
not against memory or documentation alone.

| Capability | Where it lives | Verdict on arrival |
|---|---|---|
| Single-session `CameraView` (JIT mount, release on blur/background) | `CameraPreview`, `CameraTab` | **WORKING** |
| Camera switching (front/rear, zoom reset on flip) | `cameraService.switchCamera`, `BottomControlsBar` | **WORKING** |
| Flash `off → auto → on` | `cameraService.cycleFlash`, `TopControlsBar` | **WORKING BUT NEEDS POLISH** — English-only labels on a screen that is otherwise bilingual; no relationship to any continuous light |
| Torch / continuous light | *nowhere* | **MISSING** — `CameraView.enableTorch` is supported by the foundation and was never exposed |
| Exposure / EV bias | *nowhere* | **MISSING, AND NOT AVAILABLE** — see §2 |
| Brightness of the photograph | *nowhere* | **MISSING** |
| Pinch zoom 1×–8× + transient zoom pill | `CameraPreview`, `ZoomIndicator` | **WORKING** |
| Timer Off/3/5/10 with badge | `cameraService.cycleTimer`, `TopControlsBar` | **WORKING** |
| Tap-to-focus | *nowhere* | **MISSING / NOT SAFELY ADDABLE** — see §5 |
| Filters (Original/Vivid/Warm/Cool/B&W) | `FilterStrip`, `PreviewScreen` | **INCOMPLETE (pre-existing, out of scope)** — the choice is recorded as `filterUsed` metadata; no pixels change. Left exactly as found; this session did not widen or hide it |
| Grid overlay | `GridOverlay` + settings | **WORKING** |
| Shutter / countdown / auto-hold / open-palm gesture capture | `BottomControlsBar`, `IntelligentCaptureController`, `OpenPalmGate` | **WORKING** — untouched |
| Permissions, mount-error recovery, capture-error banner | `CameraTab` | **WORKING** — untouched |
| Camera screen on web | `CameraPreview` returns `null` on web | **DEVICE-ONLY**, by design; the browser mirror in `tooling/preview` is **PREVIEW-ONLY** |

---

## 2. The brightness question, answered honestly

> **D1 AMDENDMENT (do not read this section as current law).** The audit below
> was true on arrival and stays here as history: stock `expo-camera@57.0.5`
> really ships no native exposure API. D1 (Part 2, appended at the end of
> this document) added the smallest possible native exposure bridge to that
> same foundation via patch-package. Where the bridge reports support, the
> control is now REAL camera exposure; where it cannot, the photo-processing
> mechanism below remains — explicitly labelled as the fallback it always was.

**Does the current camera foundation expose exposure compensation?** No.

`expo-camera@57.0.5` `CameraViewProps` exposes `facing`, `flash`,
`enableTorch`, `zoom`, `autofocus`, `mirror`, `mode`, `mute`, `pictureSize`,
`ratio`, `selectedLens`, `videoBitrate`, `videoQuality`,
`responsiveOrientationWhenOrientationLocked`, `poster`, `active`,
`barcodeScannerSettings` — and **no exposure, EV, ISO or metering API on
Android or iOS**. The only `exposureCompensation` symbol in the package is in
`WebCameraSettings`, a `@hidden`, web-only type that the native camera screen
never reaches (the screen does not mount on web at all).

Therefore:

* A slider wired to "exposure" would be a **no-op** — the saved photo would be
  byte-for-byte identical whatever the user chose. Not shipped.
* True sensor exposure would require replacing the camera foundation
  (`react-native-vision-camera` has full manual exposure). **That is a
  camera-foundation replacement and was NOT performed** — see §5.

**What was shipped instead, and what it honestly is:**

> **Brightness makes the PHOTOGRAPH lighter or darker.** Seven detents,
> `−3 … Normal … +3`. At capture the chosen detent is applied to the real
> image file through a Skia colour matrix; the viewfinder shows an
> approximation of the result while the user chooses.

The control never says "exposure", "EV" or "gain" to the user. It says
**Brighter / Darker / Normal / Reset**, plus one line of truth —
*"Applied to your photo"* / *"आपकी फोटो पर लागू होगा"*.

---

## 3. What was added

### Pure, platform-neutral (`shared/camera/cameraControls.ts`)

* `BRIGHTNESS_MIN/MAX/DEFAULT`, `clampBrightness`, `isBrightnessDefault`
* `brightnessGain` — **the single definition of the adjustment** (18 % per detent)
* `brightnessColorMatrix` — the 4×5 matrix the real pixel pipeline consumes;
  exactly the identity matrix at the default detent
* `brightnessPreviewScrim` — the viewfinder approximation, derived from the
  same gain, capped at 0.30 opacity so the subject stays framable
* `brightnessBadge` — direction-carrying badge, `null` at default
* `BRIGHTNESS_MECHANISM = "photo-processing"` — the claim, in data, so it can
  be asserted by a test and cannot quietly drift into "exposure"
* `torchSupported`, `resolveLighting`, `FLASH_CYCLE`, `nextFlashMode`

### Bilingual copy (`shared/camera/cameraStatusCopy.ts`)

`brightnessTitle · brightnessValue · brightnessBrighter · brightnessDarker ·
brightnessReset · brightnessNote · torchTitle · torchValue · torchBlocked ·
flashTitle · flashValue · flashSupersededNote` — English + Hindi, resolved
through the existing language pipeline. No new language mechanism.

### Real pixels (`mobile/src/core/camera/photoBrightness.ts`)

Decode → offscreen Skia surface → colour matrix → re-encode → new cache file,
using **@shopify/react-native-skia, already a project dependency** (it already
draws the silhouette, the countdown dial and the shutter ring).
No-op at the default detent; on *any* failure the original photo is returned
so a brightness preference can never cost the user a shot.

### UI

* `TopControlsBar` — now **flash · light (torch) · brightness · timer ·
  settings**; flash dims (with a reason) while the torch is lit; torch dims
  (with a reason) on the front camera; all values announced bilingually.
* `BrightnessControl` — right-edge detent track at thumb height, value chip
  doubles as **Reset**, tap-off / re-tap / 3.8 s idle all dismiss, full
  `adjustable` accessibility role with increment / decrement / activate.
* `CameraPreview` — passes `enableTorch`, renders the approximation wash.
* `CameraTab` — resolves lighting once, applies the detent to the captured
  file before the preview screen, reads the detent **once at the shutter**.

### Session semantics

Torch and brightness are **transient**: `resetTransientCameraState` returns
both to default with the session, so neither can be silently still applied the
next time the camera opens.

---

## 4. Preview (PREVIEW-ONLY) parity

The browser mirror consumes the same `resolveLighting`, the same copy table
and the same `brightnessGain`. In the browser the gain is applied as a CSS
filter to **both** the live video and the captured frame, so the mirror's
"photo" really is brighter — the same outcome the device pipeline produces,
reached with browser means.

The torch is represented **honestly**: it toggles, shows its resolved state
and logs `device hardware — not simulated in browser`. No claim is made that
the browser lit a lamp or changed physical exposure.

---

## 5. What was deliberately NOT done

* **No camera-foundation migration.** `react-native-vision-camera` would give
  true exposure, focus and frame processors, but swapping it in touches the
  ML frame path, the capture path, Expo Go compatibility and the native build.
  That is a separate, approval-gated decision; it was not started.
* **No new dependency.** Everything ships on `expo-camera`,
  `@shopify/react-native-skia`, `expo-file-system` and
  `react-native-gesture-handler` — all already in the manifest, all already
  used elsewhere in the app.
* **No tap-to-focus.** `expo-camera` exposes only `autofocus: 'on' | 'off'`
  (iOS-annotated) and no focus *point*, so a tap target would be theatre.
* **No change to filters, pose maths, coaching, TTS or capture logic.**

## 6. Device-only limitations (not verified here)

No physical device or simulator ran this code. Specifically unproven:
the torch actually lighting on real hardware, the Skia offscreen re-encode
cost on low-end Android, and the fidelity of the viewfinder wash against the
final JPEG at ±3. These are hardware claims and are not claimed as verified.
