# Create-Account Auth Repair — /auth flow (audit + repair)

Session type: bug report → code audit → root cause → minimal-architecture fix.
Scope: authentication UX only. Camera / MediaPipe / coaching / TTS / reference
engine untouched.

## A. Exact root cause

`mobile/app/auth.tsx` (old) lines 50–54:

```ts
useEffect(() => {
  if (session) exitAfterSuccess();
}, [session]);
```

`useEffect` **always fires after the mount render**; the dependency array only
gates *re-runs*. The demo repository persists a session to MMKV
(`STORAGE_KEYS.demoAuthSession`, never expiring), so after ANY earlier demo
sign-in the auth store restores a non-null `session` at boot. Opening `/auth`
then ran this effect on mount and navigated back to `/(tabs)` in the first
frame — **before the signup form could ever become visible**. This is exactly
the reported chain: *existing session → /auth opens → auth screen detects
session → automatic exit → /(tabs)*. Both reported symptoms ("appears to do
nothing", "immediately transitions to the main application") are the same
one-frame-then-unmount behaviour.

Verified directly from code; no guessing. Aggravated by: demo sign-in accepts
any valid email + 8-char password and the app gates camera/favorites/stats
behind auth, so a persisted session is the COMMON state, not an edge case.

## B. Exact files involved

Changed:

- `mobile/app/auth.tsx` — now a thin route (`?mode=` deep link supported).
- `mobile/src/features/auth/presentation/screens/AuthScreen.tsx` — NEW: the
  screen (form / confirmation / already-signed-in states).
- `mobile/src/features/auth/presentation/components/AuthField.tsx` — NEW
  labeled field (icon, inline error, hint, visibility trailing).
- `mobile/src/features/auth/presentation/components/AuthModeSwitch.tsx` — NEW
  segmented Sign In / Create Account control.
- `mobile/src/shared/stores/authStore.ts` — explicit `AuthSubmitOutcome`
  ('success' | 'confirmation-required' | 'failed'), shared validators,
  `resendConfirmationEmail`, `clearLastError`; profile/favorites hydration
  unchanged.
- `mobile/src/features/auth/domain/entities/authUser.ts` — failure-code union
  now owned by `shared/auth/authFlow` (adds `email-in-use`); duplicate-email
  mapping.
- `mobile/src/features/auth/data/repositories/authRepository.ts` — demo path
  calls `demoAuthRepository.signUp`; NEW `resendSignupConfirmation` (real:
  `supabase.auth.resend({type:'signup'})`; demo: contract no-op).
- `mobile/src/features/auth/data/demo/demoAuthRepository.ts` — explicit
  `signUp` (identical demo semantics, clearer contract + log line).
- `shared/auth/authFlow.ts` — NEW, the single source of truth for entry
  resolution, exit policy, validation and outcome classification.
- `shared/content/auth.ts` — NEW, all /auth copy (app ⇄ mirror parity).
- `shared/index.ts` — barrel exports.
- `tooling/preview/…/preview-state.tsx`, `screens-intro.tsx` — mirror parity.
- `tests/auth/authFlow.test.ts` — NEW, 23 deterministic cases.

Untouched on purpose: `AuthRequiredView`, all `/auth` callers (welcome, home
hero, guest CTAs, favorite button), Google OAuth exchange, profile sync,
favorites sync, Supabase client, storage keys, gates.

## C. Why the old behavior occurred

The effect conflated TWO different events into one condition: (1) "a session
exists", and (2) "the user just completed an auth action on this screen".
Because a restored/persisted session satisfies (1) at mount, the screen
navigated away instantly — indistinguishable from "nothing happened".
Demo-mode persistence made it permanent after the first demo sign-in, so
Create Account appeared irreparably broken in day-to-day testing.

## D. Fix applied

1. **Exit policy is now total and explicit** (`shouldExitAfterSessionChange`)
   — the ONLY automatic navigation in reaction to a session change is an
   OAuth return that this screen itself initiated (no session at entry +
   session appears + oauthInitiatedHere). Exactly one combination of the
   (had-at-entry × has-now × oauth) cube navigates; a test asserts totality.
2. **Existing session at entry** → explicit "You're already signed in" state
   (Continue to the App · View Profile · demo-only *Switch test account* via
   the existing `signOut`), instead of either a silent bounce or a
   pretend-logged-out signup form. A session appearing unprompted mid-visit
   re-renders this state — never a redirect loop, never a navigation.
3. **Create Account is unmistakable**: `/auth?mode=sign-up` deep link +
   segmented control (`AuthModeSwitch`) replacing the 12px text link.
4. **Email-confirmation is a first-class state**, not a red error:
   sign-up/sign-in that returns `AuthFailure('email-not-confirmed')` resolves
   `'confirmation-required'`; the screen keeps the user in place with the
   target email, a Back-to-Sign-In CTA (email preserved) and Resend
   (repository `resendSignupConfirmation`).
5. **Signup form hardened**: visible labels, password + confirm fields with
   visibility toggles, policy hint, whole-form validation before submit
   (shared validators), live re-validation once an error is shown, email
   trimmed + lower-cased, passwords never trimmed, submission guarded against
   double-taps, return-key chain (name → email → password → confirm → go).
   Passwords are never logged (AppLogger lines carry email only).

## E. Signup fields implemented

Display name (optional) · Email · Password · Confirm password.

## F. Why each collected field exists

| Field | Why |
|---|---|
| Email | Account identity; normalized (trim + lowercase) like the rest of the architecture. |
| Password | Credential. Client policy = 8+ characters; backend rules surface verbatim. |
| Confirm password | Prevents silent password typo lockout on mobile keyboards; costs one field. |
| Display name (optional) | Personalizes greeting/profile; already consumed by `hydrateAccount → upsertProfile` and both repositories (`display_name` metadata). |

## G. Fields intentionally NOT collected

The optional "What brings you to PoseAssist?" question was **rejected**: no
existing profile schema field or feature consumes it, and collecting data
"because it might be useful someday" contradicts the brief and the project's
privacy posture. Also rejected: phone, address, location, gender, height,
weight, date of birth, profession — no implemented feature requires them.
Additional preferences stay in the existing profile/settings system.

## H. Real Supabase behavior

- `signUp` returns `user` + `session` → signed in immediately → exit to app.
- `signUp` returns `user` without `session` (email confirmation enabled) →
  the confirmation state (no navigation — there is no session to enter with).
- Duplicate email → `email-in-use` → inline form error "Sign in instead".
- Weak password per backend policy → backend message surfaced inline.
- `resend({type:'signup'})` wired for the confirmation state; OAuth PKCE
  exchange unchanged.

## I. Demo-mode behavior

Demo sign-up = create + immediate session (mirrors the demo sign-in
contract), never a fake confirmation flow. The demo PrivacyNote stays
visible. The persisted demo session no longer hijacks `/auth`: the
already-signed-in state offers a **demo-only** Switch-account reset built on
`signOut` (dev-only because `isDemoMode` implies `__DEV__`; production
without credentials fails closed and never shows it).

## J. Session/redirect behavior

- Logged-out → `/auth` stays until success or user leaves (close X / back).
- Success → exactly one navigation (`exitAfterSuccess` is single-shot).
- Already-authed → explicit state, zero redirects, zero loops.
- OAuth return initiated from the screen → single exit.
- Abandoning signup creates no partial session (repository writes only after
  a validated submit).

## K. Tests actually run

- `tests/auth/authFlow.test.ts` — 23 cases, all pass, including the mandatory
  regression: *Create Account visible + no unexpected navigation with an
  existing session* (two explicit REGRESSION cases + exit-policy totality).
- Full suite `npm test`: 477 tests, 474 pass; the 3 failures are the
  pre-existing language-default cases documented in earlier sessions
  (voice/language hardening), untouched and out of scope.
- `mobile/ npx tsc --noEmit` PASS · `verify:purity` PASS · `verify-deps` PASS
  · `verify-reference-architecture` PASS · root `tsc --noEmit` PASS (root +
  preview configs) · root `npm run build` PASS (`dist/index.html` 646 kB).
- Lint: NOT RUN — none configured (unchanged repo state).

## L. Preview result

`tooling/preview` AuthMirror rebuilt 1:1: sign-in / create-account modes,
shared validators + copy, loading, inline errors, visibility toggles,
confirmation state, already-signed-in state, and clearly-labeled *Preview
scenarios* (email-confirmation-required, backend-offline) that honestly
simulate backend behaviours the demo backend lacks. No real Supabase calls
are claimed anywhere in preview.

## M. Remaining real-device/backend validation (not claimed)

- Physical-device keyboard/scroll behavior (KeyboardAvoidingView + modal),
  screen-reader traversal order, and OAuth round-trip on device.
- Live Supabase verification of signUp/confirm/resend with a real project +
  email provider configured (env vars are not present in this environment).
