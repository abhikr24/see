# D2 — Live Preview ⇄ Captured Photo Filter Parity

Scope of this session: the **looks system only** (Original · Vivid · Warm ·
Cool · B&W, strength 0–100). Pose detection/coaching/TTS/gesture/capture
controls, crop/rotate/enhance behaviour, auth, gallery and every other
subsystem were read for the audit but **not modified**, except where a value
had to flow through them (`CameraPreview` consuming the canonical overlay).

The success criterion restated: when a user selects a look and adjusts its
strength, the live preview must be a *trustworthy* representation of the photo
that will actually be produced — without touching the real saved-photo filter
pipeline and without spending anything the pose engine needs.

---

## 1. The filter architecture found on arrival (audit, from the code)

```
FilterStrip (Original/Vivid/Warm/Cool/B&W + strength track)
        │  tap → useCameraSession.setFilter (intensity resets to 100)
        │  re-tap → strength panel; nudge/reset actions; all clamped in shared
        ▼
useCameraSession { filter, filterIntensity, filterPanelOpen }   (zustand)
        │
        ├──── LIVE PREVIEW (device) ─────────────────────────────────────┐
        │  CameraPreview.tsx                                              │
        │    filterPreviewWash(id,intensity)  → {mode,opacity}            │
        │    mode → filterWashColors token hex  → solid <View> overlay    │
        │    (HAND-AUTHORED second definition; opacity ≤ 0.22 cap)        │
        │                                                                 │
        ├──── LIVE MIRROR (web, tooling/preview only) ────────────────────┤
        │  captureColorMatrix → 20 numbers → SVG feColorMatrix on <video> │
        │  (EXACT — same numbers as capture)                              │
        │                                                                 │
        └──── CAPTURE ────────────────────────────────────────────────────┤
           takePictureAsync → applyCaptureFraming (photoBrightness.ts)    │
             decode once → Skia surface → ColorFilter.MakeMatrix(         │
               captureColorMatrix{filter,intensity,brightnessGain})       │
             + centre crop (aspect) → encode once → /camera/preview       │
             route carries uri + filterUsed/filterIntensity METADATA      │
           Gallery datasource stores metadata only (never image bytes)    │
           PhotoEditorScreen (Unit 36): rotate→crop→enhance, ONE pass;    │
             PhotoEdit = {rotation, crop, enhance} — no filter field      │
```

Facts established by the audit:

* The **saved-photo pipeline was already real**: a Rec.709-luminance recipe
  per look → 4×5 colour matrix → strength lerp-to-identity → single Skia
  pass. Five looks, IDs `original/vivid/warm/cool/bw`, strength 0–100 step 10
  default 100. No LUTs, no shaders — deliberately.
* The **live preview was a second, unmaintained filter definition**: per-look
  hex tints in a theme token (`filterWashColors`) + per-look opacity table
  (`filterPreviewWash`), chosen by eye, not derived from the matrices.
* Order of operations at capture: look → brightness (composed into one
  matrix) → centre crop, in ONE decode/draw/encode. Editor order is
  rotate → crop → colour(enhance). **Unchanged.**
* Double-application did not exist and is now *structurally* impossible to
  reintroduce silently: the editor model has no look field (asserted by a
  test); the preview route forwards `filterUsed` as display metadata only;
  `applyCaptureFraming` is the sole pixel writer of the look.

## 2. Root cause of the preview/capture mismatch

Measured on the module's calibration set (grey ramp ×3 weight + 6³ RGB cube
+ 8 photographic anchors ×2), the hand-tuned veils — composited as
`out=(1−α)x+αc` — versus the matrices they claimed to preview:

| look @100% | old direction agreement¹ | old magnitude vs true | verdict |
|---|---|---|---|
| vivid | **−0.22 (wrong way)** | 1.10× | veil lightens/fades; capture deepens/saturates |
| warm  | 0.19 | **2.83× too strong** | preview screamed, capture whispered |
| cool  | 0.30 | **2.98× too strong** | same |
| bw    | 0.47 | 0.29× | faint grey hint (fine-ish) but hand-picked |

¹ cosine between Δlook and Δoverlay over the calibration set.

So the mismatch was not "GPU vs CPU" — it was **two unrelated parameter sets
that nothing kept in step** (D2 §1/§4 failure mode, verbatim).

## 3. Method research — what the live renderer can lawfully be (D2 §8)

Stack: Expo SDK 57 · expo-camera ~57.0.5 · RN 0.86.3 · Skia 2.6.2.

| option | finding | verdict |
|---|---|---|
| expo-camera frame access | no frame processor/GL binding in SDK 57 (confirmed against current docs + installed type surface) | impossible on this foundation |
| react-native-vision-camera + Skia frame processor | real GPU path, but: different native build, second camera library, replaces the Unit 12 session model (JIT mount, single active session), and the project's own camera docs already rejected the swap; A1 native-frame work is planned separately | **rejected** (would block A1, violates "don't adopt theory over fit") |
| RN `mixBlendMode` overlay (0.77+, New Arch, Android 10+) | blends within the app layer; Android camera preview is a CameraX `SurfaceView` composited by SurfaceFlinger in a separate layer the blend cannot read → platform-split behaviour; a full-screen offscreen blend pass every frame also competes with the pose engine | **rejected** |
| still-capture → JPEG → process → display loop | forbidden (D2 §10) — and is exactly the ML-sampling path's cost profile | **rejected** |
| Skia backdrop/color-filter over native view | Skia canvases are separate layers; a color filter cannot reach the pixels of the view beneath | impossible |
| **constrained LS projection onto the alpha-composite model** | the ONE operation available over the native preview, derived from the canonical matrix, zero per-frame cost | **adopted** |

## 4. The canonical architecture now

```
                    shared/camera/cameraFilters (ONE source of truth)
   FilterRecipe {saturation, contrast, temperature, desaturateToLuma}
                    │            filterColorMatrix(id, strength)
                    │                    │
        capture mapping                preview mapping
   captureColorMatrix(∘brightness)  filterPreviewOverlay(id, strength)
        │                                  constrained LS projection onto
        ▼                                  out=(1−α)x+αc, α≤0.22 cap
   Skia ColorFilter (applyCaptureFraming)   │
        │                                   ▼
        ▼                            solid-color <View> over CameraView
   saved JPEG                      (memoised per (id, intensity))

   lookDefinition(id) / LOOK_DEFINITIONS publish both mappings + strength
   contract side by side so "does preview match capture?" is answered by
   data. There is deliberately no second parameter table anywhere.
```

**Projection.** For each (look, strength) the canonical matrix is computed
first (this includes the strength lerp — the *same* numbers the capture
bakes), then projected: minimise the weighted squared error over the fixed
calibration set subject to `α ∈ [0, 0.22]`, offset `o_c ∈ [0, α]`. The fit is
a 1-D grid search in α (closed-form offset per step via preweighted
aggregates) — deterministic, total, ~45 µs. The cap is unchanged:
coaching readability outranks every creative effect, always.

**Fidelity is now measured, not declared.**
`viewfinderFidelity` derives from the full-strength fit:

| look | direction | magnitude ratio | fidelity now | strip copy |
|---|---|---|---|---|
| original | — | — | exact | (none) |
| warm | 0.37 | 0.46 | tinted | "Preview is approximate" |
| cool | 0.52 | 0.62 | tinted | "Preview is approximate" |
| bw | 0.59 | 0.30 → faint grey hint drawn | not-representable | "Shown after the shot" |
| vivid | 0.00 (provably nothing lawful to show) | 0.00 | not-representable | "Shown after the shot" |

Vivid's transform is cross-channel with positive gain — orthogonal to the
overlay class — so the *optimal* overlay is exactly nothing, and the UI says
so instead of showing a veil that measured as actively misleading (−0.22).
B&W's fitted grey veil is drawn as the closest lawful hint while the copy
stays conservative, because no overlay can remove colour.

Fidelity thresholds (`PREVIEW_TINTED_MIN_*`) were locked **after** measuring
the fits; both the thresholds and the shipped fits are pinned by regression
tests, so a recipe change visibly moves the numbers in CI instead of silently
drifting.

**Strength semantics.** One curve: `filterStrength` → `lerpToIdentity` →
matrix → (capture | projection). 0% is provably neutral on both sides
(identity matrix; zero-opacity overlay); intermediate steps are the same
intermediate matrices on both sides. Monotonicity of preview opacity is
asserted for every representable look across all 11 steps; B&W pins at the
coaching cap from 40% upward, which is the documented purpose of the cap.

**Original.** Exact no-op on both sides, at every strength: identity matrix,
zero-opacity overlay, fidelity `exact`. It is the reference baseline.

## 5. What "match" means here, and its hard limits (D2 §6/§16–§18)

Evaluated per look: brightness/contrast/saturation/temperature/hue/grayscale
behaviour/strength — through the parity metrics the module now publishes
(`directionAgreement`, `magnitudeRatio`, `mean/maxResidual`). Achieved vs.
impossible on this foundation:

* ACHIEVED: single definition ownership; strength parity; honest, measured,
  right-direction previews for warm/cool; wrong-direction vivid veil removed;
  B&W hint + honesty copy; cap preserved.
* IMPOSSIBLE (documented, not smoothed over): pixel-level live colour
  management of a native camera surface — desaturation (B&W) and saturation
  lift (Vivid) have no lawful overlay. These looks communicate through the
  strip swatch (each swatch renders that look's own matrix on a fixed neutral
  pair) plus the "shown after the shot" note.
* HARDWARE BOUND: the preview path (CameraX SurfaceView / AVCaptureVideoPreviewLayer)
  and the JPEG pipeline take different ISP paths (tone mapping, sharpening,
  noise reduction, WB convergence, HDR); even a perfect renderer could not
  guarantee pixel parity between viewfinder photons and the encoded file.
  The matrices operate in the sRGB-ish space JPEGs carry; wide-gamut/HDR
  displays may render the same JPEG differently than the preview signal.
* RESOLUTION: the transform is per-pixel linear and resolution-independent;
  nothing is tuned to a preview resolution.

## 6. Interaction with crop/rotate/enhance, switching, sessions

* Capture pipeline order unchanged: look∘brightness matrix → centre crop — one
  pass. Editor order unchanged: rotate → crop → enhance — one pass.
* The editor still cannot express a look; the neutral-edit identity is
  test-pinned. A filtered photo enters the editor already-filtered; editing
  composes enhance adjustments only. No double application, structurally.
* `switchCamera` keeps `{filter, filterIntensity}` (Unit 12 store behaviour);
  the overlay is a pure function of that state, so front↔rear reattachment
  is a style change, not a camera interaction. No flicker surface added.
* Rapid look switching mutates store state only; the overlay recomputes one
  45 µs fit per change, memoised. No camera restart, no frame work.

## 7. Performance (measured on this machine; Node 20, CI sandbox)

| measurement | value |
|---|---|
| full 5 looks × 11 strengths (55 fits) | **2.53 ms** total, one time |
| steady-state single fit (a strength-step change) | **45.42 µs** |
| memoised per-frame cost (as CameraPreview consumes it) | **0.031 µs** |

Live rendering cost per frame = ONE solid-colour `<View>` (a single
GPU-composited quad) + a style lookup. No JS work per frame, no camera
frames touched, nothing allocated on the pose path. Battery/thermal
contribution is that of one extra composited layer — the same class as the
long-shipped brightness scrim.

## 8. Files changed

* `shared/camera/cameraFilters.ts` — viewfinder section replaced by the
  projection (calibration set, solver, `filterPreviewOverlay`,
  `projectMatrixToOverlay`, measured `viewfinderFidelity`,
  `PREVIEW_TINTED_*` thresholds); `lookDefinition`/`LOOK_DEFINITIONS`
  canonical API; `filterPreviewWash` removed; header documents D2.
* `shared/theme/colors.ts` — `filterWashColors` token removed (its single
  consumer migrated; the file now documents why no token may return).
* `mobile/src/features/camera/presentation/components/CameraPreview.tsx` —
  renders the canonical overlay (memoised); header records the research and
  the measured reasons.
* `mobile/src/features/camera/presentation/components/FilterStrip.tsx` —
  honesty-line comment now states the measured-fidelity rule (UI untouched).
* `tests/camera/cameraFilters.test.ts` — 3 wash tests migrated to the
  projection semantics; +11 tests: canonical definitions, same-matrix
  derivation, shared strength curve, Original neutrality, fitted-vs-old-veil
  regression evidence, parity envelopes, warm/cool direction, editor-model
  structural guard, capture-once composition.

## 9. Verification results

| check | result |
|---|---|
| root `npm test` (node --test, 488 tests) | **485 pass / 3 fail — the 3 are pre-existing voice-locale failures** (`tests/coaching/hardening`, `tests/voice/languageIntegration`), identical count & identity before any D2 change; TTS/language is out of scope (D2 §30) |
| `mobile/scripts/verify-deps.mjs` | PASS |
| `mobile/scripts/verify-purity.mjs` | PASS |
| `mobile/scripts/verify-reference-architecture.mjs` | PASS |
| `mobile` `tsc --noEmit` | PASS |
| root `tsc --noEmit` (shared + tooling) | PASS |
| root `npm run build` (preview mirror, vite) | PASS |
| `expo export --platform web` | FAILS at static rendering of `app/gallery/photo/[id].tsx` ("Class extends value undefined…") — **identical failure on the pristine restored archive** (see `/tmp/expo-export-pristine.log` during session); pre-existing, unrelated to filters — production device builds (`eas`, Unit 24) unaffected; flagged for a future mainline fix |

Status labels per the task's categories:

* IMPLEMENTED: canonical definitions, projection, measured fidelity, tests,
  docs, double-application guards, strength parity.
* LOCALLY TESTED: everything in the table above (this sandbox).
* PREVIEW VERIFIED: tooling mirror builds & consumes the same 20 numbers;
  device overlay parameters snapshot-tested.
* PERFORMANCE VERIFIED: measured on this machine (§7); device-side rendering
  cost is one composited quad by construction — no FPS measurement claimed.
* VISUAL/DEVICE VERIFIED: **NOT VERIFIED** — no physical device in this
  environment. Warm/cool/overlay visibility, B&W hint subtlety and ISP-path
  differences must be eyeballed on hardware before release; the parity
  metrics are the deterministic stand-in until then.

## 10. Physical / visual verification protocol (for a device session)

1. Rear camera, no pose: select Warm at 60% — preview should warm subtly;
   capture; confirm saved photo direction/depth matches preview character.
2. Repeat Cool; confirm opposite tilt. 3. B&W 100%: preview stays colour
   (faint grey hint) + "Shown after the shot"; saved photo true neutral grey.
4. Vivid 100%: preview clean (no veil) + same note; saved photo visibly
   punchier. 5. Strength sweep 0→100 on Warm: preview grows monotonically.
6. Original at every strength: preview untouched. 7. Front↔rear flips with a
   look active: no flicker, look persists. 8. Rapid strip sweeps during pose
   guidance: coaching stays readable (cap). 9. Edit a filtered photo:
   rotate/crop/enhance apply, look neither lost nor doubled.

## 11. Known limitations (honest list)

* Vivid and B&W have *no lawful live representation* on expo-camera; they are
  declared via measured fidelity + strip copy. This is a foundation
  constraint, removable only by the planned A1 native-frame work — which this
  design does not obstruct (nothing here touches frames).
* B&W strength beyond ~40% cannot be previewed (coaching cap pins α at 0.22);
  capture honours the full curve.
* The fitted warm/cool veils show ≈0.5–0.6 of the true magnitude (class
  limit), right direction, measured.
* ISP/WB/HDR path differences between preview and JPEG are hardware-owned
  (§5), out of software control.
