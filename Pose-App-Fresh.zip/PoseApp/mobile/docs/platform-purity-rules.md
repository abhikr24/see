# Platform Purity Rules — mobile/ is React Native + Expo ONLY

This project ships to **iOS, Android and Web from one codebase** via React
Native + Expo SDK 52. A browser can render web-only elements; a phone's JS
engine cannot. Code that "looks done" in a browser preview can still crash
on a real device. These rules exist so that never happens.

## The rules (machine-enforced)

Every file under `mobile/app/` and `mobile/src/` must comply:

1. **Zero raw HTML elements** — no `<div>`, `<span>`, `<p>`, `<h1>…`,
   `<button>`, `<img>`, `<input>`, `<a>` etc. Use RN primitives:
   `View`, `Text`, `Pressable`, `Image`, `TextInput` from `react-native`.
2. **Zero web styling** — no `className=`, no `.css` imports, no inline
   `<link>`/`<style>`. Styling is `StyleSheet.create()` + theme tokens.
3. **Zero unguarded browser APIs** — no `window.`, `document.`,
   `localStorage`, `sessionStorage`, `navigator.mediaDevices`. If a web
   behavior is truly needed (it almost never is), it must sit behind a
   `Platform.OS === 'web'` guard that the native engine never evaluates.
4. **Zero web-framework imports** — no `next`, `next/router`, `next/link`,
   `react-router-dom`, `react-dom`. Routing is Expo Router (`app/` folder).
   Rendering is `react-native`.
5. **The preview mirror is not the app** — the repo-root `src/` (web preview
   tooling) is the ONLY place web code may exist. Metro watches `mobile/`
   and `shared/` only, so preview code is physically outside the app bundle.
   It is never imported by app code.

## Enforcement

```bash
cd mobile && npm run verify:purity
```

`scripts/verify-purity.mjs` exits non-zero on any violation and prints
`file:line` plus the correct replacement. Run it before every commit and at
the end of every build unit.

### What it scans

| Tree | Rules applied |
|---|---|
| `mobile/app`, `mobile/src` | All 7 native rules below |
| `shared/` | HTML elements, DOM render APIs, browser globals, **plus** a ban on `react-native` / `expo` / web-framework imports (shared must stay platform-neutral for both consumers) |

### The 7 native rules

1. **HTML element** — any lowercase DOM tag → use `View`/`Text`/`Pressable`/`Image`.
2. **Web styling** — `className=`, `style="string"`, `.css/.scss` imports → `StyleSheet.create()` + tokens.
3. **DOM event handler prop** — `onClick`, `onMouseDown`, `onSubmit`, `onKeyDown`, `onWheel`, `onDrop`… → `onPress`/`onChangeText`.
   *Deliberately allowed:* `onFocus`, `onBlur`, `onKeyPress`, `onSubmitEditing` — these are real React Native `TextInput`/`Pressable` props.
4. **DOM render / react-dom API** — `ReactDOM`, `createRoot`, `hydrateRoot`, `createPortal`, `flushSync`, `dangerouslySetInnerHTML`.
5. **Browser global / storage API** — `window.`, `document.`, `localStorage`, `sessionStorage`, `navigator.mediaDevices|clipboard|geolocation|userAgent`, and bare `alert()`/`confirm()`/`prompt()`.
   *Deliberately allowed:* React Native's `Alert.alert()` (negative lookbehind).
6. **Web framework import** — `next`, `react-router(-dom)`, `react-dom`, `vite`, `lucide-react`, `clsx`, `tailwind-merge`.
7. **Hardcoded color literal** — `'#RRGGBB'` or `rgba(...)` → `theme.colors.*` / `mediaColors.*`.
   *Sole exemption:* `shared/theme/colors.ts`, the token source itself.

Comments are blanked before scanning (line numbers preserved), so these rules
can be documented in prose without tripping the scanner.

## When unsure

Writing a UI element and torn between an HTML tag and an RN component?
**Always choose the React Native component.** There is no valid reason for
a raw HTML element to exist anywhere inside `mobile/`.
