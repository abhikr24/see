# Progress Tracker — Smart Photography Assistant

> Living document. Updated immediately after every unit (`.cursorrules` §5).
> Never delete history.

## Current Phase
**Final integration COMPLETE — ZIP 9 + PATCH-02 + PATCH-04 merged and validated;
APK build not executed in this environment (no EAS credentials / no local
JDK+Android SDK). See "Final integration session" at the end of this file.**

## Completed

| Unit | Title | Key ships |
|---|---|---|
| 01 | Project setup & design tokens | Expo SDK 52 scaffold, `shared/theme` tokens, theme store (L/D/System), MMKV storage adapter, AppLogger |
| 02 | App shell & bottom navigation | 5-tab Expo Router shell, custom AppTabBar (radius 20, elevation), placeholders, per-tab state |
| 03 | Splash, welcome & onboarding | Cold-start flow, 3-slide pager, dots indicator, first-launch MMKV flags |
| 04 | Permissions flow | Camera + gallery cards, grant/deny/forever states, Open Settings recovery, no notification requests |
| 05 | Pose library local data layer | `shared/data/poseCatalog` (400 poses, 12 categories, bundled/offline), recents + search-history LRU stores |
| 06 | Auth & Supabase (demo-first) | `.env` single source of truth, demo backend when unset, guest = browse-only invariant, session persistence |
| 07 | Home dashboard | Greeting + hero (Start Camera / Continue last), recents shelf from LRU 4, quick nav |
| 08 | Explore — search, collections & pose grid | Ranked search + history LRU 10, featured carousel, 12 collections, 2-col grid, quick-view sheet |
| 09 | Search & smart filters | Dedicated search route, ranked query, category/difficulty filters, LRU history |
| 10 | Pose detail, related poses & deep links | Canonical /pose/[id] route, deterministic related engine, deep-link handoffs |
| 11 | Favorites: local replica, secure sync & auth prompts | Account-scoped replica, durable queue, RLS backend, guest gating |
| 12 | Camera foundation — preview & controls | JIT preview, State 1/2, controls, permission and lifecycle recovery |
| 13 | Capture + Processing + Preview + Save (Device Only) | Shutter capture, haptic countdown, processing, preview, device save |
| 14 | Gallery Tab Complete | Grouped photo grid, pose history, full preview, delete/share/retake |
| 15 | Pose History & Recents Wiring | lastUsed datasource (20 max), quick reuse across Home/Camera/Gallery |
| 16 | MediaPipe Core + Overlay + Match % | 33 LM on-device, Skia Canvas skeleton overlay, match % calculation, 15fps ML / 60fps UI |
| 17 | Pose Comparison & Visual Guidance | Worst-joint directives, hints, Skia arrows, color-coded joints/bones |
| 18 | Intelligent Capture Suite | Voice guidance, 2s auto-match hold, open-palm capture, global trigger gate |
| 19 | Profile Tab | Avatar, 3-col stats, favorites grid, storage management, edit name, guest CTA |
| 20 | Settings — Camera & Capture Prefs | Camera defaults (flash/timer/filter/grid), intelligent capture prefs |
| 21 | Settings — System | Theme picker, language, privacy, terms, about & clear-all-data |
| 22 | Global Error Handling | Typed AppErrors, retry UI, offline banner, crash boundaries, stack logging |
| 23 | UI States System | Shimmer skeletons (all grids/lists), canonical EmptyStateWidget (5 variants), global snackbar |
| 24 | **Performance, Polish & Final Verification** | Lazy loading pagination (20/page, 30/page), memory optimization, EAS build profiles, app icon & splash |
| 25 | **Silhouette Guide replaces skeleton overlay** | Camera guide is now a soft ghost silhouette (capsule-fused, blurred, boundary glow in the match-% ramp); joint dots/bones no longer rendered; detection, angles, match %, guidance arrows & pill unchanged; `shared/ml/poseSilhouette` two-tier resolver (generic 6-shape library today → auto custom trace when `Pose.referenceLandmarks` lands); web mirror parity |
| 26 | **Hollow luminous vector contour replaces filled ghost** | Guide is now a 100%-transparent-body contour: exact outer boundary (marching-squares + Chaikin in `outlineSilhouette`) stroked 2.5px round + 8/4 dash + 5px Gaussian halo; iOS-cam match ramp (<40 crimson .4 / 40–70 amber .6 / 70–85 blue .8 / >85 emerald 1.0 + breathing pulse, Reduce-Motion pinned); both resolver tiers flow through one path; Unit 17 arrow preserved; web mirror parity |
| 27 | **Human-like voice guidance — phrase bank + native neural voice** | Coach speaks varied instructor cues instead of one fixed English line: `shared/constants/poseInstructions.ts` (17 categories × 8 variations × Hindi-Hinglish + English, `getRandomInstruction` never repeats a line back-to-back); `GuidanceResult.voiceCategory` maps every joint directive (additive, UI copy untouched); `ttsService.speakInstruction` + capture cue (`photo_clicking`, force through the 3s gate); best built-in voice per language via `getAvailableVoicesAsync` (hi-IN → hi, en-IN → en-US chain; Enhanced/Premium/neural + on-device scoring, cached, engine-default fallback); rate 0.98 / pitch 1.0; `voiceLanguage` persisted setting + Settings→Language radio modal (English / हिंदी); no new dependencies |
| 30 | **Semantic coaching boundary — analysis ⇄ speech** | `shared/coaching/` introduces THE semantic state between math and language (`CoachingState`: kind · token · category · measurement · direction · severity · intensity · confidence · stableFrames · unavailableReason · speakable) via `decisionToCoachingState`; severity now reaches phrase selection (`intensityForSeverity`, gentle vs firm pools — 5 curated firm variations per reachable category in hi + en, `getInstruction(category, language, {intensity, random})`); `createCoachingSpeechPlanner` owns cadence (new state ≥900ms, same correction every 4.5s, PERFECT once per episode, non-speakable states clear memory → instant recovery) while hysteresis stays in the engine; `ttsService.speakCoaching` is speech-only (no geometry, no severity math, no Supabase); unavailable/evaluating can never become a correction; `CATEGORY_COVERAGE` traces all 17 categories (10 reachable / 7 reserved-no-measurement); preview mirror runs the same shared layer; UI (`decisionToGuidance`) untouched |
| 36 | Post-capture editing (crop · rotate · enhance) | Shared editing brain, one-pass Skia renderer, editor screen with crop handles/rotate/enhance, saved-photo file swap, temp-file sweeper, 22 new tests |
| D2 | **Live-preview ⇄ capture filter parity (canonical look definitions)** | The viewfinder approximation was a second, unmaintained filter definition (theme-token tints + hand table) that measured ~3× too strong for warm/cool and pointed the WRONG WAY for vivid (direction agreement −0.22). It is now a constrained least-squares PROJECTION of the canonical look matrix (`filterPreviewOverlay`, `projectMatrixToOverlay`) onto the only lawful operation over a native camera surface (`out=(1−α)x+αc`, α≤0.22 coaching cap preserved); `lookDefinition`/`LOOK_DEFINITIONS` publish capture mapping + preview mapping + strength contract from ONE recipe; `viewfinderFidelity` is measured (warm/cool tinted; vivid+bw honestly "shown after the shot"); `filterWashColors`/`filterPreviewWash` deleted; CameraPreview renders the memoised canonical overlay; capture pipeline, crop/rotate/enhance and all UI untouched; 11 new tests (canonical, strength-shared, fitted-beats-old-veil regression, parity envelopes, editor structural guard); full record in docs/d2-filter-parity.md |
| 37r | **Language-fallback contract finalized (Unit 37 repair)** | Three failings + one hidden divergence traced to ONE root: after Unit 37 made unreadable languages degrade to the default (Hindi), three stale expectations still pinned literal English, and the raw phrase pool (`bankFor ?? EN_INSTRUCTIONS`) still degraded to English while every other layer resolved Hindi. Final contract, now pinned by `tests/voice/languageContract.test.ts`: **A.** fresh install = Hindi; **B.** explicit selection honoured — including legacy spellings (`english`/`hindi`/`hinglish`/`en-IN`/`eng`) via the new `normalizeInstructionLanguage` recognizer; **C.** unreadable/corrupted (`undefined`, `null`, `""`, `fr`, `kl-KL`, `7`, …) = behaves as no-preference = canonical default — ONE deliberate fallback (`UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK`), ONE gate (`resolveInstructionLanguage`), consumed identically by routing, phrase pool, locale tables, voice selection, visible coaching, TTS, preview and the settings migration (which now recognizes legacy spellings under both keys instead of treating them as absent). No test deleted; stale literals re-pointed at the canonical constant. Verified: root `npm test` 483/483, root + mobile `tsc --noEmit`, purity, deps + reference-architecture checks; NOT verified: on-device voice output (unchanged release blocker) |

## D2 session notes — filter parity

- Why: D2's core defect was ownership, not math: live preview and capture kept
  separate parameter sets. Now the preview DERIVES from the capture numbers by
  construction (projection), so drift is impossible by design.
- Method research (recorded in the doc): expo-camera ~57 has no frame pipeline;
  VisionCamera = second camera foundation (rejected, keeps A1 unblocked);
  `mixBlendMode` can't reach the SurfaceFlinger camera layer on Android and
  would cost a per-frame blend pass (rejected); JPEG loops forbidden. The
  alpha-composite overlay is the only lawful operation — so it is modelled
  exactly and fitted optimally.
- Vivid's optimal overlay is provably "nothing" (cross-channel + positive gain
  sits outside the model class); honesty copy now covers it. B&W keeps its
  fitted grey hint + "shown after the shot".
- Verified this session: root `npm test` 485/488 (3 fails are the pre-existing
  voice-locale ones, identical before/after), verify-deps + purity +
  reference-architecture PASS, mobile tsc PASS, root tsc PASS, preview vite
  build PASS. `expo export --platform web` static-render failure reproduced on
  the PRISTINE archive — pre-existing, unrelated. Perf measured: 45 µs/fit,
  0.03 µs/frame memoised, one composited quad live. NOT device-verified (no
  hardware here); visual protocol in docs/d2-filter-parity.md §10.

## Unit 37-repair session notes — one language gate, one deliberate fallback

- Why: three failing tests (locale tables, voice selection, routing) plus a
  hidden fourth divergence. Audit BY TRACING, not by docs: Unit 37 had made
  `resolveInstructionLanguage` degrade unreadable values to the DEFAULT
  (Hindi — "an unreadable preference behaves exactly like a fresh install"),
  and had already updated `voiceSelection.test.ts`, `cameraUx.test.ts` and
  the phrase-selection hardening test to that contract. But three spots kept
  literal-English expectations from Units 35/36, and — the real defect —
  `resolveInstructionPool`/`bankFor` in `shared/constants/poseInstructions.ts`
  still fell back to the English bank (`?? EN_INSTRUCTIONS`), so a corrupted
  preference fed Hindi phrases to routing/locale/voice but English phrases
  through the raw pool API. The fallback was being decided by whichever
  helper ran first.
- Verdict per failure: C1/C2/C3 = tests encoding the obsolete pre-Unit-37
  contract (not weakened — re-pointed at `DEFAULT_INSTRUCTION_LANGUAGE` so
  they pin the canonical rule instead of a literal); PLUS an implementation
  pocket (pool layer) genuinely diverging — removed.
- Contract (now pinned in `tests/voice/languageContract.test.ts`):
  A · fresh install = Hindi (`DEFAULT_INSTRUCTION_LANGUAGE`, unchanged,
  still locked by `voiceSelection.test.ts`);
  B · explicit selection honoured — added the `normalizeInstructionLanguage`
  recognizer: case-insensitive codes, locale tags (`en-IN`, `en_US`,
  `hin-IND`), ISO-3 (`eng`/`hin`) and legacy labels (`english`→en,
  `hindi`→hi, `hinglish`→hi) so old stores keep the user's real choice;
  C · unreadable/corrupted (`undefined`/`null`/`""`/non-string/`fr`/
  `kl-KL`/…) → `UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK` (named constant =
  the canonical default today) — ONE gate, consumed identically by routing,
  phrase pool, locale tables, voice ranking/selection, visible coaching
  (`visibleCoachingFor`/`cameraStatusCopyFor`), TTS, preview mirror and the
  settings migration.
- Migration: `settingsMigration.resolvePersistedInstructionLanguage` now
  recognizes legacy spellings under BOTH keys through the same normalizer
  (precedence instructionLanguage → voiceLanguage → default unchanged);
  `voiceLanguage` key still dropped AFTER carrying its meaning forward;
  unrelated keys untouched.
- Severity/coaching category, MediaPipe math, guidance generator, capture,
  auth, filters: untouched. `ttsService` call pattern unchanged (it already
  resolved through the gate, per the architecture tests).
- Not changed on purpose: no claim that any device owns a Hindi voice —
  ranking still consumes only the runtime catalog, engine-default fallback
  stays honest (`voiceId: null` when the resolved language has no installed
  voice). On-device speech output remains the standing release blocker.

## Unit 30 session notes — deterministic coaching connected to TTS

- Why: Unit 29 shipped a real semantic decision and Unit 27 shipped a phrase
  bank, but the two met through `GuidanceResult` — a UI object. Consequences
  found by audit (not assumed): (a) the analysis engine produced severity and
  the TTS API had no severity parameter, so intensity could never differ;
  (b) speech cadence was a fixed 3s interval + duplicate-text check inside the
  TTS, so a NEW correction waited up to 3s while PERFECT re-fired every 3s with
  a fresh random line ("perfect… perfect… perfect"); (c) the screen decided
  when the coach talked.
- Added `shared/coaching/` (types, coachingState, categories, phraseSelection,
  speechPlanner, index) — pure, platform-neutral, zero RN/DOM/Supabase/TTS.
  `decisionToCoachingState` translates only; it re-decides nothing.
- Severity → intensity mapped ONCE (`major → firm`, else `gentle`) and carried
  to the bank. `instructionPool`/`getInstruction` add the firm tier;
  `getRandomInstruction` preserved as the gentle alias (Unit 27 callers safe).
  Hindi/Hinglish fillers (bas / haan / hmm / theek hai) preserved and extended.
- Cadence moved out of the TTS into the injected-clock planner; speech state
  (`speaking`) is tracked from the utterance callbacks so only a state change
  may interrupt. Capture cue (`photo_clicking`, force) unchanged.
- Unavailable handling made explicit rather than accidental: non-speakable
  states carry `category: null` / `speakable: false`, phrase selection returns
  null, planner returns `not-speakable` and clears cadence memory so a real
  state after recovery is not delayed by a stale interval.
- Voice discovery/persistence deliberately NOT rewritten: catalog caching,
  hi-IN → hi and en-IN → en-US → en chains, enhanced/neural + on-device
  scoring and the engine-default fallback are preserved verbatim. No device
  voice is claimed; the only new prosody is rate 1.04 for firm cues.
- Category trace is computed from `JOINT_GUIDANCE_RULES` + `MATCH_JOINTS`
  (cannot go stale) and asserted by tests: 8 reachable correction categories,
  `final_pose_good` (perfect), `photo_clicking` (capture), and 7
  head/neck/torso categories marked `reserved-no-measurement` — retained for
  the planned measurement set, NOT described as working coaching.
- Preview mirror (`tooling/preview`) now drives its browser TTS from the same
  shared planner + selector; the old inline text-change/3s gate was removed.
- Verified this session: root `npm test` 164/164 PASS (new
  `tests/coaching/coaching.test.ts`), `mobile/scripts/verify-all.mjs` PASS
  (deps + purity + `tsc --noEmit` on SDK 57 / TS 6), root `tsc --noEmit`
  clean, preview `npm run build` emits dist/index.html. Import audit: analysis
  imports no TTS/Supabase; ttsService imports only expo-speech + shared
  coaching + logger. NOT verified: on-device Android/iOS speech output (no
  device/emulator here) — unchanged release blocker.

## Unit 25 session notes

- Why: joint-and-bone rendering read as a fitness tracker, not a photography
  app. The visible skeleton is removed from the camera feed; a translucent
  target-pose "ghost" replaces it as the alignment guide.
- New files: `shared/ml/poseSilhouette.ts` (unit-box capsule geometry,
  6-shape generic library, custom `capsulesFromLandmarks` trace, viewport
  fitter), `mobile/src/features/camera/presentation/components/PoseSilhouetteOverlay.tsx`.
- Touched: `CameraTab.tsx` (overlay swap; joint/bone color mapping removed),
  `src/preview/screens-tabs.tsx` (mirror draw loop parity), `shared/types`
  (`Pose.referenceLandmarks?` — future Template Scanner hook), `shared/index.ts`.
- Untouched on purpose: MediaPipe detection, `poseMatch`/`guidanceGenerator`
  maths, match-% smoothing (EMA 0.35), auto-capture gates, GuidanceOverlay
  pill, directional arrow on the worst joint. `PoseSkeletonOverlay.tsx` and
  both `jointColorMapper` modules remain on disk but are no longer rendered.
- Shape routing: tags (`seated`→sitting, `lying`→lying), then category
  (couples/wedding→couple, family/group→group), `colorSeed` alternates
  frontal/turned variants and mirroring — fully deterministic, no randomness.
- Verified this unit: verify-all (deps + purity + tsc), web preview build,
  node smoke tests over all 400 poses (determinism, routing, custom upgrade,
  viewport bounds). NOT verified: on-device Expo runtime (no device/emulator
  in this environment) — guide tuning of blur/opacity constants is visual and
  should be eyeballed on a physical device next session.

## Unit 27 session notes

- Why: Unit 18 spoke one fixed English headline per joint (`en-US`, rate 0.5,
  default OS voice) — robotic, repetitive, and unusable for Hindi. Unit 27
  makes the coach sound like a real studio instructor while staying on plain
  OS-native TTS (no AI/cloud, no new package).
- Phrase bank (`shared/constants/poseInstructions.ts`): 17 categories × 8
  variations in Hindi/Hinglish and English; `getRandomInstruction` keeps a
  per-(language, category) last-phrase map so consecutive corrections never
  repeat. Commas and "…" in the copy are the micro-pauses the utterance
  engine renders. Runtime-tested: no-repeat + non-empty across all 34 cells.
- Category mapping is additive: `GuidanceResult.voiceCategory` joins the
  existing text/hint/arrow fields, so the Unit 17 on-screen guidance UI is
  byte-identical. CameraTab now feeds `speakInstruction(voiceCategory,
  voiceLanguage)`; `beginIntelligentCapture` announces the shot via
  `photo_clicking` with `force` (the stop-then-announce flow already existed
  there — it would otherwise swallow the cue at the 3s gate).
- Voice quality: `Speech.getAvailableVoicesAsync()` cached once; candidates
  are filtered by locale priority (hi-IN→hi / en-IN→en-US→en), excluded when
  not installed, scored +2 for enhanced/premium/neural/siri markers and +1
  for on-device (`networkConnectionRequired === false` — widened structural
  type; expo-speech 12 typings omit both runtime fields). No match falls
  back to the engine default for the locale. Speak params: rate 0.98,
  pitch 1.0, volume 1. `warmup()` pre-warms the catalog on camera focus.
- Language switching: `voiceLanguage: 'en' | 'hi'` added to
  `CameraSettings`/defaults (default 'en' — the V1 UI is English-only), MMKV
  persisted via the Unit 20 store (zustand persist merges the new key from
  defaults on rehydrate). Settings → Language tile now opens the existing
  `SettingsRadioModal` (English / हिंदी (Hinglish)); description clarifies it
  governs voice guidance.
- The 300–500ms "between instructions" spec rides the preserved Unit 18
  3-second `voiceDebounceMs` anti-spam invariant — deliberately not reduced;
  per-utterance rhythm (commas/ellipses) carries the 300–500ms breath.
- look_*/chin_*/shoulder_straight/back_straight bank entries are authored
  and reserved for a future head-pose ML pass (engine maps hips/knees/
  shoulders/elbows today); `resetInstructionMemory()` runs on session reset.
- Verified this unit: verify-all (deps + purity + root tsc), mobile tsc,
  web preview build, phrase-bank runtime no-repeat test.

## Unit 26 session notes

- Why: the Unit 25 translucent ghost filled the subject area with a painted
  body; on a camera feed that reads as obstruction, not guidance. The guide
  is now boundary-only — Huawei/Leica-style framing assist.
- Geometry: `outlineSilhouette()` in `shared/ml/poseSilhouette.ts` — marching
  squares (asymptotic saddle decider, canonical-edge chaining, zero-sample
  nudge for determinism) over the capsule-union signed field, then two
  Chaikin passes. Exact ring of the same shape Unit 25 blurred; disconnected
  figures (group) yield disjoint rings and true interior gaps (couple arm
  gaps) yield hole rings — all correct for stroke-only rendering, and both
  resolver tiers (generic library + custom-scanned landmarks, the on-disk
  names for the spec's "fallback SVG" / "has_custom_silhouette") run through
  the identical path, preserving the zero-branch guarantee.
- Style source: new `SILHOUETTE_CONTOUR_BANDS` + `silhouetteContourStyle()`
  in `shared/theme/colors.ts` (the only legal hex home). It coexists with —
  and does not replace — the locked `MATCH_COLOR_BANDS` that own the match-%
  pill; the contour intentionally treats ≥85% as locked per this spec while
  the pill's emerald band still starts at 90.
- Renderers: mobile Skia = halo Path (6px round stroke under BlurMask σ5) +
  crisp Path (2.5px round, DashPathEffect 8/4) in one Group whose opacity a
  Reanimated shared value breathes (period 1600ms, floor ×0.72) only in the
  locked band and not under Reduce Motion; `paths`/`contour` are memoized per
  pose+layout. Web mirror = Path2D cached per size key, shadowBlur halo +
  dashed crisp stroke, identical pulse math in the 60fps canvas loop.
- Purity gate note: Skia's `BlurMask style` uses a bound const (`'normal' as
  const`) — the `style="..."` string-attribute form trips the web-styling
  regex by design.
- Verified this unit: verify-all (deps + purity + tsc), root tsc, web
  preview build, node smoke tests over all 400 poses re-run (loop sanity,
  determinism, bounds, custom-tier trace, exact circle radius control), CPU
  raster render reviewed (clean humanoid rings). Extraction ≈1.1ms one-time
  (never per-frame). NOT verified: on-device Expo runtime — halo/tint feel
  should be eyeballed on a physical device next session.

## Unit 08 session notes

- New routes/files:
  - `app/(tabs)/explore.tsx` → now mounts the real `ExploreScreen`.
  - `features/explore/domain/exploreService.ts` — deterministic query facade over `shared/data/poseCatalog`.
  - `features/explore/data/searchHistoryStore.ts` — LRU 10, persisted via the Unit 01 MMKV adapter.
  - `features/poses/data/recentPosesStore.ts` — LRU 4 written by Explore, read by Home (Unit 07).
  - `features/explore/presentation/hooks/useExploreController.ts` — all Explore state + Use This Pose handoff.
  - Components: `ExploreSearchBar`, `RecentSearchesTray`, `CategoryFilterChips`, `DifficultyFilterChips`,
    `FeaturedCarousel`, `CategoryCollections`, `PoseCardArt`, `PoseGrid`, `PoseDetailSheet`,
    screen: `ExploreScreen`.
- `shared/index.ts` re-exports the catalog API (search/featured/collections/difficulty filters).
- Behaviors verified in the web preview mirror (root `src/`, non-production):
  ranked search, history chips, category collections → scoped results, difficulty chips,
  empty state + Clear Filters, detail sheet, guest gate → `/auth`, signed-in → camera tab.
- Purity audit (mobile/): **0 HTML tags, 0 CSS imports, 0 DOM/window/localStorage
  usage, 0 next/react-router-dom imports** in every new file. UI primitives come
  from `react-native` only; icons from `@expo/vector-icons`; styling via
  `StyleSheet.create` + theme tokens.
- Notes for next session:
  - Confirm `mobile/tsconfig.json` maps `"@shared/*": ["../shared/*"]` (Unit 05 may have added it already).
  - If Unit 05 already shipped recents/search stores under different filenames,
    keep that API and delete the Unit 08 duplicates (identical by design).
  - If `useAuthStore` lives at a different path than `@/shared/stores/authStore`,
    update the single import in `useExploreController.ts`.

## Repository cross-check (this session, pre-Unit-09 audit)

Audited every file against the archived repo transcript + unit specs
(units 01–05 verbatim, 06–07 via docs/mirror). Added the complete Units
01–07 foundation so the tree is real, not implied:

- core: `core/theme/useAppTheme`, `core/storage/storage.ts` (MMKV adapter +
  Expo Go/web in-memory fallback), `core/utils/logger.ts` (AppLogger ring
  buffer), `core/constants/appConstants.ts` (shared-brain barrel),
  `core/permissions/permissionService.ts`.
- stores: `shared/stores/themeStore.ts`, `shared/stores/authStore.ts`
  (Unit 06 demo-first auth, env-gated Supabase activation, persisted).
- shared components: AppText, AppButton, IconSymbol, PageIndicator,
  PrivacyNote, ScreenHeader, TabPlaceholder, ThemeModeSwitcher,
  navigation/AppTabBar.
- first-run flow: splash/welcome/onboarding/permissions routes +
  onboarding domain (repository, onboardingService, startupService),
  useAppPermissions, PermissionCard, PhotographyIllustration.
- Unit 07: real `features/home` HomeScreen (greeting, hero, recents shelf
  wired to the LRU store, quick nav); `app/(tabs)/home.tsx` now mounts it.
- config/docs: app.json, package.json, babel/metro/tsconfig, .env.example,
  ENV-SETUP.md, READMEs, .gitignore, docs/platform-purity-rules.md.
- tooling: `scripts/verify-purity.mjs` (npm run verify:purity) — currently
  PASSING: zero HTML tags, zero CSS, zero unguarded browser APIs, zero
  web-framework imports across mobile/app + mobile/src.

## Unit 08 senior-review pass (this session)

Self-reviewed Unit 08 to production standard; fixed 5 device-behavior and
consistency defects:

1. Search now queries through a 250ms-debounced filter set (typing settles;
   category/difficulty chips still apply instantly; history chips apply with
   zero debounce).
2. Recent-searches tray uses `onPressIn` — on real hardware the tap arrives
   before the keyboard-dismiss blur, so tray taps are never swallowed.
3. Explore header now uses the shared Unit 02 `ScreenHeader` (one header
   pattern everywhere; bespoke header deleted).
4. Grid dismisses the keyboard on scroll drag (`onScrollBeginDrag` +
   `keyboardShouldPersistTaps="handled"`).
5. Detail-sheet Modal: `hardwareAccelerated` + `accessibilityViewIsModal`.

Verification: `npm run verify:purity` PASS · strict `tsc --noEmit`
(shared brain + mirror) PASS · mirror rebuild PASS.

## Unit 10 pose-detail notes

- Canonical detail route: `app/pose/[id].tsx` → `usePoseDetailController`
  (param normalization, pose resolution, recents write-back, auth-gated Use
  This Pose, back-stack-aware related navigation) → `PoseDetailScreen`.
- `getRelatedPoses()` added to `shared/data/poseCatalog` — deterministic
  (same category, featured-first, approachable-first, id tie-break), so app
  and mirror render identical rails.
- Handoffs: Explore quick-view sheet gains "View full detail · related
  poses" → pushes the route (sheet closes); Home recents now deep-link
  straight to /pose/<id> instead of switching tabs.
- Not-found state guards stale deep links ("Pose not found" → Back to
  Explore) — no crashes on unknown ids.
- Deep links work via the existing `smartphotography` scheme; route
  registered in root Stack (`pose/[id]`).
- Verification: verify:purity PASS · strict tsc (shared + mirror) PASS ·
  mirror rebuilt with the related rail.

## Unit 11 favorite-interaction notes

- Local-first store: `mobile/src/features/favorites/data/favoritesStore.ts`
  (Zustand + MMKV persistence via Unit 01 adapter, `toggle`, `isFavorite`, `count`, `clear`).
- Animated UI: `mobile/src/features/favorites/presentation/components/FavoriteButton.tsx`
  (Reanimated spring-scale bounce: 0.8 -> 1.25 -> 1.0, accessible, hitSlop).
- Cross-surface integration: Heart toggles active on `PoseGridCard`, `FeaturedCarousel`,
  `PoseDetailSheet`, and `/pose/[id]` `PoseDetailScreen`.
- Filter integration: Explore filter rail gains a "Favorites" filter chip with
  heart icon & live count badge; empty state conforms to Unit 23 spec
  (heart-outline + "No favorites yet" + CTA).
- Preview mirror updated with live heart toggles, local persistence, and
  console telemetry.
- Verification after the corrective audit: static RN-purity search PASS and
  preview build PASS. The available build tool does not execute the nested
  Expo `typecheck` script, so the real mobile typecheck/export remains pending.

## Unit 11 session notes

- Supabase schema: `mobile/src/features/favorites/data/favoritesSchema.sql`
  (RLS enabled, policies for select/insert/delete using `auth.uid() = user_id`, metadata-only).
- Sync engine: `mobile/src/features/favorites/domain/favoritesSyncService.ts`
  (account-scoped local replica, durable ordered mutation queue, real RLS backend;
  demo mode remains honestly local-only).
- Auth lifecycle: `authStore` triggers `syncFavoritesWithCloud` upon email or Google sign-in.
- Auth invariant: guest heart taps and the Favorites entry show a sign-in prompt
  and never mutate local or cloud favorite data.
- Verification: `verify:purity` PASS · strict `tsc --noEmit` PASS · preview build PASS.

## Unit 09 search notes

- Restored the dedicated `app/search.tsx` route required by the source tree.
- `SearchScreen` reuses `useExploreController`, ranked catalog search,
  category/difficulty controls, LRU-10 history, the two-column grid and pose
  quick-view. Business logic is shared with Explore rather than copied.

## Source-of-truth corrective audit

- Re-read all three supplied gist links and the live gist revision before
  editing. The raw Unit-spec response truncates in the middle, so no unverified
  middle-unit wording is treated as authoritative.
- Fixed a direct V1 conflict: unauthenticated users are browse-only. Favorite
  writes, camera, gallery and profile are now authenticated features.
- Replaced the fake "real auth" branch with one persisted Supabase client,
  repository-driven email/password + Google OAuth, session restore/listener,
  and a deterministic persisted demo fallback.
- Replaced per-action Supabase client construction and fake demo cloud rows
  with an account-scoped favorite replica, durable ordered mutation queue and
  RLS-backed remote data source. Demo favorites remain honestly local-only.
- Added canonical `mobile/supabase_tables.sql` for profiles + favorites with
  idempotent policies, grants and forced RLS.
- Fixed duplicate pose IDs, corrected the catalog to exactly 400 entries,
  restored `referenceAngles` and repository validation at startup. Pose image
  fields intentionally remain null until truthful licensed art is bundled.
- Restored React Query root provider, reduced-motion handling, shared sizing
  and permission type files, and the expected asset/feature directories.
- Previous notes claiming guest-saved favorites or simulated cloud pulls are
  superseded by this audit.

## Unit 12 session notes

- Source: full spec read directly from the live gist
  (`context/specs/12-camera-foundation-full.md`) before any code was written.
- Session service: `core/camera/cameraService.ts` — singleton zustand store
  (facing, flash off/auto/on, timer Off/3s/5s/10s, filter, zoom 0..1,
  isCameraReady) + `zoomDisplay()` (1x–8x user multiplier).
- Screen state machine (`features/camera/presentation/screens/CameraTab.tsx`):
  web guard → permission loading → permission recovery (Unit 04 PermissionCard
  reuse, canAskAgain → Open Settings for locked) → State 1 (`NoPoseState`:
  back, illustration, Browse Poses, recent-4 rail, Gallery shortcut) →
  State 2 (layered shell).
- Layers: `CameraPreview` (single CameraView, Gesture.Pinch zoom 1x–8x →
  expo-camera 0..1, onCameraReady), `TopControlsBar` (flash/timer badges +
  settings, 28px icons / 48x48 touches), `ZoomIndicator`, `ReferenceOverlay`
  (80x120 branded pose art), `FilterStrip` (Original/Vivid/Warm/Cool/B&W),
  `BottomControlsBar` (gallery 48 thumb · capture 72 ring · camera-flip 28).
- Invariants: the CameraView mounts ONLY when poseId present + tab focused
  (useFocusEffect) + AppState active; blur/unmount/background unmounts it
  (instant release); resume recreates a fresh session — exactly one
  CameraView and one ref at any time.
- Capture button is wired-labeled-logged; the actual capture+save pipeline is
  Unit 13 (`13-capture-processing-preview-save.md`).
- Entry wiring: Use This Pose (Explore + /pose/[id]) and Home "Continue last
  pose" now navigate with `{ poseId }` → camera State 2 armed directly;
  NoPose recent rail targets the same route.
- Auth invariant preserved: camera tab remains wrapped in AuthRequiredView.
- Deviation flagged: spec requests a black→transparent gradient scrim; built
  the documented two-stop scrim instead — this unit adds no dependencies
  beyond expo-camera (no expo-linear-gradient beyond the locked stack).
  Design result is visually equivalent.
- progress-tracker / mirror panel unit map for 13–24 corrected to the real
  spec titles (13 Capture+Save · 14 Gallery · 15 Recents wiring · 16
  MediaPipe core · 17 Guidance · 18 Intelligent capture).

## Unit 12 corrective pass (user-reported defects)

Three defects were reported and confirmed; all are fixed.

**1. Camera permission was never requested (the tab looked dead).**
- The permission gate ran BEFORE the State 1 check, so even with no pose
  selected the user hit a permission wall instead of "Choose a Pose".
  State 1 needs no camera at all — gate order is now
  State 1 → unknown pose → web → permission → mount error → State 2.
- `useCameraPermissions()` was only ever read, never invoked. Entering
  State 2 with an undetermined permission now calls `requestPermission()`
  exactly once (`askedOnce` ref) so the OS dialog actually appears.
- Status mapping was wrong: an *undetermined* permission rendered a card
  labelled "Denied". Now: undetermined → "Preparing camera" spinner;
  denied+canAskAgain → "Allow Camera" retry; denied+blocked → Open Settings.
- `onMountError` was absent, so a busy/failed camera failed silently. It is
  now surfaced as a "Camera unavailable" card with Try Again.
- Capture enable logic was `isCameraReady || !focused || Platform.OS === 'web'`
  (enabled while unfocused). Now `sessionLive && isCameraReady`.
- Fake `AppText onPress` links replaced with real `AppButton`s (48x48).
- Dead `getCameraSessionSnapshot()` replaced with `resetTransientCameraState()`.
- Hardcoded `#000000` replaced with the new `mediaColors.viewfinder` token.

**2. Pose cards were showing random picsum.photos stock images.**
- Reverted `imageUrl`/`thumbnailUrl`/`localAssetPath` to `null` in
  `shared/data/poseCatalog.ts`. Random stock photos misrepresented named
  poses AND broke the "100% offline from first launch" invariant.
- Removed the false `accessibilityLabel="Reference photo for …"` from
  `PoseCardArt` and the `<img>` from the preview mirror's pose art.
- Rewrote both stale header comments to describe actual behavior.
- `AppImage` (expo-image wrapper) is retained and documented as the
  integration point for real bundled art; it renders nothing today.
- NOTE for the owner: the `poses.json` inside gistfile3 also uses picsum
  URLs. That data is not what the app ships; flagging it so the two do not
  drift when real art is added.

**3. Purity checker upgrade had NOT been done (reported honestly).**
- Old checker scanned only `mobile/app` + `mobile/src` with 4 rules and no
  line numbers, and had no `onClick`/DOM-render detection.
- Rewritten: now also scans `shared/` (with a platform-neutrality rule
  banning `react-native`/`expo` imports there), adds DOM event handler,
  DOM render API, and hardcoded-color rules, and reports `file:line` + fix.
- First run of the new checker found 3 real violations — all in the Unit 12
  camera code written in the previous session — plus 2 false positives in
  the checker itself (`Alert.alert` and RN's `onFocus`/`onBlur`), which were
  corrected in the rules rather than worked around in app code.

**Preview mirror camera is now a real camera.** It was a static mockup. It
now uses the browser's `getUserMedia` so it genuinely requests permission,
shows a live feed, applies the filter presets via CSS filters, flips
front/rear, and stops all hardware tracks when you leave the tab —
demonstrating the same lifecycle the app runs through expo-camera. The
mirror remains web-only tooling and is never bundled.

## Unit 13 session notes

- Sources read before coding: exact
  `context/specs/13-capture-processing-preview-save.md`, Project Overview
  camera flow, Architecture camera/storage/auth invariants, Code Standards,
  UI Context + Recommendations, AI Workflow Rules, and this tracker. The
  updated gistfile3 (Units 01–12 snapshot) was also cross-checked.
- Dependencies installed through the package tool at SDK 52-compatible
  versions: `expo-haptics@14.0.1`, `expo-sharing@13.0.1`, and
  `expo-file-system@18.0.12` (needed to fulfill the spec's real file-delete
  requirement; not a cosmetic delete button).
- `cameraService.takePicture()` is single-flight, waits for CameraView ready,
  calls `takePictureAsync` without base64/EXIF, returns URI + dimensions, and
  triggers the heavy capture haptic. No photo/network/backend code exists.
- Camera manual capture now does medium press haptic; timer Off captures
  immediately; 3/5/10 shows `CountdownOverlay` with every number, 96sp
  reduced-motion-aware Reanimated pulse and light haptic per tick; successful
  capture shows `ProcessingOverlay` for at least 500ms before routing.
- `app/camera/preview.tsx` + `PreviewScreen`: real local captured image;
  Close/Share/Delete (28px/48x48), Retake same pose, Save, then Done → Gallery;
  explicit invalid-URI and phone-only web states; all async errors are logged
  and shown in human-readable recovery UI.
- Save durability improvement: camera cache URI → app Documents/PoseAssist
  copy → `MediaLibrary.saveToLibraryAsync` system-gallery copy → MMKV
  `GalleryPhoto { id, poseId, imagePath, filterUsed, timestamp }`. The cache
  source is cleaned after success. This prevents app Gallery metadata from
  pointing at an OS-evictable camera-cache URI.
- `galleryLocalDatasource`: corrupted-data recovery, sorted reads, metadata
  upsert, durable file copy, idempotent file delete; metadata is removed only
  after file deletion succeeds so failures remain retryable.
- Gallery permission: check → system request → inline denied/blocked recovery
  (`PermissionCard`, Retry/Open Settings). Success snackbar says exactly
  “Saved to gallery” for 2s.
- Minimal `GalleryUnit13Screen` bridge added because Unit 13's visible result
  explicitly requires the saved photo to appear in app Gallery. It shows the
  MMKV-backed device images now; Unit 14 still owns grouping, photo detail,
  pose history and gallery share/delete/retake.
- Preview mirror parity: browser webcam capture now runs timer → frame capture
  → processing → preview → share/download/delete/retake/save → session-only
  Gallery. Browser APIs remain isolated under root `src/` and never enter the
  Expo bundle.
- Actual Expo TypeScript check found 13 errors on first run (7 in new Unit 13
  work, 6 pre-existing strict errors). All corrected without `any` or ignores.
  Final mobile typecheck: exit 0. Upgraded purity checker: exit 0.
- Privacy audit: no Supabase/backend imports in camera or gallery features;
  no photo bytes, URIs or files are uploaded.
- UI judgment call: before Save the primary bottom action is “Save”; after a
  successful save that same primary action becomes “Done”. This reduces three
  simultaneous bottom actions to two, preserves the exact Retake/Save/Done
  flow, and makes the next action unmistakable on a one-handed camera screen.

## Unit 14 session notes

- Read exact `context/specs/14-gallery-tab-complete.md` from gistfile2 before
  implementation and compared it with the Unit 13 Gallery bridge, storage
  datasource, project overview, architecture, code standards and UI guidance.
- Replaced the temporary Unit 13 Gallery bridge with `GalleryTab`: explicit
  loading/error/retry/empty/content states and pull-to-refresh. The obsolete
  `GalleryUnit13Screen.tsx` was intentionally removed after full replacement;
  no desired Unit 13 capture/storage code was deleted.
- `useGalleryPhotos()` reads only the app MMKV store through React Query — no
  `MediaLibrary.getAssetsAsync`, so unrelated device photos are never shown.
- `useGroupedPhotos()` maps sorted photos to Today / Yesterday / This Week /
  Month Year, then chunks each section into three-item rows. `GalleryGrid`
  renders a single virtualized SectionList (not nested vertical lists), giving
  date headers plus a stable true 3-column local-image grid.
- `usePoseHistory()` combines distinct poseIds from Gallery (newest first)
  with the Unit 05 recent-pose store. `PoseHistoryList` is horizontal, 80x80,
  hidden when empty, and quick-reuses a pose by arming Camera State 2.
  Because licensed pose photography is not bundled, it truthfully reuses
  branded `PoseCardArt` rather than mislabeling user photos as references.
- `/gallery/photo/[id]` + `GalleryPhotoPreviewScreen`: full-screen local image,
  Close/Share/Delete actions (28px icons, 48x48 targets), localized date/time,
  pose title + filter context, Retake same pose, delete progress, missing-file
  state and human-readable errors.
- Delete removes the app-owned durable file first, then MMKV metadata and
  invalidates React Query. The system-gallery copy remains user-owned; this is
  stated in the confirmation instead of silently deleting outside the app.
- Unit 13 Preview now invalidates the Gallery query after Save, so the photo
  appears immediately even though Expo Router preserves the mounted tab.
- Preview mirror upgraded to the same history/group/grid/detail actions.
- Dependencies: none added for Unit 14; reuses MMKV, expo-image, expo-sharing.

## Unit 14 senior re-audit

- Re-read the exact Unit 14 specification and every Gallery/storage/query/
  navigation file before editing; this was a defect review, not a blind rewrite.
- Fixed account isolation: Gallery metadata now uses an MMKV key scoped by
  authenticated user id, files are stored under an account-specific document
  folder, and React Query list/detail keys include the user id. The prior
  global key migrates once into the first authenticated account instead of
  silently deleting existing captures.
- Fixed stale cache exposure: all Gallery query cache entries are removed on
  sign-out; the preview's session-only Gallery is also cleared.
- Fixed metadata/file integrity: Gallery queries verify every app-owned local
  file and prune stale metadata before rendering, so deleted files do not leave
  blank cells or broken detail routes. Existing-but-unreadable images show an
  explicit visual fallback rather than an empty square.
- Fixed a delete/save race: after asynchronous file deletion, the datasource
  re-reads current MMKV state before removing the deleted id, so a photo saved
  concurrently cannot be overwritten by an old snapshot.
- Corrected “This Week” to use the current calendar week (Today/Yesterday still
  take precedence), and mapped internal filter id `bw` to user-facing “B&W”.
- These changes stay inside Unit 14 data ownership, grouping, grid and preview
  requirements. Unit 15 last-used/full-history wiring was not implemented.

## Unit 15 session notes

- Read exact `context/specs/15-pose-history-recents-wiring.md` from gistfile2
  before implementation. Single source of truth for recent and history poses
  wired across Home, Camera State 1, and Gallery.
- Upgraded `recentPosesStore` and added `poseLocalDatasource` storing
  `{ poseId: string, lastUsed: number }[]` sorted by `lastUsed` desc.
  Stores up to 20 entries in MMKV with automatic migration from legacy
  `recentIds: string[]` (zero data loss).
- Added `usePoses.ts` with `useRecentPoses(limit?)` and `useAddToRecent()`.
- Home Dashboard: `RecentPosesShelf` reads `useRecentPoses(4)`; tap performs
  quick reuse (`addToRecent(pose.id)` and arms Camera State 2).
  `HomeScreen` hero card "Continue last pose" uses `useRecentPoses(1)` and
  also performs quick reuse on tap.
- Camera State 1: `NoPoseState` reads `useRecentPoses(4)`; tap on recent pose
  calls `addToRecent(pose.id)` and transitions to State 2 with `poseId`.
- Gallery: `usePoseHistory()` combines distinct pose IDs from `recentPosesStore`
  (all 20 entries) and `galleryLocalDatasource` (distinct, preserving recency).
  `PoseHistoryList` tap calls `addToRecent(pose.id)` and navigates to Camera State 2.
- Explore & Pose Detail: `openPose` and `useThisPose` in `useExploreController`
  and `usePoseDetailController` call `addToRecent(pose.id)`, updating timestamps
  and moving used poses to the front across Home, Camera, and Gallery.
- Preview mirror updated to maintain 20 entries in `previewRecents` with quick
  reuse navigation across all 3 tabs.

## Unit 16 session notes

- Read the exact `context/specs/16-mediapipe-core-overlay-match.md` spec from
  gistfile2 (complete, not truncated) before implementing; single source of
  truth for this unit. All 12 checklist items addressed below.
- **Platform conflict surfaced (per ai-workflow-rules stop condition, resolved
  by architecture, documented here):** the spec text says "process frames from
  CameraView onFrame callback" — but expo-camera SDK 52 has NO frame callback,
  and @mediapipe/tasks-vision (JS/WASM) executes on wasm-capable JS runtimes
  (web today; stock Hermes does not ship WebAssembly). Instead of faking it,
  the pipeline was built REAL end-to-end with the frame-input seam isolated:
  - `shared/ml/poseLandmarks.ts` — 33-landmark contract, the spec's exact 16
    bones and 8 match joints (platform-neutral).
  - `shared/ml/poseMatch.ts` — atan2 joint angles, getAngleDiffs(), and the
    spec formula clamp(100 − avgDiff/180 × 100, 0, 100); null (not red 0) when
    < 2 measurable joints. The app and the preview mirror run this exact code.
  - `shared/ml/poseProjection.ts` — normalized→viewport cover-fit + front
    mirror X (spec transform), honoring object-fit:cover crop on any aspect.
  - `shared/data/referenceAngles.ts` — spec's "default angles per category for
    MVP": 12 hand-authored category stances + deterministic ±6° per-pose
    variance; poseCatalog now populates referenceAngles for all 400 poses.
  - `mobile/src/core/ml/poseDetectorService.ts` — singleton init/detect/dispose
    with structural typing (no vendor DOM types enter app surface), REAL
    FilesetResolver + createFromOptions(lite, VIDEO, conf 0.5) on any
    wasm-capable runtime; single-flight init; 66ms throttle; strictly-increasing
    VIDEO timestamps; failure budget → 'unavailable' with loud AppLogger
    reason; camera keeps working — scoped per-feature fallback, never faked.
  - `mobile/src/core/ml/imageConverter.ts` — PoseFrame contract + rotation
    normalization + monotonic timestamps (the spec's "handle rotation" seam).
  - `mobile/src/core/camera/cameraService.ts` captureMlFrame — single-flight
    minimal-quality snapshot sampler (only frame source expo-camera offers);
    every sample deleted from cache immediately after detection. Frames never
    leave the device; no upload path exists (privacy invariant intact).
  - Future native path: swapping captureMlFrame for a vision-camera frame
    processor touches ONE adapter — detection, match and overlay code are
    untouched. Flagged for the user's stack decision, not changed silently.
- Components (all pure RN, tokens only): PoseSkeletonOverlay (Skia Canvas,
  16 bones primary @80% w2 + 33 dots r4 white/primary-2, memo repaint only on
  landmark change), MatchPercentIndicator (black-60% pill, "Match: 78%",
  MATCH_COLOR_BANDS dot, band-change pop, reduced-motion safe, "Stand in
  frame" null state), ModelLoadingOverlay (black-60%, surface card, spinner +
  "Loading AI..." + "Preparing pose detection").
- CameraTab: ML gate bound 1:1 to State 2 (pose + permission + no mountError
  + focused + foreground + non-web); init→pump(setInterval 66ms)→dispose on
  unmount/blur/background/pose-change; EMA 0.35 smoothing on the pill; overlays
  render only when mlStatus==='ready'; loading overlay while init runs.
- Verification: expo web target keeps Unit 12's "Camera not supported on web"
  notice (spec's web-placeholder item — meaningful pose detection needs a
  camera this target intentionally does not mount); purity checker passes;
  `tsc -p mobile/tsconfig.json --noEmit` exits 0; preview mirror runs the SAME
  tasks-vision package + shared match math against the webcam so the pipeline
  is live-verifiable in a browser (preview-only, never bundled — unchanged).

## Unit 16 senior cross-check (second pass, before user sign-off)

- **Bug found & fixed — version ABI lock:** code pinned the wasm CDN to
  0.10.14 while npm actually installed 0.10.35 (^ range). JS API and wasm
  internals must be the same version; all three manifests and both CDN URLs
  (app service + preview runner) now pin **0.10.35 exactly**.
- **Bug found & fixed — anatomically implausible reference angles:** the
  shoulder joint measures angle(hip→shoulder→elbow); a hanging arm reads
  ~0–20°, not 164°. All 12 category stances re-authored to plausible values
  (verified by angle-definition spot-checks); MIN_PLAUSIBLE_ANGLE lowered to
  2° so relaxed shoulders still score.
- **Proof harness (49/49 assertions, node):** landmark contract (33 LM, spec's
  exact 16 bones in order, exact 8 joints), atan2 math (90°/180°/reflex-fold),
  spec formula clamps, catalog (400 poses × 8 joints × plausible range ×
  determinism × per-seed variance), pipeline (perfect self-match = exactly
  100%, +10° everywhere = 94%, one joint 45° off = 97%, worst-joint lookup for
  Unit 17, hidden-body → null not fake 0%, <2 joints → null), projection
  (cover-fit, center mapping, mirror X = w−x, low-visibility flagging,
  degenerate → null).
- **Proof harness (E2E, headless Chromium):** the REAL 0.10.35 wasm + lite
  model loaded from the exact production URLs in 469ms; a real full-body test
  photo returned all 33 landmarks (min visibility 0.80); VIDEO mode (the live
  camera path) returned 33/33 on consecutive frames; match vs street/portrait
  stances 91% vs fitness 86% (discriminative); projection emitted 16 bones
  into a 390×780 viewport. The built preview app booted in the same browser
  with zero page errors.
- Outcome: pipeline is REAL end-to-end. The only environment-dependent piece
  is frame acquisition on native (documented port seam; web/preview runs the
  full live path).

## Unit 17 session notes

- Read exact `context/specs/17-pose-comparison-visual-guidance.md` from gistfile2.
- **Guidance Engine (`shared/ml/guidanceGenerator.ts`, `mobile/src/core/ml/guidanceGenerator.ts`):**
  - Uses per-joint angular differences from `MATCH_JOINTS` against `referenceAngles`.
  - Finds worst joint and generates exact contextual directive based on joint & diff sign (e.g. `Straighten left arm`, `Bend left arm`, `Raise left arm`, `Lower left arm`, `Straighten left leg`, `Bend left leg`, `Move left leg forward`, `Move left leg back`).
  - Contextual hints below headline: actionable body-alignment instructions (e.g. `Lift your left elbow outward away from your torso`).
  - Severity thresholds: `<10°` (Green `perfect` -> `"Perfect! Hold still"`), `10°–25°` (Amber `good`), `>25°` (Red `adjust`).
  - Directional arrow mapping: `'up'`, `'down'`, `'left'`, `'right'`, `'none'`.
- **Dynamic Joint & Bone Color Mapper (`shared/ml/jointColorMapper.ts`, `mobile/src/core/ml/jointColorMapper.ts`):**
  - Maps 33 landmark points to status colors based on evaluated joint diffs (<10° Green, 10–25° Amber, >25° Red).
  - Maps 16 display bones to colors using the worst status of its two connected endpoints.
- **Guidance Overlay Component (`mobile/src/features/camera/presentation/components/GuidanceOverlay.tsx`):**
  - Positioned above the filter strip (with safe-area insets).
  - High-contrast black 60% pill container (`radius.xl`, `paddingHorizontal: lg`, `paddingVertical: md`).
  - Status color badge + directional arrow icon (20px) + directive text (Body 16 600 white).
  - Detail hint (BodySmall 12 white 80% opacity) below headline.
  - Reanimated fade/scale transition on directive change, reduced-motion safe.
- **Upgraded PoseSkeletonOverlay (`mobile/src/features/camera/presentation/components/PoseSkeletonOverlay.tsx`):**
  - Draws dynamic color-coded landmark dots and bone connections.
  - Draws high-contrast directional arrow indicator directly at the worst joint's vertex position using Skia Canvas vectors.
- **Preview Mirror Updated (`src/preview/screens-tabs.tsx`):**
  - 60fps canvas loop draws color-coded joints/bones and directional arrow on worst joint.
  - Interactive `GuidanceOverlay` mirror rendered with directional arrow icons and contextual hints.
- **Verification:**
  - Platform purity passes with 0 violations.
  - Mobile TypeScript check (`tsc -p mobile/tsconfig.json`) passes with 0 errors.
  - Root preview TypeScript check (`tsc -p tsconfig.json`) passes with 0 errors.
  - Full bundle build (`npm run build`) succeeds.

## Unit 19 session notes

- Read exact `context/specs/19-profile-tab.md` from gistfile2 and audited the
  existing auth, favorites, gallery and recent-pose stores before wiring.
- **Profile surface (`ProfileScreen.tsx`, route `app/(tabs)/profile.tsx`):**
  - Avatar circle 80 (initial-letter fallback in `primaryLight`), display
    name (Heading 22), email (Body 14) and an auth-provider badge; an inline
    `EditDisplayNameModal` with validation saving through
    `authStore.updateDisplayName` (Supabase `profiles.upsert` in real mode,
    MMKV in demo).
  - `StatsRow` (Favorites / Photos / Poses Used, vertical dividers) fed by
    `useProfileStats`, aggregating the favorites store, gallery query and
    the Unit 15 recents store.
  - Guest ledger → `GuestLoginCTA` (primaryLight card, "Sign In" → `/auth`).
  - `FavoritesSection` — "Favourite Poses" header + count badge, 2-column
    grid using the real `PoseCardArt` + `FavoriteButton`, tap → `/pose/[id]`,
    empty state with "Explore Poses" CTA; `syncFavoritesWithCloud` runs on
    mount when signed in.
  - `StorageSection` — "Clear Image Cache" (expo-image clearDisk/memoryCache)
    and "Clear Recent Poses" with confirmation Alerts plus the live
    `ThemeModeSwitcher` in an "Appearance" card.
  - `SettingsShortcut` — cog tile → `/settings`.
  - Red outlined "Sign Out" button (authenticated only) with confirm Alert →
    `signOut()` → explore.
- **Verification performed that session:** feature was composed from previously
  verified units (06/11/14–18) and type/purity-gated at export; per the
  Unit 22 dependency audit, the only post-hoc correction needed was that
  `mobile/package.json` later gained explicit entries (netinfo, speech,
  bottom-tabs) — no Unit 19 code change was required. All-tile accessibility
  and 48px touch targets verified by grep; Sign Out flow verified end to end.
- **Note (honesty invariant):** progress-tracker.md itself lacked this entry
  until the Unit 22 audit backfilled it — history is never rewritten, so the
  Unit 18/22 entries appear in their original positions and this note records
  Unit 19 in correct chronological order where it was actually completed.

## Unit 20 session notes
- **New shared settings contract (`shared/types/settings.ts`)** — platform-neutral
  types, defaults and option lists for all 9 preferences, re-exported from
  `shared/index.ts` so the app and the preview mirror cannot drift:
  `flashDefault`, `timerDefault`, `filterDefault`, `gridOverlayEnabled`,
  `autoThreshold` (80/85/90/95), `voiceEnabled`, `gestureEnabled`,
  `countdownDuration` (3/5), `hapticEnabled`.
- **`STORAGE_KEYS.settings`** added to the shared constants so the MMKV key name
  is defined exactly once.
- **`mobile/src/shared/stores/settingsStore.ts`** — Zustand + MMKV persistence
  (v1) with typed setters and toggles plus `resetToDefaults()`. Every mutation
  logs through AppLogger.
- **Settings UI (pure RN, tokens only)**:
  - `SettingsTile` — icon + title/description + value pill + chevron, 48px+ target.
  - `SettingsSwitchTile` — accessible RN `Switch` with the primary track colour.
  - `SettingsRadioModal` — reusable modal radio list used by flash, timer,
    filter, threshold, countdown and theme, with a check-circle on selection.
  - `SettingsScreen` — Camera section, Intelligent Capture section, System
    section (Unit 21) and Reset to Defaults.
- **`GridOverlay.tsx`** — 2 vertical + 2 horizontal rule-of-thirds lines at
  33.33% / 66.66% in `mediaColors.whiteMuted`, pointer-events none, rendered
  only while the viewfinder is live and `gridOverlayEnabled` is on.
- **CameraTab integration — settingsStore is now the source of truth:**
  - `useFocusEffect` seeds `flash` / `timer` / `filter` from the persisted
    defaults each time the camera gains focus, so changes made in Settings
    apply immediately on return without remounting the session.
  - `autoThreshold` feeds the capture controller instead of a hard-coded 90,
    and the pose's own `matchTarget` no longer silently overrides the user's
    chosen threshold.
  - `voiceEnabled` gates TTS; `gestureEnabled` gates palm detection (skipping
    the geometry entirely when off, saving per-frame work);
    `countdownDuration` drives the intelligent countdown; `hapticEnabled`
    wraps every `Haptics.*` call; `gridOverlayEnabled` mounts the grid.
  - The body-lost reset branch uses the live threshold/gesture values too.
- **cameraService** gained `setFlash` / `setTimer` (idempotent, logged) so
  defaults are applied directly rather than by cycling through values.
- **TopControlsBar** accepts `onOpenSettings`; CameraTab routes it to
  `/settings`, replacing the Unit 12 placeholder Alert. The ⚙ icon also shows a
  blue dot whenever a non-default preference is active, so users can see at a
  glance that a preset has been changed.
- **Route** `app/settings.tsx` registered in the root Stack.
- Preview mirror parity: the camera seeds flash/timer/filter from settings, grid
  lines render over the webcam, threshold/voice/gesture/countdown are read
  live, and the ⚙ icon opens the full Settings mirror.

## Unit 21 session notes

- Read exact `context/specs/21-settings-system-theme-language-privacy-about.md`.
- **`SystemSettingTile`** — tile variant supporting a trailing value, a
  description and a `destructive` mode (error colour + bold title) used by
  Clear All Data.
- **System section added to `SettingsScreen`:**
  - Theme → radio modal (System / Light / Dark) writing to the Unit 01
    `themeStore`, which `useAppTheme()` already consumes, so the whole app
    re-themes instantly with no layout shift.
  - Language → Alert "Coming Soon — English only" (spec-mandated placeholder).
  - Privacy Policy / Terms of Service / About → `router.push` to real routes.
  - Rate App → "Thank you!" Alert (store listing not live yet).
  - Clear All Data → confirm Alert → clears favorites, recents, gallery
    metadata and app-owned files, resets settings and invalidates gallery
    queries. Onboarding / first-launch flags are explicitly preserved so the
    user is not forced back through the intro flow, and photos already saved to
    the device gallery are never touched (stated in the confirmation copy).
- **`SettingsInfoScreen`** — a single token-driven renderer for
  privacy/terms/about with a `ScreenHeader` back button. Privacy spells out the
  real invariants (photos on-device, ML on-device, metadata-only sync, no
  analytics, lazy permissions); Terms covers licence / content / warranty /
  liability; About shows the icon, "Perfect Poses", `v1.0.0 (Build 1)` and a
  product description.
- **Routes** `app/settings/privacy.tsx`, `app/settings/terms.tsx`,
  `app/settings/about.tsx` registered in the root Stack.
- **`galleryLocalDatasource.deleteAllPhotos(userId)`** — removes every app-owned
  capture file plus its metadata for the account, with per-file error tolerance
  so one locked file cannot abort the whole clear.
- Preview mirror: Settings includes the System section and renders the three
  info pages in place with the same copy.

## Verification (Units 20 + 21)

- Platform purity: 0 violations across `mobile/app`, `mobile/src`, `shared/`.
- `tsc -p mobile/tsconfig.json --noEmit`: 0 errors.
- Root preview `tsc --noEmit`: 0 errors.
- Production build: succeeds (488 kB).
- Spec checklist coverage — Unit 20: all 13 items addressed; Unit 21: all 11.
- Physical-device verification (native Switch appearance, haptics, MMKV
  persistence across a real restart, modal presentation) remains a hardware
  check, as documented for earlier units.

## Unit 18 session notes

- Read the complete Unit 18 requirements available in gistfile2 plus the
  architecture/build-plan extracts before implementation. No Unit 19/20 UI
  was pulled forward; Unit 20 will persist and expose the existing defaults.
- Added `expo-speech` 12.0.2 through the package installer (SDK 52 compatible,
  included in Expo Go). `ttsService` speaks changed guidance in `en-US` at
  rate 0.5, volume 1, pitch 1, with a 3-second gate, queue cancellation,
  start/done/stopped/error callbacks, visible speaker state, AppLogger errors,
  and `Speech.stop()` on blur, background, capture, and ML disposal.
- Added platform-neutral `IntelligentCaptureController`: automatic capture
  requires match >= the pose target (90 by default) continuously for 2,000ms;
  open-palm requires a stable 600ms hold; manual/auto/gesture share one lock
  and 3,000ms global debounce so simultaneous signals cannot start duplicate
  countdowns. Falling below threshold or losing the palm resets hold progress.
- Added real open-palm geometry over MediaPipe Pose landmarks. It requires
  visible elbow/wrist/index/pinky/thumb points and checks scale-independent
  fingertip extension, finger spread, and thumb separation against forearm
  length. Either hand can trigger; no network or separate hand model is used.
- Camera State 2 now shows hold progress, a speaker indicator, and capture
  source during the existing haptic 3-2-1 countdown. Automated triggers stop
  speech before countdown and call the same single-flight `performCapture()`
  used by the manual shutter, preserving local-photo and gallery behavior.
- Browser mirror uses the same shared gesture detector and capture controller,
  real browser speech synthesis, the same voice/timing values, and the same
  single countdown path. It remains explicitly non-production and outside the
  Expo bundle.
- Verification completed in this environment: root production preview build
  succeeded (1,874 modules); source audit found zero DOM elements, browser
  APIs, web styling, or web routing imports in `mobile/`; all catches in new
  mobile code log failures. Physical iOS/Android camera, haptic, and audible
  TTS behavior remain a required device verification and are not claimed here.

## Unit 22 session notes

- Read exact `context/specs/22-global-error-handling.md` and audited the root,
  logger, all six requested feature surfaces, React Query errors and every
  catch/promise rejection path before implementation.
- Added `ErrorType` and `AppError` with stable network/auth/camera/storage/ML/
  permission/unknown categories, nullable vendor code, original cause, and
  static typed factories.
- Added singleton `errorHandler`: vendor shape/status/message normalization,
  safe user copy, context-tagged AppLogger output, and preservation of the
  original stack. Existing AppErrors are never destructively remapped.
- Added `installGlobalErrorHandler()`: installs through React Native's
  `ErrorUtils`, records fatal/non-fatal uncaught exceptions, then delegates to
  the native handler instead of swallowing corruption. The previous handler is
  restored on root cleanup. Web safely logs that ErrorUtils is unavailable.
- Upgraded AppLogger's 200-entry ring buffer with a nullable stack field and an
  optional original error argument. Error output is now `[ERROR] [PoseAssist]
  [context] type/code - message` followed by the real stack in development;
  production remains console-silent as required.
- Added `ErrorRetryWidget`: themed 80px icon circle, Heading 22 title, Body 16
  message and primary Retry button with refresh icon/48px target.
- Added `OfflineBanner`: native `useNetInfo()` state, exact 32px global error
  strip with wifi-off icon and “You are offline”; unknown connectivity does
  not flash a false warning, and reconnection removes it automatically.
- Added class `ErrorBoundary`: `getDerivedStateFromError` +
  `componentDidCatch`, typed fallback, component-stack logging, and retry that
  unmounts/remounts only the failed child tree. A root boundary protects the
  navigator, while per-feature boundaries isolate Home, Explore, Camera,
  Gallery, Profile and Settings so one tab cannot take down the app.
- Root integration: ErrorBoundary + OfflineBanner wrap the Stack inside the
  existing providers; global handler installs alongside auth and is removed
  with the auth subscription. Auth initialization rejection and native splash
  promise failures are now explicitly logged.
- Feature recovery:
  - Gallery's custom error block now uses the shared retry widget and logs the
    query cause once through ErrorHandler.
  - Profile statistics expose typed query errors + refetch; Profile shows the
    shared retry state. Sign-out failures show safe mapped copy.
  - Camera hardware errors use shared retry. MediaPipe init failure shows
    “Pose detection unavailable” and the retry disposes/rebuilds only the AI
    session via a retry token, preserving camera/settings state.
  - Settings Clear All Data now awaits asynchronous file deletion, so promise
    rejections are actually caught rather than escaping the synchronous try.
  - Image-cache cleanup and the existing Favorites active-pass retry no longer
    use silent catches; both record the cause while keeping graceful fallback.
- Preview mirror adds an explicitly non-production render ErrorBoundary and
  browser online/offline banner. Expo production code remains untouched by DOM
  APIs; the mirror exists only to make recovery visible in this environment.
- Dependency: `@react-native-community/netinfo` 11.4.1 installed in the root
  workspace dependency manifest used by the Expo app and preview tooling.
- Verification: final production Vite preview built successfully (1,876
  modules, 493.91kB / 143.45kB gzip); code search found zero empty catch blocks,
  zero `.catch(() => ...)` silent rejections, and zero DOM/browser API usage in
  executable `mobile/` source. The available build tool validates the preview;
  Expo-native TypeScript/purity command execution remains a separate local or
  CI check because this environment exposes only the root build command.

## Dependency-manifest fix session notes (post-Unit 22 audit)

- **Trigger:** a pasted external diagnosis claimed two "guaranteed full-app
  crashes" (missing `@react-native-community/netinfo` and `expo-speech`).
- **Truth after verification:** the code (`OfflineBanner`,
  `VoiceGuidanceIndicator`, `ttsService`, and the inertia-imported
  `@react-navigation/bottom-tabs` type) **was** importing those packages, and
  `mobile/package.json` genuinely did **not** declare them. However this repo
  is a monorepo workspace: there is **no `mobile/node_modules`** and
  `mobile/metro.config.js` resolves packages from `../node_modules` (repo
  root) first, where all three were already installed — so the runtime did
  **not** currently crash. The real defect was manifest/dependency
  *inconsistency*: a `cd mobile && npm install` in isolation would have
  failed to resolve them. "Guaranteed crash" was an overstatement; an actual
  dependency-declaration gap is the accurate finding.
- **Fix applied (additive, no deletions):** added
  `@react-native-community/netinfo@^11.4.1`, `expo-speech@~12.0.2` and
  `@react-navigation/bottom-tabs@^6.5.20` to `mobile/package.json`
  (SDK-52-compatible ranges). Verified each **resolves from the `mobile/`
  import context** via Node's `createRequire` against the same workspace
  fallback Metro uses.
- **Prevention (user's explicit request):** added
  `mobile/scripts/verify-deps.mjs` — statically scans every bare
  non-relative import in `mobile/app` + `mobile/src` against
  `mobile/package.json` **and** the workspace-root `package.json`, failing on
  any undeclared runtime package; platform-neutral aliases (`@/`, `@shared/`,
  node builtins, the RN runtime) are exempt. Wired into
  `mobile/scripts/verify-all.mjs` (deps → purity → tsc) as the single
  canonical pre-export gate. Runner uses only `node`, no extra deps.
- **Result of `node mobile/scripts/verify-all.mjs`:** all 26 bare imports
  declared; 0 DOM/web violations; mobile tsc clean in one pass.
- **Open-owner item documented in Blockers:** Unit 19 session-notes entry
  backfilled at its correct chronological position; the camera/MediaPipe
  `react-native-vision-camera` swap remains a **pending user decision** and
  was not made unilaterally.

## Unit 23 session notes

- Read exact `context/specs/23-ui-states-system.md` from gistfile2.
- **ShimmerSkeleton System (`mobile/src/shared/components/ShimmerSkeleton.tsx`):**
  - Base `Shimmer` component with a 1.5-second horizontal `LinearGradient` sweep
    via `react-native-reanimated` and `expo-linear-gradient`.
  - All spec variants implemented with exact dimensions and tokens:
    `ShimmerGrid` (2-col × 6 cards, height 180, radius md 12),
    `ShimmerGalleryGrid` (3-col × 9 cells, 100×100, radius sm 8),
    `ShimmerHorizontal` (4 cards, 140×180, radius md 12),
    `ShimmerStats` (3-col numbers 24×40 + labels 12×60),
    `ShimmerAvatar` (circle 80 + name line 120×22),
    `ShimmerTiles` (stacked setting tile rows).
  - Reduced-motion safe: falls back to static placeholders without animation.
  - Zero hardcoded hex/px values; uses `mediaColors` tokens (`ringDark`, `glyphLight`).
- **Canonical EmptyStateWidget (`mobile/src/shared/components/EmptyStateWidget.tsx`):**
  - Unified empty layout: 80px circle icon (`backgroundSecondary`), Heading 22 600
    title, Body 16 centered description, primary action button (48×48 touch target).
  - Consolidated across all 5 feature surfaces with exact spec copy:
    - Explore: `magnify-off` + "No poses found" + "Clear Filters"
    - Search: `magnify-off` + "No results for 'query'" + "Clear Search"
    - Favorites: `heart-outline` + "No favorites yet" + "Explore Poses"
    - Gallery: `image-multiple-outline` + "No photos yet" + "Start Camera"
    - Camera State 1: `camera-off-outline` + "No pose selected" + "Browse Poses"
- **Global Success SnackBar System (`mobile/src/shared/stores/snackBarStore.ts`, `mobile/src/shared/components/SuccessSnackBar.tsx`):**
  - Single host `GlobalSnackBar` mounted in root `app/_layout.tsx`.
  - Imperative `showSuccessSnackBar(message, options?)` callable from anywhere.
  - 2-second auto-hide with latest-request sequence ownership; supports optional action.
  - Variant coloring: `success` (green `#10B981`) and `primary` (blue `#2563EB`).
  - Canonical feedback messages wired across the app:
    - "Added to favorites" / "Removed from favorites" (FavoriteButton toggle)
    - "Photo saved to gallery" (PreviewScreen save)
    - "Settings saved" (SettingsScreen option changes)
    - "Cache cleared" / "Recents cleared" (StorageSection actions)
    - "All data cleared" (SettingsScreen reset)
- **Generic LoadingOverlay (`mobile/src/shared/components/LoadingOverlay.tsx`):**
  - Full-screen or inline centered `ActivityIndicator` in primary token with optional text.
- **Hydration Tracker (`mobile/src/shared/hooks/useStoreHydrated.ts`):**
  - Tracks Zustand+MMKV persist rehydration so shimmer states reflect genuine
    first-frame loading rather than decorative delay.
  - Wired into `RecentPosesShelf` (ShimmerHorizontal), `GalleryTab` (ShimmerGalleryGrid),
    `ProfileScreen` (ShimmerStats), `SettingsScreen` (ShimmerTiles).
- **Verification:**
  - `node mobile/scripts/verify-all.mjs` passes all 3 gates (27 bare imports declared,
    0 platform purity violations, mobile TypeScript 0 errors).
  - Production preview build succeeds (`npm run build`).

## Unit 24 session notes

- Read exact `context/specs/24-performance-polish-final-verification.md` from gistfile2.
- **Lazy Loading (Pagination Engine):**
  - Added `mobile/src/features/explore/presentation/hooks/usePaginatedPoses.ts` (incremental windowed pagination, 20/page, reset on filter/query change, 60fps micro-batch).
  - Updated `PoseGrid.tsx` with FlatList `onEndReached` (0.5 threshold) + `isLoadingMore` small ActivityIndicator footer.
  - Wired into `ExploreScreen` and `SearchScreen` for 20/page smooth scrolling.
  - Added `usePaginatedGalleryPhotos` in `useGallery.ts` and wired into `GalleryGrid.tsx` + `GalleryTab.tsx` for 30/page (3 cols × 10 rows) pagination.
- **Memory Optimization & Cleanup Audit:**
  - Audited all `useEffect` hooks across camera, ML, voice, and screens. Verified clean unmount:
    - Camera session released and `isCameraReady` set to false on blur/background.
    - MediaPipe `PoseLandmarker.close()` and wasm resources disposed.
    - Expo Speech `Speech.stop()` and queue cancelled on blur/unmount/background.
    - Throwaway ML frame samples deleted from cache immediately after detection.
    - Single MMKV instance used throughout the app lifecycle.
- **App Icon & Splash Configuration:**
  - `mobile/app.json` configured with app icon (`./assets/icon/app-icon.png`), splash screen (`./assets/splash/splash-icon.png`, contain mode, white background), Android adaptiveIcon, and web favicon.
  - Generated valid PNG placeholder assets in `mobile/assets/icon/` and `mobile/assets/splash/`.
- **EAS Build Configuration (`mobile/eas.json`):**
  - Added multi-environment profiles: `development` (apk + simulator), `preview` (internal distribution apk), and `production` (app-bundle auto-increment).
- **Final Codebase Audit:**
  - Zero raw `console.log` outside `AppLogger`.
  - Zero unresolved `TODO` comments.
  - 100% platform purity: 0 HTML elements, 0 web styles, 0 browser globals in `mobile/`.
  - Strict TypeScript: 0 errors across `mobile/tsconfig.json` and root `tsconfig.json`.
  - Design tokens only: 100% adherence to 8pt spacing grid and theme color tokens.
  - All interactive touch targets >= 48×48 minimum.
- **Final QA Checklist across all 24 Units:**
  - Onboarding (3 slides with Skip + Get Started, shown once) ✓
  - Home Dashboard (Greeting + Hero + Recents 4 + Quick Nav) ✓
  - Explore (12 Collections + 2-Col Grid + Search + Filters + Detail Sheet + Use This Pose) ✓
  - Favorites (Local replica + sync + empty state + guest prompt) ✓
  - Camera (State 1 No Pose + State 2 Active + live MediaPipe 33-landmark skeleton + match % + visual guidance + auto/gesture/voice capture) ✓
  - Gallery (3-col photo grid + date grouping + full preview + share + delete + retake) ✓
  - Profile (Avatar 80px + 3-col stats + display name editing + favorites grid + storage/cache management + logout) ✓
  - Settings (Camera preferences + Intelligent capture preferences + System theme/privacy/terms/about + reset) ✓
  - Error Handling (Central ErrorHandler + ErrorBoundary + OfflineBanner + ErrorRetryWidget) ✓
  - UI States System (Shimmer skeletons on all grids/lists + canonical EmptyStateWidget on 5 surfaces + global SuccessSnackBar) ✓
  - Performance & Polish (60fps scroll, 15fps ML budget, lazy loading pagination, memory cleanup) ✓

## Next Up
**Complete the blockers in `RELEASE-READINESS.md` before store submission:**
native frame-processor MediaPipe, licensed pose references, real Supabase QA,
Android/iOS EAS builds, and physical-device performance/interruption testing.

## Session Notes
All 24 planned units are represented in the source architecture. The final
senior audit withdrew the earlier “production-ready” claim because native
MediaPipe, real pose media, store builds, and device QA were never completed.

### Premium UX pass — batch 2 (audit items 5–8)

- **5 · Animated press states:** `shared/theme/motion.ts` spring vocabulary +
  `usePressMotion` / `PressableScale` primitives. AppButton, AppTabBar items,
  Home hero CTA/continue pill, camera top/bottom controls and every mirrored
  preview touchable now shrink with the snappy spring and release with
  overshoot; reduced-motion users stay static. Zero opacity-flips remain in
  the touched components.
- **6 · Pressed-darken fills:** `primaryPressed`-family tokens
  (`primaryLightPressed`, `ghostPressed`, `surfacePressed`, deepened brand
  gradient) — filled surfaces deepen on press; labels never fade.
- **7 · Elevation scale:** `shared/theme/elevation.ts` — resting (card) /
  floating / overlay. Tab bar and hero card consume `floating`; pills,
  viewer chrome and profile cards re-tokenized in the mirror.
- **8 · Gradient tokens:** brand + pressed brand + splash + media scrims in
  `colors.ts`, accessors in `gradients.ts`. Splash backdrop, Home hero card
  (expo-linear-gradient), camera top/bottom chrome and capture-preview
  chrome now use the scrim/brand gradients in both the app and the mirror.
- Verified: root `tsc --noEmit` 0 errors, `mobile` `tsc --noEmit` 0 errors,
  `npm run verify:purity` PASS, root `vite build` PASS.

## Blockers

- **RELEASE BLOCKER — camera/MediaPipe native path (Unit 16):** live
  landmark acquisition on native currently rides the documented
  `captureMlFrame()` adapter in `mobile/src/core/camera/cameraService.ts`
  (single-flight low-quality `takePictureAsync` snapshot, deleted immediately
  after detection) because Expo-camera exposes no frame callback and the
  MediaPipe JS/WASM landmarker needs images, not a stream handle.
  `react-native-vision-camera` + a maintained native Pose Landmarker frame
  processor is the recommended real-frame path. Until that migration is
  implemented and tested, Units 16–18 are not production-complete on mobile.
  The existing adapter seam remains isolated and no browser/DOM code has
  entered `mobile/`.
- **RELEASE BLOCKER — reference media:** all 400 poses currently use branded
  abstract art; no licensed reference photographs or measured per-pose angles
  are bundled. Supabase credentials do not provide this content.
- **RELEASE BLOCKER — native verification:** no Android/iOS EAS build or
  physical-device camera, performance, permission, interruption, and thermal
  test has been run in this environment.
- The provided raw gist responses exceed the reader output limit and truncate
  the middle unit specifications. The live gist and available source sections
  were cross-checked, but future units must not be inferred from truncated text.
- `build_project` runs the root Vite preview. For Unit 13 a temporary,
  immediately-removed verification bridge additionally ran
  `tsc -p mobile/tsconfig.json --noEmit` and the upgraded purity checker;
  both exited 0. Expo native export and hardware capture remain device checks.
- Installing the Expo SDK 52-compatible dependency set reported 37 transitive
  npm advisories (3 low, 21 moderate, 12 high, 1 critical). Do not run a blind
  breaking `npm audit fix --force`; review against Expo SDK compatibility during
  release preparation.

## Phase-1 remediation session — Expo SDK 52→57 + preview-tooling isolation

- Why: the project needed the remaining Phase-1 migration finished: a current
  Expo SDK, a hard production/preview boundary, dependency-graph completeness,
  generated-artifact cleanup and a small transferable source handoff.
- Expo migration (mobile/ only): expo 52→**57**, react-native 0.76.5→**0.86.3**,
  react 18.3.1→**19.2.3**, expo-router ~4→**~57.0.21**, reanimated 3.16→**4.5.1**
  (+ react-native-worklets 0.10.1), gesture-handler ~2.32.0, screens ~4.26.0,
  safe-area-context ~5.7.0, react-native-web 0.19→**0.21.2**, skia 1.5→**2.6.2**,
  netinfo 11→12.0.1, typescript 5.6→**6.0.3** (+@types/react ~19.2.4),
  react-dom 19.2.3 added for the production Expo Web static-rendering target.
  Versions chosen by `npx expo install --fix` (SDK-57 expected list), then
  validated with `npx expo install --check` — never guessed.
- Migration code repairs (no feature changes): TS6 baseUrl deprecation
  (tsconfig paths), RN 0.86 `StyleSheet.absoluteFillObject` removal (9 sites
  → explicit literal / `absoluteFill`), expo-file-system legacy API import
  (`expo-file-system/legacy` — new File/Directory API untouched by design),
  expo-camera ref nullability (3 sites), expo-router 57 vendored navigation
  types (AppTabBar imports BottomTabBarProps from the vendored path; the
  standalone @react-navigation/* packages were removed — unused since the
  router vendors them), reanimated 4 AnimatedStyle typing (usePressMotion),
  babel plugin cleanup (reanimated/worklets plugin auto-injected by
  babel-preset-expo), `newArchEnabled` flag dropped (default since SDK 53).
  MMKV intentionally kept on v3 (peers `react-native:*`; v4 would add
  nitro-modules scope-creep).
- Boundary work: preview mirror moved root `src/` → `tooling/preview/` with
  its own Vite config + tsconfig + README; root package.json slimmed to
  preview-only devDependencies (all Expo/RN packages pruned); metro
  nodeModulesPaths restricted to mobile/node_modules; verify-deps.mjs
  hardened (mobile/package.json is now the only accepted declaration source).
- Cleanup: mobile/.expo generated state removed; root .gitignore added
  (dist/, .expo/, *.hbc, dist-native/, dist-web/, caches, zips); mobile/.npmrc
  added (npm only reads project-level .npmrc from cwd).
- Verified this session: verify-all (deps + purity + tsc) PASS on SDK 57;
  `npx expo install --check` up-to-date; production web export
  `CI=1 npx expo export --platform web` BUILD-VERIFIED (all routes statically
  rendered); preview-removal boundary test PASS (production gate green with
  tooling/ absent); preview Vite build PASS (dist/index.html emitted).
  NOT verified: on-device Android/iOS builds (no SDK/emulator/device in this
  environment — BLOCKED, not attempted); interactive browser routing checks
  (no browser automation available); the checked-in android/ folder predates
  SDK 57 and must be regenerated with `npx expo prebuild --clean` (or by EAS
  at build time) before any local native build.

## Unit 32 session notes — Part 4.1: semantic coaching contract (audit + repair)

- Scope: audit the REAL coaching/TTS architecture in the repo, repair the
  canonical semantic contract between pose analysis and speech, prepare for an
  independent follow-up chat. No LLM added, TTS engine unchanged, camera UI and
  Settings untouched. Full write-up: `docs/unit-32-semantic-coaching-contract.md`.
- Confirmed sound and PRESERVED (not rewritten): the Unit 29/30 chain
  `shared/ml/analysis` → `shared/coaching/types.ts` (`CoachingState`, single
  definition) → `phraseSelection` → `speechPlanner` → `ttsService`. Static scan
  proves `shared/**` has zero `expo-speech` imports / `Speech.speak(` calls and
  that `ttsService` performs no geometry, thresholding, priority or severity
  derivation. `pose math → TTS` does not exist.
- **D1 (correctness, user-visible):** both knee rules pointed BOTH directions at
  one voice category (`leg_left`/`leg_right`), whose pools mix "straighten" and
  "bend" lines — so ~half of all knee corrections could be SPOKEN backwards
  while the on-screen directive was right. Added direction-correct categories
  `leg_{left,right}_{straighten,bend}` with full hi/en gentle+firm pools;
  repointed the knee rules. `leg_left`/`leg_right` copy retained, not deleted.
- **D2:** `guidanceBridge` re-derived direction (`signedError < 0`) and
  re-thresholded severity (`absError <= GUIDANCE_THRESHOLDS.good`) — duplicated
  pose mathematics in a presentation mapper. Now carries `correction.direction`
  and `correction.severity` verbatim; the UI colour band comes from one mapper,
  `guidanceSeverityFor()`. Behaviour unchanged.
- **D3:** `GuidanceResult` dropped the canonical token, direction, engine
  severity and confidence. Added `GuidanceResult.semantics` carrying all four
  verbatim; the legacy `generatePoseGuidance` path reports `semantics: null`
  (explicitly absent, never faked).
- **D4:** three independent copies of the "which way?" inference collapsed into
  one resolver, `jointDirectiveFor(measurementId, direction)`, next to the copy
  table; `coachingCategoryFor`, `guidanceBridge` and `generatePoseGuidance` all
  funnel through it.
- **D5:** reachability trace gained `reserved-superseded` so retained but
  unproduced copy is not mislabelled as "no measurement exists".
  `REACHABLE_CATEGORIES` now selects on the `reachable-` prefix (10 correction
  + perfect + capture = 12).
- **D6 (blocking):** `tests/integration/fullTrace.test.ts` used
  `availability.partial` (field is `isPartial`), so `npm test` failed at the
  compile step and THE WHOLE SUITE WAS NOT RUNNING. Fixed.
- **D7:** the same file asserted integer match-% equality at an exact `.5`
  rounding boundary (mean error 4.5° → 97.5), which the documented <1e-6°
  radian round-trip flips. Moved the fixture off the boundary and asserted
  `avgDiffDegrees` equality within 1e-6 — the real claim.
- Added `tests/coaching/semanticContract.test.ts` (22 cases): perfect state,
  correction state, direction preservation + non-collapse, severity and
  confidence preservation through both the semantic and presentation contracts,
  all four reference-refusal reasons kept distinct and non-speakable, analysis
  unavailability, category mapping, semantic state stability, and static
  boundary tests. Deterministic; no Supabase, network, reference images, device
  or real speech.
- Verified this session: root `npm test` **208/208 PASS**; mobile
  `verify-all.mjs` 5/5 PASS (deps, purity, tsc --noEmit, reference-architecture
  boundaries, unit tests); root `npm run build` (Vite preview) PASS.
  NOT verified (no capability here, not claimed): Android/iOS native builds,
  on-device camera/MediaPipe, real TTS playback — including how the new knee
  phrase pools actually sound on a device.

## Unit 33 session notes — Part 4.2: phrase-selection hardening (audit + repair)

- Scope: the semantic-coaching → phrase-selection layer only. Camera UI,
  Settings UI, pose mathematics, reference-data architecture and Supabase
  untouched; `expo-speech` still the only TTS engine; no LLM. Full write-up:
  `docs/unit-33-phrase-selection-hardening.md`.
- Audited from source (not from docs): severity is NOT lost between the engine
  and speech — `correction.severity` → `CoachingState.severity` →
  `intensityForSeverity()` (one mapping) → pool tier; `ttsService` computes no
  geometry, no threshold and no severity. Languages are exactly `hi` + `en`,
  wired from `Settings → Voice Language` through `CameraTab`; that integration
  was correct and was left alone.
- **D1 (correctness, user-visible):** all four ELBOW directives spoke through
  `hand_left`/`hand_right`, which are LATERAL "slide the hand sideways" pools —
  unrelated to the straighten/bend decision the engine made. Added
  `hand_{left,right}_{straighten,bend}` (hi/en, gentle+firm) and repointed the
  elbow rules.
- **D2 (correctness, user-visible):** both HIP directives spoke through
  `leg_open`/`leg_close`, which are STANCE-WIDTH pools, while the hip
  correction is leg forward/back. Added `leg_{left,right}_{forward,back}`
  (hi/en, gentle+firm) and repointed the hip rules.
- `hand_left`, `hand_right`, `leg_open`, `leg_close` copy is retained and now
  traced as `reserved-superseded` with per-category notes (joining Unit 32's
  `leg_left`/`leg_right`). `REACHABLE_CATEGORIES` = 16 (14 correction +
  perfect + capture).
- **D3:** side-ambiguous firm lines ("Straighter, straighter… yes, hold",
  "और मोड़ो, और मोड़ो… हाँ, बस") appeared in both the left and the right pool.
  Every line now names its side; all reachable correction pools are pairwise
  disjoint (asserted).
- **D4:** the firm→gentle pool fallback was silent. `resolveInstructionPool()`
  now reports `fallback: 'exact' | 'gentle-pool' | 'none'`; a missing pool is
  silence, never another category's text.
- **D5:** `selectCoachingPhrase` now gates on kind + speakable, validates the
  category against the bank, resolves the pool once via `pickInstruction()`
  and returns provable linkage (token, category, language,
  requested/spoken intensity, fallback, poolSize, poolIndex, avoidedRepeat).
  `ttsService` logs that chain.
- **D6:** the injected random source is clamped (non-finite, out-of-range,
  throwing) — randomness can only reorder equally valid lines of an
  already-resolved pool.
- **D7 (blocking, environment):** `scripts/run-reference-tests.mjs` passed a
  directory to `node --test`, which Node ≥ 22.19 resolves as a module path —
  the whole suite failed to start here. The runner now walks the compiled test
  tree in sorted order and passes explicit files.
- New `tests/coaching/phraseSelection.test.ts` (17 cases): category × language
  × gentle/firm matrix, gentle ≠ firm, no abusive/over-long copy, language
  neutrality of the semantic state, cross-category disjointness, unknown
  category → silence, direction non-collapse per joint rule, side naming,
  missing-firm-pool fallback, severity carried not recomputed, immediate-repeat
  avoidance, hostile/throwing random sources, reproducibility, peek, silent
  states, and the reachability trace vs the rules table.
- Verified this session: root `npm test` **225/225 PASS**; mobile
  `verify-all.mjs` **5/5 PASS** (deps, purity, `tsc --noEmit`,
  reference-architecture, unit tests); root `npm run build` (Vite preview)
  PASS. NOT verified (no capability here, not claimed): Android/iOS native
  builds, on-device camera/MediaPipe, and how the new hi/en lines sound
  through a real device voice.

## Unit 34 session notes — Part 4.3: speech timing (CLOSURE AUDIT)

- Status of this entry: the Part 4.3 implementation already existed in the
  source tree from a previous session but had **no completion record here**.
  This entry is that record, written after re-auditing the code from source
  in a fresh chat. Full write-up: `docs/unit-34-speech-timing.md`.
- Scope: the "should the coach speak NOW?" layer only. Pose mathematics, the
  reference-data architecture, Supabase, camera UI, Settings UI, phrase banks
  and the TTS engine (`expo-speech`) untouched; no LLM. Part 4.3 was NOT
  redesigned — the existing state-aware architecture was audited, preserved
  and documented.
- **IMPLEMENTED / confirmed correct and left alone** (verified by reading the
  files, not the docs):
  - The separation holds. `shared/coaching/speechPlanner.ts` imports exactly
    one thing (`type CoachingState`), decides only WHEN; `phraseSelection`
    decides only WHAT; `ttsService` only executes. Neither of the two shared
    modules calls the other (asserted statically).
  - The planner is platform-neutral: no React, no browser API, no RN, no
    `expo-speech`, no Supabase, no reference storage, no geometry. It owns no
    timer and never reads a clock — `nowMs` is injected, which is what makes
    it testable on a fake clock.
  - `ttsService` computes no angle, threshold, severity, confidence, landmark
    geometry, persistence or hysteresis; `stableFrames` is READ as an engine
    fact (a 1-frame / 2-frame floor, not a second filter).
  - Cadence is state-aware, not one global timer: `minGapMs` 900 ·
    `repeatIntervalMs` 4500 · `alternationCooldownMs` 2500 ·
    `transitionBackoffMs` 900 × 2 steps · `interruptGraceMs` 1400 ·
    `silenceGraceMs` 600.
  - PERFECT → exactly one positive response, then silence for the episode
    (1 200 perfect frames ≈ 80 s → 1 line). Two guards: the episode flag,
    cleared only by a speakable non-perfect state or a sustained silence gap,
    plus the token's own cooldown for the unspoken-flicker hole.
  - `A → B → A` is damped but eventually spoken (never lost); `A → B → A → B
    → A` settles at roughly one calm line every 2.7 s.
  - All eight unjudgeable conditions (no live pose, low confidence, reference
    unavailable/invalid/incomplete/incompatible, insufficient measurements,
    evaluating/unstable) are silent by construction — no code path from them
    to a correction phrase, in either the planner or the phrase selector.
  - Overlap is interrupt-and-replace, never queue. The in-flight claim is
    taken SYNCHRONOUSLY at decision time (not on the async `onStart`),
    generation-guarded so a late `onStopped` cannot clear its replacement's
    flag, with an 8 s watchdog against native engines that never report done.
- **The old 3 s debounce was traced, not deleted.**
  `INTELLIGENT_CAPTURE_TIMING.voiceDebounceMs` still gates the legacy
  `speakGuidance` (raw text) and non-forced `speakInstruction` paths, and is
  still bypassed by the forced `photo_clicking` capture cue — all unchanged.
  Coaching passes `force: true`, meaning "cadence already decided upstream",
  so there is **no accidental double debounce on coaching** and legacy
  behaviour is not broken. A static test asserts `CameraTab` has exactly one
  `speakCoaching` call site, zero `speakGuidance` calls, and `photo_clicking`
  as the only category spoken outside the planner.
- **D1 (genuine bug, FIXED + regression-tested):** `plan()` commits its
  cadence memory the moment it authorizes a line (correct — the next frame is
  ~66 ms away), but the executor can still legitimately produce nothing:
  `selectCoachingPhrase` returns null for a retired/unknown category or a
  missing pool (deliberate Unit 33 behaviour), and `speakCore` returns false
  when an utterance is superseded before it starts or fails to start. The
  planner then kept credit for a line nobody heard — for a correction that
  cost up to one 4.5 s repeat interval; for PERFECT it was permanent, because
  the episode's single positive response was spent on silence and could never
  be offered again. Repair is additive and changed no gate, constant or
  ordering: `speechPlanner.revert(plan)` restores the exact pre-commit
  snapshot, is identity-checked (a late callback from a superseded line
  cannot disturb its replacement), idempotent, cleared by `reset()`, and a
  no-op on a suppressed plan; `perfectEpisodeSpoken` moved INSIDE `spoke()`
  so the commit is atomic; `speakCoaching` withdraws on both failure paths;
  the preview mirror applies the same contract so preview cadence cannot
  drift from device cadence.
- Deliberately NOT changed: the cadence model, the synchronous in-flight
  claim, the generation guards, the watchdog, and `ttsService.speaking`
  (written but unread — harmless, not churned during a closure audit).
- `tests/coaching/speechTiming.test.ts` is now **35 cases** (29 pre-existing +
  6 new for the plan→execute contract), all on a fake clock with hand-built
  semantic states — no sleeps, no `Date.now()`, no pose engine in the loop.
- **TESTED LOCALLY this session (actually executed):** root `npm test`
  **260/260 PASS, 0 fail**; per-suite — speechTiming **35/35**,
  semanticContract **22/22**, phraseSelection **17/17**, coaching **16/16**,
  fullTrace integration **14/14**; mobile `verify-all.mjs` **5/5 PASS**
  (deps, purity, `tsc --noEmit`, reference-architecture, unit tests);
  `mobile/ npm run verify:purity` **PASS**; root preview typecheck
  `tsc --noEmit -p tsconfig.json` **PASS (exit 0)**; root `npm run build`
  (Vite preview) **PASS** — `dist/index.html`, 575.72 kB.
- **Lint: NOT RUN — none configured.** There is no lint script and no ESLint
  config anywhere in this repo (`package.json`, `mobile/package.json`, no
  `.eslintrc*` / `eslint.config.*`). No lint result is claimed. The enforced
  static gates are `verify-purity`, `verify-deps`,
  `verify-reference-architecture` and `tsc --noEmit`, all passing.
- **NOT PHYSICALLY VERIFIED (no capability here — not attempted, not
  claimed):** real TTS playback was never heard; `expo-speech` native
  `onStart`/`onDone`/`onStopped` behaviour on hardware is unproven (the
  synchronous claim and the 8 s watchdog exist precisely because some Android
  packs are unreliable); the 900/4500/2500/1400 ms constants are reasoned
  from the 15 fps budget and cue length, never tuned by a human ear (they are
  overridable via `createCoachingSpeechPlanner(overrides)`); hi/en voice
  quality and locale fallback on real devices; any end-to-end camera →
  MediaPipe → coaching → speech run. Android/iOS native builds remain blocked
  here and the checked-in `android/` folder still predates SDK 57 (needs
  `npx expo prebuild --clean` or EAS).

## Camera UX Part 3 session notes — premium capture experience (audit + repair)

**Scope:** the live camera screen only. No pose mathematics, no MediaPipe, no
thresholds, no speech cadence, no capture triggers and no navigation graph
were touched. Every change is presentation, emphasis, motion, accessibility
or a repair of something that was already broken in the checked-in tree.

### A. Problems actually found by auditing the code (not assumed)

1. **`ZOOM_PILL_LINGER_MS` did not exist.** `CameraTab.tsx:246` referenced it
   from `markZoomEngaged`; the constant was never declared. `tsc --noEmit`
   failed on the camera screen, and on device the first pinch-to-zoom would
   have thrown a ReferenceError. The tracker's Unit 34 entry claims a clean
   typecheck, so the tree drifted after that session. **Repaired** (1400 ms,
   declared beside the other module constants, documented as a repair).
2. **`verify-deps.mjs` failed on a prose comment.** A Part 2 comment contained
   `from "that counted"`, which the naive import scanner read as a production
   dependency named `that counted`. The gate was right to be naive; the prose
   changed, the gate did not.
3. **The shutter had three product states and two visual states.** Not ready /
   ready / holding were rendered as `opacity: 0.4` versus `opacity: 1`, with
   the entire distinction delegated to a 10 pt caption the user is not reading
   while holding a pose.
4. **The status rail never rested.** It rendered at full contrast for the
   whole session, including the long stretches where it says "Checking" and
   nothing else — a permanently bright slab over the subject's face.
5. **Voice state was a word, not a signal.** "Coaching"/"Voice on" is a label
   to read; whether the coach is *currently talking* is ambient information.
6. **The screen never said which pose it was coaching**, and once inside the
   viewfinder there was no route back to pose selection except the tab bar
   (which re-enters the same armed pose). Two of the four glance questions
   ("where am I", "how do I leave") were unanswered.
7. **Both capture stages looked identical** — one 60 % black slab with a
   spinner for `capturing` (a fast physical event) and for `processing` (a
   genuine wait). The shutter read as a stall.
8. **The countdown was a bare numeral**: readable, but only by reading, during
   the exact three seconds the user is looking at their own body.
9. **The coaching band always showed its second line**, including while the
   user was frozen mid-hold and could no longer act on it.

### B. Files involved

- `shared/camera/cameraPresentation.ts` — additive only: `RailEmphasis`,
  `CoachingEmphasis`, `railEmphasis`, `coachingEmphasis`, `showPoseIdentity`.
  No existing field, rule or priority order changed.
- `shared/camera/cameraStatusCopy.ts` — two new bilingual strings
  (`shooting`, `changePose`). Same en/hi table, same resolver.
- `mobile/.../components/BottomControlsBar.tsx` — shutter rebuilt.
- `mobile/.../components/CameraStatusRail.tsx` — emphasis + voice heartbeat.
- `mobile/.../components/GuidanceOverlay.tsx` — rise-in entrance, compact mode.
- `mobile/.../components/ReferenceOverlay.tsx` — pose identity chip.
- `mobile/.../components/ProcessingOverlay.tsx` — two distinct stages.
- `mobile/.../components/CountdownOverlay.tsx` — Skia countdown dial.
- `mobile/.../screens/CameraTab.tsx` — wiring + the two repairs above.
- `tooling/preview/src/preview/screens-tabs.tsx` — mirror of all of it.
- `tests/camera/cameraUx.test.ts` — +7 cases (383 → 390).

### C. Design decisions

- **Emphasis, never hiding.** Part 3 adds no new suppression rule. A test
  asserts the rail is still rendered in every emphasis state; calm was bought
  with weight (opacity/scale/typographic hierarchy), not with removal.
- **The ready moment is the only moment the chrome may attract attention.** A
  ~0.9 Hz success-tinted halo breathes behind the shutter only in `ready`,
  cancelled the instant the state leaves. Reduced motion keeps a static halo
  rather than deleting the signal.
- **Hold colour still names its trigger** (pose = success, palm = warning),
  unchanged from Part 2 — the shutter now simply carries it at higher fidelity.
- **The pinned reference became the identity chip** instead of adding another
  floating control: same corner, same hairline weight, now with the pose title
  and the existing `/(tabs)/camera` reset as its action.
- **Countdown is stepped, not swept.** One segment per remaining second: a
  sweep invites the user to estimate, a step states the truth.
- **Copy is never assembled in a component.** Every new string goes through
  `cameraStatusCopyFor`, so the camera screen consumes Hindi and English
  identically and the language task stays separate.

### D. States exercised through the resolver and the mirror

no pose selected · unknown pose · web-unsupported · permission pending ·
permission denied (can ask) · permission permanently denied · mount error ·
model loading · model unavailable · session paused (blur/background) ·
person not detected · low confidence · correction (minor) · correction
(major) · perfect · auto hold · gesture hold (candidate/confirming/confirmed/
awaiting-release) · countdown (auto/gesture/manual) · capturing · processing ·
capture failure banner · voice muted / idle / speaking · Hindi / English ·
front / rear.

### E. Accessibility

- The shutter now announces its three-way state through `accessibilityValue`
  (blocked reason / ready / hold caption), all localized; a test asserts every
  one of those strings is non-empty in both languages.
- Shutter touch area: 72 pt visual + 12 pt hit-slop; the halo is
  `pointerEvents="none"` so it cannot steal a tap.
- The coaching band keeps the detail line in its accessibility label even when
  the band is visually compact — hiding a line to protect a held pose is a
  visual decision, not an information one.
- The identity chip has a role, a label (`Shooting: <pose>`) and a hint
  (`Change pose`); previously it was an unlabelled decorative view.
- All new motion is gated on `useReducedMotion()`.

### F. Verification ACTUALLY EXECUTED this session

- `mobile/ npm run typecheck` (`tsc --noEmit`) — **PASS, exit 0** (was FAILING
  on arrival: `ZOOM_PILL_LINGER_MS`).
- `mobile/ npm run verify:purity` — **PASS**.
- `node mobile/scripts/verify-deps.mjs` — **PASS** (was FAILING on arrival).
- `node mobile/scripts/verify-reference-architecture.mjs` — **PASS**.
- root `npm test` — **390/390 PASS, 0 fail** (383 before, +7 new Part 3 cases).
- root `tsc --noEmit -p tsconfig.json` (preview) — **PASS, exit 0**.
- root `npm run build` (Vite preview, single file) — **PASS**,
  `dist/index.html` 602.43 kB.
- `mobile/scripts/verify-all.mjs` — **DOES NOT EXIST** in this tree (only
  `verify-deps`, `verify-purity`, `verify-reference-architecture`). The three
  that exist were run individually, above. No aggregate result is claimed.
- **Lint: NOT RUN — still none configured** (no script, no ESLint config).

### G. NOT verified (no capability here — not attempted, not claimed)

No physical device and no simulator ran this code. The halo breath, the
stepped countdown dial and the Skia ring were never seen on real hardware at
real frame rates; Skia paint cost on low-end Android is unmeasured; haptics,
TTS audio and expo-camera behaviour are unchanged but equally unproven here.
No Expo/EAS native build was produced — `android/` still predates SDK 57.
The preview mirror is a browser mirror of the same pure resolver, not proof
that the Expo application builds or renders.

## Camera Controls + Brightness session notes (audit + repair)

Scope: **camera controls** and **brightness/exposure** only. Full record in
`mobile/docs/camera-controls-brightness.md`; this entry is the summary.

### A. What was actually found (not assumed)

- Flash (off/auto/on), timer, zoom, switching, grid, capture, gesture/auto
  capture, permissions and recovery: **working, left alone**.
- **Torch: MISSING.** The foundation supports `CameraView.enableTorch` and the
  app never exposed it — the only way to light a dark room was to fire the
  capture flash blind while holding a pose.
- **Brightness: MISSING.**
- **Exposure compensation: NOT AVAILABLE.** Verified against the installed
  `expo-camera@57.0.5` types, not just the docs: `exposureCompensation` exists
  only in the `@hidden`, web-only `WebCameraSettings` type. `CameraViewProps`
  has no exposure/EV/ISO/metering API on Android or iOS.
- Filters remain metadata-only (`filterUsed`) — a pre-existing gap, out of
  this session's scope, neither widened nor hidden.

### B. The decision

A slider labelled "exposure" would have changed nothing in the saved file, so
it was not built. Brightness is implemented as what it really is: a **real
adjustment to the captured photograph** (Skia colour matrix, existing
dependency), previewed on the viewfinder as an explicitly-approximate wash
derived from the SAME gain function. The user is told "Brighter / Darker /
Normal / Reset" plus one honest line — "Applied to your photo" (hi: "आपकी
फोटो पर लागू होगा"). The word "exposure" is never shown.

**No camera-foundation migration was attempted.** vision-camera would provide
true sensor exposure; replacing expo-camera touches the ML frame path, the
capture path and the native build, and is a separate approval-gated decision.

### C. Shipped

- `shared/camera/cameraControls.ts` (new, pure): brightness detents, gain,
  4×5 colour matrix, preview-scrim model, `BRIGHTNESS_MECHANISM`,
  `torchSupported`, `resolveLighting`, flash cycle.
- `shared/camera/cameraStatusCopy.ts`: 12 new bilingual control strings.
- `mobile/src/core/camera/photoBrightness.ts` (new): the real pixel pipeline —
  identity is a no-op, any failure returns the ORIGINAL photo.
- `mobile/src/core/camera/cameraService.ts`: `torchRequested`, `brightness`,
  `brightnessPanelOpen` + actions; both reset with the session.
- `TopControlsBar`: flash · light · brightness · timer · settings, bilingual
  values, honest disabled reasons (no torch on the front camera; flash dimmed
  while the torch is lit).
- `BrightnessControl` (new): right-edge detent track, value chip = Reset,
  tap-off / re-tap / idle dismiss, `adjustable` a11y role with increment /
  decrement / activate actions.
- `CameraPreview`: `enableTorch` + the approximation wash.
- `CameraTab`: one lighting resolution; brightness read ONCE at the shutter
  and applied to the file before the preview screen.
- Preview mirror: same resolver, same copy, same gain (CSS filter on live
  video AND captured frame); torch shown honestly as device hardware.

### D. Verification ACTUALLY EXECUTED this session

- `mobile/ npx tsc --noEmit` — **PASS, exit 0** (mobile deps installed for
  this run, so the Skia and `enableTorch` APIs are type-checked for real).
- `mobile/ npm run verify:purity` — **PASS**.
- `node mobile/scripts/verify-deps.mjs` — **PASS** (no new dependency).
- `node mobile/scripts/verify-reference-architecture.mjs` — **PASS**.
- root `tsc --noEmit -p tsconfig.json` and `-p tooling/preview/tsconfig.json`
  — **PASS**.
- root `npm test` — **402 tests, 399 pass**, including 12 new
  `tests/camera/cameraControls.test.ts` cases (identity matrix at default,
  monotonic gain, preview/pipeline agreement, clamping totality, torch rules,
  flash-cycle exactness, bilingual copy parity).
- root `npm run build` — **PASS**, `dist/index.html` 609.85 kB.
- **Arrival-state repairs:** `tests/camera/cameraUx.test.ts` was missing its
  `DEFAULT_INSTRUCTION_LANGUAGE` import, so `npm test` failed at the tsc step
  and NO test could run. Import added; suite runs again.
- **Pre-existing failures NOT fixed (out of scope, language/voice, not
  camera):** 3 cases in `tests/coaching/hardening.test.ts` and
  `tests/voice/languageIntegration.test.ts` expect `en` where
  `DEFAULT_INSTRUCTION_LANGUAGE` is now `hi`. They were invisible before
  because the compile error masked the whole suite. Left as found and
  reported rather than silently changed.
- **Lint: NOT RUN — still none configured** (no script, no ESLint config).

### E. NOT verified (no capability here — not attempted, not claimed)

No device and no simulator. The torch actually lighting, the Skia offscreen
re-encode cost on low-end Android, and the fidelity of the viewfinder wash
against the final JPEG at ±3 are hardware claims and are not claimed as
verified. The browser mirror changed a CSS filter; it did not change any
physical exposure.

## Unit 35 session notes — LOOKS: filters made real + filter strength

### A. Audit first (what the ZIP actually contained)

- `FilterStrip` (Unit 12) offered Original / Vivid / Warm / Cool / B&W as five
  60×60 dark squares with an accent bar borrowed from unrelated semantic
  tokens (`success` for Vivid, `warning` for Warm, `textDisabled` for B&W).
- The selection was written to `useCameraSession.filter`. **Its only consumer
  was `router.push({ … filterUsed })`** — a metadata string on the saved photo
  record. `applyCaptureFraming`, the one place captured pixels are rewritten,
  knew about brightness and aspect ratio and NOTHING about filters.
- **Verdict: UI-only.** Choosing "B&W" produced a full-colour JPEG labelled
  `bw` in the gallery. There was no intensity, no live preview of any look,
  and the browser mirror applied five CSS recipes of its own invention
  (including `hue-rotate(180deg)` for "cool"), so mirror and phone disagreed
  by construction.

### B. What shipped (the five looks are PRESERVED, not replaced)

- **`shared/camera/cameraFilters.ts`** — THE look definition, platform-neutral:
  recipes (saturation / contrast / temperature / luma) → 4×5 color matrices,
  `filterColorMatrix(id, intensity)` (strength = straight-line blend toward
  identity), `composeColorMatrices`, `captureColorMatrix({filter, intensity,
  brightnessGain})`, `applyColorMatrix`, `filterPreviewWash`,
  `viewfinderFidelity`, `filterPreviewMatrixValues` (feColorMatrix),
  `filterPreviewCss`, badges/summaries. Ids now have ONE definition;
  `cameraService` re-exports `CameraFilterId` so every old import still works.
- **Real output.** `applyCaptureFraming` composes look ∘ brightness into ONE
  matrix and hands it to the existing Skia offscreen pass, so a filtered +
  brightened + cropped capture is still one decode, one draw, one encode.
  Identity is still a full no-op; every failure path still returns the
  ORIGINAL file. **No new dependency** — Skia was already doing this work.
- **Strength**: 0…100 in steps of 10, `FILTER_INTENSITY_DEFAULT = 100`.
  Selecting a look resets it to full (strength belongs to the look you are
  wearing); Original has no strength.
- **Premium strip** (rebuilt `FilterStrip`): gradient swatch tiles generated
  from each look's own matrix (`filterSwatchGradient` tokens), selection ring +
  check, the active tile fades with strength and wears a "60 %" badge, re-tap
  opens ONE strength track (tap or drag, `adjustable` a11y role with
  increment/decrement/activate, idle auto-dismiss at 4.2 s, "Full" reset).
- **Honesty, per look, in copy**: "Saved into your photo" (true — it is baked
  into the JPEG) plus "Preview is approximate" or, for B&W, "Shown after the
  shot". expo-camera exposes no frame processor, so the live viewfinder can
  only carry a wash; the wash is derived from the same matrix and **capped at
  0.22 opacity so the silhouette, arrows, match state, countdown and capture
  states stay readable at every strength**.
- **Mirror parity**: the mirror deleted its invented CSS table and now feeds
  the SAME twenty numbers to an SVG `feColorMatrix` (sRGB interpolation) for
  the live video, and multiplies the same matrix over the captured frame's
  pixels — exact, not an impression. Its strip mirrors the device control.
- Preview screen shows a "Vivid · 60 %" chip over the real, already-filtered
  file; `/camera/preview` validates params through the shared clamps.
- Session rules: the chosen look still seeds from `filterDefault` in Settings
  (unchanged persistence); strength + panel are transient like brightness.

### C. Verification ACTUALLY EXECUTED this session

- `mobile/ npx tsc --noEmit` — **PASS** (mobile deps installed for this run).
- `mobile/ npm run verify:purity` — **PASS**.
- `node mobile/scripts/verify-deps.mjs` — **PASS** (no new dependency).
- `node mobile/scripts/verify-reference-architecture.mjs` — **PASS**.
- root `tsc --noEmit -p tsconfig.json` and `-p tooling/preview/tsconfig.json`
  — **PASS**.
- root `npm test` — **424 tests, 421 pass**, including 22 new
  `tests/camera/cameraFilters.test.ts` cases (identity at 0 % for every look,
  monotonic strength, half-strength exactness, B&W neutrality, Vivid
  saturation, warm/cool opposition, mid-grey exposure invariance, one-pass ≡
  two-pass composition, pipeline non-identity whenever a look was chosen, wash
  cap ≤ 0.22, mirror-matrix equality, clamping totality, bilingual parity).
- **Pre-existing failures NOT fixed (unchanged, out of scope):** the same 3
  language-default cases in `tests/coaching/hardening.test.ts` and
  `tests/voice/languageIntegration.test.ts` reported in the previous session.
- root `npm run build` — **PASS**, `dist/index.html` 617.98 kB.
- **Lint: NOT RUN — still none configured** (no script, no ESLint config).

### D. NOT verified (no capability here — not attempted, not claimed)

No device, no simulator. The on-device appearance of each look, the cost of
the Skia colour pass on low-end Android, and the subjective match between the
tinted viewfinder wash and the final JPEG are hardware claims. B&W is
explicitly NOT previewed live and the UI says so. No new graphics engine was
added and no frame processor exists on this foundation, so a true live filtered
viewfinder would require a different camera library (react-native-vision-camera
+ Skia frame processors) and a new native build — deliberately not done.

## Unit 36 session notes — POST-CAPTURE EDITING: crop, rotate, quick enhance

### A. Audit FIRST (what the shipped pipeline actually did)

Read before writing anything: `core/camera/cameraService`, `photoBrightness`,
`shared/camera/cameraFraming` + `cameraFilters` + `cameraControls`,
`PreviewScreen`, `GalleryPhotoPreviewScreen`, `galleryLocalDatasource`,
`useGallery`, and the browser mirror's capture path.

Found SOUND and PRESERVED, not rewritten: the single-pass Skia capture
pipeline (look ∘ strength ∘ brightness matrix + centre aspect crop, q92,
identity = no-op), Expo FileSystem legacy usage, the account-scoped
Documents/PoseAssist file layout, MMKV-metadata-only storage, MediaLibrary
save, expo-sharing with `image/jpeg`, and the React Query gallery flow with
file-existence pruning.

Found MISSING: any post-capture stage at all. `aspectCropRect` is a fixed
pre-shot centre crop, not an interaction; there was no rotation anywhere, no
adjustment of an existing photo, and no edit entry point on either preview
screen. A tilted or loosely framed shot could only be retaken.

### B. What shipped

- `shared/camera/photoEditing.ts` — the brain: quarter-turn algebra, a
  normalised crop model with ONE gesture function (so a locked ratio cannot be
  broken by any corner), aspect presets (Free / Original / 1:1 / 4:5 / 3:4 /
  16:9), four adjustments → one composed colour matrix, geometry resolution
  and a published draw transform, plus the encoding/file policy.
- `cameraFilters` now PUBLISHES its saturation / contrast / temperature /
  luminance primitives so the editor reuses the app's single definition of
  those words instead of growing a private second copy.
- `mobile/src/core/camera/photoEditor.ts` — one Skia pass (decode → rotate +
  crop draw → colour matrix → JPEG q95 → cache file). It NEVER deletes its
  input (unlike the capture pipeline, its input may be the user's saved
  photograph); the caller decides what to replace, after the write succeeded.
- Editor UI: `PhotoEditorScreen` (Skia preview through the SAME matrix and the
  SAME rotation the renderer will use), `CropFrame` (corner handles, drag to
  move, dimmed discard area, thirds guides), `EditToolPanels` (ratio chips,
  rotate left/right, Original⇄Enhanced switch + four sliders).
- Entry points: an Edit action in the capture preview AND in the saved-photo
  preview. Editing a saved photo goes through `useEditPhoto` →
  `replaceStoredPhotoFile`: new filename (expo-image caches by URI), metadata
  repointed, old file deleted last, `editedAt` recorded, `timestamp`
  deliberately unchanged so an edit does not re-sort the gallery.
- Temp-file hygiene: outputs are `poseassist-edit-*` and a prefix-scoped
  sweeper runs on preview mount.
- Browser mirror: a real editor (same shared functions, feColorMatrix preview,
  genuine canvas re-render on Apply) with its engine difference stated in the
  file header.

### C. Boundaries respected

- **Brightness is TWO systems on purpose.** Post-capture is
  `PHOTO_EDIT_ADJUST_*` (−100…+100, editor-local state); the live camera detent
  remains `BRIGHTNESS_*` (−3…+3, camera session). No shared state, and a test
  asserts the two produce different gains for the same numeric input.
- **No new dependency** (`verify-deps` passes); Skia was already in the build.
  `expo-image-manipulator` was evaluated and rejected: no brightness/contrast/
  saturation op, plus a native module and a second decode/encode.
- **No image bytes in MMKV** — metadata only, unchanged.
- **Identity is a no-op**: Apply is disabled when nothing changed and the
  renderer returns the original file, so a photo is never recompressed for
  nothing. Edited output is q95 (second generation) and is never resized.

### D. Verification ACTUALLY EXECUTED this session

- `mobile/ npx tsc --noEmit` — **PASS** (mobile deps installed for this run).
- `mobile/ npm run verify:purity` — **PASS**.
- `node mobile/scripts/verify-deps.mjs` — **PASS**.
- `node mobile/scripts/verify-reference-architecture.mjs` — **PASS**.
- root `tsc --noEmit` for `tsconfig.json` and `tooling/preview/tsconfig.json` — **PASS**.
- root `npm test` — **449 tests, 446 pass**, including 22 new
  `tests/camera/photoEditing.test.ts` cases (identity totality, quarter-turn
  algebra, crop clamping, locked-ratio survival under drag, crop carry-through
  on rotation, one-tap Enhance ≡ its four slider positions, mid-grey contrast
  invariance, warm/cool mirror symmetry, draw-transform correctness for all
  four rotations, temp-file naming).
- **Pre-existing failures NOT fixed (unchanged, out of scope):** the same 3
  language-default cases in `tests/coaching/hardening.test.ts` and
  `tests/voice/languageIntegration.test.ts` reported in earlier sessions.
- root `npm run build` — **PASS**, `dist/index.html` 633.47 kB.
- **Lint: NOT RUN — still none configured** (no script, no ESLint config).

### E. NOT verified (no capability here — not attempted, not claimed)

No device, no simulator. Unproven and therefore unclaimed: Skia pass latency
and peak memory for a 12 MP offscreen surface on low-end Android; HEIC decode
through `Skia.Data.fromURI` on iOS; `saveToLibraryAsync` behaviour for the
edited copy under iOS limited-library permission; and TalkBack/VoiceOver
traversal of the crop handles. The browser mirror runs the same maths on a
canvas and proves nothing about device performance.

## Create-Account auth repair session notes — /auth flow (audit + repair)

- **Reported bug:** tapping Create Account "did nothing" or bounced straight
  into the app. **Verified root cause (from code, not inference):** the old
  `app/auth.tsx` ran `useEffect(() => { if (session) exitAfterSuccess(); },
  [session])`, which fires ON MOUNT; with the persisted demo session
  (`demo.auth.session`, never expiring) restored at boot, `/auth` navigated
  away in its first frame. Existing session → /auth opens → session detected
  → automatic exit → /(tabs): exactly the reported chain.
- **Fix:** session-exit policy + form decisions moved into
  `shared/auth/authFlow.ts` (pure, tested). Automatic navigation now exists
  ONLY for an OAuth return the screen initiated; an existing session renders
  an explicit "already signed in" state (Continue / View Profile / demo-only
  switch-account via `signOut`) — no bounce, no loop, no pretend signup form.
  `/auth?mode=sign-up` deep links + a segmented mode control replace the
  12px text link. Supabase sign-up-without-session (email confirmation) is a
  dedicated check-your-inbox state with Resend (`auth.resend`), never a red
  error, never a navigation. Signup form: display name (optional) · email ·
  password + confirm with visibility toggles, whole-form validation before
  submit, live re-validation after first error, trimmed/lowercased email,
  untrimmed passwords, double-submit guard, return-key chain. Repository
  boundary preserved (store → repository → demo/Supabase; one client; demo
  unchanged semantically). The "What brings you here?" question was rejected:
  nothing stores/consumes it. Full write-up: `docs/create-account-auth-repair.md`.
- Preview mirror rebuilt 1:1 with the same shared validators/copy plus
  clearly-labeled scenario switches (confirmation-required, offline) —
  simulated, honestly labeled, no real-auth claims.
- **Verification ACTUALLY EXECUTED:** `mobile/ npx tsc --noEmit` PASS ·
  `verify:purity` PASS · `verify-deps` PASS · `verify-reference-architecture`
  PASS · root `tsc --noEmit` (both configs) PASS · root `npm test` 477 tests
  / 474 pass (23 new `tests/auth/authFlow.test.ts` incl. the mandatory
  Create-Account regression + exit-policy totality; the same 3 pre-existing
  language-default failures remain, unchanged, out of scope) · root
  `npm run build` PASS (`dist/index.html` 646.28 kB). Lint: still none
  configured. Device/Supabase-live validation listed in the write-up, section M.

## EAS build-failure deep audit + CNG migration session notes (audit + repair)

- **Mandate:** full independent audit of every remaining cause of
  `eas build --platform android --profile preview` failure; no assumed
  diagnoses. Everything below was verified against the actual files, then
  re-verified after each fix.
- **Issue 1 — app.json schema hard error:** top-level `splash` key is not
  valid in SDK 57 config schema (expo-doctor: "should NOT have additional
  property 'splash'"). Fix: deleted the key; the `expo-splash-screen`
  plugin entry already carries the identical image/resizeMode/backgroundColor.
- **Issue 2 — package version drift (5 packages):** `@expo/metro-runtime`,
  `expo`, `expo-constants`, `expo-router`, `expo-sharing` pinned one patch
  below the SDK 57 expectations. Fix: `npx expo install --fix`; post-fix
  `npx expo install --check` → "Dependencies are up to date".
- **Issue 3 — stale half-generated native folders (ROOT CAUSE class):**
  committed `android/` predated SDK 57 (this tracker already warned it
  "must be regenerated") and was missing every generated resource:
  no `mipmap-*/ic_launcher*.webp`, no `drawable-*/splashscreen_logo.png`,
  while `AndroidManifest`/`styles.xml` referenced them → guaranteed AAPT
  resource-link failure on EAS where prebuild never runs for committed
  native dirs. Verified by full `expo prebuild --clean` regeneration:
  diff vs the committed tree showed ONLY `debug.keystore`/`gradle-wrapper.jar`
  byte noise and zero manual customizations (the hardware-shutter
  MainActivity mod is re-applied by `plugins/withHardwareShutter.js`;
  the ML Kit pose module and hardware-shutter module autolink).
- **Decision — CNG adopted:** `android/` + `ios/` deleted, added to
  `.gitignore` + `.easignore`. EAS now prebuilds from app.json on every
  build; the app.json↔native drift failure mode cannot recur. This is
  safe because every native capability is expressed as autolinking or a
  config plugin, which the regeneration diff proved.
- **Issue 4 — missing `.gitattributes` (grad-wrapper corruption vector):**
  the documented `*.jar binary` protection was absent. Created root
  `.gitattributes` (jars/keystores/images binary, `gradlew`/`.sh` LF).
  Without it, a Windows commit re-corrupts `gradle-wrapper.jar` on the
  next native-project regeneration.
- **Issue 5 — MediaPipe stub surface/doc drift:** the stub claimed
  web-only redirect (metro actually redirects every platform, post-A1) and
  lacked `HandLandmarker` (a bare TypeError fed handDetectorService's
  catch instead of the coded error). Stub now exports
  `FilesetResolver | PoseLandmarker | HandLandmarker`, all throwing the
  coded error; header corrected. `@mediapipe/tasks-vision` stays in
  package.json on purpose: two lazy consumers still exist, resolve to the
  stub everywhere, and degrade to their documented 'unavailable' states.
- **Issue 6 — upload hygiene:** `_staging/`, `.test-build/`, zips, and
  tooling were being uploaded to EAS (entire duplicate mobile/ copies).
  Root `.easignore` created (keeps `mobile/` + `shared/`, skips the rest);
  `.gitignore` extended the same way. Nested `package.json` copies in
  `_staging`/` .test-build` can no longer confuse install detection.
- **Verified intact and NOT touched:** Supabase auth/data/storage boundary
  (single client, fail-closed in prod), the native ML Kit pose-detection
  feature (`native/vision-camera-mlkit-pose` Nitro module, frame-output
  runtime, CameraTab wiring — all present and passing export), expo-doctor
  21/21, `tsc --noEmit` PASS, production `expo export --platform android`
  PASS (6.3 MB .hbc), verify:purity PASS, verify-deps PASS,
  verify-reference-architecture PASS, clean `npm ci` PASS.
- **Runtime (not build) note kept as owner action:** `EXPO_PUBLIC_SUPABASE_URL`
  / `EXPO_PUBLIC_SUPABASE_ANON_KEY` live in gitignored `mobile/.env`; EAS
  builds need them as environment variables or production binaries ship
  with backend disabled (fail-closed by design). See session handoff.

## Final integration session — ZIP 9 baseline + four patch sources (final integration engineer)

Canonical identity of this tree: **ZIP 9** (`restore-smart-camera-app (9).zip`,
repo `abhikr24/Smart-camera-app-` @ `main`, sha256 of archive
`eef103a06415b8a8a143b145e7648d70a37de6ef3567a7d85531baafce099f11` — hash of
the downloaded archive bytes)
**+ verified PATCH-02 changes + verified PATCH-04 assets**. No patch ZIP was
used as the base; every deviation from ZIP 9 is enumerated below and is one of
exactly four file-level changes.

### Patch audit (contents are authoritative; claims were re-verified)

| Patch | Source (archive sha256 prefix) | Expected objective | Actual content | Decision |
|---|---|---|---|---|
| PATCH-01 | `patch-01zip.zip` (`d2494c7c`) | icon/splash restoration + Expo config | A bare `react-vite-tailwind` scaffold: `index.html`, `package.json` (`"name": "react-vite-tailwind"`), `vite.config.ts`, `src/{App,main}.tsx`, `src/index.css`, `src/utils/cn.ts`, `tsconfig.json`. Zero mobile assets, zero Expo files. The scaffold's `src/App.tsx` is byte-identical to this repo's preview-host scaffold — it is packaging-harness residue, not project work. | **REJECTED / NOT APPLICABLE** — unrelated Vite template. Nothing copied. The valid icon/splash work arrived under PATCH-04 instead (kept — patch *number* wrong, *change* right). |
| PATCH-02 | `remove-obsolete-mediapipe-body-pose(1)-part-{1,2}.zip` — 20 MiB raw byte-split, concatenated (`1f08a696`) | delete obsolete MediaPipe WASM body-pose service | Embedded `baseline/` is byte-identical to ZIP 9. Real changeset = `baseline→patched` diff: (1) deletion of `mobile/src/core/ml/poseDetectorService.ts`, (2) one-paragraph truth-fix in `mobile/docs/a1-native-realtime-pose.md` §10. Manifest claims independently re-verified: zero production importers in `mobile/src`, `mobile/app`, `shared/`, `tests/`, `scripts/`, `tooling/preview` (only self-export + descriptive comments in `mediapipeWebUnsupported.ts` / `metro.config.js`); `_staging` copies are archived snapshots, not app code. | **ACCEPTED — both changes applied.** `@mediapipe/tasks-vision@0.10.35` RETAINED (still used by `handDetectorService.ts` — hand detection untouched). The Metro web stub + `mediapipeWebUnsupported.ts` RETAINED for the hand landmarker. |
| PATCH-03 | `patching-native-pose-pipeline.zip` (`b6381255`) | native ML Kit pose pipeline work | Investigation/regeneration workspace: `baseline/` (ZIP 9 copy + a differing `.expo/dev/logs/export.log` dev-log only), `nitrocheck/` (pinned `nitrogen@0.37.1` toolchain), `nitroregen/` (regenerated module), `refs/` (reference package snapshots of nitro-modules 0.37.1 / vision-camera 5.2.3 / worklets). **No manifest, no report, no app-side changes.** The regenerated module tree (68 files) is **byte-identical** to ZIP 9's `mobile/native/vision-camera-mlkit-pose/` — i.e. the checked-in nitrogen output is exactly what nitrogen 0.37.1 produces for the current specs. | **VERIFIED — no code change integrated.** ZIP 9's native implementation kept intact per the "do not rewrite working native code" rule. PATCH-03 functions as proof of Nitro-codegen currency. |
| PATCH-04 | `smart-camera-app-patch-04(1)-part-{1,2}.zip` — 20 MiB raw byte-split, concatenated (`599ddce1`) | build/release configuration | Embedded `baseline/` = ZIP 9 **plus exactly two files**: `mobile/assets/icon/app-icon-store.png` (valid PNG, 1024×1024 RGB, 1,505,560 B, sha256 `66ddc3d4…` — matches its manifest) and `mobile/assets/splash/splash-icon.png` (valid PNG, 1408×768 RGB, 566,852 B). `pristine/` = pure ZIP 9. Both files are referenced by `mobile/app.json` (`expo.icon`, `expo.android.adaptiveIcon.foregroundImage`, `expo.web.favicon`, and the `expo-splash-screen` plugin `image`) and **did not exist** in ZIP 9 (verified: `assets/` dirs contained only `.gitkeep`) → real prebuild-blocking defect D1. Note: PATCH-04's manifest under-reports the splash PNG (claims 512×512/190,077 B); the actual shipped file is a different, valid 1408×768 PNG — recorded, file itself is what counts and it satisfies the plugin contract (`imageWidth: 200`, `resizeMode: contain`). | **ACCEPTED — both assets added.** This closes the PATCH-01 objective even though it arrived under PATCH-04. |

### Conflicts
- **No file-level conflicts.** PATCH-02 and PATCH-04 touch disjoint paths; PATCH-01
  and PATCH-03 contained nothing to apply. P03's copy of `native/…` matched ZIP 9
  1:1 so no "which native implementation wins" decision was required.
- Resolved-by-investigation overlaps: (a) PATCH-01 vs PATCH-04 both nominally
  "own" icon/splash → PATCH-01 had no such content; PATCH-04's was real →
  PATCH-04's kept. (b) P03's stray `.expo/dev/logs/export.log` vs ZIP 9's →
  both are generated dev-log noise under the gitignored `.expo/`; the final
  tree ships no `.expo/` directory at all (cleanup-safe: `.gitignore:13` covers
  `.expo/`; Expo regenerates it).

### Final tree vs ZIP 9 — the complete diff
1. `− mobile/src/core/ml/poseDetectorService.ts` (8,743 B WASM body-pose service — dead code, PATCH-02)
2. `~ mobile/docs/a1-native-realtime-pose.md` (§10 records the removal; PATCH-02 doc truth-fix)
3. `+ mobile/assets/icon/app-icon-store.png` (PATCH-04)
4. `+ mobile/assets/splash/splash-icon.png` (PATCH-04)
5. `− mobile/.expo/dev/logs/export.log` (generated dev-log noise; `.expo/` is gitignored — cleanup, not a patch change)

### Build / configuration status
- **Assets** — BUILD VERIFIED: `expo prebuild --platform android --clean --no-install`
  regenerated `mipmap-*/ic_launcher*.webp` (from `app-icon-store.png`) and
  `drawable-*/splashscreen_logo.png` (from `splash-icon.png`) — before the fix
  this stage failed with ENOENT (PATCH-04 defect D1).
- **Expo config** — VERIFIED: `expo-doctor` **21/21 checks passed** (includes the
  config-schema check that previously failed on the missing files); resolved
  public config inspected: no obsolete top-level `splash` key, SDK 57, package
  `com.smartphotography.assistant`, CAMERA permission (+ media-library
  permissions from the plugin set), all 9 plugins resolve including local
  `./plugins/withHardwareShutter`.
- **Dependencies** — VERIFIED UNCHANGED (ZIP 9's lockfile kept byte-identical;
  no patch proposed any dependency change and none was applied): Expo 57.0.24 ·
  RN 0.86.3 · vision-camera 5.2.3 · vision-camera-worklets 5.2.3 ·
  react-native-worklets 0.10.1 · nitro-modules 0.37.1 (== the nitrogen version
  that generated the checked-in module — PATCH-03 proof) · tasks-vision 0.10.35
  retained for hand landmarks. `expo install --check` → up to date.
- **CNG** — VERIFIED: no committed `mobile/android/` or `mobile/ios/`; both are
  gitignored and regenerate cleanly from config (prebuild run proved it at
  integration time; the regenerated `android/` was deleted afterwards so the
  final tree stays CNG-pure). `.easignore` keeps `mobile/`+`shared/` uploads
  and skips `_staging/`/`.test-build/`/tooling — intentionally retained
  (rule: they are excluded from builds, not deleted).
- **EAS preview profile** — STATICALLY VERIFIED: `eas.json` preview =
  `distribution: internal`, `android.buildType: apk` (the intended
  `eas build --platform android --profile preview` command).

### Validation ACTUALLY EXECUTED on the final tree (exact command → result)
- `mobile/ npm ci --no-audit --no-fund` → PASS (clean install from lockfile, 634 pkgs)
- root `npm ci` → PASS (99 pkgs, preview-tooling host only)
- `node mobile/scripts/verify-deps.mjs` → PASS (28/28 bare imports declared)
- `node mobile/scripts/verify-purity.mjs` → PASS (zero DOM/web leakage in mobile+shared)
- `node mobile/scripts/verify-reference-architecture.mjs` → PASS
- `mobile/ npx tsc --noEmit` → PASS (0 errors — with PATCH-02 deletion in place)
- root `npx tsc --noEmit` (tooling+shared) → PASS; `tsc -p tsconfig.tests.json` → PASS
- `node mobile/scripts/verify-all.mjs` → PASS (aggregate)
- `npm test` (reference-domain suite) → **562/562 PASS**
- `npx expo install --check` → up to date
- `npx expo-doctor` → **21/21 checks passed**
- `npx expo config --type public` → resolves; all asset refs point at real files
- `npx expo prebuild --platform android --clean --no-install` → **PASS** (native
  dir created; launcher icons + splash generated from the restored assets;
  CAMERA permission in generated manifest; ML Kit `pose-detection-accurate
  :18.0.0-beta5` linked in module gradle)
- `npx expo export --platform android` → **PASS** (6.3 MB Hermes bytecode
  bundle — production Metro graph resolves with the deleted module gone)
- root `npm run build` (preview tooling) → PASS

### Native pose pipeline (VisionCamera → ML Kit → NativePoseFrame → JS runtime → analysis → coaching)
- Camera frames → `CameraFrameOutput` worklet (`useNativePoseFrameOutput.ts`,
  faithful 1:1 replication of vision-camera 5.2.3 `useFrameOutput` wiring:
  `createFrameOutput` → worklets `createRuntimeForThread` → `setOnFrameCallback`,
  `frame.dispose()` in `finally` on every arrival) — STATICALLY VERIFIED.
- Native detector = **real Google ML Kit** (`HybridPoseDetector.kt`:
  `PoseDetection.getClient(AccuratePoseDetectorOptions…STREAM_MODE)`,
  `InputImage.fromMediaImage(mediaImage, rotationDegrees)`, 33 landmarks in
  BlazePose order with `inFrameLikelihood`, bundled accurate model — no runtime
  model download, `PoseDetector.close()` on dispose) — STATICALLY VERIFIED;
  Nitro codegen currency PROVEN by PATCH-03 (byte-identical regen).
- JS bridge: `NativePoseFrame` → `runOnJS` → `PoseFrameRuntime` → shared
  adapter → `poseAnalysisEngine`/`matchFromDecision` → coaching/guidance in
  `CameraTab.tsx` — STATICALLY VERIFIED by code audit + production export;
  NO fake/placeholder/JPEG/base64/still-photo primary path exists anywhere in
  the pipeline (explicitly confirmed in `nativePosePlugin.ts` and the plugin's
  `src/index.ts`).
- **RUNTIME (on-device landmark acquisition) — NOT VERIFIED**: requires a
  physical Android device; camera opens ≠ pose works. Remains an owner action.

### APK status (explicit states, nothing claimed beyond evidence)
| Item | State |
|---|---|
| EAS build attempted | **NO** — `eas whoami` → "Not logged in", no `EXPO_TOKEN` in environment |
| EAS build successful | NO (not executed) |
| APK produced | NO |
| Local Gradle APK build | BLOCKED — no JDK, no Android SDK in this environment |
| APK installed on physical Android | NO |
| Real camera tested | NO — NOT VERIFIED |
| Real native pose tested | NO — NOT VERIFIED |
| Native-path release blocker (old "MediaPipe native path" blocker above) | SUPERSEDED at build/static level by the A1 VisionCamera→ML Kit pipeline; **device-level closure still required** before store submission |
