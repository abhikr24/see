context/specs/13-capture-processing-preview-save.md# Unit 13 - Capture + Processing + Preview + Save (Device Only)
**File Path:** context/specs/13-capture-processing-preview-save.md
**Build Plan Ref:** Unit 13 - Phase 3 - Dependencies: Unit 12

## 1. Goal
Build Capture + Processing + Preview + Save flow device-only: Manual capture
from Unit 12 bottom bar, Timer countdown Reanimated 3-2-1 with haptics,
Processing screen, Preview Screen with Save/Share/Delete/Retake/Done, Save
to Device via expo-media-library (NEVER Supabase), MMKV metadata, Retake
same pose, Done → Gallery.

Visible Result: Photo taken → preview → saved to device gallery → appears
in app Gallery.

## 2. Design

**Capture Flow:**
1. Tap Capture button 72 circle in Unit 12 State 2
2. If timer off: immediate capture + Haptics.impactAsync('medium')
3. If timer 3/5/10: Countdown overlay 3-2-1 full screen
4. Processing: loader 0.5s
5. Preview: captured image + actions

**Timer Countdown:**
- Full screen overlay bg black 60%
- Center number Display 96 bold white
- Reanimated: withSequence scale 1.0→1.2→1.0 per number
- Haptics.impactAsync('light') each tick
- Haptics.impactAsync('heavy') on final capture
- 3s mode: 3-2-1, 5s: 5-4-3-2-1, 10s: 10-9...1

**Processing Screen:**
- Full screen bg black 60%, center ActivityIndicator primary #2563EB
- Text "Processing..." Body 16 white, 0.5-1s delay

**Preview Screen:**
- Full screen Image from captured URI
- Top bar: Close x 28 white touch 48x48, Share share-variant 28 white,
  Delete delete 28 white
- Bottom bar: bg black 60% height 120
  - Retake: replay 24 white + "Retake" Body 14 → back to Camera State 2
  - Save: Primary #2563EB radius md 12 "Save" Button 16 600 Title Case
  - Done: After save, "Done" → /(tabs)/gallery

**Save to Device (NEVER Supabase):**
- Use MediaLibrary.saveToLibraryAsync(uri) from expo-media-library
- Check photos permission from Unit 04
- If denied: explanation UI + Open Settings
- Save MMKV metadata: galleryStore {id, poseId, imagePath, filterUsed,
  timestamp}
- After save: SnackBar "Saved to gallery" success #10B981

**Retake:** router.replace('/(tabs)/camera?poseId=' + poseId)
**Done:** router.replace('/(tabs)/gallery')

## 3. Implementation

**Files to Create/Modify:**

1. **src/core/camera/cameraService.ts** (UPDATE)
   - async takePicture(cameraRef): cameraRef.current?.takePictureAsync()
   - Returns { uri, width, height }
   - Haptics.impactAsync('heavy') on capture

2. **src/features/camera/presentation/components/CountdownOverlay.tsx**
   - Props: seconds number, onComplete callback
   - Reanimated: useSharedValue scale, useAnimatedStyle
   - useEffect countdown timer, each second: update number + haptic light
   - Full screen absolute, bg black 60%, center number Display 96 white
   - withSequence scale animation per tick
   - onComplete → trigger capture

3. **src/features/camera/presentation/components/ProcessingOverlay.tsx**
   - Full screen absolute bg black 60%
   - ActivityIndicator primary + "Processing..." Body 16 white

4. **app/camera/preview.tsx** (NEW route)
   - useLocalSearchParams<{ uri: string, poseId?: string }>()
   - Render PreviewScreen

5. **src/features/camera/presentation/screens/PreviewScreen.tsx**
   - useState isSaved false
   - Image source={{ uri }} full screen resizeMode contain bg black
   - Top bar: Close → router.back(), Share → Sharing.shareAsync(uri),
     Delete → Alert confirm → delete file → router.back()
   - Bottom bar: Retake → router.replace('/(tabs)/camera?poseId=' + poseId),
     Save → saveToGallery(), Done → router.replace('/(tabs)/gallery')
   - saveToGallery(): check permission → MediaLibrary.saveToLibraryAsync(uri)
     → save metadata to MMKV galleryStore → SnackBar success → isSaved true

6. **src/features/gallery/data/datasources/galleryLocalDatasource.ts** (NEW)
   - MMKV instance for gallery
   - savePhoto(photo): add to galleryStore
   - getPhotos(): return all sorted desc by timestamp
   - deletePhoto(id): remove from galleryStore + delete file

7. **src/features/gallery/domain/entities/galleryPhoto.ts** (NEW)
   - interface GalleryPhoto { id, poseId, imagePath, filterUsed, timestamp }

8. **src/features/camera/presentation/screens/CameraTab.tsx** (UPDATE)
   - Capture button onPress:
     - Haptics.impactAsync('medium')
     - If timer off: takePicture → navigate to preview
     - If timer on: show CountdownOverlay → onComplete takePicture
     - Show ProcessingOverlay 0.5s
     - router.push('/camera/preview?uri=' + uri + '&poseId=' + poseId)

## 4. Dependencies
- NEW: expo-media-library ~17.0.0, expo-haptics ~14.0.0, expo-sharing ~14.0.0
  (sharing may already be from Unit 10)
- Reuse: expo-camera, MMKV, Reanimated

## 5. Verification Checklist
- [ ] Capture tap: Haptics medium + takePicture returns URI
- [ ] Timer countdown: 3-2-1 full screen Display 96 white Reanimated scale
  1.0→1.2→1.0, haptic light per tick, heavy on capture
- [ ] Processing overlay 0.5s ActivityIndicator primary
- [ ] Preview screen: full screen image, top Close/Share/Delete, bottom
  Retake/Save/Done
- [ ] Save: MediaLibrary.saveToLibraryAsync → photo appears in device gallery
- [ ] MMKV metadata saved: id, poseId, imagePath, filter, timestamp
- [ ] SnackBar "Saved to gallery" success #10B981
- [ ] Retake: back to Camera State 2 same poseId
- [ ] Done: → /(tabs)/gallery
- [ ] Share: expo-sharing shareAsync with image
- [ ] Delete: confirm Alert → delete file + MMKV → pop
- [ ] Storage permission: denied → explanation + Open Settings
- [ ] NEVER Supabase for photos: no Supabase storage code
- [ ] Web: "Capture works on phone only" placeholder
- [ ] progress-tracker.md updated
