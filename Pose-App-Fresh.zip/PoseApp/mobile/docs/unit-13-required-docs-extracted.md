docs/ai-workflow-rules.md

THEN ADD per task type A through W (same mapping as original, with RN+Expo
equivalents for all Flutter-specific references).

## 5-12. REMAINING SECTIONS

All remaining sections (Documentation Dependency Rules, Development Workflow,
Verification Workflow, Documentation Update Workflow, Progress Tracking
Workflow, Resume Workflow, Forbidden Actions, Final Mandatory Rules) follow
the exact same structure and rules as the original Flutter version with
these global substitutions applied throughout:

- Flutter/Dart → React Native/TypeScript
- Riverpod → Zustand + React Query
- GoRouter → Expo Router
- Hive → MMKV + AsyncStorage
- Widget → Component
- pubspec.yaml → package.json + app.json
- flutter build → eas build
- StatelessWidget/ConsumerWidget → React.FC functional component
- StatefulWidget → React.FC + useState/useEffect
- build() method → JSX return
- CustomPainter → @shopify/react-native-skia Canvas
- AnimationController → react-native-reanimated
- WidgetsBindingObserver → AppState from react-native
- runZonedGuarded → React ErrorBoundary
- MaterialApp.router → Expo Router Slot/StackAGENTS.md# AGENTS.md — Smart Photography Assistant | React Native + Expo
## Operating System V2 (Exhaustive)

CRITICAL: This file is a ROUTER OS, not a source of truth. Never implement
from this file alone. All decisions MUST come from the docs listed in
Section 5. This file answers only: "If user asks X, which docs must I read
first?"

Project: Smart Photography Assistant — React Native + Expo SDK 52 +
TypeScript + Zustand + React Query + Supabase JS + @mediapipe/tasks-vision
Pose 33 landmarks + expo-camera + MMKV + Expo Router + expo-speech +
expo-permissions + expo-image + @shopify/react-native-skia +
react-native-reanimated

Structure:

/
├── AGENTS.md
├── ENV-SETUP.md
├── .cursorrules
├── docs/
│   ├── project-overview.md
│   ├── architecture.md
│   ├── code-standards.md
│   ├── ai-workflow-rules.md
│   ├── ui-context.md
│   ├── ui-recommendations.md
│   └── progress-tracker.md
├── app/
│   ├── _layout.tsx
│   ├── (tabs)/
│   │   ├── _layout.tsx
│   │   ├── index.tsx
│   │   ├── explore.tsx
│   │   ├── camera.tsx
│   │   ├── gallery.tsx
│   │   └── profile.tsx
│   ├── splash.tsx
│   ├── welcome.tsx
│   ├── onboarding.tsx
│   ├── permissions.tsx
│   ├── auth.tsx
│   ├── search.tsx
│   ├── settings.tsx
│   └── pose/[id].tsx
├── src/
│   ├── core/
│   │   ├── theme/
│   │   │   ├── colors.ts
│   │   │   ├── spacing.ts
│   │   │   ├── radius.ts
│   │   │   ├── typography.ts
│   │   │   └── theme.ts
│   │   ├── constants/
│   │   │   └── appConstants.ts
│   │   ├── utils/
│   │   │   └── logger.ts
│   │   ├── ml/
│   │   │   ├── poseDetectorService.ts
│   │   │   ├── poseMatchCalculator.ts
│   │   │   ├── guidanceGenerator.ts
│   │   │   ├── jointColorMapper.ts
│   │   │   ├── gestureDetector.ts
│   │   │   └── ttsService.ts
│   │   ├── camera/
│   │   │   └── cameraService.ts
│   │   ├── permissions/
│   │   │   └── permissionService.ts
│   │   ├── network/
│   │   │   └── supabaseClient.ts
│   │   └── error/
│   │       ├── appError.ts
│   │       ├── errorTypes.ts
│   │       └── errorHandler.ts
│   ├── features/
│   │   ├── auth/
│   │   ├── poses/
│   │   ├── camera/
│   │   ├── gallery/
│   │   ├── favorites/
│   │   ├── profile/
│   │   ├── settings/
│   │   ├── search/
│   │   └── onboarding/
│   ├── shared/
│   │   ├── components/
│   │   ├── hooks/
│   │   └── stores/
│   └── demo/
│       ├── mockSupabase.ts
│       ├── mockAuth.ts
│       └── mockData.ts
├── assets/
│   ├── images/
│   ├── poses/
│   ├── data/
│   ├── icon/
│   └── splash/
├── app.json
├── package.json
├── tsconfig.json
└── .env.example

## 1. PURPOSE & CORE PRINCIPLES

1. Documentation = Source of Truth. Code vs Doc conflict → Doc wins unless
   user approves change.
2. Never Guess. Missing/Ambiguous/Conflicting → STOP per ai-workflow-rules.md
   Rule 4,5.
3. One Milestone at a Time. Search Before Creating. Reuse > Extend > Create.
4. Storage Invariant: User Photos → Device Storage ONLY (expo-media-library).
   NEVER Supabase in V1. Supabase = metadata only.
5. MediaPipe Invariant: All pose detection local, on-device, real-time via
   @mediapipe/tasks-vision. No upload of camera frames. Raw landmarks not
   stored permanently. Only 1 camera session at a time. Release immediately
   on unmount/background.
6. Auth Invariant: read-before-login, create-after-login. Explore without
   login allowed, but Favorites/Save/Profile requires auth. Guest mode is
   NOT part of V1.

## 2. MANDATORY STARTUP PROCEDURE (For EVERY Task)

STEP 1: Read AGENTS.md fully.
STEP 2: Read docs/progress-tracker.md fully → Identify Current Phase,
        Current Goal, In Progress, Open Questions, Architecture Decisions,
        Session Notes, Known Issues.
STEP 3: Classify task using Section 3 Engine.
STEP 4: Get doc list using Section 4 Matrix (EXHAUSTIVE). Follow it strictly.
STEP 5: Read required docs IN ORDER: project-overview → architecture →
        code-standards → ui-context + ui-recommendations (if UI) →
        ai-workflow-rules → progress-tracker.
STEP 6: Summarize understanding + Milestone split plan + Docs you read →
        Wait for Approval.
STEP 7: Code ONLY after approval. Never skip.

## 3. TASK CLASSIFICATION ENGINE (With Priority)

Priority Order (High to Low - Top wins if multi-system):

1. Architecture Change / Scope Change
2. Documentation / Progress Tracker Update
3. Authentication & Permissions & Session
4. MediaPipe & Pose Matching & Voice Guidance (TTS)
5. Camera Feature (Preview, Controls, Capture, Gestures)
6. Supabase / Database / MMKV Cache / Image Caching
7. Navigation / Expo Router / Deep Links
8. UI Task (Any Screen)
9. Gallery / Preview / Save
10. Performance / Logging / Bug Fix / Testing / Refactoring

Keyword → Primary Type:

- Splash, Welcome, Onboarding, App Launch → Onboarding Flow Task
- Home Tab, Dashboard, Stats, Quick Actions → Home Task
- Explore Tab, Browse Poses, Featured Collections, Pose Grid → Explore Task
- Search Bar, Filter Panel, Filter by Category/Difficulty/Tags → Search Task
- Pose Details, Pose Info, Use This Pose → Pose Details Task
- Camera Preview, Flash Toggle, Timer, Switch Camera → Camera Controls Task
- Capture, Take Photo, Countdown, Auto-capture, Gesture → Capture Task
- Voice Guidance, TTS, Speak Instructions, expo-speech → Voice Task
- MediaPipe, 33 Landmarks, Body Tracking, Pose Detection → MediaPipe Task
- Pose Matching, Pose Similarity, Match Percentage → Pose Matching Task
- Preview Screen, Photo Preview, Retake, Save Photo → Preview/Gallery Task
- Gallery Tab, Saved Photos, Device Photos → Gallery Task
- Favorites, Favourites, Recent Poses, User Statistics → Favorites Task
- Login, Sign In, Google Sign In, Email Sign In, Auth → Auth Task
- Permission, Camera Permission, Storage Permission → Permission Task
- Profile Tab, User Profile, Preferences, Theme → Profile/Settings Task
- Supabase, PostgreSQL, Database, Table, RLS → Database Task
- MMKV, Local Cache, Search History, Recently Viewed → Cache Task
- expo-image, Thumbnails, Optimized Images → Image Caching Task
- Expo Router, Routing, Navigation, Tabs, Deep Link → Navigation Task
- Network Failure, Offline, No Internet, Retry → Error Handling Task
- Performance, Lazy Loading, Camera Optimization, Battery → Performance Task
- Logger, Logging, Debug Logs, Error Logs → Logging Task
- Empty State, Loading State, Skeleton, Shimmer → UI States Task
- Color, Typography, Spacing, Radius, Icon, Button → Design System Task
- Animation, Transition, Micro-interaction, Reanimated → Animation Task
- Bug, Fix, Crash, Not Working → Bug Fix Task
- Refactor, Cleanup, Improve Code → Refactoring Task
- Test, Unit Test, Integration Test → Testing Task
- Architecture, Tech Stack, Storage Model → Architecture Task
- Premium, In-App Purchase, Future Feature → Scope Control Task
- Progress Tracker, Documentation Update → Documentation Task

MULTIPLE TASK RULE: If request touches multiple systems, COMBINE doc sets
(union). If unsure, READ ALL 7 FILES. Never guess.

## 4. TASK → DOCUMENTATION MATRIX (EXHAUSTIVE)

ALWAYS READ for EVERY task: docs/progress-tracker.md + docs/ai-workflow-rules.md

THEN ADD per task type A through W (same mapping as original, with RN+Expo
equivalents for all Flutter-specific references).

## 5-12. REMAINING SECTIONS

All remaining sections (Documentation Dependency Rules, Development Workflow,
Verification Workflow, Documentation Update Workflow, Progress Tracking
Workflow, Resume Workflow, Forbidden Actions, Final Mandatory Rules) follow
the exact same structure and rules as the original Flutter version with
these global substitutions applied throughout:

- Flutter/Dart → React Native/TypeScript
- Riverpod → Zustand + React Query
- GoRouter → Expo Router
- Hive → MMKV + AsyncStorage
- Widget → Component
- pubspec.yaml → package.json + app.json
- flutter build → eas build
- StatelessWidget/ConsumerWidget → React.FC functional component
- StatefulWidget → React.FC + useState/useEffect
- build() method → JSX return
- CustomPainter → @shopify/react-native-skia Canvas
- AnimationController → react-native-reanimated
- WidgetsBindingObserver → AppState from react-native
- runZonedGuarded → React ErrorBoundary
- MaterialApp.router → Expo Router Slot/Stack

--- NEXT REQUIRED DOCUMENT ---

docs/project-overview.md# Project Overview — Smart Photography Assistant

## Application Overview

Smart Photography Assistant is an AI-powered camera application built with
React Native + Expo that helps anyone capture better photos without requiring
photography skills, expensive equipment, or another person to take the
picture. Acting like a personalized AI photographer in the user's pocket,
the app guides users through professional poses using a curated pose library
and provides real-time feedback with MediaPipe pose tracking (33 body
landmarks via @mediapipe/tasks-vision), visual overlays, voice instructions
via expo-speech, gesture controls, and intelligent auto-capture.

Platforms: Android (Google Play), iOS (Apple App Store), Web (PWA via Expo)

## Project Goals

1. Design, develop, test, and prepare Version 1 of the application for
   production release on Android, iOS, and Web via EAS Build.
2. Build and integrate a curated pose library containing approximately 400
   professionally organized reference poses across multiple photography
   categories (Solo, Couple, Friends, Family, Travel, Fashion, Gym, Café,
   Office, Street, Wedding, Selfie, and more). Reference images provided
   separately; generating images is outside scope.
3. Enable users to accurately recreate reference poses using real-time pose
   guidance powered by MediaPipe Pose (33 body landmarks) on-device.
4. Provide intelligent pose matching with both manual capture and automatic
   capture once the required pose match threshold is reached.
5. Enable users to quickly discover suitable poses through search, filters,
   curated collections, and category-based browsing.
6. Deliver a clean, minimalist, intuitive, and beginner-friendly user
   experience that allows first-time users to understand and use the
   application with minimal onboarding.
7. Support gesture-based photo capture (👍, ✋, ✌) to allow hands-free
   photography while posing.
8. Provide real-time visual guidance and optional voice guidance to help
   users continuously adjust their posture until the selected pose is matched.
9. Ensure smooth camera performance (expo-camera), efficient MediaPipe
   processing, and reliable operation across Android, iOS, and Web while
   maintaining efficient resource usage.
10. Design a scalable, modular architecture that allows future expansion
    with additional pose collections, new photography features, AI-powered
    capabilities, and platform enhancements without requiring major
    architectural redesign.

## Core User Flow

Splash → Welcome → Onboarding → Permissions → Login → Home → Explore →
Pose Details → Use This Pose → Camera (Active) → Capture → Preview → Gallery

## Main Screens

- Splash Screen
- Welcome Screen
- Onboarding (3 slides)
- Permissions
- Login (Email + Google)
- Home Tab
- Explore Tab
- Camera Tab (State 1: No Pose, State 2: Active Camera)
- Gallery Tab
- Profile Tab

## Step-by-Step Core User Flow

### Screen 1 — Splash Screen
Purpose: Initialize app, prepare session, perform startup tasks.
UI: Center animated logo + app name, bottom loading indicator.
Background Tasks: Check first launch (MMKV), check auth, load theme,
load language, load cached pose metadata.
Navigation: 0.5-1s then auto-navigate to Welcome or Home.

### Screen 2 — Welcome Screen
Purpose: Introduce app value to first-time users.
UI: Top illustration, Title "Take Better Photos with Perfect Poses",
Subtitle, Primary "Get Started", Secondary "Sign In".
Navigation: Get Started → Onboarding, Sign In → Login.

### Screen 3 — Onboarding (3 Slides)
Slide 1: Discover Poses — Browse 400+ curated poses.
Slide 2: Live Pose Guidance — Real-time MediaPipe tracking.
Slide 3: Automatic Capture — Auto-capture at match threshold.
Navigation: Continue → Permissions, Skip → Permissions.

### Screen 4 — Permissions
Camera Permission: Live preview + MediaPipe + guidance.
Storage/Photos Permission: Saving + gallery.
Notifications: NOT requested in V1 onboarding.
Navigation: After permissions → Login.

### Screen 5 — Login
Options: Continue with Google, Continue with Email.
Note: Guest/anonymous mode is NOT part of V1. Unauthenticated users may
only browse the pose library (read-only). Camera, capture, favourites,
statistics and personal settings require authentication.

## Main Application — 5-Tab Bottom Navigation

🏠 Home | 🔍 Explore | 📷 Camera | 🖼 Gallery | 👤 Profile

### Home Tab
Personalized greeting, Hero Card (Start Camera + Continue Last Pose),
Recent 4 poses, Welcome card for first-time, Quick nav.

### Explore Tab
Search Bar, Filter Panel, Featured Collections, Category Collections,
Pose Grid, Pose Details.

### Camera Tab
State 1 (No Pose): Choose a Pose + Recent + Explore CTA + Gallery shortcut.
State 2 (Active): Live preview + MediaPipe overlay + match % + guidance +
controls (Flash, Timer, Settings, Capture, Switch, Filters, Zoom).
Capture Methods: Manual, Gesture, Auto.
Preview Screen: Save, Share, Delete, Retake, Done.

### Gallery Tab
App photo grid (device-only), Pose History, Photo Preview,
Share/Delete/Retake.

### Profile Tab
Profile header, Stats, Favourite Poses, Storage management, Settings,
Logout, Guest Login CTA.

## Features by Category (V1 Scope)

1. User Onboarding & Authentication
2. Home Experience
3. Pose Discovery
4. Pose Library (~400 poses, 12+ categories)
5. AI Pose Guidance (MediaPipe on-device)
6. Camera Experience (expo-camera)
7. Photo Management (expo-media-library, device-only)
8. User Profile
9. Application Settings

## In Scope (V1)
- Cross-platform: Android + iOS + Web via Expo
- Google Sign-In + Email Sign-In
- 400 curated poses, 12+ categories
- MediaPipe Pose 33 landmarks on-device
- Manual / Gesture / Auto capture
- Local photo storage (expo-media-library)
- 5-tab navigation (Expo Router)
- Full settings suite
- No guest mode — unauthenticated = browse-only

## Out of Scope (V1)
Cloud photo backup, social features, advanced AI (beauty/face/age),
professional camera controls, photo editing, premium/monetization,
advanced personalization, community uploads, video tutorials.

## Success Criteria (9)
1. Complete end-to-end user flow
2. Complete pose library (~400)
3. AI pose guidance works correctly
4. Camera experience fully functional
5. Gallery works correctly
6. Profile & Settings complete
7. Performance requirements met
8. Cross-platform readiness (Android + iOS + Web)
9. Production readiness (no placeholders, stable)

## Definition of Done
All in-scope features implemented, end-to-end flow works, ready for
Play Store + App Store + Web deployment via EAS Build.

--- NEXT REQUIRED DOCUMENT ---

docs/architecture.md# Architecture — Smart Photography Assistant (React Native + Expo)

## Technology Stack

| Layer | Technology | Role |
|---|---|---|
| Language | TypeScript (strict) | Primary language |
| Framework | React Native + Expo SDK 52 | Cross-platform Android/iOS/Web |
| State Mgmt | Zustand + React Query | Zustand for sync, React Query for async |
| Backend | Supabase | Auth, PostgreSQL, Storage (metadata only) |
| Database | PostgreSQL (Supabase) | User data, pose metadata, favorites |
| Auth | Supabase Auth + expo-auth-session | Google, Email, session management |
| Pose Detection | @mediapipe/tasks-vision | 33 landmarks, on-device, real-time |
| Camera | expo-camera | Preview, capture, controls |
| Local Storage | MMKV (react-native-mmkv) | Fast sync cache, settings, recents |
| Device Storage | expo-media-library | Save photos to device gallery |
| Cloud Storage | Supabase Storage | Pose assets only if needed |
| Networking | @supabase/supabase-js + fetch | Backend communication |
| Navigation | Expo Router (file-based) | Routing, tabs, deep links |
| Voice | expo-speech | Optional spoken pose guidance |
| Permissions | expo-camera/media-library perms | Runtime permission requests |
| Image Caching | expo-image | Built-in caching, optimized |
| Logging | Custom AppLogger | Debug, info, error levels |
| Build | EAS Build + EAS Submit | APK/AAB, IPA, Web |
| Version Control | Git & GitHub | Source management |

## Technology Selection Principles
- React Native + Expo is the only framework for V1.
- TypeScript strict mode is mandatory.
- Supabase is the single backend.
- @mediapipe/tasks-vision is the only pose detection engine.
- User photos stored locally via expo-media-library, NEVER cloud.
- Single codebase for Android + iOS + Web.
- No new tech without documented approval.

## Storage Model (3 Layers)

### Database (Supabase PostgreSQL)
Stores: User accounts, profiles, preferences, favorites, pose metadata,
user statistics, app configuration.
NEVER stores: Original user photographs.

### File Storage
User Photos: Device only via expo-media-library. App stores metadata
references but never uploads image files.
Pose Assets: Bundled in assets/poses/ for V1.

### Local Cache (MMKV)
Cached data: Pose metadata, recently viewed/used poses, search history,
user preferences, auth session, thumbnails.
Cache is regenerable, never source of truth.

## Storage Rules
1. User photos → device ONLY.
2. Supabase → metadata only.
3. Database = source of truth for synced data.
4. Cache = performance only, clearable.
5. No duplication between DB and file storage.

## Authentication & Access Model

Read-before-login, create-after-login.
Guest mode is NOT part of V1.

### Unauthenticated Users (Browse-Only)
Can: View splash/welcome/onboarding, browse pose library, search poses,
filter poses, view pose details, navigate app.
Cannot: Open camera, capture photos, save photos, view gallery, create
favorites, access statistics, use gesture/voice, save preferences, create
backend records.

### Authenticated Users (Full Access)
Can: Use camera, start pose sessions, MediaPipe tracking, live match %,
visual/voice guidance, gesture capture, capture/save photos, view gallery,
manage favorites, access statistics, update profile, configure settings.

### Data Ownership
Every user owns only their own data. Users cannot access/modify/delete
another user's information. Ownership enforced via Supabase RLS.

## Architecture Invariants (14)

1. On-Device Pose Processing: All MediaPipe detection local. No frame upload.
2. Read-Only Before Auth: Unauthenticated = browse-only, no persistent data.
3. Auth Before Data Creation: Features creating data require authentication.
4. Data Ownership: User owns only their data.
5. Row Level Security: Every Supabase table has RLS. No exceptions.
6. Local-First Photo Storage: Photos on device via expo-media-library.
7. Single Source of Truth: Each data piece has one authoritative source.
8. Separation of Responsibilities: UI ≠ Business Logic ≠ Data Access.
9. Non-Blocking UI: Heavy ops async, never block main thread.
10. Camera Lifecycle: Active only on camera screen, release on unmount.
11. Admin-Controlled Pose Library: Users cannot modify pose metadata.
12. V1 Scope Protection: Out-of-scope features not partially implemented.
13. Privacy by Default: Minimum data collection.
14. Future Extensibility: New features extend, not replace, architecture.

## MediaPipe Architecture

Detection: @mediapipe/tasks-vision PoseLandmarker, 33 landmarks per frame.
Pipeline: Select pose → expo-camera preview → frame extraction →
MediaPipe detect → landmark processing → pose comparison → match % →
guidance → capture → save locally.
Principles: All local, real-time, raw landmarks not stored permanently,
MediaPipe = detection only (business logic separate).

## Error Handling Strategy

Network: Core camera works offline. Supabase features show retry.
Permission: Explain + retry + open settings via Linking.openSettings().
Camera: Clear error + retry + stable state + stop MediaPipe.
Auth: Remain on screen + clear message + retry.
General: Never crash on expected error. Preserve user data. Human-readable
messages. Log unexpected errors.

## Performance Strategy

Caching: MMKV for metadata, expo-image for images.
Lazy Loading: On-demand collections, detail on open, images on visible,
camera on tab, MediaPipe on camera active.
Image Loading: expo-image with cache, appropriate sizes, release on unmount.
Camera: Single session, stop on unmount/background, release immediately.
Battery/Memory: MediaPipe only when needed, no background processing,
minimize network via cache.

--- NEXT REQUIRED DOCUMENT ---

docs/code-standards.md
Markdown

# Code Standards — React Native + Expo + TypeScript

## General Coding Principles

Readability: Clear, descriptive names. No abbreviations unless standard.
Simplicity: Simplest solution satisfying requirements. No premature optimization.
Single Responsibility: One component/class/function = one task.
Modularity: Small, reusable, independent modules.
Code Reuse: Search before creating. Reuse > Extend > Create.
Consistency: Follow established patterns. Similar problems = similar solutions.
Separation of Concerns: UI = presentation only. Business logic outside components.
Data access outside business logic.
Documentation Compliance: Follow all docs. Doc wins over code.
Scope Control: Current milestone only. No extra features.
Maintainability: Easy to modify, test, debug, extend.
Quality: No TypeScript errors. No warnings. No dead code.
Architectural Compliance: Never bypass documented architecture.

## Folder & Project Structure

app/                        # Expo Router file-based routes
├── _layout.tsx             # Root layout (providers, theme, auth guard)
├── (tabs)/                 # Bottom tab navigator group
│   ├── _layout.tsx         # Tab bar configuration
│   ├── index.tsx           # Home tab
│   ├── explore.tsx         # Explore tab
│   ├── camera.tsx          # Camera tab
│   ├── gallery.tsx         # Gallery tab
│   └── profile.tsx         # Profile tab
├── splash.tsx              # Splash screen
├── welcome.tsx             # Welcome screen
├── onboarding.tsx          # Onboarding 3 slides
├── permissions.tsx         # Permissions flow
├── auth.tsx                # Login/Signup
├── search.tsx              # Full-screen search
├── settings.tsx            # Settings screen
└── pose/[id].tsx           # Dynamic pose detail

src/
├── core/
│   ├── theme/              # Design tokens
│   │   ├── colors.ts       # Light + Dark color objects
│   │   ├── spacing.ts      # 8pt grid spacing scale
│   │   ├── radius.ts       # Border radius scale
│   │   ├── typography.ts   # Inter font styles
│   │   └── theme.ts        # useTheme() hook
│   ├── constants/
│   │   └── appConstants.ts # App name, MMKV keys, limits
│   ├── utils/
│   │   └── logger.ts       # AppLogger singleton
│   ├── ml/                 # MediaPipe services
│   │   ├── poseDetectorService.ts
│   │   ├── poseMatchCalculator.ts
│   │   ├── guidanceGenerator.ts
│   │   ├── jointColorMapper.ts
│   │   ├── gestureDetector.ts
│   │   └── ttsService.ts
│   ├── camera/
│   │   └── cameraService.ts # Camera singleton
│   ├── permissions/
│   │   └── permissionService.ts
│   ├── network/
│   │   └── supabaseClient.ts # Supabase init + demo fallback
│   └── error/
│       ├── appError.ts
│       ├── errorTypes.ts
│       └── errorHandler.ts
├── features/
│   ├── auth/
│   │   ├── data/           # datasources, repositories
│   │   ├── domain/         # entities, usecases
│   │   └── presentation/   # screens, components, hooks
│   ├── poses/
│   ├── camera/
│   ├── gallery/
│   ├── favorites/
│   ├── profile/
│   ├── settings/
│   ├── search/
│   └── onboarding/
├── shared/
│   ├── components/         # Reusable UI (AppImage, AppButton, etc.)
│   ├── hooks/              # Custom hooks (useDebounce, useAuth, etc.)
│   └── stores/             # Zustand stores (authStore, themeStore, etc.)
└── demo/                   # Demo/mock data for offline development
    ├── mockSupabase.ts
    ├── mockAuth.ts
    └── mockData.ts

## File Naming Conventions

Files: kebab-case for components (pose-card.tsx), camelCase for utilities
  (poseMatchCalculator.ts)
Components: PascalCase (PoseCard, CameraPreview)
Hooks: camelCase with use prefix (usePoseDetection, useAuth)
Stores: camelCase with Store suffix (authStore, cameraStore)
Services: camelCase with Service suffix (cameraService, ttsService)
Types/Interfaces: PascalCase (PoseModel, UserType, AuthState)
Constants: UPPER_SNAKE_CASE (MAX_RECENT_POSES, API_BASE_URL)

## TypeScript Standards

- Strict mode enabled in tsconfig.json
- No `any` types — use proper interfaces/types
- Prefer `interface` for objects, `type` for unions/intersections
- Use `readonly` for immutable data
- Proper null/undefined handling: optional chaining (?.), nullish coalescing (??)
- No non-null assertions (!) unless guaranteed safe
- All function parameters and return types explicitly typed
- Use enums for fixed value sets (PoseCategory, Difficulty)

## React Native Component Standards

- Functional components only — NO class components
- React.memo for expensive renders
- useMemo/useCallback for expensive computations/callbacks
- Keep JSX clean — extract complex sections into sub-components
- No business logic in components — use hooks and stores
- No direct Supabase calls from components — use stores/services
- Proper cleanup in useEffect (return cleanup function)
- Use FlatList over ScrollView for lists (performance)
- Use expo-image over Image for caching
- StyleSheet.create for styles (or Reanimated styles for animations)
- No inline style objects in render (causes re-renders)

## State Management Rules

- Zustand for synchronous app state (auth, theme, camera, UI)
- React Query for asynchronous server state (Supabase queries/mutations)
- MMKV for persistent local state (settings, cache, recents)
- Local UI state: useState for temporary presentation
- Business state: Zustand stores
- Server state: React Query cache
- Never duplicate state across stores
- Single source of truth per data entity
- State mutations only through store actions

## Business Logic Rules

Components: Display UI, receive input, trigger actions.
Hooks: Coordinate UI ↔ Business layer.
Services: Business logic (CameraService, MediaPipeService, TtsService).
Stores: State management (Zustand).
Repositories: Data access (Supabase, MMKV).
Models: Data structures with serialization.

Data Flow: User Interaction → Component → Hook → Service → Repository →
Data Source (Supabase/MMKV). Results return through same layers.

## Supabase Rules

- All auth via auth store/service
- All DB via repositories
- RLS on every table
- No direct Supabase calls from components
- Ownership verification on all mutations
- Demo mode: src/demo/ mock when SUPABASE_URL not configured
- Never expose service keys in client code

## MediaPipe Rules

- Dedicated service in src/core/ml/
- Detection independent from UI
- Landmark processing separate from pose matching
- Components receive processed data only
- Stop on camera unmount
- 15fps ML processing, 60fps UI

## Error Handling Standards

- try/catch around all async operations
- No empty catch blocks
- User-friendly messages (no stack traces to users)
- Log unexpected errors via AppLogger
- Retry only when likely to succeed
- Network failures: offline still works for camera
- Permission failures: explain + retry + settings
- Camera failures: clear error + retry + stable state

## Performance Standards

- FlatList with keyExtractor, getItemLayout where possible
- No expensive operations in render
- React.memo for pure components
- useMemo for expensive calculations
- useCallback for callbacks passed as props
- Dispose resources in useEffect cleanup
- Camera + MediaPipe stopped on unmount
- Lazy load images with expo-image
- MMKV for fast reads (synchronous)

## Testing Standards

- Jest + React Native Testing Library
- Unit tests for services, repositories, business logic
- Component tests for screens, interactions
- Integration tests for auth flow, navigation, camera
- Manual verification before marking complete

## Code Invariants (Never Break)

Documentation, Scope, Architecture, Business Logic, UI (tokens only),
State Management, Supabase, MediaPipe, Security, Error Handling,
Performance, Code Quality, Testing, Documentation sync — all identical
categories to original, adapted for RN+Expo+TypeScript.docs/ai-workflow-rules.md# AI Workflow Rules — Smart Photography Assistant

## Standard Development Command

Build the requested feature according to all project documentation. Every
implementation must follow the documented architecture (React Native + Expo +
TypeScript), requirements, and coding standards.

## Before Writing Any Code

1. Read every relevant project document before starting work.
2. Understand the feature completely. If unclear, missing, or conflicting →
   stop and ask for clarification.
3. Review existing project structure (app/, src/) and identify affected files.
4. Compare requested feature with current implementation.
5. If too large, divide into logical milestones.
6. Present complete milestone plan → Wait for approval.

## After Approval

1. Implement only the first approved milestone.
2. Do not begin second milestone without explicit instruction.
3. Follow all documentation exactly. Documentation is source of truth.
4. No redesign, no new tech, no new patterns without approval.
5. Reuse existing code, components, hooks, stores.
6. Keep scope focused on approved milestone only.
7. Verify implementation matches requirements.
8. Summarize: What implemented, files created/modified, decisions, limitations.
9. STOP. Wait for review.

## Rules That Must Never Be Broken

- Never skip reading documentation.
- Never make architectural decisions without approval.
- Never implement more than approved milestone.
- Never assume missing requirements.
- Never silently change documented architecture.
- Never introduce new dependencies without approval.
- Never modify unrelated parts of project.
- Never continue to next milestone without explicit instruction.

## Handling Missing/Ambiguous Requirements (Rules 1-10)

Rule 1: Documentation is Source of Truth.
Rule 2: Validate requirements before implementation.
Rule 3: Never make assumptions.
Rule 4: Stop and request clarification when multiple approaches exist,
        docs conflict, feature conflicts with architecture, new tech needed.
Rule 5: Present options with pros/cons, recommend best fit, wait for decision.
Rule 6: Respect project scope. Out-of-scope → inform user, ask to update docs.
Rule 7: Missing requirements → documented decision with user approval.
Rule 8: Previously finalized decisions never reopened.
Rule 9: Correctness > Speed. Ask rather than risk incorrect implementation.
Rule 10: No implementation without sufficient information.

## Protected Files & Documentation Rules

Protected docs: architecture.md, project-overview.md, code-standards.md,
ai-workflow-rules.md, ui-context.md.
- Read-only unless user explicitly instructs update.
- Documentation > Code. Never modify docs to justify implementation.
- Request approval before any doc change.
- User has final authority.

## Documentation Synchronization (9 Rules)

1. Implementation must match docs.
2. Verify docs exist before implementing.
3. Detect and report doc gaps.
4. Never invent documentation.
5. Implementation never overrides documentation.
6. Report documentation impact after implementation.
7. Preserve internal doc consistency.
8. Approved docs become permanent project knowledge.
9. Verify doc compliance before completion.

## Verification Checklist

- Implementation: All requirements fully implemented, no extras.
- Architecture: Follows architecture.md, no invariant violations.
- Code Standards: Follows code-standards.md, consistent naming.
- Documentation: Consistent with all docs.
- Functional: Behaves as expected, error handling works.
- Dependencies: No unnecessary packages.
- Scope: Only approved milestone.

## Completion Report

Before stopping, provide:
- What was implemented
- Which docs were followed
- Whether any docs need updating
- Limitations or known issues
- Confirmation milestone is complete
- Confirmation no future milestone work done

--- NEXT REQUIRED DOCUMENT ---

docs/ui-context.md# UI Context — Design System (React Native + Expo)

## Design Philosophy (10 Principles)

1. Minimal Interface: Clear hierarchy, important actions first, less clutter,
   large touch-friendly elements. One primary purpose per screen.
2. Modern Photography App Feel: High quality, creativity, technology, trust.
3. Clean Visual Hierarchy: Where user is, what they can do, what's next.
4. Confidence-Focused UX: Users feel guided, supported, comfortable, confident.
5. Simple Learning Curve: Discover → Select → Guide → Capture → Save.
6. Mobile-First + Web-Responsive: One-handed usage, different screen sizes.
7. AI Assistant Personality: Photography coach, not robotic.
8. Balanced Premium + Accessible: Professional but simple.
9. Consistency: Same visual style, spacing, buttons, patterns everywhere.
10. Design Flexibility: AI may improve visual details within philosophy.

## Brand Colors (Exact HEX)

Primary Blue: #2563EB — buttons, active nav, progress, links
Primary Hover: #1D4ED8 — pressed states
Primary Light: #DBEAFE — selected cards, light backgrounds
Success Emerald: #10B981 — pose match success only
Warning Amber: #F59E0B — warnings, permission reminders
Error Red: #EF4444 — errors, failed operations
Background Primary: #FFFFFF
Background Secondary: #F8FAFC — cards, lists
Surface: #FFFFFF
Divider: #E5E7EB
Text Primary: #111827
Text Secondary: #6B7280
Text Disabled: #9CA3AF
Camera Overlay: #000000 at 35-45% opacity

Dark Mode:
BG Primary: #0F172A
BG Secondary: #1E293B
Surface: #1E293B
Text Primary: #F1F5F9
Text Secondary: #94A3B8

Match % Colors:
0-39% Red #EF4444
40-69% Amber #F59E0B
70-89% Blue #2563EB
90-100% Emerald #10B981

## Spacing (8pt Grid)

xs: 4px — very small gaps
sm: 8px — icon-text, compact
md: 12px — component padding
lg: 16px — screen padding, card padding, button padding
xl: 24px — section spacing
xxl: 32px — major content blocks
xxxl: 48px — hero, onboarding
section: 64px — major vertical separation

## Border Radius

none: 0 — dividers
xs: 4px — badges, chips
sm: 8px — inputs, compact controls
md: 12px — buttons, cards, list items
lg: 16px — large cards, bottom sheets
xl: 20px — hero cards, dialogs
xxl: 24px — modals, bottom sheet top
pill: 999px — capsules, chips
circle: 50% — avatars, circular buttons

## Typography (Inter via @expo-google-fonts/inter)

Display: 32sp Bold 700 — Splash, Welcome
Title: 28sp Bold 700 — Screen headers
Heading: 22sp SemiBold 600 — Sections
Card Title: 18sp SemiBold 600 — Pose names, collections
Body: 16sp Regular 400 — Default reading size
Secondary Body: 14sp Regular 400 — Metadata, captions
Small: 12sp Regular 400 — Helper text, labels (use sparingly)
Button: 16sp SemiBold 600 Title Case (NEVER uppercase)
Nav Label: 12sp Regular 400

Line Height: Headings 120-130%, Body 140-150%
Alignment: Headings left, Body left, Buttons center, Stats center

## Icons

Library: @expo/vector-icons MaterialCommunityIcons (Rounded equivalent)
Sizes: 16 inline, 20 secondary, 24 standard, 28 camera controls,
32 feature, 40-48 empty states, 64-96 hero
Touch Target: 48×48 minimum for ALL interactive icons (mandatory)
Color: Primary for primary actions, Secondary for secondary, Disabled for
inactive, semantic colors for status.

## Elevation

Subtle shadows only. Cards lightweight. Use shadowColor/shadowOffset/
shadowOpacity/shadowRadius (iOS) + elevation (Android).

## Theme Behavior

3 options: System Default (default), Light, Dark.
Use useColorScheme() + Zustand themeStore.
Smooth transition, no layout shift.
Same structure both themes — only colors/shadows adapt.
Tokens only, never hardcoded #FFFFFF/#000000 as primary bg.

## Accessibility

- 48×48 touch targets minimum
- Sufficient contrast (4.5:1 ratio)
- accessibilityLabel + accessibilityRole on all interactive elements
- Font scaling support
- Color independence (icons + labels, not color alone)
- Screen reader support
- Reduced motion support
- Portrait V1, landscape future

## Component Behavior

Buttons: Primary = primary action, Secondary = optional, Disabled visible.
Cards: Consistent spacing, radius, elevation, padding, animation.
Input Fields: Identical border, focus, error, disabled, placeholder.
Navigation: Predictable, back returns previous, tabs preserve history.
Loading: Skeleton/shimmer, never blank.
Empty: Illustration + why + what next + CTA.
Error: Clear explanation + recovery (Retry/Refresh/Go Back).
Success: SnackBar/Toast, brief, unobtrusive.
Animations: Smooth, subtle, purposeful. Reanimated.

--- NEXT REQUIRED DOCUMENT ---

docs/ui-recommendations.md# UI Recommendations — Flexible Design Guidance

The following are flexible recommendations, not strict requirements. The AI
may propose alternatives that improve UX while maintaining design philosophy.

## Card Layouts
Modern card-based, generous spacing, consistent padding, soft corners,
subtle elevation. Lightweight, scannable, visually separated.

## Screen Composition
Clean, balanced, clear hierarchy. Avoid overcrowding. Group related content.
Use whitespace intentionally.

## Empty States
Friendly illustrations, simple icons. Explain why empty + what next +
primary action.

## Illustration Placement
Onboarding, permissions, empty states, first-time experiences. Support
content, don't distract.

## Hero Sections
Important actions: illustration + title + text + CTA.

## Animation Style (Reanimated)
Smooth, subtle, purposeful. Reinforce actions, improve navigation.
Avoid excessive/decorative animations.

## Micro-interactions
Button press, card selection, success confirmation, pull-to-refresh,
camera capture feedback, favorite toggle (scale 1.0→1.4→1.0 300ms).

## Visual Hierarchy
Important actions attract attention via spacing, typography, size, contrast.

## Loading States
Skeleton loaders, shimmer effects. Reduce perceived wait time.

## Overall UI Refinement
AI encouraged to recommend improvements: layout, spacing, hierarchy,
navigation, interactions, content presentation. Must not change core
functionality or documented requirements without approval.

## Design Freedom
AI may apply modern RN/Expo best practices. Decisions must remain
consistent with design system, brand identity, accessibility, and UX.
User retains final approval over major visual changes.

docs/progress-tracker.md# Progress Tracker

Single source of truth for implementation status. Update immediately after
every meaningful milestone.

## Documentation Status
Record status of each doc: Up to Date | Updated This Session | Requires
Review | Pending Update

## Current Phase
Single active phase: Project Setup | Authentication | Home | Explore |
Camera | MediaPipe | Pose Matching | Gallery | Testing | Release

## Current Goal
Single milestone being worked on.

## Completed
Chronological history. Never remove. Include: milestone name, date, summary.

## In Progress
Current milestone. Only one. "None" if not started.

## Next Up
Immediate next milestone only.

## Open Questions
Unresolved decisions: question, reason, status.

## Architecture Decisions
Finalized decisions: decision, reason, date.

## Session Notes
Minimum context for next session. What completed, current status,
observations, limitations. Write so new AI agent can resume with zero
conversation history.

## Known Issues
Confirmed bugs, tech debt, workarounds: description, impact, resolution.

## Future Improvements
Postponed ideas outside V1 scope.

## Tracking Rules
- Mandatory Update: After every meaningful milestone.
- Verification: Never mark complete without full verification.
- Doc Sync: Update affected docs before marking complete.
- Historical Record: Never remove completed milestones.
- Architecture Consistency: Update decisions immediately if changed.
- Incomplete Work: Record remaining in In Progress + Session Notes.
- Progress Recording: Meaningful milestones only, no minor tweaks.
- Project Resume: Read tracker → identify phase/goal → review questions →
  read docs → resume from stopping point.
- Conflict Detection: Stop if tracker conflicts with code/docs.
- Source of Truth: Tracker + docs determine progress, not conversation.docs/00-build-plan.md# 00 - Build Plan: Smart Photography Assistant (React Native + Expo)

> This file proves the entire system was designed before the first prompt.
> Generated from project-overview.md, architecture.md, code-standards.md,
> ai-workflow-rules.md, ui-context.md, ui-recommendations.md, progress-tracker.md.

**Stack:** TypeScript, React Native, Expo SDK 52, Zustand, React Query
(TanStack), Supabase JS (PostgreSQL + Auth + Storage), @mediapipe/tasks-vision
Pose 33 landmarks, expo-camera, MMKV (react-native-mmkv), expo-media-library,
Expo Router, expo-speech, expo-permissions, expo-image, react-native-reanimated,
@shopify/react-native-skia, EAS Build, GitHub

**Platforms:** Android + iOS + Web (PWA)

**Core Invariants:** Photos Device ONLY (never Supabase in V1), MediaPipe
local only no upload, read-before-login create-after-login, single camera
session, release on unmount/background. No guest mode in V1.

**Demo Mode:** App works fully with mock Supabase out of the box. Add real
keys to .env → connects to real backend in 2 minutes. See ENV-SETUP.md.

**Rules Applied for Decomposition:**
1. One visible, verifiable result per unit
2. One system boundary per unit (UI ≠ DB ≠ Background)
3. Just-in-time dependencies (Supabase only when Auth needed, Camera only
   when Camera Tab needed, MediaPipe only after Camera stable)
4. Always-together merged (Flash+Timer+Switch+Filters = one session)
5. No standalone visible result merged (Supabase tables alone merged into
   Login, MMKV cache alone merged into Explore)

## BUILD PLAN - 24 Units in Build Order

### PHASE 0: FOUNDATION

**Unit 01: Project Setup & Design Tokens**
- What: Expo init, folder structure (app/, src/), Expo Router skeleton with
  placeholder routes, design tokens (colors #2563EB etc, spacing 8pt grid,
  radius, typography Inter via @expo-google-fonts/inter), Light/Dark/System
  theme via useColorScheme + Zustand themeStore, AppLogger setup
- Deps: None (base Expo)
- Visible: App runs empty, theme switch works, logger prints

**Unit 02: App Shell & Bottom Navigation**
- What: 5-tab Expo Router Tabs (app/(tabs)/_layout.tsx) — Home, Explore,
  Camera, Gallery, Profile. Preserve state per tab, top corners radius 20px,
  placeholder screens, smooth transitions
- Deps: Unit 01
- Visible: Tapping tabs works, history preserved, no crash

**Unit 03: Splash + Welcome + Onboarding**
- What: Splash (Reanimated logo 0.5-1s + MMKV first launch check), Welcome
  (Illustration + "Take Better Photos" + Get Started + Sign In), Onboarding
  3 slides (Discover, Guidance, Auto Capture) with dots + Skip + Next/Continue
- Deps: Unit 02
- Visible: Cold start flow Splash→Welcome→Onboarding→Permissions works

### PHASE 1: PERMISSIONS & AUTH

**Unit 04: Permissions Flow**
- What: Permission explanation UI (Camera + Photos), system dialogs via
  expo-camera/expo-media-library permissions, Granted/Denied/DeniedForever
  states, Retry + Open Settings via Linking.openSettings(), Notifications
  NOT requested
- Deps: Unit 03
- Visible: Permission grant/deny flows work, denial shows recovery UI

**Unit 05: Pose Library Local Data Layer**
- What: MMKV stores (poses, recents LRU 4, search history LRU 10, favorites),
  bundled assets/data/poses.json (20+ sample, structure for 400), Repository
  pattern cache-first + network fallback, expo-image setup (AppImage wrapper),
  offline-first per architecture
- Deps: Unit 01
- Visible: Pose data loads offline from assets, recent logic works

**Unit 06: Auth Foundation + Login (Google + Email)**
- What: Supabase JS init (demo fallback when no env vars), profiles +
  favorites tables with RLS, expo-auth-session (Google + Email), Zustand
  authStore, Login UI, session persistence, auto-login. No guest mode in V1.
  Unauthenticated = browse-only. Favorites offline queue MMKV.
- Deps: Unit 04, Unit 05
- Visible: Sign in via Google/Email, session persists, logout works,
  unauthenticated browse-only enforced

### PHASE 2: HOME & DISCOVERY

**Unit 07: Home Tab Dashboard**
- What: Top Bar greeting + notification + profile shortcut, Hero Card Start
  Camera + Continue Last Pose, Recent 4 horizontal FlatList, Welcome card
  first-time, Quick nav grid
- Deps: Unit 05, Unit 06
- Visible: Home shows recents, Continue Last Pose opens Camera with pose

**Unit 08: Explore Tab Foundation + Collections + Grid**
- What: Search Bar radius 16, Featured Collections horizontal, 12 Category
  collections grid, Pose Grid 2-col FlatList, expo-image optimized loading,
  skeleton shimmer, empty state
- Deps: Unit 05
- Visible: Explore shows 400 poses, collections browsable, grid scrolls

**Unit 09: Search & Filter + Search History**
- What: Real-time debounced search (useDebounce hook), Advanced filter bottom
  sheet (Category, Difficulty, Tags AND logic), Search history MMKV LRU 10,
  Clear history, No results empty state
- Deps: Unit 08
- Visible: Search "Wedding" filters live, filters combine, history persists

**Unit 10: Pose Detail + Use This Pose**
- What: Detail screen (expo-image hero 400px, Name 18sp 600, Difficulty,
  Tags, Instructions), Share via expo-sharing, Favorite toggle UI, Use This
  Pose button → /camera?poseId via Expo Router
- Deps: Unit 08
- Visible: Tap pose opens detail, Use This Pose opens Camera with pose

**Unit 11: Favorites System Complete**
- What: Supabase favorites + RLS wired, Reanimated toggle animation scale
  1.0→1.4→1.0 300ms, persists per user Supabase + MMKV offline + sync queue,
  Favorites grid in Profile, Guest → prompt login bottom sheet
- Deps: Unit 06, Unit 10
- Visible: Heart animates, favorites persist, Profile shows favorites

### PHASE 3: CAMERA CORE

**Unit 12: Camera Foundation Full (Preview + Controls)**
- What: expo-camera init JIT, live preview, front/rear switch, State 1 No
  Pose + State 2 Active, Top controls Flash/Timer/Settings 28px icons,
  Bottom Gallery thumb + Capture 72px + Switch, Filter strip horizontal,
  Pinch zoom (GestureHandler), single session enforcement, release on
  unmount/AppState background
- Deps: Unit 04, Unit 10
- Visible: Camera preview + controls work, State 1/2, single session

**Unit 13: Capture + Processing + Preview + Save (Device Only)**
- What: Manual capture, Timer countdown Reanimated 3-2-1, expo-haptics,
  Processing overlay, Preview Screen (Save/Share/Delete/Retake/Done), Save
  to device via expo-media-library (NEVER Supabase), MMKV metadata, Retake
  same pose, Done → Gallery
- Deps: Unit 12
- Visible: Photo → preview → saved to device gallery → appears in Gallery

**Unit 14: Gallery Tab Complete**
- What: App photo grid FlatList 3-col, Pose History horizontal, Photo Preview
  Share/Delete/Retake, Date grouping, Empty state + Start Camera CTA, MMKV
  metadata management
- Deps: Unit 13
- Visible: Gallery shows saved photos, history reuse, share/delete works

### PHASE 4: AI CORE

**Unit 15: Pose History & Recents Wiring**
- What: Wire Home Recent 4 + Camera State 1 Recent + Gallery History to same
  MMKV source, lastUsed timestamp, limit 4 Home / full Gallery, quick reuse
- Deps: Unit 05, Unit 13, Unit 14
- Visible: Using pose updates Home + Camera + Gallery everywhere

**Unit 16: MediaPipe Core + Overlay + Match %**
- What: @mediapipe/tasks-vision PoseLandmarker 33 landmarks, Skia Canvas
  skeleton overlay, match % angle comparison 8-12 joints, 15fps ML / 60fps
  UI, model loading state, dispose on unmount
- Deps: Unit 12
- Visible: Live skeleton overlay + match % updating real-time

**Unit 17: Pose Comparison & Visual Guidance**
- What: Worst-diff guidance text ("Raise left arm"), Arrow indicators on
  skeleton via Skia, Color-coded joints green/amber/red, Hints system
- Deps: Unit 16
- Visible: User sees specific instructions + color feedback on body

**Unit 18: Intelligent Capture Suite (Voice + Auto + Gesture)**
- What: expo-speech voice guidance debounced 3s, Auto-capture ≥90% 2s hold
  + countdown, Gesture ✋ hand-open detection + countdown, Debounce 3s
  global, all toggles in Settings
- Deps: Unit 17
- Visible: Voice speaks, auto-captures at 90%, gesture triggers capture

### PHASE 5: PROFILE & SETTINGS & POLISH

**Unit 19: Profile Tab**
- What: Avatar 80, Stats 3-col, Edit name (Supabase + MMKV), Favorites grid
  2-col, Storage management (Clear Cache/Recents), Logout, Guest Login CTA,
  Settings shortcut
- Deps: Unit 06, Unit 11, Unit 14
- Visible: Profile shows favorites, stats, edit, logout works

**Unit 20: Settings - Camera & Capture Preferences**
- What: Camera prefs (Flash/Timer/Filter/Grid defaults), Capture prefs
  (Auto threshold/Voice/Gesture/Countdown/Haptic toggles), Reset to defaults.
  MMKV persistence. Settings affect Camera tab behavior.
- Deps: Unit 18
- Visible: Toggles change camera behavior, persist after restart

**Unit 21: Settings - System (Theme/Language/Privacy/About)**
- What: Theme Light/Dark/System app-wide, Language placeholder English,
  Privacy Policy, Terms, About v1.0.0, Rate App, Clear All Data (keeps
  onboarding flags)
- Deps: Unit 01, Unit 19
- Visible: Theme switches app-wide, about info shows

**Unit 22: Global Error Handling**
- What: Central ErrorHandler, AppError types, Retry UI component, Offline
  banner (NetInfo), ErrorBoundary crash recovery, No silent fails, AppLogger
  integration
- Deps: All previous
- Visible: App never crashes silently, shows retry on failure

**Unit 23: UI States System**
- What: Shimmer loading all grids/lists, Empty states illustration + CTA all
  tabs, Error retry all screens, Success SnackBar, No blank screens anywhere
- Deps: Unit 08, 14, 19
- Visible: Every screen has loading/empty/error/success states

**Unit 24: Performance + Polish + Final Verification**
- What: Lazy loading FlatList onEndReached 20/page, Memory dispose all
  controllers, Onboarding final, App icon app.json, Build verification
  eas build, Final QA checklist all flows
- Deps: Unit 22, 23
- Visible: App polished, fast, production-ready for Play Store + App Store + Web

## DEPENDENCY GRAPH

01→02→03→04→05→06→07→08→09→10→11→12→13→14→15→16→17→18→19→20→21→22→23→24

**Total: 24 Units, each one focused session, each verifiable, JIT deps.**
