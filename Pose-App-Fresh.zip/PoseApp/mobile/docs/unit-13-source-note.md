# Unit 13 Source Note

The implementation for Unit 13 must be based on the exact section
`context/specs/13-capture-processing-preview-save.md` from the user-supplied
gistfile2. The raw web response is too large and truncates middle units, so the
section is extracted directly from the downloaded raw file before coding.

`mobile/docs/unit-13-extracted.md` is the exact extracted section that was
read before implementation. `unit-13-required-docs-extracted.md` contains the
required Project Overview, Architecture, Code Standards, Workflow and UI
guidance sections read for this unit. These local files exist for auditability;
they do not replace the user-supplied source links.
