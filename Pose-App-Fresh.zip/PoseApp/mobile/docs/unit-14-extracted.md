context/specs/14-gallery-tab-complete.md# Unit 14 - Gallery Tab Complete
**File Path:** context/specs/14-gallery-tab-complete.md
**Build Plan Ref:** Unit 14 - Phase 3 - Dependencies: Unit 13

## 1. Goal
Build Gallery Tab Complete: App photo grid FlatList 3-col (only app-captured
from MMKV galleryStore), Pose History horizontal (previously used poses
reuse), Photo Preview Share/Delete/Retake, Date grouping, Empty state +
Start Camera CTA, MMKV metadata management.

Visible Result: Gallery shows saved photos, history allows quick reuse,
share/delete works.

## 2. Design

**Gallery Tab Structure:**
- SafeAreaView bg bgSecondary
- Top bar: "Gallery" Heading 22 600 + count "24 photos" BodySmall 14

**Pose History Section:**
- Header "Pose History" Card Title 18 600
- FlatList horizontal height 120, gap md 12
- Item: AppImage 80x80 radius md 12 + title BodySmall 12
- Tap: quick reuse → /camera?poseId=poseId
- Data: distinct poseIds from galleryStore + recentPosesStore
- Empty: hide section

**Photo Grid:**
- FlatList numColumns={3}, gap xs 4
- Item: Image source={{ uri: photo.imagePath }} aspectRatio 1, radius sm 8
- Tap: → /gallery/photo/:id full screen preview
- Date grouping: Section headers "Today", "Yesterday", "This Week",
  "March 2024" BodySmall 14 500 secondary

**Photo Preview (Full Screen):**
- Same as Unit 13 PreviewScreen but from gallery
- Top: Close, Share, Delete
- Bottom: Date "Today, 12:00 PM" BodySmall 12 white + Pose name if exists
  + Retake button → /camera?poseId

**Empty State:**
- image-multiple 48 secondary circle 80 bgSecondary
- "No photos yet" Heading 22 600
- "Your captured photos will appear here" Body 16
- "Start Camera" Primary → /(tabs)/camera

## 3. Implementation

**Files to Create/Modify:**

1. **app/(tabs)/gallery.tsx** (REWRITE)
   - Render GalleryTab component

2. **src/features/gallery/presentation/screens/GalleryTab.tsx**
   - useGalleryPhotos() hook from galleryStore
   - usePoseHistory() hook
   - If empty: EmptyState
   - Else: ScrollView with PoseHistoryList + DateGroupedGrid

3. **src/features/gallery/presentation/components/PoseHistoryList.tsx**
   - FlatList horizontal height 120
   - Item: AppImage 80x80 radius md 12 + title BodySmall 12
   - Tap → router.push('/(tabs)/camera?poseId=' + poseId)

4. **src/features/gallery/presentation/components/GalleryGrid.tsx**
   - Props: photos grouped by date
   - SectionList or FlatList with date headers
   - numColumns={3}, item aspectRatio 1 radius sm 8
   - Image source={{ uri }} from local file

5. **src/features/gallery/presentation/components/DateHeader.tsx**
   - "Today" / "Yesterday" / "This Week" / "March 2024"
   - BodySmall 14 500 secondary padding lg 16 vertical sm 8

6. **src/features/gallery/presentation/components/EmptyGallery.tsx**
   - Centered: icon image-multiple 48, title, desc, Start Camera button

7. **app/gallery/photo/[id].tsx** (NEW)
   - Full screen photo preview from gallery
   - Share, Delete, Retake, Date display

8. **src/features/gallery/presentation/hooks/useGallery.ts**
   - useGalleryPhotos(): React Query from MMKV galleryStore sorted desc
   - useGroupedPhotos(): group by date
   - usePoseHistory(): distinct poseIds from gallery + recent
   - useDeletePhoto(): mutation delete from MMKV + file

## 4. Dependencies
- No new. Reuse: expo-media-library, MMKV, expo-image, expo-sharing

## 5. Verification Checklist
- [ ] Gallery empty: EmptyState + Start Camera CTA
- [ ] Gallery with photos: 3-col grid, aspectRatio 1, radius sm 8
- [ ] Date grouping: Today/Yesterday/Week/Month headers
- [ ] Pose History: horizontal 80x80, tap → camera with poseId
- [ ] Photo Preview: full screen, Share/Delete/Retake, Date + Pose name
- [ ] Delete: confirm → remove from MMKV + file → grid updates
- [ ] Share: expo-sharing shareAsync
- [ ] Retake: → camera same poseId
- [ ] Only app-captured photos (MMKV galleryStore), not all device photos
- [ ] Offline: works from MMKV
- [ ] progress-tracker.md updated
