context/specs/15-pose-history-recents-wiring.md# Unit 15 - Pose History & Recents Wiring
**File Path:** context/specs/15-pose-history-recents-wiring.md
**Build Plan Ref:** Unit 15 - Phase 4 - Dependencies: Unit 05, 13, 14

## 1. Goal
Wire Recent 4 in Home + Recent in Camera State 1 + Pose History in Gallery
to same MMKV source (recentPosesStore from Unit 05 + galleryStore poseIds).
Last used timestamp, limit 4 Home, full list Gallery, quick reuse flow.

Visible Result: Using a pose updates Home + Camera + Gallery everywhere.

## 2. Design

**Single Source of Truth:**
- MMKV recentPosesStore: stores {poseId, lastUsed timestamp}[] sorted desc
- Max 20 entries in store, Home shows 4, Gallery shows all
- When pose used (Use This Pose, detail view, capture, quick reuse):
  update timestamp to now, move to front

**Home Recent 4:**
- useRecentPoses(4) → first 4 from sorted list
- Already from Unit 07, ensure uses unified hook

**Camera State 1 Recent:**
- Same useRecentPoses(4) hook, same data
- Tap → /camera?poseId + addToRecent

**Gallery Pose History:**
- usePoseHistory() → full list from recentPosesStore + galleryStore distinct
- Not limited to 4, show up to 20

**Quick Reuse Flow:**
- All 3 places: tap → addToRecent(poseId) → router.push('/camera?poseId=')
- addToRecent updates timestamp, moves to front, all screens update

## 3. Implementation

**Files to Modify:**

1. **src/features/poses/data/datasources/poseLocalDatasource.ts** (UPDATE)
   - recentPosesStore now stores JSON array of {poseId, lastUsed} objects
   - addToRecent(poseId): remove if exists, unshift {poseId, lastUsed: Date.now()},
     slice(0, 20)
   - getRecentPoses(limit?): sort by lastUsed desc, return limit or all

2. **src/features/poses/presentation/hooks/usePoses.ts** (UPDATE)
   - useRecentPoses(limit?: number): React Query, calls getRecentPoses(limit)
   - useAddToRecent(): mutation, invalidates recentPoses query

3. **src/features/home/presentation/components/RecentPosesList.tsx** (UPDATE)
   - use useRecentPoses(4)

4. **src/features/camera/presentation/components/NoPoseState.tsx** (UPDATE)
   - use useRecentPoses(4)

5. **src/features/gallery/presentation/hooks/useGallery.ts** (UPDATE)
   - usePoseHistory(): useRecentPoses() full list (no limit)

6. **All tap handlers** (UPDATE)
   - Home recent tap, Camera State 1 tap, Gallery history tap:
     call addToRecent(poseId) then router.push('/camera?poseId=' + id)

## 4. Dependencies
- No new.

## 5. Verification Checklist
- [ ] MMKV recentPosesStore stores {poseId, lastUsed} with timestamps
- [ ] Home shows 4 most recent sorted by lastUsed desc
- [ ] Camera State 1 shows same 4 as Home
- [ ] Gallery History shows full list up to 20
- [ ] Use pose from Explore → Home Recent updates to front
- [ ] Use pose from Gallery History → Home + Camera State 1 update
- [ ] Quick reuse: tap any recent → /camera?poseId + addToRecent
- [ ] Limit 4 Home, full Gallery verified
- [ ] progress-tracker.md updated
