# Unit 27 — Human-like Voice Guidance (Phrase Bank + Native Neural Voice)

**Build Plan Ref:** Post-Unit 24 maintenance series (25 silhouette → 26 hollow
contour → **27 voice guidance humanization**).
**Status:** ✅ COMPLETE — all four parts shipped and verified (see Part 4).

> Context: Unit 18 wired `expo-speech` with a single fixed English line per
> correction ("Raise left arm" etc.) — sounds robotic, repeats constantly,
> `rate: 0.5`, default OS voice, `language: 'en-US'` only. Unit 27 makes the
> coach sound like a real Indian photo-studio instructor (Hindi/Hinglish
> variations) and selects the best on-device enhanced/neural voice per
> language. **No new npm package — expo-speech + OS native TTS only.**

## Hard constraints (from the task, non-negotiable)

- No AI/cloud TTS. expo-speech only (Android TextToSpeech / iOS AVSpeechSynthesizer).
- `rate` 0.95–1.05 → shipped constant **0.98**. `pitch` **1.0**.
- Language switching: app voice language Hindi → utterance `hi-IN`;
  English → `en-IN` → `en-US` fallback. Persisted setting, not hardcoded.
- Phrase length 4–8 words, natural pauses via commas / "…".
- Never the same line twice in a row (≥3s Unit 18 anti-spam debounce preserved).
- Platform purity: zero DOM, zero hardcoded color hex in `shared/ + mobile/`.
- Do not delete existing behavior: Unit 17 guidance text/hint/arrow UI stays
  exactly as-is — voice layer becomes additive (`voiceCategory`).

## Part 1 — Phrase bank ✅

**File:** `shared/constants/poseInstructions.ts` (platform-neutral, exported
via `shared/index.ts`).

- `VoiceInstructionCategory` — all 15 requested categories:
  `hand_up, hand_down, hand_left, hand_right, leg_left, leg_right, leg_open,
  leg_close, look_straight, look_left, look_right, chin_up, chin_down,
  shoulder_straight, back_straight, final_pose_good, photo_clicking` (17 keys).
- 8 variations per category per language: Hindi/Hinglish (Devanagari, studio
  fillers: "bhai", "hmm", "bas", "haan", "thoda sa", "perfect") + English.
- `getRandomInstruction(category, language)` — uniform pick that never
  returns the phrase used for the same (category, language) key immediately
  before; per-key last-phrase map, module-local, no state leaks.
- `voiceCategoryToDefaultText` kept OUT — UI copy still originates in
  `guidanceGenerator`; bank is voice-only.

## Part 2 — Guidance engine wiring ✅

**Files:** `shared/ml/guidanceGenerator.ts`, `mobile/src/features/camera/
presentation/screens/CameraTab.tsx`.

- `GuidanceResult.voiceCategory: VoiceInstructionCategory` added (additive
  field; every rule branch mapped):
  - shoulders raise/lower → `hand_up` / `hand_down`
  - elbows: straigthen-out / bend-in mapped by resulting lateral direction →
    `hand_left` / `hand_right`
  - knees → `leg_left` / `leg_right` (by side)
  - hips forward/back → `leg_open` / `leg_close`
  - all-perfect → `final_pose_good`
  - `look_*, chin_*, shoulder_straight, back_straight` authored in the bank,
    reserved for a future head-pose ML pass (documented, not dead code: bank
    API is shipped and consumed).
- CameraTab speaks `speakInstruction(voiceCategory, voiceLanguage)` instead
  of the raw UI text; `isSpeaking` indicator untouched.
- `photo_clicking` cue spoken at `beginIntelligentCapture` (it already calls
  `ttsService.stop()` there — cue is `force`-flagged to bypass the 3s
  debounce, so the photographer always announces the shot).

## Part 3 — Best native neural voice ✅

**Files:** `mobile/src/core/voice/ttsService.ts`, `shared/types/settings.ts`,
`mobile/src/shared/stores/settingsStore.ts`,
`mobile/src/features/settings/presentation/screens/SettingsScreen.tsx`.

- `voiceLanguage: VoiceLanguage ('en' | 'hi')` added to `CameraSettings` +
  `DEFAULT_CAMERA_SETTINGS` (default `'en'` to match the English-only UI),
  persisted through the Unit 20 MMKV zustand store (rehydrate merges the new
  key from defaults automatically).
- Settings → Language tile: replaced "Coming Soon" alert with the existing
  `SettingsRadioModal` (English / हिंदी). Interface strings stay English in
  V1; the setting governs **voice guidance** language (tile description says
  so explicitly).
- `ttsService` voice resolver: `Speech.getAvailableVoicesAsync()` once
  (cached), scored per requested language:
  1. exact BCP-47 prefix match (`hi-IN` → `hi`, `en-IN` → `en-US` chain),
  2. prefer `quality` Enhanced/Premium or identifier containing
     enhanced/neural/premium/siri,
  3. prefer on-device (`networkConnectionRequired === false`) over
     network voices. Language + identifier logged for support.
- Speak params: `rate 0.98`, `pitch 1.0`, `volume 1`; utterance `language`
  follows `voiceLanguage` (`hi-IN` / resolved English voice locale).
- Micro-pauses: phrase copy carries the rhythm (commas, "…"); the 300–500ms
  breathing room between corrections is provided by the preserved Unit 18
  3-second voice interval — intentionally NOT reduced (anti-spam invariant).

## Part 4 — Verification ✅

- `npm run verify:all` → deps declared ✓, platform pure ✓, tsc clean ✓.
- Mobile `tsc --noEmit` ✓ (CatalogVoice structural widening resolved the two
  expo-speech 12 typing gaps: `networkConnectionRequired`, `notInstalled`).
- Root `npm run build` ✓ (web preview green; `voiceCategory` additive only).
- Phrase bank runtime test ✓ — 17 categories, no consecutive repeats, all
  cells non-empty, Hindi + English samples confirmed.
- Progress tracker: Unit 27 row + session notes appended (history kept).

## Notices / decisions taken

- Silhouette visual refactor (solid ghost → hollow luminous contour) was
  requested in the same brief — **already shipped as Unit 26**; verified in
  `PoseSilhouetteOverlay.tsx` + `shared/ml/poseSilhouette.ts`
  (`outlineSilhouette`, transparent body, 2.5px dashed stroke, BlurMask 5px
  halo, match ramp <40/40–70/70–85/>85 + breathing pulse, Reduce-Motion
  pinned). No re-work done there.
