# Unit 30 — Semantic coaching boundary (pose analysis ⇄ voice)

> Deterministic. No LLM, no network, no new dependency.

## The boundary

```
POSE ANALYSIS            shared/ml/analysis/**        geometry · thresholds · hysteresis
      ↓ PoseAnalysisDecision
SEMANTIC COACHING STATE  shared/coaching/coachingState.ts + types.ts
      ↓ CoachingState (kind · token · category · measurement · direction ·
        severity · intensity · confidence · stableFrames · unavailableReason ·
        speakable)
LANGUAGE                 shared/coaching/phraseSelection.ts
      ↓
PHRASE SELECTION         shared/constants/poseInstructions.ts (curated banks)
      ↓ CoachingPhrase (text · category · language · intensity · poolSize)
TTS                      mobile/src/core/voice/ttsService.ts  (speech only)
```

Cadence (WHEN to speak) is `shared/coaching/speechPlanner.ts` — a pure,
clock-injected scheduler. The TTS service owns no coaching timer.

## Audit of the pre-existing implementation (what was actually there)

| Piece | Found | Verdict |
|---|---|---|
| `shared/ml/analysis/**` (Unit 29) | Real engine, one semantic `PoseAnalysisDecision`, severity ladder, priority ranking, frame-counted persistence + hysteresis, structured `unavailable` | Functional — left untouched |
| `decisionToGuidance` (guidanceBridge) | Decision → `GuidanceResult` (UI copy, arrow, `voiceCategory`) | Functional for the **UI**; kept as the presentation bridge |
| `GuidanceResult.severity` | `'perfect' \| 'good' \| 'adjust'` | Computed, rendered — **never reached speech** |
| `ttsService.speakInstruction(category, language)` | No severity parameter at all | **Architectural mismatch — repaired** |
| Phrase banks | 17 categories × 8 variations × hi/en, no-repeat memory | Functional; one intensity tier only → **firm tier added** |
| Debounce | Fixed 3 s interval + duplicate-text check, inside the TTS | Spam-safe but state-blind: a *new* correction waited up to 3 s, and PERFECT re-fired every 3 s with a fresh random line (“perfect… perfect… perfect”) → **replaced by the transition-aware planner** |
| Unavailable handling | `decisionToGuidance` returned `null`, screen spoke nothing | Correct — preserved and now explicit (`speakable: false`) |
| Voice discovery | `getAvailableVoicesAsync` once, cached, locale chain hi-IN→hi / en-IN→en-US→en, enhanced/neural + on-device scoring, engine-default fallback | Useful architecture — **preserved unchanged**; no device voice is claimed, the catalog is read at runtime and an empty catalog falls back to the engine default |

## What changed

1. **`shared/coaching/` (new)** — the one semantic representation between math
   and speech: `types.ts`, `coachingState.ts`, `categories.ts`,
   `phraseSelection.ts`, `speechPlanner.ts`, `index.ts`.
2. **Severity now reaches phrase selection.** `intensityForSeverity()` maps the
   engine's `ComparisonSeverity` once (`major → firm`, otherwise `gentle`).
   The TTS layer forwards that intensity; it never derives it.
3. **Phrase bank intensity tiers.** `instructionPool(category, language,
   intensity)` and `getInstruction(..., { intensity, random })`.
   `getRandomInstruction` is preserved as the gentle-tier alias. Firm pools
   (5 curated variations, hi + en) exist for the 8 reachable correction
   categories; every other category falls back to its gentle pool.
4. **Transition-aware cadence.** `createCoachingSpeechPlanner()`:
   * new semantic state → speakable after `minGapMs` (900 ms) — ~3× lower
     latency than the old fixed gate;
   * same correction → repeated only every `repeatIntervalMs` (4500 ms);
   * PERFECT → exactly **one** positive line per perfect episode; a new
     episode only begins after the state leaves perfect;
   * non-speakable states clear the cadence memory, so recovery is immediate;
   * while speaking, only a state change may interrupt.
5. **No fabricated coaching.** `unavailable` / `evaluating` states carry
   `category: null`, `speakable: false`; `selectCoachingPhrase` returns `null`
   for them and the planner answers `not-speakable`. There is no code path
   from an unusable reference to a correction phrase.
6. **Preview mirror parity.** `tooling/preview` runs the *same* shared planner,
   state mapper and phrase selector; only the speech backend differs
   (`speechSynthesis` vs `expo-speech`). No coaching logic is duplicated.
7. **UI untouched.** `decisionToGuidance` → `GuidanceResult` still drives the
   Unit 17 overlay/pill. Both the overlay text and the spoken line now descend
   from the same decision, but the screen no longer decides when to speak.

## Category trace (`CATEGORY_COVERAGE`, computed from the live tables)

| Category | Reachability | Producer |
|---|---|---|
| `hand_right`, `hand_left` | reachable-correction | `leftElbow`, `rightElbow` |
| `hand_up`, `hand_down` | reachable-correction | `leftShoulder`, `rightShoulder` |
| `leg_left`, `leg_right` | reachable-correction | `leftKnee`, `rightKnee` |
| `leg_open`, `leg_close` | reachable-correction | `leftHip`, `rightHip` |
| `final_pose_good` | reachable-perfect | stable PERFECT episode |
| `photo_clicking` | reachable-capture | capture flow (forced cue) |
| `look_straight`, `look_left`, `look_right`, `chin_up`, `chin_down`, `shoulder_straight`, `back_straight` | **reserved-no-measurement** | none today — the engine registry has no head/neck/torso-orientation measurement |

Reserved copy is retained on purpose (it is ready the day such a measurement
lands) and is **not** claimed as functional coaching. The table is derived from
`JOINT_GUIDANCE_RULES` + `MATCH_JOINTS` at module load, so it cannot go stale,
and `tests/coaching/coaching.test.ts` asserts it.

## Verification run in this session

* `npm test` (root) — **164/164 pass**, including the new
  `tests/coaching/coaching.test.ts` suite:
  analysis state → category · severity → pool · language → bank ·
  no immediate repeat (40 draws with a degenerate RNG) · perfect spoken once
  per episode over 200 frames · unusable reference and lost body silent ·
  recovery speaks immediately · full pipeline end-to-end.
* `mobile/scripts/verify-all.mjs` — deps declared, **purity PASS**,
  `tsc --noEmit` (mobile, TS 6) clean, reference-architecture PASS.
* Root `tsc --noEmit` clean; preview `npm run build` emits `dist/index.html`.
* Import audit: analysis imports no TTS/speech/Supabase/React; `ttsService`
  imports only `expo-speech`, the shared coaching layer and the logger —
  no angle math, no Supabase.

## Not verified here (unchanged blockers)

On-device Android/iOS speech: no emulator or device in this environment, so
actual voice catalogs, neural-voice availability and audio cadence remain
device checks. Nothing in the code asserts a device voice exists.
