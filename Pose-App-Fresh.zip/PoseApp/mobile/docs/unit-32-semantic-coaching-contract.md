# Unit 32 (Part 4.1) — Semantic coaching contract: audit + repair

Scope of this session: **audit** the real coaching/TTS architecture in the
repository, **repair** the canonical semantic contract between pose analysis
and speech, and **prepare** the project for an independent follow-up chat.
No LLM was introduced, the TTS engine was not replaced, and the camera UI and
Settings were not redesigned.

Everything below was established by reading and running the code in this
repository, not by trusting progress notes, release notes or prior claims.

---

## 1 · What already existed and is CORRECT (preserved, not rewritten)

The Unit 29/30 architecture is real and largely sound. Verified by inspection:

| Layer | File | Verdict |
|---|---|---|
| Pose analysis | `shared/ml/analysis/*` | Real. Measure → compare → severity → priority → temporal → **one** `PoseAnalysisDecision`. |
| Semantic state | `shared/coaching/types.ts` | Real, single definition of `CoachingState`. Not duplicated anywhere. |
| Analysis → semantics | `shared/coaching/coachingState.ts` | Translation only; re-decides nothing. |
| Category map | `shared/coaching/categories.ts` | Derived from the one copy table. |
| Language / phrase | `shared/coaching/phraseSelection.ts` | Category → language → intensity → non-repeated variation. |
| Cadence | `shared/coaching/speechPlanner.ts` | Decision only, produces no speech. |
| TTS | `mobile/src/core/voice/ttsService.ts` | Speech execution only. |

Boundary confirmed by static scan (now an automated test, §4):

* `shared/**` contains **zero** `expo-speech` imports and **zero**
  `Speech.speak(` calls — pose mathematics cannot reach TTS.
* `ttsService.ts` contains **no** geometry, thresholds, priority or severity
  derivation; it consumes `CoachingState` and calls the shared planner and
  phrase selector.
* `pose mathematics → semantic coaching → TTS` holds.
  `pose mathematics → TTS` does **not** exist.

The four "nothing can be judged" states already reach coaching honestly:
`reference-unavailable`, `reference-invalid`, `reference-incompatible`,
`reference-incomplete`, plus the analysis-side `no-live-pose`,
`insufficient-measurements`, `low-confidence`. Each becomes a non-speakable
`CoachingState` with its own token. **A missing reference never becomes a
correction.** No production reference data was invented.

---

## 2 · Defects FOUND and REPAIRED

### D1 — Direction was collapsed for both knees (correctness, user-visible)

`JOINT_GUIDANCE_RULES.leftKnee` and `.rightKnee` pointed **both** directions
at a single voice category (`leg_left` / `leg_right`). Those pools mix
opposite instructions in one list — e.g. `'Straighten the left leg…'` and
`'Bend the left leg slightly…'`, `'…सीधा करो…'` and `'…थोड़ा मोड़ो…'`.

Consequence: the engine decided the direction correctly, the on-screen
directive rendered it correctly, and then the **spoken** cue was drawn at
random from a pool that could say the exact opposite. Roughly half of all
knee corrections could be voiced backwards.

Repair (`shared/constants/poseInstructions.ts`,
`shared/ml/guidanceGenerator.ts`):

* Added four direction-correct categories with full Hindi/Hinglish and
  English *gentle* and *firm* pools: `leg_left_straighten`, `leg_left_bend`,
  `leg_right_straighten`, `leg_right_bend`.
* Knee rules now point `liveLessThanRef → *_straighten` and
  `liveGreaterThanRef → *_bend`.
* `leg_left` / `leg_right` were **not deleted** — working copy is retained
  and reclassified (see D5).

### D2 — The presentation contract re-derived engine decisions

`shared/ml/analysis/guidanceBridge.ts` recomputed two things the engine had
already decided:

* direction, from `correction.signedError < 0` — a second sign inference in a
  presentation mapper;
* severity, by re-thresholding `correction.absError` against
  `GUIDANCE_THRESHOLDS.good` — a second severity ladder that could silently
  diverge from the engine's.

Repair: the bridge now uses `correction.direction` and
`correction.severity` verbatim. The coarse UI colour band is produced by one
exported mapper, `guidanceSeverityFor()`. Behaviour is unchanged
(`minor → 'good'`, `major → 'adjust'`); the duplication is gone.

### D3 — `GuidanceResult` was a semantic dead end

The downstream interface carried copy, arrow, colour severity and raw
`liveAngles`/`angleDiffs`, but dropped the canonical state token, the engine
direction, the engine severity ladder and the confidence. Any consumer
needing them would have had to re-derive them from raw angles — i.e. redo
pose mathematics in a presentation layer.

Repair: added `GuidanceResult.semantics: GuidanceSemantics | null` carrying
`state`, `direction`, `analysisSeverity`, `confidence` verbatim. The legacy
landmark-in/guidance-out path (`generatePoseGuidance`) owns no engine
decision and reports `semantics: null` — explicitly absent, never faked.

### D4 — Three copies of the same "which way?" inference

`generatePoseGuidance` (`live < ref`), `guidanceBridge` (`signedError < 0`)
and `coachingCategoryFor` (`direction === 'increase'`) each resolved the copy
for a correction independently.

Repair: one resolver, `jointDirectiveFor(measurementId, direction)`, in
`shared/ml/guidanceGenerator.ts` next to the copy table. All three call sites
now funnel through it, so the on-screen directive, the arrow and the spoken
category cannot disagree about which way the body must move.

### D5 — Reachability trace mislabelled retained copy

`CATEGORY_COVERAGE` had only one "not reachable" class,
`reserved-no-measurement`, whose note claims the cause is a missing
head/neck/torso measurement. After D1 that note would have been false for
`leg_left`/`leg_right`.

Repair: added `reserved-superseded` with an accurate note.
`REACHABLE_CATEGORIES` now selects on the `reachable-` prefix rather than by
excluding one specific reserved kind.

### D6 — The test suite did not compile

`tests/integration/fullTrace.test.ts` referenced
`template.availability.partial`; the field is `isPartial`. `npm test` failed
at the compile step, so **the whole suite was not running**.
Repair: corrected the property name.

### D7 — A test asserted an exact rounding boundary

The same file compared integer match % between the provider path and the
direct path using offsets whose mean error is exactly `4.5°` → exactly
`97.5` → `Math.round` boundary. The lab fixture round-trips degrees through
radians with `toFixed(9)` (a documented loss below `1e-6°`), which flips that
boundary. The test was failing on a rounding artefact, not on a pipeline
disagreement.
Repair: moved the fixture off the boundary and added a direct
`avgDiffDegrees` equality assertion (`< 1e-6`), which is the real claim.

---

## 3 · Category reachability trace (computed, not hand-written)

Produced by `CATEGORY_COVERAGE`, asserted by tests:

| Category | Reachability | Produced by |
|---|---|---|
| `hand_up`, `hand_down` | reachable-correction | `leftShoulder`, `rightShoulder` |
| `hand_left`, `hand_right` | reachable-correction | `leftElbow`, `rightElbow` |
| `leg_left_straighten`, `leg_left_bend` | reachable-correction | `leftKnee` |
| `leg_right_straighten`, `leg_right_bend` | reachable-correction | `rightKnee` |
| `leg_open`, `leg_close` | reachable-correction | `leftHip`, `rightHip` |
| `final_pose_good` | reachable-perfect | stable PERFECT episode |
| `photo_clicking` | reachable-capture | capture flow, **not** pose analysis |
| `leg_left`, `leg_right` | reserved-superseded | none — direction-ambiguous copy, retained |
| `look_straight`, `look_left`, `look_right`, `chin_up`, `chin_down`, `shoulder_straight`, `back_straight` | reserved-no-measurement | none — no head/neck/torso measurement exists |

No category was invented to inflate a feature count; the four added exist
solely to preserve a direction the engine already computed.

---

## 4 · Tests added (`tests/coaching/semanticContract.test.ts`)

Deterministic: fixed fixtures, injected clock, injected random source.
No Supabase, no network, no production reference images, no device, no real
speech playback.

* PERFECT is explicit (own kind, own token, no fabricated correction).
* A correction becomes a canonical token, not a number (no geometry leaks).
* Direction preservation, both signs, and non-collapse of opposite directions.
* Direction survives the presentation contract verbatim.
* Severity preservation, verbatim, plus derived UI band via the one mapper.
* Confidence preservation.
* `reference-unavailable` / `-invalid` / `-incompatible` / `-incomplete`:
  each keeps its own token, is non-speakable, yields no phrase, no speech plan
  and no `GuidanceResult`; all four remain distinguishable.
* Analysis-unavailable (`no-live-pose`, low-visibility body) stays silent.
* Category mapping agrees with the one resolver for every shipped joint, and
  refuses to invent for unknown joints / `direction: 'none'`.
* Semantic state stability: one stable token while held, `stableFrames`
  monotone, ~1–2 utterances over 40 frames instead of per-frame nagging.
* Boundary tests: `shared/**` has no speech engine; `ttsService` has no
  geometry; the coaching layer hardcodes no instructor copy.
* Regression: no joint may point both directions at one voice category, and
  the two pools of a joint must share no line in either language.

---

## 5 · Verification actually run in this session

| Check | Command | Result |
|---|---|---|
| Dependency completeness | `mobile/scripts/verify-deps.mjs` | PASS |
| Platform purity | `npm run verify:purity` (mobile) | PASS |
| TypeScript (app) | `npm run typecheck` (mobile, SDK 57 deps installed) | PASS |
| Reference-architecture boundaries | `verify-reference-architecture.mjs` | PASS |
| Unit tests | `npm test` (root) | **208 / 208 PASS** |
| Preview build | `npm run build` (root) | PASS |

Not verified (no capability in this environment, not claimed):
Android/iOS native builds, on-device camera/MediaPipe, and real TTS playback —
including the audible quality of the new knee phrase pools.

---

## 6 · State handed to the next chat

* The canonical semantic contract is `CoachingState` in
  `shared/coaching/types.ts` — one definition, no duplicates.
* `GuidanceResult.semantics` is the presentation-side carry-through; add to it
  rather than re-deriving from `angleDiffs`.
* `jointDirectiveFor()` and `guidanceSeverityFor()` are the only permitted
  ways to turn a decision into copy or a colour band.
* Reserved categories are honestly classified; adding a head/neck/torso
  measurement is what makes `reserved-no-measurement` reachable.
* `tests/coaching/semanticContract.test.ts` is the contract's executable
  specification. Extend it before changing the contract.
