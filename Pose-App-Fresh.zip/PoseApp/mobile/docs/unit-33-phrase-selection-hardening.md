# Unit 33 — Part 4.2: semantic coaching → phrase-selection hardening

Audit + repair of the layer that turns a **semantic coaching state** into a
**spoken sentence**. Nothing else was touched: camera UI, Settings UI, pose
mathematics, the reference-data architecture, Supabase and the TTS engine
(`expo-speech`) are unchanged, and no LLM was introduced.

Scope of this document: what the code ACTUALLY does (read from source, not
from documentation), what was wrong, what was repaired, and what remains
deliberately unreachable.

---

## 1. The architecture as found (audited from source)

| Layer | File | Responsibility |
|---|---|---|
| Pose analysis | `shared/ml/analysis/*` | geometry, severity, priority, hysteresis |
| Copy table | `shared/ml/guidanceGenerator.ts` (`JOINT_GUIDANCE_RULES`, `jointDirectiveFor`) | ONE (measurement, direction) → on-screen text + `voiceCategory` |
| Semantic state | `shared/coaching/types.ts`, `coachingState.ts` | `CoachingState` = kind · token · category · direction · severity · **intensity** · confidence · stability · speakable |
| Category map | `shared/coaching/categories.ts` | (measurementId, direction) → category + reachability trace |
| Phrase bank | `shared/constants/poseInstructions.ts` | curated `hi` / `en` pools, gentle + firm tiers |
| Phrase selection | `shared/coaching/phraseSelection.ts` | state → category → language → intensity → pool → variation |
| Cadence | `shared/coaching/speechPlanner.ts` | WHEN to speak (no geometry) |
| Speech | `mobile/src/core/voice/ttsService.ts` | executes only |

Facts confirmed by reading the code:

- **Severity is NOT lost.** `PoseAnalysisDecision.correction.severity` is
  carried verbatim into `CoachingState.severity`, and
  `intensityForSeverity()` (one place, `coachingState.ts`) maps it to
  `'gentle' | 'firm'`. `ttsService` neither computes nor re-derives it — it
  forwards `phrase.intensity` to the pool and to a small prosody nudge
  (rate 1.04 vs 0.98). No angle or threshold exists anywhere in the speech
  layer.
- **Languages: exactly two** — `hi` (Hindi/Hinglish) and `en`, driven by
  `Settings → Voice Language` (`CameraSettings.voiceLanguage`, default `en`)
  and read once in `CameraTab` (`useSettingsStore`) before being passed to
  `ttsService.speakCoaching(state, voiceLanguage)`. The Settings integration
  was found correct and was **not** changed.
- **No per-language pose logic.** One semantic state feeds both banks.

---

## 2. Defects found and repaired

### D1 — elbow corrections spoke UNRELATED text (user-visible, corrected)

`JOINT_GUIDANCE_RULES.leftElbow.liveLessThanRef` ("Straighten left arm")
pointed at the voice category `hand_right`, whose pool says *"Hand a little
right… there, hold"* — a **lateral hand translation**, not an elbow
extension. All four elbow directives were mapped this way, so on every elbow
correction the screen and the voice gave different instructions.

Repair: four direction-correct categories with full `hi`/`en`, gentle+firm
pools — `hand_left_straighten`, `hand_left_bend`, `hand_right_straighten`,
`hand_right_bend` — and the elbow rules now point at them.
`hand_left` / `hand_right` copy is **retained** and reclassified as
`reserved-superseded` (no lateral-hand measurement exists).

### D2 — hip corrections spoke stance-width text (user-visible, corrected)

`leftHip`/`rightHip` ("Move left leg back" / "…forward") pointed at
`leg_close` / `leg_open`, which are **stance-width** lines ("Open your stance
a little", "Bring those feet well in"). The hip measurement is torso↔thigh:
the leg travels forward/back, the feet do not change width.

Repair: `leg_left_forward`, `leg_left_back`, `leg_right_forward`,
`leg_right_back` (hi/en, gentle+firm); hip rules repointed. `leg_open` /
`leg_close` retained as `reserved-superseded`.

### D3 — side-ambiguous firm lines shared across categories

Unit 32's firm pools contained lines such as *"Straighter, straighter… yes,
hold"* and *"और मोड़ो, और मोड़ो… हाँ, बस"* in BOTH the left and the right
pool. Selecting correctly still produced a sentence that did not tell the
user which limb to move, and made pool membership useless as a correctness
proof. Every such line now names its side (e.g. *"Straighter on the left…
yes, hold"*, *"और मोड़ो… बायां पैर… हाँ, बस"*). All reachable correction
pools are now **pairwise disjoint** — asserted by test.

### D4 — the pool fallback was silent

`instructionPool()` quietly returned the gentle pool when a firm pool was
missing. The behaviour was reasonable but invisible to callers and logs.

Repair: `resolveInstructionPool()` returns
`{ phrases, requestedIntensity, resolvedIntensity, fallback }` with
`fallback: 'exact' | 'gentle-pool' | 'none'`:

- `'exact'` — the authored pool for that exact triple;
- `'gentle-pool'` — firm requested, none authored ⇒ **same category**, softer
  tier (documented degradation, never other copy);
- `'none'` — nothing speakable ⇒ selection returns `null` and the coach stays
  silent.

### D5 — selection could not prove it matched the semantic state

`selectCoachingPhrase` trusted `state.category` blindly and resolved the pool
twice. It now:

1. rejects non-speakable states and any kind other than `correction` /
   `perfect`;
2. validates the category against the bank (`isVoiceInstructionCategory`) —
   an unknown id is silence, never a substitute phrase;
3. resolves the pool ONCE via `pickInstruction()` and returns the evidence:
   `category`, `language`, `requestedIntensity`, `intensity` (spoken),
   `fallback`, `poolSize`, `poolIndex`, `avoidedRepeat` and the semantic
   `token` the line was selected FOR.

`ttsService` logs that whole chain, so a mis-heard cue is traceable back to
the state that produced it.

### D6 — random source was not hardened

`Math.floor(random() * n)` trusted the injected source. `drawIndex()` now
clamps non-finite, negative, `>1` and throwing sources onto a valid index.
Randomness can only reorder equally valid lines of an already-resolved pool —
it can never change meaning. A fixed source is fully reproducible, so tests
are deterministic.

### D7 — `npm test` could not run on Node ≥ 22.19 (blocking)

`scripts/run-reference-tests.mjs` passed a *directory* to `node --test`,
which newer Node resolves as a module path (`MODULE_NOT_FOUND`) — the suite
did not execute at all in this environment. The runner now walks
`.test-build/tests` itself in sorted order and passes explicit files, so it
is deterministic and Node-version independent.

---

## 3. Category map after the repair

`REACHABLE_CATEGORIES` = **16** (14 correction + perfect + capture).

| Category | Producer(s) | Direction | Tiers |
|---|---|---|---|
| `hand_up` | leftShoulder ↑, rightShoulder ↑ | raise arm | gentle + firm |
| `hand_down` | leftShoulder ↓, rightShoulder ↓ | lower arm | gentle + firm |
| `hand_left_straighten` / `hand_left_bend` | leftElbow | extend / flex | gentle + firm |
| `hand_right_straighten` / `hand_right_bend` | rightElbow | extend / flex | gentle + firm |
| `leg_left_straighten` / `leg_left_bend` | leftKnee | extend / flex | gentle + firm |
| `leg_right_straighten` / `leg_right_bend` | rightKnee | extend / flex | gentle + firm |
| `leg_left_forward` / `leg_left_back` | leftHip | forward / back | gentle + firm |
| `leg_right_forward` / `leg_right_back` | rightHip | forward / back | gentle + firm |
| `final_pose_good` | stable PERFECT episode | — | gentle only (documented: a positive line is never stern; `fallback: 'gentle-pool'`) |
| `photo_clicking` | capture flow | — | gentle only (same documented fallback) |

**Known, documented limitation (not a defect):** `hand_up` / `hand_down` are
shared by the left and right shoulder measurements, so the spoken line does
not name the side ("Hand up a little… there, hold"). It is never *wrong* for
either side, only less specific; the on-screen directive still says "Raise
left arm". Tracked as `SIDE_AGNOSTIC_CATEGORIES` in
`shared/coaching/categories.ts` and asserted by test. Adding side-specific
shoulder pools is a future unit, not a silent assumption.

**Unreachable / reserved** (copy retained, never claimed as coaching, each
with a machine-checked note):

- `reserved-superseded`: `leg_left`, `leg_right` (Unit 32), `hand_left`,
  `hand_right`, `leg_open`, `leg_close` (Unit 33).
- `reserved-no-measurement`: `look_straight`, `look_left`, `look_right`,
  `chin_up`, `chin_down`, `shoulder_straight`, `back_straight` — no
  head/neck/torso-orientation measurement exists in the engine registry.

---

## 4. Variation control

- Immediate-repeat prevention lives in the bank, keyed by
  `language:category` (deliberately **not** by intensity, so a
  gentle→firm switch on a category that falls back to the gentle pool still
  cannot repeat the identical sentence).
- One deterministic step forward on a collision — bounded, so a degenerate
  random source can never hang the coach; `avoidedRepeat` reports it.
- `peek: true` reads a phrase without consuming the memory (diagnostics).
- `resetInstructionMemory()` is called by `ttsService.resetSession()`.

---

## 5. Style rules applied to the new copy

Short (4–8 words), spoken, actionable; fillers (`bas`, `hmm`, `haan`,
`theek hai`, `perfect`) used sparingly — never in every line, never twice in
one line. Firm copy is **direct, not aggressive** ("Straighten that left arm
fully… more", "बायां हाथ पूरा सीधा करो… और"); gentle copy still contains a
real instruction, never a meaningless murmur. Tests enforce: no abusive
words, length bounds, side naming, gentle ≠ firm, cross-category disjointness.

---

## 6. Verification (this session)

- Root `npm test` — **225/225 PASS** (208 pre-existing + 17 new Unit 33
  cases in `tests/coaching/phraseSelection.test.ts`).
- `mobile/scripts/verify-all.mjs` — **5/5 PASS** (dependency boundary,
  platform purity, `tsc --noEmit` strict, reference-architecture boundaries,
  unit tests).
- Root `npm run build` (Vite preview tooling) — PASS.

NOT verified here (no capability in this environment, not claimed): Android /
iOS native builds, on-device camera + MediaPipe, and how the new Hindi and
English lines actually SOUND through a real device TTS voice.
