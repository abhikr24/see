# Unit 34 — Part 4.3: speech timing (closure audit)

Closure audit of the layer that decides **when** the coach speaks. This is
deliberately not a redesign: Part 4.3 was already implemented in the source
tree, and the purpose of this pass was to prove — from the code, not from the
documentation — that the implementation is complete, correct, tested and
honestly recorded, and to repair only what was genuinely broken.

Nothing outside the speech-timing boundary was touched. Pose mathematics, the
reference-data architecture, Supabase, the camera UI, the Settings UI, the
phrase banks and the TTS engine (`expo-speech`) are unchanged, and no LLM was
introduced.

---

## 1. Scope of Part 4.3

| In scope | Out of scope |
|---|---|
| "Should the coach speak now?" | "What should the coach say?" (Unit 33) |
| Cadence, repetition, oscillation, overlap | Angles, thresholds, severity, hysteresis (Unit 29/30 engine) |
| The plan → execute contract with the TTS layer | Voice selection, prosody, phrase copy |
| Silence for unjudgeable states | Whether a state is judgeable (engine) |

---

## 2. The architecture as found (audited from source)

```
POSE ENGINE            shared/ml/analysis/*
  angles · thresholds · severity · priority · persistence · hysteresis
        ↓ PoseAnalysisDecision
SEMANTIC COACHING STATE  shared/coaching/types.ts + coachingState.ts
  kind · token · category · direction · severity · intensity ·
  confidence · stableFrames · speakable
        ↓
SPEECH PLANNER           shared/coaching/speechPlanner.ts    "speak NOW?"
        ↓
PHRASE SELECTION         shared/coaching/phraseSelection.ts  "say WHAT?"
        ↓
TTS                      mobile/src/core/voice/ttsService.ts "execute"
```

Findings, verified by reading the files:

- **The separation is real, not aspirational.** `speechPlanner.ts` imports
  exactly one thing — `type CoachingState`. It does not import
  `phraseSelection`, and `phraseSelection` does not import the planner.
  `tests/coaching/speechTiming.test.ts` asserts both directions statically.
- **The planner is platform-neutral.** No React, no browser API, no
  React Native, no `expo-speech`, no Supabase, no reference storage, no
  geometry. Its only inputs are `CoachingState`, a caller-supplied `nowMs`
  and an `isSpeaking` flag; it owns no timer and never reads a clock itself,
  which is what makes it testable on a fake clock.
- **The TTS layer computes nothing.** `ttsService` derives no angle,
  threshold, severity, confidence, landmark geometry, persistence or
  hysteresis. It consumes `CoachingState.intensity` (mapped once, upstream)
  and executes. A static test enumerates the forbidden identifiers.
- **`stableFrames` is read, never recomputed.** The planner applies a small
  floor (1 frame; 2 for PERFECT) *beneath* the engine's own persistence. It
  is a floor, not a second filter, and it is the only stability input.
- **Both the mobile app and the preview mirror run the same planner.** Only
  the speech backend differs (`expo-speech` vs. `window.speechSynthesis`).

**Conclusion of the audit: the architecture was already correct and has been
preserved.** It was not replaced with one global timer, and the state-aware
model was not flattened.

---

## 3. Cadence model

State-aware by design — one situation, one gate:

| Gate | Default | What it protects |
|---|---|---|
| `minGapMs` | 900 ms | Floor between any two lines. A genuinely new instruction is not held hostage by the repeat timer. |
| `repeatIntervalMs` | 4500 ms | The SAME uncorrected instruction is *reminded*, not nagged. |
| `alternationCooldownMs` | 2500 ms | A token already spoken recently cannot be re-announced just because another state briefly took over. This is what makes `A → B → A` calm. |
| `transitionBackoffMs` × `maxTransitionBackoffSteps` | 900 ms × 2 | The 1st change of instruction is prompt (900 ms), the 2nd waits 1.8 s, the 3rd+ 2.7 s. Counts how often the **coach** changed its mind, never how noisy the pose is. Capped, so the coach can never fall permanently mute. |
| `interruptGraceMs` | 1400 ms | A different state may replace a line in flight only after that line has had roughly one short cue of air. |
| `silenceGraceMs` | 600 ms | A *sustained* unjudgeable gap clears cadence memory so recovery is prompt; a single churn frame does not, so flicker cannot reset the gates. |
| `minStableFrames` / `perfectMinStableFrames` | 1 / 2 | A floor beneath the engine's persistence. |

A long quiet spell (`elapsed >= repeatIntervalMs`) forgives the accumulated
transition back-off, so a user who genuinely settles does not inherit the
penalty of an earlier noisy stretch.

### The old 3-second debounce — what actually happened to it

`INTELLIGENT_CAPTURE_TIMING.voiceDebounceMs` (3 s) was **not deleted**. It was
traced to its callers first:

| API | Gate today |
|---|---|
| `speakGuidance(text)` — legacy Unit 18 raw text | duplicate-text + 3 s debounce (unchanged) |
| `speakInstruction(category, …)` without `force` | duplicate-text + 3 s debounce (unchanged) |
| `speakInstruction('photo_clicking', …, { force: true })` — capture cue | `force` bypasses both (unchanged, Unit 27 behaviour) |
| `speakCoaching(state, …)` — **the coaching path** | speech planner only |

Coaching calls `speakCore` with `force: true`, which here means *"cadence was
already decided upstream"*, never *"speak unconditionally"*. There is
therefore **no accidental double debounce on coaching**, and legacy/capture
behaviour is not broken. A static test asserts that `CameraTab` has exactly
one `speakCoaching` call site, no `speakGuidance` call at all, and that
`photo_clicking` is the only category spoken outside the planner.

---

## 4. Perfect-state behaviour

```
correction → stable correction → user adjusts → stable perfect
  → ONE positive confirmation → silence for the rest of the episode
```

Two independent guards, because either alone has a hole:

1. `perfectEpisodeSpoken` — set when the positive line is authorized, cleared
   **only** by a speakable non-perfect state, or by a sustained silence gap.
   An evaluating/unavailable flicker cannot clear it.
2. The token's own `alternationCooldownMs` — closes the case where an
   *unspoken* correction flicker between two perfect runs would otherwise
   clear the flag and let praise repeat.

There is no separate motivational engine; PERFECT is just another semantic
state with its own re-entry rule. Frame-by-frame praise is impossible:
1 200 consecutive perfect frames (≈ 80 s) produce exactly one line.

---

## 5. Oscillation protection

- `A → B → A` — the returning `A` is damped by its own token cooldown
  (`recently-said`), **not** discarded: once the cooldown expires and `A` is
  still real, it is spoken. The user is never left uncorrected.
- `A → B → A → B → A` — each change of instruction increments the transition
  back-off, so a sustained ping-pong settles at roughly one calm line every
  2.7 s instead of narrating the loop. Tested over 20 s of fast alternation
  and asserted to stay inside a human speaking rate.
- `PERFECT ↔ correction` flicker every ~4 frames for ~8 s — asserted not to
  chant.

---

## 6. Overlap policy: interrupt-and-replace, never queue

`expo-speech` offers no safe application-level queue here — at 15 fps
utterances would pile up and the coach would narrate the past. So:

- At most **one** line is ever authorized.
- A new state arriving mid-utterance is either suppressed (`reason:
  'speaking'`) or, past `interruptGraceMs`, replaces the current line with
  `plan.interrupts === true`; `speakCore` calls `Speech.stop()` first, so the
  replacement is a clean swap and never an overlap.
- The same token can never be handed to a busy engine twice.

**Speech-in-flight is claimed synchronously.** `onStart` is an async native
callback; at ~66 ms per frame several frames can be planned before it fires.
The service therefore claims `activeGeneration` at the moment the decision to
speak is committed, not when the engine confirms. Each utterance carries a
generation; callbacks release the claim **only** if their generation still
owns it, so a late `onStopped` from a replaced line cannot clear the flag of
its replacement. A `UTTERANCE_WATCHDOG_MS` (8 s) ceiling releases a claim if
a native engine never delivers `onDone`/`onStopped`, so a stuck TTS pack
cannot mute coaching forever.

---

## 7. Unavailable states are silent by construction

`!state.speakable` returns before any cadence logic and there is **no code
path from it to a correction phrase** — not in the planner, and not in
`selectCoachingPhrase`, which independently refuses non-speakable states and
null categories. Covered for every reason:

`no-live-pose` · `low-confidence` · `reference-unavailable` ·
`reference-invalid` · `reference-incomplete` · `reference-incompatible` ·
`insufficient-measurements` · `evaluating` (unstable)

None of these can produce corrective speech, whatever the clock says.

---

## 8. Defect found and repaired

### D1 — an authorization that could not be executed was still charged to the user

**Found.** `plan()` commits its cadence memory the instant it authorizes a
line — correctly, because the next ML frame is only ~66 ms away and must
already see "just spoken". But the executor downstream can still legitimately
produce nothing:

- `selectCoachingPhrase` returns `null` for a retired/unknown category or a
  missing pool. That is *deliberate* Unit 33 behaviour ("a missing pool is
  silence, never another category's text"), so it is a live path.
- `speakCore` returns `false` when the utterance is superseded before the
  native engine starts it, or when start throws.

In both cases the planner kept the credit for a line **nobody heard**.

**Impact.** For a correction, the instruction was suppressed for up to one
repeat interval (4.5 s). For PERFECT it was user-visible and permanent: the
single positive response of the entire episode was spent on silence, and
`perfectEpisodeSpoken` guaranteed it would never be offered again.

**Repair (targeted, additive — no gate was changed).**

- `speechPlanner` gained `revert(plan): boolean`. It restores the exact
  pre-commit snapshot (last spoken token and clock, that token's previous
  recency entry, the transition counter and the perfect-episode flag) and is
  **identity-checked**: it succeeds only while that plan is still the most
  recent authorization, so a late failure callback from a superseded line
  cannot disturb the line that replaced it. It is idempotent, it is cleared
  by `reset()`, and it cannot be used on a suppressed plan — there is nothing
  to undo, so it returns `false`.
- Committing was made atomic. `perfectEpisodeSpoken` used to be set by the
  caller *next to* `spoke()`; it is now set *inside* `spoke()`, in the same
  place the snapshot is taken, so the flag that guarantees "one positive line
  per episode" can never fall out of step with the undo.
- `ttsService.speakCoaching` now withdraws on both failure paths: phrase
  selection returned silence, and `speakCore` returned `false`.
- The preview mirror (`tooling/preview`) applies the same contract, so
  preview cadence cannot drift away from device cadence.

No timing constant, no gate, no ordering and no public behaviour of `plan()`
changed. Six regression tests were added.

### Considered and deliberately left alone

- The state-aware cadence model — correct; not replaced with one timer.
- The synchronous in-flight claim, generation guards and watchdog — already
  correct; no genuine race remained beyond D1.
- The legacy 3 s debounce — still required by the legacy text/category APIs;
  traced, documented, and confirmed absent from the coaching path.
- `ttsService.speaking` is written but not read (the planner is driven by the
  synchronous `activeGeneration` claim instead). Harmless bookkeeping; left
  in place rather than churned during a closure audit.

---

## 9. Tests

`tests/coaching/speechTiming.test.ts` — **35 cases**, all driven by a fake
clock (no test sleeps, reads `Date.now()`, or depends on machine speed) and
hand-built semantic states (the pose engine is not in the loop, so a cadence
regression cannot hide behind pose noise).

| Group | Covers |
|---|---|
| 1 · repeated stable state | said once not per frame; once across a full second; reminded at the repeat interval with the gap asserted |
| 2 · genuine transition | new instruction once cadence permits; not made to wait out the *old* state's repeat interval |
| 3 · perfect | exactly one positive response; 1 200 perfect frames → 1 line; evaluating flicker does not re-trigger praise; leaving for a real correction starts a new episode; perfect/correction flicker cannot chant |
| 4 · oscillation | `A → B → A` damped; `A → B → A` eventually spoken, not lost; 20 s of fast ping-pong stays within a human speaking rate |
| 5 · unavailable | never any correction speech; every non-speakable reason silent whatever the clock says; unstable never spoken; sustained loss then prompt recovery; one-frame churn cannot bypass the gates |
| 6 · overlap | cannot chop a line that just started; replaces cleanly past the grace with `interrupts === true`; never talks over itself with the same instruction; an external capture cue is respected |
| 7 · boundary | `reset()`; determinism across two planners; severity/confidence do not change timing; static scan for pose mathematics; planner ↔ phrase-selection separation; single coaching call site in `CameraTab`; config overridable |
| 8 · plan → execute (**new**) | unexecutable PERFECT does not spend the episode; withdrawn correction restores memory exactly; withdrawing does not reopen a gate for a different state; identity-checked and idempotent; a suppressed plan cannot be reverted into speech; `reset()` invalidates outstanding authorizations; static check that the executor withdraws on both failure paths |

---

## 10. Verification actually executed in this session

| Check | Command | Result |
|---|---|---|
| Platform purity | `mobile/ npm run verify:purity` | **PASS** |
| Dependency completeness | `verify-deps.mjs` (via `verify-all`) | **PASS** |
| TypeScript typecheck (app) | `mobile/ tsc --noEmit` | **PASS** |
| TypeScript typecheck (preview tooling) | `tsc --noEmit -p tsconfig.json` | **PASS** (exit 0) |
| Reference-architecture boundaries | `verify-reference-architecture.mjs` | **PASS** |
| Full unit suite | `npm test` | **260 / 260 PASS, 0 fail** |
| Speech timing suite | `tests/coaching/speechTiming.test.ts` | **35 / 35 PASS** |
| Semantic coaching suite | `tests/coaching/semanticContract.test.ts` | **22 / 22 PASS** |
| Phrase selection suite | `tests/coaching/phraseSelection.test.ts` | **17 / 17 PASS** |
| Coaching state suite | `tests/coaching/coaching.test.ts` | **16 / 16 PASS** |
| Full-trace integration | `tests/integration/fullTrace.test.ts` | **14 / 14 PASS** |
| `verify-all` | `mobile/ node scripts/verify-all.mjs` | **5 / 5 PASS** |
| Preview production build | `npm run build` | **PASS** (`dist/index.html`, 575.72 kB) |

**Lint:** no lint script and no ESLint configuration exist anywhere in this
repository (`package.json`, `mobile/package.json`, no `.eslintrc*` /
`eslint.config.*`). Nothing was run and nothing is claimed. The repo's
enforced static gates are `verify-purity`, `verify-deps`,
`verify-reference-architecture` and `tsc --noEmit`, all of which pass.

---

## 11. Remaining limitations — NOT physically verified

Everything above is **IMPLEMENTED** and **TESTED LOCALLY** on a fake clock
with synthetic semantic states. The following were **NOT PHYSICALLY
VERIFIED**, are not claimed, and remain open:

- **No real TTS playback was heard.** There is no device, emulator, audio
  device or Android/iOS SDK in this environment. Every overlap, interrupt and
  cadence assertion is against the planner's decisions and the service's
  state machine — not against audio.
- **`expo-speech` native callback behaviour is unproven on hardware.** The
  synchronous in-flight claim and the 8 s watchdog exist precisely because
  some Android TTS packs are known to be unreliable with
  `onStart`/`onDone`/`onStopped`, but which packs misbehave, and how the
  watchdog feels in practice, can only be established on a device.
- **Perceived cadence is untuned by a human ear.** 900 / 4500 / 2500 / 1400 ms
  are reasoned from the 15 fps ML budget and the length of the curated cues;
  they have not been confirmed by listening to a real session, and are
  overridable (`createCoachingSpeechPlanner(overrides)`) for exactly that
  reason.
- **Hindi and English voice quality on real hardware is unverified** — voice
  availability, locale fallback and neural-voice scoring all depend on the
  installed OS voice packs.
- **No end-to-end camera → MediaPipe → coaching → speech run was performed.**
  Native Android/iOS builds remain blocked here; the checked-in `android/`
  folder still predates SDK 57 and must be regenerated with
  `npx expo prebuild --clean` (or by EAS) before any local native build.
