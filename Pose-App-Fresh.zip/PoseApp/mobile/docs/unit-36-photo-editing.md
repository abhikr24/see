# Unit 36 — Post-capture photo editing (crop · rotate · enhance)

> Scope: what happens to a photograph AFTER the shutter. Nothing in this unit
> touches the live camera, the capture pipeline's decisions, MediaPipe, the
> coaching engine or the storage abstraction.

## 1. Audit of the pipeline as found (before any change)

| Concern | What already existed | Verdict |
|---|---|---|
| Capture output | `core/camera/cameraService.takePicture` → `quality 0.9`, no base64, no EXIF, single-flight | Kept |
| Capture processing | `core/camera/photoBrightness.applyCaptureFraming` — ONE Skia pass: look ∘ strength ∘ brightness colour matrix + centre aspect crop, JPEG q92, identity = no-op | Kept |
| Temp files | Capture writes `poseassist-shot-*.jpg` beside the camera-cache file and deletes the original | Kept |
| Durable storage | `galleryLocalDatasource.persistCapturedFile` → `Documents/PoseAssist/<userId>/<id>.jpg` | Kept |
| Metadata | MMKV, per-account key, metadata only (id, poseId, imagePath, filterUsed, timestamp) | Kept + one optional field |
| System gallery | `MediaLibrary.saveToLibraryAsync(durableUri)` | Kept |
| Sharing | `Sharing.shareAsync(uri, { mimeType: 'image/jpeg', UTI: 'public.jpeg' })` | Kept |
| Gallery flow | React Query over MMKV + file-existence verification, stale-record pruning | Kept |
| Crop / rotate | **Only** the pre-shot centre crop from `aspectCropRect`. No user crop. | **Missing** |
| Rotation | Nothing, anywhere | **Missing** |
| Adjustments | Capture-time brightness detent only; nothing post-capture | **Missing** |
| Edit entry point | None in either preview screen | **Missing** |

Conclusion: the pipeline was sound and honest; it simply had no post-capture
stage. This unit adds exactly that stage and changes nothing upstream of it.

## 2. What was built

| Layer | File | Role |
|---|---|---|
| Brain | `shared/camera/photoEditing.ts` | Rotation algebra, crop model + gesture maths, enhancement → colour matrix, geometry resolution, draw transform, file/encoding policy |
| Brain | `shared/camera/cameraFilters.ts` | Published `saturationColorMatrix` / `contrastColorMatrix` / `temperatureColorMatrix` / `luminanceColorMatrix` so the editor reuses the app's ONE definition of those words |
| Device | `mobile/src/core/camera/photoEditor.ts` | One Skia pass (decode → rotate/crop draw → colour matrix → JPEG q95 → cache file), plus `replaceFileWithEdit`, `discardEditTempFile`, `sweepEditTempFiles` |
| UI | `.../camera/presentation/screens/PhotoEditorScreen.tsx` | Full-screen editor: Skia preview, crop overlay, three tool tabs |
| UI | `.../camera/presentation/components/CropFrame.tsx` | Corner handles + move, dimmed discard area, thirds guides |
| UI | `.../camera/presentation/components/EditToolPanels.tsx` | Ratio chips, rotate buttons, Original⇄Enhanced switch, four sliders |
| Data | `galleryLocalDatasource.replaceStoredPhotoFile` | Writes the edited file under a NEW name, repoints metadata, deletes the old file |
| Data | `useGallery.useEditPhoto` | One mutation: render → swap → invalidate |
| Entry | `PreviewScreen`, `GalleryPhotoPreviewScreen` | "Edit" action, editor layer, result chip |
| Mirror | `tooling/preview/src/preview/photo-editor-mirror.tsx` | Browser mirror using the SAME shared functions |
| Tests | `tests/camera/photoEditing.test.ts` | 22 cases |

## 3. Decisions and their reasons

* **Skia, not a new library.** `@shopify/react-native-skia` (MIT) is already a
  dependency, already in the native build, already used by the capture
  pipeline. `expo-image-manipulator` would have added a native module and still
  could not do brightness/contrast/saturation; pure-JS pixel libraries would
  freeze the JS thread on a 12 MP JPEG. **No dependency was added** —
  `verify-deps` passes unchanged.
* **Quarter turns only.** Lossless; arbitrary-angle straightening always crops
  and resamples and is a different, larger feature.
* **Crop stored normalised against the rotated frame.** Survives layout,
  density and devices that report pre-rotation capture sizes.
* **Rotation carries the crop** (`rotateCropRect`) instead of resetting it.
* **Enhance = one tap + four sliders, and the tap IS the sliders.**
  `AUTO_ENHANCE` is `brightness +10, contrast +15, saturation +20, warmth +10`,
  proven by test to move mid-grey by < 10 %.
* **Brightness boundary.** Post-capture brightness is `PHOTO_EDIT_ADJUST_*`
  (−100…+100) in `photoEditing.ts`; the live camera detent stays
  `BRIGHTNESS_*` (−3…+3) in `cameraControls.ts`. Separate constants, separate
  state, separate stores. A test asserts the two disagree at the same numeric
  input.
* **Identity is a no-op.** Apply is disabled when nothing changed, and the
  renderer returns the original file untouched — no needless recompression.
* **Encoding.** JPEG q95 (capture uses q92) because an edit is a second
  generation. No resize. Format unchanged because every downstream consumer
  (sharing MIME/UTI, `<id>.jpg`, MediaLibrary) was built around JPEG; HEIC
  input decodes fine, only the edited output is normalised.
* **New filename on every edit**, because `expo-image` caches by URI and an
  in-place overwrite would leave the grid showing the pre-edit picture.
* **Write-then-delete ordering**, so a crash costs a cache file, never a photo.
* **System gallery honesty.** MediaLibrary cannot rewrite an existing asset, so
  editing a saved photo adds an edited COPY and the snackbar says so.
* **Temp-file hygiene.** Outputs are named `poseassist-edit-*`; a sweeper runs
  on preview mount and only ever deletes files with that prefix.

## 4. Verification actually executed

* `mobile/ npx tsc --noEmit` — **PASS** (mobile deps installed for this run).
* `mobile/ npm run verify:purity` — **PASS**.
* `node mobile/scripts/verify-deps.mjs` — **PASS** (no new dependency).
* `node mobile/scripts/verify-reference-architecture.mjs` — **PASS**.
* root `tsc --noEmit -p tsconfig.json` and `-p tooling/preview/tsconfig.json` — **PASS**.
* root `npm test` — **449 tests, 446 pass**, including 22 new
  `tests/camera/photoEditing.test.ts` cases. The 3 failures are the SAME
  pre-existing language-default cases recorded in previous sessions; they are
  untouched and out of scope.
* root `npm run build` — **PASS**, `dist/index.html` 633.47 kB.
* Lint: **NOT RUN — still none configured** (no script, no ESLint config).

## 5. Not verified (no capability here — not attempted, not claimed)

No device and no simulator were available. The following are hardware claims
and are NOT made: the wall-clock cost of the Skia pass on a 12 MP file on
low-end Android; peak memory during `MakeOffscreen` at full resolution; the
behaviour of `MediaLibrary.saveToLibraryAsync` with an edited copy on iOS 18+
limited-library mode; HEIC decode on iOS through `Skia.Data.fromURI`; and
VoiceOver/TalkBack traversal of the crop handles. The browser mirror applies
the identical matrices and geometry but is a canvas, not Skia, and proves
nothing about on-device performance.
