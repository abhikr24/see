// Metro config — extends Expo defaults so the bundler also watches the
// mobile-local `shared/` brain (platform-neutral TypeScript).
//
// HARD BOUNDARY: the coding-environment preview tooling (tooling/preview/,
// Vite + React DOM) is OUTSIDE the watch set and OUTSIDE the resolution
// paths — it can never be bundled into, or imported by, the app. Production
// resolves packages exclusively from mobile/node_modules; `shared/` is pure
// TypeScript with zero bare imports, so it needs no package lookup of its own.
const { getDefaultConfig } = require('expo/metro-config');
const path = require('path');

const projectRoot = __dirname;
const workspaceRoot = path.resolve(projectRoot, '..');
const appSharedRoot = path.resolve(projectRoot, 'shared');

const config = getDefaultConfig(projectRoot);

config.watchFolders = [appSharedRoot];
config.resolver.nodeModulesPaths = [path.resolve(projectRoot, 'node_modules')];

// Universal-build repair (documented in mobile/src/core/ml/mediapipeWebUnsupported.ts):
// @mediapipe/tasks-vision's vision_bundle.mjs contains a NON-LITERAL dynamic
// import (`import(t.toString())`) that Metro cannot transform on ANY platform —
// verified 2026: `npx expo export --platform android` fails with
// "Invalid call at line 1: import(t.toString())" when the real package enters
// the native graph. It still does: handDetectorService.ts (open-palm capture,
// CameraTab → gestureDetector) lazily import()s the package.
//
// Post-A1, POSE detection on Android/iOS is REAL and native (VisionCamera +
// ML Kit via mobile/native/vision-camera-mlkit-pose) and never touches this
// package. The remaining WASM consumers (hand landmarker + the legacy
// poseDetectorService) therefore resolve to the scoped stub on EVERY
// platform: Metro never transforms vision_bundle.mjs (so eas build succeeds),
// and the stub's throw at import time feeds those services' existing
// 'unavailable' fallback — exactly the documented hand-on-native behaviour
// (unavailable today; native replacement seam lives on the pose plugin).
const MEDIAPIPE_STUB = path.resolve(
  projectRoot,
  'src/core/ml/mediapipeWebUnsupported.ts',
);
config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName === '@mediapipe/tasks-vision') {
    return { type: 'sourceFile', filePath: MEDIAPIPE_STUB };
  }
  /* @supabase/realtime-js (locked 2.11.2, only main/module fields — no
     react-native/browser/exports condition) references Node's `ws` package
     via a string-literal require inside its NODE-ONLY branch:
     RealtimeClient.js:176. Metro collects that literal statically, so ws
     enters the NATIVE graph and bundling dies on Node builtins
     (`Unable to resolve module stream …/ws/lib/stream.js`). Reproduced with
     `npx expo export --platform android` — pre-existing (identical lockfile
     entry pre-A1), merely masked by the mediapipe failure above.
     On React Native the branch is dormant: RN's runtime provides a global
     WebSocket, which realtime-js uses instead — exactly the documented
     Supabase-on-RN behaviour. An empty module on native is therefore the
     canonical, behaviour-preserving repair. Web resolution is untouched. */
  if (moduleName === 'ws' && platform !== 'web') {
    return { type: 'empty' };
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;
