# `hardware-shutter` — local Expo module (volume-button shutter)

First-party, in-repo, **zero third-party dependencies**. Autolinked by
`expo-modules-autolinking` because it lives in `mobile/modules/`.

It exposes exactly one capability to JavaScript:

```ts
import { requireOptionalNativeModule } from 'expo';
const native = requireOptionalNativeModule('HardwareShutter'); // null in Expo Go
```

| Member | Meaning |
| --- | --- |
| `isSupported: boolean` | Can this platform deliver hardware-key presses at all? |
| `unsupportedReason: string \| null` | Honest, loggable reason when it cannot. |
| `setArmed(armed: boolean): void` | Start/stop intercepting the volume keys. |
| `isArmed(): boolean` | Current native arming state (diagnostics). |
| `onShutterPress` event | `{ key: 'volume-up' \| 'volume-down', repeat: boolean }` |

The JS side never imports this folder directly — `mobile/src/core/camera/hardwareShutterService.ts`
resolves it by name with `requireOptionalNativeModule`, so a build *without*
the module degrades to "feature unavailable" instead of crashing.

---

## Android — real support, by **interception**

`HardwareShutterBridge` is consulted from `MainActivity.dispatchKeyEvent`
(injected by `mobile/plugins/withHardwareShutter.js`, and already present in
the checked-in `android/` project).

While **armed**:

* `KEYCODE_VOLUME_UP` / `KEYCODE_VOLUME_DOWN` `ACTION_DOWN` → `onShutterPress`
* both `ACTION_DOWN` and `ACTION_UP` are **consumed** (`return true`)

Consuming the event is the whole point: the media/ring volume **does not
change**, no system volume HUD appears, and nothing has to be "corrected"
afterwards. This is why the module does *not* observe `AudioManager` volume
or a `ContentObserver` on `Settings.System` — those approaches let the volume
change first and then fight it, which is exactly the behaviour a user
experiences as a bug.

While **disarmed** the bridge returns `false` immediately and Android handles
the keys normally. The bridge also disarms itself when the activity leaves
the foreground and when JS stops observing, so a backgrounded app can never
hold the keys hostage.

`KEYCODE_VOLUME_MUTE` is deliberately **not** intercepted — silencing a phone
is a safety action and must always work.

## iOS — deliberately reported as **unsupported**

iOS has **no public API** for volume-button key events. The only route is
KVO on `AVAudioSession.outputVolume` (usually with a hidden `MPVolumeView` to
suppress the HUD and a re-set of the volume to keep headroom). That approach
was evaluated and rejected for this app:

1. it **changes the user's media volume** to detect a press, then changes it
   back — the precise anti-behaviour this feature exists to avoid;
2. it requires activating an audio session in a camera screen that otherwise
   needs none (`recordAudioAndroid: false` is already set in `app.json`);
3. it breaks at the volume rails (0 % / 100 %), which is why real-world
   implementations juggle the volume to ~94 %;
4. App Review guideline 2.5.9 treats altering standard hardware-button
   behaviour as a rejection risk; the camera-shutter case is *usually*
   tolerated, but "usually" is not a foundation for a shipped promise.

So the iOS module returns `isSupported = false` with
`unsupportedReason = "ios-no-public-key-event-api"`. The app reads that and
simply never promises the feature on iOS: the on-screen shutter, auto
capture, the five-finger gesture and the timer are all unchanged there.

Re-enabling iOS later is a contained change: implement `setArmed` + the
`onShutterPress` event in `ios/HardwareShutterModule.swift` and flip
`isSupported`. No JavaScript, no capture logic and no UI has to move.

## Build requirements

* **Development build / EAS build required.** Expo Go does not contain this
  module; `requireOptionalNativeModule` returns `null` there and the app
  reports `missing-native-module`.
* Android: nothing beyond the existing `android/` project.
* iOS: nothing — the Swift file compiles to a no-op capability report.
