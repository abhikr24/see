package expo.modules.hardwareshutter

import android.view.KeyEvent

/**
 * HardwareShutterBridge — the single point where a physical key event
 * becomes (or does not become) a shutter press.
 *
 * WHY A PROCESS-WIDE OBJECT
 * Key events are dispatched by the Activity, not by the Expo module; the
 * module can be created and destroyed with the React context while the
 * Activity lives on. Keeping the arming flag and the listener here means
 * `MainActivity.dispatchKeyEvent` has exactly one, always-valid thing to ask.
 *
 * THE CONTRACT
 *  · `armed == false` → `dispatchKeyEvent` returns false IMMEDIATELY and
 *    Android handles the volume keys exactly as it does in every other app.
 *  · `armed == true`  → VOLUME_UP / VOLUME_DOWN are CONSUMED (both DOWN and
 *    UP) so the system volume never moves, and ACTION_DOWN is reported once
 *    to JavaScript. Auto-repeat is reported with `repeat = true` so the JS
 *    policy gate can discard it without guessing.
 *  · VOLUME_MUTE is never intercepted — silencing a phone is a safety
 *    action and must always work.
 *  · Anything else (power, back, media keys, headset buttons) is untouched.
 */
object HardwareShutterBridge {

  /** Volatile: written from the JS thread, read on the Android UI thread. */
  @Volatile
  var armed: Boolean = false
    private set

  @Volatile
  private var listener: ((String, Boolean) -> Unit)? = null

  fun setArmed(value: Boolean) {
    armed = value
  }

  fun setListener(value: ((String, Boolean) -> Unit)?) {
    listener = value
    /* Losing the listener also loses the right to swallow keys: a consumed
       key with nobody to report it to is a key the user simply lost. */
    if (value == null) {
      armed = false
    }
  }

  /**
   * Called from `MainActivity.dispatchKeyEvent`.
   *
   * @return true when the event was consumed as a shutter press, in which
   *         case the Activity must NOT pass it on to `super`.
   */
  @JvmStatic
  fun dispatchKeyEvent(event: KeyEvent): Boolean {
    if (!armed) return false

    val key = when (event.keyCode) {
      KeyEvent.KEYCODE_VOLUME_UP -> "volume-up"
      KeyEvent.KEYCODE_VOLUME_DOWN -> "volume-down"
      else -> return false
    }

    val callback = listener ?: return false

    if (event.action == KeyEvent.ACTION_DOWN) {
      callback(key, event.repeatCount > 0)
    }

    /* Consume the UP as well. Reporting only the DOWN while letting the UP
       through leaves some OEM skins showing the volume HUD on release. */
    return true
  }
}
