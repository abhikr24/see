package expo.modules.hardwareshutter

import android.os.Bundle
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/**
 * HardwareShutterModule (Android) — the JS-facing half of the volume-button
 * shutter. It owns NO capture logic: it reports presses and nothing else.
 *
 * Lifecycle safety is the interesting part here. Every one of these hooks
 * exists because a camera app that keeps the volume keys after the user has
 * navigated away, backgrounded the app, or reloaded the bundle is a bug the
 * user cannot diagnose:
 *
 *   OnStartObserving        JS attached a listener → wire the bridge.
 *   OnStopObserving         JS detached           → unwire AND disarm.
 *   OnActivityEntersBackground / OnDestroy
 *                           the app is no longer in front → disarm.
 */
class HardwareShutterModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("HardwareShutter")

    Events("onShutterPress")

    Constants(
      "isSupported" to true,
      "unsupportedReason" to null,
      "platform" to "android",
      /* Documented so the app can log WHAT it is doing to the volume keys. */
      "interceptionMode" to "key-event-consumed",
    )

    Function("setArmed") { armed: Boolean ->
      HardwareShutterBridge.setArmed(armed)
    }

    Function("isArmed") {
      HardwareShutterBridge.armed
    }

    OnStartObserving {
      HardwareShutterBridge.setListener { key, repeat ->
        sendEvent(
          "onShutterPress",
          Bundle().apply {
            putString("key", key)
            putBoolean("repeat", repeat)
          },
        )
      }
    }

    OnStopObserving {
      HardwareShutterBridge.setListener(null)
    }

    OnActivityEntersBackground {
      HardwareShutterBridge.setArmed(false)
    }

    OnDestroy {
      HardwareShutterBridge.setListener(null)
    }
  }
}
