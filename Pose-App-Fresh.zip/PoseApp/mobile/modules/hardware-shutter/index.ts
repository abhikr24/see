/**
 * mobile/modules/hardware-shutter/index.ts
 *
 * Intentionally minimal. Application code does NOT import this file: it
 * resolves the native module by name through
 * `mobile/src/core/camera/hardwareShutterService.ts`
 * (`requireOptionalNativeModule('HardwareShutter')`), so a build that does
 * not contain the native side — Expo Go, or a stale development client —
 * degrades to "capability unavailable" instead of failing to bundle.
 *
 * This file exists so the folder is a well-formed local Expo module and so
 * the contract has one typed home.
 */
export interface HardwareShutterPressEvent {
  readonly key: 'volume-up' | 'volume-down';
  /** Android auto-repeat while the key is held. Never a new intent. */
  readonly repeat: boolean;
}

export interface HardwareShutterNativeContract {
  readonly isSupported: boolean;
  readonly unsupportedReason: string | null;
  readonly platform: string;
  readonly interceptionMode: 'key-event-consumed' | 'none';
  setArmed(armed: boolean): void;
  isArmed(): boolean;
}

export const HARDWARE_SHUTTER_NATIVE_MODULE_NAME = 'HardwareShutter';
export const HARDWARE_SHUTTER_EVENT = 'onShutterPress';
