Pod::Spec.new do |s|
  s.name           = 'HardwareShutter'
  s.version        = '1.0.0'
  s.summary        = 'Physical-button shutter capability report (iOS: unsupported by design).'
  s.description    = 'Local Expo module. On iOS it reports isSupported = false — see ios/HardwareShutterModule.swift for the rationale.'
  s.author         = 'PoseAssist'
  s.homepage       = 'https://github.com/'
  s.platforms      = { :ios => '15.1', :tvos => '15.1' }
  s.source         = { git: '' }
  s.static_framework = true

  s.dependency 'ExpoModulesCore'

  s.pod_target_xcconfig = {
    'DEFINES_MODULE' => 'YES',
    'SWIFT_COMPILATION_MODE' => 'wholemodule'
  }

  s.source_files = "**/*.{h,m,mm,swift,hpp,cpp}"
end
