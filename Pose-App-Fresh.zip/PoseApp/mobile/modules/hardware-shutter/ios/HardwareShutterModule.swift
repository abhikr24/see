import ExpoModulesCore

/**
 HardwareShutterModule (iOS) — DELIBERATELY UNSUPPORTED.

 iOS exposes no public API for volume-button key events. The only technique
 available to a third-party app is KVO on `AVAudioSession.outputVolume`,
 normally combined with a hidden `MPVolumeView` to suppress the system HUD
 and a write back to the volume to keep headroom at the rails.

 That technique is rejected for this app, on purpose:

 1. It DETECTS A PRESS BY LETTING THE VOLUME CHANGE. The user's media volume
    moves and is then moved back. Our whole contract is "a volume key that
    takes a photo does not touch your volume", and this cannot honour it.
 2. It requires activating an audio session on a camera screen that needs no
    audio at all (`recordAudioAndroid: false` is already configured).
 3. It fails at 0 % and 100 % volume, which is why shipping implementations
    quietly pin the volume near 94 % — another silent mutation of a user
    setting.
 4. App Review guideline 2.5.9 (altering standard hardware-button behaviour)
    makes it a review risk. The shutter case is commonly tolerated, but a
    tolerated risk is not a shipped promise.

 Reporting `isSupported = false` is therefore the honest answer. The JS layer
 reads it, resolves the capability as `unsupported-platform`, never arms, and
 never shows the user anything that implies iOS can do this. The on-screen
 shutter, auto capture, the five-finger gesture, the timer and every piece of
 capture feedback behave exactly as before on iOS.

 TO ENABLE LATER: implement `setArmed` + emit `onShutterPress`, flip
 `isSupported`, and change nothing else — no JavaScript, no capture logic and
 no UI depends on the mechanism, only on this flag.
 */
public class HardwareShutterModule: Module {
  public func definition() -> ModuleDefinition {
    Name("HardwareShutter")

    Events("onShutterPress")

    Constants([
      "isSupported": false,
      "unsupportedReason": "ios-no-public-key-event-api",
      "platform": "ios",
      "interceptionMode": "none",
    ])

    Function("setArmed") { (_: Bool) in
      // Intentionally a no-op. Arming something that cannot listen would be
      // a lie told to the state machine on the other side of the bridge.
    }

    Function("isArmed") { () -> Bool in
      false
    }
  }
}
