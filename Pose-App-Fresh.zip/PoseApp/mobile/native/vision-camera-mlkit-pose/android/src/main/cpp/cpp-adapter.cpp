#include <jni.h>
#include <fbjni/fbjni.h>

#include "VisionCameraMlkitPoseOnLoad.hpp"

//
// cpp-adapter.cpp — the ONLY hand-written C++ source of this module.
//
// JNI_OnLoad delegates to nitrogen's generated registerAllNatives(), which
// registers the JHybrid Spec JNI natives and autolinks the
// 'VisionCameraMlkitPose' HybridObject constructor (Kotlin impl).
// Keep this file minimal: re-running `npx nitrogen` must never diverge
// from the wiring.
//
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
  return facebook::jni::initialize(vm, []() {
    margelo::nitro::visioncameramlkitpose::registerAllNatives();
  });
}
