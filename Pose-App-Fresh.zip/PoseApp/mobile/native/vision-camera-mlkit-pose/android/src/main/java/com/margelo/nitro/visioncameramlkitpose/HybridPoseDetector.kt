package com.margelo.nitro.visioncameramlkitpose

import androidx.annotation.Keep
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import com.facebook.proguard.annotations.DoNotStrip
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import com.margelo.nitro.camera.CameraOrientation
import com.margelo.nitro.camera.HybridFrameSpec
import com.margelo.nitro.camera.public.NativeFrame
import java.util.concurrent.TimeUnit

/**
 * The REAL Google ML Kit pose detector behind the JS `PoseDetector` handle.
 *
 * THREAD MODEL (hard): [detect] runs SYNCHRONOUSLY inside the VisionCamera
 * frame-output callback on the camera thread. Blocking that thread with
 * `Tasks.await` is deliberate: the app-side runtime
 * (mobile/src/core/ml/poseFrameRuntime.ts) guarantees single-flight, and the
 * frame output is configured with `dropFramesWhileBusy`, so backpressure is
 * handled by DROPPING late frames, never by queueing work here.
 *
 * OWNERSHIP: the caller disposes the [frame] AFTER this method returns
 * (finally). This implementation therefore must NOT close the underlying
 * ImageProxy and must not retain it past return — every read happens inside
 * the call.
 *
 * OUTPUT CONTRACT (mirrors shared/ml/poseFrameTransform.ts exactly):
 *   · landmarks in UPRIGHT image pixels — ML Kit receives the frame's
 *     rotation metadata and answers in upright image space;
 *   · width/height are the UPRIGHT frame dims (swapped at 90°/270°);
 *   · exactly 33 points in BlazePose order 0..32 (ML Kit's landmark-type
 *     ints ARE the BlazePose order) or an EMPTY array when no person is
 *     present / the pose is below the minConfidence gate;
 *   · `mirrored` passes VisionCamera's isMirrored through untouched — joint
 *     identity is never renamed (the JS adapter mirrors x per point);
 *   · `timestampMs` is the frame's CAPTURE instant (the ImageProxy's own
 *     sensor timestamp), expressed in wall-clock ms so it sits in the same
 *     clock domain as JS Date.now() — NEVER a post-inference completion
 *     stamp (the JS scheduler's 350 ms staleness bound must measure the
 *     real frame age: capture → arrival, inference latency included);
 *   · `inferenceMs` is the measured native inference duration.
 *
 * There is NO model download at runtime: pose-detection-accurate bundles its
 * weights inside the artifact and works fully offline.
 */
@DoNotStrip
@Keep
class HybridPoseDetector(options: PoseDetectorOptions) : HybridPoseDetectorSpec() {
  /**
   * The long-lived ML Kit client. Constructed once — model allocation is
   * expensive and per-frame clients would be a perf bug, not a feature.
   */
  private val client: com.google.mlkit.vision.pose.PoseDetector =
    PoseDetection.getClient(
      AccuratePoseDetectorOptions.Builder()
        .setDetectorMode(
          when (options.mode) {
            PoseDetectorMode.STREAM -> AccuratePoseDetectorOptions.STREAM_MODE
            PoseDetectorMode.SINGLE -> AccuratePoseDetectorOptions.SINGLE_IMAGE_MODE
          },
        )
        .build(),
    )

  private val minConfidence: Float = options.minConfidence.toFloat()

  @Volatile
  private var isDisposed = false

  /**
   * Run ML Kit pose inference on ONE camera frame, synchronously.
   *
   * @throws IllegalStateException when the detector was disposed or the frame
   *   is no longer valid — the app runtime counts those as frame errors.
   */
  @androidx.annotation.OptIn(ExperimentalGetImage::class)
  override fun detect(frame: HybridFrameSpec): NativePoseFrame {
    check(!isDisposed) { "PoseDetector has been disposed" }
    check(frame.isValid) { "Frame is no longer valid" }

    val imageProxy: ImageProxy =
      (frame as? NativeFrame)?.image
        ?: throw IllegalStateException(
          "Frame does not expose a camera ImageProxy " +
            "(implementation is ${frame::class.java.name})",
        )
    val mediaImage =
      imageProxy.image
        ?: throw IllegalStateException("Frame has no media image (closed race)")

    val orientation = frame.orientation
    val rotationDegrees = rotationDegreesOf(orientation)
    val inputImage = InputImage.fromMediaImage(mediaImage, rotationDegrees)

    /* CAPTURE TIMESTAMP (before inference, by construction): CameraX hands us
       the sensor capture instant via ImageProxy.timestamp — nanoseconds on the
       System.nanoTime() clock for every realtime timestamp-source device (the
       overwhelmingly common CAMERA_SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
       case). We anchor BOTH clocks NOW (before inference) and translate:

         captureWallMs = nowWallMs − (nowNanos − captureNanos)/1e6

       so timestampMs carries the frame's real age (capture → JS arrival,
       inference included) in the Date.now() domain the scheduler compares
       against. NaN/negative/future skew (non-realtime source devices) degrades
       safely to "captured at inference start" — never to a bogus future or a
       post-inference completion stamp. */
    val captureNanos = imageProxy.imageInfo.timestamp
    val startNanos = System.nanoTime()
    val startWallMs = System.currentTimeMillis().toDouble()
    val ageMs = (startNanos - captureNanos) / NANOS_PER_MS
    val captureWallMs =
      if (ageMs.isFinite() && ageMs >= 0.0 && ageMs <= MAX_PLAUSIBLE_FRAME_AGE_MS) {
        startWallMs - ageMs
      } else {
        startWallMs
      }

    val pose: Pose = Tasks.await(client.process(inputImage), AWAIT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
    val inferenceMs = (System.nanoTime() - startNanos) / NANOS_PER_MS

    /* UPRIGHT dims: for 90°/270° rotations ML Kit answers in the rotated
       (upright) image space, so the upright dims are the buffer dims swapped. */
    val rotated = rotationDegrees == ROTATION_90 || rotationDegrees == ROTATION_270
    val uprightWidth = if (rotated) imageProxy.height else imageProxy.width
    val uprightHeight = if (rotated) imageProxy.width else imageProxy.height

    return NativePoseFrame(
      width = uprightWidth.toDouble(),
      height = uprightHeight.toDouble(),
      timestampMs = captureWallMs,
      orientation = mapOrientation(orientation),
      mirrored = frame.isMirrored,
      landmarks = adaptPose(pose),
      inferenceMs = inferenceMs,
    )
  }

  /**
   * Convert a detected [Pose] to the 33-point contract, in EXACT BlazePose
   * index order 0..32 (ML Kit landmark-type ints are that order).
   *
   * Returns an EMPTY array when no person is present or the mean in-frame
   * likelihood is below the minConfidence gate — the same "no usable pose"
   * semantic the legacy minPoseDetectionConfidence gate produced.
   */
  private fun adaptPose(pose: Pose): Array<NativePosePoint> {
    val points = ArrayList<NativePosePoint>(LANDMARK_COUNT)
    var likelihoodSum = 0.0
    for (type in PoseLandmark.NOSE..PoseLandmark.RIGHT_FOOT_INDEX) {
      val landmark = pose.getPoseLandmark(type)
        ?: /* ML Kit guarantees all 33 for a detected pose; a gap means the
              pose is unusable, so report "no person" rather than guessing. */
        return emptyArray()
      val position = landmark.position3D
      val likelihood = landmark.inFrameLikelihood
      likelihoodSum += likelihood.toDouble()
      points.add(
        NativePosePoint(
          x = position.x.toDouble(),
          y = position.y.toDouble(),
          z = position.z.toDouble(),
          visibility = likelihood.toDouble(),
        ),
      )
    }
    val meanLikelihood = likelihoodSum / LANDMARK_COUNT
    return if (meanLikelihood >= minConfidence) points.toTypedArray() else emptyArray()
  }

  /** Degrees ML Kit needs to interpret the frame as upright (metadata only). */
  private fun rotationDegreesOf(orientation: CameraOrientation): Int =
    when (orientation) {
      CameraOrientation.UP -> ROTATION_0
      CameraOrientation.RIGHT -> ROTATION_90
      CameraOrientation.DOWN -> ROTATION_180
      CameraOrientation.LEFT -> ROTATION_270
    }

  private fun mapOrientation(orientation: CameraOrientation): NativeFrameOrientation =
    when (orientation) {
      CameraOrientation.UP -> NativeFrameOrientation.UP
      CameraOrientation.RIGHT -> NativeFrameOrientation.RIGHT
      CameraOrientation.DOWN -> NativeFrameOrientation.DOWN
      CameraOrientation.LEFT -> NativeFrameOrientation.LEFT
    }

  /**
   * Release the native ML Kit client. Idempotent by contract (called from JS
   * during teardown; safe to call again on shutdown).
   */
  override fun dispose() {
    if (!isDisposed) {
      isDisposed = true
      client.close()
    }
    super.dispose()
  }

  companion object {
    private const val TAG = "HybridPoseDetector"
    /** BlazePose landmark count: ML Kit types run 0 (NOSE) .. 32 (RIGHT_FOOT_INDEX). */
    private const val LANDMARK_COUNT = 33
    /** Synchronous await ceiling — a hung detector must fail, not stall the camera thread. */
    private const val AWAIT_TIMEOUT_MS = 2_000L
    private const val NANOS_PER_MS = 1_000_000.0
    /** Sanity bound for clock-domain translation (10 s — a real camera frame is never older). */
    private const val MAX_PLAUSIBLE_FRAME_AGE_MS = 10_000.0
    private const val ROTATION_0 = 0
    private const val ROTATION_90 = 90
    private const val ROTATION_180 = 180
    private const val ROTATION_270 = 270
  }
}
