package com.margelo.nitro.visioncameramlkitpose

import androidx.annotation.Keep
import com.facebook.proguard.annotations.DoNotStrip

/**
 * Root factory HybridObject of the vision-camera-mlkit-pose plugin,
 * registered by nitrogen's generated autolinking glue under the JS name
 * 'VisionCameraMlkitPose'.
 */
@DoNotStrip
@Keep
class HybridVisionCameraMlkitPose : HybridVisionCameraMlkitPoseSpec() {
  override fun createPoseDetector(options: PoseDetectorOptions): HybridPoseDetectorSpec =
    HybridPoseDetector(options)
}
