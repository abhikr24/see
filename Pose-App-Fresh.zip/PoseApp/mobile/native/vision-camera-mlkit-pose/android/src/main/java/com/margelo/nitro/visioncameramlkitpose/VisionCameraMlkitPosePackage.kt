package com.margelo.nitro.visioncameramlkitpose

import android.util.Log
import com.facebook.react.BaseReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.module.model.ReactModuleInfoProvider
import com.facebook.react.uimanager.ViewManager

/**
 * Zero-module ReactPackage whose ONLY job is deterministic native-library
 * loading: the companion initializer asks Nitrogen to load/register the native
 * pose library before JS requests the HybridObject. If the library is missing
 * or incompatible, the failure is caught so the whole app can still start and
 * the pose feature can report itself unavailable. RN/Expo autolinking discovers
 * this class through the standard Android package scan.
 */
class VisionCameraMlkitPosePackage : BaseReactPackage() {
  override fun getModule(
    name: String,
    reactContext: ReactApplicationContext,
  ): NativeModule? = null

  override fun getReactModuleInfoProvider(): ReactModuleInfoProvider =
    ReactModuleInfoProvider { HashMap() }

  override fun createViewManagers(
    reactContext: ReactApplicationContext,
  ): List<ViewManager<in Nothing, in Nothing>> = emptyList()

  companion object {
    private const val TAG = "VisionCameraMlkitPosePackage"

    init {
      try {
        VisionCameraMlkitPoseOnLoad.initializeNative()
      } catch (error: Throwable) {
        // The pose engine is a feature dependency, not an app-start dependency.
        // A missing/incompatible native library must degrade pose detection to
        // unavailable instead of taking down the whole React Native process.
        Log.e(TAG, "Pose native library could not be loaded; continuing without pose", error)
      }
    }
  }
}
