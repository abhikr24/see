//
//  HybridPoseDetector.swift
//  VisionCameraMlkitPose
//
//  The REAL Google ML Kit pose detector behind the JS `PoseDetector` handle.
//
//  THREAD MODEL (hard): detect() runs SYNCHRONOUSLY inside the VisionCamera
//  frame-output callback. ML Kit's `results(in:)` is the synchronous API, so
//  no queue hops, no futures — the app-side runtime
//  (mobile/src/core/ml/poseFrameRuntime.ts) guarantees single-flight, and
//  the frame output is configured to DROP late frames while busy, so
//  backpressure never builds up here.
//
//  OWNERSHIP: the caller disposes the Frame AFTER this method returns
//  (finally) — this implementation never releases the CMSampleBuffer itself
//  and never retains it past return.
//
//  OUTPUT CONTRACT (mirrors shared/ml/poseFrameTransform.ts exactly):
//    · landmarks arrive in UPRIGHT image pixels — ML Kit receives the
//      frame's orientation metadata and answers in upright image space;
//    · width/height are the UPRIGHT frame dims (swapped at 90°/270°);
//    · EXACTLY 33 points in BlazePose index order 0..32 (built explicitly
//      from ML Kit's landmark types, never from raw array order) or an EMPTY
//      array when no person is present / below the minConfidence gate;
//    · `mirrored` passes VisionCamera's isMirrored through untouched —
//      joint identity is never renamed (the JS adapter mirrors x per point);
//    · `timestampMs` is the frame's CAPTURE instant (the sample buffer's own
//      presentation timestamp), expressed in wall-clock ms so it sits in the
//      same clock domain as JS Date.now() — NEVER a post-inference completion
//      stamp (the JS scheduler's 350 ms staleness bound must measure the real
//      frame age: capture → arrival, inference latency included);
//    · `inferenceMs` is the measured native inference duration.
//
//  The accurate ML Kit model ships inside the GoogleMLKit/PoseDetectionAccurate
//  pod: fully offline, no runtime model download.
//

import AVFoundation
import CoreMedia
import CoreVideo
import Foundation
import NitroModules
import VisionCamera

import MLKitCommon
import MLKitPoseDetectionAccurate
import MLKitPoseDetectionCommon
import MLKitVision

final class HybridPoseDetector: HybridPoseDetectorSpec {
  /// Long-lived ML Kit client (nil after dispose()).
  private var detector: MLKitPoseDetectionCommon.PoseDetector?
  private let minConfidence: Double

  init(options: PoseDetectorOptions) {
    self.minConfidence = options.minConfidence
    let mlKitOptions = AccuratePoseDetectorOptions()
    mlKitOptions.detectorMode = options.mode == .stream ? .stream : .singleImage
    self.detector = MLKitPoseDetectionCommon.PoseDetector.poseDetector(options: mlKitOptions)
    super.init()
  }

  /**
   * Runs ML Kit pose inference on ONE camera frame, synchronously.
   *
   * - Throws: `RuntimeError` when the detector was disposed or the frame
   *   carries no valid sample buffer — the app runtime counts those as
   *   frame errors, matching the Android behaviour.
   */
  func detect(frame: (any HybridFrameSpec)) throws -> NativePoseFrame {
    guard let detector else {
      throw RuntimeError.error(withMessage: "PoseDetector has been disposed")
    }
    guard frame.isValid else {
      throw RuntimeError.error(withMessage: "Frame is no longer valid")
    }
    // Swift -> C++ -> Swift round-trip returns VisionCamera's ORIGINAL
    // HybridFrame instance, so the public NativeFrame cast is exact, not a guess.
    guard let nativeFrame = frame as? NativeFrame,
          let sampleBuffer = nativeFrame.sampleBuffer,
          CMSampleBufferIsValid(sampleBuffer)
    else {
      throw RuntimeError.error(withMessage: "Frame exposes no valid CMSampleBuffer")
    }
    guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {
      throw RuntimeError.error(withMessage: "Frame sample buffer has no image buffer")
    }

    let orientation = frame.orientation
    let image = VisionImage(buffer: sampleBuffer)
    image.orientation = Self.mlKitOrientation(of: orientation)

    /* CAPTURE TIMESTAMP (before inference, by construction): the sample
       buffer's presentation timestamp lives on the HOST clock (mach
       absolute time — the same clock CMClockGetHostTimeClock reads). Anchor
       both clocks NOW (before inference) and translate:

         captureWallMs = nowWallMs − hostAge×1000

       so timestampMs carries the frame's real age (capture → JS arrival,
       inference included) in the Date.now() domain the JS scheduler
       compares against. An invalid PTS or clock skew degrades safely to
       "captured at inference start" — never to a bogus future or a
       post-inference completion stamp. */
    let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
    let start = Date()
    let hostNow = CMClockGetTime(CMClockGetHostTimeClock())
    let hostAgeSeconds = pts.isValid && hostNow.isValid
      ? CMTimeGetSeconds(CMTimeSubtract(hostNow, pts))
      : .nan
    let captureWallMs =
      hostAgeSeconds.isFinite && hostAgeSeconds >= 0 && hostAgeSeconds <= 10.0
      ? start.timeIntervalSince1970 * 1000.0 - hostAgeSeconds * 1000.0
      : start.timeIntervalSince1970 * 1000.0

    let inferenceStart = Date()
    let poses = try detector.results(in: image)
    let inferenceMs = Date().timeIntervalSince(inferenceStart) * 1000.0

    /* UPRIGHT dims: for 90°/270° orientations ML Kit answers in the rotated
       (upright) image space, so the upright dims are the buffer dims swapped. */
    let bufferWidth = CVPixelBufferGetWidth(pixelBuffer)
    let bufferHeight = CVPixelBufferGetHeight(pixelBuffer)
    let rotated = orientation == .left || orientation == .right
    let uprightWidth = rotated ? bufferHeight : bufferWidth
    let uprightHeight = rotated ? bufferWidth : bufferHeight

    return NativePoseFrame(
      width: Double(uprightWidth),
      height: Double(uprightHeight),
      timestampMs: captureWallMs,
      orientation: Self.mapOrientation(orientation),
      mirrored: frame.isMirrored,
      landmarks: Self.adapt(poses: poses, minConfidence: minConfidence),
      inferenceMs: inferenceMs
    )
  }

  /**
   * Convert detected poses to the 33-point contract in EXACT BlazePose
   * index order. The order is built landmark-type-by-landmark-type (never
   * trusting ML Kit's array order), matching the Android implementation
   * (ML Kit landmark types 0..32 ARE the BlazePose order on both platforms).
   *
   * Returns an EMPTY array when no person is present or the mean in-frame
   * likelihood is below the minConfidence gate.
   */
  private static func adapt(poses: [Pose], minConfidence: Double) -> [NativePosePoint] {
    guard let pose = poses.first else { return [] }
    var points: [NativePosePoint] = []
    points.reserveCapacity(Self.blazePoseOrder.count)
    var likelihoodSum = 0.0
    for type in Self.blazePoseOrder {
      /* ML Kit's iOS SDK returns a NON-optional landmark for every type in a
         detected pose (not-present joints come back with inFrameLikelihood 0,
         which the JS adapter keeps representable — it never drops points). */
      let landmark = pose.landmark(ofType: type)
      let likelihood = Double(landmark.inFrameLikelihood)
      likelihoodSum += likelihood
      points.append(
        NativePosePoint(
          x: Double(landmark.position.x),
          y: Double(landmark.position.y),
          z: Double(landmark.position.z),
          visibility: likelihood
        )
      )
    }
    let meanLikelihood = likelihoodSum / Double(Self.blazePoseOrder.count)
    return meanLikelihood >= minConfidence ? points : []
  }

  /**
   * VisionCamera's relative orientation -> the semantically identical
   * UIImage.Orientation for ML Kit: `.right` = "rotate the data 90°
   * clockwise to appear upright" = Android's rotationDegrees 90 (the SAME
   * metadata mapping shared/ml/poseFrameTransform.nativeOrientationDegrees
   * documents for the Android side).
   */
  private static func mlKitOrientation(of orientation: CameraOrientation) -> UIImage.Orientation {
    switch orientation {
    case .up: return .up
    case .right: return .right
    case .down: return .down
    case .left: return .left
    default: return .up
    }
  }

  private static func mapOrientation(_ orientation: CameraOrientation) -> NativeFrameOrientation {
    switch orientation {
    case .up: return .up
    case .right: return .right
    case .down: return .down
    case .left: return .left
    default: return .up
    }
  }

  /**
   * Release the native ML Kit client (ARC) and make further detect() calls
   * throw. Idempotent by contract (called from JS during teardown).
   *
   * NOTE: `dispose` is a Nitro `HybridObject` PROTOCOL requirement whose
   * default implementation lives in a protocol extension — nothing in the
   * base class hierarchy declares it, so `override` here neither compiles
   * nor exists; declaring the method satisfies conformance directly.
   * The detector's release is driven by `detector = nil` itself. */
  func dispose() {
    detector = nil
  }

  /**
   * The 33 ML Kit pose landmark types in EXACT BlazePose index order 0..32.
   * ML Kit uses the identical topology on iOS and Android (only the constant
   * NAMES differ, e.g. `.leftToe` == Android LEFT_FOOT_INDEX).
   */
  private static let blazePoseOrder: [PoseLandmarkType] = [
    .nose, // 0
    .leftEyeInner, .leftEye, .leftEyeOuter, // 1, 2, 3
    .rightEyeInner, .rightEye, .rightEyeOuter, // 4, 5, 6
    .leftEar, .rightEar, // 7, 8
    .mouthLeft, .mouthRight, // 9, 10
    .leftShoulder, .rightShoulder, // 11, 12
    .leftElbow, .rightElbow, // 13, 14
    .leftWrist, .rightWrist, // 15, 16
    .leftPinkyFinger, .rightPinkyFinger, // 17, 18
    .leftIndexFinger, .rightIndexFinger, // 19, 20
    .leftThumb, .rightThumb, // 21, 22
    .leftHip, .rightHip, // 23, 24
    .leftKnee, .rightKnee, // 25, 26
    .leftAnkle, .rightAnkle, // 27, 28
    .leftHeel, .rightHeel, // 29, 30
    .leftToe, .rightToe, // 31, 32
  ]
}
