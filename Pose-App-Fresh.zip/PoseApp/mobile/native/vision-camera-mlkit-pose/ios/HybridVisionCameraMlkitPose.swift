//
//  HybridVisionCameraMlkitPose.swift
//  VisionCameraMlkitPose
//
//  Root factory HybridObject of the vision-camera-mlkit-pose plugin,
//  instantiated by nitrogen's generated autolinking glue
//  (VisionCameraMlkitPoseAutolinking.swift) under the JS name
//  'VisionCameraMlkitPose'. There is NO JavaScript fallback: builds without
//  this pod never reach this class.
//

import Foundation
import NitroModules
import VisionCamera

final class HybridVisionCameraMlkitPose: HybridVisionCameraMlkitPoseSpec {
  override init() {
    super.init()
  }

  /**
   * Allocates a REAL native ML Kit pose detector (accurate, bundled model).
   * Performs the native client construction up-front (model load is
   * expensive and must happen once per session, never per frame); the
   * caller holds the handle and calls `dispose()` on teardown.
   */
  func createPoseDetector(options: PoseDetectorOptions) throws -> (any HybridPoseDetectorSpec) {
    return HybridPoseDetector(options: options)
  }
}
