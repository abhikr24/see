// https://github.com/react-native-community/cli/blob/main/docs/dependencies.md
// Empty platform params: the native sides are picked up by the standard
// autolinkers (Gradle include via android/build.gradle, CocoaPods via
// VisionCameraMlkitPose.podspec) and the Nitro autolinking glue in
// nitrogen/generated. Nothing custom is required at prebuild time.

module.exports = {
  dependency: {
    platforms: {
      /**
       * @type {import('@react-native-community/cli-types').IOSDependencyParams}
       */
      ios: {},
      /**
       * @type {import('@react-native-community/cli-types').AndroidDependencyParams}
       */
      android: {},
    },
  },
};
