/**
 * vision-camera-mlkit-pose — the ONLY JavaScript entry point of the local
 * Nitro frame-processor plugin (Google ML Kit Pose Detection, accurate,
 * bundled model) over VisionCamera v5 native frames.
 *
 * · There is NO JavaScript fallback, NO synthetic landmark generator and NO
 *   still-photo path here by design: if the native implementation is not
 *   linked into the running binary (Expo Go, web, preview tooling),
 *   `createPoseDetector` THROWS and the app's guarded loader
 *   (mobile/src/core/ml/nativePosePlugin.ts) reports the feature as
 *   'unavailable'.
 * · `createPoseDetector` performs a real native ML Kit client allocation;
 *   hold the handle for the session and call `dispose()` on teardown.
 */
import { NitroModules } from 'react-native-nitro-modules';
import type { VisionCameraMlkitPose as VisionCameraMlkitPoseSpec } from './specs/VisionCameraMlkitPose.nitro';
import type { Frame } from 'react-native-vision-camera/lib/specs/instances/Frame.nitro';
import type {
  NativePoseFrame,
  PoseDetectorOptions,
} from './specs/PoseTypes';

export type { NativePoseFrame, NativePosePoint, PoseDetectorOptions, PoseDetectorMode } from './specs/PoseTypes';

/** The detector handle consumed by the app's runtime. */
export interface PoseDetectorHandle {
  /**
   * Synchronous, frame-thread inference on ONE camera frame. Must be called
   * inside the frame-output worklet; the caller disposes the frame in a
   * `finally` afterwards.
   */
  detect(frame: Frame): NativePoseFrame;
  /** Release the native detector (ML Kit client close()). Idempotent. */
  dispose(): void;
}

let cachedRoot: VisionCameraMlkitPoseSpec | null | undefined;

function loadRoot(): VisionCameraMlkitPoseSpec | null {
  if (cachedRoot !== undefined) return cachedRoot;
  try {
    cachedRoot =
      NitroModules.createHybridObject<VisionCameraMlkitPoseSpec>(
        'VisionCameraMlkitPose',
      );
  } catch {
    cachedRoot = null;
  }
  return cachedRoot;
}

/** True when the native implementation is linked into this binary. */
export function isNativePoseAvailable(): boolean {
  return loadRoot() !== null;
}

/**
 * Allocate a REAL native ML Kit pose detector. THROWS when this binary does
 * not contain the native implementation — there is deliberately no JS
 * stand-in to degrade to.
 */
export function createPoseDetector(
  options: PoseDetectorOptions,
): PoseDetectorHandle {
  const root = loadRoot();
  if (root === null) {
    throw new Error(
      'vision-camera-mlkit-pose native module is not linked into this build ' +
        '(requires a prebuilt dev client — not Expo Go / web).',
    );
  }
  const detector = root.createPoseDetector(options);
  return {
    detect: (frame: Frame): NativePoseFrame => detector.detect(frame),
    dispose: (): void => detector.dispose(),
  };
}
