import type { HybridObject } from 'react-native-nitro-modules';
import type { Frame } from 'react-native-vision-camera/lib/specs/instances/Frame.nitro';
import type { NativePoseFrame } from './PoseTypes';

/**
 * A live Google ML Kit pose detector bound to the VisionCamera v5 frame
 * pipeline.
 *
 * Thread model (hard): `detect()` is invoked SYNCHRONOUSLY on the frame
 * thread, inside the frame-output worklet; the caller disposes the Frame in
 * a `finally` afterwards. `dispose()` (inherited from HybridObject) releases
 * the native ML Kit client and is idempotent; calls after disposal throw on
 * the native side, which the app's runtime treats as a counted frame error.
 *
 * @see {@linkcode VisionCameraMlkitPose.createPoseDetector}
 */
export interface PoseDetector extends HybridObject<{ ios: 'swift'; android: 'kotlin' }> {
  /**
   * Runs ML Kit pose inference on ONE camera frame.
   *
   * Returns the NativePoseFrame contract: landmarks in upright image pixels,
   * upright dims (native swaps for 90°/270° rotations), per-landmark in-frame
   * likelihood, frame mirror/orientation metadata, the frame's capture
   * instant in wall-clock ms (capture-anchored, NOT inference completion),
   * and the measured native inference time. `landmarks: []` means "no
   * person in frame" (or below the detector's minConfidence gate) — it is
   * NEVER a synthetic placeholder.
   */
  detect(frame: Frame): NativePoseFrame;
}
