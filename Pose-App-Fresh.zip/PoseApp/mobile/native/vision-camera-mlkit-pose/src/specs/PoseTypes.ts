/**
 * vision-camera-mlkit-pose — plain data contracts that cross the Nitro
 * boundary. These MIRROR the app's canonical contract
 * (shared/ml/poseFrameTransform.ts) field-for-field ON PURPOSE: the app
 * adapts this payload into its PoseLandmark[] without ever importing this
 * package's types, so the plugin can evolve without rippling into the app.
 *
 * Nitro rules respected here: plain structs only (no classes, no unions
 * outside string enums, no functions), because every field is marshalled
 * through generated C++.
 */

/**
 * Frame presentation orientation relative to the desired target orientation —
 * the SAME four values VisionCamera's `CameraOrientation` uses
 * ('up' | 'right' | 'down' | 'left').
 */
export type NativeFrameOrientation = 'up' | 'right' | 'down' | 'left';

/** One raw landmark as produced by ML Kit, in UPRIGHT image pixels. */
export interface NativePosePoint {
  /** Upright image-space x in pixels (ML Kit already applied rotation). */
  x: number;
  /** Upright image-space y in pixels. */
  y: number;
  /** ML Kit z depth (same semantics as MediaPipe: negative = closer to camera). */
  z: number;
  /** ML Kit in-frame likelihood 0..1 (maps 1:1 to PoseLandmark.visibility). */
  visibility: number;
}

/**
 * What ONE processed camera frame returns to JS.
 *
 * Coordinate contract (hard):
 *   · landmarks are in UPRIGHT image space, x right / y down;
 *   · width/height are the UPRIGHT frame dims (native swaps for 90°/270°);
 *   · mirrored = the PREVIEW is mirrored but the pixel buffer is not
 *     (selfie case) — the JS adapter flips x after normalizing; joint
 *     identity (ML Kit's person-relative labels) is never renamed;
 *   · timestampMs is the frame's CAPTURE instant (Android: ImageProxy
 *     sensor timestamp; iOS: CMSampleBuffer presentation timestamp),
 *     translated into the wall-clock domain of JS Date.now() at the moment
 *     inference starts — so the app's 350 ms staleness policy measures real
 *     frame age (capture → JS arrival, inference latency included), never a
 *     post-inference completion stamp.
 */
export interface NativePoseFrame {
  /** UPRIGHT frame width in pixels. */
  width: number;
  /** UPRIGHT frame height in pixels. */
  height: number;
  /** Wall-clock ms of the frame's CAPTURE instant (see contract above). */
  timestampMs: number;
  /** Relative frame orientation as reported by VisionCamera. */
  orientation: NativeFrameOrientation;
  /** True when the preview is mirrored but the buffer is not (front camera). */
  mirrored: boolean;
  /** Empty (= no person) or EXACTLY 33 points, BlazePose index order 0..32. */
  landmarks: NativePosePoint[];
  /** Measured native-side inference duration for THIS frame (ms). */
  inferenceMs?: number;
}

/**
 * 'stream' (tracking-optimized VIDEO semantics) or 'single' (still image).
 * The app's live pipeline always uses 'stream'.
 */
export type PoseDetectorMode = 'stream' | 'single';

export interface PoseDetectorOptions {
  mode: PoseDetectorMode;
  /**
   * Minimum mean in-frame likelihood below which a detection is reported as
   * "no person" — the ML Kit equivalent of the legacy MediaPipe
   * minPoseDetectionConfidence gate (0.5). Per-landmark likelihoods are
   * always passed through untouched; this only gates detection presence.
   */
  minConfidence: number;
}
