import type { HybridObject } from 'react-native-nitro-modules';
import type { PoseDetector } from './PoseDetector.nitro';
import type { PoseDetectorOptions } from './PoseTypes';

/**
 * Root factory HybridObject of the vision-camera-mlkit-pose plugin.
 *
 * Instantiated via `NitroModules.createHybridObject<VisionCameraMlkitPose>('VisionCameraMlkitPose')`
 * and autolinked by nitrogen's generated registration (see nitrogen/generated).
 */
export interface VisionCameraMlkitPose
  extends HybridObject<{ ios: 'swift'; android: 'kotlin' }> {
  /**
   * Allocates a REAL native ML Kit pose detector (accurate, bundled model).
   * This performs the native client construction, so callers must hold the
   * returned handle for the session and dispose() it on teardown.
   */
  createPoseDetector(options: PoseDetectorOptions): PoseDetector;
}
