const { withAppBuildGradle, withGradleProperties } = require('expo/config-plugins');

const ARCH = 'arm64-v8a';
const PROP = 'reactNativeArchitectures';
const MARKER = 'SMART-CAMERA: arm64 phone APK';
const PACKAGING_PROP = 'expo.useLegacyPackaging';
const PARALLEL_PROP = 'org.gradle.parallel';
const WORKERS_PROP = 'org.gradle.workers.max';

/**
 * The default React Native architecture list is four ABIs:
 * armeabi-v7a, arm64-v8a, x86, x86_64. That is useful for emulators and
 * universal binaries, but it makes a direct-install APK unnecessarily large.
 * This project targets a physical modern Android phone for the installable
 * release APK, so build only arm64-v8a.
 *
 * The change is made as an Expo config plugin so EAS/CNG reapplies it even
 * though mobile/android is intentionally regenerated on the build server.
 */
function withAndroidPhoneApk(config) {
  config = withGradleProperties(config, (mod) => {
    const keysToReplace = new Set([PROP, PACKAGING_PROP, PARALLEL_PROP, WORKERS_PROP]);
    const next = (mod.modResults || []).filter((entry) => !keysToReplace.has(entry.key));
    next.push({ type: 'property', key: PROP, value: ARCH });
    next.push({ type: 'property', key: PACKAGING_PROP, value: 'true' });
    // V6: serialize Gradle execution. The V5 EAS build hit concurrent
    // Android Prefab/AAR transforms that threw a JDK HashMap TreeNode
    // ClassCastException across four native modules at the same time.
    next.push({ type: 'property', key: PARALLEL_PROP, value: 'false' });
    next.push({ type: 'property', key: WORKERS_PROP, value: '1' });
    mod.modResults = next;
    return mod;
  });

  return withAppBuildGradle(config, (mod) => {
    if (mod.modResults.language !== 'groovy') {
      throw new Error('[withAndroidPhoneApk] Expected Groovy app/build.gradle.');
    }

    if (!mod.modResults.contents.includes(MARKER)) {
      const markerBlock = `\n// ${MARKER}\n// Keep the installable phone APK arm64-only. This is intentionally\n// applied at both Gradle-property and app-module level so generated\n// CNG projects cannot silently restore the four-ABI default. Native .so files
// are also compressed for the direct APK so the downloaded artifact stays smaller.\n`;
      const androidBlock = `android {\n`;
      if (!mod.modResults.contents.includes(androidBlock)) {
        throw new Error('[withAndroidPhoneApk] Could not find android { block.');
      }
      mod.modResults.contents = mod.modResults.contents.replace(
        androidBlock,
        androidBlock + markerBlock,
        1,
      );
    }

    // Ensure only the requested ABI is packaged by this app module.
    if (!mod.modResults.contents.includes('abiFilters')) {
      const defaultConfigAnchor = 'defaultConfig {\n';
      if (!mod.modResults.contents.includes(defaultConfigAnchor)) {
        throw new Error('[withAndroidPhoneApk] Could not find defaultConfig { block.');
      }
      const abiBlock = `    ndk {\n        abiFilters "${ARCH}"\n    }\n`;
      mod.modResults.contents = mod.modResults.contents.replace(
        defaultConfigAnchor,
        defaultConfigAnchor + abiBlock,
        1,
      );
    }

    return mod;
  });
}

module.exports = withAndroidPhoneApk;
