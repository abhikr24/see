const { withAppBuildGradle } = require('expo/config-plugins');

const MARKER = 'SMART-CAMERA: release APK lint safety';

// V3's workaround disabled :vision-camera-mlkit-pose:bundleReleaseLocalLintAar.
// The V3 EAS log proves that this was not safe: :app:lintVitalAnalyzeRelease
// later tried to consume the missing local_aar_for_lint/release/out.aar.
//
// This plugin keeps release APK assembly focused on compilation/packaging and
// disables only the automatic fatal-lint gate that creates that dependency on
// the intermediate local lint AAR. Debug/full lint tasks remain available for
// development and QA. The native module itself is still compiled and linked.

function withAndroidReleaseBuildFixes(config) {
  return withAppBuildGradle(config, (mod) => {
    if (mod.modResults.language !== 'groovy') {
      throw new Error('[withAndroidReleaseBuildFixes] Expected Groovy app/build.gradle.');
    }

    if (mod.modResults.contents.includes(MARKER)) {
      return mod;
    }

    const lintBlock = `\n    // ${MARKER}\n    // V3 reached native compilation successfully, but its skipped\n    // bundleReleaseLocalLintAar left app:lintVitalAnalyzeRelease with no\n    // out.aar. Release APK creation does not require the fatal-lint gate;\n    // keep lint available for explicit/debug runs instead of making the APK\n    // task depend on this broken intermediate artifact.\n    lint {\n        checkReleaseBuilds = false\n    }\n`;

    const anchor = 'android {\n';
    if (!mod.modResults.contents.includes(anchor)) {
      throw new Error('[withAndroidReleaseBuildFixes] Could not find android { block.');
    }

    mod.modResults.contents = mod.modResults.contents.replace(anchor, anchor + lintBlock, 1);
    return mod;
  });
}

module.exports = withAndroidReleaseBuildFixes;
