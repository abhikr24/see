/**
 * mobile/plugins/withHardwareShutter.js — Expo config plugin.
 *
 * WHAT IT DOES
 * Injects a `dispatchKeyEvent` override into `MainActivity.kt` that offers
 * every key event to `expo.modules.hardwareshutter.HardwareShutterBridge`
 * first. The bridge answers `false` unless the camera screen has explicitly
 * armed it, so in every other state Android handles the volume keys exactly
 * as it always did.
 *
 * WHY A PLUGIN AND NOT ONLY A HAND EDIT
 * The `android/` project is checked in AND regenerable (`expo prebuild`).
 * A hand edit alone would silently disappear on the next regeneration and
 * the feature would fail on a device with no compile error to explain it.
 * The edit is therefore applied by this plugin; the checked-in
 * `MainActivity.kt` already carries the identical block so the current
 * project builds without a prebuild.
 *
 * IDEMPOTENT: it looks for the marker and does nothing if it is present.
 * REVERSIBLE: remove the plugin from app.json, delete the marked block from
 * MainActivity.kt, delete modules/hardware-shutter — nothing else in the app
 * references the capability except one service that degrades to
 * "unavailable".
 *
 * iOS: no mod. The iOS half of the module deliberately reports
 * `isSupported = false` (see modules/hardware-shutter/README.md).
 */
const { withMainActivity } = require('expo/config-plugins');

const MARKER = 'hardware-shutter';

const IMPORT_LINE = 'import expo.modules.hardwareshutter.HardwareShutterBridge';
const KEYEVENT_IMPORT = 'import android.view.KeyEvent';

const OVERRIDE = `
  // @generated begin ${MARKER} — volume-button shutter (see mobile/plugins/withHardwareShutter.js)
  /**
   * Offers every key event to the hardware-shutter bridge BEFORE Android
   * gets it. The bridge consumes VOLUME_UP / VOLUME_DOWN only while the
   * camera screen has armed it; at every other moment it returns false and
   * the volume keys behave normally (volume changes, HUD shows, mute works).
   */
  override fun dispatchKeyEvent(event: KeyEvent): Boolean {
    if (HardwareShutterBridge.dispatchKeyEvent(event)) {
      return true
    }
    return super.dispatchKeyEvent(event)
  }
  // @generated end ${MARKER}
`;

function addImport(contents, importLine) {
  if (contents.includes(importLine)) return contents;
  const lines = contents.split('\n');
  const lastImport = lines.reduce(
    (found, line, index) => (line.startsWith('import ') ? index : found),
    -1,
  );
  if (lastImport === -1) return `${importLine}\n${contents}`;
  lines.splice(lastImport + 1, 0, importLine);
  return lines.join('\n');
}

function withHardwareShutterMainActivity(config) {
  return withMainActivity(config, (mod) => {
    if (mod.modResults.language !== 'kt') {
      throw new Error(
        '[withHardwareShutter] expected a Kotlin MainActivity; found ' +
          mod.modResults.language,
      );
    }
    if (mod.modResults.contents.includes(MARKER)) {
      return mod;
    }

    let contents = mod.modResults.contents;
    contents = addImport(contents, KEYEVENT_IMPORT);
    contents = addImport(contents, IMPORT_LINE);

    /* Append inside the class body: the LAST closing brace of the file is
       the class brace for a generated MainActivity.kt. */
    const lastBrace = contents.lastIndexOf('}');
    if (lastBrace === -1) {
      throw new Error('[withHardwareShutter] could not locate the MainActivity class body.');
    }
    contents = `${contents.slice(0, lastBrace)}${OVERRIDE}${contents.slice(lastBrace)}`;

    mod.modResults.contents = contents;
    return mod;
  });
}

module.exports = withHardwareShutterMainActivity;
