/**
 * shared/camera/cameraControls.ts — Camera Controls & Brightness.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero colors.
 *
 * WHY THIS MODULE EXISTS
 *
 * The camera screen owned three DIFFERENT kinds of "make it brighter":
 *
 *   · flash        a burst of light AT capture time (off / auto / on);
 *   · torch        continuous light while framing — supported by the camera
 *                  foundation (`CameraView.enableTorch`) but never exposed,
 *                  so the only way to light a dark room was to fire the flash
 *                  blind and hope;
 *   · brightness   how light or dark the PHOTOGRAPH itself comes out.
 *
 * The third one was the honest problem. The locked camera foundation STOCK
 * (expo-camera ~57 as published) exposes `flash`, `enableTorch`, `zoom`,
 * `autofocus`, `mirror`, `pictureSize`, `ratio` … and NO exposure /
 * exposure-compensation / EV-bias API on any platform — so at the time this
 * module was written there was no way to bias the sensor's exposure the way
 * the stock camera app does, and a slider that pretended to would be a lie.
 *
 * D1 UPDATE: the foundation now carries a minimal native exposure
 * bridge applied with patch-package (`mobile/patches/expo-camera+57.0.5.patch`
 * — see `shared/camera/cameraExposure.ts`). Where that bridge reports the
 * bound camera as exposure-capable, the detent described here drives REAL
 * sensor EV bias and this photo-processing path steps aside entirely
 * (`captureBrightnessLevel` enforces exclusivity). Where the bridge is
 * absent — unpatched build, simulator, unsupported camera module — the
 * mechanism below remains the honest fallback, under its own name.
 *
 * So brightness here means exactly what it says and nothing more:
 *
 *   THE CAPTURED PHOTO IS BRIGHTENED OR DARKENED, FOR REAL, BY A COLOR
 *   MATRIX APPLIED TO THE IMAGE AFTER THE SHUTTER — and the viewfinder shows
 *   an HONEST PREVIEW of that result while you choose the value.
 *
 * Consequences encoded here rather than in a component:
 *   · `brightnessGain` / `brightnessColorMatrix` are the SINGLE definition of
 *     the adjustment. The pixel pipeline and the live preview approximation
 *     both descend from it, so the preview can never drift from the result.
 *   · `brightnessPreviewScrim` is explicitly labelled an APPROXIMATION: a
 *     translucent lighten/darken wash over the viewfinder is the closest an
 *     app can get without owning the frame buffer, and it is derived from the
 *     same gain so it moves with the real adjustment.
 *   · `BRIGHTNESS_MECHANISM` states in data, once, what the control actually
 *     does, so no screen and no report can claim "exposure compensation".
 */

/* ────────────────────────────── brightness ────────────────────────────── */

/**
 * Seven detents, `-3 … 0 … +3`. Continuous sliders invite hunting for a value
 * the user cannot name; detents let them say "two brighter than normal", undo
 * it, and land back exactly on default.
 */
export const BRIGHTNESS_MIN = -3;
export const BRIGHTNESS_MAX = 3;
export const BRIGHTNESS_DEFAULT = 0;

export type BrightnessLevel = number;

/**
 * What the control actually manipulates. Read by the UI to word its own
 * explanation and by the docs/tests so the claim stays auditable.
 *
 *  `photo-processing` — the pixels of the saved photo change; the sensor's
 *                       exposure does not. The live viewfinder shows an
 *                       approximation of the outcome.
 */
export const BRIGHTNESS_MECHANISM = "photo-processing" as const;

export function clampBrightness(level: unknown): BrightnessLevel {
  if (typeof level !== "number" || !Number.isFinite(level)) {
    return BRIGHTNESS_DEFAULT;
  }
  return Math.max(BRIGHTNESS_MIN, Math.min(BRIGHTNESS_MAX, Math.round(level)));
}

export function isBrightnessDefault(level: unknown): boolean {
  return clampBrightness(level) === BRIGHTNESS_DEFAULT;
}

/**
 * Multiplicative gain applied to every channel. 18 % per detent: large enough
 * that one tap is visible on a phone screen, small enough that ±3 does not
 * destroy highlights or crush shadows beyond recovery.
 */
export function brightnessGain(level: unknown): number {
  return 1 + clampBrightness(level) * 0.18;
}

/**
 * The 4×5 color matrix consumed by the real image pipeline (Skia
 * `ColorFilter.MakeMatrix`). Row-major RGBA; the last column is the additive
 * lift, kept at zero so pure black stays black (a lift would grey the whole
 * frame and read as "washed out", not "brighter").
 *
 * At the default detent this is EXACTLY the identity matrix, which is what
 * lets the pipeline skip all work — and lets a test prove that "default"
 * means "your photo is untouched".
 */
export function brightnessColorMatrix(level: unknown): readonly number[] {
  const g = brightnessGain(level);
  return [
    g, 0, 0, 0, 0,
    0, g, 0, 0, 0,
    0, 0, g, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

/** True when the pipeline may hand the original file straight through. */
export function brightnessIsIdentity(level: unknown): boolean {
  return isBrightnessDefault(level);
}

/**
 * The live-viewfinder APPROXIMATION, as intent rather than pixels: which way
 * to wash the frame and how hard. No colors here — the renderer owns those.
 *
 * Capped at 0.30 opacity: beyond that the wash stops previewing the photo and
 * starts hiding the subject, which would break pose framing.
 */
export interface BrightnessPreviewScrim {
  readonly mode: "none" | "lighten" | "darken";
  /** 0..0.30 */
  readonly opacity: number;
}

export function brightnessPreviewScrim(level: unknown): BrightnessPreviewScrim {
  const step = clampBrightness(level);
  if (step === 0) return { mode: "none", opacity: 0 };
  const magnitude = Math.abs(step) / BRIGHTNESS_MAX; // 0.33 / 0.66 / 1
  const opacity = Math.round(magnitude * 0.3 * 1000) / 1000;
  return { mode: step > 0 ? "lighten" : "darken", opacity };
}

/** "0" is never shown as a number — the default must read as "normal". */
export function brightnessBadge(level: unknown): string | null {
  const step = clampBrightness(level);
  if (step === 0) return null;
  return step > 0 ? `+${step}` : `${step}`;
}

/* ─────────────────────────────── lighting ─────────────────────────────── */

export type CameraFacingValue = "front" | "back";
export type FlashModeValue = "off" | "auto" | "on";

/**
 * Torch is a HARDWARE LAMP. It exists on the rear module; the front camera on
 * effectively every Android/iOS phone has none, and `enableTorch` there is a
 * silent no-op. Offering a control that silently does nothing is worse than
 * offering a control that says why it is unavailable.
 */
export function torchSupported(facing: CameraFacingValue): boolean {
  return facing === "back";
}

export type TorchBlockedReason = "none" | "front-camera" | "session-not-live";

export interface LightingState {
  readonly facing: CameraFacingValue;
  readonly flash: FlashModeValue;
  readonly torchRequested: boolean;
  /** Viewfinder mounted, focused and foregrounded. */
  readonly sessionLive: boolean;
}

export interface LightingResolution {
  /** What the camera foundation is actually told. */
  readonly torchOn: boolean;
  readonly flash: FlashModeValue;
  readonly torchEnabled: boolean;
  readonly torchBlockedReason: TorchBlockedReason;
  /**
   * The torch is already lighting the scene continuously, so a capture-time
   * flash burst adds nothing but a startled subject. The UI dims the flash
   * control instead of silently ignoring it.
   */
  readonly flashSupersededByTorch: boolean;
}

export function resolveLighting(state: LightingState): LightingResolution {
  const supported = torchSupported(state.facing);
  const torchBlockedReason: TorchBlockedReason = !supported
    ? "front-camera"
    : !state.sessionLive
      ? "session-not-live"
      : "none";
  const torchOn = state.torchRequested && torchBlockedReason === "none";
  return {
    torchOn,
    flash: state.flash,
    torchEnabled: torchBlockedReason === "none",
    torchBlockedReason,
    flashSupersededByTorch: torchOn,
  };
}

/** The documented flash cycle, in one place, so UI and store cannot diverge. */
export const FLASH_CYCLE: readonly FlashModeValue[] = ["off", "auto", "on"];

export function nextFlashMode(current: FlashModeValue): FlashModeValue {
  const index = FLASH_CYCLE.indexOf(current);
  return FLASH_CYCLE[(index + 1) % FLASH_CYCLE.length] ?? "off";
}
