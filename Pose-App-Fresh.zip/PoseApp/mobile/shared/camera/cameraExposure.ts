/**
 * shared/camera/cameraExposure.ts — REAL camera exposure (EV compensation).
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero colors.
 *
 * WHY THIS MODULE EXISTS (D1)
 *
 * The camera screen owned ONE brightness slider and two honest claims:
 *
 *   · at the SENSOR, nothing happened — the locked camera foundation
 *     (expo-camera ~57) ships `flash`, `enableTorch`, `zoom`, `autofocus`,
 *     `mirror`, `pictureSize`, `ratio` … and no exposure / EV-bias call on
 *     Android or iOS (verified against the installed package's Kotlin, Swift
 *     AND type surface, not from memory);
 *   · at the PHOTOGRAPH, a Skia colour matrix made the saved JPEG lighter or
 *     darker after the shutter, while a wash approximated the result on the
 *     viewfinder (`shared/camera/cameraControls.ts`, mechanism
 *     "photo-processing").
 *
 * That second claim was honest but it is NOT exposure: the sensor's metering
 * never changed, so the live viewfinder never really answered the slider.
 *
 * D1 adds the missing seam WITHOUT changing the camera engine: a minimal,
 * upstream-shaped native exposure-compensation bridge applied to
 * expo-camera@57.0.5 with patch-package (mobile/patches/). CameraX's
 * `ExposureState` / `CameraControl.setExposureCompensationIndex` on Android
 * and AVFoundation's `setExposureTargetBias` on iOS both mean exactly
 * "bias the automatic exposure by this many stops" — which is what this
 * control is. No manual ISO/shutter, no pipeline rebuild, no second engine.
 *
 * THREE MECHANISMS, KEPT SEPARATE ON PURPOSE
 *
 *   A. CAMERA EXPOSURE ("native-exposure")
 *      The user's value reaches the sensor as an EV bias through the native
 *      bridge. The viewfinder brightens because the scene is really exposed
 *      brighter, and the captured JPEG carries the same exposure — no pixel
 *      post-processing participates. Capability comes from the native side:
 *      range, step and support are device facts, not assumptions.
 *
 *   B. PHOTO PROCESSING ("photo-processing")
 *      The existing Skia-matrix path. It remains — explicitly — as the
 *      fallback on cameras/builds where the native seam reports
 *      `supported: false` (an unpatched development build, a simulator, or a
 *      camera module whose driver offers no compensation). The UI labels the
 *      two mechanisms differently and the capture pipeline routes the level
 *      to exactly one of them, so they never stack.
 *
 *   C. VIEWFINDER WASH (approximation)
 *      Rendered ONLY for mechanism B. Under mechanism A the real preview
 *      change IS the preview response; adding a wash on top would double the
 *      visible adjustment and lie about the sensor.
 *
 * Everything a device does NOT get to decide lives here: the UI's logical
 * scale, EV conversion, clamping, sanitising of native payloads, mechanism
 * selection and the capture routing rule.
 */

import { BRIGHTNESS_MAX, BRIGHTNESS_MIN, clampBrightness } from "./cameraControls";

/* ─────────────────────── capabilities (device facts) ────────────────────── */

/**
 * What the NATIVE camera reports for exposure compensation, normalised.
 *
 *   supported — the sensor/driver really accepts an EV bias RIGHT NOW
 *   minEV/maxEV — supported compensation window in stops (e.g. −2 … +2)
 *   stepEV — quantisation of one compensation step in stops (Android CameraX
 *            reports e.g. 0.5 or 1/6; iOS exposes a continuous float bias,
 *            modelled here as step 0 = "no quantisation")
 *   currentEV — the value the session currently sits at, as measured natively
 */
export interface ExposureCapabilities {
  readonly supported: boolean;
  readonly minEV: number;
  readonly maxEV: number;
  readonly stepEV: number;
  readonly currentEV: number;
}

/** The safe answer for "we do not know": no seam, no support, zero bias. */
export const EXPOSURE_UNSUPPORTED: ExposureCapabilities = {
  supported: false,
  minEV: 0,
  maxEV: 0,
  stepEV: 0,
  currentEV: 0,
};

function finiteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

/**
 * Sanitises WHATEVER the native event carried. A malformed payload — missing
 * fields, strings, NaN, an inverted range, a negative step — must degrade to
 * "unsupported", never to a clamp bound that quietly mirrors the corruption.
 */
export function normalizeExposureCapabilities(payload: unknown): ExposureCapabilities {
  if (payload === null || typeof payload !== "object") return EXPOSURE_UNSUPPORTED;
  const record = payload as Record<string, unknown>;
  if (record.supported !== true) return EXPOSURE_UNSUPPORTED;

  const minEV = finiteNumber(record.minEV);
  const maxEV = finiteNumber(record.maxEV);
  const stepEV = finiteNumber(record.stepEV);
  const currentEV = finiteNumber(record.currentEV) ?? 0;
  if (minEV === null || maxEV === null || stepEV === null) return EXPOSURE_UNSUPPORTED;
  if (minEV >= maxEV || stepEV < 0) return EXPOSURE_UNSUPPORTED;

  return { supported: true, minEV, maxEV, stepEV, currentEV };
}

/* ─────────────────────── the logical exposure scale ─────────────────────── */

/**
 * One UI detent = HALF A STOP. The slider keeps its seven familiar detents
 * (−3 … 0 … +3), so the exposure window it can express is ±1.5 EV — inside
 * the ±2 EV that effectively every CameraX device advertises and well inside
 * iOS's float range. The user keeps saying "two brighter"; the hardware hears
 * "+1.0 EV from auto".
 */
export const EXPOSURE_EV_PER_LEVEL = 0.5;

/** The UI value, converted to stops. Not yet device-clamped. */
export function exposureLevelToEV(level: unknown): number {
  return clampBrightness(level) * EXPOSURE_EV_PER_LEVEL;
}

/**
 * The mechanism that will ACTUALLY carry the user's next adjustment.
 * `null` capabilities mean the native bridge has not spoken (simulator,
 * Expo Go, unpatched build, web) — the photograph-processing fallback
 * answers instead, under its own distinct label.
 */
export type ExposureMechanism = "native-exposure" | "photo-processing";

export function resolveExposureMechanism(
  capabilities: ExposureCapabilities | null,
): ExposureMechanism {
  return capabilities !== null && capabilities.supported
    ? "native-exposure"
    : "photo-processing";
}

/* ─────────────────────────────── clamping ───────────────────────────────── */

/**
 * Clamps a requested EV to the device's REAL window and snaps it onto the
 * device's step. Never passes an out-of-contract number to hardware: NaN,
 * undefined and unsupported devices all collapse to a neutral 0 EV.
 */
export function clampExposureEV(
  ev: unknown,
  capabilities: ExposureCapabilities | null,
): number {
  if (capabilities === null || !capabilities.supported) return 0;
  const requested = finiteNumber(ev) ?? 0;
  const step = capabilities.stepEV;
  const snapped =
    step > 0
      ? Math.round(requested / step) * step
      : requested;
  const clamped = Math.min(capabilities.maxEV, Math.max(capabilities.minEV, snapped));
  /* Guard float residue at the snap (0.1+0.2 territory): EV is displayed and
     compared, so carry at most ~1/1000 of a stop. */
  return Math.round(clamped * 1000) / 1000;
}

/**
 * Which UI detents the device can HONESTLY offer. A +3 detent that the
 * sensor clamps to +0.5 would be a badge that lies, so on the native
 * mechanism the slider's range narrows to the device's EV window (converted
 * whole-detent-wise) instead of pretending.
 * Photo processing is software gain and always offers the full −3 … +3.
 */
export interface ExposureLevelRange {
  readonly minLevel: number;
  readonly maxLevel: number;
}

export function exposureAvailableLevels(
  capabilities: ExposureCapabilities | null,
): ExposureLevelRange {
  if (capabilities === null || !capabilities.supported) {
    return { minLevel: BRIGHTNESS_MIN, maxLevel: BRIGHTNESS_MAX };
  }
  const minLevel = Math.max(
    BRIGHTNESS_MIN,
    Math.ceil(capabilities.minEV / EXPOSURE_EV_PER_LEVEL - 1e-9),
  );
  const maxLevel = Math.min(
    BRIGHTNESS_MAX,
    Math.floor(capabilities.maxEV / EXPOSURE_EV_PER_LEVEL + 1e-9),
  );
  return { minLevel, maxLevel: Math.max(maxLevel, minLevel) };
}

/**
 * The one clamp the STORE applies to the user-facing detent. On the native
 * mechanism it enforces the device window; on the fallback it is the classic
 * −3 … +3.
 */
export function clampExposureLevel(
  level: unknown,
  capabilities: ExposureCapabilities | null,
): number {
  const detent = clampBrightness(level);
  const { minLevel, maxLevel } = exposureAvailableLevels(capabilities);
  return Math.min(maxLevel, Math.max(minLevel, detent));
}

/* ───────────────── device switching & live prop derivation ──────────────── */

/**
 * CAMERA SWITCHING (democratic choice, documented): the LOGICAL setting is
 * retained across front → rear → front — the user's intent ("a little
 * brighter") does not change because the lens did. On every new capabilities
 * report (bind, switch, session restart) the detent is re-clamped into the
 * NEW camera's window, and the EV handed to the lens follows from it.
 */
export function reconcileExposureLevel(
  currentLevel: unknown,
  capabilities: ExposureCapabilities | null,
): number {
  return clampExposureLevel(currentLevel, capabilities);
}

/**
 * The exact number to hand the native `exposureCompensation` prop right now:
 * the detent in stops, device-clamped and step-snapped; 0 whenever the seam
 * does not exist — so an unpatched build receives a harmless range status quo.
 */
export function exposureCompensationProp(
  level: unknown,
  capabilities: ExposureCapabilities | null,
): number {
  return clampExposureEV(exposureLevelToEV(level), capabilities);
}

/* ─────────────────────── capture-time routing rule ──────────────────────── */

/**
 * THE NO-DOUBLE-COUNTING RULE. One adjustment travels exactly one road:
 *
 *   native-exposure   → the SENSOR holds the bias; the captured JPEG already
 *                       IS the exposed photograph, so the pixel pipeline must
 *                       receive the identity detent (0) and do nothing;
 *   photo-processing  → the sensor saw nothing; the Skia matrix owns the
 *                       detent on the saved file, as before.
 */
export function captureBrightnessLevel(
  mechanism: ExposureMechanism,
  level: unknown,
): number {
  return mechanism === "native-exposure" ? 0 : clampBrightness(level);
}
