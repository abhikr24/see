/**
 * shared/camera/cameraFilters.ts — LOOKS & FILTER STRENGTH.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero colors.
 *
 * WHY THIS MODULE EXISTS (the audit that produced it)
 *
 * Before this module the filter feature was a PICTURE OF A FEATURE. The
 * evidence, from the code itself and not from memory:
 *
 *   · `FilterStrip` offered Original / Vivid / Warm / Cool / B&W and wrote the
 *     choice into `useCameraSession.filter`;
 *   · the ONLY consumer of that value was `router.push({ … filterUsed })`,
 *     i.e. a metadata string attached to the saved photo record;
 *   · `applyCaptureFraming` — the one place where captured pixels are
 *     rewritten — knew about brightness and aspect ratio and NOTHING about
 *     filters;
 *   · the native viewfinder showed no filter at all, while the browser mirror
 *     applied a CSS filter of its own invention, so the two disagreed.
 *
 * A user who picked "B&W" therefore got a full-colour photograph labelled
 * `bw` in the gallery. That is precisely the class of decorative control the
 * brightness work already refused to ship, so the filters are repaired the
 * same way, from the same kind of single source:
 *
 *   THE LOOK IS A COLOR MATRIX. The matrix is defined once, here. The capture
 *   pipeline applies it to the FILE (in the same single Skia pass that already
 *   does brightness and cropping — no second decode, no new dependency), the
 *   browser mirror applies the SAME twenty numbers through `feColorMatrix`,
 *   and the live viewfinder shows an approximation that is DERIVED from it —
 *   mathematically, since D2 — and is labelled as an approximation.
 *
 * D2 (live-preview ⇄ capture parity) then closed the last remaining second
 * source of truth: the viewfinder approximation itself. What had been a
 * hand-picked tint colour and opacity per look (a theme token plus a table
 * in this file — i.e. a second, unmaintained filter definition) is now a
 * constrained least-squares PROJECTION of the twenty numbers onto the only
 * operation a translucent view can perform over a native camera surface, so
 * the approximation is provably the closest one the hardware allows, moves
 * with every recipe/strength change automatically, and carries measured
 * direction/magnitude agreement instead of hopeful adjectives. See the
 * "viewfinder projection" section below and docs/d2-filter-parity.md.
 *
 * WHY A MATRIX RATHER THAN A LIBRARY
 *
 *   · A 4×5 color matrix is exactly what `Skia.ColorFilter.MakeMatrix`,
 *     SVG `feColorMatrix` and every GPU shader already speak, so one
 *     definition drives device, mirror and tests with no translation layer.
 *   · It is closed under composition: brightness ∘ look collapses into ONE
 *     matrix, so adding filters costs zero extra passes over the pixels.
 *   · Strength is then trivially honest: interpolate the matrix toward the
 *     identity. 0 % is provably the untouched photograph (the pipeline can
 *     skip all work), 100 % is the full look, and everything between is a
 *     straight line the user can feel.
 *
 * WHAT IS DELIBERATELY *NOT* HERE
 *
 * No LUTs, no curves, no grain, no vignette, no per-channel editing UI. This
 * is a camera, not a darkroom: five looks and one strength slider is the whole
 * surface, and the pose-coaching overlay always outranks it.
 */

/* ────────────────────────────── identity ──────────────────────────────── */

export type CameraFilterId = "original" | "vivid" | "warm" | "cool" | "bw";

/**
 * The strip order. Original first because "no look" must be the shortest
 * journey on the screen, then the two colour looks, then the two extremes.
 */
export const CAMERA_FILTER_IDS: readonly CameraFilterId[] = [
  "original",
  "vivid",
  "warm",
  "cool",
  "bw",
];

export const FILTER_DEFAULT: CameraFilterId = "original";

export function clampFilterId(value: unknown): CameraFilterId {
  return typeof value === "string" &&
    (CAMERA_FILTER_IDS as readonly string[]).includes(value)
    ? (value as CameraFilterId)
    : FILTER_DEFAULT;
}

/* ────────────────────────────── strength ──────────────────────────────── */

/**
 * Strength is a PERCENTAGE, 0…100, in steps of 10.
 *
 * Percent rather than a 1..5 dial because "70 %" is a thing a person can say,
 * remember and return to; steps rather than a continuous float because a
 * thumb on a 100 px track cannot reliably reproduce 63 %, and because a
 * quantised value makes "back to full" an exact landing rather than a nudge.
 */
export const FILTER_INTENSITY_MIN = 0;
export const FILTER_INTENSITY_MAX = 100;
export const FILTER_INTENSITY_STEP = 10;
/** A look the user chose should arrive as the look they saw on the tile. */
export const FILTER_INTENSITY_DEFAULT = 100;

export function clampFilterIntensity(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    return FILTER_INTENSITY_DEFAULT;
  }
  const stepped = Math.round(value / FILTER_INTENSITY_STEP) * FILTER_INTENSITY_STEP;
  return Math.max(FILTER_INTENSITY_MIN, Math.min(FILTER_INTENSITY_MAX, stepped));
}

/** 0…1, the interpolation parameter the matrices actually consume. */
export function filterStrength(intensity: unknown): number {
  return clampFilterIntensity(intensity) / FILTER_INTENSITY_MAX;
}

/**
 * True when the look would not change a single pixel — either it IS Original
 * or its strength is zero. The pipeline uses this to return the captured file
 * untouched: no decode, no re-encode, no quality loss, no latency.
 */
export function filterIsIdentity(id: unknown, intensity: unknown): boolean {
  return clampFilterId(id) === "original" || clampFilterIntensity(intensity) === 0;
}

/** Strength only exists for looks that do something. */
export function filterSupportsIntensity(id: unknown): boolean {
  return clampFilterId(id) !== "original";
}

/* ───────────────────────────── the recipes ────────────────────────────── */

/**
 * A look expressed in four photographic words instead of twenty numbers.
 * The numbers are generated from these, so a look can be reasoned about
 * ("warm is a mild saturation lift plus a red/blue tilt") and reviewed.
 */
export interface FilterRecipe {
  readonly id: CameraFilterId;
  /** 1 = untouched. >1 deepens colour, <1 drains it. */
  readonly saturation: number;
  /** 1 = untouched. Pivots around mid-grey so exposure is not shifted. */
  readonly contrast: number;
  /** −1 … +1. Positive lifts red and drops blue (warm); negative reverses. */
  readonly temperature: number;
  /** 0 … 1 fraction of the pixel replaced by its own luminance. */
  readonly desaturateToLuma: number;
}

/**
 * Values chosen to be *photographic*, not demo-loud: at full strength each
 * look is clearly itself on a phone screen, and none of them clips skin tones
 * or crushes the shadows that the pose silhouette is read against.
 */
export const FILTER_RECIPES: Readonly<Record<CameraFilterId, FilterRecipe>> = {
  original: {
    id: "original",
    saturation: 1,
    contrast: 1,
    temperature: 0,
    desaturateToLuma: 0,
  },
  vivid: {
    id: "vivid",
    saturation: 1.38,
    contrast: 1.1,
    temperature: 0,
    desaturateToLuma: 0,
  },
  warm: {
    id: "warm",
    saturation: 1.12,
    contrast: 1.03,
    temperature: 0.75,
    desaturateToLuma: 0,
  },
  cool: {
    id: "cool",
    saturation: 1.06,
    contrast: 1.03,
    temperature: -0.75,
    desaturateToLuma: 0,
  },
  bw: {
    id: "bw",
    saturation: 1,
    contrast: 1.14,
    temperature: 0,
    desaturateToLuma: 1,
  },
};

export function filterRecipe(id: unknown): FilterRecipe {
  return FILTER_RECIPES[clampFilterId(id)];
}

/* ─────────────────────────── matrix machinery ─────────────────────────── */

/**
 * Rec. 709 luminance weights — the same ones every video pipeline uses, so a
 * B&W conversion here matches what a user expects from a camera rather than
 * the naive (R+G+B)/3 that turns skies white and lips grey.
 */
const LUMA_R = 0.2126;
const LUMA_G = 0.7152;
const LUMA_B = 0.0722;

/** Row-major RGBA 4×5 (20 numbers) — Skia, feColorMatrix and Android agree. */
export type ColorMatrix = readonly number[];

export const IDENTITY_COLOR_MATRIX: ColorMatrix = [
  1, 0, 0, 0, 0,
  0, 1, 0, 0, 0,
  0, 0, 1, 0, 0,
  0, 0, 0, 1, 0,
];

function saturationMatrix(s: number): ColorMatrix {
  const ir = (1 - s) * LUMA_R;
  const ig = (1 - s) * LUMA_G;
  const ib = (1 - s) * LUMA_B;
  return [
    ir + s, ig, ib, 0, 0,
    ir, ig + s, ib, 0, 0,
    ir, ig, ib + s, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

/**
 * Contrast pivots on mid-grey (0.5): `out = (in − 0.5) · c + 0.5`, i.e. a gain
 * plus a compensating offset. Without the pivot, "more contrast" would also
 * mean "brighter", and it would fight the brightness control the user already
 * has.
 */
function contrastMatrix(c: number): ColorMatrix {
  const t = (1 - c) * 0.5;
  return [
    c, 0, 0, 0, t,
    0, c, 0, 0, t,
    0, 0, c, 0, t,
    0, 0, 0, 1, 0,
  ];
}

/**
 * Temperature as a channel tilt: red and blue move in opposite directions and
 * green is left alone, which is what "warmer/cooler" means to a photographer.
 * 12 % at full tilt — enough to read as golden-hour / overcast, not enough to
 * turn faces orange.
 */
function temperatureMatrix(t: number): ColorMatrix {
  const r = 1 + 0.12 * t;
  const b = 1 - 0.12 * t;
  return [
    r, 0, 0, 0, 0,
    0, 1, 0, 0, 0,
    0, 0, b, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

function lumaMatrix(amount: number): ColorMatrix {
  const a = Math.max(0, Math.min(1, amount));
  const keep = 1 - a;
  return [
    keep + a * LUMA_R, a * LUMA_G, a * LUMA_B, 0, 0,
    a * LUMA_R, keep + a * LUMA_G, a * LUMA_B, 0, 0,
    a * LUMA_R, a * LUMA_G, keep + a * LUMA_B, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

/* ── the primitives, published ──────────────────────────────────────────
 *
 * POST-CAPTURE EDITING (shared/camera/photoEditing) needs exactly the same
 * three building blocks the looks are made of. They are re-exported rather
 * than re-derived so there is still ONE definition of "what saturation means"
 * in this codebase: the same Rec. 709 weights, the same mid-grey contrast
 * pivot, the same ±12 % temperature tilt. A second private copy in the editor
 * is precisely how two features that claim the same words start disagreeing.
 */

/** `s` = 1 leaves the pixel alone; > 1 deepens colour, < 1 drains it. */
export function saturationColorMatrix(s: number): ColorMatrix {
  return saturationMatrix(s);
}

/** `c` = 1 leaves the pixel alone; pivots on mid-grey, so exposure is kept. */
export function contrastColorMatrix(c: number): ColorMatrix {
  return contrastMatrix(c);
}

/** `t` in −1 … +1; positive is warmer (red up, blue down). */
export function temperatureColorMatrix(t: number): ColorMatrix {
  return temperatureMatrix(t);
}

/** `amount` in 0 … 1 of the pixel replaced by its own Rec. 709 luminance. */
export function luminanceColorMatrix(amount: number): ColorMatrix {
  return lumaMatrix(amount);
}

/**
 * `second ∘ first` — the single matrix that is equivalent to applying `first`
 * and then `second`. This is what lets brightness, look and strength cost ONE
 * pass over the pixels instead of three.
 */
export function composeColorMatrices(
  first: ColorMatrix,
  second: ColorMatrix,
): ColorMatrix {
  const out: number[] = new Array<number>(20).fill(0);
  for (let row = 0; row < 4; row += 1) {
    for (let col = 0; col < 4; col += 1) {
      let sum = 0;
      for (let k = 0; k < 4; k += 1) {
        sum += (second[row * 5 + k] ?? 0) * (first[k * 5 + col] ?? 0);
      }
      out[row * 5 + col] = sum;
    }
    let offset = second[row * 5 + 4] ?? 0;
    for (let k = 0; k < 4; k += 1) {
      offset += (second[row * 5 + k] ?? 0) * (first[k * 5 + 4] ?? 0);
    }
    out[row * 5 + 4] = offset;
  }
  return out;
}

/** Straight-line blend toward the identity — this IS the strength control. */
export function lerpToIdentity(matrix: ColorMatrix, strength: number): ColorMatrix {
  const t = Math.max(0, Math.min(1, strength));
  return IDENTITY_COLOR_MATRIX.map(
    (identity, index) => identity + ((matrix[index] ?? identity) - identity) * t,
  );
}

const MATRIX_EPSILON = 1e-6;

export function colorMatrixIsIdentity(matrix: ColorMatrix): boolean {
  return IDENTITY_COLOR_MATRIX.every(
    (value, index) => Math.abs((matrix[index] ?? value) - value) < MATRIX_EPSILON,
  );
}

/** The full-strength matrix for a look, before the strength blend. */
export function filterBaseMatrix(id: unknown): ColorMatrix {
  const recipe = filterRecipe(id);
  let matrix = IDENTITY_COLOR_MATRIX;
  if (recipe.desaturateToLuma > 0) {
    matrix = composeColorMatrices(matrix, lumaMatrix(recipe.desaturateToLuma));
  }
  if (recipe.saturation !== 1) {
    matrix = composeColorMatrices(matrix, saturationMatrix(recipe.saturation));
  }
  if (recipe.temperature !== 0) {
    matrix = composeColorMatrices(matrix, temperatureMatrix(recipe.temperature));
  }
  if (recipe.contrast !== 1) {
    matrix = composeColorMatrices(matrix, contrastMatrix(recipe.contrast));
  }
  return matrix;
}

/**
 * THE look matrix at the user's chosen strength. Consumed by the device Skia
 * pass, by the browser mirror's `feColorMatrix`, by the thumbnail renderer and
 * by the tests — one definition, four consumers, no drift possible.
 */
export function filterColorMatrix(id: unknown, intensity: unknown): ColorMatrix {
  if (filterIsIdentity(id, intensity)) return IDENTITY_COLOR_MATRIX;
  return lerpToIdentity(filterBaseMatrix(id), filterStrength(intensity));
}

/** Applies a matrix to one 0..1 RGB sample. Used by tests and thumbnails. */
export function applyColorMatrix(
  rgb: readonly [number, number, number],
  matrix: ColorMatrix,
): readonly [number, number, number] {
  const [r, g, b] = rgb;
  const channel = (row: number): number => {
    const value =
      (matrix[row * 5] ?? 0) * r +
      (matrix[row * 5 + 1] ?? 0) * g +
      (matrix[row * 5 + 2] ?? 0) * b +
      (matrix[row * 5 + 4] ?? 0);
    return Math.max(0, Math.min(1, value));
  };
  return [channel(0), channel(1), channel(2)];
}

/** Rec. 709 luminance of a 0..1 RGB sample — used to prove B&W is neutral. */
export function luminanceOf(rgb: readonly [number, number, number]): number {
  return LUMA_R * rgb[0] + LUMA_G * rgb[1] + LUMA_B * rgb[2];
}

/* ────────────────── the one matrix the capture pipeline uses ───────────── */

export interface CaptureLookInput {
  readonly filter: unknown;
  readonly intensity: unknown;
  /** Already-resolved multiplicative brightness gain (1 = untouched). */
  readonly brightnessGain: number;
}

/**
 * BRIGHTNESS ∘ LOOK, collapsed.
 *
 * Order matters and is deliberate: the LOOK is applied to the photograph the
 * sensor produced, and the brightness detent then acts on the result, exactly
 * as a user reads the two controls ("this look, a bit brighter"). Because both
 * are linear, the two collapse into one matrix and the captured JPEG is still
 * decoded once, drawn once and encoded once.
 */
export function captureColorMatrix(input: CaptureLookInput): ColorMatrix {
  const look = filterColorMatrix(input.filter, input.intensity);
  const gain =
    typeof input.brightnessGain === "number" && Number.isFinite(input.brightnessGain)
      ? input.brightnessGain
      : 1;
  if (Math.abs(gain - 1) < MATRIX_EPSILON) return look;
  const brightness: ColorMatrix = [
    gain, 0, 0, 0, 0,
    0, gain, 0, 0, 0,
    0, 0, gain, 0, 0,
    0, 0, 0, 1, 0,
  ];
  return composeColorMatrices(look, brightness);
}

/* ────────────── viewfinder projection (D2 — preview ≈ capture) ────────── */

/**
 * WHAT THE LIVE VIEWFINDER CAN AND CANNOT DO, stated in data and now MEASURED
 * instead of asserted.
 *
 * `expo-camera` renders the preview in its own native view (a CameraX
 * `SurfaceView` on Android, an `AVCaptureVideoPreviewLayer` on iOS) and hands
 * JavaScript no frames: SDK 57 has no frame processor, no GL binding and no
 * exposure hook. Verified for D2 against current sources and the installed
 * type surface, not from memory:
 *
 *   · FRAME PROCESSORS require react-native-vision-camera — a different
 *     native build and a second camera library. The project's own camera
 *     docs already rejected that foundation replacement; D2 honours the
 *     rejection (and the planned A1 native-frame work stays unblocked:
 *     nothing here touches frames at all).
 *   · RN `mixBlendMode` (New Architecture, Android 10+) blends inside the
 *     app's own layer; on Android the camera lives in a SEPARATE
 *     SurfaceFlinger layer the blend cannot read, so behaviour would differ
 *     per platform — and a full-screen offscreen blend pass every frame is
 *     GPU work the real-time pose engine should never have to compete with.
 *   · A still-capture JPEG loop is forbidden outright (D2 §10 and sanity).
 *
 * What remains — and is therefore what this module models EXACTLY — is one
 * composited translucent view: out = (1−α)·x + α·c, an affine transform with
 * shared gain g = 1−α ∈ [1−CAP, 1] and offset o = α·c ∈ [0, α] per channel.
 * Rather than hand-picking (α, c) per look (the old `filterPreviewWash` +
 * `filterWashColors` theme token — a second, unmaintained filter definition,
 * measured ~3× too strong for warm/cool and pointed the WRONG WAY for vivid,
 * direction agreement −0.22), the overlay here is PRODUCED by projecting the
 * canonical matrix onto that model class: the weighted-least-squares optimum
 * over a fixed photographic calibration set. Same twenty numbers in, closest
 * lawful approximation out — when a recipe or strength moves, the preview
 * moves, by construction.
 *
 * The cap is unchanged and non-negotiable: at 0.22 the veil is as strong as
 * it may get while the pose silhouette, the guidance arrows and the match
 * state stay readable at every strength. Creative effects never outrank
 * coaching.
 */
export const FILTER_PREVIEW_MAX_OPACITY = 0.22;

/**
 * The photographic truth the projection minimises error against. Fixed
 * forever: changing the set would change every fitted number, so any change
 * belongs in a dedicated review, like a recipe change. The grey ramp is
 * triple-weighted (camera content is mostly near-neutral, and B&W honesty
 * stands on luminance neutrality), the 6³ cube covers the gamut uniformly,
 * and the eight anchors (skin light/shadow, sky, foliage, specular highlight,
 * deep shadow) stand in for what the camera is pointed at most.
 */
interface CalibrationSample {
  readonly x: readonly [number, number, number];
  readonly w: number;
}

const CALIBRATION_SET: readonly CalibrationSample[] = (() => {
  const samples: CalibrationSample[] = [];
  for (const v of [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]) {
    samples.push({ x: [v, v, v], w: 3 });
  }
  for (const r of [0, 0.2, 0.4, 0.6, 0.8, 1]) {
    for (const g of [0, 0.2, 0.4, 0.6, 0.8, 1]) {
      for (const b of [0, 0.2, 0.4, 0.6, 0.8, 1]) {
        samples.push({ x: [r, g, b], w: 1 });
      }
    }
  }
  const anchors: readonly (readonly [number, number, number])[] = [
    [0.76, 0.57, 0.44], // skin, lit
    [0.45, 0.33, 0.27], // skin, shadowed
    [0.53, 0.72, 0.92], // sky, bright
    [0.35, 0.55, 0.8], // sky, deep
    [0.28, 0.46, 0.2], // foliage, lit
    [0.15, 0.3, 0.12], // foliage, shadowed
    [0.92, 0.9, 0.86], // specular highlight
    [0.08, 0.08, 0.09], // deep shadow
  ];
  for (const anchor of anchors) samples.push({ x: anchor, w: 2 });
  return samples;
})();

/**
 * The resolved, MEASURED viewfinder approximation of the look matrix at the
 * user's strength. `opacity`/`color` are everything the renderer needs;
 * `parity` is the quantitative honesty the strip's copy stands on.
 */
export interface FilterPreviewOverlay {
  /** 0 … FILTER_PREVIEW_MAX_OPACITY, quantised to 1e-3. 0 renders nothing. */
  readonly opacity: number;
  /** sRGB channels 0…1 of the fitted veil. Mid-grey when opacity is 0. */
  readonly color: readonly [number, number, number];
  /** "#RRGGBB" ready for a View style. "#808080" when opacity is 0. */
  readonly colorHex: string;
  readonly parity: FilterPreviewParity;
}

/**
 * How far the fitted overlay is from the TRUE matrix, all measured on the
 * calibration set, all in 0…1 channel units:
 *
 *   lookMagnitude      mean |Δlook| — how much the filter itself moves pixels;
 *   overlayDeviation   mean |Δoverlay| — how much the veil moves them;
 *   magnitudeRatio     the two divided: 1.0 would be "shown at exactly true
 *                      strength"; the old hand-tuned veils sat at ≈ 2.8–3.0;
 *   meanResidual       mean |look − overlay| after the optimal fit;
 *   maxResidual        worst single sample/channel error;
 *   directionAgreement cosine between Δlook and Δoverlay over the set:
 *                      1 = same direction, 0 = orthogonal (the veil cannot
 *                      express the transform), negative = actively misleading
 *                      (the old vivid veil measured −0.22 here).
 */
export interface FilterPreviewParity {
  readonly lookMagnitude: number;
  readonly overlayDeviation: number;
  readonly magnitudeRatio: number;
  readonly meanResidual: number;
  readonly maxResidual: number;
  readonly directionAgreement: number;
}

interface OverlayFit {
  readonly alpha: number;
  readonly offset: readonly [number, number, number];
  readonly lookMagnitude: number;
  readonly overlayDeviation: number;
  readonly meanResidual: number;
  readonly maxResidual: number;
  readonly directionAgreement: number;
}

/** Constrained LS projection of a matrix onto out = (1−α)·x + o. Exported for
    tests and the perf harness; the UI contract above never exposes internals. */
export function projectMatrixToOverlay(matrix: ColorMatrix): OverlayFit {
  /* ONE pass over the calibration set collects, per channel, every weighted
     aggregate the loss function can ever need, so each candidate α costs O(1)
     instead of another sweep. Targets are clamped to the displayable range,
     matching what the 8-bit capture surface does. */
  let W = 0;
  const sx = [0, 0, 0];
  const sxx = [0, 0, 0];
  const sy = [0, 0, 0];
  const syy = [0, 0, 0];
  const sxy = [0, 0, 0];
  let lookAbs = 0;
  for (const sample of CALIBRATION_SET) {
    const w = sample.w;
    W += w;
    const [x0, x1, x2] = sample.x;
    const xs = [x0, x1, x2];
    for (let c = 0; c < 3; c += 1) {
      const y = Math.max(
        0,
        Math.min(
          1,
          (matrix[c * 5] ?? 0) * x0 +
            (matrix[c * 5 + 1] ?? 0) * x1 +
            (matrix[c * 5 + 2] ?? 0) * x2 +
            (matrix[c * 5 + 4] ?? 0),
        ),
      );
      const x = xs[c] ?? 0;
      sx[c] = (sx[c] ?? 0) + w * x;
      sxx[c] = (sxx[c] ?? 0) + w * x * x;
      sy[c] = (sy[c] ?? 0) + w * y;
      syy[c] = (syy[c] ?? 0) + w * y * y;
      sxy[c] = (sxy[c] ?? 0) + w * x * y;
      lookAbs += w * Math.abs(y - x);
    }
  }

  /* 1-D search over the ONE degree of freedom the law leaves: α. Given α,
     the optimal offset per channel is the clamped weighted mean residual;
     ties resolve to the smaller α (the less interventionist preview). */
  const GRID_STEPS = 220;
  let bestAlpha = 0;
  const bestOffset: [number, number, number] = [0, 0, 0];
  let bestLoss = Number.POSITIVE_INFINITY;
  for (let k = 0; k <= GRID_STEPS; k += 1) {
    const alpha = (FILTER_PREVIEW_MAX_OPACITY * k) / GRID_STEPS;
    const gain = 1 - alpha;
    let loss = 0;
    const offset: [number, number, number] = [0, 0, 0];
    for (let c = 0; c < 3; c += 1) {
      const mean = ((sy[c] ?? 0) - gain * (sx[c] ?? 0)) / W;
      const o = Math.max(0, Math.min(alpha, mean));
      offset[c] = o;
      /* Σw(y − g·x − o)² expanded over the aggregates. */
      loss +=
        (syy[c] ?? 0) -
        2 * gain * (sxy[c] ?? 0) -
        2 * o * (sy[c] ?? 0) +
        gain * gain * (sxx[c] ?? 0) +
        2 * gain * o * (sx[c] ?? 0) +
        o * o * W;
    }
    if (loss < bestLoss - 1e-12) {
      bestLoss = loss;
      bestAlpha = alpha;
      bestOffset[0] = offset[0];
      bestOffset[1] = offset[1];
      bestOffset[2] = offset[2];
    }
  }

  /* The measured honesty block, computed with the winning (α, o). */
  const gain = 1 - bestAlpha;
  let meanResidual = 0;
  let maxResidual = 0;
  let overlayAbs = 0;
  let dot = 0;
  let normLook = 0;
  let normOverlay = 0;
  for (const sample of CALIBRATION_SET) {
    const w = sample.w;
    const [x0, x1, x2] = sample.x;
    const xs = [x0, x1, x2];
    for (let c = 0; c < 3; c += 1) {
      const x = xs[c] ?? 0;
      const y = Math.max(
        0,
        Math.min(
          1,
          (matrix[c * 5] ?? 0) * x0 +
            (matrix[c * 5 + 1] ?? 0) * x1 +
            (matrix[c * 5 + 2] ?? 0) * x2 +
            (matrix[c * 5 + 4] ?? 0),
        ),
      );
      const pred = gain * x + (bestOffset[c] ?? 0);
      const lookDelta = y - x;
      const overlayDelta = pred - x;
      const err = Math.abs(y - pred);
      meanResidual += w * err;
      if (err > maxResidual) maxResidual = err;
      overlayAbs += w * Math.abs(overlayDelta);
      dot += w * lookDelta * overlayDelta;
      normLook += w * lookDelta * lookDelta;
      normOverlay += w * overlayDelta * overlayDelta;
    }
  }
  const W3 = W * 3;
  const direction =
    normLook < 1e-12
      ? 1
      : normOverlay < 1e-12
        ? 0
        : dot / Math.sqrt(normLook * normOverlay);
  return {
    alpha: bestAlpha,
    offset: bestOffset,
    lookMagnitude: lookAbs / W3,
    overlayDeviation: overlayAbs / W3,
    meanResidual: meanResidual / W3,
    maxResidual,
    directionAgreement: direction,
  };
}

const round3 = (value: number): number => Math.round(value * 1000) / 1000;
const round4 = (value: number): number => Math.round(value * 10000) / 10000;

const HEX_DIGITS = "0123456789ABCDEF";
function channelHex(value: number): string {
  const v = Math.max(0, Math.min(255, Math.round(value * 255)));
  return `${HEX_DIGITS[(v >> 4) & 15]}${HEX_DIGITS[v & 15]}`;
}

/**
 * THE live-preview renderer's contract with the canonical definition. The
 * matrix the capture pipeline will bake is computed FIRST (strength included
 * — the same `filterColorMatrix` the Skia pass consumes), then projected, so
 * strength semantics cannot drift between the two renderers: 0 % produces a
 * provably zero-opacity overlay just as it produces a provably untouched file.
 *
 * Deterministic, total, allocation-light; memoise per (id, intensity) at the
 * call site and it costs nothing during zoom, capture or pose work.
 */
export function filterPreviewOverlay(
  id: unknown,
  intensity: unknown,
): FilterPreviewOverlay {
  const fit = projectMatrixToOverlay(filterColorMatrix(id, intensity));
  const opacity = round3(fit.alpha);
  const color: readonly [number, number, number] =
    fit.alpha < 1e-9
      ? [0.5, 0.5, 0.5]
      : [
          round3(Math.max(0, Math.min(1, fit.offset[0] / fit.alpha))),
          round3(Math.max(0, Math.min(1, fit.offset[1] / fit.alpha))),
          round3(Math.max(0, Math.min(1, fit.offset[2] / fit.alpha))),
        ];
  const magnitudeRatio =
    fit.lookMagnitude < 1e-9 ? 1 : fit.overlayDeviation / fit.lookMagnitude;
  return {
    opacity,
    color,
    colorHex:
      opacity === 0
        ? "#808080"
        : `#${channelHex(color[0])}${channelHex(color[1])}${channelHex(color[2])}`,
    parity: {
      lookMagnitude: round4(fit.lookMagnitude),
      overlayDeviation: round4(fit.overlayDeviation),
      magnitudeRatio: round4(magnitudeRatio),
      meanResidual: round4(fit.meanResidual),
      maxResidual: round4(fit.maxResidual),
      directionAgreement: round4(fit.directionAgreement),
    },
  };
}

/* ───────────── fidelity: declared from the measurement, not by hand ───── */

/**
 * The thresholds the fidelity declaration stands on. A look is `tinted` only
 * when its fitted overlay BOTH points the way the capture does (direction
 * agreement ≥ 0.30) and shows a meaningful share of it (magnitude ratio in
 * [0.35, 1.75]). Everything else is honestly `not-representable`, which is
 * what drives the strip's "shown after the shot" copy. Chosen AFTER the fits
 * were measured (warm 0.37 / 0.46, cool 0.51 / 0.62, bw 0.59 / 0.30, vivid
 * 0 / 0); changing them is a review event, like changing a recipe.
 */
export const PREVIEW_TINTED_MIN_DIRECTION = 0.3;
export const PREVIEW_TINTED_MIN_RATIO = 0.35;
export const PREVIEW_TINTED_MAX_RATIO = 1.75;

/**
 * What THIS device viewfinder can truthfully say about a look:
 *
 *   `exact`            Original — there is nothing to represent;
 *   `tinted`           the fitted veil demonstrably resembles the look
 *                      (warm, cool — measured, not claimed);
 *   `not-representable` no lawful overlay can say it. B&W: nothing composited
 *                      on top can REMOVE colour (the fitted grey hint is
 *                      still drawn, labelled). Vivid: the transform is
 *                      cross-channel with positive gain — orthogonal to the
 *                      overlay class — and the optimal overlay is provably
 *                      "nothing", so the strip says "shown after the shot"
 *                      instead of dressing the viewfinder in a veil that
 *                      measured as actively misleading (−0.22).
 *
 * The browser mirror is a different renderer with real pixel access, so it
 * is `exact` for every look — see `filterPreviewMatrixValues`.
 */
export type ViewfinderFidelity = "exact" | "tinted" | "not-representable";

export function viewfinderFidelity(id: unknown): ViewfinderFidelity {
  const filter = clampFilterId(id);
  if (filter === "original") return "exact";
  const fit = projectMatrixToOverlay(filterColorMatrix(filter, FILTER_INTENSITY_MAX));
  const ratio =
    fit.lookMagnitude < 1e-9 ? 1 : fit.overlayDeviation / fit.lookMagnitude;
  if (
    fit.alpha > 1e-9 &&
    fit.directionAgreement >= PREVIEW_TINTED_MIN_DIRECTION &&
    ratio >= PREVIEW_TINTED_MIN_RATIO &&
    ratio <= PREVIEW_TINTED_MAX_RATIO
  ) {
    return "tinted";
  }
  return "not-representable";
}

/* ─────────────── the canonical LookDefinition (D2 §canonical) ─────────── */

/**
 * ONE definition, TWO renderers, no third place to look.
 *
 * This is the object D2 asks for by name: per look, the capture mapping and
 * the preview mapping stated side by side with the strength contract they
 * share, so "does the preview match the capture?" is a question the DATA
 * answers instead of a comment somebody wrote.
 *
 *   capture.fullStrengthMatrix — exactly what the Skia pass bakes at 100 %
 *     (before the brightness ∘ look composition in `captureColorMatrix`);
 *   preview.fidelity / preview.overlay — the measured projection of THAT
 *     matrix at 100 %, i.e. the most the native viewfinder can lawfully say.
 *
 * Both mappings already READ strength from this module (`filterStrength` →
 * `lerpToIdentity`), so the relationship is deliberate, documented and
 * mechanically unbreakable: there is no second set of parameters to drift.
 */
export interface LookStrengthSpec {
  readonly min: number;
  readonly max: number;
  readonly step: number;
  readonly defaultValue: number;
}

export interface LookDefinition {
  readonly id: CameraFilterId;
  /** The generative parameters — the single source both renderers derive from. */
  readonly recipe: FilterRecipe;
  readonly supportsIntensity: boolean;
  readonly strength: LookStrengthSpec;
  readonly capture: {
    readonly fullStrengthMatrix: ColorMatrix;
  };
  readonly preview: {
    readonly fidelity: ViewfinderFidelity;
    readonly overlay: FilterPreviewOverlay;
  };
}

export function lookDefinition(id: unknown): LookDefinition {
  const filter = clampFilterId(id);
  return {
    id: filter,
    recipe: filterRecipe(filter),
    supportsIntensity: filterSupportsIntensity(filter),
    strength: {
      min: FILTER_INTENSITY_MIN,
      max: FILTER_INTENSITY_MAX,
      step: FILTER_INTENSITY_STEP,
      defaultValue: FILTER_INTENSITY_DEFAULT,
    },
    capture: { fullStrengthMatrix: filterColorMatrix(filter, FILTER_INTENSITY_MAX) },
    preview: {
      fidelity: viewfinderFidelity(filter),
      overlay: filterPreviewOverlay(filter, FILTER_INTENSITY_MAX),
    },
  };
}

/** The whole catalogue in strip order — the same order as CAMERA_FILTER_IDS. */
export const LOOK_DEFINITIONS: readonly LookDefinition[] =
  CAMERA_FILTER_IDS.map((id) => lookDefinition(id));

/* ─────────────────────────── labels & badges ──────────────────────────── */

/** `null` at full strength: "100 %" on every tile is noise, not information. */
export function filterIntensityBadge(id: unknown, intensity: unknown): string | null {
  if (!filterSupportsIntensity(id)) return null;
  const value = clampFilterIntensity(intensity);
  if (value === FILTER_INTENSITY_DEFAULT) return null;
  return `${value}%`;
}

/** What the gallery/preview chip says: "Vivid · 60%" or just "Vivid". */
export function filterSummary(
  id: unknown,
  intensity: unknown,
  labelFor: (filter: CameraFilterId) => string,
): string {
  const filter = clampFilterId(id);
  const label = labelFor(filter);
  const badge = filterIntensityBadge(filter, intensity);
  return badge === null ? label : `${label} · ${badge}`;
}

/* ─────────────────────── web-mirror interoperability ──────────────────── */

/**
 * The same twenty numbers, formatted for SVG `feColorMatrix`. The browser
 * mirror feeds this straight into a filter primitive, so the mirror is not an
 * "impression" of the device look — it is the identical linear transform,
 * evaluated by a different rasteriser.
 */
export function filterPreviewMatrixValues(id: unknown, intensity: unknown): string {
  return filterColorMatrix(id, intensity)
    .map((value) => Math.round(value * 10000) / 10000)
    .join(" ");
}

/**
 * A CSS `filter` fallback for surfaces that cannot reference an SVG filter
 * (small thumbnails, printed docs, older engines). Derived from the SAME
 * recipe, so it moves with strength, and honestly approximate: CSS has no
 * colour-temperature primitive, so the red/blue tilt is expressed as sepia
 * (warm) or hue-rotate (cool).
 */
export function filterPreviewCss(id: unknown, intensity: unknown): string {
  if (filterIsIdentity(id, intensity)) return "none";
  const recipe = filterRecipe(id);
  const t = filterStrength(intensity);
  const mix = (value: number): number =>
    Math.round((1 + (value - 1) * t) * 1000) / 1000;
  const parts: string[] = [];
  if (recipe.desaturateToLuma > 0) {
    parts.push(`grayscale(${Math.round(recipe.desaturateToLuma * t * 1000) / 1000})`);
  }
  if (recipe.saturation !== 1) parts.push(`saturate(${mix(recipe.saturation)})`);
  if (recipe.contrast !== 1) parts.push(`contrast(${mix(recipe.contrast)})`);
  if (recipe.temperature > 0) {
    parts.push(`sepia(${Math.round(recipe.temperature * 0.28 * t * 1000) / 1000})`);
  } else if (recipe.temperature < 0) {
    parts.push(`hue-rotate(${Math.round(recipe.temperature * -14 * t * 10) / 10}deg)`);
  }
  return parts.length === 0 ? "none" : parts.join(" ");
}
