/**
 * shared/camera/cameraFraming.ts — FRAMING: zoom, aspect ratio, grid, level.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero colors.
 * Everything a phone camera needs to answer "how much of the world is in the
 * picture, and is the picture straight?" — decided ONCE, here, so the
 * viewfinder, the capture pipeline, the accessibility labels and the browser
 * mirror can never disagree about it.
 *
 * WHAT WAS WRONG BEFORE THIS MODULE (audited, not assumed)
 *
 *  · ZOOM was a raw `zoom01` (the expo-camera 0..1 prop) multiplied by the
 *    pinch scale. At the default value `zoom01` is 0 — and `0 * scale === 0`,
 *    so pinching out from 1× could never leave 1×. The user had to already be
 *    zoomed for zoom to work. There were no zoom stops, no way back to 1×
 *    except pinching all the way in, and the front camera inherited the rear
 *    camera's 8× range.
 *  · ASPECT RATIO did not exist. Every shot was whatever the sensor handed
 *    back, and the user could not frame a square or a wide crop.
 *  · GRID existed as a fixed rule-of-thirds overlay across the WHOLE screen,
 *    including the parts of the frame that a non-native ratio will not keep.
 *  · LEVEL did not exist.
 *
 * HONESTY RULES ENCODED HERE (a control that lies is worse than no control)
 *
 *  · `ZOOM_MECHANISM = "digital-crop"`. The locked camera foundation
 *    (expo-camera ~57) exposes ONE normalised `zoom` prop and NO lens/optical
 *    camera selection. So this app never shows the "0.5× / 1× / 3×" lens
 *    switcher of a stock camera app: those labels claim physical lenses this
 *    stack cannot select. The stops offered here are honest digital-zoom
 *    multipliers, and the UI says so.
 *  · `ASPECT_MECHANISM = "preview-mask-plus-capture-crop"`. expo-camera's
 *    `ratio` prop is Android-only and applies to the preview surface, not to
 *    every still on every device. Rather than depend on that, the selected
 *    ratio is (a) masked on the viewfinder so the user sees the real frame and
 *    (b) CROPPED INTO THE SAVED FILE after the shutter, so what was framed is
 *    what is kept. No ratio is offered that cannot be produced by cropping the
 *    sensor's own frame.
 *  · `LEVEL_MECHANISM = "accelerometer-gravity"`. Roll comes from the gravity
 *    vector of the device accelerometer; nothing is invented, and when no
 *    sensor answers, the guide simply does not appear.
 */

/* ═══════════════════════════════ 1. ZOOM ═══════════════════════════════ */

export type CameraFacingId = "front" | "back";

/**
 * What the zoom control actually does. Read by the UI to word its own
 * footnote and by tests/docs so the claim stays auditable.
 */
export const ZOOM_MECHANISM = "digital-crop" as const;

/** Every camera starts at 1× — "the whole frame" — and returns to it. */
export const ZOOM_DEFAULT_X = 1;

/**
 * Upper bounds, per camera, as MULTIPLIERS the user can name.
 *
 * Rear 8×: the previous implementation's range, kept so no existing reach is
 * lost. Front 4×: a selfie sensor is smaller and the crop degrades roughly
 * twice as fast, and — decisive for THIS app — a self-portrait at 8× digital
 * zoom cannot contain a posing body at all. Offering it would be offering
 * mush.
 */
const ZOOM_MAX_X: Readonly<Record<CameraFacingId, number>> = {
  back: 8,
  front: 4,
};

/**
 * The stops a tap can jump between. Familiar, short, and always ending on the
 * range maximum so "as close as this camera goes" is one tap away.
 */
const ZOOM_STOPS: Readonly<Record<CameraFacingId, readonly number[]>> = {
  back: [1, 2, 4, 8],
  front: [1, 2, 4],
};

function facingOf(facing: unknown): CameraFacingId {
  return facing === "front" ? "front" : "back";
}

export function zoomMaxFor(facing: unknown): number {
  return ZOOM_MAX_X[facingOf(facing)];
}

export function zoomStopsFor(facing: unknown): readonly number[] {
  return ZOOM_STOPS[facingOf(facing)];
}

/** Total: any garbage in, a usable multiplier out. */
export function clampZoom(multiplier: unknown, facing: unknown): number {
  const max = zoomMaxFor(facing);
  if (typeof multiplier !== "number" || !Number.isFinite(multiplier)) {
    return ZOOM_DEFAULT_X;
  }
  return Math.max(ZOOM_DEFAULT_X, Math.min(max, multiplier));
}

export function isZoomDefault(multiplier: unknown, facing: unknown): boolean {
  return clampZoom(multiplier, facing) <= ZOOM_DEFAULT_X + 1e-6;
}

/**
 * Multiplier → the normalised 0..1 value the camera foundation consumes.
 *
 * The mapping is linear in the multiplier because that is the only mapping
 * this foundation documents on both platforms; it is an APPROXIMATION of the
 * device's real digital-zoom curve, which is exactly why the displayed number
 * is the multiplier the app asked for and not a claim about the sensor.
 */
export function zoomToNormalized(multiplier: unknown, facing: unknown): number {
  const max = zoomMaxFor(facing);
  const value = clampZoom(multiplier, facing);
  if (max <= ZOOM_DEFAULT_X) return 0;
  return (value - ZOOM_DEFAULT_X) / (max - ZOOM_DEFAULT_X);
}

/** The inverse, for state arriving from a legacy 0..1 value. */
export function zoomFromNormalized(normalized: unknown, facing: unknown): number {
  const max = zoomMaxFor(facing);
  const n =
    typeof normalized === "number" && Number.isFinite(normalized)
      ? Math.max(0, Math.min(1, normalized))
      : 0;
  return clampZoom(ZOOM_DEFAULT_X + n * (max - ZOOM_DEFAULT_X), facing);
}

/**
 * Pinch. MULTIPLICATIVE, against the multiplier the gesture started from —
 * the only model in which spreading your fingers by the same amount always
 * feels like the same amount of zoom, and the model whose absence made the
 * old control dead at 1×.
 */
export function zoomFromPinch(
  baseMultiplier: unknown,
  gestureScale: unknown,
  facing: unknown,
): number {
  const base = clampZoom(baseMultiplier, facing);
  const scale =
    typeof gestureScale === "number" && Number.isFinite(gestureScale) && gestureScale > 0
      ? gestureScale
      : 1;
  return clampZoom(base * scale, facing);
}

/** Tap-cycling through the stops; wraps back to 1× after the last one. */
export function nextZoomStop(current: unknown, facing: unknown): number {
  const stops = zoomStopsFor(facing);
  const value = clampZoom(current, facing);
  for (const stop of stops) {
    if (stop > value + 1e-3) return stop;
  }
  return ZOOM_DEFAULT_X;
}

/** The nearest stop, used to highlight "where am I" on the stop row. */
export function activeZoomStop(current: unknown, facing: unknown): number | null {
  const value = clampZoom(current, facing);
  for (const stop of zoomStopsFor(facing)) {
    if (Math.abs(stop - value) < 0.05) return stop;
  }
  return null;
}

/**
 * "1×", "2×", "2.4×". Whole numbers never carry a pointless ".0", because a
 * readout that says "1.0x" when nothing is happening is the chrome this
 * screen already spent a pass removing.
 */
export function formatZoom(multiplier: unknown, facing: unknown): string {
  const value = clampZoom(multiplier, facing);
  const rounded = Math.round(value * 10) / 10;
  const text = Number.isInteger(rounded) ? `${rounded}` : rounded.toFixed(1);
  return `${text}\u00d7`;
}

/* ═══════════════════════════ 2. ASPECT RATIO ═══════════════════════════ */

export type AspectRatioId = "4:3" | "1:1" | "16:9";

export const ASPECT_MECHANISM = "preview-mask-plus-capture-crop" as const;

/**
 * The sensor's own still-capture shape on effectively every phone: 4:3. It is
 * therefore the DEFAULT and the one ratio that involves no crop at all — the
 * "full sensor" option, which is what a camera app should hand you unless you
 * ask for something narrower.
 */
export const ASPECT_DEFAULT: AspectRatioId = "4:3";

export const ASPECT_RATIO_IDS: readonly AspectRatioId[] = ["4:3", "1:1", "16:9"];

/** long side / short side. 1:1 is square, so the value is 1. */
const ASPECT_VALUE: Readonly<Record<AspectRatioId, number>> = {
  "4:3": 4 / 3,
  "1:1": 1,
  "16:9": 16 / 9,
};

export function isAspectRatioId(value: unknown): value is AspectRatioId {
  return value === "4:3" || value === "1:1" || value === "16:9";
}

export function resolveAspectRatio(value: unknown): AspectRatioId {
  return isAspectRatioId(value) ? value : ASPECT_DEFAULT;
}

/** Long-over-short for the id; total. */
export function aspectRatioValue(value: unknown): number {
  return ASPECT_VALUE[resolveAspectRatio(value)];
}

/** True when the ratio is the sensor's own shape and nothing is discarded. */
export function aspectIsNative(value: unknown): boolean {
  return resolveAspectRatio(value) === ASPECT_DEFAULT;
}

export function nextAspectRatio(value: unknown): AspectRatioId {
  const index = ASPECT_RATIO_IDS.indexOf(resolveAspectRatio(value));
  return ASPECT_RATIO_IDS[(index + 1) % ASPECT_RATIO_IDS.length] ?? ASPECT_DEFAULT;
}

export interface FrameBox {
  readonly left: number;
  readonly top: number;
  readonly width: number;
  readonly height: number;
}

/**
 * The visible frame inside a PORTRAIT viewfinder of `frameWidth × frameHeight`.
 *
 * The viewfinder itself is left full-bleed (the camera keeps filling the
 * screen, exactly as the stock app does); this box is where the KEPT image is,
 * and everything outside it is masked. Centred vertically, so the subject the
 * user already framed stays where it was.
 *
 * Degenerate inputs return a zero box rather than NaN — an overlay that draws
 * nothing is recoverable, an overlay full of NaN is not.
 */
export function aspectFrameBox(
  ratio: unknown,
  frameWidth: number,
  frameHeight: number,
): FrameBox {
  const w = Number.isFinite(frameWidth) && frameWidth > 0 ? frameWidth : 0;
  const h = Number.isFinite(frameHeight) && frameHeight > 0 ? frameHeight : 0;
  if (w === 0 || h === 0) return { left: 0, top: 0, width: 0, height: 0 };

  /* Portrait: the long side is vertical, so height = width × (long/short). */
  const wanted = w * aspectRatioValue(ratio);
  const height = Math.min(h, wanted);
  const width = w;
  return {
    left: 0,
    top: Math.max(0, (h - height) / 2),
    width,
    height,
  };
}

/** How much of the viewfinder's height the mask covers, top and bottom each. */
export function aspectMaskInset(
  ratio: unknown,
  frameWidth: number,
  frameHeight: number,
): number {
  return aspectFrameBox(ratio, frameWidth, frameHeight).top;
}

export interface CropRect {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

/**
 * The CENTRE crop to apply to the captured file so the saved photograph is
 * the frame the user actually composed. Returns `null` when the file already
 * matches (within 1 %), which is both the 4:3 case and the "this device gave
 * us something else entirely" case — never crop for a rounding error.
 *
 * Orientation-agnostic: works from the file's own long/short sides, so a
 * landscape JPEG from a rotated device crops to the same shape.
 */
export function aspectCropRect(
  ratio: unknown,
  photoWidth: number,
  photoHeight: number,
): CropRect | null {
  if (
    !Number.isFinite(photoWidth) ||
    !Number.isFinite(photoHeight) ||
    photoWidth <= 0 ||
    photoHeight <= 0
  ) {
    return null;
  }

  const portrait = photoHeight >= photoWidth;
  const short = portrait ? photoWidth : photoHeight;
  const long = portrait ? photoHeight : photoWidth;
  const wantedLong = short * aspectRatioValue(ratio);

  if (wantedLong >= long * 0.99) return null; // already this shape (or wider)

  const keptLong = Math.round(wantedLong);
  const offset = Math.round((long - keptLong) / 2);

  return portrait
    ? { x: 0, y: offset, width: Math.round(short), height: keptLong }
    : { x: offset, y: 0, width: keptLong, height: Math.round(short) };
}

/* ═══════════════════════════════ 3. GRID ═══════════════════════════════ */

/**
 * Rule-of-thirds fractions. Exported as data (not baked into a component) so
 * the mobile overlay and the browser mirror draw the SAME lines, and so the
 * lines can be placed inside the aspect box instead of across the screen.
 */
export const GRID_FRACTIONS: readonly number[] = [1 / 3, 2 / 3];

/* ═════════════════════════ 4. LEVEL / HORIZON ═════════════════════════ */

export const LEVEL_MECHANISM = "accelerometer-gravity" as const;

/** Inside this, the shot is level and the guide says so instead of nagging. */
export const LEVEL_TOLERANCE_DEG = 1.5;

/**
 * Past this the phone is being re-oriented (or pointed at the floor), not
 * tilted: a horizon guide there is noise, so it stands down.
 */
export const LEVEL_VISIBLE_MAX_DEG = 30;

export type LevelIndicatorState = "hidden" | "tilted" | "level";

export interface LevelReading {
  /** Sensor answered at least once. */
  readonly available: boolean;
  /** Roll in degrees; negative = tilted left, positive = tilted right. */
  readonly rollDeg: number;
}

export interface LevelResolution {
  readonly state: LevelIndicatorState;
  /** Clamped for drawing, so a 90° flip can never rotate the guide absurdly. */
  readonly rollDeg: number;
  readonly isLevel: boolean;
  /** Whole degrees, for the readout. Always non-negative. */
  readonly tiltDeg: number;
}

/**
 * Minimum length of the in-screen-plane gravity component before a roll can
 * be claimed at all. Pointed at the floor or the ceiling, almost all of
 * gravity is on the device's z axis and the remaining x/y is noise: there is
 * no horizon to be level with, so the honest answer is "no reading".
 */
const LEVEL_MIN_PLANAR_G = 0.35;

/**
 * Roll from a gravity vector, in the phone's own portrait frame.
 * Positive = the RIGHT edge of the phone has dropped.
 *
 * The two platforms report opposite signs for the same pose — held upright in
 * portrait, Android's accelerometer reads ≈(0, +1) (it reports the specific
 * force, which points away from the earth) and iOS reads ≈(0, −1) (it reports
 * the gravity direction). Normalising on the sign of `y` collapses both into
 * one convention before the angle is taken, so the guide cannot be mirrored
 * on one of the two platforms.
 */
export function rollFromGravity(x: unknown, y: unknown): number | null {
  const gx = typeof x === "number" && Number.isFinite(x) ? x : null;
  const gy = typeof y === "number" && Number.isFinite(y) ? y : null;
  if (gx === null || gy === null) return null;
  if (Math.hypot(gx, gy) < LEVEL_MIN_PLANAR_G) return null;

  const flip = gy >= 0 ? 1 : -1;
  const radians = Math.atan2(gx * flip, gy * flip);
  return (-radians * 180) / Math.PI;
}

/**
 * Low-pass filter. Raw accelerometer roll jitters by a degree or two at rest;
 * an un-smoothed horizon line shivers and reads as a bug.
 */
export function smoothRoll(previous: number | null, next: number, alpha = 0.25): number {
  if (previous === null || !Number.isFinite(previous)) return next;
  const a = Math.max(0, Math.min(1, alpha));
  return previous + (next - previous) * a;
}

export function resolveLevel(reading: LevelReading): LevelResolution {
  const raw =
    Number.isFinite(reading.rollDeg) && reading.available ? reading.rollDeg : 0;
  const clamped = Math.max(-90, Math.min(90, raw));
  const magnitude = Math.abs(clamped);
  const isLevel = magnitude <= LEVEL_TOLERANCE_DEG;

  if (!reading.available || magnitude > LEVEL_VISIBLE_MAX_DEG) {
    return { state: "hidden", rollDeg: clamped, isLevel, tiltDeg: Math.round(magnitude) };
  }
  return {
    state: isLevel ? "level" : "tilted",
    rollDeg: clamped,
    isLevel,
    tiltDeg: Math.round(magnitude),
  };
}

/* ═══════════════ 5. WHEN MAY ANY OF THIS BE ON SCREEN? ═══════════════ */

/**
 * PoseAssist is not a generic camera: the user is copying a body silhouette,
 * reading a coaching sentence and holding still. Framing aids that are correct
 * but permanent would sit on top of exactly that. One resolver decides, so no
 * component invents its own rule.
 *
 * `blocked` is the screen's existing blocking-layer flag (countdown, capture,
 * processing, model loading, paused session): during those, EVERYTHING here
 * stands down, because the frame belongs to the shot.
 */
export interface FramingVisibilityInput {
  readonly sessionLive: boolean;
  /** A blocking layer owns the screen (countdown / capturing / …). */
  readonly blocked: boolean;
  /** A pose or palm hold is counting down to a shot. */
  readonly holding: boolean;
  readonly gridEnabled: boolean;
  readonly levelEnabled: boolean;
  readonly levelState: LevelIndicatorState;
  /** Pinching now, or lingering just after a pinch. */
  readonly zoomEngaged: boolean;
  readonly zoomMultiplier: number;
  readonly facing: CameraFacingId;
  readonly aspectRatio: AspectRatioId;
}

export interface FramingVisibility {
  readonly showGrid: boolean;
  readonly showLevel: boolean;
  /** The stop row (1× 2× 4× …) — contextual, never permanent chrome. */
  readonly showZoomStops: boolean;
  /** The transient "2.4×" readout. */
  readonly showZoomReadout: boolean;
  /** Letterbox mask for a non-native ratio. */
  readonly showAspectMask: boolean;
  /** True while zoom is off 1× — the control offers a one-tap way back. */
  readonly canResetZoom: boolean;
}

export function resolveFramingVisibility(
  input: FramingVisibilityInput,
): FramingVisibility {
  const live = input.sessionLive && !input.blocked;
  const zoomed = !isZoomDefault(input.zoomMultiplier, input.facing);

  return {
    /* The grid helps you place a body; it does not help you hold one. While a
       hold is running the user must see the silhouette and nothing else. */
    showGrid: live && input.gridEnabled && !input.holding,
    /* The level speaks only when it has something to say: the phone is tilted,
       or it has just become level and is confirming it. Never during a hold. */
    showLevel:
      live && input.levelEnabled && !input.holding && input.levelState !== "hidden",
    showZoomStops: live && (input.zoomEngaged || zoomed),
    showZoomReadout: live && (input.zoomEngaged || zoomed),
    /* The mask is the frame itself, so it stays up whenever the viewfinder is
       showing — including during a hold, where removing it would silently
       change what the user thinks they are composing. */
    showAspectMask: input.sessionLive && !aspectIsNative(input.aspectRatio),
    canResetZoom: zoomed,
  };
}

/* ═══════════════════ 6. THE BOTTOM CHROME STACK ═══════════════════════ */

import { sizing } from "../theme/sizing";

/**
 * The LOOKS zone's total height above the bottom controls bar, in points.
 *
 * FINAL INTEGRATION PASS — this is the number the coaching band's author
 * never subtracted.
 *
 * The vertical stack at the bottom of the live viewfinder is, from the
 * screen edge up: bottom controls bar → LOOKS zone (swatch rail + optional
 * strength track) → everything that must stay visible above it (zoom stops
 * row, coaching band). The zoom row already added this height; the coaching
 * band measured from the zone's BOTTOM edge instead, so its pill overlapped
 * the swatches it rendered above (zIndex 25 over the strip). The band is
 * `pointerEvents="none"`, so the strip still worked — it just read as a
 * dashboard collision, exactly the class of defect this module exists to
 * make impossible. ONE clearance number, and both consumers stack above it.
 *
 * Totality contract: a strength track cannot exist without a visible strip
 * (`resolveCameraPresentation` hides the zone during any blocking layer),
 * so "strength without strip" clears to ZERO rather than producing chrome
 * for a control that is not on screen.
 */
export function filterZoneClearance(
  stripVisible: boolean,
  strengthVisible: boolean,
): number {
  if (!stripVisible) return 0;
  return (
    sizing.cameraFilterStrip +
    (strengthVisible ? sizing.cameraFilterStrength : 0)
  );
}
