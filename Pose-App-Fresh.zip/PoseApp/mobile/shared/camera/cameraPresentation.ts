/**
 * shared/camera/cameraPresentation.ts — Camera UX Part 1:
 * THE CAMERA-SCREEN COMMUNICATION PRIORITY MODEL.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero network, zero React.
 *
 * WHY IT EXISTS
 *
 * The camera screen renders eleven independent overlays, each with its own
 * `visible` condition spread across ~130 lines of JSX. Nothing arbitrated
 * between them, so several pairs could legitimately occupy the same pixels
 * and the same attention at the same moment, e.g.
 *
 *   · hold-progress ("Hold your pose", 95 %) + the coaching band
 *     ("Perfect — hold it")            → the SAME instruction, twice, stacked;
 *   · the coaching band + a capture failure message competing for the one
 *     strip of screen above the filter row;
 *   · the voice chip, the match pill and the reference thumbnail all pinned
 *     to hand-computed absolute `top` values on a narrow device.
 *
 * This module is the arbiter. It answers ONE question —
 * *given the whole runtime state, what is the user allowed to be told right
 * now?* — as a pure, total, unit-testable function. It renders nothing,
 * styles nothing and knows no design tokens.
 *
 * THE HIERARCHY (highest wins, exactly one blocking layer at a time)
 *
 *   1. processing      the shutter fired, the photo is being written
 *   2. capturing       the shutter is firing right now
 *   3. countdown       a capture is committed and counting down
 *   4. model-loading   pose detection is not usable yet
 *   5. session-paused  the viewfinder was released (blur / background)
 *   6. none            live coaching
 *
 * Everything above level 6 is TRANSIENT and owns the whole screen. Level 6 is
 * PERSISTENT chrome. Transient layers suppress persistent chrome; persistent
 * chrome never suppresses a transient layer.
 */
import type { CoachingKind } from "../coaching/types";

/** The one full-screen state that currently owns the user's attention. */
export type CameraBlockingLayer =
  | "none"
  | "session-paused"
  | "model-loading"
  | "countdown"
  | "capturing"
  | "processing";

/** Why the shutter is refusing input. Surfaced verbatim to the user. */
export type CaptureBlockReason =
  | "none"
  | "session-paused"
  | "camera-warming"
  | "model-loading"
  | "countdown-running"
  | "capture-in-progress";

/**
 * The three honest answers to "is the app talking to me?".
 * `idle` is NOT cosmetic: without it a silent coach is indistinguishable from
 * a muted one, which is the single most common camera-screen confusion.
 */
export type VoiceIndicatorMode = "hidden" | "speaking" | "idle" | "muted";

/**
 * Camera UX Part 2 — how loudly the raw match number is allowed to speak.
 *
 * The percentage is an ENGINEERING readout. It is truthful, but it is not an
 * instruction, and in the states where the engine cannot judge the body it is
 * not even meaningful. Emphasis is therefore a first-class decision:
 *
 *   hidden   nothing measurable to report — a "0 %" sitting next to
 *            "step into frame" reads as failure rather than absence;
 *   muted    a number exists and is worth tracking, but the SENTENCE the
 *            coach is saying outranks it;
 *   primary  the number IS the message (locked in / holding for the shutter).
 */
export type MatchEmphasis = "hidden" | "muted" | "primary";

/**
 * Camera UX Part 2 — what the ring around the shutter is currently saying.
 *
 * Hold progress used to live in a floating card in the middle of the frame,
 * i.e. as far as possible from both the shutter and the user's own image. The
 * ring puts the deadline exactly where the thumb already is and removes one
 * competing glass surface from the viewfinder.
 */
export type ShutterRing = "none" | "ready" | "hold-auto" | "hold-gesture";

/** Which intelligent-capture source currently owns the hold. */
export type HoldSource = "none" | "auto" | "gesture";

/**
 * Camera UX Part 3 — HOW LOUD THE PERSISTENT CHROME IS ALLOWED TO BE.
 *
 * Part 2 reduced the number of surfaces. It did not reduce their WEIGHT: the
 * status rail rendered at full contrast for the entire session, including the
 * long stretches where it has nothing to report ("Checking", no number). A
 * readout that looks identical when it is idle and when it is urgent trains
 * the user to stop looking at it, which is the opposite of confidence.
 *
 *   ambient  nothing is happening that the user must act on — the rail
 *            recedes (lower opacity, thinner presence) so the SUBJECT is the
 *            brightest thing on screen;
 *   active   the state is moving (a correction to fix, a lock achieved, a
 *            hold counting down) — the rail comes forward.
 *
 * This is emphasis only. Nothing is added, removed or re-worded, so no state
 * can become unreachable because of it.
 */
export type RailEmphasis = "ambient" | "active";

/**
 * Camera UX Part 3 — how much the coaching band is allowed to say.
 *
 * `full`    headline + supporting detail (the normal coaching case).
 * `compact` headline only. Used at the two moments where the user is
 *           physically holding still and must not be handed a second line to
 *           read: the pose is locked in, or a hold is already running.
 */
export type CoachingEmphasis = "full" | "compact";

/** How close the user is to a shot, in one word, for the primary readout. */
export type CameraReadiness =
  | "blocked"
  | "searching"
  | "evaluating"
  | "adjusting"
  | "ready";

export type MlStatus = "idle" | "loading" | "ready" | "unavailable";

export interface CameraPresentationInput {
  /** Focused AND foregrounded AND the viewfinder is mounted. */
  readonly sessionLive: boolean;
  /** expo-camera reported `onCameraReady`. */
  readonly cameraReady: boolean;
  readonly mlStatus: MlStatus;
  readonly countdownActive: boolean;
  readonly isCapturing: boolean;
  readonly isProcessing: boolean;
  /** Semantic coaching kind for this frame; null when no decision exists. */
  readonly coachingKind: CoachingKind | null;
  /** max(auto, gesture) hold progress, 0..1. */
  readonly holdProgress: number;
  /** A recoverable capture/save failure is being shown. */
  readonly captureErrorActive: boolean;
  readonly voiceGuidanceEnabled: boolean;
  readonly isSpeaking: boolean;
  /**
   * Camera UX Part 2 — the zoom readout is TRANSIENT.
   *
   * A pill that permanently announces "1.0x" is pure chrome: it reports a
   * non-event, it never changes, and it sits in the most valuable strip of
   * the frame. The screen raises this flag only while the user is actually
   * zooming (or is off the 1.0x default), and the pill fades out again.
   * Optional and default-false so no existing caller changes behaviour by
   * accident: absent means "nothing is happening with zoom".
   */
  readonly zoomEngaged?: boolean;
  /**
   * Which trigger owns the current hold. `holdProgress` alone cannot say
   * whether the user is being rewarded for their POSE or for their PALM, and
   * those two deserve different colours and different words.
   */
  readonly holdSource?: HoldSource;
}

export interface CameraPresentation {
  readonly blocking: CameraBlockingLayer;
  readonly showCoachingBand: boolean;
  /**
   * The live readout exists. Since Part 2 it is ONE rail (readiness word +
   * match number + voice state) instead of two independently positioned
   * pills; the flag keeps its original name because its meaning — "the
   * measurement surface is allowed on screen" — did not change.
   */
  readonly showMatchPill: boolean;
  /** Alias of `showMatchPill`, named for what Part 2 actually renders. */
  readonly showStatusRail: boolean;
  readonly showHoldProgress: boolean;
  readonly showReferenceThumb: boolean;
  readonly showFilterStrip: boolean;
  readonly showZoomPill: boolean;
  readonly voiceIndicator: VoiceIndicatorMode;
  readonly captureEnabled: boolean;
  readonly captureBlockReason: CaptureBlockReason;
  readonly readiness: CameraReadiness;
  /** How much attention the raw percentage may claim this frame. */
  readonly matchEmphasis: MatchEmphasis;
  /** What the ring drawn around the shutter is saying. */
  readonly shutterRing: ShutterRing;
  /** Part 3 — how much visual weight the persistent readout may claim. */
  readonly railEmphasis: RailEmphasis;
  /** Part 3 — whether the coaching band may show its supporting line. */
  readonly coachingEmphasis: CoachingEmphasis;
  /**
   * Part 3 — the pinned reference is also the answer to "which pose am I
   * shooting?", so it is allowed to be an identity chip (thumbnail + title +
   * a way back to pose selection) rather than a decorative thumbnail. The
   * flag mirrors `showReferenceThumb`; it exists so the screen never has to
   * re-derive the condition for the two halves of one surface.
   */
  readonly showPoseIdentity: boolean;
}

function blockingLayerFor(input: CameraPresentationInput): CameraBlockingLayer {
  if (input.isProcessing) return "processing";
  if (input.isCapturing) return "capturing";
  if (input.countdownActive) return "countdown";
  if (input.mlStatus === "loading") return "model-loading";
  if (!input.sessionLive) return "session-paused";
  return "none";
}

function captureBlockReasonFor(
  input: CameraPresentationInput,
): CaptureBlockReason {
  if (input.isProcessing || input.isCapturing) return "capture-in-progress";
  if (input.countdownActive) return "countdown-running";
  if (!input.sessionLive) return "session-paused";
  if (input.mlStatus === "loading") return "model-loading";
  if (!input.cameraReady) return "camera-warming";
  return "none";
}

function readinessFor(input: CameraPresentationInput): CameraReadiness {
  if (input.mlStatus !== "ready" || !input.sessionLive) return "blocked";
  switch (input.coachingKind) {
    case "perfect":
      return "ready";
    case "correction":
      return "adjusting";
    case "evaluating":
      return "evaluating";
    case "unavailable":
      return "searching";
    default:
      return "evaluating";
  }
}

/**
 * Camera UX Part 2. The number never contradicts the sentence.
 *
 *  · No rail on screen, or the engine cannot judge the body at all
 *    (`unavailable`) → HIDDEN. A percentage beside "step into frame" is a
 *    number about nobody.
 *  · Locked in, or a hold is running → PRIMARY. Here the number is the
 *    progress the user is being asked to defend, so it earns full contrast.
 *  · Everything else → MUTED. It stays visible (the user who wants to track
 *    improvement can), but it never out-shouts the coaching sentence.
 */
function matchEmphasisFor(
  input: CameraPresentationInput,
  railLive: boolean,
  readiness: CameraReadiness,
  holding: boolean,
): MatchEmphasis {
  if (!railLive) return "hidden";
  if (input.coachingKind === "unavailable" || input.coachingKind === null) {
    return "hidden";
  }
  if (holding || readiness === "ready") return "primary";
  return "muted";
}

/**
 * Camera UX Part 2. The shutter answers three questions at once — can I
 * shoot, am I being counted down by my own pose, and who started it.
 */
function shutterRingFor(
  input: CameraPresentationInput,
  railLive: boolean,
  readiness: CameraReadiness,
  holding: boolean,
): ShutterRing {
  if (!railLive) return "none";
  if (holding) {
    return (input.holdSource ?? "auto") === "gesture"
      ? "hold-gesture"
      : "hold-auto";
  }
  return readiness === "ready" ? "ready" : "none";
}

function voiceIndicatorFor(
  input: CameraPresentationInput,
  blocking: CameraBlockingLayer,
): VoiceIndicatorMode {
  if (blocking !== "none") return "hidden";
  if (!input.voiceGuidanceEnabled) return "muted";
  return input.isSpeaking ? "speaking" : "idle";
}

/**
 * Resolves the whole screen in one pass. Pure and total.
 *
 * Deliberate suppression rules encoded here (each one removes a real,
 * observed double-message):
 *
 *  · `holdProgress` in flight + `kind === 'perfect'` → the band is hidden.
 *    The progress bar already says "hold", and says it with a deadline.
 *  · a capture failure is showing → the band and the filter strip yield the
 *    bottom strip to it. An error the user must act on outranks coaching.
 *  · any blocking layer → ALL persistent chrome is hidden, including the
 *    voice chip. A countdown must read as a countdown, not as a dashboard.
 */
export function resolveCameraPresentation(
  input: CameraPresentationInput,
): CameraPresentation {
  const blocking = blockingLayerFor(input);
  const live = blocking === "none";
  const mlReady = input.mlStatus === "ready";
  const holding = input.holdProgress > 0 && input.holdProgress < 1;
  const duplicateHoldMessage = holding && input.coachingKind === "perfect";
  const readiness = readinessFor(input);
  const railLive = live && mlReady;

  return {
    blocking,
    showCoachingBand:
      live && mlReady && !input.captureErrorActive && !duplicateHoldMessage,
    showMatchPill: railLive,
    showStatusRail: railLive,
    showHoldProgress: railLive && holding,
    showReferenceThumb: live,
    showFilterStrip: live && !input.captureErrorActive,
    /* Part 2: transient by design — see `zoomEngaged`. */
    showZoomPill: live && input.zoomEngaged === true,
    voiceIndicator: voiceIndicatorFor(input, blocking),
    captureEnabled: captureBlockReasonFor(input) === "none",
    captureBlockReason: captureBlockReasonFor(input),
    readiness,
    matchEmphasis: matchEmphasisFor(input, railLive, readiness, holding),
    shutterRing: shutterRingFor(input, railLive, readiness, holding),
    /* Part 3. The rail comes forward only when the state is worth a glance:
       a correction to act on, a lock achieved, or a hold already running.
       Searching/evaluating are the app thinking, not the user failing. */
    railEmphasis:
      holding || readiness === "ready" || readiness === "adjusting"
        ? "active"
        : "ambient",
    /* Part 3. One line while the body is being held still, two while the
       user is free to read. */
    coachingEmphasis: holding || readiness === "ready" ? "compact" : "full",
    showPoseIdentity: live,
  };
}
