/**
 * shared/camera/cameraStatusCopy.ts — Camera UX Part 1.
 *
 * Platform-neutral copy for the camera screen's CAPTURE-STATE communication:
 * countdown reason, shutter/processing stage, hold-progress labels, the
 * "why can't I shoot?" answer, and the voice-guidance chip.
 *
 * SCOPE NOTE (documented conflict resolution)
 *
 * `shared/types/settings.ts` says "UI strings stay English in V1". That
 * remains true for app CHROME (tab labels, Settings, Explore, Gallery…).
 * The strings in this file and in `shared/coaching/visibleCoaching.ts` are
 * the deliberate, narrow exception: they are the *live coaching surface*,
 * spoken and shown at the same instant about the same semantic state, and a
 * Hindi voice over an English overlay is a defect, not a V1 scope decision.
 * Nothing outside the camera viewfinder consumes this table.
 */
import type { InstructionLanguage } from "../constants/poseInstructions";
import { resolveInstructionLanguage } from "../voice/locales";
import type {
  CameraReadiness,
  CaptureBlockReason,
} from "./cameraPresentation";
import type { OpenPalmPhase } from "../ml/openPalmGate";
import type { CaptureTrigger } from "./intelligentCaptureController";
import {
  clampBrightness,
  type FlashModeValue,
  type TorchBlockedReason,
} from "./cameraControls";
import type { ExposureMechanism } from "./cameraExposure";
import {
  clampFilterId,
  clampFilterIntensity,
  filterIntensityBadge,
  viewfinderFidelity,
  type CameraFilterId,
} from "./cameraFilters";
import {
  formatZoom,
  type AspectRatioId,
  type CameraFacingId,
  type LevelResolution,
} from "./cameraFraming";

type Bilingual = Readonly<Record<InstructionLanguage, string>>;

function say(table: Bilingual, language: InstructionLanguage): string {
  return table[language] ?? table.en;
}

const COUNTDOWN_REASON: Readonly<Record<CaptureTrigger, Bilingual>> = {
  auto: { en: "Pose matched — shooting", hi: "पोज़ मैच हुआ — फोटो आ रही है" },
  gesture: { en: "Palm held — shooting", hi: "हथेली पकड़ी — फोटो आ रही है" },
  manual: { en: "Get set", hi: "तैयार हो जाओ" },
  /* VOLUME-BUTTON SHUTTER. The countdown has to name the input, otherwise a
     photo that starts without anyone touching the glass reads as a glitch. */
  hardware: { en: "Volume key — shooting", hi: "वॉल्यूम बटन — फोटो आ रही है" },
};

/**
 * VOLUME-BUTTON SHUTTER — the one sentence the shutter control adds to its
 * accessibility hint while the physical keys are actually armed.
 *
 * It is announced only when the capability is REAL and ARMED, never as an
 * advertisement for something this build cannot do.
 */
const VOLUME_SHUTTER_ARMED: Bilingual = {
  en: "Volume keys also take the photo",
  hi: "वॉल्यूम बटन से भी फोटो ले सकते हैं",
};

const CAPTURING: Bilingual = { en: "Capturing", hi: "फोटो ली जा रही है" };
const PROCESSING: Bilingual = { en: "Saving your shot", hi: "फोटो सेव हो रही है" };
const PAUSED: Bilingual = { en: "Camera paused", hi: "कैमरा रुका है" };
const PAUSED_DETAIL: Bilingual = {
  en: "Session released — reopen to continue",
  hi: "सेशन बंद है — दोबारा खोलें",
};

const HOLD_AUTO: Bilingual = { en: "Hold it", hi: "बस ऐसे ही रुको" };
const HOLD_GESTURE: Bilingual = { en: "Palm held", hi: "हथेली दिख गई" };

/**
 * GESTURE CAPTURE — four honest states, one short line each.
 *
 * The user has to be able to tell "I am not being recognised" from "I am
 * being recognised, keep going" from "that worked". Without that, a gesture
 * that deliberately refuses to fire on the first frame just reads as broken.
 * These are LABELS on the existing shutter ring — no new overlay, no warning
 * styling, no per-frame speech. Silence (`idle` → empty string) is the normal
 * state and must stay silent.
 */
const GESTURE_PHASE: Readonly<Record<OpenPalmPhase, Bilingual>> = {
  idle: { en: "", hi: "" },
  candidate: { en: "Open palm — hold still", hi: "हथेली खोलें — स्थिर रखें" },
  confirming: { en: "Holding palm", hi: "हथेली पकड़ी जा रही है" },
  confirmed: { en: "Palm held", hi: "हथेली दिख गई" },
  cooldown: { en: "", hi: "" },
  "awaiting-release": { en: "Lower your hand to reset", hi: "हाथ नीचे करें" },
};

/* Camera UX Part 2 — the flip control names the camera it will switch AWAY
   from, in the coaching language, at a readable size. */
const FACING_FRONT: Bilingual = { en: "FRONT", hi: "फ्रंट" };
const FACING_REAR: Bilingual = { en: "REAR", hi: "रियर" };

const NO_MATCH_YET: Bilingual = { en: "No match yet", hi: "अभी मैच नहीं" };
const MATCH_PREFIX: Bilingual = { en: "Match", hi: "मैच" };

const VOICE_SPEAKING: Bilingual = { en: "Coaching", hi: "बोल रहे हैं" };
const VOICE_IDLE: Bilingual = { en: "Voice on", hi: "आवाज़ चालू" };
const VOICE_MUTED: Bilingual = { en: "Voice off", hi: "आवाज़ बंद" };

const CAPTURE_BLOCKED: Readonly<Record<CaptureBlockReason, Bilingual>> = {
  none: { en: "", hi: "" },
  "session-paused": { en: "Camera paused", hi: "कैमरा रुका है" },
  "camera-warming": { en: "Camera starting", hi: "कैमरा शुरू हो रहा है" },
  "model-loading": { en: "Preparing pose detection", hi: "पोज़ डिटेक्शन तैयार हो रहा है" },
  "countdown-running": { en: "Countdown running", hi: "काउंटडाउन चल रहा है" },
  "capture-in-progress": { en: "Capture in progress", hi: "फोटो ली जा रही है" },
};

/**
 * Camera UX Part 2 — THE ONE-WORD ANSWER TO "AM I READY?".
 *
 * The rail's headline. It is deliberately one short word per state, because
 * it is read in peripheral vision while the user is holding a pose and cannot
 * comfortably read a sentence. The sentence lives in the coaching band; this
 * is the glanceable state label above it, and the two always descend from the
 * same semantic coaching state, so they can never disagree.
 */
const READINESS: Readonly<Record<CameraReadiness, Bilingual>> = {
  blocked: { en: "Getting ready", hi: "तैयार हो रहे हैं" },
  searching: { en: "Looking for you", hi: "आपको ढूंढ रहे हैं" },
  evaluating: { en: "Checking", hi: "देख रहे हैं" },
  adjusting: { en: "Almost there", hi: "बस थोड़ा और" },
  ready: { en: "Ready", hi: "तैयार" },
};

/**
 * Camera UX Part 3 — WHERE AM I, AND HOW DO I LEAVE?
 *
 * The pinned reference answered "what am I copying?" and nothing else. The
 * user who opened the wrong pose had no exit from the viewfinder except the
 * tab bar. These two lines turn that existing surface into the screen's
 * identity + escape hatch, in the coaching language, without adding a new
 * floating control to the frame.
 */
const SHOOTING_LABEL: Bilingual = { en: "Shooting", hi: "शूट कर रहे हैं" };
const CHANGE_POSE: Bilingual = { en: "Change pose", hi: "पोज़ बदलें" };

/**
 * CAMERA CONTROLS + BRIGHTNESS.
 *
 * Plain words only. The user is told "brighter", "darker" and "normal" — not
 * "exposure compensation", not "EV", not "gain". The one piece of engineering
 * truth that DOES reach them is `BRIGHTNESS_NOTE`: the adjustment lands on the
 * photograph they are about to take, because the camera foundation exposes no
 * sensor-exposure control and pretending otherwise would be a lie told in a
 * tooltip.
 */
const BRIGHTNESS_TITLE: Bilingual = { en: "Brightness", hi: "ब्राइटनेस" };
const BRIGHTNESS_NORMAL: Bilingual = { en: "Normal", hi: "सामान्य" };
const BRIGHTNESS_BRIGHTER: Bilingual = { en: "Brighter", hi: "ज़्यादा रोशनी" };
const BRIGHTNESS_DARKER: Bilingual = { en: "Darker", hi: "कम रोशनी" };
const BRIGHTNESS_RESET: Bilingual = { en: "Reset", hi: "रीसेट" };
const BRIGHTNESS_NOTE: Bilingual = {
  en: "Applied to your photo",
  hi: "आपकी फोटो पर लागू होगा",
};

/**
 * D1 — the SAME control, the two mechanisms it can carry, told apart in one
 * glance. When the native exposure bridge is live the control IS exposure:
 * the sensor's auto-exposure is biased and the viewfinder change is real, so
 * it is named and noted that way. When the bridge is absent (unpatched build,
 * simulator, unsupported camera module) the honest photograph-processing
 * fallback keeps its own name and its own note — never borrowing the word
 * "exposure" it cannot honour.
 */
const EXPOSURE_TITLE: Bilingual = { en: "Exposure", hi: "एक्सपोज़र" };
const EXPOSURE_NOTE: Bilingual = {
  en: "Adjusts the camera's exposure",
  hi: "कैमरे की एक्सपोज़र बदलता है",
};

/**
 * LOOKS — filter names, strength and the two honesty lines.
 *
 * Two sentences carry the whole truth of the feature and neither is optional:
 *
 *   `FILTER_NOTE`          the look is baked into the saved JPEG (it is — see
 *                          `captureColorMatrix` + `applyCaptureFraming`);
 *   `FILTER_PREVIEW_APPROX` the LIVE viewfinder can only approximate it, and
 *                          for B&W it cannot show it at all, because
 *                          expo-camera hands the app no preview frames.
 *
 * Saying the second one costs one small line of text and buys the user the
 * ability to trust the first one.
 */
const FILTER_TITLE: Bilingual = { en: "Look", hi: "लुक" };
const FILTER_NAMES: Readonly<Record<CameraFilterId, Bilingual>> = {
  original: { en: "Original", hi: "ओरिजिनल" },
  vivid: { en: "Vivid", hi: "विविड" },
  warm: { en: "Warm", hi: "वॉर्म" },
  cool: { en: "Cool", hi: "कूल" },
  bw: { en: "B&W", hi: "ब्लैक & व्हाइट" },
};
const FILTER_STRENGTH: Bilingual = { en: "Strength", hi: "स्ट्रेंथ" };
const FILTER_STRONGER: Bilingual = { en: "Stronger", hi: "और तेज़" };
const FILTER_SOFTER: Bilingual = { en: "Softer", hi: "और हल्का" };
const FILTER_RESET: Bilingual = { en: "Full", hi: "पूरा" };
const FILTER_NOTE: Bilingual = {
  en: "Saved into your photo",
  hi: "फोटो में सेव होगा",
};
const FILTER_PREVIEW_APPROX: Bilingual = {
  en: "Preview is approximate",
  hi: "प्रीव्यू अनुमानित है",
};
const FILTER_PREVIEW_UNAVAILABLE: Bilingual = {
  en: "Shown after the shot",
  hi: "फोटो के बाद दिखेगा",
};

const TORCH_TITLE: Bilingual = { en: "Light", hi: "लाइट" };
const TORCH_ON: Bilingual = { en: "On", hi: "चालू" };
const TORCH_OFF: Bilingual = { en: "Off", hi: "बंद" };
const TORCH_NO_FRONT: Bilingual = {
  en: "No light on the front camera",
  hi: "फ्रंट कैमरे पर लाइट नहीं है",
};
const TORCH_NOT_LIVE: Bilingual = {
  en: "Available once the camera is running",
  hi: "कैमरा चालू होने पर उपलब्ध",
};

const FLASH_TITLE: Bilingual = { en: "Flash", hi: "फ़्लैश" };
const FLASH_OFF: Bilingual = { en: "Off", hi: "बंद" };
const FLASH_AUTO: Bilingual = { en: "Automatic", hi: "ऑटोमैटिक" };
const FLASH_ON: Bilingual = { en: "On", hi: "चालू" };
const FLASH_TORCH_NOTE: Bilingual = {
  en: "Light is already on",
  hi: "लाइट पहले से चालू है",
};

/**
 * FRAMING — zoom, aspect ratio, grid, level.
 *
 * Same rule as brightness: plain words, and one honest engineering sentence
 * where the user would otherwise be misled. The zoom note says "digital"
 * because this camera foundation cannot select a physical lens, and the ratio
 * note says the crop reaches the saved photo because it does.
 */
const FRAMING_TITLE: Bilingual = { en: "Framing", hi: "फ्रेमिंग" };

const ZOOM_TITLE: Bilingual = { en: "Zoom", hi: "ज़ूम" };
const ZOOM_RESET: Bilingual = { en: "Back to 1×", hi: "1× पर वापस" };
const ZOOM_NOTE: Bilingual = { en: "Digital zoom", hi: "डिजिटल ज़ूम" };

const RATIO_TITLE: Bilingual = { en: "Photo shape", hi: "फोटो का आकार" };
const RATIO_FULL: Bilingual = { en: "Full", hi: "पूरा" };
const RATIO_SQUARE: Bilingual = { en: "Square", hi: "चौकोर" };
const RATIO_WIDE: Bilingual = { en: "Wide", hi: "चौड़ा" };
const RATIO_NOTE: Bilingual = {
  en: "Saved photo is cropped to this",
  hi: "फोटो इसी आकार में सेव होगी",
};

const GRID_TITLE: Bilingual = { en: "Grid", hi: "ग्रिड" };
const LEVEL_TITLE: Bilingual = { en: "Level", hi: "लेवल" };
const ON_LABEL: Bilingual = { en: "On", hi: "चालू" };
const OFF_LABEL: Bilingual = { en: "Off", hi: "बंद" };
const LEVEL_STRAIGHT: Bilingual = { en: "Straight", hi: "सीधा है" };
const LEVEL_TILT_SUFFIX: Bilingual = { en: "tilt", hi: "झुका है" };
const LEVEL_UNAVAILABLE: Bilingual = {
  en: "No motion sensor on this device",
  hi: "इस डिवाइस में मोशन सेंसर नहीं है",
};

const CAPTURE_FAILED: Bilingual = { en: "Couldn't take that shot", hi: "फोटो नहीं ली जा सकी" };
const CAPTURE_RETRY: Bilingual = { en: "Try again", hi: "फिर कोशिश करें" };
const CAPTURE_DISMISS: Bilingual = { en: "Dismiss", hi: "हटाएं" };

/** All camera capture-state copy, already resolved for one language. */
export interface CameraStatusCopy {
  readonly language: InstructionLanguage;
  readonly capturing: string;
  readonly processing: string;
  readonly paused: string;
  readonly pausedDetail: string;
  readonly holdAuto: string;
  readonly holdGesture: string;
  readonly noMatchYet: string;
  /** "Shooting" — the word above the pinned pose title. */
  readonly shooting: string;
  /** Action label on the pose-identity chip. */
  readonly changePose: string;
  /** Short label for the camera currently in use. */
  readonly facing: (facing: "front" | "back") => string;
  /** One glanceable word for the rail headline. */
  readonly readiness: (state: CameraReadiness) => string;
  /** "Match 82%" in the coaching language. */
  readonly formatMatch: (percent: number) => string;
  readonly voiceSpeaking: string;
  readonly voiceIdle: string;
  readonly voiceMuted: string;
  readonly captureFailed: string;
  readonly captureRetry: string;
  readonly captureDismiss: string;
  /** Why the shutter is disabled; empty string when it is enabled. */
  readonly captureBlocked: (reason: CaptureBlockReason) => string;
  /** One short line explaining what the countdown is for. */
  readonly countdownReason: (trigger: CaptureTrigger | null) => string;
  /**
   * VOLUME-BUTTON SHUTTER — spoken/announced only while the physical keys
   * are genuinely armed on this build. Never shown as a promise.
   */
  readonly volumeShutterArmed: string;
  /**
   * What the gesture gate is currently doing, in one glanceable line.
   * Empty string means "say nothing" — the correct output for idle/cooldown.
   */
  readonly gesturePhase: (phase: OpenPalmPhase) => string;

  /* ── camera controls & brightness ── */
  readonly brightnessTitle: string;
  /** "Normal" at the default detent, otherwise "+2 brighter" / "2 darker". */
  readonly brightnessValue: (level: number) => string;
  readonly brightnessBrighter: string;
  readonly brightnessDarker: string;
  readonly brightnessReset: string;
  /** The one honest sentence about WHERE the adjustment lands. */
  readonly brightnessNote: string;
  /**
   * D1 — what the control is CALLED under the mechanism currently carrying
   * it: "Exposure" while the sensor's auto-exposure is really biased,
   * "Brightness" on the photo-processing fallback. The two names are never
   * interchanged, so the user's vocabulary stays as honest as the pipeline.
   */
  readonly brightnessTitleFor: (mechanism: ExposureMechanism) => string;
  /**
   * D1 — the mechanism's one sentence of truth: the camera's exposure really
   * changes under the native seam; the adjustment is applied to the saved
   * photo under the fallback.
   */
  readonly brightnessNoteFor: (mechanism: ExposureMechanism) => string;

  /* ── looks (filters) & strength ── */
  /** Name of the strip: "Look", not "Filters" — one word, user language. */
  readonly filterTitle: string;
  /** "Original" / "Vivid" / … in the coaching language. */
  readonly filterName: (id: CameraFilterId) => string;
  /** "Vivid · 60%" for chips and screen readers; no badge at full strength. */
  readonly filterSummary: (id: CameraFilterId, intensity: number) => string;
  readonly filterStrengthTitle: string;
  /** "Strength 60%" — the number never travels alone. */
  readonly filterStrengthValue: (intensity: number) => string;
  readonly filterStronger: string;
  readonly filterSofter: string;
  /** The reset affordance: back to the full look, not back to Original. */
  readonly filterReset: string;
  /** Where the look actually lands: in the saved file. */
  readonly filterNote: string;
  /**
   * What the LIVE viewfinder can honestly claim for this look — empty string
   * when there is nothing to disclaim (Original).
   */
  readonly filterPreviewNote: (id: CameraFilterId) => string;

  readonly torchTitle: string;
  readonly torchValue: (on: boolean) => string;
  /** Why the light control is dimmed; empty string when it is usable. */
  readonly torchBlocked: (reason: TorchBlockedReason) => string;
  readonly flashTitle: string;
  readonly flashValue: (mode: FlashModeValue) => string;
  /** Shown on the flash control while the continuous light is already on. */
  readonly flashSupersededNote: string;

  /* ── framing: zoom, ratio, grid, level ── */
  /** Name of the one sheet that owns shape, grid and level. */
  readonly framingTitle: string;
  readonly zoomTitle: string;
  /** "1×" / "2.4×", already formatted for this camera's range. */
  readonly zoomValue: (multiplier: number, facing: CameraFacingId) => string;
  readonly zoomReset: string;
  /** The honest one-liner: this is a crop, not a lens. */
  readonly zoomNote: string;
  readonly ratioTitle: string;
  /** "Full" / "Square" / "Wide" — user concepts, not sensor jargon. */
  readonly ratioValue: (ratio: AspectRatioId) => string;
  /** Short badge used on the control itself: "4:3", "1:1", "16:9". */
  readonly ratioBadge: (ratio: AspectRatioId) => string;
  /** Where the chosen shape actually lands. */
  readonly ratioNote: string;
  readonly gridTitle: string;
  readonly levelTitle: string;
  readonly onOff: (on: boolean) => string;
  /** "Straight" when level, "3° tilt" when not. */
  readonly levelValue: (resolution: LevelResolution) => string;
  readonly levelUnavailable: string;
}

export function cameraStatusCopyFor(language: unknown): CameraStatusCopy {
  const resolved = resolveInstructionLanguage(language);
  return {
    language: resolved,
    capturing: say(CAPTURING, resolved),
    processing: say(PROCESSING, resolved),
    paused: say(PAUSED, resolved),
    pausedDetail: say(PAUSED_DETAIL, resolved),
    holdAuto: say(HOLD_AUTO, resolved),
    holdGesture: say(HOLD_GESTURE, resolved),
    noMatchYet: say(NO_MATCH_YET, resolved),
    shooting: say(SHOOTING_LABEL, resolved),
    changePose: say(CHANGE_POSE, resolved),
    facing: (facing) =>
      say(facing === "front" ? FACING_FRONT : FACING_REAR, resolved),
    readiness: (state) => say(READINESS[state] ?? READINESS.evaluating, resolved),
    formatMatch: (percent) => `${say(MATCH_PREFIX, resolved)} ${percent}%`,
    voiceSpeaking: say(VOICE_SPEAKING, resolved),
    voiceIdle: say(VOICE_IDLE, resolved),
    voiceMuted: say(VOICE_MUTED, resolved),
    captureFailed: say(CAPTURE_FAILED, resolved),
    captureRetry: say(CAPTURE_RETRY, resolved),
    captureDismiss: say(CAPTURE_DISMISS, resolved),
    captureBlocked: (reason) =>
      say(CAPTURE_BLOCKED[reason] ?? CAPTURE_BLOCKED.none, resolved),
    countdownReason: (trigger) =>
      say(COUNTDOWN_REASON[trigger ?? "manual"] ?? COUNTDOWN_REASON.manual, resolved),
    volumeShutterArmed: say(VOLUME_SHUTTER_ARMED, resolved),
    gesturePhase: (phase) => say(GESTURE_PHASE[phase] ?? GESTURE_PHASE.idle, resolved),

    brightnessTitle: say(BRIGHTNESS_TITLE, resolved),
    /* The number is never shown alone: "+2" answers "how much" but not "of
       what". Every readout carries the direction word with it. */
    brightnessValue: (level) => {
      const step = clampBrightness(level);
      if (step === 0) return say(BRIGHTNESS_NORMAL, resolved);
      const direction = say(
        step > 0 ? BRIGHTNESS_BRIGHTER : BRIGHTNESS_DARKER,
        resolved,
      );
      return `${direction} ${Math.abs(step)}`;
    },
    brightnessBrighter: say(BRIGHTNESS_BRIGHTER, resolved),
    brightnessDarker: say(BRIGHTNESS_DARKER, resolved),
    brightnessReset: say(BRIGHTNESS_RESET, resolved),
    brightnessNote: say(BRIGHTNESS_NOTE, resolved),
    brightnessTitleFor: (mechanism) =>
      say(mechanism === "native-exposure" ? EXPOSURE_TITLE : BRIGHTNESS_TITLE, resolved),
    brightnessNoteFor: (mechanism) =>
      say(mechanism === "native-exposure" ? EXPOSURE_NOTE : BRIGHTNESS_NOTE, resolved),

    filterTitle: say(FILTER_TITLE, resolved),
    filterName: (id) =>
      say(FILTER_NAMES[clampFilterId(id)] ?? FILTER_NAMES.original, resolved),
    filterSummary: (id, intensity) => {
      const filter = clampFilterId(id);
      const label = say(FILTER_NAMES[filter] ?? FILTER_NAMES.original, resolved);
      const badge = filterIntensityBadge(filter, intensity);
      return badge === null ? label : `${label} · ${badge}`;
    },
    filterStrengthTitle: say(FILTER_STRENGTH, resolved),
    filterStrengthValue: (intensity) =>
      `${say(FILTER_STRENGTH, resolved)} ${clampFilterIntensity(intensity)}%`,
    filterStronger: say(FILTER_STRONGER, resolved),
    filterSofter: say(FILTER_SOFTER, resolved),
    filterReset: say(FILTER_RESET, resolved),
    filterNote: say(FILTER_NOTE, resolved),
    /* The disclaimer is per-LOOK because the limitation is per-look: a warm
       wash really does resemble warm, and no overlay on earth resembles B&W. */
    filterPreviewNote: (id) => {
      const fidelity = viewfinderFidelity(id);
      if (fidelity === "exact") return "";
      return say(
        fidelity === "not-representable"
          ? FILTER_PREVIEW_UNAVAILABLE
          : FILTER_PREVIEW_APPROX,
        resolved,
      );
    },

    torchTitle: say(TORCH_TITLE, resolved),
    torchValue: (on) => say(on ? TORCH_ON : TORCH_OFF, resolved),
    torchBlocked: (reason) => {
      if (reason === "front-camera") return say(TORCH_NO_FRONT, resolved);
      if (reason === "session-not-live") return say(TORCH_NOT_LIVE, resolved);
      return "";
    },
    flashTitle: say(FLASH_TITLE, resolved),
    flashValue: (mode) =>
      say(
        mode === "on" ? FLASH_ON : mode === "auto" ? FLASH_AUTO : FLASH_OFF,
        resolved,
      ),
    flashSupersededNote: say(FLASH_TORCH_NOTE, resolved),

    framingTitle: say(FRAMING_TITLE, resolved),
    zoomTitle: say(ZOOM_TITLE, resolved),
    zoomValue: (multiplier, facing) => formatZoom(multiplier, facing),
    zoomReset: say(ZOOM_RESET, resolved),
    zoomNote: say(ZOOM_NOTE, resolved),
    ratioTitle: say(RATIO_TITLE, resolved),
    ratioValue: (ratio) =>
      say(
        ratio === "1:1" ? RATIO_SQUARE : ratio === "16:9" ? RATIO_WIDE : RATIO_FULL,
        resolved,
      ),
    ratioBadge: (ratio) => ratio,
    ratioNote: say(RATIO_NOTE, resolved),
    gridTitle: say(GRID_TITLE, resolved),
    levelTitle: say(LEVEL_TITLE, resolved),
    onOff: (on) => say(on ? ON_LABEL : OFF_LABEL, resolved),
    /* Degrees are the one number here the user can act on ("drop the right
       edge a bit"), and "Straight" is the reward for acting on it. */
    levelValue: (resolution) =>
      resolution.isLevel
        ? say(LEVEL_STRAIGHT, resolved)
        : `${resolution.tiltDeg}\u00b0 ${say(LEVEL_TILT_SUFFIX, resolved)}`,
    levelUnavailable: say(LEVEL_UNAVAILABLE, resolved),
  };
}
