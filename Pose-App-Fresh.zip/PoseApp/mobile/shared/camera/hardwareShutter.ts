/**
 * shared/camera/hardwareShutter.ts — VOLUME-BUTTON SHUTTER: THE POLICY.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero clock of
 * its own. Everything decidable about the physical-button shutter WITHOUT a
 * device lives here so it can be proved in the root test suite.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * WHY A POLICY MODULE AND NOT "JUST ANOTHER LISTENER"
 *
 * The camera screen already has THREE ways to take a photograph — the manual
 * shutter, the auto match hold and the five-finger open palm — and they are
 * already arbitrated by ONE coordinator
 * (`shared/camera/intelligentCaptureController`). A fourth input must not
 * become a fourth code path: a hardware key is an INPUT, not a capture
 * mechanism. It therefore ends up in exactly the same place the on-screen
 * shutter ends up (`requestManual`) and inherits the same global lock, the
 * same 3 s debounce, the same countdown, the same processing/save/retake.
 *
 * What this module owns, and nothing else:
 *
 *   1. CAPABILITY — is a real hardware-key source available on this build at
 *      all, and if not, WHY not (honest, reportable, never faked).
 *   2. ARMING — may the app consume the volume keys *right now*? This is the
 *      single most important question in the feature, because a consumed
 *      volume key is a volume key the user did NOT get to use for volume.
 *   3. EDGE HYGIENE — key auto-repeat, double-fire and the "both keys at
 *      once" case, resolved before anything reaches the capture controller.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * THE VOLUME-CONFLICT RULE (the deliberate part)
 *
 * A camera app that silently steals the volume keys forever is a bug. A
 * camera app that changes the media volume while the user expected a photo
 * is a worse bug. So the contract is narrow and stated out loud:
 *
 *   · the keys are consumed ONLY while the live viewfinder owns the screen
 *     AND the shutter itself would accept a tap;
 *   · while consumed, system volume does NOT change — no slider, no HUD, no
 *     "it went up by one anyway" (that is why this feature intercepts the
 *     key event instead of observing the volume value; see the platform
 *     notes in mobile/modules/hardware-shutter);
 *   · the instant the screen is blocked (countdown, capture, processing,
 *     model loading, paused session, editor, preview, any other tab) the
 *     keys are released back to the system and behave exactly as they do in
 *     every other app;
 *   · the user can turn the whole thing off in Settings, and OFF means the
 *     keys are never touched.
 *
 * A countdown that is already running is deliberately NOT cancellable with a
 * volume key: the key is released so the user can still change their volume,
 * and the countdown remains cancellable the way it always was.
 */

/** The physical keys this feature is willing to answer to. */
export type HardwareShutterKey = "volume-up" | "volume-down";

export const HARDWARE_SHUTTER_KEYS: readonly HardwareShutterKey[] = [
  "volume-up",
  "volume-down",
];

/**
 * Why a build can or cannot deliver hardware-key capture.
 *
 * These are REPORTED, not hidden. A user on a platform without support sees
 * nothing promising them the feature, and the log line says which of these
 * applied.
 */
export type HardwareShutterCapability =
  | "available"
  /** Native module present but the platform refuses the capability. */
  | "unsupported-platform"
  /** The JS is here, the native side is not: Expo Go / stale dev client. */
  | "missing-native-module"
  /** Browser/React-Native-Web target: no hardware keys exist to intercept. */
  | "unsupported-web";

export interface HardwareShutterCapabilityInput {
  /** 'android' | 'ios' | 'web' | anything else a host may report. */
  readonly platform: string;
  /** The native module resolved (a development build that includes it). */
  readonly nativeModulePresent: boolean;
  /** The native module's own answer to "can I do this here?". */
  readonly nativeReportsSupported: boolean;
}

/**
 * Resolves capability. Total, pure, and pessimistic by construction: every
 * unknown lands on a *reason*, never on "available".
 */
export function resolveHardwareShutterCapability(
  input: HardwareShutterCapabilityInput,
): HardwareShutterCapability {
  if (input.platform === "web") return "unsupported-web";
  if (!input.nativeModulePresent) return "missing-native-module";
  if (!input.nativeReportsSupported) return "unsupported-platform";
  return "available";
}

/** Why the keys are not being consumed at this instant. */
export type HardwareShutterBlockReason =
  | "none"
  | "capability"
  | "setting-off"
  | "session-not-live"
  | "capture-unavailable";

export interface HardwareShutterArmingInput {
  readonly capability: HardwareShutterCapability;
  /** The persisted user preference (Settings → Volume key shutter). */
  readonly enabledByUser: boolean;
  /** Focused AND foregrounded AND the viewfinder is mounted. */
  readonly sessionLive: boolean;
  /**
   * `CameraPresentation.captureEnabled` — the EXISTING resolver's answer.
   * Reused verbatim so the physical button and the on-screen button can
   * never disagree about whether a photo is possible.
   */
  readonly captureEnabled: boolean;
}

export interface HardwareShutterArming {
  readonly armed: boolean;
  readonly reason: HardwareShutterBlockReason;
}

/**
 * The arming decision, in priority order. The order is the explanation:
 * a capability we do not have outranks a preference, which outranks a
 * session state, which outranks the momentary shutter state.
 */
export function resolveHardwareShutterArming(
  input: HardwareShutterArmingInput,
): HardwareShutterArming {
  if (input.capability !== "available") {
    return { armed: false, reason: "capability" };
  }
  if (!input.enabledByUser) return { armed: false, reason: "setting-off" };
  if (!input.sessionLive) return { armed: false, reason: "session-not-live" };
  if (!input.captureEnabled) {
    return { armed: false, reason: "capture-unavailable" };
  }
  return { armed: true, reason: "none" };
}

export const HARDWARE_SHUTTER_TIMING = {
  /**
   * Minimum gap between two ACCEPTED presses at the input edge.
   *
   * This is not the capture debounce — the capture controller still owns the
   * authoritative 3 s global lock. This shorter guard exists because a key
   * press is physically noisy: Android delivers auto-repeat while the key is
   * held, and a user pressing "twice to be sure" would otherwise queue a
   * second request the controller then has to refuse. Refusing it here keeps
   * the log honest and the feedback immediate.
   */
  minIntervalMs: 700,
} as const;

export interface HardwareShutterPressInput {
  readonly nowMs: number;
  readonly key: HardwareShutterKey;
  /** Android auto-repeat while the key is held down. Never a new intent. */
  readonly repeat: boolean;
  /** The arming decision at the moment the key arrived. */
  readonly armed: boolean;
}

export type HardwareShutterPressVerdict =
  | "accepted"
  | "rejected-not-armed"
  | "rejected-repeat"
  | "rejected-debounce";

/**
 * The input-edge gate for physical presses.
 *
 * Deliberately a tiny stateful object rather than a second controller: it
 * decides only whether a KEY EVENT counts as a deliberate press. Whether
 * that press becomes a photograph is, and stays, the capture controller's
 * decision.
 */
export class HardwareShutterGate {
  private lastAcceptedAt = Number.NEGATIVE_INFINITY;

  evaluate(input: HardwareShutterPressInput): HardwareShutterPressVerdict {
    if (!input.armed) return "rejected-not-armed";
    if (input.repeat) return "rejected-repeat";
    if (
      input.nowMs - this.lastAcceptedAt <
      HARDWARE_SHUTTER_TIMING.minIntervalMs
    ) {
      return "rejected-debounce";
    }
    this.lastAcceptedAt = input.nowMs;
    return "accepted";
  }

  /** Called when the screen disarms, so a later session starts clean. */
  reset(): void {
    this.lastAcceptedAt = Number.NEGATIVE_INFINITY;
  }
}

/**
 * One line for the log / the docs / the Settings subtitle, describing what
 * this build can actually do. Written as a fact, never as a promise.
 */
export function hardwareShutterCapabilityNote(
  capability: HardwareShutterCapability,
): string {
  switch (capability) {
    case "available":
      return "Volume keys take the photo while the viewfinder is live.";
    case "unsupported-platform":
      return "Not available on this platform — the system reserves the volume keys.";
    case "missing-native-module":
      return "Needs a development build that includes the hardware-shutter module.";
    case "unsupported-web":
      return "Browser preview has no hardware keys to read.";
    default:
      return "Unavailable.";
  }
}
