/**
 * Unit 18 - deterministic intelligent-capture state machine.
 *
 * Auto match, open-palm gesture, and manual shutter all pass through one
 * coordinator. That global lock is what prevents duplicate countdowns when
 * multiple triggers become valid on the same 15fps landmark frame.
 */
/**
 * WHO ASKED FOR THIS PHOTOGRAPH.
 *
 * `hardware` (Volume-button shutter) is a fourth *input*, not a fourth
 * capture mechanism: it is routed through `requestManual()` exactly like the
 * on-screen shutter, so it inherits this controller's global lock, its 3 s
 * debounce, the countdown, the processing overlay and the save/retake flow
 * without any of them being duplicated. The trigger name exists only so the
 * countdown can tell the user WHY it started, and so the logs stay honest.
 */
export type CaptureTrigger = 'manual' | 'auto' | 'gesture' | 'hardware';

export const INTELLIGENT_CAPTURE_TIMING = {
  autoHoldMs: 2_000,
  globalDebounceMs: 3_000,
  countdownSeconds: 3,
  voiceDebounceMs: 3_000,
} as const;

/** Working defaults until Unit 20 exposes persisted user preferences. */
export const INTELLIGENT_CAPTURE_DEFAULTS = {
  autoEnabled: true,
  gestureEnabled: true,
  voiceEnabled: true,
  autoThreshold: 90,
  countdownSeconds: 3,
} as const;

export interface IntelligentCaptureSnapshot {
  readonly autoProgress: number;
  readonly gestureProgress: number;
  readonly trigger: CaptureTrigger | null;
  readonly locked: boolean;
}

export interface IntelligentCaptureInput {
  readonly nowMs: number;
  readonly matchPercent: number | null;
  readonly autoThreshold: number;
  /**
   * GESTURE CAPTURE, POST-HARDENING.
   *
   * This used to be `openPalm: boolean` — a raw per-frame "a palm is visible"
   * flag that this controller then held for 600 ms before firing. Two things
   * were wrong with that: the flag was produced by a pose-only heuristic that
   * could not tell a fist from a palm, and 600 ms of a flag that is true for
   * any raised hand is not a deliberate command.
   *
   * Temporal confirmation now lives in `shared/ml/openPalmGate.ts`, which
   * owns hold duration, frame count, stillness, drop-out tolerance, cooldown
   * and the release-before-repeat rule. The controller consumes only its
   * OUTPUT: a single-frame confirmation edge plus a display progress. The
   * controller's own job is unchanged — arbitrating between triggers and
   * holding the global capture lock.
   */
  readonly gestureConfirmed: boolean;
  /** 0..1 from the gate; display only, never a trigger condition. */
  readonly gestureProgress: number;
  readonly autoEnabled: boolean;
  readonly gestureEnabled: boolean;
}

function progress(startedAt: number | null, now: number, duration: number): number {
  if (startedAt === null) return 0;
  return Math.max(0, Math.min(1, (now - startedAt) / duration));
}

export class IntelligentCaptureController {
  private autoStartedAt: number | null = null;
  private lastTriggerAt = Number.NEGATIVE_INFINITY;
  private locked = false;

  update(input: IntelligentCaptureInput): IntelligentCaptureSnapshot {
    if (this.locked) {
      return { autoProgress: 0, gestureProgress: 0, trigger: null, locked: true };
    }

    const autoQualified =
      input.autoEnabled &&
      input.matchPercent !== null &&
      input.matchPercent >= input.autoThreshold;
    this.autoStartedAt = autoQualified ? (this.autoStartedAt ?? input.nowMs) : null;

    /* The gate already did the holding. `gestureConfirmed` is an EDGE: true on
       exactly one frame per deliberate presentation, and impossible again
       until the palm has been released and re-presented. */
    const gestureConfirmed = input.gestureEnabled && input.gestureConfirmed;
    const gestureProgress = input.gestureEnabled
      ? Math.max(0, Math.min(1, input.gestureProgress))
      : 0;

    const autoProgress = progress(
      this.autoStartedAt,
      input.nowMs,
      INTELLIGENT_CAPTURE_TIMING.autoHoldMs,
    );

    if (input.nowMs - this.lastTriggerAt < INTELLIGENT_CAPTURE_TIMING.globalDebounceMs) {
      return { autoProgress, gestureProgress, trigger: null, locked: false };
    }

    // Gesture is an explicit user command, so it wins if both complete on the
    // same frame; otherwise the stable-match auto trigger fires.
    const trigger: CaptureTrigger | null =
      gestureConfirmed ? 'gesture' : autoProgress >= 1 ? 'auto' : null;
    if (trigger !== null) {
      this.lastTriggerAt = input.nowMs;
      this.locked = true;
      this.autoStartedAt = null;
    }
    return { autoProgress, gestureProgress, trigger, locked: this.locked };
  }

  requestManual(nowMs: number): boolean {
    if (this.locked) return false;
    if (nowMs - this.lastTriggerAt < INTELLIGENT_CAPTURE_TIMING.globalDebounceMs) {
      return false;
    }
    this.lastTriggerAt = nowMs;
    this.locked = true;
    this.autoStartedAt = null;
    return true;
  }

  /** Unlock after a cancelled countdown; captured sessions navigate away. */
  cancel(): void {
    this.locked = false;
    this.autoStartedAt = null;
  }

  reset(): void {
    this.autoStartedAt = null;
    this.lastTriggerAt = Number.NEGATIVE_INFINITY;
    this.locked = false;
  }
}
