/**
 * shared/camera/photoEditing.ts — POST-CAPTURE EDITING (crop · rotate · enhance).
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero colours.
 *
 * WHY THIS MODULE EXISTS (what the audit of the existing pipeline found)
 *
 * The capture pipeline was already honest and already good:
 *
 *   · `core/camera/photoBrightness.applyCaptureFraming` decodes the captured
 *     JPEG ONCE into an offscreen Skia surface, applies ONE colour matrix
 *     (look ∘ strength ∘ capture-brightness) and ONE centre crop (the chosen
 *     aspect), re-encodes, and hands a NEW file to the preview screen;
 *   · `gallery/data/datasources/galleryLocalDatasource` copies that file into
 *     Documents/PoseAssist/<user>/ and stores only METADATA in MMKV (id, pose,
 *     path, look, timestamp) — no image bytes are ever put in key-value
 *     storage, and that invariant is preserved here;
 *   · `expo-media-library` separately copies the durable file into the system
 *     gallery; `expo-sharing` shares the same path.
 *
 * What did NOT exist anywhere: any way to change a photograph AFTER the
 * shutter. There was no crop, no rotate, no adjustment, and no edit entry
 * point in either preview screen — `aspectCropRect` is a fixed centre crop
 * decided before the shot, not an interaction. A photo that came out tilted,
 * loosely framed or a stop dark could only be retaken.
 *
 * So this module adds the SMALL, complete post-capture edit the app was
 * missing, and nothing more:
 *
 *   ROTATE   quarter turns only (90° / 180° / 270°) — lossless geometry,
 *            exactly what a tilted-by-a-quarter phone produces.
 *   CROP     a rectangle the user drags, optionally locked to a common ratio.
 *   ENHANCE  one tap Original → Enhanced, plus four honest sliders
 *            (brightness, contrast, saturation, warmth).
 *
 * DELIBERATE NON-GOALS: no curves, no LUTs, no healing, no layers, no text,
 * no stickers, no perspective, no arbitrary-angle straightening, no local
 * adjustments. This is the "fix the shot" step of a camera app, not a
 * darkroom, and the pose-coaching product always outranks it.
 *
 * ── THE BRIGHTNESS BOUNDARY (explicitly asked for, explicitly kept) ───────
 *
 * `shared/camera/cameraControls` owns the CAPTURE-TIME brightness detent
 * (−3…+3), which is read once at the shutter and baked into the file by the
 * capture pipeline. The `brightness` in THIS module is a different thing: a
 * POST-CAPTURE edit of an existing photograph, on its own −100…+100 scale,
 * with its own constants, its own neutral value and its own store. Nothing
 * here reads or writes the camera session's brightness, and nothing in the
 * camera session reads this. Two systems, two names, no shared state — the
 * only thing they have in common is the matrix algebra they both borrow from
 * `cameraFilters`, which is pure maths.
 *
 * ── ORDER OF OPERATIONS (fixed, and the renderer must obey it) ────────────
 *
 *   1. ROTATE  the source by whole quarter turns;
 *   2. CROP    a rectangle expressed in the ROTATED frame (this is what the
 *              user dragged, so the crop must be stored in that space);
 *   3. COLOUR  one composed matrix applied while the pixels are drawn.
 *
 * Because (3) is a colour filter on the single draw that (1) and (2) already
 * require, the whole edit still costs ONE decode, ONE draw and ONE encode.
 */

import {
  IDENTITY_COLOR_MATRIX,
  colorMatrixIsIdentity,
  composeColorMatrices,
  contrastColorMatrix,
  saturationColorMatrix,
  temperatureColorMatrix,
  type ColorMatrix,
} from "./cameraFilters";

/* ═══════════════════════════════ 1. ROTATION ══════════════════════════════ */

/**
 * Quarter turns clockwise. Only 90° steps exist, for two reasons that are
 * both about honesty rather than laziness:
 *
 *   · a quarter turn is a pure index remap — no resampling, no interpolation,
 *     no softening, no black corners, so the edited photo is pixel-for-pixel
 *     the original photo in a different order;
 *   · arbitrary-angle straightening always crops and always resamples, which
 *     is a materially different (and much larger) feature than "this came out
 *     sideways".
 */
export type QuarterTurns = 0 | 1 | 2 | 3;

export const QUARTER_TURN_VALUES: readonly QuarterTurns[] = [0, 1, 2, 3];

export function clampQuarterTurns(value: unknown): QuarterTurns {
  if (typeof value !== "number" || !Number.isFinite(value)) return 0;
  const wrapped = ((Math.round(value) % 4) + 4) % 4;
  return wrapped as QuarterTurns;
}

/** `direction` is +1 for clockwise, −1 for counter-clockwise. */
export function rotateQuarterTurns(
  current: unknown,
  direction: number,
): QuarterTurns {
  const step = direction < 0 ? -1 : 1;
  return clampQuarterTurns(clampQuarterTurns(current) + step);
}

export function rotationDegrees(turns: unknown): number {
  return clampQuarterTurns(turns) * 90;
}

export function rotationIsIdentity(turns: unknown): boolean {
  return clampQuarterTurns(turns) === 0;
}

/** Odd turns swap the axes; even turns do not. */
export function rotatedSize(
  width: number,
  height: number,
  turns: unknown,
): { readonly width: number; readonly height: number } {
  const swap = clampQuarterTurns(turns) % 2 === 1;
  return swap ? { width: height, height: width } : { width, height };
}

/** "90° right" / "Upright" — used for the control's accessibility value. */
export function rotationLabel(turns: unknown): string {
  const degrees = rotationDegrees(turns);
  return degrees === 0 ? "Upright" : `${degrees}\u00B0`;
}

/* ═══════════════════════════════ 2. CROP ══════════════════════════════════ */

/**
 * The crop is stored NORMALISED (0…1) against the ROTATED frame, never in
 * pixels. Three concrete benefits:
 *
 *   · it survives the preview being laid out at any size, on any density;
 *   · it survives a device that reports pre-rotation capture dimensions,
 *     because the renderer resolves it against the DECODED image;
 *   · it is trivially serialisable and trivially testable.
 */
export interface NormalizedRect {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

export const FULL_FRAME_CROP: NormalizedRect = { x: 0, y: 0, width: 1, height: 1 };

/**
 * A crop smaller than a tenth of the frame is almost never intended and is
 * impossible to place accurately with a thumb, so the interaction refuses to
 * go below it rather than letting the user produce a 40-pixel photograph.
 */
export const CROP_MIN_FRACTION = 0.1;

const CROP_EPSILON = 1e-4;

export type CropAspectId = "free" | "original" | "1:1" | "4:5" | "3:4" | "16:9";

/**
 * The ratio list is short on purpose: free-form, the photo's own shape, the
 * square, the two portrait crops people actually post, and the widescreen
 * one. Anything else is a preset nobody asked for.
 */
export const CROP_ASPECT_IDS: readonly CropAspectId[] = [
  "free",
  "original",
  "1:1",
  "4:5",
  "3:4",
  "16:9",
];

export const CROP_ASPECT_DEFAULT: CropAspectId = "free";

export function clampCropAspectId(value: unknown): CropAspectId {
  return typeof value === "string" &&
    (CROP_ASPECT_IDS as readonly string[]).includes(value)
    ? (value as CropAspectId)
    : CROP_ASPECT_DEFAULT;
}

export function cropAspectLabel(id: unknown): string {
  switch (clampCropAspectId(id)) {
    case "free":
      return "Free";
    case "original":
      return "Original";
    default:
      return clampCropAspectId(id);
  }
}

/**
 * width / height for the requested ratio, resolved against the frame that is
 * being cropped. `free` returns null (unconstrained); `original` returns the
 * frame's own ratio, which is what "keep the shape, just tighten it" means.
 */
export function cropAspectValue(
  id: unknown,
  frameWidth: number,
  frameHeight: number,
): number | null {
  const aspect = clampCropAspectId(id);
  if (aspect === "free") return null;
  if (aspect === "original") {
    if (!(frameWidth > 0) || !(frameHeight > 0)) return null;
    return frameWidth / frameHeight;
  }
  switch (aspect) {
    case "1:1":
      return 1;
    case "4:5":
      return 4 / 5;
    case "3:4":
      return 3 / 4;
    case "16:9":
      return 16 / 9;
    default:
      return null;
  }
}

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

/** Totality: any garbage in, a usable rectangle inside the frame out. */
export function clampNormalizedRect(rect: unknown): NormalizedRect {
  const source = (rect ?? {}) as Partial<NormalizedRect>;
  let width = Number.isFinite(source.width) ? Number(source.width) : 1;
  let height = Number.isFinite(source.height) ? Number(source.height) : 1;
  width = Math.max(CROP_MIN_FRACTION, Math.min(1, width));
  height = Math.max(CROP_MIN_FRACTION, Math.min(1, height));
  const x = Math.max(0, Math.min(1 - width, clamp01(Number(source.x ?? 0))));
  const y = Math.max(0, Math.min(1 - height, clamp01(Number(source.y ?? 0))));
  return { x, y, width, height };
}

export function cropIsFullFrame(rect: unknown): boolean {
  const box = clampNormalizedRect(rect);
  return (
    box.x < CROP_EPSILON &&
    box.y < CROP_EPSILON &&
    box.width > 1 - CROP_EPSILON &&
    box.height > 1 - CROP_EPSILON
  );
}

/**
 * The largest centred rectangle of the requested ratio that fits the frame.
 * Used when a ratio chip is tapped: the user asked for a shape, so they get
 * the most photograph that shape can hold, centred, rather than whatever
 * their previous free-form drag happened to leave behind.
 */
export function cropRectForAspect(
  id: unknown,
  frameWidth: number,
  frameHeight: number,
): NormalizedRect {
  const ratio = cropAspectValue(id, frameWidth, frameHeight);
  if (ratio === null || !(frameWidth > 0) || !(frameHeight > 0)) {
    return FULL_FRAME_CROP;
  }
  const frameRatio = frameWidth / frameHeight;
  if (Math.abs(frameRatio - ratio) < CROP_EPSILON) return FULL_FRAME_CROP;
  if (ratio > frameRatio) {
    /* Wider than the frame → full width, shorter height. */
    const height = frameRatio / ratio;
    return clampNormalizedRect({ x: 0, y: (1 - height) / 2, width: 1, height });
  }
  const width = ratio / frameRatio;
  return clampNormalizedRect({ x: (1 - width) / 2, y: 0, width, height: 1 });
}

/**
 * Carries a crop through a quarter turn so rotating AFTER cropping keeps the
 * same piece of the photograph under the box instead of silently throwing the
 * user's framing away. `direction` is +1 clockwise, −1 counter-clockwise.
 *
 * Clockwise: (x, y, w, h) → (1 − y − h, x, h, w).
 */
export function rotateCropRect(rect: unknown, direction: number): NormalizedRect {
  const box = clampNormalizedRect(rect);
  return direction < 0
    ? clampNormalizedRect({
        x: box.y,
        y: 1 - box.x - box.width,
        width: box.height,
        height: box.width,
      })
    : clampNormalizedRect({
        x: 1 - box.y - box.height,
        y: box.x,
        width: box.height,
        height: box.width,
      });
}

export type CropHandle =
  | "move"
  | "topLeft"
  | "topRight"
  | "bottomLeft"
  | "bottomRight";

export const CROP_HANDLES: readonly CropHandle[] = [
  "topLeft",
  "topRight",
  "bottomLeft",
  "bottomRight",
];

/**
 * ONE function for every crop gesture, so the drag maths cannot differ
 * between corners (the classic source of "the bottom-right handle behaves
 * strangely" bugs) and so it is testable without a touch screen.
 *
 * `dx`/`dy` are NORMALISED deltas in the rotated frame — the UI divides the
 * raw pixel delta by the displayed image size, which is the only place a
 * layout number is allowed to enter the model.
 *
 * When `aspect` is non-null the opposite corner is the anchor and the height
 * follows the width, so a locked ratio can never be broken by a drag.
 */
export function applyCropGesture(
  start: NormalizedRect,
  handle: CropHandle,
  dx: number,
  dy: number,
  aspect: number | null,
  frameAspect: number,
): NormalizedRect {
  const base = clampNormalizedRect(start);
  const moveX = Number.isFinite(dx) ? dx : 0;
  const moveY = Number.isFinite(dy) ? dy : 0;

  if (handle === "move") {
    const x = Math.max(0, Math.min(1 - base.width, base.x + moveX));
    const y = Math.max(0, Math.min(1 - base.height, base.y + moveY));
    return { x, y, width: base.width, height: base.height };
  }

  const right = base.x + base.width;
  const bottom = base.y + base.height;
  const anchorX = handle === "topLeft" || handle === "bottomLeft" ? right : base.x;
  const anchorY = handle === "topLeft" || handle === "topRight" ? bottom : base.y;
  const movingLeft = handle === "topLeft" || handle === "bottomLeft";
  const movingTop = handle === "topLeft" || handle === "topRight";

  let edgeX = clamp01((movingLeft ? base.x : right) + moveX);
  let edgeY = clamp01((movingTop ? base.y : bottom) + moveY);

  let width = Math.abs(edgeX - anchorX);
  let height = Math.abs(edgeY - anchorY);

  if (aspect !== null && aspect > 0 && frameAspect > 0) {
    /* The ratio is expressed in IMAGE pixels, but x and y here are fractions
       of different edge lengths, so the normalised ratio has to be divided by
       the frame's own aspect. Without this correction a "1:1" crop on a 4:3
       photo would come out rectangular — the bug this line exists to stop. */
    const normalizedRatio = aspect / frameAspect;
    /* Follow the larger gesture so the corner tracks the thumb. */
    if (width / Math.max(normalizedRatio, CROP_EPSILON) >= height) {
      height = width / normalizedRatio;
    } else {
      width = height * normalizedRatio;
    }
    width = Math.min(width, movingLeft ? anchorX : 1 - anchorX);
    height = Math.min(height, movingTop ? anchorY : 1 - anchorY);
    if (width / Math.max(normalizedRatio, CROP_EPSILON) > height) {
      width = height * normalizedRatio;
    } else {
      height = width / normalizedRatio;
    }
  }

  width = Math.max(CROP_MIN_FRACTION, width);
  height = Math.max(CROP_MIN_FRACTION, height);
  if (aspect !== null && aspect > 0 && frameAspect > 0) {
    const normalizedRatio = aspect / frameAspect;
    if (width / normalizedRatio < height) width = height * normalizedRatio;
    else height = width / normalizedRatio;
  }

  edgeX = movingLeft ? anchorX - width : anchorX + width;
  edgeY = movingTop ? anchorY - height : anchorY + height;

  const x = Math.min(anchorX, edgeX);
  const y = Math.min(anchorY, edgeY);
  return clampNormalizedRect({ x, y, width, height });
}

export interface PixelRect {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

/**
 * Normalised crop → integer pixel rectangle inside the rotated frame. Rounded
 * (never floored) so a full-frame crop of an odd-sized photo is still the
 * whole photo, and guarded so the result is always at least 1×1.
 */
export function cropRectToPixels(
  rect: unknown,
  frameWidth: number,
  frameHeight: number,
): PixelRect {
  const box = clampNormalizedRect(rect);
  const width = Math.max(1, Math.round(box.width * frameWidth));
  const height = Math.max(1, Math.round(box.height * frameHeight));
  const x = Math.max(0, Math.min(frameWidth - width, Math.round(box.x * frameWidth)));
  const y = Math.max(0, Math.min(frameHeight - height, Math.round(box.y * frameHeight)));
  return { x, y, width, height };
}

/* ═════════════════════════════ 3. ENHANCE ═════════════════════════════════ */

/**
 * Four adjustments, each −100 … +100 in steps of 5, 0 = the photograph as it
 * was taken. Percent because it is a number a person can say out loud and
 * return to; stepped because a thumb cannot reproduce 63 % and because
 * "back to zero" must be an exact landing.
 *
 * NOTE the deliberate name collision with nothing: these constants are
 * PHOTO_EDIT_*, the live camera's are BRIGHTNESS_* in cameraControls. The two
 * systems never share a value.
 */
export const PHOTO_EDIT_ADJUST_MIN = -100;
export const PHOTO_EDIT_ADJUST_MAX = 100;
export const PHOTO_EDIT_ADJUST_STEP = 5;

export type PhotoAdjustKey = "brightness" | "contrast" | "saturation" | "warmth";

export const PHOTO_ADJUST_KEYS: readonly PhotoAdjustKey[] = [
  "brightness",
  "contrast",
  "saturation",
  "warmth",
];

export interface PhotoEnhance {
  /** Post-capture exposure of an EXISTING file. Not the camera's detent. */
  readonly brightness: number;
  readonly contrast: number;
  readonly saturation: number;
  /** Red/blue tilt. Positive = warmer, negative = cooler. */
  readonly warmth: number;
}

export const ENHANCE_NEUTRAL: PhotoEnhance = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  warmth: 0,
};

export function clampAdjustValue(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return 0;
  const stepped =
    Math.round(value / PHOTO_EDIT_ADJUST_STEP) * PHOTO_EDIT_ADJUST_STEP;
  return Math.max(PHOTO_EDIT_ADJUST_MIN, Math.min(PHOTO_EDIT_ADJUST_MAX, stepped));
}

export function clampEnhance(value: unknown): PhotoEnhance {
  const source = (value ?? {}) as Partial<PhotoEnhance>;
  return {
    brightness: clampAdjustValue(source.brightness),
    contrast: clampAdjustValue(source.contrast),
    saturation: clampAdjustValue(source.saturation),
    warmth: clampAdjustValue(source.warmth),
  };
}

export function enhanceIsNeutral(value: unknown): boolean {
  const enhance = clampEnhance(value);
  return PHOTO_ADJUST_KEYS.every((key) => enhance[key] === 0);
}

/**
 * THE ONE-TAP ENHANCE.
 *
 * The question asked was whether a simple Original → Enhanced switch is worth
 * it. It is, and this is why: a phone photograph of a person posing indoors
 * is, far more often than not, very slightly flat and very slightly cool. A
 * small lift of contrast and saturation with a touch of warmth is the edit
 * almost everyone makes by hand, so offering it as one tap saves four slider
 * journeys and is instantly reversible by tapping Original.
 *
 * The values are deliberately modest — this must look like a better version
 * of the user's photo, never like a filter was applied behind their back, and
 * it must not clip skin tones. It is also EXACTLY equivalent to setting the
 * four sliders to these numbers, so the switch is a shortcut, not a hidden
 * second engine: tapping Enhanced then opening the sliders shows precisely
 * these positions.
 */
export const AUTO_ENHANCE: PhotoEnhance = {
  brightness: 10,
  contrast: 15,
  saturation: 20,
  warmth: 10,
};

export function isAutoEnhance(value: unknown): boolean {
  const enhance = clampEnhance(value);
  return PHOTO_ADJUST_KEYS.every((key) => enhance[key] === AUTO_ENHANCE[key]);
}

/* ── the adjustment → matrix mapping, stated as constants ─────────────── */

/** ±100 brightness = ×1.5 / ×0.5 exposure. */
const BRIGHTNESS_SPAN = 0.5;
/** ±100 contrast = ×1.5 / ×0.5 around mid-grey. */
const CONTRAST_SPAN = 0.5;
/** ±100 saturation = ×1.8 / ×0.2 (never a hard clip to grey). */
const SATURATION_SPAN = 0.8;
/** ±100 warmth = the full ±1 tilt of the shared temperature matrix (±12 %). */
const WARMTH_SPAN = 1;

export function adjustBrightnessGain(value: unknown): number {
  return 1 + (clampAdjustValue(value) / 100) * BRIGHTNESS_SPAN;
}

export function adjustContrastFactor(value: unknown): number {
  return 1 + (clampAdjustValue(value) / 100) * CONTRAST_SPAN;
}

export function adjustSaturationFactor(value: unknown): number {
  return 1 + (clampAdjustValue(value) / 100) * SATURATION_SPAN;
}

export function adjustTemperatureTilt(value: unknown): number {
  return (clampAdjustValue(value) / 100) * WARMTH_SPAN;
}

/**
 * ONE matrix for the whole enhancement.
 *
 * Order: saturation (what the sensor saw) → warmth → contrast → brightness,
 * i.e. tonal decisions last, which is the order a photographer would describe
 * and the same convention the capture pipeline already uses (look first,
 * brightness last). Because every step is linear the four collapse into
 * twenty numbers and the edit costs no extra pass over the pixels.
 */
export function enhanceColorMatrix(value: unknown): ColorMatrix {
  const enhance = clampEnhance(value);
  let matrix = IDENTITY_COLOR_MATRIX;
  if (enhance.saturation !== 0) {
    matrix = composeColorMatrices(
      matrix,
      saturationColorMatrix(adjustSaturationFactor(enhance.saturation)),
    );
  }
  if (enhance.warmth !== 0) {
    matrix = composeColorMatrices(
      matrix,
      temperatureColorMatrix(adjustTemperatureTilt(enhance.warmth)),
    );
  }
  if (enhance.contrast !== 0) {
    matrix = composeColorMatrices(
      matrix,
      contrastColorMatrix(adjustContrastFactor(enhance.contrast)),
    );
  }
  if (enhance.brightness !== 0) {
    const gain = adjustBrightnessGain(enhance.brightness);
    matrix = composeColorMatrices(matrix, [
      gain, 0, 0, 0, 0,
      0, gain, 0, 0, 0,
      0, 0, gain, 0, 0,
      0, 0, 0, 1, 0,
    ]);
  }
  return matrix;
}

/** Slider caption: "+15" / "0" / "−20", with a real minus sign. */
export function adjustBadge(value: unknown): string {
  const amount = clampAdjustValue(value);
  if (amount === 0) return "0";
  return amount > 0 ? `+${amount}` : `\u2212${Math.abs(amount)}`;
}

export function adjustLabel(key: PhotoAdjustKey): string {
  switch (key) {
    case "brightness":
      return "Brightness";
    case "contrast":
      return "Contrast";
    case "saturation":
      return "Saturation";
    case "warmth":
      return "Warmth";
    default:
      return key;
  }
}

/* ════════════════════════════ 4. THE EDIT ════════════════════════════════ */

export interface PhotoEdit {
  readonly rotation: QuarterTurns;
  /** Normalised against the ROTATED frame. */
  readonly crop: NormalizedRect;
  readonly enhance: PhotoEnhance;
}

export const PHOTO_EDIT_NONE: PhotoEdit = {
  rotation: 0,
  crop: FULL_FRAME_CROP,
  enhance: ENHANCE_NEUTRAL,
};

export function clampPhotoEdit(value: unknown): PhotoEdit {
  const source = (value ?? {}) as Partial<PhotoEdit>;
  return {
    rotation: clampQuarterTurns(source.rotation),
    crop: clampNormalizedRect(source.crop),
    enhance: clampEnhance(source.enhance),
  };
}

/**
 * True when applying the edit would not change a single pixel. The renderer
 * uses it to return the ORIGINAL FILE UNTOUCHED — no decode, no re-encode, no
 * generational JPEG loss, no wasted milliseconds — and the UI uses it to keep
 * "Apply" disabled so a user cannot silently recompress a photo for nothing.
 */
export function photoEditIsIdentity(value: unknown): boolean {
  const edit = clampPhotoEdit(value);
  return (
    rotationIsIdentity(edit.rotation) &&
    cropIsFullFrame(edit.crop) &&
    colorMatrixIsIdentity(enhanceColorMatrix(edit.enhance))
  );
}

/** Human summary for logs, snackbars and accessibility: "Crop · 90° · Enhanced". */
export function describePhotoEdit(value: unknown): string {
  const edit = clampPhotoEdit(value);
  const parts: string[] = [];
  if (!cropIsFullFrame(edit.crop)) parts.push("Crop");
  if (!rotationIsIdentity(edit.rotation)) parts.push(rotationLabel(edit.rotation));
  if (!enhanceIsNeutral(edit.enhance)) {
    parts.push(isAutoEnhance(edit.enhance) ? "Enhanced" : "Adjusted");
  }
  return parts.length === 0 ? "No changes" : parts.join(" \u00B7 ");
}

/* ═══════════════════════ 5. GEOMETRY RESOLUTION ══════════════════════════ */

/**
 * Everything the renderer needs, computed from the DECODED source size.
 *
 * The renderer is forbidden from doing its own geometry: if the maths lived
 * next to the Skia calls it could not be tested without a GPU, and the
 * browser mirror would inevitably grow a second, subtly different copy.
 */
export interface PhotoEditGeometry {
  readonly sourceWidth: number;
  readonly sourceHeight: number;
  readonly rotation: QuarterTurns;
  /** Size of the frame AFTER rotation, before cropping. */
  readonly rotatedWidth: number;
  readonly rotatedHeight: number;
  /** Crop in ROTATED pixel space — this is the output rectangle. */
  readonly crop: PixelRect;
  readonly outputWidth: number;
  readonly outputHeight: number;
  readonly geometryIsIdentity: boolean;
  readonly colorIsIdentity: boolean;
  readonly isIdentity: boolean;
  readonly matrix: ColorMatrix;
}

export function resolvePhotoEditGeometry(
  edit: unknown,
  sourceWidth: number,
  sourceHeight: number,
): PhotoEditGeometry {
  const model = clampPhotoEdit(edit);
  const width = Number.isFinite(sourceWidth) && sourceWidth > 0 ? Math.round(sourceWidth) : 1;
  const height =
    Number.isFinite(sourceHeight) && sourceHeight > 0 ? Math.round(sourceHeight) : 1;
  const rotated = rotatedSize(width, height, model.rotation);
  const crop = cropRectToPixels(model.crop, rotated.width, rotated.height);
  const matrix = enhanceColorMatrix(model.enhance);
  const colorIsIdentity = colorMatrixIsIdentity(matrix);
  const geometryIsIdentity =
    rotationIsIdentity(model.rotation) &&
    crop.x === 0 &&
    crop.y === 0 &&
    crop.width === rotated.width &&
    crop.height === rotated.height;
  return {
    sourceWidth: width,
    sourceHeight: height,
    rotation: model.rotation,
    rotatedWidth: rotated.width,
    rotatedHeight: rotated.height,
    crop,
    outputWidth: crop.width,
    outputHeight: crop.height,
    geometryIsIdentity,
    colorIsIdentity,
    isIdentity: geometryIsIdentity && colorIsIdentity,
    matrix,
  };
}

/**
 * The canvas transform that maps the SOURCE image into the OUTPUT surface —
 * one translate and one rotation, expressed as data so the device renderer
 * (Skia) and the browser mirror (2D context) can both consume it and cannot
 * drift apart. Both engines use the same convention: translate first in code,
 * then rotate, then draw the image at the origin.
 *
 *   turns 0 → (−cropX,            −cropY)                    ,   0°
 *   turns 1 → (−cropX + srcH,     −cropY)                    ,  90°
 *   turns 2 → (−cropX + srcW,     −cropY + srcH)             , 180°
 *   turns 3 → (−cropX,            −cropY + srcW)             , 270°
 */
export interface EditDrawTransform {
  readonly translateX: number;
  readonly translateY: number;
  readonly rotateDegrees: number;
}

export function photoEditDrawTransform(
  geometry: PhotoEditGeometry,
): EditDrawTransform {
  const { crop, rotation, sourceWidth, sourceHeight } = geometry;
  switch (rotation) {
    case 1:
      return {
        translateX: sourceHeight - crop.x,
        translateY: -crop.y,
        rotateDegrees: 90,
      };
    case 2:
      return {
        translateX: sourceWidth - crop.x,
        translateY: sourceHeight - crop.y,
        rotateDegrees: 180,
      };
    case 3:
      return {
        translateX: -crop.x,
        translateY: sourceWidth - crop.y,
        rotateDegrees: 270,
      };
    default:
      return { translateX: -crop.x, translateY: -crop.y, rotateDegrees: 0 };
  }
}

/* ═══════════════════════ 6. OUTPUT / FILE POLICY ═════════════════════════ */

/**
 * ENCODING POLICY, stated once and shared by every renderer.
 *
 * An edit is by definition applied to an ALREADY ENCODED file, so this is a
 * second JPEG generation and the quality number is a real decision, not a
 * default:
 *
 *   · 95 (not the capture pipeline's 92) because generational loss compounds
 *     and the visible cost of the extra three points is a few percent of file
 *     size, while the visible cost of a second 92 is mush in the shadows;
 *   · JPEG, not HEIC/WebP, because every downstream consumer in this app was
 *     built around `image/jpeg` — `expo-sharing` passes `mimeType: image/jpeg`
 *     and `UTI: public.jpeg`, the gallery writes `<id>.jpg`, and MediaLibrary
 *     is handed a `.jpg`. Changing container here would silently break share
 *     targets on both platforms for no user-visible gain. (An HEIC capture on
 *     iOS is decoded fine; only the EDITED output is normalised to JPEG, and
 *     only because it is being re-encoded anyway.)
 *   · NO RESIZE. The output is exactly the cropped pixels — a crop is already
 *     a downscale in file terms, and resampling a photo the user did not ask
 *     to resize is destroying their data to save bytes nobody counted.
 */
export const PHOTO_EDIT_JPEG_QUALITY = 95;

/** Cache filenames carry the edit so a stale file can never masquerade. */
export function editedFileName(edit: unknown, now: number): string {
  const model = clampPhotoEdit(edit);
  const rotationPart = `r${model.rotation}`;
  const cropPart = cropIsFullFrame(model.crop)
    ? "full"
    : `c${Math.round(model.crop.x * 100)}x${Math.round(model.crop.y * 100)}` +
      `w${Math.round(model.crop.width * 100)}h${Math.round(model.crop.height * 100)}`;
  const enhancePart = enhanceIsNeutral(model.enhance)
    ? "plain"
    : `e${model.enhance.brightness}_${model.enhance.contrast}_` +
      `${model.enhance.saturation}_${model.enhance.warmth}`;
  const stamp = Number.isFinite(now) ? Math.round(now) : 0;
  return `poseassist-edit-${rotationPart}-${cropPart}-${enhancePart}-${stamp}.jpg`;
}

/** True for the temporary files this feature creates — used by the sweeper. */
export function isEditTempFileName(name: unknown): boolean {
  return typeof name === "string" && name.startsWith("poseassist-edit-");
}
