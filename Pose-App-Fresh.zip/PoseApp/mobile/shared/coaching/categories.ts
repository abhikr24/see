/**
 * shared/coaching/categories.ts — Unit 30: measurement → coaching category.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * ONE mapping table, derived from the ONE copy table
 * (`JOINT_GUIDANCE_RULES` in shared/ml/guidanceGenerator.ts) so the spoken
 * category and the on-screen directive can never drift apart. Nothing here
 * measures, compares or thresholds anything: it translates an already-decided
 * (measurementId, direction) pair into a semantic coaching category.
 *
 * REACHABILITY TRACE (audited, not assumed) — see CATEGORY_COVERAGE below.
 */
import {
  jointDirectiveFor,
  JOINT_GUIDANCE_RULES,
} from "../ml/guidanceGenerator";
import { MATCH_JOINTS } from "../ml/poseLandmarks";
import {
  VOICE_INSTRUCTION_CATEGORIES,
  type VoiceInstructionCategory,
} from "../constants/poseInstructions";
import type { CorrectionDirection } from "../ml/analysis/types";

/**
 * Resolves the coaching category for a correction.
 *
 *   direction 'increase' ⇒ live angle is SMALLER than the reference
 *                          ⇒ the rule's `liveLessThanRef` copy
 *   direction 'decrease' ⇒ live angle is LARGER than the reference
 *                          ⇒ the rule's `liveGreaterThanRef` copy
 *
 * Returns null for an unknown measurement or a directionless correction —
 * the caller must then stay silent rather than invent a category.
 */
export function coachingCategoryFor(
  measurementId: string,
  direction: CorrectionDirection,
): VoiceInstructionCategory | null {
  /* Unit 32: resolved by THE one directive resolver, so the spoken category
     and the on-screen directive are literally the same table lookup. */
  return jointDirectiveFor(measurementId, direction)?.voiceCategory ?? null;
}

/** How a phrase-bank category relates to the shipped analysis engine. */
export type CategoryReachability =
  /** Produced today by a live joint correction. */
  | "reachable-correction"
  /** Produced today by the stable-perfect coaching state. */
  | "reachable-perfect"
  /** Produced today by the capture announcement (not a pose correction). */
  | "reachable-capture"
  /**
   * Authored copy with NO producer in the current engine: the measurement
   * set has no head/neck/torso-orientation measurement yet. Kept on purpose
   * for the planned measurement expansion — must not be described as
   * functional coaching today.
   */
  | "reserved-no-measurement"
  /**
   * Unit 32: authored copy that a measurement DOES exist for, but which no
   * rule points at any more because the category could not express the
   * engine's correction direction. Retained (never deleted) and explicitly
   * not claimed as live coaching.
   */
  | "reserved-superseded";

export interface CategoryCoverageEntry {
  readonly category: VoiceInstructionCategory;
  readonly reachability: CategoryReachability;
  /** Measurement ids that can currently produce it (empty when reserved). */
  readonly producers: readonly string[];
  readonly note: string;
}

function correctionProducers(): Map<VoiceInstructionCategory, string[]> {
  const map = new Map<VoiceInstructionCategory, string[]>();
  for (const joint of MATCH_JOINTS) {
    const rule = JOINT_GUIDANCE_RULES[joint.key];
    if (rule === undefined) continue;
    for (const directive of [rule.liveLessThanRef, rule.liveGreaterThanRef]) {
      const existing = map.get(directive.voiceCategory);
      if (existing === undefined) {
        map.set(directive.voiceCategory, [joint.key]);
      } else if (!existing.includes(joint.key)) {
        existing.push(joint.key);
      }
    }
  }
  return map;
}

/**
 * Unit 32 — categories a measurement exists for, but which are no longer
 * produced because their pool could not carry the correction DIRECTION.
 * `leg_left`/`leg_right` mix "straighten" and "bend" lines in one pool, so
 * the knee rules now point at leg_*_straighten / leg_*_bend instead. The copy
 * is kept (it is valid Hindi/English studio copy) but must never be presented
 * as reachable coaching.
 */
const SUPERSEDED_CATEGORIES: Readonly<
  Partial<Record<VoiceInstructionCategory, string>>
> = {
  leg_left:
    "Side-only knee copy that mixes straighten AND bend lines; superseded " +
    "by leg_left_straighten / leg_left_bend (Unit 32). Retained, unproduced.",
  leg_right:
    "Side-only knee copy that mixes straighten AND bend lines; superseded " +
    "by leg_right_straighten / leg_right_bend (Unit 32). Retained, unproduced.",
  /* Unit 33 (Part 4.2): the elbow rules used to borrow these LATERAL
     "slide the hand left/right" pools for an elbow straighten/bend decision —
     text unrelated to the correction. No lateral-hand measurement exists, so
     nothing produces them today. */
  hand_left:
    "Lateral 'move the hand left' copy. The elbow rules now speak through " +
    "hand_left_straighten / hand_left_bend (Unit 33); no lateral-hand " +
    "measurement exists. Retained, unproduced.",
  hand_right:
    "Lateral 'move the hand right' copy. The elbow rules now speak through " +
    "hand_right_straighten / hand_right_bend (Unit 33); no lateral-hand " +
    "measurement exists. Retained, unproduced.",
  /* Unit 33: stance-width copy borrowed by the hip (torso↔thigh) rules. */
  leg_open:
    "Stance-WIDTH copy ('open the stance'). The hip rules now speak through " +
    "leg_*_forward (Unit 33); no stance-width measurement exists. Retained, " +
    "unproduced.",
  leg_close:
    "Stance-WIDTH copy ('feet closer'). The hip rules now speak through " +
    "leg_*_back (Unit 33); no stance-width measurement exists. Retained, " +
    "unproduced.",
};

/**
 * Unit 33 — reachable categories whose copy deliberately does NOT name the
 * body side, because two measurements (left/right shoulder) share one pool.
 * The line stays TRUE for either side ("hand up a little"), it is simply
 * less specific; documented here instead of being quietly assumed.
 */
export const SIDE_AGNOSTIC_CATEGORIES: readonly VoiceInstructionCategory[] = [
  "hand_up",
  "hand_down",
];

/**
 * The audited trace: every phrase-bank category, classified against what the
 * engine can actually emit. Computed from the live tables (not a hand-written
 * list) so it can never go stale, and asserted by the unit tests.
 */
export const CATEGORY_COVERAGE: readonly CategoryCoverageEntry[] = (() => {
  const producers = correctionProducers();
  return VOICE_INSTRUCTION_CATEGORIES.map((category): CategoryCoverageEntry => {
    const from = producers.get(category);
    if (from !== undefined && from.length > 0) {
      return {
        category,
        reachability: "reachable-correction",
        producers: [...from],
        note:
          from.length > 1
            ? "Emitted when one of these joint measurements wins the priority " +
              "ranking; the copy is deliberately side-agnostic and stays true " +
              "for either side."
            : "Emitted when this joint measurement wins the priority ranking.",
      };
    }
    if (category === "final_pose_good") {
      return {
        category,
        reachability: "reachable-perfect",
        producers: [],
        note: "Emitted once per stable PERFECT episode (transition-aware).",
      };
    }
    if (category === "photo_clicking") {
      return {
        category,
        reachability: "reachable-capture",
        producers: [],
        note: "Capture announcement — spoken by the capture flow, not by pose analysis.",
      };
    }
    const supersededNote = SUPERSEDED_CATEGORIES[category];
    if (supersededNote !== undefined) {
      return {
        category,
        reachability: "reserved-superseded",
        producers: [],
        note: supersededNote,
      };
    }
    return {
      category,
      reachability: "reserved-no-measurement",
      producers: [],
      note:
        "No head/neck/torso-orientation measurement exists in the current " +
        "engine registry; copy is retained for the planned measurement set.",
    };
  });
})();

/** Categories the coaching pipeline can actually reach today. */
export const REACHABLE_CATEGORIES: readonly VoiceInstructionCategory[] =
  CATEGORY_COVERAGE.filter((entry) =>
    entry.reachability.startsWith("reachable-"),
  ).map((entry) => entry.category);
