/**
 * shared/coaching/coachingState.ts — Unit 30: analysis → semantic coaching.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * Translation ONLY. This module re-decides nothing:
 *   · which correction is dominant  → already decided by the engine's
 *     priority ranking + temporal stabilizer;
 *   · how bad it is                 → already decided by the engine's
 *     severity ladder (carried verbatim);
 *   · whether the frame is judgeable → already decided by the engine's
 *     availability/confidence rules.
 *
 * What it adds is exactly one thing the language layer needs and the engine
 * has no business knowing: the coaching CATEGORY and the phrase INTENSITY
 * implied by the engine's severity.
 */
import {
  ANALYSIS_STATE_EVALUATING,
  ANALYSIS_STATE_PERFECT,
  type ComparisonSeverity,
  type PoseAnalysisDecision,
} from "../ml/analysis";
import type { PhraseIntensity } from "../constants/poseInstructions";
import { coachingCategoryFor } from "./categories";
import type { CoachingState } from "./types";

/**
 * Severity → phrase intensity. The ONLY place this mapping exists; the TTS
 * layer receives the result and never derives it.
 *   'minor'            → gentle nudge
 *   'major'            → firmer cue
 *   'within-tolerance' → gentle (a correction held by hysteresis inside the
 *                        tolerance band is, by definition, a small one)
 */
export function intensityForSeverity(
  severity: ComparisonSeverity | null,
): PhraseIntensity {
  return severity === "major" ? "firm" : "gentle";
}

/** The silent, non-speakable state used for evaluating/unavailable frames. */
function silentState(
  decision: PoseAnalysisDecision,
  kind: "evaluating" | "unavailable",
): CoachingState {
  const reason = decision.unavailable?.reason ?? null;
  return {
    kind,
    token:
      kind === "evaluating"
        ? ANALYSIS_STATE_EVALUATING
        : `UNAVAILABLE:${reason ?? "unknown"}`,
    category: null,
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0,
    stableFrames: decision.temporal.framesHeld,
    heldByHysteresis: decision.temporal.heldByHysteresis,
    unavailableReason: kind === "unavailable" ? reason : null,
    speakable: false,
  };
}

/**
 * Maps ONE semantic engine decision onto the semantic coaching state.
 * Total function: every decision kind produces a state, and only
 * correction/perfect are marked speakable.
 */
export function decisionToCoachingState(
  decision: PoseAnalysisDecision,
): CoachingState {
  if (decision.kind === "unavailable") return silentState(decision, "unavailable");
  if (decision.kind === "evaluating") return silentState(decision, "evaluating");

  if (decision.kind === "perfect") {
    return {
      kind: "perfect",
      token: ANALYSIS_STATE_PERFECT,
      category: "final_pose_good",
      measurementId: null,
      direction: "none",
      severity: null,
      intensity: "gentle",
      /* Perfect is a whole-frame verdict: its belief is the weakest usable
         comparison the engine actually accepted, not a per-joint number. */
      confidence: frameConfidence(decision),
      stableFrames: decision.temporal.framesHeld,
      heldByHysteresis: decision.temporal.heldByHysteresis,
      unavailableReason: null,
      speakable: true,
    };
  }

  const correction = decision.correction;
  const category =
    correction === null
      ? null
      : coachingCategoryFor(correction.measurementId, correction.direction);

  if (correction === null || category === null) {
    /* A correction the coaching vocabulary cannot name is NOT coachable:
       stay silent instead of speaking a wrong or generic body part. */
    return {
      kind: "evaluating",
      token: ANALYSIS_STATE_EVALUATING,
      category: null,
      measurementId: correction?.measurementId ?? null,
      direction: correction?.direction ?? "none",
      severity: correction?.severity ?? null,
      intensity: intensityForSeverity(correction?.severity ?? null),
      confidence: correction?.confidence ?? 0,
      stableFrames: decision.temporal.framesHeld,
      heldByHysteresis: decision.temporal.heldByHysteresis,
      unavailableReason: null,
      speakable: false,
    };
  }

  return {
    kind: "correction",
    token: decision.state,
    category,
    measurementId: correction.measurementId,
    direction: correction.direction,
    severity: correction.severity,
    intensity: intensityForSeverity(correction.severity),
    confidence: correction.confidence,
    stableFrames: decision.temporal.framesHeld,
    heldByHysteresis: decision.temporal.heldByHysteresis,
    unavailableReason: null,
    speakable: true,
  };
}

/** Weakest usable comparison confidence this frame (1 when none is usable). */
function frameConfidence(decision: PoseAnalysisDecision): number {
  let weakest: number | null = null;
  for (const comparison of decision.frame.comparisons) {
    if (!comparison.valid) continue;
    if (weakest === null || comparison.confidence < weakest) {
      weakest = comparison.confidence;
    }
  }
  return weakest ?? 1;
}
