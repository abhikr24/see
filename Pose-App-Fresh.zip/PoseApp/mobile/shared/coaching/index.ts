/**
 * shared/coaching/index.ts — Unit 30 barrel: THE SEMANTIC COACHING BOUNDARY.
 *
 *   pose analysis → semantic coaching state → language → phrase → TTS
 *
 * Everything exported here is pure, deterministic and platform-neutral:
 * no LLM, no network, no RN/DOM, no Supabase, no speech engine. The mobile
 * TTS service and the preview mirror both consume exactly these functions,
 * which is why coaching behaves identically on both.
 */
export * from "./types";
export * from "./categories";
export * from "./coachingState";
export * from "./phraseSelection";
export * from "./speechPlanner";
