/**
 * shared/coaching/phraseSelection.ts — Unit 30/33: LANGUAGE + PHRASE SELECTION.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * THE SELECTION HIERARCHY (in this exact order, never random-first):
 *
 *   semantic state → category → language → severity/intensity → valid pool
 *                  → non-repeated variation
 *
 * Unit 33 hardening:
 *   · The pool is resolved from the SEMANTIC STATE first; the random source
 *     only ever chooses between equally valid lines INSIDE that pool, so
 *     randomness cannot change what the coach means.
 *   · The category is re-validated against the phrase bank, so an unknown or
 *     stale token can never fall through to some other category's copy.
 *   · A missing severity pool is reported (`fallback: 'gentle-pool'`), never
 *     silently swapped for unrelated text; a missing category pool returns
 *     null and the caller stays silent.
 *
 * The mathematical logic is NOT duplicated per language: one semantic state
 * feeds both banks, and the language only chooses which curated pool the
 * variation is drawn from. Adding a third language would add a bank, not a
 * second copy of any geometry.
 */
import {
  isVoiceInstructionCategory,
  pickInstruction,
  type InstructionLanguage,
  type PhraseIntensity,
  type PhrasePoolFallback,
  type VoiceInstructionCategory,
} from "../constants/poseInstructions";
import { resolveInstructionLanguage } from "../voice/locales";
import type { CoachingState } from "./types";

export interface CoachingPhrase {
  readonly text: string;
  readonly category: VoiceInstructionCategory;
  readonly language: InstructionLanguage;
  /**
   * The tier actually spoken. Equal to `requestedIntensity` unless the
   * category has no firm pool, in which case the fallback is reported below
   * rather than hidden.
   */
  readonly intensity: PhraseIntensity;
  /** The tier the engine's severity asked for (never derived here). */
  readonly requestedIntensity: PhraseIntensity;
  /** 'exact' | 'gentle-pool' — how the tier request was satisfied. */
  readonly fallback: PhrasePoolFallback;
  /** How many curated variations the chosen pool holds (diagnostics/tests). */
  readonly poolSize: number;
  /** Index inside that pool (deterministic tests + logging). */
  readonly poolIndex: number;
  /** True when an immediate repeat was detected and stepped past. */
  readonly avoidedRepeat: boolean;
  /** The semantic token this line was selected FOR — provable linkage. */
  readonly token: string;
}

export interface PhraseSelectionOptions {
  /** Injectable 0..1 source so selection can be made deterministic in tests. */
  readonly random?: () => number;
}

/**
 * Selects the spoken line for a semantic coaching state.
 * Returns null for any non-speakable state — the caller cannot turn
 * "nothing to say" into speech.
 */
export function selectCoachingPhrase(
  state: CoachingState,
  language: InstructionLanguage,
  options?: PhraseSelectionOptions,
): CoachingPhrase | null {
  /* 1. SEMANTIC GATE — only states the engine marked speakable may produce
        speech, and only through the category the engine chose. */
  if (!state.speakable || state.category === null) return null;
  if (state.kind !== "correction" && state.kind !== "perfect") return null;

  /* 2. CATEGORY GATE — the category must exist in the phrase bank. An
        unknown id is silence, never someone else's sentence. */
  const category = state.category;
  if (!isVoiceInstructionCategory(category)) return null;

  /* 3. LANGUAGE GATE (Unit 36; contract finalized 4.6-repair) — the language
        argument ultimately comes from a PERSISTED preference, so it is
        untrusted at runtime however well it is typed. Resolving it HERE, at
        the semantic → language boundary, means every consumer (device TTS,
        preview mirror, tests) degrades to the canonical default language
        identically instead of each caller remembering to normalize first.
        The returned phrase reports the language actually spoken, never the
        one that was asked for. */
  const resolvedLanguage = resolveInstructionLanguage(language);

  /* 4. SEVERITY/INTENSITY + 5. VARIATION, in that order. The intensity was
        mapped ONCE from the engine severity upstream. */
  const pick = pickInstruction(category, resolvedLanguage, {
    intensity: state.intensity,
    ...(options?.random !== undefined ? { random: options.random } : {}),
  });
  if (pick === null || pick.text.length === 0) return null;

  return {
    text: pick.text,
    category: pick.category,
    language: pick.language,
    intensity: pick.resolvedIntensity,
    requestedIntensity: pick.requestedIntensity,
    fallback: pick.fallback,
    poolSize: pick.poolSize,
    poolIndex: pick.index,
    avoidedRepeat: pick.avoidedRepeat,
    token: state.token,
  };
}
