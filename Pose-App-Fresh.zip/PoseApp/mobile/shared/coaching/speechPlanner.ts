/**
 * shared/coaching/speechPlanner.ts — SPEECH TIMING (decision only).
 * Unit 30 introduced it; Unit 34 (Part 4.3) hardened it.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network/React.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * THE ONE QUESTION THIS FILE ANSWERS
 *
 *   "Should the coach speak NOW?"
 *
 * It never answers "what should the coach say?" — that is
 * `shared/coaching/phraseSelection.ts`. The two are deliberately separate
 * modules with separate inputs and separate tests; neither calls the other.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * RESPONSIBILITY SPLIT (do not blur this line)
 *
 *   POSE ENGINE  (shared/ml/analysis)
 *     angles · thresholds · severity · priority · persistence · hysteresis
 *     → decides whether a coaching state is STABLE ENOUGH TO BE REAL.
 *
 *   THIS FILE
 *     semantic tokens · clock · speech-in-flight
 *     → decides whether that already-stabilized state is spoken NOW.
 *
 *   There is no angle, landmark, joint threshold, error magnitude or
 *   severity rule below. `CoachingState.stableFrames` is READ as a fact the
 *   engine established; it is never recomputed, smoothed or second-guessed.
 *   `tests/coaching/semanticContract.test.ts` asserts this statically.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * CADENCE MODEL (state-aware, not one arbitrary global timer)
 *
 *   The shipped app used to gate every utterance behind a single fixed 3 s
 *   debounce (`INTELLIGENT_CAPTURE_TIMING.voiceDebounceMs`). That one number
 *   had to be both "fast enough to react" and "slow enough not to babble",
 *   so it was neither. It is no longer on the coaching path. Instead each
 *   situation gets the gate that actually fits it:
 *
 *   · minGapMs             floor between ANY two coaching lines (latency
 *                          guard — a genuinely new instruction is not held
 *                          hostage by the repeat timer).
 *   · repeatIntervalMs     the SAME correction, still uncorrected, is
 *                          re-stated at a patient interval — reminded, not
 *                          nagged.
 *   · alternationCooldownMs a token that was ALREADY spoken recently cannot
 *                          be re-announced just because another state
 *                          briefly took over. This is what makes
 *                          A → B → A stable instead of a ping-pong chant.
 *   · transitionBackoffMs  the FIRST change of instruction is prompt; each
 *                          further change in an unbroken run of changes
 *                          gets more air, up to a cap. A user who is
 *                          genuinely being walked through fixes stays
 *                          responsive; a coach caught in an A/B/A/B loop
 *                          calms down instead of narrating the loop.
 *   · interruptGraceMs     while the device is mid-utterance, a different
 *                          state may barge in only after the current line
 *                          has had this much air — no chopped half-words.
 *   · silenceGraceMs       a SUSTAINED unjudgeable gap (body left frame,
 *                          reference unusable) clears cadence memory so the
 *                          next real state is prompt; a single churn frame
 *                          does NOT, so flicker cannot reset the gates.
 *   · minStableFrames /    a floor beneath the engine's own persistence.
 *     perfectMinStableFrames
 *
 * ─────────────────────────────────────────────────────────────────────────
 * PERFECT IS TRANSITION-AWARE
 *
 *   correction → stable correction → user adjusts → stable perfect
 *     → ONE positive confirmation → then quiet for as long as perfect holds.
 *
 *   `PERFECT, PERFECT, PERFECT, …` can never produce a second line: the
 *   episode flag is cleared only by a *speakable, non-perfect* state or by a
 *   sustained silence gap — never by one evaluating/unavailable flicker.
 *   There is no separate motivational engine; "perfect" is just another
 *   semantic state with its own re-entry rule.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * OVERLAP POLICY: INTERRUPT-AND-REPLACE, NEVER QUEUE
 *
 *   `expo-speech` has no safe application-level queue here (utterances would
 *   pile up at 15 fps and the coach would narrate the past), so the planner
 *   deliberately authorizes at most ONE line at a time and the TTS layer
 *   stops the current utterance before starting the replacement. A new state
 *   that arrives mid-utterance is either (a) too early → suppressed with
 *   reason `speaking`, or (b) past `interruptGraceMs` → it replaces the line
 *   cleanly. Two utterances can never overlap.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * PLAN → EXECUTE IS A TWO-PARTY CONTRACT (`revert`)
 *
 *   `plan()` COMMITS its cadence memory as soon as it authorizes a line,
 *   because the very next ML frame (~66 ms later) must already see "just
 *   spoken". But the executor downstream can still legitimately produce
 *   nothing: the phrase layer answers silence for an unknown/retired
 *   category (Unit 33 D4), or the utterance is superseded before it starts.
 *   Without a way back, the planner would be carrying a line that was never
 *   heard — and for PERFECT that is user-visible, because the single
 *   positive response of the whole episode would be silently spent.
 *
 *   `revert(plan)` undoes EXACTLY that one authorization, and only while it
 *   is still the most recent one. It is not a second cadence rule and it
 *   cannot be used to replay or to bypass a gate.
 */
import type { CoachingState } from "./types";

export interface SpeechCadenceConfig {
  /** Minimum time between two spoken lines, including after a state change. */
  readonly minGapMs: number;
  /** How long the SAME correction waits before it is repeated. */
  readonly repeatIntervalMs: number;
  /**
   * How long a token that was already spoken must wait before it may be
   * announced again as a "new" state. Damps A → B → A oscillation without
   * pretending the returning state is not real.
   */
  readonly alternationCooldownMs: number;
  /**
   * Added to `minGapMs` for each consecutive change of instruction beyond
   * the first, up to `maxTransitionBackoffSteps`. Pure timing: it counts
   * how often the COACH has changed its mind, never how noisy the pose is.
   */
  readonly transitionBackoffMs: number;
  /** Cap on the back-off above, so the coach can never fall permanently mute. */
  readonly maxTransitionBackoffSteps: number;
  /**
   * While the device is mid-utterance, how much air the current line must
   * have had before a DIFFERENT state is allowed to replace it.
   */
  readonly interruptGraceMs: number;
  /**
   * How long "nothing can be judged" must persist before cadence memory is
   * cleared. Shorter than a human pause, longer than a dropped frame.
   */
  readonly silenceGraceMs: number;
  /** Engine frames a state must have been held before it may be spoken. */
  readonly minStableFrames: number;
  /** Extra frames of stability required before a positive PERFECT line. */
  readonly perfectMinStableFrames: number;
}

/**
 * Defaults tuned against the shipped 15 fps ML budget (one frame ≈ 66 ms):
 *   ·  900 ms — a genuinely new instruction lands ~3× faster than the old
 *               fixed 3 s gate while still being impossible to spam.
 *   · 4500 ms — an unfixed correction is re-stated about every 4.5 s.
 *   · 2500 ms — a returning correction is not re-announced inside one
 *               oscillation cycle.
 *   ·  900 ms × 2 — the 1st change of instruction is prompt (900 ms), the
 *               2nd waits 1.8 s, the 3rd and beyond 2.7 s. A sustained
 *               A/B/A/B loop therefore settles at roughly one calm line
 *               every 2.7 s instead of one every frame.
 *   · 1400 ms — roughly one short studio cue; below this nothing barges in.
 *   ·  600 ms — ~9 dropped frames: a real absence, not a flicker.
 *   ·  1 / 2 frames — the engine already required 3 (correction) / 2
 *               (perfect) consecutive frames; this is a floor, not a second
 *               filter, and it is the ONLY stability input here.
 */
export const DEFAULT_SPEECH_CADENCE: SpeechCadenceConfig = Object.freeze({
  minGapMs: 900,
  repeatIntervalMs: 4500,
  alternationCooldownMs: 2500,
  transitionBackoffMs: 900,
  maxTransitionBackoffSteps: 2,
  interruptGraceMs: 1400,
  silenceGraceMs: 600,
  minStableFrames: 1,
  perfectMinStableFrames: 2,
});

export function resolveSpeechCadence(
  overrides?: Partial<SpeechCadenceConfig>,
): SpeechCadenceConfig {
  if (overrides === undefined) return DEFAULT_SPEECH_CADENCE;
  return Object.freeze({ ...DEFAULT_SPEECH_CADENCE, ...overrides });
}

/** Why the planner allowed or suppressed speech (logging + tests). */
export type SpeechPlanReason =
  /* speak === true */
  | "state-entered"
  | "state-changed"
  | "repeat-interval"
  /* speak === false */
  | "not-speakable"
  | "unstable"
  | "min-gap"
  | "repeat-wait"
  | "recently-said"
  | "already-said"
  | "speaking";

export interface SpeechPlan {
  readonly speak: boolean;
  readonly reason: SpeechPlanReason;
  /** True when this line replaces a different semantic state. */
  readonly isTransition: boolean;
  readonly token: string;
  /**
   * True when executing this plan must stop an utterance that is still
   * playing. The TTS layer uses it to keep the interrupt-and-replace
   * contract explicit instead of implicit.
   */
  readonly interrupts: boolean;
}

export interface SpeechPlannerInput {
  readonly state: CoachingState;
  readonly nowMs: number;
  /** True while the TTS engine is mid-utterance. */
  readonly isSpeaking: boolean;
}

export interface CoachingSpeechPlanner {
  readonly config: SpeechCadenceConfig;
  /** Advances the planner by one frame and returns its decision. */
  plan(input: SpeechPlannerInput): SpeechPlan;
  /**
   * Records a line the app spoke OUTSIDE the coaching path (today: the
   * capture announcement). Coaching then respects the normal gap after it
   * instead of talking over the shutter cue.
   */
  noteExternalSpeech(nowMs: number): void;
  /**
   * Withdraws an authorization that could NOT be executed (the phrase layer
   * returned silence, or the utterance was superseded before it started).
   *
   * Returns true only when `plan` is still the most recent authorization and
   * was actually undone; a stale or already-superseded plan is ignored, so a
   * late failure callback can never disturb the line that replaced it.
   */
  revert(plan: SpeechPlan): boolean;
  /** Clears cadence memory (new camera session / pose change). */
  reset(): void;
}

/** Upper bound on per-token recency memory — a session has ~16 tokens. */
const TOKEN_MEMORY_LIMIT = 32;

/**
 * Everything one authorization changed, captured immediately before it
 * changed it. Enough to put the planner back exactly where it was, and
 * nothing else: `revert` is an undo, not an alternative cadence path.
 */
interface CommittedPlan {
  readonly plan: SpeechPlan;
  readonly spokenToken: string | null;
  readonly spokenAtMs: number;
  readonly tokenWasKnown: boolean;
  readonly tokenAtMs: number;
  readonly consecutiveTransitions: number;
  readonly perfectEpisodeSpoken: boolean;
}

export function createCoachingSpeechPlanner(
  overrides?: Partial<SpeechCadenceConfig>,
): CoachingSpeechPlanner {
  const config = resolveSpeechCadence(overrides);

  /** Semantic token of the last line actually spoken. */
  let spokenToken: string | null = null;
  /** Clock of the last line actually spoken (coaching OR external). */
  let spokenAtMs = Number.NEGATIVE_INFINITY;
  /** Per-token recency, so a returning state is damped, not forgotten. */
  let spokenAtByToken = new Map<string, number>();
  /** Token observed on the previous frame (speakable or not). */
  let lastObservedToken: string | null = null;
  /** True once the current PERFECT episode has had its positive line. */
  let perfectEpisodeSpoken = false;
  /** Clock at which the current unjudgeable run began; null when judgeable. */
  let silentSinceMs: number | null = null;
  /**
   * How many CONSECUTIVE spoken lines changed the instruction. Counts the
   * coach's own behaviour, not the pose: it is the input to the transition
   * back-off and nothing else.
   */
  let consecutiveTransitions = 0;
  /** The most recent authorization, still withdrawable. */
  let lastCommitted: CommittedPlan | null = null;

  function clearCadenceMemory(): void {
    spokenToken = null;
    spokenAtMs = Number.NEGATIVE_INFINITY;
    spokenAtByToken = new Map<string, number>();
    perfectEpisodeSpoken = false;
    consecutiveTransitions = 0;
    lastCommitted = null;
  }

  /**
   * Spacing required before the coach may change what it is saying. The
   * first change is at the plain floor; an unbroken run of changes earns
   * progressively more air, capped so speech can never stop altogether.
   */
  function transitionGapMs(): number {
    const steps = Math.min(
      Math.max(consecutiveTransitions - 1, 0),
      config.maxTransitionBackoffSteps,
    );
    return config.minGapMs + config.transitionBackoffMs * steps;
  }

  function rememberSpoken(token: string, nowMs: number): void {
    spokenToken = token;
    spokenAtMs = nowMs;
    if (!spokenAtByToken.has(token) && spokenAtByToken.size >= TOKEN_MEMORY_LIMIT) {
      /* Deterministic eviction: drop the oldest recorded token. */
      let oldestToken: string | null = null;
      let oldestAt = Number.POSITIVE_INFINITY;
      for (const [candidate, at] of spokenAtByToken) {
        if (at < oldestAt) {
          oldestAt = at;
          oldestToken = candidate;
        }
      }
      if (oldestToken !== null) spokenAtByToken.delete(oldestToken);
    }
    spokenAtByToken.set(token, nowMs);
  }

  function recentlySaid(token: string, nowMs: number): boolean {
    const at = spokenAtByToken.get(token);
    if (at === undefined) return false;
    return nowMs - at < config.alternationCooldownMs;
  }

  function silent(
    reason: SpeechPlanReason,
    isTransition: boolean,
    token: string,
  ): SpeechPlan {
    return { speak: false, reason, isTransition, token, interrupts: false };
  }

  /**
   * Commits one authorization. The pre-commit snapshot is taken here, in the
   * single place where the planner's memory actually moves, so `revert`
   * cannot drift out of step with the gates above it.
   *
   * `closesPerfectEpisode` is passed in rather than set by the caller for
   * the same reason: the flag that guarantees "one positive line per
   * episode" must be part of the same atomic commit it protects.
   */
  function spoke(
    reason: SpeechPlanReason,
    isTransition: boolean,
    token: string,
    nowMs: number,
    isSpeaking: boolean,
    closesPerfectEpisode = false,
  ): SpeechPlan {
    const plan: SpeechPlan = {
      speak: true,
      reason,
      isTransition,
      token,
      interrupts: isSpeaking,
    };
    const previousTokenAt = spokenAtByToken.get(token);
    lastCommitted = {
      plan,
      spokenToken,
      spokenAtMs,
      tokenWasKnown: previousTokenAt !== undefined,
      tokenAtMs: previousTokenAt ?? 0,
      consecutiveTransitions,
      perfectEpisodeSpoken,
    };
    consecutiveTransitions = isTransition ? consecutiveTransitions + 1 : 0;
    if (closesPerfectEpisode) perfectEpisodeSpoken = true;
    rememberSpoken(token, nowMs);
    return plan;
  }

  function revert(plan: SpeechPlan): boolean {
    if (lastCommitted === null || lastCommitted.plan !== plan) return false;
    spokenToken = lastCommitted.spokenToken;
    spokenAtMs = lastCommitted.spokenAtMs;
    if (lastCommitted.tokenWasKnown) {
      spokenAtByToken.set(plan.token, lastCommitted.tokenAtMs);
    } else {
      spokenAtByToken.delete(plan.token);
    }
    consecutiveTransitions = lastCommitted.consecutiveTransitions;
    perfectEpisodeSpoken = lastCommitted.perfectEpisodeSpoken;
    lastCommitted = null;
    return true;
  }

  function plan(input: SpeechPlannerInput): SpeechPlan {
    const { state, nowMs, isSpeaking } = input;
    const token = state.token;
    const transition = lastObservedToken !== token;
    lastObservedToken = token;

    /* ── 1 · Nothing can be judged ────────────────────────────────────────
       Evaluating / unavailable are silent BY CONSTRUCTION: there is no code
       path from here to a correction phrase, so an unusable reference or a
       lost body can never be voiced as advice. A short gap keeps every gate
       intact (so flicker cannot be used to spam); a SUSTAINED gap wipes the
       memory, so a genuine re-entry is prompt instead of waiting out the
       interval of a state that no longer exists. */
    if (!state.speakable) {
      if (silentSinceMs === null) silentSinceMs = nowMs;
      if (nowMs - silentSinceMs >= config.silenceGraceMs) clearCadenceMemory();
      return silent("not-speakable", transition, token);
    }

    if (silentSinceMs !== null) {
      if (nowMs - silentSinceMs >= config.silenceGraceMs) clearCadenceMemory();
      silentSinceMs = null;
    }

    /* ── 2 · Perfect-episode bookkeeping ─────────────────────────────────
       Only a real, speakable, non-perfect state ends a perfect episode. */
    if (state.kind !== "perfect") perfectEpisodeSpoken = false;

    /* ── 3 · Stability is READ, never recomputed ─────────────────────────
       The engine already applied persistence and hysteresis; this is a
       floor for the very first frames, not a second filter. */
    const requiredFrames =
      state.kind === "perfect"
        ? config.perfectMinStableFrames
        : config.minStableFrames;
    if (state.stableFrames < requiredFrames) {
      return silent("unstable", transition, token);
    }

    const sameAsSpoken = spokenToken === token;
    const elapsed = nowMs - spokenAtMs;

    /* ── 4 · Overlap policy: never talk over a line that just started ──── */
    if (isSpeaking) {
      if (sameAsSpoken) return silent("speaking", false, token);
      if (elapsed < config.interruptGraceMs) {
        return silent("speaking", transition, token);
      }
    }

    /* A long quiet spell means the churn is over: forgive the back-off. */
    if (elapsed >= config.repeatIntervalMs) consecutiveTransitions = 0;

    /* Re-entering PERFECT is always a fresh announcement, never a "repeat"
       of the line that is still on record — so it is priced as a change. */
    const isRestatement = sameAsSpoken && state.kind !== "perfect";

    /* ── 5 · PERFECT: one controlled positive line per episode ───────────
       The episode flag alone is not enough: an unspoken correction flicker
       between two perfect runs would clear it and let praise repeat. The
       token's own cooldown closes that hole without looking at the pose. */
    if (state.kind === "perfect") {
      if (perfectEpisodeSpoken) return silent("already-said", false, token);
      if (recentlySaid(token, nowMs)) {
        return silent("recently-said", transition, token);
      }
      if (elapsed < transitionGapMs()) {
        return silent("min-gap", transition, token);
      }
      return spoke(
        spokenToken === null ? "state-entered" : "state-changed",
        true,
        token,
        nowMs,
        isSpeaking,
        /* closes the episode — atomically, so a withdrawn authorization
           cannot spend the one positive line the user never heard. */
        true,
      );
    }

    /* ── 6 · The SAME correction, still uncorrected: remind, don't nag ─── */
    if (isRestatement) {
      if (elapsed < config.repeatIntervalMs) {
        return silent("repeat-wait", false, token);
      }
      return spoke("repeat-interval", false, token, nowMs, isSpeaking);
    }

    /* ── 7 · A different correction ─────────────────────────────────────
       Identity first (is this just a state that came back?), then cadence
       (has the previous line had enough air?). */
    if (recentlySaid(token, nowMs)) {
      return silent("recently-said", true, token);
    }
    if (elapsed < transitionGapMs()) {
      return silent("min-gap", transition, token);
    }
    const isFirstLine = spokenToken === null;
    return spoke(
      isFirstLine ? "state-entered" : "state-changed",
      true,
      token,
      nowMs,
      isSpeaking,
    );
  }

  function noteExternalSpeech(nowMs: number): void {
    /* The clock moves, but no coaching token is claimed: the next coaching
       line still counts as a fresh state, it just waits out the gap. */
    spokenAtMs = nowMs;
  }

  function reset(): void {
    clearCadenceMemory();
    lastObservedToken = null;
    silentSinceMs = null;
  }

  return { config, plan, noteExternalSpeech, revert, reset };
}
