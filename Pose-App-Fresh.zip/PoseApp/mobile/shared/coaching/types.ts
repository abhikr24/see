/**
 * shared/coaching/types.ts — Unit 30: THE SEMANTIC COACHING STATE.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network/React.
 *
 * THE BOUNDARY THIS FILE DEFINES
 *
 *   POSE ANALYSIS (geometry, thresholds, hysteresis — shared/ml/analysis)
 *        ↓  PoseAnalysisDecision
 *   SEMANTIC COACHING STATE  ← this module
 *        ↓  CoachingState (category · direction · severity · confidence · stability)
 *   LANGUAGE                 (shared/coaching/phraseSelection)
 *        ↓
 *   PHRASE SELECTION         (curated banks, no-repeat)
 *        ↓
 *   TTS                      (mobile/src/core/voice/ttsService — speech only)
 *
 * Rules enforced by this shape:
 *   · The speech layer never sees an angle, a landmark or a threshold, so it
 *     cannot reverse-engineer geometry.
 *   · Severity is produced ONCE, by the analysis engine, and is carried here
 *     verbatim — the TTS layer never recomputes it.
 *   · "Nothing can be judged" is a first-class state with a reason, so an
 *     unavailable reference can never decay into a fabricated correction.
 */
import type {
  AnalysisUnavailableReason,
  ComparisonSeverity,
  CorrectionDirection,
} from "../ml/analysis/types";
import type {
  PhraseIntensity,
  VoiceInstructionCategory,
} from "../constants/poseInstructions";

/** What the coach is currently able to say something about. */
export type CoachingKind =
  /** A stable, confident correction is dominant. */
  | "correction"
  /** Every usable measurement is inside tolerance. */
  | "perfect"
  /** The engine has not stabilized on anything yet (first frames / churn). */
  | "evaluating"
  /** Nothing can be judged: no body, low confidence, or unusable reference. */
  | "unavailable";

/** Coarse coaching category used for phrase selection and (optionally) UI. */
export type CoachingCorrectionCategory = VoiceInstructionCategory;

/**
 * THE one object that crosses the math → language boundary.
 * Everything a phrase-selection layer may legitimately need; nothing more.
 */
export interface CoachingState {
  readonly kind: CoachingKind;
  /**
   * Canonical, comparable token for this semantic state, e.g.
   * "LEFT_ELBOW_INCREASE", "PERFECT", "UNAVAILABLE:no-live-pose",
   * "EVALUATING". State transitions are detected by comparing tokens —
   * never by comparing rendered phrases.
   */
  readonly token: string;
  /**
   * The coaching category to speak about. Present for 'correction' and
   * 'perfect' (final_pose_good); null for evaluating/unavailable, which are
   * deliberately not speakable.
   */
  readonly category: CoachingCorrectionCategory | null;
  /** Which measurement drove this state; null when not a correction. */
  readonly measurementId: string | null;
  /** What the body must do to that measurement (engine's signed-error sign). */
  readonly direction: CorrectionDirection;
  /** Engine severity, carried verbatim. Null when not a correction. */
  readonly severity: ComparisonSeverity | null;
  /** Phrase intensity implied by the severity — mapped ONCE, here. */
  readonly intensity: PhraseIntensity;
  /** 0..1 belief backing this state (engine confidence; 0 when unavailable). */
  readonly confidence: number;
  /** Consecutive frames this semantic state has been held by the engine. */
  readonly stableFrames: number;
  /** True when the engine kept the state through hysteresis this frame. */
  readonly heldByHysteresis: boolean;
  /** Why nothing can be judged; null unless kind === 'unavailable'. */
  readonly unavailableReason: AnalysisUnavailableReason | null;
  /**
   * True only for states the coach is allowed to voice
   * ('correction' and 'perfect'). Evaluating/unavailable are silent by
   * construction — not by a TTS-side guess.
   */
  readonly speakable: boolean;
}
