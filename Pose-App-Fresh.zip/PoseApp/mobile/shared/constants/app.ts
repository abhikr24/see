/**
 * shared/constants/app.ts — app-wide constants (Unit 01 + Unit 05 limits).
 */
import type { TabKey } from "../types";

export const APP_NAME = "Smart Photography Assistant";
export const APP_SHORT_NAME = "PoseAssist";
export const APP_VERSION = "1.0.0";
export const LOG_TAG = "PoseAssist";

/** LRU + pagination limits locked by Units 05/23/24 specs. */
export const LIMITS = {
  /** Home "recent poses" shelf — LRU of 4 (Unit 05 store, Unit 07 UI). */
  recentPoses: 4,
  /** Maximum pose history entries retained across the app (Unit 15). */
  poseHistory: 20,
  /** Explore search history — LRU of 10, persisted (Unit 05 store, Unit 08 UI). */
  searchHistory: 10,
  /** Explore grid page size — Unit 24 lazy loading. */
  explorePageSize: 20,
  /** Gallery page size — Unit 24. */
  galleryPageSize: 30,
  /** Auto-capture fires at/above this match % (adjustable 80–95 in settings). */
  autoCaptureDefault: 90,
} as const;

export const TABS: readonly { key: TabKey; label: string }[] = [
  { key: "home", label: "Home" },
  { key: "explore", label: "Explore" },
  { key: "camera", label: "Camera" },
  { key: "gallery", label: "Gallery" },
  { key: "profile", label: "Profile" },
] as const;

/** MMKV storage keys (mirror keeps the same names for parity). */
export const STORAGE_KEYS = {
  themeMode: "spa.theme.mode",
  isFirstLaunch: "spa.firstLaunch",
  hasSeenOnboarding: "spa.onboarding.seen",
  hasGrantedPermissions: "spa.permissions.granted",
  poseCatalog: "spa.poses.catalog",
  recentPoseIds: "spa.poses.recent",
  searchHistory: "spa.explore.searchHistory",
  galleryPhotos: "spa.gallery.photos",
  favorites: "spa.favorites.ids",
  demoAuthSession: "demo.auth.session",
  settings: "spa.settings",
} as const;
