/**
 * Unit 27 Part 1 — Human-like voice instruction phrase bank
 * (platform-neutral, zero RN/DOM).
 *
 * A real photo-studio / yoga instructor never repeats the same line twice.
 * This bank holds short spoken coaching cues (4–8 words) for every pose
 * correction category, in two voices:
 *   · hi — Hindi/Hinglish, the way an Indian photographer actually talks on
 *     set ("भाई थोड़ा सा हाथ ऊपर… बस बस"): fillers like "hmm", "bas",
 *     "haan", "thoda sa", "perfect", natural commas and ellipses.
 *   · en — crisp studio English of the same rhythm.
 *
 * `getRandomInstruction(category, language)` returns a uniformly random
 * variation and never repeats the variation used for the same
 * (category, language) key immediately before, so consecutive corrections
 * always sound fresh. Punctuation ("…", commas) is intentional: the native
 * TTS renders them as micro-pauses, which carries the human cadence.
 *
 * Pure data + a pure function: runs identically on mobile (mobile/) and the
 * web mirror (src/). No colors, no UI copy — voice text only.
 */

import { resolveInstructionLanguage } from '../voice/locales';
import type { InstructionLanguage } from '../types/settings';

/**
 * The language the coaching is authored in. Unit 37 moved the canonical
 * declaration to `shared/types/settings` (next to the persisted setting it
 * comes from) and re-exports it here so every existing phrase-bank consumer
 * keeps importing the SAME type from the SAME place it always did.
 */
export type { InstructionLanguage } from '../types/settings';

/** Every correction category the coach can speak about. */
export type VoiceInstructionCategory =
  | 'hand_up'
  | 'hand_down'
  | 'hand_left'
  | 'hand_right'
  | 'leg_left'
  | 'leg_right'
  /**
   * Unit 32 (Part 4.1) — DIRECTION-CORRECT knee categories.
   *
   * `leg_left`/`leg_right` above encode only the SIDE: their pools mix
   * "straighten" and "bend" lines, so a knee correction had a ~50% chance of
   * being spoken as the OPPOSITE of the engine's decision. The engine always
   * knew the direction; the category collapsed it. These four pools keep
   * side AND direction, so the spoken cue matches the on-screen directive.
   */
  | 'leg_left_straighten'
  | 'leg_left_bend'
  | 'leg_right_straighten'
  | 'leg_right_bend'
  /**
   * Unit 33 (Part 4.2) — DIRECTION-CORRECT ELBOW categories.
   *
   * The elbow rules used to speak through `hand_left` / `hand_right`, whose
   * pools mean "slide the hand sideways" ("Hand a little left…"). The engine
   * decision behind them is "straighten / bend that arm" — a completely
   * different instruction, so the screen and the voice disagreed on WHAT to
   * do. These four pools carry side AND the elbow direction.
   */
  | 'hand_left_straighten'
  | 'hand_left_bend'
  | 'hand_right_straighten'
  | 'hand_right_bend'
  /**
   * Unit 33 (Part 4.2) — DIRECTION-CORRECT HIP categories.
   *
   * The hip rules used to speak through `leg_open` / `leg_close`, which are
   * STANCE-WIDTH lines ("open that stance wide"). The hip measurement is
   * torso↔thigh angle: the correction is "leg forward / leg back", not
   * "feet wider / feet closer". These four pools say what the engine meant.
   */
  | 'leg_left_forward'
  | 'leg_left_back'
  | 'leg_right_forward'
  | 'leg_right_back'
  | 'leg_open'
  | 'leg_close'
  | 'look_straight'
  | 'look_left'
  | 'look_right'
  | 'chin_up'
  | 'chin_down'
  | 'shoulder_straight'
  | 'back_straight'
  | 'final_pose_good'
  | 'photo_clicking';

type InstructionBank = Readonly<Record<VoiceInstructionCategory, readonly string[]>>;

/** Hindi / Hinglish variations — set-photographer voice. */
const HI_INSTRUCTIONS: InstructionBank = {
  hand_up: [
    'भाई, थोड़ा सा हाथ ऊपर… बस बस',
    'हाथ थोड़ा ऊपर ले आओ… हाँ, बस',
    'ऊपर ऊपर… हाथ ऊपर… हाँ वहीं',
    'thoda sa हाथ ऊपर करो… perfect',
    'हाथ ऊपर, आराम से… वहीं रुको',
    'hmm, हाथ थोड़ा ऊपर… बस',
    'ऊपर ले जाओ हाथ… थोड़ा और… बस',
    'एकदम हल्का सा हाथ ऊपर… हाँ, stop',
  ],
  hand_down: [
    'हाथ थोड़ा नीचे… बस, बस',
    'नीचे लाओ हाथ… आराम से… बस',
    'thoda sa नीचे… हाँ, वहीं',
    'हाथ धीरे से नीचे… perfect',
    'नीचे नीचे… हाथ नीचे… ठीक है',
    'hmm, बहुत ऊपर है… थोड़ा नीचे… बस',
    'हाथ relax करके नीचे… हाँ',
    'थोड़ा सा नीचे ले आओ… बस बस',
  ],
  hand_left: [
    'हाथ थोड़ा बाएं… बस बस',
    'बाएं ले जाओ हाथ… हाँ, वहीं',
    'thoda left की तरफ… perfect',
    'हाथ बाईं ओर सरकाओ… बस',
    'hmm, थोड़ा बाएं… हाँ ठीक',
    'बाएं, बाएं… आहिस्ता… रुको',
    'हाथ थोड़ा सा बाएं खिसकाओ… बस',
    'left side ले आओ हाथ… हाँ, बस',
  ],
  hand_right: [
    'हाथ थोड़ा दाएं… बस बस',
    'दाएं ले जाओ हाथ… हाँ, वहीं',
    'thoda right की तरफ… perfect',
    'हाथ दाईं ओर सरकाओ… बस',
    'hmm, थोड़ा दाएं… हाँ ठीक',
    'दाएं, दाएं… आहिस्ता… रुको',
    'हाथ थोड़ा सा दाएं खिसकाओ… बस',
    'right side ले आओ हाथ… हाँ, बस',
  ],
  leg_left: [
    'बायां पैर थोड़ा सा adjust करो… बस',
    'बायां पैर… हाँ, वहीं रखो',
    'left पैर ढीला छोड़ो… perfect',
    'बायां पैर थोड़ा बाहर… बस बस',
    'hmm, बायां pair सीधा करो… हाँ',
    'बाएं पैर पर weight… आराम से… बस',
    'बायां पैर थोड़ा मोड़ो… वहीं',
    'left leg थोड़ा झुकाओ… हाँ, ठीक',
  ],
  leg_right: [
    'दायां पैर थोड़ा सा adjust करो… बस',
    'दायां पैर… हाँ, वहीं रखो',
    'right पैर ढीला छोड़ो… perfect',
    'दायां पैर थोड़ा बाहर… बस बस',
    'hmm, दायां pair सीधा करो… हाँ',
    'दाएं पैर पर weight… आराम से… बस',
    'दायां पैर थोड़ा मोड़ो… वहीं',
    'right leg थोड़ा झुकाओ… हाँ, ठीक',
  ],
  leg_left_straighten: [
    'बायां पैर सीधा करो… बस बस',
    'बायां पैर तान दो… हाँ, वहीं',
    'left पैर सीधा… perfect',
    'बायां घुटना खोलो… आराम से… बस',
    'hmm, बायां pair सीधा करो… हाँ',
    'बायां पैर पूरा सीधा… वहीं रुको',
    'एड़ी पर ज़ोर… बायां पैर सीधा… बस',
    'left leg straight करो… हाँ, ठीक',
  ],
  leg_left_bend: [
    'बायां पैर थोड़ा मोड़ो… बस बस',
    'बाएं घुटने को हल्का सा झुकाओ… हाँ',
    'left पैर ढीला छोड़ो… perfect',
    'बायां घुटना soft रखो… वहीं',
    'hmm, बायां पैर थोड़ा bend… हाँ',
    'बाएं पैर में हल्का सा झुकाव… बस',
    'left leg थोड़ा झुकाओ… हाँ, ठीक',
    'बायां घुटना थोड़ा मोड़ो… रुको',
  ],
  leg_right_straighten: [
    'दायां पैर सीधा करो… बस बस',
    'दायां पैर तान दो… हाँ, वहीं',
    'right पैर सीधा… perfect',
    'दायां घुटना खोलो… आराम से… बस',
    'hmm, दायां pair सीधा करो… हाँ',
    'दायां पैर पूरा सीधा… वहीं रुको',
    'एड़ी पर ज़ोर… दायां पैर सीधा… बस',
    'right leg straight करो… हाँ, ठीक',
  ],
  leg_right_bend: [
    'दायां पैर थोड़ा मोड़ो… बस बस',
    'दाएं घुटने को हल्का सा झुकाओ… हाँ',
    'right पैर ढीला छोड़ो… perfect',
    'दायां घुटना soft रखो… वहीं',
    'hmm, दायां पैर थोड़ा bend… हाँ',
    'दाएं पैर में हल्का सा झुकाव… बस',
    'right leg थोड़ा झुकाओ… हाँ, ठीक',
    'दायां घुटना थोड़ा मोड़ो… रुको',
  ],
  hand_left_straighten: [
    'बायां हाथ सीधा करो… बस बस',
    'बाईं कोहनी खोलो… हाँ, वहीं',
    'left हाथ तान दो… perfect',
    'hmm, बायां हाथ थोड़ा और सीधा… बस',
    'बायां हाथ पूरा फैलाओ… आराम से… रुको',
    'बाएं हाथ को straight करो… हाँ, ठीक',
  ],
  hand_left_bend: [
    'बायां हाथ थोड़ा मोड़ो… बस बस',
    'बाईं कोहनी हल्की सी झुकाओ… हाँ',
    'left हाथ थोड़ा अंदर… perfect',
    'hmm, बायां हाथ soft रखो… बस',
    'बायां हाथ पास ले आओ… आराम से… रुको',
    'बाएं हाथ में थोड़ा bend… हाँ, ठीक',
  ],
  hand_right_straighten: [
    'दायां हाथ सीधा करो… बस बस',
    'दाईं कोहनी खोलो… हाँ, वहीं',
    'right हाथ तान दो… perfect',
    'hmm, दायां हाथ थोड़ा और सीधा… बस',
    'दायां हाथ पूरा फैलाओ… आराम से… रुको',
    'दाएं हाथ को straight करो… हाँ, ठीक',
  ],
  hand_right_bend: [
    'दायां हाथ थोड़ा मोड़ो… बस बस',
    'दाईं कोहनी हल्की सी झुकाओ… हाँ',
    'right हाथ थोड़ा अंदर… perfect',
    'hmm, दायां हाथ soft रखो… बस',
    'दायां हाथ पास ले आओ… आराम से… रुको',
    'दाएं हाथ में थोड़ा bend… हाँ, ठीक',
  ],
  leg_left_forward: [
    'बायां पैर थोड़ा आगे… बस बस',
    'बाएं पैर को आगे लाओ… हाँ, वहीं',
    'left पैर हल्का सा आगे… perfect',
    'hmm, बायां पैर आगे निकालो… बस',
    'बायां पैर एक कदम आगे… आराम से… रुको',
    'बाएं पैर को आगे रखो… हाँ, ठीक',
  ],
  leg_left_back: [
    'बायां पैर थोड़ा पीछे… बस बस',
    'बाएं पैर को पीछे लो… हाँ, वहीं',
    'left पैर हल्का सा पीछे… perfect',
    'hmm, बायां पैर पीछे खिसकाओ… बस',
    'बायां पैर torso के नीचे… आराम से… रुको',
    'बाएं पैर को पीछे रखो… हाँ, ठीक',
  ],
  leg_right_forward: [
    'दायां पैर थोड़ा आगे… बस बस',
    'दाएं पैर को आगे लाओ… हाँ, वहीं',
    'right पैर हल्का सा आगे… perfect',
    'hmm, दायां पैर आगे निकालो… बस',
    'दायां पैर एक कदम आगे… आराम से… रुको',
    'दाएं पैर को आगे रखो… हाँ, ठीक',
  ],
  leg_right_back: [
    'दायां पैर थोड़ा पीछे… बस बस',
    'दाएं पैर को पीछे लो… हाँ, वहीं',
    'right पैर हल्का सा पीछे… perfect',
    'hmm, दायां पैर पीछे खिसकाओ… बस',
    'दायां पैर torso के नीचे… आराम से… रुको',
    'दाएं पैर को पीछे रखो… हाँ, ठीक',
  ],
  leg_open: [
    'पैर थोड़े खोलो… बस, बस',
    'थोड़ा सा पैर आगे… हाँ, wide… perfect',
    'एक पैर आगे लाओ… आराम से… बस',
    'stance थोड़ा खोलो… वहीं रुको',
    'पैर खोलो, कंफर्टेबल रहो… हाँ',
    'hmm, पैर थोड़े apart… बस बस',
    'एक कदम आगे… वहीं… ठीक है',
    'थोड़ा open stance लो… हाँ, perfect',
  ],
  leg_close: [
    'पैर थोड़े पास लाओ… बस बस',
    'पैर वापस खिसकाओ… हाँ, वहीं',
    'stance थोड़ा close… perfect',
    'thora पैर अंदर… आराम से… बस',
    'पैर जोड़ लो हल्का सा… ठीक',
    'hmm, पैर थोड़े पास पास… बस',
    'एक पैर पीछे ले जाओ… वहीं रुको',
    'close करो stance… हाँ, बस',
  ],
  look_straight: [
    'सीधा देखो… camera में… बस',
    'नज़र सीधी… lens की तरफ… perfect',
    'इधर देखो, सीधा… हाँ, वहीं',
    'look straight… बस, पलकें नहीं',
    'hmm, सीधा देखो… एकदम सामने… बस',
    'सामने की तरफ देखो… आराम से',
    'camera की तरफ… सीधी नज़र… ठीक',
    'seedha dekho… बस, वहीं रुको',
  ],
  look_left: [
    'नज़र थोड़ी बाएं… बस बस',
    'बाएं देखो… आहिस्ता… perfect',
    'चेहरा वहीं, नज़र बाएं… हाँ',
    'thoda left देखो… वहीं रुको',
    'hmm, नज़र बाईं तरफ… बस',
    'बाएं की ओर देखो… ढीले रहो… ठीक',
    'eyes left… हाँ, वहीं… बस',
    'धीरे से बाएं देखो… perfect',
  ],
  look_right: [
    'नज़र थोड़ी दाएं… बस बस',
    'दाएं देखो… आहिस्ता… perfect',
    'चेहरा वहीं, नज़र दाएं… हाँ',
    'thoda right देखो… वहीं रुको',
    'hmm, नज़र दाईं तरफ… बस',
    'दाएं की ओर देखो… ढीले रहो… ठीक',
    'eyes right… हाँ, वहीं… बस',
    'धीरे से दाएं देखो… perfect',
  ],
  chin_up: [
    'ठुड़ी थोड़ी ऊपर… बस बस',
    'chin up… हाँ, वहीं… perfect',
    'थोड़ा सा गला ऊपर… आराम से… बस',
    'ठुड़ी ऊपर उठाओ… हल्का सा… ठीक',
    'hmm, chin थोड़ा ऊपर… बस',
    'ऊपर की तरफ ठुड़ी… वहीं रुको',
    'chin up थोड़ा… confident… हाँ',
    'ठुड़ी ऊपर… एकदम हल्का… बस बस',
  ],
  chin_down: [
    'ठुड़ी थोड़ी नीचे… बस बस',
    'chin down… हाँ, वहीं… perfect',
    'थोड़ा सा सर नीचे… आराम से… बस',
    'ठुड़ी अंदर लो… हल्का सा… ठीक',
    'hmm, chin थोड़ा नीचे… बस',
    'नीचे की तरफ ठुड़ी… वहीं रुको',
    'chin नीचे थोड़ा… soft… हाँ',
    'ठुड़ी झुकाओ… एकदम हल्का… बस बस',
  ],
  shoulder_straight: [
    'कंधे सीधे करो… बस बस',
    'shoulders straight… हाँ… perfect',
    'कंधे बराबर… झुको मत… ठीक',
    'एक कंधा झुका है… सीधा करो… बस',
    'hmm, कंधे level में… हाँ वहीं',
    'कंधे relax, बराबर… आराम से… बस',
    'दोनों कंधे एक line में… perfect',
    'कंधा ऊपर मत करो… शांत रखो… हाँ',
  ],
  back_straight: [
    'पीठ सीधी… बस, वहीं',
    'back straight करो… perfect लगेगा',
    'कमर सीधी… झुको मत… बस बस',
    'hmm, पीठ सीधी खींचो… हाँ',
    'chest खोलो, back straight… ठीक',
    'सीधे खड़े हो जाओ… आराम से… बस',
    'पीठ सीधी, कंधे पीछे… perfect',
    'थोड़ा तन जाओ… back सीधा… हाँ, बस',
  ],
  final_pose_good: [
    'हाँ… perfect… बिल्कुल वैसे ही रहो',
    'waah… एकदम सही pose… रुको वहीं',
    'बस! यही… pose पक्का… मत हिलना',
    'perfect aa gaya… अब ऐसे ही… bas',
    'हाँ भाई, अब मज़ा आया… वहीं रुको',
    'pose set hai… ekdum perfect… hold it',
    'यही वाला… बहुत बढ़िया… रुको बस',
    'hmm… perfect… अब बिल्कुल मत हिलना',
  ],
  photo_clicking: [
    'hmm बस… अब photo खींच रहा हूँ…',
    'बस वहीं… photo ले रहा हूँ… मत हिलना',
    'perfect… अब click हो रही है… बस',
    'वहीं रुको… एक, दो… photo!',
    'hold करो… photo आ रही है…',
    'बस बस… अभी खींचता हूँ…',
    'eyes यहीं… photo ले रहा हूँ…',
    'ready… अब photo… ekdum perfect',
  ],
};

/** English variations — same set-photographer rhythm. */
const EN_INSTRUCTIONS: InstructionBank = {
  hand_up: [
    'Hand up a little… there, hold',
    'Raise your hand slightly… perfect',
    'A touch higher… yes, right there',
    'Hand up, slowly… and stop',
    'hmm, bit higher with the hand… good',
    'Bring that hand up… easy… hold',
    'Up with the hand… little more… stop',
    'Just a small lift… yes, hold it',
  ],
  hand_down: [
    'Hand down a little… there, hold',
    'Lower your hand slightly… perfect',
    'A touch lower… yes, right there',
    'Hand down, slowly… and stop',
    'hmm, bit lower with the hand… good',
    'Bring that hand down… easy… hold',
    'Down with the hand… little more… stop',
    'Relax the hand down… yes, hold it',
  ],
  hand_left: [
    'Hand a little left… there, hold',
    'Shift your hand left… perfect',
    'A touch to the left… yes, right there',
    'Slide the hand left… and stop',
    'hmm, move the hand left… good',
    'Ease it left… slowly… hold',
    'Left with the hand… little more… stop',
    'Just drift left… yes, hold it',
  ],
  hand_right: [
    'Hand a little right… there, hold',
    'Shift your hand right… perfect',
    'A touch to the right… yes, right there',
    'Slide the hand right… and stop',
    'hmm, move the hand right… good',
    'Ease it right… slowly… hold',
    'Right with the hand… little more… stop',
    'Just drift right… yes, hold it',
  ],
  leg_left: [
    'Adjust your left leg… there, hold',
    'Left leg… soften it… perfect',
    'Left leg out a touch… yes, right there',
    'Straighten the left leg… and stop',
    'hmm, weight on the left… good',
    'Bend the left leg slightly… hold',
    'Easy with the left leg… that’s it',
    'Left leg, small shift… yes, hold it',
  ],
  leg_right: [
    'Adjust your right leg… there, hold',
    'Right leg… soften it… perfect',
    'Right leg out a touch… yes, right there',
    'Straighten the right leg… and stop',
    'hmm, weight on the right… good',
    'Bend the right leg slightly… hold',
    'Easy with the right leg… that’s it',
    'Right leg, small shift… yes, hold it',
  ],
  leg_left_straighten: [
    'Straighten the left leg… there, hold',
    'Extend that left leg… perfect',
    'Left leg straight… yes, right there',
    'Push through the left heel… and stop',
    'hmm, open the left knee… good',
    'Lengthen the left leg… easy… hold',
    'Left leg long and straight… that’s it',
    'Straighten it out, left side… yes, hold it',
  ],
  leg_left_bend: [
    'Bend the left leg slightly… there, hold',
    'Soften that left knee… perfect',
    'A little bend in the left leg… yes, right there',
    'Ease the left knee down… and stop',
    'hmm, left knee a touch softer… good',
    'Small bend, left leg… easy… hold',
    'Let the left knee give a little… that’s it',
    'Bend it in, left side… yes, hold it',
  ],
  leg_right_straighten: [
    'Straighten the right leg… there, hold',
    'Extend that right leg… perfect',
    'Right leg straight… yes, right there',
    'Push through the right heel… and stop',
    'hmm, open the right knee… good',
    'Lengthen the right leg… easy… hold',
    'Right leg long and straight… that’s it',
    'Straighten it out, right side… yes, hold it',
  ],
  leg_right_bend: [
    'Bend the right leg slightly… there, hold',
    'Soften that right knee… perfect',
    'A little bend in the right leg… yes, right there',
    'Ease the right knee down… and stop',
    'hmm, right knee a touch softer… good',
    'Small bend, right leg… easy… hold',
    'Let the right knee give a little… that’s it',
    'Bend it in, right side… yes, hold it',
  ],
  hand_left_straighten: [
    'Straighten the left arm… there, hold',
    'Open that left elbow… perfect',
    'Left arm long… yes, right there',
    'hmm, extend the left arm… good',
    'Reach the left hand out… easy… hold',
    'Straighten it out, left arm… that’s it',
  ],
  hand_left_bend: [
    'Bend the left arm a little… there, hold',
    'Soften that left elbow… perfect',
    'Left hand a touch closer… yes, right there',
    'hmm, small bend in the left arm… good',
    'Bring the left hand in… easy… hold',
    'Let the left elbow give… that’s it',
  ],
  hand_right_straighten: [
    'Straighten the right arm… there, hold',
    'Open that right elbow… perfect',
    'Right arm long… yes, right there',
    'hmm, extend the right arm… good',
    'Reach the right hand out… easy… hold',
    'Straighten it out, right arm… that’s it',
  ],
  hand_right_bend: [
    'Bend the right arm a little… there, hold',
    'Soften that right elbow… perfect',
    'Right hand a touch closer… yes, right there',
    'hmm, small bend in the right arm… good',
    'Bring the right hand in… easy… hold',
    'Let the right elbow give… that’s it',
  ],
  leg_left_forward: [
    'Left leg forward a little… there, hold',
    'Bring the left leg ahead… perfect',
    'Left foot a touch forward… yes, right there',
    'hmm, step the left leg out front… good',
    'Left leg leads… easy… hold',
    'Carry the left leg forward… that’s it',
  ],
  leg_left_back: [
    'Left leg back a little… there, hold',
    'Take the left leg behind… perfect',
    'Left foot a touch back… yes, right there',
    'hmm, ease the left leg back… good',
    'Left leg under you… easy… hold',
    'Slide the left leg back… that’s it',
  ],
  leg_right_forward: [
    'Right leg forward a little… there, hold',
    'Bring the right leg ahead… perfect',
    'Right foot a touch forward… yes, right there',
    'hmm, step the right leg out front… good',
    'Right leg leads… easy… hold',
    'Carry the right leg forward… that’s it',
  ],
  leg_right_back: [
    'Right leg back a little… there, hold',
    'Take the right leg behind… perfect',
    'Right foot a touch back… yes, right there',
    'hmm, ease the right leg back… good',
    'Right leg under you… easy… hold',
    'Slide the right leg back… that’s it',
  ],
  leg_open: [
    'Open your stance a little… there, hold',
    'Step slightly wider… perfect',
    'Bring one foot forward… yes, right there',
    'Feet apart, comfortable… and stop',
    'hmm, widen the stance… good',
    'One small step out… slowly… hold',
    'Open up the legs a touch… that’s it',
    'Wider base… yes, hold it',
  ],
  leg_close: [
    'Bring your feet closer… there, hold',
    'Narrow the stance a little… perfect',
    'Step back in… yes, right there',
    'Feet together, gently… and stop',
    'hmm, close the stance… good',
    'One foot back… slowly… hold',
    'Tuck it in a touch… that’s it',
    'Closer stance… yes, hold it',
  ],
  look_straight: [
    'Look straight into the lens… there, hold',
    'Eyes forward, into camera… perfect',
    'Straight ahead… yes, right there',
    'Face the camera… and stop',
    'hmm, eyes straight… good',
    'Look right at me… slowly… hold',
    'Direct to lens… that’s it',
    'Keep the gaze forward… yes, hold it',
  ],
  look_left: [
    'Eyes a little left… there, hold',
    'Glance left, face stays… perfect',
    'Look toward the light on your left… yes',
    'Shift the gaze left… and stop',
    'hmm, eyes left… good',
    'Drift your eyes left… slowly… hold',
    'Soft look to the left… that’s it',
    'Eyes left, chin stays… yes, hold it',
  ],
  look_right: [
    'Eyes a little right… there, hold',
    'Glance right, face stays… perfect',
    'Look toward the right… yes, right there',
    'Shift the gaze right… and stop',
    'hmm, eyes right… good',
    'Drift your eyes right… slowly… hold',
    'Soft look to the right… that’s it',
    'Eyes right, chin stays… yes, hold it',
  ],
  chin_up: [
    'Chin up a little… there, hold',
    'Lift the chin slightly… perfect',
    'A touch up with the chin… yes',
    'Chin up, confidently… and stop',
    'hmm, chin higher… good',
    'Ease the chin up… slowly… hold',
    'Small lift of the chin… that’s it',
    'Chin up just a breath… yes, hold it',
  ],
  chin_down: [
    'Chin down a little… there, hold',
    'Drop the chin slightly… perfect',
    'A touch down with the chin… yes',
    'Tuck the chin softly… and stop',
    'hmm, chin lower… good',
    'Ease the chin down… slowly… hold',
    'Small drop of the chin… that’s it',
    'Chin down just a breath… yes, hold it',
  ],
  shoulder_straight: [
    'Level out your shoulders… there, hold',
    'Shoulders straight, even… perfect',
    'One shoulder is up… level it… yes',
    'Drop and square the shoulders… stop',
    'hmm, shoulders level… good',
    'Relax both shoulders evenly… hold',
    'Square the shoulders a touch… that’s it',
    'Even shoulders… yes, hold it',
  ],
  back_straight: [
    'Straighten your back… there, hold',
    'Back straight, chest open… perfect',
    'Tall through the spine… yes, right there',
    'No slouching… lengthen up… stop',
    'hmm, straighten up… good',
    'Roll shoulders back, spine tall… hold',
    'Stretch tall, easy… that’s it',
    'Back long and straight… yes, hold it',
  ],
  final_pose_good: [
    'Yes… perfect… stay right there',
    'That’s the one… hold it, beautiful',
    'Locked in… don’t move a muscle',
    'Perfect… keep exactly that… hold',
    'That’s your pose… lovely… stay',
    'Nailed it… hold that for me',
    'This is the shot… stay still… good',
    'hmm… perfect… absolutely still now',
  ],
  photo_clicking: [
    'Hold it… taking the shot now…',
    'Right there… clicking now… stay still',
    'Perfect… here comes the photo…',
    'Hold… one, two… shot!',
    'Stay with me… I’m clicking now…',
    'That’s it… capturing it…',
    'Eyes here… taking your photo…',
    'ready… and… photo!',
  ],
};

/**
 * Unit 30 — SEVERITY-AWARE PHRASE INTENSITY.
 *
 * The analysis engine already decides how far off a joint is
 * ('minor' vs 'major' ComparisonSeverity). The speech layer must never
 * recompute that; it only needs a phrase pool that SOUNDS right for the
 * severity it was handed:
 *   · 'gentle' — the original Unit 27 pools above (small nudge).
 *   · 'firm'   — the same coach, more direct, for a major deviation.
 *
 * Only the correction categories the engine can actually reach today
 * (8 joint measurements × 2 directions) have a firm pool. Every other
 * category falls back to its gentle pool — a documented fallback, not a
 * silent hole; see shared/coaching/categories.ts for the reachability trace.
 */
type PartialInstructionBank = Partial<Record<VoiceInstructionCategory, readonly string[]>>;

const HI_INSTRUCTIONS_FIRM: PartialInstructionBank = {
  hand_up: [
    'हाथ अच्छा-खासा ऊपर… और ऊपर',
    'बहुत नीचे है… हाथ ऊपर करो… जल्दी',
    'और ऊपर, और ऊपर… हाँ, बस',
    'हाथ पूरा ऊपर लाओ… थोड़ा और… रुको',
    'zyada ऊपर चाहिए… हाँ ऐसे… hold',
  ],
  hand_down: [
    'हाथ काफी नीचे लाओ… और नीचे',
    'बहुत ऊपर है… नीचे करो… जल्दी',
    'और नीचे, और नीचे… हाँ, बस',
    'हाथ पूरा नीचे… थोड़ा और… रुको',
    'zyada नीचे चाहिए… हाँ ऐसे… hold',
  ],
  hand_left: [
    'हाथ अच्छा-खासा बाएं… और बाएं',
    'बहुत दूर है… बाएं लाओ… जल्दी',
    'और बाएं, और बाएं… हाँ, बस',
    'पूरा left ले जाओ हाथ… थोड़ा और… रुको',
    'zyada बाएं चाहिए… हाँ ऐसे… hold',
  ],
  hand_right: [
    'हाथ अच्छा-खासा दाएं… और दाएं',
    'बहुत दूर है… दाएं लाओ… जल्दी',
    'और दाएं, और दाएं… हाँ, बस',
    'पूरा right ले जाओ हाथ… थोड़ा और… रुको',
    'zyada दाएं चाहिए… हाँ ऐसे… hold',
  ],
  leg_left: [
    'बायां पैर ठीक से adjust करो… और',
    'बायां पैर काफी हटा हुआ है… सुधारो',
    'और मोड़ो बायां पैर… हाँ, बस',
    'बाएं पैर पर पूरा weight… रुको',
    'बाएं पैर में zyada बदलाव चाहिए… हाँ',
  ],
  leg_right: [
    'दायां पैर ठीक से adjust करो… और',
    'दायां पैर काफी हटा हुआ है… सुधारो',
    'और मोड़ो दायां पैर… हाँ, बस',
    'दाएं पैर पर पूरा weight… रुको',
    'दाएं पैर में zyada बदलाव चाहिए… हाँ',
  ],
  leg_left_straighten: [
    'बायां पैर पूरा सीधा करो… और',
    'बायां घुटना बहुत मुड़ा है… सीधा करो',
    'और सीधा… बायां पैर… हाँ, बस',
    'बाएं पैर को पूरा तान दो… रुको',
    'zyada सीधा चाहिए बायां पैर… हाँ',
  ],
  leg_left_bend: [
    'बायां पैर अच्छा-खासा मोड़ो… और',
    'बायां घुटना बहुत सीधा है… झुकाओ',
    'और मोड़ो… बायां पैर… हाँ, बस',
    'बाएं घुटने को ठीक से झुकाओ… रुको',
    'zyada bend चाहिए बाएं पैर में… हाँ',
  ],
  leg_right_straighten: [
    'दायां पैर पूरा सीधा करो… और',
    'दायां घुटना बहुत मुड़ा है… सीधा करो',
    'और सीधा… दायां पैर… हाँ, बस',
    'दाएं पैर को पूरा तान दो… रुको',
    'zyada सीधा चाहिए दायां पैर… हाँ',
  ],
  leg_right_bend: [
    'दायां पैर अच्छा-खासा मोड़ो… और',
    'दायां घुटना बहुत सीधा है… झुकाओ',
    'और मोड़ो… दायां पैर… हाँ, बस',
    'दाएं घुटने को ठीक से झुकाओ… रुको',
    'zyada bend चाहिए दाएं पैर में… हाँ',
  ],
  hand_left_straighten: [
    'बायां हाथ पूरा सीधा करो… और',
    'बाईं कोहनी बहुत मुड़ी है… खोलो',
    'और सीधा… बायां हाथ… हाँ, बस',
    'बाएं हाथ को पूरा तान दो… रुको',
    'zyada सीधा चाहिए बायां हाथ… हाँ',
  ],
  hand_left_bend: [
    'बायां हाथ अच्छा-खासा मोड़ो… और',
    'बायां हाथ बहुत सीधा है… झुकाओ',
    'और मोड़ो… बायां हाथ… हाँ, बस',
    'बाईं कोहनी ठीक से मोड़ो… रुको',
    'zyada bend चाहिए बाएं हाथ में… हाँ',
  ],
  hand_right_straighten: [
    'दायां हाथ पूरा सीधा करो… और',
    'दाईं कोहनी बहुत मुड़ी है… खोलो',
    'और सीधा… दायां हाथ… हाँ, बस',
    'दाएं हाथ को पूरा तान दो… रुको',
    'zyada सीधा चाहिए दायां हाथ… हाँ',
  ],
  hand_right_bend: [
    'दायां हाथ अच्छा-खासा मोड़ो… और',
    'दायां हाथ बहुत सीधा है… झुकाओ',
    'और मोड़ो… दायां हाथ… हाँ, बस',
    'दाईं कोहनी ठीक से मोड़ो… रुको',
    'zyada bend चाहिए दाएं हाथ में… हाँ',
  ],
  leg_left_forward: [
    'बायां पैर अच्छा-खासा आगे… और आगे',
    'बायां पैर बहुत पीछे है… आगे लाओ',
    'और आगे… बायां पैर… हाँ, बस',
    'बाएं पैर से पूरा कदम आगे… रुको',
    'zyada आगे चाहिए बायां पैर… हाँ',
  ],
  leg_left_back: [
    'बायां पैर अच्छा-खासा पीछे… और पीछे',
    'बायां पैर बहुत आगे है… पीछे लो',
    'और पीछे… बायां पैर… हाँ, बस',
    'बाएं पैर से पूरा कदम पीछे… रुको',
    'zyada पीछे चाहिए बायां पैर… हाँ',
  ],
  leg_right_forward: [
    'दायां पैर अच्छा-खासा आगे… और आगे',
    'दायां पैर बहुत पीछे है… आगे लाओ',
    'और आगे… दायां पैर… हाँ, बस',
    'दाएं पैर से पूरा कदम आगे… रुको',
    'zyada आगे चाहिए दायां पैर… हाँ',
  ],
  leg_right_back: [
    'दायां पैर अच्छा-खासा पीछे… और पीछे',
    'दायां पैर बहुत आगे है… पीछे लो',
    'और पीछे… दायां पैर… हाँ, बस',
    'दाएं पैर से पूरा कदम पीछे… रुको',
    'zyada पीछे चाहिए दायां पैर… हाँ',
  ],
  leg_open: [
    'पैर अच्छे-खासे खोलो… और चौड़े',
    'stance बहुत तंग है… खोलो… जल्दी',
    'और खोलो, और खोलो… हाँ, बस',
    'पूरा एक कदम बाहर… रुको',
    'zyada wide चाहिए… हाँ ऐसे… hold',
  ],
  leg_close: [
    'पैर काफी पास लाओ… और पास',
    'stance बहुत चौड़ा है… समेटो… जल्दी',
    'और पास, और पास… हाँ, बस',
    'पूरा एक कदम अंदर… रुको',
    'zyada पास चाहिए… हाँ ऐसे… hold',
  ],
};

const EN_INSTRUCTIONS_FIRM: PartialInstructionBank = {
  hand_up: [
    'Hand higher… quite a bit… keep going',
    'Much higher with that hand… yes',
    'Big lift on the hand… up, up… stop',
    'That hand comes way up… now',
    'Push the hand up… more than that… hold',
  ],
  hand_down: [
    'Hand well down… quite a bit lower',
    'Drop that hand… much lower… yes',
    'Way down with the hand… keep going… stop',
    'That hand is far too high… bring it down',
    'Lower the hand properly… more… hold',
  ],
  hand_left: [
    'Hand well to the left… keep going',
    'Big move left with the hand… yes',
    'Much further left… more… stop',
    'That hand is well off… swing it left',
    'Push the hand left… more than that… hold',
  ],
  hand_right: [
    'Hand well to the right… keep going',
    'Big move right with the hand… yes',
    'Much further right… more… stop',
    'That hand is well off… swing it right',
    'Push the hand right… more than that… hold',
  ],
  leg_left: [
    'Left leg needs a big change… now',
    'Move that left leg properly… more',
    'Big adjustment on the left leg… yes',
    'Left leg is well off… fix it… stop',
    'Drive through the left leg… much more… hold',
  ],
  leg_right: [
    'Right leg needs a big change… now',
    'Move that right leg properly… more',
    'Big adjustment on the right leg… yes',
    'Right leg is well off… fix it… stop',
    'Drive through the right leg… much more… hold',
  ],
  leg_left_straighten: [
    'Straighten that left leg fully… more',
    'Left knee is far too bent… open it',
    'Straighter on the left… yes, hold',
    'Extend the left leg all the way… stop',
    'Needs a lot more extension, left… yes',
  ],
  leg_left_bend: [
    'Bend that left leg properly… more',
    'Left leg is far too locked… soften it',
    'More bend in the left… yes, hold',
    'Drop the left knee right down… stop',
    'Needs a lot more bend, left… yes',
  ],
  leg_right_straighten: [
    'Straighten that right leg fully… more',
    'Right knee is far too bent… open it',
    'Straighter on the right… yes, hold',
    'Extend the right leg all the way… stop',
    'Needs a lot more extension, right… yes',
  ],
  leg_right_bend: [
    'Bend that right leg properly… more',
    'Right leg is far too locked… soften it',
    'More bend in the right… yes, hold',
    'Drop the right knee right down… stop',
    'Needs a lot more bend, right… yes',
  ],
  hand_left_straighten: [
    'Straighten that left arm fully… more',
    'Left elbow is far too bent… open it',
    'Straighter, left arm… yes, hold',
    'Extend the left arm all the way… stop',
    'Needs a lot more extension, left arm… yes',
  ],
  hand_left_bend: [
    'Bend that left arm properly… more',
    'Left arm is far too straight… fold it in',
    'More bend, left arm… yes, hold',
    'Bring the left hand right in… stop',
    'Needs a lot more bend, left arm… yes',
  ],
  hand_right_straighten: [
    'Straighten that right arm fully… more',
    'Right elbow is far too bent… open it',
    'Straighter, right arm… yes, hold',
    'Extend the right arm all the way… stop',
    'Needs a lot more extension, right arm… yes',
  ],
  hand_right_bend: [
    'Bend that right arm properly… more',
    'Right arm is far too straight… fold it in',
    'More bend, right arm… yes, hold',
    'Bring the right hand right in… stop',
    'Needs a lot more bend, right arm… yes',
  ],
  leg_left_forward: [
    'Left leg well forward… keep going',
    'Left leg is far too far back… bring it up',
    'Further forward, left leg… yes, hold',
    'Big step forward with the left… stop',
    'Needs a lot more left leg in front… yes',
  ],
  leg_left_back: [
    'Left leg well back… keep going',
    'Left leg is far too far forward… take it back',
    'Further back, left leg… yes, hold',
    'Big step back with the left… stop',
    'Needs a lot more left leg behind… yes',
  ],
  leg_right_forward: [
    'Right leg well forward… keep going',
    'Right leg is far too far back… bring it up',
    'Further forward, right leg… yes, hold',
    'Big step forward with the right… stop',
    'Needs a lot more right leg in front… yes',
  ],
  leg_right_back: [
    'Right leg well back… keep going',
    'Right leg is far too far forward… take it back',
    'Further back, right leg… yes, hold',
    'Big step back with the right… stop',
    'Needs a lot more right leg behind… yes',
  ],
  leg_open: [
    'Open that stance wide… much wider',
    'Big step out… further… yes',
    'Feet far apart now… more… stop',
    'Stance is far too narrow… open it up',
    'Step right out… wider… hold it',
  ],
  leg_close: [
    'Bring those feet well in… much closer',
    'Big step back in… closer… yes',
    'Narrow it right down… more… stop',
    'Stance is far too wide… close it up',
    'Feet in properly… closer… hold',
  ],
};

/** Phrase intensity tier requested by the coaching layer. */
export type PhraseIntensity = 'gentle' | 'firm';

const BANKS: Readonly<Record<InstructionLanguage, InstructionBank>> = {
  hi: HI_INSTRUCTIONS,
  en: EN_INSTRUCTIONS,
};

const FIRM_BANKS: Readonly<Record<InstructionLanguage, PartialInstructionBank>> = {
  hi: HI_INSTRUCTIONS_FIRM,
  en: EN_INSTRUCTIONS_FIRM,
};

/** All supported categories, in declaration order (for tooling/tests). */
export const VOICE_INSTRUCTION_CATEGORIES: readonly VoiceInstructionCategory[] =
  Object.keys(HI_INSTRUCTIONS) as VoiceInstructionCategory[];

/**
 * Last returned phrase per (language, category) key — guarantees the coach
 * never says the same line twice in a row for the same correction.
 *
 * Unit 33: the key deliberately omits the intensity tier. Gentle and firm
 * pools are disjoint for every authored pair, but a category WITHOUT a firm
 * pool falls back to its gentle pool, and in that case a gentle→firm switch
 * must still not repeat the identical sentence.
 */
const lastPhraseForKey = new Map<string, string>();

/** Set form of the category union — the runtime guard for untrusted input. */
const VOICE_INSTRUCTION_CATEGORY_SET: ReadonlySet<string> = new Set(
  Object.keys(HI_INSTRUCTIONS),
);

/** True when `value` is a real phrase-bank category (never a guess). */
export function isVoiceInstructionCategory(
  value: string,
): value is VoiceInstructionCategory {
  return VOICE_INSTRUCTION_CATEGORY_SET.has(value);
}

/**
 * Unit 33 — how the requested (category, language, intensity) triple was
 * actually satisfied. Explicit, never silent:
 *   · 'exact'         — the authored pool for that exact triple was used.
 *   · 'gentle-pool'   — 'firm' was asked for, this category has no firm pool,
 *                       so the SAME category's gentle pool was used. The
 *                       words stay semantically correct; only the intensity
 *                       is softer than requested.
 *   · 'none'          — nothing speakable exists for the triple. Callers must
 *                       stay silent; no other category's text is ever used.
 */
export type PhrasePoolFallback = 'exact' | 'gentle-pool' | 'none';

export interface ResolvedInstructionPool {
  readonly category: VoiceInstructionCategory;
  readonly language: InstructionLanguage;
  /** What the coaching layer asked for (derived upstream from severity). */
  readonly requestedIntensity: PhraseIntensity;
  /** What the bank could actually supply. */
  readonly resolvedIntensity: PhraseIntensity;
  readonly fallback: PhrasePoolFallback;
  readonly phrases: readonly string[];
}

/**
 * THE pool resolver: (category, language, intensity) → the only phrases that
 * may be spoken for that triple, plus an explicit record of any fallback.
 *
 * Selection can therefore never wander across categories or languages: a
 * caller receives this pool or nothing, and the reason is always stated.
 */
/**
 * Unit 36 (Part 4.5) / Unit 37-repair — THE defensive language boundary.
 *
 * The language ultimately originates in a PERSISTED preference, so a
 * corrupted store can present a string this record has no row for. Indexing
 * the banks directly threw a TypeError inside the coaching path; a raw `??`
 * fallback to the English bank was almost as bad, because it made the POOL
 * layer disagree with `resolveInstructionLanguage` — an unknown language
 * then degraded to English phrases while the locale tables and voice path
 * had already decided Hindi (the documented degradation: the unreadable
 * value behaves like a fresh install, i.e. the canonical default language).
 *
 * So the pool resolves the language through the ONE canonical gate exactly
 * once — the first thing it does — and every bank read below is then a
 * guaranteed hit on a language the banks were authored for. `language` in
 * the result reports the language actually supplied, never the raw value
 * that was asked for.
 */
function bankFor(language: InstructionLanguage): InstructionBank {
  return BANKS[language];
}

function firmBankFor(language: InstructionLanguage): PartialInstructionBank {
  return FIRM_BANKS[language];
}

export function resolveInstructionPool(
  category: VoiceInstructionCategory,
  language: InstructionLanguage,
  intensity: PhraseIntensity = 'gentle',
): ResolvedInstructionPool {
  /* Typed callers pass the compile-time language; PERSISTED callers pass the
     runtime. This is the one and only normalization at the bank boundary. */
  const resolvedLanguage = resolveInstructionLanguage(language);
  const base = { category, language: resolvedLanguage, requestedIntensity: intensity } as const;
  const gentle = bankFor(resolvedLanguage)[category] ?? [];

  if (intensity === 'gentle') {
    return gentle.length > 0
      ? { ...base, resolvedIntensity: 'gentle', fallback: 'exact', phrases: gentle }
      : { ...base, resolvedIntensity: 'gentle', fallback: 'none', phrases: [] };
  }

  const firm = firmBankFor(resolvedLanguage)[category];
  if (firm !== undefined && firm.length > 0) {
    return { ...base, resolvedIntensity: 'firm', fallback: 'exact', phrases: firm };
  }
  /* Documented degradation, not a hole: same category, softer tier. */
  return gentle.length > 0
    ? { ...base, resolvedIntensity: 'gentle', fallback: 'gentle-pool', phrases: gentle }
    : { ...base, resolvedIntensity: 'gentle', fallback: 'none', phrases: [] };
}

/**
 * The phrase pool for one (category, language, intensity) triple.
 * Unit 27/30 API, now a thin view over `resolveInstructionPool`.
 */
export function instructionPool(
  category: VoiceInstructionCategory,
  language: InstructionLanguage,
  intensity: PhraseIntensity = 'gentle',
): readonly string[] {
  return resolveInstructionPool(category, language, intensity).phrases;
}

export interface InstructionPickOptions {
  /** Severity-driven tier chosen by the coaching layer (never by the TTS). */
  readonly intensity?: PhraseIntensity;
  /** Injectable 0..1 source so tests can be deterministic. */
  readonly random?: () => number;
  /**
   * Unit 33 — when true the pick is not remembered, so a diagnostic or a
   * preview read cannot consume a variation the user never heard.
   */
  readonly peek?: boolean;
}

/** Unit 33 — a pick, with the evidence that it came from the right pool. */
export interface InstructionPick {
  readonly text: string;
  readonly category: VoiceInstructionCategory;
  readonly language: InstructionLanguage;
  readonly requestedIntensity: PhraseIntensity;
  readonly resolvedIntensity: PhraseIntensity;
  readonly fallback: PhrasePoolFallback;
  readonly poolSize: number;
  /** Index inside the resolved pool (diagnostics + deterministic tests). */
  readonly index: number;
  /** True when the draw landed on the previous line and was stepped past. */
  readonly avoidedRepeat: boolean;
}

/** Clamps any (possibly hostile) 0..1 source onto a valid pool index. */
function drawIndex(random: () => number, size: number): number {
  let value: number;
  try {
    value = random();
  } catch {
    value = 0;
  }
  if (!Number.isFinite(value)) return 0;
  const scaled = Math.floor(value * size);
  if (!Number.isFinite(scaled)) return 0;
  return Math.min(Math.max(scaled, 0), size - 1);
}

/**
 * Unit 33 — THE pick. Resolves the pool first, then varies inside it:
 *
 *   category → language → intensity → pool → non-repeated variation
 *
 * Randomness only ever chooses BETWEEN equally valid lines of the resolved
 * pool, so it cannot affect semantic correctness. Returns null when the
 * triple has no speakable copy; the caller then stays silent instead of
 * borrowing an unrelated sentence.
 */
export function pickInstruction(
  category: VoiceInstructionCategory,
  language: InstructionLanguage,
  options?: InstructionPickOptions,
): InstructionPick | null {
  const resolved = resolveInstructionPool(
    category,
    language,
    options?.intensity ?? 'gentle',
  );
  const variations = resolved.phrases;
  if (variations.length === 0) return null;

  /* The reported — and no-repeat-keyed — language is the RESOLVED one the
     pool actually supplied, so two spellings of a corrupted preference can
     never fork the variation memory and a caller can never believe a line
     came from a language it did not. */
  const resolvedLanguage = resolved.language;
  const common = {
    category,
    language: resolvedLanguage,
    requestedIntensity: resolved.requestedIntensity,
    resolvedIntensity: resolved.resolvedIntensity,
    fallback: resolved.fallback,
    poolSize: variations.length,
  } as const;

  if (variations.length === 1) {
    const only = variations[0] ?? '';
    if (only.length === 0) return null;
    if (options?.peek !== true) lastPhraseForKey.set(`${resolvedLanguage}:${category}`, only);
    return { ...common, text: only, index: 0, avoidedRepeat: false };
  }

  const key = `${resolvedLanguage}:${category}`;
  const previous = lastPhraseForKey.get(key);
  let index = drawIndex(options?.random ?? Math.random, variations.length);
  let avoidedRepeat = false;
  /* One deterministic step forward is enough to dodge an immediate repeat —
     no unbounded retry loop, so a degenerate random source cannot hang. */
  if (variations[index] === previous) {
    index = (index + 1) % variations.length;
    avoidedRepeat = true;
  }

  const text = variations[index] ?? variations[0] ?? '';
  if (text.length === 0) return null;
  if (options?.peek !== true) lastPhraseForKey.set(key, text);
  return { ...common, text, index, avoidedRepeat };
}

/**
 * Picks a spoken instruction for the given correction category, voice
 * language and intensity tier. Never returns the phrase used for that same
 * (language, category) pair immediately before (single-variation pools
 * cannot vary, so they always return directly). Empty string = nothing
 * speakable for this triple.
 */
export function getInstruction(
  category: VoiceInstructionCategory,
  language: InstructionLanguage,
  options?: InstructionPickOptions,
): string {
  return pickInstruction(category, language, options)?.text ?? '';
}

/**
 * Unit 27 API preserved: gentle-tier pick. New code should call
 * getInstruction (or the coaching layer's selectCoachingPhrase) so severity
 * can reach phrase selection.
 */
export function getRandomInstruction(
  category: VoiceInstructionCategory,
  language: InstructionLanguage,
): string {
  return getInstruction(category, language);
}

/** Test/reset helper: clears the no-repeat memory (new coaching session). */
export function resetInstructionMemory(): void {
  lastPhraseForKey.clear();
}
