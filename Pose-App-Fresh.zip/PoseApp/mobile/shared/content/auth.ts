/**
 * shared/content/auth.ts — /auth screen copy.
 * Kept in the shared brain so the app and the preview mirror never drift
 * (same discipline as content/onboarding.ts). No claims beyond the real
 * architecture: browsing is free; camera/favorites/stats need an account;
 * photos stay on-device; the backend stores auth + metadata only.
 */

export const AUTH_COPY = {
  signInTitle: "Sign in to continue",
  signUpTitle: "Create your account",
  signInSubtitle:
    "Camera, favorites and stats need an account. Browsing the pose library stays free.",
  signUpSubtitle:
    "One quick account unlocks the camera, favorites and stats. Browsing the pose library stays free — always.",
  modeSignIn: "Sign In",
  modeSignUp: "Create Account",
  nameLabel: "Display name",
  namePlaceholder: "First name or nickname (optional)",
  emailLabel: "Email",
  emailPlaceholder: "Email address",
  passwordLabel: "Password",
  passwordPlaceholder: "Password",
  passwordHint: `At least 8 characters.`,
  confirmLabel: "Confirm password",
  confirmPlaceholder: "Repeat your password",
  submitSignIn: "Sign In with Email",
  submitSignUp: "Create Account",
  googleCta: "Continue with Google",
  whatHappensNext:
    "Free account. Your camera, favorites and stats open up with it.",
  // Email-confirmation-required state (real backend, confirmation enabled):
  confirmationTitle: "Check your inbox",
  confirmationBody:
    "Your account is created. We sent a confirmation link — open it, then come back and sign in.",
  confirmationBodySignIn:
    "This account exists but isn't confirmed yet. Open the confirmation link we emailed you, then sign in.",
  confirmationBackToSignIn: "Back to Sign In",
  confirmationResend: "Resend confirmation email",
  confirmationResent: "Sent — check your inbox again.",
  // Already-signed-in state (replaces the old silent auto-exit):
  alreadySignedInTitle: "You're already signed in",
  alreadySignedInBody:
    "Camera, favorites and stats are already unlocked for this account.",
  alreadySignedInContinue: "Continue to the App",
  alreadySignedInProfile: "View Profile",
  demoSwitchAccount: "Demo: sign out & test another account",
  // Backend modes (PrivacyNote suffixes, unchanged meaning):
  demoNote:
    "Demo backend — any valid email and 8-character password work. Add Supabase keys to .env to go live with no code changes.",
  liveNote: "Connected to your Supabase project. Session syncs across devices.",
} as const;

/**
 * PASSWORD_RESET_COPY — recovery flow copy (B2). Same discipline as
 * AUTH_COPY: the app, the preview mirror and tests share these strings.
 * Two non-negotiables baked into the wording:
 *   · NEVER confirm whether an email is registered (account-existence
 *     neutrality — also protects deleted accounts from enumeration).
 *   · NEVER claim an email was sent in demo mode (honest demo labeling).
 */
export const PASSWORD_RESET_COPY = {
  forgotLink: "Forgot password?",
  // Step 1 — request the recovery email
  requestTitle: "Reset your password",
  requestBody:
    "Enter the email your account was created with. We'll send a secure recovery link that opens this app and lets you choose a new password.",
  requestSubmit: "Send Recovery Link",
  requestCancel: "Back to Sign In",
  // Step 1 done — neutral acknowledgement (identical for registered,
  // unregistered and deleted addresses, by design)
  requestSentTitle: "Check your inbox",
  requestSentBody:
    "If an account exists for this email, a recovery link is on its way. It stays valid for a short time — follow it to continue.",
  requestSentSpamHint:
    "Nothing arrived? Check spam, or send another link below.",
  requestResend: "Send Another Link",
  requestResent: "Done — check your inbox again.",
  requestDemoNote:
    "Demo backend — no real email is sent here. With a live Supabase project this link opens the app directly.",
  // Step 2 — the recovery link opened the app: choose the new password
  newTitle: "Choose a new password",
  newBody:
    "Your recovery link was accepted. Set a new password for your account.",
  newLabel: "New password",
  newPlaceholder: "New password",
  newConfirmLabel: "Repeat new password",
  newConfirmPlaceholder: "Repeat your new password",
  newHint: "At least 8 characters.",
  newSubmit: "Update Password",
  // Step 3 — done (session is now normal; the user continues signed in)
  doneTitle: "Password updated",
  doneBody:
    "Your password was changed. You're signed in with the new password — you can continue right away.",
  doneContinue: "Continue",
  // Expired / already-used / malformed recovery link
  invalidTitle: "This recovery link has expired",
  invalidBody:
    "Recovery links work once and stay valid for a short time. Send yourself a new link to continue.",
  invalidCta: "Send a New Link",
  // Demo walkthrough of the new-password step (labeled, never mistaken for
  // a real password change)
  newDemoNote:
    "Demo backend — this previews the real reset form. Your demo account has no stored password.",
  // Failure mapping to inline messages (store emits these codes)
  liveNote:
    "Connected to your Supabase project. The recovery link opens this app to finish resetting.",
} as const;

/**
 * ACCOUNT_DELETE_COPY — deletion flow copy (B1). Serious, calm, specific:
 * deletion is never styled as a logout or deactivation, the consequence
 * list is plain language, and the final button is disabled behind a typed
 * DELETE confirmation.
 */
export const ACCOUNT_DELETE_COPY = {
  entryTitle: "Delete Account",
  entryDescription: "Permanently erase your account and its data",
  headerTitle: "Delete account",
  // Honest source note (demo vs live) — never hidden
  liveNote:
    "This uses the secure server-side deletion endpoint of your Supabase project.",
  demoNote:
    "Demo backend — this removes the demo account and its data from this device only. Nothing leaves the device.",
  // Step 1 — consequences
  consequenceTitle: "Deleting your account will:",
  consequenceServerProfile: "Permanently delete your sign-in identity and profile",
  consequenceFavorites: "Delete your synced favorites from our servers",
  consequenceGallery:
    "Delete this account's in-app captures stored on this device",
  consequenceSession: "Sign you out on this device immediately",
  keepTitle: "This will NOT delete:",
  keepDevicePhotos: "Photos you already exported to your device gallery",
  keepSettings: "App preferences and browsing history on this device",
  finality:
    "This is permanent. There is no undo, and support cannot recover a deleted account.",
  // Step 2 — typed confirmation
  confirmInstruction:
    "Type DELETE in capitals to enable the delete button.",
  confirmPlaceholder: "DELETE",
  submitDelete: "Delete My Account",
  cancelLabel: "Keep My Account",
  deletingLabel: "Deleting account…",
  // Outcome — success (only after the backend confirmed, or demo cleanup
  // finished; never shown otherwise)
  successTitle: "Account deleted",
  successBody:
    "Your account and its data have been permanently removed. You've been signed out.",
  successBodyDemo:
    "The demo account and its data on this device were removed. You've been signed out.",
  successContinue: "Continue",
  // Outcome — failure (session stays intact; retry is offered)
  failureTitle: "Account not deleted",
  failureBody:
    "Nothing was deleted and you're still signed in. Resolve the issue and try again.",
  retryLabel: "Try Again",
  // Guard — the flow can only run against a live session
  signInRequiredTitle: "Sign in required",
  signInRequiredBody:
    "You need an active account session to delete an account. Nothing was deleted.",
} as const;
