/**
 * shared/content/onboarding.ts — first-run copy (Unit 03).
 * Kept in the shared brain so the app and the mirror never drift.
 */
export interface OnboardingSlideContent {
  readonly key: string;
  readonly icon: string;
  readonly title: string;
  readonly description: string;
}

export const ONBOARDING_SLIDES: readonly OnboardingSlideContent[] = [
  {
    key: "discover",
    icon: "compass",
    title: "Discover Poses",
    description:
      "Browse 400+ curated poses across 12 categories — from everyday portraits to editorial fashion.",
  },
  {
    key: "guidance",
    icon: "accessibility",
    title: "Live AI Guidance",
    description:
      "On-device body tracking watches 33 landmarks and coaches you into the pose in real time.",
  },
  {
    key: "capture",
    icon: "camera",
    title: "Auto Capture",
    description:
      "When your match hits 90%, the shot fires automatically. Photos never leave your device.",
  },
] as const;

export const WELCOME_COPY = {
  title: "Take Better Photos with Perfect Poses",
  subtitle: "Discover 400+ curated poses with live AI guidance",
  primaryCta: "Get Started",
  secondaryCta: "Sign In",
} as const;
