/**
 * shared/content/visibleCoaching.ts — Camera UX Part 1:
 * THE SINGLE SOURCE OF **VISIBLE** COACHING COPY.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo-speech, zero network.
 *
 *   pose analysis → semantic coaching state → ┬→ phrase bank → voice → TTS
 *                                             └→ THIS MODULE → on-screen copy
 *
 * WHY IT EXISTS
 *
 * Before this module the camera screen rendered `GuidanceResult.text`, a
 * hardcoded ENGLISH string that lives in `shared/ml/guidanceGenerator`
 * (a geometry module). Two defects followed from that:
 *
 *  1. LANGUAGE SPLIT — with `voiceLanguage = 'hi'` the coach SPOKE Hindi
 *     while the overlay SHOWED English. Same semantic state, two languages.
 *  2. STATE COLLAPSE — `decisionToGuidance()` returns `null` for every
 *     non-correction decision, so "no body in frame", "confidence too low",
 *     "still evaluating" and "this pose has no usable reference" all
 *     rendered as *nothing at all*. The user could not tell whether the app
 *     was broken, blind, thinking, or simply unimpressed with their pose.
 *
 * WHAT THIS MODULE IS ALLOWED TO DO
 *   · read the semantic `CoachingState` (kind · category · measurementId ·
 *     direction · severity · confidence · unavailableReason);
 *   · pick pre-authored, deterministic copy in the coaching language.
 *
 * WHAT IT MUST NEVER DO
 *   · re-derive direction, severity, confidence or any threshold — those are
 *     ENGINE decisions and are consumed verbatim here;
 * WHERE IT LIVES AND WHY
 *
 * In `shared/content/` (alongside the other authored UI copy), NOT in
 * `shared/coaching/`. The semantic-coaching folder is guarded by
 * `tests/coaching/semanticContract.test.ts`, which forbids any phrase text
 * living next to the state machine — that guard is correct and is respected
 * here: this module CONSUMES `CoachingState`, it is not part of it.
 *
 *   · call, wrap or depend on the speech layer. Speech owns *when* the coach
 *     talks and *which* pooled variation is spoken. The screen is not the
 *     transcript of the voice: it is stable, deterministic, and never
 *     shuffles wording frame to frame (a rotating on-screen phrase is
 *     unreadable at 15 fps — that is why the phrase-bank pools are NOT
 *     reused here).
 */
import type { CorrectionDirection } from "../ml/analysis/types";
import type { InstructionLanguage } from "../constants/poseInstructions";
import { resolveInstructionLanguage } from "../voice/locales";
import type { CoachingKind, CoachingState } from "../coaching/types";

/**
 * How the band should *feel*. Deliberately semantic, not chromatic: the theme
 * layer owns colour, this layer owns meaning.
 *
 *   'ready'      — you are there, stop moving
 *   'adjust'     — small correction, you are close
 *   'attention'  — large correction, the pose is clearly off
 *   'searching'  — the app cannot judge you yet (not your fault, not an error)
 *   'blocked'    — guidance genuinely cannot run for this pose
 */
export type VisibleCoachingTone =
  | "ready"
  | "adjust"
  | "attention"
  | "searching"
  | "blocked";

export interface VisibleCoaching {
  /** Engine/semantic token, carried verbatim — used for change detection. */
  readonly token: string;
  readonly kind: CoachingKind;
  /** Short imperative. Never a sentence, never a paragraph. */
  readonly headline: string;
  /** One short supporting clause. May be empty — never mandatory. */
  readonly detail: string;
  readonly tone: VisibleCoachingTone;
  /** The language this copy was authored in (already resolved/sanitised). */
  readonly language: InstructionLanguage;
  /**
   * True when the user is being told about THEIR BODY (a correction or a
   * hold). False when the message is about the app's ability to see or judge
   * them. The camera screen uses this to decide whether an arrow makes sense.
   */
  readonly aboutBody: boolean;
}

interface CopyPair {
  readonly headline: string;
  readonly detail: string;
}

type BilingualCopy = Readonly<Record<InstructionLanguage, CopyPair>>;

/** `${measurementId}:${direction}` → copy. Mirrors JOINT_GUIDANCE_RULES 1:1. */
const CORRECTION_COPY: Readonly<Record<string, BilingualCopy>> = {
  "leftElbow:increase": {
    en: { headline: "Straighten your left arm", detail: "Let the elbow open out" },
    hi: { headline: "बायां हाथ सीधा करो", detail: "कोहनी खुलने दो" },
  },
  "leftElbow:decrease": {
    en: { headline: "Bend your left arm", detail: "Bring the hand in a little" },
    hi: { headline: "बायां हाथ थोड़ा मोड़ो", detail: "हाथ थोड़ा पास लाओ" },
  },
  "rightElbow:increase": {
    en: { headline: "Straighten your right arm", detail: "Let the elbow open out" },
    hi: { headline: "दायां हाथ सीधा करो", detail: "कोहनी खुलने दो" },
  },
  "rightElbow:decrease": {
    en: { headline: "Bend your right arm", detail: "Bring the hand in a little" },
    hi: { headline: "दायां हाथ थोड़ा मोड़ो", detail: "हाथ थोड़ा पास लाओ" },
  },
  "leftKnee:increase": {
    en: { headline: "Straighten your left leg", detail: "Push through the heel" },
    hi: { headline: "बायां पैर सीधा करो", detail: "एड़ी पर ज़ोर दो" },
  },
  "leftKnee:decrease": {
    en: { headline: "Soften your left knee", detail: "Just a small bend" },
    hi: { headline: "बायां घुटना हल्का मोड़ो", detail: "बस थोड़ा सा" },
  },
  "rightKnee:increase": {
    en: { headline: "Straighten your right leg", detail: "Push through the heel" },
    hi: { headline: "दायां पैर सीधा करो", detail: "एड़ी पर ज़ोर दो" },
  },
  "rightKnee:decrease": {
    en: { headline: "Soften your right knee", detail: "Just a small bend" },
    hi: { headline: "दायां घुटना हल्का मोड़ो", detail: "बस थोड़ा सा" },
  },
  "leftShoulder:increase": {
    en: { headline: "Lift your left arm", detail: "A little higher, away from your side" },
    hi: { headline: "बायां हाथ ऊपर उठाओ", detail: "थोड़ा और, शरीर से दूर" },
  },
  "leftShoulder:decrease": {
    en: { headline: "Drop your left arm", detail: "Relax it down toward your hip" },
    hi: { headline: "बायां हाथ नीचे लाओ", detail: "आराम से कूल्हे की तरफ" },
  },
  "rightShoulder:increase": {
    en: { headline: "Lift your right arm", detail: "A little higher, away from your side" },
    hi: { headline: "दायां हाथ ऊपर उठाओ", detail: "थोड़ा और, शरीर से दूर" },
  },
  "rightShoulder:decrease": {
    en: { headline: "Drop your right arm", detail: "Relax it down toward your hip" },
    hi: { headline: "दायां हाथ नीचे लाओ", detail: "आराम से कूल्हे की तरफ" },
  },
  "leftHip:increase": {
    en: { headline: "Take your left leg back", detail: "In line with your torso" },
    hi: { headline: "बायां पैर पीछे लो", detail: "शरीर की सीध में" },
  },
  "leftHip:decrease": {
    en: { headline: "Bring your left leg forward", detail: "Just a small step" },
    hi: { headline: "बायां पैर आगे लाओ", detail: "बस एक छोटा कदम" },
  },
  "rightHip:increase": {
    en: { headline: "Take your right leg back", detail: "In line with your torso" },
    hi: { headline: "दायां पैर पीछे लो", detail: "शरीर की सीध में" },
  },
  "rightHip:decrease": {
    en: { headline: "Bring your right leg forward", detail: "Just a small step" },
    hi: { headline: "दायां पैर आगे लाओ", detail: "बस एक छोटा कदम" },
  },
};

/** Copy for the states that are NOT about a single joint. */
const PERFECT_COPY: BilingualCopy = {
  en: { headline: "Perfect — hold it", detail: "Stay right there" },
  hi: { headline: "बिल्कुल सही — रुके रहो", detail: "बस वहीं" },
};

const EVALUATING_COPY: BilingualCopy = {
  en: { headline: "Reading your pose", detail: "One moment" },
  hi: { headline: "पोज़ पढ़ रहे हैं", detail: "एक पल" },
};

/**
 * THE FIVE DISTINCT "I cannot judge you" MESSAGES.
 * These are exactly the engine's `AnalysisUnavailableReason` values — no new
 * reason is invented here and none is collapsed into a generic "bad pose".
 */
const UNAVAILABLE_COPY: Readonly<Record<string, BilingualCopy>> = {
  "no-live-pose": {
    en: { headline: "Step into frame", detail: "I can't see you yet" },
    hi: { headline: "फ्रेम में आओ", detail: "अभी आप दिख नहीं रहे" },
  },
  "low-confidence": {
    en: { headline: "Hard to see you", detail: "More light, and face the camera" },
    hi: { headline: "साफ़ नहीं दिख रहे", detail: "रोशनी बढ़ाओ, कैमरे की तरफ देखो" },
  },
  "insufficient-measurements": {
    en: { headline: "Show more of your body", detail: "Step back so you fit the frame" },
    hi: { headline: "पूरा शरीर दिखाओ", detail: "थोड़ा पीछे हटो" },
  },
  "reference-unavailable": {
    en: { headline: "No guidance for this pose", detail: "Camera and capture still work" },
    hi: { headline: "इस पोज़ की गाइड नहीं है", detail: "कैमरा और कैप्चर चालू हैं" },
  },
  "reference-invalid": {
    en: { headline: "No guidance for this pose", detail: "Its reference can't be used" },
    hi: { headline: "इस पोज़ की गाइड नहीं है", detail: "रेफ़रेंस इस्तेमाल लायक नहीं" },
  },
  "reference-incomplete": {
    en: { headline: "Limited guidance", detail: "This pose has partial reference data" },
    hi: { headline: "सीमित गाइड", detail: "इस पोज़ का डेटा अधूरा है" },
  },
  "reference-incompatible": {
    en: { headline: "No guidance for this pose", detail: "Its reference needs a newer app" },
    hi: { headline: "इस पोज़ की गाइड नहीं है", detail: "ऐप अपडेट चाहिए" },
  },
};

const UNKNOWN_UNAVAILABLE_COPY: BilingualCopy = {
  en: { headline: "Guidance paused", detail: "Nothing measurable right now" },
  hi: { headline: "गाइड रुकी है", detail: "अभी कुछ मापा नहीं जा सकता" },
};

function pick(copy: BilingualCopy, language: InstructionLanguage): CopyPair {
  return copy[language] ?? copy.en;
}

/**
 * Reasons that describe the APP's inability rather than the user's framing.
 * They are the only ones rendered with the 'blocked' tone, because no amount
 * of moving will fix them.
 */
function isReferenceReason(reason: string): boolean {
  return reason.startsWith("reference-");
}

/**
 * Semantic coaching state → the copy the SCREEN shows.
 *
 * Total: every state (including the ones the voice layer must stay silent
 * about) yields a message, because silence on screen is indistinguishable
 * from a frozen app. Returns `null` ONLY when there is no state at all
 * (model warming, throttled frame) — the caller then keeps the previous band
 * or shows nothing, exactly as before.
 */
export function visibleCoachingFor(
  state: CoachingState | null,
  language: unknown,
): VisibleCoaching | null {
  if (state === null) return null;
  const resolved = resolveInstructionLanguage(language);

  if (state.kind === "perfect") {
    const copy = pick(PERFECT_COPY, resolved);
    return {
      token: state.token,
      kind: state.kind,
      headline: copy.headline,
      detail: copy.detail,
      tone: "ready",
      language: resolved,
      aboutBody: true,
    };
  }

  if (state.kind === "correction") {
    const key = correctionKey(state.measurementId, state.direction);
    const entry = key === null ? undefined : CORRECTION_COPY[key];
    if (entry !== undefined) {
      const copy = pick(entry, resolved);
      return {
        token: state.token,
        kind: state.kind,
        headline: copy.headline,
        detail: copy.detail,
        /* Severity is the ENGINE's ladder, carried verbatim — never
           re-thresholded from an angle here. */
        tone: state.severity === "major" ? "attention" : "adjust",
        language: resolved,
        aboutBody: true,
      };
    }
    /* A correction the visible vocabulary cannot name falls through to the
       evaluating copy rather than inventing a body part — the same rule the
       speech layer already applies. */
  }

  if (state.kind === "unavailable") {
    const reason = state.unavailableReason;
    const entry =
      reason === null ? undefined : UNAVAILABLE_COPY[reason];
    const copy = pick(entry ?? UNKNOWN_UNAVAILABLE_COPY, resolved);
    return {
      token: state.token,
      kind: state.kind,
      headline: copy.headline,
      detail: copy.detail,
      tone: reason !== null && isReferenceReason(reason) ? "blocked" : "searching",
      language: resolved,
      aboutBody: false,
    };
  }

  const copy = pick(EVALUATING_COPY, resolved);
  return {
    token: state.token,
    kind: "evaluating",
    headline: copy.headline,
    detail: copy.detail,
    tone: "searching",
    language: resolved,
    aboutBody: false,
  };
}

function correctionKey(
  measurementId: string | null,
  direction: CorrectionDirection,
): string | null {
  if (measurementId === null || direction === "none") return null;
  return `${measurementId}:${direction}`;
}

/** Every correction key the visible vocabulary can name (tests + audits). */
export const VISIBLE_CORRECTION_KEYS: readonly string[] =
  Object.keys(CORRECTION_COPY);

/** Every unavailable reason the visible vocabulary names (tests + audits). */
export const VISIBLE_UNAVAILABLE_REASONS: readonly string[] =
  Object.keys(UNAVAILABLE_COPY);
