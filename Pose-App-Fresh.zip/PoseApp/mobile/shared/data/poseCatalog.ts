/**
 * shared/data/poseCatalog.ts — Unit 05 local pose library (bundled, offline-first)
 * extended in Unit 08 with explore queries (search / featured / collections).
 *
 * Exactly 400 poses generated deterministically from 144 hand-authored
 * signature poses plus angle/light variants across all 12 categories.
 * Deterministic = identical output on device, web, and in tests. No randomness
 * at read time, no network: the catalog ships with the binary (src=bundle).
 */
import type {
  CategorySummary,
  Difficulty,
  Pose,
  PoseCategoryId,
  PoseCategoryMeta,
} from "../types";
import { defaultReferenceAnglesFor } from "./referenceAngles";

/* ── Category metadata ─────────────────────────────────────────────────── */

export const POSE_CATEGORIES: readonly PoseCategoryMeta[] = [
  { id: "portraits", label: "Portraits", icon: "account", hue: 217, tagline: "Timeless solo frames" },
  { id: "couples", label: "Couples", icon: "heart-multiple", hue: 350, tagline: "Chemistry for two" },
  { id: "family", label: "Family", icon: "home-heart", hue: 160, tagline: "Everyone in the shot" },
  { id: "wedding", label: "Wedding", icon: "ring", hue: 280, tagline: "The big day, guided" },
  { id: "fashion", label: "Fashion", icon: "hanger", hue: 262, tagline: "Editorial attitude" },
  { id: "street", label: "Street", icon: "city", hue: 190, tagline: "Urban candids" },
  { id: "fitness", label: "Fitness", icon: "dumbbell", hue: 24, tagline: "Power and form" },
  { id: "dance", label: "Dance", icon: "dance-ballroom", hue: 326, tagline: "Motion, frozen" },
  { id: "travel", label: "Travel", icon: "airplane", hue: 205, tagline: "Postcard frames" },
  { id: "kids", label: "Kids", icon: "baby-face-outline", hue: 45, tagline: "Little personalities" },
  { id: "group", label: "Group", icon: "account-group", hue: 152, tagline: "Squad symmetry" },
  { id: "creative", label: "Creative", icon: "palette", hue: 292, tagline: "Art-first concepts" },
] as const;

const CATEGORY_BY_ID: Readonly<Record<PoseCategoryId, PoseCategoryMeta>> =
  Object.fromEntries(POSE_CATEGORIES.map((c) => [c.id, c])) as Record<
    PoseCategoryId,
    PoseCategoryMeta
  >;

/* ── Signature poses: 12 hand-authored titles per category ─────────────── */

interface BasePose {
  readonly title: string;
  readonly tags: readonly string[];
  readonly difficulty: Difficulty;
  readonly featured?: boolean;
}

const BASE_POSES: Readonly<Record<PoseCategoryId, readonly BasePose[]>> = {
  portraits: [
    { title: "Classic Rembrandt Turn", tags: ["studio", "lighting", "timeless"], difficulty: "beginner", featured: true },
    { title: "Over-the-Shoulder Glance", tags: ["candid", "outdoor"], difficulty: "beginner" },
    { title: "Chin on Hand Study", tags: ["seated", "thoughtful"], difficulty: "beginner" },
    { title: "Window Light Profile", tags: ["indoor", "natural light"], difficulty: "intermediate", featured: true },
    { title: "Walking Towards Camera", tags: ["motion", "street"], difficulty: "intermediate" },
    { title: "Leaning on One Elbow", tags: ["seated", "relaxed"], difficulty: "beginner" },
    { title: "The Genuine Laugh", tags: ["candid", "emotion"], difficulty: "intermediate" },
    { title: "Arms Crossed Power Frame", tags: ["corporate", "confident"], difficulty: "beginner" },
    { title: "Looking Away Composition", tags: ["negative space", "moody"], difficulty: "intermediate" },
    { title: "Backlit Hair Glow", tags: ["backlight", "golden hour"], difficulty: "advanced" },
    { title: "Hands in Pockets Stance", tags: ["casual", "standing"], difficulty: "beginner" },
    { title: "Extreme Close-Up Detail", tags: ["macro", "eyes"], difficulty: "advanced" },
  ],
  couples: [
    { title: "Forehead to Forehead", tags: ["intimate", "close"], difficulty: "beginner", featured: true },
    { title: "The Walking Handhold", tags: ["motion", "candid"], difficulty: "beginner" },
    { title: "Lift and Twirl", tags: ["playful", "motion"], difficulty: "advanced" },
    { title: "Back Hug from Behind", tags: ["embrace", "warm"], difficulty: "beginner" },
    { title: "Almost-Kiss Silhouette", tags: ["silhouette", "sunset"], difficulty: "intermediate", featured: true },
    { title: "Sitting Side by Side", tags: ["bench", "relaxed"], difficulty: "beginner" },
    { title: "Dancing dip", tags: ["dramatic", "formal"], difficulty: "advanced" },
    { title: "Laughter Mid-Whisper", tags: ["candid", "emotion"], difficulty: "intermediate" },
    { title: "Wrapped in a Blanket", tags: ["cozy", "winter"], difficulty: "beginner" },
    { title: "Piggyback Ride", tags: ["playful", "energy"], difficulty: "intermediate" },
    { title: "Nose to Nose Eskimo", tags: ["close-up", "intimate"], difficulty: "beginner" },
    { title: "Leaning Heads Together", tags: ["quiet", "symmetry"], difficulty: "beginner" },
  ],
  family: [
    { title: "Layered Couch Pile", tags: ["indoor", "casual"], difficulty: "beginner", featured: true },
    { title: "Walking in a Line", tags: ["outdoor", "motion"], difficulty: "beginner" },
    { title: "Dad Lift, Mom Frame", tags: ["kids on shoulders", "classic"], difficulty: "intermediate" },
    { title: "Generations Sequence", tags: ["grandparents", "formal"], difficulty: "intermediate" },
    { title: "Picnic Blanket Circle", tags: ["outdoor", "overhead"], difficulty: "beginner" },
    { title: "The Group Squeeze", tags: ["hug", "emotion"], difficulty: "beginner", featured: true },
    { title: "Stairs Height Pyramid", tags: ["steps", "composition"], difficulty: "intermediate" },
    { title: "Running Towards Camera", tags: ["motion", "fun"], difficulty: "advanced" },
    { title: "Reading Together Corner", tags: ["quiet", "window light"], difficulty: "beginner" },
    { title: "Hands All In", tags: ["detail", "close-up"], difficulty: "beginner" },
    { title: "Piggyback Parade", tags: ["playful", "kids"], difficulty: "intermediate" },
    { title: "Sunset Silhouette Walk", tags: ["backlight", "beach"], difficulty: "advanced" },
  ],
  wedding: [
    { title: "The First Look Turn", tags: ["ceremony", "emotion"], difficulty: "intermediate", featured: true },
    { title: "Veil Over Both Faces", tags: ["veil", "romantic"], difficulty: "intermediate" },
    { title: "The Grand Dip", tags: ["dramatic", "kiss"], difficulty: "advanced" },
    { title: "Walking the Aisle Exit", tags: ["candid", "confetti"], difficulty: "beginner" },
    { title: "Ring Detail Macro", tags: ["detail", "macro"], difficulty: "beginner" },
    { title: "Champagne Tower Toast", tags: ["reception", "celebration"], difficulty: "intermediate" },
    { title: "Bouquet Over Shoulder", tags: ["bride", "fashion"], difficulty: "beginner" },
    { title: "Golden Hour Field Walk", tags: ["sunset", "landscape"], difficulty: "advanced", featured: true },
    { title: "Groom Adjusting Cufflinks", tags: ["prep", "detail"], difficulty: "beginner" },
    { title: "Sparkler Send-Off", tags: ["night", "long exposure"], difficulty: "advanced" },
    { title: "Forehead Kiss Arch", tags: ["intimate", "classic"], difficulty: "beginner" },
    { title: "Bridal Party Stagger", tags: ["group", "editorial"], difficulty: "intermediate" },
  ],
  fashion: [
    { title: "The Editorial Lean", tags: ["wall", "attitude"], difficulty: "intermediate", featured: true },
    { title: "Coat Sling Over Shoulder", tags: ["outerwear", "walk"], difficulty: "beginner" },
    { title: "Crouched Sneaker Detail", tags: ["streetwear", "low"], difficulty: "intermediate" },
    { title: "Mid-Stride Crosswalk", tags: ["motion", "urban"], difficulty: "intermediate" },
    { title: "Hand on Brim Close", tags: ["hat", "portrait"], difficulty: "beginner" },
    { title: "Sunglasses Off-Moment", tags: ["accessory", "candid"], difficulty: "beginner" },
    { title: "The Power Stance", tags: ["symmetry", "confident"], difficulty: "intermediate", featured: true },
    { title: "Flowing Fabric Toss", tags: ["motion", "dramatic"], difficulty: "advanced" },
    { title: "Seated on Raw Concrete", tags: ["minimal", "studio"], difficulty: "beginner" },
    { title: "Mirror Reflection Frame", tags: ["reflection", "indoor"], difficulty: "advanced" },
    { title: "Oversized Blazer Profile", tags: ["silhouette", "side"], difficulty: "intermediate" },
    { title: "Ladder Rungs Ascend", tags: ["industrial", "vertical"], difficulty: "advanced" },
  ],
  street: [
    { title: "Crosswalk Mid-Step", tags: ["urban", "motion"], difficulty: "beginner", featured: true },
    { title: "Coffee Cup Lean", tags: ["cafe", "candid"], difficulty: "beginner" },
    { title: "Graffiti Wall Match", tags: ["color", "backdrop"], difficulty: "beginner" },
    { title: "Umbrella in Rain Glow", tags: ["weather", "night"], difficulty: "intermediate" },
    { title: "Subway Platform Wait", tags: ["transit", "leading lines"], difficulty: "intermediate" },
    { title: "Phone Booth Throwback", tags: ["prop", "retro"], difficulty: "beginner" },
    { title: "Looking Up the Tower", tags: ["architecture", "wide"], difficulty: "intermediate", featured: true },
    { title: "Bicycle One-Hand Ride", tags: ["motion", "prop"], difficulty: "advanced" },
    { title: "Market Stall Browse", tags: ["candid", "color"], difficulty: "beginner" },
    { title: "Neon Sign Silhouette", tags: ["night", "neon"], difficulty: "advanced" },
    { title: "Staircase Diagonal Sit", tags: ["geometry", "steps"], difficulty: "intermediate" },
    { title: "Crossing Shadow Stripes", tags: ["shadow", "minimal"], difficulty: "advanced" },
  ],
  fitness: [
    { title: "Plank Hold Side Line", tags: ["core", "form"], difficulty: "intermediate" },
    { title: "Dumbbell Curl Peak", tags: ["arms", "gym"], difficulty: "beginner" },
    { title: "Sprint Start Blocks", tags: ["explosive", "track"], difficulty: "intermediate", featured: true },
    { title: "Battle Rope Slam", tags: ["power", "motion"], difficulty: "intermediate" },
    { title: "Yoga Tree Balance", tags: ["balance", "calm"], difficulty: "beginner" },
    { title: "Deadlift Setup Stare", tags: ["strength", "focus"], difficulty: "advanced" },
    { title: "Jump Squat Apex", tags: ["airborne", "explosive"], difficulty: "advanced", featured: true },
    { title: "Resistance Band Row", tags: ["back", "form"], difficulty: "beginner" },
    { title: "Stadium Stair Run", tags: ["cardio", "outdoor"], difficulty: "intermediate" },
    { title: "Warrior II Reach", tags: ["yoga", "lines"], difficulty: "beginner" },
    { title: "Box Jump Landing", tags: ["plyo", "gym"], difficulty: "advanced" },
    { title: "Stretch Against Sky", tags: ["cooldown", "silhouette"], difficulty: "beginner" },
  ],
  dance: [
    { title: "Grand Jeté Freeze", tags: ["leap", "ballet"], difficulty: "advanced", featured: true },
    { title: "Arabesque Hold", tags: ["ballet", "lines"], difficulty: "advanced" },
    { title: "Hip-Hop Isolate", tags: ["urban", "freeze"], difficulty: "intermediate" },
    { title: "Spin Skirt Flare", tags: ["motion", "twirl"], difficulty: "intermediate" },
    { title: "Tango Frame Tension", tags: ["partner", "dramatic"], difficulty: "advanced" },
    { title: "Contemporary Floor Arc", tags: ["floor", "modern"], difficulty: "intermediate" },
    { title: "Pointe Shoe Detail", tags: ["close-up", "ballet"], difficulty: "beginner" },
    { title: "Street Freeze Handstand", tags: ["breaking", "power"], difficulty: "advanced" },
    { title: "Salsa Open Break", tags: ["partner", "latin"], difficulty: "intermediate", featured: true },
    { title: "Shadow Dancer Silhouette", tags: ["backlight", "studio"], difficulty: "beginner" },
    { title: "Folk Jump Kick", tags: ["traditional", "energy"], difficulty: "intermediate" },
    { title: "Mirror Studio Duet", tags: ["reflection", "practice"], difficulty: "beginner" },
  ],
  travel: [
    { title: "Follow-Me-To Handpull", tags: ["landmark", "leading"], difficulty: "beginner", featured: true },
    { title: "Cliff Edge Wide Stand", tags: ["landscape", "scale"], difficulty: "intermediate" },
    { title: "Backpack Turn Lookback", tags: ["trail", "candid"], difficulty: "beginner" },
    { title: "Cafe Window People-Watch", tags: ["city", "quiet"], difficulty: "beginner" },
    { title: "Airplane Window Gaze", tags: ["transit", "window light"], difficulty: "beginner" },
    { title: "Beach Towel Overhead", tags: ["top-down", "summer"], difficulty: "beginner" },
    { title: "Rooftop City Embrace", tags: ["skyline", "sunset"], difficulty: "intermediate" },
    { title: "Desert Dune Walk", tags: ["minimal", "lines"], difficulty: "intermediate", featured: true },
    { title: "Market Spice Close-Up", tags: ["detail", "color"], difficulty: "beginner" },
    { title: "Kayak Mid-Paddle", tags: ["water", "action"], difficulty: "advanced" },
    { title: "Temple Steps Resect", tags: ["culture", "symmetry"], difficulty: "intermediate" },
    { title: "Snow Trail Footprints", tags: ["winter", "minimal"], difficulty: "beginner" },
  ],
  kids: [
    { title: "Peekaboo Behind Hands", tags: ["playful", "close"], difficulty: "beginner", featured: true },
    { title: "Bubble Chase Sprint", tags: ["motion", "joy"], difficulty: "beginner" },
    { title: "Superhero Cape Leap", tags: ["costume", "energy"], difficulty: "intermediate" },
    { title: "Reading Nook Curl", tags: ["quiet", "indoor"], difficulty: "beginner" },
    { title: "Mud Puddle Stomp", tags: ["messy", "rain"], difficulty: "intermediate" },
    { title: "Towering Block Builder", tags: ["focus", "floor"], difficulty: "beginner" },
    { title: "Wheelbarrow Sibling Race", tags: ["play", "garden"], difficulty: "intermediate" },
    { title: "Dandelion Wish Blow", tags: ["macro", "gentle"], difficulty: "intermediate", featured: true },
    { title: "Teddy Bear Hug Squeeze", tags: ["prop", "soft"], difficulty: "beginner" },
    { title: "Chalk Artist at Work", tags: ["driveway", "color"], difficulty: "beginner" },
    { title: "Blanket Fort Peek", tags: ["indoor", "cozy"], difficulty: "beginner" },
    { title: "Autumn Leaf Toss", tags: ["season", "motion"], difficulty: "intermediate" },
  ],
  group: [
    { title: "Staggered Depth Lineup", tags: ["composition", "friends"], difficulty: "intermediate" },
    { title: "The Walking Crew", tags: ["motion", "attitude"], difficulty: "intermediate", featured: true },
    { title: "Group Jump Sync", tags: ["airborne", "energy"], difficulty: "advanced" },
    { title: "Rooftop Circle Chat", tags: ["overhead", "casual"], difficulty: "beginner" },
    { title: "Heads In Team Huddle", tags: ["circle", "low angle"], difficulty: "beginner" },
    { title: "Staircase Tiered Rows", tags: ["steps", "formal"], difficulty: "intermediate" },
    { title: "Human Pyramid Base", tags: ["playful", "trust"], difficulty: "advanced" },
    { title: "Linked Arms Chorus Line", tags: ["symmetry", "fun"], difficulty: "beginner", featured: true },
    { title: "Bench Overflow Hangout", tags: ["casual", "candid"], difficulty: "beginner" },
    { title: "Back-to-Back Survey", tags: ["editorial", "lines"], difficulty: "intermediate" },
    { title: "Sparkler Night Circle", tags: ["night", "celebration"], difficulty: "advanced" },
    { title: "Toast Raise Freeze", tags: ["celebration", "detail"], difficulty: "beginner" },
  ],
  creative: [
    { title: "Prism Refraction Portrait", tags: ["prism", "light"], difficulty: "advanced", featured: true },
    { title: "Double Exposure Skyline", tags: ["composite", "dreamy"], difficulty: "advanced" },
    { title: "Smoke Bomb Color Walk", tags: ["smoke", "color"], difficulty: "advanced" },
    { title: "Fairy Light Bokeh Wrap", tags: ["lights", "night"], difficulty: "intermediate" },
    { title: "Mirrored Ground Upside", tags: ["reflection", "surreal"], difficulty: "intermediate" },
    { title: "Levitation Frame", tags: ["composite", "float"], difficulty: "advanced", featured: true },
    { title: "Paint Powder Explosion", tags: ["holi", "motion"], difficulty: "intermediate" },
    { title: "Steel Wool Spin Arc", tags: ["long exposure", "night"], difficulty: "advanced" },
    { title: "Shadow Play Walls", tags: ["shadow", "minimal"], difficulty: "beginner" },
    { title: "Through the Glass Pane", tags: ["texture", "rain"], difficulty: "intermediate" },
    { title: "Balloon Cloud Drift", tags: ["prop", "whimsical"], difficulty: "beginner" },
    { title: "Geometric Frame Hunt", tags: ["architecture", "composition"], difficulty: "intermediate" },
  ],
};

/* ── Generation ────────────────────────────────────────────────────────── */

const VARIANTS = [
  { suffix: "Low Angle", tag: "low angle", tip: "Drop the camera to hip height and tilt up for a longer, stronger line." },
  { suffix: "Golden Hour", tag: "golden hour", tip: "Shoot within 40 minutes of sunset; place the sun just outside frame for rim light." },
] as const;

const CATEGORY_TIPS: Readonly<Record<PoseCategoryId, readonly string[]>> = {
  portraits: ["Relax the shoulders first — tension shows in the neck.", "Angle the body 45° and turn the face back to camera.", "Focus on the nearest eye, always."],
  couples: ["Give them a prompt, not a pose — whisper, walk, twirl.", "Shoot the in-between moments; that's where chemistry lives.", "Keep hands visible and connected somewhere in frame."],
  family: ["Pose the tallest first, then layer around them.", "Get everyone touching — connection reads as warmth.", "Shoot bursts; someone is always mid-blink."],
  wedding: ["Scout the light before the couple arrives.", "Keep the bouquet low — never covering the dress line.", "Direct loudly, shoot quietly."],
  fashion: ["Create triangles with arms and legs — it's the editorial shape.", "Chin forward and down for a clean jawline.", "Let the garment move; freeze it at peak."],
  street: ["Wait for the scene to come to you — pre-frame, then hold.", "Use shadows as a second subject.", "Ask for the walk-through twice and shoot the second."],
  fitness: ["Shoot the exertion, not the rest between sets.", "Side light reveals form and muscle definition.", "Faster shutter: 1/1000s or more for explosive frames."],
  dance: ["Count with the music and fire on the beat peak.", "Freeze motion at 1/1000s+, or drag to 1/60s for blur.", "Watch fingertips and toes — they finish every line."],
  travel: ["Include a person to give landmarks scale.", "Shoot landmarks in the edges of the day.", "Get higher or lower than everyone else's postcard."],
  kids: ["Get on their eye level — always.", "Play first, shoot second; comfort reads on camera.", "Burst mode everything — moments last half a second."],
  group: ["Stagger heights — no two heads on the same line.", "Everyone leans in toward the center.", "Count down loud, shoot on 'one'."],
  creative: ["One concept per frame — restraint is the style.", "Expose for the highlight; let shadows go deep.", "Test the effect handheld, then rig it properly."],
};

const DESCRIPTIONS: Readonly<Record<PoseCategoryId, string>> = {
  portraits: "A portrait study built around clean head position and controlled light.",
  couples: "A two-person composition designed to capture genuine connection.",
  family: "A family arrangement that keeps every face visible and connected.",
  wedding: "A wedding-frame classic composed for emotion and clean lines.",
  fashion: "An editorial stance with strong geometry and deliberate attitude.",
  street: "An urban candid framed by the city's lines, light and rhythm.",
  fitness: "An athletic form study that shows power, control and symmetry.",
  dance: "A motion-frozen dance line captured at the peak of the phrase.",
  travel: "A location frame that balances the subject against the scene.",
  kids: "A play-led setup that keeps little subjects comfortable and real.",
  group: "A multi-person arrangement with depth, symmetry and energy.",
  creative: "A concept frame built on one strong visual idea, executed clean.",
};

const DIFFICULTY_CYCLE: readonly Difficulty[] = ["beginner", "intermediate", "advanced"];
const CREATED = "2025-11-01T00:00:00.000Z";

function slugify(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function makePose(
  meta: PoseCategoryMeta,
  title: string,
  tags: readonly string[],
  difficulty: Difficulty,
  featured: boolean,
  index: number,
  variantSuffix: string | null,
  extraTip: string | null,
): Pose {
  const fullTitle = variantSuffix !== null ? `${title} — ${variantSuffix}` : title;
  const slug = slugify(fullTitle);
  const id = `pose-${meta.id}-${slug}`;
  const tips = CATEGORY_TIPS[meta.id];
  return {
    id,
    title: fullTitle,
    category: meta.id,
    subCategory: meta.tagline,
    difficulty,
    tags,
    description: `${DESCRIPTIONS[meta.id]} Reference: “${title}”.`,
    tips: extraTip !== null ? [...tips, extraTip] : tips,
    // No photography ships with the catalog yet. These stay null on purpose:
    // random stock images would misrepresent a specific named pose, and a
    // network fetch would break the "100% offline from first launch" rule.
    // When real licensed art is bundled, populate localAssetPath (and the
    // remote URLs if a CDN is added); PoseCardArt then layers the photo over
    // the branded art, which becomes the offline/loading fallback.
    imageUrl: null,
    thumbnailUrl: null,
    localAssetPath: null,
    isPremium: index % 5 === 4,
    isFeatured: featured,
    // Unit 29: the pose carries its CATEGORY's hand-authored signature stance
    // — nothing more. The per-pose "deterministic variance" that used to be
    // added here was invented data and has been removed; poses in a category
    // share one approximate reference because that is all that is actually
    // known today. The reference provider labels it `category-approximate`
    // fidelity, and measured per-pose angles supersede it when they land.
    referenceAngles: defaultReferenceAnglesFor(meta.id),
    matchTarget: 90,
    colorSeed: (meta.hue + index * 13) % 360,
    createdAt: CREATED,
    updatedAt: CREATED,
  };
}

function buildCatalog(): readonly Pose[] {
  const poses: Pose[] = [];
  POSE_CATEGORIES.forEach((meta, categoryIndex) => {
    const categoryPoses: Pose[] = [];
    const bases = BASE_POSES[meta.id];
    bases.forEach((base, i) => {
      categoryPoses.push(
        makePose(
          meta,
          base.title,
          base.tags,
          base.difficulty,
          base.featured === true,
          i,
          null,
          null,
        ),
      );
      VARIANTS.forEach((variant, v) => {
        const bump = (i + v) % 3 === 1;
        const diff: Difficulty = bump
          ? DIFFICULTY_CYCLE[
              Math.min(2, DIFFICULTY_CYCLE.indexOf(base.difficulty) + 1)
            ] ?? base.difficulty
          : base.difficulty;
        categoryPoses.push(
          makePose(
            meta,
            base.title,
            [...base.tags, variant.tag],
            diff,
            false,
            i * 2 + v + 1,
            variant.suffix,
            variant.tip,
          ),
        );
      });
    });
    // Four categories contain 34 poses; eight contain 33: exactly 400 total.
    poses.push(...categoryPoses.slice(0, categoryIndex < 4 ? 34 : 33));
  });
  return poses;
}

export const POSE_CATALOG: readonly Pose[] = buildCatalog();

const POSE_BY_ID: ReadonlyMap<string, Pose> = new Map(POSE_CATALOG.map((p) => [p.id, p]));

/* ── Unit 05 query API ─────────────────────────────────────────────────── */

export function getPoseCatalog(): readonly Pose[] {
  return POSE_CATALOG;
}

export function getPoseById(id: string): Pose | null {
  return POSE_BY_ID.get(id) ?? null;
}

export interface CatalogReport {
  readonly total: number;
  readonly perCategory: Readonly<Record<string, number>>;
  readonly featured: number;
  readonly premium: number;
}

export function getCatalogReport(): CatalogReport {
  const perCategory: Record<string, number> = {};
  let featured = 0;
  let premium = 0;
  for (const pose of POSE_CATALOG) {
    perCategory[pose.category] = (perCategory[pose.category] ?? 0) + 1;
    if (pose.isFeatured) featured += 1;
    if (pose.isPremium) premium += 1;
  }
  return { total: POSE_CATALOG.length, perCategory, featured, premium };
}

/* ── Unit 08 explore query API ─────────────────────────────────────────── */

export function getFeaturedPoses(): readonly Pose[] {
  return POSE_CATALOG.filter((p) => p.isFeatured);
}

export function getPosesByCategory(category: PoseCategoryId): readonly Pose[] {
  return POSE_CATALOG.filter((p) => p.category === category);
}

/* ── Unit 10 related-poses engine ─────────────────────────────────────── */

const DIFFICULTY_ORDER: Record<Difficulty, number> = {
  beginner: 0,
  intermediate: 1,
  advanced: 2,
};

/**
 * Deterministic related-poses for the detail screen: same category,
 * excluding self, ordered editor picks first → approachable first →
 * stable id tie-break. Deterministic = deep links render identically on
 * every device and in the preview mirror.
 */
export function getRelatedPoses(pose: Pose, limit: number = 10): readonly Pose[] {
  return POSE_CATALOG.filter(
    (candidate) => candidate.category === pose.category && candidate.id !== pose.id,
  )
    .map((candidate) => ({
      candidate,
      rank:
        (candidate.isFeatured ? 0 : 100) +
        DIFFICULTY_ORDER[candidate.difficulty] * 10,
    }))
    .sort(
      (a, b) => a.rank - b.rank || a.candidate.id.localeCompare(b.candidate.id),
    )
    .slice(0, limit)
    .map((entry) => entry.candidate);
}

export function getCategorySummaries(): readonly CategorySummary[] {
  return POSE_CATEGORIES.map((meta) => {
    const poses = POSE_CATALOG.filter((p) => p.category === meta.id);
    const cover = poses.find((p) => p.isFeatured) ?? poses[0];
    if (cover === undefined) {
      throw new Error(`Pose category ${meta.id} contains no poses.`);
    }
    return { ...meta, count: poses.length, coverPoseId: cover.id };
  });
}

export function normalizeQuery(query: string): string {
  return query.trim().toLowerCase().replace(/\s+/g, " ");
}

/**
 * Ranked search across title, tags, category label and sub-category.
 * Ranking: title-prefix > title-contains > tag-contains > category/subcategory.
 * Featured poses get a small boost inside each tier. Deterministic tie-break
 * by id so the app, web and mirror return byte-identical ordering.
 */
export function searchPoses(
  query: string,
  options?: { readonly categoryId?: PoseCategoryId | "all" },
): readonly Pose[] {
  const categoryId = options?.categoryId ?? "all";
  const pool =
    categoryId === "all"
      ? POSE_CATALOG
      : POSE_CATALOG.filter((p) => p.category === categoryId);
  const q = normalizeQuery(query);
  if (q.length === 0) return pool;

  const scored: { pose: Pose; rank: number }[] = [];
  for (const pose of pool) {
    const title = pose.title.toLowerCase();
    const meta = CATEGORY_BY_ID[pose.category];
    let rank = -1;
    if (title.startsWith(q)) rank = 0;
    else if (title.includes(q)) rank = 1;
    else if (pose.tags.some((t) => t.toLowerCase().includes(q))) rank = 2;
    else if (
      meta.label.toLowerCase().includes(q) ||
      pose.subCategory.toLowerCase().includes(q)
    )
      rank = 3;
    if (rank >= 0) scored.push({ pose, rank: rank * 2 - (pose.isFeatured ? 0.25 : 0) });
  }
  scored.sort((a, b) => a.rank - b.rank || a.pose.id.localeCompare(b.pose.id));
  return scored.map((s) => s.pose);
}

/** Preset skill-level filters surfaced as chips in the Explore UI (Unit 08). */
export const DIFFICULTY_FILTERS: readonly { id: Difficulty | "all"; label: string }[] = [
  { id: "all", label: "All levels" },
  { id: "beginner", label: "Beginner" },
  { id: "intermediate", label: "Intermediate" },
  { id: "advanced", label: "Advanced" },
] as const;

export function filterByDifficulty(
  poses: readonly Pose[],
  difficulty: Difficulty | "all",
): readonly Pose[] {
  if (difficulty === "all") return poses;
  return poses.filter((p) => p.difficulty === difficulty);
}
