/**
 * shared/data/referenceAngles.ts — Unit 16 (platform-neutral, zero RN/DOM).
 *
 * The spec's "default reference angles per category for MVP" (§16.3, file 8).
 * Every catalog pose ships with the 8 joint angles of its category's
 * signature stance, plus a small DETERMINISTIC per-pose variation so 400
 * poses do not score identically while every boot still computes the exact
 * same numbers (the catalog's determinism invariant).
 *
 * Angles are degrees 0..180 keyed by MATCH_JOINTS keys. When licensed
 * per-pose reference photography lands, measured angles replace these
 * category defaults one pose at a time — the Pose.referenceAngles contract
 * does not change.
 */
import type { PoseCategoryId } from "../types";

/**
 * Category signature stances, hand-authored degrees per joint, audited for
 * anatomical plausibility against the angle definitions (Unit 16 cross-check):
 *   shoulder = angle(hip→shoulder→elbow) — ~5–20° arms at sides, ~90°
 *              T-pose, ~150°+ arm raised high;
 *   hip      = angle(shoulder→hip→knee) — ~175° standing straight, less when
 *              the torso tilts or the knee drives forward/up;
 *   elbow / knee follow everyday intuition (180° straight, smaller = bent).
 */
const CATEGORY_REFERENCE_ANGLES: Readonly<
  Record<PoseCategoryId, Readonly<Record<string, number>>>
> = {
  portraits: {
    // Relaxed standing, arms at sides, classic portrait contrapposto.
    leftElbow: 165, rightElbow: 168, leftKnee: 172, rightKnee: 175,
    leftShoulder: 14, rightShoulder: 16, leftHip: 172, rightHip: 175,
  },
  couples: {
    // Leaning in toward each other, arms linked around the partner.
    leftElbow: 145, rightElbow: 150, leftKnee: 170, rightKnee: 172,
    leftShoulder: 32, rightShoulder: 36, leftHip: 166, rightHip: 168,
  },
  family: {
    // One arm raised around a child, the other hanging relaxed.
    leftElbow: 130, rightElbow: 162, leftKnee: 168, rightKnee: 172,
    leftShoulder: 72, rightShoulder: 16, leftHip: 166, rightHip: 170,
  },
  wedding: {
    // Bouquet hold in front of the body, forearms angled forward-down.
    leftElbow: 112, rightElbow: 114, leftKnee: 173, rightKnee: 175,
    leftShoulder: 46, rightShoulder: 48, leftHip: 171, rightHip: 173,
  },
  fashion: {
    // Hand-on-hip editorial: sharp elbow one side, the other loose; one knee popped.
    leftElbow: 78, rightElbow: 164, leftKnee: 164, rightKnee: 176,
    leftShoulder: 58, rightShoulder: 12, leftHip: 162, rightHip: 174,
  },
  street: {
    // Hands in pockets: elbows tucked out, shoulders quiet, easy contrapposto.
    leftElbow: 92, rightElbow: 96, leftKnee: 170, rightKnee: 166,
    leftShoulder: 26, rightShoulder: 28, leftHip: 168, rightHip: 163,
  },
  fitness: {
    // Athletic ready stance: quarter squat, arms loaded in front.
    leftElbow: 102, rightElbow: 106, leftKnee: 146, rightKnee: 150,
    leftShoulder: 58, rightShoulder: 54, leftHip: 140, rightHip: 144,
  },
  dance: {
    // One arm extended high in a clean line, supporting leg long, other leg free.
    leftElbow: 174, rightElbow: 126, leftKnee: 176, rightKnee: 152,
    leftShoulder: 168, rightShoulder: 42, leftHip: 170, rightHip: 142,
  },
  travel: {
    // Mid-stroll: relaxed arm swing, one knee in walking bend.
    leftElbow: 156, rightElbow: 150, leftKnee: 158, rightKnee: 172,
    leftShoulder: 34, rightShoulder: 24, leftHip: 160, rightHip: 172,
  },
  kids: {
    // Big energy: elbows lifted and bent, knees spring-loaded.
    leftElbow: 122, rightElbow: 118, leftKnee: 150, rightKnee: 148,
    leftShoulder: 82, rightShoulder: 76, leftHip: 150, rightHip: 148,
  },
  group: {
    // Arms draped over each other's shoulders.
    leftElbow: 138, rightElbow: 140, leftKnee: 170, rightKnee: 172,
    leftShoulder: 96, rightShoulder: 100, leftHip: 167, rightHip: 169,
  },
  creative: {
    // Asymmetric concept stance: one arm raised, one knee driven forward.
    leftElbow: 88, rightElbow: 158, leftKnee: 162, rightKnee: 146,
    leftShoulder: 84, rightShoulder: 18, leftHip: 156, rightHip: 140,
  },
};

/**
 * UNIT 29 CORRECTION — FABRICATED PER-POSE VARIANCE REMOVED.
 *
 * This function used to add `((seed * 31 + jointIndex * 17) % 13) - 6` degrees
 * per joint so that 400 poses would not score identically. Those per-pose
 * digits were not measured from anything; they were noise presented to the
 * coaching engine as this pose's reference. The reference-data audit deleted
 * them: the banned chain is
 *
 *     no measured reference → invented angles → coaching.
 *
 * What is returned now is EXACTLY the hand-authored stance of the pose's
 * category — honest, deterministic, and labelled `category-approximate`
 * fidelity by the provider so no layer can mistake it for a measurement of
 * this specific pose. Poses in one category legitimately share one reference
 * stance, because that is genuinely all the data that exists today.
 *
 * When measured per-pose data lands (Template Scanner / licensed reference
 * photography), it arrives through a `measured-scan` provider and outranks
 * this source; the `Pose.referenceAngles` contract does not change.
 *
 * An unknown future category returns NULL — not the portrait stance. Silently
 * describing an unknown category with portrait angles is the same fabrication
 * in a different costume.
 */
export function defaultReferenceAnglesFor(
  category: PoseCategoryId,
): Readonly<Record<string, number>> | null {
  const base = CATEGORY_REFERENCE_ANGLES[category];
  if (base === undefined) return null;
  return base;
}
