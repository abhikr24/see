/**
 * shared/index.ts — barrel for THE BRAIN.
 * Platform-neutral: imported by the Expo app (mobile/) and the preview
 * mirror (src/). Keep this folder free of any RN or DOM dependency.
 */
export * from "./theme";
export * from "./types";
export * from "./constants/app";
export * from "./constants/poseInstructions";
export * from "./content/onboarding";
/* Camera UX Part 1 — the VISIBLE half of the semantic coaching boundary. */
export * from "./content/visibleCoaching";
/* Auth screen decisions, validation & copy — the Create-Account regression
   fix lives here so app, mirror and tests share one source of truth. */
export * from "./auth/authFlow";
/* Account lifecycle (B1 deletion + B2 recovery) — same decisions for the
   app, the mirror and the tests; privileged ops stay server-side. */
export * from "./auth/accountLifecycle";
export * from "./content/auth";
export * from "./data/poseCatalog";
export * from "./data/referenceAngles";
export * from "./reference";
export * from "./ml/poseLandmarks";
export * from "./ml/poseMatch";
export * from "./ml/poseProjection";
export * from "./ml/guidanceGenerator";
export * from "./ml/analysis";
export * from "./coaching";
export * from "./voice";
export * from "./ml/jointColorMapper";
export * from "./ml/poseSilhouette";
export * from "./ml/gestureDetector";
export * from "./ml/handLandmarks";
export * from "./ml/openPalmClassifier";
export * from "./ml/openPalmGate";
/* A1 — NATIVE REAL-TIME POSE PIPELINE: detector→contract transform
   (mirroring/normalization) + bounded frame-scheduling policy. See
   mobile/docs/a1-native-realtime-pose.md. */
export * from "./ml/poseFrameTransform";
export * from "./ml/poseFramePolicy";
export * from "./camera/intelligentCaptureController";
/* Unit 38 — VOLUME-BUTTON SHUTTER policy (capability · arming · edge
   hygiene). Pure; the native seam lives in mobile/modules/hardware-shutter. */
export * from "./camera/hardwareShutter";
export * from "./camera/cameraPresentation";
export * from "./camera/cameraStatusCopy";
export * from "./camera/cameraControls";
/* D1 — REAL camera exposure: capabilities, EV scale, clamping, mechanism
   routing. Pure; the native seam is the production camera engine's
   exposure-bias surface (VisionCamera `exposure` prop since A1; the retired
   expo-camera patch carried it before). */
export * from "./camera/cameraExposure";
export * from "./camera/cameraFilters";
export * from "./camera/cameraFraming";
/* Post-capture editing (crop · rotate · enhance) — deliberately separate from
   the live camera controls above; see the header of photoEditing.ts. */
export * from "./camera/photoEditing";
export * from "./types/settings";
export * from "./settings/settingsMigration";
