/**
 * shared/ml/poseMatch.ts — Unit 16 (platform-neutral, zero RN/DOM).
 *
 * The match-% engine: joint angles via atan2, per-joint diffs against the
 * armed pose's referenceAngles, and the clamped overall percent:
 *
 *     match % = 100 − (avgAngleDiff / 180 × 100), clamped 0..100   (spec §16.2)
 *
 * Pure functions — the Expo camera screen and the preview mirror run this
 * exact code, so a match shown in the browser mirror is the match the app
 * would compute on the same landmarks.
 */
import {
  MATCH_JOINTS,
  MIN_LANDMARK_VISIBILITY,
  POSE_LANDMARKS,
  type PoseLandmark,
  type PoseLandmarkName,
} from "./poseLandmarks";
import { ANALYSIS_PLAUSIBLE_ANGLE } from "./analysis/thresholds";

/**
 * Plausibility band for a measured joint angle. Legit relaxed stances reach
 * ~4° at the shoulder (arm hanging flush against the torso — Unit 16 audit),
 * so the floor sits below that; anything smaller is landmark jitter folding a
 * joint, never a pose. 180° is the anatomical ceiling by construction.
 */
const MIN_PLAUSIBLE_ANGLE = ANALYSIS_PLAUSIBLE_ANGLE.min;
const MAX_PLAUSIBLE_ANGLE = ANALYSIS_PLAUSIBLE_ANGLE.max;

function landmarkAt(
  landmarks: readonly PoseLandmark[],
  name: PoseLandmarkName,
): PoseLandmark | null {
  const index = POSE_LANDMARKS[name];
  const landmark = landmarks[index];
  if (landmark === undefined) return null;
  const confidence = landmark.visibility ?? 1;
  if (confidence < MIN_LANDMARK_VISIBILITY) return null;
  if (!Number.isFinite(landmark.x) || !Number.isFinite(landmark.y)) return null;
  return landmark;
}

/**
 * Interior angle at `vertex` formed by vertex→a and vertex→c, in degrees
 * 0..180. Returns null when any of the three points is missing or below the
 * visibility floor — unreliable joints are skipped, never guessed.
 */
export function calculateAngle(
  a: PoseLandmark,
  vertex: PoseLandmark,
  c: PoseLandmark,
): number {
  const angleAToVertex = Math.atan2(a.y - vertex.y, a.x - vertex.x);
  const angleCToVertex = Math.atan2(c.y - vertex.y, c.x - vertex.x);
  let degrees = Math.abs(angleAToVertex - angleCToVertex) * (180 / Math.PI);
  if (degrees > 180) degrees = 360 - degrees;
  return degrees;
}

/**
 * Computes the live interior angle of one named joint. Null when the joint
 * cannot be measured from the current landmarks.
 */
export function jointAngle(
  landmarks: readonly PoseLandmark[],
  joint: (typeof MATCH_JOINTS)[number],
): number | null {
  const a = landmarkAt(landmarks, joint.a);
  const vertex = landmarkAt(landmarks, joint.vertex);
  const c = landmarkAt(landmarks, joint.c);
  if (a === null || vertex === null || c === null) return null;
  const degrees = calculateAngle(a, vertex, c);
  if (
    !Number.isFinite(degrees) ||
    degrees < MIN_PLAUSIBLE_ANGLE ||
    degrees > MAX_PLAUSIBLE_ANGLE
  ) {
    return null;
  }
  return degrees;
}

/**
 * joint key → |live − reference| in degrees, for every joint that has BOTH a
 * reference angle and a measurable live angle. This is the map Unit 17 uses
 * to pick the worst joint for guidance; built here in Unit 16.
 */
export function getAngleDiffs(
  liveLandmarks: readonly PoseLandmark[],
  referenceAngles: Readonly<Record<string, number>>,
): Readonly<Record<string, number>> {
  const diffs: Record<string, number> = {};
  for (const joint of MATCH_JOINTS) {
    const reference = referenceAngles[joint.key];
    if (reference === undefined) continue;
    const live = jointAngle(liveLandmarks, joint);
    if (live === null) continue;
    diffs[joint.key] = Math.abs(live - reference);
  }
  return diffs;
}

export interface MatchResult {
  /**
   * 0..100 clamped, or null when too little of the body is visible to score
   * (< 2 measurable joints). null ≠ 0: a hidden body is not a bad pose.
   */
  readonly percent: number | null;
  /** joint key → absolute diff in degrees (measurable joints only). */
  readonly perJoint: Readonly<Record<string, number>>;
  /** How many of the 8 joints produced a comparison this frame. */
  readonly jointsCompared: number;
  /** Mean diff across compared joints; null when percent is null. */
  readonly avgDiffDegrees: number | null;
}

/** match % = clamp(100 − avgDiff/180×100, 0, 100) — spec formula, unrounded input. */
export function diffToPercent(avgDiffDegrees: number): number {
  return Math.max(0, Math.min(100, Math.round(100 - (avgDiffDegrees / 180) * 100)));
}

/**
 * Compares the live landmarks to the armed pose's reference angles.
 * With no usable body in the frame the result is percent:null — the UI reads
 * that as "stand fully into frame", never as a red 0.
 */
export function calculateMatchPercent(
  liveLandmarks: readonly PoseLandmark[],
  referenceAngles: Readonly<Record<string, number>> | null,
): MatchResult {
  if (referenceAngles === null || liveLandmarks.length === 0) {
    return { percent: null, perJoint: {}, jointsCompared: 0, avgDiffDegrees: null };
  }
  const perJoint = getAngleDiffs(liveLandmarks, referenceAngles);
  const diffs = Object.values(perJoint);
  if (diffs.length < 2) {
    return { percent: null, perJoint, jointsCompared: diffs.length, avgDiffDegrees: null };
  }
  const avg = diffs.reduce((sum, diff) => sum + diff, 0) / diffs.length;
  return {
    percent: diffToPercent(avg),
    perJoint,
    jointsCompared: diffs.length,
    avgDiffDegrees: avg,
  };
}
