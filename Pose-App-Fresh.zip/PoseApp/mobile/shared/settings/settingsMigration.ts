/**
 * shared/settings/settingsMigration.ts — Unit 37 (Part 4.6):
 * THE PERSISTED-SETTINGS MIGRATION, AS A PURE FUNCTION.
 *
 * Platform-neutral: zero RN, zero MMKV, zero DOM. The mobile store owns the
 * storage seam; this file owns the *rules*, so the migration can be tested
 * exhaustively in the root suite without a device or a native module.
 *
 * VERSION HISTORY of the `spa.settings` payload
 *   v1 — Unit 20 camera/capture defaults + `voiceLanguage` (Unit 27).
 *   v2 — Unit 35 added `voiceIds` (per-language TTS voice identity).
 *   v3 — Unit 37 renamed `voiceLanguage` → `instructionLanguage`.
 *
 * WHY v3 IS A RENAME AND NOT A RESET
 * `voiceLanguage` already selected the coaching language for BOTH the spoken
 * cue and the on-screen coaching band; only its name suggested otherwise.
 * A user who deliberately chose English must therefore stay on English —
 * migrating is a rename of the key, never a re-ask and never a reset.
 * Recognition goes through the ONE canonical language normalizer, so an old
 * locale spelling ("en-IN") or label ("English" / "Hindi" / "Hinglish") is
 * carried forward as the explicit choice it always was. Only an install
 * with NO usable stored value lands on the new default (Hindi), which is
 * precisely the fresh-install case.
 *
 * The migration is additive and non-destructive: every unrelated key in the
 * persisted object is passed through untouched.
 */
import {
  DEFAULT_CAMERA_SETTINGS,
  type CameraSettings,
  type InstructionLanguage,
} from "../types/settings";
import {
  INSTRUCTION_LANGUAGES,
  normalizeInstructionLanguage,
} from "../voice/locales";

/**
 * v4 — Unit 38 added `volumeShutterEnabled` (volume-button shutter).
 *
 * Purely ADDITIVE: an install that predates the feature has no opinion about
 * it, so it lands on the default (on) exactly like a fresh install would.
 * Nothing else in the payload is touched, and a malformed value is repaired
 * to the default rather than crashing hydration.
 */
/** Current persisted-payload version for the settings store. */
export const SETTINGS_PERSIST_VERSION = 4;

/** The legacy (Unit 27 → Unit 36) shape of the language preference. */
export interface LegacyCameraSettings {
  /** @deprecated renamed to `instructionLanguage` in v3. */
  readonly voiceLanguage?: unknown;
}

export type PersistedCameraSettings = Partial<CameraSettings> &
  LegacyCameraSettings;

/**
 * Whether a persisted value CARRIES a recognizable language decision.
 *
 * Recognition is delegated to the ONE canonical normalizer
 * (`normalizeInstructionLanguage` in shared/voice/locales), so a persisted
 * `"en-IN"`, `"English"` or `"hinglish"` under an old key is honoured as the
 * explicit preference it always was instead of silently treated as absent —
 * while genuinely unreadable junk still falls through to the default below.
 */
function knownLanguage(value: unknown): InstructionLanguage | null {
  return normalizeInstructionLanguage(value);
}

/** A persisted voice map is trusted only after its shape is verified. */
export function isVoiceIdMap(
  value: unknown,
): value is Record<InstructionLanguage, string | null> {
  if (typeof value !== "object" || value === null) return false;
  const candidate = value as Record<string, unknown>;
  return INSTRUCTION_LANGUAGES.every((language) => {
    const entry = candidate[language];
    return entry === null || entry === undefined || typeof entry === "string";
  });
}

export function normalizeVoiceIds(
  value: unknown,
): Record<InstructionLanguage, string | null> {
  if (!isVoiceIdMap(value)) return { ...DEFAULT_CAMERA_SETTINGS.voiceIds };
  const candidate = value as Record<string, string | null | undefined>;
  return {
    en: candidate.en ?? null,
    hi: candidate.hi ?? null,
  };
}

/**
 * Resolves the instruction language of a persisted payload.
 *
 * Precedence — and the reason for each step:
 *   1. a valid `instructionLanguage`      → the user's current, explicit choice;
 *   2. a valid legacy `voiceLanguage`     → the same choice under its old name;
 *   3. the default (Hindi)                → no usable preference = fresh install.
 *
 * An INVALID value at either key is treated as absent rather than repaired
 * into the other key's value: guessing between two stored languages would be
 * inventing a preference the user never expressed.
 */
export function resolvePersistedInstructionLanguage(
  persisted: PersistedCameraSettings,
): InstructionLanguage {
  return (
    knownLanguage(persisted.instructionLanguage) ??
    knownLanguage(persisted.voiceLanguage) ??
    DEFAULT_CAMERA_SETTINGS.instructionLanguage
  );
}

/**
 * Migrates any persisted settings payload to the current version.
 *
 * Total and non-destructive: unknown/unrelated keys survive, the legacy
 * language key is dropped only AFTER its value has been carried forward, and
 * a malformed `voiceIds` map is repaired instead of crashing hydration.
 */
export function migrateCameraSettings(
  persisted: unknown,
  _version: number,
): PersistedCameraSettings {
  const state: PersistedCameraSettings =
    typeof persisted === "object" && persisted !== null
      ? { ...(persisted as PersistedCameraSettings) }
      : {};

  const instructionLanguage = resolvePersistedInstructionLanguage(state);
  const voiceIds = normalizeVoiceIds(state.voiceIds);

  /* Unit 38 — a boolean is trusted only when it IS a boolean. Anything else
     (absent, null, a string from a hand-edited payload) is "no opinion
     expressed", which is the default, not a failure. */
  const volumeShutterEnabled =
    typeof state.volumeShutterEnabled === "boolean"
      ? state.volumeShutterEnabled
      : DEFAULT_CAMERA_SETTINGS.volumeShutterEnabled;

  const migrated: Record<string, unknown> = {
    ...state,
    instructionLanguage,
    voiceIds,
    volumeShutterEnabled,
  };
  /* The old key is removed only now that its meaning has been preserved, so
     a later hydration cannot resurrect a stale language. */
  delete migrated.voiceLanguage;

  return migrated as PersistedCameraSettings;
}
