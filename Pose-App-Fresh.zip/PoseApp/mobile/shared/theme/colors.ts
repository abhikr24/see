/**
 * shared/theme/colors.ts — THE BRAIN (platform-neutral, no RN, no DOM).
 * Single source of truth for color across the Expo app AND the preview
 * mirror. Exact HEX values originate in context/specs/01-project-setup-
 * design-tokens.md. Nothing else in the codebase may hardcode a color.
 */

export interface ColorScheme {
  readonly primary: string;
  readonly primaryPressed: string;
  readonly primaryLight: string;
  readonly success: string;
  readonly warning: string;
  readonly error: string;
  readonly background: string;
  readonly backgroundSecondary: string;
  readonly surface: string;
  readonly surfaceRaised: string;
  readonly divider: string;
  readonly textPrimary: string;
  readonly textSecondary: string;
  readonly textDisabled: string;
  readonly textOnPrimary: string;
  readonly cameraOverlay: string;
  readonly scrim: string;
  /** Shadow color for the elevation scale (premium-pass item 7). */
  readonly shadowColor: string;
  /** Pressed fill for tinted (secondary) buttons — pressed-darken (item 6). */
  readonly primaryLightPressed: string;
  /** Pressed fill wash for ghost/outline buttons (item 6). */
  readonly ghostPressed: string;
  /** Pressed fill for neutral cards, tiles and list rows (item 6). */
  readonly surfacePressed: string;
}

export const lightColors: ColorScheme = {
  primary: "#2563EB",
  primaryPressed: "#1D4ED8",
  primaryLight: "#DBEAFE",
  success: "#10B981",
  warning: "#F59E0B",
  error: "#EF4444",
  background: "#FFFFFF",
  backgroundSecondary: "#F8FAFC",
  surface: "#FFFFFF",
  surfaceRaised: "#FFFFFF",
  divider: "#E5E7EB",
  textPrimary: "#111827",
  textSecondary: "#6B7280",
  textDisabled: "#9CA3AF",
  textOnPrimary: "#FFFFFF",
  cameraOverlay: "rgba(0,0,0,0.4)",
  scrim: "rgba(17,24,39,0.42)",
  shadowColor: "#0F172A",
  primaryLightPressed: "#BFDBFE",
  ghostPressed: "rgba(37,99,235,0.08)",
  surfacePressed: "#F1F5F9",
};

export const darkColors: ColorScheme = {
  primary: "#3B82F6",
  primaryPressed: "#2563EB",
  primaryLight: "rgba(59,130,246,0.18)",
  success: "#34D399",
  warning: "#FBBF24",
  error: "#F87171",
  background: "#0F172A",
  backgroundSecondary: "#1E293B",
  surface: "#1E293B",
  surfaceRaised: "#263348",
  divider: "#334155",
  textPrimary: "#F1F5F9",
  textSecondary: "#94A3B8",
  textDisabled: "#64748B",
  textOnPrimary: "#FFFFFF",
  cameraOverlay: "rgba(0,0,0,0.4)",
  scrim: "rgba(2,6,23,0.62)",
  shadowColor: "#000000",
  primaryLightPressed: "rgba(59,130,246,0.30)",
  ghostPressed: "rgba(59,130,246,0.12)",
  surfacePressed: "#334155",
};

/** Scheme-independent colors used on photography/media surfaces. */
export const mediaColors = {
  transparent: "transparent",
  /** Viewfinder backdrop: always true black in both schemes, never themed. */
  viewfinder: "#000000",
  text: "#FFFFFF",
  textMuted: "rgba(255,255,255,0.85)",
  textSubtle: "rgba(255,255,255,0.60)",
  overlaySubtle: "rgba(0,0,0,0.08)",
  overlaySoft: "rgba(0,0,0,0.18)",
  overlayMedium: "rgba(0,0,0,0.35)",
  overlayStrong: "rgba(0,0,0,0.45)",
  /** Processing/countdown/preview bars: exact 60% camera scrim from spec. */
  overlayHeavy: "rgba(0,0,0,0.60)",
  whiteSubtle: "rgba(255,255,255,0.08)",
  whiteSoft: "rgba(255,255,255,0.16)",
  whiteMuted: "rgba(255,255,255,0.25)",
  ringLight: "rgba(255,255,255,0.55)",
  ringDark: "rgba(255,255,255,0.10)",
  glyphLight: "rgba(255,255,255,0.90)",
  glyphDark: "rgba(255,255,255,0.28)",
  shadow: "#000000",
  premium: "#F59E0B",
  premiumText: "#D97706",
  premiumLight: "rgba(245,158,11,0.15)",
  premiumGold: "#FCD34D",
} as const;

/**
 * Gradient stops (premium-pass item 8). Two gradient families only:
 * `brand` for hero moments (home hero, signature CTAs, splash mark) and
 * `scrim` for media surfaces (camera/viewfinder edges, photo chrome).
 * Scheme-aware accessors live in shared/theme/gradients.ts.
 */
export const brandGradient = {
  light: ["#2563EB", "#1D4ED8"] as const,
  dark: ["#3B82F6", "#2563EB"] as const,
};

/** Deepened brand gradient used while a gradient CTA is pressed (item 6). */
export const brandGradientPressed = {
  light: ["#1D4ED8", "#1E40AF"] as const,
  dark: ["#2563EB", "#1D4ED8"] as const,
};

/** Splash backdrop: brand tint bleeding into the screen background. */
export const splashGradient = {
  light: ["#EFF6FF", "#FFFFFF"] as const,
  dark: ["#172554", "#0F172A"] as const,
};

/**
 * LOOKS — the filter-tile swatches.
 *
 * A filter tile must show the LOOK, not the word. `expo-camera` hands
 * JavaScript no live frames, so a real thumbnail of the user's own scene is
 * impossible on this foundation; the honest alternative is a fixed two-stop
 * gradient per look, generated once from that look's own colour matrix
 * (`shared/camera/cameraFilters`) applied to a neutral skin-and-sky pair.
 * They are therefore a truthful picture of what the matrix does, and they are
 * scheme-independent because the strip only ever sits on the viewfinder.
 *
 * Keep the keys in sync with `CAMERA_FILTER_IDS`.
 */
export const filterSwatchGradient = {
  original: ["#8D9AAE", "#3C4757"] as const,
  vivid: ["#FF9E4F", "#1F4FD8"] as const,
  warm: ["#FFC27A", "#B9552B"] as const,
  cool: ["#9FD8FF", "#2B4FB9"] as const,
  bw: ["#E8E8E8", "#2A2A2A"] as const,
};

/* D2: the hand-picked `filterWashColors` tints that used to live here are
   GONE — a second, unmaintained filter definition measured ~3× too strong for
   warm/cool and pointed the wrong way for vivid. The live-viewfinder veil is
   now computed by constrained least-squares projection of the canonical look
   matrix itself (`shared/camera/cameraFilters.filterPreviewOverlay`), so the
   tint can never drift from the look it previews. Nothing to token. */

/** Viewfinder edges, always scheme-independent true-black scrims. */
export const scrimGradient = {
  /** Top edge: strong at the bezel, clear where the subject sits. */
  top: ["rgba(0,0,0,0.55)", "rgba(0,0,0,0)"] as const,
  /** Bottom edge: clear under the pose, strong behind the controls. */
  bottom: ["rgba(0,0,0,0)", "rgba(0,0,0,0.6)"] as const,
};

/** Match-% color ramp (AI guidance): locked by the spec, do not reorder. */
export interface MatchBand {
  readonly min: number;
  readonly max: number;
  readonly label: string;
  readonly color: string;
}

export const MATCH_COLOR_BANDS: readonly MatchBand[] = [
  { min: 0, max: 39, label: "Keep adjusting", color: "#EF4444" },
  { min: 40, max: 69, label: "Getting there", color: "#F59E0B" },
  { min: 70, max: 89, label: "Almost perfect", color: "#2563EB" },
  { min: 90, max: 100, label: "Perfect match", color: "#10B981" },
] as const;

export function matchColorFor(percent: number): string {
  const band =
    MATCH_COLOR_BANDS.find((b) => percent >= b.min && percent <= b.max) ??
    MATCH_COLOR_BANDS[0];
  return band?.color ?? lightColors.error;
}

/* ── Silhouette contour ramp (hollow vector guide) ───────────────────────
 * iOS-camera framing-guide palette driving the live-match feedback on the
 * hollow pose-guide boundary ONLY (thin stroke + glow halo). The locked
 * MATCH_COLOR_BANDS above still own the on-screen match-% pill — the two
 * ramps coexist by design: the contour treats ≥85% as the locked state with
 * a glow pulse, per the contour-guide spec.
 */
export interface SilhouetteContourBand {
  /** Inclusive lower bound of the live match % (0..100 float). */
  readonly min: number;
  /** Exclusive upper bound — gaps are impossible by construction. */
  readonly max: number;
  readonly label: string;
  readonly color: string;
  /** Contour stroke/glow opacity while the live score sits in this band. */
  readonly opacity: number;
  /** True only for the locked band (>85%): the contour pulses subtly. */
  readonly pulse: boolean;
}

export const SILHOUETTE_CONTOUR_BANDS: readonly SilhouetteContourBand[] = [
  { min: 0, max: 40, label: "Keep adjusting", color: "#FF3B30", opacity: 0.4, pulse: false },
  { min: 40, max: 70, label: "Getting there", color: "#FF9500", opacity: 0.6, pulse: false },
  { min: 70, max: 85, label: "Almost locked", color: "#007AFF", opacity: 0.8, pulse: false },
  { min: 85, max: 101, label: "Locked", color: "#34C759", opacity: 1.0, pulse: true },
] as const;

/** Idle contour opacity before the first scored frame (platform tint used). */
export const SILHOUETTE_CONTOUR_IDLE_OPACITY = 0.6;

export interface SilhouetteContourStyle {
  readonly color: string;
  readonly opacity: number;
  readonly pulse: boolean;
}

/**
 * The single match-% → contour-style decision point, mirroring
 * matchColorFor() for the boundary layer. `percent === null` (no scored
 * frame yet) renders the caller's neutral token at idle opacity, unpulsed.
 */
export function silhouetteContourStyle(
  percent: number | null,
  idleColor: string,
  bands: readonly SilhouetteContourBand[] = SILHOUETTE_CONTOUR_BANDS,
): SilhouetteContourStyle {
  if (percent === null) {
    return {
      color: idleColor,
      opacity: SILHOUETTE_CONTOUR_IDLE_OPACITY,
      pulse: false,
    };
  }
  const band = bands.find((b) => percent >= b.min && percent < b.max) ?? bands[0];
  return {
    color: band?.color ?? idleColor,
    opacity: band?.opacity ?? SILHOUETTE_CONTOUR_IDLE_OPACITY,
    pulse: band?.pulse ?? false,
  };
}
