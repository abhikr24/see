/**
 * shared/theme/elevation.ts — ELEVATION SCALE (platform-neutral tokens).
 *
 * Premium-pass item 7: three shadow levels and no others. Every surface in
 * the product reads its depth from this scale — hand-written shadows are a
 * design bug. Shadow *color* is scheme-aware (shadowColor in colors.ts);
 * geometry is fixed. RN style objects and CSS box-shadow strings are both
 * derived here so the Expo app and the preview mirror stay identical.
 */
import type { ColorScheme } from "./colors";

export type ElevationLevel = "resting" | "floating" | "overlay";
/** Surfaces may cast light downward (default) or upward (bottom tab bar). */
export type ElevationDirection = "down" | "up";

interface ElevationSpec {
  readonly offsetY: number;
  readonly blurRadius: number;
  readonly opacity: number;
  readonly androidElevation: number;
}

/**
 * Level 1 `resting` — cards and tiles sitting on the background.
 * Level 2 `floating` — tab bar, hero card, elements that lift on press.
 * Level 3 `overlay` — dialogs, pills and sheets above media.
 */
export const ELEVATION: Record<ElevationLevel, ElevationSpec> = {
  resting: { offsetY: 2, blurRadius: 8, opacity: 0.07, androidElevation: 2 },
  floating: { offsetY: 6, blurRadius: 16, opacity: 0.11, androidElevation: 6 },
  overlay: { offsetY: 12, blurRadius: 28, opacity: 0.16, androidElevation: 12 },
} as const;

export interface RNElevationStyle {
  readonly shadowColor: string;
  readonly shadowOffset: { readonly width: number; readonly height: number };
  readonly shadowOpacity: number;
  readonly shadowRadius: number;
  readonly elevation: number;
}

/** React Native style object for the level, using the scheme shadow color. */
export function elevationStyle(
  level: ElevationLevel,
  colors: ColorScheme,
  direction: ElevationDirection = "down",
): RNElevationStyle {
  const spec = ELEVATION[level];
  return {
    shadowColor: colors.shadowColor,
    shadowOffset: {
      width: 0,
      height: direction === "up" ? -spec.offsetY : spec.offsetY,
    },
    shadowOpacity: spec.opacity,
    shadowRadius: spec.blurRadius,
    elevation: spec.androidElevation,
  };
}

function hexToRgb(hex: string): readonly [number, number, number] {
  const normalized = hex.replace("#", "");
  const full =
    normalized.length === 3
      ? normalized
          .split("")
          .map((c) => c + c)
          .join("")
      : normalized;
  const value = Number.parseInt(full, 16);
  if (Number.isNaN(value)) return [0, 0, 0];
  return [(value >> 16) & 255, (value >> 8) & 255, value & 255];
}

/** CSS box-shadow string for the preview mirror, derived from the same spec. */
export function elevationBoxShadow(
  level: ElevationLevel,
  colors: ColorScheme,
  direction: ElevationDirection = "down",
): string {
  const spec = ELEVATION[level];
  const [r, g, b] = hexToRgb(colors.shadowColor);
  const y = direction === "up" ? -spec.offsetY : spec.offsetY;
  return `0 ${y}px ${spec.blurRadius}px rgba(${r},${g},${b},${spec.opacity})`;
}
