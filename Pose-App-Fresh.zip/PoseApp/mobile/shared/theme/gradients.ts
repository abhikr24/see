/**
 * shared/theme/gradients.ts — GRADIENT ACCESSORS (platform-neutral).
 *
 * Premium-pass item 8: the raw stops are literal tokens in colors.ts; this
 * module resolves them per scheme and builds CSS strings for the preview
 * mirror. RN surfaces pass the stop arrays straight to expo-linear-gradient.
 */
import {
  brandGradient,
  brandGradientPressed,
  scrimGradient,
  splashGradient,
} from "./colors";

export type GradientScheme = "light" | "dark";

/** A gradient always carries at least two stops (expo-linear-gradient contract). */
export type GradientStops = readonly [string, string, ...string[]];

/** Brand gradient for hero moments: home hero, signature CTA, splash mark. */
export function brandGradientFor(scheme: GradientScheme): GradientStops {
  return brandGradient[scheme];
}

/** Deepened brand gradient while a gradient CTA is pressed (item 6). */
export function brandGradientPressedFor(scheme: GradientScheme): GradientStops {
  return brandGradientPressed[scheme];
}

/** Splash backdrop: brand tint bleeding into the background color. */
export function splashGradientFor(scheme: GradientScheme): GradientStops {
  return splashGradient[scheme];
}

/** Media scrim for a viewfinder edge (`top` fades down, `bottom` fades up). */
export function scrimGradientFor(edge: "top" | "bottom"): GradientStops {
  return scrimGradient[edge];
}

/* ── CSS companions (preview mirror consumes identical stops) ───────────── */

export function cssLinearGradient(
  stops: readonly string[],
  angleDeg: number,
): string {
  return `linear-gradient(${angleDeg}deg, ${stops.join(", ")})`;
}

export function cssBrandGradient(scheme: GradientScheme, angleDeg = 135): string {
  return cssLinearGradient(brandGradient[scheme], angleDeg);
}

export function cssBrandGradientPressed(scheme: GradientScheme, angleDeg = 135): string {
  return cssLinearGradient(brandGradientPressed[scheme], angleDeg);
}

export function cssSplashGradient(scheme: GradientScheme): string {
  return cssLinearGradient(splashGradient[scheme], 180);
}

export function cssScrimTop(): string {
  return cssLinearGradient(scrimGradient.top, 180);
}

export function cssScrimBottom(): string {
  return cssLinearGradient(scrimGradient.bottom, 180);
}
