/**
 * shared/theme/motion.ts — MOTION TOKENS (platform-neutral, no RN, no DOM).
 *
 * The named motion language (premium-pass items 1 & 5): three durations and
 * one shared easing curve, so no two animations in the app ever disagree,
 * plus the spring vocabulary every animated press/entrance derives from.
 * Nothing else in the codebase may invent a duration, easing, or spring for
 * interaction feedback. CSS string companions are exported so the browser
 * preview mirror consumes the exact same language.
 */

/** The only three durations the product is allowed to use. */
export const motionDuration = {
  /** Micro feedback on touch-down / release. */
  tap: 120,
  /** Element changes (sheets, pills, state swaps). */
  standard: 250,
  /** Entrances and signature moments. */
  expressive: 450,
} as const;

/** One shared easing curve family — raw cubic-bezier control points. */
export const motionEase = {
  /** Default curve for everything unless a spring applies. */
  standard: [0.2, 0.8, 0.2, 1] as const,
  /** Settling curve for entrances. */
  entrance: [0.16, 1, 0.3, 1] as const,
  /** Accelerating curve for exits. */
  exit: [0.4, 0, 1, 1] as const,
} as const;

export interface SpringSpec {
  readonly damping: number;
  readonly stiffness: number;
  readonly mass: number;
}

/**
 * Spring vocabulary. `snappy` drives small controls, `gentle` drives sheets
 * and cards, `bouncy` is reserved for delight moments, and `pressRelease`
 * exists solely for the release half of an animated press (slight
 * overshoot as the finger lifts).
 */
export const motionSpring: Record<string, SpringSpec> = {
  snappy: { damping: 20, stiffness: 400, mass: 0.7 },
  gentle: { damping: 24, stiffness: 220, mass: 1 },
  bouncy: { damping: 12, stiffness: 320, mass: 0.9 },
  pressRelease: { damping: 13, stiffness: 420, mass: 0.6 },
} as const;

/** Canonical press targets for the animated press language (item 5). */
export const pressMotion = {
  /** Buttons and compact controls. */
  scale: 0.96,
  /** Large cards — deep press would feel rubbery, so barely dip. */
  cardScale: 0.99,
  /** Toolbar / camera control icons. */
  controlScale: 0.92,
} as const;

/* ── CSS companions (preview mirror consumes the identical language) ────── */

function toCssBezier(points: readonly [number, number, number, number]): string {
  return `cubic-bezier(${points.join(", ")})`;
}

export const cssEase = {
  standard: toCssBezier([...motionEase.standard]),
  entrance: toCssBezier([...motionEase.entrance]),
  exit: toCssBezier([...motionEase.exit]),
} as const;

/** Spring-approximating CSS curves (overshoot baked in, mirroring the RN springs). */
export const cssSpring = {
  snappy: "cubic-bezier(0.3, 1.4, 0.5, 1)",
  gentle: "cubic-bezier(0.25, 1.15, 0.4, 1)",
  bouncy: "cubic-bezier(0.34, 1.56, 0.64, 1)",
} as const;
