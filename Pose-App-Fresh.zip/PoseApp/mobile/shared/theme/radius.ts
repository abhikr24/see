/**
 * shared/theme/radius.ts — corner radius tokens. Platform-neutral.
 * Locked in Unit 01 spec: xs4 sm8 md12(btn) lg16(card) xl20(bottom nav) xxl24 pill999 circle.
 */
export const radius = {
  none: 0,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  pill: 999,
  circle: 9999,
} as const;

export type RadiusKey = keyof typeof radius;
