/** Shared sizing tokens for icons and minimum interactive targets. */
export const sizing = {
  iconSmall: 16,
  iconDefault: 24,
  iconCamera: 28,
  iconFeature: 32,
  iconEmpty: 48,
  touchTarget: 48,
  countdownNumber: 96,
  cameraBottomBar: 120,
  cameraCaptureOuter: 72,
  cameraCaptureInner: 60,
  cameraHoldProgressWidth: 120,
  /* LOOKS zone heights — the one source of truth for the vertical stack the
     camera screen derives (zoom row + coaching band sit on TOP of this zone).
     Values match FilterStrip's swatch rail and strength track exactly. */
  cameraFilterStrip: 74,
  cameraFilterStrength: 40,
} as const;
