/**
 * shared/theme/spacing.ts — 8pt grid. Platform-neutral tokens.
 * Locked in Unit 01 spec: xs4 sm8 md12 lg16 xl24 xxl32 xxxl48 section64.
 */
export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
  section: 64,
} as const;

export type SpacingKey = keyof typeof spacing;
