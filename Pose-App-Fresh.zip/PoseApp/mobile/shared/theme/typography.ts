/**
 * shared/theme/typography.ts — Inter type scale. Platform-neutral.
 * The Expo app maps these to loaded Inter fonts; the preview mirror maps
 * them to CSS font stacks. Max 4 type sizes per screen (spec rule).
 */
export interface TypeStyle {
  readonly fontSize: number;
  readonly lineHeight: number;
  readonly fontWeight: "regular" | "medium" | "semiBold" | "bold";
}

export const typeScale = {
  display: { fontSize: 32, lineHeight: 40, fontWeight: "bold" },
  title: { fontSize: 28, lineHeight: 36, fontWeight: "bold" },
  heading: { fontSize: 22, lineHeight: 28, fontWeight: "semiBold" },
  cardTitle: { fontSize: 18, lineHeight: 24, fontWeight: "semiBold" },
  body: { fontSize: 16, lineHeight: 24, fontWeight: "regular" },
  secondaryBody: { fontSize: 14, lineHeight: 20, fontWeight: "regular" },
  small: { fontSize: 12, lineHeight: 16, fontWeight: "regular" },
  button: { fontSize: 16, lineHeight: 24, fontWeight: "semiBold" },
  navLabel: { fontSize: 10, lineHeight: 12, fontWeight: "semiBold" },
} as const satisfies Record<string, TypeStyle>;

export type TypeVariant = keyof typeof typeScale;

export const fontFamily = {
  regular: "Inter_400Regular",
  medium: "Inter_500Medium",
  semiBold: "Inter_600SemiBold",
  bold: "Inter_700Bold",
} as const;
