/**
 * shared/types/index.ts — platform-neutral domain types (Units 01–08).
 * Consumed by the Expo app (mobile/) and the preview mirror (src/).
 * Zero RN, zero DOM imports in this folder — pure TypeScript.
 */

export type ThemeMode = "system" | "light" | "dark";

export type TabKey = "home" | "explore" | "camera" | "gallery" | "profile";

export type Difficulty = "beginner" | "intermediate" | "advanced";

/** Recent/history pose entry with last used timestamp (Unit 15). */
export interface RecentPoseRecord {
  readonly poseId: string;
  readonly lastUsed: number;
}

/**
 * The 12 pose categories (Unit 05 data layer). IDs are stable strings so
 * catalogs, URLs and MMKV entries survive renames of display labels.
 */
export type PoseCategoryId =
  | "portraits"
  | "couples"
  | "family"
  | "wedding"
  | "fashion"
  | "street"
  | "fitness"
  | "dance"
  | "travel"
  | "kids"
  | "group"
  | "creative";

/** Pose entity — matches context/specs/05-pose-library-local-data-layer.md */
export interface Pose {
  readonly id: string;
  readonly title: string;
  readonly category: PoseCategoryId;
  readonly subCategory: string;
  readonly difficulty: Difficulty;
  readonly tags: readonly string[];
  readonly description: string;
  readonly tips: readonly string[];
  readonly imageUrl: string | null;
  readonly thumbnailUrl: string | null;
  readonly localAssetPath: string | null;
  readonly isPremium: boolean;
  readonly isFeatured: boolean;
  readonly referenceAngles: Readonly<Record<string, number>> | null;
  /**
   * Unit 25: real measured 33-landmark reference pose, captured by the
   * Template Scanner or licensed photography. Null/absent for the bundled
   * catalog today — `resolvePoseSilhouette()` automatically upgrades the
   * camera guide from a generic library silhouette to a custom-traced
   * outline the moment a datasource hydrates this field.
   */
  readonly referenceLandmarks?: readonly {
    readonly x: number;
    readonly y: number;
    readonly z?: number;
    readonly visibility?: number;
  }[] | null;
  /** MediaPipe match % needed before auto-capture can fire (spec: 90 default). */
  readonly matchTarget: number;
  /** Deterministic seed used to render category-tinted placeholder art. */
  readonly colorSeed: number;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface PoseCategoryMeta {
  readonly id: PoseCategoryId;
  readonly label: string;
  /** MaterialCommunityIcons name in the app; mapped to Lucide in the mirror. */
  readonly icon: string;
  /** Hue used for the on-brand tinted card art of this category. */
  readonly hue: number;
  readonly tagline: string;
}

export interface CategorySummary extends PoseCategoryMeta {
  readonly count: number;
  readonly coverPoseId: string;
}

export type { PermissionKind, PermissionStatus } from "./permissions";
