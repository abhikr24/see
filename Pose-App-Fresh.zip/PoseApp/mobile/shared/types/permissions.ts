export type PermissionKind = "camera" | "photos";
export type PermissionStatus =
  | "undetermined"
  | "granted"
  | "denied"
  | "deniedForever";
