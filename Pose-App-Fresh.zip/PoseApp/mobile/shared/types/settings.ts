/**
 * shared/types/settings.ts — Unit 20 Camera & Capture Settings types (platform-neutral).
 * Pure TypeScript — no RN, no DOM.
 */

export type FlashDefault = 'off' | 'auto' | 'on';
export type TimerDefault = 0 | 3 | 5 | 10;
export type FilterDefault = 'original' | 'vivid' | 'warm' | 'cool' | 'bw';
export type AutoThreshold = 80 | 85 | 90 | 95;
export type CountdownDuration = 3 | 5;

/**
 * Unit 37 (Part 4.6) — INSTRUCTION LANGUAGE.
 *
 * The language the COACHING COMMUNICATES IN: the words of the live on-screen
 * coaching band AND the words the coach speaks. 'hi' covers Hindi and the
 * Hinglish register the phrase bank is authored in; 'en' is studio English.
 *
 * DELIBERATELY NOT:
 *   · the application UI language (menus, settings, navigation stay English
 *     in V1 — see docs/unit-37-instruction-language.md);
 *   · the device locale;
 *   · the TTS VOICE IDENTITY — that is `voiceIds`, a separate setting which
 *     answers "which installed voice renders it", not "what language is it";
 *   · an account/profile language.
 */
export type InstructionLanguage = 'en' | 'hi';

/**
 * @deprecated Unit 27 name kept as an alias for the one release in which
 * persisted stores may still carry the old `voiceLanguage` key. It always
 * meant the coaching language, never a voice identity — the new name says
 * so. Prefer `InstructionLanguage`.
 */
export type VoiceLanguage = InstructionLanguage;

export interface CameraSettings {
  readonly flashDefault: FlashDefault;
  readonly timerDefault: TimerDefault;
  readonly filterDefault: FilterDefault;
  readonly gridOverlayEnabled: boolean;
  readonly autoThreshold: AutoThreshold;
  readonly voiceEnabled: boolean;
  readonly gestureEnabled: boolean;
  readonly countdownDuration: CountdownDuration;
  readonly hapticEnabled: boolean;
  /**
   * Unit 37 (Part 4.6): the language the COACHING is delivered in — the
   * visible coaching band and the spoken cue, always together. The rest of
   * the interface (settings, tabs, navigation) stays English in V1: this
   * field is not an app-localization switch.
   *
   * Renamed from `voiceLanguage` (Unit 27), which controlled exactly the
   * same thing but read as if it only meant speech. The store migrates the
   * old key forward; nothing is reset.
   */
  readonly instructionLanguage: InstructionLanguage;
  /**
   * Unit 35 (Part 4.4): persisted TTS VOICE IDENTITY preference, PER
   * INSTRUCTION LANGUAGE. This is the "Voice" setting — WHICH installed
   * voice renders the coaching — and is conceptually distinct from
   * `instructionLanguage`, which decides WHAT LANGUAGE the coaching is in.
   *
   * The value is a device-reported voice identifier or null = automatic
   * (the app ranks the live catalog). It is stored per language because a
   * Hindi pick is meaningless for English speech and vice versa; switching
   * language must not silently reuse the other language's voice.
   *
   * An identifier here is only ever a REMEMBERED CHOICE, never proof the
   * voice still exists: resolution always happens against the runtime
   * catalog (shared/voice/voiceSelection), which falls back safely when the
   * pack was uninstalled or the phone changed.
   */
  readonly voiceIds: Readonly<Record<InstructionLanguage, string | null>>;
  /**
   * VOLUME-BUTTON SHUTTER (Unit 38): may the app take over the physical
   * volume keys while the live viewfinder is on screen?
   *
   * ON by default, because that is the behaviour every stock camera app on
   * the phone already has and the one a user reaches for without being
   * taught. It is a SETTING and not a hard-coded behaviour for two honest
   * reasons: consuming a volume key denies the user their volume for as
   * long as the viewfinder is up, and some users (tripod + Bluetooth remote,
   * or anyone who adjusts media volume while framing) legitimately want the
   * keys to stay keys.
   *
   * OFF means the keys are never intercepted at all — not swallowed, not
   * observed, not "handled and passed through".
   *
   * The setting is honoured on every platform; whether the CAPABILITY
   * exists is a separate question answered by
   * `shared/camera/hardwareShutter.resolveHardwareShutterCapability`.
   */
  readonly volumeShutterEnabled: boolean;
}

export const DEFAULT_CAMERA_SETTINGS: CameraSettings = {
  flashDefault: 'off',
  timerDefault: 0,
  filterDefault: 'original',
  gridOverlayEnabled: false,
  autoThreshold: 90,
  voiceEnabled: true,
  gestureEnabled: true,
  countdownDuration: 3,
  hapticEnabled: true,
  /**
   * Unit 37: a FRESH INSTALL coaches in Hindi/Hinglish. The product's first
   * audience is an Indian photography session, and the Hindi bank is the
   * fuller, more natural one. An existing install keeps whatever the user
   * already chose — the store migration carries the old value forward.
   */
  instructionLanguage: 'hi',
  voiceIds: { en: null, hi: null },
  /* Unit 38 — the stock-camera behaviour is the default behaviour. */
  volumeShutterEnabled: true,
} as const;

export const FLASH_OPTIONS: readonly { readonly value: FlashDefault; readonly label: string }[] = [
  { value: 'off', label: 'Off' },
  { value: 'auto', label: 'Auto' },
  { value: 'on', label: 'On' },
];

export const TIMER_OPTIONS: readonly { readonly value: TimerDefault; readonly label: string }[] = [
  { value: 0, label: 'Off' },
  { value: 3, label: '3 seconds' },
  { value: 5, label: '5 seconds' },
  { value: 10, label: '10 seconds' },
];

export const FILTER_OPTIONS: readonly { readonly value: FilterDefault; readonly label: string }[] = [
  { value: 'original', label: 'Original' },
  { value: 'vivid', label: 'Vivid' },
  { value: 'warm', label: 'Warm' },
  { value: 'cool', label: 'Cool' },
  { value: 'bw', label: 'B&W' },
];

export const AUTO_THRESHOLD_OPTIONS: readonly { readonly value: AutoThreshold; readonly label: string }[] = [
  { value: 80, label: '80% Match' },
  { value: 85, label: '85% Match' },
  { value: 90, label: '90% Match (Recommended)' },
  { value: 95, label: '95% Match (Strict)' },
];

export const COUNTDOWN_OPTIONS: readonly { readonly value: CountdownDuration; readonly label: string }[] = [
  { value: 3, label: '3 seconds' },
  { value: 5, label: '5 seconds' },
];

/**
 * Unit 37 — the user-facing choice for the **Instruction Language** setting.
 *
 * Hindi is listed first because it is the default; the label is written in
 * the language itself (with the English name alongside) so the option is
 * readable to a user who cannot read the other script.
 */
export const INSTRUCTION_LANGUAGE_OPTIONS: readonly {
  readonly value: InstructionLanguage;
  readonly label: string;
}[] = [
  { value: 'hi', label: 'हिंदी / Hinglish' },
  { value: 'en', label: 'English' },
];

/** @deprecated Unit 27 name — use `INSTRUCTION_LANGUAGE_OPTIONS`. */
export const VOICE_LANGUAGE_OPTIONS = INSTRUCTION_LANGUAGE_OPTIONS;

/**
 * The instruction language a brand-new install starts on (Hindi).
 *
 * DELIBERATELY one concept, not two:
 *   · FRESH-INSTALL default — this value, applied when a user has never
 *     expressed a preference.
 *   · INVALID / UNREADABLE persisted value — handled by the ONE canonical
 *     gate (`resolveInstructionLanguage` in shared/voice/locales), whose
 *     documented fallback is this same value today. The two are linked by
 *     product decision, not by type coincidence: see
 *     UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK.
 */
export const DEFAULT_INSTRUCTION_LANGUAGE: InstructionLanguage =
  DEFAULT_CAMERA_SETTINGS.instructionLanguage;
