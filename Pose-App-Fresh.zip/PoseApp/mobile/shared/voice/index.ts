/**
 * shared/voice/index.ts — Unit 35 (Part 4.4) barrel: LANGUAGE + VOICE.
 *
 *   semantic coaching state
 *     → routing.ts        (may we speak? in which language?)
 *     → phrase selection  (shared/coaching/phraseSelection)
 *     → voiceSelection.ts (which real, device-reported voice?)
 *     → TTS               (mobile/src/core/voice/ttsService — execution only)
 *
 * Pure, deterministic, platform-neutral. No expo-speech, no DOM speech API,
 * no storage, no React: the device and the preview mirror both consume these
 * same functions, which is why their language behaviour matches.
 */
export * from "./locales";
export * from "./voiceSelection";
export * from "./routing";
export * from "./prosody";
