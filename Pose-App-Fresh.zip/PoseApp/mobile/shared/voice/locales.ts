/**
 * shared/voice/locales.ts — Unit 35 (Part 4.4): THE ONE PLACE THAT KNOWS
 * WHICH DEVICE LOCALES BELONG TO A COACHING LANGUAGE.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo-speech, zero network.
 * The speech engines (expo-speech on device, the browser mirror in
 * tooling/preview) both read these tables instead of hardcoding
 * `'hi-IN'` / `'en-US'` at the call site, so language routing cannot drift
 * between the two runtimes.
 *
 *   semantic state → LANGUAGE (here) → phrase pool → voice → TTS
 *
 * Nothing in this file claims a locale is *installed*: it only states which
 * locale tags would satisfy a coaching language, in preference order. Which
 * of them actually exists is answered exclusively by the runtime voice
 * catalog (see voiceSelection.ts).
 */
import type { InstructionLanguage } from "../constants/poseInstructions";
import { DEFAULT_INSTRUCTION_LANGUAGE } from "../types/settings";

/** Every coaching language the phrase banks are authored for. */
export const INSTRUCTION_LANGUAGES: readonly InstructionLanguage[] = ["en", "hi"];

/**
 * Re-exported so the language layer has ONE import surface: callers that
 * resolve a language also need to know what "no preference" means.
 */
export { DEFAULT_INSTRUCTION_LANGUAGE } from "../types/settings";

/**
 * Locale fallback chain per coaching language — regional first, then the
 * generic tag the OS default engine understands.
 *
 * `hi` covers Hindi AND Hinglish copy: Hinglish lines are Latin-script Hindi
 * and are pronounced correctly only by a Hindi voice, so they share the
 * chain deliberately.
 */
export const VOICE_LANGUAGE_LOCALES: Readonly<
  Record<InstructionLanguage, readonly string[]>
> = {
  hi: ["hi-IN", "hi"],
  en: ["en-IN", "en-US", "en-GB", "en"],
};

/**
 * Unit 36 (Part 4.5) — THE defensive table lookup.
 *
 * `InstructionLanguage` is a compile-time promise, not a runtime one: the
 * value ultimately comes from a PERSISTED preference (MMKV), so a corrupted
 * or migrated store can hand these pure functions a string the table has no
 * row for. Indexing the table directly therefore threw a TypeError inside
 * the frame loop — a crash, not a degradation at all. Every table read goes
 * through here, which delegates to the ONE canonical language gate
 * (`resolveInstructionLanguage`), so an untrusted value degrades exactly
 * once, in one place, and always the same way.
 */
function localeChainFor(language: InstructionLanguage): readonly string[] {
  return (
    VOICE_LANGUAGE_LOCALES[language] ??
    VOICE_LANGUAGE_LOCALES[resolveInstructionLanguage(language)]
  );
}

/** The locale handed to the engine when no catalog voice is selected. */
export function primaryLocaleFor(language: InstructionLanguage): string {
  return localeChainFor(language)[0] ?? "en-US";
}

/**
 * Normalizes an OS-reported locale tag.
 *
 * Android TTS engines are NOT consistent: the same voice can be reported as
 * `hi-IN`, `hi_IN`, `hin-IND` or `HI-in` depending on engine and API level,
 * and iOS reports `en-IN`. Normalizing here (lowercase, `_`→`-`, ISO-639-2
 * → ISO-639-1 for the languages we speak) is what stops a perfectly valid
 * Hindi voice from being classified "mismatch" and silently dropped.
 *
 * Unknown tags are lowercased and returned untouched — never rewritten into
 * something the device did not say.
 */
export function normalizeVoiceLocale(raw: string): string {
  const cleaned = raw.trim().toLowerCase().replace(/_/g, "-");
  if (cleaned.length === 0) return "";
  const parts = cleaned.split("-");
  const head = parts[0] ?? "";
  const THREE_TO_TWO: Readonly<Record<string, string>> = {
    hin: "hi",
    eng: "en",
  };
  const language = THREE_TO_TWO[head] ?? head;
  const region = parts[1];
  const THREE_TO_TWO_REGION: Readonly<Record<string, string>> = {
    ind: "in",
    usa: "us",
    gbr: "gb",
  };
  if (region === undefined) return language;
  const normalizedRegion = THREE_TO_TWO_REGION[region] ?? region;
  return `${language}-${normalizedRegion}`;
}

/** The ISO-639-1 subtag of a (possibly messy) locale, e.g. `hin-IND` → `hi`. */
export function localeLanguageSubtag(raw: string): string {
  const normalized = normalizeVoiceLocale(raw);
  return normalized.split("-")[0] ?? "";
}

/** How well a device locale matches a coaching language. */
export type LocaleMatch =
  /** The exact tag the app asks for first, e.g. hi-IN for `hi`. */
  | "exact"
  /** Same language, different region (en-AU for `en`) — perfectly speakable. */
  | "language"
  /** A different language entirely — must never speak the other bank's copy. */
  | "mismatch"
  /** The device reported nothing usable. */
  | "unknown";

/**
 * The preference chain in NORMALIZED form. Comparing raw tags would make
 * `hi-IN` (table) and `hi-in` / `hin-IND` (device) look like different
 * locales — the exact class of mismatch this unit exists to remove.
 */
export function normalizedLocaleChain(
  language: InstructionLanguage,
): readonly string[] {
  return localeChainFor(language).map(normalizeVoiceLocale);
}

export function matchLocaleToLanguage(
  locale: string,
  language: InstructionLanguage,
): LocaleMatch {
  const normalized = normalizeVoiceLocale(locale);
  if (normalized.length === 0) return "unknown";
  /* Unit 36: the comparison target is the RESOLVED language, so an untrusted
     value cannot silently classify every real voice as "mismatch" (which
     reads as "this device has no voice" and mutes coaching). */
  const resolved = resolveInstructionLanguage(language);
  const chain = normalizedLocaleChain(resolved);
  if (chain.some((tag) => tag === normalized)) return "exact";
  return localeLanguageSubtag(normalized) === resolved ? "language" : "mismatch";
}

/**
 * THE UNREADABLE-VALUE FALLBACK — a deliberate product decision, not an
 * accident of whichever helper runs first.
 *
 * Two CONCEPTUALLY DIFFERENT things share one value today:
 *
 *   A. FRESH-INSTALL DEFAULT — `DEFAULT_INSTRUCTION_LANGUAGE` in
 *      shared/types/settings. What a brand-new user coaches in: Hindi
 *      (Unit 37: Hindi-first product, Indian-studio audience).
 *   B. INVALID / UNREADABLE STORED VALUE — `undefined`, `null`, a non-string,
 *      `""`, an unsupported code (`"fr"`, `"kl-KL"`, `"xx"`), or a corrupted
 *      MMKV record. Contract: **treat it as if no preference was ever
 *      expressed — exactly like a fresh install — and coach in the same
 *      default.** Rationale: both phrase banks are complete for every
 *      category, so neither language risks silence; what WOULD be wrong is a
 *      store corruption silently flipping a Hindi-first product into
 *      English, or a crashed coaching loop because no pool exists.
 *
 * B is expressed as its own named constant so the rule can never drift from
 * A by accident — and can be changed deliberately in one place without
 * touching the fresh-install default.
 */
export const UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK: InstructionLanguage =
  DEFAULT_INSTRUCTION_LANGUAGE;

/**
 * Legacy spellings of the two real languages. Earlier builds persisted some
 * of these through hand-edited stores, deep links and pre-Unit-37 UI code;
 * mapping them RECOGNISES a preference the user actually expressed instead
 * of degrading it (an old `English` choice must stay English — that is a
 * user preference, not corruption).
 *
 *   · "hinglish" — the Unit 27 bank's own register name; that bank IS the
 *     `hi` bank, so recognition lands on Hindi.
 */
const LEGACY_LANGUAGE_ALIASES: Readonly<Record<string, InstructionLanguage>> =
  {
    english: "en",
    hindi: "hi",
    hinglish: "hi",
  };

/**
 * RECOGNITION, as its own total function:
 *   a value we can honestly read as one of the two coaching languages
 *   → that language, or null when nothing recognizable is there.
 *
 * Accepted shapes: the codes themselves in any case (`"en"`, `"HI"`),
 * locale tags (`"en-IN"`, `"en_US"`, `"hin-IND"`), ISO 639-2 spellings
 * (`"eng"`, `"hin"` — via `localeLanguageSubtag`), and the legacy aliases
 * above. Everything else (including non-strings) is null — the caller, not
 * this function, decides what "unreadable" means in its context (absent
 * key, corrupted value, …).
 *
 * This is the ONLY place that pattern-matches raw language strings: callers
 * never re-implement a `'en' | 'hi'` check of their own.
 */
export function normalizeInstructionLanguage(
  value: unknown,
): InstructionLanguage | null {
  if (typeof value !== "string") return null;
  const cleaned = value.trim().toLowerCase();
  if (cleaned.length === 0) return null;
  const alias = LEGACY_LANGUAGE_ALIASES[cleaned];
  if (alias !== undefined) return alias;
  const subtag = localeLanguageSubtag(cleaned);
  return INSTRUCTION_LANGUAGES.includes(subtag as InstructionLanguage)
    ? (subtag as InstructionLanguage)
    : null;
}

/**
 * Coerces an untrusted value (persisted preference, deep link, stale store)
 * into a language the phrase banks actually have copy for.
 *
 * This is the CENTRAL language gate: callers never branch on raw strings, so
 * a corrupted preference can never select a pool that does not exist.
 *
 *   raw value → normalize → supported? yes: use it · no: deliberate fallback
 *
 * Unit 37 (Part 4.6): the fallback is `UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK`
 * — see its contract above. An absent or unreadable preference behaves
 * EXACTLY like a fresh install, and a fresh install coaches in Hindi. A
 * *valid* stored 'en' is of course honoured in exactly the same function.
 */
export function resolveInstructionLanguage(value: unknown): InstructionLanguage {
  return (
    normalizeInstructionLanguage(value) ??
    UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK
  );
}
