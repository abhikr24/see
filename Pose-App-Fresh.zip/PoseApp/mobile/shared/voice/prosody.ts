/**
 * shared/voice/prosody.ts — Unit 36 (Part 4.5): HOW A PHRASE IS RENDERED.
 * Platform-neutral: zero RN, zero DOM, zero expo-speech, zero network.
 *
 *   semantic state → language → phrase (+ intensity) → THIS TABLE → device
 *
 * WHY THIS FILE EXISTS
 *   The delivery numbers (rate/pitch/volume) were literals in TWO speech
 *   backends: `mobile/src/core/voice/ttsService.ts` (expo-speech) and the
 *   preview mirror (browser speechSynthesis). Duplicated constants are how
 *   two runtimes quietly stop sounding alike — and how a "firmer" cue ends
 *   up firmer on one of them only. There is now ONE table; each backend
 *   converts it to its own options object and nothing else.
 *
 * WHAT THIS FILE IS NOT
 *   It does not decide the intensity. That is severity → intensity, mapped
 *   exactly once in `shared/coaching/coachingState.ts` from the ENGINE's
 *   severity. Nothing here may read a pose, a measurement or a severity.
 */
import type { PhraseIntensity } from "../constants/poseInstructions";

export interface SpeechProsody {
  /** Speaking rate. 1.0 is the engine default; the band stays 0.95–1.05. */
  readonly rate: number;
  readonly pitch: number;
  readonly volume: number;
}

/**
 * Unit 27 tuning, preserved verbatim:
 *   · gentle — 0.98, a real-instructor pace; the copy carries its own
 *     micro-pauses (commas, "…"), so the rate does not have to.
 *   · firm   — 1.04, delivered slightly more briskly in the SAME voice. A
 *     firmer cue is a different sentence (firm phrase pool) spoken a little
 *     more directly; it is never louder, higher or angrier.
 */
export const SPEECH_PROSODY: Readonly<Record<PhraseIntensity, SpeechProsody>> =
  Object.freeze({
    gentle: Object.freeze({ rate: 0.98, pitch: 1, volume: 1 }),
    firm: Object.freeze({ rate: 1.04, pitch: 1, volume: 1 }),
  });

/**
 * The delivery for one phrase tier. Unknown/absent values degrade to the
 * gentle tier — the quieter mistake, never the firmer one.
 */
export function prosodyForIntensity(
  intensity: PhraseIntensity | undefined,
): SpeechProsody {
  return intensity === "firm" ? SPEECH_PROSODY.firm : SPEECH_PROSODY.gentle;
}
