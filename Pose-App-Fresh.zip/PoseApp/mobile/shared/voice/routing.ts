/**
 * shared/voice/routing.ts — Unit 35 (Part 4.4): THE SINGLE LANGUAGE/SPEECH
 * ROUTING GATE between semantic coaching state and the speech engine.
 *
 *   analysis → semantic coaching state → THIS GATE → phrase pool → voice → TTS
 *
 * Why it exists: before this unit each caller re-implemented
 * `if (voiceEnabled && state !== null && !captureFlow)` and passed a raw
 * settings string straight into the phrase bank. That is exactly how a
 * language preference silently stops reaching phrase selection, and how a
 * disabled-voice check ends up ALSO deleting the semantic state that the
 * on-screen coaching UI needs.
 *
 * The gate therefore returns BOTH answers:
 *   · `state` — always passed through untouched, so non-TTS consumers
 *     (overlay, haptics, capture controller, logging) keep working with
 *     voice guidance switched off.
 *   · `deliverToSpeech` + `language` — the only sanctioned way to reach TTS.
 *
 * It performs no geometry, no severity, no cadence and no phrase lookup: the
 * planner still owns WHEN, the phrase bank still owns WHAT.
 */
import type { CoachingState } from "../coaching/types";
import type { InstructionLanguage } from "../constants/poseInstructions";
import { resolveInstructionLanguage } from "./locales";

/** Why speech was withheld for this frame. */
export type SpeechSuppression =
  | "none"
  /** No analysis decision this frame (model warming, throttled frame). */
  | "no-state"
  /** The user turned voice guidance off — semantic state still flows. */
  | "voice-guidance-disabled"
  /** Capture countdown/shutter owns the audio channel. */
  | "capture-in-progress"
  /**
   * evaluating / unavailable reference / no body. Marked non-speakable by
   * the ENGINE, never by a guess here — this is the branch that keeps
   * REFERENCE_UNAVAILABLE, REFERENCE_INVALID, REFERENCE_INCOMPATIBLE and
   * ANALYSIS_UNAVAILABLE from ever being read out as a correction.
   */
  | "state-not-speakable";

export interface CoachingSpeechRouteInput {
  /** The frame's semantic state, or null when the engine produced none. */
  readonly state: CoachingState | null;
  /** Persisted `voiceEnabled` preference. */
  readonly voiceGuidanceEnabled: boolean;
  /**
   * Persisted language preference. UNTRUSTED at runtime: it is normalized
   * once, here, through the canonical gate (`resolveInstructionLanguage`) —
   * a recognizable value is honoured as-is, and an unreadable/corrupted one
   * degrades to the canonical default instruction language (the fresh-install
   * language, Hindi), exactly like an absent preference. It never throws and
   * never names a pool that does not exist.
   */
  readonly language: unknown;
  /** True while a countdown/shutter sequence owns the audio channel. */
  readonly captureInProgress?: boolean;
}

export interface CoachingSpeechRoute {
  /** Untouched semantic state — available to every non-TTS consumer. */
  readonly state: CoachingState | null;
  /** The coaching language phrase selection and the voice must both use. */
  readonly language: InstructionLanguage;
  /** True only when TTS may be invoked for this frame. */
  readonly deliverToSpeech: boolean;
  readonly suppression: SpeechSuppression;
}

/**
 * Routes one frame. Pure and total: every input combination has a defined
 * answer, and the semantic state is never discarded.
 */
export function routeCoachingSpeech(
  input: CoachingSpeechRouteInput,
): CoachingSpeechRoute {
  const language = resolveInstructionLanguage(input.language);
  const state = input.state;

  const suppressed = (suppression: SpeechSuppression): CoachingSpeechRoute => ({
    state,
    language,
    deliverToSpeech: false,
    suppression,
  });

  if (state === null) return suppressed("no-state");
  if (!input.voiceGuidanceEnabled) return suppressed("voice-guidance-disabled");
  if (input.captureInProgress === true) return suppressed("capture-in-progress");
  /* The engine's own verdict, carried verbatim from the coaching contract. */
  if (!state.speakable) return suppressed("state-not-speakable");

  return { state, language, deliverToSpeech: true, suppression: "none" };
}
