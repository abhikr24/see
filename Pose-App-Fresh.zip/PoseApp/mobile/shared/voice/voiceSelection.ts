/**
 * shared/voice/voiceSelection.ts — Unit 35 (Part 4.4): VOICE DISCOVERY,
 * RANKING AND PREFERENCE RESOLUTION, as pure decision logic.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo-speech. The device speech
 * engine hands this module the catalog it ACTUALLY reported
 * (`Speech.getAvailableVoicesAsync()` on native, `speechSynthesis.getVoices()`
 * in the preview mirror) and receives back one decision:
 *
 *   available voices + coaching language + persisted preference
 *        → { voiceId | null, locale, source, fallbackReason }
 *
 * Hard rules encoded here:
 *   · A voice identifier is only ever returned if it came from the supplied
 *     catalog. No identifier is invented, guessed or hardcoded.
 *   · `voiceId === null` means "use the engine default for this locale" —
 *     an honest absence, never a fake voice.
 *   · A stored preference that the device no longer reports (uninstalled
 *     pack, engine switch, restored backup on another phone) falls back
 *     silently-but-traceably; it never crashes and never mutes coaching.
 *   · Language compatibility is respected where possible: a voice whose
 *     locale is a different LANGUAGE is not used to read the other bank's
 *     copy. Same language, different region is fine.
 *
 * Everything here is deterministic: same catalog in, same decision out.
 */
import type { InstructionLanguage } from "../constants/poseInstructions";
import {
  matchLocaleToLanguage,
  normalizedLocaleChain,
  normalizeVoiceLocale,
  primaryLocaleFor,
  type LocaleMatch,
} from "./locales";

/**
 * A voice as REPORTED BY THE RUNTIME. Structural on purpose: expo-speech's
 * `Speech.Voice` and the browser's `SpeechSynthesisVoice` both satisfy it,
 * and the install/network metadata Android exposes is optional because not
 * every engine reports it.
 */
export interface DeviceVoice {
  readonly identifier: string;
  readonly name?: string;
  readonly language: string;
  readonly quality?: string;
  /** Android: the voice is listed but its data is not on the device. */
  readonly notInstalled?: boolean;
  /** Android/iOS: the voice needs the network to synthesize. */
  readonly networkConnectionRequired?: boolean;
}

/** Sentinel used by the picker UI for "let the app choose". */
export const AUTOMATIC_VOICE_ID = "auto";

/** Where the finally-used voice came from. */
export type VoiceSelectionSource =
  /** The persisted user preference was found in the live catalog. */
  | "preferred"
  /** The app ranked the catalog and chose the best match for the language. */
  | "ranked"
  /** Nothing usable was reported — the OS engine default speaks the locale. */
  | "engine-default";

/** Why the persisted preference was not honored (null = it was, or none). */
export type VoiceFallbackReason =
  | null
  | "no-preference"
  | "preferred-not-found"
  | "preferred-not-installed"
  | "preferred-language-mismatch"
  | "no-voice-for-language"
  | "empty-catalog";

export interface VoiceSelection {
  /** Catalog identifier to pass to the engine, or null for its default. */
  readonly voiceId: string | null;
  /** Locale tag to pass to the engine. Always a real language tag. */
  readonly locale: string;
  readonly source: VoiceSelectionSource;
  /** Exactly what the caller asked for (diagnostics + settings UI). */
  readonly requestedVoiceId: string | null;
  readonly languageMatch: LocaleMatch;
  readonly fallbackReason: VoiceFallbackReason;
}

export interface VoiceSelectionInput {
  /** The catalog the runtime reported. Empty is a legitimate answer. */
  readonly voices: readonly DeviceVoice[];
  readonly language: InstructionLanguage;
  /** Persisted preference; null / AUTOMATIC_VOICE_ID = automatic. */
  readonly preferredVoiceId?: string | null;
}

/** A voice is usable only if it has an id and its data is on the device. */
function isUsable(voice: DeviceVoice): boolean {
  return (
    typeof voice.identifier === "string" &&
    voice.identifier.length > 0 &&
    voice.notInstalled !== true
  );
}

/**
 * Quality hints across engines: Android high-quality packs and iOS
 * Enhanced/Premium/Siri bundles. `compact` is iOS's LOWEST tier and is
 * penalized, which the Unit 27 scorer only ignored.
 */
const ENHANCED_HINTS = [
  "enhanced",
  "premium",
  "neural",
  "siri",
  "natural",
  "high",
] as const;
const WEAK_HINTS = ["compact", "low"] as const;

/**
 * Deterministic quality score for one voice, already known to match the
 * language. Higher is better; ties are broken by catalog order so the
 * ranking never depends on `Array.prototype.sort` stability assumptions.
 */
export function scoreVoice(
  voice: DeviceVoice,
  language: InstructionLanguage,
): number {
  const blob = `${voice.identifier} ${voice.name ?? ""} ${voice.quality ?? ""}`
    .toLowerCase();
  let score = 0;

  /* 1. Locale precision — the app's own preference chain, strongest signal. */
  const normalized = normalizeVoiceLocale(voice.language);
  const chain = normalizedLocaleChain(language);
  const chainIndex = chain.indexOf(normalized);
  if (chainIndex >= 0) score += (chain.length - chainIndex) * 10;

  /* 2. Engine quality hints. */
  for (const hint of ENHANCED_HINTS) if (blob.includes(hint)) score += 4;
  for (const hint of WEAK_HINTS) if (blob.includes(hint)) score -= 3;

  /* 3. On-device beats network (coaching must work in airplane mode). */
  if (voice.networkConnectionRequired === false) score += 2;
  if (voice.networkConnectionRequired === true) score -= 2;

  return score;
}

/**
 * Every voice the device reported that can legitimately speak `language`,
 * best first. Voices of another language are excluded — not deprioritized —
 * because reading a Hindi line with an English voice is not a degraded cue,
 * it is the wrong cue.
 */
export function rankVoicesForLanguage(
  voices: readonly DeviceVoice[],
  language: InstructionLanguage,
): readonly DeviceVoice[] {
  const candidates: { voice: DeviceVoice; score: number; order: number }[] = [];
  voices.forEach((voice, order) => {
    if (!isUsable(voice)) return;
    const match = matchLocaleToLanguage(voice.language, language);
    if (match === "mismatch" || match === "unknown") return;
    candidates.push({ voice, score: scoreVoice(voice, language), order });
  });
  candidates.sort((a, b) => (b.score - a.score) || (a.order - b.order));
  return candidates.map((entry) => entry.voice);
}

function findById(
  voices: readonly DeviceVoice[],
  id: string,
): DeviceVoice | null {
  for (const voice of voices) {
    if (voice.identifier === id) return voice;
  }
  return null;
}

/**
 * THE voice decision. Honors the persisted preference when the runtime still
 * reports it and it can speak the requested language; otherwise degrades in
 * documented steps, ending at the engine default for the locale.
 */
export function resolveVoiceSelection(
  input: VoiceSelectionInput,
): VoiceSelection {
  const { voices, language } = input;
  const requestedRaw = input.preferredVoiceId ?? null;
  const requested =
    requestedRaw === null ||
    requestedRaw.length === 0 ||
    requestedRaw === AUTOMATIC_VOICE_ID
      ? null
      : requestedRaw;

  const fallbackLocale = primaryLocaleFor(language);
  const ranked = rankVoicesForLanguage(voices, language);

  const engineDefault = (reason: VoiceFallbackReason): VoiceSelection => ({
    voiceId: null,
    locale: fallbackLocale,
    source: "engine-default",
    requestedVoiceId: requested,
    languageMatch: "unknown",
    fallbackReason: reason,
  });

  const rankedChoice = (reason: VoiceFallbackReason): VoiceSelection => {
    const best = ranked[0];
    if (best === undefined) {
      return engineDefault(
        voices.length === 0 ? "empty-catalog" : "no-voice-for-language",
      );
    }
    return {
      voiceId: best.identifier,
      locale: normalizeVoiceLocale(best.language) || fallbackLocale,
      source: "ranked",
      requestedVoiceId: requested,
      languageMatch: matchLocaleToLanguage(best.language, language),
      fallbackReason: reason,
    };
  };

  if (requested === null) return rankedChoice("no-preference");

  /* The preference is only ever resolved against the LIVE catalog: a stored
     identifier is data, not evidence that the voice exists. */
  const preferred = findById(voices, requested);
  if (preferred === null) return rankedChoice("preferred-not-found");
  if (preferred.notInstalled === true) {
    return rankedChoice("preferred-not-installed");
  }

  const match = matchLocaleToLanguage(preferred.language, language);
  if (match === "mismatch" || match === "unknown") {
    return rankedChoice("preferred-language-mismatch");
  }

  return {
    voiceId: preferred.identifier,
    locale: normalizeVoiceLocale(preferred.language) || fallbackLocale,
    source: "preferred",
    requestedVoiceId: requested,
    languageMatch: match,
    fallbackReason: null,
  };
}

export interface VoiceOption {
  readonly value: string;
  readonly label: string;
}

/** Human label for a catalog voice, without inventing information. */
export function describeVoice(voice: DeviceVoice): string {
  const locale = normalizeVoiceLocale(voice.language) || voice.language;
  const base =
    voice.name !== undefined && voice.name.length > 0
      ? voice.name
      : voice.identifier;
  const extras: string[] = [locale];
  if (voice.networkConnectionRequired === true) extras.push("network");
  return `${base} (${extras.join(", ")})`;
}

/**
 * Options for the settings picker: "Automatic" first, then ONLY voices the
 * device actually reported for that language, best first. A device with no
 * Hindi pack therefore shows exactly one honest option.
 */
export function voiceOptionsForLanguage(
  voices: readonly DeviceVoice[],
  language: InstructionLanguage,
  automaticLabel = "Automatic (recommended)",
): readonly VoiceOption[] {
  const ranked = rankVoicesForLanguage(voices, language);
  return [
    { value: AUTOMATIC_VOICE_ID, label: automaticLabel },
    ...ranked.map((voice) => ({
      value: voice.identifier,
      label: describeVoice(voice),
    })),
  ];
}
