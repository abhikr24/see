/**
 * authLinks.ts — THE centralized auth redirect/deep-link configuration.
 *
 * Every Supabase Auth URL the app hands out (OAuth completion, password
 * recovery) is built here from the app's own linking context — never a
 * hardcoded production domain. When the real Supabase project is supplied,
 * these derived URLs are exactly the values to whitelist in the dashboard
 * (Authentication → URL Configuration):
 *
 *   · Site URL              — the deployed web origin (production web build)
 *                             or the dev origin during development.
 *   · Additional Redirect   — smartphoto://auth
 *                             (Google OAuth completion)
 *                           — smartphoto://auth/reset-password
 *                             (password recovery via Linking.createURL of
 *                              PASSWORD_RESET_ROUTE)
 *                           — the two matching http(s) dev origins
 *                             (e.g. http://localhost:8081/auth,
 *                              http://localhost:8081/auth/reset-password)
 *
 * Plus: the password-reset EMAIL TEMPLATE must target
 * `{{ .ConfirmationURL }}` with the redirect above (default template works
 * once the redirect URLs are whitelisted). Full step list lives in
 * mobile/docs/account-deletion-and-password-reset.md.
 */
import * as Linking from 'expo-linking';
import { PASSWORD_RESET_ROUTE } from '@shared/index';

/**
 * Google OAuth round-trip target (Unit 06 route, kept centralized now).
 * Native: smartphoto://auth · Web: <origin>/auth.
 */
export function oauthRedirectUrl(): string {
  return Linking.createURL('auth');
}

/**
 * Password-recovery target handed to resetPasswordForEmail(). Identical
 * derivation on every platform — the dashboard whitelist uses this exact
 * value, so the flow rewires to production with configuration only.
 * Native: smartphoto://auth/reset-password · Web: <origin>/auth/reset-password.
 */
export function passwordResetRedirectUrl(): string {
  return Linking.createURL(PASSWORD_RESET_ROUTE);
}
