/**
 * Earliest JS error capture for production startup diagnostics.
 *
 * This module intentionally has zero app imports so it can be evaluated before
 * the rest of the root graph. It does not replace React Native's handler; it
 * records the last fatal/non-fatal error and then delegates to the previous
 * handler unchanged.
 */

const GLOBAL = globalThis as Record<string, unknown>;
const ERROR_UTILS = GLOBAL.ErrorUtils as
  | {
      getGlobalHandler?: () => ((error: unknown, isFatal?: boolean) => void);
      setGlobalHandler?: (handler: (error: unknown, isFatal?: boolean) => void) => void;
    }
  | undefined;

if (ERROR_UTILS?.setGlobalHandler) {
  const previous = ERROR_UTILS.getGlobalHandler?.();
  const handler = (error: unknown, isFatal?: boolean): void => {
    const record = {
      at: new Date().toISOString(),
      fatal: Boolean(isFatal),
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack ?? null : null,
    };
    GLOBAL.__POSEASSIST_EARLY_ERROR__ = record;
    try {
      // Keep the native/React Native default behavior intact.
      previous?.(error, isFatal);
    } catch {
      // Never allow diagnostics to create a second startup failure.
    }
  };
  try {
    ERROR_UTILS.setGlobalHandler(handler);
  } catch {
    // Some hosts expose ErrorUtils but do not allow replacement.
  }
}
