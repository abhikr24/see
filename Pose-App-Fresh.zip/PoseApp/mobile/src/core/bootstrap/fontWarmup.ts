/**
 * Optional post-boot font warmup. Fonts are intentionally not initialized by
 * the root navigator because native font registration should never be a reason
 * for the app to hang before the first screen.
 */
let started = false;

export function warmAppFonts(): void {
  if (started) return;
  started = true;

  void Promise.all([
    import('@expo-google-fonts/inter'),
    import('expo-font'),
  ])
    .then(([inter, expoFont]) =>
      expoFont.loadAsync({
        Inter_400Regular: inter.Inter_400Regular,
        Inter_600SemiBold: inter.Inter_600SemiBold,
        Inter_700Bold: inter.Inter_700Bold,
      }),
    )
    .catch(() => {
      // System fonts are an acceptable startup fallback.
    });
}
