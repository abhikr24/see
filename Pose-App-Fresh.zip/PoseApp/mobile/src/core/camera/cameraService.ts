/**
 * Unit 12 — Camera session service (singleton state).
 *
 * Holds the camera session's control state exactly once — one facing, one
 * flash mode, one zoom value, one readiness flag. The Camera view itself is
 * mounted conditionally by the screen (only when the tab is focused and the
 * app is in the foreground), which is what enforces the single-session and
 * instant-release invariants. This object only tracks control state.
 *
 * A1 NOTE — the camera engine is now react-native-vision-camera (Nitro) and
 * the live-pose input is a NATIVE frame output, so this module deliberately
 * contains NO ML frame seam anymore. The Unit-13 photo-capture pipeline is
 * unchanged in behaviour; it now fires through the photo-output registry
 * below instead of an expo-camera ref. D1's exposure-capability session
 * state (shared/camera/cameraExposure) is fully preserved — only the native
 * seam that reports it changed (CameraPreview → VisionCamera device props).
 */
import { create } from 'zustand';
import * as Haptics from 'expo-haptics';
import {
  ASPECT_DEFAULT,
  BRIGHTNESS_DEFAULT,
  FILTER_DEFAULT,
  FILTER_INTENSITY_DEFAULT,
  ZOOM_DEFAULT_X,
  clampExposureLevel,
  clampFilterId,
  clampFilterIntensity,
  clampZoom,
  formatZoom,
  nextAspectRatio,
  nextZoomStop,
  normalizeExposureCapabilities,
  resolveAspectRatio,
  zoomFromNormalized,
  type AspectRatioId,
  type CameraFilterId,
  type ExposureCapabilities,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';
import { readPhotoDimensions } from './photoBrightness';

export type CameraFacing = 'back' | 'front';
export type FlashMode = 'off' | 'auto' | 'on';
export type TimerSeconds = 0 | 3 | 5 | 10;
/**
 * LOOKS — the filter identity now has ONE definition, in
 * `shared/camera/cameraFilters`, because the same five ids are consumed by the
 * capture pipeline, the strip, the settings default, the saved-photo record
 * and the browser mirror. It is re-exported here so every existing import of
 * `CameraFilterId` from this module keeps working unchanged.
 */
export type { CameraFilterId } from '@shared/index';

export interface CapturedPhoto {
  readonly uri: string;
  readonly width: number;
  readonly height: number;
}

const FLASH_SEQUENCE: readonly FlashMode[] = ['off', 'auto', 'on'];
const TIMER_SEQUENCE: readonly TimerSeconds[] = [0, 3, 5, 10];

interface CameraSessionState {
  readonly facing: CameraFacing;
  readonly flash: FlashMode;
  readonly timer: TimerSeconds;
  readonly filter: CameraFilterId;
  /**
   * LOOKS — how much of the chosen look is applied, 0…100 in steps of 10.
   *
   * It lives beside `filter` rather than inside it because the pair is read
   * ONCE at the shutter and baked into the file: the look is not a label on
   * the photo, it is the photo. Original ignores the value entirely.
   */
  readonly filterIntensity: number;
  /** True while the strength track is on screen (re-tap of the active look). */
  readonly filterPanelOpen: boolean;
  /**
   * FRAMING — zoom is held as the MULTIPLIER the user reads (1× … 8× rear,
   * 1× … 4× front), not as expo-camera's normalised 0..1 prop.
   *
   * The 0..1 form was the source of a real defect: pinch multiplied it by the
   * gesture scale, and at the 1× default it is 0, so `0 × scale` stayed 0 and
   * zooming out from rest did nothing at all. Multipliers compose correctly
   * under pinch, survive a camera flip (they are simply clamped to the new
   * camera's range) and are what every label already wanted to show. The
   * normalised value is derived at the edge, where the CameraView needs it.
   */
  readonly zoomX: number;
  /**
   * FRAMING — the shape of the photograph: 4:3 (the sensor's own frame),
   * 1:1 or 16:9. Masked on the viewfinder AND cropped into the saved file.
   */
  readonly aspectRatio: AspectRatioId;
  /** FRAMING — the horizon guide may appear (it still only shows when tilted). */
  readonly levelGuideEnabled: boolean;
  /** True while the framing sheet (shape / grid / level) is on screen. */
  readonly framingPanelOpen: boolean;
  /**
   * CAMERA CONTROLS: the user has ASKED for the continuous light. Whether it
   * is actually lit is decided by `resolveLighting` (front cameras have no
   * lamp), so the request survives a flip to the selfie camera and back
   * instead of being silently forgotten.
   */
  readonly torchRequested: boolean;
  /**
   * BRIGHTNESS / EXPOSURE: −3…0…+3 detents — the user's single light
   * adjustment. WHERE it lands is decided per session by the native exposure
   * bridge's capability report (shared/camera/cameraExposure.ts):
   *
   *   · mechanism "native-exposure" — the detent becomes an EV bias on the
   *     sensor's automatic exposure via the patched camera foundation; the
   *     viewfinder change IS the real exposure, and the capture inherits it;
   *   · mechanism "photo-processing" — the detent is applied to the saved
   *     photograph by the Skia capture pipeline and approximated by a wash
   *     on the viewfinder, exactly as the pre-D1 implementation did.
   *
   * The user value therefore stays one honest number; the routing rule
   * (`captureBrightnessLevel`) guarantees the two mechanisms never stack.
   */
  readonly brightness: number;
  /**
   * D1 — exposure compensation capabilities as REPORTED BY THE ACTIVE CAMERA
   * (sanitised through `normalizeExposureCapabilities`). `null` means the
   * native bridge has not spoken on this build/session: the photo-processing
   * fallback owns the control until a report arrives.
   */
  readonly exposureCapabilities: ExposureCapabilities | null;
  /** True while the brightness slider is on screen. */
  readonly brightnessPanelOpen: boolean;
  /** True while the CameraView reports onCameraReady. */
  readonly isCameraReady: boolean;
  readonly switchCamera: () => void;
  readonly cycleFlash: () => void;
  readonly cycleTimer: () => void;
  readonly setFlash: (flash: FlashMode) => void;
  readonly setTimer: (timer: TimerSeconds) => void;
  readonly setFilter: (filter: CameraFilterId) => void;
  readonly setFilterIntensity: (intensity: number) => void;
  readonly nudgeFilterIntensity: (delta: number) => void;
  readonly resetFilterIntensity: () => void;
  readonly setFilterPanelOpen: (open: boolean) => void;
  /** Legacy 0..1 entry point, kept so no caller breaks; converts internally. */
  readonly setZoom01: (zoom: number) => void;
  /** FRAMING — set the user-facing multiplier directly (pinch, stop tap). */
  readonly setZoom: (multiplier: number) => void;
  /** One tap back to the whole frame. */
  readonly resetZoom: () => void;
  /** Advance to the next stop (1× → 2× → 4× → 8× → 1×). */
  readonly stepZoomStop: () => void;
  readonly setAspectRatio: (ratio: AspectRatioId) => void;
  readonly cycleAspectRatio: () => void;
  readonly setLevelGuideEnabled: (enabled: boolean) => void;
  readonly toggleLevelGuide: () => void;
  readonly setFramingPanelOpen: (open: boolean) => void;
  readonly setTorchRequested: (on: boolean) => void;
  readonly toggleTorch: () => void;
  readonly setBrightness: (level: number) => void;
  readonly nudgeBrightness: (delta: number) => void;
  readonly resetBrightness: () => void;
  readonly setBrightnessPanelOpen: (open: boolean) => void;
  /**
   * D1 — the ONLY ingress for the native exposure bridge's capability event:
   * sanitises the payload, preserves the user's logical detent across camera
   * switches by re-clamping it into the NEW camera's EV window, and never
   * throws — a malformed report degrades to "no native exposure this session".
   */
  readonly receiveExposureCapabilities: (payload: unknown) => void;
  readonly setCameraReady: (ready: boolean) => void;
}

/**
 * The value handed to the Camera `zoom` prop. VisionCamera's zoom unit IS the
 * user-facing multiplier (1 = 1×), so the session's zoomX passes straight
 * through — derived (never stored) at the edge, exactly like before, so the
 * number on screen and the number the hardware receives cannot drift apart.
 */
export function cameraZoomProp(state: {
  readonly zoomX: number;
  readonly facing: CameraFacing;
}): number {
  void state.facing;
  return state.zoomX;
}

/** "1×" / "2.4×" for the current camera's range. */
export function zoomLabel(multiplier: number, facing: CameraFacing): string {
  return formatZoom(multiplier, facing);
}

/**
 * Legacy readout (Unit 12) kept for callers that still hold a 0..1 value.
 * It now formats through the shared range model instead of its own 1+7z
 * guess, so it agrees with every other zoom label on the screen.
 */
export function zoomDisplay(zoom01: number, facing: CameraFacing = 'back'): string {
  return formatZoom(zoomFromNormalized(zoom01, facing), facing);
}

export const useCameraSession = create<CameraSessionState>((set, get) => ({
  facing: 'back',
  flash: 'off',
  timer: 0,
  filter: FILTER_DEFAULT,
  filterIntensity: FILTER_INTENSITY_DEFAULT,
  filterPanelOpen: false,
  zoomX: ZOOM_DEFAULT_X,
  aspectRatio: ASPECT_DEFAULT,
  levelGuideEnabled: true,
  framingPanelOpen: false,
  torchRequested: false,
  brightness: BRIGHTNESS_DEFAULT,
  exposureCapabilities: null,
  brightnessPanelOpen: false,
  isCameraReady: false,

  switchCamera: () => {
    const facing = get().facing === 'back' ? 'front' : 'back';
    /* FRAMING — flipping the camera used to THROW AWAY the zoom ("front →
       0"), so a user who flipped to check themselves and flipped back had to
       re-find their framing. The two cameras have different ranges, not
       different intentions: the multiplier is kept and simply clamped into
       the new camera's honest maximum (8× rear, 4× front). */
    const zoomX = clampZoom(get().zoomX, facing);
    set({ facing, zoomX });
    AppLogger.info(`[Camera] facing → ${facing} (zoom ${formatZoom(zoomX, facing)})`);
  },

  cycleFlash: () => {
    const flash =
      FLASH_SEQUENCE[(FLASH_SEQUENCE.indexOf(get().flash) + 1) % FLASH_SEQUENCE.length];
    set({ flash });
    AppLogger.info(`[Camera] flash → ${flash}`);
  },

  cycleTimer: () => {
    const timer =
      TIMER_SEQUENCE[(TIMER_SEQUENCE.indexOf(get().timer) + 1) % TIMER_SEQUENCE.length];
    set({ timer });
    AppLogger.info(`[Camera] timer → ${timer === 0 ? 'Off' : `${timer}s`}`);
  },

  setFlash: (flash) => {
    if (get().flash !== flash) {
      set({ flash });
      AppLogger.info(`[Camera] flash set → ${flash}`);
    }
  },

  setTimer: (timer) => {
    if (get().timer !== timer) {
      set({ timer });
      AppLogger.info(`[Camera] timer set → ${timer === 0 ? 'Off' : `${timer}s`}`);
    }
  },

  setFilter: (next) => {
    const filter = clampFilterId(next);
    if (get().filter === filter) return;
    /* Switching LOOK restores full strength. A 20 % Warm that silently became
       a 20 % B&W would make the next tile look broken; strength is a property
       of the look you are currently wearing, not a global dial. Original also
       closes the strength track, because there is nothing to adjust. */
    set({
      filter,
      filterIntensity: FILTER_INTENSITY_DEFAULT,
      filterPanelOpen: filter === 'original' ? false : get().filterPanelOpen,
    });
    AppLogger.info(`[Camera] look → ${filter} (100%)`);
  },

  setFilterIntensity: (intensity) => {
    const value = clampFilterIntensity(intensity);
    if (get().filterIntensity === value) return;
    set({ filterIntensity: value });
    AppLogger.info(`[Camera] look strength → ${value}%`);
  },

  nudgeFilterIntensity: (delta) => {
    const value = clampFilterIntensity(get().filterIntensity + delta);
    if (get().filterIntensity === value) return;
    set({ filterIntensity: value });
    AppLogger.info(`[Camera] look strength → ${value}%`);
  },

  resetFilterIntensity: () => {
    if (get().filterIntensity === FILTER_INTENSITY_DEFAULT) return;
    set({ filterIntensity: FILTER_INTENSITY_DEFAULT });
    AppLogger.info('[Camera] look strength → 100% (reset)');
  },

  setFilterPanelOpen: (open) => {
    const next = open && get().filter !== 'original';
    if (get().filterPanelOpen !== next) set({ filterPanelOpen: next });
  },

  /* ── framing: zoom ──────────────────────────────────────────────────── */

  setZoom01: (zoom) => {
    const facing = get().facing;
    set({ zoomX: zoomFromNormalized(zoom, facing) });
  },

  setZoom: (multiplier) => {
    const facing = get().facing;
    const next = clampZoom(multiplier, facing);
    if (get().zoomX !== next) set({ zoomX: next });
  },

  resetZoom: () => {
    if (get().zoomX !== ZOOM_DEFAULT_X) {
      set({ zoomX: ZOOM_DEFAULT_X });
      AppLogger.info('[Camera] zoom → 1x (reset)');
    }
  },

  stepZoomStop: () => {
    const facing = get().facing;
    const next = nextZoomStop(get().zoomX, facing);
    set({ zoomX: next });
    AppLogger.info(`[Camera] zoom → ${formatZoom(next, facing)}`);
  },

  /* ── framing: shape, grid companion, level ──────────────────────────── */

  setAspectRatio: (ratio) => {
    const next = resolveAspectRatio(ratio);
    if (get().aspectRatio !== next) {
      set({ aspectRatio: next });
      AppLogger.info(`[Camera] aspect ratio → ${next}`);
    }
  },

  cycleAspectRatio: () => {
    const next = nextAspectRatio(get().aspectRatio);
    set({ aspectRatio: next });
    AppLogger.info(`[Camera] aspect ratio → ${next}`);
  },

  setLevelGuideEnabled: (enabled) => {
    if (get().levelGuideEnabled !== enabled) {
      set({ levelGuideEnabled: enabled });
      AppLogger.info(`[Camera] level guide → ${enabled ? 'on' : 'off'}`);
    }
  },

  toggleLevelGuide: () => {
    const next = !get().levelGuideEnabled;
    set({ levelGuideEnabled: next });
    AppLogger.info(`[Camera] level guide → ${next ? 'on' : 'off'}`);
  },

  setFramingPanelOpen: (open) => {
    if (get().framingPanelOpen !== open) set({ framingPanelOpen: open });
  },

  /* ── camera controls: continuous light ──────────────────────────────── */

  setTorchRequested: (on) => {
    if (get().torchRequested !== on) {
      set({ torchRequested: on });
      AppLogger.info(`[Camera] torch requested → ${on ? 'on' : 'off'}`);
    }
  },

  toggleTorch: () => {
    const next = !get().torchRequested;
    set({ torchRequested: next });
    AppLogger.info(`[Camera] torch → ${next ? 'on' : 'off'}`);
  },

  /* ── camera controls: brightness ────────────────────────────────────── */

  setBrightness: (level) => {
    /* D1 — the detent is clamped through the ACTIVE mechanism's window: the
       device's real EV range when the sensor carries the adjustment, the full
       seven detents when the photo pipeline does. A badge can therefore never
       promise a stop the hardware cannot deliver. */
    const next = clampExposureLevel(level, get().exposureCapabilities);
    if (get().brightness !== next) {
      set({ brightness: next });
      AppLogger.info(`[Camera] brightness → ${next}`);
    }
  },

  nudgeBrightness: (delta) => {
    const next = clampExposureLevel(get().brightness + delta, get().exposureCapabilities);
    if (get().brightness !== next) {
      set({ brightness: next });
      AppLogger.info(`[Camera] brightness → ${next}`);
    }
  },

  resetBrightness: () => {
    if (get().brightness !== BRIGHTNESS_DEFAULT) {
      set({ brightness: BRIGHTNESS_DEFAULT });
      AppLogger.info('[Camera] brightness reset → default');
    }
  },

  setBrightnessPanelOpen: (open) => {
    if (get().brightnessPanelOpen !== open) set({ brightnessPanelOpen: open });
  },

  receiveExposureCapabilities: (payload) => {
    const capabilities = normalizeExposureCapabilities(payload);
    /* CAMERA SWITCH + SESSION RESTART: the logical detent is the user's
       intent and survives; the NUMBER that intent resolves to is re-clamped
       into the newly-bound camera's window (a front camera with a narrower
       EV range must not inherit the rear camera's wider request). */
    const brightness = clampExposureLevel(get().brightness, capabilities);
    const previous = get().exposureCapabilities;
    if (
      brightness !== get().brightness ||
      previous?.supported !== capabilities.supported ||
      previous?.minEV !== capabilities.minEV ||
      previous?.maxEV !== capabilities.maxEV ||
      previous?.stepEV !== capabilities.stepEV
    ) {
      set({ exposureCapabilities: capabilities, brightness });
      AppLogger.info(
        capabilities.supported
          ? `[Camera] native exposure — ${capabilities.minEV}…+${capabilities.maxEV} EV, step ${capabilities.stepEV}`
          : '[Camera] native exposure unavailable — brightness falls back to photo processing',
      );
    }
  },

  setCameraReady: (ready) => {
    if (get().isCameraReady !== ready) set({ isCameraReady: ready });
  },
}));

/**
 * Resets transient session state. Called when the capture pipeline (Unit 13)
 * finishes a shot or when a session is abandoned, so a later session never
 * inherits a stale "ready" flag or zoom level.
 */
export function resetTransientCameraState(): void {
  /* CAMERA CONTROLS: the continuous light and the brightness adjustment are
     TRANSIENT framing decisions, made for the light in one room at one
     moment. A torch silently still on — or a −3 brightness silently still
     applied — the next time the camera opens is the classic camera-app trap,
     so both return to their defaults with the session. */
  /* FRAMING: zoom is transient in exactly the same way — a shot framed at 6×
     last session must not silently frame the next one. The PHOTO SHAPE and
     the level/grid preferences are NOT transient: they are how this user
     wants their pictures to come out, the same class of decision as the grid
     switch in Settings, so they survive the session. */
  /* LOOKS: the CHOSEN look is NOT reset here — it is seeded from the user's
     `filterDefault` setting every time the camera is focused, which is the
     persistence the user actually asked for. Its STRENGTH is transient in the
     same sense as brightness: a 20 % Warm chosen for one scene must not
     silently weaken the next session's shots, and the strength track must
     never be found already open. */
  useCameraSession.setState({
    isCameraReady: false,
    zoomX: ZOOM_DEFAULT_X,
    framingPanelOpen: false,
    torchRequested: false,
    brightness: BRIGHTNESS_DEFAULT,
    /* D1 — capability reports belong to the SESSION that produced them (and
       to the camera lens bound within it); the next session re-derives its
       own mechanism from the fresh bind event rather than trusting a stale
       range from a camera that may not even be attached. */
    exposureCapabilities: null,
    brightnessPanelOpen: false,
    filterIntensity: FILTER_INTENSITY_DEFAULT,
    filterPanelOpen: false,
  });
}

/* ── Unit 13 — photo capture, now through the VisionCamera photo output ────
   The Camera component owns the CameraPhotoOutput (it is an OUTPUT of the
   camera, not a method on a ref) and registers it here while mounted. The
   ML pipeline consumes a DIFFERENT output entirely (native frames) — user
   photo capture and live pose analysis share no code path (A1). */

/** Structural surface of the VC5 photo output used by capture. */
interface PhotoOutputHandle {
  readonly capturePhotoToFile: (
    settings: { readonly flashMode?: 'off' | 'on' | 'auto' },
    callbacks: Record<string, unknown>,
  ) => Promise<{ readonly filePath: string }>;
}

let activePhotoOutput: PhotoOutputHandle | null = null;

/** Called by CameraPreview on mount/unmount with its photo output handle. */
export function registerPhotoOutput(output: PhotoOutputHandle | null): void {
  activePhotoOutput = output;
}

let captureInFlight: Promise<CapturedPhoto> | null = null;

/**
 * Single-flight camera capture. VisionCamera writes the JPEG straight to a
 * cache FILE (capturePhotoToFile) — no base64, no EXIF retention, and the
 * session's flash mode is READ AT THE SHUTTER (same read-once rule the
 * brightness/aspect/look pipeline follows), so a mode flipped mid-write
 * never retroactively changes the exposed frame.
 */
export function takePicture(): Promise<CapturedPhoto> {
  if (captureInFlight !== null) return captureInFlight;

  const photoOutput = activePhotoOutput;
  if (photoOutput === null) {
    return Promise.reject(new Error('Camera is not ready yet.'));
  }

  captureInFlight = (async () => {
    try {
      const flashMode = useCameraSession.getState().flash;
      const captured = await photoOutput.capturePhotoToFile({ flashMode }, {});
      if (!captured?.filePath) throw new Error('Camera returned no photo file.');
      const uri = captured.filePath.startsWith('file://')
        ? captured.filePath
        : `file://${captured.filePath}`;
      /* Dimensions come from the saved file (the file-based API returns no
         dims) via the same Skia decoder the framing pipeline uses. Failure
         leaves 0×0 — applyCaptureFraming then plans its crop from the DECODED
         image dims instead, so a probe failure can never cost the shot. */
      let width = 0;
      let height = 0;
      try {
        const probe = await readPhotoDimensions(uri);
        width = probe.width;
        height = probe.height;
      } catch (probeError) {
        AppLogger.warn(`[Camera] photo dimension probe failed — ${String(probeError)}`);
      }
      try {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
      } catch (error) {
        AppLogger.warn(`[Camera] heavy capture haptic unavailable — ${String(error)}`);
      }
      AppLogger.info(`[Camera] captured ${width}x${height} to app cache`);
      return { uri, width, height };
    } finally {
      captureInFlight = null;
    }
  })();

  return captureInFlight;
}

/* A1 — the Unit-16 takePictureAsync ML sampling seam (captureMlFrame) is
   DELETED, not deprecated: live pose analysis now consumes native camera
   frames through the VisionCamera frame output +
   vision-camera-mlkit-pose Nitro plugin (see mobile/docs/a1-native-realtime
   -pose.md). Nothing may reintroduce still-photo sampling as pseudo-video. */
