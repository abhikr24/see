/**
 * mobile/src/core/camera/hardwareShutterService.ts — Unit 38.
 *
 * THE ONLY PLACE IN THE APP THAT TOUCHES THE NATIVE HARDWARE-SHUTTER SEAM.
 *
 * Everything decidable without a device already lives in
 * `shared/camera/hardwareShutter` (capability rules, arming rules, press
 * hygiene). This file is the thin, honest adapter over the native module:
 *
 *   · it resolves the module OPTIONALLY, by name. Expo Go and any build made
 *     before this unit simply do not contain it, and `requireOptionalNativeModule`
 *     returns null rather than throwing — the app then reports
 *     `missing-native-module` and behaves exactly as it did before;
 *   · it never guesses. `isSupported` comes from the native side, which is
 *     `true` on Android (key events are intercepted and consumed) and
 *     deliberately `false` on iOS (no public API — see the module README);
 *   · it owns no capture logic, no haptics, no timers and no UI. It reports
 *     presses. The existing IntelligentCaptureController still decides
 *     whether a press becomes a photograph.
 *
 * NOTE ON WEB: `Platform.OS === 'web'` short-circuits before the native
 * lookup. The browser preview cannot read hardware volume keys, and this
 * service will never claim otherwise.
 */
import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo';
import {
  resolveHardwareShutterCapability,
  hardwareShutterCapabilityNote,
  type HardwareShutterCapability,
  type HardwareShutterKey,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';

const NATIVE_MODULE_NAME = 'HardwareShutter';
const PRESS_EVENT = 'onShutterPress';

/** Exactly the surface `modules/hardware-shutter` promises. */
interface HardwareShutterNative {
  readonly isSupported?: boolean;
  readonly unsupportedReason?: string | null;
  readonly interceptionMode?: string;
  setArmed(armed: boolean): void;
  isArmed(): boolean;
  addListener(
    event: string,
    listener: (payload: { key?: string; repeat?: boolean }) => void,
  ): { remove: () => void };
}

export interface HardwareShutterPress {
  readonly key: HardwareShutterKey;
  readonly repeat: boolean;
}

export interface HardwareShutterSubscription {
  readonly remove: () => void;
}

const native =
  Platform.OS === 'web'
    ? null
    : requireOptionalNativeModule<HardwareShutterNative>(NATIVE_MODULE_NAME);

const capability: HardwareShutterCapability = resolveHardwareShutterCapability({
  platform: Platform.OS,
  nativeModulePresent: native !== null,
  nativeReportsSupported: native?.isSupported === true,
});

let announced = false;

/**
 * What this build can actually do, resolved once. Logged the first time it
 * is asked for so a support report always contains the real answer rather
 * than an assumption about the platform.
 */
export function hardwareShutterCapability(): HardwareShutterCapability {
  if (!announced) {
    announced = true;
    AppLogger.info(
      `[HardwareShutter] capability=${capability} platform=${Platform.OS} ` +
        `mode=${native?.interceptionMode ?? 'none'} ` +
        `reason=${native?.unsupportedReason ?? 'n/a'} — ` +
        hardwareShutterCapabilityNote(capability),
    );
  }
  return capability;
}

/** True only when a real native source of key events exists. */
export function hardwareShutterAvailable(): boolean {
  return hardwareShutterCapability() === 'available';
}

/**
 * Arms or releases the physical keys.
 *
 * ARMED means "the volume keys belong to the shutter and the system volume
 * will NOT change". Because that is a real cost to the user, every caller is
 * expected to release the keys the moment the viewfinder stops owning the
 * screen; `useHardwareShutter` does exactly that, including on unmount.
 */
export function setHardwareShutterArmed(armed: boolean): void {
  if (native === null || capability !== 'available') return;
  try {
    native.setArmed(armed);
  } catch (error) {
    AppLogger.warn(`[HardwareShutter] setArmed(${armed}) failed — ${String(error)}`);
  }
}

function normalizeKey(raw: unknown): HardwareShutterKey | null {
  if (raw === 'volume-up' || raw === 'volume-down') return raw;
  return null;
}

/**
 * Subscribes to physical presses. Returns a no-op subscription when the
 * capability does not exist, so callers never branch on the platform.
 */
export function subscribeHardwareShutter(
  listener: (press: HardwareShutterPress) => void,
): HardwareShutterSubscription {
  if (native === null || capability !== 'available') {
    return { remove: () => undefined };
  }
  try {
    const subscription = native.addListener(PRESS_EVENT, (payload) => {
      const key = normalizeKey(payload?.key);
      if (key === null) return;
      listener({ key, repeat: payload?.repeat === true });
    });
    return { remove: () => subscription.remove() };
  } catch (error) {
    AppLogger.warn(`[HardwareShutter] subscribe failed — ${String(error)}`);
    return { remove: () => undefined };
  }
}
