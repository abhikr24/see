/**
 * CAMERA CONTROLS — photoBrightness.
 *
 * THE PART OF THE BRIGHTNESS CONTROL THAT IS NOT A PICTURE OF A CONTROL.
 *
 * The locked camera foundation (expo-camera ~57) exposes flash, torch, zoom,
 * focus mode, mirror, ratio and picture size — and no exposure /
 * exposure-compensation API on any platform. A "brightness" slider wired to
 * the viewfinder alone would therefore change nothing the user keeps: the
 * saved JPEG would be identical whatever the slider said. That is the exact
 * kind of decorative control this app is not allowed to ship.
 *
 * LOOKS JOINED THIS FILE FOR THE SAME REASON (audit finding).
 *
 * The filter strip had exactly the same defect, one step worse: the chosen
 * look was written into the saved photo's METADATA (`filterUsed`) and never
 * into its pixels, so "B&W" produced a colour photograph labelled B&W. The
 * look is now a color matrix from `shared/camera/cameraFilters`, composed with
 * the brightness matrix into ONE matrix, so a filtered + brightened + cropped
 * capture still costs exactly one decode, one draw and one encode.
 *
 * So the adjustment is applied for real, to the captured file, before the
 * user ever sees it in the preview screen:
 *
 *   decode the captured JPEG  →  draw it once into an offscreen Skia surface
 *   through the shared brightness color matrix  →  re-encode  →  hand the
 *   NEW file to the preview/save flow.
 *
 * Deliberate decisions:
 *
 *  · NO NEW DEPENDENCY. @shopify/react-native-skia is already in the
 *    dependency set and already renders the pose silhouette, the countdown
 *    dial and the shutter ring, so the pixel work rides hardware the app has
 *    already paid for. expo-image-manipulator has no brightness operation;
 *    adding an image library for one color matrix would be waste.
 *  · THE MATRIX COMES FROM shared/. The same function feeds the live preview
 *    wash, so what the user judged on screen and what is written to disk can
 *    never be defined in two places.
 *  · IDENTITY IS A NO-OP. At the default detent the original file is returned
 *    untouched: no decode, no re-encode, no quality loss, no latency.
 *  · FAILURE IS NEVER FATAL. If decoding, the GPU surface or encoding fails
 *    for any reason, the ORIGINAL photo is returned and the shot survives.
 *    A brightness preference must not be able to lose a photograph.
 */
import { Skia, ImageFormat } from '@shopify/react-native-skia';
import * as FileSystem from 'expo-file-system/legacy';
import {
  ASPECT_DEFAULT,
  FILTER_DEFAULT,
  FILTER_INTENSITY_DEFAULT,
  aspectCropRect,
  brightnessGain,
  brightnessIsIdentity,
  captureColorMatrix,
  clampFilterId,
  clampFilterIntensity,
  colorMatrixIsIdentity,
  filterIsIdentity,
  resolveAspectRatio,
  type AspectRatioId,
  type CameraFilterId,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';

export interface BrightenedPhoto {
  readonly uri: string;
  readonly width: number;
  readonly height: number;
  /** True when the pixels were actually rewritten. */
  readonly adjusted: boolean;
}

export interface CaptureFramingOptions {
  readonly brightness: number;
  /**
   * FRAMING — the shape the user composed. `4:3` is the sensor's own frame
   * and means "no crop"; the other two are produced by a CENTRE crop of the
   * captured file, in the same single Skia pass as the brightness matrix, so
   * a square photo costs exactly one decode/encode and never two.
   */
  readonly aspectRatio: AspectRatioId;
  /**
   * LOOKS — the filter the user was wearing at the shutter. Optional so every
   * pre-existing caller (and `applyPhotoBrightness` below) keeps compiling and
   * keeps its exact previous behaviour: no look, no change.
   */
  readonly filter?: CameraFilterId;
  /** 0…100. Ignored for `original`; 0 means "chosen, but switched off". */
  readonly filterIntensity?: number;
}

const JPEG_QUALITY = 92;

/**
 * A1 — dimension probe for the file-based capture path. VisionCamera's
 * capturePhotoToFile returns only a path, so the pipeline learns the saved
 * JPEG's size here through the SAME Skia decoder the framing pass uses. The
 * caller treats a throw as "no dims" (0×0) — never as a capture failure.
 */
export async function readPhotoDimensions(
  uri: string,
): Promise<{ readonly width: number; readonly height: number }> {
  const data = await Skia.Data.fromURI(uri);
  const image = Skia.Image.MakeImageFromEncoded(data);
  if (image === null) {
    throw new Error('photo file could not be decoded for a dimension probe');
  }
  return { width: image.width(), height: image.height() };
}

/**
 * Applies the user's brightness detent to a captured photo file.
 * Always resolves; never throws; never deletes the caller's input on failure.
 */
export async function applyPhotoBrightness(
  photo: { readonly uri: string; readonly width: number; readonly height: number },
  level: number,
): Promise<BrightenedPhoto> {
  return applyCaptureFraming(photo, {
    brightness: level,
    aspectRatio: ASPECT_DEFAULT,
    filter: FILTER_DEFAULT,
    filterIntensity: FILTER_INTENSITY_DEFAULT,
  });
}

/**
 * FRAMING + BRIGHTNESS in ONE pass.
 *
 * The aspect ratio the user chose is a promise about the PHOTOGRAPH, not a
 * decoration on the viewfinder: a mask that is not honoured after the shutter
 * would hand back a picture that contains things the user deliberately framed
 * out. So the crop lands here, on the file, beside the brightness matrix —
 * one decode, one draw, one encode, whichever of the two is in play.
 *
 * Always resolves; never throws; on ANY failure the original photo is
 * returned intact, because a framing preference must not lose a photograph.
 */
export async function applyCaptureFraming(
  photo: { readonly uri: string; readonly width: number; readonly height: number },
  options: CaptureFramingOptions,
): Promise<BrightenedPhoto> {
  const level = options.brightness;
  const ratio = resolveAspectRatio(options.aspectRatio);
  const filter = clampFilterId(options.filter);
  const intensity = clampFilterIntensity(
    options.filterIntensity ?? FILTER_INTENSITY_DEFAULT,
  );
  /* ONE matrix for the whole colour job: look first (it acts on what the
     sensor saw), brightness second (it acts on the look the user chose).
     Both are linear, so the composition is exact and free. */
  const matrix = captureColorMatrix({
    filter,
    intensity,
    brightnessGain: brightnessGain(level),
  });
  const identityColor =
    brightnessIsIdentity(level) && filterIsIdentity(filter, intensity)
      ? true
      : colorMatrixIsIdentity(matrix);
  /* The early exit may only trust REPORTED dims when they exist: the A1
     file-based capture path can legally report 0×0 (dimension probe kept
     best-effort at the shutter), and computing a crop plan from 0×0 would
     wrongly skip the shape the user framed through. Without dims we simply
     fall through to the decode below, which re-plans from the REAL pixels. */
  const hasReportedDims = photo.width > 0 && photo.height > 0;
  const plannedCrop = hasReportedDims
    ? aspectCropRect(ratio, photo.width, photo.height)
    : null;

  if (identityColor && plannedCrop === null && hasReportedDims) {
    return { ...photo, adjusted: false };
  }
  if (identityColor && plannedCrop === null && !hasReportedDims) {
    /* fall through: decode to learn whether a crop is actually needed */
  }

  try {
    const data = await Skia.Data.fromURI(photo.uri);
    const image = Skia.Image.MakeImageFromEncoded(data);
    if (image === null) {
      AppLogger.warn('[Framing] capture could not be decoded — original kept');
      return { ...photo, adjusted: false };
    }

    /* Trust the DECODED dimensions, not the reported ones: some devices report
       pre-rotation sizes, and cropping against the wrong pair would shave the
       wrong edge. */
    const sourceWidth = image.width();
    const sourceHeight = image.height();
    const crop = aspectCropRect(ratio, sourceWidth, sourceHeight);

    if (identityColor && crop === null) {
      return { ...photo, adjusted: false };
    }

    const width = crop?.width ?? sourceWidth;
    const height = crop?.height ?? sourceHeight;
    const surface = Skia.Surface.MakeOffscreen(width, height);
    if (surface === null) {
      AppLogger.warn('[Framing] offscreen surface unavailable — original kept');
      return { ...photo, adjusted: false };
    }

    const paint = Skia.Paint();
    if (!identityColor) {
      paint.setColorFilter(Skia.ColorFilter.MakeMatrix(matrix as number[]));
    }

    const canvas = surface.getCanvas();
    if (crop === null) {
      canvas.drawImage(image, 0, 0, paint);
    } else {
      canvas.drawImageRect(
        image,
        Skia.XYWHRect(crop.x, crop.y, crop.width, crop.height),
        Skia.XYWHRect(0, 0, crop.width, crop.height),
        paint,
      );
    }
    surface.flush();

    const snapshot = surface.makeImageSnapshot();
    const base64 = snapshot.encodeToBase64(ImageFormat.JPEG, JPEG_QUALITY);
    if (base64 === null || base64.length === 0) {
      AppLogger.warn('[Brightness] re-encode produced no data — original kept');
      return { ...photo, adjusted: false };
    }

    const target = adjustedPathFor(photo.uri, level, ratio, filter, intensity);
    await FileSystem.writeAsStringAsync(target, base64, {
      encoding: FileSystem.EncodingType.Base64,
    });

    /* The untouched original is a temporary capture-cache artefact that the
       user never asked to keep; leaving it behind would double the cache cost
       of every adjusted shot. Deletion failure is not an error worth showing. */
    await FileSystem.deleteAsync(photo.uri, { idempotent: true }).catch(() => undefined);

    AppLogger.info(
      `[Framing] photo written (look ${filter}@${intensity}%, brightness ${level}, ` +
        `shape ${ratio}) — ${width}x${height}`,
    );
    return { uri: target, width, height, adjusted: true };
  } catch (error) {
    AppLogger.warn(`[Framing] adjustment skipped — ${String(error)}`);
    return { ...photo, adjusted: false };
  }
}

/** Sibling file in the same cache directory; never overwrites the original. */
function adjustedPathFor(
  uri: string,
  level: number,
  ratio: AspectRatioId,
  filter: CameraFilterId,
  intensity: number,
): string {
  const cut = uri.lastIndexOf('/');
  const directory = cut === -1 ? uri : uri.slice(0, cut + 1);
  const brightnessPart = level > 0 ? `p${level}` : level < 0 ? `m${Math.abs(level)}` : 'p0';
  const shapePart = ratio.replace(':', 'x');
  const lookPart = filterIsIdentity(filter, intensity) ? 'plain' : `${filter}${intensity}`;
  return `${directory}poseassist-shot-${lookPart}-${brightnessPart}-${shapePart}-${Date.now()}.jpg`;
}
