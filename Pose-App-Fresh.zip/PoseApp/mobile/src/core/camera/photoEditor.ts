/**
 * POST-CAPTURE EDITING — the device renderer.
 *
 * This is the half of the crop / rotate / enhance feature that is NOT a
 * picture of a feature. It is the direct sibling of `photoBrightness.ts`, and
 * it is written the same way and for the same reason:
 *
 *   decode the file ONCE  →  draw it ONCE into an offscreen Skia surface,
 *   rotated and cropped, through ONE composed colour matrix  →  encode ONCE
 *   →  hand back a NEW file.
 *
 * WHY SKIA AND NOT AN IMAGE LIBRARY (the resource check that was actually
 * carried out before writing a line of this file):
 *
 *   · `@shopify/react-native-skia` 2.6.2 is ALREADY a dependency (MIT), is
 *     already used for the pose silhouette, the coaching arrows, the countdown
 *     dial and the existing capture pipeline, and already ships its native
 *     code in this app's build. Rotation, cropping and colour matrices are
 *     first-class in it. Cost of using it here: zero new native code, zero new
 *     licences, zero new build configuration, and removal is reversible by
 *     deleting this one file.
 *   · `expo-image-manipulator` (MIT, Expo-maintained) would have given crop +
 *     rotate in one call, but it has NO brightness/contrast/saturation
 *     operation, so the enhance half would still need Skia — and it would add
 *     a native module, a second decode/encode for any combined edit, and a new
 *     dependency to the locked stack. Rejected on those grounds, not on
 *     quality.
 *   · Pure-JS pixel libraries (jimp, photon-wasm and friends) were rejected
 *     outright: decoding a 12-megapixel JPEG on the JS thread would freeze the
 *     UI for seconds on mid-range Android, and photon drags in a WASM binary.
 *
 * INVARIANTS THIS FILE KEEPS
 *
 *   · IDENTITY IS A NO-OP. If the edit would not change a pixel, the original
 *     file is returned untouched — no re-encode, no generational JPEG loss.
 *   · IT NEVER DESTROYS THE INPUT. Unlike the capture pipeline (whose input is
 *     a throwaway camera-cache file), an edit's input may be the user's saved
 *     photograph, so this renderer only ever WRITES a new temporary file. The
 *     caller decides what to replace, and only after the write succeeded.
 *   · FAILURE IS NEVER FATAL. Any decode/GPU/encode failure resolves to a
 *     result that reports `applied: false` and still carries the original URI.
 *   · NO IMAGE BYTES IN KEY-VALUE STORAGE. Output goes to the filesystem
 *     cache; MMKV keeps metadata only, exactly as before.
 */
import { Skia, ImageFormat } from '@shopify/react-native-skia';
import * as FileSystem from 'expo-file-system/legacy';
import {
  PHOTO_EDIT_JPEG_QUALITY,
  clampPhotoEdit,
  describePhotoEdit,
  editedFileName,
  isEditTempFileName,
  photoEditDrawTransform,
  photoEditIsIdentity,
  resolvePhotoEditGeometry,
  type PhotoEdit,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';

export interface EditableImage {
  readonly uri: string;
  readonly width: number;
  readonly height: number;
}

export interface EditedPhoto {
  readonly uri: string;
  readonly width: number;
  readonly height: number;
  /** True only when a NEW file was written. */
  readonly applied: boolean;
  /** Present when the edit was requested but could not be rendered. */
  readonly failure: string | null;
}

/** Temporary output lives in the cache directory; Documents stays durable. */
function editCacheDirectory(): string {
  return FileSystem.cacheDirectory ?? '';
}

/**
 * Renders an edit to a NEW file and returns it. The source file is left
 * exactly as it was found — see the invariants above.
 */
export async function renderPhotoEdit(
  source: EditableImage,
  edit: PhotoEdit,
): Promise<EditedPhoto> {
  const model = clampPhotoEdit(edit);

  if (photoEditIsIdentity(model)) {
    return { ...source, applied: false, failure: null };
  }

  try {
    const data = await Skia.Data.fromURI(source.uri);
    const image = Skia.Image.MakeImageFromEncoded(data);
    if (image === null) {
      AppLogger.warn('[PhotoEdit] file could not be decoded — original kept');
      return { ...source, applied: false, failure: 'decode' };
    }

    /* Trust the DECODED size, never the reported one: some devices report
       pre-rotation capture dimensions, and resolving a crop against the wrong
       pair would shave the wrong edge off the user's photograph. */
    const geometry = resolvePhotoEditGeometry(model, image.width(), image.height());
    if (geometry.isIdentity) {
      return { ...source, applied: false, failure: null };
    }

    const surface = Skia.Surface.MakeOffscreen(
      geometry.outputWidth,
      geometry.outputHeight,
    );
    if (surface === null) {
      AppLogger.warn('[PhotoEdit] offscreen surface unavailable — original kept');
      return { ...source, applied: false, failure: 'surface' };
    }

    const paint = Skia.Paint();
    if (!geometry.colorIsIdentity) {
      paint.setColorFilter(Skia.ColorFilter.MakeMatrix(geometry.matrix as number[]));
    }

    /* The transform is DATA from shared/, not maths invented here, so the
       browser mirror and the unit tests exercise the same mapping. */
    const transform = photoEditDrawTransform(geometry);
    const canvas = surface.getCanvas();
    canvas.save();
    canvas.translate(transform.translateX, transform.translateY);
    if (transform.rotateDegrees !== 0) canvas.rotate(transform.rotateDegrees, 0, 0);
    canvas.drawImage(image, 0, 0, paint);
    canvas.restore();
    surface.flush();

    const snapshot = surface.makeImageSnapshot();
    const base64 = snapshot.encodeToBase64(ImageFormat.JPEG, PHOTO_EDIT_JPEG_QUALITY);
    if (base64 === null || base64.length === 0) {
      AppLogger.warn('[PhotoEdit] re-encode produced no data — original kept');
      return { ...source, applied: false, failure: 'encode' };
    }

    const target = `${editCacheDirectory()}${editedFileName(model, Date.now())}`;
    await FileSystem.writeAsStringAsync(target, base64, {
      encoding: FileSystem.EncodingType.Base64,
    });

    AppLogger.info(
      `[PhotoEdit] ${describePhotoEdit(model)} — ` +
        `${geometry.sourceWidth}x${geometry.sourceHeight} → ` +
        `${geometry.outputWidth}x${geometry.outputHeight}`,
    );
    return {
      uri: target,
      width: geometry.outputWidth,
      height: geometry.outputHeight,
      applied: true,
      failure: null,
    };
  } catch (error) {
    AppLogger.warn(`[PhotoEdit] edit skipped — ${String(error)}`);
    return { ...source, applied: false, failure: 'exception' };
  }
}

/**
 * Moves a rendered edit over a destination path, replacing it.
 *
 * Order matters and is the whole point: the new bytes are already on disk
 * before anything is deleted, so a crash between the two steps costs a cache
 * file, never the photograph.
 */
export async function replaceFileWithEdit(
  editedUri: string,
  destinationUri: string,
): Promise<void> {
  if (editedUri === destinationUri) return;
  await FileSystem.deleteAsync(destinationUri, { idempotent: true }).catch(
    () => undefined,
  );
  await FileSystem.moveAsync({ from: editedUri, to: destinationUri });
}

/** Best-effort removal of a temporary edit output. Never throws. */
export async function discardEditTempFile(uri: string): Promise<void> {
  if (!uri.startsWith('file://')) return;
  const name = uri.slice(uri.lastIndexOf('/') + 1);
  if (!isEditTempFileName(name)) return;
  await FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => undefined);
}

/**
 * Sweeps abandoned edit outputs out of the cache.
 *
 * An edit that the user cancels after rendering, or an app killed mid-flow,
 * leaves a full-size JPEG behind. The cache is OS-evictable, so this is not a
 * correctness problem — but leaving tens of megabytes of the user's own photos
 * lying around unreferenced is not acceptable either. Called on preview-screen
 * mount; only touches files this feature created (name-prefixed), so it can
 * never delete a capture, a durable gallery file or anything else.
 */
export async function sweepEditTempFiles(): Promise<number> {
  const directory = editCacheDirectory();
  if (directory.length === 0) return 0;
  try {
    const entries = await FileSystem.readDirectoryAsync(directory);
    const stale = entries.filter(isEditTempFileName);
    await Promise.all(
      stale.map((name) =>
        FileSystem.deleteAsync(`${directory}${name}`, { idempotent: true }).catch(
          () => undefined,
        ),
      ),
    );
    if (stale.length > 0) {
      AppLogger.info(`[PhotoEdit] swept ${stale.length} abandoned edit file(s)`);
    }
    return stale.length;
  } catch (error) {
    AppLogger.debug(`[PhotoEdit] cache sweep skipped — ${String(error)}`);
    return 0;
  }
}
