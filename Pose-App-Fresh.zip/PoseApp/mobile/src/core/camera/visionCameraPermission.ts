/**
 * Camera permission seam used by onboarding and the live camera screen.
 *
 * Android release builds use React Native's native PermissionsAndroid API for
 * the actual runtime prompt. VisionCamera still owns the camera itself, but
 * permission acquisition no longer depends on an internal export shape from
 * the VisionCamera package. This is more robust across VisionCamera releases.
 *
 * Expo Go is detected explicitly: a standalone Android permission cannot be
 * granted to PoseAssist through the Expo Go host, so the seam returns denied
 * without attempting to request a permission for the host application.
 */
import { AppState, PermissionsAndroid, Platform } from 'react-native';
import Constants from 'expo-constants';
import { useCallback, useEffect, useState } from 'react';
import { AppLogger } from '@/core/utils/logger';
import type { PermissionStatus } from '@shared/index';

interface VisionCameraModule {
  readonly Camera?: {
    readonly getCameraPermissionStatus?: () => string;
    readonly requestCameraPermission?: () => Promise<string>;
  };
}

function isExpoGo(): boolean {
  return Constants.appOwnership === 'expo';
}

function loadModule(): VisionCameraModule | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    return (require('react-native-vision-camera') as VisionCameraModule) ?? null;
  } catch (error) {
    AppLogger.warn(`[Permissions] vision-camera unavailable — ${String(error)}`);
    return null;
  }
}

function normalizeVisionStatus(status: string | undefined): PermissionStatus {
  switch (status) {
    case 'authorized':
    case 'granted':
      return 'granted';
    case 'denied':
    case 'restricted':
      return 'denied';
    case 'not-determined':
      return 'denied';
    default:
      return 'denied';
  }
}

async function checkAndroid(): Promise<PermissionStatus> {
  if (isExpoGo()) {
    AppLogger.info('[Permissions] Expo Go host detected — camera permission unavailable');
    return 'denied';
  }
  try {
    const granted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA);
    return granted ? 'granted' : 'denied';
  } catch (error) {
    AppLogger.warn(`[Permissions] Android camera status check failed — ${String(error)}`);
    return 'denied';
  }
}

async function requestAndroid(): Promise<PermissionStatus> {
  if (isExpoGo()) {
    AppLogger.info('[Permissions] Expo Go host cannot grant PoseAssist camera access');
    return 'denied';
  }
  try {
    const result = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.CAMERA);
    switch (result) {
      case PermissionsAndroid.RESULTS.GRANTED:
        return 'granted';
      case PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN:
        return 'deniedForever';
      default:
        return 'denied';
    }
  } catch (error) {
    AppLogger.warn(`[Permissions] Android camera request failed — ${String(error)}`);
    return 'denied';
  }
}

async function checkIos(): Promise<PermissionStatus> {
  const mod = loadModule();
  try {
    const status = mod?.Camera?.getCameraPermissionStatus?.();
    return normalizeVisionStatus(status);
  } catch (error) {
    AppLogger.warn(`[Permissions] VisionCamera status check failed — ${String(error)}`);
    return 'denied';
  }
}

async function requestIos(): Promise<PermissionStatus> {
  const mod = loadModule();
  const requester = mod?.Camera?.requestCameraPermission;
  if (requester === undefined) {
    AppLogger.warn('[Permissions] VisionCamera request API missing');
    return 'denied';
  }
  try {
    return normalizeVisionStatus(await requester());
  } catch (error) {
    AppLogger.warn(`[Permissions] VisionCamera request failed — ${String(error)}`);
    return 'denied';
  }
}

async function checkNativeCamera(): Promise<PermissionStatus> {
  if (Platform.OS === 'android') return checkAndroid();
  if (Platform.OS === 'ios') return checkIos();
  return 'granted';
}

async function requestNativeCamera(): Promise<PermissionStatus> {
  if (Platform.OS === 'android') return requestAndroid();
  if (Platform.OS === 'ios') return requestIos();
  return 'granted';
}

export interface CameraPermissionRequestResult {
  readonly granted: boolean;
  readonly canAskAgain: boolean;
}

export interface CameraPermissionState {
  readonly granted: boolean;
  readonly canAskAgain: boolean;
  readonly requestPermission: () => Promise<CameraPermissionRequestResult>;
}

export function useCameraPermissionState(): CameraPermissionState {
  const [granted, setGranted] = useState(false);
  const [canAskAgain, setCanAskAgain] = useState(true);
  const [refreshTick, setRefreshTick] = useState(0);

  const refresh = useCallback(async () => {
    const status = await checkNativeCamera();
    setGranted(status === 'granted');
    setCanAskAgain(status !== 'deniedForever');
  }, []);

  useEffect(() => {
    void refresh();
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') setRefreshTick((value) => value + 1);
    });
    return () => subscription.remove();
  }, [refresh]);

  useEffect(() => {
    if (refreshTick > 0) void refresh();
  }, [refresh, refreshTick]);

  const requestPermission = useCallback(async (): Promise<CameraPermissionRequestResult> => {
    const status = await requestNativeCamera();
    const nextGranted = status === 'granted';
    const nextCanAskAgain = status !== 'deniedForever';
    setGranted(nextGranted);
    setCanAskAgain(nextCanAskAgain);
    return { granted: nextGranted, canAskAgain: nextCanAskAgain };
  }, []);

  return { granted, canAskAgain, requestPermission };
}

export async function checkCameraPermission(): Promise<PermissionStatus> {
  return checkNativeCamera();
}

export async function requestCameraPermission(): Promise<PermissionStatus> {
  return requestNativeCamera();
}
