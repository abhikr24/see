/**
 * Unit 30 — Semantic coaching facade.
 *
 * The app-side door to the platform-neutral coaching boundary in
 * shared/coaching. Feature screens import from here, never from shared
 * internals, exactly as they do for the analysis engine.
 *
 *   ONE semantic decision (analysis) → decisionToCoachingState()
 *     → CoachingState (category · direction · severity · confidence ·
 *       stability) → ttsService.speakCoaching() / visible coaching UI
 *
 * Pure and deterministic: no camera, no speech engine, no network, no
 * Supabase, no LLM.
 */
export {
  decisionToCoachingState,
  intensityForSeverity,
  selectCoachingPhrase,
  coachingCategoryFor,
  createCoachingSpeechPlanner,
  CATEGORY_COVERAGE,
  REACHABLE_CATEGORIES,
  DEFAULT_SPEECH_CADENCE,
  type CoachingKind,
  type CoachingPhrase,
  type CoachingState,
  type CoachingSpeechPlanner,
  type SpeechPlan,
  type SpeechCadenceConfig,
} from '@shared/index';
