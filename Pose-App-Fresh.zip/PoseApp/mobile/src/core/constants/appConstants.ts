/**
 * Unit 01 — app constants barrel.
 * The single source of truth lives in the platform-neutral brain
 * (repo-root shared/). This barrel re-exports it so feature code imports
 * from '@/core/constants/appConstants' or '@shared/index' interchangeably.
 *
 * Invariants (non-negotiable, see .cursorrules):
 *  · Photos stay on-device; Supabase receives metadata only, never images.
 *  · MediaPipe runs on-device only; no frame ever leaves the phone.
 *  · One active camera session at a time; released on blur/background.
 *  · Guests browse read-only; camera/favorites/stats require auth.
 *  · Design tokens only — never hardcoded hex/px outside shared/theme.
 */
export {
  APP_NAME,
  APP_SHORT_NAME,
  APP_VERSION,
  LOG_TAG,
  LIMITS,
  TABS,
  STORAGE_KEYS,
} from '@shared/index';
