/** Unit 22 - application error with a safe user message and original cause. */
import { ErrorType } from './errorTypes';

export class AppError extends Error {
  readonly type: ErrorType;
  readonly code: string | null;
  readonly originalError: unknown;

  constructor(
    type: ErrorType,
    message: string,
    code: string | null = null,
    originalError?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
    this.type = type;
    this.code = code;
    this.originalError = originalError;
  }

  static network(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.Network, message, code, cause);
  }

  static auth(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.Auth, message, code, cause);
  }

  static camera(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.Camera, message, code, cause);
  }

  static storage(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.Storage, message, code, cause);
  }

  static ml(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.ML, message, code, cause);
  }

  static permission(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.Permission, message, code, cause);
  }

  static unknown(message: string, code: string | null = null, cause?: unknown): AppError {
    return new AppError(ErrorType.Unknown, message, code, cause);
  }
}
