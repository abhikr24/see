/**
 * Unit 22 - central error normalization, logging, and global RN handler.
 * Raw vendor errors never reach presentation code; every caller receives a
 * typed AppError with copy safe to show to a user.
 */
import { AppLogger } from '@/core/utils/logger';
import { AppError } from './appError';
import { ErrorType } from './errorTypes';

interface ErrorShape {
  readonly message?: unknown;
  readonly code?: unknown;
  readonly status?: unknown;
  readonly name?: unknown;
}

function shapeOf(error: unknown): ErrorShape {
  return typeof error === 'object' && error !== null ? (error as ErrorShape) : {};
}

function rawMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  const shaped = shapeOf(error).message;
  return typeof shaped === 'string' ? shaped : String(error);
}

function codeOf(error: unknown): string | null {
  const code = shapeOf(error).code;
  return typeof code === 'string' || typeof code === 'number' ? String(code) : null;
}

function statusOf(error: unknown): number | null {
  const status = shapeOf(error).status;
  return typeof status === 'number' ? status : null;
}

class ErrorHandler {
  mapError(error: unknown): AppError {
    if (error instanceof AppError) return error;

    const sourceMessage = rawMessage(error);
    const normalized = `${sourceMessage} ${String(shapeOf(error).name ?? '')} ${codeOf(error) ?? ''}`.toLowerCase();
    const code = codeOf(error);
    const status = statusOf(error);

    if (
      normalized.includes('permission') ||
      normalized.includes('denied') ||
      normalized.includes('not authorized')
    ) {
      return AppError.permission(
        'This feature needs permission. Review access in your device settings and try again.',
        code,
        error,
      );
    }

    if (
      status === 401 ||
      status === 403 ||
      normalized.includes('auth') ||
      normalized.includes('jwt') ||
      normalized.includes('session') ||
      normalized.includes('invalid login') ||
      normalized.includes('unauthorized')
    ) {
      return AppError.auth(
        'Your session could not be verified. Sign in again and retry.',
        code,
        error,
      );
    }

    if (
      status === 0 ||
      status === 408 ||
      (status !== null && status >= 500) ||
      normalized.includes('network') ||
      normalized.includes('fetch') ||
      normalized.includes('offline') ||
      normalized.includes('timeout') ||
      normalized.includes('connection')
    ) {
      return AppError.network(
        'Check your internet connection and try again.',
        code,
        error,
      );
    }

    if (
      normalized.includes('mediapipe') ||
      normalized.includes('pose detector') ||
      normalized.includes('pose detection') ||
      normalized.includes('landmarker') ||
      normalized.includes('wasm') ||
      normalized.includes('model')
    ) {
      return AppError.ml(
        'Pose detection is unavailable right now. Reload the AI model and try again.',
        code,
        error,
      );
    }

    if (
      normalized.includes('camera') ||
      normalized.includes('viewfinder') ||
      normalized.includes('lens') ||
      normalized.includes('takepicture')
    ) {
      return AppError.camera(
        'Camera unavailable. Close other camera apps, then try again.',
        code,
        error,
      );
    }

    if (
      normalized.includes('mmkv') ||
      normalized.includes('storage') ||
      normalized.includes('file') ||
      normalized.includes('disk') ||
      normalized.includes('gallery') ||
      normalized.includes('cache')
    ) {
      return AppError.storage(
        'Local data could not be read. Your device photos have not been changed.',
        code,
        error,
      );
    }

    return AppError.unknown(
      'Something went wrong. Please try again.',
      code,
      error,
    );
  }

  handle(error: unknown, context: string = 'Application'): AppError {
    const appError = this.mapError(error);
    AppLogger.error(
      `[${context}] ${appError.type}${appError.code ? `/${appError.code}` : ''} - ${appError.message}`,
      appError.originalError ?? error,
    );
    return appError;
  }
}

export const errorHandler = new ErrorHandler();

type GlobalErrorHandler = (error: unknown, isFatal?: boolean) => void;
interface NativeErrorUtils {
  readonly getGlobalHandler?: () => GlobalErrorHandler;
  readonly setGlobalHandler: (handler: GlobalErrorHandler) => void;
}

/** Installs once per root mount and restores React Native's prior handler. */
export function installGlobalErrorHandler(): () => void {
  const runtime = globalThis as typeof globalThis & { ErrorUtils?: NativeErrorUtils };
  const utils = runtime.ErrorUtils;
  if (utils === undefined) {
    AppLogger.debug('[ErrorHandler] native ErrorUtils unavailable on this platform');
    return () => undefined;
  }

  const previous = utils.getGlobalHandler?.();
  const handler: GlobalErrorHandler = (error, isFatal = false) => {
    errorHandler.handle(error, isFatal ? 'Global/Fatal' : 'Global');
    // Preserve React Native's native redbox/crash reporting after our durable
    // log. Swallowing fatal errors would hide defects and leave corrupt state.
    previous?.(error, isFatal);
  };
  utils.setGlobalHandler(handler);

  return () => {
    if (previous !== undefined) utils.setGlobalHandler(previous);
  };
}

export { ErrorType } from './errorTypes';
export { AppError } from './appError';
