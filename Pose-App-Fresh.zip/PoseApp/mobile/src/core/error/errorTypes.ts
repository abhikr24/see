/** Unit 22 - stable categories used by logging, UI copy, and retry policy. */
export enum ErrorType {
  Network = 'network',
  Auth = 'auth',
  Camera = 'camera',
  Storage = 'storage',
  ML = 'ml',
  Permission = 'permission',
  Unknown = 'unknown',
}
