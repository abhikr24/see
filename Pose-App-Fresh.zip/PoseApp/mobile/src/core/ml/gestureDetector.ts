/**
 * App-facing gesture surface.
 *
 * `detectHandPresentation` is the CHEAP pose-level pre-filter (is a hand
 * plausibly raised?). It cannot authorise a capture on its own.
 * `classifyOpenPalm` / `selectCaptureHand` read the real 21-point hand
 * landmarks, and `OpenPalmGate` owns the temporal confirmation, cooldown and
 * release rules. All three are platform-neutral and live in shared/.
 */
export {
  detectHandPresentation,
  classifyOpenPalm,
  selectCaptureHand,
  OpenPalmGate,
  OPEN_PALM_THRESHOLDS,
  OPEN_PALM_GATE_TIMING,
  type GestureHand,
  type HandPresentationResult,
  type HandObservation,
  type OpenPalmEvidence,
  type OpenPalmPhase,
  type OpenPalmGateSnapshot,
} from '@shared/index';
export { handDetectorService } from './handDetectorService';
