/**
 * Unit 17 — Guidance generator facade (spec §17.3 file 1).
 *
 * Exposes the pure guidance generation engine from @shared/index.
 */
export {
  generatePoseGuidance,
  GUIDANCE_THRESHOLDS,
  type ArrowDirection,
  type GuidanceResult,
  type GuidanceSeverity,
} from '@shared/index';
