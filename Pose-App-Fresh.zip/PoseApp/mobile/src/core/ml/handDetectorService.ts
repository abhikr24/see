/**
 * mobile/src/core/ml/handDetectorService.ts — HandLandmarker singleton.
 *
 * WHY A SECOND DETECTOR EXISTS AT ALL
 *
 * Gesture capture used to be decided from PoseLandmarker's four hand points,
 * which cannot represent finger articulation (see shared/ml/gestureDetector.ts
 * for the full root-cause note). Distinguishing an intentional five-finger
 * open palm from a fist, a wave or a pointing finger requires per-finger
 * joints, and the smallest way to get them inside the existing MediaPipe
 * architecture is the sibling HandLandmarker task from the SAME
 * `@mediapipe/tasks-vision` package that is already installed and pinned.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO
 *
 *   · it does not touch the pose pipeline, the analysis engine or any
 *     pose-matching mathematics — gesture stays a separate concern;
 *   · it does not grab its own camera frames. The caller hands it the SAME
 *     PoseFrame the pose detector just consumed, so a gesture frame costs one
 *     extra inference, never an extra capture;
 *   · it does not run on every frame. CameraTab only calls it when the cheap
 *     pose-level pre-filter says a hand is plausibly raised, and never while
 *     a capture flow is active;
 *   · it does not re-initialise. One landmarker for the whole session,
 *     created lazily on the first frame that needs it and closed on dispose.
 *
 * SAFETY DEFAULT: if the landmarker cannot be created (no wasm runtime, no
 * network for the model, unsupported device) this service stays 'unavailable'
 * and returns null forever. Gesture capture then simply never fires. It does
 * NOT fall back to the old pose-only guess, because that guess is exactly the
 * accidental-capture bug. Manual capture and auto capture are untouched.
 *
 * Privacy invariant is unchanged: inference is on-device; frames and
 * landmarks never leave the phone. The model binary is a download.
 */
import { AppLogger } from '@/core/utils/logger';
import {
  HAND_LANDMARK_COUNT,
  type HandObservation,
  type HandSide,
} from '@shared/index';
import { monotonicTimestamp, type PoseFrame } from './imageConverter';

/** ABI-locked to the installed @mediapipe/tasks-vision (0.10.35), like pose. */
const MEDIAPIPE_WASM_BASE_URL =
  'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm';
const MEDIAPIPE_HAND_MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

export type HandDetectorStatus = 'idle' | 'loading' | 'ready' | 'unavailable';

/* Structural vendor surface — no DOM-shaped vendor types leak into the app. */
interface VisionFileset {
  readonly wasmLoaderPath: string;
  readonly wasmBinaryPath: string;
}
interface VisionLandmark {
  readonly x: number;
  readonly y: number;
  readonly z: number;
  readonly visibility?: number;
}
interface VisionCategory {
  readonly categoryName?: string;
  readonly displayName?: string;
  readonly score?: number;
}
interface VisionHandResult {
  readonly landmarks?: ReadonlyArray<ReadonlyArray<VisionLandmark>>;
  readonly handedness?: ReadonlyArray<ReadonlyArray<VisionCategory>>;
  readonly handednesses?: ReadonlyArray<ReadonlyArray<VisionCategory>>;
}
interface VisionHandLandmarker {
  detectForVideo?(source: unknown, timestampMs: number): VisionHandResult;
  detect?(source: unknown): VisionHandResult;
  close(): void;
}
interface MediapipeVisionModule {
  readonly FilesetResolver: {
    forVisionTasks(basePath: string): Promise<VisionFileset>;
  };
  readonly HandLandmarker: {
    createFromOptions(
      fileset: VisionFileset,
      options: Record<string, unknown>,
    ): Promise<VisionHandLandmarker>;
  };
}

/** Consecutive detect exceptions tolerated before gesture input is parked. */
const MAX_CONSECUTIVE_FAILURES = 8;

function sideOf(category: VisionCategory | undefined): HandSide {
  const label = (category?.categoryName ?? category?.displayName ?? '').toLowerCase();
  if (label === 'left') return 'left';
  if (label === 'right') return 'right';
  return 'unknown';
}

class HandDetectorServiceImpl {
  private landmarker: VisionHandLandmarker | null = null;
  private initPromise: Promise<boolean> | null = null;
  private status: HandDetectorStatus = 'idle';
  private ready = false;
  private lastVideoTimestamp = 0;
  private consecutiveFailures = 0;
  /** A failed load is never retried inside one session — it will fail again. */
  private loadFailed = false;

  get isModelReady(): boolean {
    return this.ready;
  }

  get currentStatus(): HandDetectorStatus {
    return this.status;
  }

  /** Idempotent; concurrent callers share one in-flight load. */
  async init(): Promise<boolean> {
    if (this.ready && this.landmarker !== null) return true;
    if (this.loadFailed) return false;
    if (this.initPromise !== null) return this.initPromise;
    this.status = 'loading';
    this.initPromise = this.loadModel();
    const ready = await this.initPromise;
    this.initPromise = null;
    return ready;
  }

  private async loadModel(): Promise<boolean> {
    const startedAt = Date.now();
    AppLogger.info('[Gesture] HandLandmarker init — hand_landmarker (on-device wasm)');
    try {
      const vision = (await import(
        '@mediapipe/tasks-vision'
      )) as unknown as MediapipeVisionModule;
      const fileset = await vision.FilesetResolver.forVisionTasks(MEDIAPIPE_WASM_BASE_URL);
      this.landmarker = await vision.HandLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MEDIAPIPE_HAND_MODEL_URL },
        runningMode: 'VIDEO',
        /* Two hands, because the user may have both up; the classifier picks
           the ONE that actually forms a capture command. */
        numHands: 2,
        minHandDetectionConfidence: 0.6,
        minHandPresenceConfidence: 0.6,
        minTrackingConfidence: 0.6,
      });
      this.ready = true;
      this.status = 'ready';
      this.lastVideoTimestamp = 0;
      this.consecutiveFailures = 0;
      AppLogger.info(
        `[Gesture] hand model ready in ${Date.now() - startedAt}ms — 21 landmarks/hand`,
      );
      return true;
    } catch (error) {
      this.landmarker = null;
      this.ready = false;
      this.loadFailed = true;
      this.status = 'unavailable';
      /* Scoped, silent degradation: gesture capture is off, every other
         capture path keeps working. Not routed through errorHandler because
         it must NOT raise a user-facing error for an optional input mode. */
      AppLogger.warn(
        `[Gesture] hand landmarker unavailable — gesture capture disabled this session (${String(error)})`,
      );
      return false;
    }
  }

  /**
   * Runs on a frame the pose detector has ALREADY consumed. Returns null when
   * the detector is not usable (never an empty-but-confident answer), and []
   * when a frame was processed and no hand was found.
   */
  async detect(frame: PoseFrame): Promise<readonly HandObservation[] | null> {
    const landmarker = this.landmarker;
    if (landmarker === null || !this.ready) return null;
    const videoTimestamp = monotonicTimestamp(this.lastVideoTimestamp, frame.timestampMs);
    try {
      const detectForVideo = landmarker.detectForVideo?.bind(landmarker);
      const result =
        detectForVideo !== undefined
          ? detectForVideo(frame.source, videoTimestamp)
          : landmarker.detect?.(frame.source);
      this.lastVideoTimestamp = videoTimestamp;
      this.consecutiveFailures = 0;
      const hands = result?.landmarks ?? [];
      const handedness = result?.handedness ?? result?.handednesses ?? [];
      const observations: HandObservation[] = [];
      for (let index = 0; index < hands.length; index += 1) {
        const points = hands[index];
        if (points === undefined || points.length < HAND_LANDMARK_COUNT) continue;
        const category = handedness[index]?.[0];
        observations.push({
          landmarks: points.map((point) => ({
            x: point.x,
            y: point.y,
            z: point.z,
            visibility: point.visibility,
          })),
          side: sideOf(category),
          /* No handedness score means the runtime did not report one; 0 is the
             safe reading, because the classifier treats low confidence as
             "not a command" rather than "assume it is fine". */
          score: typeof category?.score === 'number' ? category.score : 0,
        });
      }
      return observations;
    } catch (error) {
      this.consecutiveFailures += 1;
      if (this.consecutiveFailures === 1) {
        AppLogger.warn(`[Gesture] hand detection error — ${String(error)}`);
      }
      if (this.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
        this.ready = false;
        this.status = 'unavailable';
        AppLogger.error(
          `[Gesture] hand detection failed ${MAX_CONSECUTIVE_FAILURES}× consecutively — gesture capture parked`,
        );
      }
      return null;
    }
  }

  dispose(): void {
    if (this.landmarker !== null) {
      try {
        this.landmarker.close();
      } catch (error) {
        AppLogger.warn(`[Gesture] hand landmarker close raised — ${String(error)}`);
      }
    }
    this.landmarker = null;
    this.ready = false;
    this.status = 'idle';
    this.initPromise = null;
    this.lastVideoTimestamp = 0;
    this.consecutiveFailures = 0;
    this.loadFailed = false;
    AppLogger.info('[Gesture] hand landmarker disposed');
  }
}

export const handDetectorService = new HandDetectorServiceImpl();
