/**
 * Unit 16 — PoseFrame contract + frame-source conversion (spec §16.3 file 3).
 *
 * MediaPipe's JS runtime consumes TexImageSource-like inputs (video element,
 * ImageBitmap, canvas). The rest of the app must never depend on those web
 * shape names, so every camera frame passes through this module and becomes
 * a PoseFrame: an opaque source handle plus the metadata the pipeline needs
 * (dimensions, monotonic timestamp, rotation, mirror).
 *
 * Rotation: the lite model tolerates upright ±15°. Forward-facing frames
 * arrive upright; device-orientation locks are normalized here so the
 * overlay projection and (future) rotated-frame feeding stay consistent.
 */

/** 15fps ML budget from the spec: one detection per 66ms, UI stays 60fps. */
export const ML_FRAME_THROTTLE_MS = 66;

export type FrameRotationDegrees = 0 | 90 | 180 | 270;

export interface PoseFrame {
  /**
   * Platform TexImageSource when the runtime is wasm-capable (web), or an
   * app-decoded bitmap on such runtimes. Opaque by design: only the
   * detector service touches it.
   */
  readonly source: unknown;
  readonly width: number;
  readonly height: number;
  /** Monotonic ms timestamp — MediaPipe VIDEO mode requires strictly increasing input. */
  readonly timestampMs: number;
  readonly rotation: FrameRotationDegrees;
}

/** Normalizes any device rotation to the nearest 90° step MediaPipe expects. */
export function normalizeRotation(degrees: number): FrameRotationDegrees {
  const quarter = (Math.round(degrees / 90) * 90) % 360;
  const positive = (quarter + 360) % 360;
  return positive as FrameRotationDegrees;
}

/**
 * MediaPipe VIDEO mode throws on equal/decreasing timestamps. Given the last
 * handed-out timestamp and a candidate, returns the next legal value.
 */
export function monotonicTimestamp(previous: number, candidate: number): number {
  return candidate > previous ? candidate : previous + 1;
}

/** Structural video element — no DOM types leak into app code. */
export interface VideoFrameSource {
  readonly videoWidth: number;
  readonly videoHeight: number;
}

/** Frame backed by a live video source (web runtimes). */
export function createVideoFrame(
  video: unknown,
  metrics: VideoFrameSource,
  timestampMs: number,
  rotation: FrameRotationDegrees = 0,
): PoseFrame {
  return {
    source: video,
    width: metrics.videoWidth,
    height: metrics.videoHeight,
    timestampMs,
    rotation,
  };
}

/** Frame backed by a decoded still image (photo-mode sampling seam). */
export function createPhotoFrame(
  image: unknown,
  width: number,
  height: number,
  timestampMs: number,
  rotation: FrameRotationDegrees = 0,
): PoseFrame {
  return { source: image, width, height, timestampMs, rotation };
}
