/**
 * Unit 17 — Joint color mapper facade (spec §17.3 file 2).
 *
 * Exposes joint and bone color mapping utilities from @shared/index.
 */
export {
  colorForDiff,
  mapBoneColors,
  mapLandmarkColors,
  JOINT_STATUS_COLORS,
} from '@shared/index';
