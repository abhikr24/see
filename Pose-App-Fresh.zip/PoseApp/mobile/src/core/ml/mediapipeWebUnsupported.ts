/**
 * mediapipeWebUnsupported.ts — Metro web substitute for @mediapipe/tasks-vision.
 *
 * WHY THIS FILE EXISTS (Phase-1 web-build repair)
 * -----------------------------------------------
 * `@mediapipe/tasks-vision@0.10.35` ships `vision_bundle.mjs`, which contains
 * a non-literal dynamic import (`import(t.toString())`). Metro — the bundler
 * every Expo target uses — cannot transform that expression, so ANY bundle
 * that includes the package fails to build. On Android/iOS that is fine:
 * `poseDetectorService.loadModel()` imports it lazily and Hermes only
 * evaluates what actually ships through the native bundler graph — but
 * `expo start --web` / `expo export --platform web` must transform the async
 * chunk up front and the whole web bundle dies.
 *
 * metro.config.js therefore redirects `@mediapipe/tasks-vision` to this
 * file on EVERY platform (post-A1 scope update): pose detection on
 * Android/iOS is REAL and NATIVE (VisionCamera + ML Kit via
 * mobile/native/vision-camera-mlkit-pose) and never touches this package, so
 * the remaining WASM consumers (hand landmarker, legacy poseDetectorService)
 * resolve here everywhere. Metro never transforms vision_bundle.mjs on any
 * platform (so `expo export` / EAS bundle succeeds), and the coded throw
 * below feeds each consumer's existing scoped 'unavailable' fallback.
 *
 * This module deliberately keeps the exact surface all consumers destructure
 * (`FilesetResolver`, `PoseLandmarker`, `HandLandmarker`), and every member
 * throws a clearly-coded error. The service
 * already treats an init throw as the documented scoped fallback
 * ('unavailable' → AppError.ml → camera shell keeps Unit 12–13 behavior with
 * overlays hidden), matching RELEASE-READINESS.md's "Camera not supported on
 * web" stance. No production behavior changes; no preview/tooling code is
 * involved; the real MediaPipe implementation is never hidden here.
 */
const MEDIAPIPE_WEB_REASON =
  '@mediapipe/tasks-vision is intentionally not bundled in Expo Web builds ' +
  '(Metro cannot transform vision_bundle.mjs). On-device pose detection is ' +
  'available on Android/iOS; the web camera route stays in its documented ' +
  'unsupported-browser state.';

class MediaPipeWebUnavailableError extends Error {
  readonly code = 'ERR_MEDIAPIPE_WEB_UNSUPPORTED';
  constructor() {
    super(MEDIAPIPE_WEB_REASON);
    this.name = 'MediaPipeWebUnavailableError';
  }
}

export const FilesetResolver = {
  forVisionTasks: async (): Promise<never> => {
    throw new MediaPipeWebUnavailableError();
  },
} as const;

export const PoseLandmarker = {
  createFromOptions: async (): Promise<never> => {
    throw new MediaPipeWebUnavailableError();
  },
  createFromModelPath: async (): Promise<never> => {
    throw new MediaPipeWebUnavailableError();
  },
} as const;

/* Consumed by handDetectorService.loadModel() (open-palm capture). On
   Android/iOS the coded throw lands in that service's existing catch, which
   parks gesture capture as 'unavailable' for the session — the documented
   hand-on-native behaviour (metro.config.js comment, camera docs). */
export const HandLandmarker = {
  createFromOptions: async (): Promise<never> => {
    throw new MediaPipeWebUnavailableError();
  },
  createFromModelPath: async (): Promise<never> => {
    throw new MediaPipeWebUnavailableError();
  },
} as const;
