/**
 * A1 — nativePosePlugin: the ONLY module in the app that talks to the local
 * Nitro frame-processor plugin (`vision-camera-mlkit-pose`, Google ML Kit
 * Pose Detection). Everything above it (runtime, adapter, engine) consumes
 * plain data structures — no Nitro/Frame/plugin types leak past this file.
 *
 * SAFETY MODEL (rule: fail safe, never fake):
 *   · The plugin lives in a custom dev-client / prebuild only. In Expo Go,
 *     a web bundle, or any host where the native module is missing, loading
 *     throws — we catch it ONCE and report `null`, so the runtime can park
 *     live guidance as 'unavailable' (scoped per-feature fallback, exactly
 *     like Unit 16 defined) while the rest of the camera keeps working.
 *   · There is deliberately NO takePictureAsync/JPEG/base64 fallback here.
 *     That path was A1 and it is gone.
 *
 * THREADING: `detect()` is called from the VisionCamera frame-output worklet
 * on the camera thread (synchronous native call). `dispose()` is called from
 * JS during teardown. Nothing else in the app touches the detector handle.
 */
import { AppLogger } from '@/core/utils/logger';
import type { NativePoseFrame } from '@shared/index';

/**
 * The structural surface of the local plugin. The plugin package ships real
 * Nitro types; we depend structurally so this file compiles even where the
 * package's native code is absent (and so swapping the detector inside the
 * plugin never ripples into app code). `frame` stays opaque ON PURPOSE — it
 * is created on the frame thread and must never be held past the worklet.
 */
export interface NativePoseDetectorHandle {
  /**
   * Synchronous, frame-thread inference on ONE camera frame. Must be called
   * inside the frame-output worklet, and the frame must be disposed by the
   * CALLER (finally) afterwards. Returns a NativePoseFrame with landmarks in
   * upright image pixels + the mirrored/orientation/dims metadata the shared
   * adapter needs; `landmarks: []` = no person in frame.
   */
  detect(frame: unknown): NativePoseFrame;
  /** Release the native detector (ML Kit PoseDetector.close()). Idempotent. */
  dispose(): void;
}

/** Options the native detector is constructed with (stream/bitmap defaults). */
export interface NativePoseDetectorOptions {
  /**
   * 'stream' (default) = tracking-optimized VIDEO semantics — required: the
   * old WASM path ran VIDEO mode too, so this preserves behaviour 1:1.
   */
  readonly mode: 'stream' | 'single';
  /** Minimum detection confidence surfaced to ML Kit (0.5 = old default). */
  readonly minConfidence: number;
}

export const NATIVE_POSE_DEFAULT_OPTIONS: NativePoseDetectorOptions = {
  mode: 'stream',
  minConfidence: 0.5,
};

/** Structural mirror of the plugin's public JS entry (kept import-free). */
interface NativePosePluginModule {
  readonly createPoseDetector: (
    options: NativePoseDetectorOptions,
  ) => NativePoseDetectorHandle;
}

let cachedModule: NativePosePluginModule | null | undefined;
let unavailableReason: string | null = null;

function loadPluginModule(): NativePosePluginModule | null {
  if (cachedModule !== undefined) return cachedModule;
  try {
    /* Dynamic require so a missing native module never breaks bundling or
       other screens. Metro resolves this statically fine for dev-clients;
       the try/catch is for RUNTIME absence (Expo Go / unsupported builds). */
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require('vision-camera-mlkit-pose') as NativePosePluginModule;
    cachedModule = typeof mod?.createPoseDetector === 'function' ? mod : null;
    if (cachedModule === null) {
      unavailableReason = 'plugin module resolved but exposes no createPoseDetector';
      AppLogger.warn(`[ML/Native] pose plugin unusable — ${unavailableReason}`);
    }
  } catch (error) {
    cachedModule = null;
    unavailableReason = String(error);
    AppLogger.warn(
      `[ML/Native] pose plugin not available in this build (expected in Expo Go / web) — ${unavailableReason}`,
    );
  }
  return cachedModule;
}

/**
 * Create the native detector, or null when this build cannot provide native
 * frame processing. NEVER throws. Construction does a real ML Kit
 * PoseDetector allocation on the native side, so treat nullability as the
 * feature gate it is (and dispose() what you receive).
 */
export function createNativePoseDetector(
  options: NativePoseDetectorOptions = NATIVE_POSE_DEFAULT_OPTIONS,
): NativePoseDetectorHandle | null {
  const mod = loadPluginModule();
  if (mod === null) return null;
  try {
    return mod.createPoseDetector(options);
  } catch (error) {
    AppLogger.error(`[ML/Native] detector construction failed — ${String(error)}`);
    return null;
  }
}

/** Why the plugin is unavailable (diagnostics; null when available). */
export function nativePoseUnavailableReason(): string | null {
  void loadPluginModule();
  return cachedModule === null ? unavailableReason : null;
}
