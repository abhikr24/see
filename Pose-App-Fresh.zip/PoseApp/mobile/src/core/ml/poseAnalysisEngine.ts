/**
 * Unit 29 — Pose-analysis engine facade.
 *
 * Exposes the deterministic engine from @shared/index to the app exactly the
 * way core/ml/guidanceGenerator.ts fronts the Unit 17 generator: feature
 * screens import from here, never from shared internals.
 *
 *   live landmarks → measurements → comparison → error → confidence →
 *   severity → priority → temporal stability → ONE semantic decision
 *
 * The engine is pure math: no camera, no TTS, no network, no Supabase. The
 * screen owns the frame pump; the engine owns the verdict.
 */
export {
  createPoseAnalysisEngine,
  decisionToGuidance,
  /* Unit 31: the match % is DERIVED from the decision's comparisons, so the
     frame loop runs the joint geometry once instead of twice. */
  matchFromDecision,
  matchFromComparisons,
  ANALYSIS_STATE_EVALUATING,
  ANALYSIS_STATE_PERFECT,
  ANALYSIS_STATE_UNAVAILABLE,
  GOOD_TOLERANCE_DEGREES,
  CORRECTION_THRESHOLD_DEGREES,
  type AnalysisReferenceInput,
  type AnalysisUnavailable,
  type AnalysisUnavailableReason,
  type CorrectionCandidate,
  type MeasurementComparison,
  type PoseAnalysisDecision,
  type PoseAnalysisEngine,
} from '@shared/index';
