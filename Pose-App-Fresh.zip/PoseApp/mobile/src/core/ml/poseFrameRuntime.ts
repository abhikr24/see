/**
 * A1 — poseFrameRuntime: JS-thread orchestration of the NATIVE live pose
 * pipeline. Sits exactly where the old 66 ms takePictureAsync pump sat, but
 * consumes real native frame results instead of fabricating them.
 *
 *   VisionCamera frame thread (worklet)          JS thread
 *   ────────────────────────────────────────────────────────
 *   detector.detect(frame)  ── runOnJS ──▶  runtime.receiveNativeResult()
 *                                               │ adaptNativePoseFrame()
 *                                               ▼
 *                                     consumer(PoseLandmark[] | null, meta)
 *                                               │  (CameraTab: engine,
 *                                               │   coaching, speech, UI)
 *
 * Every DECISION (admit/drop/stale/epoch/fatal-failure-count) is delegated to
 * the pure shared PoseFrameScheduler so the policy is unit-tested at the
 * shared level; this class only wires IO + the detector handle.
 *
 * FAILURE POLICY (mirrors Unit 16 exactly): one failed inference = counted
 * and skipped; MAX_CONSECUTIVE_FAILURES in a row = detector parked
 * 'unavailable' (scoped to live guidance, camera unaffected). No retry storm:
 * failures never re-schedule work, they only count down the park budget.
 */
import { AppLogger } from '@/core/utils/logger';
import {
  adaptNativePoseFrame,
  PoseFrameScheduler,
  type NativePoseFrame,
  type PoseFrameMetrics,
  type PoseLandmark,
} from '@shared/index';
import type { NativePoseDetectorHandle } from './nativePosePlugin';

const MAX_CONSECUTIVE_FAILURES = 8;

export type PoseRuntimeStatus = 'idle' | 'running' | 'unavailable';

/** What the consumer receives per admitted, adapted result. */
export interface PoseFrameConsumption {
  /** null = unusable frame (bad dims/shape); [] = frame valid, no body. */
  readonly landmarks: readonly PoseLandmark[] | null;
  /** Upright frame dims + timestamp — the overlay scaling inputs the old
   *  pump took from the throwaway JPEG (`mlFrameSize`). */
  readonly frame: {
    readonly width: number;
    readonly height: number;
    readonly timestampMs: number;
  };
}

export type PoseFrameConsumer = (consumption: PoseFrameConsumption) => void;

export interface PoseRuntimeMetrics extends PoseFrameMetrics {
  readonly nativeErrors: number;
  readonly averageInferenceMs: number;
}

export class PoseFrameRuntime {
  private readonly scheduler = new PoseFrameScheduler();
  private detector: NativePoseDetectorHandle | null = null;
  private consumer: PoseFrameConsumer | null = null;
  private status: PoseRuntimeStatus = 'idle';
  private consecutiveFailures = 0;
  private inferenceTotalMs = 0;
  private inferenceSamples = 0;
  private pipelineDropped = 0;

  get currentStatus(): PoseRuntimeStatus {
    return this.status;
  }

  /** The epoch future bridge deliveries must carry (PAUSE/FACING contract). */
  get currentEpoch(): number {
    return this.scheduler.currentEpoch;
  }

  /**
   * Attach a constructed detector (may be null → 'unavailable') and start
   * consuming. Idempotent-safe: starting an already running session is a
   * no-op beyond swapping the consumer.
   */
  start(detector: NativePoseDetectorHandle | null, consumer: PoseFrameConsumer): PoseRuntimeStatus {
    this.detachDetector();
    this.consumer = consumer;
    this.consecutiveFailures = 0;
    this.inferenceTotalMs = 0;
    this.inferenceSamples = 0;
    this.pipelineDropped = 0;
    if (detector === null) {
      this.status = 'unavailable';
      this.consumer = null;
      return this.status;
    }
    this.detector = detector;
    this.scheduler.start();
    this.status = 'running';
    AppLogger.info('[ML/Native] pose frame runtime started (frame-driven, 15fps budget)');
    return this.status;
  }

  /**
   * The frame-thread surface the worklet uses. Returned ONCE and captured by
   * the frame-output worklet closure; reads the CURRENT detector each call,
   * so a swap never re-creates the worklet.
   */
  get workletApi(): { readonly detectSync: (frame: unknown) => NativePoseFrame } {
    return {
      detectSync: (frame: unknown): NativePoseFrame => {
        if (this.detector === null) {
          throw new Error('native pose detector is not attached');
        }
        return this.detector.detect(frame);
      },
    };
  }

  /**
   * Pause WITHOUT tearing down: capture flow start, camera facing switch.
   * Everything already bridged is invalidated via the epoch; the caller
   * stamps FUTURE worklet deliveries with the returned epoch.
   */
  invalidateEpoch(): number {
    return this.scheduler.invalidateEpoch();
  }

  /**
   * Called from the JS bridge with the RAW native payload. Full policy path:
   * admit (shared scheduler) → adapt (shared transform) → consume.
   */
  receiveNativeResult(nativeFrame: NativePoseFrame, epoch: number): void {
    if (this.status !== 'running') return;
    const arrivalMs = Date.now();
    const admission = this.scheduler.admit(nativeFrame.timestampMs, arrivalMs, epoch);
    if (!admission.admitted) return;
    try {
      const landmarks = adaptNativePoseFrame(nativeFrame);
      this.consecutiveFailures = 0;
      if (typeof nativeFrame.inferenceMs === 'number' && nativeFrame.inferenceMs >= 0) {
        this.inferenceTotalMs += nativeFrame.inferenceMs;
        this.inferenceSamples += 1;
      }
      this.consumer?.({
        landmarks,
        frame: {
          width: nativeFrame.width,
          height: nativeFrame.height,
          timestampMs: nativeFrame.timestampMs,
        },
      });
    } catch (error) {
      /* A consumer crash must not kill the loop or double-count as detector
         failure; the frame is simply lost (same as old pumpFrame try/finally). */
      AppLogger.warn(`[ML/Native] consumer raised — ${String(error)}`);
    } finally {
      this.scheduler.done();
    }
  }

  /**
   * Called from the JS bridge when the worklet reports a native inference
   * ERROR (detector threw on the frame thread). Mirrors Unit 16: counted,
   * skipped; 8 in a row parks the feature as 'unavailable' (scoped).
   */
  receiveNativeError(message: string): void {
    if (this.status !== 'running') return;
    this.consecutiveFailures += 1;
    if (this.consecutiveFailures === 1) {
      AppLogger.warn(`[ML/Native] frame inference error — ${message}`);
    }
    if (this.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
      AppLogger.error(
        `[ML/Native] inference failed ${MAX_CONSECUTIVE_FAILURES}× consecutively — live pose parked until session restart`,
      );
      this.park();
    }
  }

  /** Frames VisionCamera had to drop before they reached the worklet. */
  receivePipelineDrop(): void {
    this.pipelineDropped += 1;
  }

  /** Park the feature: releases the detector, keeps the object reusable. */
  private park(): void {
    this.detachDetector();
    this.scheduler.stop();
    this.status = 'unavailable';
  }

  private detachDetector(): void {
    const detector = this.detector;
    this.detector = null;
    if (detector !== null) {
      try {
        detector.dispose();
      } catch (error) {
        AppLogger.warn(`[ML/Native] detector dispose raised — ${String(error)}`);
      }
    }
  }

  /** Total teardown: unmount / blur / background. Idempotent. */
  stop(): void {
    if (this.status === 'idle' && this.detector === null) return;
    AppLogger.info(
      `[ML/Native] pose frame runtime stopped — ${JSON.stringify(this.snapshotMetrics())}`,
    );
    this.detachDetector();
    this.scheduler.stop();
    this.consumer = null;
    this.status = 'idle';
  }

  snapshotMetrics(): PoseRuntimeMetrics {
    const base = this.scheduler.getMetrics();
    return {
      ...base,
      /* VisionCamera-side drops surface inside droppedStopped's report slot
         via the log line; the scheduler copy stays pure per-responsibility. */
      nativeErrors: this.consecutiveFailures,
      averageInferenceMs:
        this.inferenceSamples === 0 ? 0 : Math.round(this.inferenceTotalMs / this.inferenceSamples),
    };
  }
}

/** One runtime per camera screen instance (created inside the screen). */
export function createPoseFrameRuntime(): PoseFrameRuntime {
  return new PoseFrameRuntime();
}
