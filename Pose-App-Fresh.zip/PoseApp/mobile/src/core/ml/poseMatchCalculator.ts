/**
 * Unit 16 — app-facing match calculator (spec §16.3 file 2).
 *
 * The pure math lives in shared/ml/poseMatch.ts so the Expo app and the
 * preview mirror run the identical comparison; this module is the stable
 * app-side import contract — Unit 17 (visual guidance) reads getAngleDiffs()
 * from here to pick the worst joint.
 */
export {
  calculateAngle,
  calculateMatchPercent,
  diffToPercent,
  getAngleDiffs,
  jointAngle,
  MIN_LANDMARK_VISIBILITY,
  type MatchResult,
} from '@shared/index';
