/**
 * A1 — useNativePoseFrameOutput: builds and tears down the VisionCamera
 * CameraFrameOutput that turns native camera frames into pose results. This
 * is THE seam where the app becomes frame-driven:
 *
 *   CameraFrameOutput (yuv, ≤640×480, dropFramesWhileBusy, camera thread)
 *     └ onFrame worklet: detector.detect(frame)         [native ML Kit call]
 *        └ runOnJS(bridge)(result, epoch)               [JS thread]
 *           └ runtime.receiveNativeResult → adapt → consume
 *     └ frame.dispose() in a finally on EVERY arrival (the camera buffer
 *        pool must never starve)
 *     └ onFrameDropped → runtime.receivePipelineDrop() (metrics only)
 *
 * Faithful 1:1 replication of react-native-vision-camera's own useFrameOutput
 * wiring (createFrameOutput → setOnFrameDroppedCallback → worklets provider
 * createRuntimeForThread → setOnFrameCallback), reproduced HERE instead of
 * using the hook for ONE reason: every vision-camera require is lazy +
 * guarded, so a host without the native module (Expo Go, metro-web) degrades
 * to 'unavailable' instead of crashing the bundle at import time. The ML
 * gate (`enabled`) further guarantees the output exists only while live
 * guidance should actually run; the Camera then never delivers frames for a
 * detached output.
 *
 * The worklet closure captures ONLY shareables: the Nitro detector handle +
 * bridge functions wrapped by runOnJS. No plain-JS closure is ever called on
 * the frame thread (that would crash a worklet runtime).
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { AppLogger } from '@/core/utils/logger';
import type { NativePoseFrame } from '@shared/index';
import type { NativePoseDetectorHandle } from './nativePosePlugin';
import type { PoseFrameRuntime } from './poseFrameRuntime';

/* ── Lazy library surface (requires are guarded + evaluated on first use) ── */

interface VisionCameraApi {
  readonly createFrameOutput: (options: Record<string, unknown>) => unknown;
  readonly runOnJs: <A extends unknown[]>(fn: (...args: A) => void) => (...args: A) => void;
  readonly createRuntimeForThread: (frameOutput: unknown, onFrame: unknown) => () => void;
}

/**
 * Loads { VisionCamera, worklets provider, runOnJS } ONCE. Returns null when
 * any piece is missing (non-native host). Never throws.
 *
 * Wiring below mirrors react-native-vision-camera@5.2.3
 * src/hooks/useFrameOutput.ts step-for-step (verified against the package
 * source): the returned `attach(frameOutput, onFrame)` uses the worklets
 * provider's createRuntimeForThread(...).setOnFrameCallback and returns the
 * detach routine (setOnFrameCallback(output, undefined) semantics).
 */
function loadVisionCameraApi(): VisionCameraApi | null {
  try {
    /* eslint-disable @typescript-eslint/no-var-requires */
    const visionCamera = require('react-native-vision-camera') as {
      VisionCamera: { createFrameOutput(options: Record<string, unknown>): unknown };
    };
    const vcWorklets = require('react-native-vision-camera-worklets') as {
      provider: {
        createRuntimeForThread(thread: unknown): {
          setOnFrameCallback(frameOutput: unknown, onFrame: unknown | undefined): void;
        };
      };
    };
    const worklets = require('react-native-worklets') as {
      runOnJS: <A extends unknown[]>(fn: (...args: A) => void) => (...args: A) => void;
    };
    /* eslint-enable @typescript-eslint/no-var-requires */
    if (typeof visionCamera?.VisionCamera?.createFrameOutput !== 'function') return null;
    if (typeof vcWorklets?.provider?.createRuntimeForThread !== 'function') return null;
    if (typeof worklets?.runOnJS !== 'function') return null;
    return {
      createFrameOutput: (options) => visionCamera.VisionCamera.createFrameOutput(options),
      runOnJs: (fn) => worklets.runOnJS(fn),
      createRuntimeForThread: (frameOutput, onFrame) => {
        const thread = (frameOutput as { thread: unknown }).thread;
        const threadRuntime = vcWorklets.provider.createRuntimeForThread(thread);
        threadRuntime.setOnFrameCallback(frameOutput, onFrame);
        return () => threadRuntime.setOnFrameCallback(frameOutput, undefined);
      },
    };
  } catch (error) {
    AppLogger.warn(`[ML/Native] frame-output stack unavailable — ${String(error)}`);
    return null;
  }
}

export interface NativePoseFrameOutput {
  /** Attach as an entry of the VisionCamera `<Camera outputs={…}>` array. */
  readonly frameOutput: unknown;
}

interface UseNativePoseFrameOutputArgs {
  /**
   * The admittance gate: mlGateOpen AND a constructed detector handle. The
   * detector is created ONCE per ML session (facing switch does NOT recreate
   * it — per-frame mirror/orientation flags carry every camera switch).
   */
  readonly enabled: boolean;
  readonly detector: NativePoseDetectorHandle | null;
  readonly runtime: PoseFrameRuntime | null;
}

export function useNativePoseFrameOutput({
  enabled,
  detector,
  runtime,
}: UseNativePoseFrameOutputArgs): NativePoseFrameOutput | null {
  const api = useMemo(loadVisionCameraApi, [enabled]);
  const [frameOutput, setFrameOutput] = useState<unknown | null>(null);
  const runtimeRef = useRef(runtime);
  runtimeRef.current = runtime;

  /* Bridges are STABLE across props: they read the live runtime ref, so the
     worklet closure never needs rebuilding for runtime swaps. */
  const bridgeResult = useMemo(() => {
    if (api === null) return null;
    return api.runOnJs((frame: NativePoseFrame) => {
      const current = runtimeRef.current;
      current?.receiveNativeResult(frame, current.currentEpoch);
    });
  }, [api]);
  const bridgeError = useMemo(() => {
    if (api === null) return null;
    return api.runOnJs((message: string) => runtimeRef.current?.receiveNativeError(message));
  }, [api]);
  const bridgeDropped = useMemo(() => {
    if (api === null) return null;
    return api.runOnJs(() => runtimeRef.current?.receivePipelineDrop());
  }, [api]);

  useEffect(() => {
    if (!enabled || api === null || detector === null || bridgeResult === null || bridgeError === null || bridgeDropped === null) {
      setFrameOutput(null);
      return undefined;
    }
    let detach: (() => void) | null = null;
    let output: unknown | null = null;
    try {
      /* 640×480 yuv: the documented ML configuration — preview-sized buffers,
         YUV = ML Kit's native input (no RGB conversion), and drop old frames
         while the processor is busy instead of ever queueing them. */
      output = api.createFrameOutput({
        targetResolution: { width: 640, height: 480 },
        pixelFormat: 'yuv',
        dropFramesWhileBusy: true,
        enablePreviewSizedOutputBuffers: true,
        allowDeferredStart: true,
        /* Explicit false defaults (mirrors useFrameOutput's own option list in
           react-native-vision-camera@5.2.3): no physical buffer rotation (ML
           Kit receives frame.orientation as rotationDegrees instead) and no
           intrinsic-matrix delivery (unused). */
        enablePhysicalBufferRotation: false,
        enableCameraMatrixDelivery: false,
      });
      (output as { setOnFrameDroppedCallback(cb: unknown): void }).setOnFrameDroppedCallback(
        () => bridgeDropped(),
      );
      const detect = detector.detect.bind(detector);
      const onFrame = (frame: { dispose(): void }) => {
        'worklet';
        try {
          const result = detect(frame) as NativePoseFrame;
          bridgeResult(result);
        } catch (error) {
          bridgeError(String(error));
        } finally {
          frame.dispose();
        }
      };
      detach = api.createRuntimeForThread(output, onFrame);
      setFrameOutput(output);
      AppLogger.info('[ML/Native] frame output attached (yuv 640×480, drop-while-busy)');
    } catch (error) {
      AppLogger.error(`[ML/Native] frame output creation failed — ${String(error)}`);
      setFrameOutput(null);
    }
    return () => {
      try {
        detach?.();
      } catch (error) {
        AppLogger.warn(`[ML/Native] frame-output detach raised — ${String(error)}`);
      }
      setFrameOutput(null);
    };
  }, [enabled, api, detector, bridgeResult, bridgeError, bridgeDropped]);

  return useMemo(
    () => (frameOutput === null ? null : { frameOutput }),
    [frameOutput],
  );
}
