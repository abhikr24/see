/**
 * Unit 06 - the single Supabase client boundary.
 *
 * Missing credentials enable the feature-scoped demo backend in development
 * only. Production fails closed. Supplying both values in .env creates one
 * persisted real client; feature code never creates additional clients and
 * never receives a service-role key.
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { AppState, Platform } from 'react-native';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.trim() ?? '';
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY?.trim() ?? '';
const validUrl = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url);
const validAnonKey = anonKey.length > 20 && !anonKey.includes('your-');

/**
 * Demo fallback is development-only. A production binary without backend
 * credentials fails closed instead of presenting mock authentication or data
 * to paying users as real functionality.
 */
export const isBackendConfigured = validUrl && validAnonKey;
export const isDemoMode = !isBackendConfigured && __DEV__;

/**
 * The single validated project URL. The secure deletion endpoint and every
 * future privileged boundary DERIVES its address from this value, so a new
 * deployment never requires second URL constant (configuration stays
 * localized to this file + .env). Empty when unconfigured.
 */
export const supabaseProjectUrl: string | null = isBackendConfigured ? url : null;

if ((validUrl && !validAnonKey) || (!validUrl && validAnonKey)) {
  if (isDemoMode) {
    AppLogger.warn(
      '[Supabase] incomplete credentials - development auth and metadata remain in demo mode',
    );
  } else {
    AppLogger.error(
      '[Supabase] incomplete production credentials - backend features are disabled',
    );
  }
}

const authStorage = {
  getItem: (key: string): string | null => storage.getString(key) ?? null,
  setItem: (key: string, value: string): void => storage.set(key, value),
  removeItem: (key: string): void => storage.delete(key),
};

export const supabase: SupabaseClient | null = !isBackendConfigured
  ? null
  : createClient(url, anonKey, {
      auth: {
        storage: authStorage,
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: false,
        flowType: 'pkce',
      },
    });

// Supabase's React Native guidance: refresh only while the app is active.
if (supabase !== null && Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}

export function requireSupabase(): SupabaseClient {
  if (supabase === null) {
    throw new Error('Supabase is not configured. Add both public values to .env.');
  }
  return supabase;
}

if (isDemoMode) {
  AppLogger.warn(
    '[Supabase] credentials not configured - demo auth and local-only metadata are active',
  );
} else if (!isBackendConfigured) {
  AppLogger.error(
    '[Supabase] production configuration missing - backend features are disabled, never mocked',
  );
}
