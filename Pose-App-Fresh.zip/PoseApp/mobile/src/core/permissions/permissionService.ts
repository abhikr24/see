/**
 * Unit 04 — permissionService.
 * Camera (react-native-vision-camera, since A1) + Media Library
 * (expo-media-library) permission primitives. Platform contract:
 *  · Native → real system dialogs/status
 *  · Web    → auto-granted (spec: "auto-grant on web, show Granted badge")
 *  · Unsupported host (Expo Go) → 'denied' + one log line; never a crash.
 * Notifications are NEVER requested (product rule).
 */
import { Linking, Platform } from 'react-native';
import Constants from 'expo-constants';
import {
  checkCameraPermission,
  requestCameraPermission,
} from '@/core/camera/visionCameraPermission';
import { AppLogger } from '@/core/utils/logger';
import type { PermissionKind, PermissionStatus } from '@shared/index';

export type { PermissionKind, PermissionStatus };


async function loadMediaLibrary(): Promise<typeof import('expo-media-library')> {
  return import('expo-media-library');
}

function normalize(status: string, canAskAgain: boolean): PermissionStatus {
  if (status === 'granted') return 'granted';
  if (!canAskAgain) return 'deniedForever';
  return 'denied';
}

export async function checkCamera(): Promise<PermissionStatus> {
  if (Platform.OS === 'web') return 'granted';
  return checkCameraPermission();
}

export async function requestCamera(): Promise<PermissionStatus> {
  if (Platform.OS === 'web') return 'granted';
  return requestCameraPermission();
}

export async function checkPhotos(): Promise<PermissionStatus> {
  if (Platform.OS === 'web') return 'granted';
  if (Constants.appOwnership === 'expo') {
    AppLogger.info('[Permissions] Expo Go host detected — media permission unavailable');
    return 'denied';
  }
  try {
    const MediaLibrary = await loadMediaLibrary();
    const res = await MediaLibrary.getPermissionsAsync(false, ['photo']);
    return normalize(res.status, res.canAskAgain);
  } catch (error) {
    AppLogger.warn(`[Permissions] photos status check failed — ${String(error)}`);
    return 'denied';
  }
}

export async function requestPhotos(): Promise<PermissionStatus> {
  if (Platform.OS === 'web') return 'granted';
  if (Constants.appOwnership === 'expo') {
    AppLogger.info('[Permissions] Expo Go host cannot grant full PoseAssist media access');
    return 'denied';
  }
  AppLogger.info('[Permissions] requesting photos');
  try {
    // Request exactly the permission declared by the config plugin.
    const MediaLibrary = await loadMediaLibrary();
    const res = await MediaLibrary.requestPermissionsAsync(false, ['photo']);
    const status = normalize(res.status, res.canAskAgain);
    AppLogger.info(`[Permissions] photos → ${status}`);
    return status;
  } catch (error) {
    AppLogger.warn(`[Permissions] photos request failed — ${String(error)}`);
    return 'denied';
  }
}

export async function check(kind: PermissionKind): Promise<PermissionStatus> {
  return kind === 'camera' ? checkCamera() : checkPhotos();
}

export async function request(kind: PermissionKind): Promise<PermissionStatus> {
  return kind === 'camera' ? requestCamera() : requestPhotos();
}

/** Recovery path for deniedForever — opens the OS settings for this app. */
export async function openSystemSettings(): Promise<void> {
  AppLogger.info('[Permissions] opening system settings');
  try {
    await Linking.openSettings();
  } catch (error) {
    AppLogger.error(`[Permissions] openSettings failed — ${String(error)}`);
  }
}
