/**
 * mobile/src/core/reference/referenceProvider.ts — app-facing reference
 * gateway (Unit 28, Part 1 facade).
 *
 * The architecture lives in shared/reference (platform-neutral brain):
 * providers → raw payload → parse/validate/normalize → ReferencePoseTemplate
 * → session pin → engine projection. This module is the app-side import
 * contract for that pipeline, mirroring how core/ml/poseMatchCalculator.ts
 * fronts shared/ml. Feature screens must never import shared internals
 * directly — they import from here.
 *
 * ONE provider instance per app process: the provider is stateless about
 * poses and stateful only about its source description, so a module-level
 * singleton keeps identity stable across camera sessions. Future remote
 * providers (Supabase/API/local files) MUST be constructed behind factories
 * here, never inline inside screens.
 */
import {
  createCatalogReferenceProvider,
  type ReferenceFidelityPolicy,
  type ReferenceProvider,
} from '@shared/index';

export {
  /* statuses + guards */
  ReferenceStatuses,
  isReadyResolution,
  isReadyStatus,
  isReferenceFailure,
  resolutionFailure,
  /* templates + projection */
  templateMeasurementMap,
  referenceIdentityOf,
  referenceContentHash,
  /* session pin */
  pinReferenceForSession,
  compareWithPin,
  assertPinnedResolution,
  /* versions */
  REFERENCE_TEMPLATE_SCHEMA_VERSION,
  MEASUREMENT_VERSION,
  SUPPORTED_SCHEMA_VERSIONS,
  SUPPORTED_MEASUREMENT_VERSIONS,
  isSupportedSchemaVersion,
  isSupportedMeasurementVersion,
  referenceVersionStamp,
  /* measurements */
  MEASUREMENT_DEFINITIONS,
  MIN_MEASUREMENTS_FOR_COMPARISON,
  getMeasurementDefinition,
  knownMeasurementIds,
  /* failure factories */
  approximateOnly,
  invalidReference,
  referenceUnavailable,
  incompleteReference,
  incompatibleReference,
  referenceParseError,
  providerFailure,
  referenceTimeout,
  referenceNetworkFailure,
  referenceUnauthorized,
  staleReferenceData,
  /* fidelity — how real the numbers are, and what the caller accepts */
  fidelityForProvenance,
  fidelitySatisfiesPolicy,
  fidelityDisclosureKey,
  /* provider factories + the declared provider boundary */
  createCatalogReferenceProvider,
  createMemoryReferenceProvider,
  createUnavailableReferenceProvider,
  createRemoteReferenceProvider,
  createReferenceProviderForKind,
  describeProviderKind,
  PROVIDER_KIND_DESCRIPTIONS,
  CATALOG_REFERENCE_PROVIDER_ID,
  /* adapters (source → raw payload) */
  createRecordAdapter,
  poseReferenceAdapter,
  /* reference-IMAGE pipeline — build-once, never per frame */
  buildTemplateFromReferenceImage,
  createReferenceImageTemplateCache,
  extractMeasurementsFromLandmarks,
  validateReferenceLandmarks,
  /* Unit 29 — the ONE seam to the analysis engine (bound once per session,
     never inside the frame loop) */
  analysisInputFromPin,
  analysisInputFromTemplate,
  bindTemplateForAnalysis,
  analysisSemanticsAgree,
  /* explicit measurement access (present vs absent, never a default) */
  readMeasurement,
  templateHasAll,
  /* pipeline escape hatches for future adapters */
  parseReferencePayload,
  validateReferencePayload,
  normalizeReferencePayload,
  buildReferenceTemplate,
  /* types */
  type ReferenceFailure,
  type ReferenceFailureKind,
  type ReferenceMeasurementAvailability,
  type ReferenceMeasurementValue,
  type ReferencePoseTemplate,
  type ReferenceProvenance,
  type ReferenceProvider,
  type ReferenceProviderKind,
  type ReferenceFidelity,
  type ReferenceFidelityPolicy,
  type ReferenceSourceAdapter,
  type RecordFieldMapping,
  type SourceRecord,
  type RemoteProviderConfig,
  type RemoteFetchResult,
  type NormalizationRecord,
  type MeasurementLookup,
  type ReferenceImageDetection,
  type ReferenceImageTemplateResult,
  type ReferenceImageTemplateCache,
  type ReferenceRequest,
  type ReferenceResolution,
  type ReferenceSourceState,
  type ReferenceTemplateMetadata,
  type ReferenceTemplateStatus,
  type ReferenceValidationIssue,
  type RawReferencePayload,
  type PinnedReference,
  type PinnedReferenceIdentity,
  type PinnedResolutionCheck,
  type PinComparison,
  type MeasurementDefinition,
  type MeasurementMapResult,
  type BuildReferenceResult,
  type MemoryProviderSeed,
  type ParseStageResult,
  type ValidateStageResult,
} from '@shared/index';

/**
 * THE ONE PLACE THIS APP DECIDES WHAT COUNTS AS ACCEPTABLE REFERENCE DATA.
 *
 * The bundled catalog holds hand-authored CATEGORY stances — approximate
 * guidance, not measurements of individual poses. That is a product decision
 * with a disclosure obligation, so it is stated here, once, in the open,
 * rather than hidden in a library default:
 *
 *   'allow-approximate' · ship approximate guidance, clearly labelled. Every
 *                         resolved template carries
 *                         `metadata.fidelity === 'category-approximate'`, and
 *                         UI that coaches from it must disclose that the
 *                         target is a category stance.
 *   'measured-only'     · flip this the day measured reference scans land and
 *                         the app should refuse anything weaker. Resolution
 *                         then returns the explicit `approximate-only`
 *                         failure and coaching stays idle — there is NO
 *                         substitute source, demo pose or fixture behind it.
 *
 * What must never happen: an unavailable reference silently becoming
 * plausible angles. Both settings keep that impossible.
 */
export const REFERENCE_FIDELITY_POLICY: ReferenceFidelityPolicy = 'allow-approximate';

/**
 * The production reference provider: bundled 400-pose catalog adapted into
 * versioned templates. Source state is always 'source-available' (bundled);
 * per-pose resolution may still be 'unavailable'/'incomplete' — consumers
 * must switch on the resolution status, not assume.
 */
export const referenceProvider: ReferenceProvider = createCatalogReferenceProvider({
  fidelityPolicy: REFERENCE_FIDELITY_POLICY,
});
