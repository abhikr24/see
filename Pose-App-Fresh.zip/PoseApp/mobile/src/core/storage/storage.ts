/**
 * Unit 01 — storage core.
 *
 * The storage facade is deliberately lazy: importing this module MUST NOT
 * instantiate a Nitro/JSI storage object. The real MMKV instance is created
 * only when a storage operation is actually requested. This keeps cold-start
 * route rendering independent from the native storage bridge.
 *
 * MMKV V4 is the production native backend. Expo Go/web use an in-memory
 * adapter because the standalone native module is not available there.
 */
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import { AppLogger } from '@/core/utils/logger';
import type { MMKV } from 'react-native-mmkv';

export interface StorageAdapter {
  getString(key: string): string | undefined;
  set(key: string, value: string | number | boolean): void;
  delete(key: string): void;
  contains(key: string): boolean;
  clearAll(): void;
}

/** In-memory adapter used by Expo Go/web and as a safe native fallback. */
class MemoryStorage implements StorageAdapter {
  private readonly map = new Map<string, string>();

  getString(key: string): string | undefined {
    return this.map.get(key);
  }
  set(key: string, value: string | number | boolean): void {
    this.map.set(key, String(value));
  }
  delete(key: string): void {
    this.map.delete(key);
  }
  contains(key: string): boolean {
    return this.map.has(key);
  }
  clearAll(): void {
    this.map.clear();
  }
}

let activeStorage: StorageAdapter | null = null;

function runningInExpoGo(): boolean {
  return Constants.appOwnership === 'expo';
}

function wrapMMKV(mmkv: MMKV): StorageAdapter {
  return {
    getString: (key) => mmkv.getString(key),
    set: (key, value) => mmkv.set(key, value),
    delete: (key) => {
      mmkv.remove(key);
    },
    contains: (key) => mmkv.contains(key),
    clearAll: () => mmkv.clearAll(),
  };
}

function getActiveStorage(): StorageAdapter {
  if (activeStorage !== null) return activeStorage;

  if (Platform.OS === 'web' || runningInExpoGo()) {
    activeStorage = new MemoryStorage();
    return activeStorage;
  }

  try {
    // Runtime-only load: the native Nitro/JSI storage package is not evaluated
    // while the first route is merely being imported/rendered.
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { createMMKV } = require('react-native-mmkv') as typeof import('react-native-mmkv');
    activeStorage = wrapMMKV(
      createMMKV({
        id: 'spa.storage',
        recoveryStrategy: 'recover-on-error',
      }),
    );
    return activeStorage;
  } catch (error) {
    AppLogger.warn(`[Storage] MMKV unavailable — using in-memory fallback: ${String(error)}`);
    activeStorage = new MemoryStorage();
    return activeStorage;
  }
}

/**
 * Stable facade used by existing synchronous callers. The native instance is
 * lazy behind this facade, so importing `storage` itself is safe during boot.
 */
export const storage: StorageAdapter = {
  getString: (key) => getActiveStorage().getString(key),
  set: (key, value) => getActiveStorage().set(key, value),
  delete: (key) => getActiveStorage().delete(key),
  contains: (key) => getActiveStorage().contains(key),
  clearAll: () => getActiveStorage().clearAll(),
};
