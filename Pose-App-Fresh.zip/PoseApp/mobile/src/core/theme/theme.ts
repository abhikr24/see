/**
 * Unit 01 — useAppTheme().
 * Resolves themeMode (Light / Dark / System, persisted in themeStore) with
 * the OS scheme and returns the resolved token bundle. Every component in
 * the app reads visual values from here or from shared/theme — never
 * from hardcoded hex/px literals (invariant).
 */
import { useColorScheme } from 'react-native';
import { darkColors, lightColors, type ColorScheme, MATCH_COLOR_BANDS, matchColorFor } from '@shared/theme/colors';
import { radius, spacing, typeScale } from '@shared/theme';
import { useThemeStore } from '@/shared/stores/themeStore';

export interface AppTheme {
  readonly colors: ColorScheme;
  readonly isDark: boolean;
  readonly scheme: 'light' | 'dark';
  readonly spacing: typeof spacing;
  readonly radius: typeof radius;
  readonly typeScale: typeof typeScale;
  readonly matchBands: typeof MATCH_COLOR_BANDS;
  readonly matchColorFor: typeof matchColorFor;
}

export function useAppTheme(): AppTheme {
  const mode = useThemeStore((s) => s.themeMode);

  const systemScheme = useColorScheme();
  const scheme: 'light' | 'dark' =
    mode === 'system' ? (systemScheme === 'dark' ? 'dark' : 'light') : mode;
  return {
    colors: scheme === 'dark' ? darkColors : lightColors,
    isDark: scheme === 'dark',
    scheme,
    spacing,
    radius,
    typeScale,
    matchBands: MATCH_COLOR_BANDS,
    matchColorFor,
  };
}
