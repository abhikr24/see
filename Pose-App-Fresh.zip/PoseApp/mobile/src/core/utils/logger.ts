/**
 * Unit 01 — AppLogger singleton.
 * console-backed in __DEV__, silent in production builds. Ring buffer of
 * the last 200 lines kept in memory for the future dev console overlay.
 * Rule: no raw console.log outside this class.
 */
import { LOG_TAG } from '@/core/constants/appConstants';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogLine {
  readonly level: LogLevel;
  readonly message: string;
  readonly at: string;
  readonly stack: string | null;
}

const MAX_LINES = 200;

const PREFIX: Record<LogLevel, string> = {
  debug: '[DEBUG]',
  info: '[INFO]',
  warn: '[WARN]',
  error: '[ERROR]',
};

export class AppLogger {
  private static buffer: LogLine[] = [];

  private static write(level: LogLevel, message: string, error?: unknown): void {
    const stack = error instanceof Error
      ? error.stack ?? `${error.name}: ${error.message}`
      : error === undefined
        ? null
        : String(error);
    AppLogger.buffer.push({ level, message, at: new Date().toISOString(), stack });
    if (AppLogger.buffer.length > MAX_LINES) {
      AppLogger.buffer.splice(0, AppLogger.buffer.length - MAX_LINES);
    }
    if (__DEV__) {
      const line = `${PREFIX[level]} [${LOG_TAG}] ${message}`;
      if (level === 'error') console.error(stack ? `${line}\n${stack}` : line);
      else if (level === 'warn') console.warn(line);
      else console.log(line);
    }
  }

  static debug(message: string): void {
    AppLogger.write('debug', message);
  }
  static info(message: string): void {
    AppLogger.write('info', message);
  }
  static warn(message: string): void {
    AppLogger.write('warn', message);
  }
  static error(message: string, error?: unknown): void {
    AppLogger.write('error', message, error);
  }

  /** Dev console overlay (Unit 22 can render this). */
  static recent(count: number = MAX_LINES): readonly LogLine[] {
    return AppLogger.buffer.slice(-count);
  }
}

AppLogger.info('App Started — logger online');
