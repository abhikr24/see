/**
 * Unit 30 — SPEECH ONLY. This file executes speech; it never decides what is
 * wrong with a pose.
 *
 *   pose analysis → semantic coaching state → language → phrase → THIS FILE
 *
 *   · `speakCoaching(state, language)` is the coaching entry point. It takes
 *     the semantic CoachingState (category · direction · severity ·
 *     confidence · stability) and delegates every judgement upstream:
 *       - WHEN to speak → shared/coaching/speechPlanner (transition-aware,
 *         anti-spam, low-latency; hysteresis stays in the analysis engine)
 *       - WHAT to say   → shared/coaching/phraseSelection (category →
 *         language → severity/intensity → non-repeated variation)
 *   · No angle, landmark, threshold or severity is computed here, and an
 *     unavailable/evaluating state has no path to a correction phrase.
 *
 * Unit 18 - debounced, lifecycle-safe voice guidance via expo-speech.
 * Unit 27 - human-like coaching voice (native OS TTS only, no AI library):
 *
 *   · speakInstruction() speaks from the Unit 27 phrase bank
 *     (shared/constants/poseInstructions.ts): varied Hindi/Hinglish or
 *     English studio cues instead of one fixed English headline per joint.
 *   · Best built-in voice per language: Speech.getAvailableVoicesAsync()
 *     once (cached), then the candidate pool is scored — an exact locale
 *     match first (hi-IN → hi, en-IN → en-US chain), Enhanced/Premium/
 *     neural-quality identifiers preferred, on-device voices preferred over
 *     network voices. A device with no dedicated voice still speaks with the
 *     engine default for that locale.
 *   · Human cadence: rate 0.98 (real-instructor pace), pitch 1.0. Phrase
 *     copy carries the micro-pauses (commas, "…").
 *
 * Unit 34 - Part 4.3, speech timing:
 *
 *   · The old single fixed 3s global debounce
 *     (INTELLIGENT_CAPTURE_TIMING.voiceDebounceMs) is NO LONGER on the
 *     coaching path. It survives only for the legacy text/category APIs.
 *     Coaching cadence is state-aware and lives entirely in
 *     shared/coaching/speechPlanner.
 *   · Overlap policy is INTERRUPT-AND-REPLACE, never queue: at most one
 *     utterance is ever authorized, and the "speech in flight" claim is
 *     taken SYNCHRONOUSLY at decision time so a 15fps burst of frames can
 *     never stack two cues while the native engine is still starting.
 *   · The service still computes no angle, threshold, severity or
 *     stability. It consumes the semantic CoachingState and executes.
 *
 * Unit 35 - Part 4.4, language + voice integration:
 *
 *   · LANGUAGE ROUTING IS CENTRAL. `shared/voice/routing.ts` decides whether
 *     a frame may be voiced and in which language; `speakCore` normalizes
 *     the language ONCE through `resolveInstructionLanguage`, so a stale or
 *     corrupted preference degrades to English speech instead of reaching
 *     the phrase bank with a pool that does not exist. No caller builds
 *     language-specific coaching logic of its own, and the pose mathematics
 *     is identical for every language: one semantic state, two phrase banks.
 *   · VOICE SELECTION IS A PURE DECISION. The locale chain, the quality
 *     ranking and the preference fallback ladder live in
 *     `shared/voice/voiceSelection.ts` and are unit-tested without a device.
 *     This file only asks `Speech.getAvailableVoicesAsync()` what the
 *     runtime really has and passes the answer to the engine. An identifier
 *     is used ONLY if the live catalog reported it; `null` legitimately
 *     means "engine default for this locale". Nothing is hardcoded as
 *     available.
 *   · THE PREFERENCE IS PERSISTED ONCE, in the settings store (MMKV seam),
 *     per language, and mirrored in via `setPreferredVoiceId`. The service
 *     owns no storage.
 *   · VOICE GUIDANCE OFF IS A HARD GATE inside the service
 *     (`setVoiceGuidanceEnabled`): no API here speaks while it is false, an
 *     in-flight cue is stopped, and cadence memory is cleared. The semantic
 *     coaching state is NOT deleted by it — it keeps flowing to the overlay
 *     and every other non-TTS consumer.
 *
 * Speech stays on-device and needs no credentials. stop() clears both the
 * current utterance and the in-flight claim.
 */
import * as Speech from 'expo-speech';
import {
  createCoachingSpeechPlanner,
  getInstruction,
  INTELLIGENT_CAPTURE_TIMING,
  prosodyForIntensity,
  rankVoicesForLanguage,
  resetInstructionMemory,
  resolveInstructionLanguage,
  resolveVoiceSelection,
  selectCoachingPhrase,
  voiceOptionsForLanguage,
  type CoachingSpeechPlanner,
  type CoachingState,
  type DeviceVoice,
  type InstructionLanguage,
  type PhraseIntensity,
  type SpeechPlan,
  type VoiceInstructionCategory,
  type VoiceOption,
  type VoiceSelection,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';

export type SpeechStateListener = (speaking: boolean) => void;

/**
 * Unit 36 (Part 4.5) — the rate/pitch/volume numbers moved to
 * `shared/voice/prosody.ts`. They used to be literals here AND in the
 * preview mirror, which is how two speech backends silently stop sounding
 * alike. This file now reads the one shared table and converts it into
 * expo-speech options; it still decides nothing about intensity.
 */

/**
 * Unit 34 — hard ceiling on how long one utterance may be considered "in
 * flight" without a native onDone/onStopped. Purely a stuck-state guard.
 */
const UTTERANCE_WATCHDOG_MS = 8_000;

/**
 * Unit 35 (Part 4.4) — the locale chain, the quality ranking and the
 * preference fallback rules now live in shared/voice/voiceSelection, so the
 * device engine and the preview mirror decide identically and the logic is
 * unit-testable without a phone. This file only ASKS the device what it has
 * and EXECUTES the answer.
 *
 * Runtime catalog voices carry install/network metadata on-device that the
 * expo-speech typings omit — widened structurally, always optional.
 */
type CatalogVoice = Speech.Voice & {
  readonly networkConnectionRequired?: boolean;
  readonly notInstalled?: boolean;
};

/** Adapts an expo-speech catalog entry to the shared, engine-neutral shape. */
function toDeviceVoice(voice: CatalogVoice): DeviceVoice {
  const mapped: {
    identifier: string;
    name?: string;
    language: string;
    quality?: string;
    notInstalled?: boolean;
    networkConnectionRequired?: boolean;
  } = {
    identifier: voice.identifier,
    language: voice.language,
  };
  if (typeof voice.name === 'string') mapped.name = voice.name;
  if (voice.quality !== undefined) mapped.quality = String(voice.quality);
  if (typeof voice.notInstalled === 'boolean') {
    mapped.notInstalled = voice.notInstalled;
  }
  if (typeof voice.networkConnectionRequired === 'boolean') {
    mapped.networkConnectionRequired = voice.networkConnectionRequired;
  }
  return mapped;
}

export interface SpeakInstructionOptions {
  /**
   * Bypasses the duplicate-text and 3-second-interval gates. Reserved for
   * the capture announcement ("Bas… photo kheench raha hoon") so the shot
   * is always announced even right after a correction.
   */
  readonly force?: boolean;
  /**
   * Unit 30 — phrase tier decided upstream from the engine's severity.
   * The TTS layer never derives it; it only forwards it to the bank.
   */
  readonly intensity?: PhraseIntensity;
}

class TtsService {
  private lastText: string | null = null;
  private lastSpokenAt = Number.NEGATIVE_INFINITY;
  private generation = 0;

  /**
   * Unit 34 (Part 4.3) — SPEECH-IN-FLIGHT, tracked SYNCHRONOUSLY.
   *
   * `onStart` is an asynchronous callback from the native engine; at 15 fps
   * (~66 ms per frame) several coaching frames can be planned before it ever
   * fires. Relying on it alone meant the planner was told "not speaking"
   * while an utterance was in fact about to play, which is exactly how two
   * cues end up overlapping / chopping each other. The generation of the
   * utterance that currently owns the audio is therefore claimed the moment
   * the decision to speak is committed, and released by the callbacks of
   * THAT generation only.
   */
  private activeGeneration: number | null = null;
  private activeSinceMs = Number.NEGATIVE_INFINITY;
  /**
   * Unit 36 (Part 4.5) — NATIVE CONFIRMATION, and what it is actually for.
   *
   * This used to be write-only dead state: five assignments, zero readers.
   * It now has exactly one job — re-basing the stuck-utterance watchdog on
   * the moment the engine really BEGAN speaking. `activeSinceMs` is claimed
   * synchronously at decision time (that is deliberate: the planner must see
   * "busy" on the very next frame, ~66 ms later), but on a cold TTS engine
   * `onStart` can arrive hundreds of milliseconds afterwards, which would
   * make a long cue look overdue. The claim is never *extended* by this: the
   * watchdog is a ceiling, still bounded by UTTERANCE_WATCHDOG_MS.
   */
  private speechStartedAtMs: number | null = null;

  /**
   * Unit 30 — cadence lives in the shared coaching layer, not here. The TTS
   * service owns no timers of its own for coaching: it asks the planner and
   * executes the answer.
   */
  private readonly planner: CoachingSpeechPlanner = createCoachingSpeechPlanner();

  /**
   * Defensive release: if a native engine never delivers onDone/onStopped
   * (observed on some Android TTS packs), the in-flight claim must not mute
   * coaching forever. No cue in the bank is anywhere near this long.
   */
  private isUtteranceActive(nowMs: number): boolean {
    if (this.activeGeneration === null) return false;
    /* Measured from the native start when the engine confirmed one, else
       from the synchronous claim. Both are bounded by the same ceiling. */
    const since = this.speechStartedAtMs ?? this.activeSinceMs;
    if (nowMs - since >= UTTERANCE_WATCHDOG_MS) {
      this.releaseUtterance();
      return false;
    }
    return true;
  }

  /** Drops the in-flight claim and the native-start mark together. */
  private releaseUtterance(): void {
    this.activeGeneration = null;
    this.speechStartedAtMs = null;
  }

  /** Voice catalog promise — resolved once, reused for the app lifetime. */
  private voicesPromise: Promise<readonly DeviceVoice[]> | null = null;
  /**
   * Resolved selection per (language · preference) key. Cleared whenever the
   * preference changes or the catalog is refreshed, so a newly picked voice
   * takes effect on the very next cue instead of next app launch.
   */
  private readonly resolvedVoices = new Map<string, VoiceSelection>();

  /**
   * Unit 35 — the PERSISTED voice preference, per language, pushed in from
   * the settings store (mobile/src/shared/stores/settingsStore). The service
   * owns no storage of its own: preferences live in the one MMKV seam.
   * `null` = automatic.
   */
  private preferredVoiceIds: Partial<Record<InstructionLanguage, string | null>> = {};

  /**
   * Unit 35 — the voice-guidance master switch, mirrored from the persisted
   * `voiceEnabled` preference. This is a HARD gate inside the service: when
   * it is false nothing here speaks, no matter which API is called. The
   * semantic coaching state is untouched by it — it keeps flowing to the
   * overlay, the capture controller and the logs (see
   * shared/voice/routing.ts).
   */
  private voiceGuidanceEnabled = true;

  /** Mirrors the persisted `voiceEnabled` preference into the speech layer. */
  setVoiceGuidanceEnabled(enabled: boolean): void {
    if (this.voiceGuidanceEnabled === enabled) return;
    this.voiceGuidanceEnabled = enabled;
    AppLogger.info(`[Voice] guidance ${enabled ? 'enabled' : 'disabled'}`);
    if (!enabled) {
      /* Silence immediately: a cue already in flight must not outlive the
         switch. Cadence memory is cleared too, so re-enabling starts clean. */
      void this.stop();
      this.planner.reset();
    }
  }

  isVoiceGuidanceEnabled(): boolean {
    return this.voiceGuidanceEnabled;
  }

  /**
   * Mirrors the persisted per-language voice preference. Accepts the stored
   * value as-is (including the 'auto' sentinel); resolution against the real
   * catalog happens in shared/voice/voiceSelection at speak time.
   */
  setPreferredVoiceId(
    rawLanguage: InstructionLanguage,
    voiceId: string | null,
  ): void {
    const language = resolveInstructionLanguage(rawLanguage);
    if ((this.preferredVoiceIds[language] ?? null) === (voiceId ?? null)) return;
    this.preferredVoiceIds = { ...this.preferredVoiceIds, [language]: voiceId };
    this.resolvedVoices.clear();
    AppLogger.info(
      `[Voice] preference ${language} → ${voiceId ?? 'automatic'} (applies to the next cue)`,
    );
  }

  private listVoices(): Promise<readonly DeviceVoice[]> {
    if (this.voicesPromise === null) {
      this.voicesPromise = Speech.getAvailableVoicesAsync()
        .then((voices) =>
          (voices as readonly CatalogVoice[]).map(toDeviceVoice),
        )
        .catch((error) => {
          /* An engine that cannot list its voices is not a crash: the OS
             default still speaks the locale. No voice is invented here. */
          AppLogger.warn(`[Voice] voice catalog unavailable - ${String(error)}`);
          return [] as readonly DeviceVoice[];
        });
    }
    return this.voicesPromise;
  }

  /**
   * The voices the RUNTIME reports for a language, best first — the only
   * source the settings picker is allowed to list. Never synthesized.
   */
  async availableVoices(
    language: InstructionLanguage,
  ): Promise<readonly DeviceVoice[]> {
    return rankVoicesForLanguage(
      await this.listVoices(),
      resolveInstructionLanguage(language),
    );
  }

  /** Picker options ("Automatic" + device-reported voices for `language`). */
  async voiceOptions(
    language: InstructionLanguage,
  ): Promise<readonly VoiceOption[]> {
    return voiceOptionsForLanguage(
      await this.listVoices(),
      resolveInstructionLanguage(language),
    );
  }

  /** Forgets the cached catalog (engine/pack installed while running). */
  refreshVoices(): void {
    this.voicesPromise = null;
    this.resolvedVoices.clear();
  }

  /**
   * Resolves which real voice speaks `language`, honoring the persisted
   * preference when the device still reports it and falling back through the
   * documented steps otherwise (shared/voice/voiceSelection).
   */
  async resolveVoice(rawLanguage: InstructionLanguage): Promise<VoiceSelection> {
    /* Unit 36 — the preference map and the locale chain are both keyed by a
       REAL coaching language; an untrusted value must not create a phantom
       key (a cache entry nothing can ever hit) or index a missing chain. */
    const language = resolveInstructionLanguage(rawLanguage);
    const preferred = this.preferredVoiceIds[language] ?? null;
    const key = `${language}:${preferred ?? 'auto'}`;
    const cached = this.resolvedVoices.get(key);
    if (cached !== undefined) return cached;

    const selection = resolveVoiceSelection({
      voices: await this.listVoices(),
      language,
      preferredVoiceId: preferred,
    });
    this.resolvedVoices.set(key, selection);
    AppLogger.info(
      `[Voice] ${language} → ${selection.voiceId ?? `engine default (${selection.locale})`}` +
        ` · ${selection.source}` +
        `${selection.fallbackReason === null ? '' : ` (${selection.fallbackReason})`}`,
    );
    return selection;
  }

  /**
   * Shared speech core behind the Unit 18 text API, the Unit 27 category API
   * and the Unit 30 coaching API.
   *
   * Two different gating regimes meet here, and they must not be confused:
   *
   *   · LEGACY TEXT/CATEGORY CALLERS (`force === false`) still pass the old
   *     identity gates — duplicate text plus the single fixed
   *     `INTELLIGENT_CAPTURE_TIMING.voiceDebounceMs` (3 s) global debounce.
   *     That one big timer is the reason coaching used to feel broken, so
   *     COACHING NO LONGER USES IT (see `speakCoaching`).
   *   · THE COACHING PATH arrives with `force === true` because the shared
   *     `speechPlanner` has already answered "should I say it now?" with a
   *     state-aware decision. Adding the 3 s gate on top would silently
   *     override that answer.
   *
   * Either way this method executes speech only. It computes no geometry, no
   * severity, no stability and no cadence of its own.
   */
  private async speakCore(
    resolveText: () => string,
    rawLanguage: InstructionLanguage,
    nowMs: number,
    onStateChange: SpeechStateListener | undefined,
    force: boolean,
    intensity: PhraseIntensity = 'gentle',
  ): Promise<boolean> {
    /* Unit 35 — THE hard voice-guidance gate. Every speaking API funnels
       through here, so "voice guidance off" cannot be bypassed by a caller
       that forgot to check the preference. Nothing upstream is discarded:
       the semantic coaching state still exists, it is simply not voiced. */
    if (!this.voiceGuidanceEnabled) return false;
    /* Unit 35 — the language is normalized ONCE, centrally. A corrupted or
       stale preference degrades to English speech instead of reaching the
       bank with a pool that does not exist. */
    const language = resolveInstructionLanguage(rawLanguage);
    const normalized = resolveText().trim();
    if (normalized.length === 0) return false;
    if (!force) {
      if (normalized === this.lastText) return false;
      if (nowMs - this.lastSpokenAt < INTELLIGENT_CAPTURE_TIMING.voiceDebounceMs) {
        return false;
      }
    }

    this.lastText = normalized;
    this.lastSpokenAt = nowMs;
    this.generation += 1;
    const generation = this.generation;
    /* INTERRUPT-AND-REPLACE, claimed synchronously: from this line on the
       planner sees "speaking", so the next frames cannot stack a second
       utterance while the native engine is still starting this one. */
    this.activeGeneration = generation;
    this.activeSinceMs = nowMs;
    this.speechStartedAtMs = null;

    /* Releases the audio claim, but only if THIS utterance still owns it —
       a late onStopped from the line we just replaced must never clear the
       flag belonging to its replacement. */
    const release = () => {
      if (this.activeGeneration === generation) this.releaseUtterance();
    };

    try {
      await Speech.stop();
      if (generation !== this.generation) {
        release();
        return false;
      }
      /* Unit 35 — the persisted preference is resolved against the LIVE
         catalog here; an uninstalled or foreign-language pick degrades to
         the best ranked voice, and finally to the engine default. */
      const voice = await this.resolveVoice(language);
      if (generation !== this.generation) {
        release();
        return false;
      }

      const settle = () => {
        release();
        if (generation === this.generation) onStateChange?.(false);
      };
      /* Unit 30/36: the phrase bank carries the intensity; prosody only adds
         a small, fixed nudge for a firmer cue, from the ONE shared table. No
         severity is computed here — it arrives already decided upstream. */
      const prosody = prosodyForIntensity(intensity);
      const options: Speech.SpeechOptions = {
        language: voice.locale,
        rate: prosody.rate,
        pitch: prosody.pitch,
        volume: prosody.volume,
        onStart: () => {
          /* Native confirmation: re-base the watchdog on the real start. */
          if (this.activeGeneration === generation) {
            this.speechStartedAtMs = Date.now();
          }
          if (generation === this.generation) onStateChange?.(true);
        },
        onDone: settle,
        onStopped: settle,
        onError: (error) => {
          settle();
          AppLogger.warn(`[Voice] guidance unavailable - ${String(error)}`);
        },
      };
      /* Only a catalog-reported identifier is ever passed to the engine.
         `null` means "engine default for this locale" — an honest absence,
         never a fabricated voice id. */
      if (voice.voiceId !== null) {
        options.voice = voice.voiceId;
      }
      Speech.speak(normalized, options);
      AppLogger.info(
        `[Voice] speaking (${language} · ${voice.locale} · ${voice.source}) - ${normalized}`,
      );
      return true;
    } catch (error) {
      release();
      onStateChange?.(false);
      AppLogger.warn(`[Voice] speech start failed - ${String(error)}`);
      return false;
    }
  }

  /**
   * Unit 18 API — speaks caller-supplied text (defaults to the English
   * voice chain). Kept for compatibility; new code should use
   * speakInstruction so cues vary naturally.
   */
  async speakGuidance(
    text: string,
    nowMs: number = Date.now(),
    onStateChange?: SpeechStateListener,
  ): Promise<boolean> {
    const spoke = await this.speakCore(() => text, 'en', nowMs, onStateChange, false);
    if (spoke) this.planner.noteExternalSpeech(nowMs);
    return spoke;
  }

  /**
   * Unit 27 API — speaks a varied, instructor-style cue from the phrase
   * bank for the given correction category, in the chosen voice language.
   * Same category twice in a row never repeats the same line.
   */
  async speakInstruction(
    category: VoiceInstructionCategory,
    rawLanguage: InstructionLanguage,
    nowMs: number = Date.now(),
    onStateChange?: SpeechStateListener,
    options?: SpeakInstructionOptions,
  ): Promise<boolean> {
    if (!this.voiceGuidanceEnabled) return false;
    /* Unit 36 — same rule as the coaching path: resolve BEFORE the bank is
       asked for a pool, so an untrusted preference degrades to English copy
       instead of producing silence. */
    const language = resolveInstructionLanguage(rawLanguage);
    const intensity: PhraseIntensity = options?.intensity ?? 'gentle';
    const spoke = await this.speakCore(
      () => getInstruction(category, language, { intensity }),
      language,
      nowMs,
      onStateChange,
      options?.force === true,
      intensity,
    );
    /* Unit 34: this API is OUTSIDE the coaching decision path (today it is
       the forced capture announcement). Telling the planner keeps the
       cadence honest, so a correction cannot start talking over the shutter
       cue the instant it is issued. No coaching token is claimed — the next
       real coaching state is still a fresh state, it just waits out the gap. */
    if (spoke) this.planner.noteExternalSpeech(nowMs);
    return spoke;
  }

  /**
   * Unit 30 API — THE coaching entry point.
   *
   * Input is the semantic coaching state produced by the analysis layer
   * (`decisionToCoachingState`). This method performs NO geometry, NO
   * severity computation and NO stability analysis: it asks the shared
   * cadence planner whether to speak, asks the shared phrase selector what
   * to say in the chosen language at the state's intensity, and speaks it.
   *
   * Non-speakable states (evaluating / unavailable reference / no body)
   * cannot produce speech here — there is no code path from them to a
   * correction phrase.
   */
  async speakCoaching(
    state: CoachingState,
    rawLanguage: InstructionLanguage,
    nowMs: number = Date.now(),
    onStateChange?: SpeechStateListener,
  ): Promise<boolean> {
    /* Unit 36 — the language is resolved BEFORE phrase selection, not after.
       It used to be normalized only inside speakCore, i.e. one stage too
       late: an untrusted preference reached the phrase bank first, where it
       selects no pool at all (silence) rather than degrading to English.
       One resolution, at the entry of the coaching path. */
    const language = resolveInstructionLanguage(rawLanguage);
    /* Unit 34: the planner is told about the utterance that is ACTUALLY in
       flight (claimed synchronously at decision time), not just about the
       one the native engine has already confirmed via onStart. Otherwise a
       burst of frames could each believe the device was idle. */
    /* Unit 35 — voice guidance off: return BEFORE the planner is consulted,
       so cadence memory is not spent on a line that can never be heard. The
       caller still holds the semantic state for the on-screen coaching. */
    if (!this.voiceGuidanceEnabled) return false;

    const plan: SpeechPlan = this.planner.plan({
      state,
      nowMs,
      isSpeaking: this.isUtteranceActive(nowMs),
    });
    if (!plan.speak) return false;

    const phrase = selectCoachingPhrase(state, language);
    if (phrase === null) {
      /* Unit 34: the planner already COMMITTED this line to its cadence
         memory (the next frame is only ~66 ms away and must see "just
         spoken"). The phrase layer is allowed to answer silence — a retired
         or unknown category is silence by design, never another category's
         text — so the authorization has to be withdrawn, or the planner
         would be muting itself on behalf of a line nobody heard. For
         PERFECT that is user-visible: the single positive response of the
         whole episode would be spent on nothing. */
      this.planner.revert(plan);
      return false;
    }

    /* Unit 33: the log states the full selection chain, so a mis-heard cue
       can be traced back to the semantic state that produced it —
       token → category → language → requested/spoken intensity → pool slot. */
    AppLogger.debug(
      `[Voice] ${plan.reason}${plan.interrupts ? ' (replaces)' : ''} · ` +
        `${state.kind} · ${phrase.token} · ` +
        `${phrase.category} · ${phrase.language} · ` +
        `${phrase.requestedIntensity}→${phrase.intensity}` +
        `${phrase.fallback === 'exact' ? '' : ` (${phrase.fallback})`} · ` +
        `${phrase.poolIndex + 1}/${phrase.poolSize}`,
    );
    /* The planner already owns the cadence decision, so the legacy
       duplicate-text / fixed 3 s interval gate is bypassed here BY DESIGN:
       `force: true` below means "cadence was decided upstream", never
       "speak unconditionally". speakCore stops any line still playing
       first, so plan.interrupts === true is executed as a clean replace,
       never as an overlap. */
    const spoke = await this.speakCore(
      () => phrase.text,
      language,
      nowMs,
      onStateChange,
      true,
      phrase.intensity,
    );
    /* Same contract on the execution side: an utterance that was superseded
       before the native engine started it, or that failed to start at all,
       must not leave the planner believing the user was coached. `revert`
       is identity-checked, so if a LATER frame has already authorized the
       replacement line this is a no-op and the newer line keeps the floor. */
    if (!spoke) this.planner.revert(plan);
    return spoke;
  }

  /**
   * Unit 36 (Part 4.5) — THE OBSERVATION PATH. Speech can never come out of
   * here; this method exists so the cadence planner still SEES the frames
   * that must not be spoken.
   *
   * THE DEFECT THIS REPAIRS
   *   `speakCoaching` is only reached when the routing gate says the frame
   *   is deliverable, which by definition excludes every evaluating /
   *   unavailable / body-lost frame. The planner therefore never observed
   *   them in the real app, and three of its documented behaviours were
   *   silently dead on device while passing their unit tests in isolation:
   *     · a SUSTAINED unjudgeable gap clears cadence memory, so a genuine
   *       re-entry is prompt instead of waiting out a dead interval;
   *     · a PERFECT episode that ended because the subject left the frame
   *       could never be confirmed again for the rest of the session;
   *     · transition detection compared against the last SPEAKABLE token
   *       instead of the last observed one.
   *
   * Feeding the state through `plan()` is exactly how the planner is
   * designed to learn this (gate 1 of `plan` handles non-speakable states
   * and returns 'not-speakable'). Speakable states are rejected here on
   * purpose: they belong to `speakCoaching`, which can actually execute the
   * authorization the planner would commit.
   */
  observeCoaching(state: CoachingState, nowMs: number = Date.now()): void {
    /* A speakable state observed through this path would spend cadence on a
       line nobody hears — the exact failure `revert` exists to prevent. */
    if (state.speakable) return;
    /* With guidance off there is no cadence to keep: the switch already
       cleared the planner, and re-enabling starts from a clean slate. */
    if (!this.voiceGuidanceEnabled) return;
    this.planner.plan({
      state,
      nowMs,
      isSpeaking: this.isUtteranceActive(nowMs),
    });
  }

  /** Pre-warms the voice catalog so the first cue has no discovery delay. */
  warmup(): void {
    void this.listVoices();
  }

  async stop(): Promise<void> {
    this.generation += 1;
    this.releaseUtterance();
    this.activeSinceMs = Number.NEGATIVE_INFINITY;
    try {
      await Speech.stop();
    } catch (error) {
      AppLogger.warn(`[Voice] speech cleanup failed - ${String(error)}`);
    }
  }

  resetSession(): void {
    this.lastText = null;
    this.lastSpokenAt = Number.NEGATIVE_INFINITY;
    this.releaseUtterance();
    this.activeSinceMs = Number.NEGATIVE_INFINITY;
    this.planner.reset();
    resetInstructionMemory();
  }
}

export const ttsService = new TtsService();
