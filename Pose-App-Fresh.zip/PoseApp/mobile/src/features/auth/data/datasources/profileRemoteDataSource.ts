/** Unit 06 profile metadata gateway. Photos never touch this table. */
import { isDemoMode, requireSupabase } from '@/core/network/supabaseClient';

export interface ProfileRow {
  readonly id: string;
  readonly email: string;
  readonly display_name: string | null;
  readonly avatar_url: string | null;
  readonly created_at: string;
  readonly updated_at: string;
}

export async function getProfile(userId: string): Promise<ProfileRow | null> {
  if (isDemoMode) return null;
  const { data, error } = await requireSupabase()
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw error;
  return data as ProfileRow | null;
}

export async function upsertProfile(input: {
  readonly id: string;
  readonly email: string;
  readonly displayName: string | null;
  readonly avatarUrl: string | null;
}): Promise<void> {
  if (isDemoMode) return;
  const { error } = await requireSupabase().from('profiles').upsert({
    id: input.id,
    email: input.email,
    display_name: input.displayName,
    avatar_url: input.avatarUrl,
    updated_at: new Date().toISOString(),
  });
  if (error) throw error;
}
