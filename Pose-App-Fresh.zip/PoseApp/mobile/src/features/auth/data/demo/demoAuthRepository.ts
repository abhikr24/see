/** Demo auth only. The same repository contract is used by real Supabase. */
import { STORAGE_KEYS } from '@shared/index';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';
import type { AuthProvider, AuthUser } from '../../domain/entities/authUser';

function stableId(value: string): string {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = (Math.imul(hash, 31) + value.charCodeAt(index)) | 0;
  }
  return `demo-${(hash >>> 0).toString(36)}`;
}

function createUser(email: string, provider: AuthProvider, name?: string): AuthUser {
  return {
    id: stableId(email),
    email,
    displayName: name?.trim() || email.split('@')[0] || 'Demo User',
    avatarUrl: null,
    provider,
  };
}

export const demoAuthRepository = {
  restoreSession(): AuthUser | null {
    const raw = storage.getString(STORAGE_KEYS.demoAuthSession);
    if (raw === undefined) return null;
    try {
      return JSON.parse(raw) as AuthUser;
    } catch (error) {
      AppLogger.error(`[DemoAuth] corrupt session removed - ${String(error)}`);
      storage.delete(STORAGE_KEYS.demoAuthSession);
      return null;
    }
  },
  signIn(email: string, displayName?: string): AuthUser {
    const user = createUser(email, 'email', displayName);
    storage.set(STORAGE_KEYS.demoAuthSession, JSON.stringify(user));
    return user;
  },
  /**
   * Demo sign-up mirrors the real product from the user's perspective: a
   * valid email + 8-character password creates the account and signs in
   * immediately (the demo backend never requires email confirmation).
   */
  signUp(email: string, displayName?: string): AuthUser {
    const user = createUser(email, 'email', displayName);
    storage.set(STORAGE_KEYS.demoAuthSession, JSON.stringify(user));
    AppLogger.info(`[DemoAuth] demo account created for ${email}`);
    return user;
  },
  signInWithGoogle(): AuthUser {
    const user = createUser('demo.user@gmail.com', 'google', 'Demo User');
    storage.set(STORAGE_KEYS.demoAuthSession, JSON.stringify(user));
    return user;
  },
  updateDisplayName(displayName: string): AuthUser | null {
    const current = this.restoreSession();
    if (!current) return null;
    const updated: AuthUser = { ...current, displayName: displayName.trim() };
    storage.set(STORAGE_KEYS.demoAuthSession, JSON.stringify(updated));
    return updated;
  },
  signOut(): void {
    storage.delete(STORAGE_KEYS.demoAuthSession);
  },
  /**
   * DEMO deletion (development-only): the demo backend has no server, so
   * "deleting the demo account" is exactly dropping the persisted demo
   * session. Account-scoped local cleanup (favorites replica, gallery) is
   * orchestrated by the auth store identically to production. This path is
   * unreachable when the real backend is configured — it is never a
   * production fallback.
   */
  deleteDemoAccount(): void {
    storage.delete(STORAGE_KEYS.demoAuthSession);
    AppLogger.info('[DemoAuth] demo account deleted (local demo session removed)');
  },
};
