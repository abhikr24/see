/** Unit 06 auth repository + Unit 39 lifecycle (deletion/recovery). One
 * caller contract for real and demo — the ONLY place Supabase calls live. */
import * as Linking from 'expo-linking';
import {
  DELETE_ACCOUNT_TIMEOUT_MS,
  classifyAuthDeepLink,
  classifyDeletionHttpResponse,
  classifyDeletionTransportError,
  type DeletionServerOutcome,
} from '@shared/index';
import {
  isBackendConfigured,
  isDemoMode,
  requireSupabase,
  supabase,
  supabaseProjectUrl,
} from '@/core/network/supabaseClient';
import { oauthRedirectUrl, passwordResetRedirectUrl } from '@/core/auth/authLinks';
import { AppLogger } from '@/core/utils/logger';
import {
  AuthFailure,
  mapSupabaseAuthUser,
  toAuthFailure,
  type AuthUser,
} from '../../domain/entities/authUser';
import { demoAuthRepository } from '../demo/demoAuthRepository';

/** Async auth-surface events the store must react to beyond "user changed". */
export type AuthLifecycleEvent = 'password-recovery';

export interface AuthRepository {
  restoreSession(): Promise<AuthUser | null>;
  signInWithEmail(email: string, password: string, displayName?: string): Promise<AuthUser>;
  signUpWithEmail(email: string, password: string, displayName?: string): Promise<AuthUser>;
  resendSignupConfirmation(email: string): Promise<void>;
  signInWithGoogle(): Promise<AuthUser | null>;
  updateDisplayName(displayName: string): Promise<AuthUser>;
  /**
   * B2 step 1 — ask the backend to email a recovery link. Neutral by
   * contract: succeeds identically for known, unknown and deleted emails.
   */
  requestPasswordReset(email: string): Promise<void>;
  /**
   * B2 step 2 — set the new password inside an active recovery session.
   * Throws 'session-required' when no live session exists.
   */
  completePasswordReset(newPassword: string): Promise<AuthUser>;
  /**
   * B1 — delete the authenticated account through the SECURE SERVER-SIDE
   * boundary (Edge Function holding the service role). The client sends its
   * own user token only; privileged keys never exist in the app. Resolves
   * ONLY when the server explicitly confirmed deletion — never before.
   */
  deleteAccount(): Promise<void>;
  signOut(): Promise<void>;
  onAuthChange(
    handler: (user: AuthUser | null, lifecycleEvent: AuthLifecycleEvent | null) => void,
  ): () => void;
}

class DefaultAuthRepository implements AuthRepository {
  async restoreSession(): Promise<AuthUser | null> {
    if (isDemoMode) return demoAuthRepository.restoreSession();
    if (!isBackendConfigured) return null;
    try {
      const { data, error } = await requireSupabase().auth.getSession();
      if (error) throw error;
      return data.session?.user ? mapSupabaseAuthUser(data.session.user) : null;
    } catch (error) {
      AppLogger.error(`[Auth] session restore failed - ${String(error)}`);
      return null;
    }
  }

  async signInWithEmail(
    email: string,
    password: string,
    displayName?: string,
  ): Promise<AuthUser> {
    if (isDemoMode) return demoAuthRepository.signIn(email, displayName);
    if (!isBackendConfigured) {
      throw new AuthFailure(
        'not-configured',
        'The production backend is not configured. Add the Supabase public values and rebuild.',
      );
    }
    try {
      const { data, error } = await requireSupabase().auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      if (!data.user) throw new AuthFailure('unknown', 'Sign-in returned no user.');
      return mapSupabaseAuthUser(data.user);
    } catch (error) {
      throw toAuthFailure(error);
    }
  }

  async signUpWithEmail(
    email: string,
    password: string,
    displayName?: string,
  ): Promise<AuthUser> {
    if (isDemoMode) return demoAuthRepository.signUp(email, displayName);
    if (!isBackendConfigured) {
      throw new AuthFailure(
        'not-configured',
        'The production backend is not configured. Add the Supabase public values and rebuild.',
      );
    }
    try {
      const { data, error } = await requireSupabase().auth.signUp({
        email,
        password,
        options: displayName ? { data: { display_name: displayName.trim() } } : undefined,
      });
      if (error) throw error;
      if (!data.user) throw new AuthFailure('unknown', 'Sign-up returned no user.');
      if (!data.session) {
        // Real Supabase behaviour: the user EXISTS but email confirmation is
        // required, so no session is returned. This is success-with-a-next-
        // step, not a failure — shared/authFlow classifies it as
        // 'confirmation-required' and the screen shows a dedicated state.
        throw new AuthFailure(
          'email-not-confirmed',
          'Account created. Check your email, then return here to sign in.',
        );
      }
      return mapSupabaseAuthUser(data.user);
    } catch (error) {
      throw toAuthFailure(error);
    }
  }

  async resendSignupConfirmation(email: string): Promise<void> {
    if (isDemoMode) {
      // The demo backend never gates on confirmation; resending is a no-op
      // that keeps the same contract for callers.
      return;
    }
    if (!isBackendConfigured) {
      throw new AuthFailure(
        'not-configured',
        'The production backend is not configured. Add the Supabase public values and rebuild.',
      );
    }
    try {
      const { error } = await requireSupabase().auth.resend({ type: 'signup', email });
      if (error) throw error;
    } catch (error) {
      throw toAuthFailure(error);
    }
  }

  async signInWithGoogle(): Promise<AuthUser | null> {
    if (isDemoMode) return demoAuthRepository.signInWithGoogle();
    if (!isBackendConfigured) {
      throw new AuthFailure(
        'not-configured',
        'The production backend is not configured. Add the Supabase public values and rebuild.',
      );
    }
    const googleClientId = process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID?.trim();
    if (!googleClientId || googleClientId.length < 20) {
      throw new AuthFailure(
        'not-configured',
        'Google sign-in is not configured. Add EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID to .env.',
      );
    }
    // Return to the existing /auth route; the root listener exchanges PKCE.
    // (Centralized in core/auth/authLinks.ts with the recovery redirect.)
    const redirectTo = oauthRedirectUrl();
    const { data, error } = await requireSupabase().auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo, skipBrowserRedirect: true },
    });
    if (error) throw toAuthFailure(error);
    if (!data.url) throw new AuthFailure('unknown', 'Google returned no authorization URL.');
    await Linking.openURL(data.url);
    return null;
  }

  async updateDisplayName(displayName: string): Promise<AuthUser> {
    const trimmed = displayName.trim();
    if (isDemoMode) {
      const updated = demoAuthRepository.updateDisplayName(trimmed);
      if (!updated) throw new AuthFailure('unknown', 'No active session to update.');
      return updated;
    }
    const client = requireSupabase();
    const { data, error } = await client.auth.updateUser({
      data: { display_name: trimmed },
    });
    if (error) throw toAuthFailure(error);
    if (!data.user) throw new AuthFailure('unknown', 'Update returned no user.');
    return mapSupabaseAuthUser(data.user);
  }

  async signOut(): Promise<void> {
    if (isDemoMode) {
      demoAuthRepository.signOut();
      return;
    }
    const { error } = await requireSupabase().auth.signOut();
    if (error) throw toAuthFailure(error);
  }

  /* ── B2 · PASSWORD RECOVERY ─────────────────────────────────────────── */

  /**
   * resetPasswordForEmail() is deliberately account-existence neutral on
   * Supabase (unknown emails return success), which matches the shared
   * neutrality policy — the UI's acknowledgement copy never leaks whether
   * an address is registered, deleted, or imaginary.
   */
  async requestPasswordReset(email: string): Promise<void> {
    if (isDemoMode) {
      // Demo honesty: no email exists to send. The UI labels this with
      // PASSWORD_RESET_COPY.requestDemoNote; nothing is simulated as sent.
      AppLogger.info('[Auth] demo recovery request recorded (no email exists in demo mode)');
      return;
    }
    if (!isBackendConfigured) {
      throw new AuthFailure(
        'not-configured',
        'The production backend is not configured. Add the Supabase public values and rebuild.',
      );
    }
    try {
      const { error } = await requireSupabase().auth.resetPasswordForEmail(email, {
        redirectTo: passwordResetRedirectUrl(),
      });
      if (error) throw error;
    } catch (error) {
      throw toAuthFailure(error);
    }
  }

  /**
   * Works ONLY inside a live session — for recovery, the PASSWORD_RECOVERY
   * session Supabase establishes after the link's code exchange. Never log
   * the password; client-side length policy already matched the shared rule
   * and any server-side policy error is surfaced verbatim.
   */
  async completePasswordReset(newPassword: string): Promise<AuthUser> {
    if (isDemoMode) {
      // Demo walkthrough of the real form: the demo backend stores no
      // password, so "updating" simply confirms the active demo session —
      // the screen marks this as a preview (PASSWORD_RESET_COPY.newDemoNote).
      const current = demoAuthRepository.restoreSession();
      if (!current) throw new AuthFailure('session-required', 'No active session to update.');
      AppLogger.info('[Auth] demo recovery flow completed (no password exists in demo mode)');
      return current;
    }
    const client = requireSupabase();
    const { data: sessionData } = await client.auth.getSession();
    if (!sessionData.session) {
      throw new AuthFailure(
        'session-required',
        'This recovery link is no longer active. Send yourself a new link.',
      );
    }
    try {
      const { data, error } = await client.auth.updateUser({ password: newPassword });
      if (error) throw error;
      if (!data.user) throw new AuthFailure('unknown', 'Password update returned no user.');
      return mapSupabaseAuthUser(data.user);
    } catch (error) {
      throw toAuthFailure(error);
    }
  }

  /* ── B1 · ACCOUNT DELETION — secure boundary client ─────────────────── */

  /**
   * The mobile half of the deletion sequence:
   *   app → authenticated request → Edge Function (service-role, server-side
   *   only) → Supabase admin delete → profiles/favorites cascade → ack.
   * The ONLY credential the app sends is the user's own session token.
   * Resolution happens exclusively on an explicit `deleted: true` ack —
   * the exhaustive shared classifier turns everything else into a typed
   * failure so success can never be claimed early or falsely.
   */
  async deleteAccount(): Promise<void> {
    if (isDemoMode) {
      demoAuthRepository.deleteDemoAccount();
      return;
    }
    if (!isBackendConfigured || supabaseProjectUrl === null) {
      throw new AuthFailure(
        'not-configured',
        'The production backend is not configured. Add the Supabase public values and rebuild.',
      );
    }
    const client = requireSupabase();
    const { data: sessionData } = await client.auth.getSession();
    const accessToken = sessionData.session?.access_token;
    if (typeof accessToken !== 'string' || accessToken.length === 0) {
      throw new AuthFailure(
        'session-required',
        'Your session has expired. Sign in again, then retry deletion.',
      );
    }
    const endpoint = `${supabaseProjectUrl}/functions/v1/delete-account`;
    const outcome = await this.postDeletionRequest(endpoint, accessToken);
    if (outcome.kind !== 'deleted') {
      AppLogger.warn(`[Auth] account deletion refused — ${outcome.kind}`);
      throw this.deletionFailure(outcome);
    }
    // Identity is gone server-side. Purge the now-dead local session token
    // best-effort; failure to scrub a dead token is not a deletion failure.
    await client.auth.signOut({ scope: 'local' }).catch((error: unknown) => {
      AppLogger.warn(`[Auth] post-deletion local token scrub deferred - ${String(error)}`);
    });
    AppLogger.info('[Auth] account deletion confirmed by the secure boundary');
  }

  /** Bounded, explicitly-classified POST to the deletion boundary. */
  private async postDeletionRequest(
    endpoint: string,
    accessToken: string,
  ): Promise<DeletionServerOutcome> {
    const controller = new AbortController();
    const timer = setTimeout(() => {
      controller.abort();
    }, DELETE_ACCOUNT_TIMEOUT_MS);
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
        signal: controller.signal,
      });
      const bodyText = await response.text().catch(() => null);
      // Unexpected server answers (non-JSON, acknowledged shape wrong) are
      // classified, never trusted — success requires the explicit ack.
      return classifyDeletionHttpResponse(response.status, bodyText);
    } catch (error) {
      return classifyDeletionTransportError(error);
    } finally {
      clearTimeout(timer);
    }
  }

  /** Exhaustive outcome → failure-code mapping (never success-flavored). */
  private deletionFailure(outcome: DeletionServerOutcome): AuthFailure {
    switch (outcome.kind) {
      case 'unauthorized':
        return new AuthFailure(
          'session-required',
          'Your session could not be verified. Sign in again, then retry deletion.',
        );
      case 'rejected':
        return new AuthFailure('unknown', outcome.detail);
      case 'backend-failure':
        return new AuthFailure(
          'server-unavailable',
          'The deletion service could not complete the request. Nothing was deleted — try again shortly.',
        );
      case 'network':
        return new AuthFailure(
          'network',
          'No connection to the deletion service. Check your network — nothing was deleted.',
        );
      case 'timeout':
        return new AuthFailure(
          'timeout',
          'The deletion service took too long to answer. Nothing was confirmed — check your connection and retry.',
        );
      default:
        return new AuthFailure(
          'unknown',
          'The server answered, but did not confirm deletion. Nothing was treated as deleted.',
        );
    }
  }

  /* ── Session + deep-link plumbing ───────────────────────────────────── */

  onAuthChange(
    handler: (user: AuthUser | null, lifecycleEvent: AuthLifecycleEvent | null) => void,
  ): () => void {
    if (isDemoMode || supabase === null) return () => undefined;
    const client = supabase;
    /**
     * One classified chokepoint for EVERY auth deep link: recovery links and
     * OAuth completion codes exchange here; anything else is ignored so a
     * stray `?code=` can never be fed to the exchanger.
     */
    const exchange = (url: string) => {
      const link = classifyAuthDeepLink(url);
      const code =
        link.kind === 'oauth-code'
          ? link.code
          : link.kind === 'recovery'
            ? link.code
            : null;
      if (code === null || code.length === 0) return;
      void client.auth.exchangeCodeForSession(code).then(({ error }) => {
        if (error) AppLogger.error(`[Auth] deep-link code exchange failed - ${error.message}`);
      });
    };
    const deepLinkSubscription = Linking.addEventListener('url', ({ url }) => exchange(url));
    void Linking.getInitialURL().then((url) => {
      if (url) exchange(url);
    });
    const { data } = client.auth.onAuthStateChange((event, session) => {
      handler(
        session?.user ? mapSupabaseAuthUser(session.user) : null,
        event === 'PASSWORD_RECOVERY' ? 'password-recovery' : null,
      );
    });
    return () => {
      deepLinkSubscription.remove();
      data.subscription.unsubscribe();
    };
  }
}

export const authRepository: AuthRepository = new DefaultAuthRepository();
