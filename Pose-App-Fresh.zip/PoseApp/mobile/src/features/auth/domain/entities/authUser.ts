import type { User } from '@supabase/supabase-js';
import { isDuplicateEmailMessage, type AuthIssueCode } from '@shared/index';

export type AuthProvider = 'email' | 'google';

export interface AuthUser {
  readonly id: string;
  readonly email: string;
  readonly displayName: string;
  readonly avatarUrl: string | null;
  readonly provider: AuthProvider;
}

/**
 * One failure vocabulary for both backends — the union is owned by
 * shared/auth/authFlow.ts so the UI treatment (form error vs. dedicated
 * confirmation state) can never drift between demo and Supabase.
 */
export type AuthFailureCode = AuthIssueCode;

export class AuthFailure extends Error {
  constructor(
    readonly code: AuthFailureCode,
    message: string,
    readonly cause?: unknown,
  ) {
    super(message);
    this.name = 'AuthFailure';
  }
}

export function mapSupabaseAuthUser(user: User): AuthUser {
  const provider = user.app_metadata.provider === 'google' ? 'google' : 'email';
  const email = user.email ?? '';
  const metadata = user.user_metadata as Record<string, unknown>;
  const displayName =
    typeof metadata.display_name === 'string' && metadata.display_name.trim().length > 0
      ? metadata.display_name.trim()
      : typeof metadata.full_name === 'string' && metadata.full_name.trim().length > 0
        ? metadata.full_name.trim()
        : email.split('@')[0] ?? 'User';
  return {
    id: user.id,
    email,
    displayName,
    avatarUrl: typeof metadata.avatar_url === 'string' ? metadata.avatar_url : null,
    provider,
  };
}

export function toAuthFailure(error: unknown): AuthFailure {
  if (error instanceof AuthFailure) return error;
  const message = error instanceof Error ? error.message : String(error);
  const normalized = message.toLowerCase();
  if (normalized.includes('invalid login')) {
    return new AuthFailure('invalid-credentials', 'Email or password is incorrect.', error);
  }
  if (isDuplicateEmailMessage(message)) {
    return new AuthFailure(
      'email-in-use',
      'An account already exists for this email. Sign in instead.',
      error,
    );
  }
  if (normalized.includes('email not confirmed')) {
    return new AuthFailure('email-not-confirmed', 'Confirm your email before signing in.', error);
  }
  if (normalized.includes('password')) {
    return new AuthFailure('weak-password', message, error);
  }
  if (normalized.includes('network') || normalized.includes('fetch')) {
    return new AuthFailure('network', 'Check your connection and try again.', error);
  }
  return new AuthFailure('unknown', message || 'Authentication failed.', error);
}
