/**
 * AuthField — labeled auth form field.
 * Visible label (not placeholder-only), leading icon, inline error with a
 * red border state, optional hint (e.g. the password rule), and an optional
 * trailing control (the password visibility toggle). Tokens only; pure RN.
 */
import React, { forwardRef } from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  type KeyboardTypeOptions,
  type ReturnKeyTypeOptions,
  type TextInputProps,
} from 'react-native';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface AuthFieldProps {
  readonly icon: string;
  readonly label: string;
  readonly placeholder: string;
  readonly value: string;
  readonly onChangeText: (text: string) => void;
  readonly error: string | null;
  readonly hint?: string;
  readonly secureTextEntry?: boolean;
  readonly trailing?: React.ReactNode;
  readonly keyboardType?: KeyboardTypeOptions;
  readonly autoCapitalize?: TextInputProps['autoCapitalize'];
  readonly autoComplete?: TextInputProps['autoComplete'];
  readonly autoCorrect?: boolean;
  readonly returnKeyType?: ReturnKeyTypeOptions;
  readonly onSubmitEditing?: () => void;
  readonly blurOnSubmit?: boolean;
}

export const AuthField = forwardRef<TextInput, AuthFieldProps>(function AuthField(
  {
    icon,
    label,
    placeholder,
    value,
    onChangeText,
    error,
    hint,
    secureTextEntry = false,
    trailing,
    keyboardType,
    autoCapitalize = 'none',
    autoComplete,
    autoCorrect = false,
    returnKeyType,
    onSubmitEditing,
    blurOnSubmit,
  },
  ref,
) {
  const theme = useAppTheme();
  const borderColor = error !== null ? theme.colors.error : theme.colors.divider;
  return (
    <View style={styles.wrap}>
      <AppText variant="small" color={theme.colors.textSecondary} style={styles.label}>
        {label}
      </AppText>
      <View
        style={[
          styles.field,
          { backgroundColor: theme.colors.surface, borderColor },
        ]}
      >
        <IconSymbol name={icon} size={16} color={theme.colors.textDisabled} />
        <TextInput
          ref={ref}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={theme.colors.textDisabled}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={autoCorrect}
          autoComplete={autoComplete}
          secureTextEntry={secureTextEntry}
          returnKeyType={returnKeyType}
          onSubmitEditing={onSubmitEditing}
          blurOnSubmit={blurOnSubmit}
          accessibilityLabel={label}
          style={[styles.input, { color: theme.colors.textPrimary }]}
        />
        {trailing}
      </View>
      {error !== null ? (
        <AppText
          variant="small"
          color={theme.colors.error}
          accessibilityLiveRegion="polite"
          style={styles.message}
        >
          {error}
        </AppText>
      ) : hint !== undefined ? (
        <AppText variant="small" color={theme.colors.textDisabled} style={styles.message}>
          {hint}
        </AppText>
      ) : null}
    </View>
  );
});

const styles = StyleSheet.create({
  wrap: {
    marginTop: spacing.lg,
  },
  label: {
    marginBottom: spacing.xs + 2,
  },
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
  },
  input: {
    flex: 1,
    paddingVertical: spacing.md,
    fontSize: 14,
  },
  message: {
    marginTop: spacing.xs + 2,
  },
});
