/**
 * AuthModeSwitch — the always-visible Sign In / Create Account segmented
 * control. Replaces the old 12px text link that users could miss (or never
 * find): the mode choice is now a deliberate, unmistakable decision with a
 * 48px touch target and full accessibility state per segment.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { AUTH_COPY, mediaColors, radius, spacing, type AuthScreenMode } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';

interface AuthModeSwitchProps {
  readonly mode: AuthScreenMode;
  readonly onChange: (mode: AuthScreenMode) => void;
}

interface SegmentProps {
  readonly label: string;
  readonly selected: boolean;
  readonly onPress: () => void;
}

function Segment({ label, selected, onPress }: SegmentProps) {
  const theme = useAppTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="tab"
      accessibilityState={{ selected }}
      accessibilityLabel={label}
      style={[
        styles.segment,
        selected && {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
        },
      ]}
    >
      <AppText
        variant="button"
        color={selected ? theme.colors.primary : theme.colors.textSecondary}
        align="center"
      >
        {label}
      </AppText>
    </Pressable>
  );
}

export function AuthModeSwitch({ mode, onChange }: AuthModeSwitchProps) {
  const theme = useAppTheme();
  return (
    <View
      accessibilityRole="tablist"
      style={[styles.track, { backgroundColor: theme.colors.backgroundSecondary }]}
    >
      <Segment
        label={AUTH_COPY.modeSignIn}
        selected={mode === 'sign-in'}
        onPress={() => onChange('sign-in')}
      />
      <Segment
        label={AUTH_COPY.modeSignUp}
        selected={mode === 'sign-up'}
        onPress={() => onChange('sign-up')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    flexDirection: 'row',
    borderRadius: radius.md,
    padding: spacing.xs,
    gap: spacing.xs,
    marginTop: spacing.xl,
  },
  segment: {
    flex: 1,
    minHeight: 44,
    justifyContent: 'center',
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: mediaColors.transparent,
  },
});
