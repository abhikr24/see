/** Shared authenticated-feature gate. Unauthenticated users remain browse-only. */
import React from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useAuthStore } from '@/shared/stores/authStore';
import { AppButton } from '@/shared/components/AppButton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface AuthRequiredViewProps {
  readonly feature: string;
  readonly description: string;
  readonly children: React.ReactNode;
}

export function AuthRequiredView({
  feature,
  description,
  children,
}: AuthRequiredViewProps) {
  const theme = useAppTheme();
  const router = useRouter();
  const status = useAuthStore((state) => state.status);

  if (status === 'authenticated') return <>{children}</>;
  if (status === 'initializing') {
    return (
      <View style={[styles.center, { backgroundColor: theme.colors.background }]}>
        <ActivityIndicator color={theme.colors.primary} />
      </View>
    );
  }
  return (
    <View style={[styles.center, { backgroundColor: theme.colors.background }]}>
      <View style={[styles.icon, { backgroundColor: theme.colors.primaryLight }]}>
        <IconSymbol name="lock-outline" size={32} color={theme.colors.primary} />
      </View>
      <AppText variant="heading" color={theme.colors.textPrimary} style={styles.title}>
        Sign in for {feature}
      </AppText>
      <AppText
        variant="secondaryBody"
        color={theme.colors.textSecondary}
        align="center"
        style={styles.description}
      >
        {description}
      </AppText>
      <AppButton
        title="Sign In to Continue"
        onPress={() => router.push('/auth')}
        icon="login"
        style={styles.button}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  icon: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: spacing.lg,
  },
  description: {
    marginTop: spacing.sm,
    maxWidth: 320,
  },
  button: {
    marginTop: spacing.xl,
    minWidth: 240,
  },
});
