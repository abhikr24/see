/**
 * Unit 06 — /auth screen. Email/password sign-in and sign-up plus Google
 * OAuth. The repository automatically selects real Supabase or persisted
 * demo auth. Guest browsing stays free; camera/favorites/stats are gated.
 *
 * Create-Account repair (this architecture replaces the silent auto-exit):
 *  · A session that ALREADY EXISTS when /auth opens can no longer bounce
 *    the user away unseen — the screen renders an explicit "already signed
 *    in" state instead (see shared/auth/authFlow.resolveAuthEntry).
 *  · The ONLY session-change that navigates automatically is an OAuth
 *    return this screen itself initiated (shouldExitAfterSessionChange).
 *  · signUp() success WITHOUT a session (Supabase email confirmation) is a
 *    dedicated check-your-inbox state — never a red error, never a
 *    navigation (no session exists yet).
 *  · Mode is a first-class deep link: /auth?mode=sign-up opens directly in
 *    account creation; a segmented control (not a text link) makes the
 *    choice unmistakable inside the screen.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  AUTH_COPY,
  NO_FORM_ERRORS,
  PASSWORD_RESET_COPY,
  confirmPasswordError,
  displayNameError,
  emailError,
  normalizeEmail,
  parseAuthModeParam,
  passwordError,
  radius,
  resolveAuthEntry,
  shouldExitAfterSessionChange,
  spacing,
  validateAuthForm,
  type AuthFormErrors,
  type AuthScreenMode,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { useAuthStore } from '@/shared/stores/authStore';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PrivacyNote } from '@/shared/components/PrivacyNote';
import { AuthField } from '../components/AuthField';
import { AuthModeSwitch } from '../components/AuthModeSwitch';

type SubmitTarget = 'email' | 'google' | 'resend' | null;

interface ConfirmationState {
  readonly email: string;
  readonly from: AuthScreenMode;
}

export function AuthScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const params = useLocalSearchParams();

  const signInWithEmail = useAuthStore((s) => s.signInWithEmail);
  const signUpWithEmail = useAuthStore((s) => s.signUpWithEmail);
  const signInWithGoogle = useAuthStore((s) => s.signInWithGoogle);
  const resendConfirmationEmail = useAuthStore((s) => s.resendConfirmationEmail);
  const clearLastError = useAuthStore((s) => s.clearLastError);
  const signOut = useAuthStore((s) => s.signOut);
  const isDemoMode = useAuthStore((s) => s.isDemoMode);
  const lastError = useAuthStore((s) => s.lastError);
  const session = useAuthStore((s) => s.session);

  // ── Entry capture (frozen at mount — the fix's foundation) ─────────────
  const hadSessionAtEntry = useRef<boolean>(useAuthStore.getState().session !== null);
  const oauthInitiatedHere = useRef(false);
  const exitRequested = useRef(false);
  const requestedMode = parseAuthModeParam(
    params['mode'] as string | string[] | undefined,
  );
  const entry = resolveAuthEntry(hadSessionAtEntry.current, requestedMode);

  const [mode, setMode] = useState<AuthScreenMode>(
    entry.kind === 'form' ? entry.mode : requestedMode,
  );
  const [confirmation, setConfirmation] = useState<ConfirmationState | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<AuthFormErrors>(NO_FORM_ERRORS);
  const [submitting, setSubmitting] = useState<SubmitTarget>(null);
  const [resentAck, setResentAck] = useState(false);

  const nameRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);
  const confirmRef = useRef<TextInput>(null);

  const exitAfterSuccess = useCallback(() => {
    // Navigate at most once per screen visit, no matter how many success
    // signals race (direct submit result + OAuth listener).
    if (exitRequested.current) return;
    exitRequested.current = true;
    AppLogger.info('[Nav] auth complete — leaving /auth');
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  }, [router]);

  // Automatic navigation exists ONLY for the OAuth round-trip initiated on
  // this screen: no session at entry, browser completes, session appears.
  // Any other session (restored, stale demo, sign-in elsewhere) re-renders
  // the "already signed in" state below instead of navigating.
  useEffect(() => {
    if (
      shouldExitAfterSessionChange(
        hadSessionAtEntry.current,
        session !== null,
        oauthInitiatedHere.current,
      )
    ) {
      exitAfterSuccess();
    }
  }, [session, exitAfterSuccess]);

  const dismiss = useCallback(() => {
    AppLogger.info('[Nav] auth dismissed');
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  }, [router]);

  const switchMode = useCallback(
    (next: AuthScreenMode) => {
      setMode(next);
      setFieldErrors(NO_FORM_ERRORS);
      setConfirmPassword('');
      setResentAck(false);
      clearLastError();
    },
    [clearLastError],
  );

  /** Live re-validation: once a field has an error, editing it updates the
   *  message immediately instead of waiting for the next submit. */
  const editField = useCallback(
    (field: keyof AuthFormErrors, value: string) => {
      if (field === 'displayName') setDisplayName(value);
      else if (field === 'email') setEmail(value);
      else if (field === 'password') setPassword(value);
      else setConfirmPassword(value);
      if (lastError !== null) clearLastError();
      setFieldErrors((current) => {
        // Errors appear on submit; once visible, they re-validate on edit.
        if (current[field] === null) return current;
        const nextPassword = field === 'password' ? value : password;
        const nextConfirm = field === 'confirmPassword' ? value : confirmPassword;
        let nextError: string | null = null;
        if (field === 'displayName') nextError = displayNameError(value);
        else if (field === 'email') nextError = emailError(value);
        else if (field === 'password') nextError = passwordError(value);
        else nextError = confirmPasswordError(nextPassword, nextConfirm);
        // Confirm-password validity depends on BOTH fields in sign-up mode.
        const confirmNext =
          field === 'confirmPassword'
            ? nextError
            : mode === 'sign-up' &&
                field === 'password' &&
                confirmPassword.length > 0 &&
                current.confirmPassword !== null
              ? confirmPasswordError(nextPassword, confirmPassword)
              : current.confirmPassword;
        return { ...current, [field]: nextError, confirmPassword: confirmNext };
      });
    },
    [clearLastError, confirmPassword, lastError, mode, password],
  );

  const submitEmail = useCallback(() => {
    if (submitting !== null) return;
    const { errors, submittable } = validateAuthForm(mode, {
      displayName,
      email,
      password,
      confirmPassword,
    });
    setFieldErrors(errors);
    if (!submittable) return;
    setSubmitting('email');
    void (async () => {
      try {
        const outcome =
          mode === 'sign-in'
            ? await signInWithEmail(email, password)
            : await signUpWithEmail(email, password, displayName);
        if (outcome === 'success') {
          exitAfterSuccess();
        } else if (outcome === 'confirmation-required') {
          // Account created (or unconfirmed account found) with NO session:
          // stay exactly here and explain the next step.
          setConfirmation({ email: normalizeEmail(email), from: mode });
          setPassword('');
          setConfirmPassword('');
        }
        // 'failed' → the store's lastError renders above the buttons.
      } finally {
        setSubmitting(null);
      }
    })();
  }, [
    confirmPassword,
    displayName,
    email,
    exitAfterSuccess,
    mode,
    password,
    signInWithEmail,
    signUpWithEmail,
    submitting,
  ]);

  const submitGoogle = useCallback(() => {
    if (submitting !== null) return;
    setSubmitting('google');
    oauthInitiatedHere.current = true;
    void (async () => {
      try {
        const outcome = await signInWithGoogle();
        // Demo resolves with a session immediately; real OAuth returns null
        // and the session arrives through the root listener (effect above).
        if (outcome === 'success') exitAfterSuccess();
      } finally {
        setSubmitting(null);
      }
    })();
  }, [exitAfterSuccess, signInWithGoogle, submitting]);

  const resend = useCallback(() => {
    if (submitting !== null || confirmation === null) return;
    setSubmitting('resend');
    setResentAck(false);
    void (async () => {
      try {
        const ok = await resendConfirmationEmail(confirmation.email);
        if (ok) setResentAck(true);
      } finally {
        setSubmitting(null);
      }
    })();
  }, [confirmation, resendConfirmationEmail, submitting]);

  const backToSignIn = useCallback(() => {
    setConfirmation(null);
    setResentAck(false);
    switchMode('sign-in');
  }, [switchMode]);

  const switchDemoAccount = useCallback(() => {
    // Dev-only path (isDemoMode implies __DEV__): clears the persisted demo
    // session so auth flows can be tested repeatedly, then reveals the form.
    void signOut().then(() => {
      setMode(requestedMode);
      setConfirmation(null);
      setFieldErrors(NO_FORM_ERRORS);
      AppLogger.info('[Auth] demo session cleared for a fresh auth test');
    });
  }, [requestedMode, signOut]);

  // ── Render ─────────────────────────────────────────────────────────────

  const renderVisibilityToggle = (visible: boolean, toggle: () => void, field: string) => (
    <Pressable
      onPress={toggle}
      hitSlop={10}
      accessibilityRole="button"
      accessibilityLabel={visible ? `Hide ${field}` : `Show ${field}`}
      style={styles.eye}
    >
      <IconSymbol
        name={visible ? 'eye-off-outline' : 'eye-outline'}
        size={18}
        color={theme.colors.textSecondary}
      />
    </Pressable>
  );

  const renderForm = () => (
    <>
      <AuthModeSwitch mode={mode} onChange={switchMode} />
      {mode === 'sign-up' && (
        <AuthField
          ref={nameRef}
          icon="account-outline"
          label={AUTH_COPY.nameLabel}
          placeholder={AUTH_COPY.namePlaceholder}
          value={displayName}
          onChangeText={(text) => editField('displayName', text)}
          error={fieldErrors.displayName}
          autoCapitalize="words"
          autoComplete="name"
          returnKeyType="next"
          onSubmitEditing={() => emailRef.current?.focus()}
          blurOnSubmit={false}
        />
      )}
      <AuthField
        ref={emailRef}
        icon="email-outline"
        label={AUTH_COPY.emailLabel}
        placeholder={AUTH_COPY.emailPlaceholder}
        value={email}
        onChangeText={(text) => editField('email', text)}
        error={fieldErrors.email}
        keyboardType="email-address"
        autoComplete="email"
        returnKeyType="next"
        onSubmitEditing={() => passwordRef.current?.focus()}
        blurOnSubmit={false}
      />
      <AuthField
        ref={passwordRef}
        icon="lock-outline"
        label={AUTH_COPY.passwordLabel}
        placeholder={AUTH_COPY.passwordPlaceholder}
        value={password}
        onChangeText={(text) => editField('password', text)}
        error={fieldErrors.password}
        hint={mode === 'sign-up' ? AUTH_COPY.passwordHint : undefined}
        secureTextEntry={!showPassword}
        trailing={renderVisibilityToggle(showPassword, () => setShowPassword((v) => !v), 'password')}
        autoComplete={mode === 'sign-in' ? 'current-password' : 'new-password'}
        returnKeyType={mode === 'sign-up' ? 'next' : 'go'}
        onSubmitEditing={
          mode === 'sign-up' ? () => confirmRef.current?.focus() : () => submitEmail()
        }
        blurOnSubmit={mode !== 'sign-up'}
      />
      {mode === 'sign-up' && (
        <AuthField
          ref={confirmRef}
          icon="lock-check-outline"
          label={AUTH_COPY.confirmLabel}
          placeholder={AUTH_COPY.confirmPlaceholder}
          value={confirmPassword}
          onChangeText={(text) => editField('confirmPassword', text)}
          error={fieldErrors.confirmPassword}
          secureTextEntry={!showConfirm}
          trailing={renderVisibilityToggle(showConfirm, () => setShowConfirm((v) => !v), 'password confirmation')}
          autoComplete="new-password"
          returnKeyType="go"
          onSubmitEditing={() => submitEmail()}
        />
      )}

      {/* B2 — the password-repair entry. Sign-in mode only; it leaves the
          form untouched (the reset route is a separate surface that never
          competes with this screen's exit policy). */}
      {mode === 'sign-in' && (
        <Pressable
          onPress={() => {
            AppLogger.info('[Nav] auth → /auth/reset-password');
            router.push('/auth/reset-password');
          }}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityLabel={PASSWORD_RESET_COPY.forgotLink}
          style={styles.forgotLink}
        >
          <AppText variant="small" color={theme.colors.primary} align="right">
            {PASSWORD_RESET_COPY.forgotLink}
          </AppText>
        </Pressable>
      )}

      {lastError !== null && (
        <AppText
          variant="small"
          color={theme.colors.error}
          accessibilityLiveRegion="polite"
          style={styles.error}
        >
          {lastError}
        </AppText>
      )}

      <AppButton
        title={mode === 'sign-in' ? AUTH_COPY.submitSignIn : AUTH_COPY.submitSignUp}
        onPress={submitEmail}
        loading={submitting === 'email'}
        disabled={submitting !== null}
        icon={mode === 'sign-in' ? 'email-outline' : 'account-plus-outline'}
        style={styles.primaryCta}
      />
      {mode === 'sign-up' && (
        <AppText
          variant="small"
          color={theme.colors.textSecondary}
          align="center"
          style={styles.whatNext}
        >
          {AUTH_COPY.whatHappensNext}
        </AppText>
      )}
      <AppButton
        title={AUTH_COPY.googleCta}
        onPress={submitGoogle}
        loading={submitting === 'google'}
        disabled={submitting !== null}
        variant="ghost"
        icon="google"
      />

      <View style={styles.note}>
        <PrivacyNote text={isDemoMode ? AUTH_COPY.demoNote : AUTH_COPY.liveNote} />
      </View>
    </>
  );

  const renderConfirmation = () => {
    if (confirmation === null) return null;
    return (
      <View style={styles.panel}>
        <View style={[styles.panelIcon, { backgroundColor: theme.colors.primaryLight }]}>
          <IconSymbol name="email-check-outline" size={26} color={theme.colors.primary} />
        </View>
        <AppText variant="heading" color={theme.colors.textPrimary} style={styles.panelTitle}>
          {AUTH_COPY.confirmationTitle}
        </AppText>
        <AppText
          variant="secondaryBody"
          color={theme.colors.textSecondary}
          style={styles.panelBody}
        >
          {confirmation.from === 'sign-up'
            ? AUTH_COPY.confirmationBody
            : AUTH_COPY.confirmationBodySignIn}
        </AppText>
        <View style={[styles.emailChip, { backgroundColor: theme.colors.backgroundSecondary }]}>
          <IconSymbol name="email-outline" size={14} color={theme.colors.textSecondary} />
          <AppText variant="secondaryBody" color={theme.colors.textPrimary}>
            {confirmation.email}
          </AppText>
        </View>
        {resentAck && (
          <AppText variant="small" color={theme.colors.success} style={styles.resent}>
            {AUTH_COPY.confirmationResent}
          </AppText>
        )}
        {lastError !== null && (
          <AppText
            variant="small"
            color={theme.colors.error}
            accessibilityLiveRegion="polite"
            style={styles.resent}
          >
            {lastError}
          </AppText>
        )}
        <AppButton
          title={AUTH_COPY.confirmationBackToSignIn}
          onPress={backToSignIn}
          icon="login"
          style={styles.panelCta}
        />
        <AppButton
          title={AUTH_COPY.confirmationResend}
          onPress={resend}
          loading={submitting === 'resend'}
          disabled={submitting !== null}
          variant="ghost"
          icon="email-sync-outline"
        />
      </View>
    );
  };

  const renderAlreadySignedIn = () => {
    const name = session?.displayName ?? '';
    const address = session?.email ?? '';
    return (
      <View style={styles.panel}>
        <View style={[styles.panelIcon, { backgroundColor: theme.colors.primaryLight }]}>
          <IconSymbol name="account-check-outline" size={26} color={theme.colors.primary} />
        </View>
        <AppText variant="heading" color={theme.colors.textPrimary} style={styles.panelTitle}>
          {AUTH_COPY.alreadySignedInTitle}
        </AppText>
        <AppText
          variant="secondaryBody"
          color={theme.colors.textSecondary}
          style={styles.panelBody}
        >
          {AUTH_COPY.alreadySignedInBody}
        </AppText>
        <View style={[styles.emailChip, { backgroundColor: theme.colors.backgroundSecondary }]}>
          <IconSymbol name="account-outline" size={14} color={theme.colors.textSecondary} />
          <AppText variant="secondaryBody" color={theme.colors.textPrimary}>
            {name.length > 0 ? `${name} · ${address}` : address}
          </AppText>
        </View>
        <AppButton
          title={AUTH_COPY.alreadySignedInContinue}
          onPress={exitAfterSuccess}
          icon="arrow-right"
          style={styles.panelCta}
        />
        <AppButton
          title={AUTH_COPY.alreadySignedInProfile}
          onPress={() => router.replace('/(tabs)/profile')}
          variant="ghost"
          icon="account-outline"
          style={styles.profileCta}
        />
        {isDemoMode && (
          <Pressable
            onPress={switchDemoAccount}
            accessibilityRole="button"
            accessibilityLabel={AUTH_COPY.demoSwitchAccount}
            style={styles.demoSwitch}
          >
            <AppText variant="small" color={theme.colors.textSecondary} align="center">
              {AUTH_COPY.demoSwitchAccount}
            </AppText>
          </Pressable>
        )}
      </View>
    );
  };

  const headerIcon =
    session !== null
      ? 'account-check-outline'
      : confirmation !== null
        ? 'email-check-outline'
        : mode === 'sign-up'
          ? 'account-plus-outline'
          : 'lock-outline';
  const headerTitle =
    session !== null
      ? AUTH_COPY.alreadySignedInTitle
      : confirmation !== null
        ? AUTH_COPY.confirmationTitle
        : mode === 'sign-in'
          ? AUTH_COPY.signInTitle
          : AUTH_COPY.signUpTitle;

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Pressable
            onPress={dismiss}
            hitSlop={10}
            accessibilityRole="button"
            accessibilityLabel="Close sign in"
            style={[styles.close, { backgroundColor: theme.colors.backgroundSecondary }]}
          >
            <IconSymbol name="close" size={18} color={theme.colors.textSecondary} />
          </Pressable>

          {session === null && confirmation === null ? (
            <>
              <View style={[styles.iconWrap, { backgroundColor: theme.colors.primaryLight }]}>
                <IconSymbol name={headerIcon} size={24} color={theme.colors.primary} />
              </View>
              <AppText
                variant="heading"
                color={theme.colors.textPrimary}
                accessibilityRole="header"
                style={styles.title}
              >
                {headerTitle}
              </AppText>
              <AppText
                variant="secondaryBody"
                color={theme.colors.textSecondary}
                style={styles.subtitle}
              >
                {mode === 'sign-in' ? AUTH_COPY.signInSubtitle : AUTH_COPY.signUpSubtitle}
              </AppText>
              {renderForm()}
            </>
          ) : (
            <View accessibilityLiveRegion="polite">
              {session !== null ? renderAlreadySignedIn() : renderConfirmation()}
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  scroll: {
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  close: {
    width: 36,
    height: 36,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.xl,
  },
  title: {
    marginTop: spacing.lg,
  },
  subtitle: {
    marginTop: spacing.sm,
  },
  error: {
    marginTop: spacing.lg,
  },
  primaryCta: {
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  whatNext: {
    marginTop: -spacing.xs,
    marginBottom: spacing.md,
  },
  forgotLink: {
    marginTop: spacing.md,
    paddingVertical: spacing.sm,
    alignSelf: 'stretch',
    minHeight: 44,
    justifyContent: 'center',
  },
  note: {
    marginTop: spacing.xl,
  },
  eye: {
    padding: spacing.sm,
    marginRight: -spacing.sm,
  },
  panel: {
    marginTop: spacing.section,
  },
  panelIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  panelTitle: {
    marginTop: spacing.lg,
  },
  panelBody: {
    marginTop: spacing.sm,
  },
  emailChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    alignSelf: 'flex-start',
    borderRadius: radius.pill,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    marginTop: spacing.lg,
  },
  resent: {
    marginTop: spacing.md,
  },
  panelCta: {
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  profileCta: {
    marginBottom: spacing.sm,
  },
  demoSwitch: {
    minHeight: 48,
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
});
