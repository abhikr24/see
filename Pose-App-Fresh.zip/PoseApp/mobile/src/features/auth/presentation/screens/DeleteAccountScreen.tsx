/**
 * Route screen: /delete-account — B1 ACCOUNT DELETION.
 *
 * Serious, calm, explicit. The flow is deliberately two-step:
 *   intro → consequence list (what dies / what survives) → typed DELETE
 *   confirmation → secure backend deletion → local cleanup → signed-out
 *   finality state.
 *
 * Hard guarantees this surface keeps:
 *   · 'Account deleted' renders ONLY after the store reports 'deleted'
 *     (which itself requires the explicit server ack). A failure NEVER
 *     signs the user out — the failure panel states plainly that nothing
 *     was deleted and the session is intact.
 *   · Demo mode is visibly labeled as device-local demo behavior — never
 *     implied to be server deletion.
 *   · Deleting is a request to the secure boundary; the UI shows no
 *     internal plumbing, tokens, or privileged-credential language.
 */
import React, { useCallback, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  ACCOUNT_DELETE_COPY,
  DELETE_CONFIRMATION_PHRASE,
  deleteConfirmationError,
  radius,
  spacing,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { isBackendConfigured } from '@/core/network/supabaseClient';
import { useAuthStore } from '@/shared/stores/authStore';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { ScreenHeader } from '@/shared/components/ScreenHeader';
import { PrivacyNote } from '@/shared/components/PrivacyNote';

type Phase = 'intro' | 'confirm' | 'success';

export function DeleteAccountScreen() {
  const theme = useAppTheme();
  const router = useRouter();

  const session = useAuthStore((s) => s.session);
  const isDemoMode = useAuthStore((s) => s.isDemoMode);
  const lastError = useAuthStore((s) => s.lastError);
  const clearLastError = useAuthStore((s) => s.clearLastError);
  const deleteAccount = useAuthStore((s) => s.deleteAccount);

  const [phase, setPhase] = useState<Phase>('intro');
  const [typed, setTyped] = useState('');
  const [deleting, setDeleting] = useState(false);

  const confirmError = deleteConfirmationError(typed);
  const armed = confirmError === null && !deleting;

  const leave = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)');
  }, [router]);

  const submitDeletion = useCallback(() => {
    if (!armed) return;
    setDeleting(true);
    void (async () => {
      try {
        const outcome = await deleteAccount();
        if (outcome === 'deleted') {
          setPhase('success');
        }
        // 'failed' → store.lastError renders the reason; session is intact.
      } finally {
        setDeleting(false);
      }
    })();
  }, [armed, deleteAccount]);

  const editTyped = useCallback(
    (value: string) => {
      setTyped(value);
      if (lastError !== null) clearLastError();
    },
    [clearLastError, lastError],
  );

  const backendNote = isDemoMode
    ? ACCOUNT_DELETE_COPY.demoNote
    : isBackendConfigured
      ? ACCOUNT_DELETE_COPY.liveNote
      : 'The production backend is not configured — deletion is unavailable until Supabase keys are supplied.';

  /* ── Guard: deletion only exists against a live session ─────────────── */
  if (session === null && phase !== 'success') {
    return (
      <SafeAreaView
        edges={['top']}
        style={[styles.root, { backgroundColor: theme.colors.backgroundSecondary }]}
      >
        <ScreenHeader title={ACCOUNT_DELETE_COPY.headerTitle} onBack={leave} />
        <View style={styles.center}>
          <View style={[styles.panelIcon, { backgroundColor: theme.colors.primaryLight }]}>
            <IconSymbol name="account-lock-outline" size={26} color={theme.colors.primary} />
          </View>
          <AppText variant="heading" color={theme.colors.textPrimary} style={styles.panelTitle}>
            {ACCOUNT_DELETE_COPY.signInRequiredTitle}
          </AppText>
          <AppText
            variant="secondaryBody"
            color={theme.colors.textSecondary}
            align="center"
            style={styles.panelBody}
          >
            {ACCOUNT_DELETE_COPY.signInRequiredBody}
          </AppText>
          <AppButton title="Go Back" onPress={leave} icon="arrow-left" style={styles.panelCta} />
        </View>
      </SafeAreaView>
    );
  }

  /* ── Finality: deleted CONFIRMED — a calm end state, not a fake one ─── */
  if (phase === 'success') {
    return (
      <SafeAreaView
        edges={['top']}
        style={[styles.root, { backgroundColor: theme.colors.backgroundSecondary }]}
      >
        <View style={styles.center}>
          <View style={[styles.panelIcon, { backgroundColor: theme.colors.primaryLight }]}>
            <IconSymbol name="account-remove-outline" size={26} color={theme.colors.primary} />
          </View>
          <AppText variant="heading" color={theme.colors.textPrimary} style={styles.panelTitle}>
            {ACCOUNT_DELETE_COPY.successTitle}
          </AppText>
          <AppText
            variant="secondaryBody"
            color={theme.colors.textSecondary}
            align="center"
            style={styles.panelBody}
          >
            {isDemoMode ? ACCOUNT_DELETE_COPY.successBodyDemo : ACCOUNT_DELETE_COPY.successBody}
          </AppText>
          {isDemoMode && <PrivacyNote text={ACCOUNT_DELETE_COPY.demoNote} />}
          <AppButton
            title={ACCOUNT_DELETE_COPY.successContinue}
            onPress={() => router.replace('/(tabs)/explore')}
            icon="arrow-right"
            style={styles.panelCta}
          />
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
            style={styles.finalNote}
          >
            You can keep browsing the pose library without an account.
          </AppText>
        </View>
      </SafeAreaView>
    );
  }

  const renderConsequenceRow = (icon: string, text: string) => (
    <View key={text} style={styles.consequenceRow}>
      <IconSymbol name={icon} size={16} color={theme.colors.error} style={styles.rowIcon} />
      <AppText variant="secondaryBody" color={theme.colors.textPrimary} style={styles.rowText}>
        {text}
      </AppText>
    </View>
  );

  const renderKeepRow = (icon: string, text: string) => (
    <View key={text} style={styles.consequenceRow}>
      <IconSymbol name={icon} size={16} color={theme.colors.textSecondary} style={styles.rowIcon} />
      <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.rowText}>
        {text}
      </AppText>
    </View>
  );

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.root, { backgroundColor: theme.colors.backgroundSecondary }]}
    >
      <ScreenHeader
        title={ACCOUNT_DELETE_COPY.headerTitle}
        onBack={phase === 'confirm' && deleting ? undefined : leave}
      />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={[styles.alertIcon, { backgroundColor: theme.colors.primaryLight }]}>
            <IconSymbol name="account-remove-outline" size={22} color={theme.colors.error} />
          </View>

          {/* What dies */}
          <View
            style={[
              styles.card,
              { backgroundColor: theme.colors.surface, borderColor: theme.colors.divider },
            ]}
          >
            <AppText variant="cardTitle" color={theme.colors.textPrimary}>
              {ACCOUNT_DELETE_COPY.consequenceTitle}
            </AppText>
            <View style={styles.rows}>
              {renderConsequenceRow('account-outline', ACCOUNT_DELETE_COPY.consequenceServerProfile)}
              {renderConsequenceRow('heart-outline', ACCOUNT_DELETE_COPY.consequenceFavorites)}
              {renderConsequenceRow('image-multiple-outline', ACCOUNT_DELETE_COPY.consequenceGallery)}
              {renderConsequenceRow('logout', ACCOUNT_DELETE_COPY.consequenceSession)}
            </View>
          </View>

          {/* What survives — documented keeps, stated plainly */}
          <View
            style={[
              styles.card,
              { backgroundColor: theme.colors.surface, borderColor: theme.colors.divider },
            ]}
          >
            <AppText variant="cardTitle" color={theme.colors.textPrimary}>
              {ACCOUNT_DELETE_COPY.keepTitle}
            </AppText>
            <View style={styles.rows}>
              {renderKeepRow('image-outline', ACCOUNT_DELETE_COPY.keepDevicePhotos)}
              {renderKeepRow('cog-outline', ACCOUNT_DELETE_COPY.keepSettings)}
            </View>
          </View>

          <AppText
            variant="small"
            color={theme.colors.error}
            accessibilityLiveRegion="polite"
            style={styles.finality}
          >
            {ACCOUNT_DELETE_COPY.finality}
          </AppText>

          <View style={styles.note}>
            <PrivacyNote text={backendNote} />
          </View>

          {phase === 'intro' && (
            <>
              <AppButton
                title="Continue"
                onPress={() => {
                  AppLogger.info('[Auth] delete-account: intro acknowledged');
                  setPhase('confirm');
                }}
                variant="ghost"
                icon="arrow-right"
              />
              <AppButton
                title={ACCOUNT_DELETE_COPY.cancelLabel}
                onPress={leave}
                icon="arrow-left"
                style={styles.keepCta}
              />
            </>
          )}

          {phase === 'confirm' && (
            <>
              <AppText variant="small" color={theme.colors.textSecondary} style={styles.instruction}>
                {ACCOUNT_DELETE_COPY.confirmInstruction}
              </AppText>
              <View
                style={[
                  styles.confirmField,
                  {
                    backgroundColor: theme.colors.surface,
                    borderColor: armed ? theme.colors.error : theme.colors.divider,
                  },
                ]}
              >
                <IconSymbol name="alert-decagram-outline" size={16} color={theme.colors.textDisabled} />
                <TextInput
                  value={typed}
                  onChangeText={editTyped}
                  placeholder={ACCOUNT_DELETE_COPY.confirmPlaceholder}
                  placeholderTextColor={theme.colors.textDisabled}
                  autoCapitalize="characters"
                  autoCorrect={false}
                  editable={!deleting}
                  accessibilityLabel={ACCOUNT_DELETE_COPY.confirmInstruction}
                  style={[styles.confirmInput, { color: theme.colors.textPrimary }]}
                />
              </View>

              {lastError !== null && (
                <View
                  style={[
                    styles.failureBox,
                    { backgroundColor: theme.colors.surface, borderColor: theme.colors.error },
                  ]}
                  accessibilityLiveRegion="assertive"
                >
                  <AppText variant="cardTitle" color={theme.colors.error}>
                    {ACCOUNT_DELETE_COPY.failureTitle}
                  </AppText>
                  <AppText variant="small" color={theme.colors.textSecondary} style={styles.failureBody}>
                    {ACCOUNT_DELETE_COPY.failureBody}
                  </AppText>
                  <AppText variant="small" color={theme.colors.error} style={styles.failureBody}>
                    {lastError}
                  </AppText>
                </View>
              )}

              {/* Destructive — disabled until the typed gate is exact */}
              <Pressable
                onPress={submitDeletion}
                disabled={!armed}
                accessibilityRole="button"
                accessibilityState={{ disabled: !armed, busy: deleting }}
                accessibilityLabel={ACCOUNT_DELETE_COPY.submitDelete}
                style={({ pressed }) => [
                  styles.deleteBtn,
                  {
                    backgroundColor: theme.colors.error,
                    opacity: armed ? (pressed ? 0.8 : 1) : 0.35,
                  },
                ]}
              >
                {deleting ? (
                  <AppText variant="button" color={theme.colors.textOnPrimary}>
                    {ACCOUNT_DELETE_COPY.deletingLabel}
                  </AppText>
                ) : (
                  <>
                    <IconSymbol name="delete-forever" size={16} color={theme.colors.textOnPrimary} />
                    <AppText
                      variant="button"
                      color={theme.colors.textOnPrimary}
                      style={styles.deleteBtnText}
                    >
                      {ACCOUNT_DELETE_COPY.submitDelete}
                    </AppText>
                  </>
                )}
              </Pressable>

              <AppButton
                title={ACCOUNT_DELETE_COPY.cancelLabel}
                onPress={leave}
                disabled={deleting}
                variant="ghost"
                icon="arrow-left"
                style={styles.keepCta}
              />
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  scroll: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
    paddingBottom: spacing.xxxl * 2,
  },
  alertIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  card: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  rows: {
    gap: spacing.md,
    marginTop: spacing.md,
  },
  consequenceRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  rowIcon: {
    marginTop: 1,
  },
  rowText: {
    flex: 1,
  },
  finality: {
    marginHorizontal: spacing.sm,
    marginBottom: spacing.xl,
    lineHeight: 18,
  },
  note: {
    marginBottom: spacing.xl,
  },
  keepCta: {
    marginTop: spacing.md,
  },
  instruction: {
    marginBottom: spacing.sm,
  },
  confirmField: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1.5,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.lg,
  },
  confirmInput: {
    flex: 1,
    paddingVertical: spacing.md,
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 2,
  },
  failureBox: {
    borderRadius: radius.md,
    borderWidth: 1,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  failureBody: {
    marginTop: spacing.xs,
    lineHeight: 17,
  },
  deleteBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    minHeight: 52,
    borderRadius: radius.md,
  },
  deleteBtnText: {
    fontWeight: '600',
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  panelIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  panelTitle: {
    marginTop: spacing.lg,
  },
  panelBody: {
    marginTop: spacing.sm,
    lineHeight: 20,
  },
  panelCta: {
    alignSelf: 'stretch',
    marginTop: spacing.xl,
  },
  finalNote: {
    marginTop: spacing.lg,
  },
});
