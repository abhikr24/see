/**
 * Route screen: /auth/reset-password — B2 PASSWORD RECOVERY.
 *
 * One address serves the whole repair journey, and every surface is honest
 * about where the user stands:
 *
 *   request-link  — "Forgot password?" landed here: email in, link out.
 *   sent          — neutral acknowledgement (existence-safe, spam hint,
 *                   resend). Demo mode says plainly no email can arrive.
 *   new-password  — a LIVE recovery session exists (PASSWORD_RECOVERY from
 *                   Supabase, or a labeled demo walkthrough): validated new
 *                   password form with show/hide.
 *   done          — update confirmed; the recovery session is now simply
 *                   the user's session → Continue into the app once.
 *   link-invalid  — arrived via a recovery link that never produced a
 *                   session (expired/used/malformed): explain + recover.
 *
 * Loop safety: this screen NEVER auto-navigates on session changes (the
 * shared policy has no such branch), so a recovery session can never fight
 * the auth screen's exit logic. Passwords are never logged anywhere.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  PASSWORD_RESET_COPY,
  POST_RESET_DESTINATION,
  radius,
  resolveResetPasswordEntry,
  spacing,
  validateResetForm,
  type ResetFormErrors,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { useAuthStore } from '@/shared/stores/authStore';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PrivacyNote } from '@/shared/components/PrivacyNote';
import { AuthField } from '../components/AuthField';

type Surface = 'verifying' | 'request' | 'sent' | 'new' | 'done' | 'invalid';
type Submitting = 'send' | 'update' | null;

const NO_RESET_ERRORS: ResetFormErrors = { password: null, confirmPassword: null };

export function ResetPasswordScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const params = useLocalSearchParams();

  const session = useAuthStore((s) => s.session);
  const status = useAuthStore((s) => s.status);
  const isDemoMode = useAuthStore((s) => s.isDemoMode);
  const recoveryActive = useAuthStore((s) => s.recoverySessionActive);
  const lastError = useAuthStore((s) => s.lastError);
  const clearLastError = useAuthStore((s) => s.clearLastError);
  const requestPasswordReset = useAuthStore((s) => s.requestPasswordReset);
  const completePasswordReset = useAuthStore((s) => s.completePasswordReset);
  const clearRecoverySession = useAuthStore((s) => s.clearRecoverySession);

  // The link we were opened with decides whether a session MUST appear:
  // any Supabase recovery link routes here (with ?code= for PKCE exchange,
  // or type=recovery on the deep link). The store's recovery flag only
  // turns true AFTER the code exchange settles — hence a short, explicit
  // 'verifying' pre-state instead of instantly judging the link dead.
  const recoveryIntent = useRef<boolean>(
    (() => {
      const code = params['code'];
      const type = params['type'];
      return (
        (typeof code === 'string' && code.length > 0) ||
        (typeof type === 'string' && type === 'recovery')
      );
    })(),
  );

  const [surface, setSurface] = useState<Surface>(() =>
    recoveryIntent.current ? 'verifying' : 'request',
  );
  const [email, setEmail] = useState('');
  const [emailErrorText, setEmailErrorText] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [resetErrors, setResetErrors] = useState<ResetFormErrors>(NO_RESET_ERRORS);
  const [submitting, setSubmitting] = useState<Submitting>(null);
  const [resentAck, setResentAck] = useState(false);

  const passwordRef = useRef<TextInput>(null);
  const confirmRef = useRef<TextInput>(null);

  /** Demo walkthrough: signed-in demo users may preview the form (labeled).
   *  Never available unauthenticated in demo, never in production — a real
   *  recovery session is required there. */
  const demoPreviewUnlocked = isDemoMode && session !== null;
  const liveRecovery = recoveryActive || demoPreviewUnlocked;

  // Arrival resolution: once Supabase emits PASSWORD_RECOVERY (or the
  // settle window lapses), the shared policy decides the surface.
  useEffect(() => {
    if (surface !== 'verifying') return;
    if (status === 'initializing') return;
    if (recoveryActive) {
      setSurface('new');
      return;
    }
    const settleTimer = setTimeout(() => {
      // Exchange failed/expired → the invalid surface tells the truth.
      setSurface((current) => {
        if (current !== 'verifying') return current;
        const entry = resolveResetPasswordEntry(false, recoveryIntent.current);
        return entry.kind === 'link-invalid' ? 'invalid' : 'request';
      });
    }, 2500);
    return () => clearTimeout(settleTimer);
  }, [surface, status, recoveryActive]);

  // A recovery session arriving while ANY earlier surface is on screen
  // (e.g. user opened the link with the request form visible) promotes
  // straight into the new-password step — one-directional, no loops.
  useEffect(() => {
    if (recoveryActive && (surface === 'request' || surface === 'sent' || surface === 'invalid')) {
      setSurface('new');
    }
  }, [recoveryActive, surface]);

  const backToAuth = useCallback(() => {
    clearLastError();
    if (router.canGoBack()) router.back();
    else router.replace('/auth');
  }, [clearLastError, router]);

  const sendRecoveryEmail = useCallback(() => {
    if (submitting !== null) return;
    const error = email.length > 0 ? null : 'Enter your account email to continue.';
    setEmailErrorText(error);
    if (error !== null) return;
    setSubmitting('send');
    setResentAck(false);
    void (async () => {
      try {
        const ok = await requestPasswordReset(email);
        if (ok) {
          setSurface('sent');
          AppLogger.info('[Auth] recovery request submitted (neutral ack shown)');
        }
      } finally {
        setSubmitting(null);
      }
    })();
  }, [email, requestPasswordReset, submitting]);

  const editEmail = useCallback(
    (value: string) => {
      setEmail(value);
      setEmailErrorText(null);
      if (lastError !== null) clearLastError();
    },
    [clearLastError, lastError],
  );

  const editResetField = useCallback(
    (field: keyof ResetFormErrors, value: string) => {
      if (field === 'password') setPassword(value);
      else setConfirmPassword(value);
      if (lastError !== null) clearLastError();
      setResetErrors((current) => {
        if (current[field] === null) return current;
        // Once visible, errors re-validate on edit (same as the auth form).
        const nextPassword = field === 'password' ? value : password;
        const nextConfirm = field === 'confirmPassword' ? value : confirmPassword;
        return validateResetForm({ password: nextPassword, confirmPassword: nextConfirm }).errors;
      });
    },
    [clearLastError, confirmPassword, lastError, password],
  );

  const submitNewPassword = useCallback(() => {
    if (submitting !== null) return;
    const { errors, submittable } = validateResetForm({ password, confirmPassword });
    setResetErrors(errors);
    if (!submittable) return;
    setSubmitting('update');
    void (async () => {
      try {
        const outcome = await completePasswordReset(password);
        if (outcome === 'success') {
          setPassword('');
          setConfirmPassword('');
          setSurface('done');
          AppLogger.info('[Auth] recovery completed');
        }
        // 'failed' → store.lastError renders inline; nothing navigates away.
      } finally {
        setSubmitting(null);
      }
    })();
  }, [completePasswordReset, confirmPassword, password, submitting]);

  const finishDone = useCallback(() => {
    clearRecoverySession();
    router.replace(POST_RESET_DESTINATION);
  }, [clearRecoverySession, router]);

  const renderVisibilityToggle = (visible: boolean, toggle: () => void, field: string) => (
    <Pressable
      onPress={toggle}
      hitSlop={10}
      accessibilityRole="button"
      accessibilityLabel={visible ? `Hide ${field}` : `Show ${field}`}
      style={styles.eye}
    >
      <IconSymbol
        name={visible ? 'eye-off-outline' : 'eye-outline'}
        size={18}
        color={theme.colors.textSecondary}
      />
    </Pressable>
  );

  const renderPanel = (
    icon: string,
    title: string,
    body: string,
    children?: React.ReactNode,
    tone: 'info' | 'error' = 'info',
  ) => (
    <View style={styles.panel} accessibilityLiveRegion="polite">
      <View
        style={[
          styles.panelIcon,
          { backgroundColor: theme.colors.primaryLight },
        ]}
      >
        <IconSymbol name={icon} size={26} color={tone === 'error' ? theme.colors.error : theme.colors.primary} />
      </View>
      <AppText
        variant="heading"
        color={theme.colors.textPrimary}
        accessibilityRole="header"
        style={styles.panelTitle}
      >
        {title}
      </AppText>
      <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.panelBody}>
        {body}
      </AppText>
      {children}
    </View>
  );

  const renderError = () =>
    lastError !== null ? (
      <AppText
        variant="small"
        color={theme.colors.error}
        accessibilityLiveRegion="polite"
        style={styles.error}
      >
        {lastError}
      </AppText>
    ) : null;

  const renderContent = () => {
    switch (surface) {
      case 'verifying':
        return renderPanel('link-variant', 'Opening your recovery link', 'One moment…', (
          <ActivityIndicator color={theme.colors.primary} style={styles.spinner} />
        ));

      case 'invalid':
        return renderPanel(
          'link-off',
          PASSWORD_RESET_COPY.invalidTitle,
          PASSWORD_RESET_COPY.invalidBody,
          <>
            {renderError()}
            <AppButton
              title={PASSWORD_RESET_COPY.invalidCta}
              onPress={() => setSurface('request')}
              icon="email-outline"
              style={styles.panelCta}
            />
            <AppButton
              title={PASSWORD_RESET_COPY.requestCancel}
              onPress={backToAuth}
              variant="ghost"
              icon="login"
            />
          </>,
          'error',
        );

      case 'sent':
        return renderPanel(
          'email-check-outline',
          PASSWORD_RESET_COPY.requestSentTitle,
          PASSWORD_RESET_COPY.requestSentBody,
          <>
            <View style={[styles.emailChip, { backgroundColor: theme.colors.backgroundSecondary }]}>
              <IconSymbol name="email-outline" size={14} color={theme.colors.textSecondary} />
              <AppText variant="secondaryBody" color={theme.colors.textPrimary}>
                {email}
              </AppText>
            </View>
            <AppText variant="small" color={theme.colors.textDisabled} style={styles.spam}>
              {PASSWORD_RESET_COPY.requestSentSpamHint}
            </AppText>
            {resentAck && (
              <AppText variant="small" color={theme.colors.success} style={styles.spam}>
                {PASSWORD_RESET_COPY.requestResent}
              </AppText>
            )}
            {renderError()}
            <AppButton
              title={PASSWORD_RESET_COPY.requestResend}
              onPress={sendRecoveryEmail}
              loading={submitting === 'send'}
              disabled={submitting !== null}
              variant="ghost"
              icon="email-sync-outline"
              style={styles.panelCta}
            />
            <AppButton
              title={PASSWORD_RESET_COPY.requestCancel}
              onPress={backToAuth}
              icon="login"
            />
            {isDemoMode && (
              <View style={styles.demoNote}>
                <PrivacyNote text={PASSWORD_RESET_COPY.requestDemoNote} />
              </View>
            )}
          </>,
        );

      case 'new':
        return (
          <>
            <View style={[styles.headerIcon, { backgroundColor: theme.colors.primaryLight }]}>
              <IconSymbol name="lock-reset" size={24} color={theme.colors.primary} />
            </View>
            <AppText
              variant="heading"
              color={theme.colors.textPrimary}
              accessibilityRole="header"
              style={styles.title}
            >
              {PASSWORD_RESET_COPY.newTitle}
            </AppText>
            <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.subtitle}>
              {PASSWORD_RESET_COPY.newBody}
            </AppText>
            <AuthField
              ref={passwordRef}
              icon="lock-outline"
              label={PASSWORD_RESET_COPY.newLabel}
              placeholder={PASSWORD_RESET_COPY.newPlaceholder}
              value={password}
              onChangeText={(text) => editResetField('password', text)}
              error={resetErrors.password}
              hint={PASSWORD_RESET_COPY.newHint}
              secureTextEntry={!showPassword}
              trailing={renderVisibilityToggle(showPassword, () => setShowPassword((v) => !v), 'new password')}
              autoComplete="new-password"
              returnKeyType="next"
              onSubmitEditing={() => confirmRef.current?.focus()}
              blurOnSubmit={false}
            />
            <AuthField
              ref={confirmRef}
              icon="lock-check-outline"
              label={PASSWORD_RESET_COPY.newConfirmLabel}
              placeholder={PASSWORD_RESET_COPY.newConfirmPlaceholder}
              value={confirmPassword}
              onChangeText={(text) => editResetField('confirmPassword', text)}
              error={resetErrors.confirmPassword}
              secureTextEntry={!showConfirm}
              trailing={renderVisibilityToggle(showConfirm, () => setShowConfirm((v) => !v), 'password confirmation')}
              autoComplete="new-password"
              returnKeyType="go"
              onSubmitEditing={submitNewPassword}
            />
            {renderError()}
            <AppButton
              title={PASSWORD_RESET_COPY.newSubmit}
              onPress={submitNewPassword}
              loading={submitting === 'update'}
              disabled={submitting !== null}
              icon="check"
              style={styles.primaryCta}
            />
            {isDemoMode && (
              <View style={styles.demoNote}>
                <PrivacyNote text={PASSWORD_RESET_COPY.newDemoNote} />
              </View>
            )}
          </>
        );

      case 'done':
        return renderPanel(
          'check-decagram-outline',
          PASSWORD_RESET_COPY.doneTitle,
          PASSWORD_RESET_COPY.doneBody,
          <AppButton
            title={PASSWORD_RESET_COPY.doneContinue}
            onPress={finishDone}
            icon="arrow-right"
            style={styles.panelCta}
          />,
        );

      case 'request':
      default:
        return (
          <>
            <View style={[styles.headerIcon, { backgroundColor: theme.colors.primaryLight }]}>
              <IconSymbol name="email-fast-outline" size={24} color={theme.colors.primary} />
            </View>
            <AppText
              variant="heading"
              color={theme.colors.textPrimary}
              accessibilityRole="header"
              style={styles.title}
            >
              {PASSWORD_RESET_COPY.requestTitle}
            </AppText>
            <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.subtitle}>
              {PASSWORD_RESET_COPY.requestBody}
            </AppText>
            <AuthField
              icon="email-outline"
              label="Email"
              placeholder="Email address"
              value={email}
              onChangeText={editEmail}
              error={emailErrorText}
              keyboardType="email-address"
              autoComplete="email"
              returnKeyType="go"
              onSubmitEditing={sendRecoveryEmail}
            />
            {renderError()}
            <AppButton
              title={PASSWORD_RESET_COPY.requestSubmit}
              onPress={sendRecoveryEmail}
              loading={submitting === 'send'}
              disabled={submitting !== null}
              icon="email-outline"
              style={styles.primaryCta}
            />
            <AppButton
              title={PASSWORD_RESET_COPY.requestCancel}
              onPress={backToAuth}
              variant="ghost"
              icon="login"
            />
            {isDemoMode && (
              <View style={styles.demoNote}>
                <PrivacyNote text={PASSWORD_RESET_COPY.requestDemoNote} />
              </View>
            )}
          </>
        );
    }
  };

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.root, { backgroundColor: theme.colors.background }]}
    >
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {surface !== 'done' && surface !== 'verifying' && (
            <Pressable
              onPress={backToAuth}
              hitSlop={10}
              accessibilityRole="button"
              accessibilityLabel="Back to sign in"
              style={[styles.close, { backgroundColor: theme.colors.backgroundSecondary }]}
            >
              <IconSymbol name="close" size={18} color={theme.colors.textSecondary} />
            </Pressable>
          )}
          {renderContent()}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  scroll: {
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  close: {
    width: 36,
    height: 36,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.xl,
  },
  title: {
    marginTop: spacing.lg,
  },
  subtitle: {
    marginTop: spacing.sm,
    lineHeight: 20,
  },
  primaryCta: {
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  error: {
    marginTop: spacing.lg,
  },
  eye: {
    padding: spacing.sm,
    marginRight: -spacing.sm,
  },
  panel: {
    marginTop: spacing.section,
  },
  panelIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  panelTitle: {
    marginTop: spacing.lg,
  },
  panelBody: {
    marginTop: spacing.sm,
    lineHeight: 20,
  },
  panelCta: {
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  spinner: {
    marginTop: spacing.xl,
    alignSelf: 'flex-start',
  },
  emailChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    alignSelf: 'flex-start',
    borderRadius: radius.pill,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    marginTop: spacing.lg,
  },
  spam: {
    marginTop: spacing.md,
  },
  demoNote: {
    marginTop: spacing.xl,
  },
});
