/**
 * FRAMING — AspectRatioMask.
 *
 * The viewfinder keeps filling the screen (releasing the preview surface to
 * re-letterbox it would restart the camera on every ratio change, and a black
 * flash per tap is not a premium control). Instead the bands that the chosen
 * shape will DISCARD are covered, so what the user sees framed is exactly
 * what the capture pipeline crops the file down to.
 *
 * The mask is heavy enough to read as "outside the picture" and still
 * translucent, because a posing user needs to see a hand or a foot drifting
 * into the dead band BEFORE the shutter, not discover it in the gallery.
 *
 * At the sensor's native 4:3 there is nothing to discard and this renders
 * nothing at all.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { mediaColors, type AspectRatioId } from '@shared/index';

interface AspectRatioMaskProps {
  readonly ratio: AspectRatioId;
  /** Height of the band hidden at the top AND at the bottom. */
  readonly inset: number;
  /** Announced once, for screen readers: "Square", "Wide"… */
  readonly label: string;
}

export function AspectRatioMask({ ratio, inset, label }: AspectRatioMaskProps) {
  if (inset <= 0) return null;
  return (
    <View
      style={StyleSheet.absoluteFill}
      pointerEvents="none"
      accessible
      accessibilityLabel={`${label} ${ratio}`}
    >
      <View style={[styles.band, { top: 0, height: inset }]} />
      <View style={[styles.band, { bottom: 0, height: inset }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  band: {
    position: 'absolute',
    left: 0,
    right: 0,
    backgroundColor: mediaColors.overlayHeavy,
  },
});
