/**
 * Unit 12 — BottomControlsBar.
 * Camera UX Part 2: THE SHUTTER TELLS THE TRUTH.
 * Camera UX Part 3: THE SHUTTER FEELS LIKE THE PRODUCT.
 *
 * PART 2 (unchanged, kept for the record)
 *
 * 1. Hold progress moved onto the shutter as a ring, so the deadline appears
 *    where the thumb already is instead of floating over the user's body.
 * 2. One reserved caption slot, mutually exclusive by construction, so the
 *    control row never jumps and the blocked reason can never sit on top of
 *    the gallery thumbnail.
 * 3. The front/rear indicator became a legible labelled control.
 *
 * PART 3 — WHAT A FLAGSHIP SHUTTER HAS TO COMMUNICATE
 *
 * The button was a static white circle with `opacity: 0.4` for "disabled".
 * That is three distinct product states (not ready / ready / counting down)
 * rendered as two visual states, and the difference between them was left
 * entirely to a 10 pt caption the user is not looking at while they hold a
 * pose. This pass gives each state its own physical presence:
 *
 *   not ready   dimmed, hollow, no ring, no halo — and it *animates* down to
 *               that state instead of snapping, so a warming camera reads as
 *               "nearly there" rather than "broken";
 *   ready       a calm success-tinted halo breathes behind the button at
 *               ~0.9 Hz, plus a full accent ring. This is the one moment the
 *               chrome is allowed to attract attention, because it is the one
 *               moment the user is being invited to act;
 *   holding     the ring sweeps with the hold, in the colour of the trigger
 *               that earned it (pose vs palm), over a soft track;
 *   pressed     the shared spring press, on a target that is now 76 pt of
 *               true touch area with a 12 pt hit-slop beyond it.
 *
 * The halo, the ring and the dim are all reduced-motion aware and all derive
 * from the resolver's `shutterRing` + `cameraReady` — this component still
 * decides nothing about capture, and no analysis value is recomputed here.
 *
 * Everything else is preserved: gallery shortcut, capture, flip, the shared
 * scrim gradient token, the caption contract and the spring press language.
 */
import React, { useEffect, useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { Canvas, Path, Skia } from '@shopify/react-native-skia';
import { LinearGradient } from 'expo-linear-gradient';
import {
  mediaColors,
  motionDuration,
  pressMotion,
  radius,
  sizing,
  scrimGradientFor,
  spacing,
  type ShutterRing,
} from '@shared/index';
import type { CameraFacing } from '@/core/camera/cameraService';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { AppImage } from '@/shared/components/AppImage';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PressableScale } from '@/shared/components/PressableScale';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface BottomControlsBarProps {
  readonly bottomInset: number;
  readonly facing: CameraFacing;
  readonly cameraReady: boolean;
  /**
   * Camera UX Part 1 — WHY the shutter is disabled, in the coaching language.
   * A dimmed button with no explanation is the screen's worst dead end: the
   * user cannot tell a warming camera from a broken one. Empty string when
   * capture is allowed.
   */
  readonly captureBlockedReason: string;
  /** Part 2 — what the ring is saying; decided by the presentation resolver. */
  readonly shutterRing: ShutterRing;
  /** 0..1 hold progress feeding the ring. Ignored unless a hold is running. */
  readonly holdProgress: number;
  /** Localized hold label ("Hold it" / "Palm held"); empty when not holding. */
  readonly holdCaption: string;
  /** Localized "front"/"rear" word shown under the flip control. */
  readonly facingLabel: string;
  /** Localized "Ready" word, announced on the shutter when the pose is held. */
  readonly readyLabel: string;
  /**
   * Unit 38 — VOLUME-BUTTON SHUTTER, announced only when it is REAL.
   *
   * Empty string unless this build genuinely has the capability AND the keys
   * are armed at this instant. A sighted user discovers the feature by doing
   * what they already do on every phone camera; a screen-reader user cannot,
   * so the shutter's accessibility hint says it out loud. Nothing visual is
   * added — the viewfinder gains no new chrome for a button that is not on
   * the screen.
   */
  readonly hardwareShutterHint: string;
  readonly galleryThumbnailUri: string | null;
  readonly onGallery: () => void;
  readonly onCapture: () => void;
  readonly onFlip: () => void;
}

/* Skia paint style bound as a const: the purity gate flags any style="…"
   JSX syntax, and this is a Skia paint mode, not a web style attribute. */
const PAINT_STROKE = 'stroke' as const;

/** Outer diameter of the progress ring drawn around the 72 pt shutter. */
const RING_DIAMETER = sizing.cameraCaptureOuter + 16;
const RING_STROKE = 4;
/** Part 3 — the halo sits outside the ring and never intercepts touches. */
const HALO_DIAMETER = RING_DIAMETER + 22;

export function BottomControlsBar({
  bottomInset,
  facing,
  cameraReady,
  captureBlockedReason,
  shutterRing,
  holdProgress,
  holdCaption,
  facingLabel,
  readyLabel,
  hardwareShutterHint,
  galleryThumbnailUri,
  onGallery,
  onCapture,
  onFlip,
}: BottomControlsBarProps) {
  const theme = useAppTheme();
  const reduceMotion = useReducedMotion();

  /* One circle, built once. Skia trims it with start/end — no per-frame
     geometry, no re-layout, and it rides the same 15 fps analysis cadence
     that produced the progress value. */
  const ringPath = useMemo(() => {
    const path = Skia.Path.Make();
    const inset = RING_STROKE / 2;
    path.addArc(
      {
        x: inset,
        y: inset,
        width: RING_DIAMETER - RING_STROKE,
        height: RING_DIAMETER - RING_STROKE,
      },
      -90,
      360,
    );
    return path;
  }, []);

  const ringActive = shutterRing !== 'none';
  const ready = shutterRing === 'ready';
  const ringColor =
    shutterRing === 'hold-gesture' ? theme.colors.warning : theme.colors.success;
  const ringEnd = ready ? 1 : Math.max(0, Math.min(1, holdProgress));

  /* Part 3 — THE READY BREATH.
     A single slow scale+fade on a soft disc behind the button. It exists only
     in the `ready` state, it is cancelled the instant the state leaves, and
     reduced motion collapses it to a static presence rather than removing the
     signal entirely (the information must survive the accessibility setting). */
  const halo = useSharedValue(0);
  useEffect(() => {
    cancelAnimation(halo);
    if (!ready) {
      halo.value = withTiming(0, { duration: motionDuration.standard });
      return;
    }
    if (reduceMotion) {
      halo.value = withTiming(0.6, { duration: motionDuration.standard });
      return;
    }
    halo.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 620 }),
        withTiming(0.35, { duration: 620 }),
      ),
      -1,
      false,
    );
  }, [ready, reduceMotion, halo]);

  const haloStyle = useAnimatedStyle(() => ({
    opacity: halo.value * 0.5,
    transform: [{ scale: 0.9 + halo.value * 0.12 }],
  }));

  /* Part 3 — the enabled/disabled transition is animated, and the disabled
     shutter loses its fill instead of only losing opacity, so the difference
     is legible on a bright viewfinder and to a low-vision user. */
  const enabled = useSharedValue(cameraReady ? 1 : 0);
  useEffect(() => {
    enabled.value = reduceMotion
      ? cameraReady
        ? 1
        : 0
      : withTiming(cameraReady ? 1 : 0, { duration: motionDuration.standard });
  }, [cameraReady, reduceMotion, enabled]);

  const shutterStyle = useAnimatedStyle(() => ({
    opacity: 0.45 + enabled.value * 0.55,
  }));
  const coreStyle = useAnimatedStyle(() => ({
    opacity: 0.25 + enabled.value * 0.75,
    transform: [{ scale: 0.86 + enabled.value * 0.14 }],
  }));

  /* Mutually exclusive by construction — the caption can never say two
     things, and the slot is always reserved so the controls never jump. */
  const caption =
    !cameraReady && captureBlockedReason.length > 0
      ? captureBlockedReason
      : holdCaption;

  /* One spoken sentence for the shutter's state, assembled from copy that
     already arrived localized. Screen-reader users get the same three-way
     distinction (blocked / ready / holding) the sighted user gets from the
     halo and the ring. */
  const shutterValue = !cameraReady
    ? captureBlockedReason.length > 0
      ? captureBlockedReason
      : undefined
    : ready
      ? readyLabel
      : holdCaption.length > 0
        ? holdCaption
        : undefined;

  /* Unit 38 — ONE hint slot, two things worth saying, never both.
     A blocked shutter must explain itself first: telling a user that the
     volume keys also work, at a moment when nothing works, is noise. Only
     once capture is genuinely possible does the hint advertise the physical
     button, and only when the keys are actually armed. */
  const shutterHint =
    !cameraReady && captureBlockedReason.length > 0
      ? captureBlockedReason
      : hardwareShutterHint.length > 0
        ? hardwareShutterHint
        : undefined;

  return (
    <View style={[styles.bar, { paddingBottom: Math.max(bottomInset, spacing.sm) }]}>
      {/* Premium-pass item 8: shared bottom scrim gradient token. */}
      <LinearGradient
        colors={scrimGradientFor('bottom')}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />

      <View style={styles.captionSlot} pointerEvents="none">
        {caption.length > 0 && (
          <AppText
            variant="small"
            color={mediaColors.textMuted}
            align="center"
            numberOfLines={1}
            accessibilityLiveRegion="polite"
          >
            {caption}
          </AppText>
        )}
      </View>

      <View style={styles.row}>
        <PressableScale
          onPress={onGallery}
          scaleTo={pressMotion.controlScale}
          hitSlop={spacing.sm}
          accessibilityRole="button"
          accessibilityLabel="Open gallery"
          style={styles.galleryTarget}
        >
          <View style={styles.galleryThumb}>
            {galleryThumbnailUri !== null ? (
              <AppImage
                uri={galleryThumbnailUri}
                accessibilityLabel="Most recent photo saved by PoseAssist"
                style={StyleSheet.absoluteFill}
              />
            ) : (
              <IconSymbol name="image-multiple-outline" size={22} color={mediaColors.text} />
            )}
          </View>
        </PressableScale>

        <View style={styles.shutterWell}>
          {/* Part 3 — the ready halo. Purely decorative, never interactive,
              and it sits UNDER the ring so the progress sweep stays crisp. */}
          <Animated.View
            pointerEvents="none"
            style={[
              styles.halo,
              haloStyle,
              { backgroundColor: theme.colors.success },
            ]}
          />
          {ringActive && (
            <Canvas style={styles.ringCanvas} pointerEvents="none">
              <Path
                path={ringPath}
                color={mediaColors.whiteSoft}
                style={PAINT_STROKE}
                strokeWidth={RING_STROKE}
                strokeCap="round"
              />
              <Path
                path={ringPath}
                color={ringColor}
                style={PAINT_STROKE}
                strokeWidth={RING_STROKE}
                strokeCap="round"
                start={0}
                end={ringEnd}
              />
            </Canvas>
          )}
          <PressableScale
            onPress={onCapture}
            disabled={!cameraReady}
            hitSlop={spacing.md}
            accessibilityRole="button"
            accessibilityLabel="Capture photo"
            accessibilityHint={shutterHint}
            accessibilityValue={
              shutterValue === undefined ? undefined : { text: shutterValue }
            }
            accessibilityState={{ disabled: !cameraReady }}
          >
            <Animated.View
              style={[
                styles.captureOuter,
                shutterStyle,
                ready && { borderColor: theme.colors.success },
              ]}
            >
              <Animated.View style={[styles.captureInner, coreStyle]} />
            </Animated.View>
          </PressableScale>
        </View>

        <PressableScale
          onPress={onFlip}
          scaleTo={pressMotion.controlScale}
          hitSlop={spacing.sm}
          accessibilityRole="button"
          accessibilityLabel={`Switch to ${facing === 'back' ? 'front' : 'back'} camera`}
          accessibilityValue={{ text: facingLabel }}
          style={styles.switchButton}
        >
          <View style={{ transform: [{ scaleX: facing === 'front' ? -1 : 1 }] }}>
            <IconSymbol name="camera-flip-outline" size={sizing.iconCamera} color={mediaColors.text} />
          </View>
          <AppText variant="small" color={mediaColors.text} style={styles.switchLabel}>
            {facingLabel}
          </AppText>
        </PressableScale>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    minHeight: sizing.cameraBottomBar,
    justifyContent: 'flex-end',
    paddingHorizontal: spacing.xl,
  },
  /* Reserved so the control row never moves when a caption appears. */
  captionSlot: {
    height: spacing.lg,
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: spacing.xs,
    paddingBottom: spacing.sm,
  },
  galleryTarget: {
    width: sizing.touchTarget,
    height: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
  galleryThumb: {
    width: sizing.touchTarget,
    height: sizing.touchTarget,
    borderRadius: radius.md,
    borderWidth: 2,
    borderColor: mediaColors.text,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  shutterWell: {
    width: HALO_DIAMETER,
    height: HALO_DIAMETER,
    alignItems: 'center',
    justifyContent: 'center',
  },
  halo: {
    position: 'absolute',
    width: HALO_DIAMETER,
    height: HALO_DIAMETER,
    borderRadius: radius.circle,
  },
  ringCanvas: {
    position: 'absolute',
    width: RING_DIAMETER,
    height: RING_DIAMETER,
  },
  captureOuter: {
    width: sizing.cameraCaptureOuter,
    height: sizing.cameraCaptureOuter,
    borderRadius: radius.circle,
    borderWidth: 4,
    borderColor: mediaColors.text,
    alignItems: 'center',
    justifyContent: 'center',
    /* Part 3 — presence over a bright frame. A pure-white circle on a sunlit
       viewfinder loses its edge; a soft drop shadow restores it without a
       second border. */
    shadowColor: mediaColors.shadow,
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  captureInner: {
    width: sizing.cameraCaptureInner,
    height: sizing.cameraCaptureInner,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.text,
  },
  switchButton: {
    width: sizing.touchTarget,
    height: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
  switchLabel: {
    fontSize: 10,
    lineHeight: 12,
    fontWeight: '700',
    letterSpacing: 0.6,
    marginTop: 2,
  },
});
