/**
 * CAMERA CONTROLS — BrightnessControl.
 *
 * A phone camera's brightness control has to satisfy four things at once:
 * it must be reachable without hunting, adjustable with one thumb while the
 * other hand holds the pose, obviously resettable, and invisible the rest of
 * the time. This is the whole control:
 *
 *   · COLLAPSED it is a single sun glyph in the top bar carrying a small
 *     "+2" / "−1" badge. At the default value there is no badge at all, so
 *     the normal state of this feature is "no chrome and no number".
 *   · EXPANDED it becomes a vertical detent track pinned to the RIGHT edge at
 *     thumb height — the side of the frame that is already free of the
 *     coaching band, the status rail and the pose chip. Dragging the thumb,
 *     tapping a detent or tapping the ends all work; every change is a
 *     detent, so the user can always describe where they are.
 *   · RESET is one tap on the value chip at the top of the track (and it
 *     disappears when there is nothing to reset), not a long-press secret.
 *   · DISMISS is a tap anywhere off the track, or the sun glyph again, or
 *     simply leaving it alone: the panel auto-closes after a few idle
 *     seconds, because a slider is not chrome and must not squat on the
 *     viewfinder.
 *
 * HONESTY (D1). The title and footnote UNDER the track now follow the
 * mechanism that actually carries the adjustment: while the native exposure
 * bridge is live the control is named "Exposure" and its note says the
 * camera's exposure really changes (the sensor is biased — no viewfinder
 * wash); on the photo-processing fallback it stays "Brightness · Applied to
 * your photo", with the approximation wash doing the preview. The two
 * mechanisms are never stacked and never borrow each other's name.
 */
import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import {
  BRIGHTNESS_MAX,
  BRIGHTNESS_MIN,
  clampBrightness,
  isBrightnessDefault,
  radius,
  mediaColors,
  spacing,
  type CameraStatusCopy,
  type ExposureMechanism,
} from '@shared/index';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { useAppTheme } from '@/core/theme';

/** Detents, brightest first — the track reads top = brighter, like a slider. */
const DETENTS: readonly number[] = [3, 2, 1, 0, -1, -2, -3];

const TRACK_HEIGHT = 208;
const DETENT_HEIGHT = TRACK_HEIGHT / DETENTS.length;
const IDLE_DISMISS_MS = 3800;

interface BrightnessControlProps {
  readonly level: number;
  readonly open: boolean;
  readonly copy: CameraStatusCopy;
  readonly topOffset: number;
  /** D1 — decides the mechanism-honest title, footnote and announcements. */
  readonly mechanism: ExposureMechanism;
  readonly onChange: (level: number) => void;
  readonly onReset: () => void;
  readonly onRequestClose: () => void;
}

export function BrightnessControl({
  level,
  open,
  copy,
  topOffset,
  mechanism,
  onChange,
  onReset,
  onRequestClose,
}: BrightnessControlProps) {
  const theme = useAppTheme();
  const value = clampBrightness(level);
  const title = copy.brightnessTitleFor(mechanism);
  const note = copy.brightnessNoteFor(mechanism);
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const armIdleDismiss = useCallback(() => {
    if (idleTimer.current !== null) clearTimeout(idleTimer.current);
    idleTimer.current = setTimeout(onRequestClose, IDLE_DISMISS_MS);
  }, [onRequestClose]);

  useEffect(() => {
    if (!open) {
      if (idleTimer.current !== null) clearTimeout(idleTimer.current);
      return;
    }
    armIdleDismiss();
    return () => {
      if (idleTimer.current !== null) clearTimeout(idleTimer.current);
    };
  }, [open, value, armIdleDismiss]);

  const setFromOffset = useCallback(
    (offsetY: number) => {
      const index = Math.min(
        DETENTS.length - 1,
        Math.max(0, Math.floor(offsetY / DETENT_HEIGHT)),
      );
      const next = DETENTS[index] ?? 0;
      if (next !== value) onChange(next);
      armIdleDismiss();
    },
    [armIdleDismiss, onChange, value],
  );

  /* One gesture for tap AND drag: a camera slider that only responds to
     discrete taps feels broken, and one that only responds to drags is
     unusable for a single-step correction. */
  const pan = useMemo(
    () =>
      Gesture.Pan()
        .minDistance(0)
        .onBegin((event) => setFromOffset(event.y))
        .onChange((event) => setFromOffset(event.y))
        .runOnJS(true),
    [setFromOffset],
  );

  if (!open) return null;

  const atDefault = isBrightnessDefault(value);

  return (
    <>
      {/* Tap-off-to-dismiss. Transparent, below the track, above nothing that
          needs touches while the panel is open. */}
      <Pressable
        style={StyleSheet.absoluteFill}
        accessibilityRole="button"
        accessibilityLabel={`${title} — ${copy.captureDismiss}`}
        onPress={onRequestClose}
      />
      <View style={[styles.panel, { top: topOffset }]} pointerEvents="box-none">
        <Pressable
          onPress={onReset}
          disabled={atDefault}
          accessibilityRole="button"
          accessibilityLabel={title}
          accessibilityValue={{ text: copy.brightnessValue(value) }}
          accessibilityHint={atDefault ? undefined : copy.brightnessReset}
          accessibilityState={{ disabled: atDefault }}
          style={[
            styles.valueChip,
            { backgroundColor: mediaColors.overlayStrong },
            atDefault ? null : { borderColor: theme.colors.primary, borderWidth: 1 },
          ]}
        >
          <AppText variant="small" color={mediaColors.text} style={styles.valueText}>
            {copy.brightnessValue(value)}
          </AppText>
          {!atDefault && (
            <AppText variant="small" color={mediaColors.textSubtle} style={styles.resetText}>
              {copy.brightnessReset}
            </AppText>
          )}
        </Pressable>

        <GestureDetector gesture={pan}>
          <View
            style={[styles.track, { backgroundColor: mediaColors.overlayStrong }]}
            accessible
            accessibilityRole="adjustable"
            accessibilityLabel={title}
            accessibilityValue={{
              min: BRIGHTNESS_MIN,
              max: BRIGHTNESS_MAX,
              now: value,
              text: copy.brightnessValue(value),
            }}
            accessibilityActions={[
              { name: 'increment', label: copy.brightnessBrighter },
              { name: 'decrement', label: copy.brightnessDarker },
              { name: 'activate', label: copy.brightnessReset },
            ]}
            onAccessibilityAction={(event) => {
              const action = event.nativeEvent.actionName;
              if (action === 'increment') onChange(clampBrightness(value + 1));
              else if (action === 'decrement') onChange(clampBrightness(value - 1));
              else if (action === 'activate') onReset();
            }}
          >
            <IconSymbol name="white-balance-sunny" size={16} color={mediaColors.text} />
            <View style={styles.detents}>
              {DETENTS.map((detent) => {
                const selected = detent === value;
                return (
                  <View key={detent} style={styles.detentRow}>
                    <View
                      style={[
                        styles.detentMark,
                        {
                          backgroundColor: selected
                            ? theme.colors.primary
                            : mediaColors.whiteMuted,
                          width: selected ? 26 : detent === 0 ? 18 : 12,
                          height: selected ? 4 : 2,
                        },
                      ]}
                    />
                  </View>
                );
              })}
            </View>
            <IconSymbol name="weather-night" size={16} color={mediaColors.textSubtle} />
          </View>
        </GestureDetector>

        <View style={[styles.note, { backgroundColor: mediaColors.overlayMedium }]}>
          <AppText variant="small" color={mediaColors.textSubtle} style={styles.noteText}>
            {note}
          </AppText>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  panel: {
    position: 'absolute',
    right: spacing.md,
    alignItems: 'center',
  },
  valueChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    alignItems: 'center',
    marginBottom: spacing.xs,
    minWidth: 84,
  },
  valueText: {
    fontWeight: '700',
  },
  resetText: {
    fontSize: 10,
  },
  track: {
    width: 48,
    height: TRACK_HEIGHT,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.xs,
  },
  detents: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  detentRow: {
    height: DETENT_HEIGHT - 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  detentMark: {
    borderRadius: 2,
  },
  note: {
    marginTop: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.pill,
    maxWidth: 148,
  },
  noteText: {
    fontSize: 10,
    textAlign: 'center',
  },
});
