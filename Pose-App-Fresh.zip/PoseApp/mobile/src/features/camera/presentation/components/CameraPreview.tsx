/**
 * Unit 12 — CameraPreview · A1 — engine: react-native-vision-camera (Nitro).
 *
 * The single Camera view instance (JIT-mounted, released on unmount/background)
 * wrapped with GestureHandler pinch-to-zoom (1×–8× display multiplier —
 * unchanged user semantics; VisionCamera's zoom unit IS the multiplier).
 *
 * A1 CHANGES (engine swap, UX preserved):
 *   · expo-camera CameraView → VisionCamera <Camera> via a LAZY, GUARDED
 *     require, so a host without the native module (Expo Go / metro-web)
 *     surfaces the existing mount-error path instead of crashing the bundle.
 *   · Photo capture lives in a CameraPhotoOutput registered with
 *     cameraService (flash is applied at the shutter, never mid-write).
 *   · Live pose input is a CameraFrameOutput (native frames, no JPEG/base64)
 *     authored by useNativePoseFrameOutput and attached here alongside the
 *     photo output — two independent outputs of ONE camera engine.
 *   · mirrorMode: 'auto' (default) — front preview mirrored exactly like the
 *     old expo-camera viewfinder; frames carry isMirrored for the adapter.
 *
 * D1 CARRIED FORWARD (engine-adapted):
 *   · The detent's EV bias now reaches the sensor through VisionCamera's
 *     declarative `exposure` prop (exposureBias, continuous float EV) instead
 *     of the retired expo-camera patch — same semantic: an automatic-exposure
 *     bias, never a lock, never manual ISO/shutter.
 *   · Capability reporting rides useCameraDevice: supportsExposureBias /
 *     minExposureBias / maxExposureBias are DEVICE FACTS the native layer
 *     already maintains; they are normalised into the same
 *     shared/camera/cameraExposure payload the session store consumes, fired
 *     when a camera binds and on every facing switch.
 *   · The approximation wash is drawn ONLY under the photo-processing
 *     mechanism — under native exposure the viewfinder's brightening IS the
 *     real exposure response and a wash would double-count it.
 *
 * D2 CARRIED FORWARD (unchanged):
 *   · The live look is the canonical projection
 *     shared/camera/cameraFilters.filterPreviewOverlay — tint colour, opacity
 *     and strength curve derive from the same twenty matrix numbers the
 *     capture pipeline bakes into the saved JPEG (parity, no double filter).
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Platform, StyleSheet, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import {
  ZOOM_DEFAULT_X,
  brightnessPreviewScrim,
  clampZoom,
  filterPreviewOverlay,
  formatZoom,
  isZoomDefault,
  mediaColors,
  zoomFromPinch,
  type ExposureMechanism,
} from '@shared/index';
import type {
  CameraFacing,
  CameraFilterId,
} from '@/core/camera/cameraService';
import { registerPhotoOutput } from '@/core/camera/cameraService';
import { AppLogger } from '@/core/utils/logger';

/* ── lazy native module surface ────────────────────────────────────────────
   Mirrors useNativePoseFrameOutput's rationale: NEVER resolve vision-camera
   at module scope. First offline host = null → mount-error UX, not a crash. */

/** The shape of a bound camera the D1 capability report is derived from. */
interface VisionCameraDeviceInfo {
  readonly id: string;
  readonly supportsExposureBias: boolean;
  readonly minExposureBias: number;
  readonly maxExposureBias: number;
}

interface VisionCameraUi {
  readonly Camera: React.ComponentType<Record<string, unknown>>;
  readonly usePhotoOutput: (options: Record<string, unknown>) => unknown;
  readonly useCameraDevice: (
    position: 'front' | 'back',
  ) => VisionCameraDeviceInfo | undefined;
}

function loadVisionCameraUi(): VisionCameraUi | null {
  try {
    /* eslint-disable @typescript-eslint/no-var-requires */
    const mod = require('react-native-vision-camera') as {
      Camera?: React.ComponentType<Record<string, unknown>>;
      usePhotoOutput?: (options?: Record<string, unknown>) => unknown;
      useCameraDevice?: (position: 'front' | 'back') => VisionCameraDeviceInfo | undefined;
    };
    /* eslint-enable @typescript-eslint/no-var-requires */
    if (typeof mod?.Camera !== 'function' && typeof mod?.Camera !== 'object') return null;
    if (typeof mod?.usePhotoOutput !== 'function') return null;
    if (typeof mod?.useCameraDevice !== 'function') return null;
    return { Camera: mod.Camera, usePhotoOutput: mod.usePhotoOutput, useCameraDevice: mod.useCameraDevice };
  } catch (error) {
    AppLogger.warn(`[Camera] vision-camera unavailable in this build — ${String(error)}`);
    return null;
  }
}

interface CameraPreviewProps {
  readonly facing: CameraFacing;
  /**
   * FRAMING — the user-facing multiplier (1× … 8× rear, 1× … 4× front),
   * already clamped by the shared range model. VisionCamera's `zoom` prop
   * speaks the same unit, so no conversion stands between the number the
   * user reads and the number the hardware receives.
   */
  readonly zoomX: number;
  /**
   * CAMERA CONTROLS — the continuous lamp, resolved for this facing by
   * `resolveLighting` (front cameras have no torch).
   */
  readonly torchOn: boolean;
  /**
   * BRIGHTNESS — the user's detent, previewed here as a wash ONLY while the
   * photo pipeline is the mechanism carrying it (see `mechanism`).
   */
  readonly brightness: number;
  /**
   * D1 — WHICH mechanism currently carries the detent.
   *
   *   · "native-exposure": the sensor's auto-exposure is biased through the
   *     `exposure` prop below; the viewfinder's brightening IS the real
   *     exposure response, so NO wash is drawn on top of it (a wash would
   *     double the visible adjustment and lie about the sensor).
   *   · "photo-processing": the fallback. The wash is an APPROXIMATION of the
   *     adjustment the capture pipeline bakes into the saved JPEG, nothing
   *     more — labelled that way in the control's footnote.
   */
  readonly mechanism: ExposureMechanism;
  /**
   * D1 — the EV bias handed to the native camera, already device-clamped by
   * shared/camera/cameraExposure. A no-op (0) on builds where the bound
   * device reports no exposureBias support.
   */
  readonly exposureCompensation: number;
  /**
   * D1 — the one-way capability report derived from the bound VisionCamera
   * device (support · EV range), fired when a camera binds and again on
   * every switch. Consumed exclusively by the session store.
   */
  readonly onExposureCapabilities: (payload: unknown) => void;
  /**
   * LOOKS — the selected filter and its strength (D2). The live tint is the
   * canonical `filterPreviewOverlay` projection of the same matrix the
   * capture pipeline bakes onto the photograph — parity by construction,
   * drawn as one overlay because no engine exposes per-frame viewfinder
   * colour management to this app. The REAL look lands on the file in
   * core/camera/photoBrightness, from the same matrix.
   */
  readonly filter: CameraFilterId;
  readonly filterIntensity: number;
  /**
   * A1 — the native frame output for live pose (from useNativePoseFrame
   * Output), attached ONLY while the ML gate is open. `null` = camera
   * streams preview+photo outputs only; zero ML cost.
   */
  readonly frameOutput: unknown | null;
  /** Receives a MULTIPLIER, already clamped to this camera's honest range. */
  readonly onZoomChange: (multiplier: number) => void;
  readonly onCameraReady: () => void;
  readonly onRelease: () => void;
  /** Hardware/driver failure — surfaced to the user, never swallowed. */
  readonly onMountError: (message: string) => void;
}

export function CameraPreview({
  facing,
  zoomX,
  torchOn,
  brightness,
  mechanism,
  exposureCompensation,
  onExposureCapabilities,
  filter,
  filterIntensity,
  frameOutput,
  onZoomChange,
  onCameraReady,
  onRelease,
  onMountError,
}: CameraPreviewProps) {
  const liveZoom = useRef(zoomX);
  const gestureBase = useRef(ZOOM_DEFAULT_X);
  const ui = useMemo(loadVisionCameraUi, []);
  const [mountFailed, setMountFailed] = useState(false);

  /* Photo output: created once per mount (options constant), registered with
     cameraService for the shutter, unregistered on release. In web/Go hosts
     ui is null and the mount-error path below has already taken over. */
  const photoOutput = ui?.usePhotoOutput({
    quality: 0.9,
    qualityPrioritization: 'quality',
  });

  /* D1 — the bound camera device (reactive; re-resolves on facing switch).
     VisionCamera exposes exposureBias support/range as device facts, which
     is exactly the capability contract shared/camera/cameraExposure consumes. */
  const device = ui?.useCameraDevice(facing);

  useEffect(() => {
    liveZoom.current = zoomX;
  }, [zoomX]);

  /* Report a missing native camera stack EXACTLY once, through the same
     mount-error channel hardware failures use (unchanged UX for the shell's
     state machine). */
  useEffect(() => {
    if (Platform.OS === 'web') return;
    if (ui === null && !mountFailed) {
      setMountFailed(true);
      AppLogger.error('[Camera] native camera stack missing (Expo Go / web host)');
      onMountError('The native camera is not available in this build.');
    }
  }, [ui, mountFailed, onMountError]);

  /* D1 — capability report: emitted when a camera binds (device object
     appears) and on every facing switch (device id changes). stepEV 0 models
     VisionCamera's continuous float exposureBias (no quantisation exposed);
     currentEV starts at 0 because every fresh bind starts un-biased and the
     declarative `exposure` prop re-applies the session's detent. A device
     without exposureBias support reports supported=false, which is exactly
     the "no native seam this session" branch the store already handles. */
  const deviceId = device?.id;
  useEffect(() => {
    if (device === undefined || ui === null) return;
    if (Platform.OS === 'web') return;
    onExposureCapabilities({
      supported: device.supportsExposureBias === true,
      minEV: device.minExposureBias,
      maxEV: device.maxExposureBias,
      stepEV: 0,
      currentEV: 0,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deviceId, ui, onExposureCapabilities]);

  /* photo-output registry lifecycle mirrors the mount lifecycle 1:1. */
  useEffect(() => {
    if (photoOutput == null) return undefined;
    registerPhotoOutput(photoOutput as Parameters<typeof registerPhotoOutput>[0]);
    return () => registerPhotoOutput(null);
  }, [photoOutput]);

  // A preview released by the screen unmounting it is the definitive
  // release signal for the single-session invariant.
  useEffect(() => {
    return () => {
      onRelease();
    };
  }, [onRelease]);

  /**
   * PINCH — multiplicative against the multiplier the gesture STARTED from.
   *
   * The previous implementation multiplied expo-camera's normalised 0..1 value
   * by the gesture scale. That value is 0 at the 1× default, and `0 × scale`
   * is 0, so pinching out from rest was a no-op: the user had to already be
   * zoomed for zoom to respond. The maths now lives in shared/ and is the same
   * maths the stop row and the readout use.
   */
  const gestures = useMemo(() => {
    const pinch = Gesture.Pinch()
      .onBegin(() => {
        gestureBase.current = clampZoom(liveZoom.current, facing);
      })
      .onChange((event) => {
        const next = zoomFromPinch(gestureBase.current, event.scale, facing);
        liveZoom.current = next;
        onZoomChange(next);
      })
      .onFinalize(() => {
        AppLogger.info(`[Camera] zoom → ${formatZoom(liveZoom.current, facing)}`);
      })
      .runOnJS(true);

    /* Double tap: the fastest possible way back to the whole frame while a
       pose is being held — and, at 1×, a one-gesture jump to 2×. Two taps,
       not a long press, so it cannot be discovered by accident and cannot be
       confused with the five-finger capture gesture (which is a HAND SEEN BY
       THE CAMERA, not a touch). */
    const doubleTap = Gesture.Tap()
      .numberOfTaps(2)
      .maxDuration(280)
      .onEnd(() => {
        const next = isZoomDefault(liveZoom.current, facing)
          ? clampZoom(2, facing)
          : ZOOM_DEFAULT_X;
        liveZoom.current = next;
        onZoomChange(next);
        AppLogger.info(`[Camera] zoom (double tap) → ${formatZoom(next, facing)}`);
      })
      .runOnJS(true);

    return Gesture.Race(pinch, doubleTap);
  }, [facing, onZoomChange]);

  if (Platform.OS === 'web') return null;

  /* D1 — the approximation wash exists ONLY for the photo-processing
     fallback. Under real exposure the sensor brightens the viewfinder
     itself; drawing the wash too would double-count the adjustment. */
  const wash =
    mechanism === 'photo-processing'
      ? brightnessPreviewScrim(brightness)
      : { mode: 'none' as const, opacity: 0 };
  /* D2 — the canonical matrix PROJECTED onto the one lawful viewfinder
     operation (see shared/camera/cameraFilters). Memoise it: it depends only
     on (filter, intensity), while this component re-renders for pinch-zoom
     frames, countdown ticks and pose updates. */
  const look = useMemo(
    () => filterPreviewOverlay(filter, filterIntensity),
    [filter, filterIntensity],
  );

  const outputs = useMemo(
    () => (frameOutput !== null ? [photoOutput, frameOutput] : photoOutput != null ? [photoOutput] : []),
    [photoOutput, frameOutput],
  );

  /* D1 — the sensor only hears the detent when IT is the mechanism. Under
     the photo-processing fallback the exposure stays neutral (0), so the
     wash and the JPEG pipeline own the whole adjustment — never both. */
  const exposureProp = mechanism === 'native-exposure' ? exposureCompensation : 0;

  const CameraView = ui?.Camera;

  if (CameraView != null && device === undefined) {
    return (
      <View style={styles.frame}>
        <ActivityIndicator color={mediaColors.textMuted} />
      </View>
    );
  }

  return (
    <GestureDetector gesture={gestures}>
      <View style={styles.frame} collapsable={false}>
        {CameraView != null && photoOutput != null && (
          <CameraView
            style={StyleSheet.absoluteFill}
            device={device}
            isActive
            outputs={outputs}
            zoom={liveZoomProp(zoomX)}
            exposure={exposureProp}
            torchMode={torchOn ? 'on' : 'off'}
            mirrorMode="auto"
            resizeMode="cover"
            onPreviewStarted={onCameraReady}
            onError={(error: { message?: string }) => {
              const message = error?.message ?? 'The camera could not be started.';
              AppLogger.error(`[Camera] mount error — ${message}`);
              onMountError(message);
            }}
          />
        )}
        {look.opacity > 0 && (
          <View
            style={[
              StyleSheet.absoluteFill,
              { backgroundColor: look.colorHex, opacity: look.opacity },
            ]}
            pointerEvents="none"
          />
        )}
        {wash.mode !== 'none' && (
          <View
            style={[
              StyleSheet.absoluteFill,
              {
                backgroundColor:
                  wash.mode === 'lighten' ? mediaColors.text : mediaColors.viewfinder,
                opacity: wash.opacity,
              },
            ]}
            pointerEvents="none"
          />
        )}
      </View>
    </GestureDetector>
  );
}

/** zoom is read at render from the same clamped multiplier the labels use. */
function liveZoomProp(zoomX: number): number {
  return zoomX;
}

const styles = StyleSheet.create({
  frame: {
    flex: 1,
    backgroundColor: mediaColors.viewfinder,
  },
});
