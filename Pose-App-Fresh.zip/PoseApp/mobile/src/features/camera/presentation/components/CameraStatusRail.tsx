/**
 * Camera UX Part 2 — THE STATUS RAIL.
 *
 * WHAT IT REPLACES AND WHY
 *
 * Part 1 fixed *what* the camera screen is allowed to say. It did not fix how
 * many separate pieces of glass it says it through. Before this file the top
 * of the viewfinder carried FOUR independently positioned floating surfaces,
 * each with a hand-computed absolute `top`:
 *
 *   · a zoom pill that permanently announced "1.0x" (a non-event),
 *   · a centred match pill ("Match 78%"),
 *   · a left-aligned voice chip ("Voice on"),
 *   · the pinned reference thumbnail on the right.
 *
 * Three of those are the same thought — *how is this going right now?* — and
 * they were competing for the same glance, in three different places, over
 * the user's own face. The rail merges them into ONE surface with an explicit
 * internal hierarchy:
 *
 *   1. the readiness word            (primary — read in peripheral vision)
 *   2. the match number              (supporting — emphasis decided upstream)
 *   3. the voice state               (ambient — and now also a control)
 *   4. a hairline progress track     (pre-attentive — no reading required)
 *
 * It computes NOTHING. Readiness, emphasis and voice mode all arrive already
 * decided by `resolveCameraPresentation`; the copy arrives already localized
 * by `cameraStatusCopyFor`. The only thing this component owns is motion.
 *
 * The voice element is the one interactive part: muting the coach is the most
 * common thing a user wants to do mid-shoot and it used to require leaving
 * the camera for Settings. It writes to the existing `voiceEnabled`
 * preference — the same single source of truth Settings writes to — and
 * introduces no second speech-state system.
 */
import React, { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import {
  matchColorFor,
  mediaColors,
  motionDuration,
  radius,
  sizing,
  spacing,
  type CameraReadiness,
  type MatchEmphasis,
  type RailEmphasis,
  type VoiceIndicatorMode,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PressableScale } from '@/shared/components/PressableScale';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface CameraStatusRailProps {
  readonly top: number;
  readonly readiness: CameraReadiness;
  readonly matchPercent: number | null;
  readonly matchEmphasis: MatchEmphasis;
  readonly voiceMode: VoiceIndicatorMode;
  /**
   * Camera UX Part 3 — how much weight this surface may claim right now.
   * Decided upstream by `resolveCameraPresentation`; the rail only obeys it.
   */
  readonly emphasis: RailEmphasis;
  readonly maxWidth: number;
  /** Localized labels — never assembled here. */
  readonly labels: {
    readonly readiness: string;
    readonly match: string;
    readonly voiceSpeaking: string;
    readonly voiceIdle: string;
    readonly voiceMuted: string;
  };
  /** Toggles the existing `voiceEnabled` preference. */
  readonly onToggleVoice: () => void;
}

export function CameraStatusRail({
  top,
  readiness,
  matchPercent,
  matchEmphasis,
  voiceMode,
  emphasis,
  maxWidth,
  labels,
  onToggleVoice,
}: CameraStatusRailProps) {
  const theme = useAppTheme();
  const reduceMotion = useReducedMotion();
  const fill = useSharedValue(0);

  const trackable = matchEmphasis !== 'hidden' && matchPercent !== null;
  const target = trackable ? Math.max(0, Math.min(100, matchPercent)) : 0;

  useEffect(() => {
    fill.value = reduceMotion
      ? target
      : withTiming(target, { duration: motionDuration.standard });
  }, [target, reduceMotion, fill]);

  const fillStyle = useAnimatedStyle(() => ({ width: `${fill.value}%` }));

  /**
   * Camera UX Part 3 — THE RAIL KNOWS WHEN TO GET OUT OF THE WAY.
   *
   * Part 2 gave the top of the frame one surface instead of four. It still
   * rendered that surface at full contrast for the whole session, including
   * the long stretches where it says "Checking" and nothing else — a
   * permanent bright slab over the user's face for no information. The rail
   * now recedes while the state is merely being observed and comes forward
   * when it is being acted on. No state is hidden, nothing is re-worded, and
   * the presence/absence decision still belongs entirely to the resolver.
   */
  const presence = useSharedValue(emphasis === 'active' ? 1 : 0);
  useEffect(() => {
    const target = emphasis === 'active' ? 1 : 0;
    presence.value = reduceMotion
      ? target
      : withTiming(target, { duration: motionDuration.standard });
  }, [emphasis, reduceMotion, presence]);

  const presenceStyle = useAnimatedStyle(() => ({
    opacity: 0.72 + presence.value * 0.28,
    transform: [{ scale: 0.98 + presence.value * 0.02 }],
  }));

  /**
   * Camera UX Part 3 — VOICE IS A HEARTBEAT, NOT A DASHBOARD.
   *
   * "Is the coach talking?" deserves exactly one ambient signal. A slow
   * breath on the icon while speech is in flight answers it in peripheral
   * vision; silence is the absence of the breath. No text, no second badge,
   * no status row — and it is still the same one tap to mute.
   */
  const pulse = useSharedValue(0);
  const speakingNow = voiceMode === 'speaking';
  useEffect(() => {
    cancelAnimation(pulse);
    if (!speakingNow || reduceMotion) {
      pulse.value = withTiming(speakingNow ? 1 : 0, {
        duration: motionDuration.tap,
      });
      return;
    }
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 460 }),
        withTiming(0.2, { duration: 460 }),
      ),
      -1,
      false,
    );
  }, [speakingNow, reduceMotion, pulse]);

  const voicePulseStyle = useAnimatedStyle(() => ({
    opacity: pulse.value * 0.35,
    transform: [{ scale: 0.72 + pulse.value * 0.28 }],
  }));

  /* The dot and the track share ONE colour source. While the engine is not
     judging a body there is no band colour to borrow, so the rail stays
     neutral rather than inventing a red 0 %. */
  const accent =
    readiness === 'ready'
      ? theme.colors.success
      : trackable
        ? matchColorFor(target)
        : mediaColors.textSubtle;

  const speaking = voiceMode === 'speaking';
  const muted = voiceMode === 'muted';
  const voiceLabel = speaking
    ? labels.voiceSpeaking
    : muted
      ? labels.voiceMuted
      : labels.voiceIdle;

  return (
    <View style={[styles.anchor, { top }]} pointerEvents="box-none">
      <Animated.View style={[styles.rail, presenceStyle, { maxWidth }]}>
        <View style={styles.row}>
          <View style={[styles.dot, { backgroundColor: accent }]} />
          <AppText
            variant="body"
            color={mediaColors.text}
            style={styles.readiness}
            numberOfLines={1}
            accessibilityLiveRegion="polite"
            accessibilityLabel={labels.readiness}
          >
            {labels.readiness}
          </AppText>

          {matchEmphasis !== 'hidden' && matchPercent !== null && (
            <AppText
              variant={matchEmphasis === 'primary' ? 'body' : 'small'}
              color={
                matchEmphasis === 'primary'
                  ? mediaColors.text
                  : mediaColors.textSubtle
              }
              style={styles.match}
              numberOfLines={1}
              accessibilityLabel={labels.match}
            >
              {labels.match}
            </AppText>
          )}

          {voiceMode !== 'hidden' && (
            <PressableScale
              onPress={onToggleVoice}
              hitSlop={spacing.sm}
              accessibilityRole="switch"
              accessibilityLabel={voiceLabel}
              accessibilityState={{ checked: !muted }}
              accessibilityHint="Turns the spoken coach on or off"
              style={styles.voiceButton}
            >
              <Animated.View
                pointerEvents="none"
                style={[
                  styles.voicePulse,
                  voicePulseStyle,
                  { backgroundColor: mediaColors.text },
                ]}
              />
              <IconSymbol
                name={muted ? 'volume-off' : speaking ? 'volume-high' : 'volume-medium'}
                size={sizing.iconSmall + spacing.xs}
                color={speaking ? mediaColors.text : mediaColors.textSubtle}
              />
            </PressableScale>
          )}
        </View>

        {/* Pre-attentive progress: understood without reading, and the only
            place the percentage is allowed to be a shape instead of a word. */}
        <View style={styles.track}>
          <Animated.View
            style={[styles.fill, fillStyle, { backgroundColor: accent }]}
          />
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  anchor: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    alignItems: 'center',
    zIndex: 30,
  },
  rail: {
    minHeight: sizing.touchTarget,
    justifyContent: 'center',
    gap: spacing.xs,
    paddingLeft: spacing.md,
    paddingRight: spacing.sm,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: mediaColors.whiteSoft,
    backgroundColor: mediaColors.overlayStrong,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  dot: {
    width: spacing.sm,
    height: spacing.sm,
    borderRadius: radius.circle,
  },
  readiness: {
    fontWeight: '600',
    flexShrink: 1,
  },
  match: {
    fontWeight: '600',
    fontVariant: ['tabular-nums'],
  },
  voiceButton: {
    width: sizing.iconFeature,
    height: sizing.iconFeature,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.circle,
  },
  voicePulse: {
    position: 'absolute',
    width: sizing.iconFeature,
    height: sizing.iconFeature,
    borderRadius: radius.circle,
  },
  track: {
    height: 2,
    marginHorizontal: spacing.xs,
    borderRadius: radius.pill,
    overflow: 'hidden',
    backgroundColor: mediaColors.whiteSoft,
  },
  fill: {
    height: '100%',
    borderRadius: radius.pill,
  },
});
