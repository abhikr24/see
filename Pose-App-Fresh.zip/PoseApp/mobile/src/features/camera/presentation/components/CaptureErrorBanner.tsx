/**
 * Camera UX Part 1 — CaptureErrorBanner.
 *
 * THE PROBLEM IT FIXES (structural, not cosmetic)
 *
 * A failed shutter used to call `setMountError(...)`, and `mountError` is the
 * gate that replaces the ENTIRE screen with the full-page "Camera unavailable"
 * retry widget. So one transient `takePictureAsync` rejection — a busy
 * encoder, a momentary storage error, an interrupted save — tore down the
 * live viewfinder, disposed the MediaPipe session, and dropped the user out
 * of their shoot. Recovery cost a full camera + model restart.
 *
 * A capture failure is NOT a camera-mount failure. It is recoverable in
 * place: the viewfinder is still running, the pose session is still valid,
 * and the correct affordance is "try that again" — not a new screen.
 *
 * This banner therefore owns the bottom strip (the coaching band and filter
 * strip yield to it, per the presentation resolver), is dismissible, and is
 * announced assertively because the user believes they already took a photo.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { mediaColors, radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PressableScale } from '@/shared/components/PressableScale';

interface CaptureErrorBannerProps {
  readonly title: string;
  readonly message: string;
  readonly retryLabel: string;
  readonly dismissLabel: string;
  readonly onRetry: () => void;
  readonly onDismiss: () => void;
  readonly bottom: number;
}

export function CaptureErrorBanner({
  title,
  message,
  retryLabel,
  dismissLabel,
  onRetry,
  onDismiss,
  bottom,
}: CaptureErrorBannerProps) {
  const theme = useAppTheme();
  return (
    <View
      style={[styles.anchor, { bottom }]}
      accessibilityLiveRegion="assertive"
      accessibilityLabel={`${title}. ${message}`}
    >
      <View style={[styles.card, { borderColor: theme.colors.error }]}>
        <View style={styles.headerRow}>
          <IconSymbol name="alert-circle-outline" size={20} color={theme.colors.error} />
          <AppText variant="body" color={mediaColors.text} style={styles.title}>
            {title}
          </AppText>
        </View>
        <AppText variant="small" color={mediaColors.textMuted} style={styles.message}>
          {message}
        </AppText>
        <View style={styles.actions}>
          <PressableScale
            onPress={onRetry}
            accessibilityRole="button"
            accessibilityLabel={retryLabel}
            style={[styles.action, { backgroundColor: theme.colors.primary }]}
          >
            <AppText variant="small" color={mediaColors.text} style={styles.actionLabel}>
              {retryLabel}
            </AppText>
          </PressableScale>
          <PressableScale
            onPress={onDismiss}
            accessibilityRole="button"
            accessibilityLabel={dismissLabel}
            style={[styles.action, styles.actionGhost]}
          >
            <AppText variant="small" color={mediaColors.textMuted} style={styles.actionLabel}>
              {dismissLabel}
            </AppText>
          </PressableScale>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  anchor: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    alignItems: 'center',
    zIndex: 45,
  },
  card: {
    width: '100%',
    maxWidth: 360,
    borderWidth: 1,
    borderRadius: radius.xl,
    backgroundColor: mediaColors.overlayHeavy,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    gap: spacing.xs,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  title: {
    fontWeight: '600',
    flexShrink: 1,
  },
  message: {
    marginBottom: spacing.xs,
  },
  actions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  action: {
    minHeight: sizing.touchTarget,
    minWidth: 112,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionGhost: {
    backgroundColor: mediaColors.whiteSoft,
  },
  actionLabel: {
    fontWeight: '700',
  },
});
