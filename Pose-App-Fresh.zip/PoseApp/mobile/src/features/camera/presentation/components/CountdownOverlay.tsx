/**
 * Unit 13 — full-screen capture countdown.
 *
 * Camera UX Part 3: A COUNTDOWN IS A PROMISE WITH A SHAPE.
 *
 * The number alone tells the user how long is left only if they read it. A
 * ring that empties once per second is understood without reading, from the
 * corner of an eye, while the user is looking at their own body and holding
 * still — which is exactly what they are doing during these three seconds.
 * The ring is drawn in the SAME Skia vocabulary as the shutter ring, so the
 * two never look like two different products, and it is deliberately stepped
 * (one segment per remaining second) rather than sweeping: a smooth sweep
 * invites the user to guess the fraction, a step tells them the truth.
 * One cancellable timer per displayed number, light haptic per tick, and a
 * reduced-motion-safe 1.0 → 1.2 → 1.0 pulse. Heavy capture feedback belongs
 * to cameraService.takePicture(), immediately after the shutter succeeds.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { Canvas, Path, Skia } from '@shopify/react-native-skia';
import * as Haptics from 'expo-haptics';
import { mediaColors, radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { AppText } from '@/shared/components/AppText';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface CountdownOverlayProps {
  readonly seconds: 3 | 5 | 10;
  readonly onComplete: () => void;
  readonly label?: string;
}

/* Skia paint mode bound as a const — the purity gate reads a JSX `style="…"`
   string as DOM styling, and this is a Skia paint mode. */
const PAINT_STROKE = 'stroke' as const;

const DIAL_DIAMETER = sizing.countdownNumber + 64;
const DIAL_STROKE = 5;

export function CountdownOverlay({ seconds, onComplete, label }: CountdownOverlayProps) {
  const theme = useAppTheme();
  const [remaining, setRemaining] = useState<number>(seconds);
  const complete = useRef(onComplete);
  const scale = useSharedValue(1);
  const reduceMotion = useReducedMotion();

  const dialPath = useMemo(() => {
    const path = Skia.Path.Make();
    const inset = DIAL_STROKE / 2;
    path.addArc(
      {
        x: inset,
        y: inset,
        width: DIAL_DIAMETER - DIAL_STROKE,
        height: DIAL_DIAMETER - DIAL_STROKE,
      },
      -90,
      360,
    );
    return path;
  }, []);

  useEffect(() => {
    complete.current = onComplete;
  }, [onComplete]);

  useEffect(() => {
    setRemaining(seconds);
  }, [seconds]);

  useEffect(() => {
    if (!reduceMotion) {
      scale.value = withSequence(
        withTiming(1.2, { duration: 180 }),
        withTiming(1, { duration: 320 }),
      );
    }
    /* Camera UX Part 2 — the last tick is heavier than the others. A flat
       sequence of identical taps carries no deadline; escalating on the final
       second is how the user knows to stop breathing without looking. */
    void Haptics.impactAsync(
      remaining <= 1
        ? Haptics.ImpactFeedbackStyle.Medium
        : Haptics.ImpactFeedbackStyle.Light,
    ).catch((error) => {
      AppLogger.warn(`[Capture] countdown haptic unavailable — ${String(error)}`);
    });

    const timer = setTimeout(() => {
      if (remaining <= 1) complete.current();
      else setRemaining((value) => value - 1);
    }, 1_000);

    return () => clearTimeout(timer);
  }, [remaining, reduceMotion, scale]);

  const animatedNumber = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <View
      style={styles.overlay}
      accessibilityViewIsModal
      /* Camera UX Part 1: the number changed silently for screen readers —
         a blind user got no countdown at all. Each tick is now announced. */
      accessibilityLiveRegion="assertive"
      accessibilityLabel={
        label === undefined
          ? `Photo in ${remaining}`
          : `${label}. Photo in ${remaining}`
      }
    >
      <View style={styles.dial}>
        <Canvas style={styles.dialCanvas} pointerEvents="none">
          <Path
            path={dialPath}
            color={mediaColors.whiteSoft}
            style={PAINT_STROKE}
            strokeWidth={DIAL_STROKE}
            strokeCap="round"
          />
          <Path
            path={dialPath}
            color={theme.colors.success}
            style={PAINT_STROKE}
            strokeWidth={DIAL_STROKE}
            strokeCap="round"
            start={0}
            end={Math.max(0, Math.min(1, remaining / seconds))}
          />
        </Canvas>
        <Animated.View style={animatedNumber}>
          <AppText color={mediaColors.text} style={styles.number}>
            {remaining}
          </AppText>
        </Animated.View>
      </View>
      {label !== undefined && (
        <AppText variant="body" color={mediaColors.textMuted} style={styles.label}>
          {label}
        </AppText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    zIndex: 100,
    /* Camera UX Part 2 — A COUNTDOWN MUST NOT HIDE THE POSE.
       This was the spec's 60 % capture scrim, which is correct for the
       post-shutter write (nothing to look at) and wrong for the countdown:
       these are the three seconds in which the user is actively holding the
       pose and needs to see themselves. The veil drops to 35 % and the
       numeral carries its own shadow so it stays legible against a bright
       frame without blacking the subject out. */
    backgroundColor: mediaColors.overlayMedium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dial: {
    width: DIAL_DIAMETER,
    height: DIAL_DIAMETER,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.circle,
  },
  dialCanvas: {
    position: 'absolute',
    width: DIAL_DIAMETER,
    height: DIAL_DIAMETER,
  },
  number: {
    fontSize: sizing.countdownNumber,
    lineHeight: sizing.countdownNumber + 8,
    fontFamily: 'Inter_700Bold',
    textAlign: 'center',
    textShadowColor: mediaColors.overlayHeavy,
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 18,
  },
  label: {
    marginTop: spacing.sm,
    fontWeight: '600',
    textShadowColor: mediaColors.overlayHeavy,
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 8,
  },
});
