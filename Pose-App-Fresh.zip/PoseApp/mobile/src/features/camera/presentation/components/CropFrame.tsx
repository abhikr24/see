/**
 * POST-CAPTURE EDITING — the crop interaction.
 *
 * DESIGN RULE: a crop must be understandable in one second by someone who has
 * never used this app. So it is the interaction everyone already knows — four
 * corner handles, drag inside to move, thirds guides inside the box, the
 * discarded area dimmed — and nothing else. No rotation gesture inside the
 * crop box, no pinch-zoom of the canvas, no magnifier loupe: each of those is
 * a whole feature with its own failure modes, and none of them is needed to
 * straighten a loose frame.
 *
 * WHY PanResponder AND NOT A GESTURE LIBRARY
 *
 * `react-native-gesture-handler` is in the dependency set, but its callbacks
 * run on the UI thread through Reanimated worklets, which would mean crop
 * state living in shared values and being marshalled back with `runOnJS` on
 * every frame. The crop rectangle is four numbers updated at thumb speed —
 * React Native's own PanResponder handles that on the JS thread with no
 * worklet boundary, no extra dependency surface and no Reanimated version
 * coupling. If this ever needs 120 Hz it can be migrated behind the same
 * props, because the maths does not live here.
 *
 * ALL geometry lives in `shared/camera/photoEditing.applyCropGesture` — this
 * file converts pixels to fractions and paints. That is why a locked aspect
 * ratio cannot be broken by a drag: the constraint is enforced in one tested
 * function rather than in four copies of corner-specific arithmetic.
 */
import React, { useMemo, useRef } from 'react';
import { PanResponder, StyleSheet, View } from 'react-native';
import {
  CROP_HANDLES,
  applyCropGesture,
  clampNormalizedRect,
  mediaColors,
  radius,
  type CropHandle,
  type NormalizedRect,
} from '@shared/index';

export interface CropFrameProps {
  /** The image's on-screen rectangle inside the editor's preview area. */
  readonly left: number;
  readonly top: number;
  readonly width: number;
  readonly height: number;
  readonly crop: NormalizedRect;
  /** Locked ratio in IMAGE pixels, or null for free-form. */
  readonly aspect: number | null;
  /** rotatedWidth / rotatedHeight of the photo being cropped. */
  readonly frameAspect: number;
  readonly onChange: (rect: NormalizedRect) => void;
  readonly disabled?: boolean;
}

const HANDLE_SIZE = 44;
const HANDLE_BAR = 3;
const HANDLE_ARM = 22;

export function CropFrame({
  left,
  top,
  width,
  height,
  crop,
  aspect,
  frameAspect,
  onChange,
  disabled = false,
}: CropFrameProps) {
  const box = clampNormalizedRect(crop);
  /* The rect the current gesture started from. Without this the drag would
     integrate its own rounded output and slowly drift away from the thumb. */
  const gestureStart = useRef<NormalizedRect>(box);
  const latest = useRef<NormalizedRect>(box);
  latest.current = box;

  const makeResponder = useMemo(
    () =>
      (handle: CropHandle) =>
        PanResponder.create({
          onStartShouldSetPanResponder: () => !disabled,
          onMoveShouldSetPanResponder: () => !disabled,
          onPanResponderGrant: () => {
            gestureStart.current = latest.current;
          },
          onPanResponderMove: (_event, state) => {
            if (disabled || width <= 0 || height <= 0) return;
            onChange(
              applyCropGesture(
                gestureStart.current,
                handle,
                state.dx / width,
                state.dy / height,
                aspect,
                frameAspect,
              ),
            );
          },
          onPanResponderTerminationRequest: () => false,
        }),
    [aspect, disabled, frameAspect, height, onChange, width],
  );

  const responders = useMemo(
    () => ({
      move: makeResponder('move'),
      topLeft: makeResponder('topLeft'),
      topRight: makeResponder('topRight'),
      bottomLeft: makeResponder('bottomLeft'),
      bottomRight: makeResponder('bottomRight'),
    }),
    [makeResponder],
  );

  const boxLeft = left + box.x * width;
  const boxTop = top + box.y * height;
  const boxWidth = box.width * width;
  const boxHeight = box.height * height;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      {/* Discarded area, dimmed in four strips rather than one cut-out mask:
          a mask would need a second renderer, and four Views are free. */}
      <View
        pointerEvents="none"
        style={[styles.shade, { left, top, width, height: boxTop - top }]}
      />
      <View
        pointerEvents="none"
        style={[
          styles.shade,
          { left, top: boxTop + boxHeight, width, height: top + height - (boxTop + boxHeight) },
        ]}
      />
      <View
        pointerEvents="none"
        style={[styles.shade, { left, top: boxTop, width: boxLeft - left, height: boxHeight }]}
      />
      <View
        pointerEvents="none"
        style={[
          styles.shade,
          {
            left: boxLeft + boxWidth,
            top: boxTop,
            width: left + width - (boxLeft + boxWidth),
            height: boxHeight,
          },
        ]}
      />

      <View
        {...responders.move.panHandlers}
        accessible
        accessibilityRole="adjustable"
        accessibilityLabel="Crop area. Drag to reposition, drag a corner to resize."
        style={[styles.box, { left: boxLeft, top: boxTop, width: boxWidth, height: boxHeight }]}
      >
        {/* Thirds guides: the same rule-of-thirds the viewfinder draws, so a
            recompose after the fact is judged against the same lines. */}
        <View pointerEvents="none" style={[styles.guideV, { left: boxWidth / 3 }]} />
        <View pointerEvents="none" style={[styles.guideV, { left: (boxWidth * 2) / 3 }]} />
        <View pointerEvents="none" style={[styles.guideH, { top: boxHeight / 3 }]} />
        <View pointerEvents="none" style={[styles.guideH, { top: (boxHeight * 2) / 3 }]} />
      </View>

      {CROP_HANDLES.map((handle) => {
        const isLeft = handle === 'topLeft' || handle === 'bottomLeft';
        const isTop = handle === 'topLeft' || handle === 'topRight';
        return (
          <View
            key={handle}
            {...responders[handle].panHandlers}
            accessible
            accessibilityRole="adjustable"
            accessibilityLabel={`Resize crop from the ${isTop ? 'top' : 'bottom'} ${
              isLeft ? 'left' : 'right'
            } corner`}
            style={[
              styles.handle,
              {
                left: (isLeft ? boxLeft : boxLeft + boxWidth) - HANDLE_SIZE / 2,
                top: (isTop ? boxTop : boxTop + boxHeight) - HANDLE_SIZE / 2,
              },
            ]}
          >
            <View
              pointerEvents="none"
              style={[
                styles.arm,
                styles.armH,
                isLeft ? styles.armLeft : styles.armRight,
                isTop ? styles.armTop : styles.armBottom,
              ]}
            />
            <View
              pointerEvents="none"
              style={[
                styles.arm,
                styles.armV,
                isLeft ? styles.armLeft : styles.armRight,
                isTop ? styles.armTop : styles.armBottom,
              ]}
            />
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  shade: {
    position: 'absolute',
    backgroundColor: mediaColors.overlayStrong,
  },
  box: {
    position: 'absolute',
    borderWidth: 1,
    borderColor: mediaColors.ringLight,
    borderRadius: radius.xs,
  },
  guideV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: StyleSheet.hairlineWidth,
    backgroundColor: mediaColors.whiteMuted,
  },
  guideH: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: StyleSheet.hairlineWidth,
    backgroundColor: mediaColors.whiteMuted,
  },
  handle: {
    position: 'absolute',
    width: HANDLE_SIZE,
    height: HANDLE_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  arm: {
    position: 'absolute',
    backgroundColor: mediaColors.text,
  },
  armH: {
    width: HANDLE_ARM,
    height: HANDLE_BAR,
  },
  armV: {
    width: HANDLE_BAR,
    height: HANDLE_ARM,
  },
  armLeft: {
    left: HANDLE_SIZE / 2 - HANDLE_BAR,
  },
  armRight: {
    right: HANDLE_SIZE / 2 - HANDLE_BAR,
  },
  armTop: {
    top: HANDLE_SIZE / 2 - HANDLE_BAR,
  },
  armBottom: {
    bottom: HANDLE_SIZE / 2 - HANDLE_BAR,
  },
});
