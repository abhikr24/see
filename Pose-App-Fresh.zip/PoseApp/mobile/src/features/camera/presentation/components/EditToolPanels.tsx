/**
 * POST-CAPTURE EDITING — the three tool panels.
 *
 * One file because the three panels are one control surface: they share the
 * chip, the row and the reset affordance, and splitting them would mean three
 * copies of the same 40 lines of styling drifting apart. Each is a pure,
 * stateless view over `shared/camera/photoEditing` values — none of them owns
 * any state, and none of them knows that Skia exists.
 *
 *   CROP     ratio chips + reset. Free first, because free-form is the crop
 *            people actually mean; then the photo's own shape; then the four
 *            ratios worth having.
 *   ROTATE   left / right quarter turns + reset, with the current angle stated
 *            in words. Two buttons, because a rotation dial for 90° steps is
 *            a puzzle, not a control.
 *   ENHANCE  an Original ⇄ Enhanced switch, and under it the four sliders that
 *            the switch is a shortcut for. Tapping Enhanced literally moves
 *            the sliders — there is no hidden second engine.
 */
import React, { useCallback, useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import {
  AUTO_ENHANCE,
  CROP_ASPECT_IDS,
  ENHANCE_NEUTRAL,
  PHOTO_ADJUST_KEYS,
  PHOTO_EDIT_ADJUST_MAX,
  PHOTO_EDIT_ADJUST_MIN,
  PHOTO_EDIT_ADJUST_STEP,
  adjustBadge,
  adjustLabel,
  clampAdjustValue,
  cropAspectLabel,
  enhanceIsNeutral,
  isAutoEnhance,
  radius,
  rotationLabel,
  mediaColors,
  sizing,
  spacing,
  type CropAspectId,
  type PhotoAdjustKey,
  type PhotoEnhance,
} from '@shared/index';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

/* ───────────────────────────── shared pieces ──────────────────────────── */

function Chip({
  label,
  active,
  onPress,
  accessibilityLabel,
}: {
  readonly label: string;
  readonly active: boolean;
  readonly onPress: () => void;
  readonly accessibilityLabel: string;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      accessibilityLabel={accessibilityLabel}
      style={({ pressed }) => [
        styles.chip,
        {
          backgroundColor: active ? mediaColors.text : mediaColors.whiteSoft,
          opacity: pressed ? 0.75 : 1,
        },
      ]}
    >
      <AppText
        variant="small"
        color={active ? mediaColors.viewfinder : mediaColors.text}
      >
        {label}
      </AppText>
    </Pressable>
  );
}

function RoundAction({
  icon,
  label,
  onPress,
  disabled = false,
}: {
  readonly icon: string;
  readonly label: string;
  readonly onPress: () => void;
  readonly disabled?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled }}
      style={({ pressed }) => [
        styles.round,
        { opacity: disabled ? 0.35 : pressed ? 0.7 : 1 },
      ]}
    >
      <IconSymbol name={icon} size={sizing.iconDefault} color={mediaColors.text} />
    </Pressable>
  );
}

/* ─────────────────────────────── CROP ─────────────────────────────────── */

export function CropToolPanel({
  aspect,
  cropped,
  onSelectAspect,
  onReset,
}: {
  readonly aspect: CropAspectId;
  readonly cropped: boolean;
  readonly onSelectAspect: (id: CropAspectId) => void;
  readonly onReset: () => void;
}) {
  return (
    <View style={styles.panel}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipRow}
      >
        {CROP_ASPECT_IDS.map((id) => (
          <Chip
            key={id}
            label={cropAspectLabel(id)}
            active={aspect === id}
            onPress={() => onSelectAspect(id)}
            accessibilityLabel={`Crop ratio ${cropAspectLabel(id)}`}
          />
        ))}
      </ScrollView>
      <View style={styles.panelFooter}>
        <AppText variant="small" color={mediaColors.textSubtle}>
          Drag a corner to resize, drag inside to move
        </AppText>
        <Pressable
          onPress={onReset}
          disabled={!cropped}
          accessibilityRole="button"
          accessibilityLabel="Reset crop to the full frame"
          accessibilityState={{ disabled: !cropped }}
          style={({ pressed }) => [
            styles.textAction,
            { opacity: cropped ? (pressed ? 0.7 : 1) : 0.35 },
          ]}
        >
          <AppText variant="small" color={mediaColors.text}>
            Reset
          </AppText>
        </Pressable>
      </View>
    </View>
  );
}

/* ────────────────────────────── ROTATE ────────────────────────────────── */

export function RotateToolPanel({
  rotation,
  onRotate,
  onReset,
}: {
  readonly rotation: number;
  readonly onRotate: (direction: number) => void;
  readonly onReset: () => void;
}) {
  return (
    <View style={styles.panel}>
      <View style={styles.rotateRow}>
        <RoundAction
          icon="rotate-left"
          label="Rotate 90 degrees left"
          onPress={() => onRotate(-1)}
        />
        <View style={styles.rotateValue}>
          <AppText variant="secondaryBody" color={mediaColors.text}>
            {rotationLabel(rotation)}
          </AppText>
          <AppText variant="small" color={mediaColors.textSubtle}>
            Quarter turns only — no pixels are resampled
          </AppText>
        </View>
        <RoundAction
          icon="rotate-right"
          label="Rotate 90 degrees right"
          onPress={() => onRotate(1)}
        />
      </View>
      <View style={styles.panelFooter}>
        <View />
        <Pressable
          onPress={onReset}
          disabled={rotation === 0}
          accessibilityRole="button"
          accessibilityLabel="Reset rotation to upright"
          accessibilityState={{ disabled: rotation === 0 }}
          style={({ pressed }) => [
            styles.textAction,
            { opacity: rotation === 0 ? 0.35 : pressed ? 0.7 : 1 },
          ]}
        >
          <AppText variant="small" color={mediaColors.text}>
            Reset
          </AppText>
        </Pressable>
      </View>
    </View>
  );
}

/* ───────────────────────────── ENHANCE ────────────────────────────────── */

const SLIDER_WIDTH = 220;

function AdjustSlider({
  adjustKey,
  value,
  onChange,
}: {
  readonly adjustKey: PhotoAdjustKey;
  readonly value: number;
  readonly onChange: (key: PhotoAdjustKey, next: number) => void;
}) {
  const current = clampAdjustValue(value);
  const span = PHOTO_EDIT_ADJUST_MAX - PHOTO_EDIT_ADJUST_MIN;

  const setFromOffset = useCallback(
    (offsetX: number) => {
      const fraction = Math.max(0, Math.min(1, offsetX / SLIDER_WIDTH));
      onChange(adjustKey, clampAdjustValue(PHOTO_EDIT_ADJUST_MIN + fraction * span));
    },
    [adjustKey, onChange, span],
  );

  /* Same pattern as the camera's BrightnessControl: one gesture serves both a
     tap (single correction) and a drag (search), and it runs on JS so the
     value stays in plain React state. */
  const pan = useMemo(
    () =>
      Gesture.Pan()
        .minDistance(0)
        .onBegin((event) => setFromOffset(event.x))
        .onChange((event) => setFromOffset(event.x))
        .runOnJS(true),
    [setFromOffset],
  );

  const fillLeft =
    current >= 0 ? SLIDER_WIDTH / 2 : SLIDER_WIDTH / 2 + (current / span) * SLIDER_WIDTH;
  const fillWidth = (Math.abs(current) / span) * SLIDER_WIDTH;

  return (
    <View style={styles.sliderRow}>
      <AppText variant="small" color={mediaColors.textMuted} style={styles.sliderLabel}>
        {adjustLabel(adjustKey)}
      </AppText>

      <Pressable
        onPress={() => onChange(adjustKey, current - PHOTO_EDIT_ADJUST_STEP)}
        accessibilityRole="button"
        accessibilityLabel={`Decrease ${adjustLabel(adjustKey).toLowerCase()}`}
        style={styles.stepper}
      >
        <IconSymbol name="minus" size={sizing.iconSmall} color={mediaColors.text} />
      </Pressable>

      <GestureDetector gesture={pan}>
        <View
          accessible
          accessibilityRole="adjustable"
          accessibilityLabel={`${adjustLabel(adjustKey)} adjustment`}
          accessibilityValue={{
            min: PHOTO_EDIT_ADJUST_MIN,
            max: PHOTO_EDIT_ADJUST_MAX,
            now: current,
            text: adjustBadge(current),
          }}
          accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
          onAccessibilityAction={(event) => {
            const delta =
              event.nativeEvent.actionName === 'increment'
                ? PHOTO_EDIT_ADJUST_STEP
                : -PHOTO_EDIT_ADJUST_STEP;
            onChange(adjustKey, current + delta);
          }}
          style={styles.track}
        >
          <View pointerEvents="none" style={styles.trackBase} />
          <View pointerEvents="none" style={[styles.trackFill, { left: fillLeft, width: fillWidth }]} />
          <View pointerEvents="none" style={styles.trackCentre} />
        </View>
      </GestureDetector>

      <Pressable
        onPress={() => onChange(adjustKey, current + PHOTO_EDIT_ADJUST_STEP)}
        accessibilityRole="button"
        accessibilityLabel={`Increase ${adjustLabel(adjustKey).toLowerCase()}`}
        style={styles.stepper}
      >
        <IconSymbol name="plus" size={sizing.iconSmall} color={mediaColors.text} />
      </Pressable>

      <AppText variant="small" color={mediaColors.text} style={styles.sliderValue}>
        {adjustBadge(current)}
      </AppText>
    </View>
  );
}

export function EnhanceToolPanel({
  enhance,
  onChangeAdjust,
  onApplyPreset,
}: {
  readonly enhance: PhotoEnhance;
  readonly onChangeAdjust: (key: PhotoAdjustKey, next: number) => void;
  readonly onApplyPreset: (preset: PhotoEnhance) => void;
}) {
  const neutral = enhanceIsNeutral(enhance);
  const auto = isAutoEnhance(enhance);
  return (
    <View style={styles.panel}>
      <View style={styles.chipRow}>
        <Chip
          label="Original"
          active={neutral}
          onPress={() => onApplyPreset(ENHANCE_NEUTRAL)}
          accessibilityLabel="Show the photo with no enhancement"
        />
        <Chip
          label="Enhanced"
          active={auto}
          onPress={() => onApplyPreset(AUTO_ENHANCE)}
          accessibilityLabel="Apply the one-tap enhancement"
        />
        {!neutral && !auto && (
          <View style={styles.customTag}>
            <AppText variant="small" color={mediaColors.textSubtle}>
              Custom
            </AppText>
          </View>
        )}
      </View>
      {PHOTO_ADJUST_KEYS.map((key) => (
        <AdjustSlider
          key={key}
          adjustKey={key}
          value={enhance[key]}
          onChange={onChangeAdjust}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    gap: spacing.sm,
  },
  chipRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.xs,
  },
  chip: {
    minHeight: 36,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
  },
  customTag: {
    minHeight: 36,
    justifyContent: 'center',
    paddingHorizontal: spacing.sm,
  },
  panelFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  textAction: {
    minHeight: sizing.touchTarget,
    minWidth: 64,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  rotateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  rotateValue: {
    flex: 1,
    alignItems: 'center',
    gap: spacing.xs,
  },
  round: {
    width: sizing.touchTarget,
    height: sizing.touchTarget,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: mediaColors.whiteSoft,
  },
  sliderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  sliderLabel: {
    width: 74,
  },
  sliderValue: {
    width: 40,
    textAlign: 'right',
  },
  stepper: {
    width: 32,
    height: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
  track: {
    width: SLIDER_WIDTH,
    height: sizing.touchTarget,
    justifyContent: 'center',
  },
  trackBase: {
    height: 4,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.whiteSoft,
  },
  trackFill: {
    position: 'absolute',
    height: 4,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.text,
  },
  trackCentre: {
    position: 'absolute',
    left: SLIDER_WIDTH / 2 - 1,
    width: 2,
    height: 12,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.whiteMuted,
  },
});
