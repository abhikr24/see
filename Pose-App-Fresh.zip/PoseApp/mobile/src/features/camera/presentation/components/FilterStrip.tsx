/**
 * LOOKS — FilterStrip (rebuilt on the Unit 12 control, not replacing it).
 *
 * WHAT WAS HERE BEFORE, AND WHY IT CHANGED
 *
 * The original strip was five 60×60 dark squares, each with a flat accent bar
 * borrowed from an unrelated semantic token (`success` for Vivid, `warning`
 * for Warm, `textDisabled` for B&W) and the filter's name in 9 pt. It told the
 * user the NAME of a look and nothing about the look, it had no strength, and
 * — the real defect — the selection never reached a single pixel of the saved
 * photograph. The five looks are PRESERVED exactly (Original, Vivid, Warm,
 * Cool, B&W); what changed is that they are now visible, adjustable and real.
 *
 * THE CONTROL, IN FOUR RULES
 *
 *  1. A TILE SHOWS THE LOOK. Each swatch is that look's own colour matrix
 *     applied to a fixed neutral pair (`filterSwatchGradient`), so the strip
 *     is scannable at arm's length without reading a word. A live thumbnail of
 *     the user's actual scene is impossible here — expo-camera hands JS no
 *     preview frames — and inventing one would be the same lie this work
 *     exists to remove.
 *  2. ONE TAP SELECTS, A SECOND TAP ADJUSTS. Strength is not a permanent
 *     slider squatting on the viewfinder: re-tapping the active look opens a
 *     single track above the strip, and it auto-dismisses when idle. Original
 *     has no strength and never opens anything.
 *  3. THE ACTIVE TILE CARRIES THE STRENGTH. Its swatch fades toward the
 *     Original swatch as strength drops and it wears a "60%" badge, so the
 *     current amount is legible from the strip alone.
 *  4. IT NEVER OUT-SHOUTS THE COACHING. The strip is 74 pt of the bottom
 *     edge, the track replaces nothing and covers nothing above it, and the
 *     viewfinder wash it drives is capped so the pose silhouette, the arrows
 *     and the match state stay readable at every strength.
 *
 * HONESTY LINE. Under the strip: "Saved into your photo" — true, the look is
 * baked into the JPEG by `applyCaptureFraming`. Beside it, per look, either
 * "Preview is approximate" or "Shown after the shot". The choice is no longer
 * hand-written per look: since D2 it follows the MEASURED fidelity of the
 * matrix projection (`viewfinderFidelity`) — warm/cool measurably resemble
 * live ("approximate"), while B&W (no overlay can desaturate) and Vivid (its
 * cross-channel transform measured as unrepresentable — the old white veil
 * actually pointed the wrong way) declare they will be shown after the shot.
 */
import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import {
  CAMERA_FILTER_IDS,
  FILTER_INTENSITY_DEFAULT,
  FILTER_INTENSITY_MAX,
  FILTER_INTENSITY_MIN,
  FILTER_INTENSITY_STEP,
  clampFilterIntensity,
  filterStrength,
  filterSwatchGradient,
  filterIntensityBadge,
  filterSupportsIntensity,
  mediaColors,
  radius,
  sizing,
  spacing,
  type CameraFilterId,
  type CameraStatusCopy,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

/** Kept exported: existing callers imported the option list from here. */
export const CAMERA_FILTERS: readonly { readonly id: CameraFilterId }[] =
  CAMERA_FILTER_IDS.map((id) => ({ id }));

const TILE_WIDTH = 56;
const SWATCH_SIZE = 52;
const TRACK_WIDTH = 172;
const TRACK_HEIGHT = 28;
const STEPS = (FILTER_INTENSITY_MAX - FILTER_INTENSITY_MIN) / FILTER_INTENSITY_STEP;
const IDLE_DISMISS_MS = 4200;

/** Layout heights the camera screen stacks other chrome against. ONE source
    of truth: the shared sizing tokens, re-exported for existing callers. */
export const FILTER_STRIP_HEIGHT = sizing.cameraFilterStrip;
export const FILTER_STRENGTH_HEIGHT = sizing.cameraFilterStrength;

interface FilterStripProps {
  readonly active: CameraFilterId;
  readonly intensity: number;
  readonly strengthOpen: boolean;
  readonly copy: CameraStatusCopy;
  readonly onSelect: (filter: CameraFilterId) => void;
  readonly onIntensityChange: (intensity: number) => void;
  readonly onIntensityReset: () => void;
  readonly onStrengthOpenChange: (open: boolean) => void;
}

export function FilterStrip({
  active,
  intensity,
  strengthOpen,
  copy,
  onSelect,
  onIntensityChange,
  onIntensityReset,
  onStrengthOpenChange,
}: FilterStripProps) {
  const theme = useAppTheme();
  const value = clampFilterIntensity(intensity);
  const adjustable = filterSupportsIntensity(active);
  const open = strengthOpen && adjustable;
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const armIdleDismiss = useCallback(() => {
    if (idleTimer.current !== null) clearTimeout(idleTimer.current);
    idleTimer.current = setTimeout(() => onStrengthOpenChange(false), IDLE_DISMISS_MS);
  }, [onStrengthOpenChange]);

  useEffect(() => {
    if (!open) {
      if (idleTimer.current !== null) clearTimeout(idleTimer.current);
      return;
    }
    armIdleDismiss();
    return () => {
      if (idleTimer.current !== null) clearTimeout(idleTimer.current);
    };
  }, [open, value, armIdleDismiss]);

  const setFromOffset = useCallback(
    (offsetX: number) => {
      const ratio = Math.max(0, Math.min(1, offsetX / TRACK_WIDTH));
      const next = clampFilterIntensity(
        FILTER_INTENSITY_MIN + ratio * (FILTER_INTENSITY_MAX - FILTER_INTENSITY_MIN),
      );
      if (next !== value) onIntensityChange(next);
      armIdleDismiss();
    },
    [armIdleDismiss, onIntensityChange, value],
  );

  /* Tap AND drag on one gesture — a one-step correction must not require a
     drag, and sweeping from subtle to strong must not require ten taps. */
  const pan = useMemo(
    () =>
      Gesture.Pan()
        .minDistance(0)
        .onBegin((event) => setFromOffset(event.x))
        .onChange((event) => setFromOffset(event.x))
        .runOnJS(true),
    [setFromOffset],
  );

  const handlePress = (id: CameraFilterId) => {
    if (id !== active) {
      onSelect(id);
      /* Landing on a look immediately reveals the one thing the user might
         want next, then gets out of the way by itself. */
      onStrengthOpenChange(filterSupportsIntensity(id));
      return;
    }
    if (filterSupportsIntensity(id)) onStrengthOpenChange(!strengthOpen);
  };

  const previewNote = copy.filterPreviewNote(active);

  return (
    <View style={styles.wrap} pointerEvents="box-none">
      {open && (
        <View style={styles.strengthRow} pointerEvents="box-none">
          <View style={[styles.strengthCard, { backgroundColor: mediaColors.overlayStrong }]}>
            <AppText variant="small" color={mediaColors.text} style={styles.strengthLabel}>
              {copy.filterStrengthValue(value)}
            </AppText>
            <GestureDetector gesture={pan}>
              <View
                style={styles.track}
                accessible
                accessibilityRole="adjustable"
                accessibilityLabel={`${copy.filterName(active)} — ${copy.filterStrengthTitle}`}
                accessibilityValue={{
                  min: FILTER_INTENSITY_MIN,
                  max: FILTER_INTENSITY_MAX,
                  now: value,
                  text: copy.filterStrengthValue(value),
                }}
                accessibilityActions={[
                  { name: 'increment', label: copy.filterStronger },
                  { name: 'decrement', label: copy.filterSofter },
                  { name: 'activate', label: copy.filterReset },
                ]}
                onAccessibilityAction={(event) => {
                  const action = event.nativeEvent.actionName;
                  if (action === 'increment') {
                    onIntensityChange(clampFilterIntensity(value + FILTER_INTENSITY_STEP));
                  } else if (action === 'decrement') {
                    onIntensityChange(clampFilterIntensity(value - FILTER_INTENSITY_STEP));
                  } else if (action === 'activate') {
                    onIntensityReset();
                  }
                }}
              >
                <View style={[styles.trackBase, { backgroundColor: mediaColors.whiteSoft }]} />
                <View
                  style={[
                    styles.trackFill,
                    {
                      backgroundColor: theme.colors.primary,
                      width: Math.max(2, TRACK_WIDTH * filterStrength(value)),
                    },
                  ]}
                />
                <View style={styles.ticks} pointerEvents="none">
                  {Array.from({ length: STEPS + 1 }, (_, index) => (
                    <View
                      key={index}
                      style={[styles.tick, { backgroundColor: mediaColors.whiteMuted }]}
                    />
                  ))}
                </View>
                <View
                  style={[
                    styles.knob,
                    {
                      backgroundColor: mediaColors.text,
                      borderColor: theme.colors.primary,
                      left: Math.max(
                        0,
                        Math.min(TRACK_WIDTH - 16, TRACK_WIDTH * filterStrength(value) - 8),
                      ),
                    },
                  ]}
                />
              </View>
            </GestureDetector>
            <Pressable
              onPress={onIntensityReset}
              disabled={value === FILTER_INTENSITY_DEFAULT}
              accessibilityRole="button"
              accessibilityLabel={copy.filterReset}
              accessibilityState={{ disabled: value === FILTER_INTENSITY_DEFAULT }}
              style={styles.resetChip}
            >
              <AppText
                variant="small"
                color={
                  value === FILTER_INTENSITY_DEFAULT
                    ? mediaColors.textSubtle
                    : theme.colors.primary
                }
                style={styles.resetText}
              >
                {copy.filterReset}
              </AppText>
            </Pressable>
          </View>
        </View>
      )}

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.content}
        accessibilityLabel={copy.filterTitle}
      >
        {CAMERA_FILTER_IDS.map((id) => {
          const selected = id === active;
          const label = copy.filterName(id);
          const badge = selected ? filterIntensityBadge(id, value) : null;
          /* The active swatch dims toward "no look" as strength drops: the
             tile is a readout, not just a button. */
          const swatchOpacity =
            selected && filterSupportsIntensity(id)
              ? 0.4 + 0.6 * filterStrength(value)
              : 1;
          return (
            <Pressable
              key={id}
              onPress={() => handlePress(id)}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              accessibilityLabel={copy.filterSummary(id, selected ? value : FILTER_INTENSITY_DEFAULT)}
              accessibilityHint={
                selected && filterSupportsIntensity(id) ? copy.filterStrengthTitle : undefined
              }
              style={({ pressed }) => [styles.tile, { opacity: pressed ? 0.7 : 1 }]}
            >
              <View
                style={[
                  styles.swatchRing,
                  {
                    borderColor: selected ? theme.colors.primary : mediaColors.ringDark,
                    borderWidth: selected ? 2 : 1,
                  },
                ]}
              >
                <LinearGradient
                  colors={[...filterSwatchGradient[id]]}
                  start={START}
                  end={END}
                  style={[styles.swatch, { opacity: swatchOpacity }]}
                />
                {badge !== null && (
                  <View style={[styles.badge, { backgroundColor: mediaColors.overlayHeavy }]}>
                    <AppText variant="small" color={mediaColors.text} style={styles.badgeText}>
                      {badge}
                    </AppText>
                  </View>
                )}
                {selected && badge === null && (
                  <View style={[styles.check, { backgroundColor: theme.colors.primary }]}>
                    <IconSymbol name="check" size={10} color={mediaColors.text} />
                  </View>
                )}
              </View>
              <AppText
                variant="small"
                color={selected ? mediaColors.text : mediaColors.textSubtle}
                style={styles.label}
                numberOfLines={1}
              >
                {label}
              </AppText>
            </Pressable>
          );
        })}
      </ScrollView>

      {/* The two honesty lines. They cost one 9 pt row and they are the reason
          the rest of this control can be trusted. */}
      <View style={styles.noteRow} pointerEvents="none">
        <AppText variant="small" color={mediaColors.textSubtle} style={styles.noteText}>
          {previewNote === '' ? copy.filterNote : `${copy.filterNote} · ${previewNote}`}
        </AppText>
      </View>
    </View>
  );
}

const START = { x: 0, y: 0 } as const;
const END = { x: 1, y: 1 } as const;

const styles = StyleSheet.create({
  wrap: {
    width: '100%',
  },
  strengthRow: {
    alignItems: 'center',
    paddingBottom: spacing.xs,
  },
  strengthCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
  },
  strengthLabel: {
    fontSize: 10,
    fontWeight: '600',
    minWidth: 74,
  },
  track: {
    width: TRACK_WIDTH,
    height: TRACK_HEIGHT,
    justifyContent: 'center',
  },
  trackBase: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 4,
    borderRadius: radius.pill,
  },
  trackFill: {
    position: 'absolute',
    left: 0,
    height: 4,
    borderRadius: radius.pill,
  },
  ticks: {
    position: 'absolute',
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tick: {
    width: 1,
    height: 6,
    borderRadius: radius.xs,
  },
  knob: {
    position: 'absolute',
    width: 16,
    height: 16,
    borderRadius: radius.pill,
    borderWidth: 2,
  },
  resetChip: {
    paddingHorizontal: spacing.xs,
    paddingVertical: 2,
  },
  resetText: {
    fontSize: 10,
    fontWeight: '700',
  },
  content: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    alignItems: 'flex-end',
  },
  tile: {
    width: TILE_WIDTH,
    alignItems: 'center',
    gap: 3,
  },
  swatchRing: {
    width: SWATCH_SIZE,
    height: SWATCH_SIZE,
    borderRadius: radius.md,
    overflow: 'hidden',
    backgroundColor: mediaColors.overlayStrong,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  swatch: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  badge: {
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderTopLeftRadius: radius.xs,
    borderBottomRightRadius: radius.sm,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '700',
  },
  check: {
    width: 16,
    height: 16,
    borderTopLeftRadius: radius.xs,
    borderBottomRightRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontSize: 9,
    fontWeight: '600',
  },
  noteRow: {
    alignItems: 'center',
    paddingTop: 2,
  },
  noteText: {
    fontSize: 9,
  },
});
