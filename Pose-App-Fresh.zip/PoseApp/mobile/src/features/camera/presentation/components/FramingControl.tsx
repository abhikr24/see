/**
 * FRAMING — FramingControl.
 *
 * ONE sheet, three decisions, and it gets out of the way. Deliberately NOT a
 * settings dashboard: it is the stock-camera pattern — tap the crop glyph in
 * the top bar, a small card drops under it with
 *
 *   · PHOTO SHAPE  Full 4:3 · Square 1:1 · Wide 16:9 (one tap each, live), and
 *   · GRID and LEVEL as two quiet switches, because they belong to the same
 *     question ("how is this picture framed?") and nowhere else on the camera
 *     screen was there room for either without adding two more permanent
 *     glyphs to a bar that already has five.
 *
 * DISMISS is a tap anywhere off the card, the crop glyph again, or simply
 * leaving it alone for a few seconds — the same contract the brightness panel
 * already taught the user.
 *
 * HONESTY. The footnote says the shape reaches the saved photo, because it
 * does: the capture pipeline centre-crops the file to the chosen ratio. The
 * level switch reports itself unavailable when the device has no motion
 * sensor rather than offering a dead control.
 *
 * The grid switch writes to the SAME persisted setting as Settings → Grid
 * overlay. Two surfaces, one truth; changing it here changes it there.
 */
import React, { useCallback, useEffect, useRef } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import {
  ASPECT_RATIO_IDS,
  mediaColors,
  radius,
  spacing,
  type AspectRatioId,
  type CameraStatusCopy,
} from '@shared/index';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PressableScale } from '@/shared/components/PressableScale';
import { useAppTheme } from '@/core/theme';

const IDLE_DISMISS_MS = 4200;

interface FramingControlProps {
  readonly open: boolean;
  readonly copy: CameraStatusCopy;
  readonly topOffset: number;
  readonly ratio: AspectRatioId;
  readonly gridEnabled: boolean;
  readonly levelEnabled: boolean;
  /** False when the device reports no accelerometer. */
  readonly levelAvailable: boolean;
  readonly onSelectRatio: (ratio: AspectRatioId) => void;
  readonly onToggleGrid: () => void;
  readonly onToggleLevel: () => void;
  readonly onRequestClose: () => void;
}

export function FramingControl({
  open,
  copy,
  topOffset,
  ratio,
  gridEnabled,
  levelEnabled,
  levelAvailable,
  onSelectRatio,
  onToggleGrid,
  onToggleLevel,
  onRequestClose,
}: FramingControlProps) {
  const theme = useAppTheme();
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const armIdleDismiss = useCallback(() => {
    if (idleTimer.current !== null) clearTimeout(idleTimer.current);
    idleTimer.current = setTimeout(onRequestClose, IDLE_DISMISS_MS);
  }, [onRequestClose]);

  useEffect(() => {
    if (!open) {
      if (idleTimer.current !== null) clearTimeout(idleTimer.current);
      return;
    }
    armIdleDismiss();
    return () => {
      if (idleTimer.current !== null) clearTimeout(idleTimer.current);
    };
  }, [open, ratio, gridEnabled, levelEnabled, armIdleDismiss]);

  if (!open) return null;

  return (
    <>
      <Pressable
        style={StyleSheet.absoluteFill}
        accessibilityRole="button"
        accessibilityLabel={`${copy.framingTitle} — ${copy.captureDismiss}`}
        onPress={onRequestClose}
      />
      <View style={[styles.card, { top: topOffset }]}>
        <AppText variant="small" color={mediaColors.textSubtle} style={styles.section}>
          {copy.ratioTitle}
        </AppText>
        <View style={styles.ratioRow}>
          {ASPECT_RATIO_IDS.map((id) => {
            const selected = id === ratio;
            return (
              <PressableScale
                key={id}
                onPress={() => {
                  onSelectRatio(id);
                  armIdleDismiss();
                }}
                accessibilityRole="button"
                accessibilityLabel={`${copy.ratioValue(id)} ${copy.ratioBadge(id)}`}
                accessibilityState={{ selected }}
                style={[
                  styles.ratioChip,
                  {
                    borderColor: selected ? theme.colors.primary : mediaColors.whiteMuted,
                    backgroundColor: selected
                      ? mediaColors.whiteSoft
                      : mediaColors.transparent,
                  },
                ]}
              >
                <AppText
                  variant="small"
                  color={selected ? theme.colors.primary : mediaColors.text}
                  style={styles.ratioBadge}
                >
                  {copy.ratioBadge(id)}
                </AppText>
                <AppText variant="small" color={mediaColors.textSubtle} style={styles.ratioName}>
                  {copy.ratioValue(id)}
                </AppText>
              </PressableScale>
            );
          })}
        </View>
        <AppText variant="small" color={mediaColors.textSubtle} style={styles.note}>
          {copy.ratioNote}
        </AppText>

        <View style={styles.divider} />

        <ToggleRow
          icon="grid"
          label={copy.gridTitle}
          value={copy.onOff(gridEnabled)}
          on={gridEnabled}
          tint={theme.colors.primary}
          onPress={() => {
            onToggleGrid();
            armIdleDismiss();
          }}
        />
        <ToggleRow
          icon="angle-acute"
          label={copy.levelTitle}
          value={levelAvailable ? copy.onOff(levelEnabled) : copy.levelUnavailable}
          on={levelEnabled && levelAvailable}
          tint={theme.colors.primary}
          disabled={!levelAvailable}
          onPress={() => {
            onToggleLevel();
            armIdleDismiss();
          }}
        />
      </View>
    </>
  );
}

function ToggleRow({
  icon,
  label,
  value,
  on,
  tint,
  disabled,
  onPress,
}: {
  readonly icon: string;
  readonly label: string;
  readonly value: string;
  readonly on: boolean;
  readonly tint: string;
  readonly disabled?: boolean;
  readonly onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="switch"
      accessibilityLabel={label}
      accessibilityValue={{ text: value }}
      accessibilityState={{ checked: on, disabled: disabled === true }}
      style={styles.toggleRow}
    >
      <IconSymbol
        name={icon}
        size={18}
        color={disabled === true ? mediaColors.glyphDark : on ? tint : mediaColors.textMuted}
      />
      <AppText
        variant="small"
        color={disabled === true ? mediaColors.glyphDark : mediaColors.text}
        style={styles.toggleLabel}
      >
        {label}
      </AppText>
      <AppText
        variant="small"
        color={disabled === true ? mediaColors.glyphDark : on ? tint : mediaColors.textSubtle}
        style={styles.toggleValue}
      >
        {value}
      </AppText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    position: 'absolute',
    alignSelf: 'center',
    minWidth: 268,
    maxWidth: 320,
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: mediaColors.overlayHeavy,
  },
  section: {
    fontSize: 10,
    letterSpacing: 0.6,
    textTransform: 'uppercase',
    marginBottom: spacing.xs,
  },
  ratioRow: {
    flexDirection: 'row',
    gap: spacing.xs,
  },
  ratioChip: {
    flex: 1,
    paddingVertical: spacing.xs,
    borderRadius: radius.md,
    borderWidth: 1,
    alignItems: 'center',
  },
  ratioBadge: {
    fontWeight: '700',
  },
  ratioName: {
    fontSize: 10,
  },
  note: {
    marginTop: spacing.xs,
    fontSize: 10,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: mediaColors.whiteMuted,
    marginVertical: spacing.sm,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 44,
    gap: spacing.sm,
  },
  toggleLabel: {
    flex: 1,
    fontWeight: '600',
  },
  toggleValue: {
    fontSize: 11,
  },
});
