/**
 * Unit 20 — GridOverlay (rule-of-thirds), rebuilt for FRAMING.
 *
 * What changed and why:
 *
 *  · IT NOW FOLLOWS THE PHOTO, NOT THE SCREEN. The grid used to stripe the
 *    whole viewfinder, including the bands that a 1:1 or 16:9 shot throws
 *    away — so its thirds were the thirds of an image that was never saved.
 *    It is now drawn inside the aspect box, where the picture actually is.
 *  · IT IS QUIETER. Hairlines at the device's own smallest renderable width,
 *    at a low-alpha token, with NO intersection dots and no centre cross:
 *    this app already draws a body silhouette, a skeleton and directional
 *    arrows over the same pixels, and a loud grid competes with the coaching
 *    the user is actually meant to follow.
 *  · IT KNOWS WHEN TO LEAVE. Visibility is decided by
 *    `resolveFramingVisibility` in shared/ — during a hold, a countdown or a
 *    capture the grid is not rendered at all.
 */
import React from 'react';
import { StyleSheet, View, type ViewStyle } from 'react-native';
import { GRID_FRACTIONS, mediaColors } from '@shared/index';

interface GridOverlayProps {
  /** Top of the aspect box inside the viewfinder (0 for the native ratio). */
  readonly top?: number;
  /** Height of the aspect box; omitted means "the whole viewfinder". */
  readonly height?: number;
}

export function GridOverlay({ top = 0, height }: GridOverlayProps) {
  const box: ViewStyle =
    height === undefined || height <= 0
      ? { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }
      : { position: 'absolute', left: 0, right: 0, top, height };

  return (
    <View style={box} pointerEvents="none" accessibilityElementsHidden>
      {GRID_FRACTIONS.map((fraction) => (
        <View
          key={`v-${fraction}`}
          style={[
            styles.line,
            styles.vertical,
            { left: `${fraction * 100}%` },
          ]}
        />
      ))}
      {GRID_FRACTIONS.map((fraction) => (
        <View
          key={`h-${fraction}`}
          style={[
            styles.line,
            styles.horizontal,
            { top: `${fraction * 100}%` },
          ]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  line: {
    position: 'absolute',
    backgroundColor: mediaColors.whiteMuted,
  },
  vertical: {
    top: 0,
    bottom: 0,
    width: StyleSheet.hairlineWidth,
  },
  horizontal: {
    left: 0,
    right: 0,
    height: StyleSheet.hairlineWidth,
  },
});
