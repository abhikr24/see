/**
 * Unit 17 — GuidanceOverlay, rebuilt in Camera UX Part 1 as THE COACHING BAND.
 *
 * WHAT CHANGED AND WHY
 *
 * It used to render `GuidanceResult` — a presentation object that exists only
 * for CORRECTION and PERFECT decisions. Every other semantic state
 * (`evaluating`, and all seven `unavailable` reasons) arrived as `null`, so
 * the band silently unmounted. On screen that read as "the app stopped",
 * which is exactly the state the user most needs explained.
 *
 * It now renders `VisibleCoaching` (shared/coaching/visibleCoaching), which is
 * TOTAL over the semantic coaching state and authored in the user's coaching
 * language. One band, one message, five distinguishable tones:
 *
 *   ready      → you are there, hold                       (success)
 *   adjust     → small correction, engine severity 'minor'  (warning)
 *   attention  → large correction, engine severity 'major'  (error)
 *   searching  → the app cannot see/judge you yet           (neutral)
 *   blocked    → this pose has no usable reference          (neutral, muted)
 *
 * It still computes NOTHING: tone, direction and severity all arrive decided.
 * The arrow is drawn only when the message is about the user's BODY; a
 * "step into frame" message with a left-arrow would be a lie.
 */
import React, { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import {
  mediaColors,
  motionDuration,
  radius,
  sizing,
  spacing,
  type ArrowDirection,
  type CoachingEmphasis,
  type VisibleCoaching,
  type VisibleCoachingTone,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface GuidanceOverlayProps {
  /** The semantic message for this frame, already localized. */
  readonly status: VisibleCoaching | null;
  /** Engine arrow for body corrections; ignored for non-body messages. */
  readonly arrowDirection: ArrowDirection;
  readonly bottom: number;
  /**
   * Camera UX Part 3 — `compact` drops the supporting line.
   *
   * The detail sentence is genuinely useful while the user is still reading
   * the screen. It is noise at the two moments they are holding their body
   * still — locked in, or a hold already counting down — where a second line
   * arrives too late to act on and only makes the band taller over their own
   * image. Decided by the resolver, never here.
   */
  readonly emphasis: CoachingEmphasis;
}

function arrowIcon(direction: ArrowDirection): string | null {
  switch (direction) {
    case 'up':
      return 'arrow-up';
    case 'down':
      return 'arrow-down';
    case 'left':
      return 'arrow-left';
    case 'right':
      return 'arrow-right';
    default:
      return null;
  }
}

function iconFor(status: VisibleCoaching, arrowDirection: ArrowDirection): string {
  if (status.tone === 'ready') return 'check-circle';
  if (status.aboutBody) return arrowIcon(arrowDirection) ?? 'human-handsup';
  if (status.tone === 'blocked') return 'information-outline';
  return 'account-search-outline';
}

export function GuidanceOverlay({
  status,
  arrowDirection,
  bottom,
  emphasis,
}: GuidanceOverlayProps) {
  const theme = useAppTheme();
  const reduceMotion = useReducedMotion();
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.95);
  /* Part 3 — the band RISES into place. A cross-fade alone reads as a value
     being overwritten; a 6 pt rise reads as a new instruction arriving, which
     is what actually happened. Sub-glance, and disabled by reduced motion. */
  const lift = useSharedValue(0);
  const previousToken = useRef<string | null>(null);

  const token = status?.token ?? null;

  useEffect(() => {
    if (token === null) {
      opacity.value = withTiming(0, { duration: 180 });
      previousToken.current = null;
      return;
    }

    /* Change detection rides the SEMANTIC token, not the rendered phrase:
       a token is stable across a language switch and across two different
       states that happen to share wording. */
    const changed = previousToken.current !== token;
    previousToken.current = token;

    if (changed && !reduceMotion) {
      opacity.value = withSequence(
        withTiming(0.4, { duration: 80 }),
        withTiming(1, { duration: 180 }),
      );
      scale.value = withSequence(
        withTiming(0.96, { duration: 80 }),
        withTiming(1, { duration: 180 }),
      );
      lift.value = withSequence(
        withTiming(BAND_LIFT, { duration: 0 }),
        withTiming(0, { duration: motionDuration.standard }),
      );
    } else {
      opacity.value = withTiming(1, { duration: 180 });
      scale.value = withTiming(1, { duration: 180 });
      lift.value = withTiming(0, { duration: motionDuration.tap });
    }
  }, [token, reduceMotion, opacity, scale, lift]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }, { translateY: lift.value }],
  }));

  /* Camera UX Part 2 — THE ARROW MOVES THE WAY IT MEANS.
     A static chevron is a symbol the user must decode; a chevron that drifts
     two points in its own direction and settles is understood pre-verbally.
     The motion is tiny (4 pt), slow, and exists ONLY while the message is
     about the body AND the engine actually produced a direction — so a stale
     nudge can never outlive the instruction that justified it. */
  const nudge = useSharedValue(0);
  const bodyArrow =
    status !== null && status.aboutBody && arrowDirection !== 'none'
      ? arrowDirection
      : null;

  useEffect(() => {
    cancelAnimation(nudge);
    if (bodyArrow === null || reduceMotion) {
      nudge.value = withTiming(0, { duration: 120 });
      return;
    }
    nudge.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 520 }),
        withTiming(0, { duration: 520 }),
      ),
      -1,
      false,
    );
  }, [bodyArrow, reduceMotion, nudge]);

  const nudgeStyle = useAnimatedStyle(() => {
    const travel = nudge.value * NUDGE_TRAVEL;
    switch (bodyArrow) {
      case 'up':
        return { transform: [{ translateY: -travel }] };
      case 'down':
        return { transform: [{ translateY: travel }] };
      case 'left':
        return { transform: [{ translateX: -travel }] };
      case 'right':
        return { transform: [{ translateX: travel }] };
      default:
        return { transform: [{ translateX: 0 }] };
    }
  }, [bodyArrow]);

  if (status === null) return null;

  const toneColor: Record<VisibleCoachingTone, string> = {
    ready: theme.colors.success,
    adjust: theme.colors.warning,
    attention: theme.colors.error,
    searching: mediaColors.whiteMuted,
    blocked: mediaColors.whiteSoft,
  };

  return (
    <View
      style={[styles.container, { bottom }]}
      pointerEvents="none"
      accessibilityLiveRegion="polite"
      /* The spoken label keeps the detail even when the band is compact:
         hiding a line to protect a held pose is a VISUAL decision, and a
         screen-reader user is not holding a glance budget. */
      accessibilityLabel={
        status.detail.length > 0
          ? `${status.headline}. ${status.detail}`
          : status.headline
      }
    >
      <Animated.View style={[styles.pill, animatedStyle]}>
        {/* Camera UX Part 2 — the tone is carried by a leading accent rail
            instead of a filled badge. A solid coloured disc next to white
            text reads as an alert chip; a hairline rail reads as a category,
            which is what the tone actually is. */}
        <View style={[styles.accent, { backgroundColor: toneColor[status.tone] }]} />
        <View style={styles.body}>
          <View style={styles.headerRow}>
            <Animated.View style={nudgeStyle}>
              <IconSymbol
                name={iconFor(status, arrowDirection)}
                size={sizing.iconDefault}
                color={toneColor[status.tone]}
              />
            </Animated.View>
            <AppText
              variant="body"
              color={mediaColors.text}
              style={styles.directiveText}
              numberOfLines={2}
            >
              {status.headline}
            </AppText>
          </View>
          {emphasis === 'full' && status.detail.length > 0 && (
            <AppText
              variant="small"
              color={mediaColors.textMuted}
              style={styles.hintText}
              numberOfLines={2}
            >
              {status.detail}
            </AppText>
          )}
        </View>
      </Animated.View>
    </View>
  );
}

/** Travel of the directional nudge, in points. Deliberately sub-glance. */
const NUDGE_TRAVEL = 4;
/** Entrance travel of the band itself, in points. */
const BAND_LIFT = 6;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    alignItems: 'center',
    zIndex: 25,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'stretch',
    overflow: 'hidden',
    backgroundColor: mediaColors.overlayStrong,
    borderRadius: radius.xl,
    maxWidth: 340,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: mediaColors.whiteSoft,
  },
  accent: {
    width: spacing.xs,
  },
  body: {
    flexShrink: 1,
    gap: spacing.xs,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  directiveText: {
    fontWeight: '600',
    flexShrink: 1,
  },
  hintText: {
    paddingLeft: sizing.iconDefault + spacing.sm,
  },
});
