/**
 * FRAMING — LevelIndicator (horizon guide).
 *
 * The smallest thing that can answer "is this shot straight?":
 *
 *   · two SHORT static ticks either side of centre — the true horizontal;
 *   · one short bar between them that rotates with the phone;
 *   · when the two agree (within 1.5°) the bar snaps flat, turns the success
 *     colour and the readout disappears.
 *
 * It is deliberately NOT a full-width line, a bubble, a crosshair or a pitch
 * reticle. This app draws a pose silhouette, a skeleton and a directional
 * arrow over the same centre of the frame; a horizon aid that competes with
 * them would cost the user the thing they came for. It also never appears
 * while a hold is running, and it disappears entirely past 30° — at which
 * point the user is re-orienting the phone, not levelling it.
 *
 * Everything it shows comes from the accelerometer (see `useDeviceLevel`).
 * With no sensor there is no indicator; nothing here is simulated.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { radius, mediaColors, spacing, type LevelResolution } from '@shared/index';
import { AppText } from '@/shared/components/AppText';
import { useAppTheme } from '@/core/theme';

interface LevelIndicatorProps {
  readonly level: LevelResolution;
  /** Vertical centre of the aspect box — the level sits on the picture. */
  readonly centerY: number;
  /** "Level" — the control's name, in the coaching language. */
  readonly title: string;
  /** "Straight" / "3° tilt", already localised. */
  readonly value: string;
}

const TICK_WIDTH = 26;
const BAR_WIDTH = 96;
const GAP = spacing.sm;

export function LevelIndicator({ level, centerY, title, value }: LevelIndicatorProps) {
  const theme = useAppTheme();
  const tint = level.isLevel ? theme.colors.success : mediaColors.text;

  return (
    <View
      style={[styles.root, { top: centerY - ROOT_HEIGHT / 2 }]}
      pointerEvents="none"
      accessible
      accessibilityLabel={title}
      accessibilityValue={{ text: value }}
    >
      <View style={styles.row}>
        <View style={[styles.tick, { backgroundColor: mediaColors.textSubtle }]} />
        <View style={styles.barSlot}>
          <View
            style={[
              styles.bar,
              {
                backgroundColor: tint,
                transform: [{ rotate: `${-level.rollDeg}deg` }],
              },
            ]}
          />
        </View>
        <View style={[styles.tick, { backgroundColor: mediaColors.textSubtle }]} />
      </View>
      {/* Silence is the reward for a straight shot: no number when level. */}
      {!level.isLevel && (
        <AppText variant="small" color={mediaColors.textMuted} style={styles.value}>
          {value}
        </AppText>
      )}
    </View>
  );
}

const ROOT_HEIGHT = 40;

const styles = StyleSheet.create({
  root: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: ROOT_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tick: {
    width: TICK_WIDTH,
    height: 2,
    borderRadius: radius.pill,
  },
  barSlot: {
    width: BAR_WIDTH,
    marginHorizontal: GAP,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bar: {
    width: BAR_WIDTH,
    height: 2,
    borderRadius: radius.pill,
  },
  value: {
    marginTop: 6,
    fontSize: 11,
    fontWeight: '600',
  },
});
