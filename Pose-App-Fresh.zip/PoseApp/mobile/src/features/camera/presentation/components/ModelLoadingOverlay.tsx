/**
 * Unit 16 — ModelLoadingOverlay (spec §16.3 file 6).
 *
 * Shown over the viewfinder while the PoseLandmarker wasm model initializes
 * (typically 1–2s on first run, cached afterwards): full-screen black 60%
 * scrim, centered surface card with the primary spinner, "Loading AI..."
 * (Heading 22) and "Preparing pose detection" (BodySmall 14, secondary).
 * Blocking capture while it shows is intentional — auto/manual capture
 * depend on the same session gates and the user shouldn't shoot blind.
 */
import React from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { mediaColors, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';

export function ModelLoadingOverlay() {
  const theme = useAppTheme();
  return (
    <View
      style={styles.scrim}
      accessibilityViewIsModal
      accessibilityLabel="Loading AI pose detection"
    >
      <View
        style={[
          styles.card,
          {
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.divider,
          },
        ]}
      >
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <AppText
          variant="heading"
          color={theme.colors.textPrimary}
          style={styles.title}
        >
          Loading AI...
        </AppText>
        <AppText variant="small" color={theme.colors.textSecondary} align="center">
          Preparing pose detection
        </AppText>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  scrim: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    zIndex: 60,
    backgroundColor: mediaColors.overlayHeavy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.xl,
  },
  title: {
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
  },
});
