/**
 * Unit 12 — State 1 (No Pose selected).
 * Back arrow · camera illustration · "Choose a Pose" explanation ·
 * Browse Poses → Explore · recent poses rail (Unit 07 LRU) · Gallery shortcut.
 * No CameraView is mounted in this state (JIT init invariant).
 */
import React, { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  LIMITS,
  radius,
  spacing,
  getPoseById,
  type Pose,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useRecentPoses, useAddToRecent } from '@/features/poses/presentation/hooks/usePoses';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';
import { galleryLocalDatasource } from '@/features/gallery/data/datasources/galleryLocalDatasource';
import { AppImage } from '@/shared/components/AppImage';
import { useAuthStore } from '@/shared/stores/authStore';
import { EmptyStateWidget } from '@/shared/components/EmptyStateWidget';

function RecentPoseCard({
  pose,
  onPress,
}: {
  readonly pose: Pose;
  readonly onPress: (poseId: string) => void;
}) {
  const theme = useAppTheme();
  return (
    <Pressable
      onPress={() => onPress(pose.id)}
      accessibilityRole="button"
      accessibilityLabel={`Start capture with pose ${pose.title}`}
      style={({ pressed }) => [styles.recentCard, { opacity: pressed ? 0.85 : 1 }]}
    >
      <PoseCardArt pose={pose} height={96} borderRadius={radius.md} iconSize={26} showBadges={false} />
      <AppText
        variant="small"
        color={theme.colors.textPrimary}
        numberOfLines={1}
        style={styles.recentTitle}
      >
        {pose.title}
      </AppText>
    </Pressable>
  );
}

export function NoPoseState() {
  const theme = useAppTheme();
  const router = useRouter();
  const recentPoses = useRecentPoses(LIMITS.recentPoses);
  const addToRecent = useAddToRecent();
  const userId = useAuthStore((state) => state.session?.id ?? null);
  const galleryThumbnailUri =
    userId === null
      ? null
      : galleryLocalDatasource.getPhotos(userId)[0]?.imagePath ?? null;

  const openRecent = (poseId: string) => {
    addToRecent(poseId);
    router.push({ pathname: '/(tabs)/camera', params: { poseId } });
  };

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.backgroundSecondary }]}>
      <View style={styles.topRow}>
        <Pressable
          onPress={() => (router.canGoBack() ? router.back() : router.replace('/(tabs)'))}
          hitSlop={10}
          accessibilityRole="button"
          accessibilityLabel="Back"
          style={({ pressed }) => [styles.backButton, { opacity: pressed ? 0.7 : 1 }]}
        >
          <IconSymbol name="arrow-left" size={24} color={theme.colors.primary} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Unit 23: State 1 empty state via the generic widget (spec copy) */}
        <View style={styles.hero}>
          <EmptyStateWidget
            icon="camera-off-outline"
            title="No pose selected"
            description="Select a pose to start guided capture. The AI watches your body and guides you into the perfect frame."
            buttonText="Browse Poses"
            buttonIcon="compass-outline"
            onButtonPress={() => router.push('/(tabs)/explore')}
            style={styles.emptyWidget}
          />
        </View>

        {recentPoses.length > 0 && (
          <View style={styles.recentSection}>
            <AppText variant="small" color={theme.colors.textDisabled} style={styles.sectionLabel}>
              CONTINUE WITH A RECENT POSE
            </AppText>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.recentList}
            >
              {recentPoses.map((pose) => (
                <RecentPoseCard key={pose.id} pose={pose} onPress={openRecent} />
              ))}
            </ScrollView>
          </View>
        )}

        <View style={styles.heroSpacer} />
        <Pressable
          onPress={() => router.push('/(tabs)/gallery')}
          accessibilityRole="button"
          accessibilityLabel="Open gallery"
          style={({ pressed }) => [
            styles.galleryRow,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
              opacity: pressed ? 0.85 : 1,
            },
          ]}
        >
          <View style={[styles.galleryThumb, { backgroundColor: theme.colors.primaryLight }]}>
            {galleryThumbnailUri !== null ? (
              <AppImage
                uri={galleryThumbnailUri}
                accessibilityLabel="Most recent photo saved by PoseAssist"
                style={StyleSheet.absoluteFill}
              />
            ) : (
              <IconSymbol name="image-multiple" size={20} color={theme.colors.primary} />
            )}
          </View>
          <View style={styles.galleryTexts}>
            <AppText variant="cardTitle" color={theme.colors.textPrimary} style={styles.galleryTitle}>
              Gallery
            </AppText>
            <AppText variant="small" color={theme.colors.textSecondary}>
              Your captured shots stay on this device
            </AppText>
          </View>
          <IconSymbol name="chevron-right" size={18} color={theme.colors.textDisabled} />
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  topRow: {
    height: 48,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
  },
  backButton: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    paddingBottom: spacing.xl,
  },
  hero: {
    alignItems: 'center',
    paddingTop: spacing.lg,
  },
  emptyWidget: {
    paddingHorizontal: spacing.xl,
  },
  recentSection: {
    marginTop: spacing.xxxl,
  },
  sectionLabel: {
    fontWeight: '600',
    letterSpacing: 0.8,
    paddingHorizontal: spacing.xl,
  },
  recentList: {
    gap: spacing.sm,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.sm,
  },
  recentCard: {
    width: 84,
  },
  recentTitle: {
    marginTop: spacing.xs,
    fontWeight: '600',
  },
  heroSpacer: {
    flex: 1,
    minHeight: spacing.xxl,
  },
  galleryRow: {
    marginHorizontal: spacing.xl,
    marginTop: spacing.xl,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  galleryThumb: {
    width: 48,
    height: 48,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  galleryTexts: {
    flex: 1,
  },
  galleryTitle: {
    fontSize: 15,
  },
});
