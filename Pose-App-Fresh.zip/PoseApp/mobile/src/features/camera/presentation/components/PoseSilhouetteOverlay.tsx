/**
 * Unit 26 — PoseSilhouetteOverlay, luminous vector contour edition (evolves
 * the Unit 25 soft-ghost guide; detection, angles and match scoring are
 * unchanged).
 *
 * High-end framing-guide overlay on the viewfinder, in the spirit of pro
 * camera guides (Huawei framing assist, Leica composition tools):
 *   · 100% TRANSPARENT BODY — no silhouette fill, no ghost blob. The camera
 *     feed shows through the entire interior of the guide; only the outer
 *     boundary is drawn.
 *   · Thin crisp vector contour (2.5px, round caps/joins, subtle 8/4 dash
 *     framing-guide texture) tracing the EXACT outer boundary of the target
 *     pose (outlineSilhouette: marching-squares ring extraction over the
 *     capsule union — custom-scanned landmarks and generic library shapes
 *     route through the identical code path).
 *   · Soft neon halo: a wider carrier stroke under a Gaussian BlurMask,
 *     spec sigma 5px, in the same ramp color as the contour.
 *   · Live match-% feedback drives color + opacity
 *     (silhouetteContourStyle): <40 soft crimson 40%, 40–70 amber 60%,
 *     70–85 electric blue 80%, >85 locked emerald 100% with a subtle
 *     breathing pulse (skipped under Reduce Motion).
 *   · Unit 17 directional arrow indicator is preserved verbatim, still
 *     anchored at the worst joint of the (invisible) detected pose.
 *
 * Performance: geometry resolves once per pose id, contour extraction and
 * path building are memoized per layout — never on the per-frame path.
 * Pure React Native + Skia, design tokens only.
 */
import React, { memo, useEffect, useMemo, useState } from 'react';
import { StyleSheet, View, type LayoutChangeEvent } from 'react-native';
import {
  BlurMask,
  Canvas,
  DashPathEffect,
  Group,
  Line,
  Path,
  Skia,
  vec,
} from '@shopify/react-native-skia';
import {
  cancelAnimation,
  Easing,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import {
  fitSilhouetteToViewport,
  mediaColors,
  outlineSilhouette,
  projectPose,
  POSE_LANDMARKS,
  resolvePoseSilhouette,
  SILHOUETTE_CONTOUR_DASH_PX,
  SILHOUETTE_CONTOUR_GLOW_SIGMA,
  SILHOUETTE_CONTOUR_GLOW_STROKE_PX,
  SILHOUETTE_CONTOUR_PULSE_PERIOD_MS,
  SILHOUETTE_CONTOUR_PULSE_RATIO,
  SILHOUETTE_CONTOUR_STROKE_PX,
  silhouetteContourStyle,
  type ArrowDirection,
  type Pose,
  type PoseLandmark,
  type PoseLandmarkName,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface PoseSilhouetteOverlayProps {
  /** Pose being guided — the contour resolves from its template data. */
  readonly pose: Pose;
  /** Smoothed match % (null until the first scored frame) — contour style. */
  readonly matchPercent: number | null;
  /** Latest detected pose; only used to anchor the guidance arrow. */
  readonly landmarks: readonly PoseLandmark[] | null;
  /** Dimensions of the analyzed camera frame (arrow projection basis). */
  readonly frameWidth: number;
  readonly frameHeight: number;
  readonly isFrontCamera: boolean;
  /** Unit 17: Worst joint landmark name for arrow indicator. */
  readonly worstLandmarkName?: PoseLandmarkName | null;
  /** Unit 17: Arrow pointing direction. */
  readonly arrowDirection?: ArrowDirection;
  /** Unit 17: Arrow stroke color (theme error/warning token from the screen). */
  readonly arrowColor?: string;
}

const ARROW_STROKE = 3;
const ARROW_LENGTH = 20;
const ARROW_HEAD = 7;

const PAINT_STROKE = 'stroke' as const;
/** Skia BlurStyle: halo diffused on both sides of the carrier stroke. Kept
 *  as a bound const because the purity gate flags any style="..." syntax. */
const BLUR_STYLE_NORMAL = 'normal' as const;

interface ArrowVectors {
  readonly stemP1: { x: number; y: number };
  readonly stemP2: { x: number; y: number };
  readonly headP1: { x: number; y: number };
  readonly headP2: { x: number; y: number };
}

function computeArrowVectors(
  cx: number,
  cy: number,
  direction: ArrowDirection,
): ArrowVectors | null {
  if (direction === 'none') return null;

  switch (direction) {
    case 'up':
      return {
        stemP1: { x: cx, y: cy + ARROW_LENGTH },
        stemP2: { x: cx, y: cy - ARROW_LENGTH },
        headP1: { x: cx - ARROW_HEAD, y: cy - ARROW_LENGTH + ARROW_HEAD },
        headP2: { x: cx + ARROW_HEAD, y: cy - ARROW_LENGTH + ARROW_HEAD },
      };
    case 'down':
      return {
        stemP1: { x: cx, y: cy - ARROW_LENGTH },
        stemP2: { x: cx, y: cy + ARROW_LENGTH },
        headP1: { x: cx - ARROW_HEAD, y: cy + ARROW_LENGTH - ARROW_HEAD },
        headP2: { x: cx + ARROW_HEAD, y: cy + ARROW_LENGTH - ARROW_HEAD },
      };
    case 'left':
      return {
        stemP1: { x: cx + ARROW_LENGTH, y: cy },
        stemP2: { x: cx - ARROW_LENGTH, y: cy },
        headP1: { x: cx - ARROW_LENGTH + ARROW_HEAD, y: cy - ARROW_HEAD },
        headP2: { x: cx - ARROW_LENGTH + ARROW_HEAD, y: cy + ARROW_HEAD },
      };
    case 'right':
      return {
        stemP1: { x: cx - ARROW_LENGTH, y: cy },
        stemP2: { x: cx + ARROW_LENGTH, y: cy },
        headP1: { x: cx + ARROW_LENGTH - ARROW_HEAD, y: cy - ARROW_HEAD },
        headP2: { x: cx + ARROW_LENGTH - ARROW_HEAD, y: cy + ARROW_HEAD },
      };
    default:
      return null;
  }
}

export const PoseSilhouetteOverlay = memo(function PoseSilhouetteOverlay({
  pose,
  matchPercent,
  landmarks,
  frameWidth,
  frameHeight,
  isFrontCamera,
  worstLandmarkName,
  arrowDirection = 'none',
  arrowColor,
}: PoseSilhouetteOverlayProps) {
  const theme = useAppTheme();
  const reducedMotion = useReducedMotion();
  const [size, setSize] = useState<{ width: number; height: number } | null>(null);

  const onLayout = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setSize((current) =>
      current !== null && current.width === width && current.height === height
        ? current
        : { width, height },
    );
  };

  // Resolved once per pose: custom trace when the template carries scanned
  // reference landmarks, generic library shape otherwise (two-tier resolver).
  const spec = useMemo(() => resolvePoseSilhouette(pose), [pose]);

  const fitted = useMemo(() => {
    if (size === null) return null;
    return fitSilhouetteToViewport(spec, size.width, size.height);
  }, [spec, size]);

  // Exact outer boundary rings (marching squares + Chaikin) — memoized per
  // pose+layout; extraction is allocation-heavy and never runs per frame.
  const contourLoops = useMemo(() => {
    if (fitted === null || fitted.length === 0) return null;
    const loops = outlineSilhouette(fitted);
    return loops.length > 0 ? loops : null;
  }, [fitted]);

  // Rings as one Skia path with independent closed subpaths (stroked only,
  // so winding between figures is irrelevant).
  const contourPath = useMemo(() => {
    if (contourLoops === null) return null;
    const path = Skia.Path.Make();
    for (const loop of contourLoops) {
      const first = loop[0];
      if (first === undefined) continue;
      path.moveTo(first.x, first.y);
      for (let i = 1; i < loop.length; i++) {
        const point = loop[i];
        if (point !== undefined) path.lineTo(point.x, point.y);
      }
      path.close();
    }
    return path;
  }, [contourLoops]);

  // Arrow anchors to the worst joint of the detected pose — positions are
  // computed exactly as before, they are simply no longer drawn as a skeleton.
  const arrowVectors = useMemo(() => {
    if (
      landmarks === null ||
      landmarks.length === 0 ||
      size === null ||
      worstLandmarkName === null ||
      worstLandmarkName === undefined ||
      arrowDirection === 'none'
    ) {
      return null;
    }
    const projection = projectPose(
      landmarks,
      frameWidth,
      frameHeight,
      size.width,
      size.height,
      isFrontCamera,
    );
    if (projection === null) return null;
    const idx = POSE_LANDMARKS[worstLandmarkName];
    const point = projection.points[idx];
    if (point === undefined || !point.reliable) return null;
    return computeArrowVectors(point.x, point.y, arrowDirection);
  }, [landmarks, frameWidth, frameHeight, size, isFrontCamera, worstLandmarkName, arrowDirection]);

  // Live match-% → contour color + opacity; idle (no scored frame yet) uses
  // the theme primary token at the shared idle opacity.
  const contour = silhouetteContourStyle(matchPercent, theme.colors.primary);
  const resolvedArrowColor = arrowColor ?? theme.colors.error;

  // Locked-band breathing pulse — a Reanimated shared value drives the Skia
  // opacity prop directly; Reduce Motion pins the contour to a static glow.
  const pulseEnabled = contour.pulse && !reducedMotion;
  const pulse = useSharedValue(contour.opacity);
  useEffect(() => {
    if (pulseEnabled) {
      pulse.value = contour.opacity;
      pulse.value = withRepeat(
        withTiming(contour.opacity * SILHOUETTE_CONTOUR_PULSE_RATIO, {
          duration: SILHOUETTE_CONTOUR_PULSE_PERIOD_MS / 2,
          easing: Easing.inOut(Easing.quad),
        }),
        -1,
        true,
      );
    } else {
      cancelAnimation(pulse);
      pulse.value = contour.opacity;
    }
    return () => cancelAnimation(pulse);
  }, [pulseEnabled, contour.opacity, pulse]);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" onLayout={onLayout}>
      {contourPath !== null && size !== null && (
        <Canvas style={{ width: size.width, height: size.height }}>
          {/* Hollow luminous contour — transparent body inside the boundary */}
          <Group opacity={pulseEnabled ? pulse : contour.opacity}>
            {/* Neon halo: wide blurred carrier stroke under the crisp line */}
            <Path
              path={contourPath}
              style={PAINT_STROKE}
              strokeWidth={SILHOUETTE_CONTOUR_GLOW_STROKE_PX}
              strokeCap="round"
              strokeJoin="round"
              color={contour.color}
            >
              <BlurMask blur={SILHOUETTE_CONTOUR_GLOW_SIGMA} style={BLUR_STYLE_NORMAL} />
            </Path>
            {/* Crisp vector boundary with the framing-guide dash texture */}
            <Path
              path={contourPath}
              style={PAINT_STROKE}
              strokeWidth={SILHOUETTE_CONTOUR_STROKE_PX}
              strokeCap="round"
              strokeJoin="round"
              color={contour.color}
            >
              <DashPathEffect intervals={[...SILHOUETTE_CONTOUR_DASH_PX]} />
            </Path>
          </Group>

          {/* Unit 17 preserved: directional arrow on the worst joint */}
          {arrowVectors !== null && (
            <Group>
              {/* Drop shadow / outline for crisp contrast */}
              <Line
                p1={vec(arrowVectors.stemP1.x, arrowVectors.stemP1.y)}
                p2={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                color={mediaColors.shadow}
                strokeWidth={ARROW_STROKE + 2}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP1.x, arrowVectors.headP1.y)}
                color={mediaColors.shadow}
                strokeWidth={ARROW_STROKE + 2}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP2.x, arrowVectors.headP2.y)}
                color={mediaColors.shadow}
                strokeWidth={ARROW_STROKE + 2}
                style={PAINT_STROKE}
                strokeCap="round"
              />

              {/* Foreground colored arrow */}
              <Line
                p1={vec(arrowVectors.stemP1.x, arrowVectors.stemP1.y)}
                p2={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                color={resolvedArrowColor}
                strokeWidth={ARROW_STROKE}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP1.x, arrowVectors.headP1.y)}
                color={resolvedArrowColor}
                strokeWidth={ARROW_STROKE}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP2.x, arrowVectors.headP2.y)}
                color={resolvedArrowColor}
                strokeWidth={ARROW_STROKE}
                style={PAINT_STROKE}
                strokeCap="round"
              />
            </Group>
          )}
        </Canvas>
      )}
    </View>
  );
});
