/**
 * Unit 17 — PoseSkeletonOverlay (spec §17.3 file 4).
 *
 * Upgraded Skia Canvas overlay on the camera viewfinder:
 *   · Color-coded 16 display bones: colored per worst diff of endpoints (Green/Amber/Red)
 *   · Color-coded 33 landmark dots: Green (<10°), Amber (10–25°), Red (>25°)
 *   · Directional arrow indicator: rendered directly at the worst joint's vertex
 *     pointing in the correction direction (up/down/left/right) with high contrast.
 *
 * Performance: 60fps UI canvas repaints smoothly on landmark state changes;
 * pure React Native + Skia, design tokens only.
 */
import React, { memo, useMemo, useState } from 'react';
import { StyleSheet, View, type LayoutChangeEvent } from 'react-native';
import { Canvas, Circle, Group, Line, vec } from '@shopify/react-native-skia';
import {
  mediaColors,
  projectPose,
  POSE_LANDMARKS,
  type ArrowDirection,
  type PoseLandmark,
  type PoseLandmarkName,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';

interface PoseSkeletonOverlayProps {
  /** Latest detected pose; null/empty hides the skeleton cleanly. */
  readonly landmarks: readonly PoseLandmark[] | null;
  /** Dimensions of the analyzed camera frame. */
  readonly frameWidth: number;
  readonly frameHeight: number;
  readonly isFrontCamera: boolean;
  /** Unit 17: Mapped status colors for each of the 33 landmarks. */
  readonly landmarkColors?: Readonly<Record<number, string>>;
  /** Unit 17: Mapped status colors for each of the 16 display bones. */
  readonly boneColors?: readonly string[];
  /** Unit 17: Worst joint landmark name for arrow indicator. */
  readonly worstLandmarkName?: PoseLandmarkName | null;
  /** Unit 17: Arrow pointing direction. */
  readonly arrowDirection?: ArrowDirection;
  /** Unit 17: Arrow stroke color. */
  readonly arrowColor?: string;
}

const DOT_RADIUS = 4.5;
const DOT_STROKE = 2;
const BONE_WIDTH = 2.5;
const BONE_OPACITY = 0.85;
const ARROW_STROKE = 3;
const ARROW_LENGTH = 20;
const ARROW_HEAD = 7;

const PAINT_STROKE = 'stroke' as const;

interface ArrowVectors {
  readonly stemP1: { x: number; y: number };
  readonly stemP2: { x: number; y: number };
  readonly headP1: { x: number; y: number };
  readonly headP2: { x: number; y: number };
}

function computeArrowVectors(
  cx: number,
  cy: number,
  direction: ArrowDirection,
): ArrowVectors | null {
  if (direction === 'none') return null;

  switch (direction) {
    case 'up':
      return {
        stemP1: { x: cx, y: cy + ARROW_LENGTH },
        stemP2: { x: cx, y: cy - ARROW_LENGTH },
        headP1: { x: cx - ARROW_HEAD, y: cy - ARROW_LENGTH + ARROW_HEAD },
        headP2: { x: cx + ARROW_HEAD, y: cy - ARROW_LENGTH + ARROW_HEAD },
      };
    case 'down':
      return {
        stemP1: { x: cx, y: cy - ARROW_LENGTH },
        stemP2: { x: cx, y: cy + ARROW_LENGTH },
        headP1: { x: cx - ARROW_HEAD, y: cy + ARROW_LENGTH - ARROW_HEAD },
        headP2: { x: cx + ARROW_HEAD, y: cy + ARROW_LENGTH - ARROW_HEAD },
      };
    case 'left':
      return {
        stemP1: { x: cx + ARROW_LENGTH, y: cy },
        stemP2: { x: cx - ARROW_LENGTH, y: cy },
        headP1: { x: cx - ARROW_LENGTH + ARROW_HEAD, y: cy - ARROW_HEAD },
        headP2: { x: cx - ARROW_LENGTH + ARROW_HEAD, y: cy + ARROW_HEAD },
      };
    case 'right':
      return {
        stemP1: { x: cx - ARROW_LENGTH, y: cy },
        stemP2: { x: cx + ARROW_LENGTH, y: cy },
        headP1: { x: cx + ARROW_LENGTH - ARROW_HEAD, y: cy - ARROW_HEAD },
        headP2: { x: cx + ARROW_LENGTH - ARROW_HEAD, y: cy + ARROW_HEAD },
      };
    default:
      return null;
  }
}

export const PoseSkeletonOverlay = memo(function PoseSkeletonOverlay({
  landmarks,
  frameWidth,
  frameHeight,
  isFrontCamera,
  landmarkColors,
  boneColors,
  worstLandmarkName,
  arrowDirection = 'none',
  arrowColor,
}: PoseSkeletonOverlayProps) {
  const theme = useAppTheme();
  const [size, setSize] = useState<{ width: number; height: number } | null>(null);

  const onLayout = (event: LayoutChangeEvent) => {
    const { width, height } = event.nativeEvent.layout;
    setSize((current) =>
      current !== null && current.width === width && current.height === height
        ? current
        : { width, height },
    );
  };

  const projection = useMemo(() => {
    if (landmarks === null || landmarks.length === 0 || size === null) return null;
    return projectPose(
      landmarks,
      frameWidth,
      frameHeight,
      size.width,
      size.height,
      isFrontCamera,
    );
  }, [landmarks, frameWidth, frameHeight, size, isFrontCamera]);

  // Arrow calculation for the worst joint
  const arrowVectors = useMemo(() => {
    if (
      projection === null ||
      worstLandmarkName === null ||
      worstLandmarkName === undefined ||
      arrowDirection === 'none'
    ) {
      return null;
    }
    const idx = POSE_LANDMARKS[worstLandmarkName];
    const point = projection.points[idx];
    if (point === undefined || !point.reliable) return null;
    return computeArrowVectors(point.x, point.y, arrowDirection);
  }, [projection, worstLandmarkName, arrowDirection]);

  const resolvedArrowColor = arrowColor ?? theme.colors.error;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" onLayout={onLayout}>
      {projection !== null && size !== null && (
        <Canvas style={{ width: size.width, height: size.height }}>
          {/* 16 Bones with dynamic status coloring */}
          <Group opacity={BONE_OPACITY}>
            {projection.bones.map((bone, index) => {
              if (!bone.from.reliable || !bone.to.reliable) return null;
              const color = boneColors?.[index] ?? theme.colors.primary;
              return (
                <Line
                  key={`bone-${index}`}
                  p1={vec(bone.from.x, bone.from.y)}
                  p2={vec(bone.to.x, bone.to.y)}
                  color={color}
                  strokeWidth={BONE_WIDTH}
                  style={PAINT_STROKE}
                  strokeCap="round"
                />
              );
            })}
          </Group>

          {/* 33 Landmark dots with dynamic status coloring */}
          {projection.points.map((point, index) => {
            if (!point.reliable) return null;
            const strokeColor = landmarkColors?.[index] ?? theme.colors.primary;
            return (
              <Group key={`dot-${index}`}>
                <Circle cx={point.x} cy={point.y} r={DOT_RADIUS} color={mediaColors.text} />
                <Circle
                  cx={point.x}
                  cy={point.y}
                  r={DOT_RADIUS}
                  color={strokeColor}
                  style={PAINT_STROKE}
                  strokeWidth={DOT_STROKE}
                />
              </Group>
            );
          })}

          {/* Unit 17: Directional arrow indicator on the worst joint */}
          {arrowVectors !== null && (
            <Group>
              {/* Drop shadow / outline for crisp contrast */}
              <Line
                p1={vec(arrowVectors.stemP1.x, arrowVectors.stemP1.y)}
                p2={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                color={mediaColors.shadow}
                strokeWidth={ARROW_STROKE + 2}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP1.x, arrowVectors.headP1.y)}
                color={mediaColors.shadow}
                strokeWidth={ARROW_STROKE + 2}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP2.x, arrowVectors.headP2.y)}
                color={mediaColors.shadow}
                strokeWidth={ARROW_STROKE + 2}
                style={PAINT_STROKE}
                strokeCap="round"
              />

              {/* Foreground colored arrow */}
              <Line
                p1={vec(arrowVectors.stemP1.x, arrowVectors.stemP1.y)}
                p2={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                color={resolvedArrowColor}
                strokeWidth={ARROW_STROKE}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP1.x, arrowVectors.headP1.y)}
                color={resolvedArrowColor}
                strokeWidth={ARROW_STROKE}
                style={PAINT_STROKE}
                strokeCap="round"
              />
              <Line
                p1={vec(arrowVectors.stemP2.x, arrowVectors.stemP2.y)}
                p2={vec(arrowVectors.headP2.x, arrowVectors.headP2.y)}
                color={resolvedArrowColor}
                strokeWidth={ARROW_STROKE}
                style={PAINT_STROKE}
                strokeCap="round"
              />
            </Group>
          )}
        </Canvas>
      )}
    </View>
  );
});
