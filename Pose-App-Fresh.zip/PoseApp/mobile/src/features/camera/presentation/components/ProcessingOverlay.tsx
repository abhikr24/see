/**
 * Unit 13 — blocking post-capture state.
 *
 * Camera UX Part 1: it covers BOTH capture stages instead of only the
 * post-shutter write. Before, `takePictureAsync()` ran with no overlay at all:
 * on a slow device the screen simply froze for several hundred milliseconds
 * after the shutter — the classic "did it take the photo?" moment, which makes
 * users tap again.
 *
 * Camera UX Part 3: THE TWO STAGES STOP LOOKING IDENTICAL.
 *
 * Both stages rendered the same 60 % black slab with a spinner. That is wrong
 * for the first one: the shutter firing is a fast, physical event, and a heavy
 * black curtain over it reads as a stall, not as a shutter. The stages now
 * differ the way the real events differ —
 *
 *   capturing   a brief, light veil and a soft pulse of the frame. The user
 *               keeps seeing what they shot; nothing implies waiting.
 *   processing  the honest waiting state: heavier veil, a spinner, a label.
 *
 * The label still arrives fully localized from `cameraStatusCopyFor`, the
 * blocking decision still belongs to `resolveCameraPresentation`, and this
 * component still owns nothing but presentation.
 */
import React, { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { mediaColors, motionDuration, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface ProcessingOverlayProps {
  /** Localized stage label ("Capturing" / "Saving your shot"). */
  readonly label: string;
  /** Which of the two capture stages this is. */
  readonly stage: 'capturing' | 'processing';
}

export function ProcessingOverlay({ label, stage }: ProcessingOverlayProps) {
  const theme = useAppTheme();
  const reduceMotion = useReducedMotion();
  const settled = useSharedValue(0);

  useEffect(() => {
    settled.value = reduceMotion
      ? 1
      : withTiming(1, { duration: motionDuration.standard });
  }, [reduceMotion, settled, stage]);

  const veilStyle = useAnimatedStyle(() => ({ opacity: settled.value }));
  const cardStyle = useAnimatedStyle(() => ({
    opacity: settled.value,
    transform: [{ scale: 0.96 + settled.value * 0.04 }],
  }));

  const capturing = stage === 'capturing';

  return (
    <Animated.View
      style={[
        styles.overlay,
        veilStyle,
        {
          backgroundColor: capturing
            ? mediaColors.overlayMedium
            : mediaColors.overlayHeavy,
        },
      ]}
      accessibilityViewIsModal
      accessibilityLiveRegion="polite"
      accessibilityLabel={label}
    >
      {capturing ? (
        /* A shutter is not a wait. One quiet line, no spinner, and the frame
           stays visible underneath. */
        <Animated.View style={cardStyle}>
          <AppText variant="small" color={mediaColors.textMuted}>
            {label}
          </AppText>
        </Animated.View>
      ) : (
        <Animated.View style={[styles.card, cardStyle]}>
          <ActivityIndicator size="large" color={theme.colors.primary} />
          <AppText variant="body" color={mediaColors.text} style={styles.label}>
            {label}
          </AppText>
        </Animated.View>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    zIndex: 100,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
    borderRadius: radius.xl,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: mediaColors.whiteSoft,
    backgroundColor: mediaColors.overlayStrong,
  },
  label: {
    marginTop: spacing.md,
  },
});
