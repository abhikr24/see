/**
 * Unit 12 — ReferenceOverlay.
 * Camera UX Part 3: THE PINNED REFERENCE BECOMES THE POSE IDENTITY CHIP.
 *
 * WHAT WAS WRONG
 *
 * The camera screen never said which pose it was coaching. The 80x120
 * thumbnail is a *picture* of the answer, which works for poses the user
 * already recognises and for nobody else — and once inside the viewfinder
 * there was no way back to pose selection at all except the tab bar, which
 * re-enters the same armed pose. "Where am I" and "how do I leave" are two of
 * the four questions a camera screen must answer at a glance; this surface
 * now answers both without adding another floating control to the frame.
 *
 * WHAT IT IS NOW
 *
 *   · the same reference art, at the same size and the same hairline weight,
 *   · a one-line title under it (truncated, never wrapped, never a paragraph),
 *   · the whole card is the route back to pose selection — the existing
 *     `/(tabs)/camera` reset the notice screens already use, no new nav.
 *
 * It stays top-RIGHT: out of the left-thumb arc, out of the shutter's reach,
 * and out of the centre where the subject lives. Copy arrives localized; this
 * component assembles no sentences and computes nothing.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import {
  mediaColors,
  pressMotion,
  radius,
  sizing,
  spacing,
  type Pose,
} from '@shared/index';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PressableScale } from '@/shared/components/PressableScale';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';

interface ReferenceOverlayProps {
  readonly pose: Pose;
  readonly top: number;
  /** Localized "Shooting" / "Change pose" labels. */
  readonly shootingLabel: string;
  readonly changeLabel: string;
  /** Returns to pose selection. Optional so the chip degrades to a card. */
  readonly onChangePose?: () => void;
}

export function ReferenceOverlay({
  pose,
  top,
  shootingLabel,
  changeLabel,
  onChangePose,
}: ReferenceOverlayProps) {
  const body = (
    <View style={styles.card}>
      <View style={styles.art}>
        <PoseCardArt
          pose={pose}
          height={REFERENCE_ART_HEIGHT}
          borderRadius={radius.md}
          iconSize={30}
          showBadges={false}
        />
        {onChangePose !== undefined && (
          <View style={styles.swapBadge}>
            <IconSymbol
              name="swap-horizontal"
              size={sizing.iconSmall - 2}
              color={mediaColors.text}
            />
          </View>
        )}
      </View>
      <AppText
        variant="small"
        color={mediaColors.textMuted}
        numberOfLines={1}
        style={styles.title}
      >
        {pose.title}
      </AppText>
    </View>
  );

  if (onChangePose === undefined) {
    return (
      <View
        style={[styles.frame, { top }]}
        pointerEvents="none"
        /* Camera UX Part 1: the pinned reference had no label at all, so a
           screen-reader user never learned which pose they were shooting. */
        accessibilityLabel={`${shootingLabel}: ${pose.title}`}
      >
        {body}
      </View>
    );
  }

  return (
    <View style={[styles.frame, { top }]} pointerEvents="box-none">
      <PressableScale
        onPress={onChangePose}
        scaleTo={pressMotion.cardScale}
        hitSlop={spacing.sm}
        accessibilityRole="button"
        accessibilityLabel={`${shootingLabel}: ${pose.title}`}
        accessibilityHint={changeLabel}
      >
        {body}
      </PressableScale>
    </View>
  );
}

/** Height of the reference art itself; the title sits under it. */
const REFERENCE_ART_HEIGHT = 104;

const styles = StyleSheet.create({
  frame: {
    position: 'absolute',
    right: spacing.lg,
    width: 80,
  },
  card: {
    width: 80,
    borderRadius: radius.lg,
    overflow: 'hidden',
    /* Camera UX Part 2 — a 2 pt pure-white frame around a thumbnail sitting
       on a live image is the loudest thing on the screen, and it is only a
       reference. A hairline at 25 % white still reads as a distinct card
       without competing with the subject or with the coaching band. */
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: mediaColors.whiteMuted,
    backgroundColor: mediaColors.overlayStrong,
  },
  art: {
    height: REFERENCE_ART_HEIGHT,
    overflow: 'hidden',
  },
  swapBadge: {
    position: 'absolute',
    right: spacing.xs,
    bottom: spacing.xs,
    width: sizing.iconDefault,
    height: sizing.iconDefault,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: mediaColors.overlayHeavy,
  },
  title: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    fontWeight: '600',
  },
});
