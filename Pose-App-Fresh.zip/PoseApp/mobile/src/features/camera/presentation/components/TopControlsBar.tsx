/**
 * Unit 12 — TopControlsBar.
 * Absolute top overlay over the shared top-scrim gradient token.
 *
 * CAMERA CONTROLS PASS — what changed and why.
 *
 * The bar used to carry three controls (flash, timer, settings) and answered
 * only one lighting question: "what should happen at the moment of capture?".
 * Two things a normal camera user expects were missing entirely:
 *
 *   · CONTINUOUS LIGHT. The camera foundation supports a torch
 *     (`CameraView.enableTorch`) and the app never exposed it, so the only
 *     way to light a dim room was to fire the capture flash blind and judge
 *     the result afterwards — with a pose to hold in between.
 *   · BRIGHTNESS. No control at all over how light or dark the photograph
 *     comes out.
 *
 * Both now live here, next to flash, because "how bright is this shot going
 * to be?" is one question and its answers belong in one place. Nothing else
 * moved, nothing was removed, and the bar is still one row of 48 pt targets.
 *
 * The flash control is dimmed — not hidden, not silently ignored — while the
 * torch is lit, because a capture-time burst on top of a lamp that is already
 * on is a non-event the user should not have to discover by experiment.
 */
import React from 'react';
import { Alert, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  brightnessBadge,
  isBrightnessDefault,
  mediaColors,
  pressMotion,
  scrimGradientFor,
  spacing,
  type AspectRatioId,
  type CameraStatusCopy,
  type ExposureMechanism,
  type TorchBlockedReason,
} from '@shared/index';
import type { FlashMode, TimerSeconds } from '@/core/camera/cameraService';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PressableScale } from '@/shared/components/PressableScale';
import { useAppTheme } from '@/core/theme';

interface TopControlsBarProps {
  readonly topInset: number;
  readonly flash: FlashMode;
  readonly timer: TimerSeconds;
  readonly copy: CameraStatusCopy;
  /** Whether the lamp is actually lit (already resolved for this facing). */
  readonly torchOn: boolean;
  readonly torchEnabled: boolean;
  readonly torchBlockedReason: TorchBlockedReason;
  readonly flashSupersededByTorch: boolean;
  readonly brightness: number;
  readonly brightnessOpen: boolean;
  /** D1 — which mechanism carries the adjustment; names the glyph honestly. */
  readonly exposureMechanism: ExposureMechanism;
  /** FRAMING — the current photo shape, shown as a badge on the crop glyph. */
  readonly aspectRatio: AspectRatioId;
  readonly framingOpen: boolean;
  /** True when the grid or the level guide is currently doing something. */
  readonly framingAidsActive: boolean;
  readonly onCycleFlash: () => void;
  readonly onToggleTorch: () => void;
  readonly onToggleBrightness: () => void;
  readonly onToggleFraming: () => void;
  readonly onCycleTimer: () => void;
  readonly onOpenSettings?: () => void;
}

const FLASH_ICON: Record<FlashMode, string> = {
  off: 'flash-off',
  auto: 'flash-auto',
  on: 'flash',
};

function ControlButton({
  icon,
  label,
  value,
  hint,
  badge,
  active,
  activeColor,
  disabled,
  onPress,
}: {
  readonly icon: string;
  readonly label: string;
  /** Current setting, announced separately from the control's name. */
  readonly value?: string;
  readonly hint?: string;
  readonly badge?: string;
  /** The control is currently DOING something (torch lit, panel open). */
  readonly active?: boolean;
  readonly activeColor?: string;
  readonly disabled?: boolean;
  readonly onPress: () => void;
}) {
  const tint = disabled
    ? mediaColors.glyphDark
    : active === true && activeColor !== undefined
      ? activeColor
      : mediaColors.text;
  return (
    <PressableScale
      onPress={onPress}
      disabled={disabled}
      scaleTo={pressMotion.controlScale}
      accessibilityRole="button"
      accessibilityLabel={label}
      /* Camera UX Part 1: these were cycling controls announced only by a
         static name, so a screen-reader user could not tell what the flash or
         timer was currently set to, nor that pressing cycles rather than
         toggles. */
      accessibilityValue={value === undefined ? undefined : { text: value }}
      accessibilityHint={hint}
      accessibilityState={{ disabled: disabled === true, selected: active === true }}
      style={styles.button}
    >
      {active === true && (
        <View
          style={[styles.activeHalo, { backgroundColor: mediaColors.whiteSoft }]}
          pointerEvents="none"
        />
      )}
      <IconSymbol name={icon} size={28} color={tint} />
      {badge !== undefined && (
        <View style={styles.badge}>
          <AppText variant="small" color={mediaColors.text} style={styles.badgeText}>
            {badge}
          </AppText>
        </View>
      )}
    </PressableScale>
  );
}

export function TopControlsBar({
  topInset,
  flash,
  timer,
  copy,
  torchOn,
  torchEnabled,
  torchBlockedReason,
  flashSupersededByTorch,
  brightness,
  brightnessOpen,
  exposureMechanism,
  aspectRatio,
  framingOpen,
  framingAidsActive,
  onCycleFlash,
  onToggleTorch,
  onToggleBrightness,
  onToggleFraming,
  onCycleTimer,
  onOpenSettings,
}: TopControlsBarProps) {
  const theme = useAppTheme();

  const settings = () => {
    if (onOpenSettings) {
      onOpenSettings();
    } else {
      Alert.alert('Camera Settings', 'Open settings to adjust camera preferences.');
    }
  };

  const brightnessAtDefault = isBrightnessDefault(brightness);

  return (
    <View style={styles.overlay}>
      {/* Premium-pass item 8: shared top scrim gradient token. */}
      <LinearGradient
        colors={scrimGradientFor('top')}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={[styles.scrim, { height: topInset + SCRIM_BODY_HEIGHT }]}
        pointerEvents="none"
      />
      {/* Camera UX Part 1: the safe-area inset was applied TWICE (once on the
          overlay, once on the row), pushing the flash/timer/settings controls
          a full notch-height too far down on every device with an inset —
          worst on Dynamic Island and tall Android cutouts. It is applied once
          now, and the scrim grows with the inset instead of being a fixed
          96 px slab that a large inset could out-reach. */}
      <View style={[styles.row, { paddingTop: topInset + spacing.sm }]}>
        <ControlButton
          icon={FLASH_ICON[flash]}
          label={copy.flashTitle}
          value={
            flashSupersededByTorch
              ? `${copy.flashValue(flash)} — ${copy.flashSupersededNote}`
              : copy.flashValue(flash)
          }
          hint="Cycles off, automatic and on"
          disabled={flashSupersededByTorch}
          onPress={onCycleFlash}
        />
        <ControlButton
          icon={torchOn ? 'flashlight' : 'flashlight-off'}
          label={copy.torchTitle}
          value={
            torchEnabled
              ? copy.torchValue(torchOn)
              : copy.torchBlocked(torchBlockedReason)
          }
          hint={copy.torchBlocked(torchBlockedReason) || undefined}
          active={torchOn}
          activeColor={theme.colors.warning}
          disabled={!torchEnabled}
          onPress={onToggleTorch}
        />
        <ControlButton
          icon="brightness-6"
          label={copy.brightnessTitleFor(exposureMechanism)}
          value={copy.brightnessValue(brightness)}
          hint={copy.brightnessNoteFor(exposureMechanism)}
          badge={brightnessAtDefault ? undefined : brightnessBadge(brightness) ?? undefined}
          active={brightnessOpen || !brightnessAtDefault}
          activeColor={theme.colors.primary}
          onPress={onToggleBrightness}
        />
        {/* FRAMING — one glyph for shape, grid and level. It carries the
            current shape as its badge, so the bar answers "what shape is this
            photo?" without being opened, and it lights up while a framing aid
            is actually on screen. */}
        <ControlButton
          icon="crop"
          label={copy.framingTitle}
          value={`${copy.ratioValue(aspectRatio)} ${copy.ratioBadge(aspectRatio)}`}
          hint={copy.ratioNote}
          badge={copy.ratioBadge(aspectRatio)}
          active={framingOpen || framingAidsActive || aspectRatio !== '4:3'}
          activeColor={theme.colors.primary}
          onPress={onToggleFraming}
        />
        <ControlButton
          icon="timer-outline"
          label="Capture timer"
          value={timer === 0 ? 'Off' : `${timer} seconds`}
          hint="Cycles off, 3, 5 and 10 seconds"
          badge={timer === 0 ? 'Off' : `${timer}s`}
          onPress={onCycleTimer}
        />
        <ControlButton
          icon="cog-outline"
          label="Camera settings"
          hint="Opens capture, voice and guidance preferences"
          onPress={settings}
        />
      </View>
    </View>
  );
}

/** Scrim height BELOW the safe-area inset; the inset is added on top. */
const SCRIM_BODY_HEIGHT = 96;

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  scrim: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
  },
  button: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 24,
  },
  /* A lit torch and an open brightness panel are STATES, not presses; the
     halo is what makes them visible at a glance without adding a label. */
  activeHalo: {
    position: 'absolute',
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  badge: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    backgroundColor: mediaColors.overlayStrong,
    borderRadius: 8,
    paddingHorizontal: 4,
    paddingVertical: 1,
  },
  badgeText: {
    fontSize: 8,
    fontWeight: '600',
  },
});
