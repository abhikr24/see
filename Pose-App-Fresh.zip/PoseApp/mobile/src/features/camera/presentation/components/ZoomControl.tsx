/**
 * FRAMING — ZoomControl.
 *
 * THE PROBLEM THIS REPLACES (audited on the restored code, not assumed)
 *
 * Zoom was a pinch gesture and a floating "1.0x" pill. Three things were
 * wrong with that:
 *
 *   1. the pinch multiplied expo-camera's normalised 0..1 value by the gesture
 *      scale — and that value is 0 at rest, so `0 × scale` is 0 and spreading
 *      your fingers from the default did nothing;
 *   2. there were no zoom LEVELS, so "give me 2×" meant pinching and guessing;
 *   3. there was no way back to 1× except pinching all the way in, with a pose
 *      to hold while you did it.
 *
 * THE CONTROL
 *
 *   · A row of stops — 1× 2× 4× 8× on the rear camera, 1× 2× 4× on the front —
 *     sitting just above the filter strip, where a thumb already is.
 *   · The stop you are on is filled; an in-between value (you pinched to 2.4×)
 *     is shown on the nearest stop as its exact multiplier, so the readout
 *     never lies about where you are.
 *   · 1× IS THE RESET. Tapping it from anywhere returns the whole frame, which
 *     is the one zoom action a posing user needs in a hurry.
 *   · It is CONTEXTUAL: it appears while you are pinching and while you are
 *     off 1×, and it leaves again. At rest the frame is clean.
 *
 * HONESTY: these are digital-zoom multipliers. This camera foundation exposes
 * no lens selection, so the control never offers the "0.5×" ultra-wide of a
 * stock camera app — that would be a button claiming hardware the app cannot
 * reach. The footnote says "Digital zoom" in the coaching language.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import {
  ZOOM_DEFAULT_X,
  activeZoomStop,
  formatZoom,
  isZoomDefault,
  mediaColors,
  radius,
  spacing,
  zoomStopsFor,
  type CameraStatusCopy,
} from '@shared/index';
import type { CameraFacing } from '@/core/camera/cameraService';
import { AppText } from '@/shared/components/AppText';
import { PressableScale } from '@/shared/components/PressableScale';
import { useAppTheme } from '@/core/theme';

interface ZoomControlProps {
  readonly multiplier: number;
  readonly facing: CameraFacing;
  readonly copy: CameraStatusCopy;
  /** Distance from the bottom of the screen to sit above. */
  readonly bottom: number;
  readonly onSelect: (multiplier: number) => void;
  readonly onReset: () => void;
}

export function ZoomControl({
  multiplier,
  facing,
  copy,
  bottom,
  onSelect,
  onReset,
}: ZoomControlProps) {
  const theme = useAppTheme();
  const stops = zoomStopsFor(facing);
  const snapped = activeZoomStop(multiplier, facing);
  const atDefault = isZoomDefault(multiplier, facing);

  /* Which stop carries the live value when the user is between stops: the
     largest stop at or below the current multiplier. */
  const carrier =
    snapped ??
    stops.reduce((best, stop) => (stop <= multiplier ? stop : best), stops[0] ?? ZOOM_DEFAULT_X);

  return (
    <View style={[styles.root, { bottom }]} pointerEvents="box-none">
      <View
        style={styles.row}
        accessibilityRole="adjustable"
        accessible
        accessibilityLabel={copy.zoomTitle}
        accessibilityValue={{ text: copy.zoomValue(multiplier, facing) }}
        accessibilityHint={copy.zoomNote}
        accessibilityActions={[
          { name: 'increment', label: copy.zoomTitle },
          { name: 'decrement', label: copy.zoomTitle },
          { name: 'activate', label: copy.zoomReset },
        ]}
        onAccessibilityAction={(event) => {
          const action = event.nativeEvent.actionName;
          if (action === 'increment') onSelect(multiplier * 1.5);
          else if (action === 'decrement') onSelect(multiplier / 1.5);
          else if (action === 'activate') onReset();
        }}
      >
        {stops.map((stop) => {
          const isCarrier = stop === carrier;
          const label = isCarrier
            ? formatZoom(multiplier, facing)
            : formatZoom(stop, facing);
          return (
            <PressableScale
              key={stop}
              onPress={() => (stop === ZOOM_DEFAULT_X ? onReset() : onSelect(stop))}
              accessibilityRole="button"
              accessibilityLabel={`${copy.zoomTitle} ${formatZoom(stop, facing)}`}
              accessibilityHint={
                stop === ZOOM_DEFAULT_X && !atDefault ? copy.zoomReset : undefined
              }
              accessibilityState={{ selected: isCarrier }}
              style={[
                styles.stop,
                {
                  backgroundColor: isCarrier
                    ? mediaColors.overlayHeavy
                    : mediaColors.overlaySoft,
                  borderColor: isCarrier ? theme.colors.primary : mediaColors.transparent,
                },
              ]}
            >
              <AppText
                variant="small"
                color={isCarrier ? theme.colors.primary : mediaColors.textMuted}
                style={isCarrier ? styles.activeText : styles.stopText}
              >
                {label}
              </AppText>
            </PressableScale>
          );
        })}
      </View>
      <AppText variant="small" color={mediaColors.textSubtle} style={styles.note}>
        {copy.zoomNote}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    padding: 4,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.overlayMedium,
  },
  stop: {
    minWidth: 44,
    height: 34,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stopText: {
    fontWeight: '600',
  },
  activeText: {
    fontWeight: '700',
  },
  note: {
    marginTop: 4,
    fontSize: 10,
  },
});
