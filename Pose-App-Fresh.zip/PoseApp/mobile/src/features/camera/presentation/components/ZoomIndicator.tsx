/**
 * Unit 12 — ZoomIndicator, rebuilt for FRAMING.
 *
 * The readout itself: one small pill that says how much of the frame you are
 * actually taking. It no longer positions itself — `ZoomControl` owns where
 * zoom lives on screen — so the same pill can be a stop button and the live
 * value without two components disagreeing about type size or shape.
 *
 * It reads "1×", "2×", "2.4×": never "1.0x", because a readout that shows a
 * decimal on the default value is chrome reporting a non-event.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { mediaColors, radius } from '@shared/index';
import { AppText } from '@/shared/components/AppText';

interface ZoomIndicatorProps {
  readonly label: string;
  /** The pill is the current value rather than an idle option. */
  readonly active?: boolean;
  readonly activeColor?: string;
  /** Absolute placement, for the legacy standalone use. */
  readonly top?: number;
}

export function ZoomIndicator({ label, active, activeColor, top }: ZoomIndicatorProps) {
  return (
    <View
      style={[
        styles.pill,
        top === undefined ? null : [styles.floating, { top }],
        active === true && activeColor !== undefined
          ? { borderColor: activeColor, borderWidth: 1 }
          : null,
      ]}
      pointerEvents="none"
    >
      <AppText
        variant="small"
        color={active === true && activeColor !== undefined ? activeColor : mediaColors.text}
        style={styles.text}
      >
        {label}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  pill: {
    minWidth: 44,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.overlayStrong,
    alignItems: 'center',
    justifyContent: 'center',
  },
  floating: {
    position: 'absolute',
    alignSelf: 'center',
  },
  text: {
    fontWeight: '700',
  },
});
