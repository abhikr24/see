/**
 * FRAMING — useDeviceLevel.
 *
 * The horizon guide's only source of truth: the device accelerometer, read
 * through `expo-sensors`.
 *
 * WHY expo-sensors AND NOT SOMETHING ELSE (checked, not assumed)
 *
 *  · It is a first-party Expo module on the SAME SDK (57) as every other
 *    native module this app already ships, MIT-licensed, maintained in the
 *    expo/expo monorepo, and already covered by the app's existing custom
 *    dev-client / prebuild requirement (expo-camera, Skia and MMKV all need
 *    one already), so it adds NO new build story.
 *  · The community alternatives (react-native-sensors, react-native-compass…)
 *    solve the same one problem with an unmanaged native dependency and no
 *    Expo config plugin. Adding a second sensor stack for one horizon line
 *    would be exactly the "multiple libraries for one problem" this codebase
 *    forbids.
 *  · No camera-stack migration is involved: this reads the motion sensor, not
 *    the camera.
 *
 * HONESTY
 *
 *  · Nothing is invented. If the platform has no accelerometer, or refuses it,
 *    `available` stays false and the guide never appears — it does not fall
 *    back to a guess, an animation or a zero.
 *  · On web there is no permissioned DeviceMotion access in this app's preview
 *    target, so the hook reports unavailable rather than pretending.
 *  · The subscription exists ONLY while the caller says it should (camera
 *    focused, framing guide enabled). A sensor left running behind a
 *    backgrounded camera is a battery bug.
 */
import { useEffect, useRef, useState } from 'react';
import { Platform } from 'react-native';
import { Accelerometer } from 'expo-sensors';
import {
  resolveLevel,
  rollFromGravity,
  smoothRoll,
  type LevelResolution,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';

/** ~8 Hz. Fast enough to feel live, slow enough to cost nothing measurable. */
const SAMPLE_INTERVAL_MS = 120;

export interface DeviceLevel {
  /** The sensor answered at least once in this session. */
  readonly available: boolean;
  readonly level: LevelResolution;
}

const UNAVAILABLE: DeviceLevel = {
  available: false,
  level: resolveLevel({ available: false, rollDeg: 0 }),
};

export function useDeviceLevel(active: boolean): DeviceLevel {
  const [state, setState] = useState<DeviceLevel>(UNAVAILABLE);
  const smoothed = useRef<number | null>(null);

  useEffect(() => {
    if (!active || Platform.OS === 'web') {
      smoothed.current = null;
      setState(UNAVAILABLE);
      return;
    }

    let cancelled = false;
    let subscription: { remove: () => void } | null = null;

    (async () => {
      let supported = false;
      try {
        supported = await Accelerometer.isAvailableAsync();
      } catch (error) {
        AppLogger.debug(`[Level] sensor availability unknown — ${String(error)}`);
        supported = false;
      }
      if (cancelled) return;
      if (!supported) {
        AppLogger.info('[Level] no accelerometer — horizon guide stays hidden');
        setState(UNAVAILABLE);
        return;
      }

      Accelerometer.setUpdateInterval(SAMPLE_INTERVAL_MS);
      subscription = Accelerometer.addListener(({ x, y }) => {
        const raw = rollFromGravity(x, y);
        if (raw === null) {
          /* Pointed at the floor or the ceiling: there is no horizon to be
             level with, so the guide stands down instead of spinning. */
          smoothed.current = null;
          setState(UNAVAILABLE);
          return;
        }
        const next = smoothRoll(smoothed.current, raw);
        smoothed.current = next;
        setState({
          available: true,
          level: resolveLevel({ available: true, rollDeg: next }),
        });
      });
    })();

    return () => {
      cancelled = true;
      subscription?.remove();
      subscription = null;
      smoothed.current = null;
    };
  }, [active]);

  return state;
}
