/**
 * useHardwareShutter — Unit 38.
 *
 * Binds the physical volume keys to the capture flow the screen ALREADY has.
 *
 * NON-GOALS, stated so they cannot drift:
 *   · it does not capture. It calls the callback the camera screen already
 *     uses for its own shutter, so the IntelligentCaptureController lock,
 *     the 3 s debounce, the timer, the countdown, the processing overlay and
 *     the save/retake flow are all inherited, not re-implemented;
 *   · it does not decide whether capture is possible. That is
 *     `CameraPresentation.captureEnabled`, passed in;
 *   · it owns no haptics. The press it produces is indistinguishable from a
 *     tap by the time it reaches the capture code, which is where the one
 *     existing haptic lives.
 *
 * WHAT IT DOES OWN: arming. The keys are taken from the system only while
 * the live viewfinder is on screen AND a photo is genuinely possible, and
 * they are handed straight back on blur, background, countdown, capture,
 * processing, an error banner, or unmount. That release is the difference
 * between a camera feature and a phone that has stopped answering its volume
 * keys.
 */
import { useEffect, useRef } from 'react';
import {
  HardwareShutterGate,
  resolveHardwareShutterArming,
  type HardwareShutterKey,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';
import {
  hardwareShutterCapability,
  setHardwareShutterArmed,
  subscribeHardwareShutter,
} from '@/core/camera/hardwareShutterService';

interface UseHardwareShutterOptions {
  /** Persisted user preference (Settings → Volume key shutter). */
  readonly enabled: boolean;
  /** Focused AND foregrounded AND the viewfinder is mounted. */
  readonly sessionLive: boolean;
  /** `CameraPresentation.captureEnabled` — the SAME gate as the tap target. */
  readonly captureEnabled: boolean;
  /** The screen's existing manual-capture entry point. */
  readonly onPress: (key: HardwareShutterKey) => void;
}

export interface HardwareShutterState {
  /** True only while the keys are genuinely being consumed by this app. */
  readonly armed: boolean;
  /** True when this build has a real hardware source at all. */
  readonly available: boolean;
}

export function useHardwareShutter({
  enabled,
  sessionLive,
  captureEnabled,
  onPress,
}: UseHardwareShutterOptions): HardwareShutterState {
  const capability = hardwareShutterCapability();
  const { armed } = resolveHardwareShutterArming({
    capability,
    enabledByUser: enabled,
    sessionLive,
    captureEnabled,
  });

  const gate = useRef(new HardwareShutterGate());
  /* The subscription is created once and reads the latest arming/callback
     through refs: re-subscribing on every frame of a live camera session
     would drop key events in the gap. */
  const armedRef = useRef(armed);
  armedRef.current = armed;
  const pressRef = useRef(onPress);
  pressRef.current = onPress;

  useEffect(() => {
    if (capability !== 'available') return undefined;
    const subscription = subscribeHardwareShutter((press) => {
      const verdict = gate.current.evaluate({
        nowMs: Date.now(),
        key: press.key,
        repeat: press.repeat,
        armed: armedRef.current,
      });
      if (verdict !== 'accepted') {
        /* Debug, not warn: a rejected repeat is the NORMAL outcome of
           holding a key down, and a log at warning level would make correct
           behaviour look like a fault. */
        AppLogger.debug(`[HardwareShutter] ${press.key} ${verdict}`);
        return;
      }
      AppLogger.info(`[HardwareShutter] ${press.key} accepted — manual capture requested`);
      pressRef.current(press.key);
    });
    return () => {
      subscription.remove();
    };
  }, [capability]);

  useEffect(() => {
    if (capability !== 'available') return undefined;
    setHardwareShutterArmed(armed);
    if (!armed) gate.current.reset();
    return () => {
      /* Unmount/blur must ALWAYS release the keys, even if the effect body
         above never ran its arming branch. */
      setHardwareShutterArmed(false);
    };
  }, [armed, capability]);

  return { armed, available: capability === 'available' };
}
