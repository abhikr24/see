/**
 * Unit 12 — CameraTab (state machine).
 *
 * Order of gates matters and is deliberate:
 *   1. No poseId            → State 1 (NoPoseState). Needs NO camera and NO
 *                             camera permission, so it is checked FIRST.
 *   2. Unknown pose id      → recoverable "pose unavailable" screen.
 *   3. Web                  → unsupported notice (expo-camera has no viewfinder
 *                             in this project's web target).
 *   4. Permission pending   → auto-request fires once, spinner shown.
 *   5. Permission denied    → retry card, or Open Settings when locked.
 *   6. Mount error          → explicit failure card with Try Again.
 *   7. Granted              → State 2, the live camera shell.
 *
 * Session invariants: the CameraView mounts ONLY while State 2 is reached AND
 * the tab is focused AND the app is foregrounded. Losing any of those
 * conditions unmounts it (true release, ref nulled); regaining them mounts a
 * fresh one. Exactly one CameraView can exist at any moment.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  AppState,
  Platform,
  StyleSheet,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import {
  IntelligentCaptureController,
  aspectFrameBox,
  cameraStatusCopyFor,
  captureBrightnessLevel,
  exposureCompensationProp,
  filterZoneClearance,
  resolveExposureMechanism,
  resolveFramingVisibility,
  resolveLighting,
  getPoseById,
  mediaColors,
  radius,
  resolveCameraPresentation,
  routeCoachingSpeech,
  sizing,
  spacing,
  visibleCoachingFor,
  type CaptureTrigger,
  type CoachingState,
  type HoldSource,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { openSystemSettings } from '@/core/permissions/permissionService';
import {
  takePicture,
  useCameraSession,
  zoomLabel,
  type TimerSeconds,
} from '@/core/camera/cameraService';
import { applyCaptureFraming } from '@/core/camera/photoBrightness';
/* A1 — the live pose input is now a NATIVE frame pipeline (VisionCamera
   frame output → ML Kit Nitro plugin → shared adapter → same PoseLandmark
   contract). The old WASM service + 66ms takePictureAsync pump are gone;
   see mobile/docs/a1-native-realtime-pose.md. */
import { createNativePoseDetector } from '@/core/ml/nativePosePlugin';
import {
  createPoseFrameRuntime,
  type PoseFrameRuntime,
  type PoseFrameConsumption,
} from '@/core/ml/poseFrameRuntime';
import { useNativePoseFrameOutput } from '@/core/ml/useNativePoseFrameOutput';
import { useCameraPermissionState } from '@/core/camera/visionCameraPermission';
import type { NativePoseDetectorHandle } from '@/core/ml/nativePosePlugin';
import { matchFromDecision } from '@/core/ml/poseAnalysisEngine';
import {
  analysisInputFromPin,
  isReadyResolution,
  pinReferenceForSession,
  referenceProvider,
  templateMeasurementMap,
  type PinnedReference,
} from '@/core/reference/referenceProvider';
import {
  createPoseAnalysisEngine,
  decisionToGuidance,
  type PoseAnalysisEngine,
} from '@/core/ml/poseAnalysisEngine';
import { decisionToCoachingState } from '@/core/coaching';
import {
  detectHandPresentation,
  handDetectorService,
  selectCaptureHand,
  OpenPalmGate,
  type OpenPalmEvidence,
  type OpenPalmPhase,
} from '@/core/ml/gestureDetector';
import { ttsService } from '@/core/voice/ttsService';
import { type GuidanceResult } from '@/core/ml/guidanceGenerator';
import {
  deleteLocalPhotoFile,
  galleryLocalDatasource,
} from '@/features/gallery/data/datasources/galleryLocalDatasource';
import { AppButton } from '@/shared/components/AppButton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { NoPoseState } from '../components/NoPoseState';
import { CameraPreview } from '../components/CameraPreview';
import { TopControlsBar } from '../components/TopControlsBar';
import { BrightnessControl } from '../components/BrightnessControl';
import { BottomControlsBar } from '../components/BottomControlsBar';
import { FilterStrip } from '../components/FilterStrip';
import { ZoomControl } from '../components/ZoomControl';
import { FramingControl } from '../components/FramingControl';
import { AspectRatioMask } from '../components/AspectRatioMask';
import { LevelIndicator } from '../components/LevelIndicator';
import { useDeviceLevel } from '../hooks/useDeviceLevel';
import { ReferenceOverlay } from '../components/ReferenceOverlay';
import { useAuthStore } from '@/shared/stores/authStore';
import { CountdownOverlay } from '../components/CountdownOverlay';
/* Unit 38 — VOLUME-BUTTON SHUTTER. A fourth INPUT, not a fourth capture
   mechanism: the hook below calls `beginManualCapture`, so every press lands
   in the one existing IntelligentCaptureController. */
import { useHardwareShutter } from '../hooks/useHardwareShutter';
import { ProcessingOverlay } from '../components/ProcessingOverlay';
import { PoseSilhouetteOverlay } from '../components/PoseSilhouetteOverlay';
/* Camera UX Part 2 — the match pill, the voice chip and the floating
   hold-progress card were three separate pieces of glass saying one thing.
   They are now the status rail (top) and the shutter ring (bottom). */
import { CameraStatusRail } from '../components/CameraStatusRail';
import { ModelLoadingOverlay } from '../components/ModelLoadingOverlay';
import { GuidanceOverlay } from '../components/GuidanceOverlay';
import { GridOverlay } from '../components/GridOverlay';
import { CaptureErrorBanner } from '../components/CaptureErrorBanner';
import { useSettingsStore } from '@/shared/stores/settingsStore';
import { ErrorRetryWidget } from '@/shared/components/ErrorRetryWidget';
import { errorHandler } from '@/core/error/errorHandler';
import type { PoseLandmark } from '@shared/index';

function normalizePoseId(raw: string | string[] | undefined): string | null {
  if (typeof raw === 'string' && raw.length > 0) return raw;
  if (Array.isArray(raw) && typeof raw[0] === 'string' && raw[0].length > 0) return raw[0];
  return null;
}

/** Shared full-screen message layout for every non-preview camera state. */
function CameraNotice({
  icon,
  title,
  body,
  primaryLabel,
  onPrimary,
  secondaryLabel,
  onSecondary,
  busy = false,
}: {
  readonly icon: string;
  readonly title: string;
  readonly body: string;
  readonly primaryLabel?: string;
  readonly onPrimary?: () => void;
  readonly secondaryLabel?: string;
  readonly onSecondary?: () => void;
  readonly busy?: boolean;
}) {
  const theme = useAppTheme();
  return (
    <SafeAreaView style={[styles.noticeRoot, { backgroundColor: theme.colors.background }]}>
      <View style={[styles.noticeIcon, { backgroundColor: theme.colors.primaryLight }]}>
        {busy ? (
          <ActivityIndicator color={theme.colors.primary} />
        ) : (
          <IconSymbol name={icon} size={32} color={theme.colors.primary} />
        )}
      </View>
      <AppText variant="heading" color={theme.colors.textPrimary} style={styles.noticeTitle}>
        {title}
      </AppText>
      <AppText
        variant="secondaryBody"
        color={theme.colors.textSecondary}
        align="center"
        style={styles.noticeBody}
      >
        {body}
      </AppText>
      {primaryLabel !== undefined && onPrimary !== undefined && (
        <AppButton title={primaryLabel} onPress={onPrimary} style={styles.noticeButton} />
      )}
      {secondaryLabel !== undefined && onSecondary !== undefined && (
        <AppButton
          title={secondaryLabel}
          onPress={onSecondary}
          variant="ghost"
          style={styles.noticeSecondary}
        />
      )}
    </SafeAreaView>
  );
}

export function CameraTab() {
  const theme = useAppTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width: windowWidth, height: windowHeight } = useWindowDimensions();
  const userId = useAuthStore((state) => state.session?.id ?? null);
  const params = useLocalSearchParams<{ poseId?: string | string[] }>();
  const poseId = normalizePoseId(params.poseId);
  const pose = poseId !== null ? getPoseById(poseId) : null;

  /* A1 — engine swap: same shape, VisionCamera underneath. The screens
     below (auto-ask effect, retry card, Open-Settings card) are untouched. */
  const visionPermission = useCameraPermissionState();
  const permission = useMemo(
    () => ({
      granted: visionPermission.granted,
      canAskAgain: visionPermission.canAskAgain,
    }),
    [visionPermission.granted, visionPermission.canAskAgain],
  );
  const requestPermission = visionPermission.requestPermission;
  const [focused, setFocused] = useState(false);
  const [appActive, setAppActive] = useState(AppState.currentState === 'active');
  const [mountError, setMountError] = useState<string | null>(null);
  const [requesting, setRequesting] = useState(false);
  const [countdownSeconds, setCountdownSeconds] = useState<3 | 5 | 10 | null>(null);
  const [countdownTrigger, setCountdownTrigger] = useState<CaptureTrigger | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const [galleryThumbnailUri, setGalleryThumbnailUri] = useState<string | null>(null);
  /* A FAILED SHUTTER IS NOT A FAILED CAMERA. Kept separate from `mountError`
     so a transient capture/save error no longer tears down the viewfinder and
     the MediaPipe session (see CaptureErrorBanner for the full rationale). */
  const [captureError, setCaptureError] = useState<string | null>(null);
  const askedOnce = useRef(false);
  const captureAttempt = useRef(0);
  /* A1 — one pose frame runtime per mounted screen (never recreated). */
  const poseRuntimeRef = useRef<PoseFrameRuntime | null>(null);
  if (poseRuntimeRef.current === null) {
    poseRuntimeRef.current = createPoseFrameRuntime();
  }
  const [nativeDetector, setNativeDetector] = useState<NativePoseDetectorHandle | null>(null);

  // ── Unit 20: Camera & Capture Preferences ────────────────────────────
  const flashDefault = useSettingsStore((s) => s.flashDefault);
  const timerDefault = useSettingsStore((s) => s.timerDefault);
  const filterDefault = useSettingsStore((s) => s.filterDefault);
  const gridOverlayEnabled = useSettingsStore((s) => s.gridOverlayEnabled);
  const autoThreshold = useSettingsStore((s) => s.autoThreshold);
  const voiceEnabled = useSettingsStore((s) => s.voiceEnabled);
  const gestureEnabled = useSettingsStore((s) => s.gestureEnabled);
  const countdownDuration = useSettingsStore((s) => s.countdownDuration);
  const hapticEnabled = useSettingsStore((s) => s.hapticEnabled);
  /* Unit 38 — may the app take the physical volume keys while the
     viewfinder is live? Default on; OFF means they are never intercepted. */
  const volumeShutterEnabled = useSettingsStore((s) => s.volumeShutterEnabled);
  /* Unit 37: ONE coaching language for this screen — the visible band, the
     status copy and the spoken cue all read this single value. */
  const instructionLanguage = useSettingsStore((s) => s.instructionLanguage);
  const voiceIds = useSettingsStore((s) => s.voiceIds);

  /* Unit 35 (Part 4.4) — the persisted voice preferences are mirrored into
     the speech layer; the store stays the single source of truth and the TTS
     service keeps owning no storage. Turning voice guidance off also stops
     whatever is playing, while the semantic coaching state below keeps
     flowing to the overlay and the capture controller. */
  useEffect(() => {
    ttsService.setVoiceGuidanceEnabled(voiceEnabled);
  }, [voiceEnabled]);

  useEffect(() => {
    ttsService.setPreferredVoiceId('en', voiceIds.en);
    ttsService.setPreferredVoiceId('hi', voiceIds.hi);
  }, [voiceIds]);

  useEffect(
    () => () => {
      if (zoomHideTimer.current !== null) clearTimeout(zoomHideTimer.current);
    },
    [],
  );

  const markZoomEngaged = useCallback(() => {
    setZoomEngaged(true);
    if (zoomHideTimer.current !== null) clearTimeout(zoomHideTimer.current);
    zoomHideTimer.current = setTimeout(() => setZoomEngaged(false), ZOOM_PILL_LINGER_MS);
  }, []);

  // ── Unit 16–17: ML overlay & visual guidance state (State 2 only) ────
  const [mlStatus, setMlStatus] = useState<'idle' | 'loading' | 'ready' | 'unavailable'>('idle');
  const [poseLandmarks, setPoseLandmarks] = useState<readonly PoseLandmark[] | null>(null);
  const [matchPercent, setMatchPercent] = useState<number | null>(null);
  const [guidance, setGuidance] = useState<GuidanceResult | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  /* Camera UX Part 1 — the SEMANTIC coaching state now reaches the screen.
     It was already produced on every frame for the speech planner and then
     thrown away by the UI, which is why the overlay could only ever describe
     corrections and had nothing to say about "I can't see you",
     "confidence too low" or "this pose has no usable reference". */
  const [coaching, setCoaching] = useState<CoachingState | null>(null);
  const [autoProgress, setAutoProgress] = useState(0);
  const [gestureProgress, setGestureProgress] = useState(0);
  /* GESTURE CAPTURE — the phase the open-palm gate is in, for the shutter
     ring's label only. Idle/cooldown render as an empty string, so the normal
     state of this readout is "nothing at all". */
  const [gesturePhase, setGesturePhase] = useState<OpenPalmPhase>('idle');
  const [mlFrameSize, setMlFrameSize] = useState<{ width: number; height: number } | null>(null);
  const [mlRetryToken, setMlRetryToken] = useState(0);
  /* Camera UX Part 2 — the zoom readout is transient. It appears while the
     user is pinching (or while zoom is off its 1.0x default) and fades again,
     instead of permanently occupying the frame to report a non-event. */
  const [zoomEngaged, setZoomEngaged] = useState(false);
  const zoomHideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  /* One haptic per readiness EPISODE, never per frame. */
  const readyHapticArmed = useRef(true);
  const matchSmoothing = useRef<number | null>(null);
  const intelligentCapture = useRef(new IntelligentCaptureController());
  /* ONE gate per screen, for the whole session: it carries the hold, the
     stillness history, the cooldown and the release requirement across
     frames, which is exactly the memory a single-frame detector lacks. */
  const openPalmGate = useRef(new OpenPalmGate());
  const captureFlowActive = useRef(false);
  const intelligentTrigger = useRef<(trigger: CaptureTrigger) => void>(() => undefined);

  const facing = useCameraSession((s) => s.facing);
  const flash = useCameraSession((s) => s.flash);
  const timer = useCameraSession((s) => s.timer);
  const filter = useCameraSession((s) => s.filter);
  /* LOOKS — the look AND its strength. Both are session state for the same
     reason brightness is: they are read once at the shutter and baked into
     the file, so the viewfinder wash, the strip and the capture pipeline must
     read one value, never three copies. */
  const filterIntensity = useCameraSession((s) => s.filterIntensity);
  const filterPanelOpen = useCameraSession((s) => s.filterPanelOpen);
  /* FRAMING — zoom is the multiplier the user reads; the shape, the level
     switch and the framing sheet live beside it so the viewfinder overlays,
     the control bar and the capture pipeline share one truth. */
  const zoomX = useCameraSession((s) => s.zoomX);
  const aspectRatio = useCameraSession((s) => s.aspectRatio);
  const levelGuideEnabled = useCameraSession((s) => s.levelGuideEnabled);
  const framingPanelOpen = useCameraSession((s) => s.framingPanelOpen);
  /* CAMERA CONTROLS — continuous light + photo brightness. Both are session
     state, both are transient (reset with the session), and both are read
     here so the viewfinder, the control bar and the capture pipeline can
     never disagree about their values. */
  const torchRequested = useCameraSession((s) => s.torchRequested);
  const brightness = useCameraSession((s) => s.brightness);
  const brightnessPanelOpen = useCameraSession((s) => s.brightnessPanelOpen);
  /* D1 — the native exposure bridge's capability report for the BOUND camera;
     null until the bound device reports on this build/session. */
  const exposureCapabilities = useCameraSession((s) => s.exposureCapabilities);
  const isCameraReady = useCameraSession((s) => s.isCameraReady);

  const needsCamera = poseId !== null && Platform.OS !== 'web';

  useFocusEffect(
    useCallback(() => {
      setFocused(true);
      const session = useCameraSession.getState();
      session.setFlash(flashDefault);
      session.setTimer(timerDefault);
      session.setFilter(filterDefault);
      setGalleryThumbnailUri(
        userId === null
          ? null
          : galleryLocalDatasource.getPhotos(userId)[0]?.imagePath ?? null,
      );
      // Unit 27: warm the native voice catalog while permissions/focus
      // settle, so the first coaching cue has no discovery delay.
      ttsService.warmup();
      return () => {
        captureAttempt.current += 1;
        setCountdownSeconds(null);
        setCountdownTrigger(null);
        setIsProcessing(false);
        setIsCapturing(false);
        setIsSpeaking(false);
        setCoaching(null);
        setAutoProgress(0);
        setGestureProgress(0);
        setGesturePhase('idle');
        captureFlowActive.current = false;
        intelligentCapture.current.reset();
        openPalmGate.current.reset();
        void ttsService.stop();
        ttsService.resetSession();
        setFocused(false);
        useCameraSession.getState().setCameraReady(false);
        AppLogger.info('[Camera] tab blurred — session released');
      };
    }, [userId, flashDefault, timerDefault, filterDefault]),
  );

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (next) => {
      const active = next === 'active';
      setAppActive(active);
      if (!active) {
        captureAttempt.current += 1;
        setCountdownSeconds(null);
        setCountdownTrigger(null);
        setIsProcessing(false);
        setIsCapturing(false);
        setIsSpeaking(false);
        setCoaching(null);
        setAutoProgress(0);
        setGestureProgress(0);
        setGesturePhase('idle');
        captureFlowActive.current = false;
        intelligentCapture.current.reset();
        openPalmGate.current.reset();
        void ttsService.stop();
        ttsService.resetSession();
        useCameraSession.getState().setCameraReady(false);
        AppLogger.info('[Camera] app backgrounded — session released');
      }
    });
    return () => subscription.remove();
  }, []);

  /**
   * The actual permission request. Previously this never fired on its own,
   * so opening the tab looked like a dead screen; now entering State 2 with
   * an undetermined permission triggers the OS dialog exactly once.
   */
  const askForCamera = useCallback(async () => {
    setRequesting(true);
    AppLogger.info('[Camera] requesting camera permission');
    try {
      const result = await requestPermission();
      AppLogger.info(
        `[Camera] permission result → ${result.granted ? 'granted' : result.canAskAgain ? 'denied' : 'blocked'}`,
      );
      void result;
    } catch (error) {
      errorHandler.handle(error, 'Camera/Permission');
    } finally {
      setRequesting(false);
    }
  }, [requestPermission]);

  useEffect(() => {
    if (!needsCamera || !focused) return;
    if (permission === null || permission.granted) return;
    if (!permission.canAskAgain || askedOnce.current) return;
    askedOnce.current = true;
    void askForCamera();
  }, [needsCamera, focused, permission, askForCamera]);

  // A new pose gets a fresh error slate.
  useEffect(() => {
    setMountError(null);
  }, [poseId, facing]);

  /**
   * A1 — NATIVE pose session lifecycle, bound 1:1 to State 2.
   * The session opens only while the live viewfinder is actually mounted
   * (focused + foregrounded + permission granted); unmount/blur/background
   * stops the frame runtime, releases the native ML Kit detector and clears
   * every overlay, mirroring the camera release invariant. Input is a real
   * native camera-frame stream (VisionCamera frame output — NO stills, NO
   * JPEG/base64, NO disk churn); admission runs through the shared bounded
   * scheduler (15fps result budget, latest-wins, staleness bound) and the
   * Skia overlay repaints only when landmarks change (60fps UI stays free).
   * If this build cannot do native frame processing, the feature parks as
   * 'unavailable' alone — the camera loses overlays, nothing else (scoped
   * per-feature fallback, logged, NEVER faked via still-photo sampling).
   */
  const mlGateOpen =
    pose !== null &&
    permission?.granted === true &&
    mountError === null &&
    !requesting &&
    focused &&
    appActive &&
    Platform.OS !== 'web';

  useEffect(() => {
    if (!mlGateOpen || pose === null) return undefined;
    /**
     * Unit 28: the session's reference source of truth is a PINNED, validated
     * ReferencePoseTemplate resolved through the reference provider — never a
     * raw catalog field. The engine consumes only the pinned projection;
     * identity (templateId + schema/measurement versions + contentHash) is
     * frozen for the lifetime of this effect, so the reference cannot
     * silently change mid-session. On any resolution failure no engine is
     * created — identical UX to a pose that ships no reference (match shows
     * "stand into frame", camera keeps working), and never coaching from
     * substituted numbers.
     */
    let referencePin: PinnedReference | null = null;
    /* Unit 29: the deterministic analysis engine is created ONCE per session,
       from the pinned template. The frame loop only feeds it landmarks — it
       never re-resolves, re-validates or re-fetches reference data. */
    let analysisEngine: PoseAnalysisEngine | null = null;
    let cancelled = false;
    const runtime = poseRuntimeRef.current;
    setMlStatus('loading');
    matchSmoothing.current = null;
    AppLogger.info(`[ML] guidance session start (pose=${pose.id}) — native frame pipeline`);

    /* A1 — the frame CONSUMER: exactly the downstream the old pump fed per
       processed frame (gesture → engine → coaching → speech → match →
       intelligent capture), invoked by the pose frame runtime after the
       shared scheduler admitted a native result and the shared adapter
       produced the EXISTING PoseLandmark[] contract. */
    const consumePoseFrame = (consumption: PoseFrameConsumption): void => {
      // Once any trigger owns the capture flow, pose results pause so the
      // camera is idle for the real shutter (same guard as the old pump).
      if (cancelled || captureFlowActive.current) return;
      const detected = consumption.landmarks;
      if (detected === null) return; // unusable frame — skip (no schedule drift)
      try {
        if (consumption.frame.width > 0 && consumption.frame.height > 0) {
          setMlFrameSize({ width: consumption.frame.width, height: consumption.frame.height });
        }
        setPoseLandmarks(detected.length > 0 ? detected : null);

        /* ── GESTURE CAPTURE, EVALUATED EXACTLY ONCE PER FRAME ──────────────
           Ordered cheapest-first so the expensive step is rare:
             1. gesture capture off            → nothing runs at all;
             2. no body                        → nothing runs (a capture
                gesture with nobody in frame is not a photograph anyone
                wants, and it is a free false-positive filter);
             3. pose pre-filter says no raised hand → no hand inference;
             4. hand landmarker unavailable    → gesture simply never fires.
                It deliberately does NOT fall back to the old pose-only
                guess: that guess IS the accidental-capture bug.
           Only when all four pass does one HandLandmarker inference run, and
           even then its verdict is single-frame EVIDENCE — the gate below
           decides whether it is a command. */
        /* A1: the native frame pipeline produces landmarks, not decodable
           images — the WASM hand landmarker (web-era) cannot consume native
           frames and, exactly as before, stays 'unavailable' in this build;
           the evidence path therefore evaluates to null. The native hand
           bridge (a second model on the SAME plugin boundary) replaces this
           comment when it lands. Gate + pre-filter semantics are UNCHANGED. */
        let gestureEvidence: OpenPalmEvidence | null = null;
        if (gestureEnabled && detected.length > 0 && handDetectorService.isModelReady) {
          const presentation = detectHandPresentation(detected);
          void presentation;
          void selectCaptureHand;
        }
        const gate = openPalmGate.current.update({
          nowMs: Date.now(),
          evidence: gestureEnabled ? gestureEvidence : null,
        });
        setGesturePhase(gestureEnabled ? gate.phase : 'idle');
        /* One decision per frame: the engine owns measurement → comparison →
           severity → priority → temporal stability. It is fed on EVERY frame
           (including body-lost frames) so its temporal memory stays in sync
           with what the camera actually saw. */
        const decision = analysisEngine?.analyzeFrame(detected) ?? null;
        /* Unit 30: ONE semantic coaching state per frame, derived from that
           decision. It is produced on EVERY frame — including body-lost and
           reference-unavailable frames — so the speech cadence planner sees
           real state transitions instead of guessing from silence. */
        const coachingState =
          decision === null ? null : decisionToCoachingState(decision);
        /* ONE state object, TWO consumers: the routing gate below (speech)
           and the coaching band (screen). Neither derives anything the
           engine already decided. */
        setCoaching(coachingState);
        /* Unit 35: ONE routing gate decides whether this frame may be
           voiced and in WHICH language (shared/voice/routing). It never
           consumes the semantic state — `route.state` is the same object,
           still available to every non-TTS consumer below even when voice
           guidance is off. */
        const route = routeCoachingSpeech({
          state: coachingState,
          voiceGuidanceEnabled: voiceEnabled,
          language: instructionLanguage,
          captureInProgress: captureFlowActive.current,
        });
        if (route.deliverToSpeech && route.state !== null) {
          void ttsService.speakCoaching(
            route.state,
            route.language,
            Date.now(),
            setIsSpeaking,
          );
        } else if (
          route.state !== null &&
          route.suppression === 'state-not-speakable'
        ) {
          /* Unit 36 (Part 4.5) — THE OBSERVATION PATH.
             Frames the engine marked unjudgeable (body lost, reference
             unusable, still evaluating) must not be spoken — and before this
             they were also never SHOWN to the cadence planner, because the
             routing gate short-circuited them. The planner's silence handling
             was therefore dead in the real app: a perfect episode interrupted
             by the subject stepping out could never be confirmed again, and a
             genuine re-entry waited out the interval of a state that no longer
             existed. `observeCoaching` feeds the planner and CANNOT speak. */
          ttsService.observeCoaching(route.state, Date.now());
        }
        /* Unit 31: ONE geometry pass per frame. The match % is derived from
           the comparisons the engine already computed (bit-identical to the
           legacy calculateMatchPercent pass — see
           tests/analysis/matchScore.test.ts), instead of re-deriving all
           eight joint angles a second time in the hot loop. */
        const result = matchFromDecision(decision);
        if (result.percent === null) {
          matchSmoothing.current = null;
          setMatchPercent(null);
          setGuidance(null);
          setAutoProgress(0);
          /* Body lost / reference unusable: the POSE hold resets so a later
             re-entry re-earns it. The GESTURE hold is not thrown away here —
             it is owned by the gate, which was already fed this frame above,
             and an unmatchable body is not evidence about the user's hand. */
          const captureState = intelligentCapture.current.update({
            nowMs: Date.now(),
            matchPercent: null,
            autoThreshold,
            gestureConfirmed: gate.confirmed,
            gestureProgress: gate.progress,
            autoEnabled: true,
            gestureEnabled,
          });
          setGestureProgress(captureState.gestureProgress);
          if (captureState.trigger !== null) {
            openPalmGate.current.notifyCaptureCommitted(Date.now());
            intelligentTrigger.current(captureState.trigger);
          }
        } else {
          // Mild EMA so the pill tracks the user smoothly instead of jittering
          // frame to frame; 0.35 keeps it responsive inside one guidance beat.
          const previous = matchSmoothing.current;
          const smoothed =
            previous === null ? result.percent : previous + (result.percent - previous) * 0.35;
          matchSmoothing.current = smoothed;
          setMatchPercent(Math.round(smoothed));

          /* Unit 17 copy + Unit 27 voice categories, now driven by the ONE
             semantic decision the Unit 29 engine already made. */
          const guidanceResult =
            decision === null ? null : decisionToGuidance(decision);
          setGuidance(guidanceResult);
          /* Voice is NOT driven from this visible result any more (Unit 30):
             both the overlay copy and the spoken cue descend from the same
             semantic state, but speech cadence is owned by the coaching
             planner above — the UI no longer decides when the coach talks. */

          const captureState = intelligentCapture.current.update({
            nowMs: Date.now(),
            matchPercent: Math.round(smoothed),
            autoThreshold,
            /* An EDGE, true on exactly one frame per deliberate presentation
               — not a per-frame "a palm is visible" boolean. */
            gestureConfirmed: gate.confirmed,
            gestureProgress: gate.progress,
            autoEnabled: true,
            gestureEnabled,
          });
          setAutoProgress(captureState.autoProgress);
          setGestureProgress(captureState.gestureProgress);
          if (captureState.trigger !== null) {
            /* Extend the gate's lock across countdown + shutter + save, so a
               palm still up when the camera returns cannot fire again. */
            openPalmGate.current.notifyCaptureCommitted(Date.now());
            intelligentTrigger.current(captureState.trigger);
          }
        }
      } catch (error) {
        /* A consumption crash cancels this frame only — the runtime counts,
           the loop lives (same resilience as the old pump's try/finally). */
        AppLogger.warn(`[ML] frame consumption error — ${String(error)}`);
      }
    };

    void (async () => {
      /* Reference resolution comes FIRST: the match/guidance math only ever
         sees the pinned template's projection, pinned for this session. */
      const resolution = await referenceProvider.getReference({ poseId: pose.id });
      if (cancelled) return;
      if (isReadyResolution(resolution)) {
        const projection = templateMeasurementMap(resolution.template);
        if (projection.ok) {
          referencePin = pinReferenceForSession(
            resolution.template,
            `camera:${pose.id}`,
            Date.now(),
          );
          const analysisInput = analysisInputFromPin(referencePin);
          if (analysisInput.ok) {
            analysisEngine = createPoseAnalysisEngine({
              reference: analysisInput.input,
              sessionId: `camera:${pose.id}`,
            });
            if (analysisEngine.referenceState !== 'ready') {
              AppLogger.warn(
                `[ML] analysis engine idle: ${analysisEngine.referenceFailure?.message ?? 'reference unusable'}`,
              );
            }
          } else {
            AppLogger.warn(
              `[ML] analysis projection refused: ${analysisInput.failure.message} — guidance idle`,
            );
          }
          AppLogger.info(
            `[ML] reference pinned (${resolution.template.templateId}, ` +
              `m${resolution.template.measurementVersion}, hash ${referencePin.identity.contentHash}, ` +
              `${resolution.template.availability.availableCount} measurements, ` +
              `provenance ${resolution.template.metadata.provenance})`,
          );
        } else {
          AppLogger.warn(
            `[ML] reference projection refused: ${projection.failure.message} — guidance idle`,
          );
        }
      } else {
        AppLogger.warn(
          `[ML] reference ${resolution.failure.kind}: ${resolution.failure.message} — guidance idle`,
        );
      }
      /* A1 — native detector: construction performs the real ML Kit
         PoseDetector allocation (bundled model; first-frame lazy init). null
         ⇒ this build cannot process native frames ⇒ 'unavailable', and NO
         still-photo fallback is ever engaged (A1 rule). */
      const detector = createNativePoseDetector();
      if (cancelled) {
        detector?.dispose();
        return;
      }
      const started = runtime?.start(detector, consumePoseFrame) ?? 'unavailable';
      setMlStatus(started === 'running' ? 'ready' : 'unavailable');
      if (started !== 'running') return;
      setNativeDetector(detector);
      /* Gesture capture warms its own landmarker ONCE per session, off the
         critical path: the pose overlay must never wait for it, and a failure
         only switches gesture capture off (never the camera, never coaching).
         Not awaited, not retried, not re-created per frame. */
      if (gestureEnabled) {
        void handDetectorService.init().then((gestureReady) => {
          if (!gestureReady) {
            AppLogger.info('[Gesture] palm capture inactive — hand model unavailable');
          }
        });
      }
    })();

    return () => {
      cancelled = true;
      analysisEngine?.reset();
      analysisEngine = null;
      setNativeDetector(null);
      /* Frame output detaches first (state above), then the runtime releases
         the native detector — in-flight frames on the camera thread fail
         safe via the plugin's close guard and a stopped runtime. */
      runtime?.stop();
      setMlStatus('idle');
      setPoseLandmarks(null);
      setMatchPercent(null);
      setGuidance(null);
      setIsSpeaking(false);
      setCoaching(null);
      setAutoProgress(0);
      setGestureProgress(0);
      setGesturePhase('idle');
      setMlFrameSize(null);
      matchSmoothing.current = null;
      captureFlowActive.current = false;
      intelligentCapture.current.reset();
      openPalmGate.current.reset();
      handDetectorService.dispose();
      void ttsService.stop();
      ttsService.resetSession();
      AppLogger.info('[ML] guidance session end — native runtime stopped, overlays cleared');
    };
  }, [mlGateOpen, mlRetryToken, pose?.id]);

  /* A1 — the native frame output: exists ONLY while a detector is live and
     the ML gate is open; the Camera attaches/detaches it via this prop. */
  const poseFrameOutputBridge = useNativePoseFrameOutput({
    enabled: mlGateOpen && nativeDetector !== null && mlStatus === 'ready',
    detector: nativeDetector,
    runtime: poseRuntimeRef.current,
  });
  const poseFrameOutput = poseFrameOutputBridge?.frameOutput ?? null;

  /* A1 — facing switch: invalidate the runtime epoch so an in-flight
     old-camera result can never be judged against the new camera. Per-frame
     mirror/orientation metadata already keeps coordinates honest across the
     switch; this is the explicit stale-evidence cut (switch ⇒ 1 invalidation,
     not a detector rebuild — the ML Kit stream resumes instantly). */
  const previousFacingRef = useRef(facing);
  useEffect(() => {
    if (previousFacingRef.current === facing) return;
    previousFacingRef.current = facing;
    poseRuntimeRef.current?.invalidateEpoch();
  }, [facing]);

  const performCapture = useCallback(async () => {
    if (isCapturing || pose === null || !isCameraReady || !focused || !appActive) return;
    /* Read ONCE, at the shutter. A value the user changes while the photo is
       being written must not retroactively re-brighten it. */
    const brightnessAtCapture = useCameraSession.getState().brightness;
    /* D1 — the mechanism at the shutter (read from the same single store
       snapshot, like the detent itself): under native exposure the SENSOR
       has already carried the adjustment, so the pixel pipeline must receive
       the identity detent and stay out of the photograph entirely. */
    const mechanismAtCapture = resolveExposureMechanism(
      useCameraSession.getState().exposureCapabilities,
    );
    /* FRAMING — the shape is read at the same instant and for the same
       reason: the photograph must be the frame the user was looking at when
       they fired, not the one they chose while it was being written. */
    const shapeAtCapture = useCameraSession.getState().aspectRatio;
    /* LOOKS — read at the same instant, for the same reason. The look is part
       of the photograph now, not a label on it. */
    const lookAtCapture = useCameraSession.getState().filter;
    const lookStrengthAtCapture = useCameraSession.getState().filterIntensity;
    const attempt = captureAttempt.current + 1;
    captureAttempt.current = attempt;
    setCountdownSeconds(null);
    setCountdownTrigger(null);
    setCaptureError(null);
    setIsCapturing(true);
    let captureSucceeded = false;

    try {
      const photo = await takePicture();
      if (captureAttempt.current !== attempt) {
        await deleteLocalPhotoFile(photo.uri).catch((error) => {
          AppLogger.warn(`[Capture] stale cache cleanup deferred — ${String(error)}`);
        });
        return;
      }
      setIsProcessing(true);
      /* BRIGHTNESS AND SHAPE ARE APPLIED HERE, TO THE ACTUAL FILE — not to a
         preview layer. One Skia pass does both: the aspect mask the user
         framed through becomes a real centre crop, and the brightness detent
         becomes real pixels. It is a no-op at the default detent AND the
         native 4:3 shape, and it returns the ORIGINAL photo on any failure,
         so neither preference can ever cost the user a shot. */
      const adjusted = await applyCaptureFraming(photo, {
        brightness: captureBrightnessLevel(mechanismAtCapture, brightnessAtCapture),
        aspectRatio: shapeAtCapture,
        filter: lookAtCapture,
        filterIntensity: lookStrengthAtCapture,
      });
      await new Promise((resolve) => setTimeout(resolve, 500));
      if (captureAttempt.current !== attempt) {
        await deleteLocalPhotoFile(adjusted.uri).catch((error) => {
          AppLogger.warn(`[Capture] cancelled cache cleanup deferred — ${String(error)}`);
        });
        return;
      }
      setIsProcessing(false);
      /* CAPTURE INTERACTION POLISH (Unit 38) — THE SHOT IS CONFIRMED IN THE
         HAND, NOT ONLY ON THE SCREEN.
         The press haptic said "heard you"; nothing said "got it". That gap
         is felt hardest by the two inputs where the user is NOT looking at
         the glass — the volume key and the five-finger gesture. One success
         notification on the existing expo-haptics channel, gated by the
         existing `hapticEnabled` preference. No new haptic system. */
      if (hapticEnabled) {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(
          (error) => {
            AppLogger.debug(`[Capture] success haptic unavailable — ${String(error)}`);
          },
        );
      }
      router.push({
        pathname: '/camera/preview',
        params: {
          uri: adjusted.uri,
          poseId: pose.id,
          filterUsed: lookAtCapture,
          filterIntensity: String(lookStrengthAtCapture),
        },
      });
      captureSucceeded = true;
    } catch (error) {
      /* Camera UX Part 1: this used to be `setMountError(...)`, which swapped
         the whole live screen for the full-page "Camera unavailable" retry
         widget and disposed the pose session. A shutter rejection is
         recoverable in place. */
      const appError = errorHandler.handle(error, 'Camera/Capture');
      setCaptureError(appError.message);
      /* A failure the user cannot see (they were posing, not reading) has to
         be felt. Same channel, same preference, distinct pattern. */
      if (hapticEnabled) {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(
          (hapticError) => {
            AppLogger.debug(
              `[Capture] failure haptic unavailable — ${String(hapticError)}`,
            );
          },
        );
      }
    } finally {
      if (captureAttempt.current === attempt) {
        setIsProcessing(false);
        setIsCapturing(false);
        if (!captureSucceeded) {
          captureFlowActive.current = false;
          intelligentCapture.current.cancel();
        }
      }
    }
  }, [appActive, filter, focused, hapticEnabled, isCameraReady, isCapturing, pose, router]);

  /**
   * THE ONE MANUAL CAPTURE PATH.
   *
   * Unit 38 added a `source` argument and nothing else. The on-screen
   * shutter and the physical volume key are the SAME request: same lock
   * (`requestManual`), same 3 s debounce, same palm-gate notification, same
   * press haptic, same timer, same countdown. The argument exists only so
   * the countdown can name the input and the log can stay honest.
   */
  const beginManualCapture = useCallback(async (source: 'shutter' | 'hardware' = 'shutter') => {
    if (isCapturing || countdownSeconds !== null || !isCameraReady) return;
    if (!intelligentCapture.current.requestManual(Date.now())) return;
    captureFlowActive.current = true;
    setCountdownTrigger(source === 'hardware' ? 'hardware' : 'manual');
    setAutoProgress(0);
    setGestureProgress(0);
    /* A palm that happens to be up while the user taps the shutter must not
       produce a SECOND photograph the moment this one finishes. Manual
       capture is never delayed or blocked by this — the gate is told after
       the manual request has already been granted. */
    openPalmGate.current.notifyCaptureCommitted(Date.now());
    setGesturePhase('cooldown');
    setIsSpeaking(false);
    void ttsService.stop();
    if (hapticEnabled) {
      try {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      } catch (error) {
        AppLogger.warn(`[Capture] press haptic unavailable — ${String(error)}`);
      }
    }
    if (timer === 0) {
      await performCapture();
      return;
    }
    setCountdownSeconds(timer as Exclude<TimerSeconds, 0>);
  }, [countdownSeconds, isCameraReady, isCapturing, performCapture, timer, hapticEnabled]);

  /**
   * Unit 38 — VOLUME-BUTTON SHUTTER.
   *
   * `sessionLive` and the capture gate are recomputed here rather than read
   * from `resolveCameraPresentation`, because that resolver runs *after* the
   * screen's early returns and hooks may not live behind a conditional. The
   * inputs are identical to `captureBlockReasonFor`, plus the screen gates
   * that decide whether a viewfinder exists at all — so the physical button
   * and the on-screen button can never disagree about whether a photo is
   * possible right now.
   */
  const sessionLive = focused && appActive;
  const hardwareCaptureEnabled =
    sessionLive &&
    pose !== null &&
    Platform.OS !== 'web' &&
    permission?.granted === true &&
    mountError === null &&
    mlStatus === 'ready' &&
    isCameraReady &&
    !isCapturing &&
    !isProcessing &&
    countdownSeconds === null;

  const hardwareShutter = useHardwareShutter({
    enabled: volumeShutterEnabled,
    sessionLive,
    captureEnabled: hardwareCaptureEnabled,
    onPress: () => {
      AppLogger.info('[Capture] volume key pressed — routing to manual capture');
      void beginManualCapture('hardware');
    },
  });

  const beginIntelligentCapture = useCallback((trigger: CaptureTrigger) => {
    if (
      trigger === 'manual' ||
      trigger === 'hardware' ||
      captureFlowActive.current ||
      !isCameraReady ||
      isCapturing ||
      !focused ||
      !appActive
    ) {
      return;
    }
    captureFlowActive.current = true;
    setCountdownTrigger(trigger);
    setCountdownSeconds(countdownDuration);
    setAutoProgress(0);
    setGestureProgress(0);
    setGesturePhase('cooldown');
    setIsSpeaking(false);
    void ttsService.stop();
    if (hapticEnabled) {
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch((error) => {
        AppLogger.warn(`[Capture] intelligent trigger haptic unavailable - ${String(error)}`);
      });
    }
    // Unit 27: the photographer always announces the shot — force bypasses
    // the 3s voice interval so the cue is never swallowed by a fresh
    // correction utterance.
    if (voiceEnabled) {
      void ttsService.speakInstruction(
        'photo_clicking',
        instructionLanguage,
        Date.now(),
        undefined,
        { force: true },
      );
    }
    AppLogger.info(
      `[Capture] ${trigger === 'auto' ? 'match held for 2s' : 'five-finger open palm confirmed'} - countdown started (${countdownDuration}s)`,
    );
  }, [appActive, focused, isCameraReady, isCapturing, countdownDuration, hapticEnabled, voiceEnabled, instructionLanguage]);

  // The long-lived 15fps ML effect calls the latest capture callback through
  // this ref, avoiding stale camera/readiness state without restarting ML.
  intelligentTrigger.current = beginIntelligentCapture;

  /**
   * Camera UX Part 2 — ONE HAPTIC FOR THE ONE MOMENT THAT MATTERS.
   *
   * Reaching the pose is the single transition the user cannot see coming
   * while they are holding still and looking at their own body rather than at
   * the chrome. A light tap confirms it without a sound, without a popup and
   * without asking them to read anything. It is armed once per episode: it
   * re-arms only after the engine leaves PERFECT, so a pose held for twenty
   * seconds taps exactly once, not three hundred times.
   *
   * Nothing about analysis, thresholds or hysteresis is consulted here — this
   * reads the semantic state the engine already published.
   */
  const coachingKind = coaching?.kind ?? null;
  useEffect(() => {
    if (coachingKind !== 'perfect') {
      readyHapticArmed.current = true;
      return;
    }
    if (!readyHapticArmed.current || !hapticEnabled) return;
    readyHapticArmed.current = false;
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch((error) => {
      AppLogger.debug(`[Camera] readiness haptic unavailable — ${String(error)}`);
    });
  }, [coachingKind, hapticEnabled]);

  // ── 1. State 1: no pose selected (no camera, no permission needed) ─────
  if (poseId === null) return <NoPoseState />;

  // ── 2. Unknown pose id ─────────────────────────────────────────────────
  if (pose === null) {
    return (
      <CameraNotice
        icon="image-off-outline"
        title="Pose unavailable"
        body="This pose is not in the current library. Choose another from Explore."
        primaryLabel="Browse Poses"
        onPrimary={() => router.replace('/(tabs)/explore')}
      />
    );
  }

  // ── 3. Web has no viewfinder in this target ────────────────────────────
  if (Platform.OS === 'web') {
    return (
      <CameraNotice
        icon="monitor-off"
        title="Camera not supported on web"
        body="Live guidance needs a physical device. Browse the pose library here, then open this pose on your phone."
        primaryLabel="Back to Pose Selection"
        onPrimary={() => router.replace('/(tabs)/camera')}
      />
    );
  }

  // ── 4. Permission still resolving / being requested ────────────────────
  if (permission === null || requesting) {
    return (
      <CameraNotice
        busy
        icon="camera-outline"
        title="Preparing camera"
        body="Waiting for camera access so live pose guidance can start."
      />
    );
  }

  // ── 5. Permission refused ──────────────────────────────────────────────
  if (!permission.granted) {
    return permission.canAskAgain ? (
      <CameraNotice
        icon="camera-off-outline"
        title="Camera access needed"
        body="Live preview and pose guidance need the camera. Frames are processed on-device and never leave your phone."
        primaryLabel="Allow Camera"
        onPrimary={() => void askForCamera()}
        secondaryLabel="Choose a Different Pose"
        onSecondary={() => router.replace('/(tabs)/camera')}
      />
    ) : (
      <CameraNotice
        icon="lock-outline"
        title="Camera blocked in Settings"
        body="Camera permission was permanently denied. Enable it in system settings, then return here."
        primaryLabel="Open Settings"
        onPrimary={() => void openSystemSettings()}
        secondaryLabel="Back to Pose Selection"
        onSecondary={() => router.replace('/(tabs)/camera')}
      />
    );
  }

  // ── 6. Hardware/driver failure ─────────────────────────────────────────
  if (mountError !== null) {
    return (
      <ErrorRetryWidget
        title="Camera unavailable"
        message={mountError}
        onRetry={() => setMountError(null)}
      />
    );
  }

  // ML initialization is recoverable independently from camera permission or
  // capture state. Retrying rebuilds only the detector session.
  if (mlStatus === 'unavailable') {
    return (
      <ErrorRetryWidget
        title="Pose detection unavailable"
        message="The AI model could not be prepared. Check your connection for the first model load, then retry."
        onRetry={() => {
          /* A1 — release the native detector/runtime (stop() is idempotent);
             the session effect's cleanup runs it too when the retry token
             rebuilds the session below. */
          poseRuntimeRef.current?.stop();
          setNativeDetector(null);
          setMlStatus('loading');
          setMlRetryToken((value) => value + 1);
        }}
      />
    );
  }

  // ── 7. State 2: live camera shell ──────────────────────────────────────
  /* `sessionLive` is computed above, before the early returns, because the
     volume-button shutter hook needs it and hooks cannot run conditionally. */

  /**
   * Camera UX Part 1 — ONE ARBITER FOR THE WHOLE SCREEN.
   *
   * Every overlay used to carry its own ad-hoc `visible` expression inline in
   * this JSX, so nothing decided what happens when two of them are true at
   * once. The pure resolver in shared/camera/cameraPresentation now answers
   * that question in a single, testable place; the JSX below only obeys it.
   */
  /* D1 — resolved ONCE per render from the session's capability report:
     which mechanism carries the detent (honest title/note/wash/capture
     routing all descend from it) and the exact EV bias for the native view,
     already device-snapped. When the bridge is silent the prop is a neutral
     0 and the photo-processing fallback owns the control. */
  const exposureMechanism = resolveExposureMechanism(exposureCapabilities);
  const exposureEVProp = exposureCompensationProp(brightness, exposureCapabilities);
  /* CAMERA CONTROLS — one resolution of the lighting question, shared by the
     viewfinder (what the hardware is told) and the control bar (what the user
     is shown). A torch request on the front camera stays a REQUEST: it is
     remembered, reported as unavailable, and honoured again on the rear. */
  const lighting = resolveLighting({
    facing,
    flash,
    torchRequested,
    sessionLive,
  });

  const holdProgress = Math.max(autoProgress, gestureProgress);
  /* Explicit palm input outranks the implicit pose hold — the user who raised
     a hand deliberately deserves to see THAT acknowledged. */
  const holdSource: HoldSource =
    gestureProgress > 0 ? 'gesture' : autoProgress > 0 ? 'auto' : 'none';
  const presentation = resolveCameraPresentation({
    sessionLive,
    cameraReady: isCameraReady,
    mlStatus,
    countdownActive: countdownSeconds !== null,
    isCapturing,
    isProcessing,
    coachingKind: coaching?.kind ?? null,
    holdProgress,
    holdSource,
    zoomEngaged,
    captureErrorActive: captureError !== null,
    voiceGuidanceEnabled: voiceEnabled,
    isSpeaking,
  });

  /* The SAME semantic state that drives the voice now drives the on-screen
     copy, in the SAME language. No second analysis, no TTS dependency. */
  const visibleCoaching = visibleCoachingFor(coaching, instructionLanguage);
  const statusCopy = cameraStatusCopyFor(instructionLanguage);

  /**
   * Camera UX Part 2 — THE FRAME IS THE PRODUCT.
   *
   * Part 1 stacked four readouts down the top-left/top-centre of the frame on
   * hand-tuned offsets. Two of those surfaces are gone (merged into the rail)
   * and one is transient (zoom), so the geometry collapses to: one rail under
   * the controls, the reference thumbnail beside it, and a clear centre.
   * Every offset below is derived from the safe-area inset and the spacing
   * scale — no magic numbers, and nothing that a Dynamic Island or a tall
   * Android cutout can push into the control row.
   */
  const chromeTop = insets.top + spacing.section;
  const railTop = chromeTop;
  const referenceTop = chromeTop;
  const zoomTop = chromeTop + sizing.touchTarget + spacing.md;
  /* The rail never grows under the pinned reference thumbnail, and never
     shrinks below a width that can still hold the readiness word. */
  const railMaxWidth = Math.max(
    MATCH_PILL_MIN_WIDTH,
    windowWidth - 2 * (REFERENCE_THUMB_WIDTH + spacing.lg * 2),
  );
  const bottomSafe = Math.max(insets.bottom, spacing.sm);
  const filterZoneBottom = sizing.cameraBottomBar + bottomSafe;
  /* FINAL INTEGRATION PASS — the coaching band stacks ABOVE the LOOKS zone,
     never inside it. The zone's height (swatch rail + the strength track
     when it is open) comes from ONE shared clearance function — the same
     number the zoom row clears by below — so the band, the rail and the
     swatches can never occupy the same points. Previously the band measured
     from the zone's bottom edge and its pill rendered (zIndex 25) over the
     middle swatches whenever LOOKS and coaching were both on screen. */
  const looksZoneHeight = filterZoneClearance(
    presentation.showFilterStrip,
    filterPanelOpen && filter !== 'original',
  );
  const coachingBandBottom = filterZoneBottom + looksZoneHeight + spacing.lg;

  /**
   * FRAMING GEOMETRY.
   *
   * The viewfinder is full-bleed, so the "picture" is a box inside it whenever
   * the user picks a shape narrower than the sensor's own 4:3. Every framing
   * aid is positioned from that ONE box — the grid rules its thirds, the mask
   * covers what falls outside it, the level sits on its centre — so they can
   * never describe a different photograph from the one that gets saved.
   */
  const frameBox = aspectFrameBox(aspectRatio, windowWidth, windowHeight);
  const deviceLevel = useDeviceLevel(sessionLive && levelGuideEnabled);
  const framing = resolveFramingVisibility({
    sessionLive,
    blocked: presentation.blocking !== 'none',
    holding: presentation.showHoldProgress,
    gridEnabled: gridOverlayEnabled,
    levelEnabled: levelGuideEnabled && deviceLevel.available,
    levelState: deviceLevel.level.state,
    zoomEngaged,
    zoomMultiplier: zoomX,
    facing,
    aspectRatio,
  });
  /* The zoom row sits above the filter strip; when the strip is hidden (a
     capture error owns that band) it simply takes the lower slot. Same
     clearance the coaching band uses — one stack, no drift. */
  const zoomRowBottom = filterZoneBottom + looksZoneHeight;

  return (
    <View style={styles.cameraRoot}>
      {sessionLive ? (
        <CameraPreview
          facing={facing}
          torchOn={lighting.torchOn}
          brightness={brightness}
          mechanism={exposureMechanism}
          exposureCompensation={exposureEVProp}
          onExposureCapabilities={(payload) => {
            useCameraSession.getState().receiveExposureCapabilities(payload);
          }}
          filter={filter}
          filterIntensity={filterIntensity}
          frameOutput={poseFrameOutput}
          zoomX={zoomX}
          onZoomChange={(next) => {
            useCameraSession.getState().setZoom(next);
            markZoomEngaged();
          }}
          onCameraReady={() => {
            useCameraSession.getState().setCameraReady(true);
            AppLogger.info('[Camera] viewfinder ready');
          }}
          onRelease={() => useCameraSession.getState().setCameraReady(false)}
          onMountError={setMountError}
        />
      ) : (
        <View style={[StyleSheet.absoluteFill, styles.pausedView]}>
          <ActivityIndicator color={mediaColors.textMuted} />
          <AppText variant="small" color={mediaColors.textMuted} style={styles.pausedLabel}>
            {statusCopy.paused}
          </AppText>
          <AppText variant="small" color={mediaColors.textSubtle} align="center">
            {statusCopy.pausedDetail}
          </AppText>
        </View>
      )}

      {/* FRAMING — the shape the photo will be kept at. Drawn under every
          coaching overlay so a mask can never hide the silhouette. */}
      {framing.showAspectMask && (
        <AspectRatioMask
          ratio={aspectRatio}
          inset={frameBox.top}
          label={statusCopy.ratioValue(aspectRatio)}
        />
      )}

      {/* Rule-of-thirds, inside the kept picture and nowhere else. */}
      {framing.showGrid && <GridOverlay top={frameBox.top} height={frameBox.height} />}

      {/* Horizon guide: only while the phone is actually off level, never
          during a hold, and never at all without a motion sensor. */}
      {framing.showLevel && (
        <LevelIndicator
          level={deviceLevel.level}
          centerY={frameBox.top + frameBox.height / 2}
          title={statusCopy.levelTitle}
          value={statusCopy.levelValue(deviceLevel.level)}
        />
      )}

      {sessionLive && mlStatus === 'ready' && pose !== null && (
        <PoseSilhouetteOverlay
          pose={pose}
          matchPercent={matchPercent}
          landmarks={poseLandmarks}
          frameWidth={mlFrameSize?.width ?? 3}
          frameHeight={mlFrameSize?.height ?? 4}
          isFrontCamera={facing === 'front'}
          worstLandmarkName={guidance?.worstLandmarkName}
          arrowDirection={guidance?.arrowDirection}
          arrowColor={
            guidance?.severity === 'adjust'
              ? theme.colors.error
              : theme.colors.warning
          }
        />
      )}

      <TopControlsBar
        topInset={insets.top}
        flash={flash}
        timer={timer}
        copy={statusCopy}
        torchOn={lighting.torchOn}
        torchEnabled={lighting.torchEnabled}
        torchBlockedReason={lighting.torchBlockedReason}
        flashSupersededByTorch={lighting.flashSupersededByTorch}
        brightness={brightness}
        brightnessOpen={brightnessPanelOpen}
        exposureMechanism={exposureMechanism}
        aspectRatio={aspectRatio}
        framingOpen={framingPanelOpen}
        framingAidsActive={framing.showGrid || framing.showLevel}
        onCycleFlash={() => useCameraSession.getState().cycleFlash()}
        onToggleTorch={() => useCameraSession.getState().toggleTorch()}
        onToggleBrightness={() => {
          const session = useCameraSession.getState();
          /* Two panels over one viewfinder is one too many: opening either
             closes the other. */
          session.setFramingPanelOpen(false);
          session.setBrightnessPanelOpen(!brightnessPanelOpen);
        }}
        onToggleFraming={() => {
          const session = useCameraSession.getState();
          session.setBrightnessPanelOpen(false);
          session.setFramingPanelOpen(!framingPanelOpen);
        }}
        onCycleTimer={() => useCameraSession.getState().cycleTimer()}
        onOpenSettings={() => router.push('/settings')}
      />
      {/* BRIGHTNESS — the panel is allowed on screen only while the live
          viewfinder owns the frame. A countdown, a capture or a paused
          session must never be adjustable behind a slider. */}
      {presentation.blocking === 'none' && (
        <BrightnessControl
          level={brightness}
          open={brightnessPanelOpen}
          copy={statusCopy}
          topOffset={zoomTop + sizing.touchTarget}
          mechanism={exposureMechanism}
          onChange={(next) => useCameraSession.getState().setBrightness(next)}
          onReset={() => useCameraSession.getState().resetBrightness()}
          onRequestClose={() =>
            useCameraSession.getState().setBrightnessPanelOpen(false)
          }
        />
      )}
      {/* FRAMING SHEET — shape, grid and level in one card under the top bar,
          dismissed by tapping off it, re-tapping the glyph, or waiting. */}
      {presentation.blocking === 'none' && (
        <FramingControl
          open={framingPanelOpen}
          copy={statusCopy}
          topOffset={zoomTop}
          ratio={aspectRatio}
          gridEnabled={gridOverlayEnabled}
          levelEnabled={levelGuideEnabled}
          levelAvailable={deviceLevel.available}
          onSelectRatio={(next) => useCameraSession.getState().setAspectRatio(next)}
          onToggleGrid={() => useSettingsStore.getState().toggleGridOverlay()}
          onToggleLevel={() => useCameraSession.getState().toggleLevelGuide()}
          onRequestClose={() => useCameraSession.getState().setFramingPanelOpen(false)}
        />
      )}
      {/* ZOOM — stops plus the live multiplier, in the thumb zone, contextual:
          on while pinching or while off 1×, gone the rest of the time. */}
      {framing.showZoomStops && (
        <ZoomControl
          multiplier={zoomX}
          facing={facing}
          copy={statusCopy}
          bottom={zoomRowBottom}
          onSelect={(next) => {
            useCameraSession.getState().setZoom(next);
            markZoomEngaged();
          }}
          onReset={() => {
            useCameraSession.getState().resetZoom();
            markZoomEngaged();
          }}
        />
      )}
      {/* Camera UX Part 3 — the pinned reference is also the answer to
          "which pose am I shooting?" and the only way back out of the
          viewfinder that does not go through the tab bar. */}
      {presentation.showPoseIdentity && (
        <ReferenceOverlay
          pose={pose}
          top={referenceTop}
          shootingLabel={statusCopy.shooting}
          changeLabel={statusCopy.changePose}
          onChangePose={() => router.replace('/(tabs)/camera')}
        />
      )}
      {/* ONE readout: how it is going, how close, and whether the coach is
          talking — in a single surface the eye parses in one fixation. */}
      {presentation.showStatusRail && (
        <CameraStatusRail
          top={railTop}
          readiness={presentation.readiness}
          matchPercent={matchPercent}
          matchEmphasis={presentation.matchEmphasis}
          voiceMode={presentation.voiceIndicator}
          emphasis={presentation.railEmphasis}
          maxWidth={railMaxWidth}
          labels={{
            readiness: statusCopy.readiness(presentation.readiness),
            match:
              matchPercent === null
                ? statusCopy.noMatchYet
                : statusCopy.formatMatch(matchPercent),
            voiceSpeaking: statusCopy.voiceSpeaking,
            voiceIdle: statusCopy.voiceIdle,
            voiceMuted: statusCopy.voiceMuted,
          }}
          onToggleVoice={() => useSettingsStore.getState().toggleVoice()}
        />
      )}

      {/* THE coaching band: one message, every semantic state, one language. */}
      {presentation.showCoachingBand && (
        <GuidanceOverlay
          status={visibleCoaching}
          arrowDirection={guidance?.arrowDirection ?? 'none'}
          bottom={coachingBandBottom}
          emphasis={presentation.coachingEmphasis}
        />
      )}

      {captureError !== null && (
        <CaptureErrorBanner
          title={statusCopy.captureFailed}
          message={captureError}
          retryLabel={statusCopy.captureRetry}
          dismissLabel={statusCopy.captureDismiss}
          onRetry={() => {
            setCaptureError(null);
            void beginManualCapture();
          }}
          onDismiss={() => setCaptureError(null)}
          bottom={filterZoneBottom}
        />
      )}

      {presentation.showFilterStrip && (
        <View style={[styles.filterZone, { bottom: filterZoneBottom }]}>
          <FilterStrip
            active={filter}
            intensity={filterIntensity}
            strengthOpen={filterPanelOpen}
            copy={statusCopy}
            onSelect={(next) => useCameraSession.getState().setFilter(next)}
            onIntensityChange={(next) =>
              useCameraSession.getState().setFilterIntensity(next)
            }
            onIntensityReset={() => useCameraSession.getState().resetFilterIntensity()}
            onStrengthOpenChange={(open) =>
              useCameraSession.getState().setFilterPanelOpen(open)
            }
          />
        </View>
      )}

      <BottomControlsBar
        bottomInset={insets.bottom}
        facing={facing}
        // Capture readiness and its REASON both come from the one resolver.
        cameraReady={presentation.captureEnabled}
        captureBlockedReason={statusCopy.captureBlocked(presentation.captureBlockReason)}
        /* Part 2: hold progress is drawn AT the shutter, not floating over
           the user's body. Source and progress both arrive decided. */
        shutterRing={presentation.shutterRing}
        holdProgress={holdProgress}
        holdCaption={
          presentation.showHoldProgress
            ? holdSource === 'gesture'
              /* The ring must distinguish 'I can see a palm, keep holding'
                 against 'that counted'. One existing surface, four honest
                 words, no new overlay and no repeated speech.

                 Part 3 repair: this sentence previously used a double-quoted
                 phrase preceded by the word `from`, which `verify-deps.mjs`
                 parses as an import specifier — the gate reported a missing
                 production dependency literally named "that counted". The
                 scanner is correct to be naive about strings; the prose was
                 the defect, so the prose changed and the gate did not. */
              ? statusCopy.gesturePhase(gesturePhase) || statusCopy.holdGesture
              : statusCopy.holdAuto
            : ''
        }
        facingLabel={statusCopy.facing(facing)}
        readyLabel={statusCopy.readiness('ready')}
        /* Unit 38 — announced only while the keys are genuinely armed on a
           build that genuinely has them. Never a promise. */
        hardwareShutterHint={hardwareShutter.armed ? statusCopy.volumeShutterArmed : ''}
        galleryThumbnailUri={galleryThumbnailUri}
        onGallery={() => router.push('/(tabs)/gallery')}
        onCapture={() => {
          AppLogger.info(
            `[Capture] started (pose=${pose.id}, flash=${flash}, timer=${timer}, look=${filter}@${filterIntensity}%, zoom=${zoomLabel(zoomX, facing)}, shape=${aspectRatio})`,
          );
          void beginManualCapture();
        }}
        onFlip={() => useCameraSession.getState().switchCamera()}
      />

      {/* EXACTLY ONE blocking layer can exist; the resolver picked it. */}
      {presentation.blocking === 'countdown' && countdownSeconds !== null && (
        <CountdownOverlay
          seconds={countdownSeconds}
          label={statusCopy.countdownReason(countdownTrigger)}
          onComplete={() => void performCapture()}
        />
      )}
      {(presentation.blocking === 'capturing' ||
        presentation.blocking === 'processing') && (
        <ProcessingOverlay
          stage={presentation.blocking === 'processing' ? 'processing' : 'capturing'}
          label={
            presentation.blocking === 'processing'
              ? statusCopy.processing
              : statusCopy.capturing
          }
        />
      )}
      {presentation.blocking === 'model-loading' && <ModelLoadingOverlay />}
    </View>
  );
}

/**
 * Camera UX Part 3 — REPAIR (pre-existing break, not a redesign).
 *
 * Part 2 made the zoom readout transient and referenced this linger constant
 * from `markZoomEngaged`, but the constant itself never existed in the file:
 * `tsc --noEmit` failed on `Cannot find name 'ZOOM_PILL_LINGER_MS'`, which
 * means the camera screen could not type-check (and, in a release build,
 * would throw a ReferenceError the first time the user pinched to zoom).
 * Restored here at the documented value — long enough to read the multiplier
 * after the fingers leave the glass, short enough that it never becomes
 * permanent chrome again.
 */
const ZOOM_PILL_LINGER_MS = 1_400;

/** Width of the pinned reference thumbnail — see ReferenceOverlay. */
const REFERENCE_THUMB_WIDTH = 80;
/** The match pill never shrinks below this, even on very narrow screens. */
const MATCH_PILL_MIN_WIDTH = 120;

const styles = StyleSheet.create({
  noticeRoot: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  noticeIcon: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  noticeTitle: {
    marginTop: spacing.lg,
    textAlign: 'center',
  },
  noticeBody: {
    marginTop: spacing.sm,
    maxWidth: 320,
  },
  noticeButton: {
    marginTop: spacing.xl,
    minWidth: 240,
  },
  noticeSecondary: {
    marginTop: spacing.sm,
    minWidth: 240,
  },
  cameraRoot: {
    flex: 1,
    backgroundColor: mediaColors.viewfinder,
  },
  pausedView: {
    backgroundColor: mediaColors.viewfinder,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  pausedLabel: {
    fontWeight: '600',
  },
  filterZone: {
    position: 'absolute',
    left: 0,
    right: 0,
  },
});
