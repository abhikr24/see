/**
 * POST-CAPTURE EDITING — the editor screen.
 *
 * WHAT THE USER SEES IS WHAT THE FILE BECOMES.
 *
 * The preview is NOT an RN `<Image>` with a CSS-ish transform on top: it is a
 * Skia canvas drawing the DECODED photograph through the SAME colour matrix
 * and the SAME quarter-turn transform that `core/camera/photoEditor` will feed
 * to the offscreen surface when Apply is pressed. One renderer, one matrix,
 * one rotation convention — so the preview cannot flatter the result, which is
 * the failure this whole feature was written to avoid.
 *
 * (The crop box is the one thing drawn as an overlay rather than baked in,
 * because a crop the user cannot see outside of is a crop they cannot adjust.
 * The dimmed area IS what gets discarded.)
 *
 * STRUCTURE
 *   top bar     Cancel · title · Apply
 *   canvas      the live edit + crop overlay
 *   tool tabs   Crop / Rotate / Enhance
 *   panel       the selected tool's controls
 *
 * FAILURE AND HONESTY
 *   · Until the image is decoded there is a spinner, never a stale preview.
 *   · If Skia cannot decode the file the editor says so and offers only
 *     Cancel, instead of showing an empty canvas with a working Apply button.
 *   · Apply is disabled while the edit is the identity, so a user cannot
 *     re-encode a photograph for no change.
 */
import React, { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Canvas,
  ColorMatrix,
  Group,
  Image as SkiaImage,
  useImage,
} from '@shopify/react-native-skia';
import {
  FULL_FRAME_CROP,
  PHOTO_EDIT_NONE,
  clampAdjustValue,
  clampCropAspectId,
  cropAspectValue,
  cropIsFullFrame,
  cropRectForAspect,
  describePhotoEdit,
  enhanceColorMatrix,
  photoEditIsIdentity,
  radius,
  rotateCropRect,
  rotateQuarterTurns,
  rotatedSize,
  rotationDegrees,
  mediaColors,
  sizing,
  spacing,
  type CropAspectId,
  type NormalizedRect,
  type PhotoAdjustKey,
  type PhotoEdit,
  type PhotoEnhance,
  type QuarterTurns,
} from '@shared/index';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { CropFrame } from '../components/CropFrame';
import {
  CropToolPanel,
  EnhanceToolPanel,
  RotateToolPanel,
} from '../components/EditToolPanels';

type EditorTool = 'crop' | 'rotate' | 'enhance';

const TOOLS: readonly { readonly id: EditorTool; readonly icon: string; readonly label: string }[] = [
  { id: 'crop', icon: 'crop', label: 'Crop' },
  { id: 'rotate', icon: 'rotate-right', label: 'Rotate' },
  { id: 'enhance', icon: 'auto-fix', label: 'Enhance' },
];

export interface PhotoEditorScreenProps {
  readonly uri: string;
  readonly busy: boolean;
  /** What the caller will do with the edit — render, persist, refresh. */
  readonly onApply: (edit: PhotoEdit) => void;
  readonly onCancel: () => void;
}

export function PhotoEditorScreen({
  uri,
  busy,
  onApply,
  onCancel,
}: PhotoEditorScreenProps) {
  const image = useImage(uri);
  const [tool, setTool] = useState<EditorTool>('crop');
  const [rotation, setRotation] = useState<QuarterTurns>(PHOTO_EDIT_NONE.rotation);
  const [crop, setCrop] = useState<NormalizedRect>(PHOTO_EDIT_NONE.crop);
  const [aspect, setAspect] = useState<CropAspectId>('free');
  const [enhance, setEnhance] = useState<PhotoEnhance>(PHOTO_EDIT_NONE.enhance);
  const [area, setArea] = useState({ width: 0, height: 0 });

  const edit: PhotoEdit = useMemo(
    () => ({ rotation, crop, enhance }),
    [crop, enhance, rotation],
  );
  const identity = photoEditIsIdentity(edit);
  const matrix = useMemo(() => enhanceColorMatrix(enhance) as number[], [enhance]);

  const sourceWidth = image?.width() ?? 0;
  const sourceHeight = image?.height() ?? 0;
  const rotated = rotatedSize(sourceWidth, sourceHeight, rotation);
  const frameAspect = rotated.height > 0 ? rotated.width / rotated.height : 1;

  /* Fit the ROTATED photo into the available area — "contain", never "cover",
     because a crop tool that hides part of the photograph off-screen is worse
     than useless. */
  const scale =
    rotated.width > 0 && rotated.height > 0 && area.width > 0 && area.height > 0
      ? Math.min(area.width / rotated.width, area.height / rotated.height)
      : 0;
  const displayWidth = rotated.width * scale;
  const displayHeight = rotated.height * scale;
  const displayLeft = (area.width - displayWidth) / 2;
  const displayTop = (area.height - displayHeight) / 2;

  /* The un-rotated image is drawn centred and then the GROUP is turned, which
     is exactly what the renderer does to the pixels. */
  const centreX = area.width / 2;
  const centreY = area.height / 2;
  const drawWidth = rotation % 2 === 1 ? displayHeight : displayWidth;
  const drawHeight = rotation % 2 === 1 ? displayWidth : displayHeight;

  const handleRotate = useCallback(
    (direction: number) => {
      setRotation((current) => rotateQuarterTurns(current, direction));
      setCrop((current) => rotateCropRect(current, direction));
    },
    [],
  );

  const handleAspect = useCallback(
    (next: CropAspectId) => {
      const id = clampCropAspectId(next);
      setAspect(id);
      setCrop(cropRectForAspect(id, rotated.width, rotated.height));
    },
    [rotated.height, rotated.width],
  );

  const handleAdjust = useCallback((key: PhotoAdjustKey, value: number) => {
    setEnhance((current) => ({ ...current, [key]: clampAdjustValue(value) }));
  }, []);

  const lockedAspect = cropAspectValue(aspect, rotated.width, rotated.height);
  const ready = image !== null && sourceWidth > 0 && sourceHeight > 0;

  return (
    <View style={styles.root}>
      <SafeAreaView edges={['top']} style={styles.topSafe}>
        <View style={styles.topBar}>
          <Pressable
            onPress={onCancel}
            disabled={busy}
            accessibilityRole="button"
            accessibilityLabel="Cancel editing and keep the original photo"
            style={({ pressed }) => [styles.barAction, { opacity: busy ? 0.4 : pressed ? 0.7 : 1 }]}
          >
            <AppText variant="secondaryBody" color={mediaColors.text}>
              Cancel
            </AppText>
          </Pressable>

          <View style={styles.title}>
            <AppText variant="secondaryBody" color={mediaColors.text}>
              Edit photo
            </AppText>
            <AppText variant="small" color={mediaColors.textSubtle} numberOfLines={1}>
              {describePhotoEdit(edit)}
            </AppText>
          </View>

          <Pressable
            onPress={() => onApply(edit)}
            disabled={busy || identity || !ready}
            accessibilityRole="button"
            accessibilityLabel="Apply edits and save them to this photo"
            accessibilityState={{ disabled: busy || identity || !ready, busy }}
            style={({ pressed }) => [
              styles.barAction,
              styles.barActionRight,
              { opacity: busy || identity || !ready ? 0.4 : pressed ? 0.7 : 1 },
            ]}
          >
            {busy ? (
              <ActivityIndicator color={mediaColors.text} />
            ) : (
              <AppText variant="button" color={mediaColors.text}>
                Apply
              </AppText>
            )}
          </Pressable>
        </View>
      </SafeAreaView>

      <View
        style={styles.stage}
        onLayout={(event) =>
          setArea({
            width: event.nativeEvent.layout.width,
            height: event.nativeEvent.layout.height,
          })
        }
      >
        {!ready && (
          <View style={styles.stageState}>
            {image === null ? (
              <ActivityIndicator color={mediaColors.text} />
            ) : (
              <>
                <IconSymbol
                  name="image-off-outline"
                  size={sizing.iconEmpty}
                  color={mediaColors.textSubtle}
                />
                <AppText variant="small" color={mediaColors.textMuted} align="center">
                  This photo could not be opened for editing. The file has not been changed.
                </AppText>
              </>
            )}
          </View>
        )}

        {ready && area.width > 0 && (
          <>
            <Canvas style={{ width: area.width, height: area.height }}>
              <Group
                origin={{ x: centreX, y: centreY }}
                transform={[{ rotate: (rotationDegrees(rotation) * Math.PI) / 180 }]}
              >
                <SkiaImage
                  image={image}
                  x={centreX - drawWidth / 2}
                  y={centreY - drawHeight / 2}
                  width={drawWidth}
                  height={drawHeight}
                  fit="fill"
                >
                  <ColorMatrix matrix={matrix} />
                </SkiaImage>
              </Group>
            </Canvas>
            {tool === 'crop' && (
              <CropFrame
                left={displayLeft}
                top={displayTop}
                width={displayWidth}
                height={displayHeight}
                crop={crop}
                aspect={lockedAspect}
                frameAspect={frameAspect}
                onChange={setCrop}
                disabled={busy}
              />
            )}
          </>
        )}
      </View>

      <SafeAreaView edges={['bottom']} style={styles.bottom}>
        {tool === 'crop' && (
          <CropToolPanel
            aspect={aspect}
            cropped={!cropIsFullFrame(crop)}
            onSelectAspect={handleAspect}
            onReset={() => {
              setAspect('free');
              setCrop(FULL_FRAME_CROP);
            }}
          />
        )}
        {tool === 'rotate' && (
          <RotateToolPanel
            rotation={rotation}
            onRotate={handleRotate}
            onReset={() => {
              setRotation(0);
              setCrop(FULL_FRAME_CROP);
            }}
          />
        )}
        {tool === 'enhance' && (
          <EnhanceToolPanel
            enhance={enhance}
            onChangeAdjust={handleAdjust}
            onApplyPreset={setEnhance}
          />
        )}

        <View style={styles.tabs}>
          {TOOLS.map((entry) => {
            const active = tool === entry.id;
            return (
              <Pressable
                key={entry.id}
                onPress={() => setTool(entry.id)}
                accessibilityRole="tab"
                accessibilityState={{ selected: active }}
                accessibilityLabel={`${entry.label} tool`}
                style={({ pressed }) => [styles.tab, { opacity: pressed ? 0.7 : 1 }]}
              >
                <IconSymbol
                  name={entry.icon}
                  size={sizing.iconDefault}
                  color={active ? mediaColors.text : mediaColors.textSubtle}
                />
                <AppText
                  variant="small"
                  color={active ? mediaColors.text : mediaColors.textSubtle}
                >
                  {entry.label}
                </AppText>
              </Pressable>
            );
          })}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    backgroundColor: mediaColors.viewfinder,
    zIndex: 200,
  },
  topSafe: {
    backgroundColor: mediaColors.overlayMedium,
  },
  topBar: {
    minHeight: sizing.touchTarget,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
  },
  barAction: {
    minWidth: 72,
    minHeight: sizing.touchTarget,
    justifyContent: 'center',
  },
  barActionRight: {
    alignItems: 'flex-end',
  },
  title: {
    flex: 1,
    alignItems: 'center',
  },
  stage: {
    flex: 1,
  },
  stageState: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.xl,
  },
  bottom: {
    backgroundColor: mediaColors.overlayHeavy,
    paddingTop: spacing.sm,
  },
  tabs: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: spacing.sm,
  },
  tab: {
    minWidth: 88,
    minHeight: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    borderRadius: radius.md,
  },
});
