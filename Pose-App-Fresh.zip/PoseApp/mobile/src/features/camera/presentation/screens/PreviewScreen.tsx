/**
 * Unit 13 — captured-photo preview.
 *
 * Photos stay on-device: Save copies the temporary camera URI into the app's
 * document directory, copies that file into the system gallery via
 * MediaLibrary.saveToLibraryAsync, and writes metadata to MMKV. This module
 * has no backend imports by design.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  StyleSheet,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import {
  FILTER_INTENSITY_DEFAULT,
  FILTER_OPTIONS,
  filterSummary,
  mediaColors,
  radius,
  sizing,
  spacing,
} from '@shared/index';
import type { PhotoEdit } from '@shared/index';
import { describePhotoEdit } from '@shared/index';
import type { CameraFilterId } from '@/core/camera/cameraService';
import { resetTransientCameraState } from '@/core/camera/cameraService';
import {
  discardEditTempFile,
  renderPhotoEdit,
  sweepEditTempFiles,
} from '@/core/camera/photoEditor';
import { checkPhotos, openSystemSettings, requestPhotos } from '@/core/permissions/permissionService';
import { AppLogger } from '@/core/utils/logger';
import { useAppTheme } from '@/core/theme';
import { queryClient } from '@/core/network/queryClient';
import { useAuthStore } from '@/shared/stores/authStore';
import { galleryPhotosQueryKey } from '@/features/gallery/data/galleryQueryKeys';
import {
  createGalleryPhotoId,
  deleteLocalPhotoFile,
  galleryLocalDatasource,
  persistCapturedFile,
  replaceStoredPhotoFile,
} from '@/features/gallery/data/datasources/galleryLocalDatasource';
import type { PermissionStatus } from '@/core/permissions/permissionService';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PermissionCard } from '@/features/onboarding/presentation/components/PermissionCard';
import { showSuccessSnackBar } from '@/shared/stores/snackBarStore';
import { PhotoEditorScreen } from './PhotoEditorScreen';

export interface PreviewScreenProps {
  readonly uri: string;
  readonly poseId: string | null;
  readonly filterUsed: CameraFilterId;
  /**
   * LOOKS — the strength the look was applied at. The look itself is already
   * IN the file by the time this screen runs (see core/camera/photoBrightness),
   * so this is a caption, not a pending operation: the preview below is the
   * photograph, unfiltered by any view-layer trick.
   */
  readonly filterIntensity?: number;
}

export function PreviewScreen({
  uri,
  poseId,
  filterUsed,
  filterIntensity = FILTER_INTENSITY_DEFAULT,
}: PreviewScreenProps) {
  const theme = useAppTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = useAuthStore((state) => state.session?.id ?? null);
  const [displayUri, setDisplayUri] = useState(uri);
  const [savedPhotoId, setSavedPhotoId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [permissionIssue, setPermissionIssue] = useState<PermissionStatus | null>(null);
  /* POST-CAPTURE EDITING — the editor is a full-screen layer over this
     screen rather than a route, so the photo, the save state and the pose
     context are all still here when it closes. */
  const [isEditorOpen, setEditorOpen] = useState(false);
  const [isApplyingEdit, setApplyingEdit] = useState(false);
  const [editSummary, setEditSummary] = useState<string | null>(null);

  /* Abandoned edit renderings (cancelled after Apply, or an app killed
     mid-flow) are full-size JPEGs in the cache. Sweeping on mount keeps the
     feature from quietly accumulating the user's own photographs. */
  useEffect(() => {
    void sweepEditTempFiles();
  }, []);

  const applyEdit = useCallback(
    (edit: PhotoEdit) => {
      void (async () => {
        setApplyingEdit(true);
        try {
          const result = await renderPhotoEdit(
            { uri: displayUri, width: 0, height: 0 },
            edit,
          );
          if (!result.applied) {
            Alert.alert(
              'Could not apply edits',
              'This photo could not be re-rendered on this device. Your original photo has not been changed.',
            );
            return;
          }

          if (savedPhotoId === null) {
            /* Unsaved capture: the previous file is a throwaway cache artefact
               that nothing else references, so it goes now rather than later. */
            const previous = displayUri;
            setDisplayUri(result.uri);
            await deleteLocalPhotoFile(previous).catch((error) => {
              AppLogger.warn(`[Preview] pre-edit cache cleanup deferred — ${String(error)}`);
            });
          } else if (userId === null) {
            await discardEditTempFile(result.uri);
            Alert.alert('Session ended', 'Sign in again before editing this photo.');
            return;
          } else {
            const destination = await replaceStoredPhotoFile(
              userId,
              savedPhotoId,
              result.uri,
            );
            setDisplayUri(destination);
            await queryClient.invalidateQueries({
              queryKey: galleryPhotosQueryKey(userId),
            });
          }

          setEditSummary(describePhotoEdit(edit));
          setEditorOpen(false);
          showSuccessSnackBar(
            savedPhotoId === null ? 'Edits applied' : 'Edited photo updated',
          );
          AppLogger.info(`[Preview] edit applied — ${describePhotoEdit(edit)}`);
        } catch (error) {
          AppLogger.error(`[Preview] edit failed — ${String(error)}`);
          Alert.alert(
            'Could not apply edits',
            'The edited photo could not be written. Your original photo has not been changed.',
          );
        } finally {
          setApplyingEdit(false);
        }
      })();
    },
    [displayUri, savedPhotoId, userId],
  );

  const navigateBack = useCallback(() => {
    if (router.canGoBack()) router.back();
    else {
      router.replace({
        pathname: '/(tabs)/camera',
        params: poseId ? { poseId } : {},
      });
    }
  }, [poseId, router]);

  const closePreview = useCallback(() => {
    void (async () => {
      if (savedPhotoId === null) {
        try {
          await deleteLocalPhotoFile(displayUri);
        } catch (error) {
          AppLogger.warn(`[Preview] close cleanup deferred — ${String(error)}`);
        }
      }
      navigateBack();
    })();
  }, [displayUri, navigateBack, savedPhotoId]);

  const share = useCallback(async () => {
    try {
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert('Sharing unavailable', 'This device cannot open a file sharing sheet.');
        return;
      }
      await Sharing.shareAsync(displayUri, {
        dialogTitle: 'Share your photo',
        mimeType: 'image/jpeg',
        UTI: 'public.jpeg',
      });
    } catch (error) {
      AppLogger.error(`[Preview] share failed — ${String(error)}`);
      Alert.alert('Could not share', 'The sharing sheet could not be opened. Try again.');
    }
  }, [displayUri]);

  const remove = useCallback(() => {
    Alert.alert(
      'Delete photo?',
      savedPhotoId === null
        ? 'This captured photo will be discarded. This cannot be undone.'
        : 'This removes the photo from PoseAssist. The copy already saved in your device gallery remains.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                if (savedPhotoId !== null) {
                  if (userId === null) throw new Error('Authentication session ended.');
                  await galleryLocalDatasource.deletePhoto(userId, savedPhotoId);
                } else {
                  await deleteLocalPhotoFile(displayUri);
                }
                navigateBack();
              } catch (error) {
                AppLogger.error(`[Preview] delete failed — ${String(error)}`);
                Alert.alert('Could not delete', 'The photo file could not be removed.');
              }
            })();
          },
        },
      ],
    );
  }, [displayUri, navigateBack, savedPhotoId, userId]);

  const retake = useCallback(() => {
    void (async () => {
      // Saved images are durable Gallery items; unsaved cache files can be
      // safely discarded before opening a fresh camera session.
      if (savedPhotoId === null) {
        try {
          await deleteLocalPhotoFile(displayUri);
        } catch (error) {
          AppLogger.warn(`[Preview] old capture cleanup deferred — ${String(error)}`);
        }
      }
      resetTransientCameraState();
      router.replace({
        pathname: '/(tabs)/camera',
        params: poseId ? { poseId } : {},
      });
    })();
  }, [displayUri, poseId, router, savedPhotoId]);

  const saveToGallery = useCallback(async () => {
    if (isSaving || savedPhotoId !== null) return;
    setIsSaving(true);
    setPermissionIssue(null);

    let persistentUri: string | null = null;
    try {
      if (userId === null) {
        Alert.alert('Session ended', 'Sign in again before saving this photo.');
        return;
      }
      let status = await checkPhotos();
      if (status === 'denied') status = await requestPhotos();
      if (status !== 'granted') {
        setPermissionIssue(status);
        return;
      }

      const id = createGalleryPhotoId();
      persistentUri = await persistCapturedFile(displayUri, id, userId);
      await MediaLibrary.saveToLibraryAsync(persistentUri);
      galleryLocalDatasource.savePhoto(userId, {
        id,
        poseId,
        imagePath: persistentUri,
        filterUsed,
        timestamp: Date.now(),
      });
      await queryClient.invalidateQueries({ queryKey: galleryPhotosQueryKey(userId) });
      setDisplayUri(persistentUri);
      setSavedPhotoId(id);
      if (displayUri !== persistentUri) {
        try {
          await deleteLocalPhotoFile(displayUri);
        } catch (cleanupError) {
          AppLogger.warn(`[Preview] camera-cache cleanup deferred — ${String(cleanupError)}`);
        }
      }
      showSuccessSnackBar('Photo saved to gallery');
      AppLogger.info(`[Preview] saved to device gallery + MMKV — ${id}`);
    } catch (error) {
      if (persistentUri !== null) {
        try {
          await deleteLocalPhotoFile(persistentUri);
        } catch (cleanupError) {
          AppLogger.warn(`[Preview] failed-save cleanup deferred — ${String(cleanupError)}`);
        }
      }
      AppLogger.error(`[Preview] save failed — ${String(error)}`);
      Alert.alert('Could not save', 'The photo could not be saved. Check storage access and try again.');
    } finally {
      setIsSaving(false);
    }
  }, [displayUri, filterUsed, isSaving, poseId, savedPhotoId, userId]);

  if (uri.length === 0 || (Platform.OS !== 'web' && !uri.startsWith('file://'))) {
    return (
      <SafeAreaView style={[styles.webRoot, { backgroundColor: theme.colors.background }]}>
        <IconSymbol name="image-off-outline" size={40} color={theme.colors.textDisabled} />
        <AppText variant="heading" color={theme.colors.textPrimary} style={styles.webTitle}>
          Photo unavailable
        </AppText>
        <AppText variant="secondaryBody" color={theme.colors.textSecondary} align="center">
          The captured file could not be opened. Return to the camera and try again.
        </AppText>
      </SafeAreaView>
    );
  }

  if (Platform.OS === 'web') {
    return (
      <SafeAreaView style={styles.webRoot}>
        <IconSymbol name="cellphone" size={40} color={mediaColors.textMuted} />
        <AppText variant="heading" color={mediaColors.text} style={styles.webTitle}>
          Capture works on phone only
        </AppText>
        <AppText variant="secondaryBody" color={mediaColors.textMuted} align="center">
          Open this pose on an iOS or Android device to capture and save photos.
        </AppText>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.root}>
      <Image
        source={{ uri: displayUri }}
        style={StyleSheet.absoluteFill}
        contentFit="contain"
        accessibilityLabel="Your newly captured photo"
      />

      <SafeAreaView edges={['top']} style={styles.topSafe}>
        <View style={styles.topBar}>
          <PreviewIcon icon="close" label="Close preview" onPress={closePreview} />
          {filterUsed !== 'original' && (
            <View style={styles.lookChip}>
              <IconSymbol name="image-filter-vintage" size={12} color={mediaColors.text} />
              <AppText variant="small" color={mediaColors.text}>
                {filterSummary(
                  filterUsed,
                  filterIntensity,
                  (id) =>
                    FILTER_OPTIONS.find((option) => option.value === id)?.label ?? id,
                )}
              </AppText>
            </View>
          )}
          <View style={styles.topActions}>
            <PreviewIcon
              icon="tune-variant"
              label="Edit photo: crop, rotate or enhance"
              onPress={() => setEditorOpen(true)}
            />
            <PreviewIcon icon="share-variant" label="Share photo" onPress={() => void share()} />
            <PreviewIcon icon="delete-outline" label="Delete photo" onPress={remove} />
          </View>
        </View>
      </SafeAreaView>

      <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, spacing.sm) }]}>
        <Pressable
          onPress={retake}
          accessibilityRole="button"
          accessibilityLabel="Retake photo"
          style={({ pressed }) => [styles.retake, { opacity: pressed ? 0.7 : 1 }]}
        >
          <IconSymbol name="replay" size={24} color={mediaColors.text} />
          <AppText variant="secondaryBody" color={mediaColors.text}>
            Retake
          </AppText>
        </Pressable>

        <Pressable
          onPress={savedPhotoId !== null ? () => router.replace('/(tabs)/gallery') : () => void saveToGallery()}
          disabled={isSaving}
          accessibilityRole="button"
          accessibilityLabel={savedPhotoId !== null ? 'Done and open gallery' : 'Save photo'}
          accessibilityState={{ disabled: isSaving, busy: isSaving }}
          style={({ pressed }) => [
            styles.primaryAction,
            {
              backgroundColor:
                savedPhotoId !== null ? mediaColors.text : theme.colors.primary,
              opacity: isSaving ? 0.5 : pressed ? 0.85 : 1,
            },
          ]}
        >
          {isSaving ? (
            <ActivityIndicator color={mediaColors.text} />
          ) : (
            <AppText
              variant="button"
              color={savedPhotoId !== null ? mediaColors.viewfinder : mediaColors.text}
            >
              {savedPhotoId !== null ? 'Done' : 'Save'}
            </AppText>
          )}
        </Pressable>
      </View>

      {permissionIssue !== null && (
        <View style={styles.permissionOverlay}>
          <View style={[styles.permissionPanel, { backgroundColor: theme.colors.background }]}>
            <PermissionCard
              icon="image-multiple-outline"
              title="Gallery Access"
              description="Allow gallery access to save this photo on your device. Photos are never uploaded."
              status={permissionIssue}
              requesting={false}
              onAllow={() => void saveToGallery()}
              onOpenSettings={() => void openSystemSettings()}
            />
            <Pressable
              onPress={() => setPermissionIssue(null)}
              accessibilityRole="button"
              accessibilityLabel="Dismiss gallery permission explanation"
              style={styles.dismissPermission}
            >
              <AppText variant="small" color={theme.colors.textSecondary}>
                Not Now
              </AppText>
            </Pressable>
          </View>
        </View>
      )}

      {editSummary !== null && !isEditorOpen && (
        <View style={styles.editChip} pointerEvents="none">
          <IconSymbol name="tune-variant" size={12} color={mediaColors.text} />
          <AppText variant="small" color={mediaColors.text}>
            {editSummary}
          </AppText>
        </View>
      )}

      {isEditorOpen && (
        <PhotoEditorScreen
          uri={displayUri}
          busy={isApplyingEdit}
          onApply={applyEdit}
          onCancel={() => {
            if (!isApplyingEdit) setEditorOpen(false);
          }}
        />
      )}

      {/* Unit 23: "Photo saved to gallery" now rides the global snackbar host */}
    </View>
  );
}

function PreviewIcon({
  icon,
  label,
  onPress,
}: {
  readonly icon: string;
  readonly label: string;
  readonly onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.7 : 1 }]}
    >
      <IconSymbol name={icon} size={28} color={mediaColors.text} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: mediaColors.viewfinder,
  },
  webRoot: {
    flex: 1,
    backgroundColor: mediaColors.viewfinder,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  webTitle: {
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  topSafe: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  topBar: {
    minHeight: sizing.touchTarget,
    paddingHorizontal: spacing.sm,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: mediaColors.overlayMedium,
  },
  topActions: {
    flexDirection: 'row',
  },
  iconButton: {
    width: sizing.touchTarget,
    height: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    minHeight: sizing.cameraBottomBar,
    paddingHorizontal: spacing.xl,
    backgroundColor: mediaColors.overlayHeavy,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  retake: {
    minWidth: 88,
    minHeight: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
  },
  primaryAction: {
    minWidth: 132,
    minHeight: sizing.touchTarget,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  editChip: {
    position: 'absolute',
    left: spacing.lg,
    bottom: sizing.cameraBottomBar + spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.overlayHeavy,
  },
  lookChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.overlayHeavy,
  },
  permissionOverlay: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    zIndex: 150,
    backgroundColor: mediaColors.overlayHeavy,
    justifyContent: 'flex-end',
  },
  permissionPanel: {
    padding: spacing.lg,
    borderTopLeftRadius: radius.xxl,
    borderTopRightRadius: radius.xxl,
  },
  dismissPermission: {
    minHeight: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
