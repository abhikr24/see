/**
 * Unit 08 — Search history store (LRU 10, persisted).
 *
 * Zustand + persist, backed by Unit 01's storage adapter (MMKV natively,
 * transparent in-memory fallback inside Expo Go / on web). This is the
 * canonical Unit 05 search-history store used by Explore.
 */
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { LIMITS, STORAGE_KEYS } from '@shared/index';
import { storage } from '@/core/storage/storage';

/** MMKV-shaped adapter (getString / set / delete) → zustand StateStorage. */
const mmkvStateStorage = {
  getItem: (name: string): string | null => storage.getString(name) ?? null,
  setItem: (name: string, value: string): void => {
    storage.set(name, value);
  },
  removeItem: (name: string): void => {
    storage.delete(name);
  },
};

interface SearchHistoryState {
  /** Most-recent-first, deduplicated, trimmed to LIMITS.searchHistory. */
  readonly history: readonly string[];
  /** Pushes a normalized (trimmed lowercase) query. No-ops under 2 chars. */
  readonly add: (rawQuery: string) => void;
  readonly clear: () => void;
}

export const useSearchHistoryStore = create<SearchHistoryState>()(
  persist(
    (set, get) => ({
      history: [],
      add: (rawQuery: string) => {
        const query = rawQuery.trim().toLowerCase().replace(/\s+/g, ' ');
        if (query.length < 2) return;
        const next = [
          query,
          ...get().history.filter((entry) => entry !== query),
        ].slice(0, LIMITS.searchHistory);
        set({ history: next });
      },
      clear: () => set({ history: [] }),
    }),
    {
      name: STORAGE_KEYS.searchHistory,
      storage: createJSONStorage(() => mmkvStateStorage),
      version: 1,
    },
  ),
);
