/**
 * Unit 08 — Explore domain service.
 *
 * Thin, deterministic facade over the Unit 05 catalog. Pure functions only;
 * the controller hook owns state. Everything here runs identically on
 * Android, iOS and Web because it depends on shared/ (platform-neutral)
 * code exclusively — no RN, no DOM.
 */
import {
  DIFFICULTY_FILTERS,
  POSE_CATEGORIES,
  filterByDifficulty,
  getCatalogReport,
  getCategorySummaries,
  getFeaturedPoses,
  getPoseById,
  getPoseCatalog,
  normalizeQuery,
  searchPoses,
  type CategorySummary,
  type Difficulty,
  type Pose,
  type PoseCategoryId,
} from '@shared/index';

export type ExploreCategoryFilter = PoseCategoryId | 'all' | 'favorites';
export type ExploreDifficultyFilter = Difficulty | 'all';

export interface ExploreFilters {
  readonly query: string;
  readonly category: ExploreCategoryFilter;
  readonly difficulty: ExploreDifficultyFilter;
  readonly favoriteIds?: readonly string[];
}

export const DEFAULT_EXPLORE_FILTERS: ExploreFilters = {
  query: '',
  category: 'all',
  difficulty: 'all',
};

export function isFiltering(f: ExploreFilters): boolean {
  return (
    normalizeQuery(f.query).length > 0 ||
    f.category !== 'all' ||
    f.difficulty !== 'all'
  );
}

export interface ExploreResult {
  readonly poses: readonly Pose[];
  readonly total: number;
  readonly filtering: boolean;
}

/** Ranked catalog query: search → category scope (or favorites) → difficulty filter. */
export function queryExplore(
  filters: ExploreFilters,
  options?: { readonly cap?: number },
): ExploreResult {
  let pool: readonly Pose[];
  if (filters.category === 'favorites') {
    const favSet = new Set(filters.favoriteIds ?? []);
    const favPoses = getPoseCatalog().filter((p) => favSet.has(p.id));
    const q = normalizeQuery(filters.query);
    if (q.length === 0) {
      pool = favPoses;
    } else {
      pool = favPoses.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)),
      );
    }
  } else {
    pool = searchPoses(filters.query, { categoryId: filters.category });
  }

  const filtered = filterByDifficulty(pool, filters.difficulty);
  const cap = options?.cap ?? Number.POSITIVE_INFINITY;
  return {
    poses: filtered.slice(0, cap),
    total: filtered.length,
    filtering: isFiltering(filters),
  };
}

/** Discovery-mode datasets (no filters active). */
export function getDiscoveryData(): {
  readonly featured: readonly Pose[];
  readonly collections: readonly CategorySummary[];
  /** First poses of the grid preview shown beneath the collections. */
  readonly gridPreview: readonly Pose[];
  readonly total: number;
} {
  return {
    featured: getFeaturedPoses(),
    collections: getCategorySummaries(),
    gridPreview: getPoseCatalog().slice(0, 12),
    total: getCatalogReport().total,
  };
}

// Re-exports so presentation imports a single module.
export {
  DIFFICULTY_FILTERS,
  POSE_CATEGORIES,
  getCatalogReport,
  getPoseById,
  normalizeQuery,
};
export type { CategorySummary, Difficulty, Pose, PoseCategoryId };
