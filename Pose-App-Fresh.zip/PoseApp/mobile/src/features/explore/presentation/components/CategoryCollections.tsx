/**
 * Unit 08 — CategoryCollections.
 * 12 collection tiles (2-col grid inside the discovery header). Tapping a
 * tile switches the screen into results mode scoped to that category.
 */
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { radius, spacing, type CategorySummary } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import type { ExploreCategoryFilter } from '../../domain/exploreService';
import { typeStyle } from '../utils/typeStyles';

interface CategoryCollectionsProps {
  readonly collections: readonly CategorySummary[];
  readonly totalPoses: number;
  readonly onOpenCategory: (category: ExploreCategoryFilter) => void;
}

export function CategoryCollections({
  collections,
  totalPoses,
  onOpenCategory,
}: CategoryCollectionsProps) {
  const theme = useAppTheme();
  return (
    <View>
      <View style={styles.header}>
        <Text style={[typeStyle('cardTitle'), { color: theme.colors.textPrimary, fontSize: 15 }]}>
          Browse collections
        </Text>
        <Text style={[typeStyle('small'), { color: theme.colors.textSecondary }]}>
          {totalPoses} poses · 12 categories
        </Text>
      </View>
      <View style={styles.grid}>
        {collections.map((meta) => {
          const tintBg = theme.isDark
            ? `hsla(${meta.hue}, 70%, 30%, 0.45)`
            : `hsl(${meta.hue}, 70%, 91%)`;
          const tintFg = theme.isDark
            ? `hsl(${meta.hue}, 65%, 70%)`
            : `hsl(${meta.hue}, 65%, 38%)`;
          return (
            <Pressable
              key={meta.id}
              onPress={() => onOpenCategory(meta.id)}
              accessibilityRole="button"
              accessibilityLabel={`Open ${meta.label} collection, ${meta.count} poses`}
              style={({ pressed }) => [
                styles.tile,
                {
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.divider,
                  opacity: pressed ? 0.85 : 1,
                },
              ]}
            >
              <View style={[styles.iconWrap, { backgroundColor: tintBg }]}>
                <MaterialCommunityIcons
                  name={meta.icon as never}
                  size={18}
                  color={tintFg}
                />
              </View>
              <View style={styles.tileText}>
                <Text
                  numberOfLines={1}
                  style={[typeStyle('small'), styles.tileTitle, { color: theme.colors.textPrimary }]}
                >
                  {meta.label}
                </Text>
                <Text style={[typeStyle('small'), styles.tileCount, { color: theme.colors.textSecondary }]}>
                  {meta.count} poses
                </Text>
              </View>
              <MaterialCommunityIcons
                name="chevron-right"
                size={14}
                color={theme.colors.textDisabled}
              />
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
  },
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    flexGrow: 1,
    flexBasis: '46%',
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tileText: {
    flex: 1,
    minWidth: 0,
  },
  tileTitle: {
    fontWeight: '600',
  },
  tileCount: {
    fontSize: 10,
    marginTop: 1,
  },
});
