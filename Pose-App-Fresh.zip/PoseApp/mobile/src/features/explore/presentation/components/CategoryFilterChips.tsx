/**
 * Unit 08 — CategoryFilterChips + DifficultyFilterChips.
 * Horizontally scrolling chip rails shown in results mode. Pure RN:
 * ScrollView/Pressable/Text only; colors exclusively from useAppTheme().
 */
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  DIFFICULTY_FILTERS,
  mediaColors,
  POSE_CATEGORIES,
  radius,
  spacing,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useFavoritesStore } from '@/features/favorites/data/favoritesStore';
import { useAuthStore } from '@/shared/stores/authStore';
import type {
  ExploreCategoryFilter,
  ExploreDifficultyFilter,
} from '../../domain/exploreService';

interface CategoryFilterChipsProps {
  readonly active: ExploreCategoryFilter;
  readonly onChange: (next: ExploreCategoryFilter) => void;
}

export function CategoryFilterChips({ active, onChange }: CategoryFilterChipsProps) {
  const theme = useAppTheme();
  const authenticated = useAuthStore((s) => s.status === 'authenticated');
  const storedFavoriteCount = useFavoritesStore((s) => s.favoriteIds.length);
  const favCount = authenticated ? storedFavoriteCount : 0;
  const options: { id: ExploreCategoryFilter; label: string; icon: string; count?: number; accent?: string }[] = [
    { id: 'all', label: 'All', icon: 'star-four-points-outline' },
    {
      id: 'favorites',
      label: 'Favorites',
      icon: 'heart',
      count: favCount,
      accent: theme.colors.error,
    },
    ...POSE_CATEGORIES.map((c) => ({ id: c.id as ExploreCategoryFilter, label: c.label, icon: c.icon })),
  ];
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.row}
    >
      {options.map((opt) => {
        const isActive = opt.id === active;
        return (
          <Pressable
            key={opt.id}
            onPress={() => onChange(opt.id)}
            accessibilityRole="button"
            accessibilityState={{ selected: isActive }}
            accessibilityLabel={`Filter by ${opt.label}`}
            style={({ pressed }) => [
              styles.chip,
              {
                borderColor: isActive ? theme.colors.primary : theme.colors.divider,
                backgroundColor: isActive ? theme.colors.primary : theme.colors.surface,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            <MaterialCommunityIcons
              name={opt.icon as never}
              size={12}
              color={
                isActive
                  ? theme.colors.textOnPrimary
                  : opt.accent ?? theme.colors.textSecondary
              }
            />
            <Text
              style={[
                styles.chipText,
                { color: isActive ? theme.colors.textOnPrimary : theme.colors.textSecondary },
              ]}
            >
              {opt.label}
            </Text>
            {opt.count !== undefined && opt.count > 0 && (
              <View
                style={[
                  styles.countPill,
                  {
                    backgroundColor: isActive
                      ? mediaColors.whiteMuted
                      : theme.colors.backgroundSecondary,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.countText,
                    {
                      color: isActive
                        ? theme.colors.textOnPrimary
                        : theme.colors.textSecondary,
                    },
                  ]}
                >
                  {opt.count}
                </Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

interface DifficultyFilterChipsProps {
  readonly active: ExploreDifficultyFilter;
  readonly onChange: (next: ExploreDifficultyFilter) => void;
}

export function DifficultyFilterChips({ active, onChange }: DifficultyFilterChipsProps) {
  const theme = useAppTheme();
  return (
    <View style={styles.diffRow}>
      {DIFFICULTY_FILTERS.map((f) => {
        const isActive = f.id === active;
        return (
          <Pressable
            key={f.id}
            onPress={() => onChange(f.id)}
            accessibilityRole="button"
            accessibilityState={{ selected: isActive }}
            accessibilityLabel={`Skill level ${f.label}`}
            style={({ pressed }) => [
              styles.diffChip,
              {
                backgroundColor: isActive
                  ? theme.colors.textPrimary
                  : theme.colors.backgroundSecondary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            <Text
              style={[
                styles.diffText,
                { color: isActive ? theme.colors.background : theme.colors.textSecondary },
              ]}
            >
              {f.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xs,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    borderWidth: 1,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  chipText: {
    fontSize: 11,
    fontWeight: '600',
  },
  countPill: {
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: radius.pill,
    marginLeft: 2,
  },
  countText: {
    fontSize: 9,
    fontWeight: '700',
  },
  diffRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  diffChip: {
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
  diffText: {
    fontSize: 10,
    fontWeight: '600',
  },
});
