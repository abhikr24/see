/**
 * Unit 08 — ExploreSearchBar (+ RecentSearchesTray).
 * Controlled TextInput with search chrome; commits to the LRU-10 history
 * store on blur/submit. Pure RN: View/Text/TextInput/Pressable only.
 */
import React, { useCallback, useState } from 'react';
import {
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { typeStyle } from '../utils/typeStyles';

interface ExploreSearchBarProps {
  readonly value: string;
  readonly onChangeText: (text: string) => void;
  readonly onCommit: () => void;
  /** ExploreScreen shows the history tray only while the field has focus. */
  readonly onFocusChange?: (focused: boolean) => void;
  readonly autoFocus?: boolean;
}

export function ExploreSearchBar({
  value,
  onChangeText,
  onCommit,
  onFocusChange,
  autoFocus = false,
}: ExploreSearchBarProps) {
  const theme = useAppTheme();
  const [focused, setFocused] = useState(false);

  const handleSubmit = useCallback(() => {
    onCommit();
  }, [onCommit]);

  return (
    <View
      style={[
        styles.bar,
        {
          backgroundColor: theme.colors.backgroundSecondary,
          borderColor: focused ? theme.colors.primary : theme.colors.divider,
        },
      ]}
    >
      <MaterialCommunityIcons
        name="magnify"
        size={18}
        color={focused ? theme.colors.primary : theme.colors.textDisabled}
      />
      <TextInput
        autoFocus={autoFocus}
        value={value}
        onChangeText={onChangeText}
        onFocus={() => {
          setFocused(true);
          onFocusChange?.(true);
        }}
        onBlur={() => {
          setFocused(false);
          onFocusChange?.(false);
          onCommit();
        }}
        onSubmitEditing={handleSubmit}
        placeholder="Search poses, tags, collections…"
        placeholderTextColor={theme.colors.textDisabled}
        returnKeyType="search"
        autoCapitalize="none"
        autoCorrect={false}
        accessibilityLabel="Search the pose library"
        style={[styles.input, typeStyle('secondaryBody'), { color: theme.colors.textPrimary }]}
      />
      {value.length > 0 && (
        <Pressable
          onPress={() => onChangeText('')}
          hitSlop={8}
          accessibilityLabel="Clear search text"
          accessibilityRole="button"
        >
          <MaterialCommunityIcons
            name="close-circle"
            size={16}
            color={theme.colors.textDisabled}
          />
        </Pressable>
      )}
    </View>
  );
}

interface RecentSearchesTrayProps {
  readonly history: readonly string[];
  readonly onSelect: (entry: string) => void;
  readonly onClear: () => void;
}

export function RecentSearchesTray({
  history,
  onSelect,
  onClear,
}: RecentSearchesTrayProps) {
  const theme = useAppTheme();
  if (history.length === 0) return null;
  return (
    <View
      style={[
        styles.tray,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
        },
      ]}
    >
      <View style={styles.trayHeader}>
        <Text style={[typeStyle('small'), styles.trayLabel, { color: theme.colors.textDisabled }]}>
          RECENT SEARCHES
        </Text>
        <Pressable onPressIn={onClear} hitSlop={8} accessibilityRole="button" accessibilityLabel="Clear search history">
          <Text style={[typeStyle('small'), { color: theme.colors.primary, fontWeight: '600' }]}>
            Clear
          </Text>
        </Pressable>
      </View>
      <View style={styles.chips}>
        {history.map((entry) => (
          /**
           * onPressIn (not onPress): on a real phone the tap arrives BEFORE
           * the keyboard-dismiss blur — otherwise the tray would unmount
           * first and the chip tap would be swallowed.
           */
          <Pressable
            key={entry}
            onPressIn={() => onSelect(entry)}
            style={({ pressed }) => [
              styles.chip,
              {
                borderColor: theme.colors.divider,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            accessibilityRole="button"
            accessibilityLabel={`Search again for ${entry}`}
          >
            <MaterialCommunityIcons
              name="history"
              size={12}
              color={theme.colors.textSecondary}
            />
            <Text style={[typeStyle('small'), { color: theme.colors.textSecondary }]}>
              {entry}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginHorizontal: spacing.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.md,
    borderWidth: 1,
  },
  input: {
    flex: 1,
    paddingVertical: spacing.sm,
  },
  tray: {
    marginHorizontal: spacing.lg,
    marginTop: spacing.sm,
    borderRadius: radius.md,
    borderWidth: 1,
    padding: spacing.md,
  },
  trayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  trayLabel: {
    fontWeight: '600',
    letterSpacing: 0.8,
  },
  chips: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    borderWidth: 1,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
});
