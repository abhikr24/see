/**
 * Unit 08 — FeaturedCarousel.
 * Snap-scrolling horizontal rail of the editor-pick poses (isFeatured).
 * FlatList with snapToInterval for cheap, native-smooth paging.
 */
import React, { useCallback } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  mediaColors,
  POSE_CATEGORIES,
  radius,
  spacing,
  type Pose,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { PoseCardArt } from './PoseCardArt';
import { FavoriteButton } from '@/features/favorites/presentation/components/FavoriteButton';
import { typeStyle } from '../utils/typeStyles';

const CARD_WIDTH = 136;
const CARD_GAP = spacing.sm;

interface FeaturedCarouselProps {
  readonly poses: readonly Pose[];
  readonly onOpenPose: (pose: Pose) => void;
}

export function FeaturedCarousel({ poses, onOpenPose }: FeaturedCarouselProps) {
  const theme = useAppTheme();

  const renderItem = useCallback(
    ({ item }: { item: Pose }) => {
      const meta = POSE_CATEGORIES.find((c) => c.id === item.category);
      return (
        <Pressable
          onPress={() => onOpenPose(item)}
          accessibilityRole="button"
          accessibilityLabel={`Featured pose ${item.title}`}
          style={({ pressed }) => [{ opacity: pressed ? 0.85 : 1 }]}
        >
          <View style={styles.card}>
            <PoseCardArt pose={item} height={144} borderRadius={radius.md} iconSize={46} showBadges={false} />
            <FavoriteButton
              poseId={item.id}
              size={15}
              style={styles.favBtn}
            />
            <View style={styles.overlay}>
              <Text numberOfLines={2} style={[typeStyle('small'), styles.title]}>
                {item.title}
              </Text>
              <View style={styles.metaRow}>
                <MaterialCommunityIcons
                  name={(meta?.icon ?? 'camera') as never}
                  size={10}
                  color={mediaColors.textMuted}
                />
                <Text style={styles.metaText}>{meta?.label ?? ''}</Text>
              </View>
            </View>
          </View>
        </Pressable>
      );
    },
    [onOpenPose],
  );

  return (
    <View>
      <View style={styles.header}>
        <Text style={[typeStyle('cardTitle'), { color: theme.colors.textPrimary, fontSize: 15 }]}>
          Featured this week
        </Text>
        <Text style={[typeStyle('small'), { color: theme.colors.textSecondary }]}>
          {poses.length} editor picks
        </Text>
      </View>
      <FlatList
        horizontal
        data={poses}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        showsHorizontalScrollIndicator={false}
        snapToInterval={CARD_WIDTH + CARD_GAP}
        decelerationRate="fast"
        contentContainerStyle={styles.list}
        initialNumToRender={6}
        windowSize={5}
        removeClippedSubviews
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  list: {
    gap: CARD_GAP,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xs,
  },
  card: {
    width: CARD_WIDTH,
  },
  favBtn: {
    position: 'absolute',
    top: spacing.xs + 2,
    right: spacing.xs + 2,
  },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: spacing.sm,
    borderBottomLeftRadius: radius.md,
    borderBottomRightRadius: radius.md,
    backgroundColor: mediaColors.overlayMedium,
  },
  title: {
    color: mediaColors.text,
    fontWeight: '600',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  metaText: {
    fontSize: 9,
    color: mediaColors.textMuted,
  },
});
