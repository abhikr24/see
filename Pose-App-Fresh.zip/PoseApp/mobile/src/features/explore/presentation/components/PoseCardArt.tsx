/**
 * Unit 08 — Pose card art (current behavior, accurate as written).
 *
 * The bundled catalog ships NO photography: `imageUrl`, `thumbnailUrl` and
 * `localAssetPath` are all null, so every card renders this branded
 * generative artwork — a category-hue field, a soft ring/base, the category
 * glyph, and Premium/Featured badges. It is deliberately abstract: it never
 * pretends to be a photograph of the named pose, and it needs no network,
 * which keeps the library fully offline.
 *
 * When real licensed reference art is bundled, render `AppImage` (expo-image,
 * disk-cached) ON TOP of this View and give it a truthful accessibility
 * label; this art then becomes the loading/offline fallback beneath it.
 *
 * Pure RN primitives — View/Text/StyleSheet only. No HTML, no CSS.
 */
import React from 'react';
import { StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { mediaColors, POSE_CATEGORIES, radius, type Pose } from '@shared/index';
import { useAppTheme } from '@/core/theme';

interface PoseCardArtProps {
  readonly pose: Pose;
  readonly height: number;
  readonly borderRadius?: number;
  readonly iconSize?: number;
  readonly showBadges?: boolean;
  readonly style?: StyleProp<ViewStyle>;
}

export function PoseCardArt({
  pose,
  height,
  borderRadius = radius.md,
  iconSize = 40,
  showBadges = true,
  style,
}: PoseCardArtProps) {
  const theme = useAppTheme();
  const meta = POSE_CATEGORIES.find((c) => c.id === pose.category);
  const hue = meta?.hue ?? 217;
  const base = theme.isDark
    ? `hsl(${hue} 48% 24%)`
    : `hsl(${hue} 74% 70%)`;
  const deep = theme.isDark
    ? `hsl(${hue} 52% 17%)`
    : `hsl(${hue} 82% 60%)`;

  return (
    <View
      style={[
        styles.art,
        { height, borderRadius, backgroundColor: base },
        style,
      ]}
    >
      <View
        style={[
          styles.ring,
          { borderColor: theme.isDark ? mediaColors.ringDark : mediaColors.ringLight },
        ]}
      />
      <View style={[styles.base, { backgroundColor: deep }]} />
      <MaterialCommunityIcons
        name={(meta?.icon ?? 'camera') as never}
        size={iconSize}
        color={theme.isDark ? mediaColors.glyphDark : mediaColors.glyphLight}
        style={styles.glyph}
      />
      {showBadges && pose.isPremium && (
        <View style={styles.badge}>
          <MaterialCommunityIcons name="crown" size={10} color={mediaColors.premiumGold} />
          <Text style={styles.badgeText}>PRO</Text>
        </View>
      )}
      {showBadges && !pose.isPremium && pose.isFeatured && (
        <View style={styles.badge}>
          <MaterialCommunityIcons name="star-four-points" size={10} color={mediaColors.text} />
          <Text style={[styles.badgeText, { color: mediaColors.text }]}>PICK</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  art: {
    overflow: 'hidden',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
  },
  ring: {
    position: 'absolute',
    top: -28,
    right: -20,
    width: 96,
    height: 96,
    borderRadius: radius.circle,
    borderWidth: 1.5,
  },
  base: {
    position: 'absolute',
    left: -30,
    bottom: -46,
    width: 120,
    height: 120,
    borderRadius: radius.circle,
    opacity: 0.35,
  },
  glyph: {
    margin: 10,
  },
  badge: {
    position: 'absolute',
    top: 8,
    left: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.overlayStrong,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.4,
    color: mediaColors.premiumGold,
  },
});
