/**
 * Unit 08 — PoseDetailSheet.
 * Modal bottom sheet: hero art, badges, description, photographer tips,
 * tags, and the "Use This Pose" CTA. The CTA's behavior (recents write,
 * auth gate for guests, camera handoff) lives in the controller — this
 * component stays presentational. Pure RN (Modal/Pressable/ScrollView).
 */
import React, { useEffect } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  POSE_CATEGORIES,
  mediaColors,
  radius,
  spacing,
  type Pose,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { FavoriteButton } from '@/features/favorites/presentation/components/FavoriteButton';
import { PoseCardArt } from './PoseCardArt';
import { DIFFICULTY_DOT, typeStyle } from '../utils/typeStyles';

interface PoseDetailSheetProps {
  readonly pose: Pose | null;
  readonly isAuthenticated: boolean;
  readonly onClose: () => void;
  readonly onUseThisPose: (pose: Pose) => void;
}

const DIFFICULTY_LABEL = {
  beginner: 'Beginner',
  intermediate: 'Intermediate',
  advanced: 'Advanced',
} as const;

export function PoseDetailSheet({
  pose,
  isAuthenticated,
  onClose,
  onUseThisPose,
}: PoseDetailSheetProps) {
  const theme = useAppTheme();
  const router = useRouter();

  useEffect(() => {
    if (pose) AppLogger.info(`[Explore] pose quick-view open → ${pose.id}`);
  }, [pose]);

  if (!pose) return null;
  const meta = POSE_CATEGORIES.find((c) => c.id === pose.category);

  /** Unit 09: quick sheet hands off to the canonical deep-linkable detail. */
  const openFullDetail = () => {
    const target = pose.id;
    onClose();
    router.push(`/pose/${target}`);
  };

  return (
    <Modal
      visible
      transparent
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent
      hardwareAccelerated
      accessibilityViewIsModal
    >
      <View style={styles.overlay}>
        <Pressable
          style={[styles.scrim, { backgroundColor: theme.colors.scrim }]}
          onPress={onClose}
          accessibilityLabel="Close pose detail"
          accessibilityRole="button"
        />
        <View style={[styles.sheet, { backgroundColor: theme.colors.background }]}>
          <PoseCardArt
            pose={pose}
            height={168}
            borderRadius={0}
            iconSize={72}
            showBadges={false}
          />
          <View style={styles.topActions}>
            <FavoriteButton
              poseId={pose.id}
              size={18}
              style={styles.favAction}
            />
            <Pressable
              onPress={onClose}
              hitSlop={8}
              accessibilityLabel="Close"
              accessibilityRole="button"
              style={styles.close}
            >
              <MaterialCommunityIcons name="close" size={16} color={mediaColors.text} />
            </Pressable>
          </View>
          <View style={styles.heroTitleRow}>
            <Text style={[typeStyle('heading'), styles.heroTitle]} numberOfLines={2}>
              {pose.title}
            </Text>
          </View>

          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.badges}>
              <View style={[styles.badgePill, { backgroundColor: theme.colors.primaryLight }]}>
                <Text style={[styles.badgeText, { color: theme.colors.primary }]}>
                  {meta?.label}
                </Text>
              </View>
              <View
                style={[
                  styles.badgePill,
                  { backgroundColor: `${DIFFICULTY_DOT[pose.difficulty]}1F` },
                ]}
              >
                <View style={[styles.smallDot, { backgroundColor: DIFFICULTY_DOT[pose.difficulty] }]} />
                <Text style={[styles.badgeText, { color: DIFFICULTY_DOT[pose.difficulty] }]}>
                  {DIFFICULTY_LABEL[pose.difficulty]}
                </Text>
              </View>
              {pose.isPremium && (
                <View style={[styles.badgePill, styles.premiumPill]}>
                  <MaterialCommunityIcons name="crown" size={10} color={mediaColors.premium} />
                  <Text style={[styles.badgeText, { color: mediaColors.premiumText }]}>Premium</Text>
                </View>
              )}
              <View style={[styles.badgePill, { backgroundColor: theme.colors.backgroundSecondary }]}>
                <MaterialCommunityIcons name="target" size={10} color={theme.colors.textSecondary} />
                <Text style={[styles.badgeText, { color: theme.colors.textSecondary }]}>
                  Auto-capture at {pose.matchTarget}%
                </Text>
              </View>
            </View>

            <Text style={[typeStyle('secondaryBody'), styles.desc, { color: theme.colors.textSecondary }]}>
              {pose.description}
            </Text>

            <Text style={[styles.sectionLabel, { color: theme.colors.textDisabled }]}>
              PHOTOGRAPHER TIPS
            </Text>
            {pose.tips.map((tip) => (
              <View key={tip} style={styles.tipRow}>
                <View style={[styles.tipDot, { backgroundColor: theme.colors.primaryLight }]}>
                  <MaterialCommunityIcons name="check" size={10} color={theme.colors.primary} />
                </View>
                <Text style={[typeStyle('secondaryBody'), styles.tipText, { color: theme.colors.textSecondary }]}>
                  {tip}
                </Text>
              </View>
            ))}

            <View style={styles.tags}>
              {pose.tags.map((tag) => (
                <View
                  key={tag}
                  style={[styles.tag, { backgroundColor: theme.colors.backgroundSecondary }]}
                >
                  <Text style={[styles.tagText, { color: theme.colors.textSecondary }]}>
                    #{tag}
                  </Text>
                </View>
              ))}
            </View>
          </ScrollView>

          <View style={[styles.ctaBar, { borderTopColor: theme.colors.divider }]}>
            <Pressable
              onPress={() => onUseThisPose(pose)}
              accessibilityRole="button"
              accessibilityLabel={`Use pose ${pose.title}`}
              style={({ pressed }) => [
                styles.cta,
                { backgroundColor: theme.colors.primary, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <MaterialCommunityIcons name="camera" size={16} color={theme.colors.textOnPrimary} />
              <Text style={[typeStyle('button'), { color: theme.colors.textOnPrimary }]}>
                Use This Pose
              </Text>
            </Pressable>
            <Text style={[styles.ctaNote, { color: theme.colors.textDisabled }]}>
              {isAuthenticated
                ? 'Opens the camera with this reference pinned for live guidance'
                : 'Sign-in required — the camera suite is an authenticated feature'}
            </Text>
            <Pressable
              onPress={openFullDetail}
              hitSlop={8}
              accessibilityRole="button"
              accessibilityLabel={`Open the full detail page for ${pose.title}`}
              style={({ pressed }) => [styles.fullDetailLink, { opacity: pressed ? 0.6 : 1 }]}
            >
              <Text style={[styles.fullDetailText, { color: theme.colors.primary }]}>
                View full detail · related poses
              </Text>
              <MaterialCommunityIcons name="chevron-right" size={14} color={theme.colors.primary} />
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  scrim: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
  },
  sheet: {
    maxHeight: '86%',
    borderTopLeftRadius: radius.xxl,
    borderTopRightRadius: radius.xxl,
    overflow: 'hidden',
  },
  topActions: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  favAction: {
    width: 32,
    height: 32,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.overlayMedium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  close: {
    width: 32,
    height: 32,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.overlayMedium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroTitleRow: {
    position: 'absolute',
    top: 168 - spacing.xl - spacing.md,
    left: spacing.lg,
    right: spacing.xxxl,
  },
  heroTitle: {
    color: mediaColors.text,
    fontSize: 17,
    textShadowColor: mediaColors.overlayStrong,
    textShadowRadius: 6,
    textShadowOffset: { width: 0, height: 1 },
  },
  scroll: {
    flexGrow: 0,
  },
  scrollContent: {
    padding: spacing.lg,
    paddingBottom: spacing.sm,
  },
  badges: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  badgePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.xs + 1,
  },
  premiumPill: {
    backgroundColor: mediaColors.premiumLight,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
  },
  smallDot: {
    width: 6,
    height: 6,
    borderRadius: radius.circle,
  },
  desc: {
    marginTop: spacing.md,
  },
  sectionLabel: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.8,
    marginTop: spacing.lg,
  },
  tipRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  tipDot: {
    width: 16,
    height: 16,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  tipText: {
    flex: 1,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.lg,
  },
  tag: {
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 3,
  },
  tagText: {
    fontSize: 10,
  },
  ctaBar: {
    borderTopWidth: 1,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.lg,
  },
  cta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    borderRadius: radius.md,
    paddingVertical: spacing.md + 2,
  },
  ctaNote: {
    fontSize: 9,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
  fullDetailLink: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    marginTop: spacing.sm,
    paddingVertical: spacing.xs,
  },
  fullDetailText: {
    fontSize: 11,
    fontWeight: '600',
  },
});
