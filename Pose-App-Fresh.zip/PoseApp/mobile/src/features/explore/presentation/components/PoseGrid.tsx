/**
 * Unit 08 — PoseGrid (2 columns) + PoseGridCard + ExploreEmptyState.
 * FlatList with numColumns=2; windowed rendering keeps 400 rows smooth.
 * Unit 24 adds onEndReached pagination (cap of 2 pages is applied by the
 * controller for now); this component is intentionally page-agnostic.
 */
import React, { useCallback } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Keyboard,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  POSE_CATEGORIES,
  radius,
  spacing,
  type Pose,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { PoseCardArt } from './PoseCardArt';
import { DIFFICULTY_DOT, typeStyle } from '../utils/typeStyles';
import { FavoriteButton } from '@/features/favorites/presentation/components/FavoriteButton';
import { EmptyStateWidget } from '@/shared/components/EmptyStateWidget';

interface PoseGridCardProps {
  readonly pose: Pose;
  readonly onPress: (pose: Pose) => void;
}

export function PoseGridCard({ pose, onPress }: PoseGridCardProps) {
  const theme = useAppTheme();
  const meta = POSE_CATEGORIES.find((c) => c.id === pose.category);
  return (
    <Pressable
      onPress={() => onPress(pose)}
      accessibilityRole="button"
      accessibilityLabel={`Pose ${pose.title}`}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
          opacity: pressed ? 0.88 : 1,
        },
      ]}
    >
      <View>
        <PoseCardArt pose={pose} height={150} borderRadius={0} iconSize={38} />
        <FavoriteButton
          poseId={pose.id}
          size={16}
          style={styles.favButton}
        />
      </View>
      <View style={styles.cardBody}>
        <Text
          numberOfLines={1}
          style={[typeStyle('small'), styles.cardTitle, { color: theme.colors.textPrimary }]}
        >
          {pose.title}
        </Text>
        <View style={styles.cardMeta}>
          <Text
            numberOfLines={1}
            style={[typeStyle('small'), styles.cardCategory, { color: theme.colors.textSecondary }]}
          >
            {meta?.label}
          </Text>
          <View
            style={[styles.dot, { backgroundColor: DIFFICULTY_DOT[pose.difficulty] }]}
            accessibilityLabel={`Difficulty ${pose.difficulty}`}
          />
        </View>
      </View>
    </Pressable>
  );
}

/**
 * Unit 23 — thin spec-variant wrapper over the generic EmptyStateWidget so
 * every empty grid renders one canonical layout. Search-specific copy can be
 * passed through by the caller (`emptyOverrides`).
 */
interface ExploreEmptyStateProps {
  readonly onClear: () => void;
  readonly isFavoritesFilter?: boolean;
  readonly overrides?: EmptyOverrides;
}

interface EmptyOverrides {
  readonly icon?: string;
  readonly title?: string;
  readonly description?: string;
  readonly buttonText?: string;
}

export function ExploreEmptyState({
  onClear,
  isFavoritesFilter = false,
  overrides,
}: ExploreEmptyStateProps) {
  return (
    <EmptyStateWidget
      icon={
        overrides?.icon ??
        (isFavoritesFilter ? 'heart-outline' : 'magnify-off')
      }
      title={
        overrides?.title ??
        (isFavoritesFilter ? 'No favorites yet' : 'No poses found')
      }
      description={
        overrides?.description ??
        (isFavoritesFilter
          ? 'Tap the heart icon on any pose to save it to your local library.'
          : 'Nothing matches that combination. Try a shorter word or clear the filters.')
      }
      buttonText={
        overrides?.buttonText ??
        (isFavoritesFilter ? 'Explore Poses' : 'Clear Filters')
      }
      onButtonPress={onClear}
      style={styles.empty}
    />
  );
}

interface PoseGridProps {
  readonly poses: readonly Pose[];
  readonly onOpenPose: (pose: Pose) => void;
  readonly header?: React.ReactElement;
  readonly footerNote?: string | null;
  readonly onClearFilters?: () => void;
  readonly isFavoritesFilter?: boolean;
  /** Unit 23: query-aware empty copy override (Search → "No results for 'q'"). */
  readonly emptyOverrides?: ExploreEmptyStateProps['overrides'];
  /** Unit 24: lazy loading onEndReached pagination. */
  readonly onEndReached?: () => void;
  readonly onEndReachedThreshold?: number;
  readonly isLoadingMore?: boolean;
}

export function PoseGrid({
  poses,
  onOpenPose,
  header,
  footerNote,
  onClearFilters,
  isFavoritesFilter = false,
  emptyOverrides,
  onEndReached,
  onEndReachedThreshold = 0.5,
  isLoadingMore = false,
}: PoseGridProps) {
  const theme = useAppTheme();

  const renderItem = useCallback(
    ({ item }: { item: Pose }) => (
      <View style={styles.cell}>
        <PoseGridCard pose={item} onPress={onOpenPose} />
      </View>
    ),
    [onOpenPose],
  );

  return (
    <FlatList
      data={poses}
      keyExtractor={(item) => item.id}
      renderItem={renderItem}
      numColumns={2}
      ListHeaderComponent={header}
      ListEmptyComponent={
        onClearFilters ? (
          <ExploreEmptyState
            onClear={onClearFilters}
            isFavoritesFilter={isFavoritesFilter}
            overrides={emptyOverrides}
          />
        ) : null
      }
      onEndReached={onEndReached}
      onEndReachedThreshold={onEndReachedThreshold}
      ListFooterComponent={
        isLoadingMore ? (
          <View style={styles.loaderWrap}>
            <ActivityIndicator size="small" color={theme.colors.primary} />
          </View>
        ) : footerNote ? (
          <Text style={[typeStyle('small'), styles.footerNote, { color: theme.colors.textDisabled }]}>
            {footerNote}
          </Text>
        ) : null
      }
      contentContainerStyle={[
        styles.content,
        { backgroundColor: theme.colors.background },
      ]}
      columnWrapperStyle={styles.columnWrapper}
      showsVerticalScrollIndicator={false}
      onScrollBeginDrag={Keyboard.dismiss}
      keyboardShouldPersistTaps="handled"
      initialNumToRender={8}
      maxToRenderPerBatch={10}
      windowSize={7}
      removeClippedSubviews
    />
  );
}

const styles = StyleSheet.create({
  content: {
    paddingBottom: spacing.xl,
  },
  columnWrapper: {
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
  },
  cell: {
    flex: 1,
    maxWidth: '50%',
    marginBottom: spacing.sm,
  },
  card: {
    borderWidth: 1,
    borderRadius: radius.md,
    overflow: 'hidden',
  },
  favButton: {
    position: 'absolute',
    top: spacing.xs + 2,
    right: spacing.xs + 2,
  },
  cardBody: {
    padding: spacing.sm,
  },
  cardTitle: {
    fontWeight: '600',
  },
  cardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: spacing.xs,
  },
  cardCategory: {
    fontSize: 10,
    flexShrink: 1,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: radius.circle,
  },
  empty: {
    alignItems: 'center',
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.xxxl,
  },
  emptyIconWrap: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyTitle: {
    marginTop: spacing.lg,
  },
  emptyDesc: {
    marginTop: spacing.xs,
    textAlign: 'center',
  },
  emptyButton: {
    marginTop: spacing.xl,
    borderRadius: radius.md,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
  },
  emptyButtonText: {
    fontSize: 14,
  },
  footerNote: {
    textAlign: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  loaderWrap: {
    paddingVertical: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
