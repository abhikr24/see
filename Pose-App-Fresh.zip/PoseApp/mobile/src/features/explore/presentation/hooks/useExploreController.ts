/**
 * Unit 08 — Explore controller hook.
 * Owns all Explore screen state: filters, search history commits, the pose
 * detail sheet, and the "Use This Pose" handoff (recents LRU + auth gate +
 * camera navigation). The screen and components stay purely presentational.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert } from 'react-native';
import { useRouter } from 'expo-router';
import type { Pose } from '@shared/index';
import { LIMITS } from '@shared/index';
import {
  DEFAULT_EXPLORE_FILTERS,
  getDiscoveryData,
  isFiltering,
  normalizeQuery,
  queryExplore,
  type ExploreCategoryFilter,
  type ExploreDifficultyFilter,
  type ExploreFilters,
} from '../../domain/exploreService';
import { useSearchHistoryStore } from '../../data/searchHistoryStore';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';
import { useFavoritesStore } from '@/features/favorites/data/favoritesStore';
import { useAuthStore } from '@/shared/stores/authStore';

export interface ExploreController {
  // filters
  readonly filters: ExploreFilters;
  readonly setQuery: (query: string) => void;
  readonly setCategory: (category: ExploreCategoryFilter) => void;
  readonly setDifficulty: (difficulty: ExploreDifficultyFilter) => void;
  readonly resetFilters: () => void;
  readonly filtering: boolean;
  readonly isSearching: boolean;
  // results
  readonly results: readonly Pose[];
  readonly resultTotal: number;
  readonly hasMore: boolean;
  readonly discovery: ReturnType<typeof getDiscoveryData>;
  // search history (LRU 10)
  readonly searchHistory: readonly string[];
  readonly commitQuery: () => void;
  readonly applyHistoryEntry: (entry: string) => void;
  readonly clearHistory: () => void;
  // detail sheet
  readonly focusedPose: Pose | null;
  readonly openPose: (pose: Pose) => void;
  readonly closePose: () => void;
  // Use This Pose
  readonly useThisPose: (pose: Pose) => void;
  readonly isAuthenticated: boolean;
}

/** Keystroke → catalog query delay. Chips stay instant; only text is debounced. */
const SEARCH_DEBOUNCE_MS = 250;

export function useExploreController(): ExploreController {
  const router = useRouter();
  const [query, setQuery] = useState(DEFAULT_EXPLORE_FILTERS.query);
  const [debouncedQuery, setDebouncedQuery] = useState(
    DEFAULT_EXPLORE_FILTERS.query,
  );
  const [category, setCategoryState] = useState<ExploreCategoryFilter>(
    DEFAULT_EXPLORE_FILTERS.category,
  );
  const [difficulty, setDifficulty] = useState<ExploreDifficultyFilter>(
    DEFAULT_EXPLORE_FILTERS.difficulty,
  );
  const [focusedPose, setFocusedPose] = useState<Pose | null>(null);

  // Debounce only the text dimension of the filter set. Category/difficulty
  // chip taps apply immediately (tactile feedback), typing settles in 250ms.
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), SEARCH_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [query]);

  const history = useSearchHistoryStore((s) => s.history);
  const addHistoryEntry = useSearchHistoryStore((s) => s.add);
  const clearHistory = useSearchHistoryStore((s) => s.clear);
  const addToRecent = useRecentPosesStore((s) => s.addToRecent);
  const favoriteIds = useFavoritesStore((s) => s.favoriteIds);
  const session = useAuthStore((s) => s.session);
  const isAuthenticated = session !== null && session !== undefined;

  const setCategory = useCallback(
    (next: ExploreCategoryFilter) => {
      if (next === 'favorites' && !isAuthenticated) {
        Alert.alert(
          'Sign in to view favorites',
          'Browsing the pose library is available without an account. Favorites are private account data.',
          [
            { text: 'Not Now', style: 'cancel' },
            { text: 'Sign In', onPress: () => router.push('/auth') },
          ],
        );
        return;
      }
      setCategoryState(next);
    },
    [isAuthenticated, router],
  );

  /** Raw input state (drives the TextField + result-count label). */
  const filters = useMemo<ExploreFilters>(
    () => ({ query, category, difficulty }),
    [query, category, difficulty],
  );
  /** Debounced filter set that actually hits the catalog. */
  const effectiveFilters = useMemo<ExploreFilters>(
    () => ({
      query: debouncedQuery,
      category,
      difficulty,
      favoriteIds: isAuthenticated ? favoriteIds : [],
    }),
    [debouncedQuery, category, difficulty, favoriteIds, isAuthenticated],
  );

  const { poses: results, total: resultTotal } = useMemo(
    () => queryExplore(effectiveFilters, { cap: LIMITS.explorePageSize * 2 }),
    [effectiveFilters],
  );

  const discovery = useMemo(() => getDiscoveryData(), []);
  const filtering = isFiltering(effectiveFilters);

  const resetFilters = useCallback(() => {
    setQuery('');
    setDebouncedQuery('');
    setCategoryState('all');
    setDifficulty('all');
  }, []);

  const commitQuery = useCallback(() => {
    const q = normalizeQuery(query);
    if (q.length >= 2) addHistoryEntry(q);
  }, [query, addHistoryEntry]);

  const applyHistoryEntry = useCallback(
    (entry: string) => {
      // History chips must apply instantly — no debounce lag.
      setQuery(entry);
      setDebouncedQuery(entry);
      addHistoryEntry(entry);
    },
    [addHistoryEntry],
  );

  const openPose = useCallback(
    (pose: Pose) => {
      setFocusedPose(pose);
      addToRecent(pose.id);
    },
    [addToRecent],
  );

  const closePose = useCallback(() => {
    setFocusedPose(null);
  }, []);

  /**
   * "Use This Pose" handoff — locks the catalog + recents write, then:
   *  · authenticated → camera tab armed with the pose (Units 12–13 read it)
   *  · guest → /auth with return intent (browse-only invariant, Unit 06)
   */
  const useThisPose = useCallback(
    (pose: Pose) => {
      addToRecent(pose.id);
      setFocusedPose(null);
      if (!isAuthenticated) {
        router.push('/auth');
        return;
      }
      // Unit 12: the camera tab arms State 2 directly from the passed poseId.
      router.push({ pathname: '/(tabs)/camera', params: { poseId: pose.id } });
    },
    [addToRecent, isAuthenticated, router],
  );

  const isSearching = query !== debouncedQuery;

  return {
    filters,
    setQuery,
    setCategory,
    setDifficulty,
    resetFilters,
    filtering,
    isSearching,
    results,
    resultTotal,
    hasMore: resultTotal > results.length,
    discovery,
    searchHistory: history,
    commitQuery,
    applyHistoryEntry,
    clearHistory,
    focusedPose,
    openPose,
    closePose,
    useThisPose,
    isAuthenticated,
  };
}
