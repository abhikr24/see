/**
 * Unit 24 — usePaginatedPoses hook.
 * Manages incremental 20/page pagination over filtered or discovery pose results.
 * Returns windowed poses, loadMore trigger, loading flag, and hasMore boolean.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LIMITS, type Pose } from '@shared/index';

interface PaginatedPosesResult {
  readonly poses: readonly Pose[];
  readonly isLoadingMore: boolean;
  readonly loadMore: () => void;
  readonly hasMore: boolean;
  readonly page: number;
}

export function usePaginatedPoses(
  sourcePoses: readonly Pose[],
  pageSize: number = LIMITS.explorePageSize,
): PaginatedPosesResult {
  const [page, setPage] = useState(1);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const loadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Reset page when source list changes (e.g. new search query or filter category)
  useEffect(() => {
    if (loadTimer.current !== null) {
      clearTimeout(loadTimer.current);
      loadTimer.current = null;
    }
    setPage(1);
    setIsLoadingMore(false);
    return () => {
      if (loadTimer.current !== null) {
        clearTimeout(loadTimer.current);
        loadTimer.current = null;
      }
    };
  }, [sourcePoses]);

  const total = sourcePoses.length;
  const currentCount = Math.min(total, page * pageSize);
  const hasMore = currentCount < total;

  const poses = useMemo(
    () => sourcePoses.slice(0, currentCount),
    [sourcePoses, currentCount],
  );

  const loadMore = useCallback(() => {
    if (!hasMore || isLoadingMore) return;
    setIsLoadingMore(true);
    // Smooth 60fps micro-batch deferral
    loadTimer.current = setTimeout(() => {
      setPage((prev) => prev + 1);
      setIsLoadingMore(false);
      loadTimer.current = null;
    }, 120);
  }, [hasMore, isLoadingMore]);

  return {
    poses,
    isLoadingMore,
    loadMore,
    hasMore,
    page,
  };
}
