/**
 * Unit 08 — ExploreScreen (the Explore tab's real screen).
 * Composition root: header, search bar + history tray, filter rails,
 * featured carousel, category collections, 2-col pose grid, pose detail
 * sheet. All logic is delegated to useExploreController; this file wires
 * pieces together only.
 */
import React, { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { AppText } from '@/shared/components/AppText';
import { ScreenHeader } from '@/shared/components/ScreenHeader';
import { useExploreController } from '../hooks/useExploreController';
import { usePaginatedPoses } from '../hooks/usePaginatedPoses';
import { ExploreSearchBar, RecentSearchesTray } from '../components/ExploreSearchBar';
import {
  CategoryFilterChips,
  DifficultyFilterChips,
} from '../components/CategoryFilterChips';
import { FeaturedCarousel } from '../components/FeaturedCarousel';
import { CategoryCollections } from '../components/CategoryCollections';
import { PoseGrid } from '../components/PoseGrid';
import { PoseDetailSheet } from '../components/PoseDetailSheet';
import { ShimmerGrid } from '@/shared/components/ShimmerSkeleton';
import { useFavoritesStore } from '@/features/favorites/data/favoritesStore';
import { IconSymbol } from '@/shared/components/IconSymbol';

export function ExploreScreen() {
  const theme = useAppTheme();
  const controller = useExploreController();
  const [searchFocused, setSearchFocused] = useState(false);
  const favoriteCount = useFavoritesStore((state) => state.favoriteIds.length);

  const trayVisible =
    searchFocused && controller.filters.query.trim().length === 0;

  const paginated = usePaginatedPoses(controller.results, 20);

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.root, { backgroundColor: theme.colors.background }]}
    >
      {/* Unit 02 shared header — one header pattern across every screen */}
      <ScreenHeader
        title="Explore"
        subtitle={`${controller.discovery.total} poses · offline catalog`}
        right={
          <Pressable
            onPress={() => controller.setCategory('favorites')}
            accessibilityRole="button"
            accessibilityLabel={
              controller.isAuthenticated
                ? `Open ${favoriteCount} favorites`
                : 'Sign in to view favorites'
            }
            style={({ pressed }) => [
              styles.favoriteShortcut,
              {
                backgroundColor: theme.colors.backgroundSecondary,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
          >
            <IconSymbol
              name="heart-outline"
              size={18}
              color={theme.colors.error}
            />
            {controller.isAuthenticated && favoriteCount > 0 && (
              <AppText variant="small" color={theme.colors.textSecondary}>
                {favoriteCount}
              </AppText>
            )}
          </Pressable>
        }
      />

      {/* Search (Unit 08) */}
      <ExploreSearchBar
        value={controller.filters.query}
        onChangeText={controller.setQuery}
        onCommit={controller.commitQuery}
        onFocusChange={setSearchFocused}
      />
      {trayVisible && (
        <RecentSearchesTray
          history={controller.searchHistory}
          onSelect={controller.applyHistoryEntry}
          onClear={() => {
            controller.clearHistory();
            AppLogger.info('[Explore] search history cleared');
          }}
        />
      )}

      {/* Filter rails (results mode only) */}
      {controller.filtering && (
        <View>
          <CategoryFilterChips
            active={controller.filters.category}
            onChange={controller.setCategory}
          />
          <DifficultyFilterChips
            active={controller.filters.difficulty}
            onChange={controller.setDifficulty}
          />
          <AppText
            variant="small"
            color={theme.colors.textSecondary}
            style={styles.resultCount}
          >
            {controller.resultTotal} result{controller.resultTotal === 1 ? '' : 's'}
            {controller.filters.query.trim().length > 0 &&
              ` for “${controller.filters.query.trim()}”`}
          </AppText>
        </View>
      )}

      {/* Grid: discovery preview vs results */}
      {controller.isSearching ? (
        <ShimmerGrid columns={2} count={6} />
      ) : controller.filtering ? (
        <PoseGrid
          poses={paginated.poses}
          onOpenPose={controller.openPose}
          onClearFilters={controller.resetFilters}
          isFavoritesFilter={controller.filters.category === 'favorites'}
          onEndReached={paginated.loadMore}
          isLoadingMore={paginated.isLoadingMore}
          footerNote={
            paginated.hasMore
              ? `Showing ${paginated.poses.length} of ${controller.resultTotal} — scroll to load more`
              : null
          }
        />
      ) : (
        <PoseGrid
          poses={controller.discovery.gridPreview}
          onOpenPose={controller.openPose}
          header={
            <View>
              <FeaturedCarousel
                poses={controller.discovery.featured}
                onOpenPose={controller.openPose}
              />
              <CategoryCollections
                collections={controller.discovery.collections}
                totalPoses={controller.discovery.total}
                onOpenCategory={(category) => {
                  controller.setCategory(category);
                  AppLogger.info(`[Explore] collection opened → ${category}`);
                }}
              />
              <View style={styles.allHeader}>
                <AppText
                  variant="cardTitle"
                  color={theme.colors.textPrimary}
                  style={styles.allTitle}
                >
                  All poses
                </AppText>
                <AppText variant="small" color={theme.colors.textSecondary}>
                  tap a card for the detail sheet
                </AppText>
              </View>
            </View>
          }
          footerNote={`Showing ${controller.discovery.gridPreview.length} of ${controller.discovery.total} — search or open a collection to see everything`}
        />
      )}

      {/* Detail + Use This Pose (Unit 08) */}
      <PoseDetailSheet
        pose={controller.focusedPose}
        isAuthenticated={controller.isAuthenticated}
        onClose={controller.closePose}
        onUseThisPose={controller.useThisPose}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  resultCount: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  allHeader: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  allTitle: {
    fontSize: 15,
  },
  favoriteShortcut: {
    minWidth: 48,
    height: 40,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
  },
});
