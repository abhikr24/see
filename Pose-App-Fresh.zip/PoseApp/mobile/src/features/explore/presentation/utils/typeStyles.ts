/**
 * Unit 08 — typography helper.
 * Maps shared typeScale tokens to RN TextStyle, including the Inter font
 * family loaded in app/_layout.tsx. Components use this instead of
 * hardcoded font sizes/weights (design-token invariant).
 */
import type { TextStyle } from 'react-native';
import { fontFamily, lightColors, typeScale, type TypeVariant } from '@shared/index';

const WEIGHT_TO_FAMILY = {
  regular: fontFamily.regular,
  medium: fontFamily.medium,
  semiBold: fontFamily.semiBold,
  bold: fontFamily.bold,
} as const;

export function typeStyle(variant: TypeVariant): TextStyle {
  const t = typeScale[variant];
  return {
    fontSize: t.fontSize,
    lineHeight: t.lineHeight,
    fontFamily: WEIGHT_TO_FAMILY[t.fontWeight],
  };
}

/** Difficulty dot colors — semantic mapping on top of theme tokens. */
export const DIFFICULTY_DOT = {
  beginner: lightColors.success,
  intermediate: lightColors.warning,
  advanced: lightColors.error,
} as const;
