/** Supabase favorites table gateway. RLS remains the final authority. */
import { requireSupabase } from '@/core/network/supabaseClient';

export interface FavoriteRemoteDataSource {
  list(userId: string): Promise<readonly string[]>;
  add(userId: string, poseId: string): Promise<void>;
  remove(userId: string, poseId: string): Promise<void>;
}

async function assertSession(userId: string): Promise<void> {
  const { data, error } = await requireSupabase().auth.getUser();
  if (error) throw error;
  if (!data.user || data.user.id !== userId) {
    throw new Error('Favorites sync rejected: authenticated user mismatch.');
  }
}

class SupabaseFavoriteRemoteDataSource implements FavoriteRemoteDataSource {
  async list(userId: string): Promise<readonly string[]> {
    await assertSession(userId);
    const { data, error } = await requireSupabase()
      .from('favorites')
      .select('pose_id')
      .eq('user_id', userId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return (data ?? []).map((row) => String(row.pose_id));
  }

  async add(userId: string, poseId: string): Promise<void> {
    await assertSession(userId);
    const { error } = await requireSupabase()
      .from('favorites')
      .upsert({ user_id: userId, pose_id: poseId }, { onConflict: 'user_id,pose_id' });
    if (error) throw error;
  }

  async remove(userId: string, poseId: string): Promise<void> {
    await assertSession(userId);
    const { error } = await requireSupabase()
      .from('favorites')
      .delete()
      .eq('user_id', userId)
      .eq('pose_id', poseId);
    if (error) throw error;
  }
}

export const favoriteRemoteDataSource: FavoriteRemoteDataSource =
  new SupabaseFavoriteRemoteDataSource();
