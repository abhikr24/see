-- Compatibility copy for Unit 11 documentation.
-- The canonical, complete migration is mobile/supabase_tables.sql.
-- Run that root file so profiles and favorites are installed together with RLS.

create extension if not exists pgcrypto;

create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  pose_id text not null check (length(pose_id) between 1 and 160),
  created_at timestamptz not null default now(),
  unique (user_id, pose_id)
);

create index if not exists favorites_user_created_idx
  on public.favorites (user_id, created_at desc);

alter table public.favorites enable row level security;
alter table public.favorites force row level security;

drop policy if exists "favorites_select_own" on public.favorites;
drop policy if exists "favorites_insert_own" on public.favorites;
drop policy if exists "favorites_delete_own" on public.favorites;

create policy "favorites_select_own" on public.favorites
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "favorites_insert_own" on public.favorites
  for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "favorites_delete_own" on public.favorites
  for delete to authenticated using ((select auth.uid()) = user_id);
