/**
 * Unit 11 - account-scoped local favorites replica.
 *
 * The local state remains responsive offline, while a durable mutation queue
 * records changes until the authenticated backend accepts them. Guest writes
 * are impossible by API design: every mutation requires a user id.
 */
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { STORAGE_KEYS } from '@shared/index';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';

const mmkvStateStorage = {
  getItem: (name: string): string | null => storage.getString(name) ?? null,
  setItem: (name: string, value: string): void => storage.set(name, value),
  removeItem: (name: string): void => storage.delete(name),
};

export type FavoriteOperation = 'add' | 'remove';

export interface FavoriteMutation {
  readonly id: string;
  readonly poseId: string;
  readonly operation: FavoriteOperation;
  readonly changedAt: number;
}

export interface FavoriteToggleResult {
  readonly favorited: boolean;
  readonly mutationId: string;
}

interface FavoritesState {
  readonly ownerId: string | null;
  readonly favoriteIds: readonly string[];
  readonly pending: readonly FavoriteMutation[];
  readonly favoritesByUser: Readonly<Record<string, readonly string[]>>;
  readonly pendingByUser: Readonly<Record<string, readonly FavoriteMutation[]>>;
  readonly prepareForUser: (userId: string) => void;
  readonly toggleForUser: (poseId: string, userId: string) => FavoriteToggleResult;
  readonly isFavorite: (poseId: string) => boolean;
  readonly applyRemoteSnapshot: (userId: string, remoteIds: readonly string[]) => void;
  readonly acknowledge: (mutationIds: readonly string[]) => void;
  readonly clearPending: () => void;
  readonly clearLocal: (preserveAccountSnapshot?: boolean) => void;
  /**
   * Account-deletion scope: drops ONLY the given account's replica buckets
   * (and the active workspace if it belongs to that account). Other
   * accounts' data and all device-level state are untouched.
   */
  readonly removeAccountData: (userId: string) => void;
}

let mutationSequence = 0;

function nextMutationId(): string {
  mutationSequence += 1;
  return `${Date.now().toString(36)}-${mutationSequence.toString(36)}`;
}

function applyMutations(
  baseIds: readonly string[],
  pending: readonly FavoriteMutation[],
): string[] {
  const result = new Set(baseIds);
  for (const mutation of pending) {
    if (mutation.operation === 'add') result.add(mutation.poseId);
    else result.delete(mutation.poseId);
  }
  return Array.from(result);
}

export const useFavoritesStore = create<FavoritesState>()(
  persist(
    (set, get) => ({
      ownerId: null,
      favoriteIds: [],
      pending: [],
      favoritesByUser: {},
      pendingByUser: {},

      prepareForUser: (userId) => {
        const current = get();
        if (current.ownerId === userId) return;
        const favoritesByUser = { ...current.favoritesByUser };
        const pendingByUser = { ...current.pendingByUser };
        if (current.ownerId) {
          favoritesByUser[current.ownerId] = current.favoriteIds;
          pendingByUser[current.ownerId] = current.pending;
        }
        // Discard stale guest/other-account state before loading this account.
        set({
          ownerId: userId,
          favoriteIds: favoritesByUser[userId] ?? [],
          pending: pendingByUser[userId] ?? [],
          favoritesByUser,
          pendingByUser,
        });
        AppLogger.info(`[Favorites] local replica owner - ${userId}`);
      },

      isFavorite: (poseId) => get().favoriteIds.includes(poseId),

      toggleForUser: (poseId, userId) => {
        get().prepareForUser(userId);
        const current = get();
        const favorited = !current.favoriteIds.includes(poseId);
        const mutation: FavoriteMutation = {
          id: nextMutationId(),
          poseId,
          operation: favorited ? 'add' : 'remove',
          changedAt: Date.now(),
        };
        // Keep only the newest unsent intent per pose.
        const pending = [
          ...current.pending.filter((item) => item.poseId !== poseId),
          mutation,
        ];
        const favoriteIds = favorited
          ? [...current.favoriteIds, poseId]
          : current.favoriteIds.filter((id) => id !== poseId);
        set({
          favoriteIds,
          pending,
          favoritesByUser: { ...current.favoritesByUser, [userId]: favoriteIds },
          pendingByUser: { ...current.pendingByUser, [userId]: pending },
        });
        AppLogger.info(
          `[Favorites] ${favorited ? 'added' : 'removed'} ${poseId} (${favoriteIds.length})`,
        );
        return { favorited, mutationId: mutation.id };
      },

      applyRemoteSnapshot: (userId, remoteIds) => {
        get().prepareForUser(userId);
        const pending = get().pending;
        const favoriteIds = applyMutations(remoteIds, pending);
        set((state) => ({
          favoriteIds,
          favoritesByUser: { ...state.favoritesByUser, [userId]: favoriteIds },
        }));
      },

      acknowledge: (mutationIds) => {
        const acknowledged = new Set(mutationIds);
        set((state) => {
          const pending = state.pending.filter(
            (mutation) => !acknowledged.has(mutation.id),
          );
          return {
            pending,
            pendingByUser: state.ownerId
              ? { ...state.pendingByUser, [state.ownerId]: pending }
              : state.pendingByUser,
          };
        });
      },

      clearPending: () =>
        set((state) => ({
          pending: [],
          pendingByUser: state.ownerId
            ? { ...state.pendingByUser, [state.ownerId]: [] }
            : state.pendingByUser,
        })),

      clearLocal: (preserveAccountSnapshot = false) => {
        const state = get();
        const favoritesByUser = preserveAccountSnapshot
          ? {
              ...state.favoritesByUser,
              ...(state.ownerId ? { [state.ownerId]: state.favoriteIds } : {}),
            }
          : {};
        const pendingByUser = preserveAccountSnapshot
          ? {
              ...state.pendingByUser,
              ...(state.ownerId ? { [state.ownerId]: state.pending } : {}),
            }
          : {};
        set({
          ownerId: null,
          favoriteIds: [],
          pending: [],
          favoritesByUser,
          pendingByUser,
        });
      },

      removeAccountData: (userId) => {
        const state = get();
        const ownedByDeleted = state.ownerId === userId;
        const favoritesByUser = { ...state.favoritesByUser };
        const pendingByUser = { ...state.pendingByUser };
        delete favoritesByUser[userId];
        delete pendingByUser[userId];
        set({
          ownerId: ownedByDeleted ? null : state.ownerId,
          favoriteIds: ownedByDeleted ? [] : state.favoriteIds,
          pending: ownedByDeleted ? [] : state.pending,
          favoritesByUser,
          pendingByUser,
        });
        AppLogger.info(`[Favorites] account replica removed - ${userId}`);
      },
    }),
    {
      name: STORAGE_KEYS.favorites,
      storage: createJSONStorage(() => mmkvStateStorage),
      version: 2,
      // Version 1 allowed unauthenticated favorites. Dropping that payload is
      // required by the V1 auth invariant and prevents cross-account leakage.
      migrate: () => ({
        ownerId: null,
        favoriteIds: [],
        pending: [],
        favoritesByUser: {},
        pendingByUser: {},
      }),
      partialize: (state) => ({
        ownerId: state.ownerId,
        favoriteIds: state.favoriteIds,
        pending: state.pending,
        favoritesByUser: state.favoritesByUser,
        pendingByUser: state.pendingByUser,
      }),
    },
  ),
);
