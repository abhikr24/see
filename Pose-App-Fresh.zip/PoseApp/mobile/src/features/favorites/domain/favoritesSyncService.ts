/**
 * Unit 11 - durable favorites synchronization.
 *
 * Cloud is the last confirmed snapshot; pending local mutations are replayed
 * over it and retained until Supabase confirms each operation. Demo mode is
 * intentionally local-only, matching ENV-SETUP.md.
 */
import { isDemoMode } from '@/core/network/supabaseClient';
import { AppLogger } from '@/core/utils/logger';
import { favoriteRemoteDataSource } from '../data/favoriteRemoteDataSource';
import {
  useFavoritesStore,
  type FavoriteMutation,
} from '../data/favoritesStore';

export interface SyncStats {
  readonly pushed: number;
  readonly pulled: number;
  readonly total: number;
  readonly pending: number;
  readonly mode: 'demo-local' | 'cloud';
}

let activeSync: Promise<SyncStats> | null = null;

async function pushMutation(userId: string, mutation: FavoriteMutation): Promise<void> {
  if (mutation.operation === 'add') {
    await favoriteRemoteDataSource.add(userId, mutation.poseId);
  } else {
    await favoriteRemoteDataSource.remove(userId, mutation.poseId);
  }
}

async function runSync(userId: string): Promise<SyncStats> {
  useFavoritesStore.getState().prepareForUser(userId);

  if (isDemoMode) {
    // Demo auth is real local behavior, but it must never pretend a cloud
    // round-trip occurred or inject made-up favorites into user data.
    useFavoritesStore.getState().clearPending();
    const total = useFavoritesStore.getState().favoriteIds.length;
    AppLogger.info(`[FavoritesSync] demo mode - ${total} local favorites`);
    return { pushed: 0, pulled: 0, total, pending: 0, mode: 'demo-local' };
  }

  const before = new Set(useFavoritesStore.getState().favoriteIds);
  const remoteIds = await favoriteRemoteDataSource.list(userId);
  useFavoritesStore.getState().applyRemoteSnapshot(userId, remoteIds);
  const pulled = remoteIds.filter((id) => !before.has(id)).length;
  const pending = [...useFavoritesStore.getState().pending].sort(
    (left, right) => left.changedAt - right.changedAt,
  );
  const acknowledged: string[] = [];

  for (const mutation of pending) {
    try {
      await pushMutation(userId, mutation);
      acknowledged.push(mutation.id);
    } catch (error) {
      // Stop in order: later intent must not overtake an earlier failed write.
      AppLogger.warn(
        `[FavoritesSync] mutation retained for retry - ${mutation.poseId}: ${String(error)}`,
      );
      break;
    }
  }

  useFavoritesStore.getState().acknowledge(acknowledged);
  const finalState = useFavoritesStore.getState();
  const stats: SyncStats = {
    pushed: acknowledged.length,
    pulled,
    total: finalState.favoriteIds.length,
    pending: finalState.pending.length,
    mode: 'cloud',
  };
  AppLogger.info(
    `[FavoritesSync] complete - ${stats.total} total, ${stats.pushed} pushed, ${stats.pulled} pulled, ${stats.pending} pending`,
  );
  return stats;
}

export function syncFavoritesWithCloud(userId: string): Promise<SyncStats> {
  // A mutation arriving during an active sync gets a follow-up pass; it is
  // never silently left pending until a later app launch.
  if (activeSync !== null) {
    return activeSync
      .catch((error) => {
        AppLogger.warn(`[FavoritesSync] active pass failed before retry - ${String(error)}`);
        return undefined;
      })
      .then(() => syncFavoritesWithCloud(userId));
  }
  activeSync = runSync(userId).finally(() => {
    activeSync = null;
  });
  return activeSync;
}

export async function flushFavoriteChanges(userId: string): Promise<void> {
  try {
    await syncFavoritesWithCloud(userId);
  } catch (error) {
    // Optimistic UI remains correct locally; the durable queue retries on the
    // next sign-in, app restore, or favorite action.
    AppLogger.warn(`[FavoritesSync] offline; queued changes preserved - ${String(error)}`);
  }
}
