/**
 * Unit 11 - FavoriteButton.
 * Heart toggle with a Reanimated spring-scale bounce animation (0.8 -> 1.25 -> 1.0).
 * Accessible, 48px minimum touch target option via hitSlop, theme-aware.
 * Pure React Native — zero DOM elements, zero web APIs.
 */
import React, { useCallback } from 'react';
import {
  Alert,
  Pressable,
  StyleSheet,
  type GestureResponderEvent,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { useRouter } from 'expo-router';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
} from 'react-native-reanimated';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { radius } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useFavoritesStore } from '../../data/favoritesStore';
import { useAuthStore } from '@/shared/stores/authStore';
import { flushFavoriteChanges } from '../../domain/favoritesSyncService';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';
import { showSuccessSnackBar } from '@/shared/stores/snackBarStore';

interface FavoriteButtonProps {
  readonly poseId: string;
  readonly size?: number;
  readonly activeColor?: string;
  readonly inactiveColor?: string;
  readonly showBackground?: boolean;
  readonly backgroundColor?: string;
  readonly style?: StyleProp<ViewStyle>;
  readonly onToggle?: (favorited: boolean) => void;
}

export function FavoriteButton({
  poseId,
  size = 20,
  activeColor,
  inactiveColor,
  showBackground = true,
  backgroundColor,
  style,
  onToggle,
}: FavoriteButtonProps) {
  const theme = useAppTheme();
  const router = useRouter();
  const storedFavorite = useFavoritesStore((s) => s.isFavorite(poseId));
  const toggleFav = useFavoritesStore((s) => s.toggleForUser);
  const session = useAuthStore((s) => s.session);
  const isFav = session !== null && storedFavorite;
  const scale = useSharedValue(1);
  const reduceMotion = useReducedMotion();

  const handlePress = useCallback((event: GestureResponderEvent) => {
    event.stopPropagation();
    if (!session) {
      Alert.alert(
        'Sign in to save favorites',
        'Browsing stays open to everyone. Saving poses requires an account.',
        [
          { text: 'Not Now', style: 'cancel' },
          { text: 'Sign In', onPress: () => router.push('/auth') },
        ],
      );
      return;
    }
    if (!reduceMotion) {
      scale.value = withSequence(
        withSpring(0.75, { damping: 10, stiffness: 400 }),
        withSpring(1.28, { damping: 6, stiffness: 300 }),
        withSpring(1, { damping: 12, stiffness: 200 }),
      );
    }
    const result = toggleFav(poseId, session.id);
    void flushFavoriteChanges(session.id);
    showSuccessSnackBar(result.favorited ? 'Added to favorites' : 'Removed from favorites');
    onToggle?.(result.favorited);
  }, [poseId, router, toggleFav, session, scale, reduceMotion, onToggle]);

  const animatedIconStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <Pressable
      onPress={handlePress}
      hitSlop={10}
      accessibilityRole="button"
      accessibilityLabel={isFav ? 'Remove from favorites' : 'Add to favorites'}
      accessibilityState={{ selected: isFav }}
      style={({ pressed }) => [
        styles.base,
        showBackground && [
          styles.bg,
          { backgroundColor: backgroundColor ?? theme.colors.cameraOverlay },
        ],
        { opacity: pressed ? 0.75 : 1 },
        style,
      ]}
    >
      <Animated.View style={animatedIconStyle}>
        <MaterialCommunityIcons
          name={isFav ? 'heart' : 'heart-outline'}
          size={size}
          color={
            isFav
              ? activeColor ?? theme.colors.error
              : inactiveColor ?? theme.colors.textDisabled
          }
        />
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  bg: {
    width: 34,
    height: 34,
    borderRadius: radius.circle,
  },
});
