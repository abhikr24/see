/**
 * Unit 11 — GuestSyncBanner.
 *
 * Legacy-named auth prompt retained for source compatibility. Guests cannot
 * own favorites in V1; this component never claims that guest data was saved.
 * Pure React Native — zero DOM elements, zero CSS.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface GuestSyncBannerProps {
  readonly favoriteCount?: number;
}

export function GuestSyncBanner(_props: GuestSyncBannerProps) {
  const theme = useAppTheme();
  const router = useRouter();

  return (
    <View
      style={[
        styles.banner,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
        },
      ]}
    >
      <View style={styles.content}>
        <View
          style={[
            styles.iconWrap,
            { backgroundColor: `${theme.colors.primary}18` },
          ]}
        >
          <IconSymbol name="cloud-sync-outline" size={20} color={theme.colors.primary} />
        </View>
        <View style={styles.textWrap}>
          <AppText variant="small" color={theme.colors.textPrimary} style={styles.title}>
            Sign in to use favorites
          </AppText>
          <AppText variant="small" color={theme.colors.textSecondary} style={styles.desc}>
            Favorites are private account data and sync across your devices.
          </AppText>
        </View>
      </View>

      <Pressable
        onPress={() => router.push('/auth')}
        accessibilityRole="button"
        accessibilityLabel="Sign in to sync favorites"
        style={({ pressed }) => [
          styles.btn,
          {
            backgroundColor: theme.colors.primary,
            opacity: pressed ? 0.85 : 1,
          },
        ]}
      >
        <AppText variant="small" color={theme.colors.textOnPrimary} style={styles.btnText}>
          Sign In
        </AppText>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    marginHorizontal: spacing.lg,
    marginVertical: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.sm,
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: {
    flex: 1,
  },
  title: {
    fontWeight: '600',
  },
  desc: {
    fontSize: 10,
    marginTop: 1,
  },
  btn: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs + 2,
    borderRadius: radius.sm,
  },
  btnText: {
    fontWeight: '600',
  },
});
