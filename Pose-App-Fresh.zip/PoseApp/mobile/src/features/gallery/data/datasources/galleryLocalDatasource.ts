/**
 * Unit 13 — MMKV gallery metadata + app-owned photo files.
 *
 * The CameraView returns a cache URI. Before saving, `persistCapturedFile`
 * copies it to Documents/PoseAssist so app Gallery metadata never points at
 * an OS-evictable cache file. MediaLibrary separately copies that durable URI
 * to the user's device gallery. No backend is imported here by design.
 */
import * as FileSystem from 'expo-file-system/legacy';
import { STORAGE_KEYS } from '@shared/index';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';
import type { GalleryPhoto } from '../../domain/entities/galleryPhoto';

const CAPTURE_DIRECTORY = `${FileSystem.documentDirectory ?? ''}PoseAssist/`;
let photoIdSequence = 0;

export function createGalleryPhotoId(): string {
  photoIdSequence += 1;
  return `photo-${Date.now().toString(36)}-${photoIdSequence.toString(36)}`;
}

function storageKey(userId: string): string {
  if (userId.trim().length === 0) throw new Error('A user id is required for Gallery data.');
  return `${STORAGE_KEYS.galleryPhotos}.${userId}`;
}

/**
 * Migrates the pre-audit global Gallery key once into the first authenticated
 * account that opens Gallery. This preserves existing captures while ending
 * cross-account visibility; the global key is then removed permanently.
 */
function rawForUser(userId: string): string | undefined {
  const key = storageKey(userId);
  const scoped = storage.getString(key);
  if (scoped !== undefined) return scoped;
  const legacy = storage.getString(STORAGE_KEYS.galleryPhotos);
  if (legacy !== undefined) {
    storage.set(key, legacy);
    storage.delete(STORAGE_KEYS.galleryPhotos);
    AppLogger.info('[GalleryLocal] migrated legacy metadata into account scope');
  }
  return legacy;
}

function readPhotos(userId: string): GalleryPhoto[] {
  const raw = rawForUser(userId);
  if (raw === undefined) return [];
  try {
    const value = JSON.parse(raw) as unknown;
    if (!Array.isArray(value)) return [];
    return value.filter(
      (entry): entry is GalleryPhoto =>
        typeof entry === 'object' &&
        entry !== null &&
        typeof (entry as GalleryPhoto).id === 'string' &&
        ((entry as GalleryPhoto).poseId === null ||
          typeof (entry as GalleryPhoto).poseId === 'string') &&
        typeof (entry as GalleryPhoto).imagePath === 'string' &&
        ['original', 'vivid', 'warm', 'cool', 'bw'].includes(
          String((entry as GalleryPhoto).filterUsed),
        ) &&
        typeof (entry as GalleryPhoto).timestamp === 'number',
    );
  } catch (error) {
    AppLogger.error(`[GalleryLocal] corrupted metadata reset — ${String(error)}`);
    storage.delete(storageKey(userId));
    return [];
  }
}

function writePhotos(userId: string, photos: readonly GalleryPhoto[]): void {
  storage.set(storageKey(userId), JSON.stringify(photos));
}

async function verifiedPhotosForUser(userId: string): Promise<readonly GalleryPhoto[]> {
  const photos = readPhotos(userId);
  const checks = await Promise.all(
    photos.map(async (photo) => ({
      photo,
      exists: (await FileSystem.getInfoAsync(photo.imagePath)).exists,
    })),
  );
  const valid = checks.filter((entry) => entry.exists).map((entry) => entry.photo);
  if (valid.length !== photos.length) {
    writePhotos(userId, valid);
    AppLogger.warn(
      `[GalleryLocal] removed ${photos.length - valid.length} stale metadata record(s)`,
    );
  }
  return valid.sort((left, right) => right.timestamp - left.timestamp);
}

function fileDirectoryForUser(userId: string): string {
  const safeOwner = userId.replace(/[^a-zA-Z0-9_-]/g, '_');
  return `${CAPTURE_DIRECTORY}${safeOwner}/`;
}

export async function persistCapturedFile(
  sourceUri: string,
  id: string,
  userId: string,
): Promise<string> {
  if (FileSystem.documentDirectory === null) {
    throw new Error('Persistent app storage is unavailable on this device.');
  }
  const directory = fileDirectoryForUser(userId);
  await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
  const destination = `${directory}${id}.jpg`;
  await FileSystem.copyAsync({ from: sourceUri, to: destination });
  return destination;
}

/**
 * POST-CAPTURE EDITING — swaps a saved photo's file for an edited rendering.
 *
 * The edited bytes are written to the cache by `core/camera/photoEditor` and
 * then MOVED in here, under a NEW filename in the same account-scoped folder.
 * A new name rather than an overwrite, deliberately:
 *
 *   · `expo-image` caches aggressively by URI, so overwriting `<id>.jpg` in
 *     place would leave the gallery grid and the full-screen preview showing
 *     the pre-edit picture until the cache happened to evict it — the app
 *     would look broken while the file on disk was already correct;
 *   · the old file is deleted only AFTER the new one is in place, so a crash
 *     mid-edit costs a cache file rather than the photograph.
 *
 * MMKV still holds metadata only — the path string and an `editedAt` stamp.
 * No image bytes ever enter key-value storage.
 */
export async function replaceStoredPhotoFile(
  userId: string,
  photoId: string,
  editedUri: string,
): Promise<string> {
  const photos = readPhotos(userId);
  const target = photos.find((photo) => photo.id === photoId);
  if (target === undefined) throw new Error('This photo is no longer in your gallery.');

  const directory = fileDirectoryForUser(userId);
  await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
  const editedAt = Date.now();
  const destination = `${directory}${photoId}-e${editedAt.toString(36)}.jpg`;
  await FileSystem.moveAsync({ from: editedUri, to: destination });

  const previousPath = target.imagePath;
  writePhotos(
    userId,
    readPhotos(userId).map((photo) =>
      photo.id === photoId ? { ...photo, imagePath: destination, editedAt } : photo,
    ),
  );
  if (previousPath !== destination) {
    await deleteLocalPhotoFile(previousPath).catch((error) => {
      AppLogger.warn(`[GalleryLocal] pre-edit file removal deferred — ${String(error)}`);
    });
  }
  AppLogger.info(`[GalleryLocal] edited file swapped in — ${photoId}`);
  return destination;
}

export async function deleteLocalPhotoFile(uri: string): Promise<void> {
  if (!uri.startsWith('file://')) return;
  await FileSystem.deleteAsync(uri, { idempotent: true });
}

export const galleryLocalDatasource = {
  savePhoto(userId: string, photo: GalleryPhoto): void {
    const existing = readPhotos(userId).filter((item) => item.id !== photo.id);
    writePhotos(userId, [photo, ...existing]);
    AppLogger.info(`[GalleryLocal] metadata saved — ${photo.id}`);
  },

  getPhotos(userId: string): readonly GalleryPhoto[] {
    return readPhotos(userId).sort((left, right) => right.timestamp - left.timestamp);
  },

  /** Prunes metadata whose durable app file disappeared outside the app. */
  async getVerifiedPhotos(userId: string): Promise<readonly GalleryPhoto[]> {
    return verifiedPhotosForUser(userId);
  },

  async getVerifiedPhoto(userId: string, id: string): Promise<GalleryPhoto | null> {
    const photos = await verifiedPhotosForUser(userId);
    return photos.find((photo) => photo.id === id) ?? null;
  },

  async deletePhoto(userId: string, id: string): Promise<void> {
    const photos = readPhotos(userId);
    const target = photos.find((photo) => photo.id === id);
    if (target !== undefined) await deleteLocalPhotoFile(target.imagePath);
    // Re-read after async file I/O. A concurrent Save must never be overwritten
    // by the older snapshot captured before deletion began.
    writePhotos(
      userId,
      readPhotos(userId).filter((photo) => photo.id !== id),
    );
    AppLogger.info(`[GalleryLocal] photo deleted — ${id}`);
  },

  /**
   * Unit 21 — Clear All Data.
   * Removes every app-owned capture file plus its metadata for this account.
   * Photos the user already saved to the SYSTEM gallery are theirs and are
   * deliberately never touched by this operation.
   */
  async deleteAllPhotos(userId: string): Promise<void> {
    const photos = readPhotos(userId);
    await Promise.all(
      photos.map((photo) =>
        deleteLocalPhotoFile(photo.imagePath).catch((error) => {
          AppLogger.warn(`[GalleryLocal] file removal deferred — ${String(error)}`);
        }),
      ),
    );
    writePhotos(userId, []);
    AppLogger.info(`[GalleryLocal] all app captures cleared — ${photos.length} file(s)`);
  },
};
