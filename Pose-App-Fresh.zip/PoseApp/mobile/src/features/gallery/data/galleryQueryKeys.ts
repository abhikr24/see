/** React Query keys for device-only Gallery metadata, scoped per account. */
export const GALLERY_QUERY_KEY = ['gallery', 'photos'] as const;

export function galleryPhotosQueryKey(userId: string | null) {
  return [...GALLERY_QUERY_KEY, userId] as const;
}

export function galleryPhotoQueryKey(userId: string | null, photoId: string | null) {
  return ['gallery', 'photo', userId, photoId] as const;
}
