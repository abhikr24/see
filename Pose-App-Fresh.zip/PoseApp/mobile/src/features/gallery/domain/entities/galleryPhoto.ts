import type { CameraFilterId } from '@/core/camera/cameraService';

/** Device-only gallery metadata. `imagePath` is never sent to Supabase. */
export interface GalleryPhoto {
  readonly id: string;
  readonly poseId: string | null;
  readonly imagePath: string;
  readonly filterUsed: CameraFilterId;
  readonly timestamp: number;
  /**
   * POST-CAPTURE EDITING — when this photo was last cropped / rotated /
   * enhanced. Optional so every record written before the feature existed
   * stays valid (and so the MMKV validator needs no migration): absent means
   * "never edited". `timestamp` deliberately still means WHEN IT WAS TAKEN,
   * because an edit must not re-sort the user's gallery.
   */
  readonly editedAt?: number;
}
