import React from 'react';
import { StyleSheet, View } from 'react-native';
import { spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';

export function DateHeader({ title }: { readonly title: string }) {
  const theme = useAppTheme();
  return (
    <View style={styles.header}>
      <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.text}>
        {title}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
  },
  text: {
    fontWeight: '500',
  },
});
