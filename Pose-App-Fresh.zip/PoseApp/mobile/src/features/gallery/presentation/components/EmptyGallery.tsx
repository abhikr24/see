/**
 * Unit 14 — EmptyGallery; Unit 23 — consolidated onto the generic
 * EmptyStateWidget so all five feature empties share one canonical layout.
 * Spec variant: image-multiple + "No photos yet" + "Start Camera".
 */
import React from 'react';
import { StyleSheet } from 'react-native';
import { useRouter } from 'expo-router';
import { EmptyStateWidget } from '@/shared/components/EmptyStateWidget';

export function EmptyGallery() {
  const router = useRouter();
  return (
    <EmptyStateWidget
      icon="image-multiple-outline"
      title="No photos yet"
      description="Your captured photos will appear here."
      buttonText="Start Camera"
      buttonIcon="camera-outline"
      onButtonPress={() => router.push('/(tabs)/camera')}
      style={styles.root}
    />
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
});
