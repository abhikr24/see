/** Date-grouped, three-column app-captured photo grid. */
import React, { memo, useCallback } from 'react';
import { ActivityIndicator, Pressable, SectionList, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppImage } from '@/shared/components/AppImage';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { DateHeader } from './DateHeader';
import type { GalleryRow, GallerySection } from '../hooks/useGallery';

function PhotoRow({ row }: { readonly row: GalleryRow }) {
  const theme = useAppTheme();
  const router = useRouter();
  return (
    <View style={styles.row}>
      {row.photos.map((photo) => (
        <Pressable
          key={photo.id}
          onPress={() => router.push(`/gallery/photo/${photo.id}`)}
          accessibilityRole="button"
          accessibilityLabel={`Open photo captured ${new Date(photo.timestamp).toLocaleDateString()}`}
          style={({ pressed }) => [
            styles.cell,
            { backgroundColor: theme.colors.backgroundSecondary, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <View style={styles.imageFallback} pointerEvents="none">
            <IconSymbol name="image-off-outline" size={24} color={theme.colors.textDisabled} />
          </View>
          <AppImage uri={photo.imagePath} accessibilityLabel="App-captured photo" style={StyleSheet.absoluteFill} />
        </Pressable>
      ))}
      {Array.from({ length: 3 - row.photos.length }, (_, index) => (
        <View key={`spacer-${index}`} style={styles.spacer} />
      ))}
    </View>
  );
}

const MemoPhotoRow = memo(PhotoRow);

interface GalleryGridProps {
  readonly sections: readonly GallerySection[];
  readonly header: React.ReactElement;
  readonly refreshing: boolean;
  readonly onRefresh: () => void;
  readonly onEndReached?: () => void;
  readonly isLoadingMore?: boolean;
}

export function GalleryGrid({
  sections,
  header,
  refreshing,
  onRefresh,
  onEndReached,
  isLoadingMore = false,
}: GalleryGridProps) {
  const theme = useAppTheme();
  const renderRow = useCallback(
    ({ item }: { item: GalleryRow }) => <MemoPhotoRow row={item} />,
    [],
  );
  return (
    <SectionList
      sections={sections as GallerySection[]}
      keyExtractor={(item) => item.id}
      renderItem={renderRow}
      renderSectionHeader={({ section }) => <DateHeader title={section.title} />}
      ListHeaderComponent={header}
      ListFooterComponent={
        isLoadingMore ? (
          <View style={styles.loaderWrap}>
            <ActivityIndicator size="small" color={theme.colors.primary} />
          </View>
        ) : null
      }
      onEndReached={onEndReached}
      onEndReachedThreshold={0.5}
      contentContainerStyle={styles.content}
      stickySectionHeadersEnabled={false}
      showsVerticalScrollIndicator={false}
      refreshing={refreshing}
      onRefresh={onRefresh}
      initialNumToRender={8}
      maxToRenderPerBatch={10}
      windowSize={7}
    />
  );
}

const styles = StyleSheet.create({
  content: {
    paddingBottom: spacing.xl,
  },
  row: {
    flexDirection: 'row',
    gap: spacing.xs,
    paddingHorizontal: spacing.xs,
    marginBottom: spacing.xs,
  },
  cell: {
    flex: 1,
    aspectRatio: 1,
    borderRadius: radius.sm,
    overflow: 'hidden',
  },
  imageFallback: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    alignItems: 'center',
    justifyContent: 'center',
  },
  spacer: {
    flex: 1,
  },
  loaderWrap: {
    paddingVertical: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
