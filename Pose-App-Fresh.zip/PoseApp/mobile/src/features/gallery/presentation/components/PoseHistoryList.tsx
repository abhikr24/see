/** Distinct gallery + recent pose history; tap arms Camera State 2. */
import React, { memo, useCallback } from 'react';
import { FlatList, Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing, type Pose } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useAddToRecent } from '@/features/poses/presentation/hooks/usePoses';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';
import { AppText } from '@/shared/components/AppText';

interface PoseHistoryListProps {
  readonly poses: readonly Pose[];
}

function HistoryItem({
  pose,
  onPress,
}: {
  readonly pose: Pose;
  readonly onPress: (pose: Pose) => void;
}) {
  const theme = useAppTheme();
  return (
    <Pressable
      onPress={() => onPress(pose)}
      accessibilityRole="button"
      accessibilityLabel={`Reuse pose ${pose.title}`}
      style={({ pressed }) => [styles.item, { opacity: pressed ? 0.8 : 1 }]}
    >
      {/* No licensed pose photography exists yet; honest branded art only. */}
      <PoseCardArt pose={pose} height={80} borderRadius={radius.md} iconSize={24} showBadges={false} />
      <AppText variant="small" color={theme.colors.textPrimary} numberOfLines={2} style={styles.title}>
        {pose.title}
      </AppText>
    </Pressable>
  );
}

const MemoHistoryItem = memo(HistoryItem);

export function PoseHistoryList({ poses }: PoseHistoryListProps) {
  const theme = useAppTheme();
  const router = useRouter();
  const addToRecent = useAddToRecent();

  const handleSelect = useCallback(
    (pose: Pose) => {
      addToRecent(pose.id);
      router.push({ pathname: '/(tabs)/camera', params: { poseId: pose.id } });
    },
    [addToRecent, router],
  );

  const renderItem = useCallback(
    ({ item }: { item: Pose }) => <MemoHistoryItem pose={item} onPress={handleSelect} />,
    [handleSelect],
  );
  if (poses.length === 0) return null;
  return (
    <View style={styles.section}>
      <AppText variant="cardTitle" color={theme.colors.textPrimary} style={styles.heading}>
        Pose History
      </AppText>
      <FlatList
        horizontal
        data={poses}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        showsHorizontalScrollIndicator={false}
        initialNumToRender={6}
        maxToRenderPerBatch={8}
        windowSize={5}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    height: 152,
  },
  heading: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    fontSize: 18,
  },
  list: {
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  item: {
    width: 80,
  },
  title: {
    marginTop: spacing.xs,
    fontSize: 11,
    lineHeight: 14,
  },
});
