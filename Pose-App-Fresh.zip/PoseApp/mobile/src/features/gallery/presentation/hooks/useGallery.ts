/**
 * Unit 14 Gallery hooks. React Query coordinates MMKV/file reads and delete
 * mutations; recents stay in their existing Zustand store.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { LIMITS, getPoseById, type Pose, type PhotoEdit } from '@shared/index';
import { discardEditTempFile, renderPhotoEdit } from '@/core/camera/photoEditor';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';
import { useAuthStore } from '@/shared/stores/authStore';
import {
  galleryLocalDatasource,
  replaceStoredPhotoFile,
} from '../../data/datasources/galleryLocalDatasource';
import type { GalleryPhoto } from '../../domain/entities/galleryPhoto';
import {
  galleryPhotoQueryKey,
  galleryPhotosQueryKey,
} from '../../data/galleryQueryKeys';

export interface GalleryRow {
  readonly id: string;
  readonly photos: readonly GalleryPhoto[];
}

export interface GallerySection {
  readonly title: string;
  readonly data: readonly GalleryRow[];
}

export function useGalleryPhotos() {
  const userId = useAuthStore((state) => state.session?.id ?? null);
  return useQuery({
    queryKey: galleryPhotosQueryKey(userId),
    queryFn: () =>
      userId === null
        ? Promise.resolve([])
        : galleryLocalDatasource.getVerifiedPhotos(userId),
    enabled: userId !== null,
    staleTime: 0,
  });
}

export function useGalleryPhoto(id: string | null) {
  const userId = useAuthStore((state) => state.session?.id ?? null);
  return useQuery({
    queryKey: galleryPhotoQueryKey(userId, id),
    queryFn: () =>
      id === null || userId === null
        ? Promise.resolve(null)
        : galleryLocalDatasource.getVerifiedPhoto(userId, id),
    enabled: id !== null && userId !== null,
    staleTime: 0,
  });
}

function dayStart(timestamp: number): number {
  const date = new Date(timestamp);
  date.setHours(0, 0, 0, 0);
  return date.getTime();
}

export function galleryDateLabel(timestamp: number, now = Date.now()): string {
  const today = dayStart(now);
  const photoDay = dayStart(timestamp);
  const dayDifference = Math.round((today - photoDay) / 86_400_000);
  if (dayDifference === 0) return 'Today';
  if (dayDifference === 1) return 'Yesterday';
  const todayDate = new Date(today);
  const weekStart = today - todayDate.getDay() * 86_400_000;
  if (photoDay >= weekStart && photoDay < today) return 'This Week';
  return new Intl.DateTimeFormat(undefined, {
    month: 'long',
    year: 'numeric',
  }).format(new Date(timestamp));
}

export function galleryPhotoDate(timestamp: number): string {
  const date = new Date(timestamp);
  const group = galleryDateLabel(timestamp);
  const time = new Intl.DateTimeFormat(undefined, {
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
  if (group === 'Today' || group === 'Yesterday') return `${group}, ${time}`;
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

function rowsOfThree(photos: readonly GalleryPhoto[]): GalleryRow[] {
  const rows: GalleryRow[] = [];
  for (let index = 0; index < photos.length; index += 3) {
    const row = photos.slice(index, index + 3);
    rows.push({ id: `${row[0]?.id ?? index}`, photos: row });
  }
  return rows;
}

export function usePaginatedGalleryPhotos(
  allPhotos: readonly GalleryPhoto[] | undefined,
  pageSize: number = LIMITS.galleryPageSize,
) {
  const [page, setPage] = useState(1);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const loadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (loadTimer.current !== null) {
      clearTimeout(loadTimer.current);
      loadTimer.current = null;
    }
    setPage(1);
    setIsLoadingMore(false);
    return () => {
      if (loadTimer.current !== null) {
        clearTimeout(loadTimer.current);
        loadTimer.current = null;
      }
    };
  }, [allPhotos?.length]);

  const total = allPhotos?.length ?? 0;
  const currentCount = Math.min(total, page * pageSize);
  const hasMore = currentCount < total;

  const paginatedPhotos = useMemo(
    () => (allPhotos ?? []).slice(0, currentCount),
    [allPhotos, currentCount],
  );

  const loadMore = useCallback(() => {
    if (!hasMore || isLoadingMore) return;
    setIsLoadingMore(true);
    loadTimer.current = setTimeout(() => {
      setPage((prev) => prev + 1);
      setIsLoadingMore(false);
      loadTimer.current = null;
    }, 120);
  }, [hasMore, isLoadingMore]);

  return {
    photos: paginatedPhotos,
    total,
    hasMore,
    isLoadingMore,
    loadMore,
  };
}

export function useGroupedPhotos(
  photos: readonly GalleryPhoto[] | undefined,
): readonly GallerySection[] {
  return useMemo(() => {
    const grouped = new Map<string, GalleryPhoto[]>();
    for (const photo of photos ?? []) {
      const label = galleryDateLabel(photo.timestamp);
      const current = grouped.get(label) ?? [];
      current.push(photo);
      grouped.set(label, current);
    }
    return Array.from(grouped, ([title, values]) => ({
      title,
      data: rowsOfThree(values),
    }));
  }, [photos]);
}

export function usePoseHistory(
  photos: readonly GalleryPhoto[] | undefined,
): readonly Pose[] {
  const recentEntries = useRecentPosesStore((state) => state.entries);
  return useMemo(() => {
    const photoPoseIds = (photos ?? [])
      .map((photo) => photo.poseId)
      .filter((id): id is string => id !== null);

    const orderedIds = [
      ...recentEntries.map((e) => e.poseId),
      ...photoPoseIds,
    ];

    const seen = new Set<string>();
    const poses: Pose[] = [];
    for (const id of orderedIds) {
      if (seen.has(id)) continue;
      seen.add(id);
      const pose = getPoseById(id);
      if (pose !== null) poses.push(pose);
      if (poses.length >= LIMITS.poseHistory) break;
    }
    return poses;
  }, [photos, recentEntries]);
}

/**
 * POST-CAPTURE EDITING — applies crop / rotate / enhance to a SAVED photo.
 *
 * The whole operation is one mutation so the screen cannot end up in a state
 * where the pixels were written but the metadata was not: the rendering is
 * produced first, the swap is atomic-ish (write new, repoint metadata, delete
 * old), and a failed swap discards the temporary file instead of leaving it
 * in the cache.
 *
 * The system-gallery copy is deliberately NOT touched here — MediaLibrary
 * offers no way to rewrite an existing asset, so that decision (save an
 * edited copy, or not) belongs to the screen, where it can be explained to
 * the user.
 */
export function useEditPhoto() {
  const userId = useAuthStore((state) => state.session?.id ?? null);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: { readonly photo: GalleryPhoto; readonly edit: PhotoEdit }) => {
      if (userId === null) throw new Error('Sign in to edit Gallery photos.');
      const rendered = await renderPhotoEdit(
        { uri: input.photo.imagePath, width: 0, height: 0 },
        input.edit,
      );
      if (!rendered.applied) {
        throw new Error('This photo could not be re-rendered on this device.');
      }
      try {
        return await replaceStoredPhotoFile(userId, input.photo.id, rendered.uri);
      } catch (error) {
        await discardEditTempFile(rendered.uri);
        throw error;
      }
    },
    onSuccess: (_path, input) => {
      void queryClient.invalidateQueries({
        queryKey: galleryPhotoQueryKey(userId, input.photo.id),
      });
      void queryClient.invalidateQueries({ queryKey: galleryPhotosQueryKey(userId) });
    },
  });
}

export function useDeletePhoto() {
  const userId = useAuthStore((state) => state.session?.id ?? null);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => {
      if (userId === null) throw new Error('Sign in to delete Gallery photos.');
      return galleryLocalDatasource.deletePhoto(userId, id);
    },
    onSuccess: (_data, id) => {
      queryClient.removeQueries({ queryKey: galleryPhotoQueryKey(userId, id) });
      void queryClient.invalidateQueries({ queryKey: galleryPhotosQueryKey(userId) });
    },
  });
}
