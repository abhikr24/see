/** Unit 14 saved-photo preview: share, delete, date/pose context, retake. */
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import {
  describePhotoEdit,
  getPoseById,
  mediaColors,
  radius,
  sizing,
  spacing,
  type PhotoEdit,
} from '@shared/index';
import { sweepEditTempFiles } from '@/core/camera/photoEditor';
import { checkPhotos } from '@/core/permissions/permissionService';
import { AppLogger } from '@/core/utils/logger';
import { showSuccessSnackBar } from '@/shared/stores/snackBarStore';
import { PhotoEditorScreen } from '@/features/camera/presentation/screens/PhotoEditorScreen';
import { AppButton } from '@/shared/components/AppButton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import {
  galleryPhotoDate,
  useDeletePhoto,
  useEditPhoto,
  useGalleryPhoto,
} from '../hooks/useGallery';

const FILTER_LABEL = {
  original: 'Original',
  vivid: 'Vivid',
  warm: 'Warm',
  cool: 'Cool',
  bw: 'B&W',
} as const;

export function GalleryPhotoPreviewScreen({ photoId }: { readonly photoId: string | null }) {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const photoQuery = useGalleryPhoto(photoId);
  const deletePhoto = useDeletePhoto();
  const editPhoto = useEditPhoto();
  const photo = photoQuery.data ?? null;
  const pose = photo?.poseId ? getPoseById(photo.poseId) : null;
  const [isEditorOpen, setEditorOpen] = useState(false);

  /* Clear any edit rendering abandoned by a previous session before adding
     another one to the cache. */
  useEffect(() => {
    void sweepEditTempFiles();
  }, []);

  const applyEdit = useCallback(
    (edit: PhotoEdit) => {
      if (photo === null) return;
      void (async () => {
        try {
          const destination = await editPhoto.mutateAsync({ photo, edit });
          setEditorOpen(false);
          /* HONESTY ABOUT THE SYSTEM GALLERY: MediaLibrary can add an asset
             but cannot rewrite the one the user already saved, so the edited
             photograph is added as a NEW picture and the message says exactly
             that. Silently leaving the device gallery showing the unedited
             version would be the lie; silently replacing something the user
             owns would be worse. */
          let sharedCopy = false;
          if ((await checkPhotos()) === 'granted') {
            try {
              await MediaLibrary.saveToLibraryAsync(destination);
              sharedCopy = true;
            } catch (error) {
              AppLogger.warn(`[Gallery] edited copy not added to device gallery — ${String(error)}`);
            }
          }
          showSuccessSnackBar(
            sharedCopy ? 'Edited copy added to your gallery' : 'Photo updated in PoseAssist',
          );
          AppLogger.info(`[Gallery] edit applied — ${describePhotoEdit(edit)}`);
        } catch (error) {
          AppLogger.error(`[Gallery] edit failed — ${String(error)}`);
          Alert.alert(
            'Could not apply edits',
            'The edited photo could not be written. Your saved photo has not been changed.',
          );
        }
      })();
    },
    [editPhoto, photo],
  );

  const close = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)/gallery');
  }, [router]);

  const share = useCallback(async () => {
    if (photo === null) return;
    try {
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert('Sharing unavailable', 'This device cannot open a file sharing sheet.');
        return;
      }
      await Sharing.shareAsync(photo.imagePath, {
        dialogTitle: 'Share your photo',
        mimeType: 'image/jpeg',
        UTI: 'public.jpeg',
      });
    } catch (error) {
      AppLogger.error(`[Gallery] share failed — ${String(error)}`);
      Alert.alert('Could not share', 'The sharing sheet could not be opened.');
    }
  }, [photo]);

  const confirmDelete = useCallback(() => {
    if (photo === null) return;
    Alert.alert(
      'Delete from PoseAssist?',
      'This removes the app-owned photo and its metadata. The copy in your system gallery remains yours.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            void deletePhoto.mutateAsync(photo.id).then(close).catch((error) => {
              AppLogger.error(`[Gallery] delete failed — ${String(error)}`);
              Alert.alert('Could not delete', 'The photo could not be removed. Try again.');
            });
          },
        },
      ],
    );
  }, [close, deletePhoto, photo]);

  if (photoId !== null && photoQuery.isPending) {
    return (
      <View style={styles.centerDark}>
        <ActivityIndicator color={mediaColors.text} />
      </View>
    );
  }

  if (photoQuery.isError) {
    return (
      <SafeAreaView style={styles.centerDark}>
        <IconSymbol name="alert-circle-outline" size={40} color={mediaColors.textMuted} />
        <AppText variant="heading" color={mediaColors.text} style={styles.notFoundTitle}>
          Could not open photo
        </AppText>
        <AppText variant="secondaryBody" color={mediaColors.textMuted} align="center">
          The local Gallery metadata could not be read. Your device photo has not been changed.
        </AppText>
        <AppButton
          title="Try Again"
          icon="refresh"
          onPress={() => void photoQuery.refetch()}
          variant="secondary"
          style={styles.backButton}
        />
      </SafeAreaView>
    );
  }

  if (photo === null) {
    return (
      <SafeAreaView style={styles.centerDark}>
        <IconSymbol name="image-off-outline" size={40} color={mediaColors.textMuted} />
        <AppText variant="heading" color={mediaColors.text} style={styles.notFoundTitle}>
          Photo not found
        </AppText>
        <AppText variant="secondaryBody" color={mediaColors.textMuted} align="center">
          The file may have been removed from this device.
        </AppText>
        <AppButton title="Back to Gallery" onPress={close} variant="secondary" style={styles.backButton} />
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.root}>
      <View style={styles.photoFallback} pointerEvents="none">
        <IconSymbol name="image-off-outline" size={40} color={mediaColors.textMuted} />
        <AppText variant="small" color={mediaColors.textMuted} style={styles.fallbackText}>
          Photo file cannot be displayed
        </AppText>
      </View>
      <Image
        source={{ uri: photo.imagePath }}
        style={StyleSheet.absoluteFill}
        contentFit="contain"
        accessibilityLabel={`Photo captured ${galleryPhotoDate(photo.timestamp)}`}
      />

      <SafeAreaView edges={['top']} style={styles.topSafe}>
        <View style={styles.topBar}>
          <IconAction icon="close" label="Close photo" onPress={close} />
          <View style={styles.topActions}>
            <IconAction
              icon="tune-variant"
              label="Edit photo: crop, rotate or enhance"
              onPress={() => setEditorOpen(true)}
            />
            <IconAction icon="share-variant" label="Share photo" onPress={() => void share()} />
            <IconAction icon="delete-outline" label="Delete photo" onPress={confirmDelete} />
          </View>
        </View>
      </SafeAreaView>

      <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, spacing.sm) }]}>
        <View style={styles.context}>
          <AppText variant="small" color={mediaColors.text} style={styles.date}>
            {galleryPhotoDate(photo.timestamp)}
          </AppText>
          <AppText variant="small" color={mediaColors.textMuted} numberOfLines={1}>
            {pose?.title ?? 'Pose reference unavailable'} · {FILTER_LABEL[photo.filterUsed]}
          </AppText>
        </View>
        <Pressable
          onPress={() =>
            router.replace({
              pathname: '/(tabs)/camera',
              params: photo.poseId ? { poseId: photo.poseId } : {},
            })
          }
          accessibilityRole="button"
          accessibilityLabel={pose ? `Retake using ${pose.title}` : 'Retake photo'}
          style={({ pressed }) => [styles.retake, { opacity: pressed ? 0.75 : 1 }]}
        >
          <IconSymbol name="replay" size={24} color={mediaColors.text} />
          <AppText variant="secondaryBody" color={mediaColors.text}>Retake</AppText>
        </Pressable>
      </View>

      {isEditorOpen && (
        <PhotoEditorScreen
          uri={photo.imagePath}
          busy={editPhoto.isPending}
          onApply={applyEdit}
          onCancel={() => {
            if (!editPhoto.isPending) setEditorOpen(false);
          }}
        />
      )}

      {photo.editedAt !== undefined && !isEditorOpen && (
        <View style={styles.editedChip} pointerEvents="none">
          <IconSymbol name="tune-variant" size={12} color={mediaColors.text} />
          <AppText variant="small" color={mediaColors.text}>
            Edited
          </AppText>
        </View>
      )}

      {deletePhoto.isPending && (
        <View style={styles.deleting} accessibilityViewIsModal>
          <ActivityIndicator color={mediaColors.text} />
          <AppText variant="small" color={mediaColors.text} style={styles.deletingText}>Deleting...</AppText>
        </View>
      )}
    </View>
  );
}

function IconAction({ icon, label, onPress }: { readonly icon: string; readonly label: string; readonly onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [styles.iconAction, { opacity: pressed ? 0.7 : 1 }]}
    >
      <IconSymbol name={icon} size={28} color={mediaColors.text} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: mediaColors.viewfinder },
  centerDark: {
    flex: 1,
    backgroundColor: mediaColors.viewfinder,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  notFoundTitle: { marginTop: spacing.lg, marginBottom: spacing.sm },
  photoFallback: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    alignItems: 'center',
    justifyContent: 'center',
  },
  fallbackText: { marginTop: spacing.sm },
  backButton: { marginTop: spacing.xl, minWidth: 220 },
  topSafe: { position: 'absolute', top: 0, left: 0, right: 0 },
  topBar: {
    minHeight: sizing.touchTarget,
    paddingHorizontal: spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: mediaColors.overlayMedium,
  },
  topActions: { flexDirection: 'row' },
  iconAction: {
    width: sizing.touchTarget,
    height: sizing.touchTarget,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomBar: {
    position: 'absolute', left: 0, right: 0, bottom: 0,
    minHeight: 112,
    backgroundColor: mediaColors.overlayHeavy,
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
  context: { flex: 1 },
  date: { fontWeight: '600', marginBottom: spacing.xs },
  retake: {
    minWidth: 88, minHeight: sizing.touchTarget,
    borderRadius: radius.md, alignItems: 'center', justifyContent: 'center', gap: spacing.xs,
  },
  editedChip: {
    position: 'absolute',
    left: spacing.lg,
    bottom: 112 + spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.pill,
    backgroundColor: mediaColors.overlayHeavy,
  },
  deleting: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    backgroundColor: mediaColors.overlayHeavy,
    alignItems: 'center', justifyContent: 'center', zIndex: 20,
  },
  deletingText: { marginTop: spacing.sm },
});
