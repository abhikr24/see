/** Unit 14 complete Gallery tab: history, grouped local grid, states. */
import React, { useEffect } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { ScreenHeader } from '@/shared/components/ScreenHeader';
import { ErrorRetryWidget } from '@/shared/components/ErrorRetryWidget';
import { ShimmerGalleryGrid } from '@/shared/components/ShimmerSkeleton';
import { errorHandler } from '@/core/error/errorHandler';
import { EmptyGallery } from '../components/EmptyGallery';
import { GalleryGrid } from '../components/GalleryGrid';
import { PoseHistoryList } from '../components/PoseHistoryList';
import {
  useGalleryPhotos,
  useGroupedPhotos,
  usePaginatedGalleryPhotos,
  usePoseHistory,
} from '../hooks/useGallery';

export function GalleryTab() {
  const theme = useAppTheme();
  const photosQuery = useGalleryPhotos();
  const paginated = usePaginatedGalleryPhotos(photosQuery.data, 30);
  const sections = useGroupedPhotos(paginated.photos);
  const poseHistory = usePoseHistory(photosQuery.data);
  const count = photosQuery.data?.length ?? 0;

  useEffect(() => {
    if (photosQuery.isError) {
      errorHandler.handle(photosQuery.error, 'Gallery/Load');
    }
  }, [photosQuery.error, photosQuery.isError]);

  return (
    <SafeAreaView edges={['top']} style={[styles.root, { backgroundColor: theme.colors.backgroundSecondary }]}>
      <ScreenHeader title="Gallery" subtitle={`${count} photo${count === 1 ? '' : 's'} · on this device`} />
      {/* Unit 23: shimmer skeleton while the local gallery loads — no blank state */}
      {photosQuery.isPending ? (
        <ScrollView contentContainerStyle={styles.shimmerWrap} scrollEnabled={false}>
          <ShimmerGalleryGrid count={9} />
        </ScrollView>
      ) : photosQuery.isError ? (
        <ErrorRetryWidget
          title="Could not load Gallery"
          message="Your photos remain on this device. Retry loading the local metadata."
          onRetry={() => void photosQuery.refetch()}
        />
      ) : count === 0 ? (
        <EmptyGallery />
      ) : (
        <GalleryGrid
          sections={sections}
          refreshing={photosQuery.isRefetching}
          onRefresh={() => void photosQuery.refetch()}
          onEndReached={paginated.loadMore}
          isLoadingMore={paginated.isLoadingMore}
          header={<PoseHistoryList poses={poseHistory} />}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  shimmerWrap: {
    paddingBottom: spacing.xl,
    alignItems: 'center',
  },
});
