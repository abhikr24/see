/**
 * Unit 07 — HeroCard (Home dashboard).
 * Primary CTA: "Start Camera" (auth-gated by controller, not this card).
 * Below: "Continue last pose" link when the recents LRU has an entry.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import Animated from 'react-native-reanimated';
import {
  brandGradientFor,
  elevationStyle,
  mediaColors,
  radius,
  spacing,
  type Pose,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { usePressMotion } from '@/shared/hooks/usePressMotion';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface HeroCardProps {
  readonly pose: Pose | null;
  readonly lastPose: Pose | null;
  readonly isAuthenticated: boolean;
  readonly onContinuePose: (pose: Pose) => void;
}

export function HeroCard({ pose, lastPose, isAuthenticated, onContinuePose }: HeroCardProps) {
  const theme = useAppTheme();
  const router = useRouter();
  const ctaMotion = usePressMotion();
  const continueMotion = usePressMotion();
  const [ctaPressed, setCtaPressed] = React.useState(false);

  const startCamera = () => {
    if (!isAuthenticated) {
      router.push('/auth');
      return;
    }
    router.push('/(tabs)/camera');
  };

  return (
    <LinearGradient
      colors={brandGradientFor(theme.scheme)}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[styles.card, elevationStyle('floating', theme.colors)]}
    >
      {/* Premium-pass items 7 & 8: brand-gradient hero at `floating` depth. */}
      <View style={styles.ringLarge} />
      <View style={styles.ringSmall} />
      <View style={styles.row}>
        <View style={styles.texts}>
          <AppText variant="small" color={mediaColors.textMuted} style={styles.kicker}>
            START CAPTURING PERFECT POSES
          </AppText>
          <AppText variant="heading" color={mediaColors.text} style={styles.title}>
            AI guidance for every shot
          </AppText>
          {lastPose !== null && (
            <Pressable
              onPress={() => onContinuePose(lastPose)}
              onPressIn={continueMotion.onPressIn}
              onPressOut={continueMotion.onPressOut}
              accessibilityRole="button"
              accessibilityLabel={`Continue with pose ${lastPose.title}`}
            >
              <Animated.View style={[styles.continuePill, continueMotion.animatedStyle]}>
                <IconSymbol name="history" size={12} color={mediaColors.text} />
                <AppText variant="small" color={mediaColors.text} style={styles.continueText}>
                  Continue · {lastPose.title}
                </AppText>
              </Animated.View>
            </Pressable>
          )}
        </View>
        <View style={styles.iconWrap}>
          <IconSymbol name="camera" size={26} color={mediaColors.text} />
        </View>
      </View>
      <Pressable
        onPress={startCamera}
        onPressIn={() => {
          setCtaPressed(true);
          ctaMotion.onPressIn();
        }}
        onPressOut={() => {
          setCtaPressed(false);
          ctaMotion.onPressOut();
        }}
        accessibilityRole="button"
        accessibilityLabel="Start Camera"
        style={[
          styles.cta,
          {
            backgroundColor: ctaPressed ? mediaColors.whiteMuted : mediaColors.whiteSoft,
          },
        ]}
      >
        <Animated.View style={[styles.ctaInner, ctaMotion.animatedStyle]}>
          <AppText variant="button" color={mediaColors.text} style={styles.ctaText}>
            Start Camera
          </AppText>
          <IconSymbol name="arrow-right" size={16} color={mediaColors.text} />
        </Animated.View>
      </Pressable>
      {pose !== null && (
        <AppText variant="small" color={mediaColors.textSubtle} style={styles.poseHint}>
          Featured reference · {pose.title}
        </AppText>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: spacing.lg,
    marginTop: spacing.md,
    borderRadius: radius.lg,
    padding: spacing.lg,
    overflow: 'hidden',
  },
  ringLarge: {
    position: 'absolute',
    top: -36,
    right: -24,
    width: 140,
    height: 140,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.whiteSubtle,
  },
  ringSmall: {
    position: 'absolute',
    bottom: -20,
    left: -30,
    width: 100,
    height: 100,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.overlaySubtle,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  texts: {
    flex: 1,
    paddingRight: spacing.sm,
  },
  kicker: {
    fontWeight: '600',
    letterSpacing: 0.8,
  },
  title: {
    marginTop: spacing.xs,
    fontSize: 20,
    lineHeight: 26,
  },
  continuePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: spacing.md,
    alignSelf: 'flex-start',
    backgroundColor: mediaColors.overlaySoft,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
  continueText: {
    fontWeight: '600',
  },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    backgroundColor: mediaColors.whiteSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cta: {
    marginTop: spacing.lg,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
  },
  ctaInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  ctaText: {
    fontSize: 14,
  },
  poseHint: {
    marginTop: spacing.md,
  },
});
