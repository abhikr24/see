/**
 * Unit 07 — QuickNavTiles.
 * Two tiles: Explore (pose count) and Gallery (your shots).
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface QuickNavTilesProps {
  readonly poseCount: number;
}

export function QuickNavTiles({ poseCount }: QuickNavTilesProps) {
  const theme = useAppTheme();
  const router = useRouter();

  const tiles: {
    key: string;
    icon: string;
    title: string;
    caption: string;
    route: '/(tabs)/explore' | '/(tabs)/gallery';
  }[] = [
    {
      key: 'explore',
      icon: 'compass-outline',
      title: 'Explore',
      caption: `${poseCount} poses · ready`,
      route: '/(tabs)/explore',
    },
    {
      key: 'gallery',
      icon: 'image-multiple-outline',
      title: 'Gallery',
      caption: 'Your shots · Unit 14',
      route: '/(tabs)/gallery',
    },
  ];

  return (
    <View style={styles.row}>
      {tiles.map((tile) => (
        <Pressable
          key={tile.key}
          onPress={() => router.push(tile.route)}
          accessibilityRole="button"
          accessibilityLabel={`${tile.title} — ${tile.caption}`}
          style={({ pressed }) => [
            styles.tile,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
              opacity: pressed ? 0.85 : 1,
            },
          ]}
        >
          <View style={[styles.iconWrap, { backgroundColor: theme.colors.primaryLight }]}>
            <IconSymbol name={tile.icon} size={18} color={theme.colors.primary} />
          </View>
          <View style={styles.texts}>
            <AppText variant="small" color={theme.colors.textPrimary} style={styles.title}>
              {tile.title}
            </AppText>
            <AppText variant="small" color={theme.colors.textSecondary} style={styles.caption}>
              {tile.caption}
            </AppText>
          </View>
          <IconSymbol name="chevron-right" size={16} color={theme.colors.textDisabled} />
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.xl,
  },
  tile: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  texts: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    fontWeight: '600',
  },
  caption: {
    fontSize: 9,
    marginTop: 1,
  },
});
