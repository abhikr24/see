/**
 * Unit 15 — RecentPosesShelf (Home dashboard).
 * Horizontal shelf of the 4 most recent poses from the unified recents store.
 * Tapping a recent pose triggers quick reuse (updates lastUsed timestamp and arms Camera State 2).
 */
import React from 'react';
import { FlatList, Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { LIMITS, radius, spacing, type Pose } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useRecentPoses, useAddToRecent } from '@/features/poses/presentation/hooks/usePoses';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';
import { useStoreHydrated } from '@/shared/hooks/useStoreHydrated';
import { ShimmerHorizontal } from '@/shared/components/ShimmerSkeleton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';

function RecentThumb({
  pose,
  onPress,
}: {
  readonly pose: Pose;
  readonly onPress: (pose: Pose) => void;
}) {
  const theme = useAppTheme();
  return (
    <Pressable
      onPress={() => onPress(pose)}
      accessibilityRole="button"
      accessibilityLabel={`Use pose ${pose.title}`}
      style={({ pressed }) => [styles.thumb, { opacity: pressed ? 0.85 : 1 }]}
    >
      <PoseCardArt pose={pose} height={104} borderRadius={radius.md} iconSize={28} showBadges={false} />
      <AppText variant="small" color={theme.colors.textPrimary} numberOfLines={1} style={styles.thumbTitle}>
        {pose.title}
      </AppText>
    </Pressable>
  );
}

interface RecentPosesShelfProps {
  readonly totalPoses: number;
}

export function RecentPosesShelf({ totalPoses }: RecentPosesShelfProps) {
  const theme = useAppTheme();
  const router = useRouter();
  const hydrated = useStoreHydrated(useRecentPosesStore);
  const recents = useRecentPoses(LIMITS.recentPoses);
  const addToRecent = useAddToRecent();

  const handleSelect = (pose: Pose) => {
    addToRecent(pose.id);
    router.push({ pathname: '/(tabs)/camera', params: { poseId: pose.id } });
  };

  return (
    <View style={styles.section}>
      <View style={styles.headerRow}>
        <AppText variant="cardTitle" color={theme.colors.textPrimary} style={styles.heading}>
          Recent poses
        </AppText>
        {recents.length > 0 && (
          <Pressable
            onPress={() => router.push('/(tabs)/explore')}
            accessibilityRole="button"
            accessibilityLabel="See all poses"
            hitSlop={8}
          >
            <AppText variant="small" color={theme.colors.primary} style={styles.seeAll}>
              See All
            </AppText>
          </Pressable>
        )}
      </View>

      {!hydrated ? (
        <ShimmerHorizontal count={4} />
      ) : recents.length > 0 ? (
        <FlatList
          horizontal
          data={recents}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <RecentThumb pose={item} onPress={handleSelect} />}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.list}
        />
      ) : (
        <View
          style={[
            styles.empty,
            { backgroundColor: theme.colors.backgroundSecondary, borderColor: theme.colors.divider },
          ]}
        >
          <AppText variant="secondaryBody" color={theme.colors.textPrimary} style={styles.emptyTitle}>
            Discover {totalPoses}+ poses
          </AppText>
          <AppText variant="small" color={theme.colors.textSecondary} style={styles.emptyDesc}>
            Browse curated collections — poses you use or view are pinned here (up to {LIMITS.recentPoses}).
          </AppText>
          <Pressable
            onPress={() => router.push('/(tabs)/explore')}
            accessibilityRole="button"
            accessibilityLabel="Explore poses"
            style={({ pressed }) => [styles.emptyLink, { opacity: pressed ? 0.7 : 1 }]}
          >
            <AppText variant="small" color={theme.colors.primary} style={styles.emptyLinkText}>
              Explore Poses
            </AppText>
            <IconSymbol name="arrow-right" size={12} color={theme.colors.primary} />
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginTop: spacing.xl,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
  },
  heading: {
    fontSize: 15,
  },
  seeAll: {
    fontWeight: '600',
  },
  list: {
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm + 2,
  },
  thumb: {
    width: 96,
  },
  thumbTitle: {
    marginTop: spacing.xs,
    fontWeight: '600',
  },
  empty: {
    marginHorizontal: spacing.lg,
    marginTop: spacing.sm + 2,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderRadius: radius.md,
    padding: spacing.lg,
  },
  emptyTitle: {
    fontWeight: '600',
  },
  emptyDesc: {
    marginTop: spacing.xs,
  },
  emptyLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: spacing.md,
  },
  emptyLinkText: {
    fontWeight: '600',
  },
});
