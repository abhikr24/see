/**
 * Unit 07 — HomeScreen (Home dashboard).
 * Greeting header (auth-aware) + hero card + recents shelf (LRU 4) +
 * quick navigation. Pure RN. Recents live in the same store Explore
 * writes to (features/poses/data/recentPosesStore).
 */
import React, { useEffect, useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  getCatalogReport,
  getPoseCatalog,
  getPoseById,
  radius,
  spacing,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { useAuthStore } from '@/shared/stores/authStore';
import { useRecentPoses, useAddToRecent } from '@/features/poses/presentation/hooks/usePoses';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { HeroCard } from '../components/HeroCard';
import { RecentPosesShelf } from '../components/RecentPosesShelf';
import { QuickNavTiles } from '../components/QuickNavTiles';

function greetingForHour(hour: number): string {
  if (hour >= 5 && hour < 12) return 'Good morning';
  if (hour >= 12 && hour < 18) return 'Good afternoon';
  if (hour >= 18 && hour < 22) return 'Good evening';
  return 'Good night';
}

export function HomeScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const session = useAuthStore((s) => s.session);
  const recents = useRecentPoses(1);
  const addToRecent = useAddToRecent();

  const report = useMemo(() => getCatalogReport(), []);
  const heroPose = useMemo(() => {
    const catalog = getPoseCatalog();
    return catalog.find((p) => p.isFeatured) ?? catalog[0] ?? null;
  }, []);
  const lastPose = recents[0] ?? null;
  const firstName = (session?.displayName ?? 'Guest').split(/\s+/)[0] ?? 'Guest';

  useEffect(() => {
    AppLogger.info('[Home] dashboard mounted');
  }, []);

  return (
    <SafeAreaView edges={['top']} style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Top bar */}
        <View style={styles.topBar}>
          <View>
            <AppText variant="cardTitle" color={theme.colors.textPrimary}>
              {greetingForHour(new Date().getHours())}, {firstName}
            </AppText>
            <AppText variant="small" color={theme.colors.textSecondary} style={styles.topSub}>
              Ready for perfect shots?
            </AppText>
          </View>
          <View style={styles.topActions}>
            <Pressable
              onPress={() =>
                AppLogger.info('[Notifications] bell tapped — V1 never requests notification permission')
              }
              accessibilityRole="button"
              accessibilityLabel="Notifications"
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: theme.colors.backgroundSecondary, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <IconSymbol name="bell-outline" size={17} color={theme.colors.textSecondary} />
            </Pressable>
            <Pressable
              onPress={() => router.push('/(tabs)/profile')}
              accessibilityRole="button"
              accessibilityLabel="Open profile"
              style={({ pressed }) => [
                styles.iconButton,
                { backgroundColor: theme.colors.primaryLight, opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <IconSymbol name="account" size={17} color={theme.colors.primary} />
            </Pressable>
          </View>
        </View>

        <HeroCard
          pose={heroPose}
          lastPose={lastPose}
          isAuthenticated={session !== null}
          onContinuePose={(pose) => {
            AppLogger.info(`[Home] continue last pose → camera State 2 (poseId=${pose.id})`);
            addToRecent(pose.id);
            router.push({ pathname: '/(tabs)/camera', params: { poseId: pose.id } });
          }}
        />

        <RecentPosesShelf totalPoses={report.total} />
        <QuickNavTiles poseCount={report.total} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  scroll: {
    paddingBottom: spacing.xl,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  topSub: {
    marginTop: 2,
  },
  topActions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
