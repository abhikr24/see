/**
 * Boot-state persistence used ONLY by the very first navigation decision.
 *
 * Why this is separate from MMKV:
 * - MMKV remains the app's normal fast synchronous preference store.
 * - The cold-start router must never synchronously call a native JSI store.
 * - expo-file-system is already a project dependency and gives us a small
 *   Promise-based read/write path that can be raced with a short timeout.
 *
 * If the boot file is missing, slow, malformed, or unavailable, the app
 * safely falls back to the welcome flow instead of hanging on a splash.
 */
export interface BootState {
  readonly onboardingSeen: boolean;
  readonly permissionsGranted: boolean;
}

const BOOT_FILE_NAME = 'poseassist-boot-state.json';
const DEFAULT_BOOT_STATE: BootState = {
  onboardingSeen: false,
  permissionsGranted: false,
};

function isValidBootState(value: unknown): value is BootState {
  if (typeof value !== 'object' || value === null) return false;
  const record = value as Record<string, unknown>;
  return (
    typeof record.onboardingSeen === 'boolean' &&
    typeof record.permissionsGranted === 'boolean'
  );
}

export async function readBootState(): Promise<BootState> {
  try {
    const FileSystem = await import('expo-file-system/legacy');
    const bootFile = `${FileSystem.documentDirectory ?? ''}${BOOT_FILE_NAME}`;
    if (bootFile.length === 0) return DEFAULT_BOOT_STATE;
    const raw = await FileSystem.readAsStringAsync(bootFile);
    const parsed: unknown = JSON.parse(raw);
    if (!isValidBootState(parsed)) return DEFAULT_BOOT_STATE;
    return parsed;
  } catch (error) {
    return DEFAULT_BOOT_STATE;
  }
}

export async function writeBootState(next: BootState): Promise<void> {
  try {
    const FileSystem = await import('expo-file-system/legacy');
    const bootFile = `${FileSystem.documentDirectory ?? ''}${BOOT_FILE_NAME}`;
    if (bootFile.length === 0) return;
    await FileSystem.writeAsStringAsync(bootFile, JSON.stringify(next));
  } catch (error) {
    // Boot-state persistence is convenience state, never a reason to block
    // onboarding, permissions, or the main app.
  }
}

export function bootStateTimeout<T>(promise: Promise<T>, fallback: T, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);
}
