/**
 * Unit 03 — onboardingRepository.
 *
 * Normal app preferences still use the existing MMKV adapter. Cold-start
 * navigation additionally mirrors the two route-critical flags into the
 * async boot-state file so the first screen is never blocked by a native
 * synchronous storage read.
 */
import { STORAGE_KEYS } from '@shared/constants/app';
import { writeBootState, type BootState } from './bootState';

export interface OnboardingFlags {
  readonly isFirstLaunch: boolean;
  readonly hasSeenOnboarding: boolean;
  readonly hasGrantedPermissions: boolean;
}

export async function readOnboardingFlags(): Promise<OnboardingFlags> {
  const { storage } = await import('@/core/storage/storage');
  return {
    isFirstLaunch: storage.getString(STORAGE_KEYS.isFirstLaunch) !== 'false',
    hasSeenOnboarding: storage.getString(STORAGE_KEYS.hasSeenOnboarding) === 'true',
    hasGrantedPermissions:
      storage.getString(STORAGE_KEYS.hasGrantedPermissions) === 'true',
  };
}

function mirrorBootStateFromMmkv(): void {
  try {
    void readOnboardingFlags().then((flags) => writeBootState({
      onboardingSeen: flags.hasSeenOnboarding,
      permissionsGranted: flags.hasGrantedPermissions,
    }));
  } catch {
    // The async boot file will remain the safe source for first navigation.
  }
}

export function markFirstLaunchComplete(): void {
  // Compatibility mirror only. Do not block navigation on synchronous MMKV.
  setTimeout(() => {
    void import('@/core/storage/storage')
      .then(({ storage }) => storage.set(STORAGE_KEYS.isFirstLaunch, 'false'))
      .catch(() => undefined);
  }, 0);
}

export function markOnboardingSeen(): void {
  // The async boot file is the cold-start source of truth.
  void writeBootState({ onboardingSeen: true, permissionsGranted: false });
  setTimeout(() => {
    void import('@/core/storage/storage')
      .then(({ storage }) => storage.set(STORAGE_KEYS.hasSeenOnboarding, 'true'))
      .catch(() => undefined);
  }, 0);
}

export function markPermissionsCompleted(): void {
  // The async boot file is the cold-start source of truth.
  void writeBootState({ onboardingSeen: true, permissionsGranted: true });
  setTimeout(() => {
    void import('@/core/storage/storage')
      .then(({ storage }) => storage.set(STORAGE_KEYS.hasGrantedPermissions, 'true'))
      .catch(() => undefined);
  }, 0);
}

// Keep the function intentionally small and side-effect-free for existing
// callers. The boot gate reads the async file directly; this helper is a
// compatibility bridge for old persisted MMKV flags.
export function mirrorLegacyBootState(): void {
  mirrorBootStateFromMmkv();
}
