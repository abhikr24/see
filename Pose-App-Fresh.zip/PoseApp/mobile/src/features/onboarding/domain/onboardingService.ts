/**
 * Unit 03 — onboardingService.
 * Pure routing decisions derived from the persisted flags. Screens never
 * read flags directly — they ask this service.
 */
import { AppLogger } from '@/core/utils/logger';
import {
  markFirstLaunchComplete,
  markOnboardingSeen,
  markPermissionsCompleted,
} from '../data/onboardingRepository';

export type StartupDestination = '/welcome' | '/(tabs)';

/** Splash decides where the very first navigation goes. */
export async function decideStartupRoute(): Promise<StartupDestination> {
  const { readOnboardingFlags } = await import('../data/onboardingRepository');
  const flags = await readOnboardingFlags();
  const destination: StartupDestination = flags.hasSeenOnboarding ? '/(tabs)' : '/welcome';
  AppLogger.info(
    `[Startup] flags seen=${flags.hasSeenOnboarding} perms=${flags.hasGrantedPermissions} → ${destination}`,
  );
  return destination;
}

/** Onboarding finished (last slide → Continue, or Skip). */
export function completeOnboarding(): void {
  markOnboardingSeen();
  markFirstLaunchComplete();
  AppLogger.info('[Onboarding] completed — flags persisted');
}

/** Permissions flow finished (camera granted or explicitly skipped). */
export function completePermissions(): void {
  markPermissionsCompleted();
  AppLogger.info('[Permissions] flow completed — flag persisted');
}
