/**
 * Cold-start routing service.
 * The first navigation is entirely async and bounded: it never reads MMKV
 * synchronously, never loads the pose catalog, and never waits on network.
 */
import { bootStateTimeout, readBootState } from '../data/bootState';

export interface StartupResult {
  readonly destination: '/welcome' | '/permissions' | '/(tabs)';
  readonly elapsedMs: number;
}

const BOOT_READ_TIMEOUT_MS = 900;

export async function runStartup(): Promise<StartupResult> {
  const startedAt = Date.now();
  const state = await bootStateTimeout(
    readBootState(),
    { onboardingSeen: false, permissionsGranted: false },
    BOOT_READ_TIMEOUT_MS,
  );

  const destination = !state.onboardingSeen
    ? '/welcome'
    : !state.permissionsGranted
      ? '/permissions'
      : '/(tabs)';

  const elapsedMs = Date.now() - startedAt;
  return { destination, elapsedMs };
}
