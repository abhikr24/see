/**
 * Unit 04 — PermissionCard.
 * Explains WHY a permission is needed, shows the live status badge and
 * offers Allow / Retry / Open Settings depending on the state machine:
 * undetermined → granted → denied → deniedForever.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { mediaColors } from '@shared/theme/colors';
import { radius, spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';
import type { PermissionStatus } from '@/core/permissions/permissionService';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface PermissionCardProps {
  readonly icon: string;
  readonly title: string;
  readonly description: string;
  readonly status: PermissionStatus;
  readonly requesting: boolean;
  readonly onAllow: () => void;
  readonly onOpenSettings: () => void;
}

export function PermissionCard({
  icon,
  title,
  description,
  status,
  requesting,
  onAllow,
  onOpenSettings,
}: PermissionCardProps) {
  const theme = useAppTheme();
  const granted = status === 'granted';
  const deniedForever = status === 'deniedForever';
  const denied = status === 'denied';

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: theme.colors.surface,
          borderColor: granted ? theme.colors.success : theme.colors.divider,
        },
      ]}
    >
      <View style={styles.row}>
        <View style={[styles.iconWrap, { backgroundColor: theme.colors.primaryLight }]}>
          <IconSymbol name={icon} size={22} color={theme.colors.primary} />
        </View>
        <View style={styles.texts}>
          <View style={styles.titleRow}>
            <AppText variant="cardTitle" color={theme.colors.textPrimary} style={styles.title}>
              {title}
            </AppText>
            {granted && (
              <View style={[styles.badge, { backgroundColor: theme.colors.success }]}>
                <IconSymbol name="check" size={10} color={mediaColors.text} />
                <AppText variant="small" color={mediaColors.text} style={styles.badgeText}>
                  Granted
                </AppText>
              </View>
            )}
            {denied && (
              <View style={[styles.badge, { backgroundColor: theme.colors.error }]}>
                <AppText variant="small" color={mediaColors.text} style={styles.badgeText}>
                  Denied
                </AppText>
              </View>
            )}
            {deniedForever && (
              <View style={[styles.badge, { backgroundColor: theme.colors.error }]}>
                <AppText variant="small" color={mediaColors.text} style={styles.badgeText}>
                  Blocked
                </AppText>
              </View>
            )}
          </View>
          <AppText variant="small" color={theme.colors.textSecondary} style={styles.desc}>
            {description}
          </AppText>
        </View>
      </View>

      {!granted && !deniedForever && (
        <AppButton
          title={denied ? 'Retry' : requesting ? 'Requesting…' : `Allow ${title.replace(' Access', '')}`}
          onPress={onAllow}
          loading={requesting}
          style={styles.button}
        />
      )}
      {deniedForever && (
        <View>
          <AppText variant="small" color={theme.colors.error} style={styles.foreverNote}>
            Permission was permanently denied. Enable it in system settings to continue.
          </AppText>
          <AppButton
            title="Open Settings"
            onPress={onOpenSettings}
            icon="cog-outline"
            style={styles.button}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },
  row: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  texts: {
    flex: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flexWrap: 'wrap',
  },
  title: {
    fontSize: 16,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '700',
  },
  desc: {
    marginTop: spacing.xs,
  },
  button: {
    marginTop: spacing.md,
    minHeight: 42,
  },
  foreverNote: {
    marginTop: spacing.sm,
  },
});
