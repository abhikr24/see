/**
 * Unit 03 — PhotographyIllustration.
 * Branded illustration placeholder: light-blue circle + camera badge +
 * floating sparkle dots. Built from primitives only (no asset pipeline
 * needed yet; real illustrations can replace this component in place).
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { mediaColors } from '@shared/theme/colors';
import { radius, spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface PhotographyIllustrationProps {
  readonly size?: number;
  readonly icon?: string;
  readonly iconSize?: number;
}

export function PhotographyIllustration({
  size = 128,
  icon = 'camera',
  iconSize = 52,
}: PhotographyIllustrationProps) {
  const theme = useAppTheme();
  return (
    <View style={[styles.wrap, { width: size, height: size }]}>
      <View
        style={[
          styles.halo,
          {
            width: size,
            height: size,
            borderRadius: radius.circle,
            backgroundColor: theme.colors.primaryLight,
          },
        ]}
      />
      <View
        style={[
          styles.core,
          {
            width: size * 0.62,
            height: size * 0.62,
            borderRadius: radius.lg,
            backgroundColor: theme.colors.primary,
          },
        ]}
      >
        <IconSymbol name={icon} size={iconSize} color={mediaColors.text} />
      </View>
      <View
        style={[
          styles.sparkle,
          styles.sparkleTop,
          { backgroundColor: theme.colors.success, borderColor: theme.colors.background },
        ]}
      />
      <View
        style={[
          styles.sparkle,
          styles.sparkleBottom,
          { backgroundColor: theme.colors.warning, borderColor: theme.colors.background },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  halo: {
    position: 'absolute',
  },
  core: {
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: mediaColors.shadow,
    shadowOpacity: 0.35,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 8,
  },
  sparkle: {
    position: 'absolute',
    width: 22,
    height: 22,
    borderRadius: radius.circle,
    borderWidth: 3,
  },
  sparkleTop: {
    top: spacing.sm,
    right: spacing.xs,
  },
  sparkleBottom: {
    bottom: spacing.md,
    left: 0,
    width: 14,
    height: 14,
  },
});
