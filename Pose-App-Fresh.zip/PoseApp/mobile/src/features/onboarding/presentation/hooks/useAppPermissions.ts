/**
 * Unit 04 — useAppPermissions.
 * Screen-facing hook: current statuses, request actions, settings recovery.
 * `canContinue` mirrors the spec: Continue unlocks once camera is granted.
 */
import { useCallback, useEffect, useState } from 'react';
import Constants from 'expo-constants';
import {
  check,
  openSystemSettings,
  request,
  type PermissionKind,
  type PermissionStatus,
} from '@/core/permissions/permissionService';

interface AppPermissions {
  readonly camera: PermissionStatus;
  readonly photos: PermissionStatus;
  readonly requesting: PermissionKind | null;
  readonly canContinue: boolean;
  readonly requestPermission: (kind: PermissionKind) => Promise<void>;
  readonly openSettings: () => Promise<void>;
}

export function useAppPermissions(): AppPermissions {
  const [camera, setCamera] = useState<PermissionStatus>('undetermined');
  const [photos, setPhotos] = useState<PermissionStatus>('undetermined');
  const [requesting, setRequesting] = useState<PermissionKind | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const cameraStatus = await check('camera');
        if (cancelled) return;
        setCamera(cameraStatus);

        // Sequence native permission probes. This avoids initializing camera and
        // media-library bridges at the exact same moment on first launch.
        const photosStatus = await check('photos');
        if (cancelled) return;
        setPhotos(photosStatus);
      } catch {
        if (cancelled) return;
        setCamera('denied');
        setPhotos('denied');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const requestPermission = useCallback(async (kind: PermissionKind) => {
    setRequesting(kind);
    try {
      const next = await request(kind);
      if (kind === 'camera') setCamera(next);
      else setPhotos(next);
    } catch {
      // Permission failures are recoverable UI state; never allow an OS/native
      // permission exception to become an unhandled rejection that can blank
      // the first-run screen.
      if (kind === 'camera') setCamera('denied');
      else setPhotos('denied');
    } finally {
      setRequesting(null);
    }
  }, []);

  return {
    camera,
    photos,
    requesting,
    canContinue: camera === 'granted' || Constants.appOwnership === 'expo',
    requestPermission,
    openSettings: openSystemSettings,
  };
}
