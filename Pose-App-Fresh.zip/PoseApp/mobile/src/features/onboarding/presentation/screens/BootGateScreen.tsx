import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Image, StyleSheet, Text, View } from 'react-native';
import { Redirect } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { runStartup, type StartupResult } from '../../domain/startupService';
import { lightColors } from '@shared/theme/colors';
import { warmAppFonts } from '@/core/bootstrap/fontWarmup';

/**
 * Dependency-light first React route.
 *
 * Critical rule: startup chooses a destination as state, then <Redirect />
 * performs the route change declaratively. The first mount performs no
 * imperative navigation because this screen is itself the initial route.
 */
export function BootGateScreen() {
  const [destination, setDestination] = useState<StartupResult['destination'] | null>(null);

  useEffect(() => {
    let active = true;

    // The native splash is no longer needed once this tiny first React screen
    // has rendered. Do not make app launch depend on fonts/auth/navigation.
    warmAppFonts();
    requestAnimationFrame(() => {
      SplashScreen.hideAsync().catch(() => undefined);
    });

    // Hard guarantee: even if the async boot-state file is slow/unavailable,
    // the user cannot remain on this screen indefinitely.
    const watchdog = setTimeout(() => {
      if (active) setDestination('/welcome');
    }, 1200);

    void runStartup()
      .then(({ destination: nextDestination }) => {
        if (!active) return;
        clearTimeout(watchdog);
        setDestination(nextDestination);
      })
      .catch(() => {
        if (!active) return;
        clearTimeout(watchdog);
        setDestination('/welcome');
      });

    return () => {
      active = false;
      clearTimeout(watchdog);
    };
  }, []);

  if (destination !== null) {
    return <Redirect href={destination} />;
  }

  return (
    <View style={styles.root}>
      <Image
        source={require('../../../../../assets/icon/app-icon-store.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <Text style={styles.name}>PoseAssist</Text>
      <Text style={styles.tagline}>Smart Photography Assistant</Text>
      <ActivityIndicator size="small" style={styles.spinner} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: lightColors.background,
  },
  logo: {
    width: 112,
    height: 112,
  },
  name: {
    marginTop: 20,
    fontSize: 30,
    lineHeight: 36,
    fontWeight: '700',
    color: lightColors.primary,
  },
  tagline: {
    marginTop: 6,
    fontSize: 14,
    color: lightColors.textSecondary,
  },
  spinner: {
    position: 'absolute',
    bottom: 48,
  },
});
