/**
 * Unit 03 — OnboardingScreen.
 * 3 slides (Discover · Live Guidance · Auto Capture) from shared/content,
 * horizontal paging with snap, animated dots, Skip (not last) and
 * Next/Continue. Finish persists flags via onboardingService and routes
 * to /permissions.
 */
import React, { useCallback, useRef, useState } from 'react';
import {
  FlatList,
  Pressable,
  StyleSheet,
  useWindowDimensions,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { ONBOARDING_SLIDES } from '@shared/content/onboarding';
import { radius, spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { PageIndicator } from '@/shared/components/PageIndicator';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { completeOnboarding } from '../../domain/onboardingService';

const SLIDE_ICONS = ['compass', 'accessibility', 'camera'] as const;

interface SlideProps {
  readonly index: number;
  readonly width: number;
}

function Slide({ index, width }: SlideProps) {
  const theme = useAppTheme();
  const slide = ONBOARDING_SLIDES[index];
  if (slide === undefined) return null;
  return (
    <View style={[styles.slide, { width }]}>
      <View style={[styles.slideHalo, { backgroundColor: theme.colors.primaryLight }]}>
        <IconSymbol name={SLIDE_ICONS[index] ?? 'camera'} size={64} color={theme.colors.primary} />
      </View>
      <AppText variant="heading" color={theme.colors.textPrimary} style={styles.slideTitle}>
        {slide.title}
      </AppText>
      <AppText
        variant="secondaryBody"
        color={theme.colors.textSecondary}
        align="center"
        style={styles.slideDesc}
      >
        {slide.description}
      </AppText>
    </View>
  );
}

export function OnboardingScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const { width } = useWindowDimensions();
  const [index, setIndex] = useState(0);
  const listRef = useRef<FlatList>(null);
  const last = index === ONBOARDING_SLIDES.length - 1;

  const finish = useCallback(() => {
    completeOnboarding();
    router.replace('/permissions');
  }, [router]);

  const next = useCallback(() => {
    if (last) {
      finish();
      return;
    }
    listRef.current?.scrollToIndex({ index: index + 1, animated: true });
  }, [index, last, finish]);

  const onMomentumEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const nextIndex = Math.round(event.nativeEvent.contentOffset.x / width);
    setIndex(Math.max(0, Math.min(ONBOARDING_SLIDES.length - 1, nextIndex)));
  };

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <View style={styles.skipRow}>
        {!last && (
          <Pressable
            onPress={finish}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="Skip onboarding"
          >
            <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.skip}>
              Skip
            </AppText>
          </Pressable>
        )}
      </View>

      <FlatList
        ref={listRef}
        data={ONBOARDING_SLIDES}
        keyExtractor={(item) => item.key}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={onMomentumEnd}
        renderItem={({ index: i }) => <Slide index={i} width={width} />}
        getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
      />

      <View style={styles.footer}>
        <PageIndicator count={ONBOARDING_SLIDES.length} activeIndex={index} />
        <AppButton
          title={last ? 'Continue' : 'Next'}
          onPress={next}
          style={styles.button}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  skipRow: {
    height: 48,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingHorizontal: spacing.xl,
  },
  skip: {
    fontWeight: '600',
  },
  slide: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl + spacing.sm,
  },
  slideHalo: {
    width: 160,
    height: 160,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  slideTitle: {
    marginTop: spacing.xxl,
  },
  slideDesc: {
    marginTop: spacing.md,
    maxWidth: 320,
  },
  footer: {
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.xl,
  },
  button: {
    marginTop: spacing.xl,
  },
});
