/**
 * Unit 04 — PermissionsScreen.
 * Two PermissionCards (camera + gallery), recovery via Open Settings,
 * Continue enabled once camera is granted. Notifications are never
 * requested (product rule). Web auto-grants (spec).
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import Constants from 'expo-constants';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { PrivacyNote } from '@/shared/components/PrivacyNote';
import { PermissionCard } from '../components/PermissionCard';
import { useAppPermissions } from '../hooks/useAppPermissions';
import { completePermissions } from '../../domain/onboardingService';

export function PermissionsScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const permissions = useAppPermissions();
  const isExpoGo = Constants.appOwnership === 'expo';

  const finish = () => {
    completePermissions();
    AppLogger.info('[Nav] permissions complete → /(tabs)');
    router.replace('/(tabs)');
  };

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <View style={styles.header}>
        <AppText variant="heading" color={theme.colors.textPrimary}>
          Permissions Needed
        </AppText>
        <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.headerSub}>
          Two quick asks. Nothing is ever uploaded — photos stay on your device.
        </AppText>
      </View>

      {isExpoGo && (
        <AppText
          variant="small"
          color={theme.colors.error}
          style={styles.hostNote}
        >
          Expo Go cannot provide PoseAssist's native camera/media permissions. Use the installed APK for the real camera and AI features.
        </AppText>
      )}

      <View style={styles.cards}>
        <PermissionCard
          icon="camera-outline"
          title="Camera Access"
          description="For live preview, AI pose detection and real-time guidance"
          status={permissions.camera}
          requesting={permissions.requesting === 'camera'}
          onAllow={() => permissions.requestPermission('camera')}
          onOpenSettings={permissions.openSettings}
        />
        <PermissionCard
          icon="image-multiple-outline"
          title="Gallery Access"
          description="To save your perfect shots and show them in the app gallery"
          status={permissions.photos}
          requesting={permissions.requesting === 'photos'}
          onAllow={() => permissions.requestPermission('photos')}
          onOpenSettings={permissions.openSettings}
        />
      </View>

      <View style={styles.footer}>
        <AppButton
          title="Continue"
          onPress={finish}
          disabled={!permissions.canContinue}
        />
        <View style={styles.privacy}>
          <PrivacyNote text="The camera only turns on inside the Camera tab, and angles are calculated on-device." />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.xl,
  },
  header: {
    paddingTop: spacing.xxl,
  },
  headerSub: {
    marginTop: spacing.sm,
  },
  cards: {
    marginTop: spacing.xl,
    gap: spacing.lg,
    flex: 1,
  },
  footer: {
    paddingTop: spacing.lg,
  },
  hostNote: {
    marginTop: spacing.md,
  },
  privacy: {
    marginTop: spacing.md,
  },
});
