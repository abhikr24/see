/**
 * Unit 03 — SplashScreen.
 * Animated logo (Reanimated fade + scale 0.8→1), runs startupService in
 * the background, then router.replace() to the decided destination.
 * Duration 0.5–1s per spec (startupService enforces the minimum).
 */
import React, { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { APP_SHORT_NAME } from '@shared/constants/app';
import { mediaColors } from '@shared/theme/colors';
import { radius, spacing } from '@shared/theme';
import { splashGradientFor } from '@shared/theme/gradients';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { runStartup } from '../../domain/startupService';

export function SplashScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const opacity = useSharedValue(0);
  const scale = useSharedValue(0.8);

  useEffect(() => {
    opacity.value = withTiming(1, { duration: 450 });
    scale.value = withTiming(1, { duration: 550 });

    let cancelled = false;
    const watchdog = setTimeout(() => {
      if (!cancelled) {
        AppLogger.warn('[Startup] watchdog fired — opening /welcome');
        router.replace('/welcome');
      }
    }, 2500);

    (async () => {
      try {
        const { destination } = await runStartup();
        if (!cancelled) router.replace(destination);
      } catch (error) {
        AppLogger.error(`[Startup] failed — falling back to /welcome (${String(error)})`);
        if (!cancelled) router.replace('/welcome');
      } finally {
        clearTimeout(watchdog);
      }
    })();
    return () => {
      cancelled = true;
      clearTimeout(watchdog);
    };
  }, [opacity, scale, router]);

  const animatedLogo = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }],
  }));

  return (
    <View style={[styles.root, { backgroundColor: theme.colors.background }]}>
      {/* Premium-pass item 8: brand tint bleeding into the background. */}
      <LinearGradient
        colors={splashGradientFor(theme.scheme)}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <Animated.View style={[styles.logoBlock, animatedLogo]}>
        <View style={[styles.logo, { backgroundColor: theme.colors.primary }]}>
          <IconSymbol name="camera" size={36} color={mediaColors.text} />
        </View>
        <AppText variant="title" color={theme.colors.textPrimary} style={styles.name}>
          {APP_SHORT_NAME}
        </AppText>
        <AppText variant="small" color={theme.colors.textSecondary} style={styles.tagline}>
          Smart Photography Assistant
        </AppText>
      </Animated.View>
      <ActivityIndicator
        size="small"
        color={theme.colors.primary}
        style={styles.spinner}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoBlock: {
    alignItems: 'center',
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: radius.lg + 4,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: mediaColors.shadow,
    shadowOpacity: 0.4,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 12 },
    elevation: 10,
  },
  name: {
    marginTop: spacing.lg,
  },
  tagline: {
    marginTop: spacing.xs,
  },
  spinner: {
    position: 'absolute',
    bottom: spacing.section,
  },
});
