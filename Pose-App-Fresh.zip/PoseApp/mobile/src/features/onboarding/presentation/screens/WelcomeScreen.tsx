/**
 * Unit 03 — WelcomeScreen.
 * Illustration (top 40%) + title/subtitle from shared/content + buttons:
 *  · "Get Started" → /onboarding
 *  · "Sign In"     → /auth (Unit 06 — real screen, was an Alert in Unit 03)
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { spacing } from '@shared/theme';
import { WELCOME_COPY } from '@shared/content/onboarding';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { PrivacyNote } from '@/shared/components/PrivacyNote';
import { PhotographyIllustration } from '../components/PhotographyIllustration';

export function WelcomeScreen() {
  const theme = useAppTheme();
  const router = useRouter();

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <View style={styles.hero}>
        <PhotographyIllustration size={144} icon="camera" iconSize={56} />
        <AppText
          variant="display"
          color={theme.colors.textPrimary}
          align="center"
          style={styles.title}
        >
          {WELCOME_COPY.title}
        </AppText>
        <AppText
          variant="body"
          color={theme.colors.textSecondary}
          align="center"
          style={styles.subtitle}
        >
          {WELCOME_COPY.subtitle}
        </AppText>
      </View>
      <View style={styles.actions}>
        <AppButton
          title={WELCOME_COPY.primaryCta}
          onPress={() => router.push('/onboarding')}
        />
        <AppButton
          title={WELCOME_COPY.secondaryCta}
          onPress={() => router.push('/auth')}
          variant="secondary"
          style={styles.secondary}
        />
        <View style={styles.privacy}>
          <PrivacyNote />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.xl,
  },
  hero: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: spacing.xxxl,
    maxWidth: 320,
  },
  subtitle: {
    marginTop: spacing.sm,
    maxWidth: 300,
  },
  actions: {
    gap: spacing.md,
  },
  secondary: {
    marginTop: 0,
  },
  privacy: {
    marginTop: spacing.sm,
  },
});
