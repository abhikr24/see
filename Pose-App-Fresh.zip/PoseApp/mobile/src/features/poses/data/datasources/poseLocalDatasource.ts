/**
 * Unit 15 - Pose local datasource for recent poses and pose history.
 * Single source of truth for recently viewed, used, and captured poses.
 * Persists up to 20 entries with lastUsed timestamps in MMKV.
 */
import { LIMITS, STORAGE_KEYS, getPoseById, type Pose, type RecentPoseRecord } from '@shared/index';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';

function readRawEntries(): RecentPoseRecord[] {
  const raw = storage.getString(STORAGE_KEYS.recentPoseIds);
  if (raw === undefined) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    
    // Backward compatibility / migration: handle string[] or object[]
    if (parsed.length > 0 && typeof parsed[0] === 'string') {
      const now = Date.now();
      return parsed.map((id: string, index: number) => ({
        poseId: id,
        lastUsed: now - index * 1000,
      }));
    }
    
    return parsed.filter(
      (entry): entry is RecentPoseRecord =>
        typeof entry === 'object' &&
        entry !== null &&
        typeof (entry as RecentPoseRecord).poseId === 'string' &&
        typeof (entry as RecentPoseRecord).lastUsed === 'number',
    );
  } catch (error) {
    AppLogger.error(`[PoseLocal] corrupted recents reset - ${String(error)}`);
    storage.delete(STORAGE_KEYS.recentPoseIds);
    return [];
  }
}

function writeEntries(entries: readonly RecentPoseRecord[]): void {
  storage.set(STORAGE_KEYS.recentPoseIds, JSON.stringify(entries));
}

export const poseLocalDatasource = {
  getRecentEntries(limit?: number): readonly RecentPoseRecord[] {
    const entries = readRawEntries().sort((a, b) => b.lastUsed - a.lastUsed);
    return limit !== undefined ? entries.slice(0, limit) : entries;
  },

  getRecentPoses(limit?: number): readonly Pose[] {
    const entries = this.getRecentEntries(limit);
    return entries
      .map((entry) => getPoseById(entry.poseId))
      .filter((pose): pose is Pose => pose !== null);
  },

  addToRecent(poseId: string, timestamp = Date.now()): void {
    const current = readRawEntries().filter((e) => e.poseId !== poseId);
    const updated: RecentPoseRecord[] = [
      { poseId, lastUsed: timestamp },
      ...current,
    ].slice(0, LIMITS.poseHistory);
    writeEntries(updated);
    AppLogger.info(`[PoseLocal] recent + ${poseId} (${updated.length}/${LIMITS.poseHistory} kept)`);
  },

  clear(): void {
    storage.delete(STORAGE_KEYS.recentPoseIds);
    AppLogger.info('[PoseLocal] recents cleared');
  },
};
