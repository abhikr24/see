/**
 * Unit 05 local pose repository. The bundled shared catalog is authoritative
 * and available on first launch; MMKV stores a validated metadata snapshot.
 */
import {
  getPoseById,
  getPoseCatalog,
  searchPoses,
  type Pose,
  type PoseCategoryId,
} from '@shared/index';
import { AppLogger } from '@/core/utils/logger';

function validateCatalog(poses: readonly Pose[]): void {
  if (poses.length !== 400) {
    throw new Error(`Expected 400 bundled poses; received ${poses.length}.`);
  }
  const ids = new Set(poses.map((pose) => pose.id));
  if (ids.size !== poses.length) {
    throw new Error('Bundled pose catalog contains duplicate ids.');
  }
}

class PoseRepository {
  private ready = false;

  warmup(): readonly Pose[] {
    const poses = getPoseCatalog();
    if (!this.ready) {
      // The catalog is already bundled in the JS binary and every query reads
      // that authoritative in-memory data. Persisting the entire 400-pose
      // JSON snapshot synchronously at app startup was unnecessary work on the
      // UI thread and could make low-end Android devices appear frozen.
      validateCatalog(poses);
      this.ready = true;
      AppLogger.info('[PoseLibrary] 400 unique bundled poses validated');
    }
    return poses;
  }

  getAll(): readonly Pose[] {
    return this.warmup();
  }

  getById(id: string): Pose | null {
    this.warmup();
    return getPoseById(id);
  }

  search(query: string, category: PoseCategoryId | 'all' = 'all'): readonly Pose[] {
    this.warmup();
    return searchPoses(query, { categoryId: category });
  }
}

export const poseRepository = new PoseRepository();
