/**
 * Unit 15 — Unified Recent Poses & History Store (Zustand + MMKV).
 * Single source of truth for Home Recent 4, Camera State 1, and Gallery Pose History.
 * Stores { poseId, lastUsed }[] up to 20 entries sorted by lastUsed desc.
 */
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { LIMITS, STORAGE_KEYS, type RecentPoseRecord } from '@shared/index';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';

const mmkvStateStorage = {
  getItem: (name: string): string | null => storage.getString(name) ?? null,
  setItem: (name: string, value: string): void => {
    storage.set(name, value);
  },
  removeItem: (name: string): void => {
    storage.delete(name);
  },
};

interface RecentPosesState {
  /** Full array of recent entries with timestamp, max LIMITS.poseHistory (20). */
  readonly entries: readonly RecentPoseRecord[];
  /** Legacy string ids projection for backward compatibility. */
  readonly recentIds: readonly string[];
  /** Add or move a pose to the front with an updated lastUsed timestamp. */
  readonly addToRecent: (poseId: string, timestamp?: number) => void;
  /** Alias to addToRecent for backward compatibility with earlier units. */
  readonly markViewed: (poseId: string) => void;
  readonly clear: () => void;
}

export const useRecentPosesStore = create<RecentPosesState>()(
  persist(
    (set, get) => ({
      entries: [],
      recentIds: [],

      addToRecent: (poseId: string, timestamp = Date.now()) => {
        const current = get().entries.filter((e) => e.poseId !== poseId);
        const nextEntries: RecentPoseRecord[] = [
          { poseId, lastUsed: timestamp },
          ...current,
        ].slice(0, LIMITS.poseHistory);

        set({
          entries: nextEntries,
          recentIds: nextEntries.map((e) => e.poseId),
        });
        AppLogger.info(`[PoseHistory] updated -> ${poseId} (${nextEntries.length}/${LIMITS.poseHistory})`);
      },

      markViewed: (poseId: string) => {
        get().addToRecent(poseId);
      },

      clear: () => set({ entries: [], recentIds: [] }),
    }),
    {
      name: STORAGE_KEYS.recentPoseIds,
      storage: createJSONStorage(() => mmkvStateStorage),
      version: 2,
      migrate: (persistedState: any) => {
        if (!persistedState) return { entries: [], recentIds: [] };
        // Handle migration from string[] recentIds (version 1)
        if (Array.isArray(persistedState.recentIds) && !Array.isArray(persistedState.entries)) {
          const now = Date.now();
          const entries = persistedState.recentIds.map((id: string, idx: number) => ({
            poseId: id,
            lastUsed: now - idx * 1000,
          }));
          return {
            entries,
            recentIds: entries.map((e: RecentPoseRecord) => e.poseId),
          };
        }
        return persistedState;
      },
    },
  ),
);
