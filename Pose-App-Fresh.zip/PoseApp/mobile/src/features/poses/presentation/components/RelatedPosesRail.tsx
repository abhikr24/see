/**
 * Unit 10 - RelatedPosesRail.
 * Horizontal "More like this" rail on the pose detail screen. Each card
 * pushes /pose/[id] (controller-owned) so the back stack walks the trail.
 */
import React from 'react';
import { FlatList, Pressable, StyleSheet, View } from 'react-native';
import { POSE_CATEGORIES, radius, spacing, type Pose } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';

interface RelatedPosesRailProps {
  readonly poses: readonly Pose[];
  readonly onOpen: (pose: Pose) => void;
}

export function RelatedPosesRail({ poses, onOpen }: RelatedPosesRailProps) {
  const theme = useAppTheme();
  if (poses.length === 0) return null;

  return (
    <View style={styles.section}>
      <View style={styles.headerRow}>
        <AppText variant="cardTitle" color={theme.colors.textPrimary} style={styles.heading}>
          More like this
        </AppText>
        <AppText variant="small" color={theme.colors.textSecondary}>
          {POSE_CATEGORIES.find((c) => c.id === poses[0]?.category)?.label ?? ''}
        </AppText>
      </View>
      <FlatList
        horizontal
        data={poses}
        keyExtractor={(item) => item.id}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.list}
        initialNumToRender={5}
        windowSize={5}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => onOpen(item)}
            accessibilityRole="button"
            accessibilityLabel={`Open related pose ${item.title}`}
            style={({ pressed }) => [styles.card, { opacity: pressed ? 0.85 : 1 }]}
          >
            <PoseCardArt
              pose={item}
              height={96}
              borderRadius={radius.md}
              iconSize={26}
              showBadges={false}
            />
            <AppText
              variant="small"
              color={theme.colors.textPrimary}
              numberOfLines={1}
              style={styles.cardTitle}
            >
              {item.title}
            </AppText>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginTop: spacing.xl,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
  },
  heading: {
    fontSize: 15,
  },
  list: {
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm + 2,
  },
  card: {
    width: 104,
  },
  cardTitle: {
    marginTop: spacing.xs,
    fontWeight: '600',
  },
});
