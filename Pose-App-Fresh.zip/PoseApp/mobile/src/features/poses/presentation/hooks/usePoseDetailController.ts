/**
 * Unit 10 - Pose detail controller.
 * Resolves the route id → pose, owns the recents write-back, the related
 * list, and the Use This Pose handoff (auth gate → camera). The screen
 * stays presentational; deep links hit exactly this logic.
 */
import { useCallback, useEffect, useMemo } from 'react';
import { useRouter } from 'expo-router';
import { getPoseById, getRelatedPoses, type Pose } from '@shared/index';
import { AppLogger } from '@/core/utils/logger';
import { useAuthStore } from '@/shared/stores/authStore';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';

export interface PoseDetailController {
  /** Null when the id does not resolve (stale deep link, deleted pose). */
  readonly pose: Pose | null;
  readonly related: readonly Pose[];
  readonly isAuthenticated: boolean;
  readonly useThisPose: () => void;
  readonly openRelated: (pose: Pose) => void;
  readonly goBack: () => void;
}

/** Expo Router may hand string | string[] — normalize to a single id. */
export function normalizePoseIdParam(raw: string | string[] | undefined): string | null {
  if (typeof raw === 'string' && raw.length > 0) return raw;
  if (Array.isArray(raw) && typeof raw[0] === 'string' && raw[0].length > 0) return raw[0];
  return null;
}

export function usePoseDetailController(poseId: string | null): PoseDetailController {
  const router = useRouter();
  const addToRecent = useRecentPosesStore((s) => s.addToRecent);
  const session = useAuthStore((s) => s.session);

  const pose = useMemo(
    () => (poseId !== null ? getPoseById(poseId) : null),
    [poseId],
  );
  const related = useMemo(
    () => (pose !== null ? getRelatedPoses(pose) : []),
    [pose],
  );

  // Viewing a detail page updates the unified recents / history store.
  useEffect(() => {
    if (pose !== null) {
      addToRecent(pose.id);
      AppLogger.info(`[PoseDetail] open → ${pose.id}`);
    } else if (poseId !== null) {
      AppLogger.warn(`[PoseDetail] unknown pose id → ${poseId}`);
    }
  }, [pose, poseId, addToRecent]);

  const useThisPose = useCallback(() => {
    if (pose === null) return;
    addToRecent(pose.id);
    if (session === null) {
      AppLogger.info('[PoseDetail] guest → auth gate (camera requires account)');
      router.push('/auth');
      return;
    }
    AppLogger.info(`[PoseDetail] Use This Pose → /(tabs)/camera with ${pose.id}`);
    // Unit 12: camera State 2 mounted directly with the pose reference.
    router.push({ pathname: '/(tabs)/camera', params: { poseId: pose.id } });
  }, [pose, session, addToRecent, router]);

  const openRelated = useCallback(
    (next: Pose) => {
      // push (not replace): each related pose is a legit history entry,
      // the back button walks the browsing trail — expected mobile UX.
      router.push(`/pose/${next.id}`);
    },
    [router],
  );

  const goBack = useCallback(() => {
    if (router.canGoBack()) router.back();
    else router.replace('/(tabs)/explore');
  }, [router]);

  return {
    pose,
    related,
    isAuthenticated: session !== null,
    useThisPose,
    openRelated,
    goBack,
  };
}
