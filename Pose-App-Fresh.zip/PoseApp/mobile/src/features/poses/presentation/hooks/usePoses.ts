/**
 * Unit 15 — Unified hooks for recent poses and pose history.
 * Home & Camera use useRecentPoses(4); Gallery uses useRecentPoses() for the full list.
 */
import { useMemo } from 'react';
import { getPoseById, type Pose, type RecentPoseRecord } from '@shared/index';
import { useRecentPosesStore } from '../../data/recentPosesStore';

export function useRecentPoses(limit?: number): readonly Pose[] {
  const entries = useRecentPosesStore((state: { entries: readonly RecentPoseRecord[] }) => state.entries);
  return useMemo(() => {
    const target = limit !== undefined ? entries.slice(0, limit) : entries;
    return target
      .map((entry: RecentPoseRecord) => getPoseById(entry.poseId))
      .filter((pose): pose is Pose => pose !== null);
  }, [entries, limit]);
}

export function useAddToRecent() {
  return useRecentPosesStore((state: { addToRecent: (poseId: string, timestamp?: number) => void }) => state.addToRecent);
}
