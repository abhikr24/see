/**
 * Unit 10 - PoseDetailScreen (/pose/[id]).
 * The canonical full-screen pose view: hero art, badges, description,
 * photographer tips, tags, related-poses rail, sticky Use This Pose CTA.
 * Reachable via the Explore sheet ("View full detail"), Home recents,
 * related-rail pushes, or a deep link (smartphotography://pose/<id>).
 * Pure React Native — zero DOM elements, zero web APIs.
 */
import React from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  POSE_CATEGORIES,
  mediaColors,
  radius,
  spacing,
  type Difficulty,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { AppButton } from '@/shared/components/AppButton';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { FavoriteButton } from '@/features/favorites/presentation/components/FavoriteButton';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';
import { RelatedPosesRail } from '../components/RelatedPosesRail';
import type { PoseDetailController } from '../hooks/usePoseDetailController';

const DIFFICULTY_LABEL: Record<Difficulty, string> = {
  beginner: 'Beginner',
  intermediate: 'Intermediate',
  advanced: 'Advanced',
};

function NotFound({ controller }: { readonly controller: PoseDetailController }) {
  const theme = useAppTheme();
  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <View style={styles.notFound}>
        <View style={[styles.notFoundIcon, { backgroundColor: theme.colors.backgroundSecondary }]}>
          <IconSymbol name="image-off-outline" size={36} color={theme.colors.textDisabled} />
        </View>
        <AppText variant="heading" color={theme.colors.textPrimary} style={styles.notFoundTitle}>
          Pose not found
        </AppText>
        <AppText
          variant="secondaryBody"
          color={theme.colors.textSecondary}
          align="center"
          style={styles.notFoundDesc}
        >
          This link points to a pose that is not in the bundled library. It may
          have been renamed in a newer catalog.
        </AppText>
        <AppButton
          title="Back to Explore"
          onPress={controller.goBack}
          icon="compass-outline"
          style={styles.notFoundButton}
        />
      </View>
    </SafeAreaView>
  );
}

export function PoseDetailScreen({
  controller,
}: {
  readonly controller: PoseDetailController;
}) {
  const theme = useAppTheme();
  const { pose } = controller;
  if (pose === null) return <NotFound controller={controller} />;

  const meta = POSE_CATEGORIES.find((c) => c.id === pose.category);

  return (
    <View style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Hero */}
        <View>
          <PoseCardArt
            pose={pose}
            height={252}
            borderRadius={0}
            iconSize={84}
            showBadges={false}
          />
          <SafeAreaView edges={['top']} style={styles.heroOverlay}>
            <View style={styles.heroNav}>
              <Pressable
                onPress={controller.goBack}
                hitSlop={10}
                accessibilityRole="button"
                accessibilityLabel="Back"
                style={({ pressed }) => [styles.backButton, { opacity: pressed ? 0.7 : 1 }]}
              >
                <IconSymbol name="chevron-left" size={20} color={mediaColors.text} />
              </Pressable>
              <FavoriteButton
                poseId={pose.id}
                size={20}
                style={styles.heroFav}
              />
            </View>
          </SafeAreaView>
          <View style={styles.heroTitleWrap}>
            <AppText variant="title" color={mediaColors.text} style={styles.heroTitle} numberOfLines={2}>
              {pose.title}
            </AppText>
            <AppText variant="small" color={mediaColors.textMuted}>
              {meta?.label} · {meta?.tagline}
            </AppText>
          </View>
        </View>

        {/* Badges */}
        <View style={styles.badges}>
          <View style={[styles.pill, { backgroundColor: theme.colors.primaryLight }]}>
            <IconSymbol name={(meta?.icon ?? 'camera') as never} size={11} color={theme.colors.primary} />
            <AppText variant="small" color={theme.colors.primary} style={styles.pillText}>
              {meta?.label}
            </AppText>
          </View>
          <View style={[styles.pill, { backgroundColor: theme.colors.backgroundSecondary }]}>
            <View style={[styles.levelDot, { backgroundColor: theme.colors.warning }]} />
            <AppText variant="small" color={theme.colors.textSecondary} style={styles.pillText}>
              {DIFFICULTY_LABEL[pose.difficulty]}
            </AppText>
          </View>
          {pose.isPremium && (
            <View style={[styles.pill, { backgroundColor: mediaColors.premiumLight }]}>
              <IconSymbol name="crown" size={11} color={mediaColors.premiumText} />
              <AppText variant="small" color={mediaColors.premiumText} style={styles.pillText}>
                Premium
              </AppText>
            </View>
          )}
          <View style={[styles.pill, { backgroundColor: theme.colors.backgroundSecondary }]}>
            <IconSymbol name="target" size={11} color={theme.colors.textSecondary} />
            <AppText variant="small" color={theme.colors.textSecondary} style={styles.pillText}>
              Auto-capture at {pose.matchTarget}%
            </AppText>
          </View>
        </View>

        {/* Body */}
        <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.desc}>
          {pose.description}
        </AppText>

        <AppText variant="small" color={theme.colors.textDisabled} style={styles.sectionLabel}>
          PHOTOGRAPHER TIPS
        </AppText>
        {pose.tips.map((tip) => (
          <View key={tip} style={styles.tipRow}>
            <View style={[styles.tipDot, { backgroundColor: theme.colors.primaryLight }]}>
              <IconSymbol name="check" size={10} color={theme.colors.primary} />
            </View>
            <AppText variant="secondaryBody" color={theme.colors.textSecondary} style={styles.tipText}>
              {tip}
            </AppText>
          </View>
        ))}

        <View style={styles.tags}>
          {pose.tags.map((tag) => (
            <View key={tag} style={[styles.tag, { backgroundColor: theme.colors.backgroundSecondary }]}>
              <AppText variant="small" color={theme.colors.textSecondary}>
                #{tag}
              </AppText>
            </View>
          ))}
        </View>

        <RelatedPosesRail poses={controller.related} onOpen={controller.openRelated} />
      </ScrollView>

      {/* Sticky CTA */}
      <SafeAreaView
        edges={['bottom']}
        style={[styles.ctaBar, { backgroundColor: theme.colors.background, borderTopColor: theme.colors.divider }]}
      >
        <AppButton
          title="Use This Pose"
          onPress={controller.useThisPose}
          icon="camera"
        />
        <AppText variant="small" color={theme.colors.textDisabled} align="center" style={styles.ctaNote}>
          {controller.isAuthenticated
            ? 'Opens the camera with this reference pinned for live guidance'
            : 'Sign-in required — the camera suite is an authenticated feature'}
        </AppText>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  scroll: {
    paddingBottom: spacing.xl,
  },
  heroOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  heroNav: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingTop: spacing.xs,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.overlayMedium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroFav: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    backgroundColor: mediaColors.overlayMedium,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroTitleWrap: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    bottom: spacing.md,
  },
  heroTitle: {
    fontSize: 24,
    lineHeight: 30,
    textShadowColor: mediaColors.overlayStrong,
    textShadowRadius: 8,
    textShadowOffset: { width: 0, height: 1 },
  },
  badges: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: spacing.xs + 1,
  },
  pillText: {
    fontWeight: '600',
    fontSize: 10,
  },
  levelDot: {
    width: 6,
    height: 6,
    borderRadius: radius.circle,
  },
  desc: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  sectionLabel: {
    fontWeight: '600',
    letterSpacing: 0.8,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
  },
  tipRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.sm,
  },
  tipDot: {
    width: 16,
    height: 16,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  tipText: {
    flex: 1,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  tag: {
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 3,
  },
  ctaBar: {
    borderTopWidth: 1,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  ctaNote: {
    marginTop: spacing.sm,
    marginBottom: spacing.xs,
    fontSize: 9,
  },
  notFound: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  notFoundIcon: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  notFoundTitle: {
    marginTop: spacing.lg,
  },
  notFoundDesc: {
    marginTop: spacing.xs,
    maxWidth: 300,
  },
  notFoundButton: {
    marginTop: spacing.xl,
    minWidth: 220,
  },
});
