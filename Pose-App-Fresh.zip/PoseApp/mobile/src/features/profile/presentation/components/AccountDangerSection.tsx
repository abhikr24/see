/**
 * Profile · Danger Zone — the discoverable deletion entry (B1).
 * A single restrained tile, visually subordinate to Sign Out but
 * unmistakably destructive. Navigation only — the serious two-step flow
 * lives at /delete-account. Guests never see it (no account, nothing to
 * delete).
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ACCOUNT_DELETE_COPY, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppLogger } from '@/core/utils/logger';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

export function AccountDangerSection() {
  const theme = useAppTheme();
  const router = useRouter();
  return (
    <View style={styles.wrap}>
      <View style={styles.header}>
        <IconSymbol name="alert-octagon-outline" size={20} color={theme.colors.error} />
        <AppText variant="cardTitle" color={theme.colors.textPrimary}>
          Danger Zone
        </AppText>
      </View>
      <Pressable
        onPress={() => {
          AppLogger.info('[Nav] profile → /delete-account');
          router.push('/delete-account');
        }}
        accessibilityRole="button"
        accessibilityLabel={`${ACCOUNT_DELETE_COPY.entryTitle}. ${ACCOUNT_DELETE_COPY.entryDescription}`}
        style={({ pressed }) => [
          styles.tile,
          {
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.error,
            opacity: pressed ? 0.75 : 1,
          },
        ]}
      >
        <View style={[styles.iconWrap, { backgroundColor: theme.colors.primaryLight }]}>
          <IconSymbol name="delete-forever-outline" size={20} color={theme.colors.error} />
        </View>
        <View style={styles.copy}>
          <AppText variant="body" color={theme.colors.error}>
            {ACCOUNT_DELETE_COPY.entryTitle}
          </AppText>
          <AppText variant="small" color={theme.colors.textSecondary} style={styles.description}>
            {ACCOUNT_DELETE_COPY.entryDescription}
          </AppText>
        </View>
        <IconSymbol name="chevron-right" size={18} color={theme.colors.textDisabled} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginBottom: spacing.lg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    minHeight: 64,
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  copy: {
    flex: 1,
  },
  description: {
    marginTop: 2,
  },
});
