/**
 * Unit 19 — EditDisplayNameModal.
 * Theme-aware modal for updating user's display name with validation.
 */
import React, { useEffect, useState } from 'react';
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  TextInput,
  View,
} from 'react-native';
import { mediaColors, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppButton } from '@/shared/components/AppButton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface EditDisplayNameModalProps {
  readonly visible: boolean;
  readonly currentName: string;
  readonly onSave: (newName: string) => Promise<boolean>;
  readonly onClose: () => void;
}

export function EditDisplayNameModal({
  visible,
  currentName,
  onSave,
  onClose,
}: EditDisplayNameModalProps) {
  const theme = useAppTheme();
  const [name, setName] = useState(currentName);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (visible) {
      setName(currentName);
      setError(null);
      setLoading(false);
    }
  }, [visible, currentName]);

  const handleSave = async () => {
    const trimmed = name.trim();
    if (trimmed.length === 0) {
      setError('Name cannot be empty.');
      return;
    }
    if (trimmed.length > 50) {
      setError('Name must be 50 characters or less.');
      return;
    }
    setError(null);
    setLoading(true);
    const success = await onSave(trimmed);
    setLoading(false);
    if (success) {
      onClose();
    } else {
      setError('Failed to update name. Try again.');
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.scrim}
      >
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={onClose}
          accessibilityLabel="Close modal backdrop"
        />

        <View
          style={[
            styles.dialog,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
            },
          ]}
        >
          <View style={styles.header}>
            <View
              style={[
                styles.iconWrap,
                { backgroundColor: theme.colors.primaryLight },
              ]}
            >
              <IconSymbol
                name="account-edit-outline"
                size={24}
                color={theme.colors.primary}
              />
            </View>
            <View style={styles.headerText}>
              <AppText
                variant="cardTitle"
                color={theme.colors.textPrimary}
              >
                Edit Display Name
              </AppText>
              <AppText
                variant="small"
                color={theme.colors.textSecondary}
              >
                How you appear across the app
              </AppText>
            </View>
          </View>

          <View style={styles.inputContainer}>
            <TextInput
              value={name}
              onChangeText={(text) => {
                setName(text);
                if (error) setError(null);
              }}
              placeholder="Enter display name"
              placeholderTextColor={theme.colors.textDisabled}
              style={[
                styles.input,
                {
                  color: theme.colors.textPrimary,
                  borderColor: error ? theme.colors.error : theme.colors.divider,
                  backgroundColor: theme.colors.backgroundSecondary,
                },
              ]}
              autoFocus
              maxLength={50}
              returnKeyType="done"
              onSubmitEditing={handleSave}
            />
            {error !== null && (
              <AppText
                variant="small"
                color={theme.colors.error}
                style={styles.errorText}
              >
                {error}
              </AppText>
            )}
          </View>

          <View style={styles.buttonRow}>
            <AppButton
              title="Cancel"
              variant="ghost"
              onPress={onClose}
              style={styles.actionBtn}
            />
            <AppButton
              title="Save"
              variant="primary"
              loading={loading}
              onPress={handleSave}
              style={styles.actionBtn}
            />
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  scrim: {
    flex: 1,
    backgroundColor: mediaColors.overlayHeavy,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  dialog: {
    width: '100%',
    maxWidth: 360,
    borderRadius: radius.xl,
    borderWidth: 1,
    padding: spacing.xl,
    gap: spacing.lg,
    zIndex: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    flex: 1,
    gap: spacing.xs,
  },
  inputContainer: {
    gap: spacing.xs,
  },
  input: {
    height: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: spacing.md,
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
  },
  errorText: {
    marginTop: spacing.xs,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: spacing.md,
    justifyContent: 'flex-end',
  },
  actionBtn: {
    flex: 1,
  },
});
