/**
 * Unit 19 — FavoritesSection.
 * Displays user's favorite poses in a 2-column grid with live FavoriteButton
 * toggling, or shows an empty state prompting exploration.
 */
import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import {
  getPoseById,
  radius,
  spacing,
  type Pose,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useFavoritesStore } from '@/features/favorites/data/favoritesStore';
import { useAuthStore } from '@/shared/stores/authStore';
import { syncFavoritesWithCloud } from '@/features/favorites/domain/favoritesSyncService';
import { AppButton } from '@/shared/components/AppButton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { PoseCardArt } from '@/features/explore/presentation/components/PoseCardArt';
import { FavoriteButton } from '@/features/favorites/presentation/components/FavoriteButton';
import { errorHandler, type AppError } from '@/core/error/errorHandler';
import { EmptyStateWidget } from '@/shared/components/EmptyStateWidget';

interface FavoriteCardProps {
  readonly pose: Pose;
  readonly onPress: () => void;
}

function FavoriteCard({ pose, onPress }: FavoriteCardProps) {
  const theme = useAppTheme();

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`View favorite pose ${pose.title}`}
      style={({ pressed }) => [
        styles.poseCard,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
          opacity: pressed ? 0.88 : 1,
        },
      ]}
    >
      <View style={styles.cardImageContainer}>
        <PoseCardArt pose={pose} height={120} borderRadius={radius.md} iconSize={32} />
        <FavoriteButton
          poseId={pose.id}
          size={16}
          style={styles.favBtn}
        />
      </View>
      <View style={styles.cardBody}>
        <AppText
          variant="small"
          color={theme.colors.textPrimary}
          numberOfLines={1}
          style={styles.poseTitle}
        >
          {pose.title}
        </AppText>
        <AppText
          variant="small"
          color={theme.colors.textSecondary}
          numberOfLines={1}
          style={styles.poseCategory}
        >
          {pose.category.charAt(0).toUpperCase() + pose.category.slice(1)}
        </AppText>
      </View>
    </Pressable>
  );
}

export function FavoritesSection() {
  const theme = useAppTheme();
  const router = useRouter();
  const userId = useAuthStore((s) => s.session?.id ?? null);
  const favoriteIds = useFavoritesStore((s) => s.favoriteIds);
  const [syncError, setSyncError] = useState<AppError | null>(null);

  const sync = useCallback(async () => {
    if (userId === null) return;
    setSyncError(null);
    try {
      await syncFavoritesWithCloud(userId);
    } catch (error) {
      setSyncError(errorHandler.handle(error, 'Profile/FavoritesSync'));
    }
  }, [userId]);

  useEffect(() => {
    void sync();
  }, [sync]);

  const favoritePoses = favoriteIds
    .map((id) => getPoseById(id))
    .filter((p): p is Pose => p !== null);

  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <View style={styles.headerTitleRow}>
          <IconSymbol
            name="heart"
            size={20}
            color={theme.colors.error}
          />
          <AppText variant="cardTitle" color={theme.colors.textPrimary}>
            Favourite Poses
          </AppText>
        </View>

        <View
          style={[
            styles.countBadge,
            { backgroundColor: theme.colors.primaryLight },
          ]}
        >
          <AppText
            variant="small"
            color={theme.colors.primary}
            style={styles.countText}
          >
            {favoritePoses.length}
          </AppText>
        </View>
      </View>

      {syncError !== null && (
        <View
          style={[
            styles.syncError,
            {
              backgroundColor: theme.colors.backgroundSecondary,
              borderColor: theme.colors.divider,
            },
          ]}
          accessibilityRole="alert"
        >
          <IconSymbol name="cloud-alert-outline" size={22} color={theme.colors.warning} />
          <View style={styles.syncErrorText}>
            <AppText variant="small" color={theme.colors.textPrimary} style={styles.syncErrorTitle}>
              Favorites could not sync
            </AppText>
            <AppText variant="small" color={theme.colors.textSecondary} numberOfLines={2}>
              {syncError.message} Your local favorites are still available.
            </AppText>
          </View>
          <AppButton title="Retry" variant="ghost" onPress={() => void sync()} />
        </View>
      )}

      {favoritePoses.length === 0 ? (
        <EmptyStateWidget
          icon="heart-outline"
          title="No favorites yet"
          description="Explore the catalog and tap the heart icon on any pose to save your favorite stances here."
          buttonText="Explore Poses"
          onButtonPress={() => router.push('/(tabs)/explore')}
          style={[
            styles.emptyCard,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
            },
          ]}
        />
      ) : (
        <View style={styles.grid}>
          {favoritePoses.map((pose) => (
            <FavoriteCard
              key={pose.id}
              pose={pose}
              onPress={() => router.push(`/pose/${pose.id}`)}
            />
          ))}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  headerTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  countBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
  },
  countText: {
    fontWeight: '700',
  },
  syncError: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.md,
  },
  syncErrorText: {
    flex: 1,
  },
  syncErrorTitle: {
    fontWeight: '600',
  },
  emptyCard: {
    borderRadius: radius.lg,
    borderWidth: 1,
    marginTop: spacing.xs,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  poseCard: {
    width: '47.5%',
    borderRadius: radius.md,
    borderWidth: 1,
    overflow: 'hidden',
  },
  cardImageContainer: {
    position: 'relative',
  },
  favBtn: {
    position: 'absolute',
    top: spacing.xs,
    right: spacing.xs,
  },
  cardBody: {
    padding: spacing.sm,
    gap: spacing.xs,
  },
  poseTitle: {
    fontWeight: '600',
  },
  poseCategory: {
    fontSize: 11,
  },
});
