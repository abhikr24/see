/**
 * Unit 19 — GuestLoginCTA.
 * Call-to-action card for unauthenticated guests explaining benefits of signing in.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppButton } from '@/shared/components/AppButton';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

export function GuestLoginCTA() {
  const theme = useAppTheme();
  const router = useRouter();

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: theme.colors.primaryLight,
          borderColor: theme.colors.primary,
        },
      ]}
    >
      <View style={styles.header}>
        <View
          style={[
            styles.iconWrap,
            { backgroundColor: theme.colors.surface },
          ]}
        >
          <IconSymbol
            name="cloud-sync-outline"
            size={28}
            color={theme.colors.primary}
          />
        </View>

        <View style={styles.textWrap}>
          <AppText
            variant="cardTitle"
            color={theme.colors.primary}
          >
            Sign in to sync
          </AppText>
          <AppText
            variant="small"
            color={theme.colors.textSecondary}
          >
            Save favorites across devices & unlock full camera tools
          </AppText>
        </View>
      </View>

      <AppButton
        title="Sign In or Create Account"
        variant="primary"
        onPress={() => router.push('/auth')}
        style={styles.button}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.lg,
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textWrap: {
    flex: 1,
    gap: spacing.xs,
  },
  button: {
    width: '100%',
  },
});
