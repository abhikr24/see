/**
 * Unit 19 — ProfileHeader.
 * Avatar (80px circle), Display Name (Heading 22 600), Email (Body 14),
 * Auth provider badge, and Edit button (48x48 touch target).
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import type { AuthUser } from '@/features/auth/domain/entities/authUser';
import { AppImage } from '@/shared/components/AppImage';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { ShimmerAvatar } from '@/shared/components/ShimmerSkeleton';

interface ProfileHeaderProps {
  readonly user: AuthUser | null;
  readonly onEditName: () => void;
  readonly isLoading?: boolean;
}

export function ProfileHeader({ user, onEditName, isLoading = false }: ProfileHeaderProps) {
  const theme = useAppTheme();
  const isAuthenticated = user !== null;
  const displayName = user?.displayName || 'Guest User';
  const email = user?.email || 'Sign in to sync your profile';
  const provider = user?.provider;

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
        },
      ]}
    >
      {isLoading ? (
        <View style={styles.topRow}>
          <ShimmerAvatar withName={false} />
          <View style={styles.infoCol}>
            <View style={{ height: 22, width: 140, borderRadius: radius.xs, backgroundColor: theme.colors.backgroundSecondary }} />
            <View style={{ height: 14, width: 180, borderRadius: radius.xs, backgroundColor: theme.colors.backgroundSecondary, marginTop: 4 }} />
          </View>
        </View>
      ) : (
        <View style={styles.topRow}>
          <View
            style={[
              styles.avatar,
              {
                backgroundColor: theme.colors.primaryLight,
                borderColor: theme.colors.divider,
              },
            ]}
          >
            {user?.avatarUrl ? (
              <AppImage
                uri={user.avatarUrl}
                accessibilityLabel={`${displayName}'s avatar`}
                style={styles.avatarImage}
              />
            ) : (
              <IconSymbol
                name="account"
                size={48}
                color={theme.colors.primary}
              />
            )}
          </View>

          <View style={styles.infoCol}>
            <View style={styles.nameRow}>
              <AppText
                variant="heading"
                color={theme.colors.textPrimary}
                style={styles.displayName}
                numberOfLines={1}
              >
                {displayName}
              </AppText>

              {isAuthenticated && (
                <Pressable
                  onPress={onEditName}
                  hitSlop={12}
                  accessibilityRole="button"
                  accessibilityLabel="Edit display name"
                  style={({ pressed }) => [
                    styles.editButton,
                    {
                      backgroundColor: theme.colors.primaryLight,
                      opacity: pressed ? 0.75 : 1,
                    },
                  ]}
                >
                  <IconSymbol
                    name="pencil-outline"
                    size={16}
                    color={theme.colors.primary}
                  />
                </Pressable>
              )}
            </View>

            <AppText
              variant="secondaryBody"
              color={theme.colors.textSecondary}
              numberOfLines={1}
              style={styles.emailText}
            >
              {email}
            </AppText>

            <View style={styles.badgeRow}>
              <View
                style={[
                  styles.badge,
                  {
                    backgroundColor: isAuthenticated
                      ? theme.colors.primaryLight
                      : theme.colors.divider,
                  },
                ]}
              >
                <IconSymbol
                  name={
                    provider === 'google'
                      ? 'google'
                      : isAuthenticated
                      ? 'email-outline'
                      : 'account-outline'
                  }
                  size={12}
                  color={
                    isAuthenticated
                      ? theme.colors.primary
                      : theme.colors.textSecondary
                  }
                />
                <AppText
                  variant="small"
                  color={
                    isAuthenticated
                      ? theme.colors.primary
                      : theme.colors.textSecondary
                  }
                  style={styles.badgeLabel}
                >
                  {provider === 'google'
                    ? 'Google Account'
                    : isAuthenticated
                    ? 'Email Account'
                    : 'Guest Mode'}
                </AppText>
              </View>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.lg,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImage: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
  },
  infoCol: {
    flex: 1,
    gap: spacing.xs,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.sm,
  },
  displayName: {
    flex: 1,
  },
  editButton: {
    width: 32,
    height: 32,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emailText: {
    marginTop: -spacing.xs,
  },
  badgeRow: {
    flexDirection: 'row',
    marginTop: spacing.xs,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
  },
  badgeLabel: {
    fontWeight: '600',
  },
});
