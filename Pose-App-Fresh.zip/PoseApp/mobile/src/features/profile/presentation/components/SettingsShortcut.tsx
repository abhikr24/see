/**
 * Unit 19 — SettingsShortcut.
 * Navigation shortcut to camera & system settings (built in Units 20-21).
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

export function SettingsShortcut() {
  const theme = useAppTheme();
  const router = useRouter();

  const handlePress = () => {
    router.push('/settings');
  };

  return (
    <View style={styles.container}>
      <Pressable
        onPress={handlePress}
        accessibilityRole="button"
        accessibilityLabel="Open settings"
        style={({ pressed }) => [
          styles.tile,
          {
            backgroundColor: theme.colors.surface,
            borderColor: theme.colors.divider,
            opacity: pressed ? 0.75 : 1,
          },
        ]}
      >
        <View
          style={[
            styles.iconWrap,
            { backgroundColor: theme.colors.primaryLight },
          ]}
        >
          <IconSymbol
            name="cog-outline"
            size={22}
            color={theme.colors.primary}
          />
        </View>
        <View style={styles.body}>
          <AppText variant="body" color={theme.colors.textPrimary}>
            Camera & App Settings
          </AppText>
          <AppText variant="small" color={theme.colors.textSecondary}>
            Flash, timer, voice & capture preferences
          </AppText>
        </View>
        <IconSymbol
          name="chevron-right"
          size={20}
          color={theme.colors.textDisabled}
        />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: spacing.xl,
  },
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
    minHeight: 64,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    flex: 1,
    gap: 2,
  },
});
