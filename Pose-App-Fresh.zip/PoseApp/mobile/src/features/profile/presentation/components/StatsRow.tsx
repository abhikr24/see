/**
 * Unit 19 — StatsRow.
 * 3-column statistics display (Favorites / Photos / Poses Tried) with dividers.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import type { ProfileStats } from '../hooks/useProfileStats';

interface StatsRowProps {
  readonly stats: ProfileStats;
}

export function StatsRow({ stats }: StatsRowProps) {
  const theme = useAppTheme();

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
        },
      ]}
    >
      <View style={styles.statCol}>
        <AppText
          variant="heading"
          color={theme.colors.textPrimary}
          style={styles.number}
        >
          {stats.favoritesCount}
        </AppText>
        <AppText
          variant="small"
          color={theme.colors.textSecondary}
          style={styles.label}
        >
          Favorites
        </AppText>
      </View>

      <View
        style={[
          styles.divider,
          { backgroundColor: theme.colors.divider },
        ]}
      />

      <View style={styles.statCol}>
        <AppText
          variant="heading"
          color={theme.colors.textPrimary}
          style={styles.number}
        >
          {stats.photosCount}
        </AppText>
        <AppText
          variant="small"
          color={theme.colors.textSecondary}
          style={styles.label}
        >
          Photos
        </AppText>
      </View>

      <View
        style={[
          styles.divider,
          { backgroundColor: theme.colors.divider },
        ]}
      />

      <View style={styles.statCol}>
        <AppText
          variant="heading"
          color={theme.colors.textPrimary}
          style={styles.number}
        >
          {stats.posesUsedCount}
        </AppText>
        <AppText
          variant="small"
          color={theme.colors.textSecondary}
          style={styles.label}
        >
          Poses Tried
        </AppText>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.lg,
  },
  statCol: {
    flex: 1,
    alignItems: 'center',
    gap: spacing.xs,
  },
  divider: {
    width: 1,
    height: 32,
  },
  number: {
    fontWeight: '700',
  },
  label: {
    fontWeight: '500',
  },
});
