/**
 * Unit 19 — StorageSection.
 * Storage & Cache controls: Clear Image Cache, Clear Recent Poses,
 * and live Theme Mode Switcher.
 */
import React from 'react';
import { Alert, Pressable, StyleSheet, View } from 'react-native';
import { Image } from 'expo-image';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { ThemeModeSwitcher } from '@/shared/components/ThemeModeSwitcher';
import { errorHandler } from '@/core/error/errorHandler';
import { showSuccessSnackBar } from '@/shared/stores/snackBarStore';

export function StorageSection() {
  const theme = useAppTheme();
  const recentCount = useRecentPosesStore((s) => s.entries.length);

  const handleClearCache = () => {
    Alert.alert(
      'Clear Image Cache?',
      'This removes temporary thumbnail and cache files. Your saved device gallery photos will NOT be deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear Cache',
          style: 'destructive',
          onPress: async () => {
            try {
              await Image.clearDiskCache();
              await Image.clearMemoryCache();
              showSuccessSnackBar('Cache cleared', { variant: 'primary' });
            } catch (error) {
              errorHandler.handle(error, 'Profile/ClearImageCache');
              showSuccessSnackBar('Could not clear cache', { variant: 'primary' });
            }
          },
        },
      ],
    );
  };

  const handleClearRecents = () => {
    Alert.alert(
      'Clear Recent Poses?',
      'Reset your recently viewed and used pose history.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear Recents',
          style: 'destructive',
          onPress: () => {
            useRecentPosesStore.getState().clear();
            showSuccessSnackBar('Recents cleared', { variant: 'primary' });
          },
        },
      ],
    );
  };

  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <IconSymbol
          name="database-outline"
          size={20}
          color={theme.colors.primary}
        />
        <AppText variant="cardTitle" color={theme.colors.textPrimary}>
          Storage & Preferences
        </AppText>
      </View>

      <View style={styles.tilesContainer}>
        {/* Clear Image Cache Tile */}
        <Pressable
          onPress={handleClearCache}
          accessibilityRole="button"
          accessibilityLabel="Clear temporary image cache"
          style={({ pressed }) => [
            styles.tile,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
              opacity: pressed ? 0.75 : 1,
            },
          ]}
        >
          <View
            style={[
              styles.tileIconWrap,
              { backgroundColor: theme.colors.primaryLight },
            ]}
          >
            <IconSymbol
              name="delete-sweep-outline"
              size={22}
              color={theme.colors.primary}
            />
          </View>
          <View style={styles.tileBody}>
            <AppText variant="body" color={theme.colors.textPrimary}>
              Clear Image Cache
            </AppText>
            <AppText variant="small" color={theme.colors.textSecondary}>
              Frees up temporary cache data
            </AppText>
          </View>
          <IconSymbol
            name="chevron-right"
            size={20}
            color={theme.colors.textDisabled}
          />
        </Pressable>

        {/* Clear Recent Poses Tile */}
        <Pressable
          onPress={handleClearRecents}
          accessibilityRole="button"
          accessibilityLabel={`Clear ${recentCount} recent poses`}
          style={({ pressed }) => [
            styles.tile,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
              opacity: pressed ? 0.75 : 1,
            },
          ]}
        >
          <View
            style={[
              styles.tileIconWrap,
              { backgroundColor: theme.colors.primaryLight },
            ]}
          >
            <IconSymbol
              name="history"
              size={22}
              color={theme.colors.primary}
            />
          </View>
          <View style={styles.tileBody}>
            <AppText variant="body" color={theme.colors.textPrimary}>
              Clear Recent Poses
            </AppText>
            <AppText variant="small" color={theme.colors.textSecondary}>
              {recentCount > 0 ? `${recentCount} pose(s) in history` : 'No recents stored'}
            </AppText>
          </View>
          <IconSymbol
            name="chevron-right"
            size={20}
            color={theme.colors.textDisabled}
          />
        </Pressable>

        {/* Theme Mode Switcher Embedded */}
        <View
          style={[
            styles.themeTile,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
            },
          ]}
        >
          <View style={styles.themeHeader}>
            <View
              style={[
                styles.tileIconWrap,
                { backgroundColor: theme.colors.primaryLight },
              ]}
            >
              <IconSymbol
                name="palette-outline"
                size={22}
                color={theme.colors.primary}
              />
            </View>
            <View style={styles.tileBody}>
              <AppText variant="body" color={theme.colors.textPrimary}>
                Appearance
              </AppText>
              <AppText variant="small" color={theme.colors.textSecondary}>
                Light, Dark or System theme
              </AppText>
            </View>
          </View>
          <View style={styles.themeSwitcherWrap}>
            <ThemeModeSwitcher />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: {
    marginBottom: spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  tilesContainer: {
    gap: spacing.sm,
  },
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
    minHeight: 64,
  },
  tileIconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tileBody: {
    flex: 1,
    gap: 2,
  },
  themeTile: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
  },
  themeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  themeSwitcherWrap: {
    paddingTop: spacing.xs,
  },
});
