/**
 * Unit 19 — useProfileStats hook.
 * Aggregates statistics from favorites, gallery, and recent poses stores.
 */
import { useCallback, useEffect, useMemo } from 'react';
import { useFavoritesStore } from '@/features/favorites/data/favoritesStore';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';
import { useGalleryPhotos } from '@/features/gallery/presentation/hooks/useGallery';
import { errorHandler, type AppError } from '@/core/error/errorHandler';

export interface ProfileStats {
  readonly favoritesCount: number;
  readonly photosCount: number;
  readonly posesUsedCount: number;
  /** Unit 23: pending drives the shimmer state (no blank stats row). */
  readonly isPending: boolean;
  readonly isError: boolean;
  readonly error: AppError | null;
  readonly retry: () => void;
}

export function useProfileStats(): ProfileStats {
  const favoriteIds = useFavoritesStore((state) => state.favoriteIds);
  const recentEntries = useRecentPosesStore((state) => state.entries);
  const photosQuery = useGalleryPhotos();
  const error = useMemo(
    () => photosQuery.isError ? errorHandler.mapError(photosQuery.error) : null,
    [photosQuery.error, photosQuery.isError],
  );

  useEffect(() => {
    if (photosQuery.isError) {
      errorHandler.handle(photosQuery.error, 'Profile/Stats');
    }
  }, [photosQuery.error, photosQuery.isError]);

  const retry = useCallback(() => {
    void photosQuery.refetch();
  }, [photosQuery.refetch]);

  return useMemo(() => ({
    favoritesCount: favoriteIds.length,
    photosCount: photosQuery.data?.length ?? 0,
    posesUsedCount: recentEntries.length,
    isPending: photosQuery.isPending,
    isError: photosQuery.isError,
    error,
    retry,
  }), [
    error,
    favoriteIds.length,
    photosQuery.data?.length,
    photosQuery.isPending,
    photosQuery.isError,
    recentEntries.length,
    retry,
  ]);
}
