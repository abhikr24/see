/**
 * Unit 19 — ProfileScreen.
 * Complete Profile Tab: Avatar, statistics, favorites grid, storage controls,
 * display name editing, guest CTA, live appearance switcher, and sign-out flow.
 */
import React, { useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { mediaColors, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useAuthStore } from '@/shared/stores/authStore';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { ScreenHeader } from '@/shared/components/ScreenHeader';
import { showSuccessSnackBar } from '@/shared/stores/snackBarStore';
import { ErrorRetryWidget } from '@/shared/components/ErrorRetryWidget';
import { ShimmerStats } from '@/shared/components/ShimmerSkeleton';
import { errorHandler } from '@/core/error/errorHandler';
import { useProfileStats } from '../hooks/useProfileStats';
import { ProfileHeader } from '../components/ProfileHeader';
import { EditDisplayNameModal } from '../components/EditDisplayNameModal';
import { StatsRow } from '../components/StatsRow';
import { GuestLoginCTA } from '../components/GuestLoginCTA';
import { FavoritesSection } from '../components/FavoritesSection';
import { StorageSection } from '../components/StorageSection';
import { SettingsShortcut } from '../components/SettingsShortcut';
import { AccountDangerSection } from '../components/AccountDangerSection';

export function ProfileScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const user = useAuthStore((s) => s.session);
  const authStatus = useAuthStore((s) => s.status);
  const updateDisplayName = useAuthStore((s) => s.updateDisplayName);
  const signOut = useAuthStore((s) => s.signOut);
  const stats = useProfileStats();

  const [editModalVisible, setEditModalVisible] = useState(false);

  const handleSaveName = async (newName: string): Promise<boolean> => {
    const success = await updateDisplayName(newName);
    if (success) {
      showSuccessSnackBar('Display name updated');
    }
    return success;
  };

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out?',
      'You can sign back in anytime to access your synced favorites and photos.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut();
              showSuccessSnackBar('Signed out successfully');
              router.replace('/(tabs)/explore');
            } catch (error) {
              const appError = errorHandler.handle(error, 'Profile/SignOut');
              Alert.alert('Could not sign out', appError.message);
            }
          },
        },
      ],
    );
  };

  const isAuthenticated = user !== null;

  if (stats.isError) {
    return (
      <SafeAreaView
        edges={['top']}
        style={[styles.safeRoot, { backgroundColor: theme.colors.backgroundSecondary }]}
      >
        <ScreenHeader title="Profile" />
        <ErrorRetryWidget
          title="Could not load profile statistics"
          message={stats.error?.message ?? 'Local statistics could not be prepared.'}
          onRetry={stats.retry}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView
      edges={['top']}
      style={[
        styles.safeRoot,
        { backgroundColor: theme.colors.backgroundSecondary },
      ]}
    >
      <ScreenHeader title="Profile" />

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Card / Header */}
        <ProfileHeader
          user={user}
          isLoading={authStatus === 'initializing'}
          onEditName={() => setEditModalVisible(true)}
        />

        {/* 3-Column Statistics Row — Unit 23 shimmer while local stats load */}
        {stats.isPending ? (
          <View
            style={[
              styles.statsShimmerCard,
              {
                backgroundColor: theme.colors.surface,
                borderColor: theme.colors.divider,
              },
            ]}
          >
            <ShimmerStats count={3} />
          </View>
        ) : (
          <StatsRow stats={stats} />
        )}

        {/* Guest CTA if not signed in */}
        {!isAuthenticated && <GuestLoginCTA />}

        {/* Favorites Section */}
        <FavoritesSection />

        {/* Storage & Appearance Management */}
        <StorageSection />

        {/* Settings Shortcut */}
        <SettingsShortcut />

        {/* Danger Zone (B1): account deletion entry — account-scoped users
            only; guests have no account surface here at all. */}
        {isAuthenticated && <AccountDangerSection />}

        {/* Sign Out Button (Authenticated only) */}
        {isAuthenticated && (
          <View style={styles.logoutContainer}>
            <Pressable
              onPress={handleSignOut}
              accessibilityRole="button"
              accessibilityLabel="Sign out of your account"
              style={({ pressed }) => [
                styles.logoutButton,
                {
                  borderColor: theme.colors.error,
                  backgroundColor: theme.colors.surface,
                  opacity: pressed ? 0.75 : 1,
                },
              ]}
            >
              <IconSymbol
                name="logout"
                size={20}
                color={theme.colors.error}
              />
              <AppText
                variant="body"
                color={theme.colors.error}
                style={styles.logoutText}
              >
                Sign Out
              </AppText>
            </Pressable>
          </View>
        )}

        {/* Version footer */}
        <View style={styles.footer}>
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
          >
            Smart Photography Assistant · v1.0.0
          </AppText>
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
          >
            Photos stored locally on this device only
          </AppText>
        </View>
      </ScrollView>

      {/* Edit Display Name Modal */}
      <EditDisplayNameModal
        visible={editModalVisible}
        currentName={user?.displayName || ''}
        onSave={handleSaveName}
        onClose={() => setEditModalVisible(false)}
      />

      {/* Unit 23: success feedback rides the single global snackbar host */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeRoot: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl * 2,
  },
  statsShimmerCard: {
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.lg,
    overflow: 'hidden',
  },
  logoutContainer: {
    marginBottom: spacing.xl,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    height: 52,
    borderRadius: radius.lg,
    borderWidth: 1.5,
  },
  logoutText: {
    fontWeight: '600',
  },
  footer: {
    alignItems: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.md,
  },
});
