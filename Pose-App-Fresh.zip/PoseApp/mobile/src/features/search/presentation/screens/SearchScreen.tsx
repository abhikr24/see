/**
 * Unit 09 - dedicated pose search and filters surface.
 * Reuses the Explore controller, query engine, cards and detail sheet so
 * results cannot drift between routes.
 */
import React, { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { useExploreController } from '@/features/explore/presentation/hooks/useExploreController';
import {
  ExploreSearchBar,
  RecentSearchesTray,
} from '@/features/explore/presentation/components/ExploreSearchBar';
import {
  CategoryFilterChips,
  DifficultyFilterChips,
} from '@/features/explore/presentation/components/CategoryFilterChips';
import { usePaginatedPoses } from '@/features/explore/presentation/hooks/usePaginatedPoses';
import { PoseGrid } from '@/features/explore/presentation/components/PoseGrid';
import { PoseDetailSheet } from '@/features/explore/presentation/components/PoseDetailSheet';
import { ShimmerGrid } from '@/shared/components/ShimmerSkeleton';

export function SearchScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const controller = useExploreController();
  const [focused, setFocused] = useState(true);
  const showHistory = focused && controller.filters.query.trim().length === 0;
  const paginated = usePaginatedPoses(controller.results, 20);

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <View style={styles.header}>
        <Pressable
          onPress={() => (router.canGoBack() ? router.back() : router.replace('/(tabs)/explore'))}
          accessibilityRole="button"
          accessibilityLabel="Back to Explore"
          style={styles.back}
        >
          <IconSymbol name="chevron-left" size={22} color={theme.colors.textPrimary} />
        </Pressable>
        <AppText variant="heading" color={theme.colors.textPrimary}>
          Search Poses
        </AppText>
        <View style={styles.headerBalance} />
      </View>

      <ExploreSearchBar
        value={controller.filters.query}
        onChangeText={controller.setQuery}
        onCommit={controller.commitQuery}
        onFocusChange={setFocused}
        autoFocus
      />
      {showHistory && (
        <RecentSearchesTray
          history={controller.searchHistory}
          onSelect={controller.applyHistoryEntry}
          onClear={controller.clearHistory}
        />
      )}

      <CategoryFilterChips
        active={controller.filters.category}
        onChange={controller.setCategory}
      />
      <DifficultyFilterChips
        active={controller.filters.difficulty}
        onChange={controller.setDifficulty}
      />
      <AppText variant="small" color={theme.colors.textSecondary} style={styles.count}>
        {controller.resultTotal} result{controller.resultTotal === 1 ? '' : 's'}
      </AppText>

      {/* Unit 23: Shimmer loading while query settles + spec empty state */}
      {controller.isSearching ? (
        <ShimmerGrid columns={2} count={6} />
      ) : (
        <PoseGrid
          poses={paginated.poses}
          onOpenPose={controller.openPose}
          onClearFilters={controller.resetFilters}
          isFavoritesFilter={controller.filters.category === 'favorites'}
          onEndReached={paginated.loadMore}
          isLoadingMore={paginated.isLoadingMore}
          emptyOverrides={
            controller.filters.query.trim().length > 0
              ? {
                  icon: 'magnify-off',
                  title: `No results for “${controller.filters.query.trim()}”`,
                  description:
                    'Try a shorter word, a different category, or clear the search to see everything.',
                  buttonText: 'Clear Search',
                }
              : undefined
          }
          footerNote={
            paginated.hasMore
              ? `Showing ${paginated.poses.length} of ${controller.resultTotal} — scroll to load more`
              : null
          }
        />
      )}

      <PoseDetailSheet
        pose={controller.focusedPose}
        isAuthenticated={controller.isAuthenticated}
        onClose={controller.closePose}
        onUseThisPose={controller.useThisPose}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  header: {
    minHeight: 56,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.sm,
  },
  back: {
    width: 48,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerBalance: {
    width: 48,
  },
  count: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
  },
});
