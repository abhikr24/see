/**
 * Unit 20 — SettingsRadioModal.
 * Modal picker for discrete camera/capture settings (Flash, Timer, Filter, Threshold, etc.).
 */
import React from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import { mediaColors, radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

export interface RadioOption<T> {
  readonly value: T;
  readonly label: string;
}

interface SettingsRadioModalProps<T> {
  readonly visible: boolean;
  readonly title: string;
  readonly subtitle?: string;
  readonly icon: string;
  readonly options: readonly RadioOption<T>[];
  readonly selectedValue: T;
  readonly onSelect: (value: T) => void;
  readonly onClose: () => void;
}

export function SettingsRadioModal<T extends string | number>({
  visible,
  title,
  subtitle,
  icon,
  options,
  selectedValue,
  onSelect,
  onClose,
}: SettingsRadioModalProps<T>) {
  const theme = useAppTheme();

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.scrim}>
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={onClose}
          accessibilityLabel="Close selection modal"
        />

        <View
          style={[
            styles.card,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
            },
          ]}
        >
          {/* Modal Header */}
          <View style={styles.header}>
            <View
              style={[
                styles.iconWrap,
                { backgroundColor: theme.colors.primaryLight },
              ]}
            >
              <IconSymbol name={icon} size={22} color={theme.colors.primary} />
            </View>
            <View style={styles.headerText}>
              <AppText variant="cardTitle" color={theme.colors.textPrimary}>
                {title}
              </AppText>
              {subtitle !== undefined && (
                <AppText variant="small" color={theme.colors.textSecondary}>
                  {subtitle}
                </AppText>
              )}
            </View>
          </View>

          {/* Options List */}
          <ScrollView style={styles.optionsList} bounces={false}>
            {options.map((option, index) => {
              const isSelected = option.value === selectedValue;
              return (
                <Pressable
                  key={String(option.value)}
                  onPress={() => {
                    onSelect(option.value);
                    onClose();
                  }}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: isSelected }}
                  accessibilityLabel={option.label}
                  style={({ pressed }) => [
                    styles.optionRow,
                    {
                      borderTopColor: theme.colors.divider,
                      borderTopWidth: index > 0 ? 1 : 0,
                      backgroundColor: isSelected
                        ? theme.colors.primaryLight
                        : pressed
                        ? theme.colors.backgroundSecondary
                        : 'transparent',
                    },
                  ]}
                >
                  <AppText
                    variant="body"
                    color={
                      isSelected
                        ? theme.colors.primary
                        : theme.colors.textPrimary
                    }
                    style={[
                      styles.optionLabel,
                      isSelected ? styles.optionLabelSelected : null,
                    ]}
                  >
                    {option.label}
                  </AppText>

                  {isSelected && (
                    <IconSymbol
                      name="check-circle"
                      size={20}
                      color={theme.colors.primary}
                    />
                  )}
                </Pressable>
              );
            })}
          </ScrollView>

          {/* Cancel Button */}
          <Pressable
            onPress={onClose}
            accessibilityRole="button"
            accessibilityLabel="Cancel selection"
            style={({ pressed }) => [
              styles.cancelBtn,
              {
                backgroundColor: theme.colors.backgroundSecondary,
                opacity: pressed ? 0.75 : 1,
              },
            ]}
          >
            <AppText
              variant="body"
              color={theme.colors.textSecondary}
              style={styles.cancelText}
            >
              Cancel
            </AppText>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  scrim: {
    flex: 1,
    backgroundColor: mediaColors.overlayHeavy,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  card: {
    width: '100%',
    maxWidth: 360,
    borderRadius: radius.xl,
    borderWidth: 1,
    padding: spacing.lg,
    gap: spacing.md,
    zIndex: 10,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    flex: 1,
    gap: 2,
  },
  optionsList: {
    maxHeight: 280,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.md,
    minHeight: sizing.touchTarget,
  },
  optionLabel: {
    flex: 1,
  },
  optionLabelSelected: {
    fontWeight: '700',
  },
  cancelBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 48,
    borderRadius: radius.lg,
    marginTop: spacing.xs,
  },
  cancelText: {
    fontWeight: '600',
  },
});
