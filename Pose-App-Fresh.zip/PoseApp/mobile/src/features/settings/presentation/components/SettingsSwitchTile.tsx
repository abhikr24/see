/**
 * Unit 20 — SettingsSwitchTile.
 * Preference row with an accessible toggle switch for binary preferences.
 */
import React from 'react';
import { Platform, StyleSheet, Switch, View } from 'react-native';
import { radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface SettingsSwitchTileProps {
  readonly icon: string;
  readonly title: string;
  readonly description: string;
  readonly value: boolean;
  readonly onToggle: (next: boolean) => void;
}

export function SettingsSwitchTile({
  icon,
  title,
  description,
  value,
  onToggle,
}: SettingsSwitchTileProps) {
  const theme = useAppTheme();

  return (
    <View
      style={[
        styles.tile,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
        },
      ]}
    >
      <View
        style={[
          styles.iconWrap,
          { backgroundColor: theme.colors.primaryLight },
        ]}
      >
        <IconSymbol name={icon} size={22} color={theme.colors.primary} />
      </View>

      <View style={styles.content}>
        <AppText variant="body" color={theme.colors.textPrimary}>
          {title}
        </AppText>
        <AppText variant="small" color={theme.colors.textSecondary}>
          {description}
        </AppText>
      </View>

      <Switch
        value={value}
        onValueChange={onToggle}
        trackColor={{
          false: theme.colors.divider,
          true: theme.colors.primary,
        }}
        thumbColor={
          Platform.OS === 'android'
            ? value
              ? theme.colors.textOnPrimary
              : theme.colors.backgroundSecondary
            : undefined
        }
        ios_backgroundColor={theme.colors.divider}
        accessibilityRole="switch"
        accessibilityLabel={`${title}, currently ${value ? 'enabled' : 'disabled'}`}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
    minHeight: sizing.touchTarget + spacing.md,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    gap: 2,
  },
});
