/**
 * Unit 20 — SettingsTile.
 * Interactive preference row displaying icon, title, current value badge, and chevron.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface SettingsTileProps {
  readonly icon: string;
  readonly title: string;
  readonly value: string;
  readonly onPress: () => void;
  readonly description?: string;
}

export function SettingsTile({
  icon,
  title,
  value,
  onPress,
  description,
}: SettingsTileProps) {
  const theme = useAppTheme();

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${title}, currently set to ${value}`}
      style={({ pressed }) => [
        styles.tile,
        {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.divider,
          opacity: pressed ? 0.75 : 1,
        },
      ]}
    >
      <View
        style={[
          styles.iconWrap,
          { backgroundColor: theme.colors.primaryLight },
        ]}
      >
        <IconSymbol name={icon} size={22} color={theme.colors.primary} />
      </View>

      <View style={styles.content}>
        <AppText variant="body" color={theme.colors.textPrimary}>
          {title}
        </AppText>
        {description !== undefined && (
          <AppText variant="small" color={theme.colors.textSecondary}>
            {description}
          </AppText>
        )}
      </View>

      <View style={styles.trailing}>
        <View
          style={[
            styles.valueBadge,
            { backgroundColor: theme.colors.backgroundSecondary },
          ]}
        >
          <AppText
            variant="small"
            color={theme.colors.primary}
            style={styles.valueText}
          >
            {value}
          </AppText>
        </View>
        <IconSymbol
          name="chevron-right"
          size={18}
          color={theme.colors.textDisabled}
        />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
    minHeight: sizing.touchTarget + spacing.md,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    gap: 2,
  },
  trailing: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  valueBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
  },
  valueText: {
    fontWeight: '600',
  },
});
