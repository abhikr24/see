/**
 * Unit 21 — SystemSettingTile.
 * Row used by the System settings section: theme, language, legal pages,
 * about, rate app and the destructive clear-all-data action.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { radius, sizing, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';

interface SystemSettingTileProps {
  readonly icon: string;
  readonly title: string;
  readonly description?: string;
  /** Trailing value label, e.g. "System" or "v1.0.0". */
  readonly value?: string;
  readonly onPress: () => void;
  /** Renders the row in the destructive error style (Clear All Data). */
  readonly destructive?: boolean;
  readonly boldTitle?: boolean;
}

export function SystemSettingTile({
  icon,
  title,
  description,
  value,
  onPress,
  destructive = false,
  boldTitle = false,
}: SystemSettingTileProps) {
  const theme = useAppTheme();

  const iconColor = destructive ? theme.colors.error : theme.colors.primary;
  const titleColor = destructive ? theme.colors.error : theme.colors.textPrimary;

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={
        description !== undefined ? `${title}. ${description}` : title
      }
      style={({ pressed }) => [
        styles.tile,
        {
          backgroundColor: theme.colors.surface,
          borderColor: destructive ? theme.colors.error : theme.colors.divider,
          opacity: pressed ? 0.75 : 1,
        },
      ]}
    >
      <View
        style={[
          styles.iconWrap,
          {
            backgroundColor: destructive
              ? `${theme.colors.error}1A`
              : theme.colors.primaryLight,
          },
        ]}
      >
        <IconSymbol name={icon} size={22} color={iconColor} />
      </View>

      <View style={styles.content}>
        <AppText
          variant="body"
          color={titleColor}
          style={boldTitle || destructive ? styles.boldTitle : undefined}
        >
          {title}
        </AppText>
        {description !== undefined && (
          <AppText variant="small" color={theme.colors.textSecondary}>
            {description}
          </AppText>
        )}
      </View>

      <View style={styles.trailing}>
        {value !== undefined && (
          <View
            style={[
              styles.valueBadge,
              { backgroundColor: theme.colors.backgroundSecondary },
            ]}
          >
            <AppText
              variant="small"
              color={theme.colors.primary}
              style={styles.valueText}
            >
              {value}
            </AppText>
          </View>
        )}
        <IconSymbol
          name="chevron-right"
          size={18}
          color={theme.colors.textDisabled}
        />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
    minHeight: sizing.touchTarget + spacing.md,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    gap: 2,
  },
  trailing: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  valueBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.pill,
  },
  valueText: {
    fontWeight: '600',
  },
  boldTitle: {
    fontWeight: '700',
  },
});
