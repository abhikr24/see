/**
 * Unit 21 — SettingsInfoScreen.
 * Shared renderer for the Privacy Policy, Terms of Service and About pages.
 * Scrollable, token-driven and reachable at /settings/{privacy|terms|about}.
 */
import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  APP_NAME,
  APP_SHORT_NAME,
  APP_VERSION,
  radius,
  spacing,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { ScreenHeader } from '@/shared/components/ScreenHeader';

export type SettingsInfoPage = 'privacy' | 'terms' | 'about';

const PRIVACY_PARAGRAPHS: readonly string[] = [
  `${APP_SHORT_NAME} is built with privacy as a first principle. This page explains exactly what happens to your data.`,
  'Photos never leave your device. Every photo you capture is written straight to your device gallery through the system photo library. Nothing is uploaded, transmitted, or stored on any server we control.',
  'Pose detection runs entirely on-device. MediaPipe pose tracking executes locally on your phone processor. No camera frame, landmark coordinate, or body measurement ever leaves the phone.',
  'Metadata-only sync. When you connect a Supabase account, only non-sensitive metadata syncs — your email address, display name, and the identifiers of poses you marked as favorites. Row Level Security ensures only your own account can read that row.',
  'No tracking or analytics. The app ships with no third-party analytics SDKs, no advertising identifiers, and no behavioural tracking of any kind.',
  'Local storage only. Your pose history, search history, capture preferences, and gallery metadata live in fast local storage on this device. You can clear all of it at any time from Settings.',
  'Permissions are requested lazily. Camera access is asked for only when you actually enter an active capture session, and the session is fully released the moment you leave it. Gallery permission is requested only when you save a photo.',
];

const TERMS_PARAGRAPHS: readonly string[] = [
  `By using ${APP_NAME} (${APP_SHORT_NAME}) you agree to the following terms.`,
  'Licence. You receive a personal, non-transferable licence to use the application for its intended purpose: guided photography posing assistance.',
  'Your content. All photographs you capture remain entirely your property and your responsibility. The app makes no claim on your images and cannot recover them once you delete them from your device.',
  'Acceptable use. You agree not to use the app to create content that is unlawful, harmful, or that infringes the rights of others, and not to attempt to reverse engineer, circumvent, or disrupt the on-device pose-detection engine.',
  'No warranty. The application is provided "as is" without warranty of any kind. Pose guidance is assistive, not professional photography instruction; results depend on device capability, lighting, and framing.',
  'Limitation of liability. To the maximum extent permitted by law, the developers are not liable for any indirect, incidental, or consequential damages arising from use of the application.',
  'Changes. These terms may be updated as the application evolves. Continued use after an update constitutes acceptance of the revised terms.',
];

const ABOUT_PARAGRAPHS: readonly string[] = [
  `${APP_SHORT_NAME} is an AI-guided posing coach for photographers and subjects.`,
  'Choose from a curated library of 400 reference poses across 12 categories. On-device pose tracking draws a live skeleton over your viewfinder, computes a real-time match percentage against the reference pose, and tells you exactly which joint to adjust until you lock the pose.',
  'Capture manually with the shutter, hands-free by holding an open palm to the camera, or automatically when your match percentage holds steady.',
];

interface SettingsInfoScreenProps {
  readonly page: SettingsInfoPage;
}

export function SettingsInfoScreen({ page }: SettingsInfoScreenProps) {
  const theme = useAppTheme();
  const router = useRouter();

  const meta = {
    privacy: { title: 'Privacy Policy', icon: 'shield-check-outline' },
    terms: { title: 'Terms of Service', icon: 'file-document-outline' },
    about: { title: 'About', icon: 'information-outline' },
  }[page];

  const paragraphs =
    page === 'privacy'
      ? PRIVACY_PARAGRAPHS
      : page === 'terms'
      ? TERMS_PARAGRAPHS
      : ABOUT_PARAGRAPHS;

  return (
    <SafeAreaView
      edges={['top']}
      style={[
        styles.safeRoot,
        { backgroundColor: theme.colors.backgroundSecondary },
      ]}
    >
      <ScreenHeader title={meta.title} onBack={() => router.back()} />

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {page === 'about' && (
          <View
            style={[
              styles.aboutCard,
              {
                backgroundColor: theme.colors.surface,
                borderColor: theme.colors.divider,
              },
            ]}
          >
            <View
              style={[
                styles.aboutIconWrap,
                { backgroundColor: theme.colors.primaryLight },
              ]}
            >
              <IconSymbol
                name="camera"
                size={48}
                color={theme.colors.primary}
              />
            </View>
            <AppText
              variant="heading"
              color={theme.colors.textPrimary}
              style={styles.aboutTitle}
            >
              Perfect Poses
            </AppText>
            <AppText
              variant="secondaryBody"
              color={theme.colors.textSecondary}
            >
              Version {APP_VERSION} (Build 1)
            </AppText>
          </View>
        )}

        <View
          style={[
            styles.bodyCard,
            {
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.divider,
            },
          ]}
        >
          {paragraphs.map((paragraph, index) => (
            <AppText
              key={index}
              variant="secondaryBody"
              color={theme.colors.textSecondary}
              style={styles.paragraph}
            >
              {paragraph}
            </AppText>
          ))}
        </View>

        <View style={styles.footer}>
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
          >
            {APP_NAME} · v{APP_VERSION}
          </AppText>
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
          >
            Photos stay on your device — always
          </AppText>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeRoot: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl * 2,
  },
  aboutCard: {
    alignItems: 'center',
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.xl,
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  aboutIconWrap: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  aboutTitle: {
    fontWeight: '700',
  },
  bodyCard: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.lg,
    gap: spacing.md,
  },
  paragraph: {
    lineHeight: 24,
  },
  footer: {
    alignItems: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.xl,
  },
});
