/**
 * Units 20 + 21 — SettingsScreen.
 * Unit 20: Camera defaults + intelligent capture preferences + reset.
 * Unit 21: System section — theme, language, privacy, terms, about, rate app
 *          and the destructive Clear All Data action.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import {
  APP_NAME,
  APP_VERSION,
  AUTOMATIC_VOICE_ID,
  AUTO_THRESHOLD_OPTIONS,
  COUNTDOWN_OPTIONS,
  FILTER_OPTIONS,
  FLASH_OPTIONS,
  TIMER_OPTIONS,
  INSTRUCTION_LANGUAGE_OPTIONS,
  radius,
  spacing,
  type AutoThreshold,
  type CountdownDuration,
  type FilterDefault,
  type FlashDefault,
  type ThemeMode,
  type InstructionLanguage,
  type TimerDefault,
  type VoiceOption,
} from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { ttsService } from '@/core/voice/ttsService';
import { useSettingsStore } from '@/shared/stores/settingsStore';
import { useThemeStore } from '@/shared/stores/themeStore';
import { useAuthStore } from '@/shared/stores/authStore';
import { useFavoritesStore } from '@/features/favorites/data/favoritesStore';
import { useRecentPosesStore } from '@/features/poses/data/recentPosesStore';
import { queryClient } from '@/core/network/queryClient';
import { galleryLocalDatasource } from '@/features/gallery/data/datasources/galleryLocalDatasource';
import { AppLogger } from '@/core/utils/logger';
import { errorHandler } from '@/core/error/errorHandler';
import { AppText } from '@/shared/components/AppText';
import { IconSymbol } from '@/shared/components/IconSymbol';
import { ScreenHeader } from '@/shared/components/ScreenHeader';
import { showSuccessSnackBar } from '@/shared/stores/snackBarStore';
import { ShimmerTiles } from '@/shared/components/ShimmerSkeleton';
import { useStoreHydrated } from '@/shared/hooks/useStoreHydrated';
import { SettingsTile } from '../components/SettingsTile';
import { SettingsSwitchTile } from '../components/SettingsSwitchTile';
import { SystemSettingTile } from '../components/SystemSettingTile';
import { SettingsRadioModal } from '../components/SettingsRadioModal';

type ActiveModal =
  | 'flash'
  | 'timer'
  | 'filter'
  | 'autoThreshold'
  | 'countdown'
  | 'theme'
  | 'instructionLanguage'
  | 'voice'
  | null;

const THEME_OPTIONS: readonly { readonly value: ThemeMode; readonly label: string }[] = [
  { value: 'system', label: 'System Default' },
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
];

export function SettingsScreen() {
  const theme = useAppTheme();
  const router = useRouter();
  const hydrated = useStoreHydrated(useSettingsStore);

  const flashDefault = useSettingsStore((s) => s.flashDefault);
  const timerDefault = useSettingsStore((s) => s.timerDefault);
  const filterDefault = useSettingsStore((s) => s.filterDefault);
  const gridOverlayEnabled = useSettingsStore((s) => s.gridOverlayEnabled);
  const autoThreshold = useSettingsStore((s) => s.autoThreshold);
  const voiceEnabled = useSettingsStore((s) => s.voiceEnabled);
  const gestureEnabled = useSettingsStore((s) => s.gestureEnabled);
  const countdownDuration = useSettingsStore((s) => s.countdownDuration);
  const hapticEnabled = useSettingsStore((s) => s.hapticEnabled);
  const volumeShutterEnabled = useSettingsStore((s) => s.volumeShutterEnabled);
  const toggleVolumeShutter = useSettingsStore((s) => s.toggleVolumeShutter);

  const setFlashDefault = useSettingsStore((s) => s.setFlashDefault);
  const setTimerDefault = useSettingsStore((s) => s.setTimerDefault);
  const setFilterDefault = useSettingsStore((s) => s.setFilterDefault);
  const toggleGridOverlay = useSettingsStore((s) => s.toggleGridOverlay);
  const setAutoThreshold = useSettingsStore((s) => s.setAutoThreshold);
  const toggleVoice = useSettingsStore((s) => s.toggleVoice);
  const toggleGesture = useSettingsStore((s) => s.toggleGesture);
  const setCountdownDuration = useSettingsStore((s) => s.setCountdownDuration);
  const toggleHaptic = useSettingsStore((s) => s.toggleHaptic);
  const instructionLanguage = useSettingsStore((s) => s.instructionLanguage);
  const setInstructionLanguage = useSettingsStore((s) => s.setInstructionLanguage);
  const voiceIds = useSettingsStore((s) => s.voiceIds);
  const setVoiceId = useSettingsStore((s) => s.setVoiceId);
  const resetToDefaults = useSettingsStore((s) => s.resetToDefaults);

  const [activeModal, setActiveModal] = useState<ActiveModal>(null);

  /**
   * Unit 35 (Part 4.4) — the picker lists ONLY what the runtime reported for
   * the selected language (`Speech.getAvailableVoicesAsync()` → shared
   * ranking). A device with no Hindi pack therefore shows just "Automatic",
   * which is the honest answer; no voice is ever invented here.
   */
  const [voiceOptions, setVoiceOptions] = useState<readonly VoiceOption[]>([
    { value: AUTOMATIC_VOICE_ID, label: 'Automatic (recommended)' },
  ]);

  useEffect(() => {
    let cancelled = false;
    void ttsService.voiceOptions(instructionLanguage).then((options) => {
      if (!cancelled) setVoiceOptions(options);
    });
    return () => {
      cancelled = true;
    };
  }, [instructionLanguage]);

  const selectedVoiceId = voiceIds[instructionLanguage] ?? AUTOMATIC_VOICE_ID;
  const instructionLanguageLabel =
    INSTRUCTION_LANGUAGE_OPTIONS.find(
      (option) => option.value === instructionLanguage,
    )?.label ?? INSTRUCTION_LANGUAGE_OPTIONS[0]!.label;

  const selectedVoiceOption = voiceOptions.find(
    (option) => option.value === selectedVoiceId,
  );
  /* A remembered voice the device no longer reports is stated plainly
     instead of being displayed as if it were in use. */
  const voiceTileValue =
    selectedVoiceId === AUTOMATIC_VOICE_ID
      ? 'Automatic'
      : selectedVoiceOption?.label ?? 'Unavailable — using automatic';

  /** Unit 23: all settings feedback rides the global snackbar (primary = settings). */
  const showToast = (message: string) => {
    showSuccessSnackBar(message, { variant: 'primary' });
  };

  // ── Unit 21: system-level state ──────────────────────────────────────
  const themeMode = useThemeStore((s) => s.themeMode);
  const setThemeMode = useThemeStore((s) => s.setThemeMode);
  const userId = useAuthStore((s) => s.session?.id ?? null);

  const handleReset = () => {
    Alert.alert(
      'Reset Settings?',
      'Restore all camera and capture preferences to their default values.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset to Defaults',
          style: 'destructive',
          onPress: () => {
            resetToDefaults();
            showToast('Settings restored to defaults');
          },
        },
      ],
    );
  };

  /**
   * Unit 21 — Clear All Data.
   * Clears favorites, pose recents, gallery metadata and settings, while the
   * onboarding/first-launch flags are deliberately preserved so the user is
   * not forced back through the intro flow. Device gallery photos are the
   * user's own files and are never touched.
   */
  const handleClearAllData = () => {
    Alert.alert(
      'Clear all data?',
      'This deletes favorites, recent poses, gallery metadata and settings. This cannot be undone. Photos already saved to your device gallery remain untouched. Onboarding is preserved.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All Data',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                useFavoritesStore.getState().clearLocal();
                useRecentPosesStore.getState().clear();
                if (userId !== null) {
                  await galleryLocalDatasource.deleteAllPhotos(userId);
                }
                resetToDefaults();
                queryClient.removeQueries({ queryKey: ['gallery'] });
                AppLogger.warn('[Settings] all app data cleared (onboarding flags preserved)');
                showToast('All data cleared');
              } catch (error) {
                errorHandler.handle(error, 'Settings/ClearAllData');
                showToast('Could not clear all data');
              }
            })();
          },
        },
      ],
    );
  };

  const currentFlashLabel =
    FLASH_OPTIONS.find((o) => o.value === flashDefault)?.label ?? 'Off';
  const currentTimerLabel =
    timerDefault === 0 ? 'Off' : `${timerDefault}s`;
  const currentFilterLabel =
    FILTER_OPTIONS.find((o) => o.value === filterDefault)?.label ?? 'Original';
  const currentThresholdLabel = `${autoThreshold}%`;
  const currentCountdownLabel = `${countdownDuration}s`;

  return (
    <SafeAreaView
      edges={['top']}
      style={[
        styles.safeRoot,
        { backgroundColor: theme.colors.backgroundSecondary },
      ]}
    >
      <ScreenHeader
        title="Settings"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {!hydrated ? (
          <ShimmerTiles count={6} />
        ) : (
          <>
        {/* Camera Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <IconSymbol
              name="camera-outline"
              size={20}
              color={theme.colors.primary}
            />
            <AppText variant="cardTitle" color={theme.colors.textPrimary}>
              Camera Preferences
            </AppText>
          </View>

          <View style={styles.tilesStack}>
            <SettingsTile
              icon="flash-outline"
              title="Flash Default"
              description="Initial flash setting when opening camera"
              value={currentFlashLabel}
              onPress={() => setActiveModal('flash')}
            />

            <SettingsTile
              icon="timer-outline"
              title="Timer Default"
              description="Default countdown timer for shutter"
              value={currentTimerLabel}
              onPress={() => setActiveModal('timer')}
            />

            <SettingsTile
              icon="image-filter-vintage"
              title="Filter Default"
              description="Initial photo color tone"
              value={currentFilterLabel}
              onPress={() => setActiveModal('filter')}
            />

            <SettingsSwitchTile
              icon="grid"
              title="Grid Overlay"
              description="Show 3x3 rule-of-thirds composition lines"
              value={gridOverlayEnabled}
              onToggle={toggleGridOverlay}
            />
          </View>
        </View>

        {/* Capture Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <IconSymbol
              name="auto-fix"
              size={20}
              color={theme.colors.primary}
            />
            <AppText variant="cardTitle" color={theme.colors.textPrimary}>
              Intelligent Capture
            </AppText>
          </View>

          <View style={styles.tilesStack}>
            <SettingsTile
              icon="target"
              title="Auto-capture Threshold"
              description="Required pose match percentage to fire shutter"
              value={currentThresholdLabel}
              onPress={() => setActiveModal('autoThreshold')}
            />

            <SettingsSwitchTile
              icon="volume-high"
              title="Voice Guidance"
              description="Spoken posture directions (debounced 3s)"
              value={voiceEnabled}
              onToggle={toggleVoice}
            />

            <SettingsSwitchTile
              icon="hand-back-right-outline"
              title="Gesture Capture"
              description="Hold an open palm to trigger the countdown"
              value={gestureEnabled}
              onToggle={toggleGesture}
            />

            {/* FINAL INTEGRATION PASS — the Unit 38 volume-key shutter gets
                the settings surface it shipped without. Copy is honest about
                scope: the keys are intercepted only while the live viewfinder
                is on screen. */}
            <SettingsSwitchTile
              icon="cellphone-key"
              title="Volume Key Shutter"
              description="Take a photo with the volume keys while the camera is open"
              value={volumeShutterEnabled}
              onToggle={toggleVolumeShutter}
            />

            <SettingsTile
              icon="timer-sand"
              title="Countdown Duration"
              description="Intelligent capture countdown duration"
              value={currentCountdownLabel}
              onPress={() => setActiveModal('countdown')}
            />

            <SettingsSwitchTile
              icon="vibrate"
              title="Haptic Feedback"
              description="Vibrations on shutter press & countdown ticks"
              value={hapticEnabled}
              onToggle={toggleHaptic}
            />
          </View>
        </View>

        {/* ── Unit 21: System Section ── */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <IconSymbol
              name="tune-vertical"
              size={20}
              color={theme.colors.primary}
            />
            <AppText variant="cardTitle" color={theme.colors.textPrimary}>
              System
            </AppText>
          </View>

          <View style={styles.tilesStack}>
            <SystemSettingTile
              icon="palette-outline"
              title="Theme"
              description="Light, Dark or follow the system"
              value={themeMode}
              onPress={() => setActiveModal('theme')}
            />

            {/* Unit 37: the coaching language — what the coach SAYS and
                SHOWS. Explicitly not the app interface language. */}
            <SystemSettingTile
              icon="translate"
              title="Instruction Language"
              description="Language of the coaching you see and hear"
              value={instructionLanguageLabel}
              onPress={() => setActiveModal('instructionLanguage')}
            />

            <SystemSettingTile
              icon="account-voice"
              title="Voice"
              description={
                voiceOptions.length > 1
                  ? `Which installed voice speaks the ${instructionLanguageLabel} coaching`
                  : `No extra voices installed for ${instructionLanguageLabel}`
              }
              value={voiceTileValue}
              onPress={() => setActiveModal('voice')}
            />

            <SystemSettingTile
              icon="shield-check-outline"
              title="Privacy Policy"
              description="How your photos and data are handled"
              onPress={() => router.push('/settings/privacy')}
            />

            <SystemSettingTile
              icon="file-document-outline"
              title="Terms of Service"
              description="Rules for using PoseAssist"
              onPress={() => router.push('/settings/terms')}
            />

            <SystemSettingTile
              icon="information-outline"
              title="About"
              description="Version and product info"
              value={`v${APP_VERSION}`}
              onPress={() => router.push('/settings/about')}
            />

            <SystemSettingTile
              icon="star-outline"
              title="Rate App"
              description="Tell other photographers what you think"
              onPress={() => {
                Alert.alert(
                  'Thank you!',
                  'Rating becomes available once PoseAssist is on the Play Store and App Store.',
                  [{ text: 'OK' }],
                );
              }}
            />

            <SystemSettingTile
              icon="delete-forever"
              title="Clear All Data"
              description="Favorites, recents, gallery metadata & settings"
              destructive
              onPress={handleClearAllData}
            />
          </View>
        </View>

        {/* Reset to Defaults Section */}
        <View style={styles.resetContainer}>
          <Pressable
            onPress={handleReset}
            accessibilityRole="button"
            accessibilityLabel="Reset all preferences to defaults"
            style={({ pressed }) => [
              styles.resetBtn,
              {
                borderColor: theme.colors.error,
                backgroundColor: theme.colors.surface,
                opacity: pressed ? 0.75 : 1,
              },
            ]}
          >
            <IconSymbol
              name="restore"
              size={20}
              color={theme.colors.error}
            />
            <AppText
              variant="body"
              color={theme.colors.error}
              style={styles.resetBtnText}
            >
              Reset to Defaults
            </AppText>
          </Pressable>
        </View>

        {/* Info Footer */}
        <View style={styles.footer}>
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
          >
            {APP_NAME} · v{APP_VERSION}
          </AppText>
          <AppText
            variant="small"
            color={theme.colors.textDisabled}
            align="center"
          >
            Settings are saved locally and apply immediately across sessions.
          </AppText>
        </View>
        </>
        )}
      </ScrollView>

      {/* Flash Default Modal */}
      <SettingsRadioModal<FlashDefault>
        visible={activeModal === 'flash'}
        title="Flash Default"
        subtitle="Choose default flash mode"
        icon="flash-outline"
        options={FLASH_OPTIONS}
        selectedValue={flashDefault}
        onSelect={(value) => {
          setFlashDefault(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Timer Default Modal */}
      <SettingsRadioModal<TimerDefault>
        visible={activeModal === 'timer'}
        title="Timer Default"
        subtitle="Choose default shutter delay"
        icon="timer-outline"
        options={TIMER_OPTIONS}
        selectedValue={timerDefault}
        onSelect={(value) => {
          setTimerDefault(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Filter Default Modal */}
      <SettingsRadioModal<FilterDefault>
        visible={activeModal === 'filter'}
        title="Filter Default"
        subtitle="Choose default photo tone"
        icon="image-filter-vintage"
        options={FILTER_OPTIONS}
        selectedValue={filterDefault}
        onSelect={(value) => {
          setFilterDefault(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Auto Threshold Modal */}
      <SettingsRadioModal<AutoThreshold>
        visible={activeModal === 'autoThreshold'}
        title="Auto-capture Threshold"
        subtitle="Accuracy needed to automatically trigger shutter"
        icon="target"
        options={AUTO_THRESHOLD_OPTIONS}
        selectedValue={autoThreshold}
        onSelect={(value) => {
          setAutoThreshold(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Countdown Duration Modal */}
      <SettingsRadioModal<CountdownDuration>
        visible={activeModal === 'countdown'}
        title="Countdown Duration"
        subtitle="Intelligent auto & palm countdown length"
        icon="timer-sand"
        options={COUNTDOWN_OPTIONS}
        selectedValue={countdownDuration}
        onSelect={(value) => {
          setCountdownDuration(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Unit 21: Theme Modal — applies app-wide immediately */}
      <SettingsRadioModal<ThemeMode>
        visible={activeModal === 'theme'}
        title="Theme"
        subtitle="Applies across the whole app instantly"
        icon="palette-outline"
        options={THEME_OPTIONS}
        selectedValue={themeMode}
        onSelect={(value) => {
          setThemeMode(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Unit 37: Instruction Language — one choice that moves BOTH the
          on-screen coaching band and the spoken cue. App menus stay in
          English; that is stated in the subtitle so the setting cannot be
          mistaken for an interface-language switch. */}
      <SettingsRadioModal<InstructionLanguage>
        visible={activeModal === 'instructionLanguage'}
        title="Instruction Language"
        subtitle="Coaching you see and hear. App menus stay in English."
        icon="translate"
        options={INSTRUCTION_LANGUAGE_OPTIONS}
        selectedValue={instructionLanguage}
        onSelect={(value) => {
          setInstructionLanguage(value);
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Unit 35: Voice Modal — only device-reported voices, never invented */}
      <SettingsRadioModal<string>
        visible={activeModal === 'voice'}
        title="Voice"
        subtitle="Which installed voice reads the coaching aloud"
        icon="account-voice"
        options={voiceOptions}
        selectedValue={selectedVoiceId}
        onSelect={(value) => {
          setVoiceId(
            instructionLanguage,
            value === AUTOMATIC_VOICE_ID ? null : value,
          );
          ttsService.setPreferredVoiceId(
            instructionLanguage,
            value === AUTOMATIC_VOICE_ID ? null : value,
          );
          showToast('Settings saved');
        }}
        onClose={() => setActiveModal(null)}
      />

      {/* Unit 23: success feedback rides the single global snackbar host */}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeRoot: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl * 2,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  tilesStack: {
    gap: spacing.sm,
  },
  resetContainer: {
    marginTop: spacing.sm,
    marginBottom: spacing.xl,
  },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    height: 52,
    borderRadius: radius.lg,
    borderWidth: 1.5,
  },
  resetBtnText: {
    fontWeight: '600',
  },
  footer: {
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
});
