/**
 * Unit 01 — AppButton.
 * Primary / secondary / ghost variants, loading + disabled states, 48px
 * min touch target, Title Case labels (spec). Pure RN.
 *
 * Premium pass (items 5 & 6): instant opacity-flip replaced by the shared
 * spring press (touch-down shrink, overshoot release); filled variants now
 * DARKEN their fill while pressed (primary → primaryPressed, tinted and
 * ghost → token washes) so labels stay fully solid and legible.
 */
import React, { useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  View,
  Animated,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { mediaColors } from '@shared/theme/colors';
import { radius, spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';
import { useReducedMotion } from '../hooks/useReducedMotion';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

type Variant = 'primary' | 'secondary' | 'ghost';

interface AppButtonProps {
  readonly title: string;
  readonly onPress: () => void;
  readonly variant?: Variant;
  readonly icon?: string;
  readonly disabled?: boolean;
  readonly loading?: boolean;
  readonly style?: StyleProp<ViewStyle>;
}

export function AppButton({
  title,
  onPress,
  variant = 'primary',
  icon,
  disabled = false,
  loading = false,
  style,
}: AppButtonProps) {
  const theme = useAppTheme();
  const reduced = useReducedMotion();
  const scale = useRef(new Animated.Value(1)).current;
  const [pressed, setPressed] = useState(false);

  const pressIn = () => {
    if (reduced) return;
    Animated.spring(scale, {
      toValue: 0.96,
      damping: 20,
      stiffness: 400,
      mass: 0.7,
      useNativeDriver: true,
    }).start();
  };

  const pressOut = () => {
    if (reduced) return;
    Animated.spring(scale, {
      toValue: 1,
      damping: 13,
      stiffness: 420,
      mass: 0.6,
      useNativeDriver: true,
    }).start();
  };
  const blocked = disabled || loading;

  const palette = {
    primary: {
      bg: theme.colors.primary,
      bgPressed: theme.colors.primaryPressed,
      fg: theme.colors.textOnPrimary,
      border: theme.colors.primary,
      borderPressed: theme.colors.primaryPressed,
    },
    secondary: {
      bg: theme.colors.primaryLight,
      bgPressed: theme.colors.primaryLightPressed,
      fg: theme.colors.primary,
      border: theme.colors.primaryLight,
      borderPressed: theme.colors.primaryLightPressed,
    },
    ghost: {
      bg: mediaColors.transparent,
      bgPressed: theme.colors.ghostPressed,
      fg: theme.colors.primary,
      border: theme.colors.divider,
      borderPressed: theme.colors.divider,
    },
  }[variant];

  return (
    <Pressable
      onPress={onPress}
      disabled={blocked}
      onPressIn={() => {
        setPressed(true);
        pressIn();
      }}
      onPressOut={() => {
        setPressed(false);
        pressOut();
      }}
      accessibilityRole="button"
      accessibilityState={{ disabled: blocked, busy: loading }}
      accessibilityLabel={title}
      style={[
        styles.base,
        {
          backgroundColor: pressed && !blocked ? palette.bgPressed : palette.bg,
          borderColor: pressed && !blocked ? palette.borderPressed : palette.border,
          opacity: blocked ? 0.45 : 1,
        },
        style,
      ]}
    >
      <Animated.View style={[styles.content, { transform: [{ scale }] }]}>
        {loading ? (
          <ActivityIndicator size="small" color={palette.fg} />
        ) : (
          <>
            {icon && (
              <IconSymbol name={icon} size={16} color={palette.fg} style={styles.icon} />
            )}
            <AppText variant="button" color={palette.fg}>
              {title}
            </AppText>
          </>
        )}
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    minHeight: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    marginRight: spacing.sm,
  },
});
