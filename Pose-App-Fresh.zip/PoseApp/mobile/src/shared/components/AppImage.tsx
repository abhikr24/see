/**
 * Unit 05 expo-image wrapper: disk cache, fade transition, graceful fallback.
 *
 * The bundled pose catalog still ships no photography (all image fields are
 * null), so pose cards use branded PoseCardArt. AppImage now renders real
 * local captures in Gallery and its camera shortcut thumbnail. It remains
 * the ready-made integration point for future licensed pose art; every caller
 * must provide a truthful accessibility label describing the actual image.
 */
import React, { useEffect, useState } from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { Image, type ImageContentFit } from 'expo-image';

interface AppImageProps {
  readonly uri: string | null;
  readonly accessibilityLabel: string;
  readonly contentFit?: ImageContentFit;
  readonly style?: StyleProp<ViewStyle>;
}

export function AppImage({
  uri,
  accessibilityLabel,
  contentFit = 'cover',
  style,
}: AppImageProps) {
  const [failed, setFailed] = useState(false);

  useEffect(() => setFailed(false), [uri]);

  if (!uri || failed) return null;
  return (
    <View style={[styles.container, style]}>
      <Image
        source={{ uri }}
        style={StyleSheet.absoluteFill}
        contentFit={contentFit}
        cachePolicy="memory-disk"
        transition={180}
        accessibilityLabel={accessibilityLabel}
        onError={() => setFailed(true)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
  },
});
