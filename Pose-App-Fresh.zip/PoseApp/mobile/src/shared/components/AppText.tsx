/**
 * Unit 01 — AppText.
 * The only text primitive feature code should use. Applies the shared
 * typeScale variant + Inter font family + theme color. Pure RN.
 */
import React from 'react';
import { StyleSheet, Text, type StyleProp, type TextProps, type TextStyle } from 'react-native';
import { fontFamily, typeScale } from '@shared/theme';
import type { TypeVariant } from '@shared/theme/typography';
import { useAppTheme } from '@/core/theme';

const WEIGHT_TO_FAMILY = {
  regular: fontFamily.regular,
  medium: fontFamily.medium,
  semiBold: fontFamily.semiBold,
  bold: fontFamily.bold,
} as const;

interface AppTextProps extends TextProps {
  readonly variant?: TypeVariant;
  readonly color?: string;
  readonly align?: TextStyle['textAlign'];
  readonly style?: StyleProp<TextStyle>;
  readonly children: React.ReactNode;
}

export function AppText({
  variant = 'body',
  color,
  align,
  style,
  children,
  ...rest
}: AppTextProps) {
  const theme = useAppTheme();
  const t = typeScale[variant];
  return (
    <Text
      {...rest}
      style={[
        styles.base,
        {
          fontSize: t.fontSize,
          lineHeight: t.lineHeight,
          fontFamily: WEIGHT_TO_FAMILY[t.fontWeight],
          color: color ?? theme.colors.textPrimary,
          textAlign: align,
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
}

const styles = StyleSheet.create({
  base: {
    includeFontPadding: false,
  },
});
