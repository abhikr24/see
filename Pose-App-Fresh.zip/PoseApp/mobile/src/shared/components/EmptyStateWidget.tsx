/**
 * Unit 23 — EmptyStateWidget (generic, one canonical empty state).
 * Icon 48 on circle-80 bgSecondary · Title Heading 22 600 · Desc Body 16
 * centered · optional primary CTA (radius md 12, 48px target, Title Case).
 * Feature empties keep their spec copy but render through this widget.
 */
import React from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppButton } from './AppButton';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

interface EmptyStateWidgetProps {
  readonly icon: string;
  readonly title: string;
  readonly description: string;
  readonly buttonText?: string;
  readonly buttonIcon?: string;
  readonly onButtonPress?: () => void;
  readonly style?: StyleProp<ViewStyle>;
}

export function EmptyStateWidget({
  icon,
  title,
  description,
  buttonText,
  buttonIcon,
  onButtonPress,
  style,
}: EmptyStateWidgetProps) {
  const theme = useAppTheme();
  return (
    <View style={[styles.root, style]}>
      <View
        style={[
          styles.iconWrap,
          { backgroundColor: theme.colors.backgroundSecondary },
        ]}
      >
        <IconSymbol name={icon} size={48} color={theme.colors.textDisabled} />
      </View>
      <AppText
        variant="heading"
        color={theme.colors.textPrimary}
        align="center"
        style={styles.title}
      >
        {title}
      </AppText>
      <AppText
        variant="body"
        color={theme.colors.textSecondary}
        align="center"
        style={styles.desc}
      >
        {description}
      </AppText>
      {buttonText !== undefined && onButtonPress !== undefined && (
        <AppButton
          title={buttonText}
          icon={buttonIcon}
          onPress={onButtonPress}
          style={styles.button}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.xxl,
  },
  iconWrap: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: spacing.lg,
  },
  desc: {
    marginTop: spacing.sm,
    maxWidth: 320,
  },
  button: {
    marginTop: spacing.xl,
    minWidth: 180,
  },
});
