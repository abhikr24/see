/**
 * Unit 22 - render crash containment for both the root tree and each feature.
 * React class boundaries are required because componentDidCatch has no hook
 * equivalent. The fallback remains a normal themed functional component.
 */
import React, { Component, type ErrorInfo, type ReactNode } from 'react';
import { errorHandler, type AppError } from '@/core/error/errorHandler';
import { AppLogger } from '@/core/utils/logger';
import { ErrorRetryWidget } from './ErrorRetryWidget';

interface ErrorBoundaryProps {
  readonly children: ReactNode;
  readonly context?: string;
  readonly fallbackTitle?: string;
  readonly fallbackMessage?: string;
  readonly onReset?: () => void;
}

interface ErrorBoundaryState {
  readonly error: AppError | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: unknown): ErrorBoundaryState {
    return { error: errorHandler.mapError(error) };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    errorHandler.handle(error, this.props.context ?? 'ErrorBoundary');
    if (info.componentStack) {
      AppLogger.error(
        `[${this.props.context ?? 'ErrorBoundary'}] component stack`,
        new Error(info.componentStack),
      );
    }
  }

  private reset = (): void => {
    this.props.onReset?.();
    this.setState({ error: null });
  };

  render(): ReactNode {
    const { error } = this.state;
    if (error !== null) {
      return (
        <ErrorRetryWidget
          title={this.props.fallbackTitle}
          message={this.props.fallbackMessage ?? error.message}
          onRetry={this.reset}
        />
      );
    }
    return this.props.children;
  }
}
