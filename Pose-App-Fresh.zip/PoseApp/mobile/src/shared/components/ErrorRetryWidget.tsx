/** Unit 22 - shared user-facing error state with an explicit retry action. */
import React from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppButton } from './AppButton';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

interface ErrorRetryWidgetProps {
  readonly title?: string;
  readonly message: string;
  readonly onRetry: () => void;
  readonly retryLabel?: string;
  readonly style?: StyleProp<ViewStyle>;
}

export function ErrorRetryWidget({
  title = 'Something went wrong',
  message,
  onRetry,
  retryLabel = 'Retry',
  style,
}: ErrorRetryWidgetProps) {
  const theme = useAppTheme();
  return (
    <View
      style={[styles.root, { backgroundColor: theme.colors.background }, style]}
      accessibilityRole="alert"
    >
      <View
        style={[
          styles.iconCircle,
          { backgroundColor: theme.colors.backgroundSecondary },
        ]}
      >
        <IconSymbol
          name="alert-circle-outline"
          size={48}
          color={theme.colors.textSecondary}
        />
      </View>
      <AppText
        variant="heading"
        color={theme.colors.textPrimary}
        align="center"
        style={styles.title}
      >
        {title}
      </AppText>
      <AppText
        variant="body"
        color={theme.colors.textSecondary}
        align="center"
        style={styles.message}
      >
        {message}
      </AppText>
      <AppButton
        title={retryLabel}
        icon="refresh"
        onPress={onRetry}
        style={styles.button}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.xxl,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: spacing.lg,
  },
  message: {
    maxWidth: 340,
    marginTop: spacing.sm,
  },
  button: {
    minWidth: 180,
    marginTop: spacing.xl,
  },
});
