/**
 * Unit 01 — IconSymbol.
 * Thin wrapper over MaterialCommunityIcons so icon usage stays consistent
 * (one library, token sizes) and a future icon swap touches one file.
 */
import React from 'react';
import type { StyleProp, TextStyle } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { lightColors } from '@shared/theme/colors';

interface IconSymbolProps {
  /** MaterialCommunityIcons glyph name, e.g. 'camera', 'compass-outline'. */
  readonly name: string;
  readonly size?: number;
  readonly color?: string;
  readonly style?: StyleProp<TextStyle>;
}

export function IconSymbol({
  name,
  size = 24,
  color = lightColors.textPrimary,
  style,
}: IconSymbolProps) {
  return (
    <MaterialCommunityIcons
      name={name as never}
      size={size}
      color={color}
      style={style}
    />
  );
}
