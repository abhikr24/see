/**
 * Unit 23 — LoadingOverlay (generic).
 * Centered ActivityIndicator in the primary token, optional "Loading..."
 * body-14-secondary label. Full-screen variant covers its parent; `inline`
 * renders as a compact centered block inside a section.
 */
import React from 'react';
import { ActivityIndicator, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from './AppText';

interface LoadingOverlayProps {
  readonly text?: string;
  readonly inline?: boolean;
  readonly style?: StyleProp<ViewStyle>;
}

export function LoadingOverlay({ text, inline = false, style }: LoadingOverlayProps) {
  const theme = useAppTheme();
  return (
    <View
      style={[
        styles.root,
        inline ? styles.inline : null,
        !inline && { backgroundColor: theme.colors.background },
        style,
      ]}
      accessibilityRole="progressbar"
      accessibilityLabel={text ?? 'Loading'}
    >
      <ActivityIndicator size="large" color={theme.colors.primary} />
      {text !== undefined && (
        <AppText
          variant="secondaryBody"
          color={theme.colors.textSecondary}
          align="center"
          style={styles.text}
        >
          {text}
        </AppText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 50,
  },
  inline: {
    position: 'relative',
    paddingVertical: spacing.xxl,
  },
  text: {
    marginTop: spacing.md,
  },
});
