/** Unit 22 - global connectivity status driven by native NetInfo. */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useNetInfo } from '@react-native-community/netinfo';
import { mediaColors, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

export function OfflineBanner() {
  const theme = useAppTheme();
  const network = useNetInfo();

  // null means NetInfo is still resolving; do not flash an offline warning.
  if (network.isConnected !== false) return null;

  return (
    <View
      style={[styles.banner, { backgroundColor: theme.colors.error }]}
      accessibilityRole="alert"
      accessibilityLiveRegion="assertive"
    >
      <IconSymbol name="wifi-off" size={16} color={mediaColors.text} />
      <AppText variant="small" color={mediaColors.text} style={styles.text}>
        You are offline
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    height: 32,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
  },
  text: {
    fontWeight: '600',
  },
});
