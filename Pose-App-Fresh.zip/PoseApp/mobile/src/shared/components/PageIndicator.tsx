/**
 * Unit 03 — PageIndicator (onboarding dots).
 * Active dot: width 24 primary pill; inactive: 8px divider circle.
 * Animated with Reanimated (spec).
 */
import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { radius, spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';

function Dot({ active }: { readonly active: boolean }) {
  const theme = useAppTheme();
  const width = useRef(new Animated.Value(active ? 24 : 8)).current;

  useEffect(() => {
    Animated.timing(width, {
      toValue: active ? 24 : 8,
      duration: 220,
      useNativeDriver: false,
    }).start();
  }, [active, width]);

  return (
    <Animated.View
      style={[
        styles.dot,
        { backgroundColor: active ? theme.colors.primary : theme.colors.divider },
        { width },
      ]}
    />
  );
}

interface PageIndicatorProps {
  readonly count: number;
  readonly activeIndex: number;
}

export function PageIndicator({ count, activeIndex }: PageIndicatorProps) {
  return (
    <View style={styles.row} accessibilityLabel={`Page ${activeIndex + 1} of ${count}`}>
      {Array.from({ length: count }, (_, i) => (
        <Dot key={i} active={i === activeIndex} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm - 2,
  },
  dot: {
    height: 6,
    borderRadius: radius.pill,
  },
});
