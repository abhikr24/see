/**
 * PressableScale — canonical animated-press wrapper (premium-pass item 5).
 *
 * Drop-in replacement for Pressable wherever a touchable should answer the
 * finger physically: spring-driven shrink on touch-down, gentle overshoot
 * on release, no opacity flash. Consumers pass `style` for layout/colors
 * exactly as before; the scale motion is applied around it.
 */
import React from 'react';
import {
  Pressable,
  type GestureResponderEvent,
  type PressableProps,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import Animated from 'react-native-reanimated';
import { pressMotion } from '@shared/index';
import { usePressMotion } from '../hooks/usePressMotion';

export interface PressableScaleProps extends Omit<PressableProps, 'style'> {
  readonly style?: StyleProp<ViewStyle>;
  /** Target scale on touch-down (defaults to the shared 0.96 press token). */
  readonly scaleTo?: number;
  readonly children?: React.ReactNode;
}

export function PressableScale({
  style,
  scaleTo = pressMotion.scale,
  onPressIn,
  onPressOut,
  children,
  ...rest
}: PressableScaleProps) {
  const motion = usePressMotion(scaleTo);

  const handlePressIn = (event: GestureResponderEvent) => {
    motion.onPressIn();
    onPressIn?.(event);
  };
  const handlePressOut = (event: GestureResponderEvent) => {
    motion.onPressOut();
    onPressOut?.(event);
  };

  return (
    <Pressable {...rest} onPressIn={handlePressIn} onPressOut={handlePressOut}>
      <Animated.View style={[style, motion.animatedStyle]}>
        {children}
      </Animated.View>
    </Pressable>
  );
}
