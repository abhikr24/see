/**
 * Unit 03 — PrivacyNote.
 * Small lock-icon reassurance row shown on first-run screens. Reinforces
 * the invariant: photos never leave the device.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { spacing } from '@shared/theme';
import { useAppTheme } from '@/core/theme';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

interface PrivacyNoteProps {
  readonly text?: string;
}

export function PrivacyNote({
  text = 'Photos never leave your device — everything runs on-device.',
}: PrivacyNoteProps) {
  const theme = useAppTheme();
  return (
    <View style={styles.row} accessibilityRole="text">
      <IconSymbol name="lock-outline" size={12} color={theme.colors.textDisabled} />
      <AppText variant="small" color={theme.colors.textDisabled} align="center" style={styles.text}>
        {text}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs + 2,
    paddingHorizontal: spacing.xl,
  },
  text: {
    flexShrink: 1,
  },
});
