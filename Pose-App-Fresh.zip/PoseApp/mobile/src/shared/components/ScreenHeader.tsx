/**
 * Unit 02 — ScreenHeader.
 * Consistent screen title block (title + optional subtitle + trailing slot).
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

interface ScreenHeaderProps {
  readonly title: string;
  readonly subtitle?: string;
  readonly right?: React.ReactNode;
  readonly onBack?: () => void;
}

export function ScreenHeader({ title, subtitle, right, onBack }: ScreenHeaderProps) {
  const theme = useAppTheme();
  return (
    <View style={styles.row}>
      <View style={styles.leftGroup}>
        {onBack !== undefined && (
          <Pressable
            onPress={onBack}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel="Go back"
            style={({ pressed }) => [
              styles.backButton,
              {
                backgroundColor: theme.colors.surface,
                borderColor: theme.colors.divider,
                opacity: pressed ? 0.75 : 1,
              },
            ]}
          >
            <IconSymbol name="arrow-left" size={20} color={theme.colors.textPrimary} />
          </Pressable>
        )}
        <View style={styles.texts}>
          <AppText variant="heading" color={theme.colors.textPrimary}>
            {title}
          </AppText>
          {subtitle !== undefined && (
            <AppText variant="small" color={theme.colors.textSecondary} style={styles.subtitle}>
              {subtitle}
            </AppText>
          )}
        </View>
      </View>
      {right !== undefined && <View>{right}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
  },
  leftGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    flexShrink: 1,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: radius.circle,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  texts: {
    flexShrink: 1,
  },
  subtitle: {
    marginTop: 2,
  },
});
