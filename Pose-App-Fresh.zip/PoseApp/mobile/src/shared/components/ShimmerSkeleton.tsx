/**
 * Unit 23 — ShimmerSkeleton system (NEW; spec asked to UPGRADE a file that did
 * not exist, so this is the canonical creation).
 *
 * Base `Shimmer` + spec-shaped variants:
 *   · ShimmerGrid — 2-col × 6 pose cards (radius md 12, height 180)
 *   · ShimmerGalleryGrid — 3-col × 9 cells (100×100, radius sm 8)
 *   · ShimmerHorizontal — 4 recent cards (140×180, radius md 12)
 *   · ShimmerStats — 3 columns (number 24×40 + label 12×60)
 *   · ShimmerAvatar — circle 80 (+ optional name line 120×22)
 *
 * Effect: a LinearGradient highlight sweeps (translateX) across a bgSecondary
 * base on a 1.5s Reanimated loop. Reduced-motion renders static placeholders.
 * Pure RN + Reanimated + expo-linear-gradient, theme tokens only.
 */
import React, { useEffect } from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from 'react-native-reanimated';
import { mediaColors, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';

interface ShimmerProps {
  readonly width: number | `${number}%`;
  readonly height: number;
  readonly borderRadius?: number;
  readonly style?: StyleProp<ViewStyle>;
}

export function Shimmer({
  width,
  height,
  borderRadius = radius.sm,
  style,
}: ShimmerProps) {
  const theme = useAppTheme();
  const reduceMotion = useReducedMotion();
  const sweep = useSharedValue(-1);

  useEffect(() => {
    if (reduceMotion) return;
    sweep.value = withRepeat(
      withTiming(1, { duration: 1_500 }),
      -1,
      false,
    );
  }, [reduceMotion, sweep]);

  const animatedSweep = useAnimatedStyle(() => ({
    transform: [{ translateX: sweep.value * 320 }],
  }));

  return (
    <View
      style={[
        styles.base,
        { width, height, borderRadius, backgroundColor: theme.colors.backgroundSecondary },
        style,
      ]}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      {!reduceMotion && (
        <Animated.View style={[StyleSheet.absoluteFill, { overflow: 'hidden', borderRadius }]}>
          <Animated.View style={[styles.gradientWrap, animatedSweep]}>
            <LinearGradient
              colors={[
                mediaColors.transparent,
                theme.isDark ? mediaColors.ringDark : mediaColors.glyphLight,
                mediaColors.transparent,
              ]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={styles.gradient}
            />
          </Animated.View>
        </Animated.View>
      )}
    </View>
  );
}

/** Pose Grid — 2 columns × 6 cards, 180px tiles (spec). */
export function ShimmerGrid({ columns = 2, count = 6, cardHeight = 180 }: {
  readonly columns?: number;
  readonly count?: number;
  readonly cardHeight?: number;
}) {
  return (
    <View style={styles.grid} testID="shimmer-pose-grid">
      {Array.from({ length: count }, (_, index) => (
        <Shimmer
          key={index}
          width={`${100 / columns - 2}%`}
          height={cardHeight}
          borderRadius={radius.md}
        />
      ))}
    </View>
  );
}

/** Gallery Grid — 3 columns × 9 cells, 100×100 (spec). */
export function ShimmerGalleryGrid({ count = 9 }: { readonly count?: number }) {
  return (
    <View style={styles.grid} testID="shimmer-gallery-grid">
      {Array.from({ length: count }, (_, index) => (
        <Shimmer key={index} width={100} height={100} borderRadius={radius.sm} />
      ))}
    </View>
  );
}

/** Recent horizontal shelf — 4 cards 140×180 (spec). */
export function ShimmerHorizontal({ count = 4 }: { readonly count?: number }) {
  return (
    <View style={styles.horizontal} testID="shimmer-horizontal">
      {Array.from({ length: count }, (_, index) => (
        <Shimmer key={index} width={140} height={180} borderRadius={radius.md} />
      ))}
    </View>
  );
}

/** Stats row — 3 columns: number (24×40) + label (12×60) (spec). */
export function ShimmerStats({ count = 3 }: { readonly count?: number }) {
  return (
    <View style={styles.statsRow} testID="shimmer-stats">
      {Array.from({ length: count }, (_, index) => (
        <View key={index} style={styles.statCell}>
          <Shimmer width={40} height={24} borderRadius={radius.xs} />
          <Shimmer width={60} height={12} borderRadius={radius.xs} style={styles.statLabel} />
        </View>
      ))}
    </View>
  );
}

/** Profile avatar circle 80 (+ optional name line 120×22) (spec). */
export function ShimmerAvatar({ withName = true }: { readonly withName?: boolean }) {
  return (
    <View style={styles.avatarWrap} testID="shimmer-avatar">
      <Shimmer width={80} height={80} borderRadius={radius.circle} />
      {withName && <Shimmer width={120} height={22} borderRadius={radius.xs} style={styles.statLabel} />}
    </View>
  );
}

/** Settings-style stacked tile rows. */
export function ShimmerTiles({ count = 5 }: { readonly count?: number }) {
  return (
    <View style={styles.tiles} testID="shimmer-tiles">
      {Array.from({ length: count }, (_, index) => (
        <View key={index} style={styles.tileRow}>
          <Shimmer width={40} height={40} borderRadius={radius.circle} />
          <View style={styles.tileText}>
            <Shimmer width="70%" height={14} borderRadius={radius.xs} />
            <Shimmer width="45%" height={10} borderRadius={radius.xs} style={styles.tileLabel} />
          </View>
        </View>
      ))}
    </View>
  );
}

const GRADIENT_WIDTH = 160;

const styles = StyleSheet.create({
  base: {
    overflow: 'hidden',
  },
  gradientWrap: {
    ...({ position: 'absolute' as const, top: 0, right: 0, bottom: 0, left: 0 }),
    width: GRADIENT_WIDTH * 2,
  },
  gradient: {
    flex: 1,
    width: GRADIENT_WIDTH,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  horizontal: {
    flexDirection: 'row',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  statsRow: {
    flexDirection: 'row',
    gap: spacing.lg,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  statCell: {
    flex: 1,
    alignItems: 'center',
  },
  statLabel: {
    marginTop: spacing.xs,
  },
  avatarWrap: {
    alignItems: 'center',
    paddingTop: spacing.md,
  },
  tiles: {
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  tileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  tileText: {
    flex: 1,
    gap: spacing.xs,
  },
  tileLabel: {
    marginTop: spacing.xs,
  },
});
