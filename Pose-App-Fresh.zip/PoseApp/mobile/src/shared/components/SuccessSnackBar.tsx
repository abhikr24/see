/**
 * Unit 23 — GlobalSnackBar host (rendered exactly once at the app root).
 * Rewriting of the Unit 13 SuccessSnackBar into a store-driven host:
 *   · 'success' variant → Success #10B981; 'primary' variant → Primary #2563EB
 *   · white Body-14-600 text, radius md 12, 2s auto-hide (store-owned)
 *   · optional single action label; reduced-motion honors static placement
 */
import React, { useEffect } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { mediaColors, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useReducedMotion } from '@/shared/hooks/useReducedMotion';
import { useSnackBarStore } from '@/shared/stores/snackBarStore';
import { AppText } from './AppText';

export function GlobalSnackBar() {
  const theme = useAppTheme();
  const reduceMotion = useReducedMotion();
  const message = useSnackBarStore((s) => s.message);
  const variant = useSnackBarStore((s) => s.variant);
  const actionLabel = useSnackBarStore((s) => s.actionLabel);
  const onAction = useSnackBarStore((s) => s.onAction);
  const hideSnackBar = useSnackBarStore((s) => s.hideSnackBar);

  const visible = message !== null;
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(8);

  useEffect(() => {
    opacity.value = withTiming(visible ? 1 : 0, { duration: reduceMotion ? 0 : 180 });
    translateY.value = withTiming(visible ? 0 : 8, { duration: reduceMotion ? 0 : 180 });
  }, [visible, reduceMotion, opacity, translateY]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }],
  }));

  const backgroundColor =
    variant === 'primary' ? theme.colors.primary : theme.colors.success;

  return (
    <Animated.View
      pointerEvents={visible ? 'auto' : 'none'}
      style={[styles.snackbar, { backgroundColor }, animatedStyle]}
      accessibilityLiveRegion="polite"
    >
      <View style={styles.content}>
        <AppText
          variant="secondaryBody"
          color={mediaColors.text}
          style={styles.text}
        >
          {message ?? ''}
        </AppText>
        {actionLabel !== null && onAction !== null && (
          <Pressable
            onPress={() => {
              onAction();
              hideSnackBar();
            }}
            accessibilityRole="button"
            accessibilityLabel={actionLabel}
            style={({ pressed }) => [
              styles.action,
              {
                opacity: pressed ? 0.75 : 1,
                backgroundColor: mediaColors.whiteSoft,
              },
            ]}
          >
            <AppText variant="small" color={mediaColors.text} style={styles.actionText}>
              {actionLabel}
            </AppText>
          </Pressable>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  snackbar: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    bottom: spacing.section + spacing.xxxl,
    minHeight: 48,
    borderRadius: radius.md,
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
    zIndex: 200,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
    paddingVertical: spacing.sm,
  },
  text: {
    fontWeight: '600',
    flexShrink: 1,
  },
  action: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.sm,
  },
  actionText: {
    fontWeight: '600',
  },
});
