/**
 * Unit 02 — TabPlaceholder.
 * Stand-in screen for tabs whose unit hasn't landed yet: icon, title,
 * subtitle, unit badge. Uses theme tokens only. Replaced unit by unit as
 * features ship (Explore → Unit 08 already replaced it).
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';
import { radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

interface TabPlaceholderProps {
  readonly icon: string;
  readonly title: string;
  readonly subtitle: string;
  readonly badge: string;
  readonly children?: React.ReactNode;
}

export function TabPlaceholder({
  icon,
  title,
  subtitle,
  badge,
  children,
}: TabPlaceholderProps) {
  const theme = useAppTheme();
  return (
    <View style={[styles.root, { backgroundColor: theme.colors.background }]}>
      <View style={[styles.iconWrap, { backgroundColor: theme.colors.backgroundSecondary }]}>
        <IconSymbol name={icon} size={36} color={theme.colors.textDisabled} />
      </View>
      <AppText variant="cardTitle" color={theme.colors.textPrimary} style={styles.title}>
        {title}
      </AppText>
      <AppText
        variant="secondaryBody"
        color={theme.colors.textSecondary}
        align="center"
        style={styles.subtitle}
      >
        {subtitle}
      </AppText>
      <View style={[styles.badge, { backgroundColor: theme.colors.primaryLight }]}>
        <AppText variant="small" color={theme.colors.primary} style={styles.badgeText}>
          {badge}
        </AppText>
      </View>
      {children !== undefined && <View style={styles.children}>{children}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xl,
  },
  iconWrap: {
    width: 88,
    height: 88,
    borderRadius: radius.circle,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: spacing.lg,
  },
  subtitle: {
    marginTop: spacing.xs,
    maxWidth: 320,
  },
  badge: {
    marginTop: spacing.lg,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
  badgeText: {
    fontWeight: '600',
    letterSpacing: 0.4,
  },
  children: {
    marginTop: spacing.xl,
    width: '100%',
  },
});
