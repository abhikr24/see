/**
 * Unit 01 — ThemeModeSwitcher.
 * Segmented Light / Dark / System control bound to themeStore. Living on
 * the Profile tab as the visible proof of the Unit 01 theme engine.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { mediaColors, radius, spacing, type ThemeMode } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { useThemeStore } from '@/shared/stores/themeStore';
import { AppText } from './AppText';
import { IconSymbol } from './IconSymbol';

const MODES: { key: ThemeMode; label: string; icon: string }[] = [
  { key: 'light', label: 'Light', icon: 'white-balance-sunny' },
  { key: 'dark', label: 'Dark', icon: 'weather-night' },
  { key: 'system', label: 'System', icon: 'cellphone-cog' },
];

export function ThemeModeSwitcher() {
  const theme = useAppTheme();
  const themeMode = useThemeStore((s) => s.themeMode);
  const setThemeMode = useThemeStore((s) => s.setThemeMode);

  return (
    <View
      style={[
        styles.wrap,
        { backgroundColor: theme.colors.backgroundSecondary, borderColor: theme.colors.divider },
      ]}
    >
      <AppText variant="small" color={theme.colors.textDisabled} style={styles.label}>
        APPEARANCE
      </AppText>
      <View style={styles.row}>
        {MODES.map((mode) => {
          const active = themeMode === mode.key;
          return (
            <Pressable
              key={mode.key}
              onPress={() => setThemeMode(mode.key)}
              accessibilityRole="button"
              accessibilityState={{ selected: active }}
              accessibilityLabel={`Theme ${mode.label}`}
              style={({ pressed }) => [
                styles.option,
                {
                  backgroundColor: active ? theme.colors.surface : mediaColors.transparent,
                  opacity: pressed ? 0.8 : 1,
                },
                active && styles.optionActive,
              ]}
            >
              <IconSymbol
                name={mode.icon}
                size={14}
                color={active ? theme.colors.primary : theme.colors.textSecondary}
              />
              <AppText
                variant="small"
                color={active ? theme.colors.primary : theme.colors.textSecondary}
                style={styles.optionText}
              >
                {mode.label}
              </AppText>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: spacing.md,
  },
  label: {
    fontWeight: '600',
    letterSpacing: 0.8,
    marginBottom: spacing.sm,
  },
  row: {
    flexDirection: 'row',
    gap: spacing.xs,
  },
  option: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs + 1,
    borderRadius: radius.sm,
    paddingVertical: spacing.sm,
  },
  optionActive: {
    shadowColor: mediaColors.shadow,
    shadowOpacity: 0.1,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
  },
  optionText: {
    fontWeight: '600',
  },
});
