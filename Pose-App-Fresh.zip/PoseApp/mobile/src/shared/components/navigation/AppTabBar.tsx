/**
 * Unit 02 — AppTabBar (custom bottom navigation).
 *  · 5 tabs: Home · Explore · Camera · Gallery · Profile
 *  · Top corners radius xl=20, top hairline divider, subtle elevation
 *  · Active: primary #2563EB (token) + filled icon; inactive: textSecondary + outline
 *  · 48px minimum touch targets, theme driven
 *
 * Premium pass (items 5 & 7): tab items now answer the finger with the
 * shared snappy-spring press (no more instant opacity drop + static scale),
 * and the bar's shadow reads from the 3-level elevation token scale
 * (`floating`, cast upward) instead of a hand-written shadow block.
 */
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated from 'react-native-reanimated';
// Expo Router (SDK 53+) vendors its own React Navigation internally — the
// props object the Tabs navigator feeds this custom tab bar is typed by that
// vendored copy, so the standalone @react-navigation/bottom-tabs package is
// intentionally no longer a dependency (SDK 57 migration).
import type { BottomTabBarProps } from 'expo-router/build/react-navigation/bottom-tabs/types';
import { elevationStyle, pressMotion, radius, spacing } from '@shared/index';
import { useAppTheme } from '@/core/theme';
import { usePressMotion } from '../../hooks/usePressMotion';
import { AppText } from '../AppText';
import { IconSymbol } from '../IconSymbol';

const TAB_CONFIG: Record<string, { label: string; icon: string; iconActive: string }> = {
  home: { label: 'Home', icon: 'home-outline', iconActive: 'home' },
  explore: { label: 'Explore', icon: 'compass-outline', iconActive: 'compass' },
  camera: { label: 'Camera', icon: 'camera-outline', iconActive: 'camera' },
  gallery: { label: 'Gallery', icon: 'image-multiple-outline', iconActive: 'image-multiple' },
  profile: { label: 'Profile', icon: 'account-outline', iconActive: 'account' },
};

interface TabItemProps {
  readonly label: string;
  readonly icon: string;
  readonly iconActive: string;
  readonly focused: boolean;
  readonly onPress: () => void;
  readonly onLongPress: () => void;
}

function TabItem({ label, icon, iconActive, focused, onPress, onLongPress }: TabItemProps) {
  const theme = useAppTheme();
  const motion = usePressMotion(pressMotion.controlScale);
  const tint = focused ? theme.colors.primary : theme.colors.textSecondary;

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={motion.onPressIn}
      onPressOut={motion.onPressOut}
      accessibilityRole="tab"
      accessibilityState={{ selected: focused }}
      accessibilityLabel={`${label} tab`}
      style={styles.item}
    >
      <Animated.View style={[styles.itemContent, motion.animatedStyle]}>
        <IconSymbol name={focused ? iconActive : icon} size={22} color={tint} />
        <AppText variant="navLabel" color={tint} style={styles.label}>
          {label}
        </AppText>
      </Animated.View>
    </Pressable>
  );
}

export function AppTabBar({ state, navigation }: BottomTabBarProps) {
  const theme = useAppTheme();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.bar,
        elevationStyle('floating', theme.colors, 'up'),
        {
          backgroundColor: theme.colors.surface,
          borderTopColor: theme.colors.divider,
          paddingBottom: Math.max(insets.bottom, spacing.sm),
        },
      ]}
    >
      {state.routes.map((route, index) => {
        const config = TAB_CONFIG[route.name] ?? {
          label: route.name,
          icon: 'circle-outline',
          iconActive: 'circle',
        };
        const focused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });
          if (!focused && !event.defaultPrevented) {
            navigation.navigate(route.name, route.params);
          }
        };

        const onLongPress = () => {
          navigation.emit({ type: 'tabLongPress', target: route.key });
        };

        return (
          <TabItem
            key={route.key}
            label={config.label}
            icon={config.icon}
            iconActive={config.iconActive}
            focused={focused}
            onPress={onPress}
            onLongPress={onLongPress}
          />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: spacing.sm - 2,
    paddingHorizontal: spacing.sm,
  },
  item: {
    flex: 1,
    minHeight: 48,
  },
  itemContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
  },
  label: {
    marginTop: 1,
  },
});
