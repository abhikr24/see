/**
 * usePressMotion — the animated press (premium-pass items 1 & 5).
 *
 * Replaces every instant opacity-flip / hard scale swap on touchables:
 * touch-down eases into a spring-driven shrink (~0.96, snappy spring) and
 * release settles back with the dedicated pressRelease spring (slight
 * overshoot). Honors the OS Reduce Motion preference by staying perfectly
 * still for reduced-motion users (the interaction still answers onPress).
 */
import { useCallback } from 'react';
import {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  type AnimatedStyle,
} from 'react-native-reanimated';
import { motionSpring, pressMotion } from '@shared/index';
import { useReducedMotion } from './useReducedMotion';

export interface PressMotion {
  // Reanimated 4 returns an opaque AnimatedStyleHandle (not the plain style
  // object) from useAnimatedStyle; it is consumed only as a style prop value,
  // so the public AnimatedStyle<T> union (which contains that handle) is the
  // correct contract.
  readonly animatedStyle: AnimatedStyle<{ transform: { scale: number }[] }>;
  readonly onPressIn: () => void;
  readonly onPressOut: () => void;
}

export function usePressMotion(scaleTo: number = pressMotion.scale): PressMotion {
  const reduced = useReducedMotion();
  const scale = useSharedValue(1);

  const onPressIn = useCallback(() => {
    if (reduced) return;
    scale.value = withSpring(scaleTo, motionSpring.snappy);
  }, [reduced, scale, scaleTo]);

  const onPressOut = useCallback(() => {
    if (reduced) return;
    scale.value = withSpring(1, motionSpring.pressRelease);
  }, [reduced, scale]);

  const animatedStyle = useAnimatedStyle(
    () => ({ transform: [{ scale: scale.value }] }),
    [],
  );

  return { animatedStyle, onPressIn, onPressOut };
}
