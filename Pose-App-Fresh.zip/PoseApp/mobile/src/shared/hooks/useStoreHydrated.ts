/**
 * Unit 23 — hydration tracker for Zustand+MMKV persisted stores.
 * Persist rehydration is a genuine first-frame loading phase; shimmer states
 * render only until the disk snapshot is actually in memory. Not decoration.
 */
import { useEffect, useState } from 'react';

interface PersistApi {
  readonly persist?: {
    hasHydrated: () => boolean;
    onFinishHydration: (fn: () => void) => () => void;
  };
}

export function useStoreHydrated(store: PersistApi): boolean {
  const [hydrated, setHydrated] = useState<boolean>(
    () => store.persist?.hasHydrated() ?? true,
  );

  useEffect(() => {
    if (store.persist === undefined) return undefined;
    if (store.persist.hasHydrated()) {
      setHydrated(true);
      return undefined;
    }
    return store.persist.onFinishHydration(() => {
      setHydrated(true);
    });
  }, [store]);

  return hydrated;
}
