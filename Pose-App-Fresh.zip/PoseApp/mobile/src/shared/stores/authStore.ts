/** Unit 06 auth state: repository-driven, restorable, real-or-demo automatically. */
import { create } from 'zustand';
import { emailError, normalizeEmail, passwordError } from '@shared/index';
import { isDemoMode } from '@/core/network/supabaseClient';
import { AppLogger } from '@/core/utils/logger';
import { authRepository } from '@/features/auth/data/repositories/authRepository';
import { AuthFailure, type AuthUser } from '@/features/auth/domain/entities/authUser';

export type AuthStatus = 'initializing' | 'unauthenticated' | 'authenticated';

/**
 * Every submit path reports its outcome explicitly:
 *  · 'success'               — a session exists; the screen may leave
 *  · 'confirmation-required' — account created / exists but unconfirmed,
 *                              NO session yet; the screen must stay and show
 *                              the check-your-inbox state (never navigate)
 *  · 'failed'                — lastError carries the user-facing message
 */
export type AuthSubmitOutcome = 'success' | 'confirmation-required' | 'failed';

interface AuthState {
  readonly session: AuthUser | null;
  readonly status: AuthStatus;
  readonly isDemoMode: boolean;
  readonly lastError: string | null;
  /**
   * B2 — a PASSWORD_RECOVERY session is live (Supabase emitted the recovery
   * event after the user's email link exchanged). This is the ONLY signal
   * that unlocks the new-password surface; it clears on any session change
   * (shared/auth/accountLifecycle: recovery never survives session changes).
   */
  readonly recoverySessionActive: boolean;
  readonly initialize: () => Promise<void>;
  readonly signInWithEmail: (email: string, password: string) => Promise<AuthSubmitOutcome>;
  readonly signUpWithEmail: (
    email: string,
    password: string,
    displayName: string,
  ) => Promise<AuthSubmitOutcome>;
  readonly signInWithGoogle: () => Promise<AuthSubmitOutcome>;
  readonly resendConfirmationEmail: (email: string) => Promise<boolean>;
  readonly updateDisplayName: (displayName: string) => Promise<boolean>;
  readonly clearLastError: () => void;
  readonly signOut: () => Promise<void>;
  /**
   * B2 step 1 — send a recovery email. `true` means the request was
   * ACCEPTED (neutral — it never reveals whether the email exists).
   */
  readonly requestPasswordReset: (email: string) => Promise<boolean>;
  /**
   * B2 step 2 — set the new password inside the active recovery session.
   */
  readonly completePasswordReset: (newPassword: string) => Promise<AuthSubmitOutcome>;
  /**
   * B1 — delete the account through the secure server-side boundary.
   * Resolves 'deleted' ONLY after the server confirmed deletion AND the
   * account-scoped local cleanup ran; 'failed' ALWAYS leaves the session
   * fully intact (LOGGED OUT and ACCOUNT DELETED stay distinct).
   */
  readonly deleteAccount: () => Promise<'deleted' | 'failed'>;
  /** Recovery surface closed by the user or after a successful update. */
  readonly clearRecoverySession: () => void;
}

/**
 * Account-scoped local cleanup for a confirmed deletion — EXACTLY the
 * "clear-local" rows of shared DELETION_DATA_SCOPE: the favorites replica
 * buckets of the deleted account, its in-app capture files + metadata, and
 * any cached queries that could surface them. Device-level settings,
 * browsing history and system-gallery photos are deliberately untouched.
 * Best-effort per step: the server identity is already gone, so a failed
 * local sweep warns loudly but cannot resurrect the account.
 */
async function cleanupAfterAccountDeletion(userId: string): Promise<void> {
  const steps: readonly { label: string; run: () => void | Promise<void> }[] = [
    {
      label: 'favorites-replica',
      run: async () => {
        const { useFavoritesStore } = await import('@/features/favorites/data/favoritesStore');
        useFavoritesStore.getState().removeAccountData(userId);
      },
    },
    {
      label: 'gallery-captures',
      run: async () => {
        const { galleryLocalDatasource } = await import(
          '@/features/gallery/data/datasources/galleryLocalDatasource'
        );
        await galleryLocalDatasource.deleteAllPhotos(userId);
      },
    },
    {
      label: 'query-cache',
      run: async () => {
        const { queryClient } = await import('@/core/network/queryClient');
        queryClient.removeQueries({ queryKey: ['gallery'] });
      },
    },
  ];
  for (const step of steps) {
    try {
      await step.run();
    } catch (error) {
      AppLogger.warn(`[Auth] post-deletion local sweep incomplete at ${step.label} - ${String(error)}`);
    }
  }
}

let unsubscribeAuth: (() => void) | null = null;

async function syncFavorites(user: AuthUser): Promise<void> {
  try {
    const { syncFavoritesWithCloud } = await import(
      '@/features/favorites/domain/favoritesSyncService'
    );
    await syncFavoritesWithCloud(user.id);
  } catch (error) {
    // Authentication remains successful when metadata sync is offline.
    AppLogger.warn(`[FavoritesSync] deferred after auth - ${String(error)}`);
  }
}

async function syncProfile(user: AuthUser): Promise<void> {
  try {
    const { upsertProfile } = await import(
      '@/features/auth/data/datasources/profileRemoteDataSource'
    );
    await upsertProfile({
      id: user.id,
      email: user.email,
      displayName: user.displayName,
      avatarUrl: user.avatarUrl,
    });
  } catch (error) {
    AppLogger.warn(`[Profile] metadata sync deferred - ${String(error)}`);
  }
}

async function hydrateAccount(user: AuthUser): Promise<void> {
  await Promise.all([syncFavorites(user), syncProfile(user)]);
}

function messageFor(error: unknown): string {
  return error instanceof AuthFailure ? error.message : 'Authentication failed. Try again.';
}

function isConfirmationRequired(error: unknown): boolean {
  return error instanceof AuthFailure && error.code === 'email-not-confirmed';
}

export const useAuthStore = create<AuthState>((set, get) => ({
  session: null,
  status: 'initializing',
  isDemoMode,
  lastError: null,
  recoverySessionActive: false,

  initialize: async () => {
    const user = await authRepository.restoreSession();
    set({
      session: user,
      status: user ? 'authenticated' : 'unauthenticated',
      lastError: null,
      recoverySessionActive: false,
    });
    unsubscribeAuth?.();
    unsubscribeAuth = authRepository.onAuthChange((nextUser, lifecycleEvent) => {
      set((state) => ({
        session: nextUser,
        status: nextUser ? 'authenticated' : 'unauthenticated',
        // Recovery context opens on the recovery event and closes with ANY
        // session disappearance (shared policy: it never survives changes).
        recoverySessionActive:
          lifecycleEvent === 'password-recovery'
            ? true
            : nextUser === null
              ? false
              : state.recoverySessionActive,
      }));
      if (nextUser) void hydrateAccount(nextUser);
    });
    if (user) await hydrateAccount(user);
  },

  signInWithEmail: async (rawEmail, password) => {
    const email = normalizeEmail(rawEmail);
    const invalidEmail = emailError(email);
    if (invalidEmail !== null) {
      set({ lastError: invalidEmail });
      return 'failed';
    }
    const invalidPassword = passwordError(password);
    if (invalidPassword !== null) {
      set({ lastError: invalidPassword });
      return 'failed';
    }
    try {
      const user = await authRepository.signInWithEmail(email, password);
      set({ session: user, status: 'authenticated', lastError: null });
      await hydrateAccount(user);
      AppLogger.info(`[Auth] signed in - ${user.email}`);
      return 'success';
    } catch (error) {
      if (isConfirmationRequired(error)) {
        AppLogger.info('[Auth] sign-in blocked until email is confirmed');
        return 'confirmation-required';
      }
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] sign-in failed - ${String(error)}`);
      return 'failed';
    }
  },

  signUpWithEmail: async (rawEmail, password, displayName) => {
    const email = normalizeEmail(rawEmail);
    const invalidEmail = emailError(email);
    if (invalidEmail !== null) {
      set({ lastError: invalidEmail });
      return 'failed';
    }
    const invalidPassword = passwordError(password);
    if (invalidPassword !== null) {
      set({ lastError: invalidPassword });
      return 'failed';
    }
    try {
      const user = await authRepository.signUpWithEmail(email, password, displayName.trim());
      set({ session: user, status: 'authenticated', lastError: null });
      await hydrateAccount(user);
      AppLogger.info(`[Auth] account created - ${user.email}`);
      return 'success';
    } catch (error) {
      if (isConfirmationRequired(error)) {
        // Account exists, session intentionally absent: the caller keeps the
        // user on /auth and shows the confirmation state. No lastError — this
        // is not a failure.
        AppLogger.info('[Auth] account created — email confirmation required');
        return 'confirmation-required';
      }
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] sign-up failed - ${String(error)}`);
      return 'failed';
    }
  },

  signInWithGoogle: async () => {
    try {
      const user = await authRepository.signInWithGoogle();
      if (user === null) {
        // OAuth hand-off: the browser round-trip (or a user cancel) completes
        // outside this call. No error spam for a cancelled flow.
        return 'failed';
      }
      set({ session: user, status: 'authenticated', lastError: null });
      await hydrateAccount(user);
      return 'success';
    } catch (error) {
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] Google sign-in failed - ${String(error)}`);
      return 'failed';
    }
  },

  resendConfirmationEmail: async (rawEmail) => {
    const email = normalizeEmail(rawEmail);
    try {
      await authRepository.resendSignupConfirmation(email);
      AppLogger.info(`[Auth] confirmation email re-sent - ${email}`);
      return true;
    } catch (error) {
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] resend confirmation failed - ${String(error)}`);
      return false;
    }
  },

  updateDisplayName: async (displayName: string): Promise<boolean> => {
    const trimmed = displayName.trim();
    if (trimmed.length === 0) {
      set({ lastError: 'Display name cannot be empty.' });
      return false;
    }
    try {
      const user = await authRepository.updateDisplayName(trimmed);
      set({ session: user, lastError: null });
      await syncProfile(user);
      AppLogger.info(`[Auth] display name updated -> ${trimmed}`);
      return true;
    } catch (error) {
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] update name failed - ${String(error)}`);
      return false;
    }
  },

  clearLastError: () => {
    set({ lastError: null });
  },

  /* ── B2 · password recovery ─────────────────────────────────────────── */

  requestPasswordReset: async (rawEmail) => {
    const email = normalizeEmail(rawEmail);
    const invalidEmail = emailError(email);
    if (invalidEmail !== null) {
      set({ lastError: invalidEmail });
      return false;
    }
    try {
      await authRepository.requestPasswordReset(email);
      set({ lastError: null });
      AppLogger.info('[Auth] recovery email requested');
      return true;
    } catch (error) {
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] recovery request failed - ${String(error)}`);
      return false;
    }
  },

  completePasswordReset: async (newPassword) => {
    try {
      const user = await authRepository.completePasswordReset(newPassword);
      // The recovery session becomes a normal session; close the recovery
      // context in the same commit so no stale surface can linger.
      set({
        session: user,
        status: 'authenticated',
        lastError: null,
        recoverySessionActive: false,
      });
      await syncProfile(user);
      AppLogger.info(`[Auth] password updated - ${user.email}`);
      return 'success';
    } catch (error) {
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] password update failed - ${String(error)}`);
      return 'failed';
    }
  },

  clearRecoverySession: () => {
    set({ recoverySessionActive: false });
  },

  /* ── B1 · account deletion ──────────────────────────────────────────── */

  deleteAccount: async () => {
    const session = get().session;
    if (session === null) {
      set({ lastError: 'No active session. Nothing was deleted.' });
      AppLogger.warn('[Auth] deletion attempted without a session — refused');
      return 'failed';
    }
    try {
      // Backend authority FIRST — no local state moves before this resolves.
      await authRepository.deleteAccount();
    } catch (error) {
      // Deletion did NOT happen: keep the session, say so, allow retry.
      set({ lastError: messageFor(error) });
      AppLogger.error(`[Auth] account deletion failed - ${String(error)}`);
      return 'failed';
    }
    // Confirmed deleted server-side: now (and only now) terminate locally.
    await cleanupAfterAccountDeletion(session.id);
    set({
      session: null,
      status: 'unauthenticated',
      lastError: null,
      recoverySessionActive: false,
    });
    AppLogger.info('[Auth] account deleted; session terminated after confirmed removal');
    return 'deleted';
  },

  signOut: async () => {
    try {
      await authRepository.signOut();
    } finally {
      const { useFavoritesStore } = await import(
        '@/features/favorites/data/favoritesStore'
      );
      const { queryClient } = await import('@/core/network/queryClient');
      useFavoritesStore.getState().clearLocal(isDemoMode);
      queryClient.removeQueries({ queryKey: ['gallery'] });
      // A sign-out also closes any live recovery context (policy).
      set({
        session: null,
        status: 'unauthenticated',
        lastError: null,
        recoverySessionActive: false,
      });
      AppLogger.info('[Auth] signed out; local favorites replica cleared');
    }
  },
}));

export function disposeAuthSubscription(): void {
  unsubscribeAuth?.();
  unsubscribeAuth = null;
}
