/**
 * Unit 20 — settingsStore (Zustand + MMKV persistence).
 * Single source of truth for camera defaults and intelligent capture preferences.
 *
 * Unit 37 (Part 4.6) — INSTRUCTION LANGUAGE lives here, in the one existing
 * settings store, behind the one existing MMKV seam. No second persistence
 * mechanism, no secure storage for an ordinary preference.
 */
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import {
  DEFAULT_CAMERA_SETTINGS,
  STORAGE_KEYS,
  type AutoThreshold,
  type CameraSettings,
  type CountdownDuration,
  type FilterDefault,
  type FlashDefault,
  type InstructionLanguage,
  type TimerDefault,
  SETTINGS_PERSIST_VERSION,
  migrateCameraSettings,
  resolveInstructionLanguage,
} from '@shared/index';
import { storage } from '@/core/storage/storage';
import { AppLogger } from '@/core/utils/logger';

const mmkvStateStorage = {
  getItem: (name: string): string | null => storage.getString(name) ?? null,
  setItem: (name: string, value: string): void => {
    storage.set(name, value);
  },
  removeItem: (name: string): void => {
    storage.delete(name);
  },
};

interface SettingsState extends CameraSettings {
  readonly setFlashDefault: (flash: FlashDefault) => void;
  readonly setTimerDefault: (timer: TimerDefault) => void;
  readonly setFilterDefault: (filter: FilterDefault) => void;
  readonly setGridOverlayEnabled: (enabled: boolean) => void;
  readonly toggleGridOverlay: () => void;
  readonly setAutoThreshold: (threshold: AutoThreshold) => void;
  readonly setVoiceEnabled: (enabled: boolean) => void;
  readonly toggleVoice: () => void;
  readonly setGestureEnabled: (enabled: boolean) => void;
  readonly toggleGesture: () => void;
  readonly setCountdownDuration: (duration: CountdownDuration) => void;
  readonly setHapticEnabled: (enabled: boolean) => void;
  readonly toggleHaptic: () => void;
  /* FINAL INTEGRATION PASS — Unit 38 shipped the volume-key shutter with a
     persisted flag (migration v4) but NO settings surface to change it: the
     store spread the default and the camera read it, and that was the whole
     life of the preference. A camera control the user cannot find is a
     control the user cannot trust, so the toggle lives here beside the other
     capture inputs. */
  readonly toggleVolumeShutter: () => void;
  /**
   * Unit 37 — the coaching language (visible band + spoken cue). Distinct
   * from `setVoiceId`, which only picks WHICH device voice renders it.
   */
  readonly setInstructionLanguage: (language: InstructionLanguage) => void;
  /**
   * Unit 35 (Part 4.4) — remembers the TTS voice the user picked FOR THAT
   * LANGUAGE. `null` = automatic (the app ranks the live device catalog).
   * Persisted through the same MMKV seam as every other preference; no
   * second storage mechanism, and never any secret.
   */
  readonly setVoiceId: (language: InstructionLanguage, voiceId: string | null) => void;
  readonly resetToDefaults: () => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      ...DEFAULT_CAMERA_SETTINGS,

      setFlashDefault: (flash) => {
        AppLogger.info(`[Settings] flashDefault → ${flash}`);
        set({ flashDefault: flash });
      },

      setTimerDefault: (timer) => {
        AppLogger.info(`[Settings] timerDefault → ${timer}s`);
        set({ timerDefault: timer });
      },

      setFilterDefault: (filter) => {
        AppLogger.info(`[Settings] filterDefault → ${filter}`);
        set({ filterDefault: filter });
      },

      setGridOverlayEnabled: (enabled) => {
        AppLogger.info(`[Settings] gridOverlayEnabled → ${enabled}`);
        set({ gridOverlayEnabled: enabled });
      },

      toggleGridOverlay: () => {
        const next = !get().gridOverlayEnabled;
        AppLogger.info(`[Settings] gridOverlayEnabled → ${next}`);
        set({ gridOverlayEnabled: next });
      },

      setAutoThreshold: (threshold) => {
        AppLogger.info(`[Settings] autoThreshold → ${threshold}%`);
        set({ autoThreshold: threshold });
      },

      setVoiceEnabled: (enabled) => {
        AppLogger.info(`[Settings] voiceEnabled → ${enabled}`);
        set({ voiceEnabled: enabled });
      },

      toggleVoice: () => {
        const next = !get().voiceEnabled;
        AppLogger.info(`[Settings] voiceEnabled → ${next}`);
        set({ voiceEnabled: next });
      },

      setGestureEnabled: (enabled) => {
        AppLogger.info(`[Settings] gestureEnabled → ${enabled}`);
        set({ gestureEnabled: enabled });
      },

      toggleGesture: () => {
        const next = !get().gestureEnabled;
        AppLogger.info(`[Settings] gestureEnabled → ${next}`);
        set({ gestureEnabled: next });
      },

      setCountdownDuration: (duration) => {
        AppLogger.info(`[Settings] countdownDuration → ${duration}s`);
        set({ countdownDuration: duration });
      },

      setHapticEnabled: (enabled) => {
        AppLogger.info(`[Settings] hapticEnabled → ${enabled}`);
        set({ hapticEnabled: enabled });
      },

      toggleHaptic: () => {
        const next = !get().hapticEnabled;
        AppLogger.info(`[Settings] hapticEnabled → ${next}`);
        set({ hapticEnabled: next });
      },

      toggleVolumeShutter: () => {
        const next = !get().volumeShutterEnabled;
        AppLogger.info(`[Settings] volumeShutterEnabled → ${next}`);
        set({ volumeShutterEnabled: next });
      },

      setInstructionLanguage: (language) => {
        /* Resolved even here: the value arrives from UI today, but deep
           links/tests can call the action with anything. One gate, one
           behaviour — never persist a language the phrase banks lack. */
        const resolved = resolveInstructionLanguage(language);
        AppLogger.info(`[Settings] instructionLanguage → ${resolved}`);
        set({ instructionLanguage: resolved });
      },

      setVoiceId: (language, voiceId) => {
        AppLogger.info(
          `[Settings] voiceId[${language}] → ${voiceId ?? 'automatic'}`,
        );
        set({ voiceIds: { ...get().voiceIds, [language]: voiceId } });
      },

      resetToDefaults: () => {
        AppLogger.info('[Settings] reset all camera & capture preferences to defaults');
        set({ ...DEFAULT_CAMERA_SETTINGS });
      },
    }),
    {
      name: STORAGE_KEYS.settings,
      storage: createJSONStorage(() => mmkvStateStorage),
      /**
       * v2 (Unit 35) added `voiceIds`; v3 (Unit 37) renames `voiceLanguage`
       * → `instructionLanguage`. The RULES live in the platform-neutral
       * `migrateCameraSettings()` (shared/settings) so they are unit-tested
       * without a device; this store only supplies the storage seam.
       *
       * The migration never invents a voice identifier and never re-asks for
       * a language the user already chose: an existing 'en' stays 'en', and
       * only an install with no usable stored value lands on the new Hindi
       * default. Unrelated preferences pass through untouched.
       */
      version: SETTINGS_PERSIST_VERSION,
      migrate: (persisted, version) =>
        migrateCameraSettings(persisted, version) as Partial<CameraSettings>,
    },
  ),
);
