/**
 * Unit 23 — Global success snackbar service (single host, imperatively driven).
 * One host is mounted at the app root; any feature calls showSnackBar()
 * without owning local toast state. 'success' → green, 'primary' → blue.
 * Duration locked to 2s per spec; an optional single action is supported.
 */
import { create } from 'zustand';
import { AppLogger } from '@/core/utils/logger';

export type SnackBarVariant = 'success' | 'primary';

interface SnackBarOptions {
  readonly variant?: SnackBarVariant;
  readonly actionLabel?: string;
  readonly onAction?: () => void;
}

interface SnackBarState {
  readonly message: string | null;
  readonly variant: SnackBarVariant;
  readonly actionLabel: string | null;
  readonly onAction: (() => void) | null;
  readonly showSnackBar: (message: string, options?: SnackBarOptions) => void;
  readonly hideSnackBar: () => void;
}

const DURATION_MS = 2_000;
let hideTimer: ReturnType<typeof setTimeout> | null = null;
let sequence = 0;

export const useSnackBarStore = create<SnackBarState>((set, get) => ({
  message: null,
  variant: 'success',
  actionLabel: null,
  onAction: null,

  showSnackBar: (message, options) => {
    const requestId = ++sequence;
    if (hideTimer !== null) clearTimeout(hideTimer);
    set({
      message,
      variant: options?.variant ?? 'success',
      actionLabel: options?.actionLabel ?? null,
      onAction: options?.onAction ?? null,
    });
    hideTimer = setTimeout(() => {
      // A newer toast owns the slot; only the latest request may clear it.
      if (requestId === sequence) get().hideSnackBar();
    }, DURATION_MS);
  },

  hideSnackBar: () => {
    if (hideTimer !== null) {
      clearTimeout(hideTimer);
      hideTimer = null;
    }
    set({ message: null, actionLabel: null, onAction: null });
  },
}));

/** Spec-named public API — callable from any data layer or component. */
export function showSuccessSnackBar(message: string, options?: SnackBarOptions): void {
  useSnackBarStore.getState().showSnackBar(message, options);
  AppLogger.debug(`[SnackBar] ${options?.variant ?? 'success'} — ${message}`);
}
