/**
 * Theme preference store.
 *
 * Cold-start rule: do NOT import the native MMKV adapter while the first route
 * is rendering. The app starts with `system` immediately, then hydrates the
 * persisted choice after the first interaction frame. Writes remain durable.
 */
import { create } from 'zustand';
import { STORAGE_KEYS } from '@shared/constants/app';
import type { ThemeMode } from '@shared/types';
import { AppLogger } from '@/core/utils/logger';

interface ThemeState {
  readonly themeMode: ThemeMode;
  readonly setThemeMode: (mode: ThemeMode) => void;
}

let hydrationStarted = false;
let hydrationPromise: Promise<void> | null = null;

function parsePersistedTheme(raw: string | undefined): ThemeMode | null {
  if (!raw) return null;
  try {
    const parsed: unknown = JSON.parse(raw);
    const state = (parsed as { state?: unknown })?.state;
    const mode = (state as { themeMode?: unknown })?.themeMode;
    if (mode === 'system' || mode === 'light' || mode === 'dark') return mode;
    return null;
  } catch {
    return null;
  }
}

export const useThemeStore = create<ThemeState>((set, get) => ({
  themeMode: 'system',
  setThemeMode: (mode: ThemeMode) => {
    AppLogger.info(`[Theme] mode → ${mode}`);
    set({ themeMode: mode });
    void import('@/core/storage/storage')
      .then(({ storage }) => {
        storage.set(
          STORAGE_KEYS.themeMode,
          JSON.stringify({ state: { themeMode: mode }, version: 1 }),
        );
      })
      .catch((error) => {
        AppLogger.warn(`[Theme] persistence deferred - ${String(error)}`);
      });
  },
}));

export async function hydrateThemeStore(): Promise<void> {
  if (hydrationStarted) return hydrationPromise ?? Promise.resolve();
  hydrationStarted = true;
  hydrationPromise = import('@/core/storage/storage')
    .then(({ storage }) => {
      const mode = parsePersistedTheme(storage.getString(STORAGE_KEYS.themeMode));
      if (mode !== null && mode !== getCurrentThemeMode()) {
        useThemeStore.setState({ themeMode: mode });
      }
    })
    .catch((error) => {
      AppLogger.warn(`[Theme] hydration skipped - ${String(error)}`);
    });
  await hydrationPromise;
}

function getCurrentThemeMode(): ThemeMode {
  return useThemeStore.getState().themeMode;
}
