/**
 * delete-account — THE SECURE SERVER-SIDE DELETION BOUNDARY (B1).
 *
 * Deploy: `supabase functions deploy delete-account`
 * Invoke (from the app only): POST <project>/functions/v1/delete-account
 *   Authorization: Bearer <the caller's OWN user access token>
 *   Content-Type: application/json · Body: {}
 *
 * Why this exists:
 *   Removing an auth identity requires the Supabase ADMIN API, which in
 *   turn requires the service_role key. That key is privileged and must
 *   NEVER reach: React Native code, EXPO_PUBLIC_* env vars, client storage,
 *   repository source, or the preview. Supabase Edge Functions receive
 *   service credentials from THEIR runtime environment (auto-injected by
 *   the platform), so deletions run entirely behind this boundary.
 *
 * What it does (and nothing else):
 *   1. Verifies the CALLER: the request's bearer token must resolve to a
 *      live user (auth.getUser). A user can delete only themselves —
 *      there is no "delete someone else" path, no body parameters that
 *      widen scope.
 *   2. Deletes the identity via auth.admin.deleteUser(user.id).
 *   3. Application data cleanup is the DATABASE's job, not this code's:
 *      public.profiles and public.favorites reference auth.users with
 *      `on delete cascade` (mobile/supabase_tables.sql), so every
 *      associated application row is removed atomically with the identity.
 *      Nothing else in the schema is account-linked (photos never leave
 *      the device; that is a product invariant).
 *   4. Answers with the explicit ack contract the client requires:
 *      { "deleted": true, "userId": "<uuid>", "deletedAt": "<iso>" }
 *      The client treats ANYTHING ELSE (including bare 200s) as failure —
 *      this function therefore returns real status codes for every
 *      failure class.
 *
 * Retention: none. No rows are kept, archived or anonymized after this
 * runs. The function writes no logs containing user data beyond the id
 * it was asked to delete.
 *
 * Deno / Supabase Edge Runtime only. Never bundled into the app (it lives
 * outside mobile/src + mobile/app); the client reaches it over HTTPS with
 * a user token.
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const JSON_HEADERS = { "Content-Type": "application/json" } as const;

function failure(status: number, error: string): Response {
  return new Response(JSON.stringify({ deleted: false, error }), {
    status,
    headers: JSON_HEADERS,
  });
}

Deno.serve(async (request: Request): Promise<Response> => {
  if (request.method !== "POST") {
    return failure(405, "delete-account accepts POST only.");
  }

  // The caller proves identity with its own user token — nothing else.
  const authorization = request.headers.get("Authorization") ?? "";
  if (!authorization.startsWith("Bearer ")) {
    return failure(401, "A valid user session is required to delete an account.");
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !anonKey || !serviceRoleKey) {
    // Platform wiring missing — this is an operator error, not a client one.
    return failure(500, "Deletion boundary is not configured.");
  }

  // 1 · Verify the caller with THEIR token (scoped to the anon role).
  const callerClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { data: userData, error: userError } = await callerClient.auth.getUser();
  const caller = userData?.user ?? null;
  if (userError !== null || caller === null || caller.id.length === 0) {
    return failure(401, "The session is expired or invalid. Sign in again to delete the account.");
  }

  // 2 · Privileged step — server-side only. The service key lives in the
  //    Function's environment, injected by the platform at runtime.
  const adminClient = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { error: deleteError } = await adminClient.auth.admin.deleteUser(caller.id);
  if (deleteError !== null) {
    // Partial cleanup is possible downstream; the client only sees a clear
    // non-success and will not claim deletion happened. Retrying is safe:
    // deleting an already-deleted id is idempotent on success paths.
    console.error(
      `delete-account admin deletion failed for ${caller.id}: ${deleteError.message}`,
    );
    return failure(500, "The account could not be deleted right now. Nothing was confirmed as deleted.");
  }

  // 3 · Explicit ack — the ONLY payload the client accepts as success.
  console.log(`delete-account: identity removed for ${caller.id}`);
  return new Response(
    JSON.stringify({
      deleted: true,
      userId: caller.id,
      deletedAt: new Date().toISOString(),
    }),
    { status: 200, headers: JSON_HEADERS },
  );
});
