#!/usr/bin/env node
/**
 * scripts/preview-server.mjs — CODING-ENVIRONMENT PREVIEW HOST ONLY.
 *
 * ⚠ NOT the application. The product is `mobile/` (React Native + Expo).
 * This is a ~100-line static file server whose only jobs are:
 *   · serve the Vite preview bundle built into `dist/` (`npm run build`), and
 *   · answer the hosting sandbox's `/api/health` probe so the preview counts
 *     as "up".
 *
 * Zero dependencies (node:http + node:fs), zero production code, never
 * bundled: Metro watches `mobile/` + `shared/` only. Deleting this file
 * removes nothing from the app.
 */
import { createServer } from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { dirname, extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const DIST = resolve(ROOT, 'dist');
const PORT = Number.parseInt(process.env.PORT ?? '3000', 10);
const HOST = process.env.HOST ?? '0.0.0.0';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.wasm': 'application/wasm',
  '.txt': 'text/plain; charset=utf-8',
};

function safeJoin(base, requestPath) {
  const decoded = decodeURIComponent(requestPath.split('?')[0] ?? '/');
  const candidate = normalize(join(base, decoded));
  return candidate.startsWith(base) ? candidate : base;
}

function sendFile(res, filePath) {
  res.writeHead(200, {
    'Content-Type': MIME[extname(filePath).toLowerCase()] ?? 'application/octet-stream',
    'Cache-Control': 'no-store',
  });
  createReadStream(filePath).pipe(res);
}

const server = createServer((req, res) => {
  const url = req.url ?? '/';

  if (url === '/api/health' || url.startsWith('/api/health?')) {
    const distReady = existsSync(resolve(DIST, 'index.html'));
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(
      JSON.stringify({
        status: 'ok',
        role: 'coding-environment preview host',
        app: 'mobile/ (React Native + Expo) — not served by this process',
        previewBundle: distReady ? 'built' : 'missing (run npm run build)',
        uptimeSeconds: Math.round(process.uptime()),
      }),
    );
    return;
  }

  let filePath = safeJoin(DIST, url);
  if (existsSync(filePath) && statSync(filePath).isDirectory()) {
    filePath = join(filePath, 'index.html');
  }
  if (!existsSync(filePath) || !statSync(filePath).isFile()) {
    /* Single-page preview: unknown paths fall back to the bundle. */
    filePath = resolve(DIST, 'index.html');
  }
  if (!existsSync(filePath)) {
    res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Preview bundle not built yet — run `npm run build`.\n');
    return;
  }
  sendFile(res, filePath);
});

server.listen(PORT, HOST, () => {
  process.stdout.write(`Preview host listening on http://${HOST}:${PORT} (health: /api/health)\n`);
});
