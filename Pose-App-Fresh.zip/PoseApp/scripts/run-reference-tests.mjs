#!/usr/bin/env node
/**
 * scripts/run-reference-tests.mjs — deterministic unit tests for the
 * reference-pose foundation (shared/reference).
 *
 * Design notes:
 *   · Zero new dependencies: the official typescript install already in this
 *     repo compiles shared/+tests/ to CommonJS, then the Node built-in
 *     runner (`node --test`, Node ≥ 18) executes the emitted files.
 *   · Deterministic: fixed fixtures, fixed discovery order, no network, no
 *     randomness, no clock dependence.
 *   · Usable from a fresh ZIP: run `npm install` at the root (tooling deps),
 *     then `npm test`.
 */
import { existsSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const HERE = dirname(fileURLToPath(import.meta.url));
const WORKSPACE = resolve(HERE, '..');
const OUT_DIR = resolve(WORKSPACE, '.test-build');

const tscCandidates = [
  resolve(WORKSPACE, 'node_modules/typescript/bin/tsc'),
  resolve(WORKSPACE, 'mobile/node_modules/typescript/bin/tsc'),
];
const tsc = tscCandidates.find((p) => existsSync(p));
if (!tsc) {
  process.stderr.write('✗ typescript not found — run npm install at the repo root.\n');
  process.exit(1);
}

function step(label, cmd, args) {
  process.stdout.write(`\n▶ ${label}\n${'─'.repeat(60)}\n`);
  const result = spawnSync(cmd, args, { cwd: WORKSPACE, stdio: 'inherit' });
  if (result.status !== 0) {
    process.stderr.write(`\n✗ ${label} failed (exit ${result.status}).\n`);
    process.exit(result.status ?? 1);
  }
  process.stdout.write(`✓ ${label}\n`);
}

/* Clean build container (gitignored) so stale emitted tests can never
   masquerade as current ones. */
rmSync(OUT_DIR, { recursive: true, force: true });

step('Compile shared/ + tests/ (tsc -p tsconfig.tests.json)', process.execPath, [tsc, '-p', 'tsconfig.tests.json']);

/* The workspace root package.json declares "type": "module" (preview
   tooling); the emitted tests are CommonJS. Scoping a package.json inside
   the build container restores CommonJS treatment for emitted .js files. */
writeFileSync(resolve(OUT_DIR, 'package.json'), JSON.stringify({ type: 'commonjs' }));

/* Node ≥ 22.19 no longer expands a bare directory argument for `node --test`
   (it is resolved as a module path and fails with MODULE_NOT_FOUND), so the
   emitted test files are discovered here instead — sorted, therefore still
   deterministic, and independent of the Node version in use. */
function collectTests(dir) {
  const found = [];
  for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) =>
    a.name.localeCompare(b.name),
  )) {
    const full = resolve(dir, entry.name);
    if (entry.isDirectory()) found.push(...collectTests(full));
    else if (entry.name.endsWith('.test.js')) found.push(full);
  }
  return found;
}

const testFiles = collectTests(resolve(OUT_DIR, 'tests'));
if (testFiles.length === 0) {
  process.stderr.write('✗ no compiled test files found in .test-build/tests.\n');
  process.exit(1);
}

step('Run reference-domain unit tests (node --test)', process.execPath, [
  '--test',
  ...testFiles,
]);

process.stdout.write('\n✓ Reference-foundation tests PASS.\n');
