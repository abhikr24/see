import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const checks = [
  ['mobile/app.json', true],
  ['mobile/package.json', true],
  ['mobile/package-lock.json', true],
  ['mobile/eas.json', true],
  ['mobile/assets/icon/app-icon-store.png', true],
  ['mobile/assets/splash/splash-icon.png', true],
  ['mobile/native/vision-camera-mlkit-pose/android/build.gradle', true],
  ['mobile/native/vision-camera-mlkit-pose/android/src/main/java/com/margelo/nitro/visioncameramlkitpose/HybridPoseDetector.kt', true],
  ['mobile/android/gradlew', true],
  ['shared/index.ts', true],
];
let failed = false;
for (const [rel, required] of checks) {
  const ok = fs.existsSync(path.join(root, rel));
  console.log(`${ok ? 'PASS' : 'FAIL'} ${rel}`);
  if (required && !ok) failed = true;
}
const app = JSON.parse(fs.readFileSync(path.join(root, 'mobile/app.json'), 'utf8'));
for (const rel of [app.expo.icon, app.expo.plugins.find(p => Array.isArray(p) && p[0] === 'expo-splash-screen')?.[1]?.image]) {
  if (!rel) continue;
  const abs = path.resolve(root, 'mobile', rel);
  const ok = fs.existsSync(abs);
  console.log(`${ok ? 'PASS' : 'FAIL'} config asset ${rel}`);
  if (!ok) failed = true;
}
const gradle = fs.readFileSync(path.join(root, 'mobile/native/vision-camera-mlkit-pose/android/build.gradle'), 'utf8');
const expected = 'namespace "com.margelo.nitro.visioncameramlkitpose"';
if (gradle.includes(expected)) console.log('PASS native namespace matches Kotlin package');
else { console.log('FAIL native namespace mismatch'); failed = true; }
const detector = fs.readFileSync(path.join(root, 'mobile/native/vision-camera-mlkit-pose/android/src/main/java/com/margelo/nitro/visioncameramlkitpose/HybridPoseDetector.kt'), 'utf8');
for (const needle of ['PoseDetection.getClient', 'AccuratePoseDetectorOptions', 'NativePoseFrame']) {
  const ok = detector.includes(needle);
  console.log(`${ok ? 'PASS' : 'FAIL'} native detector contains ${needle}`);
  if (!ok) failed = true;
}
if (failed) process.exit(1);
console.log('STATIC PART-2 CHECKS PASSED');
console.log('NOTE: This script does not claim an Android Gradle/APK build succeeded.');
