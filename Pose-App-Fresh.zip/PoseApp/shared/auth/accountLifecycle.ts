/**
 * shared/auth/accountLifecycle.ts — platform-neutral ACCOUNT LIFECYCLE
 * decisions: account deletion + password recovery.
 *
 * Why this module exists (and lives in THE BRAIN next to authFlow.ts):
 *   · Apple App Store Review Guideline 5.1.1(v) requires in-app account
 *     deletion initiation wherever account creation is offered; Google Play
 *     requires an in-app path plus policy-safe associated-data deletion.
 *   · Both flows must feel identical in demo and production, must never
 *     report success the backend did not confirm, and must keep the exact
 *     distinction between LOGGED OUT and ACCOUNT DELETED.
 *   · Every decision is encoded once here so the Expo app, the browser
 *     preview mirror and node --test coverage consume THE SAME logic.
 *
 * Pure TypeScript. No React, no React Native, no DOM, no storage, no fetch.
 *
 * What this module deliberately does NOT do:
 *   · It never holds, names or implies privileged credentials. The
 *     service_role operation lives ONLY in the server-side deletion
 *     boundary (mobile/supabase/functions/delete-account/index.ts).
 *   · It makes no production-readiness claims: real deletion and real
 *     recovery email REQUIRE the future Supabase project (see
 *     mobile/docs/account-deletion-and-password-reset.md).
 */

import { MIN_PASSWORD_LENGTH, normalizeEmail, emailError } from "./authFlow";

/* ════════════════════════════════════════════════════════════════════════
 * PART 1 — ACCOUNT DELETION
 * ════════════════════════════════════════════════════════════════════════ */

/** Typed confirmation: deletion is armed only when the user types DELETE. */
export const DELETE_CONFIRMATION_PHRASE = "DELETE";

export function deleteConfirmationError(typed: string): string | null {
  return typed.trim() === DELETE_CONFIRMATION_PHRASE
    ? null
    : `Type ${DELETE_CONFIRMATION_PHRASE} to enable the delete button.`;
}

/**
 * THE ACCOUNT DATA MODEL — every surface touched (or explicitly not
 * touched) when an account is deleted. This table IS the deletion data
 * model: the mobile cleanup orchestrator, the Edge Function contract and
 * the docs all derive from it, so they can never drift.
 *
 * Action legend
 *   · "delete"      — removed when the account is removed
 *   · "cascade"     — removed automatically by the database when the auth
 *                     identity is deleted (on delete cascade in
 *                     mobile/supabase_tables.sql — already in place)
 *   · "clear-local" — account-scoped on-device state removed by the app
 *                     after the backend confirms deletion
 *   · "keep"        — PRESERVED ON PURPOSE with the reason documented,
 *                     never silently (Google Play policy requires
 *                     associated data deletion; only genuinely
 *                     non-account-scoped device data survives)
 *
 * Retention position: NOTHING is retained server-side after deletion.
 * No legitimate-retention exception is claimed anywhere in this product.
 * Supabase's own infrastructure may hold immutable provider-side
 * audit/backup logs for a short provider-controlled window — that is the
 * platform's retention, documented here rather than invented as a product
 * requirement.
 */
export type DeletionSurface = "server" | "local" | "device";
export type DeletionAction = "delete" | "cascade" | "clear-local" | "keep";

export interface DeletionScopeItem {
  readonly key: string;
  readonly label: string;
  readonly surface: DeletionSurface;
  readonly action: DeletionAction;
  readonly reason: string;
}

export const DELETION_DATA_SCOPE: readonly DeletionScopeItem[] = [
  {
    key: "auth-identity",
    label: "Sign-in identity",
    surface: "server",
    action: "delete",
    reason:
      "The auth.users row is removed by the secure server-side deletion " +
      "boundary using the admin API. The mobile app never receives the " +
      "privileged key required for this operation.",
  },
  {
    key: "profile-row",
    label: "Profile metadata (name, email, avatar URL)",
    surface: "server",
    action: "cascade",
    reason:
      "public.profiles references auth.users with on delete cascade " +
      "(supabase_tables.sql) — removing the identity removes the row.",
  },
  {
    key: "favorites-rows",
    label: "Favorites cloud sync rows",
    surface: "server",
    action: "cascade",
    reason:
      "public.favorites references auth.users with on delete cascade. " +
      "Nothing else in the schema is account-linked.",
  },
  {
    key: "favorites-local-replica",
    label: "Favorites replica cached on this device",
    surface: "local",
    action: "clear-local",
    reason:
      "The local replica and its durable offline queue are account-scoped " +
      "(ownerId / *ByUser buckets) — the deleted account's buckets are " +
      "dropped; other accounts' buckets are untouched.",
  },
  {
    key: "gallery-app-captures",
    label: "In-app captures (files + metadata) saved by this account",
    surface: "local",
    action: "clear-local",
    reason:
      "Captures are written to a per-account directory and an MMKV " +
      "namespace keyed by the account id — the existing product associates " +
      "them with the account, so they are removed with it (same behavior " +
      "as Settings → Clear All Data for this account).",
  },
  {
    key: "session-tokens",
    label: "Sign-in session tokens",
    surface: "local",
    action: "clear-local",
    reason:
      "Supabase session storage and any demo session record are cleared " +
      "AFTER backend deletion is confirmed, ending the session honestly.",
  },
  {
    key: "system-gallery-photos",
    label: "Photos already exported to the device gallery",
    surface: "device",
    action: "keep",
    reason:
      "These are the user's own files outside app storage. The standing " +
      "product invariant ('Photos stay on-device; device gallery photos are " +
      "never touched') keeps them — deleting unrelated personal files on " +
      "account removal would be destructive and wrong.",
  },
  {
    key: "app-settings",
    label: "App preferences (theme, camera defaults, coaching language...)",
    surface: "device",
    action: "keep",
    reason:
      "Global application settings are DEVICE-level, never synced to any " +
      "account. They must not be collateral damage of account deletion.",
  },
  {
    key: "device-history",
    label: "Recent poses & search history on this device",
    surface: "device",
    action: "keep",
    reason:
      "Device-only browsing history (local LRU stores) — not " +
      "account-associated anywhere in the product's data model and never " +
      "uploaded. Preserved and documented rather than silently wiped.",
  },
  {
    key: "onboarding-flags",
    label: "Onboarding / permission flags",
    surface: "device",
    action: "keep",
    reason:
      "Device-level product flags, identical to the existing Clear All " +
      "Data behavior — they are not account data.",
  },
];

/** Server-side rows that MUST be gone for deletion to be honest. */
export const SERVER_DELETION_KEYS: readonly string[] = DELETION_DATA_SCOPE.filter(
  (item) => item.surface === "server",
).map((item) => item.key);

/* ── Server response classification — NO FALSE SUCCESS, EVER ────────────
 * The HTTP exchange with the deletion boundary is reduced to an exhaustive
 * union. Only `{ kind: "deleted" }` may ever become user-visible success;
 * the store treats every other variant as a failure that LEAVES THE SESSION
 * INTACT. A 200 response whose body does not explicitly confirm deletion is
 * NOT success (distinguishes "unexpected-response" from "deleted").
 */

export type DeletionServerOutcome =
  /** Backend confirms the identity and cascaded rows are gone. */
  | { readonly kind: "deleted"; readonly deletedAt: string | null }
  /** 401/403 — session expired or not the account owner. */
  | { readonly kind: "unauthorized" }
  /** 4xx other — the boundary refused the request (e.g. 409 conflict). */
  | { readonly kind: "rejected"; readonly detail: string }
  /** 5xx — the boundary or Supabase admin call failed. Partial cleanup may
   *  exist on the server side; the app MUST NOT report success. Retry-safe:
   *  the endpoint is idempotent for an already-deleted caller. */
  | { readonly kind: "backend-failure" }
  /** Transport-level failure (offline, DNS, TLS). */
  | { readonly kind: "network" }
  /** The request exceeded DELETE_ACCOUNT_TIMEOUT_MS. */
  | { readonly kind: "timeout" }
  /** HTTP 200 but the body did not CONFIRM deletion. Never success. */
  | { readonly kind: "unexpected-response" };

/** Bounded wait for the deletion boundary — no infinite spinner. */
export const DELETE_ACCOUNT_TIMEOUT_MS = 15_000;

/** The success contract the client requires from the server body. */
interface DeletionAck {
  readonly deleted: boolean;
  readonly deletedAt?: string | null;
}

function parseDeletionAck(bodyText: string | null): DeletionAck | null {
  if (bodyText === null || bodyText.trim().length === 0) return null;
  try {
    const parsed: unknown = JSON.parse(bodyText);
    if (typeof parsed !== "object" || parsed === null) return null;
    const ack = parsed as Record<string, unknown>;
    // Exactly the documented contract: boolean flag + optional timestamp.
    if (typeof ack.deleted !== "boolean") return null;
    return {
      deleted: ack.deleted,
      deletedAt: typeof ack.deletedAt === "string" ? ack.deletedAt : null,
    };
  } catch {
    return null;
  }
}

function rejectionDetail(bodyText: string | null): string {
  if (bodyText === null) return "Deletion was refused by the server.";
  const ack = parseDeletionAck(bodyText);
  if (typeof (ack as Record<string, unknown> | null)?.error === "string") {
    return String((ack as unknown as Record<string, unknown>).error);
  }
  try {
    const parsed: unknown = JSON.parse(bodyText);
    if (
      typeof parsed === "object" &&
      parsed !== null &&
      typeof (parsed as Record<string, unknown>).error === "string"
    ) {
      return (parsed as Record<string, unknown>).error as string;
    }
  } catch {
    /* plain-text or non-JSON body — fall through to generic copy */
  }
  return "Deletion was refused by the server.";
}

/**
 * Maps the raw HTTP exchange to the exhaustive outcome union.
 * `httpStatus === null` means the request never received a response
 * (the transport error was already classified by the caller).
 */
export function classifyDeletionHttpResponse(
  httpStatus: number | null,
  bodyText: string | null,
): DeletionServerOutcome {
  if (httpStatus === null) return { kind: "network" };
  if (httpStatus === 401 || httpStatus === 403) return { kind: "unauthorized" };
  if (httpStatus >= 200 && httpStatus < 300) {
    const ack = parseDeletionAck(bodyText);
    // Success requires an EXPLICIT confirmation — a bare 200 is not proof.
    if (ack !== null && ack.deleted === true) {
      return { kind: "deleted", deletedAt: ack.deletedAt ?? null };
    }
    return { kind: "unexpected-response" };
  }
  if (httpStatus >= 400 && httpStatus < 500) {
    return { kind: "rejected", detail: rejectionDetail(bodyText) };
  }
  return { kind: "backend-failure" };
}

/**
 * Classifies a fetch() throw. The abort/timeout sentinel the client throws
 * is `DeleteAccountTimeoutError`-shaped ({ name: "TimeoutError" } or the
 * DOMException AbortError we convert locally); plain network types map to
 * network. Everything unusual degrades to "network" (retryable, still not
 * success).
 */
export function classifyDeletionTransportError(error: unknown): DeletionServerOutcome {
  const name =
    typeof error === "object" && error !== null && "name" in error
      ? String((error as { name?: unknown }).name)
      : "";
  if (name === "TimeoutError" || name === "AbortError") return { kind: "timeout" };
  return { kind: "network" };
}

/* ── Demo deletion — honest, safe, never a production fallback ───────────
 * In demo mode there is no server, so "deletion" is exactly: remove the
 * persisted demo session + the same account-scoped local cleanup. The UI
 * labels it as demo behavior via ACCOUNT_DELETE_COPY.demoNote, and the
 * store returns "deleted" only after that LOCAL cleanup succeeded. Demo
 * deletion code paths are never reachable when isBackendConfigured is true
 * (the repository branches on isDemoMode, which also implies __DEV__).
 */

/* ════════════════════════════════════════════════════════════════════════
 * PART 2 — PASSWORD RECOVERY
 * ════════════════════════════════════════════════════════════════════════ */

/**
 * Where the recovery email's link must bring the user. Centralized so the
 * future Supabase dashboard config is one documented constant, not a string
 * scattered through the flow. The concrete URL is derived from THIS app
 * (scheme/host) by mobile/src/core/auth/authLinks.ts — never a hardcoded
 * fake production domain.
 */
export const PASSWORD_RESET_ROUTE = "auth/reset-password";

/**
 * Exhaustive deep-link reading for auth. The app receives exactly two kinds
 * of Supabase auth links — OAuth completion and password recovery — and
 * nothing else may ever be fed to the PKCE/implicit token exchange.
 *
 *   · "recovery"    — password-repair link (path is the reset route, or an
 *                     explicit type=recovery is present). `code` carries the
 *                     PKCE verifier when the link used the code flow
 *                     (detectSessionInUrl is false in this app — the code
 *                     exchange is performed by the repository listener).
 *   · "oauth-code"  — OAuth round-trip code on the plain /auth redirect.
 *   · "unrelated"   — any other URL. MUST be ignored by the auth pipeline.
 */
export type AuthDeepLink =
  | { readonly kind: "recovery"; readonly code: string | null }
  | { readonly kind: "oauth-code"; readonly code: string }
  | { readonly kind: "unrelated" };

/** Hand-rolled param extraction — platform-neutral, dependency-free, so it
 *  behaves identically in the app, the mirror and node --test. Handles both
 *  ?query and #fragment (implicit flow places tokens in the hash). */
function readParams(segment: string): ReadonlyMap<string, string> {
  const params = new Map<string, string>();
  if (segment.length === 0) return params;
  for (const pair of segment.split("&")) {
    if (pair.length === 0) continue;
    const eq = pair.indexOf("=");
    const rawKey = eq === -1 ? pair : pair.slice(0, eq);
    const rawValue = eq === -1 ? "" : pair.slice(eq + 1);
    try {
      params.set(decodeURIComponent(rawKey), decodeURIComponent(rawValue.replace(/\+/g, " ")));
    } catch {
      params.set(rawKey, rawValue);
    }
  }
  return params;
}

export function classifyAuthDeepLink(url: string): AuthDeepLink {
  if (typeof url !== "string" || url.trim().length === 0) return { kind: "unrelated" };
  const trimmed = url.trim();
  const hashIndex = trimmed.indexOf("#");
  const beforeHash = hashIndex === -1 ? trimmed : trimmed.slice(0, hashIndex);
  const hashSegment = hashIndex === -1 ? "" : trimmed.slice(hashIndex + 1);
  const queryIndex = beforeHash.indexOf("?");
  const pathPart = (queryIndex === -1 ? beforeHash : beforeHash.slice(0, queryIndex)).toLowerCase();
  const querySegment = queryIndex === -1 ? "" : beforeHash.slice(queryIndex + 1);
  const query = readParams(querySegment);
  const fragment = readParams(hashSegment);
  const code = query.get("code") ?? fragment.get("code") ?? null;
  const type = query.get("type") ?? fragment.get("type") ?? null;

  const isRecovery =
    type === "recovery" || pathPart.includes(PASSWORD_RESET_ROUTE);
  if (isRecovery) return { kind: "recovery", code };
  if (code !== null && code.length > 0) return { kind: "oauth-code", code };
  return { kind: "unrelated" };
}

/* ── Reset-screen state machine ──────────────────────────────────────────
 * Three honest entry surfaces. The screen NEVER invents a fourth:
 *
 *   · "request-link"      — user tapped "Forgot password?" (or opened the
 *                           route without recovery intent): show the email
 *                           request form.
 *   · "new-password"      — a live recovery session exists (PASSWORD_RECOVERY
 *                           from Supabase, or demo recovery flag): show the
 *                           new-password form.
 *   · "link-invalid"      — user ARRIVED via a recovery link (deep-link
 *                           intent recorded) but no recovery session was
 *                           established: the link expired, was already used,
 *                           or is malformed. Explain + offer "send a new
 *                           link" instead of silently showing the request
 *                           form (which would hide the failure).
 *
 * Loop-safety: the screen has NO automatic navigation on session changes —
 * the only exit is an explicit user action after success (Continue). A
 * recovery session appearing can therefore never fight an auth redirect.
 */
export type ResetPasswordEntry =
  | { readonly kind: "request-link" }
  | { readonly kind: "new-password" }
  | { readonly kind: "link-invalid" };

export function resolveResetPasswordEntry(
  hasLiveRecoverySession: boolean,
  arrivedViaRecoveryLink: boolean,
): ResetPasswordEntry {
  if (hasLiveRecoverySession) return { kind: "new-password" };
  if (arrivedViaRecoveryLink) return { kind: "link-invalid" };
  return { kind: "request-link" };
}

/**
 * After a successful password update the recovery session IS a normal
 * session — the user is signed in. The single, predictable destination is
 * the tab shell (same fallback every authenticated flow in the app uses).
 * No route here can bounce back to /auth: the reset screen performs no
 * automatic exits.
 */
export const POST_RESET_DESTINATION = "/(tabs)";

/* ── New-password form policy ────────────────────────────────────────────
 * Length policy is the existing shared rule (MIN_PASSWORD_LENGTH). A new
 * password equal to… nothing client-side: we never know the old one client
 * side, and Supabase enforces any server-side rules by returning an error
 * the flow surfaces verbatim.
 */

export interface ResetFormValues {
  readonly password: string;
  readonly confirmPassword: string;
}

export interface ResetFormErrors {
  readonly password: string | null;
  readonly confirmPassword: string | null;
}

export function validateResetForm(values: ResetFormValues): {
  readonly errors: ResetFormErrors;
  readonly submittable: boolean;
} {
  const password =
    values.password.length >= MIN_PASSWORD_LENGTH
      ? null
      : `New password must contain at least ${MIN_PASSWORD_LENGTH} characters.`;
  const confirmPassword =
    password === null && values.confirmPassword !== values.password
      ? "Passwords do not match."
      : null;
  const errors: ResetFormErrors = { password, confirmPassword };
  return {
    errors,
    submittable: errors.password === null && errors.confirmPassword === null,
  };
}

/** The recovery email request form: normalize + validate only. */
export function recoveryRequestEmailError(rawEmail: string): string | null {
  return emailError(normalizeEmail(rawEmail));
}

/* ── Recovery-session consistency policies ───────────────────────────────
 * Sequences that must leave the app in a consistent state, encoded so the
 * tests pin them and both implementations behave identically.
 */

/**
 * Whether an active password-repair context survives a sign-out/sign-in
 * change. Answer: NEVER. Any session transition closes the recovery
 * context — otherwise "logout during recovery" could resurrect a secure
 * surface for a different user later.
 */
export function recoverySessionSurvivesSessionChange(): false {
  return false;
}

/**
 * Account-existence neutrality: the request-acknowledgement copy is
 * IDENTICAL whether the email is registered, deleted, or imaginary.
 * Supabase resetPasswordForEmail() itself does not error for unknown
 * emails — this flag pins the product decision so a future "improvement"
 * can't start leaking registration state for deleted or unknown accounts.
 */
export function recoveryAckIsAccountExistenceNeutral(): true {
  return true;
}
