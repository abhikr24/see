/**
 * shared/auth/authFlow.ts — platform-neutral auth-screen decisions.
 *
 * The single source of truth for HOW the /auth screen behaves: which state it
 * enters, when (and ONLY when) it may navigate away on its own, and how the
 * email/password form validates. Consumed by:
 *   · mobile/  — the Expo /auth screen + the Zustand auth store
 *   · tooling/preview/ — the browser mirror (same decisions, honest copy)
 *   · tests/   — node --test regression coverage for the Create-Account bug
 *
 * Pure TypeScript. No React, no React Native, no DOM, no storage.
 *
 * ── The Create-Account regression this module exists to pin down ──────────
 * The old /auth screen ran `useEffect(() => { if (session) exit(); })` which
 * ALSO fires on mount. With a persisted demo session present, opening /auth
 * bounced the user straight back to /(tabs) before the signup form could ever
 * remain visible. The rules below make that class of bounce unrepresentable:
 * a session that already existed when the screen opened is rendered as an
 * explicit "already signed in" state — navigation only ever follows an auth
 * action the user just completed on this screen.
 */

/* ── Modes & entry ─────────────────────────────────────────────────────── */

export type AuthScreenMode = "sign-in" | "sign-up";

/**
 * Deep-link intent: /auth?mode=sign-up must open the form directly in
 * account-creation mode. Anything unrecognized falls back to sign-in.
 */
export function parseAuthModeParam(raw: string | string[] | undefined | null): AuthScreenMode {
  const value = Array.isArray(raw) ? raw[0] : raw;
  return value === "sign-up" ? "sign-up" : "sign-in";
}

export type AuthEntryState =
  | { readonly kind: "form"; readonly mode: AuthScreenMode }
  | { readonly kind: "already-signed-in" };

/**
 * What /auth shows when it opens.
 * An EXISTING session is never bounced away silently (the reported bug) and
 * never shown a pretend-logged-out signup form — it becomes an explicit,
 * understood "already signed in" state with a Continue action.
 */
export function resolveAuthEntry(
  hasSessionAtEntry: boolean,
  requestedMode: AuthScreenMode,
): AuthEntryState {
  if (hasSessionAtEntry) return { kind: "already-signed-in" };
  return { kind: "form", mode: requestedMode };
}

/**
 * The ONLY automatic navigation the /auth screen may perform in reaction to
 * a session change: the user initiated OAuth from THIS screen (no session at
 * entry) and a session now exists because the browser round-trip completed.
 * A session that was already there at entry → false (no silent exit).
 * A restored session appearing unprompted mid-visit → false: the screen
 * re-renders its "already signed in" state instead of navigating.
 */
export function shouldExitAfterSessionChange(
  hadSessionAtEntry: boolean,
  hasSessionNow: boolean,
  oauthInitiatedHere: boolean,
): boolean {
  if (hadSessionAtEntry) return false;
  return hasSessionNow && oauthInitiatedHere;
}

/* ── Field validation ──────────────────────────────────────────────────── */

export const MIN_PASSWORD_LENGTH = 8;

export const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Emails are trimmed and lower-cased everywhere before use or comparison. */
export function normalizeEmail(raw: string): string {
  return raw.trim().toLowerCase();
}

export const AUTH_EMAIL_ERROR = "Enter a valid email address.";
export const AUTH_PASSWORD_ERROR = `Password must contain at least ${MIN_PASSWORD_LENGTH} characters.`;
export const AUTH_CONFIRM_ERROR = "Passwords do not match.";
export const AUTH_NAME_ERROR = "Use at least 2 characters, or leave the name empty.";

export function emailError(raw: string): string | null {
  const email = normalizeEmail(raw);
  return EMAIL_PATTERN.test(email) ? null : AUTH_EMAIL_ERROR;
}

/**
 * Passwords are never trimmed or altered — a space may be intentional.
 * Length is the only client-side policy; the backend may add its own rules
 * and its message is surfaced verbatim in that case.
 */
export function passwordError(password: string): string | null {
  return password.length >= MIN_PASSWORD_LENGTH ? null : AUTH_PASSWORD_ERROR;
}

export function confirmPasswordError(password: string, confirm: string): string | null {
  return confirm === password ? null : AUTH_CONFIRM_ERROR;
}

/** Display name is OPTIONAL — empty is valid; provided-and-tiny is not. */
export function displayNameError(raw: string): string | null {
  const trimmed = raw.trim();
  if (trimmed.length === 0) return null;
  return trimmed.length >= 2 ? null : AUTH_NAME_ERROR;
}

export interface AuthFormValues {
  readonly displayName: string;
  readonly email: string;
  readonly password: string;
  readonly confirmPassword: string;
}

export interface AuthFormErrors {
  readonly displayName: string | null;
  readonly email: string | null;
  readonly password: string | null;
  readonly confirmPassword: string | null;
}

export const NO_FORM_ERRORS: AuthFormErrors = {
  displayName: null,
  email: null,
  password: null,
  confirmPassword: null,
};

/**
 * Whole-form validation prior to submission. Sign-in validates email +
 * password only; sign-up additionally validates the optional display name
 * and the confirmation field. Returns true on `errors` when submittable.
 */
export function validateAuthForm(
  mode: AuthScreenMode,
  values: AuthFormValues,
): { readonly errors: AuthFormErrors; readonly submittable: boolean } {
  const errors: AuthFormErrors = {
    displayName: mode === "sign-up" ? displayNameError(values.displayName) : null,
    email: emailError(values.email),
    password: passwordError(values.password),
    confirmPassword:
      mode === "sign-up" ? confirmPasswordError(values.password, values.confirmPassword) : null,
  };
  const submittable =
    errors.displayName === null &&
    errors.email === null &&
    errors.password === null &&
    errors.confirmPassword === null;
  return { errors, submittable };
}

/* ── Outcome classification ────────────────────────────────────────────── */

/**
 * Auth failure codes shared by the real Supabase mapping and the demo
 * repository, so the UI treatment never drifts between the two backends.
 */
export type AuthIssueCode =
  | "invalid-credentials"
  | "email-in-use"
  | "email-not-confirmed"
  | "weak-password"
  | "cancelled"
  | "not-configured"
  | "network"
  /** No active session for an operation that requires one, or the session
   *  expired mid-flow (e.g. account deletion re-authentication). */
  | "session-required"
  /** The secure backend boundary (or Supabase itself) failed or is
   *  unavailable — distinct from a client network problem. */
  | "server-unavailable"
  /** The request exceeded its time budget without a server verdict. */
  | "timeout"
  /** Password-recovery link expired, already used, or malformed. */
  | "recovery-expired"
  | "unknown";

export type AuthIssueTreatment =
  /** Show as an inline form error on the current screen. */
  | "form-error"
  /** Account exists but needs email confirmation — dedicated state, NOT an error. */
  | "confirmation-required";

/**
 * signUp() can succeed WITHOUT a session when the backend requires email
 * confirmation. That is a successful account creation, and the UI must treat
 * it as a clear confirmation state — not a red error, and absolutely not a
 * navigation into the app (no session exists yet).
 */
export function treatmentForAuthIssue(code: AuthIssueCode): AuthIssueTreatment {
  return code === "email-not-confirmed" ? "confirmation-required" : "form-error";
}

/** Supabase-side duplicate-account phrases the repository maps to email-in-use. */
export function isDuplicateEmailMessage(message: string): boolean {
  const normalized = message.toLowerCase();
  return (
    normalized.includes("already registered") ||
    normalized.includes("already in use") ||
    normalized.includes("user already exists")
  );
}
