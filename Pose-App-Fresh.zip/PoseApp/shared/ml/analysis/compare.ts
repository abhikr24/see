/**
 * shared/ml/analysis/compare.ts — Unit 29, stages 2–5:
 * MEASUREMENTS → COMPARISON → ERROR → CONFIDENCE → SEVERITY.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * One comparison per registered measurement, every frame, in canonical
 * registry order. Each comparison states EVERYTHING a downstream stage could
 * need — measurement id, reference value, live value, signed error, absolute
 * error, direction, severity, confidence, availability and validity — so no
 * later stage has to recompute (and possibly re-decide) any of it.
 *
 * The SIGNED error is the load-bearing field: direction is its sign. It is
 * never collapsed to an absolute value on the way through.
 */
import {
  DEFAULT_ANALYSIS_THRESHOLDS,
  type AnalysisThresholds,
} from "./thresholds";
import type { SessionReference } from "./sessionReference";
import type {
  ComparisonSeverity,
  ComparisonValidity,
  CorrectionDirection,
  LiveMeasurement,
  MeasurementComparison,
} from "./types";

/**
 * Severity ladder. Monotone by construction: a larger |error| can never map
 * to a lower rung.
 *   |e| <  tolerance           → within-tolerance
 *   |e| >= tolerance, <= band  → minor
 *   |e| >  band                → major
 */
export function severityFor(
  absError: number,
  thresholds: AnalysisThresholds = DEFAULT_ANALYSIS_THRESHOLDS,
): ComparisonSeverity {
  if (absError < thresholds.goodToleranceDegrees) return "within-tolerance";
  if (absError <= thresholds.correctionThresholdDegrees) return "minor";
  return "major";
}

/** Numeric rank for ordering; higher = worse. */
export function severityRank(severity: ComparisonSeverity): number {
  switch (severity) {
    case "major":
      return 2;
    case "minor":
      return 1;
    case "within-tolerance":
      return 0;
  }
}

/** Direction from the sign of (live − reference). Threshold-independent. */
export function directionFor(signedError: number): CorrectionDirection {
  if (signedError < 0) return "increase";
  if (signedError > 0) return "decrease";
  return "none";
}

/**
 * Combined belief in a comparison. The live side is measured every frame; the
 * reference side is a CLAIM which may be absent (`null` = "no claim made",
 * e.g. a hand-authored category stance). A missing claim must not be read as
 * zero confidence and must not be inflated to 1 either — the honest handling
 * is to let the live confidence stand alone, which is what happens here.
 */
export function combineConfidence(
  liveConfidence: number,
  referenceConfidence: number | null,
): number {
  const live = Math.max(0, Math.min(1, liveConfidence));
  if (referenceConfidence === null) return live;
  const reference = Math.max(0, Math.min(1, referenceConfidence));
  return live * reference;
}

/**
 * COMPARISON stage. `live` must be the dense, registry-ordered output of
 * measureLiveFrame; `reference` is the frozen session snapshot.
 */
export function compareFrame(
  live: readonly LiveMeasurement[],
  reference: SessionReference,
  thresholds: AnalysisThresholds = DEFAULT_ANALYSIS_THRESHOLDS,
): readonly MeasurementComparison[] {
  const comparisons: MeasurementComparison[] = [];

  for (const measurement of live) {
    const referenceEntry = reference.values[measurement.measurementId];
    const referenceValue = referenceEntry?.value ?? null;
    const referenceConfidence = referenceEntry?.confidence ?? null;
    const liveValue = measurement.value;
    const liveConfidence = measurement.confidence;
    const confidence = combineConfidence(liveConfidence, referenceConfidence);

    if (referenceValue === null) {
      comparisons.push({
        measurementId: measurement.measurementId,
        available: false,
        valid: false,
        validity: "reference-missing",
        referenceValue: null,
        liveValue,
        signedError: null,
        absError: null,
        direction: "none",
        severity: "within-tolerance",
        confidence: 0,
        liveConfidence,
        referenceConfidence: null,
        liveState: measurement.state,
      });
      continue;
    }

    if (liveValue === null) {
      /* A landmark that was seen but distrusted is a CONFIDENCE problem; one
         that was absent or produced impossible geometry is a DATA problem.
         Both are unusable — the distinction is kept for diagnostics. */
      const validity: ComparisonValidity =
        measurement.state === "landmark-unreliable" ? "low-confidence" : "live-missing";
      comparisons.push({
        measurementId: measurement.measurementId,
        available: false,
        valid: false,
        validity,
        referenceValue,
        liveValue: null,
        signedError: null,
        absError: null,
        direction: "none",
        severity: "within-tolerance",
        confidence: 0,
        liveConfidence,
        referenceConfidence,
        liveState: measurement.state,
      });
      continue;
    }

    const signedError = liveValue - referenceValue;
    const absError = Math.abs(signedError);
    const confidentEnough = confidence >= thresholds.minCoachingConfidence;

    comparisons.push({
      measurementId: measurement.measurementId,
      available: true,
      valid: confidentEnough,
      validity: confidentEnough ? "valid" : "low-confidence",
      referenceValue,
      liveValue,
      signedError,
      absError,
      direction: directionFor(signedError),
      severity: severityFor(absError, thresholds),
      confidence,
      liveConfidence,
      referenceConfidence,
      liveState: measurement.state,
    });
  }

  return comparisons;
}
