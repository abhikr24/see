/**
 * shared/ml/analysis/engine.ts — Unit 29, the deterministic pose-analysis
 * engine. Platform-neutral, zero RN/DOM/Supabase/TTS/network/React.
 *
 *   LIVE LANDMARKS → MEASUREMENTS → COMPARISON → ERROR → CONFIDENCE →
 *   SEVERITY → PRIORITY → TEMPORAL STABILITY → ONE SEMANTIC DECISION
 *
 * This is geometry and rules, not learning: no model is trained here, no LLM
 * is consulted, and no pose gets an `if (poseId === …)` branch — pose
 * behavior comes entirely from the reference data bound to the session.
 *
 * SESSION CONTRACT
 *   · The reference is validated and frozen ONCE at construction. The frame
 *     loop never re-parses, re-validates, re-reads an image or touches the
 *     network; it only measures, compares and decides.
 *   · The bound reference cannot change for the lifetime of the engine. A
 *     caller that wants different reference data must create a new engine —
 *     which is exactly what "the session template stays pinned" means.
 *   · An unusable reference yields a structured `unavailable` decision on
 *     every frame. It never degrades into coaching from invented numbers.
 */
import type { PoseLandmark } from "../poseLandmarks";
import { compareFrame } from "./compare";
import { measureLiveFrame } from "./measure";
import { rankCandidates } from "./priority";
import {
  bindSessionReference,
  type AnalysisReferenceInput,
  type SessionReference,
} from "./sessionReference";
import {
  createTemporalStabilizer,
  type TemporalConfig,
  type TemporalStabilizer,
} from "./temporal";
import {
  resolveThresholds,
  type AnalysisThresholds,
} from "./thresholds";
import {
  ANALYSIS_STATE_PERFECT,
  ANALYSIS_STATE_UNAVAILABLE,
  type AnalysisReferenceIdentity,
  type AnalysisUnavailable,
  type FrameAnalysis,
  type MeasurementComparison,
  type PoseAnalysisDecision,
} from "./types";

export interface PoseAnalysisEngineOptions {
  /** The prevalidated reference projection for this session; null = none. */
  readonly reference: AnalysisReferenceInput | null;
  /** Diagnostics label; does not affect any decision. */
  readonly sessionId?: string;
  readonly thresholds?: Partial<AnalysisThresholds>;
  readonly temporal?: Partial<TemporalConfig>;
}

export interface PoseAnalysisEngine {
  readonly sessionId: string;
  /** 'ready' only when a usable reference is bound. */
  readonly referenceState: "ready" | "unusable";
  /** The frozen session reference, or null when none could be bound. */
  readonly reference: SessionReference | null;
  /** Why the reference is unusable (null when ready). */
  readonly referenceFailure: AnalysisUnavailable | null;
  readonly thresholds: AnalysisThresholds;
  /** The hot path: one frame in, one semantic decision out. */
  analyzeFrame(landmarks: readonly PoseLandmark[] | null | undefined): PoseAnalysisDecision;
  /** Clears temporal memory only — the pinned reference is untouched. */
  reset(): void;
}

/** A frame the engine cannot judge: same shape, explicit reason, no coaching. */
function unavailableFrame(
  unavailable: AnalysisUnavailable,
  comparisons: readonly MeasurementComparison[],
  comparedCount: number,
  usableCount: number,
): FrameAnalysis {
  return {
    comparisons,
    candidates: [],
    comparedCount,
    usableCount,
    maxAbsError: null,
    meanAbsError: null,
    unavailable,
    candidateState: ANALYSIS_STATE_UNAVAILABLE,
  };
}

/**
 * STATELESS single-frame analysis: measurement → comparison → ranking. Used
 * by the engine and directly testable without any temporal history.
 */
export function analyzeFrameAgainstReference(
  landmarks: readonly PoseLandmark[] | null | undefined,
  reference: SessionReference,
  thresholds: AnalysisThresholds,
): FrameAnalysis {
  if (landmarks === null || landmarks === undefined || landmarks.length === 0) {
    return unavailableFrame(
      {
        reason: "no-live-pose",
        message: "No landmarks in this frame — nothing to compare.",
      },
      [],
      0,
      0,
    );
  }

  const live = measureLiveFrame(landmarks, thresholds);
  const comparisons = compareFrame(live, reference, thresholds);

  let comparedCount = 0;
  let usableCount = 0;
  let maxAbsError: number | null = null;
  let errorSum = 0;
  for (const comparison of comparisons) {
    if (comparison.available) comparedCount += 1;
    if (!comparison.valid || comparison.absError === null) continue;
    usableCount += 1;
    errorSum += comparison.absError;
    if (maxAbsError === null || comparison.absError > maxAbsError) {
      maxAbsError = comparison.absError;
    }
  }

  if (usableCount < thresholds.minComparisonsForDecision) {
    /* Distinguish "the body is not sufficiently visible" from "the visible
       measurements are too uncertain to coach from" — different fixes. */
    const reason =
      comparedCount >= thresholds.minComparisonsForDecision
        ? "low-confidence"
        : "insufficient-measurements";
    return unavailableFrame(
      {
        reason,
        message:
          reason === "low-confidence"
            ? `Only ${usableCount} measurement(s) met the coaching confidence ` +
              `floor of ${thresholds.minCoachingConfidence}.`
            : `Only ${usableCount} usable measurement(s) this frame; ` +
              `${thresholds.minComparisonsForDecision} are required.`,
      },
      comparisons,
      comparedCount,
      usableCount,
    );
  }

  const candidates = rankCandidates(comparisons);
  const top = candidates[0];
  return {
    comparisons,
    candidates,
    comparedCount,
    usableCount,
    maxAbsError,
    meanAbsError: usableCount > 0 ? errorSum / usableCount : null,
    unavailable: null,
    candidateState: top === undefined ? ANALYSIS_STATE_PERFECT : top.state,
  };
}

export function createPoseAnalysisEngine(
  options: PoseAnalysisEngineOptions,
): PoseAnalysisEngine {
  const thresholds = resolveThresholds(options.thresholds);
  const binding = bindSessionReference(options.reference, thresholds);
  const stabilizer: TemporalStabilizer = createTemporalStabilizer(options.temporal);
  const sessionId = options.sessionId ?? "analysis-session";

  const reference: SessionReference | null = binding.ok ? binding.reference : null;
  const referenceFailure: AnalysisUnavailable | null = binding.ok
    ? null
    : binding.unavailable;
  const identity: AnalysisReferenceIdentity | null =
    reference === null ? null : reference.identity;

  function analyzeFrame(
    landmarks: readonly PoseLandmark[] | null | undefined,
  ): PoseAnalysisDecision {
    if (reference === null) {
      /* Reference unusable: the answer is the same every frame, and it is a
         structured state — never a guess, never silence without a reason. */
      const failure: AnalysisUnavailable =
        referenceFailure ?? {
          reason: "reference-unavailable",
          message: "No usable reference is bound to this session.",
        };
      const frame = unavailableFrame(failure, [], 0, 0);
      const outcome = stabilizer.push({
        kind: "unavailable",
        candidateState: ANALYSIS_STATE_UNAVAILABLE,
        topCandidate: null,
        comparisons: [],
      });
      return {
        kind: outcome.kind === "evaluating" ? "unavailable" : outcome.kind,
        state:
          outcome.kind === "evaluating" ? ANALYSIS_STATE_UNAVAILABLE : outcome.state,
        correction: null,
        unavailable: failure,
        frame,
        temporal: outcome.status,
        reference: identity,
      };
    }

    const frame = analyzeFrameAgainstReference(landmarks, reference, thresholds);
    const outcome = stabilizer.push({
      kind:
        frame.unavailable !== null
          ? "unavailable"
          : frame.candidates.length === 0
            ? "perfect"
            : "correction",
      candidateState: frame.candidateState,
      topCandidate: frame.candidates[0] ?? null,
      comparisons: frame.comparisons,
    });

    return {
      kind: outcome.kind,
      state: outcome.state,
      correction: outcome.correction,
      unavailable: outcome.kind === "unavailable" ? frame.unavailable : null,
      frame,
      temporal: outcome.status,
      reference: identity,
    };
  }

  return {
    sessionId,
    referenceState: reference === null ? "unusable" : "ready",
    reference,
    referenceFailure,
    thresholds,
    analyzeFrame,
    reset: () => stabilizer.reset(),
  };
}
