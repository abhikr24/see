/**
 * shared/ml/analysis/guidanceBridge.ts — Unit 29 compatibility bridge.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * The engine decides WHICH correction is dominant; the existing Unit 17/27
 * language layer decides HOW it is said. This module is the one-way mapping
 * between them, so the camera UI, the overlay, the phrase bank and the TTS
 * service keep their current contract (`GuidanceResult`) and need no redesign.
 *
 * Nothing here re-decides anything: it reads the already-chosen decision.
 */
import {
  guidanceSeverityFor,
  jointDirectiveFor,
  JOINT_GUIDANCE_RULES,
  type GuidanceResult,
  type GuidanceSeverity,
} from "../guidanceGenerator";
import type { PoseAnalysisDecision } from "./types";

/**
 * Maps one semantic decision onto the legacy GuidanceResult shape.
 *
 *   'correction'  → the dominant joint's pre-authored directive (direction
 *                   taken from the SIGNED error, exactly as Unit 17 did:
 *                   live < reference ⇒ the 'liveLessThanRef' copy)
 *   'perfect'     → the unchanged "Perfect! Hold still" result
 *   'evaluating' /
 *   'unavailable' → null, the value the camera screen already treats as
 *                   "no guidance yet" — never invented coaching.
 */
export function decisionToGuidance(
  decision: PoseAnalysisDecision,
): GuidanceResult | null {
  const liveAngles: Record<string, number> = {};
  const angleDiffs: Record<string, number> = {};
  for (const comparison of decision.frame.comparisons) {
    if (comparison.liveValue !== null) {
      liveAngles[comparison.measurementId] = comparison.liveValue;
    }
    if (comparison.absError !== null) {
      angleDiffs[comparison.measurementId] = comparison.absError;
    }
  }

  if (decision.kind === "perfect") {
    return {
      worstJoint: null,
      worstLandmarkName: null,
      text: "Perfect! Hold still",
      hint: "Hold this stance for the cleanest photo capture",
      arrowDirection: "none",
      voiceCategory: "final_pose_good",
      severity: "perfect",
      maxDiff: decision.frame.maxAbsError ?? 0,
      isPerfect: true,
      liveAngles,
      angleDiffs,
      /* Unit 32 — the decision travels with the presentation result. */
      semantics: {
        state: decision.state,
        direction: "none",
        analysisSeverity: null,
        confidence: null,
      },
    };
  }

  const correction = decision.correction;
  if (decision.kind !== "correction" || correction === null) return null;

  const rule = JOINT_GUIDANCE_RULES[correction.measurementId];
  /* Unit 32 repair — direction and severity are ENGINE decisions, carried
     verbatim. This layer used to re-derive both (sign of `signedError`, and a
     second thresholding of `absError`), which duplicated pose mathematics in
     a presentation mapper and let the two ladders drift apart. */
  const directive = jointDirectiveFor(
    correction.measurementId,
    correction.direction,
  );
  if (rule === undefined || directive === null) return null;

  const severity: GuidanceSeverity = guidanceSeverityFor(correction.severity);

  return {
    worstJoint: correction.measurementId,
    worstLandmarkName: rule.vertexLandmark,
    text: directive.text,
    hint: directive.hint,
    arrowDirection: directive.arrowDirection,
    voiceCategory: directive.voiceCategory,
    severity,
    maxDiff: decision.frame.maxAbsError ?? correction.absError,
    isPerfect: false,
    liveAngles,
    angleDiffs,
    semantics: {
      state: decision.state,
      direction: correction.direction,
      analysisSeverity: correction.severity,
      confidence: correction.confidence,
    },
  };
}
