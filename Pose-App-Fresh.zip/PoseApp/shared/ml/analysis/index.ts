/**
 * shared/ml/analysis/index.ts — barrel for the deterministic pose-analysis
 * engine (Unit 29).
 *
 * PIPELINE OWNED BY THIS FOLDER:
 *
 *   live landmarks ─▶ measure.ts    (MEASUREMENTS + confidence + why-absent)
 *                  ─▶ compare.ts    (signed ERROR, direction, SEVERITY,
 *                                    combined CONFIDENCE, validity)
 *                  ─▶ priority.ts   (deterministic total order ⇒ ONE winner)
 *                  ─▶ temporal.ts   (persistence + hysteresis)
 *                  ─▶ engine.ts     (ONE semantic decision per frame)
 *
 * Dependency direction: this folder imports ONLY sibling math modules and
 * shared/ml primitives. It must never import the reference domain, providers,
 * Supabase, network code, React/RN, the DOM or the TTS layer — the reference
 * side depends on the engine, not the other way round.
 */
export * from "./thresholds";
export * from "./types";
export * from "./sessionReference";
export * from "./measure";
export * from "./compare";
export * from "./priority";
export * from "./temporal";
export * from "./engine";
export * from "./guidanceBridge";
export * from "./matchScore";
