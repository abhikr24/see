/**
 * shared/ml/analysis/matchScore.ts — Unit 31: ONE geometry pass per frame.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * WHY THIS MODULE EXISTS (hot-path repair, not a new feature)
 *
 * Until now the camera frame loop ran the joint geometry TWICE per frame:
 *
 *   landmarks ─┬─▶ measureLiveFrame → compareFrame → decision   (Unit 29)
 *              └─▶ calculateMatchPercent → match %              (Unit 16)
 *
 * Two independent passes over the same 33 landmarks, each re-deriving the
 * same eight interior angles with the same `jointAngle` function. That is
 * duplicated work in the hottest loop in the app AND a structural risk: two
 * code paths that must agree about which joints are measurable.
 *
 * This module derives the match % from the comparisons the engine ALREADY
 * produced, so the hot path becomes exactly:
 *
 *   live landmarks → measurements → comparison → decision (+ match %)
 *
 * BIT-IDENTICAL BY CONSTRUCTION, not by intention:
 *   · the set averaged here is `available` comparisons — a comparison is
 *     available iff the live angle was measurable (same `jointAngle`, same
 *     MIN_LANDMARK_VISIBILITY floor as `landmarkAt`) AND the reference
 *     carries that measurement — which is precisely the set `getAngleDiffs`
 *     builds;
 *   · the ≥2 rule and the percentage formula are not restated: the formula
 *     owner `diffToPercent` in shared/ml/poseMatch.ts is imported.
 *   · availability deliberately does NOT use the coaching-confidence floor:
 *     the score is a visual readout (0.3 landmark floor), while spoken
 *     coaching uses the stricter 0.5 floor. Mixing them would silently
 *     change the on-screen number.
 *
 * tests/analysis/matchScore.test.ts asserts equality against the legacy
 * `calculateMatchPercent` over deterministic frames, so this is a proven
 * refactor rather than a claimed one.
 */
import { diffToPercent, type MatchResult } from "../poseMatch";
import { MIN_COMPARISONS_FOR_DECISION } from "./thresholds";
import type { MeasurementComparison, PoseAnalysisDecision } from "./types";

const EMPTY_MATCH: MatchResult = {
  percent: null,
  perJoint: {},
  jointsCompared: 0,
  avgDiffDegrees: null,
};

/**
 * Match % from the comparisons of ONE analysed frame.
 * `percent: null` means "too little of the body is visible to score" — the
 * UI reads that as "stand fully into frame", never as a red 0.
 */
export function matchFromComparisons(
  comparisons: readonly MeasurementComparison[],
): MatchResult {
  const perJoint: Record<string, number> = {};
  let sum = 0;
  let count = 0;
  for (const comparison of comparisons) {
    if (!comparison.available || comparison.absError === null) continue;
    perJoint[comparison.measurementId] = comparison.absError;
    sum += comparison.absError;
    count += 1;
  }
  if (count < MIN_COMPARISONS_FOR_DECISION) {
    return { percent: null, perJoint, jointsCompared: count, avgDiffDegrees: null };
  }
  const avg = sum / count;
  return {
    percent: diffToPercent(avg),
    perJoint,
    jointsCompared: count,
    avgDiffDegrees: avg,
  };
}

/**
 * Convenience for the frame loop: the decision already carries the frame.
 * A null decision (no engine bound this session) scores nothing — it never
 * degrades into a fabricated percentage.
 */
export function matchFromDecision(
  decision: PoseAnalysisDecision | null | undefined,
): MatchResult {
  if (decision === null || decision === undefined) return EMPTY_MATCH;
  return matchFromComparisons(decision.frame.comparisons);
}
