/**
 * shared/ml/analysis/measure.ts — Unit 29, stage 1: LIVE LANDMARKS → MEASUREMENTS.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * The angular convention is UNCHANGED: the interior angle at a joint is the
 * existing `calculateAngle(a, vertex, c)` from shared/ml/poseMatch.ts
 * (atan2-based, 0..180°, wrap-corrected). There was no evidence the shipped
 * convention is wrong, so it is reused verbatim through `jointAngle` — this
 * module adds what the engine was missing: an explicit CONFIDENCE and an
 * explicit REASON when a measurement does not exist.
 */
import {
  MATCH_JOINTS,
  POSE_LANDMARKS,
  type PoseLandmark,
  type PoseLandmarkName,
} from "../poseLandmarks";
import { jointAngle } from "../poseMatch";
import {
  DEFAULT_ANALYSIS_THRESHOLDS,
  type AnalysisThresholds,
} from "./thresholds";
import type { LiveMeasurement, LiveMeasurementState } from "./types";

function rawLandmark(
  landmarks: readonly PoseLandmark[],
  name: PoseLandmarkName,
): PoseLandmark | undefined {
  return landmarks[POSE_LANDMARKS[name]];
}

/**
 * Confidence of a landmark. MediaPipe omits `visibility` on some builds; an
 * omitted value is documented by the PoseLandmark contract as "present", so
 * it reads 1 — this is the existing behavior in poseMatch.landmarkAt, kept
 * identical rather than silently tightened.
 */
function landmarkConfidence(landmark: PoseLandmark): number {
  const visibility = landmark.visibility ?? 1;
  return Number.isFinite(visibility) ? Math.max(0, Math.min(1, visibility)) : 0;
}

function hasFiniteCoordinates(landmark: PoseLandmark): boolean {
  return Number.isFinite(landmark.x) && Number.isFinite(landmark.y);
}

/**
 * Measures every registered joint for one frame. The result is dense and in
 * canonical registry order: one entry per measurement id, each one either a
 * value or an explicit reason it is absent. Absence is never a number.
 */
export function measureLiveFrame(
  landmarks: readonly PoseLandmark[],
  thresholds: AnalysisThresholds = DEFAULT_ANALYSIS_THRESHOLDS,
): readonly LiveMeasurement[] {
  const measurements: LiveMeasurement[] = [];
  for (const joint of MATCH_JOINTS) {
    const points = [joint.a, joint.vertex, joint.c].map((name) =>
      rawLandmark(landmarks, name),
    );
    let state: LiveMeasurementState = "measured";
    let confidence = 1;

    for (const point of points) {
      if (point === undefined || !hasFiniteCoordinates(point)) {
        state = "landmark-missing";
        confidence = 0;
        break;
      }
      confidence = Math.min(confidence, landmarkConfidence(point));
    }

    if (state === "measured" && confidence < thresholds.minMeasurableConfidence) {
      state = "landmark-unreliable";
    }

    let value: number | null = null;
    if (state === "measured") {
      /* Same geometry the match-% engine uses — one convention, no drift. */
      value = jointAngle(landmarks, joint);
      if (value === null) {
        state = "implausible";
      } else if (
        value < thresholds.plausibleAngle.min ||
        value > thresholds.plausibleAngle.max
      ) {
        value = null;
        state = "implausible";
      }
    }

    measurements.push({
      measurementId: joint.key,
      value,
      confidence: state === "measured" || state === "landmark-unreliable" ? confidence : 0,
      state,
    });
  }
  return measurements;
}
