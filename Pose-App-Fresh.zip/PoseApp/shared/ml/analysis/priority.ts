/**
 * shared/ml/analysis/priority.ts — Unit 29, stage 6: PRIORITY.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * When several measurements are wrong at once, exactly ONE correction may be
 * spoken. The choice must be reproducible: the same comparisons in any object
 * order must always yield the same winner.
 *
 * DETERMINISM MECHANICS
 *   · candidates are built by walking the canonical registry order
 *     (ANALYSIS_MEASUREMENT_IDS), never `Object.keys` of a payload;
 *   · ordering is a total order — severity, then priority score, then the
 *     registry index, which is unique per measurement. No two candidates can
 *     ever compare "equal", so `sort` stability is irrelevant;
 *   · nothing consults wall-clock time, randomness or insertion order.
 *
 * SCORE = |error| × correction importance × confidence
 *   |error|     — how wrong the joint is
 *   importance  — how much that joint shapes the photograph (data-driven,
 *                 keyed by measurement id, never by pose id)
 *   confidence  — an uncertain measurement should not out-shout a certain one
 */
import {
  measurementImportance,
  measurementRegistryIndex,
} from "./thresholds";
import { severityRank } from "./compare";
import type {
  CorrectionCandidate,
  MeasurementComparison,
} from "./types";

/** camelCase measurement id → SCREAMING_SNAKE token ("leftElbow" → "LEFT_ELBOW"). */
export function measurementToken(measurementId: string): string {
  return measurementId
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^A-Za-z0-9]+/g, "_")
    .toUpperCase();
}

/**
 * Canonical semantic state for one correction, e.g. "LEFT_ELBOW_INCREASE"
 * (open the joint) / "RIGHT_KNEE_DECREASE" (close the joint). The token is
 * geometric on purpose: the language/TTS layer maps it to instructor phrasing
 * ("raise", "bend", …) — the engine does not speak.
 */
export function canonicalCorrectionState(
  measurementId: string,
  direction: "increase" | "decrease",
): string {
  return `${measurementToken(measurementId)}_${direction.toUpperCase()}`;
}

export function buildCandidate(
  comparison: MeasurementComparison,
): CorrectionCandidate | null {
  if (!comparison.valid || !comparison.available) return null;
  if (comparison.signedError === null || comparison.absError === null) return null;
  if (comparison.severity === "within-tolerance") return null;
  if (comparison.direction === "none") return null;

  const importance = measurementImportance(comparison.measurementId);
  return {
    measurementId: comparison.measurementId,
    direction: comparison.direction,
    severity: comparison.severity,
    signedError: comparison.signedError,
    absError: comparison.absError,
    confidence: comparison.confidence,
    importance,
    priorityScore: comparison.absError * importance * comparison.confidence,
    state: canonicalCorrectionState(comparison.measurementId, comparison.direction),
    registryIndex: measurementRegistryIndex(comparison.measurementId),
  };
}

/**
 * Total ordering: worse first. Returns < 0 when `a` should be coached before
 * `b`. Never returns 0 for two different measurements.
 */
export function compareCandidates(
  a: CorrectionCandidate,
  b: CorrectionCandidate,
): number {
  const bySeverity = severityRank(b.severity) - severityRank(a.severity);
  if (bySeverity !== 0) return bySeverity;
  const byScore = b.priorityScore - a.priorityScore;
  if (byScore !== 0) return byScore;
  return a.registryIndex - b.registryIndex;
}

/**
 * PRIORITY stage: every correctable comparison, ranked, best (worst pose
 * error) first. Input order is irrelevant — candidates are rebuilt in
 * registry order and then totally ordered.
 */
export function rankCandidates(
  comparisons: readonly MeasurementComparison[],
): readonly CorrectionCandidate[] {
  const candidates: CorrectionCandidate[] = [];
  const byId = new Map<string, MeasurementComparison>();
  for (const comparison of comparisons) byId.set(comparison.measurementId, comparison);

  /* Walk registry order, not the argument order. */
  const ordered = [...byId.values()].sort(
    (a, b) =>
      measurementRegistryIndex(a.measurementId) -
      measurementRegistryIndex(b.measurementId),
  );
  for (const comparison of ordered) {
    const candidate = buildCandidate(comparison);
    if (candidate !== null) candidates.push(candidate);
  }
  return candidates.sort(compareCandidates);
}
