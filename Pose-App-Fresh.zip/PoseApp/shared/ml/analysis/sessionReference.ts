/**
 * shared/ml/analysis/sessionReference.ts — Unit 29 engine-side reference contract.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * THE SESSION REFERENCE.
 *
 * The engine never sees a database row, a provider, a template artifact or a
 * remote payload — the architecture forbids shared/ml from importing the
 * reference domain at all (mobile/scripts/verify-reference-architecture.mjs,
 * rule B). What it accepts is this plain, already-validated projection, bound
 * ONCE per analysis session.
 *
 * Two guarantees follow from binding up-front:
 *   1. HOT PATH PURITY — the per-frame path is measure → compare → decide.
 *      Nothing re-parses, re-validates, re-reads images or re-fetches data.
 *   2. IMMUTABILITY — the bound snapshot is deep-frozen and copied, so the
 *      caller cannot swap values under a running session, deliberately or by
 *      handing the engine an object it keeps mutating.
 */
import {
  ANALYSIS_MEASUREMENT_IDS,
  ANALYSIS_SUPPORTED_MEASUREMENT_VERSIONS,
  DEFAULT_ANALYSIS_THRESHOLDS,
  type AnalysisThresholds,
} from "./thresholds";
import type { AnalysisReferenceIdentity, AnalysisUnavailable } from "./types";

/** One reference value; `confidence: null` = the producer made no claim. */
export interface AnalysisReferenceValue {
  readonly value: number;
  readonly confidence: number | null;
}

/**
 * What a caller hands the engine. Produced by the reference domain's binding
 * adapter (shared/reference/analysisBinding.ts) from a validated, pinned
 * ReferencePoseTemplate — never hand-assembled by a screen.
 */
export interface AnalysisReferenceInput {
  readonly referenceId: string;
  readonly poseId: string;
  readonly schemaVersion: number;
  readonly measurementVersion: number;
  readonly contentHash: string;
  /** measurementId → value. Ids unknown to this engine are ignored. */
  readonly values: Readonly<Record<string, AnalysisReferenceValue>>;
}

/** The frozen, engine-owned snapshot used for the whole session. */
export interface SessionReference {
  readonly identity: AnalysisReferenceIdentity;
  /** Registry-ordered ids this reference actually carries and the engine can use. */
  readonly availableIds: readonly string[];
  /** Registry ids the reference does not carry. */
  readonly missingIds: readonly string[];
  readonly values: Readonly<Record<string, AnalysisReferenceValue>>;
}

export type SessionReferenceBinding =
  | { readonly ok: true; readonly reference: SessionReference }
  | { readonly ok: false; readonly unavailable: AnalysisUnavailable };

function unusable(
  reason: AnalysisUnavailable["reason"],
  message: string,
): SessionReferenceBinding {
  return { ok: false, unavailable: Object.freeze({ reason, message }) };
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

/**
 * Validate + freeze a reference for one analysis session. Returns a
 * structured unavailable state instead of throwing, and NEVER invents a value
 * for something the source did not provide.
 */
export function bindSessionReference(
  input: AnalysisReferenceInput | null | undefined,
  thresholds: AnalysisThresholds = DEFAULT_ANALYSIS_THRESHOLDS,
): SessionReferenceBinding {
  if (input === null || input === undefined) {
    return unusable(
      "reference-unavailable",
      "No reference was supplied for this session; coaching stays silent.",
    );
  }
  if (typeof input !== "object") {
    return unusable("reference-invalid", "Reference input is not an object.");
  }
  if (
    typeof input.referenceId !== "string" ||
    input.referenceId.length === 0 ||
    typeof input.poseId !== "string" ||
    input.poseId.length === 0
  ) {
    return unusable(
      "reference-invalid",
      "Reference input is missing a referenceId/poseId identity.",
    );
  }
  if (
    !isFiniteNumber(input.schemaVersion) ||
    !isFiniteNumber(input.measurementVersion)
  ) {
    return unusable(
      "reference-invalid",
      `Reference "${input.referenceId}" has no numeric version stamp.`,
    );
  }
  if (!ANALYSIS_SUPPORTED_MEASUREMENT_VERSIONS.includes(input.measurementVersion)) {
    return unusable(
      "reference-incompatible",
      `Reference "${input.referenceId}" uses measurement version ` +
        `${input.measurementVersion}; this engine reads ` +
        `[${ANALYSIS_SUPPORTED_MEASUREMENT_VERSIONS.join(", ")}].`,
    );
  }
  const rawValues = input.values;
  if (rawValues === null || typeof rawValues !== "object") {
    return unusable(
      "reference-invalid",
      `Reference "${input.referenceId}" carries no measurement values.`,
    );
  }

  const values: Record<string, AnalysisReferenceValue> = {};
  const availableIds: string[] = [];
  const missingIds: string[] = [];

  /* Registry order — never Object.keys(rawValues) — so the snapshot cannot
     inherit the key order of whatever produced the payload. */
  for (const id of ANALYSIS_MEASUREMENT_IDS) {
    const entry = rawValues[id];
    if (entry === undefined || entry === null) {
      missingIds.push(id);
      continue;
    }
    if (!isFiniteNumber(entry.value)) {
      return unusable(
        "reference-invalid",
        `Reference "${input.referenceId}" measurement "${id}" is not a finite number.`,
      );
    }
    if (
      entry.value < thresholds.plausibleAngle.min ||
      entry.value > thresholds.plausibleAngle.max
    ) {
      return unusable(
        "reference-invalid",
        `Reference "${input.referenceId}" measurement "${id}" = ${entry.value}° ` +
          `is outside the plausible band ` +
          `${thresholds.plausibleAngle.min}..${thresholds.plausibleAngle.max}°.`,
      );
    }
    const confidence = entry.confidence;
    if (
      confidence !== null &&
      confidence !== undefined &&
      (!isFiniteNumber(confidence) || confidence < 0 || confidence > 1)
    ) {
      return unusable(
        "reference-invalid",
        `Reference "${input.referenceId}" measurement "${id}" has a ` +
          `confidence outside 0..1.`,
      );
    }
    values[id] = Object.freeze({
      value: entry.value,
      confidence: confidence === undefined ? null : confidence,
    });
    availableIds.push(id);
  }

  if (availableIds.length < thresholds.minComparisonsForDecision) {
    return unusable(
      "reference-incomplete",
      `Reference "${input.referenceId}" carries ${availableIds.length} usable ` +
        `measurement(s); ${thresholds.minComparisonsForDecision} are required ` +
        `to compare a pose.`,
    );
  }

  const reference: SessionReference = Object.freeze({
    identity: Object.freeze({
      referenceId: input.referenceId,
      poseId: input.poseId,
      schemaVersion: input.schemaVersion,
      measurementVersion: input.measurementVersion,
      contentHash: typeof input.contentHash === "string" ? input.contentHash : "",
    }),
    availableIds: Object.freeze(availableIds.slice()),
    missingIds: Object.freeze(missingIds.slice()),
    values: Object.freeze(values),
  });
  return { ok: true, reference };
}

/** True when two identities describe exactly the same reference artifact. */
export function sameReferenceIdentity(
  a: AnalysisReferenceIdentity,
  b: AnalysisReferenceIdentity,
): boolean {
  return (
    a.referenceId === b.referenceId &&
    a.poseId === b.poseId &&
    a.schemaVersion === b.schemaVersion &&
    a.measurementVersion === b.measurementVersion &&
    a.contentHash === b.contentHash
  );
}
