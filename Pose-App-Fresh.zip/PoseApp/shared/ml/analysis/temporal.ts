/**
 * shared/ml/analysis/temporal.ts — Unit 29, stage 7: TEMPORAL STABILITY.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * A live camera produces noisy landmarks; consecutive frames routinely
 * disagree. Announcing every frame's winner produces the failure this stage
 * exists to prevent:  LEFT → RIGHT → LEFT → RIGHT …
 *
 * TWO MECHANISMS
 *   1. PERSISTENCE — a new state must win N consecutive frames before it
 *      becomes the active coaching state. Alternating frames never
 *      accumulate, so contradictory noise produces no switch at all.
 *   2. HYSTERESIS — an ACTIVE correction is kept until its error falls below
 *      (tolerance − release margin), and a rival must beat it by a relative
 *      score margin before it may take over. Tiny fluctuations around a
 *      boundary therefore cannot reverse a decision.
 *
 * Determinism: frame-counted, never clock-driven. The same frame sequence
 * always yields the same state sequence.
 */
import {
  CORRECTION_PERSISTENCE_FRAMES,
  DOMINANCE_SWITCH_MARGIN_RATIO,
  PERFECT_PERSISTENCE_FRAMES,
  UNAVAILABLE_PERSISTENCE_FRAMES,
  CORRECTION_RELEASE_DEGREES,
  measurementImportance,
} from "./thresholds";
import { severityFor } from "./compare";
import type {
  AnalysisDecisionKind,
  CorrectionCandidate,
  MeasurementComparison,
  TemporalStatus,
} from "./types";
import { ANALYSIS_STATE_EVALUATING } from "./types";

export interface TemporalConfig {
  readonly correctionPersistenceFrames: number;
  readonly perfectPersistenceFrames: number;
  readonly unavailablePersistenceFrames: number;
  /** |error| an active correction must drop below before it is released. */
  readonly releaseDegrees: number;
  /** Relative score advantage a challenger needs to unseat the incumbent. */
  readonly switchMarginRatio: number;
}

export const DEFAULT_TEMPORAL_CONFIG: TemporalConfig = Object.freeze({
  correctionPersistenceFrames: CORRECTION_PERSISTENCE_FRAMES,
  perfectPersistenceFrames: PERFECT_PERSISTENCE_FRAMES,
  unavailablePersistenceFrames: UNAVAILABLE_PERSISTENCE_FRAMES,
  releaseDegrees: CORRECTION_RELEASE_DEGREES,
  switchMarginRatio: DOMINANCE_SWITCH_MARGIN_RATIO,
});

export function resolveTemporalConfig(
  overrides?: Partial<TemporalConfig>,
): TemporalConfig {
  if (overrides === undefined) return DEFAULT_TEMPORAL_CONFIG;
  return Object.freeze({ ...DEFAULT_TEMPORAL_CONFIG, ...overrides });
}

/** One frame's instantaneous verdict, handed to the stabilizer. */
export interface TemporalFrameInput {
  readonly kind: Exclude<AnalysisDecisionKind, "evaluating">;
  readonly candidateState: string;
  readonly topCandidate: CorrectionCandidate | null;
  readonly comparisons: readonly MeasurementComparison[];
}

export interface TemporalOutcome {
  readonly kind: AnalysisDecisionKind;
  readonly state: string;
  readonly correction: CorrectionCandidate | null;
  readonly status: TemporalStatus;
}

export interface TemporalStabilizer {
  push(input: TemporalFrameInput): TemporalOutcome;
  reset(): void;
  /** Current active state without advancing the machine. */
  peek(): { readonly state: string | null; readonly framesHeld: number };
}

/**
 * Rebuild the held correction from the CURRENT frame so the numbers a caller
 * reads are this frame's numbers, not the ones from when the correction was
 * first raised. Severity can rise freely; while a correction is held by
 * hysteresis inside the tolerance band it is reported as 'minor' (it is still
 * an active correction — it is simply no longer over the tolerance).
 */
function refreshHeldCorrection(
  held: CorrectionCandidate,
  comparison: MeasurementComparison | undefined,
): CorrectionCandidate {
  if (
    comparison === undefined ||
    !comparison.available ||
    comparison.signedError === null ||
    comparison.absError === null
  ) {
    return held;
  }
  const severity = severityFor(comparison.absError);
  const importance = measurementImportance(comparison.measurementId);
  return {
    ...held,
    signedError: comparison.signedError,
    absError: comparison.absError,
    confidence: comparison.confidence,
    importance,
    severity: severity === "within-tolerance" ? "minor" : severity,
    priorityScore: comparison.absError * importance * comparison.confidence,
  };
}

function requiredFrames(
  kind: Exclude<AnalysisDecisionKind, "evaluating">,
  config: TemporalConfig,
): number {
  switch (kind) {
    case "perfect":
      return config.perfectPersistenceFrames;
    case "unavailable":
      return config.unavailablePersistenceFrames;
    case "correction":
      return config.correctionPersistenceFrames;
  }
}

export function createTemporalStabilizer(
  overrides?: Partial<TemporalConfig>,
): TemporalStabilizer {
  const config = resolveTemporalConfig(overrides);

  let activeState: string | null = null;
  let activeKind: AnalysisDecisionKind = "evaluating";
  let activeCorrection: CorrectionCandidate | null = null;
  let framesHeld = 0;
  let pendingState: string | null = null;
  let pendingKind: Exclude<AnalysisDecisionKind, "evaluating"> | null = null;
  let pendingFrames = 0;
  let frameIndex = 0;

  function clearPending(): void {
    pendingState = null;
    pendingKind = null;
    pendingFrames = 0;
  }

  function reset(): void {
    activeState = null;
    activeKind = "evaluating";
    activeCorrection = null;
    framesHeld = 0;
    frameIndex = 0;
    clearPending();
  }

  function push(input: TemporalFrameInput): TemporalOutcome {
    frameIndex += 1;

    const byId = new Map<string, MeasurementComparison>();
    for (const comparison of input.comparisons) {
      byId.set(comparison.measurementId, comparison);
    }

    /* ---------- 1. what does this frame propose? ---------- */
    let proposedKind: Exclude<AnalysisDecisionKind, "evaluating"> = input.kind;
    let proposedState = input.candidateState;
    let proposedCorrection: CorrectionCandidate | null = input.topCandidate;
    let heldByHysteresis = false;

    if (
      input.kind !== "unavailable" &&
      activeKind === "correction" &&
      activeCorrection !== null
    ) {
      const incumbentId = activeCorrection.measurementId;
      const incumbentComparison = byId.get(incumbentId);
      const refreshed = refreshHeldCorrection(activeCorrection, incumbentComparison);
      const stillMeasurable =
        incumbentComparison !== undefined &&
        incumbentComparison.available &&
        incumbentComparison.valid &&
        incumbentComparison.absError !== null;
      const sameDirection =
        incumbentComparison !== undefined &&
        incumbentComparison.direction === activeCorrection.direction;
      const aboveRelease =
        incumbentComparison?.absError !== null &&
        incumbentComparison?.absError !== undefined &&
        incumbentComparison.absError >= config.releaseDegrees;

      const supported = stillMeasurable && sameDirection && aboveRelease;
      if (supported) {
        const challenger = input.topCandidate;
        const unseated =
          challenger !== null &&
          challenger.measurementId !== incumbentId &&
          challenger.priorityScore >
            refreshed.priorityScore * (1 + config.switchMarginRatio);
        if (!unseated) {
          proposedKind = "correction";
          proposedState = refreshed.state;
          proposedCorrection = refreshed;
          heldByHysteresis = input.candidateState !== refreshed.state;
        }
      }
    }

    /* ---------- 2. persistence ---------- */
    if (proposedState === activeState) {
      framesHeld += 1;
      clearPending();
      if (proposedKind === "correction" && proposedCorrection !== null) {
        activeCorrection = proposedCorrection;
      }
    } else {
      if (proposedState === pendingState) {
        pendingFrames += 1;
      } else {
        pendingState = proposedState;
        pendingFrames = 1;
      }
      pendingKind = proposedKind;

      if (pendingFrames >= requiredFrames(proposedKind, config)) {
        activeState = proposedState;
        activeKind = proposedKind;
        activeCorrection = proposedKind === "correction" ? proposedCorrection : null;
        framesHeld = pendingFrames;
        clearPending();
      }
    }

    /* ---------- 3. expose exactly one semantic state ---------- */
    const status: TemporalStatus = {
      framesHeld: activeState === null ? 0 : framesHeld,
      pendingState,
      pendingFrames,
      framesUntilSwitch:
        pendingState === null || pendingKind === null
          ? 0
          : Math.max(0, requiredFrames(pendingKind, config) - pendingFrames),
      heldByHysteresis: activeState === proposedState && heldByHysteresis,
      frameIndex,
    };

    if (activeState === null) {
      return {
        kind: "evaluating",
        state: ANALYSIS_STATE_EVALUATING,
        correction: null,
        status,
      };
    }
    return {
      kind: activeKind,
      state: activeState,
      correction: activeKind === "correction" ? activeCorrection : null,
      status,
    };
  }

  return {
    push,
    reset,
    peek: () => ({ state: activeState, framesHeld }),
  };
}
