/**
 * shared/ml/analysis/thresholds.ts — Unit 29, the deterministic pose-analysis
 * engine. Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * THE SINGLE HOME FOR EVERY NUMBER THE ENGINE REASONS WITH.
 *
 * Nothing else in the engine may contain a bare numeric threshold: a magic
 * number scattered across files is how two code paths start disagreeing about
 * what "good" means. Values below are the ones the shipped implementation
 * already used (Unit 16/17) — they are CENTRALIZED here, not re-invented:
 *
 *   · 10° — the historical `GUIDANCE_THRESHOLDS.perfect` tolerance; under it a
 *           measurement is treated as matching the reference.
 *   · 25° — the historical `GUIDANCE_THRESHOLDS.good` band ceiling; above it a
 *           deviation is a major ('adjust') correction.
 *   ·  2° / 180° — the plausibility band enforced in shared/ml/poseMatch.ts.
 *   ·  0.3 — MIN_LANDMARK_VISIBILITY, the existing "this landmark is noise"
 *           floor (imported, never re-declared).
 *   ·  2  — MIN comparisons for any verdict (matches calculateMatchPercent).
 *
 * New numbers introduced by this unit (temporal stability + confidence for
 * coaching) are documented inline with their reasoning.
 */
import {
  MATCH_JOINTS,
  MIN_LANDMARK_VISIBILITY,
  PLAUSIBLE_JOINT_ANGLE_DEGREES,
} from "../poseLandmarks";

/**
 * Anatomical plausibility band for an interior joint angle, in degrees.
 * Outside it a number is landmark jitter or bad reference data, never a pose.
 *
 * Single owner: shared/ml/poseLandmarks.PLAUSIBLE_JOINT_ANGLE_DEGREES. This
 * is an alias for engine-local readability, NOT a second declaration — the
 * reference domain binds to the same constant, and a cross-domain test
 * asserts the two views are identical.
 */
export const ANALYSIS_PLAUSIBLE_ANGLE = PLAUSIBLE_JOINT_ANGLE_DEGREES;

/**
 * |live − reference| strictly BELOW this is "matching" — the historical
 * perfect tolerance. At exactly the tolerance the measurement is already a
 * (minor) deviation: the boundary belongs to the correction side, exactly as
 * the shipped `maxDiff < GUIDANCE_THRESHOLDS.perfect` comparison behaved.
 */
export const GOOD_TOLERANCE_DEGREES = 10;

/**
 * |live − reference| at or below this stays a MINOR deviation; strictly above
 * it becomes MAJOR. Mirrors the shipped `maxDiff <= GUIDANCE_THRESHOLDS.good`
 * comparison.
 */
export const CORRECTION_THRESHOLD_DEGREES = 25;

/**
 * Hysteresis release margin, in degrees. An ACTIVE correction is only let go
 * once its error falls below (tolerance − margin); between the release point
 * and the tolerance the correction is "still supported". Without this a
 * measurement hovering at 9.9°/10.1° would flip the coaching state on every
 * frame. 2° ≈ the frame-to-frame jitter of a well-tracked joint.
 */
export const HYSTERESIS_RELEASE_MARGIN_DEGREES = 2;

/** Derived: the error an active correction must drop below to be released. */
export const CORRECTION_RELEASE_DEGREES =
  GOOD_TOLERANCE_DEGREES - HYSTERESIS_RELEASE_MARGIN_DEGREES;

/**
 * A challenger measurement must beat the ACTIVE correction's priority score
 * by this relative margin before it may take over. Pure score ordering would
 * let two near-equal errors trade the microphone every frame.
 */
export const DOMINANCE_SWITCH_MARGIN_RATIO = 0.15;

/**
 * Landmark/measurement confidence floor for COACHING. A landmark above
 * MIN_LANDMARK_VISIBILITY (0.3) is good enough to draw and to score, but a
 * spoken "bend your left elbow" earned from a 0.35-confidence elbow is a
 * guess. Such comparisons stay visible in the report (validity =
 * 'low-confidence') and are excluded from correction selection.
 */
export const MIN_COACHING_CONFIDENCE = 0.5;

/** Re-exported so consumers read ONE confidence vocabulary from one module. */
export const MIN_MEASURABLE_CONFIDENCE = MIN_LANDMARK_VISIBILITY;

/**
 * Fewer usable comparisons than this and the engine refuses to judge the
 * frame — identical to the >= 2 compared-joints rule in calculateMatchPercent
 * and generatePoseGuidance.
 */
export const MIN_COMPARISONS_FOR_DECISION = 2;

/**
 * Consecutive frames a NEW correction must win before it becomes the active
 * coaching state. At the 15 fps ML budget (Unit 16) 3 frames ≈ 200 ms — long
 * enough to kill single-frame landmark noise, short enough to feel live.
 */
export const CORRECTION_PERSISTENCE_FRAMES = 3;

/**
 * Consecutive clean frames before PERFECT is announced. Slightly cheaper than
 * a correction: telling somebody they are already right is the low-risk
 * direction, and the capture gate re-verifies with its own 2 s hold.
 */
export const PERFECT_PERSISTENCE_FRAMES = 2;

/**
 * How many consecutive frames an unavailable/undecidable input must persist
 * before the engine drops the active coaching state. 1 = immediately: when
 * the body leaves the frame or the reference cannot be used, silence is the
 * honest answer and must not be delayed.
 */
export const UNAVAILABLE_PERSISTENCE_FRAMES = 1;

/**
 * Measurement-version semantics this engine implements. A reference produced
 * under different measurement semantics is refused at bind time rather than
 * silently reinterpreted (the reference domain owns the same number; the
 * binding adapter asserts they agree).
 */
export const ANALYSIS_MEASUREMENT_VERSION = 1;
export const ANALYSIS_SUPPORTED_MEASUREMENT_VERSIONS: readonly number[] = [1];

/**
 * CORRECTION IMPORTANCE — how much a given measurement matters to how the
 * photograph reads. Pose-agnostic and data-driven: keyed by measurement id
 * (never by poseId), so no pose gets an `if (poseId === ...)` special case.
 *
 * Rationale: torso-proximal joints (shoulders, hips) set the silhouette a
 * viewer reads first; limbs refine it. Weights are deliberately close to 1 so
 * importance breaks near-ties instead of overruling a much larger error.
 */
export const MEASUREMENT_IMPORTANCE: Readonly<Record<string, number>> =
  Object.freeze({
    leftShoulder: 1.2,
    rightShoulder: 1.2,
    leftHip: 1.15,
    rightHip: 1.15,
    leftKnee: 1.05,
    rightKnee: 1.05,
    leftElbow: 1,
    rightElbow: 1,
  });

/** Importance for ids without an explicit entry — never zero, never invented. */
export const DEFAULT_MEASUREMENT_IMPORTANCE = 1;

export function measurementImportance(measurementId: string): number {
  return MEASUREMENT_IMPORTANCE[measurementId] ?? DEFAULT_MEASUREMENT_IMPORTANCE;
}

/**
 * Canonical registry order for engine measurements: the MATCH_JOINTS order
 * from shared/ml/poseLandmarks.ts. Every iteration, report and tie-break in
 * the engine walks THIS order, so no result can depend on object key
 * insertion order, `Object.keys` luck or map iteration order.
 */
export const ANALYSIS_MEASUREMENT_IDS: readonly string[] = Object.freeze(
  MATCH_JOINTS.map((joint) => joint.key),
);

const REGISTRY_INDEX: ReadonlyMap<string, number> = new Map(
  ANALYSIS_MEASUREMENT_IDS.map((id, index) => [id, index]),
);

/** Deterministic tie-break rank; unknown ids sort after every known id. */
export function measurementRegistryIndex(measurementId: string): number {
  return REGISTRY_INDEX.get(measurementId) ?? ANALYSIS_MEASUREMENT_IDS.length;
}

/** The complete, immutable threshold set the engine was constructed with. */
export interface AnalysisThresholds {
  readonly goodToleranceDegrees: number;
  readonly correctionThresholdDegrees: number;
  readonly hysteresisReleaseMarginDegrees: number;
  readonly dominanceSwitchMarginRatio: number;
  readonly minCoachingConfidence: number;
  readonly minMeasurableConfidence: number;
  readonly minComparisonsForDecision: number;
  readonly plausibleAngle: { readonly min: number; readonly max: number };
}

export const DEFAULT_ANALYSIS_THRESHOLDS: AnalysisThresholds = Object.freeze({
  goodToleranceDegrees: GOOD_TOLERANCE_DEGREES,
  correctionThresholdDegrees: CORRECTION_THRESHOLD_DEGREES,
  hysteresisReleaseMarginDegrees: HYSTERESIS_RELEASE_MARGIN_DEGREES,
  dominanceSwitchMarginRatio: DOMINANCE_SWITCH_MARGIN_RATIO,
  minCoachingConfidence: MIN_COACHING_CONFIDENCE,
  minMeasurableConfidence: MIN_MEASURABLE_CONFIDENCE,
  minComparisonsForDecision: MIN_COMPARISONS_FOR_DECISION,
  plausibleAngle: Object.freeze({
    min: ANALYSIS_PLAUSIBLE_ANGLE.min,
    max: ANALYSIS_PLAUSIBLE_ANGLE.max,
  }),
});

export function resolveThresholds(
  overrides?: Partial<AnalysisThresholds>,
): AnalysisThresholds {
  if (overrides === undefined) return DEFAULT_ANALYSIS_THRESHOLDS;
  return Object.freeze({
    ...DEFAULT_ANALYSIS_THRESHOLDS,
    ...overrides,
    plausibleAngle: Object.freeze({
      ...DEFAULT_ANALYSIS_THRESHOLDS.plausibleAngle,
      ...(overrides.plausibleAngle ?? {}),
    }),
  });
}

/** Error below which an ACTIVE correction is released (hysteresis floor). */
export function releaseThresholdOf(thresholds: AnalysisThresholds): number {
  return thresholds.goodToleranceDegrees - thresholds.hysteresisReleaseMarginDegrees;
}
