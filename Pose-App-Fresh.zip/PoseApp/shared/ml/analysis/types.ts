/**
 * shared/ml/analysis/types.ts — Unit 29 engine vocabulary.
 * Platform-neutral, zero RN/DOM/Supabase/TTS/network.
 *
 * THE DATA FLOW THESE TYPES DESCRIBE:
 *
 *   LIVE LANDMARKS → MEASUREMENTS → COMPARISON → ERROR → CONFIDENCE →
 *   SEVERITY → PRIORITY → TEMPORAL STABILITY → ONE SEMANTIC DECISION
 *
 * Every stage is data, not behavior: each object states what is known, what
 * is missing and why, so no downstream layer has to guess (and no layer can
 * mistake "absent" for "zero").
 */

/** Why a live measurement could not be produced from this frame. */
export type LiveMeasurementState =
  | "measured"
  /** One of the three landmarks was absent from the frame payload. */
  | "landmark-missing"
  /** Landmark(s) below MIN_MEASURABLE_CONFIDENCE — present but untrustworthy. */
  | "landmark-unreliable"
  /** Geometry produced a non-finite or anatomically impossible angle. */
  | "implausible";

export interface LiveMeasurement {
  readonly measurementId: string;
  /** Degrees 0..180, or null when the measurement does not exist this frame. */
  readonly value: number | null;
  /** 0..1 — the weakest landmark confidence backing this measurement. */
  readonly confidence: number;
  readonly state: LiveMeasurementState;
}

/**
 * What the body must do to the joint angle. Defined purely by the SIGN of the
 * error, independent of any threshold:
 *   live < reference → 'increase' (open/extend the joint)
 *   live > reference → 'decrease' (close/bend the joint)
 *   live = reference → 'none'
 */
export type CorrectionDirection = "increase" | "decrease" | "none";

/** Severity ladder — monotone in |error|, never decreasing as error grows. */
export type ComparisonSeverity = "within-tolerance" | "minor" | "major";

/** Why a comparison is (or is not) usable for coaching. */
export type ComparisonValidity =
  | "valid"
  | "low-confidence"
  | "live-missing"
  | "reference-missing";

export interface MeasurementComparison {
  readonly measurementId: string;
  /** True when BOTH a live value and a reference value exist this frame. */
  readonly available: boolean;
  /** True when the comparison may drive coaching (available + confident). */
  readonly valid: boolean;
  readonly validity: ComparisonValidity;
  readonly referenceValue: number | null;
  readonly liveValue: number | null;
  /** live − reference, in degrees. Sign carries the direction; never dropped. */
  readonly signedError: number | null;
  readonly absError: number | null;
  readonly direction: CorrectionDirection;
  readonly severity: ComparisonSeverity;
  /** Combined 0..1 belief in this comparison (live × reference claim). */
  readonly confidence: number;
  readonly liveConfidence: number;
  /** The reference producer's claim, or null when it made none. */
  readonly referenceConfidence: number | null;
  readonly liveState: LiveMeasurementState;
}

/** A comparison promoted to a candidate correction, with its ranking score. */
export interface CorrectionCandidate {
  readonly measurementId: string;
  readonly direction: Exclude<CorrectionDirection, "none">;
  readonly severity: Exclude<ComparisonSeverity, "within-tolerance">;
  readonly signedError: number;
  readonly absError: number;
  readonly confidence: number;
  readonly importance: number;
  /** absError × importance × confidence — deterministic, order-independent. */
  readonly priorityScore: number;
  /** Canonical state string, e.g. "LEFT_ELBOW_INCREASE". */
  readonly state: string;
  /** Position in the canonical registry order (final tie-break). */
  readonly registryIndex: number;
}

/** Why the engine refuses to produce coaching for a frame. */
export type AnalysisUnavailableReason =
  | "reference-unavailable"
  | "reference-invalid"
  | "reference-incomplete"
  | "reference-incompatible"
  | "no-live-pose"
  | "insufficient-measurements"
  | "low-confidence";

export interface AnalysisUnavailable {
  readonly reason: AnalysisUnavailableReason;
  readonly message: string;
}

/** Canonical state emitted while the engine has not yet stabilized. */
export const ANALYSIS_STATE_EVALUATING = "EVALUATING";
export const ANALYSIS_STATE_PERFECT = "PERFECT";
export const ANALYSIS_STATE_UNAVAILABLE = "UNAVAILABLE";

export type AnalysisDecisionKind =
  | "perfect"
  | "correction"
  | "evaluating"
  | "unavailable";

/** The instantaneous (pre-temporal) reading of ONE frame. */
export interface FrameAnalysis {
  /** Registry-ordered, one entry per engine measurement id. Never sparse. */
  readonly comparisons: readonly MeasurementComparison[];
  /** Ranked candidates, best first; empty when nothing needs correcting. */
  readonly candidates: readonly CorrectionCandidate[];
  /** Comparisons with both sides present. */
  readonly comparedCount: number;
  /** Comparisons confident enough to coach from. */
  readonly usableCount: number;
  /** Largest |error| among usable comparisons; null when none. */
  readonly maxAbsError: number | null;
  /** Mean |error| among usable comparisons; null when none. */
  readonly meanAbsError: number | null;
  /** Set when this frame cannot be judged at all. */
  readonly unavailable: AnalysisUnavailable | null;
  /** What this frame alone would say: PERFECT / a correction / UNAVAILABLE. */
  readonly candidateState: string;
}

/** Temporal-stability bookkeeping exposed with every decision. */
export interface TemporalStatus {
  /** Consecutive frames the ACTIVE state has been held. */
  readonly framesHeld: number;
  /** State currently accumulating persistence, if any. */
  readonly pendingState: string | null;
  readonly pendingFrames: number;
  /** Frames still required before `pendingState` could take over. */
  readonly framesUntilSwitch: number;
  /** True when the active state was kept by hysteresis this frame. */
  readonly heldByHysteresis: boolean;
  /** Total frames analyzed by this engine instance. */
  readonly frameIndex: number;
}

/** Identity of the reference this decision was computed against. */
export interface AnalysisReferenceIdentity {
  readonly referenceId: string;
  readonly poseId: string;
  readonly schemaVersion: number;
  readonly measurementVersion: number;
  readonly contentHash: string;
}

/**
 * THE ONE SEMANTIC DECISION. Exactly one state at a time — the engine, not
 * the UI and not the TTS layer, decides which correction is dominant.
 */
export interface PoseAnalysisDecision {
  readonly kind: AnalysisDecisionKind;
  /** Canonical state token, e.g. "PERFECT" or "LEFT_ELBOW_INCREASE". */
  readonly state: string;
  /** Present only when kind === 'correction'. */
  readonly correction: CorrectionCandidate | null;
  /** Present only when kind === 'unavailable'. */
  readonly unavailable: AnalysisUnavailable | null;
  readonly frame: FrameAnalysis;
  readonly temporal: TemporalStatus;
  readonly reference: AnalysisReferenceIdentity | null;
}
