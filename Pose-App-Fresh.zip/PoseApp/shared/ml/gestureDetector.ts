/**
 * shared/ml/gestureDetector.ts — POSE-LEVEL HAND PRE-FILTER (not a gesture).
 *
 * HISTORY AND THE ROOT CAUSE THIS FILE NOW DOCUMENTS
 *
 * Unit 18 asked this module to decide "is the user showing an open palm?"
 * from the POSE model alone. PoseLandmarker gives four points per hand —
 * wrist, index tip, pinky tip, thumb tip — and it emits all four whenever the
 * arm is visible, regardless of what the fingers are doing. A fist, a wave, a
 * pointing finger and a genuinely open palm all produce the same four points
 * in almost the same relative positions, because finger articulation is not
 * in that tensor at all. The old thresholds ("tips are ~16 % of a forearm
 * away from the wrist and ~13 % apart") are therefore satisfied by ANY
 * visible raised hand. That is precisely why an accidental hand movement
 * took a photograph.
 *
 * So this file no longer claims to recognise a gesture. It answers one much
 * smaller, honest question:
 *
 *     "Is a hand plausibly being PRESENTED toward the camera right now?"
 *
 * and it is used for exactly one purpose: deciding whether it is worth
 * spending a HandLandmarker inference on this frame. Its output can never
 * authorise a capture — only openPalmClassifier (21 hand landmarks) plus
 * openPalmGate (temporal confirmation) can do that.
 */
import {
  MIN_LANDMARK_VISIBILITY,
  POSE_LANDMARKS,
  type PoseLandmark,
  type PoseLandmarkName,
} from "./poseLandmarks";

export type GestureHand = "left" | "right";

/** The result of the cheap pre-filter. NOT a capture authorisation. */
export interface HandPresentationResult {
  /** A hand is plausibly raised toward the camera — run hand detection. */
  readonly present: boolean;
  readonly hand: GestureHand | null;
  /** 0..1 plausibility, for diagnostics only. */
  readonly confidence: number;
}

interface HandPoints {
  readonly shoulder: PoseLandmarkName;
  readonly elbow: PoseLandmarkName;
  readonly wrist: PoseLandmarkName;
  readonly index: PoseLandmarkName;
  readonly pinky: PoseLandmarkName;
}

const HANDS: Readonly<Record<GestureHand, HandPoints>> = {
  left: {
    shoulder: "leftShoulder",
    elbow: "leftElbow",
    wrist: "leftWrist",
    index: "leftIndex",
    pinky: "leftPinky",
  },
  right: {
    shoulder: "rightShoulder",
    elbow: "rightElbow",
    wrist: "rightWrist",
    index: "rightIndex",
    pinky: "rightPinky",
  },
};

/** A forearm shorter than this is too small/too far to read fingers from. */
const MIN_FOREARM_LENGTH = 0.04;
/** The wrist must sit at least this far above the elbow, in forearm units. */
const MIN_WRIST_LIFT = 0.15;

function point(
  landmarks: readonly PoseLandmark[],
  name: PoseLandmarkName,
): PoseLandmark | null {
  const value = landmarks[POSE_LANDMARKS[name]];
  if (value === undefined || (value.visibility ?? 1) < MIN_LANDMARK_VISIBILITY) {
    return null;
  }
  return value;
}

function distance(a: PoseLandmark, b: PoseLandmark): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function inspectHand(
  landmarks: readonly PoseLandmark[],
  hand: GestureHand,
): HandPresentationResult {
  const names = HANDS[hand];
  const shoulder = point(landmarks, names.shoulder);
  const elbow = point(landmarks, names.elbow);
  const wrist = point(landmarks, names.wrist);
  const index = point(landmarks, names.index);
  const pinky = point(landmarks, names.pinky);
  if (
    shoulder === null ||
    elbow === null ||
    wrist === null ||
    index === null ||
    pinky === null
  ) {
    return { present: false, hand: null, confidence: 0 };
  }

  const forearm = distance(elbow, wrist);
  if (forearm < MIN_FOREARM_LENGTH) {
    return { present: false, hand: null, confidence: 0 };
  }

  /* y grows downward: a raised hand puts the wrist ABOVE the elbow. This is
     the one thing the pose model genuinely knows about "presenting a hand",
     and it cheaply excludes the resting-arm frames that make up most of a
     session. */
  const lift = (elbow.y - wrist.y) / forearm;
  if (lift < MIN_WRIST_LIFT) {
    return { present: false, hand: null, confidence: 0 };
  }

  const visibility = Math.min(
    wrist.visibility ?? 1,
    index.visibility ?? 1,
    pinky.visibility ?? 1,
  );
  const confidence = Math.max(
    0,
    Math.min(1, Math.min(lift / (MIN_WRIST_LIFT * 4), 1) * visibility),
  );
  return { present: true, hand, confidence };
}

/**
 * Cheap per-frame screen: should the (more expensive) hand landmarker look at
 * this frame? Returns the more plausible of the two hands.
 */
export function detectHandPresentation(
  landmarks: readonly PoseLandmark[],
): HandPresentationResult {
  if (landmarks.length === 0) {
    return { present: false, hand: null, confidence: 0 };
  }
  const left = inspectHand(landmarks, "left");
  const right = inspectHand(landmarks, "right");
  if (!left.present && !right.present) {
    return {
      present: false,
      hand: null,
      confidence: Math.max(left.confidence, right.confidence),
    };
  }
  if (left.present && right.present) {
    return left.confidence >= right.confidence ? left : right;
  }
  return left.present ? left : right;
}
