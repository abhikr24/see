/**
 * shared/ml/guidanceGenerator.ts — Unit 17 (platform-neutral, zero RN/DOM).
 *
 * Real-time pose comparison and visual guidance engine (spec §17.2).
 * Inspects per-joint angular differences between live landmarks and the
 * armed pose's reference angles, identifies the worst joint, and produces:
 *   · actionable directional instruction (e.g. "Raise left arm", "Bend right knee")
 *   · correction arrow direction ('up' | 'down' | 'left' | 'right' | 'none')
 *   · descriptive positioning hint (e.g. "Lift your left elbow to shoulder height")
 *   · severity status ('perfect' <10° | 'good' 10–25° | 'adjust' >25°)
 *
 * Pure functions: runs identically on mobile (mobile/) and web mirror (src/).
 */
import {
  MATCH_JOINTS,
  type PoseLandmark,
  type PoseLandmarkName,
} from './poseLandmarks';
import { jointAngle } from './poseMatch';
import {
  CORRECTION_THRESHOLD_DEGREES,
  GOOD_TOLERANCE_DEGREES,
} from './analysis/thresholds';
import type {
  ComparisonSeverity,
  CorrectionDirection,
} from './analysis/types';
import { type VoiceInstructionCategory } from '../constants/poseInstructions';

export type ArrowDirection = 'up' | 'down' | 'left' | 'right' | 'none';
export type GuidanceSeverity = 'perfect' | 'good' | 'adjust';

/** Guidance severity thresholds in degrees (spec §17.2). */
export const GUIDANCE_THRESHOLDS = {
  /* <10°: Green "Perfect! Hold still" — value owned by analysis/thresholds. */
  perfect: GOOD_TOLERANCE_DEGREES,
  /* 10°–25°: Amber minor adjustment — same single source of truth. */
  good: CORRECTION_THRESHOLD_DEGREES,
} as const;

/**
 * Unit 32 (Part 4.1) — SEMANTIC CARRY-THROUGH.
 *
 * `GuidanceResult` is a PRESENTATION contract: headline copy, arrow, colour
 * severity. Before this unit it was also a semantic dead end — the engine's
 * already-decided canonical state, correction direction, severity ladder and
 * confidence were all dropped at this boundary, so any consumer that needed
 * them had to re-derive them from `angleDiffs` (i.e. redo the mathematics in
 * a presentation layer). That was an architectural defect, not a style issue.
 *
 * These fields carry the engine's decision VERBATIM. Nothing downstream may
 * recompute them; nothing here computes them.
 */
export interface GuidanceSemantics {
  /** Canonical engine state token, e.g. "LEFT_ELBOW_INCREASE" / "PERFECT". */
  readonly state: string;
  /** The engine's signed-error direction — never re-derived from a diff. */
  readonly direction: CorrectionDirection;
  /**
   * The engine's severity ladder ('within-tolerance' | 'minor' | 'major'),
   * carried unchanged. `severity` below is the coarser UI colour band that is
   * DERIVED from this one; the two must never be computed independently.
   */
  readonly analysisSeverity: ComparisonSeverity | null;
  /** 0..1 belief backing the decision; null when the producer made no claim. */
  readonly confidence: number | null;
}

export interface GuidanceResult {
  /** Key of the joint needing the largest correction, or null if all good/hidden. */
  readonly worstJoint: string | null;
  /** Landmark name corresponding to the vertex of the worst joint. */
  readonly worstLandmarkName: PoseLandmarkName | null;
  /** Primary headline guidance, e.g. "Raise left arm" or "Perfect! Hold still". */
  readonly text: string;
  /** Secondary actionable detail hint below the headline. */
  readonly hint: string;
  /** Correction arrow direction at the joint vertex. */
  readonly arrowDirection: ArrowDirection;
  /** Severity level for color coding and UI priority. */
  readonly severity: GuidanceSeverity;
  /** Maximum angular difference among evaluated joints in degrees. */
  readonly maxDiff: number;
  /** True when all measurable joints are within the 10° threshold. */
  readonly isPerfect: boolean;
  /** Individual live angle measurements by joint key. */
  readonly liveAngles: Readonly<Record<string, number>>;
  /** Per-joint angular diffs in degrees. */
  readonly angleDiffs: Readonly<Record<string, number>>;
  /**
   * Unit 27: spoken-instruction category for the phrase bank
   * (poseInstructions.ts). Voice guidance speaks a varied, instructor-style
   * cue for this category instead of repeating the fixed headline text.
   */
  readonly voiceCategory: VoiceInstructionCategory;
  /**
   * Unit 32 — the engine decision this presentation result was rendered from.
   * `null` ONLY for the legacy landmark-in/guidance-out path below, which has
   * no engine decision to carry; it is explicitly absent, never faked.
   */
  readonly semantics: GuidanceSemantics | null;
}

/** Pre-authored directional copy per joint based on live vs reference angle (spec §17.2). */
export interface JointGuidanceDirective {
  readonly text: string;
  readonly hint: string;
  readonly arrowDirection: ArrowDirection;
  /** Unit 27: phrase-bank category for the spoken instructor cue. */
  readonly voiceCategory: VoiceInstructionCategory;
}

export interface JointGuidanceRule {
  readonly vertexLandmark: PoseLandmarkName;
  readonly liveLessThanRef: JointGuidanceDirective;
  readonly liveGreaterThanRef: JointGuidanceDirective;
}

/**
 * Unit 29: exported so the analysis engine's semantic bridge can reuse the
 * ONE copy table instead of duplicating instructor phrasing.
 */
export const JOINT_GUIDANCE_RULES: Readonly<Record<string, JointGuidanceRule>> = {
  leftElbow: {
    vertexLandmark: 'leftElbow',
    liveLessThanRef: {
      text: 'Straighten left arm',
      hint: 'Extend your left forearm outward to open the elbow angle',
      arrowDirection: 'right',
      /* Unit 33 repair: was 'hand_right', a LATERAL "slide the hand right"
         pool — unrelated to the elbow extension the engine decided on. */
      voiceCategory: 'hand_left_straighten',
    },
    liveGreaterThanRef: {
      text: 'Bend left arm',
      hint: 'Bring your left hand closer to your body to bend the elbow',
      arrowDirection: 'left',
      /* Unit 33 repair: was 'hand_left' (lateral hand shift copy). */
      voiceCategory: 'hand_left_bend',
    },
  },
  rightElbow: {
    vertexLandmark: 'rightElbow',
    liveLessThanRef: {
      text: 'Straighten right arm',
      hint: 'Extend your right forearm outward to open the elbow angle',
      arrowDirection: 'left',
      /* Unit 33 repair: was 'hand_left' (lateral hand shift copy). */
      voiceCategory: 'hand_right_straighten',
    },
    liveGreaterThanRef: {
      text: 'Bend right arm',
      hint: 'Bring your right hand closer to your body to bend the elbow',
      arrowDirection: 'right',
      /* Unit 33 repair: was 'hand_right' (lateral hand shift copy). */
      voiceCategory: 'hand_right_bend',
    },
  },
  leftKnee: {
    vertexLandmark: 'leftKnee',
    liveLessThanRef: {
      text: 'Straighten left leg',
      hint: 'Extend your left leg and push through your heel',
      arrowDirection: 'down',
      /* Unit 32 repair: was 'leg_left', whose pool mixes straighten AND
         bend lines — the engine's direction was discarded at the category
         boundary and the coach could say the exact opposite. */
      voiceCategory: 'leg_left_straighten',
    },
    liveGreaterThanRef: {
      text: 'Bend left leg',
      hint: 'Soften and bend your left knee slightly',
      arrowDirection: 'up',
      voiceCategory: 'leg_left_bend',
    },
  },
  rightKnee: {
    vertexLandmark: 'rightKnee',
    liveLessThanRef: {
      text: 'Straighten right leg',
      hint: 'Extend your right leg and push through your heel',
      arrowDirection: 'down',
      /* Unit 32 repair: was 'leg_right', whose pool mixes straighten AND
         bend lines — the engine's direction was discarded at the category
         boundary and the coach could say the exact opposite. */
      voiceCategory: 'leg_right_straighten',
    },
    liveGreaterThanRef: {
      text: 'Bend right leg',
      hint: 'Soften and bend your right knee slightly',
      arrowDirection: 'up',
      voiceCategory: 'leg_right_bend',
    },
  },
  leftShoulder: {
    vertexLandmark: 'leftShoulder',
    liveLessThanRef: {
      text: 'Raise left arm',
      hint: 'Lift your left elbow outward away from your torso',
      arrowDirection: 'up',
      voiceCategory: 'hand_up',
    },
    liveGreaterThanRef: {
      text: 'Lower left arm',
      hint: 'Relax your left arm down closer to your hip',
      arrowDirection: 'down',
      voiceCategory: 'hand_down',
    },
  },
  rightShoulder: {
    vertexLandmark: 'rightShoulder',
    liveLessThanRef: {
      text: 'Raise right arm',
      hint: 'Lift your right elbow outward away from your torso',
      arrowDirection: 'up',
      voiceCategory: 'hand_up',
    },
    liveGreaterThanRef: {
      text: 'Lower right arm',
      hint: 'Relax your right arm down closer to your hip',
      arrowDirection: 'down',
      voiceCategory: 'hand_down',
    },
  },
  leftHip: {
    vertexLandmark: 'leftHip',
    liveLessThanRef: {
      text: 'Move left leg back',
      hint: 'Bring your left thigh back to align with your torso',
      arrowDirection: 'down',
      /* Unit 33 repair: was 'leg_close', a STANCE-WIDTH pool ("feet closer
         together") — the hip angle asks for the leg to travel back. */
      voiceCategory: 'leg_left_back',
    },
    liveGreaterThanRef: {
      text: 'Move left leg forward',
      hint: 'Step your left leg slightly forward for dynamic stance',
      arrowDirection: 'up',
      /* Unit 33 repair: was 'leg_open' (stance-width copy). */
      voiceCategory: 'leg_left_forward',
    },
  },
  rightHip: {
    vertexLandmark: 'rightHip',
    liveLessThanRef: {
      text: 'Move right leg back',
      hint: 'Bring your right thigh back to align with your torso',
      arrowDirection: 'down',
      /* Unit 33 repair: was 'leg_close' (stance-width copy). */
      voiceCategory: 'leg_right_back',
    },
    liveGreaterThanRef: {
      text: 'Move right leg forward',
      hint: 'Step your right leg slightly forward for dynamic stance',
      arrowDirection: 'up',
      /* Unit 33 repair: was 'leg_open' (stance-width copy). */
      voiceCategory: 'leg_right_forward',
    },
  },
};

/**
 * Unit 32 (Part 4.1) — THE ONE directive resolver.
 *
 * (measurementId, direction) → the pre-authored copy for that correction.
 * Before this unit three call sites re-derived the same thing from raw
 * numbers (`live < ref`, `signedError < 0`, `direction === 'increase'`), which
 * is duplicated mathematical inference in copy/presentation layers. They now
 * all funnel through here, so the on-screen directive, the arrow and the
 * spoken category can never disagree about which way the body must move.
 *
 *   direction 'increase' ⇒ live angle is SMALLER than the reference
 *                          ⇒ open/extend the joint ⇒ `liveLessThanRef`
 *   direction 'decrease' ⇒ live angle is LARGER than the reference
 *                          ⇒ close/bend the joint  ⇒ `liveGreaterThanRef`
 *
 * Returns null for 'none' or an unknown measurement — the caller must then
 * stay silent rather than invent a body part or a direction.
 */
export function jointDirectiveFor(
  measurementId: string,
  direction: CorrectionDirection,
): JointGuidanceDirective | null {
  if (direction === 'none') return null;
  const rule = JOINT_GUIDANCE_RULES[measurementId];
  if (rule === undefined) return null;
  return direction === 'increase' ? rule.liveLessThanRef : rule.liveGreaterThanRef;
}

/**
 * Unit 32 — engine severity ladder → the coarse UI colour band.
 * The ONLY place this collapse happens. `GuidanceResult.severity` is the
 * output of this function; no consumer may re-threshold an angle to get it.
 *
 *   'within-tolerance' → 'good'   (held inside tolerance by hysteresis)
 *   'minor'            → 'good'   (amber band, historical 10°–25°)
 *   'major'            → 'adjust' (historical >25°)
 */
export function guidanceSeverityFor(
  severity: ComparisonSeverity,
): GuidanceSeverity {
  return severity === 'major' ? 'adjust' : 'good';
}

/**
 * Generates live pose guidance from raw landmark inputs and the reference angles.
 * Returns null if no person is detected or < 2 joints are measurable.
 *
 * LEGACY PATH (Unit 17). It owns no semantic decision, so it reports
 * `semantics: null`. New code must go through the analysis engine and
 * `decisionToGuidance`.
 */
export function generatePoseGuidance(
  liveLandmarks: readonly PoseLandmark[],
  referenceAngles: Readonly<Record<string, number>> | null,
): GuidanceResult | null {
  if (referenceAngles === null || liveLandmarks.length === 0) {
    return null;
  }

  const liveAngles: Record<string, number> = {};
  const angleDiffs: Record<string, number> = {};

  let worstJointKey: string | null = null;
  let maxDiff = -1;

  for (const joint of MATCH_JOINTS) {
    const ref = referenceAngles[joint.key];
    if (ref === undefined) continue;
    const live = jointAngle(liveLandmarks, joint);
    if (live === null) continue;

    liveAngles[joint.key] = live;
    const diff = Math.abs(live - ref);
    angleDiffs[joint.key] = diff;

    if (diff > maxDiff) {
      maxDiff = diff;
      worstJointKey = joint.key;
    }
  }

  const comparedCount = Object.keys(angleDiffs).length;
  if (comparedCount < 2 || worstJointKey === null) {
    return null;
  }

  // All joints within 10° tolerance: "Perfect! Hold still"
  if (maxDiff < GUIDANCE_THRESHOLDS.perfect) {
    return {
      worstJoint: null,
      worstLandmarkName: null,
      text: 'Perfect! Hold still',
      hint: 'Hold this stance for the cleanest photo capture',
      arrowDirection: 'none',
      voiceCategory: 'final_pose_good',
      severity: 'perfect',
      maxDiff,
      isPerfect: true,
      liveAngles,
      angleDiffs,
      semantics: null,
    };
  }

  const rule = JOINT_GUIDANCE_RULES[worstJointKey];
  /* Unit 29 compatibility correction: these used to read `?? 90`, inventing a
     90° reference/live angle when a measurement was absent. A missing value is
     NOT a value — and the worst joint is by construction one that had BOTH a
     reference and a live angle, so an absent entry here means the invariant
     broke. Bail out instead of coaching against a fabricated number. */
  const refVal = referenceAngles[worstJointKey];
  const liveVal = liveAngles[worstJointKey];
  if (refVal === undefined || liveVal === undefined) {
    return null;
  }
  /* Direction is a SIGN decision, resolved in exactly one place. */
  const direction: CorrectionDirection = liveVal < refVal ? 'increase' : 'decrease';

  const directive = jointDirectiveFor(worstJointKey, direction)
    ?? {
        // Unreachable today — every MATCH_JOINT has a rule — kept as a
        // safe fallback if MATCH_JOINTS ever grows beyond the rule table.
        text: `Adjust ${worstJointKey}`,
        hint: `Align your ${worstJointKey} with the reference pose`,
        arrowDirection: 'none' as ArrowDirection,
        voiceCategory: 'shoulder_straight' as VoiceInstructionCategory,
      };

  const severity: GuidanceSeverity =
    maxDiff <= GUIDANCE_THRESHOLDS.good ? 'good' : 'adjust';

  return {
    worstJoint: worstJointKey,
    worstLandmarkName: rule?.vertexLandmark ?? null,
    text: directive.text,
    hint: directive.hint,
    arrowDirection: directive.arrowDirection,
    voiceCategory: directive.voiceCategory,
    severity,
    maxDiff,
    isPerfect: false,
    liveAngles,
    angleDiffs,
    semantics: null,
  };
}
