/**
 * shared/ml/handLandmarks.ts — the 21-point MediaPipe Hand contract.
 *
 * Platform-neutral: zero RN, zero DOM, zero expo, zero React, zero network.
 *
 * WHY THIS FILE EXISTS
 *
 * Gesture capture used to be inferred from the POSE model's hand points
 * (wrist + index/pinky/thumb tips, pose indices 15–22). BlazePose emits those
 * four points whenever an arm is visible, whatever the fingers are doing: a
 * fist, a wave, a pointing finger and an open palm all produce a wrist plus
 * three "tips" in almost the same places. Finger articulation is simply not
 * in that tensor, so no threshold on it can separate "hand exists" from
 * "hand is deliberately open". That is the root cause of accidental capture.
 *
 * The HandLandmarker task emits 21 points per hand with real per-finger
 * joints (MCP → PIP → DIP → TIP), which is the minimum evidence needed to
 * answer "are all five fingers extended?". This module is only the contract;
 * the classifier lives next door in openPalmClassifier.ts and the temporal
 * gate in openPalmGate.ts, so gesture recognition stays a separate concern
 * from body-pose matching.
 */

/** One normalized hand landmark (image space, 0..1, z relative to wrist). */
export interface HandLandmark {
  readonly x: number;
  readonly y: number;
  readonly z: number;
  /** Present on some runtimes; absent means "no per-point score". */
  readonly visibility?: number;
}

/** Canonical MediaPipe hand landmark indices (21). */
export const HAND_LANDMARKS = {
  wrist: 0,
  thumbCmc: 1,
  thumbMcp: 2,
  thumbIp: 3,
  thumbTip: 4,
  indexMcp: 5,
  indexPip: 6,
  indexDip: 7,
  indexTip: 8,
  middleMcp: 9,
  middlePip: 10,
  middleDip: 11,
  middleTip: 12,
  ringMcp: 13,
  ringPip: 14,
  ringDip: 15,
  ringTip: 16,
  pinkyMcp: 17,
  pinkyPip: 18,
  pinkyDip: 19,
  pinkyTip: 20,
} as const;

export type HandLandmarkName = keyof typeof HAND_LANDMARKS;
export const HAND_LANDMARK_COUNT = 21;

export type HandSide = "left" | "right" | "unknown";

/**
 * One detected hand, exactly as the app-facing detector facade hands it over.
 * `score` is the detector's own confidence — it is an INPUT to the gate, never
 * a substitute for geometry.
 */
export interface HandObservation {
  readonly landmarks: readonly HandLandmark[];
  readonly side: HandSide;
  /** Detector handedness/presence confidence, 0..1. */
  readonly score: number;
}

/** The four jointed fingers plus the thumb, in anatomical order. */
export type FingerName = "thumb" | "index" | "middle" | "ring" | "pinky";

export const FINGER_ORDER: readonly FingerName[] = [
  "thumb",
  "index",
  "middle",
  "ring",
  "pinky",
];

/** Per-finger joint chain (MCP → PIP → DIP → TIP; thumb uses MCP → IP → TIP). */
export const FINGER_CHAINS: Readonly<
  Record<
    FingerName,
    {
      readonly mcp: HandLandmarkName;
      readonly pip: HandLandmarkName;
      readonly dip: HandLandmarkName;
      readonly tip: HandLandmarkName;
    }
  >
> = {
  thumb: { mcp: "thumbCmc", pip: "thumbMcp", dip: "thumbIp", tip: "thumbTip" },
  index: { mcp: "indexMcp", pip: "indexPip", dip: "indexDip", tip: "indexTip" },
  middle: {
    mcp: "middleMcp",
    pip: "middlePip",
    dip: "middleDip",
    tip: "middleTip",
  },
  ring: { mcp: "ringMcp", pip: "ringPip", dip: "ringDip", tip: "ringTip" },
  pinky: { mcp: "pinkyMcp", pip: "pinkyPip", dip: "pinkyDip", tip: "pinkyTip" },
};

export function handPoint(
  landmarks: readonly HandLandmark[],
  name: HandLandmarkName,
): HandLandmark | null {
  return landmarks[HAND_LANDMARKS[name]] ?? null;
}

/** True only for a complete, finite 21-point hand. */
export function isCompleteHand(landmarks: readonly HandLandmark[]): boolean {
  if (landmarks.length < HAND_LANDMARK_COUNT) return false;
  for (let index = 0; index < HAND_LANDMARK_COUNT; index += 1) {
    const point = landmarks[index];
    if (point === undefined) return false;
    if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) return false;
    if (!Number.isFinite(point.z)) return false;
  }
  return true;
}
