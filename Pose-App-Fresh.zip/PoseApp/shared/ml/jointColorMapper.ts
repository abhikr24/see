/**
 * shared/ml/jointColorMapper.ts — Unit 17 (platform-neutral, zero RN/DOM).
 *
 * Maps per-joint angular differences to design token colors (spec §17.2):
 *   · <10° diff:   Green (#10B981) — perfect alignment
 *   · 10°–25° diff: Amber (#F59E0B) — minor adjustment needed
 *   · >25° diff:   Red   (#EF4444) — major adjustment needed
 *
 * Also computes landmark dot colors (33 landmarks) and bone connection colors
 * (worst of connected joints) so the skeleton overlay provides immediate
 * visual feedback on where the user needs to adjust.
 */
import {
  POSE_BONE_CONNECTIONS,
  POSE_LANDMARKS,
  type PoseLandmarkName,
} from './poseLandmarks';

export const JOINT_STATUS_COLORS = {
  perfect: '#10B981', // Green <10°
  good: '#F59E0B',    // Amber 10°–25°
  adjust: '#EF4444',  // Red >25°
  default: '#2563EB', // Primary Blue default for non-joint landmarks
} as const;

/** Landmark names mapped to their primary match joint keys. */
const LANDMARK_TO_JOINTS: Readonly<Record<PoseLandmarkName, readonly string[]>> = {
  leftElbow: ['leftElbow'],
  rightElbow: ['rightElbow'],
  leftWrist: ['leftElbow'],
  rightWrist: ['rightElbow'],
  leftShoulder: ['leftShoulder'],
  rightShoulder: ['rightShoulder'],
  leftHip: ['leftHip'],
  rightHip: ['rightHip'],
  leftKnee: ['leftKnee'],
  rightKnee: ['rightKnee'],
  leftAnkle: ['leftKnee'],
  rightAnkle: ['rightKnee'],
  // Head & facial landmarks — default neutral
  nose: [],
  leftEyeInner: [],
  leftEye: [],
  leftEyeOuter: [],
  rightEyeInner: [],
  rightEye: [],
  rightEyeOuter: [],
  leftEar: [],
  rightEar: [],
  mouthLeft: [],
  mouthRight: [],
  leftPinky: [],
  rightPinky: [],
  leftIndex: [],
  rightIndex: [],
  leftThumb: [],
  rightThumb: [],
  leftHeel: [],
  rightHeel: [],
  leftFootIndex: [],
  rightFootIndex: [],
};

/**
 * Returns the status color for a given angular difference in degrees.
 */
export function colorForDiff(diff: number | undefined): string {
  if (diff === undefined || !Number.isFinite(diff)) {
    return JOINT_STATUS_COLORS.default;
  }
  if (diff < 10) return JOINT_STATUS_COLORS.perfect;
  if (diff <= 25) return JOINT_STATUS_COLORS.good;
  return JOINT_STATUS_COLORS.adjust;
}

/**
 * Maps each of the 33 landmarks to a status color based on evaluated joint diffs.
 */
export function mapLandmarkColors(
  angleDiffs: Readonly<Record<string, number>>,
  fallbackPrimary: string = JOINT_STATUS_COLORS.default,
): Readonly<Record<number, string>> {
  const result: Record<number, string> = {};

  (Object.keys(POSE_LANDMARKS) as PoseLandmarkName[]).forEach((name) => {
    const index = POSE_LANDMARKS[name];
    const jointKeys = LANDMARK_TO_JOINTS[name] ?? [];

    if (jointKeys.length === 0) {
      result[index] = fallbackPrimary;
      return;
    }

    // Find the worst diff affecting this landmark
    let maxDiff = -1;
    for (const key of jointKeys) {
      const diff = angleDiffs[key];
      if (diff !== undefined && diff > maxDiff) {
        maxDiff = diff;
      }
    }

    result[index] = maxDiff >= 0 ? colorForDiff(maxDiff) : fallbackPrimary;
  });

  return result;
}

/**
 * Maps each of the 16 display bones to a color based on the worst diff
 * of its two endpoints (spec §17.2).
 */
export function mapBoneColors(
  landmarkColors: Readonly<Record<number, string>>,
  fallbackPrimary: string = JOINT_STATUS_COLORS.default,
): readonly string[] {
  return POSE_BONE_CONNECTIONS.map(([fromName, toName]) => {
    const fromIdx = POSE_LANDMARKS[fromName];
    const toIdx = POSE_LANDMARKS[toName];
    const fromColor = landmarkColors[fromIdx] ?? fallbackPrimary;
    const toColor = landmarkColors[toIdx] ?? fallbackPrimary;

    // Severity hierarchy: Red > Amber > Green > Primary
    if (fromColor === JOINT_STATUS_COLORS.adjust || toColor === JOINT_STATUS_COLORS.adjust) {
      return JOINT_STATUS_COLORS.adjust;
    }
    if (fromColor === JOINT_STATUS_COLORS.good || toColor === JOINT_STATUS_COLORS.good) {
      return JOINT_STATUS_COLORS.good;
    }
    if (fromColor === JOINT_STATUS_COLORS.perfect && toColor === JOINT_STATUS_COLORS.perfect) {
      return JOINT_STATUS_COLORS.perfect;
    }
    return fallbackPrimary;
  });
}
