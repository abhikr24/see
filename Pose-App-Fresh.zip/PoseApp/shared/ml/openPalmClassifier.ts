/**
 * shared/ml/openPalmClassifier.ts — SINGLE-FRAME open-palm evidence.
 *
 * Platform-neutral, pure, total: no clock, no randomness, no I/O.
 *
 * CONTRACT
 *
 * Given one detected hand (21 MediaPipe hand landmarks) this module answers
 * *how much evidence exists, in THIS frame, that the user is deliberately
 * showing an open five-finger palm toward the camera* — and nothing else. It
 * never triggers anything. A single frame is explicitly NOT permission to
 * capture; that decision belongs to openPalmGate.ts, which requires the same
 * evidence to persist, stay still, and be released before it can repeat.
 *
 * WHAT COUNTS AS EVIDENCE (all of it required, not any of it)
 *
 *   1. detector confidence     — the model itself must be sure a hand is there
 *   2. non-degenerate scale    — a hand a few pixels wide carries no geometry
 *   3. five extended fingers   — per-finger, from the real joint chain:
 *        · reach     : |wrist→tip| clearly exceeds |wrist→pip|
 *        · straight  : the PIP and DIP joints are nearly straight
 *      A curled finger fails BOTH, which is exactly what separates a fist,
 *      a pointing finger and a peace sign from an open palm.
 *   4. separation              — adjacent fingertips are apart, not a paddle
 *   5. openness                — the fingertip fan reaches well past the palm
 *   6. orientation             — the palm plane faces the camera: an edge-on
 *      hand (the shape a moving/waving arm makes) collapses palm width and
 *      is rejected even when the fingers happen to be straight.
 *
 * Every threshold is exported so tests can state them and a future settings
 * unit can expose a sensitivity without touching this logic.
 */
import {
  FINGER_CHAINS,
  FINGER_ORDER,
  handPoint,
  isCompleteHand,
  type FingerName,
  type HandLandmark,
  type HandObservation,
  type HandSide,
} from "./handLandmarks";

export type OpenPalmRejection =
  | "none"
  | "no-hand"
  | "incomplete-landmarks"
  | "low-confidence"
  | "degenerate-scale"
  | "fingers-not-extended"
  | "fingers-not-separated"
  | "palm-not-open"
  | "palm-not-facing-camera";

export interface FingerEvidence {
  readonly finger: FingerName;
  readonly extended: boolean;
  /** 0..1 — how straight the joint chain is (1 = fully straight). */
  readonly straightness: number;
  /** |wrist→tip| / |wrist→pip|; >1 means the tip reaches past the knuckle. */
  readonly reachRatio: number;
}

export interface OpenPalmEvidence {
  /** True only when EVERY gate above passed in this single frame. */
  readonly isOpenPalm: boolean;
  readonly rejection: OpenPalmRejection;
  readonly side: HandSide;
  readonly extendedCount: number;
  readonly fingers: readonly FingerEvidence[];
  /** 0..1 scores for the non-binary gates, useful for tuning and tests. */
  readonly separationScore: number;
  readonly opennessScore: number;
  readonly orientationScore: number;
  readonly detectorConfidence: number;
  /** 0..1 aggregate (the weakest link), for display and diagnostics only. */
  readonly score: number;
  /** Palm centroid in normalized image space — the gate's stability anchor. */
  readonly centroidX: number;
  readonly centroidY: number;
  /** Palm width in normalized units — the gate's motion yardstick. */
  readonly scale: number;
}

/**
 * Tuned against the synthetic hand model in tests/camera/handFixtures.ts,
 * which is built from real MediaPipe hand proportions. The intent is
 * deliberately asymmetric: a missed gesture costs one repeat, an accidental
 * gesture costs a wrong photograph, so every bound sits on the strict side of
 * the measured open-palm value and well clear of the measured fist value.
 */
export const OPEN_PALM_THRESHOLDS = {
  /** Detector presence/handedness confidence floor. */
  minDetectorConfidence: 0.6,
  /** Palm width below this (normalized image units) carries no geometry. */
  minPalmWidth: 0.045,
  /** |wrist→tip| must exceed |wrist→pip| by this factor (four fingers). */
  minFingerReachRatio: 1.18,
  /** Straightness floor for the four jointed fingers (1 = perfectly straight). */
  minFingerStraightness: 0.78,
  /** The thumb bends differently; it gets its own, looser straightness floor. */
  minThumbStraightness: 0.62,
  /** Thumb tip must stand off the index knuckle by this fraction of palm width. */
  minThumbSpread: 0.62,
  /** Adjacent fingertip gap, as a fraction of palm width. */
  minAdjacentTipGap: 0.17,
  /** Index-tip→pinky-tip span, as a fraction of palm width. */
  minTipSpan: 0.72,
  /** Mean |wrist→tip| of the four fingers, as a multiple of palm width. */
  minOpenness: 1.55,
  /** palmWidth / palmLength — collapses when the hand turns edge-on. */
  minPalmAspect: 0.52,
  /** Aggregate score floor, on top of every individual gate. */
  minScore: 0.55,
} as const;

const EMPTY_FINGERS: readonly FingerEvidence[] = FINGER_ORDER.map((finger) => ({
  finger,
  extended: false,
  straightness: 0,
  reachRatio: 0,
}));

function rejected(
  rejection: OpenPalmRejection,
  side: HandSide,
  detectorConfidence: number,
): OpenPalmEvidence {
  return {
    isOpenPalm: false,
    rejection,
    side,
    extendedCount: 0,
    fingers: EMPTY_FINGERS,
    separationScore: 0,
    opennessScore: 0,
    orientationScore: 0,
    detectorConfidence,
    score: 0,
    centroidX: 0,
    centroidY: 0,
    scale: 0,
  };
}

function distance2d(a: HandLandmark, b: HandLandmark): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/**
 * 1 when the three points are collinear (joint straight), 0 at a right angle
 * or sharper. Curled fingers sit far below any usable floor.
 */
function straightness(
  a: HandLandmark,
  vertex: HandLandmark,
  b: HandLandmark,
): number {
  const ax = a.x - vertex.x;
  const ay = a.y - vertex.y;
  const bx = b.x - vertex.x;
  const by = b.y - vertex.y;
  const magnitude = Math.hypot(ax, ay) * Math.hypot(bx, by);
  if (magnitude <= 0) return 0;
  const cosine = (ax * bx + ay * by) / magnitude;
  const angle = Math.acos(Math.max(-1, Math.min(1, cosine)));
  // 180° → 1, 90° → 0, sharper → 0.
  return Math.max(0, (angle - Math.PI / 2) / (Math.PI / 2));
}

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

/** Evidence for one hand. Total: any malformed input returns a rejection. */
export function classifyOpenPalm(
  observation: HandObservation | null,
): OpenPalmEvidence {
  if (observation === null) return rejected("no-hand", "unknown", 0);
  const { landmarks, side } = observation;
  const confidence = Number.isFinite(observation.score) ? observation.score : 0;
  if (!isCompleteHand(landmarks)) {
    return rejected("incomplete-landmarks", side, confidence);
  }
  if (confidence < OPEN_PALM_THRESHOLDS.minDetectorConfidence) {
    return rejected("low-confidence", side, confidence);
  }

  const wrist = handPoint(landmarks, "wrist");
  const indexMcp = handPoint(landmarks, "indexMcp");
  const middleMcp = handPoint(landmarks, "middleMcp");
  const pinkyMcp = handPoint(landmarks, "pinkyMcp");
  if (
    wrist === null ||
    indexMcp === null ||
    middleMcp === null ||
    pinkyMcp === null
  ) {
    return rejected("incomplete-landmarks", side, confidence);
  }

  const palmWidth = distance2d(indexMcp, pinkyMcp);
  const palmLength = distance2d(wrist, middleMcp);
  if (
    palmWidth < OPEN_PALM_THRESHOLDS.minPalmWidth ||
    palmLength <= 0 ||
    !Number.isFinite(palmWidth)
  ) {
    return rejected("degenerate-scale", side, confidence);
  }

  /* ── 3. per-finger extension ─────────────────────────────────────────── */
  const fingers: FingerEvidence[] = [];
  for (const finger of FINGER_ORDER) {
    const chain = FINGER_CHAINS[finger];
    const mcp = handPoint(landmarks, chain.mcp);
    const pip = handPoint(landmarks, chain.pip);
    const dip = handPoint(landmarks, chain.dip);
    const tip = handPoint(landmarks, chain.tip);
    if (mcp === null || pip === null || dip === null || tip === null) {
      return rejected("incomplete-landmarks", side, confidence);
    }
    const pipStraight = straightness(mcp, pip, tip);
    const dipStraight = straightness(pip, dip, tip);
    const chainStraightness = clamp01((pipStraight + dipStraight) / 2);
    const pipReach = distance2d(wrist, pip);
    const reachRatio = pipReach > 0 ? distance2d(wrist, tip) / pipReach : 0;

    let extended: boolean;
    if (finger === "thumb") {
      /* The thumb never "reaches past its knuckle" the way a finger does — it
         abducts sideways. Its evidence is therefore standoff from the index
         knuckle plus a straight IP joint. A fist tucks the thumb across the
         fingers, collapsing both. */
      const standoff = distance2d(tip, indexMcp) / palmWidth;
      extended =
        chainStraightness >= OPEN_PALM_THRESHOLDS.minThumbStraightness &&
        standoff >= OPEN_PALM_THRESHOLDS.minThumbSpread;
    } else {
      extended =
        chainStraightness >= OPEN_PALM_THRESHOLDS.minFingerStraightness &&
        reachRatio >= OPEN_PALM_THRESHOLDS.minFingerReachRatio;
    }
    fingers.push({ finger, extended, straightness: chainStraightness, reachRatio });
  }

  const extendedCount = fingers.reduce(
    (total, finger) => total + (finger.extended ? 1 : 0),
    0,
  );

  /* ── geometry scores (computed even when a gate already failed, so the
        diagnostics that reach the UI and the tests stay meaningful) ─────── */
  const indexTip = handPoint(landmarks, "indexTip");
  const middleTip = handPoint(landmarks, "middleTip");
  const ringTip = handPoint(landmarks, "ringTip");
  const pinkyTip = handPoint(landmarks, "pinkyTip");
  if (
    indexTip === null ||
    middleTip === null ||
    ringTip === null ||
    pinkyTip === null
  ) {
    return rejected("incomplete-landmarks", side, confidence);
  }

  const gaps = [
    distance2d(indexTip, middleTip) / palmWidth,
    distance2d(middleTip, ringTip) / palmWidth,
    distance2d(ringTip, pinkyTip) / palmWidth,
  ];
  const smallestGap = Math.min(...gaps);
  const span = distance2d(indexTip, pinkyTip) / palmWidth;
  const separationScore = Math.min(
    clamp01(smallestGap / OPEN_PALM_THRESHOLDS.minAdjacentTipGap),
    clamp01(span / OPEN_PALM_THRESHOLDS.minTipSpan),
  );

  const openness =
    (distance2d(wrist, indexTip) +
      distance2d(wrist, middleTip) +
      distance2d(wrist, ringTip) +
      distance2d(wrist, pinkyTip)) /
    (4 * palmWidth);
  const opennessScore = clamp01(openness / OPEN_PALM_THRESHOLDS.minOpenness);

  const palmAspect = palmWidth / palmLength;
  const orientationScore = clamp01(
    palmAspect / OPEN_PALM_THRESHOLDS.minPalmAspect,
  );

  const centroidX = (wrist.x + indexMcp.x + middleMcp.x + pinkyMcp.x) / 4;
  const centroidY = (wrist.y + indexMcp.y + middleMcp.y + pinkyMcp.y) / 4;

  const weakestFinger = fingers.reduce(
    (lowest, finger) => Math.min(lowest, finger.straightness),
    1,
  );
  const score = Math.min(
    clamp01(confidence),
    separationScore,
    opennessScore,
    orientationScore,
    clamp01(weakestFinger),
  );

  const base = {
    side,
    extendedCount,
    fingers,
    separationScore,
    opennessScore,
    orientationScore,
    detectorConfidence: confidence,
    score,
    centroidX,
    centroidY,
    scale: palmWidth,
  };

  /* ── the gates, in the order that produces the most honest reason ─────── */
  if (extendedCount < FINGER_ORDER.length) {
    return { ...base, isOpenPalm: false, rejection: "fingers-not-extended" };
  }
  if (orientationScore < 1) {
    return { ...base, isOpenPalm: false, rejection: "palm-not-facing-camera" };
  }
  if (separationScore < 1) {
    return { ...base, isOpenPalm: false, rejection: "fingers-not-separated" };
  }
  if (opennessScore < 1) {
    return { ...base, isOpenPalm: false, rejection: "palm-not-open" };
  }
  if (score < OPEN_PALM_THRESHOLDS.minScore) {
    return { ...base, isOpenPalm: false, rejection: "palm-not-open" };
  }
  return { ...base, isOpenPalm: true, rejection: "none" };
}

/**
 * Picks the ONE hand that is meant to be the capture command.
 *
 * Two open palms are not two commands: the strongest single hand wins, and if
 * nothing qualifies the best rejected evidence is still returned so the UI can
 * say "I can see a hand but it is not an open palm" instead of going silent.
 */
export function selectCaptureHand(
  hands: readonly HandObservation[] | null,
): OpenPalmEvidence {
  if (hands === null || hands.length === 0) {
    return rejected("no-hand", "unknown", 0);
  }
  let best: OpenPalmEvidence | null = null;
  for (const hand of hands) {
    const evidence = classifyOpenPalm(hand);
    if (best === null) {
      best = evidence;
      continue;
    }
    if (evidence.isOpenPalm && !best.isOpenPalm) {
      best = evidence;
      continue;
    }
    if (evidence.isOpenPalm === best.isOpenPalm && evidence.score > best.score) {
      best = evidence;
    }
  }
  return best ?? rejected("no-hand", "unknown", 0);
}
