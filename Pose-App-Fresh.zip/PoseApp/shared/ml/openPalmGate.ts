/**
 * shared/ml/openPalmGate.ts — TEMPORAL CONFIRMATION FOR GESTURE CAPTURE.
 *
 * Platform-neutral, deterministic, clock-injected: every decision is a pure
 * function of (previous state, nowMs, this frame's evidence). No timers, no
 * Date.now(), no async — so the whole behaviour is unit-testable frame by
 * frame on a fake clock.
 *
 * THE RULE THIS FILE ENFORCES
 *
 *     DETECTED ONCE  ≠  CAPTURE NOW.
 *
 * A single open-palm frame is an opinion. Capture requires a *presentation*:
 * the same open palm, from the same place, for long enough that no plausible
 * accident explains it. Concretely, all of these must hold together:
 *
 *   · HOLD      — open-palm evidence for `confirmHoldMs` of wall time AND
 *                 `minConfirmFrames` accepted frames (time alone can be
 *                 satisfied by two frames 1.2 s apart; frames alone can be
 *                 satisfied by a fast camera in 200 ms — both are required);
 *   · STILLNESS — the palm centroid must not travel faster than
 *                 `maxDriftPerSecond` palm-widths per second. A hand that is
 *                 being waved, or an arm swinging past the lens, fails here
 *                 even if every finger happens to look straight;
 *   · CONTINUITY— evidence may drop out for at most `missToleranceMs` (one or
 *                 two dropped detections at 15 fps). A longer gap is a new
 *                 gesture, and the hold restarts from zero;
 *   · RELEASE   — after a confirmation the gate refuses to confirm again
 *                 until it has seen `releaseMs` of continuous NON-open-palm.
 *                 Holding the palm up after the shutter cannot produce a
 *                 second, third and fourth photograph.
 *
 * When anything is uncertain the gate stays unconfirmed. A missed gesture
 * costs the user one repeat; a false one costs a wrong photograph.
 */
import type { OpenPalmEvidence } from "./openPalmClassifier";

/**
 * Conceptual states. Naming is internal; the behaviour is the contract.
 *
 *   idle              nothing that looks like an open palm
 *   candidate         an open-palm frame exists but the hold has barely begun
 *   confirming        the hold is accumulating and visibly progressing
 *   confirmed         the exact frame the capture command is issued (one frame)
 *   cooldown          a capture was just commanded; nothing can re-trigger
 *   awaiting-release  cooldown is over, but the palm must go away first
 */
export type OpenPalmPhase =
  | "idle"
  | "candidate"
  | "confirming"
  | "confirmed"
  | "cooldown"
  | "awaiting-release";

export const OPEN_PALM_GATE_TIMING = {
  /** Wall-clock hold required before a palm becomes a capture command. */
  confirmHoldMs: 1_200,
  /** Accepted open-palm frames required in that window (≈15 fps → 0.8 s). */
  minConfirmFrames: 12,
  /** Frames below this threshold are "candidate", not yet "confirming". */
  candidateProgress: 0.15,
  /** Dropped-detection grace before the hold is considered broken. */
  missToleranceMs: 220,
  /** No gesture may be confirmed for this long after a confirmation. */
  cooldownMs: 2_500,
  /** Continuous absence of an open palm required to re-arm after cooldown. */
  releaseMs: 600,
  /** Palm-widths per second of centroid travel tolerated while holding. */
  maxDriftPerSecond: 1.4,
} as const;

export type OpenPalmGateTiming = typeof OPEN_PALM_GATE_TIMING;

export interface OpenPalmGateInput {
  readonly nowMs: number;
  /**
   * This frame's evidence, or null when the gesture pipeline produced nothing
   * for this frame (no hand, hand detector unavailable, gesture capture off).
   */
  readonly evidence: OpenPalmEvidence | null;
}

export interface OpenPalmGateSnapshot {
  readonly phase: OpenPalmPhase;
  /** 0..1 toward confirmation — drives the shutter ring, nothing else. */
  readonly progress: number;
  /**
   * TRUE ON EXACTLY ONE FRAME: the frame on which the gesture became a
   * capture command. Never true twice for one presentation.
   */
  readonly confirmed: boolean;
  /** True while the user must drop the palm before another capture. */
  readonly awaitingRelease: boolean;
  /** Why the gate is not progressing; "none" while it is. */
  readonly reason: GateReason;
}

export type GateReason =
  | "none"
  | "no-open-palm"
  | "hand-moving"
  | "cooling-down"
  | "awaiting-release";

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

export class OpenPalmGate {
  private readonly timing: OpenPalmGateTiming;

  private holdStartedAt: number | null = null;
  private acceptedFrames = 0;
  private lastAcceptedAt: number | null = null;
  private lastCentroidX = 0;
  private lastCentroidY = 0;
  private lastScale = 0;
  private cooldownUntil = Number.NEGATIVE_INFINITY;
  private releaseRequired = false;
  private absentSince: number | null = null;
  private phase: OpenPalmPhase = "idle";

  constructor(timing: Partial<OpenPalmGateTiming> = {}) {
    this.timing = { ...OPEN_PALM_GATE_TIMING, ...timing };
  }

  get currentPhase(): OpenPalmPhase {
    return this.phase;
  }

  update(input: OpenPalmGateInput): OpenPalmGateSnapshot {
    const { nowMs } = input;
    const evidence = input.evidence;
    const open = evidence !== null && evidence.isOpenPalm;

    /* ── release tracking runs FIRST and always: the only way out of the
          post-capture lock is a genuine, continuous absence of the palm. ── */
    if (open) {
      this.absentSince = null;
    } else if (this.absentSince === null) {
      this.absentSince = nowMs;
    }

    if (this.releaseRequired) {
      const coolingDown = nowMs < this.cooldownUntil;
      const releasedFor =
        this.absentSince === null ? 0 : nowMs - this.absentSince;
      if (!coolingDown && releasedFor >= this.timing.releaseMs) {
        this.releaseRequired = false;
      } else {
        this.resetHold();
        this.phase = coolingDown ? "cooldown" : "awaiting-release";
        return {
          phase: this.phase,
          progress: 0,
          confirmed: false,
          awaitingRelease: true,
          reason: coolingDown ? "cooling-down" : "awaiting-release",
        };
      }
    }

    if (!open || evidence === null) {
      /* CONTINUITY: a short detection gap must not throw away a hold the user
         is genuinely maintaining — 15 fps drops frames. A longer gap is not
         the same gesture any more. */
      const lastAcceptedAt = this.lastAcceptedAt;
      if (
        this.holdStartedAt !== null &&
        lastAcceptedAt !== null &&
        nowMs - lastAcceptedAt <= this.timing.missToleranceMs
      ) {
        const progress = this.progressAt(nowMs);
        this.phase = progress >= this.timing.candidateProgress ? "confirming" : "candidate";
        return {
          phase: this.phase,
          progress,
          confirmed: false,
          awaitingRelease: false,
          reason: "none",
        };
      }
      this.resetHold();
      this.phase = "idle";
      return {
        phase: "idle",
        progress: 0,
        confirmed: false,
        awaitingRelease: false,
        reason: "no-open-palm",
      };
    }

    /* ── STILLNESS: deliberate presentation, not a hand sweeping past. ──── */
    if (this.holdStartedAt !== null && this.lastAcceptedAt !== null) {
      const elapsed = Math.max(1, nowMs - this.lastAcceptedAt);
      const yardstick = Math.max(evidence.scale, this.lastScale, 1e-6);
      const travel =
        Math.hypot(
          evidence.centroidX - this.lastCentroidX,
          evidence.centroidY - this.lastCentroidY,
        ) / yardstick;
      const driftPerSecond = (travel * 1_000) / elapsed;
      if (driftPerSecond > this.timing.maxDriftPerSecond) {
        this.resetHold();
        this.rememberFrame(nowMs, evidence);
        this.holdStartedAt = nowMs;
        this.acceptedFrames = 1;
        this.phase = "candidate";
        return {
          phase: "candidate",
          progress: 0,
          confirmed: false,
          awaitingRelease: false,
          reason: "hand-moving",
        };
      }
    }

    if (this.holdStartedAt === null) this.holdStartedAt = nowMs;
    this.acceptedFrames += 1;
    this.rememberFrame(nowMs, evidence);

    const progress = this.progressAt(nowMs);
    if (progress >= 1) {
      /* THE ONE FRAME. Everything is torn down immediately so the very next
         frame — with the palm still up — sees a cooldown, not a new hold. */
      this.resetHold();
      this.releaseRequired = true;
      this.absentSince = null;
      this.cooldownUntil = nowMs + this.timing.cooldownMs;
      this.phase = "confirmed";
      return {
        phase: "confirmed",
        progress: 1,
        confirmed: true,
        awaitingRelease: true,
        reason: "none",
      };
    }

    this.phase =
      progress >= this.timing.candidateProgress ? "confirming" : "candidate";
    return {
      phase: this.phase,
      progress,
      confirmed: false,
      awaitingRelease: false,
      reason: "none",
    };
  }

  /**
   * Called by the capture flow when a gesture-triggered capture is actually
   * committed. The gate already locked itself on the confirming frame; this
   * extends the lock to cover the countdown + shutter + save, so a palm still
   * visible when the camera returns cannot immediately re-trigger.
   */
  notifyCaptureCommitted(nowMs: number): void {
    this.resetHold();
    this.releaseRequired = true;
    this.absentSince = null;
    this.cooldownUntil = Math.max(this.cooldownUntil, nowMs + this.timing.cooldownMs);
    this.phase = "cooldown";
  }

  /** Full re-arm; used when the camera session ends or the screen unmounts. */
  reset(): void {
    this.resetHold();
    this.cooldownUntil = Number.NEGATIVE_INFINITY;
    this.releaseRequired = false;
    this.absentSince = null;
    this.phase = "idle";
  }

  private progressAt(nowMs: number): number {
    if (this.holdStartedAt === null) return 0;
    const byTime = (nowMs - this.holdStartedAt) / this.timing.confirmHoldMs;
    const byFrames = this.acceptedFrames / this.timing.minConfirmFrames;
    return clamp01(Math.min(byTime, byFrames));
  }

  private rememberFrame(nowMs: number, evidence: OpenPalmEvidence): void {
    this.lastAcceptedAt = nowMs;
    this.lastCentroidX = evidence.centroidX;
    this.lastCentroidY = evidence.centroidY;
    this.lastScale = evidence.scale;
  }

  private resetHold(): void {
    this.holdStartedAt = null;
    this.acceptedFrames = 0;
    this.lastAcceptedAt = null;
  }
}
