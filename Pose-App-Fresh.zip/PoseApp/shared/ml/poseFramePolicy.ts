/**
 * A1 — poseFramePolicy: the bounded scheduling / staleness policy for the
 * live pose pipeline. Platform-neutral, zero RN/DOM, deterministic.
 *
 * WHY THIS EXISTS. The camera delivers frames far faster than pose inference
 * completes (30 fps delivery vs ~10–25 fps inference). The old loop had an
 * implicit, accidental policy (self-throttled by takePictureAsync latency,
 * and a full JPEG still per attempt). The native pipeline must have an
 * EXPLICIT one, with these guarantees — all provable in unit tests:
 *
 *   1. NO UNBOUNDED QUEUE, ever. The heavy work (native inference) runs
 *      synchronously on the frame thread, so by construction nothing piles
 *      up there. On the JS side, results arrive via runOnJS; the scheduler
 *      admits at most ONE in-flight consumption and drops newer arrivals
 *      while it is busy (INTENTIONAL drop — latest-wins, never queue).
 *   2. LATEST FRAME WINS. When busy, a newer native result replaces the
 *      pending one instead of queueing behind it — guidance always reflects
 *      the freshest usable evidence, never a backlog.
 *   3. STALE RESULTS ARE DISCARDED. A result whose frame is older than
 *      POSE_RESULT_MAX_STALENESS_MS on arrival is dropped before it can
 *      influence match %, coaching state or speech (no 700 ms-old guidance).
 *   4. SINGLE-FLIGHT CLEANUP. consume() is terminated by done() exactly
 *      once; after pause()/resume() transitions or camera facing switches
 *      (epoch bump), in-flight arrivals from the OLD session are rejected,
 *      so no landmark from the rear camera can be judged against the front
 *      camera's mirrored coordinates (and vice versa).
 *   5. TEARDOWN IS TOTAL. stop() rejects everything from then on.
 *
 * The class is a pure decision machine: IO (creating worklets, calling the
 * engine, updating React state) stays in mobile/src/core/ml/poseFrameRuntime.
 */

/**
 * Effective pose-processing budget: at most one accepted result per 66 ms —
 * the SAME 15 fps ML budget Unit 16 specified (UI stays 60 fps). Native
 * inference may also be slower; that is fine, this is a cap, not a target.
 */
export const POSE_RESULT_MIN_INTERVAL_MS = 66;

/**
 * A native result older than this when it REACHES JS is discarded. Chosen
 * deliberately tighter than typical inference+camera latency on mid-range
 * devices (≈80–200 ms) and far below any user-perceivable guidance beat
 * (~1 s): 350 ms. Anything older is no longer a picture of the user's pose.
 */
export const POSE_RESULT_MAX_STALENESS_MS = 350;

/** Runtime metrics — the instrumentation A1 asks for (§23 of the task). */
export interface PoseFrameMetrics {
  /** Native results handed to the scheduler. */
  readonly resultsReceived: number;
  /** Results accepted and sent to consumption. */
  readonly resultsAccepted: number;
  /** Dropped because the consumer was busy and this one was already replaced
   *  by an even newer pending result (latest-wins policy). */
  readonly droppedBusy: number;
  /** Dropped because the frame was older than the staleness bound on arrival. */
  readonly droppedStale: number;
  /** Dropped because the epoch changed (pause / facing switch / stop). */
  readonly droppedEpoch: number;
  /** Dropped because the scheduler was not running at all. */
  readonly droppedStopped: number;
}

export type PoseFrameDropReason = 'busy' | 'stale' | 'epoch' | 'stopped';

export interface PoseFrameAdmission {
  readonly admitted: boolean;
  readonly dropReason: PoseFrameDropReason | null;
}

export class PoseFrameScheduler {
  private running = false;
  private epoch = 0;
  private busy = false;
  private lastAcceptedAt = 0;
  private metrics: PoseFrameMetrics = {
    resultsReceived: 0,
    resultsAccepted: 0,
    droppedBusy: 0,
    droppedStale: 0,
    droppedEpoch: 0,
    droppedStopped: 0,
  };

  get currentEpoch(): number {
    return this.epoch;
  }

  get isRunning(): boolean {
    return this.running;
  }

  getMetrics(): PoseFrameMetrics {
    return { ...this.metrics };
  }

  /** Begin accepting results. Idempotent. */
  start(): void {
    this.running = true;
    this.busy = false;
  }

  /**
   * Reject all arrivals up to and including the current epoch (pause for
   * capture flow, camera facing switch). The scheduler KEEPS running; only
   * already-produced old-epoch evidence is invalidated. Returns the new epoch
   * the caller must stamp onto FUTURE native results.
   */
  invalidateEpoch(): number {
    this.epoch += 1;
    this.busy = false;
    return this.epoch;
  }

  /** Total teardown — subsequent arrivals are all rejected. Idempotent. */
  stop(): void {
    this.running = false;
    this.busy = false;
  }

  /**
   * Decide the fate of ONE native result. `frameTimestampMs` is the frame's
   * CAPTURE instant, already translated by the native detector into the
   * wall-clock (Date.now()) domain; `nowMs` is the result's arrival time in
   * that same domain, so the staleness bound below measures the frame's true
   * age (capture → JS arrival, inference included). Unit tests pass plain
   * integers in an arbitrary single domain.
   *
   * On admission the scheduler becomes BUSY until done() is called; while
   * busy, a NEWER result may replace the pending one (latest-wins) but only
   * the replaced-pending case counts as droppedBusy — an admitted-but-busy
   * newer result is itself dropped immediately (the consumer may only ever
   * process one at a time).
   *
   * IMPORTANT: admission is FIFO-strict by interval — accepted results are
   * spaced ≥ POSE_RESULT_MIN_INTERVAL_MS regardless of arrival rate.
   */
  admit(frameTimestampMs: number, arrivalMs: number, epoch: number): PoseFrameAdmission {
    if (!this.running) {
      this.metrics = { ...this.metrics, resultsReceived: this.metrics.resultsReceived + 1, droppedStopped: this.metrics.droppedStopped + 1 };
      return { admitted: false, dropReason: 'stopped' };
    }
    if (epoch !== this.epoch) {
      this.metrics = { ...this.metrics, resultsReceived: this.metrics.resultsReceived + 1, droppedEpoch: this.metrics.droppedEpoch + 1 };
      return { admitted: false, dropReason: 'epoch' };
    }
    this.metrics = { ...this.metrics, resultsReceived: this.metrics.resultsReceived + 1 };
    if (arrivalMs - frameTimestampMs > POSE_RESULT_MAX_STALENESS_MS) {
      this.metrics = { ...this.metrics, droppedStale: this.metrics.droppedStale + 1 };
      return { admitted: false, dropReason: 'stale' };
    }
    if (this.busy) {
      /* One in-flight slot, nothing else: while the consumer is busy every
         arrival is dropped immediately, and the FIRST arrival after done()
         is therefore always the freshest the native side has produced —
         latest-frame-wins without a single queued frame. */
      this.metrics = { ...this.metrics, droppedBusy: this.metrics.droppedBusy + 1 };
      return { admitted: false, dropReason: 'busy' };
    }
    if (this.lastAcceptedAt !== 0 && arrivalMs - this.lastAcceptedAt < POSE_RESULT_MIN_INTERVAL_MS) {
      /* Budget throttle: same 66 ms rule Unit 16 applied to detection. */
      this.metrics = { ...this.metrics, droppedBusy: this.metrics.droppedBusy + 1 };
      return { admitted: false, dropReason: 'busy' };
    }
    this.busy = true;
    this.lastAcceptedAt = arrivalMs;
    this.metrics = { ...this.metrics, resultsAccepted: this.metrics.resultsAccepted + 1 };
    return { admitted: true, dropReason: null };
  }

  /**
   * Terminate the single in-flight slot. MUST be called exactly once per
   * admitted result (the runtime uses try/finally). Calling without an
   * admitted result is a no-op (idempotent under async-race teardown).
   */
  done(): void {
    this.busy = false;
  }
}
