/**
 * A1 — poseFrameTransform: the DETERMINISTIC coordinate-transform layer
 * between the native pose plugin (Google ML Kit, via the local
 * vision-camera-mlkit-pose Nitro plugin) and the existing PoseLandmark
 * contract (shared/ml/poseLandmarks.ts, Unit 16).
 *
 * Platform-neutral, zero RN/DOM — the SAME math runs inside the native app's
 * JS runtime, in unit tests, and anywhere else. Camera-engine types never
 * cross this line: the input is a plain data structure, so the pose-analysis
 * engine cannot tell whether landmarks came from VisionCamera, test fixtures,
 * or a future camera engine (rule: detector output is ADAPTED, not leaked).
 *
 * Contract of the native plugin (vision-camera-mlkit-pose):
 *   · landmarks arrive in UPRIGHT image space (ML Kit already applied the
 *     frame's rotation, because we hand it frame.orientation as the input
 *     rotation), in PIXELS, x right / y down;
 *   · width/height are the UPRIGHT frame dimensions (native swaps them for
 *     90°/270° so JS never has to guess);
 *   · z is ML Kit's depth (same semantics as MediaPipe: negative = closer),
 *     passed through unscaled, exactly like the old adapter;
 *   · in-frame likelihood (0..1) maps 1:1 to PoseLandmark.visibility — the
 *     semantic Unit 16 already assigned (confidence the landmark is present
 *     AND correctly located);
 *   · mirrored is the FRAME flag: true when the preview is mirrored but the
 *     pixel buffer is not (typical selfie case).
 *
 * LEFT/RIGHT SEMANTICS (hard requirement): ML Kit labels joints relative to
 * the PERSON (their anatomical left wrist is leftWrist on either camera), so
 * mirroring only moves COORDINATES, never JOINT IDENTITY. The adapter therefore
 * flips x AFTER normalizing (so overlay coordinates agree with the mirrored
 * preview the user is looking at) and NEVER renames joints. Verified by
 * tests/camera/poseFrameTransform.test.ts ("user raises left hand" cases).
 */

import { POSE_LANDMARK_COUNT, type PoseLandmark } from './poseLandmarks';

/** Native frame orientation relative to the desired target orientation. */
export type NativeFrameOrientation = 'up' | 'right' | 'down' | 'left';

/** One raw landmark as emitted by the native plugin (upright image space). */
export interface NativePosePoint {
  /** Upright image-space x in pixels (may exceed bounds on edge devices). */
  readonly x: number;
  /** Upright image-space y in pixels. */
  readonly y: number;
  /** Depth relative to hip origin (negative = closer to camera). */
  readonly z: number;
  /** ML Kit in-frame likelihood 0..1 → PoseLandmark.visibility. */
  readonly visibility: number;
}

/** What the native plugin returns for ONE processed frame. */
export interface NativePoseFrame {
  /** UPRIGHT frame width in pixels (pre-swapped by native on 90/270). */
  readonly width: number;
  /** UPRIGHT frame height in pixels (pre-swapped by native on 90/270). */
  readonly height: number;
  /**
   * The frame's CAPTURE instant in wall-clock ms (Date.now() domain) — the
   * native side translates the buffer's own presentation timestamp before
   * inference, so the scheduler's staleness bound measures real frame age
   * (capture → JS arrival), never inference completion time.
   */
  readonly timestampMs: number;
  readonly orientation: NativeFrameOrientation;
  /** True when the preview is mirrored but the buffer is not (selfie). */
  readonly mirrored: boolean;
  /** Empty array (= no person) or EXACTLY 33 points. */
  readonly landmarks: readonly NativePosePoint[];
  /**
   * Native-side inference duration in ms, when the plugin reports it. Purely
   * observational (runtime metrics) — never used by logic, so omitting it is
   * legal and carries NO semantic difference.
   */
  readonly inferenceMs?: number;
}

/** Degrees ML Kit needs for a given native orientation (metadata, not math). */
export function nativeOrientationDegrees(orientation: NativeFrameOrientation): 0 | 90 | 180 | 270 {
  switch (orientation) {
    case 'up':
      return 0;
    case 'right':
      return 90;
    case 'down':
      return 180;
    case 'left':
      return 270;
  }
}

/**
 * True when the upright "view" of this frame is taller than wide. With the
 * native side pre-swapping dims this is descriptive only, but it is the
 * single place where the frame/dimension sanity policy lives for tests.
 */
export function isPortraitFrame(frame: Pick<NativePoseFrame, 'width' | 'height'>): boolean {
  return frame.height >= frame.width;
}

function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}

function clampVisibility(value: number): number {
  if (!Number.isFinite(value)) return 0;
  if (value < 0) return 0;
  if (value > 1) return 1;
  return value;
}

/**
 * Map ONE native point to the PoseLandmark contract.
 *
 * Order of operations is PART OF THE CONTRACT:
 *   1. normalize by upright dims (x/w, y/h),
 *   2. mirror x → 1−x when `mirrored` (overlay must match the preview),
 *   3. clamp to 0..1 (edge landmarks can sit a few px outside the buffer),
 *   4. pass z through unchanged (hip-relative, used by the match math),
 *   5. clamp likelihood into 0..1 → visibility.
 */
export function transformNativePoint(
  point: NativePosePoint,
  width: number,
  height: number,
  mirrored: boolean,
): PoseLandmark {
  const nx = width > 0 ? point.x / width : 0;
  const ny = height > 0 ? point.y / height : 0;
  return {
    x: clamp01(mirrored ? 1 - nx : nx),
    y: clamp01(ny),
    z: Number.isFinite(point.z) ? point.z : 0,
    visibility: clampVisibility(point.visibility),
  };
}

/**
 * Adapt a whole native frame to the existing PoseLandmark[] contract.
 *
 * Returns:
 *   · `null`   — the frame itself is unusable (bad dims / garbage count): the
 *                caller treats this like the old "short landmark array" case
 *                and feeds NO body to the engine this frame;
 *   · `[]`     — frame valid, no person detected (body-lost frame — the
 *                engine MUST still see it, its temporal memory depends on it);
 *   · 33 points — one adapted pose.
 *
 * Joint order is preserved EXACTLY (index i in = index i out): joint identity
 * (BlazePose topology) is never remapped here or anywhere else.
 */
export function adaptNativePoseFrame(
  frame: NativePoseFrame,
): readonly PoseLandmark[] | null {
  if (frame.width <= 0 || frame.height <= 0) return null;
  if (frame.landmarks.length === 0) return [];
  if (frame.landmarks.length < POSE_LANDMARK_COUNT) return null;
  const out = new Array<PoseLandmark>(POSE_LANDMARK_COUNT);
  for (let i = 0; i < POSE_LANDMARK_COUNT; i += 1) {
    /* Length ≥ 33 was proven above, but a garbage payload could still carry
       holes (sparse array / undefined entries) — treat those as an unusable
       frame (null), exactly like the short-array case. */
    const point = frame.landmarks[i];
    if (point === undefined) return null;
    out[i] = transformNativePoint(point, frame.width, frame.height, frame.mirrored);
  }
  return out;
}
