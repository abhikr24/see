/**
 * shared/ml/poseLandmarks.ts — Unit 16 (platform-neutral, zero RN/DOM).
 *
 * The MediaPipe PoseLandmarker contract: 33 normalized landmarks per pose,
 * the 16 display bones drawn by the Skia/Canvas skeleton overlay, and the
 * 8 three-point joint angles compared for the live match % (spec §16.2).
 * The Expo app (mobile/) and the preview mirror (src/) both consume this —
 * one contract, no drift.
 */

export interface PoseLandmark {
  /** Horizontal position, normalized 0..1 across the frame. */
  readonly x: number;
  /** Vertical position, normalized 0..1 down the frame. */
  readonly y: number;
  /** Depth relative to hip origin (negative = closer to camera). */
  readonly z: number;
  /** Confidence 0..1 that the landmark is present AND correctly located. */
  readonly visibility?: number;
}

/** Canonical MediaPipe pose landmark indices (BlazePose 33). */
export const POSE_LANDMARKS = {
  nose: 0,
  leftEyeInner: 1,
  leftEye: 2,
  leftEyeOuter: 3,
  rightEyeInner: 4,
  rightEye: 5,
  rightEyeOuter: 6,
  leftEar: 7,
  rightEar: 8,
  mouthLeft: 9,
  mouthRight: 10,
  leftShoulder: 11,
  rightShoulder: 12,
  leftElbow: 13,
  rightElbow: 14,
  leftWrist: 15,
  rightWrist: 16,
  leftPinky: 17,
  rightPinky: 18,
  leftIndex: 19,
  rightIndex: 20,
  leftThumb: 21,
  rightThumb: 22,
  leftHip: 23,
  rightHip: 24,
  leftKnee: 25,
  rightKnee: 26,
  leftAnkle: 27,
  rightAnkle: 28,
  leftHeel: 29,
  rightHeel: 30,
  leftFootIndex: 31,
  rightFootIndex: 32,
} as const;

export type PoseLandmarkName = keyof typeof POSE_LANDMARKS;
export const POSE_LANDMARK_COUNT = 33;

/**
 * The 16 skeleton connections drawn by the overlay (spec §16.2, exact list —
 * order is stable so unit tests and both renderers agree on the bone set).
 */
export const POSE_BONE_CONNECTIONS: readonly (readonly [
  PoseLandmarkName,
  PoseLandmarkName,
])[] = [
  ["nose", "leftEye"],
  ["leftEye", "leftEar"],
  ["nose", "rightEye"],
  ["rightEye", "rightEar"],
  ["leftShoulder", "rightShoulder"],
  ["leftShoulder", "leftElbow"],
  ["leftElbow", "leftWrist"],
  ["rightShoulder", "rightElbow"],
  ["rightElbow", "rightWrist"],
  ["leftShoulder", "leftHip"],
  ["rightShoulder", "rightHip"],
  ["leftHip", "rightHip"],
  ["leftHip", "leftKnee"],
  ["leftKnee", "leftAnkle"],
  ["rightHip", "rightKnee"],
  ["rightKnee", "rightAnkle"],
];

/**
 * A match joint = the interior angle at `vertex` formed by segments
 * vertex→a and vertex→c, measured in degrees 0..180.
 */
export interface MatchJoint {
  /** Stable key — matches the keys stored in Pose.referenceAngles. */
  readonly key: string;
  readonly a: PoseLandmarkName;
  readonly vertex: PoseLandmarkName;
  readonly c: PoseLandmarkName;
  /** Short human label, used by the Unit 17 guidance copy. */
  readonly label: string;
}

/** The 8 joints compared for match % (spec §16.2, exact set). */
export const MATCH_JOINTS: readonly MatchJoint[] = [
  { key: "leftElbow", a: "leftShoulder", vertex: "leftElbow", c: "leftWrist", label: "left elbow" },
  { key: "rightElbow", a: "rightShoulder", vertex: "rightElbow", c: "rightWrist", label: "right elbow" },
  { key: "leftKnee", a: "leftHip", vertex: "leftKnee", c: "leftAnkle", label: "left knee" },
  { key: "rightKnee", a: "rightHip", vertex: "rightKnee", c: "rightAnkle", label: "right knee" },
  { key: "leftShoulder", a: "leftHip", vertex: "leftShoulder", c: "leftElbow", label: "left shoulder" },
  { key: "rightShoulder", a: "rightHip", vertex: "rightShoulder", c: "rightElbow", label: "right shoulder" },
  { key: "leftHip", a: "leftShoulder", vertex: "leftHip", c: "leftKnee", label: "left hip" },
  { key: "rightHip", a: "rightShoulder", vertex: "rightHip", c: "rightKnee", label: "right hip" },
];

/** Below this confidence a landmark is treated as noise, never drawn/compared. */
export const MIN_LANDMARK_VISIBILITY = 0.3;

/**
 * THE anatomical plausibility band for an interior joint angle, in degrees —
 * declared ONCE here, in the geometry vocabulary both domains already import.
 *
 * Three modules need this band and must never disagree about it:
 *   · shared/ml/poseMatch.ts            — rejects impossible LIVE angles
 *   · shared/ml/analysis/thresholds.ts  — the engine's measurement gate
 *   · shared/reference/measurements.ts  — rejects impossible REFERENCE data
 *
 * They all re-export/derive from this constant rather than restating 2/180,
 * so a future recalibration is a one-line change with no drift window.
 * Rationale (Unit 16 audit): relaxed stances reach ~4° at the shoulder, and
 * 180° is the anatomical ceiling by construction of the interior angle.
 */
export const PLAUSIBLE_JOINT_ANGLE_DEGREES = {
  min: 2,
  max: 180,
} as const;
