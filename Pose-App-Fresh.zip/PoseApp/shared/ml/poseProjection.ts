/**
 * shared/ml/poseProjection.ts — Unit 16 (platform-neutral, zero RN/DOM).
 *
 * Normalized landmark space (0..1 over the camera frame) → viewport pixels.
 * Handles the two realities every renderer must honor (spec §16.2):
 *   · the viewfinder preview is COVER-cropped (object-fit: cover on web,
 *     scale-to-fill on device), so a naive scale misplaces the skeleton;
 *   · the front camera preview is mirrored, so X flips.
 * Both the Skia overlay (mobile/) and the preview canvas (src/) project
 * through this one function, keeping body-alignment identical everywhere.
 */
import {
  MIN_LANDMARK_VISIBILITY,
  POSE_BONE_CONNECTIONS,
  POSE_LANDMARKS,
  type PoseLandmark,
} from "./poseLandmarks";

export interface ProjectedPoint {
  readonly x: number;
  readonly y: number;
  /** False when the raw landmark was below the visibility floor. */
  readonly reliable: boolean;
}

export interface ProjectedBone {
  readonly from: ProjectedPoint;
  readonly to: ProjectedPoint;
}

export interface PoseProjection {
  /** All 33 points, frame order. Unreliable ones keep coordinates but flag. */
  readonly points: readonly ProjectedPoint[];
  /** The 16 display bones with both endpoints resolved. */
  readonly bones: readonly ProjectedBone[];
}

function projectOne(
  landmark: PoseLandmark,
  frameWidth: number,
  frameHeight: number,
  viewportWidth: number,
  viewportHeight: number,
  mirror: boolean,
): ProjectedPoint {
  // Cover-fit: the frame is uniformly scaled until both axes fill the view,
  // then centered — identical math to object-fit:cover.
  const scale = Math.max(viewportWidth / frameWidth, viewportHeight / frameHeight);
  const drawnWidth = frameWidth * scale;
  const drawnHeight = frameHeight * scale;
  const offsetX = (viewportWidth - drawnWidth) / 2;
  const offsetY = (viewportHeight - drawnHeight) / 2;
  const normX = mirror ? 1 - landmark.x : landmark.x;
  return {
    x: offsetX + normX * drawnWidth,
    y: offsetY + landmark.y * drawnHeight,
    reliable: (landmark.visibility ?? 1) >= MIN_LANDMARK_VISIBILITY,
  };
}

/**
 * Projects a full detected pose into viewport pixels.
 * frameWidth/frameHeight = the analyzed camera frame; viewportWidth/Height =
 * the on-screen preview box; mirror = front camera.
 */
export function projectPose(
  landmarks: readonly PoseLandmark[],
  frameWidth: number,
  frameHeight: number,
  viewportWidth: number,
  viewportHeight: number,
  mirror: boolean,
): PoseProjection | null {
  if (
    landmarks.length === 0 ||
    frameWidth <= 0 ||
    frameHeight <= 0 ||
    viewportWidth <= 0 ||
    viewportHeight <= 0
  ) {
    return null;
  }
  const points = landmarks.map((landmark) =>
    projectOne(landmark, frameWidth, frameHeight, viewportWidth, viewportHeight, mirror),
  );
  const bones: ProjectedBone[] = [];
  for (const [fromName, toName] of POSE_BONE_CONNECTIONS) {
    const from = points[POSE_LANDMARKS[fromName]];
    const to = points[POSE_LANDMARKS[toName]];
    if (from === undefined || to === undefined) continue;
    bones.push({ from, to });
  }
  return { points, bones };
}
