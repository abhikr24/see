/**
 * shared/ml/poseSilhouette.ts — Unit 25 (platform-neutral, zero RN/DOM).
 *
 * The premium "ghost" guide that replaces the visible MediaPipe skeleton on
 * the camera viewfinder. The user no longer sees joints and bones painted on
 * top of their body; they see a soft, translucent SILHOUETTE of the target
 * pose to align into. Detection, angle maths and match-% scoring are NOT in
 * this file and do not change — this module only decides the GUIDE GEOMETRY.
 *
 * Geometry contract
 *   A silhouette is a list of capsule segments plus round-cap dots, authored
 *   in a unit box (0..1, y down, figure vertically centered). The capsules
 *   are the structural truth; renderers never see them directly:
 *     · Unit 25 — they were fused by two blurred stroke passes into a soft,
 *       translucent ghost painted over the feed (superseded).
 *     · Unit 26 — outlineSilhouette() now derives the EXACT outer boundary
 *       of the capsule union as closed vector rings, so renderers stroke a
 *       thin, hollow, luminous contour with a glow halo instead; the camera
 *       feed stays 100% visible through the body interior. The match-%
 *       contour ramp (shared/theme/colors.ts) colors stroke + halo.
 *   This module deliberately carries NO colors — the platform purity rules
 *   keep all literals in shared/theme/colors.ts and callers inject tokens.
 *
 * Two-tier data path (mirrors the demo/real backend switch):
 *   1. pose.referenceLandmarks present (Template Scanner / licensed photo)  →
 *      capsulesFromLandmarks() traces a fully custom outline from the real
 *      measured pose. Renderers need zero code changes when data lands.
 *   2. Absent — the whole bundled catalog today — resolvePoseSilhouette()
 *      falls back to the generic shape library below, selected per template
 *      from category + tags and varied deterministically by colorSeed so the
 *      catalog's boot-determinism invariant holds.
 */
import { POSE_LANDMARKS, type PoseLandmarkName } from "./poseLandmarks";
import type { Pose, PoseCategoryId } from "../types";

/** Structural landmark input — satisfied by both PoseLandmark (live
 *  detection) and the Pose.referenceLandmarks contract (Template Scanner). */
export interface SilhouetteLandmarkInput {
  readonly x: number;
  readonly y: number;
  readonly z?: number;
  readonly visibility?: number;
}

/* ── Geometry types ────────────────────────────────────────────────────── */

export interface SilhouetteVec {
  readonly x: number;
  readonly y: number;
}

export interface SilhouetteSegment {
  /** "capsule": round-capped stroke from `from` to `to`, `width` thick.
   *  "dot": filled circle centered on `from`, diameter `width`. */
  readonly kind: "capsule" | "dot";
  readonly from: SilhouetteVec;
  readonly to: SilhouetteVec;
  readonly width: number;
}

export type SilhouetteSource = "custom-landmarks" | "generic-library";

export interface PoseSilhouetteSpec {
  /** Stable id for logging/dev — e.g. "generic/standing-forward" or "custom". */
  readonly shapeId: string;
  readonly source: SilhouetteSource;
  /** Unit-box segments (0..1, y down). Fit to pixels with fitSilhouetteToViewport. */
  readonly segments: readonly SilhouetteSegment[];
  /** True when the guide is mirrored horizontally for this template variant. */
  readonly mirrored: boolean;
}

const dot = (x: number, y: number, width: number): SilhouetteSegment => ({
  kind: "dot",
  from: { x, y },
  to: { x, y },
  width,
});

const capsule = (
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  width: number,
): SilhouetteSegment => ({
  kind: "capsule",
  from: { x: x1, y: y1 },
  to: { x: x2, y: y2 },
  width,
});

/* ── Generic shape library (unit box, y down) ──────────────────────────── */

export type GenericSilhouetteId =
  | "standing-forward"
  | "standing-turned"
  | "sitting"
  | "lying"
  | "couple"
  | "group";

const STANDING_FORWARD: readonly SilhouetteSegment[] = [
  dot(0.5, 0.115, 0.115),
  capsule(0.5, 0.175, 0.5, 0.47, 0.155),
  capsule(0.418, 0.2, 0.392, 0.325, 0.052), // left upper arm
  capsule(0.392, 0.325, 0.402, 0.445, 0.043), // left forearm
  capsule(0.582, 0.2, 0.608, 0.325, 0.052), // right upper arm
  capsule(0.608, 0.325, 0.598, 0.445, 0.043), // right forearm
  capsule(0.463, 0.475, 0.448, 0.705, 0.074), // left thigh
  capsule(0.448, 0.705, 0.442, 0.93, 0.056), // left shin
  capsule(0.537, 0.475, 0.552, 0.705, 0.074), // right thigh
  capsule(0.552, 0.705, 0.558, 0.93, 0.056), // right shin
];

const STANDING_TURNED: readonly SilhouetteSegment[] = [
  dot(0.5, 0.115, 0.105),
  capsule(0.5, 0.17, 0.488, 0.468, 0.115),
  capsule(0.458, 0.192, 0.502, 0.305, 0.046), // near upper arm (bent in)
  capsule(0.502, 0.305, 0.542, 0.398, 0.039), // near forearm toward hip
  capsule(0.52, 0.195, 0.538, 0.335, 0.042), // far arm hanging
  capsule(0.476, 0.472, 0.466, 0.702, 0.064), // near thigh
  capsule(0.466, 0.702, 0.46, 0.928, 0.051), // near shin
  capsule(0.512, 0.472, 0.526, 0.702, 0.057), // far thigh
  capsule(0.526, 0.702, 0.532, 0.928, 0.046), // far shin
];

const SITTING: readonly SilhouetteSegment[] = [
  dot(0.42, 0.15, 0.11),
  capsule(0.42, 0.205, 0.43, 0.5, 0.15),
  capsule(0.362, 0.225, 0.352, 0.36, 0.05), // left upper arm
  capsule(0.352, 0.36, 0.4, 0.485, 0.041), // left forearm to knee
  capsule(0.478, 0.225, 0.478, 0.36, 0.05), // right upper arm
  capsule(0.478, 0.36, 0.52, 0.49, 0.041), // right forearm to knee
  capsule(0.395, 0.505, 0.585, 0.545, 0.078), // left thigh, horizontal
  capsule(0.585, 0.545, 0.585, 0.83, 0.057), // left shin down
  capsule(0.455, 0.515, 0.64, 0.565, 0.078), // right thigh, horizontal
  capsule(0.64, 0.565, 0.645, 0.835, 0.057), // right shin down
];

const LYING: readonly SilhouetteSegment[] = [
  dot(0.21, 0.32, 0.105),
  capsule(0.26, 0.365, 0.52, 0.43, 0.145),
  capsule(0.3, 0.4, 0.4, 0.5, 0.046), // near arm draped forward
  capsule(0.4, 0.5, 0.5, 0.492, 0.038), // near forearm resting
  capsule(0.52, 0.435, 0.735, 0.475, 0.072), // near thigh
  capsule(0.735, 0.475, 0.94, 0.468, 0.053), // near shin
  capsule(0.5, 0.412, 0.72, 0.43, 0.062), // far thigh
  capsule(0.72, 0.43, 0.925, 0.415, 0.046), // far shin
];

const COUPLE: readonly SilhouetteSegment[] = [
  // Left partner (slightly taller)
  dot(0.392, 0.105, 0.102),
  capsule(0.396, 0.16, 0.398, 0.462, 0.132),
  capsule(0.345, 0.205, 0.308, 0.34, 0.044), // outer arm
  capsule(0.308, 0.34, 0.314, 0.452, 0.037),
  capsule(0.447, 0.212, 0.512, 0.298, 0.041), // inner arm to partner
  capsule(0.512, 0.298, 0.552, 0.362, 0.034),
  capsule(0.372, 0.466, 0.362, 0.7, 0.062),
  capsule(0.362, 0.7, 0.356, 0.925, 0.05),
  capsule(0.424, 0.466, 0.434, 0.7, 0.062),
  capsule(0.434, 0.7, 0.44, 0.925, 0.05),
  // Right partner (slightly shorter, leaning in)
  dot(0.602, 0.128, 0.096),
  capsule(0.6, 0.185, 0.606, 0.48, 0.122),
  capsule(0.653, 0.228, 0.682, 0.362, 0.042), // outer arm
  capsule(0.682, 0.362, 0.688, 0.468, 0.035),
  capsule(0.554, 0.232, 0.502, 0.318, 0.039), // inner arm to partner
  capsule(0.502, 0.318, 0.464, 0.392, 0.033),
  capsule(0.582, 0.484, 0.572, 0.712, 0.057),
  capsule(0.572, 0.712, 0.566, 0.938, 0.046),
  capsule(0.63, 0.484, 0.642, 0.712, 0.057),
  capsule(0.642, 0.712, 0.648, 0.938, 0.046),
];

const GROUP: readonly SilhouetteSegment[] = [
  // Center figure
  dot(0.5, 0.125, 0.1),
  capsule(0.5, 0.18, 0.5, 0.468, 0.128),
  capsule(0.448, 0.215, 0.428, 0.35, 0.043),
  capsule(0.428, 0.35, 0.434, 0.46, 0.036),
  capsule(0.552, 0.215, 0.572, 0.35, 0.043),
  capsule(0.572, 0.35, 0.566, 0.46, 0.036),
  capsule(0.476, 0.472, 0.467, 0.7, 0.06),
  capsule(0.467, 0.7, 0.461, 0.925, 0.049),
  capsule(0.524, 0.472, 0.533, 0.7, 0.06),
  capsule(0.533, 0.7, 0.539, 0.925, 0.049),
  // Left figure (slightly shorter)
  dot(0.33, 0.178, 0.09),
  capsule(0.333, 0.228, 0.337, 0.495, 0.112),
  capsule(0.29, 0.262, 0.271, 0.39, 0.039),
  capsule(0.271, 0.39, 0.275, 0.5, 0.033),
  capsule(0.314, 0.5, 0.306, 0.72, 0.053),
  capsule(0.306, 0.72, 0.3, 0.938, 0.043),
  capsule(0.36, 0.5, 0.368, 0.72, 0.053),
  capsule(0.368, 0.72, 0.374, 0.938, 0.043),
  // Right figure (slightly shorter)
  dot(0.67, 0.178, 0.09),
  capsule(0.667, 0.228, 0.663, 0.495, 0.112),
  capsule(0.71, 0.262, 0.729, 0.39, 0.039),
  capsule(0.729, 0.39, 0.725, 0.5, 0.033),
  capsule(0.64, 0.5, 0.632, 0.72, 0.053),
  capsule(0.632, 0.72, 0.626, 0.938, 0.043),
  capsule(0.686, 0.5, 0.694, 0.72, 0.053),
  capsule(0.694, 0.72, 0.7, 0.938, 0.043),
];

export const GENERIC_SILHOUETTE_SHAPES: Readonly<
  Record<GenericSilhouetteId, readonly SilhouetteSegment[]>
> = {
  "standing-forward": STANDING_FORWARD,
  "standing-turned": STANDING_TURNED,
  sitting: SITTING,
  lying: LYING,
  couple: COUPLE,
  group: GROUP,
};

/* ── Generic selection (deterministic — no randomness, ever) ───────────── */

const SEATED_TAGS: ReadonlySet<string> = new Set([
  "seated",
  "sitting",
  "bench",
  "couch",
]);
const LYING_TAGS: ReadonlySet<string> = new Set([
  "lying",
  "recline",
  "reclined",
  "floor",
  "supine",
]);

/**
 * Per-category generic shapes, in preference order. Single-person categories
 * list two variants so colorSeed can alternate frontal / three-quarter per
 * template while every boot still resolves identically.
 */
const CATEGORY_SHAPES: Readonly<
  Record<PoseCategoryId, readonly GenericSilhouetteId[]>
> = {
  portraits: ["standing-forward", "standing-turned"],
  couples: ["couple"],
  family: ["group"],
  wedding: ["couple"],
  fashion: ["standing-turned", "standing-forward"],
  street: ["standing-forward", "standing-turned"],
  fitness: ["standing-forward"],
  dance: ["standing-turned"],
  travel: ["standing-forward", "standing-turned"],
  kids: ["standing-forward"],
  group: ["group"],
  creative: ["standing-turned", "standing-forward"],
};

function pickGenericShapeId(
  pose: Pick<Pose, "category" | "tags" | "colorSeed">,
): GenericSilhouetteId {
  const tags = pose.tags.map((t) => t.toLowerCase());
  if (tags.some((t) => SEATED_TAGS.has(t))) return "sitting";
  if (tags.some((t) => LYING_TAGS.has(t))) return "lying";
  const options = CATEGORY_SHAPES[pose.category] ?? ["standing-forward"];
  const index =
    options.length > 1
      ? Math.abs(pose.colorSeed) % options.length
      : 0;
  return options[index] ?? "standing-forward";
}

/* ── Custom trace from real reference landmarks ────────────────────────── */

function landmarkPoint(
  landmarks: readonly SilhouetteLandmarkInput[],
  name: PoseLandmarkName,
): SilhouetteVec | null {
  const index = POSE_LANDMARKS[name];
  const lm = landmarks[index];
  if (lm === undefined) return null;
  return { x: lm.x, y: lm.y };
}

const midpoint = (a: SilhouetteVec, b: SilhouetteVec): SilhouetteVec => ({
  x: (a.x + b.x) / 2,
  y: (a.y + b.y) / 2,
});

const distance = (a: SilhouetteVec, b: SilhouetteVec): number =>
  Math.hypot(a.x - b.x, a.y - b.y);

/**
 * Traces the 33 measured landmarks into 11 fused capsules:
 * head dot, torso, upper arm ×2, forearm ×2, thigh ×2, shin ×2.
 * All widths derive from the subject's own proportions (shoulder span /
 * trunk height), so side-profile scans degrade to a slim but correct figure
 * instead of a collapsed ribbon. Normalized into the unit box the generic
 * library also uses, so both sources fit the viewport the same way.
 */
export function capsulesFromLandmarks(
  landmarks: readonly SilhouetteLandmarkInput[],
): readonly SilhouetteSegment[] | null {
  if (landmarks.length < 33) return null;
  const names: PoseLandmarkName[] = [
    "nose", "leftEar", "rightEar",
    "leftShoulder", "rightShoulder", "leftElbow", "rightElbow",
    "leftWrist", "rightWrist", "leftHip", "rightHip",
    "leftKnee", "rightKnee", "leftAnkle", "rightAnkle",
  ];
  const pts = new Map<PoseLandmarkName, SilhouetteVec>();
  for (const name of names) {
    const point = landmarkPoint(landmarks, name);
    if (point === null) return null;
    pts.set(name, point);
  }
  const get = (name: PoseLandmarkName): SilhouetteVec =>
    pts.get(name) ?? { x: 0.5, y: 0.5 };

  const midShoulders = midpoint(get("leftShoulder"), get("rightShoulder"));
  const midHips = midpoint(get("leftHip"), get("rightHip"));
  const midAnkles = midpoint(get("leftAnkle"), get("rightAnkle"));
  const midEars = midpoint(get("leftEar"), get("rightEar"));

  const shoulderSpan = distance(get("leftShoulder"), get("rightShoulder"));
  const hipSpan = distance(get("leftHip"), get("rightHip"));
  const trunkHeight = Math.max(distance(midShoulders, midHips), 0.001);
  const bodyHeight = Math.max(distance(midShoulders, midAnkles), 0.001);

  const torsoWidth = Math.max(shoulderSpan, hipSpan) * 1.25 + trunkHeight * 0.22;
  const upperArmWidth = Math.max(shoulderSpan * 0.3, bodyHeight * 0.055);
  const forearmWidth = upperArmWidth * 0.8;
  const thighWidth = Math.max(hipSpan * 0.52, bodyHeight * 0.1);
  const shinWidth = thighWidth * 0.72;
  const headWidth = Math.max(
    distance(get("leftEar"), get("rightEar")) * 2.3,
    bodyHeight * 0.16,
  );
  // Head center sits slightly above the ears, biased toward the nose line.
  const headCenter = {
    x: (midEars.x + get("nose").x) / 2,
    y: (midEars.y + get("nose").y) / 2 - headWidth * 0.12,
  };

  const segments: SilhouetteSegment[] = [
    dot(headCenter.x, headCenter.y, headWidth),
    capsule(midShoulders.x, midShoulders.y, midHips.x, midHips.y, torsoWidth),
    capsule(get("leftShoulder").x, get("leftShoulder").y, get("leftElbow").x, get("leftElbow").y, upperArmWidth),
    capsule(get("leftElbow").x, get("leftElbow").y, get("leftWrist").x, get("leftWrist").y, forearmWidth),
    capsule(get("rightShoulder").x, get("rightShoulder").y, get("rightElbow").x, get("rightElbow").y, upperArmWidth),
    capsule(get("rightElbow").x, get("rightElbow").y, get("rightWrist").x, get("rightWrist").y, forearmWidth),
    capsule(get("leftHip").x, get("leftHip").y, get("leftKnee").x, get("leftKnee").y, thighWidth),
    capsule(get("leftKnee").x, get("leftKnee").y, get("leftAnkle").x, get("leftAnkle").y, shinWidth),
    capsule(get("rightHip").x, get("rightHip").y, get("rightKnee").x, get("rightKnee").y, thighWidth),
    capsule(get("rightKnee").x, get("rightKnee").y, get("rightAnkle").x, get("rightAnkle").y, shinWidth),
  ];

  // Normalize into the shared unit box (preserve aspect, pad 6%).
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const seg of segments) {
    const half = seg.width / 2;
    minX = Math.min(minX, seg.from.x - half, seg.to.x - half);
    maxX = Math.max(maxX, seg.from.x + half, seg.to.x + half);
    minY = Math.min(minY, seg.from.y - half, seg.to.y - half);
    maxY = Math.max(maxY, seg.from.y + half, seg.to.y + half);
  }
  const spanX = Math.max(maxX - minX, 0.0001);
  const spanY = Math.max(maxY - minY, 0.0001);
  const pad = 0.06;
  const scale = Math.min((1 - pad * 2) / spanX, (1 - pad * 2) / spanY);
  const offsetX = (1 - spanX * scale) / 2 - minX * scale;
  const offsetY = (1 - spanY * scale) / 2 - minY * scale;
  const mapVec = (v: SilhouetteVec): SilhouetteVec => ({
    x: v.x * scale + offsetX,
    y: v.y * scale + offsetY,
  });
  return segments.map((seg) => ({
    kind: seg.kind,
    from: mapVec(seg.from),
    to: mapVec(seg.to),
    width: seg.width * scale,
  }));
}

/* ── Resolver: custom when data exists, generic otherwise ──────────────── */

/**
 * The single decision point. Renderers never branch on data availability —
 * when a template gains real reference landmarks, the guide upgrades to a
 * custom-traced silhouette automatically (same pattern as the demo/real
 * backend switching used across this codebase).
 */
export function resolvePoseSilhouette(
  pose: Pick<Pose, "id" | "category" | "tags" | "colorSeed" | "referenceLandmarks">,
): PoseSilhouetteSpec {
  const mirrored = Math.abs(pose.colorSeed) % 3 === 0;
  const reference = pose.referenceLandmarks;
  if (reference !== null && reference !== undefined && reference.length >= 33) {
    const traced = capsulesFromLandmarks(reference);
    if (traced !== null) {
      const segments = mirrored ? mirrorSegments(traced) : traced;
      return {
        shapeId: `custom/${pose.id}`,
        source: "custom-landmarks",
        segments,
        mirrored,
      };
    }
  }
  const shapeId = pickGenericShapeId(pose);
  const library = GENERIC_SILHOUETTE_SHAPES[shapeId];
  const segments = mirrored ? mirrorSegments(library) : library;
  return {
    shapeId: `generic/${shapeId}`,
    source: "generic-library",
    segments,
    mirrored,
  };
}

function mirrorSegments(
  segments: readonly SilhouetteSegment[],
): readonly SilhouetteSegment[] {
  const flip = (v: SilhouetteVec): SilhouetteVec => ({ x: 1 - v.x, y: v.y });
  return segments.map((seg) => ({
    kind: seg.kind,
    from: flip(seg.from),
    to: flip(seg.to),
    width: seg.width,
  }));
}

/* ── Viewport fitting ──────────────────────────────────────────────────── */

export interface FittedSilhouetteSegment {
  readonly kind: "capsule" | "dot";
  readonly from: SilhouetteVec;
  readonly to: SilhouetteVec;
  /** Pixel width of the round-capped stroke / dot diameter. */
  readonly width: number;
}

/** Fraction of the viewport the ghost may occupy (longest axis). */
const SILHOUETTE_VIEWPORT_FILL = 0.74;
/** Vertical optical-center bias: slightly above true center reads balanced
 *  once the bottom control bar is accounted for. */
const SILHOUETTE_CENTER_Y = 0.47;

/**
 * Maps unit-box segments into viewport pixels. The ghost is a framing guide
 * anchored to the SCREEN (unlike the detected person's skeleton, which used
 * cover-fit frame projection): preserve aspect, occupy at most ~74% of the
 * smaller viewport axis, centered horizontally with the vertical optical
 * bias above. Renderers re-fit on layout — same lifecycle pattern as the
 * old overlay's onLayout projection.
 */
export function fitSilhouetteToViewport(
  spec: PoseSilhouetteSpec,
  viewportWidth: number,
  viewportHeight: number,
): readonly FittedSilhouetteSegment[] {
  if (
    spec.segments.length === 0 ||
    viewportWidth <= 0 ||
    viewportHeight <= 0
  ) {
    return [];
  }
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const seg of spec.segments) {
    const half = seg.width / 2;
    minX = Math.min(minX, seg.from.x - half, seg.to.x - half);
    maxX = Math.max(maxX, seg.from.x + half, seg.to.x + half);
    minY = Math.min(minY, seg.from.y - half, seg.to.y - half);
    maxY = Math.max(maxY, seg.from.y + half, seg.to.y + half);
  }
  const spanX = Math.max(maxX - minX, 0.0001);
  const spanY = Math.max(maxY - minY, 0.0001);
  const scale = Math.min(
    (viewportWidth * SILHOUETTE_VIEWPORT_FILL) / spanX,
    (viewportHeight * SILHOUETTE_VIEWPORT_FILL) / spanY,
  );
  const drawnWidth = spanX * scale;
  const drawnHeight = spanY * scale;
  const offsetX = (viewportWidth - drawnWidth) / 2 - minX * scale;
  const offsetY =
    viewportHeight * SILHOUETTE_CENTER_Y - (minY * scale + drawnHeight / 2);
  return spec.segments.map((seg) => ({
    kind: seg.kind,
    from: { x: seg.from.x * scale + offsetX, y: seg.from.y * scale + offsetY },
    to: { x: seg.to.x * scale + offsetX, y: seg.to.y * scale + offsetY },
    width: Math.max(seg.width * scale, 1),
  }));
}

/* ── Luminous vector contour (guides) ────────────────────────────────────
 * Render-geometry constants for the hollow contour presentation of the
 * silhouette. This module stays color-free (purity rule) — the match-%
 * palette for the stroke lives in shared/theme/colors.ts
 * (SILHOUETTE_CONTOUR_BANDS / silhouetteContourStyle).
 */

/** Crisp boundary stroke, spec band 2–3px. */
export const SILHOUETTE_CONTOUR_STROKE_PX = 2.5;
/** Wider carrier stroke underneath the crisp line; its blur is the halo. */
export const SILHOUETTE_CONTOUR_GLOW_STROKE_PX = 6;
/** Gaussian sigma of the halo blur, spec band 4–6px. */
export const SILHOUETTE_CONTOUR_GLOW_SIGMA = 5;
/** Subtle framing-guide dash texture on the crisp stroke. */
export const SILHOUETTE_CONTOUR_DASH_PX: readonly [number, number] = [8, 4];
/** Locked-band pulse: opacity breathes down to the floor and back per cycle. */
export const SILHOUETTE_CONTOUR_PULSE_PERIOD_MS = 1600;
export const SILHOUETTE_CONTOUR_PULSE_RATIO = 0.72;

/** One closed boundary ring of the silhouette outline. */
export type SilhouetteContourLoop = readonly SilhouetteVec[];

/** Marching-squares sampling density (cells across the longest bbox axis). */
const CONTOUR_GRID_CELLS = 160;
/** Extra rows/columns of margin so loops always close inside the field. */
const CONTOUR_GRID_MARGIN_CELLS = 4;
/** Chaikin corner-cutting passes over each extracted ring. */
const CONTOUR_SMOOTH_PASSES = 2;
/** Rings with fewer points than this are sampling debris, not anatomy. */
const CONTOUR_MIN_LOOP_POINTS = 6;

const distToSegmentSq = (
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number,
): number => {
  const dx = bx - ax;
  const dy = by - ay;
  const lengthSq = dx * dx + dy * dy;
  let t = lengthSq === 0 ? 0 : ((px - ax) * dx + (py - ay) * dy) / lengthSq;
  t = Math.min(1, Math.max(0, t));
  const cx = ax + t * dx;
  const cy = ay + t * dy;
  const ex = px - cx;
  const ey = py - cy;
  return ex * ex + ey * ey;
};

/**
 * Extracts the EXACT outer boundary of the fused capsule silhouette as closed
 * vector loops, so renderers can stroke a thin glowing transparent-body
 * contour instead of painting the blob. Identical input for custom-traced
 * (referenceLandmarks) and generic-library segments — the zero-branch
 * guarantee of resolvePoseSilhouette() carries through.
 *
 * Method: marching squares over the union field f(p) = min_i(dist(p, seg_i)
 * − r_i); the zero crossings chain into boundary rings, which two Chaikin
 * passes then relax into the premium continuous curve. Deterministic
 * traversal order, one allocation-heavy call per pose+layout — callers
 * memoize/cache and must never put this on the per-frame path.
 *
 * Multi-figure shapes (group) legitimately resolve to several disjoint
 * loops; each is returned separately in stable largest-first order.
 */
export function outlineSilhouette(
  segments: readonly SilhouetteSegment[],
  gridCells: number = CONTOUR_GRID_CELLS,
): readonly SilhouetteContourLoop[] {
  if (segments.length === 0 || gridCells < 16) return [];

  // Field bounds: segment bbox expanded by the thickest radius plus margin.
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxRadius = 0;
  for (const seg of segments) {
    const half = seg.width / 2;
    maxRadius = Math.max(maxRadius, half);
    minX = Math.min(minX, seg.from.x - half, seg.to.x - half);
    maxX = Math.max(maxX, seg.from.x + half, seg.to.x + half);
    minY = Math.min(minY, seg.from.y - half, seg.to.y - half);
    maxY = Math.max(maxY, seg.from.y + half, seg.to.y + half);
  }
  const spanX = Math.max(maxX - minX, 1e-6);
  const spanY = Math.max(maxY - minY, 1e-6);
  const cell = Math.max(spanX, spanY) / gridCells;
  const margin = maxRadius + CONTOUR_GRID_MARGIN_CELLS * cell;
  const originX = minX - margin;
  const originY = minY - margin;
  const cols = Math.max(2, Math.ceil((spanX + margin * 2) / cell));
  const rows = Math.max(2, Math.ceil((spanY + margin * 2) / cell));

  // Sample the union field once (signed: negative = inside the silhouette).
  const field = new Float32Array((cols + 1) * (rows + 1));
  for (let j = 0; j <= rows; j++) {
    const py = originY + j * cell;
    for (let i = 0; i <= cols; i++) {
      const px = originX + i * cell;
      let best = Infinity;
      for (const seg of segments) {
        const radiusSq = (seg.width / 2) * (seg.width / 2);
        const dSq =
          seg.kind === "dot"
            ? (px - seg.from.x) * (px - seg.from.x) +
              (py - seg.from.y) * (py - seg.from.y)
            : distToSegmentSq(px, py, seg.from.x, seg.from.y, seg.to.x, seg.to.y);
        best = Math.min(best, Math.sqrt(dSq) - Math.sqrt(radiusSq));
      }
      // Exact-zero samples sit precisely on the boundary and create degree-4
      // chaining degeneracies; absorb them into "inside" deterministically.
      field[j * (cols + 1) + i] = best === 0 ? -1e-9 : best;
    }
  }

  const at = (i: number, j: number): number => field[j * (cols + 1) + i] ?? 1;

  // Crossing point on a sample edge, linearly interpolated to the iso value.
  // Keys are canonical per sample edge so adjacent cells emit identical ids.
  const pointCache = new Map<string, SilhouetteVec>();
  const hKey = (i: number, j: number): string => `H${i}:${j}`;
  const vKey = (i: number, j: number): string => `V${i}:${j}`;
  const crossing = (
    key: string,
    x1: number,
    y1: number,
    v1: number,
    x2: number,
    y2: number,
    v2: number,
  ): SilhouetteVec => {
    const hit = pointCache.get(key);
    if (hit !== undefined) return hit;
    const t = v1 / (v1 - v2);
    const point = { x: x1 + (x2 - x1) * t, y: y1 + (y2 - y1) * t };
    pointCache.set(key, point);
    return point;
  };

  // March every cell, emitting boundary segments between canonical edges.
  // edge ids: 0 top (H i,j) · 1 right (V i+1,j) · 2 bottom (H i,j+1) · 3 left (V i,j)
  const chain: Array<readonly [string, string]> = [];
  for (let j = 0; j < rows; j++) {
    for (let i = 0; i < cols; i++) {
      const a = at(i, j); // top-left
      const b = at(i + 1, j); // top-right
      const c = at(i + 1, j + 1); // bottom-right
      const d = at(i, j + 1); // bottom-left
      let cellCase = 0;
      if (a < 0) cellCase |= 8;
      if (b < 0) cellCase |= 4;
      if (c < 0) cellCase |= 2;
      if (d < 0) cellCase |= 1;
      if (cellCase === 0 || cellCase === 15) continue;

      const x0 = originX + i * cell;
      const y0 = originY + j * cell;
      const x1 = x0 + cell;
      const y1 = y0 + cell;
      const edgeKey = (e: number): string =>
        e === 0 ? hKey(i, j) : e === 1 ? vKey(i + 1, j) : e === 2 ? hKey(i, j + 1) : vKey(i, j);
      const edgePoint = (e: number): SilhouetteVec =>
        e === 0
          ? crossing(hKey(i, j), x0, y0, a, x1, y0, b)
          : e === 1
            ? crossing(vKey(i + 1, j), x1, y0, b, x1, y1, c)
            : e === 2
              ? crossing(hKey(i, j + 1), x0, y1, d, x1, y1, c)
              : crossing(vKey(i, j), x0, y0, a, x0, y1, d);

      // Segment pairing per case (corner bits: a=8 TL, b=4 TR, c=2 BR, d=1
      // BL; complement cases k and 15−k always pair identically). Saddles
      // (5/10) resolve via the summed corner field as the center proxy
      // (asymptotic decider): a negative sum joins the inside lobes through
      // the middle, pinching off the two outside corners.
      const centerInside = a + b + c + d < 0;
      let pairs: ReadonlyArray<readonly [number, number]>;
      switch (cellCase) {
        case 1: pairs = [[3, 2]]; break;   // complement of 14
        case 2: pairs = [[2, 1]]; break;   // complement of 13
        case 3: pairs = [[3, 1]]; break;   // complement of 12
        case 4: pairs = [[1, 0]]; break;   // complement of 11
        case 5: pairs = centerInside ? [[0, 3], [1, 2]] : [[0, 1], [3, 2]]; break;
        case 6: pairs = [[2, 0]]; break;   // complement of 9
        case 7: pairs = [[3, 0]]; break;   // complement of 8
        case 8: pairs = [[0, 3]]; break;
        case 9: pairs = [[0, 2]]; break;
        case 10: pairs = centerInside ? [[0, 1], [3, 2]] : [[0, 3], [1, 2]]; break;
        case 11: pairs = [[0, 1]]; break;
        case 12: pairs = [[1, 3]]; break;
        case 13: pairs = [[1, 2]]; break;
        case 14: pairs = [[2, 3]]; break;
        default: pairs = [];
      }
      for (const [e1, e2] of pairs) {
        // Touch the points so both crossings are sampled into the cache.
        edgePoint(e1);
        edgePoint(e2);
        chain.push([edgeKey(e1), edgeKey(e2)]);
      }
    }
  }
  if (chain.length === 0) return [];

  // Chain the segments into closed rings. Each edge id has degree 2 (two
  // boundary segments meet at every crossing), so a walk always terminates
  // exactly where it started.
  const adjacency = new Map<string, number[]>();
  chain.forEach(([k1, k2], index) => {
    const l1 = adjacency.get(k1);
    if (l1 !== undefined) l1.push(index);
    else adjacency.set(k1, [index]);
    const l2 = adjacency.get(k2);
    if (l2 !== undefined) l2.push(index);
    else adjacency.set(k2, [index]);
  });

  const visited = new Set<number>();
  const loops: SilhouetteVec[][] = [];
  for (let start = 0; start < chain.length; start++) {
    if (visited.has(start)) continue;
    visited.add(start);
    const firstSeg = chain[start];
    if (firstSeg === undefined) continue;
    const startKey = firstSeg[0];
    let currentKey = firstSeg[1];
    const loop: SilhouetteVec[] = [];
    const startPoint = pointCache.get(startKey);
    if (startPoint !== undefined) loop.push(startPoint);
    let guard = 0;
    while (guard <= chain.length + 1) {
      guard++;
      if (currentKey === startKey) break; // ring closed; don't repeat origin
      const point = pointCache.get(currentKey);
      if (point !== undefined) loop.push(point);
      const segs = adjacency.get(currentKey) ?? [];
      const nextSeg = segs.find((id) => !visited.has(id));
      if (nextSeg === undefined) break;
      visited.add(nextSeg);
      const seg = chain[nextSeg];
      if (seg === undefined) break;
      currentKey = seg[0] === currentKey ? seg[1] : seg[0];
    }
    if (loop.length >= CONTOUR_MIN_LOOP_POINTS) loops.push(loop);
  }

  // Chaikin corner-cutting turns the staircase rings into smooth curves.
  const smoothed = loops.map((ring) => {
    let pts = ring;
    for (let pass = 0; pass < CONTOUR_SMOOTH_PASSES; pass++) {
      const next: SilhouetteVec[] = [];
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        const q = pts[(i + 1) % pts.length];
        if (p === undefined || q === undefined) continue;
        next.push({ x: 0.75 * p.x + 0.25 * q.x, y: 0.75 * p.y + 0.25 * q.y });
        next.push({ x: 0.25 * p.x + 0.75 * q.x, y: 0.25 * p.y + 0.75 * q.y });
      }
      pts = next;
    }
    return pts;
  });

  // Stable largest-first order by shoelace area (deterministic output).
  const area = (ring: readonly SilhouetteVec[]): number => {
    let sum = 0;
    for (let i = 0; i < ring.length; i++) {
      const p = ring[i];
      const q = ring[(i + 1) % ring.length];
      if (p === undefined || q === undefined) continue;
      sum += p.x * q.y - q.x * p.y;
    }
    return Math.abs(sum / 2);
  };
  return smoothed.sort((r1, r2) => area(r2) - area(r1));
}
