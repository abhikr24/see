/**
 * shared/reference/adapter.ts — Reference-pose foundation (Unit 29, Part 2).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE ADAPTER STAGE — the named boundary between a SOURCE and RAW DATA.
 *
 *     REFERENCE SOURCE ─▶ [ ADAPTER ] ─▶ RAW DATA ─▶ VALIDATION
 *                                     ─▶ NORMALIZATION ─▶ TEMPLATE
 *
 * An adapter's ONLY job is shape translation: take whatever a source calls
 * its data (a catalog entity, a database row, a REST body, a JSON file) and
 * emit a `RawReferencePayload`. Adapters:
 *
 *   · MUST NOT validate     — validation is one implementation, downstream
 *   · MUST NOT clamp/repair — bad source data must reach the validator and
 *                             be rejected there, visibly
 *   · MUST NOT do IO        — providers own IO; adapters are pure functions
 *   · MUST NOT know a schema they cannot see — the generic record adapter
 *                             below is CONFIGURED with a field mapping; it
 *                             does not guess anybody's column names
 *
 * WHY THIS EXISTS FOR SUPABASE: when a real table finally lands, integration
 * is `createRecordAdapter({ ...actual column names... })` plus a provider
 * that fetches rows. No maths, no matching, no coaching and no temporal logic
 * changes, because everything downstream of RAW DATA is already written.
 */
import type { RawReferencePayload } from "./pipeline";

/**
 * A pure source→raw translator. `TSource` is whatever the source hands over;
 * the adapter never sees the pipeline and the pipeline never sees `TSource`.
 */
export interface ReferenceSourceAdapter<TSource> {
  /** Stable adapter id, embedded in payload provenance for diagnostics. */
  readonly id: string;
  /** Translate one source object into an untrusted raw payload. */
  toRawPayload(source: TSource): RawReferencePayload;
}

/**
 * Field mapping for the GENERIC RECORD ADAPTER — the shape-agnostic mapper a
 * remote provider configures once. Every entry names a key in the source
 * record; nothing is assumed, and no key name here is a guess about any
 * future backend's schema (the caller supplies the real names).
 */
export interface RecordFieldMapping {
  readonly templateId: string;
  readonly poseId: string;
  readonly schemaVersion: string;
  readonly measurementVersion: string;
  /** Key holding the measurements object/array. */
  readonly measurements: string;
  /** Optional keys; omitted keys simply produce no field. */
  readonly provenance?: string;
  readonly capturedAt?: string;
  readonly unit?: string;
  readonly note?: string;
  readonly landmarkGeometry?: string;
}

/** One row/record as delivered by a remote source, before any interpretation. */
export type SourceRecord = Readonly<Record<string, unknown>>;

/**
 * Build an adapter for flat records (DB rows, API objects). It COPIES mapped
 * fields into the canonical raw envelope and copies the measurements value
 * through untouched — the validator decides whether any of it is usable.
 *
 * Unmapped/absent fields are simply absent from the payload, which makes the
 * validator report `missing-field` rather than the adapter inventing a value.
 */
export function createRecordAdapter(
  adapterId: string,
  providerId: string,
  mapping: RecordFieldMapping,
): ReferenceSourceAdapter<SourceRecord> {
  return {
    id: adapterId,
    toRawPayload(record: SourceRecord): RawReferencePayload {
      const pick = (key: string | undefined): unknown =>
        key === undefined ? undefined : record[key];

      const payload: Record<string, unknown> = {};
      const assign = (field: string, value: unknown): void => {
        if (value !== undefined) payload[field] = value;
      };

      assign("templateId", pick(mapping.templateId));
      assign("poseId", pick(mapping.poseId));
      assign("schemaVersion", pick(mapping.schemaVersion));
      assign("measurementVersion", pick(mapping.measurementVersion));
      assign("measurements", pick(mapping.measurements));
      assign("unit", pick(mapping.unit));

      const metadata: Record<string, unknown> = { sourceProvider: providerId };
      const provenance = pick(mapping.provenance);
      if (provenance !== undefined) metadata["provenance"] = provenance;
      const capturedAt = pick(mapping.capturedAt);
      if (capturedAt !== undefined) metadata["capturedAt"] = capturedAt;
      const note = pick(mapping.note);
      if (note !== undefined) metadata["note"] = note;
      const geometry = pick(mapping.landmarkGeometry);
      if (geometry !== undefined) metadata["landmarkGeometry"] = geometry;
      payload["metadata"] = metadata;

      return { providerId, payload };
    },
  };
}
