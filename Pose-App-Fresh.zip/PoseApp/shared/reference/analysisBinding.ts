/**
 * shared/reference/analysisBinding.ts — the ONE seam between the validated
 * reference domain (this folder) and the mathematical analysis engine
 * (shared/ml/analysis). Platform-neutral, zero RN/DOM/Supabase/TTS.
 *
 * DIRECTION OF DEPENDENCY (enforced by verify-reference-architecture.mjs):
 *   reference domain ──▶ engine        allowed  (this file)
 *   engine ──▶ reference domain        forbidden
 *
 * The engine may only ever see a plain, prevalidated projection. This adapter
 * produces that projection from a template that already survived
 * parse → validate → normalize, and refuses (structurally, with the domain's
 * own failure vocabulary) when the template cannot serve the engine.
 *
 * Binding happens ONCE per analysis session, outside the frame loop.
 */
import {
  ANALYSIS_MEASUREMENT_VERSION,
  bindSessionReference,
  type AnalysisReferenceInput,
  type SessionReferenceBinding,
} from "../ml/analysis";
import { MEASUREMENT_VERSION, SUPPORTED_MEASUREMENT_VERSIONS } from "./versions";
import { incompatibleReference, type ReferenceFailure } from "./failure";
import type { PinnedReference } from "./session";
import { templateMeasurementMap, type ReferencePoseTemplate } from "./template";

/**
 * Compile-time-ish guard: the engine's measurement semantics and the domain's
 * measurement version are the same number by contract. If they ever diverge,
 * every binding fails loudly instead of comparing v1 live math against v2
 * reference numbers.
 */
export function analysisSemanticsAgree(): boolean {
  return (
    ANALYSIS_MEASUREMENT_VERSION === MEASUREMENT_VERSION &&
    SUPPORTED_MEASUREMENT_VERSIONS.includes(ANALYSIS_MEASUREMENT_VERSION)
  );
}

export type AnalysisProjectionResult =
  | { readonly ok: true; readonly input: AnalysisReferenceInput }
  | { readonly ok: false; readonly failure: ReferenceFailure };

/**
 * Project a validated template into the engine's input shape. Values and
 * confidences are copied verbatim — nothing is invented for ids the template
 * does not carry, and nothing is rounded or rescaled.
 */
export function analysisInputFromTemplate(
  template: ReferencePoseTemplate,
): AnalysisProjectionResult {
  if (!analysisSemanticsAgree()) {
    return {
      ok: false,
      failure: incompatibleReference(
        `Engine measurement semantics v${ANALYSIS_MEASUREMENT_VERSION} do not ` +
          `match the reference domain's v${MEASUREMENT_VERSION}.`,
      ),
    };
  }
  const projection = templateMeasurementMap(template);
  if (!projection.ok) {
    return { ok: false, failure: projection.failure };
  }
  const values: Record<string, { value: number; confidence: number | null }> = {};
  for (const id of template.availability.availableIds) {
    const entry = template.measurements[id];
    if (entry === undefined) continue;
    values[id] = { value: entry.value, confidence: entry.confidence };
  }
  return {
    ok: true,
    input: {
      referenceId: template.templateId,
      poseId: template.poseId,
      schemaVersion: template.schemaVersion,
      measurementVersion: template.measurementVersion,
      contentHash: template.contentHash,
      values,
    },
  };
}

/** Same projection, taken from the SESSION PIN — the sanctioned live path. */
export function analysisInputFromPin(
  pin: PinnedReference,
): AnalysisProjectionResult {
  return analysisInputFromTemplate(pin.template);
}

/**
 * One-call convenience for a camera session: template → engine-ready frozen
 * session reference (or the engine's structured unavailable state). Returns
 * the engine's own binding result so callers hold exactly one vocabulary.
 */
export function bindTemplateForAnalysis(
  template: ReferencePoseTemplate,
): SessionReferenceBinding {
  const projection = analysisInputFromTemplate(template);
  if (!projection.ok) {
    return {
      ok: false,
      unavailable: {
        reason:
          projection.failure.kind === "incompatible-reference"
            ? "reference-incompatible"
            : projection.failure.kind === "incomplete-reference"
              ? "reference-incomplete"
              : "reference-invalid",
        message: projection.failure.message,
      },
    };
  }
  return bindSessionReference(projection.input);
}
