/**
 * shared/reference/canonical.ts — Reference-pose foundation (Unit 29, Part 2).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * IDENTIFIER + UNIT CANONICALIZATION — the normalization rules that make the
 * engine source-agnostic.
 *
 * After this module has run, the mathematical engine cannot tell whether the
 * numbers arrived from bundled JSON, a REST payload, a database row or a
 * Supabase response:
 *
 *   · identifiers   left_elbow / LEFT_ELBOW / elbow.left / "leftElbow "
 *                   → leftElbow                      (registry id, exact)
 *   · units         radians / rad / deg / degrees / ° → degrees
 *   · numeric form  "90.0" (string) / 90 (number)   → 90 (finite number)
 *
 * HARD RULES:
 *   · canonicalization RESHAPES, it never repairs. An identifier with no
 *     unambiguous canonical form stays unknown and validation rejects it.
 *     A value that is not a finite number stays invalid. Nothing is clamped,
 *     rounded to fit a range, or invented.
 *   · the alias table is derived mechanically from the registry, so it can
 *     never drift from the measurements this build actually understands.
 *   · unit conversion is exact (`degrees = radians × 180 / π`), applied
 *     BEFORE the plausibility band is checked, and recorded so callers can
 *     see that a conversion happened.
 */
import { knownMeasurementIds } from "./measurements";

/** Units a source may declare. Everything canonicalizes to degrees. */
export type ReferenceAngleUnit = "degrees" | "radians";

const UNIT_ALIASES: Readonly<Record<string, ReferenceAngleUnit>> = {
  deg: "degrees",
  degs: "degrees",
  degree: "degrees",
  degrees: "degrees",
  "°": "degrees",
  rad: "radians",
  rads: "radians",
  radian: "radians",
  radians: "radians",
};

/**
 * Resolve a declared unit token. Returns null for tokens this build does not
 * understand — the caller raises an explicit issue rather than assuming
 * degrees (assuming is how a 1.57 rad elbow silently becomes a 1.57° elbow).
 */
export function canonicalUnit(token: unknown): ReferenceAngleUnit | null {
  if (token === undefined || token === null) return "degrees"; // absent = the v1 default, documented
  if (typeof token !== "string") return null;
  return UNIT_ALIASES[token.trim().toLowerCase()] ?? null;
}

/** Exact conversion into the canonical unit. No rounding. */
export function toDegrees(value: number, unit: ReferenceAngleUnit): number {
  return unit === "radians" ? (value * 180) / Math.PI : value;
}

/**
 * Comparison key for identifier matching: lowercase, separators removed.
 * "left_elbow", "Left-Elbow", "LEFT ELBOW", "elbow.left " all fold down —
 * but note that folding is only used for LOOKUP against registry ids; the
 * result is always an exact registry id, never a cleaned-up version of the
 * caller's string.
 */
function foldIdentifier(raw: string): string {
  return raw.toLowerCase().replace(/[\s._\-/]/g, "");
}

/**
 * Alias table built from the registry at module load:
 *   leftElbow → { "leftelbow", "elbowleft" }
 * The reversed form covers sources that key by "elbow_left". Both directions
 * are generated, never hand-listed, so adding a measurement to the registry
 * automatically teaches this module its aliases.
 */
const CANONICAL_BY_FOLDED: ReadonlyMap<string, string> = (() => {
  const table = new Map<string, string>();
  const collisions = new Set<string>();
  const add = (folded: string, canonical: string): void => {
    const existing = table.get(folded);
    if (existing !== undefined && existing !== canonical) {
      /* Ambiguous alias: two registry ids fold to the same token. Refuse to
         guess — drop it so both resolve as unknown-measurement. */
      collisions.add(folded);
      return;
    }
    table.set(folded, canonical);
  };
  for (const id of knownMeasurementIds()) {
    add(foldIdentifier(id), id);
    /* side+part ⇄ part+side (leftElbow ⇄ elbowLeft) */
    const sideMatch = /^(left|right)([A-Z].*)$/.exec(id);
    if (sideMatch !== null) {
      const side = sideMatch[1] ?? "";
      const part = sideMatch[2] ?? "";
      add(foldIdentifier(`${part}${side}`), id);
    }
  }
  for (const folded of collisions) table.delete(folded);
  return table;
})();

/**
 * Map a source identifier onto a registry id, or null when no unambiguous
 * canonical form exists. Null is a real answer — the caller must surface
 * `unknown-measurement`, not silently drop the entry.
 */
export function canonicalMeasurementId(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (trimmed.length === 0) return null;
  return CANONICAL_BY_FOLDED.get(foldIdentifier(trimmed)) ?? null;
}

/**
 * Canonical numeric form. Accepts a number, or a numeric string as emitted by
 * databases that serialize NUMERIC columns as text ("90", "90.5", " 90 ").
 * Rejects everything else — including "", "NaN", "Infinity", booleans, null —
 * by returning null. NaN/Infinity NEVER survive this function.
 */
export function canonicalNumber(raw: unknown): number | null {
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : null;
  if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (trimmed.length === 0) return null;
    /* Number("0x10") === 16 and Number("1e2") === 100 are fine; guard the
       non-decimal spellings a data source should never emit. */
    if (!/^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(trimmed)) return null;
    const parsed = Number(trimmed);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

/** Canonical integer form (version stamps arriving as "1" from a row). */
export function canonicalInteger(raw: unknown): number | null {
  const value = canonicalNumber(raw);
  if (value === null || !Number.isInteger(value)) return null;
  return value;
}

/**
 * What normalization DID, reported as data. Consumers (and tests) can assert
 * that a remote payload was renamed/converted rather than trusting prose.
 */
export interface NormalizationRecord {
  /** sourceIdentifier → canonical registry id, only where they differ. */
  readonly renamedIds: Readonly<Record<string, string>>;
  /** canonical id → unit the source declared, only where ≠ degrees. */
  readonly convertedUnits: Readonly<Record<string, ReferenceAngleUnit>>;
  /** canonical ids whose value arrived as a string and was parsed. */
  readonly coercedNumericIds: readonly string[];
}

export const EMPTY_NORMALIZATION_RECORD: NormalizationRecord = Object.freeze({
  renamedIds: Object.freeze({}),
  convertedUnits: Object.freeze({}),
  coercedNumericIds: Object.freeze([]),
});
