/**
 * shared/reference/failure.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * STRUCTURED DOMAIN FAILURES.
 *
 * Every way reference resolution can go wrong is one explicit kind with a
 * machine-checkable code, a human message and a retryability hint. Callers
 * `switch` on `failure.kind` — they never parse exception text, and this
 * layer never throws for expected failure conditions.
 *
 * Kind vocabulary (kept stable; extend at the end, never rename):
 *   reference-unavailable  · the source has no reference for this pose
 *   invalid-reference      · payload failed validation (shape/values)
 *   incomplete-reference   · valid but too little data to compare against
 *   incompatible-reference · versions this build cannot read
 *   parse-error            · bytes were not understandable at all
 *   provider-failure       · the provider itself blew up (bug/crash)
 *   timeout                · the source did not answer in time
 *   network-failure        · transport-level connectivity problem
 *   unauthorized           · credentials missing/insufficient for the source
 *   stale-data             · resolved data is older than a required bound
 *   approximate-only       · the only data available is category-approximate
 *                            and the caller's fidelity policy is measured-only
 */
export type ReferenceFailureKind =
  | "reference-unavailable"
  | "invalid-reference"
  | "incomplete-reference"
  | "incompatible-reference"
  | "parse-error"
  | "provider-failure"
  | "timeout"
  | "network-failure"
  | "unauthorized"
  | "stale-data"
  | "approximate-only";

export interface ReferenceFailure {
  readonly kind: ReferenceFailureKind;
  /** Human-readable explanation, safe for logs and diagnostics UI. */
  readonly message: string;
  /**
   * True when retrying the same request could succeed (transient problems:
   * timeout, network, stale cache). False for data the user/source must fix.
   */
  readonly retryable: boolean;
  /** Measurement the failure is about, when applicable. */
  readonly measurementId?: string;
  /** Provider that produced the failure, when applicable. */
  readonly providerId?: string;
  /** Extra structured context (validation issue codes, original error name). */
  readonly details?: Readonly<Record<string, unknown>>;
}

function failure(
  kind: ReferenceFailureKind,
  message: string,
  retryable: boolean,
  extras?: Partial<Pick<ReferenceFailure, "measurementId" | "providerId" | "details">>,
): ReferenceFailure {
  return { kind, message, retryable, ...extras };
}

export const referenceUnavailable = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("reference-unavailable", message, true, extras);

export const invalidReference = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("invalid-reference", message, false, extras);

export const incompleteReference = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("incomplete-reference", message, false, extras);

export const incompatibleReference = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("incompatible-reference", message, false, extras);

export const referenceParseError = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("parse-error", message, false, extras);

export const providerFailure = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("provider-failure", message, true, extras);

export const referenceTimeout = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("timeout", message, true, extras);

export const referenceNetworkFailure = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("network-failure", message, true, extras);

export const referenceUnauthorized = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("unauthorized", message, false, extras);

export const staleReferenceData = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("stale-data", message, true, extras);

/**
 * The honest answer when a source holds only category-approximate data and
 * the caller demanded measured data. NOT retryable: retrying cannot conjure a
 * measurement that was never taken. This is the failure that replaces the
 * banned "substitute plausible angles and coach anyway" behavior.
 */
export const approximateOnly = (
  message: string,
  extras?: Parameters<typeof failure>[3],
): ReferenceFailure => failure("approximate-only", message, false, extras);

/** Type guard for values flowing across provider boundaries. */
export function isReferenceFailure(value: unknown): value is ReferenceFailure {
  if (typeof value !== "object" || value === null) return false;
  const candidate = value as { kind?: unknown; message?: unknown };
  return typeof candidate.kind === "string" && typeof candidate.message === "string";
}
