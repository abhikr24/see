/**
 * shared/reference/fidelity.ts — Reference-pose foundation (Unit 29, Part 2).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE FIDELITY AXIS — "how real is this number?"
 *
 * Provenance answers WHERE data came from. Fidelity answers a different and
 * harder question: whether the numbers describe THIS pose as it was actually
 * measured, or merely a plausible stance for its category.
 *
 * The audit that created this module found the bundled catalog handing the
 * coaching engine per-pose angles produced by a deterministic noise function
 * (`categoryStance + ((seed * 31 + jointIndex * 17) % 13) - 6`). Those digits
 * were never measured from anything; they existed so that 400 poses would not
 * score identically. That is exactly the banned pattern:
 *
 *     no measured reference → invented angles → coaching
 *
 * The fabrication is gone (see shared/data/referenceAngles.ts). What remains
 * is an honest, hand-authored CATEGORY stance, and it is now labelled as such
 * all the way to the engine boundary. Nothing may launder approximate data
 * into measured data.
 *
 * POLICY, NOT DEFAULT: `ReferenceFidelityPolicy` is a REQUIRED provider
 * argument. There is no implicit default anywhere in this domain, because a
 * default is how "approximate" silently becomes "production". The app states
 * its choice at one auditable wiring point and the template carries the
 * fidelity forward so UI/coaching can disclose it.
 */
import type { ReferenceProvenance } from "./template";

/**
 * measured            · the values were extracted from a real observation of
 *                       THIS pose (reference photograph landmark scan, or a
 *                       remote source that asserts measured provenance)
 * category-approximate· hand-authored stance typical of the pose's CATEGORY.
 *                       Useful as a coarse guide; it is not a measurement of
 *                       this pose and must never be presented as one.
 */
export type ReferenceFidelity = "measured" | "category-approximate";

/**
 * What a consumer is willing to accept.
 *   measured-only      · reject approximate data; resolution reports the
 *                        explicit `approximate-only` failure instead
 *   allow-approximate  · accept it, clearly labelled, disclosure required
 */
export type ReferenceFidelityPolicy = "measured-only" | "allow-approximate";

/**
 * Fidelity implied by provenance. This is the ONLY mapping in the codebase —
 * a source cannot self-declare "measured" while shipping category defaults,
 * because provenance is validated against a closed vocabulary first.
 */
export function fidelityForProvenance(
  provenance: ReferenceProvenance,
): ReferenceFidelity {
  switch (provenance) {
    case "measured-scan":
      return "measured";
    case "remote-source":
      /* A remote source that has real data states provenance 'measured-scan'.
         Plain 'remote-source' is untyped delivery, treated as approximate
         until the source proves otherwise — the conservative direction. */
      return "category-approximate";
    case "bundled-category-default":
      return "category-approximate";
    case "test-fixture":
      /* Fixtures are never production data; they are approximate by
         definition so a leak can never pass a measured-only gate. */
      return "category-approximate";
    default: {
      const exhaustive: never = provenance;
      return exhaustive;
    }
  }
}

/** True when `fidelity` satisfies `policy`. */
export function fidelitySatisfiesPolicy(
  fidelity: ReferenceFidelity,
  policy: ReferenceFidelityPolicy,
): boolean {
  return policy === "allow-approximate" || fidelity === "measured";
}

/**
 * Human-readable disclosure a UI layer must show when approximate data is
 * used for coaching. Returned as data (no copy decisions in this domain, no
 * translation keys — the language layer owns wording).
 */
export function fidelityDisclosureKey(
  fidelity: ReferenceFidelity,
): "reference.fidelity.measured" | "reference.fidelity.approximate" {
  return fidelity === "measured"
    ? "reference.fidelity.measured"
    : "reference.fidelity.approximate";
}
