/**
 * shared/reference/imagePipeline.ts — Reference-pose foundation (Unit 29).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE REFERENCE-IMAGE PIPELINE — build-once, never per frame.
 *
 *   REFERENCE PIPELINE (this file, runs ONCE per reference image)
 *     image → [platform detector, injected] → landmarks
 *           → landmark validation → measurement extraction → TEMPLATE
 *
 *   LIVE PIPELINE (shared/ml, runs every frame — untouched by this file)
 *     live landmarks → measurement extraction → comparison → coaching
 *
 * The two are kept apart on purpose. A reference image describes a fixed
 * target; re-detecting it on every frame would burn battery, add latency and
 * — worse — let the reference wobble frame to frame, which makes a match-%
 * series meaningless. `createReferenceImageTemplateCache` enforces the
 * build-once rule structurally: a second request for the same image returns
 * the SAME frozen template object, and the detector is never consulted again.
 *
 * WHAT THIS FILE DOES NOT DO: decode images, own a detector, or touch the
 * network. Detection is the platform's job (MediaPipe on device); this module
 * consumes the landmarks it produces. That is what keeps the reference domain
 * infrastructure-free and unit-testable without a device.
 */
import {
  MATCH_JOINTS,
  MIN_LANDMARK_VISIBILITY,
  POSE_LANDMARK_COUNT,
  type PoseLandmark,
} from "../ml/poseLandmarks";
import { jointAngle } from "../ml/poseMatch";
import { invalidReference, incompleteReference, type ReferenceFailure } from "./failure";
import { MIN_MEASUREMENTS_FOR_COMPARISON } from "./measurements";
import { buildReferenceTemplate, type BuildReferenceResult } from "./pipeline";
import { ReferenceStatuses } from "./status";
import type { ReferencePoseTemplate } from "./template";
import { MEASUREMENT_VERSION, REFERENCE_TEMPLATE_SCHEMA_VERSION } from "./versions";

/** One detector result for one reference image. */
export interface ReferenceImageDetection {
  /** Catalog pose this reference image depicts. */
  readonly poseId: string;
  /**
   * Stable identity of the IMAGE itself (asset path, content hash, remote
   * id). It is the cache key — two different images of one pose are two
   * different references, and the same image never re-runs detection.
   */
  readonly sourceImageId: string;
  /** 33 landmarks as produced by the platform detector. */
  readonly landmarks: readonly PoseLandmark[];
  /** Detector's overall confidence 0..1, when it reports one. */
  readonly detectorConfidence?: number | null;
  /** ISO timestamp of the scan, when the caller records one. */
  readonly capturedAt?: string;
}

/* ------------------------------------------------------------------ */
/* Stage A — landmark validation                                       */
/* ------------------------------------------------------------------ */

export interface LandmarkValidationIssue {
  readonly code:
    | "wrong-landmark-count"
    | "non-finite-coordinate"
    | "invalid-visibility"
    | "too-few-visible-landmarks"
    | "invalid-detector-confidence";
  readonly message: string;
  readonly index?: number;
}

export type LandmarkValidationResult =
  | { readonly ok: true }
  | { readonly ok: false; readonly issues: readonly LandmarkValidationIssue[] };

/**
 * Minimum visible landmarks before a detection is worth measuring. The eight
 * match joints touch 12 distinct body landmarks; below that a "reference"
 * would be mostly holes.
 */
export const MIN_VISIBLE_REFERENCE_LANDMARKS = 12;

export function validateReferenceLandmarks(
  detection: ReferenceImageDetection,
): LandmarkValidationResult {
  const issues: LandmarkValidationIssue[] = [];
  const { landmarks } = detection;

  if (landmarks.length !== POSE_LANDMARK_COUNT) {
    issues.push({
      code: "wrong-landmark-count",
      message: `Expected ${POSE_LANDMARK_COUNT} landmarks; got ${landmarks.length}.`,
    });
    /* Everything below indexes the array; stop here rather than emit noise. */
    return { ok: false, issues };
  }

  const confidence = detection.detectorConfidence;
  if (
    confidence !== undefined &&
    confidence !== null &&
    (!Number.isFinite(confidence) || confidence < 0 || confidence > 1)
  ) {
    issues.push({
      code: "invalid-detector-confidence",
      message: `Detector confidence must be null or within 0..1; got ${String(confidence)}.`,
    });
  }

  let visible = 0;
  landmarks.forEach((landmark, index) => {
    if (
      !Number.isFinite(landmark.x) ||
      !Number.isFinite(landmark.y) ||
      !Number.isFinite(landmark.z)
    ) {
      issues.push({
        code: "non-finite-coordinate",
        message: `Landmark ${index} has a non-finite coordinate.`,
        index,
      });
      return;
    }
    const visibility = landmark.visibility;
    if (
      visibility !== undefined &&
      (!Number.isFinite(visibility) || visibility < 0 || visibility > 1)
    ) {
      issues.push({
        code: "invalid-visibility",
        message: `Landmark ${index} visibility must be within 0..1; got ${String(visibility)}.`,
        index,
      });
      return;
    }
    if ((visibility ?? 1) >= MIN_LANDMARK_VISIBILITY) visible += 1;
  });

  if (visible < MIN_VISIBLE_REFERENCE_LANDMARKS) {
    issues.push({
      code: "too-few-visible-landmarks",
      message:
        `Only ${visible} landmark(s) clear the visibility floor; ` +
        `${MIN_VISIBLE_REFERENCE_LANDMARKS} are required for a reference scan.`,
    });
  }

  return issues.length === 0 ? { ok: true } : { ok: false, issues };
}

/* ------------------------------------------------------------------ */
/* Stage B — measurement extraction                                    */
/* ------------------------------------------------------------------ */

export interface ExtractedMeasurements {
  /** measurementId → degrees, only for joints that could be measured. */
  readonly measurements: Readonly<Record<string, number>>;
  /** Joints skipped because their landmarks were missing/occluded. */
  readonly unmeasurableIds: readonly string[];
}

/**
 * Extract the registry's measurements from validated landmarks, reusing the
 * ENGINE's own `jointAngle` — the reference and the live path must compute
 * angles with identical maths or every comparison is apples-to-oranges.
 * Unmeasurable joints are reported, never estimated.
 */
export function extractMeasurementsFromLandmarks(
  landmarks: readonly PoseLandmark[],
): ExtractedMeasurements {
  const measurements: Record<string, number> = {};
  const unmeasurableIds: string[] = [];
  for (const joint of MATCH_JOINTS) {
    const degrees = jointAngle(landmarks, joint);
    if (degrees === null) {
      unmeasurableIds.push(joint.key);
      continue;
    }
    measurements[joint.key] = degrees;
  }
  return {
    measurements: Object.freeze(measurements),
    unmeasurableIds: Object.freeze(unmeasurableIds),
  };
}

/* ------------------------------------------------------------------ */
/* Stage C — template creation                                         */
/* ------------------------------------------------------------------ */

export interface ReferenceImageTemplateOptions {
  /** Provider that owns this scan (e.g. "reference-scanner"). */
  readonly providerId: string;
  /**
   * Confidence attached to every extracted measurement. Pass the detector's
   * confidence when it reports one; pass null to make no claim. It is NOT
   * defaulted to 1 — claiming certainty nobody measured is fabrication.
   */
  readonly measurementConfidence: number | null;
}

export type ReferenceImageTemplateResult =
  | { readonly status: typeof ReferenceStatuses.ready; readonly template: ReferencePoseTemplate }
  | {
      readonly status:
        | typeof ReferenceStatuses.invalid
        | typeof ReferenceStatuses.incomplete
        | typeof ReferenceStatuses.incompatible;
      readonly failure: ReferenceFailure;
      readonly landmarkIssues?: readonly LandmarkValidationIssue[];
    };

/**
 * image-detection → validated landmarks → measurements → TEMPLATE.
 *
 * Runs the SAME validate/normalize pipeline every other source uses, so a
 * scanned template and a bundled template are indistinguishable downstream
 * except in their honest provenance ('measured-scan') and fidelity.
 */
export function buildTemplateFromReferenceImage(
  detection: ReferenceImageDetection,
  options: ReferenceImageTemplateOptions,
): ReferenceImageTemplateResult {
  const landmarkCheck = validateReferenceLandmarks(detection);
  if (!landmarkCheck.ok) {
    return {
      status: ReferenceStatuses.invalid,
      failure: invalidReference(
        `Reference image "${detection.sourceImageId}" failed landmark validation: ` +
          `${landmarkCheck.issues[0]?.message ?? "unknown"}`,
        {
          providerId: options.providerId,
          details: { issues: landmarkCheck.issues.map((issue) => issue.code) },
        },
      ),
      landmarkIssues: landmarkCheck.issues,
    };
  }

  const extracted = extractMeasurementsFromLandmarks(detection.landmarks);
  const measuredIds = Object.keys(extracted.measurements);
  if (measuredIds.length < MIN_MEASUREMENTS_FOR_COMPARISON) {
    return {
      status: ReferenceStatuses.incomplete,
      failure: incompleteReference(
        `Reference image "${detection.sourceImageId}" yielded only ` +
          `${measuredIds.length} measurable joint(s); ` +
          `${MIN_MEASUREMENTS_FOR_COMPARISON} are required.`,
        {
          providerId: options.providerId,
          details: { unmeasurable: extracted.unmeasurableIds },
        },
      ),
    };
  }

  const measurements: Record<string, { value: number; confidence: number | null }> = {};
  for (const id of measuredIds) {
    const value = extracted.measurements[id];
    if (value === undefined) continue;
    measurements[id] = { value, confidence: options.measurementConfidence };
  }

  const built: BuildReferenceResult = buildReferenceTemplate({
    providerId: options.providerId,
    payload: {
      templateId: `${options.providerId}/${detection.poseId}@${detection.sourceImageId}`,
      poseId: detection.poseId,
      schemaVersion: REFERENCE_TEMPLATE_SCHEMA_VERSION,
      measurementVersion: MEASUREMENT_VERSION,
      unit: "degrees",
      measurements,
      metadata: {
        provenance: "measured-scan",
        sourceProvider: options.providerId,
        landmarkGeometry: "measured-33",
        ...(detection.capturedAt !== undefined ? { capturedAt: detection.capturedAt } : {}),
        note:
          `Measured from reference image "${detection.sourceImageId}"` +
          (extracted.unmeasurableIds.length > 0
            ? `; unmeasurable joints: ${extracted.unmeasurableIds.join(", ")}`
            : ""),
      },
    },
  });

  if (built.status !== ReferenceStatuses.ready) {
    return { status: built.status, failure: built.failure };
  }
  return { status: ReferenceStatuses.ready, template: built.template };
}

/* ------------------------------------------------------------------ */
/* Build-once cache — the structural guarantee                         */
/* ------------------------------------------------------------------ */

export interface ReferenceImageTemplateCache {
  /**
   * Returns the cached result for this image, or computes it exactly once.
   * `detectionCount()` lets tests PROVE the reference image is not
   * reprocessed per frame.
   */
  resolve(
    detection: ReferenceImageDetection,
    options: ReferenceImageTemplateOptions,
  ): ReferenceImageTemplateResult;
  /** How many times a template was actually built (cache misses). */
  buildCount(): number;
  clear(): void;
}

export function createReferenceImageTemplateCache(): ReferenceImageTemplateCache {
  const cache = new Map<string, ReferenceImageTemplateResult>();
  let builds = 0;
  return {
    resolve(detection, options): ReferenceImageTemplateResult {
      const key = `${options.providerId}|${detection.poseId}|${detection.sourceImageId}`;
      const hit = cache.get(key);
      if (hit !== undefined) return hit;
      builds += 1;
      const result = buildTemplateFromReferenceImage(detection, options);
      cache.set(key, result);
      return result;
    },
    buildCount(): number {
      return builds;
    },
    clear(): void {
      cache.clear();
      builds = 0;
    },
  };
}
