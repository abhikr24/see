/**
 * shared/reference/index.ts — Reference-pose foundation barrel (Part 1).
 *
 * THE PIPELINE THIS FOLDER OWNS:
 *
 *   REFERENCE SOURCE ──▶ PROVIDER (adapters here; future: local/Supabase/
 *     │                   API/test implement the same interface)
 *     │  RawReferencePayload (unknown, source-tagged)
 *     ▼
 *   parse  [loaded] ─▶ validate [validated | invalid/incomplete/incompatible]
 *     ─▶ normalize [normalized] ─▶ ReferencePoseTemplate [ready]
 *     ▼
 *   SESSION PIN (session.ts) ─▶ POSE ANALYSIS ENGINE (shared/ml — consumes
 *     the projection from templateMeasurementMap ONLY) ─▶ semantic coaching
 *     (guidance) ─▶ existing language/TTS layer.
 *
 * DEPENDENCY RULES (verified by mobile/scripts/verify-reference-architecture):
 *   · this folder never imports React/RN/DOM/Supabase/expo-speech/mobile code
 *   · shared/ml (the math engine) never imports providers or raw payloads —
 *     it receives the canonical measurement projection
 *   · shared/data/referenceAngles.ts remains the bundled DEFAULT SOURCE;
 *     it is adapted here, never imported by engines directly
 */
export * from "./versions";
export * from "./measurements";
export * from "./canonical";
export * from "./fidelity";
export * from "./adapter";
export * from "./failure";
export * from "./status";
export * from "./template";
export * from "./pipeline";
export * from "./provider";
export * from "./session";
export * from "./analysisBinding";
export * from "./imagePipeline";
export * from "./providers/catalog";
export * from "./providers/memory";
export * from "./providers/unavailable";
export * from "./providers/remote";
export * from "./providers/registry";
