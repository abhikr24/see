/**
 * shared/reference/measurements.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE MEASUREMENT REGISTRY.
 *
 * A measurement is a named, unit-typed numeric fact about a reference pose
 * (today: interior joint angles in degrees; future: generic spatial
 * measurements). The engine never sees a bare {"leftElbow": 120} map that
 * came from the outside world — every measurement id, plausible range and
 * unit is declared HERE, and validation compares payloads against this
 * registry.
 *
 * EXTENSIBILITY CONTRACT: adding a future measurement family (torsoLean,
 * shoulderAlignment, stanceWidth, headOrientation, ...) means adding
 * definitions here AND bumping MEASUREMENT_VERSION, so old reference data
 * and new math are never silently mixed. Do NOT add definitions for
 * measurements nothing can produce yet — an empty promise is worse than an
 * absent one.
 */
import {
  MATCH_JOINTS,
  PLAUSIBLE_JOINT_ANGLE_DEGREES,
} from "../ml/poseLandmarks";

/**
 * Engine-plausibility band for measured joint angles, in degrees. BOUND to
 * the single owner (shared/ml/poseLandmarks.PLAUSIBLE_JOINT_ANGLE_DEGREES) —
 * not a second copy of 2/180 — so reference validation and the live engine
 * can never disagree about what a possible angle is.
 * Reference data outside this band could never be reproduced by a human in
 * front of the camera, so it is rejected as invalid input data.
 */
export const MEASUREMENT_PLAUSIBLE_RANGE_DEGREES = PLAUSIBLE_JOINT_ANGLE_DEGREES;

/**
 * Minimum number of usable measurements a template must carry for the match
 * engine to produce any score at all (mirrors the >=2 compared-joints rule
 * in calculateMatchPercent/generatePoseGuidance). Below this the template is
 * 'incomplete-reference': a valid pose can exist, a score cannot.
 */
export const MIN_MEASUREMENTS_FOR_COMPARISON = 2;

/** How a measurement value is produced/read. Drives future engine dispatch. */
export type MeasurementKind = "joint-interior-angle" | "generic-spatial";

export interface MeasurementDefinition {
  /** Stable id stored in templates and referenced by engines. */
  readonly id: string;
  readonly kind: MeasurementKind;
  /** Unit of `value`. v1 is always degrees. */
  readonly unit: "degrees";
  /** Inclusive plausibility band; validation rejects values outside it. */
  readonly range: { readonly min: number; readonly max: number };
  /**
   * True when the v1 match engine (calculateMatchPercent /
   * generatePoseGuidance) consumes this id for scoring and guidance.
   */
  readonly engineEligible: boolean;
}

/**
 * The v1 measurement set — derived from MATCH_JOINTS (single source of
 * truth: the landmark triples live in shared/ml/poseLandmarks.ts, so the
 * registry cannot drift from the joints the engine actually measures).
 */
export const MEASUREMENT_DEFINITIONS: readonly MeasurementDefinition[] =
  MATCH_JOINTS.map((joint) => ({
    id: joint.key,
    kind: "joint-interior-angle" as const,
    unit: "degrees" as const,
    range: MEASUREMENT_PLAUSIBLE_RANGE_DEGREES,
    engineEligible: true,
  }));

/** Lookup by id; undefined for ids the registry does not know. */
const DEFINITION_BY_ID: ReadonlyMap<string, MeasurementDefinition> = new Map(
  MEASUREMENT_DEFINITIONS.map((definition) => [definition.id, definition]),
);

export function getMeasurementDefinition(
  id: string,
): MeasurementDefinition | undefined {
  return DEFINITION_BY_ID.get(id);
}

/** All measurement ids known to this build, in stable registry order. */
export function knownMeasurementIds(): readonly string[] {
  return MEASUREMENT_DEFINITIONS.map((definition) => definition.id);
}
