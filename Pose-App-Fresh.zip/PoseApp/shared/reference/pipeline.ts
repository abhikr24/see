/**
 * shared/reference/pipeline.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE RAW → VALIDATED → NORMALIZED PIPELINE.
 *
 *   RawReferencePayload (unknown, source-tagged)
 *     → parseReferencePayload   [stage: 'loaded']
 *     → validateReferencePayload [stage: 'validated' | failure issues]
 *     → normalizeReferencePayload [stage: 'normalized']
 *     → buildReferenceTemplate   [stage: 'ready'] — the one-call composed API
 *
 * RAW and VALIDATED data are intentionally different TYPES: `unknown`-shaped
 * payloads exist on the left of this file, frozen ReferencePoseTemplates on
 * the right. Nothing in the engine domain may touch the left side.
 *
 * Invariants (per the handoff contract):
 *   · expected bad data NEVER throws — it returns structured issues/failures
 *   · invalid data is never silently converted into valid data: no clamping,
 *     no rounding, no invented values, no dropped measurements
 */
import {
  getMeasurementDefinition,
  knownMeasurementIds,
  MEASUREMENT_DEFINITIONS,
  MEASUREMENT_PLAUSIBLE_RANGE_DEGREES,
  MIN_MEASUREMENTS_FOR_COMPARISON,
} from "./measurements";
import {
  isSupportedMeasurementVersion,
  isSupportedSchemaVersion,
  referenceVersionStamp,
  SUPPORTED_SCHEMA_VERSIONS,
} from "./versions";
import {
  canonicalInteger,
  canonicalMeasurementId,
  canonicalNumber,
  canonicalUnit,
  toDegrees,
  type NormalizationRecord,
  type ReferenceAngleUnit,
} from "./canonical";
import { fidelityForProvenance } from "./fidelity";
import {
  incompleteReference,
  incompatibleReference,
  invalidReference,
  referenceParseError,
  type ReferenceFailure,
} from "./failure";
import { ReferenceStatuses } from "./status";
import {
  contentHashInput,
  referenceContentHash,
  type ReferenceMeasurementValue,
  type ReferencePoseTemplate,
  type ReferenceProvenance,
  type ReferenceTemplateMetadata,
} from "./template";

/* ------------------------------------------------------------------ */
/* RAW side                                                            */
/* ------------------------------------------------------------------ */

/**
 * Untrusted input as produced by ANY source adapter: a JSON-shaped value of
 * unknown structure plus a provider tag for diagnostics. Crafting this from
 * a database row / network response / catalog entity is the ADAPTER's job —
 * the pipeline treats it as opaque bytes.
 */
export interface RawReferencePayload {
  readonly providerId: string;
  readonly payload: unknown;
}

/** A machine-checkable validation issue. Expected input errors never throw. */
export interface ReferenceValidationIssue {
  readonly code:
    | "not-an-object"
    | "missing-field"
    | "wrong-type"
    | "missing-version"
    | "unsupported-schema-version"
    | "unsupported-measurement-version"
    | "unknown-measurement"
    | "invalid-measurement-value"
    | "invalid-confidence"
    | "empty-measurements"
    | "below-minimum-measurements"
    /* Unit 29 — canonicalization issues. */
    | "unknown-unit"
    | "duplicate-measurement";
  readonly message: string;
  readonly measurementId?: string;
  /** JSON-path-ish location, e.g. "measurements.leftElbow.value". */
  readonly path: string;
}

/* ------------------------------------------------------------------ */
/* Stage 1 — parse: bytes → candidate object   [status: 'loaded']      */
/* ------------------------------------------------------------------ */

export type ParseStageResult =
  | { readonly status: typeof ReferenceStatuses.loaded; readonly data: Record<string, unknown> }
  | { readonly status: typeof ReferenceStatuses.invalid; readonly failure: ReferenceFailure };

export function parseReferencePayload(raw: RawReferencePayload): ParseStageResult {
  const { payload, providerId } = raw;
  if (typeof payload === "string") {
    try {
      const parsed: unknown = JSON.parse(payload);
      return parseReferencePayload({ providerId, payload: parsed });
    } catch (error) {
      return {
        status: ReferenceStatuses.invalid,
        failure: referenceParseError(
          `Reference payload from "${providerId}" is not valid JSON: ${
            error instanceof Error ? error.message : String(error)
          }`,
          { providerId },
        ),
      };
    }
  }
  if (typeof payload !== "object" || payload === null || Array.isArray(payload)) {
    return {
      status: ReferenceStatuses.invalid,
      failure: invalidReference(
        `Reference payload from "${providerId}" must be an object; ` +
          `got ${Array.isArray(payload) ? "array" : typeof payload}.`,
        { providerId },
      ),
    };
  }
  return { status: ReferenceStatuses.loaded, data: payload as Record<string, unknown> };
}

/* ------------------------------------------------------------------ */
/* Stage 2 — validate: candidate → issues      [status: 'validated']   */
/* ------------------------------------------------------------------ */

const REQUIRED_STRING_FIELDS = ["templateId", "poseId"] as const;

export type ValidateStageResult =
  | {
      readonly status: typeof ReferenceStatuses.validated;
      readonly data: {
        readonly templateId: string;
        readonly poseId: string;
        readonly schemaVersion: number;
        readonly measurementVersion: number;
        readonly measurements: Readonly<Record<string, ReferenceMeasurementValue>>;
        readonly metadata: ReferenceTemplateMetadata;
        /** Audit trail of the canonicalization applied to this payload. */
        readonly normalization: NormalizationRecord;
      };
    }
  | {
      readonly status:
        | typeof ReferenceStatuses.invalid
        | typeof ReferenceStatuses.incomplete
        | typeof ReferenceStatuses.incompatible;
      readonly failure: ReferenceFailure;
      readonly issues: readonly ReferenceValidationIssue[];
    };

const VALID_PROVENANCES: readonly ReferenceProvenance[] = [
  "bundled-category-default",
  "measured-scan",
  "remote-source",
  "test-fixture",
];

/** Rendered once for diagnostics messages, e.g. "s1 (v1)". */
const SUPPORTED_SCHEMA_VERSION_LIST = SUPPORTED_SCHEMA_VERSIONS.map(
  (version: number) => referenceVersionStamp(version, version).split(".")[0] ?? `s${version}`,
).join(", ");

export function validateReferencePayload(
  parsed: Record<string, unknown>,
  providerId: string,
): ValidateStageResult {
  const issues: ReferenceValidationIssue[] = [];
  /* Normalization audit trail, filled as identifiers/units/numbers are
     canonicalized below. Reported in the artifact, never hidden. */
  const renamedIds: Record<string, string> = {};
  const convertedUnits: Record<string, ReferenceAngleUnit> = {};
  const coercedNumericIds: string[] = [];
  const issue = (
    code: ReferenceValidationIssue["code"],
    message: string,
    path: string,
    measurementId?: string,
  ): void => {
    issues.push({ code, message, path, measurementId });
  };

  /* Identity fields. */
  for (const field of REQUIRED_STRING_FIELDS) {
    const value = parsed[field];
    if (value === undefined) {
      issue("missing-field", `Missing required field "${field}".`, field);
    } else if (typeof value !== "string" || value.length === 0) {
      issue("wrong-type", `Field "${field}" must be a non-empty string.`, field);
    }
  }

  /* Version stamps — checked BEFORE values: semantics decides interpretation.
     Canonicalized first, so a row that serialized "1" as text is READ, while
     anything non-integral is still rejected rather than coerced. */
  const schemaVersion: number | null =
    parsed["schemaVersion"] === undefined ? null : canonicalInteger(parsed["schemaVersion"]);
  if (parsed["schemaVersion"] === undefined) {
    issue("missing-version", 'Missing required field "schemaVersion".', "schemaVersion");
  } else if (schemaVersion === null) {
    issue("wrong-type", '"schemaVersion" must be an integer.', "schemaVersion");
  } else if (!isSupportedSchemaVersion(schemaVersion)) {
    issue(
      "unsupported-schema-version",
      `Schema version ${schemaVersion} is not supported by this build ` +
        `(reads ${SUPPORTED_SCHEMA_VERSION_LIST}).`,
      "schemaVersion",
    );
  }

  const measurementVersion: number | null =
    parsed["measurementVersion"] === undefined
      ? null
      : canonicalInteger(parsed["measurementVersion"]);
  if (parsed["measurementVersion"] === undefined) {
    issue("missing-version", 'Missing required field "measurementVersion".', "measurementVersion");
  } else if (measurementVersion === null) {
    issue("wrong-type", '"measurementVersion" must be an integer.', "measurementVersion");
  } else if (!isSupportedMeasurementVersion(measurementVersion)) {
    issue(
      "unsupported-measurement-version",
      `Measurement version ${measurementVersion} is not supported by this build.`,
      "measurementVersion",
    );
  }

  /* Payload-level unit declaration (per-measurement units may override). An
     unrecognized token is an ERROR, never "probably degrees": mistaking
     radians for degrees would silently produce nonsense coaching. */
  const payloadUnit = canonicalUnit(parsed["unit"]);
  if (payloadUnit === null) {
    issue("unknown-unit", `Unrecognized unit "${String(parsed["unit"])}".`, "unit");
  }

  /* Measurements map. */
  const measurementsRaw = parsed["measurements"];
  const measurements: Record<string, ReferenceMeasurementValue> = {};
  if (typeof measurementsRaw !== "object" || measurementsRaw === null || Array.isArray(measurementsRaw)) {
    issue("missing-field", 'Missing or malformed "measurements" object.', "measurements");
  } else {
    const entries = Object.entries(measurementsRaw as Record<string, unknown>);
    if (entries.length === 0) {
      issue("empty-measurements", "The measurements object is empty.", "measurements");
    }
    for (const [sourceId, rawEntry] of entries) {
      const path = `measurements.${sourceId}`;
      /* NORMALIZATION OF IDENTIFIERS: fold the source spelling onto exactly
         one registry id, or reject. No fuzzy "closest match" ever. */
      const id = canonicalMeasurementId(sourceId);
      const definition = id === null ? undefined : getMeasurementDefinition(id);
      if (id === null || definition === undefined) {
        issue(
          "unknown-measurement",
          `Unknown measurement id "${sourceId}" — not in the registry for this build.`,
          path,
          sourceId,
        );
        continue;
      }
      if (id !== sourceId) renamedIds[sourceId] = id;
      if (measurements[id] !== undefined) {
        /* Two source keys folded onto one registry id (e.g. "leftElbow" and
           "left_elbow" in the same payload). Picking a winner would be a
           guess about which number is authoritative. */
        issue(
          "duplicate-measurement",
          `Measurements "${sourceId}" and an earlier key both map to "${id}".`,
          path,
          id,
        );
        continue;
      }
      /* Entries accept { value, confidence?, unit? } or a bare number. */
      let rawValue: unknown;
      let rawConfidence: unknown = null;
      let entryUnitToken: unknown;
      if (typeof rawEntry === "number" || typeof rawEntry === "string") {
        rawValue = rawEntry;
      } else if (typeof rawEntry === "object" && rawEntry !== null && !Array.isArray(rawEntry)) {
        rawValue = (rawEntry as Record<string, unknown>)["value"];
        rawConfidence = (rawEntry as Record<string, unknown>)["confidence"] ?? null;
        entryUnitToken = (rawEntry as Record<string, unknown>)["unit"];
      } else {
        issue("wrong-type", `Measurement "${sourceId}" must be a number or { value, confidence }.`, path, id);
        continue;
      }
      /* NORMALIZATION OF NUMERIC FORMAT: NaN/Infinity/"" /booleans/null all
         fail here; a numeric string is read and recorded as coerced. */
      const numeric = canonicalNumber(rawValue);
      if (numeric === null) {
        issue(
          "invalid-measurement-value",
          `Measurement "${sourceId}" must be a finite number; got ${String(rawValue)}.`,
          `${path}.value`,
          id,
        );
        continue;
      }
      if (typeof rawValue === "string") coercedNumericIds.push(id);
      /* NORMALIZATION OF UNITS: per-entry unit wins over the payload unit. */
      const entryUnit: ReferenceAngleUnit | null =
        entryUnitToken === undefined ? payloadUnit : canonicalUnit(entryUnitToken);
      if (entryUnit === null) {
        issue(
          "unknown-unit",
          `Unrecognized unit "${String(entryUnitToken ?? parsed["unit"])}" for "${sourceId}".`,
          `${path}.unit`,
          id,
        );
        continue;
      }
      const value = toDegrees(numeric, entryUnit);
      if (entryUnit !== "degrees") convertedUnits[id] = entryUnit;
      const confidence: unknown =
        rawConfidence === null || rawConfidence === undefined
          ? null
          : (canonicalNumber(rawConfidence) ?? rawConfidence);
      if (value < definition.range.min || value > definition.range.max) {
        issue(
          "invalid-measurement-value",
          `Measurement "${id}"=${value} is outside the plausible band ` +
            `${definition.range.min}..${definition.range.max} ${definition.unit}.`,
          `${path}.value`,
          id,
        );
        continue;
      }
      if (confidence !== null) {
        if (
          typeof confidence !== "number" ||
          !Number.isFinite(confidence) ||
          confidence < 0 ||
          confidence > 1
        ) {
          issue(
            "invalid-confidence",
            `Confidence for "${id}" must be null or a number in 0..1; got ${String(confidence)}.`,
            `${path}.confidence`,
            id,
          );
          continue;
        }
      }
      measurements[id] = { value, confidence };
    }
  }

  /* Metadata — populated with explicit defaults when the source is terse. */
  const metadataRaw = parsed["metadata"];
  const metadataObject =
    typeof metadataRaw === "object" && metadataRaw !== null
      ? (metadataRaw as Record<string, unknown>)
      : {};
  const provenanceRaw = metadataObject["provenance"];
  const provenance: ReferenceProvenance =
    typeof provenanceRaw === "string" && VALID_PROVENANCES.includes(provenanceRaw as ReferenceProvenance)
      ? (provenanceRaw as ReferenceProvenance)
      : "remote-source";
  const metadata: ReferenceTemplateMetadata = {
    provenance,
    /* Fidelity is DERIVED, never read from the payload: a source cannot
       promote its own category defaults to "measured" by writing a field. */
    fidelity: fidelityForProvenance(provenance),
    sourceProvider:
      typeof metadataObject["sourceProvider"] === "string"
        ? metadataObject["sourceProvider"]
        : providerId,
    ...(typeof metadataObject["capturedAt"] === "string"
      ? { capturedAt: metadataObject["capturedAt"] }
      : {}),
    landmarkGeometry: metadataObject["landmarkGeometry"] === "measured-33" ? "measured-33" : "none",
    ...(typeof metadataObject["note"] === "string" ? { note: metadataObject["note"] } : {}),
  };

  /* Failure classification — invalid beats incomplete beats incompatible. */
  const coded = (code: ReferenceValidationIssue["code"]): boolean =>
    issues.some((entry) => entry.code === code);

  if (coded("unsupported-schema-version") || coded("unsupported-measurement-version")) {
    return {
      status: ReferenceStatuses.incompatible,
      failure: incompatibleReference(
        `Reference from "${providerId}" uses version stamps this build cannot read.`,
        { providerId, details: { issues: issues.map((entry) => entry.code) } },
      ),
      issues,
    };
  }

  const structural = issues.filter((entry) => entry.code !== "below-minimum-measurements");
  if (structural.length > 0) {
    return {
      status: ReferenceStatuses.invalid,
      failure: invalidReference(
        `Reference from "${providerId}" failed validation with ${structural.length} issue(s): ` +
          `${structural[0]?.message ?? "unknown"}`,
        { providerId, details: { issues: structural.map((entry) => `${entry.path}: ${entry.code}`) } },
      ),
      issues,
    };
  }

  const availableCount = Object.keys(measurements).length;
  if (availableCount < MIN_MEASUREMENTS_FOR_COMPARISON) {
    const incompleteness: ReferenceValidationIssue = {
      code: "below-minimum-measurements",
      message:
        `Only ${availableCount} measurement(s) present; at least ` +
        `${MIN_MEASUREMENTS_FOR_COMPARISON} are required for comparison.`,
      path: "measurements",
    };
    return {
      status: ReferenceStatuses.incomplete,
      failure: incompleteReference(incompleteness.message, { providerId }),
      issues: [...issues, incompleteness],
    };
  }

  if (
    typeof parsed["templateId"] !== "string" ||
    typeof parsed["poseId"] !== "string" ||
    schemaVersion === null ||
    measurementVersion === null
  ) {
    /* Unreachable given the checks above, but keeps the success branch
       exhaustively typedWITHOUT assertions. */
    return {
      status: ReferenceStatuses.invalid,
      failure: invalidReference("Identity fields failed validation.", { providerId }),
      issues,
    };
  }

  return {
    status: ReferenceStatuses.validated,
    data: {
      templateId: parsed["templateId"],
      poseId: parsed["poseId"],
      schemaVersion,
      measurementVersion,
      measurements,
      metadata,
      normalization: Object.freeze({
        renamedIds: Object.freeze({ ...renamedIds }),
        convertedUnits: Object.freeze({ ...convertedUnits }),
        coercedNumericIds: Object.freeze([...coercedNumericIds].sort()),
      }),
    },
  };
}

/* ------------------------------------------------------------------ */
/* Stage 3 — normalize → canonical template    [status: 'normalized']  */
/* ------------------------------------------------------------------ */

export function normalizeReferencePayload(
  validated: Extract<ValidateStageResult, { status: typeof ReferenceStatuses.validated }>["data"],
): ReferencePoseTemplate {
  /* Canonical key order (stable hashing, stable iteration) without touching
     any value: normalization restructures, it never rewrites numbers. */
  const sortedIds = Object.keys(validated.measurements).sort();
  const measurements: Record<string, ReferenceMeasurementValue> = {};
  for (const id of sortedIds) {
    const entry = validated.measurements[id];
    if (entry === undefined) continue;
    measurements[id] = Object.freeze({ value: entry.value, confidence: entry.confidence });
  }

  /* Validation has already rejected unknown ids, so every key is registered;
     the filter is a defensive no-op keeping types honest. */
  const registered = sortedIds.filter((id) => getMeasurementDefinition(id) !== undefined);
  const missingIds = ALL_REGISTERED_IDS.filter((id) => !sortedIds.includes(id)).sort();
  const frozenMeasurements = Object.freeze(measurements);

  const template: ReferencePoseTemplate = {
    templateId: validated.templateId,
    poseId: validated.poseId,
    schemaVersion: validated.schemaVersion,
    measurementVersion: validated.measurementVersion,
    measurements: frozenMeasurements,
    availability: Object.freeze({
      availableIds: Object.freeze([...registered]),
      missingIds: Object.freeze(missingIds),
      availableCount: registered.length,
      missingEngineEligibleIds: Object.freeze(
        ENGINE_ELIGIBLE_IDS.filter((id) => !sortedIds.includes(id)),
      ),
      /* PARTIAL TEMPLATES ARE FIRST CLASS: stated as a fact, never patched
         up. `completeness` is diagnostics only — no consumer may derive a
         missing measurement from it. */
      isPartial: missingIds.length > 0,
      completeness:
        ALL_REGISTERED_IDS.length === 0
          ? 0
          : registered.length / ALL_REGISTERED_IDS.length,
    }),
    metadata: Object.freeze({ ...validated.metadata }),
    normalization: Object.freeze({
      renamedIds: Object.freeze({ ...validated.normalization.renamedIds }),
      convertedUnits: Object.freeze({ ...validated.normalization.convertedUnits }),
      coercedNumericIds: Object.freeze([...validated.normalization.coercedNumericIds]),
    }),
    contentHash: referenceContentHash(
      contentHashInput(validated.schemaVersion, validated.measurementVersion, frozenMeasurements),
    ),
  };
  return Object.freeze(template);
}

/* Registry snapshots for availability computation — captured from the
   measurement module so normalization stays pure (no mutation leaks). */
const ALL_REGISTERED_IDS: readonly string[] = knownMeasurementIds();
const ENGINE_ELIGIBLE_IDS: readonly string[] = MEASUREMENT_DEFINITIONS.filter(
  (definition) => definition.engineEligible,
).map((definition) => definition.id);

/* ------------------------------------------------------------------ */
/* Composed convenience — the call providers make.                     */
/* ------------------------------------------------------------------ */

export type BuildReferenceResult =
  | { readonly status: typeof ReferenceStatuses.ready; readonly template: ReferencePoseTemplate }
  | {
      readonly status:
        | typeof ReferenceStatuses.invalid
        | typeof ReferenceStatuses.incomplete
        | typeof ReferenceStatuses.incompatible;
      readonly failure: ReferenceFailure;
      readonly issues?: readonly ReferenceValidationIssue[];
    };

export function buildReferenceTemplate(raw: RawReferencePayload): BuildReferenceResult {
  const parsed = parseReferencePayload(raw);
  if (parsed.status !== ReferenceStatuses.loaded) {
    return { status: parsed.status, failure: parsed.failure };
  }
  const validated = validateReferencePayload(parsed.data, raw.providerId);
  if (validated.status !== ReferenceStatuses.validated) {
    return { status: validated.status, failure: validated.failure, issues: validated.issues };
  }
  const template = normalizeReferencePayload(validated.data);
  return { status: ReferenceStatuses.ready, template };
}

/** Plausibility band re-exported for adapters producing candidate values. */
export { MEASUREMENT_PLAUSIBLE_RANGE_DEGREES };
