/**
 * shared/reference/provider.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE PROVIDER ABSTRACTION.
 *
 * A ReferenceProvider answers one question: "do you have a usable reference
 * pose template for catalog pose X?" Providers own IO and source quirks;
 * they MUST route whatever they fetch through the parse/validate/normalize
 * pipeline and answer with a ReferenceResolution — never with raw rows,
 * never by throwing for expected failure conditions.
 *
 * Architecture position:
 *
 *     REFERENCE SOURCE (bundled catalog today; local files, Supabase,
 *                       API, test fixtures tomorrow)
 *        └─ REFERENCE PROVIDER (this interface — outside the math engine)
 *              └─ ENGINE  →  SEMANTIC COACHING  →  existing language/TTS
 *
 * Adding a provider (local/Supabase/API/test) = implement this interface in
 * its own module. The interface deliberately knows nothing about any
 * concrete backend: no Supabase types, no fetch, no storage SDK.
 */
import type { ReferenceFailure } from "./failure";
import { ReferenceStatuses } from "./status";
import type { ReferencePoseTemplate } from "./template";

/** Identity of one resolution request. */
export interface ReferenceRequest {
  /** Catalog pose id the caller wants a reference for. */
  readonly poseId: string;
}

/**
 * The terminal answers a provider can give:
 *   ready        → template is validated, normalized, engine-safe
 *   unavailable  → source reachable/configured, has nothing for this pose
 *   invalid      → payload failed validation
 *   incomplete   → valid but below MIN_MEASUREMENTS_FOR_COMPARISON
 *   incompatible → version stamps this build cannot read
 */
export type ReferenceResolution =
  | {
      readonly status: typeof ReferenceStatuses.ready;
      readonly template: ReferencePoseTemplate;
    }
  | {
      readonly status:
        | typeof ReferenceStatuses.unavailable
        | typeof ReferenceStatuses.invalid
        | typeof ReferenceStatuses.incomplete
        | typeof ReferenceStatuses.incompatible;
      readonly failure: ReferenceFailure;
    };

/**
 * What a provider reports about its own configuration. 'not-configured' is
 * the honest answer of a backend whose credentials/env are absent (the demo
 * fallback pattern this repo already uses for auth); 'source-available' is a
 * provider that is configured and reachable. Probe-level, pose-independent.
 */
export type ReferenceSourceState =
  | {
      readonly status: typeof ReferenceStatuses.notConfigured | typeof ReferenceStatuses.sourceAvailable;
      readonly providerId: string;
      /** Human-readable one-liner for diagnostics screens. */
      readonly detail: string;
    };

export interface ReferenceProvider {
  /** Stable provider id (e.g. "bundled-catalog", "memory", "unconfigured"). */
  readonly id: string;
  /** Pose-independent source state probe. */
  describeSource(): ReferenceSourceState;
  /** Resolve one pose's reference template. Never throws for bad data. */
  getReference(request: ReferenceRequest): Promise<ReferenceResolution>;
}

/** Narrowing helpers — the two-line idiom every consumer needs. */
export function isReadyResolution(
  resolution: ReferenceResolution,
): resolution is Extract<ReferenceResolution, { status: typeof ReferenceStatuses.ready }> {
  return resolution.status === ReferenceStatuses.ready;
}

export function resolutionFailure(
  resolution: ReferenceResolution,
): ReferenceFailure | null {
  return resolution.status === ReferenceStatuses.ready ? null : resolution.failure;
}
