/**
 * shared/reference/providers/catalog.ts — Reference-pose foundation.
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE BUNDLED-CATALOG PROVIDER — the local reference source wired to today's
 * production data path.
 *
 * SOURCE (Pose entity) ─▶ ADAPTER (poseReferenceAdapter) ─▶ RAW PAYLOAD
 *   ─▶ validate ─▶ normalize ─▶ ReferencePoseTemplate
 *
 * HONESTY CONTRACT (load-bearing, do not remove):
 *   · provenance is 'bundled-category-default' and confidence is null — these
 *     are hand-authored CATEGORY stances, not measurements of a pose.
 *   · fidelity is therefore 'category-approximate', and the provider REQUIRES
 *     the caller to state a `ReferenceFidelityPolicy`. There is no default.
 *     Under 'measured-only' this provider answers `approximate-only`; it does
 *     not quietly hand approximate numbers to the coaching engine.
 *   · a pose with no reference angles resolves `unavailable`. It NEVER falls
 *     back to another pose, a demo template, a fixture or a category mean.
 *   · this file MUST NOT be extended with invented angles.
 */
import { getPoseById } from "../../data/poseCatalog";
import type { Pose } from "../../types";
import type { ReferenceSourceAdapter } from "../adapter";
import { approximateOnly, referenceUnavailable, providerFailure } from "../failure";
import {
  fidelityForProvenance,
  fidelitySatisfiesPolicy,
  type ReferenceFidelityPolicy,
} from "../fidelity";
import { buildReferenceTemplate, type RawReferencePayload } from "../pipeline";
import type {
  ReferenceProvider,
  ReferenceRequest,
  ReferenceResolution,
  ReferenceSourceState,
} from "../provider";
import { ReferenceStatuses } from "../status";
import {
  MEASUREMENT_VERSION,
  REFERENCE_TEMPLATE_SCHEMA_VERSION,
  referenceVersionStamp,
} from "../versions";

export const CATALOG_REFERENCE_PROVIDER_ID = "bundled-catalog";

/** Provenance every payload from this source carries. */
const CATALOG_PROVENANCE = "bundled-category-default" as const;

/**
 * ADAPTER: Pose entity → RAW reference payload. Pure shape translation; no
 * validation, no repair, no IO. Bare degrees become { value, confidence: null }
 * because the source makes no confidence claim and inventing 1.0 would be a
 * lie about hand-authored data.
 */
export const poseReferenceAdapter: ReferenceSourceAdapter<Pose> = {
  id: "pose-entity-adapter",
  toRawPayload(pose: Pose): RawReferencePayload {
    const angles = pose.referenceAngles ?? {};
    const measurements: Record<string, { value: number; confidence: number | null }> = {};
    for (const [id, degrees] of Object.entries(angles)) {
      if (typeof degrees !== "number") continue;
      measurements[id] = { value: degrees, confidence: null };
    }
    const hasMeasuredGeometry =
      Array.isArray(pose.referenceLandmarks) && pose.referenceLandmarks.length === 33;
    return {
      providerId: CATALOG_REFERENCE_PROVIDER_ID,
      payload: {
        templateId: `${CATALOG_REFERENCE_PROVIDER_ID}/${pose.id}-${referenceVersionStamp(
          REFERENCE_TEMPLATE_SCHEMA_VERSION,
          MEASUREMENT_VERSION,
        )}`,
        poseId: pose.id,
        schemaVersion: REFERENCE_TEMPLATE_SCHEMA_VERSION,
        measurementVersion: MEASUREMENT_VERSION,
        unit: "degrees",
        measurements,
        metadata: {
          provenance: CATALOG_PROVENANCE,
          sourceProvider: CATALOG_REFERENCE_PROVIDER_ID,
          landmarkGeometry: hasMeasuredGeometry ? "measured-33" : "none",
          note:
            "Hand-authored category signature stance; approximate, not a " +
            "measurement of this pose.",
        },
      },
    };
  },
};

/** Kept for call sites that only want the raw envelope. */
export function rawPayloadFromPose(pose: Pose): RawReferencePayload {
  return poseReferenceAdapter.toRawPayload(pose);
}

export interface CatalogProviderOptions {
  /**
   * REQUIRED. Stating it at the wiring point is the whole safeguard: a
   * default would let approximate data drift into production unnoticed.
   */
  readonly fidelityPolicy: ReferenceFidelityPolicy;
}

/**
 * The provider the app uses today. Bundled data ⇒ the source is always
 * 'source-available'; a pose may still resolve 'unavailable'.
 */
export function createCatalogReferenceProvider(
  options: CatalogProviderOptions,
): ReferenceProvider {
  const { fidelityPolicy } = options;
  const sourceFidelity = fidelityForProvenance(CATALOG_PROVENANCE);

  return {
    id: CATALOG_REFERENCE_PROVIDER_ID,
    describeSource(): ReferenceSourceState {
      return {
        status: ReferenceStatuses.sourceAvailable,
        providerId: CATALOG_REFERENCE_PROVIDER_ID,
        detail:
          `Bundled 400-pose catalog; ${sourceFidelity} fidelity ` +
          `(hand-authored category stances), policy=${fidelityPolicy}.`,
      };
    },
    getReference(request: ReferenceRequest): Promise<ReferenceResolution> {
      /* Policy gate BEFORE any data work: under measured-only this source has
         nothing to offer, and saying so costs nothing and hides nothing. */
      if (!fidelitySatisfiesPolicy(sourceFidelity, fidelityPolicy)) {
        return Promise.resolve({
          status: ReferenceStatuses.unavailable,
          failure: approximateOnly(
            `The bundled catalog holds ${sourceFidelity} data only; the ` +
              `caller requires measured references, so pose "${request.poseId}" ` +
              `has no usable reference.`,
            {
              providerId: CATALOG_REFERENCE_PROVIDER_ID,
              details: { fidelity: sourceFidelity, policy: fidelityPolicy },
            },
          ),
        });
      }
      const pose = getPoseById(request.poseId);
      if (pose === null) {
        return Promise.resolve({
          status: ReferenceStatuses.unavailable,
          failure: referenceUnavailable(
            `Pose "${request.poseId}" does not exist in the bundled catalog.`,
            { providerId: CATALOG_REFERENCE_PROVIDER_ID },
          ),
        });
      }
      if (pose.referenceAngles === null || Object.keys(pose.referenceAngles).length === 0) {
        return Promise.resolve({
          status: ReferenceStatuses.unavailable,
          failure: referenceUnavailable(
            `Pose "${request.poseId}" ships no reference measurements.`,
            { providerId: CATALOG_REFERENCE_PROVIDER_ID },
          ),
        });
      }
      try {
        const built = buildReferenceTemplate(poseReferenceAdapter.toRawPayload(pose));
        if (built.status === ReferenceStatuses.ready) {
          return Promise.resolve({ status: ReferenceStatuses.ready, template: built.template });
        }
        return Promise.resolve({ status: built.status, failure: built.failure });
      } catch (error) {
        /* The pipeline never throws for bad data, so an exception here is a
           genuine defect — surfaced as provider-failure, never swallowed. */
        return Promise.resolve({
          status: ReferenceStatuses.invalid,
          failure: providerFailure(
            `Catalog adapter crashed for pose "${request.poseId}": ${
              error instanceof Error ? error.message : String(error)
            }`,
            { providerId: CATALOG_REFERENCE_PROVIDER_ID },
          ),
        });
      }
    },
  };
}
