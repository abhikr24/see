/**
 * shared/reference/providers/memory.ts — Reference-pose foundation (Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE IN-MEMORY PROVIDER — a local source seeded with raw payloads.
 * Used by deterministic unit tests and by any future local-file source:
 * the owner supplies RAW payloads (this provider deliberately contains NO
 * data of its own — it ships zero fixtures, synthetic or otherwise), and
 * every payload still passes the full pipeline, so bad seed data surfaces
 * the same structured failures a remote source would.
 */
import { referenceUnavailable } from "../failure";
import { buildReferenceTemplate } from "../pipeline";
import type {
  ReferenceProvider,
  ReferenceRequest,
  ReferenceResolution,
  ReferenceSourceState,
} from "../provider";
import { ReferenceStatuses } from "../status";

export interface MemoryProviderSeed {
  /** Pose id this payload claims to describe. */
  readonly poseId: string;
  /** Raw payload (object or JSON string) — validated on every resolve. */
  readonly payload: unknown;
}

export function createMemoryReferenceProvider(
  seeds: readonly MemoryProviderSeed[],
  providerId: string = "memory",
): ReferenceProvider {
  const byPoseId = new Map<string, unknown>(seeds.map((seed) => [seed.poseId, seed.payload]));
  return {
    id: providerId,
    describeSource(): ReferenceSourceState {
      return {
        status: ReferenceStatuses.sourceAvailable,
        providerId,
        detail: `In-memory provider with ${byPoseId.size} seeded payload(s).`,
      };
    },
    getReference(request: ReferenceRequest): Promise<ReferenceResolution> {
      const payload = byPoseId.get(request.poseId);
      if (payload === undefined) {
        return Promise.resolve({
          status: ReferenceStatuses.unavailable,
          failure: referenceUnavailable(
            `No seeded reference for pose "${request.poseId}".`,
            { providerId },
          ),
        });
      }
      const built = buildReferenceTemplate({ providerId, payload });
      if (built.status === ReferenceStatuses.ready) {
        return Promise.resolve({ status: ReferenceStatuses.ready, template: built.template });
      }
      return Promise.resolve({ status: built.status, failure: built.failure });
    },
  };
}
