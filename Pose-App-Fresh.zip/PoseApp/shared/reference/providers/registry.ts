/**
 * shared/reference/providers/registry.ts — Reference-pose foundation.
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE PROVIDER BOUNDARY, STATED IN ONE PLACE.
 *
 * The architecture recognises four provider kinds. Recognising a kind is NOT
 * the same as shipping one — this registry is explicit about which kinds are
 * implemented today and which are declared-but-unimplemented, and it refuses
 * to invent the missing ones:
 *
 *   local     · IMPLEMENTED — bundled catalog (providers/catalog.ts) and
 *               seeded payloads (providers/memory.ts)
 *   test      · IMPLEMENTED — memory provider under a test-only id; the
 *               registry REFUSES to build it unless the caller passes
 *               `allowTestProviderInProduction: false`-style explicit intent
 *               (see createTestReferenceProvider's contract)
 *   supabase  · DECLARED ONLY — no client, no table names, no credentials,
 *               no column guesses. Resolving this kind yields a
 *               not-configured provider until a real integration supplies a
 *               transport via createRemoteReferenceProvider.
 *   api       · DECLARED ONLY — same rule.
 *
 * WHY NOT STUB SUPABASE ANYWAY: a stub that returns plausible data is
 * indistinguishable from a working integration at the call site, and that is
 * precisely how fake production data gets shipped. A not-configured provider
 * is loud, typed and harmless.
 */
import type { ReferenceProvider } from "../provider";
import type { ReferenceFidelityPolicy } from "../fidelity";
import { createCatalogReferenceProvider } from "./catalog";
import { createUnavailableReferenceProvider } from "./unavailable";

export type ReferenceProviderKind = "local" | "supabase" | "api" | "test";

export interface ProviderKindDescription {
  readonly kind: ReferenceProviderKind;
  /** True when this build can actually construct a working provider. */
  readonly implemented: boolean;
  /** Why, in one line — surfaced by diagnostics screens. */
  readonly detail: string;
}

export const PROVIDER_KIND_DESCRIPTIONS: readonly ProviderKindDescription[] = Object.freeze([
  Object.freeze({
    kind: "local" as const,
    implemented: true,
    detail: "Bundled catalog + seeded payload sources (no IO, always offline-safe).",
  }),
  Object.freeze({
    kind: "test" as const,
    implemented: true,
    detail: "Deterministic fixtures supplied by the caller; test trees only.",
  }),
  Object.freeze({
    kind: "supabase" as const,
    implemented: false,
    detail:
      "Declared, not implemented. No table, column or credential is assumed. " +
      "Land it with createRemoteReferenceProvider + createRecordAdapter.",
  }),
  Object.freeze({
    kind: "api" as const,
    implemented: false,
    detail:
      "Declared, not implemented. Land it with createRemoteReferenceProvider " +
      "+ createRecordAdapter once an endpoint contract exists.",
  }),
]);

export function describeProviderKind(
  kind: ReferenceProviderKind,
): ProviderKindDescription {
  const found = PROVIDER_KIND_DESCRIPTIONS.find((entry) => entry.kind === kind);
  /* The list is exhaustive over the union; the fallback keeps the function
     total without an assertion. */
  return (
    found ?? {
      kind,
      implemented: false,
      detail: "Unknown provider kind.",
    }
  );
}

export interface ReferenceProviderSelection {
  readonly kind: ReferenceProviderKind;
  /** REQUIRED for every kind — see fidelity.ts. */
  readonly fidelityPolicy: ReferenceFidelityPolicy;
}

/**
 * Construct the provider for a selected kind. Unimplemented kinds return the
 * not-configured provider: an explicit unavailable state, never a substitute
 * source. `test` is intentionally NOT constructible here — tests build their
 * own provider from their own fixtures, which keeps fixtures out of every
 * production import graph.
 */
export function createReferenceProviderForKind(
  selection: ReferenceProviderSelection,
): ReferenceProvider {
  switch (selection.kind) {
    case "local":
      return createCatalogReferenceProvider({
        fidelityPolicy: selection.fidelityPolicy,
      });
    case "supabase":
    case "api":
      return createUnavailableReferenceProvider(
        describeProviderKind(selection.kind).detail,
        `${selection.kind}-not-configured`,
      );
    case "test":
      return createUnavailableReferenceProvider(
        "Test providers are constructed inside tests/, never by production wiring.",
        "test-not-available-in-production",
      );
    default: {
      const exhaustive: never = selection.kind;
      return createUnavailableReferenceProvider(
        `Unknown provider kind "${String(exhaustive)}".`,
        "unknown-kind",
      );
    }
  }
}
