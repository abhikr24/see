/**
 * shared/reference/providers/remote.ts — Reference-pose foundation.
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE REMOTE PROVIDER SEAM — a complete provider with the transport removed.
 *
 * This is deliberately NOT a Supabase client, NOT an HTTP client, and NOT a
 * guess at anybody's schema. It is the generic half of a remote integration:
 * everything that can be written correctly *before* a real backend exists.
 * The caller injects the two things only they can know:
 *
 *   1. `fetchRecord(poseId)` — how to get a record (Supabase query, REST
 *      call, file read). It returns a plain record, `null` for "no row", or
 *      a ReferenceFailure for a transport problem it already classified.
 *   2. `adapter` — how that record's field names map onto the raw envelope
 *      (`createRecordAdapter` from ../adapter).
 *
 * Everything after that is already built and shared with every other source:
 * validate → normalize → ReferencePoseTemplate. That is the whole point of
 * the architecture — landing real Supabase later is configuration plus a
 * query, not a rewrite of maths, matching, coaching or temporal logic.
 *
 * FAILURE HANDLING: a thrown transport error becomes `provider-failure`
 * (retryable), never an empty template and never a fallback to another
 * source. Timeouts are enforced here only if the caller supplies a deadline;
 * this module starts no timers of its own.
 */
import type { ReferenceSourceAdapter, SourceRecord } from "../adapter";
import {
  approximateOnly,
  isReferenceFailure,
  providerFailure,
  referenceUnavailable,
  type ReferenceFailure,
} from "../failure";
import {
  fidelitySatisfiesPolicy,
  type ReferenceFidelityPolicy,
} from "../fidelity";
import { buildReferenceTemplate } from "../pipeline";
import type {
  ReferenceProvider,
  ReferenceRequest,
  ReferenceResolution,
  ReferenceSourceState,
} from "../provider";
import { ReferenceStatuses } from "../status";

/**
 * What a transport returns for one pose:
 *   SourceRecord    · a record was found
 *   null            · the source is reachable and has nothing for this pose
 *   ReferenceFailure· the transport already classified a problem
 */
export type RemoteFetchResult = SourceRecord | null | ReferenceFailure;

export interface RemoteProviderConfig {
  readonly providerId: string;
  /** Adapter mapping this source's record shape onto the raw envelope. */
  readonly adapter: ReferenceSourceAdapter<SourceRecord>;
  /** Injected transport. The domain never opens a socket itself. */
  readonly fetchRecord: (poseId: string) => Promise<RemoteFetchResult>;
  /** REQUIRED — see fidelity.ts; no implicit default anywhere. */
  readonly fidelityPolicy: ReferenceFidelityPolicy;
  /** One-line description for diagnostics screens. */
  readonly detail: string;
}

export function createRemoteReferenceProvider(
  config: RemoteProviderConfig,
): ReferenceProvider {
  const { providerId, adapter, fetchRecord, fidelityPolicy, detail } = config;
  return {
    id: providerId,
    describeSource(): ReferenceSourceState {
      return {
        status: ReferenceStatuses.sourceAvailable,
        providerId,
        detail,
      };
    },
    async getReference(request: ReferenceRequest): Promise<ReferenceResolution> {
      let record: RemoteFetchResult;
      try {
        record = await fetchRecord(request.poseId);
      } catch (error) {
        return {
          status: ReferenceStatuses.unavailable,
          failure: providerFailure(
            `Reference transport for "${providerId}" threw while fetching ` +
              `"${request.poseId}": ${error instanceof Error ? error.message : String(error)}`,
            { providerId },
          ),
        };
      }
      if (record === null || record === undefined) {
        return {
          status: ReferenceStatuses.unavailable,
          failure: referenceUnavailable(
            `Source "${providerId}" holds no reference for pose "${request.poseId}".`,
            { providerId },
          ),
        };
      }
      if (isReferenceFailure(record)) {
        /* The transport classified it (timeout/network/unauthorized): pass it
           through verbatim. Reclassifying would destroy information. */
        return { status: ReferenceStatuses.unavailable, failure: record };
      }
      const built = buildReferenceTemplate(adapter.toRawPayload(record));
      if (built.status !== ReferenceStatuses.ready) {
        return { status: built.status, failure: built.failure };
      }
      /* Fidelity gate AFTER validation: only a validated template can be
         trusted to state its own provenance. */
      const fidelity = built.template.metadata.fidelity;
      if (!fidelitySatisfiesPolicy(fidelity, fidelityPolicy)) {
        return {
          status: ReferenceStatuses.unavailable,
          failure: approximateOnly(
            `Source "${providerId}" returned ${fidelity} data for pose ` +
              `"${request.poseId}" but the caller requires measured references.`,
            { providerId, details: { fidelity, policy: fidelityPolicy } },
          ),
        };
      }
      /* A record that describes a different pose is a source bug, not a
         reference: refuse rather than coach against the wrong pose. */
      if (built.template.poseId !== request.poseId) {
        return {
          status: ReferenceStatuses.invalid,
          failure: providerFailure(
            `Source "${providerId}" returned a template for pose ` +
              `"${built.template.poseId}" when "${request.poseId}" was requested.`,
            { providerId },
          ),
        };
      }
      return { status: ReferenceStatuses.ready, template: built.template };
    },
  };
}
