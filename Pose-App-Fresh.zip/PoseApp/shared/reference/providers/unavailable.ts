/**
 * shared/reference/providers/unavailable.ts — Reference foundation (Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE NOT-CONFIGURED PROVIDER — the honest stand-in for a source that was
 * never set up (missing env, feature not wired yet, placeholder for a future
 * remote backend). It answers 'not-configured' at the source level and
 * 'unavailable' at the pose level. This is the shape future Supabase/API
 * providers must fall back to when their credentials are absent — mirroring
 * the repo's existing demo-mode invariant for auth.
 */
import { referenceUnavailable } from "../failure";
import type {
  ReferenceProvider,
  ReferenceRequest,
  ReferenceResolution,
  ReferenceSourceState,
} from "../provider";
import { ReferenceStatuses } from "../status";

export function createUnavailableReferenceProvider(
  reason: string,
  providerId: string = "unconfigured",
): ReferenceProvider {
  return {
    id: providerId,
    describeSource(): ReferenceSourceState {
      return {
        status: ReferenceStatuses.notConfigured,
        providerId,
        detail: reason,
      };
    },
    getReference(request: ReferenceRequest): Promise<ReferenceResolution> {
      return Promise.resolve({
        status: ReferenceStatuses.unavailable,
        failure: referenceUnavailable(
          `Reference source "${providerId}" is not configured (${reason}); ` +
            `pose "${request.poseId}" cannot be resolved.`,
          { providerId },
        ),
      });
    },
  };
}
