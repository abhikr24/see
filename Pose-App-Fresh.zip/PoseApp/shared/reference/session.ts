/**
 * shared/reference/session.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE SESSION PIN.
 *
 * The domain rule: once an analysis session selects a validated reference
 * template, THAT template — identity and versions included — cannot silently
 * change for the rest of the session. A wobble in measurement semantics
 * mid-session would make match-% series incomparable frame to frame.
 *
 * Mechanism: `pinReferenceForSession` captures a frozen identity snapshot
 * (templateId + both versions + contentHash) alongside the frozen template.
 * The session carries the pin, not a promise of "the latest data". When a
 * provider re-resolves mid-session (refresh, reconnect), `compareWithPin`
 * states IN DATA whether the new artifact is the same reference, a benign
 * re-fetch, or an actual change — and `assertPinnedResolution` returns a
 * structured failure instead of letting stale/incompatible data slip in.
 */
import {
  incompatibleReference,
  staleReferenceData,
  type ReferenceFailure,
} from "./failure";
import type { ReferenceResolution } from "./provider";
import type { ReferencePoseTemplate } from "./template";
import { ReferenceStatuses } from "./status";

/** Immutable identity snapshot of one pinned template. */
export interface PinnedReferenceIdentity {
  readonly templateId: string;
  readonly poseId: string;
  readonly schemaVersion: number;
  readonly measurementVersion: number;
  readonly contentHash: string;
}

export interface PinnedReference {
  /** Opaque session-scoped token, chosen by the caller. */
  readonly sessionToken: string;
  readonly identity: PinnedReferenceIdentity;
  /** The frozen template itself — the exact artifact engines may consume. */
  readonly template: ReferencePoseTemplate;
  /** Epoch ms when the pin was created. */
  readonly pinnedAtMs: number;
}

/** Extract the identity snapshot of any template. */
export function referenceIdentityOf(
  template: ReferencePoseTemplate,
): PinnedReferenceIdentity {
  return Object.freeze({
    templateId: template.templateId,
    poseId: template.poseId,
    schemaVersion: template.schemaVersion,
    measurementVersion: template.measurementVersion,
    contentHash: template.contentHash,
  });
}

/**
 * Pin a ready resolution for a session. Throws NEVER; the caller passes a
 * ready resolution (guarded upstream), and this function freezes the
 * identity so later code cannot retrofit a different template into it.
 */
export function pinReferenceForSession(
  template: ReferencePoseTemplate,
  sessionToken: string,
  pinnedAtMs: number,
): PinnedReference {
  return Object.freeze({
    sessionToken,
    identity: referenceIdentityOf(template),
    template,
    pinnedAtMs,
  });
}

/** Three-way comparison between the pin and a freshly resolved template. */
export type PinComparison =
  | { readonly relation: "identical" }
  | { readonly relation: "same-id-different-content" }
  | { readonly relation: "different-template" };

export function compareWithPin(
  pin: PinnedReference,
  candidate: ReferencePoseTemplate,
): PinComparison {
  const identity = referenceIdentityOf(candidate);
  if (
    identity.templateId === pin.identity.templateId &&
    identity.poseId === pin.identity.poseId &&
    identity.schemaVersion === pin.identity.schemaVersion &&
    identity.measurementVersion === pin.identity.measurementVersion &&
    identity.contentHash === pin.identity.contentHash
  ) {
    return { relation: "identical" };
  }
  if (identity.templateId === pin.identity.templateId) {
    return { relation: "same-id-different-content" };
  }
  return { relation: "different-template" };
}

export type PinnedResolutionCheck =
  | { readonly ok: true; readonly relation: PinComparison["relation"] }
  | { readonly ok: false; readonly failure: ReferenceFailure };

/**
 * Verify a fresh mid-session resolution against the pin. 'identical' passes;
 * content drift under the same id is reported as stale data; a different
 * template id or version stamp is incompatible with the session. Callers
 * decide policy (ignore the refresh, end the session) — this layer supplies
 * facts, not behavior.
 */
export function assertPinnedResolution(
  pin: PinnedReference,
  resolution: ReferenceResolution,
): PinnedResolutionCheck {
  if (resolution.status !== ReferenceStatuses.ready) {
    return {
      ok: false,
      failure: resolution.failure,
    };
  }
  const comparison = compareWithPin(pin, resolution.template);
  if (comparison.relation === "identical") {
    return { ok: true, relation: "identical" };
  }
  if (comparison.relation === "same-id-different-content") {
    return {
      ok: false,
      failure: staleReferenceData(
        `Template "${pin.identity.templateId}" changed content mid-session ` +
          `(hash ${pin.identity.contentHash} → ${resolution.template.contentHash}).`,
        { details: { sessionToken: pin.sessionToken } },
      ),
    };
  }
  return {
    ok: false,
    failure: incompatibleReference(
      `Session pinned template "${pin.identity.templateId}" but resolution ` +
        `offered "${resolution.template.templateId}" — the session keeps its pin.`,
      { details: { sessionToken: pin.sessionToken } },
    ),
  };
}
