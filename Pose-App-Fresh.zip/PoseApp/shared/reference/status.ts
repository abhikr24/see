/**
 * shared/reference/status.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * REFERENCE LIFECYCLE STATUSES.
 *
 * The architecture distinguishes every meaningful state of a reference —
 * nothing collapses into null/undefined where a cause matters:
 *
 *   PIPELINE STAGES (a payload moves through these, in order):
 *     loaded      · raw bytes/payload obtained from a source, shape parsed
 *     validated   · structure, versions, values checked against the registry
 *     normalized  · canonical key order + frozen structures + identity/hash
 *     ready       · a fully validated, normalized template, safe for engines
 *
 *   SOURCE STATES (what a provider reports about itself/its data):
 *     not-configured    · no source configured (e.g. env unset, pose has no
 *                         reference data at all)
 *     source-available  · a source exists and claims to have data
 *     unavailable       · source reachable but has no reference for this pose
 *
 *   TERMINAL FAILURE STATES (each maps 1:1 to a ReferenceFailureKind class):
 *     invalid      · malformed structure/values
 *     incomplete   · valid but below MIN_MEASUREMENTS_FOR_COMPARISON
 *     incompatible · version stamp this build cannot read
 */
export const ReferenceStatuses = {
  loaded: "loaded",
  validated: "validated",
  normalized: "normalized",
  ready: "ready",
  notConfigured: "not-configured",
  sourceAvailable: "source-available",
  unavailable: "unavailable",
  invalid: "invalid",
  incomplete: "incomplete",
  incompatible: "incompatible",
} as const;

export type ReferenceTemplateStatus =
  (typeof ReferenceStatuses)[keyof typeof ReferenceStatuses];

/** Statuses that mean "a usable canonical template exists". */
export const READY_STATUS: ReferenceTemplateStatus = ReferenceStatuses.ready;

export function isReadyStatus(
  status: ReferenceTemplateStatus,
): status is typeof ReferenceStatuses.ready {
  return status === ReferenceStatuses.ready;
}
