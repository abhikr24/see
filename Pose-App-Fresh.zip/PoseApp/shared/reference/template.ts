/**
 * shared/reference/template.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * THE CANONICAL DOMAIN MODEL: ReferencePoseTemplate.
 *
 * This is the ONE authoritative representation of a validated reference pose.
 * It is the only shape the mathematical engine side of the boundary is
 * allowed to reason about: engines never see database rows, Supabase
 * responses, raw API JSON or storage objects — only this, produced by the
 * parse → validate → normalize pipeline.
 *
 * Properties:
 *   · versioned twice (schema + measurement semantics)
 *   · explicit about WHICH measurements exist — nothing is invented for
 *     missing ids, and consumers read `availability`, never assume
 *   · content-hashed so a session can detect a silent swap of the "same"
 *     template id
 *   · deeply frozen — a template cannot be mutated after construction
 */
import {
  referenceVersionStamp,
  SUPPORTED_MEASUREMENT_VERSIONS,
} from "./versions";
import { incompatibleReference, type ReferenceFailure } from "./failure";
import type { NormalizationRecord } from "./canonical";
import type { ReferenceFidelity } from "./fidelity";

export type { ReferenceFailure } from "./failure";

/**
 * One measurement value. `confidence` (0..1) is the producer's belief in the
 * value; null means "no confidence claim" — hand-authored defaults honestly
 * report null rather than fabricating 1.0.
 */
export interface ReferenceMeasurementValue {
  readonly value: number;
  readonly confidence: number | null;
}

/**
 * Where the numbers came from. Provenance is part of the contract because
 * downstream behavior (and trust) differs by origin:
 *   bundled-category-default · hand-authored category stance from
 *                              shared/data/referenceAngles.ts — the current
 *                              production source; NOT measured data
 *   measured-scan            · captured by a template scanner from real
 *                              reference photography (future Unit)
 *   remote-source            · delivered by a remote provider (future)
 *   test-fixture             · synthetic — tests only, never shipped data
 */
export type ReferenceProvenance =
  | "bundled-category-default"
  | "measured-scan"
  | "remote-source"
  | "test-fixture";

export interface ReferenceTemplateMetadata {
  readonly provenance: ReferenceProvenance;
  /**
   * How real the numbers are — 'measured' (observed for THIS pose) vs
   * 'category-approximate' (a hand-authored stance typical of the pose's
   * category). Derived from provenance by the single mapping in
   * fidelity.ts; a source cannot self-declare a fidelity it has not earned.
   * Consumers that coach off approximate data must disclose it.
   */
  readonly fidelity: ReferenceFidelity;
  /** Provider id that produced this template (e.g. "bundled-catalog"). */
  readonly sourceProvider: string;
  /** ISO timestamp of capture/authorship, when the source reports one. */
  readonly capturedAt?: string;
  /**
   * Whether measured 33-landmark reference geometry accompanies the numbers
   * (silhouette tier-2 input, shared/ml/poseSilhouette.ts). Declared here so
   * render layers can query facts instead of probing payload internals.
   */
  readonly landmarkGeometry: "measured-33" | "none";
  /** Free-form note from the producer, diagnostics only. */
  readonly note?: string;
}

/**
 * Which measurements this template ACTUALLY carries. Missing ids are data
 * the source does not have — consumers must check membership before reading
 * `measurements[id]`, and must never substitute plausible-looking defaults.
 */
export interface ReferenceMeasurementAvailability {
  /** Ids present in `measurements`, sorted ascending (canonical order). */
  readonly availableIds: readonly string[];
  /** Registered ids this template does not carry, sorted ascending. */
  readonly missingIds: readonly string[];
  /** Count of available measurements. */
  readonly availableCount: number;
  /** Registered ids the match engine consumes that are missing here. */
  readonly missingEngineEligibleIds: readonly string[];
  /**
   * TRUE when the template carries fewer than every registered measurement.
   * A partial template is a first-class, usable artifact — it is NOT an
   * error — but it must announce itself so no consumer mistakes
   * "measurement absent" for "measurement equals something".
   */
  readonly isPartial: boolean;
  /**
   * availableCount / registered-measurement-count, exact ratio in 0..1.
   * Reported for diagnostics and UI disclosure only; NOTHING in the engine
   * derives a value from it, and it never substitutes for a missing entry.
   */
  readonly completeness: number;
}

export interface ReferencePoseTemplate {
  /** Stable id for THIS template artifact (source-namespaced). */
  readonly templateId: string;
  /** Catalog pose this reference describes. */
  readonly poseId: string;
  /** Schema version of this structure — see versions.ts. */
  readonly schemaVersion: number;
  /** Measurement semantics version — see versions.ts. */
  readonly measurementVersion: number;
  /** Canonical (sorted, frozen) measurement map. */
  readonly measurements: Readonly<Record<string, ReferenceMeasurementValue>>;
  readonly availability: ReferenceMeasurementAvailability;
  readonly metadata: ReferenceTemplateMetadata;
  /**
   * What normalization changed on the way in (identifier renames, unit
   * conversions, numeric-string coercions). Empty for payloads that were
   * already canonical. Present so a remote integration can be AUDITED
   * instead of trusted: if a Supabase row arrived keyed `left_elbow` in
   * radians, that fact is visible in the artifact itself.
   */
  readonly normalization: NormalizationRecord;
  /**
   * Deterministic content hash over versions + every measurement id/value/
   * confidence. Two templates with equal hashes are interchangeable; a pin
   * whose hash no longer matches a re-resolved template exposes a silent
   * data change. FNV-1a 32-bit, hex — dependency-free and stable across
   * platforms (no crypto, no JSON key-order luck: input is pre-sorted).
   */
  readonly contentHash: string;
}

/** FNV-1a 32-bit over a canonical string; 8-char lowercase hex. */
export function referenceContentHash(input: string): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    // 32-bit FNV prime multiplication, kept in uint32 via Math.imul.
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

/** Canonical string the content hash is computed over. */
export function contentHashInput(
  schemaVersion: number,
  measurementVersion: number,
  measurements: Readonly<Record<string, ReferenceMeasurementValue>>,
): string {
  const parts = Object.keys(measurements)
    .sort()
    .map((id) => {
      const entry = measurements[id];
      const confidence = entry?.confidence ?? null;
      return `${id}=${entry?.value ?? ""}:${confidence ?? ""}`;
    });
  return `${referenceVersionStamp(schemaVersion, measurementVersion)}|${parts.join(",")}`;
}

/**
 * The ONLY sanctioned way to read one measurement. The result distinguishes
 * "present" from "absent" IN THE TYPE, so `undefined` can never be treated as
 * a number and no caller can reach for a default.
 */
export type MeasurementLookup =
  | { readonly present: true; readonly value: number; readonly confidence: number | null }
  | { readonly present: false; readonly reason: "not-in-template" | "not-registered" };

export function readMeasurement(
  template: ReferencePoseTemplate,
  measurementId: string,
): MeasurementLookup {
  const entry = template.measurements[measurementId];
  if (entry === undefined) {
    return {
      present: false,
      reason: template.availability.missingIds.includes(measurementId)
        ? "not-in-template"
        : "not-registered",
    };
  }
  return { present: true, value: entry.value, confidence: entry.confidence };
}

/** True when the template carries every measurement in `required`. */
export function templateHasAll(
  template: ReferencePoseTemplate,
  required: readonly string[],
): boolean {
  return required.every((id) => template.measurements[id] !== undefined);
}

export interface MeasurementMapSuccess {
  readonly ok: true;
  /** measurementId → value, the canonical projection engines consume. */
  readonly map: Readonly<Record<string, number>>;
}

export interface MeasurementMapFailure {
  readonly ok: false;
  readonly failure: ReferenceFailure;
}

export type MeasurementMapResult = MeasurementMapSuccess | MeasurementMapFailure;

/**
 * Extracts the plain { measurementId: value } projection the match/guidance
 * engines consume. Refuses — with a structured failure, never a throw — when
 * the template's measurement version is not understood by this build, so old
 * reference data is never silently reinterpreted by new math (or vice versa).
 */
export function templateMeasurementMap(
  template: ReferencePoseTemplate,
  supportedMeasurementVersions: readonly number[] = SUPPORTED_MEASUREMENT_VERSIONS,
): MeasurementMapResult {
  if (!supportedMeasurementVersions.includes(template.measurementVersion)) {
    return {
      ok: false,
      failure: incompatibleReference(
        `Template "${template.templateId}" uses measurement version ` +
          `${template.measurementVersion}; this build reads ` +
          `[${supportedMeasurementVersions.join(", ")}].`,
        { details: { measurementVersion: template.measurementVersion } },
      ),
    };
  }
  const map: Record<string, number> = {};
  for (const id of template.availability.availableIds) {
    const entry = template.measurements[id];
    if (entry === undefined) continue;
    map[id] = entry.value;
  }
  return { ok: true, map };
}
