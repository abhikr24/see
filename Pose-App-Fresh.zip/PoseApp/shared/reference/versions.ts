/**
 * shared/reference/versions.ts — Reference-pose foundation (Unit 28, Part 1).
 * Platform-neutral, zero RN/DOM/Supabase/TTS. Pure TypeScript.
 *
 * CENTRALIZED VERSION DEFINITIONS for the reference-pose architecture.
 *
 * Two independent version axes exist ON PURPOSE — they change for different
 * reasons and future math changes must never silently reinterpret old data:
 *
 *   1. SCHEMA VERSION — the SHAPE of a ReferencePoseTemplate payload
 *      (which fields exist, how measurements are keyed). Bump it when the
 *      serialized structure changes.
 *
 *   2. MEASUREMENT VERSION — the SEMANTICS of measurement values (what
 *      "leftElbow" means, which landmarks define it, units, plausibility
 *      band). Bump it when the math that PRODUCED or CONSUMED the values
 *      changes — e.g. when a measurement is redefined, a new generic
 *      measurement family (torsoLean, shoulderAlignment, stanceWidth,
 *      headOrientation) is added, or angle conventions change.
 *
 * A template whose versions are not in the supported sets is INCOMPATIBLE:
 * it is rejected with a structured failure at the validation boundary, never
 * coerced, never read "best effort".
 */

/**
 * Current schema version this codebase emits and understands.
 * v1: { templateId, poseId, schemaVersion, measurementVersion, measurements,
 *       metadata } envelope with per-measurement { value, confidence }.
 */
export const REFERENCE_TEMPLATE_SCHEMA_VERSION = 1;

/**
 * Current measurement version this codebase emits and understands.
 * v1: the eight interior joint angles (degrees 0..180) defined by
 * shared/ml/poseLandmarks.ts MATCH_JOINTS.
 */
export const MEASUREMENT_VERSION = 1;

/**
 * Every schema version still readable by this build, oldest first. Add — do
 * not remove — entries when a migration path keeps an older payload readable.
 */
export const SUPPORTED_SCHEMA_VERSIONS: readonly number[] = [1];

/**
 * Every measurement version the current engine can consume. A template
 * stamped with anything else is 'incompatible-reference' for this build.
 */
export const SUPPORTED_MEASUREMENT_VERSIONS: readonly number[] = [1];

export function isSupportedSchemaVersion(version: number): boolean {
  return SUPPORTED_SCHEMA_VERSIONS.includes(version);
}

export function isSupportedMeasurementVersion(version: number): boolean {
  return SUPPORTED_MEASUREMENT_VERSIONS.includes(version);
}

/**
 * Stable machine-readable stamp embedded in template identity and content
 * hashes, e.g. "s1.m1" — schema 1, measurement semantics 1.
 */
export function referenceVersionStamp(
  schemaVersion: number,
  measurementVersion: number,
): string {
  return `s${schemaVersion}.m${measurementVersion}`;
}
