/**
 * tests/analysis/binding.test.ts — the seam between the validated reference
 * domain (shared/reference) and the analysis engine (shared/ml/analysis).
 *
 * The engine must only ever receive a prevalidated projection, bound once,
 * outside the frame loop — and an unusable template must stay unusable.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  analysisInputFromPin,
  analysisInputFromTemplate,
  analysisSemanticsAgree,
  bindTemplateForAnalysis,
  buildReferenceTemplate,
  pinReferenceForSession,
  ReferenceStatuses,
} from "../../shared/reference";
import { createPoseAnalysisEngine } from "../../shared/ml/analysis";
import { mutated, validRawPayload } from "../reference/fixtures";
import { bodyLandmarks } from "./fixtures";

const PROVIDER = "test-fixtures";

function readyTemplate(payload: Record<string, unknown>) {
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.ready);
  if (result.status !== ReferenceStatuses.ready) throw new Error("fixture must build");
  return result.template;
}

test("engine and reference domain agree on measurement semantics", () => {
  assert.equal(analysisSemanticsAgree(), true);
});

test("a validated template projects into an engine-ready session reference", () => {
  const template = readyTemplate(validRawPayload());
  const projection = analysisInputFromTemplate(template);
  assert.equal(projection.ok, true);
  if (!projection.ok) return;
  assert.equal(projection.input.referenceId, template.templateId);
  assert.equal(projection.input.contentHash, template.contentHash);
  assert.equal(
    Object.keys(projection.input.values).length,
    template.availability.availableCount,
  );

  const binding = bindTemplateForAnalysis(template);
  assert.equal(binding.ok, true);
  if (!binding.ok) return;
  assert.equal(binding.reference.identity.poseId, template.poseId);
  assert.equal(Object.isFrozen(binding.reference), true);
});

test("the pinned template is what the engine analyses against", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-analysis", 1_000);
  const projection = analysisInputFromPin(pin);
  assert.equal(projection.ok, true);
  if (!projection.ok) return;

  const engine = createPoseAnalysisEngine({
    reference: projection.input,
    sessionId: pin.sessionToken,
  });
  assert.equal(engine.referenceState, "ready");
  assert.equal(engine.reference?.identity.contentHash, pin.identity.contentHash);

  /* Frames must not disturb the pinned identity. */
  for (let index = 0; index < 5; index += 1) engine.analyzeFrame(bodyLandmarks());
  assert.equal(engine.reference?.identity.contentHash, pin.identity.contentHash);
  assert.equal(engine.reference?.identity.referenceId, template.templateId);
});

test("a template the domain rejects never reaches the engine", () => {
  const broken = buildReferenceTemplate({
    providerId: PROVIDER,
    payload: mutated(validRawPayload(), (draft) => {
      draft["measurements"] = { leftElbow: { value: 90, confidence: 0.9 } };
    }),
  });
  assert.notEqual(broken.status, ReferenceStatuses.ready);
});

test("an incompatible measurement version cannot be bound for analysis", () => {
  const template = readyTemplate(validRawPayload());
  const drifted = { ...template, measurementVersion: 99 };
  const binding = bindTemplateForAnalysis(drifted);
  assert.equal(binding.ok, false);
  if (binding.ok) return;
  assert.equal(binding.unavailable.reason, "reference-incompatible");
});
