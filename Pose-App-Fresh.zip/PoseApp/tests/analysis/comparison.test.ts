/**
 * tests/analysis/comparison.test.ts — Unit 29 stages 1–5:
 * MEASUREMENTS → COMPARISON → ERROR → CONFIDENCE → SEVERITY.
 *
 * Boundary policy under test (centralized in shared/ml/analysis/thresholds):
 *   |e| <  10  → within-tolerance      |e| == 10 → minor
 *   |e| <= 25  → minor                 |e| >  25 → major
 * Every boundary is probed immediately below, at, and above.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  CORRECTION_THRESHOLD_DEGREES,
  GOOD_TOLERANCE_DEGREES,
  MIN_COACHING_CONFIDENCE,
  MIN_MEASURABLE_CONFIDENCE,
  combineConfidence,
  directionFor,
  measureLiveFrame,
  severityFor,
} from "../../shared/ml/analysis";
import { POSE_LANDMARKS } from "../../shared/ml/poseLandmarks";
import { calculateAngle } from "../../shared/ml/poseMatch";
import {
  absent,
  bodyLandmarks,
  comparisonOf,
  comparisonsFor,
  live,
  measuredAngles,
  unreliable,
} from "./fixtures";

const REF = 100;

function compareAt(liveValue: number, confidence = 0.9) {
  const comparisons = comparisonsFor(
    [live("leftElbow", liveValue, confidence), live("rightElbow", REF, confidence)],
    { leftElbow: REF, rightElbow: REF },
  );
  return comparisonOf(comparisons, "leftElbow");
}

/* ----------------------------- perfect match ---------------------------- */

test("identical live and reference values produce zero error and no direction", () => {
  const comparison = compareAt(REF);
  assert.equal(comparison.available, true);
  assert.equal(comparison.valid, true);
  assert.equal(comparison.signedError, 0);
  assert.equal(comparison.absError, 0);
  assert.equal(comparison.direction, "none");
  assert.equal(comparison.severity, "within-tolerance");
});

/* --------------------------- threshold boundaries ----------------------- */

test("tolerance boundary: below / at / above 10°", () => {
  assert.equal(severityFor(GOOD_TOLERANCE_DEGREES - 0.001), "within-tolerance");
  assert.equal(severityFor(GOOD_TOLERANCE_DEGREES), "minor");
  assert.equal(severityFor(GOOD_TOLERANCE_DEGREES + 0.001), "minor");

  assert.equal(compareAt(REF + GOOD_TOLERANCE_DEGREES - 0.001).severity, "within-tolerance");
  assert.equal(compareAt(REF + GOOD_TOLERANCE_DEGREES).severity, "minor");
  assert.equal(compareAt(REF + GOOD_TOLERANCE_DEGREES + 0.001).severity, "minor");
});

test("correction boundary: below / at / above 25°", () => {
  assert.equal(severityFor(CORRECTION_THRESHOLD_DEGREES - 0.001), "minor");
  assert.equal(severityFor(CORRECTION_THRESHOLD_DEGREES), "minor");
  assert.equal(severityFor(CORRECTION_THRESHOLD_DEGREES + 0.001), "major");

  assert.equal(compareAt(REF - CORRECTION_THRESHOLD_DEGREES).severity, "minor");
  assert.equal(compareAt(REF - CORRECTION_THRESHOLD_DEGREES - 0.001).severity, "major");
});

test("severity is monotone: growing error never becomes less severe", () => {
  let previous = -1;
  const rank = { "within-tolerance": 0, minor: 1, major: 2 } as const;
  for (let error = 0; error <= 120; error += 0.25) {
    const current = rank[severityFor(error)];
    assert.ok(current >= previous, `severity dropped at ${error}°`);
    previous = current;
  }
});

/* ------------------------------- direction ------------------------------ */

test("positive error (live above reference) asks to decrease the angle", () => {
  const comparison = compareAt(REF + 20);
  assert.equal(comparison.signedError, 20);
  assert.equal(comparison.absError, 20);
  assert.equal(comparison.direction, "decrease");
});

test("negative error (live below reference) asks to increase the angle", () => {
  const comparison = compareAt(REF - 20);
  assert.equal(comparison.signedError, -20);
  assert.equal(comparison.absError, 20);
  assert.equal(comparison.direction, "increase");
});

test("invariant: reversing the signed error reverses the direction", () => {
  for (const delta of [0.5, 3, 11, 26, 60]) {
    assert.equal(directionFor(delta), "decrease");
    assert.equal(directionFor(-delta), "increase");
    assert.equal(compareAt(REF + delta).direction, "decrease");
    assert.equal(compareAt(REF - delta).direction, "increase");
  }
});

/* ------------------------------- confidence ----------------------------- */

test("reference confidence null leaves the live confidence standing alone", () => {
  assert.equal(combineConfidence(0.8, null), 0.8);
  assert.equal(combineConfidence(0.8, 0.5), 0.4);
  assert.equal(combineConfidence(2, null), 1, "clamped to 0..1");
  assert.equal(combineConfidence(-1, null), 0, "clamped to 0..1");
});

test("a low-confidence comparison is reported but never valid for coaching", () => {
  const comparison = compareAt(REF + 40, MIN_COACHING_CONFIDENCE - 0.01);
  assert.equal(comparison.available, true);
  assert.equal(comparison.valid, false);
  assert.equal(comparison.validity, "low-confidence");
  assert.equal(comparison.severity, "major", "the measurement is still described");
});

test("confidence boundary: below / at / above the coaching floor", () => {
  assert.equal(compareAt(REF + 40, MIN_COACHING_CONFIDENCE - 0.001).valid, false);
  assert.equal(compareAt(REF + 40, MIN_COACHING_CONFIDENCE).valid, true);
  assert.equal(compareAt(REF + 40, MIN_COACHING_CONFIDENCE + 0.001).valid, true);
});

test("reference confidence drags the combined confidence under the floor", () => {
  const comparisons = comparisonsFor(
    [live("leftElbow", REF + 40, 0.9), live("rightElbow", REF, 0.9)],
    { leftElbow: REF, rightElbow: REF },
    { confidence: 0.4 },
  );
  const comparison = comparisonOf(comparisons, "leftElbow");
  assert.ok(Math.abs(comparison.confidence - 0.36) < 1e-9);
  assert.equal(comparison.valid, false);
  assert.equal(comparison.validity, "low-confidence");
});

/* ---------------------------- missing / absent -------------------------- */

test("a missing live measurement can never produce a valid comparison", () => {
  const comparisons = comparisonsFor(
    [absent("leftElbow"), live("rightElbow", REF, 0.9)],
    { leftElbow: REF, rightElbow: REF },
  );
  const comparison = comparisonOf(comparisons, "leftElbow");
  assert.equal(comparison.available, false);
  assert.equal(comparison.valid, false);
  assert.equal(comparison.validity, "live-missing");
  assert.equal(comparison.liveValue, null);
  assert.equal(comparison.signedError, null);
  assert.equal(comparison.absError, null);
  assert.equal(comparison.direction, "none");
});

test("an unreliable live measurement is distinguished from an absent one", () => {
  const comparisons = comparisonsFor(
    [unreliable("leftElbow", 0.2), live("rightElbow", REF, 0.9)],
    { leftElbow: REF, rightElbow: REF },
  );
  const comparison = comparisonOf(comparisons, "leftElbow");
  assert.equal(comparison.validity, "low-confidence");
  assert.equal(comparison.liveState, "landmark-unreliable");
  assert.equal(comparison.valid, false);
});

test("a measurement the reference does not carry is reported, never invented", () => {
  const comparisons = comparisonsFor(
    [live("leftElbow", REF, 0.9), live("rightElbow", REF, 0.9), live("leftKnee", 170, 0.9)],
    { leftElbow: REF, rightElbow: REF },
  );
  const comparison = comparisonOf(comparisons, "leftKnee");
  assert.equal(comparison.validity, "reference-missing");
  assert.equal(comparison.referenceValue, null);
  assert.equal(comparison.available, false);
  assert.equal(comparison.valid, false);
  assert.equal(comparison.signedError, null);
});

/* ------------------------ measurement stage (geometry) ------------------ */

test("the angular convention is unchanged: calculateAngle stays the source", () => {
  const landmarks = bodyLandmarks();
  const shoulder = landmarks[POSE_LANDMARKS.leftShoulder];
  const elbow = landmarks[POSE_LANDMARKS.leftElbow];
  const wrist = landmarks[POSE_LANDMARKS.leftWrist];
  assert.ok(shoulder !== undefined && elbow !== undefined && wrist !== undefined);
  const expected = calculateAngle(shoulder, elbow, wrist);
  const measured = measuredAngles(landmarks)["leftElbow"];
  assert.equal(measured, expected);
});

test("measurement is dense, registry-ordered and explains every absence", () => {
  const measurements = measureLiveFrame(bodyLandmarks());
  assert.equal(measurements.length, 8);
  assert.deepEqual(
    measurements.map((m) => m.measurementId),
    [
      "leftElbow",
      "rightElbow",
      "leftKnee",
      "rightKnee",
      "leftShoulder",
      "rightShoulder",
      "leftHip",
      "rightHip",
    ],
  );
  for (const measurement of measurements) {
    assert.equal(measurement.state, "measured");
    assert.ok(measurement.value !== null);
  }
});

test("landmarks under the visibility floor yield an unreliable measurement", () => {
  const landmarks = bodyLandmarks({
    overrides: {
      [POSE_LANDMARKS.leftWrist]: { visibility: MIN_MEASURABLE_CONFIDENCE - 0.01 },
    },
  });
  const measurements = measureLiveFrame(landmarks);
  const elbow = measurements.find((m) => m.measurementId === "leftElbow");
  assert.ok(elbow !== undefined);
  assert.equal(elbow.state, "landmark-unreliable");
  assert.equal(elbow.value, null);
});

test("an empty frame produces no measurements with values", () => {
  const measurements = measureLiveFrame([]);
  assert.equal(measurements.length, 8);
  for (const measurement of measurements) {
    assert.equal(measurement.value, null);
    assert.equal(measurement.state, "landmark-missing");
    assert.equal(measurement.confidence, 0);
  }
});
