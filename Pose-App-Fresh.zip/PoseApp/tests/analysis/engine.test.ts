/**
 * tests/analysis/engine.test.ts — Unit 29 end to end:
 * LIVE LANDMARKS → … → ONE SEMANTIC DECISION, plus the session contract
 * (pinned reference, structured unavailable states) and the compatibility
 * bridge to the existing Unit 17/27 guidance + voice layer.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  ANALYSIS_STATE_UNAVAILABLE,
  CORRECTION_PERSISTENCE_FRAMES,
  MIN_COACHING_CONFIDENCE,
  PERFECT_PERSISTENCE_FRAMES,
  createPoseAnalysisEngine,
  decisionToGuidance,
  type PoseAnalysisDecision,
} from "../../shared/ml/analysis";
import { POSE_LANDMARKS, type PoseLandmark } from "../../shared/ml/poseLandmarks";
import {
  bodyLandmarks,
  referenceInput,
  referenceWithOffsets,
} from "./fixtures";

function engineFor(
  values: Readonly<Record<string, number>> | null,
  options?: Parameters<typeof referenceInput>[1],
) {
  return createPoseAnalysisEngine({
    reference: values === null ? null : referenceInput(values, options),
    sessionId: "test-session",
  });
}

/** Feed the same frame N times and return the last decision. */
function settle(
  engine: ReturnType<typeof createPoseAnalysisEngine>,
  landmarks: readonly PoseLandmark[],
  frames: number,
): PoseAnalysisDecision {
  let decision = engine.analyzeFrame(landmarks);
  for (let index = 1; index < frames; index += 1) {
    decision = engine.analyzeFrame(landmarks);
  }
  return decision;
}

/* ------------------------------ perfect path ---------------------------- */

test("invariant: identical live and reference values produce no correction", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}));
  const decision = settle(engine, landmarks, PERFECT_PERSISTENCE_FRAMES);
  assert.equal(decision.kind, "perfect");
  assert.equal(decision.state, "PERFECT");
  assert.equal(decision.correction, null);
  assert.equal(decision.frame.candidates.length, 0);
  assert.ok((decision.frame.maxAbsError ?? 1) < 1e-9);
});

test("the engine emits exactly one decision per frame", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const decision = settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  assert.equal(decision.kind, "correction");
  assert.equal(decision.correction?.measurementId, "leftElbow");
  assert.equal(decision.state, "LEFT_ELBOW_DECREASE");
  assert.equal(decision.unavailable, null);
});

test("direction follows the signed error, and reverses with it", () => {
  const landmarks = bodyLandmarks();

  const positive = engineFor(referenceWithOffsets(landmarks, { leftKnee: 30 }));
  const decisionPositive = settle(positive, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  assert.equal(decisionPositive.correction?.direction, "decrease");
  assert.ok((decisionPositive.correction?.signedError ?? 0) > 0);

  const negative = engineFor(referenceWithOffsets(landmarks, { leftKnee: -30 }));
  const decisionNegative = settle(negative, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  assert.equal(decisionNegative.correction?.direction, "increase");
  assert.ok((decisionNegative.correction?.signedError ?? 0) < 0);
  assert.equal(
    decisionNegative.correction?.absError,
    decisionPositive.correction?.absError,
  );
});

test("multiple simultaneous errors still yield one dominant correction", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(
    referenceWithOffsets(landmarks, { leftElbow: 12, rightKnee: -45, leftHip: 20 }),
  );
  const decision = settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  assert.equal(decision.kind, "correction");
  assert.equal(decision.correction?.measurementId, "rightKnee");
  assert.equal(decision.frame.candidates.length, 3);
});

/* --------------------------- unavailable states ------------------------- */

test("no reference: a structured unavailable state, never coaching", () => {
  const engine = engineFor(null);
  assert.equal(engine.referenceState, "unusable");
  const decision = engine.analyzeFrame(bodyLandmarks());
  assert.equal(decision.kind, "unavailable");
  assert.equal(decision.state, ANALYSIS_STATE_UNAVAILABLE);
  assert.equal(decision.unavailable?.reason, "reference-unavailable");
  assert.equal(decision.correction, null);
  assert.equal(decisionToGuidance(decision), null);
});

test("incompatible template version is refused, not reinterpreted", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}), {
    measurementVersion: 2,
  });
  assert.equal(engine.referenceState, "unusable");
  assert.equal(engine.referenceFailure?.reason, "reference-incompatible");
  const decision = engine.analyzeFrame(landmarks);
  assert.equal(decision.unavailable?.reason, "reference-incompatible");
  assert.equal(decisionToGuidance(decision), null);
});

test("an implausible reference value invalidates the reference", () => {
  const engine = engineFor({ leftElbow: 400, rightElbow: 90, leftKnee: 170 });
  assert.equal(engine.referenceState, "unusable");
  assert.equal(engine.referenceFailure?.reason, "reference-invalid");
});

test("a reference with too few measurements is incomplete, not usable", () => {
  const engine = engineFor({ leftElbow: 90 });
  assert.equal(engine.referenceState, "unusable");
  assert.equal(engine.referenceFailure?.reason, "reference-incomplete");
});

test("an empty frame reports no-live-pose", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}));
  const decision = engine.analyzeFrame([]);
  assert.equal(decision.kind, "unavailable");
  assert.equal(decision.unavailable?.reason, "no-live-pose");
});

test("too few measurable joints reports insufficient-measurements", () => {
  const hidden: Record<number, Partial<PoseLandmark>> = {};
  for (const index of [
    POSE_LANDMARKS.leftWrist,
    POSE_LANDMARKS.rightWrist,
    POSE_LANDMARKS.leftAnkle,
    POSE_LANDMARKS.rightAnkle,
    POSE_LANDMARKS.leftKnee,
    POSE_LANDMARKS.rightKnee,
    POSE_LANDMARKS.leftElbow,
    POSE_LANDMARKS.rightElbow,
  ]) {
    hidden[index] = { visibility: 0.05 };
  }
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}));
  const decision = engine.analyzeFrame(bodyLandmarks({ overrides: hidden }));
  assert.equal(decision.kind, "unavailable");
  assert.equal(decision.unavailable?.reason, "insufficient-measurements");
  assert.equal(decision.correction, null);
});

test("measurable but untrusted landmarks report low-confidence, not coaching", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const shaky = bodyLandmarks({ visibility: MIN_COACHING_CONFIDENCE - 0.05 });
  const decision = engine.analyzeFrame(shaky);
  assert.equal(decision.kind, "unavailable");
  assert.equal(decision.unavailable?.reason, "low-confidence");
  assert.ok(decision.frame.comparedCount >= 2, "the data exists…");
  assert.equal(decision.frame.usableCount, 0, "…it is simply not trustworthy");
});

test("invariant: a missing measurement can never create a valid correction", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 60 }));
  const withoutLeftArm = bodyLandmarks({
    overrides: {
      [POSE_LANDMARKS.leftWrist]: { visibility: 0.01 },
      [POSE_LANDMARKS.leftElbow]: { visibility: 0.01 },
    },
  });
  const decision = settle(engine, withoutLeftArm, CORRECTION_PERSISTENCE_FRAMES + 2);
  assert.notEqual(decision.correction?.measurementId, "leftElbow");
  for (const candidate of decision.frame.candidates) {
    assert.notEqual(candidate.measurementId, "leftElbow");
  }
});

/* ---------------------------- session contract -------------------------- */

test("the session reference is frozen and cannot be swapped mid-session", () => {
  const landmarks = bodyLandmarks();
  const input = referenceInput(referenceWithOffsets(landmarks, {}));
  const engine = createPoseAnalysisEngine({ reference: input, sessionId: "s" });
  const before = engine.reference;
  assert.ok(before !== null);
  const hashBefore = before.identity.contentHash;

  /* Mutating the caller's object must not reach the engine. */
  const mutableValues = input.values as Record<
    string,
    { value: number; confidence: number | null }
  >;
  mutableValues["leftElbow"] = { value: 5, confidence: 1 };

  engine.analyzeFrame(landmarks);
  assert.equal(engine.reference, before, "identity object is stable");
  assert.equal(engine.reference?.identity.contentHash, hashBefore);
  assert.notEqual(engine.reference?.values["leftElbow"]?.value, 5);

  /* And the snapshot itself is frozen. */
  assert.equal(Object.isFrozen(engine.reference), true);
  assert.equal(Object.isFrozen(engine.reference?.values), true);
});

test("reset clears temporal memory but keeps the pinned reference", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const settled = settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  assert.equal(settled.kind, "correction");
  const reference = engine.reference;
  engine.reset();
  const afterReset = engine.analyzeFrame(landmarks);
  assert.equal(afterReset.kind, "evaluating");
  assert.equal(engine.reference, reference);
});

test("two engines fed the same frames produce identical state sequences", () => {
  const landmarks = bodyLandmarks();
  const values = referenceWithOffsets(landmarks, { leftElbow: 30, rightHip: -18 });
  const frames = [
    landmarks,
    bodyLandmarks({ visibility: 0.9 }),
    landmarks,
    [],
    landmarks,
    landmarks,
    landmarks,
  ];
  const run = () => {
    const engine = engineFor(values);
    return frames.map((frame) => engine.analyzeFrame(frame).state);
  };
  assert.deepEqual(run(), run());
});

test("the decision reports the reference identity it was computed against", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}), {
    referenceId: "fixtures/abc",
    poseId: "pose-42",
    contentHash: "0badc0de",
  });
  const decision = engine.analyzeFrame(landmarks);
  assert.equal(decision.reference?.referenceId, "fixtures/abc");
  assert.equal(decision.reference?.poseId, "pose-42");
  assert.equal(decision.reference?.contentHash, "0badc0de");
});

/* --------------------------- semantic bridge ---------------------------- */

test("bridge maps a correction onto the existing guidance contract", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const decision = settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  const guidance = decisionToGuidance(decision);
  assert.ok(guidance !== null);
  assert.equal(guidance.worstJoint, "leftElbow");
  assert.equal(guidance.worstLandmarkName, "leftElbow");
  assert.equal(guidance.isPerfect, false);
  assert.equal(guidance.severity, "adjust");
  assert.equal(guidance.text, "Bend left arm", "live > reference ⇒ close the joint");
  /* Unit 33: the screen text and the spoken category now describe the SAME
     action ("bend the left arm"), not a lateral hand shift. */
  assert.equal(guidance.voiceCategory, "hand_left_bend");
});

test("bridge maps the mirrored error to the mirrored instruction", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: -40 }));
  const decision = settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES);
  const guidance = decisionToGuidance(decision);
  assert.equal(guidance?.text, "Straighten left arm");
});

test("bridge maps perfect and evaluating states honestly", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}));
  const first = engine.analyzeFrame(landmarks);
  assert.equal(first.kind, "evaluating");
  assert.equal(decisionToGuidance(first), null, "no coaching before stability");

  const perfect = settle(engine, landmarks, PERFECT_PERSISTENCE_FRAMES);
  const guidance = decisionToGuidance(perfect);
  assert.equal(guidance?.isPerfect, true);
  assert.equal(guidance?.text, "Perfect! Hold still");
  assert.equal(guidance?.arrowDirection, "none");
});

test("noisy frames do not produce contradictory guidance text", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(
    referenceWithOffsets(landmarks, { leftElbow: 30, rightElbow: 28 }),
  );
  const texts = new Set<string>();
  for (let index = 0; index < 12; index += 1) {
    /* Alternate a sub-degree wobble on the two competing joints. */
    const wobble = bodyLandmarks({ visibility: index % 2 === 0 ? 0.95 : 0.94 });
    const guidance = decisionToGuidance(engine.analyzeFrame(wobble));
    if (guidance !== null) texts.add(guidance.text);
  }
  assert.equal(texts.size <= 1, true, `flapping guidance: ${[...texts].join(" / ")}`);
});
