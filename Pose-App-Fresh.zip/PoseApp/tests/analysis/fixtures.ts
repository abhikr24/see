/**
 * tests/analysis/fixtures.ts — SYNTHETIC FIXTURES for the deterministic
 * pose-analysis engine (Unit 29). Test-only: no production tree may import
 * this file (enforced by verify-reference-architecture.mjs rule C).
 *
 * Everything here is deterministic — fixed coordinates, fixed confidences,
 * no randomness, no clock.
 */
import {
  bindSessionReference,
  compareFrame,
  measureLiveFrame,
  type AnalysisReferenceInput,
  type LiveMeasurement,
  type MeasurementComparison,
  type SessionReference,
} from "../../shared/ml/analysis";
import { POSE_LANDMARKS, type PoseLandmark } from "../../shared/ml/poseLandmarks";

export const ALL_IDS = [
  "leftElbow",
  "rightElbow",
  "leftKnee",
  "rightKnee",
  "leftShoulder",
  "rightShoulder",
  "leftHip",
  "rightHip",
] as const;

/** A live measurement that was taken successfully. */
export function live(
  measurementId: string,
  value: number,
  confidence = 0.9,
): LiveMeasurement {
  return { measurementId, value, confidence, state: "measured" };
}

/** A live measurement whose landmarks were not in the frame at all. */
export function absent(measurementId: string): LiveMeasurement {
  return { measurementId, value: null, confidence: 0, state: "landmark-missing" };
}

/** A live measurement seen below the measurable-confidence floor. */
export function unreliable(
  measurementId: string,
  confidence = 0.2,
): LiveMeasurement {
  return {
    measurementId,
    value: null,
    confidence,
    state: "landmark-unreliable",
  };
}

export function referenceInput(
  values: Readonly<Record<string, number>>,
  options?: {
    readonly confidence?: number | null;
    readonly measurementVersion?: number;
    readonly schemaVersion?: number;
    readonly referenceId?: string;
    readonly poseId?: string;
    readonly contentHash?: string;
  },
): AnalysisReferenceInput {
  const confidence = options?.confidence === undefined ? null : options.confidence;
  const mapped: Record<string, { value: number; confidence: number | null }> = {};
  for (const [id, value] of Object.entries(values)) {
    mapped[id] = { value, confidence };
  }
  return {
    referenceId: options?.referenceId ?? "fixtures/analysis-1",
    poseId: options?.poseId ?? "fixture-pose",
    schemaVersion: options?.schemaVersion ?? 1,
    measurementVersion: options?.measurementVersion ?? 1,
    contentHash: options?.contentHash ?? "deadbeef",
    values: mapped,
  };
}

export function boundReference(
  values: Readonly<Record<string, number>>,
  options?: Parameters<typeof referenceInput>[1],
): SessionReference {
  const binding = bindSessionReference(referenceInput(values, options));
  if (!binding.ok) {
    throw new Error(`fixture reference must bind: ${binding.unavailable.message}`);
  }
  return binding.reference;
}

/** Real comparisons, produced by the real compare stage. */
export function comparisonsFor(
  liveMeasurements: readonly LiveMeasurement[],
  values: Readonly<Record<string, number>>,
  options?: Parameters<typeof referenceInput>[1],
): readonly MeasurementComparison[] {
  return compareFrame(liveMeasurements, boundReference(values, options));
}

export function comparisonOf(
  comparisons: readonly MeasurementComparison[],
  measurementId: string,
): MeasurementComparison {
  const found = comparisons.find((c) => c.measurementId === measurementId);
  if (found === undefined) throw new Error(`no comparison for ${measurementId}`);
  return found;
}

/**
 * A deterministic 33-landmark standing body. Coordinates are fixed; the tests
 * never assert magic angle values — they measure this body with the engine's
 * own measurement stage and build references relative to it.
 */
export function bodyLandmarks(options?: {
  readonly visibility?: number;
  readonly overrides?: Readonly<Record<number, Partial<PoseLandmark>>>;
}): PoseLandmark[] {
  const visibility = options?.visibility ?? 0.95;
  const landmarks: PoseLandmark[] = [];
  for (let index = 0; index < 33; index += 1) {
    landmarks.push({ x: 0.5, y: 0.5, z: 0, visibility });
  }
  const place = (index: number, x: number, y: number): void => {
    landmarks[index] = { x, y, z: 0, visibility };
  };
  place(POSE_LANDMARKS.nose, 0.5, 0.1);
  /* Mid-range joint angles on purpose: every measurement sits far from the
     2°/180° plausibility rails, so a test can push a reference ±45° in either
     direction and still describe a physically possible pose. */
  place(POSE_LANDMARKS.leftShoulder, 0.42, 0.3);
  place(POSE_LANDMARKS.rightShoulder, 0.58, 0.3);
  place(POSE_LANDMARKS.leftElbow, 0.3, 0.4);
  place(POSE_LANDMARKS.rightElbow, 0.7, 0.4);
  place(POSE_LANDMARKS.leftWrist, 0.34, 0.55);
  place(POSE_LANDMARKS.rightWrist, 0.66, 0.55);
  place(POSE_LANDMARKS.leftHip, 0.45, 0.58);
  place(POSE_LANDMARKS.rightHip, 0.55, 0.58);
  place(POSE_LANDMARKS.leftKnee, 0.62, 0.68);
  place(POSE_LANDMARKS.rightKnee, 0.38, 0.68);
  place(POSE_LANDMARKS.leftAnkle, 0.584, 0.877);
  place(POSE_LANDMARKS.rightAnkle, 0.416, 0.877);

  for (const [rawIndex, override] of Object.entries(options?.overrides ?? {})) {
    const index = Number(rawIndex);
    const base = landmarks[index];
    if (base === undefined) continue;
    landmarks[index] = { ...base, ...override };
  }
  return landmarks;
}

/** The live angles this body produces, keyed by measurement id. */
export function measuredAngles(
  landmarks: readonly PoseLandmark[],
): Record<string, number> {
  const result: Record<string, number> = {};
  for (const measurement of measureLiveFrame(landmarks)) {
    if (measurement.value !== null) result[measurement.measurementId] = measurement.value;
  }
  return result;
}

/**
 * Reference values derived from a body: reference = live − offset, so the
 * SIGNED error of every measurement is exactly the requested offset.
 */
export function referenceWithOffsets(
  landmarks: readonly PoseLandmark[],
  offsets: Readonly<Record<string, number>>,
): Record<string, number> {
  const angles = measuredAngles(landmarks);
  const values: Record<string, number> = {};
  for (const [id, angle] of Object.entries(angles)) {
    values[id] = angle - (offsets[id] ?? 0);
  }
  return values;
}
