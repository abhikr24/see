/**
 * tests/analysis/matchScore.test.ts — Unit 31 hot-path repair.
 *
 * PROVES the refactor rather than claiming it: the match % derived from the
 * engine's own comparisons (`matchFromDecision`, one geometry pass) is
 * BIT-IDENTICAL to the legacy second pass (`calculateMatchPercent`) that the
 * camera loop used to run alongside the engine.
 *
 * Deterministic: fixed bodies, fixed offsets, no clock, no randomness.
 */
import { strict as assert } from "node:assert";
import test from "node:test";

import {
  createPoseAnalysisEngine,
  matchFromComparisons,
  matchFromDecision,
} from "../../shared/ml/analysis";
import { calculateMatchPercent } from "../../shared/ml/poseMatch";
import { POSE_LANDMARKS, type PoseLandmark } from "../../shared/ml/poseLandmarks";
import {
  bodyLandmarks,
  measuredAngles,
  referenceInput,
  referenceWithOffsets,
} from "./fixtures";

function engineFor(values: Readonly<Record<string, number>>) {
  return createPoseAnalysisEngine({
    reference: referenceInput(values),
    sessionId: "match-score",
  });
}

/** Every offset profile the equivalence must hold for. */
const OFFSET_PROFILES: readonly Readonly<Record<string, number>>[] = [
  {},
  { leftElbow: 30 },
  { leftElbow: -45, rightKnee: 12 },
  { leftElbow: 5, rightElbow: -5, leftKnee: 9, rightKnee: -9 },
  { leftShoulder: 40, rightShoulder: -40, leftHip: 20, rightHip: -20 },
];

test("derived match % equals the legacy second geometry pass, exactly", () => {
  const landmarks = bodyLandmarks();
  for (const offsets of OFFSET_PROFILES) {
    const values = referenceWithOffsets(landmarks, offsets);
    const legacy = calculateMatchPercent(landmarks, values);
    const derived = matchFromDecision(engineFor(values).analyzeFrame(landmarks));

    assert.equal(derived.percent, legacy.percent);
    assert.equal(derived.jointsCompared, legacy.jointsCompared);
    assert.deepEqual(derived.perJoint, legacy.perJoint);
    if (legacy.avgDiffDegrees === null) {
      assert.equal(derived.avgDiffDegrees, null);
    } else {
      assert.ok(derived.avgDiffDegrees !== null);
      assert.ok(Math.abs((derived.avgDiffDegrees ?? 0) - legacy.avgDiffDegrees) < 1e-12);
    }
  }
});

test("equivalence holds when the reference is partial (fewer than 8 joints)", () => {
  const landmarks = bodyLandmarks();
  const all = measuredAngles(landmarks);
  const partial: Record<string, number> = {
    leftElbow: (all["leftElbow"] ?? 0) - 20,
    rightKnee: (all["rightKnee"] ?? 0) + 8,
    leftHip: all["leftHip"] ?? 0,
  };
  const legacy = calculateMatchPercent(landmarks, partial);
  const derived = matchFromDecision(engineFor(partial).analyzeFrame(landmarks));

  assert.equal(derived.jointsCompared, 3);
  assert.equal(derived.percent, legacy.percent);
  assert.deepEqual(derived.perJoint, legacy.perJoint);
});

test("equivalence holds when landmarks drop below the visibility floor", () => {
  /* Hide one whole arm: the legacy pass and the engine must agree about
     which joints stopped being measurable. */
  const overrides: Record<number, Partial<PoseLandmark>> = {
    [POSE_LANDMARKS.leftElbow]: { visibility: 0.05 },
    [POSE_LANDMARKS.leftWrist]: { visibility: 0.05 },
  };
  const clean = bodyLandmarks();
  const values = referenceWithOffsets(clean, { leftElbow: 25, rightElbow: 25 });
  const occluded = bodyLandmarks({ overrides });

  const legacy = calculateMatchPercent(occluded, values);
  const derived = matchFromDecision(engineFor(values).analyzeFrame(occluded));

  assert.equal(derived.percent, legacy.percent);
  assert.deepEqual(derived.perJoint, legacy.perJoint);
  assert.ok(!("leftElbow" in derived.perJoint));
});

test("fewer than two comparable joints scores null, never a red zero", () => {
  /* Two reference measurements, but only one joint is visible this frame.
     The legacy pass and the derived pass must BOTH decline to score. */
  const clean = bodyLandmarks();
  const all = measuredAngles(clean);
  const values: Record<string, number> = {
    leftElbow: all["leftElbow"] ?? 0,
    rightElbow: all["rightElbow"] ?? 0,
  };
  const occluded = bodyLandmarks({
    overrides: {
      [POSE_LANDMARKS.rightElbow]: { visibility: 0.05 },
      [POSE_LANDMARKS.rightWrist]: { visibility: 0.05 },
    },
  });
  const derived = matchFromDecision(engineFor(values).analyzeFrame(occluded));
  assert.equal(derived.jointsCompared, 1);
  assert.equal(derived.percent, null);
  assert.equal(calculateMatchPercent(occluded, values).percent, null);
});

test("a single-measurement reference is refused outright (incomplete), not scored", () => {
  const landmarks = bodyLandmarks();
  const all = measuredAngles(landmarks);
  const single: Record<string, number> = { leftElbow: all["leftElbow"] ?? 0 };
  const engine = engineFor(single);
  assert.equal(engine.referenceState, "unusable");
  const derived = matchFromDecision(engine.analyzeFrame(landmarks));
  assert.equal(derived.percent, null);
  assert.equal(derived.jointsCompared, 0);
  assert.equal(calculateMatchPercent(landmarks, single).percent, null);
});

test("no engine (unusable reference) scores nothing — it fabricates no number", () => {
  assert.deepEqual(matchFromDecision(null), {
    percent: null,
    perJoint: {},
    jointsCompared: 0,
    avgDiffDegrees: null,
  });
  assert.equal(matchFromComparisons([]).percent, null);
});

test("an empty frame scores null on both paths", () => {
  const values = referenceWithOffsets(bodyLandmarks(), { leftElbow: 30 });
  const derived = matchFromDecision(engineFor(values).analyzeFrame([]));
  assert.equal(derived.percent, null);
  assert.equal(calculateMatchPercent([], values).percent, null);
});

test("the visual score is NOT gated by the stricter coaching-confidence floor", () => {
  /* Landmarks at 0.4 visibility: above the 0.3 measurable floor, below the
     0.5 coaching floor. The engine must refuse to COACH while the on-screen
     percentage keeps behaving exactly as it always did. */
  const values = referenceWithOffsets(bodyLandmarks(), { leftElbow: 30 });
  const dim = bodyLandmarks({ visibility: 0.4 });
  const decision = engineFor(values).analyzeFrame(dim);

  assert.equal(decision.kind, "unavailable");
  assert.equal(decision.unavailable?.reason, "low-confidence");

  const derived = matchFromDecision(decision);
  const legacy = calculateMatchPercent(dim, values);
  assert.equal(derived.percent, legacy.percent);
  assert.ok(derived.percent !== null);
});
