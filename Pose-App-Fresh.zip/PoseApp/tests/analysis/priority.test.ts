/**
 * tests/analysis/priority.test.ts — Unit 29 stage 6: PRIORITY.
 *
 * When several measurements are wrong at once exactly one correction wins,
 * and the winner must not depend on object ordering, insertion order or
 * iteration luck.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  canonicalCorrectionState,
  compareCandidates,
  measurementImportance,
  measurementToken,
  rankCandidates,
} from "../../shared/ml/analysis";
import { comparisonsFor, live } from "./fixtures";

const BASE = 100;

function candidatesFor(
  liveValues: Readonly<Record<string, number>>,
  confidences: Readonly<Record<string, number>> = {},
) {
  const ids = Object.keys(liveValues);
  const references: Record<string, number> = {};
  for (const id of ids) references[id] = BASE;
  const measurements = ids.map((id) =>
    live(id, liveValues[id] ?? BASE, confidences[id] ?? 0.9),
  );
  return rankCandidates(comparisonsFor(measurements, references));
}

test("no correctable comparison yields no candidates", () => {
  const candidates = candidatesFor({ leftElbow: BASE + 2, rightElbow: BASE - 3 });
  assert.equal(candidates.length, 0);
});

test("multiple simultaneous errors produce one ordered ranking, worst first", () => {
  const candidates = candidatesFor({
    leftElbow: BASE + 12, // minor
    rightElbow: BASE - 40, // major
    leftKnee: BASE + 30, // major, smaller than rightElbow
    rightKnee: BASE + 1, // within tolerance
  });
  assert.deepEqual(
    candidates.map((c) => c.measurementId),
    ["rightElbow", "leftKnee", "leftElbow"],
  );
  assert.equal(candidates[0]?.severity, "major");
  assert.equal(candidates[2]?.severity, "minor");
});

test("severity dominates raw magnitude ordering", () => {
  const candidates = candidatesFor({
    leftElbow: BASE + 25, // minor (at the boundary)
    rightElbow: BASE + 25.5, // major, barely
  });
  assert.equal(candidates[0]?.measurementId, "rightElbow");
  assert.equal(candidates[0]?.severity, "major");
});

test("confidence and importance weight the score", () => {
  const equalError = { leftElbow: BASE + 30, rightElbow: BASE + 30 };
  const confident = candidatesFor(equalError, { leftElbow: 0.9, rightElbow: 0.6 });
  assert.equal(confident[0]?.measurementId, "leftElbow");

  /* Same error, same confidence: the more important joint (shoulder) wins. */
  const byImportance = candidatesFor({
    leftElbow: BASE + 30,
    leftShoulder: BASE + 30,
  });
  assert.equal(byImportance[0]?.measurementId, "leftShoulder");
  assert.ok(
    measurementImportance("leftShoulder") > measurementImportance("leftElbow"),
  );
});

test("ranking is independent of input order (no insertion-order dependence)", () => {
  const references = {
    leftElbow: BASE,
    rightElbow: BASE,
    leftKnee: BASE,
    leftShoulder: BASE,
  };
  const measurements = [
    live("leftElbow", BASE + 18),
    live("rightElbow", BASE - 31),
    live("leftKnee", BASE + 44),
    live("leftShoulder", BASE - 12),
  ];
  const forward = rankCandidates(comparisonsFor(measurements, references));
  const reversed = rankCandidates(
    comparisonsFor([...measurements].reverse(), references),
  );
  const shuffled = rankCandidates(
    comparisonsFor(
      [measurements[2], measurements[0], measurements[3], measurements[1]].filter(
        (m): m is NonNullable<typeof m> => m !== undefined,
      ),
      references,
    ),
  );
  const ids = (list: readonly { measurementId: string }[]) =>
    list.map((c) => c.measurementId);
  assert.deepEqual(ids(forward), ids(reversed));
  assert.deepEqual(ids(forward), ids(shuffled));
});

test("exactly-tied candidates fall back to the canonical registry order", () => {
  const candidates = candidatesFor({
    rightShoulder: BASE + 30,
    leftShoulder: BASE + 30,
  });
  assert.equal(candidates.length, 2);
  /* MATCH_JOINTS registry lists leftShoulder before rightShoulder. */
  assert.equal(candidates[0]?.measurementId, "leftShoulder");
  const [first, second] = candidates;
  assert.ok(first !== undefined && second !== undefined);
  assert.ok(compareCandidates(first, second) < 0);
  assert.ok(compareCandidates(second, first) > 0);
});

test("low-confidence and missing comparisons cannot become candidates", () => {
  const candidates = candidatesFor(
    { leftElbow: BASE + 40, rightElbow: BASE + 15 },
    { leftElbow: 0.2, rightElbow: 0.9 },
  );
  assert.deepEqual(
    candidates.map((c) => c.measurementId),
    ["rightElbow"],
    "the bigger but untrusted error is excluded",
  );
});

test("canonical state tokens are geometric and stable", () => {
  assert.equal(measurementToken("leftElbow"), "LEFT_ELBOW");
  assert.equal(measurementToken("rightShoulder"), "RIGHT_SHOULDER");
  assert.equal(
    canonicalCorrectionState("leftElbow", "increase"),
    "LEFT_ELBOW_INCREASE",
  );
  assert.equal(
    canonicalCorrectionState("rightKnee", "decrease"),
    "RIGHT_KNEE_DECREASE",
  );
});

test("candidate state encodes the direction of the signed error", () => {
  const increase = candidatesFor({ leftElbow: BASE - 30, rightElbow: BASE });
  assert.equal(increase[0]?.state, "LEFT_ELBOW_INCREASE");
  const decrease = candidatesFor({ leftElbow: BASE + 30, rightElbow: BASE });
  assert.equal(decrease[0]?.state, "LEFT_ELBOW_DECREASE");
});

test("priority score grows with error and never silently shrinks", () => {
  let previousScore = -1;
  for (const error of [11, 15, 25, 40, 80]) {
    const candidates = candidatesFor({ leftElbow: BASE + error, rightElbow: BASE });
    const score = candidates[0]?.priorityScore ?? -1;
    assert.ok(score > previousScore, `score fell at ${error}°`);
    previousScore = score;
  }
});
