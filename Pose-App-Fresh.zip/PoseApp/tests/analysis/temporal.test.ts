/**
 * tests/analysis/temporal.test.ts — Unit 29 stage 7: TEMPORAL STABILITY.
 *
 * The failure this stage exists to prevent is LEFT → RIGHT → LEFT → RIGHT.
 * Persistence (a new state must win N consecutive frames) and hysteresis (an
 * active correction is held until the error falls below tolerance − margin,
 * and a rival must beat it by a relative score margin) are exercised here
 * with fully deterministic frame sequences — no clock, no randomness.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  ANALYSIS_STATE_EVALUATING,
  ANALYSIS_STATE_PERFECT,
  ANALYSIS_STATE_UNAVAILABLE,
  CORRECTION_PERSISTENCE_FRAMES,
  CORRECTION_RELEASE_DEGREES,
  GOOD_TOLERANCE_DEGREES,
  PERFECT_PERSISTENCE_FRAMES,
  createTemporalStabilizer,
  rankCandidates,
  type TemporalFrameInput,
} from "../../shared/ml/analysis";
import { comparisonsFor, live } from "./fixtures";

const BASE = 100;
const IDS = ["leftElbow", "rightElbow", "leftKnee", "rightKnee"] as const;

/** Build the exact input the engine hands the stabilizer for one frame. */
function frame(errors: Readonly<Record<string, number>>): TemporalFrameInput {
  const references: Record<string, number> = {};
  for (const id of IDS) references[id] = BASE;
  const comparisons = comparisonsFor(
    IDS.map((id) => live(id, BASE + (errors[id] ?? 0), 0.95)),
    references,
  );
  const candidates = rankCandidates(comparisons);
  const top = candidates[0] ?? null;
  return {
    kind: top === null ? "perfect" : "correction",
    candidateState: top === null ? ANALYSIS_STATE_PERFECT : top.state,
    topCandidate: top,
    comparisons,
  };
}

function unavailableFrame(): TemporalFrameInput {
  return {
    kind: "unavailable",
    candidateState: ANALYSIS_STATE_UNAVAILABLE,
    topCandidate: null,
    comparisons: [],
  };
}

test("a new correction must persist before it is announced", () => {
  const stabilizer = createTemporalStabilizer();
  const noisy = frame({ leftElbow: 30 });
  for (let index = 1; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    const outcome = stabilizer.push(noisy);
    assert.equal(outcome.kind, "evaluating");
    assert.equal(outcome.state, ANALYSIS_STATE_EVALUATING);
    assert.equal(outcome.status.pendingState, "LEFT_ELBOW_DECREASE");
  }
  const decided = stabilizer.push(noisy);
  assert.equal(decided.kind, "correction");
  assert.equal(decided.state, "LEFT_ELBOW_DECREASE");
  assert.equal(decided.status.framesHeld, CORRECTION_PERSISTENCE_FRAMES);
});

test("contradictory alternating frames never produce a flapping state", () => {
  const stabilizer = createTemporalStabilizer();
  const leftWorst = frame({ leftElbow: 40, rightElbow: 12 });
  const rightWorst = frame({ leftElbow: 12, rightElbow: 40 });
  const states: string[] = [];
  for (let index = 0; index < 10; index += 1) {
    states.push(stabilizer.push(index % 2 === 0 ? leftWorst : rightWorst).state);
  }
  assert.deepEqual(
    [...new Set(states)],
    [ANALYSIS_STATE_EVALUATING],
    "no contradictory state was ever announced",
  );
});

test("a single noisy frame cannot unseat a stable correction", () => {
  const stabilizer = createTemporalStabilizer();
  const stable = frame({ leftElbow: 40, rightElbow: 12 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(stable);
  }
  assert.equal(stabilizer.peek().state, "LEFT_ELBOW_DECREASE");

  const glitch = frame({ leftElbow: 40, rightElbow: 60 });
  assert.equal(stabilizer.push(glitch).state, "LEFT_ELBOW_DECREASE");
  assert.equal(stabilizer.push(stable).state, "LEFT_ELBOW_DECREASE");
});

test("a genuinely worse joint takes over after it persists", () => {
  const stabilizer = createTemporalStabilizer();
  const first = frame({ leftElbow: 40, rightElbow: 12 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(first);
  }
  const second = frame({ leftElbow: 40, rightElbow: 80 });
  for (let index = 1; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    assert.equal(stabilizer.push(second).state, "LEFT_ELBOW_DECREASE");
  }
  const switched = stabilizer.push(second);
  assert.equal(switched.state, "RIGHT_ELBOW_DECREASE");
  assert.equal(switched.correction?.measurementId, "rightElbow");
});

test("a marginally better rival never takes over (dominance margin)", () => {
  const stabilizer = createTemporalStabilizer();
  const settle = frame({ leftElbow: 40 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(settle);
  }
  /* rightElbow is 5% worse — below the 15% dominance margin. */
  const rival = frame({ leftElbow: 40, rightElbow: 42 });
  for (let index = 0; index < 12; index += 1) {
    assert.equal(stabilizer.push(rival).state, "LEFT_ELBOW_DECREASE");
  }
});

test("hysteresis holds a correction inside the tolerance band", () => {
  const stabilizer = createTemporalStabilizer();
  const strong = frame({ leftElbow: 30 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(strong);
  }
  /* Below the 10° tolerance but above the 8° release point: still held. */
  const easing = frame({ leftElbow: GOOD_TOLERANCE_DEGREES - 1 });
  const held = stabilizer.push(easing);
  assert.equal(held.state, "LEFT_ELBOW_DECREASE");
  assert.equal(held.status.heldByHysteresis, true);
  assert.equal(held.correction?.severity, "minor");
  assert.ok((held.correction?.absError ?? 0) < GOOD_TOLERANCE_DEGREES);
});

test("hysteresis boundary: at the release point held, below it released", () => {
  const settle = (stabilizer: ReturnType<typeof createTemporalStabilizer>) => {
    const strong = frame({ leftElbow: 30 });
    for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
      stabilizer.push(strong);
    }
  };

  const atRelease = createTemporalStabilizer();
  settle(atRelease);
  assert.equal(
    atRelease.push(frame({ leftElbow: CORRECTION_RELEASE_DEGREES })).state,
    "LEFT_ELBOW_DECREASE",
  );

  const belowRelease = createTemporalStabilizer();
  settle(belowRelease);
  const releasing = belowRelease.push(
    frame({ leftElbow: CORRECTION_RELEASE_DEGREES - 0.001 }),
  );
  assert.equal(releasing.state, "LEFT_ELBOW_DECREASE", "still active this frame");
  assert.equal(releasing.status.pendingState, ANALYSIS_STATE_PERFECT);
});

test("tiny fluctuations around the tolerance boundary do not flip the state", () => {
  const stabilizer = createTemporalStabilizer();
  const strong = frame({ leftElbow: 30 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(strong);
  }
  const jitter = [10.1, 9.9, 10.05, 9.95, 10.2, 9.8];
  for (const error of jitter) {
    assert.equal(stabilizer.push(frame({ leftElbow: error })).state, "LEFT_ELBOW_DECREASE");
  }
});

test("recovery to perfect once the error clears the release point", () => {
  const stabilizer = createTemporalStabilizer();
  const strong = frame({ leftElbow: 30 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(strong);
  }
  const clean = frame({});
  for (let index = 1; index < PERFECT_PERSISTENCE_FRAMES; index += 1) {
    assert.equal(stabilizer.push(clean).state, "LEFT_ELBOW_DECREASE");
  }
  const perfect = stabilizer.push(clean);
  assert.equal(perfect.kind, "perfect");
  assert.equal(perfect.state, ANALYSIS_STATE_PERFECT);
  assert.equal(perfect.correction, null);
});

test("a direction reversal is not held by hysteresis", () => {
  const stabilizer = createTemporalStabilizer();
  const positive = frame({ leftElbow: 30 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(positive);
  }
  const reversed = frame({ leftElbow: -30 });
  const first = stabilizer.push(reversed);
  assert.equal(first.state, "LEFT_ELBOW_DECREASE", "old state until the new one persists");
  assert.equal(first.status.pendingState, "LEFT_ELBOW_INCREASE");
  for (let index = 2; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(reversed);
  }
  assert.equal(stabilizer.push(reversed).state, "LEFT_ELBOW_INCREASE");
});

test("an unavailable frame silences coaching immediately", () => {
  const stabilizer = createTemporalStabilizer();
  const strong = frame({ leftElbow: 30 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(strong);
  }
  const gone = stabilizer.push(unavailableFrame());
  assert.equal(gone.kind, "unavailable");
  assert.equal(gone.state, ANALYSIS_STATE_UNAVAILABLE);
  assert.equal(gone.correction, null);
});

test("reset clears temporal memory", () => {
  const stabilizer = createTemporalStabilizer();
  const strong = frame({ leftElbow: 30 });
  for (let index = 0; index < CORRECTION_PERSISTENCE_FRAMES; index += 1) {
    stabilizer.push(strong);
  }
  assert.equal(stabilizer.peek().state, "LEFT_ELBOW_DECREASE");
  stabilizer.reset();
  assert.equal(stabilizer.peek().state, null);
  assert.equal(stabilizer.push(strong).kind, "evaluating");
});

test("the same frame sequence always produces the same state sequence", () => {
  const sequence = [
    frame({ leftElbow: 30 }),
    frame({ leftElbow: 28, rightKnee: 12 }),
    frame({ leftElbow: 31 }),
    frame({ rightKnee: 44, leftElbow: 30 }),
    frame({}),
    frame({}),
    frame({ leftKnee: 50 }),
  ];
  const run = () => {
    const stabilizer = createTemporalStabilizer();
    return sequence.map((input) => stabilizer.push(input).state);
  };
  assert.deepEqual(run(), run());
});
