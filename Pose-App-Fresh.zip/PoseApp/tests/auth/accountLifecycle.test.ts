/**
 * tests/auth/accountLifecycle.test.ts — B1 ACCOUNT DELETION + B2 PASSWORD
 * RECOVERY regression suite.
 *
 * VERIFICATION LEVEL: LOCAL ARCHITECTURE VERIFIED.
 * Everything under test is pure shared logic (shared/auth/accountLifecycle
 * + shared/auth/authFlow): no device, no Metro, no Supabase, no network.
 * It pins the policies so the mobile wiring and preview mirror cannot
 * drift:
 *
 *   DELETION
 *   · typed DELETE confirmation gates the destructive action
 *   · the data model says exactly what dies vs survives (documented keeps)
 *   · server responses classify honestly — NO FALSE SUCCESS on 200-without-
 *     ack, partial cleanup, 401/403, 4xx, 5xx, network, timeout, junk body
 *   · demo deletion is a labeled local scope, not a server claim
 *
 *   RECOVERY
 *   · deep links classify as recovery / oauth / unrelated
 *   · screen entry states resolve without redirect loops
 *   · new-password form validates (weak / mismatch / valid)
 *   · request form validates email only
 *   · neutrality + session-consistency policies stay pinned
 *
 * REAL SUPABASE VERIFIED / PHYSICAL DEVICE VERIFIED: nothing here claims
 * either — see mobile/docs/account-deletion-and-password-reset.md.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  ACCOUNT_DELETE_COPY,
  DELETE_CONFIRMATION_PHRASE,
  DELETION_DATA_SCOPE,
  MIN_PASSWORD_LENGTH,
  PASSWORD_RESET_COPY,
  PASSWORD_RESET_ROUTE,
  POST_RESET_DESTINATION,
  SERVER_DELETION_KEYS,
  classifyAuthDeepLink,
  classifyDeletionHttpResponse,
  classifyDeletionTransportError,
  deleteConfirmationError,
  recoveryAckIsAccountExistenceNeutral,
  recoveryRequestEmailError,
  recoverySessionSurvivesSessionChange,
  resolveResetPasswordEntry,
  treatmentForAuthIssue,
  validateResetForm,
} from "../../shared/index";

/* ══ B1 — deletion confirmation gate ══ */

test("deletion: exactly-typed DELETE arms", () => {
  assert.equal(deleteConfirmationError(DELETE_CONFIRMATION_PHRASE), null);
});

test("deletion: anything else keeps the action disarmed (cancel stays free)", () => {
  // Case-strict, whitespace-forgiving (mobile keyboards add trailing spaces):
  for (const typed of ["", "delete", "Delete", "DELET", "DELETEE", "DEL", "DELETE X"]) {
    assert.notEqual(deleteConfirmationError(typed), null, `expected error for "${typed}"`);
  }
  assert.equal(deleteConfirmationError("  DELETE  "), null); // pinned tolerance
});

/* ══ B1 — the deletion data model ══ */

test("deletion: auth identity + account-linked server rows are removed", () => {
  assert.deepEqual(SERVER_DELETION_KEYS, [
    "auth-identity",
    "profile-row",
    "favorites-rows",
  ]);
  const identity = DELETION_DATA_SCOPE.find((item) => item.key === "auth-identity");
  assert.equal(identity?.surface, "server");
  assert.equal(identity?.action, "delete");
  // The DB cascade (already in supabase_tables.sql) removes linkage rows.
  for (const key of ["profile-row", "favorites-rows"]) {
    const item = DELETION_DATA_SCOPE.find((row) => row.key === key);
    assert.equal(item?.action, "cascade");
  }
});

test("deletion: account-scoped local state is cleared; device data is documented-kept", () => {
  const local = DELETION_DATA_SCOPE.filter((item) => item.action === "clear-local");
  assert.deepEqual(
    local.map((item) => item.key).sort(),
    ["favorites-local-replica", "gallery-app-captures", "session-tokens"],
  );
  const kept = DELETION_DATA_SCOPE.filter((item) => item.action === "keep");
  for (const item of kept) {
    // Every keep is a DOCUMENTED decision with a non-empty reason — no
    // silent retention anywhere in the model.
    assert.ok(item.reason.length > 40, `${item.key} must document why it survives`);
  }
  // The two the task calls out explicitly:
  const devicePhotos = DELETION_DATA_SCOPE.find((item) => item.key === "system-gallery-photos");
  assert.equal(devicePhotos?.action, "keep");
  const settings = DELETION_DATA_SCOPE.find((item) => item.key === "app-settings");
  assert.equal(settings?.action, "keep");
});

/* ══ B1 — server response classification: no false success ══ */

test("deletion: only an explicit ack body counts as deleted", () => {
  const ok = classifyDeletionHttpResponse(
    200,
    JSON.stringify({ deleted: true, userId: "u1", deletedAt: "2026-01-01T00:00:00Z" }),
  );
  assert.deepEqual(ok, { kind: "deleted", deletedAt: "2026-01-01T00:00:00Z" });
});

test("deletion: bare 200s and decoy bodies are NOT success", () => {
  const cases: [number, string | null][] = [
    [200, null],
    [200, ""],
    [200, "not json"],
    [200, JSON.stringify({})],
    [200, JSON.stringify({ deleted: false })],
    [200, JSON.stringify({ deleted: "true" })], // string, not boolean
    [200, JSON.stringify({ status: "ok" })],
    [204, null],
  ];
  for (const [status, body] of cases) {
    assert.equal(
      classifyDeletionHttpResponse(status, body).kind,
      "unexpected-response",
      `status=${status} body=${String(body)}`,
    );
  }
});

test("deletion: unauthorized (401/403) keeps the session classification distinct", () => {
  assert.equal(classifyDeletionHttpResponse(401, null).kind, "unauthorized");
  assert.equal(classifyDeletionHttpResponse(403, "{}").kind, "unauthorized");
});

test("deletion: other 4xx is a rejection, 5xx is a backend failure", () => {
  assert.equal(classifyDeletionHttpResponse(409, "{}").kind, "rejected");
  assert.equal(classifyDeletionHttpResponse(422, "{}").kind, "rejected");
  assert.equal(classifyDeletionHttpResponse(500, null).kind, "backend-failure");
  assert.equal(classifyDeletionHttpResponse(503, "{}").kind, "backend-failure");
});

test("deletion: transport + timeout classify retryably, never as success", () => {
  assert.equal(classifyDeletionHttpResponse(null, null).kind, "network");
  assert.equal(
    classifyDeletionTransportError(new TypeError("Network request failed")).kind,
    "network",
  );
  const abort = new Error("aborted");
  abort.name = "AbortError";
  assert.equal(classifyDeletionTransportError(abort).kind, "timeout");
  const timedOut = new Error("deadline");
  timedOut.name = "TimeoutError";
  assert.equal(classifyDeletionTransportError(timedOut).kind, "timeout");
});

test("deletion: failure codes land as inline form errors, never silent", () => {
  for (const code of [
    "session-required",
    "server-unavailable",
    "timeout",
    "recovery-expired",
    "network",
  ] as const) {
    assert.equal(treatmentForAuthIssue(code), "form-error");
  }
});

/* ══ B1 — copy honesty ══ */

test("deletion: copy states permanence and the demo/liveness distinction", () => {
  assert.match(ACCOUNT_DELETE_COPY.finality, /permanent/i);
  assert.match(ACCOUNT_DELETE_COPY.demoNote, /Demo backend/);
  assert.match(ACCOUNT_DELETE_COPY.demoNote, /this device only/i);
  assert.match(ACCOUNT_DELETE_COPY.liveNote, /server-side/i);
  // Deletion ≠ logout: success copy says deleted, not "signed out" alone.
  assert.match(ACCOUNT_DELETE_COPY.successBody, /permanently removed/i);
});

/* ══ B2 — deep-link classification ══ */

test("recovery: reset-route links classify as recovery (with and without code)", () => {
  assert.deepEqual(
    classifyAuthDeepLink(`smartphoto://${PASSWORD_RESET_ROUTE}?code=abc123`),
    { kind: "recovery", code: "abc123" },
  );
  assert.deepEqual(classifyAuthDeepLink(`smartphoto://${PASSWORD_RESET_ROUTE}`), {
    kind: "recovery",
    code: null,
  });
  // type=recovery alone (any route) also flags recovery (Supabase implicit links)
  assert.deepEqual(classifyAuthDeepLink("smartphoto://auth?type=recovery"), {
    kind: "recovery",
    code: null,
  });
  // Implicit-style fragment tokens
  assert.deepEqual(
    classifyAuthDeepLink(`smartphoto://${PASSWORD_RESET_ROUTE}#type=recovery&code=xyz`),
    { kind: "recovery", code: "xyz" },
  );
});

test("recovery: OAuth codes still classify as oauth; junk never reaches the exchanger", () => {
  assert.deepEqual(classifyAuthDeepLink("smartphoto://auth?code=oauthcode"), {
    kind: "oauth-code",
    code: "oauthcode",
  });
  assert.deepEqual(classifyAuthDeepLink(""), { kind: "unrelated" });
  assert.deepEqual(classifyAuthDeepLink("smartphoto://home"), { kind: "unrelated" });
  assert.deepEqual(classifyAuthDeepLink("smartphoto://auth"), { kind: "unrelated" });
  assert.deepEqual(classifyAuthDeepLink("not a url at all"), { kind: "unrelated" });
});

/* ══ B2 — reset-screen state machine (no redirect loop, no fake states) ══ */

test("recovery: entry — request form by default, new-password with a live session", () => {
  assert.deepEqual(resolveResetPasswordEntry(false, false), { kind: "request-link" });
  assert.deepEqual(resolveResetPasswordEntry(true, false), { kind: "new-password" });
  assert.deepEqual(resolveResetPasswordEntry(true, true), { kind: "new-password" });
});

test("recovery: arriving via a dead link explains itself instead of looping", () => {
  assert.deepEqual(resolveResetPasswordEntry(false, true), { kind: "link-invalid" });
});

test("recovery: post-reset destination is the tab shell, never back to /auth", () => {
  assert.equal(POST_RESET_DESTINATION, "/(tabs)");
});

/* ══ B2 — new-password form policy ══ */

test("recovery: weak / short password is rejected before submit", () => {
  const short = "a".repeat(MIN_PASSWORD_LENGTH - 1);
  const result = validateResetForm({ password: short, confirmPassword: short });
  assert.equal(result.submittable, false);
  assert.notEqual(result.errors.password, null);
  assert.equal(result.errors.confirmPassword, null); // weak password, not mismatch
});

test("recovery: mismatched confirmation blocks submit", () => {
  const result = validateResetForm({ password: "longenough1", confirmPassword: "longenough2" });
  assert.equal(result.submittable, false);
  assert.equal(result.errors.password, null);
  assert.notEqual(result.errors.confirmPassword, null);
});

test("recovery: matching strong passwords submit", () => {
  const result = validateResetForm({ password: "longenough1", confirmPassword: "longenough1" });
  assert.equal(result.submittable, true);
  assert.deepEqual(result.errors, { password: null, confirmPassword: null });
});

test("recovery: request form validates email only (never the account state)", () => {
  assert.notEqual(recoveryRequestEmailError("not-an-email"), null);
  assert.equal(recoveryRequestEmailError("Person@Example.com "), null);
});

/* ══ B2 — consistency + neutrality policies ══ */

test("recovery: session changes ALWAYS close a recovery context", () => {
  assert.equal(recoverySessionSurvivesSessionChange(), false);
});

test("recovery: acknowledgement copy is account-existence neutral", () => {
  assert.equal(recoveryAckIsAccountExistenceNeutral(), true);
  // The ack must read the same for existing, unknown and deleted accounts.
  assert.match(PASSWORD_RESET_COPY.requestSentBody, /If an account exists/);
  assert.doesNotMatch(PASSWORD_RESET_COPY.requestSentBody, /registered|found|no account/i);
});

test("recovery: demo mode stays honest — no real-email claims", () => {
  assert.match(PASSWORD_RESET_COPY.requestDemoNote, /no real email/i);
  assert.match(PASSWORD_RESET_COPY.newDemoNote, /Demo backend/);
});
