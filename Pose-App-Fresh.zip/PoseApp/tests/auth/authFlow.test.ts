/**
 * tests/auth/authFlow.test.ts — CREATE-ACCOUNT REGRESSION SUITE.
 *
 * Everything under test is pure (shared/auth/authFlow.ts): no device, no
 * Metro, no Supabase, no MMKV. Each case pins a promise the /auth screen
 * makes to the user:
 *
 *   · "Create Account opens the signup form"                → entry resolution
 *   · "the signup form STAYS — no invisible navigation"     → exit policy
 *   · "a stale session can never hijack a fresh auth visit" → already-signed-in
 *   · "only a completed auth action leaves the screen"      → oauth-only exit
 *   · "email confirmation is a state, not an error"         → outcome treatment
 *   · "the form validates before it submits"                → validation matrix
 *
 * These functions are the SAME ones mobile/app's AuthScreen and the preview
 * mirror consume — the tests exercise the real decision logic, not a copy.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  AUTH_CONFIRM_ERROR,
  AUTH_COPY,
  AUTH_EMAIL_ERROR,
  AUTH_NAME_ERROR,
  AUTH_PASSWORD_ERROR,
  MIN_PASSWORD_LENGTH,
  NO_FORM_ERRORS,
  confirmPasswordError,
  displayNameError,
  emailError,
  isDuplicateEmailMessage,
  normalizeEmail,
  parseAuthModeParam,
  passwordError,
  resolveAuthEntry,
  shouldExitAfterSessionChange,
  treatmentForAuthIssue,
  validateAuthForm,
} from "../../shared/index";

/* ── Entry: /auth?mode= deep links ─────────────────────────────────────── */

test("mode param: sign-up opens account creation directly", () => {
  assert.equal(parseAuthModeParam("sign-up"), "sign-up");
});

test("mode param: sign-in, arrays, junk and absence fall back to sign-in", () => {
  assert.equal(parseAuthModeParam("sign-in"), "sign-in");
  assert.equal(parseAuthModeParam(["sign-up"]), "sign-up");
  assert.equal(parseAuthModeParam("whatever"), "sign-in");
  assert.equal(parseAuthModeParam(undefined), "sign-in");
  assert.equal(parseAuthModeParam(null), "sign-in");
});

test("entry: unauthenticated visitor always gets the form in the requested mode", () => {
  assert.deepEqual(resolveAuthEntry(false, "sign-in"), { kind: "form", mode: "sign-in" });
  assert.deepEqual(resolveAuthEntry(false, "sign-up"), { kind: "form", mode: "sign-up" });
});

test("entry: an EXISTING session resolves to already-signed-in, never to a form", () => {
  // A signed-in user must not see a pretend-logged-out signup form…
  assert.deepEqual(resolveAuthEntry(true, "sign-up"), { kind: "already-signed-in" });
  assert.deepEqual(resolveAuthEntry(true, "sign-in"), { kind: "already-signed-in" });
});

/* ── THE REPORTED BUG — mandatory regression coverage ──────────────────── */

test("REGRESSION: Create Account stays visible — an existing session never exits /auth", () => {
  // Reproduces the exact reported chain: existing (e.g. stale demo) session →
  // /auth opens → the old mount effect saw `session` and auto-exited to
  // /(tabs) before the form could ever remain visible. The fixed policy: a
  // session that existed AT ENTRY is never grounds for an automatic exit.
  assert.equal(shouldExitAfterSessionChange(true, true, false), false);
  assert.equal(shouldExitAfterSessionChange(true, true, true), false);
});

test("REGRESSION: stale demo session scenario — entry decision + exit policy agree", () => {
  // The full stale-session matrix a developer hits after any earlier demo
  // sign-in persisted `demo.auth.session` to MMKV:
  const entry = resolveAuthEntry(true, "sign-up");
  assert.equal(entry.kind, "already-signed-in"); // clear state…
  assert.equal(shouldExitAfterSessionChange(true, true, false), false); // …not a silent bounce
});

test("exit policy: no session at entry + none appearing → stay", () => {
  assert.equal(shouldExitAfterSessionChange(false, false, false), false);
});

test("exit policy: an UNPROMPTED session appearing mid-visit does not navigate", () => {
  // e.g. a persisted session finishing its restore while the user types;
  // the screen swaps to the already-signed-in state instead of navigating.
  assert.equal(shouldExitAfterSessionChange(false, true, false), false);
});

test("exit policy: ONLY the OAuth return this screen initiated may navigate away", () => {
  assert.equal(shouldExitAfterSessionChange(false, true, true), true);
});

test("exit policy: totality over the (had-at-entry × has-now × oauth) cube", () => {
  // Exactly one combination in the whole space navigates.
  let navigations = 0;
  for (const had of [false, true])
    for (const now of [false, true])
      for (const oauth of [false, true])
        if (shouldExitAfterSessionChange(had, now, oauth)) navigations += 1;
  assert.equal(navigations, 1);
});

/* ── Outcome treatment: confirmation is a state, not an error ──────────── */

test("outcome: signup success-without-session is classified confirmation-required", () => {
  assert.equal(treatmentForAuthIssue("email-not-confirmed"), "confirmation-required");
});

test("outcome: every failure code stays an inline form error", () => {
  for (const code of [
    "invalid-credentials",
    "email-in-use",
    "weak-password",
    "cancelled",
    "not-configured",
    "network",
    "unknown",
  ] as const) {
    assert.equal(treatmentForAuthIssue(code), "form-error");
  }
});

test("duplicate-email phrases map to the email-in-use code", () => {
  assert.equal(isDuplicateEmailMessage("User already registered"), true);
  assert.equal(isDuplicateEmailMessage("email address is already in use"), true);
  assert.equal(isDuplicateEmailMessage("Invalid login credentials"), false);
});

/* ── Validation: trim / normalize field by field ───────────────────────── */

test("email: trims and lower-cases before anything else", () => {
  assert.equal(normalizeEmail("  Ada@Example.COM "), "ada@example.com");
});

test("email: valid addresses pass, broken ones explain themselves", () => {
  assert.equal(emailError("ada@example.com"), null);
  assert.equal(emailError("  ada@example.com  "), null); // trimmed inside
  assert.equal(emailError("ada"), AUTH_EMAIL_ERROR);
  assert.equal(emailError("ada@"), AUTH_EMAIL_ERROR);
  assert.equal(emailError("ada example.com"), AUTH_EMAIL_ERROR);
  assert.equal(emailError(""), AUTH_EMAIL_ERROR);
});

test("password: length-only policy, never trimmed (a space may be intentional)", () => {
  assert.equal(passwordError("a".repeat(MIN_PASSWORD_LENGTH)), null);
  assert.equal(passwordError("a".repeat(MIN_PASSWORD_LENGTH - 1)), AUTH_PASSWORD_ERROR);
  assert.equal(passwordError(""), AUTH_PASSWORD_ERROR);
  assert.equal(passwordError("  pad me  "), null); // 9 incl. spaces — kept as-is
});

test("confirm password: must match exactly", () => {
  assert.equal(confirmPasswordError("secret-88", "secret-88"), null);
  assert.equal(confirmPasswordError("secret-88", "secret-89"), AUTH_CONFIRM_ERROR);
  assert.equal(confirmPasswordError("secret-88", ""), AUTH_CONFIRM_ERROR);
});

test("display name: optional — empty is valid, one character is not", () => {
  assert.equal(displayNameError(""), null);
  assert.equal(displayNameError("   "), null);
  assert.equal(displayNameError("Ada"), null);
  assert.equal(displayNameError("A"), AUTH_NAME_ERROR);
});

test("form: sign-in ignores display-name and confirm-password entirely", () => {
  const { errors, submittable } = validateAuthForm("sign-in", {
    displayName: "A", // invalid, not collected in this mode
    email: "ada@example.com",
    password: "secret-88",
    confirmPassword: "different", // irrelevant in this mode
  });
  assert.equal(submittable, true);
  assert.deepEqual(errors, NO_FORM_ERRORS);
});

test("form: valid sign-up is submittable end-to-end", () => {
  const { errors, submittable } = validateAuthForm("sign-up", {
    displayName: "Ada",
    email: "ada@example.com",
    password: "secret-88",
    confirmPassword: "secret-88",
  });
  assert.equal(submittable, true);
  assert.deepEqual(errors, NO_FORM_ERRORS);
});

test("form: sign-up flags each broken field and blocks submission", () => {
  const { errors, submittable } = validateAuthForm("sign-up", {
    displayName: "A",
    email: "not-an-email",
    password: "short",
    confirmPassword: "shorter",
  });
  assert.equal(submittable, false);
  assert.equal(errors.displayName, AUTH_NAME_ERROR);
  assert.equal(errors.email, AUTH_EMAIL_ERROR);
  assert.equal(errors.password, AUTH_PASSWORD_ERROR);
  assert.equal(errors.confirmPassword, AUTH_CONFIRM_ERROR);
});

test("form: untouched sign-up is not submittable (no accidental account)", () => {
  const { submittable } = validateAuthForm("sign-up", {
    displayName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  assert.equal(submittable, false);
});

/* ── Copy: the two modes are unmistakably different ────────────────────── */

test("copy: signup title and CTA are unambiguous, distinct from sign-in", () => {
  assert.equal(AUTH_COPY.signUpTitle, "Create your account");
  assert.equal(AUTH_COPY.submitSignUp, "Create Account");
  assert.notEqual(AUTH_COPY.signUpTitle, AUTH_COPY.signInTitle);
  assert.notEqual(AUTH_COPY.submitSignUp, AUTH_COPY.submitSignIn);
  assert.equal(AUTH_COPY.modeSignUp, "Create Account");
});
