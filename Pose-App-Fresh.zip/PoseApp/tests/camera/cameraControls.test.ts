/**
 * tests/camera/cameraControls.test.ts — CAMERA CONTROLS & BRIGHTNESS.
 *
 * Everything under test is pure: no device, no camera, no Skia, no MediaPipe.
 * The point of these cases is not coverage for its own sake — each one pins
 * down a claim the feature makes to the user:
 *
 *   · "default means your photo is untouched"        → identity matrix
 *   · "brighter is brighter, darker is darker"       → monotonic gain
 *   · "the preview matches what you will get"        → scrim derived from the
 *                                                       same gain, same sign
 *   · "the control cannot get stuck out of range"    → clamping, totality
 *   · "a control that cannot work says so"           → torch on front camera
 *   · "we never invent a camera mode"                → flash cycle is exactly
 *                                                       off → auto → on
 *   · "both languages say the same thing"            → copy parity
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  BRIGHTNESS_DEFAULT,
  BRIGHTNESS_MAX,
  BRIGHTNESS_MECHANISM,
  BRIGHTNESS_MIN,
  brightnessBadge,
  brightnessColorMatrix,
  brightnessGain,
  brightnessIsIdentity,
  brightnessPreviewScrim,
  clampBrightness,
  FLASH_CYCLE,
  isBrightnessDefault,
  nextFlashMode,
  resolveLighting,
  torchSupported,
  type FlashModeValue,
} from "../../shared/camera/cameraControls";
import { cameraStatusCopyFor } from "../../shared/camera/cameraStatusCopy";

const LEVELS = [-3, -2, -1, 0, 1, 2, 3];

test("the default detent is an exact no-op on the photograph", () => {
  assert.equal(BRIGHTNESS_DEFAULT, 0);
  assert.equal(brightnessGain(0), 1);
  assert.equal(brightnessIsIdentity(0), true);
  assert.deepEqual(
    brightnessColorMatrix(0),
    [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],
  );
  assert.deepEqual(brightnessPreviewScrim(0), { mode: "none", opacity: 0 });
  assert.equal(brightnessBadge(0), null, "default must show no number at all");
});

test("gain rises strictly with the detent and never inverts the image", () => {
  for (let i = 1; i < LEVELS.length; i += 1) {
    const lower = brightnessGain(LEVELS[i - 1]);
    const higher = brightnessGain(LEVELS[i]);
    assert.ok(higher > lower, `gain must rise from ${LEVELS[i - 1]} to ${LEVELS[i]}`);
  }
  assert.ok(brightnessGain(BRIGHTNESS_MIN) > 0, "the darkest step is still an image");
  assert.ok(brightnessGain(BRIGHTNESS_MAX) < 2, "the brightest step is not a white-out");
});

test("the color matrix is well-formed and only scales RGB", () => {
  for (const level of LEVELS) {
    const matrix = brightnessColorMatrix(level);
    assert.equal(matrix.length, 20, "Skia expects a 4x5 matrix");
    const gain = brightnessGain(level);
    assert.equal(matrix[0], gain);
    assert.equal(matrix[6], gain);
    assert.equal(matrix[12], gain);
    assert.equal(matrix[18], 1, "alpha must never be scaled");
    /* No additive lift anywhere: black stays black instead of greying out. */
    assert.equal(matrix[4], 0);
    assert.equal(matrix[9], 0);
    assert.equal(matrix[14], 0);
    assert.equal(matrix[19], 0);
  }
});

test("the live preview wash agrees with the adjustment in direction and size", () => {
  for (const level of LEVELS) {
    const scrim = brightnessPreviewScrim(level);
    const gain = brightnessGain(level);
    if (level === 0) {
      assert.equal(scrim.mode, "none");
    } else if (level > 0) {
      assert.equal(scrim.mode, "lighten");
      assert.ok(gain > 1);
    } else {
      assert.equal(scrim.mode, "darken");
      assert.ok(gain < 1);
    }
    assert.ok(scrim.opacity >= 0 && scrim.opacity <= 0.3, "the subject stays visible");
  }
  assert.ok(
    brightnessPreviewScrim(3).opacity > brightnessPreviewScrim(1).opacity,
    "a bigger adjustment must look bigger",
  );
});

test("the detent cannot be pushed out of range, by any input", () => {
  assert.equal(clampBrightness(99), BRIGHTNESS_MAX);
  assert.equal(clampBrightness(-99), BRIGHTNESS_MIN);
  assert.equal(clampBrightness(1.4), 1);
  assert.equal(clampBrightness(Number.NaN), BRIGHTNESS_DEFAULT);
  assert.equal(clampBrightness(Number.POSITIVE_INFINITY), BRIGHTNESS_DEFAULT);
  assert.equal(clampBrightness(undefined), BRIGHTNESS_DEFAULT);
  assert.equal(clampBrightness("2" as unknown), BRIGHTNESS_DEFAULT);
  assert.equal(isBrightnessDefault("nonsense" as unknown), true);
});

test("the badge states direction, never a bare number", () => {
  assert.equal(brightnessBadge(2), "+2");
  assert.equal(brightnessBadge(-2), "-2");
  assert.equal(brightnessBadge(0), null);
});

test("the mechanism is recorded as photo processing, not sensor exposure", () => {
  /* This is the guard against the feature quietly re-describing itself: the
     camera foundation has no exposure API, so nothing may claim one. */
  assert.equal(BRIGHTNESS_MECHANISM, "photo-processing");
});

test("torch is offered only where a lamp exists, and says why when it is not", () => {
  assert.equal(torchSupported("back"), true);
  assert.equal(torchSupported("front"), false);

  const onFront = resolveLighting({
    facing: "front",
    flash: "off",
    torchRequested: true,
    sessionLive: true,
  });
  assert.equal(onFront.torchOn, false, "no lamp, no light");
  assert.equal(onFront.torchEnabled, false);
  assert.equal(onFront.torchBlockedReason, "front-camera");

  const paused = resolveLighting({
    facing: "back",
    flash: "off",
    torchRequested: true,
    sessionLive: false,
  });
  assert.equal(paused.torchOn, false, "a released session cannot hold a torch lit");
  assert.equal(paused.torchBlockedReason, "session-not-live");
});

test("a torch request survives a flip to the selfie camera and back", () => {
  const request = { flash: "off" as FlashModeValue, torchRequested: true, sessionLive: true };
  assert.equal(resolveLighting({ ...request, facing: "back" }).torchOn, true);
  assert.equal(resolveLighting({ ...request, facing: "front" }).torchOn, false);
  assert.equal(resolveLighting({ ...request, facing: "back" }).torchOn, true);
});

test("flash is superseded — not silently ignored — while the torch is lit", () => {
  const lit = resolveLighting({
    facing: "back",
    flash: "auto",
    torchRequested: true,
    sessionLive: true,
  });
  assert.equal(lit.flashSupersededByTorch, true);
  assert.equal(lit.flash, "auto", "the user's flash choice is remembered, not reset");

  const dark = resolveLighting({
    facing: "back",
    flash: "auto",
    torchRequested: false,
    sessionLive: true,
  });
  assert.equal(dark.flashSupersededByTorch, false);
});

test("the flash cycle is exactly the three modes the camera supports", () => {
  assert.deepEqual([...FLASH_CYCLE], ["off", "auto", "on"]);
  assert.equal(nextFlashMode("off"), "auto");
  assert.equal(nextFlashMode("auto"), "on");
  assert.equal(nextFlashMode("on"), "off");
});

test("both coaching languages describe the controls, and describe them differently", () => {
  const en = cameraStatusCopyFor("en");
  const hi = cameraStatusCopyFor("hi");

  for (const copy of [en, hi]) {
    assert.ok(copy.brightnessTitle.length > 0);
    assert.ok(copy.brightnessNote.length > 0, "the honesty note is never empty");
    assert.ok(copy.brightnessReset.length > 0);
    assert.ok(copy.torchTitle.length > 0);
    for (const level of LEVELS) {
      assert.ok(copy.brightnessValue(level).length > 0);
    }
    for (const mode of FLASH_CYCLE) {
      assert.ok(copy.flashValue(mode).length > 0);
    }
    assert.equal(copy.torchBlocked("none"), "", "a usable control explains nothing");
    assert.ok(copy.torchBlocked("front-camera").length > 0);
    assert.ok(copy.torchBlocked("session-not-live").length > 0);
  }

  assert.notEqual(en.brightnessTitle, hi.brightnessTitle);
  assert.notEqual(en.brightnessNote, hi.brightnessNote);
  assert.notEqual(
    en.brightnessValue(0),
    en.brightnessValue(2),
    "default and adjusted must read differently",
  );
  /* The default reads as a word, never as "0". */
  assert.ok(!en.brightnessValue(0).includes("0"));
  assert.ok(en.brightnessValue(-2).includes("2"));
});
