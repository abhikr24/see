/**
 * tests/camera/cameraExposure.test.ts — REAL camera exposure (D1).
 *
 * Everything under test is pure: no device, no camera, no Skia, no native
 * bridge. Each case pins a claim the feature makes somewhere the user can
 * feel it:
 *
 *   · "the default is automatic exposure"              → level 0 ⇒ EV 0
 *   · "brighter is brighter"                           → monotonic EV
 *   · "hardware never receives an invalid value"       → clamping, snapping,
 *                                                         NaN/malformed input
 *   · "the badge never promises a stop the sensor
 *      cannot deliver"                                 → device-window levels
 *   · "switching cameras keeps the intent, not the
 *      contract breach"                                → reconciliation
 *   · "the two mechanisms never double the picture"    → capture routing
 *   · "a corrupt native report cannot hurt anything"   → sanitisation
 *   · "the word 'exposure' is earned, not borrowed"    → mechanism-aware copy
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  EXPOSURE_EV_PER_LEVEL,
  EXPOSURE_UNSUPPORTED,
  captureBrightnessLevel,
  clampExposureEV,
  clampExposureLevel,
  exposureAvailableLevels,
  exposureCompensationProp,
  exposureLevelToEV,
  normalizeExposureCapabilities,
  reconcileExposureLevel,
  resolveExposureMechanism,
  type ExposureCapabilities,
} from "../../shared/camera/cameraExposure";
import { cameraStatusCopyFor } from "../../shared/camera/cameraStatusCopy";

/** A realistic CameraX device: ±2 EV in half-stop steps. */
const CAMERA_X_TYPICAL: ExposureCapabilities = {
  supported: true,
  minEV: -2,
  maxEV: 2,
  stepEV: 0.5,
  currentEV: 0,
};

/** A continuous float-bias device (the iOS shape): ±8 EV, no quantisation. */
const CONTINUOUS_IOS: ExposureCapabilities = {
  supported: true,
  minEV: -8,
  maxEV: 8,
  stepEV: 0,
  currentEV: 0,
};

/* ───────────────────────────── the logical scale ───────────────────────── */

test("the default detent is exactly automatic exposure", () => {
  assert.equal(exposureLevelToEV(0), 0);
  assert.equal(exposureCompensationProp(0, CAMERA_X_TYPICAL), 0);
  assert.equal(EXPOSURE_EV_PER_LEVEL, 0.5, "one detent is half a stop");
});

test("EV rises monotonically with the detent", () => {
  const levels = [-3, -2, -1, 0, 1, 2, 3];
  for (let i = 1; i < levels.length; i += 1) {
    assert.ok(
      exposureLevelToEV(levels[i]) > exposureLevelToEV(levels[i - 1]),
      "brighter detents must bias brighter",
    );
  }
  assert.equal(exposureLevelToEV(2), 1);
  assert.equal(exposureLevelToEV(-3), -1.5);
});

/* ───────────────────── mechanism selection & the fallback ──────────────── */

test("the mechanism follows the capability report, never an assumption", () => {
  assert.equal(resolveExposureMechanism(null), "photo-processing");
  assert.equal(resolveExposureMechanism(EXPOSURE_UNSUPPORTED), "photo-processing");
  assert.equal(
    resolveExposureMechanism({ ...EXPOSURE_UNSUPPORTED, supported: true, minEV: -2, maxEV: 2 }),
    "native-exposure",
  );
});

/* ─────────────────────── clamping to the real device ────────────────────── */

test("requested EV is clamped to the device's window and snapped to its step", () => {
  assert.equal(clampExposureEV(1.5, CAMERA_X_TYPICAL), 1.5);
  assert.equal(clampExposureEV(1.2, CAMERA_X_TYPICAL), 1, "snaps onto half stops");
  assert.equal(clampExposureEV(9, CAMERA_X_TYPICAL), 2, "beyond the window clamps");
  assert.equal(clampExposureEV(-9, CAMERA_X_TYPICAL), -2);
  assert.equal(clampExposureEV(-8, CONTINUOUS_IOS), -8, "no quantisation on iOS shape");
  assert.equal(clampExposureEV(0.123, CONTINUOUS_IOS), 0.123);
});

test("invalid requests and absent hardware collapse to neutral, never to garbage", () => {
  assert.equal(clampExposureEV(Number.NaN, CAMERA_X_TYPICAL), 0);
  assert.equal(clampExposureEV(undefined, CAMERA_X_TYPICAL), 0);
  assert.equal(clampExposureEV("2", CAMERA_X_TYPICAL), 0);
  assert.equal(clampExposureEV(Number.POSITIVE_INFINITY, CAMERA_X_TYPICAL), 0);
  assert.equal(clampExposureEV(2, null), 0, "no bridge, no bias");
  assert.equal(clampExposureEV(2, EXPOSURE_UNSUPPORTED), 0);
});

test("the offered detents narrow to what the sensor can honestly deliver", () => {
  assert.deepEqual(exposureAvailableLevels(null), { minLevel: -3, maxLevel: 3 });
  assert.deepEqual(
    exposureAvailableLevels({ ...CAMERA_X_TYPICAL, minEV: -1, maxEV: 1 }),
    { minLevel: -2, maxLevel: 2 },
    "±1 EV can only promise ±2 detents",
  );
  assert.deepEqual(
    exposureAvailableLevels({ ...CAMERA_X_TYPICAL, minEV: -0.5, maxEV: 2 }),
    { minLevel: -1, maxLevel: 3 },
    "asymmetric windows clamp per side",
  );
  assert.deepEqual(
    exposureAvailableLevels(CONTINUOUS_IOS),
    { minLevel: -3, maxLevel: 3 },
    "a wide window still respects the slider's own seven detents",
  );
});

test("clamping a detent through a narrow device window can silence, never lie", () => {
  const narrow: ExposureCapabilities = { ...CAMERA_X_TYPICAL, minEV: -0.5, maxEV: 0.5 };
  assert.equal(clampExposureLevel(3, narrow), 1);
  assert.equal(clampExposureLevel(-3, narrow), -1);
  assert.equal(clampExposureLevel(0, narrow), 0);
  assert.equal(clampExposureLevel(3, null), 3, "photo processing owns the full range");
  assert.equal(clampExposureLevel(Number.NaN, narrow), 0);
});

/* ─────────────────────────── camera switching ───────────────────────────── */

test("switching cameras keeps the intent and re-clamps the number", () => {
  /* rear camera, user chose +3 (1.5 EV) → switch to a front module whose
     window is ±0.5 EV: the intent "+3 brighter" survives as long as the
     detent can move; the delivered number clamps to the new window. */
  const front: ExposureCapabilities = { ...CAMERA_X_TYPICAL, minEV: -0.5, maxEV: 0.5 };
  assert.equal(reconcileExposureLevel(3, front), 1);
  assert.equal(exposureCompensationProp(1, front), 0.5);
  /* …and switching BACK restores the intent untouched. */
  assert.equal(reconcileExposureLevel(3, CAMERA_X_TYPICAL), 3);
  assert.equal(exposureCompensationProp(3, CAMERA_X_TYPICAL), 1.5);
  /* A value already inside the new window survives unchanged. */
  assert.equal(reconcileExposureLevel(-2, CAMERA_X_TYPICAL), -2);
});

/* ─────────────────────── the native prop derivation ─────────────────────── */

test("the native prop is EV-clamped EV, and exactly 0 without a bridge", () => {
  assert.equal(exposureCompensationProp(2, CAMERA_X_TYPICAL), 1);
  assert.equal(exposureCompensationProp(-3, CAMERA_X_TYPICAL), -1.5);
  assert.equal(exposureCompensationProp(0, null), 0, "unpatched build: never fake a bias");
  assert.equal(exposureCompensationProp(3, EXPOSURE_UNSUPPORTED), 0);
  const narrow: ExposureCapabilities = { ...CAMERA_X_TYPICAL, minEV: 0, maxEV: 1 };
  assert.equal(exposureCompensationProp(-3, narrow), 0, "device that cannot darken clamps");
});

/* ─────────────────── capture routing: never double the photo ────────────── */

test("native exposure keeps the pixel pipeline at identity", () => {
  assert.equal(captureBrightnessLevel("native-exposure", 3), 0);
  assert.equal(captureBrightnessLevel("native-exposure", -3), 0);
  assert.equal(
    captureBrightnessLevel("photo-processing", 3),
    3,
    "the fallback still bakes the detent into the JPEG",
  );
  assert.equal(captureBrightnessLevel("photo-processing", -2), -2);
  assert.equal(captureBrightnessLevel("photo-processing", Number.NaN), 0);
});

/* ─────────────────── malformed native reports cannot hurt ───────────────── */

test("capability payloads are sanitised: anything doubtful is 'unsupported'", () => {
  assert.deepEqual(normalizeExposureCapabilities(null), EXPOSURE_UNSUPPORTED);
  assert.deepEqual(normalizeExposureCapabilities(undefined), EXPOSURE_UNSUPPORTED);
  assert.deepEqual(normalizeExposureCapabilities("yes"), EXPOSURE_UNSUPPORTED);
  assert.deepEqual(normalizeExposureCapabilities(7), EXPOSURE_UNSUPPORTED);
  assert.deepEqual(
    normalizeExposureCapabilities({ supported: false }),
    EXPOSURE_UNSUPPORTED,
    "an honest 'no' is honoured",
  );

  /* Missing or mistyped fields. */
  assert.equal(
    normalizeExposureCapabilities({ supported: true }).supported,
    false,
  );
  assert.equal(
    normalizeExposureCapabilities({ supported: true, minEV: "-2", maxEV: 2, stepEV: 0.5 })
      .supported,
    false,
    "strings are not numbers",
  );
  assert.equal(
    normalizeExposureCapabilities({ supported: true, minEV: 3, maxEV: 2, stepEV: 0.5 })
      .supported,
    false,
    "an inverted window is corruption, not a camera",
  );
  assert.equal(
    normalizeExposureCapabilities({ supported: true, minEV: -2, maxEV: 2, stepEV: -0.5 })
      .supported,
    false,
    "a negative step is corruption",
  );
  assert.equal(
    normalizeExposureCapabilities({ supported: true, minEV: Number.NaN, maxEV: 2, stepEV: 0.5 })
      .supported,
    false,
    "NaN poisons the whole report",
  );

  /* A clean report passes through untouched, extras ignored. */
  const clean = normalizeExposureCapabilities({
    supported: true,
    minEV: -2,
    maxEV: 2,
    stepEV: 0.5,
    currentEV: 1,
    vendorTag: "whatever",
  });
  assert.deepEqual(clean, { supported: true, minEV: -2, maxEV: 2, stepEV: 0.5, currentEV: 1 });

  /* The raw RN wrapper shape (nativeEvent) is the view's job to unwrap — a
     bare wrapper must therefore READ as unsupported rather than as data. */
  assert.equal(
    normalizeExposureCapabilities({ nativeEvent: { supported: true, minEV: -2, maxEV: 2, stepEV: 0.5 } })
      .supported,
    false,
  );
});

/* ─────────────────── mechanism-aware, bilingual copy ────────────────────── */

test("the word exposure is earned by the native mechanism, in both languages", () => {
  for (const language of ["en", "hi"] as const) {
    const copy = cameraStatusCopyFor(language);
    assert.ok(copy.brightnessTitleFor("native-exposure").length > 0);
    assert.ok(copy.brightnessTitleFor("photo-processing").length > 0);
    assert.notEqual(
      copy.brightnessTitleFor("native-exposure"),
      copy.brightnessTitleFor("photo-processing"),
      "the two mechanisms must never borrow each other's name",
    );
    assert.notEqual(
      copy.brightnessNoteFor("native-exposure"),
      copy.brightnessNoteFor("photo-processing"),
      "the two mechanisms must never borrow each other's claim",
    );
    /* The legacy single strings stay as the photo-processing flavour so
       existing callers keep telling the truth they always told. */
    assert.equal(copy.brightnessTitle, copy.brightnessTitleFor("photo-processing"));
    assert.equal(copy.brightnessNote, copy.brightnessNoteFor("photo-processing"));
  }

  const en = cameraStatusCopyFor("en");
  const hi = cameraStatusCopyFor("hi");
  assert.notEqual(en.brightnessTitleFor("native-exposure"), hi.brightnessTitleFor("native-exposure"));
  assert.notEqual(en.brightnessNoteFor("native-exposure"), hi.brightnessNoteFor("native-exposure"));
});
