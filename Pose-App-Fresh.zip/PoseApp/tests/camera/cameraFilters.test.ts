/**
 * tests/camera/cameraFilters.test.ts — LOOKS & FILTER STRENGTH.
 *
 * Everything under test is pure: no device, no camera, no Skia, no GPU. Each
 * case pins down a claim the feature makes to the user:
 *
 *   · "Original does nothing"                  → exact identity matrix
 *   · "0 % strength is the untouched photo"    → identity at zero, for EVERY
 *                                                 look
 *   · "strength moves smoothly subtle→strong"  → monotonic in the parameter
 *   · "B&W is really black and white"          → equal channels, luminance
 *                                                 preserved
 *   · "Vivid deepens colour"                   → saturation increases
 *   · "Warm is warm, Cool is cool"             → red/blue tilt has the right
 *                                                 sign, and they are opposites
 *   · "a look does not secretly change exposure" → mid-grey stays mid-grey
 *   · "brightness and look compose exactly"    → one matrix ≡ two passes
 *   · "the saved photo gets the look"          → the pipeline's own matrix is
 *                                                 non-identity whenever the
 *                                                 user chose a look
 *   · "coaching stays readable"                → viewfinder wash is capped
 *   · "the preview is honest"                  → mirror gets the SAME numbers,
 *                                                 native declares its limits
 *   · "controls cannot get stuck out of range" → clamping, totality
 *   · "both languages say the same thing"      → copy parity
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  CAMERA_FILTER_IDS,
  FILTER_DEFAULT,
  FILTER_INTENSITY_DEFAULT,
  FILTER_INTENSITY_MAX,
  FILTER_INTENSITY_MIN,
  FILTER_INTENSITY_STEP,
  FILTER_PREVIEW_MAX_OPACITY,
  IDENTITY_COLOR_MATRIX,
  LOOK_DEFINITIONS,
  PREVIEW_TINTED_MAX_RATIO,
  PREVIEW_TINTED_MIN_DIRECTION,
  PREVIEW_TINTED_MIN_RATIO,
  applyColorMatrix,
  captureColorMatrix,
  clampFilterId,
  clampFilterIntensity,
  colorMatrixIsIdentity,
  composeColorMatrices,
  filterColorMatrix,
  filterIntensityBadge,
  filterIsIdentity,
  filterPreviewCss,
  filterPreviewMatrixValues,
  filterPreviewOverlay,
  filterStrength,
  filterSummary,
  filterSupportsIntensity,
  lookDefinition,
  luminanceOf,
  projectMatrixToOverlay,
  viewfinderFidelity,
  type CameraFilterId,
  type ColorMatrix,
} from "../../shared/camera/cameraFilters";
import { brightnessGain } from "../../shared/camera/cameraControls";
import { cameraStatusCopyFor } from "../../shared/camera/cameraStatusCopy";
import {
  clampPhotoEdit,
  enhanceColorMatrix,
  photoEditIsIdentity,
} from "../../shared/camera/photoEditing";

const SAMPLES: readonly (readonly [number, number, number])[] = [
  [0.1, 0.1, 0.1],
  [0.5, 0.5, 0.5],
  [0.82, 0.62, 0.5], // skin
  [0.2, 0.45, 0.85], // sky
  [0.9, 0.2, 0.2], // red shirt
  [0.05, 0.7, 0.35], // foliage
];

const saturationOf = (rgb: readonly [number, number, number]): number =>
  Math.max(...rgb) - Math.min(...rgb);

/* ───────────────────────── preserved catalogue ─────────────────────────── */

test("the five shipped looks are preserved, in order, with Original first", () => {
  assert.deepEqual(
    [...CAMERA_FILTER_IDS],
    ["original", "vivid", "warm", "cool", "bw"],
  );
  assert.equal(FILTER_DEFAULT, "original");
});

test("an unknown or malformed look id can never reach the pipeline", () => {
  const junk: readonly unknown[] = [
    undefined,
    null,
    "",
    "sepia",
    42,
    {},
    ["vivid"],
    NaN,
  ];
  for (const value of junk) {
    assert.equal(clampFilterId(value), "original");
  }
});

/* ───────────────────────────── identity ───────────────────────────────── */

test("Original is an exact no-op at every strength", () => {
  for (let i = FILTER_INTENSITY_MIN; i <= FILTER_INTENSITY_MAX; i += FILTER_INTENSITY_STEP) {
    assert.ok(filterIsIdentity("original", i));
    assert.deepEqual(filterColorMatrix("original", i), IDENTITY_COLOR_MATRIX);
  }
  assert.equal(filterSupportsIntensity("original"), false);
});

test("zero strength returns the untouched photograph for every look", () => {
  for (const id of CAMERA_FILTER_IDS) {
    assert.ok(filterIsIdentity(id, 0), `${id} at 0% must be identity`);
    assert.ok(colorMatrixIsIdentity(filterColorMatrix(id, 0)));
  }
});

test("every non-Original look actually changes pixels at full strength", () => {
  for (const id of CAMERA_FILTER_IDS.filter((f) => f !== "original")) {
    const matrix = filterColorMatrix(id, FILTER_INTENSITY_MAX);
    assert.equal(colorMatrixIsIdentity(matrix), false, `${id} must do something`);
    const before: readonly [number, number, number] = [0.82, 0.62, 0.5];
    const after = applyColorMatrix(before, matrix);
    const moved = before.some((value, index) => Math.abs(value - (after[index] ?? 0)) > 0.01);
    assert.ok(moved, `${id} must visibly move a skin tone`);
  }
});

/* ───────────────────────────── strength ───────────────────────────────── */

test("strength is clamped, quantised and total", () => {
  assert.equal(clampFilterIntensity(-40), FILTER_INTENSITY_MIN);
  assert.equal(clampFilterIntensity(1000), FILTER_INTENSITY_MAX);
  assert.equal(clampFilterIntensity(63), 60);
  assert.equal(clampFilterIntensity(65), 70);
  assert.equal(clampFilterIntensity(Number.NaN), FILTER_INTENSITY_DEFAULT);
  assert.equal(clampFilterIntensity("70" as unknown), FILTER_INTENSITY_DEFAULT);
  assert.equal(clampFilterIntensity(undefined), FILTER_INTENSITY_DEFAULT);
  assert.equal(filterStrength(50), 0.5);
});

test("strength moves the look smoothly and monotonically from subtle to strong", () => {
  const sample: readonly [number, number, number] = [0.2, 0.45, 0.85];
  for (const id of ["vivid", "warm", "cool", "bw"] as const) {
    let previous = -Infinity;
    for (let i = 0; i <= 100; i += 10) {
      const out = applyColorMatrix(sample, filterColorMatrix(id, i));
      const distance = Math.hypot(
        out[0] - sample[0],
        out[1] - sample[1],
        out[2] - sample[2],
      );
      assert.ok(
        distance >= previous - 1e-9,
        `${id}: ${i}% must not be weaker than the step before`,
      );
      previous = distance;
    }
    /* …and the ends are genuinely different, i.e. the control does something */
    const weak = applyColorMatrix(sample, filterColorMatrix(id, 20));
    const strong = applyColorMatrix(sample, filterColorMatrix(id, 100));
    assert.ok(
      Math.hypot(strong[0] - weak[0], strong[1] - weak[1], strong[2] - weak[2]) > 0.02,
      `${id}: 20% and 100% must be visibly different`,
    );
  }
});

test("half strength is exactly halfway between untouched and full", () => {
  for (const id of CAMERA_FILTER_IDS) {
    const half = filterColorMatrix(id, 50);
    const full = filterColorMatrix(id, 100);
    half.forEach((value, index) => {
      const identity = IDENTITY_COLOR_MATRIX[index] ?? 0;
      const expected = identity + ((full[index] ?? identity) - identity) * 0.5;
      assert.ok(Math.abs(value - expected) < 1e-9);
    });
  }
});

/* ─────────────────────── what each look actually does ─────────────────── */

test("B&W produces true neutral grey and keeps perceived luminance", () => {
  const matrix = filterColorMatrix("bw", 100);
  for (const sample of SAMPLES) {
    const [r, g, b] = applyColorMatrix(sample, matrix);
    assert.ok(Math.abs(r - g) < 1e-6 && Math.abs(g - b) < 1e-6, "channels must be equal");
    /* Contrast is part of the look, so luminance may stretch around mid-grey,
       but the ORDER of tones must survive: a brighter patch stays brighter. */
    assert.ok(r >= 0 && r <= 1);
  }
  const dark = applyColorMatrix([0.15, 0.15, 0.15], matrix);
  const light = applyColorMatrix([0.75, 0.75, 0.75], matrix);
  assert.ok(luminanceOf(light) > luminanceOf(dark));
});

test("Vivid deepens colour without inverting anything", () => {
  const matrix = filterColorMatrix("vivid", 100);
  for (const sample of SAMPLES) {
    if (saturationOf(sample) < 0.05) continue;
    const out = applyColorMatrix(sample, matrix);
    assert.ok(
      saturationOf(out) > saturationOf(sample),
      "vivid must increase channel spread",
    );
  }
});

test("Warm and Cool tilt red vs blue in opposite directions", () => {
  const grey: readonly [number, number, number] = [0.5, 0.5, 0.5];
  const warm = applyColorMatrix(grey, filterColorMatrix("warm", 100));
  const cool = applyColorMatrix(grey, filterColorMatrix("cool", 100));
  assert.ok(warm[0] > warm[2], "warm: red above blue");
  assert.ok(cool[2] > cool[0], "cool: blue above red");
  assert.ok(warm[0] > cool[0] && cool[2] > warm[2], "the two are opposites");
});

test("no look secretly changes exposure — mid-grey stays mid-grey", () => {
  const grey: readonly [number, number, number] = [0.5, 0.5, 0.5];
  for (const id of CAMERA_FILTER_IDS) {
    const out = applyColorMatrix(grey, filterColorMatrix(id, 100));
    assert.ok(
      Math.abs(luminanceOf(out) - 0.5) < 0.06,
      `${id} must not act as a brightness control (got ${luminanceOf(out)})`,
    );
  }
});

/* ─────────────────────── composition with brightness ──────────────────── */

function applyTwice(
  rgb: readonly [number, number, number],
  first: ColorMatrix,
  second: ColorMatrix,
): readonly [number, number, number] {
  return applyColorMatrix(applyColorMatrix(rgb, first), second);
}

test("one composed matrix equals applying the two matrices in sequence", () => {
  const gain = brightnessGain(2);
  const brightness: ColorMatrix = [
    gain, 0, 0, 0, 0,
    0, gain, 0, 0, 0,
    0, 0, gain, 0, 0,
    0, 0, 0, 1, 0,
  ];
  for (const id of CAMERA_FILTER_IDS) {
    const look = filterColorMatrix(id, 70);
    const composed = composeColorMatrices(look, brightness);
    for (const sample of SAMPLES) {
      const sequential = applyTwice(sample, look, brightness);
      const single = applyColorMatrix(sample, composed);
      single.forEach((value, index) => {
        assert.ok(
          Math.abs(value - (sequential[index] ?? 0)) < 1e-9,
          `${id}: one pass must equal two passes`,
        );
      });
    }
  }
});

test("the capture matrix is identity only when nothing was asked for", () => {
  assert.ok(
    colorMatrixIsIdentity(
      captureColorMatrix({ filter: "original", intensity: 100, brightnessGain: 1 }),
    ),
  );
  assert.ok(
    colorMatrixIsIdentity(
      captureColorMatrix({ filter: "bw", intensity: 0, brightnessGain: 1 }),
    ),
  );
  for (const id of CAMERA_FILTER_IDS.filter((f) => f !== "original")) {
    assert.equal(
      colorMatrixIsIdentity(
        captureColorMatrix({ filter: id, intensity: 100, brightnessGain: 1 }),
      ),
      false,
      `${id} must reach the saved photo`,
    );
    assert.equal(
      colorMatrixIsIdentity(
        captureColorMatrix({ filter: id, intensity: 10, brightnessGain: 1 }),
      ),
      false,
      `${id} at 10% must still reach the saved photo`,
    );
  }
  /* Brightness alone still works exactly as it did before looks existed. */
  assert.equal(
    colorMatrixIsIdentity(
      captureColorMatrix({
        filter: "original",
        intensity: 100,
        brightnessGain: brightnessGain(-2),
      }),
    ),
    false,
  );
});

test("a non-finite brightness gain cannot corrupt the capture matrix", () => {
  const matrix = captureColorMatrix({
    filter: "warm",
    intensity: 100,
    brightnessGain: Number.NaN,
  });
  assert.deepEqual(matrix, filterColorMatrix("warm", 100));
  assert.ok(matrix.every((value) => Number.isFinite(value)));
});

/* ─────── preview projection: honesty, coaching safety, strength ─────────
 *
 * Since D2 the viewfinder overlay is PROJECTED from the canonical matrix
 * (constrained least squares onto the alpha-composite model class), not
 * hand-picked. These tests pin the projections down so a future recipe or
 * calibration change is a deliberate, review-visible event. */

test("the viewfinder overlay can never hide the pose coaching", () => {
  for (const id of CAMERA_FILTER_IDS) {
    for (let i = 0; i <= 100; i += 10) {
      const overlay = filterPreviewOverlay(id, i);
      assert.ok(
        overlay.opacity <= FILTER_PREVIEW_MAX_OPACITY + 1e-9,
        `${id}@${i}% overlay too strong`,
      );
      assert.ok(overlay.opacity >= 0);
      if (filterIsIdentity(id, i)) assert.equal(overlay.opacity, 0);
    }
  }
});

test("the overlay grows with strength where the law allows, and is absent at zero", () => {
  /* Warm, cool and B&W project onto gain/offset transforms the overlay CAN
     partially express, so their fitted opacity rises monotonically with
     strength; B&W saturates at the coaching cap, which is the documented
     point of the cap. Vivid projects onto "nothing visible" — its transform
     is orthogonal to the overlay class — so it stays at exactly zero, and
     the honesty copy says the look is shown after the shot. */
  for (const id of CAMERA_FILTER_IDS) {
    assert.equal(filterPreviewOverlay(id, 0).opacity, 0, `${id}@0% must show nothing`);
  }
  for (const id of ["warm", "cool", "bw"] as const) {
    let previous = 0;
    for (let i = 10; i <= 100; i += 10) {
      const opacity = filterPreviewOverlay(id, i).opacity;
      assert.ok(
        opacity >= previous - 1e-9,
        `${id}: opacity must not shrink with strength (${i}% → ${opacity}, was ${previous})`,
      );
      previous = opacity;
    }
    assert.ok(previous > 0, `${id}@100% must be visible`);
  }
  for (let i = 10; i <= 100; i += 10) {
    assert.equal(
      filterPreviewOverlay("vivid", i).opacity,
      0,
      "vivid has provably no lawful overlay — it is declared, not faked",
    );
  }
});

test("the native viewfinder declares exactly what it measurably can and cannot show", () => {
  assert.equal(viewfinderFidelity("original"), "exact");
  /* Measured (see parity metrics in filterPreviewOverlay): the fitted warm
     and cool veils agree with the capture in direction and show a meaningful
     share of the magnitude. */
  assert.equal(viewfinderFidelity("warm"), "tinted");
  assert.equal(viewfinderFidelity("cool"), "tinted");
  /* No translucent overlay can desaturate a native camera preview, so B&W is
     never claimed live. Vivid measured as ORTHOGONAL to the overlay class
     (the old white veil pointed the wrong way, direction −0.22), so it is
     declared too — the copy says "shown after the shot" for both. */
  assert.equal(viewfinderFidelity("vivid"), "not-representable");
  assert.equal(viewfinderFidelity("bw"), "not-representable");
});

test("fidelity is DERIVED from the measured fit, not a per-look table", () => {
  for (const id of CAMERA_FILTER_IDS) {
    const fidelity = viewfinderFidelity(id);
    const fit = projectMatrixToOverlay(filterColorMatrix(id, FILTER_INTENSITY_MAX));
    if (id === "original") {
      assert.equal(fidelity, "exact");
      assert.ok(fit.lookMagnitude < 1e-9);
      continue;
    }
    const ratio =
      fit.lookMagnitude < 1e-9 ? 1 : fit.overlayDeviation / fit.lookMagnitude;
    const tinted =
      fit.alpha > 1e-9 &&
      fit.directionAgreement >= PREVIEW_TINTED_MIN_DIRECTION &&
      ratio >= PREVIEW_TINTED_MIN_RATIO &&
      ratio <= PREVIEW_TINTED_MAX_RATIO;
    assert.equal(fidelity, tinted ? "tinted" : "not-representable", `${id} must follow the measurement`);
  }
});

test("the browser mirror receives the SAME twenty numbers, not a lookalike", () => {
  for (const id of CAMERA_FILTER_IDS) {
    for (const intensity of [0, 30, 60, 100]) {
      const values = filterPreviewMatrixValues(id, intensity).split(" ").map(Number);
      assert.equal(values.length, 20);
      filterColorMatrix(id, intensity).forEach((value, index) => {
        assert.ok(Math.abs(value - (values[index] ?? 0)) < 1e-4);
      });
    }
  }
});

test("the CSS fallback is derived from the same recipe and follows strength", () => {
  assert.equal(filterPreviewCss("original", 100), "none");
  assert.equal(filterPreviewCss("bw", 0), "none");
  assert.match(filterPreviewCss("bw", 100), /grayscale\(1\)/);
  assert.match(filterPreviewCss("vivid", 100), /saturate\(/);
  assert.match(filterPreviewCss("warm", 100), /sepia\(/);
  assert.match(filterPreviewCss("cool", 100), /hue-rotate\(/);
  const soft = Number(/saturate\(([\d.]+)\)/.exec(filterPreviewCss("vivid", 20))?.[1] ?? "0");
  const strong = Number(/saturate\(([\d.]+)\)/.exec(filterPreviewCss("vivid", 100))?.[1] ?? "0");
  assert.ok(strong > soft && soft > 1);
});

/* ───────────────────────────── labels & copy ──────────────────────────── */

test("the strength badge stays silent at full strength and speaks otherwise", () => {
  assert.equal(filterIntensityBadge("vivid", 100), null);
  assert.equal(filterIntensityBadge("original", 40), null);
  assert.equal(filterIntensityBadge("vivid", 40), "40%");
  assert.equal(
    filterSummary("bw", 100, (id: CameraFilterId) => id.toUpperCase()),
    "BW",
  );
  assert.equal(
    filterSummary("bw", 30, (id: CameraFilterId) => id.toUpperCase()),
    "BW · 30%",
  );
});

test("both coaching languages carry the whole look vocabulary", () => {
  const en = cameraStatusCopyFor("en");
  const hi = cameraStatusCopyFor("hi");
  for (const copy of [en, hi]) {
    assert.ok(copy.filterTitle.length > 0);
    assert.ok(copy.filterStrengthTitle.length > 0);
    assert.ok(copy.filterNote.length > 0);
    assert.ok(copy.filterReset.length > 0);
    assert.ok(copy.filterStronger.length > 0);
    assert.ok(copy.filterSofter.length > 0);
    for (const id of CAMERA_FILTER_IDS) {
      assert.ok(copy.filterName(id).length > 0, `${id} needs a name`);
      assert.ok(copy.filterSummary(id, 60).length > 0);
    }
    assert.equal(copy.filterPreviewNote("original"), "");
    assert.ok(copy.filterPreviewNote("bw").length > 0);
    assert.ok(copy.filterPreviewNote("warm").length > 0);
    assert.match(copy.filterStrengthValue(60), /60%/);
    assert.match(copy.filterSummary("vivid", 40), /40%/);
    assert.ok(!copy.filterSummary("vivid", 100).includes("%"));
  }
  /* Parity, not translation-by-fallback: the two must actually differ. */
  assert.notEqual(en.filterNote, hi.filterNote);
  assert.notEqual(en.filterStrengthTitle, hi.filterStrengthTitle);
});

/* ═══════════════════════ D2 — ONE canonical look, two renderers ═══════════
 *
 * The D2 contract in executable form: the live-preview renderer and the
 * saved-photo renderer are two PROJECTIONS of one definition — never two
 * definitions. What is genuinely impossible (desaturating a native camera
 * surface, showing vivid's cross-channel transform through a veil) is
 * declared through measured fidelity, not smoothed over.
 */

test("every look publishes a valid canonical definition (id, strength, both mappings)", () => {
  assert.equal(LOOK_DEFINITIONS.length, CAMERA_FILTER_IDS.length);
  assert.deepEqual(
    LOOK_DEFINITIONS.map((d) => d.id),
    [...CAMERA_FILTER_IDS],
  );
  for (const def of LOOK_DEFINITIONS) {
    assert.equal(def.strength.min, FILTER_INTENSITY_MIN);
    assert.equal(def.strength.max, FILTER_INTENSITY_MAX);
    assert.equal(def.strength.step, FILTER_INTENSITY_STEP);
    assert.equal(def.strength.defaultValue, FILTER_INTENSITY_DEFAULT);
    assert.equal(def.supportsIntensity, def.id !== "original");
    assert.equal(
      def.recipe.id,
      def.id,
      `${def.id}: the definition's recipe must be the catalogue recipe`,
    );
    assert.equal(typeof def.recipe.saturation, "number");
    assert.equal(typeof def.recipe.contrast, "number");
    assert.equal(typeof def.recipe.temperature, "number");
    assert.equal(typeof def.recipe.desaturateToLuma, "number");
    /* capture mapping = exactly what the Skia pass bakes at 100%. */
    assert.deepEqual(
      def.capture.fullStrengthMatrix,
      filterColorMatrix(def.id, FILTER_INTENSITY_MAX),
      `${def.id}: capture mapping drifted from the matrix`,
    );
    /* preview mapping = the projection of THAT matrix, nothing else. */
    assert.deepEqual(
      def.preview.overlay,
      filterPreviewOverlay(def.id, FILTER_INTENSITY_MAX),
      `${def.id}: preview mapping drifted from the projection`,
    );
    assert.equal(def.preview.fidelity, viewfinderFidelity(def.id));
  }
});

test("lookDefinition() is total and degenerates to Original for unknown ids", () => {
  assert.equal(lookDefinition("not-a-look").id, "original");
  assert.equal(lookDefinition(undefined).id, "original");
  assert.equal(lookDefinition(42).id, "original");
});

test("the preview overlay is derived from the SAME matrix the capture bakes", () => {
  /* Re-deriving the projection from the shared matrix must reproduce the
     published overlay exactly — this is the single-source-of-truth property:
     there is no second parameter set that could disagree with the first. */
  for (const id of CAMERA_FILTER_IDS) {
    for (const i of [0, 20, 50, 70, 100]) {
      const published = filterPreviewOverlay(id, i);
      const rederived = projectMatrixToOverlay(filterColorMatrix(id, i));
      assert.equal(published.opacity, Math.round(rederived.alpha * 1000) / 1000, `${id}@${i}%`);
      assert.equal(published.parity.lookMagnitude, Math.round(rederived.lookMagnitude * 10000) / 10000);
      assert.equal(published.parity.directionAgreement, Math.round(rederived.directionAgreement * 10000) / 10000);
    }
  }
});

test("strength mapping is shared: capture and preview honour the same 0…100 curve", () => {
  for (const id of CAMERA_FILTER_IDS) {
    /* The capture side: strength lerps the matrix to identity. */
    assert.deepEqual(filterColorMatrix(id, 0), IDENTITY_COLOR_MATRIX);
    /* The preview side consumes the SAME lerped matrix: every published
       overlay must be finite and total across the whole stepped range. */
    for (let i = 0; i <= 100; i += 10) {
      const overlay = filterPreviewOverlay(id, i);
      assert.ok(Number.isFinite(overlay.opacity), `${id}@${i}% opacity must be finite`);
      assert.ok(Number.isFinite(overlay.parity.lookMagnitude), `${id}@${i}% metrics must be finite`);
      assert.match(overlay.colorHex, /^#[0-9A-F]{6}$/, `${id}@${i}% must produce a styleable colour`);
    }
    /* Halfway strength must move the look halfway — measured on the shared
       target scale the preview is fitted against (the overlay itself may pin
       at the coaching cap, which is the cap's documented purpose). */
    const full = projectMatrixToOverlay(filterColorMatrix(id, 100));
    const half = projectMatrixToOverlay(filterColorMatrix(id, 50));
    assert.ok(
      Math.abs(half.lookMagnitude - full.lookMagnitude / 2) < 0.02,
      `${id}: half-strength must be ≈half the look on the shared scale`,
    );
  }
});

test("Original stays neutral live AND on the wire", () => {
  for (let i = 0; i <= 100; i += 10) {
    const overlay = filterPreviewOverlay("original", i);
    assert.equal(overlay.opacity, 0);
    assert.equal(overlay.colorHex, "#808080", "unused placeholder when nothing renders");
    assert.equal(overlay.parity.lookMagnitude, 0);
    assert.deepEqual(filterColorMatrix("original", i), IDENTITY_COLOR_MATRIX);
  }
  assert.equal(viewfinderFidelity("original"), "exact");
});

test("the fitted veil measured against the OLD hand-tuned one: strictly closer or silent", () => {
  /* The pre-D2 second source of truth (theme token colour + per-look table
     opacity), kept here verbatim as the regression baseline the projection
     must beat on the projection's own calibration set. */
  const OLD_VEILS: Readonly<Record<string, { alpha: number; color: readonly [number, number, number] }>> = {
    vivid: { alpha: 0.12, color: [1, 1, 1] },
    warm: { alpha: 0.22, color: [1, 0.69, 0.4] },
    cool: { alpha: 0.22, color: [0.4, 0.7, 1] },
    bw: { alpha: 0.18, color: [0.725, 0.741, 0.769] },
  };
  const SAMPLE_SET: { x: readonly [number, number, number]; w: number }[] = [];
  for (const v of [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]) {
    SAMPLE_SET.push({ x: [v, v, v], w: 3 });
  }
  for (const r of [0, 0.2, 0.4, 0.6, 0.8, 1]) {
    for (const g of [0, 0.2, 0.4, 0.6, 0.8, 1]) {
      for (const b of [0, 0.2, 0.4, 0.6, 0.8, 1]) {
        SAMPLE_SET.push({ x: [r, g, b], w: 1 });
      }
    }
  }
  const anchors: readonly (readonly [number, number, number])[] = [
    [0.76, 0.57, 0.44], [0.45, 0.33, 0.27],
    [0.53, 0.72, 0.92], [0.35, 0.55, 0.8],
    [0.28, 0.46, 0.2], [0.15, 0.3, 0.12],
    [0.92, 0.9, 0.86], [0.08, 0.08, 0.09],
  ];
  for (const a of anchors) SAMPLE_SET.push({ x: a, w: 2 });
  const W3 = SAMPLE_SET.reduce((total, s) => total + s.w, 0) * 3;

  const meanError = (
    matrix: ColorMatrix,
    overlay: { alpha: number; color: readonly [number, number, number] },
  ): number => {
    let sum = 0;
    for (const sample of SAMPLE_SET) {
      const [r, g, b] = applyColorMatrix(sample.x, matrix);
      const y = [r, g, b];
      for (let c = 0; c < 3; c += 1) {
        const pred = (1 - overlay.alpha) * (sample.x[c] ?? 0) + overlay.alpha * (overlay.color[c] ?? 0);
        sum += sample.w * Math.abs((y[c] ?? 0) - pred);
      }
    }
    return sum / W3;
  };

  for (const [id, oldVeil] of Object.entries(OLD_VEILS)) {
    for (const intensity of [50, 100]) {
      const t = filterStrength(intensity);
      const matrix = filterColorMatrix(id, intensity);
      const oldError = meanError(matrix, { alpha: oldVeil.alpha * t, color: oldVeil.color });
      const fitted = filterPreviewOverlay(id, intensity);
      const newError = meanError(matrix, { alpha: fitted.opacity, color: fitted.color });
      assert.ok(
        newError < oldError,
        `${id}@${intensity}%: projected overlay (${newError.toFixed(4)}) must beat the old hand-tuned veil (${oldError.toFixed(4)})`,
      );
    }
  }
});

test("parity metrics stay inside the reviewed envelopes (regression alarm for recipe changes)", () => {
  /* Numbers measured when D2 shipped; the point of these bounds is that a
     future recipe tweak MOVES them visibly instead of silently. */
  const at100 = (id: CameraFilterId) => filterPreviewOverlay(id, 100).parity;
  const warm = at100("warm");
  assert.ok(warm.directionAgreement > 0.3 && warm.directionAgreement < 0.9, `warm direction ${warm.directionAgreement}`);
  assert.ok(warm.magnitudeRatio > 0.2 && warm.magnitudeRatio < 1.5, `warm ratio ${warm.magnitudeRatio}`);
  const cool = at100("cool");
  assert.ok(cool.directionAgreement > 0.3 && cool.directionAgreement < 0.9, `cool direction ${cool.directionAgreement}`);
  assert.ok(cool.magnitudeRatio > 0.2 && cool.magnitudeRatio < 1.5, `cool ratio ${cool.magnitudeRatio}`);
  const bw = at100("bw");
  assert.ok(bw.directionAgreement > 0.4, `bw direction ${bw.directionAgreement}`);
  const vivid = at100("vivid");
  assert.equal(vivid.overlayDeviation, 0, "vivid shows nothing because nothing lawful can be shown");
  assert.ok(vivid.lookMagnitude > 0.04, "but the captured look is very real");
});

test("warm and cool previews lean the same way their captures do", () => {
  const warmFull = filterPreviewOverlay("warm", 100);
  assert.ok(warmFull.opacity > 0);
  assert.ok(
    warmFull.color[0] > warmFull.color[2],
    `warm veil must warm (#component r>b): ${warmFull.colorHex}`,
  );
  const coolFull = filterPreviewOverlay("cool", 100);
  assert.ok(coolFull.opacity > 0);
  assert.ok(
    coolFull.color[2] > coolFull.color[0],
    `cool veil must cool (b>r): ${coolFull.colorHex}`,
  );
  const bwFull = filterPreviewOverlay("bw", 100);
  const spread = Math.max(...bwFull.color) - Math.min(...bwFull.color);
  assert.ok(spread < 0.08, `bw veil must be near-neutral: ${bwFull.colorHex}`);
  assert.match(bwFull.colorHex, /^#[0-9A-F]{6}$/);
});

/* ─────────── D2 §double-application: the look is baked exactly once ─────
 *
 * Ownership is structural: the capture pipeline is the ONLY writer of the
 * look (`applyCaptureFraming`), the editor's model physically has no field
 * that could carry a look, and the preview route treats filterUsed as
 * display metadata. These tests make that structure executable. */

test("the post-capture editor model cannot express a look (no filter field, ever)", () => {
  const edit = clampPhotoEdit({});
  const keys = Object.keys(edit);
  assert.ok(
    !keys.some((key) => /filter|look/i.test(key)),
    `editor model must not grow a look channel: ${keys.join(",")}`,
  );
  assert.deepEqual(keys.sort(), ["crop", "enhance", "rotation"]);
  /* A neutral edit must be a provable no-op — if a look ever leaked into the
     enhance matrix, this breaks. */
  assert.ok(photoEditIsIdentity(edit));
  assert.ok(colorMatrixIsIdentity(enhanceColorMatrix(edit.enhance)));
});

test("capture matrix carries the look exactly once (brightness∘look composition stays exact)", () => {
  for (const id of CAMERA_FILTER_IDS) {
    const look = filterColorMatrix(id, 60);
    const composed = captureColorMatrix({ filter: id, intensity: 60, brightnessGain: 1 });
    assert.deepEqual(composed, look, `${id}: identity brightness must not disturb the look`);
    const brightened = captureColorMatrix({ filter: id, intensity: 60, brightnessGain: 1.1 });
    const manual = composeColorMatrices(look, [
      1.1, 0, 0, 0, 0,
      0, 1.1, 0, 0, 0,
      0, 0, 1.1, 0, 0,
      0, 0, 0, 1, 0,
    ]);
    assert.deepEqual(brightened, manual, `${id}: one composed matrix ≡ two passes`);
  }
});
