/**
 * tests/camera/cameraFraming.test.ts — FINAL INTEGRATION PASS.
 *
 * What broke (audited on the restored tree, not assumed): the coaching
 * band's bottom offset in the live camera screen measured from the LOOKS
 * zone's BOTTOM edge while the zone is up to 114 pt tall — so the band's
 * pill rendered over the middle filter swatches (zIndex 25) whenever
 * coaching and LOOKS were both on screen, which is the overwhelming
 * majority of a coached session. The zoom row measured the same zone
 * correctly, from its own duplicated copy of the arithmetic.
 *
 * The repair put the zone's height in ONE shared function —
 * `filterZoneClearance` — consumed by both the zoom row and the coaching
 * band. These cases pin that function's totality, its monotonic stack
 * order, and its single source of truth for the heights, so two consumers
 * can never quietly re-derive different numbers again.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import { filterZoneClearance } from "../../shared/camera/cameraFraming";
import { sizing } from "../../shared/theme/sizing";

test("a hidden LOOKS zone occupies zero points, even if a strength flag leaks", () => {
  /* Totality: `resolveCameraPresentation` unmounts the whole zone during any
     blocking layer; a stray `strengthVisible === true` must not conjure
     chrome for a control that is not on screen. */
  assert.equal(filterZoneClearance(false, false), 0);
  assert.equal(filterZoneClearance(false, true), 0);
});

test("a visible strip clears exactly the shared swatch-rail height", () => {
  assert.equal(filterZoneClearance(true, false), sizing.cameraFilterStrip);
});

test("strength-open clears rail + track — one number for both consumers", () => {
  assert.equal(
    filterZoneClearance(true, true),
    sizing.cameraFilterStrip + sizing.cameraFilterStrength,
  );
});

test("the clearance is monotonic down the stack states", () => {
  const hidden = filterZoneClearance(false, false);
  const strip = filterZoneClearance(true, false);
  const strength = filterZoneClearance(true, true);
  assert.ok(hidden < strip && strip < strength);
  assert.ok(strength > 0);
});

test("everything coaching-critical clears the zone, not just its bottom edge", () => {
  /* The invariant the bug violated: an overlay stacked "above the zone" must
     sit at >= zoneBottom + clearance. Pinning the clearance relationships
     here keeps the screen's single-line addition honest. */
  const clearance = filterZoneClearance(true, true);
  assert.ok(clearance >= sizing.cameraFilterStrip);
  assert.ok(clearance - sizing.cameraFilterStrip === sizing.cameraFilterStrength);
});
