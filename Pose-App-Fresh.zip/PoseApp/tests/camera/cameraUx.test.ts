/**
 * tests/camera/cameraUx.test.ts — Camera UX Part 1.
 *
 * Two pure modules are under test and nothing else is needed to run them:
 * no device, no camera, no MediaPipe, no speech, no network, no clock.
 *
 *   1. shared/camera/cameraPresentation — the overlay PRIORITY MODEL.
 *      Asserts that the screen can never say two competing things at once,
 *      and that "capture is blocked" always carries a reason.
 *
 *   2. shared/content/visibleCoaching — the VISIBLE half of the semantic
 *      coaching boundary. Asserts TOTALITY (every semantic state yields a
 *      message), LANGUAGE PARITY (en and hi cover exactly the same states)
 *      and SEMANTIC FIDELITY (tone follows the engine's severity verbatim,
 *      and the five "cannot judge you" reasons stay distinguishable).
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  resolveCameraPresentation,
  type CameraPresentationInput,
} from "../../shared/camera/cameraPresentation";
import { cameraStatusCopyFor } from "../../shared/camera/cameraStatusCopy";
/* Arrival-state repair: this test referenced DEFAULT_INSTRUCTION_LANGUAGE
   without importing it, so `npm test` failed at the tsc step (TS2304) before
   a single case could run. The import is the whole fix; no assertion changed. */
import { DEFAULT_INSTRUCTION_LANGUAGE } from "../../shared/types/settings";
import {
  VISIBLE_CORRECTION_KEYS,
  VISIBLE_UNAVAILABLE_REASONS,
  visibleCoachingFor,
} from "../../shared/content/visibleCoaching";
import { JOINT_GUIDANCE_RULES } from "../../shared/ml/guidanceGenerator";
import type { CoachingState } from "../../shared/coaching/types";
import type { AnalysisUnavailableReason } from "../../shared/ml/analysis/types";

const LIVE: CameraPresentationInput = {
  sessionLive: true,
  cameraReady: true,
  mlStatus: "ready",
  countdownActive: false,
  isCapturing: false,
  isProcessing: false,
  coachingKind: "correction",
  holdProgress: 0,
  captureErrorActive: false,
  voiceGuidanceEnabled: true,
  isSpeaking: false,
};

function presentation(patch: Partial<CameraPresentationInput>) {
  return resolveCameraPresentation({ ...LIVE, ...patch });
}

/* ── 1. Priority model ──────────────────────────────────────────────── */

test("a live frame shows the persistent chrome and allows capture", () => {
  const p = presentation({});
  assert.equal(p.blocking, "none");
  assert.equal(p.showCoachingBand, true);
  assert.equal(p.showMatchPill, true);
  assert.equal(p.captureEnabled, true);
  assert.equal(p.captureBlockReason, "none");
  assert.equal(p.readiness, "adjusting");
});

test("exactly one blocking layer wins, in the documented order", () => {
  assert.equal(presentation({ isProcessing: true, isCapturing: true, countdownActive: true }).blocking, "processing");
  assert.equal(presentation({ isCapturing: true, countdownActive: true }).blocking, "capturing");
  assert.equal(presentation({ countdownActive: true, mlStatus: "loading" }).blocking, "countdown");
  assert.equal(presentation({ mlStatus: "loading", sessionLive: false }).blocking, "model-loading");
  assert.equal(presentation({ sessionLive: false }).blocking, "session-paused");
});

test("any blocking layer suppresses ALL persistent chrome", () => {
  for (const patch of [
    { isProcessing: true },
    { isCapturing: true },
    { countdownActive: true },
    { mlStatus: "loading" as const },
    { sessionLive: false },
  ]) {
    const p = presentation({ ...patch, holdProgress: 0.5, coachingKind: "correction" as const });
    assert.notEqual(p.blocking, "none");
    assert.equal(p.showCoachingBand, false, `band during ${p.blocking}`);
    assert.equal(p.showMatchPill, false, `match during ${p.blocking}`);
    assert.equal(p.showHoldProgress, false, `hold during ${p.blocking}`);
    assert.equal(p.showFilterStrip, false, `filters during ${p.blocking}`);
    assert.equal(p.showZoomPill, false, `zoom during ${p.blocking}`);
    assert.equal(p.voiceIndicator, "hidden", `voice chip during ${p.blocking}`);
  }
});

test("hold progress and a PERFECT band never say 'hold' twice", () => {
  const p = presentation({ coachingKind: "perfect", holdProgress: 0.6 });
  assert.equal(p.showHoldProgress, true);
  assert.equal(p.showCoachingBand, false);
});

test("hold progress does NOT suppress an actual correction", () => {
  const p = presentation({ coachingKind: "correction", holdProgress: 0.6 });
  assert.equal(p.showHoldProgress, true);
  assert.equal(p.showCoachingBand, true);
});

test("a capture error owns the bottom strip alone", () => {
  const p = presentation({ captureErrorActive: true });
  assert.equal(p.showCoachingBand, false);
  assert.equal(p.showFilterStrip, false);
  // …and it never blocks the camera itself.
  assert.equal(p.blocking, "none");
  assert.equal(p.captureEnabled, true);
});

test("disabled capture always carries an explainable reason", () => {
  const cases: Array<[Partial<CameraPresentationInput>, string]> = [
    [{ isProcessing: true }, "capture-in-progress"],
    [{ isCapturing: true }, "capture-in-progress"],
    [{ countdownActive: true }, "countdown-running"],
    [{ sessionLive: false }, "session-paused"],
    [{ mlStatus: "loading" }, "model-loading"],
    [{ cameraReady: false }, "camera-warming"],
  ];
  const copy = cameraStatusCopyFor("en");
  for (const [patch, reason] of cases) {
    const p = presentation(patch);
    assert.equal(p.captureEnabled, false);
    assert.equal(p.captureBlockReason, reason);
    assert.ok(copy.captureBlocked(p.captureBlockReason).length > 0, reason);
  }
  assert.equal(copy.captureBlocked("none"), "");
});

test("the voice chip distinguishes speaking, idle and muted", () => {
  assert.equal(presentation({ isSpeaking: true }).voiceIndicator, "speaking");
  assert.equal(presentation({ isSpeaking: false }).voiceIndicator, "idle");
  assert.equal(
    presentation({ voiceGuidanceEnabled: false, isSpeaking: false }).voiceIndicator,
    "muted",
  );
});

test("readiness reports the coaching kind, not a guess", () => {
  assert.equal(presentation({ coachingKind: "perfect" }).readiness, "ready");
  assert.equal(presentation({ coachingKind: "correction" }).readiness, "adjusting");
  assert.equal(presentation({ coachingKind: "evaluating" }).readiness, "evaluating");
  assert.equal(presentation({ coachingKind: "unavailable" }).readiness, "searching");
  assert.equal(presentation({ mlStatus: "unavailable" }).readiness, "blocked");
});

/* ── 1b. Camera UX Part 2 — emphasis, shutter ring, transient zoom ─── */

test("the match number is hidden whenever it would be a number about nobody", () => {
  // No body / unusable reference: the engine publishes `unavailable`.
  assert.equal(presentation({ coachingKind: "unavailable" }).matchEmphasis, "hidden");
  assert.equal(presentation({ coachingKind: null }).matchEmphasis, "hidden");
  // Any blocking layer takes the whole rail with it.
  assert.equal(presentation({ isProcessing: true }).matchEmphasis, "hidden");
  assert.equal(presentation({ mlStatus: "loading" }).matchEmphasis, "hidden");
});

test("the match number is promoted only when it IS the message", () => {
  assert.equal(presentation({ coachingKind: "perfect" }).matchEmphasis, "primary");
  assert.equal(
    presentation({ coachingKind: "correction", holdProgress: 0.5 }).matchEmphasis,
    "primary",
  );
  assert.equal(presentation({ coachingKind: "correction" }).matchEmphasis, "muted");
  assert.equal(presentation({ coachingKind: "evaluating" }).matchEmphasis, "muted");
});

test("the shutter ring names the trigger that earned it", () => {
  assert.equal(
    presentation({ holdProgress: 0.4, holdSource: "gesture" }).shutterRing,
    "hold-gesture",
  );
  assert.equal(
    presentation({ holdProgress: 0.4, holdSource: "auto" }).shutterRing,
    "hold-auto",
  );
  // A hold with no declared source is the implicit pose hold, never a palm.
  assert.equal(presentation({ holdProgress: 0.4 }).shutterRing, "hold-auto");
  assert.equal(presentation({ coachingKind: "perfect" }).shutterRing, "ready");
  assert.equal(presentation({ coachingKind: "correction" }).shutterRing, "none");
  // Transient layers own the screen; the ring goes with the rest of it.
  assert.equal(
    presentation({ holdProgress: 0.4, countdownActive: true }).shutterRing,
    "none",
  );
});

test("the status rail and the legacy match-pill flag never disagree", () => {
  for (const patch of [
    {},
    { mlStatus: "loading" as const },
    { sessionLive: false },
    { isProcessing: true },
    { coachingKind: "unavailable" as const },
  ]) {
    const p = presentation(patch);
    assert.equal(p.showStatusRail, p.showMatchPill);
  }
});

test("the zoom readout is transient, never permanent chrome", () => {
  assert.equal(presentation({}).showZoomPill, false);
  assert.equal(presentation({ zoomEngaged: true }).showZoomPill, true);
  assert.equal(
    presentation({ zoomEngaged: true, countdownActive: true }).showZoomPill,
    false,
  );
});

test("every readiness state has a glanceable word in BOTH languages", () => {
  const states = [
    "blocked",
    "searching",
    "evaluating",
    "adjusting",
    "ready",
  ] as const;
  const en = cameraStatusCopyFor("en");
  const hi = cameraStatusCopyFor("hi");
  const seen = new Set<string>();
  for (const state of states) {
    assert.ok(en.readiness(state).length > 0, `en ${state}`);
    assert.ok(hi.readiness(state).length > 0, `hi ${state}`);
    assert.notEqual(en.readiness(state), hi.readiness(state), `parity ${state}`);
    // Distinguishable: two states must never collapse to the same word.
    assert.equal(seen.has(en.readiness(state)), false, `duplicate ${state}`);
    seen.add(en.readiness(state));
  }
});

test("the flip control names the camera in the coaching language", () => {
  const en = cameraStatusCopyFor("en");
  const hi = cameraStatusCopyFor("hi");
  assert.notEqual(en.facing("front"), en.facing("back"));
  assert.notEqual(hi.facing("front"), hi.facing("back"));
  assert.notEqual(en.facing("front"), hi.facing("front"));
});

/* ── 2. Visible coaching ────────────────────────────────────────────── */

function correction(
  measurementId: string,
  direction: "increase" | "decrease",
  severity: "minor" | "major",
): CoachingState {
  return {
    kind: "correction",
    token: `${measurementId}_${direction}`.toUpperCase(),
    category: "hand_up",
    measurementId,
    direction,
    severity,
    intensity: severity === "major" ? "firm" : "gentle",
    confidence: 0.9,
    stableFrames: 4,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
  };
}

function unavailable(reason: AnalysisUnavailableReason): CoachingState {
  return {
    kind: "unavailable",
    token: `UNAVAILABLE:${reason}`,
    category: null,
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0,
    stableFrames: 1,
    heldByHysteresis: false,
    unavailableReason: reason,
    speakable: false,
  };
}

test("visible copy exists for every joint/direction the engine can decide", () => {
  const expected = new Set<string>();
  for (const measurementId of Object.keys(JOINT_GUIDANCE_RULES)) {
    expected.add(`${measurementId}:increase`);
    expected.add(`${measurementId}:decrease`);
  }
  assert.deepEqual(
    [...expected].sort(),
    [...VISIBLE_CORRECTION_KEYS].sort(),
    "visible vocabulary must cover exactly the engine's joint vocabulary",
  );
});

test("every semantic state produces a message — the band is never silent", () => {
  const states: CoachingState[] = [
    correction("leftElbow", "increase", "minor"),
    { ...correction("leftElbow", "increase", "minor"), kind: "perfect", token: "PERFECT" },
    { ...correction("leftElbow", "increase", "minor"), kind: "evaluating", token: "EVALUATING" },
    unavailable("no-live-pose"),
    unavailable("low-confidence"),
    unavailable("insufficient-measurements"),
    unavailable("reference-unavailable"),
    unavailable("reference-invalid"),
    unavailable("reference-incomplete"),
    unavailable("reference-incompatible"),
  ];
  for (const language of ["en", "hi"]) {
    for (const state of states) {
      const visible = visibleCoachingFor(state, language);
      assert.ok(visible !== null, `${state.kind} in ${language}`);
      assert.ok(visible.headline.length > 0, `${state.token} headline`);
      assert.equal(visible.language, language);
      assert.equal(visible.token, state.token);
    }
  }
  assert.equal(visibleCoachingFor(null, "en"), null, "no state ⇒ no invented message");
});

test("the five 'cannot judge you' reasons stay distinguishable", () => {
  const reasons: AnalysisUnavailableReason[] = [
    "no-live-pose",
    "low-confidence",
    "insufficient-measurements",
    "reference-unavailable",
    "reference-incomplete",
  ];
  const headlines = new Set(
    reasons.map((r) => visibleCoachingFor(unavailable(r), "en")?.headline ?? ""),
  );
  assert.ok(
    headlines.size >= 4,
    "no-body / low-confidence / partial-body / no-reference must not collapse into one message",
  );
  assert.equal(VISIBLE_UNAVAILABLE_REASONS.length, 7);
});

test("tone carries the ENGINE severity verbatim and is never re-derived", () => {
  assert.equal(visibleCoachingFor(correction("leftKnee", "increase", "minor"), "en")?.tone, "adjust");
  assert.equal(visibleCoachingFor(correction("leftKnee", "increase", "major"), "en")?.tone, "attention");
  assert.equal(
    visibleCoachingFor({ ...correction("leftKnee", "increase", "minor"), kind: "perfect", token: "PERFECT" }, "en")?.tone,
    "ready",
  );
  assert.equal(visibleCoachingFor(unavailable("no-live-pose"), "en")?.tone, "searching");
  assert.equal(visibleCoachingFor(unavailable("reference-invalid"), "en")?.tone, "blocked");
});

test("only body messages are allowed to draw a direction arrow", () => {
  assert.equal(visibleCoachingFor(correction("leftHip", "decrease", "minor"), "en")?.aboutBody, true);
  assert.equal(visibleCoachingFor(unavailable("no-live-pose"), "en")?.aboutBody, false);
  assert.equal(
    visibleCoachingFor({ ...correction("leftHip", "decrease", "minor"), kind: "evaluating", token: "EVALUATING" }, "en")
      ?.aboutBody,
    false,
  );
});

test("English and Hindi coaching copy differ but describe the same state", () => {
  const state = correction("rightShoulder", "increase", "minor");
  const en = visibleCoachingFor(state, "en");
  const hi = visibleCoachingFor(state, "hi");
  assert.ok(en !== null && hi !== null);
  assert.equal(en.token, hi.token, "same semantic token");
  assert.equal(en.tone, hi.tone, "same tone");
  assert.notEqual(en.headline, hi.headline, "the overlay must actually change language");
});

test("an untrusted persisted language degrades to the default instruction language, never throws", () => {
  const state = correction("leftElbow", "decrease", "minor");
  const rogue = visibleCoachingFor(state, "kl-KL");
  assert.equal(rogue?.language, DEFAULT_INSTRUCTION_LANGUAGE);
  assert.equal(cameraStatusCopyFor(undefined).language, DEFAULT_INSTRUCTION_LANGUAGE);
  /* Both real choices still render their own copy — the fallback only ever
     catches values no user could have selected. */
  assert.equal(visibleCoachingFor(state, "en")?.language, "en");
  assert.equal(visibleCoachingFor(state, "hi")?.language, "hi");
});

test("countdown copy explains WHY the countdown is running", () => {
  const copy = cameraStatusCopyFor("en");
  assert.notEqual(copy.countdownReason("auto"), copy.countdownReason("gesture"));
  assert.ok(copy.countdownReason("manual").length > 0);
  assert.ok(copy.countdownReason(null).length > 0, "a bare number is never shown alone");
});

test("the match pill is a readout, not a second instruction", () => {
  const en = cameraStatusCopyFor("en");
  const hi = cameraStatusCopyFor("hi");
  assert.equal(en.formatMatch(82), "Match 82%");
  assert.notEqual(hi.formatMatch(82), en.formatMatch(82));
  assert.ok(!en.noMatchYet.toLowerCase().includes("stand"), "no imperative in the readout");
});

/* ── 4. Camera UX Part 3 — emphasis, calm, and the identity chip ─────── */

test("the rail recedes while the app is merely observing", () => {
  /* Searching for a body and evaluating one are the APP working, not the
     user failing. Neither is allowed to render at full weight over the
     subject's face for the whole session. */
  assert.equal(presentation({ coachingKind: "unavailable" }).railEmphasis, "ambient");
  assert.equal(presentation({ coachingKind: "evaluating" }).railEmphasis, "ambient");
});

test("the rail comes forward for every state the user must act on", () => {
  assert.equal(presentation({ coachingKind: "correction" }).railEmphasis, "active");
  assert.equal(presentation({ coachingKind: "perfect" }).railEmphasis, "active");
  assert.equal(
    presentation({ coachingKind: "evaluating", holdProgress: 0.4 }).railEmphasis,
    "active",
  );
});

test("emphasis never removes a surface — only its weight", () => {
  /* The calm pass must not become a hiding pass: whatever the emphasis, the
     rail is still on screen and the resolver's visibility flags are
     untouched. */
  for (const kind of ["unavailable", "evaluating", "correction", "perfect"] as const) {
    const p = presentation({ coachingKind: kind });
    assert.equal(p.showStatusRail, true);
    assert.ok(p.railEmphasis === "ambient" || p.railEmphasis === "active");
  }
});

test("the coaching band drops its second line only while the body is held", () => {
  assert.equal(presentation({ coachingKind: "correction" }).coachingEmphasis, "full");
  assert.equal(presentation({ coachingKind: "evaluating" }).coachingEmphasis, "full");
  assert.equal(presentation({ coachingKind: "perfect" }).coachingEmphasis, "compact");
  assert.equal(
    presentation({ coachingKind: "correction", holdProgress: 0.6 }).coachingEmphasis,
    "compact",
  );
});

test("the pose identity chip lives and dies with the live frame", () => {
  /* It answers \"where am I\" and carries the only non-tab-bar way out, so it
     must exist for every live frame and vanish behind every blocking layer,
     exactly like the reference art it replaced. */
  assert.equal(presentation({}).showPoseIdentity, true);
  assert.equal(presentation({}).showPoseIdentity, presentation({}).showReferenceThumb);
  assert.equal(presentation({ isProcessing: true }).showPoseIdentity, false);
  assert.equal(presentation({ countdownActive: true }).showPoseIdentity, false);
  assert.equal(presentation({ sessionLive: false }).showPoseIdentity, false);
});

test("the identity chip's copy exists in both coaching languages", () => {
  for (const language of ["en", "hi"] as const) {
    const copy = cameraStatusCopyFor(language);
    assert.ok(copy.shooting.length > 0);
    assert.ok(copy.changePose.length > 0);
  }
  assert.notEqual(
    cameraStatusCopyFor("en").changePose,
    cameraStatusCopyFor("hi").changePose,
  );
});

test("the shutter can always name its own state in the user's language", () => {
  /* The Part 3 shutter announces ready / holding / blocked through
     accessibilityValue, so every one of those three must have non-empty
     localized copy or a screen-reader user loses the distinction the halo
     and the ring give a sighted one. */
  for (const language of ["en", "hi"] as const) {
    const copy = cameraStatusCopyFor(language);
    assert.ok(copy.readiness("ready").length > 0);
    assert.ok(copy.holdAuto.length > 0);
    assert.ok(copy.holdGesture.length > 0);
    assert.ok(copy.captureBlocked("camera-warming").length > 0);
    assert.equal(copy.captureBlocked("none"), "");
  }
});
