/**
 * tests/camera/gestureCapture.test.ts — SAFE, INTENTIONAL GESTURE CAPTURE.
 *
 * Three pure modules under test, no device, no camera, no MediaPipe, no
 * network and no real clock — every timing assertion runs on a fake clock at
 * the real 15 fps camera cadence (66 ms per frame):
 *
 *   1. shared/ml/openPalmClassifier — single-frame EVIDENCE. Proves that a
 *      fist, one/two/three/four fingers, an edge-on palm, a tiny hand and a
 *      low-confidence detection are all rejected, and that a genuine
 *      five-finger palm is accepted.
 *   2. shared/ml/openPalmGate — TEMPORAL CONFIRMATION. Proves that one frame
 *      is never enough, that a moving hand never confirms, that a dropped
 *      frame does not destroy a genuine hold, and that a held palm cannot
 *      fire twice without being released.
 *   3. shared/camera/intelligentCaptureController — ARBITRATION. Proves that
 *      gesture, auto and manual capture cannot fight, and that manual capture
 *      is never delayed by any of this.
 *
 * The hand geometry comes from tests/camera/handFixtures.ts: synthetic, but
 * generated from real MediaPipe proportions by ONE code path, so "fist" is
 * the same hand as "open palm" with its joints flexed.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  classifyOpenPalm,
  selectCaptureHand,
  OPEN_PALM_THRESHOLDS,
  type OpenPalmEvidence,
} from "../../shared/ml/openPalmClassifier";
import {
  OpenPalmGate,
  OPEN_PALM_GATE_TIMING,
} from "../../shared/ml/openPalmGate";
import { detectHandPresentation } from "../../shared/ml/gestureDetector";
import { POSE_LANDMARKS, type PoseLandmark } from "../../shared/ml/poseLandmarks";
import { IntelligentCaptureController } from "../../shared/camera/intelligentCaptureController";
import { cameraStatusCopyFor } from "../../shared/camera/cameraStatusCopy";
import { fistHand, makeHand, nFingerHand, openPalmHand } from "./handFixtures";

/** The real camera cadence this feature lives at. */
const FRAME_MS = 66;

/* ══════════════════════════════════════════════════════════════════════
   1. SINGLE-FRAME EVIDENCE
   ══════════════════════════════════════════════════════════════════════ */

test("no hand at all is never an open palm", () => {
  assert.equal(classifyOpenPalm(null).isOpenPalm, false);
  assert.equal(classifyOpenPalm(null).rejection, "no-hand");
  assert.equal(selectCaptureHand(null).isOpenPalm, false);
  assert.equal(selectCaptureHand([]).isOpenPalm, false);
  assert.equal(selectCaptureHand([]).rejection, "no-hand");
});

test("incomplete landmark arrays are rejected, not guessed at", () => {
  const partial = { ...openPalmHand(), landmarks: openPalmHand().landmarks.slice(0, 12) };
  const evidence = classifyOpenPalm(partial);
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.rejection, "incomplete-landmarks");
});

test("a genuine five-finger open palm IS recognised", () => {
  const evidence = classifyOpenPalm(openPalmHand());
  assert.equal(evidence.isOpenPalm, true);
  assert.equal(evidence.rejection, "none");
  assert.equal(evidence.extendedCount, 5);
  assert.ok(evidence.score >= OPEN_PALM_THRESHOLDS.minScore);
});

test("recognition does not depend on the hand being upright", () => {
  for (const rotationDegrees of [-40, -15, 0, 15, 40]) {
    const evidence = classifyOpenPalm(openPalmHand({ rotationDegrees }));
    assert.equal(evidence.isOpenPalm, true, `rotation ${rotationDegrees}`);
  }
});

test("a closed fist is never an open palm", () => {
  const evidence = classifyOpenPalm(fistHand());
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.rejection, "fingers-not-extended");
  assert.equal(evidence.extendedCount, 0);
});

test("one, two, three and four fingers are all refused", () => {
  for (const count of [0, 1, 2, 3, 4] as const) {
    const evidence = classifyOpenPalm(nFingerHand(count));
    assert.equal(evidence.isOpenPalm, false, `${count} fingers must not capture`);
    assert.equal(evidence.rejection, "fingers-not-extended");
    assert.equal(evidence.extendedCount, count);
  }
});

test("four fingers plus an extended thumb is still not five", () => {
  const evidence = classifyOpenPalm(makeHand({ extended: { pinky: false } }));
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.extendedCount, 4);
  assert.equal(
    evidence.fingers.find((finger) => finger.finger === "pinky")?.extended,
    false,
  );
});

test("a tucked thumb alone is enough to refuse the gesture", () => {
  const evidence = classifyOpenPalm(makeHand({ extended: { thumb: false } }));
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.extendedCount, 4);
});

test("an edge-on hand is refused however straight the fingers are", () => {
  const evidence = classifyOpenPalm(openPalmHand({ edgeOn: 0.45 }));
  assert.equal(evidence.extendedCount, 5, "fingers still read as extended");
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.rejection, "palm-not-facing-camera");
});

test("a hand too small to carry geometry is refused", () => {
  const evidence = classifyOpenPalm(openPalmHand({ scale: 0.3 }));
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.rejection, "degenerate-scale");
});

test("a low-confidence detection is refused before any geometry is read", () => {
  const evidence = classifyOpenPalm(openPalmHand({ score: 0.45 }));
  assert.equal(evidence.isOpenPalm, false);
  assert.equal(evidence.rejection, "low-confidence");
  assert.equal(evidence.extendedCount, 0);
});

test("with two hands up, the open palm wins over the fist", () => {
  const evidence = selectCaptureHand([
    fistHand({ center: [0.3, 0.5] }),
    openPalmHand({ center: [0.7, 0.5], side: "left" }),
  ]);
  assert.equal(evidence.isOpenPalm, true);
  assert.equal(evidence.side, "left");
});

test("two non-palms never add up to a palm", () => {
  const evidence = selectCaptureHand([
    fistHand({ center: [0.3, 0.5] }),
    nFingerHand(2, { center: [0.7, 0.5] }),
  ]);
  assert.equal(evidence.isOpenPalm, false);
});

/* ══════════════════════════════════════════════════════════════════════
   2. THE POSE-LEVEL PRE-FILTER IS NOT A GESTURE
   ══════════════════════════════════════════════════════════════════════ */

function poseWithRaisedHand(raised: boolean): PoseLandmark[] {
  const landmarks: PoseLandmark[] = Array.from({ length: 33 }, () => ({
    x: 0.5,
    y: 0.5,
    z: 0,
    visibility: 0.9,
  }));
  landmarks[POSE_LANDMARKS.rightShoulder] = { x: 0.45, y: 0.4, z: 0, visibility: 0.9 };
  landmarks[POSE_LANDMARKS.rightElbow] = { x: 0.5, y: 0.55, z: 0, visibility: 0.9 };
  landmarks[POSE_LANDMARKS.rightWrist] = {
    x: 0.52,
    y: raised ? 0.35 : 0.72,
    z: 0,
    visibility: 0.9,
  };
  landmarks[POSE_LANDMARKS.rightIndex] = {
    x: 0.53,
    y: raised ? 0.31 : 0.76,
    z: 0,
    visibility: 0.9,
  };
  landmarks[POSE_LANDMARKS.rightPinky] = {
    x: 0.5,
    y: raised ? 0.31 : 0.76,
    z: 0,
    visibility: 0.9,
  };
  return landmarks;
}

test("the pose pre-filter only asks 'is a hand raised', and says so", () => {
  assert.equal(detectHandPresentation([]).present, false);
  assert.equal(detectHandPresentation(poseWithRaisedHand(false)).present, false);
  const raised = detectHandPresentation(poseWithRaisedHand(true));
  assert.equal(raised.present, true);
  assert.equal(raised.hand, "right");
  /* The contract that matters: `present` is NOT a capture authorisation.
     It carries no finger information at all, which is exactly why the
     classifier above exists. */
  assert.equal("detected" in raised, false);
});

/* ══════════════════════════════════════════════════════════════════════
   3. TEMPORAL CONFIRMATION
   ══════════════════════════════════════════════════════════════════════ */

const PALM: OpenPalmEvidence = classifyOpenPalm(openPalmHand());
const FIST: OpenPalmEvidence = classifyOpenPalm(fistHand());

interface RunResult {
  readonly confirmations: number;
  readonly lastPhase: string;
  readonly lastProgress: number;
  readonly clock: number;
}

/** Feeds the gate `frames` frames of one evidence value at 15 fps. */
function run(
  gate: OpenPalmGate,
  frames: number,
  evidence: OpenPalmEvidence | null,
  startClock: number,
  mutate?: (frame: number) => OpenPalmEvidence | null,
): RunResult {
  let clock = startClock;
  let confirmations = 0;
  let lastPhase = "idle";
  let lastProgress = 0;
  for (let frame = 0; frame < frames; frame += 1) {
    const value = mutate === undefined ? evidence : mutate(frame);
    const snapshot = gate.update({ nowMs: clock, evidence: value });
    if (snapshot.confirmed) confirmations += 1;
    lastPhase = snapshot.phase;
    lastProgress = snapshot.progress;
    clock += FRAME_MS;
  }
  return { confirmations, lastPhase, lastProgress, clock };
}

test("ONE open-palm frame is never a capture", () => {
  const gate = new OpenPalmGate();
  const snapshot = gate.update({ nowMs: 1_000, evidence: PALM });
  assert.equal(snapshot.confirmed, false);
  assert.equal(snapshot.phase, "candidate");
  assert.equal(snapshot.progress, 0);
});

test("a transient palm (5 frames ≈ 330 ms) never confirms", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 5, PALM, 1_000);
  assert.equal(result.confirmations, 0);
  assert.ok(result.lastProgress < 1);
  // …and then it is gone again, with no capture ever issued.
  const after = run(gate, 10, null, result.clock);
  assert.equal(after.confirmations, 0);
  assert.equal(after.lastPhase, "idle");
});

test("a stable, deliberately held palm confirms exactly once", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 40, PALM, 1_000);
  assert.equal(result.confirmations, 1, "one presentation → one capture command");
});

test("confirmation needs BOTH the hold time and the frame count", () => {
  /* Two frames 1.5 s apart satisfy wall time but not evidence: a detector
     blinking twice must not be read as a held gesture. */
  const gate = new OpenPalmGate();
  assert.equal(gate.update({ nowMs: 0, evidence: PALM }).confirmed, false);
  assert.equal(gate.update({ nowMs: 1_500, evidence: PALM }).confirmed, false);
});

test("progress rises monotonically and only reaches 1 at the confirming frame", () => {
  const gate = new OpenPalmGate();
  let clock = 0;
  let previous = -1;
  let confirmedAt = -1;
  for (let frame = 0; frame < 40; frame += 1) {
    const snapshot = gate.update({ nowMs: clock, evidence: PALM });
    if (confirmedAt === -1) {
      assert.ok(snapshot.progress >= previous, "progress must not go backwards");
      previous = snapshot.progress;
      if (snapshot.confirmed) confirmedAt = frame;
    }
    clock += FRAME_MS;
  }
  assert.ok(confirmedAt > 0);
  /* The user really has to hold it: at 15 fps this is ~1.2 s of palm. */
  assert.ok(
    confirmedAt * FRAME_MS >= OPEN_PALM_GATE_TIMING.confirmHoldMs - FRAME_MS,
    `confirmed after only ${confirmedAt * FRAME_MS}ms`,
  );
});

test("a fist held forever never confirms", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 120, FIST, 0);
  assert.equal(result.confirmations, 0);
  assert.equal(result.lastPhase, "idle");
});

test("an ambiguous hand (four fingers) held forever never confirms", () => {
  const gate = new OpenPalmGate();
  const ambiguous = classifyOpenPalm(nFingerHand(4));
  const result = run(gate, 120, ambiguous, 0);
  assert.equal(result.confirmations, 0);
});

test("a low-confidence palm held forever never confirms", () => {
  const gate = new OpenPalmGate();
  const weak = classifyOpenPalm(openPalmHand({ score: 0.5 }));
  const result = run(gate, 120, weak, 0);
  assert.equal(result.confirmations, 0);
});

test("a waving hand never confirms — the palm has to be held still", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 120, null, 0, (frame) => ({
    ...PALM,
    // ±0.09 normalized units per 66 ms ≈ 1.4 palm-widths/s and beyond.
    centroidX: 0.5 + (frame % 2 === 0 ? 0.09 : -0.09),
  }));
  assert.equal(result.confirmations, 0);
});

test("slow, natural drift while holding is tolerated", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 40, null, 0, (frame) => ({
    ...PALM,
    centroidX: 0.5 + frame * 0.0008,
    centroidY: 0.5 + frame * 0.0005,
  }));
  assert.equal(result.confirmations, 1);
});

test("one dropped detection does not destroy a genuine hold", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 40, null, 0, (frame) =>
    frame === 7 || frame === 15 ? null : PALM,
  );
  assert.equal(result.confirmations, 1);
});

test("the gesture disappearing mid-confirmation restarts the hold", () => {
  const gate = new OpenPalmGate();
  // 10 frames of palm (not yet enough), then a clear absence, then 10 more.
  run(gate, 10, PALM, 0);
  const gap = run(gate, 10, null, 10 * FRAME_MS);
  assert.equal(gap.lastPhase, "idle", "a real gap ends the presentation");
  const resumed = run(gate, 10, PALM, gap.clock);
  assert.equal(
    resumed.confirmations,
    0,
    "the second short presentation must start from zero, not resume",
  );
});

test("the gesture reappearing and being held properly does confirm", () => {
  const gate = new OpenPalmGate();
  run(gate, 6, PALM, 0);
  const gap = run(gate, 20, null, 6 * FRAME_MS);
  const resumed = run(gate, 40, PALM, gap.clock);
  assert.equal(resumed.confirmations, 1);
});

/* ── cooldown / re-arm ───────────────────────────────────────────────── */

test("HOLDING the palm after a capture does NOT fire again", () => {
  const gate = new OpenPalmGate();
  // 8 seconds of continuously held open palm.
  const result = run(gate, 121, PALM, 0);
  assert.equal(
    result.confirmations,
    1,
    "capture → still holding → capture → capture is the bug being fixed",
  );
  assert.equal(result.lastPhase, "awaiting-release");
});

test("re-arming requires the palm to be released AND the cooldown to pass", () => {
  const gate = new OpenPalmGate();
  const first = run(gate, 40, PALM, 0);
  assert.equal(first.confirmations, 1);

  // Drop the hand immediately: the cooldown still has to elapse.
  const shortRelease = run(gate, 5, null, first.clock);
  assert.equal(shortRelease.lastPhase, "cooldown");

  // Long enough absence, past the cooldown, re-arms the gate.
  const fullRelease = run(gate, 60, null, shortRelease.clock);
  assert.equal(fullRelease.lastPhase, "idle");

  // A fresh, deliberate presentation is accepted again.
  const second = run(gate, 40, PALM, fullRelease.clock);
  assert.equal(second.confirmations, 1);
});

test("cooldown cannot be waited out while the palm stays up", () => {
  const gate = new OpenPalmGate();
  run(gate, 40, PALM, 0);
  // Hold for well past the cooldown without ever lowering the hand.
  const held = run(gate, 90, PALM, 40 * FRAME_MS);
  assert.equal(held.confirmations, 0);
  assert.equal(held.lastPhase, "awaiting-release");
});

test("notifyCaptureCommitted extends the lock across the capture flow", () => {
  const gate = new OpenPalmGate();
  gate.notifyCaptureCommitted(0);
  const during = run(gate, 30, PALM, FRAME_MS);
  assert.equal(during.confirmations, 0);
  assert.equal(during.lastPhase, "cooldown");
});

test("reset() fully re-arms the gate for a new session", () => {
  const gate = new OpenPalmGate();
  run(gate, 40, PALM, 0);
  gate.reset();
  const after = run(gate, 40, PALM, 10_000);
  assert.equal(after.confirmations, 1);
});

test("a null evidence stream (gesture capture off) can never confirm", () => {
  const gate = new OpenPalmGate();
  const result = run(gate, 300, null, 0);
  assert.equal(result.confirmations, 0);
  assert.equal(result.lastPhase, "idle");
});

/* ══════════════════════════════════════════════════════════════════════
   4. ARBITRATION WITH AUTO AND MANUAL CAPTURE
   ══════════════════════════════════════════════════════════════════════ */

const BASE = {
  autoThreshold: 90,
  autoEnabled: true,
  gestureEnabled: true,
  gestureProgress: 0,
  gestureConfirmed: false,
} as const;

test("gesture capture fires only on the confirmation edge", () => {
  const controller = new IntelligentCaptureController();
  assert.equal(
    controller.update({ ...BASE, nowMs: 0, matchPercent: 10, gestureProgress: 0.99 })
      .trigger,
    null,
    "99% progress is not a capture",
  );
  assert.equal(
    controller.update({
      ...BASE,
      nowMs: FRAME_MS,
      matchPercent: 10,
      gestureConfirmed: true,
      gestureProgress: 1,
    }).trigger,
    "gesture",
  );
});

test("gesture capture respects the gestureEnabled switch", () => {
  const controller = new IntelligentCaptureController();
  const snapshot = controller.update({
    ...BASE,
    nowMs: 0,
    matchPercent: null,
    gestureEnabled: false,
    gestureConfirmed: true,
    gestureProgress: 1,
  });
  assert.equal(snapshot.trigger, null);
  assert.equal(snapshot.gestureProgress, 0);
});

test("auto capture semantics are unchanged by the gesture rework", () => {
  const controller = new IntelligentCaptureController();
  let trigger: string | null = null;
  for (let clock = 0; clock <= 2_100; clock += FRAME_MS) {
    const snapshot = controller.update({ ...BASE, nowMs: clock, matchPercent: 95 });
    if (snapshot.trigger !== null) {
      trigger = snapshot.trigger;
      assert.ok(clock >= 2_000, `auto fired early at ${clock}ms`);
      break;
    }
  }
  assert.equal(trigger, "auto");
});

test("a gesture confirmed on the same frame as the auto hold wins", () => {
  const controller = new IntelligentCaptureController();
  for (let clock = 0; clock < 2_000; clock += FRAME_MS) {
    controller.update({ ...BASE, nowMs: clock, matchPercent: 95 });
  }
  const snapshot = controller.update({
    ...BASE,
    nowMs: 2_100,
    matchPercent: 95,
    gestureConfirmed: true,
    gestureProgress: 1,
  });
  assert.equal(snapshot.trigger, "gesture");
});

test("gesture capture does not suppress auto capture when it never fires", () => {
  const controller = new IntelligentCaptureController();
  let fired: string | null = null;
  for (let clock = 0; clock <= 2_200; clock += FRAME_MS) {
    const snapshot = controller.update({
      ...BASE,
      nowMs: clock,
      matchPercent: 95,
      // A palm is being recognised but has NOT been confirmed.
      gestureProgress: 0.6,
    });
    if (snapshot.trigger !== null) {
      fired = snapshot.trigger;
      break;
    }
  }
  assert.equal(fired, "auto");
});

test("the controller lock still stops a second trigger of any kind", () => {
  const controller = new IntelligentCaptureController();
  const first = controller.update({
    ...BASE,
    nowMs: 1_000,
    matchPercent: 95,
    gestureConfirmed: true,
    gestureProgress: 1,
  });
  assert.equal(first.trigger, "gesture");
  const second = controller.update({
    ...BASE,
    nowMs: 1_066,
    matchPercent: 95,
    gestureConfirmed: true,
    gestureProgress: 1,
  });
  assert.equal(second.trigger, null);
  assert.equal(second.locked, true);
  assert.equal(controller.requestManual(1_100), false);
});

test("manual capture stays immediate and is never delayed by gesture work", () => {
  const controller = new IntelligentCaptureController();
  // A palm is mid-confirmation; the user taps the shutter anyway.
  controller.update({ ...BASE, nowMs: 0, matchPercent: 20, gestureProgress: 0.8 });
  assert.equal(controller.requestManual(66), true, "manual must not be blocked");
  controller.cancel();
  assert.equal(controller.requestManual(4_000), true);
});

test("a cancelled countdown unlocks the controller without capturing", () => {
  const controller = new IntelligentCaptureController();
  controller.update({
    ...BASE,
    nowMs: 0,
    matchPercent: 95,
    gestureConfirmed: true,
    gestureProgress: 1,
  });
  controller.cancel();
  assert.equal(
    controller.update({ ...BASE, nowMs: 100, matchPercent: 95 }).locked,
    false,
  );
});

/* ══════════════════════════════════════════════════════════════════════
   5. WHAT THE USER IS TOLD
   ══════════════════════════════════════════════════════════════════════ */

test("the four gesture phases are distinguishable, and silence stays silent", () => {
  for (const language of ["en", "hi"] as const) {
    const copy = cameraStatusCopyFor(language);
    assert.equal(copy.gesturePhase("idle"), "", "idle must render nothing");
    assert.equal(copy.gesturePhase("cooldown"), "", "cooldown must render nothing");
    assert.notEqual(copy.gesturePhase("candidate"), "");
    assert.notEqual(copy.gesturePhase("confirming"), "");
    assert.notEqual(copy.gesturePhase("confirmed"), "");
    assert.notEqual(copy.gesturePhase("awaiting-release"), "");
    assert.notEqual(
      copy.gesturePhase("candidate"),
      copy.gesturePhase("confirmed"),
      "'being recognised' must not read the same as 'confirmed'",
    );
  }
});

/* ══════════════════════════════════════════════════════════════════════
   6. END-TO-END, ON THE FAKE CLOCK: THE FAILURE MODE THAT STARTED THIS
   ══════════════════════════════════════════════════════════════════════ */

test("an accidental raised hand produces ZERO photographs", () => {
  const gate = new OpenPalmGate();
  const controller = new IntelligentCaptureController();
  let captures = 0;
  let clock = 0;
  /* 4 seconds of a person moving a hand around: a fist, a two-finger point,
     a fast-moving open hand, a fist again. Every frame is a raised hand — the
     exact input the old pose-only detector fired on. */
  const script: readonly (OpenPalmEvidence | null)[] = [
    FIST,
    classifyOpenPalm(nFingerHand(2)),
    { ...PALM, centroidX: 0.2 },
    { ...PALM, centroidX: 0.8 },
    FIST,
    null,
  ];
  for (let frame = 0; frame < 60; frame += 1) {
    const evidence = script[frame % script.length] ?? null;
    const gateSnapshot = gate.update({ nowMs: clock, evidence });
    const snapshot = controller.update({
      ...BASE,
      nowMs: clock,
      matchPercent: 40,
      gestureConfirmed: gateSnapshot.confirmed,
      gestureProgress: gateSnapshot.progress,
    });
    if (snapshot.trigger !== null) captures += 1;
    clock += FRAME_MS;
  }
  assert.equal(captures, 0);
});

test("a deliberate palm, held, then held again produces exactly two photographs", () => {
  const gate = new OpenPalmGate();
  const controller = new IntelligentCaptureController();
  let captures = 0;
  let clock = 0;
  const feed = (frames: number, evidence: OpenPalmEvidence | null) => {
    for (let frame = 0; frame < frames; frame += 1) {
      const gateSnapshot = gate.update({ nowMs: clock, evidence });
      const snapshot = controller.update({
        ...BASE,
        nowMs: clock,
        matchPercent: 40,
        gestureConfirmed: gateSnapshot.confirmed,
        gestureProgress: gateSnapshot.progress,
      });
      if (snapshot.trigger !== null) {
        captures += 1;
        gate.notifyCaptureCommitted(clock);
        controller.cancel(); // the capture flow completed and released the lock
      }
      clock += FRAME_MS;
    }
  };
  feed(40, PALM); // deliberate presentation → 1
  feed(40, PALM); // STILL holding → must add nothing
  feed(80, null); // hand lowered, cooldown + release satisfied
  feed(40, PALM); // presented again → 2
  assert.equal(captures, 2);
});
