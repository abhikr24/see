/**
 * tests/camera/handFixtures.ts — SYNTHETIC hand-landmark fixtures.
 *
 * TEST-ONLY. Nothing here is imported by shared/, mobile/ or tooling/: these
 * are generated geometries used to prove the classifier's thresholds, never a
 * production default and never a stand-in for a real detection.
 *
 * The generator builds a 21-point hand from real MediaPipe proportions in a
 * local frame (hand pointing up the −y axis, wrist at the origin), then
 * scales and translates it into normalized image space. Each finger is a
 * three-segment chain whose joints can be bent, so "curled" and "extended"
 * fingers are produced by the SAME code path — a fist is not a hand-written
 * blob of coordinates that happens to fail, it is the identical hand with its
 * joints flexed.
 */
import {
  HAND_LANDMARKS,
  type HandLandmark,
  type HandObservation,
  type HandSide,
} from "../../shared/ml/handLandmarks";

export interface FingerSpec {
  /** Knuckle position in the local frame. */
  readonly mcp: readonly [number, number];
  /** Base direction (will be normalized). */
  readonly direction: readonly [number, number];
  /** Proximal / middle / distal segment lengths. */
  readonly lengths: readonly [number, number, number];
}

/* Proportions relative to a palm width of ~1.0 (index MCP → pinky MCP). */
const FINGERS: Readonly<Record<"index" | "middle" | "ring" | "pinky", FingerSpec>> = {
  index: { mcp: [-0.45, -1.15], direction: [-0.13, -0.99], lengths: [0.62, 0.36, 0.26] },
  middle: { mcp: [-0.15, -1.22], direction: [-0.02, -1.0], lengths: [0.68, 0.4, 0.28] },
  ring: { mcp: [0.15, -1.18], direction: [0.12, -0.99], lengths: [0.62, 0.38, 0.26] },
  pinky: { mcp: [0.5, -1.05], direction: [0.26, -0.97], lengths: [0.48, 0.3, 0.22] },
};

const THUMB_CMC: readonly [number, number] = [-0.36, -0.3];
/** Thumb chain in the local frame, fully abducted (open palm). */
const THUMB_OPEN: readonly (readonly [number, number])[] = [
  [-0.72, -0.6],
  [-1.0, -0.82],
  [-1.18, -0.98],
];
/** Thumb tucked across the palm (fist / closed hand). */
const THUMB_TUCKED: readonly (readonly [number, number])[] = [
  [-0.5, -0.72],
  [-0.3, -0.95],
  [-0.08, -1.02],
];

function rotate(
  vector: readonly [number, number],
  radians: number,
): [number, number] {
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  return [
    vector[0] * cos - vector[1] * sin,
    vector[0] * sin + vector[1] * cos,
  ];
}

function normalize(vector: readonly [number, number]): [number, number] {
  const length = Math.hypot(vector[0], vector[1]) || 1;
  return [vector[0] / length, vector[1] / length];
}

/** Builds MCP→PIP→DIP→TIP for one finger with the given per-joint flexion. */
function buildFinger(
  spec: FingerSpec,
  bendDegrees: number,
): readonly (readonly [number, number])[] {
  const bend = (bendDegrees * Math.PI) / 180;
  let direction = normalize(spec.direction);
  let point: [number, number] = [spec.mcp[0], spec.mcp[1]];
  const chain: [number, number][] = [];
  for (let segment = 0; segment < 3; segment += 1) {
    if (segment > 0) direction = rotate(direction, bend);
    const length = spec.lengths[segment] ?? 0;
    point = [point[0] + direction[0] * length, point[1] + direction[1] * length];
    chain.push([point[0], point[1]]);
  }
  return chain;
}

export interface HandFixtureOptions {
  /** Which fingers are extended; the rest are curled into the palm. */
  readonly extended?: {
    readonly thumb?: boolean;
    readonly index?: boolean;
    readonly middle?: boolean;
    readonly ring?: boolean;
    readonly pinky?: boolean;
  };
  /** Detector handedness/presence score. */
  readonly score?: number;
  readonly side?: HandSide;
  /** Normalized-image scale multiplier (1 ≈ a hand ~0.1 of frame width). */
  readonly scale?: number;
  /** Centre of the hand in normalized image space. */
  readonly center?: readonly [number, number];
  /**
   * 0 = palm square to the camera, 1 = fully edge-on. Implemented as a
   * horizontal squash, which is exactly what perspective does to a rotating
   * palm and what collapses the palm-width / palm-length aspect.
   */
  readonly edgeOn?: number;
  /** Whole-hand rotation in degrees (deliberate presentation is not upright-only). */
  readonly rotationDegrees?: number;
}

/** 100° of flexion per joint: an unambiguous curl, as in a real fist. */
const CURLED_BEND = 100;
/** Real fingers are never perfectly straight; 6° keeps the fixture honest. */
const EXTENDED_BEND = 6;

export function makeHand(options: HandFixtureOptions = {}): HandObservation {
  const extended = {
    thumb: options.extended?.thumb ?? true,
    index: options.extended?.index ?? true,
    middle: options.extended?.middle ?? true,
    ring: options.extended?.ring ?? true,
    pinky: options.extended?.pinky ?? true,
  };
  const scale = (options.scale ?? 1) * 0.1;
  const center = options.center ?? [0.5, 0.5];
  const squash = 1 - Math.max(0, Math.min(0.95, options.edgeOn ?? 0));
  const rotation = ((options.rotationDegrees ?? 0) * Math.PI) / 180;

  const local: (readonly [number, number])[] = new Array(21).fill([0, 0]);
  local[HAND_LANDMARKS.wrist] = [0, 0];

  const thumbChain = extended.thumb ? THUMB_OPEN : THUMB_TUCKED;
  local[HAND_LANDMARKS.thumbCmc] = THUMB_CMC;
  local[HAND_LANDMARKS.thumbMcp] = thumbChain[0] ?? [0, 0];
  local[HAND_LANDMARKS.thumbIp] = thumbChain[1] ?? [0, 0];
  local[HAND_LANDMARKS.thumbTip] = thumbChain[2] ?? [0, 0];

  const jointed = [
    { name: "index", mcpIndex: HAND_LANDMARKS.indexMcp, on: extended.index },
    { name: "middle", mcpIndex: HAND_LANDMARKS.middleMcp, on: extended.middle },
    { name: "ring", mcpIndex: HAND_LANDMARKS.ringMcp, on: extended.ring },
    { name: "pinky", mcpIndex: HAND_LANDMARKS.pinkyMcp, on: extended.pinky },
  ] as const;

  for (const finger of jointed) {
    const spec = FINGERS[finger.name];
    local[finger.mcpIndex] = spec.mcp;
    const chain = buildFinger(spec, finger.on ? EXTENDED_BEND : CURLED_BEND);
    local[finger.mcpIndex + 1] = chain[0] ?? spec.mcp;
    local[finger.mcpIndex + 2] = chain[1] ?? spec.mcp;
    local[finger.mcpIndex + 3] = chain[2] ?? spec.mcp;
  }

  const landmarks: HandLandmark[] = local.map(([x, y]) => {
    const squashed: [number, number] = [x * squash, y];
    const [rx, ry] = rotate(squashed, rotation);
    return {
      x: center[0] + rx * scale,
      y: center[1] + ry * scale,
      z: 0,
    };
  });

  return {
    landmarks,
    side: options.side ?? "right",
    score: options.score ?? 0.95,
  };
}

/** The canonical intentional gesture: five fingers, square to the camera. */
export function openPalmHand(
  overrides: HandFixtureOptions = {},
): HandObservation {
  return makeHand(overrides);
}

/** The canonical accident: a raised hand that is NOT a command. */
export function fistHand(overrides: HandFixtureOptions = {}): HandObservation {
  return makeHand({
    ...overrides,
    extended: {
      thumb: false,
      index: false,
      middle: false,
      ring: false,
      pinky: false,
    },
  });
}

/** Exactly `count` of the four jointed fingers extended, thumb tucked. */
export function nFingerHand(
  count: 0 | 1 | 2 | 3 | 4,
  overrides: HandFixtureOptions = {},
): HandObservation {
  return makeHand({
    ...overrides,
    extended: {
      thumb: false,
      index: count >= 1,
      middle: count >= 2,
      ring: count >= 3,
      pinky: count >= 4,
    },
  });
}
