/**
 * tests/camera/photoEditing.test.ts — POST-CAPTURE EDITING.
 *
 * Everything under test is pure: no device, no Skia, no filesystem, no GPU.
 * Each case pins a promise the feature makes to the user, not a line of code:
 *
 *   · "if you change nothing, your photo is not touched"   → identity totality
 *   · "a quarter turn is a quarter turn"                   → rotation algebra
 *   · "the shape you picked is the shape you get"          → locked-ratio crop
 *   · "the crop cannot escape the photo"                   → clamping totality
 *   · "rotating does not throw your crop away"             → crop carry-through
 *   · "Enhanced is exactly those four slider positions"    → no hidden engine
 *   · "brighter is brighter, and grey stays put"           → matrix behaviour
 *   · "the preview and the file use the same transform"    → draw transform
 *   · "this is NOT the camera's brightness control"        → separation
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  AUTO_ENHANCE,
  CROP_ASPECT_IDS,
  CROP_MIN_FRACTION,
  ENHANCE_NEUTRAL,
  FULL_FRAME_CROP,
  PHOTO_ADJUST_KEYS,
  PHOTO_EDIT_ADJUST_MAX,
  PHOTO_EDIT_ADJUST_MIN,
  PHOTO_EDIT_ADJUST_STEP,
  PHOTO_EDIT_JPEG_QUALITY,
  PHOTO_EDIT_NONE,
  adjustBadge,
  adjustBrightnessGain,
  applyCropGesture,
  clampAdjustValue,
  clampCropAspectId,
  clampNormalizedRect,
  clampPhotoEdit,
  clampQuarterTurns,
  cropAspectValue,
  cropIsFullFrame,
  cropRectForAspect,
  cropRectToPixels,
  describePhotoEdit,
  editedFileName,
  enhanceColorMatrix,
  enhanceIsNeutral,
  isAutoEnhance,
  isEditTempFileName,
  photoEditDrawTransform,
  photoEditIsIdentity,
  resolvePhotoEditGeometry,
  rotateCropRect,
  rotateQuarterTurns,
  rotatedSize,
  rotationDegrees,
  rotationLabel,
} from "../../shared/camera/photoEditing";
import {
  applyColorMatrix,
  colorMatrixIsIdentity,
  luminanceOf,
} from "../../shared/camera/cameraFilters";
import {
  BRIGHTNESS_DEFAULT,
  BRIGHTNESS_MAX,
  brightnessGain,
} from "../../shared/camera/cameraControls";

/* ───────────────────────────── identity ───────────────────────────────── */

test("the empty edit is the identity — an untouched photo is never re-encoded", () => {
  assert.equal(photoEditIsIdentity(PHOTO_EDIT_NONE), true);
  assert.equal(photoEditIsIdentity(undefined), true);
  assert.equal(photoEditIsIdentity({}), true);
  assert.equal(describePhotoEdit(PHOTO_EDIT_NONE), "No changes");
});

test("any one change is enough to stop being the identity", () => {
  assert.equal(photoEditIsIdentity({ ...PHOTO_EDIT_NONE, rotation: 1 }), false);
  assert.equal(
    photoEditIsIdentity({
      ...PHOTO_EDIT_NONE,
      crop: { x: 0.1, y: 0.1, width: 0.5, height: 0.5 },
    }),
    false,
  );
  assert.equal(
    photoEditIsIdentity({ ...PHOTO_EDIT_NONE, enhance: AUTO_ENHANCE }),
    false,
  );
});

test("clampPhotoEdit is total — garbage in, a valid edit out", () => {
  const edit = clampPhotoEdit({
    rotation: 97,
    crop: { x: -4, y: 12, width: 900, height: Number.NaN },
    enhance: { brightness: 5_000, contrast: "x", saturation: null, warmth: -9_000 },
  });
  assert.ok(edit.rotation >= 0 && edit.rotation <= 3);
  assert.ok(edit.crop.x >= 0 && edit.crop.x + edit.crop.width <= 1 + 1e-9);
  assert.ok(edit.crop.y >= 0 && edit.crop.y + edit.crop.height <= 1 + 1e-9);
  assert.equal(edit.enhance.brightness, PHOTO_EDIT_ADJUST_MAX);
  assert.equal(edit.enhance.warmth, PHOTO_EDIT_ADJUST_MIN);
  assert.equal(edit.enhance.contrast, 0);
});

/* ───────────────────────────── rotation ───────────────────────────────── */

test("four quarter turns return to the start, in both directions", () => {
  let clockwise = 0;
  let anticlockwise = 0;
  for (let i = 0; i < 4; i += 1) {
    clockwise = rotateQuarterTurns(clockwise, 1);
    anticlockwise = rotateQuarterTurns(anticlockwise, -1);
  }
  assert.equal(clockwise, 0);
  assert.equal(anticlockwise, 0);
  assert.equal(clampQuarterTurns(-1), 3);
  assert.equal(clampQuarterTurns(4), 0);
  assert.equal(clampQuarterTurns("nonsense"), 0);
});

test("odd turns swap the axes and even turns do not", () => {
  assert.deepEqual(rotatedSize(4000, 3000, 0), { width: 4000, height: 3000 });
  assert.deepEqual(rotatedSize(4000, 3000, 1), { width: 3000, height: 4000 });
  assert.deepEqual(rotatedSize(4000, 3000, 2), { width: 4000, height: 3000 });
  assert.deepEqual(rotatedSize(4000, 3000, 3), { width: 3000, height: 4000 });
  assert.equal(rotationDegrees(3), 270);
  assert.equal(rotationLabel(0), "Upright");
});

test("rotating carries the crop with the photo instead of discarding it", () => {
  const crop = { x: 0.1, y: 0.2, width: 0.4, height: 0.3 };
  const clockwise = rotateCropRect(crop, 1);
  assert.ok(Math.abs(clockwise.width - crop.height) < 1e-9);
  assert.ok(Math.abs(clockwise.height - crop.width) < 1e-9);
  /* Four turns must land exactly back on the original rectangle. */
  let carried = crop;
  for (let i = 0; i < 4; i += 1) carried = rotateCropRect(carried, 1);
  assert.ok(Math.abs(carried.x - crop.x) < 1e-9);
  assert.ok(Math.abs(carried.y - crop.y) < 1e-9);
  assert.ok(Math.abs(carried.width - crop.width) < 1e-9);
  assert.ok(Math.abs(carried.height - crop.height) < 1e-9);
  /* And one turn each way is a round trip. */
  const there = rotateCropRect(crop, 1);
  const back = rotateCropRect(there, -1);
  assert.ok(Math.abs(back.x - crop.x) < 1e-9);
  assert.ok(Math.abs(back.y - crop.y) < 1e-9);
});

/* ─────────────────────────────── crop ─────────────────────────────────── */

test("a crop can never leave the frame, however it is abused", () => {
  const cases: unknown[] = [
    { x: -1, y: -1, width: 2, height: 2 },
    { x: 0.9, y: 0.9, width: 0.5, height: 0.5 },
    { x: 0.5, y: 0.5, width: 0, height: 0 },
    null,
    "not a rect",
  ];
  for (const value of cases) {
    const rect = clampNormalizedRect(value);
    assert.ok(rect.x >= 0 && rect.y >= 0);
    assert.ok(rect.width >= CROP_MIN_FRACTION && rect.height >= CROP_MIN_FRACTION);
    assert.ok(rect.x + rect.width <= 1 + 1e-9);
    assert.ok(rect.y + rect.height <= 1 + 1e-9);
  }
});

test("every ratio chip produces that ratio in real pixels on a 4:3 photo", () => {
  const width = 4032;
  const height = 3024;
  for (const id of CROP_ASPECT_IDS) {
    const rect = cropRectForAspect(id, width, height);
    const pixels = cropRectToPixels(rect, width, height);
    const wanted = cropAspectValue(id, width, height);
    if (wanted === null) {
      assert.equal(cropIsFullFrame(rect), true, `${id} should be the full frame`);
      continue;
    }
    const actual = pixels.width / pixels.height;
    assert.ok(
      Math.abs(actual - wanted) < 0.01,
      `${id}: wanted ${wanted}, got ${actual}`,
    );
    assert.ok(pixels.x >= 0 && pixels.y >= 0);
    assert.ok(pixels.x + pixels.width <= width);
    assert.ok(pixels.y + pixels.height <= height);
  }
  assert.equal(clampCropAspectId("banana"), "free");
});

test("a locked ratio survives a corner drag — the bug this maths exists to stop", () => {
  const frameAspect = 4032 / 3024; // 4:3 photo
  const square = cropRectForAspect("1:1", 4032, 3024);
  const dragged = applyCropGesture(square, "bottomRight", -0.2, 0.05, 1, frameAspect);
  const pixels = cropRectToPixels(dragged, 4032, 3024);
  assert.ok(
    Math.abs(pixels.width / pixels.height - 1) < 0.02,
    `square crop went rectangular: ${pixels.width}x${pixels.height}`,
  );
  assert.ok(dragged.x >= 0 && dragged.x + dragged.width <= 1 + 1e-9);
});

test("free-form drags move and resize without ever inverting the rectangle", () => {
  const start = { x: 0.2, y: 0.2, width: 0.6, height: 0.6 };
  const moved = applyCropGesture(start, "move", 0.5, -0.5, null, 1);
  assert.ok(moved.x + moved.width <= 1 + 1e-9);
  assert.ok(moved.y >= 0);
  assert.equal(Math.round(moved.width * 1000), Math.round(start.width * 1000));

  const shrunk = applyCropGesture(start, "topLeft", 5, 5, null, 1);
  assert.ok(shrunk.width >= CROP_MIN_FRACTION);
  assert.ok(shrunk.height >= CROP_MIN_FRACTION);

  const grown = applyCropGesture(start, "bottomRight", 5, 5, null, 1);
  assert.ok(grown.x + grown.width <= 1 + 1e-9);
  assert.ok(grown.y + grown.height <= 1 + 1e-9);
});

test("a full-frame crop of an odd-sized photo is still the whole photo", () => {
  const pixels = cropRectToPixels(FULL_FRAME_CROP, 4031, 3023);
  assert.deepEqual(pixels, { x: 0, y: 0, width: 4031, height: 3023 });
});

/* ────────────────────────────── enhance ───────────────────────────────── */

test("neutral enhancement is the identity matrix, exactly", () => {
  assert.equal(enhanceIsNeutral(ENHANCE_NEUTRAL), true);
  assert.equal(colorMatrixIsIdentity(enhanceColorMatrix(ENHANCE_NEUTRAL)), true);
});

test("one-tap Enhance is EXACTLY the four slider positions, not a second engine", () => {
  assert.equal(isAutoEnhance(AUTO_ENHANCE), true);
  const bySlider = PHOTO_ADJUST_KEYS.reduce(
    (accumulator, key) => ({ ...accumulator, [key]: AUTO_ENHANCE[key] }),
    ENHANCE_NEUTRAL,
  );
  assert.deepEqual(enhanceColorMatrix(bySlider), enhanceColorMatrix(AUTO_ENHANCE));
  /* And it must be modest: no channel of mid-grey may move by more than 20 %. */
  const [r, g, b] = applyColorMatrix([0.5, 0.5, 0.5], enhanceColorMatrix(AUTO_ENHANCE));
  for (const channel of [r, g, b]) {
    assert.ok(Math.abs(channel - 0.5) < 0.1, `auto enhance moved mid-grey to ${channel}`);
  }
});

test("brightness is monotonic and reaches the documented ±50 % span", () => {
  const sample: readonly [number, number, number] = [0.4, 0.4, 0.4];
  const darker = applyColorMatrix(sample, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, brightness: -50 }));
  const brighter = applyColorMatrix(sample, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, brightness: 50 }));
  assert.ok(darker[0] < sample[0]);
  assert.ok(brighter[0] > sample[0]);
  assert.ok(Math.abs(adjustBrightnessGain(100) - 1.5) < 1e-9);
  assert.ok(Math.abs(adjustBrightnessGain(-100) - 0.5) < 1e-9);
  assert.ok(Math.abs(adjustBrightnessGain(0) - 1) < 1e-9);
});

test("contrast pivots on mid-grey, so it cannot double as a brightness control", () => {
  const grey: readonly [number, number, number] = [0.5, 0.5, 0.5];
  for (const amount of [-100, -50, 25, 100]) {
    const out = applyColorMatrix(grey, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, contrast: amount }));
    assert.ok(Math.abs(out[0] - 0.5) < 1e-6, `contrast ${amount} shifted mid-grey`);
  }
});

test("saturation deepens colour without moving luminance far, and can drain it", () => {
  const colour: readonly [number, number, number] = [0.6, 0.35, 0.25];
  const drained = applyColorMatrix(colour, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, saturation: -100 }));
  const deepened = applyColorMatrix(colour, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, saturation: 100 }));
  const spread = (rgb: readonly [number, number, number]): number =>
    Math.max(...rgb) - Math.min(...rgb);
  assert.ok(spread(drained) < spread(colour));
  assert.ok(spread(deepened) > spread(colour));
  assert.ok(Math.abs(luminanceOf(drained) - luminanceOf(colour)) < 0.02);
});

test("warmth tilts red and blue in opposite directions, and cool is its mirror", () => {
  const grey: readonly [number, number, number] = [0.5, 0.5, 0.5];
  const warm = applyColorMatrix(grey, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, warmth: 100 }));
  const cool = applyColorMatrix(grey, enhanceColorMatrix({ ...ENHANCE_NEUTRAL, warmth: -100 }));
  assert.ok(warm[0] > grey[0] && warm[2] < grey[2]);
  assert.ok(cool[0] < grey[0] && cool[2] > grey[2]);
  assert.ok(Math.abs(warm[1] - grey[1]) < 1e-9, "green must not move");
  /* Cool is warm's mirror: the red lift of warm equals the blue lift of cool. */
  assert.ok(Math.abs(warm[0] - grey[0] - (cool[2] - grey[2])) < 1e-9);
});

test("adjust values are stepped, clamped and totally defined", () => {
  assert.equal(clampAdjustValue(7), 5);
  assert.equal(clampAdjustValue(-7), -5);
  assert.equal(clampAdjustValue(10_000), PHOTO_EDIT_ADJUST_MAX);
  assert.equal(clampAdjustValue(Number.NaN), 0);
  assert.equal(clampAdjustValue(undefined), 0);
  assert.equal(PHOTO_EDIT_ADJUST_MAX % PHOTO_EDIT_ADJUST_STEP, 0);
  assert.equal(adjustBadge(0), "0");
  assert.equal(adjustBadge(15), "+15");
  assert.equal(adjustBadge(-15), "\u221215");
});

/* ─────────────────── the boundary with the camera control ─────────────── */

test("post-capture brightness is a DIFFERENT system from the camera detent", () => {
  /* Same maths family, deliberately different scales and defaults: the camera
     runs −3…+3 detents, the editor −100…+100 percent. Nothing here may read
     the camera's neutral value as its own. */
  assert.equal(BRIGHTNESS_DEFAULT, 0);
  assert.equal(ENHANCE_NEUTRAL.brightness, 0);
  assert.notEqual(BRIGHTNESS_MAX, PHOTO_EDIT_ADJUST_MAX);
  /* The editor at +3 (a camera detent value) must NOT equal the camera at +3. */
  assert.notEqual(adjustBrightnessGain(BRIGHTNESS_MAX), brightnessGain(BRIGHTNESS_MAX));
  /* Both are identity at their own neutral, which is the only overlap. */
  assert.equal(adjustBrightnessGain(0), 1);
  assert.equal(brightnessGain(BRIGHTNESS_DEFAULT), 1);
});

/* ─────────────────────── geometry & draw transform ────────────────────── */

test("geometry resolves against the DECODED size and reports honest output dims", () => {
  const geometry = resolvePhotoEditGeometry(
    { rotation: 1, crop: { x: 0, y: 0, width: 0.5, height: 1 }, enhance: ENHANCE_NEUTRAL },
    4000,
    3000,
  );
  assert.equal(geometry.rotatedWidth, 3000);
  assert.equal(geometry.rotatedHeight, 4000);
  assert.equal(geometry.outputWidth, 1500);
  assert.equal(geometry.outputHeight, 4000);
  assert.equal(geometry.colorIsIdentity, true);
  assert.equal(geometry.geometryIsIdentity, false);
  assert.equal(geometry.isIdentity, false);
});

test("the draw transform maps the crop's corner onto the surface origin", () => {
  const sourceWidth = 4000;
  const sourceHeight = 3000;
  /* For each quarter turn, take the crop's top-left corner in ROTATED space,
     map it back through the published transform, and require it to land on
     (0,0) of the output surface. This is the single claim both the Skia
     renderer and the browser mirror depend on. */
  for (const rotation of [0, 1, 2, 3] as const) {
    const geometry = resolvePhotoEditGeometry(
      { rotation, crop: { x: 0.25, y: 0.25, width: 0.5, height: 0.5 }, enhance: ENHANCE_NEUTRAL },
      sourceWidth,
      sourceHeight,
    );
    const t = photoEditDrawTransform(geometry);
    const radians = (t.rotateDegrees * Math.PI) / 180;
    const cos = Math.round(Math.cos(radians));
    const sin = Math.round(Math.sin(radians));
    /* Where does the SOURCE pixel that should become output (0,0) live? Invert
       the mapping: rotate the rotated-space crop origin back into source space. */
    const rotatedOriginX = geometry.crop.x;
    const rotatedOriginY = geometry.crop.y;
    /* Forward map of a source point p: R(p) + translate. Solve R(p) = origin. */
    const targetX = rotatedOriginX - (t.translateX - (-geometry.crop.x));
    const targetY = rotatedOriginY - (t.translateY - (-geometry.crop.y));
    const sourceX = cos * targetX + sin * targetY;
    const sourceY = -sin * targetX + cos * targetY;
    const forwardX = cos * sourceX - sin * sourceY + t.translateX;
    const forwardY = sin * sourceX + cos * sourceY + t.translateY;
    assert.ok(Math.abs(forwardX) < 1e-6, `rotation ${rotation}: x landed at ${forwardX}`);
    assert.ok(Math.abs(forwardY) < 1e-6, `rotation ${rotation}: y landed at ${forwardY}`);
  }
});

test("the whole source is inside the surface when nothing is cropped", () => {
  for (const rotation of [0, 1, 2, 3] as const) {
    const geometry = resolvePhotoEditGeometry(
      { rotation, crop: FULL_FRAME_CROP, enhance: ENHANCE_NEUTRAL },
      4000,
      3000,
    );
    const t = photoEditDrawTransform(geometry);
    const radians = (t.rotateDegrees * Math.PI) / 180;
    const cos = Math.round(Math.cos(radians));
    const sin = Math.round(Math.sin(radians));
    const corners: readonly (readonly [number, number])[] = [
      [0, 0],
      [4000, 0],
      [0, 3000],
      [4000, 3000],
    ];
    const mapped = corners.map(([x, y]) => [
      cos * x - sin * y + t.translateX,
      sin * x + cos * y + t.translateY,
    ]);
    const xs = mapped.map((point) => point[0] ?? 0);
    const ys = mapped.map((point) => point[1] ?? 0);
    assert.ok(Math.abs(Math.min(...xs)) < 1e-6, `rotation ${rotation}: left edge off-surface`);
    assert.ok(Math.abs(Math.min(...ys)) < 1e-6, `rotation ${rotation}: top edge off-surface`);
    assert.ok(Math.abs(Math.max(...xs) - geometry.outputWidth) < 1e-6);
    assert.ok(Math.abs(Math.max(...ys) - geometry.outputHeight) < 1e-6);
  }
});

/* ──────────────────────── files & descriptions ────────────────────────── */

test("edit temp files are recognisable, unique and never collide with captures", () => {
  const name = editedFileName({ ...PHOTO_EDIT_NONE, rotation: 1 }, 1_700_000_000_000);
  assert.equal(isEditTempFileName(name), true);
  assert.equal(name.endsWith(".jpg"), true);
  assert.equal(isEditTempFileName("poseassist-shot-plain-p0-4x3-123.jpg"), false);
  assert.equal(isEditTempFileName(undefined), false);
  const other = editedFileName({ ...PHOTO_EDIT_NONE, rotation: 2 }, 1_700_000_000_000);
  assert.notEqual(name, other);
});

test("the edit summary says what actually changed, in order", () => {
  assert.equal(
    describePhotoEdit({
      rotation: 1,
      crop: { x: 0.1, y: 0.1, width: 0.5, height: 0.5 },
      enhance: AUTO_ENHANCE,
    }),
    "Crop \u00B7 90\u00B0 \u00B7 Enhanced",
  );
  assert.equal(
    describePhotoEdit({ ...PHOTO_EDIT_NONE, enhance: { ...ENHANCE_NEUTRAL, contrast: 25 } }),
    "Adjusted",
  );
});

test("the encoding policy is a deliberate value, not a default", () => {
  /* Higher than the capture pipeline's 92 because an edit is a SECOND JPEG
     generation; see the rationale in shared/camera/photoEditing.ts. */
  assert.equal(PHOTO_EDIT_JPEG_QUALITY, 95);
});
