/**
 * tests/camera/poseFramePolicy.test.ts — BOUNDED SCHEDULING CONTRACT.
 *
 * Unit tests for shared/ml/poseFramePolicy — the pure decision machine that
 * keeps the native live-pose pipeline bounded. No device, no camera, no
 * native code, no real clock: every admission decision is scripted with
 * explicit (frameTimestampMs, arrivalMs, epoch) triples.
 *
 * The guarantees pinned here (A1 §4 / poseFramePolicy header):
 *   1. NO UNBOUNDED QUEUE — at most ONE in-flight consumption; everything
 *      arriving while busy is dropped immediately and COUNTED (droppedBusy).
 *   2. LATEST FRAME WINS — by dropping-not-queueing, the first arrival after
 *      done() is always the freshest the native side produced.
 *   3. 15 fps BUDGET — accepted results are spaced ≥ POSE_RESULT_MIN_INTERVAL_MS.
 *   4. STALENESS — a result older than POSE_RESULT_MAX_STALENESS_MS on
 *      arrival is discarded, and the stale check runs BEFORE the busy and
 *      budget checks (a stale frame never even counts as "busy-drop").
 *   5. EPOCH — arrivals from before invalidateEpoch() are rejected
 *      ('epoch'), so rear-camera landmarks can never be judged against the
 *      front camera's mirrored coordinates, and vice versa.
 *   6. TEARDOWN — stop() rejects everything; start() resumes; done() is
 *      idempotent and safe under async-race teardown.
 *   7. METRICS TOTALITY — every received result is accounted EXACTLY once:
 *      received === accepted + busy + stale + epoch + stopped.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  PoseFrameScheduler,
  POSE_RESULT_MAX_STALENESS_MS,
  POSE_RESULT_MIN_INTERVAL_MS,
} from "../../shared/ml/poseFramePolicy";

const MIN = POSE_RESULT_MIN_INTERVAL_MS;
const STALE = POSE_RESULT_MAX_STALENESS_MS;

function totalDrops(metrics: {
  droppedBusy: number;
  droppedStale: number;
  droppedEpoch: number;
  droppedStopped: number;
}): number {
  return (
    metrics.droppedBusy + metrics.droppedStale + metrics.droppedEpoch + metrics.droppedStopped
  );
}

/* ── lifecycle ─────────────────────────────────────────────────────────── */

test("a fresh scheduler rejects everything as 'stopped' and counts it", () => {
  const s = new PoseFrameScheduler();
  const admission = s.admit(0, 10, 0);
  assert.equal(admission.admitted, false);
  assert.equal(admission.dropReason, "stopped");
  const m = s.getMetrics();
  assert.equal(m.resultsReceived, 1);
  assert.equal(m.droppedStopped, 1);
});

test("start() admits good results with the current epoch; stop() parks again", () => {
  const s = new PoseFrameScheduler();
  s.start();
  const ok = s.admit(1_000, 1_010, s.currentEpoch);
  assert.equal(ok.admitted, true);
  assert.equal(ok.dropReason, null);
  s.done();
  s.stop();
  const after = s.admit(2_000, 2_010, s.currentEpoch);
  assert.equal(after.admitted, false);
  assert.equal(after.dropReason, "stopped");
});

/* ── single flight & latest-wins ───────────────────────────────────────── */

test("single-flight: arrivals while the consumer is busy are dropped, not queued", () => {
  const s = new PoseFrameScheduler();
  s.start();
  assert.equal(s.admit(1_000, 1_000, 0).admitted, true); // in-flight now
  assert.deepEqual(s.admit(1_010, 1_010, 0), { admitted: false, dropReason: "busy" });
  assert.deepEqual(s.admit(1_020, 1_020, 0), { admitted: false, dropReason: "busy" });
  const m = s.getMetrics();
  assert.equal(m.resultsAccepted, 1);
  assert.equal(m.droppedBusy, 2);
});

test("latest-wins by construction: the first arrival AFTER done() is the freshest, and it wins", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(1_000, 1_000, 0);
  s.admit(1_016, 1_016, 0); // dropped busy
  s.admit(1_032, 1_032, 0); // dropped busy — the newest while busy never queues
  s.done();
  const next = s.admit(1_100, 1_100, 0); // ≥66ms after last accepted arrival
  assert.equal(next.admitted, true);
});

test("no unbounded queue: N arrivals while busy produce exactly N drops and zero growth", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(0, 5, 0);
  for (let i = 1; i <= 500; i += 1) {
    s.admit(i, 5 + i, 0);
  }
  const m = s.getMetrics();
  assert.equal(m.resultsAccepted, 1);
  assert.equal(m.droppedBusy, 500);
  assert.equal(m.resultsReceived, 501);
});

/* ── 15 fps budget ─────────────────────────────────────────────────────── */

test("budget throttle: accepted results are spaced ≥ 66 ms", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(1_000, 1_000, 0);
  s.done();
  assert.equal(s.admit(1_050, 1_000 + MIN - 1, 0).admitted, false); // 65 ms: too soon
  assert.equal(s.admit(1_055, 1_000 + MIN, 0).admitted, true); // exactly 66 ms: admitted
});

test("the very first admission is never throttled (no previous acceptance)", () => {
  const s = new PoseFrameScheduler();
  s.start();
  assert.equal(s.admit(0, 1, 0).admitted, true);
});

test("a throttle-drop counts as busy, not as its own bucket", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(1_000, 1_000, 0);
  s.done();
  s.admit(1_020, 1_030, 0); // 30 ms after the last acceptance → throttled
  const m = s.getMetrics();
  assert.equal(m.droppedBusy, 1);
});

/* ── staleness ─────────────────────────────────────────────────────────── */

test("stale results are discarded: older than 350 ms on arrival never reaches the consumer", () => {
  const s = new PoseFrameScheduler();
  s.start();
  const stale = s.admit(1_000, 1_000 + STALE + 1, 0);
  assert.deepEqual(stale, { admitted: false, dropReason: "stale" });
  const freshAtBoundary = s.admit(2_000, 2_000 + STALE, 0);
  assert.equal(freshAtBoundary.admitted, true, "exactly at the bound is still usable");
});

test("staleness is checked BEFORE busy: a stale frame while busy counts as stale-drop", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(10_000, 10_000, 0); // in-flight
  const m0 = s.getMetrics();
  assert.equal(m0.droppedStale, 0);
  s.admit(100, 20_000, 0); // ancient frame arriving while busy
  const m = s.getMetrics();
  assert.equal(m.droppedStale, 1);
  assert.equal(m.droppedBusy, 0, "must not double-classify as busy");
});

/* ── epochs ────────────────────────────────────────────────────────────── */

test("arrivals stamped with an old epoch are rejected ('epoch')", () => {
  const s = new PoseFrameScheduler();
  s.start();
  const epoch = s.currentEpoch;
  s.invalidateEpoch();
  const old = s.admit(1_000, 1_010, epoch);
  assert.deepEqual(old, { admitted: false, dropReason: "epoch" });
  const m = s.getMetrics();
  assert.equal(m.droppedEpoch, 1);
});

test("facing-switch invalidation: invalidateEpoch bumps the epoch and frees the in-flight slot", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(1_000, 1_000, 0); // in-flight from the OLD camera
  const newEpoch = s.invalidateEpoch();
  assert.equal(newEpoch, 1);
  assert.equal(s.currentEpoch, 1);
  /* A fresh result from the NEW camera (new epoch) is admitted immediately —
     the old in-flight slot must not deadlock the new session. The interval
     budget is respected by the runtime's own delivery cadence. */
  const fresh = s.admit(1_500, 1_500 + MIN + 10, newEpoch);
  assert.equal(fresh.admitted, true);
  /* The OLD consumption's eventual done() is a harmless no-op. */
  s.done();
});

test("epoch check precedes staleness: old-epoch garbage never pollutes stale accounting", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.invalidateEpoch();
  s.admit(0, 100_000, 0);
  const m = s.getMetrics();
  assert.equal(m.droppedEpoch, 1);
  assert.equal(m.droppedStale, 0);
});

/* ── teardown & idempotence ────────────────────────────────────────────── */

test("done() without an admitted result is a no-op", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.done();
  s.done();
  assert.equal(s.admit(0, 10, 0).admitted, true);
});

test("start() is idempotent and clears any stale busy flag", () => {
  const s = new PoseFrameScheduler();
  s.start();
  s.admit(0, 10, 0); // in-flight, never done()
  s.start(); // session restart
  assert.equal(s.admit(100, 100 + MIN + 10, 0).admitted, true);
});

/* ── metrics totality ──────────────────────────────────────────────────── */

test("every received result is accounted exactly once across all buckets", () => {
  const s = new PoseFrameScheduler();
  // stopped
  s.admit(0, 10, 0); // +1 stopped
  s.start();
  // accepted ×2
  s.admit(1_000, 1_000, 0);
  s.done();
  s.admit(1_100, 1_100, 0);
  // busy while in-flight
  s.admit(1_110, 1_110, 0);
  s.done();
  // throttled (busy bucket)
  s.admit(1_200, 1_120, 0);
  // stale
  s.admit(1_000, 5_000, 0);
  // epoch
  s.invalidateEpoch();
  s.admit(5_000, 5_010, 0);
  const m = s.getMetrics();
  assert.equal(m.resultsReceived, 7);
  assert.equal(m.resultsAccepted, 2);
  assert.equal(totalDrops(m), 5);
  assert.equal(m.resultsReceived, m.resultsAccepted + totalDrops(m));
});
