/**
 * tests/camera/poseFrameTransform.test.ts — NATIVE-POSE COORDINATE CONTRACT.
 *
 * Unit tests for shared/ml/poseFrameTransform — the deterministic adapter
 * between the native ML Kit plugin (vision-camera-mlkit-pose) and the
 * existing PoseLandmark[] contract the pose engine, coaching and overlays
 * were built against (Unit 16). Pure module: no device, no camera, no
 * native code, no clock.
 *
 * What is pinned here (A1 §5 / the plugin's OUTPUT CONTRACT):
 *   1. NORMALIZATION — upright pixels → 0..1 by the UPRIGHT dims.
 *   2. CLAMP — coordinates outside 0..1 (edge landmarks past the buffer)
 *      and non-finite values are clamped AFTER mirroring.
 *   3. MIRROR × FRONT — mirrored frames flip x AFTER normalizing, never
 *      before, so the overlay agrees with the mirrored preview the user sees.
 *   4. LEFT/RIGHT SEMANTICS — ML Kit labels are person-relative: mirroring
 *      moves COORDINATES, never JOINT IDENTITY. Array order is the BlazePose
 *      index order on both sides; the adapter never renames a joint.
 *   5. VISIBILITY MAPPING — in-frame likelihood → visibility, clamped 0..1;
 *      z passes through unscaled (negative = closer); non-finite z → 0.
 *   6. FRAME REJECTION — bad dims / short arrays / holes → null (unusable);
 *      an EMPTY landmark list is a VALID "no person" frame → [].
 *   7. EXTRAS — orientation degrees metadata + portrait sanity helper.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  adaptNativePoseFrame,
  isPortraitFrame,
  nativeOrientationDegrees,
  transformNativePoint,
  type NativePoseFrame,
  type NativePosePoint,
} from "../../shared/ml/poseFrameTransform";
import {
  POSE_LANDMARK_COUNT,
  POSE_LANDMARKS,
} from "../../shared/ml/poseLandmarks";

/* ── fixtures ──────────────────────────────────────────────────────────── */

function point(x: number, y: number, z = 0, visibility = 1): NativePosePoint {
  return { x, y, z, visibility };
}

/** 33 distinct points: (i, i*10, i*-0.01, 0.9) so index identity is checkable. */
function fullLandmarks(): NativePosePoint[] {
  const out: NativePosePoint[] = [];
  for (let i = 0; i < POSE_LANDMARK_COUNT; i += 1) {
    out.push(point(i, i * 10, i * -0.01, 0.9));
  }
  return out;
}

function frame(overrides: Partial<NativePoseFrame>): NativePoseFrame {
  return {
    width: 480,
    height: 640,
    timestampMs: 1_000,
    orientation: "left",
    mirrored: false,
    landmarks: fullLandmarks(),
    ...overrides,
  };
}

/* ── 1. normalization ──────────────────────────────────────────────────── */

test("normalizes upright pixels by the upright dims; z passthrough; visibility kept", () => {
  const lm = transformNativePoint(point(240, 320, -0.42, 0.75), 480, 640, false);
  assert.equal(lm.x, 0.5);
  assert.equal(lm.y, 0.5);
  assert.equal(lm.z, -0.42);
  assert.equal(lm.visibility, 0.75);
});

test("normalization denominator is the FRAME dims, swapped dims land differently", () => {
  const p = point(120, 160);
  const a = transformNativePoint(p, 480, 640, false);
  const b = transformNativePoint(p, 640, 480, false);
  assert.equal(a.x, 0.25);
  assert.equal(a.y, 0.25);
  assert.equal(b.x, 0.1875);
  assert.ok(Math.abs((b.y ?? 0) - 1 / 3) < 1e-9);
});

/* ── 2. clamping ───────────────────────────────────────────────────────── */

test("out-of-range coordinates clamp to 0..1 AFTER normalization", () => {
  const lm = transformNativePoint(point(-20, 700), 480, 640, false);
  assert.equal(lm.x, 0);
  assert.equal(lm.y, 1);
});

test("non-finite coordinates and visibility clamp safely; non-finite z → 0", () => {
  const lm = transformNativePoint(
    point(Number.NaN, Number.POSITIVE_INFINITY, Number.NaN, Number.NaN),
    480,
    640,
    false,
  );
  assert.equal(lm.x, 0);
  assert.equal(lm.y, 0);
  assert.equal(lm.z, 0);
  assert.equal(lm.visibility, 0);
});

test("visibility above 1 clamps down, negative clamps to 0", () => {
  assert.equal(transformNativePoint(point(0, 0, 0, 1.4), 480, 640, false).visibility, 1);
  assert.equal(transformNativePoint(point(0, 0, 0, -0.5), 480, 640, false).visibility, 0);
});

/* ── 3. mirroring ──────────────────────────────────────────────────────── */

test("mirrored frames flip x AFTER normalizing (x' = 1 − x)", () => {
  const p = point(96, 320);
  const unm = transformNativePoint(p, 480, 640, false);
  const mir = transformNativePoint(p, 480, 640, true);
  assert.equal(unm.x, 0.2);
  assert.equal(mir.x, 0.8);
  assert.equal(mir.y, unm.y);
  assert.equal(mir.z, unm.z);
});

test("mirroring happens BEFORE clamping is no longer observable: clamp is last", () => {
  /* x slightly negative in a mirrored frame: 1 − (−20/480) > 1 → clamps to 1. */
  const lm = transformNativePoint(point(-20, 100), 480, 640, true);
  assert.equal(lm.x, 1);
});

/* ── 4. L/R semantics: mirrors move coordinates, never joint identity ──── */

test("user raises left hand in a mirrored front frame: leftWrist stays index 15, x flips to its screen side", () => {
  const landmarks = fullLandmarks();
  /* Anatomical-left wrist on the person's left side of the unmirrored buffer. */
  landmarks[POSE_LANDMARKS.leftWrist] = point(96, 160, -0.1, 0.95);
  const adapted = adaptNativePoseFrame(frame({ mirrored: true, landmarks }));
  assert.ok(adapted !== null && adapted.length === POSE_LANDMARK_COUNT);
  const leftWrist = adapted[POSE_LANDMARKS.leftWrist];
  assert.ok(leftWrist !== undefined);
  assert.equal(leftWrist.x, 0.8, "mirrored to the side the user SEES their left hand on");
  assert.equal(leftWrist.y, 0.25);
  /* The SAME slot on the rear (unmirrored) camera keeps x untouched. */
  const adaptedRear = adaptNativePoseFrame(frame({ mirrored: false, landmarks }));
  assert.ok(adaptedRear !== null);
  assert.equal(adaptedRear[POSE_LANDMARKS.leftWrist]?.x, 0.2);
});

test("index order is preserved exactly — point i in is landmark i out", () => {
  const adapted = adaptNativePoseFrame(frame({}));
  assert.ok(adapted !== null);
  for (let i = 0; i < POSE_LANDMARK_COUNT; i += 1) {
    assert.equal(adapted[i]?.x, i / 480, `index ${i} x`);
    assert.equal(adapted[i]?.y, (i * 10) / 640, `index ${i} y`);
    assert.equal(adapted[i]?.z, i * -0.01, `index ${i} z`);
  }
});

/* ── 5. frame-level adaptation ─────────────────────────────────────────── */

test("bad dims → null (unusable frame), never a half-scaled pose", () => {
  assert.equal(adaptNativePoseFrame(frame({ width: 0 })), null);
  assert.equal(adaptNativePoseFrame(frame({ height: -1 })), null);
});

test("empty landmarks → [] — a VALID no-person frame (engine must still see body-lost)", () => {
  const adapted = adaptNativePoseFrame(frame({ landmarks: [] }));
  assert.ok(adapted !== null);
  assert.equal(adapted.length, 0);
});

test("short landmark array → null (garbage), never silently padded", () => {
  assert.equal(
    adaptNativePoseFrame(frame({ landmarks: fullLandmarks().slice(0, 12) })),
    null,
  );
  assert.equal(adaptNativePoseFrame(frame({ landmarks: fullLandmarks().slice(0, 32) })), null);
});

test("arrays longer than 33 use the first 33 and ignore extras", () => {
  const landmarks = fullLandmarks();
  landmarks.push(point(1, 1, 99, 1));
  landmarks.push(point(2, 2, 99, 1));
  const adapted = adaptNativePoseFrame(frame({ landmarks }));
  assert.ok(adapted !== null);
  assert.equal(adapted.length, POSE_LANDMARK_COUNT);
  assert.equal(adapted[POSE_LANDMARK_COUNT - 1]?.z, (POSE_LANDMARK_COUNT - 1) * -0.01);
});

test("sparse/holey garbage payload (length 33, one undefined entry) → null", () => {
  const landmarks = fullLandmarks();
  (landmarks as unknown[])[5] = undefined;
  const adapted = adaptNativePoseFrame(frame({ landmarks }));
  assert.equal(adapted, null);
});

/* ── 6. orientation & dims metadata ────────────────────────────────────── */

test("nativeOrientationDegrees maps the four camera orientations to ML Kit rotation", () => {
  assert.equal(nativeOrientationDegrees("up"), 0);
  assert.equal(nativeOrientationDegrees("right"), 90);
  assert.equal(nativeOrientationDegrees("down"), 180);
  assert.equal(nativeOrientationDegrees("left"), 270);
});

test("isPortraitFrame is the single dims-sanity helper (taller-or-equal = portrait)", () => {
  assert.equal(isPortraitFrame({ width: 480, height: 640 }), true);
  assert.equal(isPortraitFrame({ width: 640, height: 480 }), false);
  assert.equal(isPortraitFrame({ width: 480, height: 480 }), true);
});

test("upright-swap parity: a 90° portrait frame's landmarks normalize by swapped dims", () => {
  /* Native pre-swaps dims for 90/270 (Kotlin/Swift OUTPUT CONTRACT) — the
     adapter therefore NEVER swaps: 480×640 "upright" dims in → those exact
     denominators used, whatever the orientation field says. */
  const adapted = adaptNativePoseFrame(
    frame({ orientation: "left", width: 480, height: 640, landmarks: [point(240, 320), ...fullLandmarks().slice(1)] }),
  );
  assert.ok(adapted !== null);
  assert.equal(adapted[0]?.x, 0.5);
  assert.equal(adapted[0]?.y, 0.5);
});
