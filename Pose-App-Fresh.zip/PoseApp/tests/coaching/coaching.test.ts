/**
 * tests/coaching/coaching.test.ts — Unit 30: the semantic coaching boundary.
 *
 *   POSE ANALYSIS → SEMANTIC COACHING STATE → LANGUAGE → PHRASE → (TTS)
 *
 * Every test below asserts a boundary property, not an implementation detail:
 *   · analysis state        → correct coaching category
 *   · category + severity   → correct phrase pool (gentle vs firmer)
 *   · category + language   → correct language bank
 *   · repeated instruction  → no immediate identical phrase
 *   · perfect state         → controlled, transition-aware speech
 *   · unavailable reference → no fabricated correction
 *   · state change          → a new valid instruction may be spoken promptly
 *
 * Deterministic: fixed fixtures, injected random source, injected clock.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  CORRECTION_PERSISTENCE_FRAMES,
  PERFECT_PERSISTENCE_FRAMES,
  createPoseAnalysisEngine,
  type PoseAnalysisDecision,
} from "../../shared/ml/analysis";
import {
  CATEGORY_COVERAGE,
  REACHABLE_CATEGORIES,
  coachingCategoryFor,
  createCoachingSpeechPlanner,
  decisionToCoachingState,
  intensityForSeverity,
  selectCoachingPhrase,
  type CoachingState,
} from "../../shared/coaching";
import {
  instructionPool,
  resetInstructionMemory,
  VOICE_INSTRUCTION_CATEGORIES,
} from "../../shared/constants/poseInstructions";
import type { PoseLandmark } from "../../shared/ml/poseLandmarks";
import { bodyLandmarks, referenceInput, referenceWithOffsets } from "../analysis/fixtures";

function engineFor(
  values: Readonly<Record<string, number>> | null,
  options?: Parameters<typeof referenceInput>[1],
) {
  return createPoseAnalysisEngine({
    reference: values === null ? null : referenceInput(values, options),
    sessionId: "coaching-test",
  });
}

function settle(
  engine: ReturnType<typeof createPoseAnalysisEngine>,
  landmarks: readonly PoseLandmark[],
  frames: number,
): PoseAnalysisDecision {
  let decision = engine.analyzeFrame(landmarks);
  for (let index = 1; index < frames; index += 1) {
    decision = engine.analyzeFrame(landmarks);
  }
  return decision;
}

/** A fixed random source so phrase selection is reproducible. */
function fixedRandom(value: number): () => number {
  return () => value;
}

/* ----------------- analysis state → coaching category ------------------- */

test("a stable correction becomes a semantic coaching state with a category", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const state = decisionToCoachingState(
    settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES),
  );
  assert.equal(state.kind, "correction");
  assert.equal(state.measurementId, "leftElbow");
  assert.equal(state.direction, "decrease", "live > reference ⇒ close the joint");
  /* Unit 33: the elbow now speaks through the direction-correct arm pool
     instead of the lateral "slide the hand left" copy. */
  assert.equal(state.category, "hand_left_bend");
  assert.equal(state.severity, "major");
  assert.equal(state.intensity, "firm");
  assert.equal(state.speakable, true);
  assert.ok(state.stableFrames >= 1);
});

test("the mirrored error maps to the mirrored category, not a duplicated rule", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: -40 }));
  const state = decisionToCoachingState(
    settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES),
  );
  assert.equal(state.direction, "increase");
  /* Unit 33: same joint, opposite direction ⇒ the straighten pool for the
     SAME arm (the old mapping jumped to the other side's lateral copy). */
  assert.equal(state.category, "hand_left_straighten");
});

test("category mapping refuses to invent a category", () => {
  assert.equal(coachingCategoryFor("leftElbow", "none"), null);
  assert.equal(coachingCategoryFor("thirdElbow", "increase"), null);
});

/* ------------------------- severity → intensity ------------------------- */

test("severity reaches phrase selection and picks the right pool", () => {
  assert.equal(intensityForSeverity("minor"), "gentle");
  assert.equal(intensityForSeverity("major"), "firm");
  assert.equal(intensityForSeverity("within-tolerance"), "gentle");

  const gentlePool = instructionPool("hand_left_bend", "en", "gentle");
  const firmPool = instructionPool("hand_left_bend", "en", "firm");
  assert.ok(gentlePool.length > 1 && firmPool.length > 1);
  for (const phrase of firmPool) {
    assert.equal(gentlePool.includes(phrase), false, "firm copy must be distinct");
  }

  resetInstructionMemory();
  const minor = decisionToCoachingState(
    settle(
      engineFor(referenceWithOffsets(bodyLandmarks(), { leftElbow: 15 })),
      bodyLandmarks(),
      CORRECTION_PERSISTENCE_FRAMES,
    ),
  );
  assert.equal(minor.severity, "minor");
  const phrase = selectCoachingPhrase(minor, "en", { random: fixedRandom(0) });
  assert.ok(phrase !== null);
  assert.equal(phrase.intensity, "gentle");
  assert.ok(gentlePool.includes(phrase.text));

  const major = decisionToCoachingState(
    settle(
      engineFor(referenceWithOffsets(bodyLandmarks(), { leftElbow: 45 })),
      bodyLandmarks(),
      CORRECTION_PERSISTENCE_FRAMES,
    ),
  );
  assert.equal(major.severity, "major");
  const firmPhrase = selectCoachingPhrase(major, "en", { random: fixedRandom(0) });
  assert.ok(firmPhrase !== null);
  assert.equal(firmPhrase.intensity, "firm");
  assert.ok(firmPool.includes(firmPhrase.text));
});

/* --------------------------- language routing --------------------------- */

test("the same semantic state maps to the requested language bank", () => {
  resetInstructionMemory();
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const state = decisionToCoachingState(
    settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES),
  );
  const english = selectCoachingPhrase(state, "en", { random: fixedRandom(0.1) });
  const hindi = selectCoachingPhrase(state, "hi", { random: fixedRandom(0.1) });
  assert.ok(english !== null && hindi !== null);
  assert.equal(english.category, hindi.category, "one semantic state, two banks");
  assert.equal(english.language, "en");
  assert.equal(hindi.language, "hi");
  assert.ok(instructionPool(state.category ?? "hand_left_bend", "en", state.intensity).includes(english.text));
  assert.ok(instructionPool(state.category ?? "hand_left_bend", "hi", state.intensity).includes(hindi.text));
  assert.notEqual(english.text, hindi.text);
});

test("natural Hinglish fillers are preserved in the Hindi bank", () => {
  const joined = [
    ...instructionPool("hand_up", "hi", "gentle"),
    ...instructionPool("hand_down", "hi", "gentle"),
  ].join(" ");
  for (const filler of ["बस", "हाँ", "hmm", "ठीक"]) {
    assert.ok(joined.includes(filler), `missing natural filler: ${filler}`);
  }
});

/* ----------------------------- no repetition ---------------------------- */

test("a repeated instruction never returns the same phrase twice in a row", () => {
  resetInstructionMemory();
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const state = decisionToCoachingState(
    settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES),
  );
  let previous: string | null = null;
  for (let index = 0; index < 40; index += 1) {
    /* A degenerate random source that always asks for the same slot is the
       worst case for a no-repeat guarantee. */
    const phrase = selectCoachingPhrase(state, "en", { random: fixedRandom(0.34) });
    assert.ok(phrase !== null);
    assert.notEqual(phrase.text, previous, "immediate repetition");
    previous = phrase.text;
  }
});

/* --------------------------- cadence behaviour -------------------------- */

function correctionState(token: string, overrides?: Partial<CoachingState>): CoachingState {
  return {
    kind: "correction",
    token,
    category: "hand_left",
    measurementId: "leftElbow",
    direction: "decrease",
    severity: "major",
    intensity: "firm",
    confidence: 0.9,
    stableFrames: 3,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
    ...overrides,
  };
}

test("the planner speaks a new state promptly and does not spam it", () => {
  const planner = createCoachingSpeechPlanner();
  const state = correctionState("LEFT_ELBOW_DECREASE");
  assert.equal(planner.plan({ state, nowMs: 0, isSpeaking: false }).speak, true);
  for (let now = 100; now < 4500; now += 100) {
    assert.equal(
      planner.plan({ state, nowMs: now, isSpeaking: false }).speak,
      false,
      `spoke again too early at ${now}ms`,
    );
  }
  const repeat = planner.plan({ state, nowMs: 4600, isSpeaking: false });
  assert.equal(repeat.speak, true);
  assert.equal(repeat.reason, "repeat-interval");
});

test("a state change can be spoken without waiting out the repeat interval", () => {
  const planner = createCoachingSpeechPlanner();
  assert.equal(
    planner.plan({ state: correctionState("LEFT_ELBOW_DECREASE"), nowMs: 0, isSpeaking: false })
      .speak,
    true,
  );
  const changed = planner.plan({
    state: correctionState("RIGHT_KNEE_INCREASE", { category: "leg_right" }),
    nowMs: 1000,
    isSpeaking: false,
  });
  assert.equal(changed.speak, true);
  assert.equal(changed.reason, "state-changed");
  assert.equal(changed.isTransition, true);
});

test("an unstable state is not spoken", () => {
  const planner = createCoachingSpeechPlanner();
  const plan = planner.plan({
    state: correctionState("LEFT_ELBOW_DECREASE", { stableFrames: 0 }),
    nowMs: 0,
    isSpeaking: false,
  });
  assert.equal(plan.speak, false);
  assert.equal(plan.reason, "unstable");
});

test("perfect is transition-aware: one positive line per episode", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, {}));
  const planner = createCoachingSpeechPlanner();
  const perfect = decisionToCoachingState(
    settle(engine, landmarks, PERFECT_PERSISTENCE_FRAMES),
  );
  assert.equal(perfect.kind, "perfect");
  assert.equal(perfect.category, "final_pose_good");

  let spoken = 0;
  for (let frame = 0; frame < 200; frame += 1) {
    const state = decisionToCoachingState(engine.analyzeFrame(landmarks));
    if (planner.plan({ state, nowMs: frame * 66, isSpeaking: false }).speak) spoken += 1;
  }
  assert.equal(spoken, 1, "perfect must not be announced on every frame");
});

test("leaving and re-entering perfect starts a new episode", () => {
  const planner = createCoachingSpeechPlanner();
  const perfect: CoachingState = {
    kind: "perfect",
    token: "PERFECT",
    category: "final_pose_good",
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0.9,
    stableFrames: 4,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
  };
  assert.equal(planner.plan({ state: perfect, nowMs: 0, isSpeaking: false }).speak, true);
  assert.equal(planner.plan({ state: perfect, nowMs: 5000, isSpeaking: false }).speak, false);
  planner.plan({
    state: correctionState("LEFT_ELBOW_DECREASE"),
    nowMs: 6000,
    isSpeaking: false,
  });
  assert.equal(planner.plan({ state: perfect, nowMs: 9000, isSpeaking: false }).speak, true);
});

/* ------------------------ unavailable is honest ------------------------- */

test("an unusable reference can never become a correction", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(null);
  const planner = createCoachingSpeechPlanner();
  for (let frame = 0; frame < 10; frame += 1) {
    const state = decisionToCoachingState(engine.analyzeFrame(landmarks));
    assert.equal(state.kind, "unavailable");
    assert.equal(state.category, null);
    assert.equal(state.speakable, false);
    assert.equal(state.unavailableReason, "reference-unavailable");
    assert.equal(selectCoachingPhrase(state, "en"), null);
    assert.equal(selectCoachingPhrase(state, "hi"), null);
    const plan = planner.plan({ state, nowMs: frame * 66, isSpeaking: false });
    assert.equal(plan.speak, false);
    assert.equal(plan.reason, "not-speakable");
  }
});

test("a lost body is silent, and recovery can speak immediately", () => {
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftElbow: 40 }));
  const planner = createCoachingSpeechPlanner();

  const first = decisionToCoachingState(
    settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES),
  );
  assert.equal(planner.plan({ state: first, nowMs: 0, isSpeaking: false }).speak, true);

  const lost = decisionToCoachingState(engine.analyzeFrame([]));
  assert.equal(lost.kind, "unavailable");
  assert.equal(lost.unavailableReason, "no-live-pose");
  assert.equal(planner.plan({ state: lost, nowMs: 200, isSpeaking: false }).speak, false);

  const recovered = decisionToCoachingState(
    settle(engine, landmarks, CORRECTION_PERSISTENCE_FRAMES),
  );
  const plan = planner.plan({ state: recovered, nowMs: 1300, isSpeaking: false });
  assert.equal(plan.speak, true, "recovery must not wait out a stale interval");
});

/* --------------------------- category coverage -------------------------- */

test("every reachable category is traced, and reserved copy is not claimed", () => {
  assert.equal(CATEGORY_COVERAGE.length, VOICE_INSTRUCTION_CATEGORIES.length);
  const byCategory = new Map(CATEGORY_COVERAGE.map((entry) => [entry.category, entry]));

  for (const category of [
    "hand_up",
    "hand_down",
    "hand_left_straighten",
    "hand_left_bend",
    "hand_right_straighten",
    "hand_right_bend",
    "leg_left_straighten",
    "leg_left_bend",
    "leg_right_straighten",
    "leg_right_bend",
    "leg_left_forward",
    "leg_left_back",
    "leg_right_forward",
    "leg_right_back",
  ] as const) {
    const entry = byCategory.get(category);
    assert.ok(entry !== undefined);
    assert.equal(entry.reachability, "reachable-correction");
    assert.ok(entry.producers.length > 0);
  }

  assert.equal(byCategory.get("final_pose_good")?.reachability, "reachable-perfect");
  assert.equal(byCategory.get("photo_clicking")?.reachability, "reachable-capture");

  for (const category of [
    "look_straight",
    "look_left",
    "look_right",
    "chin_up",
    "chin_down",
    "shoulder_straight",
    "back_straight",
  ] as const) {
    assert.equal(
      byCategory.get(category)?.reachability,
      "reserved-no-measurement",
      `${category} must not be claimed as functional coaching`,
    );
  }

  /* Unit 32/33: retained copy that no rule points at any more — the
     direction-ambiguous knee pools, the lateral hand pools the elbow rules
     used to borrow, and the stance-width pools the hip rules used to borrow.
     None of it may be claimed as functional coaching. */
  for (const category of [
    "leg_left",
    "leg_right",
    "hand_left",
    "hand_right",
    "leg_open",
    "leg_close",
  ] as const) {
    const entry = byCategory.get(category);
    assert.equal(entry?.reachability, "reserved-superseded");
    assert.deepEqual(entry?.producers, []);
  }

  assert.equal(REACHABLE_CATEGORIES.length, 16);
  /* Reserved categories still have speakable copy in both banks so the day a
     measurement lands, nothing is missing. */
  for (const entry of CATEGORY_COVERAGE) {
    assert.ok(instructionPool(entry.category, "en").length > 0);
    assert.ok(instructionPool(entry.category, "hi").length > 0);
  }
});

/* ------------------------- end-to-end pipeline -------------------------- */

test("pipeline: analysis → state → language → severity → phrase, no geometry leaks", () => {
  resetInstructionMemory();
  const landmarks = bodyLandmarks();
  const engine = engineFor(referenceWithOffsets(landmarks, { leftKnee: 45 }));
  const planner = createCoachingSpeechPlanner();
  const spoken: string[] = [];

  for (let frame = 0; frame < 8; frame += 1) {
    const state = decisionToCoachingState(engine.analyzeFrame(landmarks));
    const plan = planner.plan({ state, nowMs: frame * 200, isSpeaking: false });
    if (!plan.speak) continue;
    const phrase = selectCoachingPhrase(state, "hi", { random: fixedRandom(0.5) });
    assert.ok(phrase !== null);
    /* The speech layer received a category and an intensity — never an angle. */
    assert.ok(instructionPool(phrase.category, "hi", phrase.intensity).includes(phrase.text));
    spoken.push(phrase.text);
  }
  assert.equal(spoken.length, 1, "one line for one stable correction");
});
