/**
 * tests/coaching/hardening.test.ts — Unit 36 (Part 4.5): FINAL HARDENING PASS.
 *
 * These tests exist because three real defects were found by TRACING the
 * shipped code, not by reading its documentation:
 *
 *   D1 · THE PLANNER WAS BLIND ON DEVICE. `ttsService.speakCoaching` is only
 *        reached when the routing gate says the frame is deliverable, which
 *        by construction excludes every evaluating / unavailable / body-lost
 *        frame. The planner's silence handling (documented, unit-tested in
 *        isolation) therefore never ran in the app: a PERFECT episode broken
 *        by the subject leaving the frame could not be confirmed again for
 *        the rest of the session.
 *
 *   D2 · THE LANGUAGE WAS RESOLVED ONE STAGE TOO LATE. `speakCore`
 *        normalized it, but phrase selection had already happened with the
 *        raw (persisted, therefore untrusted) value.
 *
 *   D3 · THE PURE TABLES WERE NOT DEFENSIVE. `BANKS[language]` and
 *        `VOICE_LANGUAGE_LOCALES[language]` were indexed directly, so an
 *        untrusted language threw a TypeError inside the frame loop instead
 *        of degrading to a bank that exists.
 *
 *   Unit 37-repair addendum — every degradation now names the ONE canonical
 *   default instruction language (`DEFAULT_INSTRUCTION_LANGUAGE`, the
 *   fresh-install language — Hindi), not a hardcoded second rule. Assertions
 *   below therefore compare against that constant instead of a literal:
 *   if the product default ever moves, the contract moves with it, and no
 *   layer is allowed to degrade differently from any other.
 *
 * Determinism: fake clock, injected random source, hand-built semantic
 * states. No device, no audio, no network, no sleeping.
 *
 * SCOPE HONESTY: everything below is CODE-VERIFIED on a workstation. None of
 * it proves a phone actually spoke. See mobile/docs/unit-36-final-hardening.md.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";

import {
  CORRECTION_PERSISTENCE_FRAMES,
  PERFECT_PERSISTENCE_FRAMES,
  createPoseAnalysisEngine,
} from "../../shared/ml/analysis";
import {
  createCoachingSpeechPlanner,
  decisionToCoachingState,
  selectCoachingPhrase,
  type CoachingState,
} from "../../shared/coaching";
import {
  instructionPool,
  pickInstruction,
  resetInstructionMemory,
  resolveInstructionPool,
  type InstructionLanguage,
} from "../../shared/constants/poseInstructions";
import {
  SPEECH_PROSODY,
  matchLocaleToLanguage,
  normalizedLocaleChain,
  normalizeVoiceLocale,
  primaryLocaleFor,
  prosodyForIntensity,
  rankVoicesForLanguage,
  resolveInstructionLanguage,
  DEFAULT_INSTRUCTION_LANGUAGE,
  resolveVoiceSelection,
  routeCoachingSpeech,
  voiceOptionsForLanguage,
  type DeviceVoice,
} from "../../shared/voice";
import { bodyLandmarks, referenceInput, referenceWithOffsets } from "../analysis/fixtures";

/* ───────────────────────── source-tree location ─────────────────────── */

function findRepoRoot(): string {
  let current = __dirname;
  for (let depth = 0; depth < 8; depth += 1) {
    if (
      existsSync(join(current, "shared", "voice", "prosody.ts")) &&
      existsSync(join(current, "mobile", "src", "core", "voice", "ttsService.ts"))
    ) {
      return current;
    }
    const parent = dirname(current);
    if (parent === current) break;
    current = parent;
  }
  throw new Error("repository source root not found from " + __dirname);
}

const REPO_ROOT = findRepoRoot();

function source(...parts: string[]): string {
  return readFileSync(join(REPO_ROOT, ...parts), "utf8")
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "");
}

const TTS = source("mobile", "src", "core", "voice", "ttsService.ts");
const CAMERA = source(
  "mobile",
  "src",
  "features",
  "camera",
  "presentation",
  "screens",
  "CameraTab.tsx",
);
const PREVIEW = source("tooling", "preview", "src", "preview", "screens-tabs.tsx");

/* ───────────────────────────── test doubles ─────────────────────────── */

function correctionState(token: string, stableFrames = 4): CoachingState {
  return {
    kind: "correction",
    token,
    category: "hand_left_bend",
    measurementId: "leftElbow",
    direction: "decrease",
    severity: "minor",
    intensity: "gentle",
    confidence: 0.9,
    stableFrames,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
  };
}

function perfectState(stableFrames = 4): CoachingState {
  return {
    kind: "perfect",
    token: "PERFECT",
    category: "final_pose_good",
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0.95,
    stableFrames,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
  };
}

function unavailableState(reason: "no-live-pose" | "reference-unavailable"): CoachingState {
  return {
    kind: "unavailable",
    token: `UNAVAILABLE:${reason}`,
    category: null,
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0,
    stableFrames: 0,
    heldByHysteresis: false,
    unavailableReason: reason,
    speakable: false,
  };
}

/**
 * The DEVICE loop, reduced to its speech decisions: routing gate → speak or
 * observe. `speak` mirrors ttsService.speakCoaching (plan + execute), and
 * `observeOnly` mirrors ttsService.observeCoaching (plan, never execute).
 */
function deviceLoop(options?: { readonly observeUnspeakable?: boolean }) {
  const planner = createCoachingSpeechPlanner();
  const spoken: string[] = [];
  return {
    planner,
    spoken,
    frame(state: CoachingState, nowMs: number): void {
      const route = routeCoachingSpeech({
        state,
        voiceGuidanceEnabled: true,
        language: "en",
      });
      if (route.deliverToSpeech && route.state !== null) {
        const plan = planner.plan({ state: route.state, nowMs, isSpeaking: false });
        if (!plan.speak) return;
        const phrase = selectCoachingPhrase(route.state, route.language, {
          random: () => 0,
        });
        if (phrase === null) {
          planner.revert(plan);
          return;
        }
        spoken.push(`${plan.reason}:${plan.token}`);
        return;
      }
      if (options?.observeUnspeakable !== true) return;
      if (route.suppression !== "state-not-speakable" || route.state === null) return;
      /* observeCoaching: the planner learns, speech is impossible. */
      planner.plan({ state: route.state, nowMs, isSpeaking: false });
    },
  };
}

/* ==================================================================== *
 * D1 · THE OBSERVATION PATH — the planner must see the silent frames
 * ==================================================================== */

test("D1 regression: without observation, a broken PERFECT episode can never be confirmed again", () => {
  const loop = deviceLoop({ observeUnspeakable: false });
  let now = 0;
  loop.frame(perfectState(), (now += 1_000));
  assert.equal(loop.spoken.length, 1, "the first perfect hold is confirmed");

  /* The subject walks out of frame for a full 8 seconds. */
  for (let i = 0; i < 120; i += 1) loop.frame(unavailableState("no-live-pose"), (now += 66));
  /* …and comes back into a clean, perfect pose. */
  for (let i = 0; i < 30; i += 1) loop.frame(perfectState(), (now += 66));

  assert.equal(
    loop.spoken.length,
    1,
    "this is the defect: the coach stays mute for the rest of the session",
  );
});

test("D1 fix: the observed silence lets a genuinely new PERFECT episode speak again", () => {
  const loop = deviceLoop({ observeUnspeakable: true });
  let now = 0;
  loop.frame(perfectState(), (now += 1_000));
  assert.equal(loop.spoken.length, 1);

  for (let i = 0; i < 120; i += 1) loop.frame(unavailableState("no-live-pose"), (now += 66));
  for (let i = 0; i < 30; i += 1) loop.frame(perfectState(), (now += 66));

  assert.equal(loop.spoken.length, 2, "the returning perfect hold is confirmed once");
  assert.ok(loop.spoken.every((entry) => entry.endsWith(":PERFECT")));
});

test("observation never becomes speech: unavailable frames add no utterance", () => {
  const loop = deviceLoop({ observeUnspeakable: true });
  let now = 0;
  for (let i = 0; i < 200; i += 1) {
    loop.frame(unavailableState("reference-unavailable"), (now += 66));
    loop.frame(unavailableState("no-live-pose"), (now += 66));
  }
  assert.deepEqual(loop.spoken, [], "an unusable reference is never voiced");
});

test("a ONE-FRAME unjudgeable flicker still cannot reset the cadence gates", () => {
  const loop = deviceLoop({ observeUnspeakable: true });
  let now = 0;
  loop.frame(correctionState("A"), (now += 1_000));
  assert.equal(loop.spoken.length, 1);
  /* A single dropped frame (66 ms) is far below silenceGraceMs. */
  loop.frame(unavailableState("no-live-pose"), (now += 66));
  loop.frame(correctionState("A"), (now += 66));
  assert.equal(loop.spoken.length, 1, "flicker must not buy an extra line");
});

test("the camera feeds unjudgeable frames to the observation path, and only those", () => {
  assert.ok(
    /ttsService\.observeCoaching\(/.test(CAMERA),
    "CameraTab must feed the planner the frames it may not speak",
  );
  assert.ok(
    /route\.suppression === 'state-not-speakable'/.test(CAMERA),
    "only engine-declared unjudgeable frames are observed",
  );
  /* Speech still has exactly one call site. */
  assert.equal((CAMERA.match(/speakCoaching\s*\(/g) ?? []).length, 1);
});

test("observeCoaching cannot reach the phrase layer or the speech engine", () => {
  const start = TTS.indexOf("observeCoaching(");
  assert.ok(start > 0, "observeCoaching must exist in the speech service");
  const body = TTS.slice(start, TTS.indexOf("\n  }", start));
  assert.ok(!body.includes("selectCoachingPhrase"), "observation must not pick a phrase");
  assert.ok(!body.includes("Speech."), "observation must not touch the speech engine");
  assert.ok(!body.includes("speakCore"), "observation must not execute speech");
  assert.ok(body.includes("if (state.speakable) return;"), "speakable states belong to speakCoaching");
  assert.ok(body.includes("this.planner.plan("), "observation must reach the planner");
});

/* ==================================================================== *
 * D2/D3 · AN UNTRUSTED LANGUAGE DEGRADES — it never throws, never mutes
 * ==================================================================== */

/** Exactly what a corrupted MMKV record looks like once it is typed. */
const BOGUS = "hinglish" as unknown as InstructionLanguage;
const EMPTY = "" as unknown as InstructionLanguage;
const NOT_A_STRING = 7 as unknown as InstructionLanguage;

test("the phrase bank degrades an unknown language to the canonical default instead of throwing", () => {
  for (const language of [BOGUS, EMPTY, NOT_A_STRING]) {
    const pool = resolveInstructionPool("hand_left_bend", language, "gentle");
    assert.ok(pool.phrases.length > 0, "a real pool is returned");
    /* Unit 37 contract: an unreadable language behaves EXACTLY like a fresh
       install — the canonical default bank, never a missing pool and never a
       divergent second answer. */
    assert.equal(
      pool.language,
      DEFAULT_INSTRUCTION_LANGUAGE,
      "the pool reports the language it actually supplied",
    );
    assert.deepEqual(
      pool.phrases,
      instructionPool("hand_left_bend", DEFAULT_INSTRUCTION_LANGUAGE, "gentle"),
      "the canonical default pool is the documented degradation",
    );
    const firm = resolveInstructionPool("hand_left_bend", language, "firm");
    assert.equal(firm.language, DEFAULT_INSTRUCTION_LANGUAGE);
    assert.deepEqual(
      firm.phrases,
      instructionPool("hand_left_bend", DEFAULT_INSTRUCTION_LANGUAGE, "firm"),
    );
    const pick = pickInstruction("hand_left_bend", language, { peek: true });
    assert.ok(pick !== null);
    assert.equal(pick.language, DEFAULT_INSTRUCTION_LANGUAGE);
  }
});

test("phrase selection reports the language it actually spoke, not the one asked for", () => {
  resetInstructionMemory();
  const state = correctionState("LEFT_ELBOW_DECREASE");
  const degraded = selectCoachingPhrase(state, BOGUS, { random: () => 0 });
  assert.ok(degraded !== null, "a corrupted preference must not mute the coach");
  /* Unit 37: the degrade target is the DEFAULT instruction language, i.e.
     exactly what a fresh install coaches in — never a random third answer. */
  assert.equal(degraded.language, DEFAULT_INSTRUCTION_LANGUAGE);
  assert.ok(
    instructionPool(
      "hand_left_bend",
      DEFAULT_INSTRUCTION_LANGUAGE,
      "gentle",
    ).includes(degraded.text),
    "the spoken line comes from the SAME category's pool in the fallback language",
  );

  /* Both valid languages are untouched — the guard is a fallback, never a
     rewrite of a preference the user actually expressed. */
  for (const language of ["hi", "en"] as const) {
    resetInstructionMemory();
    const picked = selectCoachingPhrase(state, language, { random: () => 0 });
    assert.ok(picked !== null);
    assert.equal(picked.language, language);
    assert.ok(
      instructionPool("hand_left_bend", language, "gentle").includes(picked.text),
    );
  }
});

test("the mathematics is identical in both languages — only the words change", () => {
  resetInstructionMemory();
  const state = correctionState("LEFT_ELBOW_DECREASE");
  const english = selectCoachingPhrase(state, "en", { random: () => 0 });
  const hindi = selectCoachingPhrase(state, "hi", { random: () => 0 });
  assert.ok(english !== null && hindi !== null);
  assert.equal(english.category, hindi.category);
  assert.equal(english.token, hindi.token);
  assert.equal(english.requestedIntensity, hindi.requestedIntensity);
  assert.notEqual(english.text, hindi.text);
});

test("the locale tables degrade an unknown language instead of throwing", () => {
  for (const language of [BOGUS, EMPTY, NOT_A_STRING]) {
    /* The locale path degrades through the SAME canonical resolution as
       routing and phrase selection — never through a second rule. */
    assert.equal(resolveInstructionLanguage(language), DEFAULT_INSTRUCTION_LANGUAGE);
    assert.equal(
      primaryLocaleFor(language),
      primaryLocaleFor(DEFAULT_INSTRUCTION_LANGUAGE),
    );
    assert.deepEqual(
      normalizedLocaleChain(language),
      normalizedLocaleChain(DEFAULT_INSTRUCTION_LANGUAGE),
    );
    /* A real voice of the RESOLVED language must still be recognised as
       speakable — a corrupted preference can never read as "this device has
       no voice". */
    assert.equal(
      matchLocaleToLanguage(primaryLocaleFor(DEFAULT_INSTRUCTION_LANGUAGE), language),
      "exact",
    );
  }
  /* Valid input keeps its own chain, in both languages. */
  assert.equal(primaryLocaleFor("hi"), "hi-IN");
  assert.equal(matchLocaleToLanguage("hi-IN", "hi"), "exact");
  assert.equal(primaryLocaleFor("en"), "en-IN");
  assert.equal(matchLocaleToLanguage("en-US", "en"), "exact");
});

test("voice selection survives an unknown language and speaks only the resolved language's voice", () => {
  const catalog: readonly DeviceVoice[] = [
    { identifier: "en-us-x-sfg#female_1", language: "en-US", quality: "Enhanced" },
    { identifier: "hi-in-x-hia#male_1", language: "hi-IN" },
  ];
  /* The voice path consumes the RESOLVED language: the expected voice is
     DERIVED from the canonical resolution, so routing, locale tables and
     voice can never disagree on what an unreadable preference means. */
  const resolved = resolveInstructionLanguage(BOGUS);
  assert.equal(resolved, DEFAULT_INSTRUCTION_LANGUAGE);
  const expected = catalog.find(
    (voice) => matchLocaleToLanguage(voice.language, resolved) === "exact",
  );
  assert.ok(expected !== undefined, "fixture must contain a voice of the resolved language");

  const ranked = rankVoicesForLanguage(catalog, BOGUS);
  assert.deepEqual(
    ranked.map((voice) => voice.identifier),
    [expected.identifier],
    "only the resolved language's voice ranks — the other bank's voice is excluded, never a last resort",
  );

  const selection = resolveVoiceSelection({
    voices: catalog,
    language: BOGUS,
    preferredVoiceId: null,
  });
  assert.equal(selection.voiceId, expected.identifier);
  assert.equal(selection.locale, normalizeVoiceLocale(expected.language));
  assert.equal(selection.source, "ranked");

  const options = voiceOptionsForLanguage(catalog, BOGUS);
  assert.equal(options.length, 2, "Automatic + the resolved language's one voice");

  /* Without ANY installed voice for the resolved language the honest answer
     is the engine default for the resolved primary locale — the other
     language's voice must not be substituted. */
  const wrongLanguageCatalog = catalog.filter(
    (voice) => matchLocaleToLanguage(voice.language, resolved) !== "exact",
  );
  assert.ok(wrongLanguageCatalog.length > 0);
  const degraded = resolveVoiceSelection({
    voices: wrongLanguageCatalog,
    language: BOGUS,
    preferredVoiceId: null,
  });
  assert.equal(degraded.voiceId, null);
  assert.equal(degraded.source, "engine-default");
  assert.equal(degraded.locale, primaryLocaleFor(resolved));
});

test("the speech service resolves the language before the phrase bank is asked", () => {
  const speakCoaching = TTS.slice(TTS.indexOf("async speakCoaching("));
  const resolveAt = speakCoaching.indexOf("resolveInstructionLanguage(");
  const selectAt = speakCoaching.indexOf("selectCoachingPhrase(");
  assert.ok(resolveAt > 0 && selectAt > 0);
  assert.ok(resolveAt < selectAt, "normalization must precede phrase selection");

  const speakInstruction = TTS.slice(TTS.indexOf("async speakInstruction("));
  const instrResolveAt = speakInstruction.indexOf("resolveInstructionLanguage(");
  const instrGetAt = speakInstruction.indexOf("getInstruction(");
  assert.ok(instrResolveAt > 0 && instrGetAt > 0 && instrResolveAt < instrGetAt);
});

/* ==================================================================== *
 * SEVERITY REACHES THE DEVICE — no dead property anywhere in the chain
 * ==================================================================== */

test("engine severity reaches the phrase pool AND the delivery, for both tiers", () => {
  const landmarks = bodyLandmarks();

  function settledState(offsetDegrees: number): CoachingState {
    const engine = createPoseAnalysisEngine({
      reference: referenceInput(referenceWithOffsets(landmarks, { leftElbow: offsetDegrees })),
      sessionId: "unit36",
    });
    let decision = engine.analyzeFrame(landmarks);
    for (let i = 1; i < CORRECTION_PERSISTENCE_FRAMES; i += 1) {
      decision = engine.analyzeFrame(landmarks);
    }
    return decisionToCoachingState(decision);
  }

  const minor = settledState(15);
  assert.equal(minor.severity, "minor");
  assert.equal(minor.intensity, "gentle");

  const major = settledState(40);
  assert.equal(major.severity, "major");
  assert.equal(major.intensity, "firm");

  for (const language of ["en", "hi"] as const) {
    resetInstructionMemory();
    const gentle = selectCoachingPhrase(minor, language, { random: () => 0 });
    const firm = selectCoachingPhrase(major, language, { random: () => 0 });
    assert.ok(gentle !== null && firm !== null);
    assert.equal(gentle.requestedIntensity, "gentle");
    assert.equal(firm.requestedIntensity, "firm");
    assert.equal(firm.fallback, "exact", "both elbow directions have firm copy");
    assert.ok(instructionPool(firm.category, language, "firm").includes(firm.text));
    /* …and the severity survives all the way into how it is DELIVERED. */
    assert.equal(
      prosodyForIntensity(firm.intensity).rate,
      SPEECH_PROSODY.firm.rate,
      "a firmer correction is also delivered as the firm tier",
    );
    assert.equal(prosodyForIntensity(gentle.intensity).rate, SPEECH_PROSODY.gentle.rate);
  }
});

test("a stable perfect hold stays gentle and never borrows a correction pool", () => {
  const landmarks = bodyLandmarks();
  const engine = createPoseAnalysisEngine({
    reference: referenceInput(referenceWithOffsets(landmarks, {})),
    sessionId: "unit36-perfect",
  });
  let decision = engine.analyzeFrame(landmarks);
  for (let i = 1; i < PERFECT_PERSISTENCE_FRAMES + 1; i += 1) {
    decision = engine.analyzeFrame(landmarks);
  }
  const state = decisionToCoachingState(decision);
  assert.equal(state.kind, "perfect");
  assert.equal(state.category, "final_pose_good");
  resetInstructionMemory();
  const phrase = selectCoachingPhrase(state, "en", { random: () => 0 });
  assert.ok(phrase !== null);
  assert.equal(phrase.category, "final_pose_good");
  assert.equal(phrase.intensity, "gentle");
});

/* ==================================================================== *
 * PROSODY IS ONE TABLE — two speech backends cannot drift apart
 * ==================================================================== */

test("the prosody table is the only place delivery numbers exist", () => {
  assert.ok(SPEECH_PROSODY.firm.rate > SPEECH_PROSODY.gentle.rate);
  for (const tier of [SPEECH_PROSODY.gentle, SPEECH_PROSODY.firm]) {
    assert.ok(tier.rate >= 0.95 && tier.rate <= 1.05, "spec band 0.95–1.05");
    assert.equal(tier.pitch, 1, "a firmer cue is not a higher voice");
    assert.equal(tier.volume, 1, "a firmer cue is not a louder voice");
  }
  assert.deepEqual(prosodyForIntensity(undefined), SPEECH_PROSODY.gentle);

  assert.ok(TTS.includes("prosodyForIntensity("), "the device backend reads the table");
  assert.ok(PREVIEW.includes("prosodyForIntensity("), "the preview mirror reads it too");
  for (const [name, code] of [
    ["ttsService", TTS],
    ["preview mirror", PREVIEW],
  ] as const) {
    assert.ok(
      !/rate\s*[:=]\s*(0|1)\.\d+/.test(code),
      `${name} must not hardcode a speech rate`,
    );
  }
});

test("the prosody module stays pure: no geometry, no engine, no storage", () => {
  const code = source("shared", "voice", "prosody.ts");
  assert.ok(!/expo-speech|react-native|speechSynthesis/.test(code));
  assert.ok(!/from\s+["'][^"']*\/ml\//.test(code), "prosody must not import geometry");
  assert.ok(!/severity|Severity/.test(code), "prosody must not derive intensity");
});

/* ==================================================================== *
 * NO DEAD STATE IN THE SPEECH SERVICE
 * ==================================================================== */

test("the speech service keeps no write-only in-flight flag", () => {
  assert.ok(
    !/this\.speaking\b/.test(TTS),
    "the old `speaking` field was assigned five times and never read",
  );
  /* The native start mark that replaced it IS read by the watchdog. */
  assert.ok(TTS.includes("this.speechStartedAtMs"));
  assert.ok(/const since = this\.speechStartedAtMs \?\? this\.activeSinceMs;/.test(TTS));
});

test("the preview mirror and the device agree on when the planner is consulted", () => {
  assert.ok(PREVIEW.includes("routeCoachingSpeech("));
  assert.ok(
    PREVIEW.indexOf("routeCoachingSpeech(") < PREVIEW.indexOf("speechPlannerRef.current.plan("),
    "routing decides first in both runtimes",
  );
  assert.ok(
    /!coachingState\.speakable/.test(PREVIEW),
    "the mirror observes unjudgeable frames like the device does",
  );
});
