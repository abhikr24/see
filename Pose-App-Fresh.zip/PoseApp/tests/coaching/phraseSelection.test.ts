/**
 * tests/coaching/phraseSelection.test.ts — Unit 33 (Part 4.2):
 * THE SEMANTIC → PHRASE CONTRACT.
 *
 *   SEMANTIC COACHING STATE → CATEGORY → LANGUAGE → SEVERITY → VALID POOL
 *                           → controlled, non-repeating variation
 *
 * Every test asserts a property of that chain, never an implementation
 * detail of a single sentence:
 *   · category + language + gentle  → a line from that exact gentle pool
 *   · category + language + firm    → a line from that exact firm pool
 *   · a wrong/unknown category      → silence, never another pool's copy
 *   · a missing firm pool           → explicit, same-category degradation
 *   · an immediate repeat           → avoided whenever alternatives exist
 *   · randomness                    → can only reorder EQUALLY valid lines
 *   · unavailable / evaluating      → no correction phrase exists at all
 *
 * Deterministic: injected random sources only, no clock, no network, no
 * device, no real speech.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  CATEGORY_COVERAGE,
  REACHABLE_CATEGORIES,
  SIDE_AGNOSTIC_CATEGORIES,
  coachingCategoryFor,
  intensityForSeverity,
  selectCoachingPhrase,
  type CoachingState,
} from "../../shared/coaching";
import {
  instructionPool,
  isVoiceInstructionCategory,
  pickInstruction,
  resetInstructionMemory,
  resolveInstructionPool,
  VOICE_INSTRUCTION_CATEGORIES,
  type InstructionLanguage,
  type PhraseIntensity,
  type VoiceInstructionCategory,
} from "../../shared/constants/poseInstructions";
import { JOINT_GUIDANCE_RULES } from "../../shared/ml/guidanceGenerator";
import { MATCH_JOINTS } from "../../shared/ml/poseLandmarks";

const LANGUAGES: readonly InstructionLanguage[] = ["en", "hi"];
const INTENSITIES: readonly PhraseIntensity[] = ["gentle", "firm"];

/** Categories a live joint correction can actually produce today. */
const CORRECTION_CATEGORIES: readonly VoiceInstructionCategory[] =
  CATEGORY_COVERAGE.filter(
    (entry) => entry.reachability === "reachable-correction",
  ).map((entry) => entry.category);

/** A hand-built semantic state — the contract input, no engine needed. */
function correctionState(
  category: VoiceInstructionCategory,
  intensity: PhraseIntensity,
  overrides?: Partial<CoachingState>,
): CoachingState {
  return {
    kind: "correction",
    token: `TEST:${category}:${intensity}`,
    category,
    measurementId: "leftElbow",
    direction: intensity === "firm" ? "decrease" : "increase",
    severity: intensity === "firm" ? "major" : "minor",
    intensity,
    confidence: 0.9,
    stableFrames: 5,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
    ...overrides,
  };
}

function fixedRandom(value: number): () => number {
  return () => value;
}

/* ------------------- category × language × severity --------------------- */

test("every reachable correction category speaks from its own pool in both languages and both tiers", () => {
  for (const category of CORRECTION_CATEGORIES) {
    for (const language of LANGUAGES) {
      for (const intensity of INTENSITIES) {
        resetInstructionMemory();
        const pool = instructionPool(category, language, intensity);
        assert.ok(
          pool.length > 0,
          `${category}/${language}/${intensity} must have copy`,
        );
        const phrase = selectCoachingPhrase(
          correctionState(category, intensity),
          language,
          { random: fixedRandom(0.42) },
        );
        assert.ok(phrase !== null, `${category}/${language}/${intensity}`);
        assert.equal(phrase.category, category);
        assert.equal(phrase.language, language);
        assert.equal(phrase.requestedIntensity, intensity);
        assert.ok(
          pool.includes(phrase.text),
          `${category}/${language}/${intensity} spoke text from another pool`,
        );
      }
    }
  }
});

test("gentle and firm are different words for the same instruction, not the same line twice", () => {
  for (const category of CORRECTION_CATEGORIES) {
    for (const language of LANGUAGES) {
      const gentle = instructionPool(category, language, "gentle");
      const firm = instructionPool(category, language, "firm");
      assert.ok(gentle.length > 1, `${category}/${language} needs variation`);
      assert.ok(firm.length > 1, `${category}/${language} needs a firm pool`);
      for (const line of firm) {
        assert.equal(
          gentle.includes(line),
          false,
          `${category}/${language}: firm copy must be distinct from gentle`,
        );
      }
      assert.equal(
        resolveInstructionPool(category, language, "firm").fallback,
        "exact",
        `${category}/${language} must have a real firm tier`,
      );
    }
  }
});

test("firmer copy stays coaching, never abuse; gentle copy stays actionable", () => {
  /* A firmer cue may be direct ("more", "much", "zyada") but must never be
     an insult, and a gentle cue must still contain an instruction. */
  const banned = ["stupid", "idiot", "useless", "बेवकूफ", "गधे"];
  for (const category of CORRECTION_CATEGORIES) {
    for (const language of LANGUAGES) {
      for (const intensity of INTENSITIES) {
        for (const line of instructionPool(category, language, intensity)) {
          const lower = line.toLowerCase();
          for (const word of banned) {
            assert.equal(lower.includes(word), false, `${category}: ${line}`);
          }
          assert.ok(line.trim().length >= 8, `${category}: "${line}" too short`);
          /* Short, session-friendly cues: a spoken correction is a breath,
             not a paragraph. */
          assert.ok(line.length <= 70, `${category}: "${line}" too long`);
        }
      }
    }
  }
});

/* ---------------------- language independence --------------------------- */

test("one semantic state feeds both language banks — no per-language pose logic", () => {
  resetInstructionMemory();
  const state = correctionState("leg_left_bend", "gentle");
  const english = selectCoachingPhrase(state, "en", { random: fixedRandom(0) });
  const hindi = selectCoachingPhrase(state, "hi", { random: fixedRandom(0) });
  assert.ok(english !== null && hindi !== null);
  assert.equal(english.token, state.token);
  assert.equal(hindi.token, state.token);
  assert.equal(english.category, hindi.category);
  assert.equal(english.intensity, hindi.intensity);
  assert.ok(instructionPool("leg_left_bend", "en", "gentle").includes(english.text));
  assert.ok(instructionPool("leg_left_bend", "hi", "gentle").includes(hindi.text));
  assert.notEqual(english.text, hindi.text);
});

test("every category has copy in every supported language — no silent language hole", () => {
  for (const category of VOICE_INSTRUCTION_CATEGORIES) {
    for (const language of LANGUAGES) {
      assert.ok(
        instructionPool(category, language, "gentle").length > 0,
        `${category}/${language} gentle pool is empty`,
      );
    }
  }
});

/* ------------------ a wrong category is unreachable --------------------- */

test("selection can never reach another category's copy", () => {
  /* Reachable correction pools are pairwise disjoint, so pool membership is
     proof of category correctness in the tests above. */
  const seen = new Map<string, VoiceInstructionCategory>();
  for (const category of CORRECTION_CATEGORIES) {
    for (const language of LANGUAGES) {
      for (const intensity of INTENSITIES) {
        for (const line of instructionPool(category, language, intensity)) {
          const owner = seen.get(line);
          assert.equal(
            owner,
            undefined,
            `"${line}" is shared by ${category} and ${String(owner)}`,
          );
          seen.set(line, category);
        }
      }
    }
  }
});

test("an unknown or non-speakable category yields silence, not a substitute phrase", () => {
  assert.equal(isVoiceInstructionCategory("hand_up"), true);
  assert.equal(isVoiceInstructionCategory("hand_sideways"), false);

  const bogus = correctionState("hand_up", "gentle", {
    category: "not_a_category" as VoiceInstructionCategory,
  });
  assert.equal(selectCoachingPhrase(bogus, "en"), null);
  assert.equal(selectCoachingPhrase(bogus, "hi"), null);
  assert.equal(
    pickInstruction("not_a_category" as VoiceInstructionCategory, "en"),
    null,
  );
});

test("the engine's direction decides the category — opposite directions never share a pool", () => {
  for (const joint of MATCH_JOINTS) {
    const rule = JOINT_GUIDANCE_RULES[joint.key];
    if (rule === undefined) continue;
    const increase = coachingCategoryFor(joint.key, "increase");
    const decrease = coachingCategoryFor(joint.key, "decrease");
    assert.equal(increase, rule.liveLessThanRef.voiceCategory);
    assert.equal(decrease, rule.liveGreaterThanRef.voiceCategory);
    assert.notEqual(
      increase,
      decrease,
      `${joint.key}: both directions map to one pool — the spoken cue could invert`,
    );
    assert.equal(coachingCategoryFor(joint.key, "none"), null);
  }
});

test("side-specific corrections say the side; the two documented side-agnostic pools do not pretend to", () => {
  const sides: Readonly<Record<string, readonly string[]>> = {
    left: ["left", "बाय", "बाई", "बाए", "बाएं"],
    right: ["right", "दाय", "दाई", "दाए", "दाएं"],
  };
  for (const category of CORRECTION_CATEGORIES) {
    if (SIDE_AGNOSTIC_CATEGORIES.includes(category)) continue;
    const side = category.includes("_left") ? "left" : "right";
    const markers = sides[side] ?? [];
    for (const language of LANGUAGES) {
      for (const intensity of INTENSITIES) {
        for (const line of instructionPool(category, language, intensity)) {
          assert.ok(
            markers.some((marker) => line.toLowerCase().includes(marker)),
            `${category}/${language}/${intensity}: "${line}" never names the ${side} side`,
          );
        }
      }
    }
  }
});

/* --------------------- severity-pool fallback --------------------------- */

test("a category without a firm pool degrades explicitly, inside the same category", () => {
  /* final_pose_good is reachable (the PERFECT line) and deliberately has no
     firm tier — a positive line is never delivered sternly. */
  const resolved = resolveInstructionPool("final_pose_good", "en", "firm");
  assert.equal(resolved.requestedIntensity, "firm");
  assert.equal(resolved.resolvedIntensity, "gentle");
  assert.equal(resolved.fallback, "gentle-pool");
  assert.deepEqual(resolved.phrases, instructionPool("final_pose_good", "en", "gentle"));

  resetInstructionMemory();
  const phrase = selectCoachingPhrase(
    correctionState("final_pose_good", "firm", { kind: "perfect" }),
    "en",
    { random: fixedRandom(0) },
  );
  assert.ok(phrase !== null);
  assert.equal(phrase.requestedIntensity, "firm");
  assert.equal(phrase.intensity, "gentle");
  assert.equal(phrase.fallback, "gentle-pool");
  assert.ok(instructionPool("final_pose_good", "en", "gentle").includes(phrase.text));
});

test("severity is carried, never recomputed, by the phrase layer", () => {
  assert.equal(intensityForSeverity("minor"), "gentle");
  assert.equal(intensityForSeverity("major"), "firm");
  assert.equal(intensityForSeverity("within-tolerance"), "gentle");
  assert.equal(intensityForSeverity(null), "gentle");

  resetInstructionMemory();
  const firm = selectCoachingPhrase(
    correctionState("hand_right_straighten", "firm"),
    "en",
    { random: fixedRandom(0) },
  );
  assert.ok(firm !== null);
  assert.equal(firm.intensity, "firm");
  assert.equal(firm.fallback, "exact");
  assert.ok(
    instructionPool("hand_right_straighten", "en", "firm").includes(firm.text),
  );
});

/* --------------------- controlled variation ----------------------------- */

test("the same correction twice in a row never repeats the same sentence", () => {
  for (const language of LANGUAGES) {
    resetInstructionMemory();
    const state = correctionState("leg_right_forward", "gentle");
    const first = selectCoachingPhrase(state, language, { random: fixedRandom(0.3) });
    const second = selectCoachingPhrase(state, language, { random: fixedRandom(0.3) });
    assert.ok(first !== null && second !== null);
    assert.notEqual(second.text, first.text, `${language}: immediate repeat`);
    assert.equal(second.avoidedRepeat, true);
    assert.ok(instructionPool("leg_right_forward", language, "gentle").includes(second.text));
  }
});

test("randomness only reorders equally valid lines — it can never change the meaning", () => {
  const category: VoiceInstructionCategory = "leg_left_straighten";
  const pool = instructionPool(category, "hi", "firm");
  const draws = [-5, 0, 0.01, 0.5, 0.999, 1, 42, Number.NaN, Number.POSITIVE_INFINITY];
  for (const draw of draws) {
    resetInstructionMemory();
    const phrase = selectCoachingPhrase(correctionState(category, "firm"), "hi", {
      random: fixedRandom(draw),
    });
    assert.ok(phrase !== null, `draw ${draw} produced nothing`);
    assert.ok(pool.includes(phrase.text), `draw ${draw} escaped the pool`);
    assert.ok(phrase.poolIndex >= 0 && phrase.poolIndex < pool.length);
  }
  /* A throwing random source must not take the coach down either. */
  resetInstructionMemory();
  const resilient = selectCoachingPhrase(correctionState(category, "firm"), "hi", {
    random: () => {
      throw new Error("bad rng");
    },
  });
  assert.ok(resilient !== null);
  assert.ok(pool.includes(resilient.text));
});

test("selection is reproducible for a fixed random source (deterministic tests)", () => {
  resetInstructionMemory();
  const a = pickInstruction("hand_left_bend", "en", {
    intensity: "gentle",
    random: fixedRandom(0.6),
  });
  resetInstructionMemory();
  const b = pickInstruction("hand_left_bend", "en", {
    intensity: "gentle",
    random: fixedRandom(0.6),
  });
  assert.ok(a !== null && b !== null);
  assert.equal(a.text, b.text);
  assert.equal(a.index, b.index);
});

test("a peeked phrase does not consume a variation the user never heard", () => {
  resetInstructionMemory();
  const peeked = pickInstruction("hand_up", "en", {
    random: fixedRandom(0),
    peek: true,
  });
  const spoken = pickInstruction("hand_up", "en", { random: fixedRandom(0) });
  assert.ok(peeked !== null && spoken !== null);
  assert.equal(spoken.text, peeked.text);
  assert.equal(spoken.avoidedRepeat, false);
});

/* -------------------- nothing to say stays silent ----------------------- */

test("evaluating and unavailable states cannot produce any phrase", () => {
  const silent: readonly CoachingState[] = [
    {
      kind: "evaluating",
      token: "EVALUATING",
      category: null,
      measurementId: null,
      direction: "none",
      severity: null,
      intensity: "gentle",
      confidence: 0,
      stableFrames: 0,
      heldByHysteresis: false,
      unavailableReason: null,
      speakable: false,
    },
    {
      kind: "unavailable",
      token: "UNAVAILABLE:reference-unavailable",
      category: null,
      measurementId: null,
      direction: "none",
      severity: null,
      intensity: "gentle",
      confidence: 0,
      stableFrames: 0,
      heldByHysteresis: false,
      unavailableReason: "reference-unavailable",
      speakable: false,
    },
  ];
  for (const state of silent) {
    for (const language of LANGUAGES) {
      assert.equal(selectCoachingPhrase(state, language), null);
    }
  }

  /* Even a state that carries a category but is marked non-speakable, or a
     speakable-looking state of a silent kind, must stay silent. */
  const spoofed = correctionState("hand_up", "gentle", { speakable: false });
  assert.equal(selectCoachingPhrase(spoofed, "en"), null);
  const wrongKind = correctionState("hand_up", "gentle", { kind: "evaluating" });
  assert.equal(selectCoachingPhrase(wrongKind, "en"), null);
});

/* ------------------------- reachability trace --------------------------- */

test("the coverage trace matches the rules table exactly", () => {
  const produced = new Set<VoiceInstructionCategory>();
  for (const joint of MATCH_JOINTS) {
    const rule = JOINT_GUIDANCE_RULES[joint.key];
    if (rule === undefined) continue;
    produced.add(rule.liveLessThanRef.voiceCategory);
    produced.add(rule.liveGreaterThanRef.voiceCategory);
  }
  for (const category of CORRECTION_CATEGORIES) {
    assert.ok(produced.has(category), `${category} is claimed but unproduced`);
  }
  for (const category of produced) {
    assert.ok(
      REACHABLE_CATEGORIES.includes(category),
      `${category} is produced but not traced as reachable`,
    );
  }
  for (const entry of CATEGORY_COVERAGE) {
    if (entry.reachability.startsWith("reachable-")) continue;
    assert.deepEqual(entry.producers, [], `${entry.category} must have no producer`);
    assert.ok(entry.note.length > 0, `${entry.category} must document its status`);
    /* Retained copy is still speakable the day a measurement lands. */
    for (const language of LANGUAGES) {
      assert.ok(instructionPool(entry.category, language).length > 0);
    }
  }
});
