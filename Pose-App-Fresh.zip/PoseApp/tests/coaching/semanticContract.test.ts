/**
 * tests/coaching/semanticContract.test.ts — Part 4.1: THE CANONICAL
 * SEMANTIC COACHING CONTRACT.
 *
 * The permanent architecture under test:
 *
 *   POSE ANALYSIS
 *      ↓ PoseAnalysisDecision        (geometry, thresholds, hysteresis)
 *   SEMANTIC COACHING STATE          (CoachingState — the ONE contract)
 *      ↓
 *   LANGUAGE / PRESENTATION CHOICE
 *      ↓
 *   PHRASE SELECTION
 *      ↓
 *   TTS                              (speech execution only)
 *
 * These tests assert TRACEABILITY, not wording:
 *
 *   mathematical decision → direction → severity → category → semantic state
 *
 * Nothing here needs Supabase, the network, a production reference image, a
 * physical device or real speech playback. Fixed fixtures, injected random
 * source, injected clock, synchronous assertions only.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, join } from "node:path";

import {
  CORRECTION_PERSISTENCE_FRAMES,
  PERFECT_PERSISTENCE_FRAMES,
  createPoseAnalysisEngine,
  decisionToGuidance,
  type AnalysisReferenceInput,
  type AnalysisUnavailableReason,
  type PoseAnalysisDecision,
} from "../../shared/ml/analysis";
import {
  coachingCategoryFor,
  createCoachingSpeechPlanner,
  decisionToCoachingState,
  intensityForSeverity,
  selectCoachingPhrase,
} from "../../shared/coaching";
import {
  guidanceSeverityFor,
  jointDirectiveFor,
  JOINT_GUIDANCE_RULES,
} from "../../shared/ml/guidanceGenerator";
import { instructionPool } from "../../shared/constants/poseInstructions";
import { MATCH_JOINTS, type PoseLandmark } from "../../shared/ml/poseLandmarks";
import {
  bodyLandmarks,
  referenceInput,
  referenceWithOffsets,
} from "../analysis/fixtures";

/**
 * The suite is compiled to .test-build/ before it runs, so __dirname points
 * at the emitted JS. Walk up to the first ancestor that actually holds the
 * SOURCE tree — the boundary tests below read .ts files, not emitted output.
 */
function findRepoRoot(): string {
  let current = __dirname;
  for (let depth = 0; depth < 8; depth += 1) {
    if (
      existsSync(join(current, "shared", "coaching", "types.ts")) &&
      existsSync(join(current, "mobile", "src", "core", "voice", "ttsService.ts"))
    ) {
      return current;
    }
    const parent = dirname(current);
    if (parent === current) break;
    current = parent;
  }
  throw new Error("repository source root not found from " + __dirname);
}

const REPO_ROOT = findRepoRoot();

function engineWith(reference: AnalysisReferenceInput | null) {
  return createPoseAnalysisEngine({ reference, sessionId: "contract-test" });
}

function settle(
  engine: ReturnType<typeof createPoseAnalysisEngine>,
  landmarks: readonly PoseLandmark[] | null,
  frames: number,
): PoseAnalysisDecision {
  let decision = engine.analyzeFrame(landmarks);
  for (let index = 1; index < frames; index += 1) {
    decision = engine.analyzeFrame(landmarks);
  }
  return decision;
}

/** Settle a held body against a reference offset by `offsets` degrees. */
function correctionFor(offsets: Readonly<Record<string, number>>): {
  readonly decision: PoseAnalysisDecision;
  readonly body: readonly PoseLandmark[];
} {
  const body = bodyLandmarks();
  const engine = engineWith(referenceInput(referenceWithOffsets(body, offsets)));
  return {
    decision: settle(engine, body, CORRECTION_PERSISTENCE_FRAMES + 2),
    body,
  };
}

/* ==================================================================== *
 * 1 · PERFECT IS AN EXPLICIT, FIRST-CLASS STATE
 * ==================================================================== */

test("PERFECT is explicit: its own kind, its own token, no fake correction", () => {
  const body = bodyLandmarks();
  const engine = engineWith(referenceInput(referenceWithOffsets(body, {})));
  const decision = settle(engine, body, PERFECT_PERSISTENCE_FRAMES + 2);

  assert.equal(decision.kind, "perfect");

  const state = decisionToCoachingState(decision);
  assert.equal(state.kind, "perfect");
  assert.equal(state.token, "PERFECT");
  assert.equal(state.category, "final_pose_good");
  assert.equal(state.measurementId, null);
  assert.equal(state.direction, "none");
  assert.equal(state.severity, null);
  assert.equal(state.unavailableReason, null);
  assert.equal(state.speakable, true);
  /* A perfect frame still carries a real belief, not a hardcoded 1. */
  assert.ok(state.confidence > 0 && state.confidence <= 1);

  const phrase = selectCoachingPhrase(state, "en", { random: () => 0 });
  assert.ok(phrase !== null);
  assert.equal(phrase?.category, "final_pose_good");
});

/* ==================================================================== *
 * 2 · A CORRECTION REACHES THE CONTRACT WITH EVERYTHING INTACT
 * ==================================================================== */

test("a correction becomes a canonical semantic state, not a number", () => {
  const { decision } = correctionFor({ leftElbow: 30 });
  assert.equal(decision.kind, "correction");

  const state = decisionToCoachingState(decision);
  assert.equal(state.kind, "correction");
  assert.equal(state.measurementId, "leftElbow");
  assert.equal(state.speakable, true);
  assert.equal(state.unavailableReason, null);

  /* The token is a canonical, comparable identifier — the next layer receives
     "LEFT_ELBOW_DECREASE", never "the elbow was 30° above reference". */
  assert.equal(state.token, decision.state);
  assert.match(state.token, /^[A-Z0-9_]+$/);
  assert.ok(state.token.includes("ELBOW"));

  /* No geometry crosses the boundary. */
  const leaked = Object.values(state).filter(
    (value) => typeof value === "number" && !Number.isInteger(value) && value > 1,
  );
  assert.deepEqual(leaked, []);
});

/* ==================================================================== *
 * 3 · DIRECTION IS PRESERVED (never re-derived downstream)
 * ==================================================================== */

test("direction preservation: live > reference ⇒ decrease, live < reference ⇒ increase", () => {
  /* referenceWithOffsets: reference = live − offset, so a POSITIVE offset
     means the live angle is LARGER than the reference. */
  const larger = correctionFor({ leftElbow: 30 }).decision;
  assert.equal(larger.correction?.direction, "decrease");
  assert.equal(decisionToCoachingState(larger).direction, "decrease");

  const smaller = correctionFor({ leftElbow: -30 }).decision;
  assert.equal(smaller.correction?.direction, "increase");
  assert.equal(decisionToCoachingState(smaller).direction, "increase");

  /* The two directions must not collapse onto the same coaching category. */
  const upCategory = decisionToCoachingState(smaller).category;
  const downCategory = decisionToCoachingState(larger).category;
  assert.ok(upCategory !== null && downCategory !== null);
  assert.notEqual(upCategory, downCategory);
});

test("direction survives the presentation contract verbatim", () => {
  for (const offset of [30, -30]) {
    const { decision } = correctionFor({ leftKnee: offset });
    const guidance = decisionToGuidance(decision);
    assert.ok(guidance !== null);
    assert.ok(guidance?.semantics !== null);
    /* Carried, not recomputed from `angleDiffs`. */
    assert.equal(guidance?.semantics?.direction, decision.correction?.direction);
    assert.equal(guidance?.semantics?.state, decision.state);
    /* And the rendered copy is the copy THAT direction selects. */
    const directive = jointDirectiveFor(
      decision.correction?.measurementId ?? "",
      decision.correction?.direction ?? "none",
    );
    assert.equal(guidance?.text, directive?.text);
    assert.equal(guidance?.arrowDirection, directive?.arrowDirection);
  }
});

/* ==================================================================== *
 * 4 · SEVERITY IS PRESERVED (produced once, carried, never recomputed)
 * ==================================================================== */

test("severity preservation: the engine ladder reaches the semantic state unchanged", () => {
  const minor = correctionFor({ leftElbow: 15 }).decision;
  assert.equal(minor.correction?.severity, "minor");
  const minorState = decisionToCoachingState(minor);
  assert.equal(minorState.severity, "minor");
  assert.equal(minorState.intensity, intensityForSeverity("minor"));
  assert.equal(minorState.intensity, "gentle");

  const major = correctionFor({ leftElbow: 45 }).decision;
  assert.equal(major.correction?.severity, "major");
  const majorState = decisionToCoachingState(major);
  assert.equal(majorState.severity, "major");
  assert.equal(majorState.intensity, "firm");
});

test("severity is not lost by the downstream presentation interface", () => {
  for (const offset of [15, 45]) {
    const { decision } = correctionFor({ rightElbow: offset });
    const guidance = decisionToGuidance(decision);
    const engineSeverity = decision.correction?.severity;
    assert.ok(guidance !== null && engineSeverity !== undefined);
    /* The full ladder is carried … */
    assert.equal(guidance?.semantics?.analysisSeverity, engineSeverity);
    /* … and the coarse UI band is DERIVED from it by the one mapper, so the
       two can never be computed independently and drift. */
    assert.equal(guidance?.severity, guidanceSeverityFor(engineSeverity));
  }
});

test("confidence is preserved from the engine decision", () => {
  const { decision } = correctionFor({ rightKnee: 30 });
  const state = decisionToCoachingState(decision);
  assert.equal(state.confidence, decision.correction?.confidence);
  assert.ok(state.confidence > 0 && state.confidence <= 1);
  assert.equal(
    decisionToGuidance(decision)?.semantics?.confidence,
    decision.correction?.confidence,
  );
});

/* ==================================================================== *
 * 5 · UNAVAILABLE / INVALID / INCOMPATIBLE NEVER BECOME CORRECTIONS
 * ==================================================================== */

/** Every way the engine can refuse, and the reason it must report. */
const REFUSALS: ReadonlyArray<{
  readonly label: string;
  readonly reference: AnalysisReferenceInput | null;
  readonly reason: AnalysisUnavailableReason;
}> = [
  {
    label: "no reference bound at all",
    reference: null,
    reason: "reference-unavailable",
  },
  {
    label: "reference with no identity",
    reference: { ...referenceInput({ leftElbow: 90, rightElbow: 90 }), referenceId: "" },
    reason: "reference-invalid",
  },
  {
    label: "reference angle outside the plausible band",
    reference: referenceInput({ leftElbow: 900, rightElbow: 90, leftKnee: 90 }),
    reason: "reference-invalid",
  },
  {
    label: "reference written under unknown measurement semantics",
    reference: referenceInput(
      { leftElbow: 90, rightElbow: 90, leftKnee: 90 },
      { measurementVersion: 99 },
    ),
    reason: "reference-incompatible",
  },
  {
    label: "reference carrying too few measurements to compare",
    reference: referenceInput({ leftElbow: 90 }),
    reason: "reference-incomplete",
  },
];

for (const refusal of REFUSALS) {
  test(`${refusal.label} → UNAVAILABLE:${refusal.reason}, never a correction`, () => {
    const engine = engineWith(refusal.reference);
    assert.equal(engine.referenceState, "unusable");

    const decision = settle(engine, bodyLandmarks(), 8);
    assert.equal(decision.kind, "unavailable");
    assert.equal(decision.unavailable?.reason, refusal.reason);
    assert.equal(decision.correction, null);

    const state = decisionToCoachingState(decision);
    assert.equal(state.kind, "unavailable");
    assert.equal(state.token, `UNAVAILABLE:${refusal.reason}`);
    assert.equal(state.unavailableReason, refusal.reason);
    assert.equal(state.category, null);
    assert.equal(state.measurementId, null);
    assert.equal(state.direction, "none");
    assert.equal(state.severity, null);
    assert.equal(state.speakable, false);

    /* No phrase, no plan, no presentation correction — three independent
       doors, all shut. A missing reference cannot become fake feedback. */
    assert.equal(selectCoachingPhrase(state, "en"), null);
    assert.equal(selectCoachingPhrase(state, "hi"), null);
    assert.equal(
      createCoachingSpeechPlanner().plan({ state, nowMs: 10_000, isSpeaking: false })
        .speak,
      false,
    );
    assert.equal(decisionToGuidance(decision), null);
  });
}

test("each refusal keeps its OWN token — they are not flattened together", () => {
  const tokens = new Set(
    REFUSALS.map((refusal) =>
      decisionToCoachingState(
        settle(engineWith(refusal.reference), bodyLandmarks(), 3),
      ).token,
    ),
  );
  /* reference-unavailable / -invalid / -incompatible / -incomplete stay
     distinguishable all the way to the language layer. */
  assert.equal(tokens.size, 4);
});

test("ANALYSIS_UNAVAILABLE: a judgeable reference with no judgeable body stays silent", () => {
  const body = bodyLandmarks();
  const engine = engineWith(referenceInput(referenceWithOffsets(body, {})));

  /* No body in the frame at all. */
  const empty = settle(engine, [], 3);
  assert.equal(empty.kind, "unavailable");
  assert.equal(empty.unavailable?.reason, "no-live-pose");
  const emptyState = decisionToCoachingState(empty);
  assert.equal(emptyState.speakable, false);
  assert.equal(emptyState.token, "UNAVAILABLE:no-live-pose");

  /* A body present but tracked too weakly to coach from. */
  const faint = settle(engine, bodyLandmarks({ visibility: 0.35 }), 3);
  assert.equal(faint.kind, "unavailable");
  assert.ok(
    faint.unavailable?.reason === "low-confidence" ||
      faint.unavailable?.reason === "insufficient-measurements",
  );
  assert.equal(decisionToCoachingState(faint).speakable, false);
});

/* ==================================================================== *
 * 6 · CATEGORY MAPPING IS ONE TABLE, REACHED ONE WAY
 * ==================================================================== */

test("category mapping agrees with the one directive resolver for every joint", () => {
  let checked = 0;
  for (const joint of MATCH_JOINTS) {
    const rule = JOINT_GUIDANCE_RULES[joint.key];
    if (rule === undefined) continue;
    assert.equal(
      coachingCategoryFor(joint.key, "increase"),
      rule.liveLessThanRef.voiceCategory,
    );
    assert.equal(
      coachingCategoryFor(joint.key, "decrease"),
      rule.liveGreaterThanRef.voiceCategory,
    );
    assert.equal(
      coachingCategoryFor(joint.key, "increase"),
      jointDirectiveFor(joint.key, "increase")?.voiceCategory,
    );
    checked += 1;
  }
  assert.ok(checked >= 8, "every shipped match joint must be covered");
});

test("no joint collapses its two directions onto one spoken category", () => {
  /* Unit 32 regression. The knee rules used to point BOTH directions at
     `leg_left`/`leg_right`, whose pools mix "straighten" and "bend" lines —
     so a correction the engine had decided precisely could be spoken as its
     opposite. Direction must survive all the way into the phrase pool. */
  for (const joint of MATCH_JOINTS) {
    const rule = JOINT_GUIDANCE_RULES[joint.key];
    if (rule === undefined) continue;
    assert.notEqual(
      rule.liveLessThanRef.voiceCategory,
      rule.liveGreaterThanRef.voiceCategory,
      `${joint.key} must not speak the same category for both directions`,
    );
    /* And the two pools must share no line, in either language. */
    for (const language of ["en", "hi"] as const) {
      const up = new Set(instructionPool(rule.liveLessThanRef.voiceCategory, language));
      for (const line of instructionPool(rule.liveGreaterThanRef.voiceCategory, language)) {
        assert.ok(
          !up.has(line),
          `${joint.key}/${language}: "${line}" is reachable for both directions`,
        );
      }
    }
  }
});

test("category mapping refuses to invent: unknown joint or no direction ⇒ null", () => {
  assert.equal(coachingCategoryFor("thirdElbow", "increase"), null);
  assert.equal(coachingCategoryFor("leftElbow", "none"), null);
  assert.equal(jointDirectiveFor("thirdElbow", "increase"), null);
  assert.equal(jointDirectiveFor("leftElbow", "none"), null);
});

/* ==================================================================== *
 * 7 · SEMANTIC STATE STABILITY
 * ==================================================================== */

test("semantic state stability: a held pose yields one stable token, not churn", () => {
  const body = bodyLandmarks();
  const engine = engineWith(referenceInput(referenceWithOffsets(body, { leftElbow: 30 })));

  const tokens: string[] = [];
  let previousFrames = -1;
  let monotonic = true;
  for (let frame = 0; frame < 12; frame += 1) {
    const state = decisionToCoachingState(engine.analyzeFrame(body));
    if (state.kind !== "correction") continue;
    tokens.push(state.token);
    if (state.stableFrames < previousFrames) monotonic = false;
    previousFrames = state.stableFrames;
  }

  assert.ok(tokens.length > 0, "a held correction must eventually be reported");
  assert.equal(new Set(tokens).size, 1, "the token must not flap while held");
  assert.ok(monotonic, "stableFrames must not go backwards while the state holds");
});

test("semantic state stability: the planner reads stability, it does not recompute it", () => {
  const body = bodyLandmarks();
  const engine = engineWith(referenceInput(referenceWithOffsets(body, { leftKnee: 30 })));
  const planner = createCoachingSpeechPlanner();

  let spoken = 0;
  let nowMs = 0;
  for (let frame = 0; frame < 40; frame += 1) {
    nowMs += 66; // ~15 fps, the shipped ML budget
    const state = decisionToCoachingState(engine.analyzeFrame(body));
    if (planner.plan({ state, nowMs, isSpeaking: false }).speak) spoken += 1;
  }
  /* ~2.6 s of an unfixed correction: said once, then reminded — never per frame. */
  assert.ok(spoken >= 1 && spoken <= 2, `expected 1–2 utterances, got ${spoken}`);
});

/* ==================================================================== *
 * 8 · THE BOUNDARY ITSELF (static, deterministic — no device needed)
 * ==================================================================== */

function tsFilesUnder(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) {
      out.push(...tsFilesUnder(full));
    } else if (entry.endsWith(".ts") || entry.endsWith(".tsx")) {
      out.push(full);
    }
  }
  return out;
}

test("pose mathematics never reaches TTS: no speech engine anywhere in shared/", () => {
  const files = tsFilesUnder(join(REPO_ROOT, "shared"));
  /* Guard against a vacuous pass if the scan root ever moves. */
  assert.ok(files.length > 20, `expected the shared source tree, saw ${files.length}`);
  const offenders: string[] = [];
  for (const file of files) {
    const source = readFileSync(file, "utf8");
    /* Comments legitimately mention the TTS layer; imports and calls must not
       exist. Strip block/line comments before scanning. */
    const code = source
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/^\s*\/\/.*$/gm, "");
    if (
      /from\s+['"]expo-speech['"]/.test(code) ||
      /require\(['"]expo-speech['"]\)/.test(code) ||
      /\bSpeech\s*\.\s*speak\s*\(/.test(code)
    ) {
      offenders.push(file.slice(REPO_ROOT.length + 1));
    }
  }
  assert.deepEqual(offenders, []);
});

test("the TTS layer never calculates pose geometry", () => {
  const tts = readFileSync(
    join(REPO_ROOT, "mobile", "src", "core", "voice", "ttsService.ts"),
    "utf8",
  );
  const code = tts
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "");

  /* No geometry, no thresholds, no priority, no severity derivation. */
  for (const forbidden of [
    "jointAngle",
    "measureLiveFrame",
    "compareFrame",
    "rankCandidates",
    "analyzeFrame",
    "JOINT_GUIDANCE_RULES",
    "GUIDANCE_THRESHOLDS",
    "Math.atan2",
    "Math.acos",
    "poseLandmarks",
    "MATCH_JOINTS",
  ]) {
    assert.ok(
      !code.includes(forbidden),
      `ttsService must not reference ${forbidden} — that is analysis, not speech`,
    );
  }
  /* It speaks what the semantic layer decided. */
  assert.ok(code.includes("selectCoachingPhrase"));
  assert.ok(code.includes("createCoachingSpeechPlanner"));
  assert.ok(code.includes("CoachingState"));
});

test("the coaching layer holds no phrase text and no speech API", () => {
  for (const file of tsFilesUnder(join(REPO_ROOT, "shared", "coaching"))) {
    const code = readFileSync(file, "utf8")
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/^\s*\/\/.*$/gm, "");
    assert.ok(!/Speech\s*\./.test(code), `${file} must not touch a speech API`);
    /* Phrase copy lives in the phrase bank, never in the semantic layer. */
    assert.ok(
      !/["'`][A-Z][a-z]+ your /.test(code),
      `${file} must not hardcode instructor copy`,
    );
  }
});
