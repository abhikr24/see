/**
 * tests/coaching/speechTiming.test.ts — Unit 34 (Part 4.3).
 *
 *   SEMANTIC COACHING STATE → SPEECH DECISION → (TTS OUTPUT)
 *
 * These tests cover ONE layer: "should the coach speak now?". They say
 * nothing about which words are chosen (that is
 * tests/coaching/phraseSelection.test.ts) and nothing about whether a state
 * is real (that is tests/analysis/*.test.ts).
 *
 * DETERMINISM CONTRACT
 *   · A FAKE CLOCK drives every timer. No test sleeps, no test reads
 *     Date.now(), no test depends on machine speed — `clock.advance(ms)` is
 *     the only way time moves, so these cases cannot become flaky.
 *   · Semantic states are hand-built literals, so the pose engine is not in
 *     the loop and a cadence regression cannot hide behind pose noise.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";

import {
  DEFAULT_SPEECH_CADENCE,
  createCoachingSpeechPlanner,
  type CoachingSpeechPlanner,
  type CoachingState,
  type SpeechPlan,
} from "../../shared/coaching";

/* ───────────────────────── source-tree location ─────────────────────── */

/**
 * The suite is compiled to .test-build/ before it runs, so __dirname points
 * at the emitted JS. The boundary tests at the bottom read .ts SOURCE, so
 * walk up to the first ancestor that actually holds it.
 */
function findRepoRoot(): string {
  let current = __dirname;
  for (let depth = 0; depth < 8; depth += 1) {
    if (
      existsSync(join(current, "shared", "coaching", "speechPlanner.ts")) &&
      existsSync(join(current, "mobile", "src", "core", "voice", "ttsService.ts"))
    ) {
      return current;
    }
    const parent = dirname(current);
    if (parent === current) break;
    current = parent;
  }
  throw new Error("repository source root not found from " + __dirname);
}

const REPO_ROOT = findRepoRoot();

/* ───────────────────────────── fake clock ───────────────────────────── */

interface FakeClock {
  now(): number;
  advance(ms: number): number;
}

function fakeClock(startMs = 0): FakeClock {
  let now = startMs;
  return {
    now: () => now,
    advance: (ms: number) => {
      now += ms;
      return now;
    },
  };
}

/** One ML frame at the shipped 15 fps budget. */
const FRAME_MS = 66;

/* ─────────────────────────── state builders ─────────────────────────── */

function correction(token: string, stableFrames = 3): CoachingState {
  return {
    kind: "correction",
    token,
    category: "hand_left_straighten",
    measurementId: "leftElbow",
    direction: "increase",
    severity: "major",
    intensity: "firm",
    confidence: 0.9,
    stableFrames,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
  };
}

function perfect(stableFrames = 4): CoachingState {
  return {
    kind: "perfect",
    token: "PERFECT",
    category: "final_pose_good",
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0.95,
    stableFrames,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
  };
}

function unavailable(
  reason: CoachingState["unavailableReason"] = "reference-unavailable",
): CoachingState {
  return {
    kind: "unavailable",
    token: `UNAVAILABLE:${String(reason)}`,
    category: null,
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0,
    stableFrames: 0,
    heldByHysteresis: false,
    unavailableReason: reason,
    speakable: false,
  };
}

function evaluating(): CoachingState {
  return {
    kind: "evaluating",
    token: "EVALUATING",
    category: null,
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0.4,
    stableFrames: 1,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: false,
  };
}

/* ────────────────────────────── harness ─────────────────────────────── */

interface Utterance {
  readonly atMs: number;
  readonly token: string;
  readonly reason: SpeechPlan["reason"];
}

/**
 * Feeds a state to the planner for `frames` consecutive ML frames, moving the
 * fake clock one frame at a time, and records everything it authorized.
 */
function run(
  planner: CoachingSpeechPlanner,
  clock: FakeClock,
  state: CoachingState,
  frames: number,
  spoken: Utterance[],
  options?: { readonly isSpeaking?: boolean },
): void {
  for (let frame = 0; frame < frames; frame += 1) {
    const nowMs = clock.now();
    const plan = planner.plan({
      state,
      nowMs,
      isSpeaking: options?.isSpeaking ?? false,
    });
    if (plan.speak) spoken.push({ atMs: nowMs, token: plan.token, reason: plan.reason });
    clock.advance(FRAME_MS);
  }
}

/* ==================================================================== *
 * 1 · A REPEATED STABLE STATE IS SAID ONCE, NOT PER FRAME
 * ==================================================================== */

test("CORRECTION_A · CORRECTION_A · CORRECTION_A → one instruction, not three", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];
  const a = correction("LEFT_ELBOW_INCREASE");

  run(planner, clock, a, 3, spoken);

  assert.equal(spoken.length, 1, "three identical frames must yield one line");
  assert.equal(spoken[0]?.reason, "state-entered");
});

test("a held correction across a full second of frames is spoken exactly once", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  /* ~2 s of an unfixed correction, well inside the repeat interval. */
  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 30, spoken);

  assert.equal(spoken.length, 1);
});

test("an uncorrected pose is REMINDED at the repeat interval, never nagged", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];
  const a = correction("LEFT_ELBOW_INCREASE");

  /* ~13 s held. */
  run(planner, clock, a, 200, spoken);

  assert.ok(spoken.length >= 2, "a long-held error must eventually be restated");
  assert.ok(spoken.length <= 4, `expected a patient cadence, got ${spoken.length} lines`);
  for (const line of spoken.slice(1)) assert.equal(line.reason, "repeat-interval");
  for (let index = 1; index < spoken.length; index += 1) {
    const gap = (spoken[index]?.atMs ?? 0) - (spoken[index - 1]?.atMs ?? 0);
    assert.ok(
      gap >= DEFAULT_SPEECH_CADENCE.repeatIntervalMs,
      `reminder gap ${gap}ms is shorter than the repeat interval`,
    );
  }
});

/* ==================================================================== *
 * 2 · A GENUINE TRANSITION IS ALLOWED A NEW INSTRUCTION
 * ==================================================================== */

test("CORRECTION_A → CORRECTION_B → a new instruction once cadence permits", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 1, spoken);
  assert.equal(spoken.length, 1);

  /* Immediately after: the new state is real, but the coach has just
     spoken — latency guard, not silence. */
  clock.advance(DEFAULT_SPEECH_CADENCE.minGapMs - FRAME_MS - 1);
  const tooSoon = planner.plan({
    state: correction("RIGHT_KNEE_DECREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(tooSoon.speak, false);
  assert.equal(tooSoon.reason, "min-gap");
  assert.equal(tooSoon.isTransition, true);

  /* The FIRST change of instruction is prompt — only the plain floor. */
  clock.advance(FRAME_MS * 4);
  const allowed = planner.plan({
    state: correction("RIGHT_KNEE_DECREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.ok(
    clock.now() < DEFAULT_SPEECH_CADENCE.repeatIntervalMs,
    "sanity: this is well inside the repeat interval",
  );
  assert.equal(allowed.speak, true);
  assert.equal(allowed.reason, "state-changed");
  assert.equal(allowed.isTransition, true);
  assert.equal(allowed.token, "RIGHT_KNEE_DECREASE");
});

test("a new instruction does not wait out the repeat interval of the old one", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 20, spoken);
  run(planner, clock, correction("RIGHT_KNEE_DECREASE"), 20, spoken);

  assert.equal(spoken.length, 2);
  const gap = (spoken[1]?.atMs ?? 0) - (spoken[0]?.atMs ?? 0);
  assert.ok(
    gap < DEFAULT_SPEECH_CADENCE.repeatIntervalMs,
    "a real change must be faster than the repeat timer",
  );
  assert.ok(gap >= DEFAULT_SPEECH_CADENCE.minGapMs);
});

/* ==================================================================== *
 * 3 · PERFECT IS TRANSITION-AWARE
 * ==================================================================== */

test("CORRECTION_A → PERFECT → exactly one controlled positive response", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 20, spoken);
  run(planner, clock, perfect(), 20, spoken);

  assert.equal(spoken.length, 2);
  assert.equal(spoken[0]?.token, "LEFT_ELBOW_INCREASE");
  assert.equal(spoken[1]?.token, "PERFECT");
  assert.equal(spoken[1]?.reason, "state-changed");
});

test("PERFECT · PERFECT · PERFECT … → no repeated speech, for minutes", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  /* 1200 frames ≈ 80 s of a held perfect pose. */
  run(planner, clock, perfect(), 1200, spoken);

  assert.equal(spoken.length, 1, "perfect must never become a chant");
  const held = planner.plan({ state: perfect(), nowMs: clock.now(), isSpeaking: false });
  assert.equal(held.speak, false);
  assert.equal(held.reason, "already-said");
});

test("a single evaluating flicker inside a perfect hold does not re-trigger praise", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, perfect(), 10, spoken);
  run(planner, clock, evaluating(), 1, spoken); // one dropped/churn frame
  run(planner, clock, perfect(), 40, spoken);

  assert.equal(spoken.length, 1, "flicker must not restart the perfect episode");
});

test("leaving perfect for a real correction and coming back is a NEW episode", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, perfect(), 20, spoken);
  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 60, spoken);
  run(planner, clock, perfect(), 40, spoken);

  assert.deepEqual(
    spoken.map((line) => line.token),
    ["PERFECT", "LEFT_ELBOW_INCREASE", "PERFECT"],
  );
});

test("perfect flickering against a correction cannot chant", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  /* Worst case: the engine alternates every ~4 frames for ~8 s. */
  for (let cycle = 0; cycle < 30; cycle += 1) {
    run(planner, clock, perfect(), 4, spoken);
    run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 4, spoken);
  }

  const elapsedSec = clock.now() / 1000;
  assert.ok(
    spoken.length <= Math.ceil(elapsedSec / 2),
    `flapping produced ${spoken.length} utterances in ${elapsedSec.toFixed(1)}s`,
  );

  /* Praise specifically must respect its own cooldown: an unspoken
     correction flicker between two perfect runs cannot unlock it early. */
  const praise = spoken.filter((line) => line.token === "PERFECT");
  assert.ok(praise.length >= 1, "the pose IS reaching perfect; say so at least once");
  for (let index = 1; index < praise.length; index += 1) {
    const gap = (praise[index]?.atMs ?? 0) - (praise[index - 1]?.atMs ?? 0);
    assert.ok(
      gap >= DEFAULT_SPEECH_CADENCE.alternationCooldownMs,
      `praise repeated after only ${gap}ms`,
    );
  }
});

/* ==================================================================== *
 * 4 · A → B → A DOES NOT CONFUSE THE COACH
 * ==================================================================== */

test("A → B → A: the returning correction is damped, not re-announced instantly", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const a = correction("LEFT_ELBOW_INCREASE");
  const b = correction("RIGHT_KNEE_DECREASE");

  /* t = 0 · A is new. */
  assert.equal(planner.plan({ state: a, nowMs: clock.now(), isSpeaking: false }).speak, true);

  /* t = 1000 · B is a real change and is coached promptly. */
  clock.advance(1_000);
  assert.equal(planner.plan({ state: b, nowMs: clock.now(), isSpeaking: false }).speak, true);

  /* t = 2000 · A comes back. The plain gap has passed, but A itself was
     said only 2 s ago — this is oscillation, not progress. */
  clock.advance(1_000);
  const damped = planner.plan({ state: a, nowMs: clock.now(), isSpeaking: false });
  assert.equal(damped.speak, false);
  assert.equal(
    damped.reason,
    "recently-said",
    "the cooldown of the RETURNING token must be what blocks it",
  );
  assert.ok(clock.now() - 0 < DEFAULT_SPEECH_CADENCE.alternationCooldownMs);
});

test("A → B → A: the returning correction IS eventually spoken, not lost", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 16, spoken);
  run(planner, clock, correction("RIGHT_KNEE_DECREASE"), 16, spoken);
  /* A comes back and STAYS: that is a real problem, so it must be coached. */
  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 90, spoken); // ~6 s

  const tokens = spoken.map((line) => line.token);
  assert.equal(tokens[0], "LEFT_ELBOW_INCREASE");
  assert.equal(tokens[1], "RIGHT_KNEE_DECREASE");
  assert.equal(tokens[2], "LEFT_ELBOW_INCREASE");
  assert.ok(tokens.length >= 3, "a persistent returning error must be coached");
});

test("fast A/B ping-pong for 20 s stays inside a human speaking rate", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  for (let cycle = 0; cycle < 40; cycle += 1) {
    run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 4, spoken);
    run(planner, clock, correction("RIGHT_KNEE_DECREASE"), 4, spoken);
  }

  const elapsedSec = clock.now() / 1000;
  assert.ok(elapsedSec > 20, "sanity: the fake clock advanced");
  assert.ok(
    spoken.length <= Math.ceil(elapsedSec / 2),
    `${spoken.length} utterances in ${elapsedSec.toFixed(1)}s is babble`,
  );
  for (let index = 1; index < spoken.length; index += 1) {
    const gap = (spoken[index]?.atMs ?? 0) - (spoken[index - 1]?.atMs ?? 0);
    assert.ok(gap >= DEFAULT_SPEECH_CADENCE.minGapMs, `gap of only ${gap}ms`);
  }
});

/* ==================================================================== *
 * 5 · NOTHING JUDGEABLE ⇒ NOTHING SPOKEN
 * ==================================================================== */

test("UNAVAILABLE → UNAVAILABLE → no correction speech, ever", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, unavailable(), 300, spoken);

  assert.equal(spoken.length, 0);
  const plan = planner.plan({
    state: unavailable(),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(plan.speak, false);
  assert.equal(plan.reason, "not-speakable");
});

test("every non-speakable reason is silent, whatever the clock says", () => {
  const planner = createCoachingSpeechPlanner();
  const reasons: CoachingState["unavailableReason"][] = [
    "no-live-pose",
    "low-confidence",
    "reference-unavailable",
    "reference-invalid",
    "reference-incomplete",
    "reference-incompatible",
    "insufficient-measurements",
  ];
  for (const reason of reasons) {
    const plan = planner.plan({
      state: unavailable(reason),
      nowMs: 10_000_000,
      isSpeaking: false,
    });
    assert.equal(plan.speak, false, `${String(reason)} spoke`);
    assert.equal(plan.reason, "not-speakable");
  }
  assert.equal(
    planner.plan({ state: evaluating(), nowMs: 20_000_000, isSpeaking: false }).speak,
    false,
  );
});

test("an unstable state is never spoken, however long it has been silent", () => {
  const planner = createCoachingSpeechPlanner();
  const plan = planner.plan({
    state: correction("LEFT_ELBOW_INCREASE", 0),
    nowMs: 60_000,
    isSpeaking: false,
  });
  assert.equal(plan.speak, false);
  assert.equal(plan.reason, "unstable");
});

test("a SUSTAINED loss of the body lets the recovered state speak promptly", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 5, spoken);
  assert.equal(spoken.length, 1);

  /* The user walks out of frame for ~1.3 s. */
  run(planner, clock, unavailable("no-live-pose"), 20, spoken);
  /* …and walks back in with the same problem: this is a new coaching
     episode, so it must not wait out the old repeat interval. */
  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 3, spoken);

  assert.equal(spoken.length, 2);
  assert.equal(spoken[1]?.reason, "state-entered");
  const gap = (spoken[1]?.atMs ?? 0) - (spoken[0]?.atMs ?? 0);
  assert.ok(
    gap < DEFAULT_SPEECH_CADENCE.repeatIntervalMs,
    "recovery must not wait out a stale interval",
  );
});

test("a ONE-FRAME churn gap cannot be used to bypass the cadence gates", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  /* The classic spam vector: correction, dropped frame, correction, … */
  for (let cycle = 0; cycle < 100; cycle += 1) {
    run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 1, spoken);
    run(planner, clock, evaluating(), 1, spoken);
  }

  const elapsedSec = clock.now() / 1000;
  assert.ok(
    spoken.length <= Math.ceil(elapsedSec / 4),
    `${spoken.length} utterances in ${elapsedSec.toFixed(1)}s of flicker`,
  );
});

/* ==================================================================== *
 * 6 · OVERLAP: ONE VOICE AT A TIME
 * ==================================================================== */

test("a new state cannot chop an utterance that just started", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();

  assert.equal(
    planner.plan({
      state: correction("LEFT_ELBOW_INCREASE"),
      nowMs: clock.now(),
      isSpeaking: false,
    }).speak,
    true,
  );

  /* Still mid-utterance, a different state arrives past the min gap. */
  clock.advance(DEFAULT_SPEECH_CADENCE.minGapMs + FRAME_MS);
  const blocked = planner.plan({
    state: correction("RIGHT_KNEE_DECREASE"),
    nowMs: clock.now(),
    isSpeaking: true,
  });
  assert.equal(blocked.speak, false);
  assert.equal(blocked.reason, "speaking");

  /* Past the interrupt grace it may replace the line — explicitly. */
  clock.advance(DEFAULT_SPEECH_CADENCE.interruptGraceMs);
  const replaces = planner.plan({
    state: correction("RIGHT_KNEE_DECREASE"),
    nowMs: clock.now(),
    isSpeaking: true,
  });
  assert.equal(replaces.speak, true);
  assert.equal(replaces.interrupts, true, "the TTS layer must stop the old line first");
});

test("the coach never talks over itself with the SAME instruction", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  /* The device is reported as permanently busy. */
  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 1, spoken);
  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 300, spoken, {
    isSpeaking: true,
  });

  assert.equal(spoken.length, 1, "a busy engine must never be handed a second copy");
});

test("an externally spoken line (capture cue) is respected by the coach", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();

  planner.noteExternalSpeech(clock.now()); // "…taking the photo now"
  clock.advance(FRAME_MS * 2);

  const tooSoon = planner.plan({
    state: correction("LEFT_ELBOW_INCREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(tooSoon.speak, false);
  assert.equal(tooSoon.reason, "min-gap");

  clock.advance(DEFAULT_SPEECH_CADENCE.minGapMs);
  const allowed = planner.plan({
    state: correction("LEFT_ELBOW_INCREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(allowed.speak, true);
  assert.equal(
    allowed.reason,
    "state-entered",
    "an external cue must not steal the coaching token",
  );
});

/* ==================================================================== *
 * 7 · THE LAYER OWNS TIMING ONLY
 * ==================================================================== */

test("reset() clears cadence memory for a new session", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("LEFT_ELBOW_INCREASE"), 5, spoken);
  planner.reset();
  const after = planner.plan({
    state: correction("LEFT_ELBOW_INCREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(after.speak, true);
  assert.equal(after.reason, "state-entered");
});

test("the decision is a pure function of state identity, clock and busy-ness", () => {
  /* Two planners fed byte-identical inputs must agree, always. */
  const left = createCoachingSpeechPlanner();
  const right = createCoachingSpeechPlanner();
  const script: CoachingState[] = [
    evaluating(),
    correction("A"),
    correction("A"),
    correction("B"),
    perfect(),
    perfect(),
    unavailable(),
    correction("A"),
  ];
  let nowMs = 0;
  for (const state of script) {
    nowMs += 400;
    assert.deepEqual(
      left.plan({ state, nowMs, isSpeaking: false }),
      right.plan({ state, nowMs, isSpeaking: false }),
    );
  }
});

test("severity and geometry do not change the TIMING decision", () => {
  /* Same token, different severity/confidence ⇒ same cadence. The phrase
     layer may react to severity; the timing layer must not. */
  const strict = createCoachingSpeechPlanner();
  const relaxed = createCoachingSpeechPlanner();
  let nowMs = 0;
  for (let frame = 0; frame < 120; frame += 1) {
    nowMs += FRAME_MS;
    const base = correction("LEFT_ELBOW_INCREASE");
    const minor: CoachingState = {
      ...base,
      severity: "minor",
      intensity: "gentle",
      confidence: 0.51,
    };
    assert.equal(
      strict.plan({ state: base, nowMs, isSpeaking: false }).speak,
      relaxed.plan({ state: minor, nowMs, isSpeaking: false }).speak,
      `timing diverged on severity at frame ${frame}`,
    );
  }
});

test("speech timing contains no copy of the pose mathematics", () => {
  /* The whole point of Part 4.3: "should I speak now?" may look at semantic
     identity and the clock, never at geometry. A rule like
     `if (elbowError > 25)` appearing here would mean the threshold now
     exists in two places and can silently diverge. */
  const source = readFileSync(
    join(REPO_ROOT, "shared", "coaching", "speechPlanner.ts"),
    "utf8",
  );
  const code = source
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "");

  for (const forbidden of [
    "angle",
    "Angle",
    "landmark",
    "Landmark",
    "threshold",
    "THRESHOLD",
    "degree",
    "elbow",
    "knee",
    "shoulder",
    "hip",
    "Math.atan2",
    "Math.acos",
    "severity",
    "confidence",
    "heldByHysteresis",
  ]) {
    assert.ok(
      !code.includes(forbidden),
      `speechPlanner must not reference "${forbidden}" — that is pose analysis`,
    );
  }

  /* It DOES read the facts the engine already established. */
  assert.ok(code.includes("state.stableFrames"));
  assert.ok(code.includes("state.speakable"));
  assert.ok(code.includes("state.token"));
});

test("phrase selection and speech timing stay separate modules", () => {
  const planner = readFileSync(
    join(REPO_ROOT, "shared", "coaching", "speechPlanner.ts"),
    "utf8",
  );
  const phrases = readFileSync(
    join(REPO_ROOT, "shared", "coaching", "phraseSelection.ts"),
    "utf8",
  );
  /* "What should I say?" and "should I say it now?" never call each other. */
  assert.ok(!planner.includes("selectCoachingPhrase"));
  assert.ok(!planner.includes("instructionPool"));
  assert.ok(!phrases.includes("createCoachingSpeechPlanner"));
  assert.ok(!phrases.includes("DEFAULT_SPEECH_CADENCE"));
});

test("every coaching caller goes through the centralized decision path", () => {
  const camera = readFileSync(
    join(
      REPO_ROOT,
      "mobile",
      "src",
      "features",
      "camera",
      "presentation",
      "screens",
      "CameraTab.tsx",
    ),
    "utf8",
  );
  const code = camera
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "");

  /* Coaching speech is requested exactly one way. */
  const coachingCalls = code.match(/speakCoaching\s*\(/g) ?? [];
  assert.equal(coachingCalls.length, 1, "coaching must have a single call site");

  /* Nothing bypasses it with raw text or a hand-picked correction category. */
  assert.ok(!/speakGuidance\s*\(/.test(code), "raw-text speech bypasses the planner");
  const directCategories = [...code.matchAll(/speakInstruction\s*\(\s*'([a-z_]+)'/g)].map(
    (match) => match[1],
  );
  /* The only direct utterance left is the forced capture announcement. */
  assert.deepEqual(
    directCategories,
    ["photo_clicking"],
    "no correction category may be spoken outside the planner",
  );
});

/* ==================================================================== *
 * 8 · PLAN → EXECUTE IS A CONTRACT (regression, Unit 34 closure audit)
 *
 * `plan()` commits the moment it authorizes a line, because the next ML
 * frame is only ~66 ms away and must already see "just spoken". The
 * executor downstream can still legitimately produce nothing — the phrase
 * layer answers silence for a retired/unknown category (Unit 33 D4), or the
 * utterance is superseded before the native engine starts it. Before the
 * fix, the planner kept the credit for a line the user never heard; for
 * PERFECT that silently spent the single positive response of the whole
 * episode.
 * ==================================================================== */

test("an unexecutable PERFECT line does not spend the episode's one response", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();

  const authorized = planner.plan({
    state: perfect(),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(authorized.speak, true);

  /* The executor could not turn it into audio. */
  assert.equal(planner.revert(authorized), true);

  clock.advance(FRAME_MS);
  const retried = planner.plan({
    state: perfect(),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(
    retried.speak,
    true,
    "praise that was never spoken must still be available",
  );
  assert.notEqual(retried.reason, "already-said");

  /* …and it is still exactly ONE response: the retry consumed the episode. */
  const spoken: Utterance[] = [];
  run(planner, clock, perfect(), 600, spoken);
  assert.equal(spoken.length, 0, "the episode is closed by the line that played");
});

test("a withdrawn correction restores the cadence memory exactly", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();

  const first = planner.plan({
    state: correction("LEFT_ELBOW_INCREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(first.speak, true);
  assert.equal(planner.revert(first), true);

  clock.advance(FRAME_MS);
  const retried = planner.plan({
    state: correction("LEFT_ELBOW_INCREASE"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(retried.speak, true, "a line that never played is not a repeat");
  assert.equal(
    retried.reason,
    "state-entered",
    "the planner must be back at 'nothing has been said yet'",
  );
});

test("withdrawing does not reopen a gate for a DIFFERENT state", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("A"), 1, spoken);
  assert.equal(spoken.length, 1);

  /* B is authorized once cadence allows, then fails to execute. */
  clock.advance(DEFAULT_SPEECH_CADENCE.minGapMs);
  const b = planner.plan({
    state: correction("B"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(b.speak, true);
  assert.equal(planner.revert(b), true);

  /* A is still the last thing actually said, at its original clock: it may
     not jump its repeat interval just because B was withdrawn. */
  clock.advance(FRAME_MS);
  const a = planner.plan({
    state: correction("A"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(a.speak, false);
  assert.equal(a.reason, "repeat-wait");
});

test("revert is identity-checked: only the most recent authorization", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();

  const first = planner.plan({
    state: correction("A"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(first.speak, true);

  clock.advance(DEFAULT_SPEECH_CADENCE.minGapMs + FRAME_MS);
  const second = planner.plan({
    state: correction("B"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(second.speak, true);

  /* A late failure callback from the SUPERSEDED line must not disturb the
     line that replaced it. */
  assert.equal(planner.revert(first), false);

  clock.advance(FRAME_MS);
  const after = planner.plan({
    state: correction("B"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(after.speak, false);
  assert.equal(after.reason, "repeat-wait");

  /* Reverting twice is idempotent, never a replay. */
  assert.equal(planner.revert(second), true);
  assert.equal(planner.revert(second), false);
});

test("a suppressed plan cannot be reverted into extra speech", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();
  const spoken: Utterance[] = [];

  run(planner, clock, correction("A"), 1, spoken);
  const blocked = planner.plan({
    state: correction("A"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(blocked.speak, false);
  assert.equal(planner.revert(blocked), false, "nothing was committed to undo");

  const stillQuiet = planner.plan({
    state: correction("A"),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(stillQuiet.speak, false);
});

test("reset() invalidates any outstanding authorization", () => {
  const planner = createCoachingSpeechPlanner();
  const clock = fakeClock();

  const authorized = planner.plan({
    state: perfect(),
    nowMs: clock.now(),
    isSpeaking: false,
  });
  assert.equal(authorized.speak, true);
  planner.reset();
  assert.equal(planner.revert(authorized), false);
});

test("the TTS executor withdraws authorizations it could not execute", () => {
  /* The rollback only protects the user if the one executor in the app
     actually calls it — on BOTH failure paths. */
  const source = readFileSync(
    join(REPO_ROOT, "mobile", "src", "core", "voice", "ttsService.ts"),
    "utf8",
  );
  const code = source
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "");

  const reverts = code.match(/planner\.revert\s*\(\s*plan\s*\)/g) ?? [];
  assert.equal(
    reverts.length,
    2,
    "expected a withdrawal for silent phrase selection AND for a failed start",
  );
  /* The result of the execution must be inspected, not fired and forgotten. */
  assert.ok(
    /if\s*\(\s*!\s*spoke\s*\)\s*this\.planner\.revert\(\s*plan\s*\)/.test(code),
    "a failed utterance must withdraw its authorization",
  );
});

test("cadence config is overridable and the defaults are sane", () => {
  assert.ok(DEFAULT_SPEECH_CADENCE.minGapMs > 0);
  assert.ok(
    DEFAULT_SPEECH_CADENCE.minGapMs < 2_000,
    "a multi-second floor makes real-time coaching feel broken",
  );
  assert.ok(DEFAULT_SPEECH_CADENCE.repeatIntervalMs > DEFAULT_SPEECH_CADENCE.minGapMs);
  assert.ok(
    DEFAULT_SPEECH_CADENCE.alternationCooldownMs >= DEFAULT_SPEECH_CADENCE.minGapMs,
  );

  const snappy = createCoachingSpeechPlanner({ minGapMs: 100, repeatIntervalMs: 500 });
  assert.equal(snappy.config.minGapMs, 100);
  assert.equal(snappy.config.repeatIntervalMs, 500);
  /* Untouched keys keep their defaults. */
  assert.equal(
    snappy.config.perfectMinStableFrames,
    DEFAULT_SPEECH_CADENCE.perfectMinStableFrames,
  );
});
