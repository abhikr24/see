/**
 * tests/integration/fullTrace.test.ts — Unit 31: THE WHOLE CHAIN, ONE TEST FILE.
 *
 * Every other suite proves one stage. This one walks the complete declared
 * architecture end to end, from a source the codebase has never seen to the
 * words a speech engine would be handed:
 *
 *   TEST REFERENCE PROVIDER (foreign shape: snake_case · radians · strings)
 *     → ADAPTER → VALIDATOR → NORMALIZER → ReferencePoseTemplate
 *     → session PIN → SAME pose engine
 *     → live landmarks → MEASUREMENTS → COMPARISON → ERROR → CONFIDENCE
 *     → SEVERITY → PRIORITY → TEMPORAL STABILITY
 *     → SEMANTIC COACHING STATE → LANGUAGE → PHRASE → (TTS input)
 *
 * What it is designed to catch:
 *   · a new provider forcing a change in the mathematics (it must not);
 *   · reference data being re-fetched / re-validated inside the frame loop;
 *   · any path from "no/invalid/incompatible reference" to a spoken cue;
 *   · a fabricated value standing in for a missing measurement.
 *
 * Deterministic: fixed bodies, injected random, frame-counted time.
 */
import { strict as assert } from "node:assert";
import test from "node:test";

import {
  createPoseAnalysisEngine,
  matchFromDecision,
  type PoseAnalysisDecision,
} from "../../shared/ml/analysis";
import {
  createCoachingSpeechPlanner,
  decisionToCoachingState,
  selectCoachingPhrase,
} from "../../shared/coaching";
import { analysisInputFromPin } from "../../shared/reference/analysisBinding";
import { pinReferenceForSession } from "../../shared/reference/session";
import { isReadyResolution } from "../../shared/reference/provider";
import { ReferenceStatuses } from "../../shared/reference/status";
import type { PoseLandmark } from "../../shared/ml/poseLandmarks";
import { POSE_LANDMARKS } from "../../shared/ml/poseLandmarks";
import {
  bodyLandmarks,
  measuredAngles,
  referenceWithOffsets,
} from "../analysis/fixtures";
import {
  createTestReferenceProvider,
  labRecordFromDegrees,
  TEST_PROVIDER_ID,
  type TestReferenceProvider,
} from "../support/testReferenceProvider";

/** Pose ids that exist ONLY in the test source — never in the bundled catalog. */
const LAB_POSE = "lab-subject-alpha";
const FUTURE_POSE = "lab-subject-future-2099";

/** Deterministic 0..1 source so phrase selection is reproducible. */
function fixedRandom(value: number): () => number {
  return () => value;
}

/**
 * Resolve → pin → bind, exactly as the camera session does. Returns the
 * engine plus the provider so the hot-path test can count resolutions.
 */
async function sessionFor(
  provider: TestReferenceProvider,
  poseId: string,
): Promise<{
  readonly engine: ReturnType<typeof createPoseAnalysisEngine> | null;
  readonly status: string;
  readonly templateId: string | null;
}> {
  const resolution = await provider.getReference({ poseId });
  if (!isReadyResolution(resolution)) {
    return { engine: null, status: resolution.status, templateId: null };
  }
  const pin = pinReferenceForSession(resolution.template, `test:${poseId}`, 0);
  const projection = analysisInputFromPin(pin);
  if (!projection.ok) {
    return { engine: null, status: "projection-refused", templateId: null };
  }
  return {
    engine: createPoseAnalysisEngine({
      reference: projection.input,
      sessionId: `test:${poseId}`,
    }),
    status: resolution.status,
    templateId: resolution.template.templateId,
  };
}

/* ------------------------------------------------------------------ *
 * 1 · A NEW SOURCE REACHES THE SAME ENGINE WITHOUT TOUCHING THE MATHS
 * ------------------------------------------------------------------ */

test("a never-before-seen source shape flows all the way to a spoken phrase", async () => {
  const body = bodyLandmarks();
  /* The subject's left elbow is 30° more open than the reference wants. */
  const degrees = referenceWithOffsets(body, { leftElbow: 30 });
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, degrees),
  ]);

  const session = await sessionFor(provider, LAB_POSE);
  assert.equal(session.status, ReferenceStatuses.ready);
  assert.ok(session.engine !== null);
  assert.equal(session.engine?.referenceState, "ready");
  assert.equal(session.templateId, `${TEST_PROVIDER_ID}/${LAB_POSE}`);

  /* Hold the pose long enough for the temporal stage to commit. */
  let decision: PoseAnalysisDecision | null = null;
  for (let frame = 0; frame < 6; frame += 1) {
    decision = session.engine?.analyzeFrame(body) ?? null;
  }
  assert.ok(decision !== null);
  assert.equal(decision?.kind, "correction");
  assert.equal(decision?.correction?.measurementId, "leftElbow");
  /* live > reference ⇒ close the joint. */
  assert.equal(decision?.correction?.direction, "decrease");

  const state = decisionToCoachingState(decision as PoseAnalysisDecision);
  assert.equal(state.kind, "correction");
  assert.equal(state.measurementId, "leftElbow");
  assert.ok(state.category !== null);
  assert.equal(state.speakable, true);

  const english = selectCoachingPhrase(state, "en", { random: fixedRandom(0) });
  const hindi = selectCoachingPhrase(state, "hi", { random: fixedRandom(0) });
  assert.ok(english !== null && english.text.length > 0);
  assert.ok(hindi !== null && hindi.text.length > 0);
  assert.equal(english?.category, state.category);
  assert.equal(hindi?.category, state.category);
  assert.notEqual(english?.text, hindi?.text);

  /* The speech planner is the only thing that decides WHEN it is said. */
  const planner = createCoachingSpeechPlanner();
  const plan = planner.plan({ state, nowMs: 10_000, isSpeaking: false });
  assert.equal(plan.speak, true);
  assert.equal(plan.token, state.token);
});

test("radians + string numbers are normalized, not reinterpreted", async () => {
  const body = bodyLandmarks();
  const degrees = referenceWithOffsets(body, {});
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, degrees),
  ]);
  const resolution = await provider.getReference({ poseId: LAB_POSE });
  assert.ok(isReadyResolution(resolution));
  if (!isReadyResolution(resolution)) return;

  for (const [id, expected] of Object.entries(degrees)) {
    const entry = resolution.template.measurements[id];
    assert.ok(entry !== undefined, `${id} must survive normalization`);
    /* toFixed(9) on the radian value is the only loss in the round trip. */
    assert.ok(Math.abs((entry?.value ?? 0) - expected) < 1e-6);
  }
  assert.equal(resolution.template.normalization.convertedUnits["leftElbow"], "radians");
  assert.ok(resolution.template.normalization.coercedNumericIds.includes("leftElbow"));
  assert.equal(resolution.template.normalization.renamedIds["left_elbow"], "leftElbow");
});

test("the same numbers from two different sources produce identical decisions", async () => {
  const body = bodyLandmarks();
  /* Offsets chosen so the mean |error| is NOT on an exact .5 boundary of the
     integer match %. The lab source round-trips through radians with
     toFixed(9), a documented loss below 1e-6°, which is invisible everywhere
     EXCEPT when Math.round() is handed exactly x.5 — asserting integer
     equality there tests the rounding boundary, not the pipeline. */
  const degrees = referenceWithOffsets(body, { rightKnee: -22, leftShoulder: 15 });

  const labProvider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, degrees),
  ]);
  const labSession = await sessionFor(labProvider, LAB_POSE);

  /* Same values, handed to the engine directly (the "old" path). */
  const direct = createPoseAnalysisEngine({
    reference: {
      referenceId: "direct",
      poseId: LAB_POSE,
      schemaVersion: 1,
      measurementVersion: 1,
      contentHash: "direct",
      values: Object.fromEntries(
        Object.entries(degrees).map(([id, value]) => [id, { value, confidence: null }]),
      ),
    },
    sessionId: "direct",
  });

  for (let frame = 0; frame < 8; frame += 1) {
    const viaProvider = labSession.engine?.analyzeFrame(body) ?? null;
    const viaDirect = direct.analyzeFrame(body);
    assert.equal(viaProvider?.state, viaDirect.state);
    assert.equal(viaProvider?.kind, viaDirect.kind);
    assert.equal(
      viaProvider?.correction?.measurementId ?? null,
      viaDirect.correction?.measurementId ?? null,
    );
    const providerMatch = matchFromDecision(viaProvider);
    const directMatch = matchFromDecision(viaDirect);
    assert.equal(providerMatch.percent, directMatch.percent);
    /* The underlying geometry must agree to normalization precision, not just
       after rounding — that is the real "same numbers, same decision" claim. */
    assert.ok(
      Math.abs((providerMatch.avgDiffDegrees ?? 0) - (directMatch.avgDiffDegrees ?? 0)) <
        1e-6,
    );
  }
});

/* ------------------------------------------------------------------ *
 * 2 · ADDING A FUTURE POSE = ADDING DATA, NOT A CODE BRANCH
 * ------------------------------------------------------------------ */

test("a brand-new pose id works with zero new mathematical branches", async () => {
  const body = bodyLandmarks();
  const degrees = referenceWithOffsets(body, { rightElbow: -28 });
  /* The ONLY thing added for this pose is the reference record itself. */
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(FUTURE_POSE, degrees),
  ]);
  const session = await sessionFor(provider, FUTURE_POSE);
  assert.ok(session.engine !== null);

  let decision: PoseAnalysisDecision | null = null;
  for (let frame = 0; frame < 6; frame += 1) {
    decision = session.engine?.analyzeFrame(body) ?? null;
  }
  assert.equal(decision?.correction?.measurementId, "rightElbow");
  assert.equal(decision?.correction?.direction, "increase");
  assert.equal(decision?.reference?.poseId, FUTURE_POSE);
  const state = decisionToCoachingState(decision as PoseAnalysisDecision);
  assert.ok(selectCoachingPhrase(state, "en", { random: fixedRandom(0.5) }) !== null);
});

/* ------------------------------------------------------------------ *
 * 3 · HOT PATH: THE FRAME LOOP TOUCHES NO INFRASTRUCTURE
 * ------------------------------------------------------------------ */

test("the reference is resolved once per session and never inside the frame loop", async () => {
  const body = bodyLandmarks();
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, referenceWithOffsets(body, { leftKnee: 18 })),
  ]);
  const session = await sessionFor(provider, LAB_POSE);
  assert.equal(provider.calls(), 1);

  const boundValues = session.engine?.reference?.values;
  for (let frame = 0; frame < 120; frame += 1) {
    session.engine?.analyzeFrame(body);
  }
  /* No re-resolution, and the bound projection is the SAME frozen object —
     nothing re-parsed, re-validated or re-normalized per frame. */
  assert.equal(provider.calls(), 1);
  assert.equal(session.engine?.reference?.values, boundValues);
  assert.equal(Object.isFrozen(session.engine?.reference), true);
});

test("resetting a session clears temporal memory without re-resolving", async () => {
  const body = bodyLandmarks();
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, referenceWithOffsets(body, { leftKnee: 18 })),
  ]);
  const session = await sessionFor(provider, LAB_POSE);
  for (let frame = 0; frame < 10; frame += 1) session.engine?.analyzeFrame(body);
  session.engine?.reset();
  const after = session.engine?.analyzeFrame(body);
  assert.equal(provider.calls(), 1);
  assert.equal(after?.temporal.frameIndex, 1);
});

/* ------------------------------------------------------------------ *
 * 4 · FAILURE STATES CANNOT BECOME COACHING
 * ------------------------------------------------------------------ */

test("no reference ⇒ analysis unavailable ⇒ silence (never a demo pose)", async () => {
  const provider = createTestReferenceProvider([]);
  const session = await sessionFor(provider, LAB_POSE);
  assert.equal(session.engine, null);
  assert.equal(session.status, ReferenceStatuses.unavailable);

  /* What the app does in that case: an engine with no reference at all. */
  const idle = createPoseAnalysisEngine({ reference: null, sessionId: "idle" });
  const decision = idle.analyzeFrame(bodyLandmarks());
  assert.equal(decision.kind, "unavailable");
  assert.equal(decision.unavailable?.reason, "reference-unavailable");
  assert.equal(matchFromDecision(decision).percent, null);

  const state = decisionToCoachingState(decision);
  assert.equal(state.speakable, false);
  assert.equal(state.category, null);
  assert.equal(selectCoachingPhrase(state, "en"), null);
  assert.equal(selectCoachingPhrase(state, "hi"), null);
  const planner = createCoachingSpeechPlanner();
  assert.equal(planner.plan({ state, nowMs: 50_000, isSpeaking: false }).speak, false);
});

test("invalid source data ⇒ structured invalid state ⇒ no misleading coaching", async () => {
  const body = bodyLandmarks();
  const record = labRecordFromDegrees(LAB_POSE, referenceWithOffsets(body, {}));
  /* An impossible angle (400°) arrives from the source. */
  const corrupted = {
    ...record,
    angles: {
      unit: record.angles.unit,
      readings: { ...record.angles.readings, left_elbow: String((400 * Math.PI) / 180) },
    },
  };
  const provider = createTestReferenceProvider([corrupted]);
  const resolution = await provider.getReference({ poseId: LAB_POSE });

  assert.equal(resolution.status, ReferenceStatuses.invalid);
  assert.ok(!isReadyResolution(resolution));
  if (!isReadyResolution(resolution)) {
    assert.equal(resolution.failure.kind, "invalid-reference");
    assert.ok(resolution.failure.message.length > 0);
  }
  const session = await sessionFor(provider, LAB_POSE);
  assert.equal(session.engine, null);
});

test("an incompatible measurement version is refused, never reinterpreted", async () => {
  const body = bodyLandmarks();
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, referenceWithOffsets(body, {}), { semantics: "2" }),
  ]);
  const resolution = await provider.getReference({ poseId: LAB_POSE });
  assert.equal(resolution.status, ReferenceStatuses.incompatible);
  if (!isReadyResolution(resolution)) {
    assert.equal(resolution.failure.kind, "incompatible-reference");
  }
  assert.equal((await sessionFor(provider, LAB_POSE)).engine, null);
});

test("a compatible measurement version is accepted", async () => {
  const body = bodyLandmarks();
  const provider = createTestReferenceProvider([
    labRecordFromDegrees(LAB_POSE, referenceWithOffsets(body, {}), { semantics: "1" }),
  ]);
  const resolution = await provider.getReference({ poseId: LAB_POSE });
  assert.equal(resolution.status, ReferenceStatuses.ready);
});

test("measurements the source omitted stay explicitly absent — nothing is invented", async () => {
  const body = bodyLandmarks();
  const all = measuredAngles(body);
  /* Only three of the eight measurements are exported. */
  const partial: Record<string, number> = {
    leftElbow: (all["leftElbow"] ?? 0) - 30,
    rightElbow: all["rightElbow"] ?? 0,
    leftKnee: all["leftKnee"] ?? 0,
  };
  const provider = createTestReferenceProvider([labRecordFromDegrees(LAB_POSE, partial)]);
  const resolution = await provider.getReference({ poseId: LAB_POSE });
  assert.ok(isReadyResolution(resolution));
  if (!isReadyResolution(resolution)) return;

  assert.equal(resolution.template.availability.isPartial, true);
  assert.equal(resolution.template.availability.availableCount, 3);
  assert.ok(resolution.template.availability.missingIds.includes("rightHip"));
  assert.equal(resolution.template.measurements["rightHip"], undefined);

  const session = await sessionFor(provider, LAB_POSE);
  const decision = session.engine?.analyzeFrame(body) ?? null;
  const rightHip = decision?.frame.comparisons.find((c) => c.measurementId === "rightHip");
  assert.ok(rightHip !== undefined);
  assert.equal(rightHip?.validity, "reference-missing");
  assert.equal(rightHip?.referenceValue, null);
  assert.equal(rightHip?.available, false);
  /* An absent measurement can never win the priority ranking. */
  assert.ok(
    (decision?.frame.candidates ?? []).every((c) => c.measurementId !== "rightHip"),
  );
});

/* ------------------------------------------------------------------ *
 * 5 · NOISE, DOMINANCE AND RECOVERY ACROSS A REALISTIC SEQUENCE
 * ------------------------------------------------------------------ */

/** Nudges one landmark so a specific joint's angle drifts frame to frame. */
function jitteredBody(step: number): PoseLandmark[] {
  const wobble = step % 2 === 0 ? 0.004 : -0.004;
  return bodyLandmarks({
    overrides: {
      [POSE_LANDMARKS.leftWrist]: { x: 0.34 + wobble },
      [POSE_LANDMARKS.rightWrist]: { x: 0.66 - wobble },
    },
  });
}

test("noisy frames never produce left/right/left/right coaching churn", async () => {
  const base = bodyLandmarks();
  /* Both elbows are wrong by an almost identical amount — the classic
     flip-flop setup. */
  const degrees = referenceWithOffsets(base, { leftElbow: 26, rightElbow: 25.4 });
  const provider = createTestReferenceProvider([labRecordFromDegrees(LAB_POSE, degrees)]);
  const session = await sessionFor(provider, LAB_POSE);
  assert.ok(session.engine !== null);

  const planner = createCoachingSpeechPlanner();
  const spokenTokens: string[] = [];
  const states: string[] = [];
  for (let frame = 0; frame < 40; frame += 1) {
    const decision = session.engine?.analyzeFrame(jitteredBody(frame));
    if (decision === undefined) continue;
    const state = decisionToCoachingState(decision);
    states.push(state.token);
    const plan = planner.plan({
      state,
      /* 15 fps ML budget: one frame ≈ 66 ms. */
      nowMs: frame * 66,
      isSpeaking: false,
    });
    if (plan.speak) spokenTokens.push(plan.token);
  }

  /* Count how often the ACTIVE semantic state changed at all. */
  let transitions = 0;
  for (let index = 1; index < states.length; index += 1) {
    if (states[index] !== states[index - 1]) transitions += 1;
  }
  assert.ok(
    transitions <= 2,
    `noisy sequence produced ${transitions} state changes: ${states.join(",")}`,
  );
  /* And the coach never said two different things in a row. */
  const distinctSpoken = new Set(spokenTokens);
  assert.ok(
    distinctSpoken.size <= 1,
    `coach flapped between ${[...distinctSpoken].join(" / ")}`,
  );
});

test("stable error ⇒ correction, stable recovery ⇒ perfect, once", async () => {
  const wrong = bodyLandmarks();
  const degrees = referenceWithOffsets(wrong, { leftElbow: 35 });
  const provider = createTestReferenceProvider([labRecordFromDegrees(LAB_POSE, degrees)]);
  const session = await sessionFor(provider, LAB_POSE);
  const planner = createCoachingSpeechPlanner();

  const spoken: { token: string; kind: string }[] = [];
  const runPhase = (landmarks: readonly PoseLandmark[], frames: number, t0: number) => {
    for (let frame = 0; frame < frames; frame += 1) {
      const decision = session.engine?.analyzeFrame(landmarks);
      if (decision === undefined) continue;
      const state = decisionToCoachingState(decision);
      const plan = planner.plan({
        state,
        nowMs: t0 + frame * 66,
        isSpeaking: false,
      });
      if (plan.speak) spoken.push({ token: plan.token, kind: state.kind });
    }
  };

  /* Phase 1 — the subject holds the wrong pose. */
  runPhase(wrong, 10, 0);
  assert.ok(spoken.length >= 1);
  assert.equal(spoken[0]?.kind, "correction");
  assert.ok(spoken[0]?.token.startsWith("LEFT_ELBOW"));

  /* Phase 2 — the subject corrects: reference now matches the body. */
  const corrected = bodyLandmarks();
  const matching = referenceWithOffsets(corrected, {});
  const provider2 = createTestReferenceProvider([
    labRecordFromDegrees(FUTURE_POSE, matching),
  ]);
  const session2 = await sessionFor(provider2, FUTURE_POSE);
  const planner2 = createCoachingSpeechPlanner();
  const positives: string[] = [];
  for (let frame = 0; frame < 30; frame += 1) {
    const decision = session2.engine?.analyzeFrame(corrected);
    if (decision === undefined) continue;
    const state = decisionToCoachingState(decision);
    const plan = planner2.plan({ state, nowMs: frame * 66, isSpeaking: false });
    if (plan.speak && state.kind === "perfect") positives.push(plan.token);
  }
  /* Controlled positive behavior: ONE line per perfect episode, not a chant. */
  assert.equal(positives.length, 1);
});

test("multiple simultaneous errors select exactly one dominant correction", async () => {
  const body = bodyLandmarks();
  const degrees = referenceWithOffsets(body, {
    leftElbow: 12,
    rightElbow: -40,
    leftKnee: 18,
    rightHip: -15,
  });
  const provider = createTestReferenceProvider([labRecordFromDegrees(LAB_POSE, degrees)]);
  const session = await sessionFor(provider, LAB_POSE);

  let decision: PoseAnalysisDecision | null = null;
  for (let frame = 0; frame < 6; frame += 1) {
    decision = session.engine?.analyzeFrame(body) ?? null;
  }
  assert.ok((decision?.frame.candidates.length ?? 0) >= 4);
  assert.equal(decision?.kind, "correction");
  assert.equal(decision?.correction?.measurementId, "rightElbow");

  const state = decisionToCoachingState(decision as PoseAnalysisDecision);
  assert.equal(state.measurementId, "rightElbow");

  /* Ordering independence: the SAME reference, keys shuffled, same winner. */
  const shuffled: Record<string, number> = {};
  for (const id of Object.keys(degrees).reverse()) {
    shuffled[id] = degrees[id] as number;
  }
  const provider2 = createTestReferenceProvider([
    labRecordFromDegrees(FUTURE_POSE, shuffled),
  ]);
  const session2 = await sessionFor(provider2, FUTURE_POSE);
  let decision2: PoseAnalysisDecision | null = null;
  for (let frame = 0; frame < 6; frame += 1) {
    decision2 = session2.engine?.analyzeFrame(body) ?? null;
  }
  assert.equal(decision2?.correction?.measurementId, decision?.correction?.measurementId);
  assert.equal(decision2?.state, decision?.state);
});
