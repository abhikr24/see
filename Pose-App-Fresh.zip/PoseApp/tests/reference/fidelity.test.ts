/**
 * tests/reference/fidelity.test.ts — Unit 29.
 *
 * Proves the NO-FAKE-PRODUCTION-FALLBACK rule:
 *   · approximate data is labelled approximate, everywhere, always
 *   · a measured-only caller gets an explicit `approximate-only` failure and
 *     NOTHING else — no substitute pose, no demo template, no fixture
 *   · partial templates state what is missing and never fabricate it
 */
import assert from "node:assert/strict";
import test from "node:test";

import {
  buildReferenceTemplate,
  CATALOG_REFERENCE_PROVIDER_ID,
  createCatalogReferenceProvider,
  createMemoryReferenceProvider,
  fidelityForProvenance,
  fidelitySatisfiesPolicy,
  isReadyResolution,
  knownMeasurementIds,
  readMeasurement,
  ReferenceStatuses,
  templateHasAll,
} from "../../shared/reference";
import { getPoseCatalog } from "../../shared/data/poseCatalog";
import { defaultReferenceAnglesFor } from "../../shared/data/referenceAngles";
import { mutated, validRawPayload } from "./fixtures";

/* ------------------------------------------------------------------ */
/* The fidelity axis                                                   */
/* ------------------------------------------------------------------ */

test("fidelity is derived from provenance; only measured-scan is 'measured'", () => {
  assert.equal(fidelityForProvenance("measured-scan"), "measured");
  assert.equal(fidelityForProvenance("bundled-category-default"), "category-approximate");
  assert.equal(fidelityForProvenance("remote-source"), "category-approximate");
  assert.equal(fidelityForProvenance("test-fixture"), "category-approximate");
});

test("policy gate: measured-only accepts measured alone", () => {
  assert.equal(fidelitySatisfiesPolicy("measured", "measured-only"), true);
  assert.equal(fidelitySatisfiesPolicy("category-approximate", "measured-only"), false);
  assert.equal(fidelitySatisfiesPolicy("category-approximate", "allow-approximate"), true);
});

test("a payload cannot promote itself to 'measured' by writing a fidelity field", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    (draft["metadata"] as Record<string, unknown>)["fidelity"] = "measured";
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  assert.equal(built.template.metadata.fidelity, "category-approximate");
});

/* ------------------------------------------------------------------ */
/* No fake production fallback                                         */
/* ------------------------------------------------------------------ */

test("catalog under measured-only returns approximate-only — no data, no substitute", async () => {
  const provider = createCatalogReferenceProvider({ fidelityPolicy: "measured-only" });
  const pose = getPoseCatalog()[0];
  assert.ok(pose !== undefined);
  const resolution = await provider.getReference({ poseId: pose.id });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected unavailable");
  assert.equal(resolution.status, ReferenceStatuses.unavailable);
  assert.equal(resolution.failure.kind, "approximate-only");
  /* Not retryable: retrying cannot conjure a measurement nobody took. */
  assert.equal(resolution.failure.retryable, false);
  assert.equal(resolution.failure.providerId, CATALOG_REFERENCE_PROVIDER_ID);
});

test("catalog under allow-approximate labels every template as approximate", async () => {
  const provider = createCatalogReferenceProvider({ fidelityPolicy: "allow-approximate" });
  const pose = getPoseCatalog()[0];
  assert.ok(pose !== undefined);
  const resolution = await provider.getReference({ poseId: pose.id });
  assert.equal(isReadyResolution(resolution), true);
  if (!isReadyResolution(resolution)) return;
  assert.equal(resolution.template.metadata.fidelity, "category-approximate");
  assert.equal(resolution.template.metadata.provenance, "bundled-category-default");
});

test("an unavailable reference NEVER yields a template from another pose", async () => {
  const provider = createCatalogReferenceProvider({ fidelityPolicy: "allow-approximate" });
  const resolution = await provider.getReference({ poseId: "no-such-pose" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected unavailable");
  assert.equal("template" in resolution, false);
});

test("an empty provider stays empty — it does not borrow the catalog", async () => {
  const provider = createMemoryReferenceProvider([], "empty-source");
  const resolution = await provider.getReference({ poseId: "portraits-1" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected unavailable");
  assert.equal(resolution.status, ReferenceStatuses.unavailable);
  assert.equal(resolution.failure.kind, "reference-unavailable");
});

/* ------------------------------------------------------------------ */
/* The fabricated per-pose variance is gone                            */
/* ------------------------------------------------------------------ */

test("category stances are returned verbatim — no invented per-pose variance", () => {
  const stance = defaultReferenceAnglesFor("portraits");
  assert.ok(stance !== null);
  if (stance === null) return;
  /* The authored portrait stance, exactly as written in the data file. */
  assert.equal(stance["leftElbow"], 165);
  assert.equal(stance["rightShoulder"], 16);
  /* Deterministic and referentially stable across calls. */
  assert.deepEqual(defaultReferenceAnglesFor("portraits"), stance);
});

test("poses of one category share one honest stance instead of noisy pseudo-data", () => {
  const catalog = getPoseCatalog();
  const portraits = catalog.filter((pose) => pose.category === "portraits").slice(0, 5);
  assert.ok(portraits.length >= 2, "need at least two portrait poses");
  const first = portraits[0]?.referenceAngles;
  assert.ok(first !== null && first !== undefined);
  for (const pose of portraits) {
    assert.deepEqual(pose.referenceAngles, first, pose.id);
  }
});

/* ------------------------------------------------------------------ */
/* Partial templates                                                   */
/* ------------------------------------------------------------------ */

test("a partial template states what it has and what it does not", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = { leftElbow: 90, rightElbow: 92 };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  const { availability } = built.template;
  assert.equal(availability.isPartial, true);
  assert.deepEqual(availability.availableIds, ["leftElbow", "rightElbow"]);
  assert.equal(availability.availableCount, 2);
  assert.equal(availability.missingIds.length, knownMeasurementIds().length - 2);
  assert.ok(availability.missingIds.includes("leftKnee"));
  assert.equal(availability.completeness, 2 / knownMeasurementIds().length);
  assert.ok(availability.missingEngineEligibleIds.includes("leftKnee"));
});

test("a complete template is not flagged partial", () => {
  const built = buildReferenceTemplate({ providerId: "test", payload: validRawPayload() });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  assert.equal(built.template.availability.isPartial, false);
  assert.equal(built.template.availability.completeness, 1);
  assert.deepEqual(built.template.availability.missingIds, []);
});

test("missing measurements read as absent — never as a value, never as zero", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = { leftElbow: 90, rightElbow: 92 };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  if (built.status !== ReferenceStatuses.ready) return assert.fail("expected ready");

  const present = readMeasurement(built.template, "leftElbow");
  assert.equal(present.present, true);
  if (present.present) assert.equal(present.value, 90);

  const absent = readMeasurement(built.template, "leftKnee");
  assert.equal(absent.present, false);
  if (!absent.present) assert.equal(absent.reason, "not-in-template");

  const unregistered = readMeasurement(built.template, "leftEyebrow");
  assert.equal(unregistered.present, false);
  if (!unregistered.present) assert.equal(unregistered.reason, "not-registered");

  assert.equal(templateHasAll(built.template, ["leftElbow", "rightElbow"]), true);
  assert.equal(templateHasAll(built.template, ["leftElbow", "leftKnee"]), false);
});
