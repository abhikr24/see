/**
 * tests/reference/fixtures.ts — SYNTHETIC TEST FIXTURES.
 *
 * These payloads exist ONLY under tests/. They are not, and must never
 * become, production reference data: nothing in shared/, mobile/, app/ or
 * tooling/ may import from here. Provenance is always "test-fixture" so even
 * an accidental leak would fail honesty inspection at the boundary.
 */

export const VALID_MEASUREMENTS: Readonly<Record<string, { value: number; confidence: number | null }>> = {
  leftElbow: { value: 90, confidence: 0.95 },
  rightElbow: { value: 92, confidence: 0.9 },
  leftKnee: { value: 170, confidence: 0.88 },
  rightKnee: { value: 172, confidence: null },
  leftShoulder: { value: 30, confidence: 0.8 },
  rightShoulder: { value: 32, confidence: 0.75 },
  leftHip: { value: 168, confidence: null },
  rightHip: { value: 170, confidence: 0.7 },
};

/** A fully valid raw payload at current versions. */
export function validRawPayload(): Record<string, unknown> {
  return {
    templateId: "fixtures/valid-1",
    poseId: "fixture-pose-1",
    schemaVersion: 1,
    measurementVersion: 1,
    measurements: JSON.parse(JSON.stringify(VALID_MEASUREMENTS)) as Record<string, unknown>,
    metadata: { provenance: "test-fixture", sourceProvider: "fixtures" },
  };
}

/** Deep-clone then mutate by path — deterministic fixture surgery. */
export function mutated(
  base: Record<string, unknown>,
  mutate: (draft: Record<string, unknown>) => void,
): Record<string, unknown> {
  const draft = JSON.parse(JSON.stringify(base)) as Record<string, unknown>;
  mutate(draft);
  return draft;
}

/**
 * Deterministic body for the engine-parity test: 33 landmarks, arms in a
 * right angle so leftElbow/rightElbow ≈ 90°, legs/hips nearly straight.
 * Coordinates are fixed constants — the test recomputes expectations, it
 * never asserts magic numbers beyond structural facts.
 */
export function fixtureLandmarks(): readonly { x: number; y: number; z: number; visibility: number }[] {
  const landmarks: { x: number; y: number; z: number; visibility: number }[] = [];
  for (let index = 0; index < 33; index += 1) {
    landmarks.push({ x: 0.5, y: 0.5, z: 0, visibility: 0.99 });
  }
  /* Left arm: shoulder→elbow vertical, elbow→wrist horizontal ⇒ 90°. */
  landmarks[11] = { x: 0.4, y: 0.3, z: 0, visibility: 0.99 }; // leftShoulder
  landmarks[13] = { x: 0.4, y: 0.5, z: 0, visibility: 0.99 }; // leftElbow
  landmarks[15] = { x: 0.6, y: 0.5, z: 0, visibility: 0.99 }; // leftWrist
  /* Right arm: mirrored right angle ⇒ 90°. */
  landmarks[12] = { x: 0.6, y: 0.3, z: 0, visibility: 0.99 }; // rightShoulder
  landmarks[14] = { x: 0.6, y: 0.5, z: 0, visibility: 0.99 }; // rightElbow
  landmarks[16] = { x: 0.4, y: 0.5, z: 0, visibility: 0.99 }; // rightWrist
  /* Legs straight down ⇒ knees ≈ 180°. */
  landmarks[23] = { x: 0.45, y: 0.55, z: 0, visibility: 0.99 }; // leftHip
  landmarks[25] = { x: 0.45, y: 0.8, z: 0, visibility: 0.99 }; // leftKnee
  landmarks[27] = { x: 0.45, y: 0.95, z: 0, visibility: 0.99 }; // leftAnkle
  landmarks[24] = { x: 0.55, y: 0.55, z: 0, visibility: 0.99 }; // rightHip
  landmarks[26] = { x: 0.55, y: 0.8, z: 0, visibility: 0.99 }; // rightKnee
  landmarks[28] = { x: 0.55, y: 0.95, z: 0, visibility: 0.99 }; // rightAnkle
  return landmarks;
}
