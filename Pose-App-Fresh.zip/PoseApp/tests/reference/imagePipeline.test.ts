/**
 * tests/reference/imagePipeline.test.ts — Unit 29.
 *
 * Proves the reference-image pipeline is (a) correct, (b) honest about what
 * it could not measure, and (c) BUILD-ONCE — the reference image is never
 * reprocessed per frame.
 */
import assert from "node:assert/strict";
import test from "node:test";

import {
  buildTemplateFromReferenceImage,
  createReferenceImageTemplateCache,
  extractMeasurementsFromLandmarks,
  MIN_VISIBLE_REFERENCE_LANDMARKS,
  ReferenceStatuses,
  templateMeasurementMap,
  validateReferenceLandmarks,
  type ReferenceImageDetection,
} from "../../shared/reference";
import { calculateMatchPercent } from "../../shared/ml/poseMatch";
import { fixtureLandmarks } from "./fixtures";

const OPTIONS = { providerId: "reference-scanner", measurementConfidence: 0.9 } as const;

function detection(overrides: Partial<ReferenceImageDetection> = {}): ReferenceImageDetection {
  return {
    poseId: "fixture-pose-1",
    sourceImageId: "asset://ref/1.jpg",
    landmarks: fixtureLandmarks(),
    detectorConfidence: 0.9,
    capturedAt: "2024-01-01T00:00:00.000Z",
    ...overrides,
  };
}

/* ------------------------------------------------------------------ */
/* Landmark validation                                                 */
/* ------------------------------------------------------------------ */

test("a well-formed 33-landmark detection validates", () => {
  assert.equal(validateReferenceLandmarks(detection()).ok, true);
});

test("wrong landmark count is rejected with one precise issue", () => {
  const result = validateReferenceLandmarks(
    detection({ landmarks: fixtureLandmarks().slice(0, 20) }),
  );
  assert.equal(result.ok, false);
  if (result.ok) return;
  assert.equal(result.issues.length, 1);
  assert.equal(result.issues[0]?.code, "wrong-landmark-count");
});

test("non-finite coordinates are rejected, never zero-filled", () => {
  const landmarks = [...fixtureLandmarks()];
  landmarks[13] = { x: Number.NaN, y: 0.5, z: 0, visibility: 0.9 };
  const result = validateReferenceLandmarks(detection({ landmarks }));
  assert.equal(result.ok, false);
  if (result.ok) return;
  assert.ok(result.issues.some((issue) => issue.code === "non-finite-coordinate"));
});

test("out-of-range visibility and detector confidence are rejected", () => {
  const landmarks = [...fixtureLandmarks()];
  landmarks[13] = { x: 0.4, y: 0.5, z: 0, visibility: 1.5 };
  const visibility = validateReferenceLandmarks(detection({ landmarks }));
  assert.equal(visibility.ok, false);
  if (!visibility.ok) {
    assert.ok(visibility.issues.some((issue) => issue.code === "invalid-visibility"));
  }
  const confidence = validateReferenceLandmarks(detection({ detectorConfidence: 4 }));
  assert.equal(confidence.ok, false);
  if (!confidence.ok) {
    assert.ok(confidence.issues.some((issue) => issue.code === "invalid-detector-confidence"));
  }
});

test("a mostly-occluded scan is refused rather than half-measured", () => {
  const landmarks = fixtureLandmarks().map((landmark) => ({ ...landmark, visibility: 0.01 }));
  const result = validateReferenceLandmarks(detection({ landmarks }));
  assert.equal(result.ok, false);
  if (result.ok) return;
  assert.ok(result.issues.some((issue) => issue.code === "too-few-visible-landmarks"));
  assert.ok(MIN_VISIBLE_REFERENCE_LANDMARKS > 0);
});

/* ------------------------------------------------------------------ */
/* Measurement extraction + template creation                          */
/* ------------------------------------------------------------------ */

test("extraction reuses the live engine's maths and reports unmeasurable joints", () => {
  const extracted = extractMeasurementsFromLandmarks(fixtureLandmarks());
  assert.ok(Math.abs((extracted.measurements["leftElbow"] ?? 0) - 90) < 1e-6);
  assert.ok(Math.abs((extracted.measurements["rightElbow"] ?? 0) - 90) < 1e-6);
  /* Nothing invented for joints that could not be measured. */
  for (const id of extracted.unmeasurableIds) {
    assert.equal(extracted.measurements[id], undefined);
  }
});

test("a reference image becomes a measured-scan template", () => {
  const result = buildTemplateFromReferenceImage(detection(), OPTIONS);
  assert.equal(result.status, ReferenceStatuses.ready);
  if (result.status !== ReferenceStatuses.ready) return;
  assert.equal(result.template.poseId, "fixture-pose-1");
  assert.equal(result.template.metadata.provenance, "measured-scan");
  assert.equal(result.template.metadata.fidelity, "measured");
  assert.equal(result.template.metadata.landmarkGeometry, "measured-33");
  assert.equal(result.template.metadata.capturedAt, "2024-01-01T00:00:00.000Z");
  for (const id of result.template.availability.availableIds) {
    assert.equal(result.template.measurements[id]?.confidence, 0.9);
  }
});

test("measurementConfidence: null makes no claim instead of fabricating 1.0", () => {
  const result = buildTemplateFromReferenceImage(detection(), {
    providerId: "reference-scanner",
    measurementConfidence: null,
  });
  if (result.status !== ReferenceStatuses.ready) return assert.fail("expected ready");
  for (const id of result.template.availability.availableIds) {
    assert.equal(result.template.measurements[id]?.confidence, null);
  }
});

test("a bad scan fails with landmark issues and produces no template", () => {
  const result = buildTemplateFromReferenceImage(
    detection({ landmarks: fixtureLandmarks().slice(0, 5) }),
    OPTIONS,
  );
  assert.equal(result.status, ReferenceStatuses.invalid);
  if (result.status !== ReferenceStatuses.invalid) return;
  assert.equal(result.failure.kind, "invalid-reference");
  assert.ok((result.landmarkIssues ?? []).length > 0);
});

test("a scanned template drives the live engine exactly like any other template", () => {
  const result = buildTemplateFromReferenceImage(detection(), OPTIONS);
  if (result.status !== ReferenceStatuses.ready) return assert.fail("expected ready");
  const projection = templateMeasurementMap(result.template);
  assert.equal(projection.ok, true);
  if (!projection.ok) return;
  /* Same body measured against its own scan ⇒ a perfect match. */
  const match = calculateMatchPercent(fixtureLandmarks(), projection.map);
  assert.equal(match.percent, 100);
});

/* ------------------------------------------------------------------ */
/* Build-once: the reference image is NOT reprocessed per frame        */
/* ------------------------------------------------------------------ */

test("the cache builds once per image and returns the identical frozen object", () => {
  const cache = createReferenceImageTemplateCache();
  const first = cache.resolve(detection(), OPTIONS);
  for (let frame = 0; frame < 60; frame += 1) {
    const again = cache.resolve(detection(), OPTIONS);
    assert.equal(again, first, "every frame must reuse the same result object");
  }
  assert.equal(cache.buildCount(), 1);
});

test("a different image for the same pose is a different reference", () => {
  const cache = createReferenceImageTemplateCache();
  cache.resolve(detection(), OPTIONS);
  cache.resolve(detection({ sourceImageId: "asset://ref/2.jpg" }), OPTIONS);
  assert.equal(cache.buildCount(), 2);
  cache.clear();
  assert.equal(cache.buildCount(), 0);
});

test("failures are cached too — a broken image is not retried every frame", () => {
  const cache = createReferenceImageTemplateCache();
  const broken = detection({ landmarks: [] });
  const first = cache.resolve(broken, OPTIONS);
  const second = cache.resolve(broken, OPTIONS);
  assert.equal(first.status, ReferenceStatuses.invalid);
  assert.equal(second, first);
  assert.equal(cache.buildCount(), 1);
});
