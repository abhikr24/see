/**
 * tests/reference/normalization.test.ts — Unit 29.
 *
 * Proves the NORMALIZATION contract: after this stage the engine cannot tell
 * whether the numbers came from bundled JSON, an API body or a database row.
 * Every assertion is deterministic — no clock, no network, no randomness.
 */
import assert from "node:assert/strict";
import test from "node:test";

import {
  buildReferenceTemplate,
  canonicalMeasurementId,
  canonicalNumber,
  canonicalUnit,
  createRecordAdapter,
  ReferenceStatuses,
  templateMeasurementMap,
  toDegrees,
} from "../../shared/reference";
import { mutated, validRawPayload } from "./fixtures";

/* ------------------------------------------------------------------ */
/* Identifier normalization                                            */
/* ------------------------------------------------------------------ */

test("canonicalMeasurementId folds source spellings onto registry ids", () => {
  for (const spelling of ["leftElbow", "left_elbow", "LEFT-ELBOW", " Left Elbow ", "elbow_left"]) {
    assert.equal(canonicalMeasurementId(spelling), "leftElbow", spelling);
  }
});

test("canonicalMeasurementId refuses anything it cannot map exactly", () => {
  for (const unknown of ["leftEyebrow", "", "   ", 42, null, undefined, "elbow"]) {
    assert.equal(canonicalMeasurementId(unknown), null, String(unknown));
  }
});

test("a payload keyed in snake_case normalizes to canonical ids and records the renames", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = {
      left_elbow: { value: 90, confidence: 0.9 },
      RIGHT_ELBOW: { value: 92, confidence: 0.9 },
    };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  assert.deepEqual(built.template.availability.availableIds, ["leftElbow", "rightElbow"]);
  assert.deepEqual(built.template.normalization.renamedIds, {
    left_elbow: "leftElbow",
    RIGHT_ELBOW: "rightElbow",
  });
});

test("two source keys folding onto one registry id is rejected, never merged", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = {
      leftElbow: { value: 90, confidence: null },
      left_elbow: { value: 120, confidence: null },
      rightElbow: { value: 92, confidence: null },
    };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.invalid);
  if (built.status !== ReferenceStatuses.invalid) return;
  assert.ok(built.issues?.some((issue) => issue.code === "duplicate-measurement"));
});

/* ------------------------------------------------------------------ */
/* Unit normalization                                                  */
/* ------------------------------------------------------------------ */

test("canonicalUnit accepts known spellings, defaults absent to degrees, rejects junk", () => {
  assert.equal(canonicalUnit("deg"), "degrees");
  assert.equal(canonicalUnit("Radians"), "radians");
  assert.equal(canonicalUnit(undefined), "degrees");
  assert.equal(canonicalUnit("gradians"), null);
  assert.equal(canonicalUnit(7), null);
});

test("radian payloads convert exactly to degrees and the conversion is recorded", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["unit"] = "radians";
    draft["measurements"] = {
      leftElbow: { value: Math.PI / 2, confidence: null },
      rightElbow: { value: Math.PI, confidence: null },
    };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  const projection = templateMeasurementMap(built.template);
  assert.equal(projection.ok, true);
  if (!projection.ok) return;
  assert.ok(Math.abs((projection.map["leftElbow"] ?? 0) - 90) < 1e-9);
  assert.ok(Math.abs((projection.map["rightElbow"] ?? 0) - 180) < 1e-9);
  assert.deepEqual(built.template.normalization.convertedUnits, {
    leftElbow: "radians",
    rightElbow: "radians",
  });
});

test("a per-measurement unit overrides the payload unit", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["unit"] = "degrees";
    draft["measurements"] = {
      leftElbow: { value: Math.PI / 2, confidence: null, unit: "rad" },
      rightElbow: { value: 92, confidence: null },
    };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  assert.ok(Math.abs((built.template.measurements["leftElbow"]?.value ?? 0) - 90) < 1e-9);
  assert.equal(built.template.measurements["rightElbow"]?.value, 92);
});

test("an unrecognized unit is an explicit issue, never assumed to be degrees", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["unit"] = "furlongs";
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.invalid);
  if (built.status !== ReferenceStatuses.invalid) return;
  assert.ok(built.issues?.some((issue) => issue.code === "unknown-unit"));
});

test("radian values that convert outside the plausible band are rejected, not clamped", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["unit"] = "radians";
    draft["measurements"] = {
      leftElbow: { value: 6, confidence: null }, // ≈343° — impossible
      rightElbow: { value: 1, confidence: null },
    };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.notEqual(built.status, ReferenceStatuses.ready);
});

/* ------------------------------------------------------------------ */
/* Numeric-format normalization                                        */
/* ------------------------------------------------------------------ */

test("canonicalNumber reads numeric strings and rejects every non-number", () => {
  assert.equal(canonicalNumber("90"), 90);
  assert.equal(canonicalNumber(" 90.5 "), 90.5);
  assert.equal(canonicalNumber(90), 90);
  for (const bad of ["", "NaN", "Infinity", "abc", "9,0", true, null, undefined, {}, []]) {
    assert.equal(canonicalNumber(bad), null, JSON.stringify(bad));
  }
  assert.equal(canonicalNumber(Number.NaN), null);
  assert.equal(canonicalNumber(Number.POSITIVE_INFINITY), null);
});

test("string-encoded values and versions (as a DB row emits them) normalize and are recorded", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["schemaVersion"] = "1";
    draft["measurementVersion"] = "1";
    draft["measurements"] = { leftElbow: "90", rightElbow: 92 };
  });
  const built = buildReferenceTemplate({ providerId: "test", payload });
  assert.equal(built.status, ReferenceStatuses.ready);
  if (built.status !== ReferenceStatuses.ready) return;
  assert.equal(built.template.schemaVersion, 1);
  assert.equal(built.template.measurements["leftElbow"]?.value, 90);
  assert.deepEqual(built.template.normalization.coercedNumericIds, ["leftElbow"]);
});

test("toDegrees is exact for both units", () => {
  assert.equal(toDegrees(90, "degrees"), 90);
  assert.equal(toDegrees(Math.PI, "radians"), 180);
});

/* ------------------------------------------------------------------ */
/* Source-agnosticism: the whole point                                 */
/* ------------------------------------------------------------------ */

test("a database-style row and bundled JSON produce IDENTICAL engine projections", () => {
  /* Bundled-JSON style: canonical ids, degrees, numbers. */
  const bundled = buildReferenceTemplate({
    providerId: "local",
    payload: mutated(validRawPayload(), (draft) => {
      draft["templateId"] = "same/template";
      draft["measurements"] = { leftElbow: 90, rightElbow: 92, leftKnee: 170 };
    }),
  });

  /* Row style: snake_case columns, radians, NUMERIC-as-text. */
  const adapter = createRecordAdapter("row-adapter", "remote", {
    templateId: "template_id",
    poseId: "pose_id",
    schemaVersion: "schema_version",
    measurementVersion: "measurement_version",
    measurements: "measurements",
    unit: "angle_unit",
    provenance: "provenance",
  });
  const remote = buildReferenceTemplate(
    adapter.toRawPayload({
      template_id: "same/template",
      pose_id: "fixture-pose-1",
      schema_version: "1",
      measurement_version: "1",
      angle_unit: "radians",
      provenance: "test-fixture",
      measurements: {
        left_elbow: String(Math.PI / 2),
        right_elbow: (92 * Math.PI) / 180,
        knee_left: (170 * Math.PI) / 180,
      },
    }),
  );

  assert.equal(bundled.status, ReferenceStatuses.ready);
  assert.equal(remote.status, ReferenceStatuses.ready);
  if (bundled.status !== ReferenceStatuses.ready || remote.status !== ReferenceStatuses.ready) return;

  const a = templateMeasurementMap(bundled.template);
  const b = templateMeasurementMap(remote.template);
  assert.equal(a.ok && b.ok, true);
  if (!a.ok || !b.ok) return;
  assert.deepEqual(Object.keys(a.map).sort(), Object.keys(b.map).sort());
  for (const id of Object.keys(a.map)) {
    assert.ok(
      Math.abs((a.map[id] ?? 0) - (b.map[id] ?? 0)) < 1e-9,
      `${id}: ${String(a.map[id])} vs ${String(b.map[id])}`,
    );
  }
});

test("the record adapter never invents fields it was not given", () => {
  const adapter = createRecordAdapter("sparse", "remote", {
    templateId: "id",
    poseId: "pose",
    schemaVersion: "sv",
    measurementVersion: "mv",
    measurements: "m",
  });
  const raw = adapter.toRawPayload({ id: "x" });
  const payload = raw.payload as Record<string, unknown>;
  assert.equal(payload["templateId"], "x");
  assert.equal("poseId" in payload, false);
  assert.equal("measurements" in payload, false);
  /* And the pipeline reports exactly that, rather than filling gaps. */
  const built = buildReferenceTemplate(raw);
  assert.equal(built.status, ReferenceStatuses.invalid);
  if (built.status !== ReferenceStatuses.invalid) return;
  assert.ok(built.issues?.some((issue) => issue.code === "missing-field"));
});
