/**
 * tests/reference/pipeline.test.ts — parse/validate/normalize contract tests.
 * Deterministic: fixed fixtures, fixed order, no randomness, no IO.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  buildReferenceTemplate,
  MEASUREMENT_VERSION,
  MIN_MEASUREMENTS_FOR_COMPARISON,
  parseReferencePayload,
  REFERENCE_TEMPLATE_SCHEMA_VERSION,
  referenceVersionStamp,
  ReferenceStatuses,
  templateMeasurementMap,
} from "../../shared/reference";
import { mutated, validRawPayload } from "./fixtures";

const PROVIDER = "test-fixtures";

/* ------------------------------ VALID ------------------------------ */

test("valid reference template builds and is frozen, versioned, hashed", () => {
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload: validRawPayload() });
  assert.equal(result.status, ReferenceStatuses.ready);
  if (result.status !== ReferenceStatuses.ready) return;

  const template = result.template;
  assert.equal(template.templateId, "fixtures/valid-1");
  assert.equal(template.poseId, "fixture-pose-1");
  assert.equal(template.schemaVersion, REFERENCE_TEMPLATE_SCHEMA_VERSION);
  assert.equal(template.measurementVersion, MEASUREMENT_VERSION);
  assert.equal(template.availability.availableCount, 8);
  assert.deepEqual(template.availability.missingIds, []);
  /* Canonical sorted order + deep freeze. */
  assert.deepEqual(
    [...template.availability.availableIds],
    [...template.availability.availableIds].sort(),
  );
  assert.ok(Object.isFrozen(template));
  assert.ok(Object.isFrozen(template.measurements));
  assert.match(template.contentHash, /^[0-9a-f]{8}$/);
  /* Extraction yields the plain engine projection. */
  const projection = templateMeasurementMap(template);
  assert.equal(projection.ok, true);
  if (projection.ok) {
    assert.equal(projection.map["leftElbow"], 90);
    assert.equal(Object.keys(projection.map).length, 8);
  }
});

test("equivalent payloads produce identical hashes regardless of key order", () => {
  const a = validRawPayload();
  const b = mutated(validRawPayload(), (draft) => {
    const measurements = draft["measurements"] as Record<string, unknown>;
    draft["measurements"] = Object.fromEntries(Object.entries(measurements).reverse());
  });
  const first = buildReferenceTemplate({ providerId: PROVIDER, payload: a });
  const second = buildReferenceTemplate({ providerId: PROVIDER, payload: b });
  assert.equal(first.status, ReferenceStatuses.ready);
  assert.equal(second.status, ReferenceStatuses.ready);
  if (first.status === "ready" && second.status === "ready") {
    assert.equal(first.template.contentHash, second.template.contentHash);
  }
});

test("JSON string payloads parse exactly like object payloads", () => {
  const asString = buildReferenceTemplate({
    providerId: PROVIDER,
    payload: JSON.stringify(validRawPayload()),
  });
  assert.equal(asString.status, ReferenceStatuses.ready);
});

/* ---------------------------- MALFORMED ---------------------------- */

test("malformed template (array payload) is rejected as invalid, not thrown", () => {
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload: [1, 2, 3] });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected invalid");
  assert.equal(result.status, ReferenceStatuses.invalid);
  assert.equal(result.failure.kind, "invalid-reference");
  assert.equal(result.failure.retryable, false);
});

test("broken JSON string is a parse-error", () => {
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload: "{not json" });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected parse error");
  assert.equal(result.status, ReferenceStatuses.invalid);
  assert.equal(result.failure.kind, "parse-error");
});

test("missing required identity field is invalid", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    delete draft["poseId"];
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.invalid);
});

/* ----------------------------- VERSIONS ---------------------------- */

test("missing schema version and missing measurement version are invalid", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    delete draft["schemaVersion"];
    delete draft["measurementVersion"];
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected invalid");
  assert.equal(result.status, ReferenceStatuses.invalid);
  assert.equal(result.failure.kind, "invalid-reference");
});

test("incompatible measurement version is 'incompatible', never coerced", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurementVersion"] = 999;
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected incompatible");
  assert.equal(result.status, ReferenceStatuses.incompatible);
  assert.equal(result.failure.kind, "incompatible-reference");
});

test("unsupported schema version is 'incompatible'", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["schemaVersion"] = 2;
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.incompatible);
});

/* --------------------------- MEASUREMENTS -------------------------- */

test("invalid numeric value (non-finite) is rejected measurement-by-measurement", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    (draft["measurements"] as Record<string, unknown>)["leftElbow"] = { value: Number.NaN };
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected invalid");
  assert.equal(result.status, ReferenceStatuses.invalid);
  assert.match(result.failure.message, /leftElbow/);
});

test("value outside the plausibility band is invalid (not clamped)", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    (draft["measurements"] as Record<string, unknown>)["leftElbow"] = { value: 250 };
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.invalid);
});

test("invalid confidence (>1) is rejected", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    (draft["measurements"] as Record<string, unknown>)["leftElbow"] = {
      value: 90,
      confidence: 1.7,
    };
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.invalid);
});

test("unknown measurement id is rejected (registry is closed per version)", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    (draft["measurements"] as Record<string, unknown>)["torsoLean"] = { value: 12 };
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected invalid");
  assert.equal(result.status, ReferenceStatuses.invalid);
  assert.match(result.failure.message, /torsoLean/);
});

test("partial reference: valid subset builds and reports availability honestly", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = {
      leftElbow: { value: 90 },
      rightElbow: { value: 92 },
      leftKnee: { value: 170 },
    };
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.ready);
  if (result.status !== ReferenceStatuses.ready) return;
  assert.equal(result.template.availability.availableCount, 3);
  assert.equal(result.template.availability.missingIds.length, 5);
  assert.ok(result.template.availability.missingIds.includes("rightHip"));
  /* Nothing invented: extraction exposes exactly the three given values. */
  const projection = templateMeasurementMap(result.template);
  assert.equal(projection.ok, true);
  if (projection.ok) {
    assert.deepEqual(Object.keys(projection.map).sort(), ["leftElbow", "leftKnee", "rightElbow"]);
  }
});

test("below-minimum measurements (<2) is 'incomplete-reference'", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = { leftElbow: { value: 90 } };
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  if (result.status === ReferenceStatuses.ready) assert.fail("expected incomplete");
  assert.equal(result.status, ReferenceStatuses.incomplete);
  assert.equal(result.failure.kind, "incomplete-reference");
  assert.ok(MIN_MEASUREMENTS_FOR_COMPARISON >= 2);
});

test("empty measurements object is invalid", () => {
  const payload = mutated(validRawPayload(), (draft) => {
    draft["measurements"] = {};
  });
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.invalid);
});

/* ------------------------------ STAGES ----------------------------- */

test("parse stage distinguishes 'loaded' from 'invalid' explicitly", () => {
  const loaded = parseReferencePayload({ providerId: PROVIDER, payload: validRawPayload() });
  assert.equal(loaded.status, ReferenceStatuses.loaded);
  const broken = parseReferencePayload({ providerId: PROVIDER, payload: 42 });
  assert.equal(broken.status, ReferenceStatuses.invalid);
});

test("version stamp format is stable for hashing/greetings", () => {
  assert.equal(referenceVersionStamp(1, 1), "s1.m1");
});
