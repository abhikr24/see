/**
 * tests/reference/providers.test.ts — provider contract + independence tests.
 * Proves: catalog provider wraps the bundled data honestly, memory provider
 * exercises the identical pipeline, unconfigured provider reports
 * not-configured, and the engine result is provider-independent.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  createCatalogReferenceProvider,
  createMemoryReferenceProvider,
  createUnavailableReferenceProvider,
  CATALOG_REFERENCE_PROVIDER_ID,
  isReadyResolution,
  ReferenceStatuses,
  templateMeasurementMap,
} from "../../shared/reference";
import { getPoseById, getPoseCatalog } from "../../shared/data/poseCatalog";
import { calculateMatchPercent } from "../../shared/ml/poseMatch";
import { fixtureLandmarks, validRawPayload } from "./fixtures";

test("catalog provider reports source-available and yields a ready template", async () => {
  const provider = createCatalogReferenceProvider({ fidelityPolicy: "allow-approximate" });
  assert.equal(provider.describeSource().status, ReferenceStatuses.sourceAvailable);

  const pose = getPoseCatalog()[0];
  assert.ok(pose !== undefined, "bundled catalog must not be empty");
  const resolution = await provider.getReference({ poseId: pose.id });
  assert.equal(resolution.status, ReferenceStatuses.ready);
  if (!isReadyResolution(resolution)) return;

  const template = resolution.template;
  assert.equal(template.poseId, pose.id);
  assert.equal(template.metadata.provenance, "bundled-category-default");
  assert.equal(template.metadata.sourceProvider, CATALOG_REFERENCE_PROVIDER_ID);
  /* Honesty: authored defaults claim null confidence, not fabricated 1.0. */
  for (const id of template.availability.availableIds) {
    assert.equal(template.measurements[id]?.confidence ?? null, null);
  }
  /* The adapted template carries exactly the pose's shipped angles. */
  const projection = templateMeasurementMap(template);
  assert.equal(projection.ok, true);
  if (projection.ok && pose.referenceAngles !== null) {
    for (const [key, degrees] of Object.entries(pose.referenceAngles)) {
      assert.equal(projection.map[key], degrees);
    }
  }
});

test("catalog provider: unknown pose id resolves 'unavailable' with failure", async () => {
  const provider = createCatalogReferenceProvider({ fidelityPolicy: "allow-approximate" });
  const resolution = await provider.getReference({ poseId: "pose-does-not-exist" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected unavailable");
  assert.equal(resolution.status, ReferenceStatuses.unavailable);
  assert.equal(resolution.failure.kind, "reference-unavailable");
  assert.equal(resolution.failure.retryable, true);
});

test("memory provider routes seeds through the same pipeline (bad seed → structured failure)", async () => {
  const provider = createMemoryReferenceProvider([
    { poseId: "good", payload: validRawPayload() },
    { poseId: "bad", payload: { nonsense: true } },
  ]);
  const good = await provider.getReference({ poseId: "good" });
  assert.equal(good.status, ReferenceStatuses.ready);
  const bad = await provider.getReference({ poseId: "bad" });
  assert.equal(bad.status, ReferenceStatuses.invalid);
  const missing = await provider.getReference({ poseId: "missing" });
  assert.equal(missing.status, ReferenceStatuses.unavailable);
});

test("unavailable provider reports not-configured at source level, unavailable per pose", async () => {
  const provider = createUnavailableReferenceProvider("no credentials set");
  assert.equal(provider.describeSource().status, ReferenceStatuses.notConfigured);
  const resolution = await provider.getReference({ poseId: "anything" });
  assert.equal(resolution.status, ReferenceStatuses.unavailable);
});

test("engine behavior is provider-independent: catalog vs memory, bit-identical results", async () => {
  const pose = getPoseCatalog()[0];
  assert.ok(pose !== undefined);
  assert.ok(pose.referenceAngles !== null, "first catalog pose ships angles");

  /* Provider A: bundled catalog adapter. */
  const catalogProvider = createCatalogReferenceProvider({ fidelityPolicy: "allow-approximate" });
  const fromCatalog = await catalogProvider.getReference({ poseId: pose.id });
  assert.equal(fromCatalog.status, ReferenceStatuses.ready);
  if (!isReadyResolution(fromCatalog)) return;

  /* Provider B: memory provider seeded with the SAME numbers but a different
     template id + provenance — content, not origin, must drive the engine. */
  const measurements: Record<string, { value: number; confidence: null }> = {};
  for (const [key, degrees] of Object.entries(pose.referenceAngles)) {
    measurements[key] = { value: degrees, confidence: null };
  }
  const memoryProvider = createMemoryReferenceProvider([
    {
      poseId: pose.id,
      payload: {
        templateId: "memory/duplicate-of-catalog",
        poseId: pose.id,
        schemaVersion: 1,
        measurementVersion: 1,
        measurements,
        metadata: { provenance: "test-fixture" },
      },
    },
  ]);
  const fromMemory = await memoryProvider.getReference({ poseId: pose.id });
  assert.equal(fromMemory.status, ReferenceStatuses.ready);
  if (!isReadyResolution(fromMemory)) return;

  /* Same content ⇒ same content hash, regardless of provider or templateId. */
  assert.equal(fromCatalog.template.contentHash, fromMemory.template.contentHash);

  /* Engine consumes projections identically from both providers. */
  const landmarks = fixtureLandmarks();
  const mapA = templateMeasurementMap(fromCatalog.template);
  const mapB = templateMeasurementMap(fromMemory.template);
  assert.ok(mapA.ok && mapB.ok);
  if (!mapA.ok || !mapB.ok) return;
  const resultA = calculateMatchPercent(landmarks, mapA.map);
  const resultB = calculateMatchPercent(landmarks, mapB.map);
  assert.deepEqual(resultA, resultB);
  assert.ok(resultA.percent !== null, "fixture body must be scoreable");
});

test("engine parity: extracted projection matches the legacy direct map exactly", async () => {
  const pose = getPoseCatalog()[0];
  assert.ok(pose !== undefined);
  const provider = createCatalogReferenceProvider({ fidelityPolicy: "allow-approximate" });
  const resolution = await provider.getReference({ poseId: pose.id });
  if (!isReadyResolution(resolution)) {
    assert.fail("catalog pose must resolve ready");
  }
  const projection = templateMeasurementMap(resolution.template);
  assert.ok(projection.ok);
  if (!projection.ok) return;
  const landmarks = fixtureLandmarks();
  const viaTemplate = calculateMatchPercent(landmarks, projection.map);
  const viaLegacy = calculateMatchPercent(landmarks, pose.referenceAngles);
  assert.deepEqual(viaTemplate, viaLegacy);
});

test("getPoseById stays the single catalog lookup the adapter uses", () => {
  const pose = getPoseCatalog()[0];
  assert.ok(pose !== undefined);
  assert.equal(getPoseById(pose.id)?.id, pose.id);
});
