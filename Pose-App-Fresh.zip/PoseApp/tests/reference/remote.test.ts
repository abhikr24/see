/**
 * tests/reference/remote.test.ts — Unit 29.
 *
 * Proves the FUTURE-BACKEND SEAM works without a backend: a remote provider
 * is configuration (field mapping) + a transport closure, and everything
 * downstream — validation, normalization, template, engine projection — is
 * already shared. No live service, no credentials, no schema guesses.
 */
import assert from "node:assert/strict";
import test from "node:test";

import {
  createRecordAdapter,
  createReferenceProviderForKind,
  createRemoteReferenceProvider,
  describeProviderKind,
  isReadyResolution,
  PROVIDER_KIND_DESCRIPTIONS,
  referenceNetworkFailure,
  ReferenceStatuses,
  templateMeasurementMap,
  type SourceRecord,
} from "../../shared/reference";

/* A hypothetical row shape. It is the TEST's invention, declared here, and
   deliberately NOT mirrored anywhere in shared/ — production guesses nothing
   about any future table. */
const adapter = createRecordAdapter("test-row-adapter", "test-remote", {
  templateId: "id",
  poseId: "pose_id",
  schemaVersion: "schema_version",
  measurementVersion: "measurement_version",
  measurements: "angles",
  provenance: "provenance",
  capturedAt: "captured_at",
  unit: "unit",
});

function row(overrides: Record<string, unknown> = {}): SourceRecord {
  return {
    id: "remote/row-1",
    pose_id: "portraits-1",
    schema_version: 1,
    measurement_version: 1,
    unit: "degrees",
    provenance: "measured-scan",
    captured_at: "2024-01-01T00:00:00.000Z",
    angles: { left_elbow: 90, right_elbow: 92, left_knee: 170 },
    ...overrides,
  };
}

function provider(
  fetchRecord: (poseId: string) => Promise<SourceRecord | null | ReturnType<typeof referenceNetworkFailure>>,
  fidelityPolicy: "measured-only" | "allow-approximate" = "measured-only",
) {
  return createRemoteReferenceProvider({
    providerId: "test-remote",
    adapter,
    fetchRecord,
    fidelityPolicy,
    detail: "Deterministic in-test transport.",
  });
}

test("a measured remote row becomes a ready template with no engine changes", async () => {
  const resolution = await provider(async () => row()).getReference({ poseId: "portraits-1" });
  assert.equal(isReadyResolution(resolution), true);
  if (!isReadyResolution(resolution)) return;
  assert.equal(resolution.template.metadata.provenance, "measured-scan");
  assert.equal(resolution.template.metadata.fidelity, "measured");
  assert.equal(resolution.template.metadata.capturedAt, "2024-01-01T00:00:00.000Z");
  const projection = templateMeasurementMap(resolution.template);
  assert.equal(projection.ok, true);
  if (!projection.ok) return;
  assert.deepEqual(projection.map, { leftElbow: 90, leftKnee: 170, rightElbow: 92 });
});

test("'no row' is an explicit unavailable state", async () => {
  const resolution = await provider(async () => null).getReference({ poseId: "portraits-1" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected unavailable");
  assert.equal(resolution.status, ReferenceStatuses.unavailable);
  assert.equal(resolution.failure.kind, "reference-unavailable");
});

test("a transport-classified failure passes through verbatim", async () => {
  const resolution = await provider(async () =>
    referenceNetworkFailure("socket closed", { providerId: "test-remote" }),
  ).getReference({ poseId: "portraits-1" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected failure");
  assert.equal(resolution.failure.kind, "network-failure");
  assert.equal(resolution.failure.message, "socket closed");
  assert.equal(resolution.failure.retryable, true);
});

test("a thrown transport error becomes provider-failure, never a template", async () => {
  const resolution = await provider(async () => {
    throw new Error("boom");
  }).getReference({ poseId: "portraits-1" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected failure");
  assert.equal(resolution.failure.kind, "provider-failure");
  assert.ok(resolution.failure.message.includes("boom"));
});

test("malformed remote data is rejected by the same validator", async () => {
  const resolution = await provider(async () =>
    row({ angles: { left_elbow: Number.NaN, right_elbow: 92 } }),
  ).getReference({ poseId: "portraits-1" });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected invalid");
  assert.equal(resolution.status, ReferenceStatuses.invalid);
  assert.equal(resolution.failure.kind, "invalid-reference");
});

test("an incompatible measurement version from a remote source is explicit", async () => {
  const resolution = await provider(async () => row({ measurement_version: 99 })).getReference({
    poseId: "portraits-1",
  });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected incompatible");
  assert.equal(resolution.status, ReferenceStatuses.incompatible);
  assert.equal(resolution.failure.kind, "incompatible-reference");
});

test("a row for the wrong pose is refused instead of coached against", async () => {
  const resolution = await provider(async () => row({ pose_id: "somebody-else" })).getReference({
    poseId: "portraits-1",
  });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected invalid");
  assert.equal(resolution.status, ReferenceStatuses.invalid);
  assert.equal(resolution.failure.kind, "provider-failure");
});

test("remote approximate data is blocked by a measured-only policy", async () => {
  const resolution = await provider(async () => row({ provenance: "remote-source" })).getReference({
    poseId: "portraits-1",
  });
  if (resolution.status === ReferenceStatuses.ready) assert.fail("expected unavailable");
  assert.equal(resolution.failure.kind, "approximate-only");
});

/* ------------------------------------------------------------------ */
/* The declared provider boundary                                      */
/* ------------------------------------------------------------------ */

test("the registry declares four kinds and implements only the justified ones", () => {
  assert.deepEqual(
    PROVIDER_KIND_DESCRIPTIONS.map((entry) => entry.kind).sort(),
    ["api", "local", "supabase", "test"],
  );
  assert.equal(describeProviderKind("local").implemented, true);
  assert.equal(describeProviderKind("supabase").implemented, false);
  assert.equal(describeProviderKind("api").implemented, false);
});

test("unimplemented kinds resolve to an honest not-configured provider", async () => {
  for (const kind of ["supabase", "api"] as const) {
    const instance = createReferenceProviderForKind({ kind, fidelityPolicy: "allow-approximate" });
    assert.equal(instance.describeSource().status, ReferenceStatuses.notConfigured);
    const resolution = await instance.getReference({ poseId: "portraits-1" });
    if (resolution.status === ReferenceStatuses.ready) assert.fail(`${kind} must not be ready`);
    assert.equal(resolution.status, ReferenceStatuses.unavailable);
    assert.equal(resolution.failure.kind, "reference-unavailable");
  }
});

test("the local kind is a working provider", async () => {
  const instance = createReferenceProviderForKind({
    kind: "local",
    fidelityPolicy: "allow-approximate",
  });
  assert.equal(instance.describeSource().status, ReferenceStatuses.sourceAvailable);
});

test("production wiring cannot construct a test provider", async () => {
  const instance = createReferenceProviderForKind({
    kind: "test",
    fidelityPolicy: "allow-approximate",
  });
  assert.equal(instance.describeSource().status, ReferenceStatuses.notConfigured);
});
