/**
 * tests/reference/session.test.ts — session pin contract tests.
 * Once a session pins a validated template, its identity/versions cannot
 * silently change: identical re-resolutions pass, swaps surface as data.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  assertPinnedResolution,
  buildReferenceTemplate,
  compareWithPin,
  pinReferenceForSession,
  ReferenceStatuses,
} from "../../shared/reference";
import { mutated, validRawPayload } from "./fixtures";

const PROVIDER = "test-fixtures";

function readyTemplate(payload: Record<string, unknown>) {
  const result = buildReferenceTemplate({ providerId: PROVIDER, payload });
  assert.equal(result.status, ReferenceStatuses.ready);
  if (result.status !== ReferenceStatuses.ready) throw new Error("fixture must build");
  return result.template;
}

test("pin captures a frozen identity snapshot", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-1", 1_000);
  assert.equal(pin.sessionToken, "session-1");
  assert.equal(pin.identity.templateId, template.templateId);
  assert.equal(pin.identity.measurementVersion, template.measurementVersion);
  assert.equal(pin.identity.contentHash, template.contentHash);
  assert.ok(Object.isFrozen(pin));
  assert.ok(Object.isFrozen(pin.identity));
});

test("identical re-resolution passes the pin check", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-1", 1_000);
  const refetch = readyTemplate(validRawPayload());
  const comparison = compareWithPin(pin, refetch);
  assert.equal(comparison.relation, "identical");
  const check = assertPinnedResolution(pin, {
    status: ReferenceStatuses.ready,
    template: refetch,
  });
  assert.equal(check.ok, true);
});

test("same template id with changed content is stale-data", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-1", 1_000);
  const drifted = readyTemplate(
    mutated(validRawPayload(), (draft) => {
      (draft["measurements"] as Record<string, unknown>)["leftElbow"] = { value: 95 };
    }),
  );
  const comparison = compareWithPin(pin, drifted);
  assert.equal(comparison.relation, "same-id-different-content");
  const check = assertPinnedResolution(pin, {
    status: ReferenceStatuses.ready,
    template: drifted,
  });
  assert.equal(check.ok, false);
  if (!check.ok) {
    assert.equal(check.failure.kind, "stale-data");
    assert.equal(check.failure.retryable, true);
  }
});

test("different template id is incompatible with the session", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-1", 1_000);
  const other = readyTemplate(
    mutated(validRawPayload(), (draft) => {
      draft["templateId"] = "fixtures/other-template";
    }),
  );
  const check = assertPinnedResolution(pin, {
    status: ReferenceStatuses.ready,
    template: other,
  });
  assert.equal(check.ok, false);
  if (!check.ok) {
    assert.equal(check.failure.kind, "incompatible-reference");
  }
});

test("failed mid-session re-resolution surfaces the provider failure verbatim", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-1", 1_000);
  const check = assertPinnedResolution(pin, {
    status: ReferenceStatuses.unavailable,
    failure: {
      kind: "network-failure",
      message: "offline",
      retryable: true,
    },
  });
  assert.equal(check.ok, false);
  if (!check.ok) {
    assert.equal(check.failure.kind, "network-failure");
  }
});

test("hash includes version stamps: same values at another stamp hash differently", () => {
  const template = readyTemplate(validRawPayload());
  const pin = pinReferenceForSession(template, "session-9", 500);
  assert.equal(pin.identity.measurementVersion, 1);
  /* Forge a same-id template stamped with a future measurement version by
     rebuilding through the pin's comparator path (identity extraction). */
  const reforged = {
    ...template,
    measurementVersion: 2,
    contentHash: "deadbeef",
  };
  const comparison = compareWithPin(pin, reforged);
  assert.equal(comparison.relation, "same-id-different-content");
  const check = assertPinnedResolution(pin, {
    status: ReferenceStatuses.ready,
    template: reforged,
  });
  assert.equal(check.ok, false);
  if (!check.ok) {
    assert.equal(check.failure.kind, "stale-data");
  }
});
