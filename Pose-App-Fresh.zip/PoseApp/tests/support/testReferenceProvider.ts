/**
 * tests/support/testReferenceProvider.ts — THE DETERMINISTIC TEST PROVIDER.
 *
 * Test-only (verify-reference-architecture.mjs rule C forbids any production
 * tree from importing tests/). Its purpose is architectural proof, not
 * coverage padding:
 *
 *   A brand-new reference SOURCE — with a shape nothing in the codebase has
 *   ever seen: snake_case ids, radians, string-encoded numbers, a nested
 *   envelope and extra vendor fields — is inserted by writing ONE adapter and
 *   ONE provider. No file in shared/ml/** (the mathematics) and no file in
 *   shared/coaching/** (the semantics) changes, because everything downstream
 *   of RAW DATA is source-agnostic:
 *
 *     TEST SOURCE → adapter → validator → normalizer → ReferencePoseTemplate
 *                 → the SAME pose engine → the SAME coaching layer
 *
 * It also COUNTS its own calls, so the hot-path test can prove that the frame
 * loop never re-resolves, re-parses or re-validates reference data.
 *
 * Nothing here is production data: provenance is always "test-fixture", the
 * values are derived from the caller's own numbers, and no pose id from the
 * bundled catalog is referenced.
 */
import type { ReferenceSourceAdapter } from "../../shared/reference/adapter";
import { referenceUnavailable } from "../../shared/reference/failure";
import { buildReferenceTemplate, type RawReferencePayload } from "../../shared/reference/pipeline";
import type {
  ReferenceProvider,
  ReferenceRequest,
  ReferenceResolution,
  ReferenceSourceState,
} from "../../shared/reference/provider";
import { ReferenceStatuses } from "../../shared/reference/status";

export const TEST_PROVIDER_ID = "test-lab-export";

/**
 * The foreign source shape. Deliberately unlike the bundled catalog AND
 * unlike the generic record mapping: nested measurements, snake_case joint
 * keys, radians, numbers serialized as strings, plus vendor noise fields the
 * adapter must ignore rather than forward.
 */
export interface LabExportRecord {
  readonly export_id: string;
  readonly subject_pose: string;
  readonly format: { readonly schema: string; readonly semantics: string };
  readonly angles: {
    readonly unit: string;
    readonly readings: Readonly<Record<string, string | number>>;
  };
  /** Ignored by the adapter on purpose — proof that adapters don't guess. */
  readonly vendor_notes?: string;
}

/** camelCase measurement id → the lab's snake_case spelling. */
function snake(id: string): string {
  return id.replace(/([a-z0-9])([A-Z])/g, "$1_$2").toLowerCase();
}

/**
 * Build a lab record from plain degrees. The degrees→radians conversion and
 * the number→string encoding happen HERE, in the source, so the normalizer
 * (not the test) is what turns them back into canonical degrees.
 */
export function labRecordFromDegrees(
  poseId: string,
  degrees: Readonly<Record<string, number>>,
  options?: { readonly schema?: string; readonly semantics?: string },
): LabExportRecord {
  const readings: Record<string, string> = {};
  for (const [id, value] of Object.entries(degrees)) {
    readings[snake(id)] = ((value * Math.PI) / 180).toFixed(9);
  }
  return {
    export_id: `${TEST_PROVIDER_ID}/${poseId}`,
    subject_pose: poseId,
    format: { schema: options?.schema ?? "1", semantics: options?.semantics ?? "1" },
    angles: { unit: "rad", readings },
    vendor_notes: "ignored by the adapter",
  };
}

/**
 * THE ADAPTER — pure shape translation. It does not validate, clamp, repair
 * or convert: the radians stay radians and the strings stay strings, and the
 * declared unit travels with them so the NORMALIZER does the conversion.
 */
export const labExportAdapter: ReferenceSourceAdapter<LabExportRecord> = {
  id: "lab-export-adapter",
  toRawPayload(record: LabExportRecord): RawReferencePayload {
    return {
      providerId: TEST_PROVIDER_ID,
      payload: {
        templateId: record.export_id,
        poseId: record.subject_pose,
        schemaVersion: record.format.schema,
        measurementVersion: record.format.semantics,
        unit: record.angles.unit,
        measurements: record.angles.readings,
        metadata: {
          provenance: "test-fixture",
          sourceProvider: TEST_PROVIDER_ID,
          note: "Deterministic test source — never production reference data.",
        },
      },
    };
  },
};

export interface TestReferenceProvider extends ReferenceProvider {
  /** How many times the frame loop (or anyone) asked for a reference. */
  readonly calls: () => number;
}

/**
 * The provider. Owns "IO" (a Map lookup), routes everything through the one
 * shared pipeline, and answers with structured resolutions — never throws,
 * never substitutes another pose's data.
 */
export function createTestReferenceProvider(
  records: readonly LabExportRecord[],
): TestReferenceProvider {
  const byPoseId = new Map(records.map((record) => [record.subject_pose, record]));
  let callCount = 0;

  return {
    id: TEST_PROVIDER_ID,
    calls: () => callCount,
    describeSource(): ReferenceSourceState {
      return {
        status: ReferenceStatuses.sourceAvailable,
        providerId: TEST_PROVIDER_ID,
        detail: `Deterministic test source with ${byPoseId.size} export(s).`,
      };
    },
    getReference(request: ReferenceRequest): Promise<ReferenceResolution> {
      callCount += 1;
      const record = byPoseId.get(request.poseId);
      if (record === undefined) {
        return Promise.resolve({
          status: ReferenceStatuses.unavailable,
          failure: referenceUnavailable(
            `No lab export for pose "${request.poseId}".`,
            { providerId: TEST_PROVIDER_ID },
          ),
        });
      }
      const built = buildReferenceTemplate(labExportAdapter.toRawPayload(record));
      if (built.status === ReferenceStatuses.ready) {
        return Promise.resolve({ status: ReferenceStatuses.ready, template: built.template });
      }
      return Promise.resolve({ status: built.status, failure: built.failure });
    },
  };
}
