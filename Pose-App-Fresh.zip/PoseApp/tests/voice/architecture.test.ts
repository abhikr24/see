/**
 * tests/voice/architecture.test.ts — Unit 35 (Part 4.4): STATIC PROOF THAT
 * THE CALLERS ACTUALLY USE THE CENTRAL LANGUAGE/VOICE SEAM.
 *
 * A pure-function test can prove the decision logic is right and still miss
 * the real defect of this area: a caller that quietly re-implements the
 * routing, hardcodes a locale, or reads/writes the preference through a
 * second storage mechanism. These assertions read the actual source files,
 * with comments stripped, exactly like the Unit 34 timing suite does.
 *
 * CODE VERIFIED only — no device, no audio.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";

/**
 * The suite is compiled to .test-build/ before it runs, so __dirname points
 * at emitted JS. Walk up to the first ancestor that holds the real sources.
 */
function findRepoRoot(): string {
  let current = __dirname;
  for (let depth = 0; depth < 8; depth += 1) {
    if (
      existsSync(join(current, "shared", "voice", "voiceSelection.ts")) &&
      existsSync(join(current, "mobile", "src", "core", "voice", "ttsService.ts"))
    ) {
      return current;
    }
    const parent = dirname(current);
    if (parent === current) break;
    current = parent;
  }
  throw new Error("repository source root not found from " + __dirname);
}

const REPO_ROOT = findRepoRoot();

function source(...parts: string[]): string {
  return readFileSync(join(REPO_ROOT, ...parts), "utf8")
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "");
}

const TTS = source("mobile", "src", "core", "voice", "ttsService.ts");
const CAMERA = source(
  "mobile",
  "src",
  "features",
  "camera",
  "presentation",
  "screens",
  "CameraTab.tsx",
);
const SETTINGS_STORE = source("mobile", "src", "shared", "stores", "settingsStore.ts");
const SETTINGS_SCREEN = source(
  "mobile",
  "src",
  "features",
  "settings",
  "presentation",
  "screens",
  "SettingsScreen.tsx",
);

/* ----------------------- language routing is central -------------------- */

test("the camera reaches speech only through the shared routing gate", () => {
  assert.ok(
    CAMERA.includes("routeCoachingSpeech("),
    "CameraTab must use the central routing gate",
  );
  const coachingCalls = CAMERA.match(/speakCoaching\s*\(/g) ?? [];
  assert.equal(coachingCalls.length, 1, "coaching keeps a single call site");
  /* The gate's language, not a raw settings string, is what reaches TTS. */
  assert.ok(/speakCoaching\(\s*route\.state,\s*route\.language,/.test(CAMERA));
});

test("the speech service normalizes the language exactly once, centrally", () => {
  assert.ok(TTS.includes("resolveInstructionLanguage("));
  /* No locale literal anywhere in the speech service: the chain lives in
     shared/voice/locales.ts so device and preview cannot diverge. */
  assert.ok(!/["'](hi|en)-[A-Za-z]{2}["']/.test(TTS), "hardcoded locale tag");
});

test("no caller hardcodes a language-specific coaching branch", () => {
  /* Comparing the language setting to a literal in a caller is how
     per-language semantic logic creeps back in. */
  assert.ok(!/voiceLanguage\s*===\s*['"]hi['"]/.test(CAMERA));
  assert.ok(!/voiceLanguage\s*===\s*['"]en['"]/.test(CAMERA));
  assert.ok(!/language\s*===\s*['"]hi['"]\s*\?/.test(TTS));
});

/* ------------------------ voice + preference seam ----------------------- */

test("voice discovery is the runtime catalog, never a hardcoded list", () => {
  assert.ok(TTS.includes("Speech.getAvailableVoicesAsync()"));
  assert.ok(TTS.includes("resolveVoiceSelection("));
  /* The engine is given an identifier only when one was resolved. */
  assert.ok(/if \(voice\.voiceId !== null\) \{/.test(TTS));
});

test("the voice preference is persisted through the one settings/MMKV seam", () => {
  assert.ok(SETTINGS_STORE.includes("setVoiceId"));
  assert.ok(SETTINGS_STORE.includes("voiceIds"));
  /* No second persistence mechanism, and no storage inside the TTS service. */
  for (const [name, code] of [
    ["ttsService", TTS],
    ["settingsStore", SETTINGS_STORE],
    ["SettingsScreen", SETTINGS_SCREEN],
    ["CameraTab", CAMERA],
  ] as const) {
    assert.ok(!/AsyncStorage/.test(code), `${name} must not add AsyncStorage`);
    assert.ok(!/localStorage/.test(code), `${name} must not add localStorage`);
  }
  assert.ok(
    !/new MMKV\(/.test(TTS),
    "the speech service owns no storage of its own",
  );
});

test("the settings picker offers only runtime-reported voices", () => {
  assert.ok(SETTINGS_SCREEN.includes("ttsService.voiceOptions("));
  assert.ok(SETTINGS_SCREEN.includes("AUTOMATIC_VOICE_ID"));
  /* No literal voice identifiers in the UI. */
  assert.ok(!/identifier:\s*['"]/.test(SETTINGS_SCREEN));
});

/* --------------------- voice-guidance switch semantics ------------------ */

test("voice guidance OFF is enforced inside the speech service", () => {
  assert.ok(TTS.includes("setVoiceGuidanceEnabled"));
  const gates = TTS.match(/if \(!this\.voiceGuidanceEnabled\) return false;/g) ?? [];
  assert.ok(gates.length >= 2, "the gate must cover the coaching and core paths");
  assert.ok(CAMERA.includes("ttsService.setVoiceGuidanceEnabled(voiceEnabled)"));
});

test("the semantic state is produced regardless of the voice switch", () => {
  /* decisionToCoachingState must not sit inside a voiceEnabled branch. */
  const index = CAMERA.indexOf("decisionToCoachingState(");
  assert.ok(index > 0);
  const before = CAMERA.slice(Math.max(0, index - 400), index);
  assert.ok(
    !/voiceEnabled\s*&&[^;]*$/.test(before),
    "coaching state must not be gated by the voice switch",
  );
});

/* ----------------------- layering stays intact -------------------------- */

test("the pose engine never imports the voice layer, and vice versa", () => {
  const engineFiles = [
    ["shared", "ml", "analysis", "engine.ts"],
    ["shared", "ml", "analysis", "compare.ts"],
    ["shared", "ml", "poseMatch.ts"],
  ];
  for (const parts of engineFiles) {
    const code = source(...parts);
    assert.ok(!/from\s+["'][^"']*voice/.test(code), parts.join("/"));
    assert.ok(!/expo-speech/.test(code), parts.join("/"));
  }
  for (const file of ["locales.ts", "voiceSelection.ts", "routing.ts"]) {
    const code = source("shared", "voice", file);
    assert.ok(!/expo-speech|react-native/.test(code), file);
    /* The voice layer may know the semantic CONTRACT, never the geometry. */
    assert.ok(!/from\s+["'][^"']*\/ml\//.test(code), `${file} imports geometry`);
    assert.ok(!/angle|landmark|threshold/i.test(code), `${file} touches geometry`);
  }
});
