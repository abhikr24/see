/**
 * tests/voice/languageContract.test.ts — THE LANGUAGE-RESOLUTION CONTRACT,
 * PINNED ONCE, FOR EVERY CONSUMER.
 *
 * This suite exists because three separate defects (locale fallback, voice
 * fallback, routing fallback) all traced back to one root question: "what
 * does an unreadable language value mean?" The project answered it in Unit
 * 37 and this file pins the final contract so no layer can drift apart
 * again:
 *
 *   A. FRESH-INSTALL DEFAULT
 *      A new user coaches in Hindi (`DEFAULT_INSTRUCTION_LANGUAGE === "hi"`).
 *
 *   B. EXPLICIT USER SELECTION
 *      A recognisable stored value is honoured verbatim — English stays
 *      English, Hindi stays Hindi — including legacy spellings and locale
 *      tags written by older builds ("en-IN", "English", "hinglish", …).
 *
 *   C. INVALID / UNKNOWN STORED VALUE
 *      undefined / null / non-strings / "" / unsupported codes / corrupted
 *      payloads behave EXACTLY as if no preference was ever expressed: the
 *      canonical default. One deliberate fallback, decided in ONE place
 *      (`resolveInstructionLanguage` in shared/voice/locales), consumed by
 *      routing, phrase pool, locale tables, voice selection, visible
 *      coaching and the settings migration alike.
 *
 * Pure functions, deterministic, no device, no audio, no network. Whether a
 * physical phone owns a Hindi voice is deliberately NOT claimed here — only
 * which language the app asks for, and that only a same-language voice may
 * answer.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  DEFAULT_CAMERA_SETTINGS,
  DEFAULT_INSTRUCTION_LANGUAGE,
  type InstructionLanguage,
} from "../../shared/types/settings";
import {
  INSTRUCTION_LANGUAGES,
  UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK,
  matchLocaleToLanguage,
  normalizeInstructionLanguage,
  normalizedLocaleChain,
  primaryLocaleFor,
  rankVoicesForLanguage,
  resolveInstructionLanguage,
  resolveVoiceSelection,
  routeCoachingSpeech,
  type DeviceVoice,
} from "../../shared/voice";
import {
  instructionPool,
  pickInstruction,
  resolveInstructionPool,
} from "../../shared/constants/poseInstructions";
import { selectCoachingPhrase, type CoachingState } from "../../shared/coaching";
import { cameraStatusCopyFor } from "../../shared/camera/cameraStatusCopy";
import { visibleCoachingFor } from "../../shared/content/visibleCoaching";
import {
  SETTINGS_PERSIST_VERSION,
  migrateCameraSettings,
  resolvePersistedInstructionLanguage,
} from "../../shared/settings/settingsMigration";

/* A speakable correction in one fixed category, reused everywhere so the
   ONLY variable across assertions is the language. */
const STATE: CoachingState = {
  kind: "correction",
  token: "LEFT_ELBOW_DECREASE_MINOR",
  category: "hand_left_bend",
  measurementId: "leftElbow",
  direction: "decrease",
  severity: "minor",
  intensity: "gentle",
  confidence: 0.92,
  stableFrames: 6,
  heldByHysteresis: false,
  unavailableReason: null,
  speakable: true,
};

const CATALOG: readonly DeviceVoice[] = [
  { identifier: "en-in-x-ene-local", language: "en-IN", quality: "Enhanced" },
  { identifier: "hi-in-x-hia-local", language: "hi-IN", quality: "Enhanced" },
];

/** The corrupted-MMKV-shape catalogue: every case must give the SAME answer. */
const UNREADABLE: readonly unknown[] = [
  undefined,
  null,
  "",
  "   ",
  7,
  Number.NaN,
  {},
  [],
  "fr",
  "xx",
  "kl-KL",
  "de-DE",
];

/* ───────────────────── A · FRESH-INSTALL DEFAULT ───────────────────── */

test("A — a fresh install coaches in Hindi, and nothing else changed", () => {
  assert.equal(DEFAULT_CAMERA_SETTINGS.instructionLanguage, "hi");
  assert.equal(DEFAULT_INSTRUCTION_LANGUAGE, "hi");
  /* The two conceptually-different things genuinely share one value today,
     and the fallback is a named, deliberate decision — not a coincidence. */
  assert.equal(UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK, DEFAULT_INSTRUCTION_LANGUAGE);
  /* Voice pickers start automatic; no invented voice identity. */
  assert.deepEqual(DEFAULT_CAMERA_SETTINGS.voiceIds, { en: null, hi: null });
  /* The supported set is still exactly the two authored languages. */
  assert.deepEqual([...INSTRUCTION_LANGUAGES], ["en", "hi"]);
});

/* ───────────────── B · EXPLICIT SELECTION IS HONOURED ───────────────── */

test("B — explicit choices and their historical spellings are honoured", () => {
  const honoured: readonly (readonly [unknown, InstructionLanguage])[] = [
    ["hi", "hi"],
    ["en", "en"],
    ["HI", "hi"],
    ["EN", "en"],
    ["hi-IN", "hi"],
    ["en-IN", "en"],
    ["en-US", "en"],
    ["en_US", "en"],
    ["hin-IND", "hi"],
    ["hin", "hi"],
    ["eng", "en"],
    /* Legacy label spellings written by older builds / hand-edited stores. */
    ["english", "en"],
    ["English", "en"],
    ["ENGLISH", "en"],
    ["hindi", "hi"],
    ["Hindi", "hi"],
    ["hinglish", "hi"],
    ["Hinglish", "hi"],
    ["  en  ", "en"],
  ];
  for (const [raw, expected] of honoured) {
    assert.equal(normalizeInstructionLanguage(raw), expected, `normalize(${String(raw)})`);
    assert.equal(resolveInstructionLanguage(raw), expected, `resolve(${String(raw)})`);
    const route = routeCoachingSpeech({
      state: STATE,
      voiceGuidanceEnabled: true,
      language: raw,
    });
    assert.equal(route.language, expected, `route(${String(raw)})`);
    assert.equal(route.deliverToSpeech, true);
  }
  /* The two banks genuinely answer in their own language. */
  assert.ok(instructionPool("hand_left_bend", "hi", "gentle").length > 0);
  assert.ok(instructionPool("hand_left_bend", "en", "gentle").length > 0);
});

/* ───────────────── C · UNREADABLE VALUES — ONE ANSWER EVERYWHERE ───────────────── */

test("C — unreadable values degrade to the canonical default through EVERY consumer", () => {
  for (const raw of UNREADABLE) {
    const label = `value ${JSON.stringify(raw) ?? String(raw)}`;
    const expected = UNREADABLE_INSTRUCTION_LANGUAGE_FALLBACK;

    /* 1 · the canonical gate itself */
    assert.equal(resolveInstructionLanguage(raw), expected, label);
    assert.equal(normalizeInstructionLanguage(raw), null, label);

    /* 2 · routing — the decision phrase selection and TTS share */
    const route = routeCoachingSpeech({
      state: STATE,
      voiceGuidanceEnabled: true,
      language: raw,
    });
    assert.equal(route.language, expected, label);

    /* 3 · phrase selection reports the language it actually spoke */
    const phrase = selectCoachingPhrase(STATE, raw as InstructionLanguage);
    assert.ok(phrase !== null, label);
    assert.equal(phrase.language, expected, label);
    assert.ok(
      instructionPool("hand_left_bend", expected, "gentle").includes(phrase.text),
      `${label}: the line comes from the resolved language's pool`,
    );

    /* 4 · the raw pool layer agrees (and cannot throw) */
    const pool = resolveInstructionPool("hand_left_bend", raw as InstructionLanguage, "gentle");
    assert.equal(pool.language, expected, label);
    assert.ok(pool.phrases.length > 0, label);
    assert.equal(
      pickInstruction("hand_left_bend", raw as InstructionLanguage, { peek: true })?.language,
      expected,
      label,
    );

    /* 5 · the locale tables agree */
    assert.equal(primaryLocaleFor(raw as InstructionLanguage), primaryLocaleFor(expected), label);
    assert.deepEqual(
      normalizedLocaleChain(raw as InstructionLanguage),
      normalizedLocaleChain(expected),
      label,
    );
    assert.equal(
      matchLocaleToLanguage(primaryLocaleFor(expected), raw as InstructionLanguage),
      "exact",
      `${label}: the resolved language's real voice is still recognised`,
    );

    /* 6 · voice selection agrees: only the resolved language's voice ranks */
    const ranked = rankVoicesForLanguage(CATALOG, raw as InstructionLanguage);
    assert.deepEqual(
      ranked.map((voice) => voice.identifier),
      [expected === "hi" ? "hi-in-x-hia-local" : "en-in-x-ene-local"],
      label,
    );
    const selection = resolveVoiceSelection({
      voices: CATALOG,
      language: raw as InstructionLanguage,
      preferredVoiceId: null,
    });
    assert.equal(selection.voiceId, ranked[0]?.identifier, label);

    /* 7 · the VISIBLE coaching the user reads agrees too — same setting,
          same resolved language, never a second resolver */
    const visible = visibleCoachingFor(STATE, raw as string);
    assert.ok(visible !== null, label);
    assert.equal(visible.language, expected, label);
    assert.equal(cameraStatusCopyFor(raw).language, expected, label);
  }
});

test("C — no consumer ever returns undefined, empty, or a foreign pool, for any value", () => {
  const EVERYTHING = [...UNREADABLE, "hinglish", "english", null, undefined];
  for (const raw of EVERYTHING) {
    const resolved = resolveInstructionLanguage(raw);
    assert.ok(resolved === "en" || resolved === "hi");
    const route = routeCoachingSpeech({
      state: STATE,
      voiceGuidanceEnabled: true,
      language: raw,
    });
    assert.equal(route.language, resolved, "routing consumes the gate, not its own guess");
  }
});

/* ───────────────── voice ↔ language consistency ───────────────── */

test("resolved language and selected voice can never disagree", () => {
  for (const language of ["en", "hi"] as const) {
    const ranked = rankVoicesForLanguage(CATALOG, language);
    assert.equal(ranked.length, 1, "exactly one catalog voice speaks each language");
    for (const voice of ranked) {
      assert.notEqual(matchLocaleToLanguage(voice.language, language), "mismatch");
    }
    /* A remembered voice of the WRONG language is refused, not obeyed. */
    const foreignId = language === "hi" ? "en-in-x-ene-local" : "hi-in-x-hia-local";
    const selection = resolveVoiceSelection({
      voices: CATALOG,
      language,
      preferredVoiceId: foreignId,
    });
    assert.equal(selection.fallbackReason, "preferred-language-mismatch");
    assert.notEqual(selection.voiceId, foreignId);
  }
  /* An unreadable language never classifies an installed same-language
     voice as missing — that failure reads as "device has no voice" and
     mutes coaching, which is exactly what must not happen. */
  for (const raw of UNREADABLE) {
    const resolved = resolveInstructionLanguage(raw);
    const match = matchLocaleToLanguage(primaryLocaleFor(resolved), raw as InstructionLanguage);
    assert.equal(match, "exact");
  }
});

/* ───────────────── migration + backward compatibility ───────────────── */

test("the persisted-payload migration honours precedence and legacy spellings", () => {
  /* Current key wins. */
  assert.equal(
    resolvePersistedInstructionLanguage({ instructionLanguage: "en", voiceLanguage: "hi" }),
    "en",
  );
  /* Legacy key carries forward unchanged. */
  assert.equal(resolvePersistedInstructionLanguage({ voiceLanguage: "en" }), "en");
  assert.equal(resolvePersistedInstructionLanguage({ voiceLanguage: "hi" }), "hi");
  /* Legacy spellings under either key are RECOGNISED, not discarded. (The
     casts mirror an untrusted store: the payload type cannot admit these
     spellings at compile time, but real persistence can.) */
  assert.equal(resolvePersistedInstructionLanguage({ voiceLanguage: "English" }), "en");
  assert.equal(
    resolvePersistedInstructionLanguage({
      instructionLanguage: "en-IN" as unknown as InstructionLanguage,
    }),
    "en",
  );
  assert.equal(resolvePersistedInstructionLanguage({ voiceLanguage: "Hinglish" }), "hi");
  assert.equal(
    resolvePersistedInstructionLanguage({
      instructionLanguage: "hindi" as unknown as InstructionLanguage,
    }),
    "hi",
  );
  /* Invalid at both keys = as absent = fresh-install default. */
  assert.equal(
    resolvePersistedInstructionLanguage({
      instructionLanguage: "xx" as unknown as InstructionLanguage,
      voiceLanguage: 42,
    }),
    DEFAULT_INSTRUCTION_LANGUAGE,
  );
  assert.equal(resolvePersistedInstructionLanguage({}), "hi");

  /* The full migration normalizes the value, drops the old key, and keeps
     every unrelated preference — nothing unrelated is ever deleted. */
  const migrated = migrateCameraSettings(
    {
      voiceLanguage: "English",
      flashDefault: "on",
      someFutureKey: { untouched: true },
    },
    SETTINGS_PERSIST_VERSION - 1,
  ) as unknown as Record<string, unknown> & {
    instructionLanguage: InstructionLanguage;
  };
  assert.equal(migrated.instructionLanguage, "en");
  assert.equal("voiceLanguage" in migrated, false);
  assert.equal(migrated.flashDefault, "on");
  assert.deepEqual(migrated.someFutureKey, { untouched: true });

  const corrupted = migrateCameraSettings(
    { voiceLanguage: "kl-KL", instructionLanguage: undefined },
    1,
  ) as unknown as { instructionLanguage: InstructionLanguage };
  assert.equal(corrupted.instructionLanguage, DEFAULT_INSTRUCTION_LANGUAGE);
});
