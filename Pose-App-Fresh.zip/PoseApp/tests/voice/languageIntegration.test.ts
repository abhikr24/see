/**
 * tests/voice/languageIntegration.test.ts — Unit 35 (Part 4.4):
 * THE COMPLETE PATH, END TO END, WITHOUT A DEVICE.
 *
 *   analysis decision → semantic coaching state → ROUTING (language +
 *   voice-guidance switch) → phrase pool → selected phrase → voice selection
 *
 * What each stage must never lose is asserted explicitly: category,
 * direction, severity and language survive to the spoken line, and the
 * unavailable/evaluating states can never become a correction.
 *
 * SCOPE OF PROOF:
 *   · CODE VERIFIED — routing, language selection, phrase pools, voice
 *     decision. Pure functions, deterministic, no clock, no network.
 *   · NOT DEVICE VERIFIED — no audio is produced here. That a phone owns a
 *     Hindi voice, and how it sounds, is unproven by this suite.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  coachingCategoryFor,
  intensityForSeverity,
  selectCoachingPhrase,
  type CoachingState,
} from "../../shared/coaching";
import {
  instructionPool,
  resetInstructionMemory,
  type InstructionLanguage,
  type VoiceInstructionCategory,
} from "../../shared/constants/poseInstructions";
import {
  DEFAULT_INSTRUCTION_LANGUAGE,
  resolveVoiceSelection,
  routeCoachingSpeech,
  type DeviceVoice,
} from "../../shared/voice";

const DEVANAGARI = /[\u0900-\u097F]/;

function correction(
  category: VoiceInstructionCategory,
  severity: "minor" | "major",
  overrides?: Partial<CoachingState>,
): CoachingState {
  return {
    kind: "correction",
    token: `LEFT_ELBOW_${severity.toUpperCase()}`,
    category,
    measurementId: "leftElbow",
    direction: "increase",
    severity,
    intensity: intensityForSeverity(severity),
    confidence: 0.92,
    stableFrames: 6,
    heldByHysteresis: false,
    unavailableReason: null,
    speakable: true,
    ...overrides,
  };
}

const PERFECT: CoachingState = {
  kind: "perfect",
  token: "PERFECT",
  category: "final_pose_good",
  measurementId: null,
  direction: "none",
  severity: null,
  intensity: "gentle",
  confidence: 0.95,
  stableFrames: 8,
  heldByHysteresis: false,
  unavailableReason: null,
  speakable: true,
};

function unavailable(reason: CoachingState["unavailableReason"]): CoachingState {
  return {
    kind: "unavailable",
    token: `UNAVAILABLE:${String(reason)}`,
    category: null,
    measurementId: null,
    direction: "none",
    severity: null,
    intensity: "gentle",
    confidence: 0,
    stableFrames: 0,
    heldByHysteresis: false,
    unavailableReason: reason,
    speakable: false,
  };
}

const EVALUATING: CoachingState = {
  kind: "evaluating",
  token: "EVALUATING",
  category: null,
  measurementId: null,
  direction: "none",
  severity: null,
  intensity: "gentle",
  confidence: 0.4,
  stableFrames: 1,
  heldByHysteresis: false,
  unavailableReason: null,
  speakable: false,
};

/* ===================== 1 · LANGUAGE ACTUALLY ROUTES ====================== */

test("the SAME semantic state speaks English in en and Hindi/Hinglish in hi", () => {
  const state = correction("hand_up", "minor");
  resetInstructionMemory();
  const english = selectCoachingPhrase(state, "en", { random: () => 0.1 });
  resetInstructionMemory();
  const hindi = selectCoachingPhrase(state, "hi", { random: () => 0.1 });

  assert.ok(english !== null && hindi !== null);
  assert.equal(english.language, "en");
  assert.equal(hindi.language, "hi");
  /* Same category, same intensity, same token — only the words differ. No
     separate mathematics exists for either language. */
  assert.equal(english.category, hindi.category);
  assert.equal(english.intensity, hindi.intensity);
  assert.equal(english.token, hindi.token);
  assert.notEqual(english.text, hindi.text);

  assert.ok(instructionPool("hand_up", "en", "gentle").includes(english.text));
  assert.ok(instructionPool("hand_up", "hi", "gentle").includes(hindi.text));
  /* The Hindi bank is genuinely Hindi/Hinglish, not English relabelled. */
  assert.ok(
    instructionPool("hand_up", "hi", "gentle").some((line) => DEVANAGARI.test(line)),
  );
  assert.ok(
    !instructionPool("hand_up", "en", "gentle").some((line) => DEVANAGARI.test(line)),
  );
});

test("routing normalizes the language once, for every consumer", () => {
  const state = correction("chin_up", "major");
  assert.equal(
    routeCoachingSpeech({ state, voiceGuidanceEnabled: true, language: "hi" })
      .language,
    "hi",
  );
  /* A corrupted persisted value cannot select a pool that does not exist:
     routing resolves it through the ONE canonical gate — to the default
     instruction language (the fresh-install language), exactly like the
     locale tables, the phrase bank and voice selection all must. */
  const route = routeCoachingSpeech({
    state,
    voiceGuidanceEnabled: true,
    language: "kl-KL",
  });
  assert.equal(route.language, DEFAULT_INSTRUCTION_LANGUAGE);
  assert.equal(
    selectCoachingPhrase(state, "kl-KL" as unknown as InstructionLanguage)?.language,
    route.language,
  );
  const phrase = selectCoachingPhrase(route.state as CoachingState, route.language);
  assert.ok(phrase !== null);
  assert.equal(phrase.language, DEFAULT_INSTRUCTION_LANGUAGE);
  assert.ok(
    instructionPool("chin_up", DEFAULT_INSTRUCTION_LANGUAGE, "firm").includes(
      phrase.text,
    ),
    "the spoken line comes from the SAME category's pool in the resolved language",
  );
});

/* ================ 2 · VOICE GUIDANCE OFF ≠ STATE DELETED ================= */

test("voice guidance OFF suppresses speech but keeps the semantic state", () => {
  const state = correction("hand_up", "major");
  const route = routeCoachingSpeech({
    state,
    voiceGuidanceEnabled: false,
    language: "hi",
  });
  assert.equal(route.deliverToSpeech, false);
  assert.equal(route.suppression, "voice-guidance-disabled");
  /* The identical object is still available to the overlay / capture logic. */
  assert.equal(route.state, state);
  assert.equal(route.state?.category, "hand_up");
  assert.equal(route.state?.severity, "major");
  assert.equal(route.language, "hi");
});

test("capture flow owns the audio without discarding coaching state", () => {
  const state = correction("hand_up", "minor");
  const route = routeCoachingSpeech({
    state,
    voiceGuidanceEnabled: true,
    language: "en",
    captureInProgress: true,
  });
  assert.equal(route.deliverToSpeech, false);
  assert.equal(route.suppression, "capture-in-progress");
  assert.equal(route.state, state);
});

test("a frame without a decision is reported, not guessed", () => {
  const route = routeCoachingSpeech({
    state: null,
    voiceGuidanceEnabled: true,
    language: "en",
  });
  assert.equal(route.deliverToSpeech, false);
  assert.equal(route.suppression, "no-state");
  assert.equal(route.state, null);
});

/* ============ 3 · NO FABRICATED CORRECTION, IN ANY LANGUAGE ============== */

test("unavailable reference / analysis states never reach a correction phrase", () => {
  const reasons: CoachingState["unavailableReason"][] = [
    "no-live-pose",
    "low-confidence",
    "reference-unavailable",
    "reference-invalid",
    "reference-incompatible",
  ];
  const languages: readonly InstructionLanguage[] = ["en", "hi"];
  for (const reason of reasons) {
    const state = unavailable(reason);
    for (const language of languages) {
      const route = routeCoachingSpeech({
        state,
        voiceGuidanceEnabled: true,
        language,
      });
      assert.equal(route.deliverToSpeech, false, String(reason));
      assert.equal(route.suppression, "state-not-speakable");
      /* Even if a caller ignored the gate, the phrase layer answers silence. */
      assert.equal(selectCoachingPhrase(state, language), null);
      /* The reason itself survives for non-speech consumers. */
      assert.equal(route.state?.unavailableReason, reason);
    }
  }
});

test("evaluating is silent in both languages", () => {
  for (const language of ["en", "hi"] as const) {
    const route = routeCoachingSpeech({
      state: EVALUATING,
      voiceGuidanceEnabled: true,
      language,
    });
    assert.equal(route.deliverToSpeech, false);
    assert.equal(selectCoachingPhrase(EVALUATING, language), null);
  }
});

/* ================= 4 · SEVERITY AND CATEGORY SURVIVE ===================== */

test("severity chooses the tier, in both languages, from the same state", () => {
  for (const language of ["en", "hi"] as const) {
    resetInstructionMemory();
    const gentle = selectCoachingPhrase(correction("hand_up", "minor"), language, {
      random: () => 0,
    });
    resetInstructionMemory();
    const firm = selectCoachingPhrase(correction("hand_up", "major"), language, {
      random: () => 0,
    });
    assert.ok(gentle !== null && firm !== null);
    assert.equal(gentle.requestedIntensity, "gentle");
    assert.equal(firm.requestedIntensity, "firm");
    assert.ok(instructionPool("hand_up", language, "gentle").includes(gentle.text));
    assert.ok(instructionPool("hand_up", language, "firm").includes(firm.text));
  }
});

test("the engine's category+direction, not the language, selects the pool", () => {
  const straighten = coachingCategoryFor("leftElbow", "increase");
  const bend = coachingCategoryFor("leftElbow", "decrease");
  assert.ok(straighten !== null && bend !== null);
  assert.notEqual(straighten, bend);
  for (const language of ["en", "hi"] as const) {
    resetInstructionMemory();
    const phrase = selectCoachingPhrase(correction(straighten, "minor"), language);
    assert.ok(phrase !== null);
    assert.equal(phrase.category, straighten);
    assert.ok(instructionPool(straighten, language, "gentle").includes(phrase.text));
  }
});

test("perfect speaks the perfect pool only, in the selected language", () => {
  for (const language of ["en", "hi"] as const) {
    resetInstructionMemory();
    const phrase = selectCoachingPhrase(PERFECT, language);
    assert.ok(phrase !== null);
    assert.equal(phrase.category, "final_pose_good");
    assert.ok(
      instructionPool("final_pose_good", language, "gentle").includes(phrase.text),
    );
  }
});

/* ============= 5 · LANGUAGE → VOICE, THE LAST HANDOVER ================== */

const CATALOG: readonly DeviceVoice[] = [
  { identifier: "en-local", name: "English", language: "en-US", networkConnectionRequired: false },
  { identifier: "hi-local", name: "Hindi", language: "hi-IN", networkConnectionRequired: false },
];

test("the language that chose the phrase also chooses the voice", () => {
  for (const language of ["en", "hi"] as const) {
    const route = routeCoachingSpeech({
      state: correction("hand_up", "minor"),
      voiceGuidanceEnabled: true,
      language,
    });
    const phrase = selectCoachingPhrase(route.state as CoachingState, route.language);
    assert.ok(phrase !== null);
    const voice = resolveVoiceSelection({
      voices: CATALOG,
      language: phrase.language,
      preferredVoiceId: null,
    });
    assert.equal(phrase.language, route.language);
    assert.equal(voice.voiceId, language === "hi" ? "hi-local" : "en-local");
    assert.equal(voice.locale.startsWith(language), true);
  }
});

test("a device missing the Hindi pack still speaks the Hindi phrase text", () => {
  /* The cue is not downgraded to English copy: the words stay Hindi and the
     locale stays hi-IN; only the VOICE falls back to the engine default.
     Whether that default can pronounce it is a device question, not a code
     question — this asserts the code does not silently switch banks. */
  const englishOnly = CATALOG.filter((voice) => voice.identifier === "en-local");
  resetInstructionMemory();
  const phrase = selectCoachingPhrase(correction("hand_up", "minor"), "hi");
  assert.ok(phrase !== null);
  assert.equal(phrase.language, "hi");
  const voice = resolveVoiceSelection({
    voices: englishOnly,
    language: "hi",
    preferredVoiceId: null,
  });
  assert.equal(voice.voiceId, null);
  assert.equal(voice.locale, "hi-IN");
  assert.equal(voice.fallbackReason, "no-voice-for-language");
});
