/**
 * tests/voice/voiceSelection.test.ts — Unit 35 (Part 4.4):
 * VOICE DISCOVERY → RANKING → PERSISTED PREFERENCE → SAFE FALLBACK.
 *
 * SCOPE OF PROOF — read this before trusting the green output:
 *   · CODE VERIFIED here: the decision logic that turns a catalog the
 *     runtime reported into one voice id + locale. Catalogs below are
 *     FIXTURES modelled on real Android/iOS shapes; they are NOT evidence
 *     that any of those voices exists on any phone.
 *   · DEVICE VERIFIED: nothing. No speech is synthesized in this suite, no
 *     `expo-speech` is loaded, and no assertion here proves a device has a
 *     Hindi (or any) voice pack installed.
 *
 * Deterministic: pure functions only — no clock, no random, no network.
 */
import { test } from "node:test";
import assert from "node:assert/strict";

import {
  AUTOMATIC_VOICE_ID,
  describeVoice,
  localeLanguageSubtag,
  matchLocaleToLanguage,
  normalizeVoiceLocale,
  primaryLocaleFor,
  rankVoicesForLanguage,
  resolveInstructionLanguage,
  DEFAULT_INSTRUCTION_LANGUAGE,
  resolveVoiceSelection,
  voiceOptionsForLanguage,
  VOICE_LANGUAGE_LOCALES,
  type DeviceVoice,
} from "../../shared/voice";

/* A catalog shaped like a real Android device: mixed quality tiers, a
   network voice, an uninstalled pack, and an odd 3-letter locale. */
const ANDROID_CATALOG: readonly DeviceVoice[] = [
  {
    identifier: "en-us-x-sfg#male_1-local",
    name: "English US male",
    language: "en-US",
    quality: "Default",
    networkConnectionRequired: false,
  },
  {
    identifier: "en-in-x-ene-network",
    name: "English India enhanced",
    language: "en-IN",
    quality: "Enhanced",
    networkConnectionRequired: true,
  },
  {
    identifier: "en-in-x-ene-local",
    name: "English India enhanced",
    language: "en-IN",
    quality: "Enhanced",
    networkConnectionRequired: false,
  },
  {
    identifier: "hin-ind-x-hia-local",
    name: "Hindi India",
    language: "hin-IND",
    quality: "Default",
    networkConnectionRequired: false,
  },
  {
    identifier: "hi-in-x-hie-local",
    name: "Hindi India enhanced",
    language: "hi-IN",
    quality: "Enhanced",
    networkConnectionRequired: false,
  },
  {
    identifier: "hi-in-x-not-installed",
    name: "Hindi India extra",
    language: "hi-IN",
    quality: "Enhanced",
    notInstalled: true,
    networkConnectionRequired: false,
  },
  {
    identifier: "fr-fr-x-frd-local",
    name: "French",
    language: "fr-FR",
    networkConnectionRequired: false,
  },
];

/* ----------------------------- locales ---------------------------------- */

test("locale normalization survives the tags Android/iOS actually report", () => {
  assert.equal(normalizeVoiceLocale("hi-IN"), "hi-in");
  assert.equal(normalizeVoiceLocale("hi_IN"), "hi-in");
  assert.equal(normalizeVoiceLocale("hin-IND"), "hi-in");
  assert.equal(normalizeVoiceLocale("ENG-USA"), "en-us");
  assert.equal(normalizeVoiceLocale("  en  "), "en");
  assert.equal(normalizeVoiceLocale(""), "");
  /* An unknown tag is lowercased, never rewritten into something else. */
  assert.equal(normalizeVoiceLocale("zz-ZZ"), "zz-zz");
  assert.equal(localeLanguageSubtag("hin-IND"), "hi");
});

test("locale → language matching separates exact, same-language and foreign", () => {
  assert.equal(matchLocaleToLanguage("hi-IN", "hi"), "exact");
  assert.equal(matchLocaleToLanguage("hin-IND", "hi"), "exact");
  assert.equal(matchLocaleToLanguage("en-AU", "en"), "language");
  assert.equal(matchLocaleToLanguage("en-US", "hi"), "mismatch");
  assert.equal(matchLocaleToLanguage("", "en"), "unknown");
});

test("an untrusted language preference degrades to the DEFAULT instruction language, never to a missing pool", () => {
  /* Unit 37: a VALID stored choice is always honoured in both directions;
     only an unreadable one falls back, and it falls back to exactly what a
     fresh install would use (Hindi) — never to a pool that does not exist. */
  assert.equal(resolveInstructionLanguage("hi"), "hi");
  assert.equal(resolveInstructionLanguage("hi-IN"), "hi");
  assert.equal(resolveInstructionLanguage("en"), "en");
  assert.equal(resolveInstructionLanguage("en-IN"), "en");
  assert.equal(DEFAULT_INSTRUCTION_LANGUAGE, "hi");
  assert.equal(resolveInstructionLanguage("fr"), DEFAULT_INSTRUCTION_LANGUAGE);
  assert.equal(resolveInstructionLanguage(undefined), DEFAULT_INSTRUCTION_LANGUAGE);
  assert.equal(resolveInstructionLanguage(null), DEFAULT_INSTRUCTION_LANGUAGE);
  assert.equal(resolveInstructionLanguage(42), DEFAULT_INSTRUCTION_LANGUAGE);
  assert.equal(primaryLocaleFor("hi"), "hi-IN");
  assert.equal(primaryLocaleFor("en"), VOICE_LANGUAGE_LOCALES.en[0]);
});

/* ----------------------------- ranking ---------------------------------- */

test("ranking lists only voices that can speak the language, best first", () => {
  const hindi = rankVoicesForLanguage(ANDROID_CATALOG, "hi");
  assert.deepEqual(
    hindi.map((voice) => voice.identifier),
    ["hi-in-x-hie-local", "hin-ind-x-hia-local"],
  );
  /* Not installed → excluded. Another language → excluded, never ranked low
     and then spoken as a last resort. */
  assert.ok(!hindi.some((voice) => voice.identifier === "hi-in-x-not-installed"));
  assert.ok(!hindi.some((voice) => voice.identifier.startsWith("fr-")));

  const english = rankVoicesForLanguage(ANDROID_CATALOG, "en");
  assert.equal(english[0]?.identifier, "en-in-x-ene-local");
  /* On-device beats the identical network voice. */
  const localIndex = english.findIndex((v) => v.identifier === "en-in-x-ene-local");
  const networkIndex = english.findIndex(
    (v) => v.identifier === "en-in-x-ene-network",
  );
  assert.ok(localIndex < networkIndex);
});

test("ranking is deterministic and never invents entries", () => {
  const first = rankVoicesForLanguage(ANDROID_CATALOG, "en").map((v) => v.identifier);
  const second = rankVoicesForLanguage(ANDROID_CATALOG, "en").map((v) => v.identifier);
  assert.deepEqual(first, second);
  for (const id of first) {
    assert.ok(ANDROID_CATALOG.some((voice) => voice.identifier === id));
  }
});

/* --------------------- preference resolution ---------------------------- */

test("a selected voice that exists is used verbatim", () => {
  const selection = resolveVoiceSelection({
    voices: ANDROID_CATALOG,
    language: "hi",
    preferredVoiceId: "hin-ind-x-hia-local",
  });
  assert.equal(selection.voiceId, "hin-ind-x-hia-local");
  assert.equal(selection.source, "preferred");
  assert.equal(selection.fallbackReason, null);
  assert.equal(selection.locale, "hi-in");
});

test("no preference → the best ranked voice, reported as such", () => {
  const selection = resolveVoiceSelection({
    voices: ANDROID_CATALOG,
    language: "hi",
    preferredVoiceId: null,
  });
  assert.equal(selection.voiceId, "hi-in-x-hie-local");
  assert.equal(selection.source, "ranked");
  assert.equal(selection.fallbackReason, "no-preference");

  /* The picker sentinel means the same thing as null. */
  const auto = resolveVoiceSelection({
    voices: ANDROID_CATALOG,
    language: "hi",
    preferredVoiceId: AUTOMATIC_VOICE_ID,
  });
  assert.deepEqual(auto, selection);
});

test("a selected voice the device no longer reports falls back safely", () => {
  const selection = resolveVoiceSelection({
    voices: ANDROID_CATALOG,
    language: "en",
    preferredVoiceId: "voice-from-my-old-phone",
  });
  assert.equal(selection.source, "ranked");
  assert.equal(selection.fallbackReason, "preferred-not-found");
  assert.equal(selection.requestedVoiceId, "voice-from-my-old-phone");
  /* The missing id is NEVER handed to the engine. */
  assert.notEqual(selection.voiceId, "voice-from-my-old-phone");
  assert.ok(
    ANDROID_CATALOG.some((voice) => voice.identifier === selection.voiceId),
  );
});

test("a selected voice whose pack is not installed falls back", () => {
  const selection = resolveVoiceSelection({
    voices: ANDROID_CATALOG,
    language: "hi",
    preferredVoiceId: "hi-in-x-not-installed",
  });
  assert.equal(selection.fallbackReason, "preferred-not-installed");
  assert.equal(selection.voiceId, "hi-in-x-hie-local");
});

test("a selected voice of the wrong language never reads the other bank", () => {
  const selection = resolveVoiceSelection({
    voices: ANDROID_CATALOG,
    language: "hi",
    preferredVoiceId: "en-in-x-ene-local",
  });
  assert.equal(selection.fallbackReason, "preferred-language-mismatch");
  assert.equal(localeLanguageSubtag(selection.locale), "hi");
});

test("a language with no installed voice degrades to the engine default", () => {
  const englishOnly = ANDROID_CATALOG.filter(
    (voice) => localeLanguageSubtag(voice.language) === "en",
  );
  const selection = resolveVoiceSelection({
    voices: englishOnly,
    language: "hi",
    preferredVoiceId: null,
  });
  assert.equal(selection.voiceId, null, "no voice id may be fabricated");
  assert.equal(selection.source, "engine-default");
  assert.equal(selection.fallbackReason, "no-voice-for-language");
  assert.equal(selection.locale, "hi-IN");
});

test("an empty or failed catalog is survivable, not a crash", () => {
  const selection = resolveVoiceSelection({
    voices: [],
    language: "en",
    preferredVoiceId: "anything",
  });
  assert.equal(selection.voiceId, null);
  assert.equal(selection.source, "engine-default");
  assert.equal(selection.fallbackReason, "empty-catalog");
  assert.equal(selection.locale, "en-IN");
});

test("malformed catalog entries are ignored instead of being spoken", () => {
  const messy: readonly DeviceVoice[] = [
    { identifier: "", language: "hi-IN" },
    { identifier: "ghost", language: "" },
    { identifier: "hi-real", language: "hi-IN", networkConnectionRequired: false },
  ];
  const selection = resolveVoiceSelection({
    voices: messy,
    language: "hi",
    preferredVoiceId: null,
  });
  assert.equal(selection.voiceId, "hi-real");
});

/* ------------------------- picker options ------------------------------- */

test("picker options are Automatic plus exactly the reported voices", () => {
  const options = voiceOptionsForLanguage(ANDROID_CATALOG, "hi");
  assert.equal(options[0]?.value, AUTOMATIC_VOICE_ID);
  assert.deepEqual(
    options.slice(1).map((option) => option.value),
    ["hi-in-x-hie-local", "hin-ind-x-hia-local"],
  );
  for (const option of options.slice(1)) {
    assert.ok(
      ANDROID_CATALOG.some((voice) => voice.identifier === option.value),
      "the picker must not offer a voice the device never reported",
    );
  }

  /* A device with nothing installed for the language offers one honest row. */
  assert.deepEqual(
    voiceOptionsForLanguage([], "hi").map((option) => option.value),
    [AUTOMATIC_VOICE_ID],
  );
});

test("voice labels state the locale and network requirement, nothing invented", () => {
  const network = ANDROID_CATALOG[1];
  assert.ok(network !== undefined);
  const label = describeVoice(network);
  assert.ok(label.includes("en-in"));
  assert.ok(label.includes("network"));
});
