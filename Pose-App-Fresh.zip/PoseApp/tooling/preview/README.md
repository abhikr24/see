# ⚠ PREVIEW TOOLING ONLY — this is **not** the application

This folder contains the **coding-environment preview mirror**: a small
Vite + React-DOM web page that visualizes the real **React Native + Expo**
application while it is being built. It exists because this coding
environment renders `dist/index.html` in a browser and cannot natively host
an interactive Expo/React-Native dev-server session.

## What the real app is

| | |
|---|---|
| **Production application** | [`mobile/`](../../mobile) — React Native + Expo + Expo Router + Metro (+ React Native Web for the production web target) |
| **Shared production logic** | [`shared/`](../../shared) — platform-neutral TypeScript (theme tokens, pose catalog, ML math) consumed by `mobile/` |
| **This folder** | Preview tooling only. A browser page that mirrors app progress. |

## Hard rules (kept true by machine checks, not promises)

1. **This is not production.** Nothing here is bundled into the app.
   Metro's watch set is `mobile/` + `shared/` only (`mobile/metro.config.js`).
2. **Production never imports this folder.** `mobile/` and `shared/` contain
   zero references to `tooling/` (enforced by `mobile/scripts/verify-purity.mjs`).
3. **Not required by any production build.** iOS, Android (EAS or local), and
   the production Expo Web export all work identically with this folder deleted.
4. **Not a source of truth.** Screen behavior mirrored here lives in
   `mobile/src/features/…`. This mirror *consumes* safe shared logic
   (`shared/theme`, `shared/data/poseCatalog`, …) — it contains **no
   production-only business logic** that exists nowhere else.
5. **Independently removable.** `rm -rf tooling/preview` + the repo-root
   `package.json` scripts leaves the entire production repo intact and working.

## Why these preview-only dependencies exist

These live in the **repo-root `package.json`** (the coding environment invokes
`npm run build` at the repository root and serves `dist/index.html`), but they
are *exclusively* consumed by this folder and are classified **preview-only**:

| Package | Why the preview needs it |
|---|---|
| `vite` | Dev server + bundler for this mirror page |
| `@vitejs/plugin-react` | JSX transform for the mirror |
| `vite-plugin-singlefile` | Emits one self-contained `dist/index.html` for the environment |
| `react`, `react-dom` | Browser rendering runtime of the mirror (DOM) |
| `tailwindcss`, `@tailwindcss/vite` | Styling of the mirror page (CSS — forbidden in production) |
| `clsx`, `tailwind-merge` | Class-name composition helpers in the mirror |
| `lucide-react` | Icons in the mirror UI |
| `@mediapipe/tasks-vision` | Lets the mirror run the *same* pose-detection model in a browser webcam demo |
| `typescript`, `@types/*` | Typechecking this tooling |

Browser-only APIs (`createRoot`, DOM tags, CSS, `navigator.mediaDevices`,
`localStorage`) are permitted **inside `tooling/preview/` only** and are
machine-forbidden in `mobile/` and `shared/` via `verify-purity.mjs`.

## Commands (run from the repo root)

```bash
npm run build   # builds this mirror → dist/index.html (gitignored artifact)
npm run dev     # local dev server of this mirror
npm run verify  # runs the PRODUCTION gate (deps + purity + typecheck of mobile/)
```
