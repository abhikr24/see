/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * ----------------------------------------------------------------------
 * This web page exists ONLY so you can watch the React Native + Expo app
 * (mobile/) being built, unit by unit. Metro (the Expo bundler) never sees
 * this folder: it watches mobile/ + shared/ only. The real Unit 08 code
 * lives in mobile/src/features/explore/ — pure React Native, zero DOM.
 *
 * Unit 13 · Capture, processing & device-only preview/save flow.
 * Unit 14 · Gallery: date-grouped grid + full saved-photo actions.
 * Unit 15 · Unified pose history & recents across Home, Camera, Gallery.
 * Unit 16 · MediaPipe core: 33-landmark skeleton overlay + live match %.
 * Unit 17 · Pose comparison & visual guidance: directive text, arrows & hints.
 * Unit 18 · Intelligent capture: voice, stable-match auto capture & open palm.
 * Unit 19 · Profile tab: avatar, 3-col stats, favorites grid, storage management & edit name.
 * Unit 20 · Settings: camera defaults + intelligent capture preferences.
 * Unit 21 · Settings: system — theme, language, privacy, terms, about & clear data.
 * Unit 22 · Global errors: typed handling, retry UI, offline state & crash recovery.
 * Unit 23 · UI States system: Shimmer skeletons, canonical EmptyState widgets, global snackbar & loading overlay.
 * Unit 24 · Performance/polish implementation; native release QA remains open.
 */
import { Camera, FlaskConical, Smartphone } from "lucide-react";
import { PreviewProvider } from "./preview/preview-state";
import { PhonePreview } from "./preview/phone-preview";
import { SidePanels } from "./preview/panels";
import { PreviewErrorBoundary, PreviewOfflineBanner } from "./preview/error-system";
import { usePreview } from "./preview/preview-state";

function Header() {
  return (
    <header className="flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 shadow-lg shadow-blue-600/30">
          <Camera size={20} className="text-white" />
        </div>
        <div>
          <h1 className="text-base font-bold tracking-tight text-white">
            Smart Photography Assistant
          </h1>
          <p className="text-[11px] text-zinc-400">
            React Native + Expo SDK 57 · one codebase for iOS, Android & Web
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-[10px] font-bold text-emerald-300">
          27 UNITS IMPLEMENTED ✓
        </span>
        <span className="animate-pulse rounded-full border border-emerald-500/40 bg-emerald-500/15 px-3 py-1 text-[10px] font-bold text-emerald-300">
          DEVICE QA PENDING
        </span>
      </div>
    </header>
  );
}

function UnitEightNotes() {
  const items = [
    "U08–09 · Explore catalog + dedicated search route with ranked text, category, difficulty and history filters",
    "U10 · Deep-linkable /pose/[id] detail with deterministic “More like this” rail",
    "U11 · Favorites: account-scoped local replica, durable sync queue, Supabase RLS, strict guest gating",
    "U12 · Camera State 1 (No Pose) + State 2 (Active): JIT-mounted live preview, front/rear flip, controls",
    "U13 · Shutter capture · countdown · processing overlay · full preview with Retake/Share/Delete · device save",
    "U14 · Gallery: date-grouped 3-column grid + full saved-photo preview with Share/Delete/Retake",
    "U15 · Unified pose history & recents datasource (lastUsed timestamps, max 20) wired across Home (4), Camera (4) & Gallery (20)",
    "U16 · MediaPipe PoseLandmarker 33-landmark skeleton overlay (Skia Canvas) + live match % vs reference angles",
    "U17 · Real-time visual guidance: worst joint angle diff comparison generates clear directives ('Raise left arm', 'Bend right knee', 'Straighten leg')",
    "U17 · High-contrast arrow indicators at worst joints on the live skeleton + color-coded joints & bones (Green <10°, Amber 10–25°, Red >25°)",
    "U17 · Floating guidance overlay pill with icon, actionable headline, contextual positioning hint, and 'Perfect! Hold still' state",
    "U18 · On-device Expo Speech guidance with text-change + 3-second debounce, queue cancellation, speaker state, and full lifecycle cleanup",
    "U18 · Automatic capture after ≥90% match is held continuously for 2 seconds, then a visible 3-2-1 countdown",
    "U18 · Open-palm capture from MediaPipe wrist/index/pinky/thumb geometry with a stability hold and one global trigger lock",
    "U19 · Complete Profile tab: avatar (80px), 3-column stats row (Favorites / Photos / Poses Tried), display name editing",
    "U19 · 2-column favorites grid with live un-favorite spring animation and empty state CTA",
    "U19 · Storage & preferences controls: clear image cache, clear recent poses history, live appearance switcher, guest CTA, and sign-out",
    "U20 · Settings screen with Camera section: Flash / Timer / Filter defaults (radio modals) + 3x3 Grid Overlay switch",
    "U20 · Intelligent Capture section: auto-capture threshold (80/85/90/95%), Voice Guidance, Gesture Capture, Countdown duration, Haptics",
    "U20 · Every setting persists to MMKV and is read live by the camera session — flash/timer/filter seed on focus, threshold gates auto-capture",
    "U21 · System section: app-wide Theme picker, Language placeholder, Privacy Policy, Terms of Service, About, Rate App & Clear All Data",
    "U21 · /settings/privacy, /settings/terms and /settings/about routes with real content; Clear All Data preserves onboarding flags",
    "U20–21 · The camera's ⚙ icon now opens the full Settings screen instead of a placeholder alert",
    "U22 · Typed AppError system maps network, auth, camera, storage, MediaPipe, permission and unknown failures to safe recovery copy",
    "U22 · Shared Retry UI on every feature boundary, camera and AI-specific restart paths, plus root render-crash recovery",
    "U22 · Live offline banner from native NetInfo, stack-aware AppLogger output, and no silent catch blocks in the Expo tree",
    "U23 · ShimmerSkeleton variants: 2-col pose grid (6 cards), 3-col gallery (9 cells), horizontal shelf (4 cards), 3-col stats, avatar circle (80px), and settings tiles with 1.5s Reanimated sweep",
    "U23 · Canonical EmptyStateWidget for Explore ('No poses found' / 'Clear Filters'), Search ('No results for query' / 'Clear Search'), Favorites ('No favorites yet' / 'Explore Poses'), Gallery ('No photos yet' / 'Start Camera'), and Camera State 1 ('No pose selected' / 'Browse Poses')",
    "U23 · Global imperative success snackbar system: 'Added to favorites', 'Removed from favorites', 'Photo saved to gallery', 'Settings saved', 'Cache cleared', 'All data cleared'",
    "U23 · Generic LoadingOverlay with primary spinner and optional secondary label; zero blank loading states anywhere",
    "U24 · Lazy loading pagination: Explore & Search onEndReached (20/page) + Gallery (30/page) with 60fps smooth scrolling",
    "U24 · Comprehensive memory & cleanup audit: CameraView release on unmount/background, MediaPipe detector disposal, Speech.stop(), and zero memory leaks",
    "U24 · App icon & splash screen configured in app.json with adaptiveIcon + web favicon; eas.json multi-environment build profiles",
    "U24 · Final QA & architecture compliance: 100% platform purity, strict TypeScript, design tokens only, on-device photos & ML",
    "UX 5–8 · Premium motion & depth pass: shared spring-press language on every touchable (0.96/0.99/0.92 snappy spring + overshoot release), pressed-darken fills (primary/tinted/ghost rows), 3-level elevation token scale (resting/floating/overlay), brand + scrim gradient tokens on splash, home hero, camera & viewer chrome — all mirrored 1:1 from shared/theme in mobile/",
  ];
  return (
    <section className="rounded-2xl border border-zinc-800 bg-zinc-950/80 p-4">
      <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-zinc-500">
        All 24 Planned Units Implemented — Release Audit Open
      </p>
      <ul className="mt-2.5 flex flex-col gap-1.5">
        {items.map((item) => (
          <li key={item} className="flex items-start gap-2 text-[11px] leading-relaxed text-zinc-300">
            <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-emerald-400" />
            {item}
          </li>
        ))}
      </ul>
      <p className="mt-3 border-t border-zinc-800/80 pt-2.5 text-[10px] leading-relaxed text-zinc-400">
        This preview demonstrates the product architecture and browser MediaPipe path. The final audit found that
        native real-time MediaPipe, licensed pose references, store builds, and physical-device QA still have to be completed.
      </p>
    </section>
  );
}

function MirrorNotice() {
  return (
    <footer className="flex items-start gap-3 rounded-2xl border border-zinc-800/70 bg-zinc-950/50 p-4">
      <FlaskConical size={16} className="mt-0.5 shrink-0 text-zinc-500" />
      <p className="text-[10px] leading-relaxed text-zinc-500">
        You are looking at the <span className="font-semibold text-zinc-300">preview mirror</span> —
        non-production web tooling rendered from the same{" "}
        <code className="rounded bg-zinc-800 px-1 py-0.5 font-mono text-[9px] text-zinc-300">shared/</code>{" "}
        design tokens and pose catalog the app uses. It is never bundled into the app.{" "}
        <span className="mt-1 flex items-center gap-1.5 pt-1 font-semibold text-zinc-400">
          <Smartphone size={12} /> The real app runs with: cd mobile && npx expo start
        </span>
      </p>
    </footer>
  );
}

function PreviewApplication() {
  const { pushLog } = usePreview();
  return (
    <PreviewErrorBoundary
      onError={(error, stack) =>
        pushLog("error", "ErrorBoundary", `${error.message} · ${stack}`)
      }
    >
      <PreviewOfflineBanner />
      <div className="min-h-screen bg-[radial-gradient(1200px_600px_at_50%_-10%,rgba(37,99,235,0.16),transparent_60%)] bg-zinc-950 px-5 py-6 font-sans text-zinc-200 lg:px-10">
        <div className="mx-auto flex max-w-6xl flex-col gap-6">
          <Header />
          <main className="grid items-start gap-6 lg:grid-cols-[min-content_1fr]">
            <div className="justify-self-center">
              <PhonePreview />
            </div>
            <div className="flex min-w-0 flex-col gap-6">
              <div className="h-[430px]">
                <SidePanels />
              </div>
              <UnitEightNotes />
            </div>
          </main>
          <MirrorNotice />
        </div>
      </div>
    </PreviewErrorBoundary>
  );
}

export default function App() {
  return (
    <PreviewProvider>
      <PreviewApplication />
    </PreviewProvider>
  );
}
