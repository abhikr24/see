/**
 * ⚠ PREVIEW MIRROR HOST — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * This file mounts the browser-only visualizer so you can watch the Expo app
 * (mobile/) being built. Metro never watches this folder: the real app is
 * mobile/ + shared/ only. The real app has no equivalent of this file —
 * its entry point is expo-router/entry via mobile/app/.
 */
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
