/**
 * PREVIEW-ONLY mirror of Unit 22 recovery UX. The real implementation lives
 * under mobile/src/core/error + mobile/src/shared/components and contains no
 * DOM code. This file is outside the Expo bundle by design.
 */
import React, { Component, useEffect, useState, type ReactNode } from "react";
import { AlertCircle, RefreshCw, WifiOff } from "lucide-react";

interface PreviewErrorBoundaryProps {
  readonly children: ReactNode;
  readonly onError: (error: Error, stack: string) => void;
}

interface PreviewErrorBoundaryState {
  readonly error: Error | null;
}

export class PreviewErrorBoundary extends Component<
  PreviewErrorBoundaryProps,
  PreviewErrorBoundaryState
> {
  state: PreviewErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): PreviewErrorBoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    this.props.onError(error, info.componentStack ?? "No component stack");
  }

  render() {
    if (this.state.error !== null) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-zinc-950 px-6 text-center text-white">
          <div className="flex max-w-sm flex-col items-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-zinc-900">
              <AlertCircle size={42} className="text-zinc-400" />
            </div>
            <h1 className="mt-5 text-xl font-semibold">PoseAssist needs to recover</h1>
            <p className="mt-2 text-sm leading-relaxed text-zinc-400">
              An unexpected preview error occurred. Your Expo app data was not changed.
            </p>
            <button
              onClick={() => this.setState({ error: null })}
              className="pv-press mt-6 flex min-h-12 cursor-pointer items-center gap-2 rounded-xl bg-blue-600 px-6 text-sm font-semibold"
            >
              <RefreshCw size={17} /> Retry
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export function PreviewOfflineBanner() {
  const [online, setOnline] = useState(() =>
    typeof navigator === "undefined" ? true : navigator.onLine,
  );

  useEffect(() => {
    const markOnline = () => setOnline(true);
    const markOffline = () => setOnline(false);
    window.addEventListener("online", markOnline);
    window.addEventListener("offline", markOffline);
    return () => {
      window.removeEventListener("online", markOnline);
      window.removeEventListener("offline", markOffline);
    };
  }, []);

  if (online) return null;
  return (
    <div
      role="alert"
      className="fixed inset-x-0 top-0 z-[100] flex h-8 items-center justify-center gap-2 bg-red-500 text-xs font-semibold text-white shadow-lg"
    >
      <WifiOff size={14} /> You are offline
    </div>
  );
}
