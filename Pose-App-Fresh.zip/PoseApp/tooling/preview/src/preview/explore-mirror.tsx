/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Unit 08 (Explore) mirror — browser twin of mobile/app/(tabs)/explore.tsx:
 *  · search bar with debounced ranked results + history LRU(10)
 *  · featured collection carousel (24 featured poses)
 *  · 12 category collections (filter entry points)
 *  · 2-column pose grid over the 400-pose bundled catalog
 *  · pose detail sheet with "Use This Pose" → camera gate (auth invariant)
 * All data flows through shared/data/poseCatalog so results are identical
 * to what the Expo app computes on-device.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Camera,
  Check,
  ChevronRight,
  Clock,
  Crown,
  Heart,
  Search,
  SearchX,
  Sparkles,
  Target,
  X,
} from "lucide-react";
import {
  DIFFICULTY_FILTERS,
  POSE_CATEGORIES,
  filterByDifficulty,
  getCatalogReport,
  getFeaturedPoses,
  getPoseById,
  getPoseCatalog,
  getRelatedPoses,
  normalizeQuery,
  searchPoses,
  type Pose,
  type PoseCategoryId,
} from "../../../../shared/index";
import { CATEGORY_ICON, DIFFICULTY_META, PoseArt } from "./pose-art";
import { usePreview } from "./preview-state";

/* ── Small pieces ──────────────────────────────────────────────────────── */

function DifficultyChip({ difficulty }: { difficulty: Pose["difficulty"] }) {
  const meta = DIFFICULTY_META[difficulty];
  return (
    <span
      className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold"
      style={{ backgroundColor: `${meta.dot}1f`, color: meta.dot }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: meta.dot }} />
      {meta.label}
    </span>
  );
}

function HeartBtn({
  poseId,
  className = "",
  size = 14,
}: {
  poseId: string;
  className?: string;
  size?: number;
}) {
  const { isFavorite, toggleFavorite } = usePreview();
  const fav = isFavorite(poseId);
  const [bounce, setBounce] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setBounce(true);
    setTimeout(() => setBounce(false), 300);
    toggleFavorite(poseId);
  };

  return (
    <button
      onClick={handleClick}
      aria-label={fav ? "Remove from favorites" : "Add to favorites"}
      className={`flex cursor-pointer items-center justify-center rounded-full bg-black/40 text-white backdrop-blur-sm pv-press ${
        bounce ? "scale-125" : "scale-100"
      } ${className}`}
    >
      <Heart
        size={size}
        fill={fav ? "#EF4444" : "none"}
        color={fav ? "#EF4444" : "rgba(255,255,255,0.85)"}
      />
    </button>
  );
}

function GridPoseCard({ pose }: { pose: Pose }) {
  const { colors, isDark, openPose } = usePreview();
  return (
    <button
      onClick={() => openPose(pose.id)}
      className="group cursor-pointer overflow-hidden rounded-xl border text-left pv-lift"
      style={{ backgroundColor: colors.surface, borderColor: colors.divider }}
    >
      <div className="relative">
        <PoseArt pose={pose} isDark={isDark} className="aspect-[4/5]" rounded="rounded-none" iconSize={38}>
          {pose.isPremium && (
            <span className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/45 px-2 py-0.5 text-[9px] font-bold text-amber-300 backdrop-blur-sm">
              <Crown size={9} /> PRO
            </span>
          )}
          {pose.isFeatured && !pose.isPremium && (
            <span className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/45 px-2 py-0.5 text-[9px] font-bold text-white backdrop-blur-sm">
              <Sparkles size={9} /> PICK
            </span>
          )}
        </PoseArt>
        <HeartBtn
          poseId={pose.id}
          size={13}
          className="absolute right-2 top-2 h-7 w-7"
        />
      </div>
      <div className="p-2.5">
        <p className="line-clamp-1 text-xs font-semibold" style={{ color: colors.textPrimary }}>
          {pose.title}
        </p>
        <div className="mt-1.5 flex items-center justify-between">
          <span className="text-[10px]" style={{ color: colors.textSecondary }}>
            {POSE_CATEGORIES.find((c) => c.id === pose.category)?.label}
          </span>
          <span
            className="h-1.5 w-1.5 rounded-full"
            style={{ backgroundColor: DIFFICULTY_META[pose.difficulty].dot }}
          />
        </div>
      </div>
    </button>
  );
}

/* ── Search history tray ───────────────────────────────────────────────── */

function HistoryTray() {
  const { colors, searchHistory, applyHistoryQuery, commitSearch, clearSearchHistory } = usePreview();
  if (searchHistory.length === 0) return null;
  return (
    <div
      className="mx-4 mt-2 rounded-xl border p-3"
      style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
    >
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: colors.textDisabled }}>
          Recent searches
        </p>
        <button
          onMouseDown={(e) => e.preventDefault()}
          onClick={clearSearchHistory}
          className="cursor-pointer text-[10px] font-semibold"
          style={{ color: colors.primary }}
        >
          Clear
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {searchHistory.map((entry) => (
          <button
            key={entry}
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              applyHistoryQuery(entry);
              commitSearch(entry);
            }}
            className="flex cursor-pointer items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] pv-press"
            style={{ borderColor: colors.divider, color: colors.textSecondary }}
          >
            <Clock size={11} /> {entry}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Discovery mode (no filters) ───────────────────────────────────────── */

function DiscoveryView() {
  const { colors, isDark, setExploreCategory, openPose, pushLog } = usePreview();
  const featured = useMemo(() => getFeaturedPoses(), []);
  const all = useMemo(() => getPoseCatalog(), []);
  const report = useMemo(() => getCatalogReport(), []);
  return (
    <div className="pb-4">
      {/* Featured collection */}
      <div className="mt-4 flex items-baseline justify-between px-4">
        <p className="text-sm font-semibold" style={{ color: colors.textPrimary }}>
          Featured this week
        </p>
        <span className="text-[10px]" style={{ color: colors.textSecondary }}>
          {featured.length} editor picks
        </span>
      </div>
      <div className="mt-2.5 flex snap-x snap-mandatory gap-2.5 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {featured.map((pose) => {
          const Icon = CATEGORY_ICON[pose.category];
          return (
            <div
              key={pose.id}
              className="relative w-[8.5rem] shrink-0 snap-start overflow-hidden rounded-xl"
            >
              <button
                onClick={() => openPose(pose.id)}
                className="w-full cursor-pointer text-left pv-press-card"
              >
                <PoseArt pose={pose} isDark={isDark} className="h-36" rounded="rounded-xl" iconSize={48}>
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/55 to-transparent p-2 pt-6">
                    <p className="line-clamp-2 text-[10px] font-semibold leading-tight text-white">{pose.title}</p>
                    <div className="mt-1 flex items-center gap-1 text-white/80">
                      <Icon size={10} />
                      <span className="text-[9px]">
                        {POSE_CATEGORIES.find((c) => c.id === pose.category)?.label}
                      </span>
                    </div>
                  </div>
                </PoseArt>
              </button>
              <HeartBtn
                poseId={pose.id}
                size={13}
                className="absolute right-2 top-2 h-7 w-7"
              />
            </div>
          );
        })}
      </div>

      {/* Category collections */}
      <div className="mt-5 flex items-baseline justify-between px-4">
        <p className="text-sm font-semibold" style={{ color: colors.textPrimary }}>
          Browse collections
        </p>
        <span className="text-[10px]" style={{ color: colors.textSecondary }}>
          {report.total} poses · 12 categories
        </span>
      </div>
      <div className="mt-2.5 grid grid-cols-2 gap-2 px-4">
        {POSE_CATEGORIES.map((meta) => {
          const Icon = CATEGORY_ICON[meta.id];
          const count = report.perCategory[meta.id] ?? 0;
          return (
            <button
              key={meta.id}
              onClick={() => {
                setExploreCategory(meta.id);
                pushLog("info", "Explore", `collection opened → ${meta.id} (${count} poses)`);
              }}
              className="flex cursor-pointer items-center gap-2.5 rounded-xl border p-2.5 text-left pv-lift"
              style={{
                borderColor: colors.divider,
                backgroundColor: colors.surface,
              }}
            >
              <span
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
                style={{ backgroundColor: `hsl(${meta.hue} 70% ${isDark ? 30 : 90}% / ${isDark ? 0.5 : 1})` }}
              >
                <Icon size={18} style={{ color: `hsl(${meta.hue} 65% ${isDark ? 70 : 40}%)` }} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-xs font-semibold" style={{ color: colors.textPrimary }}>
                  {meta.label}
                </span>
                <span className="block text-[10px]" style={{ color: colors.textSecondary }}>
                  {count} poses
                </span>
              </span>
              <ChevronRight size={14} style={{ color: colors.textDisabled }} />
            </button>
          );
        })}
      </div>

      {/* All poses preview */}
      <div className="mt-5 flex items-baseline justify-between px-4">
        <p className="text-sm font-semibold" style={{ color: colors.textPrimary }}>
          All poses
        </p>
        <span className="text-[10px]" style={{ color: colors.textSecondary }}>
          tap a card for the detail sheet
        </span>
      </div>
      <div className="mt-2.5 grid grid-cols-2 gap-2.5 px-4">
        {all.slice(0, 12).map((pose) => (
          <GridPoseCard key={pose.id} pose={pose} />
        ))}
      </div>
      <p className="mt-3 px-4 text-center text-[10px]" style={{ color: colors.textDisabled }}>
        Showing 12 of {all.length} — search or open a collection to see everything
      </p>
    </div>
  );
}

/* ── Results mode (search and/or filters active) ───────────────────────── */

function ResultsView() {
  const {
    colors, exploreQuery, exploreCategory, setExploreCategory,
    exploreDifficulty, setExploreDifficulty, resetExploreFilters,
    favorites,
  } = usePreview();

  const isFavoritesMode = exploreCategory === "favorites";

  const results = useMemo(() => {
    let pool: readonly Pose[];
    if (exploreCategory === "favorites") {
      const favSet = new Set(favorites);
      const favPoses = getPoseCatalog().filter((p) => favSet.has(p.id));
      const q = normalizeQuery(exploreQuery);
      pool =
        q.length === 0
          ? favPoses
          : favPoses.filter(
              (p) =>
                p.title.toLowerCase().includes(q) ||
                p.tags.some((t) => t.toLowerCase().includes(q)),
            );
    } else {
      pool = searchPoses(exploreQuery, {
        categoryId: exploreCategory as PoseCategoryId | "all",
      });
    }
    return filterByDifficulty(pool, exploreDifficulty);
  }, [exploreQuery, exploreCategory, exploreDifficulty, favorites]);

  const capped = results.slice(0, 40);

  return (
    <div className="pb-4">
      {/* Category chips rail with Favorites (Unit 10) */}
      <div className="mt-3 flex gap-1.5 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {[
          { id: "all" as const, label: "All", icon: Sparkles },
          { id: "favorites" as const, label: "Favorites", icon: Heart, count: favorites.length, accent: "#EF4444" },
          ...POSE_CATEGORIES.map((c) => ({
            id: c.id,
            label: c.label,
            icon: CATEGORY_ICON[c.id],
            count: undefined,
            accent: undefined,
          })),
        ].map((meta) => {
          const active = exploreCategory === meta.id;
          const Icon = meta.icon;
          return (
            <button
              key={meta.id}
              onClick={() =>
                setExploreCategory(meta.id as PoseCategoryId | "all" | "favorites")
              }
              className="flex shrink-0 cursor-pointer items-center gap-1 rounded-full border px-2.5 py-1.5 text-[11px] font-semibold pv-press"
              style={{
                borderColor: active ? colors.primary : colors.divider,
                backgroundColor: active ? colors.primary : colors.surface,
                color: active ? colors.textOnPrimary : meta.accent ?? colors.textSecondary,
              }}
            >
              <Icon size={11} fill={meta.id === "favorites" && !active ? "#EF4444" : "none"} /> {meta.label}
              {meta.count !== undefined && meta.count > 0 && (
                <span
                  className="rounded-full px-1.5 py-0.2 text-[9px] font-bold"
                  style={{
                    backgroundColor: active ? "rgba(255,255,255,0.25)" : colors.backgroundSecondary,
                    color: active ? colors.textOnPrimary : colors.textSecondary,
                  }}
                >
                  {meta.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
      {/* Difficulty chips */}
      <div className="mt-2 flex gap-1.5 px-4">
        {DIFFICULTY_FILTERS.map((f) => {
          const active = exploreDifficulty === f.id;
          return (
            <button
              key={f.id}
              onClick={() => setExploreDifficulty(f.id)}
              className="cursor-pointer rounded-full px-2.5 py-1 text-[10px] font-semibold pv-press"
              style={{
                backgroundColor: active ? colors.textPrimary : colors.backgroundSecondary,
                color: active ? colors.background : colors.textSecondary,
              }}
            >
              {f.label}
            </button>
          );
        })}
      </div>

      <p className="mt-3 px-4 text-[11px]" style={{ color: colors.textSecondary }}>
        {results.length} result{results.length === 1 ? "" : "s"}
        {normalizeQuery(exploreQuery) && (
          <>
            {" "}for <span className="font-semibold" style={{ color: colors.textPrimary }}>“{normalizeQuery(exploreQuery)}”</span>
          </>
        )}
      </p>

      {results.length === 0 ? (
        <div className="flex flex-col items-center px-8 py-14 text-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-full" style={{ backgroundColor: colors.backgroundSecondary }}>
            {isFavoritesMode ? (
              <Heart size={36} strokeWidth={1.5} style={{ color: "#EF4444" }} />
            ) : (
              <SearchX size={36} strokeWidth={1.5} style={{ color: colors.textDisabled }} />
            )}
          </div>
          <p className="mt-4 text-sm font-semibold" style={{ color: colors.textPrimary }}>
            {isFavoritesMode
              ? "No favorites yet"
              : exploreQuery.trim().length > 0
              ? `No results for “${exploreQuery.trim()}”`
              : "No poses found"}
          </p>
          <p className="mt-1.5 text-xs leading-relaxed" style={{ color: colors.textSecondary }}>
            {isFavoritesMode
              ? "Tap the heart icon on any pose to save it to your local library."
              : exploreQuery.trim().length > 0
              ? "Try a shorter search term, a different category, or clear search."
              : "Nothing matches that combination. Try a shorter word or clear the filters."}
          </p>
          <button
            onClick={resetExploreFilters}
            className="pv-press pv-btn-fill mt-5 cursor-pointer rounded-xl px-5 py-2.5 text-xs font-semibold text-white"
            style={{ backgroundColor: colors.primary }}
          >
            {isFavoritesMode
              ? "Explore Poses"
              : exploreQuery.trim().length > 0
              ? "Clear Search"
              : "Clear Filters"}
          </button>
        </div>
      ) : (
        <div className="mt-2.5 grid grid-cols-2 gap-2.5 px-4">
          {capped.map((pose) => (
            <GridPoseCard key={pose.id} pose={pose} />
          ))}
        </div>
      )}
      {results.length > capped.length && (
        <p className="mt-3 px-4 text-center text-[10px]" style={{ color: colors.textDisabled }}>
          Showing {capped.length} of {results.length} — Unit 24 adds lazy loading (20/page)
        </p>
      )}
    </div>
  );
}

/* ── Pose detail sheet (owned by Explore until Unit 09) ────────────────── */

function PoseDetailSheet() {
  const {
    colors, isDark, focusedPoseId, closePose, authStatus,
    setAuthReturnTab, navigatePreview, setActiveTab, pushLog, openPose,
    armCameraPose,
  } = usePreview();
  const pose = focusedPoseId !== null ? getPoseById(focusedPoseId) : null;
  useEffect(() => {
    if (pose) pushLog("debug", "Explore", `sheet mounted → ${pose.title}`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusedPoseId]);
  if (pose === null || pose === undefined) return null;
  const meta = POSE_CATEGORIES.find((c) => c.id === pose.category);

  const useThisPose = () => {
    if (authStatus !== "authenticated") {
      pushLog("warn", "Explore", "guest tried Use This Pose → auth gate (camera requires account)");
      setAuthReturnTab("camera");
      closePose();
      navigatePreview("auth");
      return;
    }
    pushLog("info", "Explore", `Use This Pose → camera with ${pose.id} (match target ${pose.matchTarget}%)`);
    closePose();
    // Mirrors the real router.push({ pathname: '/(tabs)/camera', params: { poseId } })
    armCameraPose(pose.id);
    setActiveTab("camera");
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-end">
      <button
        aria-label="Close"
        onClick={closePose}
        className="absolute inset-0 cursor-pointer"
        style={{ backgroundColor: colors.scrim }}
      />
      <div
        className="relative flex max-h-[86%] flex-col overflow-hidden rounded-t-3xl animate-[sheetUp_0.28s_ease-out]"
        style={{ backgroundColor: colors.background }}
      >
        <PoseArt pose={pose} isDark={isDark} className="h-40 shrink-0" rounded="rounded-none" iconSize={72}>
          <div className="absolute right-3 top-3 flex items-center gap-2">
            <HeartBtn
              poseId={pose.id}
              size={16}
              className="h-8 w-8"
            />
            <button
              onClick={closePose}
              className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-sm pv-press"
              aria-label="Close detail"
            >
              <X size={16} />
            </button>
          </div>
          <div className="absolute bottom-3 left-4 right-4">
            <p className="text-base font-bold leading-tight text-white drop-shadow">{pose.title}</p>
          </div>
        </PoseArt>
        <div className="flex-1 overflow-y-auto px-4 pb-5 pt-3.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="rounded-full px-2.5 py-1 text-[10px] font-semibold" style={{ backgroundColor: colors.primaryLight, color: colors.primary }}>
              {meta?.label}
            </span>
            <DifficultyChip difficulty={pose.difficulty} />
            {pose.isPremium && (
              <span className="flex items-center gap-1 rounded-full bg-amber-400/15 px-2.5 py-1 text-[10px] font-semibold text-amber-500">
                <Crown size={10} /> Premium
              </span>
            )}
            <span className="flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold" style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}>
              <Target size={10} /> Auto-capture at {pose.matchTarget}%
            </span>
          </div>
          <p className="mt-3 text-xs leading-relaxed" style={{ color: colors.textSecondary }}>
            {pose.description}
          </p>
          <p className="mt-4 text-[10px] font-semibold uppercase tracking-wide" style={{ color: colors.textDisabled }}>
            Photographer tips
          </p>
          <div className="mt-2 flex flex-col gap-2">
            {pose.tips.map((tip) => (
              <div key={tip} className="flex items-start gap-2">
                <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: colors.primaryLight }}>
                  <Check size={10} style={{ color: colors.primary }} />
                </span>
                <p className="text-xs leading-relaxed" style={{ color: colors.textSecondary }}>{tip}</p>
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {pose.tags.map((tag) => (
              <span key={tag} className="rounded-full px-2 py-0.5 text-[10px]" style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}>
                #{tag}
              </span>
            ))}
          </div>

          {/* Unit 10 — related poses engine, same-category rail (mirror of
              /pose/[id] "More like this"; in the app each tap pushes the
              deep-link route smartphotography://pose/<id>) */}
          <div className="mt-4 flex items-baseline justify-between">
            <p className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: colors.textDisabled }}>
              More like this
            </p>
            <p className="text-[9px]" style={{ color: colors.textDisabled }}>
              deep-link: /pose/{pose.id.slice(5, 22)}…
            </p>
          </div>
          <div className="mt-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {getRelatedPoses(pose, 8).map((related) => (
              <button
                key={related.id}
                onClick={() => openPose(related.id)}
                className="w-20 shrink-0 cursor-pointer text-left pv-press"
              >
                <PoseArt pose={related} isDark={isDark} className="h-20" rounded="rounded-lg" iconSize={22} />
                <p className="mt-1 line-clamp-1 text-[9px] font-semibold" style={{ color: colors.textPrimary }}>
                  {related.title}
                </p>
              </button>
            ))}
          </div>
        </div>
        <div className="shrink-0 border-t px-4 pb-4 pt-3" style={{ borderColor: colors.divider }}>
          <button
            onClick={useThisPose}
            className="pv-press pv-btn-fill flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-semibold text-white"
            style={{ backgroundColor: colors.primary }}
          >
            <Camera size={16} /> Use This Pose
          </button>
          <p className="mt-2 text-center text-[9px]" style={{ color: colors.textDisabled }}>
            {authStatus === "authenticated"
              ? "Opens the camera with this reference pinned for live guidance"
              : "Sign-in required — the camera suite is an authenticated feature"}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ── Screen ────────────────────────────────────────────────────────────── */

export function ExploreMirror() {
  const {
    colors, exploreQuery, setExploreQuery, exploreCategory, exploreDifficulty,
    commitSearch, pushLog, favorites, authStatus, setExploreCategory,
  } = usePreview();
  const [focused, setFocused] = useState(false);
  const blurTimer = useRef<number | null>(null);
  const report = useMemo(() => getCatalogReport(), []);
  const filtering =
    normalizeQuery(exploreQuery).length > 0 ||
    exploreCategory !== "all" ||
    exploreDifficulty !== "all";

  useEffect(() => () => {
    if (blurTimer.current !== null) window.clearTimeout(blurTimer.current);
  }, []);

  return (
    <div className="relative flex h-full flex-col" style={{ backgroundColor: colors.background }}>
      {/* Header + search (mirrors ExploreSearchBar) */}
      <div className="shrink-0 px-4 pb-2 pt-3">
        <div className="flex items-center justify-between">
          <p className="text-lg font-bold" style={{ color: colors.textPrimary }}>Explore</p>
          <div className="flex items-center gap-2">
            <p className="text-[10px]" style={{ color: colors.textSecondary }}>
              {report.total} poses · offline catalog
            </p>
            <button
              onClick={() => setExploreCategory("favorites")}
              aria-label={
                authStatus === "authenticated"
                  ? `Open ${favorites.length} favorites`
                  : "Sign in to view favorites"
              }
              className="flex h-8 min-w-8 cursor-pointer items-center justify-center gap-1 rounded-full px-2 pv-press"
              style={{ backgroundColor: colors.backgroundSecondary }}
            >
              <Heart size={13} color={colors.error} />
              {authStatus === "authenticated" && favorites.length > 0 && (
                <span className="text-[9px] font-semibold" style={{ color: colors.textSecondary }}>
                  {favorites.length}
                </span>
              )}
            </button>
          </div>
        </div>
        <div
          className="mt-2.5 flex items-center gap-2 rounded-xl border px-3 transition"
          style={{
            borderColor: focused ? colors.primary : colors.divider,
            backgroundColor: colors.backgroundSecondary,
          }}
        >
          <Search size={15} style={{ color: focused ? colors.primary : colors.textDisabled }} />
          <input
            value={exploreQuery}
            onChange={(e) => setExploreQuery(e.target.value)}
            onFocus={() => {
              setFocused(true);
              pushLog("debug", "Explore", "search focused — history tray visible");
            }}
            onBlur={() => {
              blurTimer.current = window.setTimeout(() => setFocused(false), 150);
              commitSearch(exploreQuery);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                commitSearch(exploreQuery);
                (e.target as HTMLInputElement).blur();
              }
            }}
            placeholder="Search poses, tags, collections…"
            className="w-full bg-transparent py-2.5 text-xs outline-none"
            style={{ color: colors.textPrimary }}
          />
          {exploreQuery.length > 0 && (
            <button
              onClick={() => setExploreQuery("")}
              className="cursor-pointer"
              aria-label="Clear search"
            >
              <X size={13} style={{ color: colors.textDisabled }} />
            </button>
          )}
        </div>
      </div>

      {focused && normalizeQuery(exploreQuery).length === 0 && <HistoryTray />}

      <div className="flex-1 overflow-y-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {filtering ? <ResultsView /> : <DiscoveryView />}
      </div>

      <PoseDetailSheet />
    </div>
  );
}
