/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * ----------------------------------------------------------------------
 * Mirrors mobile/src/core/ml/poseDetectorService.ts ONE-TO-ONE: the same
 * @mediapipe/tasks-vision package, same lite model, same 66ms (15fps)
 * throttle, same disposal semantics. It feeds the PHONE PREVIEW only, so
 * you can see the real Unit 16 pipeline (skeleton + match %) running in
 * this browser. In the shipped app the native camera runs this code path;
 * Expo web is gated by Unit 12's "Camera not supported on web" notice.
 * Metro never bundles this file.
 *
 * The tasks-vision module is imported LAZILY (inside init, first camera use
 * only) — never at app boot. This mirrors the mobile service's dynamic
 * import and guarantees the phone preview renders even in environments where
 * the wasm package cannot evaluate.
 */
import type { HandLandmarker, PoseLandmarker } from "@mediapipe/tasks-vision";
import {
  HAND_LANDMARK_COUNT,
  POSE_LANDMARK_COUNT,
  type HandObservation,
  type PoseLandmark,
} from "../../../../shared/index";
import type { LogLevel } from "./preview-state";

/**
 * ABI-locked to the installed package (root package.json pins 0.10.35
 * exactly) — the JS API and the wasm internals must be the same version.
 */
const WASM_BASE_URL =
  "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm";
const MODEL_ASSET_URL =
  "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task";

/** 15fps ML budget — identical to mobile/src/core/ml/imageConverter.ts. */
export const PREVIEW_ML_THROTTLE_MS = 66;

const MAX_CONSECUTIVE_FAILURES = 8;

/**
 * Result contract shared with the app service: null = frame skipped by the
 * throttle, [] = processed but no person in frame, array = 33 landmarks.
 */
export type PreviewDetection = readonly PoseLandmark[] | null;

export class PreviewPoseRunner {
  private landmarker: PoseLandmarker | null = null;
  private initPromise: Promise<boolean> | null = null;
  private disposed = false;
  private lastProcessedAt = 0;
  private lastVideoTimestamp = 0;
  private consecutiveFailures = 0;

  get isModelReady(): boolean {
    return this.landmarker !== null;
  }

  async init(log: (level: LogLevel, tag: string, message: string) => void): Promise<boolean> {
    if (this.landmarker !== null) return true;
    if (this.initPromise !== null) return this.initPromise;
    const startedAt = performance.now();
    log("info", "ML", "PoseLandmarker init — pose_landmarker_lite (on-device wasm)");
    this.initPromise = (async () => {
      try {
        const vision = await import("@mediapipe/tasks-vision");
        const fileset = await vision.FilesetResolver.forVisionTasks(WASM_BASE_URL);
        this.landmarker = await vision.PoseLandmarker.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: MODEL_ASSET_URL },
          runningMode: "VIDEO",
          numPoses: 1,
          minPoseDetectionConfidence: 0.5,
          minPosePresenceConfidence: 0.5,
          minTrackingConfidence: 0.5,
          outputSegmentationMasks: false,
        });
        log(
          "info",
          "ML",
          `model ready in ${Math.round(performance.now() - startedAt)}ms — 33 landmarks, 15fps budget`,
        );
        return true;
      } catch (error) {
        this.landmarker = null;
        log(
          "error",
          "ML",
          `PoseLandmarker unavailable — ${String(error)}. Camera continues without overlays (scoped fallback).`,
        );
        return false;
      }
    })();
    const ready = await this.initPromise;
    this.initPromise = null;
    return ready;
  }

  /** Throttled detection — same triple-state contract as the app service. */
  detect(video: HTMLVideoElement, timestampMs: number): PreviewDetection {
    const landmarker = this.landmarker;
    if (landmarker === null || this.disposed) return null;
    if (video.videoWidth === 0 || video.readyState < 2) return null;
    if (timestampMs - this.lastProcessedAt < PREVIEW_ML_THROTTLE_MS) return null;
    this.lastProcessedAt = timestampMs;
    const videoTimestamp = Math.max(timestampMs, this.lastVideoTimestamp + 1);
    try {
      const result = landmarker.detectForVideo(video, videoTimestamp);
      this.lastVideoTimestamp = videoTimestamp;
      this.consecutiveFailures = 0;
      const pose = result.landmarks[0];
      if (pose === undefined) return [];
      if (pose.length < POSE_LANDMARK_COUNT) return [];
      return pose.map((landmark) => ({
        x: landmark.x,
        y: landmark.y,
        z: landmark.z,
        visibility: landmark.visibility ?? 1,
      }));
    } catch {
      this.consecutiveFailures += 1;
      if (this.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
        this.dispose(() => undefined);
      }
      return null;
    }
  }

  dispose(log: (level: LogLevel, tag: string, message: string) => void): void {
    if (this.landmarker !== null) {
      try {
        this.landmarker.close();
      } catch {
        // close() races are harmless; the session is ending regardless.
      }
    }
    this.landmarker = null;
    this.disposed = true;
    this.initPromise = null;
    this.lastProcessedAt = 0;
    this.lastVideoTimestamp = 0;
    this.consecutiveFailures = 0;
    log("info", "ML", "PoseLandmarker disposed — wasm resources released");
  }
}

/**
 * ⚠ PREVIEW MIRROR of mobile/src/core/ml/handDetectorService.ts.
 *
 * Same package, same pinned version, same lazy import, same "two hands, then
 * the classifier picks one" policy, same scoped failure (gesture capture goes
 * quiet; the camera and coaching are untouched). It exists so the hardened
 * five-finger gesture can be watched behaving in this browser — it is NOT the
 * production path and Metro never bundles it.
 */
const HAND_MODEL_ASSET_URL =
  "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";

export class PreviewHandRunner {
  private landmarker: HandLandmarker | null = null;
  private initPromise: Promise<boolean> | null = null;
  private disposed = false;
  private loadFailed = false;
  private lastVideoTimestamp = 0;
  private consecutiveFailures = 0;

  get isModelReady(): boolean {
    return this.landmarker !== null;
  }

  async init(log: (level: LogLevel, tag: string, message: string) => void): Promise<boolean> {
    if (this.landmarker !== null) return true;
    if (this.loadFailed || this.disposed) return false;
    if (this.initPromise !== null) return this.initPromise;
    const startedAt = performance.now();
    log("info", "Gesture", "HandLandmarker init — hand_landmarker (on-device wasm)");
    this.initPromise = (async () => {
      try {
        const vision = await import("@mediapipe/tasks-vision");
        const fileset = await vision.FilesetResolver.forVisionTasks(WASM_BASE_URL);
        this.landmarker = await vision.HandLandmarker.createFromOptions(fileset, {
          baseOptions: { modelAssetPath: HAND_MODEL_ASSET_URL },
          runningMode: "VIDEO",
          numHands: 2,
          minHandDetectionConfidence: 0.6,
          minHandPresenceConfidence: 0.6,
          minTrackingConfidence: 0.6,
        });
        log(
          "info",
          "Gesture",
          `hand model ready in ${Math.round(performance.now() - startedAt)}ms — 21 landmarks/hand`,
        );
        return true;
      } catch (error) {
        this.landmarker = null;
        this.loadFailed = true;
        log(
          "warn",
          "Gesture",
          `hand landmarker unavailable — palm capture disabled (${String(error)})`,
        );
        return false;
      }
    })();
    const ready = await this.initPromise;
    this.initPromise = null;
    return ready;
  }

  /** null = unusable detector, [] = frame processed, no hand. */
  detect(video: HTMLVideoElement, timestampMs: number): readonly HandObservation[] | null {
    const landmarker = this.landmarker;
    if (landmarker === null || this.disposed) return null;
    if (video.videoWidth === 0 || video.readyState < 2) return null;
    const videoTimestamp = Math.max(timestampMs, this.lastVideoTimestamp + 1);
    try {
      const result = landmarker.detectForVideo(video, videoTimestamp);
      this.lastVideoTimestamp = videoTimestamp;
      this.consecutiveFailures = 0;
      const handedness = result.handedness ?? [];
      const observations: HandObservation[] = [];
      for (let index = 0; index < result.landmarks.length; index += 1) {
        const points = result.landmarks[index];
        if (points === undefined || points.length < HAND_LANDMARK_COUNT) continue;
        const category = handedness[index]?.[0];
        const label = (category?.categoryName ?? "").toLowerCase();
        observations.push({
          landmarks: points.map((point) => ({ x: point.x, y: point.y, z: point.z })),
          side: label === "left" ? "left" : label === "right" ? "right" : "unknown",
          score: typeof category?.score === "number" ? category.score : 0,
        });
      }
      return observations;
    } catch {
      this.consecutiveFailures += 1;
      if (this.consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
        this.dispose(() => undefined);
      }
      return null;
    }
  }

  dispose(log: (level: LogLevel, tag: string, message: string) => void): void {
    if (this.landmarker !== null) {
      try {
        this.landmarker.close();
      } catch {
        // close() races are harmless; the session is ending regardless.
      }
    }
    this.landmarker = null;
    this.disposed = true;
    this.initPromise = null;
    this.lastVideoTimestamp = 0;
    this.consecutiveFailures = 0;
    log("info", "Gesture", "HandLandmarker disposed");
  }
}
