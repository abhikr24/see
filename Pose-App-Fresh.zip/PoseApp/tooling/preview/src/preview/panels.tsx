/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Right-hand panels: build progress tracker (24 units), the AppLogger ring
 * buffer console, and the design token gallery rendered from shared/theme.
 */
import { useEffect, useRef, useState } from "react";
import { Check, CircleDashed, Loader, Rocket, Terminal } from "lucide-react";
import {
  MATCH_COLOR_BANDS,
  darkColors,
  lightColors,
  radius,
  spacing,
} from "../../../../shared/index";
import { usePreview, type LogLevel } from "./preview-state";

/* ── Progress tracker (mirrors mobile/docs/progress-tracker.md) ────────── */

interface Unit {
  n: number;
  title: string;
  phase: string;
  state: "done" | "new" | "next" | "future";
  note?: string;
}

const UNITS: Unit[] = [
  { n: 1, title: "Project setup & design tokens", phase: "Foundation", state: "done" },
  { n: 2, title: "App shell & bottom navigation", phase: "Foundation", state: "done" },
  { n: 3, title: "Splash, welcome & onboarding", phase: "Foundation", state: "done" },
  { n: 4, title: "Permissions flow", phase: "Foundation", state: "done" },
  { n: 5, title: "Pose library local data layer", phase: "Data", state: "done" },
  { n: 6, title: "Auth & Supabase (demo-first)", phase: "Data", state: "done" },
  { n: 7, title: "Home dashboard", phase: "Library", state: "done" },
  { n: 8, title: "Explore — search, collections & pose grid", phase: "Library", state: "done" },
  { n: 9, title: "Search & smart filters", phase: "Library", state: "done" },
  { n: 10, title: "Pose detail, related poses & deep links", phase: "Library", state: "done" },
  { n: 11, title: "Favorites: local replica, sync, RLS & auth", phase: "Library", state: "done" },
  { n: 12, title: "Camera foundation — preview & controls", phase: "Camera", state: "done" },
  { n: 13, title: "Capture, processing, preview & save (device-only)", phase: "Camera", state: "done" },
  { n: 14, title: "Gallery tab complete", phase: "Camera", state: "done" },
  { n: 15, title: "Pose history & recents wiring", phase: "Camera", state: "done" },
  { n: 16, title: "MediaPipe core, overlay & match %", phase: "Camera", state: "done" },
  {
    n: 17,
    title: "Pose comparison & visual guidance",
    phase: "Camera",
    state: "done",
  },
  { n: 18, title: "Intelligent capture suite (voice/auto/gesture)", phase: "Camera", state: "done" },
  { n: 19, title: "Profile tab", phase: "Profile", state: "done" },
  { n: 20, title: "Settings — camera & capture prefs", phase: "Profile", state: "done" },
  { n: 21, title: "Settings — system (theme/language/privacy/about)", phase: "Profile", state: "done" },
  { n: 22, title: "Global error handling", phase: "Polish", state: "done" },
  { n: 23, title: "UI states system", phase: "Polish", state: "done" },
  {
    n: 24,
    title: "Performance & final verification",
    phase: "Polish",
    state: "done",
    note: "final",
  },
];

export function ProgressPanel() {
  let lastPhase = "";
  return (
    <div className="flex flex-col gap-0.5">
      {UNITS.map((u) => {
        const phaseHeader = u.phase !== lastPhase ? u.phase : null;
        lastPhase = u.phase;
        return (
          <div key={u.n}>
            {phaseHeader && (
              <p className="mb-1 mt-3 text-[9px] font-bold uppercase tracking-[0.14em] text-zinc-500 first:mt-0">
                {u.phase}
              </p>
            )}
            <div
              className={`flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 ${
                u.state === "new" ? "bg-blue-500/10 ring-1 ring-blue-500/30" : ""
              }`}
            >
              {u.state === "done" || u.state === "new" ? (
                <span className={`flex h-4.5 w-4.5 h-[18px] w-[18px] items-center justify-center rounded-full ${u.state === "new" ? "bg-blue-500" : "bg-emerald-500/20 text-emerald-400"}`}>
                  <Check size={11} strokeWidth={3} className={u.state === "new" ? "text-white" : ""} />
                </span>
              ) : u.state === "next" ? (
                <Loader size={18} className="text-sky-400" />
              ) : (
                <CircleDashed size={18} className="text-zinc-700" />
              )}
              <div className="min-w-0 flex-1">
                <p
                  className={`truncate text-xs font-medium ${
                    u.state === "future" ? "text-zinc-600" : "text-zinc-200"
                  }`}
                >
                  <span className="mr-1.5 font-mono text-[10px] text-zinc-500">
                    {String(u.n).padStart(2, "0")}
                  </span>
                  {u.title}
                </p>
              </div>
              {u.note && (
                <span className="rounded-full bg-blue-500/20 px-2 py-0.5 text-[9px] font-bold text-blue-300">
                  {u.note}
                </span>
              )}
              {u.state === "next" && (
                <span className="rounded-full bg-sky-500/15 px-2 py-0.5 text-[9px] font-bold text-sky-300">
                  next up
                </span>
              )}
            </div>
          </div>
        );
      })}
      <div className="mt-4 flex items-center gap-2 rounded-lg border border-emerald-900/50 bg-emerald-950/30 px-3 py-2.5">
        <Rocket size={14} className="shrink-0 text-emerald-400" />
        <p className="text-[10px] leading-relaxed text-emerald-300">
          All 24 planned units are represented in code. Release certification remains blocked by native
          MediaPipe frame processing, licensed pose references, EAS mobile builds, and physical-device QA.
        </p>
      </div>
    </div>
  );
}

/* ── Console (AppLogger mirror) ─────────────────────────────────────────── */

const LEVEL_STYLE: Record<LogLevel, string> = {
  debug: "text-zinc-500",
  info: "text-sky-400",
  warn: "text-amber-400",
  error: "text-red-400",
};

export function ConsolePanel() {
  const { logs } = usePreview();
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [logs.length]);
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 pb-2 text-[10px] font-semibold uppercase tracking-wider text-zinc-500">
        <Terminal size={12} /> AppLogger · ring buffer 50
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto rounded-lg border border-zinc-800 bg-black/50 p-2 font-mono text-[10px] leading-relaxed">
        {logs.map((line) => (
          <div key={line.id} className="flex gap-2 whitespace-nowrap">
            <span className="text-zinc-600">{line.time}</span>
            <span className={`w-10 shrink-0 ${LEVEL_STYLE[line.level]}`}>
              {line.level.toUpperCase()}
            </span>
            <span className="w-24 shrink-0 truncate text-zinc-400">[{line.tag}]</span>
            <span className="truncate text-zinc-300">{line.message}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
}

/* ── Token gallery (compact) ───────────────────────────────────────────── */

export function TokensPanel() {
  const { isDark } = usePreview();
  const schemes: { name: string; colors: typeof lightColors }[] = [
    { name: "Light", colors: lightColors },
    { name: "Dark", colors: darkColors },
  ];
  const keys: (keyof typeof lightColors)[] = [
    "primary", "primaryPressed", "primaryLight", "success", "warning", "error",
    "background", "backgroundSecondary", "surface", "divider",
    "textPrimary", "textSecondary", "textDisabled",
  ];
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3">
        {schemes.map(({ name, colors }) => (
          <div key={name} className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-2.5">
            <p className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">{name}</p>
            <div className="grid grid-cols-2 gap-1.5">
              {keys.map((key) => (
                <div key={key} className="flex items-center gap-1.5">
                  <span
                    className="h-3.5 w-3.5 shrink-0 rounded border border-white/10"
                    style={{ backgroundColor: colors[key] }}
                  />
                  <span className="truncate text-[9px] text-zinc-400">{key}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-2.5">
        <p className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">Match % ramp</p>
        <div className="flex gap-1.5">
          {MATCH_COLOR_BANDS.map((band) => (
            <div key={band.label} className="flex-1 rounded-md p-1.5 text-center" style={{ backgroundColor: `${band.color}22` }}>
              <p className="text-[9px] font-bold" style={{ color: band.color }}>{band.min}–{band.max}%</p>
              <p className="text-[8px] text-zinc-500">{band.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-2.5">
          <p className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">Spacing (8pt)</p>
          {Object.entries(spacing).map(([key, value]) => (
            <div key={key} className="flex items-center gap-2 py-0.5">
              <span className="rounded-sm bg-blue-500/60" style={{ width: Math.max(3, value / 2), height: 8 }} />
              <span className="font-mono text-[9px] text-zinc-400">{key} · {value}</span>
            </div>
          ))}
        </div>
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-2.5">
          <p className="mb-2 text-[9px] font-bold uppercase tracking-wider text-zinc-500">Radius</p>
          <div className="flex flex-wrap gap-1.5">
            {Object.entries(radius).map(([key, value]) => (
              <span key={key} className="rounded border border-zinc-700 px-1.5 py-0.5 font-mono text-[9px] text-zinc-400">
                {key} {value === 9999 ? "50%" : value}
              </span>
            ))}
          </div>
          <p className="mt-3 text-[9px] leading-relaxed text-zinc-500">
            Live scheme on the phone: <span className="font-semibold text-zinc-300">{isDark ? "dark" : "light"}</span> —
            switch themes on the Profile tab.
          </p>
        </div>
      </div>
    </div>
  );
}

export function SidePanels() {
  const [tab, setTab] = useState<"progress" | "console" | "tokens">("progress");
  const tabs = [
    { key: "progress" as const, label: "Build Progress" },
    { key: "console" as const, label: "Console" },
    { key: "tokens" as const, label: "Tokens" },
  ];
  return (
    <div className="flex h-full flex-col rounded-2xl border border-zinc-800 bg-zinc-950/80 p-4">
      <div className="mb-3 flex gap-1 rounded-lg bg-zinc-900 p-1">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex-1 cursor-pointer rounded-md py-1.5 text-[11px] font-semibold transition ${
              tab === t.key ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        {tab === "progress" && <ProgressPanel />}
        {tab === "tokens" && <TokensPanel />}
        {tab === "console" && <ConsolePanel />}
      </div>
    </div>
  );
}
