/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Device frame + status bar + the router mirror that swaps between the
 * first-run flow (Units 03–06) and the tab shell (Unit 02 → 08).
 *
 * Premium pass (items 5–8): this container injects the shared motion /
 * elevation / gradient / pressed-fill tokens as CSS custom properties
 * (--pv-*) so every mirrored screen consumes the identical token system
 * the Expo app uses.
 */
import { Battery, RotateCcw, Signal, Wifi } from "lucide-react";
import type { CSSProperties } from "react";
import {
  cssBrandGradient,
  cssBrandGradientPressed,
  cssEase,
  cssScrimBottom,
  cssScrimTop,
  cssSplashGradient,
  cssSpring,
  elevationBoxShadow,
  motionDuration,
} from "../../../../shared/index";
import {
  AuthMirror,
  OnboardingMirror,
  PermissionsMirror,
  SplashMirror,
  WelcomeMirror,
} from "./screens-intro";
import { TabsMirror } from "./screens-tabs";
import { usePreview } from "./preview-state";

function StatusBar() {
  const { colors } = usePreview();
  return (
    <div
      className="flex shrink-0 items-center justify-between px-6 pb-1 pt-3"
      style={{ backgroundColor: colors.background }}
    >
      <span className="text-[11px] font-semibold" style={{ color: colors.textPrimary }}>
        9:41
      </span>
      <div className="absolute left-1/2 h-[22px] w-[110px] -translate-x-1/2 rounded-full bg-black" />
      <div className="flex items-center gap-1.5" style={{ color: colors.textPrimary }}>
        <Signal size={12} />
        <Wifi size={12} />
        <Battery size={14} />
      </div>
    </div>
  );
}

function CurrentScreen() {
  const { previewRoute } = usePreview();
  switch (previewRoute) {
    case "splash":
      return <SplashMirror />;
    case "welcome":
      return <WelcomeMirror />;
    case "onboarding":
      return <OnboardingMirror />;
    case "permissions":
      return <PermissionsMirror />;
    case "auth":
      return <AuthMirror />;
    default:
      return <TabsMirror />;
  }
}

export function PhonePreview() {
  const { replayIntro, colors, scheme } = usePreview();
  // Token → CSS custom property bridge (see src/index.css for consumers).
  const tokenVars = {
    "--pv-dur-tap": `${motionDuration.tap}ms`,
    "--pv-dur-standard": `${motionDuration.standard}ms`,
    "--pv-ease-standard": cssEase.standard,
    "--pv-spring-snappy": cssSpring.snappy,
    "--pv-spring-bouncy": cssSpring.bouncy,
    "--pv-primary-pressed": colors.primaryPressed,
    "--pv-primary-light-pressed": colors.primaryLightPressed,
    "--pv-ghost-pressed": colors.ghostPressed,
    "--pv-surface-pressed": colors.surfacePressed,
    "--pv-grad-brand": cssBrandGradient(scheme),
    "--pv-grad-brand-pressed": cssBrandGradientPressed(scheme),
    "--pv-grad-splash": cssSplashGradient(scheme),
    "--pv-scrim-top": cssScrimTop(),
    "--pv-scrim-bottom": cssScrimBottom(),
    "--pv-elev-1": elevationBoxShadow("resting", colors),
    "--pv-elev-2": elevationBoxShadow("floating", colors),
    "--pv-elev-2-up": elevationBoxShadow("floating", colors, "up"),
    "--pv-elev-3": elevationBoxShadow("overlay", colors),
  } as CSSProperties;
  return (
    <div className="flex flex-col items-center">
      <div className="relative w-[330px] rounded-[44px] border border-white/10 bg-zinc-950 p-[10px] shadow-[0_32px_80px_-24px_rgba(0,0,0,0.75)] ring-1 ring-black">
        <div className="relative h-[680px] w-full overflow-hidden rounded-[36px]" style={tokenVars}>
          <StatusBar />
          <div className="h-[calc(100%-40px)]">
            <CurrentScreen />
          </div>
        </div>
      </div>
      <button
        onClick={replayIntro}
        className="pv-press mt-5 flex cursor-pointer items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-zinc-300 transition-colors hover:border-white/30 hover:text-white"
      >
        <RotateCcw size={13} /> Replay first-run flow
      </button>
    </div>
  );
}
