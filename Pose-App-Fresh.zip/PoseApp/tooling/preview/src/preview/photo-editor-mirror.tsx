/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 *
 * POST-CAPTURE EDITING mirror (crop · rotate · enhance).
 *
 * WHAT IS REAL HERE AND WHAT IS NOT — stated plainly, because the rule in this
 * repo is that the mirror must never pretend to be the device:
 *
 *   REAL: every number. The rotation, the crop rectangle, the aspect-ratio
 *   constraint, the enhancement matrix and the output dimensions all come from
 *   `shared/camera/photoEditing` — the SAME functions the Expo app feeds to
 *   Skia. Apply really does rewrite the pixels on a 2D canvas through the same
 *   twenty numbers and the same draw transform, and really does produce a new
 *   JPEG data URL. Nothing is faked with CSS at apply time.
 *
 *   NOT REAL: the rendering ENGINE. The phone uses Skia on the GPU and writes
 *   a file to the app's cache; the browser uses a canvas and keeps a data URL
 *   in memory. Live sliders here preview through an SVG `feColorMatrix`
 *   carrying the identical matrix (exact transform, different rasteriser),
 *   while the phone previews through a Skia canvas. So colour and geometry
 *   match; timing, memory behaviour and file handling do not, and no claim
 *   about on-device performance can be made from this page.
 */
import { useCallback, useMemo, useRef, useState } from "react";
import { Check, Crop, RotateCw, Sparkles, X } from "lucide-react";
import {
  AUTO_ENHANCE,
  CROP_ASPECT_IDS,
  ENHANCE_NEUTRAL,
  FULL_FRAME_CROP,
  PHOTO_ADJUST_KEYS,
  PHOTO_EDIT_ADJUST_MAX,
  PHOTO_EDIT_ADJUST_MIN,
  PHOTO_EDIT_ADJUST_STEP,
  adjustBadge,
  adjustLabel,
  applyColorMatrix,
  applyCropGesture,
  clampAdjustValue,
  colorMatrixIsIdentity,
  cropAspectLabel,
  cropAspectValue,
  cropIsFullFrame,
  cropRectForAspect,
  describePhotoEdit,
  enhanceColorMatrix,
  photoEditDrawTransform,
  photoEditIsIdentity,
  resolvePhotoEditGeometry,
  rotateCropRect,
  rotateQuarterTurns,
  rotatedSize,
  rotationDegrees,
  rotationLabel,
  type CropAspectId,
  type CropHandle,
  type NormalizedRect,
  type PhotoAdjustKey,
  type PhotoEdit,
  type PhotoEnhance,
  type QuarterTurns,
} from "../../../../shared/index";

interface PhotoEditorMirrorProps {
  readonly dataUrl: string;
  readonly onCancel: () => void;
  readonly onApplied: (nextDataUrl: string, summary: string) => void;
  readonly onLog: (level: "info" | "warn" | "error", message: string) => void;
}

type Tool = "crop" | "rotate" | "enhance";

export function PhotoEditorMirror({
  dataUrl,
  onCancel,
  onApplied,
  onLog,
}: PhotoEditorMirrorProps) {
  const [tool, setTool] = useState<Tool>("crop");
  const [rotation, setRotation] = useState<QuarterTurns>(0);
  const [crop, setCrop] = useState<NormalizedRect>(FULL_FRAME_CROP);
  const [aspect, setAspect] = useState<CropAspectId>("free");
  const [enhance, setEnhance] = useState<PhotoEnhance>(ENHANCE_NEUTRAL);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [busy, setBusy] = useState(false);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{ start: NormalizedRect; handle: CropHandle; x: number; y: number } | null>(
    null,
  );

  const edit: PhotoEdit = useMemo(() => ({ rotation, crop, enhance }), [crop, enhance, rotation]);
  const matrix = useMemo(() => enhanceColorMatrix(enhance), [enhance]);
  const matrixValues = matrix.map((value) => Math.round(value * 10000) / 10000).join(" ");
  const identity = photoEditIsIdentity(edit);

  const rotated = rotatedSize(size.width, size.height, rotation);
  const frameAspect = rotated.height > 0 ? rotated.width / rotated.height : 1;
  const lockedAspect = cropAspectValue(aspect, rotated.width, rotated.height);

  const onPointerDown = useCallback(
    (handle: CropHandle) => (event: React.PointerEvent<HTMLDivElement>) => {
      event.preventDefault();
      event.currentTarget.setPointerCapture(event.pointerId);
      dragRef.current = { start: crop, handle, x: event.clientX, y: event.clientY };
    },
    [crop],
  );

  const onPointerMove = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      const drag = dragRef.current;
      const stage = stageRef.current;
      if (drag === null || stage === null) return;
      const box = stage.getBoundingClientRect();
      if (box.width === 0 || box.height === 0) return;
      setCrop(
        applyCropGesture(
          drag.start,
          drag.handle,
          (event.clientX - drag.x) / box.width,
          (event.clientY - drag.y) / box.height,
          lockedAspect,
          frameAspect,
        ),
      );
    },
    [frameAspect, lockedAspect],
  );

  const endDrag = useCallback(() => {
    dragRef.current = null;
  }, []);

  /**
   * THE REAL WORK. Identical shape to the device renderer: resolve geometry
   * from the DECODED size, create a surface of the output size, translate and
   * rotate by the published transform, draw once, then apply the colour matrix
   * to the pixels (the browser has no paint-level colour filter that survives
   * `toDataURL`, so it is done per pixel — the same matrix, the same result).
   */
  const apply = useCallback(() => {
    setBusy(true);
    const image = new Image();
    image.onload = () => {
      try {
        const geometry = resolvePhotoEditGeometry(edit, image.naturalWidth, image.naturalHeight);
        if (geometry.isIdentity) {
          setBusy(false);
          onCancel();
          return;
        }
        const canvas = document.createElement("canvas");
        canvas.width = geometry.outputWidth;
        canvas.height = geometry.outputHeight;
        const context = canvas.getContext("2d");
        if (context === null) throw new Error("no 2d context");
        const transform = photoEditDrawTransform(geometry);
        context.save();
        context.translate(transform.translateX, transform.translateY);
        if (transform.rotateDegrees !== 0) {
          context.rotate((transform.rotateDegrees * Math.PI) / 180);
        }
        context.drawImage(image, 0, 0);
        context.restore();

        if (!colorMatrixIsIdentity(geometry.matrix)) {
          const frame = context.getImageData(0, 0, canvas.width, canvas.height);
          const pixels = frame.data;
          for (let i = 0; i < pixels.length; i += 4) {
            const [r, g, b] = applyColorMatrix(
              [(pixels[i] ?? 0) / 255, (pixels[i + 1] ?? 0) / 255, (pixels[i + 2] ?? 0) / 255],
              geometry.matrix,
            );
            pixels[i] = Math.round(r * 255);
            pixels[i + 1] = Math.round(g * 255);
            pixels[i + 2] = Math.round(b * 255);
          }
          context.putImageData(frame, 0, 0);
        }

        /* 0.95 — the shared PHOTO_EDIT_JPEG_QUALITY, expressed as the fraction
           the canvas API wants. Second generation, so higher than capture. */
        const next = canvas.toDataURL("image/jpeg", 0.95);
        onLog(
          "info",
          `edit applied → ${describePhotoEdit(edit)} · ${geometry.outputWidth}×${geometry.outputHeight}`,
        );
        onApplied(next, describePhotoEdit(edit));
      } catch (error) {
        onLog("error", `edit failed → ${String(error)}`);
      } finally {
        setBusy(false);
      }
    };
    image.onerror = () => {
      onLog("error", "edit failed → the captured frame could not be decoded");
      setBusy(false);
    };
    image.src = dataUrl;
  }, [dataUrl, edit, onApplied, onCancel, onLog]);

  const boxStyle = {
    left: `${crop.x * 100}%`,
    top: `${crop.y * 100}%`,
    width: `${crop.width * 100}%`,
    height: `${crop.height * 100}%`,
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-black text-white">
      <div className="flex h-12 items-center justify-between px-3">
        <button
          onClick={onCancel}
          disabled={busy}
          className="pv-press flex h-10 cursor-pointer items-center gap-1 rounded-lg px-2 text-xs font-semibold disabled:opacity-40"
          aria-label="Cancel editing"
        >
          <X size={14} /> Cancel
        </button>
        <div className="text-center">
          <p className="text-[11px] font-semibold">Edit photo</p>
          <p className="text-[9px] text-white/60">{describePhotoEdit(edit)}</p>
        </div>
        <button
          onClick={apply}
          disabled={busy || identity}
          className="pv-press flex h-10 cursor-pointer items-center gap-1 rounded-lg px-2 text-xs font-semibold disabled:opacity-40"
          aria-label="Apply edits to this photo"
        >
          <Check size={14} /> Apply
        </button>
      </div>

      <div className="relative flex-1 overflow-hidden">
        <svg aria-hidden className="absolute h-0 w-0">
          <filter id="pv-edit-matrix" colorInterpolationFilters="sRGB">
            <feColorMatrix type="matrix" values={matrixValues} />
          </filter>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center p-3">
          <div
            ref={stageRef}
            className="relative"
            style={{
              aspectRatio: `${Math.max(rotated.width, 1)} / ${Math.max(rotated.height, 1)}`,
              maxWidth: "100%",
              maxHeight: "100%",
              height: rotated.width >= rotated.height ? "auto" : "100%",
              width: rotated.width >= rotated.height ? "100%" : "auto",
            }}
            onPointerMove={onPointerMove}
            onPointerUp={endDrag}
            onPointerCancel={endDrag}
          >
            <img
              src={dataUrl}
              alt="Photo being edited"
              onLoad={(event) =>
                setSize({
                  width: event.currentTarget.naturalWidth,
                  height: event.currentTarget.naturalHeight,
                })
              }
              className="absolute inset-0 h-full w-full object-contain"
              style={{
                filter: "url(#pv-edit-matrix)",
                transform: `rotate(${rotationDegrees(rotation)}deg) scale(${
                  rotation % 2 === 1 && rotated.height > 0
                    ? Math.min(rotated.width / rotated.height, rotated.height / rotated.width)
                    : 1
                })`,
              }}
            />
            {tool === "crop" && (
              <>
                <div className="pointer-events-none absolute inset-0 bg-black/45" />
                <div
                  onPointerDown={onPointerDown("move")}
                  className="absolute cursor-move border border-white/80"
                  style={boxStyle}
                  role="slider"
                  aria-label="Crop area"
                  aria-valuetext={`${Math.round(crop.width * 100)} by ${Math.round(crop.height * 100)} percent`}
                  aria-valuenow={Math.round(crop.width * 100)}
                >
                  <img
                    src={dataUrl}
                    alt=""
                    aria-hidden
                    className="pointer-events-none absolute h-auto w-auto max-w-none"
                    style={{
                      filter: "url(#pv-edit-matrix)",
                      width: `${100 / crop.width}%`,
                      height: `${100 / crop.height}%`,
                      left: `${(-crop.x / crop.width) * 100}%`,
                      top: `${(-crop.y / crop.height) * 100}%`,
                      objectFit: "contain",
                      transform: `rotate(${rotationDegrees(rotation)}deg)`,
                    }}
                  />
                </div>
                {(["topLeft", "topRight", "bottomLeft", "bottomRight"] as const).map((handle) => {
                  const isLeft = handle === "topLeft" || handle === "bottomLeft";
                  const isTop = handle === "topLeft" || handle === "topRight";
                  return (
                    <div
                      key={handle}
                      onPointerDown={onPointerDown(handle)}
                      role="slider"
                      aria-label={`Resize crop from the ${isTop ? "top" : "bottom"} ${
                        isLeft ? "left" : "right"
                      } corner`}
                      aria-valuenow={Math.round(crop.width * 100)}
                      className="absolute h-8 w-8 cursor-pointer"
                      style={{
                        left: `calc(${(isLeft ? crop.x : crop.x + crop.width) * 100}% - 16px)`,
                        top: `calc(${(isTop ? crop.y : crop.y + crop.height) * 100}% - 16px)`,
                      }}
                    >
                      <span className="absolute left-1/2 top-1/2 block h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-sm border-2 border-white bg-white/20" />
                    </div>
                  );
                })}
              </>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-2 px-3 pb-2 pt-2">
        {tool === "crop" && (
          <div className="flex flex-wrap items-center gap-1.5">
            {CROP_ASPECT_IDS.map((id) => (
              <button
                key={id}
                onClick={() => {
                  setAspect(id);
                  setCrop(cropRectForAspect(id, rotated.width, rotated.height));
                }}
                className={`min-h-8 cursor-pointer rounded-full px-3 text-[10px] font-semibold ${
                  aspect === id ? "bg-white text-black" : "bg-white/15 text-white"
                }`}
              >
                {cropAspectLabel(id)}
              </button>
            ))}
            <button
              onClick={() => {
                setAspect("free");
                setCrop(FULL_FRAME_CROP);
              }}
              disabled={cropIsFullFrame(crop)}
              className="ml-auto min-h-8 cursor-pointer px-2 text-[10px] font-semibold underline disabled:opacity-40"
            >
              Reset
            </button>
          </div>
        )}

        {tool === "rotate" && (
          <div className="flex items-center justify-between gap-2">
            <button
              onClick={() => {
                setRotation((current) => rotateQuarterTurns(current, -1));
                setCrop((current) => rotateCropRect(current, -1));
              }}
              className="min-h-9 cursor-pointer rounded-lg bg-white/15 px-3 text-[10px] font-semibold"
            >
              90° left
            </button>
            <span className="text-[10px] text-white/70">{rotationLabel(rotation)}</span>
            <button
              onClick={() => {
                setRotation((current) => rotateQuarterTurns(current, 1));
                setCrop((current) => rotateCropRect(current, 1));
              }}
              className="min-h-9 cursor-pointer rounded-lg bg-white/15 px-3 text-[10px] font-semibold"
            >
              90° right
            </button>
          </div>
        )}

        {tool === "enhance" && (
          <div className="space-y-1">
            <div className="flex gap-1.5">
              <button
                onClick={() => setEnhance(ENHANCE_NEUTRAL)}
                className={`min-h-8 cursor-pointer rounded-full px-3 text-[10px] font-semibold ${
                  enhance === ENHANCE_NEUTRAL ? "bg-white text-black" : "bg-white/15 text-white"
                }`}
              >
                Original
              </button>
              <button
                onClick={() => setEnhance(AUTO_ENHANCE)}
                className="min-h-8 cursor-pointer rounded-full bg-white/15 px-3 text-[10px] font-semibold"
              >
                Enhanced
              </button>
            </div>
            {PHOTO_ADJUST_KEYS.map((key: PhotoAdjustKey) => (
              <label key={key} className="flex items-center gap-2 text-[9px] text-white/70">
                <span className="w-16">{adjustLabel(key)}</span>
                <input
                  type="range"
                  min={PHOTO_EDIT_ADJUST_MIN}
                  max={PHOTO_EDIT_ADJUST_MAX}
                  step={PHOTO_EDIT_ADJUST_STEP}
                  value={enhance[key]}
                  onChange={(event) =>
                    setEnhance((current) => ({
                      ...current,
                      [key]: clampAdjustValue(Number(event.target.value)),
                    }))
                  }
                  className="flex-1 cursor-pointer"
                  aria-label={`${adjustLabel(key)} adjustment`}
                />
                <span className="w-8 text-right text-white">{adjustBadge(enhance[key])}</span>
              </label>
            ))}
          </div>
        )}

        <div className="flex justify-around border-t border-white/10 pt-1">
          {(
            [
              { id: "crop", icon: Crop, label: "Crop" },
              { id: "rotate", icon: RotateCw, label: "Rotate" },
              { id: "enhance", icon: Sparkles, label: "Enhance" },
            ] as const
          ).map((entry) => (
            <button
              key={entry.id}
              onClick={() => setTool(entry.id)}
              className={`flex min-h-10 cursor-pointer flex-col items-center gap-0.5 px-3 text-[9px] font-semibold ${
                tool === entry.id ? "text-white" : "text-white/50"
              }`}
              aria-pressed={tool === entry.id}
            >
              <entry.icon size={14} />
              {entry.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
