/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Category-tinted pose card art, matching mobile PoseCardArt exactly.
 * The bundled catalog ships no photography (imageUrl/thumbnailUrl/
 * localAssetPath are all null), so both the app and this mirror render the
 * same branded generative artwork: category hue gradient + category glyph.
 * It never claims to be a photo of the named pose and needs no network.
 */
import {
  Accessibility,
  Baby,
  Building2,
  Camera,
  Compass,
  Dumbbell,
  Gem,
  Heart,
  Images,
  Mountain,
  Palette,
  Shirt,
  User,
  Users,
  type LucideIcon,
} from "lucide-react";
import { POSE_CATEGORIES, type Pose, type PoseCategoryId } from "../../../../shared/index";

export const CATEGORY_ICON: Record<PoseCategoryId, LucideIcon> = {
  portraits: User,
  couples: Heart,
  family: Users,
  wedding: Gem,
  fashion: Shirt,
  street: Building2,
  fitness: Dumbbell,
  dance: Accessibility,
  travel: Mountain,
  kids: Baby,
  group: Users,
  creative: Palette,
};

export const NAV_ICON: Record<"home" | "explore" | "camera" | "gallery" | "profile", LucideIcon> = {
  home: Compass,
  explore: Compass,
  camera: Camera,
  gallery: Images,
  profile: User,
};

export function categoryHue(category: PoseCategoryId): number {
  return POSE_CATEGORIES.find((c) => c.id === category)?.hue ?? 217;
}

export function artGradient(pose: Pose, isDark: boolean): string {
  const hue = categoryHue(pose.category);
  const hue2 = (hue + 34) % 360;
  const [l1, l2] = isDark ? [16, 28] : [56, 74];
  const [s1, s2] = isDark ? [52, 46] : [78, 66];
  return `linear-gradient(145deg, hsl(${hue} ${s1}% ${l1}%) 0%, hsl(${hue2} ${s2}% ${l2}%) 100%)`;
}

export function artGlow(pose: Pose, isDark: boolean): string {
  const hue = categoryHue(pose.category);
  return isDark
    ? `radial-gradient(120% 90% at 18% 0%, hsl(${hue} 60% 34% / 0.55) 0%, transparent 60%)`
    : `radial-gradient(120% 90% at 18% 0%, hsl(${hue} 95% 88% / 0.9) 0%, transparent 62%)`;
}

interface PoseArtProps {
  pose: Pose;
  isDark: boolean;
  iconSize?: number;
  className?: string;
  rounded?: string;
  children?: React.ReactNode;
}

export function PoseArt({
  pose,
  isDark,
  iconSize = 44,
  className = "",
  rounded = "rounded-xl",
  children,
}: PoseArtProps) {
  const Icon = CATEGORY_ICON[pose.category];
  const hue = categoryHue(pose.category);
  return (
    <div
      className={`relative overflow-hidden ${rounded} ${className}`}
      style={{ background: artGradient(pose, isDark) }}
    >
      <div className="absolute inset-0" style={{ background: artGlow(pose, isDark) }} />
      <div
        className="absolute -right-6 -top-8 h-24 w-24 rounded-full border"
        style={{ borderColor: `hsl(${hue} 85% 92% / ${isDark ? 0.14 : 0.5})` }}
      />
      <div
        className="absolute -right-2 top-2 h-12 w-12 rounded-full border"
        style={{ borderColor: `hsl(${hue} 85% 92% / ${isDark ? 0.1 : 0.4})` }}
      />
      <Icon
        size={iconSize}
        strokeWidth={1.1}
        className="absolute bottom-2 right-2"
        style={{ color: isDark ? "rgba(255,255,255,0.22)" : "rgba(255,255,255,0.75)" }}
      />
      {children}
    </div>
  );
}

export const DIFFICULTY_META: Record<
  Pose["difficulty"],
  { label: string; dot: string }
> = {
  beginner: { label: "Beginner", dot: "#10B981" },
  intermediate: { label: "Intermediate", dot: "#F59E0B" },
  advanced: { label: "Advanced", dot: "#EF4444" },
};
