/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Browser-only mirror of mobile/'s state. Metro never bundles this folder
 * (Metro watches mobile/ + shared/ only in the real repository).
 *
 * Unit 08 additions: explore query + category/difficulty filters, search
 * history LRU(10) persisted like the Expo MMKV store, focused pose detail.
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  darkColors,
  lightColors,
  LIMITS,
  LOG_TAG,
  DEFAULT_CAMERA_SETTINGS,
  getCatalogReport,
  normalizeQuery,
  type CameraSettings,
  type Difficulty,
  type PoseCategoryId,
  type TabKey,
  type ThemeMode,
} from "../../../../shared/index";

function poseLibraryBootLog(): string {
  const report = getCatalogReport();
  return `catalog ready — ${report.total} poses · ${
    Object.keys(report.perCategory).length
  } categories · src=bundle`;
}

export type LogLevel = "debug" | "info" | "warn" | "error";
export interface LogLine {
  id: number;
  time: string;
  level: LogLevel;
  tag: string;
  message: string;
}

export type PreviewRoute =
  | "splash"
  | "welcome"
  | "onboarding"
  | "permissions"
  | "auth"
  | "tabs";

export type PreviewPermissionState = "idle" | "requesting" | "granted";

export interface PreviewAuthUser {
  readonly email: string;
  readonly displayName: string;
  readonly provider: "email" | "google";
}
export type PreviewAuthStatus = "unauthenticated" | "authenticated";

/** Sign-up outcomes the mirror can honestly simulate against a demo backend. */
export type PreviewAuthOutcome =
  | "success"
  | "confirmation-required"
  | "invalid"
  | "network-error";

/** Preview-only scenario switches — clearly labeled in the mirror UI. */
export interface PreviewAuthScenario {
  readonly confirmRequired: boolean;
  readonly offline: boolean;
}

export type ExploreCategoryFilter = PoseCategoryId | "all" | "favorites";
export type ExploreDifficultyFilter = Difficulty | "all";

export interface PreviewGalleryPhoto {
  readonly id: string;
  readonly dataUrl: string;
  readonly poseId: string;
  readonly filterUsed: string;
  readonly timestamp: number;
}

interface PreviewState {
  activeTab: TabKey;
  setActiveTab: (tab: TabKey) => void;
  previewRoute: PreviewRoute;
  navigatePreview: (route: PreviewRoute) => void;
  replayIntro: () => void;
  onboardingIndex: number;
  setOnboardingIndex: (index: number) => void;
  cameraPermission: PreviewPermissionState;
  photosPermission: PreviewPermissionState;
  requestPreviewPermission: (kind: "camera" | "photos") => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  scheme: "light" | "dark";
  isDark: boolean;
  colors: typeof lightColors;
  logs: LogLine[];
  pushLog: (level: LogLevel, tag: string, message: string) => void;
  // Unit 06 — auth mirror
  authStatus: PreviewAuthStatus;
  authUser: PreviewAuthUser | null;
  authReturnTab: TabKey | null;
  setAuthReturnTab: (tab: TabKey | null) => void;
  demoSignIn: (email: string, displayName: string, provider?: "email" | "google") => boolean;
  updateDisplayName: (displayName: string) => boolean;
  demoSignOut: () => void;
  // Create-Account repair — sign-up mirror with honest simulated outcomes
  authScenario: PreviewAuthScenario;
  setAuthScenario: (patch: Partial<PreviewAuthScenario>) => void;
  demoSignUp: (email: string, displayName: string) => PreviewAuthOutcome;
  resendPreviewConfirmation: (email: string) => boolean;
  // Unit 07 — recents LRU(4)
  previewRecents: readonly string[];
  viewPreviewPose: (poseId: string) => void;
  clearRecents: () => void;
  // Unit 08 — explore mirror
  exploreQuery: string;
  setExploreQuery: (query: string) => void;
  exploreCategory: ExploreCategoryFilter;
  setExploreCategory: (category: ExploreCategoryFilter) => void;
  exploreDifficulty: ExploreDifficultyFilter;
  setExploreDifficulty: (difficulty: ExploreDifficultyFilter) => void;
  resetExploreFilters: () => void;
  searchHistory: readonly string[];
  commitSearch: (query: string) => void;
  clearSearchHistory: () => void;
  applyHistoryQuery: (query: string) => void;
  focusedPoseId: string | null;
  openPose: (poseId: string) => void;
  closePose: () => void;
  // Unit 11 — favorites mirror
  favorites: readonly string[];
  toggleFavorite: (poseId: string) => boolean;
  isFavorite: (poseId: string) => boolean;
  // Unit 12 — camera mirror: armed pose == the real app's ?poseId= param.
  cameraPoseId: string | null;
  armCameraPose: (poseId: string | null) => void;
  // Unit 13 — session-only mirror of MMKV gallery metadata + local image.
  previewGallery: readonly PreviewGalleryPhoto[];
  savePreviewPhoto: (photo: Omit<PreviewGalleryPhoto, "id" | "timestamp">) => string;
  deletePreviewPhoto: (id: string) => void;
  // Unit 20 — camera & capture settings
  cameraSettings: CameraSettings;
  updateCameraSettings: (partial: Partial<CameraSettings>) => void;
  resetCameraSettings: () => void;
  settingsOpen: boolean;
  setSettingsOpen: (open: boolean) => void;
}

const PreviewContext = createContext<PreviewState | null>(null);

function timestamp(): string {
  const d = new Date();
  const pad = (n: number, len = 2) => String(n).padStart(len, "0");
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(
    d.getMilliseconds(),
    3,
  )}`;
}

const THEME_STORAGE_KEY = "spa-preview:themeMode";
const AUTH_STORAGE_KEY = "spa-preview:demoSession";
const SEARCH_HISTORY_KEY = "spa-preview:searchHistory";
const FAVORITES_STORAGE_KEY = "spa-preview:favorites";
const SETTINGS_STORAGE_KEY = "spa-preview:settings";

export function PreviewProvider({ children }: { children: ReactNode }) {
  const [activeTab, setActiveTabState] = useState<TabKey>("home");
  const [previewRoute, setPreviewRoute] = useState<PreviewRoute>("splash");
  const [onboardingIndex, setOnboardingIndexState] = useState(0);
  const [cameraPermission, setCameraPermission] =
    useState<PreviewPermissionState>("idle");
  const [photosPermission, setPhotosPermission] =
    useState<PreviewPermissionState>("idle");
  const [themeMode, setThemeModeState] = useState<ThemeMode>("system");
  const [systemDark, setSystemDark] = useState(false);
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [authUser, setAuthUser] = useState<PreviewAuthUser | null>(null);
  const [authReturnTab, setAuthReturnTabState] = useState<TabKey | null>(null);
  const [authScenario, setAuthScenarioState] = useState<PreviewAuthScenario>({
    confirmRequired: false,
    offline: false,
  });
  const [previewRecents, setPreviewRecents] = useState<readonly string[]>([]);
  // Unit 08 — explore mirror state
  const [exploreQuery, setExploreQueryState] = useState("");
  const [exploreCategory, setExploreCategoryState] =
    useState<ExploreCategoryFilter>("all");
  const [exploreDifficulty, setExploreDifficultyState] =
    useState<ExploreDifficultyFilter>("all");
  const [searchHistory, setSearchHistory] = useState<readonly string[]>([]);
  const [focusedPoseId, setFocusedPoseId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<readonly string[]>([]);
  const [cameraPoseId, setCameraPoseId] = useState<string | null>(null);
  const [previewGallery, setPreviewGallery] = useState<readonly PreviewGalleryPhoto[]>([]);
  const [cameraSettings, setCameraSettings] = useState<CameraSettings>(DEFAULT_CAMERA_SETTINGS);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const logId = useRef(0);

  const pushLog = useCallback((level: LogLevel, tag: string, message: string) => {
    logId.current += 1;
    setLogs((prev) => [
      ...prev.slice(-49),
      { id: logId.current, time: timestamp(), level, tag, message },
    ]);
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    setSystemDark(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(THEME_STORAGE_KEY);
      if (saved === "light" || saved === "dark" || saved === "system") {
        setThemeModeState(saved);
        pushLog("info", "Theme", `rehydrated persisted mode → ${saved}`);
      }
    } catch {
      /* storage unavailable — session-only theme */
    }
    pushLog("info", "Boot", "Smart Photography Assistant — root layout mounted");
    pushLog("debug", "Boot", "storage ready (MMKV adapter · in-memory in Expo Go)");
    pushLog("debug", "Boot", "fonts ready (Inter 400/600/700) — hiding native splash");
    pushLog("info", "Startup", "initialization started");
    pushLog("info", "PoseLibrary", poseLibraryBootLog());
    pushLog(
      "warn",
      "Supabase",
      "credentials not configured — demo backend active (auth/profiles/favorites are local-only)",
    );
    let restoredAuthenticatedSession = false;
    try {
      const persisted = window.localStorage.getItem(AUTH_STORAGE_KEY);
      if (persisted !== null) {
        const user = JSON.parse(persisted) as PreviewAuthUser;
        restoredAuthenticatedSession = true;
        setAuthUser(user);
        pushLog("info", "Auth", `session restored → ${user.email}`);
        pushLog("info", "FavoritesSync", "demo mode — local replica ready");
      } else {
        pushLog("debug", "Auth", "no persisted session");
      }
    } catch {
      pushLog("error", "Auth", "session restore failed — continuing signed out");
    }
    try {
      const history = window.localStorage.getItem(SEARCH_HISTORY_KEY);
      if (history !== null) {
        const parsed = JSON.parse(history) as string[];
        setSearchHistory(parsed.slice(0, LIMITS.searchHistory));
        if (parsed.length > 0)
          pushLog("debug", "Explore", `search history rehydrated (${parsed.length} entries)`);
      }
    } catch {
      /* session-only history */
    }
    try {
      const savedFavs = window.localStorage.getItem(FAVORITES_STORAGE_KEY);
      if (savedFavs !== null && restoredAuthenticatedSession) {
        const parsed = JSON.parse(savedFavs) as string[];
        setFavorites(parsed);
        if (parsed.length > 0)
          pushLog("info", "Favorites", `rehydrated ${parsed.length} local favorites`);
      } else if (!restoredAuthenticatedSession) {
        window.localStorage.removeItem(FAVORITES_STORAGE_KEY);
      }
    } catch {
      /* session-only favorites */
    }
    try {
      const savedSettings = window.localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (savedSettings !== null) {
        const parsed = JSON.parse(savedSettings) as CameraSettings;
        setCameraSettings({ ...DEFAULT_CAMERA_SETTINGS, ...parsed });
        pushLog("info", "Settings", "camera & capture settings rehydrated");
      }
    } catch {
      /* session-only settings */
    }
    const timer = window.setTimeout(() => {
      setPreviewRoute("welcome");
      pushLog("info", "Startup", "initialization complete → /welcome");
    }, 900);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const scheme: "light" | "dark" =
    themeMode === "system" ? (systemDark ? "dark" : "light") : themeMode;
  const isDark = scheme === "dark";
  const colors = isDark ? darkColors : lightColors;

  const setThemeMode = useCallback(
    (mode: ThemeMode) => {
      setThemeModeState(mode);
      try {
        window.localStorage.setItem(THEME_STORAGE_KEY, mode);
      } catch {
        /* session-only */
      }
      pushLog("info", "Theme", `mode → ${mode}`);
    },
    [pushLog],
  );

  const setActiveTab = useCallback(
    (tab: TabKey) => {
      setActiveTabState((prev) => {
        if (prev !== tab) pushLog("info", "Nav", `tab → ${tab}`);
        return tab;
      });
    },
    [pushLog],
  );

  const navigatePreview = useCallback(
    (route: PreviewRoute) => {
      setPreviewRoute(route);
      pushLog("info", "Nav", `route → /${route === "tabs" ? "home" : route}`);
    },
    [pushLog],
  );

  const setOnboardingIndex = useCallback(
    (index: number) => {
      const safeIndex = Math.max(0, Math.min(2, index));
      setOnboardingIndexState(safeIndex);
      pushLog("debug", "Onboarding", `slide → ${safeIndex + 1}/3`);
    },
    [pushLog],
  );

  const replayIntro = useCallback(() => {
    setOnboardingIndexState(0);
    setCameraPermission("idle");
    setPhotosPermission("idle");
    setPreviewRoute("splash");
    pushLog("info", "Startup", "first-run preview replayed");
    pushLog("info", "PoseLibrary", poseLibraryBootLog());
    window.setTimeout(() => {
      setPreviewRoute("welcome");
      pushLog("info", "Startup", "initialization complete → /welcome");
    }, 900);
  }, [pushLog]);

  const requestPreviewPermission = useCallback(
    (kind: "camera" | "photos") => {
      const setter = kind === "camera" ? setCameraPermission : setPhotosPermission;
      setter("requesting");
      pushLog("info", "Permissions", `requesting ${kind}`);
      window.setTimeout(() => {
        setter("granted");
        pushLog("info", "Permissions", `${kind} → granted`);
      }, 650);
    },
    [pushLog],
  );

  const demoSignIn = useCallback(
    (email: string, displayName: string, provider: "email" | "google" = "email"): boolean => {
      const normalized = email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) return false;
      const name =
        displayName.trim().length >= 2
          ? displayName.trim()
          : (normalized.split("@")[0] ?? "Demo User");
      const user: PreviewAuthUser = { email: normalized, displayName: name, provider };
      setAuthUser(user);
      try {
        window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
      } catch {
        /* session-only */
      }
      pushLog(
        "info",
        "Auth",
        provider === "google" ? "demo Google sign-in" : `demo sign-in → ${normalized}`,
      );
      pushLog("info", "Auth", `auth event → signed in (${normalized})`);
      pushLog("info", "FavoritesSync", "demo mode — favorites stay local to this signed-in account");
      const target = authReturnTab ?? "home";
      setAuthReturnTabState(null);
      setActiveTabState(target);
      setPreviewRoute("tabs");
      pushLog("info", "Nav", `route → /${target}`);
      return true;
    },
    [pushLog, authReturnTab],
  );

  const setAuthScenario = useCallback((patch: Partial<PreviewAuthScenario>) => {
    setAuthScenarioState((current) => ({ ...current, ...patch }));
  }, []);

  /**
   * Sign-up mirrors the real product against the demo backend. Default demo
   * behaviour = create + immediate session (same as production demo mode).
   * The scenario switches honestly simulate backend behaviours the demo
   * backend itself does not have: email-confirmation-required (account
   * created, NO session) and a network failure.
   */
  const demoSignUp = useCallback(
    (email: string, displayName: string): PreviewAuthOutcome => {
      const normalized = email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) return "invalid";
      if (authScenario.offline) {
        pushLog("warn", "Auth", "sign-up failed — simulated offline (preview scenario)");
        return "network-error";
      }
      if (authScenario.confirmRequired) {
        pushLog(
          "info",
          "Auth",
          `account created (simulated) → ${normalized} — email confirmation required, no session yet`,
        );
        pushLog("info", "Nav", "staying on /auth — no session to enter the app with");
        return "confirmation-required";
      }
      return demoSignIn(normalized, displayName, "email") ? "success" : "invalid";
    },
    [authScenario, demoSignIn, pushLog],
  );

  const resendPreviewConfirmation = useCallback(
    (email: string): boolean => {
      if (authScenario.offline) {
        pushLog("warn", "Auth", "resend failed — simulated offline (preview scenario)");
        return false;
      }
      pushLog("info", "Auth", `confirmation email re-sent (simulated) → ${email}`);
      return true;
    },
    [authScenario, pushLog],
  );

  const updateDisplayName = useCallback(
    (displayName: string): boolean => {
      const trimmed = displayName.trim();
      if (trimmed.length === 0 || !authUser) return false;
      const updated: PreviewAuthUser = { ...authUser, displayName: trimmed };
      setAuthUser(updated);
      try {
        window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(updated));
      } catch {
        /* session-only */
      }
      pushLog("info", "Profile", `display name updated → ${trimmed}`);
      return true;
    },
    [authUser, pushLog],
  );

  const demoSignOut = useCallback(() => {
    setAuthUser(null);
    setFavorites([]);
    setPreviewGallery([]);
    try {
      window.localStorage.removeItem(AUTH_STORAGE_KEY);
      window.localStorage.removeItem(FAVORITES_STORAGE_KEY);
    } catch {
      /* session-only */
    }
    pushLog("info", "Auth", "demo sign-out");
    pushLog("info", "Auth", "auth event → signed out");
    pushLog("debug", "FavoritesLocal", "local favorites replica cleared (cloud truth intact)");
    pushLog("debug", "GalleryLocal", "preview session gallery cleared on sign-out");
  }, [pushLog]);

  const setAuthReturnTab = useCallback((tab: TabKey | null) => {
    setAuthReturnTabState(tab);
  }, []);

  const viewPreviewPose = useCallback(
    (poseId: string) => {
      setPreviewRecents((prev) => {
        const next = [poseId, ...prev.filter((id) => id !== poseId)].slice(
          0,
          LIMITS.poseHistory,
        );
        pushLog("info", "PoseLocal", `recent + ${poseId} (${next.length}/${LIMITS.poseHistory} kept)`);
        return next;
      });
    },
    [pushLog],
  );

  const clearRecents = useCallback(() => {
    setPreviewRecents([]);
    pushLog("info", "PoseLocal", "recent poses history cleared");
  }, [pushLog]);

  /* ── Unit 08: explore actions ─────────────────────────────────────────── */

  const setExploreQuery = useCallback((query: string) => {
    setExploreQueryState(query);
  }, []);

  const setExploreCategory = useCallback(
    (category: ExploreCategoryFilter) => {
      if (category === "favorites" && authUser === null) {
        setAuthReturnTabState("explore");
        setPreviewRoute("auth");
        pushLog("warn", "Favorites", "guest access blocked → /auth");
        return;
      }
      setExploreCategoryState((prev) => {
        if (prev !== category)
          pushLog("info", "Explore", `category filter → ${category}`);
        return category;
      });
    },
    [authUser, pushLog],
  );

  const setExploreDifficulty = useCallback(
    (difficulty: ExploreDifficultyFilter) => {
      setExploreDifficultyState((prev) => {
        if (prev !== difficulty)
          pushLog("info", "Explore", `difficulty filter → ${difficulty}`);
        return difficulty;
      });
    },
    [pushLog],
  );

  const resetExploreFilters = useCallback(() => {
    setExploreQueryState("");
    setExploreCategoryState("all");
    setExploreDifficultyState("all");
    pushLog("info", "Explore", "filters cleared → showing full catalog");
  }, [pushLog]);

  const commitSearch = useCallback(
    (rawQuery: string) => {
      const query = normalizeQuery(rawQuery);
      if (query.length < 2) return;
      setSearchHistory((prev) => {
        const next = [query, ...prev.filter((h) => h !== query)].slice(
          0,
          LIMITS.searchHistory,
        );
        try {
          window.localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(next));
        } catch {
          /* session-only */
        }
        pushLog("info", "Explore", `search committed “${query}” → history LRU ${next.length}/${LIMITS.searchHistory}`);
        return next;
      });
    },
    [pushLog],
  );

  const clearSearchHistory = useCallback(() => {
    setSearchHistory([]);
    try {
      window.localStorage.removeItem(SEARCH_HISTORY_KEY);
    } catch {
      /* session-only */
    }
    pushLog("info", "Explore", "search history cleared");
  }, [pushLog]);

  const applyHistoryQuery = useCallback(
    (query: string) => {
      setExploreQueryState(query);
      pushLog("debug", "Explore", `history chip applied → “${query}”`);
    },
    [pushLog],
  );

  const openPose = useCallback(
    (poseId: string) => {
      setFocusedPoseId(poseId);
      viewPreviewPose(poseId);
      pushLog("info", "Explore", `pose detail open → ${poseId}`);
    },
    [pushLog, viewPreviewPose],
  );

  const closePose = useCallback(() => {
    setFocusedPoseId(null);
    pushLog("debug", "Explore", "pose detail dismissed");
  }, [pushLog]);

  /* ── Unit 11: favorites actions ────────────────────────────────────────── */

  const toggleFavorite = useCallback(
    (poseId: string): boolean => {
      if (authUser === null) {
        setAuthReturnTabState("explore");
        setPreviewRoute("auth");
        pushLog("warn", "Favorites", "guest write blocked → /auth");
        return false;
      }
      let added = false;
      setFavorites((prev) => {
        const exists = prev.includes(poseId);
        added = !exists;
        const next = exists ? prev.filter((id) => id !== poseId) : [...prev, poseId];
        try {
          window.localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* session-only */
        }
        pushLog(
          "info",
          "Favorites",
          `${added ? "+ add" : "- remove"} ${poseId} (${next.length} total)`,
        );
        return next;
      });
      return added;
    },
    [authUser, pushLog],
  );

  const isFavorite = useCallback(
    (poseId: string): boolean => {
      return authUser !== null && favorites.includes(poseId);
    },
    [authUser, favorites],
  );

  /* ── Unit 12: camera mirror ────────────────────────────────────────────── */

  const armCameraPose = useCallback(
    (poseId: string | null) => {
      setCameraPoseId(poseId);
      pushLog(
        "info",
        "Camera",
        poseId === null
          ? "pose cleared → State 1 (Choose a Pose)"
          : `State 2 armed with poseId=${poseId}`,
      );
    },
    [pushLog],
  );

  /* ── Unit 13: device-only gallery mirror ─────────────────────────────── */

  const savePreviewPhoto = useCallback(
    (photo: Omit<PreviewGalleryPhoto, "id" | "timestamp">): string => {
      const id = `preview-photo-${Date.now().toString(36)}`;
      setPreviewGallery((current) => [
        { ...photo, id, timestamp: Date.now() },
        ...current,
      ]);
      pushLog("info", "GalleryLocal", `metadata saved → ${id} (session-only mirror)`);
      return id;
    },
    [pushLog],
  );

  const deletePreviewPhoto = useCallback(
    (id: string) => {
      setPreviewGallery((current) => current.filter((photo) => photo.id !== id));
      pushLog("info", "GalleryLocal", `photo deleted → ${id}`);
    },
    [pushLog],
  );

  const updateCameraSettings = useCallback(
    (partial: Partial<CameraSettings>) => {
      setCameraSettings((prev) => {
        const next = { ...prev, ...partial };
        try {
          window.localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* session-only */
        }
        pushLog("info", "Settings", `updated → ${Object.keys(partial).join(", ")}`);
        return next;
      });
    },
    [pushLog],
  );

  const resetCameraSettings = useCallback(() => {
    setCameraSettings(DEFAULT_CAMERA_SETTINGS);
    try {
      window.localStorage.removeItem(SETTINGS_STORAGE_KEY);
    } catch {
      /* session-only */
    }
    pushLog("info", "Settings", "reset camera & capture preferences to defaults");
  }, [pushLog]);

  const authStatus: PreviewAuthStatus =
    authUser === null ? "unauthenticated" : "authenticated";

  const value = useMemo<PreviewState>(
    () => ({
      activeTab,
      setActiveTab,
      previewRoute,
      navigatePreview,
      replayIntro,
      onboardingIndex,
      setOnboardingIndex,
      cameraPermission,
      photosPermission,
      requestPreviewPermission,
      themeMode,
      setThemeMode,
      scheme,
      isDark,
      colors,
      logs,
      pushLog,
      authStatus,
      authUser,
      authReturnTab,
      setAuthReturnTab,
      demoSignIn,
      updateDisplayName,
      demoSignOut,
      authScenario,
      setAuthScenario,
      demoSignUp,
      resendPreviewConfirmation,
      previewRecents,
      viewPreviewPose,
      clearRecents,
      exploreQuery,
      setExploreQuery,
      exploreCategory,
      setExploreCategory,
      exploreDifficulty,
      setExploreDifficulty,
      resetExploreFilters,
      searchHistory,
      commitSearch,
      clearSearchHistory,
      applyHistoryQuery,
      focusedPoseId,
      openPose,
      closePose,
      favorites,
      toggleFavorite,
      isFavorite,
      cameraPoseId,
      armCameraPose,
      previewGallery,
      savePreviewPhoto,
      deletePreviewPhoto,
      cameraSettings,
      updateCameraSettings,
      resetCameraSettings,
      settingsOpen,
      setSettingsOpen,
    }),
    [
      activeTab, setActiveTab, previewRoute, navigatePreview, replayIntro,
      onboardingIndex, setOnboardingIndex, cameraPermission, photosPermission,
      requestPreviewPermission, themeMode, setThemeMode, scheme, isDark, colors,
      logs, pushLog, authStatus, authUser, authReturnTab, setAuthReturnTab,
      demoSignIn, updateDisplayName, demoSignOut,
      authScenario, setAuthScenario, demoSignUp, resendPreviewConfirmation,
      previewRecents, viewPreviewPose, clearRecents,
      exploreQuery, setExploreQuery, exploreCategory, setExploreCategory,
      exploreDifficulty, setExploreDifficulty, resetExploreFilters,
      searchHistory, commitSearch, clearSearchHistory, applyHistoryQuery,
      focusedPoseId, openPose, closePose,
      favorites, toggleFavorite, isFavorite,
      cameraPoseId, armCameraPose,
      previewGallery, savePreviewPhoto, deletePreviewPhoto,
      cameraSettings, updateCameraSettings, resetCameraSettings,
      settingsOpen, setSettingsOpen,
    ],
  );

  return <PreviewContext.Provider value={value}>{children}</PreviewContext.Provider>;
}

export function usePreview(): PreviewState {
  const ctx = useContext(PreviewContext);
  if (!ctx)
    throw new Error(`[${LOG_TAG}] usePreview must be used within PreviewProvider`);
  return ctx;
}
