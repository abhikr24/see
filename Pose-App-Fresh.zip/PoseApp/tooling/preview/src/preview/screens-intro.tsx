/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Mirrors of Units 03/04/06 screens (Splash → Welcome → Onboarding →
 * Permissions → Auth). Rendered with the same shared/ tokens the Expo app
 * uses; copy comes from shared/content/onboarding.ts.
 */
import { useState } from "react";
import {
  Accessibility,
  ArrowRight,
  Camera,
  Check,
  ChevronLeft,
  Compass,
  Eye,
  EyeOff,
  Image as ImageIcon,
  Loader2,
  Lock,
  Mail,
  MailCheck,
  User,
  UserCheck,
} from "lucide-react";
import {
  APP_SHORT_NAME,
  AUTH_COPY,
  NO_FORM_ERRORS,
  ONBOARDING_SLIDES,
  WELCOME_COPY,
  confirmPasswordError,
  displayNameError,
  emailError,
  normalizeEmail,
  passwordError,
  typeScale,
  validateAuthForm,
  type AuthFormErrors,
} from "../../../../shared/index";
import { usePreview } from "./preview-state";

const SLIDE_ICON = [Compass, Accessibility, Camera] as const;

export function SplashMirror() {
  const { colors } = usePreview();
  return (
    <div
      className="flex h-full flex-col items-center justify-center"
      style={{ backgroundColor: colors.background, backgroundImage: "var(--pv-grad-splash)" }}
    >
      <div
        className="flex h-20 w-20 items-center justify-center rounded-[22px] shadow-lg"
        style={{ backgroundColor: colors.primary, boxShadow: `0 12px 32px -8px ${colors.primary}66` }}
      >
        <Camera size={36} color="#fff" strokeWidth={2.2} />
      </div>
      <p
        className="mt-5 font-bold"
        style={{ color: colors.textPrimary, fontSize: typeScale.title.fontSize }}
      >
        {APP_SHORT_NAME}
      </p>
      <p className="mt-1 text-xs" style={{ color: colors.textSecondary }}>
        Smart Photography Assistant
      </p>
      <Loader2 size={18} className="absolute bottom-14 animate-spin" style={{ color: colors.primary }} />
    </div>
  );
}

export function WelcomeMirror() {
  const colors = usePreview().colors;
  const { navigatePreview, pushLog } = usePreview();
  return (
    <div
      className="flex h-full flex-col px-6 pb-8 pt-14"
      style={{ backgroundColor: colors.background }}
    >
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <div
          className="relative flex h-32 w-32 items-center justify-center rounded-full"
          style={{ backgroundColor: colors.primaryLight }}
        >
          <div
            className="flex h-20 w-20 items-center justify-center rounded-[24px]"
            style={{ backgroundColor: colors.primary }}
          >
            <Camera size={40} color="#fff" strokeWidth={1.8} />
          </div>
          <div className="absolute -right-1 -top-1 h-8 w-8 rounded-full border-4" style={{ borderColor: colors.background, backgroundColor: colors.success }} />
        </div>
        <h1
          className="mt-10 max-w-[18rem] font-bold leading-tight tracking-tight"
          style={{ color: colors.textPrimary, fontSize: typeScale.display.fontSize, lineHeight: 1.2 }}
        >
          {WELCOME_COPY.title}
        </h1>
        <p className="mt-3 max-w-[16rem] text-sm leading-relaxed" style={{ color: colors.textSecondary }}>
          {WELCOME_COPY.subtitle}
        </p>
      </div>
      <button
        onClick={() => navigatePreview("onboarding")}
        className="pv-press pv-btn-grad pv-elev-2 w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold text-white"
        style={{ backgroundColor: colors.primary }}
      >
        {WELCOME_COPY.primaryCta}
      </button>
      <button
        onClick={() => {
          pushLog("info", "Nav", "welcome → /auth");
          navigatePreview("auth");
        }}
        className="pv-press pv-btn-secondary mt-3 w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold"
        style={{ color: colors.primary, backgroundColor: colors.primaryLight }}
      >
        {WELCOME_COPY.secondaryCta}
      </button>
    </div>
  );
}

export function OnboardingMirror() {
  const { colors, onboardingIndex, setOnboardingIndex, navigatePreview } = usePreview();
  const slide = ONBOARDING_SLIDES[onboardingIndex];
  const Icon = SLIDE_ICON[onboardingIndex];
  const last = onboardingIndex === ONBOARDING_SLIDES.length - 1;
  const finish = () => navigatePreview("permissions");
  return (
    <div className="flex h-full flex-col px-6 pb-8 pt-5" style={{ backgroundColor: colors.background }}>
      <div className="flex h-10 items-center justify-end">
        {!last && (
          <button
            onClick={finish}
            className="cursor-pointer text-sm font-semibold"
            style={{ color: colors.textSecondary }}
          >
            Skip
          </button>
        )}
      </div>
      <div className="flex flex-1 flex-col items-center justify-center text-center">
        <div
          className="flex h-40 w-40 items-center justify-center rounded-full transition-all duration-300"
          style={{ backgroundColor: colors.primaryLight }}
        >
          <Icon size={64} strokeWidth={1.4} style={{ color: colors.primary }} />
        </div>
        <h2 className="mt-8 font-semibold" style={{ color: colors.textPrimary, fontSize: typeScale.heading.fontSize }}>
          {slide.title}
        </h2>
        <p className="mt-3 max-w-[17rem] text-sm leading-relaxed" style={{ color: colors.textSecondary }}>
          {slide.description}
        </p>
      </div>
      <div className="mb-6 flex items-center justify-center gap-1.5">
        {ONBOARDING_SLIDES.map((s, i) => (
          <div
            key={s.key}
            className="h-1.5 rounded-full transition-all duration-300"
            style={{
              width: i === onboardingIndex ? 24 : 8,
              backgroundColor: i === onboardingIndex ? colors.primary : colors.divider,
            }}
          />
        ))}
      </div>
      <button
        onClick={() => (last ? finish() : setOnboardingIndex(onboardingIndex + 1))}
        className="pv-press pv-btn-fill w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold text-white"
        style={{ backgroundColor: colors.primary }}
      >
        {last ? "Continue" : "Next"}
      </button>
    </div>
  );
}

export function PermissionsMirror() {
  const { colors, cameraPermission, photosPermission, requestPreviewPermission, navigatePreview } = usePreview();
  const cards = [
    {
      kind: "camera" as const,
      icon: Camera,
      title: "Camera Access",
      desc: "For live preview, AI pose detection and real-time guidance",
      state: cameraPermission,
    },
    {
      kind: "photos" as const,
      icon: ImageIcon,
      title: "Gallery Access",
      desc: "To save your perfect shots and show them in the app gallery",
      state: photosPermission,
    },
  ];
  return (
    <div className="flex h-full flex-col px-6 pb-8 pt-12" style={{ backgroundColor: colors.background }}>
      <h2 className="font-semibold" style={{ color: colors.textPrimary, fontSize: typeScale.heading.fontSize }}>
        Permissions Needed
      </h2>
      <p className="mt-2 text-sm" style={{ color: colors.textSecondary }}>
        Two quick asks. Nothing is ever uploaded — photos stay on your device.
      </p>
      <div className="mt-6 flex flex-col gap-4">
        {cards.map(({ kind, icon: Icon, title, desc, state }) => (
          <div
            key={kind}
            className="rounded-2xl border p-4"
            style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
          >
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: colors.primaryLight }}>
                <Icon size={22} style={{ color: colors.primary }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold" style={{ color: colors.textPrimary }}>{title}</p>
                  {state === "granted" && (
                    <span className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold text-white" style={{ backgroundColor: colors.success }}>
                      <Check size={10} /> Granted
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs leading-relaxed" style={{ color: colors.textSecondary }}>{desc}</p>
              </div>
            </div>
            {state !== "granted" && (
              <button
                onClick={() => requestPreviewPermission(kind)}
                className="pv-press pv-btn-fill mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg py-2.5 text-xs font-semibold text-white"
                style={{ backgroundColor: colors.primary }}
              >
                {state === "requesting" && <Loader2 size={13} className="animate-spin" />}
                Allow {kind === "camera" ? "Camera" : "Gallery"}
              </button>
            )}
          </div>
        ))}
      </div>
      <div className="flex-1" />
      <button
        disabled={cameraPermission !== "granted"}
        onClick={() => navigatePreview("tabs")}
        className="pv-press pv-btn-fill w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold text-white disabled:opacity-40"
        style={{ backgroundColor: colors.primary }}
      >
        Continue
      </button>
    </div>
  );
}

/**
 * AuthMirror — 1:1 mirror of the repaired Unit-06 /auth screen. Every state
 * the real screen can render exists here: sign-in form, create-account form
 * with inline validation, loading, the email-confirmation state (honestly
 * simulated through clearly-labeled preview scenarios), duplicate / network
 * errors, and the "already signed in" state that REPLACED the old silent
 * auto-exit (see shared/auth/authFlow.ts — the mirror consumes the same
 * validators and copy, never its own variants).
 */
export function AuthMirror() {
  const {
    colors,
    authUser,
    demoSignIn,
    demoSignUp,
    demoSignOut,
    resendPreviewConfirmation,
    authScenario,
    setAuthScenario,
    navigatePreview,
    setActiveTab,
    authReturnTab,
    pushLog,
  } = usePreview();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [mode, setMode] = useState<"sign-in" | "sign-up">("sign-in");
  const [pending, setPending] = useState<"email" | "google" | "resend" | null>(null);
  const [errors, setErrors] = useState<AuthFormErrors>(NO_FORM_ERRORS);
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState<{ email: string; from: "sign-in" | "sign-up" } | null>(null);
  const [resentAck, setResentAck] = useState(false);

  const leaveToTabs = () => {
    const target = authReturnTab ?? "home";
    if (authReturnTab !== null) pushLog("info", "Nav", `route → /${target}`);
    navigatePreview("tabs");
    setActiveTab(target);
  };

  const switchMode = (next: "sign-in" | "sign-up") => {
    setMode(next);
    setErrors(NO_FORM_ERRORS);
    setConfirm("");
    setFormError(null);
    setResentAck(false);
    pushLog("debug", "Auth", next === "sign-up" ? "mode → create account" : "mode → sign in");
  };

  const editField = (field: keyof AuthFormErrors, value: string) => {
    if (field === "displayName") setName(value);
    else if (field === "email") setEmail(value);
    else if (field === "password") setPassword(value);
    else setConfirm(value);
    setFormError(null);
    setErrors((current) => {
      if (current[field] === null) return current;
      let nextError: string | null = null;
      if (field === "displayName") nextError = displayNameError(value);
      else if (field === "email") nextError = emailError(value);
      else if (field === "password") nextError = passwordError(value);
      else nextError = confirmPasswordError(password, value);
      const confirmNext =
        field === "confirmPassword"
          ? nextError
          : mode === "sign-up" && field === "password" && confirm.length > 0 && current.confirmPassword !== null
            ? confirmPasswordError(value, confirm)
            : current.confirmPassword;
      return { ...current, [field]: nextError, confirmPassword: confirmNext };
    });
  };

  const submitEmail = () => {
    if (pending !== null) return;
    const { errors: nextErrors, submittable } = validateAuthForm(mode, {
      displayName: name,
      email,
      password,
      confirmPassword: confirm,
    });
    setErrors(nextErrors);
    if (!submittable) {
      pushLog("warn", "Auth", "validation failed — fix the highlighted fields");
      return;
    }
    setPending("email");
    window.setTimeout(() => {
      setPending(null);
      if (mode === "sign-in") {
        if (authScenario.offline) {
          setFormError("Check your connection and try again.");
          pushLog("warn", "Auth", "sign-in failed — simulated offline (preview scenario)");
          return;
        }
        const ok = demoSignIn(email, name, "email");
        if (!ok) setFormError("Enter a valid email address.");
        return;
      }
      const outcome = demoSignUp(email, name);
      if (outcome === "success") return; // demoSignIn navigated to the app
      if (outcome === "confirmation-required") {
        setConfirmation({ email: normalizeEmail(email), from: "sign-up" });
        setPassword("");
        setConfirm("");
        return;
      }
      if (outcome === "network-error") {
        setFormError("Check your connection and try again.");
        return;
      }
      setFormError("Enter a valid email address.");
    }, 550);
  };

  const submitGoogle = () => {
    if (pending !== null) return;
    setPending("google");
    window.setTimeout(() => {
      setPending(null);
      demoSignIn("demo.user@gmail.com", "Demo User", "google");
    }, 450);
  };

  const resend = () => {
    if (pending !== null || confirmation === null) return;
    setPending("resend");
    setResentAck(false);
    window.setTimeout(() => {
      setPending(null);
      const ok = resendPreviewConfirmation(confirmation.email);
      setResentAck(ok);
      if (!ok) setFormError("Check your connection and try again.");
    }, 450);
  };

  const inputShell = (hasError: boolean) =>
    `flex items-center gap-2.5 rounded-xl border px-3.5 transition ${hasError ? "" : ""}`;

  const renderField = (
    field: keyof AuthFormErrors,
    icon: React.ReactNode,
    label: string,
    placeholder: string,
    value: string,
    type: string,
    options?: { hint?: string; trailing?: React.ReactNode; autoComplete?: string },
  ) => {
    const error = errors[field];
    return (
      <div>
        <p className="mb-1.5 text-xs font-medium" style={{ color: colors.textSecondary }}>
          {label}
        </p>
        <label
          className={inputShell(error !== null)}
          style={{
            borderColor: error !== null ? colors.error : colors.divider,
            backgroundColor: colors.surface,
          }}
        >
          {icon}
          <input
            value={value}
            onChange={(e) => editField(field, e.target.value)}
            placeholder={placeholder}
            type={type}
            aria-label={label}
            autoComplete={options?.autoComplete}
            className="w-full bg-transparent py-3 text-sm outline-none"
            style={{ color: colors.textPrimary }}
          />
          {options?.trailing}
        </label>
        {error !== null ? (
          <p className="mt-1.5 text-xs font-medium" style={{ color: colors.error }}>{error}</p>
        ) : options?.hint ? (
          <p className="mt-1.5 text-xs" style={{ color: colors.textDisabled }}>{options.hint}</p>
        ) : null}
      </div>
    );
  };

  const eyeToggle = (visible: boolean, toggle: () => void, label: string) => (
    <button
      onClick={toggle}
      aria-label={visible ? `Hide ${label}` : `Show ${label}`}
      className="-mr-1 cursor-pointer p-1.5"
      style={{ color: colors.textSecondary }}
    >
      {visible ? <EyeOff size={16} /> : <Eye size={16} />}
    </button>
  );

  // ── State 1 · already signed in (REPLACES the old silent auto-exit) ─────
  if (authUser !== null) {
    return (
      <div className="flex h-full flex-col px-6 pb-8 pt-5" style={{ backgroundColor: colors.background }}>
        <button
          onClick={() => navigatePreview("tabs")}
          className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-full"
          style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}
          aria-label="Close"
        >
          <ChevronLeft size={18} />
        </button>
        <div className="mt-14 flex h-12 w-12 items-center justify-center rounded-2xl" style={{ backgroundColor: colors.primaryLight }}>
          <UserCheck size={22} style={{ color: colors.primary }} />
        </div>
        <h2 className="mt-4 font-semibold" style={{ color: colors.textPrimary, fontSize: typeScale.heading.fontSize }}>
          {AUTH_COPY.alreadySignedInTitle}
        </h2>
        <p className="mt-2 text-sm leading-relaxed" style={{ color: colors.textSecondary }}>
          {AUTH_COPY.alreadySignedInBody}
        </p>
        <div className="mt-4 flex items-center gap-2 self-start rounded-full px-3.5 py-2" style={{ backgroundColor: colors.backgroundSecondary }}>
          <User size={14} style={{ color: colors.textSecondary }} />
          <span className="text-sm" style={{ color: colors.textPrimary }}>
            {authUser.displayName} · {authUser.email}
          </span>
        </div>
        <button
          onClick={leaveToTabs}
          className="pv-press pv-btn-fill mt-8 w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold text-white"
          style={{ backgroundColor: colors.primary }}
        >
          {AUTH_COPY.alreadySignedInContinue}
        </button>
        <button
          onClick={() => {
            navigatePreview("tabs");
            setActiveTab("profile");
          }}
          className="pv-press pv-btn-ghost mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border py-3.5 text-sm font-semibold"
          style={{ borderColor: colors.divider, color: colors.textPrimary, backgroundColor: colors.surface }}
        >
          <ArrowRight size={15} /> {AUTH_COPY.alreadySignedInProfile}
        </button>
        <button
          onClick={() => {
            demoSignOut();
            switchMode("sign-in");
            pushLog("info", "Auth", "demo session cleared — fresh auth test from /auth");
          }}
          className="mx-auto mt-4 cursor-pointer py-3 text-xs font-medium"
          style={{ color: colors.textSecondary }}
        >
          {AUTH_COPY.demoSwitchAccount}
        </button>
      </div>
    );
  }

  // ── State 2 · email confirmation required (account created, NO session) ─
  if (confirmation !== null) {
    return (
      <div className="flex h-full flex-col px-6 pb-8 pt-5" style={{ backgroundColor: colors.background }}>
        <button
          onClick={() => navigatePreview("tabs")}
          className="flex h-9 w-9 cursor-pointer items-center justify-center rounded-full"
          style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}
          aria-label="Close"
        >
          <ChevronLeft size={18} />
        </button>
        <div className="mt-14 flex h-12 w-12 items-center justify-center rounded-2xl" style={{ backgroundColor: colors.primaryLight }}>
          <MailCheck size={22} style={{ color: colors.primary }} />
        </div>
        <h2 className="mt-4 font-semibold" style={{ color: colors.textPrimary, fontSize: typeScale.heading.fontSize }}>
          {AUTH_COPY.confirmationTitle}
        </h2>
        <p className="mt-2 text-sm leading-relaxed" style={{ color: colors.textSecondary }}>
          {confirmation.from === "sign-up" ? AUTH_COPY.confirmationBody : AUTH_COPY.confirmationBodySignIn}
        </p>
        <div className="mt-4 flex items-center gap-2 self-start rounded-full px-3.5 py-2" style={{ backgroundColor: colors.backgroundSecondary }}>
          <Mail size={14} style={{ color: colors.textSecondary }} />
          <span className="text-sm" style={{ color: colors.textPrimary }}>{confirmation.email}</span>
        </div>
        {resentAck && (
          <p className="mt-3 flex items-center gap-1.5 text-xs font-medium" style={{ color: colors.success }}>
            <Check size={12} /> {AUTH_COPY.confirmationResent}
          </p>
        )}
        {formError !== null && (
          <p className="mt-3 text-xs font-medium" style={{ color: colors.error }}>{formError}</p>
        )}
        <button
          onClick={() => {
            setConfirmation(null);
            switchMode("sign-in");
          }}
          className="pv-press pv-btn-fill mt-8 w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold text-white"
          style={{ backgroundColor: colors.primary }}
        >
          {AUTH_COPY.confirmationBackToSignIn}
        </button>
        <button
          onClick={resend}
          disabled={pending !== null}
          className="pv-press pv-btn-ghost mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border py-3.5 text-sm font-semibold disabled:opacity-50"
          style={{ borderColor: colors.divider, color: colors.textPrimary, backgroundColor: colors.surface }}
        >
          {pending === "resend" && <Loader2 size={14} className="animate-spin" />}
          {AUTH_COPY.confirmationResend}
        </button>
      </div>
    );
  }

  // ── State 3 · form (sign-in / create-account) ───────────────────────────
  return (
    <div className="flex h-full flex-col overflow-y-auto px-6 pb-8 pt-5" style={{ backgroundColor: colors.background }}>
      <button
        onClick={() => navigatePreview("tabs")}
        className="flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-full"
        style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}
        aria-label="Close"
      >
        <ChevronLeft size={18} />
      </button>
      <div className="mt-5 flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl" style={{ backgroundColor: colors.primaryLight }}>
        <Lock size={22} style={{ color: colors.primary }} />
      </div>
      <h2 className="mt-4 font-semibold" style={{ color: colors.textPrimary, fontSize: typeScale.heading.fontSize }}>
        {mode === "sign-in" ? AUTH_COPY.signInTitle : AUTH_COPY.signUpTitle}
      </h2>
      <p className="mt-2 text-sm leading-relaxed" style={{ color: colors.textSecondary }}>
        {authReturnTab
          ? `The ${authReturnTab} tab needs an account — browsing the pose library stays free.`
          : mode === "sign-in"
            ? AUTH_COPY.signInSubtitle
            : AUTH_COPY.signUpSubtitle}
      </p>

      <div className="mt-6 flex rounded-xl p-1" style={{ backgroundColor: colors.backgroundSecondary }} role="tablist">
        {(["sign-in", "sign-up"] as const).map((option) => (
          <button
            key={option}
            role="tab"
            aria-selected={mode === option}
            onClick={() => switchMode(option)}
            className="flex-1 cursor-pointer rounded-lg border py-2.5 text-sm font-semibold transition-all"
            style={{
              borderColor: mode === option ? colors.divider : "transparent",
              backgroundColor: mode === option ? colors.surface : "transparent",
              color: mode === option ? colors.primary : colors.textSecondary,
            }}
          >
            {option === "sign-in" ? AUTH_COPY.modeSignIn : AUTH_COPY.modeSignUp}
          </button>
        ))}
      </div>

      <div className="mt-5 flex flex-col gap-4">
        {mode === "sign-up" &&
          renderField(
            "displayName",
            <User size={16} style={{ color: colors.textDisabled }} />,
            AUTH_COPY.nameLabel,
            AUTH_COPY.namePlaceholder,
            name,
            "text",
            { autoComplete: "name" },
          )}
        {renderField(
          "email",
          <Mail size={16} style={{ color: colors.textDisabled }} />,
          AUTH_COPY.emailLabel,
          AUTH_COPY.emailPlaceholder,
          email,
          "email",
          { autoComplete: "email" },
        )}
        {renderField(
          "password",
          <Lock size={16} style={{ color: colors.textDisabled }} />,
          AUTH_COPY.passwordLabel,
          AUTH_COPY.passwordPlaceholder,
          password,
          showPassword ? "text" : "password",
          {
            hint: mode === "sign-up" ? AUTH_COPY.passwordHint : undefined,
            trailing: eyeToggle(showPassword, () => setShowPassword((v) => !v), "password"),
            autoComplete: mode === "sign-in" ? "current-password" : "new-password",
          },
        )}
        {mode === "sign-up" &&
          renderField(
            "confirmPassword",
            <Lock size={16} style={{ color: colors.textDisabled }} />,
            AUTH_COPY.confirmLabel,
            AUTH_COPY.confirmPlaceholder,
            confirm,
            showConfirm ? "text" : "password",
            {
              trailing: eyeToggle(showConfirm, () => setShowConfirm((v) => !v), "password confirmation"),
              autoComplete: "new-password",
            },
          )}
      </div>

      {formError !== null && (
        <p className="mt-4 text-xs font-medium" style={{ color: colors.error }}>{formError}</p>
      )}

      <button
        onClick={submitEmail}
        disabled={pending !== null}
        className="pv-press pv-btn-fill mt-6 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-semibold text-white disabled:opacity-60"
        style={{ backgroundColor: colors.primary }}
      >
        {pending === "email" && <Loader2 size={15} className="animate-spin" />}
        {mode === "sign-in" ? AUTH_COPY.submitSignIn : AUTH_COPY.submitSignUp}
      </button>
      {mode === "sign-up" && (
        <p className="mt-2 text-center text-xs" style={{ color: colors.textSecondary }}>
          {AUTH_COPY.whatHappensNext}
        </p>
      )}
      <button
        onClick={submitGoogle}
        disabled={pending !== null}
        className="pv-press pv-btn-ghost mt-3 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border py-3.5 text-sm font-semibold disabled:opacity-60"
        style={{ borderColor: colors.divider, color: colors.textPrimary, backgroundColor: colors.surface }}
      >
        {pending === "google" && <Loader2 size={14} className="animate-spin" />}
        {AUTH_COPY.googleCta}
      </button>

      <div className="mt-6 rounded-xl border border-dashed p-3" style={{ borderColor: colors.divider }}>
        <p className="text-[10px] font-bold uppercase tracking-wide" style={{ color: colors.textDisabled }}>
          Preview scenarios (demo only)
        </p>
        {(
          [
            ["confirmRequired", "Email confirmation required"],
            ["offline", "Backend offline"],
          ] as const
        ).map(([key, label]) => (
          <label key={key} className="mt-2 flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={authScenario[key]}
              onChange={(e) => setAuthScenario({ [key]: e.target.checked })}
              className="h-3.5 w-3.5 cursor-pointer accent-blue-600"
            />
            <span className="text-xs" style={{ color: colors.textSecondary }}>{label}</span>
          </label>
        ))}
      </div>

      <p className="mt-auto pt-4 text-center text-[10px] leading-relaxed" style={{ color: colors.textDisabled }}>
        {AUTH_COPY.demoNote}
      </p>
    </div>
  );
}
