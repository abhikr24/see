/**
 * ⚠ PREVIEW MIRROR — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Mirrors of the tab shell (Unit 02), Home dashboard (Unit 07), Profile
 * (theme switcher Unit 01 + auth Unit 06) and the Unit 09+ placeholders.
 */
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Bell,
  Camera,
  Check,
  CheckCircle2,
  ChevronRight,
  Compass,
  Database,
  Grid,
  Hand,
  Heart,
  History,
  Home,
  Images,
  Images as GalleryIcon,
  Lock,
  LogOut,
  Moon,
  Pencil,
  Repeat2,
  RotateCcw,
  Settings,
  Sparkles,
  Sun,
  SunDim,
  SunMoon,
  Flashlight,
  FlashlightOff,
  Target,
  Timer,
  Trash2,
  User,
  Search,
  Volume1,
  Volume2,
  VolumeX,
  Zap,
  ZapOff,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  LIMITS,
  IntelligentCaptureController,
  MATCH_COLOR_BANDS,
  POSE_LANDMARKS,
  TABS,
  matchFromDecision,
  detectHandPresentation,
  selectCaptureHand,
  OpenPalmGate,
  type OpenPalmEvidence,
  type OpenPalmPhase,
  fitSilhouetteToViewport,
  getCatalogReport,
  getPoseById,
  getPoseCatalog,
  matchColorFor,
  outlineSilhouette,
  poseReferenceAdapter,
  buildReferenceTemplate,
  analysisInputFromTemplate,
  createPoseAnalysisEngine,
  createCoachingSpeechPlanner,
  cameraStatusCopyFor,
  brightnessGain,
  clampBrightness,
  isBrightnessDefault,
  CAMERA_FILTER_IDS,
  FILTER_INTENSITY_DEFAULT,
  FILTER_INTENSITY_MAX,
  FILTER_INTENSITY_MIN,
  FILTER_INTENSITY_STEP,
  applyColorMatrix,
  captureColorMatrix,
  clampFilterIntensity,
  filterIntensityBadge,
  filterPreviewMatrixValues,
  filterStrength,
  filterSupportsIntensity,
  filterSwatchGradient,
  colorMatrixIsIdentity,
  resolveLighting,
  INSTRUCTION_LANGUAGE_OPTIONS,
  resolveInstructionLanguage,
  decisionToCoachingState,
  decisionToGuidance,
  resolveCameraPresentation,
  visibleCoachingFor,
  primaryLocaleFor,
  prosodyForIntensity,
  routeCoachingSpeech,
  selectCoachingPhrase,
  ReferenceStatuses,
  projectPose,
  resolvePoseSilhouette,
  SILHOUETTE_CONTOUR_DASH_PX,
  SILHOUETTE_CONTOUR_GLOW_SIGMA,
  SILHOUETTE_CONTOUR_GLOW_STROKE_PX,
  SILHOUETTE_CONTOUR_PULSE_PERIOD_MS,
  SILHOUETTE_CONTOUR_PULSE_RATIO,
  SILHOUETTE_CONTOUR_STROKE_PX,
  silhouetteContourStyle,
  type AutoThreshold,
  type CountdownDuration,
  type FilterDefault,
  type FlashDefault,
  type TimerDefault,
  type CoachingState,
  type GuidanceResult,
  type CaptureTrigger,
  type Pose,
  type PoseLandmark,
  type TabKey,
  type ThemeMode,
} from "../../../../shared/index";
import { CATEGORY_ICON, PoseArt } from "./pose-art";
import { ExploreMirror } from "./explore-mirror";
import { PreviewHandRunner, PreviewPoseRunner } from "./ml-runner";
import { PhotoEditorMirror } from "./photo-editor-mirror";
import { usePreview, type PreviewGalleryPhoto } from "./preview-state";

const TAB_ICONS: Record<TabKey, typeof Home> = {
  home: Home,
  explore: Compass,
  camera: Camera,
  gallery: Images,
  profile: User,
};

function greetingForNow(): string {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 12) return "Good morning";
  if (hour >= 12 && hour < 18) return "Good afternoon";
  if (hour >= 18 && hour < 22) return "Good evening";
  return "Good night";
}

/* ── Home (Unit 07) ─────────────────────────────────────────────────────── */

function RecentPoseThumb({ pose }: { pose: Pose }) {
  const { colors, isDark, viewPreviewPose, armCameraPose, setActiveTab, pushLog } = usePreview();
  return (
    <button
      onClick={() => {
        viewPreviewPose(pose.id);
        armCameraPose(pose.id);
        pushLog("info", "Home", `quick reuse recent pose → camera State 2 (poseId=${pose.id})`);
        setActiveTab("camera");
      }}
      className="w-24 shrink-0 cursor-pointer overflow-hidden rounded-xl text-left pv-press"
    >
      <PoseArt pose={pose} isDark={isDark} className="h-28" rounded="rounded-xl" iconSize={28} />
      <p className="mt-1 line-clamp-1 text-[10px] font-semibold" style={{ color: colors.textPrimary }}>
        {pose.title}
      </p>
    </button>
  );
}

function HomeMirror() {
  const {
    colors, authUser, previewRecents, setActiveTab, pushLog, viewPreviewPose,
    armCameraPose,
  } = usePreview();
  const report = getCatalogReport();
  const recents = previewRecents
    .slice(0, LIMITS.recentPoses)
    .map((id) => getPoseById(id))
    .filter((p): p is Pose => p !== null);
  const lastPose = recents[0] ?? null;
  const firstName = (authUser?.displayName ?? "Guest").split(/\s+/)[0] ?? "Guest";
  const heroPose = getPoseCatalog().find((p) => p.isFeatured) ?? getPoseCatalog()[0];
  const HeroIcon = CATEGORY_ICON[heroPose.category];

  return (
    <div className="h-full overflow-y-auto pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden" style={{ backgroundColor: colors.background }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 pt-3">
        <div>
          <p className="text-sm font-semibold" style={{ color: colors.textPrimary }}>
            {greetingForNow()}, {firstName}
          </p>
          <p className="text-[10px]" style={{ color: colors.textSecondary }}>
            Ready for perfect shots?
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => pushLog("info", "Notifications", "bell tapped — V1 never requests notification permission")}
            className="pv-press flex h-9 w-9 cursor-pointer items-center justify-center rounded-full"
            style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}
            aria-label="Notifications"
          >
            <Bell size={16} />
          </button>
          <button
            onClick={() => setActiveTab("profile")}
            className="pv-press flex h-9 w-9 cursor-pointer items-center justify-center rounded-full"
            style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
            aria-label="Profile"
          >
            <User size={16} />
          </button>
        </div>
      </div>

      {/* Hero card */}
      <button
        onClick={() => {
          pushLog("info", "Home", "hero → start camera (gate applies for guests)");
          setActiveTab("camera");
        }}
        className="mx-4 mt-4 block w-[calc(100%-2rem)] cursor-pointer overflow-hidden rounded-2xl p-4 text-left text-white pv-press-card pv-elev-2"
        style={{ backgroundColor: colors.primary, backgroundImage: "var(--pv-grad-brand)" }}
      >
        <div className="flex items-center justify-between">
          <div>
            <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-white/70">
              <HeroIcon size={11} /> Start capturing perfect poses
            </p>
            <p className="mt-1.5 text-lg font-bold leading-tight">AI guidance for every shot</p>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15">
            <Camera size={22} />
          </div>
        </div>
        <div className="mt-3 flex items-center gap-1.5 text-xs font-semibold">
          Start Camera <ArrowRight size={13} />
        </div>
      </button>
      {lastPose !== null && (
        <button
          onClick={() => {
            viewPreviewPose(lastPose.id);
            pushLog("info", "Home", `continue last pose → camera State 2 (poseId=${lastPose.id})`);
            armCameraPose(lastPose.id);
            setActiveTab("camera");
          }}
          className="mx-4 mt-2 flex w-[calc(100%-2rem)] cursor-pointer items-center justify-between rounded-xl border px-3.5 py-2.5 text-left pv-press-card"
          style={{ backgroundColor: colors.surface, borderColor: colors.divider }}
        >
          <span className="text-xs" style={{ color: colors.textSecondary }}>
            Continue last pose
          </span>
          <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: colors.primary }}>
            {lastPose.title} <ArrowRight size={12} />
          </span>
        </button>
      )}

      {/* Recents shelf */}
      <div className="mt-5 flex items-baseline justify-between px-4">
        <p className="text-sm font-semibold" style={{ color: colors.textPrimary }}>
          Recent poses
        </p>
        {recents.length > 0 && (
          <button
            onClick={() => setActiveTab("explore")}
            className="cursor-pointer text-[10px] font-semibold"
            style={{ color: colors.primary }}
          >
            See All
          </button>
        )}
      </div>
      {recents.length > 0 ? (
        <div className="mt-2.5 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {recents.map((pose) => (
            <RecentPoseThumb key={pose.id} pose={pose} />
          ))}
        </div>
      ) : (
        <div
          className="mx-4 mt-2.5 rounded-xl border border-dashed p-4"
          style={{ borderColor: colors.divider, backgroundColor: colors.backgroundSecondary }}
        >
          <p className="text-xs font-semibold" style={{ color: colors.textPrimary }}>
            Discover {report.total}+ poses
          </p>
          <p className="mt-1 text-[10px] leading-relaxed" style={{ color: colors.textSecondary }}>
            Browse curated collections — poses you open are pinned here (LRU {LIMITS.recentPoses}).
          </p>
          <button
            onClick={() => setActiveTab("explore")}
            className="mt-2.5 flex cursor-pointer items-center gap-1 text-[11px] font-semibold"
            style={{ color: colors.primary }}
          >
            Explore Poses <ArrowRight size={12} />
          </button>
        </div>
      )}

      {/* Quick nav */}
      <div className="mt-4 flex gap-2 px-4">
        {(
          [
            { key: "explore" as TabKey, icon: Compass, title: "Explore", caption: `${report.total} poses · Unit 08` },
            { key: "gallery" as TabKey, icon: GalleryIcon, title: "Gallery", caption: "Your shots · Unit 14" },
          ] as const
        ).map((item) => (
          <button
            key={item.key}
            onClick={() => setActiveTab(item.key)}
            className="flex flex-1 cursor-pointer items-center gap-2.5 rounded-xl border px-3.5 py-3 text-left pv-press"
            style={{ backgroundColor: colors.surface, borderColor: colors.divider }}
          >
            <item.icon size={18} style={{ color: colors.primary }} />
            <span>
              <span className="block text-xs font-semibold" style={{ color: colors.textPrimary }}>{item.title}</span>
              <span className="block text-[9px]" style={{ color: colors.textSecondary }}>{item.caption}</span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Auth gate (invariant: camera/gallery/profile need auth) ────────────── */

function GateCard({ tab }: { tab: "camera" | "gallery" | "profile" }) {
  const { colors, setAuthReturnTab, navigatePreview } = usePreview();
  return (
    <div className="flex h-full flex-col items-center justify-center px-8 text-center" style={{ backgroundColor: colors.background }}>
      <div className="flex h-20 w-20 items-center justify-center rounded-full" style={{ backgroundColor: colors.primaryLight }}>
        <Lock size={32} style={{ color: colors.primary }} />
      </div>
      <p className="mt-5 text-base font-semibold" style={{ color: colors.textPrimary }}>
        Sign in for {tab === "camera" ? "Camera" : tab === "gallery" ? "Gallery" : "Profile"}
      </p>
      <p className="mt-2 text-xs leading-relaxed" style={{ color: colors.textSecondary }}>
        Browsing the pose library is always free. Sign in to unlock{" "}
        {tab === "camera"
          ? "live guidance and capture"
          : tab === "gallery"
            ? "your captured shots"
            : "favorites, statistics and personal settings"}.
      </p>
      <button
        onClick={() => {
          setAuthReturnTab(tab);
          navigatePreview("auth");
        }}
        className="pv-press pv-btn-fill mt-6 w-full cursor-pointer rounded-xl py-3.5 text-sm font-semibold text-white"
        style={{ backgroundColor: colors.primary }}
      >
        Sign In to Continue
      </button>
    </div>
  );
}

/* ── Unit 12 — Camera mirror ─────────────────────────────────────────────
 * ⚠ This is the PREVIEW MIRROR. It uses the browser's getUserMedia webcam so
 * the lifecycle is genuinely observable here: it really asks permission, it
 * really shows a live feed, and it really releases the device when you leave
 * the tab. The REAL app never uses getUserMedia — mobile/ uses expo-camera's
 * <CameraView> with the identical state machine (State 1 → permission →
 * State 2 → release on blur/background). Web APIs below are legal ONLY
 * because this file is never bundled into the app.
 */

type MirrorCameraStatus =
  | "idle"
  | "requesting"
  | "live"
  | "denied"
  | "blocked"
  | "unavailable";

function drawCanvasArrow(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  direction: string,
  color: string,
) {
  if (direction === 'none') return;
  const len = 20;
  const head = 7;
  let p1x = cx, p1y = cy + len, p2x = cx, p2y = cy - len;
  let h1x = cx - head, h1y = cy - len + head, h2x = cx + head, h2y = cy - len + head;

  if (direction === 'down') {
    p1x = cx; p1y = cy - len; p2x = cx; p2y = cy + len;
    h1x = cx - head; h1y = cy + len - head; h2x = cx + head; h2y = cy + len - head;
  } else if (direction === 'left') {
    p1x = cx + len; p1y = cy; p2x = cx - len; p2y = cy;
    h1x = cx - len + head; h1y = cy - head; h2x = cx - len + head; h2y = cy + head;
  } else if (direction === 'right') {
    p1x = cx - len; p1y = cy; p2x = cx + len; p2y = cy;
    h1x = cx + len - head; h1y = cy - head; h2x = cx + len - head; h2y = cy + head;
  }

  // Shadow outline
  ctx.save();
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.globalAlpha = 0.9;
  ctx.beginPath();
  ctx.moveTo(p1x, p1y);
  ctx.lineTo(p2x, p2y);
  ctx.moveTo(h1x, h1y);
  ctx.lineTo(p2x, p2y);
  ctx.lineTo(h2x, h2y);
  ctx.stroke();

  // Colored arrow
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.globalAlpha = 1.0;
  ctx.beginPath();
  ctx.moveTo(p1x, p1y);
  ctx.lineTo(p2x, p2y);
  ctx.moveTo(h1x, h1y);
  ctx.lineTo(p2x, p2y);
  ctx.lineTo(h2x, h2y);
  ctx.stroke();
  ctx.restore();
}

function CameraMirror() {
  const {
    colors,
    cameraPoseId,
    armCameraPose,
    previewRecents,
    viewPreviewPose,
    setActiveTab,
    pushLog,
    savePreviewPhoto,
    deletePreviewPhoto,
    cameraSettings,
    updateCameraSettings,
    setSettingsOpen,
  } = usePreview();
  // Unit 20: session-local controls seed from persisted settings each time a
  // pose is armed, exactly like the app's useFocusEffect does on focus.
  const [flash, setFlash] = useState<"off" | "auto" | "on">(cameraSettings.flashDefault);
  const [timer, setTimer] = useState<number>(cameraSettings.timerDefault);
  const [facing, setFacing] = useState<"rear" | "front">("front");
  const [filter, setFilter] = useState(cameraSettings.filterDefault);
  /* LOOKS mirror — strength, and the strength track's open state, exactly as
     the device session store holds them. */
  const [filterIntensity, setFilterIntensity] = useState(FILTER_INTENSITY_DEFAULT);
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  /* CAMERA CONTROLS mirror — the same two session controls the device screen
     owns: the continuous light (hardware, honestly unsimulated here) and the
     brightness detent (fully real in this mirror: it drives the live video
     AND the captured frame through the SAME shared gain the device pipeline
     feeds to its Skia color matrix). */
  const [torchRequested, setTorchRequested] = useState(false);
  const [brightness, setBrightness] = useState(0);
  const [brightnessOpen, setBrightnessOpen] = useState(false);

  useEffect(() => {
    setFlash(cameraSettings.flashDefault);
    setTimer(cameraSettings.timerDefault);
    setFilter(cameraSettings.filterDefault);
    setFilterIntensity(FILTER_INTENSITY_DEFAULT);
    setFilterPanelOpen(false);
    /* Transient, exactly like `resetTransientCameraState` on device. */
    setTorchRequested(false);
    setBrightness(0);
    setBrightnessOpen(false);
  }, [cameraSettings.flashDefault, cameraSettings.timerDefault, cameraSettings.filterDefault]);
  const [status, setStatus] = useState<MirrorCameraStatus>("idle");
  const [errorText, setErrorText] = useState<string | null>(null);
  const [countdownRemaining, setCountdownRemaining] = useState<number | null>(null);
  /* Part 3 mirror — the dial needs the value the countdown STARTED from, not
     just what is left, so the ring empties over the right total. */
  const countdownStarted = useRef(1);
  if (countdownRemaining !== null && countdownRemaining > countdownStarted.current) {
    countdownStarted.current = countdownRemaining;
  }
  const [countdownTrigger, setCountdownTrigger] = useState<CaptureTrigger | null>(null);
  const [processing, setProcessing] = useState(false);
  const [capturedDataUrl, setCapturedDataUrl] = useState<string | null>(null);
  /* POST-CAPTURE EDITING mirror — the editor layer and the summary chip. */
  const [editorOpen, setEditorOpen] = useState(false);
  const [editSummary, setEditSummary] = useState<string | null>(null);
  const [savedPhotoId, setSavedPhotoId] = useState<string | null>(null);
  const [savedToast, setSavedToast] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  // Unit 16 mirror: same runner contract as mobile's poseDetectorService —
  // skeleton+match paint on a canvas (60fps), detection throttled (15fps).
  const [mlStatus, setMlStatus] = useState<"idle" | "loading" | "ready" | "unavailable">("idle");
  const [matchPercent, setMatchPercent] = useState<number | null>(null);
  const [guidance, setGuidance] = useState<GuidanceResult | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  /* Camera UX Part 1 mirror — the semantic coaching state reaches the UI. */
  const [coaching, setCoaching] = useState<CoachingState | null>(null);
  const [autoProgress, setAutoProgress] = useState(0);
  const [gestureProgress, setGestureProgress] = useState(0);
  const [gesturePhase, setGesturePhase] = useState<OpenPalmPhase>("idle");
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const runnerRef = useRef<PreviewPoseRunner | null>(null);
  const handRunnerRef = useRef<PreviewHandRunner | null>(null);
  const openPalmGateRef = useRef(new OpenPalmGate());
  const landmarksRef = useRef<readonly PoseLandmark[] | null>(null);
  const guidanceRef = useRef<GuidanceResult | null>(null);
  const lastGuidanceTextRef = useRef<string | null>(null);
  const matchSmoothingRef = useRef<number | null>(null);
  // Unit 26: mirrored smoothed match % so the 60fps paint loop can style the
  // silhouette contour's stroke + halo without re-rendering the mirror.
  const matchPercentRef = useRef<number | null>(null);
  const lastMatchBandRef = useRef(-1);
  const intelligentCaptureRef = useRef(new IntelligentCaptureController());
  const captureFlowActiveRef = useRef(false);
  const speechPlannerRef = useRef(createCoachingSpeechPlanner());
  const previewSpeakingRef = useRef(false);
  const lastSpokenTextRef = useRef<string | null>(null);
  const lastSpokenAtRef = useRef(Number.NEGATIVE_INFINITY);

  const pose = cameraPoseId !== null ? getPoseById(cameraPoseId) : null;
  const recentPoses = previewRecents
    .slice(0, LIMITS.recentPoses)
    .map((id) => getPoseById(id))
    .filter((p): p is Pose => p !== null);

  /* LOOKS mirror — the strip no longer invents its own CSS recipes.
     `FILTER_CSS` used to live here as five hand-written strings (including a
     180° hue-rotate for "cool", which is not what the device does at all), so
     the mirror and the phone disagreed by construction. Both now read the SAME
     twenty numbers out of shared/camera/cameraFilters: the phone hands them to
     Skia's color matrix, the mirror hands them to an SVG feColorMatrix for the
     live video and multiplies them over the pixels for the captured frame. */
  const lookMatrix = captureColorMatrix({
    filter,
    intensity: filterIntensity,
    brightnessGain: brightnessGain(brightness),
  });
  const lookMatrixValues = filterPreviewMatrixValues(filter, filterIntensity);
  const liveMatrixValues = lookMatrix
    .map((value) => Math.round(value * 10000) / 10000)
    .join(" ");

  // True release — stops every hardware track (mirrors expo-camera unmount).
  const releaseCamera = useCallback(() => {
    const stream = streamRef.current;
    if (stream !== null) {
      stream.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      pushLog("info", "Camera", "session released — hardware tracks stopped");
    }
    if (videoRef.current !== null) videoRef.current.srcObject = null;
  }, [pushLog]);

  const startCamera = useCallback(
    async (nextFacing: "rear" | "front") => {
      if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
        setStatus("unavailable");
        setErrorText("This browser exposes no camera API.");
        return;
      }
      releaseCamera();
      setStatus("requesting");
      pushLog("info", "Camera", "requesting camera permission");
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: nextFacing === "front" ? "user" : "environment" },
          audio: false,
        });
        streamRef.current = stream;
        if (videoRef.current !== null) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setStatus("live");
        setErrorText(null);
        pushLog("info", "Camera", `permission granted — viewfinder ready (${nextFacing})`);
      } catch (error) {
        const name = error instanceof DOMException ? error.name : "Error";
        if (name === "NotAllowedError") {
          setStatus("denied");
          setErrorText("Camera permission was denied for this page.");
          pushLog("warn", "Camera", "permission denied by user");
        } else if (name === "NotFoundError" || name === "OverconstrainedError") {
          setStatus("unavailable");
          setErrorText("No camera device is available on this machine.");
          pushLog("warn", "Camera", "no camera device found");
        } else {
          setStatus("blocked");
          setErrorText("The camera could not be started in this preview frame.");
          pushLog("error", "Camera", `mount error — ${name}`);
        }
      }
    },
    [pushLog, releaseCamera],
  );

  const captureFrame = useCallback(async () => {
    const video = videoRef.current;
    if (video === null || video.videoWidth === 0 || status !== "live" || pose === null) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const context = canvas.getContext("2d");
    if (context === null) return;
    if (facing === "front") {
      context.translate(canvas.width, 0);
      context.scale(-1, 1);
    }
    /* The mirror's captured frame gets the SAME adjustment the device's Skia
       pipeline applies to the JPEG, from the SAME shared gain — so what the
       preview shows after the shutter is the real outcome, not a decoration
       over the viewfinder. */
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    /* EXACT, not approximate: the same matrix the device gives Skia is applied
       here per pixel, so the mirror's saved frame is the device's saved frame
       up to JPEG quantisation. Identity is skipped, exactly as the pipeline
       skips the whole decode/encode when nothing would change. */
    if (!colorMatrixIsIdentity(lookMatrix)) {
      const frame = context.getImageData(0, 0, canvas.width, canvas.height);
      const pixels = frame.data;
      for (let i = 0; i < pixels.length; i += 4) {
        const [r, g, b] = applyColorMatrix(
          [(pixels[i] ?? 0) / 255, (pixels[i + 1] ?? 0) / 255, (pixels[i + 2] ?? 0) / 255],
          lookMatrix,
        );
        pixels[i] = Math.round(r * 255);
        pixels[i + 1] = Math.round(g * 255);
        pixels[i + 2] = Math.round(b * 255);
      }
      context.putImageData(frame, 0, 0);
    }
    const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
    setEditorOpen(false);
    setEditSummary(null);
    setSavedPhotoId(null);
    setSavedToast(false);
    setCountdownTrigger(null);
    setAutoProgress(0);
    setGestureProgress(0);
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
    setProcessing(true);
    releaseCamera();
    pushLog("info", "Capture", `${canvas.width}×${canvas.height} frame captured locally`);
    await new Promise((resolve) => window.setTimeout(resolve, 500));
    setProcessing(false);
    setCapturedDataUrl(dataUrl);
  }, [facing, lookMatrix, pose, pushLog, releaseCamera, status]);

  const beginCapture = useCallback(() => {
    if (status !== "live") return;
    if (!intelligentCaptureRef.current.requestManual(performance.now())) return;
    captureFlowActiveRef.current = true;
    setCountdownTrigger("manual");
    setAutoProgress(0);
    setGestureProgress(0);
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
    if (timer === 0) {
      void captureFrame();
      return;
    }
    setCountdownRemaining(timer);
    pushLog("info", "Capture", `countdown started → ${timer}s`);
  }, [captureFrame, pushLog, status, timer]);

  useEffect(() => {
    if (countdownRemaining === null) return;
    const timeout = window.setTimeout(() => {
      if (countdownRemaining <= 1) {
        setCountdownRemaining(null);
        void captureFrame();
      } else {
        setCountdownRemaining((current) => (current === null ? null : current - 1));
      }
    }, 1_000);
    return () => window.clearTimeout(timeout);
  }, [captureFrame, countdownRemaining]);

  // JIT init + release: only runs while State 2 is mounted.
  useEffect(() => {
    if (pose === null || capturedDataUrl !== null) return;
    void startCamera(facing);
    return () => releaseCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pose?.id, facing, capturedDataUrl]);

  // ── Unit 16: MediaPipe session, bound 1:1 to the live viewfinder ────────
  // Mirror of CameraTab's mlGateOpen effect: init while live, dispose on
  // capture/blur/unmount — the wasm model is never held across sessions.
  useEffect(() => {
    if (status !== "live" || pose === null || capturedDataUrl !== null) return;
    let cancelled = false;
    setMlStatus("loading");
    matchSmoothingRef.current = null;
    lastMatchBandRef.current = -1;
    const runner = new PreviewPoseRunner();
    runnerRef.current = runner;
    const gestureEnabledAtStart = cameraSettings.gestureEnabled;
    const handRunner = new PreviewHandRunner();
    handRunnerRef.current = handRunner;
    openPalmGateRef.current.reset();
    pushLog("info", "ML", `guidance session start (pose=${pose.id})`);
    void runner.init(pushLog).then((ready) => {
      if (cancelled) {
        runner.dispose(() => undefined);
        return;
      }
      setMlStatus(ready ? "ready" : "unavailable");
      // Warmed once per session, off the critical path — app parity.
      if (ready && gestureEnabledAtStart) {
        void handRunner.init(pushLog);
      }
    });
    return () => {
      cancelled = true;
      runner.dispose(pushLog);
      handRunner.dispose(pushLog);
      handRunnerRef.current = null;
      openPalmGateRef.current.reset();
      setGesturePhase("idle");
      runnerRef.current = null;
      landmarksRef.current = null;
      guidanceRef.current = null;
      lastGuidanceTextRef.current = null;
      matchSmoothingRef.current = null;
      setMlStatus("idle");
      setMatchPercent(null);
      matchPercentRef.current = null;
      setGuidance(null);
      setIsSpeaking(false);
      setAutoProgress(0);
      setGestureProgress(0);
      setCountdownTrigger(null);
      captureFlowActiveRef.current = false;
      intelligentCaptureRef.current.reset();
      lastSpokenTextRef.current = null;
      lastSpokenAtRef.current = Number.NEGATIVE_INFINITY;
      speechPlannerRef.current.reset();
      previewSpeakingRef.current = false;
      window.speechSynthesis?.cancel();
      pushLog("info", "ML", "guidance session end — detector disposed, overlays cleared");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, pose?.id, capturedDataUrl]);

  // 60fps UI loop (Unit 26): paints the HOLLOW luminous vector contour of the
  // target pose — the exact outer boundary of the silhouette geometry (same
  // resolvePoseSilhouette tiers: custom-scanned landmarks or generic library,
  // one code path) — as a thin crisp stroke (2.5px, round caps/joins, 8/4
  // dash framing texture) riding on a blurred halo carrier stroke, both
  // colored by the live match-% contour ramp, breathing-pulsed when locked
  // (>85). Body interior stays 100% transparent. Plus the preserved
  // directional arrow. Detection itself stays throttled to 15fps in the runner.
  useEffect(() => {
    if (mlStatus !== "ready" || status !== "live" || pose === null) return;
    /* Unit 29 parity: the mirror resolves its reference through the SAME
       adapter → validate → normalize pipeline the app uses, instead of
       reading pose.referenceAngles raw. A pose whose reference fails to
       validate gets null — guidance idles, exactly as on device. It never
       falls back to substitute angles. */
    const built = buildReferenceTemplate(poseReferenceAdapter.toRawPayload(pose));
    /* Unit 29 parity: ONE analysis engine per session, bound to the validated
       template before the loop starts. The frame loop never re-validates. */
    let analysisEngine: ReturnType<typeof createPoseAnalysisEngine> | null = null;
    if (built.status === ReferenceStatuses.ready) {
      const analysisInput = analysisInputFromTemplate(built.template);
      if (analysisInput.ok) {
        analysisEngine = createPoseAnalysisEngine({
          reference: analysisInput.input,
          sessionId: `preview:${pose.id}`,
        });
      }
    }
    const silhouetteSpec = resolvePoseSilhouette(pose);
    const reduceMotion =
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    let raf = 0;

    // Contour extraction is allocation-heavy: cached per pose+viewport size,
    // never recomputed on the per-frame path (mirrors the mobile useMemo).
    let contourCacheKey = "";
    let contourCachePath: Path2D | null = null;
    const getContourPath = (width: number, height: number): Path2D | null => {
      const key = `${Math.round(width)}x${Math.round(height)}`;
      if (contourCacheKey === key) return contourCachePath;
      contourCacheKey = key;
      contourCachePath = null;
      const fitted = fitSilhouetteToViewport(silhouetteSpec, width, height);
      const loops = outlineSilhouette(fitted);
      if (loops.length > 0) {
        const path = new Path2D();
        for (const loop of loops) {
          const first = loop[0];
          if (first === undefined) continue;
          path.moveTo(first.x, first.y);
          for (let i = 1; i < loop.length; i++) {
            const point = loop[i];
            if (point !== undefined) path.lineTo(point.x, point.y);
          }
          path.closePath();
        }
        contourCachePath = path;
      }
      return contourCachePath;
    };

    const draw = () => {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const landmarks = landmarksRef.current;
      const curGuidance = guidanceRef.current;

      if (canvas !== null && video !== null) {
        const width = canvas.clientWidth;
        const height = canvas.clientHeight;
        const dpr = window.devicePixelRatio || 1;
        if (canvas.width !== Math.round(width * dpr) || canvas.height !== Math.round(height * dpr)) {
          canvas.width = Math.round(width * dpr);
          canvas.height = Math.round(height * dpr);
        }
        const ctx = canvas.getContext("2d");
        if (ctx !== null) {
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          ctx.clearRect(0, 0, width, height);

          // Unit 26: hollow luminous contour guide — always visible while ML
          // is ready; color + opacity follow the live match-% contour ramp,
          // breathing pulse when locked, Reduce Motion pins a static glow.
          const contourPath = getContourPath(width, height);
          if (contourPath !== null) {
            const style = silhouetteContourStyle(matchPercentRef.current, colors.primary);
            let alpha = style.opacity;
            if (style.pulse && !reduceMotion) {
              const phase =
                (performance.now() % SILHOUETTE_CONTOUR_PULSE_PERIOD_MS) /
                SILHOUETTE_CONTOUR_PULSE_PERIOD_MS;
              const wave = 0.5 - 0.5 * Math.cos(phase * Math.PI * 2);
              alpha =
                style.opacity *
                (SILHOUETTE_CONTOUR_PULSE_RATIO +
                  (1 - SILHOUETTE_CONTOUR_PULSE_RATIO) * wave);
            }
            // Neon halo: wide carrier stroke with a Gaussian drop shadow.
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.strokeStyle = style.color;
            ctx.lineWidth = SILHOUETTE_CONTOUR_GLOW_STROKE_PX;
            ctx.lineCap = "round";
            ctx.lineJoin = "round";
            ctx.shadowColor = style.color;
            ctx.shadowBlur = SILHOUETTE_CONTOUR_GLOW_SIGMA * 2;
            ctx.stroke(contourPath);
            ctx.restore();
            // Crisp vector boundary with the framing-guide dash texture.
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.strokeStyle = style.color;
            ctx.lineWidth = SILHOUETTE_CONTOUR_STROKE_PX;
            ctx.lineCap = "round";
            ctx.lineJoin = "round";
            ctx.setLineDash([...SILHOUETTE_CONTOUR_DASH_PX]);
            ctx.stroke(contourPath);
            ctx.restore();
          }

          // Unit 17 preserved: Directional arrow indicator on the worst joint
          // of the detected pose (positions computed as before, never drawn as
          // a skeleton).
          if (landmarks !== null && landmarks.length > 0) {
            const projection = projectPose(
              landmarks,
              video.videoWidth,
              video.videoHeight,
              width,
              height,
              facing === "front",
            );
            if (
              projection !== null &&
              curGuidance !== null &&
              curGuidance.worstLandmarkName !== null &&
              curGuidance.arrowDirection !== 'none'
            ) {
              const idx = POSE_LANDMARKS[curGuidance.worstLandmarkName];
              const pt = projection.points[idx];
              if (pt && pt.reliable) {
                const arrowColor =
                  curGuidance.severity === 'adjust' ? '#EF4444' : '#F59E0B';
                drawCanvasArrow(ctx, pt.x, pt.y, curGuidance.arrowDirection, arrowColor);
              }
            }
          }
        }
      }
    };

    const loop = () => {
      const video = videoRef.current;
      const runner = runnerRef.current;
      if (video !== null && runner !== null && !captureFlowActiveRef.current) {
        const detected = runner.detect(video, performance.now());
        if (detected !== null) {
          landmarksRef.current = detected.length > 0 ? detected : null;
          /* GESTURE CAPTURE — app-parity ordering: gesture off → nothing; no
             body → nothing; no raised hand (cheap pose pre-filter) → no hand
             inference; hand model unavailable → gesture never fires. The
             single-frame verdict is EVIDENCE; the shared gate decides. */
          let gestureEvidence: OpenPalmEvidence | null = null;
          const handRunner = handRunnerRef.current;
          if (cameraSettings.gestureEnabled && detected.length > 0 && handRunner !== null) {
            const presentation = detectHandPresentation(detected);
            if (presentation.present && handRunner.isModelReady) {
              const hands = handRunner.detect(video, performance.now());
              gestureEvidence = hands === null ? null : selectCaptureHand(hands);
            }
          }
          const gate = openPalmGateRef.current.update({
            nowMs: performance.now(),
            evidence: cameraSettings.gestureEnabled ? gestureEvidence : null,
          });
          setGesturePhase(cameraSettings.gestureEnabled ? gate.phase : "idle");
          const decision = analysisEngine?.analyzeFrame(detected) ?? null;
          /* Unit 31 parity: ONE geometry pass — the match % is derived from
             the engine's comparisons, exactly as on device. */
          const result = matchFromDecision(decision);
          if (result.percent === null) {
            matchSmoothingRef.current = null;
            matchPercentRef.current = null;
            lastMatchBandRef.current = -1;
            guidanceRef.current = null;
            setMatchPercent(null);
            setGuidance(null);
            setAutoProgress(0);
            setGestureProgress(0);
            const lostState = intelligentCaptureRef.current.update({
              nowMs: performance.now(),
              matchPercent: null,
              autoThreshold: cameraSettings.autoThreshold,
              gestureConfirmed: gate.confirmed,
              gestureProgress: gate.progress,
              autoEnabled: true,
              gestureEnabled: cameraSettings.gestureEnabled,
            });
            setGestureProgress(lostState.gestureProgress);
            if (lostState.trigger !== null && !captureFlowActiveRef.current) {
              openPalmGateRef.current.notifyCaptureCommitted(performance.now());
              captureFlowActiveRef.current = true;
              setCountdownTrigger(lostState.trigger);
              setCountdownRemaining(cameraSettings.countdownDuration);
              setGestureProgress(0);
              setGesturePhase("cooldown");
            }
          } else {
            // Same EMA as the app screen (0.35) for shared behavior parity.
            const previous = matchSmoothingRef.current;
            const smoothed =
              previous === null ? result.percent : previous + (result.percent - previous) * 0.35;
            matchSmoothingRef.current = smoothed;
            const rounded = Math.round(smoothed);
            const bandIndex = MATCH_COLOR_BANDS.findIndex(
              (band) => rounded >= band.min && rounded <= band.max,
            );
            if (bandIndex !== lastMatchBandRef.current && lastMatchBandRef.current !== -1) {
              const band = MATCH_COLOR_BANDS[bandIndex];
              if (band !== undefined) {
                pushLog("info", "ML", `match band → ${band.label} (${rounded}%)`);
              }
            }
            if (bandIndex >= 0) lastMatchBandRef.current = bandIndex;
            matchPercentRef.current = rounded;
            setMatchPercent(rounded);

            // Unit 17 copy, selected by the Unit 29 deterministic engine.
            const guidanceResult =
              decision === null ? null : decisionToGuidance(decision);
            // Unit 30: the one semantic coaching state behind both the
            // visible guidance and the spoken cue.
            const coachingState =
              decision === null ? null : decisionToCoachingState(decision);
            setCoaching(coachingState);
            guidanceRef.current = guidanceResult;
            setGuidance(guidanceResult);

            if (
              guidanceResult !== null &&
              guidanceResult.text !== lastGuidanceTextRef.current
            ) {
              lastGuidanceTextRef.current = guidanceResult.text;
              pushLog(
                "info",
                "Guidance",
                `${guidanceResult.text} (${guidanceResult.hint})`,
              );
            }

            /* Unit 30 preview parity: the mirror runs the SAME shared
               coaching layer as the device — semantic state → cadence
               planner → language → severity-tiered phrase — and only the
               speech backend differs (browser speechSynthesis here,
               expo-speech on device). No coaching logic is duplicated. */
            const now = performance.now();
            /* Unit 35 parity: the mirror uses the SAME central routing gate
               as the device (shared/voice/routing) — voice-guidance switch,
               capture ownership and language normalization in one place.
               The semantic state itself is never dropped by it. */
            const speechRoute = routeCoachingSpeech({
              state: coachingState,
              voiceGuidanceEnabled: cameraSettings.voiceEnabled,
              language: cameraSettings.instructionLanguage,
              captureInProgress: captureFlowActiveRef.current,
            });
            /* Unit 36 parity: the planner is consulted for a DELIVERABLE
               frame, and merely OBSERVES an unjudgeable one (exactly what
               ttsService.speakCoaching / observeCoaching do on device), so
               the silence-grace and perfect-episode rules behave the same in
               both runtimes. Observation can never produce speech. */
            const deliverableState = speechRoute.deliverToSpeech
              ? speechRoute.state
              : null;
            const speechPlan =
              deliverableState === null
                ? null
                : speechPlannerRef.current.plan({
                    state: deliverableState,
                    nowMs: now,
                    isSpeaking: previewSpeakingRef.current,
                  });
            if (
              !speechRoute.deliverToSpeech &&
              coachingState !== null &&
              !coachingState.speakable &&
              cameraSettings.voiceEnabled
            ) {
              speechPlannerRef.current.plan({
                state: coachingState,
                nowMs: now,
                isSpeaking: previewSpeakingRef.current,
              });
            }
            /* Unit 34 parity: `plan()` COMMITS the moment it authorizes a
               line. If the mirror cannot actually execute it (voice off,
               capture flow owns the audio, no Web Speech API, or the phrase
               layer answers silence) the authorization is withdrawn, exactly
               as ttsService does — otherwise the preview's cadence would
               drift away from the device's. */
            let speechExecuted = false;
            if (
              speechRoute.deliverToSpeech &&
              speechRoute.state !== null &&
              speechPlan !== null &&
              speechPlan.speak &&
              typeof window.speechSynthesis !== "undefined" &&
              typeof SpeechSynthesisUtterance !== "undefined"
            ) {
              const phrase = selectCoachingPhrase(
                speechRoute.state,
                speechRoute.language,
              );
              if (phrase !== null) {
                speechExecuted = true;
                window.speechSynthesis.cancel();
                const utterance = new SpeechSynthesisUtterance(phrase.text);
                /* Locale comes from the shared table, never a literal. */
                utterance.lang = primaryLocaleFor(phrase.language);
                /* Unit 36: delivery numbers come from the ONE shared table
                   (shared/voice/prosody), never from literals duplicated per
                   speech backend. */
                const prosody = prosodyForIntensity(phrase.intensity);
                utterance.rate = prosody.rate;
                utterance.volume = prosody.volume;
                utterance.pitch = prosody.pitch;
                utterance.onstart = () => {
                  previewSpeakingRef.current = true;
                  setIsSpeaking(true);
                };
                utterance.onend = () => {
                  previewSpeakingRef.current = false;
                  setIsSpeaking(false);
                };
                utterance.onerror = () => {
                  previewSpeakingRef.current = false;
                  setIsSpeaking(false);
                };
                lastSpokenTextRef.current = phrase.text;
                lastSpokenAtRef.current = now;
                window.speechSynthesis.speak(utterance);
                pushLog(
                  "info",
                  "Voice",
                  `${speechPlan.reason} · ${phrase.category} · ${phrase.intensity} · ${phrase.language}`,
                );
              }
            }
            if (speechPlan !== null && speechPlan.speak && !speechExecuted) {
              speechPlannerRef.current.revert(speechPlan);
            }

            const intelligentState = intelligentCaptureRef.current.update({
              nowMs: now,
              matchPercent: rounded,
              autoThreshold: cameraSettings.autoThreshold,
              gestureConfirmed: gate.confirmed,
              gestureProgress: gate.progress,
              autoEnabled: true,
              gestureEnabled: cameraSettings.gestureEnabled,
            });
            setAutoProgress(intelligentState.autoProgress);
            setGestureProgress(intelligentState.gestureProgress);
            if (intelligentState.trigger !== null && !captureFlowActiveRef.current) {
              openPalmGateRef.current.notifyCaptureCommitted(now);
              setGesturePhase("cooldown");
              captureFlowActiveRef.current = true;
              setCountdownTrigger(intelligentState.trigger);
              setCountdownRemaining(cameraSettings.countdownDuration);
              setAutoProgress(0);
              setGestureProgress(0);
              window.speechSynthesis?.cancel();
              setIsSpeaking(false);
              pushLog(
                "info",
                "Capture",
                intelligentState.trigger === "auto"
                  ? `${cameraSettings.autoThreshold}% match held for 2s - automatic countdown (${cameraSettings.countdownDuration}s)`
                  : `five-finger open palm confirmed - gesture countdown (${cameraSettings.countdownDuration}s)`,
              );
            }
          }
        }
      }
      draw();
      raf = window.requestAnimationFrame(loop);
    };
    raf = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mlStatus, status, pose?.id, facing, colors.primary]);

  // ── State 1: no pose armed ───────────────────────────────────────────────
  if (pose === null) {
    return (
      <div
        className="flex h-full flex-col"
        style={{ backgroundColor: colors.backgroundSecondary }}
      >
        <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
          <div
            className="flex h-20 w-20 items-center justify-center rounded-full"
            style={{ backgroundColor: colors.primaryLight }}
          >
            <Camera size={40} style={{ color: colors.primary }} />
          </div>
          <p className="mt-4 text-base font-semibold" style={{ color: colors.textPrimary }}>
            No pose selected
          </p>
          <p className="mt-1.5 text-xs leading-relaxed" style={{ color: colors.textSecondary }}>
            Select a pose to start guided capture. The AI watches your body and
            guides you into the perfect frame.
          </p>
          <button
            onClick={() => setActiveTab("explore")}
            className="mt-5 cursor-pointer rounded-xl px-5 py-2.5 text-xs font-semibold text-white pv-press"
            style={{ backgroundColor: colors.primary }}
          >
            Browse Poses
          </button>
        </div>

        {recentPoses.length > 0 && (
          <div className="px-4 pb-3">
            <p
              className="text-[9px] font-bold uppercase tracking-wider"
              style={{ color: colors.textDisabled }}
            >
              Continue with a recent pose
            </p>
            <div className="mt-2 flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {recentPoses.map((recent) => (
                <button
                  key={recent.id}
                  onClick={() => {
                    viewPreviewPose(recent.id);
                    armCameraPose(recent.id);
                  }}
                  className="w-20 shrink-0 cursor-pointer text-left pv-press"
                >
                  <PoseArt pose={recent} isDark={false} className="h-20" rounded="rounded-lg" iconSize={22} />
                  <p
                    className="mt-1 line-clamp-1 text-[9px] font-semibold"
                    style={{ color: colors.textPrimary }}
                  >
                    {recent.title}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={() => setActiveTab("gallery")}
          className="mx-4 mb-4 flex cursor-pointer items-center gap-2.5 rounded-xl border p-3 text-left"
          style={{ backgroundColor: colors.surface, borderColor: colors.divider }}
        >
          <span
            className="flex h-9 w-9 items-center justify-center rounded-md"
            style={{ backgroundColor: colors.primaryLight }}
          >
            <GalleryIcon size={16} style={{ color: colors.primary }} />
          </span>
          <span className="flex-1">
            <span className="block text-[11px] font-semibold" style={{ color: colors.textPrimary }}>
              Gallery
            </span>
            <span className="block text-[9px]" style={{ color: colors.textSecondary }}>
              Your captured shots stay on this device
            </span>
          </span>
          <ChevronRight size={14} style={{ color: colors.textDisabled }} />
        </button>
      </div>
    );
  }

  // ── Unit 13 Preview Screen mirror ───────────────────────────────────────
  if (capturedDataUrl !== null) {
    const shareCaptured = async () => {
      try {
        const blob = await fetch(capturedDataUrl).then((response) => response.blob());
        const file = new File([blob], "poseassist-capture.jpg", { type: "image/jpeg" });
        if (navigator.share && navigator.canShare?.({ files: [file] })) {
          await navigator.share({ files: [file], title: "PoseAssist capture" });
          pushLog("info", "Preview", "native share sheet opened");
          return;
        }
        const link = document.createElement("a");
        link.href = capturedDataUrl;
        link.download = "poseassist-capture.jpg";
        link.click();
        pushLog("info", "Preview", "sharing unavailable → downloaded local image");
      } catch (error) {
        pushLog("error", "Preview", `share failed → ${String(error)}`);
      }
    };

    const discard = () => {
      if (savedPhotoId !== null) deletePreviewPhoto(savedPhotoId);
      setCapturedDataUrl(null);
      setSavedPhotoId(null);
      setSavedToast(false);
      pushLog("info", "Preview", "captured photo deleted");
    };

    return (
      <div className="relative flex h-full flex-col bg-black">
        <img
          src={capturedDataUrl}
          alt="Your newly captured photo"
          className="absolute inset-0 h-full w-full object-contain"
        />
        <div className="relative z-10 flex h-14 items-center justify-between px-3 text-white" style={{ backgroundImage: "var(--pv-scrim-top)" }}>
          <button
            onClick={() => {
              setCapturedDataUrl(null);
              setSavedPhotoId(null);
              setSavedToast(false);
            }}
            className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
            aria-label="Close preview"
          >
            ×
          </button>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setEditorOpen(true)}
              className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
              aria-label="Edit photo: crop, rotate or enhance"
            >
              <Pencil size={16} />
            </button>
            <button
              onClick={() => void shareCaptured()}
              className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
              aria-label="Share captured photo"
            >
              <ArrowRight size={18} />
            </button>
            <button
              onClick={discard}
              className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
              aria-label="Delete captured photo"
            >
              ×
            </button>
          </div>
        </div>
        <div className="flex-1" />
        <div className="relative z-10 flex h-24 items-center justify-between px-6 text-white" style={{ backgroundImage: "var(--pv-scrim-bottom)" }}>
          <button
            onClick={() => {
              setCapturedDataUrl(null);
              setSavedPhotoId(null);
              setSavedToast(false);
              pushLog("info", "Preview", `retake → camera State 2 (${pose.id})`);
            }}
            className="pv-press flex min-h-12 cursor-pointer items-center gap-1.5 rounded-lg px-3 text-xs font-semibold"
          >
            <Repeat2 size={16} /> Retake
          </button>
          <button
            onClick={() => {
              if (savedPhotoId !== null) {
                setActiveTab("gallery");
                return;
              }
              const id = savePreviewPhoto({
                dataUrl: capturedDataUrl,
                poseId: pose.id,
                /* Parity with the device record, which stores the look id and
                   nothing else: the STRENGTH is already baked into the pixels,
                   so inventing a metadata field the app does not have would
                   make the mirror lie in the other direction. */
                filterUsed: filter,
              });
              setSavedPhotoId(id);
              setSavedToast(true);
              window.setTimeout(() => setSavedToast(false), 2_000);
              pushLog("info", "Preview", "Saved to gallery (device-only mirror)");
            }}
            className={`min-h-12 min-w-28 cursor-pointer rounded-xl px-5 text-sm font-semibold pv-press ${savedPhotoId === null ? "pv-btn-fill" : ""}`}
            style={{
              backgroundColor: savedPhotoId !== null ? "#fff" : colors.primary,
              color: savedPhotoId !== null ? "#000" : "#fff",
            }}
          >
            {savedPhotoId !== null ? "Done" : "Save"}
          </button>
        </div>
        {editSummary !== null && !editorOpen && (
          <div className="absolute bottom-28 left-4 z-20 rounded-full bg-black/60 px-3 py-1 text-[9px] font-semibold text-white">
            {editSummary}
          </div>
        )}
        {savedToast && (
          <div className="absolute inset-x-4 bottom-28 z-20 rounded-xl bg-emerald-500 px-4 py-3 text-center text-xs font-semibold text-white">
            Saved to gallery
          </div>
        )}
        {editorOpen && (
          <PhotoEditorMirror
            dataUrl={capturedDataUrl}
            onCancel={() => setEditorOpen(false)}
            onApplied={(next, summary) => {
              setCapturedDataUrl(next);
              setEditSummary(summary);
              setEditorOpen(false);
              /* Parity with the device: editing a photo that is ALREADY saved
                 replaces the saved copy, it does not leave the gallery holding
                 the pre-edit picture. */
              if (savedPhotoId !== null) {
                deletePreviewPhoto(savedPhotoId);
                setSavedPhotoId(
                  savePreviewPhoto({ dataUrl: next, poseId: pose.id, filterUsed: filter }),
                );
              }
            }}
            onLog={(level, message) => pushLog(level, "Edit", message)}
          />
        )}
      </div>
    );
  }

  // ── State 2: live camera shell ───────────────────────────────────────────
  const matchPillColor = matchPercent !== null ? matchColorFor(matchPercent) : undefined;

  /* Camera UX Part 1 mirror — the preview consumes the SAME pure resolver and
     the SAME visible-copy table as the Expo screen, so what is verified here
     is the production decision, not a hand-copied approximation of it. */
  const previewStatusCopy = cameraStatusCopyFor(cameraSettings.instructionLanguage);
  const previewPresentation = resolveCameraPresentation({
    sessionLive: status === "live",
    cameraReady: status === "live",
    mlStatus,
    countdownActive: countdownRemaining !== null,
    isCapturing: false,
    isProcessing: processing,
    coachingKind: coaching?.kind ?? null,
    holdProgress: Math.max(autoProgress, gestureProgress),
    holdSource: gestureProgress > 0 ? "gesture" : autoProgress > 0 ? "auto" : "none",
    /* Part 2 mirror: the preview has no pinch gesture, so zoom is never
       "engaged" here — exactly like a device sitting at 1.0x. */
    zoomEngaged: false,
    captureErrorActive: false,
    voiceGuidanceEnabled: cameraSettings.voiceEnabled,
    isSpeaking,
  });
  const previewCoaching = visibleCoachingFor(coaching, cameraSettings.instructionLanguage);
  /* CAMERA CONTROLS mirror — the SAME pure resolver the device screen uses,
     so "no torch on the front camera" and "flash is superseded by the torch"
     are verified here rather than re-implemented for the browser. */
  const mirrorLighting = resolveLighting({
    facing: facing === "front" ? "front" : "back",
    flash,
    torchRequested,
    sessionLive: status === "live",
  });

  return (
    <div className="relative flex h-full flex-col bg-black">
      {/* The look, as a filter primitive. sRGB interpolation because the
          device operates on sRGB JPEG samples, not linear light. */}
      <svg aria-hidden className="pointer-events-none absolute h-0 w-0">
        <defs>
          <filter id="pv-look-matrix" colorInterpolationFilters="sRGB">
            <feColorMatrix type="matrix" values={liveMatrixValues} />
          </filter>
          <filter id="pv-look-swatch" colorInterpolationFilters="sRGB">
            <feColorMatrix type="matrix" values={lookMatrixValues} />
          </filter>
        </defs>
      </svg>
      <video
        ref={videoRef}
        playsInline
        muted
        className="absolute inset-0 h-full w-full object-cover"
        style={{
          /* CAMERA CONTROLS mirror — brightness is applied to the live video
             with the shared gain. On device the viewfinder can only show an
             approximating wash (expo-camera exposes no exposure control and
             the frame buffer is not ours); here the browser can filter the
             video itself, so the mirror is the STRONGER preview of the same
             adjustment, never a different one. */
          /* LOOKS mirror — one SVG feColorMatrix carrying look ∘ strength ∘
             brightness. Not a CSS impression of the phone's matrix: the
             identical matrix, evaluated by the browser's rasteriser. */
          filter: colorMatrixIsIdentity(lookMatrix) ? undefined : "url(#pv-look-matrix)",
          transform: facing === "front" ? "scaleX(-1)" : undefined,
          opacity: status === "live" ? 1 : 0,
        }}
      />
      {/* Unit 26 — Silhouette-guide mirror: hollow luminous contour + halo, 60fps canvas */}
      {status === "live" && mlStatus === "ready" && (
        <canvas
          ref={canvasRef}
          className="pointer-events-none absolute inset-0 z-[5] h-full w-full"
        />
      )}

      {/* Unit 20 — 3x3 rule-of-thirds composition grid */}
      {status === "live" && cameraSettings.gridOverlayEnabled && (
        <div className="pointer-events-none absolute inset-0 z-[6]">
          <div className="absolute inset-y-0 left-1/3 w-px bg-white/40" />
          <div className="absolute inset-y-0 left-2/3 w-px bg-white/40" />
          <div className="absolute inset-x-0 top-1/3 h-px bg-white/40" />
          <div className="absolute inset-x-0 top-2/3 h-px bg-white/40" />
        </div>
      )}

      {status !== "live" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 px-8 text-center">
          <p className="text-xs font-semibold text-white">
            {status === "requesting"
              ? "Requesting camera access…"
              : status === "denied"
                ? "Camera access denied"
                : status === "unavailable"
                  ? "No camera available"
                  : status === "blocked"
                    ? "Camera unavailable"
                    : "Starting camera…"}
          </p>
          {errorText !== null && (
            <p className="text-[10px] leading-relaxed text-white/60">{errorText}</p>
          )}
          {(status === "denied" || status === "blocked") && (
            <button
              onClick={() => void startCamera(facing)}
              className="pv-press pv-btn-fill mt-1 cursor-pointer rounded-lg px-4 py-2 text-[10px] font-semibold text-white"
              style={{ backgroundColor: colors.primary }}
            >
              Try Again
            </button>
          )}
        </div>
      )}

      {/* Top controls — CAMERA CONTROLS mirror: flash · light · brightness ·
          timer · settings, in the same order and with the same states as the
          device bar (shared/camera/cameraControls decides all of them). */}
      <div className="relative z-10 flex h-14 items-center justify-between px-3 text-white" style={{ backgroundImage: "var(--pv-scrim-top)" }}>
        <button
          onClick={() => {
            if (mirrorLighting.flashSupersededByTorch) {
              pushLog("info", "Camera", `flash ignored — ${previewStatusCopy.flashSupersededNote}`);
              return;
            }
            const next = flash === "off" ? "auto" : flash === "auto" ? "on" : "off";
            setFlash(next);
            pushLog("info", "Camera", `flash → ${next}`);
          }}
          disabled={mirrorLighting.flashSupersededByTorch}
          className={`flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press ${
            mirrorLighting.flashSupersededByTorch ? "cursor-not-allowed opacity-35" : ""
          }`}
          aria-label={`${previewStatusCopy.flashTitle} ${previewStatusCopy.flashValue(flash)}`}
          title={
            mirrorLighting.flashSupersededByTorch
              ? previewStatusCopy.flashSupersededNote
              : previewStatusCopy.flashValue(flash)
          }
        >
          {flash === "off" ? <ZapOff size={22} /> : <Zap size={22} />}
        </button>
        <button
          onClick={() => {
            if (!mirrorLighting.torchEnabled && !torchRequested) {
              pushLog("warn", "Camera", previewStatusCopy.torchBlocked(mirrorLighting.torchBlockedReason));
              return;
            }
            const next = !torchRequested;
            setTorchRequested(next);
            pushLog(
              "info",
              "Camera",
              `torch → ${next ? "on" : "off"} (device hardware — not simulated in browser)`,
            );
          }}
          className={`relative flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press ${
            mirrorLighting.torchEnabled ? "" : "opacity-35"
          }`}
          style={{ color: mirrorLighting.torchOn ? colors.warning : undefined }}
          aria-label={`${previewStatusCopy.torchTitle} ${
            mirrorLighting.torchEnabled
              ? previewStatusCopy.torchValue(mirrorLighting.torchOn)
              : previewStatusCopy.torchBlocked(mirrorLighting.torchBlockedReason)
          }`}
          title={
            mirrorLighting.torchEnabled
              ? `${previewStatusCopy.torchTitle}: ${previewStatusCopy.torchValue(mirrorLighting.torchOn)} — device hardware`
              : previewStatusCopy.torchBlocked(mirrorLighting.torchBlockedReason)
          }
        >
          {mirrorLighting.torchOn ? <Flashlight size={22} /> : <FlashlightOff size={22} />}
          {mirrorLighting.torchOn && (
            <span className="absolute inset-0 -z-10 rounded-full bg-white/15" />
          )}
        </button>
        <button
          onClick={() => setBrightnessOpen((open) => !open)}
          className="relative flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
          style={{
            color:
              brightnessOpen || !isBrightnessDefault(brightness) ? colors.primary : undefined,
          }}
          aria-label={`${previewStatusCopy.brightnessTitle} — ${previewStatusCopy.brightnessValue(brightness)}`}
          title={previewStatusCopy.brightnessNote}
        >
          <SunDim size={22} />
          {!isBrightnessDefault(brightness) && (
            <span className="absolute bottom-0 right-0 rounded bg-black/60 px-1 text-[8px] font-bold">
              {brightness > 0 ? `+${brightness}` : brightness}
            </span>
          )}
        </button>
        <button
          onClick={() => {
            const seq = [0, 3, 5, 10];
            const next = seq[(seq.indexOf(timer) + 1) % seq.length] ?? 0;
            setTimer(next);
            pushLog("info", "Camera", `timer → ${next === 0 ? "Off" : `${next}s`}`);
          }}
          className="relative flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
          aria-label="Capture timer"
        >
          <Timer size={22} />
          <span className="absolute bottom-0 right-0 rounded bg-black/60 px-1 text-[8px] font-bold">
            {timer === 0 ? "Off" : `${timer}s`}
          </span>
        </button>
        <button
          onClick={() => {
            setSettingsOpen(true);
            pushLog("info", "Camera", "settings → /settings");
          }}
          className={`relative flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press ${
            cameraSettings.gridOverlayEnabled || !cameraSettings.voiceEnabled
              ? "text-blue-400"
              : "text-white"
          }`}
          aria-label="Camera settings"
        >
          <Settings size={22} />
          {(cameraSettings.gridOverlayEnabled || !cameraSettings.voiceEnabled) && (
            <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-blue-400" />
          )}
        </button>
      </div>

      {/* BRIGHTNESS PANEL mirror — right edge, thumb height, detents top =
          brighter. Tap the value chip to reset; tap off the track, or the sun
          glyph again, to dismiss. Identical model to the device control. */}
      {brightnessOpen && previewPresentation.blocking === "none" && (
        <>
          <button
            className="absolute inset-0 z-10 cursor-default"
            aria-label={`${previewStatusCopy.brightnessTitle} — ${previewStatusCopy.captureDismiss}`}
            onClick={() => setBrightnessOpen(false)}
          />
          <div className="absolute right-3 top-24 z-20 flex flex-col items-center gap-1">
            <button
              onClick={() => setBrightness(0)}
              disabled={isBrightnessDefault(brightness)}
              className="rounded-full bg-black/60 px-3 py-1 text-[10px] font-bold text-white disabled:opacity-60"
              style={{
                border: isBrightnessDefault(brightness)
                  ? "1px solid transparent"
                  : `1px solid ${colors.primary}`,
              }}
              title={previewStatusCopy.brightnessReset}
            >
              {previewStatusCopy.brightnessValue(brightness)}
              {!isBrightnessDefault(brightness) && (
                <span className="ml-1 font-normal text-white/60">
                  {previewStatusCopy.brightnessReset}
                </span>
              )}
            </button>
            <div
              className="flex w-12 flex-col items-center justify-between rounded-full bg-black/60 py-2"
              role="slider"
              tabIndex={0}
              aria-label={previewStatusCopy.brightnessTitle}
              aria-valuemin={-3}
              aria-valuemax={3}
              aria-valuenow={brightness}
              aria-valuetext={previewStatusCopy.brightnessValue(brightness)}
              onKeyDown={(event) => {
                if (event.key === "ArrowUp") setBrightness((v) => clampBrightness(v + 1));
                else if (event.key === "ArrowDown") setBrightness((v) => clampBrightness(v - 1));
                else if (event.key === "Escape") setBrightnessOpen(false);
              }}
            >
              <Sun size={14} className="text-white" />
              <div className="flex flex-col items-center gap-2 py-2">
                {[3, 2, 1, 0, -1, -2, -3].map((detent) => {
                  const selected = detent === brightness;
                  return (
                    <button
                      key={detent}
                      onClick={() => setBrightness(detent)}
                      className="flex h-5 w-10 cursor-pointer items-center justify-center"
                      aria-label={previewStatusCopy.brightnessValue(detent)}
                      title={previewStatusCopy.brightnessValue(detent)}
                    >
                      <span
                        className="rounded-sm"
                        style={{
                          width: selected ? 26 : detent === 0 ? 18 : 12,
                          height: selected ? 4 : 2,
                          backgroundColor: selected ? colors.primary : "rgba(255,255,255,0.25)",
                        }}
                      />
                    </button>
                  );
                })}
              </div>
              <Moon size={14} className="text-white/60" />
            </div>
            <p className="max-w-[9rem] rounded-full bg-black/45 px-2 py-0.5 text-center text-[9px] text-white/70">
              {previewStatusCopy.brightnessNote}
            </p>
          </div>
        </>
      )}

      {/* Camera UX Part 2 mirror — the permanent "1.0x" pill is gone (the
          resolver hides it unless the user is actually zooming) and the
          reference thumbnail drops to a hairline so it stops out-shouting
          the live subject. */}
      {/* Camera UX Part 3 mirror — THE POSE IDENTITY CHIP. The pinned
          reference now also says WHICH pose is being coached and is the way
          back out of the viewfinder, exactly as on device. */}
      <div className="relative z-10 mt-2 flex items-start justify-end px-3">
        <button
          onClick={() => armCameraPose(null)}
          className="w-20 cursor-pointer overflow-hidden rounded-2xl border border-white/25 bg-black/45 text-left pv-press"
          aria-label={`${previewStatusCopy.shooting}: ${pose.title}`}
          title={previewStatusCopy.changePose}
        >
          <div className="relative h-[6.5rem] overflow-hidden">
            <PoseArt pose={pose} isDark className="h-full" rounded="rounded-none" iconSize={26} />
            <span className="absolute bottom-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 text-[9px] text-white">
              <Repeat2 size={11} />
            </span>
          </div>
          <span className="block truncate px-2 py-1 text-[9px] font-semibold text-white/85">
            {pose.title}
          </span>
        </button>
      </div>

      {/* Camera UX Part 2 mirror — THE STATUS RAIL. One surface: the
          readiness word (primary), the match number at the emphasis the
          resolver decided, the voice state (tappable), and a hairline
          progress track. Replaces the separate match pill + voice chip. */}
      {previewPresentation.showStatusRail && (
        <div className="absolute left-1/2 top-[10.5rem] z-20 w-[15rem] -translate-x-1/2">
          {/* Part 3 mirror — the rail recedes while the app is merely
              observing and comes forward when the user must act. */}
          <div
            className="flex flex-col gap-1 rounded-3xl border border-white/15 bg-black/45 py-2 pl-3 pr-2 transition-all duration-300"
            style={{
              opacity: previewPresentation.railEmphasis === "active" ? 1 : 0.72,
              transform:
                previewPresentation.railEmphasis === "active"
                  ? "scale(1)"
                  : "scale(0.98)",
            }}
          >
            <div className="flex items-center gap-2">
              <span
                className="h-2 w-2 shrink-0 rounded-full transition-colors duration-300"
                style={{
                  backgroundColor:
                    previewPresentation.readiness === "ready"
                      ? colors.success
                      : previewPresentation.matchEmphasis !== "hidden" && matchPercent !== null
                        ? matchColorFor(matchPercent)
                        : "rgba(255,255,255,0.6)",
                }}
              />
              <span className="flex-1 truncate text-xs font-semibold text-white">
                {previewStatusCopy.readiness(previewPresentation.readiness)}
              </span>
              {previewPresentation.matchEmphasis !== "hidden" && matchPercent !== null && (
                <span
                  className={`shrink-0 tabular-nums ${
                    previewPresentation.matchEmphasis === "primary"
                      ? "text-xs font-semibold text-white"
                      : "text-[10px] font-semibold text-white/60"
                  }`}
                >
                  {previewStatusCopy.formatMatch(matchPercent)}
                </span>
              )}
              {previewPresentation.voiceIndicator !== "hidden" && (
                <button
                  onClick={() => {
                    updateCameraSettings({ voiceEnabled: !cameraSettings.voiceEnabled });
                    pushLog("info", "Camera", `voice → ${!cameraSettings.voiceEnabled}`);
                  }}
                  className="relative flex h-8 w-8 shrink-0 cursor-pointer items-center justify-center rounded-full pv-press"
                  aria-label={
                    previewPresentation.voiceIndicator === "speaking"
                      ? previewStatusCopy.voiceSpeaking
                      : previewPresentation.voiceIndicator === "muted"
                        ? previewStatusCopy.voiceMuted
                        : previewStatusCopy.voiceIdle
                  }
                >
                  {previewPresentation.voiceIndicator === "speaking" && (
                    <span className="absolute h-8 w-8 animate-ping rounded-full bg-white/25" />
                  )}
                  {previewPresentation.voiceIndicator === "muted" ? (
                    <VolumeX size={15} className="text-white/60" />
                  ) : (
                    <Volume2
                      size={15}
                      className={
                        previewPresentation.voiceIndicator === "speaking"
                          ? "text-white"
                          : "text-white/60"
                      }
                    />
                  )}
                </button>
              )}
            </div>
            <div className="mx-1 h-0.5 overflow-hidden rounded-full bg-white/15">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{
                  width: `${
                    previewPresentation.matchEmphasis !== "hidden" && matchPercent !== null
                      ? matchPercent
                      : 0
                  }%`,
                  backgroundColor:
                    previewPresentation.readiness === "ready"
                      ? colors.success
                      : matchPillColor ?? "rgba(255,255,255,0.6)",
                }}
              />
            </div>
          </div>
        </div>
      )}

      <div className="flex-1" />

      {/* Camera UX Part 1 mirror — THE coaching band: one message per frame,
          total over the semantic state, in the coaching language. */}
      {previewPresentation.showCoachingBand && previewCoaching !== null && (
        <div className="pointer-events-none relative z-20 mx-3 mb-3 flex flex-col items-center">
          <div className="flex max-w-[300px] flex-col items-center gap-1 rounded-2xl border border-white/20 bg-black/75 px-3.5 py-2 text-center pv-elev-3 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <span
                className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white"
                style={{
                  backgroundColor:
                    previewCoaching.tone === "ready"
                      ? colors.success
                      : previewCoaching.tone === "adjust"
                        ? colors.warning
                        : previewCoaching.tone === "attention"
                          ? colors.error
                          : "rgba(255,255,255,0.25)",
                }}
              >
                {previewCoaching.tone === "ready" ? (
                  <CheckCircle2 size={13} strokeWidth={2.5} />
                ) : !previewCoaching.aboutBody ? (
                  <Search size={13} strokeWidth={2.5} />
                ) : guidance?.arrowDirection === "up" ? (
                  <ArrowUp size={13} strokeWidth={2.5} />
                ) : guidance?.arrowDirection === "down" ? (
                  <ArrowDown size={13} strokeWidth={2.5} />
                ) : guidance?.arrowDirection === "left" ? (
                  <ArrowLeft size={13} strokeWidth={2.5} />
                ) : guidance?.arrowDirection === "right" ? (
                  <ArrowRight size={13} strokeWidth={2.5} />
                ) : (
                  <Sparkles size={13} strokeWidth={2.5} />
                )}
              </span>
              <span className="text-xs font-semibold tracking-wide text-white">
                {previewCoaching.headline}
              </span>
            </div>
            {previewPresentation.coachingEmphasis === "full" &&
              previewCoaching.detail.length > 0 && (
                <p className="text-[10px] leading-tight text-white/80">
                  {previewCoaching.detail}
                </p>
              )}
          </div>
        </div>
      )}

      {/* LOOKS mirror — the rebuilt strip: swatch tiles that show the look,
          a strength track that opens on a re-tap of the active tile, and the
          two honesty lines. Same rules, same copy source, same matrices as
          the device control. */}
      {filterPanelOpen && filter !== "original" && (
        <div className="relative z-10 flex justify-center pb-1">
          <div className="flex items-center gap-2 rounded-full px-3 py-1" style={{ backgroundColor: "rgba(0,0,0,0.45)" }}>
            <span className="min-w-[74px] text-[10px] font-semibold text-white">
              {previewStatusCopy.filterStrengthValue(filterIntensity)}
            </span>
            <input
              type="range"
              min={FILTER_INTENSITY_MIN}
              max={FILTER_INTENSITY_MAX}
              step={FILTER_INTENSITY_STEP}
              value={filterIntensity}
              aria-label={`${previewStatusCopy.filterName(filter)} — ${previewStatusCopy.filterStrengthTitle}`}
              onChange={(event) => {
                const next = clampFilterIntensity(Number(event.target.value));
                setFilterIntensity(next);
                pushLog("info", "Camera", `look strength → ${next}%`);
              }}
              className="h-1 w-[150px] cursor-pointer accent-current"
              style={{ color: colors.primary }}
            />
            <button
              onClick={() => {
                setFilterIntensity(FILTER_INTENSITY_DEFAULT);
                pushLog("info", "Camera", "look strength → 100% (reset)");
              }}
              disabled={filterIntensity === FILTER_INTENSITY_DEFAULT}
              className="cursor-pointer text-[10px] font-bold disabled:cursor-default"
              style={{
                color:
                  filterIntensity === FILTER_INTENSITY_DEFAULT
                    ? "rgba(255,255,255,0.6)"
                    : colors.primary,
              }}
            >
              {previewStatusCopy.filterReset}
            </button>
          </div>
        </div>
      )}
      <div className="relative z-10 flex gap-2 overflow-x-auto px-3 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {CAMERA_FILTER_IDS.map((f) => {
          const selected = filter === f;
          const badge = selected ? filterIntensityBadge(f, filterIntensity) : null;
          const swatchOpacity =
            selected && filterSupportsIntensity(f)
              ? 0.4 + 0.6 * filterStrength(filterIntensity)
              : 1;
          const [from, to] = filterSwatchGradient[f];
          return (
            <button
              key={f}
              onClick={() => {
                if (selected) {
                  if (filterSupportsIntensity(f)) setFilterPanelOpen((open) => !open);
                  return;
                }
                setFilter(f);
                setFilterIntensity(FILTER_INTENSITY_DEFAULT);
                setFilterPanelOpen(filterSupportsIntensity(f));
                pushLog("info", "Camera", `look → ${f} (100%)`);
              }}
              aria-pressed={selected}
              aria-label={previewStatusCopy.filterSummary(f, selected ? filterIntensity : FILTER_INTENSITY_DEFAULT)}
              className="flex w-14 shrink-0 cursor-pointer flex-col items-center gap-[3px] pv-press"
            >
              <span
                className="relative flex h-[52px] w-[52px] items-end justify-end overflow-hidden rounded-xl"
                style={{
                  borderColor: selected ? colors.primary : "rgba(255,255,255,0.18)",
                  borderWidth: selected ? 2 : 1,
                  borderStyle: "solid",
                }}
              >
                <span
                  className="absolute inset-0"
                  style={{
                    backgroundImage: `linear-gradient(135deg, ${from}, ${to})`,
                    opacity: swatchOpacity,
                  }}
                />
                {badge !== null && (
                  <span className="relative rounded-bl-md px-1 text-[9px] font-bold text-white" style={{ backgroundColor: "rgba(0,0,0,0.6)" }}>
                    {badge}
                  </span>
                )}
              </span>
              <span
                className="text-[9px] font-semibold"
                style={{ color: selected ? "#FFFFFF" : "rgba(255,255,255,0.6)" }}
              >
                {previewStatusCopy.filterName(f)}
              </span>
            </button>
          );
        })}
      </div>
      <div className="relative z-10 pb-2 text-center text-[9px] text-white/60">
        {previewStatusCopy.filterPreviewNote(filter) === ""
          ? previewStatusCopy.filterNote
          : `${previewStatusCopy.filterNote} · ${previewStatusCopy.filterPreviewNote(filter)}`}
      </div>

      {/* Bottom controls */}
      <div className="relative z-10 flex h-24 items-center justify-between px-6 text-white" style={{ backgroundImage: "var(--pv-scrim-bottom)" }}>
        <button
          onClick={() => setActiveTab("gallery")}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-md border-2 border-white pv-press"
          aria-label="Open gallery"
        >
          <GalleryIcon size={16} />
        </button>
        {/* Camera UX Part 3 mirror — THE SHUTTER STATES. Ready breathes,
            a hold sweeps a ring in the colour of the trigger that earned it,
            and "not ready" loses its fill instead of only its opacity. */}
        <span className="relative flex h-[4.6rem] w-[4.6rem] items-center justify-center">
          {previewPresentation.shutterRing === "ready" && (
            <span
              className="absolute h-[4.6rem] w-[4.6rem] animate-pulse rounded-full"
              style={{ backgroundColor: colors.success, opacity: 0.35 }}
            />
          )}
          {previewPresentation.shutterRing !== "none" && (
            <span
              className="absolute h-[4.4rem] w-[4.4rem] rounded-full transition-all duration-200"
              style={{
                background: `conic-gradient(${
                  previewPresentation.shutterRing === "hold-gesture"
                    ? colors.warning
                    : colors.success
                } ${
                  (previewPresentation.shutterRing === "ready"
                    ? 1
                    : Math.max(0, Math.min(1, Math.max(autoProgress, gestureProgress)))) * 360
                }deg, rgba(255,255,255,0.16) 0deg)`,
                mask: "radial-gradient(circle, transparent 58%, black 60%)",
                WebkitMask: "radial-gradient(circle, transparent 58%, black 60%)",
              }}
            />
          )}
          <button
            disabled={status !== "live"}
            onClick={beginCapture}
            className="relative flex h-16 w-16 cursor-pointer items-center justify-center rounded-full border-4 pv-press disabled:cursor-not-allowed"
            style={{
              borderColor:
                previewPresentation.shutterRing === "ready" ? colors.success : "#FFFFFF",
              opacity: status === "live" ? 1 : 0.45,
            }}
            aria-label="Capture photo"
            aria-disabled={status !== "live"}
          >
            <span
              className="rounded-full bg-white transition-all duration-200"
              style={{
                height: status === "live" ? "3rem" : "2.6rem",
                width: status === "live" ? "3rem" : "2.6rem",
                opacity: status === "live" ? 1 : 0.35,
              }}
            />
          </button>
        </span>
        <button
          onClick={() => {
            const next = facing === "rear" ? "front" : "rear";
            setFacing(next);
            pushLog("info", "Camera", `facing → ${next}`);
          }}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full pv-press"
          aria-label="Switch camera"
        >
          <Repeat2 size={22} />
        </button>
      </div>

      <button
        onClick={() => armCameraPose(null)}
        className="absolute left-3 top-16 z-10 cursor-pointer rounded-full bg-black/50 px-2.5 py-1 text-[9px] font-semibold text-white"
      >
        ← Change pose
      </button>

      {/* Gesture-gate readout mirror: the user must be able to tell "not
          recognised" from "recognising" from "that counted". Empty copy for
          idle/cooldown means this renders nothing most of the time. */}
      {countdownRemaining === null &&
        previewStatusCopy.gesturePhase(gesturePhase).length > 0 && (
          <div className="pointer-events-none absolute bottom-28 left-1/2 z-20 -translate-x-1/2">
            <span className="rounded-full bg-black/55 px-3 py-1 text-[10px] font-semibold text-white">
              {previewStatusCopy.gesturePhase(gesturePhase)}
              {gestureProgress > 0 ? ` · ${Math.round(gestureProgress * 100)}%` : ""}
            </span>
          </div>
        )}
      {countdownRemaining !== null && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/35">
          {/* Part 3 mirror — the countdown keeps the subject visible (35 %
              veil, not 60 %) and empties a dial once per second. */}
          <span className="relative flex h-40 w-40 items-center justify-center">
            <span
              className="absolute h-40 w-40 rounded-full"
              style={{
                background: `conic-gradient(${colors.success} ${
                  (countdownRemaining / Math.max(1, countdownStarted.current)) * 360
                }deg, rgba(255,255,255,0.16) 0deg)`,
                mask: "radial-gradient(circle, transparent 88%, black 90%)",
                WebkitMask: "radial-gradient(circle, transparent 88%, black 90%)",
              }}
            />
            <span className="text-7xl font-bold text-white">{countdownRemaining}</span>
          </span>
          <span className="mt-2 text-xs font-semibold text-white/85">
            {previewStatusCopy.countdownReason(countdownTrigger)}
          </span>
        </div>
      )}
      {processing && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-2 bg-black/60 text-white">
          <div className="h-6 w-6 animate-spin rounded-full border-2 border-white/30 border-t-blue-500" />
          <span className="text-xs font-semibold">{previewStatusCopy.processing}</span>
        </div>
      )}

      {/* Unit 16 — ModelLoadingOverlay mirror while the wasm model warms up */}
      {mlStatus === "loading" && capturedDataUrl === null && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60">
          <div className="flex w-44 flex-col items-center gap-1.5 rounded-2xl bg-white p-5 text-center pv-elev-3">
            <div
              className="h-7 w-7 animate-spin rounded-full border-[3px] border-blue-100 border-t-blue-600"
              style={{ borderTopColor: colors.primary }}
            />
            <p className="mt-1 text-lg font-semibold text-zinc-900">Loading AI...</p>
            <p className="text-[10px] text-zinc-500">Preparing pose detection</p>
          </div>
        </div>
      )}
      {mlStatus === "unavailable" && (
        <div className="absolute inset-x-3 top-[4.4rem] z-10 rounded-lg bg-black/60 px-3 py-2 text-center text-[9px] font-medium text-white/80">
          AI guidance unavailable on this runtime — camera fully functional
        </div>
      )}
    </div>
  );
}

function previewDateLabel(timestamp: number): string {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const date = new Date(timestamp);
  date.setHours(0, 0, 0, 0);
  const days = Math.round((today.getTime() - date.getTime()) / 86_400_000);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days > 1 && days < 7) return "This Week";
  return new Intl.DateTimeFormat(undefined, { month: "long", year: "numeric" }).format(date);
}

/* Unit 14 complete Gallery mirror: history, groups, detail actions. */
function GalleryMirror() {
  const {
    colors,
    previewGallery,
    deletePreviewPhoto,
    previewRecents,
    viewPreviewPose,
    armCameraPose,
    setActiveTab,
    pushLog,
  } = usePreview();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = previewGallery.find((photo) => photo.id === selectedId) ?? null;
  const historyIds = Array.from(
    new Set([...previewGallery.map((photo) => photo.poseId), ...previewRecents]),
  );
  const history = historyIds
    .map((id) => getPoseById(id))
    .filter((pose): pose is Pose => pose !== null);
  const groups = previewGallery.reduce<Map<string, PreviewGalleryPhoto[]>>((map, photo) => {
    const label = previewDateLabel(photo.timestamp);
    map.set(label, [...(map.get(label) ?? []), photo]);
    return map;
  }, new Map());

  const sharePhoto = async (photo: PreviewGalleryPhoto) => {
    try {
      const blob = await fetch(photo.dataUrl).then((response) => response.blob());
      const file = new File([blob], "poseassist-photo.jpg", { type: "image/jpeg" });
      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: "PoseAssist photo" });
        return;
      }
      const link = document.createElement("a");
      link.href = photo.dataUrl;
      link.download = "poseassist-photo.jpg";
      link.click();
    } catch (error) {
      pushLog("error", "Gallery", `share failed → ${String(error)}`);
    }
  };

  if (selected !== null) {
    const pose = getPoseById(selected.poseId);
    return (
      <div className="relative flex h-full flex-col bg-black">
        <img src={selected.dataUrl} alt="App-captured photo" className="absolute inset-0 h-full w-full object-contain" />
        <div className="relative z-10 flex h-14 items-center justify-between px-3 text-white" style={{ backgroundImage: "var(--pv-scrim-top)" }}>
          <button onClick={() => setSelectedId(null)} className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full" aria-label="Close photo">×</button>
          <div className="flex gap-1">
            <button onClick={() => void sharePhoto(selected)} className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full" aria-label="Share photo"><ArrowRight size={18} /></button>
            <button
              onClick={() => {
                if (!window.confirm("Delete this photo from PoseAssist?")) return;
                deletePreviewPhoto(selected.id);
                setSelectedId(null);
              }}
              className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full"
              aria-label="Delete photo"
            >×</button>
          </div>
        </div>
        <div className="flex-1" />
        <div className="relative z-10 flex min-h-24 items-center justify-between gap-3 bg-black/60 px-4 py-3 text-white">
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-semibold">{new Date(selected.timestamp).toLocaleString()}</p>
            <p className="mt-1 truncate text-[9px] text-white/70">{pose?.title ?? "Pose unavailable"} · {selected.filterUsed}</p>
          </div>
          <button
            onClick={() => {
              armCameraPose(selected.poseId);
              setSelectedId(null);
              setActiveTab("camera");
            }}
            className="flex min-h-12 cursor-pointer items-center gap-1.5 rounded-xl px-3 text-xs font-semibold"
          ><Repeat2 size={16} /> Retake</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col" style={{ backgroundColor: colors.background }}>
      <div className="px-4 pb-3 pt-3">
        <p className="text-lg font-bold" style={{ color: colors.textPrimary }}>Gallery</p>
        <p className="text-[10px]" style={{ color: colors.textSecondary }}>
          {previewGallery.length === 0
            ? "Photos stay on this device"
            : `${previewGallery.length} saved photo${previewGallery.length === 1 ? "" : "s"} · device-only`}
        </p>
      </div>
      {previewGallery.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
          <div
            className="flex h-20 w-20 items-center justify-center rounded-full"
            style={{ backgroundColor: colors.backgroundSecondary }}
          >
            <GalleryIcon size={34} style={{ color: colors.textDisabled }} />
          </div>
          <p className="mt-4 text-sm font-semibold" style={{ color: colors.textPrimary }}>No photos yet</p>
          <p className="mt-1 text-[10px]" style={{ color: colors.textSecondary }}>
            Capture a guided pose and save it to see it here.
          </p>
          <button
            onClick={() => setActiveTab("camera")}
            className="mt-5 cursor-pointer rounded-xl px-5 py-2.5 text-xs font-semibold text-white"
            style={{ backgroundColor: colors.primary }}
          >
            Start Camera
          </button>
        </div>
      ) : (
        <div className="min-h-0 flex-1 overflow-y-auto pb-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {history.length > 0 && (
            <div className="pb-3">
              <p className="px-4 text-xs font-semibold" style={{ color: colors.textPrimary }}>Pose History</p>
              <div className="mt-2 flex gap-2 overflow-x-auto px-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                {history.map((pose) => (
                  <button
                    key={pose.id}
                    onClick={() => {
                      viewPreviewPose(pose.id);
                      armCameraPose(pose.id);
                      setActiveTab("camera");
                    }}
                    className="w-16 shrink-0 cursor-pointer text-left"
                  >
                    <PoseArt pose={pose} isDark={false} className="h-16" rounded="rounded-lg" iconSize={18} />
                    <p className="mt-1 line-clamp-1 text-[8px] font-semibold" style={{ color: colors.textPrimary }}>{pose.title}</p>
                  </button>
                ))}
              </div>
            </div>
          )}
          {Array.from(groups, ([label, photos]) => (
            <div key={label}>
              <p className="px-4 py-2 text-[10px] font-medium" style={{ color: colors.textSecondary }}>{label}</p>
              <div className="grid grid-cols-3 gap-1 px-1">
                {photos.map((photo) => (
                  <button key={photo.id} onClick={() => setSelectedId(photo.id)} className="cursor-pointer">
                    <img src={photo.dataUrl} alt="App-captured photo" className="aspect-square w-full rounded-lg object-cover" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Profile (Unit 19) ──────────────────────────────────────────────────── */

function ProfileMirror() {
  const {
    colors,
    themeMode,
    setThemeMode,
    authStatus,
    authUser,
    updateDisplayName,
    demoSignOut,
    setAuthReturnTab,
    navigatePreview,
    pushLog,
    favorites,
    toggleFavorite,
    previewGallery,
    previewRecents,
    clearRecents,
    openPose,
    setActiveTab,
    setSettingsOpen,
  } = usePreview();

  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState("");
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((cur) => (cur === msg ? null : cur));
    }, 2200);
  };

  const handleSaveName = () => {
    const trimmed = nameInput.trim();
    if (trimmed.length > 0) {
      updateDisplayName(trimmed);
      showToast("Display name updated");
    }
    setEditingName(false);
  };

  const modes: { key: ThemeMode; icon: typeof Sun; label: string }[] = [
    { key: "light", icon: Sun, label: "Light" },
    { key: "dark", icon: Moon, label: "Dark" },
    { key: "system", icon: SunMoon, label: "System" },
  ];

  const favoritePoses = favorites
    .map((id) => getPoseById(id))
    .filter((p): p is Pose => p !== null);

  const isAuthenticated = authStatus === "authenticated";

  return (
    <div
      className="relative h-full overflow-y-auto px-4 pb-6 pt-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      style={{ backgroundColor: colors.backgroundSecondary }}
    >
      <div className="flex items-center justify-between pb-2">
        <p className="text-lg font-bold" style={{ color: colors.textPrimary }}>
          Profile
        </p>
      </div>

      {/* Profile Card */}
      <div
        className="mt-2 rounded-2xl border p-4 pv-elev-1"
        style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
      >
        <div className="flex items-center gap-3.5">
          <div
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full text-lg font-bold text-white shadow-inner"
            style={{ backgroundColor: isAuthenticated ? colors.primary : colors.primaryLight, color: isAuthenticated ? "#ffffff" : colors.primary }}
          >
            {isAuthenticated ? (authUser?.displayName ?? "U")[0]?.toUpperCase() : <User size={24} />}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <p className="truncate text-sm font-bold" style={{ color: colors.textPrimary }}>
                {isAuthenticated ? authUser?.displayName : "Guest User"}
              </p>
              {isAuthenticated && (
                <button
                  onClick={() => {
                    setNameInput(authUser?.displayName ?? "");
                    setEditingName(true);
                  }}
                  className="flex h-6 w-6 cursor-pointer items-center justify-center rounded-full transition hover:bg-black/5 pv-press"
                  style={{ color: colors.textSecondary }}
                  aria-label="Edit display name"
                >
                  <Pencil size={12} />
                </button>
              )}
            </div>
            <p className="truncate text-[11px]" style={{ color: colors.textSecondary }}>
              {isAuthenticated ? authUser?.email : "Browse-only mode"}
            </p>
            <div className="mt-1.5 flex items-center gap-1">
              <span
                className="flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider"
                style={{
                  backgroundColor: isAuthenticated ? colors.primaryLight : colors.divider,
                  color: isAuthenticated ? colors.primary : colors.textSecondary,
                }}
              >
                {isAuthenticated ? <Check size={10} /> : null}
                {isAuthenticated ? `${authUser?.provider} Account` : "Guest Mode"}
              </span>
            </div>
          </div>
        </div>

        {/* Inline Edit Name Box */}
        {editingName && (
          <div className="mt-3.5 flex gap-2 border-t pt-3" style={{ borderColor: colors.divider }}>
            <input
              type="text"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              placeholder="Enter display name"
              autoFocus
              className="flex-1 rounded-lg border px-3 py-1.5 text-xs outline-none focus:ring-1"
              style={{
                backgroundColor: colors.backgroundSecondary,
                borderColor: colors.divider,
                color: colors.textPrimary,
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleSaveName();
                if (e.key === "Escape") setEditingName(false);
              }}
            />
            <button
              onClick={() => setEditingName(false)}
              className="cursor-pointer rounded-lg px-2.5 py-1 text-xs font-semibold"
              style={{ color: colors.textSecondary }}
            >
              Cancel
            </button>
            <button
              onClick={handleSaveName}
              className="cursor-pointer rounded-lg px-3 py-1 text-xs font-semibold text-white pv-press"
              style={{ backgroundColor: colors.primary }}
            >
              Save
            </button>
          </div>
        )}
      </div>

      {/* 3-Column Statistics Row */}
      <div
        className="mt-3 flex items-center justify-between rounded-2xl border p-3 pv-elev-1"
        style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
      >
        <div className="flex flex-1 flex-col items-center">
          <p className="text-base font-bold" style={{ color: colors.textPrimary }}>
            {favorites.length}
          </p>
          <p className="text-[10px] font-medium" style={{ color: colors.textSecondary }}>
            Favorites
          </p>
        </div>
        <div className="h-7 w-[1px]" style={{ backgroundColor: colors.divider }} />
        <div className="flex flex-1 flex-col items-center">
          <p className="text-base font-bold" style={{ color: colors.textPrimary }}>
            {previewGallery.length}
          </p>
          <p className="text-[10px] font-medium" style={{ color: colors.textSecondary }}>
            Photos
          </p>
        </div>
        <div className="h-7 w-[1px]" style={{ backgroundColor: colors.divider }} />
        <div className="flex flex-1 flex-col items-center">
          <p className="text-base font-bold" style={{ color: colors.textPrimary }}>
            {previewRecents.length}
          </p>
          <p className="text-[10px] font-medium" style={{ color: colors.textSecondary }}>
            Poses Tried
          </p>
        </div>
      </div>

      {/* Guest Login CTA Card */}
      {!isAuthenticated && (
        <div
          className="mt-3 flex flex-col gap-2.5 rounded-2xl border p-4 pv-elev-1"
          style={{ borderColor: colors.primary, backgroundColor: colors.primaryLight }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="flex h-9 w-9 items-center justify-center rounded-full"
              style={{ backgroundColor: colors.surface, color: colors.primary }}
            >
              <Sparkles size={18} />
            </div>
            <div>
              <p className="text-xs font-bold" style={{ color: colors.primary }}>
                Sign in to sync
              </p>
              <p className="text-[10px]" style={{ color: colors.textSecondary }}>
                Save favorites across devices & track photography stats
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setAuthReturnTab("profile");
              navigatePreview("auth");
            }}
            className="cursor-pointer rounded-xl py-2 text-xs font-semibold text-white pv-elev-1 pv-press"
            style={{ backgroundColor: colors.primary }}
          >
            Sign In or Create Account
          </button>
        </div>
      )}

      {/* Favorites Section */}
      <div className="mt-4">
        <div className="flex items-center justify-between pb-2">
          <div className="flex items-center gap-1.5">
            <Heart size={14} className="text-red-500 fill-red-500" />
            <p className="text-xs font-bold" style={{ color: colors.textPrimary }}>
              Favourite Poses
            </p>
          </div>
          <span
            className="rounded-full px-2 py-0.5 text-[9px] font-bold"
            style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
          >
            {favoritePoses.length}
          </span>
        </div>

        {favoritePoses.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center rounded-2xl border p-5 text-center pv-elev-1"
            style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
          >
            <div
              className="flex h-12 w-12 items-center justify-center rounded-full"
              style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
            >
              <Heart size={20} />
            </div>
            <p className="mt-2 text-xs font-bold" style={{ color: colors.textPrimary }}>
              No favorites yet
            </p>
            <p className="mt-1 max-w-[240px] text-[10px] leading-relaxed" style={{ color: colors.textSecondary }}>
              Browse the pose catalog and tap the heart icon on any pose to save it here.
            </p>
            <button
              onClick={() => setActiveTab("explore")}
              className="mt-3 cursor-pointer rounded-xl px-4 py-1.5 text-xs font-semibold text-white pv-press"
              style={{ backgroundColor: colors.primary }}
            >
              Explore Poses
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {favoritePoses.map((pose) => (
              <div
                key={pose.id}
                onClick={() => openPose(pose.id)}
                className="group relative cursor-pointer overflow-hidden rounded-xl border pv-press"
                style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
              >
                <div className="relative">
                  <PoseArt pose={pose} isDark={false} className="h-28" rounded="rounded-none" iconSize={26} />
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(pose.id);
                      showToast("Favorites updated");
                    }}
                    className="absolute right-1.5 top-1.5 flex h-7 w-7 cursor-pointer items-center justify-center rounded-full bg-black/40 text-red-400 backdrop-blur-sm pv-press"
                    aria-label="Toggle favorite"
                  >
                    <Heart size={14} className="fill-red-500 text-red-500" />
                  </button>
                </div>
                <div className="p-2">
                  <p className="line-clamp-1 text-[11px] font-bold" style={{ color: colors.textPrimary }}>
                    {pose.title}
                  </p>
                  <p className="text-[9px] capitalize" style={{ color: colors.textSecondary }}>
                    {pose.category}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Storage & Preferences Section */}
      <div className="mt-4">
        <div className="flex items-center gap-1.5 pb-2">
          <Database size={14} style={{ color: colors.primary }} />
          <p className="text-xs font-bold" style={{ color: colors.textPrimary }}>
            Storage & Preferences
          </p>
        </div>

        <div
          className="flex flex-col overflow-hidden rounded-2xl border pv-elev-1"
          style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
        >
          {/* Clear Image Cache */}
          <button
            onClick={() => {
              showToast("Image cache cleared");
              pushLog("info", "Storage", "temporary cache files cleared");
            }}
            className="flex cursor-pointer items-center justify-between border-b p-3 text-left pv-press-row"
            style={{ borderColor: colors.divider }}
          >
            <div className="flex items-center gap-2.5">
              <div
                className="flex h-8 w-8 items-center justify-center rounded-full"
                style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
              >
                <Trash2 size={15} />
              </div>
              <div>
                <p className="text-xs font-semibold" style={{ color: colors.textPrimary }}>
                  Clear Image Cache
                </p>
                <p className="text-[10px]" style={{ color: colors.textSecondary }}>
                  Frees up temporary cache memory
                </p>
              </div>
            </div>
            <ChevronRight size={14} style={{ color: colors.textDisabled }} />
          </button>

          {/* Clear Recent Poses */}
          <button
            onClick={() => {
              clearRecents();
              showToast("Recent poses cleared");
            }}
            className="flex cursor-pointer items-center justify-between border-b p-3 text-left pv-press-row"
            style={{ borderColor: colors.divider }}
          >
            <div className="flex items-center gap-2.5">
              <div
                className="flex h-8 w-8 items-center justify-center rounded-full"
                style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
              >
                <History size={15} />
              </div>
              <div>
                <p className="text-xs font-semibold" style={{ color: colors.textPrimary }}>
                  Clear Recent Poses
                </p>
                <p className="text-[10px]" style={{ color: colors.textSecondary }}>
                  {previewRecents.length > 0 ? `${previewRecents.length} in history` : "No history"}
                </p>
              </div>
            </div>
            <ChevronRight size={14} style={{ color: colors.textDisabled }} />
          </button>

          {/* Live Appearance Selector */}
          <div className="p-3">
            <p className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: colors.textDisabled }}>
              Appearance
            </p>
            <div
              className="mt-2 flex gap-1 rounded-xl p-1"
              style={{ backgroundColor: colors.backgroundSecondary }}
            >
              {modes.map(({ key, icon: Icon, label }) => {
                const active = themeMode === key;
                return (
                  <button
                    key={key}
                    onClick={() => setThemeMode(key)}
                    className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg py-1.5 text-[10px] font-semibold pv-press"
                    style={{
                      backgroundColor: active ? colors.surface : "transparent",
                      color: active ? colors.primary : colors.textSecondary,
                      boxShadow: active ? "0 1px 3px rgba(0,0,0,0.12)" : "none",
                    }}
                  >
                    <Icon size={12} /> {label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Settings Shortcut */}
      <div className="mt-3">
        <button
          onClick={() => {
            setSettingsOpen(true);
            pushLog("info", "Settings", "settings shortcut → /settings");
          }}
          className="flex w-full cursor-pointer items-center justify-between rounded-2xl border p-3.5 pv-elev-1 pv-press-row"
          style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
        >
          <div className="flex items-center gap-2.5">
            <div
              className="flex h-8 w-8 items-center justify-center rounded-full"
              style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
            >
              <Settings size={16} />
            </div>
            <div className="text-left">
              <p className="text-xs font-semibold" style={{ color: colors.textPrimary }}>
                Camera & App Settings
              </p>
              <p className="text-[10px]" style={{ color: colors.textSecondary }}>
                Flash, timer, voice & capture preferences
              </p>
            </div>
          </div>
          <ChevronRight size={14} style={{ color: colors.textDisabled }} />
        </button>
      </div>

      {/* Sign Out Button (Authenticated only) */}
      {isAuthenticated && (
        <button
          onClick={() => {
            demoSignOut();
            showToast("Signed out");
          }}
          className="mt-4 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-semibold pv-elev-1 pv-press"
          style={{ borderColor: colors.error, backgroundColor: colors.surface, color: colors.error }}
        >
          <LogOut size={13} /> Sign Out
        </button>
      )}

      {/* Feedback Toast */}
      {toastMsg && (
        <div className="absolute inset-x-6 bottom-4 z-30 rounded-xl bg-emerald-500 py-2.5 text-center text-xs font-semibold text-white shadow-lg animate-bounce">
          {toastMsg}
        </div>
      )}

      <p className="mt-4 text-center text-[9px] leading-relaxed" style={{ color: colors.textDisabled }}>
        Smart Photography Assistant · v1.0.0
      </p>
    </div>
  );
}

/* ── Settings (Units 20 + 21) ───────────────────────────────────────────── */

interface PickerOption<T> {
  readonly value: T;
  readonly label: string;
}

function SettingsMirror() {
  const {
    colors,
    cameraSettings,
    updateCameraSettings,
    resetCameraSettings,
    setSettingsOpen,
    themeMode,
    setThemeMode,
    pushLog,
    clearRecents,
    demoSignOut,
  } = usePreview();

  const [picker, setPicker] = useState<{
    key: string;
    title: string;
    options: readonly PickerOption<string | number>[];
    current: string | number;
  } | null>(null);
  const [infoPage, setInfoPage] = useState<"privacy" | "terms" | "about" | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg((cur) => (cur === msg ? null : cur)), 2200);
  };

  const flashOptions: readonly PickerOption<string>[] = [
    { value: "off", label: "Off" },
    { value: "auto", label: "Auto" },
    { value: "on", label: "On" },
  ];
  const timerOptions: readonly PickerOption<number>[] = [
    { value: 0, label: "Off" },
    { value: 3, label: "3 seconds" },
    { value: 5, label: "5 seconds" },
    { value: 10, label: "10 seconds" },
  ];
  const filterOptions: readonly PickerOption<string>[] = [
    { value: "original", label: "Original" },
    { value: "vivid", label: "Vivid" },
    { value: "warm", label: "Warm" },
    { value: "cool", label: "Cool" },
    { value: "bw", label: "B&W" },
  ];
  const thresholdOptions: readonly PickerOption<number>[] = [
    { value: 80, label: "80% Match" },
    { value: 85, label: "85% Match" },
    { value: 90, label: "90% Match (Recommended)" },
    { value: 95, label: "95% Match (Strict)" },
  ];
  const countdownOptions: readonly PickerOption<number>[] = [
    { value: 3, label: "3 seconds" },
    { value: 5, label: "5 seconds" },
  ];
  /* Unit 37: the mirror offers the SAME two instruction languages from the
     SAME shared table — the preview never authors its own language list. */
  const instructionLanguageOptions: readonly PickerOption<string>[] =
    INSTRUCTION_LANGUAGE_OPTIONS.map((option) => ({
      value: option.value,
      label: option.label,
    }));
  const themeOptions: readonly PickerOption<string>[] = [
    { value: "system", label: "System Default" },
    { value: "light", label: "Light" },
    { value: "dark", label: "Dark" },
  ];

  const openPicker = (
    key: string,
    title: string,
    options: readonly PickerOption<string | number>[],
    current: string | number,
  ) => setPicker({ key, title, options, current });

  const applyPicker = (value: string | number) => {
    if (picker === null) return;
    switch (picker.key) {
      case "flash":
        updateCameraSettings({ flashDefault: value as FlashDefault });
        showToast(`Flash set to ${value}`);
        break;
      case "timer":
        updateCameraSettings({ timerDefault: value as TimerDefault });
        showToast(value === 0 ? "Timer turned off" : `Timer set to ${value}s`);
        break;
      case "filter":
        updateCameraSettings({ filterDefault: value as FilterDefault });
        showToast(`Filter set to ${value}`);
        break;
      case "threshold":
        updateCameraSettings({ autoThreshold: value as AutoThreshold });
        showToast(`Auto threshold set to ${value}%`);
        break;
      case "countdown":
        updateCameraSettings({ countdownDuration: value as CountdownDuration });
        showToast(`Countdown set to ${value}s`);
        break;
      case "theme":
        setThemeMode(value as ThemeMode);
        showToast(`Theme set to ${value}`);
        break;
      case "instructionLanguage": {
        const language = resolveInstructionLanguage(value);
        updateCameraSettings({ instructionLanguage: language });
        pushLog(
          "info",
          "Settings",
          `instructionLanguage → ${language} (coaching band + speech)`,
        );
        showToast(
          language === "hi"
            ? "Coaching in हिंदी / Hinglish"
            : "Coaching in English",
        );
        break;
      }
    }
    setPicker(null);
  };

  const Tile = ({
    icon,
    title,
    value,
    onClick,
  }: {
    icon: React.ReactNode;
    title: string;
    value: string;
    onClick: () => void;
  }) => (
    <button
      onClick={onClick}
      className="flex w-full cursor-pointer items-center justify-between rounded-xl border p-3 text-left pv-press-row"
      style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
    >
      <div className="flex min-w-0 flex-1 items-center gap-2.5">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
          style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
        >
          {icon}
        </span>
        <span className="truncate text-xs font-semibold" style={{ color: colors.textPrimary }}>
          {title}
        </span>
      </div>
      <div className="flex shrink-0 items-center gap-1.5">
        <span
          className="rounded-full px-2 py-0.5 text-[10px] font-semibold"
          style={{ backgroundColor: colors.backgroundSecondary, color: colors.primary }}
        >
          {value}
        </span>
        <ChevronRight size={14} style={{ color: colors.textDisabled }} />
      </div>
    </button>
  );

  const SwitchTile = ({
    icon,
    title,
    desc,
    value,
    onToggle,
  }: {
    icon: React.ReactNode;
    title: string;
    desc: string;
    value: boolean;
    onToggle: () => void;
  }) => (
    <div
      className="flex items-center justify-between rounded-xl border p-3"
      style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
    >
      <div className="flex min-w-0 flex-1 items-center gap-2.5">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
          style={{ backgroundColor: colors.primaryLight, color: colors.primary }}
        >
          {icon}
        </span>
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold" style={{ color: colors.textPrimary }}>
            {title}
          </p>
          <p className="truncate text-[10px]" style={{ color: colors.textSecondary }}>
            {desc}
          </p>
        </div>
      </div>
      <button
        onClick={onToggle}
        role="switch"
        aria-checked={value}
        aria-label={`${title}, currently ${value ? "enabled" : "disabled"}`}
        className="relative h-6 w-11 shrink-0 cursor-pointer rounded-full transition"
        style={{ backgroundColor: value ? colors.primary : colors.divider }}
      >
        <span
          className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all"
          style={{ left: value ? "22px" : "2px" }}
        />
      </button>
    </div>
  );

  const SectionHeader = ({ icon, title }: { icon: React.ReactNode; title: string }) => (
    <div className="flex items-center gap-1.5 pb-2">
      <span style={{ color: colors.primary }}>{icon}</span>
      <p className="text-xs font-bold" style={{ color: colors.textPrimary }}>
        {title}
      </p>
    </div>
  );

  // Info pages (Unit 21)
  if (infoPage !== null) {
    const pageContent: Record<string, { title: string; body: string[] }> = {
      privacy: {
        title: "Privacy Policy",
        body: [
          "PoseAssist is built with privacy as a first principle. This page explains exactly what happens to your data.",
          "Photos never leave your device. Every photo you capture is stored locally in your device gallery using the system photo library. We never upload, transmit, or store your images on any server.",
          "Pose detection runs entirely on-device. MediaPipe pose tracking executes locally on your phone's processor. No camera frame, landmark, or body measurement is ever sent anywhere.",
          "Metadata-only sync. When you connect a Supabase account, only non-sensitive metadata syncs: your email address, display name, and favorite pose identifiers. This is protected by Row Level Security so only you can read it.",
          "No tracking or analytics. The app contains no third-party analytics SDKs, no advertising identifiers, and no behaviour tracking of any kind.",
          "Local storage. Your pose history, search history, capture preferences, and gallery metadata live in fast local storage on your device. You can clear all of it at any time from this Settings screen.",
          "Permissions. Camera access is requested only when you enter an active capture session, and the session is released the moment you leave. Gallery permission is requested only when you save a photo.",
        ],
      },
      terms: {
        title: "Terms of Service",
        body: [
          "By using Smart Photography Assistant (PoseAssist) you agree to the following terms.",
          "License. You receive a personal, non-transferable license to use the application for its intended purpose: guided photography posing assistance.",
          "Your content. All photographs you capture remain entirely your property and your responsibility. The app makes no claim on your images and cannot recover them if you delete them.",
          "Acceptable use. You agree not to use the app to create content that is unlawful, harmful, or that violates the rights of others, and not to attempt to reverse engineer, circumvent, or disrupt the pose-detection engine.",
          "No warranty. The application is provided \"as is\" without warranty of any kind. Pose guidance is assistive, not professional photography instruction; results depend on device capability, lighting, and framing.",
          "Limitation of liability. To the maximum extent permitted by law, the developers are not liable for any indirect, incidental, or consequential damages arising from use of the application.",
          "Changes. These terms may be updated as the application evolves. Continued use after an update constitutes acceptance of the revised terms.",
        ],
      },
      about: {
        title: "About",
        body: [
          "Smart Photography Assistant (PoseAssist) is an AI-guided posing coach for photographers and subjects.",
          "Choose from a curated library of 400 reference poses across 12 categories. On-device pose tracking draws a live skeleton over your camera viewfinder, computes a real-time match percentage against the reference pose, and tells you exactly which joint to adjust until you lock the pose.",
          "Capture manually, by holding an open palm to the camera, or automatically when your match percentage holds steady.",
        ],
      },
    };
    const page = pageContent[infoPage];
    return (
      <div
        className="h-full overflow-y-auto px-4 pb-6 pt-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        style={{ backgroundColor: colors.backgroundSecondary }}
      >
        <div className="flex items-center gap-2 pb-3">
          <button
            onClick={() => setInfoPage(null)}
            className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full border pv-press"
            style={{ borderColor: colors.divider, backgroundColor: colors.surface, color: colors.textPrimary }}
            aria-label="Back to settings"
          >
            <ArrowLeft size={15} />
          </button>
          <p className="text-base font-bold" style={{ color: colors.textPrimary }}>
            {page.title}
          </p>
        </div>

        {infoPage === "about" && (
          <div className="mb-4 flex flex-col items-center gap-2 rounded-2xl border p-5" style={{ borderColor: colors.divider, backgroundColor: colors.surface }}>
            <div className="flex h-16 w-16 items-center justify-center rounded-full" style={{ backgroundColor: colors.primaryLight }}>
              <Camera size={30} style={{ color: colors.primary }} />
            </div>
            <p className="text-sm font-bold" style={{ color: colors.textPrimary }}>Perfect Poses</p>
            <p className="text-[11px]" style={{ color: colors.textSecondary }}>Version 1.0.0 (Build 1)</p>
          </div>
        )}

        <div className="rounded-2xl border p-4" style={{ borderColor: colors.divider, backgroundColor: colors.surface }}>
          {page.body.map((paragraph, i) => (
            <p
              key={i}
              className="mb-3 text-[11px] leading-relaxed last:mb-0"
              style={{ color: colors.textSecondary }}
            >
              {paragraph}
            </p>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative h-full overflow-y-auto px-4 pb-6 pt-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      style={{ backgroundColor: colors.backgroundSecondary }}
    >
      {/* Header */}
      <div className="flex items-center gap-2 pb-3">
        <button
          onClick={() => setSettingsOpen(false)}
          className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-full border pv-press"
          style={{ borderColor: colors.divider, backgroundColor: colors.surface, color: colors.textPrimary }}
          aria-label="Close settings"
        >
          <ArrowLeft size={15} />
        </button>
        <p className="text-base font-bold" style={{ color: colors.textPrimary }}>
          Settings
        </p>
      </div>

      {/* ── Unit 20: Camera Section ── */}
      <div className="mt-2">
        <SectionHeader icon={<Camera size={14} />} title="Camera Preferences" />
        <div className="flex flex-col gap-2">
          <Tile
            icon={<Zap size={15} />}
            title="Flash Default"
            value={cameraSettings.flashDefault}
            onClick={() => openPicker("flash", "Flash Default", flashOptions, cameraSettings.flashDefault)}
          />
          <Tile
            icon={<Timer size={15} />}
            title="Timer Default"
            value={cameraSettings.timerDefault === 0 ? "Off" : `${cameraSettings.timerDefault}s`}
            onClick={() => openPicker("timer", "Timer Default", timerOptions, cameraSettings.timerDefault)}
          />
          <Tile
            icon={<Sparkles size={15} />}
            title="Filter Default"
            value={cameraSettings.filterDefault === "bw" ? "B&W" : cameraSettings.filterDefault}
            onClick={() => openPicker("filter", "Filter Default", filterOptions, cameraSettings.filterDefault)}
          />
          <SwitchTile
            icon={<Grid size={15} />}
            title="Grid Overlay"
            desc="Show 3x3 rule-of-thirds composition lines"
            value={cameraSettings.gridOverlayEnabled}
            onToggle={() => {
              updateCameraSettings({ gridOverlayEnabled: !cameraSettings.gridOverlayEnabled });
              showToast(cameraSettings.gridOverlayEnabled ? "Grid hidden" : "Grid shown");
            }}
          />
        </div>
      </div>

      {/* ── Unit 20: Intelligent Capture Section ── */}
      <div className="mt-5">
        <SectionHeader icon={<Target size={14} />} title="Intelligent Capture" />
        <div className="flex flex-col gap-2">
          <Tile
            icon={<Target size={15} />}
            title="Auto-capture Threshold"
            value={`${cameraSettings.autoThreshold}%`}
            onClick={() => openPicker("threshold", "Auto-capture Threshold", thresholdOptions, cameraSettings.autoThreshold)}
          />
          <SwitchTile
            icon={<Volume2 size={15} />}
            title="Voice Guidance"
            desc="Spoken posture directions (debounced 3s)"
            value={cameraSettings.voiceEnabled}
            onToggle={() => {
              updateCameraSettings({ voiceEnabled: !cameraSettings.voiceEnabled });
              showToast(cameraSettings.voiceEnabled ? "Voice off" : "Voice on");
            }}
          />
          <SwitchTile
            icon={<Hand size={15} />}
            title="Gesture Capture"
            desc="Hold open palm to trigger countdown"
            value={cameraSettings.gestureEnabled}
            onToggle={() => {
              updateCameraSettings({ gestureEnabled: !cameraSettings.gestureEnabled });
              showToast(cameraSettings.gestureEnabled ? "Gesture off" : "Gesture on");
            }}
          />
          {/* FINAL INTEGRATION PASS mirror — same tile the device now shows.
              Hardware keys are honestly unsimulated in a browser: the flag
              mirrors, the keys are not intercepted. */}
          <SwitchTile
            icon={<Volume1 size={15} />}
            title="Volume Key Shutter"
            desc="Take a photo with the volume keys while the camera is open"
            value={cameraSettings.volumeShutterEnabled}
            onToggle={() => {
              updateCameraSettings({ volumeShutterEnabled: !cameraSettings.volumeShutterEnabled });
              showToast(cameraSettings.volumeShutterEnabled ? "Volume shutter off" : "Volume shutter on");
            }}
          />
          <Tile
            icon={<Timer size={15} />}
            title="Countdown Duration"
            value={`${cameraSettings.countdownDuration}s`}
            onClick={() => openPicker("countdown", "Countdown Duration", countdownOptions, cameraSettings.countdownDuration)}
          />
          <SwitchTile
            icon={<Bell size={15} />}
            title="Haptic Feedback"
            desc="Vibration on shutter press & countdown"
            value={cameraSettings.hapticEnabled}
            onToggle={() => {
              updateCameraSettings({ hapticEnabled: !cameraSettings.hapticEnabled });
              showToast(cameraSettings.hapticEnabled ? "Haptics off" : "Haptics on");
            }}
          />
        </div>
      </div>

      {/* ── Unit 21: System Section ── */}
      <div className="mt-5">
        <SectionHeader icon={<Settings size={14} />} title="System" />
        <div className="flex flex-col gap-2">
          <Tile
            icon={<Moon size={15} />}
            title="Theme"
            value={themeMode}
            onClick={() => openPicker("theme", "Theme", themeOptions, themeMode)}
          />
          {/* Unit 37 — a REAL setting in the mirror too: it writes the same
              `instructionLanguage` field the device build persists, and the
              camera mirror above reads it for both the coaching band and the
              simulated speech line. App chrome stays English. */}
          <Tile
            icon={<User size={15} />}
            title="Instruction Language"
            value={
              INSTRUCTION_LANGUAGE_OPTIONS.find(
                (option) => option.value === cameraSettings.instructionLanguage,
              )?.label ?? "हिंदी / Hinglish"
            }
            onClick={() =>
              openPicker(
                "instructionLanguage",
                "Instruction Language",
                instructionLanguageOptions,
                cameraSettings.instructionLanguage,
              )
            }
          />
          <Tile
            icon={<Lock size={15} />}
            title="Privacy Policy"
            value="Read"
            onClick={() => setInfoPage("privacy")}
          />
          <Tile
            icon={<CheckCircle2 size={15} />}
            title="Terms of Service"
            value="Read"
            onClick={() => setInfoPage("terms")}
          />
          <Tile
            icon={<Bell size={15} />}
            title="About"
            value="v1.0.0"
            onClick={() => setInfoPage("about")}
          />
          <Tile
            icon={<Heart size={15} />}
            title="Rate App"
            value="★"
            onClick={() => {
              showToast("Thank you! Store rating coming soon");
              pushLog("info", "Settings", "rate app tapped");
            }}
          />
          <button
            onClick={() => {
              clearRecents();
              demoSignOut();
              resetCameraSettings();
              showToast("All app data cleared");
              pushLog("warn", "Settings", "clear all data — recents, settings, session cleared");
            }}
            className="flex w-full cursor-pointer items-center gap-2.5 rounded-xl border p-3 text-left pv-press-row"
            style={{ borderColor: colors.error, backgroundColor: colors.surface }}
          >
            <span
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
              style={{ backgroundColor: "rgba(239,68,68,0.12)", color: colors.error }}
            >
              <Trash2 size={15} />
            </span>
            <div className="min-w-0">
              <p className="text-xs font-bold" style={{ color: colors.error }}>
                Clear All Data
              </p>
              <p className="text-[10px]" style={{ color: colors.textSecondary }}>
                Delete favorites, recents & settings
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* ── Unit 20: Reset to Defaults ── */}
      <button
        onClick={() => {
          resetCameraSettings();
          showToast("Settings restored to defaults");
        }}
        className="mt-5 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border py-2.5 text-xs font-semibold pv-elev-1 pv-press"
        style={{ borderColor: colors.error, backgroundColor: colors.surface, color: colors.error }}
      >
        <RotateCcw size={13} /> Reset to Defaults
      </button>

      <p className="mt-4 text-center text-[9px] leading-relaxed" style={{ color: colors.textDisabled }}>
        Settings persist locally and apply to the camera immediately.
      </p>

      {/* Picker Modal */}
      {picker !== null && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 p-5">
          <div
            className="w-full max-w-[300px] rounded-2xl border p-4"
            style={{ borderColor: colors.divider, backgroundColor: colors.surface }}
          >
            <p className="mb-3 text-sm font-bold" style={{ color: colors.textPrimary }}>
              {picker.title}
            </p>
            <div className="flex flex-col gap-1">
              {picker.options.map((opt) => {
                const selected = opt.value === picker.current;
                return (
                  <button
                    key={String(opt.value)}
                    onClick={() => applyPicker(opt.value)}
                    className="flex cursor-pointer items-center justify-between rounded-lg px-3 py-2.5 text-left pv-press"
                    style={{
                      backgroundColor: selected ? colors.primaryLight : "transparent",
                      color: selected ? colors.primary : colors.textPrimary,
                    }}
                  >
                    <span className="text-xs font-semibold">{opt.label}</span>
                    {selected && <Check size={14} />}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => setPicker(null)}
              className="mt-3 w-full cursor-pointer rounded-lg py-2 text-xs font-semibold"
              style={{ backgroundColor: colors.backgroundSecondary, color: colors.textSecondary }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Toast */}
      {toastMsg && (
        <div className="absolute inset-x-6 bottom-4 z-50 rounded-xl bg-emerald-500 py-2.5 text-center text-xs font-semibold text-white shadow-lg">
          {toastMsg}
        </div>
      )}
    </div>
  );
}

/* ── Tab shell (Unit 02) ────────────────────────────────────────────────── */

export function TabsMirror() {
  const { colors, activeTab, setActiveTab, authStatus, settingsOpen } = usePreview();
  const gated =
    (activeTab === "camera" || activeTab === "gallery") &&
    authStatus !== "authenticated";

  if (settingsOpen) {
    return (
      <div className="h-full" style={{ backgroundColor: colors.background }}>
        <SettingsMirror />
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col" style={{ backgroundColor: colors.background }}>
      <div className="flex-1 overflow-hidden">
        {activeTab === "explore" ? (
          <ExploreMirror />
        ) : activeTab === "home" ? (
          <HomeMirror />
        ) : gated ? (
          <GateCard tab={activeTab as "camera" | "gallery" | "profile"} />
        ) : activeTab === "profile" ? (
          <ProfileMirror />
        ) : activeTab === "camera" ? (
          <CameraMirror />
        ) : (
          <GalleryMirror />
        )}
      </div>
      {/* AppTabBar — top corners radius xl=20, divider, active primary · premium item 7: floating elevation, cast upward */}
      <div
        className="pv-elev-2-up flex shrink-0 rounded-t-[20px] border-t px-2 pb-2 pt-1.5"
        style={{
          borderColor: colors.divider,
          backgroundColor: colors.surface,
        }}
      >
        {TABS.map((tab) => {
          const Icon = TAB_ICONS[tab.key];
          const active = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="flex flex-1 cursor-pointer flex-col items-center gap-0.5 py-1.5 pv-press"
            >
              <Icon size={20} style={{ color: active ? colors.primary : colors.textSecondary }} />
              <span
                className="text-[9px] font-semibold"
                style={{ color: active ? colors.primary : colors.textSecondary }}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
