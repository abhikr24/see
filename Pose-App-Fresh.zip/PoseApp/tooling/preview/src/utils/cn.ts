/**
 * ⚠ PREVIEW MIRROR UTILITY — NON-PRODUCTION, NEVER PART OF THE APP BUILD.
 * Tailwind class helper left over from the starter template; not imported
 * anywhere. Kept in place (nothing is deleted) and clearly labeled.
 */
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
