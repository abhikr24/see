/**
 * ⚠ PREVIEW-ONLY Vite config — coding-environment tooling, NOT the app.
 * ----------------------------------------------------------------------
 * This config exists ONLY so the coding environment can render a browser
 * mirror of the React Native + Expo app (mobile/) while it is being built.
 * It is never imported by production code, never seen by Metro (the Expo
 * bundler watches mobile/ + shared/ only), and is never used by EAS or any
 * iOS/Android/Web production build. Deleting tooling/preview/ does not
 * affect the production application in any way.
 *
 * Invocation happens through the repo-root package.json scripts:
 *   npm run dev      → vite --config tooling/preview/vite.config.ts
 *   npm run build    → vite build --config tooling/preview/vite.config.ts
 *                      (emits the environment-served dist/index.html)
 */
import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig({
  // The preview app root is this folder — never the repository root.
  root: __dirname,
  plugins: [react(), tailwindcss(), viteSingleFile()],
  build: {
    // The coding environment serves <repo>/dist/index.html. This output is a
    // generated artifact (gitignored); it is NOT the production web build.
    outDir: path.resolve(__dirname, "../../dist"),
    emptyOutDir: true,
  },
});
