# Real-device fix report — why it didn't run, and what was changed

Date: 2026-10-25
Scope: make PoseAssist launch on a physical Android phone.

## Method

I unpacked the archive, read the boot path, the Android project, the native
modules, all build config and every `scripts/verify-*.mjs` gate, cross-checked
the pinned dependency versions against Expo SDK 57's `bundledNativeModules.json`
and the upstream `react-native-screens` issue tracker, and ran the project's own
gates. (A full `npm install` + Gradle build could not run here — the sandbox has
2 GB RAM and no Android SDK — so this is a static + configuration audit, not a
live device run. The changes below are all in files that are read at build time,
so they take effect on your next build.)

## Findings

### Finding 1 — Expo Go can never run this app (not fixable in code)
The app depends on custom compiled native code: the local `vision-camera-mlkit-pose`
Nitro module (Google ML Kit pose detection), `react-native-vision-camera` v5,
`react-native-nitro-modules`/`nitro-image`, `react-native-mmkv` v4,
`@shopify/react-native-skia`, `react-native-reanimated` v4 + `react-native-worklets`,
and the local `HardwareShutter` Expo module. Expo Go ships a fixed native runtime
and cannot load any of these. Therefore `npx expo start` → scan QR → **Expo Go**
is guaranteed to fail ("Something went wrong" / won't open). The app requires a
**development build** or a **release APK**.

### Finding 2 — the checked-in Android project built x86_64 only (the real bug)
```
android/gradle.properties   → reactNativeArchitectures=x86_64
android/app/build.gradle    → ndk { abiFilters "x86_64" }
plugins/withAndroidPhoneApk.js → defaulted to x86_64 for non-EAS (local) builds
```
x86_64 is the emulator ABI. A physical phone is **arm64-v8a**. An x86_64-only
APK cannot be installed on a real phone (`INSTALL_FAILED_NO_MATCHING_ABIS`), and
the project's own gate already flagged it:

```
$ node scripts/verify-final-installable-apk.mjs
FAIL: arm64-only architecture policy missing
```

This is why the Android Studio / OTG / terminal route never worked on the phone.

### Finding 3 — the "development" EAS profile was not a development client
`eas.json` had `"development": { "developmentClient": false, ... }`. That build
cannot be connected to `expo start`, and shows the dev-loader error surface. So
even the EAS "development" path could not produce a working QR workflow.

### Findings ruled out (checked, not broken)
- **Dependency versions** — all within Expo SDK 57's required ranges
  (`react-native` 0.86.3, `react-native-screens` ~4.26.0, `reanimated` 4.5.1,
  `worklets` 0.10.1, etc.). `~4.26.0` is the *safe* screens line — the 4.27.0
  regression that produces the exact `instanceHandle is null` / `topTransition*`
  churn seen in the device logs does not apply here.
- **Routes** — every `<Stack.Screen>` name resolves to a real file.
- **Boot chain** — `_layout.tsx` → `BootGateScreen` → `runStartup` is bounded
  and fail-safe; native modules are lazily `require()`d behind try/catch.
- **Version-mismatch / config drift** — none found.

## Changes made

1. `android/gradle.properties` — `reactNativeArchitectures=arm64-v8a` (was `x86_64`).
2. `android/app/build.gradle` — `abiFilters "arm64-v8a"` (was `"x86_64"`).
3. `plugins/withAndroidPhoneApk.js` — default ABI is now `arm64-v8a` for *every*
   build (EAS and local), override with `POSEASSIST_ANDROID_ABI` if you ever want
   an emulator-only build. This stops `expo prebuild` from silently restoring
   x86_64.
4. `package.json` — added `expo-dev-client ~57.0.20`; `package-lock.json` updated.
5. `eas.json` — the `development` profile is now a real dev client
   (`developmentClient: true`, debug APK). `release-apk` is unchanged.
6. `scripts/verify-release-readiness.mjs` — tolerates the standalone archive
   layout (no repo-root `shared/`), so the gate no longer crashes.
7. Added `HOW-TO-RUN-ON-DEVICE.md`.

All 12 project gates pass after these changes.

## What you must do next

Follow `HOW-TO-RUN-ON-DEVICE.md`. The short version, over your USB/OTG cable:

```bash
cd mobile
npm install
npx expo run:android
```

That builds an arm64 app for your phone and installs it directly. If anything
still fails, capture `adb logcat | grep -E "PoseAssistBoot|ReactNativeJS|FATAL|AndroidRuntime"`
and it will name the exact step — the boot path logs each checkpoint.
