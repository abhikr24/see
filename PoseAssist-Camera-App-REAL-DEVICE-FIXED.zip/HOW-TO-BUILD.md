# How to Build PoseAssist on Your Computer (Simple Steps)

This project was repaired on 2026-10-05. Here is the only guide you need.

## What was fixed

1. **Broken Gradle engine replaced.** The old `mobile/android` folder had a corrupt starter file (3.6 KB instead of ~46 KB). It was deleted and rebuilt fresh with standard Expo tools. The new one is complete.
2. **Duplicate code removed.** The project had two identical `shared/` folders. The extra copy at the root was deleted. The live one (`mobile/shared/`) is untouched.
3. **`.env` file created.** Copy of `.env.example` with empty values. The app runs in demo mode until you add your Supabase keys.

## Before you start (one-time setup)

Install these two free tools:

1. **Node.js** — from https://nodejs.org (choose the LTS version). This lets commands like `npm` work.
2. **Android Studio** — from https://developer.android.com/studio. This includes the Android SDK needed to build the app.

## Build steps

Open PowerShell (Windows) or Terminal (Mac/Linux) and run these commands one at a time, in order:

```bash
# 1. Go into the mobile folder
cd mobile

# 2. Install the app's dependencies (downloads libraries, takes a few minutes)
npm install

# 3. (Optional) Add your Supabase keys:
#    Open the file .env in a text editor and paste your two values.
#    Skip this to try demo mode first.

# 4. Build and run on your phone
#    - Plug in your Android phone
#    - On the phone: Settings → About phone → tap "Build number" 7 times
#      → then Developer options → turn ON "USB debugging"
npx expo run:android
```

The first build takes 10–20 minutes. Later builds are faster.

## If something goes wrong

Copy the FULL error message (right-click to select all in PowerShell) and send it to me. With the exact error text, the fix is usually one small change.

## Do NOT do these

- Do not run `npx expo prebuild --clean` again unless an expert tells you to — it would wipe the repaired `android` folder.
- Do not run the old `scripts/` "verify" or "repair" files. They are history only.
