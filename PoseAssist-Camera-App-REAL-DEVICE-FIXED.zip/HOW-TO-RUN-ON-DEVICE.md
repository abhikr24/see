# How to actually run PoseAssist on a real Android phone

This is the only guide you need to get the app running on a physical device.
Read the first section once — it explains why the way you have been trying
cannot work, no matter what is changed in the code.

---

## 1. Why the QR code / Expo Go will NEVER open this app

**This app cannot run inside Expo Go. This is not a bug — it is a hard
architectural limit.**

Expo Go is a pre-built app that contains a *fixed* set of native modules. It
can only run projects that use nothing beyond that fixed set. PoseAssist uses
its own compiled native code, which Expo Go simply does not contain:

| Native module | Why it needs custom native code |
|---|---|
| `vision-camera-mlkit-pose` | A local **Nitro** module (C++/Kotlin) wrapping Google ML Kit Pose Detection |
| `react-native-vision-camera` (v5) | Camera frame pipeline (Nitro/Fabric) |
| `react-native-nitro-modules` / `react-native-nitro-image` | Nitro runtime |
| `react-native-mmkv` (v4) | Nitro/JSI key-value store |
| `@shopify/react-native-skia` | Native 2D drawing for overlays/filters |
| `react-native-reanimated` (v4) + `react-native-worklets` | Native worklets runtime |
| `HardwareShutter` (local Expo module) | Volume-button shutter, injected into `MainActivity` |

Because of this, when you run `npx expo start` and scan the QR code, Expo Go
tries to load a project whose native dependencies it does not have. The result
is exactly what you see: it does not open, or it shows a "Something went wrong"
dev-loader screen. **No amount of source fixing will make Expo Go work.**
You need a **build of this app that contains its own native code** — either a
*development build* or a *release APK*.

---

## 2. The second, separate problem (now fixed): wrong CPU architecture

The checked-in Android project was building **x86_64 only**:

- `android/gradle.properties` → `reactNativeArchitectures=x86_64`
- `android/app/build.gradle` → `ndk { abiFilters "x86_64" }`
- `plugins/withAndroidPhoneApk.js` → defaulted to `x86_64` for local builds

x86_64 is the **emulator** architecture. A real phone is **arm64-v8a**. An
x86_64-only APK cannot even install on a real phone — Android rejects it with:

```
INSTALL_FAILED_NO_MATCHING_ABIS: Failed to extract native libraries, res=-113
```

This is why "Android Studio / OTG / terminal" never worked on the phone even
when the build itself succeeded. It has been fixed — every build now targets
`arm64-v8a` (see `FIX-REPORT-REAL-DEVICE.md`).

---

## 3. One-time setup on your PC

1. **Node.js** LTS (already have it — `node -v`).
2. **Android Studio** + Android SDK + platform-tools (`adb`).
3. **JDK 17 for Gradle.** This matters. JDK 24/25 breaks AGP's CMake/Prefab
   step (`A restricted method in java.lang.System has been called` →
   `GeneratePrefabPackages` failure). In Android Studio:
   *Settings → Build, Execution, Deployment → Build Tools → Gradle →
   Gradle JDK → select 17.*
4. On the phone: *Settings → About phone → tap "Build number" 7×*, then
   *Developer options → USB debugging ON*. Plug it in and **tap "Allow"** on
   the "Allow USB debugging?" prompt.

Confirm the PC sees the phone:

```bash
adb devices
# must print your device serial followed by  "device"  (not "unauthorized")
```

---

## 4. Run it — Path A (recommended, works over your USB/OTG cable)

This builds the native app and installs it straight onto the connected phone,
then wires it to the Metro dev server. No Expo Go involved.

```bash
cd mobile
npm install            # installs deps + regenerates the lockfile
npx expo run:android
```

- First build: 10–25 minutes. Later builds: seconds.
- When it finishes, the app opens on the phone by itself.
- Keep this terminal open (Metro). To reload JS, shake the phone or press `r`.
- If you change native config, re-run `npx expo run:android`.

To build an installable **release** APK locally (no Metro needed, runs
standalone — closest to a "real" app):

```bash
npx expo run:android --variant release
```

The APK lands at:
`mobile/android/app/build/outputs/apk/release/app-release.apk`

You can copy that `.apk` to the phone and install it directly.

---

## 5. Run it — Path B (Expo's cloud build → installable APK)

If you would rather not build locally:

```bash
npm install -g eas-cli
eas login
cd mobile
eas build --platform android --profile release-apk
```

This produces an `arm64-v8a` release APK you can download and install on the
phone. It runs on its own — **do not** run `expo start` alongside a release APK.

---

## 6. Run it — Path C (QR-code workflow, done correctly)

If you specifically want the scan-a-QR workflow, that is supported — but the
QR must be opened by a **development build of this app**, not Expo Go. A dev
client is now included in the project.

1. Build and install the development build once:
   ```bash
   npx expo run:android          # installs the dev build
   ```
   (or `eas build --platform android --profile development`)
2. Start the dev server:
   ```bash
   npx expo start --dev-client
   ```
3. Scan the QR **from inside the installed "Smart Photography Assistant" app**
   (or via `adb`), never from Expo Go.

---

## 7. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `INSTALL_FAILED_NO_MATCHING_ABIS` | APK built for the wrong CPU | Fixed here; if you still see it, run `cd android && ./gradlew clean` then rebuild |
| Expo Go: "Something went wrong" / won't open | Expo Go cannot load native modules | Use Path A/B/C above, not Expo Go |
| App installs, then blank/white | JS bundle not loading | For a dev build, ensure Metro is running; for a release APK, make sure it was built as release (bundle embedded) |
| `Unauthorized` from `adb devices` | RSA prompt not accepted | Unplug, replug, tap "Allow" on the phone |
| Gradle fails at CMake/Prefab with JDK warning | Gradle using JDK 24/25 | Set Gradle JDK to **17** |
| Stale build after config change | Old native artifacts cached | `cd android && ./gradlew clean` and `npx expo start --clear` |

### Seeing the real error on the device

```bash
adb logcat -c
# launch the app on the phone, then:
adb logcat | grep -E "PoseAssistBoot|ReactNativeJS|FATAL|AndroidRuntime|ANR"
```

The app logs boot checkpoints tagged `PoseAssistBoot` even in release builds.

---

## 8. Do NOT

- Do not run `npx expo start` and open the QR in **Expo Go**.
- Do not run `npx expo prebuild --clean` unless told to — it wipes the repaired
  `android/` folder.
- Do not run the old `scripts/*verify*` / `REPAIR-*.ps1` files as a "fix" —
  they are history, not repair steps.
