# Pose App — clean package

This is a clean repackaging of the current PoseAssist Android white-screen transition fix.

After extraction, the project root is `Camera App/mobile/`. The old `smart-camera-FINAL-TECHNICAL-COMPLETE-V12` directory name is intentionally not used as the project root.

The archive excludes `node_modules`, `.git`, and Expo cache directories. Application dependencies and source behavior are unchanged by this repackaging.

Extract this ZIP only into a new/empty destination; do not merge it into an existing project folder.
