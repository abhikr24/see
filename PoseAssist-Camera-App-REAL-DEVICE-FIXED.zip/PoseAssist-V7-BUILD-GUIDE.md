# PoseAssist V7 — Android Studio First, Stable Build Path

## 0. First run after extracting the ZIP

Open PowerShell in `mobile`:

```powershell
cd mobile
.\REPAIR-WRAPPER-FIRST.ps1
```

This is required for the supplied archive because its original Gradle wrapper JAR was
corrupted. The script keeps a backup and regenerates the official Gradle 9.3.1 wrapper
using a trusted local Gradle 9.3.1 installation/ZIP.

If you already have the working `gradle-9.3.1-bin.zip` in:

```text
C:\Users\<your-user>\Downloads\
```

the script will find it automatically.

## 1. JDK

Use **JDK 17** for Gradle/Android Studio.

Do not put a user-specific `org.gradle.java.home` path into the project. In Android Studio:

`Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK`

select a JDK 17 installation.

## 2. Install JavaScript dependencies

From `mobile`:

```powershell
npm install
```

The `postinstall` hook automatically applies the project's native C++ runtime guard.
It is safe to run repeatedly.

The guard fixes only the known CMake linker targets and never deletes source code.

## 3. Android Studio

Open:

```text
mobile\android
```

Let Gradle sync finish.

For the Pixel 10a x86_64 emulator, local prebuilds default to `x86_64`.

For a physical ARM64 phone, set:

```powershell
$env:POSEASSIST_ANDROID_ABI="arm64-v8a"
```

before running a local prebuild.

EAS Android builds remain arm64-only automatically.

## 4. First local run

From `mobile`:

```powershell
npx expo run:android
```

Expo may pass the emulator's x86_64 architecture explicitly.

## 5. If you need a direct targeted native check

From `mobile\android`:

```powershell
.\gradlew.bat :react-native-worklets:buildCMakeDebug --console=plain -PreactNativeArchitectures=x86_64
```

Then:

```powershell
.\gradlew.bat :react-native-reanimated:buildCMakeDebug --console=plain -PreactNativeArchitectures=x86_64
```

Then:

```powershell
.\gradlew.bat :react-native-vision-camera:buildCMakeDebug --console=plain -PreactNativeArchitectures=x86_64
```

These are diagnostic commands, not required for a normal run.

## 6. Release APK

After the Android Studio debug build is working:

```powershell
cd mobile
eas build --platform android --profile release-apk --non-interactive
```

The EAS profile keeps the release APK ARM64-oriented for modern physical Android phones.

## 7. Environment values

Create `.env` from `.env.example` and supply the three existing public Expo variables before
running the app. Do not put service-role secrets into `EXPO_PUBLIC_*` variables.

## 8. Final functional test

- [ ] Android Studio sync completes
- [ ] Debug app builds
- [ ] Pixel 10a emulator launches the app
- [ ] Welcome/onboarding appears
- [ ] Camera permission works
- [ ] Camera opens
- [ ] Live pose detection works
- [ ] Pose guidance works
- [ ] Photo capture works
- [ ] Hardware shutter works
- [ ] Release APK builds
- [ ] Release APK installs on an ARM64 Android phone

