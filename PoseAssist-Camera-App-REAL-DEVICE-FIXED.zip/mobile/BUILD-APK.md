# Smart Photography Assistant — Android APK build path

This archive is designed to work after a normal ZIP extraction. The production app is self-contained under `mobile/`; the previous dependency on the parent `../shared` directory has been removed from the Android build path. The original repo-level `shared/` remains intact as a mirror for the preview/tests.

## Windows extraction → APK

1. Extract the ZIP.
2. Open PowerShell/Command Prompt in the extracted `mobile` folder.
3. Use Node.js 22.13+.
4. Install dependencies:

```powershell
npm ci
```

5. Check the Expo project:

```powershell
npx expo-doctor
```

6. Regenerate Android from the current Expo config and local native modules:

```powershell
npx expo prebuild --platform android --clean
```

7. For a local debug APK, build it:

```powershell
cd android
.\gradlew.bat :app:assembleDebug
```

The APK is produced under `android/app/build/outputs/apk/debug/` when the local Android toolchain is installed.

## EAS APK

From the same `mobile` folder, sign in to Expo/EAS if needed and run the preview profile:

```powershell
npx eas-cli build --platform android --profile release-apk
```

The `release-apk` profile is explicitly configured for an installable APK. EAS performs its own clean dependency installation and Android build on its worker.

## Important

- Do not run the build from a random subfolder.
- Do not delete `native/vision-camera-mlkit-pose` or `modules/hardware-shutter`; both are real native features.
- Do not restore the old `@shared/* -> ../shared/*` mapping. The Android build now uses `mobile/shared` so a ZIP extraction without a Git repository cannot lose the production brain during EAS upload.
- The archive contains static release gates, but no honest release audit can claim an APK is verified until `npm ci`, Expo prebuild, Gradle, and the final EAS APK have actually completed.


## V4 release-build repair

The V3 EAS run completed native compilation, including the real `vision-camera-mlkit-pose` C++/Kotlin/Java work, but then failed at `:app:lintVitalAnalyzeRelease` because the V3 workaround had intentionally skipped `:vision-camera-mlkit-pose:bundleReleaseLocalLintAar`; the app lint phase then attempted to read the missing `local_aar_for_lint/release/out.aar`. V4 removes that self-defeating task-disabling workaround, scopes VisionCamera as an app-local `implementation` dependency, and keeps release APK assembly independent of the optional fatal-lint gate via `lint { checkReleaseBuilds = false }`.
