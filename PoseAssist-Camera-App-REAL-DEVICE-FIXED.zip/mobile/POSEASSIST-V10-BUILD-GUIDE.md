> **V7 IMPORTANT OVERRIDE:** This is the historical V10 guide. For the supplied V7-cleaned
> project, first run `..\REPAIR-WRAPPER-FIRST.ps1` from `mobile`, select JDK 17 in Android
> Studio, then follow `PoseAssist-V7-BUILD-GUIDE.md`. The V7 project also persists the
> native `c++_shared` linker repair automatically during `npm install`.

# PoseAssist V10 — Final Easy APK Build

## 1. Extract

Extract the ZIP.

You must see:

```text
smart-camera-FINAL-TECHNICAL-COMPLETE-V10
├── mobile
└── shared
```

Open PowerShell inside `mobile`.

---

## 2. Create `.env`

```powershell
copy .env.example .env
```

Open `mobile\.env` and put your existing 3 values:

```text
EXPO_PUBLIC_SUPABASE_URL=YOUR_VALUE
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_VALUE
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=YOUR_VALUE
```

Save.

---

## 3. Install packages

```powershell
npm install
```

Then:

```powershell
npm approve-scripts @shopify/react-native-skia
```

---

## 4. Git

Move to the ZIP's parent folder:

```powershell
cd ..
```

```powershell
git init
```

```powershell
git add .
```

```powershell
git commit -m "PoseAssist V10"
```

Back to `mobile`:

```powershell
cd mobile
```

---

## 5. Check EAS internet connection

```powershell
npm run eas:preflight
```

You must see:

```text
EAS preflight PASSED.
```

### If you see `ENOTFOUND api.expo.dev`

Do this first:

```powershell
nslookup api.expo.dev
```

Then:

```powershell
ipconfig /flushdns
```

Then test again:

```powershell
npm run eas:preflight
```

If it still fails, connect the PC to your phone hotspot and run the same preflight again.

**Do not run the EAS build until the preflight passes.**

---

## 6. Put your 3 public app variables on EAS

The previous command output showed that the EAS `preview` environment had **no** plain-text/sensitive variables. Your local `.env` is not a substitute for EAS cloud environment variables when the file is excluded from the build upload. Expo recommends configuring build variables in EAS environments. citeturn121818search0turn121818search1

Run:

```powershell
npm run eas:sync-public-env
```

You should see:

```text
EAS preview environment variables are configured.
```

These 3 values use the `EXPO_PUBLIC_` prefix and are intended for the client bundle; they are not service-role secrets. Expo notes that client-side values are readable in the app. citeturn121818search0

---

## 7. Build the real APK

```powershell
eas build --platform android --profile release-apk --non-interactive
```

V10 already contains the EAS project ID, so there should be no `Which account should own this project?` setup question.

The `release-apk` profile is configured to produce an installable Android APK. Expo documents `android.buildType: "apk"` and `distribution: "internal"` for this use case. citeturn903890search2

Keep PowerShell open until EAS says the build has been submitted.

After submission, you can minimize PowerShell while the cloud build runs.

---

## 8. Install

When the build says **finished**, open the APK link on your Android phone and install it.

Open **PoseAssist from the Android home screen**.

Do not use Expo Go for the final native-camera test.

---

## 9. Test

```text
[ ] App passes the PoseAssist startup screen
[ ] Welcome / onboarding appears
[ ] Permissions screen appears
[ ] Camera permission works
[ ] Media permission works
[ ] Main app opens
[ ] Explore works
[ ] Favorites works
[ ] Camera opens
[ ] Live pose detection works
[ ] Pose guidance works
[ ] Photo capture works
[ ] Hardware shutter works
```
