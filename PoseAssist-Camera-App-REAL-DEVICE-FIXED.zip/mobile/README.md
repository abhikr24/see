# Smart Photography Assistant

AI pose-guidance camera app. Pick a reference pose, get live body tracking
and guidance, match the pose, capture.

Built with **React Native + Expo SDK 57 + TypeScript (strict)** — one
codebase for **Android, iOS and Web**.

## Run it

```bash
# From the repository root (one workspace lockfile):
npm install
cd mobile
npx expo start   # scan QR for a real phone · press "w" for web
```

No configuration needed — the app runs in Demo Mode out of the box. To
connect a real backend, see **[ENV-SETUP.md](./ENV-SETUP.md)** (2 minutes:
paste two values into `.env`).

## Project structure

```
mobile/
├── app/                        # Expo Router (file-based routes)
│   ├── _layout.tsx             # Root: fonts (Inter), providers, theme bridge
│   └── (tabs)/                 # 5-tab shell: Home · Explore · Camera · Gallery · Profile
├── src/
│   ├── core/
│   │   ├── theme/              # useAppTheme() — L/D/System resolved to tokens
│   │   ├── constants/          # barrel re-exporting the shared brain
│   │   ├── storage/            # MMKV w/ transparent Expo Go + web fallbacks
│   │   └── utils/              # AppLogger
│   ├── shared/
│   │   ├── components/         # AppText, IconSymbol, AppTabBar, TabPlaceholder…
│   │   └── stores/             # Zustand stores (themeStore, authStore…), persisted
│   └── features/               # auth · poses · explore · camera · gallery…
│                               # (one folder per domain, filled by later units)
└── ../shared/                  # THE BRAIN — design tokens, types, constants,
                                # single source of truth for this app AND
                                # the web preview mirror (see repo root)
```

## Ground rules (from docs/)

- Design tokens only — never hardcoded colors/px (`../shared/theme`).
- Photos stay on-device, backend receives metadata only.
- MediaPipe pose tracking is on-device; no frames ever leave the phone.
- Unauthenticated = browse-only. Camera/favorites/stats require sign-in.
- TypeScript strict, no `any` shortcuts, functional components only.

## Progress

24 planned units are represented in code, tracked in
`docs/progress-tracker.md`. **Release certification is not complete**
(foundation, first-run flow, permissions, offline pose data, real/demo auth,
home, explore, search, pose detail, authenticated favorites, camera
foundation with live preview + controls, capture, processing, preview,
device-only save, complete Gallery, unified pose history & recents wiring,
MediaPipe pose detection with live skeleton overlay + match %,
real-time visual guidance directives, skeleton arrow indicators, color-coded
joints/bones, debounced voice guidance, stable-match auto capture, open-palm
gesture capture, the full Profile dashboard, the complete Settings suite,
typed global error handling, offline status, render-crash containment,
UI states system with Shimmer skeletons, canonical EmptyState widgets,
global success snackbar, lazy loading pagination, memory optimization,
and root preview build verification).

Before using this as a store release, read **[RELEASE-READINESS.md](./RELEASE-READINESS.md)**.
Native real-time MediaPipe, licensed pose reference media, Android/iOS EAS
builds, and physical-device QA remain open.
