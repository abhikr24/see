# Release Readiness — Honest Final Audit

Audit date: 2026. This document distinguishes implemented code from verified
production behavior. It overrides older progress notes that called the app
"production-ready" before native builds and device tests existed.

## Current Verdict

**Release candidate architecture, not yet a production-ready store binary.**

The catalog, navigation, auth architecture, local capture/save flow, favorites,
profile, settings, error handling, UI states, and preview build are implemented.
Supabase real-mode activation is automatic once both public values are present.

The following blockers prevent a responsible final-store certification:

1. **Native real-time MediaPipe is not implemented on Hermes.**
   `@mediapipe/tasks-vision` is a browser WebAssembly API. React Native's
   Hermes runtime does not provide that browser execution environment. The
   current Expo Camera adapter repeatedly calls `takePictureAsync` and passes a
   URI/base64 string into an API that expects an image/video source. This can
   demonstrate architecture and math, but it is not a working native 15fps
   landmark stream. It may contend with the shutter and consume excessive CPU,
   memory, battery, and temporary storage.
2. **Pose reference photography is absent.** All 400 catalog entries have
   `imageUrl`, `thumbnailUrl`, and `localAssetPath` set to `null`; the app shows
   category-themed abstract art. The generated per-category reference angles
   are not measurements of the named poses. A production pose-guidance product
   needs licensed reference media plus measured per-pose angles.
3. **No native build has been proven.** Android EAS, iOS EAS, TestFlight, Play
   internal testing, camera permissions, save/share, silent-mode speech,
   thermal behavior, and long-session memory have not been tested here.
4. **Store/legal operations are incomplete.** Rate App is intentionally a
   placeholder until store IDs exist. Privacy/Terms are product copy, not legal
   advice, and need owner/legal review. Store descriptions, screenshots,
   support URL, privacy URL, age rating, and account-deletion policy are not
   configured.
5. **Web is browse-first, not feature-equivalent.** The production Expo route
   explicitly shows “Camera not supported on web”; capture, MediaPipe guidance,
   and local photo save are unavailable there. The root Vite webcam page is a
   development preview mirror and is never bundled into the product.
6. **Account lifecycle is incomplete.** Email sign-in/sign-up exists, but a
   production user still needs forgot-password/reset-password and account
   deletion flows. App-store account policies must be satisfied before review.

## Real Backend Activation

Public values to paste into `mobile/.env`:

```text
EXPO_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=<Supabase anon/publishable key>
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=<optional Google OAuth web client ID>
```

Then:

1. Run `mobile/supabase_tables.sql` in Supabase SQL Editor.
2. Configure Email auth in Supabase.
3. Optional Google: enable the provider in Supabase and place the Google client
   secret in Supabase Dashboard only. Add `smartphotography://auth` and final
   web callbacks to Supabase's redirect allow-list.
4. Restart the development server or rebuild the binary. Expo public variables
   are embedded at build time, so changing keys in an installed store binary
   requires a new build/update, not only an app restart.

With valid values, **auth, session persistence, profiles, and favorites use
real Supabase automatically**. Photos and pose landmarks remain on-device.
No demo backend is used in production; missing production values fail closed.

Supabase keys do **not** fix the native MediaPipe blocker, supply pose images,
create signing certificates, or make a store build.

## Recommended Native Pose QA

The production path is a native camera frame processor, for example:

- `react-native-vision-camera`
- a maintained native MediaPipe Pose Landmarker frame-processor module
- its required worklet runtime
- bundled `pose_landmarker_lite.task`
- Expo development builds/EAS (not Expo Go)

This is a deliberate camera-stack migration, not a one-file patch. It must be
implemented and proven on physical Android and iOS devices before Units 16–18
can be called complete on mobile.

## Release Acceptance Checklist

- [x] Root preview production build succeeds.
- [x] Mobile dependency/purity/type gate exists (`scripts/verify-all.mjs`).
- [x] Supabase schema has RLS for profiles and favorites.
- [x] Production backend configuration fails closed instead of using mocks.
- [x] App and splash artwork exists; app config points to a valid PNG asset.
- [ ] Licensed pose reference images and measured angles supplied.
- [x] Native Android pose pipeline implemented with ML Kit + VisionCamera; physical-device QA still pending.
- [ ] Android development build succeeds and passes physical-device QA.
- [ ] iOS development build succeeds and passes physical-device QA.
- [ ] 30-minute camera thermal/memory/battery test passes on low/mid/high devices.
- [ ] Offline/online, permission denial, background/foreground, and incoming-call
      interruption tests pass on both mobile platforms.
- [ ] Supabase real-mode auth/profile/favorites tested with production-like RLS.
- [ ] Google OAuth tested on Android, iOS, and web (if enabled).
- [ ] Store/legal metadata and production signing completed.
- [ ] Password reset and in-app account deletion implemented and tested.
- [ ] Product owner decides whether web is browse-only or receives real camera
      and MediaPipe feature parity; store/website copy must state the result.

Do not mark the store release complete until every unchecked item is verified.
