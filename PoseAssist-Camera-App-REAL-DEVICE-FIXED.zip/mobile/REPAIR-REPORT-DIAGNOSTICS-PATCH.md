# Historical V6 report

This document records the earlier V6 investigation. The supplied V7 cleanup supersedes its
known-wrapper/path instructions. See `V7-BUILD-STABILITY-AUDIT.md` for the current state.

# Repair Report — Diagnostics Patch (this session)

## Honesty statement first
This session had **no terminal network access, no connected Android device,
and no `node_modules` installed** (offline sandbox). I could not run
`gradlew assembleRelease`, `tsc`, install dependencies, or reproduce the
white screen on a device. Everything below is either (a) verified by
directly reading the source, or (b) explicitly marked as unproven /
needs-device-data. I am not claiming "fixed" — this patch only removes the
single biggest obstacle to diagnosing the real bug: **silence**.

## Root cause status: NOT YET IDENTIFIED
No single root cause was proven this session. See risk list below.

## What was inspected (evidence gathered)
- `app/_layout.tsx`, `app/index.tsx` — root layout and entry, read in full.
- `src/features/onboarding/presentation/screens/BootGateScreen.tsx`,
  `domain/startupService.ts`, `data/bootState.ts` — read in full. All three
  are bounded (900ms/1200ms timeouts), lazy, and fail-safe. No infinite
  hang, no unresolved promise, no missing catch found here.
- `app/(tabs)/_layout.tsx` — tabs are lazy-mounted, theme/auth bootstrap is
  deferred to `useEffect`. No render loop found.
- `src/core/ml/useNativePoseFrameOutput.ts` — VisionCamera + worklets wiring
  for the camera tab. Fully lazy (`require()` inside try/catch), never
  touched on cold start. Confirms it is NOT part of the boot path.
- `native/vision-camera-mlkit-pose/android/.../VisionCameraMlkitPosePackage.kt`
  and generated `VisionCameraMlkitPoseOnLoad.kt` — native module static init
  is wrapped in try/catch; `System.loadLibrary` failure degrades pose
  detection instead of crashing. Since your own logcat showed
  `ReactNativeJS: Running "main"`, JS successfully started, which rules out
  a *pre-JS* native init hang as the cause of what you're seeing.
- `android/gradle.properties`, `AndroidManifest.xml` (all 3 merged
  manifests), `MainActivity.kt`, `MainApplication.kt` — read in full.
  Standard Expo-generated New-Architecture (Fabric) + Hermes setup.
  `newArchEnabled=true`, `hermesEnabled=true`, `edgeToEdgeEnabled=true`.
- `package.json` — dependency graph read in full (see risk list).
- All 12 `scripts/verify-*.mjs` gates were executed. All pass. **These are
  static/text checks written by previous sessions confirming their own past
  patches are still present in source — they cannot detect an ANR, a native
  crash, or a live render loop.** Passing them is not evidence the APK
  renders correctly on a device, exactly as this repo's own docs already
  say.
- `src/core/utils/logger.ts` — **this is the one confirmed, concrete defect
  found this session.** All logging (`AppLogger.info/warn/error`) is gated
  behind `if (__DEV__)`. A release APK always has `__DEV__ === false`, so
  every internal signal the app already generates — camera/ML pipeline
  errors, the boot redirect decision, anything the error boundary or the
  early-error-capture handler recorded — never reaches `adb logcat`. This is
  the most likely reason your test only ever showed `Running "main"` and
  nothing else useful.
- Public GitHub issue research: confirmed `uiautomator dump` ->
  `could not get idle state` is a generic artifact of any continuously
  animating screen (spinner, skeleton loader) and is not, by itself,
  evidence of an app bug. Also confirmed white-screen-on-release is a
  recurring, multi-cause category across the RN ecosystem (react-navigation
  version mismatches, codepush interference, icon config, etc.) — meaning
  there is no shortcut; it needs this project's own device evidence.

## Files changed (this session)
1. `src/core/utils/logger.ts`
   - Added `AppLogger.critical(message, error?)`: writes to the in-memory
     ring buffer (like every other level) **and always calls
     `console.warn`**, bypassing the `__DEV__` gate. Tagged
     `[PoseAssistBoot]` so it's greppable:
     `adb logcat | grep PoseAssistBoot`.
   - Why: this is the only way to get real evidence out of a release build
     without shipping a dev build or attaching a debugger.
2. `src/features/onboarding/presentation/screens/BootGateScreen.tsx`
   - Added `AppLogger.critical(...)` calls at: mount, first RAF /
     `SplashScreen.hideAsync` resolve/reject, watchdog fire, `runStartup`
     resolve (with elapsed ms and destination) / reject, and the moment the
     `<Redirect>` destination is set.
   - Why: this brackets the exact cold-start window your original report
     flagged as suspect. Next run's logcat will show precisely how far boot
     gets and how long each step took, even in a release APK.
3. `app/_layout.tsx`
   - `RootErrorBoundary.componentDidCatch` now also calls
     `AppLogger.critical(...)` with the error message and component stack,
     in addition to the existing `errorHandler` call.
   - Why: if the white screen is actually a caught render error (not a
     hang), this makes it visible in logcat instead of silently showing the
     recovery UI with no trace.

No other files were touched. No dependency was upgraded, downgraded,
removed, or added. No functionality was deleted. ML Kit and MediaPipe are
untouched (see below).

## Dependency changes
None.

## MediaPipe result
`@mediapipe/tasks-vision` is present in `package.json` and used only via a
dynamic `import()` inside `src/core/ml/handDetectorService.ts` (hand
detection), guarded and web-only per `metro.config.js` /
`mediapipeWebUnsupported.ts`. Confirmed NOT eagerly imported by any file on
the Android cold-start path. Not modified, not removed, per instructions.

## ML Kit result
Native ML Kit pose detection (`vision-camera-mlkit-pose`) confirmed intact,
untouched, and native init is exception-safe. Not modified, per
instructions.

## Tests actually run
- All 12 `scripts/verify-*.mjs` static gates: **PASS** (unchanged by this
  patch — re-ran after the edit to confirm no regression).
- `tsc --noEmit`: **could not run** — `node_modules/typescript` is not
  installed in this sandbox and there is no network access to install it.
  This is an environment limitation, not a code defect. **This must be run
  in your own environment before trusting the TypeScript is clean.**
- `gradlew :app:assembleRelease`: **not run** — no Android SDK/network in
  this sandbox.
- Physical device test: **not run** — no device attached to this sandbox.
  I am not claiming this fixes anything on a real device, because it
  hasn't been tested on one.

## Remaining blockers (must happen next, in order)
1. Run `npx tsc --noEmit` in your real environment to confirm this patch
   compiles clean.
2. Build the release APK and install it on the actual failing device.
3. Reproduce the white screen, then immediately run:
   `adb logcat | grep -E "PoseAssistBoot|ReactNativeJS|FATAL|AndroidRuntime"`
4. Send that output back. It will show one of three things, each pointing
   to a different next fix:
   - **No `PoseAssistBoot` lines at all** → the JS bundle never reaches
     `BootGateScreen`; the bug is native (bridge/Fabric init), not JS.
   - **Lines appear up to a point and then stop** → the bug is exactly at
     the last logged checkpoint (e.g. stuck between "watchdog fired" and
     the redirect actually mounting `/welcome` — likely a Stack/Screens
     Fabric issue).
   - **All boot lines complete normally, redirect fires, but the screen is
     still blank/white after that** → the bug is downstream, in
     `welcome.tsx` or the Stack navigator itself, not in BootGate/startup at
     all — the previous "V" fixes' navigation-churn theory should be
     re-opened with device evidence this time.
5. Only after step 4 gives real evidence should any further code change be
   made. Do not guess-fix the worklets/edge-to-edge/reanimated risk items
   below without device evidence — they are plausible, not proven.

## Unproven risk items for the next session to check (do NOT blind-fix)
- `react-native-worklets` (0.10.1) + `react-native-vision-camera-worklets`
  (5.2.3) as two separate worklet runtimes, wired manually in
  `useNativePoseFrameOutput.ts`. Only reachable from the Camera tab, so it
  cannot explain a cold-start white screen, but could explain "works, then
  breaks after navigating further."
- `edgeToEdgeEnabled=true` (gradle.properties) combined with
  `react-native-safe-area-context ~5.7.0` is a known category of
  continuous-relayout issue on some Android 14/15 OEM builds. Not confirmed
  present here.

## Addendum — follow-up session (this session)

### Honesty statement
Same environment limits as the previous session: **no adb, no Android SDK,
no emulator, no network.** I could not build, install, run, or capture
logcat. I did NOT declare this fixed. No dependency was touched, no
existing logic was changed. Root cause status is unchanged:
**NOT YET IDENTIFIED.**

### What this session did
A deeper static trace (not a verifier-script re-run) to try to either find
a code-level defect the previous session missed, or rule out candidates:
- Traced `startupService.ts` → confirmed it never touches Supabase/auth/
  network; MMKV-only with a 900ms timeout. Matches prior finding.
- Traced `(tabs)/_layout.tsx` auth/theme bootstrap → `useEffect`-deferred,
  try/caught, non-blocking. Even an unresolved promise here cannot blank
  the screen, since Tabs have already mounted by then.
- Read the Nitro-generated `VisionCameraMlkitPoseOnLoad.kt` in full →
  confirmed it only does `System.loadLibrary`, nothing eager or
  network-bound. Matches prior finding; ML Kit path is not the boot-time
  cause.
- Checked `android/app/build.gradle` → `minifyEnabled` defaults to `false`
  unless `-Pandroid.enableMinifyInReleaseBuilds=true` is explicitly passed
  on the build command. **Action for you:** confirm your actual release
  build command doesn't set this flag, or R8 stripping of Reanimated/
  TurboModule classes becomes a live candidate again (current
  `proguard-rules.pro` only keeps `com.swmansion.reanimated.**` and
  `com.facebook.react.turbomodule.**`, which is thin).
- Checked `gradle.properties` → `reactNativeArchitectures=arm64-v8a` only.
  **Action for you:** confirm the physical test device is arm64 (virtually
  all devices sold since ~2017 are); an armeabi-v7a-only device would
  crash/ANR immediately with no usable native libs.
- New candidate (weaker, unconfirmed): `EXPO_PUBLIC_SUPABASE_URL` /
  `EXPO_PUBLIC_SUPABASE_ANON_KEY` are inlined into the bundle at build
  time. If `.env` isn't present when your release bundle is actually built
  (differs by build method — plain `gradlew assembleRelease` vs
  `expo run:android --variant release` vs EAS), `isBackendConfigured`
  silently becomes `false` in release even though dev works. Traced this
  against the actual boot path above and **it cannot explain a boot-time
  white screen** — nothing on the critical path reads it before the first
  screen renders. Ruling it in or out for *later* screens still needs
  device evidence, so one more diagnostic line was added for it (see
  below), not a fix.

### Files changed (this session)
1. `src/features/onboarding/presentation/screens/BootGateScreen.tsx`
   - Added one `AppLogger.critical` call, via dynamic `import()`, logging
     `isBackendConfigured` at boot. No behavior change. Purpose: next
     logcat capture will show whether env vars actually made it into this
     build, closing off or confirming the candidate above in one pass
     instead of a second round-trip.

No other files touched. No dependency changed. No proguard/gradle change
made — those are flagged above as things for you to check on your end,
not blind-fixed, per instruction not to guess-fix without evidence.

### Tests actually run
Same as previous session: none that require a device, SDK, or network —
none are available in this sandbox. `tsc --noEmit` also not run (no
`node_modules`). This is an environment limitation on my end, not a
code claim.

### What actually has to happen next (unchanged in substance)
I cannot do this from here — there is no way around that with the tools
available to me. You (or a session with real device/network access) need
to:
```
cd mobile/android && ./gradlew assembleRelease
adb install -r app/build/outputs/apk/release/app-release.apk
adb logcat | grep -E "PoseAssistBoot|ReactNativeJS|FATAL|AndroidRuntime|ANR"
```
then reproduce the white screen and send back the output. That log now
answers two questions at once: which of the three original boot patterns
occurred, AND whether `Backend configured at boot` is `true` or `false`
in your actual release build. Only with that in hand should the next code
change be made.

## Addendum 2 — dependency-compatibility audit (this session, no device)

Closed off one of the "unproven risk items" above with real evidence
(package sources + upstream changelogs), rather than leaving it open:

- **`react-native-vision-camera-worklets` vs `react-native-worklets`:**
  confirmed NOT a duplicate/conflicting worklets runtime. VisionCamera V5's
  own `react-native-vision-camera-worklets` package is Margelo's
  replacement for the old `react-native-worklets-core`, built specifically
  to wire VisionCamera's frame processors to `react-native-worklets`
  (Reanimated 4's core runtime) — this is the intended, current pairing,
  per VisionCamera's own V5 announcement. Not a bug. Remove this from the
  risk list.
- **`react-native-reanimated@4.5.1` vs RN `0.86.3`:** Reanimated shipped
  `fix: Android ANR deadlock between CSS updates-registry lock and Fabric
  commit` and `fix: Freezing animations after bump to RN 0.86` in the
  **4.5.0** release (one version below what's pinned here). The pinned
  4.5.1 inherits both fixes. The specific ANR/freeze category you're
  chasing was a known, named, already-fixed bug in this exact dependency —
  and it's already fixed at the pinned version. Ruled out, not guessed.
- `react-native-worklets@0.10.1`: matches Reanimated's declared 0.10.x
  compatibility for the 4.4.x/4.5.x line (0.11.x support was only added in
  4.5.2). Correct pairing for what's pinned.

None of this required code changes — it's a version audit, and the
versions check out. Recorded here so a future session doesn't re-open
this exact question from zero.

### Where this leaves the investigation
Two sessions have now read the entire cold-start path, the native module
boundaries, the build config, and the dependency graph, cross-checked
against upstream sources, without finding a static defect. The honest
conclusion: the remaining candidates (native bridge/Fabric init stall on
this specific device/OEM, a runtime-only Stack/Screens edge case, GPU
driver behavior) are not distinguishable from each other by source
reading — they only differ in the one artifact neither session had:
`adb logcat` from the failing device. That is the actual, sole blocker,
not a gap in analysis effort.

## Addendum 3 — verifying an externally-supplied "evidence" document

A document was supplied claiming to summarize real `adb`/`dumpsys`
output plus a static-inspection checklist. Flagging plainly: the
"evidence" section (device symptoms, log excerpts) was prose narrative
with no actual timestamped log lines, formatted as an AI prompt template
("Act as a SENIOR... fetch the raw gist..."), not raw terminal output. It
was treated as **unverified** — none of it was taken on trust.

The "confirmed problems from static code inspection" section made
checkable claims about this actual codebase, which were verified
directly:

1. `eas.json`'s `development` profile is release-typed
   (`gradleCommand: ":app:assembleRelease"`, `developmentClient: false`)
   — **confirmed true**. There was genuinely no way to produce a debug
   build from this config.
2. Hard arm64-v8a lock — confirmed present, via
   `plugins/withAndroidPhoneApk.js`. Read the plugin in full: intentional,
   documented, applied consistently at both Gradle-property and
   `abiFilters` level. Not a defect.
3. Logger silent in release — confirmed partially true: the in-memory
   ring buffer (`AppLogger`'s `buffer`) already records every call
   regardless of `__DEV__`; only `console.*` output was gated. Strengthened
   below.
4. `android/` drifted from `app.json` config plugins — **checked and
   false**. Read all three plugin files
   (`withAndroidPhoneApk.js`, `withAndroidReleaseBuildFixes.js`,
   `withHardwareShutter.js`) against the committed `gradle.properties`,
   `app/build.gradle`, and `MainActivity.kt`. Every plugin's output matches
   what's checked in, byte-for-byte on the relevant markers. No drift.
5. V12.2 Fabric-transition patch — already confirmed present in Addendum
   1/2; the code comments in `app/_layout.tsx` cite real prior
   device-log evidence for it.
6. Duplicate `shared/` (repo root vs `mobile/shared/`) — confirmed still
   byte-identical (`diff -rq` returned no differences). `metro.config.js`
   only watches `mobile/shared/`. Confirmed harmless duplication, not a
   functional defect — it's dead repo weight, not a runtime cause.

Also read, because it was new territory the document raised and matches
the exact shape of a system-wide-ANR cause (a native key-event hook):
`modules/hardware-shutter/android/.../HardwareShutterBridge.kt`. Its
`dispatchKeyEvent` short-circuits with `if (!armed) return false` as its
literal first line — no allocation, no bridge call unless a camera screen
has explicitly armed it. Ruled out with evidence, not assumed safe.

### Files changed (this addendum)
1. `eas.json` — added a new `debug-diagnostic` build profile
   (`buildType: apk`, `gradleCommand: ":app:assembleDebug"`). The existing
   `development` profile was left untouched (unclear what else in your
   pipeline may reference it by name; renaming its behavior without
   knowing that is exactly the kind of blind change to avoid). This is a
   genuinely high-value addition: **a debug build shows JS errors as an
   on-screen red-box overlay directly on the device — no `adb`, no
   computer, no logcat needed to at least see whether the crash is a
   catchable JS error versus a native hang.** Build it with
   `eas build --profile debug-diagnostic --platform android`.
2. `src/core/utils/logger.ts` — `AppLogger.critical()` now also flushes
   the last 20 buffered log lines (previously silent in release) as
   context around the triggering line, bounded, no behavior change to
   anything else.

Neither change touches ML Kit, MediaPipe, dependency versions, or any
navigation/render logic. Both are additive observability/tooling fixes
for gaps the supplied document correctly identified — they are not, and
are not being presented as, a fix for the white screen/ANR itself.

### Still unresolved, unchanged
The root cause of the white screen/ANR remains unknown. The
debug-diagnostic profile is now the fastest available path to find out:
install that build, reproduce, and either the on-screen red-box shows a
catchable JS error (route it back here) — or the app still fails silently
in a debug build too, which would itself be strong evidence this is a
native/Fabric-level issue rather than a JS one, narrowing the next step
considerably.

## Addendum 4 — build environment fixes found during live setup (user's machine)

While walking the user through a real Windows install (Android Studio
"Quail" / 2026.1.4), two genuine, evidence-backed environment issues were
found and fixed. Neither is the white-screen/ANR root cause — both are
things that were blocking the build from running at all on this machine.

1. **Gradle daemon was running on JDK 24/25.** AGP's
   `GeneratePrefabPackages` task reads CMake configure output line-by-line
   and mis-parses the JVM's own
   `WARNING: A restricted method in java.lang.System has been called`
   notice (emitted by JDK 24+ under JEP 454's native-access restrictions)
   as a fatal CMake error, throwing
   `IllegalStateException` and failing
   `:react-native-worklets:configureCMakeDebug[arm64-v8a]`. This is a
   confirmed, widely-reported combination (AGP + JDK 24/25), not specific
   to this project. Fix: pinned the project's Gradle JDK to 17 via
   Android Studio's "Gradle JVM criteria" setting. Confirmed in the next
   log: CMake/Prefab configuration for every native module (Skia, Nitro
   modules, worklets, vision-camera, vision-camera-mlkit-pose) completed
   without error.
2. **`android/settings.gradle`** had no toolchain download repository
   configured, so Android Studio's own `updateDaemonJvm` convenience task
   (triggered when pinning the Gradle JDK above) failed with
   `Toolchain download repositories have not been configured`. Added
   Gradle's own official
   `org.gradle.toolchains.foojay-resolver-convention` plugin (v1.0.0) to
   the `plugins {}` block in `android/settings.gradle` — this is Gradle's
   documented fix for exactly this message.

Both changes are environment/tooling fixes, not app logic changes. Once
past these, the build reached full project configuration successfully
(all `Configure project` steps for every native module completed) for
the first time in this app's history across all sessions.

## Addendum 5 — pre-baked machine-specific fixes for a clean re-import

Everything discovered during the live Windows walkthrough (Addendum 4) is
now baked directly into this zip, so a fresh extract does not need any of
these manual edits repeated:

- `android/app/debug.keystore` — replaced (original was corrupted:
  binary bytes had been mangled into UTF-8 text at some prior stage,
  confirmed via `keytool -list` failure). Regenerated as a standard
  Android debug keystore (alias `androiddebugkey`, both passwords
  `android`), matching `android/app/build.gradle`'s `signingConfigs.debug`
  exactly. AGP auto-detects keystore format from file bytes, no
  `storeType` is set in build.gradle, so the regenerated PKCS12-format
  keystore works with no other change needed.
- `android/settings.gradle` — added
  `id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"`
  to the `plugins {}` block (fixes "Toolchain download repositories have
  not been configured").
- `android/gradle.properties` — added
  `org.gradle.java.home=C:/Users/ANIKET KUMAR/.gradle/jdks/eclipse_adoptium-17-amd64-windows.2`,
  pinning Gradle to JDK 17 explicitly rather than relying on the IDE's
  "Gradle JVM" setting alone (that setting did not reliably carry over to
  the actual daemon process across sync attempts on this machine — a
  stale/reused daemon kept picking up JDK 24/25 instead). This is
  specific to this one Windows machine (this exact JDK path); on a
  different machine this line should be removed or repointed.
- `android/gradle/wrapper/gradle-wrapper.properties` — `distributionUrl`
  repointed to `file:///C:/Users/ANIKET%20KUMAR/Downloads/gradle-9.3.1-bin.zip`
  (manually downloaded via browser after the direct network download from
  services.gradle.org repeatedly hit `SocketTimeoutException`). Also
  machine-specific: depends on that file still being present in that exact
  Downloads path.

**Known remaining defect, deliberately not fixed:**
`android/gradle/wrapper/gradle-wrapper.jar` is still corrupted (same
binary-mangled-to-text damage as the keystore was) — confirmed via
`unzip -t` failure and a bad ZIP central directory. This file is only
read when `gradlew`/`gradlew.bat` is invoked directly from a command
line. Android Studio's own IDE-embedded Gradle sync does not use it. As
long as all builds go through Android Studio's UI (Run button, Sync,
Try Again) rather than a terminal `gradlew` command, this defect has no
effect and was left alone rather than guessed at without a working
internet path to source a replacement jar.

**Still not touched, still unresolved:** the original white-screen/ANR
bug this project started with. Everything in this and the previous
addenda is build-environment repair, not app-logic repair — the point of
all of it is to reach a running debug build so that bug can finally be
observed with real logs, which still hasn't happened yet.
