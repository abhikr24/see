$ErrorActionPreference = "Stop"

$MobileRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$AndroidRoot = Join-Path $MobileRoot "android"
$WrapperDir = Join-Path $AndroidRoot "gradle\wrapper"
$WrapperJar = Join-Path $WrapperDir "gradle-wrapper.jar"
$ExpectedSha256 = "b3a875ddc1f044746e1b1a55f645584505f4a10438c1afea9f15e92a7c42ec13"
$GradleVersion = "9.3.1"

Write-Host "PoseAssist wrapper repair"
Write-Host "------------------------"
Write-Host "This repairs only the Gradle wrapper JAR. No source files are deleted."

function Test-WrapperJar {
    if (-not (Test-Path $WrapperJar)) { return $false }
    try {
        $hash = (Get-FileHash -Algorithm SHA256 $WrapperJar).Hash.ToLowerInvariant()
        return $hash -eq $ExpectedSha256
    } catch {
        return $false
    }
}

if (Test-WrapperJar) {
    Write-Host "Gradle wrapper JAR is already valid."
    exit 0
}

if (Test-Path $WrapperJar) {
    $backup = "$WrapperJar.corrupt-backup"
    Copy-Item $WrapperJar $backup -Force
    Write-Host "Backed up the existing invalid wrapper to:"
    Write-Host "  $backup"
}

$gradleExe = $null
$zipCandidates = @(
    (Join-Path $env:USERPROFILE "Downloads\gradle-$GradleVersion-bin.zip"),
    (Join-Path $env:USERPROFILE "Downloads\gradle-$GradleVersion-all.zip")
)

foreach ($candidate in $zipCandidates) {
    if (Test-Path $candidate) {
        $tempRoot = Join-Path $env:TEMP "poseassist-gradle-$GradleVersion"
        if (Test-Path $tempRoot) { Remove-Item $tempRoot -Recurse -Force }
        Expand-Archive -Path $candidate -DestinationPath $tempRoot -Force
        $candidateExe = Join-Path $tempRoot "gradle-$GradleVersion\bin\gradle.bat"
        if (Test-Path $candidateExe) {
            $gradleExe = $candidateExe
            break
        }
    }
}

if (-not $gradleExe) {
    $cmd = Get-Command gradle.bat -ErrorAction SilentlyContinue
    if ($cmd) { $gradleExe = $cmd.Source }
}

if (-not $gradleExe) {
    throw @"
No trusted Gradle $GradleVersion installation was found.

Put gradle-$GradleVersion-bin.zip in:
  $env:USERPROFILE\Downloads\

Then run this script again.
"@
}

Push-Location $AndroidRoot
try {
    & $gradleExe wrapper --gradle-version $GradleVersion --distribution-type bin
    if ($LASTEXITCODE -ne 0) {
        throw "Gradle wrapper generation failed with exit code $LASTEXITCODE."
    }
} finally {
    Pop-Location
}

if (-not (Test-WrapperJar)) {
    $actual = if (Test-Path $WrapperJar) {
        (Get-FileHash -Algorithm SHA256 $WrapperJar).Hash
    } else {
        "<missing>"
    }
    throw "Wrapper JAR was generated but checksum does not match. Actual: $actual"
}

Write-Host ""
Write-Host "SUCCESS: Gradle wrapper JAR is now valid and matches Gradle 9.3.1."
Write-Host "Checksum: $ExpectedSha256"
