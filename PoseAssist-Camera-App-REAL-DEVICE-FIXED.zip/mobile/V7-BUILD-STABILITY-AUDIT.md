# PoseAssist V7 — Build Stability Audit

This report records the project-level repairs made after reviewing the supplied V6 archive
and the complete native-build failures observed during the Windows/Android Studio session.

## Confirmed problems fixed

1. **Corrupt Gradle wrapper JAR**
   - `android/gradle/wrapper/gradle-wrapper.jar` in the supplied archive failed ZIP validation.
   - The archive is therefore not safe to use with Gradle Wrapper as-is.
   - A one-time `mobile/REPAIR-WRAPPER-FIRST.ps1` is included. It preserves the bad JAR as
     `gradle-wrapper.jar.corrupt-backup`, uses a trusted Gradle 9.3.1 installation/ZIP to
     regenerate the wrapper, and verifies the official Gradle 9.3.1 wrapper-JAR SHA-256.
   - The wrapper distribution URL is now portable and points to `services.gradle.org` with
     the official Gradle 9.3.1 distribution checksum.

2. **Machine-specific JDK path**
   - Removed `org.gradle.java.home=C:/Users/...` from tracked `android/gradle.properties`.
   - The project now documents the JDK 17 requirement without binding the repository to one
     Windows user's home directory.
   - Android Studio should use JDK 17; `JAVA_HOME` may also point to JDK 17.

3. **Native C++ runtime linker failures**
   - The observed failures in Worklets, VisionCamera and Reanimated all stopped at the final
     C++ link step with missing `__cxa_*` and `std::__ndk1::*` symbols.
   - The targeted fixes were proven by successful x86_64 builds for:
     - `react-native-worklets`
     - `react-native-vision-camera`
     - `react-native-reanimated`
   - NitroModules and NitroImage received the same explicit runtime linkage.
   - The app-local `vision-camera-mlkit-pose` CMake target was also updated to link
     `c++_shared`, so the custom native module does not become the next latent linker failure.
   - The important V7 change is persistence: `scripts/patch-native-cpp-runtime.mjs` runs on
     `npm install`/`npm ci` and idempotently inserts `c++_shared` only into the affected CMake
     target blocks. It does not delete or replace application/native source code.

4. **Android Studio emulator architecture mismatch**
   - The app previously hard-coded `abiFilters "arm64-v8a"` while local development is being
     performed on an x86_64 emulator.
   - The app module now follows the `reactNativeArchitectures` Gradle property.
   - The Expo plugin defaults local prebuilds to `x86_64` and EAS Android builds to `arm64-v8a`.
   - Set `POSEASSIST_ANDROID_ABI=arm64-v8a` before a local prebuild when deliberately targeting
     a physical ARM64 phone.

## Intentionally preserved

No application screens, navigation, ML Kit logic, camera logic, hardware-shutter logic,
Supabase logic, assets, or existing native module source was deleted.

The existing Gradle worker serialization remains because it was added after a documented
Prefab/AAR transform-cache concurrency failure. It can be optimized later after a clean build
has been reproduced.

The existing Expo config plugins and release-lint workaround were preserved.

## Known first-run requirement

Because the supplied archive contains a corrupt wrapper JAR and no second valid copy of that
binary, the first step after extraction is:

```powershell
cd mobile
.\REPAIR-WRAPPER-FIRST.ps1
```

Only after that should Android Studio open/sync the `mobile/android` project.

## Verification order

1. Repair/verify Gradle wrapper.
2. Install Node dependencies; postinstall applies native C++ runtime guards.
3. Select JDK 17 in Android Studio.
4. Open `mobile/android`.
5. Sync.
6. Build/run the x86_64 debug variant on the Pixel 10a emulator.
7. Only after that succeeds, test the ARM64 release APK path.
