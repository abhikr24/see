# PoseAssist V9 Runtime Repair

## Actual runtime problem addressed

The repeated launch hang was centered on the cold-start path, not the Android APK build.

The previous boot path could reach the custom PoseAssist splash but still had too much work attached to the first React mount and used imperative navigation from the initial route. Several boot-adjacent modules also pulled the large shared barrel, which transitively loaded persisted/native app state earlier than necessary.

## V9 changes

- `app/index.tsx` remains a minimal boot entry.
- `BootGateScreen` now computes a destination in React state and renders Expo Router's declarative `<Redirect />` instead of imperative first-mount navigation.
- A 1200 ms watchdog forces `/welcome` if boot-state reading is slow or unavailable.
- The native splash is hidden as soon as the dependency-light BootGate has rendered; font loading no longer blocks the route tree.
- `app/_layout.tsx` no longer imports the MMKV-backed theme hook or auth store on the initial module path.
- Root theme reads only lightweight `shared/theme/colors` tokens.
- Auth/Supabase restoration is deferred until 1.2 seconds after root mount, after the initial route has had time to render.
- OfflineBanner and GlobalSnackBar are lazy-loaded after boot.
- `startupService.ts` and `bootState.ts` no longer import `AppLogger`, which previously pulled the large `@shared/index` barrel into the first-route dependency graph.
- `onboardingRepository.ts` imports `STORAGE_KEYS` from the exact constants module rather than the large shared barrel.
- Heavy tabs remain lazy.
- The legacy `/splash` route now declaratively returns to `/` instead of mounting another startup screen.

## Static dependency audit

The static import graph for `app/index.tsx` and `app/_layout.tsx` was inspected. The boot graph contains no static imports of:

- `react-native-mmkv`
- `@shared/index`
- `react-native-vision-camera`

The boot gate has no `useRouter`, `router.replace`, or `router.push` call.

## Preserved native/build features

The following V8 features/configuration were preserved:

- real ML Kit accurate pose detector
- VisionCamera 5.2.3
- Nitro/Nitrogen
- VisionCamera Worklets
- hardware shutter module
- arm64 phone APK policy
- compressed native `.so` packaging
- Gradle serialization/cache repair
- EAS `release-apk` profile
- existing icons/splash assets
- Supabase/auth code
- root `shared/` workspace

## Validation performed

- `node scripts/verify-v9-runtime.mjs` — PASS
- modified TypeScript/TSX files transpile successfully with TypeScript syntax validation — PASS
- static boot import graph audit — PASS (6 local boot modules scanned; no banned heavy native/shared-barrel imports)
- V8 → V9 archive comparison — performed; no V8 archive entry is intentionally removed
- ZIP reopen/test is performed before delivery

## Important limitation

A complete EAS cloud build and physical-device runtime test cannot be executed from this environment. The repair is therefore not described as physically verified until the V9 APK is built and installed on the phone.
