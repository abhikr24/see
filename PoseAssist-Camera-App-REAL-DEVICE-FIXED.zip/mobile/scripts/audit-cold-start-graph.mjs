#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const exts = ['.ts', '.tsx', '.js', '.jsx'];
const entries = [
  ['root', 'app/index.tsx'],
  ['welcome', 'src/features/onboarding/presentation/screens/WelcomeScreen.tsx'],
  ['onboarding', 'src/features/onboarding/presentation/screens/OnboardingScreen.tsx'],
  ['permissions', 'src/features/onboarding/presentation/screens/PermissionsScreen.tsx'],
];
const heavy = [
  ['MMKV', /react-native-mmkv/],
  ['Reanimated', /react-native-reanimated/],
  ['VisionCamera', /react-native-vision-camera/],
  ['Skia', /@shopify\/react-native-skia/],
  ['Supabase', /@supabase\//],
  ['PoseCatalog', /shared[\\/]data[\\/]poseCatalog\.ts$/],
  ['SharedBarrel', /shared[\\/]index\.ts$/],
  ['NativePose', /nativePosePlugin|poseFrameRuntime|useNativePoseFrameOutput/],
];

function resolve(spec, from) {
  let base;
  if (spec.startsWith('@/')) base = path.join(root, 'src', spec.slice(2));
  else if (spec.startsWith('@shared/')) base = path.join(root, 'shared', spec.slice('@shared/'.length));
  else if (spec === '@shared') base = path.join(root, 'shared', 'index');
  else if (spec.startsWith('.')) base = path.resolve(path.dirname(from), spec);
  else return null;
  if (fs.existsSync(base) && fs.statSync(base).isFile()) return base;
  for (const ext of exts) if (fs.existsSync(base + ext)) return base + ext;
  for (const ext of exts) {
    const index = path.join(base, `index${ext}`);
    if (fs.existsSync(index)) return index;
  }
  return null;
}

function importsIn(file) {
  const text = fs.readFileSync(file, 'utf8');
  const specs = [];
  const staticImport = /(?:^|\n)\s*import\s+(?!type\s)(?!\()(?:(?:.|\n)*?)\s+from\s+['"]([^'"]+)['"]/g;
  let m;
  while ((m = staticImport.exec(text))) specs.push(m[1]);
  const sideEffect = /(?:^|\n)\s*import\s*['"]([^'"]+)['"]/g;
  while ((m = sideEffect.exec(text))) specs.push(m[1]);
  return { specs: [...new Set(specs)], text };
}

function trace(entryRel) {
  const seen = new Set();
  const queue = [path.join(root, entryRel)];
  while (queue.length) {
    const file = queue.shift();
    if (seen.has(file) || !fs.existsSync(file)) continue;
    seen.add(file);
    const { specs } = importsIn(file);
    for (const spec of specs) {
      const target = resolve(spec, file);
      if (!target) continue;
      const rel = path.relative(root, target).replaceAll('\\', '/');
      for (const [label, pattern] of heavy) {
        if (pattern.test(rel)) return { seen, violation: label, file: target };
      }
      queue.push(target);
    }
  }
  return { seen, violation: null, file: null };
}

let total = 0;
for (const [name, entry] of entries) {
  const result = trace(entry);
  total += result.seen.size;
  if (result.violation) {
    console.error(`FAIL ${name}: static graph reaches ${result.violation} through ${path.relative(root, result.file)}`);
    process.exit(1);
  }
  console.log(`PASS cold-start graph: ${name} (${result.seen.size} project modules, no heavy native graph)`);
}
console.log(`COLD START GRAPH GATE: PASS (${total} entry graph visits)`);
