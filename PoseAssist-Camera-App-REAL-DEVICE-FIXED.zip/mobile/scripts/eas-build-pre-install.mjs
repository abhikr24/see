import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

if (process.env.EAS_BUILD_PLATFORM !== 'android') {
  console.log('[smart-camera] EAS pre-install: not Android; no Gradle cache action.');
  process.exit(0);
}

const gradleCaches = path.join(os.homedir(), '.gradle', 'caches');
let removed = 0;

if (fs.existsSync(gradleCaches)) {
  for (const version of fs.readdirSync(gradleCaches)) {
    if (!/^\d+\.\d+(?:\.\d+)?$/.test(version)) continue;
    const transformDir = path.join(gradleCaches, version, 'transforms');
    if (fs.existsSync(transformDir)) {
      fs.rmSync(transformDir, { recursive: true, force: true });
      removed += 1;
    }
  }
}

console.log(`[smart-camera] EAS pre-install: cleared ${removed} Gradle transform-cache directory(s).`);
