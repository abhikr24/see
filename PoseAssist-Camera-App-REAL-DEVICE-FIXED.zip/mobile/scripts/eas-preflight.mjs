import dns from 'node:dns/promises';
import https from 'node:https';

const host = 'api.expo.dev';

console.log('\nPoseAssist EAS preflight\n');
console.log(`Checking DNS for ${host}...`);
try {
  const addresses = await dns.resolve4(host);
  console.log(`PASS: ${host} resolves to ${addresses.join(', ')}`);
} catch (error) {
  console.error(`FAIL: DNS cannot resolve ${host}.`);
  console.error(`Reason: ${error?.code ?? error?.message ?? error}`);
  console.error('\nThis is a Windows/network/DNS problem, not an Android app build problem.');
  console.error('Do not rerun EAS repeatedly until this check passes.');
  process.exit(2);
}

console.log(`Checking HTTPS connectivity to https://${host}/...`);
await new Promise((resolve) => {
  const req = https.get({ host, path: '/', timeout: 10000 }, (res) => {
    console.log(`PASS: HTTPS connection reached ${host} (HTTP ${res.statusCode}).`);
    res.resume();
    resolve();
  });
  req.on('timeout', () => {
    console.error(`FAIL: HTTPS connection to ${host} timed out.`);
    req.destroy();
    process.exitCode = 3;
    resolve();
  });
  req.on('error', (error) => {
    console.error(`FAIL: HTTPS connection to ${host} failed.`);
    console.error(`Reason: ${error?.code ?? error?.message ?? error}`);
    process.exitCode = 3;
    resolve();
  });
});

if (process.exitCode) process.exit(process.exitCode);
console.log('\nEAS preflight PASSED. You can start the cloud build.\n');
