import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

const envPath = new URL('../.env', import.meta.url);
const text = fs.readFileSync(envPath, 'utf8');
const env = {};
for (const raw of text.split(/\r?\n/)) {
  const line = raw.trim();
  if (!line || line.startsWith('#')) continue;
  const i = line.indexOf('=');
  if (i <= 0) continue;
  const key = line.slice(0, i).trim();
  let value = line.slice(i + 1).trim();
  if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
    value = value.slice(1, -1);
  }
  env[key] = value;
}

const names = [
  'EXPO_PUBLIC_SUPABASE_URL',
  'EXPO_PUBLIC_SUPABASE_ANON_KEY',
  'EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID',
];

for (const name of names) {
  if (!env[name]) {
    console.error(`Missing ${name} in mobile/.env`);
    process.exit(2);
  }
}

console.log('Syncing the 3 client-public variables to the EAS preview environment...');
for (const name of names) {
  const easCommand = process.platform === 'win32' ? 'eas.cmd' : 'eas';
  const result = spawnSync(easCommand, [
    'env:set',
    '--name', name,
    '--value', env[name],
    '--environment', 'preview',
    '--visibility', 'plaintext',
  ], { stdio: 'inherit', shell: false });
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}
console.log('EAS preview environment variables are configured.');
