#!/usr/bin/env node
/**
 * PoseAssist native C++ runtime guard.
 *
 * React Native 0.86 + NDK 27.1 builds several native libraries with
 * -DANDROID_STL=c++_shared. In this project, the affected third-party
 * targets did not explicitly link libc++_shared, which produced final-link
 * failures such as __cxa_* and std::__ndk1::* being undefined.
 *
 * This script is intentionally idempotent:
 * - it only touches the listed CMakeLists.txt files;
 * - it only inserts c++_shared into the named target_link_libraries block;
 * - it never deletes source code or replaces an existing line;
 * - if a package changes its CMake layout, it fails loudly instead of
 *   guessing.
 *
 * It runs as npm's postinstall hook so a fresh install reproduces the
 * working native tree instead of relying on a manually edited node_modules.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const mobileRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const targets = [
  ['react-native-worklets', 'android/CMakeLists.txt', 'worklets'],
  ['react-native-reanimated', 'android/CMakeLists.txt', 'reanimated'],
  ['react-native-vision-camera', 'android/CMakeLists.txt', '${PACKAGE_NAME}'],
  ['react-native-nitro-modules', 'android/CMakeLists.txt', 'NitroModules'],
  ['react-native-nitro-image', 'android/CMakeLists.txt', '${PACKAGE_NAME}'],
];

function patchTarget(file, target) {
  if (!fs.existsSync(file)) {
    return { status: 'skip', target, reason: 'package not installed' };
  }

  const original = fs.readFileSync(file, 'utf8');
  if (original.includes('target_link_libraries') && original.includes('c++_shared')) {
    // Do not assume the existing c++_shared belongs to this target; verify below.
  }

  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const blockRe = new RegExp(
    `target_link_libraries\\s*\\(\\s*${escaped}(?=\\s)([\\s\\S]*?)\\)`,
  );
  const match = original.match(blockRe);

  if (!match) {
    throw new Error(`[native-cpp-runtime] Could not find target_link_libraries block for "${target}" in ${file}`);
  }

  const block = match[0];
  if (/\bc\+\+_shared\b/.test(block)) {
    return { status: 'ok', target, reason: 'already linked' };
  }

  const targetLine = new RegExp(`(target_link_libraries\\s*\\(\\s*${escaped})`);
  if (!targetLine.test(block)) {
    throw new Error(`[native-cpp-runtime] Found link block but could not identify insertion point for "${target}" in ${file}`);
  }

  const patchedBlock = block.replace(targetLine, '$1\n  c++_shared');

  const next = original.replace(block, patchedBlock);
  fs.writeFileSync(file, next, 'utf8');

  return { status: 'patched', target, reason: 'added c++_shared' };
}

const results = [];
for (const [pkg, relFile, target] of targets) {
  const file = path.join(mobileRoot, 'node_modules', pkg, relFile);
  results.push({ pkg, ...patchTarget(file, target) });
}

for (const result of results) {
  console.log(`[native-cpp-runtime] ${result.pkg}: ${result.status} (${result.reason})`);
}

console.log('[native-cpp-runtime] Native C++ runtime guard complete.');
