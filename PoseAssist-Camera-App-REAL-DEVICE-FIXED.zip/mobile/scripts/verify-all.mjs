#!/usr/bin/env node
/**
 * verify-all.mjs — the documented "run everything" compositor the root
 * `npm run verify` invokes. Restored to match its historical contract
 * (progress-tracker, Unit 30): dependency integrity → platform purity →
 * `tsc --noEmit` for the production app. Pure orchestration: each stage is
 * an existing checker, so this file owns no rules of its own.
 */
import { spawnSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const MOBILE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

function stage(label, command, args) {
  process.stdout.write(`\n▶ ${label}\n${'─'.repeat(60)}\n`);
  const result = spawnSync(command, args, { cwd: MOBILE_ROOT, stdio: 'inherit' });
  if (result.status !== 0) {
    process.stderr.write(`\n✗ ${label} failed (exit ${result.status}).\n`);
    process.exit(result.status ?? 1);
  }
  process.stdout.write(`✓ ${label}\n`);
}

stage('Dependency integrity (verify-deps)', process.execPath, [
  resolve(MOBILE_ROOT, 'scripts/verify-deps.mjs'),
]);
stage('Platform purity (verify-purity)', process.execPath, [
  resolve(MOBILE_ROOT, 'scripts/verify-purity.mjs'),
]);
stage('Architecture (verify-reference-architecture)', process.execPath, [
  resolve(MOBILE_ROOT, 'scripts/verify-reference-architecture.mjs'),
]);
stage('TypeScript (tsc --noEmit)', process.execPath, [
  resolve(MOBILE_ROOT, 'node_modules/typescript/bin/tsc'),
  '--noEmit',
]);

process.stdout.write('\n✓ verify-all: deps + purity + architecture + typecheck PASS.\n');
