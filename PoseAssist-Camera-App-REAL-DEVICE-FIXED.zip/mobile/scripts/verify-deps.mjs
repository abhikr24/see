#!/usr/bin/env node
/**
 * verify-deps.mjs — machine-enforced dependency completeness check.
 *
 * WHY THIS EXISTS (Unit 22 audit):
 * *   Real production code (OfflineBanner, CameraStatusRail, ttsService)
 *   imported packages that `mobile/package.json` did not declare. On a phone
 *   the app installs from mobile/package.json, so a bare import with no
 *   declared dependency is an uncompilable "module not found" at bundle time.
 * This script statically scans every bare (non-relative) import in
 * mobile/app and mobile/src and fails if any resolved package is not a
 * declared dependency or devDependency of mobile/package.json.
 *
 * HARD BOUNDARY (SDK 57 remediation): declarations are checked against
 * mobile/package.json ONLY. The repo-root package.json is coding-environment
 * preview tooling — a package resolving "by accident" from the root manifest
 * is a violation, not a fallback. Metro itself only resolves from
 * mobile/node_modules (see metro.config.js nodeModulesPaths).
 *
 * Exempt:
 *   · relative/path imports (./, ../, @/, @shared/) — no package lookup.
 *   · react / react-native — SDK runtime, always present.
 *   · Node builtins prefixed `node:` — runtime-provided.
 *
 * Run:      node mobile/scripts/verify-deps.mjs
 * Wired in: mobile/scripts/verify-all.mjs (runs purity + deps + typecheck).
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, extname, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { builtinModules, createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const MOBILE_ROOT = resolve(SCRIPT_DIR, '..');
const WORKSPACE_ROOT = resolve(MOBILE_ROOT, '..');

const MOBILE_PKG = JSON.parse(
  readFileSync(join(MOBILE_ROOT, 'package.json'), 'utf8'),
);

// mobile/package.json is the ONLY source of truth for production deps.
const declared = new Set([
  ...Object.keys(MOBILE_PKG.dependencies ?? {}),
  ...Object.keys(MOBILE_PKG.devDependencies ?? {}),
]);

const BUILTINS = new Set(builtinModules.map((m) => `node:${m}`));
const RUNTIME_EXEMPT = new Set(['react', 'react-native', 'react/jsx-runtime', 'react/jsx-dev-runtime']);
const SCAN_DIRS = [join(MOBILE_ROOT, 'app'), join(MOBILE_ROOT, 'src')];
const EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs']);

const IMPORT_RE = /(?:import|export)[\s\S]*?from\s+['"]([^'"]+)['"]|import\s*\(\s*['"]([^'"]+)['"]\s*\)/g;

function* walk(dir) {
  if (!existsSync(dir)) return;
  for (const entry of readdirSync(dir)) {
    if (entry === 'node_modules' || entry.startsWith('.')) continue;
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) yield* walk(full);
    else if (EXTENSIONS.has(extname(full))) yield full;
  }
}

function packageRootOf(spec) {
  if (spec.startsWith('@')) {
    const parts = spec.split('/');
    return `${parts[0]}/${parts[1]}`;
  }
  return spec.split('/')[0];
}

const violations = [];
const seen = new Map();

for (const dir of SCAN_DIRS) {
  for (const file of walk(dir)) {
    const source = readFileSync(file, 'utf8');
    let match;
    IMPORT_RE.lastIndex = 0;
    while ((match = IMPORT_RE.exec(source)) !== null) {
      const spec = match[1] ?? match[2];
      if (!spec) continue;
      if (spec.startsWith('.') || spec.startsWith('/') || spec.startsWith('~')) continue;
      if (spec.startsWith('@/') || spec.startsWith('@shared/')) continue;
      if (BUILTINS.has(spec) || spec.startsWith('node:')) continue;
      if (RUNTIME_EXEMPT.has(spec)) continue;
      const rootPkg = packageRootOf(spec);
      if (!seen.has(spec)) seen.set(spec, { rootPkg, files: new Set() });
      seen.get(spec).files.add(file);
    }
  }
}

for (const [spec, { rootPkg, files }] of seen) {
  if (declared.has(rootPkg)) continue;
  violations.push({
    spec,
    package: rootPkg,
    file: [...files][0],
    files: [...files].map((f) => f.replace(`${WORKSPACE_ROOT}/`, '')),
  });
}

if (violations.length > 0) {
  console.error('✗ Dependency completeness check failed.\n');
  console.error('These packages are imported by production code but are NOT declared');
  console.error('in mobile/package.json (the only production manifest):\n');
  for (const v of violations) {
    console.error(`  • ${v.spec}  (package: ${v.package})`);
    for (const f of v.files) console.error(`      imported by: ${f}`);
  }
  console.error('\nDeclare them in mobile/package.json.');
  process.exit(1);
}

console.log(`Dependency check passed — all ${seen.size} bare imports in mobile/app + mobile/src are declared.`);
