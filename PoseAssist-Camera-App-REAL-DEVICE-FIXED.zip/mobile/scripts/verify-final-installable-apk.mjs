import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const appJson = JSON.parse(read('app.json')).expo;
const eas = JSON.parse(read('eas.json'));
const pkg = JSON.parse(read('package.json'));

const failures = [];
const checks = [];
const ok = (label) => checks.push(`PASS: ${label}`);
const fail = (label) => failures.push(`FAIL: ${label}`);

const requiredFiles = [
  'app/index.tsx',
  'app/+native-intent.tsx',
  'app/+not-found.tsx',
  'app/_layout.tsx',
  'assets/icon/app-icon-store.png',
  'assets/splash/splash-icon.png',
  'plugins/withAndroidPhoneApk.js',
  'plugins/withAndroidReleaseBuildFixes.js',
];
for (const file of requiredFiles) fs.existsSync(path.join(root,file)) ? ok(`required file ${file}`) : fail(`missing ${file}`);

appJson.scheme === 'smartphotography' ? ok('custom scheme retained') : fail('custom scheme changed');
pkg.main === 'expo-router/entry' ? ok('Expo Router entry retained') : fail('package main is not expo-router/entry');

const p = eas.build['release-apk'];
if (!p) fail('release-apk profile missing');
else {
  p.developmentClient === false ? ok('release-apk developmentClient=false') : fail('release-apk must not be a development client');
  p.distribution === 'internal' ? ok('release-apk internal distribution') : fail('release-apk distribution must be internal');
  p.android?.buildType === 'apk' ? ok('release-apk buildType=apk') : fail('release-apk must build an APK');
  p.android?.gradleCommand === ':app:assembleRelease' ? ok('release-apk uses assembleRelease') : fail('release-apk must use assembleRelease');
}

const props = read('android/gradle.properties');
props.includes('reactNativeArchitectures=arm64-v8a') ? ok('arm64-only architecture policy is present') : fail('arm64-only architecture policy missing');
props.includes('expo.useLegacyPackaging=true') ? ok('native-library APK compression is enabled') : fail('native-library APK compression is not enabled');

const pluginList = JSON.stringify(appJson.plugins);
pluginList.includes('./plugins/withAndroidPhoneApk') ? ok('arm64 config plugin registered') : fail('arm64 config plugin not registered');
pluginList.includes('./plugins/withAndroidReleaseBuildFixes') ? ok('release build safety plugin retained') : fail('release build safety plugin missing');

const fix = read('plugins/withAndroidReleaseBuildFixes.js');
!fix.includes('tasks.matching') && fix.includes('checkReleaseBuilds = false') ? ok('old task-disable workaround is not present') : fail('unsafe release lint workaround remains');

const nativeGradle = read('native/vision-camera-mlkit-pose/android/build.gradle');
nativeGradle.includes('implementation project(":react-native-vision-camera")') ? ok('VisionCamera is implementation-scoped') : fail('VisionCamera dependency scope is wrong');
nativeGradle.includes('prefabPublishing') ? fail('prefabPublishing must not be enabled') : ok('prefabPublishing not present');
nativeGradle.includes('pose-detection-accurate') ? ok('accurate ML Kit dependency retained') : fail('accurate ML Kit dependency missing');

const index = read('app/index.tsx');
index.includes("BootGateScreen") && index.includes("return <BootGateScreen />") ? ok('root route directly renders lightweight boot gate') : fail('root route does not directly render lightweight boot gate');

console.log(checks.join('\n'));
if (failures.length) {
  console.error(failures.join('\n'));
  process.exit(1);
}
console.log('FINAL INSTALLABLE APK GATE: PASS');
