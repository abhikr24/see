#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const nativeGradle = path.join(root, 'native/vision-camera-mlkit-pose/android/build.gradle');
const plugin = path.join(root, 'plugins/withAndroidReleaseBuildFixes.js');
const appGradle = path.join(root, 'android/app/build.gradle');
const s = fs.readFileSync(nativeGradle, 'utf8');
const p = fs.readFileSync(plugin, 'utf8');
const a = fs.readFileSync(appGradle, 'utf8');
const required = [
  'implementation project(":react-native-vision-camera")',
  'namespace "com.margelo.nitro.visioncameramlkitpose"',
  'com.google.mlkit:pose-detection-accurate:18.0.0-beta5',
  "apply from: '../nitrogen/generated/android/VisionCameraMlkitPose+autolinking.gradle'",
  "apply from: './fix-prefab.gradle'",
];
for (const x of required) {
  if (!s.includes(x)) throw new Error(`Missing native release gate: ${x}`);
}
if (s.includes('api project(":react-native-vision-camera")')) throw new Error('VisionCamera must not be api-scoped');
if (p.includes('task.enabled = false')) throw new Error('Old local-lint task-disabling workaround still present');
if (!p.includes('checkReleaseBuilds = false')) throw new Error('Release lint safety plugin missing');
if (!a.includes('checkReleaseBuilds = false')) throw new Error('Checked-in app build missing release lint safety');
console.log('NATIVE RELEASE GATE: PASS');
console.log('VisionCamera dependency: implementation scope');
console.log('real ML Kit accurate pose dependency: PRESENT');
console.log('Nitrogen autolinking: PRESENT');
console.log('release APK is not blocked by the local lint AAR intermediate');
