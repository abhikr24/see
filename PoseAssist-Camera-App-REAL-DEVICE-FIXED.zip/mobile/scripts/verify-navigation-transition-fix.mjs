import fs from 'node:fs';

const root = fs.readFileSync('app/_layout.tsx', 'utf8');
const tabs = fs.readFileSync('app/(tabs)/_layout.tsx', 'utf8');
const failures = [];
const pass = (m) => console.log(`PASS ${m}`);
const fail = (m) => failures.push(`FAIL ${m}`);

root.includes("animation: 'none'") ? pass('root Stack animations disabled for Android stabilization') : fail('root Stack animation policy missing');
!root.includes("animation: 'fade'") ? pass('no root per-screen fade overrides remain') : fail('root fade override remains');
tabs.includes("animation: 'none'") ? pass('nested Tabs animations disabled for Android stabilization') : fail('nested Tabs animation policy missing');
!tabs.includes("animation: 'fade'") ? pass('nested Tabs fade animation removed') : fail('nested Tabs fade animation remains');

if (failures.length) {
  console.error(failures.join('\n'));
  process.exit(1);
}
console.log('NAVIGATION TRANSITION STABILITY GATE: PASS');
