#!/usr/bin/env node
/**
 * verify-purity.mjs — machine enforcement of the platform-purity rules.
 *
 * Scanned trees
 *   mobile/app, mobile/src  → must be pure React Native + Expo.
 *   shared/                 → must be platform-NEUTRAL TypeScript: no DOM,
 *                             and additionally no react-native imports, since
 *                             the same files are consumed by the web mirror.
 *
 * Reports file:line for every violation. Comments are stripped first, so the
 * rules themselves may be documented in prose without tripping the scanner.
 *
 * Run: cd mobile && npm run verify:purity
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, extname, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = fileURLToPath(new URL('.', import.meta.url));
const MOBILE_ROOT = join(SCRIPT_DIR, '..');
const REPO_ROOT = join(MOBILE_ROOT, '..');
const EXTENSIONS = new Set(['.ts', '.tsx']);

/** Rules applied to mobile/app + mobile/src (the real application). */
const NATIVE_RULES = [
  {
    name: 'HTML element',
    hint: 'use View / Text / Pressable / Image from react-native',
    pattern:
      /<\/?(div|span|p|img|input|button|a|h[1-6]|section|article|header|footer|main|nav|ul|ol|li|form|label|select|option|textarea|table|thead|tbody|tr|td|th|br|hr|iframe|canvas|video|audio|svg|picture|figure|small|strong|em)[\s/>]/,
  },
  {
    name: 'Web styling',
    hint: 'use StyleSheet.create() + shared/theme tokens',
    pattern: /className\s*=|style\s*=\s*["'`]|from\s+['"][^'"]+\.(css|scss|sass|less)['"]/,
  },
  {
    // NOTE: onFocus / onBlur / onKeyPress / onSubmitEditing are legitimate
    // React Native TextInput+Pressable props and are deliberately NOT listed.
    name: 'DOM event handler prop',
    hint: 'use onPress / onChangeText / onLongPress',
    pattern:
      /\bon(Click|DoubleClick|MouseDown|MouseUp|MouseEnter|MouseLeave|MouseOver|ContextMenu|DragStart|DragEnd|Drop|Input|Submit|KeyDown|KeyUp|Wheel)\s*=\s*[{"']/,
  },
  {
    name: 'DOM render / react-dom API',
    hint: 'the app renders through expo-router/entry, never a DOM root',
    pattern:
      /\b(ReactDOM\b|createRoot\s*\(|hydrateRoot\s*\(|createPortal\s*\(|flushSync\s*\(|dangerouslySetInnerHTML)/,
  },
  {
    // The lookbehind keeps React Native's own Alert.alert() legal while still
    // banning the bare browser globals alert()/confirm()/prompt().
    name: 'Browser global / storage API',
    hint: 'use RN Alert + the MMKV storage adapter; these do not exist on device',
    pattern:
      /\b(window|document)\s*\.|\blocalStorage\b|\bsessionStorage\b|\bnavigator\s*\.\s*(mediaDevices|clipboard|geolocation|userAgent)|(?<![.\w])(alert|confirm|prompt)\s*\(/,
  },
  {
    name: 'Web framework import',
    hint: 'routing is Expo Router only',
    pattern:
      /from\s+['"](next|next\/[^'"]*|react-router|react-router-dom|react-dom|react-dom\/[^'"]*|@vitejs\/[^'"]*|vite|tailwind-merge|clsx|lucide-react)['"]/,
  },
  {
    name: 'Hardcoded color literal',
    hint: 'use theme.colors.* or mediaColors.* from shared/theme',
    pattern: /['"`]#[0-9A-Fa-f]{3,8}['"`]|rgba?\s*\(\s*\d/,
  },
];

/** Rules applied to shared/ (must stay platform-neutral, no RN, no DOM). */
const SHARED_RULES = [
  NATIVE_RULES[0], // HTML element
  NATIVE_RULES[3], // DOM render / react-dom API
  NATIVE_RULES[4], // Browser global / storage API
  {
    name: 'Platform-specific import in shared/',
    hint: 'shared/ is consumed by both RN and web; keep it pure TypeScript',
    pattern:
      /from\s+['"](react-native|react-native\/[^'"]*|react-dom|expo|expo-[^'"]*|next|next\/[^'"]*|react-router-dom|lucide-react|@expo\/[^'"]*)['"]/,
  },
];

/**
 * shared/theme/colors.ts is the ONE authorized home for raw color literals —
 * it is the design-token source every other file must read from.
 */
const COLOR_TOKEN_SOURCE = join(MOBILE_ROOT, 'shared', 'theme', 'colors.ts');

function* walk(dir) {
  if (!existsSync(dir)) return;
  for (const entry of readdirSync(dir)) {
    if (entry === 'node_modules' || entry.startsWith('.')) continue;
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) yield* walk(full);
    else if (EXTENSIONS.has(extname(full))) yield full;
  }
}

/** Blank out comments and import-free doc prose, preserving line numbering. */
function stripComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, (block) => block.replace(/[^\n]/g, ' '))
    .replace(/(^|[^:])\/\/[^\n]*/g, (match, lead) => lead + ' '.repeat(match.length - lead.length));
}

function scan(dir, rules, label) {
  const found = [];
  for (const file of walk(dir)) {
    const cleaned = stripComments(readFileSync(file, 'utf8'));
    const lines = cleaned.split('\n');
    for (const rule of rules) {
      if (rule.name === 'Hardcoded color literal' && file === COLOR_TOKEN_SOURCE) continue;
      lines.forEach((line, index) => {
        if (new RegExp(rule.pattern.source, rule.pattern.flags.replace('g', '')).test(line)) {
          found.push({
            scope: label,
            file: relative(REPO_ROOT, file),
            line: index + 1,
            rule: rule.name,
            hint: rule.hint,
            text: line.trim().slice(0, 100),
          });
        }
      });
    }
  }
  return found;
}

const violations = [
  ...scan(join(MOBILE_ROOT, 'app'), NATIVE_RULES, 'mobile/app'),
  ...scan(join(MOBILE_ROOT, 'src'), NATIVE_RULES, 'mobile/src'),
  ...scan(join(MOBILE_ROOT, 'shared'), SHARED_RULES, 'mobile/shared'),
  ...scan(join(REPO_ROOT, 'shared'), SHARED_RULES, 'repo/shared'),
];

if (violations.length > 0) {
  for (const v of violations) {
    console.error(`✗ [${v.rule}] ${v.file}:${v.line}\n    ${v.text}\n    → ${v.hint}`);
  }
  console.error(
    `\n${violations.length} violation(s). mobile/ must stay pure React Native + Expo; mobile/shared/ and repo/shared/ must stay platform-neutral.`,
  );
  process.exit(1);
}

console.log(
  'Purity check passed — mobile/app + mobile/src + mobile/shared/ + repo/shared/ contain zero DOM elements,\n' +
    'zero DOM event handlers, zero react-dom/render APIs, zero browser globals,\n' +
    'zero web-framework imports, and zero hardcoded color literals.',
);
