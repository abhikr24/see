#!/usr/bin/env node
/**
 * verify-reference-architecture.mjs — machine enforcement of the
 * reference-pose architecture boundaries (Unit 28, Part 1).
 *
 * Enforced invariants (file:line reported for every violation):
 *
 *   A. shared/reference/** — the canonical reference domain — may contain
 *      ONLY relative imports. Zero bare package imports ⇒ structurally no
 *      Supabase, no expo-speech/TTS, no React/RN/DOM, no UI. The pipeline
 *      also must not reach the language/TTS layer (poseInstructions).
 *
 *   B. shared/ml/** — the mathematical engine — must not import the
 *      reference domain, providers or infrastructure: it receives the
 *      canonical measurement projection as plain arguments. (Its Unit-27
 *      import of shared/constants/poseInstructions phrase-bank data is the
 *      sanctioned semantic-coaching→language mapping and remains allowed.)
 *
 *   C. Test fixtures are test-only: no production tree (shared/, mobile/app,
 *      mobile/src, tooling/preview/src) may import tests/ or fixture paths.
 *
 *   D. No production code path may construct reference templates outside the
 *      shared/reference pipeline: the markers of raw ad-hoc template literals
 *      (measurementVersion + measurements co-located in one object literal)
 *      are forbidden outside shared/reference and tests/.
 *
 * Comments are stripped before scanning, mirroring verify-purity.mjs.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = fileURLToPath(new URL('.', import.meta.url));
const MOBILE_ROOT = join(SCRIPT_DIR, '..');
const REPO_ROOT = join(MOBILE_ROOT, '..');
const EXTENSIONS = new Set(['.ts', '.tsx']);

function collectFiles(dir, out = []) {
  let entries;
  try {
    entries = readdirSync(dir);
  } catch {
    return out;
  }
  for (const entry of entries) {
    if (entry === 'node_modules' || entry === '.expo' || entry === '.test-build') continue;
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) collectFiles(full, out);
    else if (EXTENSIONS.has(extname(full))) out.push(full);
  }
  return out;
}

/** Strip block + line comments so prose may mention forbidden topics. */
function stripComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, (m) => ' '.repeat(m.length))
    .replace(/(^|[^:])\/\/[^\n]*/g, '$1');
}

/* Statement-anchored (per-line) so quoted prose inside template literals
   (e.g. `from "${providerId}"` in a failure message) is never misread as an
   import. Multi-line import lists still match their `from` line. */
const IMPORT_RE =
  /^\s*(?:import|export)\s[^'"\n]*?from\s*['"]([^'"]+)['"]|^\s*import\s*['"]([^'"]+)['"]|import\s*\(\s*['"]([^'"]+)['"]\s*\)/gm;

const violations = [];

function report(file, line, rule, detail) {
  violations.push({ file: relative(REPO_ROOT, file), line, rule, detail });
}

function* importSpecifiers(source) {
  for (const match of source.matchAll(IMPORT_RE)) {
    const specifier = match[1] ?? match[2] ?? match[3];
    if (specifier !== undefined) yield { specifier, index: match.index };
  }
}

function lineOf(source, index) {
  return source.slice(0, index).split('\n').length;
}

/* ---------------- A. shared/reference is infrastructure-free ------------ */
for (const file of collectFiles(join(MOBILE_ROOT, 'shared', 'reference'))) {
  const source = stripComments(readFileSync(file, 'utf8'));
  for (const { specifier, index } of importSpecifiers(source)) {
    if (!specifier.startsWith('./') && !specifier.startsWith('../')) {
      report(file, lineOf(source, index), 'A: reference domain has a bare import',
        `"${specifier}" — the reference domain must import only shared-relative modules (no Supabase/RN/DOM/TTS/UI)`);
    }
    if (/poseInstructions|ttsService|expo-speech/i.test(specifier)) {
      report(file, lineOf(source, index), 'A: reference domain imports the language/TTS layer',
        `"${specifier}"`);
    }
    if (/tests?\/|fixtures/i.test(specifier)) {
      report(file, lineOf(source, index), 'A: reference domain imports test fixtures',
        `"${specifier}"`);
    }
  }
}

/* ---------------- B. the engine never depends on the reference domain --- */
for (const file of collectFiles(join(MOBILE_ROOT, 'shared', 'ml'))) {
  const source = stripComments(readFileSync(file, 'utf8'));
  for (const { specifier, index } of importSpecifiers(source)) {
    if (/(^|\/)reference(\/|$)/.test(specifier)) {
      report(file, lineOf(source, index), 'B: the math engine imports the reference domain',
        `"${specifier}" — engines receive measurement projections, never templates/providers`);
    }
    if (/@supabase|expo-speech/.test(specifier)) {
      report(file, lineOf(source, index), 'B: the math engine imports infrastructure',
        `"${specifier}"`);
    }
  }
}

/* ------------- C. fixtures never leak into production trees ------------- */
const PRODUCTION_TREES = [
  join(MOBILE_ROOT, 'shared'),
  join(MOBILE_ROOT, 'app'),
  join(MOBILE_ROOT, 'src'),
  join(REPO_ROOT, 'tooling', 'preview', 'src'),
];
for (const tree of PRODUCTION_TREES) {
  for (const file of collectFiles(tree)) {
    const source = stripComments(readFileSync(file, 'utf8'));
    for (const { specifier, index } of importSpecifiers(source)) {
      if (/(^|\/)tests?\/|fixtures/.test(specifier)) {
        report(file, lineOf(source, index), 'C: production code imports test-only modules',
          `"${specifier}"`);
      }
    }
  }
}

/* ---- D. ad-hoc template literals only inside pipeline/tests ------------ */
const TEMPLATE_LITERAL_RE = /measurementVersion\s*:\s*\d[\s\S]{0,800}?measurements\s*:/;
const EXEMPT_D = /mobile\/shared\/reference\/|tests\//;
for (const file of [
  ...collectFiles(join(MOBILE_ROOT, 'shared')),
  ...collectFiles(join(MOBILE_ROOT, 'app')),
  ...collectFiles(join(MOBILE_ROOT, 'src')),
]) {
  const rel = relative(REPO_ROOT, file);
  if (EXEMPT_D.test(rel)) continue;
  const source = stripComments(readFileSync(file, 'utf8'));
  const match = TEMPLATE_LITERAL_RE.exec(source);
  if (match) {
    report(file, lineOf(source, match.index), 'D: ad-hoc reference template literal',
      'templates must be built through shared/reference buildReferenceTemplate(), not hand-assembled');
  }
}

/* ---- E. exactly ONE validator and ONE template definition -------------- */
/* Duplicated validators/templates are how two "sources of truth" appear and
   then drift. Both must exist in exactly one file each. */
const DUP_CHECKS = [
  {
    rule: 'E: duplicated validator',
    re: /export\s+function\s+validateReferencePayload\b/,
    owner: 'mobile/shared/reference/pipeline.ts',
  },
  {
    rule: 'E: duplicated ReferencePoseTemplate definition',
    re: /export\s+interface\s+ReferencePoseTemplate\b/,
    owner: 'mobile/shared/reference/template.ts',
  },
  {
    rule: 'E: duplicated normalizer',
    re: /export\s+function\s+normalizeReferencePayload\b/,
    owner: 'mobile/shared/reference/pipeline.ts',
  },
];
const ALL_TS = [
  ...collectFiles(join(MOBILE_ROOT, 'shared')),
  ...collectFiles(join(MOBILE_ROOT, 'app')),
  ...collectFiles(join(MOBILE_ROOT, 'src')),
  ...collectFiles(join(REPO_ROOT, 'tooling', 'preview', 'src')),
];
for (const { rule, re, owner } of DUP_CHECKS) {
  const owners = [];
  for (const file of ALL_TS) {
    const source = stripComments(readFileSync(file, 'utf8'));
    if (re.test(source)) owners.push(relative(REPO_ROOT, file));
  }
  if (owners.length !== 1 || owners[0] !== owner) {
    report(
      join(REPO_ROOT, owner),
      1,
      rule,
      `expected exactly one definition in ${owner}; found in [${owners.join(', ') || 'nowhere'}]`,
    );
  }
}

/* ---- F. no fake reference fallback ------------------------------------ */
/* The banned chain is: reference unavailable → substitute plausible data →
   coach anyway. Structurally: nothing outside shared/reference may build a
   provider, and no provider may name a *different* source as a fallback. */
const FALLBACK_RE =
  /(fallback|substitute|placeholder|dummy|demo|fake|mock)[A-Za-z]*\s*(Reference|Template|Angles|Pose(?:Template)?)\b/i;
for (const file of ALL_TS) {
  const rel = relative(REPO_ROOT, file);
  const source = stripComments(readFileSync(file, 'utf8'));
  const match = FALLBACK_RE.exec(source);
  if (match) {
    report(file, lineOf(source, match.index), 'F: fake reference fallback',
      `"${match[0]}" — an unavailable reference must stay unavailable; never substitute data`);
  }
  /* Providers are constructed behind the shared factories + the mobile
     facade only, never inline in a screen/component. */
  if (
    !rel.startsWith('mobile/shared/reference') &&
    rel !== 'mobile/src/core/reference/referenceProvider.ts' &&
    /create(Catalog|Memory|Remote|Unavailable)ReferenceProvider\s*\(/.test(source)
  ) {
    report(file, 1, 'F: hidden provider construction',
      'providers are constructed by the shared factories and the app facade only');
  }
}

/* ---- G. no pose-specific hardcoding in the reference domain ----------- */
/* A catalog pose id baked into the pipeline would be a special case that
   silently changes behavior for one pose. */
const POSE_ID_RE = /["'`](portraits|couples|family|wedding|fashion|street|fitness|dance|travel|kids|group|creative)-\d+["'`]/;
for (const file of collectFiles(join(MOBILE_ROOT, 'shared', 'reference'))) {
  const source = stripComments(readFileSync(file, 'utf8'));
  const match = POSE_ID_RE.exec(source);
  if (match) {
    report(file, lineOf(source, match.index), 'G: pose-specific hardcoding',
      `${match[0]} — the reference domain must be pose-agnostic`);
  }
}


/* ---- H. the analysis engine is pure, deterministic math ---------------- */
/* shared/ml/analysis is the Unit 29 decision engine. It must contain ONLY
   geometry + rules: no bare package imports (so no Supabase, network, React,
   RN, DOM, TTS can enter), and no clock/randomness (so the same frame
   sequence always yields the same decision sequence). */
const ENGINE_DIR = join(MOBILE_ROOT, 'shared', 'ml', 'analysis');
const NONDETERMINISM_RE =
  /\b(Date\s*\.\s*now|new\s+Date|Math\s*\.\s*random|performance\s*\.\s*now|setTimeout|setInterval|fetch)\s*\(/;
for (const file of collectFiles(ENGINE_DIR)) {
  const source = stripComments(readFileSync(file, 'utf8'));
  for (const { specifier, index } of importSpecifiers(source)) {
    if (!specifier.startsWith('./') && !specifier.startsWith('../')) {
      report(file, lineOf(source, index), 'H: analysis engine has a bare import',
        `"${specifier}" — the engine imports only sibling math modules`);
    }
    if (/(^|\/)reference(\/|$)|providers?\//.test(specifier)) {
      report(file, lineOf(source, index), 'H: analysis engine imports the reference domain',
        `"${specifier}"`);
    }
  }
  const nondeterministic = NONDETERMINISM_RE.exec(source);
  if (nondeterministic) {
    report(file, lineOf(source, nondeterministic.index), 'H: non-deterministic engine code',
      `"${nondeterministic[0]}" — decisions are frame-counted, never clock- or random-driven`);
  }
}

/* ---- I. thresholds live in exactly one module -------------------------- */
/* A magic number copied into a second file is how two code paths start
   disagreeing about what "good" means. */
const THRESHOLD_OWNER = 'mobile/shared/ml/analysis/thresholds.ts';
const THRESHOLD_DECL_RE =
  /export\s+const\s+(GOOD_TOLERANCE_DEGREES|CORRECTION_THRESHOLD_DEGREES|MIN_COACHING_CONFIDENCE|CORRECTION_PERSISTENCE_FRAMES)\b/;
for (const file of ALL_TS) {
  const rel = relative(REPO_ROOT, file);
  if (rel === THRESHOLD_OWNER) continue;
  const source = stripComments(readFileSync(file, 'utf8'));
  const match = THRESHOLD_DECL_RE.exec(source);
  if (match) {
    report(file, lineOf(source, match.index), 'I: duplicated engine threshold',
      `"${match[1]}" is owned by ${THRESHOLD_OWNER}`);
  }
}

/* ------------------------------- report ------------------------------- */
if (violations.length > 0) {
  process.stderr.write(`\n✗ Reference-architecture check FAILED — ${violations.length} violation(s):\n`);
  for (const v of violations) {
    process.stderr.write(`  ${v.file}:${v.line}\n    [${v.rule}]\n    ${v.detail}\n`);
  }
  process.exit(1);
}
process.stdout.write(
  'Reference-architecture check passed — shared/reference is infrastructure-free,\n' +
    'the math engine imports no providers/templates, fixtures are test-only, no\n' +
    'ad-hoc template literals exist outside the pipeline, the validator/normalizer/\n' +
    'template each have exactly one definition, no fake reference fallback or hidden\n' +
    'provider construction exists, and the reference domain is pose-agnostic.\n',
);
