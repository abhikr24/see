import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('.', import.meta.url).pathname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const must = (label, ok) => {
  if (!ok) throw new Error(`FAIL: ${label}`);
  console.log(`PASS: ${label}`);
};

const build = read('native/vision-camera-mlkit-pose/android/build.gradle');
const plugin = read('plugins/withAndroidReleaseBuildFixes.js');
const app = JSON.parse(read('app.json'));
const wrapper = read('android/gradle/wrapper/gradle-wrapper.properties');
const nativeProps = read('native/vision-camera-mlkit-pose/android/gradle.properties');
const appGradle = read('android/app/build.gradle');

must('native module does not publish prefab AARs', !build.includes('prefabPublishing true'));
must('official Nitro prefab fix is applied', build.includes("apply from: './fix-prefab.gradle'"));
must('VisionCamera is implementation-scoped', build.includes('implementation project(":react-native-vision-camera")'));
must('VisionCamera is not api-scoped', !build.includes('api project(":react-native-vision-camera")'));
must('release APK lint safety is explicit', plugin.includes('checkReleaseBuilds = false'));
must('old task-disabling workaround removed', !plugin.includes('task.enabled = false'));
must('config plugin is registered in app.json', app.expo.plugins.includes('./plugins/withAndroidReleaseBuildFixes'));
must('checked-in Gradle wrapper matches EAS SDK 57 log', wrapper.includes('gradle-9.3.1-bin.zip'));
must('native fallback NDK matches EAS SDK 57 log', nativeProps.includes('VisionCameraMlkitPose_ndkVersion=27.1.12297006'));
must('real ML Kit accurate pose dependency remains', build.includes('com.google.mlkit:pose-detection-accurate:18.0.0-beta5'));
must('Nitro/Nitrogen glue remains', build.includes('VisionCameraMlkitPose+autolinking.gradle'));
must('native pose detector source remains', fs.existsSync(path.join(root, 'native/vision-camera-mlkit-pose/android/src/main/java/com/margelo/nitro/visioncameramlkitpose/HybridPoseDetector.kt')));
must('checked-in app build also avoids release vital-lint gate', appGradle.includes('checkReleaseBuilds = false'));

console.log('RELEASE NATIVE FIX CHECK: PASS');
console.log('Native pose module: real ML Kit + VisionCamera + Nitro preserved');
console.log('Release APK path: independent of local lint AAR intermediate artifact');
