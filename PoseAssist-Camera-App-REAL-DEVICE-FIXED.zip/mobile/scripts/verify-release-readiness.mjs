#!/usr/bin/env node
/** Static release gate. It intentionally does NOT claim that Gradle/APK execution succeeded. */
import { readFileSync, existsSync, statSync, readdirSync } from 'node:fs';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const mobile = fileURLToPath(new URL('..', import.meta.url));
const root = join(mobile, '..');
const fail = [];
const ok = (name) => console.log(`PASS ${name}`);
const bad = (name, why) => fail.push(`${name}: ${why}`);
const read = p => readFileSync(p, 'utf8');
const json = p => JSON.parse(read(p));

for (const p of [
  'package.json','package-lock.json','app.json','eas.json','metro.config.js','tsconfig.json',
  'assets/icon/app-icon-store.png','assets/splash/splash-icon.png',
  'native/vision-camera-mlkit-pose/package.json',
  'native/vision-camera-mlkit-pose/android/build.gradle',
  'native/vision-camera-mlkit-pose/android/gradle.properties',
  'native/vision-camera-mlkit-pose/android/src/main/java/com/margelo/nitro/visioncameramlkitpose/HybridPoseDetector.kt',
  'modules/hardware-shutter/expo-module.config.json',
  'plugins/withHardwareShutter.js',
  'shared/index.ts',
  'android/gradle/wrapper/gradle-wrapper.properties',
]) {
  if (existsSync(join(mobile,p))) ok(p); else bad(p,'missing');
}

const pkg=json(join(mobile,'package.json'));
const lock=json(join(mobile,'package-lock.json'));
const rootLock=lock.packages?.[''];
for (const [name,version] of Object.entries(pkg.dependencies||{})) {
  if (rootLock?.dependencies?.[name]!==version) bad(`lock:${name}`,`package.json=${version}, lock=${rootLock?.dependencies?.[name]}`);
}
if (!rootLock?.dependencies?.['expo-asset']) bad('expo-asset','must be a direct dependency because app.json loads its config plugin');

const app=json(join(mobile,'app.json')).expo;
const eas=json(join(mobile,'eas.json'));
for (const profile of ['development','preview']) {
  if (eas.build?.[profile]?.android?.buildType!=='apk') bad(`eas:${profile}`,'Android buildType is not apk');
}
if (eas.build?.development?.developmentClient===true && !pkg.dependencies?.['expo-dev-client']) bad('eas:development','developmentClient=true but expo-dev-client is not installed');
if (eas.build?.['release-apk']?.android?.buildType!=='apk') bad('eas:release-apk','explicit release APK profile is missing');

const plugins=app.plugins||[];
const pluginNames=plugins.map(x=>Array.isArray(x)?x[0]:x).filter(x=>typeof x==='string');
for (const name of pluginNames) {
  if (name.startsWith('./')) { const base=join(mobile,name.slice(2)); if (!existsSync(base) && !existsSync(base+'.js')) bad(`plugin:${name}`,'local plugin missing'); }
  else if (!pkg.dependencies?.[name]) bad(`plugin:${name}`, 'config plugin package is not a direct dependency');
}

const ts=json(join(mobile,'tsconfig.json'));
if (JSON.stringify(ts.compilerOptions?.paths?.['@shared/*'])!==JSON.stringify(['./shared/*'])) bad('tsconfig:@shared','must resolve inside mobile/shared for standalone EAS uploads');
if (!(ts.include||[]).includes('shared/**/*.ts')) bad('tsconfig:include','mobile/shared/**/*.ts is not included');

const metro=read(join(mobile,'metro.config.js'));
if (!metro.includes("path.resolve(projectRoot, 'shared')")) bad('metro:shared','Metro is not configured to watch mobile/shared');
if (metro.includes("path.resolve(workspaceRoot, 'shared')")) bad('metro:parent-shared','Metro still depends on ../shared');

const wrapper=read(join(mobile,'android/gradle/wrapper/gradle-wrapper.properties'));
if (!wrapper.includes('gradle-9.3.1-bin.zip')) bad('gradle-wrapper','must stay on the SDK 57/EAS 9.3.1 wrapper observed in the successful native compile path');

const nativeGradle=read(join(mobile,'native/vision-camera-mlkit-pose/android/build.gradle'));
const nativeProps=read(join(mobile,'native/vision-camera-mlkit-pose/android/gradle.properties'));
if (!nativeGradle.includes('namespace "com.margelo.nitro.visioncameramlkitpose"')) bad('native:namespace','namespace mismatch');
if (!nativeGradle.includes('com.google.mlkit:pose-detection-accurate:18.0.0-beta5')) bad('native:mlkit','real ML Kit accurate pose dependency/implementation not present');
if (!nativeProps.includes('VisionCameraMlkitPose_kotlinVersion=2.1.20')) bad('native:kotlin','fallback Kotlin version not aligned to SDK 57/RN 0.86 toolchain');
if (!nativeProps.includes('VisionCameraMlkitPose_compileSdkVersion=36')) bad('native:compileSdk','fallback compile SDK is not 36');
if (!nativeProps.includes('VisionCameraMlkitPose_targetSdkVersion=36')) bad('native:targetSdk','fallback target SDK is not 36');
if (!nativeProps.includes('VisionCameraMlkitPose_ndkVersion=27.1.12297006')) bad('native:ndk','fallback NDK is not 27.1.12297006');
if (!nativeGradle.includes('implementation project(":react-native-vision-camera")')) bad('native:visioncamera-scope','VisionCamera must be implementation, not api, for the app-local library');
if (nativeGradle.includes('api project(":react-native-vision-camera")')) bad('native:visioncamera-api','legacy api scope would leak VisionCamera into the local AAR publication graph');
const releasePlugin=read(join(mobile,'plugins/withAndroidReleaseBuildFixes.js'));
if (!releasePlugin.includes('checkReleaseBuilds = false')) bad('plugin:release-lint','release APK lint safety patch is missing');
if (releasePlugin.includes('task.enabled = false')) bad('plugin:old-lint-workaround','old task-disabling workaround must not remain');
const appGradle=read(join(mobile,'android/app/build.gradle'));
if (!appGradle.includes('checkReleaseBuilds = false')) bad('app:release-lint','checked-in app build must keep release lint out of the APK task');

const rootShared=join(root,'shared'), mobileShared=join(mobile,'shared');
function files(dir,base='') { let out=[]; for(const e of readdirSync(dir)){ const p=join(dir,e); const r=join(base,e); if(statSync(p).isDirectory()) out=out.concat(files(p,r)); else out.push(r.replaceAll('\\','/')); } return out; }
if (!existsSync(rootShared)) {
  // Standalone archive layout: the repo-root duplicate of shared/ is not
  // shipped (mobile/shared is the single live copy). Nothing to mirror-check.
  ok('shared-mirror (repo-root shared/ not present — mobile/shared is the only copy)');
} else {
  const a=files(rootShared), b=files(mobileShared);
  if (a.length!==b.length || a.some((f,i)=>f!==b[i] || read(join(rootShared,f))!==read(join(mobileShared,f)))) bad('shared-mirror','mobile/shared is not an exact copy of repo/shared'); else ok('shared-mirror');
}

const easignore=read(join(mobile,'.easignore'));
if (/^\s*shared\/?\s*$/m.test(easignore) || /^\s*\/shared\/?\s*$/m.test(easignore)) bad('mobile/.easignore','would exclude mobile/shared'); else ok('mobile/.easignore keeps mobile/shared');

if (fail.length) { console.error('\nRELEASE STATIC GATE FAILED'); for(const x of fail) console.error('FAIL '+x); process.exit(1); }
console.log('\nRELEASE STATIC GATE PASSED');
console.log('IMPORTANT: this gate proves packaging/configuration invariants only; it does not prove a live Gradle build, APK artifact, or physical-device feature test.');
