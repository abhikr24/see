#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.cwd());
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const must = (rel, re, label) => {
  const s = read(rel); if (!re.test(s)) throw new Error(`FAIL: ${label}`); console.log(`PASS ${label}`);
};
const mustNot = (rel, re, label) => {
  const s = read(rel); if (re.test(s)) throw new Error(`FAIL: ${label}`); console.log(`PASS ${label}`);
};

const pkg = JSON.parse(read('package.json'));
const lock = JSON.parse(read('package-lock.json'));
if (pkg.dependencies['react-native-mmkv'] !== '4.3.2') throw new Error('FAIL MMKV package pin');
if (lock.packages[''].dependencies['react-native-mmkv'] !== '4.3.2') throw new Error('FAIL MMKV lock root pin');
if (lock.packages['node_modules/react-native-mmkv'].version !== '4.3.2') throw new Error('FAIL MMKV lock package version');
console.log('PASS MMKV 4.3.2 is pinned');

must('src/core/storage/storage.ts', /createMMKV\(/, 'MMKV V4 createMMKV API');
must('src/core/storage/storage.ts', /require\('react-native-mmkv'\)/, 'MMKV native import is lazy');
must('src/core/storage/storage.ts', /export const storage: StorageAdapter = \{/, 'storage facade is pure JS at module load');
must('src/core/storage/storage.ts', /mmkv\.remove\(key\)/, 'MMKV V4 remove wrapper');
must('src/core/storage/storage.ts', /recoveryStrategy: 'recover-on-error'/, 'MMKV recovery strategy');
mustNot('src/core/storage/storage.ts', /import \{ createMMKV \} from 'react-native-mmkv'/, 'MMKV is not statically runtime-imported');
mustNot('src/core/storage/storage.ts', /new MMKV\(/, 'old MMKV constructor removed');
mustNot('src/core/storage/storage.ts', /mmkv\.delete\(/, 'old MMKV delete API absent');

must('src/shared/stores/themeStore.ts', /import\('\@\/core\/storage\/storage'\)/, 'theme persistence is dynamically loaded');
must('app/(tabs)/_layout.tsx', /ThemeBootstrap/, 'theme hydration is deferred to main app shell');
mustNot('src/shared/stores/themeStore.ts', /persist\(/, 'Zustand persist no longer hydrates native storage during cold boot');
must('src/features/onboarding/data/onboardingRepository.ts', /import\('\@\/core\/storage\/storage'\)/, 'onboarding storage is deferred');
mustNot('app/_layout.tsx', /setTimeout\(\(\) => \{[\s\S]*authStore/, 'root no longer initializes auth on a timer');
must('app/(tabs)/_layout.tsx', /AuthBootstrap/, 'tabs own auth bootstrap');
must('app/auth.tsx', /<AuthRouteBootstrap\s*\/>/, 'auth route owns direct-link auth bootstrap');
must('src/features/onboarding/presentation/hooks/useAppPermissions.ts', /const cameraStatus = await check\('camera'\)/, 'camera permission check runs first');
mustNot('src/shared/components/AppButton.tsx', /react-native-reanimated/, 'first-run button does not import Reanimated');
must('src/core/permissions/permissionService.ts', /import\('expo-media-library'\)/, 'media-library loads dynamically');

for (const rel of [
  'src/core/theme/theme.ts',
  'src/shared/stores/themeStore.ts',
  'src/shared/components/AppButton.tsx',
  'src/shared/components/AppText.tsx',
  'src/shared/components/PrivacyNote.tsx',
  'src/shared/components/IconSymbol.tsx',
  'src/shared/components/PageIndicator.tsx',
  'src/features/onboarding/presentation/screens/WelcomeScreen.tsx',
  'src/features/onboarding/presentation/screens/OnboardingScreen.tsx',
  'src/features/onboarding/presentation/screens/PermissionsScreen.tsx',
  'src/features/onboarding/presentation/components/PhotographyIllustration.tsx',
  'src/features/onboarding/presentation/components/PermissionCard.tsx',
]) {
  mustNot(rel, /@shared\/index/, `first-run path avoids shared barrel: ${rel}`);
}
mustNot('src/shared/components/PageIndicator.tsx', /react-native-reanimated/, 'onboarding indicator does not import Reanimated');
must('eas.json', /"NODE_ENV":\s*"production"/, 'release APK sets NODE_ENV production');

const eas = JSON.parse(read('eas.json'));
if (eas.build?.['release-apk']?.android?.buildType !== 'apk') throw new Error('FAIL release APK profile');
if (eas.build?.['release-apk']?.cache?.disabled !== true) throw new Error('FAIL build cache disabled');
console.log('PASS release APK profile remains intact');

console.log('V11 RUNTIME SAFETY GATE: PASS');
