import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd().endsWith('mobile') ? process.cwd() : path.join(process.cwd(), 'mobile');
const must = (p, pattern, label) => {
  const file = fs.readFileSync(path.join(root, p), 'utf8');
  if (!pattern.test(file)) throw new Error(`${label}: check failed`);
  console.log(`PASS ${label}`);
};
const mustNot = (p, pattern, label) => {
  const file = fs.readFileSync(path.join(root, p), 'utf8');
  if (pattern.test(file)) throw new Error(`${label}: check failed`);
  console.log(`PASS ${label}`);
};

must('app/index.tsx', /BootGateScreen/, 'root uses BootGateScreen');
must('src/features/onboarding/domain/startupService.ts', /BOOT_READ_TIMEOUT_MS\s*=\s*900/, 'bounded startup read');
must('src/features/onboarding/presentation/screens/BootGateScreen.tsx', /1200/, 'startup watchdog');
must('src/features/onboarding/presentation/screens/BootGateScreen.tsx', /assets\/icon\/app-icon-store\.png/, 'boot asset');
must('app/(tabs)/_layout.tsx', /lazy:\s*true/, 'lazy tabs');
mustNot('app/_layout.tsx', /@\/shared\/stores\/authStore/, 'root does not import auth store statically');
must('app/(tabs)/_layout.tsx', /AuthBootstrap/, 'auth is bootstrapped in tabs shell');
must('src/features/onboarding/data/bootState.ts', /readAsStringAsync/, 'async boot persistence');
must('src/features/onboarding/data/onboardingRepository.ts', /writeBootState/, 'boot-state mirror');
must('native/vision-camera-mlkit-pose/android/src/main/java/com/margelo/nitro/visioncameramlkitpose/HybridPoseDetector.kt', /PoseDetection\.getClient/, 'real ML Kit pose');
console.log('V8 BOOT RUNTIME CHECK: PASS');
