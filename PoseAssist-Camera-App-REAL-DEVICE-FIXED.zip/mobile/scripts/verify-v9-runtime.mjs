import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.cwd());
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const must = (rel, pattern, label) => {
  const text = read(rel);
  if (!pattern.test(text)) throw new Error(`FAIL: ${label} (${rel})`);
  console.log(`PASS: ${label}`);
};
const mustNot = (rel, pattern, label) => {
  const text = read(rel);
  if (pattern.test(text)) throw new Error(`FAIL: ${label} (${rel})`);
  console.log(`PASS: ${label}`);
};

must('app/index.tsx', /BootGateScreen/, 'index uses lightweight boot gate');
must('src/features/onboarding/presentation/screens/BootGateScreen.tsx', /<Redirect href=\{destination\}/, 'boot gate uses declarative redirect');
must('src/features/onboarding/presentation/screens/BootGateScreen.tsx', /1200/, 'boot watchdog exists');
mustNot('src/features/onboarding/presentation/screens/BootGateScreen.tsx', /useRouter|router\.replace|router\.push/, 'boot gate has no imperative navigation');
must('app/_layout.tsx', /@shared\/theme\/colors/, 'root theme import is lightweight');
mustNot('app/_layout.tsx', /(?:import .*useAppTheme|import .*useAuthStore|import .*OfflineBanner|import .*GlobalSnackBar)/, 'root no longer eagerly imports heavy theme/auth/overlay modules');
mustNot('app/_layout.tsx', /if \(!fontsLoaded && fontError === null\) \{\s*return null;/, 'root does not block route tree on fonts');
mustNot('app/_layout.tsx', /@\/shared\/stores\/authStore/, 'root does not statically import auth store');
must('app/(tabs)/_layout.tsx', /AuthBootstrap/, 'auth restore is owned by tabs shell');
must('app/auth.tsx', /AuthRouteBootstrap/, 'auth route owns direct-link bootstrap');
must('app/_layout.tsx', /lazy\(async \(\) => \{\s*const mod = await import\('\@\/shared\/components\/OfflineBanner'/, 'offline banner is lazy');
must('src/features/onboarding/domain/startupService.ts', /bootStateTimeout/, 'startup is bounded');
mustNot('src/features/onboarding/domain/startupService.ts', /AppLogger|@shared\/index|appConstants/, 'startup service has no heavy shared-barrel dependency');
mustNot('src/features/onboarding/data/bootState.ts', /AppLogger|@shared\/index|appConstants/, 'boot-state module has no heavy shared-barrel dependency');
must('src/features/onboarding/data/onboardingRepository.ts', /@shared\/constants\/app/, 'onboarding repository avoids shared barrel on boot-adjacent path');
must('app/+native-intent.tsx', /return '\/'/, 'bare native launch normalizes to root');
must('app/+not-found.tsx', /<Redirect href="\/"\s*\/>/, 'not-found returns to root');
must('app/(tabs)/_layout.tsx', /lazy: true/, 'heavy tabs mount lazily');
must('app.json', /withAndroidPhoneApk/, 'phone APK config plugin remains');
must('eas.json', /"release-apk"/, 'release APK profile remains');
must('eas.json', /"disabled": true/, 'EAS cache remains disabled for release APK');
must('eas.json', /-Dorg\.gradle\.parallel=false/, 'parallel Gradle override remains');
must('native/vision-camera-mlkit-pose/android/build.gradle', /pose-detection-accurate/, 'real ML Kit accurate pose remains');
console.log('V9 RUNTIME RELEASE GATE: PASS');
