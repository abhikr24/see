import fs from 'node:fs';

const src = fs.readFileSync('app/_layout.tsx', 'utf8');
const failures = [];
const pass = (m) => console.log(`PASS ${m}`);
const fail = (m) => failures.push(`FAIL ${m}`);

src.includes('<RootErrorBoundary>') ? pass('root error boundary retained') : fail('root error boundary missing');
src.includes('<Stack') ? pass('root Stack retained') : fail('root Stack missing');
src.includes('{postBootReady && (\n                  <View\n                    pointerEvents="box-none"') ? pass('OfflineBanner is mounted as a stable absolute overlay') : fail('OfflineBanner stability wrapper missing');
src.includes('position: \'absolute\'') ? pass('delayed overlay is absolute') : fail('delayed overlay is not absolute');
src.includes('topAttached/topDetached/topTransitionProgress') ? pass('physical-device lifecycle evidence documented in source') : fail('lifecycle evidence comment missing');

const stackIndex = src.indexOf('<Stack');
const firstPostBoot = src.indexOf('{postBootReady && (');
if (stackIndex >= 0 && firstPostBoot >= 0 && stackIndex < firstPostBoot) pass('navigator host is declared before delayed overlay branch');
else fail('delayed overlay appears before navigator host');

if (failures.length) {
  console.error(failures.join('\n'));
  process.exit(1);
}
console.log('WHITE-SCREEN ROOT STABILITY GATE: PASS');
