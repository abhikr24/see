/**
 * Unit 01 — AppLogger singleton.
 * console-backed in __DEV__, silent in production builds. Ring buffer of
 * the last 200 lines kept in memory for the future dev console overlay.
 * Rule: no raw console.log outside this class.
 */
import { LOG_TAG } from '@/core/constants/appConstants';

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogLine {
  readonly level: LogLevel;
  readonly message: string;
  readonly at: string;
  readonly stack: string | null;
}

const MAX_LINES = 200;

const PREFIX: Record<LogLevel, string> = {
  debug: '[DEBUG]',
  info: '[INFO]',
  warn: '[WARN]',
  error: '[ERROR]',
};

export class AppLogger {
  private static buffer: LogLine[] = [];

  private static write(level: LogLevel, message: string, error?: unknown): void {
    const stack = error instanceof Error
      ? error.stack ?? `${error.name}: ${error.message}`
      : error === undefined
        ? null
        : String(error);
    AppLogger.buffer.push({ level, message, at: new Date().toISOString(), stack });
    if (AppLogger.buffer.length > MAX_LINES) {
      AppLogger.buffer.splice(0, AppLogger.buffer.length - MAX_LINES);
    }
    if (__DEV__) {
      const line = `${PREFIX[level]} [${LOG_TAG}] ${message}`;
      if (level === 'error') console.error(stack ? `${line}\n${stack}` : line);
      else if (level === 'warn') console.warn(line);
      else console.log(line);
    }
  }

  static debug(message: string): void {
    AppLogger.write('debug', message);
  }
  static info(message: string): void {
    AppLogger.write('info', message);
  }
  static warn(message: string): void {
    AppLogger.write('warn', message);
  }
  static error(message: string, error?: unknown): void {
    AppLogger.write('error', message, error);
  }

  /**
   * Cold-start / crash-path diagnostics that must reach `adb logcat` even in
   * a release build, where every other level here is silenced by `__DEV__`.
   * Use ONLY on the small set of boot checkpoints (BootGate mount, startup
   * watchdog, runStartup resolution, root error boundary) — this is not a
   * general-purpose logging escape hatch. Tag mirrors ReactNativeJS so it is
   * greppable: `adb logcat | grep PoseAssistBoot`.
   */
  static critical(message: string, error?: unknown): void {
    AppLogger.write('error', message, error);
    const stack = error instanceof Error ? error.stack ?? `${error.name}: ${error.message}` : error;
    // eslint-disable-next-line no-console
    console.warn(`[PoseAssistBoot] ${message}`, stack ?? '');
    // Also flush recent buffered context (info/warn/debug lines silenced by
    // __DEV__ elsewhere) so a release-build failure shows what led up to it,
    // not just the single triggering line. Bounded to the last 20 lines to
    // avoid flooding logcat.
    const recentContext = AppLogger.buffer.slice(-20, -1);
    if (recentContext.length > 0) {
      // eslint-disable-next-line no-console
      console.warn(
        `[PoseAssistBoot] --- recent context (${recentContext.length} lines) ---\n` +
          recentContext.map((l) => `  ${l.at} ${PREFIX[l.level]} ${l.message}`).join('\n'),
      );
    }
  }

  /** Dev console overlay (Unit 22 can render this). */
  static recent(count: number = MAX_LINES): readonly LogLine[] {
    return AppLogger.buffer.slice(-count);
  }
}

AppLogger.info('App Started — logger online');
