import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Image, StyleSheet, Text, View } from 'react-native';
import { Redirect } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { runStartup, type StartupResult } from '../../domain/startupService';
import { lightColors } from '@shared/theme/colors';
import { warmAppFonts } from '@/core/bootstrap/fontWarmup';
import { AppLogger } from '@/core/utils/logger';

/**
 * Dependency-light first React route.
 *
 * Critical rule: startup chooses a destination as state, then <Redirect />
 * performs the route change declaratively. The first mount performs no
 * imperative navigation because this screen is itself the initial route.
 */
export function BootGateScreen() {
  const [destination, setDestination] = useState<StartupResult['destination'] | null>(null);

  useEffect(() => {
    let active = true;
    AppLogger.critical('BootGateScreen mounted');
    // Diagnostic only (no behavior change): rules in/out whether EXPO_PUBLIC_*
    // env vars were actually inlined at bundle time for this build. Dynamic
    // import so this stays off the eager cold-start module graph.
    void import('@/core/network/supabaseClient')
      .then(({ isBackendConfigured }) => {
        AppLogger.critical(`Backend configured at boot: ${isBackendConfigured}`);
      })
      .catch((error) => AppLogger.critical('supabaseClient diagnostic import failed', error));

    // The native splash is no longer needed once this tiny first React screen
    // has rendered. Do not make app launch depend on fonts/auth/navigation.
    warmAppFonts();
    requestAnimationFrame(() => {
      AppLogger.critical('First RAF fired — hiding native splash');
      SplashScreen.hideAsync()
        .then(() => AppLogger.critical('SplashScreen.hideAsync resolved'))
        .catch((error) => AppLogger.critical('SplashScreen.hideAsync rejected', error));
    });

    // Hard guarantee: even if the async boot-state file is slow/unavailable,
    // the user cannot remain on this screen indefinitely.
    const watchdog = setTimeout(() => {
      if (active) {
        AppLogger.critical('Startup watchdog fired (runStartup exceeded 1200ms) — forcing /welcome');
        setDestination('/welcome');
      }
    }, 1200);

    void runStartup()
      .then(({ destination: nextDestination, elapsedMs }) => {
        if (!active) return;
        AppLogger.critical(`runStartup resolved in ${elapsedMs}ms -> ${nextDestination}`);
        clearTimeout(watchdog);
        setDestination(nextDestination);
      })
      .catch((error) => {
        if (!active) return;
        AppLogger.critical('runStartup rejected — forcing /welcome', error);
        clearTimeout(watchdog);
        setDestination('/welcome');
      });

    return () => {
      active = false;
      clearTimeout(watchdog);
    };
  }, []);

  useEffect(() => {
    if (destination !== null) {
      AppLogger.critical(`BootGateScreen redirecting to ${destination}`);
    }
  }, [destination]);

  if (destination !== null) {
    return <Redirect href={destination} />;
  }

  return (
    <View style={styles.root}>
      <Image
        source={require('../../../../../assets/icon/app-icon-store.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <Text style={styles.name}>PoseAssist</Text>
      <Text style={styles.tagline}>Smart Photography Assistant</Text>
      <ActivityIndicator size="small" style={styles.spinner} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: lightColors.background,
  },
  logo: {
    width: 112,
    height: 112,
  },
  name: {
    marginTop: 20,
    fontSize: 30,
    lineHeight: 36,
    fontWeight: '700',
    color: lightColors.primary,
  },
  tagline: {
    marginTop: 6,
    fontSize: 14,
    color: lightColors.textSecondary,
  },
  spinner: {
    position: 'absolute',
    bottom: 48,
  },
});
