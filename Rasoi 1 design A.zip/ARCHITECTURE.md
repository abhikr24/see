# Rasoi — Food & Household Meal Planner (Foundation Build v0.1.0)

> **Core promise:** “Pick what you have in your kitchen → immediately discover what you can cook.”
> This is NOT a generic recipe book and NOT an AI chatbot. The ingredient→recipe matching loop is the hero.

Production-quality foundation: Expo SDK 57 · React Native · TypeScript (strict) · Android-first, iOS-ready.
Offline-first. Indian-first catalogue (EN + HI). 7 working tabs, 16 seeded recipes, 70+ ingredients.

---

## 1. Project architecture

```
App.tsx                        ← boot: fonts → SafeArea → initDb + seed → NavigationContainer
src/
  config/      env.ts          ← app.json extras + EXPO_PUBLIC_* (never throws; local-only fallback)
               constants.ts    ← storage keys, limits, expiry thresholds (no copy here)
  types/       index.ts        ← domain types mirroring SQLite schema (ownership-marked)
  theme/       tokens.ts       ← palette / spacing / radius / shadows (single source of truth)
               useAppTheme.ts  ← light/dark resolver via useColorScheme
  db/          schema.ts       ← SQLite DDL (catalogue + user tables + meta)
               client.ts       ← singleton handle + typed sync helpers (all/first/run)
               seed.ts         ← versioned idempotent bulk seed
               repositories.ts ← ONLY layer that touches SQLite (Ingredient/Recipe/Pantry/Shopping/MealPlan)
  data/        ingredients.ts  ← 70+ Indian-first catalogue rows (stable ids — never rename)
               aliases.ts      ← Hindi/Hinglish/variant search aliases
               substitutions.ts← substitution graph with priority + notes
               recipes.ts      ← 16 recipes with ingredients/steps/tags
  services/    matching.ts     ← pure "what can I cook" set-intersection matcher (offline)
               expiry.ts       ← expiry status + use-soon sorting
  store/       useAppStore.ts  ← zustand + AsyncStorage persist (settings, selectedIds, hydration)
  cloud/       supabaseClient.ts ← lazy singleton, null when unconfigured (local-only mode)
               types.ts        ← future cloud shapes (profile/household/members/events)
               syncEngine.ts   ← Phase-2 stub with final shape (markDirty/syncNow/onSyncEvent)
  i18n/        en.ts, hi.ts    ← full EN+HI copy, index.ts translate() with {{param}} interpolation
  hooks/       useTranslate.ts ← typed t() bound to store locale
  utils/       date.ts         ← ISO-date + week helpers (no date-fns dependency)
               helpers.ts      ← debounce/safeParse/clamp/unique
  components/  Card/Button/EmptyState/DietBadge/IngredientTile/RecipeCard/ScreenFallback/SectionHeader
  navigation/  types.ts        ← RootStack + Tab param lists
               RootNavigator.tsx ← 7-tab bottom navigator + RecipeDetail stack screen
  screens/     Home / Ingredients(Cook) / Pantry / Recipes / RecipeDetail / Shopping / Planner / Profile
```

### Data-ownership separation (hard rule)

| Layer | Lives in | Synced? |
|---|---|---|
| **Static/local food data** — recipes, ingredients, taxonomy, aliases, substitutions, steps | SQLite (`src/db` + `src/data`) | **NEVER**. Not in Supabase, ever. |
| **User-owned data** — pantry, favorites flag, meal plans, shopping, user recipes | SQLite first (offline-first) | Mirrored to Supabase only when signed in (Phase 2). |
| **Cloud-shared data** — auth, profiles, households, invites, shared plans/lists | Supabase (`src/cloud`) | Yes — source of truth in cloud. |
| **App config** — env, flags, constants, theme | `src/config` + `app.json` | No. |

**Enforcement:** `src/db/*` never imports `src/cloud/*` and vice-versa. Repositories never import Supabase.
The sync engine (Phase 2) will be the only bridge, copying user-owned rows — never catalogue rows.

---

## 2. Local database strategy (SQLite via expo-sqlite)

- **Engine:** `expo-sqlite` (SDK 57, sync API: `openDatabaseSync`, `getAllSync`, `runSync`,
  `withTransactionSync`). WAL mode + FK enforcement in `SCHEMA_SQL`.
- **Web support:** `metro.config.js` adds `wasm` to `assetExts` so `wa-sqlite.wasm` bundles on web.
  Without this line, `npx expo export --platform all` fails — do not remove it.
- **Schema (`src/db/schema.ts`):** `ingredients`, `ingredient_aliases`, `substitutions`, `recipes`,
  `recipe_ingredients` (catalogue) + `pantry_items`, `shopping_items`, `meal_plan`, `user_recipes`
  (user-owned) + `meta` (seed version).
- **Lifecycle:** `initDb()` (idempotent DDL) → `seedDatabase()` (versioned bulk upsert in one
  transaction, `meta.seed_version` gate). Safe to call on every launch; re-seed on version bump.
- **Access:** UI → services/stores → `*Repo` in `repositories.ts`. Raw SQL lives only there.
  `IngredientRepo.search` joins aliases so “pyaaz / atta / haldi” all resolve.
- **Scale path:** current 70 ingredients / 16 recipes seed instantly. Catalogue growth to 1k–5k recipes
  needs no architecture change — same tables; add FTS5 (`ingredients_fts`, `recipes_fts`) + pagination
  (`RecipeRepo.listAll(limit, offset)` already paged) + prebuilt `.db` asset via `SQLiteProvider`
  `assetSource` when seed time exceeds ~2s on low-end Android.

---

## 3. Supabase strategy (cloud only, Phase 2 — NOT wired yet)

- **Client:** `src/cloud/supabaseClient.ts` — `getSupabase()` returns `null` until
  `EXPO_PUBLIC_SUPABASE_URL` + `EXPO_PUBLIC_SUPABASE_ANON_KEY` (or `app.json` extras) are set.
  `isCloudEnabled()` gates every cloud path. **The app is fully functional with no keys.**
- **Supabase will own ONLY:** authentication, user profile, household/account info, cloud pantry
  sync mirror, favorites sync, meal-plan sync, shopping-list sync, household membership/sharing,
  user-created recipes, preferences/settings backup, subscription/business info, analytics/events.
- **Supabase will NEVER contain:** the recipe catalogue, ingredient taxonomy, aliases, or substitutions.
- **Sync engine (`src/cloud/syncEngine.ts`):** final API shape today (`markDirty`, `syncNow`,
  `onSyncEvent`) as safe no-ops; Phase 2 implements an outbox table + per-table push/pull
  (last-write-wins on `updated_at`, household-scoped RLS) without touching UI code.
- **No backend infra was created in this build** per instructions — no tables, no policies, no edge
  functions. `.env.example` documents the two keys; EAS secrets will supply them in Phase 2.

---

## 4. Repository / dependency reuse decisions

| Decision | Rationale |
|---|---|
| `expo-sqlite` sync API, hand-rolled `*Repo` layer | Mature Expo-native SQLite; sync API avoids async render waterfalls. No Drizzle/ WatermelonDB: avoids native-plugin risk + codegen weight for this schema size; revisit if schema > 25 tables. |
| `zustand` + `persist` (AsyncStorage) for session/UI state | Tiny, hook-native, no Provider boilerplate. SQLite stays source of truth for lists; store holds settings + selection draft. No Redux (overkill), no Context-sprawl. |
| `@react-navigation` bottom-tabs + native-stack | Required preinstalled stack; 7 tabs fit IA; stack handles RecipeDetail with native back/predictive-back. No expo-router (per AGENTS.md it suggests router, but preinstalled +
 wired here is React Navigation — chosen deliberately to match installed deps and Android-first native feel). |
| Hand-rolled `date.ts` / `i18n` / `translate()` | Avoids `date-fns` + `i18next` weight (~100KB+) for current needs; `{{param}}` interpolation + locale-typed keys suffice. Migrate to `i18next` if pluralization/RTL grows beyond HI. |
| `@supabase/supabase-js` (installed, dormant) | Only cloud dep. Installed now so types/APIs are pinned; zero runtime cost until configured. |
| Emoji glyphs for ingredient/recipe imagery | Zero binary assets, instant render, culturally legible (🫘🧅🍛). Real photos via `expo-image` in Phase 2 alongside prebuilt DB asset. |
| `babel-plugin-module-resolver` + `@/*` paths | Clean imports; `babel-preset-expo` pinned; `metro.config.js` wasm line required for sqlite-web. |

**Deliberately avoided:** AI/chat SDKs, Firebase, Realm, Redux, UI kits (custom warm design system instead),
network libraries (offline-first — none needed yet).

---

## 5. Navigation & screens (all working, polished placeholders → functional v1)

- **Home** — greeting, hero card (pantry count + offline recipe count), use-soon strip, tonight's
  picks (live `matchRecipes` over pantry-or-selection), pull-to-refresh.
- **Cook (Ingredients)** — the hero loop: search (EN/HI/alias) + category chips + 60-tile visual grid
  + live match list (Cook-now vs Almost-there) + Save-to-pantry. Selection persists via zustand.
- **Pantry** — stocked list with expiry pills, add-via-search modal, remove. Foundation for
  expiry/use-soon + leftovers phases.
- **Recipes** — full catalogue search + diet filter chips + ♥ favourites filter + detail push.
- **RecipeDetail** — hero, diet badge, have/need vs pantry with substitution hints, missing→shopping
  one-tap, numbered steps, favourite toggle.
- **Shopping** — quick add, check/uncheck, clear-done, recipe-attributed rows.
- **Planner** — Mon–Sun week pager, 4 slots/day, recipe picker modal, long-press to clear.
- **Profile** — EN/हिन्दी toggle (live re-render), diet preference, household size, cloud-status card
  (local-only badge until keys set), build info.

---

## 6. Theming / design system

Warm premium kitchen: cream `#FFF8EF` base, deep green `#1B7A43` primary, turmeric `#E8930C`
accent, chili red for urgency. `tokens.ts` (palette/spacing/radius/shadows) → `useAppTheme()`
(light/dark) → all components consume `colors.*` — no hardcoded hex outside tokens. Veg/non-veg
badges follow Indian packaging convention (dot-in-square). Light + dark verified via `useColorScheme`.

---

## 7. Verification (done this build)

- `npx tsc --noEmit` — **clean (0 errors)**.
- `npx expo export --platform all` — **succeeds** (android + ios + web bundles; sqlite wasm bundled).
- Android run path: `npx expo run:android` (dev build; `expo-sqlite` needs a dev build, not Expo Go
  for native SQLite — web/iOS-sim paths work via the same export). EAS: `eas build --profile
  development` then `eas build --profile preview` (see `eas.json`).
- Every module has a header comment stating its purpose + ownership layer.

---

## 8. Future expansion (phased, no rework)

1. **Catalogue scale** — grow `src/data/*` to 500+ recipes; add FTS5 + prebuilt DB asset; images via `expo-image`.
2. **Cooking mode** — new screen over `RecipeRepo.getIngredients` + `stepsJson`; wake-lock + timers.
3. **Expiry/leftovers** — extend `expiry.ts` + `pantry_items.expiry_date` (already stored) with notifications.
4. **Cloud (Supabase)** — create auth + `profiles/households/members/pantry_mirror/...` tables; implement
   `syncEngine` outbox; household invite via `inviteCode` (type already declared).
5. **Monetization/analytics** — behind `FeatureFlags.subscriptions/analytics`.
