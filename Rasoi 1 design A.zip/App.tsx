import React, { useEffect, useState } from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { useColorScheme } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { RootNavigator } from '@/navigation';
import { initDb } from '@/db';
import { seedDatabase } from '@/db/seed';
import { useAppStore } from '@/store';
import { ScreenFallback } from '@/components';
import { useAppTheme } from '@/theme';

function Shell() {
  const scheme = useColorScheme();
  const { dark } = useAppTheme();
  const dbReady = useAppStore((s) => s.dbReady);
  const hydrated = useAppStore((s) => s.hydrated);
  const setDbReady = useAppStore((s) => s.setDbReady);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await initDb();
        await seedDatabase();
      } catch (e) {
        console.warn('[rasoi] db init failed', e);
      } finally {
        if (alive) setDbReady(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, [setDbReady]);

  if (!hydrated || !dbReady) {
    return <ScreenFallback label={hydrated ? 'Setting up your kitchen…' : 'Loading preferences…'} />;
  }

  return (
    <NavigationContainer theme={scheme === 'dark' ? DarkTheme : DefaultTheme}>
      <StatusBar style={dark ? 'light' : 'dark'} />
      <RootNavigator />
    </NavigationContainer>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (fontsLoaded) setReady(true);
  }, [fontsLoaded]);

  if (!ready) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <Shell />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
