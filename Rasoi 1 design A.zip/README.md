# Rasoi 🍛 — Food & Household Meal Planner

**Pick what you have → discover what you can cook.** Indian-first, offline-first meal planner.

Foundation build (v0.1.0): 7 tabs (Home, Cook, Pantry, Recipes, Shopping, Planner, Profile),
70+ ingredient catalogue (EN + Hindi + Hinglish aliases), 16 Indian recipes, live ingredient→recipe
matching, pantry with expiry states, shopping list, weekly meal planner, EN/हिन्दी localization,
light + dark theme — all working fully offline on Android & iOS.

## Quick start

```bash
npm install
npx expo start            # dev server (QR → Expo Go for UI; dev build for native SQLite)
npx expo run:android      # Android dev build (recommended — full SQLite)
npx expo run:ios          # iOS dev build
```

## Checks

```bash
npx tsc --noEmit                 # typecheck — must be clean
npx expo export --platform all   # bundle android+ios+web — must succeed
```

> Web note: `metro.config.js` maps `.wasm` to assets so `expo-sqlite`'s `wa-sqlite.wasm` bundles.
> Do not remove that line.

## Cloud (optional, Phase 2)

The app works 100% without keys (local-only mode). To enable future sync:

```bash
cp .env.example .env   # fill EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY
```

The recipe catalogue **never** goes to Supabase — only user data (pantry mirror, favorites,
plans, lists, households) syncs, per `ARCHITECTURE.md`.

## Structure

```
src/config  env, constants        src/cloud    supabase (dormant) + sync stub
src/types   domain types          src/i18n     en + hi
src/theme   tokens + dark mode    src/hooks    useTranslate
src/db      schema/client/seed    src/utils    date, helpers
src/data    ingredients/aliases/  src/components  design system
          substitutions/recipes  src/navigation  7 tabs + detail stack
src/services matching/expiry     src/screens  8 screens
src/store   zustand + persist
```

See `ARCHITECTURE.md` for the full architecture, DB/Supabase strategies, and roadmap.
