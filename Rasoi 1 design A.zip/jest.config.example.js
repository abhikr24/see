/**
 * Enable when jest is installed:
 *   npx expo install -D jest jest-expo @testing-library/react-native @types/jest
 * Then uncomment `testMatch` wiring in package.json (`"test": "jest"`).
 */
// module.exports = { preset: 'jest-expo', testMatch: ['**/__tests__/**/*.test.ts?(x)'] };
