const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// expo-sqlite web needs .wasm as an asset so Metro can bundle wa-sqlite.wasm
config.resolver.assetExts.push('wasm');

module.exports = config;
