/**
 * Testing-ready structure.
 *
 * No test runner is installed in the foundation build (keeps install lean +
 * avoids native-plugin risk). When ready: `npx expo install -D jest jest-expo
 * @testing-library/react-native` then wire `jest.config.js` below.
 *
 * Conventions:
 *  - Pure logic (services/utils/matching) → `src/__tests__/*.test.ts` (no RN mocks needed)
 *  - Repositories → SQLite in-memory tests via `expo-sqlite` mock
 *  - Screens/components → `@testing-library/react-native` render tests
 */
import { matchRecipes } from '@/services/matching';

// Minimal ambient declarations so `tsc --noEmit` stays clean before jest is installed.
// Remove once `@types/jest` is added (it provides these globals).
declare function describe(name: string, fn: () => void): void;
declare function it(name: string, fn: () => void): void;
declare function expect(value: unknown): { toBe(expected: unknown): void };

// Placeholder contract test (runs under jest when installed):
// - empty selection returns catalogue-bounded list
// - full pantry for dal-tadka yields canCook match
describe('matching service contract', () => {
  it('exports a pure matcher', () => {
    expect(typeof matchRecipes).toBe('function');
  });
});
