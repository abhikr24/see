/**
 * Supabase client abstraction — CLOUD data only.
 * Lazy singleton; returns null when unconfigured (local-only mode).
 * Never import recipe/ingredient catalogue code here.
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { CloudConfig } from '@/config/env';

let client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient | null {
  if (!CloudConfig.isConfigured) return null;
  if (!client) {
    client = createClient(CloudConfig.supabaseUrl, CloudConfig.supabaseAnonKey, {
      auth: { persistSession: true, autoRefreshToken: true },
    });
  }
  return client;
}

export function isCloudEnabled(): boolean {
  return CloudConfig.isConfigured;
}
