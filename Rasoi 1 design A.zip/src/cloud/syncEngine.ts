/**
 * Sync engine stub (Phase 2). Today: local-only, queue-free.
 * Shape is final so future sync plugs in without touching UI:
 *  - markDirty(table) → queue
 *  - syncNow() → push/pull when signed in + online
 * All methods are safe no-ops until Supabase is configured.
 */
import { isCloudEnabled } from './supabaseClient';
import type { SyncEvent } from './types';

const listeners = new Set<(e: SyncEvent) => void>();

export function onSyncEvent(fn: (e: SyncEvent) => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function emit(e: SyncEvent) {
  listeners.forEach((fn) => {
    try {
      fn(e);
    } catch {
      /* ignore */
    }
  });
}

export async function markDirty(_table: SyncEvent['table']): Promise<void> {
  // Phase 2: persist to outbox table. Today: no-op.
}

export async function syncNow(): Promise<{ pushed: number; pulled: number; skipped: boolean }> {
  if (!isCloudEnabled()) return { pushed: 0, pulled: 0, skipped: true };
  // Phase 2: implement push/pull per table.
  emit({ table: 'pantry', at: new Date().toISOString(), direction: 'up', ok: true });
  return { pushed: 0, pulled: 0, skipped: false };
}
