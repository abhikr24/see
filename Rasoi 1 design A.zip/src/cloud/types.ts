/**
 * Cloud-owned type surface. Tables are created in Phase 2 (not now).
 * Declared early so UI/store code can depend on stable shapes.
 */
export interface CloudProfile {
  id: string;
  displayName: string | null;
  avatarUrl: string | null;
  locale: 'en' | 'hi';
  dietPreference: string;
  householdSize: number;
}

export interface CloudHousehold {
  id: string;
  name: string;
  inviteCode: string;
  createdBy: string;
}

export interface CloudHouseholdMember {
  householdId: string;
  userId: string;
  role: 'owner' | 'member';
}

export interface SyncEvent {
  table: 'pantry' | 'favorites' | 'meal_plans' | 'shopping' | 'settings';
  at: string;
  direction: 'up' | 'down';
  ok: boolean;
}
