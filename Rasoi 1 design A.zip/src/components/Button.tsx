import React from 'react';
import { Pressable, StyleSheet, Text, type ViewStyle, type StyleProp } from 'react-native';
import { useAppTheme } from '@/theme';
import { radius, fontSize } from '@/theme/tokens';

interface Props {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'outline' | 'danger';
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}

export function Button({ label, onPress, variant = 'primary', style, disabled }: Props) {
  const { colors } = useAppTheme();
  const bg =
    variant === 'primary'
      ? colors.primary
      : variant === 'soft'
        ? colors.primarySoft
        : variant === 'danger'
          ? colors.chiliSoft
          : 'transparent';
  const fg =
    variant === 'primary' ? '#fff' : variant === 'danger' ? colors.chili : colors.primary;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.btn,
        { backgroundColor: bg, borderColor: variant === 'outline' ? colors.primary : 'transparent', opacity: disabled ? 0.5 : pressed ? 0.85 : 1 },
        style,
      ]}
    >
      <Text style={[styles.label, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    borderRadius: radius.pill,
    paddingVertical: 13,
    paddingHorizontal: 22,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
  },
  label: { fontSize: fontSize.md, fontWeight: '800', letterSpacing: 0.2 },
});
