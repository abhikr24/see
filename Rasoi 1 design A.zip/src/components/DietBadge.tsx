import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '@/theme';
import { radius, fontSize } from '@/theme/tokens';

export function DietBadge({ diet }: { diet: string }) {
  const { colors, dark } = useAppTheme();
  const isVeg = diet === 'veg' || diet === 'vegan' || diet === 'jain';
  const dot = isVeg ? colors.primary : colors.chili;
  const label = diet === 'veg' ? 'VEG' : diet === 'non-veg' ? 'NON-VEG' : diet.toUpperCase();
  return (
    <View style={[styles.badge, { borderColor: dot, backgroundColor: dark ? colors.card : '#fff' }]}>
      <View style={[styles.dot, { borderColor: dot }]}>
        <View style={[styles.inner, { backgroundColor: dot }]} />
      </View>
      <Text style={[styles.text, { color: dot }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderWidth: 1.2,
    borderRadius: radius.sm,
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  dot: { width: 13, height: 13, borderRadius: 3, borderWidth: 1.4, alignItems: 'center', justifyContent: 'center' },
  inner: { width: 6, height: 6, borderRadius: 3 },
  text: { fontSize: 10, fontWeight: '900', letterSpacing: 0.4 },
});
