import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '@/theme';
import { fontSize, spacing } from '@/theme/tokens';

interface Props {
  icon: string;
  title: string;
  subtitle?: string;
}

export function EmptyState({ icon, title, subtitle }: Props) {
  const { colors } = useAppTheme();
  return (
    <View style={styles.wrap}>
      <Text style={styles.icon}>{icon}</Text>
      <Text style={[styles.title, { color: colors.ink }]}>{title}</Text>
      {subtitle ? <Text style={[styles.sub, { color: colors.inkSoft }]}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', paddingVertical: spacing.xxxl, paddingHorizontal: spacing.xl, gap: 6 },
  icon: { fontSize: 44 },
  title: { fontSize: fontSize.lg, fontWeight: '800', textAlign: 'center' },
  sub: { fontSize: fontSize.md, textAlign: 'center', lineHeight: 21 },
});
