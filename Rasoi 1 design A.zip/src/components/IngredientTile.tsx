import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '@/theme';
import { radius, fontSize, spacing } from '@/theme/tokens';
import type { Ingredient } from '@/types';
import { useLocale } from '@/store';

export function IngredientTile({
  item,
  selected,
  onToggle,
}: {
  item: Ingredient;
  selected: boolean;
  onToggle: () => void;
}) {
  const { colors } = useAppTheme();
  const locale = useLocale();
  return (
    <Pressable
      onPress={onToggle}
      accessibilityRole="checkbox"
      accessibilityState={{ checked: selected }}
      style={({ pressed }) => [
        styles.tile,
        {
          backgroundColor: selected ? colors.primary : colors.card,
          borderColor: selected ? colors.primaryDark : colors.line,
          opacity: pressed ? 0.88 : 1,
          transform: [{ scale: pressed ? 0.96 : 1 }],
        },
      ]}
    >
      <Text style={styles.emoji}>{item.icon}</Text>
      <Text
        numberOfLines={2}
        style={[styles.name, { color: selected ? '#fff' : colors.ink }]}
      >
        {locale === 'hi' && item.nameHi ? item.nameHi : item.nameEn}
      </Text>
      {selected ? (
        <View style={styles.check}>
          <Text style={styles.checkTxt}>✓</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    borderRadius: radius.lg,
    borderWidth: 1.5,
    paddingVertical: spacing.md,
    paddingHorizontal: 6,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 96,
    position: 'relative',
  },
  emoji: { fontSize: 30, marginBottom: 4 },
  name: { fontSize: fontSize.xs, fontWeight: '700', textAlign: 'center', lineHeight: 14 },
  check: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkTxt: { fontSize: 12, fontWeight: '900', color: '#1B7A43' },
});
