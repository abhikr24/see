import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '@/theme';
import { radius, fontSize, spacing, shadow } from '@/theme/tokens';
import { DietBadge } from './DietBadge';
import type { Recipe } from '@/types';
import { safeParse } from '@/utils';
import { useLocale } from '@/store';

export function RecipeCard({
  recipe,
  matchPct,
  missingCount,
  onPress,
}: {
  recipe: Recipe;
  matchPct?: number;
  missingCount?: number;
  onPress: () => void;
}) {
  const { colors } = useAppTheme();
  const locale = useLocale();
  const totalMin = recipe.prepMin + recipe.cookMin;
  const showMatch = typeof matchPct === 'number';
  const tags = safeParse<string[]>(recipe.tagsJson, []);
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [{ opacity: pressed ? 0.9 : 1, transform: [{ scale: pressed ? 0.985 : 1 }] }]}
    >
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.line }]}>
        <View style={[styles.emojiWrap, { backgroundColor: colors.accentSoft }]}>
          <Text style={styles.emoji}>{recipe.imageEmoji}</Text>
          {recipe.isFavorite ? <Text style={styles.fav}>❤️</Text> : null}
        </View>
        <View style={styles.body}>
          <View style={styles.topRow}>
            <DietBadge diet={recipe.diet} />
            <Text style={[styles.meta, { color: colors.muted }]}>
              ⏱ {totalMin} min • {recipe.cuisine}
            </Text>
          </View>
          <Text style={[styles.title, { color: colors.ink }]} numberOfLines={1}>
            {locale === 'hi' && recipe.titleHi ? recipe.titleHi : recipe.titleEn}
          </Text>
          {!!recipe.description && (
            <Text style={[styles.desc, { color: colors.inkSoft }]} numberOfLines={1}>
              {recipe.description}
            </Text>
          )}
          <View style={styles.bottomRow}>
            {showMatch ? (
              <View
                style={[
                  styles.pill,
                  { backgroundColor: matchPct! >= 100 ? colors.primarySoft : colors.accentSoft },
                ]}
              >
                <Text style={[styles.pillTxt, { color: matchPct! >= 100 ? colors.primary : colors.accent }]}>
                  {matchPct! >= 100 ? `✓ ${matchPct}%` : `${matchPct}% • ${missingCount} missing`}
                </Text>
              </View>
            ) : (
              <Text style={[styles.tag, { color: colors.muted }]} numberOfLines={1}>
                {tags.slice(0, 2).join(' • ')}
              </Text>
            )}
            <Text style={[styles.cta, { color: colors.primary }]}>View →</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    borderRadius: radius.xl,
    borderWidth: 1,
    padding: spacing.md,
    gap: spacing.md,
    ...shadow.card,
  },
  emojiWrap: {
    width: 84,
    height: 84,
    borderRadius: radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  emoji: { fontSize: 42 },
  fav: { position: 'absolute', top: 4, right: 6, fontSize: 14 },
  body: { flex: 1, justifyContent: 'center', gap: 3 },
  topRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  meta: { fontSize: fontSize.xs, fontWeight: '600' },
  title: { fontSize: fontSize.lg, fontWeight: '800' },
  desc: { fontSize: fontSize.sm },
  bottomRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4, gap: 8 },
  pill: { borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 },
  pillTxt: { fontSize: fontSize.xs, fontWeight: '800' },
  tag: { fontSize: fontSize.xs, flex: 1 },
  cta: { fontSize: fontSize.sm, fontWeight: '800' },
});
