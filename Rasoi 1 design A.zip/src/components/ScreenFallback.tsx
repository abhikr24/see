import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '@/theme';
import { spacing, fontSize } from '@/theme/tokens';

export function ScreenFallback({ label }: { label?: string }) {
  const { colors } = useAppTheme();
  return (
    <View style={[styles.wrap, { backgroundColor: colors.bg }]}>
      <Text style={styles.emoji}>🍳</Text>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={[styles.txt, { color: colors.inkSoft }]}>{label ?? 'Setting up your kitchen…'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md, padding: spacing.xl },
  emoji: { fontSize: 52 },
  txt: { fontSize: fontSize.md, fontWeight: '600' },
});
