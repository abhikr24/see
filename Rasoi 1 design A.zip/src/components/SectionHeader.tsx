import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '@/theme';
import { radius, fontSize } from '@/theme/tokens';

const STYLES: Record<string, { bg: string; fg: string; icon: string }> = {};

export function SectionHeader({ title, action }: { title: string; action?: React.ReactNode }) {
  const { colors } = useAppTheme();
  void STYLES;
  return (
    <View style={styles.row}>
      <Text style={[styles.title, { color: colors.ink }]}>{title}</Text>
      {action}
    </View>
  );
}

export function Pill({ text, tone = 'neutral' }: { text: string; tone?: 'neutral' | 'green' | 'amber' | 'red' | 'blue' }) {
  const { colors } = useAppTheme();
  const bg =
    tone === 'green' ? colors.primarySoft : tone === 'amber' ? colors.accentSoft : tone === 'red' ? colors.chiliSoft : tone === 'blue' ? colors.infoSoft : colors.card;
  const fg =
    tone === 'green' ? colors.primary : tone === 'amber' ? colors.accent : tone === 'red' ? colors.chili : tone === 'blue' ? colors.info : colors.inkSoft;
  return (
    <View style={[styles.pill, { backgroundColor: bg }]}>
      <Text style={[styles.pillTxt, { color: fg }]}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, marginTop: 18 },
  title: { fontSize: fontSize.xl, fontWeight: '800', letterSpacing: -0.3 },
  pill: { borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 5 },
  pillTxt: { fontSize: fontSize.xs, fontWeight: '800' },
});
