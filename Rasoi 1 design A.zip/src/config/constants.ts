/**
 * App constants. Display copy lives in `src/i18n/` — only non-translatable
 * constants (limits, keys, durations) belong here.
 */
export const STORAGE_KEYS = {
  APP_SETTINGS: '@rasoi/settings',
  SEED_META: '@rasoi/seed-meta',
  ONBOARDING_DONE: '@rasoi/onboarding-done',
  LAST_TAB: '@rasoi/last-tab',
} as const;

export const LIMITS = {
  MAX_SELECTED_INGREDIENTS: 30,
  SEARCH_DEBOUNCE_MS: 250,
  RECIPE_PAGE_SIZE: 20,
  SHOPPING_UNBOUGHT_FIRST: true,
} as const;

export const EXPIRY_THRESHOLDS_DAYS = {
  EXPIRED: 0,
  USE_SOON: 3,
} as const;

export const SUPPORTED_LOCALES = ['en', 'hi'] as const;
export type SupportedLocale = (typeof SUPPORTED_LOCALES)[number];
