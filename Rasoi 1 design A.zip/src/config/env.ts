/**
 * Single source of truth for environment + app configuration.
 *
 * Layers (never mix these):
 *  - LOCAL / STATIC food data  → SQLite (`src/db/` + `src/data/`). The full recipe
 *    catalogue NEVER goes to Supabase.
 *  - USER-OWNED data           → SQLite first (offline-first), mirrored to AsyncStorage
 *    where trivial (settings), synced to Supabase when signed in.
 *  - CLOUD-SHARED data         → Supabase (`src/cloud/`). Auth, household, sync.
 *  - APP CONFIG                → this file + `app.json` extras.
 *
 * Reads `app.json` extras first, then `process.env` (EAS / .env via
 * `EXPO_PUBLIC_*`), then safe defaults. Nothing here throws — missing cloud
 * config simply means "local-only mode".
 */
import Constants from 'expo-constants';
import { Platform } from 'react-native';

type ExtraConfig = {
  supabaseUrl?: string;
  supabaseAnonKey?: string;
  env?: string;
};

function readExtra(): ExtraConfig {
  const extra = (Constants?.expoConfig?.extra ?? {}) as ExtraConfig;
  return extra;
}

const extra = readExtra();

const SUPABASE_URL =
  extra.supabaseUrl ||
  process.env.EXPO_PUBLIC_SUPABASE_URL ||
  '';

const SUPABASE_ANON_KEY =
  extra.supabaseAnonKey ||
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  '';

export const AppEnv = {
  APP_NAME: 'Rasoi',
  APP_VERSION: Constants?.expoConfig?.version ?? '0.1.0',
  ENV: (extra.env || process.env.EXPO_PUBLIC_ENV || (__DEV__ ? 'development' : 'production')) as string,
  PLATFORM: Platform.OS,
  IS_DEV: __DEV__,
} as const;

export const CloudConfig = {
  supabaseUrl: SUPABASE_URL,
  supabaseAnonKey: SUPABASE_ANON_KEY,
  /** False until both URL + anon key are configured. App must work fully offline when false. */
  get isConfigured(): boolean {
    return Boolean(CloudConfig.supabaseUrl && CloudConfig.supabaseAnonKey);
  },
} as const;

export const LocalDbConfig = {
  databaseName: 'rasoi.db',
  /** Bump to trigger destructive re-seed during early development (migrations handle prod later). */
  schemaVersion: 1,
  seedVersion: 1,
} as const;

export const FeatureFlags = {
  householdSharing: false, // Phase 2 — behind flag until Supabase tables exist
  subscriptions: false, // Phase 3
  analytics: false,
} as const;
