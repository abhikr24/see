/**
 * Bundled ingredient catalogue (Indian-first). Source of truth for SQLite seed.
 * `id` is stable — never rename once shipped (used by pantry/meal FKs).
 */
import type { IngredientCategory } from '@/types';

export interface SeedIngredient {
  id: string;
  nameEn: string;
  nameHi: string;
  category: IngredientCategory;
  icon: string;
  unit: string;
  shelfLifeDays: number | null;
  isCommon: boolean;
}

export const SEED_INGREDIENTS: SeedIngredient[] = [
  // ─── Vegetables ───
  { id: 'onion', nameEn: 'Onion', nameHi: 'प्याज़', category: 'vegetables', icon: '🧅', unit: 'pcs', shelfLifeDays: 21, isCommon: true },
  { id: 'tomato', nameEn: 'Tomato', nameHi: 'टमाटर', category: 'vegetables', icon: '🍅', unit: 'pcs', shelfLifeDays: 7, isCommon: true },
  { id: 'potato', nameEn: 'Potato', nameHi: 'आलू', category: 'vegetables', icon: '🥔', unit: 'pcs', shelfLifeDays: 21, isCommon: true },
  { id: 'cauliflower', nameEn: 'Cauliflower', nameHi: 'फूलगोभी', category: 'vegetables', icon: '🥦', unit: 'pcs', shelfLifeDays: 7, isCommon: true },
  { id: 'green-peas', nameEn: 'Green Peas', nameHi: 'मटर', category: 'vegetables', icon: '🫛', unit: 'g', shelfLifeDays: 5, isCommon: true },
  { id: 'spinach', nameEn: 'Spinach', nameHi: 'पालक', category: 'vegetables', icon: '🥬', unit: 'g', shelfLifeDays: 3, isCommon: true },
  { id: 'okra', nameEn: 'Okra (Bhindi)', nameHi: 'भिंडी', category: 'vegetables', icon: '🌿', unit: 'g', shelfLifeDays: 4, isCommon: true },
  { id: 'eggplant', nameEn: 'Eggplant (Baingan)', nameHi: 'बैंगन', category: 'vegetables', icon: '🍆', unit: 'pcs', shelfLifeDays: 6, isCommon: true },
  { id: 'carrot', nameEn: 'Carrot', nameHi: 'गाजर', category: 'vegetables', icon: '🥕', unit: 'pcs', shelfLifeDays: 14, isCommon: true },
  { id: 'capsicum', nameEn: 'Capsicum', nameHi: 'शिमला मिर्च', category: 'vegetables', icon: '🫑', unit: 'pcs', shelfLifeDays: 7, isCommon: true },
  { id: 'cabbage', nameEn: 'Cabbage', nameHi: 'पत्तागोभी', category: 'vegetables', icon: '🥬', unit: 'pcs', shelfLifeDays: 10, isCommon: true },
  { id: 'bottle-gourd', nameEn: 'Bottle Gourd (Lauki)', nameHi: 'लौकी', category: 'vegetables', icon: '🎃', unit: 'pcs', shelfLifeDays: 7, isCommon: true },
  { id: 'pumpkin', nameEn: 'Pumpkin', nameHi: 'कद्दू', category: 'vegetables', icon: '🎃', unit: 'g', shelfLifeDays: 30, isCommon: false },
  { id: 'french-beans', nameEn: 'French Beans', nameHi: 'फलियाँ', category: 'vegetables', icon: '🫛', unit: 'g', shelfLifeDays: 5, isCommon: false },
  { id: 'radish', nameEn: 'Radish (Mooli)', nameHi: 'मूली', category: 'vegetables', icon: '🥗', unit: 'pcs', shelfLifeDays: 10, isCommon: false },
  { id: 'cucumber', nameEn: 'Cucumber', nameHi: 'खीरा', category: 'vegetables', icon: '🥒', unit: 'pcs', shelfLifeDays: 6, isCommon: false },
  { id: 'green-chilli', nameEn: 'Green Chilli', nameHi: 'हरी मिर्च', category: 'vegetables', icon: '🌶️', unit: 'pcs', shelfLifeDays: 7, isCommon: true },
  { id: 'ginger', nameEn: 'Ginger', nameHi: 'अदरक', category: 'vegetables', icon: '🫚', unit: 'g', shelfLifeDays: 14, isCommon: true },
  { id: 'garlic', nameEn: 'Garlic', nameHi: 'लहसुन', category: 'vegetables', icon: '🧄', unit: 'pcs', shelfLifeDays: 30, isCommon: true },
  { id: 'coriander-leaves', nameEn: 'Coriander Leaves', nameHi: 'हरा धनिया', category: 'herbs', icon: '🌿', unit: 'g', shelfLifeDays: 3, isCommon: true },
  { id: 'mint-leaves', nameEn: 'Mint Leaves', nameHi: 'पुदीना', category: 'herbs', icon: '🌱', unit: 'g', shelfLifeDays: 3, isCommon: false },
  { id: 'curry-leaves', nameEn: 'Curry Leaves', nameHi: 'करी पत्ता', category: 'herbs', icon: '🍃', unit: 'g', shelfLifeDays: 5, isCommon: true },
  { id: 'lemon', nameEn: 'Lemon', nameHi: 'नींबू', category: 'fruits', icon: '🍋', unit: 'pcs', shelfLifeDays: 14, isCommon: true },
  // ─── Fruits ───
  { id: 'mango', nameEn: 'Mango', nameHi: 'आम', category: 'fruits', icon: '🥭', unit: 'pcs', shelfLifeDays: 6, isCommon: false },
  { id: 'banana', nameEn: 'Banana', nameHi: 'केला', category: 'fruits', icon: '🍌', unit: 'pcs', shelfLifeDays: 4, isCommon: false },
  { id: 'coconut', nameEn: 'Coconut', nameHi: 'नारियल', category: 'nuts_seeds', icon: '🥥', unit: 'pcs', shelfLifeDays: 30, isCommon: false },
  // ─── Grains & flours ───
  { id: 'rice', nameEn: 'Rice', nameHi: 'चावल', category: 'grains_cereals', icon: '🍚', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'basmati-rice', nameEn: 'Basmati Rice', nameHi: 'बासमती चावल', category: 'grains_cereals', icon: '🍚', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'wheat-flour', nameEn: 'Wheat Flour (Atta)', nameHi: 'गेहूं का आटा', category: 'grains_cereals', icon: '🌾', unit: 'g', shelfLifeDays: 90, isCommon: true },
  { id: 'semolina', nameEn: 'Semolina (Suji/Rava)', nameHi: 'सूजी', category: 'grains_cereals', icon: '🌾', unit: 'g', shelfLifeDays: 180, isCommon: true },
  { id: 'poha', nameEn: 'Flattened Rice (Poha)', nameHi: 'पोहा', category: 'grains_cereals', icon: '🍚', unit: 'g', shelfLifeDays: 180, isCommon: true },
  { id: 'besan', nameEn: 'Gram Flour (Besan)', nameHi: 'बेसन', category: 'grains_cereals', icon: '🌾', unit: 'g', shelfLifeDays: 180, isCommon: true },
  { id: 'bread', nameEn: 'Bread / Pav', nameHi: 'ब्रेड / पाव', category: 'grains_cereals', icon: '🍞', unit: 'pcs', shelfLifeDays: 4, isCommon: false },
  // ─── Pulses & legumes ───
  { id: 'toor-dal', nameEn: 'Toor Dal (Arhar)', nameHi: 'अरहर दाल', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'moong-dal', nameEn: 'Moong Dal', nameHi: 'मूंग दाल', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'masoor-dal', nameEn: 'Masoor Dal', nameHi: 'मसूर दाल', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'chana-dal', nameEn: 'Chana Dal', nameHi: 'चना दाल', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'urad-dal', nameEn: 'Urad Dal', nameHi: 'उड़द दाल', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'rajma', nameEn: 'Kidney Beans (Rajma)', nameHi: 'राजमा', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'chole', nameEn: 'Chickpeas (Kabuli Chana)', nameHi: 'काबुली चना', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'kala-chana', nameEn: 'Black Chickpeas', nameHi: 'काला चना', category: 'pulses_lentils', icon: '🫘', unit: 'g', shelfLifeDays: 365, isCommon: false },
  // ─── Dairy ───
  { id: 'milk', nameEn: 'Milk', nameHi: 'दूध', category: 'dairy', icon: '🥛', unit: 'ml', shelfLifeDays: 2, isCommon: true },
  { id: 'curd', nameEn: 'Curd (Dahi)', nameHi: 'दही', category: 'dairy', icon: '🍶', unit: 'g', shelfLifeDays: 4, isCommon: true },
  { id: 'paneer', nameEn: 'Paneer', nameHi: 'पनीर', category: 'dairy', icon: '🧀', unit: 'g', shelfLifeDays: 4, isCommon: true },
  { id: 'ghee', nameEn: 'Ghee', nameHi: 'घी', category: 'oils_fats', icon: '🫙', unit: 'ml', shelfLifeDays: 180, isCommon: true },
  { id: 'butter', nameEn: 'Butter', nameHi: 'मक्खन', category: 'dairy', icon: '🧈', unit: 'g', shelfLifeDays: 30, isCommon: false },
  { id: 'cream', nameEn: 'Fresh Cream', nameHi: 'मलाई', category: 'dairy', icon: '🥛', unit: 'ml', shelfLifeDays: 4, isCommon: false },
  // ─── Spices & masalas ───
  { id: 'turmeric', nameEn: 'Turmeric (Haldi)', nameHi: 'हल्दी', category: 'spices', icon: '🟡', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'red-chilli-powder', nameEn: 'Red Chilli Powder', nameHi: 'लाल मिर्च पाउडर', category: 'spices', icon: '🌶️', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'coriander-powder', nameEn: 'Coriander Powder', nameHi: 'धनिया पाउडर', category: 'spices', icon: '🟤', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'cumin-seeds', nameEn: 'Cumin Seeds (Jeera)', nameHi: 'जीरा', category: 'spices', icon: '🌿', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'mustard-seeds', nameEn: 'Mustard Seeds (Rai)', nameHi: 'राई', category: 'spices', icon: '⚫', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'fenugreek', nameEn: 'Fenugreek (Methi)', nameHi: 'मेथी', category: 'spices', icon: '🌱', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'garam-masala', nameEn: 'Garam Masala', nameHi: 'गरम मसाला', category: 'spices', icon: '🧂', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'asafoetida', nameEn: 'Asafoetida (Hing)', nameHi: 'हींग', category: 'spices', icon: '🧂', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'cardamom', nameEn: 'Cardamom (Elaichi)', nameHi: 'इलायची', category: 'spices', icon: '🫛', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'bay-leaf', nameEn: 'Bay Leaf (Tej Patta)', nameHi: 'तेज पत्ता', category: 'spices', icon: '🍃', unit: 'pcs', shelfLifeDays: 365, isCommon: false },
  { id: 'black-pepper', nameEn: 'Black Pepper', nameHi: 'काली मिर्च', category: 'spices', icon: '⚫', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'kasuri-methi', nameEn: 'Kasuri Methi', nameHi: 'कसूरी मेथी', category: 'spices', icon: '🌿', unit: 'g', shelfLifeDays: 365, isCommon: false },
  { id: 'sambar-powder', nameEn: 'Sambar Powder', nameHi: 'सांभर पाउडर', category: 'spices', icon: '🧂', unit: 'g', shelfLifeDays: 365, isCommon: false },
  // ─── Oils, sweeteners, condiments ───
  { id: 'mustard-oil', nameEn: 'Mustard Oil', nameHi: 'सरसों का तेल', category: 'oils_fats', icon: '🫗', unit: 'ml', shelfLifeDays: 180, isCommon: true },
  { id: 'sunflower-oil', nameEn: 'Cooking Oil', nameHi: 'खाना बनाने का तेल', category: 'oils_fats', icon: '🫗', unit: 'ml', shelfLifeDays: 180, isCommon: true },
  { id: 'salt', nameEn: 'Salt', nameHi: 'नमक', category: 'condiments', icon: '🧂', unit: 'g', shelfLifeDays: 999, isCommon: true },
  { id: 'sugar', nameEn: 'Sugar', nameHi: 'चीनी', category: 'condiments', icon: '🍬', unit: 'g', shelfLifeDays: 999, isCommon: true },
  { id: 'jaggery', nameEn: 'Jaggery (Gud)', nameHi: 'गुड़', category: 'condiments', icon: '🟤', unit: 'g', shelfLifeDays: 180, isCommon: false },
  { id: 'tamarind', nameEn: 'Tamarind (Imli)', nameHi: 'इमली', category: 'condiments', icon: '🫘', unit: 'g', shelfLifeDays: 180, isCommon: false },
  { id: 'tea-leaves', nameEn: 'Tea Leaves', nameHi: 'चाय पत्ती', category: 'beverages', icon: '🍵', unit: 'g', shelfLifeDays: 365, isCommon: true },
  { id: 'peanut', nameEn: 'Peanuts', nameHi: 'मूंगफली', category: 'nuts_seeds', icon: '🥜', unit: 'g', shelfLifeDays: 90, isCommon: true },
  { id: 'cashew', nameEn: 'Cashews', nameHi: 'काजू', category: 'nuts_seeds', icon: '🥜', unit: 'g', shelfLifeDays: 90, isCommon: false },
  // ─── Eggs / meat ───
  { id: 'egg', nameEn: 'Egg', nameHi: 'अंडा', category: 'eggs', icon: '🥚', unit: 'pcs', shelfLifeDays: 14, isCommon: false },
  { id: 'chicken', nameEn: 'Chicken', nameHi: 'चिकन', category: 'meat', icon: '🍗', unit: 'g', shelfLifeDays: 2, isCommon: false },
];
