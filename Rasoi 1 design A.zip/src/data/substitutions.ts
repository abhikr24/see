/** Substitution graph. `priority` 0 = best substitute. Shown on recipe detail. */
export interface SeedSubstitution {
  ingredientId: string;
  substituteId: string;
  note: string;
  priority: number;
}

export const SEED_SUBSTITUTIONS: SeedSubstitution[] = [
  { ingredientId: 'onion', substituteId: 'asafoetida', note: 'For Jain cooking — skip onion, add a pinch of hing', priority: 0 },
  { ingredientId: 'tomato', substituteId: 'curd', note: 'Sourness + body when tomatoes run out', priority: 0 },
  { ingredientId: 'tomato', substituteId: 'tamarind', note: 'Small tamarind pulp for tang', priority: 1 },
  { ingredientId: 'ginger', substituteId: 'garlic', note: 'Partial swap — flavor shifts but works', priority: 1 },
  { ingredientId: 'garlic', substituteId: 'asafoetida', note: 'Jain swap — pinch of hing in hot oil', priority: 0 },
  { ingredientId: 'paneer', substituteId: 'potato', note: 'Aloo replaces paneer in most gravies', priority: 0 },
  { ingredientId: 'cream', substituteId: 'curd', note: 'Whisked curd + cashew paste for richness', priority: 0 },
  { ingredientId: 'cream', substituteId: 'milk', note: 'Milk + butter (3:1) in a pinch', priority: 1 },
  { ingredientId: 'mustard-oil', substituteId: 'sunflower-oil', note: 'Any neutral oil works', priority: 0 },
  { ingredientId: 'basmati-rice', substituteId: 'rice', note: 'Regular rice works, shorter grains', priority: 0 },
  { ingredientId: 'toor-dal', substituteId: 'masoor-dal', note: 'Masoor cooks faster, similar dal', priority: 0 },
  { ingredientId: 'toor-dal', substituteId: 'moong-dal', note: 'Lighter dal, great for khichdi', priority: 1 },
  { ingredientId: 'tamarind', substituteId: 'lemon', note: 'Lemon juice for sourness at the end', priority: 0 },
  { ingredientId: 'jaggery', substituteId: 'sugar', note: '1:1, add later to avoid splitting milk', priority: 0 },
  { ingredientId: 'curry-leaves', substituteId: 'coriander-leaves', note: 'Different aroma, still fresh', priority: 1 },
  { ingredientId: 'coriander-leaves', substituteId: 'mint-leaves', note: 'Fresh-herb finish', priority: 1 },
  { ingredientId: 'green-chilli', substituteId: 'red-chilli-powder', note: '¼ tsp powder ≈ 1 green chilli', priority: 0 },
  { ingredientId: 'kasuri-methi', substituteId: 'fenugreek', note: 'Tiny pinch of methi seeds instead', priority: 1 },
  { ingredientId: 'peanut', substituteId: 'cashew', note: 'Any neutral nut for crunch/body', priority: 1 },
];
