import * as SQLite from 'expo-sqlite';
import { LocalDbConfig } from '@/config/env';
import { SCHEMA_SQL } from './schema';

let db: SQLite.SQLiteDatabase | null = null;
let initPromise: Promise<SQLite.SQLiteDatabase> | null = null;

/** Open (or reuse) the single app database handle. Safe on Android/iOS/web. */
export function getDb(): SQLite.SQLiteDatabase {
  if (!db) {
    db = SQLite.openDatabaseSync(LocalDbConfig.databaseName);
  }
  return db;
}

/** Create tables if needed. Idempotent — safe to call on every launch. */
export async function initDb(): Promise<SQLite.SQLiteDatabase> {
  if (db) return db;
  if (initPromise) return initPromise;
  initPromise = (async () => {
    const handle = SQLite.openDatabaseSync(LocalDbConfig.databaseName);
    // execAsync runs the whole schema script atomically enough for init.
    await handle.execAsync(SCHEMA_SQL);
    db = handle;
    return handle;
  })();
  try {
    return await initPromise;
  } catch (e) {
    initPromise = null;
    throw e;
  }
}

export function closeDb() {
  db = null;
  initPromise = null;
}

// ─── Tiny typed helpers over expo-sqlite sync API ───

export function all<T>(sql: string, params: unknown[] = []): T[] {
  const handle = getDb();
  try {
    return handle.getAllSync<T>(sql, params as any);
  } catch {
    return [];
  }
}

export function first<T>(sql: string, params: unknown[] = []): T | null {
  const handle = getDb();
  try {
    return handle.getFirstSync<T>(sql, params as any) ?? null;
  } catch {
    return null;
  }
}

export function run(sql: string, params: unknown[] = []): void {
  const handle = getDb();
  handle.runSync(sql, params as any);
}

export async function getMeta(key: string): Promise<string | null> {
  const row = first<{ value: string }>('SELECT value FROM meta WHERE key = ?', [key]);
  return row?.value ?? null;
}

export async function setMeta(key: string, value: string): Promise<void> {
  run('INSERT INTO meta(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', [
    key,
    value,
  ]);
}
