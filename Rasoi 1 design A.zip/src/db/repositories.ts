/**
 * Repository layer — the ONLY place that touches SQLite directly.
 * UI talks to services/stores; services talk to these repositories.
 */
import { all, first, run } from '@/db/client';
import type {
  Ingredient,
  IngredientCategory,
  PantryItem,
  Recipe,
  RecipeIngredient,
  ShoppingItem,
  MealPlanEntry,
} from '@/types';

type IngredientRow = {
  id: string;
  name_en: string;
  name_hi: string | null;
  category: IngredientCategory;
  icon: string;
  unit: string;
  shelf_life_days: number | null;
  is_common: number;
  search_text: string;
};

function mapIngredient(r: IngredientRow): Ingredient {
  return {
    id: r.id,
    nameEn: r.name_en,
    nameHi: r.name_hi,
    category: r.category,
    icon: r.icon,
    unit: r.unit,
    shelfLifeDays: r.shelf_life_days,
    isCommon: r.is_common === 1,
    searchText: r.search_text,
  };
}

type RecipeRow = {
  id: string;
  title_en: string;
  title_hi: string | null;
  description: string | null;
  cuisine: string;
  diet: string;
  prep_min: number;
  cook_min: number;
  servings: number;
  difficulty: string;
  calories: number | null;
  protein_g: number | null;
  image_emoji: string;
  tags_json: string;
  steps_json: string;
  is_favorite: number;
};

function mapRecipe(r: RecipeRow): Recipe {
  return {
    id: r.id,
    titleEn: r.title_en,
    titleHi: r.title_hi,
    description: r.description,
    cuisine: r.cuisine,
    diet: r.diet as Recipe['diet'],
    prepMin: r.prep_min,
    cookMin: r.cook_min,
    servings: r.servings,
    difficulty: r.difficulty as Recipe['difficulty'],
    calories: r.calories,
    proteinG: r.protein_g,
    imageEmoji: r.image_emoji,
    tagsJson: r.tags_json,
    stepsJson: r.steps_json,
    isFavorite: r.is_favorite === 1,
  };
}

// ─── Ingredients ───

export const IngredientRepo = {
  listAll(): Ingredient[] {
    return all<IngredientRow>('SELECT * FROM ingredients ORDER BY is_common DESC, name_en ASC').map(mapIngredient);
  },
  listByCategory(category: IngredientCategory): Ingredient[] {
    return all<IngredientRow>('SELECT * FROM ingredients WHERE category = ? ORDER BY is_common DESC, name_en ASC', [
      category,
    ]).map(mapIngredient);
  },
  listCommon(): Ingredient[] {
    return all<IngredientRow>('SELECT * FROM ingredients WHERE is_common = 1 ORDER BY name_en ASC').map(mapIngredient);
  },
  search(query: string, limit = 40): Ingredient[] {
    const q = `%${query.trim().toLowerCase()}%`;
    if (!query.trim()) return this.listCommon().slice(0, limit);
    // Direct match + alias match in one query.
    return all<IngredientRow>(
      `SELECT DISTINCT i.* FROM ingredients i
       LEFT JOIN ingredient_aliases a ON a.ingredient_id = i.id
       WHERE i.search_text LIKE ? OR i.name_en LIKE ? OR i.name_hi LIKE ? OR a.alias LIKE ?
       ORDER BY i.is_common DESC, i.name_en ASC LIMIT ?`,
      [q, q, q, q, limit],
    ).map(mapIngredient);
  },
  getByIds(ids: string[]): Ingredient[] {
    if (ids.length === 0) return [];
    const ph = ids.map(() => '?').join(',');
    return all<IngredientRow>(`SELECT * FROM ingredients WHERE id IN (${ph})`, ids).map(mapIngredient);
  },
  getSubstitutes(ingredientId: string): Ingredient[] {
    return all<IngredientRow>(
      `SELECT i.* FROM substitutions s JOIN ingredients i ON i.id = s.substitute_id
       WHERE s.ingredient_id = ? ORDER BY s.priority ASC`,
      [ingredientId],
    ).map(mapIngredient);
  },
  categories(): Array<{ category: IngredientCategory; count: number }> {
    return all<{ category: IngredientCategory; count: number }>(
      'SELECT category, COUNT(*) as count FROM ingredients GROUP BY category ORDER BY count DESC',
    );
  },
};

// ─── Recipes ───

export const RecipeRepo = {
  listAll(limit = 100, offset = 0): Recipe[] {
    return all<RecipeRow>('SELECT * FROM recipes ORDER BY title_en ASC LIMIT ? OFFSET ?', [limit, offset]).map(mapRecipe);
  },
  count(): number {
    return first<{ n: number }>('SELECT COUNT(*) as n FROM recipes')?.n ?? 0;
  },
  getById(id: string): Recipe | null {
    const row = first<RecipeRow>('SELECT * FROM recipes WHERE id = ?', [id]);
    return row ? mapRecipe(row) : null;
  },
  search(query: string, diet: string = 'all', limit = 50): Recipe[] {
    const q = `%${query.trim().toLowerCase()}%`;
    const dietFilter = diet === 'all' ? '' : 'AND diet = ?';
    const params = query.trim()
      ? diet === 'all'
        ? [q, q, q, limit]
        : [q, q, q, diet, limit]
      : diet === 'all'
        ? [limit]
        : [diet, limit];
    const where = query.trim()
      ? `WHERE (LOWER(title_en) LIKE ? OR LOWER(title_hi) LIKE ? OR LOWER(tags_json) LIKE ?) ${dietFilter}`
      : diet === 'all'
        ? ''
        : 'WHERE diet = ?';
    return all<RecipeRow>(`SELECT * FROM recipes ${where} ORDER BY title_en ASC LIMIT ?`, params).map(mapRecipe);
  },
  getIngredients(recipeId: string): Array<RecipeIngredient & { ingredient: Ingredient }> {
    const rows = all<RecipeIngredient & IngredientRow>(
      `SELECT ri.*, i.name_en, i.name_hi, i.category, i.icon, i.unit as ing_unit, i.shelf_life_days, i.is_common, i.search_text
       FROM recipe_ingredients ri JOIN ingredients i ON i.id = ri.ingredient_id WHERE ri.recipe_id = ?`,
      [recipeId],
    );
    return rows.map((r: any) => ({
      recipeId: r.recipe_id,
      ingredientId: r.ingredient_id,
      qty: r.qty,
      unit: r.unit,
      optional: r.optional === 1,
      ingredient: {
        id: r.ingredient_id,
        nameEn: r.name_en,
        nameHi: r.name_hi,
        category: r.category,
        icon: r.icon,
        unit: r.ing_unit ?? r.unit ?? 'pcs',
        shelfLifeDays: r.shelf_life_days,
        isCommon: r.is_common === 1,
        searchText: r.search_text ?? '',
      },
    }));
  },
  toggleFavorite(id: string): boolean {
    const cur = first<{ is_favorite: number }>('SELECT is_favorite FROM recipes WHERE id = ?', [id]);
    const next = cur?.is_favorite === 1 ? 0 : 1;
    run('UPDATE recipes SET is_favorite = ?, updated_at = datetime(?) WHERE id = ?', [next, 'now', id]);
    return next === 1;
  },
  listFavorites(): Recipe[] {
    return all<RecipeRow>('SELECT * FROM recipes WHERE is_favorite = 1 ORDER BY title_en ASC').map(mapRecipe);
  },
};

// ─── Pantry (user-owned) ───

export const PantryRepo = {
  list(): PantryItem[] {
    const rows = all<any>(
      `SELECT p.*, i.name_en, i.name_hi, i.category, i.icon, i.unit as ing_unit, i.shelf_life_days, i.is_common
       FROM pantry_items p JOIN ingredients i ON i.id = p.ingredient_id ORDER BY p.updated_at DESC`,
    );
    return rows.map((r) => ({
      id: r.id,
      ingredientId: r.ingredient_id,
      qty: r.qty,
      unit: r.unit,
      expiryDate: r.expiry_date,
      location: r.location,
      updatedAt: r.updated_at,
      ingredient: {
        id: r.ingredient_id,
        nameEn: r.name_en,
        nameHi: r.name_hi,
        category: r.category,
        icon: r.icon,
        unit: r.ing_unit ?? 'pcs',
        shelfLifeDays: r.shelf_life_days,
        isCommon: r.is_common === 1,
        searchText: '',
      },
    }));
  },
  upsert(ingredientId: string, patch: Partial<Pick<PantryItem, 'qty' | 'unit' | 'expiryDate' | 'location'>> = {}) {
    run(
      `INSERT INTO pantry_items(ingredient_id, qty, unit, expiry_date, location, updated_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))
       ON CONFLICT(ingredient_id) DO UPDATE SET
         qty=COALESCE(excluded.qty, qty), unit=COALESCE(excluded.unit, unit),
         expiry_date=COALESCE(excluded.expiry_date, expiry_date), location=COALESCE(excluded.location, location),
         updated_at=datetime('now')`,
      [ingredientId, patch.qty ?? null, patch.unit ?? null, patch.expiryDate ?? null, patch.location ?? null],
    );
  },
  remove(ingredientId: string) {
    run('DELETE FROM pantry_items WHERE ingredient_id = ?', [ingredientId]);
  },
  clear() {
    run('DELETE FROM pantry_items');
  },
  ids(): string[] {
    return all<{ ingredient_id: string }>('SELECT ingredient_id FROM pantry_items').map((r) => r.ingredient_id);
  },
};

// ─── Shopping (user-owned) ───

export const ShoppingRepo = {
  list(): ShoppingItem[] {
    return all<any>('SELECT * FROM shopping_items ORDER BY checked ASC, created_at DESC').map((r) => ({
      id: r.id,
      name: r.name,
      ingredientId: r.ingredient_id,
      qty: r.qty,
      checked: r.checked === 1,
      recipeId: r.recipe_id,
      createdAt: r.created_at,
    }));
  },
  add(name: string, opts: Partial<Pick<ShoppingItem, 'ingredientId' | 'qty' | 'recipeId'>> = {}) {
    run('INSERT INTO shopping_items(name, ingredient_id, qty, recipe_id) VALUES (?, ?, ?, ?)', [
      name,
      opts.ingredientId ?? null,
      opts.qty ?? null,
      opts.recipeId ?? null,
    ]);
  },
  toggle(id: number) {
    run('UPDATE shopping_items SET checked = 1 - checked WHERE id = ?', [id]);
  },
  remove(id: number) {
    run('DELETE FROM shopping_items WHERE id = ?', [id]);
  },
  clearChecked() {
    run('DELETE FROM shopping_items WHERE checked = 1');
  },
};

// ─── Meal plan (user-owned) ───

export const MealPlanRepo = {
  listWeek(startIso: string, endIso: string): MealPlanEntry[] {
    const rows = all<any>(
      `SELECT m.*, r.title_en, r.title_hi, r.image_emoji, r.cuisine, r.diet, r.prep_min, r.cook_min, r.servings as r_serv,
              r.difficulty, r.calories, r.protein_g, r.tags_json, r.steps_json, r.description, r.is_favorite
       FROM meal_plan m JOIN recipes r ON r.id = m.recipe_id
       WHERE m.date BETWEEN ? AND ? ORDER BY m.date ASC`,
      [startIso, endIso],
    );
    return rows.map((r) => ({
      id: r.id,
      date: r.date,
      slot: r.slot,
      recipeId: r.recipe_id,
      servings: r.servings,
      recipe: {
        id: r.recipe_id,
        titleEn: r.title_en,
        titleHi: r.title_hi,
        description: r.description,
        cuisine: r.cuisine,
        diet: r.diet,
        prepMin: r.prep_min,
        cookMin: r.cook_min,
        servings: r.r_serv,
        difficulty: r.difficulty,
        calories: r.calories,
        proteinG: r.protein_g,
        imageEmoji: r.image_emoji,
        tagsJson: r.tags_json,
        stepsJson: r.steps_json,
        isFavorite: r.is_favorite === 1,
      },
    }));
  },
  set(date: string, slot: MealPlanEntry['slot'], recipeId: string, servings = 4) {
    run(
      `INSERT INTO meal_plan(date, slot, recipe_id, servings) VALUES (?, ?, ?, ?)
       ON CONFLICT(date, slot) DO UPDATE SET recipe_id=excluded.recipe_id, servings=excluded.servings`,
      [date, slot, recipeId, servings],
    );
  },
  remove(date: string, slot: string) {
    run('DELETE FROM meal_plan WHERE date = ? AND slot = ?', [date, slot]);
  },
};
