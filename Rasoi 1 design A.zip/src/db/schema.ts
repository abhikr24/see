/**
 * SQLite schema — LOCAL food data + USER-owned data.
 *
 * NEVER synced wholesale: recipes / ingredients / taxonomy / aliases /
 * substitutions live ONLY here. Supabase mirrors only user-owned rows
 * (pantry, favorites, meal plans, shopping) when signed in.
 */
export const SCHEMA_SQL = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ─── Catalogue (bundled, read-only) ───
CREATE TABLE IF NOT EXISTS ingredients (
  id TEXT PRIMARY KEY,
  name_en TEXT NOT NULL,
  name_hi TEXT,
  category TEXT NOT NULL,
  icon TEXT NOT NULL DEFAULT '🥬',
  unit TEXT NOT NULL DEFAULT 'pcs',
  shelf_life_days INTEGER,
  is_common INTEGER NOT NULL DEFAULT 0,
  search_text TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_ingredients_category ON ingredients(category);
CREATE INDEX IF NOT EXISTS idx_ingredients_common ON ingredients(is_common);
CREATE INDEX IF NOT EXISTS idx_ingredients_search ON ingredients(search_text);

CREATE TABLE IF NOT EXISTS ingredient_aliases (
  alias TEXT NOT NULL,
  ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  locale TEXT NOT NULL DEFAULT 'en',
  PRIMARY KEY (alias, ingredient_id, locale)
);
CREATE INDEX IF NOT EXISTS idx_aliases_alias ON ingredient_aliases(alias);

CREATE TABLE IF NOT EXISTS substitutions (
  ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  substitute_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
  note TEXT,
  priority INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (ingredient_id, substitute_id)
);

CREATE TABLE IF NOT EXISTS recipes (
  id TEXT PRIMARY KEY,
  title_en TEXT NOT NULL,
  title_hi TEXT,
  description TEXT,
  cuisine TEXT NOT NULL DEFAULT 'North Indian',
  diet TEXT NOT NULL DEFAULT 'veg',
  prep_min INTEGER NOT NULL DEFAULT 10,
  cook_min INTEGER NOT NULL DEFAULT 20,
  servings INTEGER NOT NULL DEFAULT 4,
  difficulty TEXT NOT NULL DEFAULT 'easy',
  calories INTEGER,
  protein_g REAL,
  image_emoji TEXT NOT NULL DEFAULT '🍛',
  tags_json TEXT NOT NULL DEFAULT '[]',
  steps_json TEXT NOT NULL DEFAULT '[]',
  is_favorite INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_recipes_diet ON recipes(diet);
CREATE INDEX IF NOT EXISTS idx_recipes_cuisine ON recipes(cuisine);
CREATE INDEX IF NOT EXISTS idx_recipes_fav ON recipes(is_favorite);

CREATE TABLE IF NOT EXISTS recipe_ingredients (
  recipe_id TEXT NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
  ingredient_id TEXT NOT NULL REFERENCES ingredients(id),
  qty TEXT,
  unit TEXT,
  optional INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (recipe_id, ingredient_id)
);
CREATE INDEX IF NOT EXISTS idx_ri_recipe ON recipe_ingredients(recipe_id);
CREATE INDEX IF NOT EXISTS idx_ri_ingredient ON recipe_ingredients(ingredient_id);

-- ─── User-owned (offline-first, optionally cloud-mirrored) ───
CREATE TABLE IF NOT EXISTS pantry_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ingredient_id TEXT NOT NULL REFERENCES ingredients(id),
  qty REAL,
  unit TEXT,
  expiry_date TEXT,
  location TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(ingredient_id)
);
CREATE INDEX IF NOT EXISTS idx_pantry_expiry ON pantry_items(expiry_date);

CREATE TABLE IF NOT EXISTS shopping_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  ingredient_id TEXT REFERENCES ingredients(id),
  qty TEXT,
  checked INTEGER NOT NULL DEFAULT 0,
  recipe_id TEXT REFERENCES recipes(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS meal_plan (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  slot TEXT NOT NULL,
  recipe_id TEXT NOT NULL REFERENCES recipes(id),
  servings INTEGER NOT NULL DEFAULT 4,
  UNIQUE(date, slot)
);
CREATE INDEX IF NOT EXISTS idx_meal_date ON meal_plan(date);

CREATE TABLE IF NOT EXISTS user_recipes (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  body_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  dirty INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`;
