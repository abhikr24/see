/**
 * One-time (versioned) seed of bundled catalogue into SQLite.
 * Safe to call on every launch — no-ops when seed version matches.
 */
import { getDb, getMeta, setMeta } from '@/db/client';
import { LocalDbConfig } from '@/config/env';
import { SEED_INGREDIENTS } from '@/data/ingredients';
import { SEED_ALIASES } from '@/data/aliases';
import { SEED_SUBSTITUTIONS } from '@/data/substitutions';
import { SEED_RECIPES } from '@/data/recipes';

export async function seedDatabase(): Promise<{ seeded: boolean }> {
  const done = await getMeta('seed_version');
  if (done === String(LocalDbConfig.seedVersion)) return { seeded: false };

  const db = getDb();
  // Use a transaction for fast bulk seed (sync API).
  try {
    db.withTransactionSync(() => {
      for (const ing of SEED_INGREDIENTS) {
        const searchText =
          `${ing.nameEn} ${ing.nameHi} ${ing.id.replace(/-/g, ' ')}`.toLowerCase();
        db.runSync(
          `INSERT INTO ingredients(id, name_en, name_hi, category, icon, unit, shelf_life_days, is_common, search_text)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name_en=excluded.name_en, name_hi=excluded.name_hi, category=excluded.category,
             icon=excluded.icon, unit=excluded.unit, shelf_life_days=excluded.shelf_life_days,
             is_common=excluded.is_common, search_text=excluded.search_text`,
          [ing.id, ing.nameEn, ing.nameHi, ing.category, ing.icon, ing.unit, ing.shelfLifeDays, ing.isCommon ? 1 : 0, searchText],
        );
      }
      for (const a of SEED_ALIASES) {
        db.runSync(
          `INSERT INTO ingredient_aliases(alias, ingredient_id, locale) VALUES (?, ?, ?)
           ON CONFLICT(alias, ingredient_id, locale) DO NOTHING`,
          [a.alias.toLowerCase(), a.ingredientId, a.locale],
        );
      }
      for (const s of SEED_SUBSTITUTIONS) {
        db.runSync(
          `INSERT INTO substitutions(ingredient_id, substitute_id, note, priority) VALUES (?, ?, ?, ?)
           ON CONFLICT(ingredient_id, substitute_id) DO UPDATE SET note=excluded.note, priority=excluded.priority`,
          [s.ingredientId, s.substituteId, s.note, s.priority],
        );
      }
      for (const r of SEED_RECIPES) {
        db.runSync(
          `INSERT INTO recipes(id, title_en, title_hi, description, cuisine, diet, prep_min, cook_min, servings, difficulty, calories, protein_g, image_emoji, tags_json, steps_json)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             title_en=excluded.title_en, title_hi=excluded.title_hi, description=excluded.description,
             cuisine=excluded.cuisine, diet=excluded.diet, prep_min=excluded.prep_min,
             cook_min=excluded.cook_min, servings=excluded.servings, difficulty=excluded.difficulty,
             calories=excluded.calories, protein_g=excluded.protein_g, image_emoji=excluded.image_emoji,
             tags_json=excluded.tags_json, steps_json=excluded.steps_json`,
          [
            r.id, r.titleEn, r.titleHi, r.description, r.cuisine, r.diet,
            r.prepMin, r.cookMin, r.servings, r.difficulty, r.calories, r.proteinG,
            r.imageEmoji, JSON.stringify(r.tags), JSON.stringify(r.steps),
          ],
        );
        for (const ri of r.ingredients) {
          db.runSync(
            `INSERT INTO recipe_ingredients(recipe_id, ingredient_id, qty, unit, optional) VALUES (?, ?, ?, ?, ?)
             ON CONFLICT(recipe_id, ingredient_id) DO UPDATE SET qty=excluded.qty, unit=excluded.unit, optional=excluded.optional`,
            [r.id, ri.ingredientId, ri.qty, ri.unit, ri.optional ? 1 : 0],
          );
        }
      }
      db.runSync(
        `INSERT INTO meta(key, value) VALUES ('seed_version', ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value`,
        [String(LocalDbConfig.seedVersion)],
      );
    });
  } catch (e) {
    // Fallback: non-transactional seed (older web builds lack withTransactionSync)
    for (const ing of SEED_INGREDIENTS) {
      const searchText = `${ing.nameEn} ${ing.nameHi} ${ing.id.replace(/-/g, ' ')}`.toLowerCase();
      db.runSync(
        `INSERT OR REPLACE INTO ingredients(id, name_en, name_hi, category, icon, unit, shelf_life_days, is_common, search_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [ing.id, ing.nameEn, ing.nameHi, ing.category, ing.icon, ing.unit, ing.shelfLifeDays, ing.isCommon ? 1 : 0, searchText],
      );
    }
    await setMeta('seed_version', String(LocalDbConfig.seedVersion));
    void e;
  }
  return { seeded: true };
}
