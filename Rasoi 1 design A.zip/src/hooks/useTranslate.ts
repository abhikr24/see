import { useAppStore } from '@/store';
import { translate, type I18nKey, type Locale } from '@/i18n';

/** Tiny typed translation hook wired to global settings locale. */
export function useTranslate() {
  const locale = useAppStore((s) => s.settings.locale) as Locale;
  const t = (key: I18nKey, params?: Record<string, string | number>) => translate(locale, key, params);
  return { t, locale };
}
