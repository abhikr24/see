import en from './en';
import hi from './hi';

export const resources = { en, hi } as const;
export type I18nKey = keyof typeof en;
export type Locale = keyof typeof resources;

export function translate(locale: Locale, key: I18nKey, params?: Record<string, string | number>): string {
  const table = resources[locale] ?? resources.en;
  let s: string = (table as any)[key] ?? (resources.en as any)[key] ?? key;
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      s = s.replace(`{{${k}}}`, String(v));
    }
  }
  return s;
}
