import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useAppTheme } from '@/theme';
import type { RootStackParamList, TabParamList } from './types';
import { HomeScreen } from '@/screens/HomeScreen';
import { IngredientsScreen } from '@/screens/IngredientsScreen';
import { PantryScreen } from '@/screens/PantryScreen';
import { RecipesScreen } from '@/screens/RecipesScreen';
import { RecipeDetailScreen } from '@/screens/RecipeDetailScreen';
import { ShoppingScreen } from '@/screens/ShoppingScreen';
import { PlannerScreen } from '@/screens/PlannerScreen';
import { ProfileScreen } from '@/screens/ProfileScreen';
import { useTranslate } from '@/hooks';

const Tab = createBottomTabNavigator<TabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

function MainTabs() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.line,
          borderTopWidth: 1,
          height: 62,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: { fontSize: 9.5, fontWeight: '700' },
        tabBarIcon: ({ color, size, focused }) => {
          const map: Record<string, keyof typeof Ionicons.glyphMap> = {
            Home: focused ? 'home' : 'home-outline',
            Cook: focused ? 'restaurant' : 'restaurant-outline',
            Pantry: focused ? 'basket' : 'basket-outline',
            Recipes: focused ? 'book' : 'book-outline',
            Shopping: focused ? 'cart' : 'cart-outline',
            Planner: focused ? 'calendar' : 'calendar-outline',
            Profile: focused ? 'person' : 'person-outline',
          };
          return <Ionicons name={map[route.name] ?? 'ellipse'} size={size ?? 22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: t('tabs.home') }} />
      <Tab.Screen name="Cook" component={IngredientsScreen} options={{ title: t('tabs.ingredients') }} />
      <Tab.Screen name="Pantry" component={PantryScreen} options={{ title: t('tabs.pantry') }} />
      <Tab.Screen name="Recipes" component={RecipesScreen} options={{ title: t('tabs.recipes') }} />
      <Tab.Screen name="Shopping" component={ShoppingScreen} options={{ title: t('tabs.shopping') }} />
      <Tab.Screen name="Planner" component={PlannerScreen} options={{ title: t('tabs.planner') }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: t('tabs.profile') }} />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  const { colors } = useAppTheme();
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.bg },
        headerTintColor: colors.ink,
        headerTitleStyle: { fontWeight: '800' },
        headerShadowVisible: false,
        contentStyle: { backgroundColor: colors.bg },
      }}
    >
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen
        name="RecipeDetail"
        component={RecipeDetailScreen}
        options={{ title: 'Recipe', headerBackTitle: 'Back' }}
      />
    </Stack.Navigator>
  );
}
