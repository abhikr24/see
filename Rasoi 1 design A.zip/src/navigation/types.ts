import type { NavigatorScreenParams } from '@react-navigation/native';

export type TabParamList = {
  Home: undefined;
  Cook: undefined;
  Pantry: undefined;
  Recipes: undefined;
  Shopping: undefined;
  Planner: undefined;
  Profile: undefined;
};

export type RootStackParamList = {
  MainTabs: NavigatorScreenParams<TabParamList> | undefined;
  RecipeDetail: { recipeId: string };
};
