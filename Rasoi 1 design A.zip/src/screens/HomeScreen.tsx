import React, { useCallback, useState } from 'react';
import { RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing, shadow } from '@/theme/tokens';
import { useAppStore } from '@/store';
import { useTranslate } from '@/hooks';
import { PantryRepo, RecipeRepo } from '@/db/repositories';
import { matchRecipes } from '@/services/matching';
import { sortByExpiry, expiryStatus } from '@/services/expiry';
import { Button, RecipeCard, SectionHeader, Pill } from '@/components';
import type { PantryItem, Recipe } from '@/types';

export function HomeScreen() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  const navigation = useNavigation<any>();
  const selectedIds = useAppStore((s) => s.selectedIds);
  const diet = useAppStore((s) => s.settings.dietPreference);
  const [refreshing, setRefreshing] = useState(false);
  const [version, setVersion] = useState(0);
  const [pantry, setPantry] = useState<PantryItem[]>([]);
  const [picks, setPicks] = useState<ReturnType<typeof matchRecipes>>([]);
  const [totalRecipes, setTotalRecipes] = useState(0);

  const reload = useCallback(() => {
    try {
      const p = PantryRepo.list();
      setPantry(p);
      const base = p.length > 0 ? p.map((x) => x.ingredientId) : selectedIds;
      setPicks(matchRecipes(base, { diet, limit: 6 }));
      setTotalRecipes(RecipeRepo.count());
    } catch {
      /* db not ready yet */
    }
  }, [selectedIds, diet]);

  useFocusEffect(
    useCallback(() => {
      reload();
    }, [reload, version]),
  );

  const onRefresh = () => {
    setRefreshing(true);
    reload();
    setVersion((v) => v + 1);
    setTimeout(() => setRefreshing(false), 500);
  };

  const useSoon = sortByExpiry(pantry).filter((i) => {
    const s = expiryStatus(i);
    return s === 'expired' || s === 'use-soon';
  }).slice(0, 4);

  const cookNow = picks.filter((p) => p.canCook).slice(0, 3);
  const almost = picks.filter((p) => !p.canCook).slice(0, 3);
  const heroList = [...cookNow, ...almost].slice(0, 4);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
        showsVerticalScrollIndicator={false}
      >
        {/* Greeting */}
        <Text style={[styles.greet, { color: colors.inkSoft }]}>{t('home.greeting')}</Text>
        <Text style={[styles.hero, { color: colors.ink }]}>{t('home.heroTitle')}</Text>
        <Text style={[styles.sub, { color: colors.inkSoft }]}>{t('home.heroSub')}</Text>

        {/* Hero card */}
        <View style={[styles.heroCard, { backgroundColor: colors.primary }]}>
          <View style={styles.heroRow}>
            <Text style={styles.heroEmoji}>🍛</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.heroCardTitle}>{t('app.tagline')}</Text>
              <Text style={styles.heroCardSub}>
                {pantry.length > 0
                  ? t('pantry.subtitle', { count: pantry.length })
                  : t('home.emptyPantrySub')}
                {'  •  '}
                {totalRecipes} recipes offline
              </Text>
            </View>
          </View>
          <View style={styles.heroBtns}>
            <Button label={t('home.ctaCook')} onPress={() => navigation.navigate('Cook')} variant="soft" style={styles.heroBtn} />
            <Button
              label={t('home.ctaPantry')}
              onPress={() => navigation.navigate('Pantry')}
              variant="outline"
              style={styles.heroBtnGhost}
            />
          </View>
          <Text style={styles.offlineBadge}>{t('home.offlineBadge')}</Text>
        </View>

        {/* Use soon */}
        <SectionHeader title={t('home.useSoon')} action={useSoon.length > 0 ? <Pill text={`${useSoon.length}`} tone="amber" /> : undefined} />
        {useSoon.length === 0 ? (
          <View style={[styles.noteCard, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <Text style={styles.noteEmoji}>🧺</Text>
            <View style={{ flex: 1 }}>
              <Text style={[styles.noteTitle, { color: colors.ink }]}>{t('home.emptyPantry')}</Text>
              <Text style={[styles.noteSub, { color: colors.inkSoft }]}>{t('home.emptyPantrySub')}</Text>
            </View>
          </View>
        ) : (
          <View style={styles.chipRow}>
            {useSoon.map((i) => {
              const s = expiryStatus(i);
              return (
                <View key={i.ingredientId} style={[styles.chip, { backgroundColor: colors.card, borderColor: colors.line }]}>
                  <Text style={styles.chipEmoji}>{i.ingredient?.icon ?? '🥬'}</Text>
                  <Text style={[styles.chipName, { color: colors.ink }]} numberOfLines={1}>
                    {i.ingredient?.nameEn}
                  </Text>
                  <Pill text={s === 'expired' ? t('pantry.expired') : t('pantry.useSoon')} tone={s === 'expired' ? 'red' : 'amber'} />
                </View>
              );
            })}
          </View>
        )}

        {/* Tonight's picks */}
        <SectionHeader
          title={t('home.quickDinner')}
          action={
            <Text style={[styles.link, { color: colors.primary }]} onPress={() => navigation.navigate('Cook')}>
              {t('home.browseAll')} →
            </Text>
          }
        />
        <View style={styles.list}>
          {heroList.map((m) => (
            <RecipeCard
              key={m.recipe.id}
              recipe={m.recipe as Recipe}
              matchPct={m.matchPct}
              missingCount={m.missingCount}
              onPress={() => navigation.navigate('RecipeDetail', { recipeId: m.recipe.id })}
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  greet: { fontSize: fontSize.md, fontWeight: '700' },
  hero: { fontSize: fontSize.hero, fontWeight: '900', letterSpacing: -0.6, marginTop: 2 },
  sub: { fontSize: fontSize.md, lineHeight: 21, marginTop: 6 },
  heroCard: { borderRadius: radius.xl, padding: spacing.lg, marginTop: spacing.lg, ...shadow.pop },
  heroRow: { flexDirection: 'row', gap: spacing.md, alignItems: 'center' },
  heroEmoji: { fontSize: 46 },
  heroCardTitle: { color: '#fff', fontSize: fontSize.xl, fontWeight: '900' },
  heroCardSub: { color: 'rgba(255,255,255,0.85)', fontSize: fontSize.sm, marginTop: 4, lineHeight: 18 },
  heroBtns: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  heroBtn: { flex: 1, backgroundColor: '#fff' },
  heroBtnGhost: { backgroundColor: 'transparent', borderColor: 'rgba(255,255,255,0.6)' },
  offlineBadge: { color: 'rgba(255,255,255,0.75)', fontSize: fontSize.xs, fontWeight: '700', marginTop: spacing.sm },
  noteCard: { flexDirection: 'row', borderWidth: 1, borderRadius: radius.lg, padding: spacing.md, gap: spacing.md, alignItems: 'center' },
  noteEmoji: { fontSize: 30 },
  noteTitle: { fontSize: fontSize.md, fontWeight: '800' },
  noteSub: { fontSize: fontSize.sm, marginTop: 2, lineHeight: 18 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: radius.pill, paddingVertical: 8, paddingHorizontal: 10, maxWidth: '48%' },
  chipEmoji: { fontSize: 18 },
  chipName: { fontSize: fontSize.sm, fontWeight: '700', flexShrink: 1 },
  list: { gap: spacing.md },
  link: { fontSize: fontSize.sm, fontWeight: '800' },
});
