import React, { useCallback, useMemo, useState } from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing } from '@/theme/tokens';
import { useAppStore } from '@/store';
import { useTranslate } from '@/hooks';
import { IngredientRepo, PantryRepo } from '@/db/repositories';
import { matchRecipes } from '@/services/matching';
import { IngredientTile, RecipeCard, EmptyState, Button, Pill } from '@/components';
import type { Ingredient, IngredientCategory } from '@/types';

const CATS: Array<{ id: IngredientCategory | 'all'; label: string; icon: string }> = [
  { id: 'all', label: 'All', icon: '🧺' },
  { id: 'vegetables', label: 'Veg', icon: '🥬' },
  { id: 'pulses_lentils', label: 'Dal', icon: '🫘' },
  { id: 'grains_cereals', label: 'Grains', icon: '🌾' },
  { id: 'dairy', label: 'Dairy', icon: '🥛' },
  { id: 'spices', label: 'Spices', icon: '🧂' },
  { id: 'herbs', label: 'Herbs', icon: '🌿' },
  { id: 'oils_fats', label: 'Oils', icon: '🫗' },
  { id: 'fruits', label: 'Fruit', icon: '🍋' },
  { id: 'nuts_seeds', label: 'Nuts', icon: '🥜' },
];

export function IngredientsScreen() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  const navigation = useNavigation<any>();
  const selectedIds = useAppStore((s) => s.selectedIds);
  const toggle = useAppStore((s) => s.toggleIngredient);
  const clear = useAppStore((s) => s.clearSelected);
  const diet = useAppStore((s) => s.settings.dietPreference);
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<string>('all');
  const [tick, setTick] = useState(0);

  useFocusEffect(useCallback(() => setTick((v) => v + 1), []));
  void tick;

  const grid: Ingredient[] = useMemo(() => {
    try {
      if (query.trim()) return IngredientRepo.search(query, 60);
      if (cat === 'all') return IngredientRepo.listAll().slice(0, 60);
      return IngredientRepo.listByCategory(cat as IngredientCategory);
    } catch {
      return [];
    }
  }, [query, cat]);

  const matches = useMemo(() => {
    try {
      return matchRecipes(selectedIds, { diet, limit: 30 });
    } catch {
      return [];
    }
  }, [selectedIds, diet]);

  const cookNow = matches.filter((m) => m.canCook);
  const almost = matches.filter((m) => !m.canCook);

  const saveToPantry = () => {
    try {
      selectedIds.forEach((id) => PantryRepo.upsert(id));
      navigation.navigate('Pantry');
    } catch { /* noop */ }
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <FlatList
        data={[...cookNow.slice(0, 4), ...almost.slice(0, 8)]}
        keyExtractor={(m) => m.recipe.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View>
            <Text style={[styles.title, { color: colors.ink }]}>{t('cook.title')}</Text>
            <Text style={[styles.sub, { color: colors.inkSoft }]}>
              {t('cook.subtitle', { count: selectedIds.length })}
            </Text>
            <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.line }]}>
              <Text style={styles.searchIcon}>🔍</Text>
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder={t('cook.searchPh')}
                placeholderTextColor={colors.muted}
                style={[styles.input, { color: colors.ink }]}
                returnKeyType="search"
              />
              {query.length > 0 && (
                <Text onPress={() => setQuery('')} style={[styles.clearX, { color: colors.muted }]}>✕</Text>
              )}
            </View>
            <FlatList
              horizontal
              data={CATS}
              keyExtractor={(c) => c.id}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cats}
              renderItem={({ item }) => {
                const active = cat === item.id;
                return (
                  <Text
                    onPress={() => setCat(item.id)}
                    style={[
                      styles.cat,
                      { backgroundColor: active ? colors.primary : colors.card, color: active ? '#fff' : colors.inkSoft, borderColor: colors.line },
                    ]}
                  >
                    {item.icon} {item.label}
                  </Text>
                );
              }}
            />
            <View style={styles.grid}>
              {grid.map((g) => (
                <View key={g.id} style={styles.cell}>
                  <IngredientTile item={g} selected={selectedIds.includes(g.id)} onToggle={() => toggle(g.id)} />
                </View>
              ))}
            </View>
            {selectedIds.length > 0 && (
              <View style={styles.selBar}>
                <Button label={t('cook.clear')} variant="soft" onPress={clear} style={{ flex: 1 }} />
                <Button label={t('cook.savePantry')} onPress={saveToPantry} style={{ flex: 2 }} />
              </View>
            )}
            <View style={styles.resHead}>
              <Text style={[styles.resTitle, { color: colors.ink }]}>
                {t('cook.results')} ({matches.length})
              </Text>
              {cookNow.length > 0 && <Pill text={`${cookNow.length} ${t('cook.canCook')}`} tone="green" />}
            </View>
          </View>
        }
        renderItem={({ item: m }) => (
          <RecipeCard
            recipe={m.recipe}
            matchPct={m.matchPct}
            missingCount={m.missingCount}
            onPress={() => navigation.navigate('RecipeDetail', { recipeId: m.recipe.id })}
          />
        )}
        ListEmptyComponent={
          <EmptyState icon="🍳" title={t('cook.emptyPick')} subtitle={t('app.subtitle')} />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  list: { padding: spacing.lg, paddingBottom: 40, gap: spacing.md },
  title: { fontSize: fontSize.xxl, fontWeight: '900', letterSpacing: -0.4 },
  sub: { fontSize: fontSize.sm, marginTop: 4, fontWeight: '600' },
  search: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    marginTop: spacing.md,
    height: 48,
    gap: 8,
  },
  searchIcon: { fontSize: 16 },
  input: { flex: 1, fontSize: fontSize.md },
  clearX: { fontSize: 16, padding: 4 },
  cats: { gap: 8, paddingVertical: spacing.md },
  cat: { borderWidth: 1, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 8, fontSize: fontSize.sm, fontWeight: '800', overflow: 'hidden', marginRight: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cell: { width: '31%' },
  selBar: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  resHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: spacing.lg, marginBottom: 2 },
  resTitle: { fontSize: fontSize.xl, fontWeight: '800' },
});
