import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing } from '@/theme/tokens';
import { useTranslate } from '@/hooks';
import { IngredientRepo, PantryRepo } from '@/db/repositories';
import { expiryStatus } from '@/services/expiry';
import { EmptyState, Pill } from '@/components';
import type { PantryItem } from '@/types';

export function PantryScreen() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  const [items, setItems] = useState<PantryItem[]>([]);
  const [modal, setModal] = useState(false);
  const [q, setQ] = useState('');

  const reload = useCallback(() => {
    try {
      setItems(PantryRepo.list());
    } catch { /* noop */ }
  }, []);
  useFocusEffect(useCallback(() => reload(), [reload]));

  const results = useMemo(() => {
    try {
      return IngredientRepo.search(q, 30);
    } catch {
      return [];
    }
  }, [q]);

  const stocked = new Set(items.map((i) => i.ingredientId));

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <View style={styles.head}>
        <View>
          <Text style={[styles.title, { color: colors.ink }]}>{t('pantry.title')}</Text>
          <Text style={[styles.sub, { color: colors.inkSoft }]}>{t('pantry.subtitle', { count: items.length })}</Text>
        </View>
        <Pressable onPress={() => setModal(true)} style={[styles.addBtn, { backgroundColor: colors.primary }]}>
          <Text style={styles.addTxt}>+ {t('pantry.add')}</Text>
        </Pressable>
      </View>
      <FlatList
        data={items}
        keyExtractor={(i) => String(i.id)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyState icon="🧺" title={t('pantry.empty')} subtitle={t('pantry.emptySub')} />}
        renderItem={({ item }) => {
          const s = expiryStatus(item);
          return (
            <View style={[styles.row, { backgroundColor: colors.card, borderColor: colors.line }]}>
              <Text style={styles.emoji}>{item.ingredient?.icon ?? '🥬'}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.name, { color: colors.ink }]}>{item.ingredient?.nameEn}</Text>
                <Text style={[styles.meta, { color: colors.muted }]}>
                  {item.expiryDate ? `Expires ${item.expiryDate}` : 'No expiry set'}
                </Text>
              </View>
              <Pill text={s === 'expired' ? t('pantry.expired') : s === 'use-soon' ? t('pantry.useSoon') : s === 'fresh' ? t('pantry.fresh') : '—'} tone={s === 'expired' ? 'red' : s === 'use-soon' ? 'amber' : s === 'fresh' ? 'green' : 'neutral'} />
              <Text
                onPress={() => {
                  PantryRepo.remove(item.ingredientId);
                  reload();
                }}
                style={[styles.del, { color: colors.chili }]}
              >
                ✕
              </Text>
            </View>
          );
        }}
      />
      <Modal visible={modal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setModal(false)}>
        <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]}>
          <View style={styles.head}>
            <Text style={[styles.title, { color: colors.ink }]}>{t('pantry.add')}</Text>
            <Text onPress={() => setModal(false)} style={[styles.link, { color: colors.primary }]}>{t('common.done')}</Text>
          </View>
          <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <TextInput value={q} onChangeText={setQ} placeholder={t('cook.searchPh')} placeholderTextColor={colors.muted} style={[styles.input, { color: colors.ink }]} autoFocus />
          </View>
          <FlatList
            data={results}
            keyExtractor={(i) => i.id}
            contentContainerStyle={styles.list}
            renderItem={({ item }) => {
              const has = stocked.has(item.id);
              return (
                <Pressable
                  onPress={() => {
                    if (has) PantryRepo.remove(item.id);
                    else PantryRepo.upsert(item.id);
                    reload();
                  }}
                  style={[styles.row, { backgroundColor: has ? colors.primarySoft : colors.card, borderColor: colors.line }]}
                >
                  <Text style={styles.emoji}>{item.icon}</Text>
                  <Text style={[styles.name, { color: colors.ink, flex: 1 }]}>{item.nameEn}</Text>
                  <Text style={{ color: has ? colors.primary : colors.muted, fontWeight: '900' }}>{has ? '✓' : '+'}</Text>
                </Pressable>
              );
            }}
          />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: spacing.lg, paddingBottom: spacing.sm },
  title: { fontSize: fontSize.xxl, fontWeight: '900' },
  sub: { fontSize: fontSize.sm, marginTop: 2, fontWeight: '600' },
  link: { fontSize: fontSize.md, fontWeight: '800' },
  addBtn: { borderRadius: radius.pill, paddingHorizontal: 16, paddingVertical: 10 },
  addTxt: { color: '#fff', fontWeight: '800', fontSize: fontSize.sm },
  list: { padding: spacing.lg, paddingTop: spacing.sm, gap: spacing.sm, paddingBottom: 40 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, borderWidth: 1, borderRadius: radius.lg, padding: spacing.md },
  emoji: { fontSize: 26 },
  name: { fontSize: fontSize.md, fontWeight: '800' },
  meta: { fontSize: fontSize.xs, marginTop: 2 },
  del: { fontSize: 16, padding: 6, fontWeight: '800' },
  search: { flexDirection: 'row', borderWidth: 1, borderRadius: radius.pill, marginHorizontal: spacing.lg, paddingHorizontal: spacing.md, height: 48, alignItems: 'center' },
  input: { flex: 1, fontSize: fontSize.md },
});
