import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing } from '@/theme/tokens';
import { useTranslate } from '@/hooks';
import { MealPlanRepo, RecipeRepo } from '@/db/repositories';
import { EmptyState } from '@/components';
import { addDays, startOfWeekMonday, toISODate, WEEKDAY_SHORT, weekDates } from '@/utils';
import type { MealPlanEntry, Recipe } from '@/types';

const SLOTS = ['breakfast', 'lunch', 'snack', 'dinner'] as const;
type Slot = (typeof SLOTS)[number];

export function PlannerScreen() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  const navigation = useNavigation<any>();
  const [weekOffset, setWeekOffset] = useState(0);
  const [entries, setEntries] = useState<MealPlanEntry[]>([]);
  const [picker, setPicker] = useState<{ date: string; slot: Slot } | null>(null);
  const [q, setQ] = useState('');

  const monday = useMemo(() => addDays(startOfWeekMonday(new Date()), weekOffset * 7), [weekOffset]);
  const days = useMemo(() => weekDates(monday), [monday]);
  const startIso = toISODate(days[0]);
  const endIso = toISODate(days[6]);

  const reload = useCallback(() => {
    try {
      setEntries(MealPlanRepo.listWeek(startIso, endIso));
    } catch { /* noop */ }
  }, [startIso, endIso]);
  useFocusEffect(useCallback(() => reload(), [reload]));

  const byDaySlot = useMemo(() => {
    const m = new Map<string, MealPlanEntry>();
    entries.forEach((e) => m.set(`${e.date}|${e.slot}`, e));
    return m;
  }, [entries]);

  const searchResults: Recipe[] = useMemo(() => {
    try {
      return RecipeRepo.search(q, 'all', 20);
    } catch {
      return [];
    }
  }, [q]);

  const pick = (r: Recipe) => {
    if (!picker) return;
    try {
      MealPlanRepo.set(picker.date, picker.slot, r.id);
      setPicker(null);
      setQ('');
      reload();
    } catch { /* noop */ }
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <View style={styles.head}>
        <Text style={[styles.title, { color: colors.ink }]}>{t('planner.title')}</Text>
        <View style={styles.weekNav}>
          <Text onPress={() => setWeekOffset((v) => v - 1)} style={[styles.navBtn, { color: colors.primary }]}>‹ Prev</Text>
          <Text style={[styles.weekLabel, { color: colors.inkSoft }]}>
            {days[0].getDate()} – {days[6].getDate()} {days[6].toLocaleString('default', { month: 'short' })}
          </Text>
          <Text onPress={() => setWeekOffset((v) => v + 1)} style={[styles.navBtn, { color: colors.primary }]}>Next ›</Text>
        </View>
      </View>
      <FlatList
        data={days}
        keyExtractor={(d) => toISODate(d)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item: day, index }) => {
          const iso = toISODate(day);
          const isToday = toISODate(new Date()) === iso;
          return (
            <View style={[styles.dayCard, { backgroundColor: colors.card, borderColor: isToday ? colors.primary : colors.line }] as any}>
              <View style={styles.dayHead}>
                <Text style={[styles.dayName, { color: colors.ink }]}>
                  {WEEKDAY_SHORT[index]} <Text style={{ color: colors.muted }}>{day.getDate()}</Text>
                </Text>
                {isToday && <Text style={[styles.today, { backgroundColor: colors.primary }]}>Today</Text>}
              </View>
              {SLOTS.map((slot) => {
                const e = byDaySlot.get(`${iso}|${slot}`);
                return (
                  <Pressable
                    key={slot}
                    onPress={() => setPicker({ date: iso, slot })}
                    onLongPress={() => {
                      if (e) {
                        MealPlanRepo.remove(iso, slot);
                        reload();
                      }
                    }}
                    style={[styles.slot, { backgroundColor: colors.bg, borderColor: colors.line }]}
                  >
                    <Text style={[styles.slotLabel, { color: colors.muted }]}>{t(`slot.${slot}` as any)}</Text>
                    {e?.recipe ? (
                      <View style={styles.mealRow}>
                        <Text style={styles.mealEmoji}>{e.recipe.imageEmoji}</Text>
                        <Text style={[styles.mealName, { color: colors.ink }]} numberOfLines={1}>
                          {e.recipe.titleEn}
                        </Text>
                      </View>
                    ) : (
                      <Text style={[styles.empty, { color: colors.muted }]}>+ {t('planner.emptyDay')}</Text>
                    )}
                  </Pressable>
                );
              })}
            </View>
          );
        }}
      />
      <Modal visible={!!picker} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setPicker(null)}>
        <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]}>
          <View style={styles.head}>
            <Text style={[styles.title, { color: colors.ink }]}>
              {picker ? `${picker.date} • ${t(`slot.${picker.slot}` as any)}` : ''}
            </Text>
            <Text onPress={() => setPicker(null)} style={[styles.navBtn, { color: colors.primary }]}>{t('common.cancel')}</Text>
          </View>
          <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <TextInput value={q} onChangeText={setQ} placeholder="Search recipes…" placeholderTextColor={colors.muted} style={[styles.input, { color: colors.ink }]} autoFocus />
          </View>
          <FlatList
            data={searchResults}
            keyExtractor={(r) => r.id}
            contentContainerStyle={styles.list}
            ListEmptyComponent={<EmptyState icon="📅" title="No recipes" />}
            renderItem={({ item }) => (
              <Pressable onPress={() => pick(item)} style={[styles.slot, { backgroundColor: colors.card, borderColor: colors.line }]}>
                <View style={styles.mealRow}>
                  <Text style={styles.mealEmoji}>{item.imageEmoji}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.mealName, { color: colors.ink }]}>{item.titleEn}</Text>
                    <Text style={[styles.slotLabel, { color: colors.muted }]}>⏱ {item.prepMin + item.cookMin} min • {item.cuisine}</Text>
                  </View>
                </View>
              </Pressable>
            )}
          />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
  void navigation;
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  head: { padding: spacing.lg, paddingBottom: spacing.sm },
  title: { fontSize: fontSize.xxl, fontWeight: '900' },
  weekNav: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  navBtn: { fontSize: fontSize.md, fontWeight: '800', padding: 6 },
  weekLabel: { fontSize: fontSize.sm, fontWeight: '700' },
  list: { padding: spacing.lg, paddingTop: spacing.sm, gap: spacing.md, paddingBottom: 40 },
  dayCard: { borderWidth: 1.5, borderRadius: radius.xl, padding: spacing.md, gap: 8 },
  dayHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dayName: { fontSize: fontSize.lg, fontWeight: '800' },
  today: { color: '#fff', fontSize: fontSize.xs, fontWeight: '800', borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4, overflow: 'hidden' },
  slot: { borderWidth: 1, borderRadius: radius.md, padding: spacing.sm, gap: 4 },
  slotLabel: { fontSize: fontSize.xs, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.5 },
  mealRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  mealEmoji: { fontSize: 22 },
  mealName: { fontSize: fontSize.md, fontWeight: '700', flex: 1 },
  empty: { fontSize: fontSize.xs },
  search: { flexDirection: 'row', borderWidth: 1, borderRadius: radius.pill, marginHorizontal: spacing.lg, paddingHorizontal: spacing.md, height: 48, alignItems: 'center' },
  input: { flex: 1, fontSize: fontSize.md },
});
