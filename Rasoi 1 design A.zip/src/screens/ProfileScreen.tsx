import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing } from '@/theme/tokens';
import { useAppStore } from '@/store';
import { useTranslate } from '@/hooks';
import { isCloudEnabled } from '@/cloud';
import { AppEnv } from '@/config/env';

const DIETS = [
  { id: 'all', en: 'All', hi: 'सभी' },
  { id: 'veg', en: 'Veg', hi: 'वेज' },
  { id: 'non-veg', en: 'Non-veg', hi: 'नॉन-वेज' },
  { id: 'vegan', en: 'Vegan', hi: 'वीगन' },
  { id: 'jain', en: 'Jain', hi: 'जैन' },
];

export function ProfileScreen() {
  const { colors } = useAppTheme();
  const { t, locale } = useTranslate();
  const settings = useAppStore((s) => s.settings);
  const update = useAppStore((s) => s.updateSettings);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.title, { color: colors.ink }]}>{t('profile.title')}</Text>

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.line }]}>
          <Text style={styles.avatar}>🙏</Text>
          <Text style={[styles.name, { color: colors.ink }]}>Home Cook</Text>
          <Text style={[styles.mode, { color: colors.muted }]}>{t('profile.localOnly')}</Text>
        </View>

        <Text style={[styles.h2, { color: colors.ink }]}>{t('profile.language')}</Text>
        <View style={styles.row2}>
          {(['en', 'hi'] as const).map((l) => (
            <Pressable
              key={l}
              onPress={() => update({ locale: l })}
              style={[styles.opt, { backgroundColor: locale === l ? colors.primary : colors.card, borderColor: colors.line }]}
            >
              <Text style={[styles.optTxt, { color: locale === l ? '#fff' : colors.ink }]}>
                {l === 'en' ? 'English' : 'हिन्दी'}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={[styles.h2, { color: colors.ink }]}>{t('profile.diet')}</Text>
        <View style={styles.chips}>
          {DIETS.map((d) => (
            <Pressable
              key={d.id}
              onPress={() => update({ dietPreference: d.id as any })}
              style={[styles.chip, { backgroundColor: settings.dietPreference === d.id ? colors.primary : colors.card, borderColor: colors.line }]}
            >
              <Text style={[styles.chipTxt, { color: settings.dietPreference === d.id ? '#fff' : colors.inkSoft }]}>
                {locale === 'hi' ? d.hi : d.en}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={[styles.h2, { color: colors.ink }]}>{t('profile.household')}</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.line }]}>
          <View style={styles.sizeRow}>
            {([2, 3, 4, 5, 6] as const).map((n) => (
              <Pressable
                key={n}
                onPress={() => update({ householdSize: n })}
                style={[styles.sizeBtn, { backgroundColor: settings.householdSize === n ? colors.primary : colors.bg, borderColor: colors.line }]}
              >
                <Text style={[styles.sizeTxt, { color: settings.householdSize === n ? '#fff' : colors.ink }]}>{n}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={[styles.hint, { color: colors.muted }]}>Scales recipe servings & shopping quantities.</Text>
        </View>

        <Text style={[styles.h2, { color: colors.ink }]}>{t('profile.cloud')}</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.line }]}>
          <Text style={styles.avatar}>☁️</Text>
          <Text style={[styles.hint, { color: colors.inkSoft }]}>{t('profile.cloudSub')}</Text>
          <View style={[styles.statusPill, { backgroundColor: isCloudEnabled() ? colors.primarySoft : colors.accentSoft }]}>
            <Text style={[styles.statusTxt, { color: isCloudEnabled() ? colors.primary : colors.accent }]}>
              {isCloudEnabled() ? '● Cloud configured' : '○ ' + t('profile.localOnly')}
            </Text>
          </View>
        </View>

        <Text style={[styles.h2, { color: colors.ink }]}>{t('profile.about')}</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.line }]}>
          <Text style={[styles.hint, { color: colors.inkSoft }]}>
            Rasoi v{AppEnv.APP_VERSION} • foundation build{`\n`}Offline-first catalogue • SQLite • {AppEnv.PLATFORM}
          </Text>
        </View>
        <View style={{ height: 24 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: 40 },
  title: { fontSize: fontSize.xxl, fontWeight: '900' },
  card: { borderWidth: 1, borderRadius: radius.xl, padding: spacing.lg, alignItems: 'center', gap: 6, marginTop: spacing.sm },
  avatar: { fontSize: 44 },
  name: { fontSize: fontSize.xl, fontWeight: '800' },
  mode: { fontSize: fontSize.xs, textAlign: 'center' },
  h2: { fontSize: fontSize.lg, fontWeight: '800', marginTop: spacing.lg, marginBottom: 2 },
  row2: { flexDirection: 'row', gap: spacing.sm },
  opt: { flex: 1, borderWidth: 1, borderRadius: radius.lg, paddingVertical: 14, alignItems: 'center' },
  optTxt: { fontSize: fontSize.md, fontWeight: '800' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { borderWidth: 1, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 9 },
  chipTxt: { fontSize: fontSize.sm, fontWeight: '800' },
  sizeRow: { flexDirection: 'row', gap: 8 },
  sizeBtn: { width: 48, height: 48, borderRadius: 24, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  sizeTxt: { fontSize: fontSize.lg, fontWeight: '800' },
  hint: { fontSize: fontSize.sm, lineHeight: 19, textAlign: 'center' },
  statusPill: { borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 8, marginTop: 6 },
  statusTxt: { fontSize: fontSize.xs, fontWeight: '800' },
});
