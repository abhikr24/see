import React, { useCallback, useMemo, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useNavigation, useRoute } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing, shadow } from '@/theme/tokens';
import { IngredientRepo, PantryRepo, RecipeRepo, ShoppingRepo } from '@/db/repositories';
import { DietBadge, Button, Pill, EmptyState } from '@/components';
import { safeParse } from '@/utils';
import { useLocale } from '@/store';

export function RecipeDetailScreen() {
  const { colors } = useAppTheme();
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const locale = useLocale();
  const recipeId: string = route.params?.recipeId;
  const [tick, setTick] = useState(0);
  useFocusEffect(useCallback(() => setTick((v) => v + 1), []));
  void tick;

  const recipe = useMemo(() => {
    try {
      return RecipeRepo.getById(recipeId);
    } catch {
      return null;
    }
  }, [recipeId]);

  const lines = useMemo(() => {
    try {
      return recipe ? RecipeRepo.getIngredients(recipe.id) : [];
    } catch {
      return [];
    }
  }, [recipe]);

  const pantryIds = useMemo(() => {
    try {
      return new Set(PantryRepo.ids());
    } catch {
      return new Set<string>();
    }
  }, [recipe]);

  if (!recipe) {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]}>
        <EmptyState icon="🍳" title="Recipe not found" />
      </SafeAreaView>
    );
  }

  const steps = safeParse<string[]>(recipe.stepsJson, []);
  const have = lines.filter((l) => pantryIds.has(l.ingredientId));
  const missing = lines.filter((l) => !pantryIds.has(l.ingredientId) && !l.optional);

  const toggleFav = () => {
    try {
      RecipeRepo.toggleFavorite(recipe.id);
      setTick((v) => v + 1);
    } catch { /* noop */ }
  };

  const addMissingToShopping = () => {
    try {
      missing.forEach((m) => ShoppingRepo.add(m.ingredient.nameEn, { ingredientId: m.ingredientId, recipeId: recipe.id }));
      navigation.navigate('MainTabs', { screen: 'Shopping' });
    } catch { /* noop */ }
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['bottom']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={[styles.hero, { backgroundColor: colors.accentSoft }]}>
          <Text style={styles.heroEmoji}>{recipe.imageEmoji}</Text>
          <Text onPress={toggleFav} style={styles.favBtn}>{recipe.isFavorite ? '❤️' : '🤍'}</Text>
        </View>
        <View style={styles.rowBetween}>
          <DietBadge diet={recipe.diet} />
          <Text style={[styles.meta, { color: colors.muted }]}>⏱ {recipe.prepMin + recipe.cookMin} min • {recipe.servings} servings</Text>
        </View>
        <Text style={[styles.title, { color: colors.ink }]}>
          {locale === 'hi' && recipe.titleHi ? recipe.titleHi : recipe.titleEn}
        </Text>
        {!!recipe.description && <Text style={[styles.desc, { color: colors.inkSoft }]}>{recipe.description}</Text>}
        <View style={styles.statRow}>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <Text style={[styles.statN, { color: colors.ink }]}>{have.length}/{lines.length}</Text>
            <Text style={[styles.statL, { color: colors.muted }]}>in pantry</Text>
          </View>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <Text style={[styles.statN, { color: colors.ink }]}>{recipe.calories ?? '—'}</Text>
            <Text style={[styles.statL, { color: colors.muted }]}>kcal</Text>
          </View>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <Text style={[styles.statN, { color: colors.ink }]}>{recipe.proteinG ?? '—'}g</Text>
            <Text style={[styles.statL, { color: colors.muted }]}>protein</Text>
          </View>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <Text style={[styles.statN, { color: colors.ink, textTransform: 'capitalize' }]}>{recipe.difficulty}</Text>
            <Text style={[styles.statL, { color: colors.muted }]}>level</Text>
          </View>
        </View>

        <Text style={[styles.h2, { color: colors.ink }]}>Ingredients</Text>
        {lines.map((l) => {
          const hasIt = pantryIds.has(l.ingredientId);
          const subs = hasIt ? [] : IngredientRepo.getSubstitutes(l.ingredientId).slice(0, 2);
          return (
            <View key={l.ingredientId} style={[styles.ing, { backgroundColor: colors.card, borderColor: colors.line }]}>
              <Text style={styles.ingEmoji}>{l.ingredient.icon}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.ingName, { color: colors.ink }]}>
                  {l.ingredient.nameEn} <Text style={{ color: colors.muted, fontWeight: '400' }}>• {l.qty} {l.unit}</Text>
                </Text>
                {subs.length > 0 && (
                  <Text style={[styles.sub, { color: colors.accent }]}>Swap: {subs.map((s) => s.nameEn).join(' / ')}</Text>
                )}
              </View>
              <Pill text={hasIt ? 'Have' : l.optional ? 'Optional' : 'Need'} tone={hasIt ? 'green' : l.optional ? 'neutral' : 'amber'} />
            </View>
          );
        })}
        {missing.length > 0 && (
          <Button label={`Add ${missing.length} missing to shopping list`} onPress={addMissingToShopping} style={{ marginTop: spacing.md }} />
        )}

        <Text style={[styles.h2, { color: colors.ink }]}>Steps</Text>
        {steps.map((s, i) => (
          <View key={i} style={[styles.step, { backgroundColor: colors.card, borderColor: colors.line }]}>
            <View style={[styles.stepN, { backgroundColor: colors.primary }]}>
              <Text style={styles.stepNTxt}>{i + 1}</Text>
            </View>
            <Text style={[styles.stepTxt, { color: colors.ink }]}>{s}</Text>
          </View>
        ))}
        <View style={{ height: 30 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: 40, gap: 10 },
  hero: { borderRadius: radius.xl, height: 190, alignItems: 'center', justifyContent: 'center', position: 'relative', ...shadow.card },
  heroEmoji: { fontSize: 92 },
  favBtn: { position: 'absolute', top: 12, right: 14, fontSize: 26 },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 },
  meta: { fontSize: fontSize.xs, fontWeight: '700' },
  title: { fontSize: 26, fontWeight: '900', letterSpacing: -0.4 },
  desc: { fontSize: fontSize.md, lineHeight: 21 },
  statRow: { flexDirection: 'row', gap: 8, marginTop: 6 },
  stat: { flex: 1, borderWidth: 1, borderRadius: radius.md, paddingVertical: 10, alignItems: 'center' },
  statN: { fontSize: fontSize.md, fontWeight: '900' },
  statL: { fontSize: fontSize.xs, marginTop: 1 },
  h2: { fontSize: fontSize.xl, fontWeight: '800', marginTop: spacing.md },
  ing: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, borderWidth: 1, borderRadius: radius.md, padding: spacing.sm },
  ingEmoji: { fontSize: 24 },
  ingName: { fontSize: fontSize.sm, fontWeight: '700' },
  sub: { fontSize: fontSize.xs, marginTop: 2, fontWeight: '600' },
  step: { flexDirection: 'row', gap: spacing.sm, borderWidth: 1, borderRadius: radius.md, padding: spacing.md },
  stepN: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  stepNTxt: { color: '#fff', fontWeight: '900', fontSize: fontSize.sm },
  stepTxt: { flex: 1, fontSize: fontSize.md, lineHeight: 21 },
});
