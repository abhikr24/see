import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing } from '@/theme/tokens';
import { useAppStore } from '@/store';
import { useTranslate } from '@/hooks';
import { RecipeRepo } from '@/db/repositories';
import { RecipeCard, EmptyState } from '@/components';

const DIETS = ['all', 'veg', 'non-veg', 'vegan', 'jain'] as const;

export function RecipesScreen() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  const navigation = useNavigation<any>();
  const dietPref = useAppStore((s) => s.settings.dietPreference);
  const [q, setQ] = useState('');
  const [diet, setDiet] = useState<string>(dietPref);
  const [favOnly, setFavOnly] = useState(false);
  const [tick, setTick] = useState(0);
  useFocusEffect(useCallback(() => setTick((v) => v + 1), []));
  void tick;

  const list = useMemo(() => {
    try {
      if (favOnly) {
        const favs = RecipeRepo.listFavorites();
        return q.trim()
          ? favs.filter((r) => (r.titleEn + r.titleHi + r.tagsJson).toLowerCase().includes(q.toLowerCase()))
          : favs;
      }
      return RecipeRepo.search(q, diet, 100);
    } catch {
      return [];
    }
  }, [q, diet, favOnly]);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <View style={styles.head}>
        <Text style={[styles.title, { color: colors.ink }]}>{t('recipes.title')}</Text>
        <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.line }]}>
          <Text>🔍</Text>
          <TextInput value={q} onChangeText={setQ} placeholder={t('recipes.searchPh')} placeholderTextColor={colors.muted} style={[styles.input, { color: colors.ink }]} returnKeyType="search" />
        </View>
        <View style={styles.filters}>
          <Text
            onPress={() => setFavOnly(!favOnly)}
            style={[styles.chip, { backgroundColor: favOnly ? colors.chili : colors.card, color: favOnly ? '#fff' : colors.inkSoft, borderColor: colors.line }]}
          >
            ♥ {t('recipes.favorites')}
          </Text>
          {DIETS.map((d) => (
            <Text
              key={d}
              onPress={() => { setDiet(d); setFavOnly(false); }}
              style={[styles.chip, { backgroundColor: diet === d && !favOnly ? colors.primary : colors.card, color: diet === d && !favOnly ? '#fff' : colors.inkSoft, borderColor: colors.line }]}
            >
              {t(`diet.${d}` as any)}
            </Text>
          ))}
        </View>
      </View>
      <FlatList
        data={list}
        keyExtractor={(r) => r.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyState icon="📖" title="No recipes found" subtitle="Try another search or filter" />}
        renderItem={({ item }) => (
          <RecipeCard recipe={item} onPress={() => navigation.navigate('RecipeDetail', { recipeId: item.id })} />
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  head: { padding: spacing.lg, paddingBottom: spacing.sm, gap: spacing.sm },
  title: { fontSize: fontSize.xxl, fontWeight: '900' },
  search: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: radius.pill, paddingHorizontal: spacing.md, height: 48 },
  input: { flex: 1, fontSize: fontSize.md },
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { borderWidth: 1, borderRadius: radius.pill, paddingHorizontal: 12, paddingVertical: 7, fontSize: fontSize.sm, fontWeight: '800', overflow: 'hidden' },
  list: { padding: spacing.lg, paddingTop: spacing.sm, gap: spacing.md, paddingBottom: 40 },
});
