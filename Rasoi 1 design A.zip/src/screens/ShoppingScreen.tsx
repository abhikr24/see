import React, { useCallback, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAppTheme } from '@/theme';
import { fontSize, radius, spacing } from '@/theme/tokens';
import { useTranslate } from '@/hooks';
import { ShoppingRepo } from '@/db/repositories';
import { EmptyState } from '@/components';
import type { ShoppingItem } from '@/types';

export function ShoppingScreen() {
  const { colors } = useAppTheme();
  const { t } = useTranslate();
  const [items, setItems] = useState<ShoppingItem[]>([]);
  const [draft, setDraft] = useState('');

  const reload = useCallback(() => {
    try {
      setItems(ShoppingRepo.list());
    } catch { /* noop */ }
  }, []);
  useFocusEffect(useCallback(() => reload(), [reload]));

  const add = () => {
    const name = draft.trim();
    if (!name) return;
    try {
      ShoppingRepo.add(name);
      setDraft('');
      reload();
    } catch { /* noop */ }
  };

  const open = items.filter((i) => !i.checked);
  const done = items.filter((i) => i.checked);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.bg }]} edges={['top']}>
      <View style={styles.head}>
        <Text style={[styles.title, { color: colors.ink }]}>{t('shopping.title')}</Text>
        <Text style={[styles.sub, { color: colors.inkSoft }]}>{open.length} to buy • {done.length} done</Text>
        <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.line }]}>
          <TextInput
            value={draft}
            onChangeText={setDraft}
            placeholder={t('shopping.addPh')}
            placeholderTextColor={colors.muted}
            style={[styles.input, { color: colors.ink }]}
            returnKeyType="done"
            onSubmitEditing={add}
          />
          <Pressable onPress={add} style={[styles.addBtn, { backgroundColor: colors.primary }]}>
            <Text style={styles.addTxt}>+ {t('common.add')}</Text>
          </Pressable>
        </View>
      </View>
      <FlatList
        data={items}
        keyExtractor={(i) => String(i.id)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyState icon="🛒" title={t('shopping.empty')} />}
        ListFooterComponent={
          done.length > 0 ? (
            <Text onPress={() => { ShoppingRepo.clearChecked(); reload(); }} style={[styles.clear, { color: colors.chili }]}>
              {t('shopping.clearDone')} ({done.length})
            </Text>
          ) : null
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => { ShoppingRepo.toggle(item.id); reload(); }}
            style={[styles.row, { backgroundColor: colors.card, borderColor: colors.line, opacity: item.checked ? 0.6 : 1 }]}
          >
            <View style={[styles.box, { borderColor: colors.primary, backgroundColor: item.checked ? colors.primary : 'transparent' }]}>
              {item.checked && <Text style={styles.tick}>✓</Text>}
            </View>
            <Text style={[styles.name, { color: colors.ink, textDecorationLine: item.checked ? 'line-through' : 'none' }]}>
              {item.name}
            </Text>
            <Text onPress={() => { ShoppingRepo.remove(item.id); reload(); }} style={[styles.del, { color: colors.muted }]}>✕</Text>
          </Pressable>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  head: { padding: spacing.lg, paddingBottom: spacing.sm, gap: 6 },
  title: { fontSize: fontSize.xxl, fontWeight: '900' },
  sub: { fontSize: fontSize.sm, fontWeight: '600' },
  search: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: radius.pill, paddingLeft: spacing.md, padding: 6, marginTop: 6 },
  input: { flex: 1, fontSize: fontSize.md, paddingVertical: 8 },
  addBtn: { borderRadius: radius.pill, paddingHorizontal: 16, paddingVertical: 10 },
  addTxt: { color: '#fff', fontWeight: '800', fontSize: fontSize.sm },
  list: { padding: spacing.lg, paddingTop: spacing.sm, gap: spacing.sm, paddingBottom: 40 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, borderWidth: 1, borderRadius: radius.lg, padding: spacing.md },
  box: { width: 24, height: 24, borderRadius: 8, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  tick: { color: '#fff', fontWeight: '900', fontSize: 14 },
  name: { flex: 1, fontSize: fontSize.md, fontWeight: '700' },
  del: { fontSize: 15, padding: 6, fontWeight: '800' },
  clear: { textAlign: 'center', fontWeight: '800', marginTop: spacing.md, fontSize: fontSize.sm },
});
