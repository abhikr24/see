import { differenceInCalendarDays, parseISO } from '@/utils/date';
import type { PantryItem } from '@/types';
import { EXPIRY_THRESHOLDS_DAYS } from '@/config/constants';

export type ExpiryStatus = 'expired' | 'use-soon' | 'fresh' | 'no-date';

export function expiryStatus(item: PantryItem, today = new Date()): ExpiryStatus {
  if (!item.expiryDate) return 'no-date';
  try {
    const days = differenceInCalendarDays(parseISO(item.expiryDate), today);
    if (days < EXPIRY_THRESHOLDS_DAYS.EXPIRED) return 'expired';
    if (days <= EXPIRY_THRESHOLDS_DAYS.USE_SOON) return 'use-soon';
    return 'fresh';
  } catch {
    return 'no-date';
  }
}

export function sortByExpiry(items: PantryItem[]): PantryItem[] {
  const rank: Record<ExpiryStatus, number> = { expired: 0, 'use-soon': 1, fresh: 2, 'no-date': 3 };
  return [...items].sort((a, b) => rank[expiryStatus(a)] - rank[expiryStatus(b)]);
}
