/**
 * Matching service — pure logic over local data.
 * "What can I cook with X?" = set intersection between selected
 * ingredient ids and each recipe's required (non-optional) ingredients.
 * Fully offline, no network.
 */
import { IngredientRepo, RecipeRepo } from '@/db/repositories';
import type { RecipeMatch } from '@/types';

export interface MatchOptions {
  diet?: string;
  maxMissing?: number;
  limit?: number;
}

export function matchRecipes(selectedIds: string[], options: MatchOptions = {}): RecipeMatch[] {
  const { diet = 'all', maxMissing = 99, limit = 50 } = options;
  const selected = new Set(selectedIds);
  const recipes = RecipeRepo.search('', diet, 500);
  const out: RecipeMatch[] = [];

  for (const recipe of recipes) {
    const ris = RecipeRepo.getIngredients(recipe.id);
    const required = ris.filter((r) => !r.optional);
    const matched = required.filter((r) => selected.has(r.ingredientId));
    const missingRis = required.filter((r) => !selected.has(r.ingredientId));
    const total = required.length || 1;
    const matchPct = Math.round((matched.length / total) * 100);
    if (missingRis.length > maxMissing) continue;
    // Skip recipes with zero overlap when the user picked something.
    if (selected.size > 0 && matched.length === 0) continue;
    out.push({
      recipe,
      matchedCount: matched.length,
      totalCount: required.length,
      missingCount: missingRis.length,
      matchPct,
      missing: missingRis.map((r) => ({
        ingredient: r.ingredient,
        optional: r.optional,
        substitutes: IngredientRepo.getSubstitutes(r.ingredientId).slice(0, 2),
      })),
      canCook: missingRis.length === 0,
    });
  }
  out.sort((a, b) => b.matchPct - a.matchPct || a.missingCount - b.missingCount);
  return out.slice(0, limit);
}

export function missingToShoppingList(match: RecipeMatch): Array<{ name: string; ingredientId: string }> {
  return match.missing.map((m) => ({ name: m.ingredient.nameEn, ingredientId: m.ingredient.id }));
}
