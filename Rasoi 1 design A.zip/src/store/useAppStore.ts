/**
 * Global app store (zustand): session draft state that many screens share.
 * Persisted slices: settings + selected ingredient ids (AsyncStorage).
 * SQLite remains the source of truth for lists; store holds UI/session state.
 */
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { AppSettings } from '@/types';
import { DEFAULT_SETTINGS } from '@/types';

interface AppState {
  hydrated: boolean;
  dbReady: boolean;
  settings: AppSettings;
  selectedIds: string[];
  setDbReady: (v: boolean) => void;
  setHydrated: (v: boolean) => void;
  updateSettings: (patch: Partial<AppSettings>) => void;
  toggleIngredient: (id: string) => void;
  setSelected: (ids: string[]) => void;
  clearSelected: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      hydrated: false,
      dbReady: false,
      settings: DEFAULT_SETTINGS,
      selectedIds: ['onion', 'tomato', 'potato', 'toor-dal', 'rice'],
      setDbReady: (v) => set({ dbReady: v }),
      setHydrated: (v) => set({ hydrated: v }),
      updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      toggleIngredient: (id) =>
        set((s) => ({
          selectedIds: s.selectedIds.includes(id)
            ? s.selectedIds.filter((x) => x !== id)
            : s.selectedIds.length >= 30
              ? s.selectedIds
              : [...s.selectedIds, id],
        })),
      setSelected: (ids) => set({ selectedIds: ids.slice(0, 30) }),
      clearSelected: () => set({ selectedIds: [] }),
    }),
    {
      name: '@rasoi/app-store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({ settings: s.settings, selectedIds: s.selectedIds }) as AppState,
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

export function useLocale(): 'en' | 'hi' {
  return useAppStore((s) => s.settings.locale);
}
