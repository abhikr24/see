export const palette = {
  // Warm premium kitchen palette — cream base, deep green primary, turmeric accent
  cream: '#FFF8EF',
  creamDark: '#F9EEDC',
  ink: '#1C1917',
  inkSoft: '#57534E',
  muted: '#A8A29E',
  card: '#FFFFFF',
  line: '#F0E6D2',
  primary: '#1B7A43',
  primaryDark: '#145C32',
  primarySoft: '#E3F2E7',
  accent: '#E8930C',
  accentSoft: '#FDF0D5',
  chili: '#C93A2E',
  chiliSoft: '#FDECEA',
  gold: '#C99A2C',
  veg: '#1B7A43',
  nonVeg: '#B3372F',
  vegan: '#2E7D5B',
  info: '#2563EB',
  infoSoft: '#E3EDFD',
  dark: {
    bg: '#131110',
    card: '#1E1B19',
    line: '#2E2A27',
    ink: '#FAFAF9',
    inkSoft: '#C9C2BB',
    muted: '#8A837C',
    primarySoft: '#1E3A28',
    accentSoft: '#3A2C12',
  },
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  xxxl: 36,
} as const;

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 22,
  pill: 999,
} as const;

export const fontSize = {
  xs: 11,
  sm: 12.5,
  md: 14,
  lg: 16,
  xl: 19,
  xxl: 24,
  hero: 30,
} as const;

export const shadow = {
  card: {
    shadowColor: '#3E2F16',
    shadowOpacity: 0.08,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 6 },
    elevation: 3,
  },
  pop: {
    shadowColor: '#3E2F16',
    shadowOpacity: 0.14,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 5,
  },
} as const;
