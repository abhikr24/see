import { useColorScheme } from 'react-native';
import { palette } from './tokens';

export type Theme = {
  dark: boolean;
  colors: {
    bg: string;
    card: string;
    line: string;
    ink: string;
    inkSoft: string;
    muted: string;
    primary: string;
    primaryDark: string;
    primarySoft: string;
    accent: string;
    accentSoft: string;
    chili: string;
    chiliSoft: string;
    info: string;
    infoSoft: string;
  };
};

export function useAppTheme(): Theme {
  const scheme = useColorScheme();
  const dark = scheme === 'dark';
  if (dark) {
    return {
      dark,
      colors: {
        bg: palette.dark.bg,
        card: palette.dark.card,
        line: palette.dark.line,
        ink: palette.dark.ink,
        inkSoft: palette.dark.inkSoft,
        muted: palette.dark.muted,
        primary: '#3CB371',
        primaryDark: '#2E8B57',
        primarySoft: palette.dark.primarySoft,
        accent: '#F5A524',
        accentSoft: palette.dark.accentSoft,
        chili: '#E0655A',
        chiliSoft: '#3A2020',
        info: '#6EA8FE',
        infoSoft: '#1E2A45',
      },
    };
  }
  return {
    dark,
    colors: {
      bg: palette.cream,
      card: palette.card,
      line: palette.line,
      ink: palette.ink,
      inkSoft: palette.inkSoft,
      muted: palette.muted,
      primary: palette.primary,
      primaryDark: palette.primaryDark,
      primarySoft: palette.primarySoft,
      accent: palette.accent,
      accentSoft: palette.accentSoft,
      chili: palette.chili,
      chiliSoft: palette.chiliSoft,
      info: palette.info,
      infoSoft: palette.infoSoft,
    },
  };
}
