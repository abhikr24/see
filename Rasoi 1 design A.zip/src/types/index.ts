/**
 * Domain types. These mirror the SQLite schema (`src/db/schema.ts`) and are
 * shared by repositories, services, and UI.
 *
 * Ownership key:
 *  - `local/*`  — bundled/seeded, read-only catalogue data (never in Supabase)
 *  - `user/*`   — user-owned, offline-first (SQLite → optional Supabase mirror)
 *  - `cloud/*`  — Supabase-owned (defined in `src/cloud/types.ts`)
 */

// ─── Taxonomy ───────────────────────────────────────────────────────────────

export type IngredientCategory =
  | 'vegetables'
  | 'fruits'
  | 'grains_cereals'
  | 'pulses_lentils'
  | 'dairy'
  | 'spices'
  | 'oils_fats'
  | 'nuts_seeds'
  | 'herbs'
  | 'condiments'
  | 'beverages'
  | 'meat'
  | 'seafood'
  | 'eggs'
  | 'sweets'
  | 'other';

export interface Ingredient {
  id: string;
  nameEn: string;
  nameHi?: string | null;
  category: IngredientCategory;
  /** emoji / glyph used for visual selection grid (no binary assets needed) */
  icon: string;
  /** canonical unit for pantry qty, e.g. 'g', 'ml', 'pcs' */
  unit: string;
  /** avg shelf life in days, used for expiry hints */
  shelfLifeDays?: number | null;
  isCommon: boolean;
  searchText: string;
}

export interface IngredientAlias {
  alias: string;
  ingredientId: string;
  locale: string;
}

export interface Substitution {
  ingredientId: string;
  substituteId: string;
  note?: string | null;
  priority: number;
}

// ─── Recipes (local catalogue — NEVER synced to Supabase) ──────────────────

export type DietType = 'veg' | 'non-veg' | 'vegan' | 'jain';
export type Difficulty = 'easy' | 'medium' | 'hard';

export interface Recipe {
  id: string;
  titleEn: string;
  titleHi?: string | null;
  description?: string | null;
  cuisine: string;
  diet: DietType;
  prepMin: number;
  cookMin: number;
  servings: number;
  difficulty: Difficulty;
  calories?: number | null;
  proteinG?: number | null;
  imageEmoji: string;
  tagsJson: string;
  stepsJson: string;
  isFavorite: boolean;
}

export interface RecipeIngredient {
  recipeId: string;
  ingredientId: string;
  qty?: string | null;
  unit?: string | null;
  optional: boolean;
}

// ─── Matching ───────────────────────────────────────────────────────────────

export interface RecipeMatch {
  recipe: Recipe;
  matchedCount: number;
  totalCount: number;
  missingCount: number;
  matchPct: number;
  missing: Array<{ ingredient: Ingredient; optional: boolean; substitutes: Ingredient[] }>;
  canCook: boolean;
}

// ─── User-owned (offline-first) ─────────────────────────────────────────────

export type PantryLocation = 'fridge' | 'pantry' | 'freezer' | 'spice_rack';

export interface PantryItem {
  id: number;
  ingredientId: string;
  ingredient?: Ingredient;
  qty?: number | null;
  unit?: string | null;
  expiryDate?: string | null; // ISO yyyy-mm-dd
  location?: PantryLocation | null;
  updatedAt: string;
}

export interface ShoppingItem {
  id: number;
  name: string;
  ingredientId?: string | null;
  qty?: string | null;
  checked: boolean;
  recipeId?: string | null;
  createdAt: string;
}

export interface MealPlanEntry {
  id: number;
  date: string; // yyyy-mm-dd
  slot: 'breakfast' | 'lunch' | 'snack' | 'dinner';
  recipeId: string;
  recipe?: Recipe;
  servings: number;
}

export type AppSettings = {
  locale: 'en' | 'hi';
  dietPreference: 'all' | DietType;
  householdSize: number;
  showHindiNames: boolean;
  expiryNotifications: boolean;
};

export const DEFAULT_SETTINGS: AppSettings = {
  locale: 'en',
  dietPreference: 'all',
  householdSize: 4,
  showHindiNames: true,
  expiryNotifications: true,
};
