/** The handoff uses Expo Router (package.json main). The design-system
 * showcase is the active entry while the rest of the feature plan is deferred.
 * Keeping App.tsx allows environments that import it directly to preview P1.
 */
export { default } from './app/dev/components';
