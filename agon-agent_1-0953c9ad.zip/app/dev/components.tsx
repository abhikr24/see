import React, { useState } from 'react';
import { View } from 'react-native';
import { Screen, Text, Button, Input, Card, Badge, Chip, Avatar, IconBox, Divider, ProgressBar, Ring, EmptyState, ErrorState, ListSkeleton, Skeleton, Sheet, GradientHeader, OverlapCard, TabBar } from '@/components/ui';
import { C, S } from '@/lib/theme';
import { copy } from '@/lib/copy';
import { inr } from '@/lib/format';
import { TABS } from '@/lib/nav';

const d = copy.dev;
const Section = ({ title, index, children }: { title: string; index: string; children: React.ReactNode }) => (
  <View style={{ marginTop: S.xxl, gap: S.md }}>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.sm }}>
      <Text variant="label" c={C.accent}>{index}</Text>
      <Text variant="label" c={C.secondary}>{title}</Text>
      <View style={{ flex: 1, height: 1, backgroundColor: C.hairline }} />
    </View>
    {children}
  </View>
);

export default function Components() {
  const [chip, setChip] = useState<string>(d.all);
  const [tab, setTab] = useState('home');
  const [sheet, setSheet] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const notify = (message: string) => setFeedback(message);

  return (
    <Screen>
      <View style={{ paddingTop: S.md }}>
        <Text variant="label" c={C.secondary}>{d.eyebrow}</Text>
        <Text variant="h1" style={{ marginTop: S.sm }}>{d.title}</Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.sm, lineHeight: 23 }}>{d.subtitle}</Text>
      </View>

      <View style={{ marginTop: S.xxl }}>
        <GradientHeader style={{ paddingVertical: 26 }}>
          <Text variant="label" c={C.surface}>{d.eyebrow}</Text>
          <Text variant="h2" c={C.surface} style={{ marginTop: S.sm, maxWidth: 240 }}>{d.heroTitle}</Text>
          <Text variant="caption" c={C.surface} style={{ marginTop: S.sm, lineHeight: 20, maxWidth: 260 }}>{d.heroBody}</Text>
          <View style={{ height: 30 }} />
        </GradientHeader>
        <OverlapCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flex: 1 }}>
              <Text variant="label" c={C.muted}>{d.heroStat}</Text>
              <Text variant="h1" tabular style={{ marginTop: 4 }}>92%</Text>
              <Text variant="caption" c={C.secondary}>{d.heroNote}</Text>
            </View>
            <Ring value={92} size={82} stroke={6} tone={C.teal} />
          </View>
        </OverlapCard>
      </View>

      {feedback ? <Card flat tint={C.tealSoft}><Text variant="caption" c={C.teal}>{feedback}</Text></Card> : null}

      <Section index="01" title={d.text}>
        <Card flat>
          <View style={{ gap: S.sm }}>
            <Text variant="h1">{d.variantH1}</Text>
            <Text variant="h2">{d.variantH2}</Text>
            <Text variant="title">{d.variantTitle}</Text>
            <Text variant="body">{d.variantBody}</Text>
            <Text variant="caption" c={C.secondary}>{d.variantCaption}</Text>
            <Text variant="label" c={C.muted}>{d.variantLabel}</Text>
          </View>
        </Card>
      </Section>

      <Section index="02" title={d.buttons}>
        <Button title={d.primary} icon="arrow-forward-outline" onPress={() => setSheet(true)} />
        <View style={{ flexDirection: 'row', gap: S.sm }}>
          <View style={{ flex: 1 }}><Button title={d.secondary} variant="secondary" onPress={() => notify(d.feedbackReady)} /></View>
          <View style={{ flex: 1 }}><Button title={d.outline} variant="outline" onPress={() => notify(d.feedbackReady)} /></View>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: S.sm }}>
          <Button title={d.small} size="sm" full={false} onPress={() => notify(d.feedbackReady)} />
          <Button title={d.ghost} variant="ghost" size="sm" full={false} onPress={() => notify(d.feedbackReady)} />
          <Button title={d.danger} variant="danger" size="sm" full={false} onPress={() => setSheet(true)} />
        </View>
        <View style={{ flexDirection: 'row', gap: S.sm }}>
          <View style={{ flex: 1 }}><Button title={d.loading} loading size="md" /></View>
          <View style={{ flex: 1 }}><Button title={d.disabled} disabled size="md" /></View>
        </View>
      </Section>

      <Section index="03" title={d.fields}>
        <Input label={d.fullName} placeholder={d.fullNamePlaceholder} value={name} onChangeText={setName} returnKeyType="done" icon="person-outline" />
        <Input label={d.phone} placeholder={d.phonePlaceholder} keyboardType="phone-pad" error={d.phoneError} icon="call-outline" />
        <Input label={d.password} placeholder={d.passwordPlaceholder} value={password} onChangeText={setPassword} secure hint={d.passwordHint} />
      </Section>

      <Section index="04" title={d.cards}>
        <Card onPress={() => notify(d.feedbackCard)} flat>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.md }}>
            <IconBox name="school-outline" />
            <View style={{ flex: 1 }}>
              <Text variant="title">{d.cardTitle}</Text>
              <Text variant="caption" c={C.secondary}>{d.cardDetail}</Text>
            </View>
          </View>
        </Card>
        <Text variant="caption" c={C.muted}>{d.cardHint}</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm }}>
          {[d.all, d.batch, d.overdue].map((item) => <Chip key={item} label={item} active={chip === item} onPress={() => setChip(item)} />)}
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm }}>
          <Badge label={copy.fees.paid} tone="teal" />
          <Badge label={`${d.due} ${inr(4999)}`} tone="danger" />
          <Badge label={copy.fees.pending} tone="warning" />
          <Badge label={d.draft} />
        </View>
        <Divider />
      </Section>

      <Section index="05" title={d.avatars}>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.md, alignItems: 'center' }}>
          <Avatar name="Aarav Sharma" size={40} />
          <Avatar name="Ishita Bose" size={48} />
          <Avatar name="Kabir Singh" size={56} />
          <Avatar name="Ananya Gupta" size={72} />
        </View>
        <View style={{ flexDirection: 'row', gap: S.md }}>
          <IconBox name="wallet-outline" tone="teal" />
          <IconBox name="book-outline" tone="accent" />
          <IconBox name="calendar-outline" tone="danger" />
        </View>
      </Section>

      <Section index="06" title={d.data}>
        <Card flat>
          <Text variant="label" c={C.muted}>{d.progress}</Text>
          <View style={{ marginTop: S.md, gap: S.lg }}>
            <ProgressBar value={92} tone="teal" />
            <ProgressBar value={42} tone="warning" />
            <ProgressBar value={18} tone="danger" />
          </View>
        </Card>
        <Card flat><View style={{ gap: S.sm }}><Skeleton h={14} w="70%" /><Skeleton h={14} w="45%" /></View></Card>
      </Section>

      <Section index="07" title={d.states}>
        <ListSkeleton rows={2} />
        <Card flat><EmptyState icon="people-outline" title={d.emptyTitle} text={d.emptyDetail} actionLabel={d.addStudent} onAction={() => setSheet(true)} /></Card>
        <Card flat><ErrorState message={d.errorDetail} onRetry={() => notify(d.feedbackRetry)} /></Card>
      </Section>

      <Section index="08" title={d.overlays}>
        <Button title={d.showSheet} variant="outline" icon="chevron-up-outline" onPress={() => setSheet(true)} />
        <Text variant="caption" c={C.secondary}>{d.nav}</Text>
        <TabBar tabs={TABS.owner.map((item) => item.key === 'more' ? { ...item, badge: 1 } : item)} selectedKey={tab} onSelect={(key) => { setTab(key); notify(`${d.feedbackTab} ${key}`); }} />
      </Section>

      <Sheet visible={sheet} onClose={() => setSheet(false)} title={d.sheetTitle}>
        <Text variant="body" c={C.secondary} style={{ marginBottom: S.xxl }}>{d.sheetDescription}</Text>
        <Text variant="caption" c={C.muted} style={{ marginBottom: S.lg }}>{d.sheetHint}</Text>
        <Button title={d.closeSheet} onPress={() => setSheet(false)} />
      </Sheet>
    </Screen>
  );
}
