import React, { useState } from 'react';
import { FlatList, View } from 'react-native';
import { Screen, Card, Text, Button, Badge, Divider, ProgressBar, Sheet } from '@/components/ui';
import { C, S, type Tone } from '@/lib/theme';
import { copy } from '@/lib/copy';
import { envError } from '@/core/config/env';
import {
  CHECK_COUNT, CHECK_GROUPS, SIDE_EFFECT_COUNT, useContractCheck,
  type CheckGroup, type CheckItem, type CheckResult,
} from '@/core/contract-check';
import { useSession } from '@/store/session';

const c = copy.contractCheck;

type RowStatus = CheckResult['status'] | 'idle';
const TONE_OF: Record<RowStatus, Tone> = { pass: 'success', fail: 'danger', skipped: 'neutral', idle: 'neutral' };
const EFFECTS = Object.values(c.effects);

function noteFor(item: CheckItem, result: CheckResult | undefined): string | null {
  if (!result) return null;
  switch (result.reason) {
    case 'error': return result.detail;
    case 'raw_error': return `${c.rawError} ${result.detail ?? ''}`.trim();
    case 'timeout': return c.timeout;
    case 'not_provided': return c.optional;
    case 'side_effect': return item.sideEffect ? `${c.notCalled} ${c.effects[item.sideEffect]}.` : null;
    default: return null;
  }
}

function Row({ item, result }: { item: CheckItem; result: CheckResult | undefined }) {
  const status: RowStatus = result?.status ?? 'idle';
  const note = noteFor(item, result);
  return (
    <View style={{ paddingVertical: S.md, gap: S.xs }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.sm }}>
        <Text variant="body" weight={600} numberOfLines={1} style={{ flex: 1 }}>{item.method}</Text>
        {result?.code ? <Text variant="caption" c={C.secondary}>{result.code}</Text> : null}
        <Badge label={c.status[status]} tone={TONE_OF[status]} small />
      </View>
      {note ? <Text variant="caption" c={C.secondary}>{note}</Text> : null}
    </View>
  );
}

function PortCard({ group, results }: { group: CheckGroup; results: Record<string, CheckResult> }) {
  return (
    <Card flat style={{ paddingVertical: S.sm }}>
      <Text variant="label" c={C.secondary} style={{ paddingTop: S.sm, paddingBottom: S.xs }}>{group.port}</Text>
      {group.items.map((item) => (
        <View key={item.id}>
          <Divider />
          <Row item={item} result={results[item.id]} />
        </View>
      ))}
    </Card>
  );
}

function Notice({ title, text }: { title?: string; text: string }) {
  return (
    <Card flat tint={C.dangerSoft} style={{ gap: S.xs }}>
      {title ? <Text variant="title">{title}</Text> : null}
      <Text variant="caption" c={C.ink} style={{ lineHeight: 19 }}>{text}</Text>
    </Card>
  );
}

/**
 * Proves the backend swap. Lists every method of every port, calls each one
 * against whichever adapter src/core/config/providers.ts names, and shows
 * pass or fail with the AppError code. All the logic lives in
 * src/core/contract-check — this file is layout only.
 */
export default function ContractCheck() {
  const orgId = useSession((s) => s.activeOrgId);
  const { results, running, preflight, summary, hasRun, run } = useContractCheck(orgId);
  const [confirming, setConfirming] = useState(false);
  const configError = envError();

  const header = (
    <View style={{ gap: S.lg }}>
      <Card>
        <Text variant="label" c={C.secondary}>{c.passed}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: S.sm, marginTop: S.xs }}>
          <Text variant="h1" tabular>{summary.passed}</Text>
          <Text variant="title" c={C.secondary} tabular>{c.of} {CHECK_COUNT}</Text>
        </View>
        <View style={{ marginTop: S.md }}>
          <ProgressBar value={(summary.passed / CHECK_COUNT) * 100} tone="success" />
        </View>
        <Text variant="caption" c={C.secondary} tabular style={{ marginTop: S.md }}>
          {hasRun ? `${summary.failed} ${c.failed} · ${summary.skipped} ${c.skipped}` : c.notRunYet}
        </Text>
      </Card>

      {configError ? <Notice title={c.envTitle} text={configError} /> : null}
      {preflight && !preflight.reachable ? <Notice text={c.unreachable} /> : null}
      {preflight && preflight.reachable && !preflight.signedIn ? <Notice text={c.signedOut} /> : null}

      <View style={{ gap: S.sm }}>
        <Text variant="caption" c={C.secondary} style={{ lineHeight: 19 }}>{c.intro}</Text>
        <Text variant="caption" c={C.secondary} style={{ lineHeight: 19 }}>{SIDE_EFFECT_COUNT} {c.sideEffectHint}</Text>
        <Button title={c.runAll} variant="outline" size="sm" full={false} disabled={running} onPress={() => setConfirming(true)} />
      </View>
    </View>
  );

  return (
    <Screen
      title={c.title}
      subtitle={c.subtitle}
      scroll={false}
      footer={<Button title={hasRun ? c.runAgain : c.run} loading={running} onPress={() => { void run(false); }} />}
    >
      <FlatList
        style={{ flex: 1 }}
        data={CHECK_GROUPS}
        initialNumToRender={CHECK_GROUPS.length}
        keyExtractor={(group) => group.port}
        renderItem={({ item }) => <PortCard group={item} results={results} />}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={{ marginBottom: S.lg }}
        ItemSeparatorComponent={() => <View style={{ height: S.md }} />}
        contentContainerStyle={{ paddingBottom: S.xxl }}
        showsVerticalScrollIndicator={false}
      />

      <Sheet visible={confirming} onClose={() => setConfirming(false)} title={c.confirmTitle}>
        <Text variant="caption" c={C.secondary} style={{ lineHeight: 19 }}>{c.confirmBody}</Text>
        <View style={{ marginTop: S.sm, marginBottom: S.lg, gap: S.xs }}>
          {EFFECTS.map((effect) => <Text key={effect} variant="caption" c={C.ink}>{effect}</Text>)}
        </View>
        <View style={{ gap: S.sm }}>
          <Button title={c.confirmRun} variant="danger" size="md" onPress={() => { setConfirming(false); void run(true); }} />
          <Button title={copy.common.cancel} variant="ghost" size="md" onPress={() => setConfirming(false)} />
        </View>
      </Sheet>
    </Screen>
  );
}
