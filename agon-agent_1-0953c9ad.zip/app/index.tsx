import { Redirect } from 'expo-router';

/**
 * Until P4 adds authentication there is no real home screen, so the entry
 * points at the deliverable of the prompt in progress: the P2 contract check.
 * The P1 design-system gallery is still at /dev/components.
 */
export default function Index() {
  return <Redirect href="/dev/contract-check" />;
}
