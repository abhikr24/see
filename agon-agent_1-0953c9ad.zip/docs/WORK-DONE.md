# WORK DONE — GuruFlow build tracker

**Last updated:** build pass 3 · 10 Nov 2026 (P2-only follow-up)
**Overall completion:** ~30% (foundation complete, zero feature screens). Pass 3 added no
screens: it reopened P2, which had been marked DONE without meeting its own spec.
**Build pack:** `docs/GuruFlow-AI-Build-Pack.md` (24 prompts — the plan)

This file is the handoff contract. Read it before writing any code.
If you are the next AI: finish the "NEXT" section, then **update this file**
before you hand off again. Never delete a row — mark it.

---

## 1. Status at a glance

| Prompt | Area | Status | Notes |
|---|---|---|---|
| P1 | Scaffold, tokens, UI primitives | **DONE** | Refined interactive gallery at `/dev/components`; typed copy/tokens, photo fallback, shimmer, sheet and tab preview; typecheck and all-platform export passed |
| P2 | Contracts layer | **DONE** (reopened and completed in pass 3) | 17 ports, 71 methods. Pass 2's "DONE" was wrong: the contract check called 14 of 71 methods, mutations had no optimistic update, rollback or toast, and 3 spec-named hooks were missing. All closed in pass 3 — see §3 for what was run. Still open: the check has never met a live backend, and toasts have no host (a P1 item) |
| P3 | Schema, RLS, seed, adapter | **DONE** | 41 policies, 17 tables, adapter implements all ports |
| P4 | Auth screens | **NOT STARTED** | Placeholder route only |
| P5 | Register / join / approvals | **NOT STARTED** | Adapter methods exist |
| P6 | Session, routing, tab bars | **PARTIAL** | Store + route groups + TabBar done. Org switcher missing |
| P7 | Students | **NOT STARTED** | Repo + hooks ready |
| P8 | Batches & timetable | **NOT STARTED** | Repo + hooks ready |
| P9 | Attendance | **NOT STARTED** | Repo + hooks ready |
| P10 | Exams & marks | **NOT STARTED** | Repo + hooks ready |
| P11 | Fees | **NOT STARTED** | Repo exists but `totals()` is simplified |
| P12 | Content library | **NOT STARTED** | Repo + hooks ready |
| P13 | Teacher screens | **NOT STARTED** | — |
| P14 | Homework | **NOT STARTED** | Schema exists, repo not written |
| P15 | Student screens | **NOT STARTED** | — |
| P16 | Player & materials | **NOT STARTED** | `VideoPort` returns the raw URL |
| P17 | Parent screens | **NOT STARTED** | `PaymentPort` throws by design |
| P18 | Notices & notifications | **NOT STARTED** | Repos ready |
| P19 | Reports | **NOT STARTED** | — |
| P20 | Settings & billing | **NOT STARTED** | Plan cap enforced in `StudentRepo.create` |
| P21 | Empty/error/offline | **PARTIAL** | Components exist, not applied to screens |
| P22 | Security audit | **PARTIAL** | Policies written, **never executed** |
| P23 | Performance & deploy | **NOT STARTED** | — |
| P24 | Extensibility docs | **PARTIAL** | AGENTS, README, ARCHITECTURE, HANDOFF written |

---

## 2. What actually exists

```
Imported full handoff (90 archive entries) into the Expo workspace; kept all existing routes, contracts, adapters, SQL, docs and assets. P1 gallery is now the default landing route. Exact file count changes with generated files; source files remain under 300 lines.

src/core/contracts/      models(206) ports(171) errors(42) query(15)
src/core/config/         env(63) providers(12)     ← the swap file
src/core/backend.tsx     the public door: re-exports provider + every hook (17)
src/core/backend-context.tsx   BackendProvider + useBackend (12)
src/core/hooks/          shared(101)  ← query + the central mutation lifecycle
                         cache(70) keys(62) people(179) classroom(150) office(216)
                         52 domain hooks: 25 queries, 27 mutations
src/core/toast.ts        UI-free toast bus (35) — published to, not yet displayed
src/core/contract-check/ probes(223) run(144) useContractCheck(32) index(4)
src/adapters/supabase/   client, mappers(95), repos.core(244),
                         repos.learning(250), auth(63), storage(34), misc(31)
src/adapters/stub/       second adapter, every method "not implemented yet" (46)
src/components/ui/       12 primitives (~460 lines total)
src/lib/                 theme(61) format(67) nav(44)
src/store/               session(42)
app/                     root layout, route resolver, 4 role groups + tabs,
                         auth & pending placeholders, dev/ gallery + contract check
supabase/migrations/     0001_init(245) · 0002_rls(197)
supabase/seed.sql        93 lines, fixed UUIDs
supabase/demo/           attach_users.sql
```

---

## 3. Verified vs not verified — read this honestly

| Claim | Status |
|---|---|
| `src/core/contracts/**` + `src/lib/**` typecheck with `tsc --strict` | **VERIFIED — 0 errors** |
| SQL is syntactically valid Postgres | **NOT VERIFIED** — never executed |
| RLS policies actually block cross-org reads | **NOT VERIFIED** — written, untested |
| Adapter compiles against the Supabase SDK | **VERIFIED** — `npm run typecheck` passed with SDK installed; API calls not exercised |
| Full project TypeScript | **VERIFIED** — `npm run typecheck` passed with zero errors, 09 Nov 2026 |
| Expo export (web, iOS, Android) | **VERIFIED** — `npx expo export --platform all` completed, 09 Nov 2026 |
| React components render visually without warnings | **NOT VERIFIED** — exported but not manually inspected on a device/browser |
| App runs end to end with live auth/backend | **NO** — P4+ and live backend not exercised |
| **Pass 3 — P2** | |
| Full project TypeScript after P2 changes | **VERIFIED** — `npm run typecheck`, zero errors, 10 Nov 2026 |
| Contract check covers every port method | **VERIFIED at compile time** — the probe table is typed against `Backend`. Deleting a probe, or adding one for a method not in the contract, was tried and each fails `tsc` |
| Contract-check runner classifies correctly | **VERIFIED in Node** against four backends: stub adapter (0 pass / 64 fail `unknown` / 7 skipped), Supabase adapter with no env (0 / 64 / 7 — 63 `unauthorized`, 1 `unknown`), a healthy in-memory fake (64 / 0 / 7, and 71 / 0 / 0 with side effects), and a fake with 7 planted defects (all 7 reported) |
| Contract check cannot change real data | **VERIFIED in Node, against a fake only** — across a full run no write received the caller's institute id; side-effect methods were not called without opt-in; `signOut` ran last |
| Contract check against live Supabase | **NOT VERIFIED** — no project is configured. Which methods pass for real is unknown |
| Hooks return `{data, loading, error, refetch}`, errors are `AppError` | **VERIFIED** — rendered with react-dom in jsdom against a fake backend |
| Mutations: optimistic update, rollback, toast | **VERIFIED** for 7 of the 27 mutation hooks (student create/update/remove, save attendance, approve all, mark all read, decide leave), covering both the success and the failure path. Removing the rollback line made the test fail, so the test is real. The other 20 share the same lifecycle code and are typechecked, not individually run |
| `assertEnv()` lists every missing/invalid key | **VERIFIED** — four env combinations run in Node |
| Acceptance: swap `providers.ts` to a second adapter, nothing else changes | **VERIFIED** — one line changed, 43 UI/hook/screen files byte-identical, typecheck clean, all-platform export succeeded, and the web bundle contained no Supabase SDK code. Reverted afterwards |
| Acceptance: no adapter or SDK import in `app/` or UI folders | **VERIFIED** — grep returns nothing; `providers.ts` is the only importer |
| `/dev/contract-check` works in the exported web build | **VERIFIED in jsdom, behaviour only** — the real `dist` bundle was loaded: `/` redirects to the screen, all 17 ports and 71 methods are listed before running, "Run checks" produces 0 of 71 passed / 64 failed / 7 skipped with the code and reason on each row, the env notice names both missing keys, the side-effects button opens the confirm sheet, zero console errors. `/dev/components` still mounts |
| `/dev/contract-check` looks right on a device or browser | **NOT VERIFIED** — jsdom has no layout engine, so spacing, wrapping, scrolling and the sheet's appearance have never been seen. iOS and Android bundles were built but not run |
| Throwaway test harness | **NOT SHIPPED** — the project has no test runner and none was requested. Tests ran from a temp folder with tsx + jsdom and were deleted |

Typecheck and bundling validate compilation, not real database behaviour or visual QA. P1 is the only scope of this follow-up; do not infer that P4+ is complete.

---

## 4. Decisions made (do not silently reverse)

1. **Backend abstraction is the spine.** UI → hooks → `src/core/contracts/ports.ts`
   → `src/adapters/<vendor>` → one line in `src/core/config/providers.ts`.
   Any prompt that makes a screen import a backend SDK is wrong — reject it.
2. **`profiles` has no `org_id`.** Tenancy lives in `memberships`. This is what
   lets a student belong to several institutes.
3. **Seed UUIDs are fixed** (`00000000-0000-4000-8000-0000000000XX`) so tests and
   screenshots stay stable across reseeds.
4. **Teacher names were removed from the marks seed.** The old contract listed
   "Rohit 91, Meera 78, Arun 68" as student marks, but those three are teachers.
   Corrected in `seed.sql`; documented in `AGENTS.md`.
5. **`PaymentPort` throws on purpose.** No gateway is wired. Parent "Pay now"
   must go through this port, never directly to a vendor.
6. **Files stay under 300 lines.** `repos.core.ts` (242) and
   `repos.learning.ts` (250) are close to the limit — split them when you add
   to them.
7. **(pass 3) The contract check never writes to a real institute.** Reads use
   the active institute; every write is aimed at an id that does not exist
   (`NOWHERE` in `probes.ts`). A clean `AppError` refusal of that dummy input
   counts as a pass — but only once `auth.getSession` has answered, so an
   unconfigured backend scores zero instead of a false green. Seven methods
   that cannot be made harmless (SMS, sign-up, sign-out, Google, create
   institute, mark-all-read, upload) are skipped unless the user opts in.
8. **(pass 3) `MembershipRepo.requestJoin(orgId)` takes no user id.** Pass 1
   had added a `userId` argument that the P2 spec does not have. It was removed:
   the adapter reads the signed-in user, which is also the only value the
   `memberships_insert` policy would accept.
9. **(pass 3) Toasts are raised centrally and by error code.** Mutation hooks
   publish to `src/core/toast.ts`; an error toast always shows
   `ERROR_COPY[code]`, never the backend's raw message (so a sentinel like
   `plan_limit` cannot reach the user). Screens do not toast for mutations.
10. **(pass 3) Hook names follow the P2 spec.** `usePayments` → `useFees`,
    `useMyMemberships` → `useMembership`. Nothing imported the old names.
11. **(pass 3) Optimistic rows carry a temporary id.** A created row is in the
    cache before the backend answers, with an id from `tempId()`. Screens must
    check `isTempId(id)` before navigating into a row.

---

## 5. Known gaps and rough edges

- `FeeRepo.totals()` returns `overdue: 0` and derives `expected` from
  collected+pending only. It needs a real fee-plan join before the fees
  dashboard can be trusted.
- `FeeRepo.dueList()` hardcodes a ₹4,999 term fee. Replace with the batch fee plan.
- `ExamRepo.analysis()` returns a single subject row. Multi-subject analysis
  needs a join across exams by subject.
- `OrgRepo.search()` builds an `or()` filter with a string replace — simplify
  before it bites.
- `BatchRepo.list()` does not return `studentCount` / `attendancePct`. The batch
  cards in P8 need a view or an RPC.
- `StudentRepo.list()` does not compute `feeDue` or `absentToday`. Same fix.
- `Avatar` now loads remote photos with initials fallback; photo load/failure still needs on-device visual QA.
- No offline queue, no haptics, no toast host yet. P1 gallery uses an inline feedback card.
- `app/index.tsx` temporarily redirects to the P1 gallery; real auth bootstrapping and route guards remain P4/P6 work. *(pass 3: it now redirects to `/dev/contract-check`, the P2 deliverable. The gallery is still at `/dev/components`. One line to change back.)*
- P1 gallery has been bundled for all platforms but not manually clicked through; inspect small-screen spacing and keyboard/sheet behaviour on a device.
- Original handoff dependencies were inconsistent with its Expo version. The project now installs against the workspace Expo SDK 57 with package overrides for transitive Radix versions; review compatibility before future SDK upgrades.
- P1 gallery demonstrates a 5-item tab bar locally; actual feature tab destinations remain outside this session's scope.
- Fonts still use system typefaces rather than the specified Satoshi/Plus Jakarta Sans because font assets were not provided. NativeWind is configured but existing primitives still use inline static style objects, contrary to the pack's NativeWind-only ideal.

**Added in pass 3**

- **SECURITY — found by reading, not by running.** `memberships_insert` in
  `0002_rls.sql` only checks `user_id = auth.uid()`, and `membership_guard`
  fires on UPDATE only. As written, any signed-in user could insert a row
  making themselves an `active` `owner` of any institute. Not fixed here (it is
  P3/P22 territory and the SQL has never been executed). Fix before any real
  data: the insert policy must force `role = 'student'` and `status = 'pending'`,
  with owner creation moved into a security-definer function.
- **Toasts are published but nothing displays them.** P1 item 6 asks for a
  Toast host in `app/_layout.tsx`; it was never built. P2 forbids touching UI
  files, so pass 3 left it. Until a host subscribes to `toast.subscribe`, every
  success and error toast is silently dropped.
- **The contract check has only ever run against fakes.** Expect these to fail
  the first time it meets live Supabase — predictions from reading the adapter,
  not observations: `payment.createIntent` (throws `unknown` by design, decision
  5); `storage.remove` / `storage.signedUrl` and `auth.signInWithOtp` /
  `auth.signUp` (the adapter maps almost every auth and storage error to
  `unknown` instead of a specific code).
- The Supabase adapter uses `any` in 16 places (`r: any`), against
  the "no `any`" rule. P3 code, left alone.
- No hooks exist for `orgs`, `auth`, `storage`, `payment` or `video`. P2's hook
  list does not name them; P4/P5/P12/P16/P17 will need them.
- `useMarkNotificationRead` does not adjust the unread count optimistically (it
  cannot know whether the row was unread); the count corrects on refetch.
- A new row is added optimistically to every cached list of its domain, even a
  filtered one it does not match, until the refetch lands. Paginated student
  lists are handled (first page only).
- `EXPO_PUBLIC_BACKEND` is validated by `env.ts` but does not choose the
  adapter — `providers.ts` is the only switch, as the spec requires.
- The contract-check screen uses inline style objects like every other screen,
  not NativeWind classes. NativeWind has never been used at runtime in this
  project (zero `className="…"` in the code), so it stayed consistent rather
  than be the first untested use.

---

## 6. NEXT — do these in order

```
1. Open the app (it lands on /dev/contract-check). Press "Run checks". With no
   backend configured the honest result is 0 of 71 passed, 64 failed, 7 skipped,
   with a notice naming the two missing env keys. Check the layout on a phone
   and in a browser — it has never been looked at.
2. Decide on the Toast host (a P1 leftover). Until it exists, P2's toasts are
   invisible. It is a small job but it is UI, so it needs a go-ahead.
3. Configure a real Supabase project: run 0001, 0002, seed, attach_users. Fix
   the memberships_insert hole (§5) before putting real data in.
4. Run the contract check signed in as the seed owner. Fix whatever it reports
   in the adapter — never in the contract.
5. Only after explicit go-ahead: begin P4 auth and replace the landing route.
```

---

## 7. How to hand off again

When you finish a session:

1. Update the status table in §1 (mark rows `DONE` / `PARTIAL`, never delete).
2. Update §3 honestly — move claims from "not verified" to "verified" only if
   you actually ran them.
3. Add new gaps to §5.
4. Rewrite §6 with the next three to five steps.
5. Append one line to §8 below.

---

## 8. Session log

| # | Date | Did | Left for next |
|---|---|---|---|
| 1 | 09 Nov 2026 | P1 scaffold + design system, P2 contracts, P3 schema/RLS/seed/adapter, partial P6 shell, docs | Auth screens onward. Nothing executed against a live backend yet. |
| 2 | 09 Nov 2026 | Imported full handoff; P1-only gallery and primitives refinement; resolved dependency/TypeScript issues; passed typecheck and all-platform Expo export; packaged full source | Manually inspect P1 on device; live backend, SQL and P4+ remain unverified/unbuilt. |
| 3 | 10 Nov 2026 | P2 only. Audited P2 against its spec and found it incomplete; rebuilt the contract check (71 methods, compile-time exhaustive, safe by construction), the central mutation lifecycle (optimistic, rollback, toast), 52 hooks, typed env validation, a stub adapter; restored `requestJoin(orgId)`; proved the one-line swap. Landing route now `/dev/contract-check` | Look at the contract-check screen on a device; build the Toast host; run the check against live Supabase; fix the RLS insert hole. P4+ untouched. |
