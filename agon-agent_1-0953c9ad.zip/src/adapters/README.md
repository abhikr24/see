# Adapters

An adapter is one folder that implements the `Backend` interface from
`src/core/contracts/ports.ts`. It is the only place in the project allowed to
import a database SDK. A new backend is a new sibling folder here — nothing
else in the app changes.

| Folder | What it is |
|---|---|
| `supabase/` | The live adapter. Postgres, Supabase Auth, Supabase Storage. |
| `stub/` | Implements the whole contract and does nothing: every method fails with `AppError('unknown', 'not implemented yet')`. Used to prove the swap, and the smallest starting point for a new adapter. |

## Swapping the backend (about 10 minutes)

1. `cp -r src/adapters/supabase src/adapters/yourvendor`
2. Rewrite the internals of each file. Keep every signature identical.
3. Add your env keys to `.env` and `src/core/config/env.ts`.
4. Change one line in `src/core/config/providers.ts`.
5. Open `/dev/contract-check` and run it.

If step 5 is green, the whole app runs on the new backend. No screen, hook or
contract file changes.

## Reading the contract check

The check lists every method of every port and calls each one.

- **Reads** go to the institute you are signed in to.
- **Writes** are aimed at an institute id that does not exist, so no real row
  can change. A backend that answers such a write with a clean `AppError`
  (`not_found`, `validation`, `unauthorized`, `conflict`) has done the right
  thing, and that counts as a pass.
- **Fail** means the method is missing, threw something that is not an
  `AppError`, timed out, or answered with `unknown` or `network`.
- A handful of methods cannot be made harmless (they send an SMS, create an
  account, end your session). They are skipped unless you choose
  "Run including side effects".
- If `auth.getSession` itself does not answer, the backend is treated as
  unreachable and refusals stop counting as passes — an unconfigured backend
  scores zero, never a false green.

The probe list lives in `src/core/contract-check/probes.ts` and is typed
against `Backend`: add a method to `ports.ts` without a probe and `tsc` fails.

## Rules

- Never leak a row type or SDK type above this layer — map to domain types.
- Normalise every error to `AppError` with a correct code.
- Enforce `orgId` in the query even though RLS also enforces it.
