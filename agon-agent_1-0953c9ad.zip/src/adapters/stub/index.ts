import { AppError } from '@/core/contracts/errors';
import type { Backend } from '@/core/contracts/ports';

/**
 * A backend that implements the whole contract and does nothing: every method
 * fails with AppError('unknown', 'not implemented yet').
 *
 * It exists to prove the swap. Point src/core/config/providers.ts at it and
 * the app must still compile and render with no other file touched;
 * /dev/contract-check then shows every method failing with code `unknown`.
 * It is also the smallest possible starting point for a new adapter.
 */
const notImplemented = (): never => {
  throw new AppError('unknown', 'not implemented yet');
};

/** `sync` names the methods that return a value directly, so they throw rather than reject. */
function port<T extends object>(sync: readonly string[] = []): T {
  return new Proxy({} as T, {
    get(_target, name) {
      // Not a method: keeps the port from looking like a promise or a React element.
      if (typeof name === 'symbol' || name === 'then') return undefined;
      return sync.includes(name) ? notImplemented : async () => notImplemented();
    },
  });
}

export const stubAdapter: Backend = {
  auth: port(['onChange']),
  orgs: port(),
  memberships: port(),
  students: port(),
  batches: port(),
  attendance: port(),
  exams: port(),
  marks: port(),
  fees: port(),
  content: port(),
  notices: port(),
  notifications: port(),
  leave: port(),
  storage: port(),
  payment: port(),
  video: port(),
  realtime: port(['subscribe']),
};
