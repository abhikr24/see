import React, { useEffect, useState } from 'react';
import { Pressable, View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { C, R, TONE, type Tone } from '@/lib/theme';
import { initials as toInitials } from '@/lib/format';
import { Text } from './Text';

export function Badge({ label, tone = 'neutral', small }: { label: string; tone?: Tone; small?: boolean }) {
  const t = TONE[tone];
  return (
    <View style={{ backgroundColor: t.bg, paddingHorizontal: small ? 8 : 10, paddingVertical: small ? 3 : 5, borderRadius: R.chip }}>
      <Text variant="label" weight={600} c={t.fg} style={{ fontSize: small ? 9.5 : 10.5 }}>{label}</Text>
    </View>
  );
}

export function Chip({ label, active, onPress, count }: { label: string; active?: boolean; onPress?: () => void; count?: number }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        height: 36, paddingHorizontal: 14, borderRadius: R.chip,
        flexDirection: 'row', alignItems: 'center', gap: 6,
        backgroundColor: active ? C.primary : C.surface,
        borderWidth: 1, borderColor: active ? C.primary : C.hairline,
        opacity: pressed ? 0.9 : 1,
      })}
    >
      <Text variant="caption" weight={600} c={active ? C.surface : C.secondary}>
        {label}{count !== undefined ? ` ${count}` : ''}
      </Text>
    </Pressable>
  );
}

export function Avatar({ name, uri, size = 48 }: { name: string; uri?: string | null; size?: number }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [uri]);
  return (
    <View style={{
      width: size, height: size, borderRadius: size / 2, backgroundColor: C.navySoft,
      alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    }}>
      {uri && !failed
        ? <Image source={{ uri }} contentFit="cover" onError={() => setFailed(true)} style={{ width: size, height: size }} accessibilityLabel={name} />
        : <Text weight={700} c={C.primary} style={{ fontSize: size * 0.36 }}>{toInitials(name)}</Text>}
    </View>
  );
}

export function IconBox({ name, tone = 'primary', size = 44 }: { name: keyof typeof Ionicons.glyphMap; tone?: Tone; size?: number }) {
  const t = TONE[tone];
  return (
    <View style={{ width: size, height: size, borderRadius: 14, backgroundColor: t.bg, alignItems: 'center', justifyContent: 'center' }}>
      <Ionicons name={name} size={size * 0.48} color={t.fg} />
    </View>
  );
}

export const Divider = ({ inset = 0 }: { inset?: number }) => (
  <View style={{ height: 1, backgroundColor: C.hairline, marginLeft: inset }} />
);

export function ProgressBar({ value, tone = 'primary', height = 6 }: { value: number; tone?: Tone; height?: number }) {
  const t = TONE[tone];
  const v = Math.max(0, Math.min(100, value));
  return (
    <View style={{ height, borderRadius: height, backgroundColor: C.track, overflow: 'hidden' }}>
      <View style={{ width: `${v}%`, height: '100%', borderRadius: height, backgroundColor: t.fg }} />
    </View>
  );
}
