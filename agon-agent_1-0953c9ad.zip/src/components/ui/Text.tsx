import React from 'react';
import { Text as RNText, type TextProps as RNTextProps, type TextStyle } from 'react-native';
import { C, FONT_SIZE } from '@/lib/theme';

type Variant = 'h1' | 'h2' | 'title' | 'body' | 'caption' | 'label';
type Weight = 500 | 600 | 700 | 800;

const SIZE: Record<Variant, number> = FONT_SIZE;
const DEFAULT_WEIGHT: Record<Variant, Weight> = { h1: 800, h2: 700, title: 700, body: 500, caption: 500, label: 600 };

export interface TextProps extends RNTextProps {
  variant?: Variant;
  weight?: Weight;
  c?: string;
  tabular?: boolean;
  className?: string;
}

export function Text({ variant = 'body', weight, c, tabular, className, style, children, ...rest }: TextProps) {
  return (
    <RNText
      {...rest}
      className={className}
      style={[
        {
          fontSize: SIZE[variant],
          fontWeight: String(weight ?? DEFAULT_WEIGHT[variant]) as TextStyle['fontWeight'],
          color: c ?? C.ink,
          ...(variant === 'label' ? { letterSpacing: 0.66, textTransform: 'uppercase' as const } : null),
          ...(tabular ? { fontVariant: ['tabular-nums'] as const } : null),
        },
        style,
      ]}
    >
      {children}
    </RNText>
  );
}
