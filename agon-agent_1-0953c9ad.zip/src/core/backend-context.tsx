import React, { createContext, useContext } from 'react';
import type { Backend } from './contracts/ports';
import { backend as activeBackend } from './config/providers';

const BackendContext = createContext<Backend>(activeBackend);

/** Pass `value` only in tests or to preview a second adapter; by default the swap file decides. */
export const BackendProvider = ({ children, value }: { children: React.ReactNode; value?: Backend }) => (
  <BackendContext.Provider value={value ?? activeBackend}>{children}</BackendContext.Provider>
);

export const useBackend = (): Backend => useContext(BackendContext);
