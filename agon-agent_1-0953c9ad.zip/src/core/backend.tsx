/**
 * The only door between the UI and the backend.
 *
 *   screen → hook (here) → port (contracts/ports.ts) → adapter → providers.ts
 *
 * Screens import hooks from '@/core/backend' and nothing else. Every query
 * hook returns { data, loading, error, refetch }; every mutation hook returns
 * { mutate, mutateAsync, loading, error } and handles optimistic update,
 * rollback and the toast centrally (see hooks/shared.ts).
 */
export { BackendProvider, useBackend } from './backend-context';
export { keys } from './hooks/keys';
export { isTempId } from './hooks/cache';
export type { MutationResult, QueryResult } from './hooks/shared';
export * from './hooks/people';
export * from './hooks/classroom';
export * from './hooks/office';
