/**
 * One place that reads the environment. Validates loudly.
 * Swapping backends starts here and ends in providers.ts.
 *
 * Expo only inlines EXPO_PUBLIC_* when it is written as a static member
 * access, so every key is spelled out below — never read process.env[name].
 */
export type BackendName = 'supabase';

const BACKENDS: readonly BackendName[] = ['supabase'];

export interface Env {
  backend: BackendName;
  supabaseUrl: string;
  supabaseAnonKey: string;
}

const raw = {
  backend: (process.env.EXPO_PUBLIC_BACKEND ?? '').trim(),
  supabaseUrl: (process.env.EXPO_PUBLIC_SUPABASE_URL ?? '').trim(),
  supabaseAnonKey: (process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '').trim(),
};

const isBackend = (value: string): value is BackendName => (BACKENDS as readonly string[]).includes(value);

export const env: Env = {
  backend: isBackend(raw.backend) ? raw.backend : 'supabase',
  supabaseUrl: raw.supabaseUrl,
  supabaseAnonKey: raw.supabaseAnonKey,
};

/** Every key that is absent, and every key that is present but unusable. */
export function envProblems(): { missing: string[]; invalid: string[] } {
  const missing: string[] = [];
  const invalid: string[] = [];
  if (raw.backend && !isBackend(raw.backend)) {
    invalid.push(`EXPO_PUBLIC_BACKEND ("${raw.backend}" is not one of: ${BACKENDS.join(', ')})`);
  }
  if (env.backend === 'supabase') {
    if (!env.supabaseUrl) missing.push('EXPO_PUBLIC_SUPABASE_URL');
    else if (!/^https?:\/\/\S+$/i.test(env.supabaseUrl)) invalid.push('EXPO_PUBLIC_SUPABASE_URL (must start with https://)');
    if (!env.supabaseAnonKey) missing.push('EXPO_PUBLIC_SUPABASE_ANON_KEY');
  }
  return { missing, invalid };
}

/** The single message assertEnv() would throw, or null when the environment is ready. */
export function envError(): string | null {
  const { missing, invalid } = envProblems();
  if (!missing.length && !invalid.length) return null;
  const parts: string[] = [];
  if (missing.length) parts.push(`Missing environment variables: ${missing.join(', ')}.`);
  if (invalid.length) parts.push(`Invalid environment variables: ${invalid.join(', ')}.`);
  parts.push('Copy .env.example to .env, fill them in and restart the bundler. See src/adapters/README.md.');
  return parts.join(' ');
}

export function assertEnv(): void {
  const message = envError();
  if (message) throw new Error(message);
}

export const hasEnv = (): boolean => envError() === null;
