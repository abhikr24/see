import { AppError, type AppErrorCode } from '../contracts/errors';
import type { Backend } from '../contracts/ports';

/**
 * One probe per port method. The ProbeTable type is derived from Backend, so
 * adding a method to ports.ts without adding its probe here fails `tsc` —
 * the check can never silently fall behind the contract.
 *
 * Safety rule: reads use the caller's institute; every write is aimed at
 * NOWHERE, an institute and record id that do not exist, so no real row can
 * change. A method that cannot be made harmless that way is tagged with a
 * `sideEffect` and is not called unless the user asks for it.
 */
export type SideEffect = 'sms' | 'account' | 'session' | 'browser' | 'institute' | 'notifications' | 'upload';

export interface ProbeContext {
  /** Institute used for reads. */
  orgId: string;
}

export interface Probe {
  run: (b: Backend, ctx: ProbeContext) => unknown;
  /** Error codes a healthy backend may answer with for this dummy input. */
  accept?: readonly AppErrorCode[];
  sideEffect?: SideEffect;
  /** Only for optional members: does this adapter provide it? */
  provided?: (b: Backend) => boolean;
}

type AnyMethod = (...args: never[]) => unknown;
type Probes<Port> = { [M in keyof Port as Port[M] extends AnyMethod | undefined ? M : never]-?: Probe };
export type ProbeTable = { [P in keyof Backend]-?: Probes<NonNullable<Backend[P]>> };

/** A well-formed id that no seed row or real record uses. */
export const NOWHERE = '00000000-0000-4000-8000-00000000dead';

const DAY = '2000-01-01';
const MONTH = '2000-01';
const LABEL = 'Contract check';
const EMAIL = 'contract-check@guruflow.invalid';
const PHONE = '0000000000';
const WRONG_SECRET = 'contract-check-not-a-credential';
const BUCKET = 'contract-check';
const FILE = { uri: 'data:text/plain;base64,Z3VydWZsb3c=', name: 'contract-check.txt', mime: 'text/plain' };

/** The backend understood the call and refused the dummy input. */
const REFUSED: readonly AppErrorCode[] = ['unauthorized', 'not_found', 'validation', 'conflict'];
const GONE: readonly AppErrorCode[] = ['not_found'];

const mustUnsubscribe = (off: unknown): void => {
  if (typeof off !== 'function') throw new AppError('unknown', 'Must return an unsubscribe function.');
  off();
};

export const PROBES: ProbeTable = {
  auth: {
    signInWithPassword: { accept: REFUSED, run: (b) => b.auth.signInWithPassword(EMAIL, WRONG_SECRET) },
    signInWithOtp: { sideEffect: 'sms', accept: REFUSED, run: (b) => b.auth.signInWithOtp(PHONE) },
    verifyOtp: { accept: REFUSED, run: (b) => b.auth.verifyOtp(PHONE, '000000') },
    signUp: { sideEffect: 'account', accept: REFUSED, run: (b) => b.auth.signUp(LABEL, EMAIL, WRONG_SECRET) },
    signOut: { sideEffect: 'session', run: (b) => b.auth.signOut() },
    getSession: { run: (b) => b.auth.getSession() },
    onChange: { run: (b) => mustUnsubscribe(b.auth.onChange(() => undefined)) },
    signInWithGoogle: {
      sideEffect: 'browser',
      provided: (b) => typeof b.auth.signInWithGoogle === 'function',
      run: (b) => b.auth.signInWithGoogle?.(),
    },
  },
  orgs: {
    get: { accept: GONE, run: (b, c) => b.orgs.get(c.orgId) },
    getByCode: { run: (b) => b.orgs.getByCode('CONTRACT-CHECK') },
    search: { run: (b) => b.orgs.search('contract-check') },
    create: {
      sideEffect: 'institute', accept: REFUSED,
      run: (b) => b.orgs.create({ name: LABEL, type: 'coaching', city: LABEL, ownerUserId: NOWHERE, ownerName: LABEL }),
    },
    update: { accept: REFUSED, run: (b) => b.orgs.update(NOWHERE, { city: LABEL }) },
  },
  memberships: {
    listMine: { run: (b) => b.memberships.listMine() },
    listPending: { run: (b, c) => b.memberships.listPending(c.orgId) },
    requestJoin: { accept: REFUSED, run: (b) => b.memberships.requestJoin(NOWHERE) },
    approve: { accept: REFUSED, run: (b) => b.memberships.approve(NOWHERE, NOWHERE) },
    reject: { accept: REFUSED, run: (b) => b.memberships.reject(NOWHERE, NOWHERE) },
    approveAll: { accept: REFUSED, run: (b) => b.memberships.approveAll(NOWHERE) },
    setRole: { accept: REFUSED, run: (b) => b.memberships.setRole(NOWHERE, NOWHERE, 'student') },
  },
  students: {
    list: { run: (b, c) => b.students.list(c.orgId, { pageSize: 1 }) },
    get: { accept: GONE, run: (b, c) => b.students.get(c.orgId, NOWHERE) },
    create: {
      accept: REFUSED,
      run: (b) => b.students.create(NOWHERE, {
        batchId: null, fullName: LABEL, rollNo: null, photoUrl: null, parentName: null,
        parentPhone: null, userId: null, parentUserId: null, status: 'active',
      }),
    },
    update: { accept: REFUSED, run: (b) => b.students.update(NOWHERE, NOWHERE, { fullName: LABEL }) },
    remove: { accept: REFUSED, run: (b) => b.students.remove(NOWHERE, NOWHERE) },
  },
  batches: {
    list: { run: (b, c) => b.batches.list(c.orgId) },
    get: { accept: GONE, run: (b, c) => b.batches.get(c.orgId, NOWHERE) },
    create: {
      accept: REFUSED,
      run: (b) => b.batches.create(NOWHERE, {
        name: LABEL, subject: LABEL, teacherMembershipId: null, days: [],
        startTime: null, endTime: null, monthlyFee: 0, capacity: null,
      }),
    },
    update: { accept: REFUSED, run: (b) => b.batches.update(NOWHERE, NOWHERE, { name: LABEL }) },
    remove: { accept: REFUSED, run: (b) => b.batches.remove(NOWHERE, NOWHERE) },
    listForTeacher: { run: (b, c) => b.batches.listForTeacher(c.orgId, NOWHERE) },
  },
  attendance: {
    getSheet: { run: (b, c) => b.attendance.getSheet(c.orgId, NOWHERE, DAY) },
    saveSheet: {
      accept: REFUSED,
      run: (b) => b.attendance.saveSheet(NOWHERE, NOWHERE, DAY, [{ studentId: NOWHERE, status: 'present' }]),
    },
    listForStudent: { run: (b, c) => b.attendance.listForStudent(c.orgId, NOWHERE, { from: DAY, to: DAY }) },
    monthlySummary: { run: (b, c) => b.attendance.monthlySummary(c.orgId, NOWHERE, MONTH) },
  },
  exams: {
    list: { run: (b, c) => b.exams.list(c.orgId) },
    get: { accept: GONE, run: (b, c) => b.exams.get(c.orgId, NOWHERE) },
    create: {
      accept: REFUSED,
      run: (b) => b.exams.create(NOWHERE, { batchId: NOWHERE, name: LABEL, subject: LABEL, examDate: DAY, maxMarks: 100 }),
    },
    update: { accept: REFUSED, run: (b) => b.exams.update(NOWHERE, NOWHERE, { name: LABEL }) },
    remove: { accept: REFUSED, run: (b) => b.exams.remove(NOWHERE, NOWHERE) },
    getMarks: { run: (b, c) => b.exams.getMarks(c.orgId, NOWHERE) },
    saveMarks: { accept: REFUSED, run: (b) => b.exams.saveMarks(NOWHERE, NOWHERE, [{ studentId: NOWHERE, marks: 0 }]) },
    analysis: { accept: GONE, run: (b, c) => b.exams.analysis(c.orgId, NOWHERE) },
  },
  marks: {
    listForStudent: { run: (b, c) => b.marks.listForStudent(c.orgId, NOWHERE) },
  },
  fees: {
    getPlan: { run: (b, c) => b.fees.getPlan(c.orgId, NOWHERE) },
    savePlan: {
      accept: REFUSED,
      run: (b) => b.fees.savePlan(NOWHERE, { batchId: NOWHERE, name: LABEL, amount: 0, instalments: [] }),
    },
    listPayments: { run: (b, c) => b.fees.listPayments(c.orgId) },
    recordPayment: {
      accept: REFUSED,
      run: (b) => b.fees.recordPayment(NOWHERE, {
        studentId: NOWHERE, term: LABEL, amount: 0, method: 'cash', reference: null,
        paidOn: DAY, status: 'pending', recordedBy: null,
      }),
    },
    totals: { run: (b, c) => b.fees.totals(c.orgId, LABEL) },
    dueList: { run: (b, c) => b.fees.dueList(c.orgId, LABEL) },
  },
  content: {
    list: { run: (b, c) => b.content.list(c.orgId) },
    create: {
      accept: REFUSED,
      run: (b) => b.content.create(NOWHERE, {
        batchIds: [], type: 'link', title: LABEL, url: 'https://guruflow.invalid/contract-check',
        storageKey: null, durationSeconds: null, thumbnailUrl: null,
      }),
    },
    remove: { accept: REFUSED, run: (b) => b.content.remove(NOWHERE, NOWHERE) },
    storageUsed: { run: (b, c) => b.content.storageUsed(c.orgId) },
  },
  notices: {
    list: { run: (b, c) => b.notices.list(c.orgId) },
    create: {
      accept: REFUSED,
      run: (b) => b.notices.create(NOWHERE, {
        title: LABEL, body: LABEL, audience: [], category: 'general', eventDate: null, createdBy: null,
      }),
    },
    remove: { accept: REFUSED, run: (b) => b.notices.remove(NOWHERE, NOWHERE) },
  },
  notifications: {
    listMine: { run: (b) => b.notifications.listMine({ pageSize: 1 }) },
    markRead: { accept: REFUSED, run: (b) => b.notifications.markRead(NOWHERE) },
    markAllRead: { sideEffect: 'notifications', run: (b) => b.notifications.markAllRead() },
    unreadCount: { run: (b) => b.notifications.unreadCount() },
    create: {
      accept: REFUSED,
      run: (b) => b.notifications.create(NOWHERE, [NOWHERE], { title: LABEL, body: LABEL, type: 'announcement' }),
    },
  },
  leave: {
    list: { run: (b, c) => b.leave.list(c.orgId) },
    create: {
      accept: REFUSED,
      run: (b) => b.leave.create(NOWHERE, {
        requesterId: NOWHERE, studentId: null, leaveType: 'sick', fromDate: DAY, toDate: DAY, reason: null,
      }),
    },
    decide: { accept: REFUSED, run: (b) => b.leave.decide(NOWHERE, NOWHERE, false) },
  },
  storage: {
    upload: {
      sideEffect: 'upload',
      run: async (b) => {
        const { key } = await b.storage.upload(BUCKET, FILE);
        await b.storage.remove(BUCKET, key);
      },
    },
    remove: { accept: REFUSED, run: (b) => b.storage.remove(BUCKET, NOWHERE) },
    signedUrl: { accept: REFUSED, run: (b) => b.storage.signedUrl(BUCKET, NOWHERE, 60) },
  },
  payment: {
    createIntent: { accept: REFUSED, run: (b) => b.payment.createIntent(NOWHERE, NOWHERE) },
  },
  video: {
    playbackUrl: { accept: REFUSED, run: (b) => b.video.playbackUrl(NOWHERE) },
  },
  realtime: {
    subscribe: {
      provided: (b) => typeof b.realtime?.subscribe === 'function',
      run: (b) => mustUnsubscribe(b.realtime?.subscribe('notifications', () => undefined)),
    },
  },
};
