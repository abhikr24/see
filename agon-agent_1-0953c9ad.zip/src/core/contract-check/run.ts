import { isAppError, toAppError, type AppErrorCode } from '../contracts/errors';
import type { Backend } from '../contracts/ports';
import { NOWHERE, PROBES, type Probe, type ProbeContext, type SideEffect } from './probes';

export type CheckStatus = 'pass' | 'fail' | 'skipped';

/** Why a check ended the way it did. The screen turns this into words. */
export type CheckReason =
  | 'ok'            // resolved
  | 'refused'       // rejected the dummy input with an accepted AppError code
  | 'error'         // AppError the probe does not accept
  | 'raw_error'     // threw something that is not an AppError — a contract breach
  | 'timeout'
  | 'not_provided'  // optional member this adapter leaves out
  | 'side_effect';  // not called, because calling it is never harmless

export interface CheckItem {
  id: string;
  port: string;
  method: string;
  sideEffect: SideEffect | null;
}

export interface CheckResult extends CheckItem {
  status: CheckStatus;
  reason: CheckReason;
  code: AppErrorCode | null;
  /** The backend's own message, when it failed. */
  detail: string | null;
  ms: number;
}

export interface CheckGroup {
  port: string;
  items: CheckItem[];
}

export interface RunOptions {
  /** Institute for reads. Without one, reads are aimed at NOWHERE too. */
  orgId?: string | null;
  includeSideEffects?: boolean;
  timeoutMs?: number;
  onResult?: (result: CheckResult) => void;
}

interface Entry extends CheckItem { probe: Probe }

const ENTRIES: Entry[] = Object.entries(PROBES).flatMap(([port, methods]) =>
  Object.entries(methods as Record<string, Probe>).map(([method, probe]) => ({
    id: `${port}.${method}`, port, method, probe, sideEffect: probe.sideEffect ?? null,
  })),
);

const toItem = ({ id, port, method, sideEffect }: Entry): CheckItem => ({ id, port, method, sideEffect });

/** Every port method, grouped by port, in contract order. */
export const CHECK_GROUPS: CheckGroup[] = Object.keys(PROBES).map((port) => ({
  port,
  items: ENTRIES.filter((entry) => entry.port === port).map(toItem),
}));

export const CHECK_COUNT = ENTRIES.length;
export const SIDE_EFFECT_COUNT = ENTRIES.filter((entry) => entry.sideEffect !== null).length;

type Outcome = { kind: 'ok' } | { kind: 'timeout' } | { kind: 'threw'; error: unknown };

const TIMED_OUT = Symbol('timed out');

async function attempt(run: () => unknown, timeoutMs: number): Promise<Outcome> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<typeof TIMED_OUT>((resolve) => { timer = setTimeout(() => resolve(TIMED_OUT), timeoutMs); });
  try {
    // Promise.resolve().then(run) also catches a method that throws synchronously.
    const settled = await Promise.race([Promise.resolve().then(run), timeout]);
    return settled === TIMED_OUT ? { kind: 'timeout' } : { kind: 'ok' };
  } catch (error) {
    return { kind: 'threw', error };
  } finally {
    clearTimeout(timer);
  }
}

function judge(outcome: Outcome, probe: Probe, reachable: boolean): Pick<CheckResult, 'status' | 'reason' | 'code' | 'detail'> {
  if (outcome.kind === 'ok') return { status: 'pass', reason: 'ok', code: null, detail: null };
  if (outcome.kind === 'timeout') return { status: 'fail', reason: 'timeout', code: 'network', detail: null };
  const error = toAppError(outcome.error);
  if (!isAppError(outcome.error)) return { status: 'fail', reason: 'raw_error', code: error.code, detail: error.message };
  // A refusal only proves something once we know the backend is actually answering.
  if (reachable && probe.accept?.includes(error.code)) return { status: 'pass', reason: 'refused', code: error.code, detail: null };
  return { status: 'fail', reason: 'error', code: error.code, detail: error.message };
}

export interface Preflight {
  /** auth.getSession answered. Until it does, a refusal proves nothing. */
  reachable: boolean;
  /** Someone is signed in. Signed out, most backends return nothing for reads. */
  signedIn: boolean;
}

async function preflight(backend: Backend, timeoutMs: number): Promise<Preflight> {
  let session: unknown = null;
  const outcome = await attempt(async () => { session = await backend.auth.getSession(); }, timeoutMs);
  const reachable = outcome.kind === 'ok';
  return { reachable, signedIn: reachable && session !== null && session !== undefined };
}

/** Safe probes first, then the ones with side effects, and the session-ending one last of all. */
const rank = (entry: Entry): number => (entry.sideEffect === null ? 0 : entry.sideEffect === 'session' ? 2 : 1);

/**
 * Calls every method of every port on `backend`. Never throws: every outcome,
 * including a missing method, becomes a row in the result.
 */
export async function runContractCheck(
  backend: Backend,
  options: RunOptions = {},
): Promise<{ results: CheckResult[] } & Preflight> {
  const ctx: ProbeContext = { orgId: options.orgId || NOWHERE };
  const timeoutMs = options.timeoutMs ?? 10_000;
  const { reachable, signedIn } = await preflight(backend, timeoutMs);
  const results: CheckResult[] = [];

  for (const entry of [...ENTRIES].sort((a, b) => rank(a) - rank(b))) {
    const { probe } = entry;
    const started = Date.now();
    let verdict: Pick<CheckResult, 'status' | 'reason' | 'code' | 'detail'>;
    if (probe.provided && !probe.provided(backend)) {
      verdict = { status: 'skipped', reason: 'not_provided', code: null, detail: null };
    } else if (probe.sideEffect && !options.includeSideEffects) {
      verdict = { status: 'skipped', reason: 'side_effect', code: null, detail: null };
    } else {
      verdict = judge(await attempt(() => probe.run(backend, ctx), timeoutMs), probe, reachable);
    }
    const result: CheckResult = { ...toItem(entry), ...verdict, ms: Date.now() - started };
    results.push(result);
    options.onResult?.(result);
  }
  return { results, reachable, signedIn };
}

export function summarise(results: CheckResult[]): { passed: number; failed: number; skipped: number } {
  const count = (status: CheckStatus) => results.filter((result) => result.status === status).length;
  return { passed: count('pass'), failed: count('fail'), skipped: count('skipped') };
}
