import { useCallback, useMemo, useState } from 'react';
import { useBackend } from '../backend-context';
import { runContractCheck, summarise, type CheckResult, type Preflight } from './run';

/** Run state for the contract-check screen, so the screen itself stays layout only. */
export function useContractCheck(orgId: string | null) {
  const backend = useBackend();
  const [results, setResults] = useState<Record<string, CheckResult>>({});
  const [running, setRunning] = useState(false);
  const [preflight, setPreflight] = useState<Preflight | null>(null);

  const run = useCallback(async (includeSideEffects: boolean) => {
    setRunning(true);
    setResults({});
    setPreflight(null);
    try {
      const outcome = await runContractCheck(backend, {
        orgId,
        includeSideEffects,
        onResult: (result) => setResults((previous) => ({ ...previous, [result.id]: result })),
      });
      setPreflight({ reachable: outcome.reachable, signedIn: outcome.signedIn });
    } finally {
      setRunning(false);
    }
  }, [backend, orgId]);

  const summary = useMemo(() => summarise(Object.values(results)), [results]);
  const hasRun = Object.keys(results).length > 0;

  return { results, running, preflight, summary, hasRun, run };
}
