import type {
  AppNotification, Attendance, AttendanceStatus, Batch, ContentItem, Exam, FeePayment,
  FeePlan, FeeTotals, Homework, LeaveRequest, Mark, Membership, Notice, Org, Profile,
  Role, Student, Submission,
} from './models';
import type { ListQuery, Paginated } from './query';

/**
 * Every repo method is async, takes orgId as its first argument (except the
 * auth/membership ones, which are user-scoped), and is org-scoped. Implementations
 * must enforce orgId in the query even though RLS also enforces it.
 */

export interface Session {
  userId: string;
  email: string | null;
  phone: string | null;
}

export interface AuthPort {
  signInWithPassword(identifier: string, password: string): Promise<Session>;
  signInWithOtp(phone: string): Promise<void>;
  verifyOtp(phone: string, token: string): Promise<Session>;
  signUp(name: string, email: string, password: string): Promise<Session>;
  signOut(): Promise<void>;
  getSession(): Promise<Session | null>;
  onChange(cb: (s: Session | null) => void): () => void;
  signInWithGoogle?(): Promise<Session | null>;
}

export interface OrgRepo {
  get(orgId: string): Promise<Org>;
  getByCode(code: string): Promise<Org | null>;
  search(term: string): Promise<Org[]>;
  create(input: { name: string; type: string; city: string; state?: string; board?: string; logoUrl?: string | null; ownerUserId: string; ownerName: string }): Promise<Org>;
  update(orgId: string, patch: Partial<Org>): Promise<Org>;
}

export interface MembershipRepo {
  listMine(): Promise<Membership[]>;
  listPending(orgId: string): Promise<(Membership & { fullName: string; phone: string | null })[]>;
  /** Always for the signed-in user — the adapter reads the session, the caller never names a user. */
  requestJoin(orgId: string): Promise<Membership>;
  approve(orgId: string, id: string): Promise<void>;
  reject(orgId: string, id: string): Promise<void>;
  approveAll(orgId: string): Promise<number>;
  setRole(orgId: string, id: string, role: Role): Promise<void>;
}

export interface StudentRepo {
  list(orgId: string, q?: ListQuery): Promise<Paginated<Student>>;
  get(orgId: string, id: string): Promise<Student>;
  create(orgId: string, input: Omit<Student, 'id' | 'orgId'>): Promise<Student>;
  update(orgId: string, id: string, patch: Partial<Student>): Promise<Student>;
  remove(orgId: string, id: string): Promise<void>;
}

export interface BatchRepo {
  list(orgId: string, q?: ListQuery): Promise<Batch[]>;
  get(orgId: string, id: string): Promise<Batch>;
  create(orgId: string, input: Omit<Batch, 'id' | 'orgId'>): Promise<Batch>;
  update(orgId: string, id: string, patch: Partial<Batch>): Promise<Batch>;
  remove(orgId: string, id: string): Promise<void>;
  listForTeacher(orgId: string, membershipId: string): Promise<Batch[]>;
}

export interface AttendanceRow { studentId: string; status: AttendanceStatus }

export interface AttendanceRepo {
  getSheet(orgId: string, batchId: string, date: string): Promise<Attendance[]>;
  saveSheet(orgId: string, batchId: string, date: string, rows: AttendanceRow[]): Promise<void>;
  listForStudent(orgId: string, studentId: string, range: { from: string; to: string }): Promise<Attendance[]>;
  monthlySummary(orgId: string, batchId: string, month: string): Promise<{ present: number; late: number; absent: number; pct: number }>;
}

export interface ExamAnalysis {
  average: number; highest: number; lowest: number; passRate: number;
  top: { studentId: string; name: string; marks: number }[];
  subjectAvg: { subject: string; average: number }[];
}

export interface ExamRepo {
  list(orgId: string, q?: ListQuery): Promise<Exam[]>;
  get(orgId: string, id: string): Promise<Exam>;
  create(orgId: string, input: Omit<Exam, 'id' | 'orgId'>): Promise<Exam>;
  update(orgId: string, id: string, patch: Partial<Exam>): Promise<Exam>;
  remove(orgId: string, id: string): Promise<void>;
  getMarks(orgId: string, examId: string): Promise<Mark[]>;
  saveMarks(orgId: string, examId: string, rows: { studentId: string; marks: number }[]): Promise<void>;
  analysis(orgId: string, examId: string): Promise<ExamAnalysis>;
}

export interface MarkRepo {
  listForStudent(orgId: string, studentId: string): Promise<(Mark & { examName: string; subject: string; maxMarks: number })[]>;
}

export interface FeeRepo {
  getPlan(orgId: string, batchId: string): Promise<FeePlan | null>;
  savePlan(orgId: string, input: Omit<FeePlan, 'id' | 'orgId'>): Promise<FeePlan>;
  listPayments(orgId: string, q?: ListQuery): Promise<FeePayment[]>;
  recordPayment(orgId: string, input: Omit<FeePayment, 'id' | 'orgId' | 'receiptNo'>): Promise<FeePayment>;
  totals(orgId: string, term: string): Promise<FeeTotals>;
  dueList(orgId: string, term: string): Promise<(Student & { due: number; daysOverdue: number })[]>;
}

export interface ContentRepo {
  list(orgId: string, q?: ListQuery): Promise<ContentItem[]>;
  create(orgId: string, input: Omit<ContentItem, 'id' | 'orgId' | 'createdAt'>): Promise<ContentItem>;
  remove(orgId: string, id: string): Promise<void>;
  storageUsed(orgId: string): Promise<{ usedBytes: number; limitBytes: number }>;
}

export interface NoticeRepo {
  list(orgId: string, q?: ListQuery): Promise<Notice[]>;
  create(orgId: string, input: Omit<Notice, 'id' | 'orgId' | 'publishedAt'>): Promise<Notice>;
  remove(orgId: string, id: string): Promise<void>;
}

export interface NotificationRepo {
  listMine(q?: ListQuery): Promise<AppNotification[]>;
  markRead(id: string): Promise<void>;
  markAllRead(): Promise<void>;
  unreadCount(): Promise<number>;
  create(orgId: string, userIds: string[], payload: { title: string; body: string; type: string }): Promise<void>;
}

export interface LeaveRepo {
  list(orgId: string, q?: ListQuery): Promise<LeaveRequest[]>;
  create(orgId: string, input: Omit<LeaveRequest, 'id' | 'orgId' | 'status' | 'decidedBy' | 'decidedAt'>): Promise<LeaveRequest>;
  decide(orgId: string, id: string, approved: boolean): Promise<void>;
}

export interface StoragePort {
  upload(bucket: string, file: { uri: string; name: string; mime: string }, onProgress?: (p: number) => void): Promise<{ url: string; key: string }>;
  remove(bucket: string, key: string): Promise<void>;
  signedUrl(bucket: string, key: string, ttlSeconds: number): Promise<string>;
}

export interface PaymentPort {
  createIntent(orgId: string, paymentId: string): Promise<{ url: string }>;
}

export interface VideoPort {
  playbackUrl(contentId: string): Promise<{ url: string; token?: string }>;
}

export interface RealtimePort {
  subscribe(topic: string, cb: (payload: unknown) => void): () => void;
}

export interface Backend {
  auth: AuthPort;
  orgs: OrgRepo;
  memberships: MembershipRepo;
  students: StudentRepo;
  batches: BatchRepo;
  attendance: AttendanceRepo;
  exams: ExamRepo;
  marks: MarkRepo;
  fees: FeeRepo;
  content: ContentRepo;
  notices: NoticeRepo;
  notifications: NotificationRepo;
  leave: LeaveRepo;
  storage: StoragePort;
  payment: PaymentPort;
  video: VideoPort;
  realtime?: RealtimePort;
}

export type { Homework, Submission, Profile };
