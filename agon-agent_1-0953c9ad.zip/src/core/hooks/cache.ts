import type { Paginated } from '../contracts/query';

/**
 * Pure helpers that rewrite cached query data for an optimistic update.
 * Each one accepts whatever is in the cache — a plain array, a Paginated
 * page or a single record — and returns it untouched if the shape is not
 * one it understands, so a patch can never corrupt an unrelated query.
 */
type Row = { id: string };

const isRow = (value: unknown): value is Row =>
  typeof value === 'object' && value !== null && typeof (value as { id?: unknown }).id === 'string';

const isPage = (value: unknown): value is Paginated<Row> =>
  typeof value === 'object' && value !== null && Array.isArray((value as { rows?: unknown }).rows);

let tempCount = 0;

/** Id for a row that exists only in the cache until the backend answers. */
export const tempId = (): string => `temp-${Date.now()}-${++tempCount}`;

/** True while a row is still optimistic. Screens should not navigate into it. */
export const isTempId = (id: string): boolean => id.startsWith('temp-');

/** Put a new row at the top of a cached list. */
export function addRow(cached: unknown, row: Row): unknown {
  if (Array.isArray(cached)) return [row, ...cached];
  if (isPage(cached)) return { ...cached, rows: [row, ...cached.rows], total: cached.total + 1 };
  return cached;
}

/** Merge a patch into the row with this id, wherever it is cached. */
export function patchRow(cached: unknown, id: string, patch: object): unknown {
  const apply = (row: unknown): unknown => (isRow(row) && row.id === id ? { ...row, ...patch } : row);
  if (Array.isArray(cached)) return cached.map(apply);
  if (isPage(cached)) return { ...cached, rows: cached.rows.map(apply) };
  return apply(cached);
}

/** Drop the row with this id from a cached list. */
export function removeRow(cached: unknown, id: string): unknown {
  const keep = (row: unknown): boolean => !(isRow(row) && row.id === id);
  if (Array.isArray(cached)) return cached.filter(keep);
  if (isPage(cached)) {
    const rows = cached.rows.filter(keep);
    return { ...cached, rows, total: cached.total - (cached.rows.length - rows.length) };
  }
  return cached;
}

/**
 * Merge a batch into a cached array: rows that match are updated in place,
 * the rest are appended. `merge` receives undefined when it must build a new row.
 */
export function upsertRows<T, I>(
  cached: unknown,
  incoming: I[],
  same: (row: T, item: I) => boolean,
  merge: (row: T | undefined, item: I) => T,
): unknown {
  if (!Array.isArray(cached)) return cached;
  const used = new Set<I>();
  const updated = (cached as T[]).map((row) => {
    const item = incoming.find((candidate) => same(row, candidate));
    if (item === undefined) return row;
    used.add(item);
    return merge(row, item);
  });
  return [...updated, ...incoming.filter((item) => !used.has(item)).map((item) => merge(undefined, item))];
}
