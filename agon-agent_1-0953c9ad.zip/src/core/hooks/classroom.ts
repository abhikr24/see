import type { Attendance, Exam, Mark } from '../contracts/models';
import type { AttendanceRow, ExamRepo } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { copy } from '@/lib/copy';
import { useBackend } from '../backend-context';
import { addRow, patchRow, removeRow, tempId, upsertRows } from './cache';
import { keys } from './keys';
import { useDomainMutation, useDomainQuery } from './shared';

const t = copy.toast;

type ExamInput = Parameters<ExamRepo['create']>[1];
type MarkRow = Parameters<ExamRepo['saveMarks']>[2][number];

// ────────────────────────── attendance ──────────────────────────
export const useAttendanceSheet = (orgId: string, batchId: string, date: string) => {
  const b = useBackend();
  return useDomainQuery(
    keys.attendance.sheet(orgId, batchId, date),
    () => b.attendance.getSheet(orgId, batchId, date),
    !!orgId && !!batchId && !!date,
  );
};

export const useSaveAttendance = (orgId: string, batchId: string, date: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (rows: AttendanceRow[]) => b.attendance.saveSheet(orgId, batchId, date, rows),
    optimistic: [{
      key: keys.attendance.sheet(orgId, batchId, date),
      apply: (cached, rows) => upsertRows<Attendance, AttendanceRow>(
        cached, rows,
        (row, item) => row.studentId === item.studentId,
        (row, item) => (row
          ? { ...row, status: item.status }
          : { id: tempId(), orgId, batchId, studentId: item.studentId, date, status: item.status, markedBy: null }),
      ),
    }],
    // Attendance feeds the percentages shown on student and batch cards.
    invalidate: [keys.attendance.all(orgId), keys.students.all(orgId), keys.batches.all(orgId)],
    success: t.attendanceSaved,
  });
};

export const useStudentAttendance = (orgId: string, studentId: string, range: { from: string; to: string }) => {
  const b = useBackend();
  return useDomainQuery(
    keys.attendance.forStudent(orgId, studentId, range),
    () => b.attendance.listForStudent(orgId, studentId, range),
    !!orgId && !!studentId,
  );
};

export const useAttendanceSummary = (orgId: string, batchId: string, month: string) => {
  const b = useBackend();
  return useDomainQuery(
    keys.attendance.summary(orgId, batchId, month),
    () => b.attendance.monthlySummary(orgId, batchId, month),
    !!orgId && !!batchId && !!month,
  );
};

// ──────────────────────────── exams ─────────────────────────────
export const useExams = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.exams.list(orgId, q), () => b.exams.list(orgId, q), !!orgId);
};

export const useExam = (orgId: string, id: string) => {
  const b = useBackend();
  return useDomainQuery(keys.exams.one(orgId, id), () => b.exams.get(orgId, id), !!orgId && !!id);
};

export const useExamAnalysis = (orgId: string, examId: string) => {
  const b = useBackend();
  return useDomainQuery(keys.exams.analysis(orgId, examId), () => b.exams.analysis(orgId, examId), !!orgId && !!examId);
};

export const useCreateExam = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: ExamInput) => b.exams.create(orgId, input),
    optimistic: [{
      key: keys.exams.lists(orgId),
      apply: (cached, input) => {
        const row: Exam = { ...input, id: tempId(), orgId };
        return addRow(cached, row);
      },
    }],
    invalidate: [keys.exams.all(orgId)],
    success: t.examCreated,
  });
};

export const useUpdateExam = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: ({ id, patch }: { id: string; patch: Partial<Exam> }) => b.exams.update(orgId, id, patch),
    optimistic: [{ key: keys.exams.all(orgId), apply: (cached, { id, patch }) => patchRow(cached, id, patch) }],
    invalidate: [keys.exams.all(orgId), keys.marks.all(orgId)],
    success: t.examUpdated,
  });
};

export const useRemoveExam = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.exams.remove(orgId, id),
    optimistic: [{ key: keys.exams.lists(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.exams.all(orgId), keys.marks.all(orgId)],
    success: t.examRemoved,
  });
};

// ──────────────────────────── marks ─────────────────────────────
/** The marks sheet for one exam. */
export const useMarks = (orgId: string, examId: string) => {
  const b = useBackend();
  return useDomainQuery(keys.marks.sheet(orgId, examId), () => b.exams.getMarks(orgId, examId), !!orgId && !!examId);
};

export const useSaveMarks = (orgId: string, examId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (rows: MarkRow[]) => b.exams.saveMarks(orgId, examId, rows),
    optimistic: [{
      key: keys.marks.sheet(orgId, examId),
      apply: (cached, rows) => upsertRows<Mark, MarkRow>(
        cached, rows,
        (row, item) => row.studentId === item.studentId,
        (row, item) => (row
          ? { ...row, marks: item.marks }
          : { id: tempId(), examId, studentId: item.studentId, marks: item.marks }),
      ),
    }],
    // Saved marks change the analysis and the entered-count on the exam card.
    invalidate: [keys.marks.all(orgId), keys.exams.all(orgId)],
    success: t.marksSaved,
  });
};

/** Every mark one student has, with the exam it belongs to. */
export const useMarksForStudent = (orgId: string, studentId: string) => {
  const b = useBackend();
  return useDomainQuery(
    keys.marks.forStudent(orgId, studentId),
    () => b.marks.listForStudent(orgId, studentId),
    !!orgId && !!studentId,
  );
};
