import type { ListQuery } from '../contracts/query';

/**
 * Every query key in the app. Keys nest so one prefix reaches a whole domain:
 * invalidating keys.students.all(orgId) refreshes every student list and every
 * single-student query for that institute, and nothing from another institute.
 */
const scope = <N extends string>(name: N) => ({
  all: (orgId: string) => [name, orgId] as const,
  lists: (orgId: string) => [name, orgId, 'list'] as const,
  list: (orgId: string, q?: ListQuery) => [name, orgId, 'list', q ?? {}] as const,
  one: (orgId: string, id: string) => [name, orgId, 'one', id] as const,
});

export const keys = {
  students: scope('students'),
  batches: {
    ...scope('batches'),
    forTeacher: (orgId: string, membershipId: string) => ['batches', orgId, 'teacher', membershipId] as const,
  },
  attendance: {
    all: (orgId: string) => ['attendance', orgId] as const,
    sheet: (orgId: string, batchId: string, date: string) => ['attendance', orgId, 'sheet', batchId, date] as const,
    forStudent: (orgId: string, studentId: string, range: { from: string; to: string }) =>
      ['attendance', orgId, 'student', studentId, range] as const,
    summary: (orgId: string, batchId: string, month: string) => ['attendance', orgId, 'summary', batchId, month] as const,
  },
  exams: {
    ...scope('exams'),
    analysis: (orgId: string, examId: string) => ['exams', orgId, 'analysis', examId] as const,
  },
  marks: {
    all: (orgId: string) => ['marks', orgId] as const,
    sheet: (orgId: string, examId: string) => ['marks', orgId, 'sheet', examId] as const,
    forStudent: (orgId: string, studentId: string) => ['marks', orgId, 'student', studentId] as const,
  },
  /** `list` holds payments. */
  fees: {
    ...scope('fees'),
    plan: (orgId: string, batchId: string) => ['fees', orgId, 'plan', batchId] as const,
    totals: (orgId: string, term: string) => ['fees', orgId, 'totals', term] as const,
    dues: (orgId: string, term: string) => ['fees', orgId, 'dues', term] as const,
  },
  content: {
    ...scope('content'),
    storage: (orgId: string) => ['content', orgId, 'storage'] as const,
  },
  notices: scope('notices'),
  leave: scope('leave'),
  /** Notifications and memberships belong to the user, not to one institute. */
  notifications: {
    all: ['notifications'] as const,
    lists: ['notifications', 'list'] as const,
    list: (q?: ListQuery) => ['notifications', 'list', q ?? {}] as const,
    unread: ['notifications', 'unread'] as const,
  },
  memberships: {
    all: ['memberships'] as const,
    mine: ['memberships', 'mine'] as const,
    pending: (orgId: string) => ['memberships', 'pending', orgId] as const,
  },
};
