import type { ContentItem, FeePayment, LeaveRequest, Notice } from '../contracts/models';
import type { ContentRepo, FeeRepo, LeaveRepo, NoticeRepo, NotificationRepo } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { copy } from '@/lib/copy';
import { useBackend } from '../backend-context';
import { addRow, patchRow, removeRow, tempId } from './cache';
import { keys } from './keys';
import { useDomainMutation, useDomainQuery } from './shared';

const t = copy.toast;

type FeePlanInput = Parameters<FeeRepo['savePlan']>[1];
type PaymentInput = Parameters<FeeRepo['recordPayment']>[1];
type ContentInput = Parameters<ContentRepo['create']>[1];
type NoticeInput = Parameters<NoticeRepo['create']>[1];
type LeaveInput = Parameters<LeaveRepo['create']>[1];
type NotificationPayload = Parameters<NotificationRepo['create']>[2];

// ───────────────────────────── fees ─────────────────────────────
/** Recorded payments, newest first. */
export const useFees = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.fees.list(orgId, q), () => b.fees.listPayments(orgId, q), !!orgId);
};

export const useFeePlan = (orgId: string, batchId: string) => {
  const b = useBackend();
  return useDomainQuery(keys.fees.plan(orgId, batchId), () => b.fees.getPlan(orgId, batchId), !!orgId && !!batchId);
};

export const useFeeTotals = (orgId: string, term: string) => {
  const b = useBackend();
  return useDomainQuery(keys.fees.totals(orgId, term), () => b.fees.totals(orgId, term), !!orgId && !!term);
};

export const useDueList = (orgId: string, term: string) => {
  const b = useBackend();
  return useDomainQuery(keys.fees.dues(orgId, term), () => b.fees.dueList(orgId, term), !!orgId && !!term);
};

export const useSaveFeePlan = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: FeePlanInput) => b.fees.savePlan(orgId, input),
    invalidate: [keys.fees.all(orgId)],
    success: t.feePlanSaved,
  });
};

export const useRecordPayment = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: PaymentInput) => b.fees.recordPayment(orgId, input),
    optimistic: [{
      key: keys.fees.lists(orgId),
      apply: (cached, input) => {
        // The receipt number is issued by the backend; it stays blank until then.
        const row: FeePayment = { ...input, id: tempId(), orgId, receiptNo: '' };
        return addRow(cached, row);
      },
    }],
    // A payment moves the totals, the due list and each student's fee-due figure.
    invalidate: [keys.fees.all(orgId), keys.students.all(orgId)],
    success: t.paymentRecorded,
  });
};

// ──────────────────────────── content ───────────────────────────
export const useContent = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.content.list(orgId, q), () => b.content.list(orgId, q), !!orgId);
};

export const useStorageUsed = (orgId: string) => {
  const b = useBackend();
  return useDomainQuery(keys.content.storage(orgId), () => b.content.storageUsed(orgId), !!orgId);
};

export const useCreateContent = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: ContentInput) => b.content.create(orgId, input),
    optimistic: [{
      key: keys.content.lists(orgId),
      apply: (cached, input) => {
        const row: ContentItem = { ...input, id: tempId(), orgId, createdAt: new Date().toISOString() };
        return addRow(cached, row);
      },
    }],
    invalidate: [keys.content.all(orgId)],
    success: t.contentAdded,
  });
};

export const useRemoveContent = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.content.remove(orgId, id),
    optimistic: [{ key: keys.content.lists(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.content.all(orgId)],
    success: t.contentRemoved,
  });
};

// ──────────────────────────── notices ───────────────────────────
export const useNotices = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.notices.list(orgId, q), () => b.notices.list(orgId, q), !!orgId);
};

export const useCreateNotice = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: NoticeInput) => b.notices.create(orgId, input),
    optimistic: [{
      key: keys.notices.lists(orgId),
      apply: (cached, input) => {
        const row: Notice = { ...input, id: tempId(), orgId, publishedAt: new Date().toISOString() };
        return addRow(cached, row);
      },
    }],
    invalidate: [keys.notices.all(orgId)],
    success: t.noticePublished,
  });
};

export const useRemoveNotice = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.notices.remove(orgId, id),
    optimistic: [{ key: keys.notices.lists(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.notices.all(orgId)],
    success: t.noticeRemoved,
  });
};

// ───────────────────────── notifications ────────────────────────
export const useNotifications = (q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.notifications.list(q), () => b.notifications.listMine(q));
};

export const useUnreadCount = () => {
  const b = useBackend();
  return useDomainQuery(keys.notifications.unread, () => b.notifications.unreadCount());
};

/** Silent: reading a notification is not an event worth a toast. */
export const useMarkNotificationRead = () => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.notifications.markRead(id),
    optimistic: [{ key: keys.notifications.lists, apply: (cached, id) => patchRow(cached, id, { isRead: true }) }],
    invalidate: [keys.notifications.all],
  });
};

export const useMarkAllNotificationsRead = () => {
  const b = useBackend();
  return useDomainMutation<void, void>({
    run: () => b.notifications.markAllRead(),
    optimistic: [
      {
        key: keys.notifications.lists,
        apply: (cached) => (Array.isArray(cached) ? cached.map((row: object) => ({ ...row, isRead: true })) : cached),
      },
      { key: keys.notifications.unread, apply: (cached) => (typeof cached === 'number' ? 0 : cached) },
    ],
    invalidate: [keys.notifications.all],
  });
};

export const useSendNotification = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: ({ userIds, payload }: { userIds: string[]; payload: NotificationPayload }) =>
      b.notifications.create(orgId, userIds, payload),
    invalidate: [keys.notifications.all],
    success: t.notificationSent,
  });
};

// ───────────────────────────── leave ────────────────────────────
export const useLeave = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.leave.list(orgId, q), () => b.leave.list(orgId, q), !!orgId);
};

export const useCreateLeave = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: LeaveInput) => b.leave.create(orgId, input),
    optimistic: [{
      key: keys.leave.lists(orgId),
      apply: (cached, input) => {
        const row: LeaveRequest = { ...input, id: tempId(), orgId, status: 'pending', decidedBy: null, decidedAt: null };
        return addRow(cached, row);
      },
    }],
    invalidate: [keys.leave.all(orgId)],
    success: t.leaveRequested,
  });
};

export const useDecideLeave = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: ({ id, approved }: { id: string; approved: boolean }) => b.leave.decide(orgId, id, approved),
    optimistic: [{
      key: keys.leave.lists(orgId),
      apply: (cached, { id, approved }) => patchRow(cached, id, { status: approved ? 'approved' : 'rejected' }),
    }],
    invalidate: [keys.leave.all(orgId)],
    success: ({ approved }) => (approved ? t.leaveApproved : t.leaveRejected),
  });
};
