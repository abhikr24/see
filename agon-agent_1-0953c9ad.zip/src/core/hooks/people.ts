import type { Batch, Role, Student } from '../contracts/models';
import type { BatchRepo, StudentRepo } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { copy } from '@/lib/copy';
import { useBackend } from '../backend-context';
import { addRow, patchRow, removeRow, tempId } from './cache';
import { keys } from './keys';
import { isFirstPage, useDomainMutation, useDomainQuery } from './shared';

const t = copy.toast;

type StudentInput = Parameters<StudentRepo['create']>[1];
type BatchInput = Parameters<BatchRepo['create']>[1];

// ─────────────────────────── students ───────────────────────────
export const useStudents = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.students.list(orgId, q), () => b.students.list(orgId, q), !!orgId);
};

export const useStudent = (orgId: string, id: string) => {
  const b = useBackend();
  return useDomainQuery(keys.students.one(orgId, id), () => b.students.get(orgId, id), !!orgId && !!id);
};

export const useCreateStudent = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: StudentInput) => b.students.create(orgId, input),
    optimistic: [{
      key: keys.students.lists(orgId),
      apply: (cached, input, key) => {
        if (!isFirstPage(key)) return cached;
        const row: Student = { ...input, id: tempId(), orgId };
        return addRow(cached, row);
      },
    }],
    invalidate: [keys.students.all(orgId), keys.batches.all(orgId)],
    success: t.studentAdded,
  });
};

export const useUpdateStudent = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: ({ id, patch }: { id: string; patch: Partial<Student> }) => b.students.update(orgId, id, patch),
    optimistic: [{ key: keys.students.all(orgId), apply: (cached, { id, patch }) => patchRow(cached, id, patch) }],
    invalidate: [keys.students.all(orgId), keys.batches.all(orgId)],
    success: t.studentUpdated,
  });
};

export const useRemoveStudent = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.students.remove(orgId, id),
    optimistic: [{ key: keys.students.lists(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.students.all(orgId), keys.batches.all(orgId)],
    success: t.studentRemoved,
  });
};

// ─────────────────────────── batches ────────────────────────────
export const useBatches = (orgId: string, q?: ListQuery) => {
  const b = useBackend();
  return useDomainQuery(keys.batches.list(orgId, q), () => b.batches.list(orgId, q), !!orgId);
};

export const useBatch = (orgId: string, id: string) => {
  const b = useBackend();
  return useDomainQuery(keys.batches.one(orgId, id), () => b.batches.get(orgId, id), !!orgId && !!id);
};

export const useTeacherBatches = (orgId: string, membershipId: string) => {
  const b = useBackend();
  return useDomainQuery(
    keys.batches.forTeacher(orgId, membershipId),
    () => b.batches.listForTeacher(orgId, membershipId),
    !!orgId && !!membershipId,
  );
};

export const useCreateBatch = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (input: BatchInput) => b.batches.create(orgId, input),
    optimistic: [{
      key: keys.batches.lists(orgId),
      apply: (cached, input) => {
        const row: Batch = { ...input, id: tempId(), orgId };
        return addRow(cached, row);
      },
    }],
    invalidate: [keys.batches.all(orgId)],
    success: t.batchCreated,
  });
};

export const useUpdateBatch = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: ({ id, patch }: { id: string; patch: Partial<Batch> }) => b.batches.update(orgId, id, patch),
    optimistic: [{ key: keys.batches.all(orgId), apply: (cached, { id, patch }) => patchRow(cached, id, patch) }],
    invalidate: [keys.batches.all(orgId)],
    success: t.batchUpdated,
  });
};

export const useRemoveBatch = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.batches.remove(orgId, id),
    // One prefix covers the institute's lists and each teacher's list.
    optimistic: [{ key: keys.batches.all(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.batches.all(orgId), keys.students.all(orgId)],
    success: t.batchRemoved,
  });
};

// ────────────────────────── memberships ─────────────────────────
/** The signed-in user's memberships, across every institute. */
export const useMembership = () => {
  const b = useBackend();
  return useDomainQuery(keys.memberships.mine, () => b.memberships.listMine());
};

export const usePendingMemberships = (orgId: string) => {
  const b = useBackend();
  return useDomainQuery(keys.memberships.pending(orgId), () => b.memberships.listPending(orgId), !!orgId);
};

export const useRequestJoin = () => {
  const b = useBackend();
  return useDomainMutation({
    run: (orgId: string) => b.memberships.requestJoin(orgId),
    invalidate: [keys.memberships.all],
    success: t.joinRequested,
  });
};

export const useApproveMembership = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.memberships.approve(orgId, id),
    optimistic: [{ key: keys.memberships.pending(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.memberships.all],
    success: t.memberApproved,
  });
};

export const useRejectMembership = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: (id: string) => b.memberships.reject(orgId, id),
    optimistic: [{ key: keys.memberships.pending(orgId), apply: (cached, id) => removeRow(cached, id) }],
    invalidate: [keys.memberships.all],
    success: t.memberRejected,
  });
};

export const useApproveAllMemberships = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation<void, number>({
    run: () => b.memberships.approveAll(orgId),
    optimistic: [{ key: keys.memberships.pending(orgId), apply: (cached) => (Array.isArray(cached) ? [] : cached) }],
    invalidate: [keys.memberships.all],
    success: t.allApproved,
  });
};

export const useSetMemberRole = (orgId: string) => {
  const b = useBackend();
  return useDomainMutation({
    run: ({ id, role }: { id: string; role: Role }) => b.memberships.setRole(orgId, id, role),
    optimistic: [{ key: keys.memberships.all, apply: (cached, { id, role }) => patchRow(cached, id, { role }) }],
    invalidate: [keys.memberships.all],
    success: t.roleChanged,
  });
};
