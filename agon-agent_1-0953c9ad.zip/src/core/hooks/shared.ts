import {
  useMutation, useQuery, useQueryClient,
  type QueryClient, type QueryKey, type UseMutationOptions,
} from '@tanstack/react-query';
import { ERROR_COPY, toAppError, type AppError } from '../contracts/errors';
import { toast } from '../toast';

/** Every query hook returns exactly this. */
export interface QueryResult<T> {
  data: T | undefined;
  loading: boolean;
  error: AppError | null;
  refetch: () => void;
}

/** Every mutation hook returns exactly this. */
export interface MutationResult<TArgs, TResult> {
  mutate: (args: TArgs) => void;
  mutateAsync: (args: TArgs) => Promise<TResult>;
  loading: boolean;
  error: AppError | null;
}

/** How one mutation rewrites the cache before the backend answers. */
export interface Optimistic<TArgs> {
  /** Key prefix. Every cached query under it is offered to `apply`. */
  key: QueryKey;
  apply: (cached: unknown, args: TArgs, key: QueryKey) => unknown;
}

export interface MutationSpec<TArgs, TResult> {
  run: (args: TArgs) => Promise<TResult>;
  /** Key prefixes to refetch once the mutation settles, success or failure. */
  invalidate: QueryKey[];
  optimistic?: Optimistic<TArgs>[];
  /** Toast shown on success. Leave out for a silent mutation. */
  success?: string | ((args: TArgs) => string);
}

type Snapshot = [QueryKey, unknown][];

/** Nothing above this line of defence ever sees an error that is not an AppError. */
async function normalised<T>(fn: () => Promise<T>): Promise<T> {
  try { return await fn(); } catch (e) { throw toAppError(e); }
}

/** False for page 2 onward of a paginated list — a new row belongs only on the first page. */
export function isFirstPage(key: QueryKey): boolean {
  const last = key[key.length - 1];
  if (typeof last !== 'object' || last === null) return true;
  return !(Number((last as { page?: unknown }).page) > 0);
}

export function useDomainQuery<T>(key: QueryKey, fn: () => Promise<T>, enabled = true): QueryResult<T> {
  const q = useQuery<T, AppError>({ queryKey: key, queryFn: () => normalised(fn), enabled, staleTime: 30_000 });
  return { data: q.data, loading: q.isLoading, error: q.error, refetch: () => { void q.refetch(); } };
}

/**
 * The one place a mutation's lifecycle is decided:
 *   before  → cancel in-flight reads, snapshot the cache, apply the optimistic patch
 *   failure → put the snapshot back, raise an error toast
 *   success → raise the success toast
 *   always  → refetch whatever the mutation could have changed
 * Kept free of React so it can be exercised without rendering anything.
 */
export function mutationOptions<TArgs, TResult>(
  qc: QueryClient,
  spec: MutationSpec<TArgs, TResult>,
): UseMutationOptions<TResult, AppError, TArgs, Snapshot> {
  return {
    mutationFn: (args) => normalised(() => spec.run(args)),
    onMutate: async (args) => {
      const snapshot: Snapshot = [];
      for (const patch of spec.optimistic ?? []) {
        await qc.cancelQueries({ queryKey: patch.key });
        for (const [key, cached] of qc.getQueriesData<unknown>({ queryKey: patch.key })) {
          if (cached === undefined) continue;
          snapshot.push([key, cached]);
          qc.setQueryData(key, patch.apply(cached, args, key));
        }
      }
      return snapshot;
    },
    onError: (error, _args, snapshot) => {
      // Newest first, so a key patched twice ends on its original value.
      [...(snapshot ?? [])].reverse().forEach(([key, cached]) => qc.setQueryData(key, cached));
      toast.error(ERROR_COPY[toAppError(error).code]);
    },
    onSuccess: (_result, args) => {
      if (spec.success) toast.success(typeof spec.success === 'function' ? spec.success(args) : spec.success);
    },
    onSettled: () => Promise.all(spec.invalidate.map((key) => qc.invalidateQueries({ queryKey: key }))),
  };
}

export function useDomainMutation<TArgs, TResult>(spec: MutationSpec<TArgs, TResult>): MutationResult<TArgs, TResult> {
  const qc = useQueryClient();
  const m = useMutation(mutationOptions(qc, spec));
  return { mutate: m.mutate, mutateAsync: m.mutateAsync, loading: m.isPending, error: m.error };
}
