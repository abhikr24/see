/**
 * UI-free toast bus. Hooks publish here; whichever toast host the UI mounts
 * subscribes. Living outside the component tree is what lets the central
 * mutation handler raise a toast without importing a single component.
 *
 * With no subscriber a message is simply dropped — nothing is queued.
 */
export type ToastTone = 'success' | 'error';

export interface ToastMessage {
  id: number;
  tone: ToastTone;
  text: string;
}

type Listener = (message: ToastMessage) => void;

const listeners = new Set<Listener>();
let lastId = 0;

function publish(tone: ToastTone, text: string): ToastMessage {
  const message: ToastMessage = { id: ++lastId, tone, text };
  listeners.forEach((listener) => listener(message));
  return message;
}

export const toast = {
  success: (text: string): ToastMessage => publish('success', text),
  error: (text: string): ToastMessage => publish('error', text),
  /** Returns an unsubscribe function. */
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => { listeners.delete(listener); };
  },
};
