/**
 * Single source of truth for every colour, radius, spacing and shadow.
 * No component may hardcode a hex value. See AGENTS.md § Design system.
 */
export const C = {
  canvas: '#F5F6FA',
  surface: '#FFFFFF',
  ink: '#0B1220',
  secondary: '#5A6684',
  muted: '#94A0BC',
  hairline: '#E7EBF5',
  primary: '#101B4C',
  primary2: '#1E3A8A',
  accent: '#FF7A1A',
  accentSoft: '#FFF1E6',
  teal: '#0D9488',
  tealSoft: '#E4F7F4',
  success: '#16A34A',
  successSoft: '#DCF5E5',
  warning: '#F59E0B',
  warningSoft: '#FEF1D6',
  danger: '#DC2626',
  dangerSoft: '#FEECEC',
  track: '#EFF2F8',
  navySoft: '#E8EEFF',
} as const;

export const GRADIENT = [C.primary, C.primary2] as const;
export const FONT_SIZE = { h1: 34, h2: 22, title: 17, body: 15, caption: 13, label: 11 } as const;
export const hit = 44;

export const R = { card: 20, btn: 16, field: 14, sheet: 28, chip: 999 } as const;

export const S = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32 } as const;

/** Screen side margin, card padding, and minimum touch target. */
export const LAYOUT = { margin: 20, cardPad: 18, hit: 44, row: 68 } as const;

export const FONT = {
  heading: 'System',
  body: 'System',
  mono: 'Courier',
} as const;

export const SHADOW = {
  shadowColor: '#101B4C',
  shadowOpacity: 0.08,
  shadowRadius: 12,
  shadowOffset: { width: 0, height: 8 },
  elevation: 3,
} as const;

export type Tone = 'neutral' | 'success' | 'warning' | 'danger' | 'teal' | 'accent' | 'primary';

export const TONE: Record<Tone, { fg: string; bg: string }> = {
  neutral: { fg: C.secondary, bg: C.track },
  success: { fg: C.success, bg: C.successSoft },
  warning: { fg: C.warning, bg: C.warningSoft },
  danger: { fg: C.danger, bg: C.dangerSoft },
  teal: { fg: C.teal, bg: C.tealSoft },
  accent: { fg: C.accent, bg: C.accentSoft },
  primary: { fg: C.primary, bg: C.navySoft },
};
