import React, { useCallback } from 'react';
import { View, ScrollView, Pressable, StyleSheet, Linking, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Text, Card, Button } from '@/components/ui';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { useHomeworkDetail } from '@/features/student/homework/hooks';
import { router } from 'expo-router';

export default function HomeworkDetailScreen() {
  const vm = useHomeworkDetail();

  const pickImage = useCallback(async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed', 'Allow access to photos to upload homework.');
      return;
    }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (!res.canceled && res.assets[0]) {
      const asset = res.assets[0];
      vm.addFile(asset.fileName ?? `photo-${Date.now()}.jpg`, asset.uri);
    }
  }, [vm]);

  const takePhoto = useCallback(async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Permission needed', 'Allow camera access to take a photo.');
      return;
    }
    const res = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (!res.canceled && res.assets[0]) {
      const asset = res.assets[0];
      vm.addFile(asset.fileName ?? `capture-${Date.now()}.jpg`, asset.uri);
    }
  }, [vm]);

  if (vm.loading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text c={C.secondary}>Loading homework...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!vm.item || !vm.card) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: LAYOUT.margin }}>
          <Text variant="title" weight={700} c={C.ink}>
            Homework not found
          </Text>
          <Pressable onPress={() => router.back()} style={{ marginTop: 12 }}>
            <Text c={C.primary} weight={600}>
              Go back
            </Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 140, gap: 16 }}>
        <Pressable onPress={() => router.back()} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="chevron-back" size={20} color={C.primary} />
          <Text weight={600} c={C.primary}>
            Homework
          </Text>
        </Pressable>

        <View style={{ gap: 8 }}>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <View style={[styles.subjectChip, { backgroundColor: vm.card.subjectTintBg }]}>
              <Ionicons name={vm.card.subjectIcon as any} size={16} color={vm.card.subjectTintFg} />
              <Text variant="label" weight={700} c={vm.card.subjectTintFg}>
                {vm.card.subjectName ?? 'General'}
              </Text>
            </View>
            {vm.card.isOverdue ? (
              <View style={[styles.subjectChip, { backgroundColor: C.dangerSoft }]}>
                <Text variant="label" weight={700} c={C.danger}>
                  {vm.card.overdueText}
                </Text>
              </View>
            ) : null}
          </View>
          <Text variant="h2" weight={800} c={C.ink}>
            {vm.card.title}
          </Text>
          <Text variant="caption" c={C.secondary}>
            {vm.card.subjectName} · {vm.card.teacherName} · {vm.card.dueLabel}
          </Text>
        </View>

        {/* Instructions */}
        <Card flat style={{ gap: 8, padding: 16 }}>
          <Text variant="label" weight={700} c={C.muted}>
            INSTRUCTIONS
          </Text>
          <Text variant="body" c={C.ink} style={{ lineHeight: 22 }}>
            {vm.item.description || 'Complete the work neatly and submit before the due time.'}
          </Text>
        </Card>

        {/* Attachment */}
        {(vm.item.attachmentNames.length > 0 || vm.item.linkUrl) && (
          <Card flat style={{ gap: 10, padding: 16 }}>
            <Text variant="label" weight={700} c={C.muted}>
              ATTACHMENTS
            </Text>
            {vm.item.attachmentNames.map((name) => (
              <View key={name} style={styles.attachmentRow}>
                <View style={styles.attIcon}>
                  <Ionicons name="document" size={18} color={C.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text variant="body" weight={600} c={C.ink} numberOfLines={1}>
                    {name}
                  </Text>
                  <Text variant="caption" c={C.secondary}>
                    PDF · Tap to download
                  </Text>
                </View>
                <Pressable onPress={() => Alert.alert('Download', `Downloading ${name}... (offline allowed)`)} style={styles.downloadBtn}>
                  <Ionicons name="download-outline" size={18} color={C.primary} />
                </Pressable>
              </View>
            ))}
            {vm.item.linkUrl ? (
              <Pressable
                onPress={() => Linking.openURL(vm.item.linkUrl as string)}
                style={({ pressed }) => [styles.attachmentRow, { opacity: pressed ? 0.7 : 1 }]}
              >
                <View style={[styles.attIcon, { backgroundColor: C.accentSoft }]}>
                  <Ionicons name="link" size={18} color={C.accent} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text variant="body" weight={600} c={C.ink} numberOfLines={1}>
                    Reference link
                  </Text>
                  <Text variant="caption" c={C.secondary} numberOfLines={1}>
                    {vm.item.linkUrl}
                  </Text>
                </View>
                <Ionicons name="open-outline" size={18} color={C.secondary} />
              </Pressable>
            ) : null}
          </Card>
        )}

        {/* Your submission */}
        <Card flat style={{ gap: 12, padding: 16 }}>
          <Text variant="label" weight={700} c={C.muted}>
            YOUR SUBMISSION
          </Text>

          {vm.optimisticSubmitted ? (
            <View style={styles.optimisticBox}>
              <Ionicons name="checkmark-circle" size={22} color={C.teal} />
              <Text variant="body" weight={700} c={C.teal}>
                Submitted! Showing on teacher tracker.
              </Text>
              <Text variant="caption" c={C.secondary}>
                It will be synced in {vm.countdown}s
              </Text>
            </View>
          ) : null}

          {/* Photo upload zone */}
          <Pressable onPress={takePhoto} style={({ pressed }) => [styles.uploadZone, { opacity: pressed ? 0.9 : 1 }]}>
            <Ionicons name="camera" size={24} color={C.primary} />
            <Text variant="title" weight={700} c={C.ink} style={{ marginTop: 8 }}>
              Take a photo of your work
            </Text>
            <Text variant="caption" c={C.secondary} style={{ marginTop: 2, textAlign: 'center' }}>
              Capture your notebook or worksheet
            </Text>
            <View style={styles.uploadBtn}>
              <Text variant="label" weight={700} c={C.surface}>
                Open Camera
              </Text>
            </View>
          </Pressable>

          <View style={styles.orRow}>
            <View style={styles.line} />
            <Text variant="label" c={C.muted}>
              or attach a file
            </Text>
            <View style={styles.line} />
          </View>

          <View style={styles.fileActions}>
            <Pressable onPress={pickImage} style={({ pressed }) => [styles.fileBtn, { opacity: pressed ? 0.8 : 1 }]}>
              <Ionicons name="image-outline" size={18} color={C.primary} />
              <Text variant="label" weight={600} c={C.primary}>
                Photo Library
              </Text>
            </Pressable>
            <Pressable onPress={() => Alert.alert('Attach File', 'File picker would open here (PDF, DOC).')} style={({ pressed }) => [styles.fileBtn, { opacity: pressed ? 0.8 : 1 }]}>
              <Ionicons name="document-attach-outline" size={18} color={C.primary} />
              <Text variant="label" weight={600} c={C.primary}>
                Browse Files
              </Text>
            </Pressable>
          </View>

          {vm.localFiles.length > 0 ? (
            <View style={{ gap: 8, marginTop: 4 }}>
              {vm.localFiles.map((f) => (
                <View key={f.name} style={styles.fileChip}>
                  <Ionicons name="document-text" size={16} color={C.primary} />
                  <Text variant="caption" weight={600} c={C.ink} numberOfLines={1} style={{ flex: 1 }}>
                    {f.name}
                  </Text>
                  <Pressable onPress={() => vm.removeFile(f.name)} hitSlop={8}>
                    <Ionicons name="close-circle" size={18} color={C.muted} />
                  </Pressable>
                </View>
              ))}
            </View>
          ) : null}
        </Card>

        <View style={{ height: 10 }} />
      </ScrollView>

      {/* Sticky footer with Submit + Undo */}
      <View style={styles.footer}>
        {vm.undoVisible ? (
          <View style={styles.undoBar}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 }}>
              <Ionicons name="time-outline" size={18} color={C.ink} />
              <Text variant="body" weight={600} c={C.ink}>
                Submitting in {vm.countdown}s
              </Text>
            </View>
            <Pressable onPress={vm.undoSubmit} style={styles.undoBtn}>
              <Text variant="label" weight={700} c={C.surface}>
                Undo
              </Text>
            </Pressable>
          </View>
        ) : (
          <Pressable
            onPress={vm.triggerOptimisticSubmit}
            disabled={vm.submitting || vm.optimisticSubmitted}
            style={({ pressed }) => [
              styles.submitFooterBtn,
              (vm.submitting || vm.optimisticSubmitted) && { opacity: 0.6 },
              { opacity: pressed ? 0.9 : 1 },
            ]}
          >
            <Text variant="title" weight={800} c={C.surface}>
              {vm.card.submitted || vm.optimisticSubmitted ? 'Submitted ✓' : 'Submit Homework'}
            </Text>
            <Ionicons name="arrow-forward" size={18} color={C.surface} />
          </Pressable>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  subjectChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#EFF2F8',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  attachmentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: C.canvas,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: C.hairline,
  },
  attIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: C.navySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  downloadBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: C.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: C.hairline,
  },
  uploadZone: {
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderColor: C.cardDash,
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.createCanvas,
  },
  uploadBtn: {
    marginTop: 12,
    backgroundColor: C.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
  },
  orRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginVertical: 4,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: C.hairline,
  },
  fileActions: {
    flexDirection: 'row',
    gap: 10,
  },
  fileBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.hairline,
    paddingVertical: 12,
    borderRadius: 12,
  },
  fileChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.hairline,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
  },
  optimisticBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: C.tealSoft,
    borderRadius: 12,
    padding: 12,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: LAYOUT.margin,
    backgroundColor: C.surface,
    borderTopWidth: 1,
    borderTopColor: C.hairline,
  },
  undoBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: C.warningSoft,
    padding: 12,
    borderRadius: 14,
  },
  undoBtn: {
    backgroundColor: C.ink,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
  },
  submitFooterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: C.primary,
    paddingVertical: 16,
    borderRadius: 16,
  },
});
