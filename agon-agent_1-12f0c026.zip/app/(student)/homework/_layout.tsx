import React from 'react';
import { Stack } from 'expo-router';
import { C } from '@/lib/theme';

export default function HomeworkLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: C.canvas },
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Homework' }} />
      <Stack.Screen name="[id]" options={{ title: 'Homework Detail' }} />
      <Stack.Screen name="materials" options={{ title: 'Materials' }} />
      <Stack.Screen name="practice" options={{ title: 'Practice' }} />
    </Stack>
  );
}
