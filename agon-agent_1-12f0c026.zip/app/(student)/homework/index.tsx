import React, { useCallback } from 'react';
import { View, FlatList, Pressable, RefreshControl, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text, SegmentedControl, Card, EmptyState, ListSkeleton } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';
import { useStudentHomeworkBoard } from '@/features/student/homework/hooks';
import { HomeworkCard } from '@/features/student/homework/components/HomeworkCard';
import type { HomeworkSegment } from '@/features/student/homework/model';

const SEG_OPTS = [
  { value: 'due', label: 'Due' },
  { value: 'submitted', label: 'Submitted' },
  { value: 'overdue', label: 'Overdue' },
];

export default function StudentHomeworkListScreen() {
  const vm = useStudentHomeworkBoard();

  const renderHeader = useCallback(
    () => (
      <View style={{ gap: 14, paddingBottom: 12 }}>
        <View style={styles.topHeader}>
          <Text variant="h1">Homework</Text>
          <View style={styles.topActions}>
            <Pressable onPress={vm.openMaterials} style={styles.iconAction}>
              <Ionicons name="folder" size={18} color={C.primary} />
              <Text variant="label" weight={700} c={C.primary}>
                Materials
              </Text>
            </Pressable>
            <Pressable onPress={vm.openPractice} style={[styles.iconAction, { backgroundColor: C.primary }]}>
              <Ionicons name="play" size={16} color={C.surface} />
              <Text variant="label" weight={700} c={C.surface}>
                Practice
              </Text>
            </Pressable>
          </View>
        </View>

        <SegmentedControl
          options={SEG_OPTS.map((o) => ({
            ...o,
            label: `${o.label} ${o.value === 'due' ? `(${vm.counts.due})` : o.value === 'submitted' ? `(${vm.counts.submitted})` : `(${vm.counts.overdue})`}`,
          })) as any}
          value={vm.segment}
          onChange={(v) => vm.setSegment(v as HomeworkSegment)}
        />
      </View>
    ),
    [vm],
  );

  if (vm.loading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
        <View style={{ padding: LAYOUT.margin, flex: 1 }}>
          {renderHeader()}
          <ListSkeleton rows={4} h={110} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <FlatList
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 120, gap: 12 }}
        data={vm.visibleCards}
        keyExtractor={(it) => it.id}
        ListHeaderComponent={renderHeader}
        renderItem={({ item }) => (
          <HomeworkCard item={item} onPress={() => vm.openHomework(item.id)} onSubmit={() => vm.openHomework(item.id)} />
        )}
        ListEmptyComponent={
          <Card flat>
            <EmptyState
              icon="book-outline"
              title={vm.segment === 'due' ? 'All caught up!' : vm.segment === 'submitted' ? 'No submissions yet' : 'No overdue work'}
              text={
                vm.segment === 'due'
                  ? 'You have no pending homework right now. Enjoy your free time!'
                  : vm.segment === 'submitted'
                    ? 'Submit your first homework to see it here.'
                    : 'Great job staying on top of deadlines!'
              }
            />
          </Card>
        }
        refreshControl={<RefreshControl refreshing={vm.refreshing} onRefresh={vm.refresh} tintColor={C.primary} />}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  topHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  topActions: {
    flexDirection: 'row',
    gap: 8,
  },
  iconAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: C.surface,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: C.hairline,
  },
});
