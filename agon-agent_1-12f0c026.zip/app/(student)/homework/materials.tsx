import React, { useCallback } from 'react';
import { View, FlatList, Pressable, StyleSheet, RefreshControl, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Text, SegmentedControl, EmptyState, ListSkeleton, Card } from '@/components/ui';
import { C, LAYOUT } from '@/lib/theme';
import { useStudentMaterialsBoard } from '@/features/student/materials/hooks';
import { MaterialCard } from '@/features/student/materials/components/MaterialCard';
import { SUBJECT_FILTERS } from '@/features/student/materials/model';

const TABS = [
  { value: 'materials', label: 'Materials' },
  { value: 'bookmarks', label: 'Bookmarks' },
];

export default function StudentMaterialsScreen() {
  const vm = useStudentMaterialsBoard();

  const onDownload = useCallback((id: string, title: string) => {
    Alert.alert('Download', `Downloading "${title}"... Available offline after toggle.`);
  }, []);

  const renderHeader = useCallback(
    () => (
      <View style={{ gap: 14, paddingBottom: 8 }}>
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={20} color={C.primary} />
          </Pressable>
          <Text variant="h2" weight={800} c={C.ink}>
            Materials
          </Text>
          <View style={{ width: 32 }} />
        </View>

        <SegmentedControl options={TABS as any} value={vm.tab} onChange={(v) => vm.setTab(v as any)} />

        {vm.tab === 'materials' ? (
          <View style={styles.chipScroll}>
            <FlatList
              horizontal
              showsHorizontalScrollIndicator={false}
              data={SUBJECT_FILTERS}
              keyExtractor={(it) => it}
              contentContainerStyle={{ gap: 8 }}
              renderItem={({ item }) => {
                const active = vm.subjectFilter === item;
                return (
                  <Pressable
                    onPress={() => vm.setSubjectFilter(item)}
                    style={[styles.subjectChip, active && styles.subjectChipActive]}
                  >
                    <Text variant="label" weight={600} c={active ? C.surface : C.secondary}>
                      {item}
                    </Text>
                  </Pressable>
                );
              }}
            />
          </View>
        ) : null}
      </View>
    ),
    [vm],
  );

  if (vm.loading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }}>
        <View style={{ padding: LAYOUT.margin, flex: 1, gap: 12 }}>
          {renderHeader()}
          <ListSkeleton rows={4} h={160} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <FlatList
        data={vm.visibleCards}
        numColumns={2}
        keyExtractor={(it) => it.id}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 120, gap: 12 }}
        columnWrapperStyle={{ gap: 12 }}
        renderItem={({ item }) => (
          <MaterialCard
            item={item}
            onToggleOffline={() => vm.toggleOffline(item.id)}
            onToggleBookmark={() => vm.toggleBookmark(item)}
            onDownload={() => onDownload(item.id, item.title)}
            onPress={() => Alert.alert(item.title, item.description ?? 'No description')}
          />
        )}
        ListEmptyComponent={
          <Card flat style={{ marginTop: 20 }}>
            <EmptyState
              icon={vm.tab === 'bookmarks' ? 'bookmark-outline' : 'document-outline'}
              title={vm.tab === 'bookmarks' ? 'No saved items' : 'No materials'}
              text={vm.tab === 'bookmarks' ? 'Bookmark materials to find them quickly later.' : 'Materials shared by your teachers will appear here.'}
            />
          </Card>
        }
        refreshControl={<RefreshControl refreshing={vm.refreshing} onRefresh={vm.refresh} tintColor={C.primary} />}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: C.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: C.hairline,
  },
  chipScroll: {
    marginTop: 4,
  },
  subjectChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.hairline,
  },
  subjectChipActive: {
    backgroundColor: C.primary,
    borderColor: C.primary,
  },
});
