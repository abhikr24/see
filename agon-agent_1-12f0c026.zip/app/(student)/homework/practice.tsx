import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, ScrollView, Pressable, StyleSheet, FlatList, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Text, Card, Button, SegmentedControl, EmptyState } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';
import { usePracticeBoard, usePracticeTest } from '@/features/student/practice/hooks';
import { OptionCard } from '@/features/student/practice/components/OptionCard';
import { ScoreRing } from '@/features/student/practice/components/ScoreRing';
import { MistakesList } from '@/features/student/practice/components/MistakesList';
type Screen = 'picker' | 'question' | 'result';

export default function PracticeScreen() {
  const [screen, setScreen] = useState<Screen>('picker');
  const board = usePracticeBoard();
  const [selectedCount, setSelectedCount] = useState<number>(10);
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null);
  const [finalAttemptId, setFinalAttemptId] = useState<string | null>(null);

  const activeQuizId = selectedQuizId ?? board.selectedQuiz?.quizId ?? null;

  // When board loads, set default count
  useEffect(() => {
    if (board.countOptions.length > 0) {
      const has = board.countOptions.includes(selectedCount);
      if (!has) setSelectedCount(board.countOptions[0]);
    }
  }, [board.countOptions]);

  // Practice test hook – only active when in question screen
  const test = usePracticeTest({
    quizId: (screen === 'question' || screen === 'result') && activeQuizId ? activeQuizId : board.selectedQuiz?.quizId ?? '',
    questionCount: selectedCount,
  });

  const startPractice = useCallback(() => {
    if (!activeQuizId) {
      Alert.alert('Select a chapter', 'Choose a chapter to start practice.');
      return;
    }
    setScreen('question');
  }, [activeQuizId]);

  const handleFinish = useCallback(async () => {
    const final = await test.finish();
    if (final) {
      setFinalAttemptId(final.id);
      setScreen('result');
    }
  }, [test]);

  const handleExit = useCallback(() => {
    setScreen('picker');
    setFinalAttemptId(null);
  }, []);

  // Picker Screen
  if (screen === 'picker') {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
        <ScrollView contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 120, gap: 16 }}>
          <View style={styles.headerRow}>
            <Pressable onPress={() => router.back()} style={styles.backBtn}>
              <Ionicons name="chevron-back" size={20} color={C.primary} />
            </Pressable>
            <Text variant="h2" weight={800} c={C.ink}>
              Practice
            </Text>
            <View style={{ width: 32 }} />
          </View>

          <Text variant="caption" c={C.secondary}>
            Chapter-wise practice. Scoring happens in the repo so answer keys never ship to the client.
          </Text>

          {/* Chapter picker */}
          <Card flat style={{ gap: 12, padding: 16 }}>
            <Text variant="label" weight={700} c={C.muted}>
              CHAPTER
            </Text>
            {board.chapters.length === 0 ? (
              <EmptyState icon="book-outline" title="No chapters" text="Practice quizzes will appear here when teachers publish them." />
            ) : (
              <View style={{ gap: 10 }}>
                {board.chapters.map((ch) => {
                  const active = activeQuizId === ch.quizId;
                  return (
                    <Pressable
                      key={ch.quizId}
                      onPress={() => setSelectedQuizId(ch.quizId)}
                      style={[styles.chapterCard, active && styles.chapterActive]}
                    >
                      <View style={styles.chapterLeft}>
                        <Text variant="title" weight={700} c={active ? C.surface : C.ink}>
                          {ch.label}
                        </Text>
                        <Text variant="caption" c={active ? 'rgba(255,255,255,0.8)' : C.secondary}>
                          {ch.subjectName ? `${ch.subjectName} · ` : ''}{ch.count} questions · {ch.quiz.durationMinutes ?? 10} min
                        </Text>
                      </View>
                      <View style={[styles.check, active && { backgroundColor: C.surface }]}>
                        {active ? <Ionicons name="checkmark" size={16} color={C.primary} /> : null}
                      </View>
                    </Pressable>
                  );
                })}
              </View>
            )}
          </Card>

          {/* Question count */}
          {board.countOptions.length > 0 ? (
            <Card flat style={{ gap: 10, padding: 16 }}>
              <Text variant="label" weight={700} c={C.muted}>
                QUESTIONS
              </Text>
              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                {board.countOptions.map((cnt) => {
                  const active = selectedCount === cnt;
                  return (
                    <Pressable
                      key={cnt}
                      onPress={() => setSelectedCount(cnt)}
                      style={[styles.countChip, active && styles.countActive]}
                    >
                      <Text variant="label" weight={700} c={active ? C.surface : C.secondary}>
                        {cnt}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </Card>
          ) : null}

          <Pressable onPress={startPractice} style={styles.startBtn}>
            <Text variant="title" weight={800} c={C.surface}>
              Start Practice
            </Text>
            <Ionicons name="play" size={18} color={C.surface} />
          </Pressable>

          {/* Previous attempts */}
          {board.attempts.length > 0 ? (
            <View style={{ gap: 10 }}>
              <Text variant="title" weight={700} c={C.ink}>
                Previous attempts
              </Text>
              {board.attempts.slice(0, 5).map((att) => (
                <Card key={att.id} flat style={{ padding: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <View>
                    <Text variant="body" weight={600} c={C.ink}>
                      Attempt {att.attemptNo} · {att.score ?? 0}/{att.maxScore ?? 0}
                    </Text>
                    <Text variant="caption" c={C.secondary}>
                      {new Date(att.startedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                    </Text>
                  </View>
                  <Text variant="label" weight={700} c={att.score !== null && att.maxScore ? (att.score / att.maxScore >= 0.7 ? C.teal : C.warning) : C.secondary}>
                    {att.maxScore ? Math.round(((att.score ?? 0) / att.maxScore) * 100) : 0}%
                  </Text>
                </Card>
              ))}
            </View>
          ) : null}
        </ScrollView>
      </SafeAreaView>
    );
  }

  // Question Screen
  if (screen === 'question') {
    if (test.loading) {
      return (
        <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}>
          <Text c={C.secondary}>Loading questions...</Text>
        </SafeAreaView>
      );
    }
    if (test.error || !test.currentQuestion) {
      return (
        <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}>
          <Text c={C.danger}>{test.error ?? 'No questions found'}</Text>
          <Pressable onPress={handleExit} style={{ marginTop: 12 }}>
            <Text c={C.primary} weight={600}>
              Back to picker
            </Text>
          </Pressable>
        </SafeAreaView>
      );
    }

    const q = test.currentQuestion;
    const selected = test.answers[q.id] ?? null;
    const evalResult = test.resultViews[q.id] ?? null; // true/false/null
    const showExpl = test.showExplanation[q.id] ?? false;

    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
        <View style={{ flex: 1, padding: LAYOUT.margin, gap: 16 }}>
          {/* Top bar */}
          <View style={styles.qTop}>
            <Pressable onPress={handleExit} style={styles.backBtn}>
              <Ionicons name="close" size={18} color={C.ink} />
            </Pressable>
            <View style={{ flex: 1, alignItems: 'center' }}>
              <Text variant="label" weight={700} c={C.secondary}>
                {test.progressLabel}
              </Text>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${((test.currentIdx + 1) / test.total) * 100}%` }]} />
              </View>
            </View>
            <View style={{ width: 36 }} />
          </View>

          <ScrollView contentContainerStyle={{ gap: 16, paddingBottom: 120 }} showsVerticalScrollIndicator={false}>
            <Text variant="title" weight={700} c={C.ink} style={{ lineHeight: 24 }}>
              {q.text}
            </Text>

            <View style={{ gap: 10 }}>
              {q.options.map((opt, idx) => {
                const label = String.fromCharCode(65 + idx);
                const isSelected = selected === opt;
                // correct prop: if evalResult not null, then for selected option show correct state, else others null
                let correctProp: boolean | null = null;
                if (evalResult !== null) {
                  if (isSelected) correctProp = evalResult;
                  // Could also highlight correct answer? But we don't have correct answer key, so only show teal/red for selected.
                }
                return (
                  <OptionCard
                    key={label}
                    label={label}
                    text={opt}
                    selected={isSelected}
                    correct={correctProp}
                    disabled={evalResult !== null}
                    onPress={() => test.selectOption(q.id, opt)}
                  />
                );
              })}
            </View>

            {evalResult !== null ? (
              <View style={[styles.resultBox, evalResult ? styles.resultTeal : styles.resultRed]}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Ionicons name={evalResult ? 'checkmark-circle' : 'close-circle'} size={20} color={evalResult ? C.teal : C.danger} />
                  <Text variant="title" weight={700} c={evalResult ? C.teal : C.danger}>
                    {evalResult ? 'Correct' : 'Wrong'}
                  </Text>
                </View>
                {q.explanation ? (
                  <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
                    <Ionicons name="bulb-outline" size={16} color={evalResult ? C.teal : C.danger} />
                    <Text variant="caption" c={C.ink} style={{ flex: 1, lineHeight: 18 }}>
                      {q.explanation}
                    </Text>
                  </View>
                ) : null}
              </View>
            ) : null}
          </ScrollView>

          <View style={styles.qFooter}>
            {evalResult === null ? (
              <Pressable
                onPress={test.submitAnswer}
                disabled={!selected || test.submitting}
                style={[styles.primaryBtn, (!selected || test.submitting) && { opacity: 0.5 }]}
              >
                <Text variant="title" weight={700} c={C.surface}>
                  Submit answer
                </Text>
              </Pressable>
            ) : (
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <Pressable onPress={test.prev} disabled={test.currentIdx === 0} style={[styles.secondaryBtn, test.currentIdx === 0 && { opacity: 0.4 }]}>
                  <Text weight={600} c={C.secondary}>
                    Prev
                  </Text>
                </Pressable>
                {test.currentIdx < test.total - 1 ? (
                  <Pressable onPress={test.next} style={[styles.primaryBtn, { flex: 1 }]}>
                    <Text variant="title" weight={700} c={C.surface}>
                      Next
                    </Text>
                  </Pressable>
                ) : (
                  <Pressable onPress={handleFinish} style={[styles.primaryBtn, { flex: 1, backgroundColor: C.teal }]}>
                    <Text variant="title" weight={700} c={C.surface}>
                      Finish
                    </Text>
                  </Pressable>
                )}
              </View>
            )}
            {evalResult === null ? (
              <Pressable onPress={test.skip} style={styles.skipBtn}>
                <Text variant="label" c={C.muted}>
                  Skip
                </Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // Result Screen
  const rv = test.resultView;
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 120, gap: 18 }}>
        <View style={styles.headerRow}>
          <Pressable onPress={handleExit} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={20} color={C.primary} />
          </Pressable>
          <Text variant="h2" weight={800} c={C.ink}>
            Results
          </Text>
          <View style={{ width: 32 }} />
        </View>

        {rv ? (
          <>
            <View style={{ alignItems: 'center', gap: 12, paddingVertical: 10 }}>
              <ScoreRing percent={rv.percent} />
              <Text variant="title" weight={700} c={C.ink}>
                You scored {rv.score} out of {rv.maxScore}
              </Text>
              <View style={{ flexDirection: 'row', gap: 12, marginTop: 8 }}>
                <View style={styles.statChip}>
                  <Text variant="label" weight={700} c={C.teal}>
                    {rv.correct} Correct
                  </Text>
                </View>
                <View style={[styles.statChip, { backgroundColor: C.dangerSoft }]}>
                  <Text variant="label" weight={700} c={C.danger}>
                    {rv.wrong} Wrong
                  </Text>
                </View>
                <View style={[styles.statChip, { backgroundColor: C.track }]}>
                  <Text variant="label" weight={700} c={C.secondary}>
                    {rv.skipped} Skipped
                  </Text>
                </View>
              </View>
              {rv.timeTakenSec !== null ? (
                <Text variant="caption" c={C.secondary} style={{ marginTop: 6 }}>
                  Time taken: {Math.floor(rv.timeTakenSec / 60)}m {rv.timeTakenSec % 60}s
                </Text>
              ) : null}
            </View>

            <MistakesList mistakes={rv.mistakes} />
          </>
        ) : (
          <Text c={C.secondary}>No result yet</Text>
        )}

        <Pressable onPress={handleExit} style={styles.startBtn}>
          <Text variant="title" weight={800} c={C.surface}>
            Back to Practice
          </Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: C.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: C.hairline,
  },
  chapterCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.hairline,
    borderRadius: 14,
    padding: 14,
    gap: 10,
  },
  chapterActive: {
    backgroundColor: C.primary,
    borderColor: C.primary,
  },
  chapterLeft: {
    flex: 1,
    gap: 4,
  },
  check: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: C.track,
    alignItems: 'center',
    justifyContent: 'center',
  },
  countChip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.hairline,
  },
  countActive: {
    backgroundColor: C.primary,
    borderColor: C.primary,
  },
  startBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: C.primary,
    paddingVertical: 16,
    borderRadius: 16,
  },
  qTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  progressTrack: {
    height: 6,
    backgroundColor: C.track,
    borderRadius: 3,
    marginTop: 6,
    width: 120,
    overflow: 'hidden',
  },
  progressFill: {
    height: 6,
    backgroundColor: C.primary,
    borderRadius: 3,
  },
  resultBox: {
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
  },
  resultTeal: {
    backgroundColor: C.tealSoft,
    borderColor: '#A7E0D9',
  },
  resultRed: {
    backgroundColor: C.dangerSoft,
    borderColor: '#F9C0C0',
  },
  qFooter: {
    position: 'absolute',
    left: LAYOUT.margin,
    right: LAYOUT.margin,
    bottom: LAYOUT.margin,
    gap: 10,
  },
  primaryBtn: {
    backgroundColor: C.primary,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryBtn: {
    flex: 1,
    backgroundColor: C.surface,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: C.hairline,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  skipBtn: {
    alignSelf: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  statChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: C.tealSoft,
  },
});
