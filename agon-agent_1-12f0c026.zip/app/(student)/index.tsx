import React from 'react';

import { StudentHomeScreen } from '@/features/student/screens/StudentHomeScreen';

export default function StudentHomeRoute() {
  return <StudentHomeScreen />;
}
