import React from 'react';

import { TeacherDoubtsScreen } from '@/features/teacher/doubts';

export default function TeacherDoubtsRoute() {
  return <TeacherDoubtsScreen />;
}
