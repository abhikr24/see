import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { TeacherExamsScreen } from '@/features/teacher/exams';
import { TeacherMarksScreen } from '@/features/teacher/marks';

export default function TeacherExamsRoute() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  if (typeof id === 'string' && id.length > 0) return <TeacherMarksScreen />;
  return <TeacherExamsScreen />;
}
