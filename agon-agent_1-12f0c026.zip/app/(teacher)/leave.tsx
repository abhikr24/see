import React from 'react';

import { TeacherLeaveScreen } from '@/features/teacher/leave';

export default function TeacherLeaveRoute() {
  return <TeacherLeaveScreen />;
}
