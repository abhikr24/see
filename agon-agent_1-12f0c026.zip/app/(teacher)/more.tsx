import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Card, Screen, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';

const ITEMS = [
  { key: 'doubts', title: 'Student doubts', detail: 'Open questions, replies and waiting time', icon: 'chatbubbles-outline' as const, route: '/(teacher)/doubts' },
  { key: 'leave', title: 'Leave requests', detail: 'Request time away and track approvals', icon: 'calendar-outline' as const, route: '/(teacher)/leave' },
];

export default function TeacherMoreRoute() {
  return (
    <Screen title="More" subtitle="Teaching tools and requests" safeTop={false} tabBarInset={96}>
      <View style={{ gap: 12 }}>
        {ITEMS.map((item) => (
          <Pressable key={item.key} onPress={() => router.push(item.route as never)}>
            <Card pad={16}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <View style={{ width: 46, height: 46, borderRadius: R.field, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={item.icon} size={22} color={C.primary} />
                </View>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text variant="title" weight={700}>{item.title}</Text>
                  <Text variant="caption" c={C.secondary}>{item.detail}</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={C.muted} />
              </View>
            </Card>
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}
