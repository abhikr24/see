import type { Assignment, Feedback, ID, NewEntity, Patch, Submission } from '../../core/contracts/models';
import type { AssignmentRepo, GradeInput, SubmissionRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { assignHomeworkLive, homeworkTrackerLive, remindPendingLive } from './homework.repo';
import {
  approveLive,
  askAgainLive,
  saveGradesLive,
  studentHomeworkLive,
  submissionsForAssignmentLive,
} from './homework-submissions.repo';
import { mapAssignment, mapFeedback, mapSubmission } from './mappers';

export function assignmentRepo(): AssignmentRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Assignment>): Promise<Page<Assignment>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('assignments').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapAssignment), count, offset, limit);
      } catch {
        return memoryFallback.assignments.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Assignment> {
      try {
        const { data, error } = await supabase.from('assignments').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapAssignment(data);
      } catch {
        return memoryFallback.assignments.get(instituteId, id);
      }
    },
    async create(instituteId: ID, input: NewEntity<Assignment, 'batchId' | 'title'>): Promise<Assignment> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('assignments').insert({
          institute_id: instituteId, batch_id: input.batchId, title: input.title,
          subject_id: input.subjectId ?? null, teacher_id: input.teacherId ?? null,
          instructions: input.instructions ?? null, assigned_on: input.assignedOn ?? new Date().toISOString().slice(0, 10),
          due_at: input.dueAt ?? null, max_marks: input.maxMarks ?? null,
          submission_type: input.submissionType ?? 'written', status: input.status ?? 'draft', created_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapAssignment(data);
      } catch {
        return memoryFallback.assignments.create(instituteId, input);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Assignment>): Promise<Assignment> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.title !== undefined) row.title = patch.title;
        if (patch.instructions !== undefined) row.instructions = patch.instructions;
        if (patch.dueAt !== undefined) row.due_at = patch.dueAt;
        if (patch.maxMarks !== undefined) row.max_marks = patch.maxMarks;
        if (patch.submissionType !== undefined) row.submission_type = patch.submissionType;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('assignments').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapAssignment(data);
      } catch {
        return memoryFallback.assignments.update(instituteId, id, patch);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('assignments').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.assignments.remove(instituteId, id);
      }
    },
    async publish(instituteId: ID, id: ID): Promise<Assignment> {
      return this.update(instituteId, id, { status: 'published' });
    },
    async close(instituteId: ID, id: ID): Promise<Assignment> {
      return this.update(instituteId, id, { status: 'closed' });
    },
    assign: assignHomeworkLive,
    tracker: (instituteId, filter) => homeworkTrackerLive(instituteId, filter?.batchId),
    remindPending: remindPendingLive,
    forStudent: studentHomeworkLive,
  };
}

export function submissionRepo(): SubmissionRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Submission>): Promise<Page<Submission>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('submissions').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1);
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapSubmission), count, offset, limit);
      } catch {
        return memoryFallback.submissions.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Submission> {
      try {
        const { data, error } = await supabase.from('submissions').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapSubmission(data);
      } catch {
        return memoryFallback.submissions.get(instituteId, id);
      }
    },
    async submit(instituteId: ID, input: { assignmentId: ID; studentId: ID; content?: string | null }): Promise<Submission> {
      try {
        const { data: asg, error: aErr } = await supabase
          .from('assignments')
          .select('batch_id, due_at, status')
          .eq('institute_id', instituteId)
          .eq('id', input.assignmentId)
          .single();
        if (aErr || !asg) throw aErr ?? new Error('Assignment not found');
        const submittedAt = new Date().toISOString();
        const status = asg.due_at && submittedAt > String(asg.due_at) ? 'late' : 'submitted';
        const { data, error } = await supabase.from('submissions').upsert({
          institute_id: instituteId, assignment_id: input.assignmentId, batch_id: String(asg.batch_id), student_id: input.studentId,
          content: input.content ?? null, submitted_at: submittedAt, status,
        }, { onConflict: 'assignment_id,student_id' }).select().single();
        if (error) throw error;
        return mapSubmission(data);
      } catch {
        return memoryFallback.submissions.submit(instituteId, input);
      }
    },
    async grade(instituteId: ID, submissionId: ID, input: GradeInput): Promise<Feedback> {
      try {
        const { data: sub } = await supabase.from('submissions').select('*').eq('id', submissionId).single();
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('feedback').insert({
          institute_id: instituteId, submission_id: submissionId, batch_id: sub.batch_id, student_id: sub.student_id,
          marks_awarded: input.marksAwarded ?? null, grade: input.grade ?? null, comment: input.comment ?? null, given_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapFeedback(data);
      } catch {
        return memoryFallback.submissions.grade(instituteId, submissionId, input);
      }
    },
    async getFeedback(instituteId: ID, submissionId: ID): Promise<Feedback | null> {
      try {
        const { data, error } = await supabase.from('feedback').select('*').eq('institute_id', instituteId).eq('submission_id', submissionId).maybeSingle();
        if (error) throw error;
        return data ? mapFeedback(data) : null;
      } catch {
        return memoryFallback.submissions.getFeedback(instituteId, submissionId);
      }
    },
    forAssignment: submissionsForAssignmentLive,
    saveGrades: saveGradesLive,
    approve: approveLive,
    askAgain: askAgainLive,
  };
}
