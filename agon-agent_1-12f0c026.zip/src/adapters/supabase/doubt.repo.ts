import type { Conversation, Doubt, DoubtStatus, ID, MeetingRequest, NewEntity } from '../../core/contracts/models';
import type { DoubtRepo, MeetingRepo, MeetingResponse } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapConversation, mapDoubt, mapMeetingRequest } from './mappers';
import { assertOwnBatch, ownBatchIds, teacherScope } from './teacher-scope';

export function doubtRepo(): DoubtRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Doubt>): Promise<Page<Doubt>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('doubts').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const scope = await teacherScope(instituteId);
        if (scope) {
          const batchIds = await ownBatchIds(instituteId, scope);
          if (batchIds.length === 0) return toPaginatedResult<Doubt>([], 0, offset, limit);
          q = q.in('batch_id', batchIds);
        }
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapDoubt), count, offset, limit);
      } catch {
        return memoryFallback.doubts.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Doubt> {
      try {
        const { data, error } = await supabase.from('doubts').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        const scope = await teacherScope(instituteId);
        if (scope) await assertOwnBatch(instituteId, String(data.batch_id));
        return mapDoubt(data);
      } catch {
        return memoryFallback.doubts.get(instituteId, id);
      }
    },
    async ask(instituteId: ID, input: NewEntity<Doubt, 'batchId' | 'studentId' | 'question'>): Promise<Doubt> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('doubts').insert({
          institute_id: instituteId, batch_id: input.batchId, student_id: input.studentId,
          question: input.question, subject_id: input.subjectId ?? null,
          teacher_id: input.teacherId ?? null, topic: input.topic ?? null,
          status: 'open', asked_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapDoubt(data);
      } catch {
        return memoryFallback.doubts.ask(instituteId, input);
      }
    },
    async answer(instituteId: ID, id: ID, answer: string): Promise<Doubt> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data: existing, error: readError } = await supabase
          .from('doubts')
          .select('batch_id, student_id')
          .eq('institute_id', instituteId)
          .eq('id', id)
          .single();
        if (readError) throw readError;
        const scope = await teacherScope(instituteId);
        if (scope) await assertOwnBatch(instituteId, String(existing.batch_id));
        const { data, error } = await supabase.from('doubts').update({
          answer, answered_by: user?.user?.id ?? null, answered_at: new Date().toISOString(), status: 'answered',
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        const { data: links } = await supabase
          .from('student_memberships')
          .select('membership_id')
          .eq('institute_id', instituteId)
          .eq('student_id', existing.student_id);
        const membershipIds = (links ?? []).map((link) => link.membership_id);
        if (membershipIds.length > 0) {
          const { data: memberships } = await supabase
            .from('memberships')
            .select('user_id')
            .eq('institute_id', instituteId)
            .eq('status', 'active')
            .in('id', membershipIds);
          const rows = (memberships ?? []).map((membership) => ({
            institute_id: instituteId,
            user_id: membership.user_id,
            type: 'doubt_answered',
            title: 'Your question was answered',
            body: answer.slice(0, 120),
            data: { screen: 'doubts', doubtId: id },
            channel: 'in_app',
          }));
          if (rows.length > 0) {
            const { error: notificationError } = await supabase.from('notifications').insert(rows);
            if (notificationError) throw notificationError;
          }
        }
        return mapDoubt(data);
      } catch {
        return memoryFallback.doubts.answer(instituteId, id, answer);
      }
    },
    async setStatus(instituteId: ID, id: ID, status: DoubtStatus): Promise<Doubt> {
      try {
        const { data: existing, error: readError } = await supabase
          .from('doubts')
          .select('batch_id')
          .eq('institute_id', instituteId)
          .eq('id', id)
          .single();
        if (readError) throw readError;
        const scope = await teacherScope(instituteId);
        if (scope) await assertOwnBatch(instituteId, String(existing.batch_id));
        const { data, error } = await supabase.from('doubts').update({ status }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapDoubt(data);
      } catch {
        return memoryFallback.doubts.setStatus(instituteId, id, status);
      }
    },
  };
}

export function meetingRepo(): MeetingRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<MeetingRequest>): Promise<Page<MeetingRequest>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('meeting_requests').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1);
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapMeetingRequest), count, offset, limit);
      } catch {
        return memoryFallback.meetings.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<MeetingRequest> {
      try {
        const { data, error } = await supabase.from('meeting_requests').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapMeetingRequest(data);
      } catch {
        return memoryFallback.meetings.get(instituteId, id);
      }
    },
    async request(instituteId: ID, input: NewEntity<MeetingRequest, 'studentId' | 'teacherId'>): Promise<MeetingRequest> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('meeting_requests').insert({
          institute_id: instituteId, student_id: input.studentId, teacher_id: input.teacherId,
          guardian_id: input.guardianId ?? null, reason: input.reason ?? null, preferred_at: input.preferredAt ?? null,
          mode: input.mode ?? 'in_person', status: 'pending', requested_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapMeetingRequest(data);
      } catch {
        return memoryFallback.meetings.request(instituteId, input);
      }
    },
    async respond(instituteId: ID, id: ID, response: MeetingResponse): Promise<MeetingRequest> {
      try {
        const { data, error } = await supabase.from('meeting_requests').update({
          status: response.status, scheduled_at: response.scheduledAt ?? null, response_note: response.note ?? null, responded_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapMeetingRequest(data);
      } catch {
        return memoryFallback.meetings.respond(instituteId, id, response);
      }
    },
    async listConversations(instituteId: ID, query?: ListQuery<Conversation>): Promise<Page<Conversation>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('conversations').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1);
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapConversation), count, offset, limit);
      } catch {
        return memoryFallback.meetings.listConversations(instituteId, query);
      }
    },
    async startConversation(instituteId: ID, input: NewEntity<Conversation, 'participantIds'>): Promise<Conversation> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('conversations').insert({
          institute_id: instituteId, participant_ids: input.participantIds, kind: input.kind ?? 'direct',
          title: input.title ?? null, student_id: input.studentId ?? null, messages: [], created_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapConversation(data);
      } catch {
        return memoryFallback.meetings.startConversation(instituteId, input);
      }
    },
    async sendMessage(instituteId: ID, conversationId: ID, body: string): Promise<Conversation> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const msg = { id: `msg_${Date.now()}`, senderId: user?.user?.id ?? '00000000-0000-4000-8000-000000000002', body, sentAt: new Date().toISOString() };
        const conv = await supabase.from('conversations').select('messages').eq('id', conversationId).single();
        const messages = [...(conv.data?.messages ?? []), msg];
        const { data, error } = await supabase.from('conversations').update({
          messages, last_message_preview: body.slice(0, 100), last_message_at: msg.sentAt,
        }).eq('institute_id', instituteId).eq('id', conversationId).select().single();
        if (error) throw error;
        return mapConversation(data);
      } catch {
        return memoryFallback.meetings.sendMessage(instituteId, conversationId, body);
      }
    },
  };
}
