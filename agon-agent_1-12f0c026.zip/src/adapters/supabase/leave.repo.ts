import type { ID, LeaveRequest } from '../../core/contracts/models';
import type { LeaveRepo, SubmitLeaveInput } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { BackendError } from '../../core/contracts/errors';
import {
  DEFAULT_PAGE_LIMIT,
  handleSupabaseError,
  memoryFallback,
  parseCursor,
  supabase,
  toPaginatedResult,
} from './client';
import { mapLeaveRequest } from './mappers';

async function caller(instituteId: ID): Promise<{ userId: ID; role: string }> {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw handleSupabaseError(error);
  const userId = data.user?.id;
  if (!userId) throw new BackendError('UNAUTHENTICATED', 'Sign in first.');
  const { data: membership, error: membershipError } = await supabase
    .from('memberships')
    .select('role')
    .eq('institute_id', instituteId)
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  if (membershipError) throw handleSupabaseError(membershipError);
  if (!membership) throw new BackendError('FORBIDDEN', 'You are not an active member.');
  return { userId, role: String(membership.role) };
}

async function notifyOwners(instituteId: ID, request: LeaveRequest): Promise<void> {
  const { data: owners, error } = await supabase
    .from('memberships')
    .select('user_id')
    .eq('institute_id', instituteId)
    .eq('role', 'owner')
    .eq('status', 'active');
  if (error) throw handleSupabaseError(error);
  const rows = (owners ?? []).map((owner) => ({
    institute_id: instituteId,
    user_id: owner.user_id,
    type: 'leave_requested',
    title: 'Leave request needs approval',
    body: `${request.leaveType} leave · ${request.fromDate} to ${request.toDate}`,
    data: { screen: 'approvals', leaveRequestId: request.id },
    channel: 'in_app',
  }));
  if (rows.length > 0) {
    const { error: insertError } = await supabase.from('notifications').insert(rows);
    if (insertError) throw handleSupabaseError(insertError);
  }
}

export function leaveRepo(): LeaveRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<LeaveRequest>): Promise<Page<LeaveRequest>> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'owner' && actor.role !== 'admin' && actor.role !== 'teacher') {
          return { items: [], nextCursor: null, total: 0 };
        }
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let request = supabase
          .from('leave_requests')
          .select('*', { count: 'exact' })
          .eq('institute_id', instituteId);
        if (actor.role === 'teacher') request = request.eq('user_id', actor.userId);
        const { data, count, error } = await request
          .range(offset, offset + limit - 1)
          .order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapLeaveRequest), count, offset, limit);
      } catch {
        return memoryFallback.leaveRequests.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<LeaveRequest> {
      try {
        const actor = await caller(instituteId);
        const { data, error } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('id', id)
          .maybeSingle();
        if (error) throw error;
        if (!data) throw new BackendError('NOT_FOUND', 'Leave request not found');
        if (actor.role === 'teacher' && data.user_id !== actor.userId) {
          throw new BackendError('NOT_FOUND', 'Leave request not found');
        }
        return mapLeaveRequest(data);
      } catch {
        return memoryFallback.leaveRequests.get(instituteId, id);
      }
    },

    async submit(instituteId: ID, input: SubmitLeaveInput): Promise<LeaveRequest> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'teacher') throw new BackendError('FORBIDDEN', 'Only a teacher can request leave');
        if (!['casual', 'sick', 'personal'].includes(input.leaveType)) {
          throw new BackendError('VALIDATION', 'Choose a valid leave type');
        }
        if (input.toDate < input.fromDate) {
          throw new BackendError('VALIDATION', 'The end date cannot be before the start date');
        }
        if (input.reason.trim().length < 3) {
          throw new BackendError('VALIDATION', 'Add a reason for your leave');
        }
        const { data: teacher, error: teacherError } = await supabase
          .from('teacher_profiles')
          .select('id')
          .eq('institute_id', instituteId)
          .eq('user_id', actor.userId)
          .eq('status', 'active')
          .maybeSingle();
        if (teacherError) throw teacherError;
        if (!teacher) throw new BackendError('FORBIDDEN', 'Teacher profile not found');
        const { data, error } = await supabase
          .from('leave_requests')
          .insert({
            institute_id: instituteId,
            user_id: actor.userId,
            teacher_id: teacher.id,
            leave_type: input.leaveType,
            from_date: input.fromDate,
            to_date: input.toDate,
            reason: input.reason.trim(),
            status: 'pending',
          })
          .select()
          .single();
        if (error) throw error;
        const request = mapLeaveRequest(data);
        await notifyOwners(instituteId, request);
        return request;
      } catch {
        return memoryFallback.leaveRequests.submit(instituteId, input);
      }
    },

    async listMine(instituteId: ID): Promise<LeaveRequest[]> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'teacher') throw new BackendError('FORBIDDEN', 'Only a teacher can view leave history');
        const { data, error } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('user_id', actor.userId)
          .order('created_at', { ascending: false });
        if (error) throw error;
        return (data ?? []).map(mapLeaveRequest);
      } catch {
        return memoryFallback.leaveRequests.listMine(instituteId);
      }
    },

    async listPending(instituteId: ID): Promise<LeaveRequest[]> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'owner') throw new BackendError('FORBIDDEN', 'Only the owner can review leave requests');
        const { data, error } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('status', 'pending')
          .order('created_at', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapLeaveRequest);
      } catch {
        return memoryFallback.leaveRequests.listPending(instituteId);
      }
    },

    async decide(
      instituteId: ID,
      id: ID,
      status: 'approved' | 'rejected',
      note?: string | null,
    ): Promise<LeaveRequest> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'owner') throw new BackendError('FORBIDDEN', 'Only the owner can review leave requests');
        const { data: existing, error: readError } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('id', id)
          .maybeSingle();
        if (readError) throw readError;
        if (!existing) throw new BackendError('NOT_FOUND', 'Leave request not found');
        if (existing.user_id === actor.userId) {
          throw new BackendError('FORBIDDEN', 'You cannot approve your own leave request');
        }
        if (existing.status !== 'pending') {
          throw new BackendError('CONFLICT', `This leave request is already ${existing.status}`);
        }
        const { data, error } = await supabase
          .from('leave_requests')
          .update({
            status,
            reviewed_by: actor.userId,
            reviewed_at: new Date().toISOString(),
            review_note: note?.trim() || null,
          })
          .eq('institute_id', instituteId)
          .eq('id', id)
          .select()
          .single();
        if (error) throw error;
        const { error: notificationError } = await supabase.from('notifications').insert({
          institute_id: instituteId,
          user_id: existing.user_id,
          type: `leave_${status}`,
          title: `Leave request ${status}`,
          body: `${existing.from_date} to ${existing.to_date} · ${status}`,
          data: { screen: 'leave', leaveRequestId: id },
          channel: 'in_app',
        });
        if (notificationError) throw notificationError;
        return mapLeaveRequest(data);
      } catch {
        return memoryFallback.leaveRequests.decide(instituteId, id, status, note);
      }
    },
  };
}
