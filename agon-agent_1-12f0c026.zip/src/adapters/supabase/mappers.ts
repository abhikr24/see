import type {
  AdmissionLead, AppNotification, Assignment, Attachment, AttendanceRecord,
  AttendanceSession, AuditLog, BankDetails, Batch, Bookmark, Branch,
  Classroom, Conversation, ConversationMessage, Doubt, Enrollment, Exam,
  ExamQuestion, FeeComponent, FeeStructure, Feedback, Guardian, Institute,
  InstituteSettings, Invitation, JsonObject, LeadFollowup, LeaveRequest, Mark, Material, MeetingRequest,
  Membership, Notice, Payment, PaymentOrder, Plan, PlanDiscount, PlanInstallment, PracticeQuestion, Profile,
  Quiz, QuizAttempt, Receipt, Refund, Result, StaffRecord, Student,
  StudentFee, StudentGoal, StudyTask, Subject, Submission, Subscription, Teacher,
  Timetable, UsageRecord, Workload,
} from '../../core/contracts/models';

export const num = (v: unknown): number => (typeof v === 'number' ? v : Number(v) || 0);
export const numOrNull = (v: unknown): number | null => (v === null || v === undefined ? null : Number(v));
export const str = (v: unknown): string => String(v ?? '');
export const strOrNull = (v: unknown): string | null => (v === null || v === undefined ? null : String(v));
export const arr = <T>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);

export function toCamel<T>(row: Record<string, unknown>): T {
  const result: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) {
    result[k.replace(/_([a-z0-9])/g, (_, letter) => letter.toUpperCase())] = v;
  }
  return result as T;
}

export function mapInstituteSettings(row?: Record<string, unknown> | null): InstituteSettings {
  const r = row ?? {};
  return {
    academicYear: strOrNull(r.academic_year ?? r.academicYear ?? '2026-27'),
    timezone: str(r.timezone ?? 'Asia/Kolkata'),
    currency: str(r.currency ?? 'INR'),
    locale: str(r.locale ?? 'en-IN'),
    workingDays: arr<number>(r.working_days ?? r.workingDays ?? [1, 2, 3, 4, 5, 6]),
    attendanceMode: (r.attendance_mode ?? r.attendanceMode ?? 'daily') as 'daily' | 'period',
    minAttendancePercent: num(r.min_attendance_percent ?? r.minAttendancePercent ?? 75),
    passPercent: num(r.pass_percent ?? r.passPercent ?? 33),
    lateFeePerDay: num(r.late_fee_per_day ?? r.lateFeePerDay ?? 0),
    receiptPrefix: strOrNull(r.receipt_prefix ?? r.receiptPrefix ?? 'SCC'),
    allowJoinRequests: Boolean(r.allow_join_requests ?? r.allowJoinRequests ?? true),
    features: (r.features as Record<string, boolean>) ?? {},
  };
}

export function mapInstitute(row: Record<string, unknown>, sRow?: Record<string, unknown> | null): Institute {
  return {
    ...toCamel<Institute>(row),
    tagline: strOrNull(row.tagline), phone: strOrNull(row.phone), email: strOrNull(row.email),
    address: strOrNull(row.address), city: strOrNull(row.city), state: strOrNull(row.state),
    pincode: strOrNull(row.pincode), country: str(row.country ?? 'IN'), logoUrl: strOrNull(row.logo_url ?? row.logoUrl),
    status: (row.status ?? 'active') as Institute['status'],
    settings: mapInstituteSettings((sRow ?? row.settings) as Record<string, unknown>),
  };
}

export const mapBranch = (r: Record<string, unknown>): Branch => toCamel<Branch>(r);
export const mapMembership = (r: Record<string, unknown>): Membership => ({
  ...toCamel<Membership>(r), permissions: arr(r.permissions),
  requestedAt: str(r.requested_at ?? r.requestedAt ?? r.created_at ?? r.createdAt),
});
export const mapProfile = (r: Record<string, unknown>): Profile => ({
  ...toCamel<Profile>(r), userId: str(r.user_id ?? r.userId ?? r.id), fullName: str(r.full_name ?? r.fullName),
});
export const mapInvitation = (r: Record<string, unknown>): Invitation => toCamel<Invitation>(r);
export const mapStudent = (r: Record<string, unknown>): Student => ({
  ...toCamel<Student>(r), admittedOn: str(r.admitted_on ?? r.admittedOn ?? new Date().toISOString().slice(0, 10)),
});
export const mapGuardian = (r: Record<string, unknown>): Guardian => toCamel<Guardian>(r);
export const mapTeacher = (r: Record<string, unknown>): Teacher => ({
  ...toCamel<Teacher>(r), experienceYears: numOrNull(r.experience_years ?? r.experienceYears),
});
export const mapStaffRecord = (r: Record<string, unknown>): StaffRecord => ({
  ...toCamel<StaffRecord>(r), salaryAmount: numOrNull(r.salary_amount ?? r.salaryAmount),
  bankDetails: (r.bank_details ?? r.bankDetails) ? ((r.bank_details ?? r.bankDetails) as BankDetails) : null,
});
export const mapWorkload = (r: Record<string, unknown>): Workload => ({
  ...toCamel<Workload>(r), periodsAssigned: num(r.periods_assigned ?? r.periodsAssigned),
  periodsTaken: num(r.periods_taken ?? r.periodsTaken), hoursAssigned: num(r.hours_assigned ?? r.hoursAssigned),
  hoursTaken: num(r.hours_taken ?? r.hoursTaken),
});
export const mapLeaveRequest = (r: Record<string, unknown>): LeaveRequest => ({
  ...toCamel<LeaveRequest>(r),
  leaveType: (r.leave_type ?? r.leaveType) as LeaveRequest['leaveType'],
  fromDate: str(r.from_date ?? r.fromDate),
  toDate: str(r.to_date ?? r.toDate),
  reviewedBy: strOrNull(r.reviewed_by ?? r.reviewedBy),
  reviewedAt: strOrNull(r.reviewed_at ?? r.reviewedAt),
  reviewNote: strOrNull(r.review_note ?? r.reviewNote),
});
export const mapClassroom = (r: Record<string, unknown>): Classroom => ({
  ...toCamel<Classroom>(r), capacity: numOrNull(r.capacity), facilities: arr(r.facilities),
});
export const mapSubject = (r: Record<string, unknown>): Subject => ({
  ...toCamel<Subject>(r), isActive: Boolean(r.is_active ?? r.isActive ?? true),
});
export const mapBatch = (r: Record<string, unknown>): Batch => ({
  ...toCamel<Batch>(r), capacity: numOrNull(r.capacity),
});
export const mapEnrollment = (r: Record<string, unknown>): Enrollment => ({
  ...toCamel<Enrollment>(r), rollNumber: numOrNull(r.roll_number ?? r.rollNumber),
});
export const mapTimetable = (r: Record<string, unknown>): Timetable => ({
  ...toCamel<Timetable>(r), dayOfWeek: num(r.day_of_week ?? r.dayOfWeek),
});
export const mapAttendanceSession = (r: Record<string, unknown>): AttendanceSession => ({
  ...toCamel<AttendanceSession>(r), date: str(r.session_date ?? r.date), period: num(r.period ?? 1),
});
export const mapAttendanceRecord = (r: Record<string, unknown>): AttendanceRecord => toCamel<AttendanceRecord>(r);
export const mapAssignment = (r: Record<string, unknown>): Assignment => ({
  ...toCamel<Assignment>(r), maxMarks: numOrNull(r.max_marks ?? r.maxMarks),
  assignedOn: str(r.assigned_on ?? r.assignedOn ?? new Date().toISOString().slice(0, 10)),
});
export const mapSubmission = (r: Record<string, unknown>): Submission => toCamel<Submission>(r);
export const mapAttachment = (r: Record<string, unknown>): Attachment => ({
  ...toCamel<Attachment>(r), ownerType: (r.entity_type ?? r.ownerType) as Attachment['ownerType'],
  ownerId: str(r.entity_id ?? r.ownerId), sizeBytes: numOrNull(r.size_bytes ?? r.sizeBytes),
});
export const mapFeedback = (r: Record<string, unknown>): Feedback => ({
  ...toCamel<Feedback>(r), marksAwarded: numOrNull(r.marks_awarded ?? r.marksAwarded),
  givenAt: str(r.given_at ?? r.givenAt ?? r.created_at ?? r.createdAt),
});
export const mapExam = (r: Record<string, unknown>): Exam => ({
  ...toCamel<Exam>(r), subjectId: strOrNull(r.subject_id ?? r.subjectId), totalMarks: numOrNull(r.total_marks ?? r.totalMarks), passPercent: num(r.pass_percent ?? r.passPercent ?? 33),
});
export const mapExamQuestion = (r: Record<string, unknown>): ExamQuestion => ({
  ...toCamel<ExamQuestion>(r), text: str(r.question_text ?? r.text), maxMarks: num(r.max_marks ?? r.maxMarks ?? 1), options: (r.options as string[]) ?? null,
});
export const mapMark = (r: Record<string, unknown>): Mark => ({
  ...toCamel<Mark>(r), marksObtained: numOrNull(r.marks_obtained ?? r.marksObtained), maxMarks: num(r.max_marks ?? r.maxMarks ?? 100), isAbsent: Boolean(r.is_absent ?? r.isAbsent),
});
export const mapResult = (r: Record<string, unknown>): Result => ({
  ...toCamel<Result>(r), totalObtained: num(r.total_obtained ?? r.totalObtained), totalMax: num(r.total_max ?? r.totalMax), percentage: num(r.percentage), rank: numOrNull(r.rank), status: (r.result_status ?? r.status ?? 'pass') as Result['status'],
});
export const mapMaterial = (r: Record<string, unknown>): Material => ({
  ...toCamel<Material>(r), isPublished: Boolean(r.is_published ?? r.isPublished ?? true),
});
export const mapBookmark = (r: Record<string, unknown>): Bookmark => toCamel<Bookmark>(r);
export const mapPracticeQuestion = (r: Record<string, unknown>): PracticeQuestion => ({
  ...toCamel<PracticeQuestion>(r), text: str(r.question_text ?? r.text), marks: num(r.marks ?? 1), isPublished: Boolean(r.is_published ?? r.isPublished ?? true),
});
export const mapQuiz = (r: Record<string, unknown>): Quiz => ({
  ...toCamel<Quiz>(r), questionIds: arr(r.question_ids ?? r.questionIds), durationMinutes: numOrNull(r.duration_minutes ?? r.durationMinutes), totalMarks: numOrNull(r.total_marks ?? r.totalMarks),
});
export const mapQuizAttempt = (r: Record<string, unknown>): QuizAttempt => ({
  ...toCamel<QuizAttempt>(r), attemptNo: num(r.attempt_no ?? r.attemptNo ?? 1), answers: (r.answers as Record<string, string>) ?? {}, score: numOrNull(r.score), maxScore: numOrNull(r.max_score ?? r.maxScore),
});
export const mapStudyTask = (r: Record<string, unknown>): StudyTask => toCamel<StudyTask>(r);
export const mapStudentGoal = (r: Record<string, unknown>): StudentGoal => ({
  ...toCamel<StudentGoal>(r), targetValue: numOrNull(r.target_value ?? r.targetValue), currentValue: numOrNull(r.current_value ?? r.currentValue), startsOn: str(r.starts_on ?? r.startsOn ?? new Date().toISOString().slice(0, 10)),
});
export const mapFeeStructure = (r: Record<string, unknown>): FeeStructure => ({
  ...toCamel<FeeStructure>(r),
  version: num(r.version ?? 1),
  supersededById: strOrNull(r.superseded_by ?? r.supersededById),
  batchIds: arr<string>(r.batch_ids ?? r.batchIds),
  schedule: arr<PlanInstallment>(r.schedule).map((x) => ({ ...x, amount: num(x.amount) })),
  discounts: arr<PlanDiscount>(r.discounts).map((x) => ({ ...x, amount: num(x.amount), note: str(x.note) })),
  totalAmount: num(r.total_amount ?? r.totalAmount), installmentCount: num(r.installment_count ?? r.installmentCount ?? 1), components: (r.components as FeeComponent[]) ?? [], lateFeePerDay: num(r.late_fee_per_day ?? r.lateFeePerDay ?? 0), isActive: Boolean(r.is_active ?? r.isActive ?? true),
});
export const mapStudentFee = (r: Record<string, unknown>): StudentFee => {
  const g = num(r.gross_amount ?? r.grossAmount), d = num(r.discount_amount ?? r.discountAmount ?? 0);
  return { ...toCamel<StudentFee>(r), discountIds: arr<string>(r.discount_ids ?? r.discountIds), grossAmount: g, discountAmount: d, netAmount: num(r.net_amount ?? r.netAmount ?? g - d) };
};
export const mapInstallment = (r: Record<string, unknown>): any => ({
  ...toCamel<any>(r), termNo: num(r.term_no ?? r.termNo), amount: num(r.amount), paidAmount: num(r.paid_amount ?? r.paidAmount ?? 0),
});
export const mapPayment = (r: Record<string, unknown>): Payment => ({
  ...toCamel<Payment>(r), amount: num(r.amount), paidAt: str(r.paid_at ?? r.paidAt ?? r.created_at ?? r.createdAt),
});
export const mapReceipt = (r: Record<string, unknown>): Receipt => ({
  ...toCamel<Receipt>(r), amount: num(r.amount), issuedAt: str(r.issued_at ?? r.issuedAt ?? r.created_at ?? r.createdAt),
});
export const mapRefund = (r: Record<string, unknown>): Refund => ({
  ...toCamel<Refund>(r), amount: num(r.amount),
});
export const mapNotice = (r: Record<string, unknown>): Notice => ({
  ...toCamel<Notice>(r), audience: arr(r.audience), isPinned: Boolean(r.is_pinned ?? r.isPinned),
});
export const mapNotification = (r: Record<string, unknown>): AppNotification => ({
  ...toCamel<AppNotification>(r), data: (r.data as JsonObject) ?? {},
});
export const mapConversation = (r: Record<string, unknown>): Conversation => ({
  ...toCamel<Conversation>(r), participantIds: arr(r.participant_ids ?? r.participantIds), messages: (r.messages as ConversationMessage[]) ?? [], isArchived: Boolean(r.is_archived ?? r.isArchived),
});
export const mapDoubt = (r: Record<string, unknown>): Doubt => toCamel<Doubt>(r);
export const mapMeetingRequest = (r: Record<string, unknown>): MeetingRequest => ({
  ...toCamel<MeetingRequest>(r), durationMinutes: numOrNull(r.duration_minutes ?? r.durationMinutes),
});
export const mapLead = (r: Record<string, unknown>): AdmissionLead => ({
  ...toCamel<AdmissionLead>(r),
  subjectInterest: strOrNull(r.subject_interest ?? r.subjectInterest),
  nextFollowupNote: strOrNull(r.next_followup_note ?? r.nextFollowupNote),
  expectedFee: numOrNull(r.expected_fee ?? r.expectedFee),
});
export const mapLeadFollowup = (r: Record<string, unknown>): LeadFollowup => ({
  ...toCamel<LeadFollowup>(r), followupAt: str(r.followup_at ?? r.followupAt ?? r.created_at ?? r.createdAt),
});
export const mapPlan = (r: Record<string, unknown>): Plan => ({
  ...toCamel<Plan>(r), priceMonthly: num(r.price_monthly ?? r.priceMonthly), priceYearly: num(r.price_yearly ?? r.priceYearly), maxStudents: numOrNull(r.max_students ?? r.maxStudents), maxTeachers: numOrNull(r.max_teachers ?? r.maxTeachers), maxBranches: numOrNull(r.max_branches ?? r.maxBranches), storageMb: numOrNull(r.storage_mb ?? r.storageMb), features: (r.features as Record<string, boolean>) ?? {}, isActive: Boolean(r.is_active ?? r.isActive ?? true),
});
export const mapSubscription = (r: Record<string, unknown>): Subscription => toCamel<Subscription>(r);
export const mapUsageRecord = (r: Record<string, unknown>): UsageRecord => ({
  ...toCamel<UsageRecord>(r), quantity: num(r.quantity),
});
export const mapAuditLog = (r: Record<string, unknown>): AuditLog => ({
  ...toCamel<AuditLog>(r), before: (r.old_data ?? r.before) as JsonObject | null, after: (r.new_data ?? r.after) as JsonObject | null,
});
export const mapPaymentOrder = (r: Record<string, unknown>): PaymentOrder => ({
  ...toCamel<PaymentOrder>(r), amount: num(r.amount),
});
