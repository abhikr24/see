import { BackendError } from '../../core/contracts/errors';
import { buildStudentHome } from '../../core/contracts/student';
import type { ID, StudentHome } from '../../core/contracts/models';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import {
  mapAssignment,
  mapAttendanceRecord,
  mapBatch,
  mapClassroom,
  mapExam,
  mapFeedback,
  mapMark,
  mapMaterial,
  mapResult,
  mapStudent,
  mapStudentGoal,
  mapSubject,
  mapSubmission,
  mapTeacher,
  mapTimetable,
} from './mappers';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

/**
 * AnalyticsRepo.studentHome (Supabase adapter).
 * Queries are explicitly scoped to the signed-in student's own student_id,
 * active batch_ids, and user_id — mirroring and reinforced by RLS.
 */
export async function studentHome(instituteId: ID): Promise<StudentHome> {
  if (!live) return memoryFallback.analytics.studentHome(instituteId);

  const { data: auth } = await supabase.auth.getUser();
  const userId = auth.user?.id;
  if (!userId) throw new BackendError('UNAUTHENTICATED', 'Sign in required');

  const { data: membership, error: mErr } = await supabase
    .from('memberships')
    .select('id, role')
    .eq('institute_id', instituteId)
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  if (mErr) throw handleSupabaseError(mErr);
  if (!membership || membership.role !== 'student') {
    throw new BackendError('FORBIDDEN', 'Student home is only for student members');
  }

  const { data: smRows, error: smErr } = await supabase
    .from('student_memberships')
    .select('student_id')
    .eq('institute_id', instituteId)
    .eq('membership_id', String(membership.id));
  if (smErr) throw handleSupabaseError(smErr);
  const studentId = smRows?.[0] ? String(smRows[0].student_id) : null;
  if (!studentId) throw new BackendError('NOT_FOUND', 'Student profile not found');

  const [{ data: stuRow, error: stuErr }, { data: enrolRows, error: eErr }] = await Promise.all([
    supabase.from('student_profiles').select('*').eq('institute_id', instituteId).eq('id', studentId).single(),
    supabase
      .from('batch_students')
      .select('batch_id')
      .eq('institute_id', instituteId)
      .eq('student_id', studentId)
      .eq('status', 'active'),
  ]);
  if (stuErr) throw handleSupabaseError(stuErr);
  if (eErr) throw handleSupabaseError(eErr);

  const batchIds = [...new Set((enrolRows ?? []).map((r) => String(r.batch_id)))];
  const emptyList = Promise.resolve({ data: [] as Record<string, unknown>[], error: null });

  const [
    batchesRes,
    subjectsRes,
    teachersRes,
    classroomsRes,
    periodsRes,
    attendanceRes,
    assignmentsRes,
    submissionsRes,
    feedbackRes,
    examsRes,
    marksRes,
    resultsRes,
    materialsRes,
    goalsRes,
    unreadRes,
  ] = await Promise.all([
    batchIds.length > 0
      ? supabase.from('batches').select('*').eq('institute_id', instituteId).in('id', batchIds)
      : emptyList,
    supabase.from('subjects').select('*').eq('institute_id', instituteId),
    supabase.from('teacher_profiles').select('*').eq('institute_id', instituteId),
    supabase.from('classrooms').select('*').eq('institute_id', instituteId),
    batchIds.length > 0
      ? supabase.from('timetables').select('*').eq('institute_id', instituteId).in('batch_id', batchIds)
      : emptyList,
    supabase.from('attendance_records').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    batchIds.length > 0
      ? supabase
          .from('assignments')
          .select('*')
          .eq('institute_id', instituteId)
          .in('batch_id', batchIds)
          .neq('status', 'draft')
      : emptyList,
    supabase.from('submissions').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    supabase.from('feedback').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    batchIds.length > 0
      ? supabase
          .from('exams')
          .select('*')
          .eq('institute_id', instituteId)
          .in('batch_id', batchIds)
          .neq('status', 'draft')
      : emptyList,
    supabase.from('marks').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    supabase.from('results').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    supabase.from('materials').select('*').eq('institute_id', instituteId).eq('is_published', true),
    supabase.from('student_goals').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('institute_id', instituteId)
      .eq('user_id', userId)
      .is('read_at', null),
  ]);

  for (const res of [
    batchesRes,
    subjectsRes,
    teachersRes,
    classroomsRes,
    periodsRes,
    attendanceRes,
    assignmentsRes,
    submissionsRes,
    feedbackRes,
    examsRes,
    marksRes,
    resultsRes,
    materialsRes,
    goalsRes,
  ]) {
    if (res.error) throw handleSupabaseError(res.error);
  }
  if (unreadRes.error) throw handleSupabaseError(unreadRes.error);

  const exams = (examsRes.data ?? []).map(mapExam);
  const publishedIds = new Set(exams.filter((e) => e.status === 'published').map((e) => e.id));

  return buildStudentHome({
    today: new Date().toISOString().slice(0, 10),
    student: mapStudent(stuRow),
    batches: (batchesRes.data ?? []).map(mapBatch),
    subjects: (subjectsRes.data ?? []).map(mapSubject),
    teachers: (teachersRes.data ?? []).map(mapTeacher),
    classrooms: (classroomsRes.data ?? []).map(mapClassroom),
    periods: (periodsRes.data ?? []).map(mapTimetable),
    attendanceRecords: (attendanceRes.data ?? []).map(mapAttendanceRecord),
    assignments: (assignmentsRes.data ?? []).map(mapAssignment),
    submissions: (submissionsRes.data ?? []).map(mapSubmission),
    feedback: (feedbackRes.data ?? []).map(mapFeedback),
    exams,
    marks: (marksRes.data ?? []).map(mapMark).filter((m) => publishedIds.has(m.examId)),
    results: (resultsRes.data ?? []).map(mapResult).filter((r) => publishedIds.has(r.examId)),
    materials: (materialsRes.data ?? []).map(mapMaterial),
    goals: (goalsRes.data ?? []).map(mapStudentGoal),
    unreadNotifications: unreadRes.count ?? 0,
  });
}
