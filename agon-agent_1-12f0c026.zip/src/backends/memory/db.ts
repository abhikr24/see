import type * as M from '../../core/contracts/models';
import type { CrudRepo } from '../../core/contracts/ports';
import { Table, fail, merge, nowIso } from './store';

type ID = M.ID;

export type OtpEntry = { challengeId: ID; userId: ID; code: string; expiresAt: string; channel: 'sms' | 'email'; credentials: { email: string; password: string } };

export function createDb() {
  let seq = 0;
  const nextId = (): ID => `00000000-0000-4000-9000-${String(++seq).padStart(12, '0')}`;
  const table = <T extends M.Entity>(label: string) => new Table<T>(label, nextId);
  return {
    nextId,
    peekSeq: () => seq,
    setSeq: (n: number) => {
      seq = n;
    },
    session: { userId: null as ID | null },
    otpChallenges: new Map<ID, OtpEntry>(),
    /** Global, not tenant-scoped: keyed by user id. */
    profiles: new Map<ID, M.Profile>(),
    listeners: new Map<string, Set<(event: M.RealtimeEvent) => void>>(),
    institutes: table<M.Institute>('Institute'),
    branches: table<M.Branch>('Branch'),
    memberships: table<M.Membership>('Membership'),
    invitations: table<M.Invitation>('Invitation'),
    staff: table<M.StaffRecord>('Staff record'),
    teachers: table<M.Teacher>('Teacher'),
    workloads: table<M.Workload>('Workload'),
    leaveRequests: table<M.LeaveRequest>('Leave request'),
    students: table<M.Student>('Student'),
    guardians: table<M.Guardian>('Guardian'),
    studentMemberships: table<M.StudentMembership>('Student login'),
    parentLinks: table<M.ParentLink>('Parent link'),
    batches: table<M.Batch>('Batch'),
    enrollments: table<M.Enrollment>('Enrolment'),
    subjects: table<M.Subject>('Subject'),
    timetables: table<M.Timetable>('Timetable period'),
    classrooms: table<M.Classroom>('Classroom'),
    attendanceSessions: table<M.AttendanceSession>('Attendance session'),
    attendanceRecords: table<M.AttendanceRecord>('Attendance record'),
    attendanceCorrections: table<M.AttendanceCorrection>('Attendance correction'),
    assignments: table<M.Assignment>('Assignment'),
    submissions: table<M.Submission>('Submission'),
    attachments: table<M.Attachment>('Attachment'),
    feedback: table<M.Feedback>('Feedback'),
    exams: table<M.Exam>('Exam'),
    examQuestions: table<M.ExamQuestion>('Exam question'),
    marks: table<M.Mark>('Mark'),
    results: table<M.Result>('Result'),
    materials: table<M.Material>('Material'),
    bookmarks: table<M.Bookmark>('Bookmark'),
    practiceQuestions: table<M.PracticeQuestion>('Practice question'),
    quizzes: table<M.Quiz>('Quiz'),
    quizAttempts: table<M.QuizAttempt>('Quiz attempt'),
    studyTasks: table<M.StudyTask>('Study task'),
    studentGoals: table<M.StudentGoal>('Goal'),
    feeStructures: table<M.FeeStructure>('Fee structure'),
    studentFees: table<M.StudentFee>('Student fee'),
    installments: table<M.Installment>('Installment'),
    payments: table<M.Payment>('Payment'),
    receipts: table<M.Receipt>('Receipt'),
    refunds: table<M.Refund>('Refund'),
    orders: table<M.PaymentOrder>('Payment order'),
    notices: table<M.Notice>('Notice'),
    notifications: table<M.AppNotification>('Notification'),
    conversations: table<M.Conversation>('Conversation'),
    doubts: table<M.Doubt>('Doubt'),
    meetings: table<M.MeetingRequest>('Meeting request'),
    leads: table<M.AdmissionLead>('Lead'),
    followups: table<M.LeadFollowup>('Follow-up'),
    plans: table<M.Plan>('Plan'),
    subscriptions: table<M.Subscription>('Subscription'),
    usage: table<M.UsageRecord>('Usage record'),
    auditLogs: table<M.AuditLog>('Audit log'),
    exportJobs: table<M.ExportJob>('Export'),
    snapshots: table<M.ProgressSnapshot>('Progress snapshot'),
    alerts: table<M.RiskAlert>('Risk alert'),
  };
}

export type Db = ReturnType<typeof createDb>;

export function requireUser(db: Db): ID {
  return db.session.userId ?? fail('UNAUTHENTICATED');
}

export function emit(db: Db, instituteId: ID, topic: M.RealtimeTopic, change: M.RealtimeEvent['change'], id: ID) {
  const event: M.RealtimeEvent = { topic, change, id, at: nowIso() };
  db.listeners.get(`${instituteId}:${topic}`)?.forEach((listener) => listener(event));
}

/** The caller's own student record plus, for a parent, their children. */
export function myStudentIds(db: Db, instituteId: ID): ID[] {
  const membership = db.memberships.find(instituteId, { userId: requireUser(db), status: 'active' });
  if (!membership) return [];
  const own = db.studentMemberships.all(instituteId, { membershipId: membership.id }).map((l) => l.studentId);
  const children = db.guardians
    .all(instituteId, { membershipId: membership.id })
    .flatMap((g) => db.parentLinks.all(instituteId, { guardianId: g.id }).map((l) => l.studentId));
  return [...new Set([...own, ...children])];
}

/** The batch a student is currently enrolled in, if any. */
export function currentBatchId(db: Db, instituteId: ID, studentId: ID): ID | null {
  return db.enrollments.find(instituteId, { studentId, status: 'active' })?.batchId ?? null;
}

/** Standard create / read / update / delete over one table. */
export function crud<T extends M.TenantEntity, Req extends keyof M.Draft<T> = never>(
  table: Table<T>,
  defaults: () => Omit<M.Draft<T>, Req>,
): CrudRepo<T, Req> {
  return {
    list: async (instituteId, query) => table.page(instituteId, query),
    get: async (instituteId, id) => table.get(instituteId, id),
    create: async (instituteId, input) =>
      table.insert(instituteId, merge(defaults(), input) as unknown as M.Draft<T>),
    update: async (instituteId, id, patch) => table.update(instituteId, id, patch as unknown as Partial<T>),
    remove: async (instituteId, id) => table.remove(instituteId, id),
  };
}

/** Create when the input has no `id`, otherwise update that row. */
export function upsert<T extends M.TenantEntity, Req extends keyof M.Draft<T> = never>(
  table: Table<T>,
  defaults: () => Omit<M.Draft<T>, Req>,
) {
  return async (instituteId: ID, input: M.Upsert<T, Req>): Promise<T> => {
    const { id, ...rest } = input as { id?: ID } & Record<string, unknown>;
    if (id) return table.update(instituteId, id, rest as Partial<T>);
    return table.insert(instituteId, merge(defaults(), rest) as unknown as M.Draft<T>);
  };
}
