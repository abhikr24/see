import type { Material, PracticeQuestion, Quiz } from '../../core/contracts/models';
import type { MaterialRepo, PracticeRepo } from '../../core/contracts/ports';
import { crud, upsert, type Db } from './db';
import * as D from './defaults';
import { studentEnrolledBatchIds } from './homework';
import { fail, merge, nowIso, sum } from './store';
import { callerRole } from './teacher-scope';

export function materialRepo(db: Db): MaterialRepo {
  const base = crud<Material, 'title'>(db.materials, D.material);
  return {
    ...base,
    list: async (instituteId, query) => {
      const role = callerRole(db, instituteId);
      if (role === 'student' || role === 'parent') {
        const batches = studentEnrolledBatchIds(db, instituteId);
        return db.materials.page(
          instituteId,
          query,
          {},
          (m) => m.isPublished && (m.batchId === null || batches.has(m.batchId)),
        );
      }
      return base.list(instituteId, query);
    },
    get: async (instituteId, id) => {
      const item = await base.get(instituteId, id);
      const role = callerRole(db, instituteId);
      if (role === 'student' || role === 'parent') {
        const batches = studentEnrolledBatchIds(db, instituteId);
        if (!item.isPublished || (item.batchId !== null && !batches.has(item.batchId))) {
          fail('NOT_FOUND', 'Material not found');
        }
      }
      return item;
    },
    create: async (instituteId, input) => {
      if (!input.title.trim()) fail('VALIDATION', 'Title is required');
      return base.create(instituteId, { uploadedBy: db.session.userId, ...input });
    },
    listBookmarks: async (instituteId, userId) => db.bookmarks.all(instituteId, { userId }),
    addBookmark: async (instituteId, input) => {
      const { userId, targetType, targetId } = input;
      const existing = db.bookmarks.find(instituteId, { userId, targetType, targetId });
      return existing ?? db.bookmarks.insert(instituteId, merge(D.bookmark(), input));
    },
    removeBookmark: async (instituteId, id) => db.bookmarks.remove(instituteId, id),
  };
}

export function practiceRepo(db: Db): PracticeRepo {
  const saveQuiz = upsert<Quiz, 'batchId' | 'title'>(db.quizzes, D.quiz);
  const sanitizeQuestionForStudent = (q: PracticeQuestion): PracticeQuestion => ({
    ...q,
    // Never ship answer key to student/parent clients
    correctAnswer: null,
  });
  return {
    listQuestions: async (instituteId, query) => {
      const page = db.practiceQuestions.page(instituteId, query);
      const role = callerRole(db, instituteId);
      if (role === 'student' || role === 'parent') {
        return {
          ...page,
          items: page.items.map(sanitizeQuestionForStudent),
        };
      }
      return page;
    },
    saveQuestion: upsert<PracticeQuestion, 'text'>(db.practiceQuestions, D.practiceQuestion),
    removeQuestion: async (instituteId, id) => db.practiceQuestions.remove(instituteId, id),
    listQuizzes: async (instituteId, query) => db.quizzes.page(instituteId, query),
    saveQuiz: async (instituteId, input) => {
      // Every question on the quiz must exist in this institute.
      input.questionIds?.forEach((questionId) => db.practiceQuestions.get(instituteId, questionId));
      return saveQuiz(instituteId, input);
    },
    listAttempts: async (instituteId, filter = {}) => db.quizAttempts.all(instituteId, filter),
    startAttempt: async (instituteId, quizId, studentId) => {
      const quiz = db.quizzes.get(instituteId, quizId);
      if (quiz.status !== 'published') fail('FORBIDDEN', 'This quiz is not open');
      if (!db.enrollments.find(instituteId, { batchId: quiz.batchId, studentId, status: 'active' })) {
        fail('VALIDATION', 'Student is not in the batch this quiz was set for');
      }
      const previous = db.quizAttempts.all(instituteId, { quizId, studentId });
      if (previous.some((attempt) => attempt.status === 'in_progress')) {
        fail('CONFLICT', 'An attempt is already in progress');
      }
      return db.quizAttempts.insert(instituteId, {
        quizId,
        batchId: quiz.batchId,
        studentId,
        attemptNo: previous.length + 1,
        startedAt: nowIso(),
        submittedAt: null,
        answers: {},
        score: null,
        maxScore: null,
        status: 'in_progress',
      });
    },
    submitAttempt: async (instituteId, attemptId, answers) => {
      const attempt = db.quizAttempts.get(instituteId, attemptId);
      // Allow re-submit for incremental grading during a practice session
      // Original guard was too strict for per-question instant feedback.
      const wasAlreadyGraded = attempt.status === 'graded';
      if (attempt.status !== 'in_progress' && !wasAlreadyGraded) {
        fail('CONFLICT', 'This attempt was already submitted');
      }
      const quiz = db.quizzes.get(instituteId, attempt.quizId);
      const questions = quiz.questionIds.map((questionId) => db.practiceQuestions.get(instituteId, questionId));
      const normalise = (value: string | null | undefined) => (value ?? '').trim().toLowerCase();
      const earned = questions
        .filter((q) => q.correctAnswer !== null && normalise(answers[q.id]) === normalise(q.correctAnswer))
        .map((q) => q.marks);
      const allAnswered = quiz.questionIds.every((qid) => answers[qid] !== undefined && answers[qid] !== null && answers[qid] !== '');
      return db.quizAttempts.update(instituteId, attemptId, {
        answers,
        submittedAt: nowIso(),
        score: sum(earned),
        maxScore: sum(questions.map((q) => q.marks)),
        status: allAnswered ? 'graded' : 'in_progress',
      });
    },
  };
}
