import type { ID, LeaveRequest } from '../../core/contracts/models';
import type { LeaveRepo, SubmitLeaveInput } from '../../core/contracts/ports';
import { emit, requireUser, type Db } from './db';
import * as D from './defaults';
import { callerRole, callerTeacher } from './teacher-scope';
import { fail, merge, nowIso } from './store';

const LEAVE_TYPES = new Set<SubmitLeaveInput['leaveType']>(['casual', 'sick', 'personal']);

function ownerIds(db: Db, instituteId: ID): ID[] {
  return db.memberships
    .all(instituteId, { role: 'owner', status: 'active' })
    .map((membership) => membership.userId);
}

function notifyOwners(db: Db, instituteId: ID, request: LeaveRequest): void {
  for (const userId of ownerIds(db, instituteId)) {
    const sent = db.notifications.insert(
      instituteId,
      merge(D.notification(), {
        userId,
        type: 'leave_requested',
        title: 'Leave request needs approval',
        body: `${request.leaveType} leave · ${request.fromDate} to ${request.toDate}`,
        data: { screen: 'approvals', leaveRequestId: request.id },
      }),
    );
    emit(db, instituteId, 'notifications', 'created', sent.id);
  }
}

export function leaveRepo(db: Db): LeaveRepo {
  return {
    list: async (instituteId, query) => {
      const role = callerRole(db, instituteId);
      if (role === 'owner' || role === 'admin') return db.leaveRequests.page(instituteId, query);
      if (role !== 'teacher') return { items: [], nextCursor: null, total: 0 };
      const userId = requireUser(db);
      return db.leaveRequests.page(instituteId, query, { userId });
    },

    get: async (instituteId, id) => {
      const request = db.leaveRequests.get(instituteId, id);
      const role = callerRole(db, instituteId);
      if (role === 'owner' || role === 'admin') return request;
      if (role === 'teacher' && request.userId === requireUser(db)) return request;
      fail('NOT_FOUND', 'Leave request not found');
    },

    submit: async (instituteId, input) => {
      const userId = requireUser(db);
      if (callerRole(db, instituteId) !== 'teacher') {
        fail('FORBIDDEN', 'Only a teacher can request leave');
      }
      const teacher = callerTeacher(db, instituteId);
      if (!teacher) fail('FORBIDDEN', 'Teacher profile not found');
      if (!LEAVE_TYPES.has(input.leaveType)) fail('VALIDATION', 'Choose a valid leave type');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(input.fromDate) || !/^\d{4}-\d{2}-\d{2}$/.test(input.toDate)) {
        fail('VALIDATION', 'Choose valid leave dates');
      }
      if (input.toDate < input.fromDate) fail('VALIDATION', 'The end date cannot be before the start date');
      if (input.reason.trim().length < 3) fail('VALIDATION', 'Add a reason for your leave');

      const request = db.leaveRequests.insert(
        instituteId,
        merge(D.leaveRequest(), {
          ...input,
          reason: input.reason.trim(),
          userId,
          teacherId: teacher.id,
        }),
      );
      notifyOwners(db, instituteId, request);
      emit(db, instituteId, 'leave_requests', 'created', request.id);
      return request;
    },

    listMine: async (instituteId) => {
      if (callerRole(db, instituteId) !== 'teacher') {
        fail('FORBIDDEN', 'Only a teacher can view leave history');
      }
      return db.leaveRequests
        .all(instituteId, { userId: requireUser(db) })
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },

    listPending: async (instituteId) => {
      if (callerRole(db, instituteId) !== 'owner') {
        fail('FORBIDDEN', 'Only the owner can review leave requests');
      }
      return db.leaveRequests
        .all(instituteId, { status: 'pending' })
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    },

    decide: async (instituteId, id, status, note = null) => {
      if (callerRole(db, instituteId) !== 'owner') {
        fail('FORBIDDEN', 'Only the owner can review leave requests');
      }
      const reviewerId = requireUser(db);
      const request = db.leaveRequests.get(instituteId, id);
      if (request.userId === reviewerId) {
        fail('FORBIDDEN', 'You cannot approve your own leave request');
      }
      if (request.status !== 'pending') {
        fail('CONFLICT', `This leave request is already ${request.status}`);
      }
      const updated = db.leaveRequests.update(instituteId, id, {
        status,
        reviewedBy: reviewerId,
        reviewedAt: nowIso(),
        reviewNote: note?.trim() || null,
      });
      const sent = db.notifications.insert(
        instituteId,
        merge(D.notification(), {
          userId: request.userId,
          type: `leave_${status}`,
          title: `Leave request ${status}`,
          body: `${request.fromDate} to ${request.toDate} · ${status}`,
          data: { screen: 'leave', leaveRequestId: request.id },
        }),
      );
      emit(db, instituteId, 'notifications', 'created', sent.id);
      emit(db, instituteId, 'leave_requests', 'updated', id);
      return updated;
    },
  };
}
