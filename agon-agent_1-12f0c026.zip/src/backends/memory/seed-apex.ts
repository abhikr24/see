import type { AttendanceStatus, ID } from '../../core/contracts/models';
import { gradeForPercent } from '../../core/contracts/exam-analysis';
import type { Db } from './db';
import * as D from './defaults';
import { addDays } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const AARAV_USER = sid(14);
const APEX_INST = sid(71001);

export function seedApexInstitute(db: Db, at: string, today: string): void {
  if (db.institutes.everything().some((inst) => inst.id === APEX_INST)) return;

  const row = (n: number) => ({ id: sid(n), instituteId: APEX_INST, createdAt: at, updatedAt: at });
  const OWNER = sid(71002);
  const BRANCH = sid(71003);
  const TEACHER = sid(71004);
  const SUBJ_PHY = sid(71005);
  const SUBJ_CHEM = sid(71006);
  const ROOM = sid(71007);
  const BATCH = sid(71008);
  const STUDENT = sid(71010);

  db.institutes.put({
    ...D.institute(),
    id: APEX_INST,
    name: 'Apex Science Academy',
    code: 'APEX-PAT',
    ownerId: OWNER,
    city: 'Patna',
    state: 'Bihar',
    settings: { ...D.settings(), academicYear: '2026-27', receiptPrefix: 'ASA', features: { attendanceAlerts: true, homeworkAlerts: true } },
    createdAt: at,
    updatedAt: at,
  });
  db.branches.put({ ...D.branch(), ...row(71003), name: 'Kankarbagh', code: 'KKB', city: 'Patna', isMain: true });

  db.profiles.set(OWNER, {
    ...D.profile(),
    id: sid(71102),
    userId: OWNER,
    fullName: 'Dr. Kavita Rao',
    email: 'kavita@apex.test',
    createdAt: at,
    updatedAt: at,
  });
  db.memberships.put({
    ...row(71103),
    userId: OWNER,
    branchId: BRANCH,
    role: 'owner',
    status: 'active',
    permissions: [],
    requestNote: null,
    requestedAt: at,
    decidedBy: OWNER,
    decidedAt: at,
  });
  db.teachers.put({ ...D.teacher(), ...row(71004), userId: OWNER, branchId: BRANCH, fullName: 'Dr. Kavita Rao', specialization: 'Physics' });
  db.subjects.put({ ...D.subject(), ...row(71005), name: 'Physics', code: 'PHY' });
  db.subjects.put({ ...D.subject(), ...row(71006), name: 'Chemistry', code: 'CHEM' });
  db.classrooms.put({ ...D.classroom(), ...row(71007), branchId: BRANCH, name: 'Hall A', capacity: 30, floor: '2' });

  db.batches.put({
    ...D.batch(),
    ...row(71008),
    branchId: BRANCH,
    classroomId: ROOM,
    name: 'NEET Foundation',
    grade: '10',
    section: 'F',
    academicYear: '2026-27',
    teacherId: TEACHER,
    subjectId: SUBJ_PHY,
  });

  // Aarav Sharma holds a second active student membership here.
  db.memberships.put({
    ...row(71009),
    userId: AARAV_USER,
    branchId: BRANCH,
    role: 'student',
    status: 'active',
    permissions: [],
    requestNote: null,
    requestedAt: at,
    decidedBy: OWNER,
    decidedAt: at,
  });
  db.students.put({
    ...D.student(),
    ...row(71010),
    branchId: BRANCH,
    fullName: 'Aarav Sharma',
    admissionNo: 'ASA-0007',
    classGrade: '10',
  });
  db.studentMemberships.put({ ...row(71011), studentId: STUDENT, membershipId: sid(71009), linkedBy: OWNER });
  db.enrollments.put({
    ...row(71012),
    batchId: BATCH,
    studentId: STUDENT,
    rollNumber: 7,
    joinedOn: addDays(today, -60),
    leftOn: null,
    status: 'active',
  });

  // Today's classes at Apex.
  const todayDow = new Date(`${today}T00:00:00Z`).getUTCDay();
  db.timetables.put({
    ...D.timetable(), ...row(71020), batchId: BATCH, subjectId: SUBJ_PHY, teacherId: TEACHER,
    classroomId: ROOM, dayOfWeek: todayDow, startsAt: '10:00', endsAt: '11:30',
  });
  db.timetables.put({
    ...D.timetable(), ...row(71021), batchId: BATCH, subjectId: SUBJ_CHEM, teacherId: TEACHER,
    classroomId: ROOM, dayOfWeek: todayDow, startsAt: '11:45', endsAt: '13:00',
  });

  // 20 attendance sessions: 17 present, 3 absent = 85%.
  for (let day = 0; day < 20; day += 1) {
    const sessionId = sid(71200 + day);
    db.attendanceSessions.put({
      ...row(71200 + day), batchId: BATCH, subjectId: SUBJ_PHY, teacherId: TEACHER,
      date: addDays(today, day - 19), period: 1, status: 'submitted', markedBy: OWNER, markedAt: at, notes: null,
    });
    const status: AttendanceStatus = day === 4 || day === 11 || day === 17 ? 'absent' : 'present';
    db.attendanceRecords.put({
      ...row(71300 + day), sessionId, batchId: BATCH, studentId: STUDENT, status, remark: null, markedBy: OWNER,
    });
  }

  // Upcoming test in 5 days + published Bridge Course Quiz (43/50 = 86%).
  db.exams.put({
    ...D.exam(), ...row(71030), batchId: BATCH, subjectId: SUBJ_PHY, name: 'Mechanics Mock Test',
    examType: 'mock', startsOn: addDays(today, 5), endsOn: addDays(today, 5), totalMarks: 60,
    passPercent: 33, status: 'scheduled', publishedAt: null, createdBy: OWNER,
  });
  db.exams.put({
    ...D.exam(), ...row(71031), batchId: BATCH, subjectId: SUBJ_PHY, name: 'Bridge Course Quiz',
    examType: 'weekly_test', startsOn: addDays(today, -7), endsOn: addDays(today, -7), totalMarks: 50,
    passPercent: 33, status: 'published', publishedAt: at, createdBy: OWNER,
  });
  db.marks.put({
    ...row(71032), examId: sid(71031), batchId: BATCH, studentId: STUDENT, subjectId: SUBJ_PHY,
    marksObtained: 43, maxMarks: 50, isAbsent: false, grade: gradeForPercent(86), remark: null, enteredBy: OWNER,
  });
  db.results.put({
    ...row(71033), examId: sid(71031), batchId: BATCH, studentId: STUDENT, totalObtained: 43,
    totalMax: 50, percentage: 86, grade: gradeForPercent(86), rank: 1, status: 'pass', remarks: null,
  });

  // Homework due today at Apex: one submitted, one pending.
  db.assignments.put({
    ...D.assignment(), ...row(71040), batchId: BATCH, subjectId: SUBJ_PHY, teacherId: TEACHER,
    title: 'Vector Addition Practice', instructions: 'Solve problems 1 to 8 using triangle law.',
    assignedOn: addDays(today, -2), dueAt: `${today}T18:00:00.000Z`, maxMarks: 20, status: 'published', createdBy: OWNER,
  });
  db.submissions.put({
    ...row(71042), assignmentId: sid(71040), batchId: BATCH, studentId: STUDENT,
    content: 'Completed all 8 problems.', submittedAt: `${today}T08:15:00.000Z`, status: 'submitted',
  });
  db.assignments.put({
    ...D.assignment(), ...row(71041), batchId: BATCH, subjectId: SUBJ_PHY, teacherId: TEACHER,
    title: 'Laws of Motion: Free Body Diagrams', instructions: 'Draw neat FBD diagrams for each block.',
    assignedOn: addDays(today, -1), dueAt: `${today}T19:00:00.000Z`, maxMarks: 25, status: 'published', createdBy: OWNER,
  });

  // Materials & goal at Apex.
  db.materials.put({
    ...D.material(), ...row(71050), batchId: BATCH, subjectId: SUBJ_PHY, teacherId: TEACHER,
    title: 'Vectors & Kinematics Notes', materialType: 'notes', topic: 'Kinematics',
    description: 'Summary of projectile and relative motion formulas.', isPublished: true, uploadedBy: OWNER,
  });
  db.materials.put({
    ...D.material(), ...row(71051), batchId: BATCH, subjectId: SUBJ_CHEM, teacherId: TEACHER,
    title: 'Mole Concept Problems', materialType: 'pdf', topic: 'Stoichiometry',
    description: '25 foundation numericals with hints.', isPublished: true, uploadedBy: OWNER,
  });
  db.studentGoals.put({
    ...D.studentGoal(), ...row(71060), studentId: STUDENT, subjectId: SUBJ_PHY,
    title: 'Score 85%+ in Foundation tests', metric: 'exam_percent', targetValue: 85, currentValue: 86,
    startsOn: addDays(today, -20), targetDate: addDays(today, 40), status: 'active', createdBy: AARAV_USER,
  });
  db.notifications.put({
    ...D.notification(), ...row(71070), userId: AARAV_USER, type: 'general',
    title: 'Mechanics Mock Test in 5 days', body: 'NEET Foundation · Revise Vectors & Kinematics Notes.',
    data: { screen: 'home' }, readAt: null,
  });
}
