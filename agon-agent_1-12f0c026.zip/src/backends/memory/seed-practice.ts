import type { ID, PracticeQuestion, Quiz } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { nowIso } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INST = sid(1);
const BATCH_10A = sid(9);
const CLASS_9A = sid(10);
const SUBJ_MATH = sid(44);
const SUBJ_PHY = sid(45);
const SUBJ_CHEM = sid(46);
const TEACHER_ROHIT = sid(3);
const TEACHER_PRIYA = sid(4);

/**
 * Practice question bank + quizzes for student practice feature.
 * Topics = chapters.
 * Each question has: text, 4 options, correctAnswer, explanation.
 */

interface QSpec {
  id: number;
  subjectId: ID;
  subjectName: string;
  topic: string; // chapter
  difficulty: PracticeQuestion['difficulty'];
  text: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const QUESTIONS: QSpec[] = [
  // Maths — Quadratic Equations (5)
  {
    id: 72001,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Quadratic Equations',
    difficulty: 'medium',
    text: 'If α and β are roots of x² - 5x + 6 = 0, what is α + β?',
    options: ['5', '6', '-5', '2'],
    correctIndex: 0,
    explanation: 'For ax²+bx+c=0, sum of roots = -b/a. Here -(-5)/1 = 5.',
  },
  {
    id: 72002,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Quadratic Equations',
    difficulty: 'medium',
    text: 'The discriminant of 2x² - 4x + 3 = 0 is?',
    options: ['-8', '8', '16', '0'],
    correctIndex: 0,
    explanation: 'D = b² - 4ac = 16 - 24 = -8. No real roots.',
  },
  {
    id: 72003,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Quadratic Equations',
    difficulty: 'hard',
    text: 'For what value of k does x² + kx + 9 = 0 have equal roots?',
    options: ['±6', '6', '-6', '±3'],
    correctIndex: 0,
    explanation: 'Equal roots when D=0: k² -36=0 => k=±6.',
  },
  {
    id: 72004,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Quadratic Equations',
    difficulty: 'easy',
    text: 'If one root of x² - 8x + 15 = 0 is 3, the other is?',
    options: ['5', '3', '15', '8'],
    correctIndex: 0,
    explanation: 'Product =15, one root 3 => other 5. Or solve (x-3)(x-5)=0.',
  },
  {
    id: 72005,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Quadratic Equations',
    difficulty: 'medium',
    text: 'Maximum value of -x² + 6x -5 is?',
    options: ['4', '5', '6', '9'],
    correctIndex: 0,
    explanation: 'Vertex at x=-b/2a? Actually for -x²+6x-5, vertex x=3, value = -9+18-5=4.',
  },
  // Maths — Trigonometry (5)
  {
    id: 72006,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Trigonometry',
    difficulty: 'easy',
    text: 'sin²θ + cos²θ = ?',
    options: ['1', '0', '2', 'tan²θ'],
    correctIndex: 0,
    explanation: 'Fundamental identity: sin²θ + cos²θ = 1 for all θ.',
  },
  {
    id: 72007,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Trigonometry',
    difficulty: 'medium',
    text: 'If sinθ = 3/5, then cosθ = ? (θ acute)',
    options: ['4/5', '5/4', '3/4', '1/2'],
    correctIndex: 0,
    explanation: 'cos²θ =1 -9/25=16/25 => cosθ=4/5 in first quadrant.',
  },
  {
    id: 72008,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Trigonometry',
    difficulty: 'hard',
    text: 'Value of tan 45° * cot 45° is?',
    options: ['1', '0', '2', '∞'],
    correctIndex: 0,
    explanation: 'tan45=1, cot45=1, product 1.',
  },
  {
    id: 72009,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Trigonometry',
    difficulty: 'medium',
    text: 'cos 60° equals?',
    options: ['1/2', '√3/2', '0', '1'],
    correctIndex: 0,
    explanation: 'Standard value: cos60° = 0.5',
  },
  {
    id: 72010,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Trigonometry',
    difficulty: 'hard',
    text: 'If tanθ = 1, then θ = ? (0°<θ<90°)',
    options: ['45°', '30°', '60°', '0°'],
    correctIndex: 0,
    explanation: 'tan45°=1 by definition.',
  },
  // Maths — Linear Equations (4)
  {
    id: 72011,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Linear Equations',
    difficulty: 'easy',
    text: 'Solve: 2x + 3 = 7. x = ?',
    options: ['2', '3', '5', '7'],
    correctIndex: 0,
    explanation: '2x=4 => x=2.',
  },
  {
    id: 72012,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Linear Equations',
    difficulty: 'medium',
    text: 'Pair x+y=5 and x-y=1 has solution?',
    options: ['(3,2)', '(2,3)', '(5,0)', '(0,5)'],
    correctIndex: 0,
    explanation: 'Add: 2x=6 => x=3, y=2.',
  },
  {
    id: 72013,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Linear Equations',
    difficulty: 'medium',
    text: 'If 3x - 2y = 0 and x=4, y=?',
    options: ['6', '4', '3', '0'],
    correctIndex: 0,
    explanation: '12 -2y=0 => y=6.',
  },
  {
    id: 72014,
    subjectId: SUBJ_MATH,
    subjectName: 'Mathematics',
    topic: 'Linear Equations',
    difficulty: 'hard',
    text: 'Number of solutions for parallel lines a1/a2 = b1/b2 ≠ c1/c2?',
    options: ['0', '1', 'Infinite', '2'],
    correctIndex: 0,
    explanation: 'Parallel distinct lines never meet: no solution.',
  },
  // Physics — Motion (5)
  {
    id: 72021,
    subjectId: SUBJ_PHY,
    subjectName: 'Physics',
    topic: 'Motion',
    difficulty: 'easy',
    text: 'SI unit of velocity is?',
    options: ['m/s', 'm/s²', 'm', 'km/h'],
    correctIndex: 0,
    explanation: 'Velocity = displacement / time = m/s.',
  },
  {
    id: 72022,
    subjectId: SUBJ_PHY,
    subjectName: 'Physics',
    topic: 'Motion',
    difficulty: 'medium',
    text: 'A car accelerates from 0 to 20 m/s in 4s. Acceleration =?',
    options: ['5 m/s²', '20 m/s²', '80 m/s²', '4 m/s²'],
    correctIndex: 0,
    explanation: 'a = (v-u)/t =20/4=5 m/s².',
  },
  {
    id: 72023,
    subjectId: SUBJ_PHY,
    subjectName: 'Physics',
    topic: 'Motion',
    difficulty: 'hard',
    text: 'Distance covered in 10s with u=5 m/s, a=2 m/s² using s=ut+½at²?',
    options: ['150 m', '100 m', '50 m', '250 m'],
    correctIndex: 0,
    explanation: 's=5*10+0.5*2*100=50+100=150 m.',
  },
  {
    id: 72024,
    subjectId: SUBJ_PHY,
    subjectName: 'Physics',
    topic: 'Motion',
    difficulty: 'medium',
    text: 'Uniform motion means?',
    options: ['Constant velocity', 'Constant acceleration', 'Zero velocity', 'Variable speed'],
    correctIndex: 0,
    explanation: 'Uniform motion = equal distances in equal times => constant velocity.',
  },
  {
    id: 72025,
    subjectId: SUBJ_PHY,
    subjectName: 'Physics',
    topic: 'Motion',
    difficulty: 'easy',
    text: 'Slope of distance-time graph gives?',
    options: ['Speed', 'Acceleration', 'Distance', 'Force'],
    correctIndex: 0,
    explanation: 'Slope = Δdistance/Δtime = speed.',
  },
  // Chemistry — Atoms (3)
  {
    id: 72031,
    subjectId: SUBJ_CHEM,
    subjectName: 'Chemistry',
    topic: 'Atoms & Molecules',
    difficulty: 'easy',
    text: 'Number of atoms in 1 mole?',
    options: ['6.022×10²³', '3.022×10²³', '1×10²³', '6×10²⁴'],
    correctIndex: 0,
    explanation: 'Avogadro number: 6.022×10²³.',
  },
  {
    id: 72032,
    subjectId: SUBJ_CHEM,
    subjectName: 'Chemistry',
    topic: 'Atoms & Molecules',
    difficulty: 'medium',
    text: 'Atomic mass unit defined w.r.t?',
    options: ['Carbon-12', 'Hydrogen', 'Oxygen-16', 'Helium'],
    correctIndex: 0,
    explanation: '1 amu = 1/12 mass of C-12 atom.',
  },
  {
    id: 72033,
    subjectId: SUBJ_CHEM,
    subjectName: 'Chemistry',
    topic: 'Atoms & Molecules',
    difficulty: 'hard',
    text: 'Molar mass of H₂SO₄?',
    options: ['98 g/mol', '49 g/mol', '100 g/mol', '96 g/mol'],
    correctIndex: 0,
    explanation: '2*1+32+4*16=98 g/mol.',
  },
];

interface QuizSpec {
  id: number;
  title: string;
  description: string;
  subjectId: ID;
  batchId: ID;
  topic: string;
  questionIds: number[];
  duration: number;
}

const QUIZZES: QuizSpec[] = [
  {
    id: 73001,
    title: 'Quadratic Equations',
    description: 'Practice set for factorization and discriminant.',
    subjectId: SUBJ_MATH,
    batchId: BATCH_10A,
    topic: 'Quadratic Equations',
    questionIds: [72001, 72002, 72003, 72004, 72005],
    duration: 15,
  },
  {
    id: 73002,
    title: 'Trigonometry',
    description: 'Identities, ratios and standard angles.',
    subjectId: SUBJ_MATH,
    batchId: BATCH_10A,
    topic: 'Trigonometry',
    questionIds: [72006, 72007, 72008, 72009, 72010],
    duration: 15,
  },
  {
    id: 73003,
    title: 'Linear Equations',
    description: 'Solve pair of linear equations.',
    subjectId: SUBJ_MATH,
    batchId: BATCH_10A,
    topic: 'Linear Equations',
    questionIds: [72011, 72012, 72013, 72014],
    duration: 12,
  },
  {
    id: 73004,
    title: 'Motion',
    description: 'Speed, velocity and Equations of motion.',
    subjectId: SUBJ_PHY,
    batchId: CLASS_9A,
    topic: 'Motion',
    questionIds: [72021, 72022, 72023, 72024, 72025],
    duration: 15,
  },
  {
    id: 73005,
    title: 'Atoms & Molecules',
    description: 'Mole concept and atomic masses.',
    subjectId: SUBJ_CHEM,
    batchId: BATCH_10A,
    topic: 'Atoms & Molecules',
    questionIds: [72031, 72032, 72033],
    duration: 10,
  },
];

export function seedPractice(db: Db): void {
  const at = nowIso();
  const row = (n: number) => ({ id: sid(n), instituteId: INST, createdAt: at, updatedAt: at });

  // Insert questions if not already present
  for (const spec of QUESTIONS) {
    if (db.practiceQuestions.all(INST, { id: sid(spec.id) }).length > 0) continue;
    db.practiceQuestions.put({
      ...D.practiceQuestion(),
      ...row(spec.id),
      batchId: spec.subjectId === SUBJ_PHY && spec.topic === 'Motion' ? CLASS_9A : BATCH_10A,
      subjectId: spec.subjectId,
      topic: spec.topic,
      difficulty: spec.difficulty,
      questionType: 'mcq',
      text: spec.text,
      options: spec.options,
      correctAnswer: spec.options[spec.correctIndex],
      explanation: spec.explanation,
      marks: 1,
      isPublished: true,
      createdBy: spec.subjectId === SUBJ_PHY ? TEACHER_PRIYA : TEACHER_ROHIT,
    });
  }

  // Insert quizzes
  for (const qz of QUIZZES) {
    if (db.quizzes.all(INST, { id: sid(qz.id) }).length > 0) continue;
    db.quizzes.put({
      ...D.quiz(),
      ...row(qz.id),
      batchId: qz.batchId,
      subjectId: qz.subjectId,
      teacherId: qz.subjectId === SUBJ_PHY ? TEACHER_PRIYA : TEACHER_ROHIT,
      title: qz.title,
      description: qz.description,
      questionIds: qz.questionIds.map(sid),
      durationMinutes: qz.duration,
      totalMarks: qz.questionIds.length,
      status: 'published',
      createdBy: qz.subjectId === SUBJ_PHY ? TEACHER_PRIYA : TEACHER_ROHIT,
    });
  }

  // One sample attempt for Aarav to show improvement tracking
  const aarav = sid(14);
  const quizId = sid(73001);
  const attemptId = sid(74001);
  if (db.quizAttempts.all(INST, { id: attemptId }).length === 0) {
    db.quizAttempts.put({
      ...row(74001),
      quizId,
      batchId: BATCH_10A,
      studentId: aarav,
      attemptNo: 1,
      startedAt: `${at.slice(0, 10)}T09:00:00.000Z`,
      submittedAt: `${at.slice(0, 10)}T09:12:00.000Z`,
      answers: {
        [sid(72001)]: '5',
        [sid(72002)]: '8',
        [sid(72003)]: '±6',
        [sid(72004)]: '3',
        [sid(72005)]: '4',
      },
      score: 3,
      maxScore: 5,
      status: 'graded',
    } as any);
  }
}

export function ensurePractice(db: Db): void {
  if (!db.institutes.everything().some((i) => i.id === INST)) return;
  if (db.practiceQuestions.all(INST).length < 10) {
    seedPractice(db);
  }
}
