import type { ID, Material } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { seedApexInstitute } from './seed-apex';
import { ensurePractice, seedPractice } from './seed-practice';
import { addDays, nowIso, todayIso } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INST = sid(1);
const BATCH_10A = sid(9);
const AARAV_USER = sid(14);

function seedSunriseStudentExtras(db: Db, at: string, today: string): void {
  const row = (n: number) => ({ id: sid(n), instituteId: INST, createdAt: at, updatedAt: at });

  if (db.exams.all(INST, { id: sid(70001) }).length === 0) {
    db.exams.put({
      ...D.exam(),
      ...row(70001),
      batchId: BATCH_10A,
      subjectId: sid(45),
      name: 'Monthly Physics Test',
      examType: 'unit_test',
      startsOn: addDays(today, 3),
      endsOn: addDays(today, 3),
      totalMarks: 50,
      passPercent: 33,
      status: 'scheduled',
      publishedAt: null,
      createdBy: sid(4),
    });
  }

  const materials: [number, string, Material['materialType'], number, number, string, string][] = [
    [70101, 'Quadratic Formula Sheet', 'pdf', 44, 3, 'Quadratic Equations', 'Key identities and solved examples for quick revision.'],
    [70102, 'Optics Ray Diagrams', 'notes', 45, 4, 'Light & Reflection', 'Concave and convex mirror ray rules with sign conventions.'],
    [70103, 'Trigonometry Identities', 'video', 44, 3, 'Chapter 8', '12-minute walkthrough of standard ratios and identities.'],
    [70104, 'Chemical Equations Guide', 'worksheet', 46, 5, 'Reactions', '20 practice equations to balance before Friday.'],
  ];
  for (const [id, title, materialType, subjectNum, teacherNum, topic, description] of materials) {
    if (db.materials.all(INST, { id: sid(id) }).length > 0) continue;
    db.materials.put({
      ...D.material(),
      ...row(id),
      batchId: BATCH_10A,
      subjectId: sid(subjectNum),
      teacherId: sid(teacherNum),
      title,
      materialType,
      topic,
      description,
      isPublished: true,
      uploadedBy: sid(teacherNum),
    });
  }

  if (db.studentGoals.all(INST, { id: sid(70201) }).length === 0) {
    db.studentGoals.put({
      ...D.studentGoal(),
      ...row(70201),
      studentId: AARAV_USER,
      subjectId: null,
      title: 'Keep attendance above 90%',
      description: 'Attend every Class 10-A session consistently.',
      metric: 'attendance_percent',
      targetValue: 90,
      currentValue: 93,
      startsOn: addDays(today, -30),
      targetDate: addDays(today, 60),
      status: 'active',
      createdBy: AARAV_USER,
    });
  }
  if (db.studentGoals.all(INST, { id: sid(70202) }).length === 0) {
    db.studentGoals.put({
      ...D.studentGoal(),
      ...row(70202),
      studentId: AARAV_USER,
      subjectId: sid(44),
      title: 'Score 80%+ average in tests',
      description: 'Maintain an 80% average across unit and weekly tests.',
      metric: 'exam_percent',
      targetValue: 80,
      currentValue: 80,
      startsOn: addDays(today, -30),
      targetDate: addDays(today, 60),
      status: 'active',
      createdBy: AARAV_USER,
    });
  }

  if (db.notifications.all(INST, { id: sid(70301) }).length === 0) {
    db.notifications.put({
      ...D.notification(),
      ...row(70301),
      userId: AARAV_USER,
      type: 'homework_assigned',
      title: 'Trigonometry practice set due today',
      body: 'Class 10-A · Turn in your Chapter 8 odd-numbered questions before tonight.',
      data: { screen: 'homework', assignmentId: sid(14003), batchId: BATCH_10A },
      readAt: null,
    });
  }
}

export function seedStudentExtras(db: Db): void {
  const at = nowIso();
  const today = todayIso();
  seedSunriseStudentExtras(db, at, today);
  seedApexInstitute(db, at, today);
  seedPractice(db);
}

/** Ensures persisted snapshots gain the student home seed additions once. */
export function ensureStudentExtras(db: Db): void {
  if (!db.institutes.everything().some((inst) => inst.id === INST)) return;
  seedStudentExtras(db);
  ensurePractice(db);
}
