import { buildStudentHome } from '../../core/contracts/student';
import type { ID, StudentHome } from '../../core/contracts/models';
import { requireUser, type Db } from './db';
import { callerStudentIds } from './homework';
import { fail, todayIso } from './store';
import { callerRole } from './teacher-scope';

/**
 * AnalyticsRepo.studentHome — strictly scoped to the signed-in student's
 * own student record, active batches, attendance, marks, materials and goals.
 */
export function studentHome(db: Db, instituteId: ID): StudentHome {
  const userId = requireUser(db);
  db.institutes.get(instituteId, instituteId);
  if (callerRole(db, instituteId) !== 'student') {
    fail('FORBIDDEN', 'Student home is only for student members');
  }
  const studentIds = callerStudentIds(db, instituteId);
  const studentId = studentIds[0];
  if (!studentId) fail('NOT_FOUND', 'Student profile not found');

  const student = db.students.get(instituteId, studentId);
  const activeBatchIds = new Set(
    db.enrollments.all(instituteId, { studentId, status: 'active' }).map((e) => e.batchId),
  );
  const batches = db.batches.all(instituteId).filter((b) => activeBatchIds.has(b.id));
  const periods = db.timetables.all(instituteId).filter((p) => activeBatchIds.has(p.batchId));
  const attendanceRecords = db.attendanceRecords.all(instituteId, { studentId });
  const assignments = db.assignments.all(instituteId).filter((a) => activeBatchIds.has(a.batchId));
  const submissions = db.submissions.all(instituteId, { studentId });
  const feedback = db.feedback.all(instituteId, { studentId });

  const exams = db.exams.all(instituteId).filter((e) => activeBatchIds.has(e.batchId));
  const publishedExamIds = new Set(exams.filter((e) => e.status === 'published').map((e) => e.id));
  const marks = db.marks.all(instituteId, { studentId }).filter((m) => publishedExamIds.has(m.examId));
  const results = db.results.all(instituteId, { studentId }).filter((r) => publishedExamIds.has(r.examId));

  const materials = db.materials
    .all(instituteId)
    .filter((m) => m.isPublished && (m.batchId === null || activeBatchIds.has(m.batchId)));
  const goals = db.studentGoals.all(instituteId, { studentId });
  const unreadNotifications = db.notifications.all(instituteId, { userId }).filter((n) => n.readAt === null).length;

  return buildStudentHome({
    today: todayIso(),
    student,
    batches,
    subjects: db.subjects.all(instituteId),
    teachers: db.teachers.all(instituteId),
    classrooms: db.classrooms.all(instituteId),
    periods,
    attendanceRecords,
    assignments,
    submissions,
    feedback,
    exams,
    marks,
    results,
    materials,
    goals,
    unreadNotifications,
  });
}
