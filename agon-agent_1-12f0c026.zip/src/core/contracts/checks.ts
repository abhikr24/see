/**
 * Contract checks – one safe, read-only call per port.
 *
 * "Safe" means nothing is written: each check is a list, a count or a lookup
 * scoped to the given institute, so it can be pointed at a real backend.
 * `CHECKS` is keyed by PortKey, so adding a port without a check is a type error.
 */

import { isBackendError, type ErrorCode } from './errors';
import type { ID } from './models';
import { PORTS, PORT_KEYS, type Backend, type PortKey } from './ports';

/** An id that is well-formed but belongs to nothing. */
export const DUMMY_ID: ID = '00000000-0000-4000-8000-000000000000';
const TIMEOUT_MS = 8000;

export interface CheckContext {
  instituteId: ID;
}

type Shape = 'page' | 'array' | 'object' | 'object-or-null' | 'number' | 'string';

interface CheckSpec {
  method: string;
  expect: Shape;
  call: (backend: Backend, instituteId: ID) => Promise<unknown>;
}

const OTP_DUMMY_CREDENTIALS = { email: 'owner@sunrise.test', password: 'demo1234' } as const;

const CHECKS: Record<PortKey, CheckSpec> = {
  auth: { method: 'getSession', expect: 'object-or-null', call: (b, i) => b.auth.getSession(i) },
  institutes: { method: 'get', expect: 'object', call: (b, i) => b.institutes.get(i) },
  branches: { method: 'list', expect: 'page', call: (b, i) => b.branches.list(i, { limit: 1 }) },
  memberships: { method: 'list', expect: 'page', call: (b, i) => b.memberships.list(i, { limit: 1 }) },
  invitations: { method: 'list', expect: 'page', call: (b, i) => b.invitations.list(i, { limit: 1 }) },
  staff: { method: 'list', expect: 'page', call: (b, i) => b.staff.list(i, { limit: 1 }) },
  leaveRequests: { method: 'list', expect: 'page', call: (b, i) => b.leaveRequests.list(i, { limit: 1 }) },
  students: { method: 'list', expect: 'page', call: (b, i) => b.students.list(i, { limit: 1 }) },
  guardians: { method: 'list', expect: 'page', call: (b, i) => b.guardians.list(i, { limit: 1 }) },
  batches: { method: 'list', expect: 'page', call: (b, i) => b.batches.list(i, { limit: 1 }) },
  subjects: { method: 'list', expect: 'page', call: (b, i) => b.subjects.list(i, { limit: 1 }) },
  timetable: { method: 'listForDay', expect: 'array', call: (b, i) => b.timetable.listForDay(i, { dayOfWeek: 1 }) },
  attendance: { method: 'listSessions', expect: 'page', call: (b, i) => b.attendance.listSessions(i, { limit: 1 }) },
  assignments: { method: 'list', expect: 'page', call: (b, i) => b.assignments.list(i, { limit: 1 }) },
  submissions: { method: 'list', expect: 'page', call: (b, i) => b.submissions.list(i, { limit: 1 }) },
  exams: { method: 'list', expect: 'page', call: (b, i) => b.exams.list(i, { limit: 1 }) },
  marks: { method: 'list', expect: 'page', call: (b, i) => b.marks.list(i, { limit: 1 }) },
  results: { method: 'list', expect: 'page', call: (b, i) => b.results.list(i, { limit: 1 }) },
  materials: { method: 'list', expect: 'page', call: (b, i) => b.materials.list(i, { limit: 1 }) },
  practice: { method: 'listQuestions', expect: 'page', call: (b, i) => b.practice.listQuestions(i, { limit: 1 }) },
  fees: { method: 'summary', expect: 'object', call: (b, i) => b.fees.summary(i) },
  payments: { method: 'list', expect: 'page', call: (b, i) => b.payments.list(i, { limit: 1 }) },
  receipts: { method: 'list', expect: 'page', call: (b, i) => b.receipts.list(i, { limit: 1 }) },
  notices: { method: 'list', expect: 'page', call: (b, i) => b.notices.list(i, { limit: 1 }) },
  notifications: { method: 'unreadCount', expect: 'number', call: (b, i) => b.notifications.unreadCount(i) },
  doubts: { method: 'list', expect: 'page', call: (b, i) => b.doubts.list(i, { limit: 1 }) },
  meetings: { method: 'list', expect: 'page', call: (b, i) => b.meetings.list(i, { limit: 1 }) },
  leads: { method: 'list', expect: 'page', call: (b, i) => b.leads.list(i, { limit: 1 }) },
  analytics: { method: 'overview', expect: 'object', call: (b, i) => b.analytics.overview(i) },
  subscriptions: { method: 'listPlans', expect: 'array', call: (b, i) => b.subscriptions.listPlans(i) },
  exports: { method: 'list', expect: 'page', call: (b, i) => b.exports.list(i, { limit: 1 }) },
  storage: {
    method: 'listAttachments',
    expect: 'array',
    call: (b, i) => b.storage.listAttachments(i, 'notice', DUMMY_ID),
  },
  paymentGateway: { method: 'listMethods', expect: 'array', call: (b, i) => b.paymentGateway.listMethods(i) },
  realtime: { method: 'status', expect: 'string', call: (b, i) => b.realtime.status(i) },
  progress: { method: 'listAlerts', expect: 'page', call: (b, i) => b.progress.listAlerts(i, { limit: 1 }) },
};

/** Failure codes beyond a BackendError code: problems with the adapter itself. */
export type CheckCode =
  | ErrorCode
  | 'BAD_SHAPE' // resolved, but not with what the contract promises
  | 'UNTYPED_ERROR' // rejected with something other than a BackendError
  | 'NO_RESPONSE'; // neither resolved nor rejected within the time limit

export interface CheckInfo {
  port: PortKey;
  /** Interface name, e.g. "StudentRepo". */
  portName: string;
  method: string;
}

export interface CheckResult extends CheckInfo {
  status: 'pass' | 'fail';
  code: CheckCode | null;
  message: string;
  durationMs: number;
}

/**
 * OTP / Google auth methods on AuthPort — listed separately so
 * /dev/contract-check shows them even though they share the 'auth' port.
 */
const OTP_SPECS: Record<string, CheckSpec> = {
  requestOtp: { method: 'requestOtp', expect: 'object', call: (b) => b.auth.requestOtp(null, OTP_DUMMY_CREDENTIALS) },
  verifyOtp: {
    method: 'verifyOtp',
    expect: 'object',
    call: async (b, i) => {
      const c = await b.auth.requestOtp(null, OTP_DUMMY_CREDENTIALS);
      return b.auth.verifyOtp(null, { challengeId: c.challengeId, code: '123456' });
    },
  },
  resendOtp: {
    method: 'resendOtp',
    expect: 'object',
    call: async (b) => {
      const c = await b.auth.requestOtp(null, OTP_DUMMY_CREDENTIALS);
      return b.auth.resendOtp(null, c.challengeId);
    },
  },
  signInWithGoogle: { method: 'signInWithGoogle', expect: 'object', call: (b) => b.auth.signInWithGoogle(null) },
};

export const OTP_CHECK_INFOS: CheckInfo[] = Object.keys(OTP_SPECS).map((method) => ({
  port: 'auth' as PortKey,
  portName: 'AuthPort',
  method,
}));

export const CONTRACT_CHECKS: CheckInfo[] = PORT_KEYS.map((port) => ({
  port,
  portName: PORTS[port],
  method: CHECKS[port].method,
}));

// Full list including OTP for UI that wants to show them; keys are "port:method" to avoid collisions
export const ALL_CHECKS: CheckInfo[] = [...CONTRACT_CHECKS, ...OTP_CHECK_INFOS];

export const ALL_CHECK_MAP: Record<string, CheckSpec> = { ...CHECKS, ...OTP_SPECS };

const isObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/** Returns a short description when the value has the promised shape, or null when it does not. */
function describe(value: unknown, shape: Shape): string | null {
  switch (shape) {
    case 'page': {
      if (!isObject(value) || !Array.isArray(value.items)) return null;
      const cursorOk = value.nextCursor === null || typeof value.nextCursor === 'string';
      const totalOk = value.total === null || typeof value.total === 'number';
      if (!cursorOk || !totalOk) return null;
      return `page · ${value.total ?? '?'} total`;
    }
    case 'array':
      return Array.isArray(value) ? `array · ${value.length}` : null;
    case 'object':
      return isObject(value) ? 'object' : null;
    case 'object-or-null':
      return value === null ? 'null' : isObject(value) ? 'object' : null;
    case 'number':
      return typeof value === 'number' && Number.isFinite(value) ? `number · ${value}` : null;
    case 'string':
      return typeof value === 'string' ? `"${value}"` : null;
  }
}

function withTimeout<T>(work: Promise<T>): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new NoResponse()), TIMEOUT_MS);
    work.then(resolve, reject).finally(() => clearTimeout(timer));
  });
}

class NoResponse extends Error {}

export async function runCheck(backend: Backend, port: PortKey, context: CheckContext): Promise<CheckResult> {
  const spec = CHECKS[port];
  const info: CheckInfo = { port, portName: PORTS[port], method: spec.method };
  const started = Date.now();
  const done = (status: CheckResult['status'], code: CheckCode | null, message: string): CheckResult => ({
    ...info,
    status,
    code,
    message,
    durationMs: Date.now() - started,
  });

  try {
    const value = await withTimeout(Promise.resolve().then(() => spec.call(backend, context.instituteId)));
    const description = describe(value, spec.expect);
    if (description === null) return done('fail', 'BAD_SHAPE', `Expected ${spec.expect}, got ${typeof value}`);
    return done('pass', null, description);
  } catch (error) {
    if (error instanceof NoResponse) return done('fail', 'NO_RESPONSE', `No answer after ${TIMEOUT_MS / 1000}s`);
    if (isBackendError(error)) return done('fail', error.code, error.message);
    const message = error instanceof Error ? error.message : String(error);
    return done('fail', 'UNTYPED_ERROR', `Threw a non-BackendError: ${message}`);
  }
}

export async function runOtpCheck(backend: Backend, method: string, context: CheckContext): Promise<CheckResult> {
  const spec = OTP_SPECS[method];
  if (!spec) throw new Error(`Unknown OTP check ${method}`);
  const info: CheckInfo = { port: 'auth', portName: 'AuthPort', method: spec.method };
  const started = Date.now();
  const done = (status: CheckResult['status'], code: CheckCode | null, message: string): CheckResult => ({
    ...info,
    status,
    code,
    message,
    durationMs: Date.now() - started,
  });
  try {
    const value = await withTimeout(Promise.resolve().then(() => spec.call(backend, context.instituteId)));
    const description = describe(value, spec.expect);
    if (description === null) return done('fail', 'BAD_SHAPE', `Expected ${spec.expect}, got ${typeof value}`);
    return done('pass', null, description);
  } catch (error) {
    if (error instanceof NoResponse) return done('fail', 'NO_RESPONSE', `No answer after ${TIMEOUT_MS / 1000}s`);
    if (isBackendError(error)) return done('fail', error.code, error.message);
    const message = error instanceof Error ? error.message : String(error);
    return done('fail', 'UNTYPED_ERROR', `Threw a non-BackendError: ${message}`);
  }
}

/** Runs every check in port order, reporting each result as it lands. */
export async function runAllChecks(
  backend: Backend,
  context: CheckContext,
  onResult?: (result: CheckResult) => void,
): Promise<CheckResult[]> {
  const results: CheckResult[] = [];
  for (const port of PORT_KEYS) {
    const result = await runCheck(backend, port, context);
    results.push(result);
    onResult?.(result);
  }
  for (const method of Object.keys(OTP_SPECS)) {
    const result = await runOtpCheck(backend, method, context);
    results.push(result);
    onResult?.(result);
  }
  return results;
}
