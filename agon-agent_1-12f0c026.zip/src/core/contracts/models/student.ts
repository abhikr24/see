import type { ID, ISODate, ISODateTime, TimeOfDay } from './common';
import type { Material, StudentGoal } from './learning';
import type { AttendanceSummary } from './academics';

export interface StudentDueTask {
  assignmentId: ID;
  batchId: ID;
  batchName: string;
  subjectName: string | null;
  title: string;
  description: string | null;
  dueAt: ISODateTime | null;
  maxMarks: number;
  submissionStatus: 'pending' | 'submitted' | 'late' | 'returned';
  submittedAt: ISODateTime | null;
  marksAwarded: number | null;
  isDone: boolean;
}

export interface StudentTodayClass {
  id: ID;
  batchId: ID;
  batchName: string;
  subjectId: ID | null;
  subjectName: string;
  teacherId: ID | null;
  teacherName: string | null;
  roomName: string | null;
  startsAt: TimeOfDay;
  endsAt: TimeOfDay;
}

export interface StudentMaterialThumb {
  id: ID;
  title: string;
  materialType: Material['materialType'];
  subjectName: string | null;
  topic: string | null;
  description: string | null;
  url: string | null;
  createdAt: ISODateTime;
}

export interface StudentUpcomingTest {
  examId: ID;
  name: string;
  subjectName: string | null;
  startsOn: ISODate;
  daysUntil: number;
}

export interface StudentExamScore {
  examId: ID;
  examName: string;
  subjectName: string | null;
  startsOn: ISODate | null;
  marksObtained: number;
  maxMarks: number;
  percentage: number;
  isAbsent: boolean;
}

export interface StudentGoalProgress {
  id: ID;
  title: string;
  metric: StudentGoal['metric'];
  targetValue: number | null;
  currentValue: number | null;
  status: StudentGoal['status'];
  onTrack: boolean;
}

export interface StudentProgressSummary {
  attendancePercent: number | null;
  averagePercent: number | null;
  goalsOnTrack: number;
  totalGoals: number;
  attendance: AttendanceSummary;
  examScores: StudentExamScore[];
  goals: StudentGoalProgress[];
}

export interface StudentHome {
  date: ISODate;
  studentId: ID;
  studentName: string;
  photoUrl: string | null;
  classLabel: string;
  attendancePercent: number | null;
  nextTest: StudentUpcomingTest | null;
  dueToday: StudentDueTask[];
  todayClasses: StudentTodayClass[];
  newMaterials: StudentMaterialThumb[];
  progress: StudentProgressSummary;
  unreadNotifications: number;
}
