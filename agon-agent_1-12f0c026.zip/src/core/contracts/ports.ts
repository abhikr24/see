/**
 * Ports – everything the app may ask a backend to do.
 *
 * A backend is one object implementing `Backend`. The UI reaches it only
 * through the hooks in `src/core/backend.tsx`, so it never sees a table name,
 * a query builder or an SDK type. To add a backend, see docs/ADDING_A_BACKEND.md.
 */

import type { AttendanceRepo, BatchRepo, SubjectRepo, TimetableRepo } from './ports/academics';
import type { AnalyticsRepo, ExportRepo, LeadRepo, StoragePort, SubscriptionRepo } from './ports/business';
import type { DoubtRepo, MeetingRepo, NoticeRepo, NotificationRepo, RealtimePort } from './ports/communication';
import type { AssignmentRepo, ExamRepo, MarkRepo, ResultRepo, SubmissionRepo } from './ports/coursework';
import type { FeeRepo, PaymentPort, PaymentRepo, ReceiptRepo } from './ports/finance';
import type { MaterialRepo, PracticeRepo, ProgressPort } from './ports/learning';
import type { GuardianRepo, LeaveRepo, StaffRepo, StudentRepo } from './ports/people';
import type { AuthPort, BranchRepo, InstituteRepo, InvitationRepo, MembershipRepo } from './ports/tenant';

export * from './ports/common';
export * from './ports/tenant';
export * from './ports/people';
export * from './ports/academics';
export * from './ports/coursework';
export * from './ports/learning';
export * from './ports/finance';
export * from './ports/communication';
export * from './ports/business';

export interface Backend {
  /** Short id shown in dev tools, e.g. "memory", "supabase". */
  readonly name: string;
  readonly auth: AuthPort;
  readonly institutes: InstituteRepo;
  readonly branches: BranchRepo;
  readonly memberships: MembershipRepo;
  readonly invitations: InvitationRepo;
  readonly staff: StaffRepo;
  readonly leaveRequests: LeaveRepo;
  readonly students: StudentRepo;
  readonly guardians: GuardianRepo;
  readonly batches: BatchRepo;
  readonly subjects: SubjectRepo;
  readonly timetable: TimetableRepo;
  readonly attendance: AttendanceRepo;
  readonly assignments: AssignmentRepo;
  readonly submissions: SubmissionRepo;
  readonly exams: ExamRepo;
  readonly marks: MarkRepo;
  readonly results: ResultRepo;
  readonly materials: MaterialRepo;
  readonly practice: PracticeRepo;
  readonly fees: FeeRepo;
  readonly payments: PaymentRepo;
  readonly receipts: ReceiptRepo;
  readonly notices: NoticeRepo;
  readonly notifications: NotificationRepo;
  readonly doubts: DoubtRepo;
  readonly meetings: MeetingRepo;
  readonly leads: LeadRepo;
  readonly analytics: AnalyticsRepo;
  readonly subscriptions: SubscriptionRepo;
  readonly exports: ExportRepo;
  readonly storage: StoragePort;
  readonly paymentGateway: PaymentPort;
  readonly realtime: RealtimePort;
  readonly progress: ProgressPort;
}

export type PortKey = Exclude<keyof Backend, 'name'>;

/** Backend key → port interface name. Adding a port to `Backend` without listing it here is a type error. */
export const PORTS: Record<PortKey, string> = {
  auth: 'AuthPort',
  institutes: 'InstituteRepo',
  branches: 'BranchRepo',
  memberships: 'MembershipRepo',
  invitations: 'InvitationRepo',
  staff: 'StaffRepo',
  leaveRequests: 'LeaveRepo',
  students: 'StudentRepo',
  guardians: 'GuardianRepo',
  batches: 'BatchRepo',
  subjects: 'SubjectRepo',
  timetable: 'TimetableRepo',
  attendance: 'AttendanceRepo',
  assignments: 'AssignmentRepo',
  submissions: 'SubmissionRepo',
  exams: 'ExamRepo',
  marks: 'MarkRepo',
  results: 'ResultRepo',
  materials: 'MaterialRepo',
  practice: 'PracticeRepo',
  fees: 'FeeRepo',
  payments: 'PaymentRepo',
  receipts: 'ReceiptRepo',
  notices: 'NoticeRepo',
  notifications: 'NotificationRepo',
  doubts: 'DoubtRepo',
  meetings: 'MeetingRepo',
  leads: 'LeadRepo',
  analytics: 'AnalyticsRepo',
  subscriptions: 'SubscriptionRepo',
  exports: 'ExportRepo',
  storage: 'StoragePort',
  paymentGateway: 'PaymentPort',
  realtime: 'RealtimePort',
  progress: 'ProgressPort',
};

export const PORT_KEYS = Object.keys(PORTS) as PortKey[];
