import type {
  Guardian,
  ID,
  ISODate,
  LeaveRequest,
  LeaveType,
  ParentLink,
  StaffRecord,
  Student,
  StudentMembership,
  Teacher,
  Upsert,
  Workload,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo, ReadRepo } from './common';

export interface StaffRepo extends CrudRepo<StaffRecord> {
  listTeachers(instituteId: ID, query?: ListQuery<Teacher>): Promise<Page<Teacher>>;
  saveTeacher(instituteId: ID, input: Upsert<Teacher, 'fullName'>): Promise<Teacher>;
  listWorkloads(instituteId: ID, filter?: { teacherId?: ID; weekStart?: ISODate }): Promise<Workload[]>;
  saveWorkload(instituteId: ID, input: Upsert<Workload, 'teacherId' | 'weekStart'>): Promise<Workload>;
}

export type SubmitLeaveInput = {
  leaveType: LeaveType;
  fromDate: ISODate;
  toDate: ISODate;
  reason: string;
};

export interface LeaveRepo extends ReadRepo<LeaveRequest> {
  /** Submits a request for the signed-in teacher and puts it in the owner's queue. */
  submit(instituteId: ID, input: SubmitLeaveInput): Promise<LeaveRequest>;
  /** The signed-in teacher's own leave history, newest first. */
  listMine(instituteId: ID): Promise<LeaveRequest[]>;
  /** Pending staff leave. Owner-only; teachers are refused. */
  listPending(instituteId: ID): Promise<LeaveRequest[]>;
  /** Owner's decision. A reviewer can never decide their own request. */
  decide(
    instituteId: ID,
    id: ID,
    status: 'approved' | 'rejected',
    note?: string | null,
  ): Promise<LeaveRequest>;
}

export interface StudentRepo extends CrudRepo<Student, 'fullName'> {
  /** Students currently enrolled in the batch, by roll number. */
  listByBatch(instituteId: ID, batchId: ID): Promise<Student[]>;
  /** The caller's own student record (student) or their children (parent). */
  listMine(instituteId: ID): Promise<Student[]>;
  getLogin(instituteId: ID, studentId: ID): Promise<StudentMembership | null>;
  /** Attach a student-role membership to the student record. */
  linkLogin(instituteId: ID, studentId: ID, membershipId: ID): Promise<StudentMembership>;
  unlinkLogin(instituteId: ID, studentId: ID): Promise<void>;
}

export interface GuardianRepo extends CrudRepo<Guardian, 'fullName'> {
  listForStudent(instituteId: ID, studentId: ID): Promise<Guardian[]>;
  listLinks(instituteId: ID, filter?: { studentId?: ID; guardianId?: ID }): Promise<ParentLink[]>;
  link(instituteId: ID, input: { studentId: ID; guardianId: ID; isPrimary?: boolean }): Promise<ParentLink>;
  unlink(instituteId: ID, linkId: ID): Promise<void>;
}
