/**
 * Pure student-home builder shared by both adapters (memory and Supabase).
 * Zero database or React dependencies.
 */
import { HOMEWORK_DEFAULT_MAX_MARKS, isSubmittedStatus } from './homework';
import type {
  Assignment, AttendanceRecord, AttendanceSummary, Batch, Classroom, Exam, Feedback,
  ID, ISODate, Mark, Material, Result, Student, StudentDueTask, StudentExamScore,
  StudentGoal, StudentGoalProgress, StudentHome, StudentMaterialThumb, StudentTodayClass,
  StudentUpcomingTest, Subject, Submission, Teacher, Timetable,
} from './models';

const round1 = (n: number): number => Math.round(n * 10) / 10;
const round2 = (n: number): number => Math.round(n * 100) / 100;

export function daysBetweenIso(from: ISODate, to: ISODate): number {
  const [fy, fm, fd] = from.split('-').map(Number);
  const [ty, tm, td] = to.split('-').map(Number);
  return Math.round((Date.UTC(ty, tm - 1, td) - Date.UTC(fy, fm - 1, fd)) / 86400000);
}

export function summarizeAttendance(records: readonly AttendanceRecord[]): AttendanceSummary {
  let present = 0;
  let late = 0;
  let absent = 0;
  let leave = 0;
  for (const r of records) {
    if (r.status === 'present') present += 1;
    else if (r.status === 'late') late += 1;
    else if (r.status === 'absent') absent += 1;
    else if (r.status === 'leave') leave += 1;
  }
  const total = records.length;
  return { total, present, late, absent, leave, percent: total > 0 ? round1(((present + late) / total) * 100) : 0 };
}

export function isGoalOnTrack(
  goal: StudentGoal,
  attendancePercent: number | null,
  averagePercent: number | null,
): boolean {
  if (goal.status === 'achieved') return true;
  if (goal.status !== 'active') return false;
  if (goal.metric === 'attendance_percent' && goal.targetValue !== null && attendancePercent !== null) {
    return attendancePercent >= goal.targetValue * 0.9;
  }
  if (goal.metric === 'exam_percent' && goal.targetValue !== null && averagePercent !== null) {
    return averagePercent >= goal.targetValue * 0.9;
  }
  if (goal.targetValue !== null && goal.currentValue !== null) {
    return goal.currentValue >= goal.targetValue * 0.75;
  }
  return true;
}

export interface StudentHomeInput {
  today: ISODate;
  student: Student;
  batches: Batch[];
  subjects: Subject[];
  teachers: Teacher[];
  classrooms: Classroom[];
  periods: Timetable[];
  attendanceRecords: AttendanceRecord[];
  assignments: Assignment[];
  submissions: Submission[];
  feedback: Feedback[];
  exams: Exam[];
  marks: Mark[];
  results: Result[];
  materials: Material[];
  goals: StudentGoal[];
  unreadNotifications: number;
}

export function buildStudentHome(input: StudentHomeInput): StudentHome {
  const { today, student, batches } = input;
  const batchMap = new Map(batches.map((b) => [b.id, b]));
  const subjectMap = new Map(input.subjects.map((s) => [s.id, s.name]));
  const teacherMap = new Map(input.teachers.map((t) => [t.id, t.fullName]));
  const roomMap = new Map(input.classrooms.map((c) => [c.id, c.name]));

  const classLabel = batches.map((b) => b.name).join(' · ') || (student.classGrade ? `Class ${student.classGrade}` : 'Student');
  const attendance = summarizeAttendance(input.attendanceRecords);
  const attendancePercent = attendance.total > 0 ? attendance.percent : null;

  const upcomingExams = input.exams
    .filter((e) => batchMap.has(e.batchId) && e.startsOn !== null && e.startsOn >= today && (e.status === 'scheduled' || e.status === 'ongoing'))
    .sort((a, b) => (a.startsOn ?? '').localeCompare(b.startsOn ?? ''));
  const nextExam = upcomingExams[0] ?? null;
  const nextTest: StudentUpcomingTest | null = nextExam && nextExam.startsOn
    ? {
        examId: nextExam.id,
        name: nextExam.name,
        subjectName: nextExam.subjectId ? (subjectMap.get(nextExam.subjectId) ?? null) : null,
        startsOn: nextExam.startsOn,
        daysUntil: Math.max(0, daysBetweenIso(today, nextExam.startsOn)),
      }
    : null;

  const subByAssignment = new Map(input.submissions.map((s) => [s.assignmentId, s]));
  const fbBySubmission = new Map(input.feedback.map((f) => [f.submissionId, f]));

  const dueToday: StudentDueTask[] = input.assignments
    .filter((a) => {
      if (!batchMap.has(a.batchId) || a.status === 'draft' || a.dueAt?.slice(0, 10) !== today) return false;
      const sub = subByAssignment.get(a.id);
      return !(a.status === 'closed' && (!sub || !isSubmittedStatus(sub.status)));
    })
    .map((a): StudentDueTask => {
      const sub = subByAssignment.get(a.id) ?? null;
      const fb = sub ? (fbBySubmission.get(sub.id) ?? null) : null;
      const submissionStatus = sub?.status ?? 'pending';
      return {
        assignmentId: a.id,
        batchId: a.batchId,
        batchName: batchMap.get(a.batchId)?.name ?? 'Class',
        subjectName: a.subjectId ? (subjectMap.get(a.subjectId) ?? null) : null,
        title: a.title,
        description: a.instructions,
        dueAt: a.dueAt,
        maxMarks: a.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS,
        submissionStatus,
        submittedAt: sub?.submittedAt ?? null,
        marksAwarded: fb?.marksAwarded ?? null,
        isDone: isSubmittedStatus(submissionStatus),
      };
    })
    .sort((a, b) => Number(b.isDone) - Number(a.isDone) || (a.dueAt ?? '').localeCompare(b.dueAt ?? '') || a.title.localeCompare(b.title));

  const todayDow = new Date(`${today}T00:00:00Z`).getUTCDay();
  const inForce = (p: Timetable) => (!p.validFrom || p.validFrom <= today) && (!p.validTo || p.validTo >= today);
  const todayClasses: StudentTodayClass[] = input.periods
    .filter((p) => batchMap.has(p.batchId) && p.dayOfWeek === todayDow && inForce(p))
    .sort((a, b) => a.startsAt.localeCompare(b.startsAt))
    .map((p) => ({
      id: p.id,
      batchId: p.batchId,
      batchName: batchMap.get(p.batchId)?.name ?? 'Class',
      subjectId: p.subjectId,
      subjectName: (p.subjectId ? subjectMap.get(p.subjectId) : null) ?? 'General',
      teacherId: p.teacherId,
      teacherName: p.teacherId ? (teacherMap.get(p.teacherId) ?? null) : null,
      roomName: p.classroomId ? (roomMap.get(p.classroomId) ?? null) : null,
      startsAt: p.startsAt,
      endsAt: p.endsAt,
    }));

  const newMaterials: StudentMaterialThumb[] = input.materials
    .filter((m) => m.isPublished && (m.batchId === null || batchMap.has(m.batchId)))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 10)
    .map((m) => ({
      id: m.id,
      title: m.title,
      materialType: m.materialType,
      subjectName: m.subjectId ? (subjectMap.get(m.subjectId) ?? null) : null,
      topic: m.topic,
      description: m.description,
      url: m.url,
      createdAt: m.createdAt,
    }));

  const publishedExams = input.exams
    .filter((e) => batchMap.has(e.batchId) && e.status === 'published')
    .sort((a, b) => (b.startsOn ?? b.createdAt).localeCompare(a.startsOn ?? a.createdAt));

  const marksByExam = new Map<ID, Mark[]>();
  for (const m of input.marks) {
    if (m.studentId !== student.id) continue;
    const list = marksByExam.get(m.examId) ?? [];
    list.push(m);
    marksByExam.set(m.examId, list);
  }
  const resultByExam = new Map(input.results.filter((r) => r.studentId === student.id).map((r) => [r.examId, r]));

  const examScores: StudentExamScore[] = [];
  for (const exam of publishedExams) {
    const ownMarks = marksByExam.get(exam.id) ?? [];
    const res = resultByExam.get(exam.id);
    const subjectName = exam.subjectId ? (subjectMap.get(exam.subjectId) ?? null) : null;
    if (ownMarks.length > 0) {
      const scoredRows = ownMarks.filter((m) => m.marksObtained !== null || m.isAbsent);
      if (scoredRows.length === 0 && !res) continue;
      const isAbsent = scoredRows.length > 0 && scoredRows.every((m) => m.isAbsent);
      const obtained = scoredRows.reduce((sum, m) => sum + (m.marksObtained ?? 0), 0);
      const max = scoredRows.reduce((sum, m) => sum + m.maxMarks, 0);
      examScores.push({
        examId: exam.id,
        examName: exam.name,
        subjectName,
        startsOn: exam.startsOn,
        marksObtained: obtained,
        maxMarks: max,
        percentage: max > 0 ? round2((obtained / max) * 100) : 0,
        isAbsent,
      });
    } else if (res) {
      examScores.push({
        examId: exam.id,
        examName: exam.name,
        subjectName,
        startsOn: exam.startsOn,
        marksObtained: res.totalObtained,
        maxMarks: res.totalMax,
        percentage: res.percentage,
        isAbsent: res.status === 'absent',
      });
    }
  }

  const scoredExams = examScores.filter((e) => !e.isAbsent && e.maxMarks > 0);
  const averagePercent = scoredExams.length
    ? round1(scoredExams.reduce((sum, e) => sum + e.percentage, 0) / scoredExams.length)
    : null;

  const goals: StudentGoalProgress[] = input.goals.map((g) => {
    const currentValue =
      g.metric === 'attendance_percent' && attendancePercent !== null
        ? attendancePercent
        : g.metric === 'exam_percent' && averagePercent !== null
          ? averagePercent
          : g.currentValue;
    return {
      id: g.id,
      title: g.title,
      metric: g.metric,
      targetValue: g.targetValue,
      currentValue,
      status: g.status,
      onTrack: isGoalOnTrack({ ...g, currentValue }, attendancePercent, averagePercent),
    };
  });
  const goalsOnTrack = goals.filter((g) => g.onTrack).length;

  return {
    date: today,
    studentId: student.id,
    studentName: student.fullName,
    photoUrl: student.photoUrl,
    classLabel,
    attendancePercent,
    nextTest,
    dueToday,
    todayClasses,
    newMaterials,
    progress: {
      attendancePercent,
      averagePercent,
      goalsOnTrack,
      totalGoals: goals.length,
      attendance,
      examScores,
      goals,
    },
    unreadNotifications: input.unreadNotifications,
  };
}
