import { useCallback } from 'react';

import { toBackendError } from '../contracts/errors';
import type {
  AdmissionLead,
  AdmissionsPipeline,
  Attachment,
  AttachmentOwner,
  AuditLog,
  BillingCycle,
  ConvertLeadInput,
  ConvertLeadResult,
  DateRange,
  ExportJob,
  ID,
  LeadDetail,
  LeadFollowup,
  LeadStage,
  Subscription,
} from '../contracts/models';
import type { AddFollowupInput, ExportRequest, UploadInput } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { useBackend } from './context';
import { dropItem, patchItem, useCrud, useDomainMutation, useDomainQuery, useListEditor } from './domain';
import { toast } from './toast';

const ADMISSION_CONVERT_SCOPES = ['leads', 'students', 'batches', 'fees', 'guardians', 'analytics', 'progress'];

/** LeadRepo · the admission pipeline. */
export function useLeads(query?: ListQuery<AdmissionLead>) {
  const leads = useCrud<AdmissionLead, 'studentName'>('leads', 'Enquiry', (b) => b.leads, query);
  const edit = useListEditor<AdmissionLead>('leads', ['list', query ?? null]);

  const moveStage = useDomainMutation<{ id: ID; stage: LeadStage; lostReason?: string | null }, AdmissionLead>(
    ['leads', 'analytics'],
    (b, i, { id, stage, lostReason }) => b.leads.moveStage(i, id, stage, lostReason),
    { success: 'Stage updated', failure: 'Could not move the lead' },
    ({ id, stage }) => edit(patchItem<AdmissionLead>(id, { stage })),
  );
  const addFollowup = useDomainMutation<AddFollowupInput, LeadFollowup>(
    ['leads', 'analytics'],
    (b, i, input) => b.leads.addFollowup(i, input),
    { success: 'Follow-up logged', failure: 'Could not log the follow-up' },
  );
  const convert = useDomainMutation<ConvertLeadInput, ConvertLeadResult>(
    ADMISSION_CONVERT_SCOPES,
    (b, i, input) => b.leads.convert(i, input),
    {
      success: (res) => `${res.student.fullName} admitted`,
      failure: 'Could not convert the lead',
    },
  );
  return {
    ...leads,
    moveStage: moveStage.mutate,
    addFollowup: addFollowup.mutate,
    convert: convert.mutate,
    saving: leads.saving || moveStage.loading || addFollowup.loading || convert.loading,
  };
}

/** LeadRepo · admissions list + summary + assignees in one read. */
export function useAdmissionsPipeline() {
  return useDomainQuery<AdmissionsPipeline>('leads', ['pipeline'], (b, i) => b.leads.pipeline(i));
}

/** LeadRepo · lead + followups + stage history in one read. Off while `leadId` is null. */
export function useLeadDetail(leadId: ID | null) {
  return useDomainQuery<LeadDetail>(
    'leads',
    ['detail', leadId],
    (b, i) => b.leads.detail(i, leadId as ID),
    leadId !== null,
  );
}

/** LeadRepo · the call and visit history of one lead. Off while `leadId` is null. */
export function useLeadFollowups(leadId: ID | null) {
  return useDomainQuery<LeadFollowup[]>(
    'leads',
    ['followups', leadId],
    (b, i) => b.leads.listFollowups(i, leadId as ID),
    leadId !== null,
  );
}

/** AnalyticsRepo · the headline numbers for the dashboard. */
export function useAnalytics() {
  return useDomainQuery('analytics', ['overview'], (b, i) => b.analytics.overview(i));
}

/** AnalyticsRepo · the owner's home screen: one call, one loading state. */
export function useOwnerDashboard() {
  return useDomainQuery('analytics', ['dashboard'], (b, i) => b.analytics.dashboard(i));
}

/** AnalyticsRepo · the teacher's home screen: one call, one loading state. */
export function useTeacherHome() {
  return useDomainQuery('analytics', ['teacher-home'], (b, i) => b.analytics.teacherHome(i));
}

/** AnalyticsRepo · the student's home screen: one call, one loading state. */
export function useStudentHome() {
  return useDomainQuery('analytics', ['student-home'], (b, i) => b.analytics.studentHome(i));
}

/** AnalyticsRepo · attendance %, money collected per day, and the lead funnel. */
export function useTrends(range: DateRange) {
  return useDomainQuery('analytics', ['trends', range], async (b, i) => {
    const [attendance, collection, funnel] = await Promise.all([
      b.analytics.attendanceTrend(i, range),
      b.analytics.feeCollection(i, range),
      b.analytics.leadFunnel(i),
    ]);
    return { attendance, collection, funnel };
  });
}

/** AnalyticsRepo · who did what, newest first. */
export function useAuditLog(query?: ListQuery<AuditLog>) {
  return useDomainQuery('analytics', ['audit', query ?? null], (b, i) => b.analytics.listAuditLogs(i, query));
}

/** SubscriptionRepo · the institute's plan, the plans on offer, and usage against limits. */
export function useSubscription() {
  const billing = useDomainQuery('subscription', null, async (b, i) => {
    const [subscription, plans, usage] = await Promise.all([
      b.subscriptions.getCurrent(i),
      b.subscriptions.listPlans(i),
      b.subscriptions.listUsage(i),
    ]);
    const plan = plans.find((p) => p.id === subscription?.planId) ?? null;
    return { subscription, plan, plans, usage };
  });
  const changePlan = useDomainMutation<{ planId: ID; billingCycle: BillingCycle }, Subscription>(
    'subscription',
    (b, i, { planId, billingCycle }) => b.subscriptions.changePlan(i, planId, billingCycle),
    { success: 'Plan changed', failure: 'Could not change the plan' },
  );
  const cancel = useDomainMutation<void, Subscription>(
    'subscription',
    (b, i) => b.subscriptions.cancel(i),
    { success: 'Subscription cancelled', failure: 'Could not cancel the subscription' },
  );
  return { ...billing, changePlan: changePlan.mutate, cancel: cancel.mutate, saving: changePlan.loading || cancel.loading };
}

/** ExportRepo · past exports and starting a new one. */
export function useExports(query?: ListQuery<ExportJob>) {
  const jobs = useDomainQuery('exports', ['list', query ?? null], (b, i) => b.exports.list(i, query));
  const start = useDomainMutation<ExportRequest, ExportJob>(
    'exports',
    (b, i, request) => b.exports.start(i, request),
    {
      success: (job) => (job.status === 'completed' ? 'Export ready' : 'Export started'),
      failure: 'Could not start the export',
    },
  );
  return { ...jobs, start: start.mutate, starting: start.loading };
}

/** StoragePort · the files attached to one record. Off while `ownerId` is null. */
export function useAttachments(ownerType: AttachmentOwner, ownerId: ID | null) {
  const { backend, instituteId } = useBackend();
  const args = [ownerType, ownerId];
  const files = useDomainQuery<Attachment[]>(
    'attachments',
    args,
    (b, i) => b.storage.listAttachments(i, ownerType, ownerId as ID),
    ownerId !== null,
  );
  const edit = useListEditor<Attachment>('attachments', args);

  const upload = useDomainMutation<Omit<UploadInput, 'ownerType' | 'ownerId'>, Attachment>(
    'attachments',
    (b, i, file) => b.storage.upload(i, { ...file, ownerType, ownerId: ownerId ?? '' }),
    { success: 'File uploaded', failure: 'Could not upload the file' },
  );
  const remove = useDomainMutation<ID, void>(
    'attachments',
    (b, i, attachmentId) => b.storage.remove(i, attachmentId),
    { success: 'File removed', failure: 'Could not remove the file' },
    (attachmentId) => edit(dropItem<Attachment>(attachmentId)),
  );
  /** Resolves a file to a URL the app can open, or null (with a toast) if it cannot. Never cached: links expire. */
  const openUrl = useCallback(
    async (file: Attachment): Promise<string | null> => {
      try {
        return await backend.storage.getUrl(instituteId ?? '', file.storagePath);
      } catch (cause) {
        toast.error(`Could not open ${file.fileName}. ${toBackendError(cause).message}`);
        return null;
      }
    },
    [backend, instituteId],
  );

  return { ...files, upload: upload.mutate, remove: remove.mutate, openUrl, saving: upload.loading || remove.loading };
}
