import { useEffect, useRef } from 'react';

import type {
  AppNotification,
  Conversation,
  Doubt,
  DoubtStatus,
  ID,
  MeetingRequest,
  NewEntity,
  Notice,
  RealtimeEvent,
  RealtimeTopic,
} from '../contracts/models';
import type { MeetingResponse, RealtimeSubscription } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { queryCache, queryScope } from './cache';
import { useBackend } from './context';
import { patchItem, useCrud, useDomainMutation, useDomainQuery, useListEditor } from './domain';

/** NoticeRepo */
export function useNotices(query?: ListQuery<Notice>) {
  const notices = useCrud<Notice, 'title'>('notices', 'Notice', (b) => b.notices, query);
  const edit = useListEditor<Notice>('notices', ['list', query ?? null]);
  const publish = useDomainMutation<ID, Notice>(
    'notices',
    (b, i, id) => b.notices.publish(i, id),
    { success: 'Notice published', failure: 'Could not publish the notice' },
    (id) => edit(patchItem<Notice>(id, { publishedAt: new Date().toISOString() })),
  );
  const setPinned = useDomainMutation<{ id: ID; pinned: boolean }, Notice>(
    'notices',
    (b, i, { id, pinned }) => b.notices.setPinned(i, id, pinned),
    { failure: 'Could not pin the notice' },
    ({ id, pinned }) => edit(patchItem<Notice>(id, { isPinned: pinned })),
  );
  return {
    ...notices,
    publish: publish.mutate,
    setPinned: setPinned.mutate,
    saving: notices.saving || publish.loading || setPinned.loading,
  };
}

/** NotificationRepo · the signed-in person's inbox. `unread` counts what is loaded and unread. */
export function useNotifications(query?: ListQuery<AppNotification>) {
  const args = ['list', query ?? null];
  const inbox = useDomainQuery('notifications', args, (b, i) => b.notifications.list(i, query));
  const edit = useListEditor<AppNotification>('notifications', args);
  const now = () => new Date().toISOString();

  const markRead = useDomainMutation<ID, AppNotification>(
    ['notifications', 'analytics'],
    (b, i, id) => b.notifications.markRead(i, id),
    { failure: 'Could not mark the notification as read' },
    (id) => edit(patchItem<AppNotification>(id, { readAt: now() })),
  );
  const markAllRead = useDomainMutation<void, number>(
    ['notifications', 'analytics'],
    (b, i) => b.notifications.markAllRead(i),
    { failure: 'Could not mark notifications as read' },
    () => edit((items) => items.map((n) => (n.readAt ? n : { ...n, readAt: now() }))),
  );
  return {
    ...inbox,
    unread: inbox.data?.items.filter((n) => n.readAt === null).length ?? 0,
    markRead: markRead.mutate,
    markAllRead: markAllRead.mutate,
  };
}

/** DoubtRepo */
export function useDoubts(query?: ListQuery<Doubt>) {
  const args = ['list', query ?? null];
  const doubts = useDomainQuery('doubts', args, (b, i) => b.doubts.list(i, query));
  const edit = useListEditor<Doubt>('doubts', args);

  const ask = useDomainMutation<NewEntity<Doubt, 'batchId' | 'studentId' | 'question'>, Doubt>(
    ['doubts', 'progress'],
    (b, i, input) => b.doubts.ask(i, input),
    { success: 'Question sent to your teacher', failure: 'Could not send your question' },
  );
  const answer = useDomainMutation<{ id: ID; answer: string }, Doubt>(
    ['doubts', 'progress'],
    (b, i, input) => b.doubts.answer(i, input.id, input.answer),
    { success: 'Answer sent', failure: 'Could not send the answer' },
    (input) => edit(patchItem<Doubt>(input.id, { answer: input.answer, status: 'answered' })),
  );
  const setStatus = useDomainMutation<{ id: ID; status: DoubtStatus }, Doubt>(
    ['doubts', 'progress'],
    (b, i, { id, status }) => b.doubts.setStatus(i, id, status),
    { failure: 'Could not update the question' },
    ({ id, status }) => edit(patchItem<Doubt>(id, { status })),
  );
  return {
    ...doubts,
    ask: ask.mutate,
    answer: answer.mutate,
    setStatus: setStatus.mutate,
    saving: ask.loading || answer.loading || setStatus.loading,
  };
}

/** MeetingRepo · parent–teacher meeting requests. */
export function useMeetings(query?: ListQuery<MeetingRequest>) {
  const args = ['list', query ?? null];
  const meetings = useDomainQuery('meetings', args, (b, i) => b.meetings.list(i, query));
  const edit = useListEditor<MeetingRequest>('meetings', args);

  const request = useDomainMutation<NewEntity<MeetingRequest, 'studentId' | 'teacherId'>, MeetingRequest>(
    'meetings',
    (b, i, input) => b.meetings.request(i, input),
    { success: 'Meeting requested', failure: 'Could not request the meeting' },
  );
  const respond = useDomainMutation<{ id: ID } & MeetingResponse, MeetingRequest>(
    'meetings',
    (b, i, { id, ...response }) => b.meetings.respond(i, id, response),
    { success: (m) => `Meeting ${m.status}`, failure: 'Could not update the meeting' },
    ({ id, status }) => edit(patchItem<MeetingRequest>(id, { status })),
  );
  return { ...meetings, request: request.mutate, respond: respond.mutate, saving: request.loading || respond.loading };
}

/** MeetingRepo · the signed-in person's message threads. */
export function useConversations(query?: ListQuery<Conversation>) {
  const threads = useDomainQuery('conversations', ['list', query ?? null], (b, i) =>
    b.meetings.listConversations(i, query),
  );
  const start = useDomainMutation<NewEntity<Conversation, 'participantIds'>, Conversation>(
    'conversations',
    (b, i, input) => b.meetings.startConversation(i, input),
    { failure: 'Could not start the conversation' },
  );
  const send = useDomainMutation<{ conversationId: ID; body: string }, Conversation>(
    'conversations',
    (b, i, { conversationId, body }) => b.meetings.sendMessage(i, conversationId, body),
    { failure: 'Message not sent' },
  );
  return { ...threads, start: start.mutate, send: send.mutate, sending: start.loading || send.loading };
}

/** Which hook cache a realtime topic makes stale. */
const TOPIC_DOMAIN: Record<RealtimeTopic, string> = {
  memberships: 'memberships',
  attendance: 'attendance',
  notices: 'notices',
  notifications: 'notifications',
  doubts: 'doubts',
  leave_requests: 'leaveRequests',
  conversations: 'conversations',
  payments: 'payments',
};

/**
 * RealtimePort · while mounted, keeps the matching hook's data live: each
 * event reloads that domain. `data` is the connection status.
 */
export function useRealtime(topic: RealtimeTopic, onEvent?: (event: RealtimeEvent) => void) {
  const { backend, instituteId } = useBackend();
  const status = useDomainQuery('realtime', ['status'], (b, i) => b.realtime.status(i));
  const handler = useRef(onEvent);
  handler.current = onEvent;

  useEffect(() => {
    if (!instituteId) return;
    let active = true;
    let subscription: RealtimeSubscription | null = null;
    backend.realtime
      .subscribe(instituteId, topic, (event) => {
        void queryCache.invalidate([queryScope(backend.name, TOPIC_DOMAIN[topic], instituteId)]);
        handler.current?.(event);
      })
      .then((opened) => {
        if (active) subscription = opened;
        else opened.unsubscribe().catch(() => {});
      })
      .catch(() => {
        // The status query above already reports that realtime is unavailable.
      });
    return () => {
      active = false;
      subscription?.unsubscribe().catch(() => {});
    };
  }, [backend, instituteId, topic]);

  return status;
}
