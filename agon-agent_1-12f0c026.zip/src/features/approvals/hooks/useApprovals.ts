import { useCallback, useEffect, useMemo, useState } from 'react';
import { useBackend, useDecideLeave, usePendingLeaveRequests } from '@/core/backend';
import type { LeaveRequest, Membership, Profile } from '@/core/contracts/models';
import { queryCache, queryKey, queryScope } from '@/core/hooks/cache';
import { toast } from '@/core/hooks/toast';
import { useDomainQuery } from '@/core/hooks/domain';

export interface EnrichedRequest {
  membership: Membership;
  profile: Profile | null;
  isDuplicatePhone: boolean;
}

export interface EnrichedLeaveRequest {
  request: LeaveRequest;
  profile: Profile | null;
}

/**
 * Approvals queue hook: list pending, enrich with profile, duplicate-phone detection,
 * optimistic approve/reject with rollback and toast, approve-all.
 */
export function useApprovals() {
  const { backend, instituteId } = useBackend();
  const listKey = queryKey(backend.name, 'memberships', instituteId, ['list', { where: { status: 'pending' } }]);
  const pendingQuery = useDomainQuery('memberships', ['list', { where: { status: 'pending' } }], (b, i) => b.memberships.list(i, { where: { status: 'pending' } } as never));
  const leavePending = usePendingLeaveRequests();
  const leaveDecision = useDecideLeave();
  const [profiles, setProfiles] = useState<Record<string, Profile | null>>({});
  const [leaveProfiles, setLeaveProfiles] = useState<Record<string, Profile | null>>({});
  const items = (pendingQuery.data?.items as Membership[] | undefined) ?? [];
  const leaveItems = leavePending.data ?? [];

  // Fetch profiles for duplicate phone check
  useEffect(() => {
    if (!instituteId || items.length === 0) {
      setProfiles({});
      return;
    }
    let cancelled = false;
    (async () => {
      const map: Record<string, Profile | null> = {};
      await Promise.all(
        items.map(async (m) => {
          try {
            const p = await backend.auth.getProfile(instituteId, m.userId);
            if (!cancelled) map[m.userId] = p;
          } catch {
            if (!cancelled) map[m.userId] = null;
          }
        }),
      );
      if (!cancelled) setProfiles(map);
    })();
    return () => {
      cancelled = true;
    };
  }, [backend, instituteId, items]);

  useEffect(() => {
    if (!instituteId || leaveItems.length === 0) {
      setLeaveProfiles({});
      return;
    }
    let cancelled = false;
    void Promise.all(
      leaveItems.map(async (request) => {
        try {
          const profile = await backend.auth.getProfile(instituteId, request.userId);
          if (!cancelled) setLeaveProfiles((current) => ({ ...current, [request.userId]: profile }));
        } catch {
          if (!cancelled) setLeaveProfiles((current) => ({ ...current, [request.userId]: null }));
        }
      }),
    );
    return () => {
      cancelled = true;
    };
  }, [backend, instituteId, leaveItems]);

  const enriched: EnrichedRequest[] = useMemo(() => {
    const phoneCounts: Record<string, number> = {};
    items.forEach((m) => {
      const phone = profiles[m.userId]?.phone?.trim();
      if (phone) phoneCounts[phone] = (phoneCounts[phone] ?? 0) + 1;
    });
    return items.map((m) => {
      const phone = profiles[m.userId]?.phone?.trim() ?? null;
      return {
        membership: m,
        profile: profiles[m.userId] ?? null,
        isDuplicatePhone: !!(phone && phoneCounts[phone] > 1),
      };
    });
  }, [items, profiles]);

  const decide = useCallback(
    async (id: string, status: 'active' | 'rejected') => {
      if (!instituteId) return { ok: false };
      const scope = queryScope(backend.name, 'memberships', instituteId);
      const snapshot = queryCache.snapshot([scope]);
      // optimistic: patch status in cached page
      queryCache.update<{ items: Membership[]; total: number | null; nextCursor: string | null }>(listKey, (current) => {
        if (!current) return current;
        return {
          ...current,
          items: current.items.map((m) => (m.id === id ? { ...m, status } : m)),
        };
      });
      try {
        const res = await backend.memberships.decide(instituteId, id, status);
        toast.success(status === 'active' ? 'Member approved' : 'Request rejected');
        // Invalidate to reload and ensure no duplicate membership created; approve twice stays idempotent
        await queryCache.invalidate([scope]);
        return { ok: true, data: res };
      } catch (e: unknown) {
        queryCache.restore(snapshot);
        const msg = e instanceof Error ? e.message : 'Could not update request';
        toast.error(msg);
        return { ok: false, error: e };
      }
    },
    [backend, instituteId, listKey],
  );

  const enrichedLeave: EnrichedLeaveRequest[] = useMemo(
    () => leaveItems.map((request) => ({ request, profile: leaveProfiles[request.userId] ?? null })),
    [leaveItems, leaveProfiles],
  );

  const approve = useCallback((id: string) => decide(id, 'active'), [decide]);
  const reject = useCallback((id: string) => decide(id, 'rejected'), [decide]);

  const approveAll = useCallback(async () => {
    if (!instituteId || enriched.length === 0) return;
    const scope = queryScope(backend.name, 'memberships', instituteId);
    const snapshot = queryCache.snapshot([scope]);
    queryCache.update<{ items: Membership[]; total: number | null; nextCursor: string | null }>(listKey, (current) => {
      if (!current) return current;
      return { ...current, items: current.items.map((m) => ({ ...m, status: 'active' as const })) };
    });
    try {
      await Promise.all(enriched.map((e) => backend.memberships.decide(instituteId, e.membership.id, 'active')));
      toast.success(`Approved ${enriched.length} members`);
      await queryCache.invalidate([scope]);
    } catch (e: unknown) {
      queryCache.restore(snapshot);
      const msg = e instanceof Error ? e.message : 'Could not approve all';
      toast.error(msg);
    }
  }, [backend, instituteId, enriched, listKey]);

  const approveLeave = useCallback(
    (id: string) => leaveDecision.mutate({ id, status: 'approved' }),
    [leaveDecision],
  );
  const rejectLeave = useCallback(
    (id: string) => leaveDecision.mutate({ id, status: 'rejected' }),
    [leaveDecision],
  );

  return {
    pending: pendingQuery,
    items: enriched,
    leaveItems: enrichedLeave,
    count: enriched.length + enrichedLeave.length,
    membershipCount: enriched.length,
    approve,
    reject,
    approveAll,
    approveLeave,
    rejectLeave,
    loading: pendingQuery.loading || leavePending.loading,
  };
}
