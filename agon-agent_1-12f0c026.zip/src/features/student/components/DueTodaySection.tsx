import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Card, Text } from '@/components/ui';
import { subjectTint } from '@/lib/subject-tint';
import { C, R, S } from '@/lib/theme';
import type { DueTaskCardView } from '../model';

export interface DueTodaySectionProps {
  tasks: DueTaskCardView[];
  summaryLabel: string | null;
  onSubmitTask: (task: DueTaskCardView) => void;
  onSeeAllHomework: () => void;
}

function DueTaskCard({
  item,
  onSubmit,
}: {
  item: DueTaskCardView;
  onSubmit: (task: DueTaskCardView) => void;
}) {
  const tint = subjectTint(item.subjectName);
  return (
    <Card flat pad={16} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
      <View
        style={{
          width: 42,
          height: 42,
          borderRadius: R.field,
          backgroundColor: tint.bg,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name={tint.icon} size={20} color={tint.fg} />
      </View>

      <View style={{ flex: 1, gap: 3 }}>
        <Text weight={700} c={C.ink} numberOfLines={2} style={{ fontSize: 15, lineHeight: 20 }}>
          {item.title}
        </Text>
        <Text variant="caption" c={C.secondary} numberOfLines={1} tabular>
          {item.subtitle}
        </Text>
      </View>

      {item.isDone ? (
        <View
          accessibilityLabel={`${item.title}: ${item.statusLabel}`}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
            paddingHorizontal: 10,
            paddingVertical: 6,
            borderRadius: R.chip,
            backgroundColor: C.tealSoft,
          }}
        >
          <Ionicons name="checkmark-circle" size={14} color={C.teal} />
          <Text variant="label" weight={700} c={C.teal}>
            {item.statusLabel}
          </Text>
        </View>
      ) : (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Submit ${item.title}`}
          onPress={() => onSubmit(item)}
          style={({ pressed }) => ({
            paddingHorizontal: 14,
            minHeight: 36,
            borderRadius: R.chip,
            backgroundColor: C.primary,
            alignItems: 'center',
            justifyContent: 'center',
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Text variant="caption" weight={700} c={C.surface}>
            Submit
          </Text>
        </Pressable>
      )}
    </Card>
  );
}

/**
 * First section on the student home: due today, leading with completed tasks
 * and showing an encouraging empty state when nothing is due.
 */
export function DueTodaySection({
  tasks,
  summaryLabel,
  onSubmitTask,
  onSeeAllHomework,
}: DueTodaySectionProps) {
  return (
    <View style={{ gap: S.md }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <Text variant="title">Due today</Text>
        {summaryLabel ? (
          <View
            style={{
              paddingHorizontal: 10,
              paddingVertical: 4,
              borderRadius: R.chip,
              backgroundColor: C.tealSoft,
            }}
          >
            <Text variant="label" weight={700} c={C.teal}>
              {summaryLabel}
            </Text>
          </View>
        ) : null}
      </View>

      {tasks.length === 0 ? (
        <Card flat pad={18} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: C.tealSoft,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="checkmark-done-outline" size={22} color={C.teal} />
          </View>
          <View style={{ flex: 1, gap: 3 }}>
            <Text variant="body" weight={700} c={C.ink}>
              All caught up for today
            </Text>
            <Text variant="caption" c={C.secondary}>
              Nothing due today. Great time to review notes or check your progress.
            </Text>
          </View>
          <Pressable
            accessibilityRole="link"
            accessibilityLabel="See all homework"
            onPress={onSeeAllHomework}
            hitSlop={8}
            style={{ paddingLeft: 4 }}
          >
            <Ionicons name="chevron-forward" size={18} color={C.muted} />
          </Pressable>
        </Card>
      ) : (
        <View style={{ gap: 10 }}>
          {tasks.map((task) => (
            <DueTaskCard key={task.id} item={task} onSubmit={onSubmitTask} />
          ))}
        </View>
      )}
    </View>
  );
}
