import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Card, Text } from '@/components/ui';
import { subjectTint } from '@/lib/subject-tint';
import { C, R, S } from '@/lib/theme';
import type { MaterialThumbView } from '../model';

export interface NewMaterialSectionProps {
  items: MaterialThumbView[];
  onOpenMaterial: (item: MaterialThumbView) => void;
}

function MaterialThumbCard({
  item,
  onPress,
}: {
  item: MaterialThumbView;
  onPress: (item: MaterialThumbView) => void;
}) {
  const tint = subjectTint(item.subjectName);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open ${item.title}`}
      onPress={() => onPress(item)}
      style={({ pressed }) => ({
        width: 152,
        borderRadius: R.card,
        backgroundColor: C.surface,
        borderWidth: 1,
        borderColor: C.hairline,
        overflow: 'hidden',
        opacity: pressed ? 0.9 : 1,
      })}
    >
      <View
        style={{
          height: 76,
          backgroundColor: tint.bg,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <View
          style={{
            position: 'absolute',
            top: 8,
            left: 8,
            paddingHorizontal: 7,
            paddingVertical: 2,
            borderRadius: R.chip,
            backgroundColor: C.surface,
          }}
        >
          <Text variant="label" weight={700} c={tint.fg} style={{ fontSize: 10 }}>
            {item.typeLabel}
          </Text>
        </View>
        <Ionicons name={item.typeIcon} size={28} color={tint.fg} />
      </View>

      <View style={{ padding: 12, gap: 4 }}>
        <Text weight={700} c={C.ink} numberOfLines={2} style={{ fontSize: 13.5, lineHeight: 18 }}>
          {item.title}
        </Text>
        <Text variant="label" c={C.secondary} numberOfLines={1} style={{ textTransform: 'none', letterSpacing: 0 }}>
          {item.subtitle}
        </Text>
      </View>
    </Pressable>
  );
}

/**
 * Third section on the student home: horizontal study material thumbnails.
 */
export function NewMaterialSection({ items, onOpenMaterial }: NewMaterialSectionProps) {
  return (
    <View style={{ gap: S.md }}>
      <Text variant="title">New material</Text>

      {items.length === 0 ? (
        <Card flat pad={16} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: R.field,
              backgroundColor: C.navySoft,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="folder-open-outline" size={20} color={C.primary} />
          </View>
          <Text variant="caption" c={C.secondary} style={{ flex: 1 }}>
            Study notes and worksheets shared by your teachers will appear here.
          </Text>
        </Card>
      ) : (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 12, paddingRight: 4 }}
        >
          {items.map((item) => (
            <MaterialThumbCard key={item.key} item={item} onPress={onOpenMaterial} />
          ))}
        </ScrollView>
      )}
    </View>
  );
}
