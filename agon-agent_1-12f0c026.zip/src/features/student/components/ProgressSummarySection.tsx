import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, R, S } from '@/lib/theme';

export interface ProgressSummarySectionProps {
  line: string;
  onOpenProgress: () => void;
}

/**
 * Fourth section on the student home: single-line progress summary with a
 * chevron to the full progress screen.
 */
export function ProgressSummarySection({ line, onOpenProgress }: ProgressSummarySectionProps) {
  return (
    <View style={{ gap: S.md }}>
      <Text variant="title">Your progress</Text>

      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`Your progress: ${line}`}
        onPress={onOpenProgress}
        style={({ pressed }) => ({
          backgroundColor: C.surface,
          borderRadius: R.card,
          borderWidth: 1,
          borderColor: C.hairline,
          padding: 16,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 12,
          opacity: pressed ? 0.9 : 1,
        })}
      >
        <View
          style={{
            width: 34,
            height: 34,
            borderRadius: 17,
            backgroundColor: C.tealSoft,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name="trending-up-outline" size={18} color={C.teal} />
        </View>

        <Text
          variant="body"
          weight={600}
          tabular
          c={C.ink}
          numberOfLines={2}
          style={{ flex: 1, fontSize: 14, lineHeight: 20 }}
        >
          {line}
        </Text>

        <Ionicons name="chevron-forward" size={18} color={C.muted} />
      </Pressable>
    </View>
  );
}
