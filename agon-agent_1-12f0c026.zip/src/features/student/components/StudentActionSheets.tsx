import React, { useState } from 'react';
import { Linking, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Badge, Button, Card, EmptyState, Input, Sheet, Text } from '@/components/ui';
import { toast } from '@/core/backend';
import type { AppNotification, ID } from '@/core/contracts/models';
import { relTime } from '@/lib/format';
import { subjectTint } from '@/lib/subject-tint';
import { C, R } from '@/lib/theme';
import type { DueTaskCardView, MaterialThumbView, TodayClassRowView } from '../model';

export function SubmitHomeworkSheet({
  task,
  submitting,
  onClose,
  onConfirm,
}: {
  task: DueTaskCardView | null;
  submitting: boolean;
  onClose: () => void;
  onConfirm: (assignmentId: ID, note: string) => Promise<void>;
}) {
  const [draft, setDraft] = useState<{ taskId: string | null; note: string }>({ taskId: null, note: '' });
  const note = task && draft.taskId === task.id ? draft.note : '';

  return (
    <Sheet
      visible={task !== null}
      onClose={onClose}
      title={task?.title ?? 'Submit homework'}
      subtitle={task?.subtitle}
    >
      {task ? (
        <View style={{ gap: 14 }}>
          {task.description ? (
            <Card flat pad={14} tint={C.canvas}>
              <Text variant="caption" c={C.secondary}>
                {task.description}
              </Text>
            </Card>
          ) : null}

          <Input
            label="Note for your teacher (optional)"
            value={note}
            onChangeText={(text) => setDraft({ taskId: task.id, note: text })}
            placeholder="e.g. Completed Q1–Q10 in my notebook"
            multiline
            returnKeyType="done"
          />

          <Button
            title="Turn in homework"
            loading={submitting}
            onPress={() => void onConfirm(task.id, note)}
          />
        </View>
      ) : null}
    </Sheet>
  );
}

export function JoinClassSheet({
  session,
  onClose,
}: {
  session: TodayClassRowView | null;
  onClose: () => void;
}) {
  const tint = subjectTint(session?.subject);
  return (
    <Sheet
      visible={session !== null}
      onClose={onClose}
      title={session?.subject ?? 'Class session'}
      subtitle={session ? `${session.item.batchName} · ${session.timeRange}` : undefined}
    >
      {session ? (
        <View style={{ gap: 14 }}>
          <Card flat pad={16} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <View
              style={{
                width: 44,
                height: 44,
                borderRadius: R.field,
                backgroundColor: tint.bg,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Ionicons name={tint.icon} size={22} color={tint.fg} />
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <Text variant="body" weight={700} c={C.ink}>
                {session.item.teacherName ?? 'Class teacher'}
              </Text>
              <Text variant="caption" c={C.secondary}>
                {session.item.roomName ?? 'Classroom session'} · {session.timeRange}
              </Text>
            </View>
          </Card>

          <Button
            title="Join class"
            onPress={() => {
              onClose();
              toast.success(`Joined ${session.subject}`);
            }}
          />
        </View>
      ) : null}
    </Sheet>
  );
}

export function MaterialDetailSheet({
  material,
  onClose,
}: {
  material: MaterialThumbView | null;
  onClose: () => void;
}) {
  return (
    <Sheet
      visible={material !== null}
      onClose={onClose}
      title={material?.title ?? 'Study material'}
      subtitle={material?.subtitle}
    >
      {material ? (
        <View style={{ gap: 14 }}>
          <Badge label={material.typeLabel} tone="primary" />
          <Text variant="body" c={C.secondary}>
            {material.item.description ?? 'Shared by your teacher for class revision.'}
          </Text>
          {material.item.url ? (
            <Button
              title="Open resource"
              onPress={() => {
                void Linking.openURL(material.item.url as string);
                onClose();
              }}
            />
          ) : (
            <Button title="Done" variant="secondary" onPress={onClose} />
          )}
        </View>
      ) : null}
    </Sheet>
  );
}

export function NotificationsSheet({
  visible,
  notifications,
  onClose,
  onMarkRead,
  onMarkAllRead,
}: {
  visible: boolean;
  notifications: AppNotification[];
  onClose: () => void;
  onMarkRead: (id: ID) => void;
  onMarkAllRead: () => void;
}) {
  const hasUnread = notifications.some((n) => n.readAt === null);
  return (
    <Sheet visible={visible} onClose={onClose} title="Notifications" subtitle="Updates from your classes">
      <View style={{ gap: 10 }}>
        {hasUnread ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Mark all notifications as read"
            onPress={onMarkAllRead}
            style={{ alignSelf: 'flex-end', paddingVertical: 4 }}
          >
            <Text variant="caption" weight={700} c={C.primary}>
              Mark all read
            </Text>
          </Pressable>
        ) : null}

        {notifications.length === 0 ? (
          <EmptyState
            icon="notifications-outline"
            title="All caught up"
            text="No notifications yet. Class and homework updates will appear here."
          />
        ) : (
          notifications.slice(0, 12).map((item) => {
            const unread = item.readAt === null;
            return (
              <Pressable
                key={item.id}
                accessibilityRole="button"
                onPress={() => unread && onMarkRead(item.id)}
                style={{
                  padding: 12,
                  borderRadius: R.field,
                  borderWidth: 1,
                  borderColor: unread ? C.primary : C.hairline,
                  backgroundColor: unread ? C.navySoft : C.surface,
                  gap: 3,
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                  <Text variant="body" weight={700} c={C.ink} style={{ flex: 1 }} numberOfLines={1}>
                    {item.title}
                  </Text>
                  <Text variant="label" c={C.muted}>
                    {relTime(item.sentAt ?? item.createdAt)}
                  </Text>
                </View>
                {item.body ? (
                  <Text variant="caption" c={C.secondary} numberOfLines={2}>
                    {item.body}
                  </Text>
                ) : null}
              </Pressable>
            );
          })
        )}
      </View>
    </Sheet>
  );
}
