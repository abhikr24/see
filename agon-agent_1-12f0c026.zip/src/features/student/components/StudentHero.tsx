import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, GradientHeader, OverlapCard, Ring, Text } from '@/components/ui';
import { C, hit, R } from '@/lib/theme';
import type { StudentHeroView } from '../hooks/useStudentHomeView';

const HERO_RADIUS = 24;
const HERO_PAD = 20;
const OVERLAP = 22;

export interface StudentHeroProps {
  hero: StudentHeroView;
  onOpenBell: () => void;
  onOpenSwitcher: () => void;
}

/**
 * Shape A student header:
 * - Compact navy header: 40pt avatar, 13 white/70 batch label, 20 white/800 greeting, bell with unread dot
 * - Institute switcher pill under the name when holding > 1 membership
 * - Overlapping white card: teal attendance ring + amber next-test countdown
 */
export function StudentHero({ hero, onOpenBell, onOpenSwitcher }: StudentHeroProps) {
  return (
    <View>
      <GradientHeader
        style={{
          borderRadius: HERO_RADIUS,
          padding: HERO_PAD,
          paddingBottom: HERO_PAD + OVERLAP,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12 }}>
          <Avatar name={hero.studentName} uri={hero.avatarUrl} size={40} />
          <View style={{ flex: 1 }}>
            <Text
              numberOfLines={1}
              style={{ fontSize: 13, lineHeight: 18, color: C.surface, opacity: 0.7 }}
            >
              {hero.classLabel || 'Student'}
            </Text>
            <Text
              weight={800}
              numberOfLines={1}
              style={{ fontSize: 20, lineHeight: 26, color: C.surface, marginTop: 2 }}
            >
              {hero.greeting}
            </Text>
            {hero.canSwitchInstitute ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Switch institute (${hero.activeInstituteName})`}
                onPress={onOpenSwitcher}
                style={({ pressed }) => ({
                  alignSelf: 'flex-start',
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 6,
                  marginTop: 8,
                  paddingHorizontal: 10,
                  paddingVertical: 5,
                  borderRadius: R.chip,
                  backgroundColor: C.heroGlass,
                  borderWidth: 1,
                  borderColor: C.heroLine,
                  opacity: pressed ? 0.8 : 1,
                })}
              >
                <Ionicons name="business-outline" size={12} color={C.navyPale} />
                <Text variant="label" weight={600} c={C.surface} numberOfLines={1} style={{ maxWidth: 180 }}>
                  {hero.activeInstituteName}
                </Text>
                <Ionicons name="chevron-down" size={13} color={C.navyPale} />
              </Pressable>
            ) : null}
          </View>

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={
              hero.unreadNotifications > 0
                ? `Notifications (${hero.unreadNotifications} unread)`
                : 'Notifications'
            }
            onPress={onOpenBell}
            hitSlop={6}
            style={({ pressed }) => ({
              width: hit,
              height: hit,
              borderRadius: hit / 2,
              backgroundColor: C.heroGlass,
              alignItems: 'center',
              justifyContent: 'center',
              opacity: pressed ? 0.8 : 1,
            })}
          >
            <Ionicons name="notifications-outline" size={20} color={C.surface} />
            {hero.unreadNotifications > 0 ? (
              <View
                testID="student-bell-unread-dot"
                style={{
                  position: 'absolute',
                  top: 9,
                  right: 10,
                  width: 9,
                  height: 9,
                  borderRadius: 4.5,
                  backgroundColor: C.accent,
                  borderWidth: 1.5,
                  borderColor: C.primary,
                }}
              />
            ) : null}
          </Pressable>
        </View>
      </GradientHeader>

      <OverlapCard style={{ paddingHorizontal: 18, paddingVertical: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <View style={{ alignItems: 'center', gap: 4 }}>
            <Ring value={hero.attendancePercent ?? 0} size={74} stroke={7} tone={C.teal} />
            <Text variant="label" c={C.muted}>
              Attendance
            </Text>
          </View>

          <View style={{ width: 1, height: 56, backgroundColor: C.hairline }} />

          <View style={{ flex: 1, gap: 6 }}>
            <View
              style={{
                alignSelf: 'flex-start',
                flexDirection: 'row',
                alignItems: 'center',
                gap: 6,
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: R.chip,
                backgroundColor: hero.nextTest.hasTest ? C.warningSoft : C.tealSoft,
              }}
            >
              <Ionicons
                name={hero.nextTest.hasTest ? 'calendar-outline' : 'sparkles-outline'}
                size={14}
                color={hero.nextTest.hasTest ? C.duesInk : C.teal}
              />
              <Text
                weight={700}
                tabular
                c={hero.nextTest.hasTest ? C.duesInk : C.teal}
                style={{ fontSize: 13 }}
              >
                {hero.nextTest.headline}
              </Text>
            </View>
            <Text variant="caption" c={C.secondary} numberOfLines={2}>
              {hero.nextTest.detail}
            </Text>
          </View>
        </View>
      </OverlapCard>
    </View>
  );
}
