import React from 'react';
import { View } from 'react-native';

import { Card, ListSkeleton, Skeleton } from '@/components/ui';
import { C, R, S } from '@/lib/theme';

export function StudentHomeSkeleton() {
  return (
    <View style={{ gap: S.xxl }}>
      <View>
        <View
          style={{
            borderRadius: 24,
            backgroundColor: C.primary,
            padding: 20,
            paddingBottom: 44,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 12,
          }}
        >
          <Skeleton w={40} h={40} r={20} />
          <View style={{ flex: 1, gap: 6 }}>
            <Skeleton w={96} h={12} r={6} />
            <Skeleton w={148} h={22} r={8} />
          </View>
          <Skeleton w={44} h={44} r={22} />
        </View>
        <View
          style={{
            marginTop: -22,
            marginHorizontal: 12,
            borderRadius: R.card,
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            padding: 18,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 16,
          }}
        >
          <Skeleton w={74} h={74} r={37} />
          <View style={{ flex: 1, gap: 8 }}>
            <Skeleton w={140} h={24} r={12} />
            <Skeleton w={180} h={14} r={6} />
          </View>
        </View>
      </View>

      <Card flat>
        <ListSkeleton rows={2} h={56} />
      </Card>
      <Card flat>
        <ListSkeleton rows={2} h={56} />
      </Card>
    </View>
  );
}
