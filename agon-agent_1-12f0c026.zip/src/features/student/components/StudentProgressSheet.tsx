import React from 'react';
import { View } from 'react-native';

import { Badge, Button, Card, Divider, ProgressBar, Sheet, Text } from '@/components/ui';
import type { StudentProgressSummary } from '@/core/contracts/models';
import { pct } from '@/lib/format';
import { C, R } from '@/lib/theme';
import { examScoresOf, goalDetailLabel } from '../model';

export interface StudentProgressSheetProps {
  visible: boolean;
  progress: StudentProgressSummary | null;
  onClose: () => void;
  onOpenResults: () => void;
}

/**
 * Full progress view reached from the "Your progress" chevron on Student Home:
 * attendance summary, published exam marks (matching the teacher's entry
 * exactly), and active goals.
 */
export function StudentProgressSheet({
  visible,
  progress,
  onClose,
  onOpenResults,
}: StudentProgressSheetProps) {
  const scores = progress ? examScoresOf(progress.examScores) : [];

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Your progress"
      subtitle="Attendance, exam marks and goals"
    >
      {progress ? (
        <View style={{ gap: 16 }}>
          <Card flat pad={16} style={{ gap: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Text variant="body" weight={700} c={C.ink}>
                Attendance
              </Text>
              <Text variant="title" weight={800} c={C.teal} tabular>
                {progress.attendancePercent !== null ? pct(progress.attendancePercent) : '—'}
              </Text>
            </View>
            <Text variant="caption" c={C.secondary} tabular>
              {progress.attendance.present} present · {progress.attendance.late} late · {progress.attendance.absent} absent of{' '}
              {progress.attendance.total} classes
            </Text>
          </Card>

          <View style={{ gap: 8 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Text variant="body" weight={700} c={C.ink}>
                Exam marks
              </Text>
              <Text variant="caption" weight={700} c={C.primary} tabular>
                Average {progress.averagePercent !== null ? pct(progress.averagePercent) : '—'}
              </Text>
            </View>

            {scores.length === 0 ? (
              <Card flat pad={14}>
                <Text variant="caption" c={C.secondary}>
                  Published test marks will appear here right after your teacher enters them.
                </Text>
              </Card>
            ) : (
              <Card flat pad={0}>
                {scores.map((row, idx) => (
                  <React.Fragment key={row.key}>
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        paddingHorizontal: 14,
                        paddingVertical: 12,
                        gap: 10,
                      }}
                    >
                      <View style={{ flex: 1 }}>
                        <Text variant="body" weight={600} c={C.ink} numberOfLines={1}>
                          {row.examName}
                        </Text>
                        {row.subjectName ? (
                          <Text variant="label" c={C.muted}>
                            {row.subjectName}
                          </Text>
                        ) : null}
                      </View>
                      <View style={{ alignItems: 'flex-end' }}>
                        <Text variant="body" weight={800} c={C.ink} tabular>
                          {row.scoreLabel}
                        </Text>
                        <Text variant="label" c={C.teal} tabular>
                          {row.percentLabel}
                        </Text>
                      </View>
                    </View>
                    {idx < scores.length - 1 ? <Divider inset={14} /> : null}
                  </React.Fragment>
                ))}
              </Card>
            )}
          </View>

          {progress.goals.length > 0 ? (
            <View style={{ gap: 8 }}>
              <Text variant="body" weight={700} c={C.ink}>
                Goals ({progress.goalsOnTrack} on track)
              </Text>
              {progress.goals.map((g) => {
                const ratio =
                  g.targetValue && g.currentValue !== null
                    ? Math.min(100, Math.round((g.currentValue / g.targetValue) * 100))
                    : g.onTrack
                      ? 100
                      : 40;
                return (
                  <Card key={g.id} flat pad={14} style={{ gap: 8, borderRadius: R.field }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                      <Text variant="caption" weight={700} c={C.ink} style={{ flex: 1 }}>
                        {g.title}
                      </Text>
                      <Badge label={g.onTrack ? 'On track' : 'Active'} tone={g.onTrack ? 'teal' : 'neutral'} small />
                    </View>
                    <ProgressBar value={ratio} tone={g.onTrack ? 'teal' : 'primary'} height={6} />
                    <Text variant="label" c={C.muted} tabular>
                      {goalDetailLabel(g)}
                    </Text>
                  </Card>
                );
              })}
            </View>
          ) : null}

          <Button title="Open full results" variant="secondary" onPress={onOpenResults} />
        </View>
      ) : null}
    </Sheet>
  );
}
