import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Card, Divider, Text } from '@/components/ui';
import { C, R, S } from '@/lib/theme';
import type { TodayClassRowView } from '../model';

export interface TodayClassesSectionProps {
  rows: TodayClassRowView[];
  onJoin: (row: TodayClassRowView) => void;
}

function ClassRow({
  row,
  isLast,
  onJoin,
}: {
  row: TodayClassRowView;
  isLast: boolean;
  onJoin: (row: TodayClassRowView) => void;
}) {
  return (
    <>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 12,
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}
      >
        <View
          style={{
            width: 56,
            height: 46,
            borderRadius: R.field,
            backgroundColor: C.navySoft,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text variant="caption" weight={700} c={C.primary} tabular style={{ lineHeight: 15 }}>
            {row.clock}
          </Text>
          {row.meridiem ? (
            <Text variant="label" weight={600} c={C.secondary} style={{ fontSize: 10, lineHeight: 12 }}>
              {row.meridiem}
            </Text>
          ) : null}
        </View>

        <View style={{ flex: 1, gap: 2 }}>
          <Text weight={700} c={C.ink} numberOfLines={1} style={{ fontSize: 15, lineHeight: 20 }}>
            {row.subject}
          </Text>
          <Text variant="caption" c={C.secondary} numberOfLines={1}>
            {row.meta}
          </Text>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Join ${row.subject}`}
          onPress={() => onJoin(row)}
          style={({ pressed }) => ({
            paddingHorizontal: 14,
            minHeight: 34,
            borderRadius: R.chip,
            backgroundColor: C.navySoft,
            alignItems: 'center',
            justifyContent: 'center',
            opacity: pressed ? 0.8 : 1,
          })}
        >
          <Text variant="caption" weight={700} c={C.primary}>
            Join
          </Text>
        </Pressable>
      </View>
      {!isLast ? <Divider inset={16} /> : null}
    </>
  );
}

/**
 * Second section on the student home: today's classes from the institute timetable.
 */
export function TodayClassesSection({ rows, onJoin }: TodayClassesSectionProps) {
  return (
    <View style={{ gap: S.md }}>
      <Text variant="title">{"Today's classes"}</Text>

      {rows.length === 0 ? (
        <Card flat pad={16} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: R.field,
              backgroundColor: C.navySoft,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="calendar-outline" size={20} color={C.primary} />
          </View>
          <View style={{ flex: 1, gap: 2 }}>
            <Text variant="body" weight={700} c={C.ink}>
              No classes scheduled today
            </Text>
            <Text variant="caption" c={C.secondary}>
              Use this free block to revise or practice at your own pace.
            </Text>
          </View>
        </Card>
      ) : (
        <Card flat pad={0}>
          {rows.map((row, index) => (
            <ClassRow
              key={row.key}
              row={row}
              isLast={index === rows.length - 1}
              onJoin={onJoin}
            />
          ))}
        </Card>
      )}
    </View>
  );
}
