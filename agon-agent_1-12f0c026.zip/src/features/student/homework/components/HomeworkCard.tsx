import React from 'react';
import { View, Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Text, Badge } from '@/components/ui';
import { C, R, S } from '@/lib/theme';
import type { HomeworkCardView } from '../model';

interface Props {
  item: HomeworkCardView;
  onPress: () => void;
  onSubmit: () => void;
}

export function HomeworkCard({ item, onPress, onSubmit }: Props) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.9 : 1 })}>
      <View style={[styles.wrapper, item.isOverdue && styles.overdueWrapper]}>
        {item.isOverdue ? <View style={styles.accent} /> : null}
        <Card flat style={styles.card}>
          <View style={styles.row}>
            <View style={[styles.square, { backgroundColor: item.subjectTintBg }]}>
              <Ionicons name={item.subjectIcon as any} size={22} color={item.subjectTintFg} />
            </View>
            <View style={styles.middle}>
              <Text variant="title" weight={700} numberOfLines={1} c={C.ink}>
                {item.title}
              </Text>
              <Text variant="caption" c={C.secondary} numberOfLines={1} style={{ marginTop: 2 }}>
                {item.subjectName ? `${item.subjectName} · ${item.teacherName}` : item.teacherName}
              </Text>
              {item.isOverdue && item.overdueText ? (
                <Text variant="caption" weight={700} c={C.danger} style={{ marginTop: 4 }}>
                  {item.overdueText}
                </Text>
              ) : null}
            </View>
            <View style={styles.right}>
              <View style={styles.chip}>
                <Text variant="label" weight={600} c={C.secondary}>
                  {item.dueChip}
                </Text>
              </View>
            </View>
          </View>

          <View style={styles.footer}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View style={[styles.dot, { backgroundColor: item.isOverdue ? C.danger : C.track }]} />
              <Text variant="caption" c={item.isOverdue ? C.danger : C.secondary}>
                {item.isOverdue ? item.overdueText ?? 'Overdue' : item.dueLabel}
              </Text>
            </View>
            {item.submitted ? (
              <View style={styles.submittedPill}>
                <Ionicons name="checkmark-circle" size={14} color={C.teal} />
                <Text variant="label" weight={700} c={C.teal}>
                  {item.graded && item.marksAwarded !== null ? `Graded ${item.marksAwarded}/${item.maxMarks}` : 'Submitted'}
                </Text>
              </View>
            ) : (
              <Pressable onPress={onSubmit} style={({ pressed }) => [styles.submitBtn, { opacity: pressed ? 0.8 : 1 }]}>
                <Text variant="label" weight={700} c={C.surface}>
                  Submit
                </Text>
              </Pressable>
            )}
          </View>
        </Card>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: R.card,
    overflow: 'hidden',
    backgroundColor: C.surface,
    position: 'relative',
  },
  overdueWrapper: {
    borderWidth: 1,
    borderColor: C.dangerSoft,
  },
  accent: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    backgroundColor: C.danger,
    zIndex: 2,
    borderTopLeftRadius: R.card,
    borderBottomLeftRadius: R.card,
  },
  card: {
    padding: 16,
    gap: 14,
    backgroundColor: 'transparent',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  square: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  middle: {
    flex: 1,
    gap: 2,
  },
  right: {
    alignItems: 'flex-end',
    gap: 6,
  },
  chip: {
    backgroundColor: C.track,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 2,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  submittedPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: C.tealSoft,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  submitBtn: {
    backgroundColor: C.primary,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 999,
  },
});
