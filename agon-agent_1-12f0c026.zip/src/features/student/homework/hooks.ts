import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocalSearchParams, router } from 'expo-router';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  useAssignments,
  useStudentHomework,
  useSubmissions,
  useTeachers,
  useSession,
} from '@/core/backend';
import type { ID, StudentHomeworkItem } from '@/core/contracts/models';
import { toHomeworkCardView, filterBySegment, type HomeworkSegment, type HomeworkCardView } from './model';

/**
 * Homework list board with Due / Submitted / Overdue segmentation.
 */
export function useStudentHomeworkBoard() {
  const homeworkQ = useStudentHomework();
  const teachersQ = useTeachers({ limit: 50 });
  const [segment, setSegment] = useState<HomeworkSegment>('due');
  const [refreshing, setRefreshing] = useState(false);

  const now = useMemo(() => new Date(), [homeworkQ.dataUpdatedAt]);

  const allCards = useMemo(() => {
    const items = (homeworkQ.data ?? []) as StudentHomeworkItem[];
    return items.map((it) => toHomeworkCardView(it, now));
  }, [homeworkQ.data, now]);

  const dueCount = useMemo(() => filterBySegment(allCards, 'due').length, [allCards]);
  const submittedCount = useMemo(() => filterBySegment(allCards, 'submitted').length, [allCards]);
  const overdueCount = useMemo(() => filterBySegment(allCards, 'overdue').length, [allCards]);

  const visibleCards = useMemo(() => filterBySegment(allCards, segment), [allCards, segment]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await homeworkQ.refetch();
    } finally {
      setRefreshing(false);
    }
  }, [homeworkQ]);

  const openHomework = useCallback((id: string) => {
    router.push(`/(student)/homework/${id}` as never);
  }, []);

  const openMaterials = useCallback(() => {
    router.push('/(student)/homework/materials' as never);
  }, []);

  const openPractice = useCallback(() => {
    router.push('/(student)/homework/practice' as never);
  }, []);

  return {
    loading: homeworkQ.loading && !homeworkQ.data,
    error: homeworkQ.error ? (homeworkQ.error.message ?? 'Failed to load') : null,
    refreshing,
    refresh,
    segment,
    setSegment,
    allCards,
    visibleCards,
    counts: { due: dueCount, submitted: submittedCount, overdue: overdueCount },
    openHomework,
    openMaterials,
    openPractice,
  };
}

export interface HomeworkDetailData {
  item: StudentHomeworkItem | null;
  card: HomeworkCardView | null;
}

export function useHomeworkDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const homeworkQ = useStudentHomework();
  const sessionQ = useSession();
  const submissionsQ = useSubmissions({
    where: { assignmentId: id as ID },
    limit: 50,
  } as any);
  const submissionMut = useSubmissions();

  const item = useMemo(() => {
    const list = (homeworkQ.data ?? []) as StudentHomeworkItem[];
    return list.find((x) => x.id === id) ?? null;
  }, [homeworkQ.data, id]);

  const card = useMemo(() => (item ? toHomeworkCardView(item, new Date()) : null), [item]);

  const studentId = useMemo(() => {
    // Session userId is not studentId; we need to get student id via enrollment guess.
    // For memory backend, studentId equals userId for students (Aarav = sid(14) = userId).
    // Use session user id directly as studentId fallback.
    return (sessionQ.data?.user?.id as ID) ?? null;
  }, [sessionQ.data]);

  const [localFiles, setLocalFiles] = useState<{ name: string; uri: string }[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [optimisticSubmitted, setOptimisticSubmitted] = useState(false);
  const [undoVisible, setUndoVisible] = useState(false);
  const undoTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [countdown, setCountdown] = useState(10);

  const canSubmit = localFiles.length > 0 || (item?.description ? true : true);

  const clearTimers = useCallback(() => {
    if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
    undoTimerRef.current = null;
    countdownRef.current = null;
  }, []);

  useEffect(() => {
    return () => clearTimers();
  }, [clearTimers]);

  const triggerOptimisticSubmit = useCallback(async () => {
    if (!item || !studentId) return;
    if (localFiles.length === 0) {
      Alert.alert('Add a photo', 'Take a photo of your work or attach a file first.');
      return;
    }
    setSubmitting(true);
    // Optimistic
    setOptimisticSubmitted(true);
    setUndoVisible(true);
    setCountdown(10);
    // Start countdown
    countdownRef.current = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          if (countdownRef.current) clearInterval(countdownRef.current);
          return 0;
        }
        return c - 1;
      });
    }, 1000);

    undoTimerRef.current = setTimeout(async () => {
      // Commit after 10s
      try {
        await submissionMut.submit({
          assignmentId: item.id as ID,
          studentId: studentId as ID,
          content: localFiles.map((f) => f.name).join(', '),
        });
        setUndoVisible(false);
        // Persist that submission happened for teacher tracker invalidation (hook already does)
      } catch (e) {
        // Rollback on failure
        setOptimisticSubmitted(false);
        setUndoVisible(false);
        Alert.alert('Failed', 'Could not submit homework. Try again.');
      } finally {
        setSubmitting(false);
        clearTimers();
      }
    }, 10000);
  }, [item, studentId, localFiles, submissionMut, clearTimers]);

  const undoSubmit = useCallback(() => {
    clearTimers();
    setOptimisticSubmitted(false);
    setUndoVisible(false);
    setSubmitting(false);
    setCountdown(10);
  }, [clearTimers]);

  const addFile = useCallback((name: string, uri: string) => {
    setLocalFiles((prev) => [...prev, { name, uri }]);
  }, []);

  const removeFile = useCallback((name: string) => {
    setLocalFiles((prev) => prev.filter((f) => f.name !== name));
  }, []);

  return {
    id: id as string,
    loading: homeworkQ.loading && !homeworkQ.data,
    item,
    card,
    localFiles,
    addFile,
    removeFile,
    submitting,
    optimisticSubmitted,
    undoVisible,
    countdown,
    canSubmit,
    triggerOptimisticSubmit,
    undoSubmit,
    refresh: homeworkQ.refetch,
  };
}
