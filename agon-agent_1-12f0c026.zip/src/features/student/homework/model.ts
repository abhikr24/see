import type { StudentHomeworkItem } from '@/core/contracts/models';
import { subjectTint } from '@/lib/subject-tint';
import { C } from '@/lib/theme';

export type HomeworkSegment = 'due' | 'submitted' | 'overdue';

export interface HomeworkCardView {
  id: string;
  title: string;
  description: string | null;
  subjectName: string | null;
  batchName: string;
  teacherName: string;
  dueAt: string | null;
  dueLabel: string;
  dueChip: string;
  isOverdue: boolean;
  overdueText: string | null;
  submitted: boolean;
  late: boolean;
  graded: boolean;
  marksAwarded: number | null;
  maxMarks: number;
  subjectTintBg: string;
  subjectTintFg: string;
  subjectIcon: string;
  raw: StudentHomeworkItem;
}

const TEACHER_MAP: Record<string, string> = {
  Mathematics: 'Priya Nair',
  Physics: 'Rohit Verma',
  Chemistry: 'Meera Iyer',
  English: 'Sneha Iyer',
  Biology: 'Arun Kumar',
};

function teacherForSubject(subject: string | null): string {
  if (!subject) return 'Class Teacher';
  return TEACHER_MAP[subject] ?? 'Priya Nair';
}

function daysDiff(dueAt: string, now: Date): number {
  const due = new Date(dueAt).getTime();
  const n = now.getTime();
  const diffMs = n - due;
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  return Math.max(0, days);
}

export function formatDueChip(dueAt: string | null, now: Date = new Date()): string {
  if (!dueAt) return 'No due date';
  const due = new Date(dueAt);
  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  const dueDay = new Date(due);
  dueDay.setHours(0, 0, 0, 0);
  const diffDays = Math.round((dueDay.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays === 0) {
    const hh = due.getHours();
    const ampm = hh >= 12 ? 'PM' : 'AM';
    const h12 = hh % 12 === 0 ? 12 : hh % 12;
    const mm = String(due.getMinutes()).padStart(2, '0');
    return `Due today, ${h12}:${mm} ${ampm}`;
  }
  if (diffDays === 1) return 'Due tomorrow';
  if (diffDays === -1) return 'Due yesterday';
  if (diffDays < 0) return `Due ${Math.abs(diffDays)} days ago`;
  return `Due in ${diffDays} days`;
}

export function overdueTextFor(dueAt: string | null, now: Date = new Date()): string | null {
  if (!dueAt) return null;
  const due = new Date(dueAt).getTime();
  const n = now.getTime();
  if (n <= due) return null;
  const d = daysDiff(dueAt, now);
  if (d === 0) return 'Overdue today';
  if (d === 1) return 'Overdue by 1 day';
  return `Overdue by ${d} days`;
}

export function toHomeworkCardView(item: StudentHomeworkItem, now: Date = new Date()): HomeworkCardView {
  const tint = subjectTint(item.subjectName);
  const dueAt = item.dueAt;
  const isOverdue = dueAt ? new Date(dueAt).getTime() < now.getTime() && item.submissionStatus === 'pending' : false;
  const dueLabel = formatDueChip(dueAt, now);
  const overdue = isOverdue ? overdueTextFor(dueAt, now) : null;
  const submitted = item.submissionStatus === 'submitted' || item.submissionStatus === 'late' || item.submissionStatus === 'returned';
  const late = item.submissionStatus === 'late';
  const graded = item.submissionStatus === 'returned';
  return {
    id: item.id,
    title: item.title,
    description: item.description,
    subjectName: item.subjectName,
    batchName: item.batchName,
    teacherName: teacherForSubject(item.subjectName),
    dueAt: item.dueAt,
    dueLabel,
    dueChip: dueAt ? new Date(dueAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) : '—',
    isOverdue,
    overdueText: overdue,
    submitted,
    late,
    graded,
    marksAwarded: item.marksAwarded,
    maxMarks: item.maxMarks,
    subjectTintBg: tint.bg,
    subjectTintFg: tint.fg,
    subjectIcon: tint.icon,
    raw: item,
  };
}

export function filterBySegment(items: HomeworkCardView[], seg: HomeworkSegment): HomeworkCardView[] {
  const now = new Date();
  switch (seg) {
    case 'due':
      return items.filter((i) => !i.submitted && !i.isOverdue);
    case 'submitted':
      return items.filter((i) => i.submitted);
    case 'overdue':
      return items.filter((i) => i.isOverdue);
    default:
      return items;
  }
}

export const SEGMENTS: { key: HomeworkSegment; label: string }[] = [
  { key: 'due', label: 'Due' },
  { key: 'submitted', label: 'Submitted' },
  { key: 'overdue', label: 'Overdue' },
];
