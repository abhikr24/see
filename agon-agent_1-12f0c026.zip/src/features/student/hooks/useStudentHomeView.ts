import { useCallback, useMemo, useState } from 'react';

import { useNotifications, useStudentHome, useSubmissions } from '@/core/backend';
import type { AppNotification, ID, StudentProgressSummary } from '@/core/contracts/models';
import { useSessionStore, type InstituteMembership } from '@/store/session';
import {
  dueSummaryLabel,
  dueTasksOf,
  materialsOf,
  nextTestView,
  progressLineOf,
  studentGreeting,
  todayClassesOf,
  type DueTaskCardView,
  type MaterialThumbView,
  type NextTestView,
  type TodayClassRowView,
} from '../model';

export type StudentHomeStatus = 'loading' | 'error' | 'ready';

export interface StudentHeroView {
  greeting: string;
  classLabel: string;
  studentName: string;
  avatarUrl: string | null;
  unreadNotifications: number;
  attendancePercent: number | null;
  nextTest: NextTestView;
  activeInstituteName: string;
  canSwitchInstitute: boolean;
  institutes: InstituteMembership[];
}

export interface StudentHomeView {
  status: StudentHomeStatus;
  hero: StudentHeroView;
  dueToday: DueTaskCardView[];
  dueSummary: string | null;
  todayClasses: TodayClassRowView[];
  newMaterials: MaterialThumbView[];
  progressLine: string;
  progress: StudentProgressSummary | null;
  notifications: AppNotification[];
  submitting: boolean;
  submitHomework: (assignmentId: ID, content?: string | null) => Promise<boolean>;
  markNotificationRead: (id: ID) => void;
  markAllNotificationsRead: () => void;
  errorMessage: string | null;
  refreshing: boolean;
  refresh: () => Promise<void>;
}

export function useStudentHomeView(): StudentHomeView {
  const home = useStudentHome();
  const inbox = useNotifications({ limit: 30 });
  const submissions = useSubmissions();
  const session = useSessionStore();
  const [refreshing, setRefreshing] = useState(false);

  const refetchHome = home.refetch;
  const refetchInbox = inbox.refetch;
  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await Promise.all([refetchHome(), refetchInbox()]);
    } finally {
      setRefreshing(false);
    }
  }, [refetchHome, refetchInbox]);

  const data = home.data;
  const activeInstitute =
    session.institutes.find((row) => row.institute.id === session.activeInstituteId)?.institute ??
    session.institutes[0]?.institute ??
    null;

  const dueToday = useMemo(() => (data ? dueTasksOf(data) : []), [data]);
  const dueSummary = useMemo(() => dueSummaryLabel(dueToday), [dueToday]);
  const todayClasses = useMemo(() => (data ? todayClassesOf(data) : []), [data]);
  const newMaterials = useMemo(() => (data ? materialsOf(data) : []), [data]);
  const progressLine = useMemo(() => (data ? progressLineOf(data.progress) : ''), [data]);

  const unreadCount = inbox.data ? inbox.unread : (data?.unreadNotifications ?? 0);

  const hero: StudentHeroView = {
    greeting: studentGreeting(data?.studentName ?? session.user?.fullName),
    classLabel: data?.classLabel ?? '',
    studentName: data?.studentName ?? session.user?.fullName ?? 'Student',
    avatarUrl: data?.photoUrl ?? session.user?.avatarUrl ?? null,
    unreadNotifications: unreadCount,
    attendancePercent: data?.attendancePercent ?? null,
    nextTest: nextTestView(data?.nextTest ?? null),
    activeInstituteName: activeInstitute?.name ?? 'Institute',
    canSwitchInstitute: session.institutes.length > 1,
    institutes: session.institutes,
  };

  const studentId = data?.studentId ?? null;
  const submitMutation = submissions.submit;
  const submitHomework = useCallback(
    async (assignmentId: ID, content?: string | null): Promise<boolean> => {
      if (!studentId) return false;
      const result = await submitMutation({
        assignmentId,
        studentId,
        content: content?.trim() ? content.trim() : null,
      });
      if (result.ok) {
        await refetchHome();
        return true;
      }
      return false;
    },
    [studentId, submitMutation, refetchHome],
  );

  let status: StudentHomeStatus;
  if (data) status = 'ready';
  else status = home.error && !home.loading ? 'error' : 'loading';

  return {
    status,
    hero,
    dueToday,
    dueSummary,
    todayClasses,
    newMaterials,
    progressLine,
    progress: data?.progress ?? null,
    notifications: inbox.data?.items ?? [],
    submitting: submissions.saving,
    submitHomework,
    markNotificationRead: (id) => {
      void inbox.markRead(id);
    },
    markAllNotificationsRead: () => {
      void inbox.markAllRead();
    },
    errorMessage: home.error?.message ?? null,
    refreshing,
    refresh,
  };
}
