import React from 'react';
import { View, Pressable, StyleSheet, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import { getMaterialIcon, type MaterialCardView } from '../model';

interface Props {
  item: MaterialCardView;
  onToggleOffline: () => void;
  onToggleBookmark: () => void;
  onDownload: () => void;
  onPress: () => void;
}

export function MaterialCard({ item, onToggleOffline, onToggleBookmark, onDownload, onPress }: Props) {
  const iconName = getMaterialIcon(item.type);
  return (
    <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.92 : 1, flex: 1 })}>
      <Card flat style={styles.card}>
        <View style={styles.topRow}>
          <View style={styles.iconBox}>
            <Ionicons name={iconName as any} size={20} color={C.primary} />
          </View>
          <View style={styles.actions}>
            <Pressable onPress={onToggleBookmark} hitSlop={8}>
              <Ionicons name={item.isBookmarked ? 'bookmark' : 'bookmark-outline'} size={18} color={item.isBookmarked ? C.accent : C.muted} />
            </Pressable>
            <Pressable onPress={onDownload} hitSlop={8}>
              <Ionicons name="download-outline" size={18} color={C.secondary} />
            </Pressable>
          </View>
        </View>

        <Text variant="title" weight={700} numberOfLines={2} c={C.ink} style={{ marginTop: 8, minHeight: 38 }}>
          {item.title}
        </Text>
        <Text variant="caption" c={C.secondary} numberOfLines={1} style={{ marginTop: 4 }}>
          {item.sizeLabel}
        </Text>

        {item.subjectName ? (
          <View style={styles.subjectChip}>
            <Text variant="label" weight={600} c={C.primary}>
              {item.subjectName}
            </Text>
          </View>
        ) : null}

        <View style={styles.bottomRow}>
          <Text variant="label" weight={600} c={C.muted}>
            Offline
          </Text>
          <Switch
            value={item.isOffline}
            onValueChange={onToggleOffline}
            thumbColor={item.isOffline ? C.primary : C.surface}
            trackColor={{ false: C.track, true: C.navySoft }}
            style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
          />
        </View>
      </Card>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    padding: 14,
    gap: 4,
    minHeight: 160,
    justifyContent: 'space-between',
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  iconBox: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: C.navySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
  },
  subjectChip: {
    alignSelf: 'flex-start',
    backgroundColor: C.track,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginTop: 6,
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: C.hairline,
  },
});
