import { useCallback, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useMaterials, useSubjects, useSession } from '@/core/backend';
import type { Bookmark, ID, Material } from '@/core/contracts/models';
import { useBackend } from '@/core/backend';
import { toMaterialCardView, type MaterialCardView, type MaterialTab } from './model';

const OFFLINE_KEY = 'gf.offline.materials.v1';
const BOOKMARKS_KEY = 'gf.bookmarks.materials.v1';

export function useOfflineMaterials() {
  const [offlineIds, setOfflineIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(OFFLINE_KEY);
        if (raw) {
          const arr = JSON.parse(raw) as string[];
          setOfflineIds(new Set(arr));
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  const persist = useCallback(async (next: Set<string>) => {
    setOfflineIds(new Set(next));
    try {
      await AsyncStorage.setItem(OFFLINE_KEY, JSON.stringify([...next]));
    } catch {}
  }, []);

  const toggleOffline = useCallback(
    async (id: string) => {
      const next = new Set(offlineIds);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      await persist(next);
      return next.has(id);
    },
    [offlineIds, persist],
  );

  return { offlineIds, loading: loading, toggleOffline };
}

export function useStudentMaterialsBoard() {
  const materialsQ = useMaterials({ limit: 100 } as any);
  const subjectsQ = useSubjects({ limit: 50 } as any);
  const sessionQ = useSession();
  const { backend, instituteId } = useBackend();
  const { offlineIds, toggleOffline } = useOfflineMaterials();

  const [subjectFilter, setSubjectFilter] = useState<string>('All');
  const [tab, setTab] = useState<MaterialTab>('materials');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const subjectMap = useMemo(() => {
    const map = new Map<string, string>();
    (subjectsQ.data?.items ?? []).forEach((s: any) => map.set(s.id, s.name));
    return map;
  }, [subjectsQ.data]);

  const subjectNameLookup = useCallback(
    (id: string | null) => {
      if (!id) return null;
      return subjectMap.get(id) ?? null;
    },
    [subjectMap],
  );

  const fetchBookmarks = useCallback(async () => {
    if (!instituteId) return;
    const userId = sessionQ.data?.user?.id;
    if (!userId) return;
    try {
      const list = await backend.materials.listBookmarks(instituteId as ID, userId as ID);
      setBookmarks(list);
    } catch {}
  }, [backend, instituteId, sessionQ.data]);

  useEffect(() => {
    fetchBookmarks();
  }, [fetchBookmarks]);

  const allCards = useMemo(() => {
    const items = (materialsQ.data?.items ?? []) as Material[];
    return items.map((m) => toMaterialCardView(m, bookmarks, offlineIds, subjectNameLookup));
  }, [materialsQ.data, bookmarks, offlineIds, subjectNameLookup]);

  const filteredBySubject = useMemo(() => {
    if (subjectFilter === 'All') return allCards;
    return allCards.filter((c) => (c.subjectName ?? '').toLowerCase().includes(subjectFilter.toLowerCase()));
  }, [allCards, subjectFilter]);

  const visibleCards = useMemo(() => {
    if (tab === 'bookmarks') {
      return allCards.filter((c) => c.isBookmarked);
    }
    return filteredBySubject;
  }, [tab, allCards, filteredBySubject]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await Promise.all([materialsQ.refetch(), subjectsQ.refetch(), fetchBookmarks()]);
    } finally {
      setRefreshing(false);
    }
  }, [materialsQ, subjectsQ, fetchBookmarks]);

  const toggleBookmark = useCallback(
    async (card: MaterialCardView) => {
      if (!instituteId) return;
      const userId = sessionQ.data?.user?.id as ID;
      if (!userId) return;
      try {
        if (card.isBookmarked && card.bookmarkId) {
          await backend.materials.removeBookmark(instituteId as ID, card.bookmarkId as ID);
          setBookmarks((prev) => prev.filter((b) => b.id !== card.bookmarkId));
        } else {
          const bm = await backend.materials.addBookmark(instituteId as ID, {
            userId,
            targetType: 'material',
            targetId: card.id as ID,
            note: null,
          });
          setBookmarks((prev) => [...prev, bm]);
        }
      } catch (e) {
        console.warn('bookmark failed', e);
      }
    },
    [backend, instituteId, sessionQ.data],
  );

  return {
    loading: materialsQ.loading && !materialsQ.data,
    error: materialsQ.error ? (materialsQ.error.message ?? 'Failed') : null,
    refreshing,
    refresh,
    subjectFilter,
    setSubjectFilter,
    tab,
    setTab,
    visibleCards,
    allCount: allCards.length,
    bookmarkCount: allCards.filter((c) => c.isBookmarked).length,
    offlineIds,
    toggleOffline,
    toggleBookmark,
  };
}
