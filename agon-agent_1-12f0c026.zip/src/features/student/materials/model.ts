import type { Material, Bookmark } from '@/core/contracts/models';
import { C } from '@/lib/theme';

export type MaterialTab = 'materials' | 'bookmarks';

export interface MaterialCardView {
  id: string;
  title: string;
  description: string | null;
  type: Material['materialType'];
  subjectName: string | null;
  topic: string | null;
  sizeLabel: string; // "2.4 MB · 12 Nov"
  fileSize: number | null;
  isBookmarked: boolean;
  bookmarkId: string | null;
  isOffline: boolean;
  url: string | null;
  raw: Material;
}

function formatBytes(bytes: number | null | undefined): string {
  if (!bytes || bytes <= 0) return 'PDF';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
  } catch {
    return '';
  }
}

export function toMaterialCardView(
  m: Material,
  bookmarks: Bookmark[],
  offlineIds: Set<string>,
  subjectNameLookup: (id: string | null) => string | null,
): MaterialCardView {
  const bm = bookmarks.find((b) => b.targetType === 'material' && b.targetId === m.id);
  const size = formatBytes((m as any).sizeBytes ?? null);
  const date = formatDate(m.createdAt);
  const sizeLabel = date ? `${size} · ${date}` : size;
  return {
    id: m.id,
    title: m.title,
    description: m.description,
    type: m.materialType,
    subjectName: subjectNameLookup(m.subjectId),
    topic: m.topic,
    sizeLabel,
    fileSize: (m as any).sizeBytes ?? null,
    isBookmarked: !!bm,
    bookmarkId: bm?.id ?? null,
    isOffline: offlineIds.has(m.id),
    url: m.url,
    raw: m,
  };
}

export function getMaterialIcon(type: Material['materialType']): string {
  switch (type) {
    case 'pdf':
      return 'document-text';
    case 'video':
      return 'play-circle';
    case 'notes':
      return 'reader';
    case 'worksheet':
      return 'create';
    case 'book':
      return 'book';
    case 'link':
      return 'link';
    default:
      return 'document';
  }
}

export const SUBJECT_FILTERS = ['All', 'Mathematics', 'Physics', 'Chemistry', 'English', 'Biology'];
