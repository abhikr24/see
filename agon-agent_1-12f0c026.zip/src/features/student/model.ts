import type { Ionicons } from '@expo/vector-icons';

import type {
  StudentDueTask,
  StudentExamScore,
  StudentGoalProgress,
  StudentHome,
  StudentMaterialThumb,
  StudentProgressSummary,
  StudentTodayClass,
  StudentUpcomingTest,
} from '@/core/contracts/models';
import { pct, timeShort } from '@/lib/format';

export type IconName = keyof typeof Ionicons.glyphMap;

export interface DueTaskCardView {
  id: string;
  title: string;
  subtitle: string;
  subjectName: string | null;
  description: string | null;
  maxMarks: number;
  isDone: boolean;
  statusLabel: string;
  task: StudentDueTask;
}

export interface TodayClassRowView {
  key: string;
  clock: string;
  meridiem: string;
  subject: string;
  meta: string;
  timeRange: string;
  item: StudentTodayClass;
}

export interface MaterialThumbView {
  key: string;
  title: string;
  subtitle: string;
  subjectName: string | null;
  typeLabel: string;
  typeIcon: IconName;
  item: StudentMaterialThumb;
}

export interface NextTestView {
  hasTest: boolean;
  headline: string;
  detail: string;
}

export interface ExamScoreRowView {
  key: string;
  examName: string;
  subjectName: string | null;
  scoreLabel: string;
  percentLabel: string;
  isAbsent: boolean;
}

export function studentGreeting(fullName: string | null | undefined): string {
  const first = fullName?.trim().split(/\s+/)[0];
  return first ? `Hello, ${first}` : 'Hello';
}

export function nextTestView(nextTest: StudentUpcomingTest | null): NextTestView {
  if (!nextTest) {
    return {
      hasTest: false,
      headline: 'No upcoming tests',
      detail: 'Steady progress every day',
    };
  }
  const headline =
    nextTest.daysUntil === 0
      ? 'Test today'
      : nextTest.daysUntil === 1
        ? 'Next test tomorrow'
        : `Next test in ${nextTest.daysUntil} days`;
  const detail = [nextTest.name, nextTest.subjectName].filter(Boolean).join(' · ');
  return { hasTest: true, headline, detail };
}

export function dueClockLabel(dueAt: string | null): string {
  if (!dueAt) return 'Due today';
  const timePart = dueAt.slice(11, 16);
  if (!timePart) return 'Due today';
  return `Due ${timeShort(timePart)}`;
}

export function dueTasksOf(home: StudentHome): DueTaskCardView[] {
  return home.dueToday.map((task) => ({
    id: task.assignmentId,
    title: task.title,
    subtitle: [task.subjectName ?? task.batchName, dueClockLabel(task.dueAt)].filter(Boolean).join(' · '),
    subjectName: task.subjectName,
    description: task.description,
    maxMarks: task.maxMarks,
    isDone: task.isDone,
    statusLabel:
      task.submissionStatus === 'returned' && task.marksAwarded !== null
        ? `Submitted · ${task.marksAwarded}/${task.maxMarks}`
        : 'Submitted',
    task,
  }));
}

export function dueSummaryLabel(tasks: readonly DueTaskCardView[]): string | null {
  if (tasks.length === 0) return null;
  const done = tasks.filter((t) => t.isDone).length;
  if (done === tasks.length) return `All ${done} done`;
  if (done > 0) return `${done} of ${tasks.length} done`;
  return `${tasks.length} to turn in`;
}

export function todayClassesOf(home: StudentHome): TodayClassRowView[] {
  return home.todayClasses.map((item) => {
    const [clock, meridiem = ''] = timeShort(item.startsAt).split(' ');
    return {
      key: item.id,
      clock,
      meridiem,
      subject: item.subjectName,
      meta: [item.teacherName, item.roomName].filter(Boolean).join(' · ') || item.batchName,
      timeRange: `${timeShort(item.startsAt)} – ${timeShort(item.endsAt)}`,
      item,
    };
  });
}

const MATERIAL_META: Record<StudentMaterialThumb['materialType'], { label: string; icon: IconName }> = {
  pdf: { label: 'PDF', icon: 'document-text-outline' },
  notes: { label: 'Notes', icon: 'reader-outline' },
  video: { label: 'Video', icon: 'play-circle-outline' },
  link: { label: 'Link', icon: 'link-outline' },
  worksheet: { label: 'Worksheet', icon: 'create-outline' },
  book: { label: 'Book', icon: 'book-outline' },
};

export function materialsOf(home: StudentHome): MaterialThumbView[] {
  return home.newMaterials.map((item) => {
    const meta = MATERIAL_META[item.materialType] ?? MATERIAL_META.notes;
    return {
      key: item.id,
      title: item.title,
      subtitle: [item.subjectName, item.topic].filter(Boolean).join(' · ') || meta.label,
      subjectName: item.subjectName,
      typeLabel: meta.label,
      typeIcon: meta.icon,
      item,
    };
  });
}

export function progressLineOf(progress: StudentProgressSummary): string {
  const att = progress.attendancePercent !== null ? `Attendance ${pct(progress.attendancePercent)}` : 'Attendance —';
  const avg = progress.averagePercent !== null ? `Average ${pct(progress.averagePercent)}` : 'Average —';
  const goals = `${progress.goalsOnTrack} ${progress.goalsOnTrack === 1 ? 'goal' : 'goals'} on track`;
  return `${att} · ${avg} · ${goals}`;
}

export function examScoresOf(scores: readonly StudentExamScore[]): ExamScoreRowView[] {
  return scores.map((s) => ({
    key: s.examId,
    examName: s.examName,
    subjectName: s.subjectName,
    scoreLabel: s.isAbsent ? 'Absent' : `${s.marksObtained}/${s.maxMarks}`,
    percentLabel: s.isAbsent ? '—' : `${Math.round(s.percentage)}%`,
    isAbsent: s.isAbsent,
  }));
}

export function goalDetailLabel(goal: StudentGoalProgress): string {
  if (goal.targetValue === null) return goal.onTrack ? 'On track' : 'Active';
  const suffix = goal.metric === 'attendance_percent' || goal.metric === 'exam_percent' ? '%' : '';
  const current = goal.currentValue !== null ? `${Math.round(goal.currentValue)}${suffix}` : '—';
  return `${current} / ${Math.round(goal.targetValue)}${suffix}`;
}
