import React, { useState } from 'react';
import { RefreshControl, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Card, ErrorState, InstituteSwitcher, Text } from '@/components/ui';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { DueTodaySection } from '../components/DueTodaySection';
import { NewMaterialSection } from '../components/NewMaterialSection';
import { ProgressSummarySection } from '../components/ProgressSummarySection';
import {
  JoinClassSheet,
  MaterialDetailSheet,
  NotificationsSheet,
  SubmitHomeworkSheet,
} from '../components/StudentActionSheets';
import { StudentHero } from '../components/StudentHero';
import { StudentHomeSkeleton } from '../components/StudentHomeSkeleton';
import { StudentProgressSheet } from '../components/StudentProgressSheet';
import { TodayClassesSection } from '../components/TodayClassesSection';
import { useStudentHomeView } from '../hooks/useStudentHomeView';
import type { DueTaskCardView, MaterialThumbView, TodayClassRowView } from '../model';

/** Clears the floating tab bar the student shell draws over the bottom of every tab. */
const TAB_BAR_INSET = 136;

function StaleNotice({ message }: { message: string }) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        paddingVertical: 12,
        paddingHorizontal: 14,
        borderRadius: R.btn,
        backgroundColor: C.warningSoft,
      }}
    >
      <Ionicons name="cloud-offline-outline" size={18} color={C.duesInk} />
      <Text variant="caption" c={C.duesInk} weight={600} style={{ flex: 1 }}>
        Showing your last loaded schedule. {message}
      </Text>
    </View>
  );
}

/**
 * Student home (shape A): encouraging overview leading with what is done,
 * ordered strictly: Due today -> Today's classes -> New material -> Your progress.
 */
export function StudentHomeScreen() {
  const view = useStudentHomeView();
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const [bellOpen, setBellOpen] = useState(false);
  const [progressOpen, setProgressOpen] = useState(false);
  const [submittingTask, setSubmittingTask] = useState<DueTaskCardView | null>(null);
  const [joiningClass, setJoiningClass] = useState<TodayClassRowView | null>(null);
  const [viewingMaterial, setViewingMaterial] = useState<MaterialThumbView | null>(null);

  return (
    <>
      <ScrollView
        style={{ flex: 1, backgroundColor: C.canvas }}
        contentContainerStyle={{
          paddingHorizontal: LAYOUT.margin,
          paddingTop: 8,
          paddingBottom: TAB_BAR_INSET,
          gap: S.xxl,
          flexGrow: 1,
        }}
        refreshControl={
          <RefreshControl
            refreshing={view.refreshing}
            onRefresh={() => void view.refresh()}
            tintColor={C.primary}
            colors={[C.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {view.status === 'loading' ? <StudentHomeSkeleton /> : null}

        {view.status === 'error' ? (
          <Card flat>
            <ErrorState
              title="Could not load your home"
              message={view.errorMessage ?? 'Something went wrong.'}
              onRetry={() => void view.refresh()}
            />
          </Card>
        ) : null}

        {view.status === 'ready' ? (
          <>
            <StudentHero
              hero={view.hero}
              onOpenBell={() => setBellOpen(true)}
              onOpenSwitcher={() => setSwitcherOpen(true)}
            />

            {view.errorMessage ? <StaleNotice message={view.errorMessage} /> : null}

            <DueTodaySection
              tasks={view.dueToday}
              summaryLabel={view.dueSummary}
              onSubmitTask={setSubmittingTask}
              onSeeAllHomework={() => router.push('/(student)/homework' as never)}
            />

            <TodayClassesSection rows={view.todayClasses} onJoin={setJoiningClass} />

            <NewMaterialSection items={view.newMaterials} onOpenMaterial={setViewingMaterial} />

            <ProgressSummarySection
              line={view.progressLine}
              onOpenProgress={() => setProgressOpen(true)}
            />
          </>
        ) : null}
      </ScrollView>

      <InstituteSwitcher visible={switcherOpen} onClose={() => setSwitcherOpen(false)} />

      <NotificationsSheet
        visible={bellOpen}
        notifications={view.notifications}
        onClose={() => setBellOpen(false)}
        onMarkRead={view.markNotificationRead}
        onMarkAllRead={view.markAllNotificationsRead}
      />

      <SubmitHomeworkSheet
        task={submittingTask}
        submitting={view.submitting}
        onClose={() => setSubmittingTask(null)}
        onConfirm={async (assignmentId, note) => {
          const ok = await view.submitHomework(assignmentId, note);
          if (ok) setSubmittingTask(null);
        }}
      />

      <JoinClassSheet session={joiningClass} onClose={() => setJoiningClass(null)} />

      <MaterialDetailSheet material={viewingMaterial} onClose={() => setViewingMaterial(null)} />

      <StudentProgressSheet
        visible={progressOpen}
        progress={view.progress}
        onClose={() => setProgressOpen(false)}
        onOpenResults={() => {
          setProgressOpen(false);
          router.push('/(student)/results' as never);
        }}
      />
    </>
  );
}
