import React, { useEffect, useState } from 'react';
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Badge, Button, Text } from '@/components/ui';
import { useAttachments } from '@/core/backend';
import { C, LAYOUT, R } from '@/lib/theme';
import type { TeacherDoubtRow } from '../teacher-tools';

interface Props {
  row: TeacherDoubtRow | null;
  visible: boolean;
  sending: boolean;
  onClose: () => void;
  onSend: (answer: string) => void;
}

export function DoubtDetailModal({ row, visible, sending, onClose, onSend }: Props) {
  const [reply, setReply] = useState('');
  const [imageUrls, setImageUrls] = useState<Record<string, string>>({});
  const attachments = useAttachments('doubt', row?.id ?? null);

  useEffect(() => {
    setReply('');
    setImageUrls({});
  }, [row?.id]);

  useEffect(() => {
    const files = attachments.data ?? [];
    let active = true;
    void Promise.all(
      files.map(async (file) => {
        const url = await attachments.openUrl(file);
        return [file.id, url] as const;
      }),
    ).then((entries) => {
      if (!active) return;
      setImageUrls(Object.fromEntries(entries.filter((entry): entry is [string, string] => Boolean(entry[1]))));
    });
    return () => {
      active = false;
    };
  }, [attachments.data]);

  if (!row) return null;

  const send = () => {
    const body = reply.trim();
    if (!body || sending) return;
    onSend(body);
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={12}
        >
          <View style={styles.header}>
            <Pressable onPress={onClose} hitSlop={12} accessibilityLabel="Close doubt">
              <Ionicons name="chevron-back" size={24} color={C.primary} />
            </Pressable>
            <Text variant="title" weight={700} style={{ flex: 1 }}>Student question</Text>
            <Badge label={row.status === 'open' ? 'Waiting' : 'Answered'} tone={row.status === 'open' ? 'warning' : 'success'} small />
          </View>

          <View style={{ flex: 1, padding: LAYOUT.margin, gap: 16 }}>
            <View style={styles.studentRow}>
              <Avatar name={row.studentName} uri={row.studentPhotoUrl} size={44} />
              <View style={{ flex: 1, gap: 3 }}>
                <Text variant="title" weight={700}>{row.studentName}</Text>
                <Text variant="caption" c={C.secondary}>{row.subjectName} · {row.timeLabel}</Text>
              </View>
            </View>

            <View style={styles.questionCard}>
              <Text variant="body" c={C.ink} style={{ fontSize: 17, lineHeight: 25 }}>{row.question}</Text>
            </View>

            {attachments.data?.map((file) => {
              const url = imageUrls[file.id];
              if (!url || !file.mimeType?.startsWith('image/')) return null;
              return (
                <Image
                  key={file.id}
                  source={{ uri: url }}
                  contentFit="cover"
                  style={{ width: '100%', height: 220, borderRadius: R.card }}
                />
              );
            })}

            {row.answer ? (
              <View style={styles.answerCard}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Ionicons name="checkmark-circle" size={20} color={C.success} />
                  <Text variant="label" c={C.success}>Your reply</Text>
                </View>
                <Text variant="body" c={C.ink} style={{ lineHeight: 22 }}>{row.answer}</Text>
              </View>
            ) : null}

            <View style={{ flex: 1 }} />
          </View>

          {row.status === 'open' ? (
            <View style={styles.composer}>
              <TextInput
                value={reply}
                onChangeText={setReply}
                placeholder="Write a clear answer…"
                placeholderTextColor={C.muted}
                multiline
                maxLength={1200}
                style={styles.input}
                accessibilityLabel="Reply to student"
              />
              <Button
                title="Send"
                icon="send"
                size="md"
                full={false}
                loading={sending}
                disabled={!reply.trim()}
                onPress={send}
              />
            </View>
          ) : null}
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}

const styles = {
  header: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 10,
    paddingHorizontal: LAYOUT.margin,
    paddingVertical: 12,
    backgroundColor: C.surface,
    borderBottomWidth: 1,
    borderBottomColor: C.hairline,
  },
  studentRow: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 12 },
  questionCard: {
    backgroundColor: C.surface,
    borderRadius: R.card,
    borderWidth: 1,
    borderColor: C.hairline,
    padding: 18,
  },
  answerCard: {
    backgroundColor: C.successSoft,
    borderRadius: R.card,
    borderWidth: 1,
    borderColor: C.success,
    padding: 16,
    gap: 10,
  },
  composer: {
    flexDirection: 'row' as const,
    alignItems: 'flex-end' as const,
    gap: 10,
    padding: 12,
    paddingHorizontal: LAYOUT.margin,
    backgroundColor: C.surface,
    borderTopWidth: 1,
    borderTopColor: C.hairline,
  },
  input: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    borderRadius: R.field,
    borderWidth: 1,
    borderColor: C.hairline,
    backgroundColor: C.canvas,
    color: C.ink,
    fontSize: 15,
    paddingHorizontal: 14,
    paddingVertical: 12,
    textAlignVertical: 'top' as const,
  },
};
