import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Avatar, Badge, Card, EmptyState, ErrorState, ListSkeleton, SegmentedControl, Text } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';
import { DoubtDetailModal } from './components/DoubtDetailModal';
import { useTeacherDoubts } from './hooks/useTeacherDoubts';
import type { DoubtSegment, TeacherDoubtRow } from './teacher-tools';

const TAB_BAR_INSET = 136;

export function TeacherDoubtsScreen() {
  const view = useTeacherDoubts();
  const [segment, setSegment] = useState<DoubtSegment>('open');
  const [selected, setSelected] = useState<TeacherDoubtRow | null>(null);
  const rows = useMemo(() => view.filter(segment), [segment, view]);

  const headerStat = `${view.waiting} waiting · average reply ${
    view.averageReply === null ? '—' : `${view.averageReply}h`
  }`;

  const send = async (answer: string) => {
    if (!selected) return;
    const result = await view.answer({ id: selected.id, answer });
    if (result.ok) setSelected(null);
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList<TeacherDoubtRow>
        data={rows}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{
          paddingHorizontal: LAYOUT.margin,
          paddingTop: 8,
          paddingBottom: TAB_BAR_INSET,
          gap: 12,
          flexGrow: 1,
        }}
        refreshControl={
          <RefreshControl refreshing={view.loading && Boolean(view.rows)} onRefresh={() => void view.refetch()} tintColor={C.primary} />
        }
        ListHeaderComponent={
          <View style={{ gap: 14, paddingBottom: 4 }}>
            <Pressable
              onPress={() => (router.canGoBack() ? router.back() : router.replace('/(teacher)' as never))}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
            >
              <Ionicons name="chevron-back" size={18} color={C.secondary} />
              <Text variant="body" weight={600} c={C.secondary}>Teacher home</Text>
            </Pressable>
            <View>
              <Text variant="h1">Doubts</Text>
              <Text variant="caption" c={C.secondary}>Questions from students in your classes</Text>
            </View>
            <Card flat pad={14} style={{ backgroundColor: C.primary, borderColor: C.primary }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Ionicons name="chatbubbles-outline" size={21} color={C.surface} />
                <Text variant="body" weight={700} c={C.surface} tabular>{headerStat}</Text>
              </View>
            </Card>
            <SegmentedControl
              value={segment}
              onChange={setSegment}
              options={[
                { key: 'open', label: 'Open', count: view.waiting },
                { key: 'answered', label: 'Answered', count: view.answered },
                { key: 'all', label: 'All', count: view.waiting + view.answered },
              ]}
            />
          </View>
        }
        renderItem={({ item }) => (
          <Pressable
            onPress={() => setSelected(item)}
            accessibilityRole="button"
            accessibilityLabel={`Question from ${item.studentName}`}
            style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}
          >
            <Card pad={14}>
              <View style={{ flexDirection: 'row', gap: 12 }}>
                <View>
                  <Avatar name={item.studentName} uri={item.studentPhotoUrl} size={44} />
                  {item.status === 'open' ? <View style={styles.redDot} /> : null}
                </View>
                <View style={{ flex: 1, gap: 6 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text variant="title" weight={700} numberOfLines={1} style={{ flex: 1 }}>{item.studentName}</Text>
                    <Badge label={item.subjectName} tone="primary" small />
                  </View>
                  <Text variant="body" c={C.ink} numberOfLines={2}>{item.question}</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text variant="caption" c={C.secondary}>{item.timeLabel}</Text>
                    {item.ageBadge ? <Badge label={item.ageBadge} tone="warning" small /> : null}
                    {item.status === 'answered' ? <Ionicons name="checkmark-circle" size={16} color={C.success} /> : null}
                  </View>
                </View>
              </View>
            </Card>
          </Pressable>
        )}
        ListEmptyComponent={
          view.loading && !view.rows.length ? (
            <ListSkeleton rows={4} h={104} />
          ) : view.error && !view.rows.length ? (
            <ErrorState message={view.error.message} onRetry={() => void view.refetch()} />
          ) : (
            <EmptyState
              icon="checkmark-done-circle-outline"
              title={segment === 'open' ? 'All questions answered' : 'No questions here'}
              text="New student questions will appear here."
            />
          )
        }
        showsVerticalScrollIndicator={false}
      />

      <DoubtDetailModal
        row={selected}
        visible={Boolean(selected)}
        sending={view.answering}
        onClose={() => setSelected(null)}
        onSend={(answer) => void send(answer)}
      />
    </View>
  );
}

const styles = {
  redDot: {
    position: 'absolute' as const,
    right: -1,
    top: -1,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: C.danger,
    borderWidth: 2,
    borderColor: C.surface,
  },
};
