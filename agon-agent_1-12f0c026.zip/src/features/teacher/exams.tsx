import React from 'react';
import { FlatList, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Badge, Button, Card, EmptyState, ErrorState, ListSkeleton, ProgressBar, Text } from '@/components/ui';
import { dateShort } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { useTeacherExams } from './hooks/useTeacherExams';
import type { TeacherExamRow } from './teacher-tools';

const TAB_BAR_INSET = 136;

export function TeacherExamsScreen() {
  const view = useTeacherExams();

  const openMarks = (exam: TeacherExamRow) => {
    router.push({ pathname: '/(teacher)/exams', params: { id: exam.id } } as never);
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList<TeacherExamRow>
        data={view.items}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: TAB_BAR_INSET, gap: 12, flexGrow: 1 }}
        refreshControl={<RefreshControl refreshing={view.loading && Boolean(view.items)} onRefresh={() => void view.refetch()} tintColor={C.primary} />}
        ListHeaderComponent={
          <View style={{ gap: 4, paddingBottom: 8 }}>
            <Text variant="h1">Exams</Text>
            <Text variant="caption" c={C.secondary}>Only exams assigned to your classes</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Card pad={16}>
            <Pressable onPress={() => openMarks(item)} accessibilityRole="button" accessibilityLabel={`Enter marks for ${item.name}`}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 13 }}>
                <View style={styles.icon}>
                  <Ionicons name="document-text-outline" size={22} color={C.primary} />
                </View>
                <View style={{ flex: 1, gap: 5 }}>
                  <Text variant="title" weight={700} numberOfLines={1}>{item.name}</Text>
                  <Text variant="caption" c={C.secondary} numberOfLines={1}>{item.subjectName} · {item.batchName}</Text>
                  <View style={{ flexDirection: 'row', gap: 6, marginTop: 2 }}>
                    <Badge label={item.startsOn ? dateShort(item.startsOn) : 'No date'} tone="primary" small />
                    <Badge label={item.marksLabel} tone={item.marksLabel === 'Published' ? 'teal' : 'warning'} small />
                  </View>
                </View>
                <Ionicons name="chevron-forward" size={18} color={C.muted} />
              </View>
            </Pressable>
            {item.totalStudents > 0 && item.entered < item.totalStudents ? (
              <View style={{ marginTop: 13, gap: 6 }}>
                <ProgressBar value={item.entered / item.totalStudents} tone="accent" height={5} />
                <Text variant="caption" weight={600} c={C.accent} tabular>{item.entered} of {item.totalStudents} entered</Text>
              </View>
            ) : null}
            <Button title="Enter marks" icon="create-outline" variant="outline" size="sm" onPress={() => openMarks(item)} />
          </Card>
        )}
        ListEmptyComponent={
          view.loading && !view.items.length ? <ListSkeleton rows={4} h={126} /> : view.error && !view.items.length ? (
            <ErrorState message={view.error.message} onRetry={() => void view.refetch()} />
          ) : (
            <EmptyState icon="document-text-outline" title="No exams in your classes" text="Exams assigned to your batches will appear here." />
          )
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = {
  icon: {
    width: 46,
    height: 46,
    borderRadius: R.field,
    backgroundColor: C.navySoft,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
};
