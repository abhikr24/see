import { useMemo } from 'react';

import type { Doubt } from '@/core/contracts/models';
import { useDomainMutation, useDomainQuery } from '@/core/hooks/domain';
import { averageReplyHours, doubtRow, type DoubtSegment, type TeacherDoubtRow } from '../teacher-tools';

export interface TeacherDoubtsData {
  rows: TeacherDoubtRow[];
  waiting: number;
  answered: number;
  averageReply: number | null;
}

export function useTeacherDoubts() {
  const query = useDomainQuery<TeacherDoubtsData>('teacherDoubts', ['list'], async (backend, instituteId) => {
    const page = await backend.doubts.list(instituteId, { limit: 200 });
    const rows = await Promise.all(
      page.items.map(async (doubt) => {
        const [student, subject] = await Promise.all([
          backend.students.get(instituteId, doubt.studentId),
          doubt.subjectId ? backend.subjects.get(instituteId, doubt.subjectId) : Promise.resolve(null),
        ]);
        return doubtRow(doubt, student, subject?.name ?? 'General');
      }),
    );
    const answered = page.items.filter((doubt) => doubt.status === 'answered');
    return {
      rows,
      waiting: page.items.filter((doubt) => doubt.status === 'open').length,
      answered: answered.length,
      averageReply: averageReplyHours(page.items),
    };
  });

  const answer = useDomainMutation<{ id: string; answer: string }, Doubt>(
    ['teacherDoubts', 'doubts', 'notifications'],
    (backend, instituteId, input) => backend.doubts.answer(instituteId, input.id, input.answer),
    { success: 'Reply sent · student notified', failure: 'Could not send the reply' },
  );

  const rows = query.data?.rows ?? [];
  const filter = (segment: DoubtSegment) => {
    if (segment === 'open') return rows.filter((row) => row.status === 'open');
    if (segment === 'answered') return rows.filter((row) => row.status === 'answered');
    return rows;
  };

  return {
    ...query,
    rows,
    filter,
    waiting: query.data?.waiting ?? 0,
    answered: query.data?.answered ?? 0,
    averageReply: query.data?.averageReply ?? null,
    answer: answer.mutate,
    answering: answer.loading,
  };
}
