import { useMemo } from 'react';

import { useDomainQuery } from '@/core/hooks/domain';
import { computeExamStats, resolveExamSubject } from '@/features/exams/model';
import type { TeacherExamRow } from '../teacher-tools';

export function useTeacherExams() {
  const query = useDomainQuery<TeacherExamRow[]>('teacherExams', ['list'], async (backend, instituteId) => {
    const [examPage, batches, subjects, markPage] = await Promise.all([
      backend.exams.list(instituteId, { limit: 200 }),
      backend.batches.listSummaries(instituteId),
      backend.subjects.list(instituteId, { limit: 100 }),
      backend.marks.list(instituteId, { limit: 1000 }),
    ]);
    const batchMap = new Map(batches.map((batch) => [batch.id, batch]));
    const marksByExam = new Map<string, typeof markPage.items>();
    for (const mark of markPage.items) {
      const list = marksByExam.get(mark.examId) ?? [];
      list.push(mark);
      marksByExam.set(mark.examId, list);
    }
    return examPage.items.map((exam): TeacherExamRow => {
      const batch = batchMap.get(exam.batchId);
      const examMarks = marksByExam.get(exam.id) ?? [];
      const { subjectName } = resolveExamSubject(exam, examMarks, batch, subjects.items);
      const stats = computeExamStats(exam, examMarks, batch?.studentCount ?? 0);
      return {
        id: exam.id,
        name: exam.name,
        subjectName,
        batchName: batch?.name ?? 'Your class',
        startsOn: exam.startsOn,
        totalMarks: exam.totalMarks ?? 100,
        entered: stats.entered,
        totalStudents: stats.totalStudents,
        marksLabel: stats.marksState.label,
      };
    });
  });

  const items = useMemo(
    () => [...(query.data ?? [])].sort((a, b) => (b.startsOn ?? '').localeCompare(a.startsOn ?? '')),
    [query.data],
  );
  return { ...query, items };
}
