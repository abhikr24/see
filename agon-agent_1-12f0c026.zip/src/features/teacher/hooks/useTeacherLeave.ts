import { useMemo } from 'react';

import type { LeaveType } from '@/core/contracts/models';
import { useMyLeaveRequests, useSubmitLeave } from '@/core/backend';
import { useDomainQuery } from '@/core/hooks/domain';
import type { AffectedClass } from '../teacher-tools';
import { leaveDayCount } from '../teacher-tools';

function addDays(date: string, count: number): string {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + count);
  return value.toISOString().slice(0, 10);
}

function dateLabel(date: string): string {
  return new Date(`${date}T00:00:00Z`).toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    timeZone: 'UTC',
  });
}

export function useTeacherLeave(from = '', to = '') {
  const history = useMyLeaveRequests();
  const submitMutation = useSubmitLeave();
  const validRange = Boolean(from && to && to >= from);

  const affected = useDomainQuery<AffectedClass[]>(
    'teacherLeaveClasses',
    ['affected', from, to],
    async (backend, instituteId) => {
      if (!validRange) return [];
      const [batches, subjects] = await Promise.all([
        backend.batches.listMine(instituteId),
        backend.subjects.list(instituteId, { limit: 100 }),
      ]);
      const ownIds = new Set(batches.map((batch) => batch.id));
      const batchMap = new Map(batches.map((batch) => [batch.id, batch]));
      const subjectMap = new Map(subjects.items.map((subject) => [subject.id, subject.name]));
      const rows: AffectedClass[] = [];
      const totalDays = Math.min(31, leaveDayCount(from, to));
      for (let index = 0; index < totalDays; index += 1) {
        const date = addDays(from, index);
        const dayOfWeek = new Date(`${date}T00:00:00Z`).getUTCDay();
        const periods = await backend.timetable.listForDay(instituteId, { dayOfWeek });
        for (const period of periods) {
          if (!ownIds.has(period.batchId)) continue;
          rows.push({
            id: `${date}:${period.id}`,
            date,
            dateLabel: dateLabel(date),
            subjectName: period.subjectId ? subjectMap.get(period.subjectId) ?? 'General' : 'General',
            batchName: batchMap.get(period.batchId)?.name ?? 'Your class',
            timeLabel: `${period.startsAt} – ${period.endsAt}`,
            substituteNeeded: true,
          });
        }
      }
      return rows.sort((a, b) => a.date.localeCompare(b.date) || a.timeLabel.localeCompare(b.timeLabel));
    },
    validRange,
  );

  const submit = async (input: {
    leaveType: LeaveType;
    fromDate: string;
    toDate: string;
    reason: string;
  }) => submitMutation.mutate(input);

  const requests = useMemo(() => {
    const items = history.data ?? [];
    return [...items].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [history.data]);

  return {
    history,
    requests,
    affected: affected.data ?? [],
    affectedLoading: affected.loading,
    submit,
    submitting: submitMutation.loading,
    dayCount: leaveDayCount(from, to),
  };
}
