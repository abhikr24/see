import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Badge, Button, Card, Chip, DateField, EmptyState, ErrorState, Input, ListSkeleton, Text } from '@/components/ui';
import type { LeaveRequest, LeaveType } from '@/core/contracts/models';
import { C, LAYOUT, R } from '@/lib/theme';
import { useTeacherLeave } from './hooks/useTeacherLeave';
import {
  LEAVE_TYPES,
  leaveDayCount,
  leaveRangeLabel,
  leaveStatusLabel,
  leaveStatusTone,
  leaveTypeLabel,
} from './teacher-tools';

export function TeacherLeaveScreen() {
  const [leaveType, setLeaveType] = useState<LeaveType>('casual');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [reason, setReason] = useState('');
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const view = useTeacherLeave(from, to);

  const submitted = useMemo(
    () => view.requests.find((request) => request.id === submittedId) ?? null,
    [submittedId, view.requests],
  );

  const submit = async () => {
    const result = await view.submit({
      leaveType,
      fromDate: from,
      toDate: to,
      reason,
    });
    if (result.ok) {
      setSubmittedId(result.data.id);
      setReason('');
    }
  };

  const reset = () => {
    setSubmittedId(null);
    setFrom('');
    setTo('');
    setReason('');
  };

  const canSubmit = Boolean(from && to && to >= from && reason.trim().length >= 3);

  const header = (
    <View style={{ gap: 14, paddingBottom: 4 }}>
      <Pressable
        onPress={() => (router.canGoBack() ? router.back() : router.replace('/(teacher)' as never))}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
      >
        <Ionicons name="chevron-back" size={18} color={C.secondary} />
        <Text variant="body" weight={600} c={C.secondary}>Teacher home</Text>
      </Pressable>
      <View>
        <Text variant="h1">Leave</Text>
        <Text variant="caption" c={C.secondary}>Request time away and see what needs cover</Text>
      </View>

      {submitted ? <StatusCard request={submitted} /> : null}

      {!submitted ? (
        <Card pad={16} style={{ gap: 16 }}>
          <View style={{ gap: 8 }}>
            <Text variant="title" weight={700}>Request leave</Text>
            <Text variant="caption" c={C.secondary}>Choose the type of leave</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              {LEAVE_TYPES.map((item) => (
                <Chip key={item.key} label={item.label} active={leaveType === item.key} onPress={() => setLeaveType(item.key)} />
              ))}
            </View>
          </View>

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <DateField label="From" value={from} onChange={(_, iso) => setFrom(iso)} />
            </View>
            <View style={{ flex: 1 }}>
              <DateField label="To" value={to} onChange={(_, iso) => setTo(iso)} minDate={from || undefined} />
            </View>
          </View>

          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text variant="caption" c={C.secondary}>Total duration</Text>
            <Text variant="title" weight={700} c={C.primary} tabular>{leaveDayCount(from, to)} {leaveDayCount(from, to) === 1 ? 'day' : 'days'}</Text>
          </View>

          <Input
            label="Reason"
            value={reason}
            onChangeText={setReason}
            placeholder="Tell the owner why you need leave"
            multiline
            maxLength={500}
            style={{ height: 92, textAlignVertical: 'top' }}
          />

          <View style={{ gap: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Text variant="title" weight={700}>Affected classes</Text>
              <Text variant="caption" c={C.secondary}>{view.affected.length} scheduled</Text>
            </View>
            {view.affectedLoading ? <ListSkeleton rows={1} h={72} /> : null}
            {!view.affectedLoading && view.affected.length === 0 ? (
              <View style={styles.emptyClasses}>
                <Ionicons name="calendar-outline" size={20} color={C.muted} />
                <Text variant="caption" c={C.secondary}>No classes in this date range</Text>
              </View>
            ) : null}
            {view.affected.map((item) => (
              <View key={item.id} style={styles.classRow}>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text variant="body" weight={700}>{item.subjectName} · {item.batchName}</Text>
                  <Text variant="caption" c={C.secondary}>{item.dateLabel} · {item.timeLabel}</Text>
                </View>
                <Badge label="Substitute needed" tone="warning" small />
              </View>
            ))}
          </View>

          <Button
            title="Submit leave request"
            icon="paper-plane-outline"
            loading={view.submitting}
            disabled={!canSubmit}
            onPress={() => void submit()}
          />
        </Card>
      ) : (
        <Button title="Request another leave" variant="outline" icon="add" onPress={reset} />
      )}

      <View style={{ marginTop: 4 }}>
        <Text variant="h2">History</Text>
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList<LeaveRequest>
        data={view.requests}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={header}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: 136, gap: 10, flexGrow: 1 }}
        refreshControl={<RefreshControl refreshing={view.history.loading && Boolean(view.requests)} onRefresh={() => void view.history.refetch()} tintColor={C.primary} />}
        renderItem={({ item }) => (
          <Card pad={14} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <View style={styles.historyIcon}>
              <Ionicons name={item.leaveType === 'sick' ? 'medkit-outline' : item.leaveType === 'personal' ? 'person-outline' : 'sunny-outline'} size={20} color={C.primary} />
            </View>
            <View style={{ flex: 1, gap: 4 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Text variant="title" weight={700}>{leaveTypeLabel(item.leaveType)}</Text>
                <Badge label={leaveStatusLabel(item.status)} tone={leaveStatusTone(item.status)} small />
              </View>
              <Text variant="caption" c={C.secondary}>{leaveRangeLabel(item)} · {leaveDayCount(item.fromDate, item.toDate)} days</Text>
              <Text variant="caption" c={C.secondary} numberOfLines={1}>{item.reason}</Text>
            </View>
          </Card>
        )}
        ListEmptyComponent={
          view.history.loading ? <ListSkeleton rows={2} h={80} /> : view.history.error ? (
            <ErrorState message={view.history.error.message} onRetry={() => void view.history.refetch()} />
          ) : <EmptyState icon="calendar-outline" title="No leave requests" text="Your submitted requests will appear here." />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

function StatusCard({ request }: { request: LeaveRequest }) {
  return (
    <Card pad={16} style={{ borderColor: C.warning, borderLeftWidth: 5 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View style={{ gap: 4 }}>
          <Text variant="label" c={C.warning}>REQUEST SUBMITTED</Text>
          <Text variant="h2">Awaiting owner</Text>
        </View>
        <Ionicons name="hourglass-outline" size={28} color={C.warning} />
      </View>
      <Text variant="body" c={C.secondary} style={{ marginTop: 10 }}>{leaveTypeLabel(request.leaveType)} leave · {leaveRangeLabel(request)}</Text>
    </Card>
  );
}

const styles = {
  emptyClasses: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 8,
    padding: 14,
    borderRadius: R.field,
    backgroundColor: C.canvas,
  },
  classRow: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 10,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: C.hairline,
  },
  historyIcon: {
    width: 42,
    height: 42,
    borderRadius: R.field,
    backgroundColor: C.navySoft,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
};
