import React from 'react';

import { MarksScreen } from '@/features/exams/marks';

/**
 * Teacher marks entry deliberately mounts the shared P16 grid. The backend
 * scopes the exam to the teacher's own batches, so this is an entry point,
 * not a second marks implementation.
 */
export function TeacherMarksScreen() {
  return <MarksScreen />;
}
