import type { Doubt, ID, LeaveRequest, LeaveStatus, LeaveType } from '@/core/contracts/models';
import { dateShort, relTime } from '@/lib/format';

export type DoubtSegment = 'open' | 'answered' | 'all';

export interface TeacherDoubtRow {
  id: ID;
  studentId: ID;
  studentName: string;
  studentPhotoUrl: string | null;
  subjectName: string;
  question: string;
  answer: string | null;
  status: Doubt['status'];
  createdAt: string;
  timeLabel: string;
  ageHours: number;
  ageBadge: string | null;
}

export interface TeacherExamRow {
  id: ID;
  name: string;
  subjectName: string;
  batchName: string;
  startsOn: string | null;
  totalMarks: number;
  entered: number;
  totalStudents: number;
  marksLabel: string;
}

export interface AffectedClass {
  id: string;
  date: string;
  dateLabel: string;
  subjectName: string;
  batchName: string;
  timeLabel: string;
  substituteNeeded: boolean;
}

export const LEAVE_TYPES: { key: LeaveType; label: string }[] = [
  { key: 'casual', label: 'Casual' },
  { key: 'sick', label: 'Sick' },
  { key: 'personal', label: 'Personal' },
];

export function ageHours(iso: string, now = Date.now()): number {
  return Math.max(0, (now - new Date(iso).getTime()) / 3_600_000);
}

export function ageBadge(hours: number): string | null {
  if (hours <= 24) return null;
  if (hours < 48) return `${Math.floor(hours)}h old`;
  return `${Math.floor(hours / 24)}d old`;
}

export function doubtRow(
  doubt: Doubt,
  student: { id: ID; fullName: string; photoUrl: string | null },
  subjectName: string,
  now = Date.now(),
): TeacherDoubtRow {
  const hours = ageHours(doubt.createdAt, now);
  return {
    id: doubt.id,
    studentId: student.id,
    studentName: student.fullName,
    studentPhotoUrl: student.photoUrl,
    subjectName,
    question: doubt.question,
    answer: doubt.answer,
    status: doubt.status,
    createdAt: doubt.createdAt,
    timeLabel: relTime(doubt.createdAt),
    ageHours: hours,
    ageBadge: ageBadge(hours),
  };
}

export function averageReplyHours(doubts: Doubt[]): number | null {
  const durations = doubts
    .filter((doubt) => doubt.answeredAt)
    .map((doubt) => (new Date(doubt.answeredAt!).getTime() - new Date(doubt.createdAt).getTime()) / 3_600_000);
  if (durations.length === 0) return null;
  return Math.round(durations.reduce((sum, value) => sum + value, 0) / durations.length);
}

export function leaveDayCount(from: string, to: string): number {
  if (!from || !to || to < from) return 0;
  const start = new Date(`${from}T00:00:00Z`).getTime();
  const end = new Date(`${to}T00:00:00Z`).getTime();
  return Math.max(1, Math.round((end - start) / 86_400_000) + 1);
}

export function leaveTypeLabel(type: LeaveType): string {
  return LEAVE_TYPES.find((item) => item.key === type)?.label ?? type;
}

export function leaveStatusLabel(status: LeaveStatus): string {
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export function leaveStatusTone(status: LeaveStatus): 'warning' | 'success' | 'danger' | 'neutral' {
  if (status === 'approved') return 'success';
  if (status === 'rejected') return 'danger';
  if (status === 'pending') return 'warning';
  return 'neutral';
}

export function leaveRangeLabel(request: LeaveRequest): string {
  return `${dateShort(request.fromDate)} – ${dateShort(request.toDate)}`;
}
