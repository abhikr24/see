import assert from 'node:assert/strict';

import { attendanceRepo, batchRepo, timetableRepo } from '../src/backends/memory/academics';
import { analyticsRepo } from '../src/backends/memory/business';
import { assignmentRepo, examRepo, markRepo, resultRepo, submissionRepo } from '../src/backends/memory/coursework';
import { createDb } from '../src/backends/memory/db';
import { materialRepo } from '../src/backends/memory/learning';
import { capture, restore } from '../src/backends/memory/persist';
import { progressPort } from '../src/backends/memory/progress';
import { seed, SEED } from '../src/backends/memory/seed';
import { ensureStudentExtras } from '../src/backends/memory/seed-student';
import { todayIso } from '../src/backends/memory/store';
import { isBackendError } from '../src/core/contracts/errors';
import {
  dueSummaryLabel,
  dueTasksOf,
  examScoresOf,
  nextTestView,
  progressLineOf,
  studentGreeting,
} from '../src/features/student/model';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

const rejects = async (promise: Promise<unknown>, code: string) => {
  try {
    await promise;
  } catch (error) {
    assert.ok(isBackendError(error), `expected BackendError, got ${String(error)}`);
    assert.equal(error.code, code, error.message);
    return error;
  }
  return assert.fail(`expected ${code}`);
};

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const AARAV = sid(14);
const ISHITA = sid(15);
const ROHIT = sid(3);
const SUNRISE = SEED.instituteId;
const APEX = sid(71001);
const CLASS_10A = sid(9);
const CLASS_9A = sid(10);
const TRIG_HW = sid(14003);
const MATHS = sid(44);

async function main() {
  const db = createDb();
  seed(db);
  const analytics = analyticsRepo(db);
  const assignments = assignmentRepo(db);
  const submissions = submissionRepo(db);
  const attendance = attendanceRepo(db);
  const batches = batchRepo(db);
  const timetable = timetableRepo(db);
  const materials = materialRepo(db);
  const exams = examRepo(db);
  const marks = markRepo(db);
  const results = resultRepo(db);
  const progress = progressPort(db);
  const myInstitutesFor = (targetDb: typeof db, userId: string) =>
    targetDb.institutes.everything().filter((inst) => targetDb.memberships.find(inst.id, { userId, status: 'active' }));
  const as = (userId: string | null) => {
    db.session.userId = userId;
  };

  console.log('Student home acceptance');

  await check('student home loads Aarav\'s own Sunrise data, leading with what is done', async () => {
    as(AARAV);
    const myInstitutes = myInstitutesFor(db, AARAV);
    assert.equal(myInstitutes.length, 2, 'Aarav holds two active memberships');

    const home = await analytics.studentHome(SUNRISE);
    assert.equal(home.classLabel, 'Class 10-A');
    assert.equal(studentGreeting(home.studentName), 'Hello, Aarav');
    assert.equal(Math.round(home.attendancePercent ?? 0), 93);
    assert.equal(nextTestView(home.nextTest).headline, 'Next test in 3 days');
    assert.ok(home.unreadNotifications >= 1);

    // Due today leads with submitted work first, then pending work.
    assert.equal(home.dueToday.length, 2);
    assert.equal(home.dueToday[0].title, 'Quadratic equations worksheet');
    assert.equal(home.dueToday[0].isDone, true);
    assert.equal(home.dueToday[1].title, 'Trigonometry: Chapter 8 practice set');
    assert.equal(home.dueToday[1].isDone, false);
    assert.equal(dueSummaryLabel(dueTasksOf(home)), '1 of 2 done');

    // Classes, material, progress.
    assert.ok(home.todayClasses.length >= 2);
    assert.ok(home.todayClasses.every((c) => c.batchId === CLASS_10A));
    assert.equal(home.newMaterials.length, 4);
    assert.equal(home.progress.goalsOnTrack, 2);
    assert.match(progressLineOf(home.progress), /^Attendance 93% · Average 80% · 2 goals on track$/);
  });

  await check('only their own data is accessible — enforced in the repos', async () => {
    as(ROHIT);
    await rejects(analytics.studentHome(SUNRISE), 'FORBIDDEN');
    as(SEED.ownerId);
    await rejects(analytics.studentHome(SUNRISE), 'FORBIDDEN');

    as(AARAV);
    // Cannot read another student's progress, goals, tasks, results, or attendance.
    await rejects(progress.getStudent360(SUNRISE, ISHITA), 'FORBIDDEN');
    await rejects(progress.listGoals(SUNRISE, ISHITA), 'FORBIDDEN');
    await rejects(progress.listTasks(SUNRISE, ISHITA), 'FORBIDDEN');
    await rejects(results.listForStudent(SUNRISE, ISHITA), 'FORBIDDEN');
    await rejects(
      submissions.submit(SUNRISE, { assignmentId: TRIG_HW, studentId: ISHITA, content: 'spoof' }),
      'FORBIDDEN',
    );
    assert.equal((await attendance.listRecords(SUNRISE, { studentId: ISHITA })).length, 0);
    assert.equal((await attendance.summary(SUNRISE, { studentId: ISHITA })).total, 0);

    // Cannot see another batch's timetable, exams, or unpublished materials.
    const todayDow = new Date(`${todayIso()}T00:00:00Z`).getUTCDay();
    assert.equal((await timetable.listForDay(SUNRISE, { dayOfWeek: todayDow, batchId: CLASS_9A })).length, 0);
    assert.ok((await batches.listMine(SUNRISE)).every((b) => b.id === CLASS_10A));

    // Draft material or Class 9-A material is hidden from Aarav.
    as(ROHIT);
    const hiddenMat = await materials.create(SUNRISE, {
      batchId: CLASS_9A,
      title: '9-A Secret Notes',
      isPublished: true,
    });
    const draftMat = await materials.create(SUNRISE, {
      batchId: CLASS_10A,
      title: '10-A Draft Notes',
      isPublished: false,
    });
    as(AARAV);
    const visibleMats = await materials.list(SUNRISE);
    assert.ok(!visibleMats.items.some((m) => m.id === hiddenMat.id || m.id === draftMat.id));
    await rejects(materials.get(SUNRISE, hiddenMat.id), 'NOT_FOUND');
    await rejects(materials.get(SUNRISE, draftMat.id), 'NOT_FOUND');
  });

  await check('switching institute swaps every card on the student home', async () => {
    as(AARAV);
    const sunrise = await analytics.studentHome(SUNRISE);
    const apex = await analytics.studentHome(APEX);

    assert.notEqual(sunrise.classLabel, apex.classLabel);
    assert.equal(apex.classLabel, 'NEET Foundation');
    assert.equal(Math.round(apex.attendancePercent ?? 0), 85);
    assert.equal(nextTestView(apex.nextTest).headline, 'Next test in 5 days');
    assert.notDeepEqual(
      sunrise.dueToday.map((d) => d.title),
      apex.dueToday.map((d) => d.title),
    );
    assert.ok(apex.dueToday.some((d) => d.title === 'Laws of Motion: Free Body Diagrams' && !d.isDone));
    assert.ok(apex.dueToday.some((d) => d.title === 'Vector Addition Practice' && d.isDone));
    assert.notDeepEqual(
      sunrise.todayClasses.map((c) => c.teacherName),
      apex.todayClasses.map((c) => c.teacherName),
    );
    assert.equal(apex.todayClasses[0].teacherName, 'Dr. Kavita Rao');
    assert.notDeepEqual(
      sunrise.newMaterials.map((m) => m.title),
      apex.newMaterials.map((m) => m.title),
    );
    assert.equal(progressLineOf(apex.progress), 'Attendance 85% · Average 86% · 1 goal on track');
  });

  await check('submitting homework from student home reflects immediately on the teacher\'s tracker', async () => {
    as(ROHIT);
    const beforeTracker = (await assignments.tracker(SUNRISE)).active.find((a) => a.id === TRIG_HW)!;
    const beforeHome = await analytics.teacherHome(SUNRISE);
    assert.equal(beforeTracker.submittedCount, 0);
    assert.equal(beforeTracker.pendingCount, 12);

    as(AARAV);
    await submissions.submit(SUNRISE, {
      assignmentId: TRIG_HW,
      studentId: AARAV,
      content: 'Solved odd-numbered questions 1 to 15.',
    });
    const studentAfter = await analytics.studentHome(SUNRISE);
    const trigCard = studentAfter.dueToday.find((d) => d.assignmentId === TRIG_HW)!;
    assert.equal(trigCard.isDone, true);
    assert.equal(dueSummaryLabel(dueTasksOf(studentAfter)), 'All 2 done');

    as(ROHIT);
    const afterTracker = (await assignments.tracker(SUNRISE)).active.find((a) => a.id === TRIG_HW)!;
    const afterHome = await analytics.teacherHome(SUNRISE);
    assert.equal(afterTracker.submittedCount, 1);
    assert.equal(afterTracker.pendingCount, 11);
    assert.equal(afterTracker.percentage, 8);
    assert.equal(afterHome.submissionsToGrade, beforeHome.submissionsToGrade + 1);
  });

  await check('marks shown on student home match the teacher\'s entry exactly', async () => {
    as(ROHIT);
    const newExam = await exams.create(SUNRISE, {
      batchId: CLASS_10A,
      subjectId: MATHS,
      name: 'Algebra Checkpoint',
      startsOn: todayIso(),
      totalMarks: 50,
      status: 'scheduled',
    });
    await marks.saveMany(SUNRISE, newExam.id, [
      { studentId: AARAV, subjectId: MATHS, marksObtained: 44, maxMarks: 50, isAbsent: false },
    ]);
    await results.compute(SUNRISE, newExam.id);

    // Unpublished exam stays hidden from Aarav.
    as(AARAV);
    const hiddenView = await analytics.studentHome(SUNRISE);
    assert.ok(!hiddenView.progress.examScores.some((e) => e.examId === newExam.id));

    // Teacher publishes -> Aarav sees exact marks (44/50, 88%).
    as(ROHIT);
    await exams.publish(SUNRISE, newExam.id);

    as(AARAV);
    let publishedView = await analytics.studentHome(SUNRISE);
    let score = examScoresOf(publishedView.progress.examScores).find((e) => e.examName === 'Algebra Checkpoint');
    assert.equal(score?.scoreLabel, '44/50');
    assert.equal(score?.percentLabel, '88%');

    // Teacher updates Aarav's mark to 47/50 -> student view matches 47/50 (94%) immediately.
    as(ROHIT);
    await marks.saveMany(SUNRISE, newExam.id, [
      { studentId: AARAV, subjectId: MATHS, marksObtained: 47, maxMarks: 50, isAbsent: false },
    ]);
    await results.compute(SUNRISE, newExam.id);

    as(AARAV);
    publishedView = await analytics.studentHome(SUNRISE);
    score = examScoresOf(publishedView.progress.examScores).find((e) => e.examName === 'Algebra Checkpoint');
    assert.equal(score?.scoreLabel, '47/50');
    assert.equal(score?.percentLabel, '94%');
  });

  await check('nothing due today produces an empty dueToday array (encouraging empty state) and snapshot restore works', async () => {
    // Move all due dates at Apex away from today.
    for (const a of db.assignments.all(APEX)) {
      db.assignments.update(APEX, a.id, { dueAt: '2026-11-28T18:00:00.000Z' });
    }
    as(AARAV);
    const quietApex = await analytics.studentHome(APEX);
    assert.equal(quietApex.dueToday.length, 0);
    assert.equal(dueSummaryLabel(dueTasksOf(quietApex)), null);

    // Snapshot round-trip & ensureStudentExtras top-up on older snapshots.
    const snap = capture(db);
    const copy = createDb();
    assert.equal(restore(copy, snap), true);
    copy.session.userId = AARAV;
    const restoredSunrise = await analyticsRepo(copy).studentHome(SUNRISE);
    assert.equal(restoredSunrise.classLabel, 'Class 10-A');

    // Older snapshot without Apex gets topped up cleanly by ensureStudentExtras.
    const oldDb = createDb();
    seed(oldDb);
    oldDb.institutes.remove(APEX, APEX);
    ensureStudentExtras(oldDb);
    oldDb.session.userId = AARAV;
    assert.equal(myInstitutesFor(oldDb, AARAV).length, 2);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
