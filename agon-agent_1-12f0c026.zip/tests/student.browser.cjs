const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

// Drives the exported web build (`npm run build` first) across Student Home + Teacher Homework Tracker.
const root = path.join(process.cwd(), 'dist');
const shots = path.join(process.cwd(), '.shots');
const types = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.ttf': 'font/ttf',
  '.png': 'image/png',
};

const server = http
  .createServer((req, res) => {
    let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
    if (!file.startsWith(root)) {
      res.writeHead(403).end();
      return;
    }
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
    res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
    fs.createReadStream(file).pipe(res);
  })
  .listen(8136);

const BASE = 'http://localhost:8136';
const tab = (page, label) => page.getByRole('tab', { name: label, exact: true });
const step = (msg) => console.log(`PASS: ${msg}`);
const seen = (page, text, timeout = 15000) =>
  page.getByText(text, { exact: true }).first().waitFor({ state: 'visible', timeout });

async function shot(page, name) {
  fs.mkdirSync(shots, { recursive: true });
  await page.screenshot({ path: path.join(shots, `student-${name}.png`) });
}

async function signIn(page, { pill, waitTab }) {
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 15000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 30000 });
  await page.getByText(pill, { exact: true }).click();
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await tab(page, waitTab).waitFor({ state: 'visible', timeout: 30000 });
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  try {
    await page.goto(`${BASE}/`);
    await signIn(page, { pill: 'Student', waitTab: 'Home' });

    // ---- 1. Shape A header, overlapping card, section order ----
    for (const text of [
      'Class 10-A',
      'Hello, Aarav',
      '93%',
      'Next test in 3 days',
      'Due today',
      '1 of 2 done',
      'Quadratic equations worksheet',
      'Trigonometry: Chapter 8 practice set',
      "Today's classes",
      'New material',
      'Quadratic Formula Sheet',
      'Your progress',
      'Attendance 93% · Average 80% · 2 goals on track',
    ]) {
      await seen(page, text);
    }

    // Verify section order: due today < today's classes < new material < your progress.
    const bodyText = await page.locator('body').innerText();
    const iDue = bodyText.indexOf('Due today');
    const iClasses = bodyText.indexOf("Today's classes");
    const iMat = bodyText.indexOf('New material');
    const iProg = bodyText.indexOf('Your progress');
    assert.ok(iDue > 0 && iDue < iClasses && iClasses < iMat && iMat < iProg, 'section order violated');
    await shot(page, '1-home');
    step('Student home renders Shape A header, overlapping card, and sections in exact order');

    // ---- 2. Submitting homework reflects immediately & on teacher tracker ----
    await page.getByRole('button', { name: 'Submit Trigonometry: Chapter 8 practice set' }).click();
    await seen(page, 'Turn in homework');
    await page.getByPlaceholder('e.g. Completed Q1–Q10 in my notebook').fill('Done all odd-numbered questions');
    await page.getByRole('button', { name: 'Turn in homework', exact: true }).click();
    await seen(page, 'All 2 done');
    await shot(page, '2-submitted');
    step('Submitting pending homework flips the card to Submitted and updates Due today summary');

    // ---- 3. Full progress sheet shows exact teacher marks ----
    await page.getByRole('button', { name: /Your progress:/ }).click();
    await seen(page, 'Exam marks');
    await seen(page, '92/100');
    await seen(page, '284/320');
    await shot(page, '3-progress');
    await page.getByRole('button', { name: 'Close sheet' }).first().click().catch(async () => {
      await page.keyboard.press('Escape');
    });
    step('Full progress view shows exact exam marks matching teacher entries');

    // ---- 4. Switching institute swaps every card on the screen ----
    await page.getByRole('button', { name: 'Switch institute (Sunrise Coaching Classes)' }).click();
    await seen(page, 'Apex Science Academy');
    await page.getByRole('button', { name: 'Switch to Apex Science Academy' }).click();
    await seen(page, 'NEET Foundation');
    await seen(page, '85%');
    await seen(page, 'Next test in 5 days');
    await seen(page, 'Laws of Motion: Free Body Diagrams');
    await seen(page, 'Dr. Kavita Rao · Hall A');
    await seen(page, 'Vectors & Kinematics Notes');
    await seen(page, 'Attendance 85% · Average 86% · 1 goal on track');
    await shot(page, '4-switched-institute');
    step('Switching institute via the header pill swaps every card on Student Home');

    // ---- 5. Verify submission reflected on teacher's Homework Tracker ----
    await page.getByRole('button', { name: 'Sign out' }).click();
    await signIn(page, { pill: 'Teacher', waitTab: 'Homework' });
    await tab(page, 'Homework').click();
    await seen(page, 'Trigonometry: Chapter 8 practice set');
    await seen(page, '1 submitted');
    await seen(page, '11 pending');
    await shot(page, '5-teacher-tracker');
    step("Student submission reflected on teacher's Homework Tracker (1 submitted / 11 pending)");

    assert.deepEqual(errors, []);
    step('0 runtime page errors');
  } catch (error) {
    await shot(page, 'failure').catch(() => {});
    console.error(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.closeAllConnections?.();
    server.close();
  }
})();
