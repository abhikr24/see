# Work done

## 2026-11-11 · Full GuruFlow data model (migrations 0003–0008, seed)

Replaced the 17-table schema with the 62-table GuruFlow model.

**Added**
- `supabase/migrations/0003_core.sql` – drops the old public tables; GLOBAL (users, profiles, user_preferences, sessions) and TENANT (institutes, memberships, invitations, branches, institute_settings); `auth.users` sync trigger; owner bootstrap trigger.
- `supabase/migrations/0004_academics.sql` – ACADEMICS, BATCHES, ATTENDANCE, HOMEWORK, EXAMS, LEARNING (35 tables).
- `supabase/migrations/0005_finance.sql` – FINANCE (6 tables).
- `supabase/migrations/0006_communication.sql` – COMMUNICATION (6 tables).
- `supabase/migrations/0007_business.sql` – BUSINESS (6 tables).
- `supabase/migrations/0008_rls.sql` – `auth_institute_ids()`, `has_role()`, `my_student_ids()` and supporting helpers; RLS on all 62 tables; `membership_guard`; grants.
- `supabase/seed.sql` – rewritten: Sunrise Coaching Classes, Patna (`SUNRISE-PAT`) with fixed UUIDs.
- `docs/DATA_MODEL.md` – tables, RLS rules, seed ID map.

**Verified** (PostgreSQL 16 and 18 via PGlite, with a stand-in `auth` schema and API roles – not yet on a real Supabase project)
- 0003–0008 and `seed.sql` run without error, on an empty database and on one holding older tables with clashing names.
- 62 tables, matching the list; each has `id uuid` pk, `created_at`, `updated_at` + trigger; the 58 tenant tables have `institute_id`; RLS on all.
- A second institute's owner sees zero Sunrise rows in every table and cannot write into Sunrise.
- Pending member sees only their own membership row; anon is denied on all tables.
- Student, parent, teacher, admin and owner each see and write only what `docs/DATA_MODEL.md` describes; only an owner can change a role.

**Not verified / to do**
- 0001 and 0002 were not available when this was written, so the full chain 0001 → 0008 has not been run together.
- Run `supabase db reset` against the real stack to confirm the seed's `auth.users` / `auth.identities` rows and password sign-in.
- App code still queries the old tables and needs updating to the new model.
- Join-by-code lookup and invitation acceptance need an RPC or edge function (see Known limits in `docs/DATA_MODEL.md`).
