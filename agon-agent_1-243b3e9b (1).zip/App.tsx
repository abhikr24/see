import Ionicons from '@expo/vector-icons/Ionicons';
import { DarkTheme, DefaultTheme, NavigationContainer, type LinkingOptions } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useFonts } from 'expo-font';
import { StatusBar } from 'expo-status-bar';
import { useColorScheme } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import ContractCheckScreen from './app/dev/contract-check';
import HomeScreen from './app/index';
import { DEFAULT_BACKEND, DEFAULT_INSTITUTE_ID, createBackends } from './src/backends';
import { BackendProvider } from './src/core/backend';

type RootStackParamList = {
  Home: undefined;
  ContractCheck: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

// Composition root: the one place a concrete backend meets the UI.
const backends = createBackends();

// Screens live under app/ at the path they are served from, so /dev/contract-check opens directly.
const linking: LinkingOptions<RootStackParamList> = {
  prefixes: ['guruflow://'],
  config: {
    initialRouteName: 'Home',
    screens: {
      Home: '',
      ContractCheck: 'dev/contract-check',
    },
  },
};

export default function App() {
  // Icon fonts must be loaded before first paint or icons render as boxes on web.
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  const scheme = useColorScheme();

  if (!fontsLoaded) return null;

  return (
    <SafeAreaProvider>
      <BackendProvider backends={backends} initial={DEFAULT_BACKEND} instituteId={DEFAULT_INSTITUTE_ID}>
        <NavigationContainer linking={linking} theme={scheme === 'dark' ? DarkTheme : DefaultTheme}>
          <Stack.Navigator>
            <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'GuruFlow' }} />
            <Stack.Screen name="ContractCheck" component={ContractCheckScreen} options={{ title: 'Contract check' }} />
          </Stack.Navigator>
        </NavigationContainer>
        <StatusBar style="auto" />
      </BackendProvider>
    </SafeAreaProvider>
  );
}
