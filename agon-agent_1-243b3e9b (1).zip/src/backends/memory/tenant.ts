import type { AuthSession, Branch, ID, Institute, Membership, Profile } from '../../core/contracts/models';
import type {
  AuthPort,
  BranchRepo,
  InstituteRepo,
  InstituteScope,
  InvitationRepo,
  MembershipRepo,
} from '../../core/contracts/ports';
import { crud, emit, requireUser, type Db } from './db';
import * as D from './defaults';
import { defined, fail, merge, nowIso } from './store';

/** Every seeded and newly signed-up account uses this password. Local demo only. */
export const MEMORY_PASSWORD = 'demo1234';

function profileOf(db: Db, userId: ID): Profile {
  return db.profiles.get(userId) ?? fail('NOT_FOUND', 'Profile not found');
}

function findByEmail(db: Db, email: string): Profile | undefined {
  const wanted = email.trim().toLowerCase();
  return [...db.profiles.values()].find((p) => p.email?.toLowerCase() === wanted);
}

export function authPort(db: Db): AuthPort {
  const session = (instituteId: InstituteScope): AuthSession | null => {
    const userId = db.session.userId;
    if (!userId) return null;
    const profile = profileOf(db, userId);
    const membership = instituteId ? (db.memberships.find(instituteId, { userId }) ?? null) : null;
    return { user: { id: userId, email: profile.email, phone: profile.phone }, profile, membership, expiresAt: null };
  };

  return {
    getSession: async (instituteId) => session(instituteId),
    signIn: async (instituteId, { email, password }) => {
      const profile = findByEmail(db, email);
      if (!profile || password !== MEMORY_PASSWORD) fail('UNAUTHENTICATED', 'Wrong email or password');
      db.session.userId = profile.userId;
      return session(instituteId) as AuthSession;
    },
    signUp: async (instituteId, { email, password, fullName }) => {
      if (!email.includes('@')) fail('VALIDATION', 'Enter a valid email address');
      if (password.length < 8) fail('VALIDATION', 'Password must be at least 8 characters');
      if (!fullName.trim()) fail('VALIDATION', 'Name is required');
      if (findByEmail(db, email)) fail('CONFLICT', 'An account with this email already exists');
      const at = nowIso();
      const userId = db.nextId();
      db.profiles.set(userId, {
        ...D.profile(),
        id: db.nextId(),
        userId,
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        createdAt: at,
        updatedAt: at,
      });
      db.session.userId = userId;
      return session(instituteId) as AuthSession;
    },
    signOut: async () => {
      db.session.userId = null;
    },
    requestPasswordReset: async (_instituteId, email) => {
      if (!email.includes('@')) fail('VALIDATION', 'Enter a valid email address');
    },
    getProfile: async (_instituteId, userId) => profileOf(db, userId),
    updateProfile: async (_instituteId, userId, patch) => {
      if (userId !== requireUser(db)) fail('FORBIDDEN', 'You can only edit your own profile');
      const next: Profile = { ...profileOf(db, userId), ...defined(patch), userId, updatedAt: nowIso() };
      db.profiles.set(userId, next);
      return next;
    },
  };
}

export function instituteRepo(db: Db): InstituteRepo {
  return {
    listMine: async () => {
      const userId = requireUser(db);
      return db.institutes.everything().filter((inst) => db.memberships.find(inst.id, { userId, status: 'active' }));
    },
    findByCode: async (_instituteId, code) => {
      const wanted = code.trim().toUpperCase();
      return db.institutes.everything().find((inst) => inst.code === wanted) ?? null;
    },
    create: async (_instituteId, input) => {
      const ownerId = requireUser(db);
      const code = input.code.trim().toUpperCase();
      if (!input.name.trim()) fail('VALIDATION', 'Institute name is required');
      if (!/^[A-Z0-9][A-Z0-9-]{2,23}$/.test(code)) fail('VALIDATION', 'Code must be 3–24 letters, digits or dashes');
      if (db.institutes.everything().some((inst) => inst.code === code)) fail('CONFLICT', 'That code is taken');
      const at = nowIso();
      const created: Institute = {
        ...D.institute(),
        ...defined(input),
        id: db.nextId(),
        name: input.name.trim(),
        code,
        ownerId,
        createdAt: at,
        updatedAt: at,
      };
      db.institutes.put(created);
      db.memberships.insert(created.id, {
        userId: ownerId,
        branchId: null,
        role: 'owner',
        status: 'active',
        permissions: [],
        requestNote: null,
        requestedAt: at,
        decidedBy: ownerId,
        decidedAt: at,
      });
      return created;
    },
    get: async (instituteId) => db.institutes.get(instituteId, instituteId),
    update: async (instituteId, patch) => db.institutes.update(instituteId, instituteId, patch),
    updateSettings: async (instituteId, patch) => {
      const current = db.institutes.get(instituteId, instituteId);
      return db.institutes.update(instituteId, instituteId, { settings: { ...current.settings, ...defined(patch) } });
    },
  };
}

export function branchRepo(db: Db): BranchRepo {
  const base = crud<Branch, 'name' | 'code'>(db.branches, D.branch);
  return {
    ...base,
    create: async (instituteId, input) => {
      if (db.branches.find(instituteId, { code: input.code })) fail('CONFLICT', 'A branch with this code exists');
      return base.create(instituteId, input);
    },
  };
}

export function membershipRepo(db: Db): MembershipRepo {
  const changed = (membership: Membership, change: 'created' | 'updated' | 'removed') => {
    emit(db, membership.instituteId, 'memberships', change, membership.id);
    return membership;
  };
  return {
    list: async (instituteId, query) => db.memberships.page(instituteId, query),
    get: async (instituteId, id) => db.memberships.get(instituteId, id),
    getMine: async (instituteId) => {
      const userId = db.session.userId;
      return userId ? (db.memberships.find(instituteId, { userId }) ?? null) : null;
    },
    requestToJoin: async (instituteId, { role, note }) => {
      const userId = requireUser(db);
      const institute = db.institutes.get(instituteId, instituteId);
      if (!institute.settings.allowJoinRequests) fail('FORBIDDEN', 'This institute is not accepting join requests');
      if (db.memberships.find(instituteId, { userId })) fail('CONFLICT', 'You already have a membership here');
      return changed(
        db.memberships.insert(instituteId, {
          userId,
          branchId: null,
          role,
          status: 'pending',
          permissions: [],
          requestNote: note ?? null,
          requestedAt: nowIso(),
          decidedBy: null,
          decidedAt: null,
        }),
        'created',
      );
    },
    decide: async (instituteId, id, status) =>
      changed(
        db.memberships.update(instituteId, id, { status, decidedBy: db.session.userId, decidedAt: nowIso() }),
        'updated',
      ),
    setRole: async (instituteId, id, role, permissions) => {
      const target = db.memberships.get(instituteId, id);
      const owners = db.memberships.all(instituteId, { role: 'owner', status: 'active' });
      if (target.role === 'owner' && role !== 'owner' && owners.length === 1) {
        fail('CONFLICT', 'An institute must keep at least one owner');
      }
      return changed(db.memberships.update(instituteId, id, defined({ role, permissions })), 'updated');
    },
    remove: async (instituteId, id) => {
      const target = db.memberships.get(instituteId, id);
      if (target.role === 'owner') fail('FORBIDDEN', 'An owner cannot be removed');
      db.memberships.remove(instituteId, id);
      changed(target, 'removed');
    },
  };
}

export function invitationRepo(db: Db): InvitationRepo {
  return {
    list: async (instituteId, query) => db.invitations.page(instituteId, query),
    get: async (instituteId, id) => db.invitations.get(instituteId, id),
    create: async (instituteId, input) => {
      if (!input.email && !input.phone) fail('VALIDATION', 'An email or a phone number is required');
      return db.invitations.insert(instituteId, { ...merge(D.invitation(), input), invitedBy: db.session.userId });
    },
    resend: async (instituteId, id) =>
      db.invitations.update(instituteId, id, { status: 'pending', expiresAt: D.invitation().expiresAt }),
    revoke: async (instituteId, id) => db.invitations.update(instituteId, id, { status: 'revoked' }),
    // The memory backend has no mail to send, so an invitation's id doubles as its token.
    accept: async (instituteId, token) => {
      const userId = requireUser(db);
      const invitation = db.invitations.find(instituteId, { id: token, status: 'pending' });
      if (!invitation) fail('NOT_FOUND', 'This invitation is not valid any more');
      if (db.memberships.find(instituteId, { userId })) fail('CONFLICT', 'You already have a membership here');
      const at = nowIso();
      db.invitations.update(instituteId, invitation.id, { status: 'accepted', acceptedBy: userId, acceptedAt: at });
      return db.memberships.insert(instituteId, {
        userId,
        branchId: null,
        role: invitation.role,
        status: 'active',
        permissions: [],
        requestNote: null,
        requestedAt: at,
        decidedBy: invitation.invitedBy,
        decidedAt: at,
      });
    },
  };
}
