import type { ID, ISODate, ISODateTime, JsonObject, Money, Role, TenantEntity } from './common';

export type LeadStage =
  | 'new'
  | 'contacted'
  | 'interested'
  | 'demo_scheduled'
  | 'demo_attended'
  | 'negotiation'
  | 'enrolled'
  | 'lost';

/** An admission enquiry moving through the pipeline. */
export interface AdmissionLead extends TenantEntity {
  branchId: ID | null;
  studentName: string;
  guardianName: string | null;
  phone: string | null;
  email: string | null;
  classInterested: string | null;
  schoolName: string | null;
  source: 'walk_in' | 'referral' | 'website' | 'social' | 'phone' | 'campaign' | 'other';
  stage: LeadStage;
  assignedTo: ID | null;
  expectedFee: Money | null;
  nextFollowupAt: ISODateTime | null;
  lostReason: string | null;
  convertedStudentId: ID | null;
  notes: string | null;
}

export interface LeadFollowup extends TenantEntity {
  leadId: ID;
  channel: 'call' | 'whatsapp' | 'sms' | 'email' | 'visit';
  summary: string | null;
  outcome: 'no_answer' | 'interested' | 'callback' | 'demo_booked' | 'not_interested' | 'enrolled' | null;
  followupAt: ISODateTime;
  nextFollowupAt: ISODateTime | null;
  doneBy: ID | null;
}

/** A SaaS plan as offered to this institute. */
export interface Plan extends TenantEntity {
  code: string;
  name: string;
  priceMonthly: Money;
  priceYearly: Money;
  currency: string;
  maxStudents: number | null;
  maxTeachers: number | null;
  maxBranches: number | null;
  storageMb: number | null;
  features: Record<string, boolean>;
  isActive: boolean;
}

export type BillingCycle = 'monthly' | 'yearly';

export interface Subscription extends TenantEntity {
  planId: ID;
  status: 'trialing' | 'active' | 'past_due' | 'cancelled' | 'expired';
  billingCycle: BillingCycle;
  currentPeriodStart: ISODateTime;
  currentPeriodEnd: ISODateTime | null;
  trialEndsAt: ISODateTime | null;
  cancelAt: ISODateTime | null;
  cancelledAt: ISODateTime | null;
  provider: string | null;
  providerSubscriptionId: string | null;
}

export type UsageMetric = 'students' | 'teachers' | 'branches' | 'storage_mb' | 'sms' | 'notifications';

export interface UsageRecord extends TenantEntity {
  subscriptionId: ID | null;
  metric: UsageMetric;
  quantity: number;
  periodStart: ISODate;
  periodEnd: ISODate;
}

/** Append-only record of who did what. */
export interface AuditLog extends TenantEntity {
  actorId: ID | null;
  actorRole: Role | null;
  action: string;
  targetType: string | null;
  targetId: ID | null;
  before: JsonObject | null;
  after: JsonObject | null;
  ipAddress: string | null;
  userAgent: string | null;
}

/** Headline numbers for the owner dashboard. */
export interface InstituteOverview {
  activeStudents: number;
  activeTeachers: number;
  activeBatches: number;
  pendingMembers: number;
  /** Across all batches, last 30 days. null when nothing was marked. */
  attendancePercent: number | null;
  feesCollected: Money;
  feesOutstanding: Money;
  openLeads: number;
  openAlerts: number;
}

export interface TrendPoint {
  date: ISODate;
  value: number;
}

export interface FunnelStage {
  stage: LeadStage;
  count: number;
}

export type ExportKind = 'students' | 'attendance' | 'marks' | 'results' | 'fees' | 'payments' | 'leads' | 'audit';
export type ExportFormat = 'csv' | 'xlsx' | 'pdf';

export interface ExportJob extends TenantEntity {
  kind: ExportKind;
  format: ExportFormat;
  status: 'queued' | 'running' | 'completed' | 'failed';
  rowCount: number | null;
  /** Download link once completed. May expire. */
  fileUrl: string | null;
  error: string | null;
  requestedBy: ID | null;
  completedAt: ISODateTime | null;
}
