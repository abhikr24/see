import type {
  AuthSession,
  Branch,
  ID,
  Institute,
  InstituteSettings,
  Invitation,
  JoinRole,
  Membership,
  NewEntity,
  Patch,
  Permission,
  Profile,
  Role,
} from '../models';
import type { CrudRepo, ReadRepo } from './common';

/**
 * Sign-in happens before an institute is chosen, so the scope argument may be
 * null on AuthPort and on the three InstituteRepo methods that find or create
 * an institute. Everywhere else it is a real institute id.
 */
export type InstituteScope = ID | null;

export interface Credentials {
  email: string;
  password: string;
}

export interface AuthPort {
  /** The current session with the caller's membership in `instituteId`, or null when signed out. */
  getSession(instituteId: InstituteScope): Promise<AuthSession | null>;
  signIn(instituteId: InstituteScope, credentials: Credentials): Promise<AuthSession>;
  signUp(instituteId: InstituteScope, input: Credentials & { fullName: string }): Promise<AuthSession>;
  signOut(instituteId: InstituteScope): Promise<void>;
  requestPasswordReset(instituteId: InstituteScope, email: string): Promise<void>;
  getProfile(instituteId: InstituteScope, userId: ID): Promise<Profile>;
  updateProfile(instituteId: InstituteScope, userId: ID, patch: Patch<Profile>): Promise<Profile>;
}

export interface InstituteRepo {
  /** Institutes where the caller has an active membership. */
  listMine(instituteId: InstituteScope): Promise<Institute[]>;
  /** Look an institute up by its join code. null when no institute has that code. */
  findByCode(instituteId: InstituteScope, code: string): Promise<Institute | null>;
  /** Creates an institute and makes the caller its first owner. */
  create(instituteId: InstituteScope, input: NewEntity<Institute, 'name' | 'code'>): Promise<Institute>;
  get(instituteId: ID): Promise<Institute>;
  update(instituteId: ID, patch: Omit<Patch<Institute>, 'settings'>): Promise<Institute>;
  updateSettings(instituteId: ID, patch: Partial<InstituteSettings>): Promise<Institute>;
}

export type BranchRepo = CrudRepo<Branch, 'name' | 'code'>;

export interface MembershipRepo extends ReadRepo<Membership> {
  /** The caller's own membership, whatever its status. null if they have none. */
  getMine(instituteId: ID): Promise<Membership | null>;
  /** Files a pending join request for the caller. */
  requestToJoin(instituteId: ID, input: { role: JoinRole; note?: string | null }): Promise<Membership>;
  /** Approve (`active`), reject or suspend a membership. */
  decide(instituteId: ID, id: ID, status: 'active' | 'rejected' | 'suspended'): Promise<Membership>;
  /** Owner only. */
  setRole(instituteId: ID, id: ID, role: Role, permissions?: Permission[]): Promise<Membership>;
  remove(instituteId: ID, id: ID): Promise<void>;
}

export interface InvitationRepo extends ReadRepo<Invitation> {
  /** Needs an email or a phone. The backend delivers the invite. */
  create(instituteId: ID, input: NewEntity<Invitation, 'role'>): Promise<Invitation>;
  resend(instituteId: ID, id: ID): Promise<Invitation>;
  revoke(instituteId: ID, id: ID): Promise<Invitation>;
  /** Redeems the token from an invite link for the caller. */
  accept(instituteId: ID, token: string): Promise<Membership>;
}
