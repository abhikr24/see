import type {
  AuthSession,
  Branch,
  ID,
  Institute,
  InstituteSettings,
  Invitation,
  JoinRole,
  Membership,
  NewEntity,
  Patch,
  Profile,
} from '../contracts/models';
import type { Credentials } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { queryCache, queryKey } from './cache';
import { useBackend } from './context';
import { patchItem, useCrud, useDomainMutation, useDomainQuery, useListEditor } from './domain';
import { useMutation } from './useMutation';
import { useQuery } from './useQuery';

/** AuthPort · who is signed in, and their membership in the current institute. */
export function useSession() {
  const { backend, instituteId } = useBackend();
  const key = queryKey(backend.name, 'session', null, instituteId);
  const session = useQuery<AuthSession | null>(key, () => backend.auth.getSession(instituteId));
  // Who is signed in changes what every query returns, so these reload the whole backend's cache.
  const everything = [`${backend.name}|`];

  const signIn = useMutation<Credentials, AuthSession>({
    scopes: everything,
    run: (credentials) => backend.auth.signIn(instituteId, credentials),
    success: (result) => `Welcome, ${result.profile.fullName.split(' ')[0]}`,
    failure: 'Could not sign in',
  });
  const signUp = useMutation<Credentials & { fullName: string }, AuthSession>({
    scopes: everything,
    run: (input) => backend.auth.signUp(instituteId, input),
    success: 'Account created',
    failure: 'Could not create the account',
  });
  const signOut = useMutation<void, void>({
    scopes: everything,
    run: () => backend.auth.signOut(instituteId),
    optimistic: () => queryCache.update<AuthSession | null>(key, () => null),
    success: 'Signed out',
    failure: 'Could not sign out',
  });
  const updateProfile = useMutation<Patch<Profile>, Profile>({
    scopes: [`${backend.name}|session|`],
    run: async (patch) => backend.auth.updateProfile(instituteId, session.data?.user.id ?? '', patch),
    optimistic: (patch) =>
      queryCache.update<AuthSession | null>(key, (s) => (s ? { ...s, profile: { ...s.profile, ...patch } } : s)),
    success: 'Profile updated',
    failure: 'Could not update your profile',
  });

  return {
    ...session,
    signIn: signIn.mutate,
    signUp: signUp.mutate,
    signOut: signOut.mutate,
    updateProfile: updateProfile.mutate,
    working: signIn.loading || signUp.loading || signOut.loading || updateProfile.loading,
  };
}

/** InstituteRepo · the current institute and its settings. */
export function useInstitute() {
  const { backend, instituteId } = useBackend();
  const key = queryKey(backend.name, 'institute', instituteId, null);
  const institute = useDomainQuery<Institute>('institute', null, (b, i) => b.institutes.get(i));
  const update = useDomainMutation<Omit<Patch<Institute>, 'settings'>, Institute>(
    'institute',
    (b, i, patch) => b.institutes.update(i, patch),
    { success: 'Institute updated', failure: 'Could not update the institute' },
    (patch) => queryCache.update<Institute>(key, (current) => ({ ...current, ...patch })),
  );
  const updateSettings = useDomainMutation<Partial<InstituteSettings>, Institute>(
    'institute',
    (b, i, patch) => b.institutes.updateSettings(i, patch),
    { success: 'Settings saved', failure: 'Could not save the settings' },
    (patch) =>
      queryCache.update<Institute>(key, (current) => ({ ...current, settings: { ...current.settings, ...patch } })),
  );
  return {
    ...institute,
    update: update.mutate,
    updateSettings: updateSettings.mutate,
    saving: update.loading || updateSettings.loading,
  };
}

/** InstituteRepo · the institutes the signed-in person belongs to, for the switcher. */
export function useMyInstitutes() {
  const { backend, setInstituteId } = useBackend();
  const key = queryKey(backend.name, 'my-institutes', null);
  const mine = useQuery<Institute[]>(key, () => backend.institutes.listMine(null));
  const create = useMutation<NewEntity<Institute, 'name' | 'code'>, Institute>({
    scopes: [`${backend.name}|my-institutes|`],
    run: (input) => backend.institutes.create(null, input),
    success: (created) => `${created.name} is ready`,
    failure: 'Could not create the institute',
  });
  return { ...mine, create: create.mutate, creating: create.loading, open: setInstituteId };
}

/** BranchRepo */
export function useBranches(query?: ListQuery<Branch>) {
  return useCrud<Branch, 'name' | 'code'>('branches', 'Branch', (b) => b.branches, query);
}

/** MembershipRepo · members and join requests. */
export function useMemberships(query?: ListQuery<Membership>) {
  const args = ['list', query ?? null];
  const members = useDomainQuery('memberships', args, (b, i) => b.memberships.list(i, query));
  const edit = useListEditor<Membership>('memberships', args);

  const decide = useDomainMutation<{ id: ID; status: 'active' | 'rejected' | 'suspended' }, Membership>(
    'memberships',
    (b, i, { id, status }) => b.memberships.decide(i, id, status),
    {
      success: (m) => (m.status === 'active' ? 'Member approved' : `Member ${m.status}`),
      failure: 'Could not update the member',
    },
    ({ id, status }) => edit(patchItem<Membership>(id, { status })),
  );
  const requestToJoin = useDomainMutation<{ role: JoinRole; note?: string | null }, Membership>(
    ['memberships', 'session'],
    (b, i, input) => b.memberships.requestToJoin(i, input),
    { success: 'Request sent', failure: 'Could not send your request' },
  );
  const remove = useDomainMutation<ID, void>(
    'memberships',
    (b, i, id) => b.memberships.remove(i, id),
    { success: 'Member removed', failure: 'Could not remove the member' },
    (id) => edit((items) => items.filter((m) => m.id !== id)),
  );

  return {
    ...members,
    decide: decide.mutate,
    requestToJoin: requestToJoin.mutate,
    remove: remove.mutate,
    saving: decide.loading || requestToJoin.loading || remove.loading,
  };
}

/** InvitationRepo */
export function useInvitations(query?: ListQuery<Invitation>) {
  const args = ['list', query ?? null];
  const invitations = useDomainQuery('invitations', args, (b, i) => b.invitations.list(i, query));
  const edit = useListEditor<Invitation>('invitations', args);

  const invite = useDomainMutation<NewEntity<Invitation, 'role'>, Invitation>(
    'invitations',
    (b, i, input) => b.invitations.create(i, input),
    { success: 'Invitation sent', failure: 'Could not send the invitation' },
  );
  const resend = useDomainMutation<ID, Invitation>(
    'invitations',
    (b, i, id) => b.invitations.resend(i, id),
    { success: 'Invitation sent again', failure: 'Could not resend the invitation' },
  );
  const revoke = useDomainMutation<ID, Invitation>(
    'invitations',
    (b, i, id) => b.invitations.revoke(i, id),
    { success: 'Invitation revoked', failure: 'Could not revoke the invitation' },
    (id) => edit(patchItem<Invitation>(id, { status: 'revoked' })),
  );

  return {
    ...invitations,
    invite: invite.mutate,
    resend: resend.mutate,
    revoke: revoke.mutate,
    saving: invite.loading || resend.loading || revoke.loading,
  };
}
