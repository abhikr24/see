import { Platform, useColorScheme } from 'react-native';

export interface Theme {
  dark: boolean;
  background: string;
  surface: string;
  border: string;
  text: string;
  muted: string;
  primary: string;
  onPrimary: string;
  passText: string;
  passFill: string;
  failText: string;
  failFill: string;
}

const light: Theme = {
  dark: false,
  background: '#F5F6FA',
  surface: '#FFFFFF',
  border: '#E2E5EC',
  text: '#111827',
  muted: '#5B6472',
  primary: '#4338CA',
  onPrimary: '#FFFFFF',
  passText: '#166534',
  passFill: '#DCFCE7',
  failText: '#991B1B',
  failFill: '#FEE2E2',
};

const dark: Theme = {
  dark: true,
  background: '#0B1020',
  surface: '#151B2E',
  border: '#28324D',
  text: '#F3F4F6',
  muted: '#A3ACBD',
  primary: '#818CF8',
  onPrimary: '#0B1020',
  passText: '#BBF7D0',
  passFill: '#14532D',
  failText: '#FECACA',
  failFill: '#7F1D1D',
};

export function useTheme(): Theme {
  return useColorScheme() === 'dark' ? dark : light;
}

export const MONO = Platform.select({
  ios: 'Menlo',
  android: 'monospace',
  default: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
});
