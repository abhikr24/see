import React from 'react';

import { RoleTabShell } from '@/features/shell/RoleTabShell';

export default function OwnerLayout() {
  return <RoleTabShell role="owner" />;
}
