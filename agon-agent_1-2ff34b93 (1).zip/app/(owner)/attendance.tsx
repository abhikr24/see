import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

/** Target of the dashboard's "Take attendance" shortcut. Receives `?batchId=` for the batch to mark. */
export default function OwnerAttendanceRoute() {
  return (
    <TabPlaceholder
      tabLabel="Take attendance"
      prompt="NOT BUILT YET"
      title="Roll call lands here"
      description="The dashboard already opens this screen with the batch to mark (batchId). The roll-call screen itself is built by a later prompt."
    />
  );
}
