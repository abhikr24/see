import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function OwnerBatchesRoute() {
  return (
    <TabPlaceholder
      tabLabel="Batches"
      prompt="PROMPT P9"
      title="Built in Prompt P9 (Owner dashboard)"
      description="Batch, timetable and teacher-workload management will be built here by Prompt P9."
    />
  );
}
