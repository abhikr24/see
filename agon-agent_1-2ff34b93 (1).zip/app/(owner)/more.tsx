import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function OwnerMoreRoute() {
  return (
    <TabPlaceholder
      tabLabel="More"
      prompt="PROMPT P9"
      title="Built in Prompt P9 (Owner dashboard)"
      description="Staff, branches, reports and the institute profile will be built here by Prompt P9."
    />
  );
}
