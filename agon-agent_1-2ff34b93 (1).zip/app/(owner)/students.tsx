import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function OwnerStudentsRoute() {
  return (
    <TabPlaceholder
      tabLabel="Students"
      prompt="PROMPT P9"
      title="Built in Prompt P9 (Owner dashboard)"
      description="The student roster, admissions and profiles will be built here by Prompt P9."
    />
  );
}
