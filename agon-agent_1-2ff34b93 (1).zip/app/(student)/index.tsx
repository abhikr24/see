import React from 'react';

import { HomePlaceholder } from '@/features/shell/HomePlaceholder';

export default function StudentHomeRoute() {
  return (
    <HomePlaceholder
      prompt="PROMPT P15"
      title="Built in Prompt P15 (Student screens)"
      description="Today's classes, attendance streak and the latest result will replace this card."
    />
  );
}
