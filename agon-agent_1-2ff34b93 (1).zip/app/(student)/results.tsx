import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function StudentResultsRoute() {
  return (
    <TabPlaceholder
      tabLabel="Results"
      prompt="PROMPT P15"
      title="Built in Prompt P15 (Student screens)"
      description="Exam results and report cards will be built here by Prompt P15."
    />
  );
}
