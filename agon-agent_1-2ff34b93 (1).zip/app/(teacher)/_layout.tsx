import React from 'react';

import { RoleTabShell } from '@/features/shell/RoleTabShell';

export default function TeacherLayout() {
  return <RoleTabShell role="teacher" />;
}
