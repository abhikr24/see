import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function TeacherClassesRoute() {
  return (
    <TabPlaceholder
      tabLabel="Classes"
      prompt="PROMPT P13"
      title="Built in Prompt P13 (Teacher screens)"
      description="Class rosters, timetable and attendance marking will be built here by Prompt P13."
    />
  );
}
