import React from 'react';

import { HomePlaceholder } from '@/features/shell/HomePlaceholder';

export default function TeacherHomeRoute() {
  return (
    <HomePlaceholder
      prompt="PROMPT P13"
      title="Built in Prompt P13 (Teacher screens)"
      description="Today's schedule, quick attendance and pending homework will replace this card."
    />
  );
}
