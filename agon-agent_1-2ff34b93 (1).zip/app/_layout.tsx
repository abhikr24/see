import '../global.css';
import React from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { DEFAULT_BACKEND, DEFAULT_INSTITUTE_ID, createBackends } from '../src/backends';
import { BackendProvider } from '../src/core/backend';
import { DevAuthBypassBanner } from '../src/features/shell/DevAuthBypassBanner';
import { useSessionStore } from '../src/store/session';

const backends = createBackends();

/**
 * Keeps the session queries subscribed for the life of the app, so invalidating
 * `session` / `my-institutes` / `memberships` after sign-in re-reads getSession
 * instead of leaving a signed-out snapshot until the next full reload.
 */
function SessionCacheKeeper() {
  useSessionStore();
  return null;
}

export default function RootLayout() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <BackendProvider
          backends={backends}
          initial={DEFAULT_BACKEND}
          instituteId={DEFAULT_INSTITUTE_ID}
        >
          <DevAuthBypassBanner />
          <SessionCacheKeeper />
          <Stack screenOptions={{ headerShown: false }} />
          <StatusBar style="dark" />
        </BackendProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
