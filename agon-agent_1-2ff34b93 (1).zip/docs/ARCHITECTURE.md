# Architecture

## The one rule

The UI never knows what database exists.

```
app/ + src/features/          ← screens. Call hooks & UI primitives. No SDK imports. Ever.
        │
        ▼
src/core/backend.tsx          ← useStudents(), useAttendance(), useFees(), …
        │
        ▼
src/core/contracts/ports.ts   ← 34 interfaces. The only vocabulary the app speaks.
        │
        ▼
src/adapters/supabase/        ← the only code that knows Postgres exists
src/backends/memory/          ← reference in-memory adapter for offline & contract checks
        │
        ▼
src/backends/index.ts         ← registers live & reference adapters
```

## Design system (`src/components/ui/` + `src/lib/theme.ts`)

Every visual primitive lives under `src/components/ui/` and reads tokens exclusively from `src/lib/theme.ts`:
- Zero hardcoded hex literals outside `src/lib/theme.ts`.
- Every component accepts a `className` passthrough for NativeWind composition.
- Charts are built on `react-native-gifted-charts` (flat, no gridlines, saffron spotlight).
- Sheets are built on `@gorhom/bottom-sheet`.
- The interactive QA gallery at `/dev/components` renders all 35 primitives across every variant and state.
