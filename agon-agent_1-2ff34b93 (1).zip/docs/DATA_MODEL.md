# GuruFlow data model

Source of truth: `supabase/migrations/0003_core.sql` … `0008_rls.sql`, demo data in `supabase/seed.sql`.
62 tables, all in schema `public`, all with row level security enabled. Requires PostgreSQL 15+.

## Conventions

| Rule | Detail |
|---|---|
| Primary key | `id uuid primary key` on every table |
| Tenant column | `institute_id uuid not null` on every table outside the GLOBAL group. On `institutes` it is a generated copy of `id`. |
| Timestamps | `created_at`, `updated_at` + trigger `trg_<table>_updated_at` (`set_updated_at()`) on every table |
| Tenant integrity | Tenant tables have `unique (institute_id, id)`; children reference parents with composite keys `(institute_id, x_id)`, so a row cannot point into another institute |
| Batch integrity | Rows with both `batch_id` and `student_id` reference `batch_students (institute_id, batch_id, student_id)` – a teacher can only write about students enrolled in that batch |
| Enumerations | `text` + `check` constraint (no enum types) |
| Money | `numeric(12,2)`, institute currency (INR by default) |

`0003_core.sql` starts by **dropping every table in `public`** (and any app trigger on `auth.users`). The old 17-table schema is replaced, not migrated – existing rows are lost. Existing `auth.users` accounts are kept and backfilled into `users` / `profiles` / `user_preferences`.

## Tables

### GLOBAL (4) · `0003_core.sql` · no `institute_id`
| Table | Purpose |
|---|---|
| `users` | Mirror of `auth.users` (`id` references it). Written only by the `handle_auth_user` trigger. |
| `profiles` | Name, avatar, basic details. One per user. |
| `user_preferences` | Theme, language, notification channels, default institute. One per user. |
| `sessions` | App device sessions and push tokens (not `auth.sessions`). |

### TENANT (5) · `0003_core.sql`
| Table | Purpose |
|---|---|
| `institutes` | The tenant. `code` is the join code (e.g. `SUNRISE-PAT`). Creating one makes `owner_id` its first active owner. |
| `memberships` | User ↔ institute. `role`: owner, admin, teacher, student, parent. `status`: pending, active, suspended, rejected. `permissions[]`: delegated powers for admins. One row per user per institute. |
| `invitations` | Invite by email/phone with a token. |
| `branches` | Physical locations. |
| `institute_settings` | Academic year, timezone, attendance and fee defaults. One per institute. |

### ACADEMICS (10) · `0004_academics.sql`
| Table | Purpose |
|---|---|
| `student_profiles` | The student record. |
| `guardians` | Parent/guardian contact; `membership_id` once they have a login. |
| `student_memberships` | Student record ↔ the student's own login. Role pinned to `student` by foreign key. |
| `parent_links` | Student ↔ guardian. |
| `student_history` | Timeline: admitted, batch changes, promotions, notes. |
| `teacher_profiles` | Public teacher card (readable by students). |
| `staff_records` | HR record: employee code, salary, contact, bank details. |
| `teacher_assignments` | Staffing plan: teacher ↔ subject (↔ batch), periods per week. |
| `workloads` | Weekly periods/hours per teacher. |
| `leave_requests` | Staff leave and its approval. |

### BATCHES (6) · `0004_academics.sql`
| Table | Purpose |
|---|---|
| `batches` | A class group, e.g. Class 10-A. |
| `subjects` | Subjects taught by the institute. |
| `batch_students` | Enrolment + roll number. |
| `batch_teachers` | Who teaches in a batch. **Defines a teacher's "own batches" for RLS.** |
| `timetables` | Weekly periods. |
| `classrooms` | Rooms. |

### ATTENDANCE (3) · HOMEWORK (4) · EXAMS (4) · `0004_academics.sql`
| Table | Purpose |
|---|---|
| `attendance_sessions` | One roll call (batch, date, period). |
| `attendance_records` | One student in one session: present, absent, late, leave. |
| `attendance_corrections` | Request to change a record, and its review. |
| `assignments` | Homework set for a batch. |
| `submissions` | A student's answer. Holds no marks. |
| `attachments` | Files for any record (`entity_type`, `entity_id`). |
| `feedback` | Teacher's marks and comment on a submission. |
| `exams` | An exam for a batch, covering several subjects. |
| `exam_questions` | Question paper. |
| `marks` | One student, one subject, one exam. |
| `results` | Total, percentage, grade, rank per student per exam. |

### LEARNING (8) · `0004_academics.sql`
| Table | Purpose |
|---|---|
| `materials` | Notes, PDFs, videos, links. `batch_id` null = whole institute. |
| `material_access` | Per-student open count and progress. |
| `bookmarks` | A user's saved items. |
| `practice_questions` | Question bank. |
| `quizzes` | Ordered set of practice questions for a batch. |
| `quiz_attempts` | A student's attempt and score. |
| `study_tasks` | To-do items for a student. |
| `student_goals` | Targets (attendance %, exam %, hours). |

### FINANCE (6) · `0005_finance.sql`
| Table | Purpose |
|---|---|
| `fee_structures` | Fee plan for a batch/year. |
| `student_fees` | A student's fee for a structure, with discount. |
| `installments` | One row per term. |
| `payments` | Money received. |
| `receipts` | One per payment, numbered per institute. |
| `refunds` | Money returned against a payment. |

### COMMUNICATION (6) · `0006_communication.sql`
| Table | Purpose |
|---|---|
| `notices` | Announcements. `audience[]` = roles that may read; `batch_id` null = everyone; `published_at` null = draft. |
| `notifications` | One row per recipient. |
| `conversations` | A thread; `participant_ids[]`, messages kept in a `jsonb` array. |
| `doubts` | Student question and the teacher's answer. |
| `teacher_feedback` | Teacher's remark about a student, optionally shared with the family. |
| `meeting_requests` | Parent–teacher meetings. |

### BUSINESS (6) · `0007_business.sql`
| Table | Purpose |
|---|---|
| `admission_leads` | Enquiry pipeline: new → contacted → interested → demo_scheduled → demo_attended → negotiation → enrolled / lost. |
| `lead_followups` | Calls and visits against a lead. |
| `plans` | The institute's copy of its SaaS plan (limits, price). Tenant-scoped so that no table is readable across institutes. |
| `subscriptions` | The institute's subscription. One live row per institute. |
| `usage_records` | Metered usage per period. |
| `audit_logs` | Append-only activity log. |

## Row level security · `0008_rls.sql`

### Helper functions
| Function | Returns |
|---|---|
| `auth_institute_ids()` | `uuid[]` – institutes where the caller has an **active** membership |
| `has_role(inst, roles text[])` | caller actively holds one of the roles in `inst` |
| `my_student_ids()` | `uuid[]` – the caller's own student record (via `student_memberships`) and their children (via `guardians` + `parent_links`) |
| `has_permission(inst, perm)` | owner, or admin whose `permissions` contains `perm` |
| `my_teacher_ids()` / `my_batch_ids()` | caller's teacher profile / the batches they teach |
| `my_student_batch_ids()` | batches the caller's students are enrolled in |
| `my_taught_student_ids()` | students in the batches the caller teaches |
| `is_staff_over(user)` / `can_view_profile(user)` | visibility of `users` / `profiles` rows |

All are `security definer`, `search_path = ''`, and only ever report on the calling user.

### Who can do what
Every tenant policy is `institute_id = any(auth_institute_ids()) and (<role rule>)`.

| Role | Read | Write |
|---|---|---|
| **owner** | Everything in the institute | Everything except billing tables |
| **admin** | Academics, batches, attendance, homework, exams, learning, communication, memberships | Same academic tables. `fees`, `institute`, `members`, `staff`, `leads`, `billing`, `audit` only when granted in `memberships.permissions` |
| **teacher** | Own batches: students, attendance, assignments, submissions, exams, marks, results, doubts. All materials and practice questions. Own staff record, workload, leave. | Attendance, assignments, feedback, exams, marks, results, materials, quizzes, doubts, teacher feedback, notices – **own batches only** |
| **student** | Rows where the student is in `my_student_ids()`; their batch's published assignments/exams/materials/notices; own fees | Own submissions, quiz attempts, study tasks, goals, doubts, bookmarks, correction requests |
| **parent** | Same as student, for their children | Meeting requests and attendance-correction requests for their children |
| **pending / suspended / rejected** | Nothing, except their own `memberships` row | May withdraw their own pending request |
| **anon** | Nothing (no grants, no policies) | Nothing |

Permission-gated tables: `student_fees`, `installments`, `payments`, `receipts`, `refunds`, `fee_structures` (`fees`) · `institutes`, `branches`, `institute_settings` (`institute`) · `memberships`, `invitations` (`members`) · `staff_records`, `teacher_profiles`, `teacher_assignments`, `batch_teachers`, `workloads`, `leave_requests` (`staff`) · `admission_leads`, `lead_followups` (`leads`) · `plans`, `subscriptions`, `usage_records` (`billing`, read only – written by the service role) · `audit_logs` (`audit`, read only – any member may insert their own entries).

### Guards
- **`membership_guard`** (before insert/update/delete on `memberships`)
  - only an owner can change `role` or `permissions`, grant owner/admin, or modify/remove an owner or admin
  - a self-made join request must be `pending` with role teacher, student or parent
  - an institute always keeps at least one active owner
  - a membership cannot be moved to another user or institute
  - Requests with no user (service role, SQL editor, migrations, seed) skip the actor checks.
- **`institute_guard`** – only an owner can change `institutes.owner_id`.
- **Teachers are never students** – enforced three ways: `student_memberships` can only reference a membership whose role is `student`; `teacher_profiles` rejects a login whose role is `student`; `membership_guard` rejects changing a teacher's role to `student`.

### Known limits
- A pending user cannot read `institutes`, so looking an institute up by its join code needs a `security definer` RPC or an edge function. None is included.
- Accepting an invitation needs the service role (invitees cannot read `invitations`).
- `conversations.messages` is a `jsonb` array: any participant can rewrite the thread.
- `quiz_attempts.score` is written by the student's client; score on the server if it matters.

## Seed · `supabase/seed.sql`

Sunrise Coaching Classes, Patna (`SUNRISE-PAT`). All accounts sign in with the password in the seed file header – local use only.

| NN | What |
|---|---|
| 01 | Institute (also its `institute_settings` row) |
| 02 | Owner – Rahul Sharma |
| 03–07 | Teachers – Rohit Verma (Mathematics, class teacher), Priya Nair (Physics), Meera Iyer (Chemistry), Sneha Iyer (English), Arun Kumar (Biology) |
| 08 | Branch – Boring Road (Main) |
| 09 | Batch – Class 10-A |
| 14–25 | Students, NN = roll number. 14 Aarav Sharma, 15 Aditya Pandey, 16 Ananya Singh, 17 Diya Gupta, 18 Faizan Khan, 19 Ishaan Mishra, 20 Kavya Sinha, 21 Neha Kumari, 22 Rohan Yadav, 23 Saanvi Jha, 24 Tanvi Prasad, 25 Vivaan Raj |
| 38–43 | Pending join requests – 3 students, 2 parents, 1 teacher |
| 44–48 | Subjects – Mathematics, Physics, Chemistry, English, Biology |
| 50 | Exam – Unit Test 3 |
| 51 | Fee structure |
| 61–66 | Notices |
| 71–78 | Admission leads, one per pipeline stage |

ID scheme: `00000000-0000-4000-8000-0000000000NN`. A person keeps their NN in every table with one row per person (`users`, `profiles`, `memberships`, `student_profiles`, `teacher_profiles`, `batch_students`, `student_fees`, `results` …), and attendance sessions use the day number 01–30. Tables with one row per student per day/subject/term use `00000000-0000-4000-8000-0000XX0000NN` (XX = day 01–30, subject 44–48 or term 01–03; NN = roll number).

| Data | Rows | Notes |
|---|---|---|
| Accounts / memberships | 24 | 1 owner + 5 teachers + 12 students active, 6 pending |
| Attendance | 30 sessions, 360 records | Last 30 Mon–Sat days up to yesterday. 331 attended (323 present + 8 late) = 91.94 % → 92 %. 25 absent, 4 leave. |
| Unit Test 3 | 60 marks, 12 results | 5 subjects × 25. Rank 1 Saanvi Jha 119/125; Aarav Sharma 112/125. |
| Fees | 36 installments, 22 payments, 22 receipts | ₹36,000 in 3 terms. Term 1 paid by all; Term 2: 8 paid, 2 partial (roll 22, 23), 2 overdue (24, 25); Term 3 upcoming. |
| Notices | 6 | 5 visible to students, 1 staff-only |
| Leads | 8 | 8 different stages |

Dates are relative to `current_date`. Parents/guardians, timetables, homework and billing rows are not seeded.
