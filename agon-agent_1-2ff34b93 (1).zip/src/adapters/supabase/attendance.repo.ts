import type { AttendanceRecord, AttendanceSession, AttendanceSheet, AttendanceSummary, ID } from '../../core/contracts/models';
import type { AttendanceFilter, AttendanceRepo, AttendanceSheetInput } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapAttendanceRecord, mapAttendanceSession } from './mappers';

export function attendanceRepo(): AttendanceRepo {
  return {
    async listSessions(instituteId: ID, query?: ListQuery<AttendanceSession>): Promise<Page<AttendanceSession>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('attendance_sessions').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('session_date', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapAttendanceSession), count, offset, limit);
      } catch {
        return memoryFallback.attendance.listSessions(instituteId, query);
      }
    },

    async getSheet(instituteId: ID, sessionId: ID): Promise<AttendanceSheet> {
      try {
        const { data: session, error: sErr } = await supabase.from('attendance_sessions').select('*').eq('institute_id', instituteId).eq('id', sessionId).single();
        if (sErr) throw sErr;
        const { data: records, error: rErr } = await supabase.from('attendance_records').select('*').eq('institute_id', instituteId).eq('session_id', sessionId);
        if (rErr) throw rErr;
        return {
          session: mapAttendanceSession(session),
          records: (records ?? []).map(mapAttendanceRecord),
        };
      } catch {
        return memoryFallback.attendance.getSheet(instituteId, sessionId);
      }
    },

    async saveSheet(instituteId: ID, input: AttendanceSheetInput): Promise<AttendanceSheet> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const userId = user?.user?.id ?? null;
        const { data: session, error: sErr } = await supabase.from('attendance_sessions').upsert({
          institute_id: instituteId, batch_id: input.batchId, session_date: input.date, period: input.period ?? 1,
          subject_id: input.subjectId ?? null, teacher_id: input.teacherId ?? null, notes: input.notes ?? null,
          status: 'submitted', marked_by: userId, marked_at: new Date().toISOString(),
        }, { onConflict: 'batch_id,session_date,period' }).select().single();
        if (sErr) throw sErr;

        const recordRows = input.records.map((r: { studentId: ID; status: any; remark?: string | null }) => ({
          institute_id: instituteId, session_id: session.id, batch_id: input.batchId,
          student_id: r.studentId, status: r.status, remark: r.remark ?? null, marked_by: userId,
        }));
        const { data: records, error: rErr } = await supabase.from('attendance_records').upsert(recordRows, { onConflict: 'session_id,student_id' }).select();
        if (rErr) throw rErr;
        return {
          session: mapAttendanceSession(session),
          records: (records ?? []).map(mapAttendanceRecord),
        };
      } catch {
        return memoryFallback.attendance.saveSheet(instituteId, input);
      }
    },

    async listRecords(instituteId: ID, filter: AttendanceFilter): Promise<AttendanceRecord[]> {
      try {
        let q = supabase.from('attendance_records').select('*').eq('institute_id', instituteId);
        if (filter.studentId) q = q.eq('student_id', filter.studentId);
        if (filter.batchId) q = q.eq('batch_id', filter.batchId);
        const { data, error } = await q;
        if (error) throw error;
        return (data ?? []).map(mapAttendanceRecord);
      } catch {
        return memoryFallback.attendance.listRecords(instituteId, filter);
      }
    },

    async summary(instituteId: ID, filter: AttendanceFilter): Promise<AttendanceSummary> {
      try {
        const records = await this.listRecords(instituteId, filter);
        const total = records.length;
        const present = records.filter((r) => r.status === 'present').length;
        const late = records.filter((r) => r.status === 'late').length;
        const absent = records.filter((r) => r.status === 'absent').length;
        const leave = records.filter((r) => r.status === 'leave').length;
        const percent = total > 0 ? Math.round(((present + late) / total) * 1000) / 10 : 0;
        return { total, present, late, absent, leave, percent };
      } catch {
        return memoryFallback.attendance.summary(instituteId, filter);
      }
    },
  };
}
