import type { Exam, ExamQuestion, ID, NewEntity, Patch, Result, Upsert } from '../../core/contracts/models';
import type { ExamRepo, ResultRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapExam, mapExamQuestion, mapResult } from './mappers';

export function examRepo(): ExamRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Exam>): Promise<Page<Exam>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('exams').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapExam), count, offset, limit);
      } catch {
        return memoryFallback.exams.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Exam> {
      try {
        const { data, error } = await supabase.from('exams').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapExam(data);
      } catch {
        return memoryFallback.exams.get(instituteId, id);
      }
    },
    async create(instituteId: ID, input: NewEntity<Exam, 'batchId' | 'name'>): Promise<Exam> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('exams').insert({
          institute_id: instituteId, batch_id: input.batchId, name: input.name,
          exam_type: input.examType ?? 'unit_test', starts_on: input.startsOn ?? null,
          ends_on: input.endsOn ?? null, total_marks: input.totalMarks ?? null,
          pass_percent: input.passPercent ?? 33, status: input.status ?? 'draft', created_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapExam(data);
      } catch {
        return memoryFallback.exams.create(instituteId, input);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Exam>): Promise<Exam> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.name !== undefined) row.name = patch.name;
        if (patch.examType !== undefined) row.exam_type = patch.examType;
        if (patch.startsOn !== undefined) row.starts_on = patch.startsOn;
        if (patch.endsOn !== undefined) row.ends_on = patch.endsOn;
        if (patch.totalMarks !== undefined) row.total_marks = patch.totalMarks;
        if (patch.passPercent !== undefined) row.pass_percent = patch.passPercent;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('exams').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapExam(data);
      } catch {
        return memoryFallback.exams.update(instituteId, id, patch);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('exams').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.exams.remove(instituteId, id);
      }
    },
    async publish(instituteId: ID, id: ID): Promise<Exam> {
      try {
        const { data, error } = await supabase.from('exams').update({
          status: 'published', published_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapExam(data);
      } catch {
        return memoryFallback.exams.publish(instituteId, id);
      }
    },
    async listQuestions(instituteId: ID, examId: ID): Promise<ExamQuestion[]> {
      try {
        const { data, error } = await supabase.from('exam_questions').select('*').eq('institute_id', instituteId).eq('exam_id', examId).order('question_no', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapExamQuestion);
      } catch {
        return memoryFallback.exams.listQuestions(instituteId, examId);
      }
    },
    async saveQuestion(instituteId: ID, input: Upsert<ExamQuestion, 'examId' | 'questionNo' | 'text'>): Promise<ExamQuestion> {
      try {
        const row = {
          institute_id: instituteId, exam_id: input.examId, batch_id: input.batchId,
          subject_id: input.subjectId ?? null, question_no: input.questionNo, question_text: input.text,
          question_type: input.questionType ?? 'short', options: input.options ?? null,
          answer_key: input.answerKey ?? null, max_marks: input.maxMarks ?? 1, topic: input.topic ?? null,
        };
        const op = input.id
          ? supabase.from('exam_questions').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('exam_questions').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapExamQuestion(data);
      } catch {
        return memoryFallback.exams.saveQuestion(instituteId, input);
      }
    },
    async removeQuestion(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('exam_questions').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.exams.removeQuestion(instituteId, id);
      }
    },
  };
}

export function resultRepo(): ResultRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Result>): Promise<Page<Result>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('results').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1);
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapResult), count, offset, limit);
      } catch {
        return memoryFallback.results.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Result> {
      try {
        const { data, error } = await supabase.from('results').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapResult(data);
      } catch {
        return memoryFallback.results.get(instituteId, id);
      }
    },
    async listForStudent(instituteId: ID, studentId: ID): Promise<Result[]> {
      try {
        const { data, error } = await supabase.from('results').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapResult);
      } catch {
        return memoryFallback.results.listForStudent(instituteId, studentId);
      }
    },
    async compute(instituteId: ID, examId: ID): Promise<Result[]> {
      return memoryFallback.results.compute(instituteId, examId);
    },
  };
}
