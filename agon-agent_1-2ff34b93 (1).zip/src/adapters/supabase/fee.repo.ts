import type { FeeStructure, FeeSummary, ID, Installment, InstallmentStatus, StudentFee, Upsert } from '../../core/contracts/models';
import type { AssignFeeInput, FeeRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapFeeStructure, mapInstallment, mapStudentFee } from './mappers';

export function feeRepo(): FeeRepo {
  return {
    async listStructures(instituteId: ID, query?: ListQuery<FeeStructure>): Promise<Page<FeeStructure>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('fee_structures').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapFeeStructure), count, offset, limit);
      } catch {
        return memoryFallback.fees.listStructures(instituteId, query);
      }
    },

    async saveStructure(instituteId: ID, input: Upsert<FeeStructure, 'name' | 'academicYear' | 'totalAmount'>): Promise<FeeStructure> {
      try {
        const row = {
          institute_id: instituteId, name: input.name, academic_year: input.academicYear,
          total_amount: input.totalAmount, batch_id: input.batchId ?? null,
          installment_count: input.installmentCount ?? 1, frequency: input.frequency ?? 'term',
          components: input.components ?? [], late_fee_per_day: input.lateFeePerDay ?? 0,
          is_active: input.isActive ?? true,
        };
        const op = input.id
          ? supabase.from('fee_structures').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('fee_structures').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapFeeStructure(data);
      } catch {
        return memoryFallback.fees.saveStructure(instituteId, input);
      }
    },

    async listStudentFees(instituteId: ID, query?: ListQuery<StudentFee>): Promise<Page<StudentFee>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('student_fees').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapStudentFee), count, offset, limit);
      } catch {
        return memoryFallback.fees.listStudentFees(instituteId, query);
      }
    },

    async assign(instituteId: ID, input: AssignFeeInput): Promise<StudentFee> {
      try {
        const { data: st } = await supabase.from('fee_structures').select('*').eq('id', input.feeStructureId).single();
        const gross = st?.total_amount ?? 0;
        const discount = input.discountAmount ?? 0;
        const { data, error } = await supabase.from('student_fees').insert({
          institute_id: instituteId, student_id: input.studentId, fee_structure_id: input.feeStructureId,
          academic_year: st?.academic_year ?? '2026-27', gross_amount: gross,
          discount_amount: discount, discount_reason: input.discountReason ?? null, status: 'active',
        }).select().single();
        if (error) throw error;
        return mapStudentFee(data);
      } catch {
        return memoryFallback.fees.assign(instituteId, input);
      }
    },

    async listInstallments(instituteId: ID, filter?: { studentId?: ID; studentFeeId?: ID; status?: InstallmentStatus }): Promise<Installment[]> {
      try {
        let q = supabase.from('installments').select('*').eq('institute_id', instituteId);
        if (filter?.studentId) q = q.eq('student_id', filter.studentId);
        if (filter?.studentFeeId) q = q.eq('student_fee_id', filter.studentFeeId);
        if (filter?.status) q = q.eq('status', filter.status);
        const { data, error } = await q.order('due_date', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapInstallment);
      } catch {
        return memoryFallback.fees.listInstallments(instituteId, filter);
      }
    },

    async waiveInstallment(instituteId: ID, installmentId: ID): Promise<Installment> {
      try {
        const { data, error } = await supabase.from('installments').update({
          status: 'waived',
        }).eq('institute_id', instituteId).eq('id', installmentId).select().single();
        if (error) throw error;
        return mapInstallment(data);
      } catch {
        return memoryFallback.fees.waiveInstallment(instituteId, installmentId);
      }
    },

    async summary(instituteId: ID): Promise<FeeSummary> {
      try {
        const insts = await this.listInstallments(instituteId);
        let billed = 0, collected = 0, outstanding = 0, overdue = 0, overdueCount = 0;
        const today = new Date().toISOString().slice(0, 10);
        for (const inst of insts) {
          if (inst.status === 'waived') continue;
          billed += inst.amount;
          collected += inst.paidAmount;
          const rem = Math.max(0, inst.amount - inst.paidAmount);
          outstanding += rem;
          if (rem > 0 && inst.dueDate < today) {
            overdue += rem;
            overdueCount++;
          }
        }
        return { billed, collected, outstanding, overdue, overdueInstallments: overdueCount };
      } catch {
        return memoryFallback.fees.summary(instituteId);
      }
    },
  };
}
