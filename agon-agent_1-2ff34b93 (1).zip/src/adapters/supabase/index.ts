import type { Backend } from '../../core/contracts/ports';
import { analyticsRepo } from './analytics.repo';
import { assignmentRepo, submissionRepo } from './assignment.repo';
import { attendanceRepo } from './attendance.repo';
import { authAdapter } from './auth.adapter';
import { batchRepo, subjectRepo, timetableRepo } from './batch.repo';
import { branchRepo } from './branch.repo';
import { doubtRepo, meetingRepo } from './doubt.repo';
import { examRepo, resultRepo } from './exam.repo';
import { feeRepo } from './fee.repo';
import { instituteRepo } from './institute.repo';
import { leadRepo } from './lead.repo';
import { markRepo } from './mark.repo';
import { materialRepo } from './material.repo';
import { invitationRepo, membershipRepo } from './membership.repo';
import { exportRepo, realtimePort } from './misc.adapter';
import { noticeRepo } from './notice.repo';
import { notificationRepo } from './notification.repo';
import { paymentGatewayPort, paymentRepo } from './payment.repo';
import { practiceRepo } from './practice.repo';
import { progressRepo } from './progress.repo';
import { receiptRepo } from './receipt.repo';
import { staffRepo } from './staff.repo';
import { storageAdapter } from './storage.adapter';
import { guardianRepo, studentRepo } from './student.repo';
import { subscriptionRepo } from './subscription.repo';

export function createSupabaseBackend(): Backend {
  return {
    name: 'supabase',
    auth: authAdapter(),
    institutes: instituteRepo(),
    branches: branchRepo(),
    memberships: membershipRepo(),
    invitations: invitationRepo(),
    staff: staffRepo(),
    students: studentRepo(),
    guardians: guardianRepo(),
    batches: batchRepo(),
    subjects: subjectRepo(),
    timetable: timetableRepo(),
    attendance: attendanceRepo(),
    assignments: assignmentRepo(),
    submissions: submissionRepo(),
    exams: examRepo(),
    marks: markRepo(),
    results: resultRepo(),
    materials: materialRepo(),
    practice: practiceRepo(),
    fees: feeRepo(),
    payments: paymentRepo(),
    receipts: receiptRepo(),
    notices: noticeRepo(),
    notifications: notificationRepo(),
    doubts: doubtRepo(),
    meetings: meetingRepo(),
    leads: leadRepo(),
    analytics: analyticsRepo(),
    subscriptions: subscriptionRepo(),
    exports: exportRepo(),
    storage: storageAdapter(),
    paymentGateway: paymentGatewayPort(),
    realtime: realtimePort(),
    progress: progressRepo(),
  };
}

export * from './client';
export * from './mappers';
