import type { AdmissionLead, ID, LeadFollowup, LeadStage, NewEntity, Patch, Student } from '../../core/contracts/models';
import type { LeadRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapLead, mapLeadFollowup, mapStudent } from './mappers';

export function leadRepo(): LeadRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<AdmissionLead>): Promise<Page<AdmissionLead>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('admission_leads').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.stage) q = q.eq('stage', query.where.stage);
        if (query?.search) q = q.ilike('student_name', `%${query.search}%`);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapLead), count, offset, limit);
      } catch {
        return memoryFallback.leads.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<AdmissionLead> {
      try {
        const { data, error } = await supabase.from('admission_leads').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapLead(data);
      } catch {
        return memoryFallback.leads.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<AdmissionLead, 'studentName'>): Promise<AdmissionLead> {
      try {
        const { data, error } = await supabase.from('admission_leads').insert({
          institute_id: instituteId, student_name: input.studentName, branch_id: input.branchId ?? null,
          guardian_name: input.guardianName ?? null, phone: input.phone ?? null, email: input.email ?? null,
          class_interested: input.classInterested ?? null, school_name: input.schoolName ?? null,
          source: input.source ?? 'walk_in', stage: input.stage ?? 'new',
          assigned_to: input.assignedTo ?? null, expected_fee: input.expectedFee ?? null,
          next_followup_at: input.nextFollowupAt ?? null, notes: input.notes ?? null,
        }).select().single();
        if (error) throw error;
        return mapLead(data);
      } catch {
        return memoryFallback.leads.create(instituteId, input);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<AdmissionLead>): Promise<AdmissionLead> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.studentName !== undefined) row.student_name = patch.studentName;
        if (patch.guardianName !== undefined) row.guardian_name = patch.guardianName;
        if (patch.phone !== undefined) row.phone = patch.phone;
        if (patch.email !== undefined) row.email = patch.email;
        if (patch.classInterested !== undefined) row.class_interested = patch.classInterested;
        if (patch.stage !== undefined) row.stage = patch.stage;
        if (patch.nextFollowupAt !== undefined) row.next_followup_at = patch.nextFollowupAt;
        if (patch.lostReason !== undefined) row.lost_reason = patch.lostReason;
        if (patch.notes !== undefined) row.notes = patch.notes;
        const { data, error } = await supabase.from('admission_leads').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapLead(data);
      } catch {
        return memoryFallback.leads.update(instituteId, id, patch);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('admission_leads').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.leads.remove(instituteId, id);
      }
    },

    async moveStage(instituteId: ID, id: ID, stage: LeadStage, lostReason?: string | null): Promise<AdmissionLead> {
      return this.update(instituteId, id, { stage, lostReason: lostReason ?? null });
    },

    async listFollowups(instituteId: ID, leadId: ID): Promise<LeadFollowup[]> {
      try {
        const { data, error } = await supabase.from('lead_followups').select('*').eq('institute_id', instituteId).eq('lead_id', leadId).order('followup_at', { ascending: false });
        if (error) throw error;
        return (data ?? []).map(mapLeadFollowup);
      } catch {
        return memoryFallback.leads.listFollowups(instituteId, leadId);
      }
    },

    async addFollowup(instituteId: ID, input: NewEntity<LeadFollowup, 'leadId'>): Promise<LeadFollowup> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('lead_followups').insert({
          institute_id: instituteId, lead_id: input.leadId, channel: input.channel ?? 'call',
          summary: input.summary ?? null, outcome: input.outcome ?? null,
          followup_at: input.followupAt ?? new Date().toISOString(),
          next_followup_at: input.nextFollowupAt ?? null, done_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapLeadFollowup(data);
      } catch {
        return memoryFallback.leads.addFollowup(instituteId, input);
      }
    },

    async convert(instituteId: ID, id: ID): Promise<Student> {
      try {
        const lead = await this.get(instituteId, id);
        const { data: st, error: stErr } = await supabase.from('student_profiles').insert({
          institute_id: instituteId, full_name: lead.studentName, phone: lead.phone,
          email: lead.email, school_name: lead.schoolName, class_grade: lead.classInterested,
          status: 'active',
        }).select().single();
        if (stErr) throw stErr;
        await this.update(instituteId, id, { stage: 'enrolled' });
        return mapStudent(st);
      } catch {
        return memoryFallback.leads.convert(instituteId, id);
      }
    },
  };
}
