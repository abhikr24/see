import type {
  AttendanceSummary, ID, InstituteSettings, ProgressSnapshot,
  RiskAlert, RiskKind, RiskLevel, Student360, StudentGoal, StudyTask, Upsert,
} from '../../core/contracts/models';
import type { ProgressPort } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapStudentGoal, mapStudyTask } from './mappers';

/** Configurable early-warning rules constants */
export const RISK_RULES = {
  /** Watch student whose exam average is within this margin of pass mark */
  MARKS_MARGIN: 10,
  /** Minimum homework completion rate percentage */
  HOMEWORK_MIN_PERCENT: 60,
  /** Critical attendance deficit triggering high severity */
  LOW_ATTENDANCE_DEFICIT_HIGH: 15,
  /** Critical homework threshold triggering medium severity */
  HOMEWORK_CRITICAL_PERCENT: 30,
  /** Overdue installments triggering high severity */
  OVERDUE_COUNT_HIGH: 1,
} as const;

export function progressRepo(): ProgressPort {
  return {
    async getStudent360(instituteId: ID, studentId: ID): Promise<Student360> {
      try {
        return await memoryFallback.progress.getStudent360(instituteId, studentId);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async computeSnapshot(instituteId: ID, studentId: ID): Promise<ProgressSnapshot> {
      try {
        return await memoryFallback.progress.computeSnapshot(instituteId, studentId);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listSnapshots(instituteId: ID, studentId: ID): Promise<ProgressSnapshot[]> {
      try {
        return await memoryFallback.progress.listSnapshots(instituteId, studentId);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listAlerts(instituteId: ID, query?: ListQuery<RiskAlert>): Promise<Page<RiskAlert>> {
      try {
        return await memoryFallback.progress.listAlerts(instituteId, query);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async computeAlerts(instituteId: ID, filter?: { batchId?: ID; studentId?: ID }): Promise<RiskAlert[]> {
      try {
        return await memoryFallback.progress.computeAlerts(instituteId, filter);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async setAlertStatus(instituteId: ID, alertId: ID, status: RiskAlert['status']): Promise<RiskAlert> {
      try {
        return await memoryFallback.progress.setAlertStatus(instituteId, alertId, status);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listTasks(instituteId: ID, studentId: ID): Promise<StudyTask[]> {
      try {
        const { data, error } = await supabase.from('study_tasks').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapStudyTask);
      } catch {
        return memoryFallback.progress.listTasks(instituteId, studentId);
      }
    },

    async saveTask(instituteId: ID, input: Upsert<StudyTask, 'studentId' | 'title'>): Promise<StudyTask> {
      try {
        const row = {
          institute_id: instituteId, student_id: input.studentId, title: input.title,
          subject_id: input.subjectId ?? null, notes: input.notes ?? null, due_on: input.dueOn ?? null,
          priority: input.priority ?? 'medium', status: input.status ?? 'todo',
          completed_at: input.status === 'done' ? new Date().toISOString() : null,
          source: input.source ?? 'self',
        };
        const op = input.id
          ? supabase.from('study_tasks').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('study_tasks').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapStudyTask(data);
      } catch {
        return memoryFallback.progress.saveTask(instituteId, input);
      }
    },

    async removeTask(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('study_tasks').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.progress.removeTask(instituteId, id);
      }
    },

    async listGoals(instituteId: ID, studentId: ID): Promise<StudentGoal[]> {
      try {
        const { data, error } = await supabase.from('student_goals').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapStudentGoal);
      } catch {
        return memoryFallback.progress.listGoals(instituteId, studentId);
      }
    },

    async saveGoal(instituteId: ID, input: Upsert<StudentGoal, 'studentId' | 'title'>): Promise<StudentGoal> {
      try {
        const row = {
          institute_id: instituteId, student_id: input.studentId, title: input.title,
          subject_id: input.subjectId ?? null, description: input.description ?? null,
          metric: input.metric ?? 'custom', target_value: input.targetValue ?? null,
          current_value: input.currentValue ?? null, starts_on: input.startsOn ?? new Date().toISOString().slice(0, 10),
          target_date: input.targetDate ?? null, status: input.status ?? 'active',
        };
        const op = input.id
          ? supabase.from('student_goals').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('student_goals').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapStudentGoal(data);
      } catch {
        return memoryFallback.progress.saveGoal(instituteId, input);
      }
    },
  };
}
