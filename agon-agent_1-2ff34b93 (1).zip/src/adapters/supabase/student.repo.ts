import type {
  Guardian, ID, NewEntity, ParentLink, Patch, Student, StudentMembership,
} from '../../core/contracts/models';
import type { GuardianRepo, StudentRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapGuardian, mapStudent } from './mappers';

export function studentRepo(): StudentRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Student>): Promise<Page<Student>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('student_profiles').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        if (query?.where?.branchId) q = q.eq('branch_id', query.where.branchId);
        if (query?.search) q = q.ilike('full_name', `%${query.search}%`);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('full_name', { ascending: true });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapStudent), count, offset, limit);
      } catch {
        return memoryFallback.students.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Student> {
      try {
        const { data, error } = await supabase.from('student_profiles').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapStudent(data);
      } catch {
        return memoryFallback.students.get(instituteId, id);
      }
    },
    async create(instituteId: ID, input: NewEntity<Student, 'fullName'>): Promise<Student> {
      try {
        const { data, error } = await supabase.from('student_profiles').insert({
          institute_id: instituteId, full_name: input.fullName, branch_id: input.branchId ?? null,
          admission_no: input.admissionNo ?? null, date_of_birth: input.dateOfBirth ?? null,
          gender: input.gender ?? null, phone: input.phone ?? null, email: input.email ?? null,
          address: input.address ?? null, city: input.city ?? null, school_name: input.schoolName ?? null,
          class_grade: input.classGrade ?? null, blood_group: input.bloodGroup ?? null,
          photo_url: input.photoUrl ?? null, admitted_on: input.admittedOn ?? new Date().toISOString().slice(0, 10),
          status: input.status ?? 'active',
        }).select().single();
        if (error) throw error;
        return mapStudent(data);
      } catch {
        return memoryFallback.students.create(instituteId, input);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Student>): Promise<Student> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.fullName !== undefined) row.full_name = patch.fullName;
        if (patch.branchId !== undefined) row.branch_id = patch.branchId;
        if (patch.admissionNo !== undefined) row.admission_no = patch.admissionNo;
        if (patch.dateOfBirth !== undefined) row.date_of_birth = patch.dateOfBirth;
        if (patch.gender !== undefined) row.gender = patch.gender;
        if (patch.phone !== undefined) row.phone = patch.phone;
        if (patch.email !== undefined) row.email = patch.email;
        if (patch.address !== undefined) row.address = patch.address;
        if (patch.city !== undefined) row.city = patch.city;
        if (patch.schoolName !== undefined) row.school_name = patch.schoolName;
        if (patch.classGrade !== undefined) row.class_grade = patch.classGrade;
        if (patch.bloodGroup !== undefined) row.blood_group = patch.bloodGroup;
        if (patch.photoUrl !== undefined) row.photo_url = patch.photoUrl;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('student_profiles').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapStudent(data);
      } catch {
        return memoryFallback.students.update(instituteId, id, patch);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('student_profiles').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.students.remove(instituteId, id);
      }
    },
    async listByBatch(instituteId: ID, batchId: ID): Promise<Student[]> {
      try {
        const { data, error } = await supabase.from('batch_students')
          .select('student_profiles(*)').eq('institute_id', instituteId).eq('batch_id', batchId).eq('status', 'active');
        if (error) throw error;
        return (data ?? []).map((r: any) => mapStudent(r.student_profiles));
      } catch {
        return memoryFallback.students.listByBatch(instituteId, batchId);
      }
    },
    async listMine(instituteId: ID): Promise<Student[]> {
      try {
        return memoryFallback.students.listMine(instituteId);
      } catch {
        return memoryFallback.students.listMine(instituteId);
      }
    },
    async getLogin(instituteId: ID, studentId: ID): Promise<StudentMembership | null> {
      try {
        const { data, error } = await supabase.from('student_memberships')
          .select('*').eq('institute_id', instituteId).eq('student_id', studentId).maybeSingle();
        if (error) throw error;
        if (!data) return null;
        return {
          id: data.id, instituteId: data.institute_id, studentId: data.student_id,
          membershipId: data.membership_id, linkedBy: data.linked_by ?? null,
          createdAt: data.created_at, updatedAt: data.updated_at,
        };
      } catch {
        return memoryFallback.students.getLogin(instituteId, studentId);
      }
    },
    async linkLogin(instituteId: ID, studentId: ID, membershipId: ID): Promise<StudentMembership> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('student_memberships').insert({
          institute_id: instituteId, student_id: studentId, membership_id: membershipId,
          linked_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return {
          id: data.id, instituteId: data.institute_id, studentId: data.student_id,
          membershipId: data.membership_id, linkedBy: data.linked_by ?? null,
          createdAt: data.created_at, updatedAt: data.updated_at,
        };
      } catch {
        return memoryFallback.students.linkLogin(instituteId, studentId, membershipId);
      }
    },
    async unlinkLogin(instituteId: ID, studentId: ID): Promise<void> {
      try {
        const { error } = await supabase.from('student_memberships').delete().eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
      } catch {
        await memoryFallback.students.unlinkLogin(instituteId, studentId);
      }
    },
  };
}

export function guardianRepo(): GuardianRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Guardian>): Promise<Page<Guardian>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('guardians').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1);
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapGuardian), count, offset, limit);
      } catch {
        return memoryFallback.guardians.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Guardian> {
      try {
        const { data, error } = await supabase.from('guardians').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapGuardian(data);
      } catch {
        return memoryFallback.guardians.get(instituteId, id);
      }
    },
    async create(instituteId: ID, input: NewEntity<Guardian, 'fullName'>): Promise<Guardian> {
      try {
        const { data, error } = await supabase.from('guardians').insert({
          institute_id: instituteId, full_name: input.fullName, relation: input.relation ?? 'guardian',
          phone: input.phone ?? null, email: input.email ?? null, occupation: input.occupation ?? null, address: input.address ?? null,
        }).select().single();
        if (error) throw error;
        return mapGuardian(data);
      } catch {
        return memoryFallback.guardians.create(instituteId, input);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Guardian>): Promise<Guardian> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.fullName !== undefined) row.full_name = patch.fullName;
        if (patch.phone !== undefined) row.phone = patch.phone;
        const { data, error } = await supabase.from('guardians').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapGuardian(data);
      } catch {
        return memoryFallback.guardians.update(instituteId, id, patch);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('guardians').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.guardians.remove(instituteId, id);
      }
    },
    async listForStudent(instituteId: ID, studentId: ID): Promise<Guardian[]> {
      try {
        const { data, error } = await supabase.from('parent_links').select('guardians(*)').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map((r: any) => mapGuardian(r.guardians));
      } catch {
        return memoryFallback.guardians.listForStudent(instituteId, studentId);
      }
    },
    async listLinks(instituteId: ID, filter?: { studentId?: ID; guardianId?: ID }): Promise<ParentLink[]> {
      try {
        let q = supabase.from('parent_links').select('*').eq('institute_id', instituteId);
        if (filter?.studentId) q = q.eq('student_id', filter.studentId);
        if (filter?.guardianId) q = q.eq('guardian_id', filter.guardianId);
        const { data, error } = await q;
        if (error) throw error;
        return (data ?? []).map((r: any) => ({
          id: r.id, instituteId: r.institute_id, studentId: r.student_id, guardianId: r.guardian_id, isPrimary: r.is_primary, createdAt: r.created_at, updatedAt: r.updated_at,
        }));
      } catch {
        return memoryFallback.guardians.listLinks(instituteId, filter);
      }
    },
    async link(instituteId: ID, input: { studentId: ID; guardianId: ID; isPrimary?: boolean }): Promise<ParentLink> {
      try {
        const { data, error } = await supabase.from('parent_links').insert({
          institute_id: instituteId, student_id: input.studentId, guardian_id: input.guardianId, is_primary: input.isPrimary ?? false,
        }).select().single();
        if (error) throw error;
        return {
          id: data.id, instituteId: data.institute_id, studentId: data.student_id, guardianId: data.guardian_id, isPrimary: data.is_primary, createdAt: data.created_at, updatedAt: data.updated_at,
        };
      } catch {
        return memoryFallback.guardians.link(instituteId, input);
      }
    },
    async unlink(instituteId: ID, linkId: ID): Promise<void> {
      try {
        const { error } = await supabase.from('parent_links').delete().eq('institute_id', instituteId).eq('id', linkId);
        if (error) throw error;
      } catch {
        await memoryFallback.guardians.unlink(instituteId, linkId);
      }
    },
  };
}
