import type { Backend } from '../core/contracts/ports';
import { createSupabaseBackend } from '../adapters/supabase';
import { MEMORY_DEFAULT_INSTITUTE_ID, createMemoryBackend } from './memory';
import { createStubBackend } from './stub';

/**
 * The only place that knows which backends exist. App.tsx hands this list to
 * <BackendProvider>; nothing under app/ or src/features imports from here.
 *
 * To add one: build it in src/backends/<name>/, add it to this array.
 * See docs/ADDING_A_BACKEND.md.
 */
export function createBackends(): Backend[] {
  return [createMemoryBackend(), createSupabaseBackend(), createStubBackend('stub')];
}

/** Backend used on launch. Override with EXPO_PUBLIC_BACKEND=<name>. */
export const DEFAULT_BACKEND = process.env.EXPO_PUBLIC_BACKEND ?? 'supabase';

/** Institute opened on launch, until sign-in and institute selection exist. */
export const DEFAULT_INSTITUTE_ID = process.env.EXPO_PUBLIC_INSTITUTE_ID ?? MEMORY_DEFAULT_INSTITUTE_ID;
