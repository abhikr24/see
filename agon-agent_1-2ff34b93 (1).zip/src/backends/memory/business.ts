import type { AdmissionLead, ExportKind, ID, LeadStage, TrendPoint } from '../../core/contracts/models';
import type {
  AnalyticsRepo,
  ExportRepo,
  LeadRepo,
  StoragePort,
  SubscriptionRepo,
} from '../../core/contracts/ports';
import { attendanceRecords, summarize } from './academics';
import { ownerDashboard } from './dashboard';
import { crud, type Db } from './db';
import * as D from './defaults';
import { addDays, fail, merge, nowIso, round1, round2, sum, todayIso } from './store';

const STAGES: LeadStage[] = [
  'new',
  'contacted',
  'interested',
  'demo_scheduled',
  'demo_attended',
  'negotiation',
  'enrolled',
  'lost',
];

export function leadRepo(db: Db): LeadRepo {
  const base = crud<AdmissionLead, 'studentName'>(db.leads, D.lead);
  return {
    ...base,
    create: async (instituteId, input) => {
      if (!input.studentName.trim()) fail('VALIDATION', 'Student name is required');
      return base.create(instituteId, input);
    },
    moveStage: async (instituteId, id, stage, lostReason = null) => {
      const lead = db.leads.get(instituteId, id);
      if (lead.stage === 'enrolled') fail('CONFLICT', 'An enrolled lead cannot be moved');
      if (stage === 'enrolled') fail('VALIDATION', 'Use convert to enrol a lead');
      if (stage === 'lost' && !lostReason?.trim()) fail('VALIDATION', 'Say why this lead was lost');
      return db.leads.update(instituteId, id, { stage, lostReason: stage === 'lost' ? lostReason : null });
    },
    listFollowups: async (instituteId, leadId) => {
      db.leads.get(instituteId, leadId);
      return db.followups.all(instituteId, { leadId }).sort((a, b) => b.followupAt.localeCompare(a.followupAt));
    },
    addFollowup: async (instituteId, input) => {
      const lead = db.leads.get(instituteId, input.leadId);
      const followup = db.followups.insert(instituteId, merge({ ...D.followup(), doneBy: db.session.userId }, input));
      db.leads.update(instituteId, lead.id, {
        nextFollowupAt: followup.nextFollowupAt,
        stage: lead.stage === 'new' ? 'contacted' : lead.stage,
      });
      return followup;
    },
    convert: async (instituteId, id) => {
      const lead = db.leads.get(instituteId, id);
      if (lead.convertedStudentId) fail('CONFLICT', 'This lead is already enrolled');
      const student = db.students.insert(instituteId, {
        ...D.student(),
        fullName: lead.studentName,
        phone: lead.phone,
        email: lead.email,
        schoolName: lead.schoolName,
        classGrade: lead.classInterested,
        branchId: lead.branchId,
      });
      db.leads.update(instituteId, id, { stage: 'enrolled', convertedStudentId: student.id, nextFollowupAt: null });
      return student;
    },
  };
}

export function analyticsRepo(db: Db): AnalyticsRepo {
  return {
    overview: async (instituteId) => {
      db.institutes.get(instituteId, instituteId);
      const today = todayIso();
      const recent = summarize(attendanceRecords(db, instituteId, { from: addDays(today, -30), to: today }));
      const installments = db.installments.all(instituteId).filter((x) => x.status !== 'waived');
      const collected = sum(installments.map((x) => x.paidAmount));
      return {
        activeStudents: db.students.all(instituteId, { status: 'active' }).length,
        activeTeachers: db.teachers.all(instituteId, { status: 'active' }).length,
        activeBatches: db.batches.all(instituteId, { status: 'active' }).length,
        pendingMembers: db.memberships.all(instituteId, { status: 'pending' }).length,
        attendancePercent: recent.total ? recent.percent : null,
        feesCollected: round2(collected),
        feesOutstanding: round2(sum(installments.map((x) => x.amount)) - collected),
        openLeads: db.leads.all(instituteId).filter((l) => l.stage !== 'enrolled' && l.stage !== 'lost').length,
        openAlerts: db.alerts.all(instituteId, { status: 'open' }).length,
      };
    },
    dashboard: (instituteId) => ownerDashboard(db, instituteId),
    attendanceTrend: async (instituteId, { from, to }) => {
      if (to < from) fail('VALIDATION', 'The range ends before it starts');
      const sessions = db.attendanceSessions.all(instituteId).filter((s) => s.date >= from && s.date <= to);
      return [...new Set(sessions.map((s) => s.date))].sort().map((date): TrendPoint => {
        const ids = sessions.filter((s) => s.date === date).map((s) => s.id);
        const records = db.attendanceRecords.all(instituteId).filter((r) => ids.includes(r.sessionId));
        const attended = records.filter((r) => r.status === 'present' || r.status === 'late').length;
        return { date, value: records.length ? round1((attended / records.length) * 100) : 0 };
      });
    },
    feeCollection: async (instituteId, { from, to }) => {
      if (to < from) fail('VALIDATION', 'The range ends before it starts');
      const byDay = new Map<string, number>();
      for (const payment of db.payments.all(instituteId, { status: 'completed' })) {
        const date = payment.paidAt.slice(0, 10);
        if (date >= from && date <= to) byDay.set(date, round2((byDay.get(date) ?? 0) + payment.amount));
      }
      return [...byDay].sort(([a], [b]) => a.localeCompare(b)).map(([date, value]) => ({ date, value }));
    },
    leadFunnel: async (instituteId) => {
      const leads = db.leads.all(instituteId);
      return STAGES.map((stage) => ({ stage, count: leads.filter((l) => l.stage === stage).length }));
    },
    listAuditLogs: async (instituteId, query) =>
      db.auditLogs.page(instituteId, { sort: { field: 'createdAt', direction: 'desc' }, ...query }),
    recordAudit: async (instituteId, input) => {
      const actorId = db.session.userId;
      const actorRole = actorId ? (db.memberships.find(instituteId, { userId: actorId })?.role ?? null) : null;
      return db.auditLogs.insert(instituteId, merge({ ...D.auditLog(), actorId, actorRole }, input));
    },
  };
}

export function subscriptionRepo(db: Db): SubscriptionRepo {
  const current = (instituteId: ID) =>
    db.subscriptions.all(instituteId).find((s) => s.status !== 'cancelled' && s.status !== 'expired') ?? null;
  return {
    getCurrent: async (instituteId) => current(instituteId),
    listPlans: async (instituteId) =>
      db.plans.all(instituteId, { isActive: true }).sort((a, b) => a.priceMonthly - b.priceMonthly),
    changePlan: async (instituteId, planId, billingCycle) => {
      const plan = db.plans.get(instituteId, planId);
      if (!plan.isActive) fail('VALIDATION', 'That plan is no longer offered');
      const start = nowIso();
      const end = `${addDays(todayIso(), billingCycle === 'yearly' ? 365 : 30)}T00:00:00.000Z`;
      const period = { planId, billingCycle, status: 'active' as const, currentPeriodStart: start, currentPeriodEnd: end };
      const existing = current(instituteId);
      if (existing) return db.subscriptions.update(instituteId, existing.id, { ...period, cancelAt: null });
      return db.subscriptions.insert(instituteId, {
        ...period,
        trialEndsAt: null,
        cancelAt: null,
        cancelledAt: null,
        provider: 'memory',
        providerSubscriptionId: null,
      });
    },
    cancel: async (instituteId) => {
      const existing = current(instituteId);
      if (!existing) fail('NOT_FOUND', 'There is no subscription to cancel');
      return db.subscriptions.update(instituteId, existing.id, { status: 'cancelled', cancelledAt: nowIso() });
    },
    listUsage: async (instituteId) => db.usage.all(instituteId),
  };
}

export function exportRepo(db: Db): ExportRepo {
  const rowCount: Record<ExportKind, (instituteId: ID) => number> = {
    students: (i) => db.students.all(i).length,
    attendance: (i) => db.attendanceRecords.all(i).length,
    marks: (i) => db.marks.all(i).length,
    results: (i) => db.results.all(i).length,
    fees: (i) => db.installments.all(i).length,
    payments: (i) => db.payments.all(i).length,
    leads: (i) => db.leads.all(i).length,
    audit: (i) => db.auditLogs.all(i).length,
  };
  return {
    list: async (instituteId, query) => db.exportJobs.page(instituteId, query),
    // Nothing is written anywhere: the job completes at once with a placeholder link.
    start: async (instituteId, { kind, format }) => {
      const count = rowCount[kind] ?? fail('VALIDATION', 'Unknown export');
      const job = db.exportJobs.insert(instituteId, {
        kind,
        format,
        status: 'completed',
        rowCount: count(instituteId),
        fileUrl: null,
        error: null,
        requestedBy: db.session.userId,
        completedAt: nowIso(),
      });
      return db.exportJobs.update(instituteId, job.id, { fileUrl: `memory://exports/${job.id}.${format}` });
    },
    get: async (instituteId, jobId) => db.exportJobs.get(instituteId, jobId),
  };
}

/** Records the attachment but keeps no bytes; URLs use a `memory://` scheme that opens nothing. */
export function storagePort(db: Db): StoragePort {
  return {
    upload: async (instituteId, input) => {
      const { ownerType, ownerId, fileName, uri } = input;
      if (!fileName.trim() || !uri) fail('VALIDATION', 'A file is required');
      return db.attachments.insert(instituteId, {
        ownerType,
        ownerId,
        fileName,
        storagePath: `${instituteId}/${ownerType}/${ownerId}/${fileName}`,
        mimeType: input.mimeType ?? null,
        sizeBytes: input.sizeBytes ?? null,
        batchId: input.batchId ?? null,
        studentId: input.studentId ?? null,
        uploadedBy: db.session.userId,
      });
    },
    listAttachments: async (instituteId, ownerType, ownerId) =>
      db.attachments.all(instituteId, { ownerType, ownerId }),
    getUrl: async (instituteId, storagePath) => {
      if (!storagePath.startsWith(`${instituteId}/`)) fail('NOT_FOUND', 'File not found');
      return `memory://${storagePath}`;
    },
    remove: async (instituteId, attachmentId) => db.attachments.remove(instituteId, attachmentId),
  };
}
