import type { Backend } from '../../core/contracts/ports';
import { attendanceRepo, batchRepo, subjectRepo, timetableRepo } from './academics';
import { analyticsRepo, exportRepo, leadRepo, storagePort, subscriptionRepo } from './business';
import { doubtRepo, meetingRepo, noticeRepo, notificationRepo, realtimePort } from './communication';
import { assignmentRepo, examRepo, markRepo, resultRepo, submissionRepo } from './coursework';
import { createDb } from './db';
import { feeRepo, paymentGateway, paymentRepo, receiptRepo } from './finance';
import { materialRepo, practiceRepo } from './learning';
import { guardianRepo, staffRepo, studentRepo } from './people';
import { progressPort } from './progress';
import { SEED, seed } from './seed';
import { authPort, branchRepo, instituteRepo, invitationRepo, membershipRepo } from './tenant';

export { SEED } from './seed';
export { MEMORY_PASSWORD } from './tenant';

/**
 * Reference backend: every port implemented over plain in-process maps.
 * Data lives only as long as the app is open. It exists to prove the
 * contracts are implementable and to give the UI something to run against
 * with no network – it is not a production backend.
 */
export function createMemoryBackend(options: { seeded?: boolean } = {}): Backend {
  const db = createDb();
  if (options.seeded ?? true) seed(db);
  return {
    name: 'memory',
    auth: authPort(db),
    institutes: instituteRepo(db),
    branches: branchRepo(db),
    memberships: membershipRepo(db),
    invitations: invitationRepo(db),
    staff: staffRepo(db),
    students: studentRepo(db),
    guardians: guardianRepo(db),
    batches: batchRepo(db),
    subjects: subjectRepo(db),
    timetable: timetableRepo(db),
    attendance: attendanceRepo(db),
    assignments: assignmentRepo(db),
    submissions: submissionRepo(db),
    exams: examRepo(db),
    marks: markRepo(db),
    results: resultRepo(db),
    materials: materialRepo(db),
    practice: practiceRepo(db),
    fees: feeRepo(db),
    payments: paymentRepo(db),
    receipts: receiptRepo(db),
    notices: noticeRepo(db),
    notifications: notificationRepo(db),
    doubts: doubtRepo(db),
    meetings: meetingRepo(db),
    leads: leadRepo(db),
    analytics: analyticsRepo(db),
    subscriptions: subscriptionRepo(db),
    exports: exportRepo(db),
    storage: storagePort(db),
    paymentGateway: paymentGateway(db),
    realtime: realtimePort(db),
    progress: progressPort(db),
  };
}

/** The institute the seeded memory backend opens on. */
export const MEMORY_DEFAULT_INSTITUTE_ID = SEED.instituteId;
