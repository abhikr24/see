import type { Guardian, StaffRecord, Student, Teacher, Workload } from '../../core/contracts/models';
import type { GuardianRepo, StaffRepo, StudentRepo } from '../../core/contracts/ports';
import { crud, myStudentIds, upsert, type Db } from './db';
import * as D from './defaults';
import { fail } from './store';

export function staffRepo(db: Db): StaffRepo {
  return {
    ...crud<StaffRecord>(db.staff, D.staff),
    listTeachers: async (instituteId, query) => db.teachers.page(instituteId, query),
    saveTeacher: upsert<Teacher, 'fullName'>(db.teachers, D.teacher),
    listWorkloads: async (instituteId, filter = {}) => db.workloads.all(instituteId, filter),
    saveWorkload: upsert<Workload, 'teacherId' | 'weekStart'>(db.workloads, D.workload),
  };
}

export function studentRepo(db: Db): StudentRepo {
  const base = crud<Student, 'fullName'>(db.students, D.student);
  return {
    ...base,
    create: async (instituteId, input) => {
      if (!input.fullName.trim()) fail('VALIDATION', 'Student name is required');
      if (input.admissionNo && db.students.find(instituteId, { admissionNo: input.admissionNo })) {
        fail('CONFLICT', 'That admission number is already in use');
      }
      return base.create(instituteId, input);
    },
    listByBatch: async (instituteId, batchId) => {
      db.batches.get(instituteId, batchId);
      return db.enrollments
        .all(instituteId, { batchId, status: 'active' })
        .sort((a, b) => (a.rollNumber ?? Infinity) - (b.rollNumber ?? Infinity))
        .map((enrollment) => db.students.get(instituteId, enrollment.studentId));
    },
    listMine: async (instituteId) => myStudentIds(db, instituteId).map((id) => db.students.get(instituteId, id)),
    getLogin: async (instituteId, studentId) => db.studentMemberships.find(instituteId, { studentId }) ?? null,
    linkLogin: async (instituteId, studentId, membershipId) => {
      db.students.get(instituteId, studentId);
      const membership = db.memberships.get(instituteId, membershipId);
      if (membership.role !== 'student') fail('VALIDATION', 'Only a student login can be linked to a student record');
      const taken =
        db.studentMemberships.find(instituteId, { studentId }) ??
        db.studentMemberships.find(instituteId, { membershipId });
      if (taken) fail('CONFLICT', 'That student or login is already linked');
      return db.studentMemberships.insert(instituteId, { studentId, membershipId, linkedBy: db.session.userId });
    },
    unlinkLogin: async (instituteId, studentId) => {
      const link = db.studentMemberships.find(instituteId, { studentId });
      if (!link) fail('NOT_FOUND', 'This student has no linked login');
      db.studentMemberships.remove(instituteId, link.id);
    },
  };
}

export function guardianRepo(db: Db): GuardianRepo {
  return {
    ...crud<Guardian, 'fullName'>(db.guardians, D.guardian),
    listForStudent: async (instituteId, studentId) =>
      db.parentLinks
        .all(instituteId, { studentId })
        .sort((a, b) => Number(b.isPrimary) - Number(a.isPrimary))
        .map((link) => db.guardians.get(instituteId, link.guardianId)),
    listLinks: async (instituteId, filter = {}) => db.parentLinks.all(instituteId, filter),
    link: async (instituteId, { studentId, guardianId, isPrimary = false }) => {
      db.students.get(instituteId, studentId);
      db.guardians.get(instituteId, guardianId);
      if (db.parentLinks.find(instituteId, { studentId, guardianId })) fail('CONFLICT', 'Already linked');
      return db.parentLinks.insert(instituteId, { studentId, guardianId, isPrimary });
    },
    unlink: async (instituteId, linkId) => db.parentLinks.remove(instituteId, linkId),
  };
}
