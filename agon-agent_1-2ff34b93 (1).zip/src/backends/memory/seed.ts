import type { AttendanceStatus, ID } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { addDays, nowIso, todayIso } from './store';

/** Same id scheme as supabase/seed.sql: the last two digits identify the record. */
const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
/** Deterministic ids for one-per-student/day/term rows, kept clear of the core ids above. */
const xid = (base: number, i: number): ID => sid(base + i);

const ROLLS = [14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25];

export const SEED = {
  instituteId: sid(1),
  ownerId: sid(2),
  teacherId: sid(3),
  branchId: sid(8),
  batchId: sid(9),
  studentIds: ROLLS.map(sid),
  ownerEmail: 'owner@sunrise.test',
};

/** Class 10-A, rolls 14–25 (AGENTS.md). Aarav Sharma is first. */
const CLASS_10A: [number, string][] = [
  [14, 'Aarav Sharma'], [15, 'Ishita Bose'], [16, 'Kabir Singh'], [17, 'Ananya Gupta'],
  [18, 'Ritesh Mehta'], [19, 'Zoya Ahmed'], [20, 'Kabeer Singh'], [21, 'Diya Patel'],
  [22, 'Manav Sethi'], [23, 'Priya Menon'], [24, 'Rohan Das'], [25, 'Sara Khan'],
];
const CLASS_9A = ['Arnav Mehta', 'Kavya Reddy', 'Vivaan Joshi', 'Anika Bose', 'Reyansh Gupta', 'Ira Kapoor', 'Atharv Singh', 'Zara Khan', 'Neil Verma', 'Tara Iyer'];
const CLASS_11A = ['Aryan Kapoor', 'Sanya Rao', 'Varun Mehta', 'Rhea Singh', 'Aditi Verma', 'Nikhil Bose', 'Sana Khan', 'Ishaan Rao'];
/** Five teachers and their subjects (subject ids 44–48), in AGENTS.md order. */
const TEACHERS: [number, string, string][] = [
  [3, 'Rohit Verma', 'Mathematics'], [4, 'Priya Nair', 'Physics'], [5, 'Meera Iyer', 'Chemistry'],
  [6, 'Sneha Iyer', 'English'], [7, 'Arun Kumar', 'Biology'],
];
const PENDING: [number, string, 'student' | 'parent' | 'teacher'][] = [
  [38, 'Kunal Sinha', 'student'], [39, 'Riya Chaudhary', 'student'], [40, 'Harsh Tiwari', 'student'],
  [41, 'Anita Tiwari', 'parent'], [42, 'Sanjay Chaudhary', 'parent'], [43, 'Nikhil Anand', 'teacher'],
];
/** Unit Test 3 · Mathematics, max 100, in roll order. Sums to 936, so the average is exactly 78%. */
const UNIT_TEST_3 = [92, 85, 78, 88, 74, 81, 69, 93, 77, 84, 61, 54];

const slug = (name: string): string => name.toLowerCase().replace(/[^a-z]+/g, '.').replace(/^\.|\.$/g, '');

/**
 * Sunrise Coaching Classes, Patna — a full demo slice, sized so every screen
 * from P9 onward has something real to show:
 *   12 students in Class 10-A (plus 10 in 9-A, 8 in 11-A), 5 teachers,
 *   30 attendance days at 92%, 3 payments today (₹12,400), 18 students with
 *   ₹34,500 overdue, 6 pending join requests, Unit Test 3 averaging 78%.
 */
export function seed(db: Db): void {
  const at = nowIso();
  const today = todayIso();
  const inst = SEED.instituteId;
  const row = (n: number) => ({ id: sid(n), instituteId: inst, createdAt: at, updatedAt: at });

  db.institutes.put({
    ...D.institute(), id: inst, name: 'Sunrise Coaching Classes', code: 'SUNRISE-PAT',
    ownerId: SEED.ownerId, city: 'Patna', state: 'Bihar',
    settings: { ...D.settings(), academicYear: '2026-27', receiptPrefix: 'SCC' },
    createdAt: at, updatedAt: at,
  });
  db.branches.put({ ...D.branch(), ...row(8), name: 'Boring Road (Main)', code: 'BR', city: 'Patna', isMain: true });

  // People who can sign in: owner, 5 teachers, 12 students, 1 demo parent.
  const people: [number, string, string, 'owner' | 'teacher' | 'student' | 'parent'][] = [
    [2, 'Rahul Sharma', SEED.ownerEmail, 'owner'],
    ...TEACHERS.map(([n, name]): [number, string, string, 'teacher'] => [n, name, `${slug(name)}@sunrise.test`, 'teacher']),
    ...CLASS_10A.map(([n, name]): [number, string, string, 'student'] => [
      n, name, n === 14 ? 'aarav@sunrise.test' : `${slug(name)}@sunrise.test`, 'student',
    ]),
    [37, 'Anita Sharma', 'parent@sunrise.test', 'parent'],
  ];
  for (const [n, fullName, email, role] of people) {
    db.profiles.set(sid(n), { ...D.profile(), id: sid(100 + n), userId: sid(n), fullName, email, createdAt: at, updatedAt: at });
    db.memberships.put({
      ...row(200 + n), userId: sid(n), branchId: SEED.branchId, role, status: 'active',
      permissions: [], requestNote: null, requestedAt: at, decidedBy: SEED.ownerId, decidedAt: at,
    });
  }
  // Six join requests waiting for the owner (dashboard: pending approvals).
  for (const [n, fullName, role] of PENDING) {
    db.profiles.set(sid(n), { ...D.profile(), id: sid(100 + n), userId: sid(n), fullName, email: `${slug(fullName)}@sunrise.test`, createdAt: at, updatedAt: at });
    db.memberships.put({
      ...row(200 + n), userId: sid(n), branchId: SEED.branchId, role, status: 'pending',
      permissions: [], requestNote: 'I want to join Sunrise Coaching Classes.', requestedAt: at, decidedBy: null, decidedAt: null,
    });
  }

  TEACHERS.forEach(([n, fullName, specialization], i) => {
    db.teachers.put({ ...D.teacher(), ...row(n), userId: sid(n), fullName, specialization });
    db.staff.put({ ...D.staff(), ...row(300 + n), userId: sid(n), teacherId: sid(n), employeeCode: `SCC-T0${i + 1}`, designation: i === 0 ? 'Class teacher' : 'Subject teacher' });
  });
  TEACHERS.forEach(([, , subject], i) => {
    db.subjects.put({ ...D.subject(), ...row(44 + i), name: subject, code: subject.slice(0, 4).toUpperCase() });
  });

  // Three batches. Every student below is enrolled in exactly one of them.
  const batches = [
    { id: sid(9), name: 'Class 10-A', grade: '10', students: CLASS_10A.map(([roll, name]) => ({ id: sid(roll), name, roll })) },
    { id: sid(10), name: 'Class 9-A', grade: '9', students: CLASS_9A.map((name, i) => ({ id: sid(26 + i), name, roll: i + 1 })) },
    { id: sid(11), name: 'Class 11-A', grade: '11', students: CLASS_11A.map((name, i) => ({ id: sid(80 + i), name, roll: i + 1 })) },
  ];
  batches.forEach((batch, bi) => {
    db.batches.put({ ...D.batch(), id: batch.id, instituteId: inst, createdAt: at, updatedAt: at, branchId: SEED.branchId, name: batch.name, grade: batch.grade, section: 'A', academicYear: '2026-27' });
    batch.students.forEach((student, si) => {
      db.students.put({
        ...D.student(), id: student.id, instituteId: inst, createdAt: at, updatedAt: at,
        fullName: student.name, admissionNo: `SCC-${student.id.slice(-4)}`, classGrade: batch.grade, branchId: SEED.branchId,
      });
      db.enrollments.put({
        id: xid(1000, bi * 100 + si), instituteId: inst, createdAt: at, updatedAt: at,
        batchId: batch.id, studentId: student.id, rollNumber: student.roll, joinedOn: addDays(today, -90), leftOn: null, status: 'active',
      });
    });
  });
  db.studentMemberships.put({ ...row(500), studentId: sid(14), membershipId: sid(214), linkedBy: SEED.ownerId });
  const allStudents = batches.flatMap((batch) => batch.students);

  // Timetable: Mon–Fri for every batch, plus a second period on today's
  // weekday — so "Today's batches" always shows all three batches, any day.
  const todayDow = new Date(`${today}T00:00:00Z`).getUTCDay();
  const days = [...new Set([todayDow, 1, 2, 3, 4, 5])];
  batches.forEach((batch, bi) => {
    days.forEach((dayOfWeek, di) => {
      const teacher = TEACHERS[(bi + di) % TEACHERS.length];
      db.timetables.put({
        ...D.timetable(), id: xid(10000, bi * 100 + di), instituteId: inst, createdAt: at, updatedAt: at,
        batchId: batch.id, subjectId: sid(44 + ((bi + di) % 5)), teacherId: sid(teacher[0]),
        dayOfWeek, startsAt: `${16 + bi}:00`, endsAt: `${17 + bi}:00`,
      });
    });
    const teacher = TEACHERS[(bi + 2) % TEACHERS.length];
    db.timetables.put({
      ...D.timetable(), id: xid(10000, bi * 100 + 50), instituteId: inst, createdAt: at, updatedAt: at,
      batchId: batch.id, subjectId: sid(44 + ((bi + 2) % 5)), teacherId: sid(teacher[0]),
      dayOfWeek: todayDow, startsAt: `${17 + bi}:15`, endsAt: `${18 + bi}:15`,
    });
  });

  // 30 days of attendance for Class 10-A, ending today: 12 × 30 = 360 records.
  // One student is absent each day except the first (29 missed), so 331 of
  // 360 attended = 91.9% → 92%, and today reads 11 of 12 → 92%. Each student
  // misses only 2–3 days, so nobody trips the low-attendance alert.
  for (let day = 0; day < 30; day += 1) {
    const sessionId = xid(2000, day);
    db.attendanceSessions.put({
      id: sessionId, instituteId: inst, createdAt: at, updatedAt: at, batchId: SEED.batchId,
      subjectId: null, teacherId: sid(3), date: addDays(today, day - 29), period: 1,
      status: 'submitted', markedBy: sid(3), markedAt: at, notes: null,
    });
    CLASS_10A.forEach(([,], si) => {
      const status: AttendanceStatus =
        day > 0 && si === day % CLASS_10A.length ? 'absent' : (day + si) % 17 === 0 ? 'late' : 'present';
      db.attendanceRecords.put({
        id: xid(3000, day * 20 + si), instituteId: inst, createdAt: at, updatedAt: at,
        sessionId, batchId: SEED.batchId, studentId: sid(ROLLS[si]), status, remark: null, markedBy: sid(3),
      });
    });
  }

  // Fees. Every student owes a ₹2,000 Term 2 instalment (due 10 days ago) and
  // a ₹5,000 Term 3 instalment (due in 30 days). 18 students still owe Term 2:
  // 12 owe the full ₹2,000 and 6 owe ₹1,750 → ₹24,000 + ₹10,500 = ₹34,500
  // overdue across 18 students. The other 12 have paid Term 2 in full.
  db.feeStructures.put({
    ...D.feeStructure(), ...row(51), batchId: null, name: 'Sunrise annual fee', academicYear: '2026-27', totalAmount: 7000,
  });
  const overdueIds = new Set([
    ...ROLLS.slice(6).map(sid),
    ...CLASS_9A.slice(0, 7).map((_, i) => sid(26 + i)),
    ...CLASS_11A.slice(0, 5).map((_, i) => sid(80 + i)),
  ]);
  // Three payments made today, ₹5,000 + ₹4,200 + ₹3,200 = ₹12,400, from the
  // first three Class 10-A students towards their (not yet due) Term 3 fee.
  const paidToday = new Map([[sid(14), 5000], [sid(15), 4200], [sid(16), 3200]]);
  allStudents.forEach((student, si) => {
    const overdueRank = [...overdueIds].indexOf(student.id);
    const term2Due = overdueRank >= 0 ? (overdueRank < 12 ? 2000 : 1750) : 0;
    const term3Paid = paidToday.get(student.id) ?? 0;
    db.studentFees.put({
      id: xid(5000, si), instituteId: inst, createdAt: at, updatedAt: at, studentId: student.id,
      feeStructureId: sid(51), academicYear: '2026-27', grossAmount: 7000, discountAmount: 0,
      discountReason: null, netAmount: 7000, status: 'active',
    });
    db.installments.put({
      id: xid(6000, si * 2), instituteId: inst, createdAt: at, updatedAt: at, studentFeeId: xid(5000, si),
      studentId: student.id, termNo: 2, label: 'Term 2 fee', amount: 2000, dueDate: addDays(today, -10),
      paidAmount: 2000 - term2Due, paidOn: term2Due === 0 ? addDays(today, -12) : null,
      status: term2Due === 0 ? 'paid' : 'overdue',
    });
    db.installments.put({
      id: xid(6000, si * 2 + 1), instituteId: inst, createdAt: at, updatedAt: at, studentFeeId: xid(5000, si),
      studentId: student.id, termNo: 3, label: 'Term 3 fee', amount: 5000, dueDate: addDays(today, 30),
      paidAmount: term3Paid, paidOn: term3Paid > 0 ? today : null, status: term3Paid >= 5000 ? 'paid' : term3Paid > 0 ? 'partial' : 'upcoming',
    });
    if (term3Paid > 0) {
      db.payments.put({
        id: xid(7000, si), instituteId: inst, createdAt: at, updatedAt: at, studentId: student.id,
        studentFeeId: xid(5000, si), installmentId: xid(6000, si * 2 + 1), amount: term3Paid,
        method: 'upi', referenceNo: `UPI-${si}`, receivedBy: SEED.ownerId, notes: null,
        paidAt: `${today}T09:30:00.000Z`, status: 'completed',
      });
    }
  });

  // Unit Test 3 (Mathematics, max 100) for Class 10-A, with results, so the
  // exam average is 936 / 12 = 78% whichever port a screen reads it through.
  db.exams.put({
    ...D.exam(), ...row(50), batchId: SEED.batchId, name: 'Unit Test 3', examType: 'unit_test',
    startsOn: addDays(today, -12), endsOn: addDays(today, -10), totalMarks: 100, passPercent: 33,
    status: 'published', publishedAt: at, createdBy: sid(3),
  });
  const ranked = [...UNIT_TEST_3].sort((a, b) => b - a);
  CLASS_10A.forEach(([roll], si) => {
    const marks = UNIT_TEST_3[si];
    db.marks.put({
      id: xid(8000, si), instituteId: inst, createdAt: at, updatedAt: at, examId: sid(50),
      batchId: SEED.batchId, studentId: sid(roll), subjectId: sid(44), marksObtained: marks,
      maxMarks: 100, isAbsent: false, grade: marks >= 90 ? 'A+' : marks >= 80 ? 'A' : marks >= 70 ? 'B' : marks >= 60 ? 'C' : 'D',
      remark: null, enteredBy: sid(3),
    });
    db.results.put({
      id: xid(9000, si), instituteId: inst, createdAt: at, updatedAt: at, examId: sid(50),
      batchId: SEED.batchId, studentId: sid(roll), totalObtained: marks, totalMax: 100, percentage: marks,
      grade: marks >= 90 ? 'A+' : marks >= 80 ? 'A' : marks >= 70 ? 'B' : 'D', rank: ranked.indexOf(marks) + 1,
      status: 'pass', remarks: null,
    });
  });

  db.notices.put({ ...D.notice(), ...row(61), title: 'Unit Test 3 schedule', body: 'Unit Test 3 begins next Monday.', category: 'exam', publishedAt: at, createdBy: SEED.ownerId });
  db.leads.put({ ...D.lead(), ...row(71), studentName: 'Kunal Raj', phone: '9000000071', classInterested: '10' });

  const plan = { currency: 'INR', maxBranches: 1, storageMb: 1024, features: {}, isActive: true };
  db.plans.put({ ...row(90), ...plan, code: 'starter', name: 'Starter', priceMonthly: 999, priceYearly: 9990, maxStudents: 100, maxTeachers: 10 });
  db.plans.put({ ...row(91), ...plan, code: 'growth', name: 'Growth', priceMonthly: 2499, priceYearly: 24990, maxStudents: 500, maxTeachers: 50 });
  db.subscriptions.put({
    ...row(92), planId: sid(90), status: 'trialing', billingCycle: 'monthly', currentPeriodStart: at,
    currentPeriodEnd: null, trialEndsAt: `${addDays(today, 14)}T00:00:00.000Z`, cancelAt: null,
    cancelledAt: null, provider: 'memory', providerSubscriptionId: null,
  });

  // Start signed out. A session is created only by sign-in / OTP verify, so
  // the shell has to resolve membership from a fresh cache instead of a
  // launch-time owner session.
}
