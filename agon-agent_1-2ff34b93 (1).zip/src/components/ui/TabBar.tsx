import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, SHADOW } from '@/lib/theme';
import { Text } from './Text';
import type { TabDef } from '@/lib/nav';

export interface TabBarProps {
  tabs: readonly TabDef[];
  selectedKey?: string;
  onSelect?: (key: string) => void;
  className?: string;
}

export function TabBar({ tabs, selectedKey = 'home', onSelect, className }: TabBarProps) {
  return (
    <View
      className={className}
      style={{
        flexDirection: 'row',
        backgroundColor: C.surface,
        borderRadius: 28,
        borderWidth: 1,
        borderColor: C.hairline,
        paddingVertical: 8,
        paddingHorizontal: 8,
        marginHorizontal: 4,
        ...SHADOW,
      }}
    >
      {tabs.map((t) => {
        const active = selectedKey === t.key;
        return (
          <Pressable
            key={t.key}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            onPress={() => onSelect?.(t.key)}
            style={{ flex: 1, alignItems: 'center', gap: 3, paddingVertical: 4 }}
          >
            <View
              style={{
                width: 46,
                height: 28,
                borderRadius: 14,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: active ? C.navySoft : C.transparent,
              }}
            >
              <Ionicons
                name={(active ? t.iconActive : t.icon) as keyof typeof Ionicons.glyphMap}
                size={20}
                color={active ? C.primary : C.muted}
              />
              {t.badge ? (
                <View
                  style={{
                    position: 'absolute',
                    right: t.badge > 9 ? -6 : -2,
                    top: -4,
                    minWidth: 16,
                    height: 16,
                    paddingHorizontal: 3,
                    borderRadius: 8,
                    backgroundColor: C.danger,
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderWidth: 1.5,
                    borderColor: C.surface,
                  }}
                >
                  <Text variant="label" weight={700} c={C.surface} tabular style={{ fontSize: 9, lineHeight: 11 }}>
                    {t.badge > 99 ? '99+' : t.badge}
                  </Text>
                </View>
              ) : null}
            </View>
            <Text
              variant="label"
              weight={600}
              c={active ? C.primary : C.muted}
              style={{ fontSize: 9.5 }}
            >
              {t.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
