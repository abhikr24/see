/**
 * The UI's only door to data.
 *
 *   <BackendProvider backends={[...]} instituteId="…">   ← App.tsx, once
 *   const { data, loading, error, refetch, create } = useStudents();   ← any screen
 *
 * Every hook returns `{ data, loading, error, refetch }` plus that domain's
 * actions. Actions never throw: optimistic update, rollback on failure and the
 * success / error toast are handled in one place (hooks/mutation.ts).
 *
 * Screens import from this file only – never from src/backends or an SDK.
 */

import { useMemo, useState, type ReactNode } from 'react';

import type { ID } from './contracts/models';
import type { Backend } from './contracts/ports';
import { BackendContext, type BackendContextValue } from './hooks/context';
import { ToastHost } from './hooks/ToastHost';

export interface BackendProviderProps {
  /** Every backend the app can run on. The first is used unless `initial` names another. */
  backends: Backend[];
  initial?: string;
  /** Institute to open on. null shows the app with no institute selected. */
  instituteId?: ID | null;
  children: ReactNode;
}

export function BackendProvider({ backends, initial, instituteId = null, children }: BackendProviderProps) {
  if (backends.length === 0) throw new Error('BackendProvider needs at least one backend');
  const [name, selectBackend] = useState(initial ?? backends[0].name);
  const [currentInstitute, setInstituteId] = useState<ID | null>(instituteId);

  const value = useMemo<BackendContextValue>(
    () => ({
      backend: backends.find((b) => b.name === name) ?? backends[0],
      backends,
      selectBackend,
      instituteId: currentInstitute,
      setInstituteId,
    }),
    [backends, name, currentInstitute],
  );

  return (
    <BackendContext.Provider value={value}>
      {children}
      <ToastHost />
    </BackendContext.Provider>
  );
}

export { useBackend } from './hooks/context';
export { toast } from './hooks/toast';
export { isOptimistic } from './hooks/domain';
export type { QueryResult } from './hooks/useQuery';
export type { MutationResult } from './hooks/mutation';

// One hook per port, grouped by feature. The port each hook fronts is named in its doc comment.
export * from './hooks/tenant'; // useSession, useInstitute, useMyInstitutes, useBranches, useMemberships, useInvitations
export * from './hooks/people'; // useStaff, useTeachers, useStudents, useBatchStudents, useMyStudents, useGuardians
export * from './hooks/academics'; // useBatches, useMyBatches, useSubjects, useTimetable, useAttendance*
export * from './hooks/coursework'; // useAssignments, useSubmissions, useFeedback, useExams, useMarks, useResults
export * from './hooks/learning'; // useMaterials, usePractice, useQuizzes, useStudent360, useRiskAlerts
export * from './hooks/finance'; // useFees, useFeeStructures, useFeeSummary, usePayments, useReceipts, useCheckout
export * from './hooks/communication'; // useNotices, useNotifications, useDoubts, useMeetings, useConversations, useRealtime
export * from './hooks/business'; // useLeads, useAnalytics, useTrends, useAuditLog, useSubscription, useExports, useAttachments
