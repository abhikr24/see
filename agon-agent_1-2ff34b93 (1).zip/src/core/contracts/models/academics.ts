import type { ActiveStatus, ID, ISODate, ISODateTime, TenantEntity, TimeOfDay } from './common';

/** A class group, e.g. "Class 10-A". */
export interface Batch extends TenantEntity {
  branchId: ID | null;
  classroomId: ID | null;
  name: string;
  grade: string | null;
  section: string | null;
  academicYear: string;
  capacity: number | null;
  startsOn: ISODate | null;
  endsOn: ISODate | null;
  status: 'upcoming' | 'active' | 'completed' | 'archived';
}

/** A student's place in a batch. */
export interface Enrollment extends TenantEntity {
  batchId: ID;
  studentId: ID;
  rollNumber: number | null;
  joinedOn: ISODate;
  leftOn: ISODate | null;
  status: 'active' | 'left' | 'transferred';
}

export interface Subject extends TenantEntity {
  name: string;
  code: string;
  color: string | null;
  description: string | null;
  isActive: boolean;
}

/** One weekly period for a batch. A batch's timetable is the list of these. */
export interface Timetable extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  classroomId: ID | null;
  /** 0 = Sunday … 6 = Saturday. */
  dayOfWeek: number;
  startsAt: TimeOfDay;
  endsAt: TimeOfDay;
  validFrom: ISODate | null;
  validTo: ISODate | null;
}

export interface Classroom extends TenantEntity {
  branchId: ID | null;
  name: string;
  capacity: number | null;
  floor: string | null;
  facilities: string[];
  status: ActiveStatus;
}

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'leave';

/** One roll call: a batch, a date and a period. */
export interface AttendanceSession extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  date: ISODate;
  period: number;
  status: 'open' | 'submitted' | 'locked';
  markedBy: ID | null;
  markedAt: ISODateTime | null;
  notes: string | null;
}

/** One student in one roll call. */
export interface AttendanceRecord extends TenantEntity {
  sessionId: ID;
  batchId: ID;
  studentId: ID;
  status: AttendanceStatus;
  remark: string | null;
  markedBy: ID | null;
}

export interface AttendanceSheet {
  session: AttendanceSession;
  records: AttendanceRecord[];
}

export interface AttendanceSummary {
  total: number;
  present: number;
  absent: number;
  late: number;
  leave: number;
  /** (present + late) / total × 100, one decimal. 0 when there are no records. */
  percent: number;
}
