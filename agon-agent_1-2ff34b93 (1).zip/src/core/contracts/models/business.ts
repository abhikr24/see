import type { ID, ISODate, ISODateTime, JsonObject, Money, Role, TenantEntity, TimeOfDay } from './common';

export type LeadStage =
  | 'new'
  | 'contacted'
  | 'interested'
  | 'demo_scheduled'
  | 'demo_attended'
  | 'negotiation'
  | 'enrolled'
  | 'lost';

/** An admission enquiry moving through the pipeline. */
export interface AdmissionLead extends TenantEntity {
  branchId: ID | null;
  studentName: string;
  guardianName: string | null;
  phone: string | null;
  email: string | null;
  classInterested: string | null;
  schoolName: string | null;
  source: 'walk_in' | 'referral' | 'website' | 'social' | 'phone' | 'campaign' | 'other';
  stage: LeadStage;
  assignedTo: ID | null;
  expectedFee: Money | null;
  nextFollowupAt: ISODateTime | null;
  lostReason: string | null;
  convertedStudentId: ID | null;
  notes: string | null;
}

export interface LeadFollowup extends TenantEntity {
  leadId: ID;
  channel: 'call' | 'whatsapp' | 'sms' | 'email' | 'visit';
  summary: string | null;
  outcome: 'no_answer' | 'interested' | 'callback' | 'demo_booked' | 'not_interested' | 'enrolled' | null;
  followupAt: ISODateTime;
  nextFollowupAt: ISODateTime | null;
  doneBy: ID | null;
}

/** A SaaS plan as offered to this institute. */
export interface Plan extends TenantEntity {
  code: string;
  name: string;
  priceMonthly: Money;
  priceYearly: Money;
  currency: string;
  maxStudents: number | null;
  maxTeachers: number | null;
  maxBranches: number | null;
  storageMb: number | null;
  features: Record<string, boolean>;
  isActive: boolean;
}

export type BillingCycle = 'monthly' | 'yearly';

export interface Subscription extends TenantEntity {
  planId: ID;
  status: 'trialing' | 'active' | 'past_due' | 'cancelled' | 'expired';
  billingCycle: BillingCycle;
  currentPeriodStart: ISODateTime;
  currentPeriodEnd: ISODateTime | null;
  trialEndsAt: ISODateTime | null;
  cancelAt: ISODateTime | null;
  cancelledAt: ISODateTime | null;
  provider: string | null;
  providerSubscriptionId: string | null;
}

export type UsageMetric = 'students' | 'teachers' | 'branches' | 'storage_mb' | 'sms' | 'notifications';

export interface UsageRecord extends TenantEntity {
  subscriptionId: ID | null;
  metric: UsageMetric;
  quantity: number;
  periodStart: ISODate;
  periodEnd: ISODate;
}

/** Append-only record of who did what. */
export interface AuditLog extends TenantEntity {
  actorId: ID | null;
  actorRole: Role | null;
  action: string;
  targetType: string | null;
  targetId: ID | null;
  before: JsonObject | null;
  after: JsonObject | null;
  ipAddress: string | null;
  userAgent: string | null;
}

/** Headline numbers for the owner dashboard. */
export interface InstituteOverview {
  activeStudents: number;
  activeTeachers: number;
  activeBatches: number;
  pendingMembers: number;
  /** Across all batches, last 30 days. null when nothing was marked. */
  attendancePercent: number | null;
  feesCollected: Money;
  feesOutstanding: Money;
  openLeads: number;
  openAlerts: number;
}

/** A teacher as shown on a dashboard row: enough for an avatar. */
export interface DashboardTeacher {
  id: ID;
  fullName: string;
  photoUrl: string | null;
}

/** One batch that meets today. */
export interface DashboardBatch {
  batchId: ID;
  name: string;
  /** Start of its first period today. */
  startsAt: TimeOfDay;
  /** End of its last period today. */
  endsAt: TimeOfDay;
  /** Everyone teaching it today, in period order. */
  teachers: DashboardTeacher[];
  /** Students currently enrolled. */
  studentCount: number;
}

/**
 * Everything the owner's home screen shows, computed by the backend in one call.
 * Each figure uses the same rule as the port that owns it, so it reconciles with
 * that port's own screen: `collectedToday` with PaymentRepo / feeCollection,
 * `attendancePercent` with AttendanceRepo.summary for `date`, `pendingApprovals`
 * with MembershipRepo, `overdue*` with FeeRepo.summary, alerts with ProgressPort.
 */
export interface OwnerDashboard {
  /** The day every "today" figure is for. */
  date: ISODate;
  /** Active and upcoming batches. 0 = the institute has not been set up yet. */
  batchCount: number;
  /** Completed payments received on `date`. */
  collectedToday: Money;
  /** (present + late) / marked on `date`, all batches. null until a roll call is marked. */
  attendancePercent: number | null;
  pendingApprovals: number;
  overdueAmount: Money;
  /** Distinct students with at least one overdue installment. */
  overdueStudents: number;
  /** Open low-attendance alerts raised in the 7 days ending on `date`. */
  lowAttendanceAlerts: number;
  /** Ordered by first period. Empty when nothing is on the timetable today. */
  batchesToday: DashboardBatch[];
  /** The batch in session now, else the next one today. null when nothing is scheduled. */
  currentBatchId: ID | null;
}

export interface TrendPoint {
  date: ISODate;
  value: number;
}

export interface FunnelStage {
  stage: LeadStage;
  count: number;
}

export type ExportKind = 'students' | 'attendance' | 'marks' | 'results' | 'fees' | 'payments' | 'leads' | 'audit';
export type ExportFormat = 'csv' | 'xlsx' | 'pdf';

export interface ExportJob extends TenantEntity {
  kind: ExportKind;
  format: ExportFormat;
  status: 'queued' | 'running' | 'completed' | 'failed';
  rowCount: number | null;
  /** Download link once completed. May expire. */
  fileUrl: string | null;
  error: string | null;
  requestedBy: ID | null;
  completedAt: ISODateTime | null;
}
