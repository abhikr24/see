import type { ID, ISODate, ISODateTime, Money, TenantEntity } from './common';

export interface FeeComponent {
  label: string;
  amount: Money;
}

/** A fee plan for a batch and academic year. */
export interface FeeStructure extends TenantEntity {
  batchId: ID | null;
  name: string;
  academicYear: string;
  totalAmount: Money;
  installmentCount: number;
  frequency: 'one_time' | 'monthly' | 'quarterly' | 'term' | 'yearly';
  components: FeeComponent[];
  lateFeePerDay: Money;
  isActive: boolean;
}

/** What one student owes under one fee structure. */
export interface StudentFee extends TenantEntity {
  studentId: ID;
  feeStructureId: ID;
  academicYear: string;
  grossAmount: Money;
  discountAmount: Money;
  discountReason: string | null;
  /** grossAmount − discountAmount. Computed by the backend. */
  netAmount: Money;
  status: 'active' | 'settled' | 'cancelled';
}

export type InstallmentStatus = 'upcoming' | 'due' | 'partial' | 'paid' | 'overdue' | 'waived';

export interface Installment extends TenantEntity {
  studentFeeId: ID;
  studentId: ID;
  termNo: number;
  label: string;
  amount: Money;
  dueDate: ISODate;
  paidAmount: Money;
  paidOn: ISODate | null;
  status: InstallmentStatus;
}

export type PaymentMethod = 'cash' | 'upi' | 'card' | 'bank_transfer' | 'cheque' | 'online';

/** Money received. */
export interface Payment extends TenantEntity {
  studentId: ID;
  studentFeeId: ID;
  installmentId: ID | null;
  amount: Money;
  method: PaymentMethod;
  referenceNo: string | null;
  paidAt: ISODateTime;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  receivedBy: ID | null;
  notes: string | null;
}

/** One per payment, numbered per institute. */
export interface Receipt extends TenantEntity {
  paymentId: ID;
  studentId: ID;
  receiptNo: string;
  amount: Money;
  issuedAt: ISODateTime;
  issuedBy: ID | null;
  /** Storage path of the rendered PDF; resolve with StoragePort.getUrl. */
  pdfPath: string | null;
}

export interface Refund extends TenantEntity {
  paymentId: ID;
  studentId: ID;
  amount: Money;
  reason: string | null;
  method: PaymentMethod | null;
  referenceNo: string | null;
  status: 'requested' | 'approved' | 'processed' | 'rejected';
  requestedBy: ID | null;
  approvedBy: ID | null;
  processedAt: ISODateTime | null;
}

/** Institute-wide fee position. */
export interface FeeSummary {
  billed: Money;
  collected: Money;
  outstanding: Money;
  overdue: Money;
  overdueInstallments: number;
}

/** An online checkout opened with the payment gateway. */
export interface PaymentOrder extends TenantEntity {
  studentId: ID;
  installmentId: ID;
  amount: Money;
  currency: string;
  provider: string;
  providerOrderId: string;
  /** Hosted checkout page, when the provider has one. */
  checkoutUrl: string | null;
  status: 'created' | 'paid' | 'failed' | 'expired';
  /** Set once the order is confirmed and a Payment exists. */
  paymentId: ID | null;
}
