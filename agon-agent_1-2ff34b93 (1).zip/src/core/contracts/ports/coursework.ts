import type { Assignment, Exam, ExamQuestion, Feedback, ID, Mark, Result, Submission, Upsert } from '../models';
import type { CrudRepo, ReadRepo } from './common';

export interface AssignmentRepo extends CrudRepo<Assignment, 'batchId' | 'title'> {
  publish(instituteId: ID, id: ID): Promise<Assignment>;
  close(instituteId: ID, id: ID): Promise<Assignment>;
}

export interface GradeInput {
  marksAwarded?: number | null;
  grade?: string | null;
  comment?: string | null;
}

export interface SubmissionRepo extends ReadRepo<Submission> {
  /** Hands in (or re-hands in) a student's answer. Late is decided by the backend. */
  submit(
    instituteId: ID,
    input: { assignmentId: ID; studentId: ID; content?: string | null },
  ): Promise<Submission>;
  /** Records the teacher's marks and comment and returns the submission to the student. */
  grade(instituteId: ID, submissionId: ID, input: GradeInput): Promise<Feedback>;
  getFeedback(instituteId: ID, submissionId: ID): Promise<Feedback | null>;
}

export interface ExamRepo extends CrudRepo<Exam, 'batchId' | 'name'> {
  /** Makes the exam and its results visible to students and parents. */
  publish(instituteId: ID, id: ID): Promise<Exam>;
  listQuestions(instituteId: ID, examId: ID): Promise<ExamQuestion[]>;
  saveQuestion(instituteId: ID, input: Upsert<ExamQuestion, 'examId' | 'questionNo' | 'text'>): Promise<ExamQuestion>;
  removeQuestion(instituteId: ID, id: ID): Promise<void>;
}

export interface MarkEntry {
  studentId: ID;
  subjectId: ID;
  /** null with `isAbsent: true`, or to clear an entry. */
  marksObtained: number | null;
  maxMarks: number;
  isAbsent?: boolean;
  remark?: string | null;
}

export interface MarkRepo extends ReadRepo<Mark> {
  /** Enters or corrects marks for one exam. One row per student per subject. */
  saveMany(instituteId: ID, examId: ID, entries: MarkEntry[]): Promise<Mark[]>;
}

export interface ResultRepo extends ReadRepo<Result> {
  listForStudent(instituteId: ID, studentId: ID): Promise<Result[]>;
  /** Recomputes totals, percentage, grade and rank for the exam from its marks. */
  compute(instituteId: ID, examId: ID): Promise<Result[]>;
}
