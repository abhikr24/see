import type {
  FeeStructure,
  FeeSummary,
  ID,
  ISODate,
  Installment,
  InstallmentStatus,
  Money,
  NewEntity,
  Payment,
  PaymentMethod,
  PaymentOrder,
  Receipt,
  Refund,
  StudentFee,
  Upsert,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { ReadRepo } from './common';

export interface AssignFeeInput {
  studentId: ID;
  feeStructureId: ID;
  discountAmount?: Money;
  discountReason?: string | null;
  /** Due date of the first installment. Defaults to today. */
  firstDueDate?: ISODate;
}

export interface FeeRepo {
  listStructures(instituteId: ID, query?: ListQuery<FeeStructure>): Promise<Page<FeeStructure>>;
  saveStructure(
    instituteId: ID,
    input: Upsert<FeeStructure, 'name' | 'academicYear' | 'totalAmount'>,
  ): Promise<FeeStructure>;
  listStudentFees(instituteId: ID, query?: ListQuery<StudentFee>): Promise<Page<StudentFee>>;
  /** Gives a student a fee structure and generates its installments. */
  assign(instituteId: ID, input: AssignFeeInput): Promise<StudentFee>;
  listInstallments(
    instituteId: ID,
    filter?: { studentId?: ID; studentFeeId?: ID; status?: InstallmentStatus },
  ): Promise<Installment[]>;
  waiveInstallment(instituteId: ID, installmentId: ID): Promise<Installment>;
  summary(instituteId: ID): Promise<FeeSummary>;
}

export interface PaymentRepo extends ReadRepo<Payment> {
  /** Records money received at the desk, updates the installment and issues a receipt. */
  record(
    instituteId: ID,
    input: NewEntity<Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'>,
  ): Promise<Payment>;
  listRefunds(instituteId: ID, filter?: { paymentId?: ID; studentId?: ID }): Promise<Refund[]>;
  requestRefund(instituteId: ID, input: { paymentId: ID; amount: Money; reason?: string | null }): Promise<Refund>;
  decideRefund(instituteId: ID, refundId: ID, status: 'approved' | 'rejected' | 'processed'): Promise<Refund>;
}

export interface ReceiptRepo extends ReadRepo<Receipt> {
  getForPayment(instituteId: ID, paymentId: ID): Promise<Receipt | null>;
  /** Idempotent: returns the existing receipt if the payment already has one. */
  issue(instituteId: ID, paymentId: ID): Promise<Receipt>;
}

/** The online payment gateway (Razorpay, Stripe, …). Desk payments go through PaymentRepo. */
export interface PaymentPort {
  /** Online methods switched on for this institute. Empty = online payment is off. */
  listMethods(instituteId: ID): Promise<PaymentMethod[]>;
  createOrder(instituteId: ID, input: { studentId: ID; installmentId: ID; amount: Money }): Promise<PaymentOrder>;
  getOrder(instituteId: ID, orderId: ID): Promise<PaymentOrder>;
  /** Verifies the gateway's proof of payment and records the Payment. */
  confirm(
    instituteId: ID,
    orderId: ID,
    proof: { providerPaymentId: string; signature?: string },
  ): Promise<Payment>;
}
