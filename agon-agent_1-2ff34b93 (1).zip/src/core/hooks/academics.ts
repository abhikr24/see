import type { AttendanceSheet, Batch, Enrollment, ID, Subject, Timetable } from '../contracts/models';
import type { AttendanceFilter, AttendanceSheetInput } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { useCrud, useDomainMutation, useDomainQuery } from './domain';

/** BatchRepo · batches and who is enrolled in them. */
export function useBatches(query?: ListQuery<Batch>) {
  const batches = useCrud<Batch, 'name' | 'academicYear'>('batches', 'Batch', (b) => b.batches, query);
  const enroll = useDomainMutation<{ batchId: ID; studentId: ID; rollNumber?: number | null }, Enrollment>(
    ['batches', 'students', 'progress'],
    (b, i, { batchId, ...input }) => b.batches.enroll(i, batchId, input),
    { success: 'Student enrolled', failure: 'Could not enrol the student' },
  );
  const unenroll = useDomainMutation<ID, Enrollment>(
    ['batches', 'students', 'progress'],
    (b, i, enrollmentId) => b.batches.unenroll(i, enrollmentId),
    { success: 'Student removed from the batch', failure: 'Could not remove the student from the batch' },
  );
  return {
    ...batches,
    enroll: enroll.mutate,
    unenroll: unenroll.mutate,
    saving: batches.saving || enroll.loading || unenroll.loading,
  };
}

/** BatchRepo · the batches the signed-in person teaches, studies in or has a child in. */
export function useMyBatches() {
  return useDomainQuery<Batch[]>('batches', ['mine'], (b, i) => b.batches.listMine(i));
}

/** SubjectRepo */
export function useSubjects(query?: ListQuery<Subject>) {
  return useCrud<Subject, 'name' | 'code'>('subjects', 'Subject', (b) => b.subjects, query);
}

/** TimetableRepo · weekly periods. Pass `{ where: { batchId } }` for one batch. */
export function useTimetable(query?: ListQuery<Timetable>) {
  return useCrud<Timetable, 'batchId' | 'dayOfWeek' | 'startsAt' | 'endsAt'>(
    'timetable',
    'Period',
    (b) => b.timetable,
    query,
  );
}

/** AttendanceRepo · roll calls for a batch, newest first, and saving a sheet. */
export function useAttendance(batchId?: ID) {
  const sessions = useDomainQuery('attendance', ['sessions', batchId ?? null], (b, i) =>
    b.attendance.listSessions(i, { where: { batchId }, sort: { field: 'date', direction: 'desc' } }),
  );
  const save = useDomainMutation<AttendanceSheetInput, AttendanceSheet>(
    ['attendance', 'analytics', 'progress'],
    (b, i, input) => b.attendance.saveSheet(i, input),
    {
      success: (sheet) => `Attendance saved for ${sheet.records.length} students`,
      failure: 'Could not save attendance',
    },
  );
  return { ...sessions, save: save.mutate, saving: save.loading };
}

/** AttendanceRepo · one roll call with its records. Off while `sessionId` is null. */
export function useAttendanceSheet(sessionId: ID | null) {
  return useDomainQuery<AttendanceSheet>(
    'attendance',
    ['sheet', sessionId],
    (b, i) => b.attendance.getSheet(i, sessionId as ID),
    sessionId !== null,
  );
}

/** AttendanceRepo · present / absent / late / leave counts and the percentage for a student or batch. */
export function useAttendanceSummary(filter: AttendanceFilter) {
  return useDomainQuery('attendance', ['summary', filter], (b, i) => b.attendance.summary(i, filter));
}
