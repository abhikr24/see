import type {
  ID,
  Material,
  PracticeQuestion,
  Quiz,
  QuizAttempt,
  RiskAlert,
  Student360,
  StudentGoal,
  StudyTask,
  Upsert,
} from '../contracts/models';
import type { ListQuery } from '../contracts/query';
import { queryCache, queryKey } from './cache';
import { useBackend } from './context';
import { dropItem, patchItem, useCrud, useDomainMutation, useDomainQuery, useListEditor } from './domain';

/** MaterialRepo */
export function useMaterials(query?: ListQuery<Material>) {
  return useCrud<Material, 'title'>('materials', 'Material', (b) => b.materials, query);
}

/** PracticeRepo · the question bank. */
export function usePractice(query?: ListQuery<PracticeQuestion>) {
  const args = ['questions', query ?? null];
  const questions = useDomainQuery('practice', args, (b, i) => b.practice.listQuestions(i, query));
  const edit = useListEditor<PracticeQuestion>('practice', args);
  const save = useDomainMutation<Upsert<PracticeQuestion, 'text'>, PracticeQuestion>(
    'practice',
    (b, i, input) => b.practice.saveQuestion(i, input),
    { success: 'Question saved', failure: 'Could not save the question' },
  );
  const remove = useDomainMutation<ID, void>(
    'practice',
    (b, i, id) => b.practice.removeQuestion(i, id),
    { success: 'Question removed', failure: 'Could not remove the question' },
    (id) => edit(dropItem<PracticeQuestion>(id)),
  );
  return { ...questions, save: save.mutate, remove: remove.mutate, saving: save.loading || remove.loading };
}

/** PracticeRepo · quizzes and attempts. */
export function useQuizzes(query?: ListQuery<Quiz>) {
  const quizzes = useDomainQuery('practice', ['quizzes', query ?? null], (b, i) => b.practice.listQuizzes(i, query));
  const save = useDomainMutation<Upsert<Quiz, 'batchId' | 'title'>, Quiz>(
    'practice',
    (b, i, input) => b.practice.saveQuiz(i, input),
    { success: 'Quiz saved', failure: 'Could not save the quiz' },
  );
  const start = useDomainMutation<{ quizId: ID; studentId: ID }, QuizAttempt>(
    'practice',
    (b, i, { quizId, studentId }) => b.practice.startAttempt(i, quizId, studentId),
    { failure: 'Could not start the quiz' },
  );
  const submit = useDomainMutation<{ attemptId: ID; answers: Record<ID, string> }, QuizAttempt>(
    'practice',
    (b, i, { attemptId, answers }) => b.practice.submitAttempt(i, attemptId, answers),
    { success: (a) => `You scored ${a.score ?? 0} out of ${a.maxScore ?? 0}`, failure: 'Could not submit the quiz' },
  );
  return {
    ...quizzes,
    save: save.mutate,
    start: start.mutate,
    submit: submit.mutate,
    saving: save.loading || start.loading || submit.loading,
  };
}

/** ProgressPort · Student 360: everything about one student, plus their tasks and goals. */
export function useStudent360(studentId: ID | null) {
  const { backend, instituteId } = useBackend();
  const args = ['student360', studentId];
  const key = queryKey(backend.name, 'progress', instituteId, args);
  const view = useDomainQuery<Student360>(
    'progress',
    args,
    (b, i) => b.progress.getStudent360(i, studentId as ID),
    studentId !== null,
  );
  const editTasks = (change: (tasks: StudyTask[]) => StudyTask[]) =>
    queryCache.update<Student360>(key, (current) => ({ ...current, tasks: change(current.tasks) }));

  const saveTask = useDomainMutation<Upsert<StudyTask, 'studentId' | 'title'>, StudyTask>(
    'progress',
    (b, i, input) => b.progress.saveTask(i, input),
    { failure: 'Could not save the task' },
    // Ticking a task off should feel instant; a brand-new task waits for the backend's id.
    (input) => input.id && editTasks(patchItem<StudyTask>(input.id, input)),
  );
  const removeTask = useDomainMutation<ID, void>(
    'progress',
    (b, i, id) => b.progress.removeTask(i, id),
    { success: 'Task removed', failure: 'Could not remove the task' },
    (id) => editTasks(dropItem<StudyTask>(id)),
  );
  const saveGoal = useDomainMutation<Upsert<StudentGoal, 'studentId' | 'title'>, StudentGoal>(
    'progress',
    (b, i, input) => b.progress.saveGoal(i, input),
    { success: 'Goal saved', failure: 'Could not save the goal' },
  );

  return {
    ...view,
    saveTask: saveTask.mutate,
    removeTask: removeTask.mutate,
    saveGoal: saveGoal.mutate,
    saving: saveTask.loading || removeTask.loading || saveGoal.loading,
  };
}

/** ProgressPort · early-warning alerts across the institute, a batch or one student. */
export function useRiskAlerts(query?: ListQuery<RiskAlert>) {
  const args = ['alerts', query ?? null];
  const alerts = useDomainQuery('progress', args, (b, i) => b.progress.listAlerts(i, query));
  const edit = useListEditor<RiskAlert>('progress', args);
  const recompute = useDomainMutation<{ batchId?: ID; studentId?: ID } | void, RiskAlert[]>(
    ['progress', 'analytics'],
    (b, i, filter) => b.progress.computeAlerts(i, filter ?? {}),
    { success: (open) => `${open.length} open alert${open.length === 1 ? '' : 's'}`, failure: 'Could not check for risks' },
  );
  const setStatus = useDomainMutation<{ id: ID; status: RiskAlert['status'] }, RiskAlert>(
    ['progress', 'analytics'],
    (b, i, { id, status }) => b.progress.setAlertStatus(i, id, status),
    { failure: 'Could not update the alert' },
    ({ id, status }) => edit(patchItem<RiskAlert>(id, { status })),
  );
  return {
    ...alerts,
    recompute: recompute.mutate,
    setStatus: setStatus.mutate,
    saving: recompute.loading || setStatus.loading,
  };
}
