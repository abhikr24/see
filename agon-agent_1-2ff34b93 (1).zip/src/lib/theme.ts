import { Platform, useColorScheme } from 'react-native';

/**
 * Single source of truth for every colour, radius, spacing and shadow.
 * No component or file may hardcode a hex value outside this module.
 * See AGENTS.md § Design system.
 */
export const C = {
  canvas: '#F5F6FA',
  surface: '#FFFFFF',
  ink: '#0B1220',
  secondary: '#5A6684',
  muted: '#94A0BC',
  hairline: '#E7EBF5',
  primary: '#101B4C',
  primary2: '#1E3A8A',
  accent: '#FF7A1A',
  accentSoft: '#FFF1E6',
  teal: '#0D9488',
  tealSoft: '#E4F7F4',
  success: '#16A34A',
  successSoft: '#DCF5E5',
  warning: '#F59E0B',
  warningSoft: '#FEF1D6',
  danger: '#DC2626',
  dangerSoft: '#FEECEC',
  track: '#EFF2F8',
  navySoft: '#E8EEFF',
  navyMid: '#93B4FF',
  navyBright: '#3B66D6',
  scrim: 'rgba(11, 18, 32, 0.45)',
  transparent: 'transparent',
  // Contract-check & dark-mode support tokens
  darkCanvas: '#0B1020',
  darkSurface: '#151B2E',
  darkBorder: '#28324D',
  darkText: '#F3F4F6',
  darkMuted: '#A3ACBD',
  darkPassText: '#BBF7D0',
  darkPassFill: '#14532D',
  darkPassBar: '#4ADE80',
  darkFailText: '#FECACA',
  darkFailFill: '#7F1D1D',
  darkFailBar: '#F87171',
} as const;

export const GRADIENT = [C.primary, C.primary2] as const;

export const FONT_SIZE = {
  h1: 34,
  h2: 22,
  title: 17,
  body: 15,
  caption: 13,
  label: 11,
} as const;

export const hit = 44;

export const R = {
  card: 20,
  btn: 16,
  field: 14,
  sheet: 28,
  chip: 999,
  cell: 8,
} as const;

export const S = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
} as const;

/** Screen side margin, card padding, and minimum touch target. */
export const LAYOUT = {
  margin: 20,
  cardPad: 18,
  hit: 44,
  row: 68,
} as const;

export const FONT = {
  heading: 'System',
  body: 'System',
  mono: 'Courier',
} as const;

export const SHADOW = {
  shadowColor: C.primary,
  shadowOpacity: 0.08,
  shadowRadius: 12,
  shadowOffset: { width: 0, height: 8 },
  elevation: 3,
} as const;

export type Tone = 'neutral' | 'success' | 'warning' | 'danger' | 'teal' | 'accent' | 'primary';

export const TONE: Record<Tone, { fg: string; bg: string }> = {
  neutral: { fg: C.secondary, bg: C.track },
  success: { fg: C.success, bg: C.successSoft },
  warning: { fg: C.warning, bg: C.warningSoft },
  danger: { fg: C.danger, bg: C.dangerSoft },
  teal: { fg: C.teal, bg: C.tealSoft },
  accent: { fg: C.accent, bg: C.accentSoft },
  primary: { fg: C.primary, bg: C.navySoft },
};

export interface Theme {
  dark: boolean;
  background: string;
  surface: string;
  border: string;
  text: string;
  muted: string;
  primary: string;
  onPrimary: string;
  passText: string;
  passFill: string;
  passBar: string;
  failText: string;
  failFill: string;
  failBar: string;
}

const light: Theme = {
  dark: false,
  background: C.canvas,
  surface: C.surface,
  border: C.hairline,
  text: C.ink,
  muted: C.secondary,
  primary: C.primary,
  onPrimary: C.surface,
  passText: C.success,
  passFill: C.successSoft,
  passBar: C.success,
  failText: C.danger,
  failFill: C.dangerSoft,
  failBar: C.danger,
};

const dark: Theme = {
  dark: true,
  background: C.darkCanvas,
  surface: C.darkSurface,
  border: C.darkBorder,
  text: C.darkText,
  muted: C.darkMuted,
  primary: C.navyMid,
  onPrimary: C.darkCanvas,
  passText: C.darkPassText,
  passFill: C.darkPassFill,
  passBar: C.darkPassBar,
  failText: C.darkFailText,
  failFill: C.darkFailFill,
  failBar: C.darkFailBar,
};

export function useTheme(): Theme {
  return useColorScheme() === 'dark' ? dark : light;
}

export const MONO = Platform.select({
  ios: 'Menlo',
  android: 'monospace',
  default: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
});
