import { Redirect } from 'expo-router';

/** P1 showcase is the only active entry until P4 adds authentication. */
export default function Index() {
  return <Redirect href="/dev/components" />;
}
