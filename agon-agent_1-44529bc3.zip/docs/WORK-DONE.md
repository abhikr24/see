# WORK DONE — GuruFlow build tracker

**Last updated:** build pass 2 · 09 Nov 2026 (P1-only follow-up)
**Overall completion:** ~30% (foundation complete, zero feature screens)
**Build pack:** `docs/GuruFlow-AI-Build-Pack.md` (24 prompts — the plan)

This file is the handoff contract. Read it before writing any code.
If you are the next AI: finish the "NEXT" section, then **update this file**
before you hand off again. Never delete a row — mark it.

---

## 1. Status at a glance

| Prompt | Area | Status | Notes |
|---|---|---|---|
| P1 | Scaffold, tokens, UI primitives | **DONE** | Refined interactive gallery at `/dev/components`; typed copy/tokens, photo fallback, shimmer, sheet and tab preview; typecheck and all-platform export passed |
| P2 | Contracts layer | **DONE** | Typechecks clean. 14 ports, 22 domain types |
| P3 | Schema, RLS, seed, adapter | **DONE** | 41 policies, 17 tables, adapter implements all ports |
| P4 | Auth screens | **NOT STARTED** | Placeholder route only |
| P5 | Register / join / approvals | **NOT STARTED** | Adapter methods exist |
| P6 | Session, routing, tab bars | **PARTIAL** | Store + route groups + TabBar done. Org switcher missing |
| P7 | Students | **NOT STARTED** | Repo + hooks ready |
| P8 | Batches & timetable | **NOT STARTED** | Repo + hooks ready |
| P9 | Attendance | **NOT STARTED** | Repo + hooks ready |
| P10 | Exams & marks | **NOT STARTED** | Repo + hooks ready |
| P11 | Fees | **NOT STARTED** | Repo exists but `totals()` is simplified |
| P12 | Content library | **NOT STARTED** | Repo + hooks ready |
| P13 | Teacher screens | **NOT STARTED** | — |
| P14 | Homework | **NOT STARTED** | Schema exists, repo not written |
| P15 | Student screens | **NOT STARTED** | — |
| P16 | Player & materials | **NOT STARTED** | `VideoPort` returns the raw URL |
| P17 | Parent screens | **NOT STARTED** | `PaymentPort` throws by design |
| P18 | Notices & notifications | **NOT STARTED** | Repos ready |
| P19 | Reports | **NOT STARTED** | — |
| P20 | Settings & billing | **NOT STARTED** | Plan cap enforced in `StudentRepo.create` |
| P21 | Empty/error/offline | **PARTIAL** | Components exist, not applied to screens |
| P22 | Security audit | **PARTIAL** | Policies written, **never executed** |
| P23 | Performance & deploy | **NOT STARTED** | — |
| P24 | Extensibility docs | **PARTIAL** | AGENTS, README, ARCHITECTURE, HANDOFF written |

---

## 2. What actually exists

```
Imported full handoff (90 archive entries) into the Expo workspace; kept all existing routes, contracts, adapters, SQL, docs and assets. P1 gallery is now the default landing route. Exact file count changes with generated files; source files remain under 300 lines.

src/core/contracts/      models(206) ports(170) errors(42) query(15)
src/core/config/         env(31) providers(12)     ← the swap file
src/core/backend.tsx     context + 18 domain hooks (139)
src/adapters/supabase/   client, mappers(95), repos.core(242),
                         repos.learning(250), auth(63), storage(34), misc(31)
src/components/ui/       12 primitives (~460 lines total)
src/lib/                 theme(61) format(67) nav(44)
src/store/               session(42)
app/                     root layout, route resolver, 4 role groups + tabs,
                         auth & pending placeholders, dev/ gallery + contract check
supabase/migrations/     0001_init(245) · 0002_rls(197)
supabase/seed.sql        93 lines, fixed UUIDs
supabase/demo/           attach_users.sql
```

---

## 3. Verified vs not verified — read this honestly

| Claim | Status |
|---|---|
| `src/core/contracts/**` + `src/lib/**` typecheck with `tsc --strict` | **VERIFIED — 0 errors** |
| SQL is syntactically valid Postgres | **NOT VERIFIED** — never executed |
| RLS policies actually block cross-org reads | **NOT VERIFIED** — written, untested |
| Adapter compiles against the Supabase SDK | **VERIFIED** — `npm run typecheck` passed with SDK installed; API calls not exercised |
| Full project TypeScript | **VERIFIED** — `npm run typecheck` passed with zero errors, 09 Nov 2026 |
| Expo export (web, iOS, Android) | **VERIFIED** — `npx expo export --platform all` completed, 09 Nov 2026 |
| React components render visually without warnings | **NOT VERIFIED** — exported but not manually inspected on a device/browser |
| App runs end to end with live auth/backend | **NO** — P4+ and live backend not exercised |

Typecheck and bundling validate compilation, not real database behaviour or visual QA. P1 is the only scope of this follow-up; do not infer that P4+ is complete.

---

## 4. Decisions made (do not silently reverse)

1. **Backend abstraction is the spine.** UI → hooks → `src/core/contracts/ports.ts`
   → `src/adapters/<vendor>` → one line in `src/core/config/providers.ts`.
   Any prompt that makes a screen import a backend SDK is wrong — reject it.
2. **`profiles` has no `org_id`.** Tenancy lives in `memberships`. This is what
   lets a student belong to several institutes.
3. **Seed UUIDs are fixed** (`00000000-0000-4000-8000-0000000000XX`) so tests and
   screenshots stay stable across reseeds.
4. **Teacher names were removed from the marks seed.** The old contract listed
   "Rohit 91, Meera 78, Arun 68" as student marks, but those three are teachers.
   Corrected in `seed.sql`; documented in `AGENTS.md`.
5. **`PaymentPort` throws on purpose.** No gateway is wired. Parent "Pay now"
   must go through this port, never directly to a vendor.
6. **Files stay under 300 lines.** `repos.core.ts` (242) and
   `repos.learning.ts` (250) are close to the limit — split them when you add
   to them.

---

## 5. Known gaps and rough edges

- `FeeRepo.totals()` returns `overdue: 0` and derives `expected` from
  collected+pending only. It needs a real fee-plan join before the fees
  dashboard can be trusted.
- `FeeRepo.dueList()` hardcodes a ₹4,999 term fee. Replace with the batch fee plan.
- `ExamRepo.analysis()` returns a single subject row. Multi-subject analysis
  needs a join across exams by subject.
- `OrgRepo.search()` builds an `or()` filter with a string replace — simplify
  before it bites.
- `BatchRepo.list()` does not return `studentCount` / `attendancePct`. The batch
  cards in P8 need a view or an RPC.
- `StudentRepo.list()` does not compute `feeDue` or `absentToday`. Same fix.
- `Avatar` now loads remote photos with initials fallback; photo load/failure still needs on-device visual QA.
- No offline queue, no haptics, no toast host yet. P1 gallery uses an inline feedback card.
- `app/index.tsx` temporarily redirects to the P1 gallery; real auth bootstrapping and route guards remain P4/P6 work.
- P1 gallery has been bundled for all platforms but not manually clicked through; inspect small-screen spacing and keyboard/sheet behaviour on a device.
- Original handoff dependencies were inconsistent with its Expo version. The project now installs against the workspace Expo SDK 57 with package overrides for transitive Radix versions; review compatibility before future SDK upgrades.
- P1 gallery demonstrates a 5-item tab bar locally; actual feature tab destinations remain outside this session's scope.
- Fonts still use system typefaces rather than the specified Satoshi/Plus Jakarta Sans because font assets were not provided. NativeWind is configured but existing primitives still use inline static style objects, contrary to the pack's NativeWind-only ideal.

---

## 6. NEXT — do these in order

```
1. Install from the included package-lock.json with npm install; rerun npm run typecheck.
2. Open the default /dev/components gallery on a phone and web browser; test inputs,
   chips, buttons, sheet, tab preview and empty/error actions; record visual issues.
3. Resolve P1 typography and NativeWind-only styling gaps if required by design QA.
4. Only after approval to leave P1: configure a real Supabase project and execute
   the migrations, seed and tenancy tests; do not treat SQL as verified yet.
5. Only after explicit go-ahead: begin P4 auth and replace the gallery landing route.
```

---

## 7. How to hand off again

When you finish a session:

1. Update the status table in §1 (mark rows `DONE` / `PARTIAL`, never delete).
2. Update §3 honestly — move claims from "not verified" to "verified" only if
   you actually ran them.
3. Add new gaps to §5.
4. Rewrite §6 with the next three to five steps.
5. Append one line to §8 below.

---

## 8. Session log

| # | Date | Did | Left for next |
|---|---|---|---|
| 1 | 09 Nov 2026 | P1 scaffold + design system, P2 contracts, P3 schema/RLS/seed/adapter, partial P6 shell, docs | Auth screens onward. Nothing executed against a live backend yet. |
| 2 | 09 Nov 2026 | Imported full handoff; P1-only gallery and primitives refinement; resolved dependency/TypeScript issues; passed typecheck and all-platform Expo export; packaged full source | Manually inspect P1 on device; live backend, SQL and P4+ remain unverified/unbuilt. |
