import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { TakeAttendanceScreen } from '@/features/attendance/take';
import { todayIso } from '@/features/attendance/model';

const ISO = /^\d{4}-\d{2}-\d{2}$/;

/** Take Attendance for one batch. `date`, `period` and `subjectId` are prefilled by the caller. */
export default function TakeAttendanceRoute() {
  const params = useLocalSearchParams<{ batchId: string; date?: string; period?: string; subjectId?: string }>();
  const today = todayIso();
  const date = params.date && ISO.test(params.date) && params.date <= today ? params.date : today;
  const period = Math.max(1, Number.parseInt(params.period ?? '1', 10) || 1);
  return (
    <TakeAttendanceScreen
      batchId={String(params.batchId)}
      date={date}
      period={period}
      subjectId={params.subjectId ? String(params.subjectId) : null}
    />
  );
}
