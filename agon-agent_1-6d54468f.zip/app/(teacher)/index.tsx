import React from 'react';

import { TodayScheduleScreen } from '@/features/timetable';

/**
 * The teacher home reads today's periods straight from the institute
 * timetable (TimetableRepo) — the same rows the owner's board edits.
 * P13 grows the rest of the teacher home around this.
 */
export default function TeacherHomeRoute() {
  return <TodayScheduleScreen role="teacher" />;
}
