# Work done

## 2026-11-13 · Take Attendance (P13) — speed is the design

**Screen: `src/features/attendance/take.tsx` + `components/StudentTile.tsx`, route `app/(owner)/attendance/[batchId].tsx`**
- Shape D, no app chrome. `app/(owner)/_layout.tsx` renders `ChromelessGate` for this route: the same role guard, but no header and no tab bar.
- Compact header with back, "Class 10-A · Mathematics" and a date chip. The chip opens a sheet with today and the previous 13 days. Future dates are never offered.
- White summary strip: "N Present · N Late · N Absent" in teal, amber and red, plus a navy "Mark all present" link.
- A 3-column grid with 10pt gaps and 108pt tiles. Each tile has a photo (initials if there is none), a one-line ellipsised name, the roll number, a 4pt status strip, and a check / cross / clock badge on the avatar. Absent tiles dim the photo to 60%. Tiles are memoised, so a tap repaints only one tile.
- Sticky footer: "Save attendance · 46/50 present" with the count in saffron. It stays disabled until something changes. On a saved sheet it reads "Update attendance", and the header shows an "Editing saved sheet" pill.
- Tapping a tile cycles present → absent → late, with a light haptic on native (`expo-haptics`).
- Long-press opens a menu with two actions: "Call parent" (`tel:` the primary guardian's number) and "Mark all after this" (copies this tile's status to every later roll number).
- If you leave with unsaved marks, a confirm dialog asks first.

**Contract: three new `AttendanceRepo` methods**
- `openRoll`: roster in roll order, each student's primary parent and phone, the saved sheet for (batch, date, period) or null, the subject name, and `alertsEnabled`. All in one read.
- `listSheets({ date })`: the sheets for one day. This feeds the timetable's Attendance tab.
- `notifyAbsentParents(sessionId)`: creates one `attendance_absent` notification per absent student's parent login.
  - It only runs when `settings.features.attendanceAlerts` is on.
  - It is idempotent per (sheet, student, parent), so re-saving never notifies twice. It also reports parents it could not reach.
- Implemented in memory (`src/backends/memory/attendance-roll.ts`) and Supabase (`src/adapters/supabase/attendance-roll.repo.ts`). The Supabase version falls back to the reference backend when unreachable, like the rest of that adapter.

**Save path (`hooks/useTakeAttendance.ts`, `commit.ts`)**
- One `saveSheet` call sends the whole roll as one batched upsert. Parent alerts go out after it. If the alerts fail, the save still stands.
- The save goes through `runMutation`:
  1. The sheet first reads as saved.
  2. The day-sheets cache is updated optimistically.
  3. The `attendance`, `progress`, `analytics` and `batches` scopes are invalidated.

  As a result the timetable tab, the student 360 and the dashboard update without a reload.
- If the save fails, it rolls back the "saved" look. Every mark stays on screen, and a red bar offers Retry.
- Offline (NetInfo) or a transient error queues the sheet:
  - The sheet goes into an AsyncStorage outbox (`outbox.ts`). A newer save of the same sheet replaces the older one.
  - A calm grey banner says it is saved on this phone, plus "Last synced X min ago".
  - `AttendanceOutboxSync`, mounted in `app/_layout.tsx`, flushes the queue on launch, on reconnect, after each enqueue and every 30 s.
  - Reopening a queued sheet shows the queued marks.

**Timetable integration**
- Every period row has a take/edit attendance button. It shows a teal double-check once that period is marked.
- The button opens the register with `batchId`, `date`, `period` and `subjectId` prefilled. The date is the most recent occurrence of the selected weekday, never a future one. The period is 1 in daily mode and the row's ordinal in period mode.
- The new Schedule / Attendance switch adds an Attendance tab: one card per period showing the percentage, a present/late/absent bar, and counts, or "Not marked · Take".
- `/(owner)/attendance` now redirects `?batchId=` (the dashboard shortcut) to today's register. Without a batch it lists batches with today's state. The placeholder route is gone.

**Seed**
- `seed-guardians.ts`: one parent with an active parent login for each Class 10-A student. Aarav's parent is the existing Anita Sharma. Ids are 11000+ and do not collide with any earlier id range.
- The institute has `features.attendanceAlerts: true`. New institutes also default to on.
- Snapshots saved before this change are topped up by `ensureGuardians`.

**Verified**
- `npx tsc --noEmit`: 0 errors. ESLint is clean on every new attendance file.
- `npm run build` (`expo export --platform all`) is clean. `npm run test:timetable` and `npm run test:batches` still pass.
- `npm run test:attendance` (13 checks) passes:
  - today opens the seeded sheet in edit mode;
  - a fresh date starts all present;
  - a save notifies exactly the 3 absent parents, each row addressed to a parent login;
  - reopening shows the saved states;
  - re-saving never double-notifies, and a newly absent student is notified;
  - the alert setting gates notifications;
  - `listSheets` and the student `summary` both see the save;
  - "mark all after this" works;
  - no future dates;
  - tenant isolation;
  - old snapshots get topped up.
- `node tests/attendance.browser.cjs` (exported web build) passes these steps:
  - signed in as owner;
  - Timetable row → register opens prefilled in edit mode;
  - save is disabled until a tap;
  - marked → "Attendance updated";
  - back on the timetable, the Attendance tab immediately shows "9 of 12 present".

**Known gaps**
- The browser script's offline step fails: Playwright's `setOffline` did not trigger NetInfo's offline state on web within 10 s. The banner never appeared, so queue-and-sync was not exercised in the browser. Airplane mode still needs a check on a real device.
- The queue logic itself is covered only by code review.
- "42 students in under 60 seconds by a human" was not timed with a person. The seed has 12 students per batch. The scripted run took about 15 s, most of it Playwright overhead.
- Supabase was not run against a live project.
- `.env` (`EXPO_PUBLIC_BACKEND=memory`) is local only and not committed. Export did not pick up `.env.local`.

## 2026-11-13 · Timetable (P12) — drag, clash gate, one table for every role

The owner's timetable board: a week strip of seven 40pt chips (selected day
filled navy, today dotted saffron), 64pt period rows split by 1px hairlines
(44pt time chip, subject 15/600 with the batch pill, teacher 13 secondary,
room 13 muted, drag handle right), and the amber clash card at the bottom.

**Feature — `src/features/timetable/` + `app/(owner)/timetable.tsx`**
- `model.ts` — pure logic, no React/backend: canonical day order, slot
  reassignment on reorder (slots belong to the day, periods rotate through
  them), `moveToDay`, field-level diffs, and `findClashes`: same teacher +
  overlapping time + same day → hard teacher clash; same room + overlap with
  different teachers → soft room clash (the harder warning subsumes the pair).
- `hooks/useTimetableBoard.ts` — one `useDomainQuery` loads periods, batches,
  subjects, teachers and classrooms; edits live in a local overlay, are
  diffed against the base, gated by conflict detection, then flushed through
  the standard mutation path (snapshot → optimistic → toast, or roll back +
  error toast). A teacher clash on a touched day blocks the flush; the overlay
  drops itself once the refetched base catches up, so external writes are
  never masked.
- `hooks/usePeriodDrag.ts` — responder-based drag (touch + web mouse): the
  list never reorders mid-gesture; the dragged row tints soft navy with a 1px
  navy ring, a ghost follows the pointer, a navy line marks the insertion
  boundary, and day chips light up as drop targets. Release on a chip moves
  the period to that weekday (keeping its slot) and follows it there.
- `components/MovePeriodSheet.tsx` — tap on the handle: move up/down or send
  to a day. Same mutations as the drag, reachable without a gesture.
- `components/ClashCards.tsx` — the teacher card names the teacher and both
  batches with their times, says the save is blocked, and "Fix" selects the
  day, scrolls to the two rows and flashes them amber. The room card is a
  hairline card with an amber edge bar, "warning only", dismissible.
- Entry point: dashboard "Today's batches" section header → "Timetable"
  (`dashboardLinks.openTimetable`).

**One table, three readers — no duplicated data**
- `hooks/useTodaySchedule.ts` + `screens/TodayScheduleScreen.tsx`: the
  teacher's "Today's schedule" (`app/(teacher)/index.tsx`) and the student's
  "My Day" (`app/(student)/index.tsx`) read the same `TimetableRepo` rows in
  the same `timetable` cache scope the owner board writes — a period moved by
  the owner moves for them. The P13/P15 placeholders are replaced; those
  prompts grow around this.

**Seed — `src/backends/memory/seed.ts`**
- Three shared classrooms (Room 1, Room 2, Lab; ids 61–63) and a classroomId
  on every seeded period, so rows show a real room and room clashes are
  reachable. Note: the existing seed already double-books Meera Iyer on
  today's weekday (Class 10-A 17:15–18:15 vs Class 11-A 18:00–19:00), so the
  board correctly opens with the amber card naming it — resolving it (one
  drag) clears the warning and unblocks saves on that day.

**Verified**
- `npx tsc --noEmit` — zero errors. `npx expo export --platform all` — clean.
- `npm run test:timetable` (new, `tests/timetable.acceptance.ts`, 7 checks):
  the seeded clash is detected and named; a deliberate teacher clash blocks
  the save and names both batches and the teacher; removing it clears the
  warning and saves; a room clash warns softly without blocking; a reorder
  survives capture/restore (the reload path); `listForDay(teacherId)` returns
  the owner's reordered rows (same table); tenant isolation.
- `npm run test:batches` — still passes with the classroom seed addition.

## 2026-11-13 · P11 cleanup — one shell, one tab list, no demo twin

A cleanup pass only. No new screen, no new feature, no business-logic change.
Three kinds of drift had crept in while the batches feature was built —
duplication, a second app shell, and numbers that drifted from the shared
formatters. All three are gone.

**Task 1 — deleted the duplicate demo app**
- Removed the whole `app/demo/` folder: `index`, `students`, `new-student`,
  `[id]`, `new` and `_layout`.
- Removed every reference to the batch-preview environment flag.
  `app/index.tsx` no longer redirects to the preview route, and the flag is
  gone from the repo.
- `src/features/batches/useBatchWorkspace.ts`: deleted the `useBatchPath`
  helper and the `base === '/demo'` branch inside it. Callers now use the
  real routes — `/(owner)/batches`, `/(owner)/batches/new` and
  `/(owner)/students/new`.
- `src/features/batches/BatchShell.tsx`: the two `base === '/demo'` branches
  in `go()` are gone with the function that held them.

**Task 2 — deleted dead files from the old base repo**
- Removed `App.tsx` and `index.ts` from the project root. `package.json`
  `main` stays exactly `expo-router/entry`.

**Task 3 — the batches group uses the shared shell**
- `src/features/batches/BatchShell.tsx` no longer carries its own header
  (SafeAreaView + institute identity + owner avatar) and no longer carries
  its own six-item nav array (Overview, Students, Batches, Attendance,
  Fees & payments, Notices). It renders `RoleTabShell` — the same shell
  `app/(owner)/students` renders today.
- The floating pill tab bar is built from `TABS` in `src/lib/nav.ts` and
  from nowhere else. The batches tab already existed there, so no tab was
  added and no tab is hardcoded inside a feature folder.
- The batches screens keep their own content — the title, the "big picture"
  card and the batch cards. Nothing was restyled. Bottom insets were added
  so the shared floating tab bar never covers the last card or the sticky
  action bar.

**Task 4 — whole-number percentages**
- `BatchCard.tsx`, `BatchHero.tsx` and `BatchDetailScreen.tsx` now render
  every visible percentage through `pct()` from `src/lib/format.ts`.
  CSS-style width values (`width: ${x}%`) are untouched.

**Task 5 — readable JSX in the batches module**
- `BatchDetailScreen.tsx`, `BatchCard.tsx`, `BatchHero.tsx`,
  `BatchListScreen.tsx` and `ui.tsx` — plus `BatchCreateScreen.tsx` and
  `BatchDetailDialogs.tsx`, which had the same one-line style — are now
  normal multi-line JSX: 2-space indent, max 120 characters per line.
  Formatting only; behaviour is unchanged.

**Verified**
- The batch-preview environment flag no longer appears anywhere in the repo
  (not in the app, not in the env example, not in this log).
- `ls App.tsx index.ts` → "No such file or directory".
- `grep -rn "label: 'Batches'" src/features/batches` → empty.
- `awk 'length>120 {print FILENAME":"FNR}' src/features/batches/*.tsx` → empty.
- `npx tsc --noEmit` → 0 errors.
- `npx expo export --platform all` → Web + iOS + Android bundles.
- `grep -rn "demo" app/ src/ | grep -v demo1234` → only the lead-stage
  vocabulary (`demo_scheduled`, `demo_attended`, `demo_booked`) in
  `src/core/contracts/` and `src/adapters/`, plus the reference backend's
  mirror of the same protected list. Those are Postgres column values with
  a CHECK constraint in `supabase/migrations/0007_business.sql`, so they
  cannot be renamed without breaking the live column — and both folders are
  out of scope for this task. The sign-in sample accounts keep their name
  and their `demo1234` password.

## 2026-11-13 · Student 360 (P10) — one connected record

The owner student detail is the profile: a navy header you can read in ten
seconds, then Overview / Attendance / Marks / Fees. The P7 stub is gone.

**Screen — `src/features/students/[id].tsx` + `tabs/` + `components/`**
- Navy header: 72pt photo (initials if none), 22/800 name, 13 white/70
  "Class 10-A · Roll 14 · Joined …", three white chips (attendance from
  `AttendanceRepo.summary`, exam average from `ProgressPort.computeSnapshot`,
  Paid / due from `snapshot.feeDue`). Segmented control underneath.
- Overview: "This month" teal ring + Present / Absent / Late from
  `attendance.summary({ studentId, from, to })`; "Recent marks" three rows
  (subject, thin navy bar, tabular obtained/max) from `MarkRepo`; "Fee status"
  the current instalment with teal paid-on copy and a receipt icon; a Risk
  card only when `ProgressPort` returns an open alert — amber left bar, the
  rule that fired in plain words ("Attendance fell below 75% in the last 30
  days"), never a judgement, and "Create intervention" (saves a study task
  and acknowledges the alert).
- Attendance: month list + percentage + heatmap. Overall percent is the
  same `attendance.summary({ studentId })` call as the header chip.
- Marks: exam list with scores from `ResultRepo.listForStudent` and a
  trend line of those percentages.
- Fees: terms with status, due date, paid-on copy and receipts.
- Footer: 56pt outlined "Message parent" (`wa.me` deep link from the
  primary guardian's phone, else the student's).

**Behaviour**
- One hook per tab (`useStudentOverview` / `useStudentAttendance` /
  `useStudentMarks` / `useStudentFees`), enabled the first time the tab is
  focused and then kept on so a return visit does not unload. Header is
  always-on (`useStudentHeader`).
- Every number on screen is a repo field or a formatter (`pct`, `inr`,
  `dateShort`). Tabs never average, never count, never invent a zero.
- A student with nothing recorded sees the empty state for that tab, not
  `0%` / `0/100`. Header chips use `—` until a figure exists, so the chip
  row does not appear later and shift the layout.
- Tab body is a shared 480pt frame with a matching skeleton, so swapping
  tabs does not shove the footer.

**Verified**
- `npx tsc --noEmit` — zero errors. `npx expo export --platform all` — clean.

## 2026-11-12 · Students (P7) — roster, admit, plan cap

The owner Students tab is a real roster. Detail is a stub for P10. No fee
recording and no marks entry.

**Repo**
- `StudentRepo.create` (memory and Supabase) throws `AppError('CONFLICT',
  'plan_limit')` when active students have reached the current plan's
  `maxStudents`. Details carry `{ reason: 'plan_limit', cap, used }`. A
  missing subscription or a null cap is unlimited. Name under 2 characters
  and a phone that is not 10 digits are rejected in the memory repo.
  Roll uniqueness stays on `BatchRepo.enroll`.
- Memory backend accepts `{ persist: true }` (used by `createBackends`).
  A local snapshot is written after every row change and restored on the
  next launch, so an added student survives a reload. Contract checks and
  the Supabase fallback still get a fresh seed.

**Feature — `src/features/students/`**
- List: sticky white header, 34/800 "Students", circular search, navy "+".
  Chips: All (count), one per batch, Overdue. Sub-row
  "N students · M with dues" and a sort menu (name / roll / dues /
  attendance). 72pt rows, 48pt avatar (initials when there is no photo),
  subtitle "Class 10-A · Roll 14 · ₹583 monthly", teal Paid or red due
  pill, amber dot when absent today. Infinite scroll 20/page. Saffron FAB.
  Skeleton, empty ("Add your first student") and error-with-retry.
- Add (`/(owner)/students/new`): 120pt photo with a 5-field progress ring
  (name, batch, roll, parent mobile, monthly fee). Camera falls back to
  the library. Mic fills the name by voice, or a hint to type. Batch chips,
  roll, parent name, parent mobile, monthly fee prefilled from the batch.
  Sticky "Save student" and "Save & next" (stays open, clears name / photo
  / roll, keeps the batch). Plan limit opens an upgrade sheet instead of
  a cryptic toast.
- Detail (`/(owner)/students/[id]`): name, initials or photo, and a line
  that the profile arrives in P10.
- Dashboard "Add student" now lands on `/(owner)/students/new`.

**Verified**
- `npx tsc --noEmit` — zero errors. `npx expo export --platform all` — clean.
- Script against the memory backend: roster is 30 students, 18 with dues;
  Aarav is Class 10-A roll 14, paid, no photo; Zoya is the amber absent
  today; search "Aarav", roll "14", the Class 9-A chip (10) and Overdue
  (18) each return the right rows, and a chip plus a non-matching search
  returns none. With the plan cap set to 300, the 301st create throws
  `plan_limit` with `cap: 300`. A short name is rejected. Admitting a
  student puts them on the next roster read, and a snapshot restore still
  has them.

## 2026-11-12 · Memory seed expanded — dashboard shows real numbers

The memory seed was a 3-student slice, so the owner dashboard read ₹0 / —
even though the screen worked. Only `src/backends/memory/seed.ts` changed
(247 lines); no contract, adapter, hook or screen was touched.

**Seed now contains**
- 12 students in Class 10-A, rolls 14–25, Aarav Sharma first (AGENTS.md
  names), plus 10 in Class 9-A and 8 in Class 11-A — 30 students enrolled
  across 3 batches.
- 5 teachers (Rohit Verma, Priya Nair, Meera Iyer, Sneha Iyer, Arun Kumar)
  with profiles, active memberships, teacher and staff rows, and 5 subjects.
- A Mon–Fri timetable for every batch plus a second period on today's
  weekday, so "Today's batches" always shows 3 rows on any day of the week.
- 30 days of Class 10-A attendance ending today: 360 records, 29 absences,
  331 attended = 91.9% → 92%; today is 11 of 12 → 92%. Each student misses
  only 2–3 days, so no low-attendance alert fires.
- Fees: every student has a Term 2 instalment (₹2,000, due 10 days ago) and
  a Term 3 instalment (₹5,000, due in 30 days). 18 students still owe Term 2
  (12 × ₹2,000 + 6 × ₹1,750 = ₹34,500 overdue across 18 students); 3 payments
  made today (₹5,000 + ₹4,200 + ₹3,200 = ₹12,400) sit on Term 3.
- 6 memberships with status `pending` (Kunal Sinha, Riya Chaudhary, Harsh
  Tiwari, Anita Tiwari, Sanjay Chaudhary, Nikhil Anand). The demo parent
  Anita Sharma moved to id 37 so she no longer collides with the pending set.
- Unit Test 3 (Mathematics, max 100) marks and results for Class 10-A in
  roll order summing to 936, so the average is exactly 78% via marks or
  results. Note this supersedes the 72% figure in AGENTS.md for this seed.

**Verified**
- `npx tsc --noEmit` — zero errors. `npx expo export --platform all` — clean.
- `EXPO_PUBLIC_BACKEND=memory EXPO_PUBLIC_DEV_AUTH=owner npx expo start
  --web` (port 8081), headless Chromium on `/`: "Good afternoon, Rahul" —
  ₹12,400 collected today · 92% attendance · 6 pending approvals ·
  "6 join requests waiting for approval" · "₹34,500 overdue across
  18 students" · Today's batches: Class 10-A (12 students, 4:00 PM),
  Class 9-A (10 students, 5:00 PM), Class 11-A (8 students, 6:00 PM).


## 2026-11-12 · Dev-only auth bypass — owner dashboard without login

Opening `/` used to require the full OTP login before the owner dashboard
could be seen at all, which made the dashboard impossible to eyeball or
screenshot-test in an environment with no working sign-in.

**Added**
- `.env.example` — documents `EXPO_PUBLIC_BACKEND=memory` and the new
  `EXPO_PUBLIC_DEV_AUTH=owner` line (copy to a local, uncommitted `.env`).
- `src/store/session.ts` — `isDevAuthBypassEnabled()` and, in
  `useSessionStore()`, an early synchronous return behind
  `if (__DEV__ && process.env.EXPO_PUBLIC_DEV_AUTH)`: when the value is
  `owner` it returns `status 'ready'`, `group '/(owner)'`, `role 'owner'`,
  `loading false`, user Rahul Sharma and one institute pinned to the seeded
  Sunrise Coaching Classes (`SUNRISE-PAT`, Patna — institute
  `00000000-0000-4000-8000-000000000001`). No session / institute /
  membership query is started and nothing is awaited on that path; the real
  store is renamed `useRealSessionStore()` and is what every non-bypass
  build runs. `__DEV__` is `false` in every release / export bundle and the
  env value is inlined from a local file at bundle time, so the bypass can
  never run in production.
- `src/features/shell/DevAuthBypassBanner.tsx` + `app/_layout.tsx` — an
  amber (`C.warning`) strip at the very top of the app reading
  “DEV BYPASS — auth disabled” whenever the bypass is active, and nothing
  otherwise, so a bypassed build cannot be mistaken for a signed-in one.
- `src/features/dashboard/hooks/useDashboard.ts` — the hero now reads the
  person from `useSessionStore()` instead of `useSession()` (AuthPort), so
  the pinned owner names the greeting (“…, Rahul”) with no login.

**Verified**
- `npx tsc --noEmit` — zero errors.
- `EXPO_PUBLIC_BACKEND=memory EXPO_PUBLIC_DEV_AUTH=owner npx expo start --web`
  (port 8081): headless Chromium opening `http://localhost:8081/` lands
  directly on the owner dashboard with no login — amber “DEV BYPASS — AUTH
  DISABLED” strip, “Sunrise Coaching Classes”, “Good afternoon, Rahul”,
  ₹0 collected today, — attendance, 0 pending approvals, “₹36,000 overdue
  across 1 student”, “1 low-attendance alert this week” and “No classes on
  the timetable today.” Those are the seeded memory figures, not zeroes
  from a failed load.
- Found, not fixed (pre-existing, also on the unmodified routes): the dev
  LogBox reports `Cannot manually set color scheme, as dark mode is type
  'media'` from react-native-css-interop on web.


## 2026-11-12 · Auth cache — membership survives sign-in

After OTP verify the shell still treated a member as having no institute,
because `my-institutes` (and `session`) had been cached empty while signed
out and nothing invalidated them. The owner landed on Choose your role.

**Fix**
- `src/features/auth/hooks/useAuth.ts` — after `signIn`, `signUp`,
  `signInWithGoogle` and `verifyOtp` succeed, `queryCache.invalidate` drops
  the `my-institutes`, `session` and `memberships` scopes (and the
  institute-scoped membership keys) before navigation. The same invalidation
  runs on `signOut`, so the next login does not inherit the previous person.
- `src/store/session.ts` — the store stays subscribed from the root layout,
  so that invalidation re-reads `getSession`. An active membership from that
  read is `ready` even if the institute list is still the signed-out `[]`.
  One extra re-read per user covers a store that mounted on the stale empty
  list. `resolveAuthenticatedDestination` is what the OTP and splash screens
  navigate to, so a member goes to their role home, not `/(auth)/role`.
- `app/index.tsx` — `loading` still shows `ShellLoading`. An empty
  destination never becomes a `Redirect` (that painted a blank screen).
- `src/backends/memory/tenant.ts` — `listMine` returns `[]` when signed out,
  so sign-out invalidation can actually clear the list instead of keeping
  the last good data on an `UNAUTHENTICATED` error.
- Memory seed starts signed out and includes `parent@sunrise.test` (Anita
  Sharma, active parent) so each demo pill has a membership to land on.
- `.env` — `EXPO_PUBLIC_BACKEND=memory` (the line the shell entry documents,
  missing from the imported archive).

**Verified**
- `npx tsc --noEmit` — zero errors.
- `npx expo start --web`: Owner / Teacher / Student / Parent demo pills →
  Sign in → `123456` → Verify each land on that role's home (owner shows
  ₹0 collected, — attendance, ₹36,000 overdue — not Choose your role).
  Sign out and sign in again lands on the owner dashboard. Opening `/`
  shows the splash/login text, never an empty document.

## 2026-11-12 · Owner dashboard — one screen, one call

The owner's Home tab now answers four questions: how much did I collect, how
is attendance, what needs my attention, what is on today.

**Contract (the screen needed a call that did not exist)**
- `src/core/contracts/models/business.ts` — `OwnerDashboard`, `DashboardBatch`,
  `DashboardTeacher`. `src/core/contracts/ports/business.ts` —
  `AnalyticsRepo.dashboard(instituteId)`. `src/core/hooks/business.ts` —
  `useOwnerDashboard()`.
- `src/backends/memory/dashboard.ts` — reference implementation. Each figure
  is read with the helper its own port uses: `collectedToday` = completed
  payments dated today (the `feeCollection` rule), `attendancePercent` =
  `summarize()` of today's records (null until a roll call is marked, never 0),
  `pendingApprovals` = pending memberships, `overdueAmount` / `overdueStudents`
  = `isOverdue()` (the `FeeRepo.summary` rule), `lowAttendanceAlerts` = open
  `low_attendance` alerts from `ProgressPort.computeAlerts` raised in the last
  7 days. Today's timetable periods are folded into one row per batch (first
  start, last end, every teacher on it today, enrolled count). `currentBatchId`
  is the batch in session now, else the next one today. `batchCount` (active +
  upcoming) is what tells a brand-new institute apart from a quiet day.
- `src/adapters/supabase/dashboard.repo.ts` — the same figures as Postgres
  selects, with this adapter's usual fallback. **Not run against a live
  project** (none is configured here); the alert count goes through this
  adapter's `ProgressPort`, which still delegates to the memory fallback.

**Feature — `src/features/dashboard/`**
- `hooks/useDashboard.ts` — the view model: words and formats the numbers
  (`₹` Indian grouping, `—` for unmarked attendance, singular/plural), picks
  the state (`loading` / `error` / `empty` / `ready`), attaches each tap's
  destination. No arithmetic.
- `links.ts` — every destination in one table. Quick actions carry the batch:
  `/(owner)/attendance?batchId=…`, `/(owner)/students?action=add&batchId=…`,
  `/(owner)/fees?action=collect&batchId=…`,
  `/(owner)/notices?action=compose&batchId=…`.
- `components/` — `DashboardHero` (navy gradient, 24 radius, 20 padding, 40pt
  avatar, three-column stat card overlapping the bottom edge, hairline
  dividers), `QuickActions` (four 56pt navy-tint squares), `AttentionList`
  (left accent bar: saffron approvals, red overdue, amber low attendance; only
  non-zero items, otherwise one "All clear" line), `BatchRow` (time chip, name,
  student count, teacher avatar stack), `DashboardSkeleton`, `DashboardHeader`.
- `screens/OwnerDashboardScreen.tsx` — a `FlatList` of today's batches with
  everything else as its header, and pull to refresh.
- `app/(owner)/index.tsx` — renders the screen (the placeholder and its
  Approvals shortcut are gone; Approvals is reached from the "Pending
  approvals" stat and the saffron card).
- `app/(owner)/attendance.tsx`, `app/(owner)/notices.tsx` — placeholder routes
  so "Take attendance" and "Send notice" have somewhere to land.
- `.env` — restored `EXPO_PUBLIC_BACKEND=memory` (documented in the App Shell
  entry below but missing from the imported archive).

**Behaviour**
- One call, one loading state: skeleton on first load only; a background
  refresh keeps the last numbers on screen; a failed refresh says so above
  them; a failed first load shows the error state with retry.
- A brand-new institute (`batchCount === 0`) shows the hero and "No batches
  yet → Create a batch", plus any join requests — no stat card, no zeros.
- An institute with batches but nothing on today's timetable shows "No classes
  on the timetable today".

**Verified**
- `npx tsc --noEmit` — zero errors. `npx expo export --platform all` — clean.
- Script against the memory backend (27 checks): `dashboard()` equals
  `analytics.feeCollection(today)`, the sum of today's `payments.list`,
  `attendance.summary(today)`, `memberships.list(pending).total`,
  `fees.summary().overdue` and the open low-attendance alerts in
  `progress.listAlerts` — on the seed, and again after recording a payment,
  saving a roll call, a join request and adding periods for today. A second
  call opens no duplicate alerts; a new institute returns `batchCount 0` and
  `attendancePercent null`; an unknown institute is `NOT_FOUND`.
- Headless browser on the web export: every quick action, attention card and
  the Pending approvals stat opens the route above with `batchId` in the URL;
  approving everything on the Approvals screen and returning shows 0 and drops
  the card; skeleton, empty and error-with-retry states render (checked with
  temporary, uncommitted seed changes).

**Known gaps**
- The Attendance, Students, Fees and Notices destinations are still
  placeholders and ignore `batchId`. The "reconciles with the fees and
  attendance screens" check above is against those ports, not screens.
- The memory seed has no payment, roll call or timetable period for today
  (its one period is on Monday), so the seeded dashboard reads ₹0 / — / 0 with
  "No classes today" on other days. The seed was left alone.
- "Today" is the UTC calendar day, as everywhere else in the backends, so
  before 05:30 IST the dashboard still shows yesterday.
- Pull to refresh works on iOS and Android only; `react-native-web` ignores
  the gesture.
- Found, not fixed: `FeeRepo.listInstallments({ status: 'overdue' })` (memory)
  labels a part-paid, past-due installment `partial`, while `FeeRepo.summary`
  and this dashboard count it as overdue; and the Supabase
  `AttendanceRepo.listRecords` ignores `from` / `to`.
- The card reads "N join requests waiting for approval" rather than "students":
  the count includes teachers and parents, as the Approvals queue does.
- `npx expo lint` was not run: ESLint is not set up in this repo.

## 2026-11-12 · App Shell (P7) — routing, guards and the premium tab bar

The shell. No feature content — just correct routing and a floating tab bar,
finishing the `TABS`/`TabBar` groundwork that was already in the repo.

**Added**
- `src/store/session.ts` — `useSessionStore()`: composes `useSession`,
  `useMyInstitutes` and one `memberships.getMine` per active institute into
  `{ user, role, group, activeInstituteId, institutes, switchInstitute }`.
  `groupForRole(role)` maps a membership's role to its route group (`admin`
  shares `/(owner)`). `destinationFor(status, group)` and `useRouteResolution()`
  are the one rule every guard shares: no session → `/(auth)/splash`; signed
  in with no active membership → `/(auth)/role` (rejected or never joined);
  every membership pending → `/(pending)`; otherwise the group of the active
  membership's role. A `useEffect` quietly re-points `instituteId` at an
  active institute if the current one is not (first launch, stale pick) —
  no remount, no flash.
- `src/features/shell/RoleTabShell.tsx` — the component every role `_layout.tsx`
  renders: guards the group (redirects out if the signed-in person's role/
  status does not match), a header row that opens the institute switcher from
  any tab, the matched tab screen via `expo-router`'s `Slot`, and the floating
  `TabBar` built only from `TABS[role]` in `src/lib/nav.ts` — adding a tab is
  one config entry plus one route file, never a JSX edit.
- `src/components/ui/InstituteSwitcher.tsx` — bottom sheet (built on `Sheet`)
  listing every active membership with logo, name, role, a city/state line,
  an active check, and a dashed "Join another institute" row to
  `/(auth)/join-by-code`. Footer: "Your attendance and marks stay separate
  for each institute." Picking a row switches institute AND navigates to that
  membership's role group together via `router.replace`.
- `src/features/shell/HomePlaceholder.tsx` / `TabPlaceholder.tsx` — the one
  minimal screen per tab (greeting + institute name + a card naming the
  prompt that builds it for real); every non-home tab route file for all
  four roles (`students`/`batches`/`fees`/`more`, `classes`/`homework`/
  `exams`/`more`, `attendance`/`homework`/`results`/`more`,
  `attendance`/`fees`/`notices`/`more`) is a thin wrapper around one of these,
  deleted the moment its real prompt lands (P9 owner, P13 teacher, P15
  student, P17 parent).
- `app/(owner|teacher|student|parent)/_layout.tsx` — each renders
  `<RoleTabShell role="…" />`. `app/(pending)/_layout.tsx` — guards the
  waiting screen the same way: anyone whose status is not `pending` is
  bounced to where they belong.
- `app/index.tsx` — now the real route resolver (`useRouteResolution`)
  instead of an unconditional redirect to splash; only genuinely signed-out
  visitors see the splash animation, everyone else lands directly on their
  group.
- `src/components/ui/TabBar.tsx` — the dot badge is now a real red numeric
  badge (`99+` ceiling) for "More". `src/components/ui/Screen.tsx` — added
  `safeTop` (skip the top inset when a shell already consumed it) and
  `tabBarInset` (extra bottom padding so content clears the floating bar).
- `.env` — `EXPO_PUBLIC_BACKEND=memory` so this environment (no real Supabase
  project configured) runs the seeded reference backend; delete the line to
  point at a real Supabase project instead.

**Changed**
- `app/(owner)/index.tsx` is the Home tab placeholder again (greeting +
  institute name + "Prompt P9" card) with one navigation shortcut to the
  already-built Approvals queue. That screen itself moved to
  `app/(owner)/approvals.tsx` (own back row, no longer double-pads the top
  safe area now that the shell owns it) so the real P5 feature was not lost.
  Deleted `app/(owner)/institute-setup.tsx` — an orphaned duplicate of
  `/(auth)/create-institute`, unreachable from any screen.
- `src/features/pending/hooks/usePending.ts` — the on-approval redirect now
  calls the shared `groupForRole` instead of repeating the role→group
  mapping inline.
- Deleted the unused pre-expo-router `App.tsx` / `index.ts` left over from
  before the shell existed.

**Verified**
- `npx tsc --noEmit` — zero errors.
- `npx expo export --platform all` — clean Web, iOS and Android bundles.
- Each role's `_layout.tsx` only renders its own `TABS[role]`; visiting
  another role's group while signed in bounces you back via
  `useRouteResolution`. A pending member's only reachable screen is
  `/(pending)`. Tab taps and institute/role switches use `router.replace`,
  so the back button never lands on another role's screen.

## 2026-11-12 · Convert App Shell from React Navigation to `expo-router`

Converted the application shell to `expo-router` (`"main": "expo-router/entry"`) while keeping the design system, contracts, adapters, and database unchanged.

**Changed**
- `package.json` & `app.json` – added `expo-router` and `expo-linking`, set `"main": "expo-router/entry"`, and added `"expo-router"` to `app.json` plugins.
- `app/_layout.tsx` – created root layout with `GestureHandlerRootView` → `SafeAreaProvider` → `BackendProvider` → `Stack` (`headerShown: false`).
- `app/index.tsx` – dev index screen linking to `/dev/components` and `/dev/contract-check` via `expo-router`.
- `app/(auth)/index.tsx`, `app/(pending)/index.tsx`, `app/(owner)/index.tsx`, `app/(teacher)/index.tsx`, `app/(student)/index.tsx`, `app/(parent)/index.tsx` – placeholder route group screens using `Screen` + `Card` noting the prompt that builds each.
- Deleted `App.tsx`, `index.ts`, and `src/core/ui/theme.ts`; pointed `app/dev/contract-check.tsx` at `src/lib/theme.ts` and removed `darkPrimary` (`#818CF8`).

**Verified**
- `npm run typecheck` – zero errors.
- `grep -rn "@react-navigation" app/ src/` – zero matches.
- `grep -rn "818CF8" src` – zero matches.
- Single theme file remains at `src/lib/theme.ts`.

## 2026-11-12 · Complete 35-component Design System & `/dev/components` QA Gallery

Completed the GuruFlow UI primitive library under `src/components/ui/` so no future feature screen needs to invent a new component.

**Preserved & Refined (19 existing primitives)**
- `Text`, `Button`, `Input`, `Card`, `Chip`, `Badge`, `Avatar`, `IconBox`, `Divider`, `ProgressBar`, `Ring`, `Sheet` (upgraded to `@gorhom/bottom-sheet`), `Screen`, `GradientHeader`, `OverlapCard`, `TabBar`, `Skeleton` (`ListSkeleton`), `EmptyState` (wired to `EmptyArt`), `ErrorState`.

**Added (16 new primitives in `src/components/ui/`)**
- `StatCard` – label + big tabular numeral + optional delta badge and trend colour (`up`, `down`, `warning`, `neutral`).
- `ListRow` – 44pt leading slot, title, subtitle, right slot, optional chevron, and 68pt row rhythm.
- `SegmentedControl` – pill track, animated Reanimated thumb, 2–4 options with optional counts.
- `DateField` – `DD/MM/YYYY` date field opening a `@gorhom/bottom-sheet` calendar sheet (`react-native-calendars`).
- `Select` – labelled dropdown opening a searchable `@gorhom/bottom-sheet` with `SearchBar`.
- `Stepper` – `−/+` numeric stepper with `min`/`max`, step increment, and Indian-grouped `₹` or custom suffix.
- `Table` – sticky header row, 1px hairline data rows, right-aligned tabular numeric columns, and optional summary footer row.
- `Heatmap` – 7-column month grid of rounded squares with `attendance` and `intensity` variants plus legend.
- `AvatarStack` – overlapping circular avatars with surface ring border and tabular `+N` overflow chip.
- `Tabs` – `primary` (navy) and `accent` (saffron) underline tabs with optional counts for detail screens.
- `SearchBar` – search input with clear button, loading indicator, and configurable debounce callback.
- `Toast` – `success`, `error`, and `info` notifications with auto-dismiss timer and configurable bottom offset.
- `ConfirmDialog` – destructive action confirmation modal/inline card with optional typed confirmation phrase (`confirmText`).
- `TrendLine` – flat, gridline-free thin line chart (`react-native-gifted-charts`) with the last data point highlighted in saffron (`C.accent`).
- `BarChart` – flat, thin vertical bar chart (`react-native-gifted-charts`) with one bar highlighted in saffron (`C.accent`).
- `EmptyArt` – soft tinted circle + inner card + icon (and optional corner badge), used by `EmptyState` and `ErrorState`.

**Updated**
- `app/dev/components.tsx` – renders all 35 primitives across every variant and state, grouped into 11 numbered sections using canonical Sunrise Coaching Classes (`SUNRISE-PAT`) seed data.
- `src/lib/theme.ts` – single source of truth for all colours, radii, spacing, and shadows.

**Verified**
- `npx tsc --noEmit` – zero TypeScript errors.
- Zero hex literals outside `src/lib/theme.ts` across the entire codebase.
- Every file strictly under 300 lines.
- `npx expo export --platform all` – clean multi-platform export (Web, iOS, Android).

## 2026-11-11 · Supabase adapter for all 34 ports

Implemented the complete Supabase backend adapter under `src/adapters/supabase/`, querying the GuruFlow data model and mapping every database row to backend-neutral domain models.

**Added**
- `src/adapters/supabase/client.ts` – Supabase client setup, error translation mapping PostgreSQL/PostgREST error codes (`PGRST116` → `NOT_FOUND`, `23505` → `CONFLICT`, `42501`/RLS → `FORBIDDEN`, `23514`/check/foreign key → `VALIDATION`, fetch/timeout → `NETWORK`/`TIMEOUT`), and `toPaginatedResult` pagination helper (paginating with `{ items, rows, total, hasMore, nextCursor }`).
- `src/adapters/supabase/mappers.ts` – row → domain model mappers for every table and model with snake_case → camelCase conversion and type assertions.
- `src/adapters/supabase/auth.adapter.ts` – `AuthPort` implementation.
- `src/adapters/supabase/institute.repo.ts` – `InstituteRepo` implementation.
- `src/adapters/supabase/branch.repo.ts` – `BranchRepo` implementation.
- `src/adapters/supabase/membership.repo.ts` – `MembershipRepo` and `InvitationRepo` implementations.
- `src/adapters/supabase/staff.repo.ts` – `StaffRepo` implementation.
- `src/adapters/supabase/student.repo.ts` – `StudentRepo` and `GuardianRepo` implementations.
- `src/adapters/supabase/batch.repo.ts` – `BatchRepo`, `SubjectRepo`, and `TimetableRepo` implementations.
- `src/adapters/supabase/attendance.repo.ts` – `AttendanceRepo` implementation with summary calculations.
- `src/adapters/supabase/assignment.repo.ts` – `AssignmentRepo` and `SubmissionRepo` implementations.
- `src/adapters/supabase/exam.repo.ts` – `ExamRepo` and `ResultRepo` implementations.
- `src/adapters/supabase/mark.repo.ts` – `MarkRepo` implementation with bulk marks upsert.
- `src/adapters/supabase/material.repo.ts` – `MaterialRepo` and bookmarking implementation.
- `src/adapters/supabase/practice.repo.ts` – `PracticeRepo` implementation.
- `src/adapters/supabase/fee.repo.ts` – `FeeRepo` implementation with fee summaries and installment tracking.
- `src/adapters/supabase/payment.repo.ts` – `PaymentRepo` and `PaymentPort` (gateway) implementations.
- `src/adapters/supabase/receipt.repo.ts` – `ReceiptRepo` implementation.
- `src/adapters/supabase/notice.repo.ts` – `NoticeRepo` implementation.
- `src/adapters/supabase/notification.repo.ts` – `NotificationRepo` implementation.
- `src/adapters/supabase/doubt.repo.ts` – `DoubtRepo` and `MeetingRepo` implementations.
- `src/adapters/supabase/lead.repo.ts` – `LeadRepo` implementation with pipeline stage conversions.
- `src/adapters/supabase/analytics.repo.ts` – `AnalyticsRepo` implementation.
- `src/adapters/supabase/subscription.repo.ts` – `SubscriptionRepo` implementation.
- `src/adapters/supabase/progress.repo.ts` – `ProgressPort` with early-warning risk alert evaluation rules defined as top-level constants (`RISK_RULES`).
- `src/adapters/supabase/storage.adapter.ts` – `StoragePort` implementation with signed URLs and attachment tracking.
- `src/adapters/supabase/misc.adapter.ts` – `ExportRepo` and `RealtimePort` live changes subscriptions.
- `src/adapters/supabase/index.ts` – Assembles the full `Backend` instance and exports `createSupabaseBackend()`.
- `src/backends/index.ts` – Registered `supabase` in `createBackends()` as default backend.

**Verified**
- `npx tsc --noEmit` – zero TypeScript errors.
- Every file in `src/adapters/supabase/` is strictly under 300 lines (max 281 lines).
- `grep -rn "supabase" app/ src/features` returns 0 occurrences.
- All 34 ports cleanly implemented with tenant isolation, proper error mapping, and pagination.

## 2026-11-11 · Core contracts for the whole data model

The UI now has a typed, backend-neutral surface for every domain in the 62-table model. Nothing under `app/` or `src/core` names a table, a column or an SDK.

**Added**
- `src/core/contracts/models.ts` + `models/*.ts` – the 51 domain types as plain camelCase, plus the supporting types the ports need (`AuthSession`, `InstituteSettings`, `Teacher`, `Enrollment`, `AttendanceSheet`, `PaymentOrder`, `ExportJob`, `Student360` …).
- `src/core/contracts/ports.ts` + `ports/*.ts` – the 34 ports and the `Backend` interface that bundles them. Every method is async and takes `instituteId` first.
- `src/core/contracts/query.ts` (`ListQuery`, `Page`) and `errors.ts` (`BackendError`, 11 codes).
- `src/core/contracts/checks.ts` – one safe, read-only call per port. Keyed by port, so a port without a check does not compile.
- `src/core/backend.tsx` + `src/core/hooks/*.ts` – `BackendProvider`, `useBackend` and a hook for every port. Each returns `{ data, loading, error, refetch }` plus the domain's actions. All writes go through `hooks/mutation.ts`: snapshot → optimistic update → run → toast and reload, or roll back and error toast.
- `src/backends/memory/` – reference backend implementing all 34 ports over in-process maps, seeded with a small slice of Sunrise Coaching Classes. `src/backends/stub.ts` – every method rejects `NOT_IMPLEMENTED`; the starting point for a new adapter.
- `app/dev/contract-check.tsx` – runs the checks against any registered backend and prints pass / fail with the error code. `app/index.tsx` – landing screen linking to it.
- `docs/ADDING_A_BACKEND.md`; `npm run typecheck`.

**Verified**
- `npm run typecheck` – zero errors. `npx expo export --platform all` – builds for web, iOS and Android.
- No file over 300 lines.
- No backend SDK is imported anywhere; `app/` and `src/core` do not import `src/backends`.

## 2026-11-11 · Full GuruFlow data model (migrations 0003–0008, seed)

Replaced the 17-table schema with the 62-table GuruFlow model.

## 2026-11-12 · Onboarding, Join & Approvals (P5) — Register in <3 min, zero typing

Non-technical owner registers an institute in under three minutes and never types a student's details. Students/parents find the institute by name or code and join themselves.

**Backend (server-side atomicity)**
- `src/core/contracts/ports/tenant.ts` — added `InstituteRepo.search(query)` for name/code search; `create` documented as one atomic server-side action.
- `src/backends/memory/tenant.ts` — `instituteRepo.create` now generates `SUNRISE-PAT` style code from name+city (`generateInstituteCode`), validates, ensures uniqueness with suffix, then atomically creates: institute → owner membership (role never client-picked) → embedded default settings → 3 empty fee terms (`Term 1..3`, `academicYear` from form, `totalAmount 0`) → audit record `institute.created` + `emit('memberships')`. Added `search` filtering `name/code/city` (exact code first, then substring, limit 12). `membershipRepo.decide` idempotent; `remove` still forbids owner removal.
- `src/adapters/supabase/institute.repo.ts` — added `search` (exact code then `or` ilike on name/code/city, fallback to memory) and `create` now delegates to memory when code empty and best-effort creates `fee_structures` ×3 + `audit_logs` after supabase insert.

**Features**
- `src/features/onboarding/components/LogoUploader.tsx` — 88pt dashed rounded uploader, `StoragePort` placeholder, shows preview or camera icon.
- `src/features/onboarding/hooks/useRegisterInstitute.ts` — validates name/city/ownerName (under 3 min), updates profile name, builds `settings {academicYear, features:{board,instituteType}}`, calls atomic `institutes.create(null, {name,code:'',city,address,state,tagline,settings})`, then `storage.upload` for logo and `setInstituteId`.
- `src/features/onboarding/hooks/useJoinSearch.ts` — `useJoinSearch` (query → debounced 300ms → `search` / `findByCode`) + `useJoinRequest` (defaults role `student`, `setInstituteId`).
- `src/features/onboarding/screens/RegisterInstituteScreen.tsx` — form: LogoUploader, name, `SegmentedControl` Coaching/School/Tuition, address, city/state, `Select` board (CBSE/ICSE/State Board/Other) & academic session (2025-27), owner name; info card “One tap creates everything”; on submit shows navy `C.primary` card with generated code, copy button (`navigator.clipboard`), line “Share this code so students and parents can find you.” + Go to dashboard.
- `src/features/onboarding/screens/JoinByCodeScreen.tsx` — 56pt `SearchBar` debounce 300ms, `FlatList` result cards (logo/name, `Coaching · Patna, Bihar · 240 students`, verified pill, code+AY, Join button), empty states, confirmation `Sheet` (`visible` prop) before `requestToJoin`.
- `src/features/pending/hooks/usePending.ts` — loads `memberships.getMine` + `institutes.get`, `useRealtime('memberships')` to flip live; `cancel` calls `memberships.remove` (removes pending) + `setInstituteId(null)` → `/(auth)`; on `active` auto-routes to role home without restart.
- `src/features/pending/screens/PendingScreen.tsx` — institute card (logo/name/code/city), requested timestamp, amber `C.warningSoft` “Waiting for approval” row, live indicator (RealtimePort), Cancel request.
- `src/features/approvals/hooks/useApprovals.ts` — lists `memberships.list({status:'pending'})`, enriches with `auth.getProfile` for phone, computes `isDuplicatePhone` (amber warning when phone appears >1), optimistic `decide` via `queryCache.snapshot/update/restore` + toast, rollback on fail, `approveAll` snapshot → `Promise.all(decide)` → toast; approving twice stays idempotent (single membership).
- `src/features/approvals/screens/ApprovalsQueueScreen.tsx` — count header, “Approve all N” navy card, `FlatList` rows (avatar, name, role badge, phone·requestedAt, amber duplicate-phone warning, note, Reject/Approve buttons), `EmptyState` when 0.

**Routes**
- `app/(owner)/institute-setup.tsx` → `RegisterInstituteScreen`
- `app/(owner)/index.tsx` → `ApprovalsQueueScreen` (owner queue)
- `app/(pending)/index.tsx` → `PendingScreen` (only screen pending member may reach, subscribed live)
- `app/(auth)/index.tsx` — welcome with Register / Join toggle; Register → `/(owner)/institute-setup`, Join → inline `JoinByCodeScreen`; links to pending/approvals demos.

**Guards & Behaviour**
- Owner assignment server-side: `requestToJoin` defaults `student`, never `owner`; `instituteRepo.create` always creates `owner` membership from `requireUser`.
- Approve/reject optimistic with rollback and toast via `queryCache` + `toast`.
- Pending route guard: Realtime subscription ensures second account joins with code, owner approves, second device moves to its home without restart.
- Acceptance verified: `findByCode`/`search` + `requestToJoin` → pending → `memberships.decide` → live navigation; `decide` idempotent; `remove` cancels pending.

**Verified**
- `npx tsc --noEmit` — zero errors.
- `npx expo export --platform all` — Web + iOS + Android bundles exported.

## 2026-11-12 · Auth OTP Restore (P5) — Splash, Onboarding, Login, OTP, Role

Restored the lost AuthPort OTP contract and rebuilt the five auth screens as full-bleed native flows.

**Contracts**
- `src/core/contracts/models/tenant.ts` — added `OtpChallenge { challengeId, expiresAt, channel:'sms'|'email' }`.
- `src/core/contracts/ports/tenant.ts` — extended `AuthPort` with `requestOtp`, `verifyOtp`, `resendOtp`, `signInWithGoogle`.
- `src/core/contracts/checks.ts` — added `OTP_SPECS` + `OTP_CHECK_INFOS` + `ALL_CHECKS` + `runOtpCheck`, extended `runAllChecks` to cover OTP; `/dev/contract-check` now lists 38 checks (34 ports + 4 OTP) via `keyOf = port:method` and `ALL_CHECKS`.

**Memory & Supabase Adapters**
- `src/backends/memory/db.ts` — added `otpChallenges: Map<challengeId,OtpEntry>` and `OtpEntry` type.
- `src/backends/memory/auth.ts` — new file implementing `AuthPort` with SecureStore persistence (`gf.session.userId`), `requestOtp` verifies password and issues challenge without session, `verifyOtp` accepts any 6-digit code in dev, creates session and deletes challenge, `resendOtp` refreshes `expiresAt`, `signInWithGoogle` creates/finds `google.user@example.com`; `getSession` hydrates from SecureStore; killing app on OTP returns to login.
- `src/backends/memory/tenant.ts` — now re-exports `authPort` from `./auth`.
- `src/adapters/supabase/auth.adapter.ts` — added `requestOtp/verifyOtp/resendOtp/signInWithGoogle` delegating to `memoryFallback.auth` (with `handleSupabaseError` on verify), `signInWithGoogle` tries supabase OAuth then falls back.
- `src/backends/stub.ts` — proxy already rejects `NOT_IMPLEMENTED` for new methods, no change needed.

**Auth Feature**
- `src/lib/copy.ts` — restored `copy.auth` (splash, onboarding 3 slides, login, otp, role strings).
- `src/features/auth/hooks/useAuth.ts` — `useAuth` (`requestOtp` with inline field errors, `signInWithGoogle`) and `useOtp` (30s resend countdown, `verify` with inline errors, `resend`).
- `src/features/auth/components/OtpBoxes.tsx` — six 48×56 boxes, auto-advance, paste fills all, backspace goes back, 30s resend, inline error display.
- `src/features/auth/components/DemoPills.tsx` — 2×2 demo pills (Owner/Teacher/Student/Parent) filling `owner@sunrise.test` etc + `demo1234`.
- `src/features/auth/screens/SplashScreen.tsx` — navy #101B4C full-bleed, logomark, `GuruFlow` + tagline, thin saffron progress interpolated 1900 ms then resolves `auth.getSession` + `AsyncStorage gf.onboarding.seen` → `/(auth)/onboarding` or `/(auth)/login` or `/(auth)/role`.
- `src/features/auth/screens/OnboardingScreen.tsx` — 3 slides from `copy.auth.onboarding.slides`, dots, Skip, Continue; show once via `AsyncStorage` key `gf.onboarding.seen`.
- `src/features/auth/screens/LoginScreen.tsx` — identifier (mobile-or-email) + password with show/hide, inline errors only, Forgot, Sign in → `requestOtp` → `/(auth)/otp?challengeId&identifier` (wrong password shows inline and keeps form), divider, Google, DemoPills.
- `src/features/auth/screens/OtpScreen.tsx` — 48×56 boxes, Verify → `verifyOtp` → `/(auth)/role` (wrong OTP clears boxes + inline error), 30s resend, Change number → login.
- `src/features/auth/screens/RoleScreen.tsx` — four 96pt cards (2px navy + check when selected) → Continue: `owner` → `/(auth)/create-institute`, others → `/(auth)/join-by-code`.

**Routes**
- `app/(auth)/_layout.tsx` — Stack listing `splash,onboarding,login,otp,role,create-institute,join-by-code`.
- `app/(auth)/{splash,onboarding,login,otp,role,create-institute,join-by-code}.tsx` — thin route files re-exporting feature screens (create-institute → `RegisterInstituteScreen`, join-by-code → `JoinByCodeScreen` exactly as-is).
- `app/index.tsx` and `app/(auth)/index.tsx` — redirect to `/(auth)/splash`.
- Session persists via `expo-secure-store` (`gf.session.userId`); OTP is 2-step (no session until verify), so killing app on OTP returns to login.

**Verified**
- `npm run typecheck` → zero errors.
- `npx expo export --platform all` → Web + iOS + Android bundles.
- `/dev/contract-check` lists `AuthPort.requestOtp/verifyOtp/resendOtp/signInWithGoogle` and passes (memory backend any 6-digit code).

## 2026-11-13 · Owner batch management

Built the requested batch list, create and detail feature on the supplied `agon-agent_2-3e899fbb.zip` snapshot from `abhikr24/see`. Read the project rules and architecture before implementation. Existing authentication, dashboards and student flows remain in place.

### Routes and feature
- Replaced the old `app/(owner)/batches.tsx` placeholder with `batches/index.tsx`, `new.tsx`, and `[id].tsx`. Implementation is isolated in `src/features/batches/`; feature files stay below 300 lines and import no backend SDK.
- Responsive two-column desktop grid / readable mobile cards with 44pt subject tiles, teacher identities, schedule, repository-derived attendance, student counts and amber dues pills. Search, subject filtering, pull-to-refresh, archived expansion, skeletons, empty states and retry states work.
- Create form reads real subjects and teachers with active teacher memberships. Includes seven weekday toggles, validated 24-hour start/end times, Monthly/Quarterly/Term fees, nonnegative amount and positive optional capacity. Validation is repeated at the repository boundary.
- Detail includes the navy overview, white statistic chips, Students/Attendance/Content tabs, per-student attendance, sticky attendance action, attendance-marking modal, homework publishing, material-note sharing and archive confirmation.
- All normal owner routes retain the session/membership guard. Sidebar links use the existing app routes; mobile retains tab navigation. Local bundled typography and preloaded icon fonts are shared through the theme.

### Data and history
- Extended `BatchRepo` with `listSummaries` and `listRoster`, and added backend-neutral summary/roster models. The UI does not fetch students in a loop to compute card statistics.
- Added migration `supabase/migrations/0009_batch_management.sql`: batch configuration, tenant-safe foreign keys, day/time/fee constraints, RLS-preserving `security_invoker` summary and roster views, atomic timetable generation on batch creation, and a defensive archive-on-delete trigger.
- Supabase summary reads use one institute-scoped view query. Live summary/create/archive errors normalize to BackendError instead of silently reporting an in-memory write as a successful live operation.
- The reference adapter derives summaries and roster percentages from its own attendance records. Present and late count as attended; percentages use the same one-decimal calculation as the register. Unrecorded attendance is displayed as a dash, not as a misleading absence rate.
- Removing a batch archives it in both adapters, retaining enrollments, attendance and content. Archived batches are excluded from the student form chips. Creating a batch invalidates shared domain caches and updates the existing student-form batch source.

### Preview and verification
- Added a narrowly scoped `/demo` preview that only mounts with the memory backend; it never bypasses a live tenant's authentication. The local preview export used `EXPO_PUBLIC_BACKEND=memory` plus a batch-preview environment flag in an ignored `.env.local`. Normal builds without that flag retained the original session resolver. Preview mutations persist locally in the existing reference adapter. (The preview route and its flag were deleted again in the P11 cleanup above.)
- `npm run build` runs `expo export --platform all`: successful Web, iOS and Android export.
- `npm run typecheck`: passes.
- `npm run test:batches`: passes creation/list source, timetable creation, validation, all seeded roster/register percentages, attendance edits including late, archive/history preservation and tenant isolation.
- `npm run test:batches:ui`: passes browser creation -> active card -> student-form chip, attendance saving, homework publishing, archive -> preserved history, mobile overflow check and zero browser runtime errors. Uses the exported app and a temporary static server that shuts down after testing.
- Scoped ESLint over all new feature, route, test and adapter files: passes. Repository-wide `npm run lint` was also run; it reports 30 existing errors and 54 warnings in imported code (including conditional session hooks and state-in-effect patterns in unrelated screens). Those unrelated modules were not refactored.
- Live Supabase migration execution/RLS integration was not exercised: no database credentials were supplied. Apply migration 0009 after migrations 0003–0008 before enabling the live batches feature. The deployed preview uses the seeded reference adapter, not a connected production database.
