import type {
  AbsenceAlertResult,
  AttendanceRoll,
  AttendanceRollStudent,
  AttendanceSheet,
  ID,
} from '../../core/contracts/models';
import type { AttendanceRepo } from '../../core/contracts/ports';
import { emit, type Db } from './db';
import * as D from './defaults';
import { merge } from './store';

/** The institute's attendance-alert switch. Absent from settings means off. */
export function alertsEnabled(db: Db, instituteId: ID): boolean {
  const institute = db.institutes.get(instituteId, instituteId);
  return institute.settings.features?.attendanceAlerts === true;
}

function primaryGuardian(db: Db, instituteId: ID, studentId: ID) {
  const links = db.parentLinks
    .all(instituteId, { studentId })
    .sort((a, b) => Number(b.isPrimary) - Number(a.isPrimary));
  return links.map((link) => db.guardians.get(instituteId, link.guardianId));
}

function sheetOf(db: Db, instituteId: ID, sessionId: ID): AttendanceSheet {
  return {
    session: db.attendanceSessions.get(instituteId, sessionId),
    records: db.attendanceRecords.all(instituteId, { sessionId }),
  };
}

type RollPorts = Pick<AttendanceRepo, 'openRoll' | 'listSheets' | 'notifyAbsentParents'>;

/** The three roll-call reads/writes the Take Attendance screen is built on. */
export function attendanceRollPorts(db: Db): RollPorts {
  return {
    openRoll: async (instituteId, { batchId, date, period = 1, subjectId }) => {
      const batch = db.batches.get(instituteId, batchId);
      const dayOfWeek = new Date(`${date}T00:00:00Z`).getUTCDay();
      const firstPeriod = db.timetables
        .all(instituteId, { batchId, dayOfWeek })
        .sort((a, b) => a.startsAt.localeCompare(b.startsAt))[0];
      const existingSession = db.attendanceSessions.find(instituteId, { batchId, date, period }) ?? null;
      const subject = subjectId ?? existingSession?.subjectId ?? firstPeriod?.subjectId ?? batch.subjectId ?? null;
      const subjectRow = subject ? db.subjects.all(instituteId).find((row) => row.id === subject) : undefined;

      const students: AttendanceRollStudent[] = db.enrollments
        .all(instituteId, { batchId, status: 'active' })
        .map((enrolment) => {
          const student = db.students.get(instituteId, enrolment.studentId);
          const [guardian] = primaryGuardian(db, instituteId, student.id);
          return {
            studentId: student.id,
            fullName: student.fullName,
            photoUrl: student.photoUrl,
            rollNumber: enrolment.rollNumber,
            parentName: guardian?.fullName ?? null,
            parentPhone: guardian?.phone ?? student.phone ?? null,
          };
        })
        .sort((a, b) => (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999) || a.fullName.localeCompare(b.fullName));

      const roll: AttendanceRoll = {
        batchId,
        batchName: batch.name,
        subjectId: subjectRow?.id ?? null,
        subjectName: subjectRow?.name ?? null,
        date,
        period,
        students,
        existing: existingSession ? sheetOf(db, instituteId, existingSession.id) : null,
        alertsEnabled: alertsEnabled(db, instituteId),
      };
      return roll;
    },

    listSheets: async (instituteId, { date, batchId }) =>
      db.attendanceSessions
        .all(instituteId, batchId ? { date, batchId } : { date })
        .map((session) => sheetOf(db, instituteId, session.id)),

    notifyAbsentParents: async (instituteId, sessionId) => {
      const sheet = sheetOf(db, instituteId, sessionId);
      const result: AbsenceAlertResult = { sent: 0, alreadySent: 0, unreachable: 0, disabled: false };
      if (!alertsEnabled(db, instituteId)) return { ...result, disabled: true };
      const batch = db.batches.get(instituteId, sheet.session.batchId);

      for (const record of sheet.records.filter((row) => row.status === 'absent')) {
        const student = db.students.get(instituteId, record.studentId);
        const userIds = primaryGuardian(db, instituteId, student.id)
          .flatMap((guardian) => (guardian.membershipId ? db.memberships.all(instituteId, { id: guardian.membershipId }) : []))
          .filter((membership) => membership.status === 'active')
          .map((membership) => membership.userId);
        if (userIds.length === 0) {
          result.unreachable += 1;
          continue;
        }
        for (const userId of [...new Set(userIds)]) {
          const duplicate = db.notifications
            .all(instituteId, { userId, type: 'attendance_absent' })
            .some((row) => row.data.sessionId === sessionId && row.data.studentId === student.id);
          if (duplicate) {
            result.alreadySent += 1;
            continue;
          }
          const sent = db.notifications.insert(
            instituteId,
            merge(D.notification(), {
              userId,
              type: 'attendance_absent',
              title: `${student.fullName} was absent today`,
              body: `${student.fullName} was marked absent in ${batch.name} on ${sheet.session.date}.`,
              data: { screen: 'attendance', sessionId, studentId: student.id, batchId: batch.id, date: sheet.session.date },
            }),
          );
          emit(db, instituteId, 'notifications', 'created', sent.id);
          result.sent += 1;
        }
      }
      return result;
    },
  };
}
