import type { ID } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { nowIso } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INSTITUTE = sid(1);
const OWNER = sid(2);
const BRANCH = sid(8);

/**
 * One parent per Class 10-A student (roll → parent), each with an active
 * parent login so an absence can land in their inbox. Aarav's mother is the
 * existing sample parent, Anita Sharma (user 37). Ids: users 11000+roll,
 * memberships 11100+roll, profiles 11200+roll, guardians 11300+roll, links 11400+roll.
 */
const PARENTS: [number, string, 'father' | 'mother', string][] = [
  [14, 'Anita Sharma', 'mother', '9801000014'], [15, 'Rina Bose', 'mother', '9801000015'],
  [16, 'Harpreet Singh', 'father', '9801000016'], [17, 'Neha Gupta', 'mother', '9801000017'],
  [18, 'Suresh Mehta', 'father', '9801000018'], [19, 'Farah Ahmed', 'mother', '9801000019'],
  [20, 'Manjeet Singh', 'father', '9801000020'], [21, 'Hetal Patel', 'mother', '9801000021'],
  [22, 'Rajiv Sethi', 'father', '9801000022'], [23, 'Lakshmi Menon', 'mother', '9801000023'],
  [24, 'Bikash Das', 'father', '9801000024'], [25, 'Nasreen Khan', 'mother', '9801000025'],
];

const slug = (name: string): string => name.toLowerCase().replace(/[^a-z]+/g, '.');

export function seedGuardians(db: Db): void {
  const at = nowIso();
  const row = (n: number) => ({ id: sid(n), instituteId: INSTITUTE, createdAt: at, updatedAt: at });
  for (const [roll, fullName, relation, phone] of PARENTS) {
    const existingParent = roll === 14;
    const userId = existingParent ? sid(37) : sid(11000 + roll);
    const membershipId = existingParent ? sid(237) : sid(11100 + roll);
    if (!existingParent) {
      db.profiles.set(userId, {
        ...D.profile(), id: sid(11200 + roll), userId, fullName, phone,
        email: `${slug(fullName)}@sunrise.test`, createdAt: at, updatedAt: at,
      });
      db.memberships.put({
        ...row(11100 + roll), userId, branchId: BRANCH, role: 'parent', status: 'active',
        permissions: [], requestNote: null, requestedAt: at, decidedBy: OWNER, decidedAt: at,
      });
    }
    db.guardians.put({ ...D.guardian(), ...row(11300 + roll), membershipId, fullName, relation, phone });
    db.parentLinks.put({ ...row(11400 + roll), studentId: sid(roll), guardianId: sid(11300 + roll), isPrimary: true });
  }
}

/** Tops up a snapshot saved before parents were seeded, so absence alerts have someone to reach. */
export function ensureGuardians(db: Db): void {
  const institute = db.institutes.everything().find((row) => row.id === INSTITUTE);
  if (!institute) return;
  if (institute.settings.features?.attendanceAlerts === undefined) {
    db.institutes.put({
      ...institute,
      settings: { ...institute.settings, features: { ...institute.settings.features, attendanceAlerts: true } },
    });
  }
  if (db.parentLinks.all(INSTITUTE, { studentId: sid(14) }).length === 0) seedGuardians(db);
}
