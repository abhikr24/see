import React from 'react';
import { FlatList, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { BatchSummary } from '@/core/contracts/models';
import { useDaySheets } from '@/core/hooks/academics';
import { useDomainQuery } from '@/core/hooks/domain';
import { C, LAYOUT, R } from '@/lib/theme';
import { takeAttendanceHref } from './links';
import { countMarks, marksFrom, todayIso } from './model';

/**
 * Attendance landing (no batch chosen yet): every active batch with today's
 * state — "Not marked" or "11/12 present" — one tap from its register.
 */
export function PickBatchScreen() {
  const today = todayIso();
  const batches = useDomainQuery<BatchSummary[]>('batches', ['summaries'], (b, i) => b.batches.listSummaries(i));
  const sheets = useDaySheets(today);
  const active = (batches.data ?? []).filter((b) => b.status === 'active' || b.status === 'upcoming');

  const stateOf = (batchId: string): string | null => {
    const sheet = sheets.data?.find((s) => s.session.batchId === batchId);
    if (!sheet) return null;
    const students = sheet.records.map((r) => ({ studentId: r.studentId, fullName: '', photoUrl: null, rollNumber: null, parentName: null, parentPhone: null }));
    const counts = countMarks(students, marksFrom(students, sheet));
    return `${counts.present}/${counts.total} present`;
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 12, gap: 4 }}>
        <Text variant="h1">Attendance</Text>
        <Text variant="caption" c={C.secondary}>
          Pick a batch to take today’s roll call
        </Text>
      </View>
      {batches.loading && !batches.data ? (
        <View style={{ paddingHorizontal: LAYOUT.margin }}>
          <ListSkeleton rows={4} h={72} />
        </View>
      ) : batches.error && !batches.data ? (
        <ErrorState title="Could not load batches" message={batches.error.message} onRetry={() => void batches.refetch()} />
      ) : (
        <FlatList
          data={active}
          keyExtractor={(b) => b.id}
          refreshing={batches.loading}
          onRefresh={() => {
            void batches.refetch();
            void sheets.refetch();
          }}
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 140, gap: 10 }}
          ListEmptyComponent={
            <EmptyState
              icon="albums-outline"
              title="No batches yet"
              text="Create a batch first, then take its attendance here."
              actionLabel="Create a batch"
              onAction={() => router.push('/(owner)/batches/new' as never)}
            />
          }
          renderItem={({ item }) => {
            const marked = stateOf(item.id);
            return (
              <Pressable
                accessibilityRole="button"
                onPress={() => router.push(takeAttendanceHref({ batchId: item.id, date: today }) as never)}
                style={({ pressed }) => ({
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 12,
                  padding: 16,
                  borderRadius: R.card,
                  backgroundColor: pressed ? C.track : C.surface,
                  borderWidth: 1,
                  borderColor: C.hairline,
                })}
              >
                <View style={{ flex: 1, gap: 2 }}>
                  <Text variant="title" numberOfLines={1}>
                    {item.name}
                  </Text>
                  <Text variant="caption" c={C.secondary} numberOfLines={1}>
                    {item.studentCount} students · {item.subjectName}
                  </Text>
                </View>
                <Text weight={700} c={marked ? C.teal : C.muted} tabular style={{ fontSize: 13 }}>
                  {marked ?? 'Not marked'}
                </Text>
                <Ionicons name="chevron-forward" size={18} color={C.muted} />
              </Pressable>
            );
          }}
        />
      )}
    </View>
  );
}
