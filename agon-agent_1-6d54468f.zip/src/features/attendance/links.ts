import type { ID, ISODate } from '@/core/contracts/models';

export interface TakeAttendanceTarget {
  batchId: ID;
  date: ISODate;
  period?: number;
  subjectId?: ID | null;
}

/** The Take Attendance route with its batch, date, period and subject prefilled. */
export function takeAttendanceHref({ batchId, date, period = 1, subjectId }: TakeAttendanceTarget) {
  const params: Record<string, string> = { batchId, date, period: String(period) };
  if (subjectId) params.subjectId = subjectId;
  return { pathname: '/(owner)/attendance/[batchId]', params } as const;
}
