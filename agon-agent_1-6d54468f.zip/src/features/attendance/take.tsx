import React, { useCallback, useState } from 'react';
import { FlatList, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ConfirmDialog, EmptyState, ErrorState, Skeleton } from '@/components/ui';
import type { AttendanceRoll, AttendanceRollStudent, ID, ISODate } from '@/core/contracts/models';
import { C, LAYOUT } from '@/lib/theme';
import { DateSheet } from './components/DateSheet';
import { SaveFooter } from './components/SaveFooter';
import { StudentTile, TILE_GAP, TILE_HEIGHT } from './components/StudentTile';
import { SummaryStrip } from './components/SummaryStrip';
import { FailureBar, SyncBanner } from './components/SyncBanner';
import { TakeHeader } from './components/TakeHeader';
import { TileMenu } from './components/TileMenu';
import { useOnline } from './hooks/useOnline';
import { useRollQuery, useTakeAttendance, type TakeParams } from './hooks/useTakeAttendance';
import { agoLabel, dateChipLabel } from './model';

const COLUMNS = 3;
const MAX_CONTENT = 560;

/**
 * Take Attendance — shape D, no chrome. Header, summary strip, a 3-column grid
 * of 108pt tiles, sticky save. Tap cycles a tile; long-press opens its menu.
 * This shell loads the roll; `RollSheet` (mounted once per sheet) holds the marks.
 */
export function TakeAttendanceScreen(params: TakeParams) {
  const { roll, key } = useRollQuery(params);
  const { width } = useWindowDimensions();
  const tileWidth = tileWidthFor(width);
  const data = roll.data && roll.data.date === params.date && roll.data.batchId === params.batchId ? roll.data : null;

  if (data && key) {
    return (
      <RollSheet
        key={key}
        rollKey={key}
        roll={data}
        tileWidth={tileWidth}
        refreshing={roll.loading}
        onRefresh={() => void roll.refetch()}
      />
    );
  }
  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_CONTENT, alignSelf: 'center' }}>
        <SafeAreaView edges={['top']}>
          <TakeHeader title="Take attendance" dateLabel={dateChipLabel(params.date)} editing={false} onBack={leave} onDate={leave} />
        </SafeAreaView>
        {roll.error ? (
          <ErrorState title="Could not open the register" message={roll.error.message} onRetry={() => void roll.refetch()} />
        ) : (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: TILE_GAP, padding: LAYOUT.margin }}>
            {Array.from({ length: 12 }, (_, i) => (
              <Skeleton key={i} w={tileWidth} h={TILE_HEIGHT} r={16} />
            ))}
          </View>
        )}
      </View>
    </View>
  );
}

function tileWidthFor(width: number): number {
  const content = Math.min(width, MAX_CONTENT);
  return Math.floor((content - LAYOUT.margin * 2 - TILE_GAP * (COLUMNS - 1)) / COLUMNS);
}

function leave() {
  if (router.canGoBack()) router.back();
  else router.replace('/(owner)' as never);
}

interface RollSheetProps {
  rollKey: string;
  roll: AttendanceRoll;
  tileWidth: number;
  refreshing: boolean;
  onRefresh: () => void;
}

function RollSheet({ rollKey, roll, tileWidth, refreshing, onRefresh }: RollSheetProps) {
  const take = useTakeAttendance(roll, rollKey);
  const online = useOnline();
  const [menuId, setMenuId] = useState<ID | null>(null);
  const [datesOpen, setDatesOpen] = useState(false);
  const [confirmLeave, setConfirmLeave] = useState(false);

  const students = roll.students;
  const title = [roll.batchName, roll.subjectName].filter(Boolean).join(' · ');
  const onBack = () => (take.dirty ? setConfirmLeave(true) : leave());
  const pickDate = (date: ISODate) => {
    setDatesOpen(false);
    if (date !== roll.date) router.setParams({ date });
  };

  const openMenu = useCallback((id: ID) => setMenuId(id), []);
  const menuStudent = students.find((s) => s.studentId === menuId) ?? null;
  const afterCount = menuStudent ? students.length - 1 - students.indexOf(menuStudent) : 0;

  const renderTile = useCallback(
    ({ item }: { item: AttendanceRollStudent }) => (
      <StudentTile
        student={item}
        status={take.marks[item.studentId] ?? 'present'}
        width={tileWidth}
        onPress={take.cycle}
        onLongPress={openMenu}
      />
    ),
    [take.marks, take.cycle, tileWidth, openMenu],
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_CONTENT, alignSelf: 'center' }}>
        <SafeAreaView edges={['top']} style={{ backgroundColor: C.canvas }}>
          <TakeHeader
            title={title}
            dateLabel={dateChipLabel(roll.date)}
            editing={take.editing}
            onBack={onBack}
            onDate={() => setDatesOpen(true)}
          />
        </SafeAreaView>
        <SummaryStrip counts={take.counts} onMarkAllPresent={take.markAllPresent} />
        <SyncBanner online={online} queued={take.queued !== null} lastSynced={agoLabel(take.lastSyncedAt)} />
        {take.failure ? (
          <FailureBar message={take.failure} onRetry={() => void take.save()} onDismiss={take.dismissFailure} />
        ) : null}
        <FlatList
          style={{ flex: 1 }}
          data={students}
          key={`grid-${COLUMNS}`}
          numColumns={COLUMNS}
          keyExtractor={(s) => s.studentId}
          renderItem={renderTile}
          extraData={take.marks}
          columnWrapperStyle={{ gap: TILE_GAP }}
          contentContainerStyle={{ padding: LAYOUT.margin, gap: TILE_GAP, paddingBottom: 32 }}
          initialNumToRender={24}
          refreshing={refreshing && !take.dirty}
          onRefresh={take.dirty ? undefined : onRefresh}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <EmptyState
              icon="people-outline"
              title="No students in this batch"
              text="Admit students to this batch and they will appear here for roll call."
              actionLabel="Add a student"
              onAction={() => router.push('/(owner)/students/new' as never)}
            />
          }
        />
        <SaveFooter
          counts={take.counts}
          editing={take.editing}
          dirty={take.dirty}
          phase={take.phase}
          onSave={() => void take.save()}
        />
      </View>

      <TileMenu
        student={menuStudent}
        status={menuStudent ? take.marks[menuStudent.studentId] ?? 'present' : 'present'}
        afterCount={afterCount}
        onMarkAfter={(status) => menuStudent && take.applyAfter(menuStudent.studentId, status)}
        onClose={() => setMenuId(null)}
      />
      <DateSheet
        visible={datesOpen}
        value={roll.date}
        dirty={take.dirty}
        onPick={pickDate}
        onClose={() => setDatesOpen(false)}
      />
      <ConfirmDialog
        visible={confirmLeave}
        title="Discard these marks?"
        description="You have changes that are not saved. Leaving now drops them."
        confirmLabel="Discard"
        cancelLabel="Keep marking"
        onConfirm={() => {
          setConfirmLeave(false);
          leave();
        }}
        onCancel={() => setConfirmLeave(false)}
      />
    </View>
  );
}
