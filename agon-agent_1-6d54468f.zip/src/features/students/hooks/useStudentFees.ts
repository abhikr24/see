import { useDomainQuery } from '@/core/hooks/domain';
import type { ID, InstallmentStatus } from '@/core/contracts/models';
import { dateShort, inr } from '@/lib/format';
import type { Tone } from '@/lib/theme';
import { paidOnLabel } from '../profile';

export interface ReceiptView {
  id: ID;
  number: string;
  amount: string;
  issued: string;
}

export interface TermRow {
  id: ID;
  title: string;
  amount: string;
  status: InstallmentStatus;
  statusLabel: string;
  tone: Tone;
  due: string;
  paidLabel: string;
  receipts: ReceiptView[];
}

export interface FeesTabView {
  terms: TermRow[];
}

function toneOf(status: InstallmentStatus): Tone {
  if (status === 'paid' || status === 'waived') return 'teal';
  if (status === 'overdue') return 'danger';
  if (status === 'partial' || status === 'due') return 'warning';
  return 'neutral';
}

function titleCase(status: InstallmentStatus): string {
  if (status === 'paid') return 'Paid';
  if (status === 'overdue') return 'Overdue';
  if (status === 'partial') return 'Part paid';
  if (status === 'waived') return 'Waived';
  if (status === 'upcoming') return 'Upcoming';
  return 'Due';
}

/** Fees tab. Off until focused. Amounts and status come from FeeRepo. */
export function useStudentFees(studentId: ID | null, enabled: boolean) {
  return useDomainQuery<FeesTabView>(
    'fees',
    ['student-tab', studentId],
    async (b, i) => {
      const id = studentId as ID;
      const [installments, paymentPage, receiptPage] = await Promise.all([
        b.fees.listInstallments(i, { studentId: id }),
        b.payments.list(i, { where: { studentId: id }, limit: 200 }),
        b.receipts.list(i, { where: { studentId: id }, limit: 200 }),
      ]);
      const payments = paymentPage.items;
      const receiptsByPayment = new Map(receiptPage.items.map((row) => [row.paymentId, row]));
      const terms: TermRow[] = [...installments]
        .sort((a, b) => a.termNo - b.termNo)
        .map((row) => {
          const linked = payments.filter((payment) => payment.installmentId === row.id);
          const receipts: ReceiptView[] = [];
          for (const payment of linked) {
            const receipt = receiptsByPayment.get(payment.id);
            if (!receipt) continue;
            receipts.push({
              id: receipt.id,
              number: receipt.receiptNo,
              amount: inr(receipt.amount),
              issued: dateShort(receipt.issuedAt),
            });
          }
          return {
            id: row.id,
            title: row.label,
            amount: inr(row.amount),
            status: row.status,
            statusLabel: titleCase(row.status),
            tone: toneOf(row.status),
            due: dateShort(row.dueDate),
            paidLabel: paidOnLabel(row.paidOn, row.status),
            receipts,
          };
        });
      return { terms };
    },
    enabled && studentId !== null,
  );
}
