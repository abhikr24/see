import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Card, Text } from '@/components/ui';
import { C, TONE } from '@/lib/theme';
import { TabFrame } from '../components/TabFrame';
import type { FeesTabView, TermRow } from '../hooks/useStudentFees';

function TermCard({ term }: { term: TermRow }) {
  const tone = TONE[term.tone];
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
        <View style={{ flex: 1, gap: 4 }}>
          <Text variant="title">{term.title}</Text>
          <Text variant="caption" c={C.secondary}>
            Due {term.due}
          </Text>
        </View>
        <View style={{ alignItems: 'flex-end', gap: 6 }}>
          <Text variant="h2" weight={800} tabular>
            {term.amount}
          </Text>
          <Badge label={term.statusLabel} tone={term.tone} />
        </View>
      </View>
      <Text variant="caption" weight={600} c={tone.fg} style={{ marginTop: 12 }}>
        {term.paidLabel}
      </Text>
      {term.receipts.length ? (
        <View style={{ marginTop: 14, gap: 8, borderTopWidth: 1, borderTopColor: C.hairline, paddingTop: 12 }}>
          {term.receipts.map((receipt) => (
            <View key={receipt.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <Ionicons name="receipt-outline" size={18} color={C.teal} />
              <View style={{ flex: 1 }}>
                <Text variant="caption" weight={700}>
                  {receipt.number}
                </Text>
                <Text variant="label" c={C.muted} style={{ textTransform: 'none', letterSpacing: 0 }}>
                  {receipt.issued}
                </Text>
              </View>
              <Text variant="caption" weight={700} tabular>
                {receipt.amount}
              </Text>
            </View>
          ))}
        </View>
      ) : term.status === 'paid' ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12 }}>
          <Ionicons name="receipt-outline" size={18} color={C.teal} />
          <Text variant="caption" c={C.secondary}>
            Paid \u2014 receipt not issued
          </Text>
        </View>
      ) : null}
    </Card>
  );
}

export function FeesTab({
  data,
  loading,
  error,
  onRetry,
}: {
  data: FeesTabView | undefined;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}) {
  return (
    <TabFrame
      loading={loading && !data}
      error={error}
      onRetry={onRetry}
      empty={Boolean(data) && data?.terms.length === 0}
      emptyIcon="wallet-outline"
      emptyTitle="No fees assigned"
      emptyText="Terms and receipts will show here once a fee plan is assigned."
    >
      <View style={{ gap: 12 }}>{data?.terms.map((term) => <TermCard key={term.id} term={term} />)}</View>
    </TabFrame>
  );
}
