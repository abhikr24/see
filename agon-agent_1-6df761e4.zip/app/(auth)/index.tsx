/**
 * Auth area placeholder. Sign-in screens land in P2 with the auth contract.
 */

import { Placeholder } from '../../src/features/shared/Placeholder';
import { copy } from '../../src/lib/copy';

export default function AuthIndex() {
  return <Placeholder title={copy.auth.welcomeTitle} message={copy.auth.troubleSigningIn} />;
}
