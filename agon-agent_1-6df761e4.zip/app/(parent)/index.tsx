/**
 * Parent area placeholder. Parent home lands with the first feature.
 */

import { Placeholder } from '../../src/features/shared/Placeholder';
import { copy } from '../../src/lib/copy';

export default function ParentIndex() {
  return (
    <Placeholder title={copy.common.comingSoonTitle} message={copy.common.comingSoonMessage} icon="people-outline" />
  );
}
