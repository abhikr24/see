/**
 * Pending-approval area placeholder. Approval flow lands in P2.
 */

import { Placeholder } from '../../src/features/shared/Placeholder';
import { copy } from '../../src/lib/copy';

export default function PendingIndex() {
  return <Placeholder title={copy.pending.title} message={copy.pending.message} icon="hourglass-outline" />;
}
