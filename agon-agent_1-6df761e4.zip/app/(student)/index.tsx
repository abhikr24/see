/**
 * Student area placeholder. Student home lands with the first feature.
 */

import { Placeholder } from '../../src/features/shared/Placeholder';
import { copy } from '../../src/lib/copy';

export default function StudentIndex() {
  return (
    <Placeholder
      title={copy.common.comingSoonTitle}
      message={copy.common.comingSoonMessage}
      icon="book-outline"
    />
  );
}
