/**
 * Root layout — providers only. No UI, no business logic.
 */

import '../global.css';
import { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { SplashScreen, Stack } from 'expo-router';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BackendProvider } from '../src/core/backend';
import { ToastProvider } from '../src/core/toast';

void SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

/**
 * Loads icon fonts (prevents box-glyphs on web), then hides the splash.
 * Must call hooks unconditionally before any early return.
 */
function FontGate({ children }: { readonly children: React.ReactNode }) {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });

  useEffect(() => {
    if (fontsLoaded) {
      void SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }
  return children;
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <QueryClientProvider client={queryClient}>
        <BackendProvider>
          <ToastProvider>
            <FontGate>
              <StatusBar style="dark" />
              <Stack screenOptions={{ headerShown: false }} />
            </FontGate>
          </ToastProvider>
        </BackendProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}
