/**
 * Design QA page — renders every primitive in every variant and state.
 * Thin route: sections live in `src/features/dev/`.
 */

import { copy } from '../../src/lib/copy';
import { Card, GradientHeader, Screen, Text } from '../../src/components/ui';
import {
  ButtonsSection,
  ChromeSection,
  FeedbackSection,
  InputsSection,
  SheetSection,
  SurfacesSection,
  TypographySection,
} from '../../src/features/dev';

export default function DevComponents() {
  return (
    <Screen scroll>
      <GradientHeader
        title={copy.dev.heroTitle}
        subtitle={copy.dev.heroSubtitle}
        card={
          <Card>
            <Text variant="body">
              {copy.dev.heroCardBody}
            </Text>
          </Card>
        }
      />
      <TypographySection />
      <ButtonsSection />
      <InputsSection />
      <SurfacesSection />
      <FeedbackSection />
      <SheetSection />
      <ChromeSection />
    </Screen>
  );
}
