/**
 * Entry route — thin redirect. Role-aware routing lands in P2 with auth.
 */

import { Redirect } from 'expo-router';
import { routes } from '../src/lib/nav';

export default function Index() {
  return <Redirect href={routes.devComponents} />;
}
