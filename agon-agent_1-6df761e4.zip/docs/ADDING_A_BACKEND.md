# Adding a backend

The UI never imports an adapter. It depends on the contracts in
`src/core/contracts/` and reaches them through the domain hooks in
`src/core/backend.tsx`. Swapping backends is a config change, not a
code change.

## Steps

1. **Contract first** — define (or extend) the domain interface in
   `src/core/contracts/`. Contracts use plain types only: no SDK
   imports, no framework types.
2. **New adapter folder** — create `src/adapters/<name>/` with an
   `index.ts` that exports a `Backend`-compatible object. The folder
   may import from `core/contracts`, `core/config` and `lib/` only —
   never from `components/`, `features/` or `app/`.
3. **Register** — add the name to `BACKENDS` in
   `src/core/config/providers.ts`.
4. **Configure** — read any credentials in `src/core/config/env.ts`
   from `EXPO_PUBLIC_*` variables with safe defaults. Nothing else
   touches `process.env`.
5. **Wire** — resolve the adapter by `env.backend` inside
   `src/core/backend.tsx`. Keep every domain hook signature unchanged
   so no screen or feature file needs to change.
6. **Verify** — `npx tsc --noEmit` passes, and the app boots with both
   the old and the new `EXPO_PUBLIC_BACKEND` value.

## Rules

- One folder per backend. Shared backend code goes in the contract
  types, not in cross-adapter imports.
- Adapters own all I/O, mapping and error normalisation. The UI sees
  domain types or throws domain errors — never SDK shapes.
- The `stub` adapter stays forever: tests and the design QA page run
  against it.
