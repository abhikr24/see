# Adding a feature

A full feature slice walks through every layer. Work top-down so each
step compiles before the next:

1. **Contract** — add the domain interface to `src/core/contracts/`
   (see `docs/ADDING_A_BACKEND.md` for the shape). UI depends on this.
2. **Backend hook** — expose the domain through `src/core/backend.tsx`
   (e.g. `useStudents()`). Screens call hooks, never adapters.
3. **Adapter** — implement the contract in `src/adapters/<backend>/`.
   Keep I/O and mapping inside the adapter.
4. **Copy + format** — add strings to `src/lib/copy.ts`; use
   `src/lib/format.ts` for money, dates and percentages. Never hardcode
   a user-facing string or a format in a component.
5. **Feature folder** — create `src/features/<feature>/` with
   `screens/`, `components/`, `hooks/` and an `index.ts` that exports
   screens + hooks only (see `src/features/README.md`).
6. **Primitives first** — build screens from `src/components/ui/`.
   If a primitive is missing, add it there (typed props, `className`
   passthrough, tokens from `src/lib/theme.ts`) and showcase it in
   `app/dev/components.tsx` before using it.
7. **Routes** — add thin files under the right `app/` group. Routes
   render a screen and pass params; no business logic.
8. **Schema (if needed)** — add a numbered migration in
   `supabase/migrations/`, regenerate `supabase/schema.sql`, and extend
   `supabase/seed.sql`.
9. **Verify** — `npx tsc --noEmit` passes, every touched file is under
   300 lines, no colour value lives outside `src/lib/theme.ts`, and the
   design QA page still renders without warnings.
