# Design system

All primitives live in `src/components/ui/`, are styled with NativeWind,
and read every colour, radius, spacing and type value from
`src/lib/theme.ts`. QA them on one page: `app/dev/components.tsx`.

## Rules

- Typed props, a `className` passthrough, and no hardcoded colour
  values. The only exception is `GradientHeader`, which reads the
  gradient pair from `theme.ts`.
- Layout with NativeWind utilities; colour and mandated measurements
  via `style` from the theme tokens.
- Every user-facing string comes from `src/lib/copy.ts`.
- Keep every file under 300 lines — split early.

## Primitives

| Primitive       | Purpose                                              |
| --------------- | ---------------------------------------------------- |
| Text            | h1 h2 title body caption label; weights; colours     |
| Button          | primary secondary outline ghost danger; sm md lg;    |
|                 | loading; disabled; leftIcon; full width              |
| Input           | label above, error below in danger, leftIcon, secure |
|                 | toggle, keyboardType, 2px primary focus ring         |
| Card            | white, 20 radius, 1px hairline, 18 padding, optional |
|                 | onPress with press state                             |
| Chip            | selectable filter pill                               |
| Badge           | tonal status/count pill                              |
| Avatar          | photo with initials fallback; sm md lg               |
| Divider         | hairline, optional centred label                     |
| ProgressBar     | tonal linear percentage                              |
| Ring            | SVG circular percentage with centred label           |
| Sheet           | bottom sheet, 28 top radius, drag handle, backdrop,  |
|                 | 60% max height                                       |
| Skeleton        | shimmer block in #EFF2F8                             |
| EmptyState      | icon + title + message + optional action             |
| ErrorState      | icon + title + message + retry                       |
| Screen          | SafeAreaView + optional scroll + 20 side margin      |
| TabBar          | floating pill, 28 radius, shadow, 5 items, active    |
|                 | navy pill, red badge support                         |
| GradientHeader  | 135° navy gradient, 24 radius, overlapping card slot |

## Adding a primitive

1. Create `src/components/ui/<Name>.tsx` (+ types) and export it from
   `src/components/ui/index.ts`.
2. Showcase every variant and state in `app/dev/components.tsx`
   (via a section in `src/features/dev/`).
3. Document the primitive in the table above.
