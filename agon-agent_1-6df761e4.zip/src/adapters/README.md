# Adapters — one folder per backend

Each folder here implements the contracts in `src/core/contracts/` for one
backend (e.g. `stub/`, and in P2 something like `supabase/`).

Rules:

- An adapter folder exports a `Backend`-compatible object from its `index.ts`.
- Adapters may import from `core/contracts`, `core/config` and `lib/` only.
  They must never import from `components/`, `features/` or `app/`.
- UI code never imports an adapter directly — it goes through the domain
  hooks in `src/core/backend.tsx`.
- To add a backend: create the folder, implement the contracts, register the
  name in `src/core/config/providers.ts`, and select it with
  `EXPO_PUBLIC_BACKEND`.

Today only `stub/` exists. It performs no I/O and reports a signed-out
session, so the design system and navigation skeleton can be built first.
