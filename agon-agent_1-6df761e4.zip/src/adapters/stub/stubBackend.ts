/**
 * Stub backend adapter. Satisfies the `Backend` contract with no I/O so the
 * UI can be built and QA'd before P2 wires a real backend.
 */

import type { Backend } from '../../core/contracts';

export const stubBackend: Backend = {
  name: 'stub',
};
