import { useState } from 'react';
import { View } from 'react-native';
import { Image } from 'expo-image';
import { colors, radii } from '../../lib/theme';
import { Text } from './Text';

export type AvatarSize = 'sm' | 'md' | 'lg';

export interface AvatarProps {
  readonly name: string;
  readonly uri?: string;
  readonly size?: AvatarSize;
  readonly className?: string;
}

const DIMS: Record<AvatarSize, number> = { sm: 36, md: 48, lg: 64 };

function initialsOf(name: string): string {
  const parts = name.trim().split(/\s+/);
  const first = parts[0] ?? '';
  const last = parts.length > 1 ? (parts[parts.length - 1] ?? '') : '';
  return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
}

export function Avatar({ name, uri, size = 'md', className }: AvatarProps) {
  const [failed, setFailed] = useState(false);
  const dim = DIMS[size];
  const showPhoto = uri !== undefined && !failed;
  return (
    <View
      className={className}
      style={{
        width: dim,
        height: dim,
        borderRadius: radii.full,
        backgroundColor: colors.primarySoft,
        borderWidth: 1,
        borderColor: colors.line,
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      {showPhoto ? (
        <Image
          source={{ uri }}
          style={{ width: dim, height: dim }}
          contentFit="cover"
          onError={() => setFailed(true)}
          accessibilityLabel={name}
        />
      ) : (
        <Text variant={size === 'lg' ? 'title' : size === 'md' ? 'body' : 'caption'} weight="semibold" color="primary">
          {initialsOf(name)}
        </Text>
      )}
    </View>
  );
}
