import { View } from 'react-native';
import { colors, radii, spacing } from '../../lib/theme';
import { Text } from './Text';
import type { TextColor } from './Text';

export type BadgeTone = 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'neutral';

export interface BadgeProps {
  readonly label: string | number;
  readonly tone?: BadgeTone;
  readonly className?: string;
}

const TONES: Record<BadgeTone, { readonly background: string; readonly text: TextColor }> = {
  primary: { background: colors.primarySoft, text: 'primary' },
  success: { background: colors.successSoft, text: 'success' },
  warning: { background: colors.warningSoft, text: 'warning' },
  danger: { background: colors.dangerSoft, text: 'danger' },
  info: { background: colors.infoSoft, text: 'info' },
  neutral: { background: colors.shimmer, text: 'muted' },
};

export function Badge({ label, tone = 'neutral', className }: BadgeProps) {
  const t = TONES[tone];
  return (
    <View
      className={className}
      style={{
        backgroundColor: t.background,
        borderRadius: radii.full,
        paddingHorizontal: spacing.sm,
        paddingVertical: spacing.xs,
        alignSelf: 'flex-start',
      }}
    >
      <Text variant="label" weight="semibold" color={t.text}>
        {label}
      </Text>
    </View>
  );
}
