import { ActivityIndicator, Pressable } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, hit, radii, spacing } from '../../lib/theme';
import { Text } from './Text';
import type { TextColor } from './Text';
import type { IconName } from './icon';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  readonly title: string;
  readonly variant?: ButtonVariant;
  readonly size?: ButtonSize;
  readonly loading?: boolean;
  readonly disabled?: boolean;
  readonly fullWidth?: boolean;
  readonly leftIcon?: IconName;
  readonly onPress: () => void;
  readonly className?: string;
}

interface VariantStyle {
  readonly background: string;
  readonly text: TextColor;
  readonly border?: string;
}

const VARIANTS: Record<ButtonVariant, VariantStyle> = {
  primary: { background: colors.primary, text: 'white' },
  secondary: { background: colors.primarySoft, text: 'primary' },
  outline: { background: colors.transparent, text: 'primary', border: colors.primary },
  ghost: { background: colors.transparent, text: 'primary' },
  danger: { background: colors.danger, text: 'white' },
};

interface SizeStyle {
  readonly minHeight: number;
  readonly paddingHorizontal: number;
  readonly radius: number;
  readonly icon: number;
  readonly text: 'label' | 'body';
}

const SIZES: Record<ButtonSize, SizeStyle> = {
  sm: { minHeight: hit, paddingHorizontal: 14, radius: radii.sm, icon: 16, text: 'label' },
  md: { minHeight: 48, paddingHorizontal: 18, radius: radii.md, icon: 18, text: 'body' },
  lg: { minHeight: 52, paddingHorizontal: 22, radius: radii.lg, icon: 20, text: 'body' },
};

export function Button({
  title,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  fullWidth = false,
  leftIcon,
  onPress,
  className,
}: ButtonProps) {
  const v = VARIANTS[variant];
  const s = SIZES[size];
  const inactive = loading || disabled;
  const iconColor = v.text === 'white' ? colors.white : colors.primary;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: inactive, busy: loading }}
      disabled={inactive}
      onPress={onPress}
      className={className}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: spacing.sm,
        backgroundColor: v.background,
        borderRadius: s.radius,
        borderWidth: v.border === undefined ? 0 : 1,
        borderColor: v.border,
        minHeight: s.minHeight,
        paddingHorizontal: s.paddingHorizontal,
        alignSelf: fullWidth ? 'stretch' : 'flex-start',
        opacity: inactive ? 0.55 : pressed ? 0.85 : 1,
      })}
    >
      {loading ? (
        <ActivityIndicator size="small" color={iconColor} />
      ) : leftIcon === undefined ? null : (
        <Ionicons name={leftIcon} size={s.icon} color={iconColor} />
      )}
      <Text variant={s.text} weight="semibold" color={v.text}>
        {title}
      </Text>
    </Pressable>
  );
}
