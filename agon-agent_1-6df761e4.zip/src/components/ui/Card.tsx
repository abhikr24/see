import { Pressable, StyleSheet, View } from 'react-native';
import type { ReactNode } from 'react';
import { colors, radii, shadows, spacing } from '../../lib/theme';

export interface CardProps {
  readonly children: ReactNode;
  readonly onPress?: () => void;
  readonly className?: string;
}

export function Card({ children, onPress, className }: CardProps) {
  if (onPress === undefined) {
    return (
      <View className={className} style={styles.card}>
        {children}
      </View>
    );
  }
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      className={className}
      style={({ pressed }) => [styles.card, pressed ? styles.pressed : null]}
    >
      {children}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radii.xl,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.line,
    padding: spacing.card,
    ...shadows.card,
  },
  pressed: {
    opacity: 0.96,
  },
});
