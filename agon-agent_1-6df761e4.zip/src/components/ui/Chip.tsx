import { Pressable, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, hit, radii, spacing } from '../../lib/theme';
import { Text } from './Text';
import type { IconName } from './icon';

export interface ChipProps {
  readonly label: string;
  readonly selected?: boolean;
  readonly leftIcon?: IconName;
  readonly onPress?: () => void;
  readonly className?: string;
}

export function Chip({ label, selected = false, leftIcon, onPress, className }: ChipProps) {
  const content = (
    <>
      {leftIcon === undefined ? null : (
        <Ionicons name={leftIcon} size={16} color={selected ? colors.white : colors.body} />
      )}
      <Text variant="label" weight="semibold" color={selected ? 'white' : 'body'}>
        {label}
      </Text>
    </>
  );
  const box = {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: spacing.xs,
    backgroundColor: selected ? colors.primary : colors.surface,
    borderWidth: 1,
    borderColor: selected ? colors.primary : colors.line,
    borderRadius: radii.full,
    minHeight: hit,
    paddingHorizontal: spacing.lg,
  };
  if (onPress === undefined) {
    return (
      <View className={className} style={box}>
        {content}
      </View>
    );
  }
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      className={className}
      style={({ pressed }) => [box, pressed ? { opacity: 0.85 } : null]}
    >
      {content}
    </Pressable>
  );
}
