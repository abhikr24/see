import { StyleSheet, View } from 'react-native';
import { colors, spacing } from '../../lib/theme';
import { Text } from './Text';

export interface DividerProps {
  readonly label?: string;
  readonly className?: string;
}

export function Divider({ label, className }: DividerProps) {
  if (label === undefined) {
    return <View className={className} style={styles.line} />;
  }
  return (
    <View className={className} style={styles.row}>
      <View style={[styles.line, styles.grow]} />
      <Text variant="caption" color="muted">
        {label}
      </Text>
      <View style={[styles.line, styles.grow]} />
    </View>
  );
}

const styles = StyleSheet.create({
  line: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.line,
  },
  grow: {
    flex: 1,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
});
