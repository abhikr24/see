import { View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, radii, spacing } from '../../lib/theme';
import { copy } from '../../lib/copy';
import { Button } from './Button';
import { Text } from './Text';
import type { IconName } from './icon';

export interface EmptyStateProps {
  readonly icon?: IconName;
  readonly title?: string;
  readonly message?: string;
  readonly actionLabel?: string;
  readonly onAction?: () => void;
  readonly className?: string;
}

export function EmptyState({
  icon = 'file-tray-outline',
  title = copy.empty.defaultTitle,
  message = copy.empty.defaultMessage,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  return (
    <View className={className} style={{ alignItems: 'center', gap: spacing.md, paddingVertical: spacing.xl }}>
      <View
        style={{
          width: 64,
          height: 64,
          borderRadius: radii.full,
          backgroundColor: colors.primarySoft,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name={icon} size={28} color={colors.primary} />
      </View>
      <Text variant="title" weight="semibold" color="ink" align="center">
        {title}
      </Text>
      <Text variant="body" color="muted" align="center">
        {message}
      </Text>
      {actionLabel !== undefined && onAction !== undefined ? (
        <Button title={actionLabel} variant="primary" size="md" onPress={onAction} />
      ) : null}
    </View>
  );
}
