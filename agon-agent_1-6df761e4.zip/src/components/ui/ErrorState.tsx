import { View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, radii, spacing } from '../../lib/theme';
import { copy } from '../../lib/copy';
import { Button } from './Button';
import { Text } from './Text';

export interface ErrorStateProps {
  readonly title?: string;
  readonly message?: string;
  readonly retryLabel?: string;
  readonly onRetry: () => void;
  readonly className?: string;
}

export function ErrorState({
  title = copy.errors.title,
  message = copy.errors.message,
  retryLabel = copy.errors.retry,
  onRetry,
  className,
}: ErrorStateProps) {
  return (
    <View className={className} style={{ alignItems: 'center', gap: spacing.md, paddingVertical: spacing.xl }}>
      <View
        style={{
          width: 64,
          height: 64,
          borderRadius: radii.full,
          backgroundColor: colors.dangerSoft,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name="alert-circle-outline" size={28} color={colors.danger} />
      </View>
      <Text variant="title" weight="semibold" color="ink" align="center">
        {title}
      </Text>
      <Text variant="body" color="muted" align="center">
        {message}
      </Text>
      <Button title={retryLabel} variant="danger" size="md" leftIcon="refresh-outline" onPress={onRetry} />
    </View>
  );
}
