import { View } from 'react-native';
import type { ReactNode } from 'react';
import { LinearGradient } from 'expo-linear-gradient';
import { gradients, radii, spacing } from '../../lib/theme';
import { Text } from './Text';

export interface GradientHeaderProps {
  readonly title: string;
  readonly subtitle?: string;
  readonly children?: ReactNode;
  readonly card?: ReactNode;
  readonly className?: string;
}

export function GradientHeader({ title, subtitle, children, card, className }: GradientHeaderProps) {
  return (
    <View className={className}>
      <LinearGradient
        colors={gradients.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          borderRadius: radii.xxl,
          padding: spacing.xl,
          paddingBottom: card === undefined ? spacing.xl : 48,
          gap: spacing.xs,
        }}
      >
        <Text variant="h2" weight="bold" color="white">
          {title}
        </Text>
        {subtitle === undefined ? null : (
          <View style={{ opacity: 0.85 }}>
            <Text variant="body" color="white">
              {subtitle}
            </Text>
          </View>
        )}
        {children}
      </LinearGradient>
      {card === undefined ? null : <View style={{ marginTop: -32, paddingHorizontal: spacing.lg }}>{card}</View>}
    </View>
  );
}
