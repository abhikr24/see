import { useState } from 'react';
import { Pressable, TextInput as RNTextInput, View } from 'react-native';
import type { KeyboardTypeOptions, ReturnKeyTypeOptions } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, fontSizes, hit, lineHeights, radii, spacing } from '../../lib/theme';
import { copy } from '../../lib/copy';
import { Text } from './Text';
import type { IconName } from './icon';

export interface InputProps {
  readonly label: string;
  readonly value: string;
  readonly onChangeText: (text: string) => void;
  readonly placeholder?: string;
  readonly error?: string;
  readonly leftIcon?: IconName;
  readonly secure?: boolean;
  readonly keyboardType?: KeyboardTypeOptions;
  readonly returnKeyType?: ReturnKeyTypeOptions;
  readonly editable?: boolean;
  readonly onSubmitEditing?: () => void;
  readonly className?: string;
}

export function Input({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  leftIcon,
  secure = false,
  keyboardType = 'default',
  returnKeyType = 'done',
  editable = true,
  onSubmitEditing,
  className,
}: InputProps) {
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(true);
  const hasError = error !== undefined && error.length > 0;
  const borderColor = hasError ? colors.danger : focused ? colors.primary : colors.line;

  return (
    <View className={className} style={{ gap: spacing.xs, opacity: editable ? 1 : 0.6 }}>
      <Text variant="label" weight="semibold" color="ink">
        {label}
      </Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: colors.surface,
          borderWidth: focused ? 2 : 1,
          borderColor,
          borderRadius: radii.md,
          minHeight: 52,
          paddingLeft: leftIcon === undefined ? spacing.lg : spacing.md,
          paddingRight: secure ? spacing.xs : spacing.lg,
        }}
      >
        {leftIcon === undefined ? null : (
          <Ionicons
            name={leftIcon}
            size={20}
            color={focused ? colors.primary : colors.muted}
            style={{ marginRight: spacing.sm }}
          />
        )}
        <RNTextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.faint}
          secureTextEntry={secure && hidden}
          keyboardType={keyboardType}
          returnKeyType={returnKeyType}
          editable={editable}
          onSubmitEditing={onSubmitEditing}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            flex: 1,
            color: colors.ink,
            fontSize: fontSizes.body,
            lineHeight: lineHeights.body,
            paddingVertical: spacing.md,
          }}
        />
        {secure ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={hidden ? copy.common.showPassword : copy.common.hidePassword}
            onPress={() => setHidden((prev) => !prev)}
            style={{ minWidth: hit, minHeight: hit, alignItems: 'center', justifyContent: 'center' }}
          >
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={20} color={colors.muted} />
          </Pressable>
        ) : null}
      </View>
      {hasError ? (
        <Text variant="caption" color="danger">
          {error}
        </Text>
      ) : null}
    </View>
  );
}
