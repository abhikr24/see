import { View } from 'react-native';
import { colors, radii } from '../../lib/theme';

export type ProgressTone = 'primary' | 'success' | 'warning' | 'danger';

export interface ProgressBarProps {
  readonly value: number;
  readonly tone?: ProgressTone;
  readonly className?: string;
}

const FILLS: Record<ProgressTone, string> = {
  primary: colors.primary,
  success: colors.success,
  warning: colors.warning,
  danger: colors.danger,
};

export function ProgressBar({ value, tone = 'primary', className }: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, value));
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityValue={{ now: clamped, min: 0, max: 100 }}
      className={className}
      style={{ height: 8, borderRadius: radii.full, backgroundColor: colors.line, overflow: 'hidden' }}
    >
      <View style={{ width: `${clamped}%`, height: '100%', borderRadius: radii.full, backgroundColor: FILLS[tone] }} />
    </View>
  );
}
