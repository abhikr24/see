import { View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { colors } from '../../lib/theme';
import { pct } from '../../lib/format';
import { Text } from './Text';
import type { ProgressTone } from './ProgressBar';

export interface RingProps {
  readonly value: number;
  readonly size?: number;
  readonly strokeWidth?: number;
  readonly tone?: ProgressTone;
  readonly label?: string;
  readonly className?: string;
}

const STROKES: Record<ProgressTone, string> = {
  primary: colors.primary,
  success: colors.success,
  warning: colors.warning,
  danger: colors.danger,
};

export function Ring({ value, size = 120, strokeWidth = 10, tone = 'primary', label, className }: RingProps) {
  const clamped = Math.min(100, Math.max(0, value));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center = size / 2;
  return (
    <View className={className} style={{ width: size, height: size }}>
      <Svg width={size} height={size}>
        <Circle cx={center} cy={center} r={radius} stroke={colors.line} strokeWidth={strokeWidth} fill={colors.transparent} />
        <Circle
          cx={center}
          cy={center}
          r={radius}
          stroke={STROKES[tone]}
          strokeWidth={strokeWidth}
          fill={colors.transparent}
          strokeLinecap="round"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={circumference * (1 - clamped / 100)}
          transform={`rotate(-90 ${center} ${center})`}
        />
      </Svg>
      <View
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text variant="title" weight="semibold" color="ink">
          {label ?? pct(clamped)}
        </Text>
      </View>
    </View>
  );
}
