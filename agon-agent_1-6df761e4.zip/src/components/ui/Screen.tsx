import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { Edge } from 'react-native-safe-area-context';
import type { ReactNode } from 'react';
import { colors, spacing } from '../../lib/theme';

export interface ScreenProps {
  readonly children: ReactNode;
  readonly scroll?: boolean;
  readonly edges?: Edge[];
  readonly className?: string;
}

export function Screen({ children, scroll = false, edges, className }: ScreenProps) {
  return (
    <SafeAreaView edges={edges} style={{ flex: 1, backgroundColor: colors.background }}>
      {scroll ? (
        <ScrollView
          className={className}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            flexGrow: 1,
            gap: spacing.xl,
            paddingHorizontal: spacing.screen,
            paddingVertical: spacing.xl,
          }}
        >
          {children}
        </ScrollView>
      ) : (
        <View
          className={className}
          style={{ flex: 1, gap: spacing.xl, paddingHorizontal: spacing.screen, paddingVertical: spacing.xl }}
        >
          {children}
        </View>
      )}
    </SafeAreaView>
  );
}
