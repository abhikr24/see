import { Modal, Pressable, ScrollView, View } from 'react-native';
import type { ReactNode } from 'react';
import { colors, radii, shadows, spacing } from '../../lib/theme';
import { copy } from '../../lib/copy';
import { Text } from './Text';

export interface SheetProps {
  readonly visible: boolean;
  readonly onClose: () => void;
  readonly title?: string;
  readonly children: ReactNode;
  readonly className?: string;
}

export function Sheet({ visible, onClose, title, children, className }: SheetProps) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={copy.common.close}
        onPress={onClose}
        style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: colors.overlay }}
      >
        {/* Inner pressable swallows taps so content taps don't dismiss. */}
        <Pressable
          onPress={() => undefined}
          className={className}
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: radii.sheet,
            borderTopRightRadius: radii.sheet,
            maxHeight: '60%',
            paddingHorizontal: spacing.screen,
            paddingTop: spacing.md,
            paddingBottom: spacing.xxxl,
            ...shadows.sheet,
          }}
        >
          <View
            style={{
              alignSelf: 'center',
              width: 40,
              height: 4,
              borderRadius: radii.full,
              backgroundColor: colors.line,
              marginBottom: spacing.lg,
            }}
          />
          {title === undefined ? null : (
            <Text variant="title" weight="semibold" color="ink">
              {title}
            </Text>
          )}
          <ScrollView
            bounces={false}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{
              paddingTop: title === undefined ? 0 : spacing.sm,
              paddingBottom: spacing.sm,
            }}
          >
            {children}
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
