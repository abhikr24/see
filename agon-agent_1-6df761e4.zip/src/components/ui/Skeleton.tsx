import { useEffect, useRef } from 'react';
import { Animated } from 'react-native';
import { colors, radii } from '../../lib/theme';
import type { Radii } from '../../lib/theme';

export interface SkeletonProps {
  readonly className?: string;
  readonly radius?: keyof Radii;
}

export function Skeleton({ className, radius = 'md' }: SkeletonProps) {
  const opacity = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 0.4, duration: 900, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 1, duration: 900, useNativeDriver: true }),
      ]),
    );
    pulse.start();
    return () => pulse.stop();
  }, [opacity]);

  return (
    <Animated.View
      className={className}
      style={{ backgroundColor: colors.shimmer, borderRadius: radii[radius], opacity }}
    />
  );
}
