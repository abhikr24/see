import { Pressable, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { colors, hit, radii, shadows, spacing } from '../../lib/theme';
import { Badge } from './Badge';
import { Text } from './Text';
import type { IconName } from './icon';

export interface TabItem {
  readonly key: string;
  readonly label: string;
  readonly icon: IconName;
  readonly badge?: number;
}

export type TabItems = readonly [TabItem, TabItem, TabItem, TabItem, TabItem];

export interface TabBarProps {
  readonly items: TabItems;
  readonly activeKey: string;
  readonly onSelect: (key: string) => void;
  readonly className?: string;
}

export function TabBar({ items, activeKey, onSelect, className }: TabBarProps) {
  return (
    <View
      className={className}
      style={{
        flexDirection: 'row',
        backgroundColor: colors.surface,
        borderRadius: radii.tab,
        paddingHorizontal: spacing.sm,
        paddingVertical: spacing.sm,
        ...shadows.float,
      }}
    >
      {items.map((item) => {
        const active = item.key === activeKey;
        return (
          <Pressable
            key={item.key}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
            onPress={() => onSelect(item.key)}
            style={{
              flex: 1,
              alignItems: 'center',
              justifyContent: 'center',
              gap: spacing.xs,
              minHeight: hit,
              paddingVertical: spacing.xs,
            }}
          >
            <View>
              <View
                style={{
                  backgroundColor: active ? colors.primarySoft : colors.transparent,
                  borderRadius: radii.full,
                  paddingHorizontal: spacing.lg,
                  paddingVertical: spacing.xs,
                }}
              >
                <Ionicons name={item.icon} size={22} color={active ? colors.primary : colors.muted} />
              </View>
              {item.badge === undefined || item.badge <= 0 ? null : (
                <View style={{ position: 'absolute', top: -6, right: 6 }}>
                  <Badge tone="danger" label={item.badge > 9 ? '9+' : item.badge} />
                </View>
              )}
            </View>
            <Text variant="label" weight={active ? 'semibold' : 'medium'} color={active ? 'primary' : 'muted'} numberOfLines={1}>
              {item.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
