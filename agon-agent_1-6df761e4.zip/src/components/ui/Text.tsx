import { Text as RNText } from 'react-native';
import type { ReactNode } from 'react';
import { colors, fontSizes, fontWeights, lineHeights } from '../../lib/theme';

export type TextVariant = 'h1' | 'h2' | 'title' | 'body' | 'caption' | 'label';
export type TextWeight = 'regular' | 'medium' | 'semibold' | 'bold';
export type TextColor =
  | 'ink'
  | 'body'
  | 'muted'
  | 'faint'
  | 'white'
  | 'primary'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info';

export interface TextProps {
  readonly variant?: TextVariant;
  readonly weight?: TextWeight;
  readonly color?: TextColor;
  readonly align?: 'left' | 'center' | 'right';
  readonly numberOfLines?: number;
  readonly className?: string;
  readonly children: ReactNode;
}

const TONES: Record<TextColor, string> = {
  ink: colors.ink,
  body: colors.body,
  muted: colors.muted,
  faint: colors.faint,
  white: colors.white,
  primary: colors.primary,
  success: colors.success,
  warning: colors.warning,
  danger: colors.danger,
  info: colors.info,
};

export function Text({
  variant = 'body',
  weight = 'regular',
  color = 'body',
  align = 'left',
  numberOfLines,
  className,
  children,
}: TextProps) {
  return (
    <RNText
      numberOfLines={numberOfLines}
      className={className}
      style={{
        fontSize: fontSizes[variant],
        lineHeight: lineHeights[variant],
        fontWeight: fontWeights[weight],
        color: TONES[color],
        textAlign: align,
      }}
    >
      {children}
    </RNText>
  );
}
