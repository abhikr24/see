import type Ionicons from '@expo/vector-icons/Ionicons';
import type { ComponentProps } from 'react';

/** Any glyph name from the Ionicons set. */
export type IconName = ComponentProps<typeof Ionicons>['name'];
