/**
 * Backend context + domain hooks. The ONLY way UI code reaches the backend.
 *
 * Today this wires the stub adapter with a signed-out session. In P2 the
 * provider resolves the adapter named by `env.backend` and exposes real
 * domain hooks — without changing any call site.
 */

import { createContext, useContext, useMemo } from 'react';
import type { ReactNode } from 'react';
import type { Backend, Role, Session, UserProfile } from './contracts';
import { stubBackend } from '../adapters/stub';
import { copy } from '../lib/copy';

export interface BackendContextValue {
  readonly backend: Backend;
  readonly session: Session;
}

const BackendContext = createContext<BackendContextValue | null>(null);

/** Provides the active backend and session to the whole tree. */
export function BackendProvider({ children }: { readonly children: ReactNode }) {
  const value = useMemo<BackendContextValue>(
    () => ({ backend: stubBackend, session: { user: null } }),
    [],
  );
  return <BackendContext.Provider value={value}>{children}</BackendContext.Provider>;
}

function useBackendContext(): BackendContextValue {
  const ctx = useContext(BackendContext);
  if (ctx === null) {
    throw new Error(copy.errors.backendMissing);
  }
  return ctx;
}

/** The active backend adapter. */
export function useBackend(): Backend {
  return useBackendContext().backend;
}

/** The current session (signed-out stub until P2). */
export function useSession(): Session {
  return useBackendContext().session;
}

/** The signed-in user, or null. */
export function useUser(): UserProfile | null {
  return useSession().user;
}

/** The signed-in user's role, or null. */
export function useRole(): Role | null {
  return useSession().user?.role ?? null;
}
