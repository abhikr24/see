/**
 * Typed environment. Every `EXPO_PUBLIC_*` variable is read, validated and
 * defaulted here so the rest of the app never touches `process.env`.
 */

import { DEFAULT_BACKEND } from './providers';
import type { BackendName } from './providers';

function readBackendName(): BackendName {
  const raw: string | undefined = process.env.EXPO_PUBLIC_BACKEND;
  return raw === 'stub' ? raw : DEFAULT_BACKEND;
}

export const env = {
  backend: readBackendName(),
  appName: 'GuruFlow',
} as const;
