/**
 * Registry of available backend adapters. P2 adds real backends here
 * (e.g. 'supabase') — one entry per folder under `src/adapters/`.
 */

export const BACKENDS = ['stub'] as const;

export type BackendName = (typeof BACKENDS)[number];

export const DEFAULT_BACKEND: BackendName = 'stub';
