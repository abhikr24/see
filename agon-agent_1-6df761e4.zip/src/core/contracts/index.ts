/**
 * Backend contracts — the interfaces every backend adapter must satisfy.
 *
 * UI code may depend ONLY on these contracts (via `core/backend.tsx` hooks).
 * Swapping backends means adding a folder under `src/adapters/` and flipping
 * `EXPO_PUBLIC_BACKEND`; no UI file changes.
 *
 * Foundation types live here now. Full domain contracts (auth, students,
 * batches, attendance, fees, timetable, chat \u2026) land in P2 alongside the
 * first real adapter.
 */

/** The four GuruFlow roles. */
export type Role = 'owner' | 'teacher' | 'student' | 'parent';

/** The signed-in user, as the UI sees them. */
export interface UserProfile {
  readonly id: string;
  readonly role: Role;
  readonly fullName: string;
  readonly avatarUri?: string;
}

/** Session state surfaced to the UI. Null user = signed out. */
export interface Session {
  readonly user: UserProfile | null;
}

/**
 * Backend handle. The stub backend implements this today; P2 extends it
 * with per-domain contracts (auth, students, fees \u2026).
 */
export interface Backend {
  readonly name: string;
}
