/**
 * Minimal toast system: `ToastProvider` hosts the toast, `useToast` shows one.
 * No third-party dependency — a timed, animated pill above the tab bar.
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { Animated } from 'react-native';
import { colors, radii, shadows, spacing } from '../lib/theme';
import { copy } from '../lib/copy';
import { Text } from '../components/ui/Text';

const DURATION_MS = 2600;

interface ToastState {
  readonly message: string;
  readonly key: number;
}

interface ToastContextValue {
  readonly show: (message: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

function ToastPill({ message }: { readonly message: string }) {
  const opacity = useRef(new Animated.Value(0)).current;
  const rise = useRef(new Animated.Value(12)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, { toValue: 1, duration: 220, useNativeDriver: true }),
      Animated.timing(rise, { toValue: 0, duration: 220, useNativeDriver: true }),
    ]).start();
  }, [opacity, rise]);

  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute',
        left: spacing.screen,
        right: spacing.screen,
        bottom: 48,
        backgroundColor: colors.ink,
        borderRadius: radii.lg,
        paddingHorizontal: spacing.lg,
        paddingVertical: spacing.md,
        alignItems: 'center',
        opacity,
        transform: [{ translateY: rise }],
        ...shadows.float,
      }}
    >
      <Text color="white" weight="medium" align="center">
        {message}
      </Text>
    </Animated.View>
  );
}

export function ToastProvider({ children }: { readonly children: ReactNode }) {
  const [toast, setToast] = useState<ToastState | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = useCallback((message: string) => {
    if (timer.current !== null) {
      clearTimeout(timer.current);
    }
    setToast((prev) => ({ message, key: (prev?.key ?? 0) + 1 }));
    timer.current = setTimeout(() => {
      setToast(null);
    }, DURATION_MS);
  }, []);

  const value = useMemo<ToastContextValue>(() => ({ show }), [show]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      {toast === null ? null : <ToastPill key={toast.key} message={toast.message} />}
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (ctx === null) {
    throw new Error(copy.errors.toastMissing);
  }
  return ctx;
}
