# Features — one folder per feature

Each feature folder owns its screens, components and hooks:

```
src/features/<feature>/
  screens/        one file per screen (UI composition only)
  components/     feature-specific components (built on `components/ui`)
  hooks/          feature hooks (call the domain hooks in `core/backend.tsx`)
  index.ts        public API: screens + hooks only
```

Rules:

- Route files in `app/` are thin: they render a screen from here and pass
  route params. No business logic in `app/`.
- Screens compose primitives from `src/components/ui/`. No raw
  `react-native` text/buttons/inputs — extend the design system instead.
- Strings come from `src/lib/copy.ts`; colours and sizes from
  `src/lib/theme.ts`; formatting from `src/lib/format.ts`.
- Data comes only from the domain hooks in `src/core/backend.tsx`.
  Features never import from `src/adapters/` — the backend is injected.
- Keep every file under 300 lines; split screens and sections early.

## Adding a feature

See `docs/ADDING_A_FEATURE.md` for the step-by-step checklist.
