/** Buttons section: every Button variant, size and state. */

import { copy } from '../../lib/copy';
import { useToast } from '../../core/toast';
import { Button } from '../../components/ui';
import type { ButtonSize, ButtonVariant } from '../../components/ui';
import { Column, Row, Section } from './Section';

const VARIANTS: ReadonlyArray<{ readonly variant: ButtonVariant; readonly label: string }> = [
  { variant: 'primary', label: copy.dev.variants[0] ?? 'Primary' },
  { variant: 'secondary', label: copy.dev.variants[1] ?? 'Secondary' },
  { variant: 'outline', label: copy.dev.variants[2] ?? 'Outline' },
  { variant: 'ghost', label: copy.dev.variants[3] ?? 'Ghost' },
  { variant: 'danger', label: copy.dev.variants[4] ?? 'Danger' },
];

const SIZES: ReadonlyArray<{ readonly size: ButtonSize; readonly label: string }> = [
  { size: 'sm', label: copy.dev.sizes[0] ?? 'Small' },
  { size: 'md', label: copy.dev.sizes[1] ?? 'Medium' },
  { size: 'lg', label: copy.dev.sizes[2] ?? 'Large' },
];

export function ButtonsSection() {
  const toast = useToast();
  const tap = () => toast.show(copy.dev.toastDemo);
  return (
    <Section title={copy.dev.sections.buttons}>
      <Column>
        {VARIANTS.map((item) => (
          <Button key={item.variant} title={item.label} variant={item.variant} fullWidth onPress={tap} />
        ))}
      </Column>
      <Row>
        {SIZES.map((item) => (
          <Button key={item.size} title={item.label} size={item.size} onPress={tap} />
        ))}
      </Row>
      <Row>
        <Button title={copy.dev.download} leftIcon="download-outline" onPress={tap} />
        <Button title={copy.dev.remove} variant="danger" leftIcon="trash-outline" onPress={tap} />
      </Row>
      <Row>
        <Button title={copy.dev.loading} loading onPress={tap} />
        <Button title={copy.dev.disabled} disabled onPress={tap} />
        <Button title={copy.common.retry} variant="outline" disabled onPress={tap} />
      </Row>
    </Section>
  );
}
