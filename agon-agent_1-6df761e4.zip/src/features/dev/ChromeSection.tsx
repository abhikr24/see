/** Chrome section: gradient header + floating tab bar. */

import { useState } from 'react';
import { copy } from '../../lib/copy';
import { useToast } from '../../core/toast';
import { Card, GradientHeader, TabBar, Text } from '../../components/ui';
import type { TabItems } from '../../components/ui';
import { Column, DemoText, Section } from './Section';

const TABS: TabItems = [
  { key: 'home', label: copy.dev.tabs.home, icon: 'home-outline' },
  { key: 'batches', label: copy.dev.tabs.batches, icon: 'people-outline' },
  { key: 'fees', label: copy.dev.tabs.fees, icon: 'card-outline' },
  { key: 'chat', label: copy.dev.tabs.chat, icon: 'chatbubble-outline', badge: 3 },
  { key: 'profile', label: copy.dev.tabs.profile, icon: 'person-outline' },
];

export function ChromeSection() {
  const toast = useToast();
  const [active, setActive] = useState('home');
  return (
    <Section title={copy.dev.sections.chrome}>
      <Column>
        <GradientHeader title={copy.dev.headerTitle} subtitle={copy.dev.headerSubtitle} />
        <GradientHeader
          title={copy.dev.heroTitle}
          subtitle={copy.dev.heroSubtitle}
          card={
            <Card>
              <Column>
                <Text variant="title" weight="semibold" color="ink">
                  {copy.dev.heroCardTitle}
                </Text>
                <Text variant="body">{copy.dev.heroCardBody}</Text>
                <DemoText>{copy.dev.nextClass}</DemoText>
              </Column>
            </Card>
          }
        />
        <TabBar
          items={TABS}
          activeKey={active}
          onSelect={(key) => {
            setActive(key);
            toast.show(key);
          }}
        />
      </Column>
    </Section>
  );
}
