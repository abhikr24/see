/** Feedback section: progress, rings, skeletons, empty/error states. */

import { View } from 'react-native';
import { useToast } from '../../core/toast';
import { copy } from '../../lib/copy';
import { spacing } from '../../lib/theme';
import { Card, EmptyState, ErrorState, ProgressBar, Ring, Skeleton, Text } from '../../components/ui';
import type { ProgressTone } from '../../components/ui';
import { Column, Row, Section } from './Section';

const BARS: ReadonlyArray<{ readonly value: number; readonly tone: ProgressTone }> = [
  { value: 25, tone: 'danger' },
  { value: 55, tone: 'warning' },
  { value: 78, tone: 'primary' },
  { value: 100, tone: 'success' },
];

export function FeedbackSection() {
  const toast = useToast();
  const tap = () => toast.show(copy.dev.toastDemo);
  return (
    <Section title={copy.dev.sections.feedback}>
      <Column>
        {BARS.map((bar) => (
          <ProgressBar key={`${bar.tone}-${bar.value}`} value={bar.value} tone={bar.tone} />
        ))}
      </Column>
      <Row>
        <Ring value={92} />
        <Ring value={64} size={96} tone="success" />
        <Ring value={30} size={96} tone="warning" label={copy.attendance.leave} />
      </Row>
      <Card>
        <Column>
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-1/2" />
        </Column>
      </Card>
      <View style={{ gap: spacing.xs }}>
        <Text variant="caption" color="muted">
          {copy.students.emptyTitle}
        </Text>
        <EmptyState
          icon="people-outline"
          title={copy.students.emptyTitle}
          message={copy.students.emptyMessage}
          actionLabel={copy.students.addStudent}
          onAction={tap}
        />
      </View>
      <ErrorState onRetry={tap} />
    </Section>
  );
}
