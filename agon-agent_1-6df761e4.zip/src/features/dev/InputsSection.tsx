/** Inputs section: every Input configuration and state. */

import { useState } from 'react';
import { copy } from '../../lib/copy';
import { Input } from '../../components/ui';
import { Column, Section } from './Section';

export function InputsSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('98765');
  const [email, setEmail] = useState('parent@');
  const [password, setPassword] = useState('secret123');
  return (
    <Section title={copy.dev.sections.inputs}>
      <Column>
        <Input label={copy.students.nameLabel} value={name} onChangeText={setName} placeholder={copy.students.namePlaceholder} leftIcon="person-outline" returnKeyType="next" />
        <Input label={copy.auth.phoneLabel} value={phone} onChangeText={setPhone} placeholder={copy.auth.phonePlaceholder} keyboardType="phone-pad" leftIcon="call-outline" error={copy.auth.invalidPhone} returnKeyType="next" />
        <Input label={copy.auth.emailLabel} value={email} onChangeText={setEmail} placeholder={copy.auth.emailPlaceholder} keyboardType="email-address" leftIcon="mail-outline" error={copy.auth.invalidEmail} returnKeyType="next" />
        <Input label={copy.auth.passwordLabel} value={password} onChangeText={setPassword} placeholder={copy.auth.passwordPlaceholder} secure leftIcon="lock-closed-outline" />
        <Input label={copy.auth.otpLabel} value="" onChangeText={() => undefined} placeholder={copy.auth.otpPlaceholder} keyboardType="number-pad" editable={false} />
      </Column>
    </Section>
  );
}
