/** Section wrapper for the design QA page: label + divider + content. */

import { View } from 'react-native';
import type { ReactNode } from 'react';
import { Divider, Text } from '../../components/ui';
import { spacing } from '../../lib/theme';

export interface SectionProps {
  readonly title: string;
  readonly children: ReactNode;
}

export function Section({ title, children }: SectionProps) {
  return (
    <View style={{ gap: spacing.lg }}>
      <Divider label={title} />
      {children}
    </View>
  );
}

export function Row({ children }: { readonly children: ReactNode }) {
  return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md, alignItems: 'center' }}>{children}</View>;
}

export function Column({ children }: { readonly children: ReactNode }) {
  return <View style={{ gap: spacing.md }}>{children}</View>;
}

export function DemoText({ children }: { readonly children: string }) {
  return (
    <Text variant="caption" color="muted">
      {children}
    </Text>
  );
}
