/** Sheet section: bottom sheet demo with backdrop + drag handle. */

import { useState } from 'react';
import { copy } from '../../lib/copy';
import { Button, Sheet, Text } from '../../components/ui';
import { Column, Section } from './Section';

export function SheetSection() {
  const [open, setOpen] = useState(false);
  return (
    <Section title={copy.dev.sections.sheet}>
      <Column>
        <Button title={copy.dev.openSheet} variant="secondary" leftIcon="chevron-up-outline" onPress={() => setOpen(true)} />
      </Column>
      <Sheet visible={open} onClose={() => setOpen(false)} title={copy.dev.sheetTitle}>
        <Column>
          <Text variant="body">{copy.dev.sheetBody}</Text>
          <Button title={copy.dev.closeSheet} fullWidth onPress={() => setOpen(false)} />
        </Column>
      </Sheet>
    </Section>
  );
}
