/** Surfaces section: cards, chips, badges, avatars, dividers. */

import { useState } from 'react';
import { View } from 'react-native';
import { useToast } from '../../core/toast';
import { copy } from '../../lib/copy';
import { spacing } from '../../lib/theme';
import { Avatar, Badge, Button, Card, Chip, Divider, Text } from '../../components/ui';
import type { BadgeTone } from '../../components/ui';
import { Column, DemoText, Row, Section } from './Section';

const TONES: readonly BadgeTone[] = ['primary', 'success', 'warning', 'danger', 'info', 'neutral'];

export function SurfacesSection() {
  const toast = useToast();
  const [selected, setSelected] = useState(0);
  const tap = () => toast.show(copy.dev.toastDemo);
  return (
    <Section title={copy.dev.sections.surfaces}>
      <Column>
        <Card>
          <Column>
            <Text variant="title" weight="semibold" color="ink">
              {copy.dev.cardTitle}
            </Text>
            <Text variant="body">{copy.dev.cardBody}</Text>
          </Column>
        </Card>
        <Card onPress={tap}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.md }}>
            <Text variant="body" weight="medium" color="ink">
              {copy.dev.viewDetails}
            </Text>
            <Button title={copy.common.continue} size="sm" onPress={tap} />
          </View>
        </Card>
      </Column>
      <DemoText>{copy.dev.chipFilters.join(' / ')}</DemoText>
      <Row>
        {copy.dev.chipFilters.map((label, index) => (
          <Chip key={label} label={label} selected={selected === index} onPress={() => setSelected(index)} />
        ))}
      </Row>
      <Row>
        <Chip label={copy.dev.download} leftIcon="download-outline" onPress={tap} />
        <Chip label={copy.fees.pendingAmount} />
      </Row>
      <Row>
        {TONES.map((tone) => (
          <Badge key={tone} label={tone} tone={tone} />
        ))}
      </Row>
      <Row>
        <Badge label={3} tone="danger" />
        <Badge label={copy.attendance.present} tone="success" />
        <Badge label={copy.attendance.absent} tone="danger" />
      </Row>
      <Row>
        <Avatar name={copy.dev.names[0] ?? 'A S'} size="sm" />
        <Avatar name={copy.dev.names[1] ?? 'D P'} size="md" />
        <Avatar name={copy.dev.names[2] ?? 'K S'} size="lg" />
        <Avatar name={copy.dev.names[3] ?? 'M I'} uri={copy.dev.avatarPhoto} size="lg" />
      </Row>
      <Column>
        <Divider />
        <Divider label={copy.common.or} />
      </Column>
    </Section>
  );
}
