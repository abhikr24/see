/** Typography section: every Text variant, weight and colour. */

import { copy } from '../../lib/copy';
import { Text } from '../../components/ui';
import type { TextColor, TextVariant, TextWeight } from '../../components/ui';
import { Column, DemoText, Row, Section } from './Section';

const VARIANTS: readonly TextVariant[] = ['h1', 'h2', 'title', 'body', 'caption', 'label'];
const WEIGHTS: readonly TextWeight[] = ['regular', 'medium', 'semibold', 'bold'];
const COLOURS: readonly TextColor[] = [
  'ink',
  'body',
  'muted',
  'faint',
  'primary',
  'success',
  'warning',
  'danger',
  'info',
];

export function TypographySection() {
  return (
    <Section title={copy.dev.sections.typography}>
      <Column>
        {VARIANTS.map((variant) => (
          <Text key={variant} variant={variant} weight="semibold" color="ink">
            {`${variant}: ${copy.dev.sample}`}
          </Text>
        ))}
      </Column>
      <DemoText>{copy.dev.sections.typography}</DemoText>
      <Row>
        {WEIGHTS.map((weight, index) => (
          <Text key={weight} variant="title" weight={weight} color="ink">
            {copy.dev.weights[index] ?? weight}
          </Text>
        ))}
      </Row>
      <Column>
        {COLOURS.map((color) => (
          <Text key={color} variant="body" weight="medium" color={color}>
            {`${color}: ${copy.dev.sample}`}
          </Text>
        ))}
      </Column>
    </Section>
  );
}
