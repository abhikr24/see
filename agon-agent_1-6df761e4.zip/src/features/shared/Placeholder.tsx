/**
 * Shared placeholder screen used by every thin route file until the first
 * real features land. Reads copy + theme like every other screen.
 */

import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { Button, Screen, Text } from '../../components/ui';
import type { IconName } from '../../components/ui';
import { EmptyState } from '../../components/ui/EmptyState';
import { copy } from '../../lib/copy';
import { routes } from '../../lib/nav';
import { spacing } from '../../lib/theme';

export interface PlaceholderProps {
  readonly title: string;
  readonly message: string;
  readonly icon?: IconName;
}

export function Placeholder({ title, message, icon }: PlaceholderProps) {
  const router = useRouter();
  return (
    <Screen>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <EmptyState title={title} message={message} icon={icon} />
        <View style={{ marginTop: spacing.xl, alignItems: 'center', gap: spacing.sm }}>
          <Text variant="caption" color="muted">
            {copy.dev.heroSubtitle}
          </Text>
          <Button title={copy.dev.title} onPress={() => router.push(routes.devComponents)} />
        </View>
      </View>
    </Screen>
  );
}
