/**
 * Pure formatting helpers. Deterministic on every platform (no Intl
 * dependency, so Hermes, JSC and web all render identical output).
 * All pure, all unit-testable.
 */

const MONTHS = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
] as const;

type DateInput = Date | string | number;

function toDate(value: DateInput): Date {
  return value instanceof Date ? value : new Date(value);
}

/** Indian digit grouping: last 3 digits, then groups of 2. */
function groupIndianDigits(digits: string): string {
  if (digits.length <= 3) {
    return digits;
  }
  const lastThree = digits.slice(-3);
  const rest = digits.slice(0, -3);
  const pairs: string[] = [];
  let i = rest.length;
  while (i > 0) {
    pairs.unshift(rest.slice(Math.max(0, i - 2), i));
    i -= 2;
  }
  return `${pairs.join(',')},${lastThree}`;
}

/**
 * Indian rupees with Indian digit grouping: inr(124500) -> "Rs.1,24,500".
 * No decimals unless asked: inr(124500, 2) -> "Rs.1,24,500.00".
 */
export function inr(amount: number, decimals = 0): string {
  const sign = amount < 0 ? '-' : '';
  const places = Math.max(0, Math.floor(decimals));
  const fixed = Math.abs(amount).toFixed(places);
  const dot = fixed.indexOf('.');
  const intPart = dot === -1 ? fixed : fixed.slice(0, dot);
  const fracPart = dot === -1 ? '' : fixed.slice(dot);
  return `${sign}\u20B9${groupIndianDigits(intPart)}${fracPart}`;
}

/** Percentage with no decimals: pct(92) -> "92%". */
export function pct(value: number): string {
  return `${Math.round(value)}%`;
}

/** Short date: dateShort(new Date(2026, 10, 12)) -> "12 Nov 2026". */
export function dateShort(value: DateInput): string {
  const date = toDate(value);
  return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

/** Short time: timeShort(new Date(2026, 10, 12, 16, 0)) -> "4:00 PM". */
export function timeShort(value: DateInput): string {
  const date = toDate(value);
  const hours = date.getHours();
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const suffix = hours < 12 ? 'AM' : 'PM';
  const twelve = hours % 12 === 0 ? 12 : hours % 12;
  return `${twelve}:${minutes} ${suffix}`;
}

/**
 * Relative time: relTime(twoHoursAgo) -> "2 hours ago".
 * Handles future dates too (-> "in 3 days"). Anything under 45 seconds
 * is "just now".
 */
export function relTime(value: DateInput, nowValue: DateInput = new Date()): string {
  const then = toDate(value).getTime();
  const now = toDate(nowValue).getTime();
  const diffSeconds = Math.round((now - then) / 1000);
  const abs = Math.abs(diffSeconds);
  const future = diffSeconds < 0;

  const unit = (count: number, word: string): string => {
    const label = `${count} ${word}${count === 1 ? '' : 's'}`;
    return future ? `in ${label}` : `${label} ago`;
  };

  if (abs < 45) {
    return 'just now';
  }
  if (abs < 90) {
    return future ? 'in a minute' : 'a minute ago';
  }
  const minutes = Math.round(abs / 60);
  if (minutes < 60) {
    return unit(minutes, 'minute');
  }
  const hours = Math.round(minutes / 60);
  if (hours < 24) {
    return unit(hours, 'hour');
  }
  const days = Math.round(hours / 24);
  if (days < 7) {
    return unit(days, 'day');
  }
  const weeks = Math.round(days / 7);
  if (weeks < 5) {
    return unit(weeks, 'week');
  }
  const months = Math.round(days / 30);
  if (months < 12) {
    return unit(months, 'month');
  }
  return unit(Math.round(days / 365), 'year');
}
