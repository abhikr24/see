/**
 * Typed route paths for GuruFlow. Screens navigate with these constants
 * instead of string literals, so a renamed route breaks the build
 * instead of failing silently at runtime.
 */

export const routes = {
  home: '/',
  auth: '/(auth)',
  pending: '/(pending)',
  owner: '/(owner)',
  teacher: '/(teacher)',
  student: '/(student)',
  parent: '/(parent)',
  devComponents: '/dev/components',
} as const;

export type AppRoute = (typeof routes)[keyof typeof routes];
