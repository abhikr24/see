/**
 * GuruFlow design tokens — the single source of truth for colour, type,
 * spacing, radii and shadow. Every component reads from here.
 *
 * Rule: no colour value may appear anywhere else in `app/` or `src/`.
 * Components use NativeWind utilities for layout and these tokens
 * (via `style`) for every colour, radius and mandated measurement.
 */

import type { TextStyle, ViewStyle } from 'react-native';

export const colors = {
  primary: '#1E3A8A',
  primaryDark: '#101B4C',
  primarySoft: '#E8EDFB',
  accent: '#F59E0B',
  accentSoft: '#FEF3C7',
  background: '#F5F6FA',
  surface: '#FFFFFF',
  ink: '#101B4C',
  body: '#3C4767',
  muted: '#6B7590',
  faint: '#9AA3BC',
  line: '#E3E8F3',
  success: '#16A34A',
  successSoft: '#E5F6EB',
  warning: '#B45309',
  warningSoft: '#FEF3C7',
  danger: '#DC2626',
  dangerSoft: '#FDEAEA',
  info: '#0284C7',
  infoSoft: '#E0F2FE',
  overlay: 'rgba(16, 27, 76, 0.5)',
  shimmer: '#EFF2F8',
  white: '#FFFFFF',
  transparent: 'transparent',
} as const;

export const radii = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  sheet: 28,
  tab: 28,
  full: 9999,
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  card: 18,
  screen: 20,
} as const;

export const fontSizes = {
  h1: 30,
  h2: 24,
  title: 18,
  body: 15,
  caption: 13,
  label: 12,
} as const;

export const lineHeights = {
  h1: 38,
  h2: 32,
  title: 26,
  body: 22,
  caption: 18,
  label: 16,
} as const;

export const fontWeights: Record<'regular' | 'medium' | 'semibold' | 'bold', TextStyle['fontWeight']> = {
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
};

type Shadow = Pick<ViewStyle, 'shadowColor' | 'shadowOffset' | 'shadowOpacity' | 'shadowRadius'> & {
  elevation: number;
};

export const shadows: Record<'card' | 'float' | 'sheet', Shadow> = {
  card: {
    shadowColor: '#101B4C',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 2,
  },
  float: {
    shadowColor: '#101B4C',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.16,
    shadowRadius: 24,
    elevation: 8,
  },
  sheet: {
    shadowColor: '#101B4C',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 12,
  },
};

export const gradients = {
  header: ['#101B4C', '#1E3A8A'] as const,
};

/** Minimum touch-target edge, in points. */
export const hit = 44;

export type Colors = typeof colors;
export type Radii = typeof radii;
export type Spacing = typeof spacing;
export type FontSizes = typeof fontSizes;
