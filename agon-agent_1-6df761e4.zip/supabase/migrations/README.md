# Migrations

One numbered SQL file per schema change: `0001_auth_profiles.sql`,
`0002_batches.sql`, and so on. Each migration is applied once, in order.

Rules:

- Migrations are append-only — never edit a migration that has shipped.
- After adding a migration, regenerate `../schema.sql` so it always
  matches the current shape of the database.
- Seeds in `../seed.sql` must keep working after every migration.

No migrations yet — the first lands in P2 with the auth contract.
