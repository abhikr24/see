-- GuruFlow database schema.
--
-- Foundation only: no tables yet. P2 adds the first migration alongside
-- the auth + profiles contracts, and mirrors it here as the readable
-- record of the current schema.
--
-- Convention: every change ships as a numbered file in `migrations/`,
-- then this file is regenerated to match.

-- No statements yet.
