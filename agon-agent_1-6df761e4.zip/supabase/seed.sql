-- GuruFlow seed data for local development.
--
-- Foundation only: no rows yet. P2 seeds demo roles (owner, teacher,
-- student, parent) once the profiles contract exists.
--
-- Convention: seeds are idempotent (safe to run more than once) and
-- reference only objects created in `schema.sql`.

-- No statements yet.
