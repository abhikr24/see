import type { Backend } from '../../core/contracts/ports';
import { attendanceRepo, batchRepo, subjectRepo, timetableRepo } from './academics';
import { analyticsRepo, exportRepo, leadRepo, storagePort, subscriptionRepo } from './business';
import { doubtRepo, meetingRepo, noticeRepo, notificationRepo, realtimePort } from './communication';
import { assignmentRepo, examRepo, markRepo, resultRepo, submissionRepo } from './coursework';
import { createDb } from './db';
import { leaveRepo } from './leave';
import { feeRepo, paymentGateway, paymentRepo, receiptRepo } from './finance';
import { materialRepo, practiceRepo } from './learning';
import { guardianRepo, staffRepo, studentRepo } from './people';
import { progressPort } from './progress';
import { bindAutosave, readLocal, restore } from './persist';
import { SEED, seed } from './seed';
import { ensureGuardians } from './seed-guardians';
import { familyRepo } from './family';
import { ensureHomework } from './seed-homework';
import { ensureNotices } from './seed-notices';
import { ensureProgress } from './seed-progress';
import { ensureStudentExtras } from './seed-student';
import { PARENT_PREVIEW, seedParentPreview } from './seed-parent-preview';
import { authPort, branchRepo, instituteRepo, invitationRepo, membershipRepo } from './tenant';

export { SEED } from './seed';
export { MEMORY_PASSWORD } from './tenant';

/**
 * Reference backend: every port implemented over plain in-process maps.
 * Data lives in memory. With `persist`, a local snapshot survives a reload
 * so an added student is still there after a refresh. It is not a production backend.
 */
export function createMemoryBackend(options: { seeded?: boolean; persist?: boolean } = {}): Backend {
  let db = createDb();
  const raw = options.persist ? readLocal() : null;
  const restored = raw ? restore(db, raw) : false;
  if (!restored) {
    if (raw) db = createDb();
    if (options.seeded ?? true) seed(db);
  } else {
    ensureGuardians(db);
    ensureHomework(db);
    ensureProgress(db);
    ensureStudentExtras(db);
    ensureNotices(db);
  }
  if (process.env.EXPO_PUBLIC_PARENT_PREVIEW === 'true' && process.env.EXPO_PUBLIC_BACKEND === 'memory') {
    seedParentPreview(db);
    db.session.userId = PARENT_PREVIEW.userId;
  }
  if (options.persist) bindAutosave(db);
  return {
    name: 'memory',
    auth: authPort(db),
    institutes: instituteRepo(db),
    branches: branchRepo(db),
    memberships: membershipRepo(db),
    invitations: invitationRepo(db),
    staff: staffRepo(db),
    leaveRequests: leaveRepo(db),
    students: studentRepo(db),
    guardians: guardianRepo(db),
    batches: batchRepo(db),
    subjects: subjectRepo(db),
    timetable: timetableRepo(db),
    attendance: attendanceRepo(db),
    assignments: assignmentRepo(db),
    submissions: submissionRepo(db),
    exams: examRepo(db),
    marks: markRepo(db),
    results: resultRepo(db),
    materials: materialRepo(db),
    practice: practiceRepo(db),
    fees: feeRepo(db),
    payments: paymentRepo(db),
    receipts: receiptRepo(db),
    notices: noticeRepo(db),
    notifications: notificationRepo(db),
    doubts: doubtRepo(db),
    meetings: meetingRepo(db),
    leads: leadRepo(db),
    analytics: analyticsRepo(db),
    subscriptions: subscriptionRepo(db),
    exports: exportRepo(db),
    storage: storagePort(db),
    paymentGateway: paymentGateway(db),
    realtime: realtimePort(db),
    progress: progressPort(db),
    family: familyRepo(db),
  };
}

/** The institute the seeded memory backend opens on. */
export const MEMORY_DEFAULT_INSTITUTE_ID = SEED.instituteId;
