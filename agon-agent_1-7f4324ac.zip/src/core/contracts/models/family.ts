import type { ID, ISODate, ISODateTime, Money, TenantEntity } from './common';
import type { PaymentMethod } from './finance';

/** A parent's request for their child to be away. Reaches the affected teachers and the owner. */
export type FamilyLeaveType = 'sick' | 'family' | 'personal' | 'other';
export type FamilyLeaveStatus = 'pending' | 'approved' | 'rejected' | 'cancelled';

export interface StudentLeaveRequest extends TenantEntity {
  studentId: ID;
  requestedBy: ID;
  leaveType: FamilyLeaveType;
  fromDate: ISODate;
  toDate: ISODate;
  /** Inclusive calendar days, computed once when the request is submitted. */
  days: number;
  reason: string;
  /** Batches whose timetable falls inside the leave dates. */
  affectedBatchIds: ID[];
  /** Number of scheduled classes the leave covers. */
  affectedClassCount: number;
  status: FamilyLeaveStatus;
  reviewNote: string | null;
  reviewedAt: ISODateTime | null;
}

/**
 * An online payment attempt. One pending row per installment at a time; a retry reuses it.
 * Only a confirmed gateway proof turns a row into a completed Payment.
 */
export interface FeePayment extends TenantEntity {
  studentId: ID;
  installmentId: ID;
  amount: Money;
  provider: string;
  providerOrderId: string;
  status: 'pending' | 'completed' | 'failed';
  paymentId: ID | null;
  failureReason: string | null;
}

/** One payment as the family sees it. */
export interface FamilyPayment {
  id: ID;
  studentId: ID;
  installmentId: ID | null;
  label: string;
  amount: Money;
  method: PaymentMethod;
  referenceNo: string | null;
  paidAt: ISODateTime;
  receiptId: ID | null;
  receiptNo: string | null;
}

/** A receipt with the payment it was issued for, read together so they can be compared. */
export interface FamilyReceipt {
  receiptId: ID;
  receiptNo: string;
  studentId: ID;
  studentName: string;
  instituteName: string;
  instituteCity: string | null;
  termLabel: string;
  amount: Money;
  method: PaymentMethod;
  referenceNo: string | null;
  paymentId: ID;
  paidAt: ISODateTime;
  issuedAt: ISODateTime;
}

/** A teacher who takes one of the child's classes. */
export interface FamilyTeacher {
  id: ID;
  name: string;
  userId: ID | null;
  subjectName: string;
  batchId: ID;
  batchName: string;
}

export interface LeaveClassCount {
  batchId: ID;
  batchName: string;
  subjectName: string;
  sessions: number;
}

export interface LeavePreview {
  days: number;
  classCount: number;
  classes: LeaveClassCount[];
}

/** A meeting request as the parent sees it, with the teacher's reply. */
export interface FamilyMeeting {
  id: ID;
  studentId: ID;
  teacherId: ID;
  teacherName: string;
  preferredAt: ISODateTime | null;
  status: 'pending' | 'accepted' | 'declined' | 'completed' | 'cancelled';
  responseNote: string | null;
  respondedAt: ISODateTime | null;
  reason: string | null;
  createdAt: ISODateTime;
}
