import type { ID, ISODate } from './common';
import type { AttendanceStatus } from './academics';

export interface ParentUpdate {
  id: ID;
  kind: 'homework' | 'attendance' | 'notice';
  title: string;
  subtitle: string;
  body: string;
  date: string;
}
export interface ParentTerm {
  id: ID;
  studentFeeId: ID;
  label: string;
  amount: number;
  paidAmount: number;
  remaining: number;
  dueDate: ISODate;
}
export interface ParentChildSummary {
  id: ID;
  name: string;
  photoUrl: string | null;
  classLabel: string;
  instituteName: string;
  attendancePercent: number | null;
  averagePercent: number | null;
  dueNow: number;
  totalOutstanding: number;
  attendance: { id: ID; date: ISODate; status: AttendanceStatus }[];
  trend: { id: ID; label: string; date: ISODate; percent: number }[];
  improvement: number | null;
  updates: ParentUpdate[];
  terms: ParentTerm[];
  nextFee: ParentTerm | null;
}
export interface ParentSummary {
  parentName: string;
  parentPhotoUrl: string | null;
  month: string;
  asOf: ISODate;
  children: ParentChildSummary[];
}
