/**
 * Notice rules shared by every adapter and by the composer form. Pure: no
 * storage, no React. An adapter decides *who the people are*; this module
 * decides what a valid notice is and who may read one.
 */
import type { ID, Notice, NoticeAudienceRole, PublishNoticeInput, Role } from './models';

export const NOTICE_TITLE_MAX = 80;
export const NOTICE_BODY_MAX = 500;
/** `settings.features[NOTICE_ALERTS_FEATURE]` — `false` means a notice is listed but nobody is notified. */
export const NOTICE_ALERTS_FEATURE = 'noticeAlerts';
/** `AppNotification.type` of the row each recipient gets. */
export const NOTICE_NOTIFICATION_TYPE = 'notice_published';
/** Characters of the body carried in the notification. The full text stays on the notice. */
export const NOTICE_NOTIFICATION_BODY_MAX = 140;

/** Notice alerts are on unless the institute has switched them off. Both adapters and the composer ask here. */
export function noticeAlertsOn(features: Record<string, boolean> | null | undefined): boolean {
  return features?.[NOTICE_ALERTS_FEATURE] !== false;
}

export const NOTICE_AUDIENCE_ROLES: readonly NoticeAudienceRole[] = ['student', 'parent', 'teacher'];
export const NOTICE_CATEGORIES: readonly Notice['category'][] = [
  'general', 'academic', 'exam', 'fee', 'holiday', 'event', 'urgent',
];

export type NoticeField = 'title' | 'body' | 'audience' | 'batchId' | 'category' | 'eventOn';
export type NoticeValidationErrors = Partial<Record<NoticeField, string>>;

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

function isRealDate(value: string): boolean {
  if (!ISO_DATE.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

/** Field → message for everything wrong with a notice. Empty object = publishable. */
export function getNoticeValidationErrors(input: PublishNoticeInput): NoticeValidationErrors {
  const errors: NoticeValidationErrors = {};
  const title = input.title.trim();
  const body = input.body.trim();
  if (!title) errors.title = 'Give the notice a title';
  else if (title.length > NOTICE_TITLE_MAX) errors.title = `Keep the title under ${NOTICE_TITLE_MAX} characters`;
  if (!body) errors.body = 'Write the notice';
  else if (body.length > NOTICE_BODY_MAX) errors.body = `Keep the notice under ${NOTICE_BODY_MAX} characters`;

  const audience = input.audience ?? [];
  if (audience.length === 0) errors.audience = 'Choose who should get this notice';
  else if (audience.some((role) => !NOTICE_AUDIENCE_ROLES.includes(role))) {
    errors.audience = 'A notice can go to students, parents or teachers';
  }

  const category = input.category ?? 'general';
  if (!NOTICE_CATEGORIES.includes(category)) errors.category = 'Choose a category';
  if (category === 'event') {
    if (!input.eventOn) errors.eventOn = 'Pick the day of the event';
    else if (!isRealDate(input.eventOn)) errors.eventOn = 'That is not a valid date';
  }
  return errors;
}

/** The selected roles in a stable order, without repeats. */
export function normaliseAudience(audience: readonly NoticeAudienceRole[]): NoticeAudienceRole[] {
  return NOTICE_AUDIENCE_ROLES.filter((role) => audience.includes(role));
}

/** The short text a recipient's notification carries. */
export function noticeNotificationBody(body: string): string {
  const flat = body.trim().replace(/\s+/g, ' ');
  if (flat.length <= NOTICE_NOTIFICATION_BODY_MAX) return flat;
  return `${flat.slice(0, NOTICE_NOTIFICATION_BODY_MAX - 1).trimEnd()}…`;
}

export interface NoticeReader {
  userId: ID | null;
  /** The reader's active role in the notice's institute; null = not a member. */
  role: Role | null;
  /** Batches that are "theirs": taught (teacher) or attended by them / their children (student, parent). */
  batchIds: ReadonlySet<ID>;
  now: string;
}

/**
 * The one read rule, mirrored by the `notices` row policy in migration 0008:
 * staff read everything, an author reads their own, and everyone else reads a
 * published, unexpired notice addressed to their role and (if batch-bound) to
 * one of their batches.
 */
export function canReadNotice(notice: Notice, reader: NoticeReader): boolean {
  if (!reader.role) return false;
  if (reader.role === 'owner' || reader.role === 'admin') return true;
  if (reader.userId && notice.createdBy === reader.userId) return true;
  if (!notice.publishedAt || notice.publishedAt > reader.now) return false;
  if (notice.expiresAt && notice.expiresAt <= reader.now) return false;
  if (!notice.audience.includes(reader.role)) return false;
  return notice.batchId === null || reader.batchIds.has(notice.batchId);
}
