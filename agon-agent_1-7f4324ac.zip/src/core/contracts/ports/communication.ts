import type {
  AppNotification,
  Conversation,
  Doubt,
  DoubtStatus,
  ID,
  ISODateTime,
  MeetingRequest,
  MeetingStatus,
  NewEntity,
  Notice,
  PublishNoticeInput,
  PublishNoticeResult,
  RealtimeEvent,
  RealtimeStatus,
  RealtimeTopic,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo, ReadRepo } from './common';

/**
 * `list` and `get` return only what the caller may read: owners and admins
 * everything; everyone else published, unexpired notices addressed to their
 * role and — when the notice is for one batch — to a batch of theirs.
 */
export interface NoticeRepo extends CrudRepo<Notice, 'title'> {
  /**
   * Composer path (owner, admin, teacher): stores a published notice and, when
   * the institute's `settings.features.noticeAlerts` is on, one in-app
   * notification for each person in the chosen audience. Never the sender.
   */
  broadcast(instituteId: ID, input: PublishNoticeInput): Promise<PublishNoticeResult>;
  publish(instituteId: ID, id: ID): Promise<Notice>;
  setPinned(instituteId: ID, id: ID, pinned: boolean): Promise<Notice>;
}

/** The caller's own inbox, plus sending to others. */
export interface NotificationRepo {
  list(instituteId: ID, query?: ListQuery<AppNotification>): Promise<Page<AppNotification>>;
  unreadCount(instituteId: ID): Promise<number>;
  markRead(instituteId: ID, id: ID): Promise<AppNotification>;
  /** Returns how many were marked. */
  markAllRead(instituteId: ID): Promise<number>;
  /** Removes one of the caller's own notifications from their inbox for good. */
  dismiss(instituteId: ID, id: ID): Promise<void>;
  send(instituteId: ID, input: NewEntity<AppNotification, 'userId' | 'title'>): Promise<AppNotification>;
}

export interface DoubtRepo extends ReadRepo<Doubt> {
  ask(instituteId: ID, input: NewEntity<Doubt, 'batchId' | 'studentId' | 'question'>): Promise<Doubt>;
  answer(instituteId: ID, id: ID, answer: string): Promise<Doubt>;
  setStatus(instituteId: ID, id: ID, status: DoubtStatus): Promise<Doubt>;
}

export interface MeetingResponse {
  status: Exclude<MeetingStatus, 'pending'>;
  scheduledAt?: ISODateTime | null;
  note?: string | null;
}

/** Family ↔ teacher contact: meeting requests and the message threads around them. */
export interface MeetingRepo extends ReadRepo<MeetingRequest> {
  request(instituteId: ID, input: NewEntity<MeetingRequest, 'studentId' | 'teacherId'>): Promise<MeetingRequest>;
  respond(instituteId: ID, id: ID, response: MeetingResponse): Promise<MeetingRequest>;
  /** Threads the caller takes part in, most recent first. */
  listConversations(instituteId: ID, query?: ListQuery<Conversation>): Promise<Page<Conversation>>;
  startConversation(instituteId: ID, input: NewEntity<Conversation, 'participantIds'>): Promise<Conversation>;
  sendMessage(instituteId: ID, conversationId: ID, body: string): Promise<Conversation>;
}

export interface RealtimeSubscription {
  topic: RealtimeTopic;
  unsubscribe(): Promise<void>;
}

/** Live change feed. Events carry ids only; read the record through its repo. */
export interface RealtimePort {
  status(instituteId: ID): Promise<RealtimeStatus>;
  subscribe(
    instituteId: ID,
    topic: RealtimeTopic,
    onEvent: (event: RealtimeEvent) => void,
  ): Promise<RealtimeSubscription>;
}
