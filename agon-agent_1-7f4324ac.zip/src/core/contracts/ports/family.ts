import type { FamilyLeaveType, FamilyMeeting, FamilyPayment, FamilyReceipt, FamilyTeacher, ID, ISODate, LeavePreview, StudentLeaveRequest } from '../models';

/**
 * Everything a parent does for one child: fees, receipts, leave and meetings.
 * Every method takes the child id and fails closed (NOT_FOUND) unless that child is linked to the caller.
 */
export interface FamilyRepo {
  paymentHistory(instituteId: ID, studentId: ID): Promise<FamilyPayment[]>;
  /** Only a receipt whose student is linked to the caller. The amount must match its payment. */
  receipt(instituteId: ID, receiptId: ID): Promise<FamilyReceipt>;
  teachers(instituteId: ID, studentId: ID): Promise<FamilyTeacher[]>;
  previewLeave(instituteId: ID, studentId: ID, fromDate: ISODate, toDate: ISODate): Promise<LeavePreview>;
  submitLeave(
    instituteId: ID,
    input: { studentId: ID; leaveType: FamilyLeaveType; fromDate: ISODate; toDate: ISODate; reason: string },
  ): Promise<StudentLeaveRequest>;
  leaveRequests(instituteId: ID, studentId: ID): Promise<StudentLeaveRequest[]>;
  /** The teacher/owner queue: a teacher sees requests touching their batches, the owner sees all. */
  leaveQueue(instituteId: ID): Promise<StudentLeaveRequest[]>;
  meetings(instituteId: ID, studentId: ID): Promise<FamilyMeeting[]>;
  requestMeeting(
    instituteId: ID,
    input: { studentId: ID; teacherId: ID; preferredDate: ISODate; note: string },
  ): Promise<FamilyMeeting>;
}
