import type {
  FeePlanView,
  FeeStatement,
  FeeStructure,
  FeeSummary,
  ID,
  ISODate,
  Installment,
  InstallmentStatus,
  Money,
  NewEntity,
  Payment,
  PaymentMethod,
  PaymentOrder,
  Receipt,
  Refund,
  SavePlanInput,
  SavePlanResult,
  StudentFee,
  Upsert,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { FeeOverview } from '../fee-collection';
import type { ReadRepo } from './common';
export type { FeeOverview, FeeTotals } from '../fee-collection';

export interface AssignFeeInput {
  studentId: ID;
  feeStructureId: ID;
  discountAmount?: Money;
  discountReason?: string | null;
  /** Due date of the first installment. Defaults to today. */
  firstDueDate?: ISODate;
}

export interface FeeRepo {
  listStructures(instituteId: ID, query?: ListQuery<FeeStructure>): Promise<Page<FeeStructure>>;
  saveStructure(
    instituteId: ID,
    input: Upsert<FeeStructure, 'name' | 'academicYear' | 'totalAmount'>,
  ): Promise<FeeStructure>;
  listStudentFees(instituteId: ID, query?: ListQuery<StudentFee>): Promise<Page<StudentFee>>;
  /** Gives a student a fee structure and generates its installments. */
  assign(instituteId: ID, input: AssignFeeInput): Promise<StudentFee>;
  listInstallments(
    instituteId: ID,
    filter?: { studentId?: ID; studentFeeId?: ID; status?: InstallmentStatus },
  ): Promise<Installment[]>;
  waiveInstallment(instituteId: ID, installmentId: ID): Promise<Installment>;
  summary(instituteId: ID): Promise<FeeSummary>;
  /** Paisa-exact dashboard, dues and recent payments from one reconciled read. */
  totals(instituteId: ID): Promise<FeeOverview>;

  /** Everything the plan screen shows for one batch, in one read. */
  getPlan(instituteId: ID, batchId: ID): Promise<FeePlanView>;
  /**
   * Saves a batch plan. The instalments must add up to the total or nothing is written.
   * When payments exist on the current plan a new version is created and the old one is
   * kept, still linked to those payments; otherwise the plan is edited in place. Students
   * who already paid keep the fee they paid on, so receipts never change.
   */
  savePlan(instituteId: ID, input: SavePlanInput): Promise<SavePlanResult>;
  /**
   * The individual override: sets which of the plan's discount rows one student has.
   * Lowers that student's unpaid instalments only; the batch plan total is untouched.
   */
  applyStudentDiscounts(instituteId: ID, input: { studentId: ID; discountIds: string[] }): Promise<StudentFee>;
  /** A student's total, scholarship, paid and due. Null when they have no fee. */
  studentStatement(instituteId: ID, studentId: ID): Promise<FeeStatement | null>;
}

export interface PaymentRepo extends ReadRepo<Payment> {
  /** Records money received at the desk, updates the installment and issues a receipt. */
  record(
    instituteId: ID,
    input: NewEntity<Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'>,
  ): Promise<Payment>;
  /** Rejection reverses the completed payment and its installment allocation. */
  reject(instituteId: ID, paymentId: ID): Promise<Payment>;
  listRefunds(instituteId: ID, filter?: { paymentId?: ID; studentId?: ID }): Promise<Refund[]>;
  requestRefund(instituteId: ID, input: { paymentId: ID; amount: Money; reason?: string | null }): Promise<Refund>;
  decideRefund(instituteId: ID, refundId: ID, status: 'approved' | 'rejected' | 'processed'): Promise<Refund>;
}

export interface ReceiptRepo extends ReadRepo<Receipt> {
  getForPayment(instituteId: ID, paymentId: ID): Promise<Receipt | null>;
  /** Idempotent: returns the existing receipt if the payment already has one. */
  issue(instituteId: ID, paymentId: ID): Promise<Receipt>;
}

/** A pending online payment attempt. Exists only once a gateway has accepted the order. */
export interface PaymentIntent {
  id: ID;
  installmentId: ID;
  amount: Money;
  status: 'pending';
  checkoutUrl: string | null;
}

/** The online payment gateway (Razorpay, Stripe, …). Desk payments go through PaymentRepo. */
export interface PaymentPort {
  /**
   * Starts an online payment for one installment. Fails with NOT_IMPLEMENTED and a plain
   * message until a gateway is configured. Never returns a payment that did not happen.
   * A retry while a pending attempt exists returns that attempt, never a second one.
   */
  createIntent(instituteId: ID, input: { studentId: ID; installmentId: ID }): Promise<PaymentIntent>;
  /** Online methods switched on for this institute. Empty = online payment is off. */
  listMethods(instituteId: ID): Promise<PaymentMethod[]>;
  createOrder(instituteId: ID, input: { studentId: ID; installmentId: ID; amount: Money }): Promise<PaymentOrder>;
  getOrder(instituteId: ID, orderId: ID): Promise<PaymentOrder>;
  /** Verifies the gateway's proof of payment and records the Payment. */
  confirm(
    instituteId: ID,
    orderId: ID,
    proof: { providerPaymentId: string; signature?: string },
  ): Promise<Payment>;
}
