import React from 'react';
import { useSegments } from 'expo-router';
import { RoleTabShell } from '@/features/shell/RoleTabShell';
import { ChromelessGate } from '@/features/shell/ChromelessGate';
import { BatchOwnerGate } from '@/features/batches/BatchOwnerGate';

export default function OwnerLayout() {
  const segments = useSegments() as string[];
  if (segments.includes('batches')) return <BatchOwnerGate />;
  // Take Attendance (/(owner)/attendance/[batchId]) is full-screen: guard only, no chrome.
  if (segments[1] === 'attendance' && segments.length > 2) return <ChromelessGate group="/(owner)" />;
  // Marks entry (/(owner)/exams/[id]/marks) is full-screen
  if (segments[1] === 'exams' && segments[segments.length - 1] === 'marks') return <ChromelessGate group="/(owner)" />;
  // The fee plan form (/(owner)/fees/plan/[batchId]) is full-screen with its own sticky Save bar.
  if (segments[1] === 'fees' && segments.length > 2) return <ChromelessGate group="/(owner)" />;
  return <RoleTabShell role="owner" />;
}
