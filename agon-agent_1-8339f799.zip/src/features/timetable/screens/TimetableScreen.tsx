import React, { useMemo, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Badge, EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { ID } from '@/core/contracts/models';
import { C, LAYOUT } from '@/lib/theme';
import { ClashCards } from '../components/ClashCards';
import { MovePeriodSheet } from '../components/MovePeriodSheet';
import { PERIOD_ROW_HEIGHT, PeriodRow } from '../components/PeriodRow';
import { WeekStrip } from '../components/WeekStrip';
import { usePeriodDrag } from '../hooks/usePeriodDrag';
import { useTimetableBoard } from '../hooks/useTimetableBoard';
import { DAY_NAMES, dayOfWeekOf, sortDay, todayIso, type PeriodRowView, type TeacherClash } from '../model';

/** Clears the floating tab bar plus the amber card stack. */
const BOTTOM_INSET = 108;

/**
 * The owner's timetable board: one week strip, one day of 64pt period rows,
 * drag to reorder or to move between days, and the amber clash card when the
 * schedule contradicts itself. Layout and gestures only — ordering, diffs and
 * conflict rules live in `model.ts`, saving in `useTimetableBoard`.
 */
export function TimetableScreen() {
  const board = useTimetableBoard();
  const today = useMemo(() => dayOfWeekOf(todayIso()), []);
  const [selectedDay, setSelectedDay] = useState(today);
  const [highlight, setHighlight] = useState<ID[] | null>(null);
  const [moveId, setMoveId] = useState<ID | null>(null);
  const [dismissedRooms, setDismissedRooms] = useState<string[]>([]);
  const listRef = useRef<FlatList<PeriodRowView> | null>(null);
  const highlightTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const rows = board.rowsFor(selectedDay);
  const rowsRef = useRef(rows);
  rowsRef.current = rows;
  const dayRef = useRef(selectedDay);
  dayRef.current = selectedDay;

  const dragApi = usePeriodDrag({
    rowCount: () => rowsRef.current.length,
    currentDay: () => dayRef.current,
    onReorder: (periodId, _from, to) => board.reorder(dayRef.current, periodId, to),
    onMoveDay: (periodId, day) => {
      board.moveDay(periodId, day);
      setSelectedDay(day);
    },
  });
  const dragging = dragApi.drag !== null;

  const teacherClash: TeacherClash | null =
    board.clashes.teacher.find((c) => board.blockedDays.has(c.dayOfWeek)) ?? board.clashes.teacher[0] ?? null;
  const blocking = teacherClash !== null && board.blockedDays.has(teacherClash.dayOfWeek);
  const roomClash = board.clashes.room.find((c) => !dismissedRooms.includes(c.key)) ?? null;

  const fixClash = (clash: TeacherClash) => {
    setSelectedDay(clash.dayOfWeek);
    setHighlight([clash.a.periodId, clash.b.periodId]);
    if (highlightTimer.current) clearTimeout(highlightTimer.current);
    highlightTimer.current = setTimeout(() => setHighlight(null), 2600);
    const dayRows = sortDay(board.periods.filter((p) => p.dayOfWeek === clash.dayOfWeek));
    const index = dayRows.findIndex((p) => p.id === clash.a.periodId);
    setTimeout(() => {
      listRef.current?.scrollToOffset({ offset: Math.max(0, index * PERIOD_ROW_HEIGHT - 48), animated: true });
    }, 80);
  };

  const moveRow = rows.find((row) => row.id === moveId) ?? null;
  const moveIndex = moveRow ? rows.indexOf(moveRow) : -1;
  const draggedRow = dragApi.drag ? rows.find((row) => row.id === dragApi.drag?.id) ?? null : null;

  const showInsert = (at: number): boolean => {
    const d = dragApi.drag;
    return (
      d !== null &&
      d.hoverDay === null &&
      d.hoverIndex === at &&
      at !== d.fromIndex &&
      at !== d.fromIndex + 1
    );
  };

  const renderRow = ({ item, index }: { item: PeriodRowView; index: number }) => (
    <PeriodRow
      row={item}
      first={index === 0}
      last={index === rows.length - 1}
      draggable
      dragging={dragApi.drag?.id === item.id}
      insertBefore={showInsert(index)}
      insertAfter={index === rows.length - 1 && showInsert(rows.length)}
      highlighted={highlight?.includes(item.id) ?? false}
      onDragGrant={(pageY) => dragApi.grant(item.id, index, pageY)}
      onDragMove={dragApi.move}
      onDragEnd={dragApi.end}
      onDragCancel={dragApi.cancel}
      onHandleTap={() => setMoveId(item.id)}
    />
  );

  return (
    <View ref={dragApi.setRootView} onLayout={dragApi.measure} style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, gap: 14 }}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back to home"
          onPress={() => (router.canGoBack() ? router.back() : router.replace('/(owner)' as never))}
          hitSlop={10}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start' }}
        >
          <Ionicons name="chevron-back" size={18} color={C.secondary} />
          <Text variant="body" weight={600} c={C.secondary}>
            Home
          </Text>
        </Pressable>

        <View style={{ flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12 }}>
          <View style={{ flex: 1, gap: 4 }}>
            <Text variant="h1">Timetable</Text>
            <Text variant="caption" c={C.secondary}>
              Drag a period to reorder · drop it on a day to move
            </Text>
          </View>
          {board.saving ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingBottom: 4 }}>
              <ActivityIndicator size="small" color={C.primary} />
              <Text variant="label" c={C.muted}>
                SAVING
              </Text>
            </View>
          ) : board.saveBlocked ? (
            <View style={{ paddingBottom: 4 }}>
              <Badge label="Save blocked" tone="warning" />
            </View>
          ) : null}
        </View>

        <WeekStrip
          selected={selectedDay}
          today={today}
          hoverDay={dragApi.drag?.hoverDay ?? null}
          onSelect={setSelectedDay}
          registerChip={dragApi.registerChip}
        />
      </View>

      <View ref={dragApi.setListView} onLayout={dragApi.measure} style={{ flex: 1, marginTop: 14 }}>
        {board.loading && !board.data ? (
          <View style={{ paddingHorizontal: LAYOUT.margin }}>
            <ListSkeleton rows={5} h={PERIOD_ROW_HEIGHT} />
          </View>
        ) : board.error && !board.data ? (
          <ErrorState
            title="Could not load the timetable"
            message={board.error.message}
            onRetry={() => void board.refetch()}
          />
        ) : (
          <FlatList
            ref={listRef}
            data={rows}
            keyExtractor={(row) => row.id}
            renderItem={renderRow}
            scrollEnabled={!dragging}
            onScroll={dragApi.onScroll}
            scrollEventThrottle={16}
            contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 240 }}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <EmptyState
                icon="calendar-outline"
                title={`Nothing on ${DAY_NAMES[selectedDay]}`}
                text="No batch meets on this day yet. Drag a period onto its chip above to move one here."
              />
            }
          />
        )}
      </View>

      <ClashCards
        teacher={teacherClash}
        blocking={blocking}
        room={roomClash}
        onFix={fixClash}
        onDismissRoom={(key) => setDismissedRooms((prev) => [...prev, key])}
        bottom={BOTTOM_INSET}
      />

      {dragApi.drag && draggedRow ? (
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: LAYOUT.margin,
            right: LAYOUT.margin,
            top: dragApi.drag.ghostTop,
            height: PERIOD_ROW_HEIGHT,
            zIndex: 30,
          }}
        >
          <PeriodRow row={draggedRow} first last ghost />
        </View>
      ) : null}

      <MovePeriodSheet
        row={moveRow}
        index={moveIndex}
        count={rows.length}
        selectedDay={selectedDay}
        onClose={() => setMoveId(null)}
        onNudge={(delta) => {
          if (moveRow) board.nudge(selectedDay, moveRow.id, delta);
          setMoveId(null);
        }}
        onPickDay={(day) => {
          if (moveRow) board.moveDay(moveRow.id, day);
          setMoveId(null);
          setSelectedDay(day);
        }}
      />
    </View>
  );
}
