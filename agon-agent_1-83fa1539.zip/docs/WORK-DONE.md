# Work done

## 2026-11-11 · Core contracts for the whole data model

The UI now has a typed, backend-neutral surface for every domain in the 62-table model. Nothing under `app/` or `src/core` names a table, a column or an SDK.

**Added**
- `src/core/contracts/models.ts` + `models/*.ts` – the 51 domain types as plain camelCase, plus the supporting types the ports need (`AuthSession`, `InstituteSettings`, `Teacher`, `Enrollment`, `AttendanceSheet`, `PaymentOrder`, `ExportJob`, `Student360` …).
- `src/core/contracts/ports.ts` + `ports/*.ts` – the 34 ports and the `Backend` interface that bundles them. Every method is async and takes `instituteId` first.
- `src/core/contracts/query.ts` (`ListQuery`, `Page`) and `errors.ts` (`BackendError`, 11 codes).
- `src/core/contracts/checks.ts` – one safe, read-only call per port. Keyed by port, so a port without a check does not compile.
- `src/core/backend.tsx` + `src/core/hooks/*.ts` – `BackendProvider`, `useBackend` and a hook for every port. Each returns `{ data, loading, error, refetch }` plus the domain's actions. All writes go through `hooks/mutation.ts`: snapshot → optimistic update → run → toast and reload, or roll back and error toast.
- `src/backends/memory/` – reference backend implementing all 34 ports over in-process maps, seeded with a small slice of Sunrise Coaching Classes. `src/backends/stub.ts` – every method rejects `NOT_IMPLEMENTED`; the starting point for a new adapter.
- `app/dev/contract-check.tsx` – runs the checks against any registered backend and prints pass / fail with the error code. `app/index.tsx` – landing screen linking to it.
- `docs/ADDING_A_BACKEND.md`; `npm run typecheck`.

**Verified**
- `npm run typecheck` – zero errors. `npx expo export --platform all` – builds for web, iOS and Android.
- No file over 300 lines (largest: `src/backends/memory/finance.ts`, 253).
- No backend SDK is imported anywhere; `app/` and `src/core` do not import `src/backends`.
- `/dev/contract-check`, opened directly by URL in a headless DOM against the exported web bundle: lists all 34 ports; memory backend 34/34 pass; stub backend 34/34 fail with `NOT_IMPLEMENTED`; an adapter returning the wrong shape or throwing a plain `Error` is reported as `BAD_SHAPE` / `UNTYPED_ERROR`.
- Memory backend, by a throw-away Node script (not in the repo): cross-institute get / update / remove are `NOT_FOUND`; duplicate, invalid and out-of-range inputs are rejected with `CONFLICT` / `VALIDATION`; attendance, marks → results → rank, fee assignment → payment → receipt → refund, and risk alerts opening and resolving all produce the expected figures.
- Mutation core, same script: a failed write restores the cache and raises one error toast; a successful one raises one success toast and reloads; a response that arrives after an optimistic write does not overwrite it.

**Not verified / to do**
- **There is no Supabase adapter.** Nothing reads or writes the 62 tables yet; the app runs on the in-memory backend and loses its data on reload. Writing `src/backends/supabase/` is the next step (see `docs/ADDING_A_BACKEND.md`).
- The base this was built on had no `src/`, no `app/`, no `docs/ARCHITECTURE.md` and no `docs/ADDING_A_BACKEND.md`. `query.ts` and `errors.ts` were therefore written new, not kept; if the real repo has its own versions, reconcile them.
- Expo Router is not installed: it could not be resolved from the registry (`@radix-ui/primitive@1.2.0`, a dependency of its dependencies, does not exist there). Screens sit under `app/` at their route path with default exports, and `App.tsx` maps the paths with React Navigation linking. Moving to Expo Router later means deleting that mapping; `app/index.tsx` uses `useNavigation` and would need `router.push`.
- Not run on an iOS or Android device or simulator. `npx expo lint` not run (no ESLint config installed).
- Only `useInstitute` has been rendered in a screen. The other hooks type-check and share the tested query / mutation core, but have not been exercised in a UI.
- No automated tests are checked in; there is no test runner in the project.
- Tables with no model yet: `sessions`, `user_preferences`, `student_history`, `teacher_assignments`, `batch_teachers`, `leave_requests`, `attendance_corrections`, `material_access`, `teacher_feedback`.
- `ProgressSnapshot` and `RiskAlert` have no table in migrations 0003–0008. A database backend must compute them on read or add tables.
- The risk rules (attendance below the institute minimum, exam average within 10 points of the pass mark, under 60 % of homework handed in, any overdue installment) are first guesses and live only in the memory backend.

## 2026-11-11 · Full GuruFlow data model (migrations 0003–0008, seed)

Replaced the 17-table schema with the 62-table GuruFlow model.

**Added**
- `supabase/migrations/0003_core.sql` – drops the old public tables; GLOBAL (users, profiles, user_preferences, sessions) and TENANT (institutes, memberships, invitations, branches, institute_settings); `auth.users` sync trigger; owner bootstrap trigger.
- `supabase/migrations/0004_academics.sql` – ACADEMICS, BATCHES, ATTENDANCE, HOMEWORK, EXAMS, LEARNING (35 tables).
- `supabase/migrations/0005_finance.sql` – FINANCE (6 tables).
- `supabase/migrations/0006_communication.sql` – COMMUNICATION (6 tables).
- `supabase/migrations/0007_business.sql` – BUSINESS (6 tables).
- `supabase/migrations/0008_rls.sql` – `auth_institute_ids()`, `has_role()`, `my_student_ids()` and supporting helpers; RLS on all 62 tables; `membership_guard`; grants.
- `supabase/seed.sql` – rewritten: Sunrise Coaching Classes, Patna (`SUNRISE-PAT`) with fixed UUIDs.
- `docs/DATA_MODEL.md` – tables, RLS rules, seed ID map.

**Verified** (PostgreSQL 16 and 18 via PGlite, with a stand-in `auth` schema and API roles – not yet on a real Supabase project)
- 0003–0008 and `seed.sql` run without error, on an empty database and on one holding older tables with clashing names.
- 62 tables, matching the list; each has `id uuid` pk, `created_at`, `updated_at` + trigger; the 58 tenant tables have `institute_id`; RLS on all.
- A second institute's owner sees zero Sunrise rows in every table and cannot write into Sunrise.
- Pending member sees only their own membership row; anon is denied on all tables.
- Student, parent, teacher, admin and owner each see and write only what `docs/DATA_MODEL.md` describes; only an owner can change a role.

**Not verified / to do**
- 0001 and 0002 were not available when this was written, so the full chain 0001 → 0008 has not been run together.
- Run `supabase db reset` against the real stack to confirm the seed's `auth.users` / `auth.identities` rows and password sign-in.
- App code still queries the old tables and needs updating to the new model.
- Join-by-code lookup and invitation acceptance need an RPC or edge function (see Known limits in `docs/DATA_MODEL.md`).
