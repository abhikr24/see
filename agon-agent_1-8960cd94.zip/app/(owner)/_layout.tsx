import React from 'react';
import { useSegments } from 'expo-router';
import { RoleTabShell } from '@/features/shell/RoleTabShell';
import { BatchOwnerGate } from '@/features/batches/BatchOwnerGate';

export default function OwnerLayout() {
  const segments = useSegments() as string[];
  if (segments.includes('batches')) return <BatchOwnerGate />;
  return <RoleTabShell role="owner" />;
}
