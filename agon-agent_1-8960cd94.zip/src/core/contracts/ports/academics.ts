import type {
  AttendanceRecord,
  AttendanceSession,
  AttendanceSheet,
  AttendanceStatus,
  AttendanceSummary,
  Batch,
  BatchSummary,
  BatchRosterRow,
  Classroom,
  Enrollment,
  ID,
  ISODate,
  Subject,
  Timetable,
  Upsert,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo } from './common';

export interface BatchRepo extends CrudRepo<Batch, 'name' | 'academicYear'> {
  /** Aggregated by the backend, never by a card's student-fetch loop. */
  listSummaries(instituteId: ID): Promise<BatchSummary[]>;
  listRoster(instituteId: ID, batchId: ID): Promise<BatchRosterRow[]>;
  /** Batches the caller teaches, studies in, or (as a parent) has a child in. Staff admins get all. */
  listMine(instituteId: ID): Promise<Batch[]>;
  listEnrollments(instituteId: ID, batchId: ID): Promise<Enrollment[]>;
  enroll(instituteId: ID, batchId: ID, input: { studentId: ID; rollNumber?: number | null }): Promise<Enrollment>;
  /** Marks the enrolment as left; history is kept. */
  unenroll(instituteId: ID, enrollmentId: ID): Promise<Enrollment>;
}

export type SubjectRepo = CrudRepo<Subject, 'name' | 'code'>;

export interface TimetableRepo extends CrudRepo<Timetable, 'batchId' | 'dayOfWeek' | 'startsAt' | 'endsAt'> {
  /** Periods on one weekday, ordered by start time. */
  listForDay(instituteId: ID, filter: { dayOfWeek: number; batchId?: ID; teacherId?: ID }): Promise<Timetable[]>;
  listClassrooms(instituteId: ID): Promise<Classroom[]>;
  saveClassroom(instituteId: ID, input: Upsert<Classroom, 'name'>): Promise<Classroom>;
  removeClassroom(instituteId: ID, id: ID): Promise<void>;
}

export interface AttendanceSheetInput {
  batchId: ID;
  date: ISODate;
  /** Defaults to 1. */
  period?: number;
  subjectId?: ID | null;
  teacherId?: ID | null;
  notes?: string | null;
  records: { studentId: ID; status: AttendanceStatus; remark?: string | null }[];
}

export interface AttendanceFilter {
  studentId?: ID;
  batchId?: ID;
  from?: ISODate;
  to?: ISODate;
}

export interface AttendanceRepo {
  listSessions(instituteId: ID, query?: ListQuery<AttendanceSession>): Promise<Page<AttendanceSession>>;
  getSheet(instituteId: ID, sessionId: ID): Promise<AttendanceSheet>;
  /** Creates or overwrites the roll call for (batch, date, period) in one call. */
  saveSheet(instituteId: ID, input: AttendanceSheetInput): Promise<AttendanceSheet>;
  listRecords(instituteId: ID, filter: AttendanceFilter): Promise<AttendanceRecord[]>;
  summary(instituteId: ID, filter: AttendanceFilter): Promise<AttendanceSummary>;
}
