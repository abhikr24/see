import type { Assignment, Exam, ExamQuestion, ID, Result } from '../../core/contracts/models';
import type { AssignmentRepo, ExamRepo, MarkRepo, ResultRepo, SubmissionRepo } from '../../core/contracts/ports';
import { validateNewExam } from '../../core/contracts/exam-validation';
import { crud, emit, type Db } from './db';
import * as D from './defaults';
import { defined, fail, merge, nowIso, round2, sum, todayIso } from './store';

function callerIsStudentOrParent(db: Db, instituteId: ID): boolean {
  if (!db.session.userId) return false;
  const membership = db.memberships.find(instituteId, { userId: db.session.userId, status: 'active' });
  return membership?.role === 'student' || membership?.role === 'parent';
}

function isExamPublished(db: Db, instituteId: ID, examId: ID): boolean {
  const exam = db.exams.all(instituteId).find((e) => e.id === examId);
  return exam?.status === 'published';
}

export function gradeFor(percent: number): string {
  if (percent >= 90) return 'A+';
  if (percent >= 80) return 'A';
  if (percent >= 70) return 'B';
  if (percent >= 60) return 'C';
  if (percent >= 50) return 'D';
  if (percent >= 33) return 'E';
  return 'F';
}

export function assignmentRepo(db: Db): AssignmentRepo {
  const base = crud<Assignment, 'batchId' | 'title'>(db.assignments, D.assignment);
  return {
    ...base,
    create: async (instituteId, input) => {
      db.batches.get(instituteId, input.batchId);
      if (!input.title.trim()) fail('VALIDATION', 'Title is required');
      return base.create(instituteId, { createdBy: db.session.userId, ...input });
    },
    publish: async (instituteId, id) => db.assignments.update(instituteId, id, { status: 'published' }),
    close: async (instituteId, id) => db.assignments.update(instituteId, id, { status: 'closed' }),
  };
}

export function submissionRepo(db: Db): SubmissionRepo {
  return {
    list: async (instituteId, query) => db.submissions.page(instituteId, query),
    get: async (instituteId, id) => db.submissions.get(instituteId, id),
    submit: async (instituteId, { assignmentId, studentId, content = null }) => {
      const assignment = db.assignments.get(instituteId, assignmentId);
      if (assignment.status !== 'published') fail('FORBIDDEN', 'This assignment is not open for submissions');
      const enrolled = db.enrollments.find(instituteId, { batchId: assignment.batchId, studentId, status: 'active' });
      if (!enrolled) fail('VALIDATION', 'Student is not in the batch this assignment was set for');
      const submittedAt = nowIso();
      const status = assignment.dueAt && submittedAt > assignment.dueAt ? 'late' : 'submitted';
      const existing = db.submissions.find(instituteId, { assignmentId, studentId });
      return existing
        ? db.submissions.update(instituteId, existing.id, { content, submittedAt, status })
        : db.submissions.insert(instituteId, {
            assignmentId,
            batchId: assignment.batchId,
            studentId,
            content,
            submittedAt,
            status,
          });
    },
    grade: async (instituteId, submissionId, input) => {
      const submission = db.submissions.get(instituteId, submissionId);
      const assignment = db.assignments.get(instituteId, submission.assignmentId);
      const { marksAwarded } = input;
      if (marksAwarded != null && (marksAwarded < 0 || (assignment.maxMarks !== null && marksAwarded > assignment.maxMarks))) {
        fail('VALIDATION', `Marks must be between 0 and ${assignment.maxMarks ?? 'the maximum'}`);
      }
      db.submissions.update(instituteId, submissionId, { status: 'returned' });
      const existing = db.feedback.find(instituteId, { submissionId });
      const givenBy = db.session.userId;
      const givenAt = nowIso();
      if (existing) return db.feedback.update(instituteId, existing.id, { ...defined(input), givenBy, givenAt });
      return db.feedback.insert(instituteId, {
        submissionId,
        batchId: submission.batchId,
        studentId: submission.studentId,
        teacherId: assignment.teacherId,
        marksAwarded: input.marksAwarded ?? null,
        grade: input.grade ?? null,
        comment: input.comment ?? null,
        givenBy,
        givenAt,
      });
    },
    getFeedback: async (instituteId, submissionId) => {
      db.submissions.get(instituteId, submissionId);
      return db.feedback.find(instituteId, { submissionId }) ?? null;
    },
  };
}

export function examRepo(db: Db): ExamRepo {
  const base = crud<Exam, 'batchId' | 'name'>(db.exams, D.exam);
  const results = resultRepo(db);
  return {
    ...base,
    list: async (instituteId, query) => {
      if (!callerIsStudentOrParent(db, instituteId)) return base.list(instituteId, query);
      return db.exams.page(instituteId, query, {}, (e) => e.status !== 'draft');
    },
    get: async (instituteId, id) => {
      const exam = await base.get(instituteId, id);
      if (callerIsStudentOrParent(db, instituteId) && exam.status === 'draft') fail('NOT_FOUND', 'Exam not found');
      return exam;
    },
    create: async (instituteId, input) => {
      db.batches.get(instituteId, input.batchId);
      if (input.subjectId) db.subjects.get(instituteId, input.subjectId);
      validateNewExam(
        {
          name: input.name,
          batchId: input.batchId,
          subjectId: input.subjectId ?? null,
          startsOn: input.startsOn ?? todayIso(),
          totalMarks: input.totalMarks ?? null,
        },
        todayIso(),
      );
      if (input.startsOn && input.endsOn && input.endsOn < input.startsOn) {
        fail('VALIDATION', 'An exam cannot end before it starts');
      }
      return base.create(instituteId, {
        createdBy: db.session.userId,
        startsOn: input.startsOn ?? todayIso(),
        ...input,
      });
    },
    publish: async (instituteId, id) => {
      const exam = db.exams.get(instituteId, id);
      const marks = db.marks.all(instituteId, { examId: id });
      if (marks.length > 0) {
        await results.compute(instituteId, id);
      }
      const updated = db.exams.update(instituteId, id, {
        status: 'published',
        publishedAt: exam.publishedAt ?? nowIso(),
      });
      const batch = db.batches.get(instituteId, exam.batchId);
      const enrolledIds = db.enrollments
        .all(instituteId, { batchId: exam.batchId, status: 'active' })
        .map((e) => e.studentId);
      const recipientUserIds = new Set<ID>();
      for (const studentId of enrolledIds) {
        for (const sm of db.studentMemberships.all(instituteId, { studentId })) {
          const m = db.memberships.all(instituteId, { id: sm.membershipId, status: 'active' })[0];
          if (m) recipientUserIds.add(m.userId);
        }
        for (const link of db.parentLinks.all(instituteId, { studentId })) {
          const guardian = db.guardians.all(instituteId, { id: link.guardianId })[0];
          if (guardian?.membershipId) {
            const m = db.memberships.all(instituteId, { id: guardian.membershipId, status: 'active' })[0];
            if (m) recipientUserIds.add(m.userId);
          }
        }
      }
      for (const userId of recipientUserIds) {
        const alreadySent = db.notifications
          .all(instituteId, { userId, type: 'exam_published' })
          .some((n) => n.data.examId === id);
        if (alreadySent) continue;
        const sent = db.notifications.insert(
          instituteId,
          merge(D.notification(), {
            userId,
            type: 'exam_published',
            title: `${exam.name} results published`,
            body: `Results for ${exam.name} (${batch.name}) are now available.`,
            data: { screen: 'results', examId: id, batchId: batch.id },
          }),
        );
        emit(db, instituteId, 'notifications', 'created', sent.id);
      }
      return updated;
    },
    listQuestions: async (instituteId, examId) => {
      db.exams.get(instituteId, examId);
      return db.examQuestions.all(instituteId, { examId }).sort((a, b) => a.questionNo - b.questionNo);
    },
    saveQuestion: async (instituteId, input) => {
      const { id, ...rest } = input;
      const exam = db.exams.get(instituteId, input.examId);
      if (id) return db.examQuestions.update(instituteId, id, defined(rest) as Partial<ExamQuestion>);
      if (db.examQuestions.find(instituteId, { examId: exam.id, questionNo: input.questionNo })) {
        fail('CONFLICT', `Question ${input.questionNo} already exists`);
      }
      return db.examQuestions.insert(instituteId, { ...merge(D.examQuestion(), rest), batchId: exam.batchId });
    },
    removeQuestion: async (instituteId, id) => db.examQuestions.remove(instituteId, id),
  };
}

export function markRepo(db: Db): MarkRepo {
  return {
    list: async (instituteId, query) => {
      if (!callerIsStudentOrParent(db, instituteId)) return db.marks.page(instituteId, query);
      return db.marks.page(instituteId, query, {}, (m) => isExamPublished(db, instituteId, m.examId));
    },
    get: async (instituteId, id) => {
      const mark = db.marks.get(instituteId, id);
      if (callerIsStudentOrParent(db, instituteId) && !isExamPublished(db, instituteId, mark.examId)) {
        fail('NOT_FOUND', 'Mark not found');
      }
      return mark;
    },
    saveMany: async (instituteId, examId, entries) => {
      const exam = db.exams.get(instituteId, examId);
      const enrolled = new Set(db.enrollments.all(instituteId, { batchId: exam.batchId }).map((e) => e.studentId));
      // Validate the whole sheet before writing any of it.
      for (const entry of entries) {
        db.subjects.get(instituteId, entry.subjectId);
        if (!enrolled.has(entry.studentId)) fail('VALIDATION', 'A student on this sheet is not in the exam batch');
        if (entry.maxMarks <= 0) fail('VALIDATION', 'Maximum marks must be above zero');
        if (entry.isAbsent && entry.marksObtained !== null) fail('VALIDATION', 'An absent student cannot have marks');
        if (entry.marksObtained !== null && (entry.marksObtained < 0 || entry.marksObtained > entry.maxMarks)) {
          fail('VALIDATION', `Marks must be between 0 and ${entry.maxMarks}`);
        }
      }
      return entries.map((entry) => {
        const { studentId, subjectId, marksObtained, maxMarks, isAbsent = false, remark = null } = entry;
        const percent = marksObtained === null ? null : (marksObtained / maxMarks) * 100;
        const values = {
          marksObtained,
          maxMarks,
          isAbsent,
          remark,
          grade: percent === null ? null : gradeFor(percent),
          enteredBy: db.session.userId,
        };
        const existing = db.marks.find(instituteId, { examId, studentId, subjectId });
        return existing
          ? db.marks.update(instituteId, existing.id, values)
          : db.marks.insert(instituteId, { examId, batchId: exam.batchId, studentId, subjectId, ...values });
      });
    },
  };
}

export function resultRepo(db: Db): ResultRepo {
  return {
    list: async (instituteId, query) => {
      if (!callerIsStudentOrParent(db, instituteId)) return db.results.page(instituteId, query);
      return db.results.page(instituteId, query, {}, (r) => isExamPublished(db, instituteId, r.examId));
    },
    get: async (instituteId, id) => {
      const result = db.results.get(instituteId, id);
      if (callerIsStudentOrParent(db, instituteId) && !isExamPublished(db, instituteId, result.examId)) {
        fail('NOT_FOUND', 'Result not found');
      }
      return result;
    },
    listForStudent: async (instituteId, studentId) => {
      db.students.get(instituteId, studentId);
      const restricted = callerIsStudentOrParent(db, instituteId);
      return db.results
        .all(instituteId, { studentId })
        .filter((r) => !restricted || isExamPublished(db, instituteId, r.examId))
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
    compute: async (instituteId, examId) => {
      const exam = db.exams.get(instituteId, examId);
      const marks = db.marks.all(instituteId, { examId });
      const totals = [...new Set(marks.map((m) => m.studentId))].map((studentId: ID) => {
        const own = marks.filter((m) => m.studentId === studentId);
        const totalObtained = sum(own.map((m) => m.marksObtained ?? 0));
        const totalMax = sum(own.map((m) => m.maxMarks));
        const percentage = round2((totalObtained / totalMax) * 100);
        const status: Result['status'] = own.every((m) => m.isAbsent)
          ? 'absent'
          : percentage >= exam.passPercent
            ? 'pass'
            : 'fail';
        return { studentId, totalObtained, totalMax, percentage, status };
      });
      const ranked = totals.filter((t) => t.status !== 'absent').sort((a, b) => b.totalObtained - a.totalObtained);
      return totals.map((total) => {
        // Equal totals share a rank; the next rank skips (1, 2, 2, 4).
        const ahead = ranked.filter((other) => other.totalObtained > total.totalObtained).length;
        const values = {
          ...total,
          grade: total.status === 'absent' ? null : gradeFor(total.percentage),
          rank: total.status === 'absent' ? null : ahead + 1,
        };
        const existing = db.results.find(instituteId, { examId, studentId: total.studentId });
        return existing
          ? db.results.update(instituteId, existing.id, values)
          : db.results.insert(instituteId, { examId, batchId: exam.batchId, remarks: null, ...values });
      });
    },
  };
}
