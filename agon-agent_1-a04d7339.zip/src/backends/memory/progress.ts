import type {
  AttendanceSummary,
  ID,
  InstituteSettings,
  ProgressSnapshot,
  RiskAlert,
  RiskKind,
  RiskLevel,
  StudentGoal,
  StudyTask,
} from '../../core/contracts/models';
import type { ProgressPort } from '../../core/contracts/ports';
import { attendanceRecords, summarize } from './academics';
import { currentBatchId, upsert, type Db } from './db';
import * as D from './defaults';
import { isOverdue, remaining } from './finance';
import { nowIso, round1, round2, sum } from './store';

/** Watch a student whose exam average is within this many points of the pass mark. */
const MARKS_MARGIN = 10;
/** Minimum share of set homework a student is expected to hand in. */
const HOMEWORK_MIN = 60;
const ALL_KINDS: RiskKind[] = ['low_attendance', 'low_marks', 'missing_homework', 'fee_overdue'];
const SEVERITY_ORDER: RiskLevel[] = ['none', 'low', 'medium', 'high'];

interface Measures {
  batchId: ID | null;
  attendance: AttendanceSummary;
  attendancePercent: number | null;
  examPercent: number | null;
  homeworkPercent: number | null;
  latestRank: number | null;
  feeDue: number;
  overdueInstallments: number;
  openDoubts: number;
}

type Finding = Pick<RiskAlert, 'kind' | 'severity' | 'title' | 'detail' | 'metricValue' | 'threshold'>;

function publishedResultsForStudent(db: Db, instituteId: ID, studentId: ID) {
  const publishedIds = new Set(
    db.exams
      .all(instituteId)
      .filter((e) => e.status === 'published')
      .map((e) => e.id),
  );
  return db.results
    .all(instituteId, { studentId })
    .filter((r) => publishedIds.has(r.examId))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

function measure(db: Db, instituteId: ID, studentId: ID): Measures {
  const attendance = summarize(attendanceRecords(db, instituteId, { studentId }));
  const results = publishedResultsForStudent(db, instituteId, studentId);
  const batchIds = db.enrollments.all(instituteId, { studentId, status: 'active' }).map((e) => e.batchId);
  const homework = db.assignments.all(instituteId).filter((a) => a.status !== 'draft' && batchIds.includes(a.batchId));
  const handedIn = homework.filter((a) => db.submissions.find(instituteId, { assignmentId: a.id, studentId }));
  const overdue = db.installments.all(instituteId, { studentId }).filter((x) => isOverdue(x));
  return {
    batchId: currentBatchId(db, instituteId, studentId),
    attendance,
    attendancePercent: attendance.total ? attendance.percent : null,
    examPercent: results.length ? round1(sum(results.map((r) => r.percentage)) / results.length) : null,
    homeworkPercent: homework.length ? round1((handedIn.length / homework.length) * 100) : null,
    latestRank: results[0]?.rank ?? null,
    feeDue: round2(sum(overdue.map(remaining))),
    overdueInstallments: overdue.length,
    openDoubts: db.doubts.all(instituteId, { studentId, status: 'open' }).length,
  };
}

/** The early-warning rules. Thresholds come from the institute's own settings where it has them. */
function evaluate(m: Measures, settings: InstituteSettings): Finding[] {
  const findings: Finding[] = [];
  const { minAttendancePercent, passPercent } = settings;
  if (m.attendancePercent !== null && m.attendancePercent < minAttendancePercent) {
    findings.push({
      kind: 'low_attendance',
      severity: m.attendancePercent < minAttendancePercent - 15 ? 'high' : 'medium',
      title: 'Attendance below the minimum',
      detail: `${m.attendancePercent}% attendance against a required ${minAttendancePercent}%.`,
      metricValue: m.attendancePercent,
      threshold: minAttendancePercent,
    });
  }
  if (m.examPercent !== null && m.examPercent < passPercent + MARKS_MARGIN) {
    findings.push({
      kind: 'low_marks',
      severity: m.examPercent < passPercent ? 'high' : 'medium',
      title: m.examPercent < passPercent ? 'Failing exam average' : 'Exam average close to the pass mark',
      detail: `Exam average is ${m.examPercent}%; the pass mark is ${passPercent}%.`,
      metricValue: m.examPercent,
      threshold: passPercent + MARKS_MARGIN,
    });
  }
  if (m.homeworkPercent !== null && m.homeworkPercent < HOMEWORK_MIN) {
    findings.push({
      kind: 'missing_homework',
      severity: m.homeworkPercent < HOMEWORK_MIN / 2 ? 'medium' : 'low',
      title: 'Homework not being handed in',
      detail: `${m.homeworkPercent}% of set homework handed in.`,
      metricValue: m.homeworkPercent,
      threshold: HOMEWORK_MIN,
    });
  }
  if (m.overdueInstallments > 0) {
    findings.push({
      kind: 'fee_overdue',
      severity: m.overdueInstallments > 1 ? 'high' : 'medium',
      title: 'Fee overdue',
      detail: `${m.overdueInstallments} installment(s) overdue, ${m.feeDue} outstanding.`,
      metricValue: m.feeDue,
      threshold: 0,
    });
  }
  return findings;
}

const worst = (findings: Finding[]): RiskLevel =>
  findings.reduce<RiskLevel>(
    (level, f) => (SEVERITY_ORDER.indexOf(f.severity) > SEVERITY_ORDER.indexOf(level) ? f.severity : level),
    'none',
  );

export function progressPort(db: Db): ProgressPort {
  const settingsOf = (instituteId: ID) => db.institutes.get(instituteId, instituteId).settings;
  const openAlerts = (instituteId: ID, studentId: ID) =>
    db.alerts.all(instituteId, { studentId }).filter((alert) => alert.status !== 'resolved');

  const snapshot = (instituteId: ID, studentId: ID): ProgressSnapshot => {
    db.students.get(instituteId, studentId);
    const measures = measure(db, instituteId, studentId);
    const { attendance: _summary, ...numbers } = measures; // the summary is not part of a snapshot
    const riskLevel = worst(evaluate(measures, settingsOf(instituteId)));
    return db.snapshots.insert(instituteId, { studentId, computedAt: nowIso(), ...numbers, riskLevel });
  };

  /** Opens, refreshes or resolves this student's alerts so they match the rules right now. */
  const syncAlerts = (instituteId: ID, studentId: ID): RiskAlert[] => {
    const m = measure(db, instituteId, studentId);
    const findings = evaluate(m, settingsOf(instituteId));
    const open = openAlerts(instituteId, studentId);
    for (const kind of ALL_KINDS) {
      const finding = findings.find((f) => f.kind === kind);
      const existing = open.find((alert) => alert.kind === kind);
      if (finding && existing) db.alerts.update(instituteId, existing.id, finding);
      else if (finding) {
        db.alerts.insert(instituteId, {
          ...finding,
          studentId,
          batchId: m.batchId,
          status: 'open',
          detectedAt: nowIso(),
          resolvedAt: null,
        });
      } else if (existing) {
        db.alerts.update(instituteId, existing.id, { status: 'resolved', resolvedAt: nowIso() });
      }
    }
    return openAlerts(instituteId, studentId);
  };

  return {
    getStudent360: async (instituteId, studentId) => {
      const student = db.students.get(instituteId, studentId);
      const alerts = syncAlerts(instituteId, studentId);
      return {
        student,
        enrollments: db.enrollments.all(instituteId, { studentId }),
        guardians: db.parentLinks
          .all(instituteId, { studentId })
          .map((link) => db.guardians.get(instituteId, link.guardianId)),
        snapshot: snapshot(instituteId, studentId),
        attendance: measure(db, instituteId, studentId).attendance,
        results: publishedResultsForStudent(db, instituteId, studentId),
        installments: db.installments.all(instituteId, { studentId }).sort((a, b) => a.termNo - b.termNo),
        alerts,
        goals: db.studentGoals.all(instituteId, { studentId }),
        tasks: db.studyTasks.all(instituteId, { studentId }),
      };
    },
    computeSnapshot: async (instituteId, studentId) => snapshot(instituteId, studentId),
    listSnapshots: async (instituteId, studentId) => {
      db.students.get(instituteId, studentId);
      return db.snapshots.all(instituteId, { studentId }).sort((a, b) => b.computedAt.localeCompare(a.computedAt));
    },
    listAlerts: async (instituteId, query) => db.alerts.page(instituteId, query),
    computeAlerts: async (instituteId, filter = {}) => {
      let studentIds: ID[];
      if (filter.studentId) studentIds = [db.students.get(instituteId, filter.studentId).id];
      else if (filter.batchId) {
        db.batches.get(instituteId, filter.batchId);
        studentIds = db.enrollments
          .all(instituteId, { batchId: filter.batchId, status: 'active' })
          .map((e) => e.studentId);
      } else studentIds = db.students.all(instituteId, { status: 'active' }).map((s) => s.id);
      return studentIds.flatMap((studentId) => syncAlerts(instituteId, studentId));
    },
    setAlertStatus: async (instituteId, alertId, status) =>
      db.alerts.update(instituteId, alertId, { status, resolvedAt: status === 'resolved' ? nowIso() : null }),
    listTasks: async (instituteId, studentId) => db.studyTasks.all(instituteId, { studentId }),
    saveTask: async (instituteId, input) => {
      const completedAt = input.status === 'done' ? nowIso() : input.status ? null : undefined;
      return upsert<StudyTask, 'studentId' | 'title'>(db.studyTasks, D.studyTask)(instituteId, { ...input, completedAt });
    },
    removeTask: async (instituteId, id) => db.studyTasks.remove(instituteId, id),
    listGoals: async (instituteId, studentId) => db.studentGoals.all(instituteId, { studentId }),
    saveGoal: upsert<StudentGoal, 'studentId' | 'title'>(db.studentGoals, D.studentGoal),
  };
}
