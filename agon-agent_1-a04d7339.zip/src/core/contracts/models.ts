/**
 * Domain models – the only data shapes the UI knows.
 *
 * Plain camelCase types. No table names, column names or SDK types: each
 * backend adapter maps its own storage to and from these.
 *
 * Split by domain to keep every file small; import from here.
 */

export * from './models/common';
export * from './models/tenant'; // Institute, Branch, Membership, Profile, Invitation, AuthSession
export * from './models/people'; // Student, Guardian, StudentMembership, ParentLink, Teacher, StaffRecord, Workload
export * from './models/register'; // MonthRegister, RegisterDay, AttendanceCorrection …
export * from './models/academics'; // Batch, Enrollment, Subject, Timetable, Classroom, AttendanceSession, AttendanceRecord
export * from './models/coursework'; // Assignment, Submission, Attachment, Feedback, Exam, ExamQuestion, Mark, Result
export * from './models/learning'; // Material, Bookmark, PracticeQuestion, Quiz, QuizAttempt, StudyTask, StudentGoal
export * from './models/finance'; // FeeStructure, StudentFee, Installment, Payment, Receipt, Refund, PaymentOrder
export * from './models/communication'; // Notice, AppNotification, Conversation, Doubt, MeetingRequest, Realtime*
export * from './models/business'; // AdmissionLead, LeadFollowup, Plan, Subscription, UsageRecord, AuditLog, ExportJob
export * from './models/progress'; // ProgressSnapshot, RiskAlert, Student360
