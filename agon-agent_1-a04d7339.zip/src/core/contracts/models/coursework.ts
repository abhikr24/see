import type { ID, ISODate, ISODateTime, TenantEntity } from './common';

/** Homework set for a batch. */
export interface Assignment extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  title: string;
  instructions: string | null;
  assignedOn: ISODate;
  dueAt: ISODateTime | null;
  maxMarks: number | null;
  submissionType: 'written' | 'upload' | 'online' | 'none';
  status: 'draft' | 'published' | 'closed';
  createdBy: ID | null;
}

/** A student's answer to an assignment. Marks live on Feedback. */
export interface Submission extends TenantEntity {
  assignmentId: ID;
  batchId: ID;
  studentId: ID;
  content: string | null;
  submittedAt: ISODateTime | null;
  status: 'pending' | 'submitted' | 'late' | 'returned';
}

export type AttachmentOwner =
  | 'assignment'
  | 'submission'
  | 'feedback'
  | 'material'
  | 'exam'
  | 'notice'
  | 'doubt'
  | 'conversation'
  | 'leave_request'
  | 'lead'
  | 'receipt'
  | 'student';

/** A stored file belonging to another record. */
export interface Attachment extends TenantEntity {
  ownerType: AttachmentOwner;
  ownerId: ID;
  batchId: ID | null;
  studentId: ID | null;
  fileName: string;
  /** Opaque location inside the backend's storage; resolve with StoragePort.getUrl. */
  storagePath: string;
  mimeType: string | null;
  sizeBytes: number | null;
  uploadedBy: ID | null;
}

/** A teacher's marks and comment on one submission. */
export interface Feedback extends TenantEntity {
  submissionId: ID;
  batchId: ID;
  studentId: ID;
  teacherId: ID | null;
  marksAwarded: number | null;
  grade: string | null;
  comment: string | null;
  givenBy: ID | null;
  givenAt: ISODateTime;
}

export interface Exam extends TenantEntity {
  batchId: ID;
  subjectId?: ID | null;
  name: string;
  examType: 'unit_test' | 'weekly_test' | 'mid_term' | 'final' | 'mock' | 'other';
  startsOn: ISODate | null;
  endsOn: ISODate | null;
  totalMarks: number | null;
  passPercent: number;
  status: 'draft' | 'scheduled' | 'ongoing' | 'completed' | 'published';
  publishedAt: ISODateTime | null;
  createdBy: ID | null;
}

export type QuestionType = 'mcq' | 'short' | 'long' | 'numerical';

export interface ExamQuestion extends TenantEntity {
  examId: ID;
  batchId: ID;
  subjectId: ID | null;
  questionNo: number;
  text: string;
  questionType: QuestionType;
  options: string[] | null;
  answerKey: string | null;
  maxMarks: number;
  topic: string | null;
}

/** One student, one subject, one exam. */
export interface Mark extends TenantEntity {
  examId: ID;
  batchId: ID;
  studentId: ID;
  subjectId: ID;
  /** null while not yet entered, or when the student was absent. */
  marksObtained: number | null;
  maxMarks: number;
  isAbsent: boolean;
  grade: string | null;
  remark: string | null;
  enteredBy: ID | null;
}

/** A student's overall outcome in one exam. */
export interface Result extends TenantEntity {
  examId: ID;
  batchId: ID;
  studentId: ID;
  totalObtained: number;
  totalMax: number;
  percentage: number;
  grade: string | null;
  rank: number | null;
  status: 'pass' | 'fail' | 'absent' | 'withheld';
  remarks: string | null;
}
