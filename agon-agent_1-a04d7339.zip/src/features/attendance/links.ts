import type { ID, ISODate } from '@/core/contracts/models';

export interface TakeAttendanceTarget {
  batchId: ID;
  date: ISODate;
  period?: number;
  subjectId?: ID | null;
}

/** The Take Attendance route with its batch, date, period and subject prefilled. */
export function takeAttendanceHref({ batchId, date, period = 1, subjectId }: TakeAttendanceTarget) {
  const params: Record<string, string> = { batchId, date, period: String(period) };
  if (subjectId) params.subjectId = subjectId;
  return { pathname: '/(owner)/attendance/[batchId]', params } as const;
}

/** The monthly register for a batch, optionally opened on a month (`YYYY-MM`). */
export function registerHref(batchId: ID, month?: string) {
  const params: Record<string, string> = { batchId };
  if (month) params.month = month;
  return { pathname: '/(owner)/attendance/register', params } as const;
}
