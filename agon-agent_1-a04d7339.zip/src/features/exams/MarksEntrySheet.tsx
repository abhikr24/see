import React, { useState } from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Avatar, Button, Text } from '@/components/ui';
import type { BatchRosterRow, ID, Mark } from '@/core/contracts/models';
import type { MarkEntry } from '@/core/contracts/ports';
import { C, LAYOUT, R } from '@/lib/theme';

interface DraftRow {
  marks: string;
  absent: boolean;
}

export interface MarksEntrySheetProps {
  visible: boolean;
  onClose: () => void;
  examName: string;
  subjectId: ID | null;
  maxMarks: number;
  roster: BatchRosterRow[];
  existingMarks: Mark[];
  saving: boolean;
  onSave: (entries: MarkEntry[]) => Promise<{ ok: boolean }>;
}

function buildInitialDraft(roster: BatchRosterRow[], existing: Mark[]): Record<ID, DraftRow> {
  const byStudent = new Map(existing.map((m) => [m.studentId, m]));
  const map: Record<ID, DraftRow> = {};
  for (const student of roster) {
    const row = byStudent.get(student.studentId);
    map[student.studentId] = {
      marks: row && !row.isAbsent && row.marksObtained !== null ? String(row.marksObtained) : '',
      absent: row?.isAbsent ?? false,
    };
  }
  return map;
}

export function MarksEntrySheet({
  visible,
  onClose,
  examName,
  subjectId,
  maxMarks,
  roster,
  existingMarks,
  saving,
  onSave,
}: MarksEntrySheetProps) {
  const [draft, setDraft] = useState<Record<ID, DraftRow>>(() =>
    buildInitialDraft(roster, existingMarks),
  );
  const [error, setError] = useState<string | null>(null);

  const setStudentMarks = (studentId: ID, value: string) => {
    setError(null);
    setDraft((prev) => ({ ...prev, [studentId]: { marks: value, absent: false } }));
  };

  const toggleAbsent = (studentId: ID) => {
    setError(null);
    setDraft((prev) => {
      const current = prev[studentId] ?? { marks: '', absent: false };
      return {
        ...prev,
        [studentId]: { marks: !current.absent ? '' : current.marks, absent: !current.absent },
      };
    });
  };

  const handleSave = async () => {
    if (!subjectId) {
      setError('This exam has no subject linked.');
      return;
    }
    const entries: MarkEntry[] = [];
    for (const student of roster) {
      const row = draft[student.studentId] ?? { marks: '', absent: false };
      if (row.absent) {
        entries.push({
          studentId: student.studentId,
          subjectId,
          marksObtained: null,
          maxMarks,
          isAbsent: true,
        });
        continue;
      }
      const trimmed = row.marks.trim();
      if (!trimmed) continue;
      const parsed = Number(trimmed);
      if (!Number.isFinite(parsed) || parsed < 0 || parsed > maxMarks) {
        setError(`${student.fullName}: marks must be between 0 and ${maxMarks}.`);
        return;
      }
      entries.push({
        studentId: student.studentId,
        subjectId,
        marksObtained: parsed,
        maxMarks,
        isAbsent: false,
      });
    }
    if (entries.length === 0) {
      setError('Enter marks or mark at least one student absent.');
      return;
    }
    const result = await onSave(entries);
    if (result.ok) onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingHorizontal: LAYOUT.margin,
              paddingVertical: 14,
              borderBottomWidth: 1,
              borderBottomColor: C.hairline,
              backgroundColor: C.surface,
            }}
          >
            <Pressable onPress={onClose} hitSlop={10} accessibilityLabel="Close marks entry">
              <Ionicons name="close" size={24} color={C.ink} />
            </Pressable>
            <View style={{ flex: 1, marginHorizontal: 12 }}>
              <Text variant="title" weight={700} numberOfLines={1}>
                Enter marks · {examName}
              </Text>
              <Text variant="caption" c={C.secondary} tabular>
                Max {maxMarks} marks · {roster.length} students
              </Text>
            </View>
          </View>

          <View
            style={{
              marginHorizontal: LAYOUT.margin,
              marginTop: 12,
              padding: 12,
              borderRadius: R.field,
              backgroundColor: C.navySoft,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 10,
            }}
          >
            <Ionicons name="eye-off-outline" size={18} color={C.primary} />
            <Text variant="caption" c={C.primary} style={{ flex: 1 }}>
              Marks stay hidden from students and parents until you publish results.
            </Text>
          </View>

          {error ? (
            <View
              style={{
                marginHorizontal: LAYOUT.margin,
                marginTop: 10,
                padding: 12,
                borderRadius: R.field,
                backgroundColor: C.dangerSoft,
              }}
            >
              <Text variant="caption" weight={600} c={C.danger}>
                {error}
              </Text>
            </View>
          ) : null}

          <FlatList
            data={roster}
            keyExtractor={(item) => item.studentId}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{ padding: LAYOUT.margin, gap: 10, paddingBottom: 24 }}
            renderItem={({ item }) => {
              const row = draft[item.studentId] ?? { marks: '', absent: false };
              return (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 12,
                    backgroundColor: C.surface,
                    borderWidth: 1,
                    borderColor: C.hairline,
                    borderRadius: R.btn,
                    paddingHorizontal: 14,
                    paddingVertical: 10,
                  }}
                >
                  <Avatar name={item.fullName} uri={item.photoUrl} size={38} />
                  <View style={{ flex: 1 }}>
                    <Text variant="body" weight={600} numberOfLines={1}>
                      {item.fullName}
                    </Text>
                    <Text variant="caption" c={C.muted} tabular>
                      Roll {item.rollNumber ?? '—'}
                    </Text>
                  </View>

                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Mark ${item.fullName} absent`}
                    onPress={() => toggleAbsent(item.studentId)}
                    style={{
                      paddingHorizontal: 10,
                      paddingVertical: 6,
                      borderRadius: R.chip,
                      backgroundColor: row.absent ? C.dangerSoft : C.track,
                    }}
                  >
                    <Text
                      variant="label"
                      weight={700}
                      c={row.absent ? C.danger : C.secondary}
                    >
                      {row.absent ? 'Absent' : 'AB'}
                    </Text>
                  </Pressable>

                  <TextInput
                    accessibilityLabel={`Marks for ${item.fullName}`}
                    value={row.marks}
                    onChangeText={(v) => setStudentMarks(item.studentId, v)}
                    editable={!row.absent}
                    keyboardType="numeric"
                    placeholder={row.absent ? 'AB' : `/${maxMarks}`}
                    placeholderTextColor={C.muted}
                    style={{
                      width: 74,
                      height: 44,
                      borderRadius: R.field,
                      borderWidth: 1,
                      borderColor: row.absent ? C.hairline : C.primary,
                      backgroundColor: row.absent ? C.track : C.surface,
                      textAlign: 'center',
                      fontSize: 16,
                      fontWeight: '700',
                      fontVariant: ['tabular-nums'],
                      color: row.absent ? C.muted : C.ink,
                    }}
                  />
                </View>
              );
            }}
          />

          <View
            style={{
              padding: LAYOUT.margin,
              borderTopWidth: 1,
              borderTopColor: C.hairline,
              backgroundColor: C.surface,
            }}
          >
            <Button
              title="Save marks"
              onPress={() => void handleSave()}
              loading={saving}
              disabled={roster.length === 0}
            />
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}
