import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { Avatar, Badge, Button, Card, EmptyState, ErrorState, ListSkeleton, ProgressBar, Sheet, StatCard, Text } from '@/components/ui';
import { toast } from '@/core/backend';
import { dateShort, pct } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { buildExamCsv, examCsvFilename, type ExamCsvRow } from './csv';
import { deliverExamCsv } from './export';
import { useExamDetail } from './hooks';

const TAB_BAR_INSET = 136;

export function ExamDetailScreen() {
  const { id, enterMarks } = useLocalSearchParams<{ id?: string; enterMarks?: string }>();
  const examId = typeof id === 'string' && id.length > 0 ? id : null;
  const detail = useExamDetail(examId);
  const [marksOpen, setMarksOpen] = useState(false);
  const [publishConfirm, setPublishConfirm] = useState(false);
  const [exporting, setExporting] = useState(false);
  const autoOpened = useRef(false);

  useEffect(() => {
    if (enterMarks === '1' && detail.data && !autoOpened.current) {
      autoOpened.current = true;
      setMarksOpen(true);
    }
  }, [enterMarks, detail.data]);

  const marksByStudent = useMemo(
    () => new Map((detail.data?.marks ?? []).map((m) => [m.studentId, m])),
    [detail.data?.marks],
  );

  const csvRows = useMemo<ExamCsvRow[]>(() => {
    if (!detail.data) return [];
    const maxMarks = detail.data.exam.totalMarks ?? detail.data.marks[0]?.maxMarks ?? 100;
    return detail.data.roster.map((student) => {
      const m = marksByStudent.get(student.studentId);
      const status: ExamCsvRow['status'] = !m ? 'Pending' : m.isAbsent ? 'Absent' : m.marksObtained !== null ? 'Scored' : 'Pending';
      const percentage =
        m && !m.isAbsent && m.marksObtained !== null && (m.maxMarks || maxMarks) > 0
          ? Math.round((m.marksObtained / (m.maxMarks || maxMarks)) * 100)
          : null;
      return {
        rollNumber: student.rollNumber,
        fullName: student.fullName,
        status,
        marksObtained: m && !m.isAbsent ? m.marksObtained : null,
        maxMarks: m?.maxMarks ?? maxMarks,
        percentage,
        grade: m?.grade ?? null,
      };
    });
  }, [detail.data, marksByStudent]);

  const handleDownloadCsv = async () => {
    if (!detail.data) return;
    setExporting(true);
    try {
      const csv = buildExamCsv(detail.data.exam, detail.data.subjectName, detail.data.batchName, csvRows);
      const outcome = await deliverExamCsv(examCsvFilename(detail.data.exam), csv);
      toast.success(outcome === 'downloaded' ? 'CSV downloaded' : 'CSV ready');
    } catch {
      toast.error('Could not export CSV');
    } finally {
      setExporting(false);
    }
  };

  const handlePublish = async () => {
    const result = await detail.publish.mutate();
    if (result.ok) setPublishConfirm(false);
  };

  if (!examId) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState title="Exam not found" message="No exam id was provided." />
      </View>
    );
  }

  const data = detail.data;
  const stats = detail.stats;
  const maxMarks = data?.exam.totalMarks ?? data?.marks[0]?.maxMarks ?? 100;
  const isPublished = data?.exam.status === 'published';

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={detail.loading && Boolean(data)} onRefresh={() => void detail.refetch()} tintColor={C.primary} />}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: TAB_BAR_INSET, gap: 16, flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back to exams"
          onPress={() => router.replace('/(owner)/exams' as never)}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
        >
          <Ionicons name="chevron-back" size={20} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>Exams</Text>
        </Pressable>

        {detail.loading && !data ? (
          <ListSkeleton rows={4} h={84} />
        ) : detail.error && !data ? (
          <ErrorState message={detail.error.message} onRetry={() => void detail.refetch()} />
        ) : data && stats ? (
          <>
            <View style={{ backgroundColor: C.primary, borderRadius: R.card, padding: 20, gap: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <Text variant="label" c={C.navyPale} style={{ flex: 1 }}>
                  {data.subjectName} · {data.batchName}
                </Text>
                <Badge label={isPublished ? 'Published' : 'Unpublished'} tone={isPublished ? 'teal' : 'warning'} small />
              </View>
              <Text variant="h2" weight={800} c={C.surface}>{data.exam.name}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginTop: 4 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name="calendar-outline" size={14} color={C.navyPale} />
                  <Text variant="caption" c={C.surface} tabular>{data.exam.startsOn ? dateShort(data.exam.startsOn) : 'No date'}</Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name="ribbon-outline" size={14} color={C.navyPale} />
                  <Text variant="caption" c={C.surface} tabular>Max {maxMarks} marks</Text>
                </View>
              </View>
            </View>

            <View style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ flex: 1 }}><StatCard label="Entered" value={`${stats.entered}/${stats.totalStudents}`} /></View>
              <View style={{ flex: 1 }}><StatCard label="Average" value={stats.averagePct === null ? '—' : pct(stats.averagePct)} /></View>
              <View style={{ flex: 1 }}><StatCard label="Highest" value={stats.highestMarks === null ? '—' : stats.highestMarks} /></View>
            </View>

            {stats.partlyEntered ? (
              <Card flat pad={14}>
                <View style={{ gap: 8 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text variant="caption" weight={600} c={C.secondary}>Marks entry progress</Text>
                    <Text variant="caption" weight={700} c={C.accent} tabular>{stats.entered} of {stats.totalStudents} entered</Text>
                  </View>
                  <ProgressBar value={stats.enteredPct} tone="accent" height={5} />
                </View>
              </Card>
            ) : null}

            <View style={{ gap: 10 }}>
              <Button title="Enter marks" icon="create-outline" onPress={() => router.push(`/(owner)/exams/${data.exam.id}/marks`)} disabled={data.roster.length === 0} />
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Button
                    title={isPublished ? 'Results published' : 'Publish results'}
                    icon={isPublished ? 'checkmark-circle-outline' : 'megaphone-outline'}
                    variant={isPublished ? 'outline' : 'secondary'}
                    size="md"
                    disabled={isPublished || stats.entered === 0}
                    loading={detail.publish.loading}
                    onPress={() => setPublishConfirm(true)}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Button
                    title="Download CSV"
                    icon="download-outline"
                    variant="outline"
                    size="md"
                    loading={exporting}
                    onPress={() => void handleDownloadCsv()}
                  />
                </View>
              </View>
            </View>

            <View style={{ gap: 10, marginTop: 4 }}>
              <Text variant="title" weight={700}>Students ({data.roster.length})</Text>
              {data.roster.length === 0 ? (
                <EmptyState icon="people-outline" title="No students in batch" text="Enrol students in this batch before entering marks." />
              ) : (
                data.roster.map((student) => {
                  const m = marksByStudent.get(student.studentId);
                  return (
                    <Card key={student.studentId} flat pad={14}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                        <Avatar name={student.fullName} uri={student.photoUrl} size={38} />
                        <View style={{ flex: 1 }}>
                          <Text variant="body" weight={600} numberOfLines={1}>{student.fullName}</Text>
                          <Text variant="caption" c={C.muted} tabular>Roll {student.rollNumber ?? '—'}</Text>
                        </View>
                        {!m ? (
                          <Badge label="Pending" tone="neutral" small />
                        ) : m.isAbsent ? (
                          <Badge label="Absent" tone="danger" small />
                        ) : (
                          <View style={{ alignItems: 'flex-end', gap: 2 }}>
                            <Text variant="body" weight={800} tabular>{m.marksObtained}/{m.maxMarks}</Text>
                            {m.grade ? <Text variant="label" c={C.teal}>Grade {m.grade}</Text> : null}
                          </View>
                        )}
                      </View>
                    </Card>
                  );
                })
              )}
            </View>
          </>
        ) : null}
      </ScrollView>

      <Sheet
        visible={publishConfirm}
        onClose={() => setPublishConfirm(false)}
        title="Publish results?"
        subtitle={data ? `${data.exam.name} · ${data.batchName}` : undefined}
        snapPoints={['42%']}
      >
        <View style={{ gap: 16 }}>
          <Text variant="body" c={C.secondary}>
            {data
              ? `Students and parents in ${data.batchName} will be notified immediately and marks will become visible to them.`
              : ''}
          </Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <Button title="Cancel" variant="outline" size="md" onPress={() => setPublishConfirm(false)} />
            </View>
            <View style={{ flex: 1 }}>
              <Button title="Publish results" size="md" loading={detail.publish.loading} onPress={() => void handlePublish()} />
            </View>
          </View>
        </View>
      </Sheet>
    </View>
  );
}
