/** Notices list (owner / admin). Also receives the dashboard's `?action=compose&batchId=` and forwards it to the composer. */
export { NoticesListScreen as default } from '@/features/notices/screens/NoticesListScreen';
