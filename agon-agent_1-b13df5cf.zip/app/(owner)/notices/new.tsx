import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { NoticeComposerScreen } from '@/features/notices/screens/NoticeComposerScreen';

/** Notice composer (owner / admin). `?batchId=` pre-selects one batch. Full-screen: see `(owner)/_layout.tsx`. */
export default function OwnerNoticeComposerRoute() {
  const { batchId } = useLocalSearchParams<{ batchId?: string }>();
  return <NoticeComposerScreen initialBatchId={typeof batchId === 'string' && batchId ? batchId : undefined} />;
}
