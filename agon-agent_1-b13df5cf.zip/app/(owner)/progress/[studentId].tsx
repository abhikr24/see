import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { ProgressStudentScreen } from '@/features/progress/screens/ProgressStudentScreen';

export default function OwnerProgressStudentRoute() {
  const { studentId, alertId, log } = useLocalSearchParams<{
    studentId?: string;
    alertId?: string;
    log?: string;
  }>();
  return (
    <ProgressStudentScreen
      studentId={typeof studentId === 'string' ? studentId : ''}
      alertId={typeof alertId === 'string' ? alertId : null}
      autoLog={log === '1'}
    />
  );
}
