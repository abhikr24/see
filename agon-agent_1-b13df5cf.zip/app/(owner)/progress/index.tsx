import React from 'react';

import { AlertListScreen } from '@/features/progress/screens/AlertListScreen';

export default function OwnerProgressRoute() {
  return <AlertListScreen />;
}
