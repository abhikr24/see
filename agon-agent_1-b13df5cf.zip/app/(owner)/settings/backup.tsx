import React from 'react';

import { BackupScreen } from '@/features/settings/screens/BackupScreen';

export default function OwnerBackupRoute() {
  return <BackupScreen />;
}
