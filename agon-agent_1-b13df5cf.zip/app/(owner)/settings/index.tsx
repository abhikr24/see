import React from 'react';

import { SettingsHomeScreen } from '@/features/settings/screens/SettingsHomeScreen';

export default function OwnerSettingsRoute() {
  return <SettingsHomeScreen />;
}
