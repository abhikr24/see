import React from 'react';

import { StaffScreen } from '@/features/settings/screens/StaffScreen';

export default function OwnerStaffRoute() {
  return <StaffScreen />;
}
