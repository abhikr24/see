import React from 'react';

import { SubscriptionScreen } from '@/features/settings/screens/SubscriptionScreen';

export default function OwnerSubscriptionRoute() {
  return <SubscriptionScreen />;
}
