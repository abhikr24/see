import React from 'react';

import { ParentProvider } from '@/features/parent/context';
import { ParentShell } from '@/features/parent/ParentShell';

export default function ParentLayout() {
  return (
    <ParentProvider>
      <ParentShell />
    </ParentProvider>
  );
}
