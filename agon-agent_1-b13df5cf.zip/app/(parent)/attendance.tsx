export { ParentAttendanceScreen as default } from '@/features/parent/attendance';
