export { ParentFeesScreen as default } from '@/features/parent/fees';
