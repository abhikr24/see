export { default } from '@/features/parent/ParentHome';
