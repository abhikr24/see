export { ParentLeaveScreen as default } from '@/features/parent/leave';
