export { ParentMeetingsScreen as default } from '@/features/parent/meetings';
