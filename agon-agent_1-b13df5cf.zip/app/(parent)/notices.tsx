/** Notices list (parent) — the Notices tab. The per-child updates feed that used to live here is now `/(parent)/updates`. */
export { NoticesListScreen as default } from '@/features/notices/screens/NoticesListScreen';
