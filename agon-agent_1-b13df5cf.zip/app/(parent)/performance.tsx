export { ParentPerformanceScreen as default } from '@/features/parent/performance';
