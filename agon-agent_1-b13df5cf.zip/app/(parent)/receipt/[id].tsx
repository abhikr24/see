import { useLocalSearchParams } from 'expo-router';
import { ParentReceiptScreen } from '@/features/parent/receipt';

export default function ParentReceiptRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return <ParentReceiptScreen id={String(id ?? '')} />;
}
