/** The per-child updates feed (homework, attendance, notices) built with the parent overview. Linked from More. */
export { ParentNotices as default } from '@/features/parent/details';
