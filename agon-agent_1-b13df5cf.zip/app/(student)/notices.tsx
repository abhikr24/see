/** Notices list (student). Read-only: no composer, no delete. */
export { NoticesListScreen as default } from '@/features/notices/screens/NoticesListScreen';
