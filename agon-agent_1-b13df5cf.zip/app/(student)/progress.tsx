import React from 'react';
import { StudentProgressScreen } from '@/features/student/progress';

export default function StudentProgressRoute() {
  return <StudentProgressScreen />;
}
