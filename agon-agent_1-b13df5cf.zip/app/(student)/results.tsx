import React from 'react';
import { StudentResultsScreen } from '@/features/student/results';

export default function StudentResultsRoute() {
  return <StudentResultsScreen />;
}
