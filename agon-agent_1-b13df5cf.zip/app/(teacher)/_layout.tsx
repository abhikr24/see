import React from 'react';
import { useSegments } from 'expo-router';

import { ChromelessGate } from '@/features/shell/ChromelessGate';
import { RoleTabShell } from '@/features/shell/RoleTabShell';

export default function TeacherLayout() {
  const segments = useSegments() as string[];
  // Take Attendance (/(teacher)/[batchId]) is full-screen: the same role guard, no header and no tab bar.
  if (segments[1] === '[batchId]') return <ChromelessGate group="/(teacher)" />;
  // Assign homework (/new) and Submissions (/[id]) are full-screen with their own sticky footers.
  if (segments[1] === 'homework' && segments.length > 2) return <ChromelessGate group="/(teacher)" />;
  // The notice composer (/(teacher)/notices/new) is full-screen with a sticky Publish bar.
  if (segments[1] === 'notices' && segments.length > 2) return <ChromelessGate group="/(teacher)" />;
  return <RoleTabShell role="teacher" />;
}
