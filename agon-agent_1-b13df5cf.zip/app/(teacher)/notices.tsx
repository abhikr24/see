/** Notices list (teacher). The same screen every role gets; NoticeRepo decides what a teacher may read. */
export { NoticesListScreen as default } from '@/features/notices/screens/NoticesListScreen';
