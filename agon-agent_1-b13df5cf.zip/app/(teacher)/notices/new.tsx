import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { NoticeComposerScreen } from '@/features/notices/screens/NoticeComposerScreen';

/** Notice composer (teacher): the shared composer, bound by the backend to the teacher's own batches. */
export default function TeacherNoticeComposerRoute() {
  const { batchId } = useLocalSearchParams<{ batchId?: string }>();
  return <NoticeComposerScreen initialBatchId={typeof batchId === 'string' && batchId ? batchId : undefined} />;
}
