import React from 'react';

import { JoinInviteScreen } from '@/features/settings/screens/JoinInviteScreen';

export default function JoinRoute() {
  return <JoinInviteScreen />;
}
