/** Notification centre — one route for every role. Guarded inside the screen, since it lives outside the role groups. */
export { NotificationCentreScreen as default } from '@/features/notifications/screens/NotificationCentreScreen';
