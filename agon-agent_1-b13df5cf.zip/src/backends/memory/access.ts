import type { ID, Subscription } from '../../core/contracts/models';
import { featureBlockedMessage, writesRestricted, type GatedFeature } from '../../core/contracts/subscription';
import type { Db } from './db';
import { callerRole } from './teacher-scope';
import { fail } from './store';

export function assertOwner(db: Db, instituteId: ID, action: string): void {
  if (callerRole(db, instituteId) !== 'owner') fail('FORBIDDEN', `Only an owner can ${action}`);
}

export function latestSubscription(db: Db, instituteId: ID): Subscription | null {
  const rows = db.subscriptions.all(instituteId);
  return rows.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0] ?? null;
}

export function openSubscription(db: Db, instituteId: ID): Subscription | null {
  return (
    db.subscriptions
      .all(instituteId)
      .find((item) => item.status === 'trialing' || item.status === 'active' || item.status === 'past_due') ?? null
  );
}

/**
 * Pauses non-essential writes when the plan is cancelled or expired.
 * Does not delete, archive or hide existing rows.
 */
export function assertFeatureOpen(db: Db, instituteId: ID, feature: GatedFeature): void {
  if (openSubscription(db, instituteId)) return;
  const latest = latestSubscription(db, instituteId);
  if (latest && writesRestricted(latest.status)) fail('FORBIDDEN', featureBlockedMessage(feature));
}
