import type { Entity, ID, Profile } from '../../core/contracts/models';
import type { ExportFile, ExportRequest } from '../../core/contracts/ports';
import { BACKUP_VERSION, CLEAR_DATA_PHRASE } from '../../core/contracts/backup';
import { assertOwner } from './access';
import type { Db } from './db';
import * as D from './defaults';
import { TABLE_KEYS } from './persist';
import { callerRole } from './teacher-scope';
import { fail, merge, nowIso, type Table } from './store';

const BACKUP_ACTION = 'backup.exported';

const CLEAR_KEYS = [
  'branches', 'invitations', 'staff', 'teachers', 'workloads', 'leaveRequests',
  'studentLeaveRequests', 'feePayments', 'students', 'guardians', 'studentMemberships',
  'parentLinks', 'batches', 'enrollments', 'subjects', 'timetables', 'classrooms',
  'attendanceSessions', 'attendanceRecords', 'attendanceCorrections', 'assignments',
  'submissions', 'attachments', 'feedback', 'exams', 'examQuestions', 'marks', 'results',
  'materials', 'bookmarks', 'practiceQuestions', 'quizzes', 'quizAttempts', 'studyTasks',
  'studentGoals', 'studentAchievements', 'feeStructures', 'studentFees', 'installments',
  'payments', 'receipts', 'refunds', 'orders', 'notices', 'notifications', 'conversations',
  'doubts', 'meetings', 'leads', 'followups', 'usage', 'exportJobs', 'snapshots', 'alerts',
  'interventions',
] as const;

interface Bundle {
  version: number;
  instituteId: ID;
  exportedAt: string;
  tables: Record<string, Entity[]>;
  profiles: Profile[];
}

function tableOf(db: Db, key: string): Table<Entity> {
  return (db as unknown as Record<string, Table<Entity>>)[key];
}

function csvCell(value: unknown): string {
  const text = value == null ? '' : String(value);
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function toCsv(headers: string[], rows: unknown[][]): string {
  return [headers.join(','), ...rows.map((row) => row.map(csvCell).join(','))].join('\n') + '\n';
}

function stamp(db: Db, instituteId: ID): void {
  db.auditLogs.insert(
    instituteId,
    merge(D.auditLog(), {
      actorId: db.session.userId,
      actorRole: callerRole(db, instituteId),
      action: BACKUP_ACTION,
      targetType: 'institute',
      targetId: instituteId,
      before: null,
      after: { at: nowIso() },
      ipAddress: null,
      userAgent: null,
    }),
  );
}

export function lastBackupAt(db: Db, instituteId: ID): string | null {
  return (
    db.auditLogs
      .all(instituteId, { action: BACKUP_ACTION })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0]?.createdAt ?? null
  );
}

function studentsCsv(db: Db, instituteId: ID): string {
  const rows = db.students.all(instituteId).map((student) => [
    student.fullName, student.admissionNo, student.phone, student.classGrade, student.status, student.admittedOn,
  ]);
  return toCsv(['fullName', 'admissionNo', 'phone', 'classGrade', 'status', 'admittedOn'], rows);
}

function attendanceCsv(db: Db, instituteId: ID): string {
  const sessions = new Map(db.attendanceSessions.all(instituteId).map((session) => [session.id, session]));
  const rows = db.attendanceRecords.all(instituteId).map((record) => [
    sessions.get(record.sessionId)?.date ?? '', record.batchId, record.studentId, record.status, record.remark ?? '',
  ]);
  return toCsv(['date', 'batchId', 'studentId', 'status', 'remark'], rows);
}

function feesCsv(db: Db, instituteId: ID): string {
  const names = new Map(db.students.all(instituteId).map((student) => [student.id, student.fullName]));
  const rows = db.installments.all(instituteId).map((row) => [
    names.get(row.studentId) ?? row.studentId, row.label, row.amount, row.paidAmount, row.dueDate, row.status,
  ]);
  return toCsv(['student', 'term', 'amount', 'paid', 'dueDate', 'status'], rows);
}

export function renderExport(db: Db, instituteId: ID, request: ExportRequest): ExportFile {
  assertOwner(db, instituteId, 'export institute data');
  const builders: Record<string, () => { filename: string; body: string; rows: number }> = {
    students: () => ({ filename: 'students.csv', body: studentsCsv(db, instituteId), rows: db.students.all(instituteId).length }),
    attendance: () => ({ filename: 'attendance.csv', body: attendanceCsv(db, instituteId), rows: db.attendanceRecords.all(instituteId).length }),
    fees: () => ({ filename: 'fee-records.csv', body: feesCsv(db, instituteId), rows: db.installments.all(instituteId).length }),
  };
  const build = builders[request.kind];
  if (!build || request.format !== 'csv') fail('VALIDATION', 'Choose a CSV export of students, attendance or fee records');
  const file = build();
  stamp(db, instituteId);
  return { filename: file.filename, mime: 'text/csv', body: file.body, rowCount: file.rows };
}

export function exportBundle(db: Db, instituteId: ID): string {
  assertOwner(db, instituteId, 'export institute data');
  stamp(db, instituteId);
  const tables: Record<string, Entity[]> = {};
  for (const key of TABLE_KEYS) tables[key] = tableOf(db, key).all(instituteId);
  const userIds = new Set(db.memberships.all(instituteId).map((membership) => membership.userId));
  const profiles = [...db.profiles.values()].filter((profile) => userIds.has(profile.userId));
  const bundle: Bundle = { version: BACKUP_VERSION, instituteId, exportedAt: nowIso(), tables, profiles };
  return JSON.stringify(bundle);
}

export function importBundle(db: Db, instituteId: ID, json: string): { restored: number } {
  assertOwner(db, instituteId, 'import institute data');
  let bundle: Bundle;
  try {
    bundle = JSON.parse(json) as Bundle;
  } catch {
    fail('VALIDATION', 'That file is not a GuruFlow backup');
  }
  if (bundle.version !== BACKUP_VERSION || !bundle.tables || bundle.instituteId !== instituteId) {
    fail('VALIDATION', 'This backup is for a different institute');
  }
  let restored = 0;
  for (const key of TABLE_KEYS) {
    const rows = bundle.tables[key];
    if (!Array.isArray(rows)) continue;
    const table = tableOf(db, key);
    for (const row of table.all(instituteId)) table.remove(instituteId, row.id);
    for (const row of rows) {
      const owner = (row as { instituteId?: ID }).instituteId ?? row.id;
      if (owner !== instituteId || !row.id) continue;
      table.put(row);
      restored += 1;
    }
  }
  for (const profile of bundle.profiles ?? []) {
    if (profile?.userId) db.profiles.set(profile.userId, profile);
  }
  return { restored };
}

/** Removes operational data. The institute, its plan and its owner login stay. */
export function clearInstituteData(db: Db, instituteId: ID, confirmation: string): void {
  assertOwner(db, instituteId, 'clear institute data');
  if (confirmation !== CLEAR_DATA_PHRASE) fail('VALIDATION', `Type ${CLEAR_DATA_PHRASE} to confirm`);
  for (const key of CLEAR_KEYS) {
    const table = tableOf(db, key);
    for (const row of [...table.all(instituteId)]) table.remove(instituteId, row.id);
  }
  for (const membership of [...db.memberships.all(instituteId)]) {
    if (membership.role !== 'owner') db.memberships.remove(instituteId, membership.id);
  }
}
