import type { BillingInvoice, ID, UpiMandate } from '../../core/contracts/models';
import type { Db } from './db';
import { latestSubscription } from './access';
import { fail } from './store';

const DEFAULT_VPA = 'sunrise.coaching@oksbi';

export function paymentMethod(db: Db, instituteId: ID): UpiMandate | null {
  const sub = latestSubscription(db, instituteId);
  if (!sub) return null;
  return {
    kind: 'upi',
    label: 'UPI',
    vpa: sub.upiVpa?.trim() || DEFAULT_VPA,
    autopay: sub.autopay !== false,
  };
}

export function setAutopay(db: Db, instituteId: ID, enabled: boolean): UpiMandate {
  const sub = latestSubscription(db, instituteId);
  if (!sub) fail('NOT_FOUND', 'There is no subscription to update');
  db.subscriptions.update(instituteId, sub.id, { autopay: enabled, upiVpa: sub.upiVpa ?? DEFAULT_VPA });
  return paymentMethod(db, instituteId) as UpiMandate;
}

export function invoicesFor(db: Db, instituteId: ID): BillingInvoice[] {
  const sub = latestSubscription(db, instituteId);
  if (!sub) return [];
  const plan = db.plans.get(instituteId, sub.planId);
  const amount = sub.billingCycle === 'yearly' ? plan.priceYearly : plan.priceMonthly;
  const start = new Date(sub.currentPeriodStart);
  const previous = new Date(start);
  previous.setUTCMonth(previous.getUTCMonth() - 1);
  const numberFor = (date: Date) => `INV-${date.toISOString().slice(0, 7).replace('-', '')}`;
  const open = sub.status === 'past_due' || sub.status === 'cancelled' || sub.status === 'expired';
  return [
    {
      id: `${sub.id}-current`,
      number: numberFor(start),
      issuedAt: sub.currentPeriodStart,
      amount,
      currency: plan.currency,
      status: open ? 'open' : 'paid',
      periodLabel: sub.billingCycle === 'yearly' ? 'Annual' : 'Monthly',
    },
    {
      id: `${sub.id}-previous`,
      number: numberFor(previous),
      issuedAt: previous.toISOString(),
      amount,
      currency: plan.currency,
      status: 'paid',
      periodLabel: sub.billingCycle === 'yearly' ? 'Annual' : 'Monthly',
    },
  ];
}
