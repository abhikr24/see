import type { FamilyMeeting, FamilyPayment, FamilyReceipt, FamilyTeacher, FeePayment, ID, Timetable } from '../../core/contracts/models';
import type { FamilyRepo } from '../../core/contracts/ports';
import { assertReceiptMatchesPayment, inclusiveDays, isIsoDate, previewLeaveClasses, validateLeaveInput, validateMeetingInput } from '../../core/contracts/family';
import { emit, requireUser, type Db } from './db';
import * as D from './defaults';
import { parentChildIds } from './parent';
import { callerRole, callerTeacher } from './teacher-scope';
import { fail, merge, todayIso } from './store';

/** Fail closed: the child must be one of the caller's linked children in this institute. */
function assertChild(db: Db, instituteId: ID, studentId: ID): void {
  if (!parentChildIds(db, instituteId).includes(studentId)) fail('NOT_FOUND', 'That child could not be found');
}

/** Batches a student takes, from active enrolments. */
function activeBatchIds(db: Db, instituteId: ID, studentId: ID): ID[] {
  return [...new Set(db.enrollments.all(instituteId, { studentId, status: 'active' }).map((e) => e.batchId))];
}

/** Every timetable period a batch set runs, plus each batch's assigned teacher. */
function periodsFor(db: Db, instituteId: ID, batchIds: ID[]): Timetable[] {
  const set = new Set(batchIds);
  return db.timetables.all(instituteId).filter((p) => set.has(p.batchId));
}

/** Teacher profiles who take at least one of the given batches. */
function teacherIdsFor(db: Db, instituteId: ID, batchIds: ID[]): Set<ID> {
  const set = new Set(batchIds);
  const ids = new Set<ID>();
  for (const period of db.timetables.all(instituteId)) if (set.has(period.batchId) && period.teacherId) ids.add(period.teacherId);
  for (const batch of db.batches.all(instituteId)) if (set.has(batch.id) && batch.teacherId) ids.add(batch.teacherId);
  return ids;
}

function notifyUser(db: Db, instituteId: ID, userId: ID, type: string, title: string, body: string, data: Record<string, unknown>) {
  const sent = db.notifications.insert(instituteId, merge(D.notification(), { userId, type, title, body, data }));
  emit(db, instituteId, 'notifications', 'created', sent.id);
}

/**
 * The one place a pending online payment is created. A retry while one is pending returns that row,
 * so a failed or repeated tap can never leave two pending rows for the same installment.
 */
export function ensurePendingFeePayment(
  db: Db,
  instituteId: ID,
  input: { studentId: ID; installmentId: ID; amount: number; provider: string; providerOrderId: string },
): FeePayment {
  const existing = db.feePayments.all(instituteId, { installmentId: input.installmentId, status: 'pending' })[0];
  if (existing) return existing;
  return db.feePayments.insert(instituteId, { ...input, status: 'pending', paymentId: null, failureReason: null });
}

export function familyRepo(db: Db): FamilyRepo {
  return {
    paymentHistory: async (instituteId, studentId) => {
      assertChild(db, instituteId, studentId);
      return db.payments.all(instituteId, { studentId })
        .filter((p) => p.status === 'completed')
        .sort((a, b) => b.paidAt.localeCompare(a.paidAt))
        .map((payment): FamilyPayment => {
          const receipt = db.receipts.find(instituteId, { paymentId: payment.id });
          const installment = payment.installmentId ? db.installments.find(instituteId, { id: payment.installmentId }) : undefined;
          return {
            id: payment.id, studentId, installmentId: payment.installmentId, label: installment?.label ?? 'Fee payment', amount: payment.amount, method: payment.method,
            referenceNo: payment.referenceNo, paidAt: payment.paidAt, receiptId: receipt?.id ?? null, receiptNo: receipt?.receiptNo ?? null,
          };
        });
    },

    receipt: async (instituteId, receiptId) => {
      const receipt = db.receipts.get(instituteId, receiptId);
      assertChild(db, instituteId, receipt.studentId);
      const payment = db.payments.get(instituteId, receipt.paymentId);
      assertReceiptMatchesPayment(receipt, payment);
      const institute = db.institutes.get(instituteId, instituteId);
      const installment = payment.installmentId ? db.installments.find(instituteId, { id: payment.installmentId }) : undefined;
      const view: FamilyReceipt = {
        receiptId: receipt.id, receiptNo: receipt.receiptNo, studentId: receipt.studentId,
        studentName: db.students.get(instituteId, receipt.studentId).fullName,
        instituteName: institute.name, instituteCity: institute.city, termLabel: installment?.label ?? 'Fee payment',
        amount: payment.amount, method: payment.method, referenceNo: payment.referenceNo,
        paymentId: payment.id, paidAt: payment.paidAt, issuedAt: receipt.issuedAt,
      };
      return view;
    },

    teachers: async (instituteId, studentId) => {
      assertChild(db, instituteId, studentId);
      const batchIds = activeBatchIds(db, instituteId, studentId);
      const subjects = new Map(db.subjects.all(instituteId).map((s) => [s.id, s.name]));
      const seen = new Map<string, FamilyTeacher>();
      for (const period of periodsFor(db, instituteId, batchIds)) {
        if (!period.teacherId || seen.has(`${period.teacherId}:${period.batchId}`)) continue;
        const teacher = db.teachers.get(instituteId, period.teacherId);
        seen.set(`${period.teacherId}:${period.batchId}`, {
          id: teacher.id, name: teacher.fullName, userId: teacher.userId,
          subjectName: subjects.get(period.subjectId ?? '') ?? 'Class', batchId: period.batchId,
          batchName: db.batches.get(instituteId, period.batchId).name,
        });
      }
      return [...seen.values()].sort((a, b) => a.name.localeCompare(b.name));
    },

    previewLeave: async (instituteId, studentId, fromDate, toDate) => {
      assertChild(db, instituteId, studentId);
      if (!isIsoDate(fromDate) || !isIsoDate(toDate)) fail('VALIDATION', 'Choose valid leave dates');
      const batchIds = activeBatchIds(db, instituteId, studentId);
      return previewLeaveClasses({
        fromDate, toDate, periods: periodsFor(db, instituteId, batchIds),
        batches: db.batches.all(instituteId).filter((b) => batchIds.includes(b.id)),
        subjects: db.subjects.all(instituteId),
      });
    },

    submitLeave: async (instituteId, input) => {
      const userId = requireUser(db);
      assertChild(db, instituteId, input.studentId);
      const reason = validateLeaveInput(input, todayIso());
      const batchIds = activeBatchIds(db, instituteId, input.studentId);
      const preview = previewLeaveClasses({
        fromDate: input.fromDate, toDate: input.toDate, periods: periodsFor(db, instituteId, batchIds),
        batches: db.batches.all(instituteId).filter((b) => batchIds.includes(b.id)), subjects: db.subjects.all(instituteId),
      });
      const affectedBatchIds = [...new Set(preview.classes.map((c) => c.batchId))];
      const request = db.studentLeaveRequests.insert(instituteId, {
        studentId: input.studentId, requestedBy: userId, leaveType: input.leaveType, fromDate: input.fromDate, toDate: input.toDate,
        days: inclusiveDays(input.fromDate, input.toDate), reason, affectedBatchIds, affectedClassCount: preview.classCount,
        status: 'pending', reviewNote: null, reviewedAt: null,
      });
      // Reaches the affected teachers and the owner.
      const teacherIds = teacherIdsFor(db, instituteId, affectedBatchIds);
      const recipients = new Set<ID>();
      for (const teacherId of teacherIds) {
        const teacher = db.teachers.find(instituteId, { id: teacherId });
        if (teacher?.userId) recipients.add(teacher.userId);
      }
      for (const membership of db.memberships.all(instituteId, { role: 'owner', status: 'active' })) recipients.add(membership.userId);
      const student = db.students.get(instituteId, input.studentId);
      for (const recipient of recipients) {
        notifyUser(db, instituteId, recipient, 'student_leave_requested', 'Leave request for a student',
          `${student.fullName} · ${input.fromDate} to ${input.toDate} · ${preview.classCount} class${preview.classCount === 1 ? '' : 'es'}`,
          { screen: 'leave-queue', leaveRequestId: request.id });
      }
      return request;
    },

    leaveRequests: async (instituteId, studentId) => {
      assertChild(db, instituteId, studentId);
      return db.studentLeaveRequests.all(instituteId, { studentId }).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },

    leaveQueue: async (instituteId) => {
      const role = callerRole(db, instituteId);
      if (role === 'owner' || role === 'admin') {
        return db.studentLeaveRequests.all(instituteId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      }
      if (role !== 'teacher') fail('FORBIDDEN', 'Only a teacher or the owner can see the leave queue');
      const teacher = callerTeacher(db, instituteId);
      if (!teacher) fail('FORBIDDEN', 'Teacher profile not found');
      const mine = new Set(db.batches.all(instituteId).filter((b) => b.teacherId === teacher.id).map((b) => b.id));
      db.timetables.all(instituteId).filter((p) => p.teacherId === teacher.id).forEach((p) => mine.add(p.batchId));
      return db.studentLeaveRequests.all(instituteId)
        .filter((r) => r.affectedBatchIds.some((id) => mine.has(id)))
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },

    meetings: async (instituteId, studentId) => {
      assertChild(db, instituteId, studentId);
      return db.meetings.all(instituteId, { studentId })
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        .map((m): FamilyMeeting => ({
          id: m.id, studentId, teacherId: m.teacherId, teacherName: db.teachers.get(instituteId, m.teacherId).fullName,
          preferredAt: m.preferredAt, status: m.status, responseNote: m.responseNote, respondedAt: m.respondedAt,
          reason: m.reason, createdAt: m.createdAt,
        }));
    },

    requestMeeting: async (instituteId, input) => {
      const userId = requireUser(db);
      assertChild(db, instituteId, input.studentId);
      const note = validateMeetingInput(input, todayIso());
      const batchIds = activeBatchIds(db, instituteId, input.studentId);
      if (!teacherIdsFor(db, instituteId, batchIds).has(input.teacherId)) {
        fail('FORBIDDEN', 'That teacher does not take your child');
      }
      const teacher = db.teachers.get(instituteId, input.teacherId);
      const membershipIds = new Set(db.memberships.all(instituteId, { userId, role: 'parent', status: 'active' }).map((m) => m.id));
      const guardian = db.guardians.all(instituteId).find((g) => g.membershipId && membershipIds.has(g.membershipId)
        && db.parentLinks.find(instituteId, { guardianId: g.id, studentId: input.studentId }));
      const meeting = db.meetings.insert(instituteId, merge(D.meeting(), {
        studentId: input.studentId, teacherId: input.teacherId, guardianId: guardian?.id ?? null, requestedBy: userId,
        reason: note, preferredAt: `${input.preferredDate}T00:00:00.000Z`,
      }));
      if (teacher.userId) {
        notifyUser(db, instituteId, teacher.userId, 'meeting_requested', 'A parent asked to meet you',
          `${input.preferredDate}${note ? ` · ${note}` : ''}`, { screen: 'meetings', meetingId: meeting.id });
      }
      emit(db, instituteId, 'notifications', 'created', meeting.id);
      return {
        id: meeting.id, studentId: input.studentId, teacherId: input.teacherId, teacherName: teacher.fullName,
        preferredAt: meeting.preferredAt, status: meeting.status, responseNote: null, respondedAt: null,
        reason: note, createdAt: meeting.createdAt,
      };
    },
  };
}

