import {
  NOTICE_NOTIFICATION_TYPE,
  canReadNotice,
  getNoticeValidationErrors,
  normaliseAudience,
  noticeAlertsOn,
  noticeNotificationBody,
  type NoticeReader,
} from '../../core/contracts/notices';
import type {
  ID,
  Notice,
  NoticeAudienceRole,
  PublishNoticeInput,
  PublishNoticeResult,
} from '../../core/contracts/models';
import { emit, type Db } from './db';
import * as D from './defaults';
import { activeLoginIdsForStudent, activeParentLoginIdsForStudent, studentEnrolledBatchIds } from './homework';
import { assertFeatureOpen } from './access';
import { fail, merge, nowIso } from './store';
import { assignmentOf, callerRole, teacherBatchScope } from './teacher-scope';

/** The institute's notice-alert setting: on unless it has been switched off. */
export function noticeAlertsEnabled(db: Db, instituteId: ID): boolean {
  return noticeAlertsOn(db.institutes.get(instituteId, instituteId).settings.features);
}

/** Who is asking, in the terms `canReadNotice` needs. */
export function noticeReader(db: Db, instituteId: ID): NoticeReader {
  const role = callerRole(db, instituteId);
  const batchIds =
    role === 'teacher'
      ? (teacherBatchScope(db, instituteId) ?? new Set<ID>())
      : role === 'student' || role === 'parent'
        ? studentEnrolledBatchIds(db, instituteId)
        : new Set<ID>();
  return { userId: db.session.userId, role, batchIds, now: nowIso() };
}

/** A notice the caller may not read is NOT_FOUND, the same as one that does not exist. */
export function readableNotice(db: Db, instituteId: ID, id: ID): Notice {
  const notice = db.notices.get(instituteId, id);
  if (!canReadNotice(notice, noticeReader(db, instituteId))) fail('NOT_FOUND', 'Notice not found');
  return notice;
}

const activeUsersWithRole = (db: Db, instituteId: ID, role: NoticeAudienceRole): ID[] =>
  db.memberships.all(instituteId, { role, status: 'active' }).map((membership) => membership.userId);

/**
 * The logins one audience role resolves to. `batchId` null = the whole
 * institute; otherwise only people attached to that batch: its enrolled
 * students, their linked parents, and the teacher the batch is assigned to.
 */
function recipientsFor(db: Db, instituteId: ID, role: NoticeAudienceRole, batchId: ID | null): ID[] {
  if (batchId === null) return activeUsersWithRole(db, instituteId, role);
  if (role === 'teacher') {
    const teacherId = assignmentOf(db, instituteId, db.batches.get(instituteId, batchId)).teacherId;
    const userId = teacherId ? (db.teachers.find(instituteId, { id: teacherId, status: 'active' })?.userId ?? null) : null;
    if (!userId) return [];
    return db.memberships.find(instituteId, { userId, role: 'teacher', status: 'active' }) ? [userId] : [];
  }
  const studentIds = db.enrollments.all(instituteId, { batchId, status: 'active' }).map((row) => row.studentId);
  const logins = role === 'student' ? activeLoginIdsForStudent : activeParentLoginIdsForStudent;
  // A login linked to a student but holding another role (a teacher who is also a guardian) is not that audience.
  return studentIds
    .flatMap((studentId) => logins(db, instituteId, studentId))
    .filter((userId) => db.memberships.find(instituteId, { userId, role, status: 'active' }) !== undefined);
}

/**
 * Publishes a notice and fans it out. One transaction's worth of work:
 *   1. only owner / admin / teacher may publish; a teacher only to their own batches,
 *   2. the notice row(s) are stored already published,
 *   3. if notice alerts are on, each person in the audience gets exactly one
 *      in-app notification — never the sender, never a pending or suspended member.
 */
export function broadcastNotice(db: Db, instituteId: ID, input: PublishNoticeInput): PublishNoticeResult {
  const sender = db.session.userId ?? fail('UNAUTHENTICATED');
  assertFeatureOpen(db, instituteId, 'broadcast');
  const role = callerRole(db, instituteId);
  if (role !== 'owner' && role !== 'admin' && role !== 'teacher') fail('FORBIDDEN', 'Only staff can publish a notice');

  const firstError = Object.values(getNoticeValidationErrors(input))[0];
  if (firstError) fail('VALIDATION', firstError);
  const audience = normaliseAudience(input.audience);
  const category = input.category ?? 'general';

  // Which batches the notice is bound to. `[null]` = one institute-wide notice.
  let targets: (ID | null)[];
  if (role === 'teacher') {
    const own = teacherBatchScope(db, instituteId) ?? new Set<ID>();
    if (input.batchId) {
      // Someone else's batch does not exist for a teacher.
      if (!own.has(input.batchId)) fail('NOT_FOUND', 'Batch not found');
      targets = [input.batchId];
    } else {
      if (own.size === 0) fail('VALIDATION', 'No class is assigned to you yet');
      targets = [...own];
    }
  } else {
    if (input.batchId) db.batches.get(instituteId, input.batchId);
    targets = [input.batchId ?? null];
  }

  const alertsEnabled = noticeAlertsEnabled(db, instituteId);
  const publishedAt = nowIso();
  const notified: Record<NoticeAudienceRole, number> = { student: 0, parent: 0, teacher: 0 };
  const reached = new Set<ID>([sender]);
  const notices: Notice[] = [];

  for (const batchId of targets) {
    const notice = db.notices.insert(
      instituteId,
      merge(D.notice(), {
        title: input.title.trim(),
        body: input.body.trim(),
        batchId,
        category,
        audience,
        eventOn: category === 'event' ? (input.eventOn ?? null) : null,
        publishedAt,
        createdBy: sender,
      }),
    );
    notices.push(notice);
    emit(db, instituteId, 'notices', 'created', notice.id);
    if (!alertsEnabled) continue;

    for (const audienceRole of audience) {
      for (const userId of recipientsFor(db, instituteId, audienceRole, batchId)) {
        if (reached.has(userId)) continue;
        reached.add(userId);
        const sent = db.notifications.insert(
          instituteId,
          merge(D.notification(), {
            userId,
            type: NOTICE_NOTIFICATION_TYPE,
            title: notice.title,
            body: noticeNotificationBody(notice.body),
            data: { screen: 'notice', noticeId: notice.id, batchId, category, audience: audienceRole },
          }),
        );
        emit(db, instituteId, 'notifications', 'created', sent.id);
        notified[audienceRole] += 1;
      }
    }
  }

  return {
    notices,
    notified,
    totalNotified: notified.student + notified.parent + notified.teacher,
    alertsDisabled: !alertsEnabled,
  };
}

/** Owner / admin, or the author. The notifications that pointed at the notice go with it. */
export function removeNotice(db: Db, instituteId: ID, id: ID): void {
  const notice = readableNotice(db, instituteId, id);
  const role = callerRole(db, instituteId);
  const isStaff = role === 'owner' || role === 'admin';
  if (!isStaff && notice.createdBy !== db.session.userId) fail('FORBIDDEN', 'Only the institute can delete this notice');
  db.notices.remove(instituteId, id);
  emit(db, instituteId, 'notices', 'removed', id);
  for (const notification of db.notifications.all(instituteId)) {
    if (notification.data?.noticeId !== id) continue;
    db.notifications.remove(instituteId, notification.id);
    emit(db, instituteId, 'notifications', 'removed', notification.id);
  }
}
