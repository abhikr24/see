import type { ID } from '../../core/contracts/models';
import type { ParentSummary } from '../../core/contracts/models/parent';
import { buildChildSummary } from '../../core/contracts/parent';
import { requireUser, type Db } from './db';
import { fail, todayIso } from './store';

/** Fail closed. Membership + guardian + parent_links are all institute-scoped. */
export function parentChildIds(db: Db, instituteId: ID): ID[] {
  const userId = requireUser(db);
  const memberships = db.memberships.all(instituteId, { userId, role: 'parent', status: 'active' });
  if (!memberships.length) fail('FORBIDDEN', 'An active parent membership is required');
  const membershipIds = new Set(memberships.map(m => m.id));
  const guardianIds = new Set(db.guardians.all(instituteId).filter(g => g.membershipId && membershipIds.has(g.membershipId)).map(g => g.id));
  return [...new Set(db.parentLinks.all(instituteId).filter(link => guardianIds.has(link.guardianId)).map(link => link.studentId))];
}
export function childSummary(db: Db, instituteId: ID): ParentSummary {
  const ids = parentChildIds(db, instituteId);
  const userId = requireUser(db);
  const institute = db.institutes.get(instituteId, instituteId);
  const profile = db.profiles.get(userId);
  const today = todayIso();
  return {
    parentName: profile?.fullName ?? 'Parent', parentPhotoUrl: profile?.avatarUrl ?? null,
    month: new Date(`${today}T12:00:00Z`).toLocaleDateString('en-IN', { month: 'long', year: 'numeric', timeZone: 'UTC' }),
    asOf: today,
    children: ids.map(studentId => {
      const batchIds = new Set(db.enrollments.all(instituteId, { studentId, status: 'active' }).map(e => e.batchId));
      const feeIds = new Set(db.studentFees.all(instituteId, { studentId }).filter(f => f.status !== 'cancelled').map(f => f.id));
      return buildChildSummary({
        today, student: db.students.get(instituteId, studentId), instituteName: institute.name,
        batches: db.batches.all(instituteId).filter(b => batchIds.has(b.id)),
        records: db.attendanceRecords.all(instituteId, { studentId }),
        sessions: db.attendanceSessions.all(instituteId).filter(s => batchIds.has(s.batchId)),
        exams: db.exams.all(instituteId).filter(e => batchIds.has(e.batchId)), marks: db.marks.all(instituteId, { studentId }),
        installments: db.installments.all(instituteId, { studentId }).filter(t => feeIds.has(t.studentFeeId)),
        assignments: db.assignments.all(instituteId).filter(a => batchIds.has(a.batchId)), submissions: db.submissions.all(instituteId, { studentId }),
        subjects: db.subjects.all(instituteId), notices: db.notices.all(instituteId),
      });
    }),
  };
}
