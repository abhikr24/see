import type {
  AttendanceSummary,
  ID,
  Intervention,
  InterventionOutcome,
  NewEntity,
  ProgressSnapshot,
  RiskAlert,
  RiskKind,
  RiskLevel,
  StudentAchievement,
  StudentGoal,
  StudyTask,
} from '../../core/contracts/models';
import type { ProgressPort } from '../../core/contracts/ports';
import {
  evaluateProgress,
  worstRisk,
  type ProgressFinding,
  type ProgressRuleInput,
} from '../../core/contracts/progress';
import { attendanceRecords, summarize } from './academics';
import { currentBatchId, myStudentIds, upsert, type Db } from './db';
import * as D from './defaults';
import { isOverdue, remaining } from './finance';
import { fail, nowIso, round1, round2, sum, todayIso } from './store';
import { fallingStudents } from './teacher';
import { callerRole } from './teacher-scope';

/** Every kind the current rules can open. Thresholds live in PROGRESS_RULES. */
const ALL_KINDS: RiskKind[] = [
  'low_attendance',
  'declining_marks',
  'work_incomplete',
  'sudden_absence',
  'improving',
  'fee_overdue',
];
/** Kinds the previous rules produced; open rows of these are resolved, never reopened. */
const LEGACY_KINDS: RiskKind[] = ['low_marks', 'missing_homework'];

const INTERVENTION_KINDS: Intervention['kind'][] = ['call_parent', 'extra_class', 'counselling', 'other'];
const INTERVENTION_OUTCOMES: InterventionOutcome[] = ['improved', 'unchanged', 'escalated'];

interface Measures {
  batchId: ID | null;
  attendance: AttendanceSummary;
  attendancePercent: number | null;
  examPercent: number | null;
  homeworkPercent: number | null;
  latestRank: number | null;
  feeDue: number;
  overdueInstallments: number;
  openDoubts: number;
}

type Finding = ProgressFinding;

function publishedResultsForStudent(db: Db, instituteId: ID, studentId: ID) {
  const publishedIds = new Set(
    db.exams
      .all(instituteId)
      .filter((e) => e.status === 'published')
      .map((e) => e.id),
  );
  return db.results
    .all(instituteId, { studentId })
    .filter((r) => publishedIds.has(r.examId))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

function measure(db: Db, instituteId: ID, studentId: ID): Measures {
  const attendance = summarize(attendanceRecords(db, instituteId, { studentId }));
  const results = publishedResultsForStudent(db, instituteId, studentId);
  const batchIds = db.enrollments.all(instituteId, { studentId, status: 'active' }).map((e) => e.batchId);
  const homework = db.assignments.all(instituteId).filter((a) => a.status !== 'draft' && batchIds.includes(a.batchId));
  const handedIn = homework.filter((a) => db.submissions.find(instituteId, { assignmentId: a.id, studentId }));
  const overdue = db.installments.all(instituteId, { studentId }).filter((x) => isOverdue(x));
  return {
    batchId: currentBatchId(db, instituteId, studentId),
    attendance,
    attendancePercent: attendance.total ? attendance.percent : null,
    examPercent: results.length ? round1(sum(results.map((r) => r.percentage)) / results.length) : null,
    homeworkPercent: homework.length ? round1((handedIn.length / homework.length) * 100) : null,
    latestRank: results[0]?.rank ?? null,
    feeDue: round2(sum(overdue.map(remaining))),
    overdueInstallments: overdue.length,
    openDoubts: db.doubts.all(instituteId, { studentId, status: 'open' }).length,
  };
}

/** The rows the pure progress rules read. Wording lives in core/contracts/progress.ts. */
function ruleInput(db: Db, instituteId: ID, studentId: ID): ProgressRuleInput {
  const dates = new Map(db.attendanceSessions.all(instituteId).map((s) => [s.id, s.date]));
  const attendance = db.attendanceRecords
    .all(instituteId, { studentId })
    .filter((record) => dates.has(record.sessionId))
    .map((record) => ({
      date: dates.get(record.sessionId) as string,
      attended: record.status === 'present' || record.status === 'late',
      absent: record.status === 'absent',
    }));
  const exams = new Map(db.exams.all(instituteId).map((e) => [e.id, e]));
  const tests = publishedResultsForStudent(db, instituteId, studentId).map((result) => {
    const exam = exams.get(result.examId);
    return {
      name: exam?.name ?? 'Test',
      percentage: result.percentage,
      when: exam?.endsOn ?? exam?.startsOn ?? result.createdAt,
    };
  });
  const batchIds = db.enrollments.all(instituteId, { studentId, status: 'active' }).map((e) => e.batchId);
  const homework = db.assignments
    .all(instituteId)
    .filter((a) => a.status !== 'draft' && batchIds.includes(a.batchId))
    .map((a) => {
      const submission = db.submissions.find(instituteId, { assignmentId: a.id, studentId });
      return { dueAt: a.dueAt, submitted: Boolean(submission && submission.status !== 'pending') };
    });
  const overdue = db.installments.all(instituteId, { studentId }).filter((x) => isOverdue(x));
  return {
    today: todayIso(),
    attendance,
    tests,
    homework,
    overdueInstallments: overdue.length,
    feeOutstanding: round2(sum(overdue.map(remaining))),
  };
}

/** The early-warning rules. Thresholds come from PROGRESS_RULES, shared with every adapter. */
function evaluate(db: Db, instituteId: ID, studentId: ID): Finding[] {
  return evaluateProgress(ruleInput(db, instituteId, studentId));
}

const worst = (findings: Finding[]): RiskLevel => worstRisk(findings);

const byDoneOnDesc = (a: Intervention, b: Intervention) =>
  b.doneOn.localeCompare(a.doneOn) || b.createdAt.localeCompare(a.createdAt);

export function progressPort(db: Db): ProgressPort {
  const openAlerts = (instituteId: ID, studentId: ID) =>
    db.alerts.all(instituteId, { studentId }).filter((alert) => alert.status !== 'resolved');

  const snapshot = (instituteId: ID, studentId: ID): ProgressSnapshot => {
    db.students.get(instituteId, studentId);
    const measures = measure(db, instituteId, studentId);
    const { attendance: _summary, ...numbers } = measures; // the summary is not part of a snapshot
    const riskLevel = worst(evaluate(db, instituteId, studentId));
    return db.snapshots.insert(instituteId, { studentId, computedAt: nowIso(), ...numbers, riskLevel });
  };

  /** Opens, refreshes or resolves this student's alerts so they match the rules right now. */
  const syncAlerts = (instituteId: ID, studentId: ID): RiskAlert[] => {
    const m = measure(db, instituteId, studentId);
    const findings = evaluate(db, instituteId, studentId);
    const open = openAlerts(instituteId, studentId);
    for (const kind of [...ALL_KINDS, ...LEGACY_KINDS]) {
      const finding = findings.find((f) => f.kind === kind);
      const existing = open.find((alert) => alert.kind === kind);
      if (finding && existing) db.alerts.update(instituteId, existing.id, finding);
      else if (finding) {
        db.alerts.insert(instituteId, {
          ...finding,
          studentId,
          batchId: m.batchId,
          status: 'open',
          detectedAt: nowIso(),
          resolvedAt: null,
        });
      } else if (existing) {
        db.alerts.update(instituteId, existing.id, { status: 'resolved', resolvedAt: nowIso() });
      }
    }
    return openAlerts(instituteId, studentId);
  };

  const assertOwnStudent = (instituteId: ID, studentId: ID) => {
    const role = callerRole(db, instituteId);
    if ((role === 'student' || role === 'parent') && !myStudentIds(db, instituteId).includes(studentId)) {
      fail('FORBIDDEN', 'You can only view your own progress');
    }
  };

  return {
    getStudent360: async (instituteId, studentId) => {
      assertOwnStudent(instituteId, studentId);
      const student = db.students.get(instituteId, studentId);
      const alerts = syncAlerts(instituteId, studentId);
      return {
        student,
        enrollments: db.enrollments.all(instituteId, { studentId }),
        guardians: db.parentLinks
          .all(instituteId, { studentId })
          .map((link) => db.guardians.get(instituteId, link.guardianId)),
        snapshot: snapshot(instituteId, studentId),
        attendance: measure(db, instituteId, studentId).attendance,
        results: publishedResultsForStudent(db, instituteId, studentId),
        installments: db.installments.all(instituteId, { studentId }).sort((a, b) => a.termNo - b.termNo),
        alerts,
        goals: db.studentGoals.all(instituteId, { studentId }),
        tasks: db.studyTasks.all(instituteId, { studentId }),
      };
    },
    computeSnapshot: async (instituteId, studentId) => {
      assertOwnStudent(instituteId, studentId);
      return snapshot(instituteId, studentId);
    },
    listSnapshots: async (instituteId, studentId) => {
      assertOwnStudent(instituteId, studentId);
      db.students.get(instituteId, studentId);
      return db.snapshots.all(instituteId, { studentId }).sort((a, b) => b.computedAt.localeCompare(a.computedAt));
    },
    listAlerts: async (instituteId, query) => {
      const role = callerRole(db, instituteId);
      if (role === 'student' || role === 'parent') {
        const own = new Set(myStudentIds(db, instituteId));
        return db.alerts.page(instituteId, query, {}, (a) => own.has(a.studentId));
      }
      return db.alerts.page(instituteId, query);
    },
    computeAlerts: async (instituteId, filter = {}) => {
      let studentIds: ID[];
      if (filter.studentId) studentIds = [db.students.get(instituteId, filter.studentId).id];
      else if (filter.batchId) {
        db.batches.get(instituteId, filter.batchId);
        studentIds = db.enrollments
          .all(instituteId, { batchId: filter.batchId, status: 'active' })
          .map((e) => e.studentId);
      } else studentIds = db.students.all(instituteId, { status: 'active' }).map((s) => s.id);
      return studentIds.flatMap((studentId) => syncAlerts(instituteId, studentId));
    },
    setAlertStatus: async (instituteId, alertId, status) =>
      db.alerts.update(instituteId, alertId, { status, resolvedAt: status === 'resolved' ? nowIso() : null }),
    listFallingStudents: async (instituteId) => fallingStudents(db, instituteId),
    listInterventions: async (instituteId, filter = {}) => {
      const role = callerRole(db, instituteId);
      const rows = filter.studentId
        ? db.interventions.all(instituteId, { studentId: filter.studentId })
        : db.interventions.all(instituteId);
      if (role === 'student' || role === 'parent') {
        const own = new Set(myStudentIds(db, instituteId));
        return rows.filter((row) => own.has(row.studentId)).sort(byDoneOnDesc);
      }
      return [...rows].sort(byDoneOnDesc);
    },
    logIntervention: async (
      instituteId,
      input: NewEntity<Intervention, 'studentId' | 'kind' | 'doneBy' | 'doneOn'>,
    ) => {
      db.students.get(instituteId, input.studentId);
      if (!INTERVENTION_KINDS.includes(input.kind)) fail('VALIDATION', 'Pick what was tried');
      if (!input.doneBy?.trim()) fail('VALIDATION', 'Say who did it');
      if (!input.doneOn || !/^\d{4}-\d{2}-\d{2}$/.test(input.doneOn)) {
        fail('VALIDATION', 'Give the date it was done');
      }
      if (input.doneOn > todayIso()) fail('VALIDATION', 'The date cannot be in the future');
      if (input.alertId) {
        const alert = db.alerts.get(instituteId, input.alertId);
        if (alert.studentId !== input.studentId) fail('VALIDATION', 'That alert is for another student');
      }
      return db.interventions.insert(instituteId, {
        studentId: input.studentId,
        batchId: input.batchId ?? currentBatchId(db, instituteId, input.studentId),
        alertId: input.alertId ?? null,
        kind: input.kind,
        note: input.note?.trim() ? input.note.trim() : null,
        doneBy: input.doneBy.trim(),
        doneOn: input.doneOn,
        outcome: null,
        closedAt: null,
      });
    },
    setInterventionOutcome: async (instituteId, id, outcome) => {
      if (!INTERVENTION_OUTCOMES.includes(outcome)) {
        fail('VALIDATION', 'Pick improved, unchanged or escalated');
      }
      return db.interventions.update(instituteId, id, { outcome, closedAt: nowIso() });
    },
    listTasks: async (instituteId, studentId) => {
      assertOwnStudent(instituteId, studentId);
      return db.studyTasks.all(instituteId, { studentId });
    },
    saveTask: async (instituteId, input) => {
      assertOwnStudent(instituteId, input.studentId);
      const completedAt = input.status === 'done' ? nowIso() : input.status ? null : undefined;
      return upsert<StudyTask, 'studentId' | 'title'>(db.studyTasks, D.studyTask)(instituteId, { ...input, completedAt });
    },
    removeTask: async (instituteId, id) => {
      const existing = db.studyTasks.get(instituteId, id);
      assertOwnStudent(instituteId, existing.studentId);
      return db.studyTasks.remove(instituteId, id);
    },
    listGoals: async (instituteId, studentId) => {
      assertOwnStudent(instituteId, studentId);
      return db.studentGoals.all(instituteId, { studentId });
    },
    saveGoal: async (instituteId, input) => {
      assertOwnStudent(instituteId, input.studentId);
      return upsert<StudentGoal, 'studentId' | 'title'>(db.studentGoals, D.studentGoal)(instituteId, input);
    },
    syncAchievements: async (instituteId, studentId) => {
      assertOwnStudent(instituteId, studentId);
      const now = new Date();
      const month = now.toISOString().slice(0, 7);
      const sessions = new Map(
        db.attendanceSessions.all(instituteId)
          .filter((session) => session.date.startsWith(month) && session.status !== 'open')
          .map((session) => [session.id, session]),
      );
      const monthRecords = db.attendanceRecords.all(instituteId, { studentId })
        .filter((record) => sessions.has(record.sessionId));
      const assignments = new Map(db.assignments.all(instituteId).map((assignment) => [assignment.id, assignment]));
      const onTimeHomework = db.submissions.all(instituteId, { studentId }).filter((submission) => {
        const dueAt = assignments.get(submission.assignmentId)?.dueAt;
        return Boolean(dueAt && submission.submittedAt && submission.submittedAt <= dueAt);
      }).length;
      const published = publishedResultsForStudent(db, instituteId, studentId);
      const eligible: { key: StudentAchievement['key']; title: string; description: string; unlocked: boolean }[] = [
        { key: 'perfect_attendance_month', title: 'Perfect attendance', description: 'Every class attended this month', unlocked: monthRecords.length > 0 && monthRecords.every((record) => record.status === 'present' || record.status === 'late') },
        { key: 'homework_streak_10', title: 'Homework hero', description: '10 homework assignments handed in on time', unlocked: onTimeHomework >= 10 },
        { key: 'first_90_score', title: 'First 90+', description: 'Earned 90% or higher on a published exam', unlocked: published.some((result) => result.percentage >= 90) },
      ];
      for (const item of eligible) {
        if (!item.unlocked || db.studentAchievements.find(instituteId, { studentId, key: item.key })) continue;
        db.studentAchievements.insert(instituteId, { studentId, key: item.key, title: item.title, description: item.description, earnedAt: nowIso(), celebratedAt: null });
      }
      return db.studentAchievements.all(instituteId, { studentId }).sort((a, b) => a.earnedAt.localeCompare(b.earnedAt));
    },
    markAchievementCelebrated: async (instituteId, studentId, achievementId) => {
      assertOwnStudent(instituteId, studentId);
      const achievement = db.studentAchievements.get(instituteId, achievementId);
      if (achievement.studentId !== studentId || achievement.celebratedAt) return false;
      db.studentAchievements.update(instituteId, achievementId, { celebratedAt: nowIso() });
      return true;
    },
  };
}
