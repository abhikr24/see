import { NOTICE_ALERTS_FEATURE, NOTICE_NOTIFICATION_TYPE, noticeNotificationBody } from '../../core/contracts/notices';
import type { ID, Notice, NoticeAudienceRole } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { addDays, todayIso } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INSTITUTE = sid(1);
const OWNER = sid(2);
const ROHIT = sid(3);
const ANITA = sid(37);
const CLASS_10A = sid(9);

const hoursAgo = (hours: number): string => new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();

interface SeedNotice {
  id: number;
  title: string;
  body: string;
  category: Notice['category'];
  audience: NoticeAudienceRole[];
  hours: number;
  batchId?: ID;
  createdBy?: ID;
  eventInDays?: number;
  pinned?: boolean;
  /** Notification ids start here; omitted = an older notice whose alerts are long gone. */
  notifyFrom?: number;
  /** Recipients have already opened it. */
  read?: boolean;
}

/** Ids 18001–18099 notices, 18100–18499 notifications. */
const NOTICES: SeedNotice[] = [
  {
    id: 18001, title: 'Annual Science Fair', category: 'event', audience: ['student', 'parent', 'teacher'], hours: 5,
    eventInDays: 9, pinned: true, notifyFrom: 18100,
    body: 'Our Science Fair is open to every class. Project teams of up to three, with a one-page abstract handed to your class teacher four days before the fair. Families are welcome from 10:00 AM; judging starts at 11:30 AM in the Lab.',
  },
  {
    id: 18002, title: 'Extra Mathematics class for 10-A', category: 'academic', audience: ['student', 'parent'], hours: 26,
    batchId: CLASS_10A, createdBy: ROHIT, notifyFrom: 18200, read: true,
    body: 'We are adding a revision class on Quadratic Equations this Saturday, 4:00–5:30 PM in Room 1. Bring the Chapter 4 practice set and your Unit Test 3 answer sheet.',
  },
  {
    id: 18003, title: 'Revised timetable from Monday', category: 'academic', audience: ['student', 'parent', 'teacher'], hours: 52,
    body: 'Evening batches move 30 minutes earlier from Monday to make room for doubt-clearing hours. The updated timetable is in the app for every class.',
  },
  {
    id: 18004, title: 'Staff meeting on Saturday', category: 'general', audience: ['teacher'], hours: 54,
    notifyFrom: 18300, read: true,
    body: 'All teachers, please join at 5:45 PM in Room 2. Agenda: Unit Test 3 review, the revised timetable and half-yearly paper setting.',
  },
  {
    id: 18005, title: 'Winter break dates', category: 'holiday', audience: ['student', 'parent', 'teacher'], hours: 96,
    eventInDays: 40,
    body: 'Classes pause for the winter break in the last week of December. Doubt-clearing sessions continue online on alternate days; the schedule will follow.',
  },
  {
    id: 18006, title: 'Fee receipts are now in the app', category: 'fee', audience: ['parent'], hours: 120,
    body: 'Every paid term now has a receipt you can download or share from the Fees tab. If a payment made at the office is missing, tell the front desk and we will fix it the same day.',
  },
];

/**
 * Demo notices across every category, plus the inbox rows they would have
 * produced. Recipients are read from the memberships table, so the fan-out
 * here follows the same rule as `broadcastNotice`: active members with the
 * addressed role, one row each, never the author.
 */
export function seedNotices(db: Db): void {
  const today = todayIso();
  const row = (n: number, at: string) => ({ id: sid(n), instituteId: INSTITUTE, createdAt: at, updatedAt: at });
  const withRole = (role: NoticeAudienceRole): ID[] =>
    db.memberships.all(INSTITUTE, { role, status: 'active' }).map((membership) => membership.userId);

  for (const spec of NOTICES) {
    const at = hoursAgo(spec.hours);
    const author = spec.createdBy ?? OWNER;
    db.notices.put({
      ...D.notice(), ...row(spec.id, at), title: spec.title, body: spec.body, category: spec.category,
      audience: spec.audience, batchId: spec.batchId ?? null, isPinned: spec.pinned ?? false, publishedAt: at,
      eventOn: spec.category === 'event' && spec.eventInDays ? addDays(today, spec.eventInDays) : null,
      createdBy: author,
    });
    if (spec.notifyFrom === undefined) continue;
    let next = spec.notifyFrom;
    for (const role of spec.audience) {
      for (const userId of withRole(role)) {
        if (userId === author) continue;
        db.notifications.put({
          ...D.notification(), ...row(next, at), userId, type: NOTICE_NOTIFICATION_TYPE, title: spec.title,
          body: noticeNotificationBody(spec.body), sentAt: at, readAt: spec.read ? hoursAgo(Math.max(1, spec.hours - 2)) : null,
          data: { screen: 'notice', noticeId: sid(spec.id), batchId: spec.batchId ?? null, category: spec.category, audience: role },
        });
        next += 1;
      }
    }
  }

  // Two inbox rows that are not announcements, so the owner and the sample parent see more than one icon.
  const pendingLeave = db.leaveRequests.all(INSTITUTE, { status: 'pending' })[0];
  if (pendingLeave) {
    const at = pendingLeave.createdAt;
    db.notifications.put({
      ...D.notification(), ...row(18400, at), userId: OWNER, type: 'leave_requested', title: 'Leave request needs approval',
      body: `${pendingLeave.leaveType} leave · ${pendingLeave.fromDate} to ${pendingLeave.toDate}`, sentAt: at, readAt: null,
      data: { screen: 'approvals', leaveRequestId: pendingLeave.id },
    });
  }
  const receiptsAt = hoursAgo(120);
  db.notifications.put({
    ...D.notification(), ...row(18401, receiptsAt), userId: ANITA, type: 'fee_receipts', title: 'Fee receipts are now in the app',
    body: 'Every paid term has a receipt you can download or share from the Fees tab.', sentAt: receiptsAt, readAt: hoursAgo(100),
    data: { screen: 'fees' },
  });
}

/**
 * Tops up a snapshot saved before notices were built. An institute whose
 * notice-alert setting has never been written gets it switched on and the demo
 * notices added — once: after that the setting exists, so a notice the owner
 * deleted is never brought back.
 */
export function ensureNotices(db: Db): void {
  const institute = db.institutes.everything().find((entry) => entry.id === INSTITUTE);
  if (!institute) return;
  for (const notice of db.notices.all(INSTITUTE)) {
    if (notice.eventOn === undefined) db.notices.put({ ...notice, eventOn: null });
  }
  if (institute.settings.features?.[NOTICE_ALERTS_FEATURE] !== undefined) return;
  db.institutes.put({
    ...institute,
    settings: { ...institute.settings, features: { ...institute.settings.features, [NOTICE_ALERTS_FEATURE]: true } },
  });
  seedNotices(db);
}
