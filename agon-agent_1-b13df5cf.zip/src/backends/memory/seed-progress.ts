import type { AttendanceStatus, ID } from '../../core/contracts/models';
import { gradeForPercent, rankWithTies } from '../../core/contracts/exam-analysis';
import type { Db } from './db';
import * as D from './defaults';
import { addDays, nowIso, todayIso } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INST = sid(1);
const CLASS_11A = sid(11);
const MEERA = sid(5);
const CHEMISTRY = sid(46);

/** Class 11-A, rolls 1–8: the progress board's demo students. */
const CLASS_11A_ROLLS = [80, 81, 82, 83, 84, 85, 86, 87];
/** Sanya Rao: attendance 60% in the window, absent 3 days in a row. */
const LOW_ATTENDANCE_STUDENT = sid(81);
/** Nikhil Bose: 85 → 80 → 74 across the last 3 tests (drop 11, latest-vs-previous 6). */
const DECLINING_STUDENT = sid(85);
/** Rhea Singh: 70 → 68 → 80 (up 12 in the latest test). */
const IMPROVING_STUDENT = sid(83);
/** Varun Mehta: 1 of 3 homework sets handed in (33%). */
const BEHIND_ON_HOMEWORK = sid(82);

const ATTENDANCE_DAY_OFFSETS = [-10, -9, -8, -7, -6, -5, -4, -3, -2, -1];
const ABSENT_OFFSETS = new Set([-8, -3, -2, -1]);

/** Three Chemistry quizzes, oldest first. Flat for everyone except the two demo students. */
const QUIZZES: { id: number; name: string; startsAgo: number; endsAgo: number; marks: number[] }[] = [
  { id: 57, name: 'Chemistry Quiz 1', startsAgo: 20, endsAgo: 19, marks: [76, 72, 78, 70, 74, 85, 80, 68] },
  { id: 58, name: 'Chemistry Quiz 2', startsAgo: 12, endsAgo: 11, marks: [77, 73, 77, 68, 75, 80, 79, 69] },
  { id: 59, name: 'Chemistry Quiz 3', startsAgo: 5, endsAgo: 4, marks: [76, 72, 78, 80, 74, 74, 81, 68] },
];

const SETS: { id: number; title: string; instructions: string; assignedAgo: number; dueAgo: number }[] = [
  { id: 14021, title: 'Chemical reactions: worksheet 1', instructions: 'Balance all ten equations.', assignedAgo: 16, dueAgo: 12 },
  { id: 14022, title: 'Acids and bases: numericals', instructions: 'Show the formula before substituting.', assignedAgo: 12, dueAgo: 8 },
  { id: 14023, title: 'Metals and non-metals: notes', instructions: 'One page on reactivity order.', assignedAgo: 7, dueAgo: 3 },
];

/**
 * Progress demo data, kept inside Class 11-A so no other suite's pinned
 * numbers move: 9-A stays empty (the teacher suite asserts that), 10-A is
 * untouched, and the batch/student counts stay at 3 and 30.
 *
 *   - Sanya Rao: 6 of 10 present (60%) with absences on the last 3 days →
 *     low_attendance + sudden_absence in Needs attention.
 *   - Nikhil Bose: 85 → 80 → 74 → declining_marks in Watch. The latest exam
 *     is only 6 below the one before, so the teacher falling rule (10) stays quiet.
 *   - Varun Mehta: 1 of 3 sets handed in → work_incomplete in Watch.
 *   - Rhea Singh: 68 → 80 → improving in teal.
 *
 * Ten roll calls is below the teacher falling rule's two 14-wide windows, so
 * the owner's falling-student count stays exactly as the teacher suite pins it.
 */
export function seedProgress(db: Db): void {
  const at = nowIso();
  const today = todayIso();

  ATTENDANCE_DAY_OFFSETS.forEach((offset, dayIdx) => {
    const sessionId = sid(30000 + dayIdx);
    db.attendanceSessions.put({
      id: sessionId, instituteId: INST, createdAt: at, updatedAt: at, batchId: CLASS_11A,
      subjectId: null, teacherId: MEERA, date: addDays(today, offset), period: 1,
      status: 'submitted', markedBy: MEERA, markedAt: at, notes: null,
    });
    CLASS_11A_ROLLS.forEach((roll, si) => {
      const status: AttendanceStatus =
        sid(roll) === LOW_ATTENDANCE_STUDENT && ABSENT_OFFSETS.has(offset) ? 'absent' : 'present';
      db.attendanceRecords.put({
        id: sid(30100 + dayIdx * 20 + si), instituteId: INST, createdAt: at, updatedAt: at,
        sessionId, batchId: CLASS_11A, studentId: sid(roll), status, remark: null, markedBy: MEERA,
      });
    });
  });

  QUIZZES.forEach((quiz, quizIdx) => {
    const examId = sid(quiz.id);
    db.exams.put({
      ...D.exam(), id: examId, instituteId: INST, createdAt: at, updatedAt: at,
      batchId: CLASS_11A, subjectId: CHEMISTRY, name: quiz.name, examType: 'weekly_test',
      startsOn: addDays(today, -quiz.startsAgo), endsOn: addDays(today, -quiz.endsAgo),
      totalMarks: 100, passPercent: 33, status: 'published', publishedAt: at, createdBy: MEERA,
    });
    const ranks = rankWithTies(quiz.marks);
    CLASS_11A_ROLLS.forEach((roll, si) => {
      const obtained = quiz.marks[si];
      const percentage = obtained;
      db.marks.put({
        id: sid(31000 + quizIdx * 20 + si), instituteId: INST, createdAt: at, updatedAt: at,
        examId, batchId: CLASS_11A, studentId: sid(roll), subjectId: CHEMISTRY,
        marksObtained: obtained, maxMarks: 100, isAbsent: false,
        grade: gradeForPercent(percentage), remark: null, enteredBy: MEERA,
      });
      db.results.put({
        id: sid(31100 + quizIdx * 20 + si), instituteId: INST, createdAt: at, updatedAt: at,
        examId, batchId: CLASS_11A, studentId: sid(roll), totalObtained: obtained,
        totalMax: 100, percentage, grade: gradeForPercent(percentage), rank: ranks[si],
        status: percentage >= 33 ? 'pass' : 'fail', remarks: null,
      });
    });
  });

  let row = 0;
  for (const set of SETS) {
    const dueDate = addDays(today, -set.dueAgo);
    db.assignments.put({
      ...D.assignment(), id: sid(set.id), instituteId: INST, createdAt: at, updatedAt: at,
      batchId: CLASS_11A, subjectId: CHEMISTRY, teacherId: MEERA, title: set.title,
      instructions: set.instructions, assignedOn: addDays(today, -set.assignedAgo),
      dueAt: `${dueDate}T18:30:00.000Z`, maxMarks: 20, status: 'published', createdBy: MEERA,
    });
    for (const roll of CLASS_11A_ROLLS) {
      // Varun hands in only the most recent set; everyone else hands in all three.
      if (sid(roll) === BEHIND_ON_HOMEWORK && set.id !== 14023) continue;
      row += 1;
      db.submissions.put({
        id: sid(14500 + row), instituteId: INST, createdAt: at, updatedAt: at,
        assignmentId: sid(set.id), batchId: CLASS_11A, studentId: sid(roll),
        content: null, submittedAt: `${addDays(dueDate, -1)}T15:44:00.000Z`, status: 'submitted',
      });
    }
  }

  // One open intervention (the board's "open" count) and one closed with an outcome.
  db.interventions.put({
    id: sid(14601), instituteId: INST, createdAt: at, updatedAt: at,
    studentId: LOW_ATTENDANCE_STUDENT, batchId: CLASS_11A, alertId: null,
    kind: 'call_parent', note: 'Spoke about the missed classes this week.',
    doneBy: 'Meera Iyer', doneOn: addDays(today, -2), outcome: null, closedAt: null,
  });
  db.interventions.put({
    id: sid(14602), instituteId: INST, createdAt: at, updatedAt: at,
    studentId: DECLINING_STUDENT, batchId: CLASS_11A, alertId: null,
    kind: 'extra_class', note: 'Extra practice set for the last two quizzes.',
    doneBy: 'Meera Iyer', doneOn: addDays(today, -9), outcome: 'improved',
    closedAt: `${addDays(today, -1)}T10:00:00.000Z`,
  });
}

/** Tops up a snapshot saved before the progress demo existed. */
export function ensureProgress(db: Db): void {
  if (db.attendanceSessions.all(INST, { id: sid(30000) }).length === 0) seedProgress(db);
}

export const PROGRESS_DEMO = {
  lowAttendanceStudent: LOW_ATTENDANCE_STUDENT,
  decliningStudent: DECLINING_STUDENT,
  improvingStudent: IMPROVING_STUDENT,
  behindOnHomework: BEHIND_ON_HOMEWORK,
};
