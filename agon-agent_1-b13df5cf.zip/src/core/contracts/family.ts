import type { Batch, FamilyLeaveType, ISODate, LeaveClassCount, LeavePreview, Subject, Timetable } from './models';
import { BackendError } from './errors';

/** The pure rules for the parent's fees, leave and meetings. Shared by every adapter and the tests. */

export const LEAVE_TYPE_LABELS: Record<FamilyLeaveType, string> = {
  sick: 'Sick',
  family: 'Family matter',
  personal: 'Personal',
  other: 'Other',
};

export const ONLINE_PAYMENT_OFF = 'Online payment is not enabled yet — please pay at the office.';
export const LEAVE_MAX_DAYS = 60;
export const LEAVE_BACKDATE_DAYS = 14;
export const MEETING_NOTE_MAX = 280;

const DATE = /^\d{4}-\d{2}-\d{2}$/;

export function isIsoDate(value: string): boolean {
  if (!DATE.test(value)) return false;
  const time = Date.parse(`${value}T00:00:00Z`);
  return !Number.isNaN(time) && new Date(time).toISOString().slice(0, 10) === value;
}

function addDaysIso(date: ISODate, days: number): ISODate {
  return new Date(Date.parse(`${date}T00:00:00Z`) + days * 86_400_000).toISOString().slice(0, 10);
}

/** Inclusive calendar days from `from` to `to`. Throws when the range is backwards. */
export function inclusiveDays(from: ISODate, to: ISODate): number {
  if (to < from) throw new BackendError('VALIDATION', 'The end date cannot be before the start date');
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000) + 1;
}

/** Every date from `from` to `to`, inclusive. */
export function datesBetween(from: ISODate, to: ISODate): ISODate[] {
  const out: ISODate[] = [];
  for (let day = 0; day < inclusiveDays(from, to); day++) out.push(addDaysIso(from, day));
  return out;
}

/** Validates a leave request's dates and reason before anything is written. Returns the trimmed reason. */
export function validateLeaveInput(input: { leaveType: FamilyLeaveType; fromDate: ISODate; toDate: ISODate; reason: string }, today: ISODate): string {
  if (!(input.leaveType in LEAVE_TYPE_LABELS)) throw new BackendError('VALIDATION', 'Choose a leave type');
  if (!isIsoDate(input.fromDate) || !isIsoDate(input.toDate)) throw new BackendError('VALIDATION', 'Choose valid leave dates');
  const days = inclusiveDays(input.fromDate, input.toDate);
  if (days > LEAVE_MAX_DAYS) throw new BackendError('VALIDATION', `Leave can be requested for up to ${LEAVE_MAX_DAYS} days at a time`);
  if (input.fromDate < addDaysIso(today, -LEAVE_BACKDATE_DAYS)) throw new BackendError('VALIDATION', `Leave can be backdated by ${LEAVE_BACKDATE_DAYS} days at most`);
  const reason = input.reason.trim();
  if (reason.length < 3 || reason.length > 300) throw new BackendError('VALIDATION', 'Add a short reason (3 to 300 characters)');
  return reason;
}

/** Validates a meeting request. Returns the trimmed note, or null. */
export function validateMeetingInput(input: { preferredDate: ISODate; note: string }, today: ISODate): string | null {
  if (!isIsoDate(input.preferredDate)) throw new BackendError('VALIDATION', 'Choose a preferred date');
  if (input.preferredDate < today) throw new BackendError('VALIDATION', 'Choose today or a later date');
  const note = input.note.trim();
  if (note.length > MEETING_NOTE_MAX) throw new BackendError('VALIDATION', `Keep the note under ${MEETING_NOTE_MAX} characters`);
  return note.length ? note : null;
}

/**
 * The classes a leave covers: every timetable period of the child's batches whose weekday falls
 * inside the dates and whose validity window includes that day.
 */
export function previewLeaveClasses(input: {
  fromDate: ISODate;
  toDate: ISODate;
  periods: Pick<Timetable, 'batchId' | 'subjectId' | 'dayOfWeek' | 'validFrom' | 'validTo'>[];
  batches: Pick<Batch, 'id' | 'name'>[];
  subjects: Pick<Subject, 'id' | 'name'>[];
}): LeavePreview {
  const dates = datesBetween(input.fromDate, input.toDate);
  const batchName = new Map(input.batches.map((b) => [b.id, b.name]));
  const subjectName = new Map(input.subjects.map((s) => [s.id, s.name]));
  const counts = new Map<string, LeaveClassCount>();
  for (const period of input.periods) {
    if (!batchName.has(period.batchId)) continue;
    const hits = dates.filter((date) => {
      const weekday = new Date(`${date}T12:00:00Z`).getUTCDay();
      return weekday === period.dayOfWeek && (!period.validFrom || date >= period.validFrom) && (!period.validTo || date <= period.validTo);
    }).length;
    if (!hits) continue;
    const key = `${period.batchId}:${period.subjectId ?? ''}`;
    const current = counts.get(key);
    if (current) current.sessions += hits;
    else counts.set(key, { batchId: period.batchId, batchName: batchName.get(period.batchId) ?? '', subjectName: subjectName.get(period.subjectId ?? '') ?? 'Class', sessions: hits });
  }
  const classes = [...counts.values()].sort((a, b) => a.batchName.localeCompare(b.batchName) || a.subjectName.localeCompare(b.subjectName));
  return { days: inclusiveDays(input.fromDate, input.toDate), classCount: classes.reduce((sum, c) => sum + c.sessions, 0), classes };
}

type Tone = 'warning' | 'success' | 'danger' | 'neutral';

/** A declined meeting is never shown as a confirmed one. */
export function meetingStatusView(status: string): { label: string; tone: Tone } {
  if (status === 'accepted') return { label: 'Confirmed', tone: 'success' };
  if (status === 'declined') return { label: 'Declined', tone: 'danger' };
  if (status === 'completed') return { label: 'Completed', tone: 'neutral' };
  if (status === 'cancelled') return { label: 'Cancelled', tone: 'neutral' };
  return { label: 'Requested', tone: 'warning' };
}

export function leaveStatusView(status: string): { label: string; tone: Tone } {
  if (status === 'approved') return { label: 'Approved', tone: 'success' };
  if (status === 'rejected') return { label: 'Declined', tone: 'danger' };
  if (status === 'cancelled') return { label: 'Cancelled', tone: 'neutral' };
  return { label: 'Waiting for approval', tone: 'warning' };
}

/** A receipt must describe the payment it was issued for, to the paisa. */
export function assertReceiptMatchesPayment(receipt: { paymentId: string; amount: number }, payment: { id: string; amount: number }): void {
  if (receipt.paymentId !== payment.id || Math.round(receipt.amount * 100) !== Math.round(payment.amount * 100)) {
    throw new BackendError('CONFLICT', 'This receipt does not match its payment. Please contact the office.');
  }
}
