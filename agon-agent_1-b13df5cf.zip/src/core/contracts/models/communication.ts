import type { ID, ISODate, ISODateTime, JsonObject, Role, TenantEntity } from './common';

/** An announcement. `publishedAt` null = draft; `batchId` null = everyone in `audience`. */
export interface Notice extends TenantEntity {
  batchId: ID | null;
  title: string;
  body: string;
  category: 'general' | 'academic' | 'exam' | 'fee' | 'holiday' | 'event' | 'urgent';
  audience: Role[];
  isPinned: boolean;
  publishedAt: ISODateTime | null;
  expiresAt: ISODateTime | null;
  /** The day an `event` notice is about. null for every other category (and for older rows). */
  eventOn: ISODate | null;
  createdBy: ID | null;
}

/** The roles a notice composer can address. Owners and admins read every notice anyway. */
export type NoticeAudienceRole = Extract<Role, 'student' | 'parent' | 'teacher'>;

/** What the composer sends. The backend owns who that reaches. */
export interface PublishNoticeInput {
  title: string;
  body: string;
  /** At least one role. */
  audience: NoticeAudienceRole[];
  /** null = all batches. For a teacher that means every batch assigned to them, never the whole institute. */
  batchId: ID | null;
  category?: Notice['category'];
  /** Required when `category` is `event`. */
  eventOn?: ISODate | null;
}

export interface PublishNoticeResult {
  /** One notice, except a teacher addressing all of their batches: one per batch. */
  notices: Notice[];
  /** In-app notifications created, per audience role. Each person is counted once. */
  notified: Record<NoticeAudienceRole, number>;
  totalNotified: number;
  /** The institute's notice-alert setting is off: the notice is listed, nobody was notified. */
  alertsDisabled: boolean;
}

export type NotificationChannel = 'in_app' | 'push' | 'sms' | 'email' | 'whatsapp';

/** One message to one person. Named AppNotification to avoid the DOM `Notification`. */
export interface AppNotification extends TenantEntity {
  userId: ID;
  type: string;
  title: string;
  body: string | null;
  /** Routing payload, e.g. `{ screen: 'notice', id: '…' }`. */
  data: JsonObject;
  channel: NotificationChannel;
  sentAt: ISODateTime | null;
  readAt: ISODateTime | null;
}

export interface ConversationMessage {
  id: ID;
  senderId: ID;
  body: string;
  sentAt: ISODateTime;
}

export interface Conversation extends TenantEntity {
  kind: 'direct' | 'parent_teacher' | 'group' | 'support';
  title: string | null;
  /** The student the thread is about, if any. */
  studentId: ID | null;
  participantIds: ID[];
  messages: ConversationMessage[];
  lastMessagePreview: string | null;
  lastMessageAt: ISODateTime | null;
  isArchived: boolean;
  createdBy: ID | null;
}

export type DoubtStatus = 'open' | 'answered' | 'resolved' | 'closed';

/** A student's question and the teacher's answer. */
export interface Doubt extends TenantEntity {
  batchId: ID;
  studentId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  askedBy: ID | null;
  topic: string | null;
  question: string;
  answer: string | null;
  answeredBy: ID | null;
  answeredAt: ISODateTime | null;
  status: DoubtStatus;
}

export type MeetingStatus = 'pending' | 'accepted' | 'declined' | 'completed' | 'cancelled';

/** A parent–teacher meeting. */
export interface MeetingRequest extends TenantEntity {
  studentId: ID;
  teacherId: ID;
  guardianId: ID | null;
  requestedBy: ID | null;
  reason: string | null;
  preferredAt: ISODateTime | null;
  scheduledAt: ISODateTime | null;
  durationMinutes: number | null;
  mode: 'in_person' | 'phone' | 'video';
  status: MeetingStatus;
  responseNote: string | null;
  respondedAt: ISODateTime | null;
}

export type RealtimeTopic =
  | 'memberships'
  | 'attendance'
  | 'notices'
  | 'notifications'
  | 'doubts'
  | 'leave_requests'
  | 'conversations'
  | 'payments';

export interface RealtimeEvent {
  topic: RealtimeTopic;
  change: 'created' | 'updated' | 'removed';
  /** Id of the record that changed. Fetch it through its repo. */
  id: ID;
  at: ISODateTime;
}

export type RealtimeStatus = 'connected' | 'connecting' | 'offline';
