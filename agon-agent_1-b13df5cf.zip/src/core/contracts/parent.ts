import type { Assignment, AttendanceRecord, AttendanceSession, Batch, Exam, Installment, Mark, Notice, Student, Subject, Submission } from './models';
import type { ParentChildSummary, ParentTerm, ParentUpdate } from './models/parent';

export interface ChildSummaryInput {
  today: string;
  student: Student;
  instituteName: string;
  batches: Batch[];
  records: AttendanceRecord[];
  sessions: AttendanceSession[];
  exams: Exam[];
  marks: Mark[];
  installments: Installment[];
  assignments: Assignment[];
  submissions: Submission[];
  subjects: Subject[];
  notices: Notice[];
}
const round = (n: number) => Math.round(n * 100) / 100;
export function buildChildSummary(input: ChildSummaryInput): ParentChildSummary {
  const { student, today } = input;
  const batchIds = new Set(input.batches.map(b => b.id));
  const month = today.slice(0, 7);
  const sessions = new Map(input.sessions.filter(s => s.status !== 'open' && s.date <= today).map(s => [s.id, s]));
  const attendance = input.records.filter(r => r.studentId === student.id && sessions.has(r.sessionId))
    .map(r => ({ id: r.id, date: sessions.get(r.sessionId)!.date, status: r.status }))
    .filter(r => r.date.startsWith(month)).sort((a, b) => b.date.localeCompare(a.date));
  const attended = attendance.filter(r => r.status === 'present' || r.status === 'late').length;
  const scores = input.exams.filter(e => batchIds.has(e.batchId) && e.status === 'published')
    .map(e => {
      const marks = input.marks.filter(m => m.studentId === student.id && m.examId === e.id && (m.marksObtained !== null || m.isAbsent));
      const max = marks.reduce((sum, m) => sum + m.maxMarks, 0);
      return { id: e.id, label: e.name, date: e.startsOn ?? e.createdAt.slice(0, 10), percent: max ? round(marks.reduce((sum, m) => sum + (m.marksObtained ?? 0), 0) / max * 100) : null };
    }).filter((e): e is typeof e & { percent: number } => e.percent !== null && e.date <= today)
    .sort((a, b) => a.date.localeCompare(b.date));
  const thisMonth = scores.filter(e => e.date.startsWith(month));
  const trend = scores.slice(-5);
  const terms: ParentTerm[] = input.installments.filter(t => t.studentId === student.id && t.status !== 'waived')
    .map(t => ({ id: t.id, studentFeeId: t.studentFeeId, label: t.label, amount: t.amount, paidAmount: t.paidAmount, remaining: round(Math.max(0, t.amount - t.paidAmount)), dueDate: t.dueDate }))
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const outstanding = terms.filter(t => t.remaining > 0);
  const subjectName = (id: string | null) => input.subjects.find(s => s.id === id)?.name ?? 'Classwork';
  const updates: ParentUpdate[] = [];
  const homework = input.assignments.filter(a => batchIds.has(a.batchId) && a.status !== 'draft').sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  if (homework) {
    const sub = input.submissions.find(s => s.assignmentId === homework.id && s.studentId === student.id);
    const done = sub && ['submitted', 'late', 'graded', 'returned'].includes(sub.status);
    updates.push({ id: homework.id, kind: 'homework', title: done ? 'Homework submitted' : 'New homework assigned', subtitle: `${subjectName(homework.subjectId)} · ${homework.title}`, body: `${homework.instructions ?? homework.title}\n\n${done ? `${student.fullName.split(' ')[0]} has handed in this assignment. A little encouragement goes a long way.` : 'A little time set aside for practice can make a big difference.'}`, date: sub?.submittedAt ?? homework.createdAt });
  }
  const absence = attendance.find(r => r.status === 'absent' || r.status === 'late');
  if (absence) updates.push({ id: absence.id, kind: 'attendance', title: absence.status === 'late' ? 'Arrived a little late' : 'An attendance heads-up', subtitle: `${absence.status === 'late' ? 'Marked late' : 'One class missed'} · ${formatParentDate(absence.date)}`, body: `${student.fullName.split(' ')[0]} was marked ${absence.status} on ${formatParentDate(absence.date)}. If this doesn’t look right, please check with the class teacher. We’re here to keep you in the loop, not to worry you.`, date: absence.date });
  const notice = input.notices.filter(n => n.publishedAt && n.publishedAt.slice(0, 10) <= today && (!n.expiresAt || n.expiresAt.slice(0, 10) >= today) && n.audience.includes('parent') && (!n.batchId || batchIds.has(n.batchId))).sort((a, b) => b.publishedAt!.localeCompare(a.publishedAt!))[0];
  if (notice) updates.push({ id: notice.id, kind: 'notice', title: notice.title, subtitle: `${input.instituteName.replace(' Classes', '')} · Notice`, body: notice.body, date: notice.publishedAt! });
  return {
    id: student.id, name: student.fullName, photoUrl: student.photoUrl,
    classLabel: input.batches.map(b => b.name).join(' · ') || `Class ${student.classGrade ?? '—'}`,
    instituteName: input.instituteName,
    attendancePercent: attendance.length ? round(attended / attendance.length * 100) : null,
    averagePercent: thisMonth.length ? round(thisMonth.reduce((sum, e) => sum + e.percent, 0) / thisMonth.length) : null,
    dueNow: round(outstanding.filter(t => t.dueDate <= today).reduce((sum, t) => sum + t.remaining, 0)),
    totalOutstanding: round(outstanding.reduce((sum, t) => sum + t.remaining, 0)),
    attendance, trend, improvement: trend.length >= 2 ? round(trend.at(-1)!.percent - trend[0].percent) : null,
    updates, terms, nextFee: outstanding[0] ?? null,
  };
}
export function formatParentDate(date: string): string {
  return new Date(`${date.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', timeZone: 'UTC' });
}
