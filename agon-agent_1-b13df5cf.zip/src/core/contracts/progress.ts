import type { ID, ISODate, RiskAlert, RiskKind, RiskLevel } from './models';

/**
 * The progress early-warning rules: four data streams (attendance, marks,
 * homework, absence) turned into a short, actionable list.
 *
 * Pure: both adapters load already-scoped rows and hand them here, so no
 * screen and no adapter words an alert twice. Thresholds live in
 * PROGRESS_RULES and nowhere else.
 *
 * Every finding states the rule in words a parent could read, with the actual
 * number. Findings never label a student: no "weak", "poor", "failing".
 */

/** When a rule fires. Change the numbers here, nowhere else. */
export const PROGRESS_RULES = {
  /** low_attendance: below this % over the last 30 days. */
  LOW_ATTENDANCE_PCT: 75,
  /** low_attendance + sudden_absence look-back window. */
  ATTENDANCE_WINDOW_DAYS: 30,
  /** Fewer records than this in the window is too little to call a trend. */
  ATTENDANCE_MIN_RECORDS: 5,
  /** declining_marks: the oldest of the last 3 tests minus the latest, in points. */
  MARKS_DROP_POINTS: 10,
  /** declining_marks compares exactly this many published tests. */
  MARKS_TEST_COUNT: 3,
  /** work_incomplete: below this % of homework submitted in the last 14 days. */
  HOMEWORK_MIN_PCT: 60,
  /** work_incomplete look-back window for due dates. */
  HOMEWORK_WINDOW_DAYS: 14,
  /** sudden_absence: this many absent days in a row. */
  SUDDEN_ABSENCE_DAYS: 3,
  /** improving: the latest test minus the one before it, in points. */
  IMPROVING_MARKS_POINTS: 10,
  /** improving: attendance at or above this % in the last fortnight, after a dip. */
  IMPROVING_ATTENDANCE_PCT: 90,
  /** improving: the fortnight before must have been below this % (the dip). */
  IMPROVING_PRIOR_PCT: 75,
  /** improving compares two windows of this many days. */
  IMPROVING_WINDOW_DAYS: 14,
  /** Fewer records than this in either improving window is too little to compare. */
  IMPROVING_MIN_RECORDS: 3,
} as const;

/** One attendance record with its session date resolved, newest date first or not — sorted inside. */
export interface ProgressAttendanceRow {
  date: ISODate;
  attended: boolean;
  absent: boolean;
}

/** One published test with the student's percentage. */
export interface ProgressTestRow {
  name: string;
  percentage: number;
  /** Orders the tests, newest last: exam end date, then start, then created. */
  when: string;
}

/** One published homework set of the student's batches. */
export interface ProgressHomeworkRow {
  /** Null when the set has no due date: it cannot be late, so it is skipped. */
  dueAt: string | null;
  submitted: boolean;
}

/** Rows for one student. Everything is already tenant-scoped by the adapter. */
export interface ProgressRuleInput {
  today: ISODate;
  attendance: ProgressAttendanceRow[];
  tests: ProgressTestRow[];
  homework: ProgressHomeworkRow[];
  overdueInstallments: number;
  feeOutstanding: number;
}

export type ProgressFinding = Pick<
  RiskAlert,
  'kind' | 'severity' | 'title' | 'detail' | 'metricValue' | 'threshold'
>;

const round1 = (value: number): number => Math.round(value * 10) / 10;
const whole = (value: number): number => Math.round(value);

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "2026-11-12" → "12 Nov". */
function shortDay(iso: ISODate): string {
  const [y, m, d] = iso.split('-').map(Number);
  const month = MONTHS[(m ?? 1) - 1] ?? '';
  return `${d} ${month}`.trim() || iso;
}

function addDaysISO(iso: ISODate, days: number): ISODate {
  const dt = new Date(`${iso}T00:00:00Z`);
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

function inr(amount: number): string {
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
}

function lowAttendance(input: ProgressRuleInput): ProgressFinding | null {
  const { LOW_ATTENDANCE_PCT, ATTENDANCE_WINDOW_DAYS, ATTENDANCE_MIN_RECORDS } = PROGRESS_RULES;
  const from = addDaysISO(input.today, -ATTENDANCE_WINDOW_DAYS);
  const rows = input.attendance.filter((r) => r.date >= from && r.date <= input.today);
  if (rows.length < ATTENDANCE_MIN_RECORDS) return null;
  const attended = rows.filter((r) => r.attended).length;
  const pct = round1((attended / rows.length) * 100);
  if (pct >= LOW_ATTENDANCE_PCT) return null;
  return {
    kind: 'low_attendance',
    severity: 'high',
    title: `Attendance below ${LOW_ATTENDANCE_PCT}% in the last 30 days`,
    detail: `Attendance ${whole(pct)}% in the last 30 days (${attended} of ${rows.length} classes).`,
    metricValue: pct,
    threshold: LOW_ATTENDANCE_PCT,
  };
}

function orderedTests(input: ProgressRuleInput): ProgressTestRow[] {
  return [...input.tests].sort((a, b) => a.when.localeCompare(b.when));
}

function decliningMarks(input: ProgressRuleInput): ProgressFinding | null {
  const { MARKS_DROP_POINTS, MARKS_TEST_COUNT } = PROGRESS_RULES;
  const tests = orderedTests(input);
  if (tests.length < MARKS_TEST_COUNT) return null;
  const last = tests.slice(-MARKS_TEST_COUNT);
  const oldest = last[0];
  const latest = last[last.length - 1];
  const drop = round1(oldest.percentage - latest.percentage);
  if (drop < MARKS_DROP_POINTS) return null;
  return {
    kind: 'declining_marks',
    severity: 'medium',
    title: `Marks dropped across the last ${MARKS_TEST_COUNT} tests`,
    detail:
      `Marks moved from ${whole(oldest.percentage)}% to ${whole(latest.percentage)}% ` +
      `across the last ${MARKS_TEST_COUNT} tests (${oldest.name} to ${latest.name}).`,
    metricValue: drop,
    threshold: MARKS_DROP_POINTS,
  };
}

function workIncomplete(input: ProgressRuleInput): ProgressFinding | null {
  const { HOMEWORK_MIN_PCT, HOMEWORK_WINDOW_DAYS } = PROGRESS_RULES;
  const from = addDaysISO(input.today, -HOMEWORK_WINDOW_DAYS);
  // Only sets whose due date has passed can be behind; future sets are not counted.
  const due = input.homework.filter((h) => {
    if (!h.dueAt) return false;
    const day = h.dueAt.slice(0, 10);
    return day >= from && day <= input.today;
  });
  if (due.length === 0) return null;
  const submitted = due.filter((h) => h.submitted).length;
  const pct = round1((submitted / due.length) * 100);
  if (pct >= HOMEWORK_MIN_PCT) return null;
  return {
    kind: 'work_incomplete',
    severity: 'medium',
    title: `Homework below ${HOMEWORK_MIN_PCT}% in the last 14 days`,
    detail:
      `Submitted ${submitted} of ${due.length} homework tasks due in the last 14 days ` +
      `(${whole(pct)}%).`,
    metricValue: pct,
    threshold: HOMEWORK_MIN_PCT,
  };
}

function suddenAbsence(input: ProgressRuleInput): ProgressFinding | null {
  const { SUDDEN_ABSENCE_DAYS, ATTENDANCE_WINDOW_DAYS } = PROGRESS_RULES;
  const from = addDaysISO(input.today, -ATTENDANCE_WINDOW_DAYS);
  const absentDays = [...new Set(
    input.attendance.filter((r) => r.absent && r.date >= from && r.date <= input.today).map((r) => r.date),
  )].sort();
  // The most recent run of consecutive calendar days, longest match wins.
  let best: ISODate[] = [];
  let run: ISODate[] = [];
  for (const day of absentDays) {
    const prev = run[run.length - 1];
    run = prev && addDaysISO(prev, 1) === day ? [...run, day] : [day];
    if (run.length >= SUDDEN_ABSENCE_DAYS && run.length > best.length) best = [...run];
  }
  if (best.length < SUDDEN_ABSENCE_DAYS) return null;
  const last = best.slice(-SUDDEN_ABSENCE_DAYS);
  const shorts = last.map(shortDay);
  const sameMonth = shorts.every((s) => s.split(' ')[1] === shorts[shorts.length - 1].split(' ')[1]);
  const days = sameMonth && shorts.length === 3
    ? `${shorts[0].split(' ')[0]}, ${shorts[1].split(' ')[0]} and ${shorts[2]}`
    : shorts.join(', ').replace(/, ([^,]*)$/, ' and $1');
  return {
    kind: 'sudden_absence',
    severity: 'high',
    title: `Absent ${SUDDEN_ABSENCE_DAYS} days in a row`,
    detail: `Absent on ${days} — ${SUDDEN_ABSENCE_DAYS} days in a row.`,
    metricValue: best.length,
    threshold: SUDDEN_ABSENCE_DAYS,
  };
}

function improving(input: ProgressRuleInput): ProgressFinding | null {
  const { IMPROVING_MARKS_POINTS, IMPROVING_ATTENDANCE_PCT, IMPROVING_PRIOR_PCT, IMPROVING_WINDOW_DAYS, IMPROVING_MIN_RECORDS } = PROGRESS_RULES;
  const parts: string[] = [];
  let metricValue = 0;
  let threshold: number = IMPROVING_MARKS_POINTS;
  let title = '';

  const tests = orderedTests(input);
  if (tests.length >= 2) {
    const previous = tests[tests.length - 2];
    const latest = tests[tests.length - 1];
    const gain = round1(latest.percentage - previous.percentage);
    if (gain >= IMPROVING_MARKS_POINTS) {
      parts.push(
        `Marks moved from ${whole(previous.percentage)}% to ${whole(latest.percentage)}% ` +
        `in the latest test (${latest.name}).`,
      );
      metricValue = gain;
      threshold = IMPROVING_MARKS_POINTS;
      title = 'Marks up in the latest test';
    }
  }

  const recentFrom = addDaysISO(input.today, -IMPROVING_WINDOW_DAYS);
  const priorFrom = addDaysISO(input.today, -IMPROVING_WINDOW_DAYS * 2);
  const recent = input.attendance.filter((r) => r.date >= recentFrom && r.date <= input.today);
  const prior = input.attendance.filter((r) => r.date >= priorFrom && r.date < recentFrom);
  if (recent.length >= IMPROVING_MIN_RECORDS && prior.length >= IMPROVING_MIN_RECORDS) {
    const pct = round1((recent.filter((r) => r.attended).length / recent.length) * 100);
    const before = round1((prior.filter((r) => r.attended).length / prior.length) * 100);
    if (pct >= IMPROVING_ATTENDANCE_PCT && before < IMPROVING_PRIOR_PCT) {
      parts.push(`Attendance ${whole(pct)}% in the last 14 days, up from ${whole(before)}% the fortnight before.`);
      if (!title) {
        title = 'Attendance back above 90%';
        metricValue = pct;
        threshold = IMPROVING_ATTENDANCE_PCT;
      }
    }
  }

  if (parts.length === 0) return null;
  return { kind: 'improving', severity: 'low', title, detail: parts.join(' '), metricValue, threshold };
}

function feeOverdue(input: ProgressRuleInput): ProgressFinding | null {
  if (input.overdueInstallments <= 0) return null;
  return {
    kind: 'fee_overdue',
    severity: input.overdueInstallments > 1 ? 'high' : 'medium',
    title: 'Fee overdue',
    detail: `${input.overdueInstallments} instalment${input.overdueInstallments === 1 ? '' : 's'} overdue, ${inr(input.feeOutstanding)} outstanding.`,
    metricValue: input.feeOutstanding,
    threshold: 0,
  };
}

/** Every rule that fires for one student, worst first. Empty when nothing fires. */
export function evaluateProgress(input: ProgressRuleInput): ProgressFinding[] {
  return [lowAttendance(input), suddenAbsence(input), decliningMarks(input), workIncomplete(input), improving(input), feeOverdue(input)]
    .filter((finding): finding is ProgressFinding => finding !== null);
}

const SEVERITY_ORDER: RiskLevel[] = ['none', 'low', 'medium', 'high'];

/** The worst severity across findings. Improving never counts as risk. */
export function worstRisk(findings: Pick<ProgressFinding, 'kind' | 'severity'>[]): RiskLevel {
  return findings
    .filter((f) => f.kind !== 'improving')
    .reduce<RiskLevel>(
      (level, f) => (SEVERITY_ORDER.indexOf(f.severity) > SEVERITY_ORDER.indexOf(level) ? f.severity : level),
      'none',
    );
}

/** Words a child must never be called. Tests scan every alert title and detail against this. */
export const ABILITY_LABELS = /\b(weak|weaker|weakest|poor|poorer|poorest|failing|failed|fail|failure|dull|dumb|stupid|slow learner)\b/i;

export type { ID, RiskKind };
