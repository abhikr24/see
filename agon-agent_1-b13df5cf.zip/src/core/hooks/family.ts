import type { FamilyLeaveType, ID, ISODate } from '../contracts/models';
import { useDomainMutation, useDomainQuery } from './domain';

/** FamilyRepo · a parent's view of one child's payments. */
export function useFamilyPayments(studentId: ID | undefined) {
  return useDomainQuery('family', ['payments', studentId ?? null], (b, i) => b.family.paymentHistory(i, studentId as ID), Boolean(studentId));
}

/** FamilyRepo · one receipt, checked against its payment before it is returned. */
export function useFamilyReceipt(receiptId: ID | undefined) {
  return useDomainQuery('family', ['receipt', receiptId ?? null], (b, i) => b.family.receipt(i, receiptId as ID), Boolean(receiptId));
}

/** FamilyRepo · the teachers who take one child. */
export function useFamilyTeachers(studentId: ID | undefined) {
  return useDomainQuery('family', ['teachers', studentId ?? null], (b, i) => b.family.teachers(i, studentId as ID), Boolean(studentId));
}

/** FamilyRepo · how many classes and days a leave covers, before it is submitted. */
export function useLeavePreview(studentId: ID | undefined, fromDate: ISODate, toDate: ISODate) {
  const ready = Boolean(studentId) && fromDate.length === 10 && toDate.length === 10 && toDate >= fromDate;
  return useDomainQuery('family', ['leave-preview', studentId ?? null, fromDate, toDate], (b, i) => b.family.previewLeave(i, studentId as ID, fromDate, toDate), ready);
}

/** FamilyRepo · a child's leave requests and their status. */
export function useFamilyLeave(studentId: ID | undefined) {
  return useDomainQuery('family', ['leave', studentId ?? null], (b, i) => b.family.leaveRequests(i, studentId as ID), Boolean(studentId));
}

/** FamilyRepo · the leave queue for a teacher (their batches) or the owner (all). */
export function useLeaveQueue(enabled = true) {
  return useDomainQuery('family', ['leave-queue'], (b, i) => b.family.leaveQueue(i), enabled);
}

export function useSubmitFamilyLeave() {
  return useDomainMutation<{ studentId: ID; leaveType: FamilyLeaveType; fromDate: ISODate; toDate: ISODate; reason: string }, unknown>(
    'family',
    (b, i, input) => b.family.submitLeave(i, input),
    { success: 'Leave request sent to the teacher and the office', failure: 'Could not send the leave request' },
  );
}

/** FamilyRepo · a child's meeting requests and the teacher's replies. */
export function useFamilyMeetings(studentId: ID | undefined) {
  return useDomainQuery('family', ['meetings', studentId ?? null], (b, i) => b.family.meetings(i, studentId as ID), Boolean(studentId));
}

export function useRequestFamilyMeeting() {
  return useDomainMutation<{ studentId: ID; teacherId: ID; preferredDate: ISODate; note: string }, unknown>(
    'family',
    (b, i, input) => b.family.requestMeeting(i, input),
    { success: 'Meeting requested. The teacher will reply here', failure: 'Could not request the meeting' },
  );
}
