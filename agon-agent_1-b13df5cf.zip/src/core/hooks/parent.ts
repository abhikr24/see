import { useSession } from './tenant';
import { useDomainMutation, useDomainQuery } from './domain';
import type { ParentSummary } from '../contracts/models/parent';
import type { PaymentIntent } from '../contracts/ports';

export function useParentSummary() {
  const session = useSession();
  const userId = session.data?.user.id;
  return useDomainQuery<ParentSummary>('analytics', ['parent-summary', userId], (b, i) => b.analytics.childSummary(i), Boolean(userId));
}

/**
 * "Pay now". Calls PaymentPort.createIntent(). Until a gateway is configured it fails with a
 * NOT_IMPLEMENTED BackendError, and nothing is shown as paid. No demo receipt is ever issued.
 */
export function usePaymentIntent() {
  return useDomainMutation<{ studentId: string; installmentId: string }, PaymentIntent>(
    ['analytics', 'fees', 'payments', 'receipts'],
    (b, i, input) => b.paymentGateway.createIntent(i, input),
  );
}
