import React from 'react';
import { Pressable, Switch, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { IconBox, Text } from '@/components/ui';
import type { Notice } from '@/core/contracts/models';
import { C, R } from '@/lib/theme';
import { categoryMeta } from '../model';

export interface ToggleRowProps {
  label: string;
  detail: string;
  icon: keyof typeof Ionicons.glyphMap;
  value: boolean;
  onChange: (next: boolean) => void;
  divider?: boolean;
  testID?: string;
}

/** One "Send to" line. The whole row is the switch — 44pt high, one tap. */
export function ToggleRow({ label, detail, icon, value, onChange, divider = true, testID }: ToggleRowProps) {
  return (
    <Pressable
      testID={testID}
      accessibilityRole="switch"
      accessibilityLabel={label}
      accessibilityState={{ checked: value }}
      onPress={() => onChange(!value)}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        minHeight: 60,
        paddingVertical: 8,
        borderBottomWidth: divider ? 1 : 0,
        borderBottomColor: C.hairline,
      }}
    >
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 12,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: value ? C.navySoft : C.track,
        }}
      >
        <Ionicons name={icon} size={18} color={value ? C.primary : C.muted} />
      </View>
      <View style={{ flex: 1, gap: 1 }}>
        <Text variant="body" weight={700}>
          {label}
        </Text>
        <Text variant="caption" c={C.secondary} numberOfLines={2}>
          {detail}
        </Text>
      </View>
      <View pointerEvents="none">
        <Switch
          value={value}
          onValueChange={onChange}
          trackColor={{ false: C.hairline, true: C.primary }}
          thumbColor={C.surface}
          accessibilityElementsHidden
          importantForAccessibility="no-hide-descendants"
        />
      </View>
    </Pressable>
  );
}

/**
 * The amber card shown while Parents is switched on.
 *
 * NOTE (v1): this card is copy only. Publishing writes in-app notifications and
 * nothing else — no adapter sends a WhatsApp message yet. See docs/WORK-DONE.md
 * (P30, Known limits) before shipping this wording to real institutes.
 */
export function WhatsAppSummaryCard() {
  return (
    <View
      testID="whatsapp-summary-card"
      accessibilityRole="text"
      style={{
        flexDirection: 'row',
        gap: 12,
        padding: 14,
        borderRadius: R.card,
        backgroundColor: C.warningSoft,
        borderWidth: 1,
        borderColor: C.warning,
      }}
    >
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 18,
          backgroundColor: C.surface,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name="logo-whatsapp" size={19} color={C.duesInk} />
      </View>
      <View style={{ flex: 1, gap: 3 }}>
        <Text variant="body" weight={700} c={C.duesInk}>
          Parents also get a WhatsApp summary
        </Text>
        <Text variant="caption" c={C.duesInk} style={{ lineHeight: 18 }}>
          A short version of this notice goes to each parent’s registered WhatsApp number. The full notice stays in the app.
        </Text>
      </View>
    </View>
  );
}

/** Shown instead of silence when the institute has switched notice alerts off. */
export function AlertsOffCard() {
  return (
    <View
      testID="notice-alerts-off"
      style={{
        flexDirection: 'row',
        gap: 10,
        padding: 14,
        borderRadius: R.card,
        backgroundColor: C.track,
        borderWidth: 1,
        borderColor: C.hairline,
      }}
    >
      <Ionicons name="notifications-off-outline" size={18} color={C.secondary} />
      <Text variant="caption" c={C.secondary} style={{ flex: 1, lineHeight: 18 }}>
        Notice alerts are switched off for this institute. The notice will be listed for the people you choose, but nobody gets a notification.
      </Text>
    </View>
  );
}

export interface PreviewStripProps {
  title: string;
  body: string;
  category: Notice['category'];
  summary: string;
}

/** Live preview: what recipients will see in their list, updated on every keystroke. */
export function PreviewStrip({ title, body, category, summary }: PreviewStripProps) {
  const meta = categoryMeta(category);
  const hasTitle = title.trim().length > 0;
  const hasBody = body.trim().length > 0;
  return (
    <View testID="notice-preview" style={{ gap: 8 }}>
      <Text variant="label" c={C.secondary}>
        Preview
      </Text>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 12,
          padding: 12,
          borderRadius: R.card,
          backgroundColor: C.surface,
          borderWidth: 1,
          borderColor: C.cardDash,
          borderStyle: 'dashed',
        }}
      >
        <IconBox name={meta.icon} tone={meta.tone} size={40} />
        <View style={{ flex: 1, gap: 2 }}>
          <Text variant="body" weight={700} c={hasTitle ? C.ink : C.muted} numberOfLines={1}>
            {hasTitle ? title.trim() : 'Your title appears here'}
          </Text>
          <Text variant="caption" c={hasBody ? C.secondary : C.muted} numberOfLines={1}>
            {hasBody ? body.trim().replace(/\s+/g, ' ') : 'The first line of your notice'}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 }}>
            <Ionicons name="paper-plane-outline" size={12} color={C.primary} />
            <Text variant="caption" weight={600} c={C.primary} numberOfLines={1} style={{ flex: 1, fontSize: 12 }}>
              {summary}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}
