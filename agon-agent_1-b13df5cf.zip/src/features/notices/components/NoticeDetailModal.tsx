import React from 'react';
import { Modal, Pressable, ScrollView, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Badge, Button, IconBox, Text } from '@/components/ui';
import type { Notice } from '@/core/contracts/models';
import { C, R, S } from '@/lib/theme';
import { audienceSummary, categoryMeta, noticeDateLabel } from '../model';

export interface NoticeDetailModalProps {
  notice: Notice | null;
  /** Name of the batch the notice is bound to, when the reader can see batches. */
  batchName?: string | null;
  /** Staff see who a notice went to. */
  showAudience?: boolean;
  onClose: () => void;
}

/** "Read more": the whole notice, presented as a sheet on phones and a dialog on wide screens. */
export function NoticeDetailModal({ notice, batchName, showAudience, onClose }: NoticeDetailModalProps) {
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const wide = width >= 720;
  if (!notice) return null;
  const meta = categoryMeta(notice.category);

  return (
    <Modal visible transparent animationType={wide ? 'fade' : 'slide'} onRequestClose={onClose} statusBarTranslucent>
      <Pressable
        accessibilityLabel="Close notice"
        onPress={onClose}
        style={{
          flex: 1,
          backgroundColor: C.scrim,
          justifyContent: wide ? 'center' : 'flex-end',
          alignItems: wide ? 'center' : 'stretch',
          padding: wide ? 24 : 0,
        }}
      >
        <Pressable
          onPress={(event) => event.stopPropagation()}
          accessibilityViewIsModal
          style={{
            backgroundColor: C.surface,
            borderTopLeftRadius: R.sheet,
            borderTopRightRadius: R.sheet,
            borderBottomLeftRadius: wide ? R.sheet : 0,
            borderBottomRightRadius: wide ? R.sheet : 0,
            maxHeight: height * 0.86,
            width: wide ? 560 : undefined,
            paddingTop: 10,
            paddingBottom: (wide ? 0 : insets.bottom) + 16,
          }}
        >
          {wide ? null : (
            <View style={{ alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: C.hairline, marginBottom: 8 }} />
          )}

          <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12, paddingHorizontal: 20, paddingTop: 8 }}>
            <IconBox name={meta.icon} tone={meta.tone} size={44} />
            <View style={{ flex: 1, gap: 6 }}>
              <Text variant="h2" style={{ fontSize: 20, lineHeight: 26 }}>
                {notice.title}
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <Badge label={meta.label} tone={meta.tone} small />
                <Text variant="caption" c={C.muted} tabular>
                  {noticeDateLabel(notice.publishedAt)}
                </Text>
              </View>
            </View>
            <Pressable accessibilityRole="button" accessibilityLabel="Close" onPress={onClose} hitSlop={12}>
              <Ionicons name="close" size={22} color={C.muted} />
            </Pressable>
          </View>

          <ScrollView
            style={{ marginTop: S.lg }}
            contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 8, gap: S.md }}
            showsVerticalScrollIndicator={false}
          >
            {notice.category === 'event' && notice.eventOn ? (
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 10,
                  padding: 12,
                  borderRadius: R.field,
                  backgroundColor: C.accentSoft,
                }}
              >
                <Ionicons name="calendar-outline" size={18} color={C.accent} />
                <Text variant="caption" weight={700} c={C.ink}>
                  {`Event day · ${noticeDateLabel(notice.eventOn)}`}
                </Text>
              </View>
            ) : null}

            <Text variant="body" c={C.ink} style={{ lineHeight: 23 }} selectable>
              {notice.body}
            </Text>

            {showAudience ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingTop: 4 }}>
                <Ionicons name="people-outline" size={16} color={C.muted} />
                <Text variant="caption" c={C.secondary} style={{ flex: 1 }}>
                  {`Sent to ${audienceSummary(notice.audience, { allBatches: notice.batchId === null, batchName: batchName ?? 'One batch' })}`}
                </Text>
              </View>
            ) : null}
          </ScrollView>

          <View style={{ paddingHorizontal: 20, paddingTop: 12 }}>
            <Button title="Done" variant="outline" size="md" onPress={onClose} />
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
