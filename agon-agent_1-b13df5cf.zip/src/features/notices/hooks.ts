import { useCallback, useMemo, useState } from 'react';
import { router } from 'expo-router';

import { useBatches, useInstitute, useNotices, usePublishNotice, useRealtime } from '@/core/backend';
import type { Notice, NoticeAudienceRole, PublishNoticeInput } from '@/core/contracts/models';
import {
  NOTICE_BODY_MAX,
  NOTICE_TITLE_MAX,
  getNoticeValidationErrors,
  noticeAlertsOn,
  type NoticeValidationErrors,
} from '@/core/contracts/notices';
import { useSessionStore } from '@/store/session';
import {
  audienceSummary,
  canComposeNotice,
  canDeleteNotice,
  filterNotices,
  noticeRoutes,
  sortNotices,
  type NoticeSegment,
} from './model';

const LIST_QUERY = { limit: 100 } as const;

/** The notices list for whoever is signed in. What they may read is decided by NoticeRepo, not here. */
export function useNoticeBoard() {
  const { role } = useSessionStore();
  const notices = useNotices(LIST_QUERY);
  // A notice published (or deleted) elsewhere shows up without a pull-to-refresh.
  useRealtime('notices');
  const [segment, setSegment] = useState<NoticeSegment>('all');

  const all = useMemo(() => sortNotices(notices.data?.items ?? []), [notices.data?.items]);
  const visible = useMemo(() => filterNotices(all, segment), [all, segment]);

  return {
    role,
    routes: noticeRoutes(role),
    canCompose: canComposeNotice(role),
    canDelete: canDeleteNotice(role),
    segment,
    setSegment,
    all,
    visible,
    loading: notices.loading && !notices.data,
    refreshing: notices.loading && Boolean(notices.data),
    error: notices.error && !notices.data ? notices.error : null,
    refetch: notices.refetch,
    remove: notices.remove,
  };
}

export type ComposerErrors = NoticeValidationErrors;

/** The composer form: fields, the four "Send to" toggles, validation and Publish. */
export function useNoticeComposer(initialBatchId?: string) {
  const { role } = useSessionStore();
  const isTeacher = role === 'teacher';
  const routes = noticeRoutes(role);
  const institute = useInstitute();
  const batchList = useBatches();
  const publish = usePublishNotice();

  const batches = useMemo(
    () => (batchList.data?.items ?? []).filter((batch) => batch.status === 'active' || batch.status === 'upcoming'),
    [batchList.data?.items],
  );

  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [students, setStudents] = useState(true);
  const [parents, setParents] = useState(true);
  const [teachers, setTeachers] = useState(false);
  const [allBatches, setAllBatches] = useState(!initialBatchId);
  const [batchId, setBatchId] = useState<string | null>(initialBatchId ?? null);
  const [category, setCategory] = useState<Notice['category']>('general');
  const [eventOn, setEventOn] = useState<string | null>(null);
  const [attempted, setAttempted] = useState(false);

  const audience = useMemo<NoticeAudienceRole[]>(() => {
    const roles: NoticeAudienceRole[] = [];
    if (students) roles.push('student');
    if (parents) roles.push('parent');
    // A teacher's notice goes to their own classes; the Teachers toggle is the institute's to use.
    if (teachers && !isTeacher) roles.push('teacher');
    return roles;
  }, [students, parents, teachers, isTeacher]);

  const selectedBatch = useMemo(
    () => (allBatches ? null : (batches.find((batch) => batch.id === batchId) ?? null)),
    [allBatches, batches, batchId],
  );

  const input = useMemo<PublishNoticeInput>(
    () => ({
      title,
      body,
      audience,
      batchId: allBatches ? null : (selectedBatch?.id ?? null),
      category,
      eventOn: category === 'event' ? eventOn : null,
    }),
    [title, body, audience, allBatches, selectedBatch, category, eventOn],
  );

  const errors = useMemo<ComposerErrors>(() => {
    const found: ComposerErrors = getNoticeValidationErrors(input);
    if (!allBatches && !selectedBatch) found.batchId = 'Choose a batch, or switch All batches back on';
    return found;
  }, [input, allBatches, selectedBatch]);

  const valid = Object.keys(errors).length === 0;
  const alertsOn = noticeAlertsOn(institute.data?.settings.features);

  const submit = useCallback(async () => {
    setAttempted(true);
    if (!valid) return;
    const result = await publish.mutate({ ...input, title: input.title.trim(), body: input.body.trim() });
    if (result.ok) router.replace(routes.list as never);
  }, [valid, publish, input, routes.list]);

  return {
    role,
    isTeacher,
    routes,
    allowed: canComposeNotice(role),
    batches,
    batchesLoading: batchList.loading && !batchList.data,
    title,
    setTitle: (value: string) => setTitle(value.slice(0, NOTICE_TITLE_MAX)),
    body,
    setBody: (value: string) => setBody(value.slice(0, NOTICE_BODY_MAX)),
    students,
    setStudents,
    parents,
    setParents,
    teachers,
    setTeachers,
    allBatches,
    setAllBatches,
    batchId: selectedBatch?.id ?? null,
    setBatchId,
    category,
    setCategory,
    eventOn,
    setEventOn,
    audience,
    summary: audienceSummary(audience, {
      allBatches,
      batchName: selectedBatch?.name ?? null,
      ownBatchesOnly: isTeacher,
    }),
    /** Shown only once Publish has been tried, so an empty form is not a wall of red. */
    errors: attempted ? errors : ({} as ComposerErrors),
    valid,
    alertsOn,
    saving: publish.loading,
    submit,
  };
}

export type NoticeComposer = ReturnType<typeof useNoticeComposer>;
