/**
 * Notices — pure view rules. No React, no backend: everything here is checked
 * by tests/notices.acceptance.ts.
 */
import type { Ionicons } from '@expo/vector-icons';

import type { ID, Notice, NoticeAudienceRole, Role } from '@/core/contracts/models';
import type { Tone } from '@/lib/theme';

export type NoticeSegment = 'all' | 'academic' | 'events';

export const NOTICE_SEGMENTS: readonly { key: NoticeSegment; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'academic', label: 'Academic' },
  { key: 'events', label: 'Events' },
];

type IconName = keyof typeof Ionicons.glyphMap;

export interface CategoryMeta {
  label: string;
  icon: IconName;
  tone: Tone;
  /** Which segment, besides All, lists this category. */
  segment: Exclude<NoticeSegment, 'all'> | null;
}

export const CATEGORY_META: Record<Notice['category'], CategoryMeta> = {
  general: { label: 'General', icon: 'megaphone-outline', tone: 'primary', segment: null },
  academic: { label: 'Academic', icon: 'school-outline', tone: 'primary', segment: 'academic' },
  exam: { label: 'Exam', icon: 'document-text-outline', tone: 'teal', segment: 'academic' },
  fee: { label: 'Fees', icon: 'wallet-outline', tone: 'success', segment: null },
  holiday: { label: 'Holiday', icon: 'sunny-outline', tone: 'warning', segment: 'events' },
  event: { label: 'Event', icon: 'calendar-outline', tone: 'accent', segment: 'events' },
  urgent: { label: 'Urgent', icon: 'alert-circle-outline', tone: 'danger', segment: null },
};

export function categoryMeta(category: Notice['category'] | string | null | undefined): CategoryMeta {
  return CATEGORY_META[category as Notice['category']] ?? CATEGORY_META.general;
}

/** The categories the composer offers. Each one lands in a segment of the list (General → All only). */
export const COMPOSER_CATEGORIES: readonly { key: Notice['category']; label: string }[] = [
  { key: 'general', label: 'General' },
  { key: 'academic', label: 'Academic' },
  { key: 'event', label: 'Event' },
];

export function filterNotices(notices: readonly Notice[], segment: NoticeSegment): Notice[] {
  if (segment === 'all') return [...notices];
  return notices.filter((notice) => categoryMeta(notice.category).segment === segment);
}

/** Newest first. A draft (staff only) has no publish time and sorts by when it was written. */
export function sortNotices(notices: readonly Notice[]): Notice[] {
  const at = (notice: Notice) => notice.publishedAt ?? notice.createdAt;
  return [...notices].sort((a, b) => (at(a) < at(b) ? 1 : at(a) > at(b) ? -1 : 0));
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** `12 Nov 2026` from an ISO date or instant, read as a calendar day in UTC so it never shifts by a zone. */
export function noticeDateLabel(iso: string | null | undefined): string {
  if (!iso) return 'Draft';
  const parsed = new Date(iso.length === 10 ? `${iso}T00:00:00Z` : iso);
  if (Number.isNaN(parsed.getTime())) return '—';
  return `${parsed.getUTCDate()} ${MONTHS[parsed.getUTCMonth()]} ${parsed.getUTCFullYear()}`;
}

export interface EventChip {
  day: string;
  month: string;
}

/** The date chip on an event card. Only an event with a day gets one — a publish date is never dressed up as it. */
export function eventChip(notice: Pick<Notice, 'category' | 'eventOn'>): EventChip | null {
  if (notice.category !== 'event' || !notice.eventOn) return null;
  const parsed = new Date(`${notice.eventOn.slice(0, 10)}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return null;
  return { day: String(parsed.getUTCDate()), month: MONTHS[parsed.getUTCMonth()].toUpperCase() };
}

const ROLE_LABEL: Record<NoticeAudienceRole, string> = {
  student: 'Students',
  parent: 'Parents',
  teacher: 'Teachers',
};

export const audienceRoleLabel = (role: NoticeAudienceRole): string => ROLE_LABEL[role];

/** `Students · Parents · All batches` — the line under the preview and in the detail sheet. */
export function audienceSummary(
  audience: readonly string[],
  scope: { allBatches: boolean; batchName?: string | null; ownBatchesOnly?: boolean },
): string {
  const roles = (['student', 'parent', 'teacher'] as const).filter((role) => audience.includes(role)).map(audienceRoleLabel);
  const who = roles.length > 0 ? roles.join(' · ') : 'Nobody yet';
  const where = scope.allBatches
    ? scope.ownBatchesOnly
      ? 'All my batches'
      : 'All batches'
    : (scope.batchName ?? 'Choose a batch');
  return `${who} · ${where}`;
}

export const canComposeNotice = (role: Role | null): boolean => role === 'owner' || role === 'admin' || role === 'teacher';
export const canDeleteNotice = (role: Role | null): boolean => role === 'owner' || role === 'admin';

export interface NoticeRoutes {
  list: string;
  /** null = this role cannot compose. */
  compose: string | null;
  more: string;
}

/** Where each role's notices live. Routes are thin files; the screens are shared. */
export function noticeRoutes(role: Role | null): NoticeRoutes {
  if (role === 'teacher') return { list: '/(teacher)/notices', compose: '/(teacher)/notices/new', more: '/(teacher)/more' };
  if (role === 'student') return { list: '/(student)/notices', compose: null, more: '/(student)/more' };
  if (role === 'parent') return { list: '/(parent)/notices', compose: null, more: '/(parent)/more' };
  return { list: '/(owner)/notices', compose: '/(owner)/notices/new', more: '/(owner)/more' };
}

/** Counter under the body field. */
export function bodyCounter(length: number, max: number): { label: string; tone: 'muted' | 'warning' | 'danger' } {
  const tone = length >= max ? 'danger' : length >= max * 0.9 ? 'warning' : 'muted';
  return { label: `${length}/${max}`, tone };
}

export type { ID };
