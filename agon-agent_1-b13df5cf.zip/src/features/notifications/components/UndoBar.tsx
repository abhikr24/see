import React from 'react';
import { Pressable, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import { C, R, SHADOW } from '@/lib/theme';

export interface UndoBarProps {
  visible: boolean;
  message: string;
  onUndo: () => void;
}

/** The bar that follows a swipe: says what happened and offers one way back. */
export function UndoBar({ visible, message, onUndo }: UndoBarProps) {
  const insets = useSafeAreaInsets();
  if (!visible) return null;
  return (
    <View
      pointerEvents="box-none"
      style={{ position: 'absolute', left: 16, right: 16, bottom: insets.bottom + 16, alignItems: 'center' }}
    >
      <View
        testID="undo-bar"
        accessibilityRole="alert"
        accessibilityLiveRegion="polite"
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 12,
          width: '100%',
          maxWidth: 480,
          minHeight: 52,
          paddingLeft: 18,
          paddingRight: 6,
          borderRadius: R.btn,
          backgroundColor: C.ink,
          ...SHADOW,
        }}
      >
        <Text variant="caption" weight={600} c={C.surface} style={{ flex: 1 }} numberOfLines={1}>
          {message}
        </Text>
        <Pressable
          testID="undo-dismiss"
          accessibilityRole="button"
          accessibilityLabel="Undo dismiss"
          onPress={onUndo}
          hitSlop={6}
          style={({ pressed }) => ({
            minHeight: 44,
            paddingHorizontal: 14,
            justifyContent: 'center',
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Text variant="caption" weight={800} c={C.accent}>
            UNDO
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
