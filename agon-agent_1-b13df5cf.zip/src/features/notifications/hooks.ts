import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { useNotifications, useRealtime } from '@/core/backend';
import type { ID } from '@/core/contracts/models';
import { INBOX_SEGMENTS, UNDO_WINDOW_MS, filterInbox, unreadIn, type InboxSegment } from './model';

const INBOX_QUERY = { limit: 100 } as const;

/**
 * Swipe → hidden at once → removed for good after the undo window. Undo simply
 * cancels the timer, so nothing has to be written back. A second swipe, or
 * leaving the screen, commits the one that was waiting.
 */
export function useDismissWithUndo(commit: (id: ID) => unknown, windowMs: number = UNDO_WINDOW_MS) {
  const [pendingId, setPendingId] = useState<ID | null>(null);
  const waiting = useRef<ID | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const commitRef = useRef(commit);
  useEffect(() => {
    commitRef.current = commit;
  });

  const stopTimer = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  }, []);

  const flush = useCallback(() => {
    stopTimer();
    const id = waiting.current;
    waiting.current = null;
    setPendingId(null);
    if (id) void commitRef.current(id);
  }, [stopTimer]);

  const dismiss = useCallback(
    (id: ID) => {
      flush();
      waiting.current = id;
      setPendingId(id);
      timer.current = setTimeout(flush, windowMs);
    },
    [flush, windowMs],
  );

  const undo = useCallback(() => {
    stopTimer();
    waiting.current = null;
    setPendingId(null);
  }, [stopTimer]);

  // Leaving the screen is not an undo.
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
      const id = waiting.current;
      waiting.current = null;
      if (id) void commitRef.current(id);
    },
    [],
  );

  return { pendingId, dismiss, undo };
}

/** The signed-in person's inbox: segments, read state, swipe-to-dismiss with undo. */
export function useNotificationCentre() {
  const inbox = useNotifications(INBOX_QUERY);
  // New notifications arrive, and reads made elsewhere land, without a refresh.
  useRealtime('notifications');
  const [segment, setSegment] = useState<InboxSegment>('all');
  const { pendingId, dismiss, undo } = useDismissWithUndo((id) => inbox.dismiss(id));

  const items = useMemo(() => inbox.data?.items ?? [], [inbox.data?.items]);
  const hiddenId = pendingId;
  const visible = useMemo(() => filterInbox(items, segment, hiddenId), [items, segment, hiddenId]);
  const unread = useMemo(() => unreadIn(items, hiddenId), [items, hiddenId]);

  const segments = useMemo(
    () => INBOX_SEGMENTS.map((entry) => (entry.key === 'unread' && unread > 0 ? { ...entry, count: unread } : entry)),
    [unread],
  );

  return {
    segment,
    setSegment,
    segments,
    visible,
    unread,
    loading: inbox.loading && !inbox.data,
    refreshing: inbox.loading && Boolean(inbox.data),
    error: inbox.error && !inbox.data ? inbox.error : null,
    refetch: inbox.refetch,
    markRead: inbox.markRead,
    markAllRead: inbox.markAllRead,
    markingAll: inbox.markingAll,
    pendingDismissId: pendingId,
    dismiss,
    undo,
  };
}
