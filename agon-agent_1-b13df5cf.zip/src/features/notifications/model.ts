/**
 * Notification centre — pure view rules. Checked by tests/notices.acceptance.ts.
 */
import type { Ionicons } from '@expo/vector-icons';

import type { AppNotification, ID } from '@/core/contracts/models';
import type { Tone } from '@/lib/theme';

/** The six kinds the centre draws, plus a neutral one for anything it does not recognise. */
export type NotificationKind = 'announcement' | 'homework' | 'fee' | 'exam' | 'leave' | 'attendance' | 'general';

type IconName = keyof typeof Ionicons.glyphMap;

export const KIND_META: Record<NotificationKind, { label: string; icon: IconName; tone: Tone }> = {
  announcement: { label: 'Announcement', icon: 'megaphone-outline', tone: 'primary' },
  homework: { label: 'Homework', icon: 'book-outline', tone: 'accent' },
  fee: { label: 'Fees', icon: 'wallet-outline', tone: 'success' },
  exam: { label: 'Exam', icon: 'document-text-outline', tone: 'teal' },
  leave: { label: 'Leave', icon: 'bed-outline', tone: 'warning' },
  attendance: { label: 'Attendance', icon: 'calendar-number-outline', tone: 'danger' },
  general: { label: 'Update', icon: 'notifications-outline', tone: 'neutral' },
};

const PREFIXES: [NotificationKind, readonly string[]][] = [
  ['announcement', ['notice', 'announcement']],
  ['homework', ['homework', 'assignment']],
  ['fee', ['fee', 'payment', 'receipt']],
  ['exam', ['exam', 'result', 'marks']],
  ['leave', ['leave']],
  ['attendance', ['attendance']],
];

/**
 * Maps the backend's free-form `type` (`notice_published`, `homework_assigned`,
 * `attendance_absent`, …) to a kind. Unknown types stay `general` rather than
 * being passed off as an announcement.
 */
export function kindOf(notification: Pick<AppNotification, 'type' | 'data'>): NotificationKind {
  const type = (notification.type ?? '').toLowerCase();
  for (const [kind, prefixes] of PREFIXES) {
    if (prefixes.some((prefix) => type === prefix || type.startsWith(`${prefix}_`))) return kind;
  }
  return notification.data?.screen === 'notice' ? 'announcement' : 'general';
}

export type InboxSegment = 'all' | 'unread' | 'announcements';

export const INBOX_SEGMENTS: readonly { key: InboxSegment; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'unread', label: 'Unread' },
  { key: 'announcements', label: 'Announcements' },
];

/** Newest first, minus anything swiped away and waiting on Undo. */
export function filterInbox(
  items: readonly AppNotification[],
  segment: InboxSegment,
  hiddenId: ID | null = null,
): AppNotification[] {
  return items
    .filter((item) => item.id !== hiddenId)
    .filter((item) => {
      if (segment === 'unread') return item.readAt === null;
      if (segment === 'announcements') return kindOf(item) === 'announcement';
      return true;
    })
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0));
}

export function unreadIn(items: readonly AppNotification[], hiddenId: ID | null = null): number {
  return items.filter((item) => item.readAt === null && item.id !== hiddenId).length;
}

/** The notice a notification points at, if it is an announcement. */
export function noticeIdOf(notification: Pick<AppNotification, 'data'>): ID | null {
  const id = notification.data?.noticeId;
  return typeof id === 'string' && id.length > 0 ? id : null;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** `Just now`, `12 min ago`, `3 h ago`, `Yesterday`, `4 days ago`, then `12 Nov`. */
export function relativeTime(iso: string | null | undefined, now: number = Date.now()): string {
  if (!iso) return '';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '';
  const minutes = Math.floor(Math.max(0, now - then) / 60000);
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days} days ago`;
  const date = new Date(then);
  return `${date.getDate()} ${MONTHS[date.getMonth()]}`;
}

/** How long a swiped notification waits before it is really removed. */
export const UNDO_WINDOW_MS = 5000;
