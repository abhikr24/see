import React, { useCallback } from 'react';
import { FlatList, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Card, EmptyState, ErrorState, ListSkeleton, SegmentedControl, Text } from '@/components/ui';
import type { AppNotification } from '@/core/contracts/models';
import { noticeRoutes } from '@/features/notices/model';
import { ShellLoading } from '@/features/shell/ShellLoading';
import { C, LAYOUT, S } from '@/lib/theme';
import { useSessionStore, destinationFor } from '@/store/session';
import { NotificationCard } from '../components/NotificationCard';
import { UndoBar } from '../components/UndoBar';
import { useNotificationCentre } from '../hooks';
import { noticeIdOf, type InboxSegment } from '../model';

const EMPTY_COPY: Record<InboxSegment, { title: string; text: string }> = {
  all: { title: 'You’re all caught up', text: 'Announcements, homework, fees and attendance updates will land here.' },
  unread: { title: 'Nothing unread', text: 'Everything here has been opened.' },
  announcements: { title: 'No announcements', text: 'Notices from your institute will show up here.' },
};

function Inbox({ moreRoute, noticesRoute }: { moreRoute: string; noticesRoute: string }) {
  const centre = useNotificationCentre();

  const goBack = () => {
    if (router.canGoBack()) router.back();
    else router.replace(moreRoute as never);
  };

  const open = useCallback(
    (notification: AppNotification) => {
      if (notification.readAt === null) void centre.markRead(notification.id);
      const noticeId = noticeIdOf(notification);
      if (noticeId) router.replace({ pathname: noticesRoute, params: { open: noticeId } } as never);
    },
    [centre, noticesRoute],
  );

  const empty = centre.loading ? (
    <ListSkeleton rows={5} h={84} />
  ) : centre.error ? (
    <Card flat>
      <ErrorState message={centre.error.message} onRetry={() => void centre.refetch()} />
    </Card>
  ) : (
    <Card flat>
      <EmptyState
        icon="notifications-outline"
        title={EMPTY_COPY[centre.segment].title}
        text={EMPTY_COPY[centre.segment].text}
      />
    </Card>
  );

  const canMarkAll = centre.unread > 0 && !centre.markingAll;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 10, gap: S.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 32 }}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Back"
            onPress={goBack}
            hitSlop={8}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
          >
            <Ionicons name="chevron-back" size={20} color={C.primary} />
            <Text variant="caption" weight={700} c={C.primary}>
              More
            </Text>
          </Pressable>
          <Pressable
            testID="mark-all-read"
            accessibilityRole="button"
            accessibilityLabel="Mark all read"
            accessibilityState={{ disabled: !canMarkAll }}
            disabled={!canMarkAll}
            onPress={() => void centre.markAllRead()}
            hitSlop={8}
            style={({ pressed }) => ({
              flexDirection: 'row',
              alignItems: 'center',
              gap: 5,
              minHeight: 32,
              opacity: !canMarkAll ? 0.4 : pressed ? 0.7 : 1,
            })}
          >
            <Ionicons name="checkmark-done-outline" size={17} color={C.primary} />
            <Text variant="caption" weight={700} c={C.primary}>
              Mark all read
            </Text>
          </Pressable>
        </View>

        <View style={{ gap: 2 }}>
          <Text variant="h2">Notifications</Text>
          <Text testID="inbox-unread-line" variant="caption" c={C.secondary} tabular>
            {centre.loading
              ? 'Loading…'
              : centre.unread > 0
                ? `${centre.unread} unread · swipe a card to dismiss it`
                : 'All read · swipe a card to dismiss it'}
          </Text>
        </View>

        <SegmentedControl options={centre.segments} value={centre.segment} onChange={centre.setSegment} />
      </View>

      <FlatList
        data={centre.loading || centre.error ? [] : centre.visible}
        keyExtractor={(notification) => notification.id}
        renderItem={({ item }) => <NotificationCard notification={item} onPress={open} onDismiss={centre.dismiss} />}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={empty}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: S.lg, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={centre.refreshing} onRefresh={() => void centre.refetch()} tintColor={C.primary} />
        }
      />

      <UndoBar visible={centre.pendingDismissId !== null} message="Notification dismissed" onUndo={centre.undo} />
    </SafeAreaView>
  );
}

/**
 * The notification centre, shared by every role (`/shared/notifications`). It
 * sits outside the role groups, so it carries the session guard itself: only a
 * signed-in person with an active membership gets an inbox.
 */
export function NotificationCentreScreen() {
  const { status, group, role } = useSessionStore();
  if (status === 'loading') return <ShellLoading />;
  if (status !== 'ready') return <Redirect href={destinationFor(status, group) as never} />;
  const routes = noticeRoutes(role);
  return <Inbox moreRoute={routes.more} noticesRoute={routes.list} />;
}
