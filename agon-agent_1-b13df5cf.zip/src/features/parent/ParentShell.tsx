import React from 'react';

import { RoleTabShell } from '@/features/shell/RoleTabShell';

/**
 * The parent group used to ship its own app shell: a SafeAreaView header
 * with a four-item nav (Overview, Attendance, Fees & payments, Notices).
 * That was a second shell, which is why the parent screens looked like a
 * different app from every other screen.
 *
 * There is exactly one shell now. RoleTabShell renders the shared header and
 * the floating pill tab bar, and the tab list comes from `src/lib/nav.ts` —
 * never from a feature folder. The parent module keeps its own content only.
 */
export function ParentShell() {
  return <RoleTabShell role="parent" />;
}
