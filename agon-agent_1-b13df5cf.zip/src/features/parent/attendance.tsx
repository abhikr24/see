import React, { useMemo } from 'react';
import { FlatList, Linking, RefreshControl, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import {
  Button,
  Card,
  EmptyState,
  ErrorState,
  ListSkeleton,
  Text,
} from '@/components/ui';
import { toast, useInstitute, useMyBatches, useStaff, useSubjects, useTeachers } from '@/core/backend';
import { useDomainQuery } from '@/core/hooks/domain';
import type { AttendanceRecord, AttendanceSession, AttendanceStatus, ID } from '@/core/contracts/models';
import { dateShort } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { ChildStrip } from './child-strip';
import { useParent } from './context';

const TAB_INSET = 136;
const SQUARE = 28;
const WEEKDAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'] as const;
const SEVERITY: Record<AttendanceStatus, number> = { absent: 4, late: 3, leave: 2, present: 1 };

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function DaysRing({ attended, total }: { attended: number; total: number }) {
  const size = 140;
  const stroke = 10;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const share = total ? Math.max(0, Math.min(1, attended / total)) : 0;
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={C.track} strokeWidth={stroke} fill="none" />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={C.teal}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={`${circ}`}
          strokeDashoffset={circ - circ * share}
          strokeLinecap="round"
        />
      </Svg>
      <Text weight={800} tabular style={{ fontSize: 18, lineHeight: 22 }}>
        {attended} of {total}
      </Text>
      <Text variant="label" c={C.muted} style={{ marginTop: 2 }}>
        days
      </Text>
    </View>
  );
}

function StatDot({ color, label, value }: { color: string; label: string; value: number }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 36 }}>
      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color }} />
      <Text variant="caption" c={C.secondary} style={{ flex: 1 }}>
        {label}
      </Text>
      <Text weight={800} tabular style={{ fontSize: 18 }}>
        {value}
      </Text>
    </View>
  );
}

function MonthHeatmap({ byDate }: { byDate: Map<string, AttendanceStatus> }) {
  const today = todayIso();
  const month = today.slice(0, 7);
  const year = Number(month.slice(0, 4));
  const monthIndex = Number(month.slice(5, 7)) - 1;
  const daysInMonth = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
  const firstWeekday = new Date(`${month}-01T12:00:00Z`).getUTCDay();
  const startOffset = (firstWeekday + 6) % 7;
  const cells: ({ date: string; day: number } | null)[] = [
    ...Array.from({ length: startOffset }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => {
      const day = i + 1;
      const date = `${month}-${String(day).padStart(2, '0')}`;
      return { date, day };
    }),
  ];
  while (cells.length % 7 !== 0) cells.push(null);
  const weeks = Array.from({ length: cells.length / 7 }, (_, w) => cells.slice(w * 7, w * 7 + 7));
  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', gap: 6 }}>
        {WEEKDAYS.map((label, i) => (
          <View key={`${label}-${i}`} style={{ flex: 1, alignItems: 'center' }}>
            <Text variant="label" c={C.muted}>{label}</Text>
          </View>
        ))}
      </View>
      {weeks.map((week, w) => (
        <View key={w} style={{ flexDirection: 'row', gap: 6 }}>
          {week.map((cell, c) => {
            if (!cell) return <View key={`gap-${w}-${c}`} style={{ flex: 1, height: 36 }} />;
            const status = byDate.get(cell.date);
            const isToday = cell.date === today;
            const future = cell.date > today;
            const fill = future ? C.track : status === 'present' ? C.teal : status === 'late' ? C.warning : status === 'absent' ? C.danger : C.transparent;
            const outline = isToday ? C.primary : !status && !future ? C.hairline : C.transparent;
            const ink = status === 'present' || status === 'absent' ? C.surface : C.ink;
            return (
              <View key={cell.date} style={{ flex: 1, height: 36, alignItems: 'center', justifyContent: 'center' }}>
                <View
                  style={{
                    width: SQUARE,
                    height: SQUARE,
                    borderRadius: R.cell,
                    backgroundColor: fill,
                    borderWidth: isToday ? 2 : outline === C.hairline ? 1 : 0,
                    borderColor: outline,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Text weight={700} c={ink} tabular style={{ fontSize: 11 }}>{cell.day}</Text>
                </View>
              </View>
            );
          })}
        </View>
      ))}
    </View>
  );
}

function lateLabel(remark: string | null) {
  if (remark && /\d/.test(remark)) return remark;
  return 'Late';
}

export function ParentAttendanceScreen() {
  const p = useParent();
  const studentId = p.child?.id ?? null;
  const summary = useDomainQuery(
    'attendance',
    ['summary', studentId],
    (b, i) => b.attendance.summary(i, { studentId: studentId as ID }),
    Boolean(studentId),
  );
  const records = useDomainQuery<AttendanceRecord[]>(
    'attendance',
    ['records', studentId],
    (b, i) => b.attendance.listRecords(i, { studentId: studentId as ID }),
    Boolean(studentId),
  );
  const sessions = useDomainQuery(
    'attendance',
    ['sessions-page', studentId],
    (b, i) => b.attendance.listSessions(i, { limit: 200, sort: { field: 'date', direction: 'desc' } }),
    Boolean(studentId),
  );
  const subjects = useSubjects({ limit: 100 });
  const batches = useMyBatches();
  const teachers = useTeachers({ limit: 50 });
  const staff = useStaff({ limit: 50 });
  const institute = useInstitute();

  const dated = useMemo(() => {
    const sessionById = new Map((sessions.data?.items ?? []).map((session: AttendanceSession) => [session.id, session]));
    return (records.data ?? [])
      .map((record) => {
        const session = sessionById.get(record.sessionId);
        return session ? { record, session } : null;
      })
      .filter((row): row is { record: AttendanceRecord; session: AttendanceSession } => row !== null);
  }, [records.data, sessions.data]);

  const byDate = useMemo(() => {
    const map = new Map<string, AttendanceStatus>();
    for (const { record, session } of dated) {
      const current = map.get(session.date);
      if (!current || SEVERITY[record.status] > SEVERITY[current]) map.set(session.date, record.status);
    }
    return map;
  }, [dated]);

  const absences = useMemo(() => {
    const subjectName = new Map((subjects.data?.items ?? []).map((subject) => [subject.id, subject.name]));
    return dated
      .filter(({ record }) => record.status === 'absent' || record.status === 'late')
      .sort((a, b) => b.session.date.localeCompare(a.session.date) || b.session.period - a.session.period)
      .slice(0, 2)
      .map(({ record, session }) => ({
        id: record.id,
        date: session.date,
        subject: (session.subjectId && subjectName.get(session.subjectId)) || 'Class',
        status: record.status,
        pill: record.status === 'absent' ? 'Absent' : lateLabel(record.remark),
      }));
  }, [dated, subjects.data]);

  const counts = summary.data;
  const attended = counts ? counts.present + counts.late : 0;
  const total = counts?.total ?? 0;
  const loading = (summary.loading || records.loading) && !summary.data;
  const error = summary.error ?? records.error;

  const messageTeacher = async () => {
    const batch = batches.data?.find((item) => p.child?.classLabel.includes(item.name)) ?? batches.data?.[0];
    const teacher = (teachers.data?.items ?? []).find((item) => item.id === batch?.teacherId);
    const staffRow = (staff.data?.items ?? []).find((item) => item.teacherId === teacher?.id);
    const raw = staffRow?.phone ?? institute.data?.phone ?? '';
    const digits = raw.replace(/\D/g, '');
    const who = teacher?.fullName ? ` ${teacher.fullName}` : '';
    const text = `Hello${who ? ` ${who}` : ''}, this is ${p.summary?.parentName ?? 'a parent'} (${p.child?.name ?? 'my child'}'s parent). I wanted to talk about attendance.`;
    const url = digits
      ? `https://wa.me/${digits}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    try {
      await Linking.openURL(url);
    } catch {
      toast.error('Could not open WhatsApp');
    }
  };

  const refresh = () =>
    Promise.all([
      summary.refetch(),
      records.refetch(),
      sessions.refetch(),
      subjects.refetch(),
      p.refresh(),
    ]);

  const header = (
    <View style={{ gap: 16, paddingBottom: 8 }}>
      <ChildStrip />
      {loading ? <ListSkeleton rows={3} h={88} /> : null}
      {error && !counts ? <ErrorState message={error.message} onRetry={() => void refresh()} /> : null}
      {!loading && !error && counts ? (
        <Card flat pad={18}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <DaysRing attended={attended} total={total} />
            <View style={{ flex: 1, gap: 4 }}>
              <StatDot color={C.teal} label="Present" value={counts.present} />
              <StatDot color={C.danger} label="Absent" value={counts.absent} />
              <StatDot color={C.warning} label="Late" value={counts.late} />
            </View>
          </View>
        </Card>
      ) : null}
      {!loading && counts ? (
        <Card flat pad={18} style={{ gap: 12 }}>
          <Text variant="title" weight={800}>This month</Text>
          <MonthHeatmap byDate={byDate} />
        </Card>
      ) : null}
      <Text variant="title" weight={800}>Absences this term</Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: TAB_INSET, flexGrow: 1 }}
        data={!loading && counts ? absences : []}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={header}
        renderItem={({ item }) => (
          <View
            style={{
              minHeight: 64,
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: C.hairline,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 12,
            }}
          >
            <View style={{ flex: 1, gap: 3 }}>
              <Text variant="body" weight={700}>{dateShort(item.date)}</Text>
              <Text variant="caption" c={C.secondary}>{item.subject}</Text>
            </View>
            <View
              style={{
                backgroundColor: item.status === 'absent' ? C.dangerSoft : C.warningSoft,
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: R.chip,
              }}
            >
              <Text variant="label" weight={700} c={item.status === 'absent' ? C.danger : C.duesInk}>
                {item.pill}
              </Text>
            </View>
          </View>
        )}
        ListEmptyComponent={
          !loading && counts ? (
            <EmptyState icon="checkmark-circle-outline" title="No absences this term" text="Every recorded day so far has been present." />
          ) : null
        }
        ListFooterComponent={
          <View style={{ paddingTop: 20 }}>
            <Button title="Message the teacher" variant="outline" size="lg" icon="logo-whatsapp" onPress={() => void messageTeacher()} />
          </View>
        }
        refreshControl={
          <RefreshControl refreshing={summary.loading && Boolean(summary.data)} onRefresh={() => void refresh()} tintColor={C.primary} />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
