import React from 'react';
import { FlatList, Pressable, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { router } from 'expo-router';
import { C } from '@/lib/theme';
import { formatParentDate } from '@/core/contracts/parent';
import type { ParentChildSummary, ParentUpdate } from '@/core/contracts/models/parent';
import { useParent } from './context';
import { Action, currency, Icon, Label, Panel, percent, styles } from './ui';

export function MonthlyCard({ child }: { child: ParentChildSummary }) {
  const { summary } = useParent();
  const mobile = useWindowDimensions().width < 600;
  const stats = [
    { name: 'Attendance', value: percent(child.attendancePercent), color: C.teal },
    { name: 'Average', value: percent(child.averagePercent), color: C.primary },
    { name: 'Due now', value: currency(child.dueNow), color: child.dueNow ? C.duesInk : C.teal },
  ];
  return <Panel style={{ padding: mobile ? 20 : 24 }}>
    <View style={styles.spread}><Label size={15} weight="700">This month</Label><Label size={10} color={C.muted}>{summary?.month}</Label></View>
    <View style={{ flexDirection: 'row', marginTop: 19 }}>{stats.map((s, i) => <View key={s.name} testID={`stat-${s.name}`} style={{ flex: 1, paddingLeft: i ? (mobile ? 18 : 26) : 0, borderLeftWidth: i ? 1 : 0, borderColor: C.hairline }}><Label size={mobile ? (i === 2 && child.dueNow > 0 ? 22 : 29) : 34} numberOfLines={1} weight="800" color={s.color} style={{ lineHeight: 42, letterSpacing: -1 }}>{s.value}</Label><Label size={11} color={C.muted} style={{ marginTop: 3 }}>{s.name}</Label></View>)}</View>
  </Panel>;
}
export function TrendCard({ child }: { child: ParentChildSummary }) {
  const trend = child.trend;
  const min = Math.min(...trend.map(t => t.percent)) - 12;
  const max = Math.max(...trend.map(t => t.percent)) + 10;
  const points = trend.map((t, i) => ({ x: 18 + i / Math.max(trend.length - 1, 1) * 524, y: 115 - (t.percent - min) / Math.max(max - min, 1) * 100 }));
  let path = points.length ? `M ${points[0].x} ${points[0].y}` : '';
  for (let i = 1; i < points.length; i++) { const previous = points[i - 1]; const p = points[i]; const mid = (previous.x + p.x) / 2; path += ` C ${mid} ${previous.y}, ${mid} ${p.y}, ${p.x} ${p.y}`; }
  return <Panel style={{ paddingBottom: 19, flex: 1, minHeight: 224 }}>
    <View style={styles.spread}><Label size={15} weight="700">Performance trend</Label>{child.improvement !== null && child.improvement > 0 && <View style={[styles.row, { gap: 4, backgroundColor: C.tealSoft, paddingVertical: 3, paddingHorizontal: 8, borderRadius: 7 }]}><Icon name="trending-up" size={13} color={C.teal} /><Label size={10} color={C.teal} weight="700">{child.improvement} pts</Label></View>}</View>
    <Label size={10} color={C.muted} style={{ marginTop: 3 }}>Small steps. Steady progress.</Label>
    {trend.length ? <View accessible accessibilityLabel={`Last ${trend.length} tests: ${trend.map(t => `${t.label}, ${t.percent}%`).join('; ')}`}>
      <View style={{ height: 115, marginTop: 9, marginHorizontal: -3 }}><Svg width="100%" height="100%" viewBox="0 0 560 138" preserveAspectRatio="none"><Path d={path} stroke={C.primary} strokeWidth={2.2} fill="none" />{points.map((p, i) => <Circle key={i} cx={p.x} cy={p.y} r={i === points.length - 1 ? 5 : 3} fill={i === points.length - 1 ? C.accent : C.surface} stroke={i === points.length - 1 ? C.accent : C.primary} strokeWidth={i === points.length - 1 ? 0 : 1.6} />)}</Svg><View style={{ position: 'absolute', right: 0, top: -4 }}><Label size={11} color={C.accent} weight="700">{percent(trend.at(-1)!.percent)}</Label></View></View>
      <View style={styles.spread}><Label size={10} color={C.muted}>{trend[0].label}</Label><Label size={10} color={C.muted}>{trend.at(-1)!.label}</Label></View>
    </View> : <Label size={13} color={C.muted} style={{ paddingVertical: 35 }}>The next chapter is still being written. Test results will appear here.</Label>}
  </Panel>;
}
export function UpdateRow({ update, last = false }: { update: ParentUpdate; last?: boolean }) {
  const p = useParent();
  const alert = update.kind === 'attendance';
  const icon = update.kind === 'homework' ? 'book-outline' : alert ? 'calendar-outline' : 'megaphone-outline';
  return <Pressable accessibilityRole="button" accessibilityLabel={update.title} onPress={() => p.open({ type: 'update', update })} style={({ pressed }) => ({ flexDirection: 'row', gap: 13, alignItems: 'flex-start', paddingVertical: 19, borderBottomWidth: last ? 0 : 1, borderColor: C.hairline, opacity: pressed ? 0.6 : 1 })}>
    <View style={[styles.iconTile, { backgroundColor: alert ? C.warningSoft : C.canvas, width: 36, height: 36, borderRadius: 11 }]}><Icon name={icon} size={17} color={alert ? C.duesInk : C.muted} /></View>
    <View style={{ flex: 1 }}><Label size={12} weight="700" color={alert ? C.duesInk : C.ink}>{update.title}</Label><Label numberOfLines={1} size={10} color={C.muted} style={{ marginTop: 3 }}>{update.subtitle}</Label><Label size={9} color={C.muted} style={{ marginTop: 7 }}>{formatParentDate(update.date)}</Label></View><Icon name="chevron-forward" size={13} color={C.muted} />
  </Pressable>;
}
export function UpdatesCard({ child }: { child: ParentChildSummary }) {
  return <Panel style={{ flex: 1, paddingBottom: 18 }}>
    <View style={styles.spread}><Label size={15} weight="700">Recent updates</Label><Pressable accessibilityRole="button" accessibilityLabel="View all updates" onPress={() => router.navigate('/(parent)/updates')} hitSlop={10}><Icon name="arrow-forward" size={17} color={C.muted} /></Pressable></View>
    <Label size={10} color={C.muted} style={{ marginTop: 4 }}>The little things worth knowing.</Label>
    <FlatList data={child.updates} keyExtractor={u => u.id} scrollEnabled={false} renderItem={({ item, index }) => <UpdateRow update={item} last={index === child.updates.length - 1} />} ListEmptyComponent={<Label color={C.muted} size={13} style={{ paddingVertical: 28 }}>All quiet for now. We’ll keep you in the loop.</Label>} />
    <View style={[styles.row, { gap: 6, borderTopWidth: 1, borderColor: C.hairline, paddingTop: 14, marginTop: 'auto' }]}><Icon name="checkmark-circle-outline" size={13} color={C.teal} /><Label size={9} color={C.muted}>You’re up to date with their day.</Label></View>
  </Panel>;
}
export function FeeReminder({ child }: { child: ParentChildSummary }) {
  const mobile = useWindowDimensions().width < 600;
  const term = child.nextFee;
  if (!term) return null;
  return <View testID="fee-reminder" style={{ backgroundColor: C.accentSoft, borderRadius: 18, padding: mobile ? 20 : 24, flexDirection: mobile ? 'column' : 'row', alignItems: mobile ? 'stretch' : 'center', gap: 18 }}>
    <View style={[styles.row, { gap: 16, flex: 1 }]}><View style={{ width: 42, height: 42, borderRadius: 13, backgroundColor: C.surface, alignItems: 'center', justifyContent: 'center' }}><Icon name="wallet-outline" size={20} color={C.duesInk} /></View><View style={{ flex: 1 }}><Label size={13} weight="700" color={C.primary}>{term.label.replace(/ fee$/i, '')} fee of {currency(term.remaining)} is due on {formatParentDate(term.dueDate)}</Label><Label size={11} color={C.secondary} style={{ marginTop: 5 }}>A gentle reminder, so you can plan ahead.</Label></View></View>
    <Action label="Pay now" onPress={() => router.push('/(parent)/fees')} icon="arrow-forward" />
  </View>;
}
