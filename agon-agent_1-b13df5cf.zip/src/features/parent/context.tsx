import React, { createContext, useContext, useState } from 'react';
import { View } from 'react-native';
import type { ParentSummary, ParentChildSummary, ParentUpdate } from '@/core/contracts/models/parent';
import type { BackendError } from '@/core/contracts/errors';
import { useBackend, useParentSummary } from '@/core/backend';
import { ChildSwitcher } from '@/components/ui/ChildSwitcher';
import { ParentDialogs } from './dialogs';

/** Payments are not dialogs: "Pay now" opens the Fees screen and goes through PaymentPort.createIntent(). */
export type ParentDialog = { type: 'update'; update: ParentUpdate } | { type: 'profile' } | { type: 'support' } | null;
interface ParentContextValue {
  summary?: ParentSummary;
  child?: ParentChildSummary;
  loading: boolean;
  error: BackendError | null;
  refresh: () => Promise<void>;
  select: (id: string) => void;
  switcherOpen: boolean;
  setSwitcherOpen: (open: boolean) => void;
  open: (dialog: ParentDialog) => void;
  demo: boolean;
}
const ParentContext = createContext<ParentContextValue | null>(null);
export function ParentProvider({ children }: { children: React.ReactNode }) {
  const query = useParentSummary();
  const [selected, setSelected] = useState<string | null>(null);
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const [dialog, setDialog] = useState<ParentDialog>(null);
  const { backend } = useBackend();
  const child = query.data?.children.find(c => c.id === selected) ?? query.data?.children[0];
  const select = (id: string) => {
    if (!query.data?.children.some(c => c.id === id)) return;
    setSelected(id);
    setSwitcherOpen(false);
    setDialog(null);
  };
  return <ParentContext.Provider value={{ summary: query.data, child, loading: query.loading, error: query.error, refresh: query.refetch, select, switcherOpen, setSwitcherOpen, open: setDialog, demo: backend.name === 'memory' }}>
    {children}
    {query.data && child ? (
      <View style={{ position: 'absolute', width: 0, height: 0, overflow: 'hidden' }} pointerEvents="box-none">
        <ChildSwitcher items={query.data.children} selectedId={child.id} visible={switcherOpen} onOpen={() => setSwitcherOpen(true)} onClose={() => setSwitcherOpen(false)} onSelect={select} />
      </View>
    ) : null}
    <ParentDialogs dialog={dialog} close={() => setDialog(null)} />
  </ParentContext.Provider>;
}
export function useParent() {
  const value = useContext(ParentContext);
  if (!value) throw new Error('ParentProvider is missing');
  return value;
}
