import React from 'react';
import { View } from 'react-native';
import { C } from '@/lib/theme';
import { formatParentDate } from '@/core/contracts/parent';
import { ParentSheet } from './ParentSheet';
import { useParent, type ParentDialog } from './context';
import { Action, Icon, Label, Photo, styles } from './ui';

export function ParentDialogs({ dialog, close }: { dialog: ParentDialog; close: () => void }) {
  const { summary, demo } = useParent();
  if (!dialog) return null;
  const title = dialog.type === 'profile' ? 'Your parent space' : dialog.type === 'support' ? 'We’re here for you' : dialog.type === 'update' ? dialog.update.title : '';
  return <ParentSheet visible close={close} title={title}>
    {dialog.type === 'update' && <View style={{ gap: 22 }}>
      <View style={[styles.row, { gap: 8 }]}><Icon name={dialog.update.kind === 'homework' ? 'book-outline' : dialog.update.kind === 'attendance' ? 'calendar-outline' : 'megaphone-outline'} color={C.muted} size={17} /><Label color={C.muted} size={12}>{formatParentDate(dialog.update.date)} · {dialog.update.kind}</Label></View>
      <Label size={15} style={{ lineHeight: 26 }}>{dialog.update.body}</Label>
      <Action label="Got it, thank you" onPress={close} />
    </View>}
    {dialog.type === 'profile' && <View style={{ gap: 24 }}><View style={[styles.row, { gap: 15 }]}><Photo name={summary?.parentName ?? 'Parent'} uri={summary?.parentPhotoUrl} size={60} /><View><Label size={18} weight="700">{summary?.parentName}</Label><Label size={12} color={C.muted}>Parent · Sunrise Coaching</Label></View></View><View style={{ backgroundColor: C.canvas, padding: 18, borderRadius: 16 }}><Label weight="700">A space just for your family</Label><Label size={13} color={C.muted} style={{ marginTop: 6 }}>Only children linked to your parent account appear here. Your family’s details stay private.</Label></View>{demo && <Label size={12} color={C.muted}>You’re exploring the local demo. Changes are saved on this device.</Label>}<Action label="Back to overview" onPress={close} /></View>}
    {dialog.type === 'support' && <View style={{ gap: 22 }}><Label color={C.muted}>A question about attendance, homework or fees? Your child’s class teacher is the best place to start.</Label><View style={{ backgroundColor: C.canvas, padding: 20, borderRadius: 16, gap: 7 }}><Label weight="700">Sunrise Coaching Classes</Label><Label size={13} color={C.muted}>Boring Road, Patna, Bihar</Label><Label size={13} color={C.muted}>Speak with the office during your child’s next class.</Label></View><Label size={12} color={C.muted}>If an attendance entry seems incorrect, mention the date and class so the teacher can check it for you.</Label><Action label="Thanks, got it" onPress={close} /></View>}
  </ParentSheet>;
}
