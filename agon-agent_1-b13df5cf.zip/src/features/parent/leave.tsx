import React, { useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { C } from '@/lib/theme';
import { LEAVE_BACKDATE_DAYS, LEAVE_TYPE_LABELS, inclusiveDays, leaveStatusView } from '@/core/contracts/family';
import type { FamilyLeaveType, ISODate } from '@/core/contracts/models';
import { DateField } from '@/components/ui';
import { useFamilyLeave, useLeavePreview, useSubmitFamilyLeave } from '@/core/backend';
import { useParent } from './context';
import { ChildStrip, FamilyPage, StatusPill, formatLongDate } from './family-parts';
import { Action, Label, Panel, styles } from './ui';

const TYPES = Object.keys(LEAVE_TYPE_LABELS) as FamilyLeaveType[];
const todayIso = (): ISODate => new Date().toISOString().slice(0, 10);
const addDays = (iso: ISODate, days: number): ISODate => new Date(Date.parse(`${iso}T00:00:00Z`) + days * 86_400_000).toISOString().slice(0, 10);

/** Ask for leave for one child. Shows the classes it covers before it is sent. */
export function ParentLeaveScreen() {
  const p = useParent();
  const child = p.child;
  const today = todayIso();
  const [type, setType] = useState<FamilyLeaveType>('sick');
  const [from, setFrom] = useState<ISODate>(today);
  const [to, setTo] = useState<ISODate>(today);
  const [reason, setReason] = useState('');
  const rangeError = to < from ? 'The end date cannot be before the start date.' : null;
  const preview = useLeavePreview(child?.id, from, to);
  const history = useFamilyLeave(child?.id);
  const submit = useSubmitFamilyLeave();
  const reasonReady = reason.trim().length >= 3;
  const canSend = Boolean(child) && !rangeError && reasonReady && Boolean(preview.data) && !submit.loading;

  const send = async () => {
    if (!child || !canSend) return;
    const result = await submit.mutate({ studentId: child.id, leaveType: type, fromDate: from, toDate: to, reason: reason.trim() });
    if (result.ok) setReason('');
  };

  return (
    <FamilyPage title="Request leave" subtitle={child ? `For ${child.name}` : 'Choose a child to continue'}>
      <ChildStrip />

      <Panel style={{ padding: 20, gap: 18 }}>
        <View style={{ gap: 10 }}>
          <Label size={13} weight="700">Type</Label>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {TYPES.map((key) => {
              const selected = key === type;
              return (
                <Pressable key={key} accessibilityRole="button" accessibilityState={{ selected }} accessibilityLabel={LEAVE_TYPE_LABELS[key]} onPress={() => setType(key)}
                  style={{ minHeight: 44, paddingHorizontal: 16, justifyContent: 'center', borderRadius: 22, backgroundColor: selected ? C.primary : C.track }}>
                  <Label size={13} weight="600" color={selected ? C.surface : C.secondary}>{LEAVE_TYPE_LABELS[key]}</Label>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={{ gap: 12 }}>
          <DateField label="From" value={from} minDate={addDays(today, -LEAVE_BACKDATE_DAYS)} onChange={(_, iso) => setFrom(iso)} />
          <DateField label="To" value={to} minDate={from} onChange={(_, iso) => setTo(iso)} error={rangeError ?? undefined} />
          {!rangeError ? <Label size={13} color={C.muted}>{inclusiveDays(from, to)} day{inclusiveDays(from, to) === 1 ? '' : 's'}</Label> : null}
        </View>

        <View style={{ gap: 8 }}>
          <Label size={13} weight="700">Reason</Label>
          <TextInput
            accessibilityLabel="Reason for leave"
            value={reason}
            onChangeText={setReason}
            multiline
            maxLength={300}
            placeholder="A few words for the teacher and the office"
            placeholderTextColor={C.muted}
            style={{ minHeight: 84, borderRadius: 14, borderWidth: 1, borderColor: C.hairline, backgroundColor: C.canvas, padding: 14, color: C.ink, fontSize: 15, textAlignVertical: 'top' }}
          />
        </View>

        <View style={{ gap: 10 }}>
          <Label size={13} weight="700">Classes this covers</Label>
          {preview.loading && !preview.data ? <Label size={13} color={C.muted}>Checking the timetable…</Label> : null}
          {preview.error ? <Label size={13} color={C.danger}>{preview.error.message}</Label> : null}
          {preview.data ? (
            <View style={{ gap: 10 }}>
              <View style={[styles.row, { gap: 10 }]}>
                <View style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, backgroundColor: C.warningSoft }}>
                  <Label size={12} weight="700" color={C.duesInk}>{preview.data.classCount} class{preview.data.classCount === 1 ? '' : 'es'} affected</Label>
                </View>
                <Label size={12} color={C.muted}>{preview.data.days} day{preview.data.days === 1 ? '' : 's'}</Label>
              </View>
              {preview.data.classes.length === 0 ? <Label size={13} color={C.muted}>No scheduled classes fall on these dates.</Label> : null}
              {preview.data.classes.map((cls) => (
                <View key={`${cls.batchId}:${cls.subjectName}`} style={[styles.spread, { gap: 12 }]}>
                  <Label size={13}>{cls.subjectName} · {cls.batchName}</Label>
                  <Label size={13} weight="700" color={C.secondary}>{cls.sessions}</Label>
                </View>
              ))}
            </View>
          ) : null}
        </View>

        {submit.error ? <Label size={13} color={C.danger}>{submit.error.message}</Label> : null}
        <Action label={submit.loading ? 'Sending…' : 'Submit leave request'} disabled={!canSend} onPress={() => void send()} icon="paper-plane-outline" />
        <Label size={12} color={C.muted}>The teacher of each affected class and the office are notified straight away.</Label>
      </Panel>

      <View style={{ gap: 12 }}>
        <Label size={16} weight="700">Requests</Label>
        {history.loading && !history.data ? <Label color={C.muted}>Loading requests…</Label> : null}
        {history.data && history.data.length === 0 ? <Panel><Label color={C.muted}>No leave requests yet.</Label></Panel> : null}
        {(history.data ?? []).map((request) => {
          const status = leaveStatusView(request.status);
          return (
            <Panel key={request.id} style={{ padding: 18, gap: 8 }}>
              <View style={styles.spread}>
                <Label size={15} weight="700">{LEAVE_TYPE_LABELS[request.leaveType]}</Label>
                <StatusPill label={status.label} tone={status.tone} />
              </View>
              <Label size={13} color={C.secondary}>{formatLongDate(request.fromDate)} – {formatLongDate(request.toDate)} · {request.days} day{request.days === 1 ? '' : 's'} · {request.affectedClassCount} class{request.affectedClassCount === 1 ? '' : 'es'}</Label>
              <Label size={13} color={C.muted}>{request.reason}</Label>
              {request.reviewNote ? <Label size={13} color={C.ink}>Office note: {request.reviewNote}</Label> : null}
            </Panel>
          );
        })}
      </View>
    </FamilyPage>
  );
}
