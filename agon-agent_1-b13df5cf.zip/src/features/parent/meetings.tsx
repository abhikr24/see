import React, { useMemo, useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { C } from '@/lib/theme';
import { MEETING_NOTE_MAX, meetingStatusView } from '@/core/contracts/family';
import type { ISODate } from '@/core/contracts/models';
import { DateField } from '@/components/ui';
import { useFamilyMeetings, useFamilyTeachers, useRequestFamilyMeeting } from '@/core/backend';
import { useParent } from './context';
import { ChildStrip, FamilyPage, StatusPill, formatLongDate } from './family-parts';
import { Action, Label, Panel, styles } from './ui';

const todayIso = (): ISODate => new Date().toISOString().slice(0, 10);

/** Ask a teacher for a meeting, and follow each request through to the teacher's reply. */
export function ParentMeetingsScreen() {
  const p = useParent();
  const child = p.child;
  const teachers = useFamilyTeachers(child?.id);
  const meetings = useFamilyMeetings(child?.id);
  const request = useRequestFamilyMeeting();
  const [teacherId, setTeacherId] = useState<string | null>(null);
  const [date, setDate] = useState<ISODate>(todayIso());
  const [note, setNote] = useState('');

  // One chip per teacher, even when they take several of the child's batches.
  const choices = useMemo(() => {
    const byTeacher = new Map<string, { id: string; name: string; subjects: string[] }>();
    for (const t of teachers.data ?? []) {
      const entry = byTeacher.get(t.id) ?? { id: t.id, name: t.name, subjects: [] };
      if (!entry.subjects.includes(t.subjectName)) entry.subjects.push(t.subjectName);
      byTeacher.set(t.id, entry);
    }
    return [...byTeacher.values()];
  }, [teachers.data]);

  const canSend = Boolean(child) && Boolean(teacherId) && date >= todayIso() && !request.loading;

  const send = async () => {
    if (!child || !teacherId || !canSend) return;
    const result = await request.mutate({ studentId: child.id, teacherId, preferredDate: date, note });
    if (result.ok) setNote('');
  };

  return (
    <FamilyPage title="Meetings" subtitle={child ? `With ${child.name}’s teachers` : 'Choose a child to continue'}>
      <ChildStrip />

      <Panel style={{ padding: 20, gap: 18 }}>
        <Label size={16} weight="700">Request a meeting</Label>
        <View style={{ gap: 10 }}>
          <Label size={13} weight="700">Teacher</Label>
          {teachers.loading && !teachers.data ? <Label size={13} color={C.muted}>Loading teachers…</Label> : null}
          {teachers.data && choices.length === 0 ? <Label size={13} color={C.muted}>No teacher is assigned to {child?.name ?? 'this child'} yet.</Label> : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {choices.map((t) => {
              const selected = t.id === teacherId;
              return (
                <Pressable key={t.id} accessibilityRole="button" accessibilityState={{ selected }} accessibilityLabel={`Teacher ${t.name}`} onPress={() => setTeacherId(t.id)}
                  style={{ minHeight: 44, paddingHorizontal: 16, justifyContent: 'center', borderRadius: 22, backgroundColor: selected ? C.primary : C.track }}>
                  <Label size={13} weight="700" color={selected ? C.surface : C.ink}>{t.name}</Label>
                  <Label size={11} color={selected ? C.navyPale : C.muted}>{t.subjects.join(' · ')}</Label>
                </Pressable>
              );
            })}
          </View>
        </View>

        <DateField label="Preferred date" value={date} minDate={todayIso()} onChange={(_, iso) => setDate(iso)} />

        <View style={{ gap: 8 }}>
          <View style={styles.spread}>
            <Label size={13} weight="700">Note (optional)</Label>
            <Label size={12} color={C.muted}>{note.length}/{MEETING_NOTE_MAX}</Label>
          </View>
          <TextInput
            accessibilityLabel="Note for the teacher"
            value={note}
            onChangeText={setNote}
            multiline
            maxLength={MEETING_NOTE_MAX}
            placeholder="What would you like to discuss?"
            placeholderTextColor={C.muted}
            style={{ minHeight: 72, borderRadius: 14, borderWidth: 1, borderColor: C.hairline, backgroundColor: C.canvas, padding: 14, color: C.ink, fontSize: 15, textAlignVertical: 'top' }}
          />
        </View>

        {request.error ? <Label size={13} color={C.danger}>{request.error.message}</Label> : null}
        <Action label={request.loading ? 'Sending…' : 'Send request'} disabled={!canSend} onPress={() => void send()} icon="calendar-outline" />
      </Panel>

      <View style={{ gap: 12 }}>
        <Label size={16} weight="700">Your requests</Label>
        {meetings.loading && !meetings.data ? <Label color={C.muted}>Loading requests…</Label> : null}
        {meetings.data && meetings.data.length === 0 ? <Panel><Label color={C.muted}>No meeting requests yet.</Label></Panel> : null}
        {(meetings.data ?? []).map((meeting) => {
          const status = meetingStatusView(meeting.status);
          return (
            <Panel key={meeting.id} style={{ padding: 18, gap: 8 }}>
              <View style={styles.spread}>
                <Label size={15} weight="700">{meeting.teacherName}</Label>
                <StatusPill label={status.label} tone={status.tone} />
              </View>
              <Label size={13} color={C.secondary}>
                {meeting.preferredAt ? `Preferred ${formatLongDate(meeting.preferredAt)}` : 'No date given'}
              </Label>
              {meeting.reason ? <Label size={13} color={C.muted}>{meeting.reason}</Label> : null}
              {meeting.responseNote
                ? <Label size={13} color={C.ink}>Teacher’s reply: {meeting.responseNote}</Label>
                : <Label size={12} color={C.muted}>{meeting.status === 'pending' ? 'Waiting for the teacher to reply.' : 'No note from the teacher.'}</Label>}
            </Panel>
          );
        })}
      </View>
    </FamilyPage>
  );
}
