import React, { useMemo, useState } from 'react';
import { FlatList, Platform, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import {
  Button,
  Card,
  EmptyState,
  ErrorState,
  ListSkeleton,
  Text,
} from '@/components/ui';
import { toast, useInstitute, useStudent360, useSubjects } from '@/core/backend';
import { useDomainQuery } from '@/core/hooks/domain';
import type { ID, Mark } from '@/core/contracts/models';
import { useExamAnalysis, useStudentExamList } from '@/features/exams/analysis-hooks';
import { dateShort } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { ChildStrip } from './child-strip';
import { useParent } from './context';
import { reportCardHtml, type ReportSubject } from './report-card';

const TAB_INSET = 136;

function SubjectBar({ name, percent, weak }: { name: string; percent: number; weak: boolean }) {
  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text variant="caption" weight={600} numberOfLines={1} style={{ flex: 1, marginRight: 8 }}>
          {name}
        </Text>
        <Text variant="caption" weight={700} tabular>
          {Math.round(percent)}%
        </Text>
      </View>
      <View style={{ height: 8, borderRadius: R.chip, backgroundColor: C.track, overflow: 'hidden' }}>
        <View
          style={{
            width: `${Math.max(0, Math.min(100, percent))}%`,
            height: '100%',
            backgroundColor: weak ? C.warning : C.primary,
            borderRadius: R.chip,
          }}
        />
      </View>
    </View>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <Card flat pad={12} style={{ flex: 1, minHeight: 78, justifyContent: 'space-between' }}>
      <Text variant="label" c={C.muted} numberOfLines={1}>
        {label}
      </Text>
      <Text weight={800} numberOfLines={2} style={{ fontSize: 16, lineHeight: 20, marginTop: 8 }}>
        {value}
      </Text>
    </Card>
  );
}

export function ParentPerformanceScreen() {
  const p = useParent();
  const studentId = p.child?.id ?? null;
  const institute = useInstitute();
  const board = useStudent360(studentId);
  const list = useStudentExamList();
  const subjects = useSubjects({ limit: 100 });
  const marks = useDomainQuery(
    'marks',
    ['parent-child', studentId],
    (b, i) => b.marks.list(i, { where: { studentId: studentId as ID }, limit: 200 }),
    Boolean(studentId),
  );
  const [busy, setBusy] = useState(false);

  const showMarks = institute.data?.settings.features.showMarksToParents !== false;
  const rows = useMemo(
    () => (list.data ?? []).filter((row) => !studentId || row.studentId === studentId),
    [list.data, studentId],
  );
  const latest = rows[0] ?? null;
  const analysis = useExamAnalysis(latest?.examId ?? null);
  const me = analysis.data?.students.find((student) => student.studentId === studentId) ?? null;
  const overall = board.data?.snapshot.examPercent ?? null;
  const first = [...rows].sort((a, b) => (a.date ?? '').localeCompare(b.date ?? ''))[0];
  const delta = overall !== null && first ? overall - first.percentage : null;
  const since = first?.date
    ? new Date(`${first.date.slice(0, 10)}T12:00:00`).toLocaleDateString('en-IN', { month: 'long' })
    : null;

  const subjectRows: ReportSubject[] = useMemo(() => {
    const names = new Map((subjects.data?.items ?? []).map((subject) => [subject.id, subject.name]));
    const grouped = new Map<string, { name: string; obtained: number; max: number }>();
    for (const mark of (marks.data?.items ?? []) as Mark[]) {
      if (studentId && mark.studentId !== studentId) continue;
      if (mark.isAbsent || mark.maxMarks <= 0) continue;
      const current = grouped.get(mark.subjectId) ?? { name: names.get(mark.subjectId) ?? 'Subject', obtained: 0, max: 0 };
      current.obtained += mark.marksObtained ?? 0;
      current.max += mark.maxMarks;
      grouped.set(mark.subjectId, current);
    }
    return [...grouped.values()]
      .map((row) => ({ ...row, percent: row.max ? (row.obtained / row.max) * 100 : 0 }))
      .sort((a, b) => b.percent - a.percent);
  }, [marks.data, subjects.data, studentId]);

  const weakest = subjectRows.length ? subjectRows.reduce((min, row) => (row.percent < min.percent ? row : min)) : null;
  const best = subjectRows[0] ?? null;
  const rankLabel = me?.rank && analysis.data ? `${me.rank}/${analysis.data.totalStudents}` : board.data?.snapshot.latestRank ? `${board.data.snapshot.latestRank}` : '—';
  const attendance = board.data?.attendance;

  const download = async () => {
    if (!p.child || busy) return;
    setBusy(true);
    try {
      const html = reportCardHtml({
        studentName: p.child.name,
        classLabel: p.child.classLabel,
        instituteName: institute.data?.name ?? p.child.instituteName,
        term: institute.data?.settings.academicYear ? `Academic year ${institute.data.settings.academicYear}` : 'This term',
        attendancePresent: attendance ? attendance.present + attendance.late : 0,
        attendanceTotal: attendance?.total ?? 0,
        attendancePercent: attendance?.percent ?? 0,
        overallPercent: overall,
        rankLabel,
        subjects: subjectRows,
      });
      if (Platform.OS === 'web') await Print.printAsync({ html });
      else {
        const file = await Print.printToFileAsync({ html });
        await Sharing.shareAsync(file.uri, { mimeType: 'application/pdf', UTI: '.pdf' });
      }
    } catch {
      toast.error('Could not create the report card. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const refresh = () =>
    Promise.all([list.refetch(), board.refetch(), marks.refetch(), subjects.refetch(), analysis.refetch(), p.refresh()]);

  const loading = (list.loading || board.loading) && !list.data && !board.data;
  const error = list.error ?? board.error;

  if (!showMarks) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin, paddingBottom: TAB_INSET, gap: 16 }}>
        <ChildStrip />
        <EmptyState
          icon="eye-off-outline"
          title="Marks stay with the teacher for now"
          text="Your institute has turned off marks for parents. Please speak with the class teacher if you have a question about progress."
        />
      </View>
    );
  }

  const recent = rows.slice(0, 3);
  const header = (
    <View style={{ gap: 16, paddingBottom: 8 }}>
      <ChildStrip />
      {loading ? <ListSkeleton rows={4} h={84} /> : null}
      {error && !board.data && !list.data ? <ErrorState message={error.message} onRetry={() => void refresh()} /> : null}
      {!loading ? (
        <>
          <View style={{ gap: 4 }}>
            <Text weight={800} tabular style={{ fontSize: 34, lineHeight: 40 }}>
              {overall === null ? '—' : `${Math.round(overall)}%`}
            </Text>
            <Text variant="caption" c={C.secondary}>
              Overall average
            </Text>
            {delta !== null && since ? (
              <Text variant="caption" weight={700} c={delta >= 0 ? C.teal : C.danger}>
                {delta >= 0 ? '+' : ''}
                {Math.round(delta)}% since {since}
              </Text>
            ) : null}
          </View>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <MiniStat label="Rank" value={rankLabel} />
            <MiniStat label="Best subject" value={best?.name ?? '—'} />
            <MiniStat label="Needs help" value={weakest && best && weakest.name !== best.name ? weakest.name : weakest?.name ?? '—'} />
          </View>
          <View style={{ gap: 10 }}>
            <Text variant="title" weight={800}>Subject-wise</Text>
            <Card flat pad={14} style={{ gap: 12 }}>
              {subjectRows.length ? (
                subjectRows.map((row) => (
                  <SubjectBar key={row.name} name={row.name} percent={row.percent} weak={weakest?.name === row.name && subjectRows.length > 1} />
                ))
              ) : (
                <Text variant="caption" c={C.secondary}>Published subject marks will appear here.</Text>
              )}
            </Card>
          </View>
          <Text variant="title" weight={800}>Recent tests</Text>
        </>
      ) : null}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: TAB_INSET, flexGrow: 1 }}
        data={!loading ? recent : []}
        keyExtractor={(item) => `${item.examId}-${item.studentId}`}
        ListHeaderComponent={header}
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            style={({ pressed }) => ({
              minHeight: 64,
              paddingVertical: 12,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 12,
              borderBottomWidth: 1,
              borderBottomColor: C.hairline,
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <View style={{ flex: 1, gap: 3 }}>
              <Text variant="body" weight={700} numberOfLines={1}>{item.name}</Text>
              <Text variant="caption" c={C.muted}>{item.date ? dateShort(item.date) : 'Date not set'}</Text>
            </View>
            <Text variant="body" weight={800} tabular>
              {item.marksObtained}/{item.maxMarks}
            </Text>
            <Ionicons name="chevron-forward" size={17} color={C.muted} />
          </Pressable>
        )}
        ListEmptyComponent={
          !loading ? (
            <EmptyState icon="ribbon-outline" title="No tests yet" text="Published results will show here as soon as the teacher shares them." />
          ) : null
        }
        ListFooterComponent={
          <View style={{ paddingTop: 20 }}>
            <Button
              title="Download report card"
              variant="outline"
              size="lg"
              icon="download-outline"
              loading={busy}
              onPress={() => void download()}
            />
          </View>
        }
        refreshControl={
          <RefreshControl refreshing={list.loading && Boolean(list.data)} onRefresh={() => void refresh()} tintColor={C.primary} />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
