import type { FamilyReceipt } from '@/core/contracts/models';
import { METHOD_LABEL } from './family-parts';

const escape = (text: string) => text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
/** Same formatting as the on-screen amount (₹ with Indian digit grouping). */
const money = (amount: number) => `₹${amount.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;

/** The one-page receipt a parent downloads. Every figure is read from the same FamilyReceipt the screen shows. */
export function familyReceiptHtml(receipt: FamilyReceipt): string {
  const date = new Date(`${receipt.paidAt.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
  const rows: [string, string][] = [
    ['Student', receipt.studentName],
    ['Term', receipt.termLabel],
    ['Receipt no', receipt.receiptNo],
    ['Paid on', date],
    ['Method', METHOD_LABEL[receipt.method] ?? receipt.method],
    ...(receipt.referenceNo ? [['Reference', receipt.referenceNo] as [string, string]] : []),
  ];
  return `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;color:#101B4C;padding:48px}main{border:1.5px dashed #D7DDEB;border-radius:18px;padding:36px;max-width:530px;margin:auto}h1{font-size:22px;margin-bottom:3px}.city{color:#5A6684;margin:0 0 30px}.tag{letter-spacing:3px;color:#5A6684;font-size:12px}.amount{font-size:42px;font-weight:800;margin:8px 0 28px}.row{border-top:1px solid #E7EBF5;padding:14px 0;display:flex;justify-content:space-between}.row span{color:#5A6684}</style></head><body><main><h1>${escape(receipt.instituteName)}</h1><p class="city">${escape(receipt.instituteCity ?? '')}</p><div class="tag">RECEIPT</div><div class="amount">${escape(money(receipt.amount))}</div>${rows.map(([k, v]) => `<div class="row"><span>${escape(k)}</span><b>${escape(v)}</b></div>`).join('')}</main></body></html>`;
}
