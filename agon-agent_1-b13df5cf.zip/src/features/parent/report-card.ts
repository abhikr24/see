import { C } from '@/lib/theme';

export interface ReportSubject {
  name: string;
  obtained: number;
  max: number;
  percent: number;
}

export interface ReportCardInput {
  studentName: string;
  classLabel: string;
  instituteName: string;
  term: string;
  attendancePresent: number;
  attendanceTotal: number;
  attendancePercent: number;
  overallPercent: number | null;
  rankLabel: string;
  subjects: ReportSubject[];
}

const escape = (text: string) =>
  text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

/** One printable page. Institute identity only — no product branding. */
export function reportCardHtml(doc: ReportCardInput): string {
  const attendance =
    doc.attendanceTotal > 0
      ? `${doc.attendancePresent} of ${doc.attendanceTotal} days (${Math.round(doc.attendancePercent)}%)`
      : 'No roll calls recorded';
  const overall = doc.overallPercent === null ? '—' : `${Math.round(doc.overallPercent)}%`;
  const rows = doc.subjects
    .map(
      (subject) =>
        `<tr><td>${escape(subject.name)}</td><td class="num">${subject.obtained}</td><td class="num">${subject.max}</td><td class="num">${Math.round(subject.percent)}%</td></tr>`,
    )
    .join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>Report card</title>
<style>
  @page { size: A4; margin: 18mm; }
  body { font-family: Arial, sans-serif; color: ${C.primary}; margin: 0; }
  h1 { font-size: 22px; margin: 0 0 4px; }
  .sub { color: ${C.secondary}; margin: 0 0 22px; font-size: 13px; }
  .meta { display: flex; justify-content: space-between; gap: 16px; margin-bottom: 22px; }
  .meta div { flex: 1; border: 1px solid ${C.hairline}; border-radius: 10px; padding: 12px 14px; }
  .k { color: ${C.secondary}; font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; margin: 0 0 4px; }
  .v { font-size: 16px; font-weight: 700; margin: 0; }
  table { width: 100%; border-collapse: collapse; }
  th { text-align: left; font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; color: ${C.secondary}; padding: 8px 0; border-bottom: 1px solid ${C.hairline}; }
  td { padding: 10px 0; border-bottom: 1px solid ${C.hairline}; font-size: 14px; }
  .num { text-align: right; font-variant-numeric: tabular-nums; }
  .empty { color: ${C.secondary}; padding: 18px 0; }
</style></head><body>
  <h1>${escape(doc.instituteName)}</h1>
  <p class="sub">${escape(doc.term)} · Report card</p>
  <div class="meta">
    <div><p class="k">Student</p><p class="v">${escape(doc.studentName)}</p></div>
    <div><p class="k">Class</p><p class="v">${escape(doc.classLabel)}</p></div>
    <div><p class="k">Overall</p><p class="v">${escape(overall)}</p></div>
  </div>
  <div class="meta">
    <div><p class="k">Attendance</p><p class="v">${escape(attendance)}</p></div>
    <div><p class="k">Rank</p><p class="v">${escape(doc.rankLabel)}</p></div>
  </div>
  <p class="k">Subject-wise marks</p>
  ${
    rows
      ? `<table><thead><tr><th>Subject</th><th class="num">Marks</th><th class="num">Max</th><th class="num">%</th></tr></thead><tbody>${rows}</tbody></table>`
      : `<p class="empty">No published marks for this term.</p>`
  }
</body></html>`;
}
