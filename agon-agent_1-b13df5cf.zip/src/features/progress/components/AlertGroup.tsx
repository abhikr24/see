import React from 'react';
import { View } from 'react-native';
import { Badge, Card, Text } from '@/components/ui';
import { C, TONE } from '@/lib/theme';
import { GROUP_META, type AlertGroup as AlertGroupView } from '../model';
import { AlertRow } from './AlertRow';

export function AlertGroup({
  group,
  onView,
  onLog,
}: {
  group: AlertGroupView;
  onView: (studentId: string, alertId: string) => void;
  onLog: (studentId: string, alertId: string) => void;
}) {
  const meta = GROUP_META[group.key];
  const tone = TONE[meta.tone];
  if (group.items.length === 0) return null;
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: tone.fg }} />
        <Text variant="title" weight={800}>
          {meta.title}
        </Text>
        <Badge label={`${group.items.length}`} tone={meta.tone} small />
        <Text variant="caption" c={C.secondary} style={{ marginLeft: 'auto' }}>
          {meta.hint}
        </Text>
      </View>
      <Card pad={0} style={{ paddingHorizontal: 16 }}>
        {group.items.map((card, idx) => (
          <AlertRow
            key={card.alert.id}
            card={card}
            divider={idx < group.items.length - 1}
            onView={() => onView(card.studentId, card.alert.id)}
            onLog={() => onLog(card.studentId, card.alert.id)}
          />
        ))}
      </Card>
    </View>
  );
}
