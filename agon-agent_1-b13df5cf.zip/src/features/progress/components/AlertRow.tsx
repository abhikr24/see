import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Divider, Text } from '@/components/ui';
import { C } from '@/lib/theme';
import type { AlertCard as AlertCardView } from '../model';

function Actions({ onView, onLog }: { onView: () => void; onLog: () => void }) {
  return (
    <View style={{ alignItems: 'flex-end', justifyContent: 'center', gap: 10 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="View student"
        onPress={onView}
        hitSlop={8}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 2 }}
      >
        <Text variant="body" weight={700} c={C.primary}>
          View
        </Text>
        <Ionicons name="chevron-forward" size={16} color={C.primary} />
      </Pressable>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Log intervention"
        onPress={onLog}
        hitSlop={8}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
      >
        <Ionicons name="add-circle-outline" size={15} color={C.secondary} />
        <Text variant="caption" weight={600} c={C.secondary}>
          Log
        </Text>
      </Pressable>
    </View>
  );
}

export function AlertRow({
  card,
  divider,
  onView,
  onLog,
}: {
  card: AlertCardView;
  divider?: boolean;
  onView: () => void;
  onLog: () => void;
}) {
  return (
    <View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`View ${card.studentName}`}
        onPress={onView}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14 }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 }}>
          <Avatar name={card.studentName} uri={card.photoUrl} size={44} />
          <View style={{ flex: 1, gap: 3 }}>
            <Text variant="body" weight={700} numberOfLines={1}>
              {card.studentName}
            </Text>
            <Text variant="caption" c={C.secondary} numberOfLines={1}>
              {card.batchName}
            </Text>
            <Text variant="caption" c={C.ink} numberOfLines={2} style={{ lineHeight: 18 }}>
              {card.alert.detail}
            </Text>
          </View>
        </View>
        <Actions onView={onView} onLog={onLog} />
      </Pressable>
      {divider ? <Divider /> : null}
    </View>
  );
}
