import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Card, Divider, EmptyState, IconBox, Text } from '@/components/ui';
import type { Intervention } from '@/core/contracts/models';
import { dateShort } from '@/lib/format';
import { C } from '@/lib/theme';
import {
  INTERVENTION_KINDS,
  kindLabel,
  outcomeLabel,
  outcomeTone,
} from '../model';

function TimelineRow({
  item,
  divider,
  onPress,
}: {
  item: Intervention;
  divider?: boolean;
  onPress: () => void;
}) {
  const kind = INTERVENTION_KINDS.find((row) => row.key === item.kind);
  return (
    <View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${kindLabel(item.kind)} by ${item.doneBy}`}
        onPress={onPress}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14 }}
      >
        <IconBox name={kind?.icon ?? 'ellipsis-horizontal-outline'} tone="primary" size={44} />
        <View style={{ flex: 1, gap: 3 }}>
          <Text variant="body" weight={700} numberOfLines={1}>
            {kindLabel(item.kind)}
          </Text>
          <Text variant="caption" c={C.secondary} numberOfLines={1}>
            {item.doneBy} · {dateShort(item.doneOn)}
          </Text>
          {item.note ? (
            <Text variant="caption" c={C.ink} numberOfLines={2} style={{ lineHeight: 18 }}>
              {item.note}
            </Text>
          ) : null}
        </View>
        <View style={{ alignItems: 'flex-end', gap: 6 }}>
          <Badge label={outcomeLabel(item.outcome)} tone={outcomeTone(item.outcome)} small />
          <Ionicons name="chevron-forward" size={16} color={C.muted} />
        </View>
      </Pressable>
      {divider ? <Divider /> : null}
    </View>
  );
}

export function InterventionsSection({
  items,
  onLog,
  onOutcome,
}: {
  items: Intervention[];
  onLog: () => void;
  onOutcome: (item: Intervention) => void;
}) {
  return (
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Text variant="title" weight={800}>
          Interventions
        </Text>
        {items.length > 0 ? <Badge label={`${items.length}`} tone="primary" small /> : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Log intervention"
          onPress={onLog}
          hitSlop={8}
          style={{
            marginLeft: 'auto',
            flexDirection: 'row',
            alignItems: 'center',
            gap: 4,
            backgroundColor: C.primary,
            paddingHorizontal: 14,
            height: 36,
            borderRadius: 18,
          }}
        >
          <Ionicons name="add" size={16} color={C.surface} />
          <Text variant="caption" weight={700} c={C.surface}>
            Log
          </Text>
        </Pressable>
      </View>
      {items.length === 0 ? (
        <Card>
          <EmptyState
            icon="heart-outline"
            tone="primary"
            title="Nothing tried yet"
            text="Log the first step — a call home, an extra class, a counselling session."
            actionLabel="Log intervention"
            onAction={onLog}
          />
        </Card>
      ) : (
        <Card pad={0} style={{ paddingHorizontal: 16 }}>
          {items.map((item, idx) => (
            <TimelineRow
              key={item.id}
              item={item}
              divider={idx < items.length - 1}
              onPress={() => onOutcome(item)}
            />
          ))}
        </Card>
      )}
      <Text variant="caption" c={C.secondary}>
        Tap an entry to record how it went: improved, unchanged or escalated.
      </Text>
    </View>
  );
}
