import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, View } from 'react-native';
import { Button, DateField, Input, Sheet, Text } from '@/components/ui';
import type { ID, InterventionKind } from '@/core/contracts/models';
import { todayISO } from '@/lib/format';
import { C, R } from '@/lib/theme';
import { INTERVENTION_KINDS } from '../model';
import { type LogInterventionInput } from '../hooks';
import type { MutationResult } from '@/core/hooks/mutation';
import type { Intervention } from '@/core/contracts/models';

function KindChips({
  value,
  onChange,
}: {
  value: InterventionKind | null;
  onChange: (kind: InterventionKind) => void;
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {INTERVENTION_KINDS.map((row) => {
        const active = value === row.key;
        return (
          <Pressable
            key={row.key}
            accessibilityRole="button"
            accessibilityLabel={row.label}
            accessibilityState={{ selected: active }}
            onPress={() => onChange(row.key)}
            style={{
              height: 44,
              paddingHorizontal: 16,
              borderRadius: R.chip,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: active ? C.primary : C.surface,
              borderWidth: 1,
              borderColor: active ? C.primary : C.hairline,
            }}
          >
            <Text variant="body" weight={600} c={active ? C.surface : C.secondary}>
              {row.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function LogInterventionSheet({
  visible,
  onClose,
  studentId,
  alertId,
  defaultDoneBy,
  log,
  saving,
}: {
  visible: boolean;
  onClose: () => void;
  studentId: ID;
  alertId: ID | null;
  defaultDoneBy: string;
  log: (input: LogInterventionInput) => Promise<MutationResult<Intervention>>;
  saving: boolean;
}) {
  const [kind, setKind] = useState<InterventionKind | null>(null);
  const [doneBy, setDoneBy] = useState(defaultDoneBy);
  const [doneOn, setDoneOn] = useState(todayISO());
  const [note, setNote] = useState('');

  useEffect(() => {
    if (visible) {
      setKind(null);
      setDoneBy(defaultDoneBy);
      setDoneOn(todayISO());
      setNote('');
    }
  }, [visible, defaultDoneBy]);

  const valid = kind !== null && doneBy.trim().length > 0 && doneOn.length === 10;

  const save = async () => {
    if (!valid || !kind) return;
    const result = await log({
      studentId,
      alertId,
      kind,
      doneBy: doneBy.trim(),
      doneOn,
      note: note.trim() ? note.trim() : null,
    });
    if (result.ok) onClose();
  };

  return (
    <Sheet visible={visible} onClose={onClose} title="Log intervention" subtitle="What was tried, who did it, and when.">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingBottom: 24 }}
        >
          <View style={{ gap: 16 }}>
            <View style={{ gap: 8 }}>
              <Text variant="label" c={C.muted}>
                What was tried
              </Text>
              <KindChips value={kind} onChange={setKind} />
            </View>
            <Input
              label="Who did it"
              value={doneBy}
              onChangeText={setDoneBy}
              placeholder="Teacher or staff name"
              returnKeyType="next"
            />
            <DateField label="Date" value={doneOn} onChange={(_dmy, iso) => setDoneOn(iso)} maxDate={todayISO()} />
            <Input
              label="Note (optional)"
              value={note}
              onChangeText={setNote}
              placeholder="A line about what happened"
              multiline
              numberOfLines={3}
              returnKeyType="done"
            />
            <Button title="Save intervention" full loading={saving} disabled={!valid} onPress={() => void save()} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Sheet>
  );
}
