import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { IconBox, Sheet, Text } from '@/components/ui';
import type { ID, Intervention, InterventionOutcome } from '@/core/contracts/models';
import type { MutationResult } from '@/core/hooks/mutation';
import { dateShort } from '@/lib/format';
import { C, R } from '@/lib/theme';
import { INTERVENTION_OUTCOMES, kindLabel } from '../model';

export function OutcomeSheet({
  item,
  onClose,
  setOutcome,
  saving,
}: {
  item: Intervention | null;
  onClose: () => void;
  setOutcome: (input: { id: ID; outcome: InterventionOutcome }) => Promise<MutationResult<Intervention>>;
  saving: boolean;
}) {
  const pick = async (outcome: InterventionOutcome) => {
    if (!item) return;
    const result = await setOutcome({ id: item.id, outcome });
    if (result.ok) onClose();
  };

  return (
    <Sheet
      visible={item !== null}
      onClose={onClose}
      title="How did it go?"
      subtitle={item ? `${kindLabel(item.kind)} · ${item.doneBy} · ${dateShort(item.doneOn)}` : undefined}
      snapPoints={['46%']}
    >
      <View style={{ gap: 10, paddingBottom: 24 }}>
        {INTERVENTION_OUTCOMES.map((row) => {
          const selected = item?.outcome === row.key;
          return (
            <Pressable
              key={row.key}
              accessibilityRole="button"
              accessibilityLabel={`Mark ${row.label.toLowerCase()}`}
              accessibilityState={{ selected }}
              disabled={saving}
              onPress={() => void pick(row.key)}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 12,
                backgroundColor: C.surface,
                borderRadius: R.card,
                borderWidth: selected ? 2 : 1,
                borderColor: selected ? C.primary : C.hairline,
                padding: 14,
                opacity: saving ? 0.6 : 1,
              }}
            >
              <IconBox name={row.icon} tone={row.tone} size={44} />
              <Text variant="body" weight={700} style={{ flex: 1 }}>
                {row.label}
              </Text>
              {selected ? <Ionicons name="checkmark-circle" size={22} color={C.primary} /> : null}
            </Pressable>
          );
        })}
      </View>
    </Sheet>
  );
}
