import { useDomainMutation, useDomainQuery } from '@/core/hooks/domain';
import type { ID, Intervention, InterventionOutcome, NewEntity } from '@/core/contracts/models';
import { buildBoard, type ProgressBoard } from './model';

/**
 * The owner progress board. computeAlerts recomputes every rule on read, so
 * the list is never stale and needs no background job.
 */
export function useProgressBoard() {
  return useDomainQuery<ProgressBoard>('progress', ['board'], async (b, i) => {
    const [alerts, students, batches, interventions] = await Promise.all([
      b.progress.computeAlerts(i, {}),
      b.students.list(i, { limit: 500 }),
      b.batches.listSummaries(i),
      b.progress.listInterventions(i),
    ]);
    return buildBoard(alerts, students.items, batches, interventions);
  });
}

export type LogInterventionInput = NewEntity<Intervention, 'studentId' | 'kind' | 'doneBy' | 'doneOn'>;

/** One student's intervention timeline, newest first. */
export function useInterventions(studentId: ID | null) {
  const timeline = useDomainQuery<Intervention[]>(
    'progress',
    ['interventions', studentId],
    (b, i) => b.progress.listInterventions(i, { studentId: studentId as ID }),
    studentId !== null,
  );
  const log = useDomainMutation<LogInterventionInput, Intervention>(
    'progress',
    (b, i, input) => b.progress.logIntervention(i, input),
    { success: 'Intervention logged', failure: 'Could not log the intervention' },
  );
  const close = useDomainMutation<{ id: ID; outcome: InterventionOutcome }, Intervention>(
    'progress',
    (b, i, { id, outcome }) => b.progress.setInterventionOutcome(i, id, outcome),
    { success: 'Outcome saved', failure: 'Could not save the outcome' },
  );
  return {
    ...timeline,
    log: log.mutate,
    setOutcome: close.mutate,
    saving: log.loading || close.loading,
  };
}
