import type { Ionicons } from '@expo/vector-icons';
import type {
  BatchSummary,
  ID,
  Intervention,
  InterventionKind,
  InterventionOutcome,
  RiskAlert,
  RiskKind,
  Student,
} from '@/core/contracts/models';
import type { Tone } from '@/lib/theme';

export type AlertGroupKey = 'attention' | 'watch' | 'improving';

export interface AlertCard {
  alert: RiskAlert;
  studentId: ID;
  studentName: string;
  photoUrl: string | null;
  batchName: string;
  group: AlertGroupKey;
}

export interface AlertGroup {
  key: AlertGroupKey;
  items: AlertCard[];
}

export interface BoardStats {
  studentsAtRisk: number;
  alertsThisWeek: number;
  interventionsOpen: number;
}

export interface ProgressBoard {
  groups: AlertGroup[];
  stats: BoardStats;
  total: number;
}

/**
 * Where an alert lands on the board. Fee and legacy kinds stay on the
 * Student 360; the board shows only the four progress streams + improving.
 */
export function groupOfAlert(kind: RiskKind): AlertGroupKey | null {
  if (kind === 'low_attendance' || kind === 'sudden_absence') return 'attention';
  if (kind === 'declining_marks' || kind === 'work_incomplete') return 'watch';
  if (kind === 'improving') return 'improving';
  return null;
}

export const GROUP_META: Record<AlertGroupKey, { title: string; hint: string; tone: Tone }> = {
  attention: {
    title: 'Needs attention',
    hint: 'Act on these first',
    tone: 'danger',
  },
  watch: {
    title: 'Watch',
    hint: 'Drifting — check in soon',
    tone: 'warning',
  },
  improving: {
    title: 'Improving',
    hint: 'Recovery in progress',
    tone: 'teal',
  },
};

const GROUP_ORDER: AlertGroupKey[] = ['attention', 'watch', 'improving'];

function weekAgo(today: string): string {
  const dt = new Date(`${today}T00:00:00Z`);
  dt.setUTCDate(dt.getUTCDate() - 7);
  return dt.toISOString();
}

export function buildBoard(
  alerts: RiskAlert[],
  students: Pick<Student, 'id' | 'fullName' | 'photoUrl'>[],
  batches: Pick<BatchSummary, 'id' | 'name'>[],
  interventions: Intervention[],
  today = new Date().toISOString().slice(0, 10),
): ProgressBoard {
  const names = new Map(students.map((s) => [s.id, s]));
  const batchNames = new Map(batches.map((b) => [b.id, b.name]));
  const cards: AlertCard[] = [];
  for (const alert of alerts) {
    const group = groupOfAlert(alert.kind);
    const student = names.get(alert.studentId);
    if (!group || !student || alert.status === 'resolved') continue;
    cards.push({
      alert,
      studentId: student.id,
      studentName: student.fullName,
      photoUrl: student.photoUrl,
      batchName: (alert.batchId && batchNames.get(alert.batchId)) || 'No batch',
      group,
    });
  }
  cards.sort((a, b) => b.alert.detectedAt.localeCompare(a.alert.detectedAt));
  const groups: AlertGroup[] = GROUP_ORDER.map((key) => ({
    key,
    items: cards.filter((card) => card.group === key),
  }));
  const atRisk = new Set(
    cards.filter((card) => card.group !== 'improving').map((card) => card.studentId),
  );
  const cutoff = weekAgo(today);
  return {
    groups,
    stats: {
      studentsAtRisk: atRisk.size,
      alertsThisWeek: cards.filter((card) => card.alert.detectedAt >= cutoff).length,
      interventionsOpen: interventions.filter((row) => row.outcome === null).length,
    },
    total: cards.length,
  };
}

export const INTERVENTION_KINDS: { key: InterventionKind; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { key: 'call_parent', label: 'Call parent', icon: 'call-outline' },
  { key: 'extra_class', label: 'Extra class', icon: 'school-outline' },
  { key: 'counselling', label: 'Counselling', icon: 'heart-outline' },
  { key: 'other', label: 'Other', icon: 'ellipsis-horizontal-outline' },
];

export const INTERVENTION_OUTCOMES: {
  key: InterventionOutcome;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  tone: Tone;
}[] = [
  { key: 'improved', label: 'Improved', icon: 'trending-up-outline', tone: 'teal' },
  { key: 'unchanged', label: 'Unchanged', icon: 'remove-outline', tone: 'warning' },
  { key: 'escalated', label: 'Escalated', icon: 'arrow-up-circle-outline', tone: 'danger' },
];

export function kindLabel(kind: InterventionKind): string {
  return INTERVENTION_KINDS.find((row) => row.key === kind)?.label ?? 'Other';
}

export function outcomeLabel(outcome: InterventionOutcome | null): string {
  if (!outcome) return 'Open';
  return INTERVENTION_OUTCOMES.find((row) => row.key === outcome)?.label ?? outcome;
}

export function outcomeTone(outcome: InterventionOutcome | null): Tone {
  if (!outcome) return 'accent';
  return INTERVENTION_OUTCOMES.find((row) => row.key === outcome)?.tone ?? 'neutral';
}
