import React, { useState } from 'react';
import { View } from 'react-native';
import type { ID, Intervention } from '@/core/contracts/models';
import { useSession } from '@/core/backend';
import { StudentProfileScreen } from '@/features/students/[id]';
import { useInterventions } from '../hooks';
import { InterventionsSection } from '../components/InterventionsSection';
import { LogInterventionSheet } from '../components/LogInterventionSheet';
import { OutcomeSheet } from '../components/OutcomeSheet';

/**
 * Progress student detail: the Student 360 record plus the Interventions
 * timeline. `autoLog` opens the log sheet immediately (one-tap logging from
 * an alert row).
 */
export function ProgressStudentScreen({
  studentId,
  alertId,
  autoLog,
}: {
  studentId: ID;
  alertId: ID | null;
  autoLog: boolean;
}) {
  const session = useSession();
  const interventions = useInterventions(studentId);
  const [logOpen, setLogOpen] = useState(autoLog);
  const [outcomeFor, setOutcomeFor] = useState<Intervention | null>(null);
  const doneBy = session.data?.profile.fullName ?? '';

  return (
    <View style={{ flex: 1 }}>
      <StudentProfileScreen
        id={studentId}
        backLabel="Progress"
        afterTabs={
          <InterventionsSection
            items={interventions.data ?? []}
            onLog={() => setLogOpen(true)}
            onOutcome={setOutcomeFor}
          />
        }
      />
      <LogInterventionSheet
        visible={logOpen}
        onClose={() => setLogOpen(false)}
        studentId={studentId}
        alertId={alertId}
        defaultDoneBy={doneBy}
        log={interventions.log}
        saving={interventions.saving}
      />
      <OutcomeSheet
        item={outcomeFor}
        onClose={() => setOutcomeFor(null)}
        setOutcome={interventions.setOutcome}
        saving={interventions.saving}
      />
    </View>
  );
}
