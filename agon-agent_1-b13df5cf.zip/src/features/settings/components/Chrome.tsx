import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export function SettingsBack({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <View style={{ gap: 2, marginBottom: S.md }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Back"
        onPress={() => router.back()}
        hitSlop={8}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 44, alignSelf: 'flex-start' }}
      >
        <Ionicons name="chevron-back" size={20} color={C.primary} />
        <Text variant="caption" c={C.primary} weight={700}>
          Settings
        </Text>
      </Pressable>
      <Text variant="h2">{title}</Text>
      {subtitle ? (
        <Text variant="caption" c={C.secondary}>
          {subtitle}
        </Text>
      ) : null}
    </View>
  );
}

export function Group({ children }: { children: React.ReactNode }) {
  return (
    <View
      style={{
        backgroundColor: C.surface,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: C.hairline,
        paddingHorizontal: 6,
        paddingVertical: 4,
      }}
    >
      {children}
    </View>
  );
}
