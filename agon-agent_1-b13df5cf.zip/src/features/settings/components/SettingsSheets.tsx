import React, { useEffect, useState } from 'react';
import { Pressable, View } from 'react-native';

import { Button, Chip, Input, Sheet, Text } from '@/components/ui';
import type { Institute } from '@/core/contracts/models';
import { C, R, S } from '@/lib/theme';
import { BRANDS, NOTIFICATION_TOGGLES, SESSIONS } from '../model';

const BRAND_COLOR: Record<string, string> = {
  navy: C.primary,
  saffron: C.accent,
  teal: C.teal,
  green: C.success,
};

export function ProfileSheet({
  visible,
  institute,
  saving,
  onClose,
  onSave,
}: {
  visible: boolean;
  institute: Institute | null;
  saving: boolean;
  onClose: () => void;
  onSave: (patch: { name: string; city: string; phone: string }) => void;
}) {
  const [name, setName] = useState(institute?.name ?? '');
  const [city, setCity] = useState(institute?.city ?? '');
  const [phone, setPhone] = useState(institute?.phone ?? '');
  useEffect(() => {
    if (!visible) return;
    setName(institute?.name ?? '');
    setCity(institute?.city ?? '');
    setPhone(institute?.phone ?? '');
  }, [visible, institute]);

  return (
    <Sheet visible={visible} onClose={onClose} title="Institute profile" subtitle="Name, city and phone. The join code stays the same.">
      <View style={{ gap: S.md }}>
        <Input label="Institute name" value={name} onChangeText={setName} />
        <Input label="City" value={city} onChangeText={setCity} />
        <Input label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
        <Button title="Save profile" loading={saving} onPress={() => onSave({ name, city, phone })} />
      </View>
    </Sheet>
  );
}

export function SessionSheet({
  visible,
  current,
  saving,
  onClose,
  onSave,
}: {
  visible: boolean;
  current: string | null;
  saving: boolean;
  onClose: () => void;
  onSave: (year: string) => void;
}) {
  const [year, setYear] = useState(current ?? '2026-27');
  useEffect(() => {
    if (visible) setYear(current ?? '2026-27');
  }, [visible, current]);
  return (
    <Sheet visible={visible} onClose={onClose} title="Academic session">
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm, marginBottom: S.lg }}>
        {SESSIONS.map((item) => (
          <Chip key={item} label={item} active={year === item} onPress={() => setYear(item)} />
        ))}
      </View>
      <Button title="Save session" loading={saving} onPress={() => onSave(year)} />
    </Sheet>
  );
}

export function BrandSheet({
  visible,
  current,
  saving,
  onClose,
  onSave,
}: {
  visible: boolean;
  current: string | null;
  saving: boolean;
  onClose: () => void;
  onSave: (id: string) => void;
}) {
  const [picked, setPicked] = useState(current ?? 'navy');
  useEffect(() => {
    if (visible) setPicked(current ?? 'navy');
  }, [visible, current]);
  return (
    <Sheet visible={visible} onClose={onClose} title="Branding colour" subtitle="Used on the institute card. It does not change student records.">
      <View style={{ flexDirection: 'row', gap: S.md, marginBottom: S.lg }}>
        {BRANDS.map((brand) => {
          const on = picked === brand.id;
          return (
            <Pressable key={brand.id} onPress={() => setPicked(brand.id)} style={{ alignItems: 'center', gap: 6 }}>
              <View
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  backgroundColor: BRAND_COLOR[brand.id],
                  borderWidth: on ? 3 : 0,
                  borderColor: C.ink,
                }}
              />
              <Text variant="label" c={on ? C.ink : C.secondary}>
                {brand.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <Button title="Save colour" loading={saving} onPress={() => onSave(picked)} />
    </Sheet>
  );
}

export function NotifySheet({
  visible,
  features,
  saving,
  onClose,
  onSave,
}: {
  visible: boolean;
  features: Record<string, boolean>;
  saving: boolean;
  onClose: () => void;
  onSave: (features: Record<string, boolean>) => void;
}) {
  const [draft, setDraft] = useState(features);
  useEffect(() => {
    if (visible) setDraft(features);
  }, [visible, features]);
  return (
    <Sheet visible={visible} onClose={onClose} title="Notification preferences">
      <View style={{ gap: S.sm, marginBottom: S.lg }}>
        {NOTIFICATION_TOGGLES.map((item) => {
          const on = draft[item.key] !== false;
          return (
            <Pressable
              key={item.key}
              onPress={() => setDraft((current) => ({ ...current, [item.key]: !on }))}
              style={{
                minHeight: 64,
                borderRadius: R.field,
                borderWidth: 1,
                borderColor: C.hairline,
                padding: 12,
                flexDirection: 'row',
                alignItems: 'center',
                gap: S.md,
              }}
            >
              <View style={{ flex: 1 }}>
                <Text weight={700}>{item.title}</Text>
                <Text variant="caption" c={C.secondary}>
                  {item.subtitle}
                </Text>
              </View>
              <Text weight={700} c={on ? C.teal : C.muted}>
                {on ? 'On' : 'Off'}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <Button title="Save preferences" loading={saving} onPress={() => onSave(draft)} />
    </Sheet>
  );
}

export function AboutSheet({ visible, code, onClose }: { visible: boolean; code: string; onClose: () => void }) {
  return (
    <Sheet visible={visible} onClose={onClose} title="About GuruFlow" subtitle="Coaching institute software">
      <Text variant="body">Version 1.0.0</Text>
      <Text variant="caption" c={C.secondary} style={{ marginTop: 8, marginBottom: 16 }}>
        Institute code {code || '—'}. Your students, attendance and fees stay in this institute even if the plan lapses.
      </Text>
      <Button title="Close" variant="outline" onPress={onClose} />
    </Sheet>
  );
}
