import React, { useState } from 'react';
import { View } from 'react-native';

import { Button, Chip, Input, Sheet, Text } from '@/components/ui';
import type { Role } from '@/core/contracts/models';
import { C, S } from '@/lib/theme';
import { INVITE_ROLES, ROLE_LABEL } from '../model';

const CHANGEABLE: Exclude<Role, 'owner'>[] = ['admin', 'teacher', 'parent', 'student'];

export function InviteSheet({
  visible,
  saving,
  link,
  onClose,
  onInvite,
}: {
  visible: boolean;
  saving: boolean;
  link: string | null;
  onClose: () => void;
  onInvite: (role: Exclude<Role, 'owner'>, name: string) => void;
}) {
  const [role, setRole] = useState<Exclude<Role, 'owner'>>('teacher');
  const [name, setName] = useState('');
  return (
    <Sheet visible={visible} onClose={onClose} title="Invite by link" subtitle="Creates an invitation and copies a join URL.">
      <Input label="Name (optional)" value={name} onChangeText={setName} placeholder="Priya Nair" />
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm, marginVertical: S.md }}>
        {INVITE_ROLES.map((item) => (
          <Chip key={item} label={ROLE_LABEL[item]} active={role === item} onPress={() => setRole(item)} />
        ))}
      </View>
      <Button title="Create link and copy" loading={saving} onPress={() => onInvite(role, name)} />
      {link ? (
        <Text variant="caption" c={C.secondary} style={{ marginTop: S.md }}>
          {link}
        </Text>
      ) : null}
    </Sheet>
  );
}

export function RoleSheet({
  visible,
  name,
  current,
  saving,
  onClose,
  onSave,
}: {
  visible: boolean;
  name: string;
  current: Role | null;
  saving: boolean;
  onClose: () => void;
  onSave: (role: Exclude<Role, 'owner'>) => void;
}) {
  const [role, setRole] = useState<Exclude<Role, 'owner'>>(current && current !== 'owner' ? current : 'teacher');
  return (
    <Sheet visible={visible} onClose={onClose} title="Change role" subtitle={`${name}. Only an owner can do this — the server refuses anyone else.`}>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm, marginBottom: S.lg }}>
        {CHANGEABLE.map((item) => (
          <Chip key={item} label={ROLE_LABEL[item]} active={role === item} onPress={() => setRole(item)} />
        ))}
      </View>
      <Button title="Save role" loading={saving} onPress={() => onSave(role)} />
    </Sheet>
  );
}
