import { Platform } from 'react-native';

export async function copyText(text: string): Promise<boolean> {
  try {
    const clipboard = (globalThis as { navigator?: { clipboard?: { writeText: (value: string) => Promise<void> } } }).navigator?.clipboard;
    if (clipboard?.writeText) {
      await clipboard.writeText(text);
      return true;
    }
  } catch {
    return false;
  }
  return false;
}

interface WebAnchor {
  href: string;
  download: string;
  style: { display: string };
  click(): void;
  remove(): void;
}
interface WebGlobals {
  document: { createElement(tag: 'a' | 'input'): WebAnchor & { type?: string; accept?: string; onchange?: (() => void) | null; files?: { item(i: number): { text(): Promise<string> } | null } }; body: { appendChild(node: WebAnchor): void } };
  URL: { createObjectURL(blob: unknown): string; revokeObjectURL(url: string): void };
  Blob: new (parts: string[], options: { type: string }) => unknown;
}

export async function deliverText(filename: string, text: string, mime: string): Promise<'downloaded' | 'shared' | 'saved'> {
  if (Platform.OS === 'web') {
    const web = globalThis as unknown as WebGlobals;
    const url = web.URL.createObjectURL(new web.Blob([text], { type: `${mime};charset=utf-8` }));
    const anchor = web.document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = 'none';
    web.document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => web.URL.revokeObjectURL(url), 10_000);
    return 'downloaded';
  }
  const [{ File, Paths }, Sharing] = await Promise.all([import('expo-file-system'), import('expo-sharing')]);
  const file = new File(Paths.cache, filename);
  file.create({ overwrite: true });
  file.write(text);
  if (!(await Sharing.isAvailableAsync())) return 'saved';
  await Sharing.shareAsync(file.uri, { mimeType: mime, dialogTitle: filename });
  return 'shared';
}

export function pickJsonFile(): Promise<string | null> {
  if (Platform.OS !== 'web') return Promise.resolve(null);
  const web = globalThis as unknown as WebGlobals;
  return new Promise((resolve) => {
    const input = web.document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.style.display = 'none';
    input.onchange = () => {
      const file = input.files?.item(0);
      input.remove();
      if (!file) {
        resolve(null);
        return;
      }
      void file.text().then(resolve);
    };
    web.document.body.appendChild(input);
    input.click();
  });
}
