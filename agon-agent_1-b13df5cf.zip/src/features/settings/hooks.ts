import { useCallback, useEffect, useMemo, useState } from 'react';

import {
  toast,
  useBackend,
  useDecideLeave,
  useInstitute,
  useInvitations,
  useMemberships,
  usePendingLeaveRequests,
  useSubscription,
} from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import type { ExportKind, LeaveRequest, Membership, Profile, Role } from '@/core/contracts/models';
import { writesRestricted } from '@/core/contracts/subscription';
import { queryCache } from '@/core/hooks/cache';
import { useDomainQuery } from '@/core/hooks/domain';
import { copyText, deliverText, pickJsonFile } from './deliver';
import { absoluteJoinUrl, staffPresence, todayIso } from './model';

export function useSettingsHome() {
  const institute = useInstitute();
  const billing = useSubscription();
  const shown = billing.data?.subscription ?? billing.data?.latest ?? null;
  const plan = billing.data?.plan ?? null;
  return {
    institute,
    billing,
    shown,
    plan,
    restricted: writesRestricted(shown?.status),
    pillStatus: shown?.status ?? null,
  };
}

export function useStaffDesk() {
  const { backend, instituteId } = useBackend();
  const members = useMemberships({ limit: 80 });
  const invitations = useInvitations({ limit: 40 });
  const leave = usePendingLeaveRequests();
  const decide = useDecideLeave();
  const institute = useInstitute();
  const mine = useDomainQuery('memberships', ['mine'], (b, i) => b.memberships.getMine(i));
  const history = useDomainQuery<LeaveRequest[]>('leaveRequests', ['all'], (b, i) => b.leaveRequests.list(i, { limit: 80 }).then((page) => page.items));
  const [profiles, setProfiles] = useState<Record<string, Profile | null>>({});
  const [link, setLink] = useState<string | null>(null);
  const isOwner = mine.data?.role === 'owner' && mine.data.status === 'active';
  const rows = members.data?.items ?? [];

  useEffect(() => {
    if (!instituteId || rows.length === 0) return;
    let cancelled = false;
    void Promise.all(
      rows.map(async (member) => {
        try {
          return [member.userId, await backend.auth.getProfile(instituteId, member.userId)] as const;
        } catch {
          return [member.userId, null] as const;
        }
      }),
    ).then((pairs) => {
      if (cancelled) return;
      setProfiles(Object.fromEntries(pairs));
    });
    return () => {
      cancelled = true;
    };
  }, [backend, instituteId, rows]);

  const invite = useCallback(
    async (role: Exclude<Role, 'owner'>, fullName: string) => {
      const code = institute.data?.code;
      if (!code) {
        toast.error('Institute code is not ready yet');
        return null;
      }
      const result = await invitations.invite({ role, fullName: fullName.trim() || null });
      if (!result.ok) return null;
      const url = absoluteJoinUrl(code, result.data.token);
      const copied = await copyText(url);
      setLink(url);
      toast.success(copied ? 'Join link copied' : 'Join link ready');
      return url;
    },
    [institute.data?.code, invitations],
  );

  const changeRole = useCallback(
    async (id: string, role: Role) => {
      const result = await members.setRole({ id, role });
      return result.ok;
    },
    [members],
  );

  const attendance = useMemo(() => {
    const today = todayIso();
    return rows
      .filter((member) => member.role === 'teacher' || member.role === 'admin' || member.role === 'owner')
      .filter((member) => member.status === 'active')
      .map((member) => ({
        member,
        name: profiles[member.userId]?.fullName ?? 'Staff member',
        presence: staffPresence(history.data ?? [], member.userId, today),
      }));
  }, [history.data, profiles, rows]);

  return {
    members,
    invitations,
    leave,
    decide,
    profiles,
    isOwner,
    link,
    setLink,
    invite,
    changeRole,
    attendance,
    saving: members.saving || invitations.saving || decide.loading,
  };
}

export function useBillingDesk() {
  const { backend, instituteId } = useBackend();
  const billing = useSubscription();
  const [used, setUsed] = useState<number | null>(null);

  const reloadUsed = useCallback(async () => {
    if (!instituteId) return;
    const page = await backend.students.list(instituteId, { limit: 1, where: { status: 'active' } });
    setUsed(page.total ?? page.items.length);
  }, [backend, instituteId]);

  useEffect(() => {
    void reloadUsed();
  }, [reloadUsed, billing.data?.subscription?.id, billing.data?.subscription?.status]);

  const shown = billing.data?.subscription ?? billing.data?.latest ?? null;
  return { billing, used, shown, restricted: writesRestricted(shown?.status), reloadUsed };
}

export function useBackupDesk() {
  const { backend, instituteId } = useBackend();
  const [last, setLast] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    if (!instituteId) return;
    setLast(await backend.exports.lastBackupAt(instituteId));
  }, [backend, instituteId]);

  useEffect(() => {
    void refresh().catch((cause) => setError(toBackendError(cause).message));
  }, [refresh]);

  const run = useCallback(
    async (key: string, work: () => Promise<void>) => {
      if (!instituteId) return;
      setBusy(key);
      setError(null);
      try {
        await work();
        await refresh();
      } catch (cause) {
        const message = toBackendError(cause).message;
        setError(message);
        toast.error(message);
      } finally {
        setBusy(null);
      }
    },
    [instituteId, refresh],
  );

  const exportCsv = (kind: Extract<ExportKind, 'students' | 'attendance' | 'fees'>) =>
    run(kind, async () => {
      const file = await backend.exports.render(instituteId ?? '', { kind, format: 'csv' });
      const outcome = await deliverText(file.filename, file.body, file.mime);
      toast.success(outcome === 'downloaded' ? `${file.filename} downloaded` : 'Export ready');
    });

  const exportJson = () =>
    run('json', async () => {
      const json = await backend.exports.exportBundle(instituteId ?? '');
      const outcome = await deliverText('guruflow-backup.json', json, 'application/json');
      toast.success(outcome === 'downloaded' ? 'Full backup downloaded' : 'Full backup ready');
    });

  const importJson = (json: string) =>
    run('import', async () => {
      const result = await backend.exports.importBundle(instituteId ?? '', json);
      await queryCache.invalidate([`${backend.name}|`]);
      toast.success(`Restored ${result.restored} records`);
    });

  const importFile = () =>
    run('import', async () => {
      const json = await pickJsonFile();
      if (!json) {
        toast.error('Choose the JSON backup on this device, or paste it below.');
        return;
      }
      const result = await backend.exports.importBundle(instituteId ?? '', json);
      await queryCache.invalidate([`${backend.name}|`]);
      toast.success(`Restored ${result.restored} records`);
    });

  const clearAll = () =>
    run('clear', async () => {
      await backend.exports.clearAll(instituteId ?? '', 'CLEAR');
      await queryCache.invalidate([`${backend.name}|`]);
      toast.success('Operational data cleared. The institute account is still here.');
    });

  return { last, busy, error, refresh, exportCsv, exportJson, importJson, importFile, clearAll };
}

export type StaffMember = Membership;
