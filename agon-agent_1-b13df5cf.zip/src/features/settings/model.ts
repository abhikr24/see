import type { LeaveRequest, Role } from '@/core/contracts/models';
import { CLEAR_DATA_PHRASE } from '@/core/contracts/backup';

export { CLEAR_DATA_PHRASE };

export const STAFF_ROLES: Role[] = ['owner', 'admin', 'teacher'];

export const INVITE_ROLES: Exclude<Role, 'owner'>[] = ['teacher', 'admin', 'parent', 'student'];

export const ROLE_LABEL: Record<Role, string> = {
  owner: 'Owner',
  admin: 'Admin',
  teacher: 'Teacher',
  student: 'Student',
  parent: 'Parent',
};

export const SESSIONS = ['2025-26', '2026-27', '2027-28'] as const;

export const BRANDS = [
  { id: 'navy', label: 'Navy' },
  { id: 'saffron', label: 'Saffron' },
  { id: 'teal', label: 'Teal' },
  { id: 'green', label: 'Green' },
] as const;

export const NOTIFICATION_TOGGLES = [
  { key: 'noticeAlerts', title: 'Notice alerts', subtitle: 'In-app alerts when a notice is published' },
  { key: 'homeworkAlerts', title: 'Homework alerts', subtitle: 'Tell families about new homework' },
  { key: 'attendanceAlerts', title: 'Attendance alerts', subtitle: 'Flag low attendance for the family' },
  { key: 'showMarksToParents', title: 'Marks for parents', subtitle: 'Parents can see published marks' },
] as const;

export const SUPPORT = {
  videos: 'https://www.youtube.com/results?search_query=coaching+institute+app+tutorial',
  whatsapp: 'https://wa.me/918800120034?text=Hi%20GuruFlow%20support',
  phone: 'tel:+918800120034',
} as const;

export function joinPath(code: string, token: string): string {
  return `/join?code=${encodeURIComponent(code)}&token=${encodeURIComponent(token)}`;
}

export function absoluteJoinUrl(code: string, token: string): string {
  const path = joinPath(code, token);
  const origin = typeof globalThis !== 'undefined' ? (globalThis as { location?: { origin?: string } }).location?.origin : undefined;
  if (origin) return `${origin}${path}`;
  return `guruflow://join?code=${encodeURIComponent(code)}&token=${encodeURIComponent(token)}`;
}

export function parseJoinUrl(url: string): { code: string; token: string } | null {
  const query = url.includes('?') ? url.slice(url.indexOf('?') + 1) : '';
  const params = new URLSearchParams(query);
  const code = params.get('code');
  const token = params.get('token');
  if (!code || !token) return null;
  return { code, token };
}

export function coversToday(request: LeaveRequest, today: string): boolean {
  return request.status === 'approved' && request.fromDate <= today && request.toDate >= today;
}

export function staffPresence(requests: LeaveRequest[], userId: string, today: string): 'On leave' | 'Present' {
  return requests.some((request) => request.userId === userId && coversToday(request, today)) ? 'On leave' : 'Present';
}

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function invoiceText(input: { number: string; amount: string; issued: string; status: string; period: string; vpa: string }): string {
  return [
    'GuruFlow invoice',
    input.number,
    input.period,
    `Issued ${input.issued}`,
    `Amount ${input.amount}`,
    `Status ${input.status}`,
    `Pay via UPI ${input.vpa}`,
  ].join('\n');
}
