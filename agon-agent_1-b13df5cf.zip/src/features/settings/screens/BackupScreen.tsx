import React, { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Linking from 'expo-linking';

import { Button, ConfirmDialog, IconBox, Input, ListRow, Text } from '@/components/ui';
import { dateLong, relTime } from '@/lib/format';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { SettingsBack, Group } from '../components/Chrome';
import { useBackupDesk } from '../hooks';
import { CLEAR_DATA_PHRASE, SUPPORT } from '../model';

export function BackupScreen() {
  const desk = useBackupDesk();
  const [confirm, setConfirm] = useState(false);
  const [paste, setPaste] = useState('');

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.canvas }} contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 136, gap: S.lg }}>
      <SettingsBack title="Backup and data" subtitle="Take a copy before you clear anything" />

      <View style={{ backgroundColor: C.teal, borderRadius: 24, padding: 20, gap: 6 }}>
        <Text variant="label" c={C.surface}>
          Backup status
        </Text>
        <Text variant="h2" c={C.surface}>
          {desk.last ? relTime(desk.last) : 'No backup yet'}
        </Text>
        <Text variant="caption" c={C.surface}>
          {desk.last ? `Last backup ${dateLong(desk.last)}` : 'Export the full JSON to record a backup.'}
        </Text>
      </View>

      <Group>
        <ListRow title="Students CSV" subtitle="Names, admission numbers, status" leading={<IconBox name="people-outline" />} right={<Ionicons name="download-outline" size={20} color={C.primary} />} onPress={() => void desk.exportCsv('students')} />
        <ListRow title="Attendance CSV" subtitle="Date, batch, student and status" leading={<IconBox name="checkbox-outline" tone="teal" />} right={<Ionicons name="download-outline" size={20} color={C.primary} />} onPress={() => void desk.exportCsv('attendance')} divider />
        <ListRow title="Fee records CSV" subtitle="Terms, amounts and dues" leading={<IconBox name="wallet-outline" tone="accent" />} right={<Ionicons name="download-outline" size={20} color={C.primary} />} onPress={() => void desk.exportCsv('fees')} divider />
        <ListRow title="Full JSON" subtitle="The file you can import again" leading={<IconBox name="document-text-outline" />} right={<Ionicons name="download-outline" size={20} color={C.primary} />} onPress={() => void desk.exportJson()} divider />
      </Group>

      <Button title={desk.busy === 'import' ? 'Importing…' : 'Import JSON backup'} variant="outline" icon="cloud-download-outline" onPress={() => void desk.importFile()} />
      <Input label="Or paste a backup" value={paste} onChangeText={setPaste} placeholder="Paste the full JSON" multiline />
      <Button title="Re-import pasted JSON" variant="secondary" disabled={!paste.trim()} onPress={() => void desk.importJson(paste.trim())} />
      {desk.error ? (
        <Text variant="caption" c={C.danger}>
          {desk.error}
        </Text>
      ) : null}

      <View style={{ backgroundColor: C.dangerSoft, borderRadius: R.card, padding: 16, gap: S.sm }}>
        <Text weight={800} c={C.danger}>
          Danger zone
        </Text>
        <Text variant="caption" c={C.danger}>
          Clear all data removes students, attendance, fees and content. The institute and owner login stay. Type {CLEAR_DATA_PHRASE} to confirm.
        </Text>
        <Button title="Clear all data" variant="danger" onPress={() => setConfirm(true)} />
      </View>

      <Text variant="title" weight={800}>Help</Text>
      <Group>
        <ListRow title="Watch videos" subtitle="Short lessons in the browser" leading={<IconBox name="play-circle-outline" tone="accent" />} chevron onPress={() => void Linking.openURL(SUPPORT.videos)} divider />
        <ListRow title="WhatsApp support" subtitle="Message the GuruFlow desk" leading={<IconBox name="logo-whatsapp" tone="teal" />} chevron onPress={() => void Linking.openURL(SUPPORT.whatsapp)} divider />
        <ListRow title="Call us" subtitle="Speak to support" leading={<IconBox name="call-outline" />} chevron onPress={() => void Linking.openURL(SUPPORT.phone)} />
      </Group>
      <Pressable onPress={() => void Linking.openURL(SUPPORT.phone)} style={{ minHeight: 8 }} />

      <ConfirmDialog
        visible={confirm}
        title="Clear all data"
        description="Students, attendance, fees and content will be removed. The institute account stays. This cannot be undone."
        confirmText={CLEAR_DATA_PHRASE}
        confirmLabel="Clear all data"
        onCancel={() => setConfirm(false)}
        onConfirm={() => {
          setConfirm(false);
          void desk.clearAll();
        }}
      />
    </ScrollView>
  );
}
