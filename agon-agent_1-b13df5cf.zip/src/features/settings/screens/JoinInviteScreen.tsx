import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';

import { Badge, Button, Card, ErrorState, Text } from '@/components/ui';
import { toast, useBackend } from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import type { Institute } from '@/core/contracts/models';
import { C, LAYOUT, S } from '@/lib/theme';
import { ROLE_LABEL } from '../model';

export function JoinInviteScreen() {
  const params = useLocalSearchParams<{ code?: string; token?: string }>();
  const { backend, setInstituteId } = useBackend();
  const [institute, setInstitute] = useState<Institute | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const code = typeof params.code === 'string' ? params.code : '';
  const token = typeof params.token === 'string' ? params.token : '';

  useEffect(() => {
    if (!code) return;
    let cancelled = false;
    void backend.institutes.findByCode(null, code).then((found) => {
      if (!cancelled) setInstitute(found);
      if (!cancelled && !found) setError('No institute uses that code.');
    });
    return () => {
      cancelled = true;
    };
  }, [backend, code]);

  const accept = async () => {
    if (!institute || !token) return;
    setBusy(true);
    setError(null);
    try {
      const session = await backend.auth.getSession(null);
      if (!session) {
        router.push('/(auth)/login' as never);
        toast.error('Sign in, then open the link again.');
        return;
      }
      setInstituteId(institute.id);
      const membership = await backend.invitations.accept(institute.id, token);
      setDone(membership.role);
      toast.success(`Joined as ${ROLE_LABEL[membership.role]}`);
    } catch (cause) {
      setError(toBackendError(cause).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin, justifyContent: 'center' }}>
      <Card>
        <Text variant="label" c={C.muted}>
          Join link
        </Text>
        <Text variant="h2" style={{ marginTop: 4 }}>
          {institute?.name ?? 'Looking up the institute…'}
        </Text>
        <Text variant="caption" c={C.secondary} style={{ marginTop: 4, marginBottom: S.md }}>
          {institute ? `${institute.city ?? ''} · ${institute.code}` : code || 'Missing code'}
        </Text>
        {done ? <Badge label={ROLE_LABEL[done as keyof typeof ROLE_LABEL] ?? done} tone="success" /> : null}
        {error ? <ErrorState message={error} onRetry={() => void accept()} /> : null}
        <View style={{ marginTop: S.lg, gap: S.sm }}>
          <Button title={done ? 'Go to home' : 'Accept invite'} loading={busy} onPress={() => (done ? router.replace('/' as never) : void accept())} />
          <Button title="Not now" variant="outline" onPress={() => router.replace('/' as never)} />
        </View>
      </Card>
    </View>
  );
}
