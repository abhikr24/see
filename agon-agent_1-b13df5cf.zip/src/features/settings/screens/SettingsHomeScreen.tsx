import React, { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Avatar, Badge, ErrorState, IconBox, ListRow, ListSkeleton, Text } from '@/components/ui';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { subscriptionPill } from '@/core/contracts/subscription';
import { C, LAYOUT, R, S, SHADOW } from '@/lib/theme';
import { Group } from '../components/Chrome';
import { AboutSheet, BrandSheet, NotifySheet, ProfileSheet, SessionSheet } from '../components/SettingsSheets';
import { useSettingsHome } from '../hooks';

type SheetKey = 'profile' | 'session' | 'brand' | 'notify' | 'about' | null;

const BRAND_COLOR: Record<string, string> = {
  navy: C.primary,
  saffron: C.accent,
  teal: C.teal,
  green: C.success,
};

export function SettingsHomeScreen() {
  const home = useSettingsHome();
  const { signOut, loading: signingOut } = useAuth();
  const [sheet, setSheet] = useState<SheetKey>(null);
  const institute = home.institute.data;
  const pill = subscriptionPill(home.pillStatus);
  const brand = BRAND_COLOR[institute?.settings.brandColor ?? 'navy'] ?? C.primary;

  if (home.institute.loading && !institute) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}>
        <ListSkeleton rows={6} />
      </View>
    );
  }
  if (home.institute.error && !institute) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState message={home.institute.error.message} onRetry={() => void home.institute.refetch()} />
      </View>
    );
  }

  const saveProfile = (patch: { name: string; city: string; phone: string }) => {
    void home.institute.update({ name: patch.name.trim(), city: patch.city.trim() || null, phone: patch.phone.trim() || null }).then((result) => {
      if (result.ok) setSheet(null);
    });
  };

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: C.canvas }}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: 136, gap: S.lg }}
    >
      <Text variant="h2">Settings</Text>
      <View style={{ backgroundColor: C.surface, borderRadius: R.card, padding: 16, borderWidth: 1, borderColor: C.hairline, ...SHADOW }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.md }}>
          <View style={{ borderRadius: 36, borderWidth: 3, borderColor: brand }}>
            <Avatar name={institute?.name ?? 'Institute'} uri={institute?.logoUrl} size={64} />
          </View>
          <View style={{ flex: 1, gap: 2 }}>
            <Text variant="title" weight={800} numberOfLines={2}>
              {institute?.name ?? 'Institute'}
            </Text>
            <Text variant="caption" c={C.secondary}>
              {institute?.city ?? 'City not set'}
            </Text>
            <Badge label={institute?.code ?? '—'} tone="primary" small />
          </View>
          <Pressable accessibilityRole="button" onPress={() => setSheet('profile')} hitSlop={8} style={{ minHeight: 44, justifyContent: 'center' }}>
            <Text weight={700} c={C.primary}>
              Edit
            </Text>
          </Pressable>
        </View>
      </View>

      {home.restricted ? (
        <View style={{ backgroundColor: C.warningSoft, borderRadius: R.field, padding: 14 }}>
          <Text weight={700} c={C.duesInk}>
            Plan paused. Your students, attendance and fees are still here.
          </Text>
          <Text variant="caption" c={C.duesInk} style={{ marginTop: 4 }}>
            Renew to invite staff and admit students. Nothing was deleted.
          </Text>
        </View>
      ) : null}

      <Group>
        <ListRow title="Institute profile" subtitle="Name, city and phone" leading={<IconBox name="business-outline" />} chevron onPress={() => setSheet('profile')} divider />
        <ListRow title="Academic session" subtitle={institute?.settings.academicYear ?? 'Not set'} leading={<IconBox name="calendar-outline" tone="teal" />} chevron onPress={() => setSheet('session')} divider />
        <ListRow title="Branding colour" subtitle={institute?.settings.brandColor ?? 'Navy'} leading={<IconBox name="color-palette-outline" tone="accent" />} chevron onPress={() => setSheet('brand')} divider />
        <ListRow title="Notification preferences" subtitle="Notices, homework, attendance, marks" leading={<IconBox name="notifications-outline" />} chevron onPress={() => setSheet('notify')} divider />
        <ListRow title="Staff and permissions" subtitle="Roles, invite links and leave" leading={<IconBox name="people-outline" tone="teal" />} chevron onPress={() => router.push('/(owner)/settings/staff' as never)} divider />
        <ListRow title="Backup and data" subtitle="Export, import and clear" leading={<IconBox name="cloud-upload-outline" />} chevron onPress={() => router.push('/(owner)/settings/backup' as never)} />
      </Group>

      <Group>
        <ListRow
          title="Subscription"
          subtitle={home.plan?.name ?? 'No plan'}
          leading={<IconBox name="card-outline" />}
          right={<Badge label={pill.label} tone={pill.tone} small />}
          chevron
          onPress={() => router.push('/(owner)/settings/subscription' as never)}
          divider
        />
        <ListRow title="Help and support" subtitle="Videos, WhatsApp and a phone call" leading={<IconBox name="help-circle-outline" tone="teal" />} chevron onPress={() => router.push('/(owner)/settings/backup' as never)} divider />
        <ListRow title="About" subtitle="GuruFlow 1.0.0" leading={<IconBox name="information-circle-outline" />} chevron onPress={() => setSheet('about')} />
      </Group>

      <Pressable
        accessibilityRole="button"
        onPress={() => void signOut()}
        disabled={signingOut}
        style={{ minHeight: 56, borderRadius: R.card, backgroundColor: C.dangerSoft, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 }}
      >
        <Ionicons name="log-out-outline" size={18} color={C.danger} />
        <Text weight={700} c={C.danger}>
          {signingOut ? 'Signing out…' : 'Sign out'}
        </Text>
      </Pressable>

      <ProfileSheet visible={sheet === 'profile'} institute={institute ?? null} saving={home.institute.saving} onClose={() => setSheet(null)} onSave={saveProfile} />
      <SessionSheet
        visible={sheet === 'session'}
        current={institute?.settings.academicYear ?? null}
        saving={home.institute.saving}
        onClose={() => setSheet(null)}
        onSave={(year) => {
          void home.institute.updateSettings({ academicYear: year }).then((result) => {
            if (result.ok) setSheet(null);
          });
        }}
      />
      <BrandSheet
        visible={sheet === 'brand'}
        current={institute?.settings.brandColor ?? null}
        saving={home.institute.saving}
        onClose={() => setSheet(null)}
        onSave={(id) => {
          void home.institute.updateSettings({ brandColor: id }).then((result) => {
            if (result.ok) setSheet(null);
          });
        }}
      />
      <NotifySheet
        visible={sheet === 'notify'}
        features={institute?.settings.features ?? {}}
        saving={home.institute.saving}
        onClose={() => setSheet(null)}
        onSave={(features) => {
          void home.institute.updateSettings({ features }).then((result) => {
            if (result.ok) setSheet(null);
          });
        }}
      />
      <AboutSheet visible={sheet === 'about'} code={institute?.code ?? ''} onClose={() => setSheet(null)} />
    </ScrollView>
  );
}
