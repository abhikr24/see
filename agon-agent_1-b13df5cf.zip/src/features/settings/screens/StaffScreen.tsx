import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';

import { Avatar, Badge, Button, EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { Membership, Role } from '@/core/contracts/models';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { SettingsBack } from '../components/Chrome';
import { InviteSheet, RoleSheet } from '../components/StaffSheets';
import { useStaffDesk } from '../hooks';
import { ROLE_LABEL, STAFF_ROLES } from '../model';

const TONE: Record<Role, 'primary' | 'accent' | 'teal' | 'neutral' | 'warning'> = {
  owner: 'primary',
  admin: 'accent',
  teacher: 'teal',
  student: 'neutral',
  parent: 'warning',
};

export function StaffScreen() {
  const desk = useStaffDesk();
  const [filter, setFilter] = useState<'staff' | 'all'>('staff');
  const [inviteOpen, setInviteOpen] = useState(false);
  const [target, setTarget] = useState<Membership | null>(null);
  const rows = desk.members.data?.items ?? [];
  const visible = useMemo(
    () => rows.filter((member) => (filter === 'staff' ? STAFF_ROLES.includes(member.role) : true)),
    [filter, rows],
  );
  const pendingLeave = desk.leave.data ?? [];

  if (desk.members.loading && !desk.members.data) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}>
        <ListSkeleton rows={6} />
      </View>
    );
  }
  if (desk.members.error && !desk.members.data) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState message={desk.members.error.message} onRetry={() => void desk.members.refetch()} />
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.canvas }} contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 136 }}>
      <SettingsBack title="Staff" subtitle="Memberships, invite links and leave" />
      <Button title="Invite by link" icon="link-outline" onPress={() => setInviteOpen(true)} />
      <View style={{ flexDirection: 'row', gap: S.sm, marginVertical: S.md }}>
        <Pressable onPress={() => setFilter('staff')}><Badge label="Staff" tone={filter === 'staff' ? 'primary' : 'neutral'} /></Pressable>
        <Pressable onPress={() => setFilter('all')}><Badge label="All memberships" tone={filter === 'all' ? 'primary' : 'neutral'} /></Pressable>
      </View>

      {visible.length === 0 ? <EmptyState title="No members yet" text="Invite a teacher with a join link." icon="people-outline" /> : null}
      <View style={{ gap: S.sm }}>
        {visible.map((member) => {
          const name = desk.profiles[member.userId]?.fullName ?? 'Member';
          return (
            <Pressable
              key={member.id}
              onPress={() => {
                if (desk.isOwner && member.role !== 'owner') setTarget(member);
              }}
              style={{ backgroundColor: C.surface, borderRadius: R.card, padding: 14, flexDirection: 'row', alignItems: 'center', gap: S.md, borderWidth: 1, borderColor: C.hairline }}
            >
              <Avatar name={name} uri={desk.profiles[member.userId]?.avatarUrl} size={44} />
              <View style={{ flex: 1 }}>
                <Text weight={700}>{name}</Text>
                <Text variant="caption" c={C.secondary}>
                  {member.status === 'pending' ? 'Waiting for approval' : desk.isOwner && member.role !== 'owner' ? 'Tap to change role' : 'Role is fixed here'}
                </Text>
              </View>
              <Badge label={ROLE_LABEL[member.role]} tone={TONE[member.role]} small />
            </Pressable>
          );
        })}
      </View>

      <Text variant="title" weight={800} style={{ marginTop: S.xl, marginBottom: S.sm }}>
        Open invite links
      </Text>
      {(desk.invitations.data?.items ?? []).filter((item) => item.status === 'pending').length === 0 ? (
        <Text variant="caption" c={C.secondary}>No pending invitations.</Text>
      ) : (
        (desk.invitations.data?.items ?? [])
          .filter((item) => item.status === 'pending')
          .map((item) => (
            <Text key={item.id} variant="body" style={{ marginBottom: 6 }}>
              {item.fullName || 'Link invite'} · {ROLE_LABEL[item.role]}
            </Text>
          ))
      )}

      <Text variant="title" weight={800} style={{ marginTop: S.xl, marginBottom: S.sm }}>
        Staff attendance
      </Text>
      {desk.attendance.map((row) => (
        <View key={row.member.id} style={{ flexDirection: 'row', alignItems: 'center', minHeight: 48, gap: S.md }}>
          <Text style={{ flex: 1 }}>{row.name}</Text>
          <Badge label={row.presence} tone={row.presence === 'On leave' ? 'warning' : 'success'} small />
        </View>
      ))}

      <Text variant="title" weight={800} style={{ marginTop: S.xl, marginBottom: S.sm }}>
        Leave approvals
      </Text>
      {pendingLeave.length === 0 ? (
        <EmptyState title="No leave waiting" text="Teacher leave requests show up here for approve or reject." icon="calendar-outline" />
      ) : (
        pendingLeave.map((request) => (
          <View key={request.id} style={{ backgroundColor: C.surface, borderRadius: R.card, padding: 14, marginBottom: S.sm, borderWidth: 1, borderColor: C.hairline, gap: S.sm }}>
            <Text weight={700}>{request.leaveType} leave</Text>
            <Text variant="caption" c={C.secondary}>
              {request.fromDate} to {request.toDate} · {request.reason}
            </Text>
            <View style={{ flexDirection: 'row', gap: S.sm }}>
              <View style={{ flex: 1 }}>
                <Button title="Reject" variant="outline" size="sm" onPress={() => void desk.decide.mutate({ id: request.id, status: 'rejected' }).then(() => desk.leave.refetch())} />
              </View>
              <View style={{ flex: 1 }}>
                <Button title="Approve" size="sm" onPress={() => void desk.decide.mutate({ id: request.id, status: 'approved' }).then(() => desk.leave.refetch())} />
              </View>
            </View>
          </View>
        ))
      )}

      <InviteSheet
        visible={inviteOpen}
        saving={desk.saving}
        link={desk.link}
        onClose={() => setInviteOpen(false)}
        onInvite={(role, name) => void desk.invite(role, name)}
      />
      <RoleSheet
        visible={target != null}
        name={target ? desk.profiles[target.userId]?.fullName ?? 'Member' : ''}
        current={target?.role ?? null}
        saving={desk.saving}
        onClose={() => setTarget(null)}
        onSave={(role) => {
          if (!target) return;
          void desk.changeRole(target.id, role).then((ok) => {
            if (ok) setTarget(null);
          });
        }}
      />
    </ScrollView>
  );
}
