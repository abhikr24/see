import React, { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Button, ConfirmDialog, ErrorState, ListSkeleton, ProgressBar, Sheet, Text } from '@/components/ui';
import { nextPlan, usageHelper, usageLabel, usageRatio } from '@/core/contracts/subscription';
import { dateShort, inr } from '@/lib/format';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { deliverText } from '../deliver';
import { SettingsBack } from '../components/Chrome';
import { useBillingDesk } from '../hooks';
import { invoiceText } from '../model';

export function SubscriptionScreen() {
  const desk = useBillingDesk();
  const [upgrade, setUpgrade] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const billing = desk.billing.data;
  const shown = desk.shown;
  const plan = billing?.plan ?? null;
  const cap = plan?.maxStudents ?? null;
  const used = desk.used ?? 0;
  const renewal = shown?.currentPeriodEnd ?? shown?.trialEndsAt ?? shown?.cancelAt ?? null;
  const price = shown?.billingCycle === 'yearly' ? plan?.priceYearly : plan?.priceMonthly;
  const higher = nextPlan(billing?.plans ?? [], cap);

  if (desk.billing.loading && !billing) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}>
        <ListSkeleton rows={5} />
      </View>
    );
  }
  if (desk.billing.error && !billing) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState message={desk.billing.error.message} onRetry={() => void desk.billing.refetch()} />
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: C.canvas }} contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 136, gap: S.lg }}>
      <SettingsBack title="Subscription" subtitle="Plan, usage and invoices" />

      <View style={{ backgroundColor: C.primary, borderRadius: 24, padding: 20, gap: 6 }}>
        <Text variant="label" c={C.navyPale}>
          {shown?.status === 'trialing' ? 'Trial' : 'Current plan'}
        </Text>
        <Text variant="h2" c={C.surface}>
          {plan?.name ?? 'No plan'}
        </Text>
        <Text variant="title" c={C.surface} weight={700}>
          {price != null ? `${inr(price)} / ${shown?.billingCycle === 'yearly' ? 'year' : 'month'}` : '—'}
        </Text>
        <Text variant="caption" c={C.navyPale}>
          {desk.restricted ? 'Paused — your data is safe' : `Renews ${dateShort(renewal)}`}
        </Text>
        <View style={{ marginTop: S.md }}>
          <Button title="Upgrade" variant="secondary" onPress={() => setUpgrade(true)} />
        </View>
      </View>

      <View style={{ backgroundColor: C.surface, borderRadius: R.card, padding: 18, borderWidth: 1, borderColor: C.hairline, gap: 8 }}>
        <Text variant="title" weight={800}>
          {usageLabel(used, cap)}
        </Text>
        <ProgressBar value={usageRatio(used, cap)} tone={usageRatio(used, cap) >= 80 ? 'warning' : 'primary'} height={10} />
        <Text variant="caption" c={C.warning}>
          {usageHelper(used, cap)}
        </Text>
      </View>

      <View style={{ backgroundColor: C.surface, borderRadius: R.card, padding: 16, borderWidth: 1, borderColor: C.hairline, flexDirection: 'row', alignItems: 'center', gap: S.md }}>
        <Ionicons name="phone-portrait-outline" size={22} color={C.primary} />
        <View style={{ flex: 1 }}>
          <Text weight={700}>UPI</Text>
          <Text variant="caption" c={C.secondary}>
            {billing?.method?.vpa ?? 'No UPI ID'} · Autopay {billing?.method?.autopay ? 'on' : 'off'}
          </Text>
        </View>
        <Pressable
          accessibilityRole="switch"
          onPress={() => void desk.billing.setAutopay(!(billing?.method?.autopay ?? false))}
          style={{ minHeight: 44, justifyContent: 'center' }}
        >
          <Text weight={700} c={billing?.method?.autopay ? C.teal : C.muted}>
            {billing?.method?.autopay ? 'On' : 'Off'}
          </Text>
        </Pressable>
      </View>

      <Text variant="title" weight={800}>Invoices</Text>
      {(billing?.invoices ?? []).length === 0 ? (
        <Text variant="caption" c={C.secondary}>No invoices yet.</Text>
      ) : (
        (billing?.invoices ?? []).map((invoice) => (
          <View key={invoice.id} style={{ flexDirection: 'row', alignItems: 'center', minHeight: 56, gap: S.md }}>
            <View style={{ flex: 1 }}>
              <Text weight={700}>{invoice.number}</Text>
              <Text variant="caption" c={C.secondary}>
                {dateShort(invoice.issuedAt)} · {invoice.status}
              </Text>
            </View>
            <Text weight={700}>{inr(invoice.amount)}</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Download ${invoice.number}`}
              hitSlop={8}
              onPress={() =>
                void deliverText(
                  `${invoice.number}.txt`,
                  invoiceText({
                    number: invoice.number,
                    amount: inr(invoice.amount),
                    issued: dateShort(invoice.issuedAt),
                    status: invoice.status,
                    period: invoice.periodLabel,
                    vpa: billing?.method?.vpa ?? '',
                  }),
                  'text/plain',
                )
              }
            >
              <Ionicons name="download-outline" size={22} color={C.primary} />
            </Pressable>
          </View>
        ))
      )}

      <Button title="Cancel plan" variant="outline" onPress={() => setCancelOpen(true)} />
      <Text variant="caption" c={C.secondary}>
        Cancelling pauses non-essential features. Students, attendance and fees are not deleted.
      </Text>

      <Sheet visible={upgrade} onClose={() => setUpgrade(false)} title="Upgrade" subtitle={higher ? `${higher.name} raises the student cap.` : 'You are on the largest plan.'}>
        {(billing?.plans ?? []).map((item) => (
          <View key={item.id} style={{ paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.hairline }}>
            <Text weight={700}>{item.name}</Text>
            <Text variant="caption" c={C.secondary}>
              {item.maxStudents == null ? 'Unlimited students' : `Up to ${item.maxStudents} students`} · {inr(item.priceMonthly)} / month
            </Text>
          </View>
        ))}
        {higher ? (
          <View style={{ marginTop: S.md }}>
            <Button
              title={`Upgrade to ${higher.name}`}
              loading={desk.billing.saving}
              onPress={() => {
                void desk.billing.changePlan({ planId: higher.id, billingCycle: 'monthly' }).then((result) => {
                  if (result.ok) setUpgrade(false);
                });
              }}
            />
          </View>
        ) : null}
      </Sheet>
      <ConfirmDialog
        visible={cancelOpen}
        title="Cancel plan?"
        description="The institute keeps every student, attendance mark and fee. Invites and new admissions pause until you renew."
        confirmLabel="Cancel plan"
        onCancel={() => setCancelOpen(false)}
        onConfirm={() => {
          setCancelOpen(false);
          void desk.billing.cancel();
        }}
      />
    </ScrollView>
  );
}
