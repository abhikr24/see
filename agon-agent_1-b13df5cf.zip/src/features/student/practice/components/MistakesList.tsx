import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import type { MistakeItem } from '../model';

interface Props {
  mistakes: MistakeItem[];
}

export function MistakesList({ mistakes }: Props) {
  if (mistakes.length === 0) {
    return (
      <Card flat style={styles.empty}>
        <Ionicons name="checkmark-done-circle" size={28} color={C.teal} />
        <Text variant="title" weight={700} c={C.ink} style={{ marginTop: 8 }}>
          No mistakes! Perfect attempt.
        </Text>
        <Text variant="caption" c={C.secondary} style={{ marginTop: 4, textAlign: 'center' }}>
          You answered every question correctly. Keep it up!
        </Text>
      </Card>
    );
  }
  return (
    <View style={{ gap: 12 }}>
      <Text variant="title" weight={800} c={C.ink}>
        Mistakes to review ({mistakes.length})
      </Text>
      {mistakes.map((m, idx) => (
        <Card key={m.questionId} flat style={styles.card}>
          <View style={styles.qRow}>
            <View style={styles.idx}>
              <Text variant="label" weight={700} c={C.danger}>
                {idx + 1}
              </Text>
            </View>
            <Text variant="body" weight={600} c={C.ink} style={{ flex: 1 }}>
              {m.questionText}
            </Text>
          </View>
          {m.yourAnswer ? (
            <View style={styles.ansRow}>
              <Text variant="caption" c={C.secondary}>
                Your answer:
              </Text>
              <Text variant="caption" weight={700} c={C.danger}>
                {m.yourAnswer}
              </Text>
            </View>
          ) : (
            <View style={styles.ansRow}>
              <Text variant="caption" c={C.secondary}>
                Skipped
              </Text>
            </View>
          )}
          {m.explanation ? (
            <View style={styles.explBox}>
              <Ionicons name="bulb" size={14} color={C.warning} />
              <Text variant="caption" c={C.ink} style={{ flex: 1, marginLeft: 6 }}>
                {m.explanation}
              </Text>
            </View>
          ) : null}
        </Card>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  empty: {
    padding: 20,
    alignItems: 'center',
    gap: 4,
  },
  card: {
    padding: 14,
    gap: 10,
  },
  qRow: {
    flexDirection: 'row',
    gap: 10,
  },
  idx: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FEECEC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ansRow: {
    flexDirection: 'row',
    gap: 6,
    marginLeft: 34,
  },
  explBox: {
    flexDirection: 'row',
    backgroundColor: '#FEF1D6',
    borderRadius: 10,
    padding: 10,
    marginLeft: 34,
    marginTop: 4,
  },
});
