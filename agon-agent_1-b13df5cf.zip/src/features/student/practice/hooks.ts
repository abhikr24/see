import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useBackend } from '@/core/backend';
import { useQuizzes, useSession } from '@/core/backend';
import type { ID, PracticeQuestion, Quiz, QuizAttempt } from '@/core/contracts/models';
import { useSubjects } from '@/core/backend';
import {
  toQuestionView,
  toQuizCardView,
  computeResultView,
  type PracticeQuestionView,
  type QuizCardView,
  type ChapterOption,
  type AttemptResultView,
} from './model';

// ---------- Chapter picker & attempt list ----------

export function usePracticeBoard() {
  const quizzesQ = useQuizzes({ limit: 50 } as any);
  const subjectsQ = useSubjects({ limit: 50 } as any);
  const { backend, instituteId } = useBackend();
  const sessionQ = useSession();

  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [loadingAttempts, setLoadingAttempts] = useState(false);

  const subjectMap = useMemo(() => {
    const m = new Map<string, string>();
    (subjectsQ.data?.items ?? []).forEach((s: any) => m.set(s.id, s.name));
    return m;
  }, [subjectsQ.data]);

  const subjectLookup = useCallback((id: string | null) => (id ? (subjectMap.get(id) ?? null) : null), [subjectMap]);

  const chapters: ChapterOption[] = useMemo(() => {
    const quizzes = (quizzesQ.data?.items ?? []) as Quiz[];
    return quizzes
      .filter((q) => q.status === 'published')
      .map((q) => ({
        label: q.title,
        count: q.questionIds.length,
        subjectName: subjectLookup(q.subjectId),
        quizId: q.id,
        quiz: q,
      }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [quizzesQ.data, subjectLookup]);

  const selectedQuiz = useMemo(() => {
    if (!selectedChapter) return chapters[0] ?? null;
    return chapters.find((c) => c.quizId === selectedChapter) ?? chapters[0] ?? null;
  }, [chapters, selectedChapter]);

  // Fetch attempts for student
  const fetchAttempts = useCallback(async () => {
    if (!instituteId) return;
    const studentId = sessionQ.data?.user?.id as ID;
    if (!studentId) return;
    setLoadingAttempts(true);
    try {
      const list = await backend.practice.listAttempts(instituteId as ID, { studentId });
      setAttempts(list.sort((a, b) => b.startedAt.localeCompare(a.startedAt)));
    } catch {}
    setLoadingAttempts(false);
  }, [backend, instituteId, sessionQ.data]);

  useEffect(() => {
    fetchAttempts();
  }, [fetchAttempts]);

  // Auto-select first chapter
  useEffect(() => {
    if (chapters.length > 0 && !selectedChapter) {
      setSelectedChapter(chapters[0].quizId);
    }
  }, [chapters, selectedChapter]);

  // Question count options based on selected quiz
  const countOptions = useMemo(() => {
    const max = selectedQuiz?.count ?? 10;
    const opts = [5, 10, 15, 20].filter((n) => n <= max);
    if (opts.length === 0) return [max];
    if (!opts.includes(max) && max < 20) opts.push(max);
    return opts.sort((a, b) => a - b);
  }, [selectedQuiz]);

  return {
    loading: quizzesQ.loading && !quizzesQ.data,
    error: quizzesQ.error ? (quizzesQ.error.message ?? 'Failed') : null,
    chapters,
    selectedChapter: selectedQuiz?.quizId ?? null,
    setSelectedChapter,
    questionCount,
    setQuestionCount,
    countOptions,
    selectedQuiz,
    attempts,
    loadingAttempts,
    refresh: async () => {
      await quizzesQ.refetch();
      await fetchAttempts();
    },
  };
}

// ---------- Practice test runtime ----------

export interface UsePracticeTestArgs {
  quizId: string;
  questionCount: number;
}

export function usePracticeTest({ quizId, questionCount }: UsePracticeTestArgs) {
  const { backend, instituteId } = useBackend();
  const sessionQ = useSession();
  const subjectsQ = useSubjects({ limit: 50 } as any);

  const [questions, setQuestions] = useState<PracticeQuestionView[]>([]);
  const [rawMap, setRawMap] = useState<Map<string, PracticeQuestion>>(new Map());
  const [attempt, setAttempt] = useState<QuizAttempt | null>(null);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [resultViews, setResultViews] = useState<Record<string, boolean | null>>({}); // questionId -> isCorrect (null = not answered yet)
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState<Record<string, boolean>>({});
  const startTimeRef = useRef<number>(Date.now());

  const subjectMap = useMemo(() => {
    const m = new Map<string, string>();
    (subjectsQ.data?.items ?? []).forEach((s: any) => m.set(s.id, s.name));
    return m;
  }, [subjectsQ.data]);
  const subjectLookup = useCallback((id: string | null) => (id ? (subjectMap.get(id) ?? null) : null), [subjectMap]);

  // Load quiz + questions + start attempt
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        if (!instituteId) throw new Error('No institute');
        // Get quiz
        const quizPage = await backend.practice.listQuizzes(instituteId as ID, { where: { id: quizId } as any, limit: 1 } as any);
        let quiz = (quizPage.items as Quiz[]).find((q) => q.id === quizId);
        if (!quiz) {
          // Fallback: get directly from all
          const all = await backend.practice.listQuizzes(instituteId as ID, { limit: 100 } as any);
          quiz = (all.items as Quiz[]).find((q) => q.id === quizId);
        }
        if (!quiz) throw new Error('Quiz not found');
        // Slice question ids to requested count (shuffle? keep order for now)
        const slicedIds = quiz.questionIds.slice(0, questionCount);
        // Fetch questions (sanitized for student)
        const qPage = await backend.practice.listQuestions(instituteId as ID, {
          where: { id: { in: slicedIds } as any } as any,
          limit: 100,
        } as any);
        // But our listQuestions filter by where subject etc, not id in. So get all and filter
        let allQs: PracticeQuestion[] = [];
        if (qPage.items.length === 0) {
          const allQPage = await backend.practice.listQuestions(instituteId as ID, { limit: 100 } as any);
          allQs = allQPage.items.filter((qq: PracticeQuestion) => slicedIds.includes(qq.id));
        } else {
          allQs = qPage.items as PracticeQuestion[];
        }
        // Keep order of slicedIds
        const ordered = slicedIds.map((id) => allQs.find((qq) => qq.id === id)).filter(Boolean) as PracticeQuestion[];

        if (cancelled) return;

        // For scoring we need raw map with correct answers. We have to fetch raw from db via backend? For memory backend, we sanitized listQuestions, so we lost correctAnswer. We need to fetch raw via internal? Workaround: For student, we have sanitized, but for result computation we need raw. We'll fetch via a second path: if we are owner, raw available. For memory, we can still get raw by directly accessing? We'll store correctAnswer separately by using backend's underlying table if available? Simpler: we fetch questions with correctAnswer through a fallback that bypasses sanitization by using memoryFallback? Instead we will attempt to get raw questions from same page but we have correctAnswer nulled. So we need to keep a second fetch that is not sanitized? We can hide sanitization behind role: fetch as owner role would give correctAnswer. But current session is student, so always sanitized.
        // Solution: after startAttempt + submitAttempt, the backend's attempt scoring uses correctAnswer internally. For per-question instant feedback we will determine correctness via score delta (see model). So we keep.rawMap empty for client, but resultViews will be computed via score delta after each submit.
        // However for final mistakes list we need explanations (available) but not correct answers. For computing isCorrect locally for final view we would need correctAnswer. Instead we will compute isCorrect via raw correctAnswer if we can get it via attempt's score? Actually score alone doesn't tell per question.
        // To get per-question correctness for mistakes list after graded, we need correctAnswer. So we need rawMap with correctAnswer. We'll fetch raw via backend.practice.listQuestions but with a trick: call backend's underlying db? Since we are in memory, we can fetch via API that returns correctAnswer if we query as teacher? For now, we will fetch from backend's memory directly by using an unsafe method: try backend.practice.saveQuestion? No.
        // Simplest: we will store raw questions with correctAnswer from seed data embedded in app? But requirement says answer keys not in client bundle. For final mistakes list we can still show wrong without revealing correct answer, using only explanation and user answer.
        // So we don't need correctAnswer for final view if we have resultViews already built from incremental submits.
        // We'll keep rawMap with whatever backend returned (with correctAnswer null) plus we will keep a local copy of correctAnswer hidden? We will NOT store correctAnswer at all; resultViews is determined via backend's submitAttempt score delta.
        const views = ordered.map((qq) => toQuestionView(qq, subjectLookup));
        setQuestions(views);
        // rawMap for scoring reference: we need correctAnswer for computeResultView fallback. We'll populate from ordered (which has null correctAnswer for student). So we keep a separate map from ordered as is (null), but for final result we will rely on resultViews built incrementally.
        const map = new Map<string, PracticeQuestion>();
        ordered.forEach((qq) => map.set(qq.id, qq));
        setRawMap(map);

        // Start attempt
        const studentId = sessionQ.data?.user?.id as ID;
        if (!studentId) throw new Error('No student session');
        const att = await backend.practice.startAttempt(instituteId as ID, quizId as ID, studentId);
        if (cancelled) return;
        setAttempt(att);
        startTimeRef.current = Date.now();
      } catch (e: any) {
        setError(e.message ?? 'Failed to start');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [backend, instituteId, quizId, questionCount, subjectLookup, sessionQ.data]);

  const currentQuestion = questions[currentIdx] ?? null;
  const total = questions.length;
  const progressLabel = `${currentIdx + 1} of ${total}`;

  const selectOption = useCallback((questionId: string, option: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: option }));
    // Reset result view for this question when changing selection before submit
    setResultViews((prev) => ({ ...prev, [questionId]: null }));
    setShowExplanation((prev) => ({ ...prev, [questionId]: false }));
  }, []);

  // Submit answer for current question -> calls backend to grade incrementally
  const submitAnswer = useCallback(async () => {
    if (!currentQuestion || !attempt || !instituteId) return;
    const qId = currentQuestion.id;
    const chosen = answers[qId];
    if (!chosen) return;
    setSubmitting(true);
    try {
      const newAnswers = { ...answers };
      const updated = await backend.practice.submitAttempt(instituteId as ID, attempt.id as ID, newAnswers);
      // Determine if this question was correct by comparing score
      // Previous score before this answer
      const prevScore = attempt.score ?? 0;
      const newScore = updated.score ?? 0;
      // Need to know if score increased due to this specific question.
      // Since we may have answered multiple before, we compare increment.
      // We can compute previous correctness map: if previously answered correctly, score already counted.
      // Simpler: if newScore > prevScore OR result was already correct (and we changed?)... Let's compute via backend's internal correct check using hidden correctAnswer? We have rawMap with null correctAnswer for student, so can't.
      // Use score delta: if answer was newly added, delta 1 => correct, else 0 => wrong.
      // For updates where we changed answer from correct to wrong, score would decrease.
      const hadPrevAnswer = attempt.answers[qId] !== undefined;
      let isCorrect: boolean;
      if (!hadPrevAnswer) {
        isCorrect = newScore > prevScore;
      } else {
        // If we had previous answer, check if new score is higher than if we had previous answer removed? Hard.
        // Re-evaluate via: if newScore > (prevScore - (wasPrevCorrect?1:0)) => correct now
        // We need to know wasPrevCorrect. We have resultViews[qId]
        const wasCorrect = resultViews[qId] === true;
        if (wasCorrect && newScore < prevScore) isCorrect = false;
        else if (!wasCorrect && newScore > prevScore) isCorrect = true;
        else isCorrect = wasCorrect ?? false;
      }
      setAttempt(updated);
      setResultViews((prev) => ({ ...prev, [qId]: isCorrect }));
      setShowExplanation((prev) => ({ ...prev, [qId]: true }));
    } catch (e: any) {
      setError(e.message ?? 'Submit failed');
    } finally {
      setSubmitting(false);
    }
  }, [currentQuestion, attempt, answers, backend, instituteId, resultViews]);

  const next = useCallback(() => {
    if (currentIdx < total - 1) setCurrentIdx((i) => i + 1);
  }, [currentIdx, total]);

  const prev = useCallback(() => {
    if (currentIdx > 0) setCurrentIdx((i) => i - 1);
  }, [currentIdx]);

  const skip = useCallback(() => {
    setCurrentIdx((i) => (i < total - 1 ? i + 1 : i));
  }, [total]);

  const finish = useCallback(async (): Promise<QuizAttempt | null> => {
    if (!attempt || !instituteId) return null;
    setSubmitting(true);
    try {
      // Final submit with all answers (if not already graded)
      const final = await backend.practice.submitAttempt(instituteId as ID, attempt.id as ID, answers);
      setAttempt(final);
      return final;
    } catch (e: any) {
      setError(e.message ?? 'Failed to submit');
      return null;
    } finally {
      setSubmitting(false);
    }
  }, [attempt, answers, backend, instituteId]);

  const resultView: AttemptResultView | null = useMemo(() => {
    if (!attempt) return null;
    // Build result view using our incremental correctness knowledge to avoid needing correctAnswer
    const score = attempt.score ?? 0;
    const maxScore = attempt.maxScore ?? total;
    const percent = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
    let correct = 0;
    let wrong = 0;
    let skipped = 0;
    const mistakes: any[] = [];
    for (const qv of questions) {
      const ans = answers[qv.id] ?? null;
      if (!ans) {
        skipped++;
        mistakes.push({
          questionId: qv.id,
          questionText: qv.text,
          yourAnswer: null,
          explanation: qv.explanation,
          options: qv.options,
        });
        continue;
      }
      const isCorrect = resultViews[qv.id];
      if (isCorrect === true) correct++;
      else {
        wrong++;
        mistakes.push({
          questionId: qv.id,
          questionText: qv.text,
          yourAnswer: ans,
          explanation: qv.explanation,
          options: qv.options,
        });
      }
    }
    const started = attempt.startedAt ? new Date(attempt.startedAt).getTime() : null;
    const submitted = attempt.submittedAt ? new Date(attempt.submittedAt).getTime() : null;
    const timeTakenSec = started && submitted ? Math.round((submitted - started) / 1000) : Math.round((Date.now() - startTimeRef.current) / 1000);
    return {
      attempt,
      score,
      maxScore,
      percent,
      correct,
      wrong,
      skipped,
      timeTakenSec,
      mistakes,
      allQuestions: questions,
    } as AttemptResultView;
  }, [attempt, questions, answers, resultViews, total]);

  return {
    loading,
    error,
    questions,
    currentQuestion,
    currentIdx,
    total,
    progressLabel,
    answers,
    resultViews,
    showExplanation,
    selectOption,
    submitAnswer,
    next,
    prev,
    skip,
    finish,
    submitting,
    attempt,
    resultView,
  };
}
