import type { PracticeQuestion, Quiz, QuizAttempt } from '@/core/contracts/models';

export interface PracticeQuestionView {
  id: string;
  text: string;
  options: string[];
  topic: string | null;
  subjectName: string | null;
  explanation: string | null;
  marks: number;
  raw: PracticeQuestion;
}

export interface QuizCardView {
  id: string;
  title: string;
  description: string | null;
  subjectName: string | null;
  topic: string;
  questionCount: number;
  duration: number | null;
  raw: Quiz;
}

export interface ChapterOption {
  label: string; // e.g. "Quadratic Equations"
  count: number;
  subjectName: string | null;
  quizId: string;
  quiz: Quiz;
}

export interface MistakeItem {
  questionId: string;
  questionText: string;
  yourAnswer: string | null;
  explanation: string | null;
  options: string[];
}

export interface AttemptResultView {
  attempt: QuizAttempt;
  score: number;
  maxScore: number;
  percent: number;
  correct: number;
  wrong: number;
  skipped: number;
  timeTakenSec: number | null;
  mistakes: MistakeItem[];
  allQuestions: PracticeQuestionView[];
}

export function toQuestionView(
  q: PracticeQuestion,
  subjectLookup: (id: string | null) => string | null,
): PracticeQuestionView {
  return {
    id: q.id,
    text: q.text,
    options: q.options ?? [],
    topic: q.topic,
    subjectName: subjectLookup(q.subjectId),
    explanation: q.explanation,
    marks: q.marks,
    raw: q,
  };
}

export function toQuizCardView(
  quiz: Quiz,
  subjectLookup: (id: string | null) => string | null,
): QuizCardView {
  return {
    id: quiz.id,
    title: quiz.title,
    description: quiz.description,
    subjectName: subjectLookup(quiz.subjectId),
    topic: quiz.title,
    questionCount: quiz.questionIds.length,
    duration: quiz.durationMinutes,
    raw: quiz,
  };
}

export function computeResultView(
  attempt: QuizAttempt,
  questions: PracticeQuestionView[],
  questionMapRaw: Map<string, PracticeQuestion>,
): AttemptResultView {
  const answers = attempt.answers ?? {};
  const score = attempt.score ?? 0;
  const maxScore = attempt.maxScore ?? questions.length;
  const percent = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;

  let correct = 0;
  let wrong = 0;
  let skipped = 0;
  const mistakes: MistakeItem[] = [];

  for (const qv of questions) {
    const raw = questionMapRaw.get(qv.id);
    const userAns = answers[qv.id] ?? null;
    if (!userAns) {
      skipped += 1;
      mistakes.push({
        questionId: qv.id,
        questionText: qv.text,
        yourAnswer: null,
        explanation: qv.explanation,
        options: qv.options,
      });
      continue;
    }
    // Normalise comparison
    const norm = (s: string | null | undefined) => (s ?? '').trim().toLowerCase();
    const isCorrect = raw?.correctAnswer ? norm(userAns) === norm(raw.correctAnswer) : false;
    if (isCorrect) correct += 1;
    else {
      wrong += 1;
      mistakes.push({
        questionId: qv.id,
        questionText: qv.text,
        yourAnswer: userAns,
        explanation: qv.explanation,
        options: qv.options,
      });
    }
  }

  const started = attempt.startedAt ? new Date(attempt.startedAt).getTime() : null;
  const submitted = attempt.submittedAt ? new Date(attempt.submittedAt).getTime() : null;
  const timeTakenSec = started && submitted ? Math.round((submitted - started) / 1000) : null;

  return {
    attempt,
    score,
    maxScore,
    percent,
    correct,
    wrong,
    skipped,
    timeTakenSec,
    mistakes,
    allQuestions: questions,
  };
}

/** Score ring: 0-100 */
export function ringColor(percent: number): string {
  if (percent >= 70) return '#0D9488'; // teal
  if (percent >= 40) return '#F59E0B'; // amber
  return '#DC2626'; // red
}
