/** Pure formatting helpers. Indian digit grouping throughout. */

export function inr(n: number | null | undefined): string {
  const v = Math.round(Number(n ?? 0));
  const neg = v < 0;
  const s = Math.abs(v).toString();
  let out: string;
  if (s.length <= 3) out = s;
  else {
    const last3 = s.slice(-3);
    const rest = s.slice(0, -3);
    out = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + last3;
  }
  return `${neg ? '-' : ''}₹${out}`;
}

export function formatIndianNumber(n: number | null | undefined): string {
  const v = Math.round(Number(n ?? 0));
  const neg = v < 0;
  const s = Math.abs(v).toString();
  let out: string;
  if (s.length <= 3) out = s;
  else {
    const last3 = s.slice(-3);
    const rest = s.slice(0, -3);
    out = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + last3;
  }
  return `${neg ? '-' : ''}${out}`;
}

/** Text for a count badge. Nothing below 1; anything above `cap` reads "9+". */
export function badgeLabel(count: number | null | undefined, cap = 9): string {
  const n = Math.floor(Number(count ?? 0));
  if (!Number.isFinite(n) || n <= 0) return '';
  return n > cap ? `${cap}+` : String(n);
}

export const pct = (n: number | null | undefined): string => `${Math.round(Number(n ?? 0))}%`;

export function dateShort(d: string | Date | null | undefined): string {
  if (!d) return '—';
  const dt = typeof d === 'string' ? new Date(d) : d;
  if (isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function dateLong(d: string | Date | null | undefined): string {
  if (!d) return '—';
  const dt = typeof d === 'string' ? new Date(d) : d;
  if (isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

export function timeShort(t: string | null | undefined): string {
  if (!t) return '—';
  const [hRaw, m] = t.split(':');
  const h = Number(hRaw);
  if (isNaN(h)) return t;
  const suffix = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${m ?? '00'} ${suffix}`;
}

export function relTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const then = new Date(iso).getTime();
  if (isNaN(then)) return '';
  const mins = Math.round((Date.now() - then) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hour${hrs > 1 ? 's' : ''} ago`;
  const days = Math.round(hrs / 24);
  if (days < 30) return `${days} day${days > 1 ? 's' : ''} ago`;
  return dateShort(iso);
}

export const initials = (name: string): string =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');

export const daysBetween = (from: string, to: string): number => {
  const a = new Date(from).getTime();
  const b = new Date(to).getTime();
  if (isNaN(a) || isNaN(b)) return 0;
  return Math.max(1, Math.round((b - a) / 86400000) + 1);
};

export const todayISO = (): string => new Date().toISOString().slice(0, 10);

/** Converts YYYY-MM-DD to DD/MM/YYYY */
export function isoToDMY(iso: string): string {
  if (!iso) return '';
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(iso)) return iso;
  const parts = iso.slice(0, 10).split('-');
  if (parts.length !== 3) return iso;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

/** Converts DD/MM/YYYY to YYYY-MM-DD */
export function dmyToISO(dmy: string): string {
  if (!dmy) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(dmy)) return dmy;
  const parts = dmy.split('/');
  if (parts.length !== 3) return dmy;
  return `${parts[2]}-${parts[1]}-${parts[0]}`;
}
