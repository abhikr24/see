import type { AttendanceStatus, ID } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { addDays, nowIso, todayIso } from './store';

/** Same id scheme as supabase/seed.sql: the last two digits identify the record. */
const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;

export const SEED = {
  instituteId: sid(1),
  ownerId: sid(2),
  teacherId: sid(3),
  branchId: sid(8),
  batchId: sid(9),
  studentIds: [sid(14), sid(15), sid(16)],
  ownerEmail: 'owner@sunrise.test',
};

/**
 * A small slice of "Sunrise Coaching Classes, Patna" – enough for every port to
 * return something and for the progress rules to raise real alerts.
 * Student 16 is deliberately at risk: poor attendance and an overdue fee.
 */
export function seed(db: Db): void {
  const at = nowIso();
  const today = todayIso();
  const inst = SEED.instituteId;
  const row = (n: number) => ({ id: sid(n), instituteId: inst, createdAt: at, updatedAt: at });

  db.institutes.put({
    ...D.institute(),
    id: inst,
    name: 'Sunrise Coaching Classes',
    code: 'SUNRISE-PAT',
    ownerId: SEED.ownerId,
    city: 'Patna',
    state: 'Bihar',
    settings: { ...D.settings(), academicYear: '2026-27', receiptPrefix: 'SCC' },
    createdAt: at,
    updatedAt: at,
  });

  const people: [number, string, string, 'owner' | 'teacher' | 'student' | 'parent'][] = [
    [2, 'Rahul Sharma', SEED.ownerEmail, 'owner'],
    [3, 'Rohit Verma', 'rohit@sunrise.test', 'teacher'],
    [14, 'Aarav Sharma', 'aarav@sunrise.test', 'student'],
    [41, 'Anita Sharma', 'parent@sunrise.test', 'parent'],
  ];
  for (const [n, fullName, email, role] of people) {
    db.profiles.set(sid(n), { ...D.profile(), id: sid(100 + n), userId: sid(n), fullName, email, createdAt: at, updatedAt: at });
    db.memberships.put({
      ...row(200 + n),
      userId: sid(n),
      branchId: SEED.branchId,
      role,
      status: 'active',
      permissions: [],
      requestNote: null,
      requestedAt: at,
      decidedBy: SEED.ownerId,
      decidedAt: at,
    });
  }

  db.branches.put({ ...D.branch(), ...row(8), name: 'Boring Road (Main)', code: 'BR', city: 'Patna', isMain: true });
  db.teachers.put({ ...D.teacher(), ...row(3), userId: sid(3), fullName: 'Rohit Verma', specialization: 'Mathematics' });
  db.staff.put({ ...D.staff(), ...row(303), userId: sid(3), teacherId: sid(3), employeeCode: 'SCC-T01', designation: 'Class teacher' });
  db.batches.put({ ...D.batch(), ...row(9), branchId: SEED.branchId, name: 'Class 10-A', grade: '10', section: 'A', academicYear: '2026-27' });
  db.subjects.put({ ...D.subject(), ...row(44), name: 'Mathematics', code: 'MATH' });
  db.subjects.put({ ...D.subject(), ...row(45), name: 'Physics', code: 'PHY' });
  db.timetables.put({ ...D.timetable(), ...row(60), batchId: SEED.batchId, subjectId: sid(44), teacherId: sid(3), dayOfWeek: 1, startsAt: '16:00', endsAt: '17:00' });

  const names = ['Aarav Sharma', 'Aditya Pandey', 'Ananya Singh'];
  SEED.studentIds.forEach((studentId, index) => {
    const n = 14 + index;
    db.students.put({ ...D.student(), ...row(n), fullName: names[index], admissionNo: `SCC-${n}`, classGrade: '10', branchId: SEED.branchId });
    db.enrollments.put({ ...row(400 + n), batchId: SEED.batchId, studentId, rollNumber: n, joinedOn: addDays(today, -90), leftOn: null, status: 'active' });
  });
  db.studentMemberships.put({ ...row(500), studentId: sid(14), membershipId: sid(214), linkedBy: SEED.ownerId });

  // Five roll calls. Students 14 and 15 attend; student 16 misses three of five.
  const pattern: AttendanceStatus[][] = [
    ['present', 'present', 'absent'],
    ['present', 'late', 'absent'],
    ['present', 'present', 'present'],
    ['present', 'present', 'absent'],
    ['present', 'absent', 'present'],
  ];
  pattern.forEach((statuses, day) => {
    const sessionId = sid(600 + day);
    db.attendanceSessions.put({
      ...row(600 + day),
      batchId: SEED.batchId,
      subjectId: null,
      teacherId: sid(3),
      date: addDays(today, day - 5),
      period: 1,
      status: 'submitted',
      markedBy: sid(3),
      markedAt: at,
      notes: null,
    });
    statuses.forEach((status, index) => {
      db.attendanceRecords.put({
        ...row(700 + day * 10 + index),
        sessionId,
        batchId: SEED.batchId,
        studentId: SEED.studentIds[index],
        status,
        remark: null,
        markedBy: sid(3),
      });
    });
  });

  // One fee plan; student 16's only installment fell due ten days ago and is unpaid.
  db.feeStructures.put({ ...D.feeStructure(), ...row(51), batchId: SEED.batchId, name: 'Class 10 annual fee', academicYear: '2026-27', totalAmount: 36000 });
  db.studentFees.put({ ...row(816), studentId: sid(16), feeStructureId: sid(51), academicYear: '2026-27', grossAmount: 36000, discountAmount: 0, discountReason: null, netAmount: 36000, status: 'active' });
  db.installments.put({ ...row(916), studentFeeId: sid(816), studentId: sid(16), termNo: 1, label: 'Class 10 annual fee', amount: 36000, dueDate: addDays(today, -10), paidAmount: 0, paidOn: null, status: 'overdue' });

  db.notices.put({ ...D.notice(), ...row(61), title: 'Unit Test 3 schedule', body: 'Unit Test 3 begins next Monday.', category: 'exam', publishedAt: at, createdBy: SEED.ownerId });
  db.leads.put({ ...D.lead(), ...row(71), studentName: 'Kunal Raj', phone: '9000000071', classInterested: '10' });

  const plan = { currency: 'INR', maxBranches: 1, storageMb: 1024, features: {}, isActive: true };
  db.plans.put({ ...row(90), ...plan, code: 'starter', name: 'Starter', priceMonthly: 999, priceYearly: 9990, maxStudents: 100, maxTeachers: 10 });
  db.plans.put({ ...row(91), ...plan, code: 'growth', name: 'Growth', priceMonthly: 2499, priceYearly: 24990, maxStudents: 500, maxTeachers: 50 });
  db.subscriptions.put({
    ...row(92),
    planId: sid(90),
    status: 'trialing',
    billingCycle: 'monthly',
    currentPeriodStart: at,
    currentPeriodEnd: null,
    trialEndsAt: `${addDays(today, 14)}T00:00:00.000Z`,
    cancelAt: null,
    cancelledAt: null,
    provider: 'memory',
    providerSubscriptionId: null,
  });

  // Start signed out. A session is created only by sign-in / OTP verify, so
  // the shell has to resolve membership from a fresh cache instead of a
  // launch-time owner session.
}
