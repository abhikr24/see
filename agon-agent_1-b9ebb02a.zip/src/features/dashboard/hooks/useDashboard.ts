import { useCallback, useMemo, useState } from 'react';
import type { Ionicons } from '@expo/vector-icons';

import { useInstitute, useOwnerDashboard, useSession } from '@/core/backend';
import type { OwnerDashboard } from '@/core/contracts/models';
import { inr, pct, timeShort } from '@/lib/format';
import type { Tone } from '@/lib/theme';
import { dashboardLinks, type DashboardLink } from '../links';

export type IconName = keyof typeof Ionicons.glyphMap;

/** loading = first load only. A background refresh keeps the last numbers on screen. */
export type DashboardStatus = 'loading' | 'error' | 'empty' | 'ready';

export interface HeroView {
  institute: string;
  greeting: string;
  /** Date, plus how many batches meet today once that is known. */
  meta: string;
  userName: string;
  avatarUrl: string | null;
}

export interface StatView {
  key: string;
  value: string;
  label: string;
  link?: DashboardLink;
}

export interface QuickActionView {
  key: string;
  label: string;
  icon: IconName;
  link: DashboardLink;
}

export interface AttentionView {
  key: string;
  tone: Tone;
  title: string;
  link: DashboardLink;
}

export interface BatchRowView {
  key: string;
  time: string;
  name: string;
  students: string;
  teachers: { name: string; uri: string | null }[];
}

export interface DashboardView {
  status: DashboardStatus;
  hero: HeroView;
  stats: StatView[];
  quickActions: QuickActionView[];
  attention: AttentionView[];
  batches: BatchRowView[];
  /** Set when a load failed. With `status: 'ready'` it means the numbers shown are the last good ones. */
  errorMessage: string | null;
  refreshing: boolean;
  refresh: () => Promise<void>;
}

const plural = (count: number, one: string, many: string): string => `${count} ${count === 1 ? one : many}`;

function greetingFor(hour: number): string {
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

function firstName(fullName: string | undefined): string {
  return fullName?.trim().split(/\s+/)[0] ?? '';
}

/** `2026-11-12` → `Thu, 12 Nov`. Built from the parts so no timezone can shift the day. */
function dayLabel(date: string): string {
  const [year, month, day] = date.split('-').map(Number);
  return new Date(year, month - 1, day).toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
}

function todayLine(data: OwnerDashboard): string {
  const count = data.batchesToday.length;
  if (data.batchCount === 0) return dayLabel(data.date);
  return `${dayLabel(data.date)} · ${count === 0 ? 'No classes today' : `${plural(count, 'batch', 'batches')} today`}`;
}

function statsOf(data: OwnerDashboard): StatView[] {
  return [
    { key: 'collected', value: inr(data.collectedToday), label: 'Collected today' },
    {
      key: 'attendance',
      value: data.attendancePercent === null ? '—' : pct(data.attendancePercent),
      label: 'Attendance',
    },
    {
      key: 'approvals',
      value: String(data.pendingApprovals),
      label: 'Pending approvals',
      link: dashboardLinks.approvals(),
    },
  ];
}

/** Only what is actually wrong. A zero never becomes a card. */
function attentionOf(data: OwnerDashboard): AttentionView[] {
  const items: AttentionView[] = [];
  if (data.pendingApprovals > 0) {
    items.push({
      key: 'approvals',
      tone: 'accent',
      title: `${plural(data.pendingApprovals, 'join request', 'join requests')} waiting for approval`,
      link: dashboardLinks.approvals(),
    });
  }
  if (data.overdueAmount > 0) {
    items.push({
      key: 'overdue',
      tone: 'danger',
      title: `${inr(data.overdueAmount)} overdue across ${plural(data.overdueStudents, 'student', 'students')}`,
      link: dashboardLinks.overdueFees(),
    });
  }
  if (data.lowAttendanceAlerts > 0) {
    items.push({
      key: 'low-attendance',
      tone: 'warning',
      title: `${plural(data.lowAttendanceAlerts, 'low-attendance alert', 'low-attendance alerts')} this week`,
      link: dashboardLinks.lowAttendance(),
    });
  }
  return items;
}

function quickActionsOf(data: OwnerDashboard): QuickActionView[] {
  const batchId = data.currentBatchId;
  return [
    { key: 'attendance', label: 'Take attendance', icon: 'checkbox-outline', link: dashboardLinks.takeAttendance(batchId) },
    { key: 'student', label: 'Add student', icon: 'person-add-outline', link: dashboardLinks.addStudent(batchId) },
    { key: 'fee', label: 'Collect fee', icon: 'wallet-outline', link: dashboardLinks.collectFee(batchId) },
    { key: 'notice', label: 'Send notice', icon: 'megaphone-outline', link: dashboardLinks.sendNotice(batchId) },
  ];
}

function batchRowsOf(data: OwnerDashboard): BatchRowView[] {
  return data.batchesToday.map((batch) => ({
    key: batch.batchId,
    time: timeShort(batch.startsAt),
    name: batch.name,
    students: plural(batch.studentCount, 'student', 'students'),
    teachers: batch.teachers.map((teacher) => ({ name: teacher.fullName, uri: teacher.photoUrl })),
  }));
}

/**
 * The owner dashboard's view model. Every number arrives ready-made from
 * `AnalyticsRepo.dashboard` – this hook only words and formats them, decides
 * which state the screen is in, and attaches where each tap goes.
 */
export function useDashboard(): DashboardView {
  const { data, loading, error, refetch } = useOwnerDashboard();
  const institute = useInstitute();
  const session = useSession();
  const [refreshing, setRefreshing] = useState(false);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refetch();
    } finally {
      setRefreshing(false);
    }
  }, [refetch]);

  const profile = session.data?.profile;
  const name = firstName(profile?.fullName);
  const hero: HeroView = {
    institute: institute.data?.name ?? '',
    greeting: name ? `${greetingFor(new Date().getHours())}, ${name}` : greetingFor(new Date().getHours()),
    meta: data ? todayLine(data) : '',
    userName: profile?.fullName ?? '',
    avatarUrl: profile?.avatarUrl ?? null,
  };

  const sections = useMemo(
    () => ({
      stats: data ? statsOf(data) : [],
      quickActions: data ? quickActionsOf(data) : [],
      attention: data ? attentionOf(data) : [],
      batches: data ? batchRowsOf(data) : [],
    }),
    [data],
  );

  let status: DashboardStatus;
  if (data) status = data.batchCount === 0 ? 'empty' : 'ready';
  else status = error && !loading ? 'error' : 'loading';

  return { status, hero, ...sections, errorMessage: error?.message ?? null, refreshing, refresh };
}
