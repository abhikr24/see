// Expo Router owns the application entry; keep the scaffold entry compatible.
export { default } from './app/_layout';
