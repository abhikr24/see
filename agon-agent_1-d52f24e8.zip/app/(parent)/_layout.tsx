export { ParentShell as default } from '@/features/parent/ParentShell';
