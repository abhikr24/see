export { ParentAttendance as default } from '@/features/parent/details';
