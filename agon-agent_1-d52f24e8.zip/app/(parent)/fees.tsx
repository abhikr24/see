export { ParentFees as default } from '@/features/parent/details';
