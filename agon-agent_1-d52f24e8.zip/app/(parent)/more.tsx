import React from 'react';
import { Redirect } from 'expo-router';
export default function ParentMoreRoute() { return <Redirect href="/(parent)" />; }
