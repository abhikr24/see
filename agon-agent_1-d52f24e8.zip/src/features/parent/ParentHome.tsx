import React from 'react';
import { FlatList, Pressable, RefreshControl, View, useWindowDimensions } from 'react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChildSwitcher } from '@/components/ui/ChildSwitcher';
import { C, useTheme } from '@/lib/theme';
import { useParent } from './context';
import { FeeReminder, MonthlyCard, TrendCard, UpdatesCard } from './cards';
import { Action, Icon, Label, Panel, Photo, styles } from './ui';

export function ParentState() {
  const p = useParent();
  const theme = useTheme();
  if (p.error && !p.summary) return <Panel><Label size={18} weight="700">Let’s try that again</Label><Label color={theme.muted} style={{ marginVertical: 15 }}>{p.error.message}</Label><Action label="Try again" onPress={() => void p.refresh()} /></Panel>;
  if (!p.summary) return <View accessibilityLabel="Loading your family overview" style={{ gap: 20 }}>{[150, 85, 150, 230].map((height, i) => <View key={i} style={{ height, borderRadius: 20, backgroundColor: i ? theme.surface : C.primary, opacity: i ? 0.8 : 0.92 }} />)}</View>;
  return <Panel><Icon name="people-outline" size={32} color={theme.muted} /><Label size={18} weight="700" style={{ marginTop: 16 }}>Your family’s story starts here</Label><Label color={theme.muted} style={{ marginTop: 10 }}>No children are linked to this account yet. Ask your institute to link your child to your parent account.</Label><View style={{ marginTop: 20 }}><Action label="Check again" onPress={() => void p.refresh()} /></View></Panel>;
}
export default function ParentHome() {
  const p = useParent();
  const theme = useTheme();
  const width = useWindowDimensions().width;
  const wide = width >= 980;
  const split = width >= 1180;
  const child = p.child;
  return <SafeAreaView edges={wide ? [] : ['top']} style={{ flex: 1, backgroundColor: wide ? theme.background : C.primary }}>
    <FlatList data={child ? [child] : []} keyExtractor={c => c.id} showsVerticalScrollIndicator={false} style={{ backgroundColor: theme.background }} contentContainerStyle={[styles.page, !wide && { paddingHorizontal: 20, paddingTop: 0 }]} refreshControl={<RefreshControl refreshing={p.loading && !!p.summary} onRefresh={() => void p.refresh()} tintColor={C.teal} />} ListEmptyComponent={<ParentState />} renderItem={() => <View>
      <View style={{ backgroundColor: C.primary, minHeight: wide ? 162 : 172, borderRadius: wide ? 20 : 0, paddingHorizontal: wide ? 29 : 24, paddingTop: 27, paddingBottom: 43, marginHorizontal: wide ? 0 : -20, overflow: 'hidden' }}>
        <View pointerEvents="none" style={{ position: 'absolute', right: 70, top: -91, width: 330, height: 330, borderWidth: 1, borderRadius: 200, borderColor: C.heroLine, opacity: 0.6 }} /><View pointerEvents="none" style={{ position: 'absolute', right: 28, top: -50, width: 330, height: 330, borderWidth: 1, borderRadius: 200, borderColor: C.heroLine, opacity: 0.6 }} />
        <View style={styles.spread}>
          <View><View style={[styles.row, { gap: 7 }]}><Icon name="moon-outline" size={13} color={C.navyPale} /><Label size={12} color={C.navyPale}>Good evening</Label></View><Label size={22} weight="800" color={C.surface} style={{ marginTop: 4, letterSpacing: -0.5 }}>{p.summary?.parentName}</Label><Label size={11} color={C.navyPale} style={{ marginTop: 9 }}>A little closer to their day.</Label></View>
          {wide && <View style={{ marginLeft: 'auto', marginRight: 34, borderLeftWidth: 1, borderColor: C.heroLine, paddingLeft: 24 }}><Label size={12} color={C.navyPale} style={{ lineHeight: 21 }}>Growing minds.{'\n'}Brighter tomorrows.</Label></View>}
          <Pressable accessibilityRole="button" accessibilityLabel="Open parent profile" onPress={() => p.open({ type: 'profile' })} style={{ padding: 4, borderWidth: 1, borderColor: C.heroLine, borderRadius: 40 }}><Photo name={p.summary?.parentName ?? 'Parent'} uri={p.summary?.parentPhotoUrl} size={wide ? 52 : 46} /></Pressable>
        </View>
      </View>
      {p.summary && child && p.summary.children.length > 1 ? <View style={{ marginTop: -27, marginHorizontal: wide ? 24 : 0 }}><ChildSwitcher items={p.summary.children} selectedId={child.id} visible={false} onOpen={() => p.setSwitcherOpen(true)} onClose={() => p.setSwitcherOpen(false)} onSelect={p.select} /></View> : <Label size={14} weight="700" style={{ paddingTop: 22 }}>{child?.name} · {child?.classLabel}</Label>}
      {p.error && <View style={[styles.row, { paddingTop: 15, gap: 10 }]}><Label color={C.duesInk} size={12} style={{ flex: 1 }}>We couldn’t refresh just now. These are your last saved details.</Label><Pressable onPress={() => void p.refresh()}><Label size={12} weight="700">Retry</Label></Pressable></View>}
      {child && <Animated.View key={child.id} entering={FadeIn.duration(220)} style={{ marginTop: 24, gap: 22 }}>
        <View style={{ flexDirection: split ? 'row' : 'column', gap: 22 }}>
          <View style={{ flex: split ? 1.45 : undefined, gap: 20 }}><MonthlyCard child={child} /><TrendCard child={child} /></View>
          <View style={{ flex: split ? 1 : undefined }}><UpdatesCard child={child} /></View>
        </View>
        <FeeReminder child={child} />
      </Animated.View>}
      <View style={[styles.row, { alignSelf: 'center', gap: 6, paddingTop: 24 }]}><Icon name="heart-outline" size={12} color={C.muted} /><Label size={10} color={C.muted}>Supporting their journey, together.</Label></View>
    </View>} />
  </SafeAreaView>;
}
