import React, { useCallback, useEffect } from 'react';
import { Modal, Platform, Pressable, View, useWindowDimensions } from 'react-native';
import Animated, { FadeIn, FadeInUp } from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import BottomSheet, { BottomSheetBackdrop, BottomSheetView, type BottomSheetBackdropProps } from '@gorhom/bottom-sheet';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { C, useTheme } from '@/lib/theme';
import { Icon, Label } from './ui';

export function ParentSheet({ visible, close, title, subtitle, children }: { visible: boolean; close: () => void; title: string; subtitle?: string; children: React.ReactNode }) {
  const { width, height } = useWindowDimensions();
  const wide = width >= 760;
  const theme = useTheme();
  const backdrop = useCallback((props: BottomSheetBackdropProps) => <BottomSheetBackdrop {...props} appearsOnIndex={0} disappearsOnIndex={-1} pressBehavior="close" opacity={0.45} />, []);
  useEffect(() => {
    if (!visible || typeof document === 'undefined') return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [visible, close]);
  const content = <>
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, marginBottom: 5 }}>
      <Label size={22} weight="800" style={{ flex: 1 }}>{title}</Label>
      <Pressable onPress={close} accessibilityRole="button" accessibilityLabel="Close dialog" style={{ width: 36, height: 36, backgroundColor: theme.background, borderRadius: 18, justifyContent: 'center', alignItems: 'center' }}><Icon name="close" color={theme.muted} size={20} /></Pressable>
    </View>
    {subtitle && <Label size={13} color={theme.muted}>{subtitle}</Label>}
    <View style={{ marginTop: 24 }}>{children}</View>
    <SafeAreaView edges={['bottom']} />
  </>;
  // Native keeps the repository's gesture-driven sheet; web gets a keyboard-friendly dialog.
  if (Platform.OS !== 'web') return <Modal transparent visible={visible} onRequestClose={close} animationType="fade">
    <GestureHandlerRootView style={{ flex: 1 }}>
      <BottomSheet index={0} enableDynamicSizing maxDynamicContentSize={height * 0.92} enablePanDownToClose onClose={close} backdropComponent={backdrop} backgroundStyle={{ backgroundColor: theme.surface, borderRadius: 28 }} handleIndicatorStyle={{ backgroundColor: theme.border, width: 38, height: 4 }}>
        <BottomSheetView style={{ paddingHorizontal: 24, paddingTop: 12, paddingBottom: 24 }}>{content}</BottomSheetView>
      </BottomSheet>
    </GestureHandlerRootView>
  </Modal>;
  return <Modal transparent visible={visible} onRequestClose={close} animationType="fade">
    <View style={{ flex: 1, justifyContent: wide ? 'center' : 'flex-end', alignItems: 'center' }}>
      <Animated.View entering={FadeIn.duration(180)} style={{ position: 'absolute', inset: 0, backgroundColor: C.scrim }}><Pressable accessibilityRole="button" accessibilityLabel="Dismiss dialog" onPress={close} style={{ flex: 1 }} /></Animated.View>
      <Animated.View entering={FadeInUp.duration(240)} accessibilityViewIsModal style={{ width: '100%', maxWidth: 540, backgroundColor: theme.surface, borderRadius: wide ? 24 : 28, borderBottomLeftRadius: wide ? 24 : 0, borderBottomRightRadius: wide ? 24 : 0, padding: wide ? 28 : 24, maxHeight: '92%' }}>
        {!wide && <View style={{ alignSelf: 'center', width: 38, height: 4, borderRadius: 4, backgroundColor: theme.border, marginTop: -12, marginBottom: 20 }} />}
        {content}
      </Animated.View>
    </View>
  </Modal>;
}
