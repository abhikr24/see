import React from 'react';
import { Pressable, View, useWindowDimensions } from 'react-native';
import { Redirect, Tabs, router, useSegments } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { C, useTheme } from '@/lib/theme';
import { useRouteResolution } from '@/store/session';
import { ShellLoading } from '@/features/shell/ShellLoading';
import { ChildSwitcher } from '@/components/ui/ChildSwitcher';
import { ParentProvider, useParent } from './context';
import { Icon, Label, Photo, styles } from './ui';

const tabs = [
  { key: 'index', label: 'Overview', icon: 'grid-outline' as const, route: '/(parent)' },
  { key: 'attendance', label: 'Attendance', icon: 'calendar-outline' as const, route: '/(parent)/attendance' },
  { key: 'fees', label: 'Fees & payments', short: 'Fees', icon: 'wallet-outline' as const, route: '/(parent)/fees' },
  { key: 'notices', label: 'Notices', icon: 'notifications-outline' as const, route: '/(parent)/notices' },
];
function FamilySwitcherOverlay() {
  const p = useParent();
  if (!p.child || !p.summary || !p.switcherOpen) return null;
  return <View style={{ position: 'absolute', width: 0, height: 0, overflow: 'hidden' }}><ChildSwitcher items={p.summary.children} selectedId={p.child.id} visible={p.switcherOpen} onOpen={() => p.setSwitcherOpen(true)} onClose={() => p.setSwitcherOpen(false)} onSelect={p.select} /></View>;
}
function ShellContent() {
  const theme = useTheme();
  const wide = useWindowDimensions().width >= 980;
  const segments = useSegments() as readonly string[];
  const active = segments[1] ?? 'index';
  const p = useParent();
  const current = tabs.find(t => t.key === active) ?? tabs[0];
  return <View style={{ flex: 1, flexDirection: 'row', backgroundColor: theme.background }}>
    <StatusBar style={theme.dark || !wide ? 'light' : 'dark'} />
    {wide && <View style={{ width: 236, backgroundColor: theme.surface, borderRightWidth: 1, borderColor: theme.border, paddingHorizontal: 20 }}>
      <View style={[styles.row, { gap: 10, marginTop: 31, paddingHorizontal: 8 }]}><View style={{ height: 35, width: 35, borderRadius: 11, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center' }}><Icon name="school" color={C.surface} size={21} /></View><Label size={24} weight="800" color={theme.primary} style={{ letterSpacing: -1 }}>GuruFlow<Label size={24} color={C.accent}>.</Label></Label></View>
      <Label size={9} color={C.muted} weight="600" style={[styles.eyebrow, { marginLeft: 54, marginTop: 1 }]}>Growing together</Label>
      <Label size={10} weight="600" color={C.muted} style={[styles.eyebrow, { marginTop: 53, paddingHorizontal: 14, marginBottom: 14 }]}>Parent space</Label>
      <View style={{ gap: 7 }}>{tabs.map(tab => <Pressable key={tab.key} accessibilityRole="tab" accessibilityLabel={tab.label} accessibilityState={{ selected: active === tab.key }} onPress={() => router.navigate(tab.route as never)} style={({ pressed }) => ({ minHeight: 48, paddingHorizontal: 16, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 13, backgroundColor: active === tab.key ? (theme.dark ? C.heroGlass : C.navySoft) : pressed ? theme.background : C.transparent })}>
        <Icon name={tab.icon} size={19} color={active === tab.key ? theme.primary : theme.muted} /><Label size={12} weight={active === tab.key ? '700' : '500'} color={active === tab.key ? theme.primary : theme.muted}>{tab.label}</Label>{active === tab.key && <View style={{ width: 5, height: 5, borderRadius: 4, backgroundColor: theme.primary, marginLeft: 'auto' }} />}
      </Pressable>)}</View>
      <View style={{ marginTop: 33, marginHorizontal: 13, borderTopWidth: 1, borderColor: theme.border, paddingTop: 24 }}><Label size={9} color={C.muted} weight="600" style={styles.eyebrow}>Your institute</Label><View style={[styles.row, { marginTop: 14, gap: 10 }]}><View style={{ width: 31, height: 34, borderRadius: 9, backgroundColor: theme.background, alignItems: 'center', justifyContent: 'center' }}><Icon name="sunny-outline" color={theme.muted} size={18} /></View><View><Label size={11} weight="700">Sunrise Coaching</Label><Label size={10} color={C.muted}>Patna, Bihar</Label></View></View></View>
      <View style={{ flex: 1 }} />
      <Pressable accessibilityRole="button" onPress={() => p.open({ type: 'support' })} style={({ pressed }) => ({ borderRadius: 16, backgroundColor: theme.background, padding: 17, marginBottom: 24, opacity: pressed ? 0.7 : 1 })}><View style={[styles.row, { gap: 8 }]}><Icon name="chatbubbles-outline" size={19} color={theme.muted} /><Label size={12} weight="700">A little help?</Label></View><Label size={11} color={theme.muted} style={{ marginTop: 9, lineHeight: 19 }}>We’re here for you and your family.</Label><View style={[styles.row, { gap: 6, marginTop: 13 }]}><Label size={11} weight="700" color={theme.primary}>Let’s talk</Label><Icon name="arrow-forward" size={14} color={theme.primary} /></View></Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel="Your profile" onPress={() => p.open({ type: 'profile' })} style={[styles.row, { gap: 11, paddingTop: 19, paddingBottom: 26, borderTopWidth: 1, borderColor: theme.border }]}><Photo name={p.summary?.parentName ?? 'Parent'} uri={p.summary?.parentPhotoUrl} size={35} /><View style={{ flex: 1 }}><Label size={12} weight="700">{p.summary?.parentName ?? 'Your account'}</Label><Label size={10} color={C.muted}>Parent account</Label></View><Icon name="chevron-forward" size={14} color={C.muted} /></Pressable>
    </View>}
    <View style={{ flex: 1, minWidth: 0 }}>
      {wide && <View style={{ height: 76, backgroundColor: theme.surface, borderBottomWidth: 1, borderColor: theme.border, paddingHorizontal: 37, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View style={[styles.row, { gap: 12 }]}><Label size={12} color={C.muted}>Parent space</Label><Icon name="chevron-forward" size={11} color={C.muted} /><Label size={12} weight="600">{current.label}</Label></View>
        <View style={[styles.row, { gap: 22 }]}><View style={[styles.row, { gap: 8 }]}><Icon name="calendar-clear-outline" color={C.muted} size={15} /><Label size={11} color={theme.muted}>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</Label></View><View style={{ width: 1, height: 22, backgroundColor: theme.border }} /><Pressable accessibilityRole="button" accessibilityLabel="View recent updates" onPress={() => router.navigate('/(parent)/notices')} style={{ padding: 8 }}><Icon name="notifications-outline" size={20} color={theme.muted} /><View style={{ position: 'absolute', width: 5, height: 5, top: 7, right: 8, backgroundColor: C.accent, borderRadius: 4 }} /></Pressable></View>
      </View>}
      <Tabs screenOptions={{ headerShown: false, sceneStyle: { backgroundColor: theme.background }, animation: 'fade' }} tabBar={({ state, navigation }) => wide ? null : <SafeAreaView edges={['bottom']} style={{ backgroundColor: theme.surface, borderTopWidth: 1, borderColor: theme.border }}><View style={{ flexDirection: 'row', paddingVertical: 9 }}>{tabs.map(tab => {
        const index = state.routes.findIndex(r => r.name === tab.key);
        const selected = state.index === index;
        return <Pressable key={tab.key} accessibilityRole="tab" accessibilityLabel={tab.label} accessibilityState={{ selected }} onPress={() => navigation.navigate(tab.key)} style={{ flex: 1, alignItems: 'center', gap: 4, minHeight: 44 }}><View style={{ paddingHorizontal: 15, paddingVertical: 4, backgroundColor: selected ? (theme.dark ? C.heroGlass : C.navySoft) : C.transparent, borderRadius: 14 }}><Icon name={tab.icon} size={20} color={selected ? theme.primary : C.muted} /></View><Label size={9} weight={selected ? '700' : '500'} color={selected ? theme.primary : C.muted}>{tab.short ?? tab.label}</Label></Pressable>;
      })}</View></SafeAreaView>}>
        {tabs.map(tab => <Tabs.Screen key={tab.key} name={tab.key} options={{ title: tab.label }} />)}
        <Tabs.Screen name="more" options={{ href: null }} />
      </Tabs>
    </View>
    <FamilySwitcherOverlay />
  </View>;
}
export function ParentShell() {
  const { status, group, destination } = useRouteResolution();
  if (status === 'loading' || !destination) return <ShellLoading />;
  if (status !== 'ready' || group !== '/(parent)') return <Redirect href={destination as never} />;
  return <ParentProvider><ShellContent /></ParentProvider>;
}
