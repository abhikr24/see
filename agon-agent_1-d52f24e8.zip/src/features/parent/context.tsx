import React, { createContext, useContext, useState } from 'react';
import type { ParentChildSummary, ParentSummary, ParentTerm, ParentUpdate } from '@/core/contracts/models/parent';
import type { BackendError } from '@/core/contracts/errors';
import { useBackend, useParentPayment, useParentSummary } from '@/core/backend';
import { ParentDialogs } from './dialogs';

export type ParentDialog = { type: 'update'; update: ParentUpdate } | { type: 'payment'; term: ParentTerm; child: ParentChildSummary } | { type: 'profile' } | { type: 'support' } | { type: 'success'; receipt: string; amount: number } | null;
interface ParentContextValue {
  summary?: ParentSummary;
  child?: ParentChildSummary;
  loading: boolean;
  error: BackendError | null;
  refresh: () => Promise<void>;
  select: (id: string) => void;
  switcherOpen: boolean;
  setSwitcherOpen: (open: boolean) => void;
  open: (dialog: ParentDialog) => void;
  demo: boolean;
}
const ParentContext = createContext<ParentContextValue | null>(null);
export function ParentProvider({ children }: { children: React.ReactNode }) {
  const query = useParentSummary();
  const [selected, setSelected] = useState<string | null>(null);
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const [dialog, setDialog] = useState<ParentDialog>(null);
  const payment = useParentPayment();
  const { backend } = useBackend();
  const child = query.data?.children.find(c => c.id === selected) ?? query.data?.children[0];
  const select = (id: string) => {
    if (!query.data?.children.some(c => c.id === id)) return;
    setSelected(id);
    setSwitcherOpen(false);
    setDialog(null);
  };
  const pay = async () => {
    if (dialog?.type !== 'payment' || payment.loading) return;
    const result = await payment.mutate({ studentId: dialog.child.id, installmentId: dialog.term.id });
    if (result.ok) {
      await query.refetch();
      setDialog({ type: 'success', receipt: result.data, amount: dialog.term.remaining });
    }
  };
  return <ParentContext.Provider value={{ summary: query.data, child, loading: query.loading, error: query.error, refresh: query.refetch, select, switcherOpen, setSwitcherOpen, open: setDialog, demo: backend.name === 'memory' }}>
    {children}
    <ParentDialogs dialog={dialog} close={() => setDialog(null)} pay={() => void pay()} paying={payment.loading} error={payment.error?.message} />
  </ParentContext.Provider>;
}
export function useParent() {
  const value = useContext(ParentContext);
  if (!value) throw new Error('ParentProvider is missing');
  return value;
}
