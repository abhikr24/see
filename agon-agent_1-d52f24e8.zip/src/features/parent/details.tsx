import React, { useState } from 'react';
import { FlatList, Pressable, RefreshControl, View, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, useTheme } from '@/lib/theme';
import { formatParentDate } from '@/core/contracts/parent';
import { useParent } from './context';
import { UpdateRow } from './cards';
import { ParentState } from './ParentHome';
import { Action, currency, Icon, Label, Panel, percent, Photo, styles } from './ui';

function Heading({ title, subtitle }: { title: string; subtitle: string }) {
  const p = useParent();
  const theme = useTheme();
  return <View style={{ marginBottom: 24, gap: 12 }}><Label size={27} weight="800" style={{ letterSpacing: -0.7 }}>{title}</Label><Label color={theme.muted} size={13}>{subtitle}</Label>{p.child && <Pressable accessibilityRole="button" disabled={(p.summary?.children.length ?? 0) <= 1} accessibilityLabel="Switch child" onPress={() => p.setSwitcherOpen(true)} style={[styles.row, { gap: 10, marginTop: 8, alignSelf: 'flex-start' }]}><Photo name={p.child.name} uri={p.child.photoUrl} size={30} /><Label size={13} weight="700">{p.child.name}</Label>{(p.summary?.children.length ?? 0) > 1 && <Icon name="chevron-down" size={14} color={theme.muted} />}</Pressable>}</View>;
}
function Frame({ children }: { children: React.ReactNode }) {
  const theme = useTheme();
  return <SafeAreaView edges={useWindowDimensions().width < 980 ? ['top'] : []} style={{ flex: 1, backgroundColor: theme.background }}>{children}</SafeAreaView>;
}
function useDetailStyle() { const mobile = useWindowDimensions().width < 980; return [styles.page, mobile && { paddingHorizontal: 20, paddingTop: 24 }]; }
export function ParentAttendance() {
  const p = useParent();
  const theme = useTheme();
  const contentStyle = useDetailStyle();
  return <Frame><FlatList data={p.child?.attendance ?? []} keyExtractor={a => a.id} contentContainerStyle={contentStyle} refreshControl={<RefreshControl refreshing={p.loading && !!p.summary} onRefresh={() => void p.refresh()} />} ListHeaderComponent={<><Heading title="Every day is a little step forward" subtitle="A simple look at this month’s attendance." />{p.child ? <Panel style={{ marginBottom: 24 }}><Label size={13} color={theme.muted}>{p.summary?.month}</Label><Label size={42} weight="800" color={C.teal}>{percent(p.child.attendancePercent)}</Label><Label size={13} color={theme.muted}>Showing up, learning and growing.</Label></Panel> : <ParentState />}</>}
    ListEmptyComponent={p.child ? <Panel><Label color={theme.muted}>No classes recorded this month yet. Check back after the next class.</Label></Panel> : null}
    renderItem={({ item }) => <View style={[styles.spread, { backgroundColor: theme.surface, padding: 18, borderBottomWidth: 1, borderColor: theme.border }]}><View style={[styles.row, { gap: 12 }]}><Icon name="calendar-outline" size={17} color={theme.muted} /><Label size={13}>{formatParentDate(item.date)}</Label></View><View style={{ backgroundColor: item.status === 'absent' || item.status === 'late' ? C.warningSoft : C.tealSoft, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5 }}><Label size={11} color={item.status === 'absent' || item.status === 'late' ? C.duesInk : C.teal}>{item.status === 'present' ? 'Attended' : item.status === 'absent' ? 'Missed class' : item.status === 'late' ? 'Arrived late' : 'On leave'}</Label></View></View>} />
  </Frame>;
}
export function ParentFees() {
  const p = useParent();
  const theme = useTheme();
  const contentStyle = useDetailStyle();
  return <Frame><FlatList data={p.child?.terms ?? []} keyExtractor={t => t.id} contentContainerStyle={[...contentStyle, { gap: 15 }]} refreshControl={<RefreshControl refreshing={p.loading && !!p.summary} onRefresh={() => void p.refresh()} />} ListHeaderComponent={<><Heading title="One less thing to think about" subtitle="Your child’s fees, with everything in its place." />{!p.child ? <ParentState /> : <Panel style={{ marginBottom: 8 }}><Label color={theme.muted} size={12}>Due now</Label><Label size={40} color={p.child.dueNow ? C.duesInk : C.teal} weight="800">{currency(p.child.dueNow)}</Label><Label size={13} color={theme.muted}>{p.child.totalOutstanding === 0 ? 'Everything is taken care of. Thank you.' : p.child.dueNow === 0 ? 'Nothing overdue. You can plan ahead for the next term.' : 'You can settle the outstanding term below.'}</Label></Panel>}</>}
    ListEmptyComponent={p.child ? <Panel><Label color={theme.muted}>No fees have been assigned yet.</Label></Panel> : null}
    renderItem={({ item }) => <Panel><View style={styles.spread}><View><Label size={16} weight="700">{item.label}</Label><Label size={12} color={theme.muted}>Due {formatParentDate(item.dueDate)}</Label></View><Label size={22} weight="800" color={theme.primary}>{currency(item.remaining || item.paidAmount)}</Label></View><View style={[styles.spread, { marginTop: 20 }]}><View style={[styles.row, { gap: 6 }]}><Icon name={item.remaining ? 'time-outline' : 'checkmark-circle'} size={16} color={item.remaining ? C.duesInk : C.teal} /><Label size={12} color={item.remaining ? C.duesInk : C.teal}>{item.remaining ? 'To be paid' : 'Fully paid'}</Label></View>{item.remaining > 0 && p.child && <Action label="Pay now" onPress={() => p.open({ type: 'payment', term: item, child: p.child! })} />}</View></Panel>} />
  </Frame>;
}
export function ParentNotices() {
  const p = useParent();
  const theme = useTheme();
  const [filter, setFilter] = useState('All');
  const contentStyle = useDetailStyle();
  const updates = p.child?.updates.filter(u => filter === 'All' || u.kind === filter.toLowerCase()) ?? [];
  return <Frame><FlatList data={updates} keyExtractor={u => u.id} contentContainerStyle={contentStyle} refreshControl={<RefreshControl refreshing={p.loading && !!p.summary} onRefresh={() => void p.refresh()} />} ListHeaderComponent={<><Heading title="A little window into their day" subtitle="Homework, class updates and things worth knowing." /><View style={{ flexDirection: 'row', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>{['All', 'Homework', 'Attendance', 'Notice'].map(label => <Pressable key={label} accessibilityRole="tab" accessibilityState={{ selected: filter === label }} accessibilityLabel={`Filter ${label}`} onPress={() => setFilter(label)} style={{ paddingHorizontal: 17, paddingVertical: 10, borderRadius: 22, backgroundColor: filter === label ? C.primary : theme.surface, borderWidth: 1, borderColor: filter === label ? C.primary : theme.border }}><Label size={12} weight="600" color={filter === label ? C.surface : theme.muted}>{label === 'Notice' ? 'Notices' : label}</Label></Pressable>)}</View></>}
    renderItem={({ item }) => <Panel style={{ marginBottom: 14, paddingTop: 0, paddingBottom: 0 }}><UpdateRow update={item} last /></Panel>}
    ListEmptyComponent={p.child ? <Panel><Icon name="checkmark-circle-outline" color={C.teal} size={27} /><Label size={16} weight="700" style={{ marginTop: 12 }}>All quiet for now</Label><Label size={13} color={theme.muted} style={{ marginTop: 5 }}>When there’s something to share, you’ll find it here.</Label></Panel> : <ParentState />} />
  </Frame>;
}
