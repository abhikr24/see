import React from 'react';
import { Pressable, StyleSheet, Text as NativeText, View, type TextProps, type ViewStyle } from 'react-native';
import { Image } from 'expo-image';
import Ionicons from '@expo/vector-icons/Ionicons';
import { C, FONT, useTheme } from '@/lib/theme';

export function Label({ children, size = 14, weight = '500', color, style, ...rest }: TextProps & { size?: number; weight?: '400' | '500' | '600' | '700' | '800'; color?: string }) {
  const theme = useTheme();
  return <NativeText {...rest} style={[{ fontFamily: FONT.body, fontSize: size, lineHeight: size * 1.55, fontWeight: weight, color: color ?? theme.text, fontVariant: ['tabular-nums'] }, style]}>{children}</NativeText>;
}
const photos: Record<string, number> = {
  'bundled:aarav': require('../../../assets/images/aarav.jpg'),
  'bundled:siya': require('../../../assets/images/siya.jpg'),
  'bundled:rahul': require('../../../assets/images/rahul.jpg'),
};
export function Photo({ uri, name, size = 48 }: { uri?: string | null; name: string; size?: number }) {
  const source = uri && photos[uri];
  return <View style={{ height: size, width: size, borderRadius: size / 2, overflow: 'hidden', backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
    {source ? <Image source={source} contentFit="cover" transition={160} style={{ width: size, height: size }} accessibilityLabel={`${name}’s photo`} /> : <Label color={C.primary} weight="700" size={size / 3}>{name.split(' ').map(n => n[0]).slice(0, 2).join('')}</Label>}
  </View>;
}
export function Icon({ name, size = 20, color = C.primary }: { name: React.ComponentProps<typeof Ionicons>['name']; size?: number; color?: string }) { return <Ionicons name={name} size={size} color={color} />; }
export function Panel({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const theme = useTheme();
  return <View style={[styles.panel, { backgroundColor: theme.surface, borderColor: theme.border }, style]}>{children}</View>;
}
export function Action({ label, onPress, secondary = false, disabled = false, icon }: { label: string; onPress: () => void; secondary?: boolean; disabled?: boolean; icon?: React.ComponentProps<typeof Ionicons>['name'] }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress} style={({ pressed }) => ({ minHeight: 44, paddingHorizontal: 22, paddingVertical: 10, borderRadius: 13, backgroundColor: secondary ? C.track : C.primary, opacity: pressed || disabled ? 0.65 : 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 })}>
    <Label size={13} weight="700" color={secondary ? C.primary : C.surface}>{label}</Label>{icon ? <Icon name={icon} size={17} color={secondary ? C.primary : C.surface} /> : null}
  </Pressable>;
}
export const styles = StyleSheet.create({ panel: { borderRadius: 20, borderWidth: 1, padding: 24 }, row: { flexDirection: 'row', alignItems: 'center' }, spread: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, page: { width: '100%', maxWidth: 1160, alignSelf: 'center', paddingHorizontal: 36, paddingTop: 30, paddingBottom: 32 }, eyebrow: { letterSpacing: 1.6, textTransform: 'uppercase' }, iconTile: { width: 42, height: 42, borderRadius: 13, alignItems: 'center', justifyContent: 'center' } });
export const currency = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
export const percent = (n: number | null) => n === null ? '—' : `${Math.round(n)}%`;
