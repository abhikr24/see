import React from 'react';
import { Redirect } from 'expo-router';
import { useBackend } from '@/core/backend';
import { BatchShell } from '@/features/batches/BatchShell';
/** Explicit offline preview; never grants access to a live tenant. */
export default function BatchPreviewLayout() {
  const { backend } = useBackend();
  if (backend.name !== 'memory') return <Redirect href={'/(auth)/login' as never}/>;
  return <BatchShell/>;
}
