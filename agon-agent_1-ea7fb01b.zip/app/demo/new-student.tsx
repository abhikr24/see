import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { AddStudentScreen } from '@/features/students/screens/AddStudentScreen';
export default function DemoStudentForm() {
  const { batchId } = useLocalSearchParams<{ batchId?: string }>();
  return <AddStudentScreen initialBatchId={batchId}/>;
}
