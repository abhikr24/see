import React from 'react';
import { FlatList, View } from 'react-native';
import { router } from 'expo-router';
import { useStudentRoster } from '@/features/students/hooks/useStudentRoster';
import { Action, Person, State, Text, panel, row } from '@/features/batches/ui';
import { C } from '@/lib/theme';
/** Reuses the student domain to verify batch chips without an auth bypass. */
export default function DemoStudents() {
  const q = useStudentRoster();
  return <FlatList data={q.rows ?? []} keyExtractor={(s) => s.id} refreshing={q.refreshing} onRefresh={() => void q.refresh()} contentContainerStyle={{ padding: 30, maxWidth: 1000, width: '100%', alignSelf: 'center' }} ListHeaderComponent={<View style={{ gap: 22, marginBottom: 25 }}><View style={{ ...row, justifyContent: 'space-between' }}><Text variant="h1">Students</Text><Action label="Add student" icon="add" onPress={() => router.push('/demo/new-student' as never)}/></View><Text variant="caption" c={C.secondary}>Every student. The right batch.</Text><State loading={q.loading} error={q.error} retry={() => void q.refresh()}/></View>} ListEmptyComponent={!q.loading ? <State empty message="No students yet."/> : null} renderItem={({ item }) => <View style={{ ...row, ...panel, padding: 17, marginBottom: 10, gap: 12 }}><Person name={item.fullName}/><View style={{ flex: 1 }}><Text variant="caption" weight={700}>{item.fullName}</Text><Text style={{ fontSize: 11, marginTop: 5 }} c={C.secondary}>{item.batchName}</Text></View><Text variant="caption" c={C.teal}>{item.attendancePercent ?? 0}%</Text></View>}/>;
}
