import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { C } from '@/lib/theme';
import { useBatchForm } from './useBatchForm';
import { Action, DAYS, Field, Icon, Person, State, Text, panel, row } from './ui';
export function BatchCreateScreen() {
  const f = useBatchForm();
  const { draft: d, patch } = f;
  const wide = useWindowDimensions().width > 700;
  const [picker, setPicker] = useState<'subject' | 'teacher' | null>(null);
  const subjects = f.options.data?.subjects ?? [];
  const teachers = f.options.data?.teachers ?? [];
  const selectedSubject = subjects.find((s) => s.id === d.subjectId);
  const selectedTeacher = teachers.find((t) => t.id === d.teacherId);
  return <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <FlatList data={[]} renderItem={() => null} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: wide ? 38 : 20, maxWidth: 850, width: '100%', alignSelf: 'center', paddingBottom: 45 }} ListHeaderComponent={<>
      <Pressable onPress={() => router.back()} style={{ ...row, gap: 7, marginBottom: 23 }}><Icon name="arrow-back" size={17}/><Text variant="caption" c={C.secondary}>Back to batches</Text></Pressable>
      <View style={{ ...row, gap: 13, marginBottom: 27 }}><View style={{ width: 48, height: 48, backgroundColor: C.navySoft, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }}><Icon name="albums-outline" color={C.primary} size={24}/></View><View><Text style={{ fontSize: 28, fontFamily: 'Heading' }} weight={800}>Create a batch</Text><Text variant="caption" c={C.secondary} style={{ marginTop: 7 }}>A great group starts here.</Text></View></View>
      <State loading={f.options.loading && !f.options.data} error={f.options.error?.message} retry={() => void f.options.refetch()}/>
      <View style={{ ...panel, padding: wide ? 28 : 20, gap: 24 }}>
        <Text variant="label" c={C.muted}>01 · THE BASICS</Text>
        <Field label="Batch name" placeholder="e.g. Class 10-B" value={d.name} onChangeText={(name) => patch({ name })} autoFocus/>
        <View style={{ gap: 9 }}><Text variant="caption" weight={700}>Subject</Text><Pressable onPress={() => setPicker('subject')} style={{ ...row, borderWidth: 1, borderColor: C.hairline, borderRadius: 12, padding: 14, justifyContent: 'space-between' }}><Text variant="caption" c={selectedSubject ? C.ink : C.muted}>{selectedSubject?.name ?? 'Choose a subject'}</Text><Icon name="chevron-down" size={16}/></Pressable></View>
        <View style={{ gap: 9 }}><Text variant="caption" weight={700}>Teacher</Text><Pressable onPress={() => setPicker('teacher')} style={{ ...row, borderWidth: 1, borderColor: C.hairline, borderRadius: 12, padding: 12, gap: 10 }}><Person name={selectedTeacher?.fullName ?? 'Teacher'} uri={selectedTeacher?.photoUrl} size={28}/><Text variant="caption" c={selectedTeacher ? C.ink : C.muted} style={{ flex: 1 }}>{selectedTeacher?.fullName ?? 'Assign a teacher'}</Text><Icon name="chevron-down" size={16}/></Pressable></View>
        <View style={{ height: 1, backgroundColor: C.hairline }}/><Text variant="label" c={C.muted}>02 · SCHEDULE</Text>
        <View style={{ gap: 11 }}><Text variant="caption" weight={700}>Teaching days</Text><View style={{ ...row, gap: 7, flexWrap: 'wrap' }}>{[1,2,3,4,5,6,0].map((day) => <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: d.days.includes(day) }} key={day} onPress={() => patch({ days: d.days.includes(day) ? d.days.filter((x) => x !== day) : [...d.days,day] })} style={{ minWidth: wide ? 60 : 35, minHeight: 42, paddingHorizontal: wide ? 13 : 8, alignItems: 'center', justifyContent: 'center', borderRadius: 10, borderWidth: 1, borderColor: d.days.includes(day) ? C.primary : C.hairline, backgroundColor: d.days.includes(day) ? C.primary : C.surface }}><Text style={{ fontSize: wide ? 12 : 10 }} weight={600} c={d.days.includes(day) ? C.surface : C.secondary}>{DAYS[day]}</Text></Pressable>)}</View></View>
        <View style={{ ...row, gap: 16 }}><Field label="Start time · 24-hour" placeholder="16:00" keyboardType="numbers-and-punctuation" value={d.startsAt} onChangeText={(startsAt) => patch({ startsAt })}/><Field label="End time · 24-hour" placeholder="17:00" keyboardType="numbers-and-punctuation" value={d.endsAt} onChangeText={(endsAt) => patch({ endsAt })}/></View>
        <View style={{ height: 1, backgroundColor: C.hairline }}/><Text variant="label" c={C.muted}>03 · FEES & CAPACITY</Text>
        <View style={{ gap: 10 }}><Text variant="caption" weight={700}>Fee plan</Text><View style={{ ...row, backgroundColor: C.canvas, borderRadius: 12, padding: 5 }}>{(['monthly', 'quarterly', 'term'] as const).map((p) => <Pressable key={p} onPress={() => patch({ feePlan: p })} style={{ flex: 1, paddingVertical: 12, backgroundColor: p === d.feePlan ? C.surface : C.transparent, borderRadius: 9, alignItems: 'center', borderWidth: p === d.feePlan ? 1 : 0, borderColor: C.hairline }}><Text variant="caption" weight={p === d.feePlan ? 700 : 500} c={p === d.feePlan ? C.primary : C.secondary} style={{ textTransform: 'capitalize' }}>{p}</Text></Pressable>)}</View></View>
        <View style={{ ...row, gap: 16 }}><Field label="Fee amount (₹)" value={d.amount} placeholder="0" keyboardType="decimal-pad" onChangeText={(amount) => patch({ amount })}/><Field label="Capacity" value={d.capacity} placeholder="e.g. 30" keyboardType="number-pad" onChangeText={(capacity) => patch({ capacity })}/></View>
        <View style={{ ...row, gap: 8, backgroundColor: C.navySoft, borderRadius: 10, padding: 13 }}><Icon name="information-circle-outline" color={C.primary} size={16}/><Text style={{ fontSize: 11 }} c={C.primary}>Students will see this in their Fees tab.</Text></View>
        {f.error && <Text accessibilityRole="alert" variant="caption" c={C.danger}>{f.error}</Text>}
        <View style={{ ...row, justifyContent: 'flex-end', gap: 12 }}><Action label="Cancel" soft onPress={() => router.back()}/><Action label={f.saving ? 'Creating…' : 'Create batch'} disabled={f.saving || !f.options.data} icon="add" onPress={() => void f.submit()}/></View>
      </View>
    </>}/>
    <Modal visible={picker !== null} transparent animationType="slide" onRequestClose={() => setPicker(null)}><View style={{ flex: 1, backgroundColor: C.scrim, justifyContent: wide ? 'center' : 'flex-end' }}><Pressable accessibilityLabel="Close picker" onPress={() => setPicker(null)} style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}/><View style={{ ...panel, borderRadius: 24, padding: 24, maxWidth: 500, width: '100%', alignSelf: 'center', maxHeight: '75%' }}><View style={{ ...row, justifyContent: 'space-between', marginBottom: 20 }}><Text variant="title">{picker === 'subject' ? 'Choose a subject' : 'Choose a teacher'}</Text><Pressable onPress={() => setPicker(null)} accessibilityLabel="Close picker"><Icon name="close"/></Pressable></View>
      <FlatList data={picker === 'subject' ? subjects.map((s) => ({ id: s.id, name: s.name, detail: s.code, photo: null })) : teachers.map((t) => ({ id: t.id, name: t.fullName, detail: t.specialization ?? 'Teacher', photo: t.photoUrl }))} keyExtractor={(item) => item.id} ListEmptyComponent={<State empty message={picker === 'teacher' ? 'No active teacher memberships yet.' : 'No subjects available.'}/>} renderItem={({ item }) => <Pressable onPress={() => { patch(picker === 'subject' ? { subjectId: item.id } : { teacherId: item.id }); setPicker(null); }} style={{ ...row, gap: 12, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: C.hairline }}>{picker === 'teacher' && <Person name={item.name} uri={item.photo}/>}<View style={{ flex: 1 }}><Text variant="caption" weight={700}>{item.name}</Text><Text style={{ fontSize: 11, marginTop: 5 }} c={C.muted}>{item.detail}</Text></View>{(d.subjectId === item.id || d.teacherId === item.id) && <Icon name="checkmark-circle" color={C.teal}/>}</Pressable>}/>
    </View></View></Modal>
  </KeyboardAvoidingView>;
}
