import React, { useState } from 'react';
import { FlatList, Modal, Pressable, View, useWindowDimensions } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { C } from '@/lib/theme';
import { useBatchDetail, useBatchPath, useBatchWorkspace } from './useBatchWorkspace';
import { BatchDetailDialogs, type BatchDialog } from './BatchDetailDialogs';
import { Action, Icon, Person, State, Text, panel, row, schedule, time } from './ui';
export function BatchDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const q = useBatchWorkspace();
  const d = useBatchDetail(id);
  const base = useBatchPath();
  const b = q.data?.find((x) => x.id === id);
  const wide = useWindowDimensions().width > 700;
  const [tab, setTab] = useState('Students');
  const [dialog, setDialog] = useState<BatchDialog>(null);
  const [selected, setSelected] = useState<{ title: string; text: string | null } | null>(null);
  if (!b) return <View style={{ padding: 30 }}><State loading={q.loading} error={q.error?.message} retry={() => void q.refetch()} empty={!q.loading && !q.error} message="This batch could not be found."/></View>;
  const isArchived = b.status === 'archived';
  const rows: { id: string; title: string; sub: string; pct: number | null; photo: string | null; text: string | null }[] = tab === 'Students' ? (d.roster.data ?? []).map((s) => ({ id: s.studentId, title: s.fullName, sub: `Roll ${s.rollNumber ?? '—'} · ${s.attendanceTotal} attendance records`, pct: s.attendancePct, photo: s.photoUrl, text: null as string | null })) : tab === 'Attendance'
    ? (d.register.data?.items ?? []).map((s) => ({ id: s.id, title: new Date(`${s.date}T12:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }), sub: `Period ${s.period} · ${s.status}`, pct: null, photo: null, text: s.notes }))
    : (d.content.data ?? []).map((s) => ({ id: s.id, title: s.title, sub: s.type, pct: null, photo: null, text: s.text }));
  const current = tab === 'Students' ? d.roster : tab === 'Attendance' ? d.register : d.content;
  const archive = async () => { const result = await q.archive.mutate(id); if (result.ok) { setDialog(null); router.replace(base as never); } };
  return <View style={{ flex: 1 }}>
    <FlatList data={rows} keyExtractor={(item) => item.id} refreshing={current.loading && !!current.data} onRefresh={() => { void current.refetch(); void q.refetch(); }} contentContainerStyle={{ padding: wide ? 36 : 20, maxWidth: 1080, width: '100%', alignSelf: 'center', paddingBottom: isArchived ? 30 : 100 }}
      ListHeaderComponent={<>
        <View style={{ ...row, justifyContent: 'space-between', marginBottom: 21 }}><Pressable onPress={() => router.replace(base as never)} style={{ ...row, gap: 7 }}><Icon name="arrow-back" size={17}/><Text variant="caption" c={C.secondary}>All batches</Text></Pressable>{!isArchived && <Pressable onPress={() => setDialog('archive')} style={{ ...row, gap: 7, padding: 8 }}><Icon name="archive-outline" size={15}/><Text style={{ fontSize: 11 }} c={C.secondary}>Archive batch</Text></Pressable>}</View>
        <View style={{ backgroundColor: C.primary, borderRadius: 21, padding: wide ? 30 : 23, gap: 16 }}>
          <View style={{ ...row, gap: 8 }}><Text variant="label" c={C.navyPale}>{b.subjectName}</Text>{isArchived && <Text variant="label" c={C.warning}>· Archived</Text>}</View>
          <Text c={C.surface} style={{ fontSize: 30, fontFamily: 'Heading', letterSpacing: -.7 }} weight={800}>{b.name}</Text>
          <View style={{ ...row, gap: 8, flexWrap: 'wrap' }}><Icon name="calendar-outline" size={15} color={C.navyPale}/><Text variant="caption" c={C.navyPale} style={{ fontSize: 11 }}>{schedule(b.days)} · {time(b.startsAt)} – {time(b.endsAt)}</Text></View>
          <View style={{ ...row, gap: 9 }}><Person name={b.teacherName} uri={b.teacherPhoto} size={29}/><Text variant="caption" c={C.surface}>{b.teacherName}</Text><Text style={{ fontSize: 10 }} c={C.navyPale}>· Teacher</Text></View>
          <View style={{ ...row, gap: 10, marginTop: 6 }}>{[{ n: b.studentCount, l: 'Students', c: C.primary }, { n: `${b.attendancePct}%`, l: 'Attendance', c: C.teal }, { n: b.pendingFees, l: 'Pending fees', c: C.duesInk }].map((s) => <View key={s.l} style={{ flex: 1, backgroundColor: C.surface, padding: wide ? 16 : 12, borderRadius: 12, gap: 5 }}><Text tabular style={{ fontSize: wide ? 25 : 22 }} weight={800} c={s.c}>{s.n}</Text><Text style={{ fontSize: 10 }} c={C.secondary}>{s.l}</Text></View>)}</View>
        </View>
        <View style={{ ...row, borderBottomWidth: 1, borderBottomColor: C.hairline, marginTop: 23, marginBottom: 22, gap: wide ? 38 : 26 }}>{['Students', 'Attendance', 'Content'].map((t) => <Pressable key={t} onPress={() => setTab(t)} style={{ paddingVertical: 16, borderBottomWidth: 2, borderBottomColor: tab === t ? C.primary : C.transparent }}><Text variant="caption" weight={tab === t ? 700 : 500} c={tab === t ? C.primary : C.secondary}>{t}</Text></Pressable>)}</View>
        {tab === 'Students' && !isArchived && <View style={{ ...row, gap: wide ? 12 : 6, marginBottom: 27 }}>{[{ title: 'Take attendance', icon: 'checkbox-outline' as const, bg: C.navySoft, fg: C.primary, dialog: 'attendance' as const }, { title: 'Assign homework', icon: 'book-outline' as const, bg: C.accentSoft, fg: C.accent, dialog: 'homework' as const }, { title: 'Share material', icon: 'share-outline' as const, bg: C.tealSoft, fg: C.teal, dialog: 'material' as const }].map((a) => <Pressable key={a.title} onPress={() => setDialog(a.dialog)} style={{ flex: 1, backgroundColor: a.bg, borderRadius: 13, paddingVertical: 17, alignItems: 'center', gap: 10 }}><Icon name={a.icon} color={a.fg} size={21}/><Text style={{ fontSize: wide ? 12 : 9 }} weight={700} c={a.fg}>{a.title}</Text></Pressable>)}</View>}
        <View style={{ ...row, justifyContent: 'space-between', marginBottom: 17 }}><Text variant="title">{tab === 'Students' ? 'Student roster' : tab === 'Attendance' ? 'Attendance register' : 'Learning content'}</Text>{tab === 'Students' && !isArchived && <Pressable onPress={() => router.push((base === '/demo' ? `/demo/new-student?batchId=${id}` : `/(owner)/students/new?batchId=${id}`) as never)}><Text variant="caption" weight={700} c={C.primary}>+ Add student</Text></Pressable>}</View>
        <State loading={current.loading && !current.data} error={current.error?.message} retry={() => void current.refetch()}/>
      </>}
      renderItem={({ item }) => <Pressable disabled={tab !== 'Content'} onPress={() => setSelected({ title: item.title, text: item.text })} style={{ ...row, ...panel, borderRadius: 13, paddingHorizontal: wide ? 20 : 14, paddingVertical: 16, marginBottom: 9, gap: 13 }}>
        {tab === 'Students' ? <Person name={item.title} uri={item.photo} size={37}/> : <View style={{ backgroundColor: C.navySoft, padding: 10, borderRadius: 10 }}><Icon name={tab === 'Attendance' ? 'calendar-outline' : item.sub === 'Homework' ? 'book-outline' : 'document-text-outline'} color={C.primary} size={20}/></View>}
        <View style={{ flex: 1 }}><Text variant="caption" weight={700}>{item.title}</Text><Text style={{ fontSize: 10, marginTop: 7 }} c={C.muted}>{item.sub}</Text></View>
        {item.pct !== null ? <View style={{ alignItems: 'flex-end', gap: 5 }}><Text tabular variant="caption" weight={700} c={item.pct >= 75 ? C.teal : C.danger}>{item.pct}%</Text><Text style={{ fontSize: 9 }} c={C.muted}>attendance</Text></View> : tab === 'Content' ? <Icon name="chevron-forward" size={15}/> : <View style={{ ...row, gap: 5 }}><Icon name="checkmark-circle-outline" size={15} color={C.teal}/><Text style={{ fontSize: 10 }} c={C.teal}>Recorded</Text></View>}
      </Pressable>}
      ListEmptyComponent={!current.loading && !current.error ? <State empty message={tab === 'Students' ? 'Your batch is ready. Add your first student.' : tab === 'Attendance' ? 'No attendance recorded yet.' : 'No content yet. Share something worth learning.'}/> : null}/>
    {!isArchived && <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, backgroundColor: C.surface, borderTopWidth: 1, borderTopColor: C.hairline, alignItems: wide ? 'flex-end' : 'stretch' }}><Action label="Take attendance" icon="checkbox-outline" disabled={!d.roster.data?.length} onPress={() => setDialog('attendance')}/></View>}
    <BatchDetailDialogs key={dialog ?? 'closed'} dialog={dialog} close={() => setDialog(null)} detail={d} archive={() => void archive()} archiving={q.archive.loading}/>
    <Modal visible={!!selected} transparent animationType="fade" onRequestClose={() => setSelected(null)}><Pressable onPress={() => setSelected(null)} style={{ flex: 1, backgroundColor: C.scrim, justifyContent: 'center', padding: 25 }}><View style={{ ...panel, padding: 26, maxWidth: 600, width: '100%', alignSelf: 'center', gap: 20 }}><Text variant="h2">{selected?.title}</Text><Text style={{ lineHeight: 25 }} c={C.secondary}>{selected?.text || 'No additional notes.'}</Text><Action label="Close" onPress={() => setSelected(null)}/></View></Pressable></Modal>
  </View>;
}
