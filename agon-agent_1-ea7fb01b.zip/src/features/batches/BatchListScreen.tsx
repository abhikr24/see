import React, { useMemo, useState } from 'react';
import { FlatList, Modal, Pressable, TextInput, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import Animated, { FadeIn } from 'react-native-reanimated';
import { C } from '@/lib/theme';
import { BatchCard } from './BatchCard';
import { BatchHero } from './BatchHero';
import { useBatchPath, useBatchWorkspace } from './useBatchWorkspace';
import { Action, Icon, State, Text, panel, row } from './ui';
export function BatchListScreen() {
  const q = useBatchWorkspace();
  const base = useBatchPath();
  const width = useWindowDimensions().width;
  const two = width >= 700;
  const [search, setSearch] = useState('');
  const [subject, setSubject] = useState('All subjects');
  const [filter, setFilter] = useState(false);
  const [archived, setArchived] = useState(false);
  const active = useMemo(() => (q.data ?? []).filter((b) => b.status !== 'archived'), [q.data]);
  const history = (q.data ?? []).filter((b) => b.status === 'archived');
  const visible = active.filter((b) => b.name.toLowerCase().includes(search.toLowerCase()) && (subject === 'All subjects' || b.subjectName === subject));
  const create = () => router.push(`${base}/new` as never);
  const isFiltered = !!search || subject !== 'All subjects';
  const data = [...visible.map((batch) => ({ id: batch.id, batch })), ...(!isFiltered && !q.loading && !q.error ? [{ id: 'create', batch: null }] : [])];
  return <Animated.View entering={FadeIn.duration(250)} style={{ flex: 1 }}>
    <FlatList key={two ? 'two' : 'one'} data={data} numColumns={two ? 2 : 1} keyExtractor={(item) => item.id}
      refreshing={q.loading && !!q.data} onRefresh={() => void q.refetch()}
      columnWrapperStyle={two ? { gap: 20, marginBottom: 20 } : undefined}
      contentContainerStyle={{ padding: width >= 1000 ? 42 : 20, paddingTop: 29, maxWidth: 1250, width: '100%', alignSelf: 'center', paddingBottom: 30 }}
      ListHeaderComponent={<>
        <View style={{ ...row, gap: 7, marginBottom: 25 }}><Text variant="label" c={C.muted} style={{ fontSize: 9, letterSpacing: 1.6 }}>ACADEMICS</Text><Icon name="chevron-forward" size={10} color={C.muted}/><Text variant="label" c={C.primary} style={{ fontSize: 9, letterSpacing: 1.6 }}>BATCHES</Text></View>
        <View style={{ ...row, justifyContent: 'space-between', marginBottom: 27, gap: 10 }}><View style={{ flex: 1 }}><Text variant="h1" style={{ fontSize: 30, fontFamily: 'Heading', letterSpacing: -1 }}>Batches</Text><Text variant="caption" c={C.secondary} style={{ marginTop: 9, fontSize: 12 }}>Great learning starts with the right group.</Text></View><Action label={width > 500 ? 'Create batch' : 'Create'} icon="add" onPress={create}/></View>
        <BatchHero batches={active}/>
        <View style={{ ...row, justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: C.hairline, marginBottom: 22 }}><View style={{ ...row, borderBottomWidth: 2, borderBottomColor: C.primary, paddingBottom: 15, gap: 8 }}><Text variant="caption" weight={700} c={C.primary}>Active batches</Text><View style={{ backgroundColor: C.navySoft, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 }}><Text style={{ fontSize: 10 }} weight={700} c={C.primary}>{active.length}</Text></View></View><Text style={{ fontSize: 10, paddingBottom: 15 }} c={C.muted}>Organised for better learning</Text></View>
        <View style={{ ...row, gap: 12, marginBottom: 23 }}>
          <View style={{ ...row, ...panel, borderRadius: 10, flex: 1, paddingHorizontal: 13, height: 43, gap: 9 }}><Icon name="search-outline" size={17} color={C.muted}/><TextInput accessibilityLabel="Search batches" placeholder="Search batches..." value={search} onChangeText={setSearch} placeholderTextColor={C.muted} style={{ flex: 1, fontSize: 12, fontFamily: 'Jakarta', color: C.ink, height: '100%', outlineWidth: 0 } as never}/>{!!search && <Pressable accessibilityLabel="Clear search" onPress={() => setSearch('')}><Icon name="close" size={16}/></Pressable>}</View>
          <Pressable onPress={() => setFilter(true)} style={{ ...row, ...panel, borderRadius: 10, height: 43, paddingHorizontal: 13, gap: 15 }}><Icon name="options-outline" size={16}/><Text style={{ fontSize: 11 }} c={C.secondary}>{subject}</Text><Icon name="chevron-down" size={12}/></Pressable>
        </View>
        <State loading={q.loading && !q.data} error={q.error?.message} retry={() => void q.refetch()}/>
      </>}
      renderItem={({ item, index }) => <View style={{ flex: 1, marginBottom: two ? 0 : 16 }}>
        {item.batch ? <BatchCard batch={item.batch} index={index} onPress={() => router.push(`${base}/${item.id}` as never)}/> :
          <Pressable onPress={create} accessibilityLabel="Create a new batch" style={({ pressed }) => ({ flex: 1, minHeight: 279, borderRadius: 20, borderWidth: 1.5, borderStyle: 'dashed', borderColor: pressed ? C.primary : C.cardDash, backgroundColor: pressed ? C.navySoft : C.createCanvas, padding: 25, alignItems: 'center', justifyContent: 'center', gap: 12 })}>
            <View style={{ width: 54, height: 54, borderRadius: 17, backgroundColor: C.surface, borderWidth: 1, borderColor: C.hairline, alignItems: 'center', justifyContent: 'center', marginBottom: 3 }}><Icon name="add" size={25} color={C.primary}/></View>
            <Text variant="caption" weight={700} c={C.primary}>Make room for more potential</Text><Text style={{ fontSize: 11, lineHeight: 19, textAlign: 'center', maxWidth: 230 }} c={C.secondary}>{'A new group, a fresh start. Set up your\nnext batch in just a few taps.'}</Text><Text style={{ fontSize: 11, marginTop: 7 }} weight={700} c={C.primary}>Create a batch  →</Text>
          </Pressable>}
      </View>}
      ListEmptyComponent={!q.loading && !q.error ? <State empty message="No batches match your search."/> : null}
      ListFooterComponent={<View style={{ marginTop: two ? 6 : 10 }}>
        <Pressable onPress={() => setArchived(!archived)} style={{ ...row, ...panel, backgroundColor: C.archiveCanvas, paddingHorizontal: 19, paddingVertical: 18, borderRadius: 12, gap: 11 }}><Icon name="archive-outline" size={17} color={C.muted}/><Text variant="caption" c={C.secondary}>Archived batches</Text><Text style={{ fontSize: 10, backgroundColor: C.track, borderRadius: 5, paddingHorizontal: 7, paddingVertical: 3 }} c={C.muted}>{history.length}</Text><View style={{ flex: 1 }}/>{width > 650 && <Text style={{ fontSize: 11 }} c={C.muted}>Past batches. Every memory, preserved.</Text>}<Icon name={archived ? 'chevron-up' : 'chevron-down'} size={15} color={C.muted}/></Pressable>
        {archived && <FlatList data={history} keyExtractor={(b) => b.id} ListEmptyComponent={<Text variant="caption" c={C.muted} style={{ padding: 20 }}>No archived batches. Completed batches will live here.</Text>} renderItem={({ item }) => <Pressable onPress={() => router.push(`${base}/${item.id}` as never)} style={{ ...row, padding: 20, borderBottomWidth: 1, borderBottomColor: C.hairline }}><Text variant="caption" c={C.secondary}>{item.name}</Text><View style={{ flex: 1 }}/><Text variant="caption" c={C.muted}>View history →</Text></Pressable>}/>}
        <View style={{ ...row, justifyContent: 'center', gap: 7, marginTop: 25 }}><Icon name="shield-checkmark-outline" size={12} color={C.muted}/><Text style={{ fontSize: 10 }} c={C.muted}>Less managing. More mentoring.</Text></View>
      </View>}/>
    <Modal visible={filter} transparent animationType="fade" onRequestClose={() => setFilter(false)}><Pressable onPress={() => setFilter(false)} style={{ flex: 1, backgroundColor: C.scrim, justifyContent: 'center', padding: 24 }}><View style={{ ...panel, padding: 24, maxWidth: 440, width: '100%', alignSelf: 'center', gap: 18 }}><Text variant="title">Filter by subject</Text><FlatList data={['All subjects', ...new Set(active.map((b) => b.subjectName))]} keyExtractor={(s) => s} renderItem={({ item }) => <Pressable onPress={() => { setSubject(item); setFilter(false); }} style={{ ...row, paddingVertical: 16, justifyContent: 'space-between' }}><Text c={item === subject ? C.primary : C.secondary}>{item}</Text>{item === subject && <Icon name="checkmark" color={C.primary}/>}</Pressable>}/></View></Pressable></Modal>
  </Animated.View>;
}
