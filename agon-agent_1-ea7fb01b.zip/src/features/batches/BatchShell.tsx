import React from 'react';
import { Pressable, View, useWindowDimensions } from 'react-native';
import { router, Slot, useSegments } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C } from '@/lib/theme';
import { Icon, Person, Text, row } from './ui';
import { useBatchPath } from './useBatchWorkspace';
import { useBatchIdentity } from './useBatchIdentity';

const nav = [
  { label: 'Overview', icon: 'grid-outline', path: '/(owner)' },
  { label: 'Students', icon: 'people-outline', path: '/(owner)/students' },
  { label: 'Batches', icon: 'albums-outline', path: '/(owner)/batches' },
  { label: 'Attendance', icon: 'calendar-outline', path: '/(owner)/attendance' },
  { label: 'Fees & payments', icon: 'wallet-outline', path: '/(owner)/fees' },
  { label: 'Notices', icon: 'megaphone-outline', path: '/(owner)/notices' },
] as const;
export function BatchShell() {
  const wide = useWindowDimensions().width >= 1000;
  const base = useBatchPath();
  const identity = useBatchIdentity().data;
  const ownerName = identity?.owner.fullName ?? 'Owner';
  const institute = identity?.institute;
  const segments = useSegments() as string[];
  const studentPage = segments.includes('students');
  const go = (path: string) => {
    if (base === '/demo' && path.endsWith('/batches')) router.push('/demo' as never);
    else if (base === '/demo' && path.endsWith('/students')) router.push('/demo/students' as never);
    else router.push(path as never);
  };
  return <SafeAreaView edges={['top', 'bottom']} style={{ flex: 1, backgroundColor: C.canvas }}>
    <View style={{ flex: 1, flexDirection: 'row' }}>
      {wide && <View style={{ width: 238, backgroundColor: C.surface, borderRightWidth: 1, borderRightColor: C.hairline, paddingHorizontal: 22, paddingTop: 35 }}>
        <View style={{ ...row, gap: 11, paddingHorizontal: 8, marginBottom: 42 }}>
          <View style={{ backgroundColor: C.accent, width: 35, height: 38, borderRadius: 11, alignItems: 'center', justifyContent: 'center' }}><Icon name="school" color={C.surface} size={23}/></View>
          <Text style={{ fontSize: 25, fontFamily: 'Heading', letterSpacing: -1 }} weight={800} c={C.primary}>GuruFlow<Text c={C.accent}>.</Text></Text>
        </View>
        <Text variant="label" c={C.muted} style={{ fontSize: 10, marginLeft: 14, marginBottom: 15, letterSpacing: 1.7 }}>WORKSPACE</Text>
        <View style={{ gap: 7 }}>{nav.map((n) => {
          const selected = studentPage ? n.label === 'Students' : n.label === 'Batches';
          return <Pressable key={n.label} onPress={() => go(n.path)} style={({ pressed }) => ({ ...row, gap: 13, height: 48, paddingHorizontal: 14, borderRadius: 11, backgroundColor: selected ? C.primary : pressed ? C.canvas : C.transparent })}>
            <Icon name={n.icon} size={19} color={selected ? C.surface : C.secondary}/><Text style={{ fontSize: 13 }} weight={selected ? 700 : 500} c={selected ? C.surface : C.secondary}>{n.label}</Text>
            {selected && <View style={{ width: 5, height: 5, backgroundColor: C.accent, borderRadius: 5, marginLeft: 'auto' }}/>}</Pressable>;
        })}</View>
        <View style={{ flex: 1 }}/>
        <View style={{ backgroundColor: C.canvas, borderRadius: 14, padding: 16, gap: 9, marginBottom: 24 }}>
          <View style={{ ...row, gap: 7 }}><View style={{ width: 6, height: 6, backgroundColor: C.teal, borderRadius: 3 }}/><Text style={{ fontSize: 11 }} weight={700} c={C.primary}>A little less admin.</Text></View>
          <Text variant="caption" style={{ fontSize: 11, lineHeight: 18 }} c={C.secondary}>{'A little more teaching.\nThat’s the GuruFlow way.'}</Text>
        </View>
        <View style={{ ...row, paddingVertical: 23, borderTopWidth: 1, borderTopColor: C.hairline, gap: 10 }}><Person name={ownerName} size={35}/><View><Text variant="caption" weight={700}>{ownerName}</Text><Text style={{ fontSize: 11, marginTop: 4 }} c={C.muted}>Institute owner</Text></View><Icon name="shield-checkmark-outline" size={18}/></View>
      </View>}
      <View style={{ flex: 1 }}>
        <View style={{ ...row, minHeight: wide ? 86 : 67, paddingHorizontal: wide ? 42 : 20, backgroundColor: C.surface, borderBottomWidth: 1, borderBottomColor: C.hairline }}>
          <View style={{ width: 34, height: 34, borderRadius: 10, borderWidth: 1, borderColor: C.hairline, alignItems: 'center', justifyContent: 'center', marginRight: 11 }}><Icon name="sunny-outline" color={C.accent} size={21}/></View>
          <View><Text variant="caption" weight={700}>{institute?.name ?? 'Your institute'}</Text><Text style={{ fontSize: 10, marginTop: 4 }} c={C.muted}>{[institute?.city, institute?.state].filter(Boolean).join(', ')} <Text style={{ fontSize: 10 }} c={C.muted}> · </Text> {institute?.code}</Text></View>
          <View style={{ flex: 1 }}/>
          {wide && <View style={{ ...row, gap: 7, backgroundColor: C.canvas, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 7 }}><Icon name="calendar-outline" size={14}/><Text style={{ fontSize: 11 }} c={C.secondary}>Academic year {institute?.settings.academicYear ?? '—'}</Text></View>}
          <View style={{ width: 1, height: 27, backgroundColor: C.hairline, marginHorizontal: wide ? 22 : 12 }}/><Person name={ownerName} size={32}/>
        </View>
        <Slot/>
        {!wide && <View style={{ ...row, justifyContent: 'space-around', backgroundColor: C.surface, borderTopWidth: 1, borderTopColor: C.hairline, paddingVertical: 10 }}>{nav.slice(0, 5).map((n) => <Pressable accessibilityLabel={n.label} key={n.label} onPress={() => go(n.path)} style={{ gap: 4, alignItems: 'center', padding: 5 }}><Icon name={n.icon} color={n.label === 'Batches' ? C.primary : C.muted}/><Text style={{ fontSize: 9 }} c={n.label === 'Batches' ? C.primary : C.muted}>{n.label.split(' ')[0]}</Text></Pressable>)}</View>}
      </View>
    </View>
  </SafeAreaView>;
}
