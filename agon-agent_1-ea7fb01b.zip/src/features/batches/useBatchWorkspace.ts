import { useState } from 'react';
import { useSegments } from 'expo-router';
import type { Batch, BatchSummary, NewEntity, AttendanceStatus } from '@/core/contracts/models';
import { useDomainMutation, useDomainQuery, useListEditor, placeholder } from '@/core/hooks/domain';
import { rosterCache } from '@/features/students/cache';

export function useBatchPath() {
  const segments = useSegments() as string[];
  return segments[0] === 'demo' ? '/demo' : '/(owner)/batches';
}
export function useBatchWorkspace() {
  const query = useDomainQuery('batches', ['summaries'], (b, i) => b.batches.listSummaries(i));
  const edit = useListEditor<BatchSummary>('batches', ['summaries']);
  const create = useDomainMutation<NewEntity<Batch, 'name' | 'academicYear'>, Batch>(
    ['batches', 'students', 'timetable'], async (b, i, input) => {
      const batch = await b.batches.create(i, input);
      rosterCache.write(rosterCache.rows ?? [], [...rosterCache.batches, batch]);
      return batch;
    }, { success: 'Batch created. Ready for your students.', failure: 'Could not create batch' },
    (input) => edit((items) => [...items, placeholder<BatchSummary>({ ...input,
      studentCount: 0, attendanceTotal: 0, attendancePct: 0, pendingFees: 0, subjectName: 'New batch', teacherName: 'Unassigned', status: 'active' }, null)]),
  );
  const archive = useDomainMutation<string, void>(['batches', 'students'], async (b, i, id) => {
    await b.batches.remove(i, id);
    rosterCache.write(rosterCache.rows ?? [], rosterCache.batches.filter((batch) => batch.id !== id));
  }, { success: 'Batch archived. All history is preserved.' },
  (id) => edit((items) => items.map((b) => b.id === id ? { ...b, status: 'archived' } : b)));
  return { ...query, create, archive };
}
export function useBatchOptions() {
  return useDomainQuery('batches', ['options'], async (b, i) => {
    const [subjects, memberships, teachers] = await Promise.all([
      b.subjects.list(i, { limit: 200 }), b.memberships.list(i, { where: { role: 'teacher', status: 'active' }, limit: 200 }),
      b.staff.listTeachers(i, { limit: 200 }),
    ]);
    const eligible = new Set(memberships.items.map((m) => m.userId));
    return { subjects: subjects.items.filter((s) => s.isActive), teachers: teachers.items.filter((t) => t.userId && eligible.has(t.userId)) };
  });
}
export function useBatchDetail(id: string) {
  const roster = useDomainQuery('batches', ['roster', id], (b, i) => b.batches.listRoster(i, id));
  const register = useDomainQuery('attendance', ['batch-register', id], (b, i) =>
    b.attendance.listSessions(i, { where: { batchId: id }, limit: 200, sort: { field: 'date', direction: 'desc' } }));
  const content = useDomainQuery('batches', ['content', id], async (b, i) => {
    const [a, m] = await Promise.all([b.assignments.list(i, { where: { batchId: id }, limit: 200 }), b.materials.list(i, { where: { batchId: id }, limit: 200 })]);
    return [...a.items.map((x) => ({ id: x.id, title: x.title, text: x.instructions, type: 'Homework' })),
      ...m.items.map((x) => ({ id: x.id, title: x.title, text: x.description, type: 'Material' }))];
  });
  const [marks, setMarks] = useState<Record<string, AttendanceStatus>>({});
  const prepareQuery = useDomainQuery('attendance', ['today-sheet', id], async (b, i) => {
    const today = new Date().toISOString().slice(0, 10);
    const sessions = await b.attendance.listSessions(i, { where: { batchId: id, date: today }, limit: 200 });
    const session = sessions.items.find((s) => s.date === today && s.period === 1);
    return session ? b.attendance.getSheet(i, session.id) : null;
  });
  const effectiveMarks: Record<string, AttendanceStatus> = { ...Object.fromEntries((prepareQuery.data?.records ?? []).map((r) => [r.studentId, r.status])), ...marks };
  const save = useDomainMutation<void, unknown>(['attendance', 'batches', 'students'], async (b, i) => {
    return b.attendance.saveSheet(i, { batchId: id, date: new Date().toISOString().slice(0, 10),
      records: (roster.data ?? []).map((r) => ({ studentId: r.studentId, status: effectiveMarks[r.studentId] ?? 'present' })) });
  }, { success: 'Attendance saved. Percentages are up to date.' });
  const publish = useDomainMutation<{ type: 'homework' | 'material'; title: string; text: string }, unknown>(
    ['batches', 'assignments', 'materials'], async (b, i, input) => input.type === 'homework'
      ? b.assignments.create(i, { batchId: id, title: input.title.trim(), instructions: input.text, status: 'published' })
      : b.materials.create(i, { batchId: id, title: input.title.trim(), description: input.text, materialType: 'notes', isPublished: true }),
    { success: 'Published to this batch.' },
  );
  return { roster, register, content, marks: effectiveMarks, setMarks, save, publish, prepareQuery };
}
