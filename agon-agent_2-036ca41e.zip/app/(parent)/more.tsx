import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Card, Screen, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';

const ITEMS = [
  {
    key: 'performance',
    title: 'Performance',
    detail: 'Marks, rank and a one-page report card',
    icon: 'trophy-outline' as const,
    route: '/(parent)/performance',
  },
  {
    key: 'home',
    title: 'Overview',
    detail: 'Your child’s day at a glance',
    icon: 'home-outline' as const,
    route: '/(parent)',
  },
  {
    key: 'attendance',
    title: 'Attendance',
    detail: 'Heatmap, absences and a note to the teacher',
    icon: 'calendar-outline' as const,
    route: '/(parent)/attendance',
  },
  {
    key: 'fees',
    title: 'Fees & payments',
    detail: 'Terms, receipts and payment history',
    icon: 'wallet-outline' as const,
    route: '/(parent)/fees',
  },
  {
    key: 'leave',
    title: 'Request leave',
    detail: 'Tell the teacher and the office, with the classes it covers',
    icon: 'bed-outline' as const,
    route: '/(parent)/leave',
  },
  {
    key: 'meetings',
    title: 'Meet a teacher',
    detail: 'Ask for a meeting and see the teacher’s reply',
    icon: 'people-outline' as const,
    route: '/(parent)/meetings',
  },
  {
    key: 'notices',
    title: 'Notices',
    detail: 'Homework, class updates and things worth knowing',
    icon: 'megaphone-outline' as const,
    route: '/(parent)/notices',
  },
];

export default function ParentMoreRoute() {
  return (
    <Screen title="More" subtitle="Family tools sit with the rest of the portal" safeTop={false} tabBarInset={96}>
      <View style={{ gap: 12 }}>
        {ITEMS.map((item) => (
          <Card
            key={item.key}
            pad={16}
            onPress={() => router.push(item.route as never)}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View
                style={{
                  width: 46,
                  height: 46,
                  borderRadius: R.field,
                  backgroundColor: C.navySoft,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Ionicons name={item.icon} size={22} color={C.primary} />
              </View>
              <View style={{ flex: 1, gap: 3 }}>
                <Text variant="title" weight={700}>{item.title}</Text>
                <Text variant="caption" c={C.secondary}>{item.detail}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={C.muted} />
            </View>
          </Card>
        ))}
      </View>
    </Screen>
  );
}
