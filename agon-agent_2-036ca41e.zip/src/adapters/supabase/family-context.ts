import type { ID } from '../../core/contracts/models';
import { BackendError } from '../../core/contracts/errors';
import { handleSupabaseError, supabase } from './client';

/** Who is asking, and which children that parent may see. Resolved from the database, never from the client. */
export interface ParentScope {
  userId: ID;
  guardianIds: ID[];
  childIds: ID[];
  /** Guardian id for each linked student, used as the meeting's guardian. */
  guardianByStudent: Map<string, string>;
}

export async function currentUserId(): Promise<ID> {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw handleSupabaseError(error);
  if (!data.user) throw new BackendError('UNAUTHENTICATED', 'Sign in to continue.');
  return data.user.id;
}

/** Active parent membership → guardian → parent_links, all institute-scoped. Fails closed. */
export async function parentScope(instituteId: ID): Promise<ParentScope> {
  const userId = await currentUserId();
  const { data: memberships, error: mError } = await supabase
    .from('memberships').select('id').eq('institute_id', instituteId).eq('user_id', userId).eq('role', 'parent').eq('status', 'active');
  if (mError) throw handleSupabaseError(mError);
  if (!memberships?.length) throw new BackendError('FORBIDDEN', 'An active parent membership is required');
  const { data: guardians, error: gError } = await supabase
    .from('guardians').select('id').eq('institute_id', instituteId).in('membership_id', memberships.map((m) => String(m.id)));
  if (gError) throw handleSupabaseError(gError);
  const guardianIds = (guardians ?? []).map((g) => String(g.id));
  const scope: ParentScope = { userId, guardianIds, childIds: [], guardianByStudent: new Map() };
  if (!guardianIds.length) return scope;
  const { data: links, error: lError } = await supabase
    .from('parent_links').select('student_id, guardian_id').eq('institute_id', instituteId).in('guardian_id', guardianIds);
  if (lError) throw handleSupabaseError(lError);
  for (const link of links ?? []) {
    scope.guardianByStudent.set(String(link.student_id), String(link.guardian_id));
  }
  scope.childIds = [...scope.guardianByStudent.keys()];
  return scope;
}

/** Any read or write for one child starts here. A child who is not linked is NOT_FOUND. */
export async function assertLinkedChild(instituteId: ID, studentId: ID): Promise<ParentScope> {
  const scope = await parentScope(instituteId);
  if (!scope.childIds.includes(studentId)) throw new BackendError('NOT_FOUND', 'That child could not be found');
  return scope;
}

/** The caller's highest staff role in this institute, or null. */
export async function staffRole(instituteId: ID): Promise<'owner' | 'admin' | 'teacher' | null> {
  const userId = await currentUserId();
  const { data, error } = await supabase
    .from('memberships').select('role').eq('institute_id', instituteId).eq('user_id', userId).eq('status', 'active');
  if (error) throw handleSupabaseError(error);
  const roles = (data ?? []).map((m) => String(m.role));
  if (roles.includes('owner')) return 'owner';
  if (roles.includes('admin')) return 'admin';
  if (roles.includes('teacher')) return 'teacher';
  return null;
}

/** Batches a student is actively enrolled in. */
export async function activeBatchIds(instituteId: ID, studentId: ID): Promise<string[]> {
  const { data, error } = await supabase
    .from('batch_students').select('batch_id').eq('institute_id', instituteId).eq('student_id', studentId).eq('status', 'active');
  if (error) throw handleSupabaseError(error);
  return [...new Set((data ?? []).map((row) => String(row.batch_id)))];
}

/** Teacher profiles who take at least one of these batches, from the timetable or the batch's own teacher. */
export async function teacherIdsForBatches(instituteId: ID, batchIds: string[]): Promise<Set<string>> {
  const ids = new Set<string>();
  if (!batchIds.length) return ids;
  const [{ data: periods, error: pError }, { data: batches, error: bError }] = await Promise.all([
    supabase.from('timetables').select('teacher_id').eq('institute_id', instituteId).in('batch_id', batchIds).not('teacher_id', 'is', null),
    supabase.from('batches').select('teacher_id').eq('institute_id', instituteId).in('id', batchIds).not('teacher_id', 'is', null),
  ]);
  if (pError) throw handleSupabaseError(pError);
  if (bError) throw handleSupabaseError(bError);
  for (const row of [...(periods ?? []), ...(batches ?? [])]) ids.add(String(row.teacher_id));
  return ids;
}
