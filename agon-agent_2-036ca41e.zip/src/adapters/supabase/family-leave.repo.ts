import type { FamilyLeaveType, ID, ISODate, LeavePreview, StudentLeaveRequest } from '../../core/contracts/models';
import type { FamilyRepo } from '../../core/contracts/ports';
import { BackendError } from '../../core/contracts/errors';
import { inclusiveDays, isIsoDate, previewLeaveClasses, validateLeaveInput } from '../../core/contracts/family';
import { handleSupabaseError, supabase } from './client';
import { activeBatchIds, assertLinkedChild, currentUserId, staffRole, teacherIdsForBatches } from './family-context';

const todayIso = (): ISODate => new Date().toISOString().slice(0, 10);

function mapLeave(row: Record<string, unknown>): StudentLeaveRequest {
  return {
    id: String(row.id), instituteId: String(row.institute_id), studentId: String(row.student_id), requestedBy: String(row.requested_by),
    leaveType: row.leave_type as FamilyLeaveType, fromDate: String(row.from_date), toDate: String(row.to_date), days: Number(row.days),
    reason: String(row.reason), affectedBatchIds: ((row.affected_batch_ids as string[] | null) ?? []).map(String),
    affectedClassCount: Number(row.affected_class_count), status: row.status as StudentLeaveRequest['status'],
    reviewNote: row.review_note ? String(row.review_note) : null, reviewedAt: row.reviewed_at ? String(row.reviewed_at) : null,
    createdAt: String(row.created_at), updatedAt: String(row.updated_at),
  };
}

/** The classes a leave would cover, from the child's live timetable. */
async function leavePreview(instituteId: ID, studentId: ID, fromDate: ISODate, toDate: ISODate): Promise<LeavePreview> {
  const batchIds = await activeBatchIds(instituteId, studentId);
  if (!batchIds.length) return { days: inclusiveDays(fromDate, toDate), classCount: 0, classes: [] };
  const [{ data: periods, error: pError }, { data: batches, error: bError }, { data: subjects, error: sError }] = await Promise.all([
    supabase.from('timetables').select('batch_id, subject_id, day_of_week, valid_from, valid_to').eq('institute_id', instituteId).in('batch_id', batchIds),
    supabase.from('batches').select('id, name').eq('institute_id', instituteId).in('id', batchIds),
    supabase.from('subjects').select('id, name').eq('institute_id', instituteId),
  ]);
  if (pError) throw handleSupabaseError(pError);
  if (bError) throw handleSupabaseError(bError);
  if (sError) throw handleSupabaseError(sError);
  const preview = previewLeaveClasses({
    fromDate, toDate,
    periods: (periods ?? []).map((p) => ({
      batchId: String(p.batch_id), subjectId: p.subject_id ? String(p.subject_id) : null, dayOfWeek: Number(p.day_of_week),
      validFrom: p.valid_from ? String(p.valid_from) : null, validTo: p.valid_to ? String(p.valid_to) : null,
    })),
    batches: (batches ?? []).map((b) => ({ id: String(b.id), name: String(b.name) })),
    subjects: (subjects ?? []).map((s) => ({ id: String(s.id), name: String(s.name) })),
  });
  return preview;
}

export function familyLeaveRepo(): Pick<FamilyRepo, 'previewLeave' | 'submitLeave' | 'leaveRequests' | 'leaveQueue'> {
  return {
    async previewLeave(instituteId, studentId, fromDate, toDate) {
      await assertLinkedChild(instituteId, studentId);
      if (!isIsoDate(fromDate) || !isIsoDate(toDate)) throw new BackendError('VALIDATION', 'Choose valid leave dates');
      return leavePreview(instituteId, studentId, fromDate, toDate);
    },

    async submitLeave(instituteId, input) {
      const scope = await assertLinkedChild(instituteId, input.studentId);
      const reason = validateLeaveInput(input, todayIso());
      const preview = await leavePreview(instituteId, input.studentId, input.fromDate, input.toDate);
      const affectedBatchIds = [...new Set(preview.classes.map((c) => c.batchId))];
      const { data, error } = await supabase.from('student_leave_requests').insert({
        institute_id: instituteId, student_id: input.studentId, requested_by: scope.userId, leave_type: input.leaveType,
        from_date: input.fromDate, to_date: input.toDate, days: inclusiveDays(input.fromDate, input.toDate), reason,
        affected_batch_ids: affectedBatchIds, affected_class_count: preview.classCount, status: 'pending',
      }).select().single();
      if (error) throw handleSupabaseError(error);
      // Reaches the affected teachers and every active owner.
      const teacherIds = await teacherIdsForBatches(instituteId, affectedBatchIds);
      const [{ data: teachers, error: tError }, { data: owners, error: oError }] = await Promise.all([
        teacherIds.size ? supabase.from('teacher_profiles').select('user_id').eq('institute_id', instituteId).in('id', [...teacherIds]) : Promise.resolve({ data: [], error: null }),
        supabase.from('memberships').select('user_id').eq('institute_id', instituteId).eq('role', 'owner').eq('status', 'active'),
      ]);
      if (tError) throw handleSupabaseError(tError);
      if (oError) throw handleSupabaseError(oError);
      const recipients = new Set<string>([...(teachers ?? []), ...(owners ?? [])].map((r) => String(r.user_id)).filter(Boolean));
      if (recipients.size) {
        const { error: nError } = await supabase.from('notifications').insert([...recipients].map((userId) => ({
          institute_id: instituteId, user_id: userId, type: 'student_leave_requested', title: 'Leave request for a student',
          body: `${input.fromDate} to ${input.toDate} · ${preview.classCount} class${preview.classCount === 1 ? '' : 'es'}`,
          data: { screen: 'leave-queue', leaveRequestId: data.id }, channel: 'in_app',
        })));
        if (nError) throw handleSupabaseError(nError);
      }
      return mapLeave(data);
    },

    async leaveRequests(instituteId, studentId) {
      await assertLinkedChild(instituteId, studentId);
      const { data, error } = await supabase.from('student_leave_requests').select('*')
        .eq('institute_id', instituteId).eq('student_id', studentId).order('created_at', { ascending: false });
      if (error) throw handleSupabaseError(error);
      return (data ?? []).map(mapLeave);
    },

    async leaveQueue(instituteId) {
      const role = await staffRole(instituteId);
      if (role === 'owner' || role === 'admin') {
        const { data, error } = await supabase.from('student_leave_requests').select('*')
          .eq('institute_id', instituteId).order('created_at', { ascending: false });
        if (error) throw handleSupabaseError(error);
        return (data ?? []).map(mapLeave);
      }
      if (role !== 'teacher') throw new BackendError('FORBIDDEN', 'Only a teacher or the owner can see the leave queue');
      const userId = await currentUserId();
      const { data: teacher, error: tError } = await supabase.from('teacher_profiles').select('id')
        .eq('institute_id', instituteId).eq('user_id', userId).eq('status', 'active').maybeSingle();
      if (tError) throw handleSupabaseError(tError);
      if (!teacher) throw new BackendError('FORBIDDEN', 'Teacher profile not found');
      const { data: batches, error: bError } = await supabase.from('batches').select('id')
        .eq('institute_id', instituteId).eq('teacher_id', teacher.id);
      if (bError) throw handleSupabaseError(bError);
      const { data: periods, error: pError } = await supabase.from('timetables').select('batch_id')
        .eq('institute_id', instituteId).eq('teacher_id', teacher.id);
      if (pError) throw handleSupabaseError(pError);
      const mine = new Set<string>();
      for (const batch of batches ?? []) mine.add(String(batch.id));
      for (const period of periods ?? []) mine.add(String(period.batch_id));
      const { data, error } = await supabase.from('student_leave_requests').select('*')
        .eq('institute_id', instituteId).order('created_at', { ascending: false });
      if (error) throw handleSupabaseError(error);
      return (data ?? []).map(mapLeave).filter((r) => r.affectedBatchIds.some((id) => mine.has(id)));
    },
  };
}

