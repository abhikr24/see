import type { FamilyMeeting, FamilyPayment, FamilyReceipt, FamilyTeacher, ID, ISODate } from '../../core/contracts/models';
import type { FamilyRepo } from '../../core/contracts/ports';
import { BackendError } from '../../core/contracts/errors';
import { assertReceiptMatchesPayment, validateMeetingInput } from '../../core/contracts/family';
import { handleSupabaseError, supabase } from './client';
import { activeBatchIds, assertLinkedChild, teacherIdsForBatches } from './family-context';
import { familyLeaveRepo } from './family-leave.repo';

const todayIso = (): ISODate => new Date().toISOString().slice(0, 10);

/** The family's view of fees, receipts, teachers and meetings. Every call starts with the linked-child check. */
export function familyRepo(): FamilyRepo {
  const leave = familyLeaveRepo();
  return {
    ...leave,

    async paymentHistory(instituteId: ID, studentId: ID): Promise<FamilyPayment[]> {
      await assertLinkedChild(instituteId, studentId);
      const { data: payments, error } = await supabase.from('payments').select('*')
        .eq('institute_id', instituteId).eq('student_id', studentId).eq('status', 'completed').order('paid_at', { ascending: false });
      if (error) throw handleSupabaseError(error);
      const rows = payments ?? [];
      const installmentIds = [...new Set(rows.map((p) => p.installment_id).filter(Boolean).map(String))];
      const paymentIds = rows.map((p) => String(p.id));
      const [{ data: installments, error: iError }, { data: receipts, error: rError }] = await Promise.all([
        installmentIds.length ? supabase.from('installments').select('id, label').eq('institute_id', instituteId).in('id', installmentIds) : Promise.resolve({ data: [], error: null }),
        paymentIds.length ? supabase.from('receipts').select('id, payment_id, receipt_no').eq('institute_id', instituteId).in('payment_id', paymentIds) : Promise.resolve({ data: [], error: null }),
      ]);
      if (iError) throw handleSupabaseError(iError);
      if (rError) throw handleSupabaseError(rError);
      const labels = new Map((installments ?? []).map((i) => [String(i.id), String(i.label)]));
      const receiptByPayment = new Map((receipts ?? []).map((r) => [String(r.payment_id), r]));
      return rows.map((p): FamilyPayment => {
        const receipt = receiptByPayment.get(String(p.id));
        return {
          id: String(p.id), studentId, installmentId: p.installment_id ? String(p.installment_id) : null,
          label: labels.get(String(p.installment_id)) ?? 'Fee payment', amount: Number(p.amount),
          method: p.method, referenceNo: p.reference_no ? String(p.reference_no) : null, paidAt: String(p.paid_at),
          receiptId: receipt ? String(receipt.id) : null, receiptNo: receipt ? String(receipt.receipt_no) : null,
        };
      });
    },

    async receipt(instituteId: ID, receiptId: ID): Promise<FamilyReceipt> {
      const { data: receipt, error } = await supabase.from('receipts').select('*').eq('institute_id', instituteId).eq('id', receiptId).maybeSingle();
      if (error) throw handleSupabaseError(error);
      if (!receipt) throw new BackendError('NOT_FOUND', 'That receipt could not be found');
      await assertLinkedChild(instituteId, String(receipt.student_id));
      const [{ data: payment, error: pError }, { data: institute, error: iError }, { data: student, error: sError }] = await Promise.all([
        supabase.from('payments').select('*').eq('institute_id', instituteId).eq('id', receipt.payment_id).single(),
        supabase.from('institutes').select('name, city').eq('id', instituteId).single(),
        supabase.from('student_profiles').select('full_name').eq('institute_id', instituteId).eq('id', receipt.student_id).single(),
      ]);
      if (pError) throw handleSupabaseError(pError);
      if (iError) throw handleSupabaseError(iError);
      if (sError) throw handleSupabaseError(sError);
      const { data: installment } = payment.installment_id
        ? await supabase.from('installments').select('label').eq('institute_id', instituteId).eq('id', payment.installment_id).maybeSingle()
        : { data: null };
      const view = {
        receiptId: String(receipt.id), receiptNo: String(receipt.receipt_no), studentId: String(receipt.student_id),
        studentName: String(student.full_name), instituteName: String(institute.name), instituteCity: institute.city ? String(institute.city) : null,
        termLabel: installment ? String(installment.label) : 'Fee payment', amount: Number(receipt.amount), method: payment.method,
        referenceNo: payment.reference_no ? String(payment.reference_no) : null, paymentId: String(payment.id),
        paidAt: String(payment.paid_at), issuedAt: String(receipt.issued_at),
      } as FamilyReceipt;
      // The receipt must describe its payment exactly, to the paisa, before the family sees it.
      assertReceiptMatchesPayment({ paymentId: view.paymentId, amount: view.amount }, { id: String(payment.id), amount: Number(payment.amount) });
      return view;
    },

    async teachers(instituteId: ID, studentId: ID): Promise<FamilyTeacher[]> {
      await assertLinkedChild(instituteId, studentId);
      const batchIds = await activeBatchIds(instituteId, studentId);
      if (!batchIds.length) return [];
      const [{ data: periods, error: pError }, { data: batches, error: bError }, { data: subjects, error: sError }] = await Promise.all([
        supabase.from('timetables').select('batch_id, subject_id, teacher_id').eq('institute_id', instituteId).in('batch_id', batchIds).not('teacher_id', 'is', null),
        supabase.from('batches').select('id, name').eq('institute_id', instituteId).in('id', batchIds),
        supabase.from('subjects').select('id, name').eq('institute_id', instituteId),
      ]);
      if (pError) throw handleSupabaseError(pError);
      if (bError) throw handleSupabaseError(bError);
      if (sError) throw handleSupabaseError(sError);
      const teacherIds = [...new Set((periods ?? []).map((p) => String(p.teacher_id)))];
      const { data: teachers, error: tError } = teacherIds.length
        ? await supabase.from('teacher_profiles').select('id, full_name, user_id').eq('institute_id', instituteId).in('id', teacherIds)
        : { data: [], error: null };
      if (tError) throw handleSupabaseError(tError);
      const teacherById = new Map((teachers ?? []).map((t) => [String(t.id), t]));
      const batchName = new Map((batches ?? []).map((b) => [String(b.id), String(b.name)]));
      const subjectName = new Map((subjects ?? []).map((s) => [String(s.id), String(s.name)]));
      const seen = new Map<string, FamilyTeacher>();
      for (const period of periods ?? []) {
        const teacher = teacherById.get(String(period.teacher_id));
        const key = `${period.teacher_id}:${period.batch_id}`;
        if (!teacher || seen.has(key)) continue;
        seen.set(key, {
          id: String(teacher.id), name: String(teacher.full_name), userId: teacher.user_id ? String(teacher.user_id) : null,
          subjectName: subjectName.get(String(period.subject_id)) ?? 'Class', batchId: String(period.batch_id),
          batchName: batchName.get(String(period.batch_id)) ?? '',
        });
      }
      return [...seen.values()].sort((a, b) => a.name.localeCompare(b.name));
    },

    async meetings(instituteId: ID, studentId: ID): Promise<FamilyMeeting[]> {
      await assertLinkedChild(instituteId, studentId);
      const { data, error } = await supabase.from('meeting_requests').select('*')
        .eq('institute_id', instituteId).eq('student_id', studentId).order('created_at', { ascending: false });
      if (error) throw handleSupabaseError(error);
      const rows = data ?? [];
      const teacherIds = [...new Set(rows.map((m) => String(m.teacher_id)))];
      const { data: teachers, error: tError } = teacherIds.length
        ? await supabase.from('teacher_profiles').select('id, full_name').eq('institute_id', instituteId).in('id', teacherIds)
        : { data: [], error: null };
      if (tError) throw handleSupabaseError(tError);
      const names = new Map((teachers ?? []).map((t) => [String(t.id), String(t.full_name)]));
      return rows.map((m): FamilyMeeting => ({
        id: String(m.id), studentId, teacherId: String(m.teacher_id), teacherName: names.get(String(m.teacher_id)) ?? 'Teacher',
        preferredAt: m.preferred_at ? String(m.preferred_at) : null, status: m.status, responseNote: m.response_note ? String(m.response_note) : null,
        respondedAt: m.responded_at ? String(m.responded_at) : null, reason: m.reason ? String(m.reason) : null, createdAt: String(m.created_at),
      }));
    },

    async requestMeeting(instituteId: ID, input): Promise<FamilyMeeting> {
      const scope = await assertLinkedChild(instituteId, input.studentId);
      const note = validateMeetingInput(input, todayIso());
      const batchIds = await activeBatchIds(instituteId, input.studentId);
      if (!(await teacherIdsForBatches(instituteId, batchIds)).has(input.teacherId)) {
        throw new BackendError('FORBIDDEN', 'That teacher does not take your child');
      }
      const { data: teacher, error: tError } = await supabase.from('teacher_profiles').select('id, full_name, user_id')
        .eq('institute_id', instituteId).eq('id', input.teacherId).single();
      if (tError) throw handleSupabaseError(tError);
      const { data, error } = await supabase.from('meeting_requests').insert({
        institute_id: instituteId, student_id: input.studentId, teacher_id: input.teacherId,
        guardian_id: scope.guardianByStudent.get(input.studentId) ?? null, requested_by: scope.userId,
        reason: note, preferred_at: `${input.preferredDate}T00:00:00.000Z`, mode: 'in_person', status: 'pending',
      }).select().single();
      if (error) throw handleSupabaseError(error);
      if (teacher.user_id) {
        const { error: nError } = await supabase.from('notifications').insert({
          institute_id: instituteId, user_id: teacher.user_id, type: 'meeting_requested', title: 'A parent asked to meet you',
          body: `${input.preferredDate}${note ? ` · ${note}` : ''}`, data: { screen: 'meetings', meetingId: data.id }, channel: 'in_app',
        });
        if (nError) throw handleSupabaseError(nError);
      }
      return {
        id: String(data.id), studentId: input.studentId, teacherId: input.teacherId, teacherName: String(teacher.full_name),
        preferredAt: String(data.preferred_at), status: data.status, responseNote: null, respondedAt: null, reason: note, createdAt: String(data.created_at),
      };
    },
  };
}

