import React from 'react';
import { RegisterInstituteScreen } from '@/features/onboarding/screens/RegisterInstituteScreen';

export default function InstituteSetupRoute() {
  return <RegisterInstituteScreen />;
}
