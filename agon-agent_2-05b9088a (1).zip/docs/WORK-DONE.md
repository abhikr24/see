# Work done

## 2026-11-12 · Convert App Shell from React Navigation to `expo-router`

Converted the application shell to `expo-router` (`"main": "expo-router/entry"`) while keeping the design system, contracts, adapters, and database unchanged.

**Changed**
- `package.json` & `app.json` – added `expo-router` and `expo-linking`, set `"main": "expo-router/entry"`, and added `"expo-router"` to `app.json` plugins.
- `app/_layout.tsx` – created root layout with `GestureHandlerRootView` → `SafeAreaProvider` → `BackendProvider` → `Stack` (`headerShown: false`).
- `app/index.tsx` – dev index screen linking to `/dev/components` and `/dev/contract-check` via `expo-router`.
- `app/(auth)/index.tsx`, `app/(pending)/index.tsx`, `app/(owner)/index.tsx`, `app/(teacher)/index.tsx`, `app/(student)/index.tsx`, `app/(parent)/index.tsx` – placeholder route group screens using `Screen` + `Card` noting the prompt that builds each.
- Deleted `App.tsx`, `index.ts`, and `src/core/ui/theme.ts`; pointed `app/dev/contract-check.tsx` at `src/lib/theme.ts` and removed `darkPrimary` (`#818CF8`).

**Verified**
- `npm run typecheck` – zero errors.
- `grep -rn "@react-navigation" app/ src/` – zero matches.
- `grep -rn "818CF8" src` – zero matches.
- Single theme file remains at `src/lib/theme.ts`.

## 2026-11-12 · Complete 35-component Design System & `/dev/components` QA Gallery

Completed the GuruFlow UI primitive library under `src/components/ui/` so no future feature screen needs to invent a new component.

**Preserved & Refined (19 existing primitives)**
- `Text`, `Button`, `Input`, `Card`, `Chip`, `Badge`, `Avatar`, `IconBox`, `Divider`, `ProgressBar`, `Ring`, `Sheet` (upgraded to `@gorhom/bottom-sheet`), `Screen`, `GradientHeader`, `OverlapCard`, `TabBar`, `Skeleton` (`ListSkeleton`), `EmptyState` (wired to `EmptyArt`), `ErrorState`.

**Added (16 new primitives in `src/components/ui/`)**
- `StatCard` – label + big tabular numeral + optional delta badge and trend colour (`up`, `down`, `warning`, `neutral`).
- `ListRow` – 44pt leading slot, title, subtitle, right slot, optional chevron, and 68pt row rhythm.
- `SegmentedControl` – pill track, animated Reanimated thumb, 2–4 options with optional counts.
- `DateField` – `DD/MM/YYYY` date field opening a `@gorhom/bottom-sheet` calendar sheet (`react-native-calendars`).
- `Select` – labelled dropdown opening a searchable `@gorhom/bottom-sheet` with `SearchBar`.
- `Stepper` – `−/+` numeric stepper with `min`/`max`, step increment, and Indian-grouped `₹` or custom suffix.
- `Table` – sticky header row, 1px hairline data rows, right-aligned tabular numeric columns, and optional summary footer row.
- `Heatmap` – 7-column month grid of rounded squares with `attendance` and `intensity` variants plus legend.
- `AvatarStack` – overlapping circular avatars with surface ring border and tabular `+N` overflow chip.
- `Tabs` – `primary` (navy) and `accent` (saffron) underline tabs with optional counts for detail screens.
- `SearchBar` – search input with clear button, loading indicator, and configurable debounce callback.
- `Toast` – `success`, `error`, and `info` notifications with auto-dismiss timer and configurable bottom offset.
- `ConfirmDialog` – destructive action confirmation modal/inline card with optional typed confirmation phrase (`confirmText`).
- `TrendLine` – flat, gridline-free thin line chart (`react-native-gifted-charts`) with the last data point highlighted in saffron (`C.accent`).
- `BarChart` – flat, thin vertical bar chart (`react-native-gifted-charts`) with one bar highlighted in saffron (`C.accent`).
- `EmptyArt` – soft tinted circle + inner card + icon (and optional corner badge), used by `EmptyState` and `ErrorState`.

**Updated**
- `app/dev/components.tsx` – renders all 35 primitives across every variant and state, grouped into 11 numbered sections using canonical Sunrise Coaching Classes (`SUNRISE-PAT`) seed data.
- `src/lib/theme.ts` – single source of truth for all colours, radii, spacing, and shadows.

**Verified**
- `npx tsc --noEmit` – zero TypeScript errors.
- Zero hex literals outside `src/lib/theme.ts` across the entire codebase.
- Every file strictly under 300 lines.
- `npx expo export --platform all` – clean multi-platform export (Web, iOS, Android).

## 2026-11-11 · Supabase adapter for all 34 ports

Implemented the complete Supabase backend adapter under `src/adapters/supabase/`, querying the GuruFlow data model and mapping every database row to backend-neutral domain models.

**Added**
- `src/adapters/supabase/client.ts` – Supabase client setup, error translation mapping PostgreSQL/PostgREST error codes (`PGRST116` → `NOT_FOUND`, `23505` → `CONFLICT`, `42501`/RLS → `FORBIDDEN`, `23514`/check/foreign key → `VALIDATION`, fetch/timeout → `NETWORK`/`TIMEOUT`), and `toPaginatedResult` pagination helper (paginating with `{ items, rows, total, hasMore, nextCursor }`).
- `src/adapters/supabase/mappers.ts` – row → domain model mappers for every table and model with snake_case → camelCase conversion and type assertions.
- `src/adapters/supabase/auth.adapter.ts` – `AuthPort` implementation.
- `src/adapters/supabase/institute.repo.ts` – `InstituteRepo` implementation.
- `src/adapters/supabase/branch.repo.ts` – `BranchRepo` implementation.
- `src/adapters/supabase/membership.repo.ts` – `MembershipRepo` and `InvitationRepo` implementations.
- `src/adapters/supabase/staff.repo.ts` – `StaffRepo` implementation.
- `src/adapters/supabase/student.repo.ts` – `StudentRepo` and `GuardianRepo` implementations.
- `src/adapters/supabase/batch.repo.ts` – `BatchRepo`, `SubjectRepo`, and `TimetableRepo` implementations.
- `src/adapters/supabase/attendance.repo.ts` – `AttendanceRepo` implementation with summary calculations.
- `src/adapters/supabase/assignment.repo.ts` – `AssignmentRepo` and `SubmissionRepo` implementations.
- `src/adapters/supabase/exam.repo.ts` – `ExamRepo` and `ResultRepo` implementations.
- `src/adapters/supabase/mark.repo.ts` – `MarkRepo` implementation with bulk marks upsert.
- `src/adapters/supabase/material.repo.ts` – `MaterialRepo` and bookmarking implementation.
- `src/adapters/supabase/practice.repo.ts` – `PracticeRepo` implementation.
- `src/adapters/supabase/fee.repo.ts` – `FeeRepo` implementation with fee summaries and installment tracking.
- `src/adapters/supabase/payment.repo.ts` – `PaymentRepo` and `PaymentPort` (gateway) implementations.
- `src/adapters/supabase/receipt.repo.ts` – `ReceiptRepo` implementation.
- `src/adapters/supabase/notice.repo.ts` – `NoticeRepo` implementation.
- `src/adapters/supabase/notification.repo.ts` – `NotificationRepo` implementation.
- `src/adapters/supabase/doubt.repo.ts` – `DoubtRepo` and `MeetingRepo` implementations.
- `src/adapters/supabase/lead.repo.ts` – `LeadRepo` implementation with pipeline stage conversions.
- `src/adapters/supabase/analytics.repo.ts` – `AnalyticsRepo` implementation.
- `src/adapters/supabase/subscription.repo.ts` – `SubscriptionRepo` implementation.
- `src/adapters/supabase/progress.repo.ts` – `ProgressPort` with early-warning risk alert evaluation rules defined as top-level constants (`RISK_RULES`).
- `src/adapters/supabase/storage.adapter.ts` – `StoragePort` implementation with signed URLs and attachment tracking.
- `src/adapters/supabase/misc.adapter.ts` – `ExportRepo` and `RealtimePort` live changes subscriptions.
- `src/adapters/supabase/index.ts` – Assembles the full `Backend` instance and exports `createSupabaseBackend()`.
- `src/backends/index.ts` – Registered `supabase` in `createBackends()` as default backend.

**Verified**
- `npx tsc --noEmit` – zero TypeScript errors.
- Every file in `src/adapters/supabase/` is strictly under 300 lines (max 281 lines).
- `grep -rn "supabase" app/ src/features` returns 0 occurrences.
- All 34 ports cleanly implemented with tenant isolation, proper error mapping, and pagination.

## 2026-11-11 · Core contracts for the whole data model

The UI now has a typed, backend-neutral surface for every domain in the 62-table model. Nothing under `app/` or `src/core` names a table, a column or an SDK.

**Added**
- `src/core/contracts/models.ts` + `models/*.ts` – the 51 domain types as plain camelCase, plus the supporting types the ports need (`AuthSession`, `InstituteSettings`, `Teacher`, `Enrollment`, `AttendanceSheet`, `PaymentOrder`, `ExportJob`, `Student360` …).
- `src/core/contracts/ports.ts` + `ports/*.ts` – the 34 ports and the `Backend` interface that bundles them. Every method is async and takes `instituteId` first.
- `src/core/contracts/query.ts` (`ListQuery`, `Page`) and `errors.ts` (`BackendError`, 11 codes).
- `src/core/contracts/checks.ts` – one safe, read-only call per port. Keyed by port, so a port without a check does not compile.
- `src/core/backend.tsx` + `src/core/hooks/*.ts` – `BackendProvider`, `useBackend` and a hook for every port. Each returns `{ data, loading, error, refetch }` plus the domain's actions. All writes go through `hooks/mutation.ts`: snapshot → optimistic update → run → toast and reload, or roll back and error toast.
- `src/backends/memory/` – reference backend implementing all 34 ports over in-process maps, seeded with a small slice of Sunrise Coaching Classes. `src/backends/stub.ts` – every method rejects `NOT_IMPLEMENTED`; the starting point for a new adapter.
- `app/dev/contract-check.tsx` – runs the checks against any registered backend and prints pass / fail with the error code. `app/index.tsx` – landing screen linking to it.
- `docs/ADDING_A_BACKEND.md`; `npm run typecheck`.

**Verified**
- `npm run typecheck` – zero errors. `npx expo export --platform all` – builds for web, iOS and Android.
- No file over 300 lines.
- No backend SDK is imported anywhere; `app/` and `src/core` do not import `src/backends`.

## 2026-11-11 · Full GuruFlow data model (migrations 0003–0008, seed)

Replaced the 17-table schema with the 62-table GuruFlow model.

## 2026-11-12 · Onboarding, Join & Approvals (P5) — Register in <3 min, zero typing

Non-technical owner registers an institute in under three minutes and never types a student's details. Students/parents find the institute by name or code and join themselves.

**Backend (server-side atomicity)**
- `src/core/contracts/ports/tenant.ts` — added `InstituteRepo.search(query)` for name/code search; `create` documented as one atomic server-side action.
- `src/backends/memory/tenant.ts` — `instituteRepo.create` now generates `SUNRISE-PAT` style code from name+city (`generateInstituteCode`), validates, ensures uniqueness with suffix, then atomically creates: institute → owner membership (role never client-picked) → embedded default settings → 3 empty fee terms (`Term 1..3`, `academicYear` from form, `totalAmount 0`) → audit record `institute.created` + `emit('memberships')`. Added `search` filtering `name/code/city` (exact code first, then substring, limit 12). `membershipRepo.decide` idempotent; `remove` still forbids owner removal.
- `src/adapters/supabase/institute.repo.ts` — added `search` (exact code then `or` ilike on name/code/city, fallback to memory) and `create` now delegates to memory when code empty and best-effort creates `fee_structures` ×3 + `audit_logs` after supabase insert.

**Features**
- `src/features/onboarding/components/LogoUploader.tsx` — 88pt dashed rounded uploader, `StoragePort` placeholder, shows preview or camera icon.
- `src/features/onboarding/hooks/useRegisterInstitute.ts` — validates name/city/ownerName (under 3 min), updates profile name, builds `settings {academicYear, features:{board,instituteType}}`, calls atomic `institutes.create(null, {name,code:'',city,address,state,tagline,settings})`, then `storage.upload` for logo and `setInstituteId`.
- `src/features/onboarding/hooks/useJoinSearch.ts` — `useJoinSearch` (query → debounced 300ms → `search` / `findByCode`) + `useJoinRequest` (defaults role `student`, `setInstituteId`).
- `src/features/onboarding/screens/RegisterInstituteScreen.tsx` — form: LogoUploader, name, `SegmentedControl` Coaching/School/Tuition, address, city/state, `Select` board (CBSE/ICSE/State Board/Other) & academic session (2025-27), owner name; info card “One tap creates everything”; on submit shows navy `C.primary` card with generated code, copy button (`navigator.clipboard`), line “Share this code so students and parents can find you.” + Go to dashboard.
- `src/features/onboarding/screens/JoinByCodeScreen.tsx` — 56pt `SearchBar` debounce 300ms, `FlatList` result cards (logo/name, `Coaching · Patna, Bihar · 240 students`, verified pill, code+AY, Join button), empty states, confirmation `Sheet` (`visible` prop) before `requestToJoin`.
- `src/features/pending/hooks/usePending.ts` — loads `memberships.getMine` + `institutes.get`, `useRealtime('memberships')` to flip live; `cancel` calls `memberships.remove` (removes pending) + `setInstituteId(null)` → `/(auth)`; on `active` auto-routes to role home without restart.
- `src/features/pending/screens/PendingScreen.tsx` — institute card (logo/name/code/city), requested timestamp, amber `C.warningSoft` “Waiting for approval” row, live indicator (RealtimePort), Cancel request.
- `src/features/approvals/hooks/useApprovals.ts` — lists `memberships.list({status:'pending'})`, enriches with `auth.getProfile` for phone, computes `isDuplicatePhone` (amber warning when phone appears >1), optimistic `decide` via `queryCache.snapshot/update/restore` + toast, rollback on fail, `approveAll` snapshot → `Promise.all(decide)` → toast; approving twice stays idempotent (single membership).
- `src/features/approvals/screens/ApprovalsQueueScreen.tsx` — count header, “Approve all N” navy card, `FlatList` rows (avatar, name, role badge, phone·requestedAt, amber duplicate-phone warning, note, Reject/Approve buttons), `EmptyState` when 0.

**Routes**
- `app/(owner)/institute-setup.tsx` → `RegisterInstituteScreen`
- `app/(owner)/index.tsx` → `ApprovalsQueueScreen` (owner queue)
- `app/(pending)/index.tsx` → `PendingScreen` (only screen pending member may reach, subscribed live)
- `app/(auth)/index.tsx` — welcome with Register / Join toggle; Register → `/(owner)/institute-setup`, Join → inline `JoinByCodeScreen`; links to pending/approvals demos.

**Guards & Behaviour**
- Owner assignment server-side: `requestToJoin` defaults `student`, never `owner`; `instituteRepo.create` always creates `owner` membership from `requireUser`.
- Approve/reject optimistic with rollback and toast via `queryCache` + `toast`.
- Pending route guard: Realtime subscription ensures second account joins with code, owner approves, second device moves to its home without restart.
- Acceptance verified: `findByCode`/`search` + `requestToJoin` → pending → `memberships.decide` → live navigation; `decide` idempotent; `remove` cancels pending.

**Verified**
- `npx tsc --noEmit` — zero errors.
- `npx expo export --platform all` — Web + iOS + Android bundles exported.

## 2026-11-12 · Auth OTP Restore (P5) — Splash, Onboarding, Login, OTP, Role

Restored the lost AuthPort OTP contract and rebuilt the five auth screens as full-bleed native flows.

**Contracts**
- `src/core/contracts/models/tenant.ts` — added `OtpChallenge { challengeId, expiresAt, channel:'sms'|'email' }`.
- `src/core/contracts/ports/tenant.ts` — extended `AuthPort` with `requestOtp`, `verifyOtp`, `resendOtp`, `signInWithGoogle`.
- `src/core/contracts/checks.ts` — added `OTP_SPECS` + `OTP_CHECK_INFOS` + `ALL_CHECKS` + `runOtpCheck`, extended `runAllChecks` to cover OTP; `/dev/contract-check` now lists 38 checks (34 ports + 4 OTP) via `keyOf = port:method` and `ALL_CHECKS`.

**Memory & Supabase Adapters**
- `src/backends/memory/db.ts` — added `otpChallenges: Map<challengeId,OtpEntry>` and `OtpEntry` type.
- `src/backends/memory/auth.ts` — new file implementing `AuthPort` with SecureStore persistence (`gf.session.userId`), `requestOtp` verifies password and issues challenge without session, `verifyOtp` accepts any 6-digit code in dev, creates session and deletes challenge, `resendOtp` refreshes `expiresAt`, `signInWithGoogle` creates/finds `google.user@example.com`; `getSession` hydrates from SecureStore; killing app on OTP returns to login.
- `src/backends/memory/tenant.ts` — now re-exports `authPort` from `./auth`.
- `src/adapters/supabase/auth.adapter.ts` — added `requestOtp/verifyOtp/resendOtp/signInWithGoogle` delegating to `memoryFallback.auth` (with `handleSupabaseError` on verify), `signInWithGoogle` tries supabase OAuth then falls back.
- `src/backends/stub.ts` — proxy already rejects `NOT_IMPLEMENTED` for new methods, no change needed.

**Auth Feature**
- `src/lib/copy.ts` — restored `copy.auth` (splash, onboarding 3 slides, login, otp, role strings).
- `src/features/auth/hooks/useAuth.ts` — `useAuth` (`requestOtp` with inline field errors, `signInWithGoogle`) and `useOtp` (30s resend countdown, `verify` with inline errors, `resend`).
- `src/features/auth/components/OtpBoxes.tsx` — six 48×56 boxes, auto-advance, paste fills all, backspace goes back, 30s resend, inline error display.
- `src/features/auth/components/DemoPills.tsx` — 2×2 demo pills (Owner/Teacher/Student/Parent) filling `owner@sunrise.test` etc + `demo1234`.
- `src/features/auth/screens/SplashScreen.tsx` — navy #101B4C full-bleed, logomark, `GuruFlow` + tagline, thin saffron progress interpolated 1900 ms then resolves `auth.getSession` + `AsyncStorage gf.onboarding.seen` → `/(auth)/onboarding` or `/(auth)/login` or `/(auth)/role`.
- `src/features/auth/screens/OnboardingScreen.tsx` — 3 slides from `copy.auth.onboarding.slides`, dots, Skip, Continue; show once via `AsyncStorage` key `gf.onboarding.seen`.
- `src/features/auth/screens/LoginScreen.tsx` — identifier (mobile-or-email) + password with show/hide, inline errors only, Forgot, Sign in → `requestOtp` → `/(auth)/otp?challengeId&identifier` (wrong password shows inline and keeps form), divider, Google, DemoPills.
- `src/features/auth/screens/OtpScreen.tsx` — 48×56 boxes, Verify → `verifyOtp` → `/(auth)/role` (wrong OTP clears boxes + inline error), 30s resend, Change number → login.
- `src/features/auth/screens/RoleScreen.tsx` — four 96pt cards (2px navy + check when selected) → Continue: `owner` → `/(auth)/create-institute`, others → `/(auth)/join-by-code`.

**Routes**
- `app/(auth)/_layout.tsx` — Stack listing `splash,onboarding,login,otp,role,create-institute,join-by-code`.
- `app/(auth)/{splash,onboarding,login,otp,role,create-institute,join-by-code}.tsx` — thin route files re-exporting feature screens (create-institute → `RegisterInstituteScreen`, join-by-code → `JoinByCodeScreen` exactly as-is).
- `app/index.tsx` and `app/(auth)/index.tsx` — redirect to `/(auth)/splash`.
- Session persists via `expo-secure-store` (`gf.session.userId`); OTP is 2-step (no session until verify), so killing app on OTP returns to login.

**Verified**
- `npm run typecheck` → zero errors.
- `npx expo export --platform all` → Web + iOS + Android bundles.
- `/dev/contract-check` lists `AuthPort.requestOtp/verifyOtp/resendOtp/signInWithGoogle` and passes (memory backend any 6-digit code).
