import type { Branch, ID, Institute, Membership } from '../../core/contracts/models';
import type { BranchRepo, InstituteRepo, InvitationRepo, MembershipRepo } from '../../core/contracts/ports';
import { crud, emit, requireUser, type Db } from './db';
import * as D from './defaults';
import { defined, fail, merge, nowIso } from './store';

export { authPort, MEMORY_PASSWORD } from './auth';

function generateInstituteCode(db: Db, name: string, city: string | null): string {
  const baseRaw = name.trim().split(/\s+/)[0]?.toUpperCase().replace(/[^A-Z0-9]/g, '') ?? 'INST';
  const base = baseRaw.slice(0, 8) || 'INST';
  const cityPartRaw = (city ?? '').trim().slice(0, 3).toUpperCase().replace(/[^A-Z]/g, '');
  const cityPart = (cityPartRaw || 'GEN').padEnd(3, 'X').slice(0, 3);
  let code = `${base}-${cityPart}`;
  if (!db.institutes.everything().some((inst) => inst.code === code)) return code;
  let counter = 2;
  while (counter < 100) {
    const variant = `${base}-${cityPart}${counter}`;
    if (!db.institutes.everything().some((inst) => inst.code === variant)) return variant;
    counter++;
  }
  fail('CONFLICT', 'That code is taken');
  return code;
}

export function instituteRepo(db: Db): InstituteRepo {
  return {
    listMine: async () => {
      const userId = requireUser(db);
      return db.institutes.everything().filter((inst) => db.memberships.find(inst.id, { userId, status: 'active' }));
    },
    findByCode: async (_instituteId, code) => {
      const wanted = code.trim().toUpperCase();
      return db.institutes.everything().find((inst) => inst.code === wanted) ?? null;
    },
    search: async (_instituteId, query) => {
      const q = query.trim().toLowerCase();
      if (!q || q.length < 1) return [];
      const all = db.institutes.everything();
      // exact code match first
      const exact = all.find((inst) => inst.code.toLowerCase() === q);
      if (exact) return [exact];
      return all
        .filter(
          (inst) =>
            inst.name.toLowerCase().includes(q) ||
            inst.code.toLowerCase().includes(q) ||
            (inst.city ?? '').toLowerCase().includes(q),
        )
        .slice(0, 12);
    },
    create: async (_instituteId, input) => {
      const ownerId = requireUser(db);
      if (!input.name?.trim()) fail('VALIDATION', 'Institute name is required');
      const name = input.name.trim();
      // Code: use provided if valid & unique, otherwise generate server-side
      let code = (input.code ?? '').trim().toUpperCase();
      const cityForCode = (input.city as string | null) ?? null;
      if (!code || !/^[A-Z0-9][A-Z0-9-]{2,23}$/.test(code)) {
        code = generateInstituteCode(db, name, cityForCode);
      } else if (db.institutes.everything().some((inst) => inst.code === code)) {
        // auto-suffix instead of throwing, to keep atomic UX
        code = generateInstituteCode(db, name, cityForCode);
      }
      const at = nowIso();
      // Merge defaults but ensure settings include derived academicYear/board/type
      const baseInstitute = D.institute();
      const incomingSettings = (input as unknown as { settings?: Partial<Institute['settings']> }).settings ?? {};
      const mergedSettings = {
        ...baseInstitute.settings,
        ...incomingSettings,
        // ensure academicYear defaults to 2026-27 if not provided
        academicYear: incomingSettings.academicYear ?? baseInstitute.settings.academicYear ?? '2026-27',
      } as Institute['settings'];
      const created: Institute = {
        ...baseInstitute,
        ...defined(input),
        id: db.nextId(),
        name,
        code,
        ownerId,
        settings: mergedSettings,
        createdAt: at,
        updatedAt: at,
      };
      // Ensure city/state/address from input are kept
      if (input.city !== undefined) created.city = (input.city as string) ?? null;
      if (input.address !== undefined) created.address = (input.address as string) ?? null;
      if (input.state !== undefined) created.state = (input.state as string) ?? null;
      db.institutes.put(created);
      // 1) owner membership (server-side, role never client-picked)
      db.memberships.insert(created.id, {
        userId: ownerId,
        branchId: null,
        role: 'owner',
        status: 'active',
        permissions: [],
        requestNote: null,
        requestedAt: at,
        decidedBy: ownerId,
        decidedAt: at,
      });
      // 2) default settings already embedded above; ensure institute_settings consistency is just the institute row in memory
      // 3) three empty fee terms (fee structures)
      const academicYear = mergedSettings.academicYear ?? '2026-27';
      for (let term = 1; term <= 3; term++) {
        db.feeStructures.insert(created.id, {
          batchId: null,
          name: `Term ${term}`,
          academicYear,
          totalAmount: 0,
          installmentCount: 1,
          frequency: 'term',
          components: [],
          lateFeePerDay: 0,
          isActive: true,
        });
      }
      // 4) audit record (append-only)
      db.auditLogs.insert(created.id, {
        action: 'institute.created',
        actorId: ownerId,
        actorRole: 'owner',
        targetType: 'institute',
        targetId: created.id,
        before: null,
        after: { name: created.name, code: created.code, city: created.city },
        ipAddress: null,
        userAgent: null,
      });
      // Update owner profile name if input carried ownerName via tagline misuse? We keep profile separate.
      // But ensure membership is active and code generated.
      emit(db, created.id, 'memberships', 'created', created.id);
      return created;
    },
    get: async (instituteId) => db.institutes.get(instituteId, instituteId),
    update: async (instituteId, patch) => db.institutes.update(instituteId, instituteId, patch),
    updateSettings: async (instituteId, patch) => {
      const current = db.institutes.get(instituteId, instituteId);
      return db.institutes.update(instituteId, instituteId, { settings: { ...current.settings, ...defined(patch) } });
    },
  };
}

export function branchRepo(db: Db): BranchRepo {
  const base = crud<Branch, 'name' | 'code'>(db.branches, D.branch);
  return {
    ...base,
    create: async (instituteId, input) => {
      if (db.branches.find(instituteId, { code: input.code })) fail('CONFLICT', 'A branch with this code exists');
      return base.create(instituteId, input);
    },
  };
}

export function membershipRepo(db: Db): MembershipRepo {
  const changed = (membership: Membership, change: 'created' | 'updated' | 'removed') => {
    emit(db, membership.instituteId, 'memberships', change, membership.id);
    return membership;
  };
  return {
    list: async (instituteId, query) => db.memberships.page(instituteId, query),
    get: async (instituteId, id) => db.memberships.get(instituteId, id),
    getMine: async (instituteId) => {
      const userId = db.session.userId;
      return userId ? (db.memberships.find(instituteId, { userId }) ?? null) : null;
    },
    requestToJoin: async (instituteId, { role, note }) => {
      const userId = requireUser(db);
      const institute = db.institutes.get(instituteId, instituteId);
      if (!institute.settings.allowJoinRequests) fail('FORBIDDEN', 'This institute is not accepting join requests');
      if (db.memberships.find(instituteId, { userId })) fail('CONFLICT', 'You already have a membership here');
      return changed(
        db.memberships.insert(instituteId, {
          userId,
          branchId: null,
          role,
          status: 'pending',
          permissions: [],
          requestNote: note ?? null,
          requestedAt: nowIso(),
          decidedBy: null,
          decidedAt: null,
        }),
        'created',
      );
    },
    decide: async (instituteId, id, status) =>
      changed(
        db.memberships.update(instituteId, id, { status, decidedBy: db.session.userId, decidedAt: nowIso() }),
        'updated',
      ),
    setRole: async (instituteId, id, role, permissions) => {
      const target = db.memberships.get(instituteId, id);
      const owners = db.memberships.all(instituteId, { role: 'owner', status: 'active' });
      if (target.role === 'owner' && role !== 'owner' && owners.length === 1) {
        fail('CONFLICT', 'An institute must keep at least one owner');
      }
      return changed(db.memberships.update(instituteId, id, defined({ role, permissions })), 'updated');
    },
    remove: async (instituteId, id) => {
      const target = db.memberships.get(instituteId, id);
      if (target.role === 'owner') fail('FORBIDDEN', 'An owner cannot be removed');
      db.memberships.remove(instituteId, id);
      changed(target, 'removed');
    },
  };
}

export function invitationRepo(db: Db): InvitationRepo {
  return {
    list: async (instituteId, query) => db.invitations.page(instituteId, query),
    get: async (instituteId, id) => db.invitations.get(instituteId, id),
    create: async (instituteId, input) => {
      if (!input.email && !input.phone) fail('VALIDATION', 'An email or a phone number is required');
      return db.invitations.insert(instituteId, { ...merge(D.invitation(), input), invitedBy: db.session.userId });
    },
    resend: async (instituteId, id) =>
      db.invitations.update(instituteId, id, { status: 'pending', expiresAt: D.invitation().expiresAt }),
    revoke: async (instituteId, id) => db.invitations.update(instituteId, id, { status: 'revoked' }),
    // The memory backend has no mail to send, so an invitation's id doubles as its token.
    accept: async (instituteId, token) => {
      const userId = requireUser(db);
      const invitation = db.invitations.find(instituteId, { id: token, status: 'pending' });
      if (!invitation) fail('NOT_FOUND', 'This invitation is not valid any more');
      if (db.memberships.find(instituteId, { userId })) fail('CONFLICT', 'You already have a membership here');
      const at = nowIso();
      db.invitations.update(instituteId, invitation.id, { status: 'accepted', acceptedBy: userId, acceptedAt: at });
      return db.memberships.insert(instituteId, {
        userId,
        branchId: null,
        role: invitation.role,
        status: 'active',
        permissions: [],
        requestNote: null,
        requestedAt: at,
        decidedBy: invitation.invitedBy,
        decidedAt: at,
      });
    },
  };
}
