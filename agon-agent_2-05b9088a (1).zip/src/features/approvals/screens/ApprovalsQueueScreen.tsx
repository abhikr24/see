import React from 'react';
import { FlatList, View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { Button, Card, EmptyState, Text } from '@/components/ui';
import { useApprovals } from '../hooks/useApprovals';

export function ApprovalsQueueScreen() {
  const { items, count, approve, reject, approveAll, pending } = useApprovals();

  if (pending.loading && items.length === 0) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text c={C.muted}>Loading approvals…</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, gap: 16, flex: 1 }}>
        <View style={{ gap: 4 }}>
          <Text variant="h1">Approvals</Text>
          <Text variant="body" c={C.secondary}>
            {count === 0 ? 'No pending requests' : `${count} pending ${count === 1 ? 'request' : 'requests'} need your attention`}
          </Text>
        </View>

        {count > 0 ? (
          <View style={{ gap: 12 }}>
            <Card pad={16} style={{ backgroundColor: C.primary, borderColor: C.primary }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <View style={{ gap: 4 }}>
                  <Text variant="label" c={C.navyMid}>
                    PENDING REQUESTS
                  </Text>
                  <Text variant="h2" c={C.surface}>
                    {count} awaiting approval
                  </Text>
                  <Text variant="caption" c={C.surface} style={{ opacity: 0.8 }}>
                    Approve all to add them instantly — each approval is idempotent.
                  </Text>
                </View>
                <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name="people-outline" size={22} color={C.surface} />
                </View>
              </View>
              <View style={{ marginTop: 14 }}>
                <Button title={`Approve all ${count}`} variant="secondary" onPress={approveAll} icon="checkmark-done-outline" />
              </View>
            </Card>
          </View>
        ) : null}

        {count === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', paddingBottom: 40 }}>
            <EmptyState
              title="All caught up"
              text="No pending join requests. Share your institute code so students can find you."
              icon="checkmark-done-circle-outline"
            />
            <Card flat tint={C.surface} pad={12} style={{ marginTop: 16, borderStyle: 'dashed' }}>
              <Text variant="caption" c={C.secondary} style={{ textAlign: 'center' }}>
                Students join by searching your code like SUNRISE-PAT — you never type their details.
              </Text>
            </Card>
          </View>
        ) : (
          <FlatList
            data={items}
            keyExtractor={(it) => it.membership.id}
            contentContainerStyle={{ gap: 12, paddingBottom: 24 }}
            renderItem={({ item }) => (
              <Card pad={14}>
                <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
                  <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.track, alignItems: 'center', justifyContent: 'center' }}>
                    <Text variant="title" c={C.primary}>
                      {(item.profile?.fullName ?? 'U').slice(0, 2).toUpperCase()}
                    </Text>
                  </View>
                  <View style={{ flex: 1, gap: 2 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Text variant="title" numberOfLines={1} style={{ flex: 1 }}>
                        {item.profile?.fullName ?? 'Unknown user'}
                      </Text>
                      <View style={{ backgroundColor: C.track, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999 }}>
                        <Text variant="label" c={C.secondary} style={{ fontSize: 10 }}>
                          {item.membership.role.toUpperCase()}
                        </Text>
                      </View>
                    </View>
                    <Text variant="caption" c={C.secondary}>
                      {item.profile?.phone ?? 'No phone'} · requested {new Date(item.membership.requestedAt).toLocaleDateString()} {new Date(item.membership.requestedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                    {item.isDuplicatePhone ? (
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4, backgroundColor: C.warningSoft, paddingHorizontal: 8, paddingVertical: 6, borderRadius: 8 }}>
                        <Ionicons name="warning-outline" size={14} color={C.warning} />
                        <Text variant="caption" c={C.warning} weight={600}>
                          Duplicate phone — already requested
                        </Text>
                      </View>
                    ) : null}
                  </View>
                </View>
                {item.membership.requestNote ? (
                  <View style={{ marginTop: 10, backgroundColor: C.canvas, padding: 10, borderRadius: R.field }}>
                    <Text variant="caption" c={C.secondary}>
                      “{item.membership.requestNote}”
                    </Text>
                  </View>
                ) : null}
                <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
                  <View style={{ flex: 1 }}>
                    <Button title="Reject" variant="outline" size="sm" onPress={() => reject(item.membership.id)} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Button title="Approve" size="sm" onPress={() => approve(item.membership.id)} icon="checkmark" />
                  </View>
                </View>
              </Card>
            )}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </SafeAreaView>
  );
}
