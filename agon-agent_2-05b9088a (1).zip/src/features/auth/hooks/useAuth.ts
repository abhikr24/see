import { useCallback, useState } from 'react';
import { useRouter } from 'expo-router';
import { useBackend } from '@/core/backend';
import type { OtpChallenge } from '@/core/contracts/models';

export function useAuth() {
  const { backend } = useBackend();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [fieldError, setFieldError] = useState<string | null>(null);

  const requestOtp = useCallback(
    async (identifier: string, password: string): Promise<OtpChallenge | null> => {
      if (!identifier.trim()) {
        setFieldError('Enter your mobile or email');
        return null;
      }
      if (!password) {
        setFieldError('Enter your password');
        return null;
      }
      setLoading(true);
      setFieldError(null);
      try {
        const challenge = await backend.auth.requestOtp(null, { email: identifier.trim(), password });
        return challenge;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Wrong email or password';
        setFieldError(msg.includes('Wrong') ? msg : 'Wrong email or password');
        return null;
      } finally {
        setLoading(false);
      }
    },
    [backend],
  );

  const signInWithGoogle = useCallback(async () => {
    setLoading(true);
    try {
      await backend.auth.signInWithGoogle(null);
      router.replace('/(auth)/role' as never);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Google sign-in failed';
      setFieldError(msg);
    } finally {
      setLoading(false);
    }
  }, [backend, router]);

  return { requestOtp, signInWithGoogle, loading, fieldError, setFieldError };
}

export function useOtp(challengeId: string) {
  const { backend } = useBackend();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resendIn, setResendIn] = useState(30);

  const verify = useCallback(
    async (code: string) => {
      if (code.length !== 6) {
        setError('Enter the 6-digit code');
        return false;
      }
      setLoading(true);
      setError(null);
      try {
        await backend.auth.verifyOtp(null, { challengeId, code });
        return true;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Wrong code — try again';
        const friendly = msg.includes('expired') ? 'Code expired — request a new one' : 'Wrong code — try again';
        setError(friendly);
        return false;
      } finally {
        setLoading(false);
      }
    },
    [backend, challengeId],
  );

  const resend = useCallback(async (): Promise<string | null> => {
    try {
      const c = await backend.auth.resendOtp(null, challengeId);
      setResendIn(30);
      setError(null);
      return c.challengeId;
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Could not resend';
      setError(msg);
      return null;
    }
  }, [backend, challengeId]);

  return { verify, resend, loading, error, setError, resendIn, setResendIn };
}
