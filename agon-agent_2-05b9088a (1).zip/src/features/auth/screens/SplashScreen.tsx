import React, { useEffect, useRef } from 'react';
import { Animated, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { C } from '@/lib/theme';
import { Text } from '@/components/ui';
import { copy } from '@/lib/copy';
import { useBackend } from '@/core/backend';

export function SplashScreen() {
  const router = useRouter();
  const { backend } = useBackend();
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(progress, { toValue: 1, duration: 1900, useNativeDriver: false }).start();
  }, [progress]);

  useEffect(() => {
    const timer = setTimeout(async () => {
      try {
        const session = await backend.auth.getSession(null);
        if (session) {
          router.replace('/(auth)/role' as never);
          return;
        }
      } catch {}
      try {
        const seen = await AsyncStorage.getItem('gf.onboarding.seen');
        if (!seen) router.replace('/(auth)/onboarding' as never);
        else router.replace('/(auth)/login' as never);
      } catch {
        router.replace('/(auth)/login' as never);
      }
    }, 1900);
    return () => clearTimeout(timer);
  }, [backend, router]);

  const widthInterpolate = progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] });

  return (
    <View style={{ flex: 1, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <View style={{ alignItems: 'center', gap: 14 }}>
        <View style={{ width: 72, height: 72, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' }}>
          <Ionicons name="school" size={36} color={C.surface} />
        </View>
        <Text variant="h1" c={C.surface} style={{ fontSize: 34, letterSpacing: -0.5 }}>
          {copy.auth.splash.title}
        </Text>
        <Text variant="body" c={C.navyMid} style={{ textAlign: 'center', opacity: 0.9 }}>
          {copy.auth.splash.tagline}
        </Text>
      </View>
      <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 3, backgroundColor: 'rgba(255,255,255,0.15)' }}>
        <Animated.View style={{ height: 3, backgroundColor: C.accent, width: widthInterpolate }} />
      </View>
    </View>
  );
}
