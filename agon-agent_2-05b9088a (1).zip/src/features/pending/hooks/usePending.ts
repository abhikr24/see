import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'expo-router';
import { useBackend } from '@/core/backend';
import type { Institute, Membership } from '@/core/contracts/models';
import { toast } from '@/core/hooks/toast';
import { useRealtime } from '@/core/hooks/communication';

export function usePending() {
  const { backend, instituteId, setInstituteId } = useBackend();
  const router = useRouter();
  const [membership, setMembership] = useState<Membership | null>(null);
  const [institute, setInstitute] = useState<Institute | null>(null);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);

  const load = useCallback(async () => {
    if (!instituteId) {
      setLoading(false);
      return;
    }
    try {
      const mine = await backend.memberships.getMine(instituteId);
      setMembership(mine);
      if (mine) {
        try {
          const inst = await backend.institutes.get(mine.instituteId);
          setInstitute(inst);
        } catch {}
      }
      // If approved, redirect to home without restart
      if (mine?.status === 'active') {
        const role = mine.role;
        if (role === 'owner' || role === 'admin') router.replace('/(owner)' as never);
        else if (role === 'teacher') router.replace('/(teacher)' as never);
        else if (role === 'student') router.replace('/(student)' as never);
        else if (role === 'parent') router.replace('/(parent)' as never);
        else router.replace('/' as never);
      }
    } catch {}
    setLoading(false);
  }, [backend, instituteId, router]);

  useEffect(() => {
    void load();
  }, [load]);

  // Realtime subscription: approval flips live
  useRealtime('memberships', () => {
    void load();
  });

  const cancel = useCallback(async () => {
    if (!instituteId || !membership || membership.status !== 'pending') return;
    setCancelling(true);
    try {
      await backend.memberships.remove(instituteId, membership.id);
      toast.success('Request cancelled');
      setMembership(null);
      // After cancel, go to auth / join
      setInstituteId(null);
      router.replace('/(auth)' as never);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Could not cancel';
      toast.error(msg);
    } finally {
      setCancelling(false);
    }
  }, [backend, instituteId, membership, router, setInstituteId]);

  return { membership, institute, loading, cancelling, cancel, reload: load };
}
