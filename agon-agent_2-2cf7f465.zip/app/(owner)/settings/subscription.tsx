export { SubscriptionScreen as default } from '@/features/settings/SubscriptionScreen';
