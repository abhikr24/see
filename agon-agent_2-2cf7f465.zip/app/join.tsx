import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { JoinLinkScreen } from '@/features/settings/JoinLinkScreen';

export default function JoinRoute() {
  const params = useLocalSearchParams<{ code?: string; token?: string }>();
  const code = Array.isArray(params.code) ? params.code[0] : params.code ?? '';
  const token = Array.isArray(params.token) ? params.token[0] : params.token ?? '';
  return <JoinLinkScreen code={code} token={token} />;
}
