# Deployment and verification

## Status and safety

The exported Vercel deployment from this work is a **seeded memory-backend preview**. It is not a production service: data is browser-local, the sample OTP accepts any six digits, and the login tested below is not a real Supabase login. The supplied live adapter's `requestOtp` delegates to the memory adapter and several repositories silently fall back to memory on remote errors. Do not use it with real student information or submit it to stores until live authentication, fail-closed behavior, consent, RLS and storage have been implemented and audited. No Supabase credentials, Expo account token or Android device were provided.

## Web preview on Vercel

1. Install Node and run `npm ci` in the project root.
2. Set Vercel project environment variable `EXPO_PUBLIC_BACKEND=memory`; leave `EXPO_PUBLIC_DEV_AUTH` empty. These are compile-time public values. Do not put secrets in `EXPO_PUBLIC_*`.
3. Set the Vercel build command to `npx expo export --platform all`, output directory to `dist`, and use the included `vercel.json` rewrite. Or, for a prebuilt deployment from the project root, run `EXPO_PUBLIC_BACKEND=memory npx expo export --platform all` and deploy the resulting `dist` using Vercel CLI or your deployment integration.
4. Open the deployed site. Skip onboarding if shown, enter `owner@sunrise.test` / `demo1234`, submit, enter `123456`, then verify. The reference backend is non-production and accepts any six-digit OTP. The same owner flow was verified locally by `node tests/attendance.browser.cjs` up to successful attendance save; `npm run test:student:ui` passed a student login and teacher login. A browser check against the public deployment itself was not available from this environment; do not consider public login acceptance confirmed.

For a future real deployment, use a project you control, apply all migrations in order including `0023_performance.sql`, configure Supabase Auth, RLS, storage and data retention, then set `EXPO_PUBLIC_BACKEND=supabase`, `EXPO_PUBLIC_SUPABASE_URL`, `EXPO_PUBLIC_SUPABASE_ANON_KEY` and optionally `EXPO_PUBLIC_INSTITUTE_ID`. The anon/publishable key is public; never expose a service-role key. **Those settings alone do not make the current live login safe or functional.** See `.env.example` for all variables; Expo inlines public variables at build time, so rebuild after changing them. Verify using a real approved tenant account only after the blockers above are fixed.

## Native / EAS

The checked-in `app.json` contains an inherited Expo owner and project ID. The project owner must link their own EAS project, supply unique Android package and iOS bundle identifiers, sign in to Expo and configure signing credentials, then configure the same environment variables in EAS. Install `expo-dev-client` is included for the development profile. Android SDK platform-tools/`adb` and a USB-authorized Android phone are needed to install and verify an APK.

```sh
npm ci
npx eas-cli@latest login
npx eas-cli@latest build:configure
# Internal testing APK
npx eas-cli@latest build --platform android --profile preview
# Download the completed APK from the EAS build page, then:
adb devices
adb install -r /path/to/downloaded-build.apk
# Google Play AAB
npx eas-cli@latest build --platform android --profile production
# iOS App Store build (Apple developer account and signing required)
npx eas-cli@latest build --platform ios --profile production
# Optional development client
npx eas-cli@latest build --platform android --profile development
```

The preview profile explicitly builds an APK, production explicitly builds an AAB, and development builds an internal development-client APK. The attempted noninteractive preview build could not start: `npx eas-cli@latest` dependency resolution returned `ETARGET` for `nanoid@3.3.20`. No `adb`, Android device, EAS credentials or APK were available, so **no APK was built or installed**. Resolve the CLI registry issue and provide credentials/device before claiming native acceptance.
