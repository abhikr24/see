# Design Log — GuruFlow UI System

## 2026-11-12 · Complete 35-Primitive Design System (`src/components/ui/`)

### 1. Design Laws Enforced
1. **One focal point per screen:** Hero headers (`GradientHeader` + `OverlapCard`) or a single saffron spotlight (`C.accent`) anchor visual hierarchy; surrounding cards use flat `1px` hairlines (`C.hairline`) on `#F5F6FA` (`C.canvas`).
2. **Depth from borders and space, not stacked shadows:** Cards default to `1px` hairline borders and `18pt` padding (`LAYOUT.cardPad`), reserving `SHADOW` for floating overlays (`OverlapCard`, `TabBar`, `Toast`, `ConfirmDialog` modal, `SegmentedControl` active thumb).
3. **Data is the decoration:** Metrics use `22–34pt` bold tabular numerals (`tabular-nums`) with Indian digit grouping (`₹1,24,500`, `₹4,999`).

### 2. Token Architecture (`src/lib/theme.ts`)
- Every colour literal in the repository lives in `src/lib/theme.ts` (`C`, `TONE`, `GRADIENT`, `SHADOW`).
- `grep -rn "#[0-9A-Fa-f]\{3,8\}" app/ src/` matches only `src/lib/theme.ts`.
- Every component in `src/components/ui/` accepts a `className?: string` passthrough for NativeWind composition.

### 3. Component Inventory (35 Components)

| Category | Components | Notes |
|---|---|---|
| Structure & Navigation | `Screen`, `GradientHeader`, `OverlapCard`, `Card`, `Divider`, `Tabs`, `TabBar`, `SegmentedControl` | `SegmentedControl` uses a Reanimated sliding pill thumb; `Tabs` provides `primary` and `accent` underline variants |
| Typography & Status | `Text`, `Badge`, `Chip`, `Avatar`, `AvatarStack`, `IconBox` | `AvatarStack` overlaps circles with `2px` surface rings and a tabular `+N` overflow chip |
| Forms & Pickers | `Button`, `Input`, `SearchBar`, `DateField`, `Select`, `Stepper` | `DateField` (`DD/MM/YYYY`) and `Select` (searchable) open `@gorhom/bottom-sheet` sheets; `Stepper` formats `₹` with Indian grouping |
| Data Display & Charts | `StatCard`, `ListRow`, `Table`, `Heatmap`, `ProgressBar`, `Ring`, `TrendLine`, `BarChart` | `TrendLine` and `BarChart` use `react-native-gifted-charts` (flat, no gridlines, saffron spotlight on last point / highlighted bar); `Heatmap` renders a 7-column month grid of rounded squares with legend |
| Feedback & Overlays | `EmptyArt`, `EmptyState`, `ErrorState`, `Skeleton`, `ListSkeleton`, `Sheet`, `Toast`, `ConfirmDialog` | `EmptyState` & `ErrorState` compose `EmptyArt`; `ConfirmDialog` supports typed phrase verification (`confirmText`) |

### 4. Design QA Verification (`/dev/components`)
- Renders all 35 components in 11 labelled sections with at least 2 variants/states per component.
- Uses canonical seed figures from `supabase/seed.sql` (Sunrise Coaching Classes, `SUNRISE-PAT`, Class 10-A 92% attendance, Unit Test 3 average 72% with Diya Patel 93 highest, Term 3 `₹4,999` due).

## 2026-11-15 · P31 — Calm states & consistency audit

**EmptyState — one component, four variants**
- `EmptyState` prop `variant?: 'students'|'homework'|'payments'|'approvals'` selects a preset icon/tone/title/text. No screen invents its own copy for these four cases. Implementation in `src/components/ui/States.tsx`; presets: students (people-outline primary), homework (book-outline teal), payments (wallet-outline accent), approvals (checkmark-done-circle-outline success). Used in StudentList (`students` when all==0), HomeworkTracker (`homework`), Fees/Dues (`payments`), ApprovalsQueue (`approvals`). Generic `icon/title/text` still supported for other contexts (e.g. search).

**ErrorState — “This is on us, not on you”**
- Default `title="This is on us, not on you"` in `States.tsx`; every list renders `ErrorState` with `message={error.message}` + `onRetry={refetch}`. Visual: 88pt `cloud-offline-outline` on navyTint, centered 22/800 title, 13 secondary message max 280, `Try again` md button. No red background, no alert icon.

**OfflineBanner — calm, never red, never a modal**
- `src/components/ui/OfflineBanner.tsx`: tracks NetInfo online + `attendanceOutbox` + `submissionOutbox` queues. Shown when `!online || queued>0`. Style: `C.navyTint` bg, `C.hairline` border, 32pt surface icon chip, 13/600 title (“Saved on this phone · 2 waiting to sync” / “You are offline…”), 12 secondary “Last synced X min ago” (formatAgo: just now/1 min/5 min/2 hrs). Right “Retry” navy button when queued>0 flushes both queues (loops `commitSheet` and `backend.submissions.submit`, respects TRANSIENT). AccessibilityLabel includes title + last synced. Mounted in `RoleTabShell` header + `ChromelessGate` so every major screen plus full-screen take screens show it; `app/_layout.tsx` mounts `SubmissionOutboxSync` alongside `AttendanceOutboxSync`.

**Skeletons — shaped like content, no layout shift**
- `Skeleton` pulsing opacity 0.55→1 (850ms), `ListSkeleton` 44pt avatar + two lines in hairline card, `CardGridSkeleton` 96pt with avatar+lines+chip style. All lists now render skeletons while `loading && !data`: HomeworkTracker, Submissions, Assign, StudentHome, TeacherHome, MyClasses, batches, timetable, attendance register, exams, progress, parent attendance/performance, notices. Before: Approvals showed centered Text, Pending showed Text, JoinByCode showed ActivityIndicator; now ListSkeleton. `ActivityIndicator` kept only for inline button `loading` (Button, SearchBar small). `ShellLoading` kept minimal for route-resolution guard (not a data list).

**Global error boundary**
- `src/components/ui/ErrorBoundary.tsx` class component `getDerivedStateFromError`, `componentDidCatch`, fallback view: `C.canvas` bg, bug-outline 96pt danger tint, title “This is on us, not on you”, message max 300, dev block with error.message monospaced, `Try again` resets state. Wrapped around `BackendProvider` in `app/_layout.tsx`.

**Polish pass**
- Haptics: `tapHaptic` on attendance tile cycle/markAll/applyAfter, `successHaptic` on `useTakeAttendance.save` success and on `fees/collect` `record` success.
- Press states: `Card` Pressable opacity 0.92, `Button` 0.9, `SearchField` clear 0.7/Cancel 0.6, `OfflineBanner` retry 0.88, highlight rows track↔surface, `RoleTabShell` institute switcher 0.85, `approvals` leave cards have button pressed states.
- Keyboard dismissal: `SearchScreen` ScrollView+FlatList `keyboardDismissMode="on-drag"` + `keyboardShouldPersistTaps="handled"` + `onScrollBeginDrag={Keyboard.dismiss}`; `StudentList` already had refresh but now also `keyboardDismissMode` where search header present.
- Accessibility: every icon-only Pressable has `accessibilityLabel` + `accessibilityRole="button"` (SearchField clear/Cancel, OfflineBanner retry, Approve/Reject leave, not-found Go to home/Search, highlight rows, chip remove, approvals back, etc.)

**Consistency audit — deviations fixed vs tokens (`src/lib/theme.ts`)**
- Found via `grep -rn "#[0-9A-Fa-f]" src app --exclude theme`: 9 files had hardcoded hex outside tokens. Fixed 7 UI files (see WORK-DONE list). Remaining 2 are `src/features/fees/receipt-document.ts` and `src/features/parent/receipt-html.ts` HTML strings for `expo-print` PDF — kept as print-only but noted; future generates CSS from tokens.
- `grep ActivityIndicator` — verified 5 inline uses (Button, SearchBar 18pt, SaveFooter small) remain; 3 list spinners removed.
- `grep "Loading"` — 4 text loadings replaced with skeletons (Approvals, Pending, JoinByCode, parent fees). 3 remaining “Loading…” are inside `InstituteSwitcher` sheet while fetching institutes — acceptable small sheet, not a main screen list.
- Pressable without `accessibilityLabel` count dropped from ~120 to <40 after adding labels to icon-only buttons; remaining are labeled cards with nested text or non-icon buttons.
- `Length>120` check clean; `npx expo export --platform all` clean.
