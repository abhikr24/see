# Performance evidence — 2026-11-16

## Measured preview (not native or live-service benchmarks)

Device: Linux x86_64 container, Intel Xeon Processor 2.50 GHz, headless Chrome for Testing 159.0.8154.6 (Playwright Chromium 1255), 400 × 860 CSS-pixel mobile viewport at device scale factor 1. This is a **desktop browser simulating a mobile viewport, not an Android/iOS emulator or phone**. Node 24.19.0; fresh browser context, local static HTTP server, production Expo export, seeded `memory` backend, 12-student reference batch; no network throttling. Single run, wall-clock as measured by Node `performance.now()`; timings include Playwright scheduling and DOM visibility checks, not a percentile.

| Metric | Measured | Start → end |
| --- | ---: | --- |
| Cold start | 3,016.0 ms | navigation to local `/` → first interactive login/onboarding control visible |
| Students list first render | 90.0 ms | owner Students tab click → first seeded row visible |
| Attendance save | 515.3 ms | Update attendance click → success message visible |

The last measurement is a **local memory-adapter save**, not a network round trip. An actual Supabase-backed attendance save and physical device/emulator results remain unmeasured and are required for acceptance. To reproduce: `npm ci`, `EXPO_PUBLIC_BACKEND=memory npx expo export --platform all`, `npx playwright install chromium`, then `node tests/performance.browser.cjs`. Repeat on representative devices and with realistic tenant sizes and a real database before release.

## Database work

`0023_performance.sql` adds indexes matching the normalized schema and an invoker-rights dashboard totals RPC. Attendance dates live on `attendance_sessions`, while student and batch IDs live on `attendance_records`, so a single cross-table `(student_id,date)` B-tree cannot exist; the migration indexes the join and date access paths separately. Batch membership is in `batch_students`, read state is `read_at`, and leads are `admission_leads`. Existing leftmost indexes cover marks, payments, notification read state and lead stage. The dashboard replaces raw payment, installment, attendance and enrollment aggregation with one server-side aggregate, avoiding PostgREST's default row cap while retaining RLS.

**Not complete:** a full audit/migration of all >1,000-row aggregations remains. In particular `src/adapters/supabase/exam-analysis.repo.ts` downloads marks for an entire batch and `src/features/students/loadRoster.ts` collects pages before client-side roster calculations. They must be redesigned with RLS-safe server-side aggregation/pagination and tested with >1,000 rows. Migration 0023 has not been applied or benchmarked against a live database in this environment.
