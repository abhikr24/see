# Security audit — evidence

Two runs of the same harness (`npm run test:security`): **Run A** against the repository as received, **Run B** after the fixes. The full Run B output follows the Run A excerpt.

# Security audit — evidence
Generated: 2026-11-16T04:18:13.140Z
Harness: the repository’s real `supabase/migrations/*.sql` and `supabase/seed.sql` executed against real Postgres (PGlite) with a Supabase shim (auth schema + `auth.uid()` reading `request.jwt.claim.sub`, `anon` / `authenticated` / `service_role` roles, storage schema). Every check signs in as a real identity and runs the exact SQL shown.
Postgres: PostgreSQL 18.6

### Migration chain (supabase/migrations, file order)
| file | statements | result |
| --- | --- | --- |
| 0003_core.sql | 24 | applied |
| 0004_academics.sql | 70 | applied |
| 0005_finance.sql | 12 | applied |
| 0006_communication.sql | 16 | applied |
| 0007_business.sql | 12 | applied |
| 0008_rls.sql | 43 | applied |
| 0009_batch_management.sql | 11 | **FAILED — chain stops here** |

First failing statement in `0009_batch_management.sql`:
```sql
  create view public.batch_roster with (security_invoker = true) as
  select e.institute_id,e.batch_id,e.student_id,e.roll_number,s.full_name,s.photo_url,
    coalesce(a.total,0) as attendance_total,
    coalesce(round(100.0 * a.present / nullif(a.total,0),1),0) as attendance_pct
  from public.batch_students e
  join public.students s on s.institute_id=e.institute_id and s.id=e.student_id
  left join (select institute_id,batch_id,student_id,count(*) as total,
    count(*) filter (where status in ('present','late')) as present
    from public.attendance_records group by institute_id,batch_id,student_id) a
  on a.institute_id=e.institute_id and a.batch_id=e.batch_id and a.student_id=e.student_id
  where e.status='active'
```

---

# Security audit — evidence
Generated: 2026-11-16T04:26:08.260Z
Harness: the repository’s real `supabase/migrations/*.sql` and `supabase/seed.sql` executed against real Postgres (PGlite) with a Supabase shim (auth schema + `auth.uid()` reading `request.jwt.claim.sub`, `anon` / `authenticated` / `service_role` roles, storage schema). Every check signs in as a real identity and runs the exact SQL shown.
Postgres: PostgreSQL 18.6

### Migration chain (supabase/migrations, file order)
| file | statements | result |
| --- | --- | --- |
| 0003_core.sql | 24 | applied |
| 0004_academics.sql | 70 | applied |
| 0005_finance.sql | 12 | applied |
| 0006_communication.sql | 16 | applied |
| 0007_business.sql | 12 | applied |
| 0008_rls.sql | 43 | applied |
| 0009_batch_management.sql | 11 | applied |
| 0010_attendance_corrections.sql | 8 | applied |
| 0011_exams.sql | 7 | applied |
| 0012_fee_plans.sql | 20 | applied |
| 0013_fee_collection.sql | 6 | applied |
| 0014_admissions.sql | 15 | applied |
| 0015_student_achievements.sql | 6 | applied |
| 0016_family_fees_leave.sql | 18 | applied |
| 0017_progress_interventions.sql | 7 | applied |
| 0018_notice_broadcast.sql | 9 | applied |
| 0019_settings.sql | 3 | applied |
| 0020_storage_buckets.sql | 13 | applied |
| 0021_join_rate_limit.sql | 2 | applied |
| 0022_post_0008_grants.sql | 1 | applied |

All 20 migrations applied. Seeding `supabase/seed.sql` (Sunrise Coaching Classes, 1 owner · 5 teachers · 12 students · pending users) and adding fixtures: a second institute **Rival Classes** with its own students, attendance, marks, fees, materials and leads, two families inside Sunrise, one admin with the `members` permission, and rate-limit probe institutes.

## Check 1 · every table has RLS enabled and policy coverage per operation
```sql
  select c.relname, c.relrowsecurity,
    count(*) filter (where cmd in ('SELECT','ALL')) … per command
  from pg_class c left join pg_policies … where nspname = 'public'
```
| table | RLS | SELECT | INSERT | UPDATE | DELETE |
| --- | --- | --- | --- | --- | --- |
| admission_leads | on | 1 | 1 | 1 | 1 |
| assignments | on | 1 | 1 | 1 | 1 |
| attachments | on | 1 | 1 | 0 | 1 |
| attendance_corrections | on | 1 | 1 | 1 | 1 |
| attendance_records | on | 1 | 1 | 1 | 1 |
| attendance_sessions | on | 1 | 1 | 1 | 1 |
| audit_logs | on | 1 | 1 | 0 | 0 |
| batch_students | on | 1 | 1 | 1 | 1 |
| batch_teachers | on | 1 | 1 | 1 | 1 |
| batches | on | 1 | 1 | 1 | 1 |
| bookmarks | on | 1 | 1 | 1 | 1 |
| branches | on | 1 | 1 | 1 | 1 |
| classrooms | on | 1 | 1 | 1 | 1 |
| conversations | on | 1 | 1 | 1 | 0 |
| doubts | on | 1 | 1 | 1 | 1 |
| exam_questions | on | 1 | 1 | 1 | 1 |
| exams | on | 1 | 1 | 1 | 1 |
| fee_payments | on | 2 | 0 | 0 | 0 |
| fee_structures | on | 1 | 1 | 1 | 1 |
| feedback | on | 1 | 1 | 1 | 1 |
| guardians | on | 1 | 1 | 1 | 1 |
| installments | on | 1 | 1 | 1 | 1 |
| institute_settings | on | 1 | 1 | 1 | 1 |
| institutes | on | 1 | 1 | 1 | 1 |
| interventions | on | 2 | 1 | 1 | 0 |
| invitations | on | 1 | 1 | 1 | 1 |
| lead_followups | on | 1 | 1 | 1 | 1 |
| leave_requests | on | 1 | 1 | 1 | 1 |
| marks | on | 1 | 1 | 1 | 1 |
| material_access | on | 1 | 1 | 1 | 1 |
| materials | on | 1 | 1 | 1 | 1 |
| meeting_requests | on | 1 | 1 | 1 | 1 |
| memberships | on | 1 | 1 | 1 | 1 |
| notices | on | 1 | 1 | 1 | 1 |
| notifications | on | 1 | 1 | 1 | 1 |
| parent_links | on | 1 | 1 | 1 | 1 |
| payments | on | 1 | 1 | 1 | 1 |
| plans | on | 1 | 0 | 0 | 0 |
| practice_questions | on | 1 | 1 | 1 | 1 |
| profiles | on | 1 | 1 | 1 | 0 |
| quiz_attempts | on | 1 | 1 | 1 | 1 |
| quizzes | on | 1 | 1 | 1 | 1 |
| receipts | on | 1 | 1 | 1 | 1 |
| refunds | on | 1 | 1 | 1 | 1 |
| results | on | 1 | 1 | 1 | 1 |
| sessions | on | 1 | 1 | 1 | 1 |
| staff_records | on | 1 | 1 | 1 | 1 |
| student_achievements | on | 1 | 1 | 1 | 0 |
| student_fees | on | 1 | 1 | 1 | 1 |
| student_goals | on | 1 | 1 | 1 | 1 |
| student_history | on | 1 | 1 | 1 | 1 |
| student_leave_requests | on | 3 | 2 | 1 | 1 |
| student_memberships | on | 1 | 1 | 1 | 1 |
| student_profiles | on | 1 | 1 | 1 | 1 |
| study_tasks | on | 1 | 1 | 1 | 1 |
| subjects | on | 1 | 1 | 1 | 1 |
| submissions | on | 1 | 1 | 1 | 1 |
| subscriptions | on | 1 | 0 | 0 | 0 |
| teacher_assignments | on | 1 | 1 | 1 | 1 |
| teacher_feedback | on | 1 | 1 | 1 | 1 |
| teacher_profiles | on | 1 | 1 | 1 | 1 |
| timetables | on | 1 | 1 | 1 | 1 |
| usage_records | on | 1 | 0 | 0 | 0 |
| user_preferences | on | 1 | 1 | 1 | 1 |
| users | on | 1 | 0 | 0 | 0 |
| workloads | on | 1 | 1 | 1 | 1 |

All 66 public tables have RLS enabled.
Every operation on every table is either policy-governed or deliberately deny-by-default (22 denials, each matching the design comment in the migration). Postgres denies a command with no matching policy, so "no policy" = no access.

## Check 2 · student in institute A reads institute B

Signed in as the seeded student Aarav Sharma (`request.jwt.claim.sub = 00000000-0000-4000-8000-000000000014`, role `authenticated`, active student membership in 00000000-0000-4000-8000-000000000001). One query per table:
```sql
  select count(*) filter (where institute_id = '20000000-0000-4000-8000-000000000001') as rows_from_b, count(*) as rows_visible_at_all from public.student_profiles;
```

| data | table | rows in B (as superuser) | rows from B (as student A) | rows visible at all |
| --- | --- | --- | --- | --- |
| students | student_profiles | 3 | 0 | 1 |
| students (links) | student_memberships | 3 | 0 | 1 |
| attendance (sessions) | attendance_sessions | 1 | 0 | 30 |
| attendance (records) | attendance_records | 3 | 0 | 30 |
| marks | marks | 3 | 0 | 5 |
| marks (results) | results | 1 | 0 | 1 |
| fees (structures) | fee_structures | 1 | 0 | 1 |
| fees (student fees) | student_fees | 1 | 0 | 1 |
| fees (installments) | installments | 1 | 0 | 3 |
| fees (payments) | payments | 1 | 0 | 2 |
| materials | materials | 2 | 0 | 0 |
| leads | admission_leads | 2 | 0 | 0 |
| leads (follow-ups) | lead_followups | 1 | 0 | 0 |
| notices | notices | 1 | 0 | 5 |
`rows visible at all` is the whole table through RLS eyes — only the student’s own institute-A rows appear (their own profile, their own batch’s sessions…). Nothing from institute B is ever visible.

## Check 3 · parent reads another family’s child
Two families inside institute A: Parent One (`30000000-0000-4000-8000-000000000001`) is linked to Aditya Pandey (`00000000-0000-4000-8000-000000000015`); Parent Two (`30000000-0000-4000-8000-000000000002`) is linked to Ananya Singh (`00000000-0000-4000-8000-000000000016`). Signed in as Parent One:
```sql
  select public.my_student_ids();
```
→ `["00000000-0000-4000-8000-000000000015"]` (only Aditya, not Ananya)
```sql
  select count(*) filter (where id = '00000000-0000-4000-8000-000000000016') as other_family, count(*) as own_family from public.student_profiles;
```

| data | table | Ananya (other family) rows | own family rows |
| --- | --- | --- | --- |
| child record | student_profiles | 0 | 1 |
| parent links | parent_links | 0 | 1 |
| student memberships | student_memberships | 0 | 1 |
| attendance records | attendance_records | 0 | 30 |
| marks | marks | 0 | 5 |
| results | results | 0 | 1 |
| student fees | student_fees | 0 | 1 |
| installments | installments | 0 | 3 |
| payments | payments | 0 | 2 |

## Check 4 · pending membership reads nothing
Signed in as the seeded pending user Kunal Sinha (`00000000-0000-4000-8000-000000000038`, membership status `pending` in institute A):
```sql
  select count(*) as visible from public.student_profiles;  -- one of 16 tables probed
```

| table | rows visible |
| --- | --- |
| institutes | 0 |
| memberships | 1 |
| batches | 0 |
| student_profiles | 0 |
| attendance_sessions | 0 |
| attendance_records | 0 |
| marks | 0 |
| results | 0 |
| fee_structures | 0 |
| student_fees | 0 |
| materials | 0 |
| admission_leads | 0 |
| notices | 0 |
| notifications | 0 |
| interventions | 0 |
| audit_logs | 0 |
The single visible memberships row is the pending user’s own (`user_id = auth.uid()`) — the documented exception in 0008 so the app can show “awaiting approval”: `[{"institute_id":"00000000-0000-4000-8000-000000000001","role":"student","status":"pending"}]`
Everything else — institutes, batches, students, attendance, marks, fees, materials, leads, notices, notifications, interventions, audit logs — returns zero rows. `auth_institute_ids()` counts ACTIVE memberships only, so no policy that scopes by institute can pass.

## Check 5 · teacher cannot change roles, edit fees, manage staff, or approve their own leave
Signed in as the seeded teacher Rohit Verma (`00000000-0000-4000-8000-000000000003`, class teacher of 10-A, active teacher membership in A):

(a) changing a role:
```sql
  update public.memberships set role = 'admin'
  where institute_id = '00000000-0000-4000-8000-000000000001' and user_id = '00000000-0000-4000-8000-000000000004';
```
```sql
  insert into public.memberships (id, institute_id, user_id, role, status, permissions)
  values ('30000000-0000-4000-8000-00000000a006', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000003', 'owner', 'active', '{}');
```

(b) editing fee structures:
```sql
  update public.fee_structures set total_amount = 1 where institute_id = '00000000-0000-4000-8000-000000000001';
```
```sql
  select public.save_fee_plan('00000000-0000-4000-8000-000000000001', '{"batchId":"00000000-0000-4000-8000-000000000009","batchIds":["00000000-0000-4000-8000-000000000009"],"totalAmount":1,"schedule":[{"amount":1}]}'::jsonb);
```

(c) managing staff:

(d) approving their own leave:
```sql
  update public.leave_requests set status = 'approved', reviewed_by = '00000000-0000-4000-8000-000000000003', reviewed_at = now()
  where user_id = '00000000-0000-4000-8000-000000000003';
```

| attempt | expected | result | outcome | error |
| --- | --- | --- | --- | --- |
| promote another teacher to admin | expect zero rows | blocked | 0 rows |  |
| promote self to owner | expect zero rows | blocked | 0 rows |  |
| insert a new owner membership | expect error | blocked | SQLSTATE 42501 | only an owner can grant the owner role |
| rewrite fee totals | expect zero rows | blocked | 0 rows |  |
| insert a fee structure | expect error | blocked | SQLSTATE 42501 | new row violates row-level security policy for table "fee_structures" |
| call save_fee_plan RPC | expect error | blocked | SQLSTATE 42501 | Only the owner can change fee plans |
| insert a teacher profile | expect error | blocked | SQLSTATE 42501 | new row violates row-level security policy for table "teacher_profiles" |
| edit a staff record | expect zero rows | blocked | 0 rows |  |
| insert a staff record | expect error | blocked | SQLSTATE 42501 | new row violates row-level security policy for table "staff_records" |
| approve own pending leave | expect error | blocked | SQLSTATE 42501 | new row violates row-level security policy for table "leave_requests" |
| approve a colleague’s leave | expect zero rows | blocked | 0 rows |  |
| cancel own pending leave (allowed) | succeeds (allowed) | blocked | 1 rows |  |

## Check 6 · a user cannot update their own membership role
Signed in as the seeded student Aarav (`00000000-0000-4000-8000-000000000014`):
```sql
  update public.memberships set role = 'owner'  where institute_id = '00000000-0000-4000-8000-000000000001' and user_id = '00000000-0000-4000-8000-000000000014';
```
role→owner: 0 rows · role→teacher: 0 rows · status→suspended: 0 rows

The policy layer blocks a plain member entirely (0 rows — `memberships_update` needs the `members` permission). An **admin who holds that permission** passes the policy, so the `membership_guard()` trigger is the second layer. Signed in as the admin `30000000-0000-4000-8000-000000000005` (permissions `{members}`):
```sql
  update public.memberships set role = 'owner' where id = '30000000-0000-4000-8000-000000000005';
```
admin self-promotion to owner: SQLSTATE 42501 — only an owner can change a role
admin self-grant of extra permissions: SQLSTATE 42501 — only an owner can change permissions
select role, permissions from public.memberships where id = '30000000-0000-4000-8000-000000000005';
→ `[{"role":"admin","permissions":["members"]}]` (unchanged)

## Check 9 · storage buckets — avatars public, everything else private + short-TTL signed URLs
```sql
  select id, public, file_size_limit, allowed_mime_types from storage.buckets order by id;
```
→ [{"id":"attachments","public":false,"file_size_limit":52428800,"allowed_mime_types":null},{"id":"avatars","public":true,"file_size_limit":2097152,"allowed_mime_types":["image/png","image/jpeg","image/webp"]}]
```sql
  select policyname, cmd, roles from pg_policies where schemaname = 'storage';
```
| policy | cmd | roles |
| --- | --- | --- |
| attachments owner delete | DELETE | authenticated |
| attachments owner update | UPDATE | authenticated |
| attachments tenant read | SELECT | authenticated |
| attachments tenant write | INSERT | authenticated |
| avatars owner write | ALL | authenticated |
| avatars public read | SELECT | anon,authenticated |
avatars bucket public-read: yes · every other bucket private: yes.
Signed-URL TTL: `src/adapters/supabase/storage.adapter.ts` default `expiresInSeconds = 900` seconds (15 minutes).

## Check 12 · rate limiting on auth and on the public join-by-code path

(a) join-by-code enumeration — there is no public read of institute rows:
```sql
  select count(*) from public.institutes where code = 'RIVAL-MUM';
  select count(*) from public.institutes;
  select count(*) from public.institutes where name ilike '%rival%';
```
→ by code: 0 · all institutes: 0 · by name search: 0 (a member sees only their own; a non-member sees nothing — the read fails closed, so there is no code-enumeration oracle)
positive control, signed in as the student: own institute by code `SUNRISE-PAT` → 1 row.

(b) the one public write — a self-serve pending join request — is rate-limited in the database:
```sql
  insert into public.memberships (id, institute_id, user_id, role, status, permissions)
  values ('<id>', '<institute n>', '40000000-0000-4000-8000-000000000001', 'student', 'pending', '{}');  -- × 6
```
| attempt | outcome | error |
| --- | --- | --- |
| join request #1 | accepted |  |
| join request #2 | accepted |  |
| join request #3 | accepted |  |
| join request #4 | accepted |  |
| join request #5 | accepted |  |
| join request #6 | SQLSTATE P0004 | Too many join requests. Please wait a while before asking to join another instit |
service-role / staff-created rows bypass the limiter (actor is null or the row is not a self-serve pending request): accepted.
Auth rate limiting: sign-in / sign-up / OTP / password-reset are Supabase Auth endpoints, rate-limited by the platform (per-IP and per-factor limits configurable in the dashboard); the client additionally throttles its own auth calls (`src/adapters/supabase/auth-rate-limit.ts`, 5 per 60 s) — see the unit evidence in the transcript.

## Check 7 · service-role key must not reach the client bundle
Searched 4 built files in `dist/` for `service[_-]?role` (case-insensitive): **0 hits**.
Distinct JWT-shaped strings in the bundle: 
- `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9 eyJyb2xlIjoiYW5vbiIsIm1hcmtlciI6IkFORU9OLU1BUktFUiJ9`

## Check 8 · `grep -rn "supabase" src/features app/`
```bash
grep -rn "supabase" src/features app/   # → 0 hits (exit 1)
grep -rni "supabase" src/features app/  # → 0 hits
```
No feature or route file mentions Supabase. All SDK access lives behind `src/adapters/supabase/`.

## Check 10 · sessions in expo-secure-store, never AsyncStorage
`AsyncStorage` occurrences in `src/`:
- `src/adapters/supabase/client.ts:17` → `* the device keychain through expo-secure-store — never AsyncStorage. On`
- `src/features/attendance/hooks/useTakeAttendance.ts:78` → `* or (offline) queue in AsyncStorage for the root flusher.`
- `src/features/attendance/outbox.ts:1` → `import AsyncStorage from '@react-native-async-storage/async-storage';`
- `src/features/attendance/outbox.ts:8` → `* a newer save of the same sheet replaces the older one. Persisted in AsyncStorage`
- `src/features/attendance/outbox.ts:33` → `this.loaded = Promise.all([AsyncStorage.getItem(QUEUE_KEY), AsyncStorage.getItem(SYNC_KEY)])`
- `src/features/attendance/outbox.ts:60` → `void AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(this.items)).catch(() => undefined);`
- `src/features/attendance/outbox.ts:93` → `void AsyncStorage.setItem(SYNC_KEY, at).catch(() => undefined);`
- `src/features/auth/screens/OnboardingScreen.tsx:3` → `import AsyncStorage from '@react-native-async-storage/async-storage';`
- `src/features/auth/screens/OnboardingScreen.tsx:20` → `await AsyncStorage.setItem('gf.onboarding.seen', '1');`
- `src/features/homework/submissionOutbox.ts:1` → `import AsyncStorage from '@react-native-async-storage/async-storage';`
- `src/features/homework/submissionOutbox.ts:25` → `this.loaded = Promise.all([AsyncStorage.getItem(QUEUE_KEY), AsyncStorage.getItem(SYNC_KEY)])`
- `src/features/homework/submissionOutbox.ts:51` → `void AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(this.items)).catch(() => undefined);`
- `src/features/homework/submissionOutbox.ts:83` → `void AsyncStorage.setItem(SYNC_KEY, at).catch(() => undefined);`
- `src/features/search/useSearch.ts:2` → `import AsyncStorage from '@react-native-async-storage/async-storage';`
- `src/features/search/useSearch.ts:21` → `void AsyncStorage.getItem(RECENT_KEY).then((raw) => {`
- `src/features/search/useSearch.ts:33` → `void AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch(() => undefined);`
- `src/features/search/useSearch.ts:39` → `await AsyncStorage.removeItem(RECENT_KEY).catch(() => undefined);`
- `src/features/search/useSearch.ts:44` → `void AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch(() => undefined);`
- `src/features/student/homework/hooks.ts:4` → `import AsyncStorage from '@react-native-async-storage/async-storage';`
- `src/features/student/materials/hooks.ts:2` → `import AsyncStorage from '@react-native-async-storage/async-storage';`
- `src/features/student/materials/hooks.ts:18` → `const raw = await AsyncStorage.getItem(OFFLINE_KEY);`
- `src/features/student/materials/hooks.ts:31` → `await AsyncStorage.setItem(OFFLINE_KEY, JSON.stringify([...next]));`
None of the lines above read or write a session, token or key — they are the onboarding-seen flag, offline outboxes and the recent-searches cache.
Reference backend session: `src/backends/memory/auth.ts` uses `expo-secure-store` — confirmed.
Live backend session: `src/adapters/supabase/client.ts` passes a secure storage adapter to `createClient` — confirmed (expo-secure-store on native; localStorage on web where SecureStore does not exist).

## Check 11 · webhook signature verification (Razorpay)
`grep -rni "razorpay\|webhook" src app supabase` → 1 hits:
- `src/core/contracts/ports/finance.ts:100` → `/** The online payment gateway (Razorpay, Stripe, …). Desk payments go through PaymentRepo. */`
No payment gateway and no webhook endpoint exist in the project yet — there is nothing to verify and nothing that trusts an unsigned callback. The requirement for the day Razorpay is added is written into docs/SECURITY.md.

---

## Database-side verdict
| check | result |
| --- | --- |
| 1 · RLS + policies per table | PASS |
| 2 · cross-tenant reads (student A → B) | PASS |
| 3 · parent vs another family | PASS |
| 4 · pending member reads nothing | PASS |
| 5 · teacher restrictions | PASS |
| 6 · self-membership role change | PASS |
| 9 · storage buckets | PASS |
| 12 · rate limiting (database half) | PASS |
