# Store listing and data safety — draft, not approved for submission

## Listing

**App title:** GuruFlow — Coaching Management

**Short description:** Manage classes, attendance, fees and student progress in one place.

**Full description:** GuruFlow helps coaching institutes organize their day. Owners and teachers can manage batches, take attendance, plan lessons, record marks and follow up on fees. Students can see their classes, homework and progress, while parents can follow linked children's updates. In-app notices keep institute members informed. Access depends on institute membership and role. Features and availability may vary by institute. Online payments and some live services require separate configuration and are not available in the reference preview.

## Proposed Google Play data-safety answers

These are a source-code inventory for a prospective live deployment, **not verified declarations**. The publisher must validate actual configured SDKs, data flows, sub-processors, retention, deletion, security and regional obligations before submitting. The local reference backend and a future hosted deployment have materially different answers.

| Question / category | Proposed answer and purpose |
| --- | --- |
| Data collected? | Yes for a hosted service; institute/user-entered data is sent to its backend. |
| Personal info | Names, email, phone, address, profile details, user identifiers, student/guardian relationships, and optional dates of birth; account management and app functionality. |
| Health and fitness | Optional student blood group is present in the data model; treat as sensitive health information if collected. Avoid collection unless necessary and consented. |
| Financial info | Fee amounts, payment status, payment method and transaction references for institute operations. No card number or bank account field identified in this source inventory; reassess when adding a payment provider. |
| Photos and videos / files | Optional profile photos, homework submissions and attachments for app functionality. |
| Messages / other user-generated content | Notices, questions, feedback, leave requests and assignments, for communication and education. |
| Education information | Attendance, batches, grades, homework, exam results and related progress; app functionality. |
| Device identifiers, diagnostics, analytics, location | No dedicated collection identified by this source review; verify Expo, hosting, backend and all production SDK configurations before answering. Address/city are user-entered personal info, not precise device location. |
| Data shared? | Hosted data is processed by the configured hosting/backend providers and may be visible to authorized institute members; determine whether each transfer constitutes Play-defined sharing and declare each provider's practices. No sale identified in this review. |
| Collection optional? | Some profile and attachment fields are optional, but account and institute records are necessary for service. Verify field-by-field with the release. |
| Encrypted in transit? | Require HTTPS/TLS for every production endpoint; verify deployed configuration before answering yes. |
| Deletion | Account/data deletion flow, request URL, retention and backups have not been verified. Implement and publish an accessible deletion process before answering or submitting. |

## Children and family declaration

The app has student and parent roles and can hold information about children. Intended age groups and whether children are a target audience must be determined by the publisher based on actual distribution; do not represent the app as adult-only without that review. If children are included, comply with applicable Google Play Families policies, restrict SDKs/ads accordingly, and ensure an age-appropriate experience. No advertising SDK was identified in the inspected project, but verify the final dependency/build configuration.

For India, the Digital Personal Data Protection framework requires verifiable parental/guardian consent before processing children's personal data, subject to applicable law, exemptions and commencement; obtain legal advice on current requirements. The app does **not** currently implement a verified parental-consent workflow. Implement consent, withdrawal, guardian verification, safeguards and deletion before processing child data or submitting. Prepare privacy policy, support contact, privacy-policy URL, app-access instructions, testing credentials, content rating and verified screenshots for the actual release. No submission-ready URLs or publisher identity were supplied.
