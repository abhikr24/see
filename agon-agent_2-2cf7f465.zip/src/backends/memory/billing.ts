import type { BillingCycle, BillingMethod, ID, Invoice, Plan, Subscription } from '../../core/contracts/models';
import type { SubscriptionRepo } from '../../core/contracts/ports';
import { accessFor } from '../../core/contracts/subscription-access';
import type { Db } from './db';
import { governingSubscription, requireOwner } from './subscription-gate';
import { addDays, fail, nowIso, todayIso } from './store';

const UPI_LABEL = 'rahul@okaxis';

function shiftMonth(isoDate: string, months: number): string {
  const [year, month, day] = isoDate.split('-').map(Number);
  const next = new Date(Date.UTC(year, month - 1 + months, 1));
  const last = new Date(Date.UTC(next.getUTCFullYear(), next.getUTCMonth() + 1, 0)).getUTCDate();
  const clamped = Math.min(day, last);
  const stamped = new Date(Date.UTC(next.getUTCFullYear(), next.getUTCMonth(), clamped));
  return stamped.toISOString().slice(0, 10);
}

function priceOf(plan: Plan | null, cycle: BillingCycle): number {
  if (!plan) return 0;
  return cycle === 'yearly' ? plan.priceYearly : plan.priceMonthly;
}

export function invoicesFor(instituteId: ID, plan: Plan | null, sub: Subscription | null, today = todayIso()): Invoice[] {
  const cycle = sub?.billingCycle ?? 'monthly';
  const amount = priceOf(plan, cycle);
  const step = cycle === 'yearly' ? -12 : -1;
  return [2, 1, 0].map((ago) => {
    const issuedOn = shiftMonth(today, ago * step);
    const [year, month] = issuedOn.split('-');
    const number = `INV-${year}-${month}`;
    return {
      id: `${instituteId}:${number}`,
      number,
      issuedOn,
      amount,
      status: 'paid' as const,
      downloadUrl: `memory://invoices/${number}.pdf`,
    };
  });
}

function method(db: Db, instituteId: ID): BillingMethod {
  return {
    id: `${instituteId}:upi`,
    kind: 'upi',
    label: UPI_LABEL,
    autopay: db.billingAutopay.get(instituteId) ?? true,
  };
}

export function subscriptionRepo(db: Db): SubscriptionRepo {
  const current = (instituteId: ID) =>
    db.subscriptions.all(instituteId).find((item) => item.status !== 'cancelled' && item.status !== 'expired') ?? null;

  return {
    getCurrent: async (instituteId) => current(instituteId),
    latest: async (instituteId) => governingSubscription(db, instituteId),
    listPlans: async (instituteId) =>
      db.plans.all(instituteId, { isActive: true }).sort((a, b) => a.priceMonthly - b.priceMonthly),
    changePlan: async (instituteId, planId, billingCycle) => {
      requireOwner(db, instituteId);
      const plan = db.plans.get(instituteId, planId);
      if (!plan.isActive) fail('VALIDATION', 'That plan is no longer offered');
      const start = nowIso();
      const end = `${addDays(todayIso(), billingCycle === 'yearly' ? 365 : 30)}T00:00:00.000Z`;
      const period = {
        planId,
        billingCycle,
        status: 'active' as const,
        currentPeriodStart: start,
        currentPeriodEnd: end,
      };
      const existing = governingSubscription(db, instituteId);
      if (existing) return db.subscriptions.update(instituteId, existing.id, { ...period, cancelAt: null, cancelledAt: null });
      return db.subscriptions.insert(instituteId, {
        ...period,
        trialEndsAt: null,
        cancelAt: null,
        cancelledAt: null,
        provider: 'memory',
        providerSubscriptionId: null,
      });
    },
    cancel: async (instituteId) => {
      requireOwner(db, instituteId);
      const existing = current(instituteId) ?? governingSubscription(db, instituteId);
      if (!existing || existing.status === 'cancelled' || existing.status === 'expired') {
        fail('NOT_FOUND', 'There is no subscription to cancel');
      }
      // Keep the paid period. Do not touch students, attendance or fees.
      const periodEnd = existing.currentPeriodEnd ?? existing.trialEndsAt ?? `${addDays(todayIso(), 30)}T00:00:00.000Z`;
      return db.subscriptions.update(instituteId, existing.id, {
        status: 'cancelled',
        cancelledAt: nowIso(),
        cancelAt: periodEnd,
        currentPeriodEnd: periodEnd,
      });
    },
    lapse: async (instituteId) => {
      const before = db.students.all(instituteId).length;
      const existing = governingSubscription(db, instituteId);
      if (existing && existing.status !== 'expired') {
        db.subscriptions.update(instituteId, existing.id, { status: 'expired', currentPeriodEnd: nowIso() });
      }
      return { status: 'expired' as const, students: db.students.all(instituteId).length === before ? before : db.students.all(instituteId).length, retained: true as const };
    },
    access: async (instituteId) => accessFor(governingSubscription(db, instituteId)),
    listUsage: async (instituteId) => db.usage.all(instituteId),
    billingMethod: async (instituteId) => method(db, instituteId),
    setAutopay: async (instituteId, autopay) => {
      requireOwner(db, instituteId);
      db.billingAutopay.set(instituteId, autopay);
      return method(db, instituteId);
    },
    listInvoices: async (instituteId) => {
      const sub = governingSubscription(db, instituteId);
      const plan = sub ? db.plans.get(instituteId, sub.planId) : null;
      return invoicesFor(instituteId, plan, sub);
    },
  };
}
