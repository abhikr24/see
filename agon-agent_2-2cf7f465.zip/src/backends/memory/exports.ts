import type { ExportKind, ID } from '../../core/contracts/models';
import type { ExportRepo, ExportRequest } from '../../core/contracts/ports';
import type { Db } from './db';
import { capture, restore } from './persist';
import { requireOwner } from './subscription-gate';
import { fail, nowIso } from './store';

const CLEAR_PHRASE = 'CLEAR';

function csv(headers: string[], rows: string[][]): string {
  const esc = (value: string) => (/[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value);
  return [headers.join(','), ...rows.map((row) => row.map((cell) => esc(cell ?? '')).join(','))].join('\n');
}

export function buildExportBody(db: Db, instituteId: ID, kind: ExportKind, format: ExportRequest['format']): string {
  if (kind === 'full' || format === 'json') return capture(db);
  if (kind === 'students') {
    return csv(
      ['fullName', 'phone', 'admissionNo', 'status', 'admittedOn'],
      db.students.all(instituteId).map((row) => [row.fullName, row.phone ?? '', row.admissionNo ?? '', row.status, row.admittedOn]),
    );
  }
  if (kind === 'attendance') {
    const sessions = new Map(db.attendanceSessions.all(instituteId).map((row) => [row.id, row]));
    return csv(
      ['date', 'studentId', 'status'],
      db.attendanceRecords.all(instituteId).map((row) => [sessions.get(row.sessionId)?.date ?? '', row.studentId, row.status]),
    );
  }
  if (kind === 'fees' || kind === 'payments') {
    return csv(
      ['studentId', 'label', 'amount', 'paidAmount', 'dueDate', 'status'],
      db.installments.all(instituteId).map((row) => [row.studentId, row.label, String(row.amount), String(row.paidAmount), row.dueDate, row.status]),
    );
  }
  const count = rowCount(db, kind, instituteId);
  return csv(['kind', 'rows'], [[kind, String(count)]]);
}

function rowCount(db: Db, kind: ExportKind, instituteId: ID): number {
  switch (kind) {
    case 'students':
    case 'full':
      return db.students.all(instituteId).length;
    case 'attendance':
      return db.attendanceRecords.all(instituteId).length;
    case 'marks':
      return db.marks.all(instituteId).length;
    case 'results':
      return db.results.all(instituteId).length;
    case 'fees':
    case 'payments':
      return db.installments.all(instituteId).length;
    case 'leads':
      return db.leads.all(instituteId).length;
    case 'audit':
      return db.auditLogs.all(instituteId).length;
    default:
      return fail('VALIDATION', 'Unknown export');
  }
}

const WIPE = [
  'students', 'guardians', 'studentMemberships', 'parentLinks', 'enrollments',
  'attendanceSessions', 'attendanceRecords', 'attendanceCorrections',
  'assignments', 'submissions', 'marks', 'results', 'exams', 'examQuestions',
  'installments', 'payments', 'receipts', 'studentFees', 'refunds',
  'notices', 'notifications', 'doubts', 'leads', 'followups',
  'invitations', 'leaveRequests', 'studentLeaveRequests', 'exportJobs',
] as const;

function wipeOperational(db: Db, instituteId: ID): void {
  for (const key of WIPE) {
    const table = db[key] as { all: (id: ID) => { id: ID }[]; remove: (instituteId: ID, id: ID) => void };
    for (const row of [...table.all(instituteId)]) table.remove(instituteId, row.id);
  }
}

function statusOf(db: Db, instituteId: ID) {
  db.institutes.get(instituteId, instituteId);
  return { lastBackupAt: db.lastBackupAt.get(instituteId) ?? null, automatic: true };
}

export function exportRepo(db: Db): ExportRepo {
  return {
    list: async (instituteId, query) => db.exportJobs.page(instituteId, query),
    start: async (instituteId, request) => {
      requireOwner(db, instituteId);
      const count = rowCount(db, request.kind, instituteId);
      const body = buildExportBody(db, instituteId, request.kind, request.format);
      const job = db.exportJobs.insert(instituteId, {
        kind: request.kind,
        format: request.format,
        status: 'completed',
        rowCount: count,
        fileUrl: null,
        error: null,
        requestedBy: db.session.userId,
        completedAt: nowIso(),
      });
      db.exportPayloads.set(job.id, body);
      if (request.kind === 'full') db.lastBackupAt.set(instituteId, job.completedAt ?? nowIso());
      return db.exportJobs.update(instituteId, job.id, { fileUrl: `memory://exports/${job.id}.${request.format}` });
    },
    get: async (instituteId, jobId) => db.exportJobs.get(instituteId, jobId),
    status: async (instituteId) => statusOf(db, instituteId),
    recordBackup: async (instituteId) => {
      requireOwner(db, instituteId);
      db.lastBackupAt.set(instituteId, nowIso());
      return statusOf(db, instituteId);
    },
    content: async (instituteId, jobId) => {
      const job = db.exportJobs.get(instituteId, jobId);
      return db.exportPayloads.get(job.id) ?? buildExportBody(db, instituteId, job.kind, job.format);
    },
    importJson: async (instituteId, payload) => {
      requireOwner(db, instituteId);
      const trimmed = payload.trim();
      if (!trimmed.startsWith('{')) fail('VALIDATION', 'That file is not a GuruFlow backup');
      const ok = restore(db, trimmed);
      if (!ok) fail('VALIDATION', 'That backup could not be read');
      return {
        students: db.students.all(instituteId).length,
        attendance: db.attendanceRecords.all(instituteId).length,
        fees: db.installments.all(instituteId).length,
      };
    },
    clearAll: async (instituteId, confirmation) => {
      requireOwner(db, instituteId);
      if (confirmation.trim() !== CLEAR_PHRASE) fail('VALIDATION', 'Type CLEAR to confirm');
      const kept = db.subscriptions.all(instituteId).length;
      wipeOperational(db, instituteId);
      if (db.subscriptions.all(instituteId).length !== kept) {
        fail('UNKNOWN', 'Subscription rows must survive a data clear');
      }
      return { students: db.students.all(instituteId).length, subscriptionKept: true as const };
    },
  };
}
