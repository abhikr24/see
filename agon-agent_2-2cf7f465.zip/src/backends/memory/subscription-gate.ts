import { BackendError } from '../../core/contracts/errors';
import type { ID, Subscription } from '../../core/contracts/models';
import { accessFor, type RestrictedFeature } from '../../core/contracts/subscription-access';
import type { Db } from './db';
import { callerRole } from './teacher-scope';
import { fail } from './store';

/** Live plan if there is one, otherwise the most recently updated row. */
export function governingSubscription(db: Db, instituteId: ID): Subscription | null {
  const all = db.subscriptions.all(instituteId);
  const live = all.find((item) => item.status === 'trialing' || item.status === 'active' || item.status === 'past_due');
  if (live) return live;
  return [...all].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0] ?? null;
}

/**
 * Lapsed plans keep every institute row. This only refuses a non-essential write.
 */
export function assertFeatureOpen(db: Db, instituteId: ID, feature: RestrictedFeature): void {
  const access = accessFor(governingSubscription(db, instituteId));
  if (!access.restricted) return;
  throw new BackendError('FORBIDDEN', 'subscription_restricted', {
    details: { reason: 'subscription_restricted', feature, retained: true },
  });
}

/** Owner check lives in the repository, not the screen. */
export function requireOwner(db: Db, instituteId: ID): ID {
  const userId = db.session.userId ?? fail('UNAUTHENTICATED');
  if (callerRole(db, instituteId) !== 'owner') {
    fail('FORBIDDEN', 'Only an owner can do that');
  }
  return userId;
}
