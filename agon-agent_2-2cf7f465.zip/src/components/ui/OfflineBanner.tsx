import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import NetInfo from '@react-native-community/netinfo';
import { C, R, LAYOUT } from '@/lib/theme';
import { Text } from './Text';
import { useBackend } from '@/core/backend';
import { attendanceOutbox } from '@/features/attendance/outbox';
import { submissionOutbox } from '@/features/homework/submissionOutbox';
import { commitSheet } from '@/features/attendance/commit';
import { useOutbox as useAttendanceOutbox } from '@/features/attendance/hooks/useOutbox';
import { useSubmissionOutbox } from '@/features/homework/useSubmissionOutbox';

function formatAgo(iso: string | null): string {
  if (!iso) return 'just now';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.floor(diff / 60000));
  if (mins < 1) return 'just now';
  if (mins === 1) return '1 min ago';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs === 1) return '1 hr ago';
  return `${hrs} hrs ago`;
}

/**
 * OfflineBanner — calm, never red, never a modal.
 * Shows "Last synced X min ago" and Retry flushes attendance + submissions queues.
 */
export function OfflineBanner() {
  const { backend } = useBackend();
  const attendance = useAttendanceOutbox();
  const submissions = useSubmissionOutbox();
  const [online, setOnline] = useState(true);
  const [flushing, setFlushing] = useState(false);

  useEffect(() => {
    let mounted = true;
    void NetInfo.fetch().then((s) => {
      if (mounted) setOnline(s.isConnected !== false && s.isInternetReachable !== false);
    });
    const unsub = NetInfo.addEventListener((s) => setOnline(s.isConnected !== false && s.isInternetReachable !== false));
    return () => {
      mounted = false;
      unsub();
    };
  }, []);

  const queued = attendance.items.length + submissions.items.length;
  const lastSynced = attendance.lastSyncedAt ?? submissions.lastSyncedAt ?? null;
  const show = !online || queued > 0;
  if (!show) return null;

  const title = !online
    ? queued > 0
      ? `Saved on this phone · ${queued} waiting to sync`
      : 'You are offline · work will queue on this phone'
    : queued > 0
      ? `Offline queue · ${queued} ${queued === 1 ? 'item' : 'items'} waiting`
      : 'Back online · syncing…';

  const handleRetry = useCallback(async () => {
    if (flushing) return;
    setFlushing(true);
    try {
      const net = await NetInfo.fetch();
      const isOnlineNow = net.isConnected !== false && net.isInternetReachable !== false;
      if (!isOnlineNow) return;
      // Flush attendance
      const pendingA = attendanceOutbox.list().filter((i) => i.backendName === backend.name);
      for (const item of pendingA) {
        try {
          await commitSheet(backend, item.instituteId, item.input);
          attendanceOutbox.remove(item.key, item.queuedAt);
          attendanceOutbox.markSynced();
        } catch {
          break;
        }
      }
      // Flush submissions
      const pendingS = submissionOutbox.list().filter((i) => i.backendName === backend.name);
      for (const item of pendingS) {
        try {
          await backend.submissions.submit(item.instituteId, item.input as never);
          submissionOutbox.remove(item.key, item.queuedAt);
          submissionOutbox.markSynced();
        } catch (e: unknown) {
          const code = (e as { code?: string })?.code;
          if (code === 'NETWORK' || code === 'TIMEOUT' || code === 'UNAVAILABLE') break;
          submissionOutbox.remove(item.key, item.queuedAt);
        }
      }
    } finally {
      setFlushing(false);
    }
  }, [backend, flushing]);

  return (
    <View
      accessibilityRole="summary"
      accessibilityLabel={`Offline banner: ${title}. Last synced ${formatAgo(lastSynced)}`}
      style={{
        marginHorizontal: LAYOUT.margin,
        marginTop: 10,
        marginBottom: 2,
        paddingHorizontal: 14,
        paddingVertical: 11,
        borderRadius: R.field,
        backgroundColor: C.navyTint,
        borderWidth: 1,
        borderColor: C.hairline,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
      }}
    >
      <View
        style={{
          width: 32,
          height: 32,
          borderRadius: 16,
          backgroundColor: C.surface,
          alignItems: 'center',
          justifyContent: 'center',
          borderWidth: 1,
          borderColor: C.hairline,
        }}
      >
        <Ionicons name={online ? 'sync-outline' : 'cloud-offline-outline'} size={16} color={C.secondary} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <Text weight={600} c={C.ink} style={{ fontSize: 13 }}>
          {title}
        </Text>
        <Text c={C.secondary} style={{ fontSize: 12 }}>
          Last synced {formatAgo(lastSynced)}
        </Text>
      </View>
      {queued > 0 ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Retry syncing offline queue"
          onPress={handleRetry}
          disabled={flushing}
          style={({ pressed }) => ({
            paddingHorizontal: 14,
            height: 34,
            borderRadius: R.chip,
            backgroundColor: C.primary,
            alignItems: 'center',
            justifyContent: 'center',
            opacity: pressed ? 0.88 : flushing ? 0.6 : 1,
          })}
        >
          <Text weight={700} c={C.surface} style={{ fontSize: 12 }}>
            {flushing ? 'Retrying…' : 'Retry'}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export default OfflineBanner;
