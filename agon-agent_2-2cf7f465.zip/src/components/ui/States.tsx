import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { C, R, type Tone } from '@/lib/theme';
import { Text } from './Text';
import { Button } from './Button';
import { EmptyArt } from './EmptyArt';

export interface SkeletonProps {
  h?: number;
  w?: number | string;
  r?: number;
  className?: string;
}

export function Skeleton({ h = 16, w = '100%', r = 8, className }: SkeletonProps) {
  const opacity = useSharedValue(0.55);
  useEffect(() => {
    opacity.value = withRepeat(withTiming(1, { duration: 850 }), -1, true);
  }, [opacity]);
  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return (
    <Animated.View
      className={className}
      style={[{ height: h, width: w as number, borderRadius: r, backgroundColor: C.track }, animatedStyle]}
    />
  );
}

export interface ListSkeletonProps {
  rows?: number;
  h?: number;
  className?: string;
}

export function ListSkeleton({ rows = 5, h = 68, className }: ListSkeletonProps) {
  return (
    <View className={className} style={{ gap: 12 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <View
          key={i}
          style={{
            height: h,
            borderRadius: R.card,
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            padding: 14,
            flexDirection: 'row',
            gap: 12,
            alignItems: 'center',
          }}
        >
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.track }} />
          <View style={{ flex: 1, gap: 8 }}>
            <Skeleton h={12} w="55%" />
            <Skeleton h={10} w="35%" />
          </View>
        </View>
      ))}
    </View>
  );
}

/** Content-shaped skeleton: icon + two lines + card list, no layout shift. */
export function CardGridSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <View style={{ gap: 12 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <View
          key={i}
          style={{
            height: 96,
            borderRadius: R.card,
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            padding: 14,
            gap: 10,
          }}
        >
          <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: C.track }} />
            <View style={{ flex: 1, gap: 8 }}>
              <Skeleton h={12} w="45%" />
              <Skeleton h={10} w="65%" />
            </View>
            <Skeleton h={22} w={64} r={R.chip} />
          </View>
          <Skeleton h={8} w="100%" r={6} />
        </View>
      ))}
    </View>
  );
}

export type EmptyVariant = 'students' | 'homework' | 'payments' | 'approvals';

const VARIANT_PRESET: Record<EmptyVariant, { icon: keyof typeof Ionicons.glyphMap; tone: Tone; title: string; text: string }> = {
  students: {
    icon: 'people-outline',
    tone: 'primary',
    title: 'No students yet',
    text: 'Admissions land here. Add your first student or convert an enquiry to get started.',
  },
  homework: {
    icon: 'book-outline',
    tone: 'teal',
    title: 'No homework due',
    text: 'You’re all caught up. New assignments will appear here when a teacher sends them.',
  },
  payments: {
    icon: 'wallet-outline',
    tone: 'accent',
    title: 'No payments yet',
    text: 'Fees you collect will show here. Pull to refresh or tap Collect to record one.',
  },
  approvals: {
    icon: 'checkmark-done-circle-outline',
    tone: 'success',
    title: 'Nothing to approve',
    text: 'New join requests will appear here. Share your institute code so students can find you.',
  },
};

export interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  tone?: Tone;
  title?: string;
  text?: string;
  variant?: EmptyVariant;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  icon,
  tone,
  title,
  text,
  variant,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  const preset = variant ? VARIANT_PRESET[variant] : null;
  const resolvedIcon = icon ?? preset?.icon ?? 'file-tray-outline';
  const resolvedTone = tone ?? preset?.tone ?? 'primary';
  const resolvedTitle = title ?? preset?.title ?? 'Nothing here yet';
  const resolvedText = text ?? preset?.text ?? undefined;
  return (
    <View
      className={className}
      style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}
    >
      <View style={{ marginBottom: 4 }}>
        <EmptyArt icon={resolvedIcon} tone={resolvedTone} size={88} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>
        {resolvedTitle}
      </Text>
      {resolvedText ? (
        <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 280 }}>
          {resolvedText}
        </Text>
      ) : null}
      {actionLabel && onAction ? (
        <View style={{ marginTop: 10 }}>
          <Button title={actionLabel} onPress={onAction} size="md" full={false} />
        </View>
      ) : null}
    </View>
  );
}

export interface ErrorStateProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorState({
  title = 'This is on us, not on you',
  message,
  onRetry,
  className,
}: ErrorStateProps) {
  return (
    <View
      className={className}
      style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}
    >
      <View style={{ marginBottom: 4 }}>
        <EmptyArt icon="cloud-offline-outline" tone="primary" size={88} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 280 }}>
        {message}
      </Text>
      {onRetry ? (
        <View style={{ marginTop: 10 }}>
          <Button title="Try again" onPress={onRetry} size="md" full={false} />
        </View>
      ) : null}
    </View>
  );
}
