import type { Subscription } from './models';

/**
 * Features that pause when a plan has lapsed.
 * Students, attendance, fees and every other institute row stay put —
 * expiry never deletes data.
 */
export const RESTRICTED_WHEN_LAPSED = ['invites', 'notices', 'branding', 'admissions'] as const;
export type RestrictedFeature = (typeof RESTRICTED_WHEN_LAPSED)[number];

export interface SubscriptionAccess {
  restricted: boolean;
  /** Always true. A lapsed plan does not delete institute data. */
  dataRetained: true;
  blocked: RestrictedFeature[];
}

export function isLapsedSubscription(
  sub: Pick<Subscription, 'status' | 'currentPeriodEnd'> | null | undefined,
  now = Date.now(),
): boolean {
  if (!sub) return false;
  if (sub.status === 'expired') return true;
  if (sub.status !== 'cancelled') return false;
  if (!sub.currentPeriodEnd) return true;
  const end = new Date(sub.currentPeriodEnd).getTime();
  return Number.isFinite(end) && end <= now;
}

export function accessFor(
  sub: Pick<Subscription, 'status' | 'currentPeriodEnd'> | null | undefined,
  now = Date.now(),
): SubscriptionAccess {
  const restricted = isLapsedSubscription(sub, now);
  return {
    restricted,
    dataRetained: true,
    blocked: restricted ? [...RESTRICTED_WHEN_LAPSED] : [],
  };
}
