import { useEffect, useRef } from 'react';
import NetInfo from '@react-native-community/netinfo';
import { useBackend } from '@/core/hooks/context';
import { toast } from '@/core/hooks/toast';
import { submissionOutbox } from './submissionOutbox';

const RETRY_MS = 30_000;

export function SubmissionOutboxSync() {
  const { backend } = useBackend();
  const busy = useRef(false);
  const online = useRef(true);

  useEffect(() => {
    let alive = true;
    const flush = async () => {
      if (busy.current || !online.current) return;
      await submissionOutbox.load();
      const pending = submissionOutbox.list().filter((i) => i.backendName === backend.name);
      if (pending.length === 0) return;
      busy.current = true;
      let synced = 0;
      try {
        for (const item of pending) {
          if (!alive || !online.current) break;
          try {
            await backend.submissions.submit(item.instituteId, item.input as never);
            submissionOutbox.remove(item.key, item.queuedAt);
            submissionOutbox.markSynced();
            synced += 1;
          } catch (e: unknown) {
            const code = (e as { code?: string })?.code;
            if (code === 'NETWORK' || code === 'TIMEOUT' || code === 'UNAVAILABLE') break;
            // For validation/conflict, drop and notify
            submissionOutbox.remove(item.key, item.queuedAt);
            toast.error(`A queued homework submission could not be saved. ${(e as Error).message}`);
          }
        }
      } finally {
        busy.current = false;
      }
      if (synced > 0) toast.success(synced === 1 ? 'Queued homework synced' : `${synced} homework submissions synced`);
    };
    const unsubNet = NetInfo.addEventListener((s) => {
      const next = s.isConnected !== false && s.isInternetReachable !== false;
      const cameBack = next && !online.current;
      online.current = next;
      if (cameBack) void flush();
    });
    const unsubQueue = submissionOutbox.subscribe(() => {
      if (online.current && !busy.current) void flush();
    });
    const timer = setInterval(() => void flush(), RETRY_MS);
    void NetInfo.fetch().then((s) => {
      online.current = s.isConnected !== false && s.isInternetReachable !== false;
      void flush();
    });
    return () => {
      alive = false;
      unsubNet();
      unsubQueue();
      clearInterval(timer);
    };
  }, [backend]);

  return null;
}
