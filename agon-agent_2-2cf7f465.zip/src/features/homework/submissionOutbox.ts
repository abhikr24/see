import AsyncStorage from '@react-native-async-storage/async-storage';
import type { ID } from '@/core/contracts/models';

export interface SubmissionOutboxItem {
  key: string;
  backendName: string;
  instituteId: ID;
  input: { assignmentId: ID; studentId: ID; content?: string | null };
  queuedAt: string;
}

const QUEUE_KEY = 'gf.submissions.outbox.v1';
const SYNC_KEY = 'gf.submissions.lastSync.v1';

type Listener = () => void;

class SubmissionOutbox {
  private items: SubmissionOutboxItem[] = [];
  private lastSync: string | null = null;
  private loaded: Promise<void> | null = null;
  private readonly listeners = new Set<Listener>();

  load(): Promise<void> {
    if (!this.loaded) {
      this.loaded = Promise.all([AsyncStorage.getItem(QUEUE_KEY), AsyncStorage.getItem(SYNC_KEY)])
        .then(([queue, sync]) => {
          const parsed: unknown = queue ? JSON.parse(queue) : [];
          const stored = Array.isArray(parsed) ? (parsed as SubmissionOutboxItem[]) : [];
          const keys = new Set(this.items.map((i) => i.key));
          this.items = [...stored.filter((i) => !keys.has(i.key)), ...this.items];
          this.lastSync = this.lastSync ?? sync;
          this.emit();
        })
        .catch(() => undefined);
    }
    return this.loaded;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(): void {
    this.listeners.forEach((l) => l());
  }

  private persist(): void {
    void AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(this.items)).catch(() => undefined);
  }

  list(): readonly SubmissionOutboxItem[] {
    return this.items;
  }

  get(key: string): SubmissionOutboxItem | undefined {
    return this.items.find((i) => i.key === key);
  }

  lastSyncedAt(): string | null {
    return this.lastSync;
  }

  enqueue(item: SubmissionOutboxItem): void {
    this.items = [...this.items.filter((r) => r.key !== item.key), item];
    this.persist();
    this.emit();
  }

  remove(key: string, queuedAt?: string): void {
    const before = this.items.length;
    this.items = this.items.filter((r) => !(r.key === key && (!queuedAt || r.queuedAt === queuedAt)));
    if (this.items.length !== before) {
      this.persist();
      this.emit();
    }
  }

  markSynced(at: string = new Date().toISOString()): void {
    this.lastSync = at;
    void AsyncStorage.setItem(SYNC_KEY, at).catch(() => undefined);
    this.emit();
  }
}

export const submissionOutbox = new SubmissionOutbox();
