import { useEffect, useSyncExternalStore } from 'react';
import { submissionOutbox, type SubmissionOutboxItem } from './submissionOutbox';

interface View {
  items: readonly SubmissionOutboxItem[];
  lastSyncedAt: string | null;
}

let cached: View = { items: submissionOutbox.list(), lastSyncedAt: submissionOutbox.lastSyncedAt() };

function read(): View {
  const items = submissionOutbox.list();
  const lastSyncedAt = submissionOutbox.lastSyncedAt();
  if (items !== cached.items || lastSyncedAt !== cached.lastSyncedAt) cached = { items, lastSyncedAt };
  return cached;
}

const subscribe = (l: () => void) => submissionOutbox.subscribe(l);

export function useSubmissionOutbox(): View {
  useEffect(() => {
    void submissionOutbox.load();
  }, []);
  return useSyncExternalStore(subscribe, read, read);
}
