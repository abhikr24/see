import React, { useState } from 'react';
import { Linking, Pressable, Share, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, ConfirmDialog, IconBox, ListRow, Text } from '@/components/ui';
import type { ExportFormat, ExportKind } from '@/core/contracts/models';
import { C, R, S } from '@/lib/theme';
import { SettingsBack, SettingsScroll } from './Chrome';
import { useSettingsActions, useSettingsBundle } from './hooks';
import { CLEAR_PHRASE, SUPPORT_PHONE, SUPPORT_VIDEOS, SUPPORT_WHATSAPP, backupStamp } from './model';

const EXPORTS: { title: string; subtitle: string; kind: ExportKind; format: ExportFormat; icon: keyof typeof Ionicons.glyphMap }[] = [
  { title: 'Students CSV', subtitle: 'Names, phones and admission numbers', kind: 'students', format: 'csv', icon: 'people-outline' },
  { title: 'Attendance CSV', subtitle: 'Date, student and status', kind: 'attendance', format: 'csv', icon: 'checkbox-outline' },
  { title: 'Fee records CSV', subtitle: 'Instalments, paid and due', kind: 'fees', format: 'csv', icon: 'wallet-outline' },
  { title: 'Full JSON', subtitle: 'Everything, ready to re-import', kind: 'full', format: 'json', icon: 'code-slash-outline' },
];

export function BackupScreen() {
  const bundle = useSettingsBundle();
  const actions = useSettingsActions();
  const [payload, setPayload] = useState<string | null>(null);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  const runExport = async (kind: ExportKind, format: ExportFormat) => {
    setBusy(kind);
    const result = await actions.exportFile(kind, format);
    setBusy(null);
    if (!result) return;
    if (kind === 'full') setPayload(result.body);
    await Share.share({ message: result.body.slice(0, 4000) });
  };

  return (
    <SettingsScroll>
      <SettingsBack title="Backup and data" subtitle="Exports, restore and help" />
      <View style={{ backgroundColor: C.teal, borderRadius: R.card, padding: 20, gap: 6 }}>
        <Text variant="label" c={C.tealSoft}>BACKUP STATUS</Text>
        <Text variant="h2" c={C.surface}>Last backup</Text>
        <Text c={C.surface} weight={700}>{backupStamp(bundle.data?.backup.lastBackupAt ?? null)}</Text>
        <Text variant="caption" c={C.tealSoft}>{bundle.data?.backup.automatic ? 'Automatic backups are on' : 'Manual backups'}</Text>
        <View style={{ marginTop: 8 }}>
          <Button title="Back up now" variant="secondary" onPress={() => void actions.backupNow()} />
        </View>
      </View>

      <Card pad={6}>
        {EXPORTS.map((item, index) => (
          <ListRow
            key={item.kind}
            title={item.title}
            subtitle={busy === item.kind ? 'Preparing…' : item.subtitle}
            leading={<IconBox name={item.icon} tone="teal" />}
            right={<Ionicons name="download-outline" size={20} color={C.teal} />}
            chevron={false}
            divider={index < EXPORTS.length - 1}
            onPress={() => void runExport(item.kind, item.format)}
          />
        ))}
      </Card>

      {payload ? (
        <Card tint={C.tealSoft}>
          <Text weight={700}>Full JSON is ready to re-import</Text>
          <Text variant="caption" c={C.secondary} style={{ marginTop: 4 }}>{payload.length.toLocaleString('en-IN')} characters</Text>
          <View style={{ marginTop: 12 }}>
            <Button title="Re-import this backup" variant="outline" onPress={() => void actions.importJson(payload)} />
          </View>
        </Card>
      ) : null}

      <Card tint={C.dangerSoft}>
        <Text variant="label" c={C.danger}>DANGER ZONE</Text>
        <Text weight={800} style={{ marginTop: 4 }}>Clear all data</Text>
        <Text variant="caption" c={C.secondary} style={{ marginTop: 4 }}>
          Removes students, attendance and fees. The institute and subscription stay. This is not what happens when a plan expires.
        </Text>
        <View style={{ marginTop: 12 }}>
          <Button title="Clear all data" variant="danger" onPress={() => setConfirm(true)} />
        </View>
      </Card>

      <Card pad={6}>
        <HelpRow icon="play-circle-outline" title="Watch videos" onPress={() => void Linking.openURL(SUPPORT_VIDEOS)} />
        <HelpRow icon="logo-whatsapp" title="WhatsApp support" onPress={() => void Linking.openURL(SUPPORT_WHATSAPP)} divider />
        <HelpRow icon="call-outline" title="Call us" onPress={() => void Linking.openURL(`tel:${SUPPORT_PHONE}`)} />
      </Card>

      <ConfirmDialog
        visible={confirm}
        title="Clear all data?"
        description="Type CLEAR. Students and fees go. The plan is not deleted, and a lapsed subscription never does this on its own."
        confirmText={CLEAR_PHRASE}
        confirmLabel="Clear all data"
        onCancel={() => setConfirm(false)}
        onConfirm={() => { setConfirm(false); void actions.clearAll(CLEAR_PHRASE); }}
      />
    </SettingsScroll>
  );
}

function HelpRow({ icon, title, onPress }: { icon: keyof typeof Ionicons.glyphMap; title: string; onPress: () => void; divider?: boolean }) {
  return (
    <Pressable onPress={onPress} style={{ minHeight: 56, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
      <Ionicons name={icon} size={20} color={C.teal} />
      <Text weight={700} style={{ flex: 1 }}>{title}</Text>
      <Ionicons name="chevron-forward" size={16} color={C.muted} />
    </Pressable>
  );
}
