import React, { useState } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { Button, Card, Text } from '@/components/ui';
import { toast, useBackend } from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import { C, LAYOUT, S } from '@/lib/theme';
import { useSettingsActions } from './hooks';

/** Redeems `guruflow://join?code=&token=` after the person is signed in. */
export function JoinLinkScreen({ code, token }: { code: string; token: string }) {
  const { instituteId, setInstituteId } = useBackend();
  const actions = useSettingsActions();
  const [working, setWorking] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  const redeem = async () => {
    setWorking(true);
    try {
      const membership = await actions.redeem(`guruflow://join?code=${encodeURIComponent(code)}&token=${encodeURIComponent(token)}`);
      if (instituteId == null) setInstituteId(membership.instituteId);
      setDone(membership.role);
      toast.success(`Joined as ${membership.role}`);
    } catch (cause) {
      toast.error(toBackendError(cause).message);
    } finally {
      setWorking(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin, justifyContent: 'center', gap: S.lg }}>
      <Card>
        <Text variant="h2">Join with your invite</Text>
        <Text variant="caption" c={C.secondary} style={{ marginTop: 6 }}>
          {code ? `Institute code ${code}` : 'Open the link your owner shared.'}
        </Text>
        {done ? <Text weight={700} style={{ marginTop: 12 }}>You are in as {done}.</Text> : null}
        <View style={{ marginTop: 16, gap: 8 }}>
          <Button title={done ? 'Joined' : 'Accept invite'} loading={working} disabled={!token || Boolean(done)} onPress={() => void redeem()} />
          <Button title="Back to sign in" variant="outline" onPress={() => router.replace('/(auth)/login' as never)} />
        </View>
      </Card>
    </View>
  );
}
