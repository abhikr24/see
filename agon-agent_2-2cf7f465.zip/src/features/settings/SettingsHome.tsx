import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { router } from 'expo-router';
import { Avatar, Badge, Card, ErrorState, IconBox, ListRow, ListSkeleton, Text } from '@/components/ui';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { C, R, S } from '@/lib/theme';
import { SettingsScroll } from './Chrome';
import { useSettingsActions, useSettingsBundle } from './hooks';
import { planPill } from './model';
import { AboutSheet, BrandSheet, EditInstituteSheet, NotificationsSheet, SessionSheet } from './sheets';

const GROUP_A = [
  { key: 'profile', title: 'Institute profile', subtitle: 'Name, city and phone', icon: 'business-outline' as const, tone: 'primary' as const },
  { key: 'session', title: 'Academic session', subtitle: 'The year fees and batches follow', icon: 'school-outline' as const, tone: 'primary' as const },
  { key: 'brand', title: 'Branding colour', subtitle: 'Navy by default', icon: 'color-palette-outline' as const, tone: 'accent' as const },
  { key: 'alerts', title: 'Notification preferences', subtitle: 'Attendance, homework and notices', icon: 'notifications-outline' as const, tone: 'teal' as const },
  { key: 'staff', title: 'Staff and permissions', subtitle: 'Roles, invites and leave', icon: 'people-outline' as const, tone: 'primary' as const },
  { key: 'backup', title: 'Backup and data', subtitle: 'Export, restore and help', icon: 'cloud-upload-outline' as const, tone: 'teal' as const },
] as const;

export function SettingsHomeScreen() {
  const bundle = useSettingsBundle();
  const actions = useSettingsActions();
  const { signOut, loading: signingOut } = useAuth();
  const [sheet, setSheet] = useState<string | null>(null);
  const data = bundle.data;
  const institute = data?.institute;

  const open = (key: string) => {
    if (key === 'staff') router.push('/(owner)/settings/staff' as never);
    else if (key === 'backup') router.push('/(owner)/settings/backup' as never);
    else setSheet(key);
  };

  return (
    <SettingsScroll>
      <Text variant="h2">Settings</Text>
      {bundle.loading && !data ? <ListSkeleton rows={4} /> : null}
      {bundle.error ? <ErrorState title="Could not load settings" message={bundle.error.message} onRetry={() => void bundle.refetch()} /> : null}
      {institute ? (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.md }}>
            <Avatar name={institute.name} uri={institute.logoUrl} size={64} />
            <View style={{ flex: 1, gap: 2 }}>
              <Text variant="title" weight={800}>{institute.name}</Text>
              <Text variant="caption" c={C.secondary}>{institute.city ?? 'City not set'} · {institute.code}</Text>
            </View>
            <Pressable accessibilityRole="button" accessibilityLabel="Edit institute" onPress={() => setSheet('profile')} style={{ paddingHorizontal: 12, paddingVertical: 8, borderRadius: R.chip, backgroundColor: C.navySoft }}>
              <Text variant="caption" weight={700} c={C.primary}>Edit</Text>
            </Pressable>
          </View>
        </Card>
      ) : null}

      <Card pad={6}>
        {GROUP_A.map((item, index) => (
          <ListRow
            key={item.key}
            title={item.title}
            subtitle={item.key === 'session' ? institute?.settings.academicYear ?? item.subtitle : item.subtitle}
            leading={<IconBox name={item.icon} tone={item.tone} />}
            chevron
            divider={index < GROUP_A.length - 1}
            onPress={() => open(item.key)}
          />
        ))}
      </Card>

      <Card pad={6}>
        <ListRow
          title="Subscription"
          subtitle={data?.plan ? `${data.plan.name} plan` : 'Plan and invoices'}
          leading={<IconBox name="card-outline" tone="primary" />}
          right={<Badge label={planPill(data?.subscription?.status)} tone={planPill(data?.subscription?.status) === 'Active' ? 'success' : 'warning'} small />}
          chevron
          divider
          onPress={() => router.push('/(owner)/settings/subscription' as never)}
        />
        <ListRow title="Help and support" subtitle="Videos, WhatsApp and a phone call" leading={<IconBox name="help-circle-outline" tone="teal" />} chevron divider onPress={() => router.push('/(owner)/settings/backup' as never)} />
        <ListRow title="About" subtitle="GuruFlow for coaching institutes" leading={<IconBox name="information-circle-outline" tone="neutral" />} chevron onPress={() => setSheet('about')} />
      </Card>

      {data?.access.restricted ? (
        <Card tint={C.warningSoft}>
          <Text variant="title" weight={700}>Plan ended — your data is still here</Text>
          <Text variant="caption" c={C.duesInk} style={{ marginTop: 4 }}>
            Students, attendance and fees were not deleted. Renew to invite staff and send notices.
          </Text>
        </Card>
      ) : null}

      <Card pad={6}>
        <ListRow
          title={signingOut ? 'Signing out…' : 'Sign out'}
          subtitle="Leave this device"
          leading={<IconBox name="log-out-outline" tone="danger" />}
          chevron={false}
          disabled={signingOut}
          onPress={() => void signOut()}
        />
      </Card>

      <EditInstituteSheet
        visible={sheet === 'profile'}
        name={institute?.name ?? ''}
        city={institute?.city ?? ''}
        phone={institute?.phone ?? ''}
        onClose={() => setSheet(null)}
        onSave={async (patch) => { const ok = await actions.saveInstitute(patch); if (ok) setSheet(null); }}
      />
      <SessionSheet
        visible={sheet === 'session'}
        current={institute?.settings.academicYear ?? null}
        onClose={() => setSheet(null)}
        onSave={async (academicYear) => { const ok = await actions.saveSettings({ academicYear }); if (ok) setSheet(null); }}
      />
      <BrandSheet
        visible={sheet === 'brand'}
        current={institute?.settings.brandColor ?? null}
        locked={Boolean(data?.access.restricted)}
        onClose={() => setSheet(null)}
        onSave={async (brandColor) => { const ok = await actions.saveSettings({ brandColor }); if (ok) setSheet(null); }}
      />
      <NotificationsSheet
        visible={sheet === 'alerts'}
        features={institute?.settings.features ?? {}}
        onClose={() => setSheet(null)}
        onSave={async (features) => { const ok = await actions.saveSettings({ features }); if (ok) setSheet(null); }}
      />
      <AboutSheet visible={sheet === 'about'} onClose={() => setSheet(null)} />
    </SettingsScroll>
  );
}
