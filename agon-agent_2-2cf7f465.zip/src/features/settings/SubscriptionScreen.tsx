import React, { useState } from 'react';
import { Pressable, Share, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, ConfirmDialog, ProgressBar, Sheet, Text } from '@/components/ui';
import { useSettingsActions, useSettingsBundle } from './hooks';
import { planPill, renewalLabel, usageHelper, usageLine, usageRatio } from './model';
import { SettingsBack, SettingsScroll } from './Chrome';
import { inr } from '@/lib/format';
import { C, R, S } from '@/lib/theme';

export function SubscriptionScreen() {
  const bundle = useSettingsBundle();
  const actions = useSettingsActions();
  const [upgrade, setUpgrade] = useState(false);
  const [cancel, setCancel] = useState(false);
  const data = bundle.data;
  const cap = data?.plan?.maxStudents ?? null;
  const used = data?.used ?? 0;
  const plans = (data?.plans ?? []).filter((plan) => plan.isActive && plan.id !== data?.plan?.id);

  return (
    <SettingsScroll>
      <SettingsBack title="Subscription" subtitle="Plan, usage and invoices" />
      <View style={{ backgroundColor: C.primary, borderRadius: R.card, padding: 20, gap: 6 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text variant="label" c={C.navyPale}>CURRENT PLAN</Text>
          <Badge label={planPill(data?.subscription?.status)} tone="success" small />
        </View>
        <Text variant="h2" c={C.surface}>{data?.plan?.name ?? 'No plan'}</Text>
        <Text c={C.surface} weight={700}>{data?.plan ? `${inr(data.plan.priceMonthly)} / month` : '—'}</Text>
        <Text variant="caption" c={C.navyPale}>{renewalLabel(data?.subscription ?? null)}</Text>
        <View style={{ marginTop: 8 }}>
          <Button title="Upgrade" variant="secondary" onPress={() => setUpgrade(true)} />
        </View>
      </View>

      <Card>
        <Text variant="label" c={C.secondary}>USAGE</Text>
        <Text variant="h2" style={{ marginTop: 6 }}>{usageLine(used, cap)}</Text>
        <View style={{ marginTop: 12 }}>
          <ProgressBar value={usageRatio(used, cap)} tone={cap != null && used / cap >= 0.8 ? 'warning' : 'teal'} height={10} />
        </View>
        <View style={{ marginTop: 12, backgroundColor: C.warningSoft, borderRadius: R.field, padding: 12 }}>
          <Text variant="caption" c={C.duesInk}>{usageHelper(used, cap)}</Text>
        </View>
      </Card>

      <Card>
        <Text variant="label" c={C.secondary}>PAYMENT METHOD</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10, gap: 12 }}>
          <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="phone-portrait-outline" size={20} color={C.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text weight={700}>UPI · {data?.method.label ?? 'rahul@okaxis'}</Text>
            <Text variant="caption" c={C.secondary}>Autopay {data?.method.autopay ? 'on' : 'off'}</Text>
          </View>
          <Pressable onPress={() => void actions.setAutopay(!data?.method.autopay)} style={{ paddingHorizontal: 12, paddingVertical: 8, borderRadius: R.chip, backgroundColor: C.track }}>
            <Text variant="caption" weight={700}>{data?.method.autopay ? 'Turn off' : 'Turn on'}</Text>
          </Pressable>
        </View>
      </Card>

      <Text variant="title" weight={800}>Invoices</Text>
      <Card pad={6}>
        {(data?.invoices ?? []).map((invoice, index, list) => (
          <View key={invoice.id} style={{ minHeight: 60, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: index < list.length - 1 ? 1 : 0, borderBottomColor: C.hairline }}>
            <View style={{ flex: 1 }}>
              <Text weight={700}>{invoice.number}</Text>
              <Text variant="caption" c={C.secondary}>{invoice.issuedOn} · {invoice.status}</Text>
            </View>
            <Text weight={700} tabular>{inr(invoice.amount)}</Text>
            <Pressable
              accessibilityLabel={`Download ${invoice.number}`}
              onPress={() => void Share.share({ message: `${invoice.number} · ${inr(invoice.amount)} · paid ${invoice.issuedOn}` })}
              style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}
            >
              <Ionicons name="download-outline" size={20} color={C.primary} />
            </Pressable>
          </View>
        ))}
      </Card>

      <Button title="Cancel plan" variant="danger" onPress={() => setCancel(true)} />
      <Text variant="caption" c={C.secondary}>
        Cancelling does not delete students, attendance or fees. Non-essential features pause after the period ends.
      </Text>

      <Sheet visible={upgrade} onClose={() => setUpgrade(false)} title="Upgrade">
        {plans.map((plan) => (
          <View key={plan.id} style={{ paddingVertical: 10, gap: 4, borderBottomWidth: 1, borderBottomColor: C.hairline }}>
            <Text weight={800}>{plan.name}</Text>
            <Text variant="caption" c={C.secondary}>
              {plan.maxStudents == null ? 'Unlimited students' : `Up to ${plan.maxStudents} students`} · {inr(plan.priceMonthly)} / month
            </Text>
            <Button title={`Upgrade to ${plan.name}`} size="sm" onPress={() => { void actions.changePlan(plan.id); setUpgrade(false); }} />
          </View>
        ))}
        {plans.length === 0 ? <Text variant="caption" c={C.secondary}>You are already on the largest plan.</Text> : null}
      </Sheet>
      <ConfirmDialog
        visible={cancel}
        title="Cancel plan?"
        description="Your students, attendance and fees stay. Invites and notices pause once the period ends."
        confirmLabel="Cancel plan"
        cancelLabel="Keep plan"
        onCancel={() => setCancel(false)}
        onConfirm={() => { setCancel(false); void actions.cancelPlan(); }}
      />
    </SettingsScroll>
  );
}
