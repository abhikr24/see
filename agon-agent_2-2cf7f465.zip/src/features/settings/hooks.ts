import { useCallback } from 'react';
import { Share } from 'react-native';

import { toast, useBackend } from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import type { ExportFormat, ExportKind, Role } from '@/core/contracts/models';
import { queryCache, queryKey, queryScope } from '@/core/hooks/cache';
import { useQuery } from '@/core/hooks/useQuery';
import { codeFromJoinUrl, tokenFromJoinUrl } from '@/lib/join-link';

async function copyText(value: string): Promise<void> {
  const nav = globalThis.navigator as { clipboard?: { writeText: (text: string) => Promise<void> } } | undefined;
  if (nav?.clipboard?.writeText) {
    await nav.clipboard.writeText(value);
    return;
  }
  await Share.share({ message: value });
}

export function useSettingsBundle() {
  const { backend, instituteId } = useBackend();
  const key = instituteId ? queryKey(backend.name, 'settings-home', instituteId, 'bundle') : null;
  return useQuery(key, async () => {
    const id = instituteId as string;
    const [institute, subscription, plans, access, overview, backup, method, invoices] = await Promise.all([
      backend.institutes.get(id),
      backend.subscriptions.latest(id),
      backend.subscriptions.listPlans(id),
      backend.subscriptions.access(id),
      backend.analytics.overview(id),
      backend.exports.status(id),
      backend.subscriptions.billingMethod(id),
      backend.subscriptions.listInvoices(id),
    ]);
    const plan = plans.find((item) => item.id === subscription?.planId) ?? null;
    return { institute, subscription, plans, plan, access, used: overview.activeStudents, backup, method, invoices };
  });
}

export function useStaffDesk() {
  const { backend, instituteId } = useBackend();
  const key = instituteId ? queryKey(backend.name, 'settings-staff', instituteId, 'desk') : null;
  return useQuery(key, async () => {
    const id = instituteId as string;
    const today = new Date().toISOString().slice(0, 10);
    const [members, pending, leavePage] = await Promise.all([
      backend.memberships.list(id, { limit: 80 }),
      backend.leaveRequests.listPending(id).catch(() => []),
      backend.leaveRequests.list(id, { limit: 80 }).catch(() => ({ items: [], nextCursor: null, total: 0 })),
    ]);
    const staff = members.items.filter((item) => item.role === 'owner' || item.role === 'admin' || item.role === 'teacher');
    const profiles = await Promise.all(
      staff.map(async (item) => {
        try {
          return await backend.auth.getProfile(id, item.userId);
        } catch {
          return null;
        }
      }),
    );
    const byUser = new Map(staff.map((item, index) => [item.userId, profiles[index]]));
    const onLeave = new Set(
      leavePage.items
        .filter((item) => item.status === 'approved' && item.fromDate <= today && item.toDate >= today)
        .map((item) => item.userId),
    );
    return {
      members: staff.map((item) => ({
        id: item.id,
        userId: item.userId,
        role: item.role,
        status: item.status,
        name: byUser.get(item.userId)?.fullName ?? 'Staff member',
        phone: byUser.get(item.userId)?.phone ?? null,
      })),
      pending: pending.map((item) => ({
        ...item,
        name: byUser.get(item.userId)?.fullName ?? 'Teacher',
      })),
      present: staff.filter((item) => item.status === 'active' && !onLeave.has(item.userId)).length,
      onLeave: staff.filter((item) => onLeave.has(item.userId)).length,
    };
  });
}

export function useSettingsActions() {
  const { backend, instituteId } = useBackend();
  const refresh = useCallback(async (domains: string[]) => {
    if (!instituteId) return;
    await queryCache.invalidate(domains.map((domain) => queryScope(backend.name, domain, instituteId)));
  }, [backend.name, instituteId]);

  const run = useCallback(async <T,>(work: () => Promise<T>, ok: string, domains: string[]): Promise<T | null> => {
    try {
      const result = await work();
      await refresh(domains);
      if (ok) toast.success(ok);
      return result;
    } catch (cause) {
      toast.error(toBackendError(cause).message === 'subscription_restricted'
        ? 'Plan ended. Your data is safe — renew to use this.'
        : toBackendError(cause).message);
      return null;
    }
  }, [refresh]);

  return {
    invite: async (role: Exclude<Role, 'owner'>, fullName: string) => {
      if (!instituteId) return null;
      const link = await run(
        () => backend.invitations.createLink(instituteId, { role, fullName: fullName.trim() || null }),
        '',
        ['settings-staff', 'invitations'],
      );
      if (!link) return null;
      try { await copyText(link.joinUrl); } catch { /* shown on screen */ }
      toast.success('Join link copied');
      return link;
    },
    setRole: (id: string, role: Role) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.memberships.setRole(instituteId, id, role), 'Role updated', ['settings-staff', 'memberships']);
    },
    decideLeave: (id: string, status: 'approved' | 'rejected') => {
      if (!instituteId) return Promise.resolve(null);
      return run(
        () => backend.leaveRequests.decide(instituteId, id, status),
        status === 'approved' ? 'Leave approved' : 'Leave rejected',
        ['settings-staff', 'leaveRequests'],
      );
    },
    saveInstitute: (patch: { name?: string; city?: string; phone?: string | null }) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.institutes.update(instituteId, patch), 'Institute updated', ['settings-home', 'institute']);
    },
    saveSettings: (patch: Parameters<typeof backend.institutes.updateSettings>[1]) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.institutes.updateSettings(instituteId, patch), 'Settings saved', ['settings-home', 'institute']);
    },
    changePlan: (planId: string) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.subscriptions.changePlan(instituteId, planId, 'monthly'), 'Plan updated', ['settings-home', 'subscription']);
    },
    cancelPlan: () => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.subscriptions.cancel(instituteId), 'Plan cancelled. Your data is still here.', ['settings-home', 'subscription']);
    },
    setAutopay: (on: boolean) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.subscriptions.setAutopay(instituteId, on), on ? 'Autopay on' : 'Autopay off', ['settings-home', 'subscription']);
    },
    exportFile: async (kind: ExportKind, format: ExportFormat) => {
      if (!instituteId) return null;
      const job = await run(() => backend.exports.start(instituteId, { kind, format }), 'Export ready', ['settings-home', 'exports']);
      if (!job) return null;
      const body = await backend.exports.content(instituteId, job.id);
      return { job, body };
    },
    importJson: (payload: string) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.exports.importJson(instituteId, payload), 'Backup restored', ['settings-home', 'students', 'exports']);
    },
    backupNow: () => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.exports.recordBackup(instituteId), 'Backup recorded', ['settings-home', 'exports']);
    },
    clearAll: (confirmation: string) => {
      if (!instituteId) return Promise.resolve(null);
      return run(() => backend.exports.clearAll(instituteId, confirmation), 'Operational data cleared. The plan is unchanged.', ['settings-home', 'students']);
    },
    redeem: async (urlOrToken: string) => {
      const token = tokenFromJoinUrl(urlOrToken) ?? urlOrToken;
      const code = codeFromJoinUrl(urlOrToken);
      let id = instituteId;
      if (code) {
        const found = await backend.institutes.findByCode(null, code);
        if (found) id = found.id;
      }
      if (!id) throw toBackendError(new Error('Choose an institute first'));
      return backend.invitations.accept(id, token);
    },
  };
}
