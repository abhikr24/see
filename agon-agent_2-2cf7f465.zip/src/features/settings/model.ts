import type { Role, Subscription } from '@/core/contracts/models';
import { dateShort } from '@/lib/format';

export const CLEAR_PHRASE = 'CLEAR';
export const SUPPORT_PHONE = '+919800011100';
export const SUPPORT_WHATSAPP = 'https://wa.me/919800011100?text=Hi%20GuruFlow%20support';
export const SUPPORT_VIDEOS = 'https://www.youtube.com/results?search_query=coaching+institute+app+tutorial';

export const SESSIONS = ['2024-25', '2025-26', '2026-27', '2027-28'] as const;
export const STAFF_ROLES: Role[] = ['owner', 'admin', 'teacher'];
export const ASSIGNABLE_ROLES: Exclude<Role, 'owner'>[] = ['admin', 'teacher', 'student', 'parent'];

/** Design copy when the numbers are 240 and 300: "240 of 300 students used". */
export function usageLine(used: number, cap: number | null): string {
  if (cap == null) return `${used} students used`;
  return `${used} of ${cap} students used`;
}

export function usageRatio(used: number, cap: number | null): number {
  if (cap == null || cap <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((used / cap) * 100)));
}

export function usageHelper(used: number, cap: number | null): string {
  if (cap == null) return 'This plan does not cap admissions. A lapsed plan never deletes your records.';
  if (used >= cap) return 'The next admission is blocked. Upgrade before you add another student.';
  if (used / cap >= 0.8) return 'You are close to the cap. Upgrade before the next admission is blocked.';
  return 'Admissions stay open until the cap. If the plan ends, your data stays.';
}

export function planPill(status: string | null | undefined): string {
  if (status === 'active' || status === 'trialing') return 'Active';
  if (status === 'past_due') return 'Past due';
  if (status === 'cancelled') return 'Cancelled';
  if (status === 'expired') return 'Expired';
  return 'None';
}

export function renewalLabel(sub: Subscription | null): string {
  if (!sub) return 'No renewal date';
  const when = sub.status === 'trialing' ? sub.trialEndsAt ?? sub.currentPeriodEnd : sub.currentPeriodEnd;
  if (!when) return 'Renews at the end of the period';
  return `Renews ${dateShort(when)}`;
}

export function roleLabel(role: string): string {
  return role.charAt(0).toUpperCase() + role.slice(1);
}

export function leaveDays(fromDate: string, toDate: string): number {
  const start = new Date(`${fromDate}T00:00:00Z`).getTime();
  const end = new Date(`${toDate}T00:00:00Z`).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end)) return 1;
  return Math.max(1, Math.round((end - start) / 86400000) + 1);
}

export function backupStamp(iso: string | null): string {
  if (!iso) return 'No backup yet';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return 'No backup yet';
  return dt.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' });
}
