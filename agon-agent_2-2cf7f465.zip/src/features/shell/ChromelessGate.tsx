import React from 'react';
import { View } from 'react-native';
import { Redirect, Slot } from 'expo-router';

import { useRouteResolution } from '@/store/session';
import { ShellLoading } from './ShellLoading';
import { OfflineBanner } from '@/components/ui/OfflineBanner';
import { C } from '@/lib/theme';

/**
 * Same guard as the role shell, without the header or the tab bar — for
 * full-screen tasks such as Take Attendance, where speed is the design.
 */
export function ChromelessGate({ group }: { group: string }) {
  const r = useRouteResolution();
  if (r.status === 'loading' || r.destination.length === 0) return <ShellLoading />;
  if (r.status !== 'ready' || r.group !== group) return <Redirect href={r.destination as never} />;
  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <OfflineBanner />
      <View style={{ flex: 1 }}>
        <Slot />
      </View>
    </View>
  );
}
