/** Join links the staff screen copies. `accept` redeems `token`. */

export function buildJoinUrl(code: string, token: string): string {
  const params = new URLSearchParams({ code, token });
  return `guruflow://join?${params.toString()}`;
}

export function tokenFromJoinUrl(url: string): string | null {
  const match = url.match(/[?&]token=([^&]+)/);
  if (!match) return null;
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}

export function codeFromJoinUrl(url: string): string | null {
  const match = url.match(/[?&]code=([^&]+)/);
  if (!match) return null;
  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
}
