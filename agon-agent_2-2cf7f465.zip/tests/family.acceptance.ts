import assert from 'node:assert/strict';
import { createDb, type Db } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { PARENT_PREVIEW, seedParentPreview } from '../src/backends/memory/seed-parent-preview';
import { analyticsRepo } from '../src/backends/memory/business';
import { paymentRepo, paymentGateway } from '../src/backends/memory/finance';
import { ensurePendingFeePayment, familyRepo } from '../src/backends/memory/family';
import { meetingRepo } from '../src/backends/memory/communication';
import { ONLINE_PAYMENT_OFF, inclusiveDays, leaveStatusView, meetingStatusView, validateLeaveInput } from '../src/core/contracts/family';

// P28 · Parent fees, receipts, leave and meetings. Runs against the reference backend.
const inst = PARENT_PREVIEW.instituteId;
const db: Db = createDb();
seed(db);
seedParentPreview(db);
const family = familyRepo(db);
const payments = paymentRepo(db);
const gateway = paymentGateway(db);
const meetings = meetingRepo(db);
const analytics = analyticsRepo(db);
const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const aaravId = PARENT_PREVIEW.aaravId;
const siyaId = PARENT_PREVIEW.siyaId;
const ownerUser = SEED.ownerId;
const teacherUser = SEED.teacherId;
const today = new Date().toISOString().slice(0, 10);
const addDays = (iso: string, days: number) => new Date(Date.parse(`${iso}T00:00:00Z`) + days * 86_400_000).toISOString().slice(0, 10);

async function asParent(): Promise<void> { db.session.userId = PARENT_PREVIEW.userId; }
async function asOwner(): Promise<void> { db.session.userId = ownerUser; }

let passed = 0;
async function check(name: string, run: () => Promise<void> | void) {
  await run();
  passed++;
  console.log(`✓ ${name}`);
}

async function main() {
  await asParent();
  const summary = await analytics.childSummary(inst);
  const aarav = summary.children.find((c) => c.id === aaravId)!;
  const siya = summary.children.find((c) => c.id === siyaId)!;
  assert.ok(aarav.nextFee, 'Aarav has an upcoming fee');
  assert.ok(siya.nextFee, 'Siya has an upcoming fee');

  await check('a parent sees payment history and receipts only for their own linked child', async () => {
    // A payment is recorded at the desk by the owner, then the parent reads it back.
    await asOwner();
    const paid = await payments.record(inst, {
      studentId: aaravId, studentFeeId: aarav.nextFee!.studentFeeId, installmentId: aarav.nextFee!.id,
      amount: 1000, method: 'upi', referenceNo: 'UPI-P28-1',
    });
    await asParent();
    const history = await family.paymentHistory(inst, aaravId);
    const mine = history.find((p) => p.id === paid.id);
    assert.ok(mine, 'the parent sees the payment');
    assert.equal(mine.amount, 1000);
    assert.ok(mine.receiptNo, 'the payment has a receipt number');
    assert.equal(mine.installmentId, aarav.nextFee!.id);
    await assert.rejects(() => family.paymentHistory(inst, sid(999)), { code: 'NOT_FOUND' });
    await assert.rejects(() => family.teachers(inst, sid(999)), { code: 'NOT_FOUND' });
    await assert.rejects(() => family.leaveRequests(inst, sid(999)), { code: 'NOT_FOUND' });
    await assert.rejects(() => family.meetings(inst, sid(999)), { code: 'NOT_FOUND' });
  });

  await check('a receipt matches its payment exactly, and a tampered receipt is refused', async () => {
    await asParent();
    const history = await family.paymentHistory(inst, aaravId);
    const payment = history.find((p) => p.referenceNo === 'UPI-P28-1')!;
    const receipt = await family.receipt(inst, payment.receiptId!);
    assert.equal(receipt.amount, payment.amount);
    assert.equal(receipt.receiptNo, payment.receiptNo);
    assert.equal(receipt.paymentId, payment.id);
    assert.equal(receipt.referenceNo, 'UPI-P28-1');
    assert.equal(receipt.method, 'upi');
    assert.equal(receipt.studentName, 'Aarav Sharma');
    // Someone changing the receipt amount after issue must be caught before it is shown.
    const stored = db.receipts.get(inst, payment.receiptId!);
    db.receipts.update(inst, stored.id, { amount: stored.amount + 1 });
    await assert.rejects(() => family.receipt(inst, stored.id), { code: 'CONFLICT' });
    db.receipts.update(inst, stored.id, { amount: stored.amount });
    // A parent cannot open another family's receipt by id.
    await asOwner();
    const otherPayment = await payments.record(inst, {
      studentId: siyaId, studentFeeId: siya.nextFee!.studentFeeId, installmentId: siya.nextFee!.id, amount: 500, method: 'cash',
    });
    await asParent();
    const siyaReceipt = db.receipts.find(inst, { paymentId: otherPayment.id })!;
    assert.equal(siyaReceipt.studentId, siyaId, 'the receipt belongs to the linked sibling');
    const outsider = sid(11015);
    db.session.userId = outsider;
    await assert.rejects(() => family.receipt(inst, siyaReceipt.id), { code: 'NOT_FOUND' });
    await asParent();
  });

  await check('pay now is not a fake payment: it fails clearly and writes nothing', async () => {
    await asParent();
    const before = db.feePayments.all(inst).length;
    const payments0 = db.payments.all(inst, { studentId: aaravId }).length;
    await assert.rejects(
      () => gateway.createIntent(inst, { studentId: aaravId, installmentId: aarav.nextFee!.id }),
      (error: { code?: string; message?: string }) => error.code === 'NOT_IMPLEMENTED' && error.message === ONLINE_PAYMENT_OFF,
    );
    assert.equal(db.feePayments.all(inst).length, before, 'no pending payment row is created');
    assert.equal(db.payments.all(inst, { studentId: aaravId }).length, payments0, 'no payment is recorded');
  });

  await check('a parent cannot start a payment for another child, or pay someone else’s installment', async () => {
    await asParent();
    await assert.rejects(() => gateway.createIntent(inst, { studentId: sid(999), installmentId: aarav.nextFee!.id }), { code: 'NOT_FOUND' });
    await assert.rejects(() => gateway.createIntent(inst, { studentId: aaravId, installmentId: siya.nextFee!.id }), { code: 'NOT_FOUND' });
    await assert.rejects(() => gateway.createIntent(inst, { studentId: siyaId, installmentId: aarav.nextFee!.id }), { code: 'NOT_FOUND' });
  });

  await check('retrying a failed payment never leaves two pending rows for one installment', async () => {
    const installmentId = aarav.nextFee!.id;
    const input = { studentId: aaravId, installmentId, amount: 500, provider: 'razorpay', providerOrderId: 'order_1' };
    const first = ensurePendingFeePayment(db, inst, input);
    const again = ensurePendingFeePayment(db, inst, input);
    assert.equal(again.id, first.id, 'a repeat tap returns the same pending attempt');
    assert.equal(db.feePayments.all(inst, { installmentId, status: 'pending' }).length, 1);
    db.feePayments.update(inst, first.id, { status: 'failed', failureReason: 'card declined' });
    const retry = ensurePendingFeePayment(db, inst, { ...input, providerOrderId: 'order_2' });
    assert.notEqual(retry.id, first.id, 'after a failure a new attempt is allowed');
    assert.equal(db.feePayments.all(inst, { installmentId, status: 'pending' }).length, 1, 'still exactly one pending row');
    ensurePendingFeePayment(db, inst, { ...input, providerOrderId: 'order_3' });
    assert.equal(db.feePayments.all(inst, { installmentId, status: 'pending' }).length, 1);
    db.feePayments.update(inst, retry.id, { status: 'failed' });
  });

  await check('leave: the day count is inclusive and a backwards or too-long range is refused', async () => {
    assert.equal(inclusiveDays('2026-11-16', '2026-11-16'), 1);
    assert.equal(inclusiveDays('2026-11-16', '2026-11-18'), 3);
    assert.throws(() => inclusiveDays('2026-11-18', '2026-11-16'), { code: 'VALIDATION' });
    assert.throws(() => validateLeaveInput({ leaveType: 'sick', fromDate: today, toDate: addDays(today, 90), reason: 'Fever' }, today), { code: 'VALIDATION' });
    assert.throws(() => validateLeaveInput({ leaveType: 'sick', fromDate: addDays(today, -30), toDate: today, reason: 'Fever' }, today), { code: 'VALIDATION' });
    assert.throws(() => validateLeaveInput({ leaveType: 'sick', fromDate: today, toDate: today, reason: 'a' }, today), { code: 'VALIDATION' });
    assert.equal(validateLeaveInput({ leaveType: 'sick', fromDate: today, toDate: today, reason: '  Fever  ' }, today), 'Fever');
  });

  await check('leave: the classes it covers are computed from the child’s own timetable', async () => {
    await asParent();
    const preview = await family.previewLeave(inst, aaravId, today, addDays(today, 6));
    assert.equal(preview.days, 7);
    assert.ok(preview.classCount > 0, 'a full week covers at least one class');
    assert.equal(preview.classCount, preview.classes.reduce((sum, c) => sum + c.sessions, 0));
    assert.ok(preview.classes.every((c) => c.batchId === SEED.batchId), 'only Aarav’s batch');
  });

  await check('leave: a submitted request reaches the teacher’s and the owner’s queues and their notifications', async () => {
    await asParent();
    const request = await family.submitLeave(inst, { studentId: aaravId, leaveType: 'sick', fromDate: today, toDate: addDays(today, 1), reason: '  Fever and rest  ' });
    assert.equal(request.status, 'pending');
    assert.equal(request.days, 2);
    assert.equal(request.reason, 'Fever and rest');
    assert.ok(request.affectedClassCount >= 0);
    assert.equal(leaveStatusView(request.status).label, 'Waiting for approval');
    const notified = db.notifications.all(inst).filter((n) => n.type === 'student_leave_requested');
    assert.ok(notified.some((n) => n.userId === ownerUser), 'the owner is notified');
    assert.ok(notified.some((n) => n.userId === teacherUser), 'Aarav’s class teacher is notified');
    await asOwner();
    assert.ok((await family.leaveQueue(inst)).some((r) => r.id === request.id), 'owner queue has it');
    db.session.userId = teacherUser;
    assert.ok((await family.leaveQueue(inst)).some((r) => r.id === request.id), 'teacher queue has it');
    db.session.userId = sid(14);
    await assert.rejects(() => family.leaveQueue(inst), { code: 'FORBIDDEN' });
    await asParent();
    assert.ok((await family.leaveRequests(inst, aaravId)).some((r) => r.id === request.id), 'the parent sees the status');
    await assert.rejects(() => family.submitLeave(inst, { studentId: sid(999), leaveType: 'sick', fromDate: today, toDate: today, reason: 'Fever' }), { code: 'NOT_FOUND' });
  });

  await check('meetings: a parent can only ask a teacher who takes their child, and sees the teacher’s reply', async () => {
    await asParent();
    const teachers = await family.teachers(inst, aaravId);
    assert.ok(teachers.some((t) => t.id === teacherUser), 'Rohit is listed for Aarav');
    const stranger = db.teachers.all(inst).find((t) => !db.timetables.all(inst).some((p) => p.teacherId === t.id && p.batchId === SEED.batchId));
    if (stranger) await assert.rejects(() => family.requestMeeting(inst, { studentId: aaravId, teacherId: stranger.id, preferredDate: addDays(today, 3), note: 'Hello' }), { code: 'FORBIDDEN' });
    await assert.rejects(() => family.requestMeeting(inst, { studentId: aaravId, teacherId: teacherUser, preferredDate: addDays(today, -2), note: 'Hello' }), { code: 'VALIDATION' });
    const requested = await family.requestMeeting(inst, { studentId: aaravId, teacherId: teacherUser, preferredDate: addDays(today, 3), note: '  Progress in maths?  ' });
    assert.equal(requested.status, 'pending');
    assert.equal(requested.reason, 'Progress in maths?');
    assert.equal(meetingStatusView(requested.status).label, 'Requested');
    // The teacher replies.
    await asOwner();
    db.session.userId = teacherUser;
    await meetings.respond(inst, requested.id, { status: 'declined', note: 'Free only on Friday' });
    await asParent();
    const listed = (await family.meetings(inst, aaravId)).find((m) => m.id === requested.id)!;
    assert.equal(listed.status, 'declined');
    assert.equal(listed.responseNote, 'Free only on Friday');
    assert.equal(meetingStatusView(listed.status).label, 'Declined', 'a declined meeting is never shown as confirmed');
    await assert.rejects(() => family.meetings(inst, sid(999)), { code: 'NOT_FOUND' });
  });

  console.log(`\n${passed} family checks passed`);
}

main().catch((error) => {
  console.error('FAILED', error);
  process.exit(1);
});
