import assert from 'node:assert/strict';

import { noticeRepo, notificationRepo, realtimePort } from '../src/backends/memory/communication';
import { createDb, type Db } from '../src/backends/memory/db';
import { capture, restore } from '../src/backends/memory/persist';
import { seed, SEED } from '../src/backends/memory/seed';
import { ensureNotices } from '../src/backends/memory/seed-notices';
import { isBackendError } from '../src/core/contracts/errors';
import type { AppNotification, ID, Notice } from '../src/core/contracts/models';
import {
  NOTICE_BODY_MAX,
  NOTICE_NOTIFICATION_TYPE,
  NOTICE_TITLE_MAX,
  getNoticeValidationErrors,
  noticeAlertsOn,
  noticeNotificationBody,
} from '../src/core/contracts/notices';
import { queryCache, queryKey, queryScope } from '../src/core/hooks/cache';
import { publishNoticeMessage } from '../src/core/hooks/communication';
import {
  audienceSummary, bodyCounter, canComposeNotice, canDeleteNotice, eventChip, filterNotices, noticeRoutes, sortNotices,
} from '../src/features/notices/model';
import { filterInbox, kindOf, noticeIdOf, relativeTime, unreadIn } from '../src/features/notifications/model';
import { badgeLabel } from '../src/lib/format';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => { passed += 1; console.log(`  ✓ ${name}`); });

const rejects = async (promise: Promise<unknown>, code: string) => {
  try { await promise; } catch (error) {
    assert.ok(isBackendError(error), `expected BackendError, got ${String(error)}`);
    assert.equal(error.code, code, error.message);
    return error;
  }
  return assert.fail(`expected ${code}`);
};

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const OWNER = sid(2);
const ROHIT = sid(3); // class teacher of 10-A
const PRIYA = sid(4); // class teacher of 9-A
const AARAV = sid(14); // student, 10-A
const ANITA = sid(37); // Aarav's mother
const PENDING_STUDENT = sid(38);
const CLASS_10A = sid(9);
const CLASS_9A = sid(10);
const TEACHERS = [3, 4, 5, 6, 7].map(sid);
const STUDENTS = Array.from({ length: 12 }, (_, n) => sid(14 + n));
const PARENTS = [ANITA, ...Array.from({ length: 11 }, (_, n) => sid(11015 + n))];

const tick = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

/**
 * One signed-in device. The memory backend keeps a single session, so a second
 * person is modelled as a second view of the same tables and the same change
 * feed with their own session — which is what two phones on one backend are.
 */
function device(db: Db, userId: ID | null) {
  const view: Db = { ...db, session: { userId } };
  return { userId, notices: noticeRepo(view), inbox: notificationRepo(view), realtime: realtimePort(view) };
}

/**
 * The tab badge on a device, wired exactly as `useUnreadNotifications` wires
 * it: a cached `unreadCount` query, reloaded by every `notifications` event
 * that RealtimePort delivers.
 */
async function mountBadge(db: Db, userId: ID, screen = 'tab') {
  const i = SEED.instituteId;
  const me = device(db, userId);
  const backendName = `device-${userId}-${screen}`;
  const key = queryKey(backendName, 'notifications', i, ['unread']);
  const unsubscribe = queryCache.subscribe(key, () => {});
  await queryCache.fetch(key, () => me.inbox.unreadCount(i));
  let lastChangeAt = 0;
  const feed = await me.realtime.subscribe(i, 'notifications', () => {
    void queryCache.invalidate([queryScope(backendName, 'notifications', i)]).then(() => { lastChangeAt = Date.now(); });
  });
  return {
    ...me,
    count: () => queryCache.read(key).data as number,
    label: () => badgeLabel(queryCache.read(key).data as number),
    lastChangeAt: () => lastChangeAt,
    unmount: async () => { unsubscribe(); await feed.unsubscribe(); },
  };
}

const noticeRows = (db: Db, noticeId: ID): AppNotification[] =>
  db.notifications.all(SEED.instituteId).filter((row) => row.data.noticeId === noticeId);

const draft = (overrides: Partial<Parameters<ReturnType<typeof noticeRepo>['broadcast']>[1]> = {}) => ({
  title: 'Parent–teacher meeting on Saturday',
  body: 'Meet your child’s class teacher between 10:00 AM and 12:30 PM. Bring the progress card.',
  audience: ['student', 'parent', 'teacher'] as ('student' | 'parent' | 'teacher')[],
  batchId: null as ID | null,
  ...overrides,
});

async function main() {
  const db = createDb();
  seed(db);
  const i = SEED.instituteId;
  const owner = device(db, OWNER);
  const rohit = device(db, ROHIT);

  console.log('Notices and notification centre acceptance');

  await check('composer rules: title, 500-character body, at least one audience, an event needs its day', () => {
    assert.deepEqual(getNoticeValidationErrors(draft()), {});
    assert.ok(getNoticeValidationErrors(draft({ title: '   ' })).title);
    assert.ok(getNoticeValidationErrors(draft({ title: 'x'.repeat(NOTICE_TITLE_MAX + 1) })).title);
    assert.ok(getNoticeValidationErrors(draft({ body: '' })).body);
    assert.deepEqual(getNoticeValidationErrors(draft({ body: 'x'.repeat(NOTICE_BODY_MAX) })), {});
    assert.ok(getNoticeValidationErrors(draft({ body: 'x'.repeat(NOTICE_BODY_MAX + 1) })).body);
    assert.ok(getNoticeValidationErrors(draft({ audience: [] })).audience);
    assert.ok(getNoticeValidationErrors(draft({ category: 'event' })).eventOn);
    assert.ok(getNoticeValidationErrors(draft({ category: 'event', eventOn: '2026-02-30' })).eventOn);
    assert.deepEqual(getNoticeValidationErrors(draft({ category: 'event', eventOn: '2026-12-05' })), {});
    assert.deepEqual(bodyCounter(0, 500), { label: '0/500', tone: 'muted' });
    assert.deepEqual(bodyCounter(450, 500), { label: '450/500', tone: 'warning' });
    assert.deepEqual(bodyCounter(500, 500), { label: '500/500', tone: 'danger' });
    assert.equal(noticeNotificationBody('a'.repeat(300)).length, 140);
    assert.equal(noticeAlertsOn(undefined), true);
    assert.equal(noticeAlertsOn({ noticeAlerts: false }), false);
  });

  await check('publishing creates the notice and exactly one notification per recipient — never the sender, never a pending member', async () => {
    const result = await owner.notices.broadcast(i, draft());
    assert.equal(result.notices.length, 1);
    const notice = result.notices[0];
    assert.ok(notice.publishedAt);
    assert.equal(notice.createdBy, OWNER);
    assert.deepEqual(notice.audience, ['student', 'parent', 'teacher']);
    assert.deepEqual(result.notified, { student: 12, parent: 12, teacher: 5 });
    assert.equal(result.totalNotified, 29);
    assert.equal(result.alertsDisabled, false);
    assert.equal(publishNoticeMessage(result), 'Notice published · 29 people notified');

    const rows = noticeRows(db, notice.id);
    assert.equal(rows.length, 29);
    assert.deepEqual([...new Set(rows.map((row) => row.userId))].sort(), [...STUDENTS, ...PARENTS, ...TEACHERS].sort());
    assert.ok(rows.every((row) => row.type === NOTICE_NOTIFICATION_TYPE && row.channel === 'in_app' && row.readAt === null));
    assert.ok(!rows.some((row) => row.userId === OWNER || row.userId === PENDING_STUDENT));
  });

  await check('publishing a notice moves every recipient’s badge within a second, through RealtimePort', async () => {
    queryCache.clear();
    const recipients = await Promise.all([...STUDENTS, ...PARENTS, ...TEACHERS].map((userId) => mountBadge(db, userId)));
    const bystanders = await Promise.all([OWNER, PENDING_STUDENT].map((userId) => mountBadge(db, userId)));
    const before = recipients.map((badge) => badge.count());
    const bystandersBefore = bystanders.map((badge) => badge.count());

    const startedAt = Date.now();
    await owner.notices.broadcast(i, draft({ title: 'Diwali break dates' }));
    await tick();
    await tick();

    recipients.forEach((badge, n) => {
      assert.equal(badge.count(), before[n] + 1, `badge of ${badge.userId}`);
      const elapsed = badge.lastChangeAt() - startedAt;
      assert.ok(elapsed >= 0 && elapsed < 1000, `badge of ${badge.userId} moved after ${elapsed} ms`);
    });
    bystanders.forEach((badge, n) => assert.equal(badge.count(), bystandersBefore[n]));
    await Promise.all([...recipients, ...bystanders].map((badge) => badge.unmount()));
  });

  await check('the badge caps at “9+” and is empty at zero', () => {
    assert.deepEqual([0, 1, 9, 10, 57, 250].map((n) => badgeLabel(n)), ['', '1', '9', '9+', '9+', '9+']);
    assert.equal(badgeLabel(null), '');
    assert.equal(badgeLabel(-3), '');
  });

  await check('“Students only” never notifies a parent, and no parent can read it', async () => {
    const parentCounts = await Promise.all(PARENTS.map((userId) => device(db, userId).inbox.unreadCount(i)));
    const result = await owner.notices.broadcast(i, draft({ title: 'Bring your ID cards', audience: ['student'] }));
    const notice = result.notices[0];
    assert.deepEqual(result.notified, { student: 12, parent: 0, teacher: 0 });

    const rows = noticeRows(db, notice.id);
    assert.deepEqual(rows.map((row) => row.userId).sort(), [...STUDENTS].sort());
    assert.ok(!rows.some((row) => PARENTS.includes(row.userId) || TEACHERS.includes(row.userId)));
    assert.deepEqual(await Promise.all(PARENTS.map((userId) => device(db, userId).inbox.unreadCount(i))), parentCounts);

    const aarav = device(db, AARAV);
    const anita = device(db, ANITA);
    assert.ok((await aarav.notices.list(i, { limit: 200 })).items.some((row) => row.id === notice.id));
    assert.ok(!(await anita.notices.list(i, { limit: 200 })).items.some((row) => row.id === notice.id));
    await rejects(anita.notices.get(i, notice.id), 'NOT_FOUND');
    await rejects(rohit.notices.get(i, notice.id), 'NOT_FOUND');

    // And the mirror image: parents only never reaches a student.
    const parentsOnly = await owner.notices.broadcast(i, draft({ title: 'Fee window', audience: ['parent'], batchId: CLASS_10A }));
    assert.deepEqual(parentsOnly.notified, { student: 0, parent: 12, teacher: 0 });
    assert.ok(noticeRows(db, parentsOnly.notices[0].id).every((row) => PARENTS.includes(row.userId)));
    await rejects(aarav.notices.get(i, parentsOnly.notices[0].id), 'NOT_FOUND');
  });

  await check('marking all read clears the badge everywhere that person is signed in — and nobody else’s', async () => {
    queryCache.clear();
    const tab = await mountBadge(db, AARAV, 'tab');
    const moreRow = await mountBadge(db, AARAV, 'more-row');
    const otherPhone = await mountBadge(db, AARAV, 'second-phone');
    const anita = await mountBadge(db, ANITA);
    assert.ok(tab.count() >= 3);
    assert.equal(tab.count(), moreRow.count());
    const anitaBefore = anita.count();
    assert.ok(anitaBefore > 0);

    const marked = await tab.inbox.markAllRead(i);
    await tick();
    await tick();
    assert.equal(marked > 0, true);
    assert.deepEqual([tab.count(), moreRow.count(), otherPhone.count()], [0, 0, 0]);
    assert.deepEqual([tab.label(), moreRow.label(), otherPhone.label()], ['', '', '']);
    assert.equal(anita.count(), anitaBefore);
    assert.equal(await tab.inbox.markAllRead(i), 0);

    // One tap on a single card moves the other screens too.
    const one = (await anita.inbox.list(i, { limit: 200 })).items.find((row) => row.readAt === null) as AppNotification;
    await anita.inbox.markRead(i, one.id);
    await tick();
    await tick();
    assert.equal(anita.count(), anitaBefore - 1);
    await Promise.all([tab, moreRow, otherPhone, anita].map((badge) => badge.unmount()));
  });

  await check('the institute’s notice-alert setting is honoured: off lists the notice and notifies nobody', async () => {
    const institute = db.institutes.get(i, i);
    db.institutes.put({ ...institute, settings: { ...institute.settings, features: { ...institute.settings.features, noticeAlerts: false } } });
    const total = db.notifications.all(i).length;
    const result = await owner.notices.broadcast(i, draft({ title: 'Quiet notice' }));
    assert.equal(result.alertsDisabled, true);
    assert.equal(result.totalNotified, 0);
    assert.equal(db.notifications.all(i).length, total);
    assert.equal(publishNoticeMessage(result), 'Notice published · alerts are off, so nobody was notified');
    assert.ok((await device(db, AARAV).notices.list(i, { limit: 200 })).items.some((row) => row.id === result.notices[0].id));
    db.institutes.put(institute);
  });

  await check('a teacher publishes only to their own batches; students and parents cannot publish at all', async () => {
    const all = await rohit.notices.broadcast(i, draft({ title: 'Revision class', audience: ['student', 'parent'] }));
    assert.deepEqual(all.notices.map((row) => row.batchId), [CLASS_10A]);
    assert.deepEqual(all.notified, { student: 12, parent: 12, teacher: 0 });
    assert.ok(!noticeRows(db, all.notices[0].id).some((row) => row.userId === ROHIT));

    await rejects(rohit.notices.broadcast(i, draft({ batchId: CLASS_9A })), 'NOT_FOUND');
    await rejects(device(db, AARAV).notices.broadcast(i, draft()), 'FORBIDDEN');
    await rejects(device(db, ANITA).notices.broadcast(i, draft()), 'FORBIDDEN');
    await rejects(device(db, PENDING_STUDENT).notices.broadcast(i, draft()), 'FORBIDDEN');
    await rejects(device(db, null).notices.broadcast(i, draft()), 'UNAUTHENTICATED');
    await rejects(owner.notices.broadcast(i, draft({ audience: [] })), 'VALIDATION');
    await rejects(owner.notices.broadcast(i, draft({ body: 'x'.repeat(501) })), 'VALIDATION');
    await rejects(owner.notices.broadcast(i, draft({ batchId: sid(999999) })), 'NOT_FOUND');

    // 9-A has no student or parent logins: the notice is stored, and the count says so honestly.
    const nineA = await owner.notices.broadcast(i, draft({ title: '9-A lab coats', audience: ['student', 'parent'], batchId: CLASS_9A }));
    assert.equal(nineA.totalNotified, 0);
    assert.equal(publishNoticeMessage(nineA), 'Notice published · nobody in that audience has a login yet');
    // A batch-bound notice to Teachers reaches the teacher that batch is assigned to.
    const toClassTeacher = await owner.notices.broadcast(i, draft({ title: '9-A lab duty', audience: ['teacher'], batchId: CLASS_9A }));
    assert.deepEqual(noticeRows(db, toClassTeacher.notices[0].id).map((row) => row.userId), [PRIYA]);
  });

  await check('the list is scoped by role and batch; drafts and expired notices stay with staff', async () => {
    const staffOnly = (await owner.notices.broadcast(i, draft({ title: 'Staff meeting', audience: ['teacher'] }))).notices[0];
    const tenA = (await owner.notices.broadcast(i, draft({ title: '10-A picnic', audience: ['student', 'parent'], batchId: CLASS_10A }))).notices[0];
    const nineA = (await owner.notices.broadcast(i, draft({ title: '9-A picnic', audience: ['student', 'parent', 'teacher'], batchId: CLASS_9A }))).notices[0];
    const draftNotice = await owner.notices.create(i, { title: 'Not ready yet' });
    const expired = await owner.notices.create(i, { title: 'Old news', publishedAt: '2026-01-01T00:00:00.000Z', expiresAt: '2026-01-02T00:00:00.000Z' });

    const ids = async (userId: ID | null) => new Set((await device(db, userId).notices.list(i, { limit: 200 })).items.map((row) => row.id));
    const seenBy = { owner: await ids(OWNER), rohit: await ids(ROHIT), priya: await ids(PRIYA), aarav: await ids(AARAV), anita: await ids(ANITA) };

    for (const notice of [staffOnly, tenA, nineA, draftNotice, expired]) assert.ok(seenBy.owner.has(notice.id));
    assert.ok(seenBy.rohit.has(staffOnly.id) && seenBy.priya.has(staffOnly.id));
    assert.ok(!seenBy.aarav.has(staffOnly.id) && !seenBy.anita.has(staffOnly.id));
    assert.ok(seenBy.aarav.has(tenA.id) && seenBy.anita.has(tenA.id));
    assert.ok(!seenBy.aarav.has(nineA.id) && !seenBy.anita.has(nineA.id));
    assert.ok(seenBy.priya.has(nineA.id) && !seenBy.rohit.has(nineA.id));
    for (const reader of [seenBy.rohit, seenBy.aarav, seenBy.anita]) {
      assert.ok(!reader.has(draftNotice.id) && !reader.has(expired.id));
    }
    assert.equal((await device(db, null).notices.list(i)).items.length, 0);
    assert.equal((await device(db, PENDING_STUDENT).notices.list(i)).items.length, 0);
    await rejects(device(db, AARAV).notices.get(i, staffOnly.id), 'NOT_FOUND');
  });

  await check('swipe-to-dismiss removes only your own notification; delete is the owner’s and takes the inbox rows with it', async () => {
    const aarav = device(db, AARAV);
    const anita = device(db, ANITA);
    const notice = (await owner.notices.broadcast(i, draft({ title: 'Sports day' }))).notices[0];
    const mine = noticeRows(db, notice.id).find((row) => row.userId === AARAV) as AppNotification;
    const hers = noticeRows(db, notice.id).find((row) => row.userId === ANITA) as AppNotification;

    const events: string[] = [];
    const feed = await aarav.realtime.subscribe(i, 'notifications', (event) => events.push(`${event.change}:${event.id}`));
    const unreadBefore = await aarav.inbox.unreadCount(i);
    await rejects(aarav.inbox.dismiss(i, hers.id), 'NOT_FOUND');
    await aarav.inbox.dismiss(i, mine.id);
    assert.equal(await aarav.inbox.unreadCount(i), unreadBefore - 1);
    assert.ok(events.includes(`removed:${mine.id}`));
    assert.ok(!(await aarav.inbox.list(i, { limit: 200 })).items.some((row) => row.id === mine.id));
    assert.ok((await anita.inbox.list(i, { limit: 200 })).items.some((row) => row.id === hers.id));
    await rejects(aarav.inbox.dismiss(i, mine.id), 'NOT_FOUND');

    await rejects(aarav.notices.remove(i, notice.id), 'FORBIDDEN');
    await rejects(rohit.notices.remove(i, notice.id), 'FORBIDDEN');
    assert.equal(noticeRows(db, notice.id).length, 28);
    await owner.notices.remove(i, notice.id);
    assert.equal(noticeRows(db, notice.id).length, 0);
    await rejects(owner.notices.get(i, notice.id), 'NOT_FOUND');
    assert.equal(canDeleteNotice('owner') && canDeleteNotice('admin'), true);
    assert.equal(canDeleteNotice('teacher') || canDeleteNotice('student') || canDeleteNotice('parent'), false);
    await feed.unsubscribe();
  });

  await check('list and inbox view rules: segments, event chip, kinds, relative time, routes', () => {
    const base = { id: 'n', instituteId: i, batchId: null, body: '', audience: ['student'], isPinned: false, expiresAt: null, eventOn: null, createdBy: null, updatedAt: '' } as const;
    const notices: Notice[] = [
      { ...base, id: 'a', title: 'A', category: 'general', publishedAt: '2026-11-10T00:00:00.000Z', createdAt: '2026-11-10T00:00:00.000Z', audience: ['student'] },
      { ...base, id: 'b', title: 'B', category: 'exam', publishedAt: '2026-11-12T00:00:00.000Z', createdAt: '2026-11-12T00:00:00.000Z', audience: ['student'] },
      { ...base, id: 'c', title: 'C', category: 'event', eventOn: '2026-11-24', publishedAt: '2026-11-11T00:00:00.000Z', createdAt: '2026-11-11T00:00:00.000Z', audience: ['student'] },
      { ...base, id: 'd', title: 'D', category: 'holiday', publishedAt: '2026-11-09T00:00:00.000Z', createdAt: '2026-11-09T00:00:00.000Z', audience: ['student'] },
      { ...base, id: 'e', title: 'E', category: 'academic', publishedAt: '2026-11-13T00:00:00.000Z', createdAt: '2026-11-13T00:00:00.000Z', audience: ['student'] },
    ];
    assert.deepEqual(sortNotices(notices).map((n) => n.id), ['e', 'b', 'c', 'a', 'd']);
    assert.deepEqual(filterNotices(sortNotices(notices), 'all').length, 5);
    assert.deepEqual(filterNotices(sortNotices(notices), 'academic').map((n) => n.id), ['e', 'b']);
    assert.deepEqual(filterNotices(sortNotices(notices), 'events').map((n) => n.id), ['c', 'd']);
    assert.deepEqual(eventChip(notices[2]), { day: '24', month: 'NOV' });
    assert.equal(eventChip(notices[3]), null); // a holiday without a day gets no chip
    assert.equal(eventChip({ category: 'event', eventOn: null }), null);
    assert.equal(audienceSummary(['parent', 'student'], { allBatches: true }), 'Students · Parents · All batches');
    assert.equal(audienceSummary(['student'], { allBatches: false, batchName: 'Class 10-A' }), 'Students · Class 10-A');

    const types: [string, string][] = [
      ['notice_published', 'announcement'], ['homework_assigned', 'homework'], ['homework_reminder', 'homework'],
      ['homework_ask_again', 'homework'], ['fee_receipts', 'fee'], ['payment_received', 'fee'], ['exam_published', 'exam'],
      ['leave_requested', 'leave'], ['attendance_absent', 'attendance'], ['doubt_answered', 'general'], ['general', 'general'],
    ];
    for (const [type, kind] of types) assert.equal(kindOf({ type, data: {} }), kind, type);
    assert.equal(kindOf({ type: 'general', data: { screen: 'notice' } }), 'announcement');

    const at = (minutes: number) => new Date(Date.UTC(2026, 10, 15, 12, 0) - minutes * 60000).toISOString();
    const now = Date.UTC(2026, 10, 15, 12, 0);
    const row = (id: string, type: string, minutes: number, read: boolean): AppNotification => ({
      id, instituteId: i, userId: AARAV, type, title: id, body: null, data: type === 'notice_published' ? { noticeId: 'x' } : {},
      channel: 'in_app', sentAt: at(minutes), readAt: read ? at(minutes - 1) : null, createdAt: at(minutes), updatedAt: at(minutes),
    });
    const inbox = [row('old', 'exam_published', 3000, true), row('new', 'notice_published', 2, false), row('mid', 'homework_assigned', 90, false)];
    assert.deepEqual(filterInbox(inbox, 'all').map((n) => n.id), ['new', 'mid', 'old']);
    assert.deepEqual(filterInbox(inbox, 'unread').map((n) => n.id), ['new', 'mid']);
    assert.deepEqual(filterInbox(inbox, 'announcements').map((n) => n.id), ['new']);
    assert.deepEqual(filterInbox(inbox, 'all', 'new').map((n) => n.id), ['mid', 'old']); // swiped, waiting on Undo
    assert.equal(unreadIn(inbox), 2);
    assert.equal(unreadIn(inbox, 'new'), 1);
    assert.equal(noticeIdOf(inbox[1]), 'x');
    assert.equal(noticeIdOf(inbox[0]), null);
    assert.deepEqual(
      [0, 2, 59, 90, 23 * 60, 26 * 60, 3 * 24 * 60].map((minutes) => relativeTime(at(minutes), now)),
      ['Just now', '2 min ago', '59 min ago', '1 h ago', '23 h ago', 'Yesterday', '3 days ago'],
    );

    assert.equal(canComposeNotice('owner') && canComposeNotice('admin') && canComposeNotice('teacher'), true);
    assert.equal(canComposeNotice('student') || canComposeNotice('parent') || canComposeNotice(null), false);
    assert.equal(noticeRoutes('teacher').compose, '/(teacher)/notices/new');
    assert.equal(noticeRoutes('admin').compose, '/(owner)/notices/new');
    assert.equal(noticeRoutes('student').compose, null);
    assert.equal(noticeRoutes('parent').list, '/(parent)/notices');
  });

  await check('seeded demo data follows the same fan-out rule, and an older snapshot is topped up exactly once', async () => {
    const fresh = createDb();
    seed(fresh);
    const fair = fresh.notices.get(i, sid(18001));
    assert.equal(fair.category, 'event');
    assert.ok(fair.eventOn);
    const fairRows = noticeRows(fresh, fair.id);
    assert.equal(fairRows.length, 29);
    assert.ok(!fairRows.some((row) => row.userId === OWNER));
    assert.ok(!noticeRows(fresh, sid(18004)).some((row) => !TEACHERS.includes(row.userId)));
    assert.ok(noticeRows(fresh, sid(18002)).every((row) => row.userId !== ROHIT && row.readAt !== null));

    // A snapshot from before this prompt: no noticeAlerts flag, no eventOn, none of the demo rows.
    const old = JSON.parse(capture(fresh)) as { tables: Record<string, Record<string, unknown>[]> };
    const isDemo = (row: Record<string, unknown>) => /-000000018\d{3}$/.test(String(row.id));
    old.tables.notices = old.tables.notices.filter((row) => !isDemo(row)).map(({ eventOn: _eventOn, ...row }) => row);
    old.tables.notifications = old.tables.notifications.filter((row) => !isDemo(row));
    for (const institute of old.tables.institutes) {
      const settings = institute.settings as { features: Record<string, boolean> };
      delete settings.features.noticeAlerts;
    }
    const restored = createDb();
    assert.equal(restore(restored, JSON.stringify(old)), true);
    assert.equal(restored.notices.all(i, { id: sid(18001) }).length, 0);
    ensureNotices(restored);
    assert.equal(restored.institutes.get(i, i).settings.features.noticeAlerts, true);
    assert.equal(restored.notices.all(i, { id: sid(18001) }).length, 1);
    assert.ok(restored.notices.all(i).every((row) => row.eventOn !== undefined));

    // The owner deletes a demo notice; the next launch must not bring it back.
    await device(restored, OWNER).notices.remove(i, sid(18001));
    const again = createDb();
    assert.equal(restore(again, capture(restored)), true);
    ensureNotices(again);
    assert.equal(again.notices.all(i, { id: sid(18001) }).length, 0);
    assert.equal(noticeRows(again, sid(18001)).length, 0);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
