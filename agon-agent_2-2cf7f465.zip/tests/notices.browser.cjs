const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

// Drives the exported web build (`npm run build` with EXPO_PUBLIC_BACKEND=memory first)
// as owner, student and parent: composer, notices list, notification centre, More-tab badge.
const root = path.join(process.cwd(), 'dist');
const shots = path.join(process.cwd(), '.shots');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png', '.jpg': 'image/jpeg' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8147);

const BASE = 'http://localhost:8147';
const tab = (page, label) => page.getByRole('tab', { name: label }).filter({ visible: true }).first();
const step = (msg) => console.log(`PASS: ${msg}`);
// A screen left underneath in the navigation stack stays in the DOM, hidden; only what is on screen counts.
const shown = (page, text) => page.getByText(text, { exact: true }).filter({ visible: true });
const seen = (page, text, timeout = 15000) => shown(page, text).first().waitFor({ state: 'visible', timeout });
const gone = (page, text, timeout = 15000) => shown(page, text).first().waitFor({ state: 'hidden', timeout });
const visible = async (page, text) => (await shown(page, text).count()) > 0;
async function shot(page, name) {
  fs.mkdirSync(shots, { recursive: true });
  await page.waitForTimeout(350);
  await page.screenshot({ path: path.join(shots, `notices-${name}.png`) });
}

/** Signs in with a demo pill and waits for a tab only that role has. */
async function signIn(page, pill, landingTab) {
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 8000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 30000 });
  await page.getByText(pill, { exact: true }).click();
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await tab(page, landingTab).waitFor({ state: 'visible', timeout: 30000 });
}

async function signOut(page) {
  await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 30000 });
}

/** The More tab's badge text, or '' when there is no badge. */
async function badge(page) {
  const node = page.getByTestId('tab-badge-more').filter({ visible: true });
  return (await node.count()) === 0 ? '' : (await node.first().innerText()).trim();
}
async function badgeBecomes(page, expected, timeout = 4000) {
  const started = Date.now();
  for (;;) {
    const now = await badge(page);
    if (now === expected) return Date.now() - started;
    if (Date.now() - started > timeout) assert.fail(`More badge is "${now}", expected "${expected}"`);
    await page.waitForTimeout(50);
  }
}

async function publish(page, { title, body }) {
  await page.getByTestId('notice-compose').click();
  await seen(page, 'New notice');
  await page.getByTestId('notice-title').fill(title);
  await page.getByTestId('notice-body').fill(body);
}

/** Drags a notification card sideways with the mouse, the way a finger would. */
async function swipe(page, card, distance = 260) {
  const box = await card.boundingBox();
  const y = box.y + box.height / 2;
  const x = box.x + box.width / 2;
  await page.mouse.move(x, y);
  await page.mouse.down();
  for (let moved = 0; moved <= distance; moved += 20) await page.mouse.move(x - moved, y, { steps: 1 });
  await page.mouse.up();
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  try {
    // ---------------- Owner: list, composer, publish ----------------
    await page.goto(`${BASE}/`);
    await signIn(page, 'Owner', 'Students');
    await badgeBecomes(page, '1');
    step('owner lands on the shell with the seeded unread count on the More tab');

    await tab(page, 'More').click();
    await seen(page, 'Notifications');
    await shown(page, 'Notices').first().click();
    await seen(page, 'Everything the institute has announced');
    for (const text of ['Annual Science Fair', 'Extra Mathematics class for 10-A', 'Read more']) await seen(page, text);
    await shot(page, 'list-owner');
    await tab(page, 'Events').click();
    await seen(page, 'Annual Science Fair');
    await seen(page, 'Winter break dates');
    assert.equal(await visible(page, 'Staff meeting on Saturday'), false);
    assert.equal(await page.getByLabel(/^Event on /).count(), 1, 'only the event with a day carries a date chip');
    await tab(page, 'Academic').click();
    await seen(page, 'Revised timetable from Monday');
    await seen(page, 'Unit Test 3 schedule');
    assert.equal(await visible(page, 'Annual Science Fair'), false);
    await tab(page, 'All').click();
    step('notices list segments All / Academic / Events and shows the event date chip');

    await shown(page, 'Annual Science Fair').first().click();
    await page.getByText(/^Event day · /).first().waitFor({ state: 'visible' });
    await page.getByText(/^Sent to Students · Parents · Teachers · All batches$/).first().waitFor({ state: 'visible' });
    await page.getByRole('button', { name: 'Done', exact: true }).click();
    step('Read more opens the whole notice');

    await publish(page, { title: 'Bring your ID cards', body: 'ID cards are checked at the gate from Monday.' });
    await seen(page, '45/500');
    await seen(page, 'Parents also get a WhatsApp summary');
    await seen(page, 'Students · Parents · All batches');
    await shot(page, 'composer');
    await page.getByTestId('toggle-parents').click();
    await gone(page, 'Parents also get a WhatsApp summary');
    await seen(page, 'Students · All batches');
    await page.getByTestId('notice-body').fill('x'.repeat(620));
    await seen(page, '500/500');
    await page.getByTestId('notice-body').fill('ID cards are checked at the gate from Monday.');
    await page.getByTestId('notice-publish').click();
    await seen(page, 'Notice published · 12 people notified');
    await seen(page, 'Everything the institute has announced');
    await seen(page, 'Bring your ID cards');
    assert.equal(await badge(page), '1', 'the sender is never notified of their own notice');
    step('composer: counter, toggles, live preview, amber card; "Students only" publishes to 12 people');

    // Validation, then nine more to students so their badge has to cap.
    await page.getByTestId('notice-compose').click();
    await seen(page, 'New notice');
    await page.getByTestId('notice-publish').click();
    await seen(page, 'Give the notice a title');
    await seen(page, 'Write the notice');
    await page.getByRole('button', { name: 'Back to notices' }).click();
    for (let n = 1; n <= 8; n += 1) {
      await publish(page, { title: `Reminder ${n}`, body: `Reminder number ${n} for every student.` });
      await page.getByTestId('toggle-parents').click();
      await page.getByTestId('notice-publish').click();
      await seen(page, `Reminder ${n}`);
      await seen(page, 'Everything the institute has announced');
    }
    step('an empty composer explains itself; nine student-only notices are out');

    // Long-press delete (owner only).
    const doomed = shown(page, 'Reminder 8').first();
    await doomed.click({ delay: 700 });
    await seen(page, 'Delete this notice?');
    await page.getByRole('button', { name: 'Delete notice', exact: true }).click();
    await gone(page, 'Reminder 8');
    step('owner long-press deletes a notice after confirmation');

    // ---------------- Student: capped badge, centre, swipe + undo, mark all read ----------------
    await signOut(page);
    await signIn(page, 'Student', 'Homework');
    // 1 seeded homework + Science Fair + ID cards + 7 reminders left = 10 unread.
    await badgeBecomes(page, '9+');
    await shot(page, 'badge-capped');
    step('a student with 10 unread sees "9+" on the More tab');

    await tab(page, 'More').click();
    await seen(page, '9+ new');
    await shown(page, 'Notifications').first().click();
    await seen(page, '10 unread · swipe a card to dismiss it');
    await seen(page, 'Reminder 7');
    assert.equal(await visible(page, 'Reminder 8'), false, 'a deleted notice takes its notification with it');
    await shot(page, 'centre-student');
    await tab(page, 'Announcements').click();
    assert.equal(await visible(page, 'Trigonometry practice set due today'), false);
    await tab(page, 'Unread').click();
    await seen(page, 'Trigonometry practice set due today');
    await tab(page, 'All').click();

    // Swipe → undo → it is back, still unread.
    const card = page.locator('[data-testid^="notification-"]').filter({ visible: true }).filter({ hasText: 'Reminder 7' }).first();
    await swipe(page, card);
    await seen(page, 'Notification dismissed');
    await gone(page, 'Reminder 7');
    await seen(page, '9 unread · swipe a card to dismiss it');
    await page.getByTestId('undo-dismiss').click();
    await seen(page, 'Reminder 7');
    await seen(page, '10 unread · swipe a card to dismiss it');
    // Swipe again and let the undo window lapse: gone for good.
    await swipe(page, page.locator('[data-testid^="notification-"]').filter({ visible: true }).filter({ hasText: 'Reminder 7' }).first());
    await gone(page, 'Reminder 7');
    await gone(page, 'Notification dismissed', 9000);
    await seen(page, '9 unread · swipe a card to dismiss it');
    step('swipe dismisses, Undo brings it back, and after the window it is removed');

    // Tapping an announcement marks it read and opens the notice.
    await page.locator('[data-testid^="notification-"]').filter({ visible: true }).filter({ hasText: 'Bring your ID cards' }).first().click();
    // The notice opens in a sheet over the list (the list behind it is inert until Done).
    await page.getByRole('button', { name: 'Done', exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    await page.getByText('ID cards are checked at the gate from Monday.', { exact: true }).last().waitFor({ state: 'visible' });
    await page.getByRole('button', { name: 'Done', exact: true }).click();
    await seen(page, 'Announcements from your institute');
    assert.equal(await page.getByTestId('notice-compose').count(), 0, 'students have no composer');
    assert.equal(await visible(page, 'Staff meeting on Saturday'), false, 'a teachers-only notice is not a student notice');
    await badgeBecomes(page, '8');
    step('tapping an announcement opens its notice and the badge drops without a refresh');

    await tab(page, 'More').click();
    await shown(page, 'Notifications').first().click();
    await seen(page, '8 unread · swipe a card to dismiss it');
    await page.getByTestId('mark-all-read').filter({ visible: true }).first().click();
    await seen(page, 'All read · swipe a card to dismiss it');
    assert.equal(await page.locator('[data-testid^="unread-dot-"]').filter({ visible: true }).count(), 0);
    await page.getByRole('button', { name: 'Back', exact: true }).filter({ visible: true }).first().click();
    await seen(page, 'Notices and your notifications');
    const cleared = await badgeBecomes(page, '');
    assert.equal(await visible(page, '9+ new'), false);
    await tab(page, 'Home').click();
    assert.equal(await badge(page), '');
    step(`mark all read clears the badge on the tab bar and the More row (${cleared} ms)`);

    // ---------------- Parent: students-only notices never arrive ----------------
    await signOut(page);
    await signIn(page, 'Parent', 'Fees');
    await badgeBecomes(page, '1');
    await tab(page, 'Notices').click();
    await seen(page, 'Announcements from your institute');
    await seen(page, 'Annual Science Fair');
    for (const hidden of ['Bring your ID cards', 'Reminder 1', 'Staff meeting on Saturday']) {
      assert.equal(await visible(page, hidden), false, `${hidden} must not reach a parent`);
    }
    await tab(page, 'More').click();
    await shown(page, 'Notifications').first().click();
    await seen(page, '1 unread · swipe a card to dismiss it');
    assert.equal(await visible(page, 'Bring your ID cards'), false);
    assert.equal(await visible(page, 'Reminder 1'), false);
    await shot(page, 'centre-parent');
    step('a parent got none of the ten "Students only" notices: badge 1, inbox and list clean');

    assert.deepEqual(errors, [], `page errors: ${errors.join(' | ')}`);
    step('no runtime errors in the browser');
    console.log('\nNotices browser acceptance passed');
  } catch (error) {
    await shot(page, 'failure').catch(() => {});
    console.error(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.close();
  }
})();
