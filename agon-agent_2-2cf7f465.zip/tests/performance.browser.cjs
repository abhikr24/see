// Measures the exported memory-backend preview on local headless Chromium.
const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) return res.writeHead(403).end();
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
});
(async () => {
  await new Promise(resolve => server.listen(8126, resolve));
  const browser = await chromium.launch({headless:true,args:['--no-sandbox']});
  const context = await browser.newContext({viewport:{width:400,height:860}, deviceScaleFactor:1});
  const page = await context.newPage();
  try {
    let t = performance.now();
    await page.goto('http://localhost:8126/');
    await page.locator('input[type="password"]').or(page.getByText('Skip', {exact:true})).first().waitFor({timeout:30000});
    console.log(`cold start to first interactive auth screen: ${(performance.now()-t).toFixed(1)} ms`);
    if (await page.getByText('Skip', {exact:true}).isVisible().catch(() => false)) await page.getByText('Skip', {exact:true}).click();
    await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
    await page.locator('input[type="password"]').first().fill('demo1234');
    await page.getByRole('button',{name:'Sign in',exact:true}).click();
    await page.getByText('Enter code',{exact:true}).waitFor({timeout:30000});
    await page.locator('input:visible').first().click();
    await page.keyboard.type('123456');
    await page.getByRole('button',{name:'Verify',exact:true}).click();
    await page.locator('[role="tab"]').first().waitFor({timeout:30000});
    t = performance.now();
    await page.locator('[role="tab"]').nth(1).click();
    await page.getByText('Aarav Sharma',{exact:true}).first().waitFor({timeout:30000});
    console.log(`students tab click to first seeded row visible: ${(performance.now()-t).toFixed(1)} ms`);
    await page.locator('[role="tab"]').first().click();
    await page.getByText('Timetable',{exact:true}).first().click();
    await page.getByText('Drag a period to reorder',{exact:false}).waitFor({timeout:30000});
    await page.getByRole('button',{name:/attendance for Class 10-A/}).first().click();
    await page.getByText('Editing saved sheet').waitFor({timeout:30000});
    await page.getByRole('button',{name:/^Ishita Bose, roll/}).click();
    t = performance.now();
    await page.getByRole('button',{name:/Update attendance/}).click();
    await page.getByText(/Attendance updated/).waitFor({timeout:30000});
    console.log(`attendance save click to confirmation: ${(performance.now()-t).toFixed(1)} ms`);
  } finally { await browser.close(); server.close(); }
})().catch(e => { console.error(e); server.close(); process.exitCode = 1; });
