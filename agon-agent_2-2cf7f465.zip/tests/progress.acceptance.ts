import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { PROGRESS_DEMO } from '../src/backends/memory/seed-progress';
import { progressPort } from '../src/backends/memory/progress';
import { ABILITY_LABELS } from '../src/core/contracts/progress';
import { buildBoard, groupOfAlert } from '../src/features/progress/model';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

async function main() {
  const db = createDb();
  seed(db);
  db.session.userId = SEED.ownerId;
  const i = SEED.instituteId;
  const progress = progressPort(db);

  console.log('Progress alerts acceptance');

  await check('a student seeded below 75% attendance appears in Needs attention', async () => {
    const alerts = await progress.computeAlerts(i, {});
    const mine = alerts.filter((a) => a.studentId === PROGRESS_DEMO.lowAttendanceStudent);
    const low = mine.find((a) => a.kind === 'low_attendance');
    const sudden = mine.find((a) => a.kind === 'sudden_absence');
    assert.ok(low, 'low_attendance fires');
    assert.ok(sudden, 'sudden_absence fires');
    assert.equal(groupOfAlert(low.kind), 'attention');
    assert.equal(groupOfAlert(sudden.kind), 'attention');
    const declining = alerts.find(
      (a) => a.studentId === PROGRESS_DEMO.decliningStudent && a.kind === 'declining_marks',
    );
    assert.ok(declining, 'declining_marks fires for the seeded student');
    assert.equal(groupOfAlert(declining.kind), 'watch');
    const behind = alerts.find(
      (a) => a.studentId === PROGRESS_DEMO.behindOnHomework && a.kind === 'work_incomplete',
    );
    assert.ok(behind, 'work_incomplete fires for the seeded student');
    const improving = alerts.find(
      (a) => a.studentId === PROGRESS_DEMO.improvingStudent && a.kind === 'improving',
    );
    assert.ok(improving, 'improving fires for the seeded student');
    assert.equal(groupOfAlert(improving.kind), 'improving');
  });

  await check('every alert states the rule with the actual number', async () => {
    const alerts = await progress.computeAlerts(i, {});
    assert.ok(alerts.length > 0);
    for (const alert of alerts) {
      assert.match(alert.detail, /\d/, `${alert.kind} detail carries a number: ${alert.detail}`);
      assert.ok(
        alert.detail.length >= 20,
        `${alert.kind} detail states the rule in words: ${alert.detail}`,
      );
    }
    const low = alerts.find(
      (a) => a.studentId === PROGRESS_DEMO.lowAttendanceStudent && a.kind === 'low_attendance',
    )!;
    assert.ok(low.detail.includes('60%'), `seeded text shows 60%: ${low.detail}`);
  });

  await check('logging an intervention shows on the timeline and can be closed', async () => {
    const studentId = PROGRESS_DEMO.lowAttendanceStudent;
    const before = await progress.listInterventions(i, { studentId });
    assert.ok(before.length >= 1, 'seeded timeline exists');
    assert.ok(before.every((row) => row.studentId === studentId));
    const logged = await progress.logIntervention(i, {
      studentId,
      kind: 'extra_class',
      doneBy: 'Meera Iyer',
      doneOn: new Date().toISOString().slice(0, 10),
      note: 'Saturday revision hour.',
    });
    assert.equal(logged.outcome, null);
    const after = await progress.listInterventions(i, { studentId });
    assert.ok(after.some((row) => row.id === logged.id), 'new entry is on the timeline');
    const open = (await progress.listInterventions(i)).filter((row) => row.outcome === null).length;
    const closed = await progress.setInterventionOutcome(i, logged.id, 'improved');
    assert.equal(closed.outcome, 'improved');
    assert.ok(closed.closedAt);
    const openAfter = (await progress.listInterventions(i)).filter((row) => row.outcome === null).length;
    assert.equal(openAfter, open - 1, 'closing removes it from the open count');
  });

  await check('no alert ever labels a student by ability', async () => {
    const alerts = await progress.computeAlerts(i, {});
    for (const alert of alerts) {
      assert.ok(!ABILITY_LABELS.test(alert.title), `clean title: ${alert.title}`);
      assert.ok(!ABILITY_LABELS.test(alert.detail), `clean detail: ${alert.detail}`);
    }
  });

  await check('the board groups by severity with header stats', async () => {
    const alerts = await progress.computeAlerts(i, {});
    const students = await db.students.all(i);
    const batches = db.batches.all(i);
    const interventions = await progress.listInterventions(i);
    const board = buildBoard(alerts, students, batches, interventions);
    const keys = board.groups.map((g) => g.key);
    assert.deepEqual(keys, ['attention', 'watch', 'improving']);
    assert.ok(board.groups[0].items.length >= 1, 'Needs attention is not empty');
    assert.ok(board.stats.studentsAtRisk >= 3, 'at least the three seeded risk students');
    assert.ok(board.stats.alertsThisWeek >= board.total, 'fresh seed: everything detected this week');
    assert.equal(
      board.stats.interventionsOpen,
      interventions.filter((row) => row.outcome === null).length,
    );
    for (const group of board.groups) {
      for (const card of group.items) {
        assert.ok(card.studentName.length > 0);
        assert.ok(card.batchName.length > 0);
      }
    }
  });

  await check('alerts are per-institute and recomputed on read', async () => {
    assert.deepEqual(await progress.computeAlerts('other-tenant', {}), []);
    assert.deepEqual(await progress.listInterventions('other-tenant'), []);
    // Resolving the cause resolves the alert on the next read: no background job.
    const studentId = PROGRESS_DEMO.behindOnHomework;
    const before = (await progress.computeAlerts(i, { studentId })).map((a) => a.kind);
    assert.ok(before.includes('work_incomplete'));
    for (const assignment of db.assignments.all(i, { batchId: db.batches.all(i).find((b) => b.name === 'Class 11-A')!.id })) {
      if (!db.submissions.find(i, { assignmentId: assignment.id, studentId })) {
        db.submissions.insert(i, {
          assignmentId: assignment.id,
          batchId: assignment.batchId,
          studentId,
          content: null,
          submittedAt: new Date().toISOString(),
          status: 'submitted',
        });
      }
    }
    const after = (await progress.computeAlerts(i, { studentId })).map((a) => a.kind);
    assert.ok(!after.includes('work_incomplete'), 'handing everything in clears the alert on read');
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
