import { PGlite } from '@electric-sql/pglite';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
const db = new PGlite({ extensions: { pgcrypto } });
try {
  await db.query('create extension if not exists pgcrypto');
  const r = await db.query("select crypt('x', gen_salt('bf', 4)) as h");
  console.log('pgcrypto+crypt OK', r.rows[0].h.slice(0, 7));
} catch (e) { console.log('FAIL:', e.message); }
await db.query('create role authenticated nologin');
await db.query('create function auth_uid() returns uuid language sql stable as $$ select nullif(current_setting(\'request.jwt.claim.sub\', true), \'\')::uuid $$');
await db.query("select set_config('request.jwt.claim.sub', '00000000-0000-4000-8000-000000000002', false)");
const r2 = await db.query('select auth_uid() as u');
console.log('jwt claim sub:', r2.rows[0].u);
await db.query('set role authenticated');
const r3 = await db.query('select auth_uid() as u, current_user as cu');
console.log('as role:', r3.rows[0]);
await db.close();
