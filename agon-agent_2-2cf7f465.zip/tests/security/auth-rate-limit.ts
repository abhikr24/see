/**
 * tests/security/auth-rate-limit.ts
 *
 * Evidence for the client half of check 12: the auth throttle in
 * src/adapters/supabase/auth-rate-limit.ts allows 5 attempts per 60 s
 * sliding window and refuses the 6th; the window slides, so an attempt
 * after it passes is accepted again.
 *
 * Usage: npx tsx tests/security/auth-rate-limit.ts
 */

import assert from 'node:assert/strict';
import { checkAuthRateLimit, resetAuthRateLimit } from '../../src/adapters/supabase/auth-rate-limit';
import { BackendError } from '../../src/core/contracts/errors';

const T0 = 1_000_000_000_000;
const results: (string | number)[][] = [];

// 5 attempts inside the window — all accepted
for (let i = 1; i <= 5; i++) {
  checkAuthRateLimit('sign-in', T0 + i * 1_000);
  results.push([`attempt ${i} at t+${i}s`, 'accepted']);
}

// 6th attempt, still inside the window — refused
let refused = false;
let code = '';
try {
  checkAuthRateLimit('sign-in', T0 + 6_000);
} catch (e) {
  refused = e instanceof BackendError;
  code = (e as BackendError).code;
  results.push(['attempt 6 at t+6s', `refused — BackendError ${code}`]);
}
assert.ok(refused, 'the 6th attempt must be refused');
assert.equal(code, 'RATE_LIMITED');

// A different action is not affected by sign-in's window
checkAuthRateLimit('otp', T0 + 6_000);
results.push(['otp at t+6s (different action)', 'accepted']);

// After the window has passed, attempts are accepted again
checkAuthRateLimit('sign-in', T0 + 62_000);
results.push(['attempt 7 at t+62s (window elapsed)', 'accepted']);

// Reset clears the window (used on sign-out)
resetAuthRateLimit('sign-in');
for (let i = 1; i <= 5; i++) checkAuthRateLimit('sign-in', T0 + 70_000);
results.push(['5 attempts after resetAuthRateLimit', 'accepted']);

console.log('## Check 12 (client half) · auth throttle — src/adapters/supabase/auth-rate-limit.ts');
console.log('');
console.log('```ts');
console.log("checkAuthRateLimit('sign-in', now);  // before every supabase.auth call");
console.log('```');
console.log('');
console.log('| step | outcome |');
console.log('| --- | --- |');
for (const r of results) console.log(`| ${r[0]} | ${r[1]} |`);
console.log('');
console.log('5/5 + refused 6th + sliding window + per-action isolation + reset — all asserted, 0 failures.');
