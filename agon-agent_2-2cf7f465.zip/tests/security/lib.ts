/**
 * tests/security/lib.ts
 *
 * Harness for the security audit. Runs the project's real Supabase
 * migrations against real Postgres (PGlite — Postgres compiled to WASM,
 * single connection) with a shim for the parts a hosted Supabase project
 * provides: the auth schema (auth.users, auth.identities, auth.uid()),
 * the anon / authenticated / service_role roles, and the storage schema.
 *
 * Migrations are executed exactly as `supabase db push` would: in file
 * order, statement by statement, stopping at the first failure. Data is
 * seeded from supabase/seed.sql, then fixtures add a second institute and
 * a second family so tenant and family boundaries can be tested.
 */

import { PGlite } from '@electric-sql/pglite';
import { pgcrypto } from '@electric-sql/pglite/contrib/pgcrypto';
import * as fs from 'node:fs';
import * as path from 'node:path';

export const ROOT = path.resolve(__dirname, '..', '..');
export const MIGRATIONS_DIR = path.join(ROOT, 'supabase', 'migrations');
export const SEED_FILE = path.join(ROOT, 'supabase', 'seed.sql');

// ---------------------------------------------------------------------
// SQL statement splitter (quote / dollar-quote / comment aware)
// ---------------------------------------------------------------------

function stripComments(stmt: string): string {
  return stmt
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .split('\n')
    .map((line) => line.replace(/--.*$/, ''))
    .join('\n');
}

export function splitSql(sql: string): string[] {
  const out: string[] = [];
  let cur = '';
  let i = 0;
  let inLine = false;
  let inBlock = false;
  let quote: string | null = null;
  let dollar: string | null = null;

  while (i < sql.length) {
    const ch = sql[i];
    const two = sql.slice(i, i + 2);

    if (inLine) {
      if (ch === '\n') inLine = false;
      cur += ch;
      i += 1;
      continue;
    }
    if (inBlock) {
      if (two === '*/') {
        inBlock = false;
        cur += two;
        i += 2;
      } else {
        cur += ch;
        i += 1;
      }
      continue;
    }
    if (quote) {
      if ((quote === "'" && two === "''") || (quote === '"' && two === '""')) {
        cur += two;
        i += 2;
        continue;
      }
      if (ch === quote) quote = null;
      cur += ch;
      i += 1;
      continue;
    }
    if (dollar) {
      if (sql.startsWith(dollar, i)) {
        cur += dollar;
        i += dollar.length;
        dollar = null;
      } else {
        cur += ch;
        i += 1;
      }
      continue;
    }
    if (two === '--') {
      inLine = true;
      cur += two;
      i += 2;
      continue;
    }
    if (two === '/*') {
      inBlock = true;
      cur += two;
      i += 2;
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      cur += ch;
      i += 1;
      continue;
    }
    if (ch === '$') {
      const m = /^\$[A-Za-z_0-9]*\$/.exec(sql.slice(i));
      if (m) {
        dollar = m[0];
        cur += m[0];
        i += m[0].length;
        continue;
      }
    }
    if (ch === ';') {
      out.push(cur);
      cur = '';
      i += 1;
      continue;
    }
    cur += ch;
    i += 1;
  }
  if (cur.trim()) out.push(cur);

  return out.map((s) => s.trim()).filter((s) => stripComments(s).trim().length > 0);
}

// ---------------------------------------------------------------------
// Evidence report
// ---------------------------------------------------------------------

export class Report {
  readonly lines: string[] = [];

  push(line = ''): void {
    this.lines.push(line);
    process.stdout.write(line + '\n');
  }

  sql(sqlText: string): void {
    this.push('```sql');
    for (const line of sqlText.split('\n')) this.push('  ' + line);
    this.push('```');
  }

  table(header: string[], rows: (string | number)[][]): void {
    this.push('| ' + header.join(' | ') + ' |');
    this.push('| ' + header.map(() => '---').join(' | ') + ' |');
    for (const row of rows) this.push('| ' + row.join(' | ') + ' |');
  }
}

// ---------------------------------------------------------------------
// Harness
// ---------------------------------------------------------------------

export async function createHarness(): Promise<PGlite> {
  const db = new PGlite({ extensions: { pgcrypto } });
  await installSupabaseShim(db);
  return db;
}

async function installSupabaseShim(db: PGlite): Promise<void> {
  await db.exec(`
    create role anon nologin;
    create role authenticated nologin;
    create role service_role nologin bypassrls;

    -- pgcrypto lives in the extensions schema, as on a hosted project
    create schema if not exists extensions;
    create extension if not exists pgcrypto with schema extensions;
    grant usage on schema extensions to anon, authenticated, service_role;

    -- ---- auth schema, as a hosted Supabase project provides it --------
    create schema if not exists auth;
    grant usage on schema auth to anon, authenticated, service_role;

    create table auth.users (
      id                       uuid primary key,
      instance_id              uuid,
      aud                      text,
      role                     text,
      email                    text,
      phone                    text,
      encrypted_password       text,
      email_confirmed_at       timestamptz,
      raw_app_meta_data        jsonb,
      raw_user_meta_data       jsonb,
      created_at               timestamptz default now(),
      updated_at               timestamptz default now(),
      confirmation_token       text,
      recovery_token           text,
      email_change             text,
      email_change_token_new   text
    );

    create table auth.identities (
      id              uuid primary key,
      provider_id     text not null,
      user_id         uuid not null references auth.users (id) on delete cascade,
      identity_data   jsonb not null,
      provider        text not null,
      last_sign_in_at timestamptz,
      created_at      timestamptz default now(),
      updated_at      timestamptz default now()
    );

    -- PostgREST sets these GUCs per request from the verified JWT.
    create function auth.uid() returns uuid
      language sql stable
      as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;

    create function auth.role() returns text
      language sql stable
      as $$ select coalesce(nullif(current_setting('request.jwt.claim.role', true), ''), 'authenticated') $$;

    grant execute on function auth.uid() to anon, authenticated, service_role;
    grant execute on function auth.role() to anon, authenticated, service_role;

    -- ---- storage schema (buckets + objects), as Supabase provides ------
    create schema if not exists storage;
    grant usage on schema storage to anon, authenticated, service_role;

    create table storage.buckets (
      id                 text primary key,
      name               text not null,
      public             boolean not null default false,
      file_size_limit    bigint,
      allowed_mime_types text[]
    );

    create table storage.objects (
      id          uuid primary key default gen_random_uuid(),
      bucket_id   text not null references storage.buckets (id) on delete cascade,
      name        text not null,
      owner       text,
      created_at  timestamptz default now(),
      updated_at  timestamptz default now(),
      metadata    jsonb,
      path_tokens text[],
      unique (bucket_id, name)
    );

    alter table storage.objects enable row level security;
    grant select, insert, update, delete on storage.objects to authenticated, anon;
    grant select, insert, update, delete on storage.buckets to service_role;

    -- helper Supabase ships with the storage schema (folder of an object)
    create function storage.foldername(fullpath text)
      returns text[]
      language sql immutable
      as $$ select (string_to_array(fullpath, '/'))[1:greatest(array_length(string_to_array(fullpath, '/'), 1) - 1, 0)] $$;
  `);
}

export interface MigrationOutcome {
  file: string;
  ok: boolean;
  statements: number;
  failedStatement?: string;
  error?: string;
}

/**
 * Applies migrations in file order, statement by statement. Stops at the
 * first failing file, exactly as `supabase db push` does on a clean
 * database. Files that wrap themselves in begin/commit roll back whole.
 */
export async function applyMigrations(db: PGlite, report: Report): Promise<MigrationOutcome[]> {
  const files = fs.readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith('.sql')).sort();
  const outcomes: MigrationOutcome[] = [];

  for (const file of files) {
    const stmts = splitSql(fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8'));
    let ok = true;
    let failedStatement: string | undefined;
    let error: string | undefined;

    for (const stmt of stmts) {
      try {
        await db.exec(stmt);
      } catch (e) {
        ok = false;
        failedStatement = stmt;
        error = e instanceof Error ? e.message : String(e);
        // close the aborted transaction the file opened, if any
        try {
          await db.exec('rollback');
        } catch {
          /* not in a transaction — fine */
        }
        break;
      }
    }

    outcomes.push({ file, ok, statements: stmts.length, failedStatement, error });
    if (!ok) break;
  }

  report.push(`
### Migration chain (supabase/migrations, file order)`);
  report.table(
    ['file', 'statements', 'result'],
    outcomes.map((o) => [o.file, o.statements, o.ok ? 'applied' : '**FAILED — chain stops here**']),
  );
  const failed = outcomes.find((o) => !o.ok);
  if (failed?.failedStatement) {
    report.push('');
    report.push(`First failing statement in \`${failed.file}\`:`);
    report.sql(failed.failedStatement.trim());
    report.push(`Postgres error: \`${failed.error}\``);
  }
  return outcomes;
}

export async function applySeed(db: PGlite): Promise<void> {
  for (const stmt of splitSql(fs.readFileSync(SEED_FILE, 'utf8'))) {
    await db.exec(stmt);
  }
}

// ---------------------------------------------------------------------
// Identity switching
// ---------------------------------------------------------------------

export async function asSuperuser(db: PGlite): Promise<void> {
  await db.exec('reset role');
  await db.query("select set_config('request.jwt.claim.sub', '', false)");
  await db.query("select set_config('request.jwt.claim.role', '', false)");
}

/** Sign in as a user (PostgREST-equivalent: role + verified JWT claims). */
export async function becomeUser(db: PGlite, userId: string): Promise<void> {
  await db.exec('reset role');
  await db.query("select set_config('request.jwt.claim.sub', $1, false)", [userId]);
  await db.query("select set_config('request.jwt.claim.role', 'authenticated', false)");
  await db.exec('set role authenticated');
}

export async function becomeAnon(db: PGlite): Promise<void> {
  await db.exec('reset role');
  await db.query("select set_config('request.jwt.claim.sub', '', false)");
  await db.query("select set_config('request.jwt.claim.role', 'anon', false)");
  await db.exec('set role anon');
}

// ---------------------------------------------------------------------
// Query helpers
// ---------------------------------------------------------------------

export async function scalar<T = unknown>(db: PGlite, sqlText: string): Promise<T> {
  const res = await db.query<{ v: T }>(`select (${sqlText}) as v`);
  return res.rows[0].v;
}

export async function count(db: PGlite, table: string, where = 'true'): Promise<number> {
  const res = await db.query<{ n: number }>(`select count(*)::int as n from ${table} where ${where}`);
  return res.rows[0].n;
}

export interface AttemptResult {
  ok: boolean;
  affected: number | null;
  code: string;
  message: string;
}

/** Run one statement as the current identity; capture the outcome. */
export async function attempt(db: PGlite, sqlText: string): Promise<AttemptResult> {
  try {
    const res = await db.query(sqlText);
    const affected =
      (res as unknown as { affectedRows?: number }).affectedRows ??
      (res as unknown as { rowCount?: number }).rowCount ??
      null;
    return { ok: true, affected, code: '00000', message: 'ok' };
  } catch (e) {
    const err = e as { code?: string; message?: string };
    return { ok: false, affected: null, code: err.code ?? '?', message: err.message ?? String(e) };
  }
}
