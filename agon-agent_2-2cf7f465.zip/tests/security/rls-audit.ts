/**
 * tests/security/rls-audit.ts
 *
 * Security audit for the 12 checks in the security prompt. Runs the real
 * migrations + seed against real Postgres (PGlite) with a Supabase shim,
 * adds a second institute and a second family, then executes every check
 * as the exact identities involved and prints evidence: the SQL that ran
 * and the row counts / errors that came back.
 *
 * File / bundle checks (7, 8, 10, 11 and the client half of 12) are
 * executed against the working tree (and dist/ when present).
 *
 * Usage: npx tsx tests/security/rls-audit.ts
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import {
  MIGRATIONS_DIR,
  ROOT,
  Report,
  applyMigrations,
  applySeed,
  asSuperuser,
  attempt,
  becomeUser,
  count,
  createHarness,
  scalar,
  type MigrationOutcome,
} from './lib';
import type { PGlite } from '@electric-sql/pglite';

const report = new Report();

// ---------------------------------------------------------------------
// Fixed identities (seed pattern: 00000000-…-NN)
// ---------------------------------------------------------------------
const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const bid = (s: string) => `20000000-0000-4000-8000-${s.padStart(12, '0')}`;
const fid = (s: string) => `30000000-0000-4000-8000-${s.padStart(12, '0')}`;
const rid = (s: string) => `40000000-0000-4000-8000-${s.padStart(12, '0')}`;
const iid = (s: string) => `50000000-0000-4000-8000-${s.padStart(12, '0')}`;

const INST_A = sid(1); // Sunrise Coaching Classes (seeded)
const OWNER_A = sid(2); // Rahul Sharma
const TEACHER_A = sid(3); // Rohit Verma — class teacher of 10-A
const TEACHER_A2 = sid(4); // Priya Nair
const STUDENT_A = sid(14); // Aarav Sharma (student in A)
const STUDENT_A2 = sid(15); // Aditya Pandey — family 1's child
const STUDENT_A3 = sid(16); // Ananya Singh — family 2's child
const PENDING_A = sid(38); // Kunal Sinha — pending student in A
const BRANCH_A = sid(8);
const BATCH_A = sid(9); // Class 10-A

const INST_B = bid('1'); // Rival Classes (fixture)
const OWNER_B = bid('2');
const TEACHER_B = bid('3');
const STUDENT_B1 = bid('14');
const STUDENT_B2 = bid('15');
const STUDENT_B3 = bid('16');
const PARENT_B = bid('41');
const PENDING_B = bid('38');

const PARENT_1 = fid('1'); // parent of Aditya (15) in institute A
const PARENT_2 = fid('2'); // parent of Ananya (16) in institute A
const ADMIN_1 = fid('5'); // admin in A holding the `members` permission

const RL_USER = rid('1'); // fresh user with no memberships (rate-limit / enumeration probes)
const RL_LOOKUP = rid('3'); // fresh user with no memberships (lookup probe)
const RL_DUMMY_OWNER = rid('2');

// ---------------------------------------------------------------------
// File / bundle checks (7, 8, 10, 11 — client half of 12)
// ---------------------------------------------------------------------

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

function grepFiles(files: string[], pattern: RegExp): { file: string; line: string }[] {
  const hits: { file: string; line: string }[] = [];
  for (const f of files) {
    const text = fs.readFileSync(f, 'utf8');
    text.split('\n').forEach((line, i) => {
      if (pattern.test(line)) hits.push({ file: path.relative(ROOT, f) + ':' + (i + 1), line: line.trim() });
    });
  }
  return hits;
}

function fileChecks(): void {
  report.push('\n## Check 7 · service-role key must not reach the client bundle');
  const dist = path.join(ROOT, 'dist');
  if (!fs.existsSync(dist)) {
    report.push('`dist/` not built in this run — see the bundle search below the export in the transcript.');
  } else {
    const bundleFiles = walk(dist).filter((f) => /\.(js|html|css)$/.test(f));
    const hits = grepFiles(bundleFiles, /service[_-]?role|SERVICE[_-]?ROLE/i);
    report.push(
      `Searched ${bundleFiles.length} built files in \`dist/\` for \`service[_-]?role\` (case-insensitive): **${hits.length} hits**.`,
    );
    for (const h of hits) report.push(`- \`${h.file}\` → \`${h.line.slice(0, 120)}\``);
    const jwtHits = grepFiles(bundleFiles, /eyJ[A-Za-z0-9_-]{10,}/);
    const distinct = [...new Set(jwtHits.map((h) => (h.line.match(/eyJ[A-Za-z0-9_-]{10,}/g) ?? []).join(' ')))];
    report.push(`Distinct JWT-shaped strings in the bundle: ${distinct.length === 0 ? 'none' : ''}`);
    for (const d of distinct) report.push(`- \`${d.slice(0, 160)}\``);
  }

  report.push('\n## Check 8 · `grep -rn "supabase" src/features app/`');
  const featureFiles = [...walk(path.join(ROOT, 'src', 'features')), ...walk(path.join(ROOT, 'app'))].filter((f) =>
    /\.(ts|tsx)$/.test(f),
  );
  const supHits = grepFiles(featureFiles, /supabase/);
  const supHitsCi = grepFiles(featureFiles, /supabase/i);
  report.push(`\`\`\`bash`);
  report.push(`grep -rn "supabase" src/features app/   # → ${supHits.length} hits (exit ${supHits.length === 0 ? 1 : 0})`);
  report.push(`grep -rni "supabase" src/features app/  # → ${supHitsCi.length} hits`);
  report.push(`\`\`\``);
  report.push(
    supHits.length === 0
      ? 'No feature or route file mentions Supabase. All SDK access lives behind `src/adapters/supabase/`.'
      : `**FAIL** — ${supHits.length} hits:`,
  );
  for (const h of supHits) report.push(`- \`${h.file}\` → \`${h.line.slice(0, 120)}\``);

  report.push('\n## Check 10 · sessions in expo-secure-store, never AsyncStorage');
  const srcFiles = walk(path.join(ROOT, 'src')).filter((f) => /\.(ts|tsx)$/.test(f));
  const asyncHits = grepFiles(srcFiles, /AsyncStorage/);
  report.push('`AsyncStorage` occurrences in `src/`:');
  for (const h of asyncHits) report.push(`- \`${h.file}\` → \`${h.line.slice(0, 110)}\``);
  report.push(
    'None of the lines above read or write a session, token or key — they are the onboarding-seen flag, offline outboxes and the recent-searches cache.',
  );
  const memoryAuth = fs.readFileSync(path.join(ROOT, 'src', 'backends', 'memory', 'auth.ts'), 'utf8');
  report.push(
    `Reference backend session: \`src/backends/memory/auth.ts\` uses \`expo-secure-store\` — ${
      /SecureStore/.test(memoryAuth) ? 'confirmed' : 'MISSING'
    }.`,
  );
  const client = fs.readFileSync(path.join(ROOT, 'src', 'adapters', 'supabase', 'client.ts'), 'utf8');
  const hasSecureAdapter = /storage:\s*secureSessionStorage/.test(client);
  const referencesSecureStore = /expo-secure-store/.test(client);
  report.push(
    `Live backend session: \`src/adapters/supabase/client.ts\` passes a secure storage adapter to \`createClient\` — ${
      hasSecureAdapter && referencesSecureStore ? 'confirmed (expo-secure-store on native; localStorage on web where SecureStore does not exist)' : '**MISSING** — supabase-js falls back to in-memory (native) / localStorage (web)'
    }.`,
  );

  report.push('\n## Check 11 · webhook signature verification (Razorpay)');
  const codeDirs = [path.join(ROOT, 'src'), path.join(ROOT, 'app'), path.join(ROOT, 'supabase')];
  const allCode = codeDirs.flatMap((d) => (fs.existsSync(d) ? walk(d) : [])).filter((f) => /\.(ts|tsx|sql)$/.test(f));
  const webhookHits = grepFiles(allCode, /razorpay|webhook|x-webhook/i);
  report.push(`\`grep -rni "razorpay\\|webhook" src app supabase\` → ${webhookHits.length} hits:`);
  for (const h of webhookHits) report.push(`- \`${h.file}\` → \`${h.line.slice(0, 110)}\``);
  report.push(
    'No payment gateway and no webhook endpoint exist in the project yet — there is nothing to verify and nothing that trusts an unsigned callback. The requirement for the day Razorpay is added is written into docs/SECURITY.md.',
  );
}

// ---------------------------------------------------------------------
// Fixtures: institute B, two families in A, one admin, rate-limit dummies
// ---------------------------------------------------------------------

async function installFixtures(db: PGlite): Promise<void> {
  const sql = `
insert into auth.users (id, email, raw_user_meta_data) values
  ('${OWNER_B}',   'owner.b@rival.test',   '{"full_name":"Bhavna Owner"}'),
  ('${TEACHER_B}', 'teacher.b@rival.test', '{"full_name":"Tarun Teacher"}'),
  ('${STUDENT_B1}','student.b1@rival.test','{"full_name":"B Student One"}'),
  ('${STUDENT_B2}','student.b2@rival.test','{"full_name":"B Student Two"}'),
  ('${STUDENT_B3}','student.b3@rival.test','{"full_name":"B Student Three"}'),
  ('${PARENT_B}',  'parent.b@rival.test',  '{"full_name":"Beena Parent"}'),
  ('${PENDING_B}', 'pending.b@rival.test', '{"full_name":"Bharat Pending"}'),
  ('${PARENT_1}',  'parent.one@sunrise.test', '{"full_name":"Prakash Parent One"}'),
  ('${PARENT_2}',  'parent.two@sunrise.test', '{"full_name":"Priyanka Parent Two"}'),
  ('${ADMIN_1}',   'admin.one@sunrise.test', '{"full_name":"Aarti Admin"}'),
  ('${RL_USER}',   'rl.user@test',        '{"full_name":"Rima Ratelimit"}'),
  ('${RL_LOOKUP}', 'rl.lookup@test',      '{"full_name":"Lalit Lookup"}'),
  ('${RL_DUMMY_OWNER}', 'rl.owner@test',  '{"full_name":"Dinesh Dummy"}');

-- Institute B (the trigger gives its owner an active owner membership)
insert into public.institutes (id, name, code, owner_id, city) values
  ('${INST_B}', 'Rival Classes', 'RIVAL-MUM', '${OWNER_B}', 'Mumbai');

insert into public.branches (id, institute_id, name, code, is_main) values
  ('${bid('8')}', '${INST_B}', 'Andheri Main', 'RIV-MAIN', true);

insert into public.subjects (id, institute_id, name, code, color) values
  ('${bid('44')}', '${INST_B}', 'Mathematics', 'RIV-MATH', '#2563eb');

insert into public.batches (id, institute_id, branch_id, name, grade, section, academic_year, status) values
  ('${bid('9')}', '${INST_B}', '${bid('8')}', 'Class 9-B', '9', 'B', '2026-27', 'active');

insert into public.memberships (id, institute_id, user_id, branch_id, role, status, decided_by, decided_at) values
  ('${TEACHER_B}', '${INST_B}', '${TEACHER_B}', '${bid('8')}', 'teacher', 'active', '${OWNER_B}', now()),
  ('${STUDENT_B1}', '${INST_B}', '${STUDENT_B1}', '${bid('8')}', 'student', 'active', '${OWNER_B}', now()),
  ('${STUDENT_B2}', '${INST_B}', '${STUDENT_B2}', '${bid('8')}', 'student', 'active', '${OWNER_B}', now()),
  ('${STUDENT_B3}', '${INST_B}', '${STUDENT_B3}', '${bid('8')}', 'student', 'active', '${OWNER_B}', now()),
  ('${PARENT_B}', '${INST_B}', '${PARENT_B}', '${bid('8')}', 'parent', 'active', '${OWNER_B}', now());

insert into public.memberships (id, institute_id, user_id, role, status, request_note, requested_at) values
  ('${PENDING_B}', '${INST_B}', '${PENDING_B}', 'student', 'pending', 'Want to join Class 9-B', now());

insert into public.teacher_profiles (id, institute_id, user_id, branch_id, full_name, specialization, status) values
  ('${TEACHER_B}', '${INST_B}', '${TEACHER_B}', '${bid('8')}', 'Tarun Teacher', 'Physics', 'active');

insert into public.batch_teachers (id, institute_id, batch_id, teacher_id, subject_id, is_class_teacher) values
  ('${bid('a00c')}', '${INST_B}', '${bid('9')}', '${TEACHER_B}', '${bid('44')}', true);

insert into public.student_profiles (id, institute_id, branch_id, admission_no, full_name, class_grade) values
  ('${STUDENT_B1}', '${INST_B}', '${bid('8')}', 'RIV-001', 'B Student One', '9'),
  ('${STUDENT_B2}', '${INST_B}', '${bid('8')}', 'RIV-002', 'B Student Two', '9'),
  ('${STUDENT_B3}', '${INST_B}', '${bid('8')}', 'RIV-003', 'B Student Three', '9');

insert into public.student_memberships (id, institute_id, student_id, membership_id, linked_by) values
  ('${STUDENT_B1}', '${INST_B}', '${STUDENT_B1}', '${STUDENT_B1}', '${OWNER_B}'),
  ('${STUDENT_B2}', '${INST_B}', '${STUDENT_B2}', '${STUDENT_B2}', '${OWNER_B}'),
  ('${STUDENT_B3}', '${INST_B}', '${STUDENT_B3}', '${STUDENT_B3}', '${OWNER_B}');

insert into public.batch_students (id, institute_id, batch_id, student_id, roll_number) values
  ('${bid('a00d')}', '${INST_B}', '${bid('9')}', '${STUDENT_B1}', 1),
  ('${bid('a00e')}', '${INST_B}', '${bid('9')}', '${STUDENT_B2}', 2),
  ('${bid('a00f')}', '${INST_B}', '${bid('9')}', '${STUDENT_B3}', 3);

insert into public.guardians (id, institute_id, membership_id, full_name, relation) values
  ('${bid('a00b')}', '${INST_B}', '${PARENT_B}', 'Beena Parent', 'mother');
insert into public.parent_links (id, institute_id, student_id, guardian_id, is_primary) values
  ('${bid('a010')}', '${INST_B}', '${STUDENT_B1}', '${bid('a00b')}', true);

insert into public.attendance_sessions (id, institute_id, batch_id, subject_id, teacher_id, session_date, period, status, marked_by, marked_at) values
  ('${bid('a001')}', '${INST_B}', '${bid('9')}', '${bid('44')}', '${TEACHER_B}', current_date, 1, 'submitted', '${TEACHER_B}', now());

insert into public.attendance_records (id, institute_id, session_id, batch_id, student_id, status, marked_by) values
  ('${bid('a011')}', '${INST_B}', '${bid('a001')}', '${bid('9')}', '${STUDENT_B1}', 'present', '${TEACHER_B}'),
  ('${bid('a012')}', '${INST_B}', '${bid('a001')}', '${bid('9')}', '${STUDENT_B2}', 'absent', '${TEACHER_B}'),
  ('${bid('a013')}', '${INST_B}', '${bid('a001')}', '${bid('9')}', '${STUDENT_B3}', 'late', '${TEACHER_B}');

insert into public.exams (id, institute_id, batch_id, name, exam_type, starts_on, ends_on, total_marks, status, published_at, created_by) values
  ('${bid('a002')}', '${INST_B}', '${bid('9')}', 'Unit Test 1', 'unit_test', current_date - 7, current_date - 7, 100, 'published', now(), '${OWNER_B}');

insert into public.marks (id, institute_id, exam_id, batch_id, student_id, subject_id, marks_obtained, max_marks, entered_by) values
  ('${bid('a014')}', '${INST_B}', '${bid('a002')}', '${bid('9')}', '${STUDENT_B1}', '${bid('44')}', 88, 100, '${TEACHER_B}'),
  ('${bid('a015')}', '${INST_B}', '${bid('a002')}', '${bid('9')}', '${STUDENT_B2}', '${bid('44')}', 72, 100, '${TEACHER_B}'),
  ('${bid('a016')}', '${INST_B}', '${bid('a002')}', '${bid('9')}', '${STUDENT_B3}', '${bid('44')}', 64, 100, '${TEACHER_B}');

insert into public.results (id, institute_id, exam_id, batch_id, student_id, total_obtained, total_max, percentage, grade, result_status) values
  ('${bid('a017')}', '${INST_B}', '${bid('a002')}', '${bid('9')}', '${STUDENT_B1}', 88, 100, 88, 'A', 'pass');

insert into public.fee_structures (id, institute_id, batch_id, name, academic_year, total_amount, installment_count, frequency) values
  ('${bid('a003')}', '${INST_B}', '${bid('9')}', 'Rival Annual Plan', '2026-27', 30000, 2, 'term');

insert into public.student_fees (id, institute_id, student_id, fee_structure_id, academic_year, gross_amount) values
  ('${bid('a004')}', '${INST_B}', '${STUDENT_B1}', '${bid('a003')}', '2026-27', 30000);

insert into public.installments (id, institute_id, student_fee_id, student_id, term_no, label, amount, due_date, status) values
  ('${bid('a005')}', '${INST_B}', '${bid('a004')}', '${STUDENT_B1}', 1, 'Term 1', 15000, current_date + 10, 'upcoming');

insert into public.payments (id, institute_id, student_id, student_fee_id, installment_id, amount, method, status, received_by) values
  ('${bid('a018')}', '${INST_B}', '${STUDENT_B1}', '${bid('a004')}', '${bid('a005')}', 15000, 'cash', 'completed', '${OWNER_B}');

insert into public.materials (id, institute_id, batch_id, subject_id, teacher_id, title, material_type, url, is_published, uploaded_by) values
  ('${bid('a006')}', '${INST_B}', '${bid('9')}', '${bid('44')}', '${TEACHER_B}', 'B Notes Chapter 1', 'notes', 'https://rival.test/notes-1', true, '${TEACHER_B}'),
  ('${bid('a007')}', '${INST_B}', null, null, null, 'B General Handbook', 'pdf', 'https://rival.test/handbook', true, '${OWNER_B}');

insert into public.admission_leads (id, institute_id, student_name, guardian_name, phone, class_interested, source, stage) values
  ('${bid('a008')}', '${INST_B}', 'B Lead One', 'B Guardian One', '9800000001', '9', 'walk_in', 'new'),
  ('${bid('a009')}', '${INST_B}', 'B Lead Two', 'B Guardian Two', '9800000002', '10', 'referral', 'contacted');

insert into public.lead_followups (id, institute_id, lead_id, channel, summary, outcome, done_by) values
  ('${bid('a00a')}', '${INST_B}', '${bid('a008')}', 'call', 'Called the guardian', 'callback', '${OWNER_B}');

insert into public.notices (id, institute_id, title, body, category, audience, published_at, created_by) values
  ('${bid('a01a')}', '${INST_B}', 'Rival welcome notice', 'Welcome to Rival Classes.', 'general', '{owner,admin,teacher,student,parent}', now(), '${OWNER_B}');

-- Two families inside institute A (for the family-boundary check)
insert into public.memberships (id, institute_id, user_id, branch_id, role, status, decided_by, decided_at) values
  ('${PARENT_1}', '${INST_A}', '${PARENT_1}', '${BRANCH_A}', 'parent', 'active', '${OWNER_A}', now()),
  ('${PARENT_2}', '${INST_A}', '${PARENT_2}', '${BRANCH_A}', 'parent', 'active', '${OWNER_A}', now()),
  ('${ADMIN_1}', '${INST_A}', '${ADMIN_1}', '${BRANCH_A}', 'admin', 'active', '${OWNER_A}', now());

update public.memberships set permissions = '{members}' where id = '${ADMIN_1}';

insert into public.guardians (id, institute_id, membership_id, full_name, relation) values
  ('${fid('2')}', '${INST_A}', '${PARENT_1}', 'Prakash Parent One', 'father'),
  ('${fid('4')}', '${INST_A}', '${PARENT_2}', 'Priyanka Parent Two', 'mother');

insert into public.parent_links (id, institute_id, student_id, guardian_id, is_primary) values
  ('${fid('a001')}', '${INST_A}', '${STUDENT_A2}', '${fid('2')}', true),
  ('${fid('a002')}', '${INST_A}', '${STUDENT_A3}', '${fid('4')}', true);

-- A staff record and two pending leave requests for the teacher checks
insert into public.staff_records (id, institute_id, user_id, employee_code, designation) values
  ('${fid('a003')}', '${INST_A}', '${TEACHER_A2}', 'S-004', 'Senior Teacher');

insert into public.leave_requests (id, institute_id, user_id, leave_type, from_date, to_date, reason, status) values
  ('${fid('a004')}', '${INST_A}', '${TEACHER_A}', 'casual', current_date + 3, current_date + 3, 'Family function', 'pending'),
  ('${fid('a005')}', '${INST_A}', '${TEACHER_A2}', 'sick', current_date + 5, current_date + 5, 'Fever', 'pending');

-- Six institutes owned by a dummy user, for the join-request rate-limit probe
insert into public.institutes (id, name, code, owner_id, city) values
  ('${iid('1')}', 'RL Institute 1', 'RL-INST-0001', '${RL_DUMMY_OWNER}', 'Patna'),
  ('${iid('2')}', 'RL Institute 2', 'RL-INST-0002', '${RL_DUMMY_OWNER}', 'Patna'),
  ('${iid('3')}', 'RL Institute 3', 'RL-INST-0003', '${RL_DUMMY_OWNER}', 'Patna'),
  ('${iid('4')}', 'RL Institute 4', 'RL-INST-0004', '${RL_DUMMY_OWNER}', 'Patna'),
  ('${iid('5')}', 'RL Institute 5', 'RL-INST-0005', '${RL_DUMMY_OWNER}', 'Patna'),
  ('${iid('6')}', 'RL Institute 6', 'RL-INST-0006', '${RL_DUMMY_OWNER}', 'Patna');
`;
  const { splitSql } = await import('./lib');
  for (const stmt of splitSql(sql)) await db.exec(stmt);
}

// ---------------------------------------------------------------------
// Check 1 · RLS + policies per table
// ---------------------------------------------------------------------

// Operations with no policy on purpose (deny-by-default), from the design
// comments in 0008_rls.sql and the later migrations.
const DENIED_BY_DESIGN: Record<string, { op: string; why: string }[]> = {
  plans: [
    { op: 'INSERT', why: 'service role only' },
    { op: 'UPDATE', why: 'service role only' },
    { op: 'DELETE', why: 'service role only' },
  ],
  subscriptions: [
    { op: 'INSERT', why: 'service role only' },
    { op: 'UPDATE', why: 'service role only' },
    { op: 'DELETE', why: 'service role only' },
  ],
  usage_records: [
    { op: 'INSERT', why: 'service role only' },
    { op: 'UPDATE', why: 'service role only' },
    { op: 'DELETE', why: 'service role only' },
  ],
  audit_logs: [
    { op: 'UPDATE', why: 'append-only' },
    { op: 'DELETE', why: 'append-only' },
  ],
  users: [
    { op: 'INSERT', why: 'read-only mirror of auth.users, written only by the handle_auth_user trigger (0008)' },
    { op: 'UPDATE', why: 'read-only mirror of auth.users, written only by the handle_auth_user trigger (0008)' },
    { op: 'DELETE', why: 'read-only mirror of auth.users, written only by the handle_auth_user trigger (0008)' },
  ],
  profiles: [{ op: 'DELETE', why: 'profile rows live with the account; deleted only by the user cascade (0008)' }],
  interventions: [{ op: 'DELETE', why: 'the InterventionPort has no delete — records are closed with an outcome, never removed (0017)' }],
  conversations: [{ op: 'DELETE', why: 'no delete path in the design' }],
  attachments: [{ op: 'UPDATE', why: 'immutable once uploaded' }],
  student_achievements: [{ op: 'DELETE', why: 'append-once (0015)' }],
  fee_payments: [
    { op: 'INSERT', why: 'created only by ensure_pending_fee_payment RPC (0016)' },
    { op: 'UPDATE', why: 'status moves only through the RPC / service role' },
    { op: 'DELETE', why: 'no delete path in the design' },
  ],
};

async function check1(db: PGlite): Promise<boolean> {
  report.push('\n## Check 1 · every table has RLS enabled and policy coverage per operation');
  const res = await db.query(`
    with pol as (
      select tablename, cmd from pg_policies where schemaname = 'public'
    )
    select c.relname as tbl, c.relrowsecurity as rls,
      (select count(*)::int from pol where pol.tablename = c.relname and cmd in ('SELECT','ALL')) as s,
      (select count(*)::int from pol where pol.tablename = c.relname and cmd in ('INSERT','ALL')) as i,
      (select count(*)::int from pol where pol.tablename = c.relname and cmd in ('UPDATE','ALL')) as u,
      (select count(*)::int from pol where pol.tablename = c.relname and cmd in ('DELETE','ALL')) as d
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public' and c.relkind = 'r'
    order by c.relname`);
  const rows = res.rows as { tbl: string; rls: boolean; s: number; i: number; u: number; d: number }[];
  report.sql(`select c.relname, c.relrowsecurity,
  count(*) filter (where cmd in ('SELECT','ALL')) … per command
from pg_class c left join pg_policies … where nspname = 'public'`);
  report.table(
    ['table', 'RLS', 'SELECT', 'INSERT', 'UPDATE', 'DELETE'],
    rows.map((r) => [r.tbl, r.rls ? 'on' : '**OFF**', r.s, r.i, r.u, r.d]),
  );

  const noRls = rows.filter((r) => !r.rls);
  const uncovered: { tbl: string; op: string; why?: string }[] = [];
  for (const r of rows) {
    const ops: [string, number][] = [
      ['SELECT', r.s],
      ['INSERT', r.i],
      ['UPDATE', r.u],
      ['DELETE', r.d],
    ];
    for (const [op, n] of ops) {
      if (n === 0) {
        const designed = (DENIED_BY_DESIGN[r.tbl] ?? []).find((x) => x.op === op);
        uncovered.push({ tbl: r.tbl, op, why: designed ? `deny-by-default — ${designed.why}` : undefined });
      }
    }
  }
  report.push('');
  if (noRls.length > 0) {
    report.push(`**Tables without RLS:** ${noRls.map((r) => r.tbl).join(', ')}`);
  } else {
    report.push(`All ${rows.length} public tables have RLS enabled.`);
  }
  const unexplained = uncovered.filter((u) => !u.why);
  if (unexplained.length > 0) {
    report.push(`**Operations with no policy and no documented reason:**`);
    for (const u of unexplained) report.push(`- ${u.tbl} ${u.op}`);
  } else {
    report.push(
      `Every operation on every table is either policy-governed or deliberately deny-by-default (${uncovered.length} denials, each matching the design comment in the migration). Postgres denies a command with no matching policy, so "no policy" = no access.`,
    );
  }
  return noRls.length === 0 && unexplained.length === 0;
}

// ---------------------------------------------------------------------
// Check 2 · student in A reading institute B
// ---------------------------------------------------------------------

async function check2(db: PGlite): Promise<boolean> {
  report.push('\n## Check 2 · student in institute A reads institute B');
  const tables: [string, string][] = [
    ['students', 'student_profiles'],
    ['students (links)', 'student_memberships'],
    ['attendance (sessions)', 'attendance_sessions'],
    ['attendance (records)', 'attendance_records'],
    ['marks', 'marks'],
    ['marks (results)', 'results'],
    ['fees (structures)', 'fee_structures'],
    ['fees (student fees)', 'student_fees'],
    ['fees (installments)', 'installments'],
    ['fees (payments)', 'payments'],
    ['materials', 'materials'],
    ['leads', 'admission_leads'],
    ['leads (follow-ups)', 'lead_followups'],
    ['notices', 'notices'],
  ];

  await asSuperuser(db);
  const baseline: number[] = [];
  for (const [, t] of tables) baseline.push(await count(db, `public.${t}`, `institute_id = '${INST_B}'`));

  await becomeUser(db, STUDENT_A);
  report.push(
    `\nSigned in as the seeded student Aarav Sharma (\`request.jwt.claim.sub = ${STUDENT_A}\`, role \`authenticated\`, active student membership in ${INST_A}). One query per table:`,
  );
  const probe = (t: string) =>
    `select count(*) filter (where institute_id = '${INST_B}') as rows_from_b, count(*) as rows_visible_at_all from public.${t};`;
  report.sql(probe('student_profiles'));
  const results: (string | number)[][] = [];
  let pass = true;
  for (let i = 0; i < tables.length; i++) {
    const [label, t] = tables[i];
    const res = await db.query(probe(t));
    const row = res.rows[0] as { rows_from_b: number; rows_visible_at_all: number };
    if (row.rows_from_b !== 0) pass = false;
    results.push([label, t, baseline[i], row.rows_from_b, row.rows_visible_at_all]);
  }
  report.push('');
  report.table(['data', 'table', 'rows in B (as superuser)', 'rows from B (as student A)', 'rows visible at all'], results);
  report.push(
    '`rows visible at all` is the whole table through RLS eyes — only the student\u2019s own institute-A rows appear (their own profile, their own batch\u2019s sessions…). Nothing from institute B is ever visible.',
  );
  return pass;
}

// ---------------------------------------------------------------------
// Check 3 · parent reads another family's child
// ---------------------------------------------------------------------

async function check3(db: PGlite): Promise<boolean> {
  report.push('\n## Check 3 · parent reads another family\u2019s child');
  report.push(
    `Two families inside institute A: Parent One (\`${PARENT_1}\`) is linked to Aditya Pandey (\`${STUDENT_A2}\`); Parent Two (\`${PARENT_2}\`) is linked to Ananya Singh (\`${STUDENT_A3}\`). Signed in as Parent One:`,
  );
  await becomeUser(db, PARENT_1);
  report.sql(`select public.my_student_ids();`);
  const mine = await scalar<string[]>(db, `select public.my_student_ids()`);
  report.push(`→ \`${JSON.stringify(mine)}\` (only Aditya, not Ananya)`);

  const tables: [string, string, string][] = [
    ['child record', 'student_profiles', 'id'],
    ['parent links', 'parent_links', 'student_id'],
    ['student memberships', 'student_memberships', 'student_id'],
    ['attendance records', 'attendance_records', 'student_id'],
    ['marks', 'marks', 'student_id'],
    ['results', 'results', 'student_id'],
    ['student fees', 'student_fees', 'student_id'],
    ['installments', 'installments', 'student_id'],
    ['payments', 'payments', 'student_id'],
  ];
  const probe = (t: string, col: string) =>
    `select count(*) filter (where ${col} = '${STUDENT_A3}') as other_family, count(*) as own_family from public.${t};`;
  report.sql(probe('student_profiles', 'id'));
  let pass = mine.length === 1 && mine[0] === STUDENT_A2;
  const rows: (string | number)[][] = [];
  for (const [label, t, col] of tables) {
    const res = await db.query(probe(t, col));
    const row = res.rows[0] as { other_family: number; own_family: number };
    if (row.other_family !== 0) pass = false;
    rows.push([label, t, row.other_family, row.own_family]);
  }
  report.push('');
  report.table(['data', 'table', 'Ananya (other family) rows', 'own family rows'], rows);
  return pass;
}

// ---------------------------------------------------------------------
// Check 4 · pending membership reads nothing
// ---------------------------------------------------------------------

async function check4(db: PGlite): Promise<boolean> {
  report.push('\n## Check 4 · pending membership reads nothing');
  report.push(`Signed in as the seeded pending user Kunal Sinha (\`${PENDING_A}\`, membership status \`pending\` in institute A):`);
  await becomeUser(db, PENDING_A);
  const tables = [
    'institutes',
    'memberships',
    'batches',
    'student_profiles',
    'attendance_sessions',
    'attendance_records',
    'marks',
    'results',
    'fee_structures',
    'student_fees',
    'materials',
    'admission_leads',
    'notices',
    'notifications',
    'interventions',
    'audit_logs',
  ];
  report.sql(`select count(*) as visible from public.student_profiles;  -- one of ${tables.length} tables probed`);
  let pass = true;
  const rows: (string | number)[][] = [];
  for (const t of tables) {
    const n = await count(db, `public.${t}`);
    if (n !== 0 && t !== 'memberships') pass = false;
    rows.push([t, n]);
  }
  report.push('');
  report.table(['table', 'rows visible'], rows);
  const own = await db.query(
    `select institute_id, role, status from public.memberships`,
  );
  report.push(
    `The single visible memberships row is the pending user\u2019s own (\`user_id = auth.uid()\`) — the documented exception in 0008 so the app can show “awaiting approval”: \`${JSON.stringify(own.rows)}\``,
  );
  report.push(
    'Everything else — institutes, batches, students, attendance, marks, fees, materials, leads, notices, notifications, interventions, audit logs — returns zero rows. `auth_institute_ids()` counts ACTIVE memberships only, so no policy that scopes by institute can pass.',
  );
  return pass;
}

// ---------------------------------------------------------------------
// Check 5 · teacher restrictions
// ---------------------------------------------------------------------

async function check5(db: PGlite): Promise<boolean> {
  report.push('\n## Check 5 · teacher cannot change roles, edit fees, manage staff, or approve their own leave');
  report.push(`Signed in as the seeded teacher Rohit Verma (\`${TEACHER_A}\`, class teacher of 10-A, active teacher membership in A):`);
  await becomeUser(db, TEACHER_A);
  let pass = true;
  const results: (string | number)[][] = [];

  const tryIt = async (label: string, sqlText: string, expect: 'zero rows' | 'error' | 'allowed') => {
    const r = await attempt(db, sqlText);
    const ok =
      expect === 'error'
        ? !r.ok
        : expect === 'zero rows'
          ? r.ok && (r.affected ?? 0) === 0
          : r.ok && (r.affected ?? 0) === 1;
    if (!ok) pass = false;
    results.push([
      label,
      expect === 'allowed' ? 'succeeds (allowed)' : `expect ${expect}`,
      ok ? 'blocked' : '**NOT BLOCKED**',
      r.ok ? `${r.affected ?? '?'} rows` : `SQLSTATE ${r.code}`,
      r.ok ? '' : r.message.slice(0, 90),
    ]);
    return r;
  };

  report.push('\n(a) changing a role:');
  report.sql(`update public.memberships set role = 'admin'
where institute_id = '${INST_A}' and user_id = '${TEACHER_A2}';`);
  await tryIt('promote another teacher to admin', `update public.memberships set role = 'admin' where institute_id = '${INST_A}' and user_id = '${TEACHER_A2}'`, 'zero rows');
  await tryIt('promote self to owner', `update public.memberships set role = 'owner' where institute_id = '${INST_A}' and user_id = '${TEACHER_A}'`, 'zero rows');
  report.sql(`insert into public.memberships (id, institute_id, user_id, role, status, permissions)
values ('${fid('a006')}', '${INST_A}', '${TEACHER_A}', 'owner', 'active', '{}');`);
  await tryIt('insert a new owner membership', `insert into public.memberships (id, institute_id, user_id, role, status, permissions) values ('${fid('a006')}', '${INST_A}', '${TEACHER_A}', 'owner', 'active', '{}')`, 'error');

  report.push('\n(b) editing fee structures:');
  report.sql(`update public.fee_structures set total_amount = 1 where institute_id = '${INST_A}';`);
  await tryIt('rewrite fee totals', `update public.fee_structures set total_amount = 1 where institute_id = '${INST_A}'`, 'zero rows');
  await tryIt(
    'insert a fee structure',
    `insert into public.fee_structures (id, institute_id, name, academic_year, total_amount) values ('${fid('a007')}', '${INST_A}', 'Hacked', '2026-27', 1)`,
    'error',
  );
  report.sql(`select public.save_fee_plan('${INST_A}', '{"batchId":"${BATCH_A}","batchIds":["${BATCH_A}"],"totalAmount":1,"schedule":[{"amount":1}]}'::jsonb);`);
  await tryIt(
    'call save_fee_plan RPC',
    `select public.save_fee_plan('${INST_A}', '{"batchId":"${BATCH_A}","batchIds":["${BATCH_A}"],"totalAmount":1,"schedule":[{"amount":1}]}'::jsonb)`,
    'error',
  );

  report.push('\n(c) managing staff:');
  await tryIt(
    'insert a teacher profile',
    `insert into public.teacher_profiles (id, institute_id, user_id, full_name) values ('${fid('a008')}', '${INST_A}', '${TEACHER_A}', 'Fake Teacher')`,
    'error',
  );
  await tryIt(
    'edit a staff record',
    `update public.staff_records set designation = 'Director' where institute_id = '${INST_A}'`,
    'zero rows',
  );
  await tryIt(
    'insert a staff record',
    `insert into public.staff_records (id, institute_id, user_id, employee_code, designation) values ('${fid('a009')}', '${INST_A}', '${TEACHER_A}', 'X-1', 'Director')`,
    'error',
  );

  report.push('\n(d) approving their own leave:');
  report.sql(`update public.leave_requests set status = 'approved', reviewed_by = '${TEACHER_A}', reviewed_at = now()
where user_id = '${TEACHER_A}';`);
  await tryIt('approve own pending leave', `update public.leave_requests set status = 'approved', reviewed_by = '${TEACHER_A}', reviewed_at = now() where user_id = '${TEACHER_A}'`, 'error');
  await tryIt('approve a colleague\u2019s leave', `update public.leave_requests set status = 'approved', reviewed_by = '${TEACHER_A}', reviewed_at = now() where user_id = '${TEACHER_A2}'`, 'zero rows');
  await tryIt('cancel own pending leave (allowed)', `update public.leave_requests set status = 'cancelled' where user_id = '${TEACHER_A}'`, 'allowed');

  report.push('');
  report.table(['attempt', 'expected', 'result', 'outcome', 'error'], results);
  return pass;
}

// ---------------------------------------------------------------------
// Check 6 · user cannot update their own membership role
// ---------------------------------------------------------------------

async function check6(db: PGlite): Promise<boolean> {
  report.push('\n## Check 6 · a user cannot update their own membership role');
  await becomeUser(db, STUDENT_A);
  report.push(`Signed in as the seeded student Aarav (\`${STUDENT_A}\`):`);
  report.sql(`update public.memberships set role = 'owner'  where institute_id = '${INST_A}' and user_id = '${STUDENT_A}';`);
  const r1 = await attempt(
    db,
    `update public.memberships set role = 'owner' where institute_id = '${INST_A}' and user_id = '${STUDENT_A}'`,
  );
  const r2 = await attempt(
    db,
    `update public.memberships set role = 'teacher' where institute_id = '${INST_A}' and user_id = '${STUDENT_A}'`,
  );
  const r3 = await attempt(
    db,
    `update public.memberships set status = 'suspended' where institute_id = '${INST_A}' and user_id = '${STUDENT_A}'`,
  );
  report.push(
    `role→owner: ${r1.ok ? r1.affected + ' rows' : 'SQLSTATE ' + r1.code} · role→teacher: ${r2.ok ? r2.affected + ' rows' : 'SQLSTATE ' + r2.code} · status→suspended: ${r3.ok ? r3.affected + ' rows' : 'SQLSTATE ' + r3.code}`,
  );

  report.push(
    `\nThe policy layer blocks a plain member entirely (0 rows — \`memberships_update\` needs the \`members\` permission). An **admin who holds that permission** passes the policy, so the \`membership_guard()\` trigger is the second layer. Signed in as the admin \`${ADMIN_1}\` (permissions \`{members}\`):`,
  );
  await becomeUser(db, ADMIN_1);
  report.sql(`update public.memberships set role = 'owner' where id = '${ADMIN_1}';`);
  const r4 = await attempt(db, `update public.memberships set role = 'owner' where id = '${ADMIN_1}'`);
  const r5 = await attempt(db, `update public.memberships set permissions = '{members,fees}' where id = '${ADMIN_1}'`);
  report.push(`admin self-promotion to owner: ${r4.ok ? '**NOT BLOCKED**' : 'SQLSTATE ' + r4.code + ' — ' + r4.message}`);
  report.push(`admin self-grant of extra permissions: ${r5.ok ? '**NOT BLOCKED**' : 'SQLSTATE ' + r5.code + ' — ' + r5.message}`);
  report.push(`select role, permissions from public.memberships where id = '${ADMIN_1}';`);
  const after = await db.query(`select role, permissions from public.memberships where id = '${ADMIN_1}'`);
  report.push(`→ \`${JSON.stringify(after.rows)}\` (unchanged)`);

  return (
    !r1.ok || (r1.affected ?? 0) === 0
      ? (r1.ok ? (r1.affected ?? 1) === 0 : true) && (r2.ok ? (r2.affected ?? 1) === 0 : true) && (r3.ok ? (r3.affected ?? 1) === 0 : true) && !r4.ok && !r5.ok
      : false
  );
}

// ---------------------------------------------------------------------
// Check 9 · storage buckets
// ---------------------------------------------------------------------

async function check9(db: PGlite): Promise<boolean> {
  report.push('\n## Check 9 · storage buckets — avatars public, everything else private + short-TTL signed URLs');
  await asSuperuser(db); // bucket listing is a service-role operation on real Supabase too
  const buckets = await db.query('select id, public, file_size_limit, allowed_mime_types from storage.buckets order by id');
  report.sql(`select id, public, file_size_limit, allowed_mime_types from storage.buckets order by id;`);
  report.push('→ ' + JSON.stringify(buckets.rows));
  const pols = await db.query(`select policyname, cmd, roles, qual from pg_policies where schemaname = 'storage' order by policyname`);
  report.sql(`select policyname, cmd, roles from pg_policies where schemaname = 'storage';`);
  report.table(
    ['policy', 'cmd', 'roles'],
    (pols.rows as { policyname: string; cmd: string; roles: string }[]).map((p) => [p.policyname, p.cmd, p.roles]),
  );
  const avatarsPublic = (buckets.rows as { id: string; public: boolean }[]).find((b) => b.id === 'avatars')?.public === true;
  const othersPrivate = (buckets.rows as { id: string; public: boolean }[]).filter((b) => b.id !== 'avatars').every((b) => b.public === false);
  report.push(
    `avatars bucket public-read: ${avatarsPublic ? 'yes' : '**no**'} · every other bucket private: ${othersPrivate ? 'yes' : '**no**'}.`,
  );

  const adapter = fs.readFileSync(path.join(ROOT, 'src', 'adapters', 'supabase', 'storage.adapter.ts'), 'utf8');
  const ttl = adapter.match(/expiresInSeconds(?:\s*:\s*[a-z]+\s*=\s*|\s*=\s*)(\d+)/)?.[1];
  report.push(
    `Signed-URL TTL: \`src/adapters/supabase/storage.adapter.ts\` default \`expiresInSeconds = ${ttl ?? 'not found'}\` seconds (${ttl ? Math.round(Number(ttl) / 60) + ' minutes' : '?'}).`,
  );
  return avatarsPublic && othersPrivate && !!ttl && Number(ttl) <= 900;
}

// ---------------------------------------------------------------------
// Check 12 · rate limiting (DB half; client half is in the file checks + transcript)
// ---------------------------------------------------------------------

async function check12(db: PGlite): Promise<boolean> {
  report.push('\n## Check 12 · rate limiting on auth and on the public join-by-code path');
  let pass = true;

  report.push('\n(a) join-by-code enumeration — there is no public read of institute rows:');
  await becomeUser(db, RL_LOOKUP);
  report.sql(`select count(*) from public.institutes where code = 'RIVAL-MUM';
select count(*) from public.institutes;
select count(*) from public.institutes where name ilike '%rival%';`);
  const c1 = await count(db, 'public.institutes', `code = 'RIVAL-MUM'`);
  const c2 = await count(db, 'public.institutes');
  const c3 = await count(db, 'public.institutes', `name ilike '%rival%'`);
  report.push(`→ by code: ${c1} · all institutes: ${c2} · by name search: ${c3} (a member sees only their own; a non-member sees nothing — the read fails closed, so there is no code-enumeration oracle)`);
  if (c1 !== 0 || c2 !== 0 || c3 !== 0) pass = false;
  await becomeUser(db, STUDENT_A);
  const member = await count(db, 'public.institutes', `code = 'SUNRISE-PAT'`);
  report.push(`positive control, signed in as the student: own institute by code \`SUNRISE-PAT\` → ${member} row.`);

  report.push('\n(b) the one public write — a self-serve pending join request — is rate-limited in the database:');
  await becomeUser(db, RL_USER);
  report.sql(`insert into public.memberships (id, institute_id, user_id, role, status, permissions)
values ('<id>', '<institute n>', '${RL_USER}', 'student', 'pending', '{}');  -- × 6`);
  const rl: (string | number)[][] = [];
  for (let i = 1; i <= 6; i++) {
    const r = await attempt(
      db,
      `insert into public.memberships (id, institute_id, user_id, role, status, permissions) values ('${rid(String(100 + i))}', '${iid(String(i))}', '${RL_USER}', 'student', 'pending', '{}')`,
    );
    rl.push([`join request #${i}`, r.ok ? 'accepted' : `SQLSTATE ${r.code}`, r.ok ? '' : r.message.slice(0, 80)]);
    if (i <= 5 && !r.ok) pass = false;
    if (i === 6 && r.ok) pass = false;
  }
  report.table(['attempt', 'outcome', 'error'], rl);

  await asSuperuser(db);
  const svc = await attempt(
    db,
    `insert into public.memberships (id, institute_id, user_id, role, status, permissions) values ('${rid('200')}', '${iid('6')}', '${RL_USER}', 'student', 'active', '{}')`,
  );
  report.push(
    `service-role / staff-created rows bypass the limiter (actor is null or the row is not a self-serve pending request): ${svc.ok ? 'accepted' : 'SQLSTATE ' + svc.code}.`,
  );
  report.push(
    'Auth rate limiting: sign-in / sign-up / OTP / password-reset are Supabase Auth endpoints, rate-limited by the platform (per-IP and per-factor limits configurable in the dashboard); the client additionally throttles its own auth calls (`src/adapters/supabase/auth-rate-limit.ts`, 5 per 60 s) — see the unit evidence in the transcript.',
  );
  return pass;
}

// ---------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------

async function main(): Promise<void> {
  report.push('# Security audit — evidence');
  report.push(`Generated: ${new Date().toISOString()}`);
  report.push(
    'Harness: the repository\u2019s real `supabase/migrations/*.sql` and `supabase/seed.sql` executed against real Postgres (PGlite) with a Supabase shim (auth schema + `auth.uid()` reading `request.jwt.claim.sub`, `anon` / `authenticated` / `service_role` roles, storage schema). Every check signs in as a real identity and runs the exact SQL shown.',
  );

  const db = await createHarness();
  const version = await scalar<string>(db, 'select version()');
  report.push(`Postgres: ${version.split(' (')[0]}`);

  const outcomes: MigrationOutcome[] = await applyMigrations(db, report);
  const chainComplete = outcomes.length > 0 && outcomes.every((o) => o.ok);
  const files = fs.readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith('.sql')).sort();

  if (!chainComplete) {
    report.push('\n**The migration chain does not complete on a clean database — the checks below cannot run against the as-received schema.** Fix the failing migrations and re-run.');
    fileChecks();
    report.push('\n---\n');
    await db.close();
    return;
  }

  report.push(`\nAll ${files.length} migrations applied. Seeding \`supabase/seed.sql\` (Sunrise Coaching Classes, 1 owner · 5 teachers · 12 students · pending users) and adding fixtures: a second institute **Rival Classes** with its own students, attendance, marks, fees, materials and leads, two families inside Sunrise, one admin with the \`members\` permission, and rate-limit probe institutes.`);
  await applySeed(db);
  await installFixtures(db);

  const results: [string, boolean][] = [];
  results.push(['1 · RLS + policies per table', await check1(db)]);
  results.push(['2 · cross-tenant reads (student A → B)', await check2(db)]);
  results.push(['3 · parent vs another family', await check3(db)]);
  results.push(['4 · pending member reads nothing', await check4(db)]);
  results.push(['5 · teacher restrictions', await check5(db)]);
  results.push(['6 · self-membership role change', await check6(db)]);
  results.push(['9 · storage buckets', await check9(db)]);
  results.push(['12 · rate limiting (database half)', await check12(db)]);

  fileChecks();

  report.push('\n---\n');
  report.push('## Database-side verdict');
  report.table(
    ['check', 'result'],
    results.map(([c, ok]) => [c, ok ? 'PASS' : '**FAIL**']),
  );

  await asSuperuser(db);
  await db.close();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
