import assert from 'node:assert/strict';

import { subscriptionRepo } from '../src/backends/memory/billing';
import { createDb } from '../src/backends/memory/db';
import { exportRepo } from '../src/backends/memory/exports';
import { studentRepo } from '../src/backends/memory/people';
import { seed, SEED } from '../src/backends/memory/seed';
import * as D from '../src/backends/memory/defaults';
import { invitationRepo, membershipRepo } from '../src/backends/memory/tenant';
import { isBackendError } from '../src/core/contracts/errors';
import { isPlanLimit } from '../src/features/students/types';
import { usageLine } from '../src/features/settings/model';
import { codeFromJoinUrl, tokenFromJoinUrl } from '../src/lib/join-link';

let passed = 0;
const check = async (name: string, fn: () => Promise<void>) => {
  await fn();
  passed += 1;
  console.log(`  ✓ ${name}`);
};

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;

function fresh(userId: string | null = SEED.ownerId) {
  const db = createDb();
  seed(db);
  db.session.userId = userId;
  return db;
}

async function main() {
  await check('usage line matches the 240 of 300 copy', async () => {
    assert.equal(usageLine(240, 300), '240 of 300 students used');
  });

  await check('the 301st student on a 300 cap is blocked with an upgrade path', async () => {
    const db = fresh();
    const i = SEED.instituteId;
    const sub = db.subscriptions.all(i)[0];
    db.plans.update(i, sub.planId, { maxStudents: 300 });
    const have = db.students.all(i).filter((row) => row.status === 'active').length;
    for (let n = have; n < 300; n += 1) {
      db.students.insert(i, { ...D.student(), fullName: `Cap Student ${n}` });
    }
    assert.equal(db.students.all(i).filter((row) => row.status === 'active').length, 300);
    try {
      await studentRepo(db).create(i, { fullName: 'Student 301' });
      assert.fail('expected plan_limit');
    } catch (error) {
      assert.ok(isBackendError(error));
      assert.equal(error.message, 'plan_limit');
      assert.equal(error.code, 'CONFLICT');
      assert.equal(error.details?.cap, 300);
      assert.equal(error.details?.used, 300);
      assert.ok(isPlanLimit(error));
    }
  });

  await check('inviting a teacher produces a working join link', async () => {
    const db = fresh();
    const i = SEED.instituteId;
    const link = await invitationRepo(db).createLink(i, { role: 'teacher', fullName: 'New Teacher' });
    assert.equal(link.invitation.role, 'teacher');
    assert.equal(link.invitation.status, 'pending');
    assert.ok(db.invitations.get(i, link.invitation.id));
    const token = tokenFromJoinUrl(link.joinUrl);
    const code = codeFromJoinUrl(link.joinUrl);
    assert.equal(code, 'SUNRISE-PAT');
    assert.equal(token, link.invitation.token);
    const guest = sid(8800);
    db.profiles.set(guest, { ...D.profile(), id: guest, userId: guest, fullName: 'Guest Teacher', createdAt: link.invitation.createdAt, updatedAt: link.invitation.createdAt });
    db.session.userId = guest;
    const membership = await invitationRepo(db).accept(i, token as string);
    assert.equal(membership.role, 'teacher');
    assert.equal(membership.status, 'active');
    assert.equal(membership.userId, guest);
  });

  await check('changing a role is impossible for a non-owner', async () => {
    const db = fresh(sid(3));
    const i = SEED.instituteId;
    const target = db.memberships.find(i, { userId: sid(4) });
    assert.ok(target);
    try {
      await membershipRepo(db).setRole(i, target.id, 'admin');
      assert.fail('expected FORBIDDEN');
    } catch (error) {
      assert.ok(isBackendError(error));
      assert.equal(error.code, 'FORBIDDEN');
    }
    assert.equal(db.memberships.get(i, target.id).role, 'teacher');
    db.session.userId = SEED.ownerId;
    const updated = await membershipRepo(db).setRole(i, target.id, 'admin');
    assert.equal(updated.role, 'admin');
  });

  await check('the full JSON export can be re-imported', async () => {
    const db = fresh();
    const i = SEED.instituteId;
    const before = db.students.all(i).length;
    const job = await exportRepo(db).start(i, { kind: 'full', format: 'json' });
    const payload = await exportRepo(db).content(i, job.id);
    assert.ok(payload.includes('Aarav Sharma'));
    await studentRepo(db).create(i, { fullName: 'Temporary Student' });
    assert.equal(db.students.all(i).length, before + 1);
    const restored = await exportRepo(db).importJson(i, payload);
    assert.equal(restored.students, before);
    assert.equal(db.students.all(i).some((row) => row.fullName === 'Temporary Student'), false);
    assert.equal(db.students.all(i).some((row) => row.fullName === 'Aarav Sharma'), true);
  });

  await check('a lapsed plan keeps institute data and restricts invites', async () => {
    const db = fresh();
    const i = SEED.instituteId;
    const before = db.students.all(i).length;
    const lapsed = await subscriptionRepo(db).lapse(i);
    assert.equal(lapsed.retained, true);
    assert.equal(lapsed.students, before);
    assert.equal(db.students.all(i).length, before);
    const access = await subscriptionRepo(db).access(i);
    assert.equal(access.dataRetained, true);
    assert.equal(access.restricted, true);
    try {
      await invitationRepo(db).createLink(i, { role: 'teacher' });
      assert.fail('expected subscription_restricted');
    } catch (error) {
      assert.ok(isBackendError(error));
      assert.equal(error.message, 'subscription_restricted');
      assert.equal(error.details?.retained, true);
    }
    assert.equal(db.students.all(i).length, before);
  });

  console.log(`\n${passed} settings checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
