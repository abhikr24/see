import type {
  AdmissionLead,
  AdmissionsPipeline,
  Attachment,
  AttachmentOwner,
  AuditLog,
  BillingCycle,
  ConvertLeadInput,
  ConvertLeadResult,
  DateRange,
  ExportFormat,
  ExportJob,
  ExportKind,
  FunnelStage,
  ID,
  InstituteOverview,
  LeadDetail,
  LeadFollowup,
  LeadStage,
  NewEntity,
  OwnerDashboard,
  Plan,
  Subscription,
  TrendPoint,
  UsageRecord,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo } from './common';

export type AddFollowupInput = NewEntity<LeadFollowup, 'leadId'> & {
  nextFollowupNote?: string | null;
};

export interface LeadRepo extends CrudRepo<AdmissionLead, 'studentName'> {
  pipeline(instituteId: ID): Promise<AdmissionsPipeline>;
  detail(instituteId: ID, leadId: ID): Promise<LeadDetail>;
  moveStage(instituteId: ID, id: ID, stage: LeadStage, lostReason?: string | null): Promise<AdmissionLead>;
  listFollowups(instituteId: ID, leadId: ID): Promise<LeadFollowup[]>;
  addFollowup(instituteId: ID, input: AddFollowupInput): Promise<LeadFollowup>;
  /** Single atomic conversion: updates lead, creates student, guardian, batch membership & fee plan. */
  convert(instituteId: ID, input: ConvertLeadInput): Promise<ConvertLeadResult>;
}

export interface AnalyticsRepo {
  overview(instituteId: ID): Promise<InstituteOverview>;
  /** The owner's home screen in one call. Every figure is computed here, never by the UI. */
  dashboard(instituteId: ID): Promise<OwnerDashboard>;
  /** Attendance % per day. */
  attendanceTrend(instituteId: ID, range: DateRange): Promise<TrendPoint[]>;
  /** Money collected per day. */
  feeCollection(instituteId: ID, range: DateRange): Promise<TrendPoint[]>;
  leadFunnel(instituteId: ID): Promise<FunnelStage[]>;
  listAuditLogs(instituteId: ID, query?: ListQuery<AuditLog>): Promise<Page<AuditLog>>;
  recordAudit(instituteId: ID, input: NewEntity<AuditLog, 'action'>): Promise<AuditLog>;
}

export interface SubscriptionRepo {
  /** null when the institute has never subscribed. */
  getCurrent(instituteId: ID): Promise<Subscription | null>;
  listPlans(instituteId: ID): Promise<Plan[]>;
  changePlan(instituteId: ID, planId: ID, billingCycle: BillingCycle): Promise<Subscription>;
  cancel(instituteId: ID): Promise<Subscription>;
  listUsage(instituteId: ID): Promise<UsageRecord[]>;
}

export interface ExportRequest {
  kind: ExportKind;
  format: ExportFormat;
  /** Narrow the export, e.g. `{ batchId, from, to }`. Keys are model field names. */
  filters?: Record<string, string | number | boolean | null>;
}

export interface ExportRepo {
  list(instituteId: ID, query?: ListQuery<ExportJob>): Promise<Page<ExportJob>>;
  /** Starts an export. Poll `get` until the job is completed or failed. */
  start(instituteId: ID, request: ExportRequest): Promise<ExportJob>;
  get(instituteId: ID, jobId: ID): Promise<ExportJob>;
}

export interface UploadInput {
  ownerType: AttachmentOwner;
  ownerId: ID;
  fileName: string;
  /** Local file to upload: a `file://` or `blob:` URI from a picker. */
  uri: string;
  mimeType?: string | null;
  sizeBytes?: number | null;
  batchId?: ID | null;
  studentId?: ID | null;
}

/** File storage. The UI never builds a bucket path or a public URL itself. */
export interface StoragePort {
  upload(instituteId: ID, input: UploadInput): Promise<Attachment>;
  listAttachments(instituteId: ID, ownerType: AttachmentOwner, ownerId: ID): Promise<Attachment[]>;
  /** A URL the app can open or download, valid for `expiresInSeconds` (default 1 hour). */
  getUrl(instituteId: ID, storagePath: string, expiresInSeconds?: number): Promise<string>;
  remove(instituteId: ID, attachmentId: ID): Promise<void>;
}
