const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8129);

const BASE = 'http://localhost:8129';
const tab = (page, i) => page.locator('[role="tab"]').nth(i);
const step = (msg) => console.log(`PASS: ${msg}`);

async function signIn(page) {
  await page.goto(`${BASE}/`);
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
  await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  const box = page.locator('input:visible').first();
  await box.click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await page.locator('[role="tab"]').first().waitFor({ state: 'visible', timeout: 30000 });
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] }).catch((err) => {
    server.closeAllConnections?.();
    server.close();
    throw err;
  });
  const page = await browser.newPage({ viewport: { width: 400, height: 844 } });
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(e.message));

  try {
    await signIn(page);
    step('signed in as owner');

    // Navigate More -> Admissions
    await tab(page, 4).click();
    await page.getByText('Admissions', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    await page.getByText('Admissions', { exact: true }).click();

    await page.getByText('This month', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    await page.getByText('Aryan Sinha', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    for (const label of ['New', 'Following up', 'Demo booked', 'Converted', 'Lost']) {
      await page.getByText(label, { exact: true }).first().waitFor({ state: 'visible', timeout: 5000 });
    }
    step('admissions list rendered summary strip, 5 segments, and seeded New enquiry');

    // Create a new enquiry
    await page.getByRole('button', { name: 'New enquiry' }).click();
    await page.getByText('Student name', { exact: true }).waitFor({ state: 'visible', timeout: 10000 });
    await page.getByPlaceholder('e.g. Rohan Verma').fill('Rohan Verma');
    await page.getByPlaceholder('10-digit mobile').fill('9876543210');
    await page.getByText('Instagram', { exact: true }).click();
    await page.getByRole('button', { name: 'Save enquiry' }).click();

    await page.getByText('Rohan Verma', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    step('adding an enquiry shows it in the New column');

    // Open Rohan Verma detail and log a follow-up today
    await page.getByText('Rohan Verma', { exact: true }).click();
    await page.getByText('Instagram', { exact: true }).waitFor({ state: 'visible', timeout: 10000 });
    await page.getByRole('button', { name: 'Log follow-up' }).click();
    await page.getByPlaceholder('Spoke with parent, shared batch timings…').fill('Called mother about Class 10 Science.');
    await page.getByRole('button', { name: 'Save follow-up' }).click();

    await page.getByText('Called mother about Class 10 Science.', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    step('follow-up logged today appears on the lead timeline');

    // Convert to student
    await page.getByRole('button', { name: 'Convert to student' }).click();
    await page.getByRole('button', { name: 'Admit student' }).waitFor({ state: 'visible', timeout: 15000 });
    await page.getByRole('button', { name: 'Admit student' }).click();
    await page.getByText('Converted to student', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    step('converted lead in one flow');

    // Return to Admissions list and verify conversion % matches 2 / 9 = 22%
    await page.getByRole('button', { name: 'Back to admissions' }).click();
    await page.getByText('22%', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    step('conversion percentage on list matches underlying stages (2/9 = 22%)');

    // Navigate to Students tab and verify Rohan Verma appears in Students list
    await tab(page, 1).click();
    await page.getByText('Rohan Verma', { exact: true }).waitFor({ state: 'visible', timeout: 15000 });
    step('converted student appears in the real Students list');

    assert.equal(pageErrors.length, 0, `Page errors: ${pageErrors.join('; ')}`);
    console.log('\nBrowser admissions verification passed (0 runtime errors)');
  } finally {
    await browser.close().catch(() => {});
    server.closeAllConnections?.();
    server.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
