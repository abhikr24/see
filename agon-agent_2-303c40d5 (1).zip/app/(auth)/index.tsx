import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export default function AuthPlaceholderScreen() {
  return (
    <Screen title="Authentication" subtitle="Route group: /(auth)">
      <Card flat>
        <Text variant="label" c={C.accent}>PROMPT P4</Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          Built in Prompt P4 (Auth screens)
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          Sign-in, OTP verification, and account onboarding screens will be added here by Prompt P4.
        </Text>
      </Card>
    </Screen>
  );
}
