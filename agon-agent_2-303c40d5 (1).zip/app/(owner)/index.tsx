import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export default function OwnerPlaceholderScreen() {
  return (
    <Screen title="Owner Console" subtitle="Route group: /(owner)">
      <Card flat>
        <Text variant="label" c={C.accent}>PROMPT P6–P12</Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          Built in Prompts P6–P12 (Owner home, students, batches, attendance, exams & fees)
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          Institute owner dashboard and management workflows will be built here starting in Prompt P6.
        </Text>
      </Card>
    </Screen>
  );
}
