import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export default function ParentPlaceholderScreen() {
  return (
    <Screen title="Parent Overview" subtitle="Route group: /(parent)">
      <Card flat>
        <Text variant="label" c={C.accent}>PROMPT P17</Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          Built in Prompt P17 (Parent screens)
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          Child attendance tracking, fee installments, and institute notices will be built here by Prompt P17.
        </Text>
      </Card>
    </Screen>
  );
}
