import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export default function PendingPlaceholderScreen() {
  return (
    <Screen title="Membership Pending" subtitle="Route group: /(pending)">
      <Card flat>
        <Text variant="label" c={C.accent}>PROMPT P5</Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          Built in Prompt P5 (Register / join / approvals)
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          The waiting room screen for pending institute memberships will be built here by Prompt P5.
        </Text>
      </Card>
    </Screen>
  );
}
