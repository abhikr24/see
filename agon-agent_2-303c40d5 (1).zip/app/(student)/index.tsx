import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export default function StudentPlaceholderScreen() {
  return (
    <Screen title="Student Portal" subtitle="Route group: /(student)">
      <Card flat>
        <Text variant="label" c={C.accent}>PROMPT P15</Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          Built in Prompt P15 (Student screens)
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          Student timetable, attendance summary, study materials, and test results will be built here by Prompt P15.
        </Text>
      </Card>
    </Screen>
  );
}
