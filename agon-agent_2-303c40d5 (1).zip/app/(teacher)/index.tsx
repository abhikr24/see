import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

export default function TeacherPlaceholderScreen() {
  return (
    <Screen title="Teacher Workspace" subtitle="Route group: /(teacher)">
      <Card flat>
        <Text variant="label" c={C.accent}>PROMPT P13</Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          Built in Prompt P13 (Teacher screens)
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          Teacher schedule, class attendance, homework, and marks entry screens will be built here by Prompt P13.
        </Text>
      </Card>
    </Screen>
  );
}
