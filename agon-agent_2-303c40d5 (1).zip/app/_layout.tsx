import '../global.css';
import React from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { DEFAULT_BACKEND, DEFAULT_INSTITUTE_ID, createBackends } from '../src/backends';
import { BackendProvider } from '../src/core/backend';

const backends = createBackends();

export default function RootLayout() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <BackendProvider
          backends={backends}
          initial={DEFAULT_BACKEND}
          instituteId={DEFAULT_INSTITUTE_ID}
        >
          <Stack screenOptions={{ headerShown: false }} />
          <StatusBar style="dark" />
        </BackendProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
