import React from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { useBackend, useInstitute } from '../src/core/backend';
import { PORT_KEYS } from '../src/core/contracts/ports';
import { MONO, useTheme } from '../src/lib/theme';

/** Dev index screen: shows what the app is connected to and links to the two dev screens. */
export default function HomeScreen() {
  const theme = useTheme();
  const router = useRouter();
  const { backend } = useBackend();
  const institute = useInstitute();
  const card = [styles.card, { backgroundColor: theme.surface, borderColor: theme.border }];

  return (
    <ScrollView style={{ backgroundColor: theme.background }} contentContainerStyle={styles.content}>
      <Text style={[styles.section, { color: theme.muted }]}>Connected to</Text>
      <View style={card}>
        {institute.data ? (
          <>
            <Text style={[styles.title, { color: theme.text }]}>{institute.data.name}</Text>
            <Text style={[styles.mono, { color: theme.muted }]}>{institute.data.code}</Text>
          </>
        ) : institute.error ? (
          <>
            <Text style={[styles.title, { color: theme.failText }]}>Could not load the institute</Text>
            <Text style={[styles.body, { color: theme.muted }]}>
              {institute.error.message} ({institute.error.code})
            </Text>
            <Pressable accessibilityRole="button" onPress={() => void institute.refetch()} style={styles.retry}>
              <Text style={[styles.retryText, { color: theme.primary }]}>Try again</Text>
            </Pressable>
          </>
        ) : (
          <ActivityIndicator color={theme.primary} accessibilityLabel="Loading institute" />
        )}
        <View style={[styles.divider, { backgroundColor: theme.border }]} />
        <Text style={[styles.body, { color: theme.muted }]}>
          Backend <Text style={[styles.mono, { color: theme.text }]}>{backend.name}</Text> · {PORT_KEYS.length} ports
        </Text>
      </View>

      <Text style={[styles.section, { color: theme.muted }]}>Developer tools</Text>
      <Pressable
        accessibilityRole="button"
        onPress={() => router.push('/dev/components' as never)}
        style={({ pressed }) => [card, styles.link, { opacity: pressed ? 0.7 : 1 }]}
      >
        <Ionicons name="color-palette-outline" size={24} color={theme.primary} />
        <View style={styles.linkText}>
          <Text style={[styles.title, { color: theme.text }]}>Design system</Text>
          <Text style={[styles.body, { color: theme.muted }]}>
            Inspect all 35 UI primitives in every variant and state at /dev/components.
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={theme.muted} />
      </Pressable>

      <Pressable
        accessibilityRole="button"
        onPress={() => router.push('/dev/contract-check' as never)}
        style={({ pressed }) => [card, styles.link, { opacity: pressed ? 0.7 : 1 }]}
      >
        <Ionicons name="shield-checkmark-outline" size={24} color={theme.primary} />
        <View style={styles.linkText}>
          <Text style={[styles.title, { color: theme.text }]}>Contract check</Text>
          <Text style={[styles.body, { color: theme.muted }]}>
            Call every port and see pass or fail with the error code at /dev/contract-check.
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={theme.muted} />
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, gap: 8, width: '100%', maxWidth: 720, alignSelf: 'center' },
  section: { fontSize: 13, fontWeight: '600', marginTop: 16 },
  card: { borderWidth: 1, borderRadius: 12, padding: 16, gap: 4 },
  title: { fontSize: 16, fontWeight: '700' },
  body: { fontSize: 14, lineHeight: 20 },
  mono: { fontSize: 13, fontFamily: MONO },
  divider: { height: 1, marginVertical: 8 },
  retry: { minHeight: 44, justifyContent: 'center', alignSelf: 'flex-start' },
  retryText: { fontSize: 14, fontWeight: '700' },
  link: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 72 },
  linkText: { flex: 1, gap: 4 },
});
