# Work done

## 2026-11-12 · Convert App Shell from React Navigation to `expo-router`

Converted the application shell to `expo-router` (`"main": "expo-router/entry"`) while keeping the design system, contracts, adapters, and database unchanged.

**Changed**
- `package.json` & `app.json` – added `expo-router` and `expo-linking`, set `"main": "expo-router/entry"`, and added `"expo-router"` to `app.json` plugins.
- `app/_layout.tsx` – created root layout with `GestureHandlerRootView` → `SafeAreaProvider` → `BackendProvider` → `Stack` (`headerShown: false`).
- `app/index.tsx` – dev index screen linking to `/dev/components` and `/dev/contract-check` via `expo-router`.
- `app/(auth)/index.tsx`, `app/(pending)/index.tsx`, `app/(owner)/index.tsx`, `app/(teacher)/index.tsx`, `app/(student)/index.tsx`, `app/(parent)/index.tsx` – placeholder route group screens using `Screen` + `Card` noting the prompt that builds each.
- Deleted `App.tsx`, `index.ts`, and `src/core/ui/theme.ts`; pointed `app/dev/contract-check.tsx` at `src/lib/theme.ts` and removed `darkPrimary` (`#818CF8`).

**Verified**
- `npm run typecheck` – zero errors.
- `grep -rn "@react-navigation" app/ src/` – zero matches.
- `grep -rn "818CF8" src` – zero matches.
- Single theme file remains at `src/lib/theme.ts`.

## 2026-11-12 · Complete 35-component Design System & `/dev/components` QA Gallery

Completed the GuruFlow UI primitive library under `src/components/ui/` so no future feature screen needs to invent a new component.

**Preserved & Refined (19 existing primitives)**
- `Text`, `Button`, `Input`, `Card`, `Chip`, `Badge`, `Avatar`, `IconBox`, `Divider`, `ProgressBar`, `Ring`, `Sheet` (upgraded to `@gorhom/bottom-sheet`), `Screen`, `GradientHeader`, `OverlapCard`, `TabBar`, `Skeleton` (`ListSkeleton`), `EmptyState` (wired to `EmptyArt`), `ErrorState`.

**Added (16 new primitives in `src/components/ui/`)**
- `StatCard` – label + big tabular numeral + optional delta badge and trend colour (`up`, `down`, `warning`, `neutral`).
- `ListRow` – 44pt leading slot, title, subtitle, right slot, optional chevron, and 68pt row rhythm.
- `SegmentedControl` – pill track, animated Reanimated thumb, 2–4 options with optional counts.
- `DateField` – `DD/MM/YYYY` date field opening a `@gorhom/bottom-sheet` calendar sheet (`react-native-calendars`).
- `Select` – labelled dropdown opening a searchable `@gorhom/bottom-sheet` with `SearchBar`.
- `Stepper` – `−/+` numeric stepper with `min`/`max`, step increment, and Indian-grouped `₹` or custom suffix.
- `Table` – sticky header row, 1px hairline data rows, right-aligned tabular numeric columns, and optional summary footer row.
- `Heatmap` – 7-column month grid of rounded squares with `attendance` and `intensity` variants plus legend.
- `AvatarStack` – overlapping circular avatars with surface ring border and tabular `+N` overflow chip.
- `Tabs` – `primary` (navy) and `accent` (saffron) underline tabs with optional counts for detail screens.
- `SearchBar` – search input with clear button, loading indicator, and configurable debounce callback.
- `Toast` – `success`, `error`, and `info` notifications with auto-dismiss timer and configurable bottom offset.
- `ConfirmDialog` – destructive action confirmation modal/inline card with optional typed confirmation phrase (`confirmText`).
- `TrendLine` – flat, gridline-free thin line chart (`react-native-gifted-charts`) with the last data point highlighted in saffron (`C.accent`).
- `BarChart` – flat, thin vertical bar chart (`react-native-gifted-charts`) with one bar highlighted in saffron (`C.accent`).
- `EmptyArt` – soft tinted circle + inner card + icon (and optional corner badge), used by `EmptyState` and `ErrorState`.

**Updated**
- `app/dev/components.tsx` – renders all 35 primitives across every variant and state, grouped into 11 numbered sections using canonical Sunrise Coaching Classes (`SUNRISE-PAT`) seed data.
- `src/lib/theme.ts` – single source of truth for all colours, radii, spacing, and shadows.

**Verified**
- `npx tsc --noEmit` – zero TypeScript errors.
- Zero hex literals outside `src/lib/theme.ts` across the entire codebase.
- Every file strictly under 300 lines.
- `npx expo export --platform all` – clean multi-platform export (Web, iOS, Android).

## 2026-11-11 · Supabase adapter for all 34 ports

Implemented the complete Supabase backend adapter under `src/adapters/supabase/`, querying the GuruFlow data model and mapping every database row to backend-neutral domain models.

**Added**
- `src/adapters/supabase/client.ts` – Supabase client setup, error translation mapping PostgreSQL/PostgREST error codes (`PGRST116` → `NOT_FOUND`, `23505` → `CONFLICT`, `42501`/RLS → `FORBIDDEN`, `23514`/check/foreign key → `VALIDATION`, fetch/timeout → `NETWORK`/`TIMEOUT`), and `toPaginatedResult` pagination helper (paginating with `{ items, rows, total, hasMore, nextCursor }`).
- `src/adapters/supabase/mappers.ts` – row → domain model mappers for every table and model with snake_case → camelCase conversion and type assertions.
- `src/adapters/supabase/auth.adapter.ts` – `AuthPort` implementation.
- `src/adapters/supabase/institute.repo.ts` – `InstituteRepo` implementation.
- `src/adapters/supabase/branch.repo.ts` – `BranchRepo` implementation.
- `src/adapters/supabase/membership.repo.ts` – `MembershipRepo` and `InvitationRepo` implementations.
- `src/adapters/supabase/staff.repo.ts` – `StaffRepo` implementation.
- `src/adapters/supabase/student.repo.ts` – `StudentRepo` and `GuardianRepo` implementations.
- `src/adapters/supabase/batch.repo.ts` – `BatchRepo`, `SubjectRepo`, and `TimetableRepo` implementations.
- `src/adapters/supabase/attendance.repo.ts` – `AttendanceRepo` implementation with summary calculations.
- `src/adapters/supabase/assignment.repo.ts` – `AssignmentRepo` and `SubmissionRepo` implementations.
- `src/adapters/supabase/exam.repo.ts` – `ExamRepo` and `ResultRepo` implementations.
- `src/adapters/supabase/mark.repo.ts` – `MarkRepo` implementation with bulk marks upsert.
- `src/adapters/supabase/material.repo.ts` – `MaterialRepo` and bookmarking implementation.
- `src/adapters/supabase/practice.repo.ts` – `PracticeRepo` implementation.
- `src/adapters/supabase/fee.repo.ts` – `FeeRepo` implementation with fee summaries and installment tracking.
- `src/adapters/supabase/payment.repo.ts` – `PaymentRepo` and `PaymentPort` (gateway) implementations.
- `src/adapters/supabase/receipt.repo.ts` – `ReceiptRepo` implementation.
- `src/adapters/supabase/notice.repo.ts` – `NoticeRepo` implementation.
- `src/adapters/supabase/notification.repo.ts` – `NotificationRepo` implementation.
- `src/adapters/supabase/doubt.repo.ts` – `DoubtRepo` and `MeetingRepo` implementations.
- `src/adapters/supabase/lead.repo.ts` – `LeadRepo` implementation with pipeline stage conversions.
- `src/adapters/supabase/analytics.repo.ts` – `AnalyticsRepo` implementation.
- `src/adapters/supabase/subscription.repo.ts` – `SubscriptionRepo` implementation.
- `src/adapters/supabase/progress.repo.ts` – `ProgressPort` with early-warning risk alert evaluation rules defined as top-level constants (`RISK_RULES`).
- `src/adapters/supabase/storage.adapter.ts` – `StoragePort` implementation with signed URLs and attachment tracking.
- `src/adapters/supabase/misc.adapter.ts` – `ExportRepo` and `RealtimePort` live changes subscriptions.
- `src/adapters/supabase/index.ts` – Assembles the full `Backend` instance and exports `createSupabaseBackend()`.
- `src/backends/index.ts` – Registered `supabase` in `createBackends()` as default backend.

**Verified**
- `npx tsc --noEmit` – zero TypeScript errors.
- Every file in `src/adapters/supabase/` is strictly under 300 lines (max 281 lines).
- `grep -rn "supabase" app/ src/features` returns 0 occurrences.
- All 34 ports cleanly implemented with tenant isolation, proper error mapping, and pagination.

## 2026-11-11 · Core contracts for the whole data model

The UI now has a typed, backend-neutral surface for every domain in the 62-table model. Nothing under `app/` or `src/core` names a table, a column or an SDK.

**Added**
- `src/core/contracts/models.ts` + `models/*.ts` – the 51 domain types as plain camelCase, plus the supporting types the ports need (`AuthSession`, `InstituteSettings`, `Teacher`, `Enrollment`, `AttendanceSheet`, `PaymentOrder`, `ExportJob`, `Student360` …).
- `src/core/contracts/ports.ts` + `ports/*.ts` – the 34 ports and the `Backend` interface that bundles them. Every method is async and takes `instituteId` first.
- `src/core/contracts/query.ts` (`ListQuery`, `Page`) and `errors.ts` (`BackendError`, 11 codes).
- `src/core/contracts/checks.ts` – one safe, read-only call per port. Keyed by port, so a port without a check does not compile.
- `src/core/backend.tsx` + `src/core/hooks/*.ts` – `BackendProvider`, `useBackend` and a hook for every port. Each returns `{ data, loading, error, refetch }` plus the domain's actions. All writes go through `hooks/mutation.ts`: snapshot → optimistic update → run → toast and reload, or roll back and error toast.
- `src/backends/memory/` – reference backend implementing all 34 ports over in-process maps, seeded with a small slice of Sunrise Coaching Classes. `src/backends/stub.ts` – every method rejects `NOT_IMPLEMENTED`; the starting point for a new adapter.
- `app/dev/contract-check.tsx` – runs the checks against any registered backend and prints pass / fail with the error code. `app/index.tsx` – landing screen linking to it.
- `docs/ADDING_A_BACKEND.md`; `npm run typecheck`.

**Verified**
- `npm run typecheck` – zero errors. `npx expo export --platform all` – builds for web, iOS and Android.
- No file over 300 lines.
- No backend SDK is imported anywhere; `app/` and `src/core` do not import `src/backends`.

## 2026-11-11 · Full GuruFlow data model (migrations 0003–0008, seed)

Replaced the 17-table schema with the 62-table GuruFlow model.
