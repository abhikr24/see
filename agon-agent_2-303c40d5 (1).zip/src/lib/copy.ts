/** User-facing copy for the design-system gallery and feature screens. */
export const copy = {
  dev: {
    eyebrow: 'DESIGN SYSTEM · QA GALLERY',
    title: 'Design system',
    subtitle: 'All 35 GuruFlow primitives in every variant and state — zero hardcoded colours.',
    heroTitle: 'Sunrise Coaching Classes',
    heroBody: 'Patna, Bihar · SUNRISE-PAT · Academic Year 2026–27',
    heroStat: 'TODAY ATTENDANCE',
    heroNote: '46 present · 1 late · 3 absent of 50',
  },
  fees: {
    title: 'Fees',
    paid: 'Paid',
    pending: 'Pending',
    overdue: 'Overdue',
  },
  common: {
    cancel: 'Cancel',
    done: 'Done',
    retry: 'Try again',
  },
} as const;
