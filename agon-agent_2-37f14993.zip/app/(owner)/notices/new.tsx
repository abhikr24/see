export { NoticeComposerScreen as default } from '@/features/notices';
