import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Card, Screen, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';

const ITEMS = [
  { key: 'notices', title: 'Notices', detail: 'Academic updates, events and announcements', icon: 'megaphone-outline' as const, route: '/(student)/notices' },
  { key: 'notifications', title: 'Notifications', detail: 'Homework, exams and attendance alerts', icon: 'notifications-outline' as const, route: '/shared/notifications' },
];

export default function StudentMoreRoute() {
  return (
    <Screen title="More" subtitle="Updates and institute information" safeTop={false} tabBarInset={96}>
      <View style={{ gap: 12 }}>
        {ITEMS.map((item) => (
          <Card key={item.key} pad={16} onPress={() => router.push(item.route as never)}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ width: 46, height: 46, borderRadius: R.field, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={item.icon} size={22} color={C.primary} />
              </View>
              <View style={{ flex: 1, gap: 3 }}>
                <Text variant="title" weight={700}>{item.title}</Text>
                <Text variant="caption" c={C.secondary}>{item.detail}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={C.muted} />
            </View>
          </Card>
        ))}
      </View>
    </Screen>
  );
}
