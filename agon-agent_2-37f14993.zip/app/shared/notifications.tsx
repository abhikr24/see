export { NotificationCentreScreen as default } from '@/features/notifications';
