import type {
  ConversationMessage,
  ID,
  Notice,
  PublishNoticeInput,
  PublishNoticeResult,
} from '../../core/contracts/models';
import type {
  DoubtRepo,
  MeetingRepo,
  NoticeRepo,
  NotificationRepo,
  RealtimePort,
} from '../../core/contracts/ports';
import { crud, emit, myStudentIds, requireUser, type Db } from './db';
import * as D from './defaults';
import { callerRole, teacherBatchScope, visibleBatch } from './teacher-scope';
import { canSeeNotice, noticeRecipientIds } from './notice-recipients';
import { fail, merge, nowIso } from './store';

function assertNoticeAuthor(db: Db, instituteId: ID) {
  const role = callerRole(db, instituteId);
  if (role !== 'owner' && role !== 'admin' && role !== 'teacher') {
    fail('FORBIDDEN', 'Only institute staff can publish a notice');
  }
}

function validateNotice(input: Pick<PublishNoticeInput, 'title' | 'body' | 'audience'>) {
  if (!input.title.trim()) fail('VALIDATION', 'Title is required');
  if (!input.body.trim()) fail('VALIDATION', 'Write a short message');
  if (input.body.length > 500) fail('VALIDATION', 'Notice body must be 500 characters or fewer');
  if (input.audience.length === 0) fail('VALIDATION', 'Choose who should see this notice');
}

export function noticeRepo(db: Db): NoticeRepo {
  const base = crud<Notice, 'title'>(db.notices, D.notice);
  return {
    ...base,
    list: async (instituteId, query) =>
      db.notices.page(
        instituteId,
        { ...query, sort: query?.sort ?? { field: 'publishedAt', direction: 'desc' } },
        {},
        (notice) => canSeeNotice(db, instituteId, notice),
      ),
    get: async (instituteId, id) => {
      const notice = db.notices.get(instituteId, id);
      if (!canSeeNotice(db, instituteId, notice)) fail('NOT_FOUND', 'Notice not found');
      return notice;
    },
    create: async (instituteId, input) => {
      assertNoticeAuthor(db, instituteId);
      validateNotice({ title: input.title, body: input.body ?? '', audience: (input.audience ?? []) as PublishNoticeInput['audience'] });
      return base.create(instituteId, { createdBy: requireUser(db), ...input });
    },
    publish: async (instituteId, id) => {
      assertNoticeAuthor(db, instituteId);
      const notice = db.notices.update(instituteId, id, { publishedAt: nowIso() });
      emit(db, instituteId, 'notices', 'updated', id);
      return notice;
    },
    publishNew: async (instituteId, input): Promise<PublishNoticeResult> => {
      assertNoticeAuthor(db, instituteId);
      validateNotice(input);
      if (input.batchId) db.batches.get(instituteId, input.batchId);
      const publishedAt = nowIso();
      const notice = db.notices.insert(instituteId, {
        ...D.notice(),
        ...input,
        title: input.title.trim(),
        body: input.body.trim(),
        createdBy: requireUser(db),
        publishedAt,
      });
      emit(db, instituteId, 'notices', 'created', notice.id);

      const alertsEnabled = db.institutes.get(instituteId, instituteId).settings.features.noticeAlerts !== false;
      let notified = 0;
      if (alertsEnabled) {
        for (const userId of noticeRecipientIds(db, instituteId, input.audience, input.batchId)) {
          const sent = db.notifications.insert(
            instituteId,
            merge(D.notification(), {
              userId,
              type: 'announcement',
              title: notice.title,
              body: notice.body.slice(0, 180),
              data: { screen: 'notice', noticeId: notice.id },
              channel: 'in_app' as const,
            }),
          );
          notified += 1;
          emit(db, instituteId, 'notifications', 'created', sent.id);
        }
      }
      return { notice, notified, alertsEnabled };
    },
    update: async (instituteId, id, patch) => {
      assertNoticeAuthor(db, instituteId);
      return base.update(instituteId, id, patch);
    },
    remove: async (instituteId, id) => {
      if (callerRole(db, instituteId) !== 'owner') fail('FORBIDDEN', 'Only the owner can delete a notice');
      db.notices.remove(instituteId, id);
      emit(db, instituteId, 'notices', 'removed', id);
    },
    setPinned: async (instituteId, id, pinned) => {
      assertNoticeAuthor(db, instituteId);
      return db.notices.update(instituteId, id, { isPinned: pinned });
    },
  };
}

export function notificationRepo(db: Db): NotificationRepo {
  const unread = (instituteId: string) =>
    db.notifications.all(instituteId, { userId: requireUser(db) }).filter((n) => n.readAt === null);
  return {
    list: async (instituteId, query) =>
      db.notifications.page(
        instituteId,
        { ...query, sort: query?.sort ?? { field: 'createdAt', direction: 'desc' } },
        { userId: requireUser(db) },
      ),
    unreadCount: async (instituteId) => unread(instituteId).length,
    markRead: async (instituteId, id) => {
      const notification = db.notifications.get(instituteId, id);
      // Someone else's notification is indistinguishable from one that does not exist.
      if (notification.userId !== requireUser(db)) fail('NOT_FOUND', 'Notification not found');
      if (notification.readAt) return notification;
      const updated = db.notifications.update(instituteId, id, { readAt: nowIso() });
      emit(db, instituteId, 'notifications', 'updated', id);
      return updated;
    },
    markAllRead: async (instituteId) => {
      const pending = unread(instituteId);
      pending.forEach((notification) => {
        db.notifications.update(instituteId, notification.id, { readAt: nowIso() });
        emit(db, instituteId, 'notifications', 'updated', notification.id);
      });
      return pending.length;
    },
    dismiss: async (instituteId, id) => {
      const notification = db.notifications.get(instituteId, id);
      if (notification.userId !== requireUser(db)) fail('NOT_FOUND', 'Notification not found');
      db.notifications.remove(instituteId, id);
      emit(db, instituteId, 'notifications', 'removed', id);
    },
    send: async (instituteId, input) => {
      if (!db.memberships.find(instituteId, { userId: input.userId })) {
        fail('VALIDATION', 'That person is not a member of this institute');
      }
      const sent = db.notifications.insert(instituteId, merge(D.notification(), input));
      emit(db, instituteId, 'notifications', 'created', sent.id);
      return sent;
    },
  };
}

export function doubtRepo(db: Db): DoubtRepo {
  const visibleDoubt = (instituteId: ID, id: ID) => {
    const doubt = db.doubts.get(instituteId, id);
    const role = callerRole(db, instituteId);
    if (role === 'owner' || role === 'admin') return doubt;
    if (role === 'teacher') {
      visibleBatch(db, instituteId, doubt.batchId);
      return doubt;
    }
    if (role === 'student' || role === 'parent') {
      if (myStudentIds(db, instituteId).includes(doubt.studentId)) return doubt;
    }
    fail('NOT_FOUND', 'Doubt not found');
  };

  return {
    list: async (instituteId, query) => {
      const role = callerRole(db, instituteId);
      if (role === 'owner' || role === 'admin') return db.doubts.page(instituteId, query);
      if (role === 'teacher') {
        const scope = teacherBatchScope(db, instituteId);
        return db.doubts.page(instituteId, query, {}, (doubt) => scope?.has(doubt.batchId) ?? false);
      }
      if (role === 'student' || role === 'parent') {
        const studentIds = new Set(myStudentIds(db, instituteId));
        return db.doubts.page(instituteId, query, {}, (doubt) => studentIds.has(doubt.studentId));
      }
      return { items: [], nextCursor: null, total: 0 };
    },
    get: async (instituteId, id) => visibleDoubt(instituteId, id),
    ask: async (instituteId, input) => {
      const { batchId, studentId } = input;
      if (callerRole(db, instituteId) !== 'student') fail('FORBIDDEN', 'Only a student can ask a question');
      if (!input.question.trim()) fail('VALIDATION', 'Type your question first');
      if (!myStudentIds(db, instituteId).includes(studentId)) {
        fail('FORBIDDEN', 'You can only ask about your own studies');
      }
      if (!db.enrollments.find(instituteId, { batchId, studentId, status: 'active' })) {
        fail('VALIDATION', 'Student is not enrolled in that batch');
      }
      const doubt = db.doubts.insert(instituteId, merge({ ...D.doubt(), askedBy: db.session.userId }, input));
      emit(db, instituteId, 'doubts', 'created', doubt.id);
      return doubt;
    },
    answer: async (instituteId, id, answer) => {
      if (!answer.trim()) fail('VALIDATION', 'The answer cannot be empty');
      if (callerRole(db, instituteId) !== 'teacher') fail('FORBIDDEN', 'Only a teacher can answer');
      const existing = visibleDoubt(instituteId, id);
      const doubt = db.doubts.update(instituteId, id, {
        answer: answer.trim(),
        answeredBy: db.session.userId,
        answeredAt: nowIso(),
        status: 'answered',
      });
      const studentLogins = db.studentMemberships
        .all(instituteId, { studentId: existing.studentId })
        .map((link) => db.memberships.find(instituteId, { id: link.membershipId, status: 'active' }))
        .filter((membership) => membership !== undefined);
      for (const membership of studentLogins) {
        const sent = db.notifications.insert(
          instituteId,
          merge(D.notification(), {
            userId: membership.userId,
            type: 'doubt_answered',
            title: 'Your question was answered',
            body: answer.trim().slice(0, 120),
            data: { screen: 'doubts', doubtId: doubt.id },
          }),
        );
        emit(db, instituteId, 'notifications', 'created', sent.id);
      }
      emit(db, instituteId, 'doubts', 'updated', id);
      return doubt;
    },
    setStatus: async (instituteId, id, status) => {
      if (callerRole(db, instituteId) !== 'teacher') fail('FORBIDDEN', 'Only a teacher can update a question');
      visibleDoubt(instituteId, id);
      return db.doubts.update(instituteId, id, { status });
    },
  };
}

export function meetingRepo(db: Db): MeetingRepo {
  return {
    list: async (instituteId, query) => db.meetings.page(instituteId, query),
    get: async (instituteId, id) => db.meetings.get(instituteId, id),
    request: async (instituteId, input) => {
      db.students.get(instituteId, input.studentId);
      db.teachers.get(instituteId, input.teacherId);
      return db.meetings.insert(instituteId, merge({ ...D.meeting(), requestedBy: db.session.userId }, input));
    },
    respond: async (instituteId, id, { status, scheduledAt, note = null }) => {
      const meeting = db.meetings.get(instituteId, id);
      if (meeting.status !== 'pending' && meeting.status !== 'accepted') {
        fail('CONFLICT', `This meeting is already ${meeting.status}`);
      }
      const when = scheduledAt ?? meeting.scheduledAt ?? meeting.preferredAt;
      if (status === 'accepted' && !when) fail('VALIDATION', 'Pick a time to accept this meeting');
      return db.meetings.update(instituteId, id, {
        status,
        scheduledAt: status === 'accepted' ? when : meeting.scheduledAt,
        responseNote: note,
        respondedAt: nowIso(),
      });
    },
    listConversations: async (instituteId, query) => {
      const userId = requireUser(db);
      const sort = query?.sort ?? { field: 'lastMessageAt' as const, direction: 'desc' as const };
      return db.conversations.page(instituteId, { ...query, sort }, {}, (c) => c.participantIds.includes(userId));
    },
    startConversation: async (instituteId, input) => {
      const userId = requireUser(db);
      const participantIds = [...new Set([userId, ...input.participantIds])];
      if (participantIds.length < 2) fail('VALIDATION', 'A conversation needs someone else in it');
      const outsider = participantIds.find((id) => !db.memberships.find(instituteId, { userId: id }));
      if (outsider) fail('VALIDATION', 'Everyone in a conversation must belong to this institute');
      return db.conversations.insert(instituteId, {
        ...merge(D.conversation(), input),
        participantIds,
        messages: [],
        createdBy: userId,
      });
    },
    sendMessage: async (instituteId, conversationId, body) => {
      const userId = requireUser(db);
      const conversation = db.conversations.get(instituteId, conversationId);
      if (!conversation.participantIds.includes(userId)) fail('FORBIDDEN', 'You are not part of this conversation');
      if (!body.trim()) fail('VALIDATION', 'Type a message first');
      const message: ConversationMessage = { id: db.nextId(), senderId: userId, body: body.trim(), sentAt: nowIso() };
      const updated = db.conversations.update(instituteId, conversationId, {
        messages: [...conversation.messages, message],
        lastMessagePreview: message.body.slice(0, 80),
        lastMessageAt: message.sentAt,
      });
      emit(db, instituteId, 'conversations', 'updated', conversationId);
      return updated;
    },
  };
}

/** In-process change feed: events are delivered synchronously to subscribers in this app only. */
export function realtimePort(db: Db): RealtimePort {
  return {
    status: async (instituteId) => {
      db.institutes.get(instituteId, instituteId);
      return 'connected';
    },
    subscribe: async (instituteId, topic, onEvent) => {
      db.institutes.get(instituteId, instituteId);
      const key = `${instituteId}:${topic}`;
      const listeners = db.listeners.get(key) ?? new Set();
      db.listeners.set(key, listeners);
      listeners.add(onEvent);
      return {
        topic,
        unsubscribe: async () => {
          listeners.delete(onEvent);
        },
      };
    },
  };
}
