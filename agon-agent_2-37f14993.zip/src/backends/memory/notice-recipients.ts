import type { ID, Notice, NoticeAudienceRole } from '../../core/contracts/models';
import { myStudentIds, requireUser, type Db } from './db';
import { callerRole } from './teacher-scope';

function teacherBelongsToBatch(db: Db, instituteId: ID, userId: ID, batchId: ID): boolean {
  const teacher = db.teachers.find(instituteId, { userId, status: 'active' });
  if (!teacher) return false;
  const batch = db.batches.get(instituteId, batchId);
  return batch.teacherId === teacher.id || db.timetables.all(instituteId, { batchId, teacherId: teacher.id }).length > 0;
}

function memberBelongsToBatch(db: Db, instituteId: ID, membershipId: ID, role: NoticeAudienceRole, batchId: ID): boolean {
  if (role === 'teacher') {
    const member = db.memberships.get(instituteId, membershipId);
    return teacherBelongsToBatch(db, instituteId, member.userId, batchId);
  }

  const enrolledStudents = new Set(
    db.enrollments.all(instituteId, { batchId, status: 'active' }).map((enrollment) => enrollment.studentId),
  );
  if (role === 'student') {
    return db.studentMemberships
      .all(instituteId, { membershipId })
      .some((link) => enrolledStudents.has(link.studentId));
  }

  return db.guardians
    .all(instituteId, { membershipId })
    .some((guardian) =>
      db.parentLinks
        .all(instituteId, { guardianId: guardian.id })
        .some((link) => enrolledStudents.has(link.studentId)),
    );
}

/** Active login ids in the chosen roles, optionally narrowed to one batch. */
export function noticeRecipientIds(
  db: Db,
  instituteId: ID,
  audience: readonly NoticeAudienceRole[],
  batchId: ID | null,
): ID[] {
  if (batchId) db.batches.get(instituteId, batchId);
  const roles = new Set(audience);
  return [...new Set(
    db.memberships
      .all(instituteId, { status: 'active' })
      .filter((membership) => roles.has(membership.role as NoticeAudienceRole))
      .filter((membership) =>
        batchId
          ? memberBelongsToBatch(db, instituteId, membership.id, membership.role as NoticeAudienceRole, batchId)
          : true,
      )
      .map((membership) => membership.userId),
  )];
}

/** Mirrors the notice RLS rule for the reference adapter. */
export function canSeeNotice(db: Db, instituteId: ID, notice: Notice): boolean {
  const role = callerRole(db, instituteId);
  const userId = db.session.userId;
  if (!role || !userId) return false;
  if (role === 'owner' || role === 'admin') return true;
  if (notice.createdBy === userId) return true;
  if (!notice.publishedAt || (notice.expiresAt && notice.expiresAt <= new Date().toISOString())) return false;
  if (!notice.audience.includes(role)) return false;
  if (!notice.batchId) return true;
  if (role === 'teacher') return teacherBelongsToBatch(db, instituteId, requireUser(db), notice.batchId);
  return myStudentIds(db, instituteId).some((studentId) =>
    db.enrollments.all(instituteId, { studentId, batchId: notice.batchId!, status: 'active' }).length > 0,
  );
}
