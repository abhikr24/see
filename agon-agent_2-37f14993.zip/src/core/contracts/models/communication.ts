import type { ID, ISODateTime, JsonObject, Role, TenantEntity } from './common';

/** An announcement. `publishedAt` null = draft; `batchId` null = everyone in `audience`. */
export type NoticeCategory = 'general' | 'academic' | 'exam' | 'fee' | 'holiday' | 'event' | 'urgent';
export type NoticeAudienceRole = Extract<Role, 'teacher' | 'student' | 'parent'>;

export interface Notice extends TenantEntity {
  batchId: ID | null;
  title: string;
  body: string;
  category: NoticeCategory;
  audience: Role[];
  isPinned: boolean;
  publishedAt: ISODateTime | null;
  expiresAt: ISODateTime | null;
  createdBy: ID | null;
}

/** The composer publishes in one operation so a notice and its inbox rows cannot drift. */
export interface PublishNoticeInput {
  title: string;
  body: string;
  category: NoticeCategory;
  audience: NoticeAudienceRole[];
  /** null broadcasts to every batch; otherwise recipients are scoped to this batch. */
  batchId: ID | null;
}

export interface PublishNoticeResult {
  notice: Notice;
  notified: number;
  alertsEnabled: boolean;
}

export type NotificationChannel = 'in_app' | 'push' | 'sms' | 'email' | 'whatsapp';

/** One message to one person. Named AppNotification to avoid the DOM `Notification`. */
export interface AppNotification extends TenantEntity {
  userId: ID;
  type: string;
  title: string;
  body: string | null;
  /** Routing payload, e.g. `{ screen: 'notice', id: '…' }`. */
  data: JsonObject;
  channel: NotificationChannel;
  sentAt: ISODateTime | null;
  readAt: ISODateTime | null;
}

export interface ConversationMessage {
  id: ID;
  senderId: ID;
  body: string;
  sentAt: ISODateTime;
}

export interface Conversation extends TenantEntity {
  kind: 'direct' | 'parent_teacher' | 'group' | 'support';
  title: string | null;
  /** The student the thread is about, if any. */
  studentId: ID | null;
  participantIds: ID[];
  messages: ConversationMessage[];
  lastMessagePreview: string | null;
  lastMessageAt: ISODateTime | null;
  isArchived: boolean;
  createdBy: ID | null;
}

export type DoubtStatus = 'open' | 'answered' | 'resolved' | 'closed';

/** A student's question and the teacher's answer. */
export interface Doubt extends TenantEntity {
  batchId: ID;
  studentId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  askedBy: ID | null;
  topic: string | null;
  question: string;
  answer: string | null;
  answeredBy: ID | null;
  answeredAt: ISODateTime | null;
  status: DoubtStatus;
}

export type MeetingStatus = 'pending' | 'accepted' | 'declined' | 'completed' | 'cancelled';

/** A parent–teacher meeting. */
export interface MeetingRequest extends TenantEntity {
  studentId: ID;
  teacherId: ID;
  guardianId: ID | null;
  requestedBy: ID | null;
  reason: string | null;
  preferredAt: ISODateTime | null;
  scheduledAt: ISODateTime | null;
  durationMinutes: number | null;
  mode: 'in_person' | 'phone' | 'video';
  status: MeetingStatus;
  responseNote: string | null;
  respondedAt: ISODateTime | null;
}

export type RealtimeTopic =
  | 'memberships'
  | 'attendance'
  | 'notices'
  | 'notifications'
  | 'doubts'
  | 'leave_requests'
  | 'conversations'
  | 'payments';

export interface RealtimeEvent {
  topic: RealtimeTopic;
  change: 'created' | 'updated' | 'removed';
  /** Id of the record that changed. Fetch it through its repo. */
  id: ID;
  at: ISODateTime;
}

export type RealtimeStatus = 'connected' | 'connecting' | 'offline';
