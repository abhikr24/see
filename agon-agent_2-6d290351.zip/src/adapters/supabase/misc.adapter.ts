import type { BackupStatus, ExportJob, ID, ImportResult, RealtimeEvent, RealtimeStatus, RealtimeTopic } from '../../core/contracts/models';
import type { ExportRepo, ExportRequest, RealtimePort, RealtimeSubscription } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { memoryFallback, supabase } from './client';

export function exportRepo(): ExportRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<ExportJob>): Promise<Page<ExportJob>> {
      return memoryFallback.exports.list(instituteId, query);
    },
    async start(instituteId: ID, request: ExportRequest): Promise<ExportJob> {
      return memoryFallback.exports.start(instituteId, request);
    },
    async get(instituteId: ID, jobId: ID): Promise<ExportJob> {
      return memoryFallback.exports.get(instituteId, jobId);
    },
    status(instituteId: ID): Promise<BackupStatus> {
      return memoryFallback.exports.status(instituteId);
    },
    recordBackup(instituteId: ID): Promise<BackupStatus> {
      return memoryFallback.exports.recordBackup(instituteId);
    },
    content(instituteId: ID, jobId: ID): Promise<string> {
      return memoryFallback.exports.content(instituteId, jobId);
    },
    importJson(instituteId: ID, payload: string): Promise<ImportResult> {
      return memoryFallback.exports.importJson(instituteId, payload);
    },
    clearAll(instituteId: ID, confirmation: string) {
      return memoryFallback.exports.clearAll(instituteId, confirmation);
    },
  };
}

/** The table whose row changes feed each topic. */
const TOPIC_TABLE: Record<RealtimeTopic, string> = {
  memberships: 'memberships',
  attendance: 'attendance_records',
  notices: 'notices',
  notifications: 'notifications',
  doubts: 'doubts',
  leave_requests: 'leave_requests',
  conversations: 'conversations',
  payments: 'payments',
};

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

/** Two screens may follow the same topic at once (the tab badge and the inbox); each gets its own channel. */
let channelSeq = 0;

export function realtimePort(): RealtimePort {
  return {
    async status(instituteId: ID): Promise<RealtimeStatus> {
      return 'connected';
    },
    async subscribe(instituteId: ID, topic: RealtimeTopic, onEvent: (event: RealtimeEvent) => void): Promise<RealtimeSubscription> {
      // No project configured: writes land in the bundled reference data, so its change feed is the live one.
      if (!live) return memoryFallback.realtime.subscribe(instituteId, topic, onEvent);
      channelSeq += 1;
      const channel = supabase.channel(`institute_${instituteId}_${topic}_${channelSeq}`)
        // Row policies still apply: a person only ever hears about rows they may read (their own notifications).
        .on('postgres_changes', { event: '*', schema: 'public', table: TOPIC_TABLE[topic], filter: `institute_id=eq.${instituteId}` }, (payload) => {
          onEvent({
            topic,
            change: payload.eventType === 'INSERT' ? 'created' : payload.eventType === 'DELETE' ? 'removed' : 'updated',
            id: (payload.new as any)?.id ?? (payload.old as any)?.id ?? '',
            at: new Date().toISOString(),
          });
        })
        .subscribe();
      return {
        topic,
        unsubscribe: async () => {
          await supabase.removeChannel(channel);
        },
      };
    },
  };
}
