import { BackendError } from '../../core/contracts/errors';
import { getNoticeValidationErrors, normaliseAudience } from '../../core/contracts/notices';
import type { ID, NewEntity, Notice, Patch, PublishNoticeInput, PublishNoticeResult } from '../../core/contracts/models';
import type { NoticeRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapNotice } from './mappers';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

/**
 * Publish + fan-out runs in one database function (`publish_notice`, migration
 * 0018): the notice row(s) and every recipient's notification are written in a
 * single transaction, by the database, under the caller's identity. The client
 * never inserts a notification itself and there is no reference fallback for a
 * configured project — a failed publish is reported, not faked.
 */
async function broadcastLive(instituteId: ID, input: PublishNoticeInput): Promise<PublishNoticeResult> {
  const firstError = Object.values(getNoticeValidationErrors(input))[0];
  if (firstError) throw new BackendError('VALIDATION', firstError);
  const category = input.category ?? 'general';
  const { data, error } = await supabase.rpc('publish_notice', {
    p_institute_id: instituteId,
    p_title: input.title.trim(),
    p_body: input.body.trim(),
    p_audience: normaliseAudience(input.audience),
    p_batch_id: input.batchId ?? null,
    p_category: category,
    p_event_on: category === 'event' ? (input.eventOn ?? null) : null,
  });
  if (error) throw handleSupabaseError(error, 'Could not publish the notice');
  const row = (data ?? {}) as {
    notices?: Record<string, unknown>[];
    students?: number;
    parents?: number;
    teachers?: number;
    alerts_disabled?: boolean;
  };
  const notified = {
    student: Number(row.students ?? 0),
    parent: Number(row.parents ?? 0),
    teacher: Number(row.teachers ?? 0),
  };
  return {
    notices: (row.notices ?? []).map(mapNotice),
    notified,
    totalNotified: notified.student + notified.parent + notified.teacher,
    alertsDisabled: row.alerts_disabled === true,
  };
}

export function noticeRepo(): NoticeRepo {
  return {
    async broadcast(instituteId: ID, input: PublishNoticeInput): Promise<PublishNoticeResult> {
      if (!live) return memoryFallback.notices.broadcast(instituteId, input);
      return broadcastLive(instituteId, input);
    },

    async list(instituteId: ID, query?: ListQuery<Notice>): Promise<Page<Notice>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('notices').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.category) q = q.eq('category', query.where.category);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapNotice), count, offset, limit);
      } catch {
        return memoryFallback.notices.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Notice> {
      try {
        const { data, error } = await supabase.from('notices').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapNotice(data);
      } catch {
        return memoryFallback.notices.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<Notice, 'title'>): Promise<Notice> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('notices').insert({
          institute_id: instituteId, title: input.title, body: input.body ?? '',
          batch_id: input.batchId ?? null, category: input.category ?? 'general',
          audience: input.audience ?? ['owner', 'admin', 'teacher', 'student', 'parent'],
          is_pinned: input.isPinned ?? false, published_at: input.publishedAt ?? null,
          expires_at: input.expiresAt ?? null, event_on: input.eventOn ?? null, created_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapNotice(data);
      } catch {
        return memoryFallback.notices.create(instituteId, input);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<Notice>): Promise<Notice> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.title !== undefined) row.title = patch.title;
        if (patch.body !== undefined) row.body = patch.body;
        if (patch.category !== undefined) row.category = patch.category;
        if (patch.audience !== undefined) row.audience = patch.audience;
        if (patch.isPinned !== undefined) row.is_pinned = patch.isPinned;
        if (patch.publishedAt !== undefined) row.published_at = patch.publishedAt;
        if (patch.expiresAt !== undefined) row.expires_at = patch.expiresAt;
        if (patch.eventOn !== undefined) row.event_on = patch.eventOn;
        const { data, error } = await supabase.from('notices').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapNotice(data);
      } catch {
        return memoryFallback.notices.update(instituteId, id, patch);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('notices').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.notices.remove(instituteId, id);
      }
    },

    async publish(instituteId: ID, id: ID): Promise<Notice> {
      return this.update(instituteId, id, { publishedAt: new Date().toISOString() });
    },

    async setPinned(instituteId: ID, id: ID, pinned: boolean): Promise<Notice> {
      return this.update(instituteId, id, { isPinned: pinned });
    },
  };
}
