import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { StudentDetailScreen } from '@/features/students/screens/StudentDetailScreen';

export default function StudentDetailRoute() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  return <StudentDetailScreen id={typeof id === 'string' ? id : ''} />;
}
