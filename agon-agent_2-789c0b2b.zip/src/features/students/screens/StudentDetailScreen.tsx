import React, { useEffect, useState } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Avatar, Card, ErrorState, Text } from '@/components/ui';
import { useBackend } from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import type { Student } from '@/core/contracts/models';
import { C, LAYOUT } from '@/lib/theme';

/** Stub. The full profile (attendance, marks, fees) is Prompt P10. */
export function StudentDetailScreen({ id }: { id: string }) {
  const { backend, instituteId } = useBackend();
  const [student, setStudent] = useState<Student | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!instituteId || !id) return;
    let live = true;
    backend.students.get(instituteId, id).then(
      (next) => {
        if (live) setStudent(next);
      },
      (cause) => {
        if (live) setError(toBackendError(cause).message);
      },
    );
    return () => {
      live = false;
    };
  }, [backend, instituteId, id]);

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin, gap: 16 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Back to students"
        onPress={() => router.back()}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
      >
        <Ionicons name="chevron-back" size={20} color={C.primary} />
        <Text variant="caption" weight={700} c={C.primary}>
          Students
        </Text>
      </Pressable>
      {error ? (
        <ErrorState message={error} onRetry={() => router.back()} />
      ) : (
        <Card>
          <View style={{ alignItems: 'center', gap: 10, paddingVertical: 8 }}>
            <Avatar name={student?.fullName ?? 'Student'} uri={student?.photoUrl} size={72} />
            <Text variant="h2" style={{ textAlign: 'center' }}>
              {student?.fullName ?? 'Student'}
            </Text>
            <Text variant="caption" c={C.secondary} style={{ textAlign: 'center' }}>
              Attendance, marks and fees open in Prompt P10.
            </Text>
          </View>
        </Card>
      )}
    </View>
  );
}
