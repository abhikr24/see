import React from 'react';

import { StudentHomeworkScreen } from '@/features/homework/student';

export default function StudentHomeworkRoute() {
  return <StudentHomeworkScreen />;
}
