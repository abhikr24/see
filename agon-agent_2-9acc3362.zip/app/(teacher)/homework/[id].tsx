import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { HomeworkSubmissionsScreen } from '@/features/homework/screens/HomeworkSubmissionsScreen';

export default function TeacherHomeworkSubmissionsRoute() {
  const params = useLocalSearchParams<{ id?: string }>();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  return <HomeworkSubmissionsScreen assignmentId={id ?? ''} />;
}
