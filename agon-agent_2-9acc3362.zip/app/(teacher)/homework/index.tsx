import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { HomeworkTrackerScreen } from '@/features/homework/screens/HomeworkTrackerScreen';

export default function TeacherHomeworkIndexRoute() {
  const params = useLocalSearchParams<{ batchId?: string; action?: string }>();
  const batchId = Array.isArray(params.batchId) ? params.batchId[0] : params.batchId;
  const action = Array.isArray(params.action) ? params.action[0] : params.action;
  return <HomeworkTrackerScreen initialBatchId={batchId} action={action} />;
}
