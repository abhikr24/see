import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { AssignHomeworkScreen } from '@/features/homework/screens/AssignHomeworkScreen';

export default function TeacherAssignHomeworkRoute() {
  const params = useLocalSearchParams<{ batchId?: string }>();
  const batchId = Array.isArray(params.batchId) ? params.batchId[0] : params.batchId;
  return <AssignHomeworkScreen initialBatchId={batchId} />;
}
