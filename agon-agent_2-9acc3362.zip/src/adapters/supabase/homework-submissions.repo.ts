import { BackendError } from '../../core/contracts/errors';
import {
  assertValidGrade,
  buildHomeworkSubmissionsView,
  buildStudentHomeworkList,
  HOMEWORK_DEFAULT_MAX_MARKS,
  splitAssignmentAttachments,
} from '../../core/contracts/homework';
import type {
  AskAgainResult,
  Attachment,
  Feedback,
  HomeworkAttachmentView,
  HomeworkGradeEntry,
  HomeworkSubmissionsView,
  ID,
  StudentHomeworkItem,
} from '../../core/contracts/models';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { studentLoginsFor } from './homework.repo';
import {
  mapAssignment,
  mapAttachment,
  mapBatch,
  mapEnrollment,
  mapFeedback,
  mapStudent,
  mapSubject,
  mapSubmission,
} from './mappers';
import { assertOwnBatch } from './teacher-scope';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

const attachmentUrl = (att: Attachment): string =>
  att.storagePath.startsWith('http') ? att.storagePath : `https://storage.guruflow.dev/${att.storagePath}`;

function gradeLetter(percent: number): string {
  if (percent >= 90) return 'A+';
  if (percent >= 80) return 'A';
  if (percent >= 70) return 'B';
  if (percent >= 60) return 'C';
  if (percent >= 50) return 'D';
  if (percent >= 33) return 'E';
  return 'F';
}

export async function studentHomeworkLive(instituteId: ID): Promise<StudentHomeworkItem[]> {
  if (!live) return memoryFallback.assignments.forStudent(instituteId);
  const { data: auth } = await supabase.auth.getUser();
  const userId = auth.user?.id;
  if (!userId) return [];
  const { data: member } = await supabase.from('memberships').select('id').eq('institute_id', instituteId).eq('user_id', userId).eq('status', 'active').maybeSingle();
  if (!member) return [];
  const { data: smRows } = await supabase.from('student_memberships').select('student_id').eq('institute_id', instituteId).eq('membership_id', String(member.id));
  const studentId = smRows?.[0] ? String(smRows[0].student_id) : null;
  if (!studentId) return [];
  const { data: enrols } = await supabase.from('batch_students').select('batch_id').eq('institute_id', instituteId).eq('student_id', studentId).eq('status', 'active');
  const batchIds = (enrols ?? []).map((r) => String(r.batch_id));
  if (batchIds.length === 0) return [];
  const [bRes, sRes, aRes, subRes, fbRes, attRes] = await Promise.all([
    supabase.from('batches').select('*').eq('institute_id', instituteId).in('id', batchIds),
    supabase.from('subjects').select('*').eq('institute_id', instituteId),
    supabase.from('assignments').select('*').eq('institute_id', instituteId).in('batch_id', batchIds),
    supabase.from('submissions').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    supabase.from('feedback').select('*').eq('institute_id', instituteId).eq('student_id', studentId),
    supabase.from('attachments').select('*').eq('institute_id', instituteId).eq('entity_type', 'assignment'),
  ]);
  const attachmentsByAssignment = new Map<ID, Attachment[]>();
  for (const row of (attRes.data ?? []).map(mapAttachment)) {
    const list = attachmentsByAssignment.get(row.ownerId) ?? [];
    list.push(row);
    attachmentsByAssignment.set(row.ownerId, list);
  }
  return buildStudentHomeworkList({
    assignments: (aRes.data ?? []).map(mapAssignment), batches: (bRes.data ?? []).map(mapBatch),
    subjects: (sRes.data ?? []).map(mapSubject), submissions: (subRes.data ?? []).map(mapSubmission),
    feedback: (fbRes.data ?? []).map(mapFeedback), attachmentsByAssignment,
  });
}

export async function submissionsForAssignmentLive(instituteId: ID, assignmentId: ID): Promise<HomeworkSubmissionsView> {
  if (!live) return memoryFallback.submissions.forAssignment(instituteId, assignmentId);
  const { data: asgRow, error } = await supabase.from('assignments').select('*').eq('institute_id', instituteId).eq('id', assignmentId).single();
  if (error) throw handleSupabaseError(error);
  const assignment = mapAssignment(asgRow);
  await assertOwnBatch(instituteId, assignment.batchId);
  const [bRes, subjRes, enrolRes, stuRes, subRes, fbRes, asgAttRes, subAttRes] = await Promise.all([
    supabase.from('batches').select('*').eq('institute_id', instituteId).eq('id', assignment.batchId).single(),
    assignment.subjectId
      ? supabase.from('subjects').select('name').eq('institute_id', instituteId).eq('id', assignment.subjectId).maybeSingle()
      : Promise.resolve({ data: null, error: null }),
    supabase.from('batch_students').select('*').eq('institute_id', instituteId).eq('batch_id', assignment.batchId).eq('status', 'active'),
    supabase.from('student_profiles').select('*').eq('institute_id', instituteId),
    supabase.from('submissions').select('*').eq('institute_id', instituteId).eq('assignment_id', assignmentId),
    supabase.from('feedback').select('*').eq('institute_id', instituteId).eq('batch_id', assignment.batchId),
    supabase.from('attachments').select('*').eq('institute_id', instituteId).eq('entity_type', 'assignment').eq('entity_id', assignmentId),
    supabase.from('attachments').select('*').eq('institute_id', instituteId).eq('entity_type', 'submission').eq('batch_id', assignment.batchId),
  ]);
  if (bRes.error) throw handleSupabaseError(bRes.error);
  const submissions = (subRes.data ?? []).map(mapSubmission);
  const subIds = new Set(submissions.map((s) => s.id));
  const { files: assignmentAttachments, linkUrl } = splitAssignmentAttachments((asgAttRes.data ?? []).map(mapAttachment), attachmentUrl);
  const submissionAttachments = new Map<ID, HomeworkAttachmentView[]>();
  for (const att of (subAttRes.data ?? []).map(mapAttachment)) {
    if (!subIds.has(att.ownerId)) continue;
    const list = submissionAttachments.get(att.ownerId) ?? [];
    list.push({ id: att.id, fileName: att.fileName, mimeType: att.mimeType, sizeBytes: att.sizeBytes, url: attachmentUrl(att) });
    submissionAttachments.set(att.ownerId, list);
  }
  return buildHomeworkSubmissionsView({
    assignment, batch: mapBatch(bRes.data), subjectName: subjRes.data ? String((subjRes.data as { name?: string }).name ?? '') : null,
    enrollments: (enrolRes.data ?? []).map(mapEnrollment), students: (stuRes.data ?? []).map(mapStudent),
    submissions, feedback: (fbRes.data ?? []).map(mapFeedback).filter((f) => subIds.has(f.submissionId)),
    assignmentAttachments, submissionAttachments, linkUrl,
  });
}

async function upsertStudentGradeLive(
  instituteId: ID,
  assignmentId: ID,
  batchId: ID,
  teacherId: ID | null,
  maxMarks: number,
  userId: ID | null,
  studentId: ID,
  marksAwarded: number | null | undefined,
  comment?: string | null,
): Promise<Feedback> {
  const now = new Date().toISOString();
  const { data: existingSub } = await supabase.from('submissions').select('*').eq('institute_id', instituteId).eq('assignment_id', assignmentId).eq('student_id', studentId).maybeSingle();
  const { data: subRow, error: sErr } = existingSub
    ? await supabase.from('submissions').update({ status: 'returned', submitted_at: existingSub.submitted_at ?? now }).eq('id', existingSub.id).select().single()
    : await supabase.from('submissions').insert({ institute_id: instituteId, assignment_id: assignmentId, batch_id: batchId, student_id: studentId, submitted_at: now, status: 'returned' }).select().single();
  if (sErr) throw handleSupabaseError(sErr);
  const sub = mapSubmission(subRow);
  const { data: existingFb } = await supabase.from('feedback').select('*').eq('institute_id', instituteId).eq('submission_id', sub.id).maybeSingle();
  const resolved = marksAwarded === undefined ? (existingFb?.marks_awarded != null ? Number(existingFb.marks_awarded) : null) : marksAwarded;
  const grade = resolved === null ? null : gradeLetter((resolved / maxMarks) * 100);
  const { data: fbRow, error: fErr } = existingFb
    ? await supabase.from('feedback').update({ marks_awarded: resolved, grade, comment: comment === undefined ? existingFb.comment : comment, given_by: userId, given_at: now }).eq('id', existingFb.id).select().single()
    : await supabase.from('feedback').insert({ institute_id: instituteId, submission_id: sub.id, batch_id: batchId, student_id: studentId, teacher_id: teacherId, marks_awarded: resolved, grade, comment: comment ?? null, given_by: userId, given_at: now }).select().single();
  if (fErr) throw handleSupabaseError(fErr);
  return mapFeedback(fbRow);
}

export async function saveGradesLive(instituteId: ID, assignmentId: ID, entries: HomeworkGradeEntry[]): Promise<Feedback[]> {
  if (!live) return memoryFallback.submissions.saveGrades(instituteId, assignmentId, entries);
  if (entries.length === 0) throw new BackendError('VALIDATION', 'Enter at least one grade to save.');
  const { data: asgRow, error } = await supabase.from('assignments').select('*').eq('institute_id', instituteId).eq('id', assignmentId).single();
  if (error) throw handleSupabaseError(error);
  const assignment = mapAssignment(asgRow);
  await assertOwnBatch(instituteId, assignment.batchId);
  const maxMarks = assignment.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;
  for (const e of entries) assertValidGrade(e.marksAwarded, maxMarks);
  const { data: auth } = await supabase.auth.getUser();
  const userId = auth.user?.id ?? null;
  const out: Feedback[] = [];
  for (const e of entries) {
    out.push(await upsertStudentGradeLive(instituteId, assignment.id, assignment.batchId, assignment.teacherId, maxMarks, userId, e.studentId, e.marksAwarded, e.comment));
  }
  return out;
}

export async function approveLive(instituteId: ID, assignmentId: ID, studentId: ID, marksAwarded?: number | null): Promise<Feedback> {
  if (!live) return memoryFallback.submissions.approve(instituteId, assignmentId, studentId, marksAwarded);
  const { data: asgRow, error } = await supabase.from('assignments').select('*').eq('institute_id', instituteId).eq('id', assignmentId).single();
  if (error) throw handleSupabaseError(error);
  const assignment = mapAssignment(asgRow);
  await assertOwnBatch(instituteId, assignment.batchId);
  const maxMarks = assignment.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;
  assertValidGrade(marksAwarded, maxMarks);
  const { data: auth } = await supabase.auth.getUser();
  return upsertStudentGradeLive(instituteId, assignment.id, assignment.batchId, assignment.teacherId, maxMarks, auth.user?.id ?? null, studentId, marksAwarded);
}

export async function askAgainLive(instituteId: ID, assignmentId: ID, studentId: ID, comment?: string | null): Promise<AskAgainResult> {
  if (!live) return memoryFallback.submissions.askAgain(instituteId, assignmentId, studentId, comment);
  const { data: asgRow, error } = await supabase.from('assignments').select('*').eq('institute_id', instituteId).eq('id', assignmentId).single();
  if (error) throw handleSupabaseError(error);
  const assignment = mapAssignment(asgRow);
  await assertOwnBatch(instituteId, assignment.batchId);
  const { data: batchRow } = await supabase.from('batches').select('name').eq('institute_id', instituteId).eq('id', assignment.batchId).single();
  const { data: subRow, error: sErr } = await supabase.from('submissions').upsert({
    institute_id: instituteId, assignment_id: assignment.id, batch_id: assignment.batchId, student_id: studentId,
    submitted_at: null, status: 'pending',
  }, { onConflict: 'assignment_id,student_id' }).select().single();
  if (sErr) throw handleSupabaseError(sErr);
  const logins = await studentLoginsFor(instituteId, [studentId]);
  if (logins.length > 0) {
    const batchName = String(batchRow?.name ?? 'Batch');
    const { error: nErr } = await supabase.from('notifications').insert(
      logins.map((userId) => ({
        institute_id: instituteId, user_id: userId, type: 'homework_ask_again',
        title: `Please resubmit: ${assignment.title}`,
        body: comment?.trim() || `${batchName} · Your teacher asked you to submit "${assignment.title}" again.`,
        data: { screen: 'homework', assignmentId: assignment.id, batchId: assignment.batchId, studentId }, channel: 'in_app',
      })),
    );
    if (nErr) throw handleSupabaseError(nErr);
  }
  return { submission: mapSubmission(subRow), notified: logins.length > 0 };
}
