import { BackendError } from '../../core/contracts/errors';
import {
  buildHomeworkTracker,
  getAssignValidationErrors,
  HOMEWORK_DEFAULT_MAX_MARKS,
  isSubmittedStatus,
  LINK_MIME,
} from '../../core/contracts/homework';
import type {
  AssignHomeworkInput,
  AssignHomeworkResult,
  Batch,
  HomeworkTracker,
  ID,
  RemindHomeworkResult,
} from '../../core/contracts/models';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { mapAssignment, mapBatch, mapEnrollment, mapSubject, mapSubmission } from './mappers';
import { assertOwnBatch, ownBatches, teacherScope } from './teacher-scope';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

export async function homeworkAlertsOn(instituteId: ID): Promise<boolean> {
  const { data, error } = await supabase.from('institute_settings').select('features').eq('institute_id', instituteId).maybeSingle();
  if (error) throw handleSupabaseError(error);
  return ((data?.features as Record<string, unknown> | undefined) ?? {}).homeworkAlerts === true;
}

export async function studentLoginsFor(instituteId: ID, studentIds: ID[]): Promise<ID[]> {
  if (studentIds.length === 0) return [];
  const { data: links, error } = await supabase.from('student_memberships').select('membership_id').eq('institute_id', instituteId).in('student_id', studentIds);
  if (error) throw handleSupabaseError(error);
  const ids = (links ?? []).map((row) => String(row.membership_id));
  if (ids.length === 0) return [];
  const { data: members, error: mErr } = await supabase.from('memberships').select('user_id').eq('institute_id', instituteId).eq('status', 'active').in('id', ids);
  if (mErr) throw handleSupabaseError(mErr);
  return [...new Set((members ?? []).map((row) => String(row.user_id)))];
}

async function parentLoginsFor(instituteId: ID, studentIds: ID[]): Promise<ID[]> {
  if (studentIds.length === 0) return [];
  const { data: pLinks, error } = await supabase.from('parent_links').select('guardian_id').eq('institute_id', instituteId).in('student_id', studentIds);
  if (error) throw handleSupabaseError(error);
  const gIds = (pLinks ?? []).map((row) => String(row.guardian_id));
  if (gIds.length === 0) return [];
  const { data: guardians, error: gErr } = await supabase.from('guardians').select('membership_id').eq('institute_id', instituteId).in('id', gIds);
  if (gErr) throw handleSupabaseError(gErr);
  const mIds = (guardians ?? []).map((r) => (r.membership_id ? String(r.membership_id) : null)).filter((id): id is string => Boolean(id));
  if (mIds.length === 0) return [];
  const { data: members, error: mErr } = await supabase.from('memberships').select('user_id').eq('institute_id', instituteId).eq('status', 'active').in('id', mIds);
  if (mErr) throw handleSupabaseError(mErr);
  return [...new Set((members ?? []).map((row) => String(row.user_id)))];
}

export async function assignHomeworkLive(instituteId: ID, input: AssignHomeworkInput): Promise<AssignHomeworkResult> {
  if (!live) return memoryFallback.assignments.assign(instituteId, input);
  await assertOwnBatch(instituteId, input.batchId);
  const dueDate = input.dueAt.slice(0, 10);
  const dueTime = input.dueAt.slice(11, 16) || '20:00';
  const firstErr = Object.values(getAssignValidationErrors({
    batchId: input.batchId, subjectId: input.subjectId, title: input.title, dueDate, dueTime,
    maxMarks: input.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS, linkUrl: input.linkUrl,
  }))[0];
  if (firstErr) throw new BackendError('VALIDATION', firstErr);

  const scope = await teacherScope(instituteId);
  const { data: userRes } = await supabase.auth.getUser();
  const userId = userRes.user?.id ?? null;
  const { data: batchRow, error: bErr } = await supabase.from('batches').select('*').eq('institute_id', instituteId).eq('id', input.batchId).single();
  if (bErr) throw handleSupabaseError(bErr);
  const batch = mapBatch(batchRow);

  const { data: inserted, error: insErr } = await supabase.from('assignments').insert({
    institute_id: instituteId, batch_id: batch.id, subject_id: input.subjectId ?? batch.subjectId ?? null,
    teacher_id: scope?.teacherIds[0] ?? batch.teacherId ?? null, title: input.title.trim(),
    instructions: input.description?.trim() ? input.description.trim() : null,
    assigned_on: new Date().toISOString().slice(0, 10), due_at: input.dueAt,
    max_marks: input.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS,
    submission_type: input.file ? 'upload' : input.linkUrl?.trim() ? 'online' : 'written',
    status: 'published', created_by: userId,
  }).select().single();
  if (insErr) throw handleSupabaseError(insErr);
  const assignment = mapAssignment(inserted);

  if (input.file) {
    const name = input.file.fileName.trim();
    const { error: attErr } = await supabase.from('attachments').insert({
      institute_id: instituteId, entity_type: 'assignment', entity_id: assignment.id, batch_id: batch.id,
      file_name: name, storage_path: `uploads/${instituteId}/assignment/${assignment.id}/${name}`,
      mime_type: input.file.mimeType ?? 'application/octet-stream', size_bytes: input.file.sizeBytes ?? null, uploaded_by: userId,
    });
    if (attErr) throw handleSupabaseError(attErr);
  }
  if (input.linkUrl?.trim()) {
    const { error: linkErr } = await supabase.from('attachments').insert({
      institute_id: instituteId, entity_type: 'assignment', entity_id: assignment.id, batch_id: batch.id,
      file_name: input.linkUrl.trim(), storage_path: `uploads/${instituteId}/assignment/${assignment.id}/link`,
      mime_type: LINK_MIME, uploaded_by: userId,
    });
    if (linkErr) throw handleSupabaseError(linkErr);
  }

  const alertsEnabled = await homeworkAlertsOn(instituteId);
  if (input.notifyStudents === false || !alertsEnabled) {
    return { assignment, studentsNotified: 0, parentsNotified: 0, alertsDisabled: !alertsEnabled };
  }
  const { data: enrols, error: eErr } = await supabase.from('batch_students').select('student_id').eq('institute_id', instituteId).eq('batch_id', batch.id).eq('status', 'active');
  if (eErr) throw handleSupabaseError(eErr);
  const sIds = (enrols ?? []).map((r) => String(r.student_id));
  const [studentUsers, parentUsers] = await Promise.all([studentLoginsFor(instituteId, sIds), parentLoginsFor(instituteId, sIds)]);
  const rows = [
    ...studentUsers.map((uid) => ({
      institute_id: instituteId, user_id: uid, type: 'homework_assigned', title: `New homework: ${assignment.title}`,
      body: `${batch.name} · Due ${dueDate}`, data: { screen: 'homework', assignmentId: assignment.id, batchId: batch.id, audience: 'student' }, channel: 'in_app',
    })),
    ...parentUsers.map((uid) => ({
      institute_id: instituteId, user_id: uid, type: 'homework_assigned', title: `Homework assigned: ${assignment.title}`,
      body: `${batch.name} · Due ${dueDate}`, data: { screen: 'homework', assignmentId: assignment.id, batchId: batch.id, audience: 'parent' }, channel: 'in_app',
    })),
  ];
  if (rows.length > 0) {
    const { error: nErr } = await supabase.from('notifications').insert(rows);
    if (nErr) throw handleSupabaseError(nErr);
  }
  return { assignment, studentsNotified: studentUsers.length, parentsNotified: parentUsers.length, alertsDisabled: false };
}

export async function homeworkTrackerLive(instituteId: ID, batchId?: ID | null): Promise<HomeworkTracker> {
  if (!live) return memoryFallback.assignments.tracker(instituteId, { batchId });
  if (batchId) await assertOwnBatch(instituteId, batchId);
  const scope = await teacherScope(instituteId);
  let batches: Batch[];
  if (scope) batches = await ownBatches(instituteId, scope);
  else {
    const { data, error } = await supabase.from('batches').select('*').eq('institute_id', instituteId);
    if (error) throw handleSupabaseError(error);
    batches = (data ?? []).map(mapBatch);
  }
  const batchIds = batches.map((b) => b.id);
  if (batchIds.length === 0) return { active: [], closed: [], alertsEnabled: await homeworkAlertsOn(instituteId) };
  const [asgRes, subRes, enrolRes, subjRes, alertsEnabled] = await Promise.all([
    supabase.from('assignments').select('*').eq('institute_id', instituteId).in('batch_id', batchIds),
    supabase.from('submissions').select('*').eq('institute_id', instituteId).in('batch_id', batchIds),
    supabase.from('batch_students').select('*').eq('institute_id', instituteId).eq('status', 'active').in('batch_id', batchIds),
    supabase.from('subjects').select('*').eq('institute_id', instituteId),
    homeworkAlertsOn(instituteId),
  ]);
  for (const r of [asgRes, subRes, enrolRes, subjRes]) if (r.error) throw handleSupabaseError(r.error);
  return buildHomeworkTracker({
    assignments: (asgRes.data ?? []).map(mapAssignment), batches, subjects: (subjRes.data ?? []).map(mapSubject),
    enrollments: (enrolRes.data ?? []).map(mapEnrollment), submissions: (subRes.data ?? []).map(mapSubmission),
    alertsEnabled, now: new Date().toISOString(), batchId,
  });
}

export async function remindPendingLive(instituteId: ID, assignmentId: ID): Promise<RemindHomeworkResult> {
  if (!live) return memoryFallback.assignments.remindPending(instituteId, assignmentId);
  const { data: asgRow, error } = await supabase.from('assignments').select('*').eq('institute_id', instituteId).eq('id', assignmentId).single();
  if (error) throw handleSupabaseError(error);
  const assignment = mapAssignment(asgRow);
  await assertOwnBatch(instituteId, assignment.batchId);
  const [{ data: batchRow }, { data: enrols }, { data: subs }] = await Promise.all([
    supabase.from('batches').select('name').eq('institute_id', instituteId).eq('id', assignment.batchId).single(),
    supabase.from('batch_students').select('student_id').eq('institute_id', instituteId).eq('batch_id', assignment.batchId).eq('status', 'active'),
    supabase.from('submissions').select('*').eq('institute_id', instituteId).eq('assignment_id', assignmentId),
  ]);
  const submittedIds = new Set((subs ?? []).map(mapSubmission).filter((s) => isSubmittedStatus(s.status)).map((s) => s.studentId));
  const pendingIds = (enrols ?? []).map((r) => String(r.student_id)).filter((id) => !submittedIds.has(id));
  const logins = await studentLoginsFor(instituteId, pendingIds);
  if (logins.length > 0) {
    const batchName = String(batchRow?.name ?? 'Batch');
    const { error: nErr } = await supabase.from('notifications').insert(
      logins.map((userId) => ({
        institute_id: instituteId, user_id: userId, type: 'homework_reminder', title: `Reminder: ${assignment.title}`,
        body: `Please submit "${assignment.title}" for ${batchName}.`,
        data: { screen: 'homework', assignmentId: assignment.id, batchId: assignment.batchId }, channel: 'in_app',
      })),
    );
    if (nErr) throw handleSupabaseError(nErr);
  }
  return { notified: logins.length, pendingCount: pendingIds.length };
}
