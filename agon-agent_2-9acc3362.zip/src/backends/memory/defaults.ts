import type * as M from '../../core/contracts/models';
import { addDays, nowIso, nulls, todayIso } from './store';

/** Everything a create call may leave out. A missing field here is a type error. */
type Rest<T, Req extends keyof M.Draft<T> = never> = Omit<M.Draft<T>, Req>;

export const settings = (): M.InstituteSettings => ({
  academicYear: null,
  timezone: 'Asia/Kolkata',
  currency: 'INR',
  locale: 'en-IN',
  workingDays: [1, 2, 3, 4, 5, 6],
  attendanceMode: 'daily',
  minAttendancePercent: 75,
  passPercent: 33,
  lateFeePerDay: 0,
  receiptPrefix: null,
  allowJoinRequests: true,
  features: { attendanceAlerts: true, homeworkAlerts: true },
});

export const institute = (): Rest<M.Institute, 'name' | 'code' | 'ownerId'> => ({
  ...nulls('tagline', 'phone', 'email', 'address', 'city', 'state', 'pincode', 'logoUrl'),
  country: 'IN',
  status: 'active',
  settings: settings(),
});

export const profile = (): Rest<M.Profile, 'userId' | 'fullName'> =>
  nulls('email', 'phone', 'avatarUrl', 'gender', 'dateOfBirth', 'city', 'state', 'bio');

export const branch = (): Rest<M.Branch, 'name' | 'code'> => ({
  ...nulls('address', 'city', 'state', 'pincode', 'phone'),
  isMain: false,
  status: 'active',
});

export const invitation = (): Rest<M.Invitation, 'role'> => ({
  ...nulls('email', 'phone', 'fullName', 'invitedBy', 'acceptedBy', 'acceptedAt'),
  status: 'pending',
  expiresAt: `${addDays(todayIso(), 7)}T23:59:59.000Z`,
});

export const staff = (): Rest<M.StaffRecord> => ({
  ...nulls('userId', 'teacherId', 'employeeCode', 'designation', 'department', 'joinedOn', 'leftOn'),
  ...nulls('salaryAmount', 'phone', 'email', 'emergencyContact', 'bankDetails'),
  employmentType: 'full_time',
  salaryPeriod: 'monthly',
  status: 'active',
});

export const teacher = (): Rest<M.Teacher, 'fullName'> => ({
  ...nulls('userId', 'branchId', 'specialization', 'qualification', 'experienceYears', 'bio', 'photoUrl'),
  status: 'active',
});

export const workload = (): Rest<M.Workload, 'teacherId' | 'weekStart'> => ({
  periodsAssigned: 0,
  periodsTaken: 0,
  hoursAssigned: 0,
  hoursTaken: 0,
  notes: null,
});

export const student = (): Rest<M.Student, 'fullName'> => ({
  ...nulls('branchId', 'admissionNo', 'dateOfBirth', 'gender', 'phone', 'email', 'address', 'city'),
  ...nulls('schoolName', 'classGrade', 'bloodGroup', 'photoUrl'),
  admittedOn: todayIso(),
  status: 'active',
});

export const guardian = (): Rest<M.Guardian, 'fullName'> => ({
  ...nulls('membershipId', 'phone', 'email', 'occupation', 'address'),
  relation: 'guardian',
});

export const batch = (): Rest<M.Batch, 'name' | 'academicYear'> => ({
  ...nulls('branchId', 'classroomId', 'grade', 'section', 'capacity', 'startsOn', 'endsOn'),
  status: 'active',
});

export const subject = (): Rest<M.Subject, 'name' | 'code'> => ({
  ...nulls('color', 'description'),
  isActive: true,
});

export const timetable = (): Rest<M.Timetable, 'batchId' | 'dayOfWeek' | 'startsAt' | 'endsAt'> =>
  nulls('subjectId', 'teacherId', 'classroomId', 'validFrom', 'validTo');

export const classroom = (): Rest<M.Classroom, 'name'> => ({
  ...nulls('branchId', 'capacity', 'floor'),
  facilities: [],
  status: 'active',
});

export const assignment = (): Rest<M.Assignment, 'batchId' | 'title'> => ({
  ...nulls('subjectId', 'teacherId', 'instructions', 'dueAt', 'maxMarks', 'createdBy'),
  assignedOn: todayIso(),
  submissionType: 'written',
  status: 'draft',
});

export const exam = (): Rest<M.Exam, 'batchId' | 'name'> => ({
  ...nulls('subjectId', 'startsOn', 'endsOn', 'totalMarks', 'publishedAt', 'createdBy'),
  examType: 'unit_test',
  passPercent: 33,
  status: 'draft',
});

export const examQuestion = (): Rest<M.ExamQuestion, 'examId' | 'questionNo' | 'text' | 'batchId'> => ({
  ...nulls('subjectId', 'options', 'answerKey', 'topic'),
  questionType: 'short',
  maxMarks: 1,
});

export const material = (): Rest<M.Material, 'title'> => ({
  ...nulls('batchId', 'subjectId', 'teacherId', 'description', 'url', 'storagePath', 'topic', 'uploadedBy'),
  materialType: 'notes',
  isPublished: true,
});

export const practiceQuestion = (): Rest<M.PracticeQuestion, 'text'> => ({
  ...nulls('batchId', 'subjectId', 'topic', 'options', 'correctAnswer', 'explanation', 'createdBy'),
  difficulty: 'medium',
  questionType: 'mcq',
  marks: 1,
  isPublished: true,
});

export const quiz = (): Rest<M.Quiz, 'batchId' | 'title'> => ({
  ...nulls('subjectId', 'teacherId', 'description', 'durationMinutes', 'totalMarks', 'opensAt', 'closesAt', 'createdBy'),
  questionIds: [],
  status: 'draft',
});

export const studyTask = (): Rest<M.StudyTask, 'studentId' | 'title'> => ({
  ...nulls('subjectId', 'notes', 'dueOn', 'completedAt', 'assignedBy'),
  priority: 'medium',
  status: 'todo',
  source: 'self',
});

export const studentGoal = (): Rest<M.StudentGoal, 'studentId' | 'title'> => ({
  ...nulls('subjectId', 'description', 'targetValue', 'currentValue', 'targetDate', 'createdBy'),
  metric: 'custom',
  startsOn: todayIso(),
  status: 'active',
});

export const feeStructure = (): Rest<M.FeeStructure, 'name' | 'academicYear' | 'totalAmount'> => ({
  batchId: null,
  installmentCount: 1,
  frequency: 'term',
  components: [],
  lateFeePerDay: 0,
  isActive: true,
  version: 1,
  supersededById: null,
  batchIds: [],
  schedule: [],
  discounts: [],
});

export const payment = (): Rest<M.Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'> => ({
  ...nulls('installmentId', 'referenceNo', 'receivedBy', 'notes'),
  paidAt: nowIso(),
  status: 'completed',
});

export const notice = (): Rest<M.Notice, 'title'> => ({
  ...nulls('batchId', 'publishedAt', 'expiresAt', 'createdBy'),
  body: '',
  category: 'general',
  audience: ['owner', 'admin', 'teacher', 'student', 'parent'],
  isPinned: false,
});

export const notification = (): Rest<M.AppNotification, 'userId' | 'title'> => ({
  ...nulls('body', 'readAt'),
  type: 'general',
  data: {},
  channel: 'in_app',
  sentAt: nowIso(),
});

export const conversation = (): Rest<M.Conversation, 'participantIds'> => ({
  ...nulls('title', 'studentId', 'lastMessagePreview', 'lastMessageAt', 'createdBy'),
  kind: 'direct',
  messages: [],
  isArchived: false,
});

export const doubt = (): Rest<M.Doubt, 'batchId' | 'studentId' | 'question'> => ({
  ...nulls('subjectId', 'teacherId', 'askedBy', 'topic', 'answer', 'answeredBy', 'answeredAt'),
  status: 'open',
});

export const meeting = (): Rest<M.MeetingRequest, 'studentId' | 'teacherId'> => ({
  ...nulls('guardianId', 'requestedBy', 'reason', 'preferredAt', 'scheduledAt', 'durationMinutes'),
  ...nulls('responseNote', 'respondedAt'),
  mode: 'in_person',
  status: 'pending',
});

export const lead = (): Rest<M.AdmissionLead, 'studentName'> => ({
  ...nulls('branchId', 'guardianName', 'phone', 'email', 'classInterested', 'subjectInterest', 'schoolName', 'assignedTo'),
  ...nulls('expectedFee', 'nextFollowupAt', 'nextFollowupNote', 'lostReason', 'convertedStudentId', 'notes'),
  source: 'walk_in',
  stage: 'new',
});

export const followup = (): Rest<M.LeadFollowup, 'leadId'> => ({
  ...nulls('summary', 'outcome', 'nextFollowupAt', 'doneBy'),
  channel: 'call',
  followupAt: nowIso(),
});

export const auditLog = (): Rest<M.AuditLog, 'action'> =>
  nulls('actorId', 'actorRole', 'targetType', 'targetId', 'before', 'after', 'ipAddress', 'userAgent');

export const bookmark = (): Rest<M.Bookmark, 'userId' | 'targetType' | 'targetId'> => ({ note: null });
