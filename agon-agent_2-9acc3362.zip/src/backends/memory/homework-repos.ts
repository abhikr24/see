import type { Assignment, ID } from '../../core/contracts/models';
import type { AssignmentRepo, SubmissionRepo } from '../../core/contracts/ports';
import { crud, type Db } from './db';
import * as D from './defaults';
import {
  assignHomework,
  callerStudentIds,
  homeworkTracker,
  remindPendingHomework,
  studentEnrolledBatchIds,
  studentHomeworkList,
} from './homework';
import {
  approveSubmission,
  askStudentAgain,
  saveHomeworkGrades,
  submissionsForAssignment,
} from './homework-submissions';
import { defined, fail, nowIso } from './store';
import { teacherBatchScope, visibleBatch } from './teacher-scope';

function callerIsStudentOrParent(db: Db, instituteId: ID): boolean {
  if (!db.session.userId) return false;
  const membership = db.memberships.find(instituteId, { userId: db.session.userId, status: 'active' });
  return membership?.role === 'student' || membership?.role === 'parent';
}

export function assignmentRepo(db: Db): AssignmentRepo {
  const base = crud<Assignment, 'batchId' | 'title'>(db.assignments, D.assignment);
  const guardAssignment = (instituteId: ID, id: ID): Assignment => {
    const row = db.assignments.get(instituteId, id);
    if (callerIsStudentOrParent(db, instituteId)) {
      const batches = studentEnrolledBatchIds(db, instituteId);
      if (row.status === 'draft' || !batches.has(row.batchId)) fail('NOT_FOUND', 'Assignment not found');
      return row;
    }
    visibleBatch(db, instituteId, row.batchId);
    return row;
  };
  return {
    ...base,
    list: async (instituteId, query) => {
      db.institutes.get(instituteId, instituteId);
      if (callerIsStudentOrParent(db, instituteId)) {
        const batches = studentEnrolledBatchIds(db, instituteId);
        return db.assignments.page(
          instituteId,
          { sort: { field: 'createdAt', direction: 'desc' }, ...query },
          {},
          (a) => a.status !== 'draft' && batches.has(a.batchId),
        );
      }
      const scope = teacherBatchScope(db, instituteId);
      if (!scope) return db.assignments.page(instituteId, { sort: { field: 'createdAt', direction: 'desc' }, ...query });
      if (query?.where?.batchId && !scope.has(query.where.batchId)) fail('NOT_FOUND', 'Batch not found');
      return db.assignments.page(
        instituteId,
        { sort: { field: 'createdAt', direction: 'desc' }, ...query },
        {},
        (a) => scope.has(a.batchId),
      );
    },
    get: async (instituteId, id) => guardAssignment(instituteId, id),
    create: async (instituteId, input) => {
      visibleBatch(db, instituteId, input.batchId);
      if (!input.title.trim()) fail('VALIDATION', 'Title is required');
      return base.create(instituteId, { createdBy: db.session.userId, ...input });
    },
    update: async (instituteId, id, patch) => {
      guardAssignment(instituteId, id);
      if (patch.batchId) visibleBatch(db, instituteId, patch.batchId);
      return base.update(instituteId, id, patch);
    },
    remove: async (instituteId, id) => {
      guardAssignment(instituteId, id);
      return base.remove(instituteId, id);
    },
    publish: async (instituteId, id) => {
      guardAssignment(instituteId, id);
      return db.assignments.update(instituteId, id, { status: 'published' });
    },
    close: async (instituteId, id) => {
      guardAssignment(instituteId, id);
      return db.assignments.update(instituteId, id, { status: 'closed' });
    },
    assign: async (instituteId, input) => assignHomework(db, instituteId, input),
    tracker: async (instituteId, filter) => homeworkTracker(db, instituteId, filter?.batchId),
    remindPending: async (instituteId, assignmentId) => remindPendingHomework(db, instituteId, assignmentId),
    forStudent: async (instituteId) => studentHomeworkList(db, instituteId),
  };
}

export function submissionRepo(db: Db): SubmissionRepo {
  return {
    list: async (instituteId, query) => {
      db.institutes.get(instituteId, instituteId);
      if (callerIsStudentOrParent(db, instituteId)) {
        const ownStudents = new Set(callerStudentIds(db, instituteId));
        return db.submissions.page(instituteId, query, {}, (s) => ownStudents.has(s.studentId));
      }
      const scope = teacherBatchScope(db, instituteId);
      if (!scope) return db.submissions.page(instituteId, query);
      return db.submissions.page(instituteId, query, {}, (s) => scope.has(s.batchId));
    },
    get: async (instituteId, id) => {
      const sub = db.submissions.get(instituteId, id);
      if (callerIsStudentOrParent(db, instituteId)) {
        const ownStudents = new Set(callerStudentIds(db, instituteId));
        if (!ownStudents.has(sub.studentId)) fail('NOT_FOUND', 'Submission not found');
      } else {
        visibleBatch(db, instituteId, sub.batchId);
      }
      return sub;
    },
    submit: async (instituteId, { assignmentId, studentId, content = null }) => {
      const assignment = db.assignments.get(instituteId, assignmentId);
      if (assignment.status !== 'published') fail('FORBIDDEN', 'This assignment is not open for submissions');
      const enrolled = db.enrollments.find(instituteId, { batchId: assignment.batchId, studentId, status: 'active' });
      if (!enrolled) fail('VALIDATION', 'Student is not in the batch this assignment was set for');
      const submittedAt = nowIso();
      const status = assignment.dueAt && submittedAt > assignment.dueAt ? 'late' : 'submitted';
      const existing = db.submissions.find(instituteId, { assignmentId, studentId });
      return existing
        ? db.submissions.update(instituteId, existing.id, { content, submittedAt, status })
        : db.submissions.insert(instituteId, {
            assignmentId,
            batchId: assignment.batchId,
            studentId,
            content,
            submittedAt,
            status,
          });
    },
    grade: async (instituteId, submissionId, input) => {
      const submission = db.submissions.get(instituteId, submissionId);
      visibleBatch(db, instituteId, submission.batchId);
      const assignment = db.assignments.get(instituteId, submission.assignmentId);
      const { marksAwarded } = input;
      if (marksAwarded != null && (marksAwarded < 0 || (assignment.maxMarks !== null && marksAwarded > assignment.maxMarks))) {
        fail('VALIDATION', `Marks must be between 0 and ${assignment.maxMarks ?? 'the maximum'}`);
      }
      db.submissions.update(instituteId, submissionId, { status: 'returned' });
      const existing = db.feedback.find(instituteId, { submissionId });
      const givenBy = db.session.userId;
      const givenAt = nowIso();
      if (existing) return db.feedback.update(instituteId, existing.id, { ...defined(input), givenBy, givenAt });
      return db.feedback.insert(instituteId, {
        submissionId,
        batchId: submission.batchId,
        studentId: submission.studentId,
        teacherId: assignment.teacherId,
        marksAwarded: input.marksAwarded ?? null,
        grade: input.grade ?? null,
        comment: input.comment ?? null,
        givenBy,
        givenAt,
      });
    },
    getFeedback: async (instituteId, submissionId) => {
      const sub = db.submissions.get(instituteId, submissionId);
      if (!callerIsStudentOrParent(db, instituteId)) visibleBatch(db, instituteId, sub.batchId);
      return db.feedback.find(instituteId, { submissionId }) ?? null;
    },
    forAssignment: async (instituteId, assignmentId) => submissionsForAssignment(db, instituteId, assignmentId),
    saveGrades: async (instituteId, assignmentId, entries) => saveHomeworkGrades(db, instituteId, assignmentId, entries),
    approve: async (instituteId, assignmentId, studentId, marksAwarded) =>
      approveSubmission(db, instituteId, assignmentId, studentId, marksAwarded),
    askAgain: async (instituteId, assignmentId, studentId, comment) =>
      askStudentAgain(db, instituteId, assignmentId, studentId, comment),
  };
}
