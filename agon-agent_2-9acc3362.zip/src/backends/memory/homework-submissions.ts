import {
  assertValidGrade,
  buildHomeworkSubmissionsView,
  HOMEWORK_DEFAULT_MAX_MARKS,
  splitAssignmentAttachments,
} from '../../core/contracts/homework';
import type {
  AskAgainResult,
  Assignment,
  Attachment,
  Feedback,
  HomeworkAttachmentView,
  HomeworkGradeEntry,
  HomeworkSubmissionsView,
  ID,
} from '../../core/contracts/models';
import { emit, type Db } from './db';
import * as D from './defaults';
import { activeLoginIdsForStudent } from './homework';
import { fail, merge, nowIso } from './store';
import { visibleBatch } from './teacher-scope';

const uploadedUris = new Map<ID, string>();

export function rememberUploadedUri(attachmentId: ID, uri: string): void {
  uploadedUris.set(attachmentId, uri);
}

/** Crisp inline SVG worksheet preview so memory attachments render cleanly on web and native. */
export function worksheetPreviewUri(label: string): string {
  const safe = label.replace(/[^a-zA-Z0-9._ -]/g, '').slice(0, 24) || 'Worksheet';
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="160" height="120" viewBox="0 0 160 120">` +
    `<rect width="160" height="120" rx="12" fill="rgb(232,238,255)"/>` +
    `<rect x="16" y="14" width="128" height="92" rx="8" fill="rgb(255,255,255)" stroke="rgb(231,235,245)"/>` +
    `<rect x="28" y="28" width="58" height="6" rx="3" fill="rgb(16,27,76)"/>` +
    `<rect x="28" y="42" width="96" height="4" rx="2" fill="rgb(148,160,188)"/>` +
    `<rect x="28" y="54" width="84" height="4" rx="2" fill="rgb(148,160,188)"/>` +
    `<rect x="28" y="66" width="92" height="4" rx="2" fill="rgb(13,148,136)"/>` +
    `<text x="28" y="92" font-family="sans-serif" font-size="10" font-weight="700" fill="rgb(90,102,132)">${safe}</text>` +
    `</svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function resolveAttachmentUrl(att: Attachment): string {
  const direct = uploadedUris.get(att.id);
  if (direct) return direct;
  if (att.storagePath.startsWith('http://') || att.storagePath.startsWith('https://') || att.storagePath.startsWith('data:')) {
    return att.storagePath;
  }
  return worksheetPreviewUri(att.fileName);
}

function gradeLetter(percent: number): string {
  if (percent >= 90) return 'A+';
  if (percent >= 80) return 'A';
  if (percent >= 70) return 'B';
  if (percent >= 60) return 'C';
  if (percent >= 50) return 'D';
  if (percent >= 33) return 'E';
  return 'F';
}

export function submissionsForAssignment(db: Db, instituteId: ID, assignmentId: ID): HomeworkSubmissionsView {
  const assignment = db.assignments.get(instituteId, assignmentId);
  const batch = visibleBatch(db, instituteId, assignment.batchId);
  const subjectName = assignment.subjectId ? (db.subjects.all(instituteId, { id: assignment.subjectId })[0]?.name ?? null) : null;
  const submissions = db.submissions.all(instituteId, { assignmentId });
  const subIds = new Set(submissions.map((s) => s.id));
  const feedback = db.feedback.all(instituteId).filter((f) => subIds.has(f.submissionId));
  const { files: assignmentAttachments, linkUrl } = splitAssignmentAttachments(
    db.attachments.all(instituteId, { ownerType: 'assignment', ownerId: assignmentId }),
    resolveAttachmentUrl,
  );
  const submissionAttachments = new Map<ID, HomeworkAttachmentView[]>();
  for (const att of db.attachments.all(instituteId, { ownerType: 'submission' })) {
    if (!subIds.has(att.ownerId)) continue;
    const list = submissionAttachments.get(att.ownerId) ?? [];
    list.push({ id: att.id, fileName: att.fileName, mimeType: att.mimeType, sizeBytes: att.sizeBytes, url: resolveAttachmentUrl(att) });
    submissionAttachments.set(att.ownerId, list);
  }
  return buildHomeworkSubmissionsView({
    assignment,
    batch,
    subjectName,
    enrollments: db.enrollments.all(instituteId, { batchId: batch.id, status: 'active' }),
    students: db.students.all(instituteId),
    submissions,
    feedback,
    assignmentAttachments,
    submissionAttachments,
    linkUrl,
  });
}

function writeStudentGrade(
  db: Db,
  instituteId: ID,
  assignment: Assignment,
  studentId: ID,
  marksAwarded: number | null | undefined,
  comment?: string | null,
): Feedback {
  const maxMarks = assignment.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;
  const existingSub = db.submissions.find(instituteId, { assignmentId: assignment.id, studentId });
  const at = nowIso();
  const sub = existingSub
    ? db.submissions.update(instituteId, existingSub.id, {
        status: 'returned',
        submittedAt: existingSub.submittedAt ?? at,
      })
    : db.submissions.insert(instituteId, {
        assignmentId: assignment.id,
        batchId: assignment.batchId,
        studentId,
        content: null,
        submittedAt: at,
        status: 'returned',
      });
  const existingFb = db.feedback.find(instituteId, { submissionId: sub.id });
  const resolvedMarks = marksAwarded === undefined ? (existingFb?.marksAwarded ?? null) : marksAwarded;
  const grade = resolvedMarks === null ? null : gradeLetter((resolvedMarks / maxMarks) * 100);
  if (existingFb) {
    return db.feedback.update(instituteId, existingFb.id, {
      marksAwarded: resolvedMarks,
      grade,
      comment: comment === undefined ? existingFb.comment : comment,
      givenBy: db.session.userId,
      givenAt: at,
    });
  }
  return db.feedback.insert(instituteId, {
    submissionId: sub.id,
    batchId: assignment.batchId,
    studentId,
    teacherId: assignment.teacherId,
    marksAwarded: resolvedMarks,
    grade,
    comment: comment ?? null,
    givenBy: db.session.userId,
    givenAt: at,
  });
}

export function saveHomeworkGrades(db: Db, instituteId: ID, assignmentId: ID, entries: HomeworkGradeEntry[]): Feedback[] {
  const assignment = db.assignments.get(instituteId, assignmentId);
  visibleBatch(db, instituteId, assignment.batchId);
  if (entries.length === 0) fail('VALIDATION', 'Enter at least one grade to save.');
  const maxMarks = assignment.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;
  const enrolled = new Set(db.enrollments.all(instituteId, { batchId: assignment.batchId, status: 'active' }).map((e) => e.studentId));
  for (const entry of entries) {
    if (!enrolled.has(entry.studentId)) fail('VALIDATION', 'Student is not enrolled in this batch.');
    assertValidGrade(entry.marksAwarded, maxMarks);
  }
  return entries.map((entry) => writeStudentGrade(db, instituteId, assignment, entry.studentId, entry.marksAwarded, entry.comment));
}

export function approveSubmission(
  db: Db,
  instituteId: ID,
  assignmentId: ID,
  studentId: ID,
  marksAwarded?: number | null,
): Feedback {
  const assignment = db.assignments.get(instituteId, assignmentId);
  visibleBatch(db, instituteId, assignment.batchId);
  const enrolled = db.enrollments.find(instituteId, { batchId: assignment.batchId, studentId, status: 'active' });
  if (!enrolled) fail('VALIDATION', 'Student is not enrolled in this batch.');
  const maxMarks = assignment.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;
  assertValidGrade(marksAwarded, maxMarks);
  return writeStudentGrade(db, instituteId, assignment, studentId, marksAwarded);
}

export function askStudentAgain(
  db: Db,
  instituteId: ID,
  assignmentId: ID,
  studentId: ID,
  comment?: string | null,
): AskAgainResult {
  const assignment = db.assignments.get(instituteId, assignmentId);
  const batch = visibleBatch(db, instituteId, assignment.batchId);
  const enrolled = db.enrollments.find(instituteId, { batchId: batch.id, studentId, status: 'active' });
  if (!enrolled) fail('VALIDATION', 'Student is not enrolled in this batch.');
  const existing = db.submissions.find(instituteId, { assignmentId, studentId });
  const submission = existing
    ? db.submissions.update(instituteId, existing.id, { status: 'pending', submittedAt: null })
    : db.submissions.insert(instituteId, {
        assignmentId,
        batchId: batch.id,
        studentId,
        content: null,
        submittedAt: null,
        status: 'pending',
      });
  const fb = db.feedback.find(instituteId, { submissionId: submission.id });
  if (fb) db.feedback.update(instituteId, fb.id, { marksAwarded: null, grade: null, comment: comment ?? fb.comment });

  const logins = activeLoginIdsForStudent(db, instituteId, studentId);
  let notified = false;
  for (const userId of logins) {
    const row = db.notifications.insert(
      instituteId,
      merge(D.notification(), {
        userId,
        type: 'homework_ask_again',
        title: `Please resubmit: ${assignment.title}`,
        body: comment?.trim() || `${batch.name} · Your teacher asked you to submit "${assignment.title}" again.`,
        data: { screen: 'homework', assignmentId: assignment.id, batchId: batch.id, studentId },
      }),
    );
    emit(db, instituteId, 'notifications', 'created', row.id);
    notified = true;
  }
  return { submission, notified };
}
