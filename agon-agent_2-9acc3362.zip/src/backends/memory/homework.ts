import {
  buildHomeworkTracker,
  buildStudentHomeworkList,
  getAssignValidationErrors,
  HOMEWORK_DEFAULT_MAX_MARKS,
  isSubmittedStatus,
  LINK_MIME,
} from '../../core/contracts/homework';
import type {
  AssignHomeworkInput,
  AssignHomeworkResult,
  Attachment,
  HomeworkTracker,
  ID,
  RemindHomeworkResult,
  StudentHomeworkItem,
} from '../../core/contracts/models';
import { emit, type Db } from './db';
import * as D from './defaults';
import { rememberUploadedUri } from './homework-submissions';
import { fail, merge, nowIso, todayIso } from './store';
import { assignmentOf, callerRole, callerTeacher, teacherBatchScope, visibleBatch } from './teacher-scope';

export function homeworkAlertsEnabled(db: Db, instituteId: ID): boolean {
  const institute = db.institutes.get(instituteId, instituteId);
  return institute.settings.features?.homeworkAlerts === true;
}

/** Active student IDs belonging to the signed-in student or parent caller. */
export function callerStudentIds(db: Db, instituteId: ID): ID[] {
  const userId = db.session.userId;
  if (!userId) return [];
  const membership = db.memberships.find(instituteId, { userId, status: 'active' });
  if (!membership) return [];
  if (membership.role === 'student') {
    return db.studentMemberships.all(instituteId, { membershipId: membership.id }).map((sm) => sm.studentId);
  }
  if (membership.role === 'parent') {
    const guardianIds = db.guardians.all(instituteId, { membershipId: membership.id }).map((g) => g.id);
    return db.parentLinks
      .all(instituteId)
      .filter((link) => guardianIds.includes(link.guardianId))
      .map((link) => link.studentId);
  }
  return [];
}

export function studentEnrolledBatchIds(db: Db, instituteId: ID): Set<ID> {
  const studentIds = new Set(callerStudentIds(db, instituteId));
  const batchIds = new Set<ID>();
  for (const e of db.enrollments.all(instituteId, { status: 'active' })) {
    if (studentIds.has(e.studentId)) batchIds.add(e.batchId);
  }
  return batchIds;
}

export function activeLoginIdsForStudent(db: Db, instituteId: ID, studentId: ID): ID[] {
  const out = new Set<ID>();
  for (const sm of db.studentMemberships.all(instituteId, { studentId })) {
    const m = db.memberships.all(instituteId, { id: sm.membershipId, status: 'active' })[0];
    if (m) out.add(m.userId);
  }
  return [...out];
}

function activeParentLoginIdsForStudent(db: Db, instituteId: ID, studentId: ID): ID[] {
  const out = new Set<ID>();
  for (const link of db.parentLinks.all(instituteId, { studentId })) {
    const guardian = db.guardians.all(instituteId, { id: link.guardianId })[0];
    if (guardian?.membershipId) {
      const m = db.memberships.all(instituteId, { id: guardian.membershipId, status: 'active' })[0];
      if (m) out.add(m.userId);
    }
  }
  return [...out];
}

export function assignHomework(db: Db, instituteId: ID, input: AssignHomeworkInput): AssignHomeworkResult {
  const batch = visibleBatch(db, instituteId, input.batchId);
  if (input.subjectId) db.subjects.get(instituteId, input.subjectId);
  const dueDate = input.dueAt.slice(0, 10);
  const dueTime = input.dueAt.slice(11, 16) || '20:00';
  const errors = getAssignValidationErrors({
    batchId: input.batchId,
    subjectId: input.subjectId,
    title: input.title,
    dueDate,
    dueTime,
    maxMarks: input.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS,
    linkUrl: input.linkUrl,
  });
  const firstError = Object.values(errors)[0];
  if (firstError) fail('VALIDATION', firstError);

  const assigned = assignmentOf(db, instituteId, batch);
  const teacherId = callerTeacher(db, instituteId)?.id ?? assigned.teacherId;
  const subjectId = input.subjectId ?? assigned.subjectId;
  const maxMarks = input.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;

  const assignment = db.assignments.insert(
    instituteId,
    merge(D.assignment(), {
      batchId: batch.id,
      subjectId,
      teacherId,
      title: input.title.trim(),
      instructions: input.description?.trim() ? input.description.trim() : null,
      assignedOn: todayIso(),
      dueAt: input.dueAt,
      maxMarks,
      submissionType: input.file ? 'upload' : input.linkUrl?.trim() ? 'online' : 'written',
      status: 'published',
      createdBy: db.session.userId,
    }),
  );

  if (input.file) {
    const fileRow = db.attachments.insert(instituteId, {
      ownerType: 'assignment',
      ownerId: assignment.id,
      batchId: batch.id,
      studentId: null,
      fileName: input.file.fileName.trim(),
      storagePath: `${instituteId}/assignment/${assignment.id}/${input.file.fileName.trim()}`,
      mimeType: input.file.mimeType ?? 'application/octet-stream',
      sizeBytes: input.file.sizeBytes ?? null,
      uploadedBy: db.session.userId,
    });
    if (input.file.uri) rememberUploadedUri(fileRow.id, input.file.uri);
  }

  if (input.linkUrl?.trim()) {
    db.attachments.insert(instituteId, {
      ownerType: 'assignment',
      ownerId: assignment.id,
      batchId: batch.id,
      studentId: null,
      fileName: input.linkUrl.trim(),
      storagePath: `${instituteId}/assignment/${assignment.id}/link`,
      mimeType: LINK_MIME,
      sizeBytes: null,
      uploadedBy: db.session.userId,
    });
  }

  const alertsEnabled = homeworkAlertsEnabled(db, instituteId);
  const shouldNotify = input.notifyStudents !== false && alertsEnabled;
  let studentsNotified = 0;
  let parentsNotified = 0;

  if (shouldNotify) {
    const enrolledIds = db.enrollments.all(instituteId, { batchId: batch.id, status: 'active' }).map((e) => e.studentId);
    const studentUsers = new Set<ID>();
    const parentUsers = new Set<ID>();
    for (const sid of enrolledIds) {
      for (const uid of activeLoginIdsForStudent(db, instituteId, sid)) studentUsers.add(uid);
      for (const uid of activeParentLoginIdsForStudent(db, instituteId, sid)) parentUsers.add(uid);
    }
    for (const userId of studentUsers) {
      const row = db.notifications.insert(
        instituteId,
        merge(D.notification(), {
          userId,
          type: 'homework_assigned',
          title: `New homework: ${assignment.title}`,
          body: `${batch.name} · Due ${dueDate}`,
          data: { screen: 'homework', assignmentId: assignment.id, batchId: batch.id, audience: 'student' },
        }),
      );
      emit(db, instituteId, 'notifications', 'created', row.id);
      studentsNotified += 1;
    }
    for (const userId of parentUsers) {
      const row = db.notifications.insert(
        instituteId,
        merge(D.notification(), {
          userId,
          type: 'homework_assigned',
          title: `Homework assigned: ${assignment.title}`,
          body: `${batch.name} · Due ${dueDate}`,
          data: { screen: 'homework', assignmentId: assignment.id, batchId: batch.id, audience: 'parent' },
        }),
      );
      emit(db, instituteId, 'notifications', 'created', row.id);
      parentsNotified += 1;
    }
  }

  return { assignment, studentsNotified, parentsNotified, alertsDisabled: !alertsEnabled };
}

export function homeworkTracker(db: Db, instituteId: ID, batchId?: ID | null): HomeworkTracker {
  db.institutes.get(instituteId, instituteId);
  const role = callerRole(db, instituteId);
  if (role === 'student' || role === 'parent') fail('FORBIDDEN', 'Only staff may open the homework tracker');
  if (batchId) visibleBatch(db, instituteId, batchId);
  const scope = teacherBatchScope(db, instituteId);
  const batches = db.batches.all(instituteId).filter((b) => !scope || scope.has(b.id));
  return buildHomeworkTracker({
    assignments: db.assignments.all(instituteId),
    batches,
    subjects: db.subjects.all(instituteId),
    enrollments: db.enrollments.all(instituteId, { status: 'active' }),
    submissions: db.submissions.all(instituteId),
    alertsEnabled: homeworkAlertsEnabled(db, instituteId),
    now: nowIso(),
    batchId,
  });
}

export function remindPendingHomework(db: Db, instituteId: ID, assignmentId: ID): RemindHomeworkResult {
  const assignment = db.assignments.get(instituteId, assignmentId);
  const batch = visibleBatch(db, instituteId, assignment.batchId);
  const enrolled = db.enrollments.all(instituteId, { batchId: batch.id, status: 'active' }).map((e) => e.studentId);
  const submittedSet = new Set(
    db.submissions
      .all(instituteId, { assignmentId })
      .filter((s) => isSubmittedStatus(s.status))
      .map((s) => s.studentId),
  );
  const pendingIds = enrolled.filter((sid) => !submittedSet.has(sid));
  const recipients = new Set<ID>();
  for (const sid of pendingIds) {
    for (const uid of activeLoginIdsForStudent(db, instituteId, sid)) recipients.add(uid);
  }
  for (const userId of recipients) {
    const row = db.notifications.insert(
      instituteId,
      merge(D.notification(), {
        userId,
        type: 'homework_reminder',
        title: `Reminder: ${assignment.title}`,
        body: `Please submit "${assignment.title}" for ${batch.name}.`,
        data: { screen: 'homework', assignmentId: assignment.id, batchId: batch.id },
      }),
    );
    emit(db, instituteId, 'notifications', 'created', row.id);
  }
  return { notified: recipients.size, pendingCount: pendingIds.length };
}

export function studentHomeworkList(db: Db, instituteId: ID): StudentHomeworkItem[] {
  db.institutes.get(instituteId, instituteId);
  const studentIds = callerStudentIds(db, instituteId);
  if (studentIds.length === 0) return [];
  const batchIds = studentEnrolledBatchIds(db, instituteId);
  const batches = db.batches.all(instituteId).filter((b) => batchIds.has(b.id));
  const primaryStudentId = studentIds[0];
  const submissions = db.submissions.all(instituteId, { studentId: primaryStudentId });
  const feedback = db.feedback.all(instituteId, { studentId: primaryStudentId });
  const attachmentsByAssignment = new Map<ID, Attachment[]>();
  for (const att of db.attachments.all(instituteId, { ownerType: 'assignment' })) {
    const list = attachmentsByAssignment.get(att.ownerId) ?? [];
    list.push(att);
    attachmentsByAssignment.set(att.ownerId, list);
  }
  return buildStudentHomeworkList({
    assignments: db.assignments.all(instituteId),
    batches,
    subjects: db.subjects.all(instituteId),
    submissions,
    feedback,
    attachmentsByAssignment,
  });
}
