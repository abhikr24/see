import { BackendError } from './errors';
import type {
  Assignment, Attachment, Batch, Enrollment, Feedback, HomeworkAttachmentView,
  HomeworkSubmissionRow, HomeworkSubmissionsView, HomeworkTracker, HomeworkTrackerItem,
  ID, ISODateTime, Student, StudentHomeworkItem, Subject, Submission,
} from './models';

declare const __DEV__: boolean | undefined;

export const HOMEWORK_DEFAULT_MAX_MARKS = 20;
export const HOMEWORK_MAX_MARKS_LIMIT = 500;
export const LINK_MIME = 'text/uri-list';

export interface AssignValidationInput {
  batchId: string;
  subjectId?: string | null;
  title: string;
  dueDate: string;
  dueTime: string;
  maxMarks?: number | null;
  linkUrl?: string | null;
}

export interface AssignValidationErrors {
  batchId?: string;
  subjectId?: string;
  title?: string;
  dueDate?: string;
  dueTime?: string;
  maxMarks?: string;
  linkUrl?: string;
}

export interface HomeworkCounts {
  totalStudents: number;
  submittedCount: number;
  pendingCount: number;
  gradedCount: number;
  percentage: number;
}

/**
 * Asserts `submitted + pending === batchStudentCount`.
 * Logs a warning in development whenever the invariant is violated.
 */
export function assertHomeworkCounts(
  submitted: number,
  pending: number,
  batchStudentCount: number,
  assignmentId?: string,
): boolean {
  const valid = submitted + pending === batchStudentCount;
  const isDev = typeof __DEV__ !== 'undefined' ? __DEV__ : process.env.NODE_ENV !== 'production';
  if (isDev && !valid) {
    console.warn(
      `[homework] submitted (${submitted}) + pending (${pending}) !== batch student count (${batchStudentCount})` +
        (assignmentId ? ` for assignment ${assignmentId}` : ''),
    );
  }
  return valid;
}

export const isSubmittedStatus = (status: Submission['status']): boolean =>
  status === 'submitted' || status === 'late' || status === 'returned';

/** Independently accumulates submitted and pending over active batch students, then runs `assertHomeworkCounts`. */
export function computeHomeworkCounts(
  activeStudentIds: readonly ID[],
  submissions: readonly Submission[],
  assignmentId?: string,
): HomeworkCounts {
  const uniqueStudents = [...new Set(activeStudentIds)];
  const byStudent = new Map(submissions.map((sub) => [sub.studentId, sub]));
  let submittedCount = 0;
  let pendingCount = 0;
  let gradedCount = 0;
  for (const studentId of uniqueStudents) {
    const sub = byStudent.get(studentId);
    if (sub && isSubmittedStatus(sub.status)) {
      submittedCount += 1;
      if (sub.status === 'returned') gradedCount += 1;
    } else {
      pendingCount += 1;
    }
  }
  const totalStudents = uniqueStudents.length;
  assertHomeworkCounts(submittedCount, pendingCount, totalStudents, assignmentId);
  const percentage = totalStudents > 0 ? Math.round((submittedCount / totalStudents) * 100) : 0;
  return { totalStudents, submittedCount, pendingCount, gradedCount, percentage };
}

export function getAssignValidationErrors(input: AssignValidationInput): AssignValidationErrors {
  const errors: AssignValidationErrors = {};
  if (!input.batchId.trim()) errors.batchId = 'Choose a batch.';
  if (input.title.trim().length < 2) errors.title = 'Enter a title of at least 2 characters.';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.dueDate)) errors.dueDate = 'Choose a valid due date.';
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(input.dueTime)) errors.dueTime = 'Enter a valid time (HH:MM).';
  if (input.maxMarks !== undefined && input.maxMarks !== null) {
    if (!Number.isFinite(input.maxMarks) || input.maxMarks < 1 || input.maxMarks > HOMEWORK_MAX_MARKS_LIMIT) {
      errors.maxMarks = `Max marks must be between 1 and ${HOMEWORK_MAX_MARKS_LIMIT}.`;
    }
  }
  const link = input.linkUrl?.trim() ?? '';
  if (link.length > 0 && !/^https?:\/\/\S+$/i.test(link)) {
    errors.linkUrl = 'Link must start with https:// or http://';
  }
  return errors;
}

export function validateGradeValue(marks: number | null | undefined, maxMarks: number): string | null {
  if (marks === null || marks === undefined) return null;
  if (!Number.isFinite(marks) || marks < 0) return 'Grade must be 0 or higher.';
  if (marks > maxMarks) return `Grade cannot exceed ${maxMarks}.`;
  return null;
}

export function assertValidGrade(marks: number | null | undefined, maxMarks: number): void {
  const err = validateGradeValue(marks, maxMarks);
  if (err) throw new BackendError('VALIDATION', err);
}

export interface TrackerBuildInput {
  assignments: Assignment[];
  batches: Batch[];
  subjects: Subject[];
  enrollments: Enrollment[];
  submissions: Submission[];
  alertsEnabled: boolean;
  now: ISODateTime;
  batchId?: ID | null;
}

export function buildHomeworkTracker(input: TrackerBuildInput): HomeworkTracker {
  const batches = new Map(input.batches.map((b) => [b.id, b]));
  const subjects = new Map(input.subjects.map((s) => [s.id, s.name]));
  const rosterByBatch = new Map<ID, ID[]>();
  for (const e of input.enrollments) {
    if (e.status !== 'active' || !batches.has(e.batchId)) continue;
    const list = rosterByBatch.get(e.batchId) ?? [];
    list.push(e.studentId);
    rosterByBatch.set(e.batchId, list);
  }
  const subsByAssignment = new Map<ID, Submission[]>();
  for (const s of input.submissions) {
    const list = subsByAssignment.get(s.assignmentId) ?? [];
    list.push(s);
    subsByAssignment.set(s.assignmentId, list);
  }

  const active: HomeworkTrackerItem[] = [];
  const closed: HomeworkTrackerItem[] = [];
  const sorted = [...input.assignments]
    .filter((a) => a.status !== 'draft' && batches.has(a.batchId) && (!input.batchId || a.batchId === input.batchId))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || (a.dueAt ?? '9999').localeCompare(b.dueAt ?? '9999'));

  for (const a of sorted) {
    const batch = batches.get(a.batchId);
    if (!batch) continue;
    const counts = computeHomeworkCounts(rosterByBatch.get(a.batchId) ?? [], subsByAssignment.get(a.id) ?? [], a.id);
    const status: 'published' | 'closed' = a.status === 'closed' ? 'closed' : 'published';
    const item: HomeworkTrackerItem = {
      id: a.id,
      batchId: a.batchId,
      batchName: batch.name,
      subjectId: a.subjectId,
      subjectName: a.subjectId ? (subjects.get(a.subjectId) ?? null) : null,
      title: a.title,
      description: a.instructions,
      dueAt: a.dueAt,
      maxMarks: a.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS,
      status,
      isOverdue: status === 'published' && a.dueAt !== null && a.dueAt < input.now,
      ...counts,
    };
    if (status === 'closed') closed.push(item);
    else active.push(item);
  }
  return { active, closed, alertsEnabled: input.alertsEnabled };
}

export interface SubmissionsBuildInput {
  assignment: Assignment;
  batch: Batch;
  subjectName: string | null;
  enrollments: Enrollment[];
  students: Student[];
  submissions: Submission[];
  feedback: Feedback[];
  assignmentAttachments: HomeworkAttachmentView[];
  submissionAttachments: Map<ID, HomeworkAttachmentView[]>;
  linkUrl: string | null;
}

export function buildHomeworkSubmissionsView(input: SubmissionsBuildInput): HomeworkSubmissionsView {
  const maxMarks = input.assignment.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;
  const studentMap = new Map(input.students.map((s) => [s.id, s]));
  const subByStudent = new Map(input.submissions.map((s) => [s.studentId, s]));
  const fbBySub = new Map(input.feedback.map((f) => [f.submissionId, f]));
  const activeEnrollments = input.enrollments
    .filter((e) => e.status === 'active' && studentMap.has(e.studentId))
    .sort((a, b) => (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999));

  const counts = computeHomeworkCounts(
    activeEnrollments.map((e) => e.studentId),
    input.submissions,
    input.assignment.id,
  );

  const rows: HomeworkSubmissionRow[] = activeEnrollments.map((enrollment) => {
    const student = studentMap.get(enrollment.studentId) as Student;
    const sub = subByStudent.get(student.id) ?? null;
    const fb = sub ? (fbBySub.get(sub.id) ?? null) : null;
    return {
      studentId: student.id,
      fullName: student.fullName,
      rollNumber: enrollment.rollNumber,
      photoUrl: student.photoUrl,
      submissionId: sub?.id ?? null,
      status: sub?.status ?? 'pending',
      submittedAt: sub && isSubmittedStatus(sub.status) ? sub.submittedAt : null,
      content: sub?.content ?? null,
      marksAwarded: fb?.marksAwarded ?? null,
      comment: fb?.comment ?? null,
      attachments: sub ? (input.submissionAttachments.get(sub.id) ?? []) : [],
    };
  });

  return {
    assignment: input.assignment,
    batchName: input.batch.name,
    subjectName: input.subjectName,
    maxMarks,
    ...counts,
    assignmentAttachments: input.assignmentAttachments,
    linkUrl: input.linkUrl,
    rows,
  };
}

export function splitAssignmentAttachments(
  attachments: Attachment[],
  resolveUrl: (a: Attachment) => string,
): { files: HomeworkAttachmentView[]; linkUrl: string | null } {
  let linkUrl: string | null = null;
  const files: HomeworkAttachmentView[] = [];
  for (const a of attachments) {
    if (a.mimeType === LINK_MIME) linkUrl = a.fileName;
    else files.push({ id: a.id, fileName: a.fileName, mimeType: a.mimeType, sizeBytes: a.sizeBytes, url: resolveUrl(a) });
  }
  return { files, linkUrl };
}

export function buildStudentHomeworkList(input: {
  assignments: Assignment[];
  batches: Batch[];
  subjects: Subject[];
  submissions: Submission[];
  feedback: Feedback[];
  attachmentsByAssignment: Map<ID, Attachment[]>;
}): StudentHomeworkItem[] {
  const batches = new Map(input.batches.map((b) => [b.id, b.name]));
  const subjects = new Map(input.subjects.map((s) => [s.id, s.name]));
  const subByAssignment = new Map(input.submissions.map((s) => [s.assignmentId, s]));
  const fbBySub = new Map(input.feedback.map((f) => [f.submissionId, f]));
  return [...input.assignments]
    .filter((a) => a.status !== 'draft' && batches.has(a.batchId))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || (b.assignedOn ?? '').localeCompare(a.assignedOn ?? ''))
    .map((a) => {
      const sub = subByAssignment.get(a.id) ?? null;
      const fb = sub ? (fbBySub.get(sub.id) ?? null) : null;
      const atts = input.attachmentsByAssignment.get(a.id) ?? [];
      const linkRow = atts.find((att) => att.mimeType === LINK_MIME);
      const attachmentNames = atts.filter((att) => att.mimeType !== LINK_MIME).map((att) => att.fileName);
      return {
        id: a.id,
        batchId: a.batchId,
        batchName: batches.get(a.batchId) ?? 'Batch',
        subjectName: a.subjectId ? (subjects.get(a.subjectId) ?? null) : null,
        title: a.title,
        description: a.instructions,
        assignedOn: a.assignedOn,
        dueAt: a.dueAt,
        maxMarks: a.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS,
        assignmentStatus: a.status === 'closed' ? 'closed' : 'published',
        submissionStatus: sub?.status ?? 'pending',
        submittedAt: sub?.submittedAt ?? null,
        marksAwarded: fb?.marksAwarded ?? null,
        linkUrl: linkRow?.fileName ?? null,
        attachmentNames,
      };
    });
}
