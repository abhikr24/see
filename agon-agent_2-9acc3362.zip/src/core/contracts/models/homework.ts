import type { ID, ISODate, ISODateTime } from './common';
import type { Assignment, Submission } from './coursework';

export interface AssignHomeworkFile {
  fileName: string;
  uri: string;
  mimeType?: string | null;
  sizeBytes?: number | null;
}

export interface AssignHomeworkInput {
  batchId: ID;
  subjectId: ID | null;
  title: string;
  description?: string | null;
  dueAt: ISODateTime;
  maxMarks?: number | null;
  linkUrl?: string | null;
  file?: AssignHomeworkFile | null;
  notifyStudents?: boolean;
}

export interface AssignHomeworkResult {
  assignment: Assignment;
  studentsNotified: number;
  parentsNotified: number;
  alertsDisabled: boolean;
}

export interface HomeworkTrackerItem {
  id: ID;
  batchId: ID;
  batchName: string;
  subjectId: ID | null;
  subjectName: string | null;
  title: string;
  description: string | null;
  dueAt: ISODateTime | null;
  maxMarks: number;
  status: 'published' | 'closed';
  isOverdue: boolean;
  totalStudents: number;
  submittedCount: number;
  pendingCount: number;
  gradedCount: number;
  percentage: number;
}

export interface HomeworkTracker {
  active: HomeworkTrackerItem[];
  closed: HomeworkTrackerItem[];
  alertsEnabled: boolean;
}

export interface RemindHomeworkResult {
  notified: number;
  pendingCount: number;
}

export interface HomeworkAttachmentView {
  id: ID;
  fileName: string;
  mimeType: string | null;
  sizeBytes: number | null;
  url: string;
}

export interface HomeworkSubmissionRow {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
  photoUrl: string | null;
  submissionId: ID | null;
  status: 'pending' | 'submitted' | 'late' | 'returned';
  submittedAt: ISODateTime | null;
  content: string | null;
  marksAwarded: number | null;
  comment: string | null;
  attachments: HomeworkAttachmentView[];
}

export interface HomeworkSubmissionsView {
  assignment: Assignment;
  batchName: string;
  subjectName: string | null;
  maxMarks: number;
  totalStudents: number;
  submittedCount: number;
  pendingCount: number;
  gradedCount: number;
  percentage: number;
  assignmentAttachments: HomeworkAttachmentView[];
  linkUrl: string | null;
  rows: HomeworkSubmissionRow[];
}

export interface HomeworkGradeEntry {
  studentId: ID;
  marksAwarded: number;
  comment?: string | null;
}

export interface AskAgainResult {
  submission: Submission;
  notified: boolean;
}

export interface StudentHomeworkItem {
  id: ID;
  batchId: ID;
  batchName: string;
  subjectName: string | null;
  title: string;
  description: string | null;
  assignedOn: ISODate;
  dueAt: ISODateTime | null;
  maxMarks: number;
  assignmentStatus: 'published' | 'closed';
  submissionStatus: 'pending' | 'submitted' | 'late' | 'returned';
  submittedAt: ISODateTime | null;
  marksAwarded: number | null;
  linkUrl: string | null;
  attachmentNames: string[];
}
