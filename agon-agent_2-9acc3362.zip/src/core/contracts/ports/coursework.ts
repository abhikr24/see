import type {
  AskAgainResult,
  AssignHomeworkInput,
  AssignHomeworkResult,
  Assignment,
  Exam,
  ExamAnalysis,
  ExamQuestion,
  Feedback,
  HomeworkGradeEntry,
  HomeworkSubmissionsView,
  HomeworkTracker,
  ID,
  Mark,
  RemindHomeworkResult,
  Result,
  StudentHomeworkItem,
  Submission,
  Upsert,
} from '../models';
import type { CrudRepo, ReadRepo } from './common';

export interface AssignmentRepo extends CrudRepo<Assignment, 'batchId' | 'title'> {
  publish(instituteId: ID, id: ID): Promise<Assignment>;
  close(instituteId: ID, id: ID): Promise<Assignment>;
  /** Publishes new homework for one of the teacher's own batches and sends homework alerts if enabled. */
  assign(instituteId: ID, input: AssignHomeworkInput): Promise<AssignHomeworkResult>;
  /** Active and closed homework cards with live submitted/pending counts reconciled to batch size. */
  tracker(instituteId: ID, filter?: { batchId?: ID | null }): Promise<HomeworkTracker>;
  /** Sends a reminder notification exclusively to active enrolled students who have not submitted. */
  remindPending(instituteId: ID, assignmentId: ID): Promise<RemindHomeworkResult>;
  /** Published and closed homework for the signed-in student's active batches. */
  forStudent(instituteId: ID): Promise<StudentHomeworkItem[]>;
}

export interface GradeInput {
  marksAwarded?: number | null;
  grade?: string | null;
  comment?: string | null;
}

export interface SubmissionRepo extends ReadRepo<Submission> {
  /** Hands in (or re-hands in) a student's answer. Late is decided by the backend. */
  submit(
    instituteId: ID,
    input: { assignmentId: ID; studentId: ID; content?: string | null },
  ): Promise<Submission>;
  /** Records the teacher's marks and comment and returns the submission to the student. */
  grade(instituteId: ID, submissionId: ID, input: GradeInput): Promise<Feedback>;
  getFeedback(instituteId: ID, submissionId: ID): Promise<Feedback | null>;
  /** Full roster + submissions + attachments + marks for one assignment. */
  forAssignment(instituteId: ID, assignmentId: ID): Promise<HomeworkSubmissionsView>;
  /** Saves grades in one batch for an assignment (validating grade <= maxMarks). */
  saveGrades(instituteId: ID, assignmentId: ID, entries: HomeworkGradeEntry[]): Promise<Feedback[]>;
  /** Approves a student's submission (optionally recording marks) and returns it. */
  approve(instituteId: ID, assignmentId: ID, studentId: ID, marksAwarded?: number | null): Promise<Feedback>;
  /** Returns one student's submission to pending and notifies only that student. */
  askAgain(instituteId: ID, assignmentId: ID, studentId: ID, comment?: string | null): Promise<AskAgainResult>;
}

export interface ExamRepo extends CrudRepo<Exam, 'batchId' | 'name'> {
  /** Makes the exam and its results visible to students and parents. */
  publish(instituteId: ID, id: ID): Promise<Exam>;
  listQuestions(instituteId: ID, examId: ID): Promise<ExamQuestion[]>;
  saveQuestion(instituteId: ID, input: Upsert<ExamQuestion, 'examId' | 'questionNo' | 'text'>): Promise<ExamQuestion>;
  removeQuestion(instituteId: ID, id: ID): Promise<void>;
}

export interface MarkEntry {
  studentId: ID;
  subjectId: ID;
  /** null with `isAbsent: true`, or to clear an entry. */
  marksObtained: number | null;
  maxMarks: number;
  isAbsent?: boolean;
  remark?: string | null;
}

export interface MarkRepo extends ReadRepo<Mark> {
  /** Enters or corrects marks for one exam. One row per student per subject. */
  saveMany(instituteId: ID, examId: ID, entries: MarkEntry[]): Promise<Mark[]>;
}

export interface ResultRepo extends ReadRepo<Result> {
  listForStudent(instituteId: ID, studentId: ID): Promise<Result[]>;
  /** Recomputes totals, percentage, grade and rank for the exam from its marks. */
  compute(instituteId: ID, examId: ID): Promise<Result[]>;
  /**
   * Everything the analysis of one exam shows: class average, highest, lowest,
   * pass rate, ranked students (ties share a rank), subject averages, the
   * score distribution and the class-average trend.
   *
   * The owner's analysis screen and the student's own results screen both
   * read this one method, so the numbers can never differ between them.
   */
  analysis(instituteId: ID, examId: ID): Promise<ExamAnalysis>;
}
