import type {
  AskAgainResult,
  AssignHomeworkInput,
  AssignHomeworkResult,
  Assignment,
  Exam,
  Feedback,
  HomeworkGradeEntry,
  HomeworkSubmissionsView,
  HomeworkTracker,
  ID,
  Mark,
  RemindHomeworkResult,
  Result,
  StudentHomeworkItem,
  Submission,
} from '../contracts/models';
import type { GradeInput, MarkEntry } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { patchItem, useCrud, useDomainMutation, useDomainQuery, useListEditor } from './domain';

const HOMEWORK_SCOPES = ['assignments', 'submissions', 'notifications', 'analytics', 'batches', 'progress'];

/** AssignmentRepo */
export function useAssignments(query?: ListQuery<Assignment>) {
  const assignments = useCrud<Assignment, 'batchId' | 'title'>('assignments', 'Assignment', (b) => b.assignments, query);
  const edit = useListEditor<Assignment>('assignments', ['list', query ?? null]);
  const publish = useDomainMutation<ID, Assignment>(
    HOMEWORK_SCOPES,
    (b, i, id) => b.assignments.publish(i, id),
    { success: 'Assignment published', failure: 'Could not publish the assignment' },
    (id) => edit(patchItem<Assignment>(id, { status: 'published' })),
  );
  const close = useDomainMutation<ID, Assignment>(
    HOMEWORK_SCOPES,
    (b, i, id) => b.assignments.close(i, id),
    { success: 'Homework closed', failure: 'Could not close the homework' },
    (id) => edit(patchItem<Assignment>(id, { status: 'closed' })),
  );
  return {
    ...assignments,
    publish: publish.mutate,
    close: close.mutate,
    saving: assignments.saving || publish.loading || close.loading,
  };
}

/** AssignmentRepo.tracker + remindPending + close/publish */
export function useHomeworkTracker(batchId?: ID | null) {
  const tracker = useDomainQuery<HomeworkTracker>(
    'assignments',
    ['tracker', batchId ?? null],
    (b, i) => b.assignments.tracker(i, { batchId }),
  );
  const remind = useDomainMutation<ID, RemindHomeworkResult>(
    ['notifications'],
    (b, i, assignmentId) => b.assignments.remindPending(i, assignmentId),
    {
      success: (res) =>
        res.notified === 0
          ? 'Everyone has already submitted'
          : `Reminded ${res.notified} pending ${res.notified === 1 ? 'student' : 'students'}`,
      failure: 'Could not send reminder',
    },
  );
  return {
    ...tracker,
    remindPending: remind.mutate,
    reminding: remind.loading,
  };
}

/** AssignmentRepo.assign */
export function useAssignHomework() {
  return useDomainMutation<AssignHomeworkInput, AssignHomeworkResult>(
    HOMEWORK_SCOPES,
    (b, i, input) => b.assignments.assign(i, input),
    {
      success: 'Homework assigned',
      failure: 'Could not assign homework',
    },
  );
}

/** SubmissionRepo.forAssignment + saveGrades + approve + askAgain + close/publish */
export function useHomeworkSubmissions(assignmentId: ID | null) {
  const view = useDomainQuery<HomeworkSubmissionsView>(
    'submissions',
    ['for-assignment', assignmentId],
    (b, i) => b.submissions.forAssignment(i, assignmentId as ID),
    Boolean(assignmentId),
  );
  const saveGrades = useDomainMutation<HomeworkGradeEntry[], Feedback[]>(
    HOMEWORK_SCOPES,
    (b, i, entries) => b.submissions.saveGrades(i, assignmentId ?? '', entries),
    {
      success: (saved) => `${saved.length} ${saved.length === 1 ? 'grade' : 'grades'} saved`,
      failure: 'Could not save grades',
    },
  );
  const approve = useDomainMutation<{ studentId: ID; marksAwarded?: number | null }, Feedback>(
    HOMEWORK_SCOPES,
    (b, i, { studentId, marksAwarded }) => b.submissions.approve(i, assignmentId ?? '', studentId, marksAwarded),
    { success: 'Submission approved', failure: 'Could not approve submission' },
  );
  const askAgain = useDomainMutation<{ studentId: ID; studentName?: string; comment?: string | null }, AskAgainResult>(
    HOMEWORK_SCOPES,
    (b, i, { studentId, comment }) => b.submissions.askAgain(i, assignmentId ?? '', studentId, comment),
    {
      success: (_res) => 'Asked student to submit again',
      failure: 'Could not request a resubmission',
    },
  );
  const close = useDomainMutation<void, Assignment>(
    HOMEWORK_SCOPES,
    (b, i) => b.assignments.close(i, assignmentId ?? ''),
    { success: 'Homework closed', failure: 'Could not close homework' },
  );
  const reopen = useDomainMutation<void, Assignment>(
    HOMEWORK_SCOPES,
    (b, i) => b.assignments.publish(i, assignmentId ?? ''),
    { success: 'Homework reopened', failure: 'Could not reopen homework' },
  );
  return {
    ...view,
    saveGrades: saveGrades.mutate,
    savingGrades: saveGrades.loading,
    approve: approve.mutate,
    approving: approve.loading,
    askAgain: askAgain.mutate,
    askingAgain: askAgain.loading,
    close: close.mutate,
    reopen: reopen.mutate,
    updatingStatus: close.loading || reopen.loading,
  };
}

/** AssignmentRepo.forStudent */
export function useStudentHomework() {
  return useDomainQuery<StudentHomeworkItem[]>(
    'assignments',
    ['for-student'],
    (b, i) => b.assignments.forStudent(i),
  );
}

/** SubmissionRepo · handing in and grading. Pass `{ where: { assignmentId } }` or `{ where: { studentId } }`. */
export function useSubmissions(query?: ListQuery<Submission>) {
  const submissions = useDomainQuery('submissions', ['list', query ?? null], (b, i) => b.submissions.list(i, query));
  const submit = useDomainMutation<{ assignmentId: ID; studentId: ID; content?: string | null }, Submission>(
    ['submissions', 'progress'],
    (b, i, input) => b.submissions.submit(i, input),
    {
      success: (s) => (s.status === 'late' ? 'Handed in (late)' : 'Handed in'),
      failure: 'Could not hand in your work',
    },
  );
  const grade = useDomainMutation<{ submissionId: ID } & GradeInput, Feedback>(
    ['submissions', 'progress'],
    (b, i, { submissionId, ...input }) => b.submissions.grade(i, submissionId, input),
    { success: 'Feedback sent', failure: 'Could not save the feedback' },
  );
  return { ...submissions, submit: submit.mutate, grade: grade.mutate, saving: submit.loading || grade.loading };
}

/** SubmissionRepo · the teacher's feedback on one submission. null until graded. */
export function useFeedback(submissionId: ID | null) {
  return useDomainQuery<Feedback | null>(
    'submissions',
    ['feedback', submissionId],
    (b, i) => b.submissions.getFeedback(i, submissionId as ID),
    submissionId !== null,
  );
}

/** ExamRepo */
export function useExams(query?: ListQuery<Exam>) {
  const exams = useCrud<Exam, 'batchId' | 'name'>('exams', 'Exam', (b) => b.exams, query);
  const edit = useListEditor<Exam>('exams', ['list', query ?? null]);
  const publish = useDomainMutation<ID, Exam>(
    ['exams', 'marks', 'results', 'notifications', 'progress'],
    (b, i, id) => b.exams.publish(i, id),
    { success: 'Results published', failure: 'Could not publish the exam' },
    (id) => edit(patchItem<Exam>(id, { status: 'published' })),
  );
  return { ...exams, publish: publish.mutate, saving: exams.saving || publish.loading };
}

/** MarkRepo · the mark sheet for one exam. Off while `examId` is null. */
export function useMarks(examId: ID | null) {
  const marks = useDomainQuery(
    'marks',
    ['exam', examId],
    (b, i) => b.marks.list(i, { where: { examId: examId as ID }, limit: 200 }),
    examId !== null,
  );
  const save = useDomainMutation<MarkEntry[], Mark[]>(
    ['marks', 'results', 'progress'],
    async (b, i, entries) => {
      const saved = await b.marks.saveMany(i, examId ?? '', entries);
      // Results are derived from marks, so they are recomputed in the same action.
      await b.results.compute(i, examId ?? '');
      return saved;
    },
    { success: (saved) => `${saved.length} marks saved`, failure: 'Could not save the marks' },
  );
  return { ...marks, save: save.mutate, saving: save.loading };
}

/** ResultRepo · pass `{ where: { examId } }` for a rank list or `{ where: { studentId } }` for a report card. */
export function useResults(query?: ListQuery<Result>) {
  const results = useDomainQuery('results', ['list', query ?? null], (b, i) => b.results.list(i, query));
  const compute = useDomainMutation<ID, Result[]>(
    ['results', 'progress'],
    (b, i, examId) => b.results.compute(i, examId),
    { success: (rows) => `Results computed for ${rows.length} students`, failure: 'Could not compute the results' },
  );
  return { ...results, compute: compute.mutate, saving: compute.loading };
}
