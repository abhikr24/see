import React from 'react';
import { Pressable, Switch, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Card, Input, Text } from '@/components/ui';
import type { AssignHomeworkFile } from '@/core/contracts/models';
import { C, R } from '@/lib/theme';
import { formatFileSize } from '../model';

export interface AssignAttachmentCardProps {
  file: AssignHomeworkFile | null;
  onAttachFile: () => void;
  onClearFile: () => void;
  linkUrl: string;
  onChangeLinkUrl: (v: string) => void;
  linkError?: string;
}

export function AssignAttachmentCard({
  file,
  onAttachFile,
  onClearFile,
  linkUrl,
  onChangeLinkUrl,
  linkError,
}: AssignAttachmentCardProps) {
  return (
    <Card flat style={{ gap: 12 }}>
      <Text variant="label" c={C.secondary}>
        Attach a file or paste a link
      </Text>

      {file ? (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
            padding: 12,
            borderRadius: R.field,
            backgroundColor: C.navySoft,
            borderWidth: 1,
            borderColor: C.hairline,
          }}
        >
          <Ionicons name="document-attach-outline" size={20} color={C.primary} />
          <View style={{ flex: 1 }}>
            <Text variant="caption" weight={700} c={C.primary} numberOfLines={1}>
              {file.fileName}
            </Text>
            {file.sizeBytes ? (
              <Text variant="label" c={C.secondary} tabular>
                {formatFileSize(file.sizeBytes)}
              </Text>
            ) : null}
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Remove attached file"
            onPress={onClearFile}
            hitSlop={8}
          >
            <Ionicons name="close-circle" size={20} color={C.secondary} />
          </Pressable>
        </View>
      ) : (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Attach a file"
          onPress={onAttachFile}
          style={({ pressed }) => ({
            height: 48,
            borderRadius: R.field,
            borderWidth: 1.5,
            borderStyle: 'dashed',
            borderColor: C.cardDash,
            backgroundColor: C.canvas,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            opacity: pressed ? 0.8 : 1,
          })}
        >
          <Ionicons name="attach-outline" size={18} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>
            Attach a file
          </Text>
        </Pressable>
      )}

      <Input
        label="Or paste a link"
        value={linkUrl}
        onChangeText={onChangeLinkUrl}
        placeholder="https://drive.google.com/…"
        autoCapitalize="none"
        keyboardType="url"
        error={linkError}
      />
    </Card>
  );
}

export interface NotifyStudentsCardProps {
  value: boolean;
  alertsEnabled: boolean;
  onChange: (next: boolean) => void;
}

export function NotifyStudentsCard({ value, alertsEnabled, onChange }: NotifyStudentsCardProps) {
  return (
    <Card flat pad={16}>
      <Pressable
        accessibilityRole="switch"
        accessibilityLabel="Notify students"
        accessibilityState={{ checked: value }}
        onPress={() => onChange(!value)}
        style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}
      >
        <View style={{ flex: 1, gap: 2 }}>
          <Text variant="body" weight={700} c={C.ink}>
            Notify students
          </Text>
          <Text variant="caption" c={C.secondary}>
            {alertsEnabled
              ? 'Sends a homework alert to every student and parent in this batch.'
              : 'Homework alerts are turned off in institute settings.'}
          </Text>
        </View>
        <Switch
          value={value}
          onValueChange={onChange}
          trackColor={{ false: C.track, true: C.primary }}
          thumbColor={C.surface}
        />
      </Pressable>
    </Card>
  );
}
