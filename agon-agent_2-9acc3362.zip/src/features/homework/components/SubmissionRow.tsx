import React, { useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, Badge, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import { formatFileSize, type SubmissionRowView } from '../model';

export interface SubmissionRowItem extends SubmissionRowView {
  gradeText: string;
  gradeValue: number | null;
  gradeError: string | null;
  hasGrade: boolean;
}

export interface SubmissionRowProps {
  row: SubmissionRowItem;
  maxMarks: number;
  expanded: boolean;
  busy: boolean;
  onToggleExpand: (studentId: string) => void;
  onChangeGrade: (studentId: string, value: string) => void;
  onApprove: (studentId: string) => void;
  onAskAgain: (studentId: string) => void;
}

export function SubmissionRow({
  row,
  maxMarks,
  expanded,
  busy,
  onToggleExpand,
  onChangeGrade,
  onApprove,
  onAskAgain,
}: SubmissionRowProps) {
  const [focused, setFocused] = useState(false);
  const firstAttachment = row.attachments[0] ?? null;
  const hasError = Boolean(row.gradeError);

  return (
    <View style={{ backgroundColor: C.surface }}>
      <View
        style={{
          minHeight: 80,
          paddingHorizontal: 16,
          paddingVertical: 12,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 12,
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`${row.fullName}, ${row.subtitle}`}
          onPress={() => onToggleExpand(row.studentId)}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 12,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Avatar name={row.fullName} uri={row.photoUrl} size={40} />
          <View style={{ flex: 1, gap: 3 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
              <Text variant="body" weight={700} c={C.ink} numberOfLines={1}>
                {row.fullName}
              </Text>
              {row.isApproved ? <Badge label="Approved" tone="teal" small /> : null}
              {row.isLate ? <Badge label="Late" tone="warning" small /> : null}
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Text
                variant="caption"
                c={row.askedAgain ? C.duesInk : row.isSubmitted ? C.secondary : C.muted}
                tabular
                numberOfLines={1}
              >
                {row.subtitle}
              </Text>
              <Ionicons
                name={expanded ? 'chevron-up' : 'chevron-down'}
                size={14}
                color={C.muted}
              />
            </View>
          </View>
        </Pressable>

        <View style={{ alignItems: 'flex-end', gap: 3 }}>
          <View
            style={{
              width: 76,
              height: 44,
              borderRadius: 12,
              backgroundColor: focused || hasError ? C.surface : C.canvas,
              borderWidth: focused || hasError ? 2 : 1,
              borderColor: hasError ? C.danger : focused ? C.primary : C.hairline,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              paddingHorizontal: 8,
            }}
          >
            <TextInput
              accessibilityLabel={`Grade for ${row.fullName}`}
              value={row.gradeText}
              onChangeText={(v) => onChangeGrade(row.studentId, v)}
              onFocus={() => setFocused(true)}
              onBlur={() => setFocused(false)}
              keyboardType="decimal-pad"
              placeholder="—"
              placeholderTextColor={C.muted}
              style={{
                flex: 1,
                textAlign: 'center',
                fontSize: 17,
                fontWeight: '700',
                fontVariant: ['tabular-nums'],
                color: hasError ? C.danger : C.ink,
                paddingVertical: 0,
              }}
            />
          </View>
          <Text variant="label" c={hasError ? C.danger : C.muted} tabular style={{ fontSize: 10.5 }}>
            {hasError ? row.gradeError : `/ ${maxMarks}`}
          </Text>
        </View>
      </View>

      {expanded ? (
        <View
          style={{
            marginHorizontal: 16,
            marginBottom: 14,
            padding: 12,
            borderRadius: R.field,
            backgroundColor: C.canvas,
            borderWidth: 1,
            borderColor: C.hairline,
            gap: 12,
          }}
        >
          {firstAttachment ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <Image
                source={{ uri: firstAttachment.url }}
                contentFit="cover"
                accessibilityLabel={`Attachment ${firstAttachment.fileName}`}
                style={{
                  width: 76,
                  height: 56,
                  borderRadius: R.cell,
                  borderWidth: 1,
                  borderColor: C.hairline,
                  backgroundColor: C.surface,
                }}
              />
              <View style={{ flex: 1, gap: 2 }}>
                <Text variant="caption" weight={700} c={C.ink} numberOfLines={1}>
                  {firstAttachment.fileName}
                </Text>
                <Text variant="label" c={C.muted} tabular>
                  {formatFileSize(firstAttachment.sizeBytes) || 'Worksheet attachment'}
                </Text>
              </View>
            </View>
          ) : (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View
                style={{
                  width: 56,
                  height: 44,
                  borderRadius: R.cell,
                  backgroundColor: C.surface,
                  borderWidth: 1,
                  borderColor: C.hairline,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Ionicons name="document-text-outline" size={18} color={C.muted} />
              </View>
              <Text variant="caption" c={C.muted}>
                No attachment uploaded yet
              </Text>
            </View>
          )}

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Approve ${row.fullName}`}
              disabled={busy || hasError}
              onPress={() => onApprove(row.studentId)}
              style={({ pressed }) => ({
                flex: 1,
                height: 40,
                borderRadius: 12,
                backgroundColor: C.tealSoft,
                borderWidth: 1,
                borderColor: C.teal,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                opacity: busy || hasError ? 0.5 : pressed ? 0.8 : 1,
              })}
            >
              <Ionicons name="checkmark-circle-outline" size={16} color={C.teal} />
              <Text variant="caption" weight={700} c={C.teal}>
                Approve
              </Text>
            </Pressable>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Ask ${row.fullName} again`}
              disabled={busy}
              onPress={() => onAskAgain(row.studentId)}
              style={({ pressed }) => ({
                flex: 1,
                height: 40,
                borderRadius: 12,
                backgroundColor: C.surface,
                borderWidth: 1,
                borderColor: C.hairline,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
                opacity: busy ? 0.5 : pressed ? 0.8 : 1,
              })}
            >
              <Ionicons name="refresh-outline" size={16} color={C.ink} />
              <Text variant="caption" weight={700} c={C.ink}>
                Ask again
              </Text>
            </Pressable>
          </View>
        </View>
      ) : null}
    </View>
  );
}
