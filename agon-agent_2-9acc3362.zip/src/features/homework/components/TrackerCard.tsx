import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Badge, Card, Divider, Text } from '@/components/ui';
import { C } from '@/lib/theme';
import type { TrackerCardView } from '../model';
import { TwoToneBar } from './TwoToneBar';

export interface TrackerCardProps {
  card: TrackerCardView;
  reminding: boolean;
  onRemind: (id: string) => void;
  onOpenSubmissions: (id: string) => void;
}

export function TrackerCard({ card, reminding, onRemind, onOpenSubmissions }: TrackerCardProps) {
  return (
    <Card flat style={{ gap: 14 }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
        <View style={{ flex: 1, gap: 3 }}>
          {card.subjectName ? (
            <Text variant="label" weight={700} c={C.muted}>
              {card.subjectName.toUpperCase()}
            </Text>
          ) : null}
          <Text variant="title" weight={700} c={C.ink}>
            {card.title}
          </Text>
          <Text variant="caption" c={C.secondary} tabular>
            {card.metaLine}
          </Text>
        </View>
        {card.isOverdue ? <Badge label="Overdue" tone="danger" /> : null}
      </View>

      <TwoToneBar
        assignmentId={card.id}
        submittedCount={card.submittedCount}
        pendingCount={card.pendingCount}
        totalStudents={card.totalStudents}
        percentageLabel={card.percentageLabel}
      />

      {card.gradedSummary ? (
        <Text variant="caption" c={C.secondary} tabular>
          {card.gradedSummary}
        </Text>
      ) : null}

      <Divider />

      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Remind pending for ${card.title}`}
          disabled={!card.canRemind || reminding}
          onPress={() => onRemind(card.id)}
          hitSlop={6}
          style={({ pressed }) => ({
            paddingVertical: 6,
            paddingRight: 8,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            opacity: !card.canRemind || reminding ? 0.45 : pressed ? 0.75 : 1,
          })}
        >
          <Ionicons name="notifications-outline" size={16} color={card.canRemind ? C.primary : C.muted} />
          <Text variant="caption" weight={700} c={card.canRemind ? C.primary : C.muted}>
            {reminding ? 'Reminding…' : 'Remind pending'}
          </Text>
        </Pressable>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`View submissions for ${card.title}`}
          onPress={() => onOpenSubmissions(card.id)}
          hitSlop={6}
          style={({ pressed }) => ({
            paddingVertical: 6,
            paddingLeft: 8,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 4,
            opacity: pressed ? 0.75 : 1,
          })}
        >
          <Text variant="caption" weight={700} c={C.primary}>
            View submissions
          </Text>
          <Ionicons name="chevron-forward" size={16} color={C.primary} />
        </Pressable>
      </View>
    </Card>
  );
}
