import React from 'react';
import { View } from 'react-native';

import { Text } from '@/components/ui';
import { assertHomeworkCounts } from '@/core/contracts/homework';
import { C, R } from '@/lib/theme';

export interface TwoToneBarProps {
  assignmentId?: string;
  submittedCount: number;
  pendingCount: number;
  totalStudents: number;
  percentageLabel: string;
}

/**
 * Two-tone progress bar: submitted in teal, pending in amber, counts on each
 * side, and the bold tabular percentage on the right.
 */
export function TwoToneBar({
  assignmentId,
  submittedCount,
  pendingCount,
  totalStudents,
  percentageLabel,
}: TwoToneBarProps) {
  assertHomeworkCounts(submittedCount, pendingCount, totalStudents, assignmentId);

  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.teal }} />
          <Text variant="caption" weight={700} c={C.teal} tabular>
            {submittedCount} submitted
          </Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.warning }} />
          <Text variant="caption" weight={600} c={C.duesInk} tabular>
            {pendingCount} pending
          </Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View
          style={{
            flex: 1,
            height: 8,
            borderRadius: R.chip,
            backgroundColor: C.track,
            overflow: 'hidden',
            flexDirection: 'row',
          }}
        >
          {totalStudents > 0 ? (
            <>
              {submittedCount > 0 ? (
                <View style={{ flex: submittedCount, backgroundColor: C.teal, height: '100%' }} />
              ) : null}
              {submittedCount > 0 && pendingCount > 0 ? (
                <View style={{ width: 2, backgroundColor: C.surface, height: '100%' }} />
              ) : null}
              {pendingCount > 0 ? (
                <View style={{ flex: pendingCount, backgroundColor: C.warning, height: '100%' }} />
              ) : null}
            </>
          ) : null}
        </View>
        <Text variant="title" weight={800} c={C.ink} tabular style={{ minWidth: 44, textAlign: 'right' }}>
          {percentageLabel}
        </Text>
      </View>
    </View>
  );
}
