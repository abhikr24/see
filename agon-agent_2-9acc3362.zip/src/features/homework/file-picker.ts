import { Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

import type { AssignHomeworkFile } from '@/core/contracts/models';

function pickWebFile(): Promise<AssignHomeworkFile | null> {
  return new Promise((resolve) => {
    if (typeof document === 'undefined') {
      resolve(null);
      return;
    }
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,application/pdf,.doc,.docx,.txt';
    let settled = false;
    const finish = (file: AssignHomeworkFile | null) => {
      if (settled) return;
      settled = true;
      resolve(file);
    };
    input.onchange = () => {
      const selected = input.files?.[0];
      if (!selected) {
        finish(null);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        finish({
          fileName: selected.name,
          uri: typeof reader.result === 'string' ? reader.result : URL.createObjectURL(selected),
          mimeType: selected.type || 'application/octet-stream',
          sizeBytes: selected.size,
        });
      };
      reader.onerror = () => finish(null);
      reader.readAsDataURL(selected);
    };
    input.oncancel = () => finish(null);
    input.click();
  });
}

/** Opens the system file / media picker and returns metadata + URI for upload. */
export async function pickHomeworkAttachment(): Promise<AssignHomeworkFile | null> {
  if (Platform.OS === 'web') {
    return pickWebFile();
  }
  try {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return null;
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.7,
      base64: true,
    });
    if (res.canceled || !res.assets[0]) return null;
    const asset = res.assets[0];
    const uri = asset.base64 ? `data:${asset.mimeType ?? 'image/jpeg'};base64,${asset.base64}` : asset.uri;
    return {
      fileName: asset.fileName ?? `attachment-${Date.now()}.jpg`,
      uri,
      mimeType: asset.mimeType ?? 'image/jpeg',
      sizeBytes: asset.fileSize ?? null,
    };
  } catch {
    return null;
  }
}
