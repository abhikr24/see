import { useCallback, useMemo, useState } from 'react';
import { router } from 'expo-router';

import {
  useAssignHomework,
  useHomeworkTracker,
  useInstitute,
  useMyClasses,
  useStudentHomework,
  useSubjects,
} from '@/core/backend';
import {
  getAssignValidationErrors,
  HOMEWORK_DEFAULT_MAX_MARKS,
  type AssignValidationErrors,
} from '@/core/contracts/homework';
import type { AssignHomeworkFile, ID } from '@/core/contracts/models';
import { pickHomeworkAttachment } from './file-picker';
import {
  buildDueAtIso,
  sendFooterLabel,
  todayUtcIso,
  toStudentHomeworkCardView,
  toTrackerCardView,
} from './model';

export { useHomeworkSubmissionsScreen } from './submissions-hook';

export type TrackerSegment = 'active' | 'closed';

export function useHomeworkTrackerScreen(routeBatchId?: string) {
  const classes = useMyClasses();
  const [batchOverride, setBatchOverride] = useState<string | null | undefined>(undefined);
  const [segment, setSegment] = useState<TrackerSegment>('active');
  const [remindingId, setRemindingId] = useState<ID | null>(null);

  const selectedBatchId = batchOverride !== undefined ? batchOverride : (routeBatchId || null);
  const setSelectedBatchId = useCallback((next: string | null) => setBatchOverride(next), []);

  const ownBatches = useMemo(() => classes.data ?? [], [classes.data]);
  const validBatchId = useMemo(() => {
    if (!selectedBatchId) return null;
    if (ownBatches.length === 0) return selectedBatchId;
    return ownBatches.some((c) => c.batchId === selectedBatchId) ? selectedBatchId : null;
  }, [ownBatches, selectedBatchId]);

  const tracker = useHomeworkTracker(validBatchId);
  const today = useMemo(() => todayUtcIso(), []);

  const activeCards = useMemo(
    () => (tracker.data?.active ?? []).map((item) => toTrackerCardView(item, today)),
    [today, tracker.data?.active],
  );
  const closedCards = useMemo(
    () => (tracker.data?.closed ?? []).map((item) => toTrackerCardView(item, today)),
    [today, tracker.data?.closed],
  );

  const remind = useCallback(
    async (assignmentId: ID) => {
      setRemindingId(assignmentId);
      try {
        await tracker.remindPending(assignmentId);
      } finally {
        setRemindingId(null);
      }
    },
    [tracker],
  );

  const openAssign = useCallback(() => {
    const targetBatch = validBatchId ?? ownBatches[0]?.batchId;
    if (targetBatch) {
      router.push({ pathname: '/(teacher)/homework/new', params: { batchId: targetBatch } } as never);
    } else {
      router.push('/(teacher)/homework/new' as never);
    }
  }, [ownBatches, validBatchId]);

  const openSubmissions = useCallback((assignmentId: ID) => {
    router.push(`/(teacher)/homework/${assignmentId}` as never);
  }, []);

  return {
    status:
      tracker.loading && !tracker.data
        ? ('loading' as const)
        : tracker.error && !tracker.data
          ? ('error' as const)
          : ('ready' as const),
    errorMessage: tracker.error?.message ?? null,
    refreshing: tracker.loading && Boolean(tracker.data),
    refresh: () => Promise.all([tracker.refetch(), classes.refetch()]),
    segment,
    setSegment,
    cards: segment === 'active' ? activeCards : closedCards,
    activeCount: activeCards.length,
    closedCount: closedCards.length,
    ownBatches,
    selectedBatchId: validBatchId,
    setSelectedBatchId,
    remindingId,
    remind,
    openAssign,
    openSubmissions,
  };
}

export const DUE_TIME_PRESETS = [
  { value: '17:00', label: '5:00 PM' },
  { value: '20:00', label: '8:00 PM' },
  { value: '21:00', label: '9:00 PM' },
  { value: '23:59', label: '11:59 PM' },
] as const;

export function useAssignHomeworkForm(initialBatchId?: string) {
  const classes = useMyClasses();
  const subjects = useSubjects({ where: { isActive: true }, limit: 100 });
  const institute = useInstitute();
  const assign = useAssignHomework();

  const batches = useMemo(() => classes.data ?? [], [classes.data]);
  const subjectList = useMemo(() => subjects.data?.items ?? [], [subjects.data?.items]);

  const [batchId, setBatchId] = useState(initialBatchId ?? '');
  const [subjectId, setSubjectId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState(todayUtcIso);
  const [dueTime, setDueTime] = useState('20:00');
  const [maxMarksText, setMaxMarksText] = useState(String(HOMEWORK_DEFAULT_MAX_MARKS));
  const [file, setFile] = useState<AssignHomeworkFile | null>(null);
  const [linkUrl, setLinkUrl] = useState('');
  const [notifyStudents, setNotifyStudents] = useState(true);
  const [errors, setErrors] = useState<AssignValidationErrors>({});

  const effectiveBatchId = useMemo(() => {
    if (batchId && batches.some((b) => b.batchId === batchId)) return batchId;
    if (initialBatchId && batches.some((b) => b.batchId === initialBatchId)) return initialBatchId;
    return batches[0]?.batchId ?? '';
  }, [batchId, batches, initialBatchId]);

  const selectedBatch = useMemo(
    () => batches.find((b) => b.batchId === effectiveBatchId) ?? null,
    [batches, effectiveBatchId],
  );
  const effectiveSubjectId = subjectId || selectedBatch?.subjectId || subjectList[0]?.id || '';

  const selectBatch = useCallback(
    (nextBatchId: string) => {
      setBatchId(nextBatchId);
      setErrors((prev) => ({ ...prev, batchId: undefined }));
      const next = batches.find((b) => b.batchId === nextBatchId);
      if (next?.subjectId) setSubjectId(next.subjectId);
    },
    [batches],
  );

  const attachFile = useCallback(async () => {
    const picked = await pickHomeworkAttachment();
    if (picked) setFile(picked);
  }, []);

  const alertsEnabled = institute.data?.settings.features?.homeworkAlerts !== false;
  const studentCount = selectedBatch?.studentCount ?? 0;

  const submit = useCallback(async () => {
    const parsedMax = maxMarksText.trim() === '' ? HOMEWORK_DEFAULT_MAX_MARKS : Number(maxMarksText);
    const nextErrors = getAssignValidationErrors({
      batchId: effectiveBatchId,
      subjectId: effectiveSubjectId,
      title,
      dueDate,
      dueTime,
      maxMarks: parsedMax,
      linkUrl,
    });
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const res = await assign.mutate({
      batchId: effectiveBatchId,
      subjectId: effectiveSubjectId || null,
      title: title.trim(),
      description: description.trim() || null,
      dueAt: buildDueAtIso(dueDate, dueTime),
      maxMarks: parsedMax,
      file,
      linkUrl: linkUrl.trim() || null,
      notifyStudents,
    });
    if (res.ok) router.replace('/(teacher)/homework' as never);
  }, [assign, description, dueDate, dueTime, effectiveBatchId, effectiveSubjectId, file, linkUrl, maxMarksText, notifyStudents, title]);

  return {
    loading: (classes.loading && !classes.data) || (subjects.loading && !subjects.data),
    error: classes.error && !classes.data ? classes.error : subjects.error && !subjects.data ? subjects.error : null,
    retry: () => Promise.all([classes.refetch(), subjects.refetch()]),
    batches,
    subjectList,
    effectiveBatchId,
    selectBatch,
    effectiveSubjectId,
    setSubjectId,
    title,
    setTitle: (v: string) => {
      setTitle(v);
      if (errors.title) setErrors((e) => ({ ...e, title: undefined }));
    },
    description,
    setDescription,
    dueDate,
    setDueDate: (iso: string) => {
      setDueDate(iso);
      if (errors.dueDate) setErrors((e) => ({ ...e, dueDate: undefined }));
    },
    dueTime,
    setDueTime: (v: string) => {
      setDueTime(v);
      if (errors.dueTime) setErrors((e) => ({ ...e, dueTime: undefined }));
    },
    maxMarksText,
    setMaxMarksText: (v: string) => {
      setMaxMarksText(v.replace(/[^0-9]/g, ''));
      if (errors.maxMarks) setErrors((e) => ({ ...e, maxMarks: undefined }));
    },
    file,
    attachFile,
    clearFile: () => setFile(null),
    linkUrl,
    setLinkUrl: (v: string) => {
      setLinkUrl(v);
      if (errors.linkUrl) setErrors((e) => ({ ...e, linkUrl: undefined }));
    },
    notifyStudents,
    setNotifyStudents,
    alertsEnabled,
    studentCount,
    footerLabel: sendFooterLabel(studentCount),
    errors,
    saving: assign.loading,
    submit,
  };
}

export function useStudentHomeworkScreen() {
  const query = useStudentHomework();
  const today = useMemo(() => todayUtcIso(), []);
  const items = useMemo(
    () => (query.data ?? []).map((item) => toStudentHomeworkCardView(item, today)),
    [query.data, today],
  );
  return {
    loading: query.loading && !query.data,
    error: query.error && !query.data ? query.error : null,
    refreshing: query.loading && Boolean(query.data),
    refresh: query.refetch,
    items,
  };
}
