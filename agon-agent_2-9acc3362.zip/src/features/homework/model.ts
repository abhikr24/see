import {
  assertHomeworkCounts,
  validateGradeValue,
} from '@/core/contracts/homework';
import type {
  HomeworkSubmissionRow,
  HomeworkTrackerItem,
  ISODate,
  ISODateTime,
  StudentHomeworkItem,
} from '@/core/contracts/models';
import { pct, timeShort } from '@/lib/format';

const SHORT_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function todayUtcIso(): ISODate {
  return new Date().toISOString().slice(0, 10);
}

export function addDaysUtcIso(iso: ISODate, days: number): ISODate {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return dt.toISOString().slice(0, 10);
}

export function buildDueAtIso(dueDate: ISODate, dueTime: string): ISODateTime {
  const cleanTime = /^([01]\d|2[0-3]):[0-5]\d$/.test(dueTime) ? dueTime : '20:00';
  return `${dueDate}T${cleanTime}:00.000Z`;
}

function dayMonthLabel(isoDate: string): string {
  const parts = isoDate.slice(0, 10).split('-').map(Number);
  if (parts.length !== 3 || parts.some(Number.isNaN)) return isoDate;
  const [, month, day] = parts;
  return `${day} ${SHORT_MONTHS[(month - 1 + 12) % 12]}`;
}

/**
 * Formats an ISO timestamp deterministically from its UTC date/time parts:
 * - Today -> "Due today, 8:00 PM"
 * - Tomorrow -> "Due tomorrow, 8:00 PM"
 * - Other -> "Due 11 Nov, 8:00 PM"
 */
export function formatHomeworkDue(dueAt: ISODateTime | null, today: ISODate = todayUtcIso()): string {
  if (!dueAt) return 'No due date';
  const datePart = dueAt.slice(0, 10);
  const timePart = dueAt.slice(11, 16) || '20:00';
  const clock = timeShort(timePart);
  if (datePart === today) return `Due today, ${clock}`;
  if (datePart === addDaysUtcIso(today, 1)) return `Due tomorrow, ${clock}`;
  return `Due ${dayMonthLabel(datePart)}, ${clock}`;
}

/** "Class 10-A · Due today, 8:00 PM" */
export function trackerMetaLine(batchName: string, dueAt: ISODateTime | null, today: ISODate = todayUtcIso()): string {
  return `${batchName} · ${formatHomeworkDue(dueAt, today)}`;
}

/** "Submitted 11 Nov, 9:14 PM" */
export function formatSubmittedAt(submittedAt: ISODateTime | null): string {
  if (!submittedAt) return 'Not submitted';
  const datePart = submittedAt.slice(0, 10);
  const timePart = submittedAt.slice(11, 16) || '00:00';
  return `Submitted ${dayMonthLabel(datePart)}, ${timeShort(timePart)}`;
}

export function sendFooterLabel(studentCount: number): string {
  return `Send to ${studentCount} ${studentCount === 1 ? 'student' : 'students'}`;
}

export function submissionsHeaderLabel(submittedCount: number, totalStudents: number): string {
  return `${submittedCount} of ${totalStudents} submitted`;
}

export function saveGradesFooterLabel(count: number): string {
  if (count <= 0) return 'Save grades';
  return `Save ${count} ${count === 1 ? 'grade' : 'grades'}`;
}

export function formatFileSize(bytes: number | null | undefined): string {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export interface GradeDraftResult {
  hasValue: boolean;
  value: number | null;
  error: string | null;
}

export function parseGradeDraft(raw: string, maxMarks: number): GradeDraftResult {
  const trimmed = raw.trim();
  if (trimmed.length === 0) return { hasValue: false, value: null, error: null };
  if (!/^\d+(\.\d{1,2})?$/.test(trimmed)) {
    return { hasValue: true, value: null, error: `0–${maxMarks} only` };
  }
  const parsed = Number(trimmed);
  const err = validateGradeValue(parsed, maxMarks);
  if (err) return { hasValue: true, value: null, error: `Max ${maxMarks}` };
  return { hasValue: true, value: parsed, error: null };
}

export interface TrackerCardView {
  id: string;
  title: string;
  subjectName: string | null;
  metaLine: string;
  isOverdue: boolean;
  status: 'published' | 'closed';
  totalStudents: number;
  submittedCount: number;
  pendingCount: number;
  gradedCount: number;
  percentage: number;
  percentageLabel: string;
  submittedLabel: string;
  pendingLabel: string;
  gradedSummary: string | null;
  canRemind: boolean;
}

export function toTrackerCardView(item: HomeworkTrackerItem, today: ISODate = todayUtcIso()): TrackerCardView {
  assertHomeworkCounts(item.submittedCount, item.pendingCount, item.totalStudents, item.id);
  const gradedPct = item.totalStudents > 0 ? pct((item.gradedCount / item.totalStudents) * 100) : '0%';
  const gradedSummary =
    item.submittedCount > 0 || item.gradedCount > 0
      ? `${item.gradedCount} of ${item.totalStudents} graded · ${gradedPct}`
      : null;
  return {
    id: item.id,
    title: item.title,
    subjectName: item.subjectName,
    metaLine: trackerMetaLine(item.batchName, item.dueAt, today),
    isOverdue: item.isOverdue,
    status: item.status,
    totalStudents: item.totalStudents,
    submittedCount: item.submittedCount,
    pendingCount: item.pendingCount,
    gradedCount: item.gradedCount,
    percentage: item.percentage,
    percentageLabel: pct(item.percentage),
    submittedLabel: `${item.submittedCount} submitted`,
    pendingLabel: `${item.pendingCount} pending`,
    gradedSummary,
    canRemind: item.status === 'published' && item.pendingCount > 0,
  };
}

export interface SubmissionRowView {
  studentId: string;
  fullName: string;
  rollNumber: number | null;
  photoUrl: string | null;
  status: HomeworkSubmissionRow['status'];
  subtitle: string;
  askedAgain: boolean;
  isSubmitted: boolean;
  isApproved: boolean;
  isLate: boolean;
  attachments: HomeworkSubmissionRow['attachments'];
}

export function toSubmissionRowView(row: HomeworkSubmissionRow): SubmissionRowView {
  const isSubmitted = row.status === 'submitted' || row.status === 'late' || row.status === 'returned';
  const askedAgain = row.submissionId !== null && row.status === 'pending';
  const subtitle = isSubmitted
    ? formatSubmittedAt(row.submittedAt)
    : askedAgain
      ? 'Asked to resubmit'
      : 'Not submitted';
  return {
    studentId: row.studentId,
    fullName: row.fullName,
    rollNumber: row.rollNumber,
    photoUrl: row.photoUrl,
    status: row.status,
    subtitle,
    askedAgain,
    isSubmitted,
    isApproved: row.status === 'returned',
    isLate: row.status === 'late',
    attachments: row.attachments,
  };
}

export interface StudentHomeworkCardView {
  id: string;
  title: string;
  metaLine: string;
  subjectName: string | null;
  description: string | null;
  statusLabel: string;
  statusTone: 'teal' | 'warning' | 'primary' | 'neutral';
  scoreLabel: string | null;
  linkUrl: string | null;
  attachmentNames: string[];
}

export function toStudentHomeworkCardView(
  item: StudentHomeworkItem,
  today: ISODate = todayUtcIso(),
): StudentHomeworkCardView {
  const graded = item.submissionStatus === 'returned';
  const handedIn = item.submissionStatus === 'submitted' || item.submissionStatus === 'late';
  const statusLabel = graded
    ? 'Graded'
    : handedIn
      ? 'Submitted'
      : item.assignmentStatus === 'closed'
        ? 'Closed'
        : 'Pending';
  const statusTone = graded ? 'teal' : handedIn ? 'primary' : item.assignmentStatus === 'closed' ? 'neutral' : 'warning';
  const scoreLabel =
    item.marksAwarded !== null ? `${item.marksAwarded}/${item.maxMarks}` : null;
  return {
    id: item.id,
    title: item.title,
    metaLine: trackerMetaLine(item.batchName, item.dueAt, today),
    subjectName: item.subjectName,
    description: item.description,
    statusLabel,
    statusTone,
    scoreLabel,
    linkUrl: item.linkUrl,
    attachmentNames: item.attachmentNames,
  };
}
