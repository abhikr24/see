import React, { useMemo } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  Button,
  Card,
  Chip,
  DateField,
  EmptyState,
  ErrorState,
  Input,
  ListSkeleton,
  Select,
  Text,
} from '@/components/ui';
import { C, LAYOUT, S } from '@/lib/theme';
import { AssignAttachmentCard, NotifyStudentsCard } from '../components/AssignExtras';
import { DUE_TIME_PRESETS, useAssignHomeworkForm } from '../hooks';
import { todayUtcIso } from '../model';

export interface AssignHomeworkScreenProps {
  initialBatchId?: string;
}

function goBackToHomework() {
  if (router.canGoBack()) router.back();
  else router.replace('/(teacher)/homework' as never);
}

export function AssignHomeworkScreen({ initialBatchId }: AssignHomeworkScreenProps) {
  const form = useAssignHomeworkForm(initialBatchId);
  const minDate = useMemo(() => todayUtcIso(), []);

  const batchOptions = useMemo(
    () =>
      form.batches.map((b) => ({
        value: b.batchId,
        label: b.name,
        subtitle: `${b.subjectName ?? 'General'} · ${b.studentCount} ${b.studentCount === 1 ? 'student' : 'students'}`,
        badge: String(b.studentCount),
      })),
    [form.batches],
  );

  const subjectOptions = useMemo(
    () => form.subjectList.map((s) => ({ value: s.id, label: s.name, badge: s.code })),
    [form.subjectList],
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 10, paddingBottom: 6 }}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Back to homework"
            onPress={goBackToHomework}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
          >
            <Ionicons name="chevron-back" size={20} color={C.primary} />
            <Text variant="caption" weight={700} c={C.primary}>
              Homework
            </Text>
          </Pressable>
        </View>

        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 28, gap: S.md + 2 }}
          showsVerticalScrollIndicator={false}
        >
          <View style={{ gap: 2 }}>
            <Text variant="h2">Assign homework</Text>
            <Text variant="caption" c={C.secondary}>
              Choose one of your batches, set a due time, and attach a worksheet or link.
            </Text>
          </View>

          {form.loading ? (
            <ListSkeleton rows={4} h={64} />
          ) : form.error ? (
            <Card flat>
              <ErrorState message={form.error.message} onRetry={() => void form.retry()} />
            </Card>
          ) : form.batches.length === 0 ? (
            <Card flat>
              <EmptyState
                icon="library-outline"
                title="No classes assigned yet"
                text="You can assign homework as soon as a batch is assigned to you."
              />
            </Card>
          ) : (
            <>
              <Select
                label="Batch"
                options={batchOptions}
                value={form.effectiveBatchId}
                onChange={form.selectBatch}
                placeholder="Choose batch"
                error={form.errors.batchId}
              />

              <Select
                label="Subject"
                options={subjectOptions}
                value={form.effectiveSubjectId}
                onChange={form.setSubjectId}
                placeholder="Choose subject"
                error={form.errors.subjectId}
              />

              <Input
                label="Title"
                value={form.title}
                onChangeText={form.setTitle}
                placeholder="e.g. Quadratic equations: Practice set 2"
                error={form.errors.title}
                returnKeyType="next"
              />

              <Input
                label="Description"
                value={form.description}
                onChangeText={form.setDescription}
                placeholder="Questions to solve, chapter pages, or submission notes…"
                multiline
              />

              <View style={{ flexDirection: 'row', gap: 12 }}>
                <View style={{ flex: 1 }}>
                  <DateField
                    label="Due date"
                    value={form.dueDate}
                    minDate={minDate}
                    onChange={(_dmy, iso) => form.setDueDate(iso)}
                    error={form.errors.dueDate}
                  />
                </View>
                <View style={{ width: 126 }}>
                  <Input
                    label="Due time"
                    value={form.dueTime}
                    onChangeText={form.setDueTime}
                    placeholder="20:00"
                    error={form.errors.dueTime}
                    maxLength={5}
                  />
                </View>
              </View>

              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                {DUE_TIME_PRESETS.map((preset) => (
                  <Chip
                    key={preset.value}
                    label={preset.label}
                    active={form.dueTime === preset.value}
                    onPress={() => form.setDueTime(preset.value)}
                  />
                ))}
              </ScrollView>

              <Input
                label="Max marks"
                value={form.maxMarksText}
                onChangeText={form.setMaxMarksText}
                placeholder="20"
                keyboardType="number-pad"
                error={form.errors.maxMarks}
              />

              <AssignAttachmentCard
                file={form.file}
                onAttachFile={() => void form.attachFile()}
                onClearFile={form.clearFile}
                linkUrl={form.linkUrl}
                onChangeLinkUrl={form.setLinkUrl}
                linkError={form.errors.linkUrl}
              />

              <NotifyStudentsCard
                value={form.notifyStudents}
                alertsEnabled={form.alertsEnabled}
                onChange={form.setNotifyStudents}
              />
            </>
          )}
        </ScrollView>

        {form.batches.length > 0 ? (
          <View
            style={{
              paddingHorizontal: LAYOUT.margin,
              paddingTop: 10,
              paddingBottom: 14,
              backgroundColor: C.surface,
              borderTopWidth: 1,
              borderTopColor: C.hairline,
            }}
          >
            <Button
              title={form.footerLabel}
              variant="primary"
              loading={form.saving}
              onPress={() => void form.submit()}
            />
          </View>
        ) : null}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
