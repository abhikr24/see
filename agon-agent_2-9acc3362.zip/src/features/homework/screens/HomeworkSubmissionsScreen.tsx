import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  RefreshControl,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  Button,
  Card,
  Divider,
  EmptyState,
  ErrorState,
  ListSkeleton,
  Text,
} from '@/components/ui';
import { pct } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { SubmissionRow, type SubmissionRowItem } from '../components/SubmissionRow';
import { TwoToneBar } from '../components/TwoToneBar';
import { useHomeworkSubmissionsScreen } from '../hooks';

export interface HomeworkSubmissionsScreenProps {
  assignmentId: string;
}

function goBackToTracker() {
  if (router.canGoBack()) router.back();
  else router.replace('/(teacher)/homework' as never);
}

export function HomeworkSubmissionsScreen({ assignmentId }: HomeworkSubmissionsScreenProps) {
  const vm = useHomeworkSubmissionsScreen(assignmentId);
  const data = vm.data;
  const isClosed = data?.assignment.status === 'closed';

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View
          style={{
            paddingHorizontal: LAYOUT.margin,
            paddingTop: 10,
            paddingBottom: 8,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 12,
          }}
        >
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Back to homework"
            onPress={goBackToTracker}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
          >
            <Ionicons name="chevron-back" size={20} color={C.primary} />
            <Text variant="caption" weight={700} c={C.primary}>
              Homework
            </Text>
          </Pressable>

          {data ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={isClosed ? 'Reopen homework' : 'Close homework'}
              disabled={vm.updatingStatus}
              onPress={() => void vm.toggleClosed()}
              style={({ pressed }) => ({
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: R.chip,
                backgroundColor: C.surface,
                borderWidth: 1,
                borderColor: C.hairline,
                opacity: vm.updatingStatus ? 0.5 : pressed ? 0.8 : 1,
              })}
            >
              <Text variant="label" weight={700} c={C.secondary}>
                {isClosed ? 'Reopen' : 'Close'}
              </Text>
            </Pressable>
          ) : null}
        </View>

        {vm.loading ? (
          <View style={{ padding: LAYOUT.margin }}>
            <ListSkeleton rows={5} h={80} />
          </View>
        ) : vm.error ? (
          <View style={{ padding: LAYOUT.margin }}>
            <Card flat>
              {vm.error.code === 'NOT_FOUND' ? (
                <EmptyState
                  icon="alert-circle-outline"
                  title="Homework not found"
                  text="This homework set does not exist or belongs to another batch."
                  actionLabel="Go back"
                  onAction={goBackToTracker}
                />
              ) : (
                <ErrorState message={vm.error.message} onRetry={() => void vm.refresh()} />
              )}
            </Card>
          </View>
        ) : data ? (
          <>
            <FlatList<SubmissionRowItem>
              style={{ flex: 1 }}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{
                paddingHorizontal: LAYOUT.margin,
                paddingBottom: 24,
              }}
              data={vm.rows}
              keyExtractor={(row) => row.studentId}
              ListHeaderComponent={
                <View style={{ gap: 14, paddingBottom: 14 }}>
                  <Card flat style={{ gap: 12 }}>
                    <View style={{ gap: 3 }}>
                      <Text variant="title" weight={700} c={C.ink}>
                        {data.assignment.title}
                      </Text>
                      <Text variant="caption" c={C.secondary} tabular>
                        {[data.batchName, data.subjectName, `Max ${vm.maxMarks}`].filter(Boolean).join(' · ')}
                      </Text>
                    </View>

                    <Text variant="h2" weight={800} c={C.ink} tabular>
                      {vm.headerProgress}
                    </Text>

                    <TwoToneBar
                      assignmentId={data.assignment.id}
                      submittedCount={data.submittedCount}
                      pendingCount={data.pendingCount}
                      totalStudents={data.totalStudents}
                      percentageLabel={pct(data.percentage)}
                    />
                  </Card>

                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      paddingHorizontal: 4,
                    }}
                  >
                    <Text variant="label" c={C.muted}>
                      STUDENT
                    </Text>
                    <Text variant="label" c={C.muted}>
                      GRADE (MAX {vm.maxMarks})
                    </Text>
                  </View>
                </View>
              }
              renderItem={({ item, index }) => (
                <View
                  style={{
                    borderLeftWidth: 1,
                    borderRightWidth: 1,
                    borderTopWidth: index === 0 ? 1 : 0,
                    borderBottomWidth: index === vm.rows.length - 1 ? 1 : 0,
                    borderColor: C.hairline,
                    borderTopLeftRadius: index === 0 ? R.card : 0,
                    borderTopRightRadius: index === 0 ? R.card : 0,
                    borderBottomLeftRadius: index === vm.rows.length - 1 ? R.card : 0,
                    borderBottomRightRadius: index === vm.rows.length - 1 ? R.card : 0,
                    overflow: 'hidden',
                  }}
                >
                  <SubmissionRow
                    row={item}
                    maxMarks={vm.maxMarks}
                    expanded={vm.expandedId === item.studentId}
                    busy={vm.actingStudentId === item.studentId}
                    onToggleExpand={vm.toggleExpand}
                    onChangeGrade={vm.setGradeText}
                    onApprove={(id) => void vm.approveRow(id)}
                    onAskAgain={(id) => void vm.askAgainRow(id)}
                  />
                </View>
              )}
              ItemSeparatorComponent={() => <Divider />}
              ListEmptyComponent={
                <Card flat>
                  <EmptyState
                    icon="people-outline"
                    title="No students enrolled"
                    text="Enrol students in this batch to collect and grade homework."
                  />
                </Card>
              }
              refreshControl={
                <RefreshControl
                  refreshing={vm.refreshing}
                  onRefresh={() => void vm.refresh()}
                  tintColor={C.primary}
                  colors={[C.primary]}
                />
              }
              showsVerticalScrollIndicator={false}
            />

            <View
              style={{
                paddingHorizontal: LAYOUT.margin,
                paddingTop: 10,
                paddingBottom: 14,
                backgroundColor: C.surface,
                borderTopWidth: 1,
                borderTopColor: C.hairline,
                gap: 8,
              }}
            >
              {vm.invalidCount > 0 ? (
                <Text variant="caption" weight={600} c={C.danger} tabular>
                  Grade must be ≤ {vm.maxMarks}. Fix highlighted rows to save.
                </Text>
              ) : null}
              <Button
                title={vm.saveFooterTitle}
                variant="primary"
                disabled={!vm.canSave}
                loading={vm.savingGrades}
                onPress={() => void vm.saveAllGrades()}
              />
            </View>
          </>
        ) : null}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
