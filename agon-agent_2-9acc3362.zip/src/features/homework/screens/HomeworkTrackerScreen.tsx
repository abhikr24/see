import React, { useEffect } from 'react';
import { FlatList, RefreshControl, ScrollView, View } from 'react-native';
import { router } from 'expo-router';

import {
  Button,
  Card,
  Chip,
  EmptyState,
  ErrorState,
  ListSkeleton,
  SegmentedControl,
  Text,
} from '@/components/ui';
import { C, LAYOUT, S } from '@/lib/theme';
import { TrackerCard } from '../components/TrackerCard';
import { useHomeworkTrackerScreen, type TrackerSegment } from '../hooks';
import type { TrackerCardView } from '../model';

const TAB_BAR_INSET = 136;

export interface HomeworkTrackerScreenProps {
  initialBatchId?: string;
  action?: string;
}

export function HomeworkTrackerScreen({ initialBatchId, action }: HomeworkTrackerScreenProps) {
  const vm = useHomeworkTrackerScreen(initialBatchId);

  useEffect(() => {
    if (action === 'assign') {
      if (initialBatchId) {
        router.push({ pathname: '/(teacher)/homework/new', params: { batchId: initialBatchId } } as never);
      } else {
        router.push('/(teacher)/homework/new' as never);
      }
    }
  }, [action, initialBatchId]);

  const segments = [
    { key: 'active' as const, label: 'Active', count: vm.activeCount },
    { key: 'closed' as const, label: 'Closed', count: vm.closedCount },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: S.md, gap: S.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          <Text variant="h1" numberOfLines={1} style={{ flex: 1 }}>
            Homework
          </Text>
          <Button
            title="Assign"
            icon="add-outline"
            variant="primary"
            size="sm"
            accessibilityLabel="Assign homework"
            onPress={vm.openAssign}
            full={false}
          />
        </View>

        {vm.ownBatches.length > 1 ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            <Chip
              label="All classes"
              active={vm.selectedBatchId === null}
              onPress={() => vm.setSelectedBatchId(null)}
            />
            {vm.ownBatches.map((batch) => (
              <Chip
                key={batch.batchId}
                label={batch.name}
                active={vm.selectedBatchId === batch.batchId}
                onPress={() => vm.setSelectedBatchId(batch.batchId)}
              />
            ))}
          </ScrollView>
        ) : null}

        <SegmentedControl<TrackerSegment>
          options={segments}
          value={vm.segment}
          onChange={vm.setSegment}
        />
      </View>

      <FlatList<TrackerCardView>
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: LAYOUT.margin,
          paddingBottom: TAB_BAR_INSET,
          gap: 14,
          flexGrow: 1,
        }}
        data={vm.status === 'ready' ? vm.cards : []}
        keyExtractor={(card) => card.id}
        renderItem={({ item }) => (
          <TrackerCard
            card={item}
            reminding={vm.remindingId === item.id}
            onRemind={(id) => void vm.remind(id)}
            onOpenSubmissions={vm.openSubmissions}
          />
        )}
        ListEmptyComponent={
          vm.status === 'loading' ? (
            <ListSkeleton rows={3} h={168} />
          ) : vm.status === 'error' ? (
            <Card flat>
              <ErrorState
                title="Could not load homework"
                message={vm.errorMessage ?? 'Something went wrong.'}
                onRetry={() => void vm.refresh()}
              />
            </Card>
          ) : vm.segment === 'active' ? (
            <Card flat>
              <EmptyState
                icon="book-outline"
                title="No active homework"
                text="Assign a worksheet or practice set to start tracking submissions."
                actionLabel="Assign homework"
                onAction={vm.openAssign}
              />
            </Card>
          ) : (
            <Card flat>
              <EmptyState
                icon="checkmark-done-outline"
                title="No closed homework yet"
                text="Closed assignments move here once submissions wrap up."
              />
            </Card>
          )
        }
        refreshControl={
          <RefreshControl
            refreshing={vm.refreshing}
            onRefresh={() => void vm.refresh()}
            tintColor={C.primary}
            colors={[C.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
