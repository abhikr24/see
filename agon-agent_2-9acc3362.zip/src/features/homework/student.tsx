import React from 'react';
import { FlatList, Linking, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import {
  Badge,
  Card,
  EmptyState,
  ErrorState,
  ListSkeleton,
  Text,
} from '@/components/ui';
import { C, LAYOUT } from '@/lib/theme';
import { useStudentHomeworkScreen } from './hooks';
import type { StudentHomeworkCardView } from './model';

const TAB_BAR_INSET = 136;

function StudentHomeworkCard({ item }: { item: StudentHomeworkCardView }) {
  return (
    <Card flat style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
        <View style={{ flex: 1, gap: 3 }}>
          {item.subjectName ? (
            <Text variant="label" weight={700} c={C.muted}>
              {item.subjectName.toUpperCase()}
            </Text>
          ) : null}
          <Text variant="title" weight={700} c={C.ink}>
            {item.title}
          </Text>
          <Text variant="caption" c={C.secondary} tabular>
            {item.metaLine}
          </Text>
        </View>
        <View style={{ alignItems: 'flex-end', gap: 4 }}>
          <Badge label={item.statusLabel} tone={item.statusTone} />
          {item.scoreLabel ? (
            <Text variant="caption" weight={800} c={C.teal} tabular>
              {item.scoreLabel}
            </Text>
          ) : null}
        </View>
      </View>

      {item.description ? (
        <Text variant="caption" c={C.secondary}>
          {item.description}
        </Text>
      ) : null}

      {item.attachmentNames.length > 0 || item.linkUrl ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {item.attachmentNames.map((name) => (
            <View key={name} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Ionicons name="document-attach-outline" size={14} color={C.primary} />
              <Text variant="caption" weight={600} c={C.primary}>
                {name}
              </Text>
            </View>
          ))}
          {item.linkUrl ? (
            <Pressable
              accessibilityRole="link"
              accessibilityLabel={`Open link ${item.linkUrl}`}
              onPress={() => void Linking.openURL(item.linkUrl as string)}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
            >
              <Ionicons name="link-outline" size={14} color={C.primary} />
              <Text variant="caption" weight={600} c={C.primary} numberOfLines={1}>
                Reference link
              </Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}
    </Card>
  );
}

export function StudentHomeworkScreen() {
  const vm = useStudentHomeworkScreen();

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList<StudentHomeworkCardView>
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: LAYOUT.margin,
          paddingBottom: TAB_BAR_INSET,
          gap: 14,
          flexGrow: 1,
        }}
        data={vm.items}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <View style={{ gap: 2, paddingBottom: 2 }}>
            <Text variant="h1">Homework</Text>
            <Text variant="caption" c={C.secondary}>
              Worksheets and practice sets assigned to your classes.
            </Text>
          </View>
        }
        renderItem={({ item }) => <StudentHomeworkCard item={item} />}
        ListEmptyComponent={
          vm.loading ? (
            <ListSkeleton rows={3} h={120} />
          ) : vm.error ? (
            <Card flat>
              <ErrorState message={vm.error.message} onRetry={() => void vm.refresh()} />
            </Card>
          ) : (
            <Card flat>
              <EmptyState
                icon="book-outline"
                title="No homework yet"
                text="New assignments from your teachers will appear here right away."
              />
            </Card>
          )
        }
        refreshControl={
          <RefreshControl
            refreshing={vm.refreshing}
            onRefresh={() => void vm.refresh()}
            tintColor={C.primary}
            colors={[C.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
