import { useCallback, useMemo, useState } from 'react';

import { useHomeworkSubmissions } from '@/core/backend';
import { HOMEWORK_DEFAULT_MAX_MARKS } from '@/core/contracts/homework';
import type { HomeworkGradeEntry } from '@/core/contracts/models';
import {
  parseGradeDraft,
  saveGradesFooterLabel,
  submissionsHeaderLabel,
  toSubmissionRowView,
} from './model';

export function useHomeworkSubmissionsScreen(assignmentId: string) {
  const subs = useHomeworkSubmissions(assignmentId || null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [actingStudentId, setActingStudentId] = useState<string | null>(null);

  const data = subs.data;
  const maxMarks = data?.maxMarks ?? HOMEWORK_DEFAULT_MAX_MARKS;

  const gradeForStudent = useCallback(
    (studentId: string, savedMarks: number | null): string => {
      if (touched[studentId]) return drafts[studentId] ?? '';
      return savedMarks !== null ? String(savedMarks) : '';
    },
    [drafts, touched],
  );

  const setGradeText = useCallback((studentId: string, raw: string) => {
    const cleaned = raw.replace(/[^0-9.]/g, '');
    setTouched((prev) => ({ ...prev, [studentId]: true }));
    setDrafts((prev) => ({ ...prev, [studentId]: cleaned }));
  }, []);

  const rows = useMemo(() => {
    if (!data) return [];
    return data.rows.map((row) => {
      const text = gradeForStudent(row.studentId, row.marksAwarded);
      const parsed = parseGradeDraft(text, maxMarks);
      return {
        ...toSubmissionRowView(row),
        gradeText: text,
        gradeValue: parsed.value,
        gradeError: parsed.error,
        hasGrade: parsed.hasValue,
      };
    });
  }, [data, gradeForStudent, maxMarks]);

  const invalidRows = useMemo(() => rows.filter((r) => r.gradeError !== null), [rows]);
  const validEntries = useMemo<HomeworkGradeEntry[]>(
    () =>
      rows
        .filter((r) => r.hasGrade && r.gradeError === null && r.gradeValue !== null)
        .map((r) => ({ studentId: r.studentId, marksAwarded: r.gradeValue as number })),
    [rows],
  );

  const saveAllGrades = useCallback(async () => {
    if (invalidRows.length > 0 || validEntries.length === 0) return;
    const res = await subs.saveGrades(validEntries);
    if (res.ok) {
      setTouched({});
      setDrafts({});
    }
  }, [invalidRows.length, subs, validEntries]);

  const approveRow = useCallback(
    async (studentId: string) => {
      const row = rows.find((r) => r.studentId === studentId);
      if (!row || row.gradeError) return;
      setActingStudentId(studentId);
      try {
        const res = await subs.approve({
          studentId,
          marksAwarded: row.hasGrade ? row.gradeValue : undefined,
        });
        if (res.ok) setTouched((prev) => ({ ...prev, [studentId]: false }));
      } finally {
        setActingStudentId(null);
      }
    },
    [rows, subs],
  );

  const askAgainRow = useCallback(
    async (studentId: string) => {
      setActingStudentId(studentId);
      try {
        const res = await subs.askAgain({ studentId });
        if (res.ok) {
          setTouched((prev) => ({ ...prev, [studentId]: false }));
          setDrafts((prev) => ({ ...prev, [studentId]: '' }));
        }
      } finally {
        setActingStudentId(null);
      }
    },
    [subs],
  );

  const toggleClosed = useCallback(async () => {
    if (!data) return;
    if (data.assignment.status === 'closed') await subs.reopen();
    else await subs.close();
  }, [data, subs]);

  return {
    loading: subs.loading && !data,
    error: subs.error && !data ? subs.error : null,
    refreshing: subs.loading && Boolean(data),
    refresh: subs.refetch,
    data,
    maxMarks,
    headerProgress: data ? submissionsHeaderLabel(data.submittedCount, data.totalStudents) : '',
    rows,
    expandedId,
    toggleExpand: (studentId: string) => setExpandedId((prev) => (prev === studentId ? null : studentId)),
    setGradeText,
    invalidCount: invalidRows.length,
    enteredCount: validEntries.length,
    saveFooterTitle: saveGradesFooterLabel(validEntries.length),
    canSave: validEntries.length > 0 && invalidRows.length === 0 && !subs.savingGrades,
    savingGrades: subs.savingGrades,
    saveAllGrades,
    actingStudentId,
    approveRow,
    askAgainRow,
    toggleClosed,
    updatingStatus: subs.updatingStatus,
  };
}
