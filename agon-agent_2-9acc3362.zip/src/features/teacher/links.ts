import type { ID, ISODate } from '@/core/contracts/models';

/** A route plus its query params, in the shape `router.push` takes. */
export interface TeacherLink {
  pathname: string;
  params?: Record<string, string>;
}

export interface AttendanceTarget {
  batchId: ID;
  date: ISODate;
  period?: number;
  subjectId?: ID | null;
}

const link = (pathname: string, params: Record<string, string> = {}, batchId?: ID | null): TeacherLink => ({
  pathname,
  params: batchId ? { ...params, batchId } : params,
});

/**
 * Every place the teacher home and My Classes can send the teacher, in one
 * table. The receiving screen reads `batchId` (and `action`) with
 * `useLocalSearchParams`; re-pointing a shortcut is a one-line change here.
 */
export const teacherLinks = {
  home: (): TeacherLink => link('/(teacher)'),
  classes: (): TeacherLink => link('/(teacher)/classes'),
  /** Take Attendance for one of the teacher's own batches, with the batch, date and period prefilled. */
  attendance: ({ batchId, date, period = 1, subjectId }: AttendanceTarget): TeacherLink => {
    const params: Record<string, string> = { batchId, date, period: String(period) };
    if (subjectId) params.subjectId = subjectId;
    return { pathname: '/(teacher)/[batchId]', params };
  },
  homework: (batchId?: ID | null): TeacherLink => link('/(teacher)/homework', {}, batchId),
  assignHomework: (batchId: ID | null): TeacherLink => link('/(teacher)/homework/new', {}, batchId),
  enterMarks: (batchId: ID | null): TeacherLink => link('/(teacher)/exams', { action: 'marks' }, batchId),
  shareMaterial: (batchId: ID | null): TeacherLink => link('/(teacher)/more', { action: 'share-material' }, batchId),
} as const;
