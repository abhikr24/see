import assert from 'node:assert/strict';

import { batchRepo } from '../src/backends/memory/academics';
import { analyticsRepo } from '../src/backends/memory/business';
import { assignmentRepo, submissionRepo } from '../src/backends/memory/coursework';
import { createDb } from '../src/backends/memory/db';
import { capture, restore } from '../src/backends/memory/persist';
import { seed, SEED } from '../src/backends/memory/seed';
import { isBackendError } from '../src/core/contracts/errors';
import { assertHomeworkCounts, computeHomeworkCounts } from '../src/core/contracts/homework';
import { queryCache, queryKey } from '../src/core/hooks/cache';
import {
  buildDueAtIso, formatHomeworkDue, formatSubmittedAt, parseGradeDraft,
  saveGradesFooterLabel, sendFooterLabel, submissionsHeaderLabel,
  todayUtcIso, toTrackerCardView, trackerMetaLine,
} from '../src/features/homework/model';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => { passed += 1; console.log(`  ✓ ${name}`); });

const rejects = async (promise: Promise<unknown>, code: string) => {
  try { await promise; } catch (error) {
    assert.ok(isBackendError(error), `expected BackendError, got ${String(error)}`);
    assert.equal(error.code, code, error.message);
    return error;
  }
  return assert.fail(`expected ${code}`);
};

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const ROHIT = sid(3);
const PRIYA = sid(4);
const AARAV = sid(14);
const CLASS_10A = sid(9);
const CLASS_9A = sid(10);
const MATHS = sid(44);
const QUADRATIC_HW = sid(14002);
const TRIG_HW = sid(14003);
const PHYSICS_HW = sid(14012);

async function main() {
  const db = createDb();
  seed(db);
  const i = SEED.instituteId;
  const today = todayUtcIso();
  const assignments = assignmentRepo(db);
  const submissions = submissionRepo(db);
  const batches = batchRepo(db);
  const analytics = analyticsRepo(db);
  const as = (userId: string | null) => { db.session.userId = userId; };

  console.log('Teacher homework assign, tracker and submissions acceptance');

  await check('batch picker and homework endpoints are strictly scoped to the teacher\'s own batches', async () => {
    as(ROHIT);
    const rohitBatches = await batches.listMyClasses(i);
    assert.deepEqual(rohitBatches.map((b) => [b.batchId, b.name, b.studentCount]), [[CLASS_10A, 'Class 10-A', 12]]);
    assert.equal(sendFooterLabel(rohitBatches[0].studentCount), 'Send to 12 students');
    assert.equal(sendFooterLabel(42), 'Send to 42 students');
    assert.ok((await assignments.tracker(i)).active.every((item) => item.batchId === CLASS_10A));

    as(PRIYA);
    const priyaBatches = await batches.listMyClasses(i);
    assert.deepEqual(priyaBatches.map((b) => [b.batchId, b.name, b.studentCount]), [[CLASS_9A, 'Class 9-A', 10]]);
    assert.ok((await assignments.tracker(i)).active.every((item) => item.batchId === CLASS_9A));

    as(ROHIT);
    await rejects(assignments.assign(i, { batchId: CLASS_9A, subjectId: MATHS, title: 'Blocked', dueAt: buildDueAtIso(today, '20:00') }), 'NOT_FOUND');
    await rejects(assignments.tracker(i, { batchId: CLASS_9A }), 'NOT_FOUND');
    await rejects(assignments.remindPending(i, PHYSICS_HW), 'NOT_FOUND');
    await rejects(submissions.forAssignment(i, PHYSICS_HW), 'NOT_FOUND');
    await rejects(submissions.saveGrades(i, PHYSICS_HW, [{ studentId: sid(26), marksAwarded: 15 }]), 'NOT_FOUND');
    await rejects(submissions.approve(i, PHYSICS_HW, sid(26), 15), 'NOT_FOUND');
    await rejects(submissions.askAgain(i, PHYSICS_HW, sid(26)), 'NOT_FOUND');
  });

  await check('assigning homework appears instantly in the student\'s homework list and notifies student + parent', async () => {
    queryCache.clear();
    as(AARAV);
    const studentKey = queryKey('memory', 'assignments', i, ['for-student']);
    await queryCache.fetch(studentKey, () => assignments.forStudent(i));
    assert.equal(((queryCache.read(studentKey).data as unknown[]) ?? []).length, 3);
    const beforeNotifs = db.notifications.all(i).length;

    as(ROHIT);
    const created = await assignments.assign(i, {
      batchId: CLASS_10A, subjectId: MATHS, title: 'Coordinate geometry: Section formula',
      description: 'Complete Q1–Q10 in your fair notebook.', dueAt: buildDueAtIso(today, '20:00'),
      maxMarks: 20, linkUrl: 'https://sunrise.test/worksheets/coord-geo.pdf',
      file: { fileName: 'section-formula-notes.pdf', uri: 'data:application/pdf;base64,JVBERi0xLjQK', mimeType: 'application/pdf', sizeBytes: 51200 },
      notifyStudents: true,
    });
    assert.equal(created.assignment.status, 'published');
    assert.equal(created.studentsNotified, 12);
    assert.equal(created.parentsNotified, 12);
    assert.equal(created.alertsDisabled, false);
    assert.equal(db.notifications.all(i).length - beforeNotifs, 24);

    as(AARAV);
    await queryCache.invalidate([`memory|assignments|${i}|`]);
    const instantList = await assignments.forStudent(i);
    assert.equal(instantList[0].title, 'Coordinate geometry: Section formula');
    assert.equal(instantList[0].linkUrl, 'https://sunrise.test/worksheets/coord-geo.pdf');
    assert.deepEqual(instantList[0].attachmentNames, ['section-formula-notes.pdf']);
    const page = await assignments.list(i);
    assert.ok(page.items.some((a) => a.id === created.assignment.id));
    assert.ok(page.items.every((a) => a.batchId === CLASS_10A));
  });

  await check('homework notifications on send are gated by institute homeworkAlerts and the notify toggle', async () => {
    const institute = db.institutes.get(i, i);
    const before = db.notifications.all(i).length;
    db.institutes.put({ ...institute, settings: { ...institute.settings, features: { ...institute.settings.features, homeworkAlerts: false } } });
    as(ROHIT);
    const gatedOff = await assignments.assign(i, { batchId: CLASS_10A, subjectId: MATHS, title: 'Circles: Tangent theorems', dueAt: buildDueAtIso(today, '20:00'), notifyStudents: true });
    assert.equal(gatedOff.alertsDisabled, true);
    assert.equal(gatedOff.studentsNotified + gatedOff.parentsNotified, 0);
    assert.equal(db.notifications.all(i).length, before);

    db.institutes.put(institute);
    const toggleOff = await assignments.assign(i, { batchId: CLASS_10A, subjectId: MATHS, title: 'Constructions practice', dueAt: buildDueAtIso(today, '21:00'), notifyStudents: false });
    assert.equal(toggleOff.alertsDisabled, false);
    assert.equal(toggleOff.studentsNotified + toggleOff.parentsNotified, 0);
    assert.equal(db.notifications.all(i).length, before);
  });

  await check('counts always add up to the batch size, and __DEV__ logs a warning when violated', async () => {
    const warnings: string[] = [];
    const origWarn = console.warn;
    const g = globalThis as { __DEV__?: boolean };
    const prevDev = g.__DEV__;
    console.warn = (...args: unknown[]) => warnings.push(args.map(String).join(' '));
    try {
      g.__DEV__ = true;
      assert.equal(assertHomeworkCounts(28, 14, 42, 'hw-42'), true);
      assert.equal(warnings.length, 0);
      assert.equal(assertHomeworkCounts(27, 14, 42, 'hw-bad'), false);
      assert.equal(warnings.length, 1);
      assert.match(warnings[0], /submitted \(27\) \+ pending \(14\) !== batch student count \(42\)/);
      g.__DEV__ = false;
      assert.equal(assertHomeworkCounts(1, 1, 10, 'hw-prod'), false);
      assert.equal(warnings.length, 1);
    } finally {
      console.warn = origWarn;
      if (prevDev === undefined) delete g.__DEV__;
      else g.__DEV__ = prevDev;
    }

    const fortyTwo = Array.from({ length: 42 }, (_, idx) => sid(5000 + idx));
    const twentyEightSubs = fortyTwo.slice(0, 28).map((studentId, idx) => ({
      id: sid(6000 + idx), instituteId: i, createdAt: `${today}T10:00:00.000Z`, updatedAt: `${today}T10:00:00.000Z`,
      assignmentId: sid(99001), batchId: CLASS_10A, studentId, content: null, submittedAt: '2026-11-11T21:14:00.000Z',
      status: (idx < 10 ? 'returned' : 'submitted') as 'returned' | 'submitted',
    }));
    const c42 = computeHomeworkCounts(fortyTwo, twentyEightSubs, sid(99001));
    assert.deepEqual([c42.totalStudents, c42.submittedCount, c42.pendingCount, c42.percentage], [42, 28, 14, 67]);
    assert.equal(submissionsHeaderLabel(c42.submittedCount, c42.totalStudents), '28 of 42 submitted');
    assert.equal(saveGradesFooterLabel(28), 'Save 28 grades');

    as(SEED.ownerId);
    const all = await assignments.tracker(i);
    for (const item of [...all.active, ...all.closed]) {
      assert.equal(item.totalStudents, db.enrollments.all(i, { batchId: item.batchId, status: 'active' }).length);
      assert.equal(item.submittedCount + item.pendingCount, item.totalStudents);
    }
  });

  await check('reminding pending creates notifications ONLY for students who have not submitted', async () => {
    const submittedRolls = [14, 15, 16, 17, 18];
    const pendingRolls = [19, 20, 21, 22, 23, 24, 25];
    for (const roll of submittedRolls) {
      as(sid(roll));
      await submissions.submit(i, { assignmentId: TRIG_HW, studentId: sid(roll), content: 'My answers' });
    }
    as(ROHIT);
    const before = db.notifications.all(i, { type: 'homework_reminder' }).length;
    const res = await assignments.remindPending(i, TRIG_HW);
    assert.deepEqual([res.pendingCount, res.notified], [7, 7]);
    const notifiedUsers = db.notifications.all(i, { type: 'homework_reminder' }).slice(before).map((n) => n.userId).sort();
    assert.deepEqual(notifiedUsers, pendingRolls.map(sid).sort());
  });

  await check('grading validates grade <= max and updates the tracker percentage and counts', async () => {
    as(ROHIT);
    let trigCard = (await assignments.tracker(i)).active.find((a) => a.id === TRIG_HW);
    assert.deepEqual([trigCard?.submittedCount, trigCard?.pendingCount, trigCard?.percentage], [5, 7, 42]);
    assert.equal(parseGradeDraft('25', 20).error, 'Max 20');
    assert.equal(parseGradeDraft('20', 20).error, null);
    await rejects(submissions.saveGrades(i, TRIG_HW, [{ studentId: sid(14), marksAwarded: 18 }, { studentId: sid(19), marksAwarded: 21 }]), 'VALIDATION');
    assert.equal((await submissions.forAssignment(i, TRIG_HW)).gradedCount, 0);

    const saved = await submissions.saveGrades(i, TRIG_HW, [14, 15, 16, 17, 19, 20, 21, 22].map((r) => ({ studentId: sid(r), marksAwarded: 18 })));
    assert.equal(saved.length, 8);
    trigCard = (await assignments.tracker(i)).active.find((a) => a.id === TRIG_HW);
    assert.deepEqual([trigCard?.submittedCount, trigCard?.pendingCount, trigCard?.percentage, trigCard?.gradedCount], [9, 3, 75, 8]);
  });

  await check('Approve and Ask again: Ask again notifies ONLY that student and updates counts', async () => {
    as(ROHIT);
    const detailBefore = await submissions.forAssignment(i, QUADRATIC_HW);
    assert.equal(detailBefore.submittedCount, 12);
    assert.ok(detailBefore.rows[0].attachments.length > 0);
    await submissions.approve(i, QUADRATIC_HW, sid(15), 23);
    assert.equal((await analytics.teacherHome(i)).submissionsToGrade, 12);

    const beforeAsk = db.notifications.all(i).length;
    const asked = await submissions.askAgain(i, QUADRATIC_HW, AARAV);
    assert.deepEqual([asked.notified, asked.submission.status], [true, 'pending']);
    const newNotifs = db.notifications.all(i).slice(beforeAsk);
    assert.equal(newNotifs.length, 1);
    assert.deepEqual([newNotifs[0].userId, newNotifs[0].type], [AARAV, 'homework_ask_again']);

    const afterTracker = (await assignments.tracker(i)).active.find((a) => a.id === QUADRATIC_HW);
    assert.deepEqual([afterTracker?.submittedCount, afterTracker?.pendingCount, afterTracker?.percentage], [11, 1, 92]);
  });

  await check('overdue pill, copy formatters, Active/Closed switching and snapshot persistence', async () => {
    assert.equal(trackerMetaLine('Class 10-A', `${today}T20:00:00.000Z`, today), 'Class 10-A · Due today, 8:00 PM');
    assert.equal(formatHomeworkDue('2026-11-11T20:00:00.000Z', '2026-11-14'), 'Due 11 Nov, 8:00 PM');
    assert.equal(formatSubmittedAt('2026-11-11T21:14:00.000Z'), 'Submitted 11 Nov, 9:14 PM');

    as(ROHIT);
    const linearId = sid(14001);
    let tracker = await assignments.tracker(i);
    assert.equal(toTrackerCardView(tracker.active.find((a) => a.id === linearId)!, today).isOverdue, true);
    await assignments.close(i, linearId);
    tracker = await assignments.tracker(i);
    assert.equal(toTrackerCardView(tracker.closed.find((a) => a.id === linearId)!, today).isOverdue, false);

    const snap = capture(db);
    const copy = createDb();
    assert.equal(restore(copy, snap), true);
    copy.session.userId = ROHIT;
    assert.equal((await assignmentRepo(copy).tracker(i)).closed.length, 1);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => { console.error(error); process.exit(1); });
