const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

// Drives the exported web build (`npm run build` first) across Teacher and Student roles.
const root = path.join(process.cwd(), 'dist');
const shots = path.join(process.cwd(), '.shots');
const types = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.ttf': 'font/ttf',
  '.png': 'image/png',
};

const server = http
  .createServer((req, res) => {
    let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
    if (!file.startsWith(root)) {
      res.writeHead(403).end();
      return;
    }
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
    res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
    fs.createReadStream(file).pipe(res);
  })
  .listen(8135);

const BASE = 'http://localhost:8135';
const tab = (page, label) => page.getByRole('tab', { name: label, exact: true });
const step = (msg) => console.log(`PASS: ${msg}`);
const seen = (page, text, timeout = 15000) =>
  page.getByText(text, { exact: true }).first().waitFor({ state: 'visible', timeout });

async function shot(page, name) {
  fs.mkdirSync(shots, { recursive: true });
  await page.screenshot({ path: path.join(shots, `homework-${name}.png`) });
}

async function signIn(page, { pill }) {
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 15000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 30000 });
  await page.getByText(pill, { exact: true }).click();
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await tab(page, 'Homework').waitFor({ state: 'visible', timeout: 30000 });
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  try {
    await page.goto(`${BASE}/`);
    await signIn(page, { pill: 'Teacher' });
    await tab(page, 'Homework').click();

    // ---- 1. Tracker ----
    for (const text of [
      'Homework',
      'Quadratic equations worksheet',
      'Trigonometry: Chapter 8 practice set',
      'Linear equations: Exercise 3.2',
      'Overdue',
      '12 submitted',
      '12 pending',
    ]) {
      await seen(page, text);
    }
    const trackerText = await page.locator('body').innerText();
    assert.ok(!trackerText.includes('Class 9-A'), 'teacher must not see Class 9-A homework');
    await shot(page, '1-tracker');
    step('Tracker displays Active/Closed segments, Overdue pill, two-tone counts and teacher-scoped cards');

    // Remind pending on Trigonometry
    await page.getByRole('button', { name: 'Remind pending for Trigonometry: Chapter 8 practice set' }).click();
    await seen(page, 'Reminded 12 pending students');
    step('Remind pending sends notifications to pending students');

    // ---- 2. Assign homework (Shape C) ----
    await page.getByRole('button', { name: 'Assign homework' }).click();
    await seen(page, 'Assign homework');
    await seen(page, 'Send to 12 students');

    await page.getByPlaceholder('e.g. Quadratic equations: Practice set 2').fill('Polynomials: Exercise 2.5');
    await page
      .getByPlaceholder('Questions to solve, chapter pages, or submission notes…')
      .fill('Solve all factor theorem problems cleanly.');

    // Attach a file via filechooser + paste a link
    const [chooser] = await Promise.all([
      page.waitForEvent('filechooser'),
      page.getByRole('button', { name: 'Attach a file' }).click(),
    ]);
    await chooser.setFiles({
      name: 'polynomials-sheet.png',
      mimeType: 'image/png',
      buffer: Buffer.from(
        'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
        'base64',
      ),
    });
    await seen(page, 'polynomials-sheet.png');
    await page.getByPlaceholder('https://drive.google.com/…').fill('https://sunrise.test/poly-2-5');
    await shot(page, '2-assign');

    await page.getByRole('button', { name: 'Send to 12 students' }).click();
    await seen(page, 'Polynomials: Exercise 2.5');
    await seen(page, 'Class 10-A · Due today, 8:00 PM');
    step('Assigning homework creates the card on Tracker with Due today, 8:00 PM and 0% (0 submitted, 12 pending)');

    // ---- 3. Submissions: expand row, thumbnail, Ask again, Approve, grade <= max ----
    await page.getByRole('button', { name: 'View submissions for Quadratic equations worksheet' }).click();
    await seen(page, '12 of 12 submitted');
    await shot(page, '3-submissions');

    // Expand Aarav Sharma -> reveals attachment thumbnail + Approve / Ask again
    await page.getByRole('button', { name: /^Aarav Sharma,/ }).click();
    await seen(page, 'worksheet-roll-14.svg');
    await seen(page, 'Approve');
    await seen(page, 'Ask again');
    await shot(page, '4-expanded-row');

    // Ask again notifies Aarav and drops count to 11 of 12 submitted
    await page.getByRole('button', { name: 'Ask Aarav Sharma again' }).click();
    await seen(page, '11 of 12 submitted');
    await seen(page, 'Asked to resubmit');
    step('Expanding a row reveals thumbnail + Approve/Ask again; Ask again moves student to pending (11 of 12)');

    // Expand Ishita Bose and Approve
    await page.getByRole('button', { name: /^Ishita Bose,/ }).click();
    await page.getByRole('button', { name: 'Approve Ishita Bose' }).click();
    await seen(page, 'Approved');
    step('Approve marks submission returned');

    // Grade validation: > max (25) blocks saving
    const kabirInput = page.getByLabel('Grade for Kabir Singh');
    await kabirInput.fill('30');
    await seen(page, 'Max 25');
    await seen(page, 'Grade must be ≤ 25. Fix highlighted rows to save.');
    await kabirInput.fill('22');
    await page.getByLabel('Grade for Ananya Gupta').fill('24');
    await page.getByRole('button', { name: 'Save 2 grades' }).click();
    await seen(page, '2 grades saved');
    step('Grade > max is rejected inline, and valid grades save cleanly');

    // ---- 4. Grading updates the tracker percentage ----
    await page.getByRole('button', { name: 'Back to homework' }).click();
    await page.getByRole('button', { name: 'View submissions for Polynomials: Exercise 2.5' }).click();
    await seen(page, '0 of 12 submitted');
    await page.getByLabel('Grade for Aarav Sharma').fill('19');
    await page.getByLabel('Grade for Ishita Bose').fill('18');
    await page.getByLabel('Grade for Kabir Singh').fill('20');
    await page.getByRole('button', { name: 'Save 3 grades' }).click();
    await seen(page, '3 of 12 submitted');
    await page.getByRole('button', { name: 'Back to homework' }).click();
    await seen(page, '25%');
    await seen(page, '3 submitted');
    await seen(page, '9 pending');
    await shot(page, '5-tracker-updated');
    step('Grading updates the tracker percentage (0% -> 25%, 3 submitted + 9 pending = 12)');

    // ---- 5. Student sees assigned homework instantly in their Homework list ----
    await page.getByRole('button', { name: 'Sign out' }).click();
    await signIn(page, { pill: 'Student' });
    await tab(page, 'Homework').click();
    await seen(page, 'Polynomials: Exercise 2.5');
    await seen(page, 'Class 10-A · Due today, 8:00 PM');
    await seen(page, 'polynomials-sheet.png');
    await shot(page, '6-student-homework');
    step('Assigned homework appears in the student\'s Homework tab with due time and attachment');

    assert.deepEqual(errors, []);
    step('0 runtime page errors');
  } catch (error) {
    await shot(page, 'failure').catch(() => {});
    console.error(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.closeAllConnections?.();
    server.close();
  }
})();
