import React from 'react';
import { Stack } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { AppStateProvider, useAppState } from '../src/data/AppState';
import { VesteThemeProvider, useTheme } from '../src/theme';
import type { ThemePreference } from '../src/data/types';

function ThemedApp() {
  const { profile, updateProfile } = useAppState();
  return <VesteThemeProvider preference={profile?.theme ?? 'light'} setPreference={(theme: ThemePreference) => { void updateProfile({ theme }); }}><ThemedStack /></VesteThemeProvider>;
}
function ThemedStack() { const { colors } = useTheme(); return <><StatusBar style={colors.dark ? 'light' : 'dark'} /><Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.paper }, animation: 'slide_from_right' }} /></>; }

export default function RootLayout() {
  const [loaded] = useFonts({ ...Ionicons.font });
  if (!loaded) return null;
  return <GestureHandlerRootView style={{ flex: 1 }}><SafeAreaProvider><BottomSheetModalProvider><AppStateProvider><ThemedApp /></AppStateProvider></BottomSheetModalProvider></SafeAreaProvider></GestureHandlerRootView>;
}
