import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { ScreenRegistry } from '../../src/screens/registry';

export default function NumberedScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const number = Number(id);
  return <ScreenRegistry id={Number.isInteger(number) && number >= 1 && number <= 60 ? number : 1} />;
}
