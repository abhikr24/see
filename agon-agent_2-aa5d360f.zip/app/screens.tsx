import React from 'react';
import { View, Pressable } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { useRouter } from 'expo-router';
import { getCopy } from '../src/copy';
import { useAppState } from '../src/data/AppState';
import { useTheme } from '../src/theme';
import { EditorialTitle, ScreenFrame, VesteText, screenId } from '../src/components/ui';

const screens = Array.from({ length: 60 }, (_, index) => index + 1);
export default function ScreenAtlas() {
  const router = useRouter(); const { colors } = useTheme(); const { profile } = useAppState(); const c = getCopy(profile?.language ?? 'en');
  return <ScreenFrame id={60}><EditorialTitle size={36} style={{ marginTop: 22 }}>{c.common.screenIndex}</EditorialTitle><VesteText style={{ color: colors.taupe, fontSize: 12, marginVertical: 10 }}>{c.common.screenIndexHint}</VesteText><FlashList data={screens} numColumns={2} keyExtractor={(id) => String(id)} renderItem={({ item: id }) => <Pressable onPress={() => router.push(`/s/${screenId(id)}`)} style={{ flex: 1, minHeight: 108, margin: 5, padding: 12, borderWidth: 1, borderColor: colors.hairline, borderRadius: 14, backgroundColor: colors.paperRaised }}><VesteText style={{ fontSize: 10, color: colors.bronze, letterSpacing: 1 }}>{screenId(id)}</VesteText><VesteText style={{ fontFamily: 'Georgia', fontSize: 17, lineHeight: 20, marginTop: 8 }} numberOfLines={3}>{c.screens[id][0]}</VesteText></Pressable>} /></ScreenFrame>;
}
