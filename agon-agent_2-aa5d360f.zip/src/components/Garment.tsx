import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Image } from 'expo-image';
import Svg, { Path, Rect, Circle, Line, G } from 'react-native-svg';
import type { Item, WishlistItem } from '../data/types';
import { useTheme } from '../theme';

type Garment = Pick<Item, 'category' | 'subcategory' | 'colours' | 'imageUri'> | Pick<WishlistItem, 'category' | 'subcategory' | 'colours'>;

export function GarmentArt({ item, size = 144, contain = true }: { item: Garment; size?: number; contain?: boolean }) {
  const { colors } = useTheme();
  const imageUri = 'imageUri' in item ? item.imageUri : undefined;
  if (imageUri) return <Image source={{ uri: imageUri }} style={{ width: size, height: size * 1.18, borderRadius: 12 }} contentFit={contain ? 'contain' : 'cover'} transition={180} />;
  const fill = item.colours[0]?.hex ?? '#B7A68C';
  const accent = item.colours[1]?.hex ?? '#E8E0D1';
  const stroke = colors.dark ? '#B8ADA3' : '#51483F';
  const common = { stroke, strokeWidth: 1.15, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const };
  const sub = item.subcategory.toLowerCase();
  let drawing: React.ReactNode;
  if (item.category === 'top' || item.category === 'outerwear') {
    const long = /kurta|sherwani|achkan|coat/.test(sub);
    const jacket = item.category === 'outerwear' || /jacket|blazer|bandhgala/.test(sub);
    drawing = <G {...common}>
      <Path d={long ? 'M46 25 L32 34 L17 79 L31 85 L39 62 L35 137 Q60 145 85 137 L81 62 L89 85 L103 79 L88 34 L74 25 L67 20 L53 20 Z' : 'M45 27 L29 35 L16 76 L31 82 L39 61 L38 116 Q60 122 82 116 L81 61 L89 82 L104 76 L91 35 L75 27 L68 21 L52 21 Z'} fill={fill} />
      <Path d='M51 22 Q60 35 69 22 M60 33 L60 105' fill='none' />
      {jacket && <><Path d='M48 25 L59 48 L48 63 M72 25 L61 48 L72 63' fill={accent} /><Circle cx='64' cy='68' r='1.6' fill={stroke} stroke='none' /><Circle cx='64' cy='82' r='1.6' fill={stroke} stroke='none' /></>}
      {/kurta|sherwani|bandhgala/.test(sub) && <><Path d='M53 20 Q60 29 67 20 L66 35 L54 35 Z' fill={accent} /><Circle cx='61' cy='48' r='1.3' fill={stroke} stroke='none' /><Circle cx='61' cy='59' r='1.3' fill={stroke} stroke='none' /></>}
      <Path d='M41 91 L51 91 M69 91 L79 91' fill='none' opacity={0.55} />
    </G>;
  } else if (item.category === 'bottom') {
    const wide = /wide|palazzo|salwar|drawstring/.test(sub);
    drawing = <G {...common}>
      <Path d={wide ? 'M34 17 L86 17 L91 130 L65 130 L60 58 L55 130 L29 130 Z' : 'M34 17 L86 17 L82 130 L64 130 L60 58 L56 130 L38 130 Z'} fill={fill} />
      <Path d='M34 27 L86 27 M60 28 L60 58 M43 31 Q47 43 54 44 M77 31 Q73 43 66 44' fill='none' />
      <Path d='M40 119 L55 119 M65 119 L80 119' fill='none' opacity={0.5} />
    </G>;
  } else if (item.category === 'footwear') {
    const boot = /boot/.test(sub);
    const heel = /heel|wedge/.test(sub);
    drawing = <G {...common}>
      {boot ? <Path d='M35 25 L65 25 L67 83 Q76 93 96 99 Q105 103 102 113 L32 113 Q25 106 31 93 Z' fill={fill} /> : <Path d={heel ? 'M24 83 Q43 81 51 58 L67 61 Q67 88 91 96 L98 109 L75 109 L69 98 L54 102 L49 116 L40 116 L39 102 L22 98 Z' : 'M28 62 Q40 71 53 60 L65 72 Q72 88 97 96 Q107 101 101 112 L31 112 Q21 107 24 94 Z'} fill={fill} />}
      <Path d='M25 101 Q57 108 102 103 M50 72 L69 83 M46 78 L66 89' fill='none' />
      <Path d='M31 112 L101 112' stroke={accent} strokeWidth={4} />
    </G>;
  } else if (item.category === 'accessory') {
    if (/watch/.test(sub)) drawing = <G {...common}><Rect x='48' y='8' width='24' height='108' rx='9' fill={fill} /><Rect x='41' y='41' width='38' height='45' rx='11' fill={accent} /><Circle cx='60' cy='63' r='16' fill={fill} /><Circle cx='60' cy='63' r='12' fill={colors.paperRaised} /><Line x1='60' y1='63' x2='60' y2='54' /><Line x1='60' y1='63' x2='67' y2='67' /></G>;
    else if (/belt/.test(sub)) drawing = <G {...common}><Path d='M25 50 Q60 30 95 50 L95 73 Q60 53 25 73 Z' fill={fill} /><Rect x='48' y='40' width='27' height='31' rx='3' fill={accent} /><Rect x='54' y='46' width='15' height='19' fill='none' /></G>;
    else if (/glasses/.test(sub)) drawing = <G {...common} fill='none'><Circle cx='40' cy='65' r='20' fill={fill} opacity={0.75} /><Circle cx='84' cy='65' r='20' fill={fill} opacity={0.75} /><Path d='M60 62 Q62 58 64 62 M20 59 L10 50 M104 59 L114 50' /></G>;
    else drawing = <G {...common}><Path d='M37 13 Q61 24 83 13 L76 115 Q59 106 42 116 Z' fill={fill} /><Path d='M46 22 L52 105 M72 22 L67 105' stroke={accent} fill='none' /><Path d='M42 116 L39 124 M49 114 L48 123 M74 114 L77 123' fill='none' /></G>;
  } else {
    drawing = <G {...common}><Path d='M46 17 L75 17 L82 42 L97 125 Q61 139 24 125 L39 42 Z' fill={fill} /><Path d='M45 18 Q60 32 76 18 M39 43 Q60 53 82 43 M46 54 L36 121 M73 54 L85 121' fill='none' stroke={accent} /></G>;
  }
  return <View style={{ width: size, height: size * 1.08, alignItems: 'center', justifyContent: 'center' }}><Svg width={size} height={size * 1.08} viewBox='0 0 120 140'>{drawing}</Svg></View>;
}

export function ColourDots({ colours, size = 12 }: { colours: Array<{ hex: string }>; size?: number }) {
  return <View style={styles.dots}>{colours.map((colour, index) => <View key={`${colour.hex}-${index}`} style={[styles.dot, { width: size, height: size, borderRadius: size / 2, backgroundColor: colour.hex }]} />)}</View>;
}
const styles = StyleSheet.create({ dots: { flexDirection: 'row', gap: 5 }, dot: { borderWidth: StyleSheet.hairlineWidth, borderColor: '#8C8078' } });
