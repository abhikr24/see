import React, { useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, Pressable, TextInput, ScrollView, KeyboardAvoidingView, Platform, type TextInputProps, type ViewStyle, type StyleProp } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { Easing, FadeIn, ReduceMotion, useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { BlurView } from 'expo-blur';
import BottomSheet, { BottomSheetBackdrop, BottomSheetScrollView, type BottomSheetBackdropProps } from '@gorhom/bottom-sheet';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';
import Svg, { Pattern, Rect, Circle } from 'react-native-svg';
import { radii, serif, useTheme } from '../theme';
import { getCopy } from '../copy';
import { useAppState } from '../data/AppState';
import type { Item } from '../data/types';
import { GarmentArt } from './Garment';

export type IconName = React.ComponentProps<typeof Ionicons>['name'];
export const screenId = (id: number) => String(id).padStart(2, '0');
export function goToScreen(router: ReturnType<typeof useRouter>, id: number, replace = false) {
  const route = `/s/${screenId(id)}`;
  if (replace) router.replace(route); else router.push(route);
}

export function useCopy() { const { profile } = useAppState(); return getCopy(profile?.language ?? 'en'); }

function PaperGrain() {
  const { colors } = useTheme();
  return <Svg pointerEvents='none' style={StyleSheet.absoluteFill} width='100%' height='100%'><Pattern id='grain' width='37' height='41' patternUnits='userSpaceOnUse'><Circle cx='4' cy='7' r='0.55' fill={colors.taupe} opacity={0.12} /><Circle cx='28' cy='31' r='0.45' fill={colors.bronze} opacity={0.09} /></Pattern><Rect width='100%' height='100%' fill='url(#grain)' /></Svg>;
}

export function VesteText({ children, style, numberOfLines, accessibilityRole }: { children: React.ReactNode; style?: StyleProp<any>; numberOfLines?: number; accessibilityRole?: 'header' | 'text' }) {
  const { colors } = useTheme();
  return <Text accessibilityRole={accessibilityRole} numberOfLines={numberOfLines} style={[{ color: colors.ink, fontFamily: 'System', fontSize: 15, lineHeight: 22 }, style]}>{children}</Text>;
}

export function EditorialTitle({ children, size = 36, italic = false, style }: { children: React.ReactNode; size?: number; italic?: boolean; style?: StyleProp<any> }) {
  return <VesteText accessibilityRole='header' style={[{ fontFamily: serif, fontSize: size, lineHeight: size * 1.04, letterSpacing: -1.15, fontWeight: '500' }, italic && { fontStyle: 'italic' }, style]}>{children}</VesteText>;
}

export function Eyebrow({ children, icon }: { children: React.ReactNode; icon?: IconName }) {
  const { colors } = useTheme();
  return <View style={styles.eyebrow}>{icon && <Ionicons name={icon} color={colors.bronze} size={14} />}<VesteText style={{ color: colors.taupe, fontSize: 11, lineHeight: 16, letterSpacing: 1.35, textTransform: 'uppercase', fontWeight: '600' }}>{children}</VesteText></View>;
}

export function PrimaryButton({ label, onPress, icon, variant = 'primary', disabled = false, style, compact = false }: { label: string; onPress: () => void; icon?: IconName; variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger'; disabled?: boolean; style?: StyleProp<ViewStyle>; compact?: boolean }) {
  const { colors } = useTheme();
  const reduced = useReducedMotion();
  const scale = useSharedValue(1);
  const animated = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const palette = {
    primary: { backgroundColor: colors.ink, borderColor: colors.ink, color: colors.inverse },
    secondary: { backgroundColor: colors.bronze, borderColor: colors.bronze, color: '#FFFFFF' },
    outline: { backgroundColor: 'transparent', borderColor: colors.hairline, color: colors.ink },
    ghost: { backgroundColor: 'transparent', borderColor: 'transparent', color: colors.bronze },
    danger: { backgroundColor: 'transparent', borderColor: colors.danger, color: colors.danger },
  }[variant];
  const press = () => { if (disabled) return; if (variant === 'primary' || variant === 'secondary') { if (Platform.OS !== 'web') void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); } onPress(); };
  return <Animated.View style={[animated, style]}><Pressable accessibilityRole='button' accessibilityLabel={label} disabled={disabled} onPress={press} onPressIn={() => { scale.value = reduced ? 1 : withTiming(0.975, { duration: 120 }); }} onPressOut={() => { scale.value = reduced ? 1 : withTiming(1, { duration: 240, easing: Easing.bezier(0.22, 1, 0.36, 1) }); }} style={({ pressed }) => [styles.button, compact && styles.buttonCompact, { backgroundColor: palette.backgroundColor, borderColor: palette.borderColor, opacity: disabled ? 0.42 : pressed ? 0.88 : 1 }]}>
    {icon && <Ionicons name={icon} size={18} color={palette.color} />}<Text style={[styles.buttonLabel, compact && { fontSize: 13 }, { color: palette.color }]}>{label}</Text>
  </Pressable></Animated.View>;
}

export function IconButton({ icon, onPress, label, active = false, size = 20 }: { icon: IconName; onPress: () => void; label: string; active?: boolean; size?: number }) {
  const { colors } = useTheme();
  return <Pressable accessibilityRole='button' accessibilityLabel={label} onPress={onPress} hitSlop={6} style={({ pressed }) => [styles.iconButton, { borderColor: colors.hairline, backgroundColor: active ? colors.bronzeSoft : 'transparent', opacity: pressed ? 0.65 : 1 }]}><Ionicons name={icon} size={size} color={active ? colors.bronze : colors.ink} /></Pressable>;
}

export function ChoiceChip({ label, selected = false, onPress, icon, tone = 'default' }: { label: string; selected?: boolean; onPress: () => void; icon?: IconName; tone?: 'default' | 'olive' }) {
  const { colors } = useTheme();
  return <Pressable accessibilityRole='button' accessibilityState={{ selected }} onPress={onPress} style={({ pressed }) => [styles.chip, { borderColor: selected ? colors.bronze : colors.hairline, backgroundColor: selected ? (tone === 'olive' ? colors.olive : colors.bronzeSoft) : 'transparent', opacity: pressed ? 0.75 : 1 }]}>
    {icon && <Ionicons name={icon} size={15} color={selected && tone === 'olive' ? '#FFF' : selected ? colors.bronze : colors.taupe} />}<VesteText style={{ fontSize: 13, lineHeight: 18, color: selected && tone === 'olive' ? '#FFF' : selected ? colors.ink : colors.inkSoft }}>{label}</VesteText>
  </Pressable>;
}

export function Field({ label, value, onChangeText, suffix, ...props }: { label: string; value: string; onChangeText: (value: string) => void; suffix?: string } & Omit<TextInputProps, 'value' | 'onChangeText'>) {
  const { colors } = useTheme();
  return <View style={styles.field}><VesteText style={{ fontSize: 12, color: colors.taupe, marginBottom: 6 }}>{label}</VesteText><View style={[styles.inputWrap, { borderColor: colors.hairline, backgroundColor: colors.paperRaised }]}><TextInput placeholderTextColor={colors.taupe} selectionColor={colors.bronze} value={value} onChangeText={onChangeText} style={[styles.input, { color: colors.ink }]} {...props} />{suffix && <VesteText style={{ color: colors.taupe, fontSize: 13, paddingRight: 12 }}>{suffix}</VesteText>}</View></View>;
}

export function Rule({ style }: { style?: StyleProp<ViewStyle> }) { const { colors } = useTheme(); return <View style={[{ height: StyleSheet.hairlineWidth * 2, backgroundColor: colors.hairline }, style]} />; }

export function RangeControl({ value, onChange, left, right }: { value: number; onChange: (value: number) => void; left: string; right: string }) {
  const { colors } = useTheme();
  return <View style={{ paddingVertical: 10 }}><View style={styles.rangeLabels}><VesteText style={{ fontSize: 13 }}>{left}</VesteText><VesteText style={{ fontSize: 13, color: colors.taupe }}>{right}</VesteText></View><Pressable accessibilityRole='adjustable' accessibilityValue={{ min: 0, max: 100, now: value }} onPress={(event) => onChange(Math.round(event.nativeEvent.locationX / 280 * 100))} style={styles.rangeTouch}><View style={[styles.rangeTrack, { backgroundColor: colors.hairline }]}><View style={{ width: `${Math.max(0, Math.min(100, value))}%`, height: 2, backgroundColor: colors.bronze }} /><View style={[styles.rangeKnob, { left: `${Math.max(0, Math.min(100, value))}%`, backgroundColor: colors.bronze }]} /></View></Pressable></View>;
}

export function ScoreBar({ label, value }: { label: string; value: number }) {
  const { colors } = useTheme();
  return <View style={styles.scoreRow}><VesteText style={{ width: 96, fontSize: 12, color: colors.inkSoft }}>{label}</VesteText><View style={[styles.scoreTrack, { backgroundColor: colors.paperSubtle }]}><View style={{ width: `${Math.min(100, Math.max(0, value))}%`, height: 3, backgroundColor: colors.bronze, borderRadius: 3 }} /></View><VesteText style={{ width: 32, textAlign: 'right', fontSize: 11, color: colors.taupe }}>{Math.round(value)}</VesteText></View>;
}

export function Skeleton({ rows = 3 }: { rows?: number }) {
  const { colors } = useTheme();
  return <View accessibilityLabel='Loading' style={{ gap: 12, paddingVertical: 24 }}>{Array.from({ length: rows }, (_, index) => <View key={index} style={{ height: index === 0 ? 180 : 20, borderRadius: 12, backgroundColor: colors.paperSubtle, width: index === 0 ? '100%' : `${90 - index * 12}%` }} />)}</View>;
}

export function Notice({ children, icon = 'checkmark-circle-outline', tone = 'olive' }: { children: React.ReactNode; icon?: IconName; tone?: 'olive' | 'danger' | 'bronze' }) {
  const { colors } = useTheme();
  const color = colors[tone];
  return <View style={[styles.notice, { borderColor: colors.hairline, backgroundColor: colors.paperRaised }]}><Ionicons name={icon} size={18} color={color} /><VesteText style={{ flex: 1, fontSize: 12, lineHeight: 18, color: colors.inkSoft }}>{children}</VesteText></View>;
}

export function BottomNav({ active }: { active: 'today' | 'closet' | 'plan' | 'profile' }) {
  const { colors } = useTheme(); const c = useCopy(); const router = useRouter(); const insets = useSafeAreaInsets();
  const entries = [{ key: 'today', id: 30, icon: 'sunny-outline' }, { key: 'closet', id: 38, icon: 'shirt-outline' }, { key: 'plan', id: 50, icon: 'calendar-outline' }, { key: 'profile', id: 56, icon: 'person-outline' }] as const;
  return <View style={[styles.bottomNav, { paddingBottom: Math.max(insets.bottom, 8), backgroundColor: colors.paper, borderColor: colors.hairline }]}>{entries.map((entry) => <Pressable key={entry.key} accessibilityRole='tab' accessibilityState={{ selected: active === entry.key }} onPress={() => goToScreen(router, entry.id)} style={styles.navItem}><Ionicons name={entry.icon} size={20} color={active === entry.key ? colors.bronze : colors.taupe} /><VesteText style={{ fontSize: 10, lineHeight: 14, color: active === entry.key ? colors.bronze : colors.taupe }}>{c.common[entry.key]}</VesteText></Pressable>)}</View>;
}

export function ScreenFrame({ id, children, nav, scroll = false, noHeader = false, contentStyle }: { id: number; children: React.ReactNode; nav?: 'today' | 'closet' | 'plan' | 'profile'; scroll?: boolean; noHeader?: boolean; contentStyle?: StyleProp<ViewStyle> }) {
  const { colors } = useTheme(); const c = useCopy(); const router = useRouter();
  const body = scroll ? <ScrollView keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false} contentContainerStyle={[styles.scrollContent, contentStyle]}>{children}</ScrollView> : <View style={[styles.body, contentStyle]}>{children}</View>;
  return <SafeAreaView edges={['top', 'bottom']} style={[styles.safe, { backgroundColor: colors.paper }]}><PaperGrain /><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.safe}>
    {!noHeader && <View style={[styles.topBar, { borderColor: colors.hairline }]}><IconButton icon='arrow-back-outline' label={c.common.back} onPress={() => router.canGoBack() ? router.back() : goToScreen(router, Math.max(1, id - 1))} /><Pressable accessibilityLabel={c.common.screenIndex} onPress={() => router.push('/screens')} style={styles.indexButton}><VesteText style={{ fontFamily: serif, fontSize: 15, color: colors.taupe }}>{screenId(id)} <Text style={{ fontSize: 10 }}>/ 60</Text></VesteText></Pressable><IconButton icon='grid-outline' label={c.common.screenIndex} onPress={() => router.push('/screens')} /></View>}
    {body}
  </KeyboardAvoidingView>{nav && <BottomNav active={nav} />}</SafeAreaView>;
}

export function IntakeFrame({ id, children, onContinue, continueLabel }: { id: number; children: React.ReactNode; onContinue?: () => void | Promise<void>; continueLabel?: string }) {
  const c = useCopy(); const router = useRouter(); const { colors } = useTheme(); const [busy, setBusy] = useState(false);
  const advance = async (run: boolean) => { if (!onContinue || !run) goToScreen(router, id + 1); else { setBusy(true); try { await onContinue(); goToScreen(router, id + 1); } finally { setBusy(false); } } };
  return <ScreenFrame id={id} scroll contentStyle={{ paddingBottom: 24 }}>
    <View style={[styles.progress, { backgroundColor: colors.hairline }]}><View style={{ width: `${((id - 8) / 21) * 100}%`, height: 2, backgroundColor: colors.bronze }} /></View>
    <Animated.View entering={FadeIn.duration(240).reduceMotion(ReduceMotion.System)} style={styles.intakeContent}><Eyebrow>{`${screenId(id)} \u00b7 ${c.common.profile}`}</Eyebrow><EditorialTitle style={{ marginTop: 12 }}>{c.screens[id][0]}</EditorialTitle><VesteText style={{ color: colors.taupe, fontSize: 13, lineHeight: 19, marginTop: 10 }}>{c.screens[id][1]}</VesteText><View style={{ marginTop: 28, flex: 1 }}>{children}</View>
      <View style={styles.why}><Ionicons name='information-circle-outline' size={16} color={colors.bronze} /><VesteText style={{ flex: 1, fontSize: 11, lineHeight: 17, color: colors.taupe }}><Text style={{ color: colors.bronze, fontWeight: '600' }}>{c.common.whyWeAsk}: </Text>{c.screens[id][1]}</VesteText></View>
      <PrimaryButton label={continueLabel ?? c.common.continue} disabled={busy} onPress={() => { void advance(true); }} style={{ marginTop: 20 }} /><Pressable onPress={() => { void advance(false); }} style={styles.skip}><VesteText style={{ fontSize: 12, color: colors.taupe, textDecorationLine: 'underline' }}>{c.common.skip}</VesteText></Pressable>
    </Animated.View></ScreenFrame>;
}

export function LookCanvas({ items, compact = false }: { items: Item[]; compact?: boolean }) {
  const { colors } = useTheme();
  const anchors = items.filter((item) => item.category === 'top' || item.category === 'onepiece');
  const bottoms = items.filter((item) => item.category === 'bottom');
  const footwear = items.filter((item) => item.category === 'footwear');
  const other = items.filter((item) => !anchors.includes(item) && !bottoms.includes(item) && !footwear.includes(item));
  return <View style={[styles.lookCanvas, compact && { height: 220 }, { backgroundColor: colors.paperSubtle, borderColor: colors.hairline }]}>
    <View style={[styles.paperCircle, { borderColor: colors.hairline }]} />
    {anchors[0] && <View style={{ position: 'absolute', left: '7%', top: compact ? 0 : 12 }}><GarmentArt item={anchors[0]} size={compact ? 128 : 176} /></View>}
    {bottoms[0] && <View style={{ position: 'absolute', right: '5%', top: compact ? 16 : 28 }}><GarmentArt item={bottoms[0]} size={compact ? 116 : 152} /></View>}
    {footwear[0] && <View style={{ position: 'absolute', right: '14%', bottom: compact ? -12 : -4 }}><GarmentArt item={footwear[0]} size={compact ? 78 : 96} /></View>}
    {other[0] && <View style={{ position: 'absolute', left: '12%', bottom: compact ? -20 : -10 }}><GarmentArt item={other[0]} size={compact ? 64 : 78} /></View>}
    {!items.length && <Ionicons name='shirt-outline' size={52} color={colors.taupe} />}
  </View>;
}

export function VesteSheet({ children, onClose, snapPoints = ['72%'], title }: { children: React.ReactNode; onClose: () => void; snapPoints?: string[]; title?: string }) {
  const { colors } = useTheme(); const ref = useRef<BottomSheet>(null); const insets = useSafeAreaInsets();
  const backdrop = useMemo(() => function SheetBackdrop(props: BottomSheetBackdropProps) { return <BottomSheetBackdrop {...props} appearsOnIndex={0} disappearsOnIndex={-1} pressBehavior='close' opacity={0.45}><BlurView intensity={28} tint={colors.dark ? 'dark' : 'light'} style={StyleSheet.absoluteFill} /></BottomSheetBackdrop>; }, [colors.dark]);
  return <BottomSheet ref={ref} index={0} snapPoints={snapPoints} onClose={onClose} enablePanDownToClose backdropComponent={backdrop} handleIndicatorStyle={{ backgroundColor: colors.taupe, width: 36 }} backgroundStyle={{ backgroundColor: colors.paper, borderRadius: 20 }} style={{ borderTopLeftRadius: 20, borderTopRightRadius: 20 }}>
    <BottomSheetScrollView contentContainerStyle={{ padding: 24, paddingBottom: Math.max(32, insets.bottom + 16) }} keyboardShouldPersistTaps='handled'>{title && <EditorialTitle size={30} style={{ marginBottom: 22 }}>{title}</EditorialTitle>}{children}</BottomSheetScrollView>
  </BottomSheet>;
}

export function Segmented({ options, value, onChange }: { options: Array<{ value: string; label: string }>; value: string; onChange: (value: string) => void }) {
  const { colors } = useTheme();
  return <View style={[styles.segmented, { borderColor: colors.hairline }]}>{options.map((option) => <Pressable key={option.value} onPress={() => onChange(option.value)} style={[styles.segment, { backgroundColor: value === option.value ? colors.ink : 'transparent' }]}><VesteText style={{ fontSize: 12, color: value === option.value ? colors.inverse : colors.taupe }}>{option.label}</VesteText></Pressable>)}</View>;
}

export const styles = StyleSheet.create({
  safe: { flex: 1 }, body: { flex: 1, paddingHorizontal: 24 }, scrollContent: { paddingHorizontal: 24, flexGrow: 1 }, topBar: { height: 56, marginHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: StyleSheet.hairlineWidth }, indexButton: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 16 }, iconButton: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', borderWidth: StyleSheet.hairlineWidth },
  button: { minHeight: 52, borderRadius: radii.small, borderWidth: 1, flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20 }, buttonCompact: { minHeight: 44, paddingHorizontal: 14 }, buttonLabel: { fontSize: 14, fontWeight: '600', letterSpacing: 0.1 }, eyebrow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  chip: { minHeight: 44, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 }, field: { marginBottom: 18 }, inputWrap: { minHeight: 50, borderWidth: 1, borderRadius: 12, flexDirection: 'row', alignItems: 'center' }, input: { flex: 1, minHeight: 50, paddingHorizontal: 14, fontSize: 15, outlineStyle: 'none' } as any,
  rangeLabels: { flexDirection: 'row', justifyContent: 'space-between' }, rangeTouch: { height: 44, justifyContent: 'center' }, rangeTrack: { height: 2, position: 'relative', justifyContent: 'center' }, rangeKnob: { width: 14, height: 14, borderRadius: 7, position: 'absolute', marginLeft: -7 }, scoreRow: { flexDirection: 'row', alignItems: 'center', minHeight: 34, gap: 8 }, scoreTrack: { height: 3, flex: 1, borderRadius: 3 },
  notice: { borderWidth: 1, borderRadius: 12, padding: 12, flexDirection: 'row', gap: 10, alignItems: 'center' }, bottomNav: { minHeight: 62, borderTopWidth: StyleSheet.hairlineWidth, flexDirection: 'row', paddingHorizontal: 16, paddingTop: 8 }, navItem: { flex: 1, minHeight: 44, alignItems: 'center', justifyContent: 'center', gap: 2 },
  progress: { height: 2, marginTop: 18 }, intakeContent: { paddingTop: 24, flex: 1 }, why: { flexDirection: 'row', gap: 8, alignItems: 'flex-start', marginTop: 28 }, skip: { minHeight: 44, alignItems: 'center', justifyContent: 'center', marginTop: 6 },
  lookCanvas: { height: 330, borderRadius: 20, borderWidth: StyleSheet.hairlineWidth, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }, paperCircle: { position: 'absolute', width: 230, height: 230, borderRadius: 115, borderWidth: StyleSheet.hairlineWidth, opacity: 0.5 },
  segmented: { flexDirection: 'row', borderWidth: 1, padding: 3, borderRadius: 12, minHeight: 46 }, segment: { flex: 1, minHeight: 38, borderRadius: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 },
});
