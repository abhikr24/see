import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';
import { composeLookSet } from '../engine/stylist';
import { weatherProvider } from '../services/weather';
import { getRepository } from './repository';
import type { AuthCredentials, Feedback, Item, Occasion, Outfit, Profile, Repository, Signal, ThemePreference, WearLog, Weather, WishlistItem } from './types';

const today = () => new Date().toISOString().slice(0, 10);
const id = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

interface AppState {
  repository: Repository;
  profile: Profile | null;
  items: Item[];
  outfits: Outfit[];
  logs: WearLog[];
  signals: Signal[];
  wishlist: WishlistItem[];
  weather: Weather | null;
  looks: [Outfit, Outfit, Outfit] | null;
  look: Outfit | null;
  lookIndex: number;
  occasion: Occasion;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  updateProfile: (patch: Partial<Profile>) => Promise<void>;
  saveItem: (item: Item) => Promise<void>;
  deleteItem: (itemId: string) => Promise<void>;
  setOccasion: (occasion: Occasion) => void;
  selectLook: (index: number) => void;
  remix: () => void;
  signalLook: (kind: Signal['kind'], note?: string) => Promise<void>;
  wearLook: () => Promise<void>;
  saveLook: () => Promise<void>;
  submitFeedback: (fit: Feedback['fit'], tags: string[]) => Promise<void>;
  signIn: (credentials: AuthCredentials) => Promise<void>;
  signUp: (credentials: AuthCredentials) => Promise<'verified' | 'verificationRequired'>;
  verifyEmail: (email: string, token: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  exportData: () => Promise<string>;
  deleteAccount: () => Promise<void>;
}
const StateContext = createContext<AppState | null>(null);

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  const repository = useRef(getRepository()).current;
  const [profile, setProfile] = useState<Profile | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [outfits, setOutfits] = useState<Outfit[]>([]);
  const [logs, setLogs] = useState<WearLog[]>([]);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [weather, setWeather] = useState<Weather | null>(null);
  const [occasion, setOccasion] = useState<Occasion>('office');
  const [lookIndex, setLookIndex] = useState(0);
  const [remixSalt, setRemixSalt] = useState('daily');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const nextProfile = await repository.getProfile();
      const [nextItems, nextOutfits, nextLogs, nextSignals, nextWishlist, nextWeather] = await Promise.all([repository.listItems(), repository.listOutfits(), repository.listWearLogs(), repository.listSignals(), repository.listWishlist(), weatherProvider.getWeather(nextProfile.city)]);
      setProfile(nextProfile); setItems(nextItems); setOutfits(nextOutfits); setLogs(nextLogs); setSignals(nextSignals); setWishlist(nextWishlist); setWeather(nextWeather);
    } catch (reason) {
      const message = reason instanceof Error ? reason.message : 'LOAD_FAILED';
      if (message === 'AUTH_REQUIRED') setProfile(null); else setError(message);
    } finally { setLoading(false); }
  }, [repository]);
  useEffect(() => { void refresh(); }, [refresh]);

  const looks = useMemo(() => {
    if (!profile || !weather) return null;
    return composeLookSet(items, profile, logs, signals, { date: today(), occasion, weather, salt: remixSalt });
  }, [profile, weather, items, logs, signals, occasion, remixSalt]);
  const look = looks?.[lookIndex] ?? null;

  const updateProfile = useCallback(async (patch: Partial<Profile>) => {
    if (!profile) return;
    const next = { ...profile, ...patch };
    await repository.saveProfile(next); setProfile(next);
  }, [profile, repository]);
  const saveItem = useCallback(async (item: Item) => { await repository.saveItem(item); setItems(await repository.listItems()); }, [repository]);
  const deleteItem = useCallback(async (itemId: string) => { await repository.deleteItem(itemId); setItems((current) => current.filter((item) => item.id !== itemId)); }, [repository]);
  const selectLook = useCallback((index: number) => { setLookIndex(Math.max(0, Math.min(2, index))); }, []);
  const remix = useCallback(() => { setRemixSalt((value) => `${value}-r`); setLookIndex(0); }, []);
  const signalLook = useCallback(async (kind: Signal['kind'], note?: string) => {
    if (!profile || !look?.anchorId) return;
    const signal: Signal = { id: id('signal'), userId: profile.id, itemId: look.anchorId, kind, note, createdAt: new Date().toISOString() };
    await repository.addSignal(signal); setSignals((current) => [...current, signal]);
    if (kind === 'dismiss') { setRemixSalt((value) => `${value}-d`); setLookIndex(0); }
  }, [profile, look, repository]);
  const saveLook = useCallback(async () => { if (look) { const saved = { ...look, saved: true }; await repository.saveOutfit(saved); setOutfits((current) => [...current.filter((entry) => entry.id !== saved.id), saved]); } }, [look, repository]);
  const wearLook = useCallback(async () => {
    if (!profile || !look || !look.itemIds.length) return;
    const worn = { ...look, worn: true };
    await repository.saveOutfit(worn);
    for (const itemId of look.itemIds) await repository.logWear({ id: id('wear'), userId: profile.id, itemId, outfitId: look.id, wornAt: today(), occasion: look.occasion });
    if (Platform.OS !== 'web') await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await refresh();
  }, [profile, look, repository, refresh]);
  const submitFeedback = useCallback(async (fit: Feedback['fit'], tags: string[]) => { if (profile && look) await repository.addFeedback({ id: id('feedback'), userId: profile.id, outfitId: look.id, fit, tags, createdAt: new Date().toISOString() }); }, [profile, look, repository]);
  const signIn = useCallback(async (credentials: AuthCredentials) => { await repository.signIn(credentials); await refresh(); }, [repository, refresh]);
  const signUp = useCallback((credentials: AuthCredentials) => repository.signUp(credentials), [repository]);
  const verifyEmail = useCallback(async (email: string, token: string) => { await repository.verifyEmail(email, token); await refresh(); }, [repository, refresh]);
  const resetPassword = useCallback((email: string) => repository.resetPassword(email), [repository]);
  const signOut = useCallback(async () => { await repository.signOut(); setProfile(null); }, [repository]);
  const exportData = useCallback(() => repository.exportData(), [repository]);
  const deleteAccount = useCallback(async () => { await repository.deleteAccount(); setProfile(null); setItems([]); }, [repository]);

  const value: AppState = { repository, profile, items, outfits, logs, signals, wishlist, weather, looks, look, lookIndex, occasion, loading, error, refresh, updateProfile, saveItem, deleteItem, setOccasion, selectLook, remix, signalLook, wearLook, saveLook, submitFeedback, signIn, signUp, verifyEmail, resetPassword, signOut, exportData, deleteAccount };
  return <StateContext.Provider value={value}>{children}</StateContext.Provider>;
}

export function useAppState() {
  const value = useContext(StateContext);
  if (!value) throw new Error('APP_STATE_UNAVAILABLE');
  return value;
}

export const useThemePreference = (): [ThemePreference, (theme: ThemePreference) => void] => {
  const { profile, updateProfile } = useAppState();
  return [profile?.theme ?? 'light', (theme) => { void updateProfile({ theme }); }];
};
