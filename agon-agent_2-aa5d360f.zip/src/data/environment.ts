export interface AppEnvironment {
  demo: boolean;
  supabaseUrl?: string;
  supabaseAnonKey?: string;
  visionServiceUrl?: string;
  weatherProviderUrl?: string;
  weatherApiKey?: string;
}

const value = (key: string) => {
  const candidate = process.env[key]?.trim();
  return candidate ? candidate : undefined;
};

export const environment: AppEnvironment = {
  demo: value('EXPO_PUBLIC_DEMO') === '1',
  supabaseUrl: value('EXPO_PUBLIC_SUPABASE_URL'),
  supabaseAnonKey: value('EXPO_PUBLIC_SUPABASE_ANON_KEY'),
  visionServiceUrl: value('VISION_SERVICE_URL') ?? value('EXPO_PUBLIC_VISION_SERVICE_URL'),
  weatherProviderUrl: value('EXPO_PUBLIC_WEATHER_PROVIDER_URL'),
  weatherApiKey: value('EXPO_PUBLIC_WEATHER_API_KEY'),
};

export const hasSupabaseEnvironment = Boolean(environment.supabaseUrl && environment.supabaseAnonKey);
export const dataMode = environment.demo || !hasSupabaseEnvironment ? 'demo' : 'supabase';
