import { Platform } from 'react-native';
import * as SQLite from 'expo-sqlite';
import type { DataMode, Repository, Item, Outfit } from './types';

class ReadCache {
  private database: SQLite.SQLiteDatabase | undefined;
  private memory = new Map<string, string>();

  private async db() {
    if (Platform.OS === 'web') return undefined;
    if (!this.database) {
      this.database = await SQLite.openDatabaseAsync('veste-read-cache.db');
      await this.database.execAsync('CREATE TABLE IF NOT EXISTS read_cache (cache_key TEXT PRIMARY KEY NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL);');
    }
    return this.database;
  }

  async set(key: string, payload: unknown) {
    const serialised = JSON.stringify(payload);
    this.memory.set(key, serialised);
    const database = await this.db();
    if (database) await database.runAsync('INSERT OR REPLACE INTO read_cache (cache_key, payload, updated_at) VALUES (?, ?, ?);', key, serialised, new Date().toISOString());
  }

  async get<T>(key: string): Promise<T | undefined> {
    const database = await this.db();
    if (database) {
      const row = await database.getFirstAsync<{ payload: string }>('SELECT payload FROM read_cache WHERE cache_key = ?;', key);
      return row ? JSON.parse(row.payload) as T : undefined;
    }
    const cached = this.memory.get(key);
    return cached ? JSON.parse(cached) as T : undefined;
  }
}

export class OfflineRepository implements Repository {
  private cache = new ReadCache();
  private offline = false;
  constructor(private inner: Repository, private userKey: () => string) {}
  get mode(): DataMode { return this.offline ? 'offline' : this.inner.mode; }
  private key(name: string) { return `${this.userKey()}:${name}`; }
  getProfile() { return this.inner.getProfile(); }
  saveProfile(profile: Parameters<Repository['saveProfile']>[0]) { return this.inner.saveProfile(profile); }
  async listItems(): Promise<Item[]> {
    try {
      const result = await this.inner.listItems();
      await this.cache.set(this.key('closet'), result);
      this.offline = false;
      return result;
    } catch (error) {
      const cached = await this.cache.get<Item[]>(this.key('closet'));
      if (!cached) throw error;
      this.offline = true;
      return cached;
    }
  }
  getItem(id: string) { return this.inner.getItem(id); }
  saveItem(item: Item) { return this.inner.saveItem(item); }
  deleteItem(id: string) { return this.inner.deleteItem(id); }
  async listOutfits(): Promise<Outfit[]> {
    try {
      const result = await this.inner.listOutfits();
      await this.cache.set(this.key('today'), result.filter((outfit) => outfit.date === new Date().toISOString().slice(0, 10)));
      this.offline = false;
      return result;
    } catch (error) {
      const cached = await this.cache.get<Outfit[]>(this.key('today'));
      if (!cached) throw error;
      this.offline = true;
      return cached;
    }
  }
  saveOutfit(outfit: Outfit) { return this.inner.saveOutfit(outfit); }
  listWearLogs() { return this.inner.listWearLogs(); }
  logWear(log: Parameters<Repository['logWear']>[0]) { return this.inner.logWear(log); }
  addSignal(signal: Parameters<Repository['addSignal']>[0]) { return this.inner.addSignal(signal); }
  listSignals() { return this.inner.listSignals(); }
  addFeedback(feedback: Parameters<Repository['addFeedback']>[0]) { return this.inner.addFeedback(feedback); }
  listFeedback() { return this.inner.listFeedback(); }
  listWishlist() { return this.inner.listWishlist(); }
  signIn(credentials: Parameters<Repository['signIn']>[0]) { return this.inner.signIn(credentials); }
  signUp(credentials: Parameters<Repository['signUp']>[0]) { return this.inner.signUp(credentials); }
  verifyEmail(email: string, token: string) { return this.inner.verifyEmail(email, token); }
  resetPassword(email: string) { return this.inner.resetPassword(email); }
  signOut() { return this.inner.signOut(); }
  exportData() { return this.inner.exportData(); }
  deleteAccount() { return this.inner.deleteAccount(); }
}
