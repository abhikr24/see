import { DemoRepository } from '../demo/repository';
import { environment, hasSupabaseEnvironment } from './environment';
import { OfflineRepository } from './offline';
import { SupabaseRepository } from './supabaseRepository';
import type { Repository } from './types';

let instance: Repository | undefined;

export function getRepository(): Repository {
  if (instance) return instance;
  if (environment.demo || !hasSupabaseEnvironment) {
    instance = new DemoRepository();
  } else {
    const remote = new SupabaseRepository(environment.supabaseUrl as string, environment.supabaseAnonKey as string);
    let userKey = 'signed-out';
    instance = new OfflineRepository(remote, () => userKey);
    const originalSignIn = instance.signIn.bind(instance);
    instance.signIn = async (credentials) => {
      const profile = await originalSignIn(credentials);
      userKey = profile.id;
      return profile;
    };
  }
  return instance;
}

export type { Repository } from './types';
