import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { z } from 'zod';
import type { AuthCredentials, Feedback, Item, Outfit, Profile, Repository, Signal, WearLog, WishlistItem } from './types';

type Row = Record<string, unknown>;
const text = (value: unknown, fallback = '') => typeof value === 'string' ? value : fallback;
const number = (value: unknown, fallback = 0) => typeof value === 'number' ? value : fallback;
const bool = (value: unknown) => value === true;
const list = <T,>(value: unknown, fallback: T): T => value as T ?? fallback;
const authStorage = Platform.OS === 'web' ? AsyncStorage : {
  getItem: (key: string) => SecureStore.getItemAsync(key),
  setItem: (key: string, value: string) => SecureStore.setItemAsync(key, value),
  removeItem: (key: string) => SecureStore.deleteItemAsync(key),
};
const itemSchema = z.object({ id: z.string(), user_id: z.string(), name: z.string(), category: z.string(), subcategory: z.string(), colours: z.array(z.object({ name: z.string(), hex: z.string(), undertone: z.string() })).length(3) }).passthrough();

export class SupabaseRepository implements Repository {
  readonly mode = 'supabase' as const;
  private client: SupabaseClient;
  constructor(url: string, anonKey: string) {
    this.client = createClient(url, anonKey, { auth: { storage: authStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: true } });
  }
  private async userId() {
    const { data, error } = await this.client.auth.getUser();
    if (error || !data.user) throw new Error('AUTH_REQUIRED');
    return data.user.id;
  }
  private async rows(table: string, order = 'created_at'): Promise<Row[]> {
    await this.userId();
    const { data, error } = await this.client.from(table).select('*').order(order, { ascending: false });
    if (error) throw error;
    return (data ?? []) as Row[];
  }
  private profileFromRow(row: Row): Profile {
    return {
      id: text(row.id), name: text(row.name), email: text(row.email), city: text(row.city), climate: text(row.climate), pronouns: text(row.pronouns), ageRange: text(row.age_range), photoUri: text(row.photo_uri) || undefined, moodboardUris: list(row.moodboard_uris, []),
      measurements: list(row.measurements, {}), bodyShape: list(row.body_shape, 'rectangle'), undertone: list(row.undertone, 'neutral'), colourSeason: list(row.colour_season, 'warmAutumn'), faceShape: text(row.face_shape), hair: text(row.hair), grooming: text(row.grooming), styleArchetype: text(row.style_archetype), tasteVector: list(row.taste_vector, []), lovedColours: list(row.loved_colours, []), avoidedColours: list(row.avoided_colours, []),
      patternLevel: number(row.pattern_level), textureLevel: number(row.texture_level), shineLevel: number(row.shine_level), brands: list(row.brands, []), budgets: list(row.budgets, { top: [0, 0], bottom: [0, 0], footwear: [0, 0], outerwear: [0, 0], accessory: [0, 0], onepiece: [0, 0] }), constraints: list(row.constraints, []), sensoryDislikes: list(row.sensory_dislikes, []), weeklyRhythm: list(row.weekly_rhythm, []), goals: list(row.goals, []), noRepeatDays: number(row.no_repeat_days, 14), language: list(row.language, 'en'), theme: list(row.theme, 'system'), notifications: bool(row.notifications), onboardingComplete: bool(row.onboarding_complete),
    };
  }
  async getProfile() { const id = await this.userId(); const { data, error } = await this.client.from('profiles').select('*').eq('id', id).single(); if (error) throw error; return this.profileFromRow(data as Row); }
  async saveProfile(profile: Profile) {
    await this.userId();
    const { error } = await this.client.from('profiles').upsert({ id: profile.id, name: profile.name, email: profile.email, city: profile.city, climate: profile.climate, pronouns: profile.pronouns, age_range: profile.ageRange, photo_uri: profile.photoUri ?? null, moodboard_uris: profile.moodboardUris, measurements: profile.measurements, body_shape: profile.bodyShape, undertone: profile.undertone, colour_season: profile.colourSeason, face_shape: profile.faceShape, hair: profile.hair, grooming: profile.grooming, style_archetype: profile.styleArchetype, taste_vector: profile.tasteVector, loved_colours: profile.lovedColours, avoided_colours: profile.avoidedColours, pattern_level: profile.patternLevel, texture_level: profile.textureLevel, shine_level: profile.shineLevel, brands: profile.brands, budgets: profile.budgets, constraints: profile.constraints, sensory_dislikes: profile.sensoryDislikes, weekly_rhythm: profile.weeklyRhythm, goals: profile.goals, no_repeat_days: profile.noRepeatDays, language: profile.language, theme: profile.theme, notifications: profile.notifications, onboarding_complete: profile.onboardingComplete, updated_at: new Date().toISOString() });
    if (error) throw error;
  }
  private itemFromRow(row: Row): Item {
    const parsed = itemSchema.parse(row);
    return {
      id: parsed.id, userId: parsed.user_id, name: parsed.name, category: parsed.category as Item['category'], subcategory: parsed.subcategory, colours: parsed.colours as Item['colours'], pattern: text(row.pattern), texture: text(row.texture), material: text(row.material), care: text(row.care), warmth: number(row.warmth), formality: number(row.formality), seasons: list(row.seasons, []), occasions: list(row.occasions, []), fit: text(row.fit), silhouette: text(row.silhouette), neckline: text(row.neckline), sleeve: text(row.sleeve), rise: text(row.rise), hem: text(row.hem), brand: text(row.brand), size: text(row.size), price: number(row.price), purchaseDate: text(row.purchase_date), lifecycle: list(row.lifecycle, 'clean'), condition: text(row.condition), location: text(row.location), wearCount: number(row.wear_count), lastWorn: text(row.last_worn) || undefined, favourite: bool(row.favourite), imageUri: text(row.image_uri) || undefined, imageSha256: text(row.image_sha256) || undefined, autoTagged: bool(row.auto_tagged), createdAt: text(row.created_at),
    };
  }
  private async resolveImages(items: Item[], rows: Row[]) {
    return Promise.all(items.map(async (item) => {
      const path = text(rows.find((row) => row.id === item.id)?.image_path);
      if (!path) return item;
      const { data } = await this.client.storage.from('garments').createSignedUrl(path, 3600);
      return { ...item, imageUri: data?.signedUrl ?? item.imageUri };
    }));
  }
  async listItems() { const rows = await this.rows('items'); return this.resolveImages(rows.map((row) => this.itemFromRow(row)), rows); }
  async getItem(id: string) { await this.userId(); const { data, error } = await this.client.from('items').select('*').eq('id', id).maybeSingle(); if (error) throw error; if (!data) return undefined; const [item] = await this.resolveImages([this.itemFromRow(data as Row)], [data as Row]); return item; }
  async saveItem(item: Item) {
    const userId = await this.userId();
    let imagePath: string | undefined;
    if (item.imageUri && /^(file|content|blob):/.test(item.imageUri)) {
      const response = await fetch(item.imageUri);
      const blob = await response.blob();
      imagePath = `${userId}/${item.imageSha256 ?? item.id}.jpg`;
      const { error } = await this.client.storage.from('garments').upload(imagePath, blob, { contentType: 'image/jpeg', upsert: true });
      if (error) throw error;
    }
    const { error } = await this.client.from('items').upsert({ id: item.id, user_id: userId, name: item.name, category: item.category, subcategory: item.subcategory, colours: item.colours, pattern: item.pattern, texture: item.texture, material: item.material, care: item.care, warmth: item.warmth, formality: item.formality, seasons: item.seasons, occasions: item.occasions, fit: item.fit, silhouette: item.silhouette, neckline: item.neckline, sleeve: item.sleeve, rise: item.rise, hem: item.hem, brand: item.brand, size: item.size, price: item.price, purchase_date: item.purchaseDate || null, lifecycle: item.lifecycle, condition: item.condition, location: item.location, wear_count: item.wearCount, last_worn: item.lastWorn ?? null, favourite: item.favourite, image_path: imagePath, image_sha256: item.imageSha256 ?? null, auto_tagged: item.autoTagged ?? false, updated_at: new Date().toISOString() });
    if (error) throw error;
  }
  async deleteItem(id: string) { await this.userId(); const { error } = await this.client.from('items').delete().eq('id', id); if (error) throw error; }
  async listOutfits(): Promise<Outfit[]> { return (await this.rows('outfits')).map((row) => ({ id: text(row.id), userId: text(row.user_id), date: text(row.date), occasion: list(row.occasion, 'daily'), itemIds: list(row.item_ids, []), score: list(row.score, { total: 0, occasion: 0, weather: 0, colour: 0, season: 0, silhouette: 0, taste: 0, rotation: 0, favourite: 0, dismissal: 0, variety: 0 }), reasons: list(row.reasons, []), saved: bool(row.saved), worn: bool(row.worn), anchorId: text(row.anchor_id), packing: list(row.packing, undefined), createdAt: text(row.created_at) })); }
  async saveOutfit(outfit: Outfit) { await this.userId(); const { error } = await this.client.from('outfits').upsert({ id: outfit.id, user_id: outfit.userId, date: outfit.date, occasion: outfit.occasion, item_ids: outfit.itemIds, score: outfit.score, reasons: outfit.reasons, saved: outfit.saved, worn: outfit.worn, anchor_id: outfit.anchorId, packing: outfit.packing ?? null }); if (error) throw error; }
  async listWearLogs(): Promise<WearLog[]> { return (await this.rows('wear_logs', 'worn_at')).map((row) => ({ id: text(row.id), userId: text(row.user_id), itemId: text(row.item_id), outfitId: text(row.outfit_id) || undefined, wornAt: text(row.worn_at), occasion: list(row.occasion, 'daily') })); }
  async logWear(log: WearLog) { await this.userId(); const { error } = await this.client.from('wear_logs').insert({ id: log.id, user_id: log.userId, item_id: log.itemId, outfit_id: log.outfitId ?? null, worn_at: log.wornAt, occasion: log.occasion }); if (error) throw error; }
  async addSignal(signal: Signal) { await this.userId(); const { error } = await this.client.from('signals').insert({ id: signal.id, user_id: signal.userId, item_id: signal.itemId, kind: signal.kind, note: signal.note ?? null }); if (error) throw error; }
  async listSignals(): Promise<Signal[]> { return (await this.rows('signals')).map((row) => ({ id: text(row.id), userId: text(row.user_id), itemId: text(row.item_id), kind: list(row.kind, 'dismiss'), note: text(row.note) || undefined, createdAt: text(row.created_at) })); }
  async addFeedback(feedback: Feedback) { await this.userId(); const { error } = await this.client.from('feedback').insert({ id: feedback.id, user_id: feedback.userId, outfit_id: feedback.outfitId, fit: feedback.fit, tags: feedback.tags }); if (error) throw error; }
  async listFeedback(): Promise<Feedback[]> { return (await this.rows('feedback')).map((row) => ({ id: text(row.id), userId: text(row.user_id), outfitId: text(row.outfit_id), fit: list(row.fit, 'good'), tags: list(row.tags, []), createdAt: text(row.created_at) })); }
  async listWishlist(): Promise<WishlistItem[]> { return (await this.rows('wishlist')).map((row) => ({ id: text(row.id), name: text(row.name), brand: text(row.brand), price: number(row.price), category: list(row.category, 'top'), subcategory: text(row.subcategory), colours: list(row.colours, []), fitScore: number(row.fit_score), pairsWith: list(row.pairs_with, []) })); }
  async signIn(credentials: AuthCredentials) { const { error } = await this.client.auth.signInWithPassword({ email: credentials.email, password: credentials.password }); if (error) throw error; return this.getProfile(); }
  async signUp(credentials: AuthCredentials) { const { data, error } = await this.client.auth.signUp({ email: credentials.email, password: credentials.password, options: { data: { name: credentials.name ?? '' } } }); if (error) throw error; return data.session ? 'verified' as const : 'verificationRequired' as const; }
  async verifyEmail(email: string, token: string) { const { error } = await this.client.auth.verifyOtp({ email, token, type: 'signup' }); if (error) throw error; return this.getProfile(); }
  async resetPassword(email: string) { const { error } = await this.client.auth.resetPasswordForEmail(email); if (error) throw error; }
  async signOut() { const { error } = await this.client.auth.signOut(); if (error) throw error; }
  async exportData() { const [profile, items, outfits, wearLogs, signals, feedback] = await Promise.all([this.getProfile(), this.listItems(), this.listOutfits(), this.listWearLogs(), this.listSignals(), this.listFeedback()]); return JSON.stringify({ profile, items, outfits, wearLogs, signals, feedback }, null, 2); }
  async deleteAccount() { await this.userId(); const { error } = await this.client.rpc('delete_own_account'); if (error) throw error; }
}
