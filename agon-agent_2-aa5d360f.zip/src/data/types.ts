export type DataMode = 'demo' | 'supabase' | 'offline';
export type Language = 'en' | 'hi';
export type ThemePreference = 'light' | 'dark' | 'system';
export type Category = 'top' | 'bottom' | 'footwear' | 'outerwear' | 'accessory' | 'onepiece';
export type LifecycleState = 'clean' | 'worn' | 'laundry' | 'drycleaner';
export type Undertone = 'warm' | 'cool' | 'neutral';
export type Occasion = 'daily' | 'college' | 'office' | 'interview' | 'date' | 'wedding' | 'party' | 'family' | 'travel' | 'dinner' | 'gym' | 'festival';
export type BodyShape = 'rectangle' | 'triangle' | 'invertedTriangle' | 'oval' | 'hourglass';
export type ColourSeason = 'warmAutumn' | 'warmSpring' | 'coolWinter' | 'coolSummer';

export interface GarmentColour {
  name: string;
  hex: string;
  undertone: Undertone;
}

export interface Measurements {
  heightCm?: number;
  weightKg?: number;
  shoulderCm?: number;
  chestCm?: number;
  waistCm?: number;
  hipCm?: number;
  inseamCm?: number;
  build?: string;
}

export interface Profile {
  id: string;
  name: string;
  email: string;
  city: string;
  climate: string;
  pronouns: string;
  ageRange: string;
  photoUri?: string;
  moodboardUris: string[];
  measurements: Measurements;
  bodyShape: BodyShape;
  undertone: Undertone;
  colourSeason: ColourSeason;
  faceShape: string;
  hair: string;
  grooming: string;
  styleArchetype: string;
  tasteVector: number[];
  lovedColours: string[];
  avoidedColours: string[];
  patternLevel: number;
  textureLevel: number;
  shineLevel: number;
  brands: Array<{ name: string; size: string }>;
  budgets: Record<Category, [number, number]>;
  constraints: string[];
  sensoryDislikes: string[];
  weeklyRhythm: Occasion[];
  goals: string[];
  noRepeatDays: number;
  language: Language;
  theme: ThemePreference;
  notifications: boolean;
  onboardingComplete: boolean;
}

export interface Item {
  id: string;
  userId: string;
  name: string;
  category: Category;
  subcategory: string;
  colours: [GarmentColour, GarmentColour, GarmentColour];
  pattern: string;
  texture: string;
  material: string;
  care: string;
  warmth: number;
  formality: number;
  seasons: string[];
  occasions: Occasion[];
  fit: string;
  silhouette: string;
  neckline: string;
  sleeve: string;
  rise: string;
  hem: string;
  brand: string;
  size: string;
  price: number;
  purchaseDate: string;
  lifecycle: LifecycleState;
  condition: string;
  location: string;
  wearCount: number;
  lastWorn?: string;
  favourite: boolean;
  imageUri?: string;
  imageSha256?: string;
  autoTagged?: boolean;
  createdAt: string;
}

export type ScoreKey = 'occasion' | 'weather' | 'colour' | 'season' | 'silhouette' | 'taste' | 'rotation' | 'favourite' | 'dismissal' | 'variety';
export type ScoreBreakdown = Record<ScoreKey, number> & { total: number };

export type ReasonCode = 'dressCode' | 'weather' | 'colour' | 'season' | 'silhouette' | 'rotation' | 'favourite' | 'versatile' | 'texture' | 'noRepeat';
export interface LocalizedReason { code: ReasonCode; value?: string }

export interface PackingPlan {
  destination: string;
  days: number;
  dressCode: Occasion;
  includeLaundry: boolean;
  bagType: 'cabin' | 'checkin';
  packedItemIds: string[];
}

export interface Outfit {
  id: string;
  userId: string;
  date: string;
  occasion: Occasion;
  itemIds: string[];
  score: ScoreBreakdown;
  reasons: LocalizedReason[];
  saved: boolean;
  worn: boolean;
  anchorId: string;
  packing?: PackingPlan;
  createdAt: string;
}

export interface WearLog {
  id: string;
  userId: string;
  itemId: string;
  outfitId?: string;
  wornAt: string;
  occasion: Occasion;
}

export interface Signal {
  id: string;
  userId: string;
  itemId: string;
  kind: 'dismiss' | 'love' | 'save' | 'wear';
  note?: string;
  createdAt: string;
}

export interface Feedback {
  id: string;
  userId: string;
  outfitId: string;
  fit: 'awful' | 'tight' | 'good' | 'loose' | 'great';
  tags: string[];
  createdAt: string;
}

export interface Weather {
  temperatureC: number;
  humidity: number;
  precipitationChance: number;
  condition: string;
  source: 'provider' | 'seasonal';
}

export interface LookRequest {
  date: string;
  occasion: Occasion;
  weather: Weather;
  lockedItemIds?: string[];
  mustWearIds?: string[];
  excludedItemIds?: string[];
  noRepeatDays?: number;
  salt?: string;
  alternativeAnchors?: string[];
}

export interface WishlistItem {
  id: string;
  name: string;
  brand: string;
  price: number;
  category: Category;
  subcategory: string;
  colours: [GarmentColour, GarmentColour, GarmentColour];
  fitScore: number;
  pairsWith: string[];
}

export interface AuthCredentials { email: string; password: string; name?: string }

export interface Repository {
  readonly mode: DataMode;
  getProfile(): Promise<Profile>;
  saveProfile(profile: Profile): Promise<void>;
  listItems(): Promise<Item[]>;
  getItem(id: string): Promise<Item | undefined>;
  saveItem(item: Item): Promise<void>;
  deleteItem(id: string): Promise<void>;
  listOutfits(): Promise<Outfit[]>;
  saveOutfit(outfit: Outfit): Promise<void>;
  listWearLogs(): Promise<WearLog[]>;
  logWear(log: WearLog): Promise<void>;
  addSignal(signal: Signal): Promise<void>;
  listSignals(): Promise<Signal[]>;
  addFeedback(feedback: Feedback): Promise<void>;
  listFeedback(): Promise<Feedback[]>;
  listWishlist(): Promise<WishlistItem[]>;
  signIn(credentials: AuthCredentials): Promise<Profile>;
  signUp(credentials: AuthCredentials): Promise<'verified' | 'verificationRequired'>;
  verifyEmail(email: string, token: string): Promise<Profile>;
  resetPassword(email: string): Promise<void>;
  signOut(): Promise<void>;
  exportData(): Promise<string>;
  deleteAccount(): Promise<void>;
}
