import type { Profile } from '../data/types';
import type { CaptureSession } from '../services/captureSession';
import { demoItems } from './seed';

export function createDemoCaptureSession(profile: Profile): CaptureSession {
  return {
    drafts: [demoItems[0], demoItems[1], demoItems[3]].map((item, index) => ({
      item: { ...item, id: `capture-${Date.now()}-${index}`, userId: profile.id, name: item.name, wearCount: 0, lastWorn: undefined, lifecycle: 'clean', createdAt: new Date().toISOString() },
      confidence: [0.94, 0.91, 0.87][index], accepted: true,
    })),
  };
}

export const demoCareSuggestion = { material: 'Cotton', care: 'Cold machine wash \u00b7 Wash with similar colours \u00b7 Line dry', confidence: 0.92 };
