import type { AuthCredentials, Feedback, Item, Outfit, Profile, Repository, Signal, WearLog, WishlistItem } from '../data/types';
import { demoItems, demoOutfits, demoProfile, demoSignals, demoWearLogs, demoWishlist } from './seed';

const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;

export class DemoRepository implements Repository {
  readonly mode = 'demo' as const;
  private profile = clone(demoProfile);
  private items = clone(demoItems);
  private outfits: Outfit[] = clone(demoOutfits);
  private logs = clone(demoWearLogs);
  private signals = clone(demoSignals);
  private feedback: Feedback[] = [];
  private wishlist = clone(demoWishlist);

  async getProfile() { return clone(this.profile); }
  async saveProfile(profile: Profile) { this.profile = clone(profile); }
  async listItems() { return clone(this.items).sort((a, b) => a.name.localeCompare(b.name)); }
  async getItem(id: string) { const item = this.items.find((entry) => entry.id === id); return item ? clone(item) : undefined; }
  async saveItem(item: Item) { const index = this.items.findIndex((entry) => entry.id === item.id); if (index >= 0) this.items[index] = clone(item); else this.items.unshift(clone(item)); }
  async deleteItem(id: string) { this.items = this.items.filter((item) => item.id !== id); }
  async listOutfits() { return clone(this.outfits).sort((a, b) => b.date.localeCompare(a.date)); }
  async saveOutfit(outfit: Outfit) { const index = this.outfits.findIndex((entry) => entry.id === outfit.id); if (index >= 0) this.outfits[index] = clone(outfit); else this.outfits.push(clone(outfit)); }
  async listWearLogs() { return clone(this.logs); }
  async logWear(log: WearLog) {
    this.logs.push(clone(log));
    const item = this.items.find((entry) => entry.id === log.itemId);
    if (item) { item.wearCount += 1; item.lastWorn = log.wornAt; item.lifecycle = 'worn'; }
  }
  async addSignal(signal: Signal) { this.signals.push(clone(signal)); }
  async listSignals() { return clone(this.signals); }
  async addFeedback(feedback: Feedback) { this.feedback.push(clone(feedback)); }
  async listFeedback() { return clone(this.feedback); }
  async listWishlist() { return clone(this.wishlist); }
  async signIn(credentials: AuthCredentials) { this.profile = { ...this.profile, email: credentials.email, name: credentials.name || this.profile.name }; return clone(this.profile); }
  async signUp(credentials: AuthCredentials) { this.profile = { ...this.profile, email: credentials.email, name: credentials.name || this.profile.name }; return 'verificationRequired' as const; }
  async verifyEmail() { return clone(this.profile); }
  async resetPassword() { return Promise.resolve(); }
  async signOut() { return Promise.resolve(); }
  async exportData() { return JSON.stringify({ profile: this.profile, items: this.items, outfits: this.outfits, wearLogs: this.logs, signals: this.signals, feedback: this.feedback }, null, 2); }
  async deleteAccount() { this.items = []; this.outfits = []; this.logs = []; this.signals = []; this.feedback = []; this.wishlist = []; this.profile = { ...this.profile, name: '', email: '', onboardingComplete: false }; }
}
