import type { GarmentColour, Item, Outfit, Profile, ScoreBreakdown, Signal, WearLog, WishlistItem } from '../data/types';

const c = (name: string, hex: string, undertone: GarmentColour['undertone'] = 'neutral'): GarmentColour => ({ name, hex, undertone });
const sand = c('Sand', '#C8B79E', 'warm');
const ivory = c('Ivory', '#E8E0D1', 'warm');
const olive = c('Olive', '#5B6248', 'warm');
const tan = c('Tan', '#8A5738', 'warm');
const white = c('White', '#F4F2EC', 'neutral');
const bronze = c('Bronze', '#A9793F', 'warm');
const indigo = c('Indigo', '#293B50', 'cool');
const charcoal = c('Charcoal', '#353431');
const navy = c('Navy', '#202D3B', 'cool');
const black = c('Black', '#1B1A18');
const burgundy = c('Burgundy', '#693C3A', 'warm');
const beige = c('Beige', '#B7A68C', 'warm');
const sage = c('Sage', '#87947E', 'warm');
const terracotta = c('Terracotta', '#A75D43', 'warm');
const grey = c('Grey', '#85827B');
const brown = c('Brown', '#4B372B', 'warm');
const gold = c('Antique gold', '#B39455', 'warm');
const teal = c('Deep teal', '#305B57', 'cool');
const rust = c('Rust', '#914E32', 'warm');
const blue = c('Washed blue', '#6C8496', 'cool');
const rose = c('Dusty rose', '#A77D76', 'warm');

export const demoProfile: Profile = {
  id: 'demo-abhishek', name: 'Abhishek', email: 'abhishek@example.com', city: 'Mumbai', climate: 'Humid · 26–34° · Monsoon Jun–Sep', pronouns: 'He/Him', ageRange: '25–34',
  measurements: { heightCm: 178, weightKg: 72, shoulderCm: 46, chestCm: 96, waistCm: 84, hipCm: 96, inseamCm: 78, build: 'Athletic' },
  bodyShape: 'rectangle', undertone: 'warm', colourSeason: 'warmAutumn', faceShape: 'Oval', hair: 'Medium', grooming: 'Clean shaven', styleArchetype: 'The Modern Classic', tasteVector: [0.82, 0.68, 0.35, 0.74, 0.22],
  lovedColours: [olive.hex, sand.hex, burgundy.hex, ivory.hex], avoidedColours: ['#B7A6C9', '#E8D94E'], patternLevel: 28, textureLevel: 64, shineLevel: 18,
  moodboardUris: [],
  brands: [{ name: 'Fabindia', size: 'M' }, { name: 'Zara', size: '40' }, { name: 'Levi’s', size: '32' }, { name: 'H&M', size: 'M' }],
  budgets: { top: [1500, 3000], bottom: [2000, 4000], footwear: [3000, 6000], outerwear: [5000, 9000], accessory: [1500, 8000], onepiece: [5000, 12000] },
  constraints: ['No sleeveless', 'Cover shoulders', 'Prefer loose fit', 'No leather at festivals'], sensoryDislikes: ['Tags itch', 'Tight waist', 'Synthetic fabric', 'Stiff collars'],
  weeklyRhythm: ['office', 'office', 'gym', 'office', 'dinner', 'family', 'daily'], goals: ['Build a capsule', 'No repeats for 30 days', 'Dress for my new size'], noRepeatDays: 14, language: 'en', theme: 'light', notifications: true, onboardingComplete: true,
};

type Seed = [string, Item['category'], string, GarmentColour, string, number, number, string, string, number, number, string, Item['lifecycle'], number, string?];
const seeds: Seed[] = [
  ['Sand Linen Kurta', 'top', 'Kurta', sand, 'Linen', 1, 3, 'Fabindia', 'M', 2990, 7, 'Straight', 'clean', 20260712],
  ['Ivory Cotton Churidar', 'bottom', 'Churidar', ivory, 'Cotton', 1, 3, 'Fabindia', 'M', 1490, 9, 'Tapered', 'clean', 20260802],
  ['Olive Nehru Jacket', 'outerwear', 'Nehru jacket', olive, 'Cotton silk', 2, 4, 'Manyavar', '40', 5990, 4, 'Structured', 'clean', 20260910],
  ['Tan Leather Loafers', 'footwear', 'Loafers', tan, 'Leather', 1, 4, 'Hidesign', '42', 6990, 12, 'Classic', 'clean', 20260701],
  ['White Minimal Sneakers', 'footwear', 'White sneakers', white, 'Leather', 1, 2, 'Puma', '42', 4999, 18, 'Low profile', 'clean', 20260520],
  ['Bronze Field Watch', 'accessory', 'Watch', bronze, 'Steel and leather', 0, 3, 'Titan', '38 mm', 8995, 26, 'Classic', 'clean', 20260118],
  ['Indigo Slim Jeans', 'bottom', 'Slim jeans', indigo, 'Denim', 2, 2, 'Levi’s', '32', 3999, 24, 'Straight', 'clean', 20251010],
  ['Ecru Oxford Shirt', 'top', 'Oxford shirt', ivory, 'Cotton', 1, 4, 'Allen Solly', '40', 2499, 11, 'Tailored', 'clean', 20260902],
  ['Charcoal Dress Trousers', 'bottom', 'Dress trousers', charcoal, 'Wool blend', 2, 4, 'Van Heusen', '32', 3299, 8, 'Tailored', 'clean', 20260820],
  ['Navy Unstructured Blazer', 'outerwear', 'Unstructured blazer', navy, 'Cotton', 2, 5, 'Massimo Dutti', '40', 12990, 5, 'Structured', 'drycleaner', 20260412],
  ['Black Derby Shoes', 'footwear', 'Derby shoes', black, 'Leather', 1, 5, 'Clarks', '42', 7990, 7, 'Classic', 'clean', 20260214],
  ['Burgundy Silk Kurta', 'top', 'Silk kurta', burgundy, 'Silk', 1, 5, 'Manyavar', 'M', 6990, 3, 'Straight', 'clean', 20250928],
  ['Sand Pleated Chinos', 'bottom', 'Chinos', beige, 'Cotton', 1, 3, 'Uniqlo', '32', 2990, 16, 'Straight', 'worn', 20260322],
  ['Sage Cotton Shirt', 'top', 'Linen shirt', sage, 'Cotton linen', 1, 3, 'Fabindia', 'M', 2290, 10, 'Relaxed', 'clean', 20260720],
  ['Terracotta Pique Polo', 'top', 'Polo shirt', terracotta, 'Cotton', 1, 2, 'Marks & Spencer', 'M', 1999, 14, 'Tailored', 'laundry', 20260514],
  ['Oatmeal Crewneck Sweater', 'top', 'Crewneck sweater', ivory, 'Merino wool', 4, 3, 'Uniqlo', 'M', 3990, 6, 'Relaxed', 'clean', 20251202],
  ['Charcoal Merino Turtleneck', 'top', 'Turtleneck', charcoal, 'Merino wool', 4, 4, 'COS', 'M', 5990, 2, 'Tailored', 'clean', 20251218],
  ['Indigo Denim Shirt', 'top', 'Denim shirt', indigo, 'Denim', 2, 2, 'Levi’s', 'M', 3499, 13, 'Straight', 'clean', 20251102],
  ['Black Cotton T-shirt', 'top', 'T-shirt', black, 'Supima cotton', 1, 1, 'Uniqlo', 'M', 990, 30, 'Straight', 'clean', 20260604],
  ['Ivory Henley', 'top', 'Henley', ivory, 'Cotton', 1, 1, 'H&M', 'M', 1299, 20, 'Straight', 'worn', 20260528],
  ['Olive Camp Collar Shirt', 'top', 'Camp collar shirt', olive, 'Viscose', 0, 2, 'Zara', 'M', 2790, 8, 'Relaxed', 'clean', 20260622],
  ['Chikankari Celebration Kurta', 'top', 'Chikankari kurta', white, 'Cotton', 1, 4, 'Tasva', 'M', 4990, 4, 'Straight', 'clean', 20251016],
  ['Stone Drawstring Trousers', 'bottom', 'Drawstring trousers', sand, 'Linen blend', 1, 2, 'Zara', '32', 3290, 10, 'Relaxed', 'clean', 20260618],
  ['Black Pleated Trousers', 'bottom', 'Pleated trousers', black, 'Tencel', 1, 3, 'COS', '32', 6990, 5, 'Wide', 'clean', 20260808],
  ['Olive Cargo Trousers', 'bottom', 'Cargo trousers', olive, 'Cotton ripstop', 2, 1, 'Uniqlo', '32', 3990, 9, 'Straight', 'laundry', 20251120],
  ['Navy Track Pants', 'bottom', 'Track pants', navy, 'Cotton knit', 2, 0, 'Nike', 'M', 2995, 15, 'Tapered', 'clean', 20260105],
  ['Cream Salwar Trousers', 'bottom', 'Salwar', ivory, 'Cotton', 1, 4, 'Fabindia', 'M', 1790, 3, 'Relaxed', 'clean', 20251001],
  ['Graphite Corduroy Trousers', 'bottom', 'Corduroy trousers', grey, 'Cotton corduroy', 3, 3, 'Marks & Spencer', '32', 3999, 6, 'Straight', 'clean', 20251222],
  ['Brown Penny Loafers', 'footwear', 'Penny loafers', brown, 'Leather', 1, 4, 'Bata', '42', 4499, 10, 'Classic', 'clean', 20260315],
  ['Black Leather Sandals', 'footwear', 'Leather sandals', black, 'Leather', 0, 2, 'Hidesign', '42', 3990, 9, 'Minimal', 'clean', 20260409],
  ['Tan Kolhapuri Sandals', 'footwear', 'Kolhapuri sandals', tan, 'Leather', 0, 3, 'Aprajita Toor', '42', 3290, 5, 'Classic', 'clean', 20251008],
  ['Grey Running Shoes', 'footwear', 'Running shoes', grey, 'Mesh and rubber', 1, 0, 'Nike', '42', 6995, 22, 'Athletic', 'worn', 20260202],
  ['Ivory Espadrilles', 'footwear', 'Espadrilles', ivory, 'Canvas and jute', 0, 2, 'Zara', '42', 2990, 4, 'Relaxed', 'clean', 20260503],
  ['Olive Suede Desert Boots', 'footwear', 'Desert boots', olive, 'Suede', 2, 3, 'Clarks', '42', 8990, 3, 'Classic', 'clean', 20251212],
  ['Indigo Denim Jacket', 'outerwear', 'Denim jacket', indigo, 'Denim', 3, 2, 'Levi’s', 'M', 4999, 11, 'Straight', 'clean', 20241118],
  ['Stone Trench Coat', 'outerwear', 'Trench coat', sand, 'Cotton gabardine', 3, 4, 'Marks & Spencer', '40', 9999, 2, 'Structured', 'drycleaner', 20250110],
  ['Black Bandhgala Jacket', 'outerwear', 'Bandhgala jacket', black, 'Wool silk', 3, 5, 'Tasva', '40', 15990, 2, 'Structured', 'clean', 20250912],
  ['Ivory Silk Sherwani', 'outerwear', 'Sherwani', ivory, 'Raw silk', 2, 5, 'Manyavar', '40', 24990, 1, 'Structured', 'clean', 20240920],
  ['Olive Utility Overshirt', 'outerwear', 'Overshirt', olive, 'Brushed cotton', 2, 2, 'Uniqlo', 'M', 3990, 12, 'Relaxed', 'clean', 20251115],
  ['Washed Blue Bomber', 'outerwear', 'Bomber jacket', blue, 'Cotton', 2, 2, 'Zara', 'M', 5990, 7, 'Relaxed', 'clean', 20250303],
  ['Woven Tan Belt', 'accessory', 'Belt', tan, 'Leather', 0, 3, 'Hidesign', '34', 2490, 20, 'Classic', 'clean', 20250401],
  ['Rust Silk Pocket Square', 'accessory', 'Pocket square', rust, 'Silk', 0, 5, 'The Tie Hub', 'One size', 990, 2, 'Soft', 'clean', 20250912],
  ['Teal Printed Stole', 'accessory', 'Stole', teal, 'Modal silk', 1, 4, 'Fabindia', 'One size', 1990, 3, 'Soft', 'clean', 20251011],
  ['Dusty Rose Linen Scarf', 'accessory', 'Scarf', rose, 'Linen', 1, 3, 'Nicobar', 'One size', 2490, 4, 'Soft', 'clean', 20260220],
  ['Gold Rim Sunglasses', 'accessory', 'Sunglasses', gold, 'Metal and acetate', 0, 2, 'Lenskart', 'One size', 3490, 8, 'Classic', 'clean', 20260425],
];

export const demoItems: Item[] = seeds.map((seed, index) => {
  const [name, category, subcategory, colour, material, warmth, formality, brand, size, price, wearCount, silhouette, lifecycle, purchased] = seed;
  const date = String(purchased);
  const lastWorn = index % 4 === 0 ? `2026-10-${String(28 - (index % 12)).padStart(2, '0')}` : index % 5 === 0 ? '2026-09-18' : undefined;
  return {
    id: `garment-${String(index + 1).padStart(2, '0')}`, userId: demoProfile.id, name, category, subcategory,
    colours: [colour, index % 2 ? ivory : sand, index % 3 ? charcoal : olive], pattern: index % 7 === 0 ? 'Subtle weave' : 'Solid', texture: material.includes('Linen') ? 'Slubbed' : material.includes('Silk') ? 'Smooth lustre' : 'Matte', material, care: material.includes('Silk') || material.includes('wool') ? 'Dry clean only' : 'Cold machine wash · Line dry', warmth, formality,
    seasons: warmth >= 3 ? ['Winter'] : warmth === 2 ? ['Winter', 'Monsoon'] : ['Summer', 'Monsoon'], occasions: formality >= 5 ? ['wedding', 'interview'] : formality === 4 ? ['office', 'dinner', 'festival'] : formality === 3 ? ['office', 'family', 'dinner'] : formality === 2 ? ['daily', 'college', 'travel'] : ['daily', 'gym'],
    fit: silhouette === 'Relaxed' ? 'Relaxed' : 'True to size', silhouette: silhouette.toLowerCase(), neckline: category === 'top' ? (subcategory.includes('Kurta') ? 'Band collar' : subcategory.includes('Polo') ? 'Polo collar' : 'Crew') : 'None', sleeve: category === 'top' ? (formality >= 3 ? 'Full' : 'Half') : 'None', rise: category === 'bottom' ? 'Mid' : 'None', hem: category === 'top' ? 'Straight' : category === 'bottom' ? 'Ankle' : 'Standard', brand, size, price, purchaseDate: `${date.slice(0, 4)}-${date.slice(4, 6)}-${date.slice(6, 8)}`, lifecycle, condition: wearCount > 20 ? 'Well loved' : 'Excellent', location: lifecycle === 'laundry' ? 'Laundry basket' : index % 3 === 0 ? 'Wardrobe · rail' : 'Wardrobe · shelf', wearCount, lastWorn, favourite: [0, 2, 5, 7, 13].includes(index), autoTagged: index < 5, createdAt: `2026-01-${String((index % 27) + 1).padStart(2, '0')}T08:00:00.000Z`,
  };
});

const historyScore: ScoreBreakdown = { total: 91, occasion: 94, weather: 92, colour: 93, season: 90, silhouette: 89, taste: 94, rotation: 78, favourite: 88, dismissal: 100, variety: 6 };
export const demoOutfits: Outfit[] = [
  { id: 'history-1', userId: demoProfile.id, date: '2026-11-01', occasion: 'office', itemIds: ['garment-01', 'garment-02', 'garment-04', 'garment-06'], score: historyScore, reasons: [{ code: 'dressCode', value: 'office' }, { code: 'weather' }, { code: 'colour' }], saved: true, worn: true, anchorId: 'garment-01', createdAt: '2026-11-01T06:00:00.000Z' },
  { id: 'history-2', userId: demoProfile.id, date: '2026-10-29', occasion: 'dinner', itemIds: ['garment-12', 'garment-09', 'garment-11'], score: { ...historyScore, total: 89 }, reasons: [{ code: 'dressCode', value: 'dinner' }, { code: 'colour' }], saved: false, worn: true, anchorId: 'garment-12', createdAt: '2026-10-29T06:00:00.000Z' },
  { id: 'history-3', userId: demoProfile.id, date: '2026-10-26', occasion: 'travel', itemIds: ['garment-14', 'garment-23', 'garment-05'], score: { ...historyScore, total: 87 }, reasons: [{ code: 'weather' }, { code: 'versatile' }], saved: true, worn: false, anchorId: 'garment-14', createdAt: '2026-10-26T06:00:00.000Z' },
  { id: 'packing-demo', userId: demoProfile.id, date: '2026-11-12', occasion: 'travel', itemIds: ['garment-01', 'garment-14', 'garment-23', 'garment-02', 'garment-04', 'garment-05'], score: historyScore, reasons: [{ code: 'versatile' }], saved: true, worn: false, anchorId: 'garment-01', packing: { destination: 'Udaipur', days: 4, dressCode: 'wedding', includeLaundry: false, bagType: 'cabin', packedItemIds: ['garment-01', 'garment-14', 'garment-23', 'garment-02'] }, createdAt: '2026-11-01T06:00:00.000Z' },
];
export const demoWearLogs: WearLog[] = demoItems.filter((item) => item.lastWorn).map((item, index) => ({ id: `wear-${index}`, userId: demoProfile.id, itemId: item.id, wornAt: item.lastWorn as string, occasion: index % 3 === 0 ? 'office' : 'daily' }));
export const demoSignals: Signal[] = [{ id: 'signal-1', userId: demoProfile.id, itemId: 'garment-15', kind: 'dismiss', note: 'Too warm', createdAt: '2026-10-29T09:00:00.000Z' }];
export const demoWishlist: WishlistItem[] = [
  { id: 'wish-1', name: 'Veja Campo', brand: 'Veja', price: 12990, category: 'footwear', subcategory: 'White sneakers', colours: [white, ivory, grey], fitScore: 8.4, pairsWith: ['garment-07', 'garment-13', 'garment-23'] },
  { id: 'wish-2', name: 'Unstructured Cotton Blazer', brand: 'Massimo Dutti', price: 17990, category: 'outerwear', subcategory: 'Unstructured blazer', colours: [charcoal, navy, sand], fitScore: 8.1, pairsWith: ['garment-01', 'garment-08', 'garment-09'] },
  { id: 'wish-3', name: 'Chanderi Silk Stole', brand: 'Nicobar', price: 4990, category: 'accessory', subcategory: 'Stole', colours: [teal, gold, ivory], fitScore: 9.2, pairsWith: ['garment-01', 'garment-12', 'garment-22'] },
];
