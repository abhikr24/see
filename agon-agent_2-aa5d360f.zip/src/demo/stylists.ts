export const demoStylists = [
  { id: 'stylist-rhea', name: 'Rhea Sharma', speciality: 'Minimal & classic', price: 1999, initials: 'RS' },
  { id: 'stylist-arjun', name: 'Arjun Mehta', speciality: 'Smart casual', price: 1499, initials: 'AM' },
  { id: 'stylist-meera', name: 'Meera Iyer', speciality: 'Festive & ethnic', price: 1999, initials: 'MI' },
];
