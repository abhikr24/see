import { differenceInCalendarDays, parseISO } from 'date-fns';
import type { Item, LocalizedReason, LookRequest, Occasion, Outfit, Profile, ScoreBreakdown, Signal, WearLog } from '../data/types';

const clamp = (value: number, min = 0, max = 100) => Math.min(max, Math.max(min, value));
const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
const formalityFor: Record<Occasion, number> = { daily: 1, college: 2, office: 3, interview: 5, date: 3, wedding: 5, party: 4, family: 3, travel: 1, dinner: 4, gym: 0, festival: 4 };

function hash(value: string): number {
  let result = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    result ^= value.charCodeAt(index);
    result = Math.imul(result, 16777619);
  }
  return Math.abs(result >>> 0);
}

function rgb(hex: string): [number, number, number] {
  const safe = /^#[0-9a-f]{6}$/i.test(hex) ? hex : '#8C8078';
  return [1, 3, 5].map((start) => parseInt(safe.slice(start, start + 2), 16)) as [number, number, number];
}

export function colourHarmony(first: string, second: string): number {
  const a = rgb(first).map((value) => value / 255);
  const b = rgb(second).map((value) => value / 255);
  const spread = (values: number[]) => Math.max(...values) - Math.min(...values);
  const chromaA = spread(a);
  const chromaB = spread(b);
  const luminanceA = average(a);
  const luminanceB = average(b);
  if (chromaA < 0.12 || chromaB < 0.12) return 96 - Math.abs(luminanceA - luminanceB) * 8;
  const hue = (values: number[]) => {
    const [r, g, bl] = values;
    const max = Math.max(r, g, bl);
    const min = Math.min(r, g, bl);
    const delta = max - min;
    if (delta === 0) return 0;
    const value = max === r ? ((g - bl) / delta) % 6 : max === g ? (bl - r) / delta + 2 : (r - g) / delta + 4;
    return (value * 60 + 360) % 360;
  };
  const distance = Math.abs(hue(a) - hue(b));
  const shortest = Math.min(distance, 360 - distance);
  if (shortest < 32) return 94;
  if (shortest > 145) return 91;
  if (shortest > 85 && shortest < 125) return 86;
  return clamp(83 - Math.abs(luminanceA - luminanceB) * 12, 60, 83);
}

export function warmthNeed(temperatureC: number, precipitationChance = 0): number {
  if (temperatureC <= 8) return 5;
  if (temperatureC <= 14) return 4;
  if (temperatureC <= 19) return 3;
  if (temperatureC <= 25) return precipitationChance > 60 ? 2 : 1;
  return 0;
}

export function scoreGarment(item: Item, anchors: Item[], profile: Profile, signals: Signal[], logs: WearLog[], request: LookRequest): ScoreBreakdown {
  const occasionTarget = formalityFor[request.occasion];
  const occasion = item.occasions.includes(request.occasion) ? clamp(100 - Math.abs(item.formality - occasionTarget) * 10) : clamp(76 - Math.abs(item.formality - occasionTarget) * 20);
  const need = warmthNeed(request.weather.temperatureC, request.weather.precipitationChance);
  const categoryNeed = item.category === 'outerwear' ? need : item.category === 'footwear' || item.category === 'accessory' ? Math.min(need, 2) : Math.max(0, need - 1);
  const weather = clamp(100 - Math.abs(item.warmth - categoryNeed) * 19 - (request.weather.precipitationChance > 65 && /suede|silk/i.test(item.material) ? 24 : 0));
  const colour = anchors.length ? Math.max(...anchors.map((anchor) => colourHarmony(item.colours[0].hex, anchor.colours[0].hex))) : 88;
  const preferredUndertones = profile.colourSeason === 'warmAutumn' || profile.colourSeason === 'warmSpring' ? ['warm', 'neutral'] : ['cool', 'neutral'];
  const season = item.colours.some((entry) => preferredUndertones.includes(entry.undertone)) ? 94 : 63;
  const preferredSilhouettes: Record<Profile['bodyShape'], string[]> = {
    rectangle: ['straight', 'tailored', 'relaxed', 'structured'], triangle: ['structured', 'wide', 'straight', 'a-line'],
    invertedTriangle: ['relaxed', 'wide', 'straight', 'a-line'], oval: ['straight', 'relaxed', 'tailored', 'a-line'], hourglass: ['tailored', 'fitted', 'wrap', 'straight'],
  };
  const silhouette = preferredSilhouettes[profile.bodyShape].includes(item.silhouette) ? 95 : 72;
  const loved = item.colours.some((entry) => profile.lovedColours.includes(entry.hex) || profile.lovedColours.includes(entry.name));
  const avoided = item.colours.some((entry) => profile.avoidedColours.includes(entry.hex) || profile.avoidedColours.includes(entry.name));
  const taste = avoided ? 8 : loved ? 100 : 72;
  const itemLogs = logs.filter((log) => log.itemId === item.id);
  const latest = [item.lastWorn, ...itemLogs.map((log) => log.wornAt)].filter((value): value is string => Boolean(value)).sort().at(-1);
  const days = latest ? Math.max(0, differenceInCalendarDays(parseISO(request.date), parseISO(latest))) : 45;
  const rotation = clamp(35 + days * 4);
  const favourite = item.favourite ? 100 : 62;
  const lastDismissal = signals.filter((signal) => signal.itemId === item.id && signal.kind === 'dismiss').sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  const dismissalDays = lastDismissal ? Math.max(0, differenceInCalendarDays(parseISO(request.date), parseISO(lastDismissal.createdAt))) : 60;
  const dismissal = clamp(dismissalDays * 5);
  const variety = (hash(`${item.id}:${request.salt ?? request.date}`) % 81) / 10;
  const total = clamp(occasion * 0.22 + weather * 0.16 + colour * 0.12 + season * 0.08 + silhouette * 0.08 + taste * 0.12 + rotation * 0.09 + favourite * 0.04 + dismissal * 0.05 + variety * 0.04);
  return { occasion: Math.round(occasion), weather: Math.round(weather), colour: Math.round(colour), season: Math.round(season), silhouette: Math.round(silhouette), taste: Math.round(taste), rotation: Math.round(rotation), favourite: Math.round(favourite), dismissal: Math.round(dismissal), variety: Math.round(variety * 10) / 10, total: Math.round(total * 10) / 10 };
}

function aggregate(items: Item[], scores: ScoreBreakdown[]): ScoreBreakdown {
  const result = { total: 0, occasion: 0, weather: 0, colour: 0, season: 0, silhouette: 0, taste: 0, rotation: 0, favourite: 0, dismissal: 0, variety: 0 } as ScoreBreakdown;
  (Object.keys(result) as Array<keyof ScoreBreakdown>).forEach((key) => { result[key] = Math.round(average(scores.map((score) => score[key])) * 10) / 10; });
  if (items.length > 1) {
    const pair = colourHarmony(items[0].colours[0].hex, items[1].colours[0].hex);
    result.colour = Math.round((result.colour * 0.6 + pair * 0.4) * 10) / 10;
    result.total = Math.round((result.total * 0.88 + pair * 0.12) * 10) / 10;
  }
  return result;
}

function reasonsFor(items: Item[], score: ScoreBreakdown, request: LookRequest): LocalizedReason[] {
  const reasons: LocalizedReason[] = [{ code: 'dressCode', value: request.occasion }];
  if (request.weather.temperatureC >= 24) reasons.push({ code: 'weather' });
  if (score.colour >= 82) reasons.push({ code: 'colour' });
  else if (score.rotation >= 75) reasons.push({ code: 'rotation' });
  else reasons.push({ code: 'versatile' });
  if (reasons.length < 3 && items.some((item) => /linen|cotton|silk|wool/i.test(item.material))) reasons.push({ code: 'texture' });
  return reasons.slice(0, 3);
}

const isBottom = (item: Item) => item.category === 'bottom';

export function composeLook(items: Item[], profile: Profile, logs: WearLog[], signals: Signal[], request: LookRequest): Outfit {
  const excluded = new Set(request.excludedItemIds ?? []);
  const noRepeatDays = request.noRepeatDays ?? profile.noRepeatDays;
  const recent = new Set(logs.filter((log) => {
    const days = differenceInCalendarDays(parseISO(request.date), parseISO(log.wornAt));
    return days >= 0 && days < noRepeatDays;
  }).map((log) => log.itemId));
  const forcedIds = new Set([...(request.lockedItemIds ?? []), ...(request.mustWearIds ?? [])]);
  const available = items.filter((item) => item.lifecycle === 'clean' && item.condition !== 'Retired' && (!excluded.has(item.id) || forcedIds.has(item.id)) && (!recent.has(item.id) || forcedIds.has(item.id)));
  const alternatives = new Set(request.alternativeAnchors ?? []);
  let anchors = available.filter((item) => (item.category === 'top' || item.category === 'onepiece') && !alternatives.has(item.id));
  const forcedAnchor = anchors.find((item) => forcedIds.has(item.id));
  if (forcedAnchor) anchors = [forcedAnchor, ...anchors.filter((item) => item.id !== forcedAnchor.id)];
  if (!anchors.length) {
    return { id: `empty-${request.date}-${request.occasion}`, userId: profile.id, date: request.date, occasion: request.occasion, itemIds: [], anchorId: '', score: aggregate([], []), reasons: [], saved: false, worn: false, createdAt: new Date(0).toISOString() };
  }
  const rankedAnchors = anchors.map((item) => ({ item, score: scoreGarment(item, [], profile, signals, logs, request) })).sort((a, b) => b.score.total - a.score.total);
  const anchor = rankedAnchors[0].item;
  const forced = (category: Item['category']) => available.find((item) => item.category === category && forcedIds.has(item.id));
  const pick = (category: Item['category'], anchored: Item[]) => {
    const locked = forced(category);
    if (locked) return locked;
    return available.filter((item) => item.category === category && !anchored.some((part) => part.id === item.id))
      .map((item) => ({ item, score: scoreGarment(item, anchored, profile, signals, logs, request) }))
      .sort((a, b) => b.score.total - a.score.total)[0]?.item;
  };
  const selected: Item[] = [anchor];
  if (anchor.category !== 'onepiece') {
    const bottom = pick('bottom', selected);
    if (bottom) selected.push(bottom);
  }
  const footwear = pick('footwear', selected);
  if (footwear) selected.push(footwear);
  const formalOuterwear = formalityFor[request.occasion] >= 5 && ['office', 'interview', 'wedding'].includes(request.occasion);
  if (request.weather.temperatureC <= 18 || request.weather.precipitationChance >= 65 || formalOuterwear || forced('outerwear')) {
    const outerwear = pick('outerwear', selected);
    if (outerwear) selected.push(outerwear);
  }
  const accessory = pick('accessory', selected);
  if (accessory) selected.push(accessory);
  for (const id of forcedIds) {
    if (!selected.some((item) => item.id === id)) {
      const item = available.find((candidate) => candidate.id === id);
      if (item) selected.push(item);
    }
  }
  const scores = selected.map((item, index) => scoreGarment(item, selected.slice(0, index), profile, signals, logs, request));
  const score = aggregate(selected, scores);
  const identity = `${request.date}-${request.occasion}-${anchor.id}-${request.salt ?? 'main'}`;
  return { id: `look-${hash(identity)}`, userId: profile.id, date: request.date, occasion: request.occasion, itemIds: selected.map((item) => item.id), anchorId: anchor.id, score, reasons: reasonsFor(selected, score, request), saved: false, worn: false, createdAt: `${request.date}T06:00:00.000Z` };
}

export function composeLookSet(items: Item[], profile: Profile, logs: WearLog[], signals: Signal[], request: LookRequest): [Outfit, Outfit, Outfit] {
  const main = composeLook(items, profile, logs, signals, request);
  const second = composeLook(items, profile, logs, signals, { ...request, salt: `${request.salt ?? 'veste'}-second`, alternativeAnchors: [main.anchorId] });
  const third = composeLook(items, profile, logs, signals, { ...request, salt: `${request.salt ?? 'veste'}-third`, alternativeAnchors: [main.anchorId, second.anchorId].filter(Boolean) });
  return [main, second, third];
}
