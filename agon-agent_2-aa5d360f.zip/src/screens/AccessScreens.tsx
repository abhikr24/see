import React, { useEffect, useState } from 'react';
import { View, Pressable, TextInput, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';
import * as LocalAuthentication from 'expo-local-authentication';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useReducedMotion } from 'react-native-reanimated';
import { useAppState } from '../data/AppState';
import { serif, useTheme } from '../theme';
import { EditorialTitle, Eyebrow, Field, IconButton, LookCanvas, Notice, PrimaryButton, ScreenFrame, VesteText, goToScreen, useCopy } from '../components/ui';

export function AccessScreen({ id }: { id: number }) {
  const router = useRouter(); const c = useCopy(); const { colors } = useTheme();
  const app = useAppState();
  const [name, setName] = useState(app.profile?.name ?? '');
  const [email, setEmail] = useState(app.profile?.email ?? '');
  const [password, setPassword] = useState('veste-demo');
  const [code, setCode] = useState('');
  const [terms, setTerms] = useState(true);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const reduced = useReducedMotion();

  useEffect(() => {
    if (id !== 1) return;
    const timer = setTimeout(() => goToScreen(router, 2, true), reduced ? 250 : 1150);
    return () => clearTimeout(timer);
  }, [id, reduced, router]);

  const run = async (action: () => Promise<void>) => { setBusy(true); setMessage(''); try { await action(); } catch (error) { setMessage(error instanceof Error ? error.message : c.access.invalid); } finally { setBusy(false); } };
  const social = () => { if (app.repository.mode === 'demo') goToScreen(router, 8); else setMessage(c.access.invalid); };

  if (id === 1) return <ScreenFrame id={1} noHeader><View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><VesteText style={{ fontFamily: serif, fontSize: 64, letterSpacing: -3 }}>{c.brand}</VesteText><VesteText style={{ color: colors.taupe, fontSize: 13, marginTop: 10 }}>{c.tagline}</VesteText><View style={{ width: 32, height: 1, backgroundColor: colors.bronze, marginTop: 32 }} /></View><VesteText style={{ textAlign: 'center', color: colors.taupe, fontSize: 10, letterSpacing: 1.3, marginBottom: 20 }}>{c.posture.toUpperCase()}</VesteText></ScreenFrame>;

  if (id === 2) return <ScreenFrame id={2} noHeader><View style={{ paddingTop: 28 }}><Eyebrow>{c.posture}</Eyebrow></View><LookCanvas items={app.items.filter((item) => ['garment-01', 'garment-02', 'garment-04', 'garment-06'].includes(item.id))} /><View style={{ flex: 1, justifyContent: 'center', paddingVertical: 24 }}><EditorialTitle size={42}>{c.access.welcomeTitle}</EditorialTitle><VesteText style={{ color: colors.taupe, marginTop: 12, maxWidth: 290 }}>{c.access.welcomeBody}</VesteText></View><PrimaryButton label={c.common.begin} onPress={() => goToScreen(router, 3)} /><View style={{ height: 20 }} /></ScreenFrame>;

  if (id === 7) return <ScreenFrame id={7} noHeader contentStyle={{ paddingHorizontal: 0 }}><BlurView intensity={52} tint={colors.dark ? 'dark' : 'light'} style={{ flex: 1, paddingHorizontal: 24 }}><LookCanvas items={app.items.slice(0, 4)} /><View style={{ flex: 1, justifyContent: 'center' }}><View style={{ alignSelf: 'center', width: 92, height: 92, borderWidth: 1.5, borderColor: colors.bronze, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}><Ionicons name='scan-outline' size={52} color={colors.ink} /></View><EditorialTitle style={{ textAlign: 'center' }}>{c.access.unlock}</EditorialTitle><VesteText style={{ textAlign: 'center', color: colors.taupe, marginTop: 10 }}>{c.access.unlockBody}</VesteText></View>{message && <Notice tone='danger' icon='alert-circle-outline'>{message}</Notice>}<PrimaryButton label={c.access.unlock} icon='finger-print-outline' disabled={busy} onPress={() => { void run(async () => { if (Platform.OS === 'web') { goToScreen(router, 30); return; } const result = await LocalAuthentication.authenticateAsync({ promptMessage: c.access.unlock, cancelLabel: c.common.cancel }); if (result.success) goToScreen(router, 30); else setMessage(c.access.invalid); }); }} /><PrimaryButton variant='ghost' label={c.access.usePasscode} onPress={() => goToScreen(router, 5)} /><View style={{ height: 16 }} /></BlurView></ScreenFrame>;

  if (id === 8) return <ScreenFrame id={8}><View style={{ paddingTop: 32, flex: 1 }}><EditorialTitle size={40}>{c.access.choiceTitle}</EditorialTitle><VesteText style={{ color: colors.taupe, marginTop: 12 }}>{c.screens[8][1]}</VesteText><View style={{ flexDirection: 'row', gap: 12, marginTop: 36, flex: 1 }}>{[{ id: 9, icon: 'sparkles-outline' as const, title: c.access.fresh, body: c.access.freshBody }, { id: 45, icon: 'download-outline' as const, title: c.access.import, body: c.access.importBody }].map((choice) => <Pressable key={choice.id} onPress={() => goToScreen(router, choice.id)} style={{ flex: 1, borderWidth: 1, borderColor: colors.hairline, borderRadius: 16, padding: 18, minHeight: 240 }}><View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: colors.paperSubtle, alignItems: 'center', justifyContent: 'center' }}><Ionicons name={choice.icon} size={26} color={colors.bronze} /></View><EditorialTitle size={24} style={{ marginTop: 28 }}>{choice.title}</EditorialTitle><VesteText style={{ fontSize: 12, color: colors.taupe, marginTop: 10 }}>{choice.body}</VesteText><Ionicons name='arrow-forward' size={18} color={colors.ink} style={{ marginTop: 24 }} /></Pressable>)}</View><Notice>{c.access.demoNotice}</Notice></View><View style={{ height: 24 }} /></ScreenFrame>;

  const titles: Record<number, string> = { 3: c.access.signupTitle, 4: c.access.verifyTitle, 5: c.access.signinTitle, 6: c.access.resetTitle };
  return <ScreenFrame id={id} scroll contentStyle={{ paddingBottom: 24 }}><View style={{ paddingTop: 36 }}><Eyebrow>{c.posture}</Eyebrow><EditorialTitle size={40} style={{ marginTop: 16 }}>{titles[id]}</EditorialTitle>{id === 4 && <VesteText style={{ color: colors.taupe, marginTop: 12 }}>{c.access.verifyBody} {email}</VesteText>}{id === 6 && <VesteText style={{ color: colors.taupe, marginTop: 12 }}>{c.access.resetBody}</VesteText>}</View>
    <View style={{ marginTop: 32 }}>
      {id === 3 && <><Field label={c.access.fullName} value={name} onChangeText={setName} autoComplete='name' returnKeyType='next' /><Field label={c.access.email} value={email} onChangeText={setEmail} keyboardType='email-address' autoCapitalize='none' autoComplete='email' returnKeyType='next' /><Field label={c.access.password} value={password} onChangeText={setPassword} secureTextEntry autoComplete='new-password' /><View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 20 }}><View style={{ width: 100, height: 3, backgroundColor: colors.olive }} /><VesteText style={{ fontSize: 11, color: colors.olive }}>{c.access.strength}</VesteText></View><Pressable onPress={() => setTerms(!terms)} style={{ minHeight: 44, flexDirection: 'row', gap: 10, alignItems: 'center' }}><Ionicons name={terms ? 'checkbox' : 'square-outline'} size={20} color={colors.bronze} /><VesteText style={{ flex: 1, fontSize: 11 }}>{c.access.terms}</VesteText></Pressable></>}
      {id === 4 && <><TextInput accessibilityLabel={c.access.verify} value={code} onChangeText={(value) => setCode(value.replace(/\D/g, '').slice(0, 6))} keyboardType='number-pad' autoFocus={false} placeholder='000000' placeholderTextColor={colors.taupe} style={{ height: 64, borderWidth: 1, borderColor: colors.hairline, borderRadius: 12, textAlign: 'center', letterSpacing: 18, fontSize: 25, color: colors.ink, backgroundColor: colors.paperRaised }} /><PrimaryButton variant='ghost' label={c.access.resend} onPress={() => setMessage(c.access.resetSent)} /></>}
      {id === 5 && <><Field label={c.access.email} value={email} onChangeText={setEmail} keyboardType='email-address' autoCapitalize='none' autoComplete='email' /><Field label={c.access.password} value={password} onChangeText={setPassword} secureTextEntry autoComplete='current-password' /><PrimaryButton variant='ghost' label={c.access.forgot} onPress={() => goToScreen(router, 6)} style={{ alignSelf: 'flex-end', marginBottom: 12 }} /></>}
      {id === 6 && <Field label={c.access.email} value={email} onChangeText={setEmail} keyboardType='email-address' autoCapitalize='none' />}
      {message && <Notice tone={message === c.access.resetSent ? 'olive' : 'danger'} icon={message === c.access.resetSent ? 'mail-outline' : 'alert-circle-outline'}>{message}</Notice>}
      <PrimaryButton disabled={busy || (id === 3 && !terms)} label={id === 3 ? c.access.create : id === 4 ? c.access.verify : id === 5 ? c.access.signin : c.access.sendLink} onPress={() => {
        if (id === 3) void run(async () => { await app.signUp({ name, email, password }); goToScreen(router, 4); });
        else if (id === 4) void run(async () => { await app.verifyEmail(email, code); goToScreen(router, 8); });
        else if (id === 5) void run(async () => { await app.signIn({ email, password }); goToScreen(router, 30); });
        else void run(async () => { await app.resetPassword(email); setMessage(c.access.resetSent); });
      }} style={{ marginTop: 20 }} />
      {(id === 3 || id === 5) && <><VesteText style={{ textAlign: 'center', color: colors.taupe, fontSize: 11, marginVertical: 18 }}>{c.access.or}</VesteText><PrimaryButton variant='outline' icon='logo-google' label={c.access.google} onPress={social} /><View style={{ height: 10 }} /><PrimaryButton variant='outline' icon='logo-apple' label={c.access.apple} onPress={social} /></>}
    </View><Notice icon='lock-closed-outline'>{c.common.noEnv}</Notice></ScreenFrame>;
}
