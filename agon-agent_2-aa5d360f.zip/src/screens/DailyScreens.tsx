import React, { useState } from 'react';
import { View, Pressable, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';
import Ionicons from '@expo/vector-icons/Ionicons';
import { format } from 'date-fns';
import { useAppState } from '../data/AppState';
import type { Item, LocalizedReason, Occasion, Outfit } from '../data/types';
import { localizeReason } from '../copy';
import { useTheme } from '../theme';
import { ChoiceChip, EditorialTitle, Eyebrow, Field, IconButton, LookCanvas, Notice, PrimaryButton, ScoreBar, ScreenFrame, Skeleton, VesteSheet, VesteText, goToScreen, useCopy, type IconName } from '../components/ui';

function LookItems({ look, items }: { look: Outfit | null; items: Item[] }) { return look ? look.itemIds.map((id) => items.find((item) => item.id === id)).filter((item): item is Item => Boolean(item)) : []; }
function ReasonLine({ reason, index }: { reason: LocalizedReason; index: number }) {
  const { colors } = useTheme(); const c = useCopy();
  const localised = reason.code === 'dressCode' && reason.value ? localizeReason({ ...reason, value: c.occasion[reason.value as Occasion] ?? reason.value }) : localizeReason(reason);
  return <View style={{ flexDirection: 'row', gap: 12, minHeight: 42, alignItems: 'center' }}><View style={{ width: 24, height: 24, borderRadius: 12, borderWidth: 1, borderColor: colors.bronze, alignItems: 'center', justifyContent: 'center' }}><VesteText style={{ fontSize: 11, color: colors.bronze }}>{index + 1}</VesteText></View><VesteText style={{ flex: 1, fontSize: 13, lineHeight: 19 }}>{localised}</VesteText></View>;
}

function TodayContent({ id }: { id: number }) {
  const app = useAppState(); const c = useCopy(); const { colors } = useTheme(); const router = useRouter(); const [message, setMessage] = useState('');
  const items = LookItems(app.look, app.items); const anchor = items.find((item) => item.id === app.look?.anchorId);
  if (app.loading && !app.profile) return <ScreenFrame id={id} nav='today'><Skeleton rows={5} /></ScreenFrame>;
  return <ScreenFrame id={id} nav='today' scroll contentStyle={{ paddingBottom: 24 }}>
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 20 }}><VesteText style={{ fontSize: 11, color: colors.taupe }}>{format(new Date(), 'EEE, d MMM')}</VesteText><View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name='sunny-outline' size={17} color={colors.bronze} /><VesteText style={{ fontSize: 11 }}>{app.weather ? `${Math.round(app.weather.temperatureC)}° · ${app.weather.condition}` : c.common.loading}</VesteText></View></View>
    <EditorialTitle size={39} style={{ marginTop: 18 }}>{id === 37 ? c.daily.evening : c.daily.morning}</EditorialTitle><EditorialTitle size={39} italic style={{ color: colors.bronze }}>{app.profile?.name}.</EditorialTitle>
    <View style={{ flexDirection: 'row', gap: 8, marginVertical: 18 }}><ChoiceChip icon='briefcase-outline' label={c.occasion[app.occasion]} selected onPress={() => goToScreen(router, 34)} /><ChoiceChip icon='refresh-outline' label={c.daily.otherTakes} onPress={() => goToScreen(router, 32)} /></View>
    {app.error && <Notice tone='danger' icon='alert-circle-outline'>{app.error}</Notice>}
    {message && <Notice>{message}</Notice>}
    <Pressable onPress={() => goToScreen(router, 35)}><LookCanvas items={items} /></Pressable>
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, gap: 4 }}>{([
      ['heart-dislike-outline', c.daily.pass, () => { void app.signalLook('dismiss'); }],
      ['scan-outline', c.daily.remix, () => app.remix()],
      ['heart-outline', c.daily.love, () => { void app.signalLook('love'); setMessage(c.common.loved); }],
      ['bookmark-outline', c.common.save, () => { void app.saveLook(); setMessage(c.common.saved); }],
      ['checkmark-circle-outline', c.daily.wear, () => { void app.wearLook().then(() => setMessage(c.common.worn)); }],
    ] as Array<[IconName, string, () => void]>).map(([icon, label, action]) => <Pressable key={label} onPress={action} style={{ alignItems: 'center', minWidth: 52, minHeight: 48, gap: 5 }}><Ionicons name={icon} size={20} color={colors.ink} /><VesteText style={{ fontSize: 9, color: colors.taupe }}>{label}</VesteText></Pressable>)}</View>
    <Pressable onPress={() => goToScreen(router, 31)} style={{ marginTop: 24, paddingTop: 20, borderTopWidth: 1, borderColor: colors.hairline }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}><EditorialTitle size={25}>{c.daily.why}</EditorialTitle><View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 3 }}><VesteText style={{ fontFamily: 'Georgia', fontSize: 24, color: colors.bronze }}>{Math.round(app.look?.score.total ?? 0)}</VesteText><VesteText style={{ fontSize: 10, color: colors.taupe }}>/100</VesteText></View></View>{app.look?.reasons.slice(0, 2).map((reason, index) => <ReasonLine key={reason.code} reason={reason} index={index} />)}<VesteText style={{ fontSize: 11, color: colors.bronze, marginTop: 8 }}>{c.common.learnMore} →</VesteText></Pressable>
    {id === 37 && <View style={{ marginTop: 28 }}><Eyebrow>{c.daily.quickActions}</Eyebrow><View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>{([[c.common.plan, 50, 'calendar-outline'], [c.common.add, 42, 'add-outline'], [c.daily.discover, 57, 'compass-outline'], [c.daily.insights, 53, 'stats-chart-outline']] as Array<[string, number, IconName]>).map(([label, target, icon]) => <Pressable key={label} onPress={() => goToScreen(router, target)} style={{ flex: 1, minHeight: 74, borderRadius: 12, backgroundColor: colors.paperSubtle, alignItems: 'center', justifyContent: 'center', gap: 7 }}><Ionicons name={icon} size={20} color={colors.bronze} /><VesteText style={{ fontSize: 10 }}>{label}</VesteText></Pressable>)}</View></View>}
    {!anchor && !app.loading && <PrimaryButton label={c.common.addPiece} onPress={() => goToScreen(router, 42)} style={{ marginTop: 20 }} />}
  </ScreenFrame>;
}

function Alternatives() {
  const app = useAppState(); const c = useCopy(); const { colors } = useTheme(); const router = useRouter();
  const alternatives = app.looks?.slice(1).filter((look) => look.itemIds.length) ?? [];
  return <ScreenFrame id={32} nav='today'><EditorialTitle size={36} style={{ marginTop: 26, marginBottom: 8 }}>{c.daily.otherTakes}</EditorialTitle><VesteText style={{ color: colors.taupe, fontSize: 12, marginBottom: 22 }}>{c.daily.alternatives}</VesteText><FlatList horizontal showsHorizontalScrollIndicator={false} data={alternatives} keyExtractor={(look) => look.id} contentContainerStyle={{ gap: 14 }} renderItem={({ item, index }) => <View style={{ width: 246, borderWidth: 1, borderColor: colors.hairline, borderRadius: 20, padding: 10 }}><LookCanvas compact items={LookItems(item, app.items)} /><VesteText numberOfLines={1} style={{ fontFamily: 'Georgia', fontSize: 20, margin: 8 }}>{app.items.find((garment) => garment.id === item.anchorId)?.name}</VesteText><PrimaryButton compact variant={index === 0 ? 'secondary' : 'primary'} label={c.daily.swap} onPress={() => { app.selectLook(index + 1); goToScreen(router, 30); }} style={{ margin: 8 }} /></View>} ListEmptyComponent={<Skeleton rows={2} />} /></ScreenFrame>;
}

const occasionIcons: Record<Occasion, IconName> = { daily: 'cafe-outline', college: 'school-outline', office: 'briefcase-outline', interview: 'ribbon-outline', date: 'heart-outline', wedding: 'diamond-outline', party: 'champagne-outline', family: 'people-outline', travel: 'airplane-outline', dinner: 'restaurant-outline', gym: 'barbell-outline', festival: 'flower-outline' };

export function DailyScreen({ id }: { id: number }) {
  const app = useAppState(); const c = useCopy(); const { colors } = useTheme(); const router = useRouter();
  const [note, setNote] = useState(''); const [selected, setSelected] = useState(''); const [message, setMessage] = useState('');
  if (id === 30 || id === 37) return <TodayContent id={id} />;
  if (id === 32) return <Alternatives />;
  if (id === 36) return <ScreenFrame id={36} nav='today'><View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><Ionicons name='shirt-outline' size={100} color={colors.ink} /><EditorialTitle size={34} style={{ textAlign: 'center', marginTop: 26 }}>{c.daily.emptyTitle}</EditorialTitle><VesteText style={{ textAlign: 'center', color: colors.taupe, maxWidth: 280, marginTop: 14 }}>{c.daily.emptyBody}</VesteText><PrimaryButton variant='ghost' label={c.common.addPiece} onPress={() => goToScreen(router, 42)} style={{ marginTop: 20 }} /></View></ScreenFrame>;
  if (id === 35) {
    const items = LookItems(app.look, app.items); const anchor = app.items.find((item) => item.id === app.look?.anchorId);
    return <ScreenFrame id={35} nav='today' scroll contentStyle={{ paddingBottom: 24 }}><View style={{ flexDirection: 'row', justifyContent: 'flex-end', paddingTop: 12 }}><IconButton icon='heart-outline' label={c.daily.love} onPress={() => { void app.signalLook('love'); }} /></View><LookCanvas items={items} /><EditorialTitle size={32} style={{ marginTop: 24 }}>{anchor?.name ?? c.screens[35][0]}</EditorialTitle><VesteText style={{ color: colors.taupe, marginTop: 6 }}>{c.occasion[app.occasion]} · {app.profile?.city}</VesteText><View style={{ flexDirection: 'row', gap: 8, marginVertical: 20, flexWrap: 'wrap' }}>{items.map((item) => <ChoiceChip key={item.id} label={item.subcategory} onPress={() => goToScreen(router, 40)} />)}</View>{app.look?.reasons.map((reason, index) => <ReasonLine key={reason.code} reason={reason} index={index} />)}<PrimaryButton label={c.common.wearToday} onPress={() => { void app.wearLook().then(() => setMessage(c.common.worn)); }} style={{ marginTop: 22 }} />{message && <Notice>{message}</Notice>}</ScreenFrame>;
  }
  const backgroundItems = LookItems(app.look, app.items);
  return <ScreenFrame id={id} noHeader contentStyle={{ paddingHorizontal: 0 }}><BlurView intensity={34} tint={colors.dark ? 'dark' : 'light'} style={{ flex: 1, padding: 24 }}><LookCanvas items={backgroundItems} /><View style={{ flex: 1 }} /></BlurView>
    {id === 31 && <VesteSheet title={c.daily.whyTitle} onClose={() => router.back()} snapPoints={['78%']}><View style={{ flexDirection: 'row', alignItems: 'baseline', marginBottom: 16 }}><EditorialTitle size={44}>{Math.round(app.look?.score.total ?? 0)}</EditorialTitle><VesteText style={{ color: colors.taupe }}> / 100 · {c.daily.score}</VesteText></View>{app.look?.reasons.map((reason, index) => <ReasonLine key={reason.code} reason={reason} index={index} />)}<View style={{ height: 16 }} />{[[c.closet.colour, app.look?.score.colour ?? 0], [c.plan.dressCode, app.look?.score.occasion ?? 0], [c.daily.quickActions, app.look?.score.rotation ?? 0], [c.profile.colourSeason, app.look?.score.season ?? 0], [c.profile.bodyShape, app.look?.score.silhouette ?? 0]].map(([label, value]) => <ScoreBar key={String(label)} label={String(label)} value={Number(value)} />)}</VesteSheet>}
    {id === 33 && <VesteSheet title={c.daily.feltOff} onClose={() => router.back()} snapPoints={['72%']}><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{c.daily.dislikeOptions.map((option) => <ChoiceChip key={option} label={option} selected={selected === option} onPress={() => setSelected(option)} />)}</View><View style={{ height: 20 }} /><Field label={c.daily.note} value={note} onChangeText={setNote} multiline numberOfLines={3} />{message && <Notice>{message}</Notice>}<PrimaryButton label={c.daily.submit} onPress={() => { void app.signalLook('dismiss', `${selected} ${note}`.trim()).then(() => { setMessage(c.daily.thanks); setTimeout(() => goToScreen(router, 30), 450); }); }} /></VesteSheet>}
    {id === 34 && <VesteSheet title={c.daily.occasion} onClose={() => router.back()} snapPoints={['86%']}><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>{(Object.keys(c.occasion) as Occasion[]).map((occasion) => <Pressable key={occasion} onPress={() => { app.setOccasion(occasion); goToScreen(router, 30); }} style={{ width: '30%', minHeight: 92, borderRadius: 14, borderWidth: 1, borderColor: app.occasion === occasion ? colors.bronze : colors.hairline, backgroundColor: app.occasion === occasion ? colors.bronzeSoft : 'transparent', alignItems: 'center', justifyContent: 'center', gap: 8 }}><Ionicons name={occasionIcons[occasion]} size={23} color={app.occasion === occasion ? colors.bronze : colors.ink} /><VesteText style={{ fontSize: 11 }}>{c.occasion[occasion]}</VesteText></Pressable>)}</View></VesteSheet>}
  </ScreenFrame>;
}
