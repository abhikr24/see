import React from 'react';
import { AccessScreen } from './AccessScreens';
import { IntakeScreen } from './IntakeScreens';
import { DailyScreen } from './DailyScreens';
import { ClosetScreen } from './ClosetScreens';
import { PlanScreen } from './PlanScreens';
import { ProfileScreen } from './ProfileScreens';
import { ThemeScope } from '../theme';
import { ScreenFrame, VesteText } from '../components/ui';

export function ScreenRegistry({ id }: { id: number }) {
  if (id >= 1 && id <= 8) return <AccessScreen id={id} />;
  if (id >= 9 && id <= 29) return <IntakeScreen id={id} />;
  if (id >= 30 && id <= 37) return id === 37 ? <ThemeScope dark><DailyScreen id={id} /></ThemeScope> : <DailyScreen id={id} />;
  if (id >= 38 && id <= 47) return <ClosetScreen id={id} />;
  if (id >= 48 && id <= 55) return <PlanScreen id={id} />;
  if (id >= 56 && id <= 60) return <ProfileScreen id={id} />;
  return <ScreenFrame id={1}><VesteText>404</VesteText></ScreenFrame>;
}
