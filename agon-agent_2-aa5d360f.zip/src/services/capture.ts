import * as Crypto from 'expo-crypto';
import { manipulateAsync, SaveFormat } from 'expo-image-manipulator';
import jpeg from 'jpeg-js';
import type { GarmentColour } from '../data/types';

function bytesFromBase64(value: string): Uint8Array {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' ;
  const clean = value.replace(/=+$/, '');
  const output = new Uint8Array(Math.floor(clean.length * 3 / 4));
  let buffer = 0;
  let bits = 0;
  let offset = 0;
  for (const character of clean) {
    const digit = alphabet.indexOf(character);
    if (digit < 0) continue;
    buffer = (buffer << 6) | digit;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      output[offset++] = (buffer >> bits) & 255;
    }
  }
  return output.subarray(0, offset);
}

const hex = (red: number, green: number, blue: number) => `#${[red, green, blue].map((value) => Math.round(value).toString(16).padStart(2, '0')).join('').toUpperCase()}`;
const colourName = (red: number, green: number, blue: number) => {
  const max = Math.max(red, green, blue);
  const min = Math.min(red, green, blue);
  if (max - min < 22) return max > 205 ? 'Light neutral' : max < 70 ? 'Deep neutral' : 'Mid neutral';
  if (red > green * 1.15 && red > blue * 1.2) return 'Warm earth';
  if (green > red && green > blue) return 'Green';
  if (blue > red && blue > green) return 'Blue';
  return red > blue ? 'Warm tone' : 'Cool tone';
};

export interface CaptureAnalysis { uri: string; sha256: string; colours: [GarmentColour, GarmentColour, GarmentColour]; width: number; height: number }

export async function analyseCapture(sourceUri: string): Promise<CaptureAnalysis> {
  const result = await manipulateAsync(sourceUri, [{ resize: { width: 1200 } }], { compress: 0.78, format: SaveFormat.JPEG, base64: true });
  if (!result.base64) throw new Error('IMAGE_READ_FAILED');
  const bytes = bytesFromBase64(result.base64);
  const digest = await Crypto.digest(Crypto.CryptoDigestAlgorithm.SHA256, bytes);
  const sha256 = Array.from(new Uint8Array(digest)).map((value) => value.toString(16).padStart(2, '0')).join('');
  const decoded = jpeg.decode(bytes, { useTArray: true, maxMemoryUsageInMB: 64 });
  const bins = new Map<string, { red: number; green: number; blue: number; count: number }>();
  const stride = Math.max(4, Math.floor(decoded.data.length / 4 / 24000) * 4);
  for (let index = 0; index + 3 < decoded.data.length; index += stride) {
    const red = decoded.data[index];
    const green = decoded.data[index + 1];
    const blue = decoded.data[index + 2];
    const max = Math.max(red, green, blue);
    const min = Math.min(red, green, blue);
    if (max > 246 && min > 246) continue;
    const key = `${red >> 5}-${green >> 5}-${blue >> 5}`;
    const bin = bins.get(key) ?? { red: 0, green: 0, blue: 0, count: 0 };
    bin.red += red; bin.green += green; bin.blue += blue; bin.count += 1;
    bins.set(key, bin);
  }
  const dominant = [...bins.values()].sort((a, b) => b.count - a.count).slice(0, 3);
  const fallback = [{ red: 140, green: 128, blue: 120, count: 1 }, { red: 200, green: 190, blue: 175, count: 1 }, { red: 50, green: 45, blue: 40, count: 1 }];
  const colours = [...dominant, ...fallback].slice(0, 3).map((entry): GarmentColour => {
    const red = entry.red / entry.count; const green = entry.green / entry.count; const blue = entry.blue / entry.count;
    return { name: colourName(red, green, blue), hex: hex(red, green, blue), undertone: red > blue + 12 ? 'warm' : blue > red + 12 ? 'cool' : 'neutral' };
  }) as [GarmentColour, GarmentColour, GarmentColour];
  return { uri: result.uri, sha256, colours, width: result.width, height: result.height };
}
