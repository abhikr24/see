import type { Item } from '../data/types';
import type { CaptureAnalysis } from './capture';

export interface DetectionDraft { item: Item; confidence: number; accepted: boolean }
export interface CaptureSession { analysis?: CaptureAnalysis; drafts: DetectionDraft[] }
let session: CaptureSession | undefined;
let editingDraft: Item | undefined;
export const setCaptureSession = (value: CaptureSession | undefined) => { session = value; };
export const getCaptureSession = () => session;
export const setEditingDraft = (item: Item | undefined) => { editingDraft = item; };
export const getEditingDraft = () => editingDraft;
