import type { Category, LifecycleState } from '../data/types';
export interface ClosetFilter { category?: Category; season?: string; lifecycle?: LifecycleState; minimumFormality: number }
let filter: ClosetFilter = { minimumFormality: 0 };
export const getClosetFilter = () => filter;
export const setClosetFilter = (value: ClosetFilter) => { filter = value; };
