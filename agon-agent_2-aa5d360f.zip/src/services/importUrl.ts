export interface ImportedProduct { title: string; imageUri?: string; brand?: string; price?: number; sourceUrl: string }

const decode = (value: string) => value.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
const meta = (html: string, property: string) => {
  const escaped = property.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const expression = new RegExp(`<meta[^>]+(?:property|name)=[\"']${escaped}[\"'][^>]+content=[\"']([^\"']+)[\"'][^>]*>|<meta[^>]+content=[\"']([^\"']+)[\"'][^>]+(?:property|name)=[\"']${escaped}[\"'][^>]*>`, 'i');
  const match = html.match(expression);
  return match ? decode(match[1] || match[2] || '') : '';
};

export async function importProductUrl(sourceUrl: string): Promise<ImportedProduct> {
  const url = new URL(sourceUrl);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('INVALID_URL');
  const response = await fetch(url, { headers: { Accept: 'text/html' } });
  if (!response.ok) throw new Error('URL_READ_FAILED');
  const html = await response.text();
  const title = meta(html, 'og:title') || meta(html, 'twitter:title') || decode(html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1] ?? '');
  if (!title) throw new Error('URL_DETAILS_NOT_FOUND');
  const imageUri = meta(html, 'og:image') || undefined;
  const brand = meta(html, 'product:brand') || meta(html, 'brand') || undefined;
  const rawPrice = meta(html, 'product:price:amount') || meta(html, 'price');
  const price = rawPrice ? Number(rawPrice.replace(/[^0-9.]/g, '')) : undefined;
  return { title, imageUri, brand, price: price && Number.isFinite(price) ? price : undefined, sourceUrl: url.toString() };
}
