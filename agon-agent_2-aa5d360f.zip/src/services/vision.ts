import { z } from 'zod';
import { environment } from '../data/environment';

const suggestionSchema = z.object({
  name: z.string().optional(), category: z.string().optional(), subcategory: z.string().optional(), material: z.string().optional(), care: z.string().optional(), confidence: z.number().min(0).max(1).optional(),
});
export type VisionSuggestion = z.infer<typeof suggestionSchema>;
const cache = new Map<string, VisionSuggestion[]>();

export async function suggestGarments(sha256: string, base64Jpeg?: string): Promise<VisionSuggestion[]> {
  const cached = cache.get(sha256);
  if (cached) return cached;
  if (!environment.visionServiceUrl) throw new Error('VISION_MANUAL_FALLBACK');
  const response = await fetch(environment.visionServiceUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ sha256, image: base64Jpeg, operation: 'garment-tags', backgroundRemoval: 'u2net' }) });
  if (!response.ok) throw new Error('VISION_UNAVAILABLE');
  const parsed = z.object({ suggestions: z.array(suggestionSchema) }).parse(await response.json());
  cache.set(sha256, parsed.suggestions);
  return parsed.suggestions;
}

export async function suggestCareLabel(sha256: string, base64Jpeg?: string): Promise<VisionSuggestion> {
  if (!environment.visionServiceUrl) throw new Error('OCR_MANUAL_FALLBACK');
  const response = await fetch(environment.visionServiceUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sha256, image: base64Jpeg, operation: 'care-label-ocr' }) });
  if (!response.ok) throw new Error('OCR_UNAVAILABLE');
  const result = suggestionSchema.parse(await response.json());
  cache.set(`care:${sha256}`, [result]);
  return result;
}
