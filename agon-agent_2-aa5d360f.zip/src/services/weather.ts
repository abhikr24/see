import { environment } from '../data/environment';
import type { Weather } from '../data/types';

export interface WeatherProvider { getWeather(city: string, date?: Date): Promise<Weather> }

const seasonalWeather = (city: string, date: Date): Weather => {
  const month = date.getMonth() + 1;
  const mumbai = /mumbai|pune|chennai|kochi|goa/i.test(city);
  const monsoon = mumbai && month >= 6 && month <= 9;
  const winter = month === 12 || month <= 2;
  return {
    temperatureC: winter ? (mumbai ? 24 : 14) : monsoon ? 27 : mumbai ? 31 : 29,
    humidity: monsoon ? 84 : mumbai ? 68 : 46,
    precipitationChance: monsoon ? 72 : winter ? 8 : 18,
    condition: monsoon ? 'Monsoon showers' : winter ? 'Clear and mild' : mumbai ? 'Warm and humid' : 'Clear',
    source: 'seasonal',
  };
};

export class SeasonalWeatherProvider implements WeatherProvider {
  async getWeather(city: string, date = new Date()) { return seasonalWeather(city, date); }
}

export class KeyedWeatherProvider implements WeatherProvider {
  constructor(private endpoint: string, private key: string) {}
  async getWeather(city: string, date = new Date()): Promise<Weather> {
    try {
      const url = new URL(this.endpoint);
      url.searchParams.set('q', city);
      url.searchParams.set('apikey', this.key);
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error('WEATHER_UNAVAILABLE');
      const body = await response.json() as { current?: { temperature_2m?: number; relative_humidity_2m?: number; precipitation_probability?: number; weather_code?: number } };
      if (typeof body.current?.temperature_2m !== 'number') throw new Error('WEATHER_INVALID');
      return { temperatureC: body.current.temperature_2m, humidity: body.current.relative_humidity_2m ?? 50, precipitationChance: body.current.precipitation_probability ?? 0, condition: 'Live forecast', source: 'provider' };
    } catch {
      return seasonalWeather(city, date);
    }
  }
}

export const weatherProvider: WeatherProvider = environment.weatherProviderUrl && environment.weatherApiKey
  ? new KeyedWeatherProvider(environment.weatherProviderUrl, environment.weatherApiKey)
  : new SeasonalWeatherProvider();
