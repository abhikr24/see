import React, { createContext, useContext, useMemo } from 'react';
import { useColorScheme } from 'react-native';
import type { ThemePreference } from '../data/types';

export interface Palette {
  paper: string;
  paperRaised: string;
  paperSubtle: string;
  ink: string;
  inkSoft: string;
  bronze: string;
  bronzeSoft: string;
  taupe: string;
  olive: string;
  hairline: string;
  inverse: string;
  danger: string;
  scrim: string;
  dark: boolean;
}

const light: Palette = {
  paper: '#FAF8F5', paperRaised: '#FFFFFF', paperSubtle: '#F0EBE4', ink: '#14110F', inkSoft: '#453E38',
  bronze: '#A9793F', bronzeSoft: '#E9DDCE', taupe: '#8C8078', olive: '#5B6F5E', hairline: '#DCD4CA',
  inverse: '#FAF8F5', danger: '#9B453B', scrim: 'rgba(20,17,15,0.32)', dark: false,
};
const dark: Palette = {
  paper: '#14110F', paperRaised: '#1E1A17', paperSubtle: '#29231F', ink: '#FAF8F5', inkSoft: '#D8D0C8',
  bronze: '#C79A64', bronzeSoft: '#433224', taupe: '#A99C92', olive: '#91AA95', hairline: '#3A332E',
  inverse: '#14110F', danger: '#E39588', scrim: 'rgba(0,0,0,0.58)', dark: true,
};

interface ThemeValue { colors: Palette; preference: ThemePreference; setPreference: (value: ThemePreference) => void }
const ThemeContext = createContext<ThemeValue>({ colors: light, preference: 'light', setPreference: () => undefined });

export function VesteThemeProvider({ preference, setPreference, children }: { preference: ThemePreference; setPreference: (value: ThemePreference) => void; children: React.ReactNode }) {
  const system = useColorScheme();
  const colors = preference === 'dark' || (preference === 'system' && system === 'dark') ? dark : light;
  const value = useMemo(() => ({ colors, preference, setPreference }), [colors, preference, setPreference]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function ThemeScope({ dark: forceDark, children }: { dark?: boolean; children: React.ReactNode }) {
  const parent = useContext(ThemeContext);
  const value = useMemo(() => ({ ...parent, colors: forceDark ? dark : light }), [parent, forceDark]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);
export const serif = 'Georgia';
export const sans = 'System';
export const radii = { small: 12, medium: 16, large: 20 };
export const motion = { duration: 240, easing: [0.22, 1, 0.36, 1] as const };
