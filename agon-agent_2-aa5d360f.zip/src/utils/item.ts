import type { Item, Profile } from '../data/types';
import type { CaptureAnalysis } from '../services/capture';

export function blankItem(profile: Profile, analysis?: CaptureAnalysis): Item {
  return {
    id: `garment-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, userId: profile.id, name: '', category: 'top', subcategory: 'T-shirt',
    colours: analysis?.colours ?? [{ name: '', hex: '#8C8078', undertone: 'neutral' }, { name: '', hex: '#C8B79E', undertone: 'neutral' }, { name: '', hex: '#353431', undertone: 'neutral' }],
    pattern: 'Solid', texture: '', material: '', care: '', warmth: 1, formality: 2, seasons: [], occasions: ['daily'], fit: 'True to size', silhouette: 'Straight', neckline: '', sleeve: '', rise: '', hem: '', brand: '', size: '', price: 0, purchaseDate: new Date().toISOString().slice(0, 10), lifecycle: 'clean', condition: 'Excellent', location: 'Wardrobe · rail', wearCount: 0, favourite: false, imageUri: analysis?.uri, imageSha256: analysis?.sha256, autoTagged: Boolean(analysis), createdAt: new Date().toISOString(),
  };
}

export const costPerWear = (item: Item) => item.wearCount > 0 ? Math.round(item.price / item.wearCount) : item.price;
