const { ts, fs, path, walk, roleOf, parse, isCAccess } = require('./lib.cjs');
const DRY = process.argv.includes('--dry');
const SKIP = [/src\/lib\/theme\.ts$/, /src\/lib\/motion\.ts$/, /src\/lib\/ThemeProvider\.tsx$/, /src\/core\/contracts\//, /src\/adapters\//, /src\/backends\//, /src\/core\/hooks\/cache\.ts$/, /src\/components\/ui\/Pressable\.tsx$/, /src\/components\/ui\/Refresh\.tsx$/, /src\/components\/ui\/Overlay\.tsx$/];
const files = [...walk('src'), ...walk('app')].filter((f) => !SKIP.some((r) => r.test(f)));
const TONES = new Set(['teal', 'danger', 'accent', 'warning', 'success']);
const ICON_TAG = /(Icon|Ionicons|MaterialIcons|FontAwesome|Feather)$/;
const report = { unknown: [], calledComponents: [], primitives: [], shadow: [], passive: [], flexPress: [] };
let changed = 0;

function componentName(fn) {
  if (fn.name && ts.isIdentifier(fn.name)) return fn.name.text;
  let p = fn.parent;
  // memo(function X) / forwardRef((props, ref) => ...) assigned to a variable
  while (p && (ts.isCallExpression(p) || ts.isParenthesizedExpression(p) || ts.isAsExpression(p))) p = p.parent;
  if (p && ts.isVariableDeclaration(p) && ts.isIdentifier(p.name)) return p.name.text;
  return null;
}
const isComponentish = (name) => !!name && (/^[A-Z]/.test(name) || /^use[A-Z]/.test(name));
function nearestComponent(node) {
  let f = node.parent; let found = null;
  while (f) {
    if (ts.isFunctionDeclaration(f) || ts.isFunctionExpression(f) || ts.isArrowFunction(f)) { if (isComponentish(componentName(f))) found = found ?? f; }
    if (ts.isClassDeclaration(f)) return 'class';
    f = f.parent;
  }
  return found;
}
function anyFunction(node) { let f = node.parent; while (f && !ts.isFunctionLike(f)) f = f.parent; return f; }
function containsJsx(fn) { let has = false; (function v(n) { if (has) return; if (ts.isJsxElement(n) || ts.isJsxSelfClosingElement(n) || ts.isJsxFragment(n)) { has = true; return; } ts.forEachChild(n, v); })(fn); return has; }

for (const file of files) {
  const src = fs.readFileSync(file, 'utf8');
  const sf = parse(file);
  const edits = [];
  const line = (n) => sf.getLineAndCharacterOfPosition(n.getStart()).line + 1;
  const themeImport = sf.statements.find((s) => ts.isImportDeclaration(s) && /lib\/theme'?$/.test(s.moduleSpecifier.getText().replace(/['"]/g, '')));
  const importsC = !!themeImport && /\bC\b/.test(themeImport.importClause?.getText() ?? '');
  const importsToneOrShadow = !!themeImport && /\b(TONE|SHADOW)\b/.test(themeImport.importClause?.getText() ?? '');
  const isUi = /src\/components\/ui\//.test(file);

  // names of capitalised functions that are also called as plain functions
  const called = new Set();
  (function v(n) { if (ts.isCallExpression(n) && ts.isIdentifier(n.expression) && /^[A-Z]/.test(n.expression.text)) called.add(n.expression.text); ts.forEachChild(n, v); })(sf);

  const needHook = new Map(); // fn -> true
  const moduleDecls = new Set();
  let keepCImport = false;
  let usesThemed = false;

  if (importsC) {
    (function visit(n) {
      if (isCAccess(n)) {
        const tok = n.name.text; const r = roleOf(n);
        // A. role remap
        let next = tok;
        const attrEl = (() => { let p = n.parent; while (p && !ts.isJsxAttribute(p) && !ts.isPropertyAssignment(p) && !ts.isVariableDeclaration(p)) p = p.parent; return p && ts.isJsxAttribute(p) ? p.parent.parent : null; })();
        const onIcon = attrEl && ICON_TAG.test(attrEl.tagName.getText());
        if (r.role === 'fg') {
          if (tok === 'surface') next = 'onFill';
          else if (tok === 'primary') next = 'primaryInk';
          else if (TONES.has(tok) && !onIcon) next = tok + 'Ink';
        } else if (r.role === 'border') {
          if (tok === 'primary') next = 'primaryInk';
        } else if (r.role === 'unknown' || r.role === 'cond') {
          if (tok === 'primary' || tok === 'surface' || TONES.has(tok)) report.unknown.push(`${file}:${line(n)} C.${tok} (${r.via})`);
        }
        if (next !== tok) edits.push({ pos: n.name.getStart(), end: n.name.getEnd(), text: next });
        // B/C. where does it live
        const comp = nearestComponent(n);
        if (comp === 'class') keepCImport = true;
        else if (comp) {
          const name = componentName(comp);
          if (called.has(name)) { keepCImport = true; report.calledComponents.push(`${file}:${line(comp)} ${name}`); }
          else needHook.set(comp, true);
        } else if (!anyFunction(n)) {
          let d = n.parent; while (d && !(ts.isVariableDeclaration(d) && d.parent.parent.parent === sf)) d = d.parent;
          if (d && d.initializer) moduleDecls.add(d); else { keepCImport = true; report.primitives.push(`${file}:${line(n)} module-level C.${tok} not in a const`); }
          keepCImport = true;
        } else keepCImport = true;
      }
      ts.forEachChild(n, visit);
    })(sf);
  }

  // C. wrap module-level tables
  for (const d of moduleDecls) {
    const init = d.initializer;
    const inner = ts.isAsExpression(init) || ts.isSatisfiesExpression?.(init) ? init.expression : init;
    if (ts.isObjectLiteralExpression(inner) || ts.isArrayLiteralExpression(inner) || ts.isCallExpression(inner)) {
      if (ts.isCallExpression(inner) && inner.expression.getText() === 'themed') continue;
      edits.push({ pos: init.getStart(), end: init.getStart(), text: 'themed(() => (' });
      edits.push({ pos: init.getEnd(), end: init.getEnd(), text: '))' });
      usesThemed = true;
    } else report.primitives.push(`${file}:${line(d)} const ${d.name.getText()} = ${init.getText().slice(0, 50)}`);
  }

  // B. hook insertion (also components that only read themed tables / TONE / SHADOW)
  if (themeImport && (usesThemed || importsToneOrShadow || moduleDecls.size)) {
    (function v(n) {
      if ((ts.isFunctionDeclaration(n) || ts.isFunctionExpression(n) || ts.isArrowFunction(n)) && !needHook.has(n)) {
        const name = componentName(n);
        if (isComponentish(name) && /^[A-Z]/.test(name) && !called.has(name) && containsJsx(n) && !nearestComponent(n)) needHook.set(n, false);
      }
      ts.forEachChild(n, v);
    })(sf);
  }
  let hookAdded = false;
  for (const [fn, wantsC] of needHook) {
    const body = fn.body; if (!body) continue;
    const stmt = wantsC ? 'const C = useColors();' : 'useColors();';
    if (ts.isBlock(body)) {
      const text = body.getText();
      if (/const C = useColors\(\)/.test(text.slice(0, 400)) || (!wantsC && /useColors\(\)/.test(text.slice(0, 400)))) continue;
      const indent = (() => { const first = body.statements[0]; if (!first) return '  '; const lc = sf.getLineAndCharacterOfPosition(first.getStart()); return ' '.repeat(lc.character); })();
      const sameLine = body.statements[0] && sf.getLineAndCharacterOfPosition(body.statements[0].getStart()).line === sf.getLineAndCharacterOfPosition(body.getStart()).line;
      edits.push({ pos: body.getStart() + 1, end: body.getStart() + 1, text: sameLine ? ` ${stmt}` : `\n${indent}${stmt}` });
    } else {
      // expression-bodied arrow: => expr   →   => { const C = useColors(); return expr; }
      let s = body.getStart(), e = body.getEnd();
      edits.push({ pos: s, end: s, text: `{ ${stmt} return ` });
      edits.push({ pos: e, end: e, text: `; }` });
    }
    hookAdded = true;
  }

  // D. SHADOW spreads
  (function v(n) {
    if (ts.isIdentifier(n) && n.text === 'SHADOW' && !ts.isImportSpecifier(n.parent)) {
      if (ts.isSpreadAssignment(n.parent)) edits.push({ pos: n.getEnd(), end: n.getEnd(), text: '.raised' });
      else if (ts.isPropertyAccessExpression(n.parent) && n.parent.expression === n && /^(raised|overlay|flat)$/.test(n.parent.name.text)) { /* already scaled */ }
      else report.shadow.push(`${file}:${line(n)} ${n.parent.getText().slice(0, 60)}`);
    }
    ts.forEachChild(n, v);
  })(sf);

  // E. Pressable + F. RefreshControl
  let pressableSwap = false, refreshSwap = false, refreshNeeded = false;
  const rnImport = sf.statements.find((s) => ts.isImportDeclaration(s) && s.moduleSpecifier.getText().replace(/['"]/g, '') === 'react-native');
  const rnNames = rnImport?.importClause?.namedBindings && ts.isNamedImports(rnImport.importClause.namedBindings) ? rnImport.importClause.namedBindings.elements.map((e) => e.getText()) : [];
  if (rnNames.includes('Pressable')) pressableSwap = true;
  if (rnNames.includes('RefreshControl')) refreshSwap = true;
  (function v(n) {
    if (ts.isJsxOpeningElement(n) || ts.isJsxSelfClosingElement(n)) {
      const tag = n.tagName.getText();
      const attrs = n.attributes.properties.filter(ts.isJsxAttribute);
      const get = (name) => attrs.find((a) => a.name.getText() === name);
      if (tag === 'Pressable' && pressableSwap) {
        const onPress = get('onPress'); const style = get('style');
        const pressText = onPress?.initializer?.getText() ?? '';
        const noop = /^\{\s*\(\s*\w*\s*\)\s*=>\s*(undefined|null|void 0|\{\s*\}|\w+\.stopPropagation\(\))\s*\}$/.test(pressText);
        const styleText = style?.initializer?.getText() ?? '';
        const scrim = /C\.scrim|rgba\(|[0-9A-Fa-f]{6}(66|80|99|73)'/.test(styleText) && /flex: 1|absoluteFill/.test(styleText);
        if ((noop || scrim) && !get('scale')) {
          edits.push({ pos: n.tagName.getEnd(), end: n.tagName.getEnd(), text: ' haptic={false} scale={false}' });
          report.passive.push(`${file}:${line(n)} ${noop ? 'noop' : 'scrim'}`);
        } else if (/flex: 1/.test(styleText) && /justifyContent: '(flex-end|center)'/.test(styleText) && /backgroundColor/.test(styleText)) report.flexPress.push(`${file}:${line(n)} ${styleText.slice(0, 80)}`);
      }
      if (tag === 'RefreshControl' && refreshSwap) {
        edits.push({ pos: n.tagName.getStart(), end: n.tagName.getEnd(), text: 'Refresh' });
        for (const a of attrs) if (/^(tintColor|colors|progressBackgroundColor)$/.test(a.name.getText())) edits.push({ pos: a.getFullStart(), end: a.getEnd(), text: '' });
      }
      const refreshing = get('refreshing'), onRefresh = get('onRefresh');
      if (tag !== 'RefreshControl' && tag !== 'Refresh' && refreshing && onRefresh && !get('refreshControl')) {
        edits.push({ pos: refreshing.getFullStart(), end: refreshing.getEnd(), text: '' });
        edits.push({ pos: onRefresh.getStart(), end: onRefresh.getEnd(), text: `refreshControl={<Refresh refreshing=${refreshing.initializer.getText()} onRefresh=${onRefresh.initializer.getText()} />}` });
        refreshNeeded = true;
      }
    }
    if (ts.isJsxClosingElement(n) && n.tagName.getText() === 'RefreshControl' && refreshSwap) edits.push({ pos: n.tagName.getStart(), end: n.tagName.getEnd(), text: 'Refresh' });
    ts.forEachChild(n, v);
  })(sf);

  if (!edits.length && !pressableSwap && !refreshSwap) continue;
  // An edit that sits inside a removed range goes with it.
  const removals = edits.filter((e) => e.text === '' && e.end > e.pos);
  const live = edits.filter((e) => e.text === '' || !removals.some((r) => e.pos >= r.pos && e.end <= r.end));
  edits.length = 0; edits.push(...live);
  edits.sort((a, b) => b.pos - a.pos || b.end - a.end);
  let out = src;
  for (const e of edits) out = out.slice(0, e.pos) + e.text + out.slice(e.end);

  // imports
  const fixNamed = (text, mod, mutate) => text.replace(new RegExp(`import\\s*(type\\s*)?\\{([^}]*)\\}\\s*from\\s*'${mod}';`), (m, t, names) => {
    if (t) return m;
    let list = names.split(',').map((x) => x.trim()).filter(Boolean);
    list = mutate(list);
    return list.length ? (names.includes('\n') ? `import {\n  ${list.join(',\n  ')},\n} from '${mod}';` : `import { ${list.join(', ')} } from '${mod}';`) : '';
  });
  if (themeImport) {
    const mod = themeImport.moduleSpecifier.getText().replace(/['"]/g, '').replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&');
    out = fixNamed(out, mod, (list) => {
      if (hookAdded && !list.includes('useColors')) list.push('useColors');
      if (usesThemed && !list.includes('themed')) list.push('themed');
      if (hookAdded && importsC && !keepCImport) list = list.filter((x) => x !== 'C');
      return list;
    });
  }
  const uiPath = (name) => (isUi ? `./${name}` : `@/components/ui/${name}`);
  const addImport = (text, stmt) => { const m = [...text.matchAll(/^import[\s\S]*?from\s*'[^']+';\s*$/gm)]; const last = m[m.length - 1]; const at = last ? last.index + last[0].length : 0; return text.slice(0, at) + (at ? '\n' : '') + stmt + (at ? '' : '\n') + text.slice(at); };
  if (pressableSwap) { out = fixNamed(out, 'react-native', (list) => list.filter((x) => x !== 'Pressable')); out = addImport(out, `import { Pressable } from '${uiPath('Pressable')}';`); }
  if (refreshSwap) out = fixNamed(out, 'react-native', (list) => list.filter((x) => x !== 'RefreshControl'));
  if (refreshSwap || refreshNeeded) out = addImport(out, `import { Refresh } from '${uiPath('Refresh')}';`);
  out = out.replace(/^import \{\s*\} from 'react-native';\n/m, '');
  if (out !== src) { changed++; if (!DRY) fs.writeFileSync(file, out); }
}
console.log('files changed:', changed);
for (const [k, v] of Object.entries(report)) { console.log(`\n== ${k} (${v.length})`); v.forEach((x) => console.log('  ' + x)); }
