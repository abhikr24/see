const { ts, walk, roleOf, parse, isCAccess, enclosingFn } = require('./lib.cjs');
const files = [...walk('src'), ...walk('app')].filter((f) => !f.endsWith('lib/theme.ts'));
const census = {}; const unknown = {}; let moduleLevel = [];
for (const f of files) {
  const sf = parse(f);
  (function visit(n) {
    if (isCAccess(n)) {
      const tok = n.name.text; const r = roleOf(n);
      census[tok] ??= { fg: 0, bg: 0, border: 0, unknown: 0, cond: 0 };
      census[tok][r.role]++;
      if (r.role === 'unknown') { unknown[r.via] = (unknown[r.via] || 0) + 1; }
      if (!enclosingFn(n)) moduleLevel.push(`${f}:${sf.getLineAndCharacterOfPosition(n.getStart()).line + 1} C.${tok}`);
    }
    ts.forEachChild(n, visit);
  })(sf);
}
console.log('token'.padEnd(16), 'fg', 'bg', 'border', 'unknown');
for (const [k, v] of Object.entries(census).sort((a, b) => (b[1].fg + b[1].bg + b[1].border + b[1].unknown) - (a[1].fg + a[1].bg + a[1].border + a[1].unknown))) console.log(k.padEnd(16), String(v.fg).padStart(4), String(v.bg).padStart(4), String(v.border).padStart(4), String(v.unknown).padStart(4));
console.log('\nunknown vias:'); for (const [k, v] of Object.entries(unknown).sort((a, b) => b[1] - a[1]).slice(0, 60)) console.log(String(v).padStart(4), k);
console.log('\nmodule-level C uses:', moduleLevel.length); const byFile = {}; moduleLevel.forEach((m) => { const f = m.split(':')[0]; byFile[f] = (byFile[f] || 0) + 1; }); for (const [k, v] of Object.entries(byFile).sort((a, b) => b[1] - a[1])) console.log(String(v).padStart(4), k);
