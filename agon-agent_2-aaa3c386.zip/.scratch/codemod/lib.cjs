const ts = require('typescript');
const fs = require('fs');
const path = require('path');
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(tsx|ts)$/.test(e.name)) out.push(p);
  }
  return out;
}
const FG_NAMES = /^(color|c|tintColor|textDecorationColor|placeholderTextColor|selectionColor|cursorColor|fg|ink|iconColor|textColor|stroke|labelColor|activeTintColor|foreground|text|icon|tint|accent|handleColor|dotColor|barColor|lineColor|dataPointsColor|frontColor|activeColor|inactiveColor|thumbColor)$/i;
const BG_NAMES = /^(backgroundColor|bg|background|fill|soft|tintBg|surface|trackColor|backgroundGradientFrom|bgColor|wash|canvas)$/i;
const BORDER_NAMES = /^(border.*Color|outlineColor|shadowColor|hairline|ring|divider|rulesColor|xAxisColor|yAxisColor)$/i;
function nameRole(n) {
  if (FG_NAMES.test(n)) return 'fg';
  if (BORDER_NAMES.test(n)) return 'border';
  if (BG_NAMES.test(n)) return 'bg';
  if (/color$/i.test(n)) return /(bg|background|fill|track)/i.test(n) ? 'bg' : 'fg';
  if (/(bg|background|fill)$/i.test(n)) return 'bg';
  if (/(fg|ink|text|tint|tone)$/i.test(n)) return 'fg';
  return null;
}
/** Role of an expression node by the slot it finally lands in. */
function roleOf(node) {
  let cur = node;
  for (let i = 0; i < 12; i++) {
    const p = cur.parent;
    if (!p) return { role: 'unknown', via: 'root' };
    if (ts.isParenthesizedExpression(p) || ts.isAsExpression(p) || ts.isNonNullExpression(p) || ts.isSatisfiesExpression?.(p)) { cur = p; continue; }
    if (ts.isConditionalExpression(p)) { if (p.condition === cur) return { role: 'cond', via: 'condition' }; cur = p; continue; }
    if (ts.isBinaryExpression(p)) {
      const k = p.operatorToken.kind;
      if (k === ts.SyntaxKind.QuestionQuestionToken || k === ts.SyntaxKind.BarBarToken || k === ts.SyntaxKind.AmpersandAmpersandToken) { cur = p; continue; }
      if (k === ts.SyntaxKind.EqualsEqualsEqualsToken || k === ts.SyntaxKind.ExclamationEqualsEqualsToken) return { role: 'cond', via: 'compare' };
      return { role: 'unknown', via: 'binary' };
    }
    if (ts.isPropertyAssignment(p)) { const n = p.name.getText().replace(/['"]/g, ''); return { role: nameRole(n) ?? 'unknown', via: 'prop:' + n }; }
    if (ts.isJsxExpression(p) && p.parent && ts.isJsxAttribute(p.parent)) { const n = p.parent.name.getText(); return { role: nameRole(n) ?? 'unknown', via: 'attr:' + n }; }
    if (ts.isVariableDeclaration(p)) { const n = p.name.getText(); return { role: nameRole(n) ?? 'unknown', via: 'var:' + n }; }
    if (ts.isParameter(p)) { const n = p.name.getText(); return { role: nameRole(n) ?? 'unknown', via: 'param:' + n }; }
    if (ts.isArrayLiteralExpression(p)) { cur = p; continue; }
    if (ts.isReturnStatement(p) || ts.isArrowFunction(p)) {
      // returned from a function: use the function's name if any
      let f = p; while (f && !ts.isFunctionLike(f)) f = f.parent;
      let n = f && f.name ? f.name.getText() : (f && f.parent && ts.isVariableDeclaration(f.parent) ? f.parent.name.getText() : null);
      if (f && f.parent && ts.isPropertyAssignment(f.parent)) n = f.parent.name.getText();
      if (f && f.parent && ts.isJsxExpression(f.parent)) return { role: 'unknown', via: 'jsxfn' };
      return { role: (n && nameRole(n)) ?? 'unknown', via: 'return:' + n };
    }
    if (ts.isCallExpression(p)) return { role: 'unknown', via: 'call:' + p.expression.getText().slice(0, 30) };
    if (ts.isTemplateSpan(p)) return { role: 'unknown', via: 'template' };
    if (ts.isShorthandPropertyAssignment(p)) return { role: 'unknown', via: 'shorthand' };
    return { role: 'unknown', via: ts.SyntaxKind[p.kind] };
  }
  return { role: 'unknown', via: 'deep' };
}
function parse(file) { return ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, file.endsWith('x') ? ts.ScriptKind.TSX : ts.ScriptKind.TS); }
function isCAccess(node) { return ts.isPropertyAccessExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'C'; }
function enclosingFn(node) { let f = node.parent; while (f && !ts.isFunctionLike(f)) f = f.parent; return f; }
module.exports = { ts, fs, path, walk, roleOf, parse, isCAccess, enclosingFn, nameRole };
