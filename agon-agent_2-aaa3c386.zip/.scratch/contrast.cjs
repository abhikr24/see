// tiny WCAG helper for tuning tokens: node .scratch/contrast.cjs fg bg [fg bg ...]
function lum(hex) { const h = hex.replace('#', ''); const v = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; }
function ratio(a, b) { const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m); return (x + 0.05) / (y + 0.05); }
module.exports = { ratio, lum };
if (require.main === module) { const a = process.argv.slice(2); for (let i = 0; i < a.length; i += 2) console.log(a[i], 'on', a[i + 1], ratio(a[i], a[i + 1]).toFixed(2)); }
