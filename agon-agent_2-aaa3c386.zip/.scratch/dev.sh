#!/usr/bin/env bash
# usage: dev.sh restart|stop  — controls the background `npx expo start --web` by pid file.
cd "$(dirname "$0")/.."
if [ -f .scratch/dev.pid ]; then kill -- -"$(cat .scratch/dev.pid)" 2>/dev/null; kill "$(cat .scratch/dev.pid)" 2>/dev/null; rm -f .scratch/dev.pid; sleep 2; fi
fuser -k 8081/tcp 2>/dev/null; sleep 1
[ "$1" = stop ] && exit 0
rm -f /tmp/expo.log
CI=false BROWSER=none setsid nohup timeout 3000 npx expo start --web --port 8081 -c > /tmp/expo.log 2>&1 < /dev/null &
echo $! > .scratch/dev.pid
for i in $(seq 1 120); do code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://localhost:8081/login); [ "$code" = 200 ] && break; sleep 2; done
echo "dev server: HTTP $code"
