const { chromium } = require('@playwright/test');
const http = require('node:http'); const fs = require('node:fs'); const path = require('node:path');
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => { let f = path.join(root, decodeURIComponent(req.url.split('?')[0])); if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(root, 'index.html'); res.setHeader('Content-Type', types[path.extname(f)] || 'application/octet-stream'); fs.createReadStream(f).pipe(res); }).listen(8132);
const BASE = 'http://localhost:8132';
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const page = await (await browser.newContext({ viewport: { width: 400, height: 860 } })).newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message));
  const step = async (name, fn) => { try { await fn(); console.log('PASS', name); } catch (e) { console.log('FAIL', name, '::', e.message.split('\n')[0]); await page.screenshot({ path: `.scratch/shots/flow-fail-${name.replace(/\W+/g, '_')}.png` }); } };
  await page.goto(`${BASE}/`);
  const skip = page.getByText('Skip', { exact: true }); await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {}); if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test'); await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click(); await page.getByText('Enter code', { exact: true }).waitFor({ timeout: 30000 });
  await page.locator('input:visible').first().click(); await page.keyboard.type('123456', { delay: 60 }); await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await page.locator('[role="tab"]').first().waitFor({ timeout: 30000 }); await page.waitForTimeout(1500);
  await step('students: swipe actions are real buttons', async () => {
    await page.getByRole('tab', { name: /Students/ }).click(); await page.waitForTimeout(1500);
    const n = await page.getByRole('button', { name: /^Call the parent of / }).count(); const m = await page.getByRole('button', { name: /^Remind .* about the fee$/ }).count();
    if (!n || !m) throw new Error(`call=${n} remind=${m}`); console.log(`     call buttons ${n}, remind buttons ${m}`);
  });
  await step('notices: swipe delete -> undo bar -> undo', async () => {
    await page.getByRole('tab', { name: /More/ }).click(); await page.waitForTimeout(1000);
    await page.getByText('Notices', { exact: true }).first().click(); await page.waitForTimeout(2000);
    const del = page.getByRole('button', { name: /^Delete the notice / }).first();
    const label = await del.getAttribute('aria-label'); const title = label.replace('Delete the notice ', '');
    await del.focus(); await page.keyboard.press('Enter');
    await page.getByText('Notice removed', { exact: true }).waitFor({ timeout: 8000 });
    if (await page.getByText(title, { exact: true }).count()) throw new Error('notice still listed after delete');
    await page.screenshot({ path: '.scratch/shots/flow-undo-bar.png' });
    await page.getByRole('button', { name: /^Undo deleting the notice/ }).click();
    await page.getByText(title, { exact: true }).first().waitFor({ timeout: 8000 });
    console.log(`     deleted and restored "${title}"`);
  });
  await step('settings: Dark switch repaints the app', async () => {
    await page.getByRole('tab', { name: /More/ }).click(); await page.waitForTimeout(1000);
    await page.getByText('Settings', { exact: true }).first().click(); await page.waitForTimeout(2000);
    const before = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    await page.getByRole('tab', { name: 'Dark', exact: true }).click(); await page.waitForTimeout(800);
    const after = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    await page.screenshot({ path: '.scratch/shots/flow-settings-dark.png' });
    if (before === after) throw new Error('background did not change'); console.log(`     body ${before} -> ${after}`);
  });
  console.log('page errors:', errors.length); errors.slice(0, 5).forEach((e) => console.log('  ', e.slice(0, 200)));
  await browser.close(); server.close();
})();
