// Reproduction driver: /login → demo pill → Sign in → 123456 → Verify, then watch the shell.
const { chromium } = require('@playwright/test');
const BASE = process.env.BASE || 'http://localhost:8081';
const role = process.env.ROLE || 'Owner';
const watch = Number(process.env.WATCH || 10000);
const runs = Number(process.env.RUNS || 1);

async function login(page, pill) {
  await page.goto(`${BASE}/login`, { timeout: 240000 });
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 90000 });
  if (process.env.KILL_OVERLAY) await page.evaluate(() => { const kill = () => ['error-overlay','error-toast'].forEach((id) => document.getElementById(id)?.remove()); kill(); setInterval(kill, 100); });
  await page.getByText(pill, { exact: true }).click();
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 40 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
}
async function snapshot(page, label) {
  const vis = async (t) => page.getByText(t).first().isVisible().catch(() => false);
  const visText = await page.evaluate(() => [...document.querySelectorAll('div[dir=auto]')].filter((e) => e.offsetParent !== null && e.getBoundingClientRect().width > 0 && e.getBoundingClientRect().x >= 0 && e.getBoundingClientRect().x < 400 && e.childElementCount === 0).map((e) => e.textContent).join(' | '));
  console.log(`--- ${label} | "Loading…" visible: ${await vis('Loading…')}`);
  if (process.env.VIS) console.log('    visible:', visText.slice(0, Number(process.env.VIS)));
}
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  for (let r = 1; r <= runs; r++) {
    const ctx = await browser.newContext({ viewport: { width: 400, height: 860 } }); // new context = cleared site data
    const page = await ctx.newPage();
    const logs = []; let tv = 0;
    page.on('console', (m) => { if (m.text().includes('[session]')) logs.push(`${String(tv ? Date.now() - tv : 0).padStart(6)}ms ${m.text()}`); });
    page.on('pageerror', (e) => console.log('PAGEERROR', e.message)); page.on('console', (m) => { if (m.type() === 'error' && process.env.ERRS) console.log('CONSOLE.ERROR', m.text().slice(0, 300)); });
    await login(page, role); tv = Date.now(); logs.push('       ==== VERIFY CLICKED ====');
    for (const s of [1000, 3000, watch]) { await page.waitForTimeout(Math.max(0, s - (Date.now() - tv))); await snapshot(page, `run ${r} · ${role} · +${s}ms`); }
    if (process.env.DUMP) console.log('=== screen text ===\n' + (await page.evaluate(() => document.body.innerText)).slice(0, Number(process.env.DUMP)));
    if (process.env.STUDENTS) {
      await page.getByRole('tab', { name: 'Students', exact: true }).click(); await page.waitForTimeout(3000);
      const line = page.getByText(/\d+ students? · \d+ with dues/).first();
      console.log('=== Students tab: ' + (await line.textContent().catch(() => '(no count line)')));
    }
    if (process.env.SHOT) await page.screenshot({ path: `.scratch/${role}-${r}.png` });
    if (process.env.LOGS) { console.log(`=== ${logs.length} [session] renders after Verify ===`); const n = Number(process.env.LOGS); console.log(logs.slice(0, n).join('\n')); if (logs.length > n) console.log('   …\n' + logs.slice(-4).join('\n')); }
    await ctx.close();
  }
  await browser.close();
})().catch((e) => { console.error('FAILED', e.message); process.exit(1); });
