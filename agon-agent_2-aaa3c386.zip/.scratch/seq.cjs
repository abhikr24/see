// One browser context, several logins in a row (no clearing between), signing out via the shell header.
const { chromium } = require('@playwright/test');
const BASE = process.env.BASE || 'http://localhost:8081';
const seq = (process.env.SEQ || 'Owner,Owner,Teacher,Parent').split(',');
const killOverlay = () => { const k = () => ['error-overlay', 'error-toast'].forEach((id) => document.getElementById(id)?.remove()); k(); setInterval(k, 100); };
async function visibleText(page) {
  return page.evaluate(() => [...document.querySelectorAll('div[dir=auto]')].filter((e) => { const r = e.getBoundingClientRect(); return e.offsetParent !== null && r.width > 0 && r.x >= 0 && r.x < 400 && r.y >= 0 && r.y < 860 && e.childElementCount === 0; }).map((e) => e.textContent.trim()).filter(Boolean).join(' | '));
}
async function login(page, pill, first) {
  if (first) await page.goto(`${BASE}/login`, { timeout: 240000 });
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 90000 });
  if (process.env.KILL_OVERLAY) await page.evaluate(killOverlay);
  await page.getByText(pill, { exact: true }).click();
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 40 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
}
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 400, height: 860 } });
  const page = await ctx.newPage();
  const logs = []; let t0 = Date.now();
  page.on('console', (m) => { if (m.text().includes('[session]')) logs.push(`${String(Date.now() - t0).padStart(6)}ms ${m.text()}`); });
  page.on('pageerror', (e) => { if (!e.message.includes('color scheme')) console.log('PAGEERROR', e.message); });
  for (let i = 0; i < seq.length; i++) {
    const role = seq[i];
    await login(page, role, i === 0); t0 = Date.now(); logs.length = 0;
    await page.waitForTimeout(Number(process.env.WATCH || 10000));
    const loadingVisible = await page.getByText('Loading…').first().isVisible().catch(() => false);
    console.log(`\n### Login ${i + 1}: ${role} — url ${page.url().replace(BASE, '')} — "Loading…" visible after ${process.env.WATCH || 10000}ms: ${loadingVisible}`);
    console.log('    screen: ' + (await visibleText(page)).slice(0, Number(process.env.VIS || 600)));
    if (role === 'Owner' && process.env.STUDENTS) {
      await page.getByRole('tab', { name: 'Students', exact: true }).click(); await page.waitForTimeout(3000);
      console.log('    Students tab: ' + (await page.getByText(/\d+ students? · \d+ with dues/).first().textContent().catch(() => '(no count line)')));
      await page.getByRole('tab', { name: 'Home', exact: true }).click(); await page.waitForTimeout(500);
    }
    if (process.env.SHOT) await page.screenshot({ path: `.scratch/seq-${i + 1}-${role}.png` });
    if (process.env.LOGS) { const n = Number(process.env.LOGS); console.log(`    ${logs.length} [session] renders:`); console.log(logs.slice(0, n).map((l) => '    ' + l).join('\n')); if (logs.length > n) console.log('    …\n' + logs.slice(-3).map((l) => '    ' + l).join('\n')); }
    if (i < seq.length - 1) {
      // Sign out from whichever shell we are in.
      const so = page.getByText(/^sign out$/i).first();
      if (await so.isVisible().catch(() => false)) await so.click();
      else { await page.getByRole('tab', { name: 'More', exact: true }).click().catch(() => {}); await page.waitForTimeout(800); await page.getByText(/^sign out$/i).first().click(); }
      await page.waitForTimeout(1500);
    }
  }
  await browser.close();
})().catch((e) => { console.error('FAILED', e.message.split('\n')[0]); process.exit(1); });
