// usage: SCHEME=dark|light OUT=.scratch/shots/before node .scratch/shots.cjs
const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png', '.ico': 'image/x-icon' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8131);
const BASE = 'http://localhost:8131';
const scheme = process.env.SCHEME || 'light';
const out = process.env.OUT || '.scratch/shots';
fs.mkdirSync(out, { recursive: true });
async function signIn(page) {
  await page.goto(`${BASE}/`);
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
  await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await page.locator('[role="tab"]').first().waitFor({ state: 'visible', timeout: 30000 });
}
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 400, height: 860 }, colorScheme: scheme, reducedMotion: process.env.REDUCED ? 'reduce' : 'no-preference' });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 300)); });
  const shot = async (name) => { await page.waitForTimeout(1200); await page.screenshot({ path: path.join(out, `${scheme}-${name}.png`) }); console.log('shot', name, page.url().replace(BASE, '')); };
  try {
    await signIn(page);
    await page.waitForTimeout(2500);
    await shot('1-dashboard');
    await page.getByRole('tab', { name: /Students/ }).click();
    await page.waitForTimeout(2000);
    await shot('2-students');
    await page.getByRole('tab', { name: /Home/ }).click();
    await page.waitForTimeout(1500);
    await page.getByText('Take attendance', { exact: false }).first().click();
    await page.waitForTimeout(2500);
    const batch = page.getByText(/Class 10-A/).first();
    if (await batch.isVisible().catch(() => false)) { await batch.click(); await page.waitForTimeout(3000); }
    await shot('3-attendance');
    const extra = (process.env.ROUTES || '').split(',').filter(Boolean);
    let i = 4;
    for (const r of extra) { await page.goto(`${BASE}${r}`); await page.waitForTimeout(2500); await shot(`${i++}-${r.replace(/[^a-z0-9]+/gi, '_')}`); }
  } catch (e) { console.log('FAILED', e.message.split('\n')[0]); await page.screenshot({ path: path.join(out, `${scheme}-FAILED.png`) }); }
  console.log('page errors:', errors.length); errors.slice(0, 12).forEach((e) => console.log('  ', e));
  await browser.close(); server.close();
})();
