import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Modal, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Text } from '@/components/ui';
import type { AnalyticsReportPeriod, AnalyticsReportType } from '@/core/contracts/models';
import { useBatches } from '@/core/backend';
import { useReport } from '@/features/reports/hooks';
import { REPORTS, isParentFacing } from '@/features/reports/model';
import { exportReportCsv, exportReportPdf } from '@/features/reports/report-export';
import { ReportChart } from '@/features/reports/components/ReportChart';
import { useColors } from '@/lib/theme';
import { money } from '@/features/fees/ui';

import { Pressable } from '@/components/ui/Pressable';
import { Refresh } from '@/components/ui/Refresh';
const PERIODS: { key: AnalyticsReportPeriod; label: string }[] = [{ key: 'week', label: '7 days' }, { key: 'month', label: '30 days' }, { key: 'term', label: 'Term' }];
const currencyTypes = new Set(['fee-collection']);
const percentTypes = new Set(['attendance', 'academic-performance', 'teacher-performance']);

export default function ReportDetailRoute() {
  const C = useColors();
  const params = useLocalSearchParams<{ type?: string }>();
  const type = REPORTS.some((report) => report.type === params.type) ? params.type as AnalyticsReportType : 'student-strength';
  const [period, setPeriod] = useState<AnalyticsReportPeriod>('term');
  const [batchId, setBatchId] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const reportQuery = useReport(type, period, batchId);
  const batches = useBatches();
  const [previousReport, setPreviousReport] = useState<NonNullable<typeof reportQuery.data>>();
  useEffect(() => { if (reportQuery.data) setPreviousReport(reportQuery.data); }, [reportQuery.data]);
  const report = reportQuery.data ?? (previousReport?.type === type ? previousReport : undefined);
  const batchName = useMemo(() => batches.data?.items?.find((b) => b.id === batchId)?.name ?? 'All batches', [batches.data, batchId]);
  const isCurrency = currencyTypes.has(type);
  const formatValue = (value: string | number) => typeof value === 'string' ? value : isCurrency ? money(value) : percentTypes.has(type) ? `${value.toFixed(1)}%` : value.toLocaleString('en-IN');
  const exportCsv = async () => { if (!report) return; setExporting(true); try { await exportReportCsv(report); } finally { setExporting(false); } };
  const exportPdf = async () => { if (!report) return; setExporting(true); try { await exportReportPdf(report); } finally { setExporting(false); } };
  const selectedTitle = REPORTS.find((r) => r.type === type)?.title ?? 'Report';

  const listData: Array<{ id: string; kind: 'table-header' } | (NonNullable<typeof report>['rows'][number] & { kind?: 'report-row' })> = report ? [{ id: 'table-header', kind: 'table-header' }, ...report.rows] : [];
  return <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
    <FlatList data={listData} stickyHeaderIndices={[1]} keyExtractor={(row) => row.id} renderItem={({ item }) => item.kind === 'table-header' ? <View style={{ minHeight: 44, flexDirection: 'row', alignItems: 'center', backgroundColor: C.surface, paddingHorizontal: 14, borderBottomWidth: 1, borderColor: C.hairline }}><Text weight={700} style={{ flex: 1.5 }}>Name</Text>{report?.columns.map((col) => <Text key={col.key} variant="label" weight={700} style={{ flex: 1, textAlign: 'right' }}>{col.title}</Text>)}</View> : <View style={{ minHeight: 58, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 9, borderBottomWidth: 1, borderColor: C.hairline, backgroundColor: C.surface }}><View style={{ flex: 1.5, flexDirection: 'row', alignItems: 'center', gap: 8 }}><View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: item.status === 'good' ? C.teal : item.status === 'bad' ? C.danger : C.secondary }}/><View style={{ flex: 1 }}><Text weight={700} numberOfLines={1}>{item.label}</Text><Text variant="label" c={C.secondary} numberOfLines={1}>{item.detail}</Text></View></View>{item.values.map((value, index) => <Text key={`${item.id}-${index}`} tabular variant="caption" style={{ flex: 1, textAlign: 'right' }}>{formatValue(value)}</Text>)}</View>} refreshControl={<Refresh refreshing={reportQuery.loading} onRefresh={() => void reportQuery.refetch()} />} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 122, gap: 16 }} 
      ListHeaderComponent={<View style={{ gap: 18 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 7 }}><Pressable accessibilityLabel="Back to reports" onPress={() => router.back()} style={{ height: 40, width: 40, borderRadius: 14, backgroundColor: C.surface, borderWidth: 1, borderColor: C.hairline, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="arrow-back" size={19} color={C.primaryInk}/></Pressable><View style={{ flex: 1 }}><Text variant="h2">{selectedTitle}</Text><Text variant="caption" c={C.secondary}>Institute report</Text></View><Pressable onPress={() => setFiltersOpen(true)} style={{ width: 42, height: 42, borderRadius: 14, backgroundColor: C.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.hairline }}><Ionicons name="options-outline" size={19} color={C.primaryInk}/></Pressable></View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}><Pressable onPress={() => setFiltersOpen(true)} style={{ backgroundColor: C.surface, borderColor: C.hairline, borderWidth: 1, borderRadius: 999, paddingHorizontal: 13, paddingVertical: 8 }}><Text variant="caption" weight={700}>{PERIODS.find((p) => p.key === period)?.label}</Text></Pressable><Pressable onPress={() => setFiltersOpen(true)} style={{ backgroundColor: C.surface, borderColor: C.hairline, borderWidth: 1, borderRadius: 999, paddingHorizontal: 13, paddingVertical: 8 }}><Text variant="caption" weight={700}>{batchName}</Text></Pressable><Pressable onPress={() => setFiltersOpen(true)}><Text variant="caption" c={C.primaryInk} weight={700}>Change</Text></Pressable></View>
        {reportQuery.error && !report ? <Card><View style={{ gap: 12 }}><Text variant="title">Could not load this report</Text><Text variant="caption" c={C.secondary}>{reportQuery.error.message}</Text><Button title="Try again" onPress={() => void reportQuery.refetch()} /></View></Card> : null}
        {reportQuery.loading && !report ? <Card><ActivityIndicator color={C.primaryInk}/><Text variant="caption" c={C.secondary} style={{ textAlign: 'center', marginTop: 10 }}>Loading report data…</Text></Card> : null}
        {reportQuery.error && report ? <Text variant="caption" c={C.dangerInk}>Refresh failed. Showing previously loaded report data.</Text> : reportQuery.loading && report ? <Text variant="caption" c={C.secondary}>Updating report filters…</Text> : null}
        {report ? <>
          <Card style={{ padding: 20, gap: 8, backgroundColor: C.primary }}><Text variant="caption" c={C.navyPale}>{report.headlineLabel.toUpperCase()}</Text><Text c={C.onFill} tabular style={{ fontSize: 34, fontWeight: '800' }}>{report.headlineValue}</Text><Text variant="caption" c={report.deltaValue !== null && report.deltaValue < 0 ? '#FFC7C0' : '#A9E8D9'}>{report.deltaLabel}</Text><ReportChart bars={report.bars}/></Card>
          <View style={{ flexDirection: 'row', gap: 10 }}><Button title={exporting ? 'Preparing…' : 'Export CSV'} icon="download-outline" variant="outline" onPress={() => void exportCsv()} disabled={exporting}/>{isParentFacing(type) ? <Button title="Export PDF" icon="document-outline" variant="outline" onPress={() => void exportPdf()} disabled={exporting}/> : null}</View>
          {report.rows.length === 0 ? <Card><View style={{ alignItems: 'center', paddingVertical: 16, gap: 8 }}><Ionicons name="file-tray-outline" size={30} color={C.secondary}/><Text weight={700}>No data in this period</Text><Text variant="caption" c={C.secondary}>Choose a different period or batch to see report data.</Text></View></Card> : null}
        </> : null}
      </View>}
      ListEmptyComponent={!report && !reportQuery.loading && !reportQuery.error ? <Card><Text>Loading report…</Text></Card> : null}
    />
    <Modal visible={filtersOpen} transparent animationType="slide" onRequestClose={() => setFiltersOpen(false)}><Pressable haptic={false} scale={false} onPress={() => setFiltersOpen(false)} style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: '#101B4C66' }}><Pressable haptic={false} scale={false} onPress={(e) => e.stopPropagation()} style={{ backgroundColor: C.surface, borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 24, gap: 16, paddingBottom: 34 }}><View style={{ width: 40, height: 4, backgroundColor: C.hairline, borderRadius: 3, alignSelf: 'center' }}/><Text variant="title">Change report filters</Text><Text variant="caption" c={C.secondary}>Period</Text><View style={{ flexDirection: 'row', gap: 8 }}>{PERIODS.map((item) => <Pressable key={item.key} onPress={() => setPeriod(item.key)} style={{ borderRadius: 999, paddingHorizontal: 14, paddingVertical: 9, backgroundColor: period === item.key ? C.primary : C.canvas }}><Text variant="caption" weight={700} c={period === item.key ? C.onFill : C.primaryInk}>{item.label}</Text></Pressable>)}</View><Text variant="caption" c={C.secondary}>Batch</Text><View style={{ gap: 8, maxHeight: 220 }}><Pressable onPress={() => setBatchId(null)} style={{ padding: 12, borderRadius: 12, backgroundColor: !batchId ? C.navySoft : C.canvas }}><Text weight={700} c={!batchId ? C.primaryInk : C.ink}>All batches</Text></Pressable>{batches.data?.items?.map((batch) => <Pressable key={batch.id} onPress={() => setBatchId(batch.id)} style={{ padding: 12, borderRadius: 12, backgroundColor: batchId === batch.id ? C.navySoft : C.canvas }}><Text weight={700} c={batchId === batch.id ? C.primaryInk : C.ink}>{batch.name}</Text></Pressable>)}</View><Button title="Apply filters" onPress={() => setFiltersOpen(false)}/></Pressable></Pressable></Modal>
  </SafeAreaView>;
}
