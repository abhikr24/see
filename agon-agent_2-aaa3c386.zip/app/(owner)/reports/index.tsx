import React from 'react';
import { FlatList, View } from 'react-native';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { Text, Card } from '@/components/ui';
import { REPORTS } from '@/features/reports/model';
import { LAYOUT, S, useColors } from '@/lib/theme';

import { Pressable } from '@/components/ui/Pressable';
export default function ReportsHub() {
  const C = useColors();
  return <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
    <FlatList data={REPORTS} numColumns={2} keyExtractor={(item) => item.type} contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 130, gap: 12 }} columnWrapperStyle={{ gap: 12 }}
      ListHeaderComponent={<View style={{ gap: 4, marginBottom: 16 }}><Text variant="h2">Reports</Text><Text variant="caption" c={C.secondary}>A clear view of how your institute is moving.</Text></View>}
      renderItem={({ item }) => <Pressable accessibilityRole="button" onPress={() => router.push({ pathname: '/(owner)/reports/[type]', params: { type: item.type } } as never)} style={{ flex: 1, minHeight: 164, padding: 16, borderRadius: 20, backgroundColor: C.surface, borderWidth: 1, borderColor: C.hairline, gap: 12 }}>
        <View style={{ width: 42, height: 42, borderRadius: 13, backgroundColor: item.tint, alignItems: 'center', justifyContent: 'center' }}><Ionicons name={item.icon as never} size={21} color={item.tone}/></View>
        <View style={{ gap: 4 }}><Text weight={700} style={{ fontSize: 15 }}>{item.title}</Text><Text variant="label" c={C.secondary} style={{ lineHeight: 17 }}>{item.description}</Text></View>
        <Ionicons name="arrow-forward" size={15} color={C.secondary} style={{ position: 'absolute', right: 15, top: 17 }}/>
      </Pressable>}
      ListEmptyComponent={<Card><Text>No reports available.</Text></Card>}/>
  </SafeAreaView>;
}
