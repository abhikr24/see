import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Badge, Card, Screen, Text } from '@/components/ui';
import { useUnreadNotifications } from '@/core/backend';
import { badgeLabel } from '@/lib/format';
import { R, useColors } from '@/lib/theme';

const ITEMS = [
  {
    key: 'notices',
    title: 'Notices',
    detail: 'Announcements from your institute',
    icon: 'megaphone-outline' as const,
    route: '/(student)/notices',
  },
  {
    key: 'notifications',
    title: 'Notifications',
    detail: 'Homework, results and everything sent to you',
    icon: 'notifications-outline' as const,
    route: '/shared/notifications',
  },
];

/** Student More: the two places this prompt adds. Materials, practice and profile settings are still to come. */
export default function StudentMoreRoute() {
  const C = useColors();
  const unread = useUnreadNotifications();
  return (
    <Screen title="More" subtitle="Notices and your notifications" safeTop={false} tabBarInset={96}>
      <View style={{ gap: 12 }}>
        {ITEMS.map((item) => (
          <Card key={item.key} pad={16} onPress={() => router.push(item.route as never)}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View
                style={{
                  width: 46,
                  height: 46,
                  borderRadius: R.field,
                  backgroundColor: C.navySoft,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Ionicons name={item.icon} size={22} color={C.primaryInk} />
              </View>
              <View style={{ flex: 1, gap: 3 }}>
                <Text variant="title" weight={700}>{item.title}</Text>
                <Text variant="caption" c={C.secondary}>{item.detail}</Text>
              </View>
              {item.key === 'notifications' && unread > 0 ? <Badge label={`${badgeLabel(unread)} new`} tone="danger" small /> : null}
              <Ionicons name="chevron-forward" size={18} color={C.muted} />
            </View>
          </Card>
        ))}
      </View>
    </Screen>
  );
}
