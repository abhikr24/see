import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { Badge, Card, Screen, Text } from '@/components/ui';
import { useUnreadNotifications } from '@/core/backend';
import { badgeLabel } from '@/lib/format';
import { R, useColors } from '@/lib/theme';

import { Pressable } from '@/components/ui/Pressable';
const ITEMS = [
  { key: 'doubts', title: 'Student doubts', detail: 'Open questions, replies and waiting time', icon: 'chatbubbles-outline' as const, route: '/(teacher)/doubts' },
  { key: 'leave', title: 'Leave requests', detail: 'Request time away and track approvals', icon: 'calendar-outline' as const, route: '/(teacher)/leave' },
  { key: 'notices', title: 'Notices', detail: 'Read announcements and write to your classes', icon: 'megaphone-outline' as const, route: '/(teacher)/notices' },
  { key: 'notifications', title: 'Notifications', detail: 'Announcements, leave replies and class updates', icon: 'notifications-outline' as const, route: '/shared/notifications' },
];

export default function TeacherMoreRoute() {
  const C = useColors();
  const unread = useUnreadNotifications();
  return (
    <Screen title="More" subtitle="Teaching tools and requests" safeTop={false} tabBarInset={96}>
      <View style={{ gap: 12 }}>
        {ITEMS.map((item) => (
          <Pressable key={item.key} onPress={() => router.push(item.route as never)}>
            <Card pad={16}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <View style={{ width: 46, height: 46, borderRadius: R.field, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={item.icon} size={22} color={C.primaryInk} />
                </View>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text variant="title" weight={700}>{item.title}</Text>
                  <Text variant="caption" c={C.secondary}>{item.detail}</Text>
                </View>
                {item.key === 'notifications' && unread > 0 ? <Badge label={`${badgeLabel(unread)} new`} tone="danger" small /> : null}
                <Ionicons name="chevron-forward" size={18} color={C.muted} />
              </View>
            </Card>
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}
