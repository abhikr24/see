import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Link, Stack } from 'expo-router';
import { LAYOUT, R, useColors } from '@/lib/theme';
import { Text, Button } from '@/components/ui';

import { Pressable } from '@/components/ui/Pressable';
export default function NotFoundScreen() {
  const C = useColors();
  return (
    <>
      <Stack.Screen options={{ title: 'Not found', headerShown: false }} />
      <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin, alignItems: 'center', justifyContent: 'center', gap: 14 }}>
        <View
          style={{
            width: 72,
            height: 72,
            borderRadius: 36,
            backgroundColor: C.navyTint,
            borderWidth: 1,
            borderColor: C.hairline,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name="compass-outline" size={32} color={C.primaryInk} />
        </View>
        <Text variant="h2" style={{ textAlign: 'center' }}>
          Page not found
        </Text>
        <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 300 }}>
          This page doesn’t exist or was moved. Check the link or head back home — your data is still safe.
        </Text>
        <Link href="/(owner)" asChild>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Go to home"
            style={({ pressed }) => ({
              marginTop: 8,
              height: 44,
              paddingHorizontal: 20,
              borderRadius: R.btn,
              backgroundColor: C.primary,
              alignItems: 'center',
              justifyContent: 'center',
              opacity: pressed ? 0.9 : 1,
            })}
          >
            <Text weight={700} c={C.onFill}>
              Go to home
            </Text>
          </Pressable>
        </Link>
        <Link href="/shared/search" asChild>
          <Pressable accessibilityRole="button" accessibilityLabel="Search" hitSlop={8} style={{ marginTop: 4 }}>
            <Text variant="caption" c={C.primaryInk} weight={700}>
              Search students, batches, materials
            </Text>
          </Pressable>
        </Link>
      </View>
    </>
  );
}
