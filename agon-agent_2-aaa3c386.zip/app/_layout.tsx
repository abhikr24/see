import '../global.css';
import React from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { DEFAULT_BACKEND, DEFAULT_INSTITUTE_ID, createBackends } from '../src/backends';
import { BackendProvider } from '../src/core/backend';
import { DevAuthBypassBanner } from '../src/features/shell/DevAuthBypassBanner';
import { AttendanceOutboxSync } from '../src/features/attendance/OutboxSync';
import { SubmissionOutboxSync } from '../src/features/homework/SubmissionOutboxSync';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { useSessionStore } from '../src/store/session';
import { DUR } from '@/lib/motion';
import { ThemeProvider } from '@/lib/ThemeProvider';
import { useTheme } from '@/lib/theme';

const backends = createBackends();

/**
 * Keeps the session queries subscribed for the life of the app, so invalidating
 * `session` / `my-institutes` / `memberships` after sign-in re-reads getSession
 * instead of leaving a signed-out snapshot until the next full reload.
 */
function SessionCacheKeeper() {
  useSessionStore();
  return null;
}

/**
 * The root stack. Pushes slide in over DUR.base; the two overlay routes
 * (search and the notification centre) fade, as modal routes do.
 */
function RootStack() {
  const theme = useTheme();
  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'slide_from_right',
          animationDuration: DUR.base,
          contentStyle: { backgroundColor: theme.background },
        }}
      >
        <Stack.Screen name="shared/search" options={{ animation: 'fade', animationDuration: DUR.base }} />
        <Stack.Screen name="shared/notifications" options={{ animation: 'fade', animationDuration: DUR.base }} />
      </Stack>
      <StatusBar style={theme.dark ? 'light' : 'dark'} />
    </>
  );
}

export default function RootLayout() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font, Jakarta: require('../assets/fonts/PlusJakartaSans.ttf'), Heading: require('../assets/fonts/Manrope.ttf') });

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider>
        <ErrorBoundary>
          <BackendProvider
            backends={backends}
            initial={DEFAULT_BACKEND}
            instituteId={DEFAULT_INSTITUTE_ID}
          >
            <DevAuthBypassBanner />
            <SessionCacheKeeper />
            <AttendanceOutboxSync />
            <SubmissionOutboxSync />
            <RootStack />
          </BackendProvider>
        </ErrorBoundary>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
