import React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '@/lib/theme';
import { SearchScreen } from '@/features/search/screens/SearchScreen';

export default function SharedSearchRoute() {
  const C = useColors();
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
      <SearchScreen />
    </SafeAreaView>
  );
}
