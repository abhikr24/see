import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { queryCache } from '@/core/hooks/cache';
import { useColors, SHADOW } from '@/lib/theme';
import { Text } from './Text';

import { Pressable } from './Pressable';
export function BackendFailureBanner({ backendName }: { backendName: string }) {
  const C = useColors();
  const [, refresh] = useState(0);
  useEffect(() => queryCache.subscribeAll(() => refresh((value) => value + 1)), []);
  if (backendName === 'memory') return null;
  const prefix = `${backendName}|`;
  const errors = queryCache.activeErrors().filter((entry) => entry.key.startsWith(prefix));
  if (!errors.length) return null;
  return <SafeAreaView edges={['top']} pointerEvents="box-none" style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 2000 }}>
    <View accessibilityRole="alert" style={{ marginHorizontal: 14, marginTop: 5, paddingHorizontal: 14, paddingVertical: 11, borderRadius: 15, backgroundColor: C.dangerSoft, borderWidth: 1, borderColor: C.danger, flexDirection: 'row', alignItems: 'center', gap: 10, ...SHADOW.overlay }}>
      <Ionicons name="cloud-offline-outline" size={19} color={C.danger}/>
      <View style={{ flex: 1, gap: 2 }}><Text weight={700} c={C.dangerInk}>Could not load data</Text><Text variant="label" c={C.dangerInk} numberOfLines={2}>{errors[0].error.message}</Text></View>
      <Pressable accessibilityRole="button" accessibilityLabel="Retry failed data loads" onPress={() => void queryCache.retryActiveErrors(prefix)} hitSlop={10} style={{ padding: 7 }}><Ionicons name="refresh" size={19} color={C.danger}/></Pressable>
    </View>
  </SafeAreaView>;
}
