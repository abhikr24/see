import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { R, TONE, type Tone, useColors } from '@/lib/theme';
import { initials as toInitials } from '@/lib/format';
import { Text } from './Text';

import { Pressable } from './Pressable';
export interface BadgeProps {
  label: string;
  tone?: Tone;
  small?: boolean;
  className?: string;
}

export function Badge({ label, tone = 'neutral', small, className }: BadgeProps) {
  useColors();
  const t = TONE[tone];
  return (
    <View
      className={className}
      style={{
        backgroundColor: t.bg,
        paddingHorizontal: small ? 8 : 10,
        paddingVertical: small ? 3 : 5,
        borderRadius: R.chip,
        alignSelf: 'flex-start',
      }}
    >
      <Text variant="label" weight={600} c={t.fg} style={{ fontSize: small ? 9.5 : 10.5 }}>
        {label}
      </Text>
    </View>
  );
}

export interface ChipProps {
  label: string;
  active?: boolean;
  onPress?: () => void;
  count?: number;
  className?: string;
}

export function Chip({ label, active, onPress, count, className }: ChipProps) {
  const C = useColors();
  return (
    <Pressable
      onPress={onPress}
      className={className}
      style={({ pressed }) => ({
        height: 36,
        paddingHorizontal: 14,
        borderRadius: R.chip,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: active ? C.primary : C.surface,
        borderWidth: 1,
        borderColor: active ? C.primaryInk : C.hairline,
        opacity: pressed ? 0.9 : 1,
      })}
    >
      <Text variant="caption" weight={600} c={active ? C.onFill : C.secondary} tabular>
        {label}
        {count !== undefined ? ` ${count}` : ''}
      </Text>
    </Pressable>
  );
}

export interface AvatarProps {
  name: string;
  uri?: string | null;
  size?: number;
  className?: string;
}

export function Avatar({ name, uri, size = 48, className }: AvatarProps) {
  const C = useColors();
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [uri]);
  return (
    <View
      className={className}
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: C.navySoft,
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
      }}
    >
      {uri && !failed ? (
        <Image
          source={{ uri }}
          contentFit="cover"
          onError={() => setFailed(true)}
          style={{ width: size, height: size }}
          accessibilityLabel={name}
        />
      ) : (
        <Text weight={700} c={C.primaryInk} style={{ fontSize: size * 0.36 }}>
          {toInitials(name)}
        </Text>
      )}
    </View>
  );
}

export interface IconBoxProps {
  name: keyof typeof Ionicons.glyphMap;
  tone?: Tone;
  size?: number;
  className?: string;
}

export function IconBox({ name, tone = 'primary', size = 44, className }: IconBoxProps) {
  useColors();
  const t = TONE[tone];
  return (
    <View
      className={className}
      style={{
        width: size,
        height: size,
        borderRadius: R.field,
        backgroundColor: t.bg,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Ionicons name={name} size={size * 0.48} color={t.icon} />
    </View>
  );
}

export interface DividerProps {
  inset?: number;
  className?: string;
}

export function Divider({ inset = 0, className }: DividerProps) {
  const C = useColors();
  return <View className={className} style={{ height: 1, backgroundColor: C.hairline, marginLeft: inset }} />;
}

export interface ProgressBarProps {
  value: number;
  tone?: Tone;
  height?: number;
  className?: string;
}

export function ProgressBar({ value, tone = 'primary', height = 6, className }: ProgressBarProps) {
  const C = useColors();
  const t = TONE[tone];
  const v = Math.max(0, Math.min(100, value));
  return (
    <View
      className={className}
      style={{ height, borderRadius: height, backgroundColor: C.track, overflow: 'hidden' }}
    >
      <View style={{ width: `${v}%`, height: '100%', borderRadius: height, backgroundColor: t.fill }} />
    </View>
  );
}
