import React from 'react';
import { View, type ViewProps } from 'react-native';
import { R, SHADOW, useColors } from '@/lib/theme';
import { Pressable } from './Pressable';

export interface CardProps extends ViewProps {
  onPress?: () => void;
  pad?: number;
  flat?: boolean;
  tint?: string;
  /** Draws the 1px inner top highlight (stat cards). */
  highlight?: boolean;
  className?: string;
}

export function Card({
  onPress,
  pad = 18,
  flat,
  tint,
  highlight,
  style,
  className,
  children,
  ...rest
}: CardProps) {
  const C = useColors();
  const body = (
    <View
      {...rest}
      className={className}
      style={[
        {
          backgroundColor: tint ?? C.surface,
          borderRadius: R.card,
          borderWidth: 1,
          borderColor: C.hairline,
          padding: pad,
          ...(flat ? null : SHADOW.raised),
        },
        style,
      ]}
    >
      {highlight ? <TopHighlight radius={R.card} /> : null}
      {children}
    </View>
  );
  if (!onPress) return body;
  return (
    <Pressable onPress={onPress} accessibilityLabel={rest.accessibilityLabel} style={({ pressed }) => ({ opacity: pressed ? 0.92 : 1 })}>
      {body}
    </Pressable>
  );
}

/** The 1px inner top highlight that gives stat cards and the tab bar their edge. */
export function TopHighlight({ radius }: { radius: number }) {
  const C = useColors();
  return (
    <View
      pointerEvents="none"
      style={{
        position: 'absolute',
        top: 0,
        left: radius * 0.6,
        right: radius * 0.6,
        height: 1,
        backgroundColor: C.highlight,
      }}
    />
  );
}
