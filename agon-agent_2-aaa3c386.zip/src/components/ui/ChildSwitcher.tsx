import React from 'react';
import { FlatList, View } from 'react-native';
import type { ParentChildSummary } from '@/core/contracts/models/parent';
import { useTheme, useColors, SHADOW } from '@/lib/theme';
import { ParentSheet } from '@/features/parent/ParentSheet';
import { currency, Icon, Label, percent, Photo, styles } from '@/features/parent/ui';

import { Pressable } from './Pressable';
interface Props {
  items: ParentChildSummary[];
  selectedId: string;
  visible: boolean;
  onOpen: () => void;
  onClose: () => void;
  onSelect: (id: string) => void;
  className?: string;
}
export function ChildSwitcher({ items, selectedId, visible, onOpen, onClose, onSelect, className }: Props) {
  const C = useColors();
  const theme = useTheme();
  const active = items.find(c => c.id === selectedId);
  // A one-child family never gets a redundant selector or sheet.
  if (items.length <= 1 || !active) return null;
  return <View className={className}>
    <Pressable accessibilityRole="button" accessibilityLabel={`Switch child. ${active.name} selected. ${items.length} children`} onPress={onOpen} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 15, backgroundColor: theme.surface, borderWidth: 1, borderColor: theme.border, padding: 19, borderRadius: 18, opacity: pressed ? 0.85 : 1, ...SHADOW.raised })}>
      <Photo name={active.name} uri={active.photoUrl} />
      <View style={{ flex: 1 }}><Label weight="700" size={17}>{active.name}</Label><Label size={13} color={theme.muted}>{active.classLabel} · {active.instituteName.replace(' Classes', '')}</Label></View>
      <View style={{ backgroundColor: theme.background, borderRadius: 20, paddingVertical: 5, paddingHorizontal: 10 }}><Label size={10} color={theme.muted} weight="600">{items.length} children</Label></View>
      <Icon name="chevron-down" size={18} color={theme.muted} />
    </Pressable>
    <ParentSheet visible={visible} close={onClose} title="Your children" subtitle="A little window into each of their worlds.">
      <FlatList data={items} keyExtractor={c => c.id} scrollEnabled={false} contentContainerStyle={{ gap: 14 }} renderItem={({ item }) => {
        const selected = item.id === selectedId;
        return <Pressable accessibilityRole="button" accessibilityLabel={`Select ${item.name}`} accessibilityState={{ selected }} onPress={() => onSelect(item.id)} style={({ pressed }) => ({ padding: 18, borderWidth: selected ? 1.5 : 1, borderColor: selected ? C.primaryInk : theme.border, borderRadius: 18, backgroundColor: selected ? (theme.dark ? theme.background : C.canvas) : theme.surface, opacity: pressed ? 0.75 : 1 })}>
          <View style={[styles.row, { gap: 13 }]}>
            <Photo uri={item.photoUrl} name={item.name} size={48} />
            <View style={{ flex: 1 }}><Label size={16} weight="700">{item.name}</Label><Label size={12} color={theme.muted}>{item.classLabel} · {item.instituteName.replace(' Classes', '')}</Label></View>
            {selected ? <Icon name="checkmark-circle" size={23} color={C.teal} /> : item.dueNow > 0 ? <View style={{ backgroundColor: C.warningSoft, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 4 }}><Label color={C.duesInk} size={10} weight="700">Fee due</Label></View> : null}
          </View>
          <View style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: theme.border, marginTop: 16, paddingTop: 14 }}>
            {[{ label: 'Attendance', value: percent(item.attendancePercent), color: C.tealInk }, { label: 'Average', value: percent(item.averagePercent), color: theme.primary }, { label: 'Due now', value: currency(item.dueNow), color: item.dueNow > 0 ? C.duesInk : C.tealInk }].map((stat, i) => <View key={stat.label} style={{ flex: 1, paddingLeft: i ? 15 : 0, borderLeftWidth: i ? 1 : 0, borderColor: theme.border }}><Label size={18} weight="800" color={stat.color}>{stat.value}</Label><Label size={10} color={theme.muted}>{stat.label}</Label></View>)}
          </View>
        </Pressable>;
      }} />
      <Label size={12} color={theme.muted} style={{ textAlign: 'center', paddingTop: 23 }}>Tap a child to see their details.</Label>
    </ParentSheet>
  </View>;
}
