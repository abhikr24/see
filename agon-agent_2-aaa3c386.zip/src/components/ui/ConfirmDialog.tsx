import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { R, S, SHADOW, useColors } from '@/lib/theme';
import { Button } from './Button';
import { Modal, Scrim, SheetPanel } from './Overlay';
import { Input } from './Input';
import { Text } from './Text';

export interface ConfirmDialogProps {
  visible: boolean;
  title: string;
  description: string;
  /** Optional confirmation word the user must type to enable the destructive button */
  confirmText?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onCancel: () => void;
  /** Renders inline as a card for QA preview instead of a blocking Modal */
  inline?: boolean;
  className?: string;
}

/**
 * ConfirmDialog — destructive action with a typed confirmation option.
 */
export function ConfirmDialog({
  visible,
  title,
  description,
  confirmText,
  confirmLabel = 'Remove permanently',
  cancelLabel = 'Cancel',
  onConfirm,
  onCancel,
  inline = false,
  className,
}: ConfirmDialogProps) {
  const C = useColors();
  const [typed, setTyped] = useState('');

  useEffect(() => {
    if (visible) setTyped('');
  }, [visible]);

  if (!visible) return null;

  const canConfirm = confirmText ? typed.trim() === confirmText : true;

  const dialogCard = (
    <View
      className={className}
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: 20,
        gap: S.md,
        ...(inline ? null : SHADOW.overlay),
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.md }}>
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: 22,
            backgroundColor: C.dangerSoft,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name="warning-outline" size={22} color={C.danger} />
        </View>
        <View style={{ flex: 1 }}>
          <Text variant="h2" style={{ fontSize: 19 }}>
            {title}
          </Text>
        </View>
      </View>

      <Text variant="body" c={C.secondary} style={{ lineHeight: 21 }}>
        {description}
      </Text>

      {confirmText ? (
        <Input
          label={`Type "${confirmText}" to confirm`}
          placeholder={confirmText}
          value={typed}
          onChangeText={setTyped}
          autoCapitalize="characters"
          autoCorrect={false}
        />
      ) : null}

      <View style={{ flexDirection: 'row', gap: S.sm, marginTop: S.xs }}>
        <View style={{ flex: 1 }}>
          <Button title={cancelLabel} variant="outline" size="md" onPress={onCancel} />
        </View>
        <View style={{ flex: 1 }}>
          <Button
            title={confirmLabel}
            variant="danger"
            size="md"
            disabled={!canConfirm}
            onPress={() => {
              if (canConfirm) onConfirm();
            }}
          />
        </View>
      </View>
    </View>
  );

  if (inline) return dialogCard;

  return (
    <Modal visible={visible} transparent onRequestClose={onCancel}>
      <Scrim
        onPress={onCancel}
        accessibilityLabel={`Cancel: ${title}`}
        style={{
          backgroundColor: C.scrim,
          alignItems: 'center',
          justifyContent: 'center',
          padding: 20,
        }}
      >
        <SheetPanel from="center" accessibilityViewIsModal style={{ width: '100%', maxWidth: 420 }}>
          {dialogCard}
        </SheetPanel>
      </Scrim>
    </Modal>
  );
}
