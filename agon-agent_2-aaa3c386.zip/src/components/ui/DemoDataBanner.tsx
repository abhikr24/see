import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useColors } from '@/lib/theme';
import { Text } from './Text';

export function DemoDataBanner() {
  const C = useColors();
  return (
    <View accessibilityRole="text" style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 14, paddingVertical: 9, marginHorizontal: 20, marginTop: 8, borderRadius: 12, backgroundColor: C.warningSoft }}>
      <Ionicons name="information-circle-outline" size={16} color={C.duesInk} />
      <Text style={{ color: C.duesInk, fontSize: 12, fontWeight: '700' }}>Demo data — not connected to Supabase</Text>
    </View>
  );
}
