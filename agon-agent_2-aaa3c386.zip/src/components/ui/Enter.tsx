import React, { createContext, useContext, useEffect, useState } from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue } from 'react-native-reanimated';

import { DUR, STAGGER, timeTo, timeToAfter, useReduceMotion } from '@/lib/motion';

/** When the list mounted. Rows that mount long after it (scrolled in) do not replay the entrance. */
const StaggerContext = createContext<{ startedAt: number } | null>(null);

/** How long after the list mounts a row may still join the entrance. */
const WINDOW = STAGGER.cap * STAGGER.step + DUR.base;

/**
 * Marks the start of a list's entrance. Wrap the list (or mount it beside
 * the FlatList) so rows recycled in later by scrolling appear at rest.
 */
export function StaggerGroup({ children }: { children: React.ReactNode }) {
  const [value] = useState(() => ({ startedAt: Date.now() }));
  return <StaggerContext.Provider value={value}>{children}</StaggerContext.Provider>;
}

export interface StaggerItemProps {
  /** Position in the list. Rows at STAGGER.cap and beyond appear at rest. */
  index: number;
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

/**
 * A list row's entrance: fade in and rise 8pt, each row STAGGER.step after the
 * one before, for the first STAGGER.cap rows only. With reduce motion on, or
 * past the cap, the row is simply there.
 */
export function StaggerItem({ index, children, style }: StaggerItemProps) {
  const reduced = useReduceMotion();
  const group = useContext(StaggerContext);
  const [plays] = useState(
    () => !reduced && index < STAGGER.cap && (!group || Date.now() - group.startedAt < WINDOW),
  );
  const progress = useSharedValue(plays ? 0 : 1);

  useEffect(() => {
    if (plays) progress.set(timeToAfter(index * STAGGER.step, 1, DUR.base));
  }, [plays, index, progress]);

  const motion = useAnimatedStyle(() => ({
    opacity: progress.get(),
    transform: [{ translateY: (1 - progress.get()) * STAGGER.rise }],
  }));

  if (!plays) return <View style={style}>{children}</View>;
  return <Animated.View style={[style, motion]}>{children}</Animated.View>;
}

export interface CrossfadeProps {
  /** True once the data is there. */
  ready: boolean;
  /** Shown until `ready`, then faded out over the content. Same footprint as the content's first paint. */
  skeleton: React.ReactNode;
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  /** The content should fill its parent (a list that owns the remaining height). */
  fill?: boolean;
}

/**
 * Skeleton → content without the hard swap: when `ready` flips, the content
 * fades in over DUR.base while the skeleton, lifted out of the layout, fades
 * out on top of it. Nothing reflows because the skeleton no longer takes space.
 */
export function Crossfade({ ready, skeleton, children, style, fill }: CrossfadeProps) {
  // `settled` = the skeleton is gone for good. True from the start when the data was already there.
  const [settled, setSettled] = useState(ready);
  const content = useSharedValue(ready ? 1 : 0);

  useEffect(() => {
    if (!ready || settled) return;
    content.set(timeTo(1, DUR.base));
    const timer = setTimeout(() => setSettled(true), DUR.base);
    return () => clearTimeout(timer);
  }, [ready, settled, content]);

  const contentMotion = useAnimatedStyle(() => ({ opacity: content.get() }));
  const skeletonMotion = useAnimatedStyle(() => ({ opacity: 1 - content.get() }));

  if (!ready) return <View style={style}>{skeleton}</View>;
  if (settled) return <View style={style}>{children}</View>;

  return (
    <View style={style}>
      <Animated.View style={[fill ? { flex: 1 } : null, contentMotion]}>{children}</Animated.View>
      <Animated.View
        pointerEvents="none"
        accessibilityElementsHidden
        importantForAccessibility="no-hide-descendants"
        style={[{ position: 'absolute', left: 0, right: 0, top: 0 }, skeletonMotion]}
      >
        {skeleton}
      </Animated.View>
    </View>
  );
}

/** Content that fades in over DUR.base when it mounts (data arriving into a list's empty slot). */
export function FadeIn({ children, style }: { children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const opacity = useSharedValue(0);
  useEffect(() => {
    opacity.set(timeTo(1, DUR.base));
  }, [opacity]);
  const motion = useAnimatedStyle(() => ({ opacity: opacity.get() }));
  return <Animated.View style={[style, motion]}>{children}</Animated.View>;
}
