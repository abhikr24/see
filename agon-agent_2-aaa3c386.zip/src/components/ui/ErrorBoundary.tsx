import React from 'react';
import { View, ScrollView } from 'react-native';
import { C, LAYOUT } from '@/lib/theme';
import { Text } from './Text';
import { Button } from './Button';
import { EmptyArt } from './EmptyArt';

interface Props {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false, error: null };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    if (__DEV__) console.error('[ErrorBoundary]', error, info.componentStack);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;
      return (
        <View style={{ flex: 1, backgroundColor: C.canvas }}>
          <ScrollView contentContainerStyle={{ flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: LAYOUT.margin, gap: 12 }}>
            <EmptyArt icon="bug-outline" tone="danger" size={96} />
            <Text variant="h2" style={{ textAlign: 'center' }}>
              This is on us, not on you
            </Text>
            <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 300 }}>
              Something unexpected happened. Your data is still safe — try again and we’ll get you back on track.
            </Text>
            {__DEV__ && this.state.error ? (
              <View style={{ marginTop: 8, padding: 12, backgroundColor: C.surface, borderRadius: 12, borderWidth: 1, borderColor: C.hairline, maxWidth: 320, alignSelf: 'stretch' }}>
                <Text variant="caption" c={C.dangerInk} style={{ fontFamily: 'monospace' }} numberOfLines={6}>
                  {this.state.error.message}
                </Text>
              </View>
            ) : null}
            <View style={{ marginTop: 10 }}>
              <Button title="Try again" onPress={this.handleReset} size="md" full={false} />
            </View>
            <Text variant="caption" c={C.muted} style={{ textAlign: 'center', marginTop: 6 }}>
              If this keeps happening, close and reopen the app.
            </Text>
          </ScrollView>
        </View>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
