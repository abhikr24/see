import React from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { GRADIENT, GRADIENT_END, GRADIENT_START, R, SHADOW, useColors } from '@/lib/theme';

export interface GradientHeaderProps {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  className?: string;
}

/** The navy hero: primary → primary2 → #22307A at 135°. Navy in both schemes. */
export function GradientHeader({ children, style, className }: GradientHeaderProps) {
  useColors();
  return (
    <View className={className}>
      <LinearGradient
        colors={[GRADIENT[0], GRADIENT[1], GRADIENT[2]]}
        locations={[0, 0.62, 1]}
        start={GRADIENT_START}
        end={GRADIENT_END}
        style={[{ borderRadius: R.card, padding: 20, ...SHADOW.raised }, style]}
      >
        {children}
      </LinearGradient>
    </View>
  );
}

export interface OverlapCardProps {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  className?: string;
}

/** White card that overlaps the bottom edge of a hero header. */
export function OverlapCard({ children, style, className }: OverlapCardProps) {
  const C = useColors();
  return (
    <View
      className={className}
      style={[
        {
          backgroundColor: C.surface,
          borderRadius: R.card,
          borderWidth: 1,
          borderColor: C.hairline,
          padding: 18,
          marginTop: -22,
          marginHorizontal: 12,
          ...SHADOW.raised,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}
