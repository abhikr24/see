import React, { createContext, useContext, useEffect, useState } from 'react';
import { Modal as RNModal, StyleSheet, View, type ModalProps, type StyleProp, type ViewProps, type ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, type SharedValue } from 'react-native-reanimated';

import { DUR, springTo, timeTo, useReduceMotion } from '@/lib/motion';
import { useColors } from '@/lib/theme';
import { Pressable } from './Pressable';

interface OverlayMotion {
  /** 0 → 1 over DUR.base. Drives the scrim. */
  fade: SharedValue<number>;
  /** 0 → 1 on SPRING.sheet. Drives the panel. */
  rise: SharedValue<number>;
  reduced: boolean;
}

const OverlayContext = createContext<OverlayMotion | null>(null);

/**
 * Drop-in for React Native's Modal. The native `animationType` is ignored:
 * the scrim (`Scrim`) fades over DUR.base and the panel (`SheetPanel`) slides
 * up on SPRING.sheet. Closing plays the same motion backwards before the
 * modal unmounts, when the caller keeps it mounted and flips `visible`.
 */
export function Modal({ visible = true, children, ...rest }: ModalProps) {
  const reduced = useReduceMotion();
  const fade = useSharedValue(0);
  const rise = useSharedValue(0);
  // Stays mounted through the closing motion, then lets go.
  const [mounted, setMounted] = useState(visible);
  if (visible && !mounted) setMounted(true);

  useEffect(() => {
    if (visible) {
      fade.set(timeTo(1, DUR.base));
      rise.set(springTo(1, 'sheet', reduced));
      return;
    }
    fade.set(timeTo(0, DUR.quick));
    rise.set(timeTo(0, DUR.quick));
    const timer = setTimeout(() => setMounted(false), DUR.quick);
    return () => clearTimeout(timer);
  }, [visible, fade, rise, reduced]);

  if (!mounted && !visible) return null;

  return (
    <RNModal {...rest} visible transparent animationType="none" statusBarTranslucent>
      <OverlayContext.Provider value={{ fade, rise, reduced }}>{children}</OverlayContext.Provider>
    </RNModal>
  );
}

export interface ScrimProps extends Omit<ViewProps, 'style'> {
  /** Backdrop tap. */
  onPress?: () => void;
  /** Layout of the area the panel sits in (`justifyContent`, `padding`…). A `backgroundColor` here is the scrim colour. */
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
}

/**
 * The dimmed backdrop of a modal. Fades over DUR.base; a tap on it closes, as
 * before. It is not a button and does not scale or buzz.
 */
export function Scrim({ onPress, style, children, accessibilityLabel, ...rest }: ScrimProps) {
  const C = useColors();
  const motion = useContext(OverlayContext);
  const flat = StyleSheet.flatten(style) ?? {};
  const { backgroundColor, ...layout } = flat;
  const fadeStyle = useAnimatedStyle(() => ({ opacity: motion ? motion.fade.get() : 1 }));

  return (
    <View {...rest} style={{ flex: 1 }}>
      <Animated.View
        pointerEvents="none"
        style={[StyleSheet.absoluteFill, { backgroundColor: (backgroundColor as string | undefined) ?? C.scrim }, fadeStyle]}
      />
      <Pressable
        haptic={false}
        scale={false}
        accessibilityLabel={accessibilityLabel ?? 'Close'}
        accessibilityRole="none"
        accessible={false}
        onPress={onPress}
        style={[{ flex: 1 }, layout]}
      >
        {children}
      </Pressable>
    </View>
  );
}

export interface SheetPanelProps extends ViewProps {
  /** `bottom` slides the full sheet up; `center` rises 24pt and fades (dialogs, menus). */
  from?: 'bottom' | 'center';
  children?: React.ReactNode;
}

/**
 * The panel of a sheet, menu or dialog. Slides up on SPRING.sheet (a
 * DUR.quick fade when reduce motion is on) and swallows taps so they do not
 * reach the scrim behind it.
 */
export function SheetPanel({ from = 'bottom', style, children, ...rest }: SheetPanelProps) {
  const motion = useContext(OverlayContext);
  const travel = from === 'bottom' ? 420 : 24;
  const riseStyle = useAnimatedStyle(() => {
    if (!motion) return {};
    const t = motion.rise.get();
    if (motion.reduced) return { opacity: t };
    return {
      opacity: from === 'center' ? Math.min(1, t * 1.6) : Math.min(1, t * 4),
      transform: [{ translateY: (1 - t) * travel }],
    };
  });

  return (
    <Animated.View
      {...rest}
      onStartShouldSetResponder={() => true}
      // A click inside the panel must not bubble to the scrim's onPress on web.
      {...({ onClick: (event: { stopPropagation: () => void }) => event.stopPropagation() } as object)}
      style={[style, riseStyle]}
    >
      {children}
    </Animated.View>
  );
}
