import React, { forwardRef, useCallback, useState } from 'react';
import {
  Pressable as RNPressable,
  StyleSheet,
  type GestureResponderEvent,
  type LayoutChangeEvent,
  type PressableProps as RNPressableProps,
  type PressableStateCallbackType,
  type StyleProp,
  type View,
  type ViewStyle,
} from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue } from 'react-native-reanimated';

import { DUR, PRESS_SCALE, haptic as fireHaptic, springTo, timeTo, useReduceMotion, type HapticKind } from '@/lib/motion';
import { LAYOUT } from '@/lib/theme';

const AnimatedPressable = Animated.createAnimatedComponent(RNPressable);

export interface PressableProps extends RNPressableProps {
  /**
   * Haptic fired on press. Light by default; `"medium"` for destructive
   * actions; `false` for scrims and wrappers that are not really buttons.
   */
  haptic?: HapticKind | false;
  /**
   * Press-in scale (0.97 by default). `false` for full-screen scrims, sheet
   * bodies and anything that should not visibly move.
   */
  scale?: number | false;
  className?: string;
}

type Slop = { top: number; bottom: number; left: number; right: number };

/**
 * The one pressable. Scales to 0.97 on press-in and springs back
 * (SPRING.press), fires an optional haptic, defaults to
 * `accessibilityRole="button"`, and pads its hit area to 44pt when the
 * element itself is smaller. With reduce motion on it dims instead of scaling.
 *
 * Drop-in for React Native's Pressable: function `style` and function
 * `children` still receive `{ pressed }`.
 */
export const Pressable = forwardRef<View, PressableProps>(function Pressable(
  {
    haptic = 'light',
    scale = PRESS_SCALE,
    style,
    children,
    onPress,
    onPressIn,
    onPressOut,
    onLayout,
    hitSlop,
    disabled,
    accessibilityRole,
    ...rest
  },
  ref,
) {
  const reduced = useReduceMotion();
  const progress = useSharedValue(0);
  const [pressed, setPressed] = useState(false);
  const [slop, setSlop] = useState<Slop | undefined>(undefined);

  const interactive = !disabled && Boolean(onPress || rest.onLongPress);
  const target = scale === false ? 1 : scale;
  const moves = interactive && scale !== false;

  const animated = useAnimatedStyle(() => {
    if (!moves) return {};
    if (reduced) return { opacity: 1 - progress.get() * 0.18 };
    return { transform: [{ scale: 1 - progress.get() * (1 - target) }] };
  }, [moves, reduced, target]);

  const handleIn = useCallback(
    (event: GestureResponderEvent) => {
      setPressed(true);
      if (moves) progress.set(timeTo(1, DUR.tap));
      onPressIn?.(event);
    },
    [moves, onPressIn, progress],
  );

  const handleOut = useCallback(
    (event: GestureResponderEvent) => {
      setPressed(false);
      if (moves) progress.set(springTo(0, 'press', reduced));
      onPressOut?.(event);
    },
    [moves, onPressOut, progress, reduced],
  );

  const handlePress = useCallback(
    (event: GestureResponderEvent) => {
      if (haptic) fireHaptic(haptic);
      onPress?.(event);
    },
    [haptic, onPress],
  );

  const handleLayout = useCallback(
    (event: LayoutChangeEvent) => {
      onLayout?.(event);
      if (hitSlop !== undefined) return;
      const { width, height } = event.nativeEvent.layout;
      const v = Math.max(0, Math.ceil((LAYOUT.hit - height) / 2));
      const h = Math.max(0, Math.ceil((LAYOUT.hit - width) / 2));
      setSlop((current) => {
        if (v === 0 && h === 0) return current === undefined ? current : undefined;
        if (current && current.top === v && current.left === h) return current;
        return { top: v, bottom: v, left: h, right: h };
      });
    },
    [hitSlop, onLayout],
  );

  const state: PressableStateCallbackType = { pressed };
  const resolved = typeof style === 'function' ? style(state) : style;

  return (
    <AnimatedPressable
      ref={ref}
      accessibilityRole={accessibilityRole ?? 'button'}
      {...rest}
      disabled={disabled}
      hitSlop={hitSlop ?? slop}
      onLayout={interactive ? handleLayout : onLayout}
      onPress={onPress ? handlePress : undefined}
      onPressIn={handleIn}
      onPressOut={handleOut}
      style={[resolved as StyleProp<ViewStyle>, animated]}
    >
      {typeof children === 'function' ? children(state) : children}
    </AnimatedPressable>
  );
});

/** Flattened style helper for callers that need to read a pressable's own style. */
export const flattenPressableStyle = (style: StyleProp<ViewStyle>): ViewStyle => StyleSheet.flatten(style) ?? {};
