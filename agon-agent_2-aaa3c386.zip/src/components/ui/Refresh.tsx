import React from 'react';
import { RefreshControl, type RefreshControlProps } from 'react-native';

import { useColors } from '@/lib/theme';

/**
 * The app's one pull-to-refresh control: the same tint on every list, in
 * both schemes. Use as `refreshControl={<Refresh refreshing={…} onRefresh={…} />}`.
 */
export function Refresh(props: RefreshControlProps) {
  const C = useColors();
  return (
    <RefreshControl
      tintColor={C.primaryInk}
      colors={[C.primaryInk]}
      progressBackgroundColor={C.surface}
      {...props}
    />
  );
}
