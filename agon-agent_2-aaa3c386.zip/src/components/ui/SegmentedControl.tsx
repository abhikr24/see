import React, { useEffect, useRef, useState } from 'react';
import { View, type LayoutChangeEvent } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue } from 'react-native-reanimated';
import { springTo, useReduceMotion } from '@/lib/motion';
import { R, S, SHADOW, useColors } from '@/lib/theme';
import { Pressable } from './Pressable';
import { Text } from './Text';

export interface SegmentedOption<T extends string = string> {
  key: T;
  label: string;
  count?: number;
}

export interface SegmentedControlProps<T extends string = string> {
  options: readonly (SegmentedOption<T> | T)[];
  value: T;
  onChange: (value: T) => void;
  size?: 'sm' | 'md';
  className?: string;
}

/**
 * SegmentedControl — pill track, 2–4 options. The selected background
 * slides between options on SPRING.press.
 */
export function SegmentedControl<T extends string = string>({
  options,
  value,
  onChange,
  size = 'md',
  className,
}: SegmentedControlProps<T>) {
  const C = useColors();
  const reduced = useReduceMotion();
  const normalized: SegmentedOption<T>[] = options.map((opt) =>
    typeof opt === 'string' ? { key: opt as T, label: opt } : opt,
  );

  const count = Math.max(2, Math.min(4, normalized.length));
  const items = normalized.slice(0, count);
  const activeIndex = Math.max(
    0,
    items.findIndex((item) => item.key === value),
  );

  const [trackWidth, setTrackWidth] = useState(0);
  const pad = 4;
  const segmentWidth = trackWidth > 0 ? (trackWidth - pad * 2) / items.length : 0;

  const translateX = useSharedValue(0);
  const placed = useRef(false);

  useEffect(() => {
    if (segmentWidth <= 0) return;
    const to = activeIndex * segmentWidth;
    translateX.set(placed.current ? springTo(to, 'press', reduced) : to);
    placed.current = true;
  }, [activeIndex, segmentWidth, translateX, reduced]);

  const thumbStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.get() }],
  }));

  const handleLayout = (e: LayoutChangeEvent) => {
    const w = e.nativeEvent.layout.width;
    if (w > 0 && Math.abs(w - trackWidth) > 0.5) {
      setTrackWidth(w);
    }
  };

  const height = size === 'sm' ? 38 : 44;

  return (
    <View
      className={className}
      onLayout={handleLayout}
      accessibilityRole="tablist"
      style={{
        height,
        borderRadius: R.chip,
        backgroundColor: C.track,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: pad,
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      {segmentWidth > 0 ? (
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: 'absolute',
              left: pad,
              top: pad,
              bottom: pad,
              width: segmentWidth,
              borderRadius: R.chip,
              backgroundColor: C.surface,
              borderWidth: 1,
              borderColor: C.hairline,
              ...SHADOW.raised,
            },
            thumbStyle,
          ]}
        />
      ) : null}

      {items.map((item) => {
        const active = item.key === value;
        return (
          <Pressable
            key={item.key}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            scale={false}
            onPress={() => onChange(item.key)}
            style={{
              flex: 1,
              height: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: S.xs,
              paddingHorizontal: S.sm,
            }}
          >
            <Text
              variant="caption"
              weight={active ? 700 : 600}
              c={active ? C.primaryInk : C.secondary}
              numberOfLines={1}
            >
              {item.label}
              {item.count !== undefined ? ` · ${item.count}` : ''}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
