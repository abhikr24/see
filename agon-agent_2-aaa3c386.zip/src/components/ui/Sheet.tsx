import React, { useCallback, useMemo, useRef } from 'react';
import { Modal, View } from 'react-native';
import BottomSheet, {
  BottomSheetBackdrop,
  BottomSheetView,
  useBottomSheetSpringConfigs,
  useBottomSheetTimingConfigs,
  type BottomSheetBackdropProps,
} from '@gorhom/bottom-sheet';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Ionicons } from '@expo/vector-icons';
import { DUR, EASE, SPRING, useReduceMotion } from '@/lib/motion';
import { R, S, SHADOW, useColors } from '@/lib/theme';
import { Text } from './Text';

import { Pressable } from './Pressable';
export interface SheetProps {
  visible: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  snapPoints?: readonly (string | number)[];
  className?: string;
  children: React.ReactNode;
}

/**
 * Bottom sheet powered by @gorhom/bottom-sheet.
 * Wraps BottomSheet inside a transparent Modal + GestureHandlerRootView so
 * any screen can open it declaratively via `visible`.
 */
export function Sheet({
  visible,
  onClose,
  title,
  subtitle,
  snapPoints: customSnapPoints,
  className,
  children,
}: SheetProps) {
  const C = useColors();
  const sheetRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(
    () => (customSnapPoints ? [...customSnapPoints] : ['58%', '85%']),
    [customSnapPoints],
  );

  // Slides up on SPRING.sheet; a DUR.quick ease when reduce motion is on. The backdrop follows the sheet.
  const reduced = useReduceMotion();
  const spring = useBottomSheetSpringConfigs({ ...SPRING.sheet, overshootClamping: false });
  const timing = useBottomSheetTimingConfigs({ duration: DUR.quick, easing: EASE.out });

  const renderBackdrop = useCallback(
    (props: BottomSheetBackdropProps) => (
      <BottomSheetBackdrop
        {...props}
        appearsOnIndex={0}
        disappearsOnIndex={-1}
        pressBehavior="close"
        opacity={0.45}
      />
    ),
    [],
  );

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="none" onRequestClose={onClose}>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <BottomSheet
          ref={sheetRef}
          index={0}
          snapPoints={snapPoints}
          enablePanDownToClose
          animationConfigs={reduced ? timing : spring}
          onClose={onClose}
          backdropComponent={renderBackdrop}
          handleIndicatorStyle={{
            backgroundColor: C.hairline,
            width: 40,
            height: 4,
          }}
          backgroundStyle={{
            backgroundColor: C.surface,
            borderTopLeftRadius: R.sheet,
            borderTopRightRadius: R.sheet,
            ...SHADOW.overlay,
          }}
        >
          <BottomSheetView
            style={{
              paddingHorizontal: S.xl,
              paddingBottom: S.xxxl,
              paddingTop: S.xs,
            }}
          >
            <View className={className}>
              {title ? (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: subtitle ? 4 : S.md,
                  }}
                >
                  <Text variant="h2" style={{ flex: 1 }}>
                    {title}
                  </Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={title ? `Close ${title}` : 'Close sheet'}
                    onPress={onClose}
                    hitSlop={12}
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 16,
                      backgroundColor: C.track,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Ionicons name="close" size={18} color={C.secondary} />
                  </Pressable>
                </View>
              ) : null}
              {subtitle ? (
                <Text variant="caption" c={C.secondary} style={{ marginBottom: S.md }}>
                  {subtitle}
                </Text>
              ) : null}
              {children}
            </View>
          </BottomSheetView>
        </BottomSheet>
      </GestureHandlerRootView>
    </Modal>
  );
}
