import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { R, S, TONE, useColors, type Tone } from '@/lib/theme';
import { Card } from './Card';
import { Text } from './Text';

export type StatTrend = 'up' | 'down' | 'warning' | 'neutral';

export interface StatCardProps {
  label: string;
  value: string | number;
  delta?: string;
  trend?: StatTrend;
  subtitle?: string;
  flat?: boolean;
  tint?: string;
  onPress?: () => void;
  className?: string;
}

const TREND_CONFIG: Record<StatTrend, { tone: Tone; icon: keyof typeof Ionicons.glyphMap }> = {
  up: { tone: 'teal', icon: 'trending-up-outline' },
  down: { tone: 'danger', icon: 'trending-down-outline' },
  warning: { tone: 'warning', icon: 'alert-circle-outline' },
  neutral: { tone: 'neutral', icon: 'remove-outline' },
};

/**
 * StatCard — label + big tabular value + optional delta and trend colour.
 * Carries the 1px inner top highlight.
 */
export function StatCard({
  label,
  value,
  delta,
  trend = 'neutral',
  subtitle,
  flat = true,
  tint,
  onPress,
  className,
}: StatCardProps) {
  const C = useColors();
  const trendStyle = { ...TONE[TREND_CONFIG[trend].tone], icon: TREND_CONFIG[trend].icon };

  return (
    <Card flat={flat} tint={tint} onPress={onPress} highlight className={className}>
      <View style={{ gap: S.xs }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: S.sm,
          }}
        >
          <Text variant="label" c={C.muted} numberOfLines={1} style={{ flex: 1 }}>
            {label}
          </Text>
          {delta ? (
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 4,
                backgroundColor: trendStyle.bg,
                paddingHorizontal: 8,
                paddingVertical: 3,
                borderRadius: R.chip,
              }}
            >
              <Ionicons name={trendStyle.icon} size={12} color={trendStyle.fg} />
              <Text variant="label" weight={700} c={trendStyle.fg} tabular style={{ fontSize: 10 }}>
                {delta}
              </Text>
            </View>
          ) : null}
        </View>

        <Text variant="h1" weight={800} tabular style={{ fontSize: 30, marginTop: 2 }}>
          {value}
        </Text>

        {subtitle ? (
          <Text variant="caption" c={C.secondary} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    </Card>
  );
}
