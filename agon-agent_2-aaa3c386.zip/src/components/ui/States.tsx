import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import Animated, {
  cancelAnimation,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withRepeat,
  withSequence,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { DUR, EASE, LIFE, timeTo, useReduceMotion } from '@/lib/motion';
import { R, RHYTHM, useColors, type Tone } from '@/lib/theme';
import { Text } from './Text';
import { Button } from './Button';
import { EmptyArt } from './EmptyArt';

export interface SkeletonProps {
  h?: number;
  w?: number | string;
  r?: number;
  className?: string;
}

/**
 * A placeholder bar. A soft light band sweeps across it over DUR.slow, rests,
 * and repeats. The bar's own size never changes, so nothing reflows. With
 * reduce motion on the bar is still.
 */
export function Skeleton({ h = 16, w = '100%', r = 8, className }: SkeletonProps) {
  const C = useColors();
  const reduced = useReduceMotion();
  const [width, setWidth] = useState(0);
  const sweep = useSharedValue(0);

  useEffect(() => {
    if (reduced || width <= 0) return;
    sweep.set(0);
    sweep.set(
      withRepeat(
        withSequence(timeTo(1, DUR.slow, EASE.inOut), withDelay(LIFE.shimmerRest, timeTo(1, 0))),
        -1,
        false,
      ),
    );
    return () => cancelAnimation(sweep);
  }, [reduced, width, sweep]);

  const band = useAnimatedStyle(() => ({
    transform: [{ translateX: -width + sweep.get() * width * 2 }],
  }));

  return (
    <View
      className={className}
      onLayout={(event) => {
        const next = event.nativeEvent.layout.width;
        if (Math.abs(next - width) > 0.5) setWidth(next);
      }}
      style={{ height: h, width: w as number, borderRadius: r, backgroundColor: C.track, overflow: 'hidden' }}
    >
      {!reduced && width > 0 ? (
        <Animated.View pointerEvents="none" style={[{ position: 'absolute', top: 0, bottom: 0, left: 0, width }, band]}>
          <LinearGradient
            colors={[C.shimmerEdge, C.shimmer, C.shimmerEdge]}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            style={{ flex: 1 }}
          />
        </Animated.View>
      ) : null}
    </View>
  );
}

export interface ListSkeletonProps {
  rows?: number;
  h?: number;
  className?: string;
}

export function ListSkeleton({ rows = 5, h = 68, className }: ListSkeletonProps) {
  const C = useColors();
  return (
    <View className={className} style={{ gap: RHYTHM.card }}>
      {Array.from({ length: rows }).map((_, i) => (
        <View
          key={i}
          style={{
            height: h,
            borderRadius: R.card,
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            padding: 14,
            flexDirection: 'row',
            gap: 12,
            alignItems: 'center',
          }}
        >
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.track }} />
          <View style={{ flex: 1, gap: 8 }}>
            <Skeleton h={12} w="55%" />
            <Skeleton h={10} w="35%" />
          </View>
        </View>
      ))}
    </View>
  );
}

/** Content-shaped skeleton: icon + two lines + card list, no layout shift. */
export function CardGridSkeleton({ rows = 3 }: { rows?: number }) {
  const C = useColors();
  return (
    <View style={{ gap: RHYTHM.card }}>
      {Array.from({ length: rows }).map((_, i) => (
        <View
          key={i}
          style={{
            height: 96,
            borderRadius: R.card,
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            padding: 14,
            gap: 10,
          }}
        >
          <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: C.track }} />
            <View style={{ flex: 1, gap: 8 }}>
              <Skeleton h={12} w="45%" />
              <Skeleton h={10} w="65%" />
            </View>
            <Skeleton h={22} w={64} r={R.chip} />
          </View>
          <Skeleton h={8} w="100%" r={6} />
        </View>
      ))}
    </View>
  );
}

export type EmptyVariant = 'students' | 'homework' | 'payments' | 'approvals';

const VARIANT_PRESET: Record<EmptyVariant, { icon: keyof typeof Ionicons.glyphMap; tone: Tone; title: string; text: string }> = {
  students: {
    icon: 'people-outline',
    tone: 'primary',
    title: 'No students yet',
    text: 'Admissions land here. Add your first student or convert an enquiry to get started.',
  },
  homework: {
    icon: 'book-outline',
    tone: 'teal',
    title: 'No homework due',
    text: 'You’re all caught up. New assignments will appear here when a teacher sends them.',
  },
  payments: {
    icon: 'wallet-outline',
    tone: 'accent',
    title: 'No payments yet',
    text: 'Fees you collect will show here. Pull to refresh or tap Collect to record one.',
  },
  approvals: {
    icon: 'checkmark-done-circle-outline',
    tone: 'success',
    title: 'Nothing to approve',
    text: 'New join requests will appear here. Share your institute code so students can find you.',
  },
};

export interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  tone?: Tone;
  title?: string;
  text?: string;
  variant?: EmptyVariant;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  icon,
  tone,
  title,
  text,
  variant,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  const C = useColors();
  const preset = variant ? VARIANT_PRESET[variant] : null;
  const resolvedIcon = icon ?? preset?.icon ?? 'file-tray-outline';
  const resolvedTone = tone ?? preset?.tone ?? 'primary';
  const resolvedTitle = title ?? preset?.title ?? 'Nothing here yet';
  const resolvedText = text ?? preset?.text ?? undefined;
  return (
    <View
      className={className}
      style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}
    >
      <View style={{ marginBottom: 4 }}>
        <EmptyArt icon={resolvedIcon} tone={resolvedTone} size={88} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>
        {resolvedTitle}
      </Text>
      {resolvedText ? (
        <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 280 }}>
          {resolvedText}
        </Text>
      ) : null}
      {actionLabel && onAction ? (
        <View style={{ marginTop: 10 }}>
          <Button title={actionLabel} onPress={onAction} size="md" full={false} />
        </View>
      ) : null}
    </View>
  );
}

export interface ErrorStateProps {
  title?: string;
  /**
   * What could not be loaded, as it would finish "Could not load …" — e.g.
   * "the students list". Shown above the backend's own message so the person
   * knows which part of the screen failed.
   */
  what?: string;
  message: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorState({
  title = 'This is on us, not on you',
  what,
  message,
  onRetry,
  className,
}: ErrorStateProps) {
  const C = useColors();
  return (
    <View
      className={className}
      style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}
    >
      <View style={{ marginBottom: 4 }}>
        <EmptyArt icon="cloud-offline-outline" tone="primary" size={88} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 280 }}>
        {what ? `Could not load ${what}. ` : ''}
        {message}
      </Text>
      {onRetry ? (
        <View style={{ marginTop: 10 }}>
          <Button
            title="Try again"
            accessibilityLabel={what ? `Try loading ${what} again` : 'Try again'}
            onPress={onRetry}
            size="md"
            full={false}
          />
        </View>
      ) : null}
    </View>
  );
}
