import React, { useCallback, useEffect, useId, useMemo } from 'react';
import { View, type AccessibilityActionEvent, type StyleProp, type ViewStyle } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue } from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { Ionicons } from '@expo/vector-icons';

import { haptic, springTo, useReduceMotion } from '@/lib/motion';
import { R, TONE, useColors, type Tone } from '@/lib/theme';
import { Pressable } from './Pressable';
import { Text } from './Text';

export interface SwipeAction {
  /** Short visible label under the icon, e.g. "Remind". */
  label: string;
  /** Full name for screen readers: object and action, e.g. "Remind Aarav Sharma about the fee". */
  accessibilityLabel: string;
  icon: keyof typeof Ionicons.glyphMap;
  tone?: Tone;
  /** Fires a medium haptic instead of a light one. */
  destructive?: boolean;
  onPress: () => void;
  testID?: string;
}

export interface SwipeRowProps {
  /** Revealed by swiping the row to the right; sits under its left edge. */
  leading?: SwipeAction;
  /** Revealed by swiping the row to the left; sits under its right edge. */
  trailing?: SwipeAction;
  children: React.ReactNode;
  /** Corner radius of the row, so the revealed action matches it. */
  radius?: number;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}

/** Width of a revealed action. */
const ACTION_W = 88;
/** Past this the row settles open instead of closed. */
const OPEN_AT = ACTION_W * 0.45;

/** Only one row is open at a time. */
let openRowId: string | null = null;
const closers = new Map<string, () => void>();

/**
 * Swipe-to-reveal for list rows. One action per side, each an existing action
 * of the row — nothing here is gesture-only:
 *   · the revealed buttons are real, focusable buttons (focusing one with the
 *     keyboard opens that side), and
 *   · the row exposes the same actions as accessibility actions, so VoiceOver
 *     and TalkBack list them in the row's actions menu.
 * A horizontal pan must clear 12pt before it takes over, so the list still
 * scrolls and a tap still opens the row.
 */
export function SwipeRow({ leading, trailing, children, radius = R.btn, style, disabled }: SwipeRowProps) {
  const C = useColors();
  const reduced = useReduceMotion();
  const x = useSharedValue(0);
  const start = useSharedValue(0);
  const id = useId();

  const maxRight = leading ? ACTION_W : 0;
  const maxLeft = trailing ? -ACTION_W : 0;

  const close = useCallback(() => {
    x.set(springTo(0, 'press', reduced));
    if (openRowId === id) openRowId = null;
  }, [id, reduced, x]);

  useEffect(() => {
    closers.set(id, close);
    return () => {
      closers.delete(id);
      if (openRowId === id) openRowId = null;
    };
  }, [id, close]);

  const claim = useCallback(() => {
    if (openRowId && openRowId !== id) closers.get(openRowId)?.();
    openRowId = id;
    haptic('light');
  }, [id]);

  const open = useCallback(
    (side: 'leading' | 'trailing') => {
      claim();
      x.set(springTo(side === 'leading' ? maxRight : maxLeft, 'press', reduced));
    },
    [claim, maxLeft, maxRight, reduced, x],
  );

  const run = useCallback(
    (action: SwipeAction) => {
      close();
      action.onPress();
    },
    [close],
  );

  const pan = useMemo(
    () =>
      Gesture.Pan()
        .enabled(!disabled && Boolean(leading || trailing))
        .activeOffsetX([-12, 12])
        .failOffsetY([-10, 10])
        .onStart(() => {
          start.set(x.get());
        })
        .onUpdate((event) => {
          const next = start.get() + event.translationX;
          // Rubber-band a little past the action, and not at all on a side with no action.
          const over = next > maxRight ? maxRight + (next - maxRight) * 0.2 : next < maxLeft ? maxLeft + (next - maxLeft) * 0.2 : next;
          x.set(over);
        })
        .onEnd((event) => {
          const projected = x.get() + event.velocityX * 0.08;
          if (projected > OPEN_AT && maxRight > 0) scheduleOnRN(open, 'leading');
          else if (projected < -OPEN_AT && maxLeft < 0) scheduleOnRN(open, 'trailing');
          else scheduleOnRN(close);
        }),
    [close, disabled, leading, maxLeft, maxRight, open, start, trailing, x],
  );

  const rowMotion = useAnimatedStyle(() => ({ transform: [{ translateX: x.get() }] }));
  const leadMotion = useAnimatedStyle(() => ({ opacity: Math.min(1, Math.max(0, x.get() / OPEN_AT)) }));
  const trailMotion = useAnimatedStyle(() => ({ opacity: Math.min(1, Math.max(0, -x.get() / OPEN_AT)) }));

  const actions = useMemo(
    () =>
      [leading, trailing]
        .filter((action): action is SwipeAction => Boolean(action))
        .map((action) => ({ name: action.label, label: action.accessibilityLabel })),
    [leading, trailing],
  );

  const onAccessibilityAction = useCallback(
    (event: AccessibilityActionEvent) => {
      const picked = [leading, trailing].find((action) => action?.label === event.nativeEvent.actionName);
      if (picked) run(picked);
    },
    [leading, run, trailing],
  );

  const button = (action: SwipeAction, side: 'leading' | 'trailing', motion: typeof leadMotion) => {
    const tone = TONE[action.tone ?? 'primary'];
    return (
      <Animated.View
        style={[
          {
            position: 'absolute',
            top: 0,
            bottom: 0,
            width: ACTION_W,
            [side === 'leading' ? 'left' : 'right']: 0,
            paddingRight: side === 'leading' ? 8 : 0,
            paddingLeft: side === 'trailing' ? 8 : 0,
          },
          motion,
        ]}
      >
        <Pressable
          testID={action.testID}
          accessibilityLabel={action.accessibilityLabel}
          haptic={action.destructive ? 'medium' : 'light'}
          onFocus={() => open(side)}
          onBlur={close}
          onPress={() => run(action)}
          style={{
            flex: 1,
            borderRadius: radius,
            backgroundColor: tone.bg,
            alignItems: 'center',
            justifyContent: 'center',
            gap: 4,
          }}
        >
          <Ionicons name={action.icon} size={20} color={tone.fg} />
          <Text variant="label" weight={700} c={tone.fg} numberOfLines={1} style={{ textTransform: 'none', letterSpacing: 0 }}>
            {action.label}
          </Text>
        </Pressable>
      </Animated.View>
    );
  };

  if (!leading && !trailing) return <View style={style}>{children}</View>;

  return (
    <View
      style={style}
      accessibilityActions={actions}
      onAccessibilityAction={onAccessibilityAction}
    >
      {leading ? button(leading, 'leading', leadMotion) : null}
      {trailing ? button(trailing, 'trailing', trailMotion) : null}
      <GestureDetector gesture={pan}>
        <Animated.View style={[{ backgroundColor: C.transparent }, rowMotion]}>{children}</Animated.View>
      </GestureDetector>
    </View>
  );
}
