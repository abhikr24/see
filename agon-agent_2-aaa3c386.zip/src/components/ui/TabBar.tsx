import React, { useEffect, useRef, useState } from 'react';
import { View, type LayoutChangeEvent } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSequence } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { badgeLabel } from '@/lib/format';
import { DUR, springTo, timeTo, useReduceMotion } from '@/lib/motion';
import { SHADOW, useColors } from '@/lib/theme';
import { TopHighlight } from './Card';
import { Pressable } from './Pressable';
import { Text } from './Text';
import type { TabDef } from '@/lib/nav';

export interface TabBarProps {
  tabs: readonly TabDef[];
  selectedKey?: string;
  onSelect?: (key: string) => void;
  className?: string;
}

const PILL_W = 46;
const PILL_H = 28;
const PAD = 8;
const RADIUS = 28;

/**
 * The floating pill tab bar. The active pill slides between tabs on
 * SPRING.press, icons cross-fade outline ↔ filled over DUR.quick, and a badge
 * pops when its count changes.
 */
export function TabBar({ tabs, selectedKey = 'home', onSelect, className }: TabBarProps) {
  const C = useColors();
  const reduced = useReduceMotion();
  const [width, setWidth] = useState(0);
  const index = Math.max(0, tabs.findIndex((t) => t.key === selectedKey));
  const known = tabs.some((t) => t.key === selectedKey);
  // The measured width includes the 1px border on each side.
  const slot = width > 0 ? (width - 2 - PAD * 2) / tabs.length : 0;
  const x = useSharedValue(0);
  const placed = useRef(false);

  useEffect(() => {
    if (slot <= 0) return;
    const to = PAD + index * slot + (slot - PILL_W) / 2;
    // The first placement is not a journey: the pill is simply there.
    x.set(placed.current ? springTo(to, 'press', reduced) : to);
    placed.current = true;
  }, [index, slot, x, reduced]);

  const pill = useAnimatedStyle(() => ({ transform: [{ translateX: x.get() }] }));

  const onLayout = (event: LayoutChangeEvent) => {
    const w = event.nativeEvent.layout.width;
    if (Math.abs(w - width) > 0.5) setWidth(w);
  };

  return (
    <View
      className={className}
      onLayout={onLayout}
      accessibilityRole="tablist"
      style={{
        flexDirection: 'row',
        backgroundColor: C.surface,
        borderRadius: RADIUS,
        borderWidth: 1,
        borderColor: C.hairline,
        paddingVertical: PAD,
        paddingHorizontal: PAD,
        marginHorizontal: 4,
        ...SHADOW.overlay,
      }}
    >
      <TopHighlight radius={RADIUS} />
      {slot > 0 && known ? (
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: 'absolute',
              left: 0,
              top: PAD + 4,
              width: PILL_W,
              height: PILL_H,
              borderRadius: PILL_H / 2,
              backgroundColor: C.navySoft,
            },
            pill,
          ]}
        />
      ) : null}
      {tabs.map((t) => {
        const active = selectedKey === t.key;
        const badge = badgeLabel(t.badge);
        return (
          <Pressable
            key={t.key}
            accessibilityRole="tab"
            accessibilityLabel={badge ? `${t.label}, ${badge} new` : t.label}
            accessibilityState={{ selected: active }}
            onPress={() => onSelect?.(t.key)}
            style={{ flex: 1, alignItems: 'center', gap: 3, paddingVertical: 4 }}
          >
            <View style={{ width: PILL_W, height: PILL_H, alignItems: 'center', justifyContent: 'center' }}>
              <TabIcon icon={t.icon} iconActive={t.iconActive} active={active} />
              {badge ? <TabBadge tabKey={t.key} label={badge} /> : null}
            </View>
            <Text variant="label" weight={600} c={active ? C.primaryInk : C.muted} style={{ fontSize: 9.5 }}>
              {t.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/** Outline and filled glyphs stacked; the pair cross-fades over DUR.quick. */
function TabIcon({ icon, iconActive, active }: { icon: string; iconActive: string; active: boolean }) {
  const C = useColors();
  const on = useSharedValue(active ? 1 : 0);
  useEffect(() => {
    on.set(timeTo(active ? 1 : 0, DUR.quick));
  }, [active, on]);
  const filled = useAnimatedStyle(() => ({ opacity: on.get() }));
  const outline = useAnimatedStyle(() => ({ opacity: 1 - on.get() }));
  return (
    <View style={{ width: 20, height: 20 }}>
      <Animated.View style={[{ position: 'absolute' }, outline]}>
        <Ionicons name={icon as keyof typeof Ionicons.glyphMap} size={20} color={C.muted} />
      </Animated.View>
      <Animated.View style={[{ position: 'absolute' }, filled]}>
        <Ionicons name={iconActive as keyof typeof Ionicons.glyphMap} size={20} color={C.primaryInk} />
      </Animated.View>
    </View>
  );
}

/** The unread badge. Pops on SPRING.press whenever its label changes. */
function TabBadge({ tabKey, label }: { tabKey: string; label: string }) {
  const C = useColors();
  const reduced = useReduceMotion();
  const scale = useSharedValue(1);
  const seen = useRef(label);
  useEffect(() => {
    if (seen.current === label) return;
    seen.current = label;
    if (reduced) return;
    scale.set(withSequence(timeTo(1.28, DUR.tap), springTo(1, 'press', false)));
  }, [label, reduced, scale]);
  const pop = useAnimatedStyle(() => ({ transform: [{ scale: scale.get() }] }));
  return (
    <Animated.View
      testID={`tab-badge-${tabKey}`}
      style={[
        {
          position: 'absolute',
          right: label.length > 1 ? -6 : -2,
          top: -4,
          minWidth: 16,
          height: 16,
          paddingHorizontal: 3,
          borderRadius: 8,
          backgroundColor: C.danger,
          alignItems: 'center',
          justifyContent: 'center',
          borderWidth: 1.5,
          borderColor: C.surface,
        },
        pop,
      ]}
    >
      <Text variant="label" weight={700} c={C.onFill} style={{ fontSize: 9, lineHeight: 11 }}>
        {label}
      </Text>
    </Animated.View>
  );
}
