import React from 'react';
import { StyleSheet, Text as RNText, type TextProps as RNTextProps, type TextStyle } from 'react-native';
import { FONT_SIZE, FONT, TYPE, useColors } from '@/lib/theme';

export type TextVariant = 'h1' | 'h2' | 'title' | 'body' | 'caption' | 'label';
export type TextWeight = 500 | 600 | 700 | 800;

const SIZE: Record<TextVariant, number> = FONT_SIZE;
const DEFAULT_WEIGHT: Record<TextVariant, TextWeight> = {
  h1: 800,
  h2: 700,
  title: 700,
  body: 500,
  caption: 500,
  label: 600,
};

/** Line-height ratio per variant: headings 1.15, body 1.45, captions and labels 1.35. */
const LINE: Record<TextVariant, number> = {
  h1: TYPE.headingLine,
  h2: TYPE.headingLine,
  title: TYPE.headingLine,
  body: TYPE.bodyLine,
  caption: TYPE.captionLine,
  label: TYPE.captionLine,
};

const HEADING: Record<TextVariant, boolean> = { h1: true, h2: true, title: true, body: false, caption: false, label: false };

const TABULAR = ['tabular-nums'] as const;

export interface TextProps extends RNTextProps {
  variant?: TextVariant;
  weight?: TextWeight;
  c?: string;
  /** Kept for call sites that ask for it; every Text now sets tabular figures. */
  tabular?: boolean;
  className?: string;
}

/**
 * The app's text. One rhythm for all of it:
 *   · every figure is tabular, so numbers never jitter as they change;
 *   · anything at 22pt and above (the big figures and screen titles) tracks at -0.5;
 *   · headings track at -0.3 with a 1.15 line; body 1.45; captions 1.35.
 * The line height follows the final font size, including a `style` override.
 */
export function Text({
  variant = 'body',
  weight,
  c,
  tabular: _tabular,
  className,
  style,
  children,
  ...rest
}: TextProps) {
  const C = useColors();
  const override = style ? (StyleSheet.flatten(style) as TextStyle | undefined) : undefined;
  const size = typeof override?.fontSize === 'number' ? override.fontSize : SIZE[variant];
  const tracking =
    variant === 'label'
      ? 0.66
      : size >= TYPE.displayMin
        ? TYPE.displayTracking
        : HEADING[variant]
          ? TYPE.headingTracking
          : undefined;

  return (
    <RNText
      {...rest}
      className={className}
      style={[
        {
          fontSize: SIZE[variant],
          lineHeight: Math.round(size * LINE[variant]),
          fontFamily: variant === 'h1' || variant === 'h2' ? FONT.heading : FONT.body,
          fontWeight: String(weight ?? DEFAULT_WEIGHT[variant]) as TextStyle['fontWeight'],
          color: c ?? C.ink,
          fontVariant: TABULAR as unknown as TextStyle['fontVariant'],
          ...(tracking !== undefined ? { letterSpacing: tracking } : null),
          ...(variant === 'label' ? { textTransform: 'uppercase' as const } : null),
        },
        style,
      ]}
    >
      {children}
    </RNText>
  );
}
