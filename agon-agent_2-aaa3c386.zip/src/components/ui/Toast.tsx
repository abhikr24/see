import React, { useEffect } from 'react';
import { View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue } from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { Ionicons } from '@expo/vector-icons';
import { DUR, EASE, springTo, timeTo, useReduceMotion } from '@/lib/motion';
import { R, S, SHADOW, useColors, type Palette } from '@/lib/theme';
import { Pressable } from './Pressable';
import { Text } from './Text';

export type ToastVariant = 'success' | 'error' | 'info';

export interface ToastActionProps {
  label: string;
  accessibilityLabel?: string;
  testID?: string;
  onPress: () => void;
}

export interface ToastProps {
  kind?: ToastVariant;
  message: string;
  subtitle?: string;
  visible?: boolean;
  onDismiss?: () => void;
  /**
   * Auto-dismiss timer in ms. Pass 0 to disable auto-dismiss (inline previews,
   * errors, and bars whose lifetime the caller owns).
   */
  autoDismissMs?: number;
  /** Draws the remaining time as a hairline along the bottom edge. */
  progress?: boolean;
  /** Undo mode: one action on the right, swipe sideways to dismiss. */
  action?: ToastActionProps;
  bottomOffset?: number;
  floating?: boolean;
  testID?: string;
  className?: string;
}

function toastStyle(C: Palette, kind: ToastVariant): { accent: string; soft: string; icon: keyof typeof Ionicons.glyphMap } {
  if (kind === 'success') return { accent: C.successInk, soft: C.successSoft, icon: 'checkmark-circle' };
  if (kind === 'error') return { accent: C.dangerInk, soft: C.dangerSoft, icon: 'alert-circle' };
  return { accent: C.primaryInk, soft: C.navySoft, icon: 'information-circle' };
}

/** Distance a toast must be dragged sideways before it counts as dismissed. */
const SWIPE_AWAY = 96;

/**
 * Toast — success / error / info with a distinct icon and tone each. Rises
 * with SPRING.sheet, shows its remaining life as a hairline, and (with an
 * `action`) doubles as the undo bar. One implementation for both.
 */
export function Toast({
  kind = 'info',
  message,
  subtitle,
  visible = true,
  onDismiss,
  autoDismissMs = 0,
  progress = false,
  action,
  bottomOffset = 24,
  floating = false,
  testID,
  className,
}: ToastProps) {
  const C = useColors();
  const reduced = useReduceMotion();
  const enter = useSharedValue(0);
  const dragX = useSharedValue(0);
  const life = useSharedValue(1);

  useEffect(() => {
    if (!visible) return;
    enter.set(0);
    enter.set(springTo(1, 'sheet', reduced));
  }, [visible, enter, reduced]);

  useEffect(() => {
    if (!visible || autoDismissMs <= 0) return;
    life.set(1);
    life.set(timeTo(0, autoDismissMs, EASE.inOut));
    if (!onDismiss) return;
    const timer = setTimeout(onDismiss, autoDismissMs);
    return () => clearTimeout(timer);
  }, [visible, onDismiss, autoDismissMs, life]);

  const cardMotion = useAnimatedStyle(() => ({
    opacity: enter.get() * (1 - Math.min(1, Math.abs(dragX.get()) / (SWIPE_AWAY * 2))),
    transform: [{ translateY: reduced ? 0 : (1 - enter.get()) * 24 }, { translateX: dragX.get() }],
  }));
  const lifeMotion = useAnimatedStyle(() => ({ transform: [{ scaleX: life.get() }] }));

  const swipe = Gesture.Pan()
    .enabled(Boolean(onDismiss))
    .activeOffsetX([-12, 12])
    .failOffsetY([-12, 12])
    .onUpdate((event) => {
      dragX.set(event.translationX);
    })
    .onEnd((event) => {
      if (Math.abs(event.translationX) > SWIPE_AWAY && onDismiss) {
        dragX.set(timeTo(Math.sign(event.translationX) * 420, DUR.quick));
        scheduleOnRN(onDismiss);
      } else {
        dragX.set(springTo(0, 'press', reduced));
      }
    });

  if (!visible) return null;

  const cfg = toastStyle(C, kind);

  const card = (
    <GestureDetector gesture={swipe}>
      <Animated.View
        testID={testID}
        accessibilityRole="alert"
        accessibilityLiveRegion={kind === 'error' ? 'assertive' : 'polite'}
        className={className}
        style={[
          {
            backgroundColor: C.surface,
            borderRadius: R.btn,
            borderWidth: 1,
            borderColor: C.hairline,
            overflow: 'hidden',
            ...SHADOW.overlay,
          },
          cardMotion,
        ]}
      >
        <View
          style={{
            borderLeftWidth: 4,
            borderLeftColor: cfg.accent,
            paddingVertical: 12,
            paddingLeft: 12,
            paddingRight: action ? 6 : 14,
            flexDirection: 'row',
            alignItems: 'center',
            gap: S.md,
            minHeight: 56,
          }}
        >
          <View
            style={{
              width: 34,
              height: 34,
              borderRadius: 17,
              backgroundColor: cfg.soft,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name={action ? 'arrow-undo' : cfg.icon} size={action ? 17 : 20} color={cfg.accent} />
          </View>

          <View style={{ flex: 1, gap: 2 }}>
            <Text variant="body" weight={700} c={C.ink} style={{ fontSize: 14 }} numberOfLines={action ? 2 : 4}>
              {message}
            </Text>
            {subtitle ? (
              <Text variant="caption" c={C.secondary} style={{ fontSize: 12 }}>
                {subtitle}
              </Text>
            ) : null}
          </View>

          {action ? (
            <Pressable
              testID={action.testID}
              accessibilityLabel={action.accessibilityLabel ?? `${action.label}: ${message}`}
              onPress={action.onPress}
              style={({ pressed }) => ({
                minHeight: 44,
                paddingHorizontal: 14,
                borderRadius: R.field,
                justifyContent: 'center',
                backgroundColor: pressed ? C.accentSoft : C.transparent,
              })}
            >
              <Text variant="caption" weight={800} c={C.accentInk} style={{ textTransform: 'uppercase' }}>
                {action.label}
              </Text>
            </Pressable>
          ) : onDismiss ? (
            <Pressable
              accessibilityLabel={`Dismiss message: ${message}`}
              onPress={onDismiss}
              hitSlop={12}
              style={{ width: 28, height: 28, alignItems: 'center', justifyContent: 'center' }}
            >
              <Ionicons name="close" size={18} color={C.muted} />
            </Pressable>
          ) : null}
        </View>

        {progress && autoDismissMs > 0 ? (
          <Animated.View
            pointerEvents="none"
            style={[
              {
                position: 'absolute',
                left: 0,
                right: 0,
                bottom: 0,
                height: 2,
                backgroundColor: cfg.accent,
                transformOrigin: 'left',
              },
              lifeMotion,
            ]}
          />
        ) : null}
      </Animated.View>
    </GestureDetector>
  );

  if (!floating) return card;

  return (
    <View
      pointerEvents="box-none"
      style={{
        position: 'absolute',
        left: 20,
        right: 20,
        bottom: bottomOffset,
        zIndex: 50,
      }}
    >
      {card}
    </View>
  );
}
