import { useEffect, useRef } from 'react';

import { toast, type UndoOptions } from '@/core/hooks/toast';

export interface UndoBarProps {
  /** While true the bar is up. The caller owns the window; hide it to dismiss. */
  visible: boolean;
  /** What happened, e.g. "Notification dismissed". */
  message: string;
  /** The inverse of what happened. */
  onUndo: () => void;
  /** Screen-reader name of the action, e.g. "Undo dismiss". */
  accessibilityLabel?: string;
  testID?: string;
  actionTestID?: string;
}

/**
 * Offers the inverse of something that has already happened. Call it after a
 * reversible destructive action (archive a batch, delete a notice): the bar
 * rises above the tab bar, says what happened, auto-dismisses after LIFE.undo
 * and can be swiped away.
 *
 * It is the toast in undo mode — the same card, queue and position — not a
 * second snackbar. See `Toast` and `ToastHost`.
 */
export function showUndo(message: string, onUndo: () => void, options?: UndoOptions): number {
  return toast.undo(message, onUndo, options).id;
}

/**
 * Declarative form of `showUndo` for screens that already track a pending
 * action in state: the bar is up exactly while `visible` is true.
 */
export function UndoBar({ visible, message, onUndo, accessibilityLabel, testID, actionTestID }: UndoBarProps) {
  const undo = useRef(onUndo);
  useEffect(() => {
    undo.current = onUndo;
  }, [onUndo]);

  useEffect(() => {
    if (!visible) return;
    const id = showUndo(message, () => undo.current(), {
      life: null,
      accessibilityLabel,
      testID,
      actionTestID,
    });
    return () => toast.dismiss(id);
  }, [visible, message, accessibilityLabel, testID, actionTestID]);

  return null;
}
