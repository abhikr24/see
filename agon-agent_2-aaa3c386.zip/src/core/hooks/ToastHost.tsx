import { useCallback, useEffect, useState, useSyncExternalStore } from 'react';
import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Toast as ToastCard } from '@/components/ui/Toast';
import { LIFE, TOAST_MAX } from '@/lib/motion';
import { toast, type Toast } from './toast';

/** Toasts waiting for a slot. Older waiting ones are dropped beyond this. */
const WAITING_MAX = 3;

const lifeOf = (item: Toast): number => {
  if (item.life === null) return 0;
  if (item.life !== undefined) return item.life;
  if (item.action) return LIFE.undo;
  return item.kind === 'error' ? 0 : LIFE.toast;
};

/**
 * The toast stack. Mounted once, by BackendProvider.
 *
 * `items` is in arrival order. The first TOAST_MAX are on screen, drawn newest
 * on top; the rest wait for a slot. Success and info leave after LIFE.toast
 * with a progress hairline; errors stay until dismissed; an undo toast is the
 * same card with an action. The stack sits above the floating tab bar and
 * inside the safe area.
 */
export function ToastHost() {
  const insets = useSafeAreaInsets();
  const chrome = useSyncExternalStore(toast.subscribeBottomInset, toast.getBottomInset, toast.getBottomInset);
  const [items, setItems] = useState<Toast[]>([]);

  useEffect(
    () =>
      toast.subscribe((event) => {
        if (event.type === 'dismiss') {
          setItems((current) => current.filter((item) => item.id !== event.id));
          return;
        }
        const incoming = event.toast;
        setItems((current) => {
          // The same words twice is one toast, and an undo offer absorbs the plain toast it follows.
          let next = current.filter((item) => item.message !== incoming.message || (item.action && !incoming.action));
          if (next.some((item) => item.message === incoming.message)) return current;
          next = [...next, incoming];
          // Two errors must not hold the stack shut: the older one gives way.
          const shown = next.slice(0, TOAST_MAX);
          if (next.length > TOAST_MAX && shown.every((item) => lifeOf(item) === 0)) next = next.slice(1);
          const overflow = next.length - TOAST_MAX - WAITING_MAX;
          return overflow > 0 ? [...next.slice(0, TOAST_MAX), ...next.slice(TOAST_MAX + overflow)] : next;
        });
      }),
    [],
  );

  const remove = useCallback((id: number) => setItems((current) => current.filter((item) => item.id !== id)), []);

  if (items.length === 0) return null;
  const shown = items.slice(0, TOAST_MAX);

  return (
    <View
      pointerEvents="box-none"
      style={{
        position: 'absolute',
        left: 16,
        right: 16,
        bottom: insets.bottom + chrome + 12,
        alignItems: 'center',
        zIndex: 60,
      }}
    >
      <View pointerEvents="box-none" style={{ width: '100%', maxWidth: 480, flexDirection: 'column-reverse', gap: 8 }}>
        {shown.map((item) => (
          <ToastRow key={item.id} item={item} onRemove={remove} />
        ))}
      </View>
    </View>
  );
}

function ToastRow({ item, onRemove }: { item: Toast; onRemove: (id: number) => void }) {
  const dismiss = useCallback(() => onRemove(item.id), [item.id, onRemove]);
  const life = lifeOf(item);
  const action = item.action;
  return (
    <ToastCard
      kind={item.kind}
      message={item.message}
      testID={item.testID}
      autoDismissMs={life}
      progress={life > 0}
      onDismiss={dismiss}
      action={
        action
          ? {
              label: action.label,
              accessibilityLabel: action.accessibilityLabel,
              testID: action.testID,
              onPress: () => {
                dismiss();
                action.onPress();
              },
            }
          : undefined
      }
    />
  );
}
