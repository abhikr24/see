/**
 * App-wide toast bus. Mutations report here; <ToastHost> (mounted once by
 * BackendProvider) shows them. Screens never show their own success/error toasts.
 *
 * Toasts queue: at most two are on screen, newest on top. Success and info
 * leave after LIFE.toast; errors stay until dismissed. An "undo" toast is the
 * same thing with an action: it says what happened and offers the inverse.
 */

export type ToastKind = 'success' | 'error' | 'info';

export interface ToastAction {
  label: string;
  /** Read by screen readers and used as the button's name, e.g. "Undo: Notice removed". */
  accessibilityLabel?: string;
  testID?: string;
  onPress: () => void;
}

export interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
  /** Present on an undo toast. */
  action?: ToastAction;
  /** `null` = stays until dismissed. Unset = the default for its kind. */
  life?: number | null;
  testID?: string;
}

export type ToastEvent = { type: 'show'; toast: Toast } | { type: 'dismiss'; id: number };

type Listener = (event: ToastEvent) => void;

const listeners = new Set<Listener>();
const insetListeners = new Set<() => void>();
let nextId = 1;
let bottomInset = 0;

function emit(event: ToastEvent) {
  listeners.forEach((listener) => listener(event));
}

function show(kind: ToastKind, message: string, extra: Omit<Toast, 'id' | 'kind' | 'message'> = {}): Toast {
  const item: Toast = { id: nextId++, kind, message, ...extra };
  emit({ type: 'show', toast: item });
  return item;
}

export interface UndoOptions {
  /** What the action button says. "Undo" unless told otherwise. */
  label?: string;
  accessibilityLabel?: string;
  /** `null` keeps the bar until `toast.dismiss(id)`; unset uses LIFE.undo. */
  life?: number | null;
  testID?: string;
  actionTestID?: string;
}

export const toast = {
  show,
  success: (message: string) => show('success', message),
  error: (message: string) => show('error', message),
  info: (message: string) => show('info', message),
  /**
   * Says what just happened and offers one way back. The action has already
   * run; `onUndo` is its inverse. Replaces a plain toast carrying the same
   * message, so a mutation's own success toast and the undo offer never stack.
   */
  undo(message: string, onUndo: () => void, options: UndoOptions = {}): Toast {
    return show('info', message, {
      life: options.life,
      testID: options.testID,
      action: {
        label: options.label ?? 'Undo',
        accessibilityLabel: options.accessibilityLabel ?? `Undo: ${message}`,
        testID: options.actionTestID,
        onPress: onUndo,
      },
    });
  },
  dismiss(id: number): void {
    emit({ type: 'dismiss', id });
  },
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },
  /**
   * How far above the bottom safe-area inset toasts must sit to clear floating
   * chrome. The tab shell sets this to the tab bar's height while it is mounted.
   */
  setBottomInset(next: number): void {
    if (bottomInset === next) return;
    bottomInset = next;
    insetListeners.forEach((listener) => listener());
  },
  getBottomInset: (): number => bottomInset,
  subscribeBottomInset(listener: () => void): () => void {
    insetListeners.add(listener);
    return () => {
      insetListeners.delete(listener);
    };
  },
};
