import React from 'react';
import { FlatList, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { BatchSummary } from '@/core/contracts/models';
import { useDaySheets } from '@/core/hooks/academics';
import { useDomainQuery } from '@/core/hooks/domain';
import { LAYOUT, R, useColors } from '@/lib/theme';
import { registerHref, takeAttendanceHref } from './links';
import { countMarks, marksFrom, todayIso } from './model';

import { Pressable } from '@/components/ui/Pressable';
import { Refresh } from '@/components/ui/Refresh';
/**
 * Attendance landing (no batch chosen yet): every active batch with today's
 * state — "Not marked" or "11/12 present" — one tap from its register.
 */
export function PickBatchScreen() {
  const C = useColors();
  const today = todayIso();
  const batches = useDomainQuery<BatchSummary[]>('batches', ['summaries'], (b, i) => b.batches.listSummaries(i));
  const sheets = useDaySheets(today);
  const active = (batches.data ?? []).filter((b) => b.status === 'active' || b.status === 'upcoming');

  const stateOf = (batchId: string): string | null => {
    const sheet = sheets.data?.find((s) => s.session.batchId === batchId);
    if (!sheet) return null;
    const students = sheet.records.map((r) => ({ studentId: r.studentId, fullName: '', photoUrl: null, rollNumber: null, parentName: null, parentPhone: null }));
    const counts = countMarks(students, marksFrom(students, sheet));
    return `${counts.present}/${counts.total} present`;
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 12, gap: 4 }}>
        <Text variant="h1">Attendance</Text>
        <Text variant="caption" c={C.secondary}>
          Pick a batch to take today’s roll call
        </Text>
      </View>
      {batches.loading && !batches.data ? (
        <View style={{ paddingHorizontal: LAYOUT.margin }}>
          <ListSkeleton rows={4} h={72} />
        </View>
      ) : batches.error && !batches.data ? (
        <ErrorState title="Could not load batches" message={batches.error.message} onRetry={() => void batches.refetch()} />
      ) : (
        <FlatList
          data={active}
          keyExtractor={(b) => b.id}
          refreshControl={<Refresh refreshing={batches.loading} onRefresh={() => {
            void batches.refetch();
            void sheets.refetch();
          }} />}
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 140, gap: 10 }}
          ListEmptyComponent={
            <EmptyState
              icon="albums-outline"
              title="No batches yet"
              text="Create a batch first, then take its attendance here."
              actionLabel="Create a batch"
              onAction={() => router.push('/(owner)/batches/new' as never)}
            />
          }
          renderItem={({ item }) => {
            const marked = stateOf(item.id);
            return (
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  borderRadius: R.card,
                  backgroundColor: C.surface,
                  borderWidth: 1,
                  borderColor: C.hairline,
                }}
              >
                <Pressable
                  accessibilityRole="button"
                  onPress={() => router.push(takeAttendanceHref({ batchId: item.id, date: today }) as never)}
                  style={({ pressed }) => ({
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'center',
                    gap: 12,
                    padding: 16,
                    borderTopLeftRadius: R.card,
                    borderBottomLeftRadius: R.card,
                    backgroundColor: pressed ? C.track : C.transparent,
                  })}
                >
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text variant="title" numberOfLines={1}>
                      {item.name}
                    </Text>
                    <Text variant="caption" c={C.secondary} numberOfLines={1}>
                      {item.studentCount} students · {item.subjectName}
                    </Text>
                  </View>
                  <Text weight={700} c={marked ? C.tealInk : C.muted} tabular style={{ fontSize: 13 }}>
                    {marked ?? 'Not marked'}
                  </Text>
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Open the monthly register for ${item.name}`}
                  onPress={() => router.push(registerHref(item.id) as never)}
                  style={({ pressed }) => ({
                    alignSelf: 'stretch',
                    width: 56,
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 2,
                    borderLeftWidth: 1,
                    borderLeftColor: C.hairline,
                    borderTopRightRadius: R.card,
                    borderBottomRightRadius: R.card,
                    backgroundColor: pressed ? C.track : C.transparent,
                  })}
                >
                  <Ionicons name="calendar-outline" size={20} color={C.primaryInk} />
                  <Text variant="label" c={C.primaryInk} style={{ fontSize: 10 }}>
                    Register
                  </Text>
                </Pressable>
              </View>
            );
          }}
        />
      )}
    </View>
  );
}
