import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import { LAYOUT, R, useColors } from '@/lib/theme';
import type { SavePhase } from '../hooks/useTakeAttendance';
import type { Counts } from '../model';

import { Pressable } from '@/components/ui/Pressable';
export interface SaveFooterProps {
  counts: Counts;
  editing: boolean;
  dirty: boolean;
  phase: SavePhase;
  onSave: () => void;
}

/**
 * Sticky footer: "Save attendance · 46/50 present" with the count in saffron.
 * Disabled until something changes; "Update attendance" on a saved sheet.
 */
export function SaveFooter({ counts, editing, dirty, phase, onSave }: SaveFooterProps) {
  const C = useColors();
  const saving = phase === 'saving';
  const enabled = dirty && !saving;
  const verb = editing ? 'Update attendance' : 'Save attendance';
  const done = !dirty && (phase === 'saved' || phase === 'queued');
  return (
    <SafeAreaView edges={['bottom']} style={{ backgroundColor: C.surface, borderTopWidth: 1, borderTopColor: C.hairline }}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 10, paddingBottom: 10 }}>
        <Pressable
          accessibilityRole="button"
          accessibilityState={{ disabled: !enabled, busy: saving }}
          accessibilityLabel={`${verb}, ${counts.present} of ${counts.total} present`}
          disabled={!enabled}
          onPress={onSave}
          style={({ pressed }) => ({
            height: 56,
            borderRadius: R.btn,
            backgroundColor: enabled ? C.primary : C.navyPale,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            opacity: pressed ? 0.9 : 1,
            transform: [{ scale: pressed ? 0.99 : 1 }],
          })}
        >
          {saving ? <ActivityIndicator color={C.onFill} size="small" /> : null}
          {done ? (
            <Ionicons name={phase === 'queued' ? 'cloud-offline-outline' : 'checkmark-circle'} size={18} color={C.onFill} />
          ) : null}
          <Text weight={700} c={C.onFill} style={{ fontSize: 16 }}>
            {saving ? 'Saving…' : done ? (phase === 'queued' ? 'Queued · ' : 'Saved · ') : `${verb} · `}
            {saving ? null : (
              <Text tabular weight={800} c={enabled ? C.accentInk : C.onFill} style={{ fontSize: 16 }}>
                {counts.present}/{counts.total}
              </Text>
            )}
            {saving ? null : ' present'}
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}
