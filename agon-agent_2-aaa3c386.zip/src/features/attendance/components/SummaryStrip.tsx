import React from 'react';
import { View } from 'react-native';

import { Text } from '@/components/ui';
import { LAYOUT, useColors } from '@/lib/theme';
import type { Counts } from '../model';

import { Pressable } from '@/components/ui/Pressable';
export interface SummaryStripProps {
  counts: Counts;
  onMarkAllPresent: () => void;
}

/** White strip: "46 Present · 1 Late · 3 Absent" in data colours, and the navy "Mark all present" link. */
export function SummaryStrip({ counts, onMarkAllPresent }: SummaryStripProps) {
  const C = useColors();
  const allPresent = counts.present === counts.total;
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: LAYOUT.margin,
        height: 48,
        backgroundColor: C.surface,
        borderTopWidth: 1,
        borderBottomWidth: 1,
        borderColor: C.hairline,
      }}
    >
      <Text tabular weight={600} numberOfLines={1} style={{ flex: 1, fontSize: 14 }} accessibilityLiveRegion="polite">
        <Text tabular weight={700} c={C.tealInk} style={{ fontSize: 14 }}>
          {counts.present} Present
        </Text>
        <Text c={C.muted} style={{ fontSize: 14 }}>
          {'  ·  '}
        </Text>
        <Text tabular weight={700} c={C.warningInk} style={{ fontSize: 14 }}>
          {counts.late} Late
        </Text>
        <Text c={C.muted} style={{ fontSize: 14 }}>
          {'  ·  '}
        </Text>
        <Text tabular weight={700} c={C.dangerInk} style={{ fontSize: 14 }}>
          {counts.absent} Absent
        </Text>
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Mark all present"
        onPress={onMarkAllPresent}
        hitSlop={10}
        style={({ pressed }) => ({ opacity: pressed ? 0.6 : allPresent ? 0.55 : 1, paddingVertical: 6 })}
      >
        <Text weight={700} c={C.primaryInk} style={{ fontSize: 13.5 }}>
          Mark all present
        </Text>
      </Pressable>
    </View>
  );
}
