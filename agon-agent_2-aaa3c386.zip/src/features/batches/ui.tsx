import React from 'react';
import { ActivityIndicator, TextInput, View, type TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Text } from '@/components/ui/Text';
import { C, R, useColors, themed } from '@/lib/theme';

import { Pressable } from '@/components/ui/Pressable';
export { Text };

export const row = { flexDirection: 'row' as const, alignItems: 'center' as const };

export const panel = themed(() => ({
  backgroundColor: C.surface,
  borderWidth: 1,
  borderColor: C.hairline,
  borderRadius: R.card,
}));

export const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const schedule = (days?: number[]) =>
  (days ?? [])
    .slice()
    .sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7))
    .map((d) => DAYS[d])
    .join(' ');

export function time(v?: string | null) {
  if (!v) return 'Not scheduled';
  const [h, m] = v.split(':');
  const n = Number(h);
  return `${n % 12 || 12}:${m} ${n >= 12 ? 'PM' : 'AM'}`;
}

export function Icon({
  name,
  size = 20,
  color,
}: {
  name: React.ComponentProps<typeof Ionicons>['name'];
  size?: number;
  color?: string;
}) {
  const C = useColors();
  return <Ionicons name={name} size={size} color={color ?? C.secondary} />;
}

export function Action({
  label,
  onPress,
  icon,
  soft,
  color,
  disabled,
}: {
  label: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
  soft?: boolean;
  color?: string;
  disabled?: boolean;
}) {
  const C = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        ...row,
        justifyContent: 'center',
        gap: 9,
        paddingHorizontal: 19,
        minHeight: 46,
        borderRadius: 12,
        backgroundColor: soft ? C.navySoft : color ?? C.primary,
        opacity: disabled ? 0.5 : pressed ? 0.8 : 1,
      })}
    >
      {icon && <Icon name={icon} size={18} color={soft ? C.primaryInk : C.onFill} />}
      <Text variant="caption" weight={700} c={soft ? C.primaryInk : C.onFill}>
        {label}
      </Text>
    </Pressable>
  );
}

export function Person({ name, uri, size = 34 }: { name: string; uri?: string | null; size?: number }) {
  const C = useColors();
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: C.navySoft,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {uri ? (
        <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />
      ) : (
        <Text style={{ fontSize: size * 0.32 }} weight={700} c={C.primaryInk}>
          {name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
        </Text>
      )}
    </View>
  );
}

export function Field({ label, ...props }: TextInputProps & { label: string }) {
  const C = useColors();
  return (
    <View style={{ gap: 8, flex: 1 }}>
      <Text variant="caption" weight={700}>
        {label}
      </Text>
      <TextInput
        placeholderTextColor={C.muted}
        returnKeyType="next"
        {...props}
        style={[
          {
            borderWidth: 1,
            borderColor: C.hairline,
            borderRadius: 12,
            backgroundColor: C.surface,
            minHeight: 48,
            paddingHorizontal: 14,
            paddingVertical: 12,
            fontSize: 14,
            color: C.ink,
            fontFamily: 'Jakarta',
          },
          props.style,
        ]}
      />
    </View>
  );
}

export function State({
  loading,
  error,
  empty,
  retry,
  message = 'Nothing here yet.',
}: {
  loading?: boolean;
  error?: string | null;
  empty?: boolean;
  retry?: () => void;
  message?: string;
}) {
  const C = useColors();
  if (loading) {
    return (
      <View style={{ gap: 14, padding: 30, ...panel }}>
        <ActivityIndicator color={C.primaryInk} />
        {[1, 2, 3].map((n) => (
          <View
            key={n}
            style={{ height: 22, width: `${90 - n * 15}%`, backgroundColor: C.track, borderRadius: 6 }}
          />
        ))}
      </View>
    );
  }
  if (!error && !empty) return null;
  return (
    <View style={{ ...panel, alignItems: 'center', padding: 32, gap: 14 }}>
      <Icon name={error ? 'cloud-offline-outline' : 'albums-outline'} size={30} />
      <Text c={C.secondary}>{error ?? message}</Text>
      {error && retry && <Action label="Try again" onPress={retry} />}
    </View>
  );
}
