import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Badge, IconBox, Text } from '@/components/ui';
import type { Notice } from '@/core/contracts/models';
import { R, SHADOW, useColors } from '@/lib/theme';
import { categoryMeta, eventChip, noticeDateLabel } from '../model';

import { Pressable } from '@/components/ui/Pressable';
export interface NoticeCardProps {
  notice: Notice;
  onOpen: (notice: Notice) => void;
  /** Present only for a role that may delete: long-press asks for confirmation. */
  onLongPress?: (notice: Notice) => void;
}

/** Calendar-style chip: month over day. Only event notices with a day carry one. */
export function EventDateChip({ day, month }: { day: string; month: string }) {
  const C = useColors();
  return (
    <View
      accessibilityLabel={`Event on ${day} ${month}`}
      style={{
        width: 46,
        borderRadius: R.field,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: C.accentSoft,
        backgroundColor: C.surface,
        alignItems: 'stretch',
      }}
    >
      <View style={{ backgroundColor: C.accent, paddingVertical: 2, alignItems: 'center' }}>
        <Text variant="label" weight={700} c={C.onFill} style={{ fontSize: 9, letterSpacing: 0.8 }}>
          {month}
        </Text>
      </View>
      <View style={{ paddingVertical: 3, alignItems: 'center', backgroundColor: C.accentSoft }}>
        <Text variant="title" weight={800} c={C.ink} tabular style={{ fontSize: 16, lineHeight: 20 }}>
          {day}
        </Text>
      </View>
    </View>
  );
}

/**
 * One notice: category icon square, title, three lines of body, and a footer
 * with the category pill, the date and Read more.
 */
export function NoticeCard({ notice, onOpen, onLongPress }: NoticeCardProps) {
  const C = useColors();
  const meta = categoryMeta(notice.category);
  const chip = eventChip(notice);

  return (
    <Pressable
      testID={`notice-card-${notice.id}`}
      accessibilityRole="button"
      accessibilityLabel={`${notice.title}. ${meta.label} notice.`}
      accessibilityHint={onLongPress ? 'Opens the notice. Long-press to delete.' : 'Opens the notice.'}
      accessibilityActions={onLongPress ? [{ name: 'longpress', label: 'Delete notice' }] : undefined}
      onAccessibilityAction={(event) => {
        if (event.nativeEvent.actionName === 'longpress') onLongPress?.(notice);
      }}
      onPress={() => onOpen(notice)}
      onLongPress={onLongPress ? () => onLongPress(notice) : undefined}
      delayLongPress={380}
      style={({ pressed }) => ({
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: 16,
        gap: 12,
        opacity: pressed ? 0.94 : 1,
        ...SHADOW.raised,
      })}
    >
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12 }}>
        <IconBox name={meta.icon} tone={meta.tone} size={44} />
        <View style={{ flex: 1, minHeight: 44, justifyContent: 'center' }}>
          <Text variant="title" weight={700} numberOfLines={2}>
            {notice.title}
          </Text>
        </View>
        {chip ? <EventDateChip day={chip.day} month={chip.month} /> : null}
      </View>

      <Text variant="body" c={C.secondary} numberOfLines={3} style={{ lineHeight: 21 }}>
        {notice.body}
      </Text>

      <View style={{ height: 1, backgroundColor: C.hairline }} />

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Badge label={meta.label} tone={meta.tone} small />
        <Text variant="caption" c={C.muted} tabular style={{ flex: 1 }} numberOfLines={1}>
          {noticeDateLabel(notice.publishedAt)}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 2 }}>
          <Text variant="caption" weight={700} c={C.primaryInk}>
            Read more
          </Text>
          <Ionicons name="chevron-forward" size={14} color={C.primaryInk} />
        </View>
      </View>
    </Pressable>
  );
}
