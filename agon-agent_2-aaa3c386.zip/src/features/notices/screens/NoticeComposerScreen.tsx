import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button, Card, Chip, DateField, Input, Skeleton, Text } from '@/components/ui';
import { NOTICE_BODY_MAX, NOTICE_TITLE_MAX } from '@/core/contracts/notices';
import { todayISO } from '@/lib/format';
import { C, LAYOUT, R, S, useColors, themed } from '@/lib/theme';
import { AlertsOffCard, PreviewStrip, ToggleRow, WhatsAppSummaryCard } from '../components/ComposerParts';
import { useNoticeComposer } from '../hooks';
import { COMPOSER_CATEGORIES, bodyCounter } from '../model';

import { Pressable } from '@/components/ui/Pressable';
export interface NoticeComposerScreenProps {
  /** Batch to address, when the composer is opened from a batch shortcut. */
  initialBatchId?: string;
}

const COUNTER_COLOR = themed(() => ({ muted: C.muted, warning: C.warningInk, danger: C.dangerInk } as const));

/**
 * Write a notice and publish it. Full-screen with a sticky Publish bar: title,
 * body (500 characters), who it goes to, a live preview, then one tap.
 */
export function NoticeComposerScreen({ initialBatchId }: NoticeComposerScreenProps) {
  const C = useColors();
  const form = useNoticeComposer(initialBatchId);
  const [bodyFocused, setBodyFocused] = useState(false);
  const counter = bodyCounter(form.body.length, NOTICE_BODY_MAX);

  const goBack = () => {
    if (router.canGoBack()) router.back();
    else router.replace(form.routes.list as never);
  };

  // Students and parents have no composer; the route guard already keeps other groups out.
  if (form.role && !form.allowed) return <Redirect href={form.routes.list as never} />;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 10, paddingBottom: 6 }}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Back to notices"
            onPress={goBack}
            hitSlop={8}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start', minHeight: 32 }}
          >
            <Ionicons name="chevron-back" size={20} color={C.primaryInk} />
            <Text variant="caption" weight={700} c={C.primaryInk}>
              Notices
            </Text>
          </Pressable>
        </View>

        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 28, gap: S.lg }}
          showsVerticalScrollIndicator={false}
        >
          <View style={{ gap: 2 }}>
            <Text variant="h2">New notice</Text>
            <Text variant="caption" c={C.secondary}>
              {form.isTeacher
                ? 'Goes to the classes assigned to you, in the app.'
                : 'Write it once. Everyone you choose is told in the app.'}
            </Text>
          </View>

          <Input
            testID="notice-title"
            label="Title"
            value={form.title}
            onChangeText={form.setTitle}
            placeholder="e.g. Parent–teacher meeting on Saturday"
            maxLength={NOTICE_TITLE_MAX}
            returnKeyType="next"
            autoCapitalize="sentences"
            error={form.errors.title}
          />

          <View style={{ gap: 6 }}>
            <Text variant="label" c={C.secondary}>
              Notice
            </Text>
            <View
              style={{
                borderRadius: R.field,
                backgroundColor: C.surface,
                borderWidth: bodyFocused ? 2 : 1,
                borderColor: form.errors.body ? C.danger : bodyFocused ? C.primaryInk : C.hairline,
                paddingHorizontal: 18,
                paddingTop: 14,
                paddingBottom: 10,
              }}
            >
              <TextInput
                testID="notice-body"
                accessibilityLabel="Notice text"
                value={form.body}
                onChangeText={form.setBody}
                placeholder="What should people know? Keep it short — dates, times and what to bring."
                placeholderTextColor={C.muted}
                multiline
                maxLength={NOTICE_BODY_MAX}
                textAlignVertical="top"
                onFocus={() => setBodyFocused(true)}
                onBlur={() => setBodyFocused(false)}
                style={{ minHeight: 132, fontSize: 15, lineHeight: 22, color: C.ink, padding: 0 }}
              />
              <Text
                testID="notice-body-counter"
                variant="caption"
                weight={600}
                tabular
                c={COUNTER_COLOR[counter.tone]}
                accessibilityLabel={`${form.body.length} of ${NOTICE_BODY_MAX} characters used`}
                style={{ alignSelf: 'flex-end', marginTop: 6 }}
              >
                {counter.label}
              </Text>
            </View>
            {form.errors.body ? (
              <Text variant="caption" c={C.dangerInk}>
                {form.errors.body}
              </Text>
            ) : null}
          </View>

          <View style={{ gap: 8 }}>
            <Text variant="label" c={C.secondary}>
              Category
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {COMPOSER_CATEGORIES.map((option) => (
                <Chip
                  key={option.key}
                  label={option.label}
                  active={form.category === option.key}
                  onPress={() => form.setCategory(option.key)}
                />
              ))}
            </View>
            {form.category === 'event' ? (
              <DateField
                label="Event day"
                value={form.eventOn ?? undefined}
                minDate={todayISO()}
                onChange={(_dmy, iso) => form.setEventOn(iso || null)}
                placeholder="Pick the day"
                error={form.errors.eventOn}
              />
            ) : null}
          </View>

          <View style={{ gap: 8 }}>
            <Text variant="label" c={C.secondary}>
              Send to
            </Text>
            <Card flat pad={16} style={{ paddingVertical: 4 }}>
              <ToggleRow
                testID="toggle-students"
                label="Students"
                detail="Students with a login"
                icon="school-outline"
                value={form.students}
                onChange={form.setStudents}
              />
              <ToggleRow
                testID="toggle-parents"
                label="Parents"
                detail="Parents with a login"
                icon="heart-outline"
                value={form.parents}
                onChange={form.setParents}
              />
              {form.isTeacher ? null : (
                <ToggleRow
                  testID="toggle-teachers"
                  label="Teachers"
                  detail="Teaching staff"
                  icon="easel-outline"
                  value={form.teachers}
                  onChange={form.setTeachers}
                />
              )}
              <ToggleRow
                testID="toggle-all-batches"
                label={form.isTeacher ? 'All my batches' : 'All batches'}
                detail={
                  form.allBatches
                    ? form.isTeacher
                      ? 'Every class assigned to you'
                      : 'The whole institute'
                    : 'Switched off — pick one batch below'
                }
                icon="albums-outline"
                value={form.allBatches}
                onChange={form.setAllBatches}
                divider={false}
              />
            </Card>
            {form.errors.audience ? (
              <Text variant="caption" c={C.dangerInk}>
                {form.errors.audience}
              </Text>
            ) : null}

            {form.allBatches ? null : (
              <View style={{ gap: 8, marginTop: 4 }}>
                {form.batchesLoading ? (
                  <Skeleton h={36} w="70%" r={18} />
                ) : form.batches.length === 0 ? (
                  <Text variant="caption" c={C.secondary}>
                    There is no active batch to choose yet.
                  </Text>
                ) : (
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                    {form.batches.map((batch) => (
                      <Chip
                        key={batch.id}
                        label={batch.name}
                        active={form.batchId === batch.id}
                        onPress={() => form.setBatchId(batch.id)}
                      />
                    ))}
                  </View>
                )}
                {form.errors.batchId ? (
                  <Text variant="caption" c={C.dangerInk}>
                    {form.errors.batchId}
                  </Text>
                ) : null}
              </View>
            )}
          </View>

          {form.parents ? <WhatsAppSummaryCard /> : null}
          {form.alertsOn ? null : <AlertsOffCard />}

          <PreviewStrip title={form.title} body={form.body} category={form.category} summary={form.summary} />
        </ScrollView>

        <View
          style={{
            paddingHorizontal: LAYOUT.margin,
            paddingTop: 10,
            paddingBottom: 14,
            backgroundColor: C.surface,
            borderTopWidth: 1,
            borderTopColor: C.hairline,
          }}
        >
          <Button
            testID="notice-publish"
            title="Publish"
            icon="paper-plane-outline"
            loading={form.saving}
            onPress={() => void form.submit()}
          />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
