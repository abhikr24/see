import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { FlatList, View } from 'react-native';
import { Redirect, router, useLocalSearchParams } from 'expo-router';

import {
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  ErrorState,
  ListSkeleton,
  SegmentedControl,
  StaggerItem,
  SwipeRow,
  showUndo,
  Text,
} from '@/components/ui';
import { toast, useBatches } from '@/core/backend';
import type { Notice } from '@/core/contracts/models';
import { LAYOUT, S, useColors, R } from '@/lib/theme';
import { NoticeCard } from '../components/NoticeCard';
import { NoticeDetailModal } from '../components/NoticeDetailModal';
import { useNoticeBoard } from '../hooks';
import { NOTICE_SEGMENTS, type NoticeSegment } from '../model';

import { Refresh } from '@/components/ui/Refresh';
const EMPTY_COPY: Record<NoticeSegment, { title: string; text: string }> = {
  all: { title: 'No notices yet', text: 'When the institute shares something, it will be here.' },
  academic: { title: 'Nothing academic right now', text: 'Timetable changes, tests and class updates show up here.' },
  events: { title: 'No events coming up', text: 'Fairs, meetings and holidays show up here.' },
};

/** Staff see who a notice went to; that needs batch names, which only staff can list. */
function StaffNoticeDetail({ notice, onClose }: { notice: Notice | null; onClose: () => void }) {
  const batches = useBatches();
  const batchName = notice?.batchId
    ? (batches.data?.items.find((batch) => batch.id === notice.batchId)?.name ?? null)
    : null;
  return <NoticeDetailModal notice={notice} batchName={batchName} showAudience onClose={onClose} />;
}

/**
 * Notices for every role. Which notices arrive is NoticeRepo's decision (role,
 * batch, published, unexpired); this screen only segments and draws them.
 */
export function NoticesListScreen() {
  const C = useColors();
  const board = useNoticeBoard();
  const params = useLocalSearchParams<{ action?: string; batchId?: string; open?: string }>();
  const [picked, setPicked] = useState<Notice | null>(null);
  const [toDelete, setToDelete] = useState<Notice | null>(null);
  const [closedParam, setClosedParam] = useState<string | null>(null);
  const warnedFor = useRef<string | null>(null);

  // A notification tap lands here with ?open=<noticeId>: that notice opens once the list has it.
  const openId = typeof params.open === 'string' && params.open ? params.open : null;
  const fromParam = openId && closedParam !== openId ? (board.all.find((notice) => notice.id === openId) ?? null) : null;
  const open = picked ?? fromParam;
  const missing = openId !== null && !board.loading && !board.error && !board.all.some((notice) => notice.id === openId);

  useEffect(() => {
    if (!missing || warnedFor.current === openId) return;
    warnedFor.current = openId;
    toast.info('That notice is no longer available');
  }, [missing, openId]);

  const closeDetail = useCallback(() => {
    setPicked(null);
    setClosedParam(openId);
  }, [openId]);

  // Delete happens at once, as before. The undo bar then offers the inverse: the same
  // notice is stored again (no second round of alerts; the old inbox rows are not restored).
  const removeWithUndo = useCallback(
    async (target: Notice) => {
      const result = await board.remove(target.id);
      if (!result.ok) return;
      showUndo(
        'Notice removed',
        () =>
          void board.create({
            title: target.title,
            body: target.body,
            category: target.category,
            audience: target.audience,
            batchId: target.batchId,
            isPinned: target.isPinned,
            publishedAt: target.publishedAt,
            expiresAt: target.expiresAt,
            eventOn: target.eventOn,
          }),
        { accessibilityLabel: `Undo deleting the notice ${target.title}` },
      );
    },
    [board],
  );

  const confirmDelete = useCallback(async () => {
    const target = toDelete;
    setToDelete(null);
    if (target) await removeWithUndo(target);
  }, [toDelete, removeWithUndo]);

  const header = useMemo(
    () => (
      <View style={{ gap: S.lg, marginBottom: S.lg }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ flex: 1, gap: 2 }}>
            <Text variant="h2">Notices</Text>
            <Text variant="caption" c={C.secondary}>
              {board.canCompose ? 'Everything the institute has announced' : 'Announcements from your institute'}
            </Text>
          </View>
          {board.canCompose && board.routes.compose ? (
            <Button
              testID="notice-compose"
              title="New notice"
              icon="add"
              size="sm"
              full={false}
              onPress={() => router.push(board.routes.compose as never)}
            />
          ) : null}
        </View>
        <SegmentedControl options={NOTICE_SEGMENTS} value={board.segment} onChange={board.setSegment} />
      </View>
    ),
    [board.canCompose, board.routes.compose, board.segment, board.setSegment, C],
  );

  // The owner dashboard's "Send notice" shortcut still arrives as ?action=compose&batchId=.
  if (params.action === 'compose' && board.canCompose && board.routes.compose) {
    return (
      <Redirect
        href={{ pathname: board.routes.compose, params: params.batchId ? { batchId: params.batchId } : {} } as never}
      />
    );
  }

  const empty = board.loading ? (
    <ListSkeleton rows={3} h={150} />
  ) : board.error ? (
    <Card flat>
      <ErrorState message={board.error.message} onRetry={() => void board.refetch()} />
    </Card>
  ) : (
    <Card flat>
      <EmptyState
        icon="megaphone-outline"
        title={EMPTY_COPY[board.segment].title}
        text={EMPTY_COPY[board.segment].text}
        actionLabel={board.canCompose && board.segment === 'all' ? 'Write the first notice' : undefined}
        onAction={
          board.canCompose && board.routes.compose ? () => router.push(board.routes.compose as never) : undefined
        }
      />
    </Card>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        data={board.loading || board.error ? [] : board.visible}
        keyExtractor={(notice) => notice.id}
        renderItem={({ item, index }) => (
          <StaggerItem index={index}>
            <SwipeRow
              radius={R.card}
              trailing={
                board.canDelete
                  ? {
                      label: 'Delete',
                      accessibilityLabel: `Delete the notice ${item.title}`,
                      icon: 'trash-outline',
                      tone: 'danger',
                      destructive: true,
                      onPress: () => void removeWithUndo(item),
                    }
                  : undefined
              }
            >
              <NoticeCard notice={item} onOpen={setPicked} onLongPress={board.canDelete ? setToDelete : undefined} />
            </SwipeRow>
          </StaggerItem>
        )}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 136 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <Refresh refreshing={board.refreshing} onRefresh={() => void board.refetch()} />
        }
      />

      {board.canCompose ? (
        <StaffNoticeDetail notice={open} onClose={closeDetail} />
      ) : (
        <NoticeDetailModal notice={open} onClose={closeDetail} />
      )}

      <ConfirmDialog
        visible={toDelete !== null}
        title="Delete this notice?"
        description={
          toDelete
            ? `“${toDelete.title}” will disappear from everyone’s list, and its notifications from their inboxes.`
            : ''
        }
        confirmLabel="Delete notice"
        onConfirm={() => void confirmDelete()}
        onCancel={() => setToDelete(null)}
      />
    </View>
  );
}
