import React, { useMemo, useState } from 'react';
import { Animated, PanResponder, Platform, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { IconBox, Text } from '@/components/ui';
import type { AppNotification, ID } from '@/core/contracts/models';
import { LAYOUT, R, useColors } from '@/lib/theme';
import { KIND_META, kindOf, relativeTime } from '../model';

import { Pressable } from '@/components/ui/Pressable';
export interface NotificationCardProps {
  notification: AppNotification;
  onPress: (notification: AppNotification) => void;
  /** Called once the card has been swiped away. */
  onDismiss: (id: ID) => void;
}

const NATIVE_DRIVER = Platform.OS !== 'web';
/** Fraction of the card's width a swipe must cover to count as a dismiss. */
const DISMISS_AT = 0.35;

/**
 * One notification: tinted icon for its kind, title, body, relative time, an
 * unread dot and a soft navy wash while unread. Swipe either way to dismiss.
 */
export function NotificationCard({ notification, onPress, onDismiss }: NotificationCardProps) {
  const C = useColors();
  const kind = kindOf(notification);
  const meta = KIND_META[kind];
  const unread = notification.readAt === null;

  const id = notification.id;
  const [x] = useState(() => new Animated.Value(0));
  // The card spans the screen minus the list margins; that is far enough to carry it off.
  const span = Math.max(240, useWindowDimensions().width - LAYOUT.margin * 2);

  // Rebuilt only if the card's id or the screen width changes — never mid-drag by a data refresh.
  const responder = useMemo(() => {
    const settle = () => Animated.spring(x, { toValue: 0, useNativeDriver: NATIVE_DRIVER, bounciness: 6 }).start();
    return PanResponder.create({
      // Only a clearly horizontal drag takes the gesture, so the list still scrolls and a tap still opens.
      onMoveShouldSetPanResponder: (_event, gesture) =>
        Math.abs(gesture.dx) > 10 && Math.abs(gesture.dx) > Math.abs(gesture.dy) * 1.5,
      onPanResponderMove: (_event, gesture) => x.setValue(gesture.dx),
      onPanResponderRelease: (_event, gesture) => {
        const far = Math.abs(gesture.dx) > span * DISMISS_AT;
        const fast = Math.abs(gesture.vx) > 0.9 && Math.abs(gesture.dx) > 40;
        if (!far && !fast) return settle();
        Animated.timing(x, {
          toValue: Math.sign(gesture.dx) * span,
          duration: 150,
          useNativeDriver: NATIVE_DRIVER,
        }).start(() => onDismiss(id));
      },
      onPanResponderTerminate: settle,
    });
  }, [x, span, id, onDismiss]);

  return (
    <View style={{ borderRadius: R.card, overflow: 'hidden' }}>
      {/* What shows through while the card is being dragged. */}
      <View
        pointerEvents="none"
        style={{
          position: 'absolute',
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
          borderRadius: R.card,
          backgroundColor: C.dangerSoft,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingHorizontal: 20,
        }}
      >
        <Ionicons name="trash-outline" size={20} color={C.danger} />
        <Ionicons name="trash-outline" size={20} color={C.danger} />
      </View>

      <Animated.View {...responder.panHandlers} style={{ transform: [{ translateX: x }] }}>
        <Pressable
          testID={`notification-${notification.id}`}
          accessibilityRole="button"
          accessibilityLabel={`${unread ? 'Unread. ' : ''}${meta.label}. ${notification.title}`}
          accessibilityHint="Opens it and marks it read. Swipe sideways to dismiss."
          accessibilityActions={[{ name: 'dismiss', label: 'Dismiss' }]}
          onAccessibilityAction={(event) => {
            if (event.nativeEvent.actionName === 'dismiss') onDismiss(id);
          }}
          onPress={() => onPress(notification)}
          style={({ pressed }) => [
            {
              flexDirection: 'row',
              alignItems: 'flex-start',
              gap: 12,
              padding: 14,
              borderRadius: R.card,
              borderWidth: 1,
              borderColor: unread ? C.navySoft : C.hairline,
              backgroundColor: unread ? C.navyTint : C.surface,
              opacity: pressed ? 0.94 : 1,
            },
            Platform.OS === 'web' ? ({ userSelect: 'none', cursor: 'pointer' } as object) : null,
          ]}
        >
          <IconBox name={meta.icon} tone={meta.tone} size={44} />
          <View style={{ flex: 1, gap: 3 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 8 }}>
              <Text variant="body" weight={unread ? 700 : 600} numberOfLines={2} style={{ flex: 1 }}>
                {notification.title}
              </Text>
              {unread ? (
                <View
                  testID={`unread-dot-${notification.id}`}
                  style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: C.accent, marginTop: 6 }}
                />
              ) : null}
            </View>
            {notification.body ? (
              <Text variant="caption" c={C.secondary} numberOfLines={2} style={{ lineHeight: 18 }}>
                {notification.body}
              </Text>
            ) : null}
            <Text variant="caption" c={C.muted} tabular style={{ fontSize: 12, marginTop: 2 }}>
              {`${meta.label} · ${relativeTime(notification.createdAt)}`}
            </Text>
          </View>
        </Pressable>
      </Animated.View>
    </View>
  );
}
