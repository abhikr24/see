import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Text } from '@/components/ui';
import { useColors } from '@/lib/theme';
import { useParent } from './context';
import { Photo } from './ui';

import { Pressable } from '@/components/ui/Pressable';
/** Compact selected-child strip. Opens the shared switcher when a family has more than one child. */
export function ChildStrip() {
  const C = useColors();
  const p = useParent();
  if (!p.child) return null;
  const many = (p.summary?.children.length ?? 0) > 1;
  return (
    <Pressable
      accessibilityRole={many ? 'button' : undefined}
      accessibilityLabel={many ? `Switch child. ${p.child.name} selected` : p.child.name}
      disabled={!many}
      onPress={() => many && p.setSwitcherOpen(true)}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        opacity: pressed && many ? 0.75 : 1,
      })}
    >
      <Photo name={p.child.name} uri={p.child.photoUrl} size={40} />
      <View style={{ flex: 1, gap: 1 }}>
        <Text weight={700} style={{ fontSize: 15, lineHeight: 20 }} numberOfLines={1}>
          {p.child.name}
        </Text>
        <Text variant="caption" c={C.secondary} numberOfLines={1}>
          {p.child.classLabel}
        </Text>
      </View>
      {many ? <Ionicons name="chevron-down" size={16} color={C.muted} /> : null}
    </Pressable>
  );
}
