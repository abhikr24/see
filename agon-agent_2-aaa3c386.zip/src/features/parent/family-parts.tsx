import React from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useColors } from '@/lib/theme';
import { useParent } from './context';
import { Icon, Label, Photo, styles } from './ui';

import { Pressable } from '@/components/ui/Pressable';
/** Clears the floating pill tab bar at the bottom of every family screen. */
export const FAMILY_TAB_INSET = 136;

export const METHOD_LABEL: Record<string, string> = {
  cash: 'Cash', upi: 'UPI', card: 'Card', bank_transfer: 'Bank transfer', cheque: 'Cheque', online: 'Online',
};

/** "20 Nov 2026" from any ISO date or timestamp. */
export function formatLongDate(iso: string): string {
  return new Date(`${iso.slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

/** "Term 3 fee" → "Term 3". */
export const termName = (label: string): string => label.replace(/ fee$/i, '');

/** A scrolling page with an optional back link, a title and room for the tab bar. */
export function FamilyPage({ title, subtitle, onBack, children }: { title: string; subtitle?: string; onBack?: () => void; children: React.ReactNode }) {
  const C = useColors();
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.canvas }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: FAMILY_TAB_INSET, gap: 18 }} keyboardShouldPersistTaps="handled">
        {onBack ? (
          <Pressable accessibilityRole="button" accessibilityLabel="Back" onPress={onBack} style={[styles.row, { gap: 6, minHeight: 44, alignSelf: 'flex-start' }]}>
            <Icon name="chevron-back" size={20} color={C.primaryInk} />
            <Label weight="600" color={C.primaryInk}>Back</Label>
          </Pressable>
        ) : null}
        <View style={{ gap: 6 }}>
          <Label size={27} weight="800" style={{ letterSpacing: -0.7 }}>{title}</Label>
          {subtitle ? <Label size={13} color={C.muted}>{subtitle}</Label> : null}
        </View>
        {children}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

/** The children linked to this account. Tapping one changes whose fees, leave and meetings are shown. */
export function ChildStrip() {
  const C = useColors();
  const p = useParent();
  const children = p.summary?.children ?? [];
  if (!p.child || children.length < 2) return null;
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {children.map((child) => {
        const selected = child.id === p.child?.id;
        return (
          <Pressable
            key={child.id}
            accessibilityRole="button"
            accessibilityLabel={`Choose ${child.name}`}
            accessibilityState={{ selected }}
            onPress={() => p.select(child.id)}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44, paddingVertical: 6, paddingLeft: 6, paddingRight: 14, borderRadius: 22, backgroundColor: selected ? C.primary : C.surface, borderWidth: 1, borderColor: selected ? C.primaryInk : C.hairline }}
          >
            <Photo name={child.name} uri={child.photoUrl} size={30} />
            <View>
              <Label size={13} weight="700" color={selected ? C.onFill : C.ink}>{child.name.split(' ')[0]}</Label>
              <Label size={11} color={selected ? C.navyPale : C.muted}>{child.classLabel}</Label>
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}

/** A small rounded status pill, in one of the theme's tones. */
export function StatusPill({ label, tone }: { label: string; tone: 'warning' | 'success' | 'danger' | 'neutral' }) {
  const C = useColors();
  const palette = {
    warning: { fg: C.duesInk, bg: C.warningSoft },
    success: { fg: C.tealInk, bg: C.tealSoft },
    danger: { fg: C.dangerInk, bg: C.dangerSoft },
    neutral: { fg: C.secondary, bg: C.track },
  }[tone];
  return (
    <View style={{ alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, backgroundColor: palette.bg }}>
      <Label size={11} weight="700" color={palette.fg}>{label}</Label>
    </View>
  );
}
