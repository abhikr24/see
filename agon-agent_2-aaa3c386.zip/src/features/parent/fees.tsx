import React, { useState } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { useColors } from '@/lib/theme';
import { ONLINE_PAYMENT_OFF } from '@/core/contracts/family';
import { useFamilyPayments, usePaymentIntent } from '@/core/backend';
import { useParent } from './context';
import { ChildStrip, FamilyPage, METHOD_LABEL, StatusPill, formatLongDate, termName } from './family-parts';
import { Icon, Label, Panel, currency, styles } from './ui';

import { Pressable } from '@/components/ui/Pressable';
/** The parent's fees: amount due, terms, receipts, payment history and the trust note. */
export function ParentFeesScreen() {
  const C = useColors();
  const p = useParent();
  const child = p.child;
  const history = useFamilyPayments(child?.id);
  const intent = usePaymentIntent();
  const [notice, setNotice] = useState<string | null>(null);
  const due = child?.nextFee ?? null;

  const receiptForTerm = (installmentId: string): string | null =>
    history.data?.find((payment) => payment.installmentId === installmentId && payment.receiptId)?.receiptId ?? null;

  const pay = async () => {
    if (!child || !due || intent.loading) return;
    setNotice(null);
    const result = await intent.mutate({ studentId: child.id, installmentId: due.id });
    if (result.ok) {
      setNotice('Payment started. Your receipt will appear here once the institute confirms it.');
      return;
    }
    setNotice(result.error.code === 'NOT_IMPLEMENTED' ? ONLINE_PAYMENT_OFF : result.error.message);
  };

  if (!child) {
    return (
      <FamilyPage title="Fees">
        <Panel><Label color={C.muted}>{p.loading ? 'Loading fees…' : 'No child is linked to this account yet.'}</Label></Panel>
      </FamilyPage>
    );
  }

  return (
    <FamilyPage title="Fees" subtitle={`${child.name} · ${child.classLabel}`}>
      <ChildStrip />

      <View style={{ backgroundColor: C.primary, borderRadius: 22, padding: 22, gap: 6 }}>
        <Label size={12} weight="700" color={C.navyPale}>Amount due</Label>
        <Label size={44} weight="800" color={C.onFill} style={{ letterSpacing: -1 }}>{currency(due?.remaining ?? 0)}</Label>
        <Label size={13} color={C.navyPale}>
          {due ? `${termName(due.label)} · due ${formatLongDate(due.dueDate)}` : 'Nothing is due right now. Thank you.'}
        </Label>
        {due ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Pay now"
            disabled={intent.loading}
            onPress={() => void pay()}
            style={({ pressed }) => ({ marginTop: 16, height: 44, borderRadius: 13, backgroundColor: C.accent, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, opacity: pressed || intent.loading ? 0.7 : 1 })}
          >
            <Label size={15} weight="800" color={C.onFill}>{intent.loading ? 'Starting payment…' : 'Pay now'}</Label>
            <Icon name="arrow-forward" size={17} color={C.onFill} />
          </Pressable>
        ) : null}
        {notice ? <Label size={13} color={C.onFill} style={{ marginTop: 10 }}>{notice}</Label> : null}
      </View>

      <Panel style={{ padding: 20 }}>
        <Label size={16} weight="700">Term breakdown</Label>
        {child.terms.length === 0 ? <Label color={C.muted} style={{ marginTop: 12 }}>No fees have been assigned yet.</Label> : null}
        {child.terms.map((term, index) => {
          const paid = term.remaining <= 0;
          const receiptId = paid ? receiptForTerm(term.id) : null;
          return (
            <View key={term.id} style={[styles.spread, { paddingVertical: 14, borderTopWidth: index ? 1 : 0, borderTopColor: C.hairline }]}>
              <View style={{ flex: 1, gap: 3 }}>
                <Label size={15} weight="700">{termName(term.label)}</Label>
                <Label size={12} color={C.muted}>{paid ? `Paid ${currency(term.paidAmount)}` : `Due ${formatLongDate(term.dueDate)} · ${currency(term.remaining)} to pay`}</Label>
              </View>
              <View style={[styles.row, { gap: 8 }]}>
                <StatusPill label={paid ? 'Paid' : 'Due'} tone={paid ? 'success' : 'danger'} />
                {paid ? (
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Receipt for ${termName(term.label)}`}
                    disabled={!receiptId}
                    onPress={() => receiptId && router.push(`/(parent)/receipt/${receiptId}`)}
                    style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center', opacity: receiptId ? 1 : 0.35 }}
                  >
                    <Icon name="receipt-outline" size={20} color={C.teal} />
                  </Pressable>
                ) : null}
              </View>
            </View>
          );
        })}
      </Panel>

      <Panel style={{ padding: 20 }}>
        <Label size={16} weight="700">Payment history</Label>
        {history.loading && !history.data ? <Label color={C.muted} style={{ marginTop: 12 }}>Loading payments…</Label> : null}
        {history.error ? (
          <Pressable accessibilityRole="button" onPress={() => void history.refetch()} style={{ marginTop: 12, minHeight: 44, justifyContent: 'center' }}>
            <Label color={C.dangerInk}>Could not load payments. Tap to try again.</Label>
          </Pressable>
        ) : null}
        {!history.loading && !history.error && (history.data ?? []).length === 0 ? <Label color={C.muted} style={{ marginTop: 12 }}>No payments yet.</Label> : null}
        {(history.data ?? []).map((payment, index) => (
          <View key={payment.id} style={[styles.spread, { paddingVertical: 14, borderTopWidth: index ? 1 : 0, borderTopColor: C.hairline }]}>
            <View style={{ flex: 1, gap: 3 }}>
              <Label size={14} weight="700">{formatLongDate(payment.paidAt)}</Label>
              <Label size={12} color={C.muted}>{METHOD_LABEL[payment.method] ?? payment.method}{payment.referenceNo ? ` · ${payment.referenceNo}` : ''}</Label>
            </View>
            <View style={[styles.row, { gap: 8 }]}>
              <Label size={15} weight="800">{currency(payment.amount)}</Label>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Download receipt for ${formatLongDate(payment.paidAt)}`}
                disabled={!payment.receiptId}
                onPress={() => payment.receiptId && router.push(`/(parent)/receipt/${payment.receiptId}`)}
                style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center', opacity: payment.receiptId ? 1 : 0.35 }}
              >
                <Icon name="download-outline" size={20} color={C.primaryInk} />
              </Pressable>
            </View>
          </View>
        ))}
      </Panel>

      <View style={{ flexDirection: 'row', gap: 12, padding: 18, borderRadius: 18, backgroundColor: C.tealSoft, alignItems: 'flex-start' }}>
        <Icon name="shield-checkmark-outline" size={20} color={C.teal} />
        <Label size={13} style={{ flex: 1, lineHeight: 20 }}>Payments are verified by the institute. You will get a receipt instantly.</Label>
      </View>
    </FamilyPage>
  );
}
