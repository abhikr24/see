import React, { useState } from 'react';
import { Linking, Platform, View } from 'react-native';
import { router } from 'expo-router';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { useColors } from '@/lib/theme';
import { toast, useFamilyReceipt } from '@/core/backend';
import { FamilyPage, METHOD_LABEL, formatLongDate, termName } from './family-parts';
import { familyReceiptHtml } from './receipt-html';
import { Action, Icon, Label, Panel, currency, styles } from './ui';

import { Pressable } from '@/components/ui/Pressable';
/** One receipt: a success tick, the dashed receipt card and two ways to keep it. */
export function ParentReceiptScreen({ id }: { id: string }) {
  const C = useColors();
  const query = useFamilyReceipt(id);
  const [making, setMaking] = useState(false);
  const back = () => router.back();

  if (query.loading && !query.data) {
    return <FamilyPage title="Receipt" onBack={back}><Panel><Label color={C.muted}>Loading the receipt…</Label></Panel></FamilyPage>;
  }
  if (query.error || !query.data) {
    return (
      <FamilyPage title="Receipt" onBack={back}>
        <Panel>
          <Label color={C.dangerInk}>{query.error?.message ?? 'That receipt could not be found.'}</Label>
          <Pressable accessibilityRole="button" onPress={() => void query.refetch()} style={{ marginTop: 14, minHeight: 44, justifyContent: 'center' }}>
            <Label weight="700" color={C.primaryInk}>Try again</Label>
          </Pressable>
        </Panel>
      </FamilyPage>
    );
  }

  const receipt = query.data;
  const rows: [string, string][] = [
    ['Student', receipt.studentName],
    ['Term', termName(receipt.termLabel)],
    ['Receipt no', receipt.receiptNo],
    ['Paid on', formatLongDate(receipt.paidAt)],
    ['Method', METHOD_LABEL[receipt.method] ?? receipt.method],
    ...(receipt.referenceNo ? [['Reference', receipt.referenceNo] as [string, string]] : []),
  ];

  const downloadPdf = async () => {
    setMaking(true);
    try {
      const html = familyReceiptHtml(receipt);
      if (Platform.OS === 'web') {
        await Print.printAsync({ html });
      } else {
        const file = await Print.printToFileAsync({ html });
        await Sharing.shareAsync(file.uri, { mimeType: 'application/pdf', UTI: '.pdf' });
      }
    } catch {
      toast.error('Could not create the PDF. Please try again.');
    } finally {
      setMaking(false);
    }
  };

  const shareWhatsApp = async () => {
    const message = `Payment receipt ${receipt.receiptNo} from ${receipt.instituteName}: ${currency(receipt.amount)} for ${receipt.studentName} (${termName(receipt.termLabel)}) on ${formatLongDate(receipt.paidAt)}${receipt.referenceNo ? `. Reference ${receipt.referenceNo}` : ''}.`;
    try {
      await Linking.openURL(`https://wa.me/?text=${encodeURIComponent(message)}`);
    } catch {
      toast.error('Could not open WhatsApp');
    }
  };

  return (
    <FamilyPage title="Receipt" onBack={back}>
      <View style={{ alignItems: 'center', gap: 12, paddingVertical: 4 }}>
        <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: C.tealSoft, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="checkmark" size={38} color={C.teal} />
        </View>
        <Label size={20} weight="800">Payment received</Label>
        <Label size={13} color={C.muted}>{receipt.instituteName} · {receipt.receiptNo}</Label>
      </View>

      <View style={{ borderRadius: 20, borderWidth: 1.5, borderStyle: 'dashed', borderColor: C.cardDash, backgroundColor: C.surface, padding: 22, gap: 4 }}>
        <Label size={11} weight="700" color={C.muted} style={{ letterSpacing: 2 }}>RECEIPT</Label>
        <Label size={40} weight="800" color={C.primaryInk} style={{ letterSpacing: -1 }}>{currency(receipt.amount)}</Label>
        {receipt.instituteCity ? <Label size={12} color={C.muted}>{receipt.instituteCity}</Label> : null}
        <View style={{ height: 1, backgroundColor: C.hairline, marginVertical: 14 }} />
        {rows.map(([label, value]) => (
          <View key={label} style={[styles.spread, { paddingVertical: 10, gap: 12 }]}>
            <Label size={13} color={C.muted}>{label}</Label>
            <Label size={13} weight="700" style={{ flexShrink: 1, textAlign: 'right' }}>{value}</Label>
          </View>
        ))}
      </View>

      <Action label={making ? 'Preparing PDF…' : 'Download PDF'} icon="download-outline" disabled={making} onPress={() => void downloadPdf()} />
      <Action label="Share on WhatsApp" icon="logo-whatsapp" secondary onPress={() => void shareWhatsApp()} />
    </FamilyPage>
  );
}
