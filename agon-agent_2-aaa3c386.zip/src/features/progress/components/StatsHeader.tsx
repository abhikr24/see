import React from 'react';
import { View } from 'react-native';
import { Card, Text } from '@/components/ui';
import { useColors } from '@/lib/theme';
import type { BoardStats } from '../model';

function Stat({ value, label }: { value: number; label: string }) {
  const C = useColors();
  return (
    <View style={{ flex: 1, alignItems: 'center', gap: 4 }}>
      <Text variant="h2" weight={800} tabular>
        {value}
      </Text>
      <Text variant="label" c={C.secondary} style={{ textAlign: 'center' }}>
        {label}
      </Text>
    </View>
  );
}

export function StatsHeader({ stats }: { stats: BoardStats }) {
  const C = useColors();
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Stat value={stats.studentsAtRisk} label="Students at risk" />
        <View style={{ width: 1, alignSelf: 'stretch', backgroundColor: C.hairline }} />
        <Stat value={stats.alertsThisWeek} label="Alerts this week" />
        <View style={{ width: 1, alignSelf: 'stretch', backgroundColor: C.hairline }} />
        <Stat value={stats.interventionsOpen} label="Interventions open" />
      </View>
    </Card>
  );
}
