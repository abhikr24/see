import React, { useCallback } from 'react';
import { SectionList, View } from 'react-native';
import { router } from 'expo-router';
import { EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import { LAYOUT, useColors } from '@/lib/theme';
import { useProgressBoard } from '../hooks';
import { GROUP_META } from '../model';
import { AlertGroup } from '../components/AlertGroup';
import { StatsHeader } from '../components/StatsHeader';

import { Refresh } from '@/components/ui/Refresh';
export function AlertListScreen() {
  const C = useColors();
  const board = useProgressBoard();

  const openStudent = useCallback((studentId: string, alertId: string, log: boolean) => {
    router.push({
      pathname: '/(owner)/progress/[studentId]',
      params: { studentId, alertId, ...(log ? { log: '1' } : {}) },
    } as never);
  }, []);

  if (board.loading && !board.data) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}>
        <ListSkeleton rows={6} h={76} />
      </View>
    );
  }

  if (board.error && !board.data) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState message={board.error.message} onRetry={() => void board.refetch()} />
      </View>
    );
  }

  const groups = (board.data?.groups ?? []).filter((group) => group.items.length > 0);

  return (
    <SectionList
      style={{ flex: 1, backgroundColor: C.canvas }}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 136, gap: 20 }}
      sections={groups.map((group) => ({
        key: group.key,
        title: GROUP_META[group.key].title,
        data: [group],
      }))}
      keyExtractor={(group) => group.key}
      renderItem={({ item }) => (
        <AlertGroup
          group={item}
          onView={(studentId, alertId) => openStudent(studentId, alertId, false)}
          onLog={(studentId, alertId) => openStudent(studentId, alertId, true)}
        />
      )}
      renderSectionHeader={() => null}
      ListHeaderComponent={
        <View style={{ gap: 14 }}>
          <View style={{ gap: 2 }}>
            <Text variant="h2">Progress alerts</Text>
            <Text variant="caption" c={C.secondary}>
              Attendance, marks and homework — recomputed every time you open this.
            </Text>
          </View>
          {board.data ? <StatsHeader stats={board.data.stats} /> : null}
        </View>
      }
      ListEmptyComponent={
        <EmptyState
          icon="checkmark-circle-outline"
          tone="teal"
          title="All clear"
          text="No student needs attention right now. Pull to check again."
        />
      }
      refreshControl={
        <Refresh refreshing={board.loading} onRefresh={() => void board.refetch()} />
      }
      showsVerticalScrollIndicator={false}
    />
  );
}
