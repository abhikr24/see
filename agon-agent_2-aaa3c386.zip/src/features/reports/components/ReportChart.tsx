import React from 'react';
import { View } from 'react-native';
import { Text } from '@/components/ui';
import { useColors } from '@/lib/theme';
import type { AnalyticsReportBar } from '@/core/contracts/models';

export function ReportChart({ bars }: { bars: AnalyticsReportBar[] }) {
  const C = useColors();
  const max = Math.max(1, ...bars.map((bar) => bar.value));
  const tallest = bars.findIndex((bar) => bar.value === max);
  return <View accessibilityLabel="Report trend chart" style={{ height: 142, flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingTop: 12 }}>
    {bars.map((bar, index) => <View key={`${bar.label}-${index}`} style={{ flex: 1, height: '100%', justifyContent: 'flex-end', alignItems: 'center', gap: 8 }}>
      <View style={{ width: '65%', minWidth: 12, height: `${Math.max(4, (bar.value / max) * 100)}%`, maxHeight: 100, backgroundColor: index === tallest ? C.accent : C.navySoft, borderTopLeftRadius: 7, borderTopRightRadius: 7 }} />
      <Text variant="label" c={C.secondary} numberOfLines={1}>{bar.label}</Text>
    </View>)}
  </View>;
}
