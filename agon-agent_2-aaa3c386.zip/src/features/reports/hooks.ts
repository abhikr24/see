import { useDomainQuery } from '@/core/hooks/domain';
import type { AnalyticsReport, AnalyticsReportQuery, AnalyticsReportType } from '@/core/contracts/models';

export function useReport(type: AnalyticsReportType, period: AnalyticsReportQuery['period'], batchId: string | null) {
  const query: AnalyticsReportQuery = { type, period, batchId };
  return useDomainQuery<AnalyticsReport>('analytics', ['report', query], (backend, instituteId) => backend.analytics.report(instituteId, query));
}
