import type { AnalyticsReport, AnalyticsReportType } from '@/core/contracts/models';

export const REPORTS: Array<{ type: AnalyticsReportType; title: string; description: string; icon: string; tint: string; tone: string }> = [
  { type: 'student-strength', title: 'Student strength', description: 'Enrolments across every batch', icon: 'people-outline', tint: '#EAF0FF', tone: '#374F9F' },
  { type: 'fee-collection', title: 'Fee collection', description: 'Collected, pending and overdue', icon: 'wallet-outline', tint: '#E4F5F1', tone: '#158B79' },
  { type: 'attendance', title: 'Attendance', description: 'Presence by student and batch', icon: 'checkmark-done-outline', tint: '#FFF3D8', tone: '#B77A0B' },
  { type: 'academic-performance', title: 'Academic performance', description: 'Published results and averages', icon: 'school-outline', tint: '#F2EAFF', tone: '#7550A6' },
  { type: 'teacher-performance', title: 'Teacher performance', description: 'Classes, attendance and progress', icon: 'briefcase-outline', tint: '#E6F2FA', tone: '#397D9E' },
  { type: 'admissions-funnel', title: 'Admissions funnel', description: 'Enquiries moving to enrolment', icon: 'filter-outline', tint: '#FDEAE5', tone: '#B85C47' },
];

export const reportTitle = (type: AnalyticsReportType): string => REPORTS.find((r) => r.type === type)?.title ?? 'Report';
export const isParentFacing = (type: AnalyticsReportType) => ['student-strength', 'attendance', 'academic-performance'].includes(type);

export function toCsv(report: AnalyticsReport): string {
  const field = (value: string | number | null | undefined) => {
    if (value === null || value === undefined) return '';
    let text = String(value);
    if (typeof value === 'string' && /^[=+\-@\t\r]/.test(text)) text = `'${text}`;
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const EOL = '\r\n';
  const rows = [
    [`${report.title} · ${report.periodLabel}`],
    [report.headlineLabel, report.headlineValue],
    ['Change vs previous period', report.deltaValue === null ? '' : report.deltaValue],
    [],
    ['Name', 'Details', ...report.columns.map((column) => column.title)],
    ...report.rows.map((row) => [row.label, row.detail, ...row.values]),
  ];
  return '\uFEFF' + rows.map((row) => row.map(field).join(',')).join(EOL) + EOL;
}

export const reportFilename = (report: AnalyticsReport) => `${report.type}-${report.from}-to-${report.to}.csv`;
