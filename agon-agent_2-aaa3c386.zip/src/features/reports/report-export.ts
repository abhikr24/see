import { Platform } from 'react-native';
import type { AnalyticsReport } from '@/core/contracts/models';
import { reportFilename, toCsv } from './model';

interface WebDownload { document: { createElement(tag: 'a'): { href: string; download: string; style: { display: string }; click(): void; remove(): void }; body: { appendChild(node: unknown): void } }; URL: { createObjectURL(blob: unknown): string; revokeObjectURL(url: string): void }; Blob: new (parts: string[], options: { type: string }) => unknown }
export async function exportReportCsv(report: AnalyticsReport): Promise<void> {
  const filename = reportFilename(report);
  const text = toCsv(report);
  if (Platform.OS === 'web') {
    const web = globalThis as unknown as WebDownload;
    const url = web.URL.createObjectURL(new web.Blob([text], { type: 'text/csv;charset=utf-8' }));
    const anchor = web.document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.style.display = 'none';
    web.document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => web.URL.revokeObjectURL(url), 10_000); return;
  }
  const [{ File, Paths }, Sharing] = await Promise.all([import('expo-file-system'), import('expo-sharing')]);
  const file = new File(Paths.cache, filename); file.create({ overwrite: true }); file.write(text);
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(file.uri, { mimeType: 'text/csv', UTI: 'public.comma-separated-values-text', dialogTitle: `${report.title} CSV` });
}

export async function exportReportPdf(report: AnalyticsReport): Promise<void> {
  const { printToFileAsync } = await import('expo-print');
  const Sharing = await import('expo-sharing');
  const esc = (value: unknown) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char] ?? char);
  const body = report.rows.map((row) => `<tr><td>${esc(row.label)}</td><td>${esc(row.detail)}</td>${row.values.map((value) => `<td>${esc(value)}</td>`).join('')}</tr>`).join('');
  const headers = report.columns.map((column) => `<th>${esc(column.title)}</th>`).join('');
  const { uri } = await printToFileAsync({ html: `<html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{font-family:Arial,sans-serif;color:#172342;padding:28px}h1{font-size:22px}.meta{color:#667085}.hero{padding:16px;background:#f1f4fa;border-radius:12px;font-size:18px;font-weight:bold}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{text-align:left;padding:9px;border-bottom:1px solid #e5e9f0;font-size:12px}th{background:#f7f8fb}</style></head><body><h1>${esc(report.title)}</h1><p class="meta">${esc(report.periodLabel)} · ${esc(report.from)} — ${esc(report.to)}</p><div class="hero">${esc(report.headlineLabel)}: ${esc(report.headlineValue)}</div><p>${esc(report.deltaLabel)}</p><table><thead><tr><th>Name</th><th>Details</th>${headers}</tr></thead><tbody>${body}</tbody></table></body></html>` });
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: `${report.title} PDF` });
}
