import React from 'react';
import { Text } from 'react-native';
import { useColors } from '@/lib/theme';
import { highlightParts } from '../model';

export function HighlightText({ text, query, style, matchStyle, baseColor }: { text: string; query: string; style?: object; matchStyle?: object; baseColor?: string }) {
  const C = useColors();
  const parts = highlightParts(text, query);
  return (
    <Text style={style} numberOfLines={1}>
      {parts.map((p, i) => (
        <Text key={i} style={p.match ? [{ color: C.primaryInk, fontWeight: '800' as const }, matchStyle] : [{ color: baseColor ?? C.ink }]}>
          {p.text}
        </Text>
      ))}
    </Text>
  );
}
