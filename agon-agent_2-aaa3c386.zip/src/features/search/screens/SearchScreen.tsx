import React, { useMemo, useState } from 'react';
import { FlatList, Keyboard, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Card, EmptyState, ErrorState, Skeleton, Text } from '@/components/ui';
import { OfflineBanner } from '@/components/ui/OfflineBanner';
import { LAYOUT, R, S, useColors } from '@/lib/theme';
import { useRecentSearches, useSearch } from '../useSearch';
import { SearchField } from '../components/SearchField';
import { HighlightText } from '../components/HighlightText';

import { Pressable } from '@/components/ui/Pressable';
function Chip({ label, onPress, onRemove }: { label: string; onPress: () => void; onRemove?: () => void }) {
  const C = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Recent search ${label}`}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        paddingHorizontal: 12,
        height: 34,
        borderRadius: R.chip,
        backgroundColor: C.surface,
        borderWidth: 1,
        borderColor: C.hairline,
        opacity: pressed ? 0.8 : 1,
      })}
    >
      <Ionicons name="time-outline" size={14} color={C.muted} />
      <Text variant="caption" weight={600} c={C.secondary}>
        {label}
      </Text>
      {onRemove ? (
        <Pressable accessibilityRole="button" accessibilityLabel={`Remove ${label}`} onPress={onRemove} hitSlop={8}>
          <Ionicons name="close" size={14} color={C.muted} />
        </Pressable>
      ) : null}
    </Pressable>
  );
}

function GroupHeader({ title, count }: { title: string; count: number }) {
  const C = useColors();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 10 }}>
      <Text variant="label" c={C.secondary} style={{ letterSpacing: 0.6 }}>
        {title.toUpperCase()}
      </Text>
      <View style={{ backgroundColor: C.track, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999 }}>
        <Text variant="label" c={C.secondary} style={{ fontSize: 10 }}>
          {count}
        </Text>
      </View>
    </View>
  );
}

function HighlightRow({ title, subtitle, query, icon, onPress }: { title: string; subtitle: string; query: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void }) {
  const C = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Open ${title}`}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 14,
        paddingVertical: 13,
        backgroundColor: pressed ? C.track : C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
      })}
    >
      <View style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: C.navyTint, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: C.hairline }}>
        <Ionicons name={icon} size={18} color={C.primaryInk} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <HighlightText text={title} query={query} style={{ fontSize: 15, fontWeight: '700', color: C.ink }} />
        <Text variant="caption" c={C.secondary} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
      <Ionicons name="chevron-forward" size={16} color={C.muted} />
    </Pressable>
  );
}

function SkeletonGroup() {
  return (
    <View style={{ gap: 10 }}>
      <Skeleton h={16} w={120} r={6} />
      <Skeleton h={64} w="100%" r={R.card} />
      <Skeleton h={64} w="100%" r={R.card} />
      <View style={{ marginTop: 8 }}>
        <Skeleton h={16} w={100} r={6} />
      </View>
      <Skeleton h={64} w="100%" r={R.card} />
    </View>
  );
}

export function SearchScreen() {
  const C = useColors();
  const [query, setQuery] = useState('');
  const { recent, push, clear, remove } = useRecentSearches();
  const { results, loading, error, refresh, query: debounced } = useSearch(query);
  const trimmed = query.trim();
  const isEmptyQuery = trimmed.length === 0;
  const hasResults = results.total > 0;

  const handleSelectRecent = (term: string) => setQuery(term);
  const handleOpen = (term: string) => {
    void push(term);
  };

  const data = useMemo(() => {
    if (isEmptyQuery || loading) return [];
    const sections: { key: string; title: string; count: number; icon: keyof typeof Ionicons.glyphMap; items: { id: string; title: string; subtitle: string }[]; onPress: (id: string) => void }[] = [];
    if (results.students.length) sections.push({ key: 'students', title: 'Students', count: results.students.length, icon: 'person-outline', items: results.students.map((s) => ({ id: s.id, title: s.title, subtitle: s.subtitle })), onPress: (id) => { handleOpen(debounced); router.push(`/(owner)/students/${id}` as never); } });
    if (results.batches.length) sections.push({ key: 'batches', title: 'Batches', count: results.batches.length, icon: 'albums-outline', items: results.batches.map((b) => ({ id: b.id, title: b.title, subtitle: b.subtitle })), onPress: (id) => { handleOpen(debounced); router.push(`/(owner)/batches/${id}` as never); } });
    if (results.materials.length) sections.push({ key: 'materials', title: 'Materials', count: results.materials.length, icon: 'document-text-outline', items: results.materials.map((m) => ({ id: m.id, title: m.title, subtitle: m.subtitle })), onPress: () => { handleOpen(debounced); router.push(`/(student)/homework/materials` as never); } });
    return sections;
  }, [isEmptyQuery, loading, results, debounced]);

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <SearchField value={query} onChange={setQuery} onCancel={() => (router.canGoBack() ? router.back() : router.replace('/(owner)' as never))} autoFocus />
      <OfflineBanner />
      {isEmptyQuery ? (
        <ScrollView keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag" contentContainerStyle={{ padding: LAYOUT.margin, gap: 16, paddingBottom: 40 }}>
          {recent.length > 0 ? (
            <View style={{ gap: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text variant="label" c={C.secondary}>
                  RECENT SEARCHES
                </Text>
                <Pressable accessibilityRole="button" accessibilityLabel="Clear recent searches" onPress={clear} hitSlop={8}>
                  <Text variant="caption" c={C.primaryInk} weight={700}>
                    Clear
                  </Text>
                </Pressable>
              </View>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {recent.map((term) => (
                  <Chip key={term} label={term} onPress={() => handleSelectRecent(term)} onRemove={() => void remove(term)} />
                ))}
              </View>
            </View>
          ) : null}
          <Card flat tint={C.onFill} pad={0} style={{ borderStyle: 'dashed', padding: 0 }}>
            <EmptyState
              icon="search-outline"
              tone="primary"
              title="Search everything"
              text="Find students, batches and materials in one place. Recent searches show up as chips above — tap one to search again."
            />
          </Card>
          <View style={{ gap: 8 }}>
            <Text variant="label" c={C.secondary}>
              TRY
            </Text>
            <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
              {['Aarav', 'Class 10-A', 'Quadratic', 'SUNRISE'].map((s) => (
                <Pressable
                  key={s}
                  onPress={() => setQuery(s)}
                  accessibilityRole="button"
                  accessibilityLabel={`Try search ${s}`}
                  style={({ pressed }) => ({
                    paddingHorizontal: 14,
                    height: 36,
                    borderRadius: R.chip,
                    backgroundColor: pressed ? C.track : C.surface,
                    borderWidth: 1,
                    borderColor: C.hairline,
                    alignItems: 'center',
                    justifyContent: 'center',
                  })}
                >
                  <Text variant="caption" weight={600} c={C.primaryInk}>
                    {s}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </ScrollView>
      ) : loading ? (
        <View style={{ flex: 1, padding: LAYOUT.margin }}>
          <SkeletonGroup />
        </View>
      ) : error ? (
        <View style={{ flex: 1, padding: LAYOUT.margin }}>
          <ErrorState message={error} onRetry={() => void refresh()} />
        </View>
      ) : !hasResults ? (
        <View style={{ flex: 1, padding: LAYOUT.margin }}>
          <Card flat>
            <EmptyState icon="search-outline" tone="neutral" title={`No results for "${debounced}"`} text="Try another name, roll or keyword. Check your spelling or try a shorter query." actionLabel="Clear search" onAction={() => setQuery('')} />
          </Card>
        </View>
      ) : (
        <FlatList
          data={data}
          keyExtractor={(s) => s.key}
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 40, gap: 18 }}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          onScrollBeginDrag={Keyboard.dismiss}
          renderItem={({ item: section }) => (
            <View style={{ gap: 8 }}>
              <GroupHeader title={section.title} count={section.count} />
              <View style={{ gap: 8 }}>
                {section.items.map((it) => (
                  <HighlightRow key={it.id} title={it.title} subtitle={it.subtitle} query={debounced} icon={section.icon} onPress={() => section.onPress(it.id)} />
                ))}
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}
