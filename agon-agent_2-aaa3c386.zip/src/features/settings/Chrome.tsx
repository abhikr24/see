import React from 'react';
import { ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Text } from '@/components/ui';
import { LAYOUT, S, useColors } from '@/lib/theme';

import { Pressable } from '@/components/ui/Pressable';
export function SettingsScroll({ children }: { children: React.ReactNode }) {
  const C = useColors();
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: C.canvas }}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: 136, gap: S.lg }}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </ScrollView>
  );
}

export function SettingsBack({ title, subtitle }: { title: string; subtitle?: string }) {
  const C = useColors();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Back"
        onPress={() => router.back()}
        hitSlop={8}
        style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}
      >
        <Ionicons name="chevron-back" size={22} color={C.primaryInk} />
      </Pressable>
      <View style={{ flex: 1, gap: 2 }}>
        <Text variant="h2">{title}</Text>
        {subtitle ? <Text variant="caption" c={C.secondary}>{subtitle}</Text> : null}
      </View>
    </View>
  );
}
