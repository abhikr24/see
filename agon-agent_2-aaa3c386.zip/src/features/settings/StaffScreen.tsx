import React, { useState } from 'react';
import { View } from 'react-native';
import { Badge, Button, Card, EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { Role } from '@/core/contracts/models';
import { R, S, useColors } from '@/lib/theme';
import { SettingsBack, SettingsScroll } from './Chrome';
import { useSettingsActions, useStaffDesk } from './hooks';
import { leaveDays, roleLabel } from './model';
import { InviteSheet, RoleSheet } from './sheets';

import { Pressable } from '@/components/ui/Pressable';
const TONE: Record<string, 'primary' | 'accent' | 'teal' | 'neutral'> = {
  owner: 'primary', admin: 'accent', teacher: 'teal',
};

export function StaffScreen() {
  const C = useColors();
  const desk = useStaffDesk();
  const actions = useSettingsActions();
  const [inviteOpen, setInviteOpen] = useState(false);
  const [link, setLink] = useState<string | null>(null);
  const [roleFor, setRoleFor] = useState<{ id: string; name: string; role: Role } | null>(null);
  const data = desk.data;

  return (
    <SettingsScroll>
      <SettingsBack title="Staff" subtitle="Roles, join links and leave" />
      <Button title="Invite by link" icon="link-outline" onPress={() => setInviteOpen(true)} />
      {link ? (
        <Card tint={C.tealSoft}>
          <Text variant="label" c={C.tealInk}>JOIN LINK COPIED</Text>
          <Text variant="caption" style={{ marginTop: 6 }}>{link}</Text>
        </Card>
      ) : null}
      {desk.loading && !data ? <ListSkeleton rows={4} /> : null}
      {desk.error ? <ErrorState title="Could not load staff" message={desk.error.message} onRetry={() => void desk.refetch()} /> : null}
      {data ? (
        <Card>
          <Text variant="label" c={C.secondary}>STAFF ATTENDANCE TODAY</Text>
          <Text variant="title" weight={800} style={{ marginTop: 4 }}>{data.present} present · {data.onLeave} on leave</Text>
        </Card>
      ) : null}
      <Card pad={6}>
        {(data?.members ?? []).map((member, index, list) => (
          <Pressable key={member.id} onPress={() => setRoleFor(member)} style={{ minHeight: 68, paddingHorizontal: 12, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: index < list.length - 1 ? 1 : 0, borderBottomColor: C.hairline }}>
            <View style={{ flex: 1 }}>
              <Text weight={700}>{member.name}</Text>
              <Text variant="caption" c={C.secondary}>{member.phone ?? member.status}</Text>
            </View>
            <Badge label={roleLabel(member.role)} tone={TONE[member.role] ?? 'neutral'} small />
          </Pressable>
        ))}
        {data && data.members.length === 0 ? <EmptyState title="No staff yet" text="Invite a teacher with a join link." icon="people-outline" /> : null}
      </Card>
      <Text variant="title" weight={800}>Leave approvals</Text>
      {(data?.pending ?? []).length === 0 ? (
        <Card><Text variant="caption" c={C.secondary}>No pending leave.</Text></Card>
      ) : (
        (data?.pending ?? []).map((item) => (
          <Card key={item.id}>
            <Text weight={700}>{item.name}</Text>
            <Text variant="caption" c={C.secondary} style={{ marginTop: 2 }}>
              {roleLabel(item.leaveType)} · {leaveDays(item.fromDate, item.toDate)} days · {item.fromDate}
            </Text>
            <Text variant="caption" style={{ marginTop: 6 }}>{item.reason}</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
              <View style={{ flex: 1 }}><Button title="Reject" variant="outline" size="sm" onPress={() => void actions.decideLeave(item.id, 'rejected')} /></View>
              <View style={{ flex: 1 }}><Button title="Approve" size="sm" onPress={() => void actions.decideLeave(item.id, 'approved')} /></View>
            </View>
          </Card>
        ))
      )}
      <InviteSheet
        visible={inviteOpen}
        onClose={() => setInviteOpen(false)}
        onInvite={async (role, name) => {
          const created = await actions.invite(role, name);
          if (created) { setLink(created.joinUrl); setInviteOpen(false); }
        }}
      />
      <RoleSheet
        visible={roleFor != null}
        name={roleFor?.name ?? ''}
        role={roleFor?.role ?? 'teacher'}
        onClose={() => setRoleFor(null)}
        onSave={async (role) => {
          if (!roleFor) return;
          const saved = await actions.setRole(roleFor.id, role);
          if (saved) setRoleFor(null);
        }}
      />
    </SettingsScroll>
  );
}
