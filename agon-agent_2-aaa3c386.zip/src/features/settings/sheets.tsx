import React, { useEffect, useState } from 'react';
import { Switch, View } from 'react-native';
import { Button, Input, Sheet, Text } from '@/components/ui';
import type { Role } from '@/core/contracts/models';
import { PALETTES, R, S, useColors } from '@/lib/theme';
import { ASSIGNABLE_ROLES, SESSIONS, roleLabel } from './model';

import { Pressable } from '@/components/ui/Pressable';
// These hexes are saved to the institute's settings, so they never follow the colour scheme.
const BRAND = PALETTES.light;
const BRANDS = [
  { label: 'Navy', value: BRAND.primary },
  { label: 'Saffron', value: BRAND.accent },
  { label: 'Teal', value: BRAND.teal },
  { label: 'Blue', value: BRAND.navyBright },
] as const;

export function EditInstituteSheet({
  visible, name, city, phone, onClose, onSave,
}: {
  visible: boolean;
  name: string;
  city: string;
  phone: string;
  onClose: () => void;
  onSave: (patch: { name: string; city: string; phone: string | null }) => Promise<void>;
}) {
  useColors();
  const [draft, setDraft] = useState({ name, city, phone });
  useEffect(() => { if (visible) setDraft({ name, city, phone }); }, [visible, name, city, phone]);
  return (
    <Sheet visible={visible} onClose={onClose} title="Edit institute" subtitle="The join code stays the same.">
      <Input label="Name" value={draft.name} onChangeText={(value) => setDraft((d) => ({ ...d, name: value }))} />
      <Input label="City" value={draft.city} onChangeText={(value) => setDraft((d) => ({ ...d, city: value }))} />
      <Input label="Phone" value={draft.phone} keyboardType="phone-pad" onChangeText={(value) => setDraft((d) => ({ ...d, phone: value }))} />
      <Button title="Save" onPress={() => void onSave({ name: draft.name.trim(), city: draft.city.trim(), phone: draft.phone.trim() || null })} />
    </Sheet>
  );
}

export function SessionSheet({
  visible, current, onClose, onSave,
}: { visible: boolean; current: string | null; onClose: () => void; onSave: (year: string) => Promise<void> }) {
  const C = useColors();
  return (
    <Sheet visible={visible} onClose={onClose} title="Academic session">
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {SESSIONS.map((year) => {
          const on = year === current;
          return (
            <Pressable key={year} onPress={() => void onSave(year)} style={{ paddingHorizontal: 14, paddingVertical: 10, borderRadius: R.chip, backgroundColor: on ? C.primary : C.surface, borderWidth: 1, borderColor: on ? C.primaryInk : C.hairline }}>
              <Text weight={700} c={on ? C.onFill : C.ink}>{year}</Text>
            </Pressable>
          );
        })}
      </View>
    </Sheet>
  );
}

export function BrandSheet({
  visible, current, locked, onClose, onSave,
}: { visible: boolean; current: string | null; locked: boolean; onClose: () => void; onSave: (color: string) => Promise<void> }) {
  const C = useColors();
  return (
    <Sheet visible={visible} onClose={onClose} title="Branding colour" subtitle={locked ? 'Renew the plan to change branding. Your data is safe.' : 'Used on receipts and the institute mark.'}>
      <View style={{ flexDirection: 'row', gap: 12 }}>
        {BRANDS.map((swatch) => (
          <Pressable key={swatch.label} disabled={locked} onPress={() => void onSave(swatch.value)} accessibilityLabel={swatch.label} style={{ alignItems: 'center', gap: 6, opacity: locked ? 0.45 : 1 }}>
            <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: swatch.value, borderWidth: current === swatch.value ? 3 : 0, borderColor: C.ink }} />
            <Text variant="label">{swatch.label}</Text>
          </Pressable>
        ))}
      </View>
    </Sheet>
  );
}

export function NotificationsSheet({
  visible, features, onClose, onSave,
}: { visible: boolean; features: Record<string, boolean>; onClose: () => void; onSave: (features: Record<string, boolean>) => Promise<void> }) {
  const C = useColors();
  const rows = [
    ['attendanceAlerts', 'Attendance alerts'],
    ['homeworkAlerts', 'Homework alerts'],
    ['noticeAlerts', 'Notice alerts'],
  ] as const;
  return (
    <Sheet visible={visible} onClose={onClose} title="Notification preferences">
      {rows.map(([key, label]) => (
        <View key={key} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 48 }}>
          <Text weight={600}>{label}</Text>
          <Switch
            value={features[key] !== false}
            onValueChange={(value) => void onSave({ ...features, [key]: value })}
            trackColor={{ false: C.track, true: C.teal }}
            thumbColor={C.onFill}
          />
        </View>
      ))}
    </Sheet>
  );
}

export function AboutSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const C = useColors();
  return (
    <Sheet visible={visible} onClose={onClose} title="About GuruFlow">
      <Text>GuruFlow 1.0.0</Text>
      <Text variant="caption" c={C.secondary} style={{ marginTop: 6 }}>
        Coaching institute software. A lapsed subscription never deletes students, attendance or fees.
      </Text>
      <View style={{ marginTop: S.lg }}><Button title="Close" variant="outline" onPress={onClose} /></View>
    </Sheet>
  );
}

export function RoleSheet({
  visible, name, role, onClose, onSave,
}: { visible: boolean; name: string; role: Role; onClose: () => void; onSave: (role: Role) => Promise<void> }) {
  const C = useColors();
  return (
    <Sheet visible={visible} onClose={onClose} title="Change role" subtitle={`${name} is ${roleLabel(role)}. Only an owner can save this.`}>
      {ASSIGNABLE_ROLES.map((option) => (
        <Pressable key={option} onPress={() => void onSave(option)} style={{ minHeight: 48, justifyContent: 'center', borderBottomWidth: 1, borderBottomColor: C.hairline }}>
          <Text weight={option === role ? 800 : 600} c={option === role ? C.primaryInk : C.ink}>{roleLabel(option)}</Text>
        </Pressable>
      ))}
    </Sheet>
  );
}

export function InviteSheet({
  visible, onClose, onInvite,
}: { visible: boolean; onClose: () => void; onInvite: (role: Exclude<Role, 'owner'>, name: string) => Promise<void> }) {
  const C = useColors();
  const [name, setName] = useState('');
  const [role, setRole] = useState<Exclude<Role, 'owner'>>('teacher');
  useEffect(() => { if (visible) { setName(''); setRole('teacher'); } }, [visible]);
  return (
    <Sheet visible={visible} onClose={onClose} title="Invite by link" subtitle="Creates an invitation and copies a join URL.">
      <Input label="Name (optional)" value={name} onChangeText={setName} placeholder="Priya Nair" />
      <View style={{ flexDirection: 'row', gap: 8, marginVertical: 8 }}>
        {(['teacher', 'admin'] as const).map((option) => (
          <Pressable key={option} onPress={() => setRole(option)} style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: R.chip, backgroundColor: role === option ? C.primary : C.surface, borderWidth: 1, borderColor: role === option ? C.primaryInk : C.hairline }}>
            <Text weight={700} c={role === option ? C.onFill : C.secondary}>{roleLabel(option)}</Text>
          </Pressable>
        ))}
      </View>
      <Button title="Create join link" onPress={() => void onInvite(role, name)} />
    </Sheet>
  );
}
