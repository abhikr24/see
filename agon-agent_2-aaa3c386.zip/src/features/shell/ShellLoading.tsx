import React from 'react';
import { ActivityIndicator, View } from 'react-native';

import { useColors } from '@/lib/theme';

/** Shown for the instant between "app opened" and "we know where you belong". */
export function ShellLoading() {
  const C = useColors();
  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}>
      <ActivityIndicator color={C.primaryInk} />
    </View>
  );
}
