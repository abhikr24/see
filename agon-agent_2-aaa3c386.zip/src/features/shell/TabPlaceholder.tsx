import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { S, useColors } from '@/lib/theme';

export interface TabPlaceholderProps {
  tabLabel: string;
  prompt: string;
  title: string;
  description: string;
}

/**
 * One minimal screen standing in for a tab that has not been built yet.
 * Deleted the moment the real screen lands — never add business logic here.
 */
export function TabPlaceholder({ tabLabel, prompt, title, description }: TabPlaceholderProps) {
  const C = useColors();
  return (
    <Screen title={tabLabel} subtitle="Coming soon" safeTop={false} tabBarInset={96}>
      <Card flat>
        <Text variant="label" c={C.accentInk}>
          {prompt}
        </Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          {title}
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          {description}
        </Text>
      </Card>
    </Screen>
  );
}
