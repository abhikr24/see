import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Text } from '@/components/ui';
import { C, R, useColors, themed } from '@/lib/theme';

import { Pressable } from '@/components/ui/Pressable';
interface Props {
  label: string; // A, B, C, D
  text: string;
  selected: boolean;
  correct?: boolean | null; // null = not evaluated, true/false after submit
  disabled?: boolean;
  onPress: () => void;
}

export function OptionCard({ label, text, selected, correct, disabled, onPress }: Props) {
  const C = useColors();
  const isTeal = correct === true;
  const isRed = correct === false;

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.card,
        selected && styles.selected,
        isTeal && styles.correct,
        isRed && styles.wrong,
        { opacity: pressed && !disabled ? 0.9 : 1 },
      ]}
    >
      <View style={[styles.badge, selected && styles.badgeSelected, isTeal && styles.badgeCorrect, isRed && styles.badgeWrong]}>
        {isTeal || (selected && correct === null) ? (
          <Ionicons name="checkmark" size={14} color={C.onFill} />
        ) : (
          <Text variant="label" weight={700} c={selected ? C.onFill : C.secondary}>
            {label}
          </Text>
        )}
      </View>
      <Text variant="body" weight={selected ? 600 : 500} c={isRed ? C.dangerInk : isTeal ? C.tealInk : C.ink} style={{ flex: 1 }}>
        {text}
      </Text>
      {isTeal ? <Ionicons name="checkmark-circle" size={18} color={C.teal} /> : null}
      {isRed ? <Ionicons name="close-circle" size={18} color={C.danger} /> : null}
    </Pressable>
  );
}

const styles = themed(() => (StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: C.hairline,
    backgroundColor: C.surface,
  },
  selected: {
    borderColor: C.primaryInk,
    backgroundColor: C.navySoft,
  },
  correct: {
    borderColor: C.teal,
    backgroundColor: C.tealSoft,
  },
  wrong: {
    borderColor: C.danger,
    backgroundColor: C.dangerSoft,
  },
  badge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.track,
  },
  badgeSelected: {
    backgroundColor: C.primary,
  },
  badgeCorrect: {
    backgroundColor: C.teal,
  },
  badgeWrong: {
    backgroundColor: C.danger,
  },
})));
