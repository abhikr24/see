import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { Text } from '@/components/ui';
import { useColors } from '@/lib/theme';
import { ringColor } from '../model';

interface Props {
  percent: number;
  size?: number;
  stroke?: number;
}

export function ScoreRing({ percent, size = 120, stroke = 10 }: Props) {
  const C = useColors();
  const radius = (size - stroke) / 2;
  const circum = 2 * Math.PI * radius;
  const progress = circum * (1 - percent / 100);
  const color = ringColor(percent);

  return (
    <View style={[styles.wrap, { width: size, height: size }]}>
      <Svg width={size} height={size} style={{ transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={radius} stroke={C.track} strokeWidth={stroke} fill="none" />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={`${circum} ${circum}`}
          strokeDashoffset={progress}
          strokeLinecap="round"
          fill="none"
        />
      </Svg>
      <View style={styles.center}>
        <Text variant="h1" weight={800} c={C.ink}>
          {percent}%
        </Text>
        <Text variant="caption" c={C.secondary}>
          Score
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  center: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
