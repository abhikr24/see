import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FlatList, Modal, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, EmptyState, ErrorState, ListSkeleton, ProgressBar, Ring, Text } from '@/components/ui';
import { useExams, useMyStudents, useStudentAchievements, useStudent360, useStudentHomework } from '@/core/backend';
import type { StudentAchievement, StudentGoal, StudyTask } from '@/core/contracts/models';
import { LAYOUT, R, useColors } from '@/lib/theme';

import { Pressable } from '@/components/ui/Pressable';
import { Refresh } from '@/components/ui/Refresh';
const isoToday = () => new Date().toISOString().slice(0, 10);
const dateLabel = (date: string | null) => date ? new Date(`${date}T12:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : 'This week';
const isFreshGoal = (goal: StudentGoal) => Date.now() - new Date(goal.createdAt).getTime() < 7 * 86400000;

function GoalCard({ goal, onComplete }: { goal: StudentGoal; onComplete: () => void }) {
  const C = useColors();
  const target = goal.targetValue ?? 1;
  const current = goal.currentValue ?? 0;
  const progress = Math.min(100, target > 0 ? current / target * 100 : goal.status === 'achieved' ? 100 : 0);
  const recent = isFreshGoal(goal);
  const onTrack = goal.status === 'achieved' || recent || progress >= 50;
  return <Card flat pad={14} style={{ gap: 9, borderRadius: R.field }}>
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
      <View style={{ flex: 1, gap: 2 }}>
        <Text variant="body" weight={700} numberOfLines={1}>{goal.title}</Text>
        <Text variant="label" c={C.muted}>{goal.metric === 'study_hours' ? 'PERSONAL HABIT' : goal.subjectId ? 'SUBJECT GOAL' : 'PERSONAL GOAL'}</Text>
      </View>
      <Badge label={goal.status === 'achieved' ? 'Complete' : onTrack ? 'On track' : 'At risk'} tone={goal.status === 'achieved' || onTrack ? 'teal' : 'warning'} small />
    </View>
    <ProgressBar value={progress} tone={onTrack ? 'primary' : 'warning'} height={5} />
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
      <Text variant="caption" c={C.secondary} tabular>{current} / {target} {goal.metric === 'study_hours' ? 'hours' : goal.metric === 'attendance_percent' || goal.metric === 'exam_percent' ? '%' : 'done'}</Text>
      {goal.status !== 'achieved' ? <Pressable accessibilityRole="button" onPress={onComplete} hitSlop={8}><Text variant="label" weight={700} c={C.primaryInk}>Mark complete</Text></Pressable> : null}
    </View>
  </Card>;
}

function StudyTaskRow({ task, onToggle }: { task: StudyTask; onToggle: () => void }) {
  const C = useColors();
  const done = task.status === 'done';
  return <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: done }} onPress={onToggle} style={({ pressed }) => ({ minHeight: 66, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 12, opacity: pressed ? 0.72 : 1 })}>
    <View style={{ width: 24, height: 24, borderRadius: 8, borderWidth: 1.5, borderColor: done ? C.teal : C.cardDash, backgroundColor: done ? C.tealSoft : C.surface, alignItems: 'center', justifyContent: 'center' }}>
      {done ? <Ionicons name="checkmark" size={16} color={C.teal} /> : null}
    </View>
    <View style={{ flex: 1, gap: 4 }}>
      <Text variant="body" weight={700} c={done ? C.muted : C.ink} style={done ? { textDecorationLine: 'line-through' } : undefined} numberOfLines={2}>{task.title}</Text>
      <Text variant="label" c={C.muted}>{task.source === 'system' ? 'STUDY PLAN' : task.dueOn ? dateLabel(task.dueOn) : 'Personal task'}</Text>
    </View>
    <Ionicons name="chevron-forward" size={17} color={C.muted} />
  </Pressable>;
}

function AchievementCard({ item, earned }: { item: { key: StudentAchievement['key']; title: string; description: string }; earned: StudentAchievement | undefined }) {
  const C = useColors();
  const unlocked = Boolean(earned);
  return <View style={{ width: 205, minHeight: 106, backgroundColor: unlocked ? C.accentSoft : C.track, borderRadius: R.field, padding: 13, gap: 8, marginRight: 10, opacity: unlocked ? 1 : 0.68 }}>
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
      <Ionicons name={unlocked ? 'ribbon' : 'lock-closed-outline'} size={18} color={unlocked ? C.accent : C.muted} />
      {unlocked ? <Text variant="label" weight={700} c={C.accentInk}>EARNED</Text> : null}
    </View>
    <Text variant="caption" weight={800} c={unlocked ? C.ink : C.secondary}>{item.title}</Text>
    <Text variant="label" c={unlocked ? C.secondary : C.muted}>{item.description}</Text>
  </View>;
}

const MILESTONES: { key: StudentAchievement['key']; title: string; description: string }[] = [
  { key: 'perfect_attendance_month', title: 'Perfect attendance', description: '100% attendance in a month' },
  { key: 'homework_streak_10', title: 'Homework hero', description: '10 assignments on time' },
  { key: 'first_90_score', title: 'First 90+', description: 'Score 90% or higher in an exam' },
];

export function StudentProgressScreen() {
  const C = useColors();
  const students = useMyStudents();
  const studentId = students.data?.[0]?.id ?? null;
  const board = useStudent360(studentId);
  const homework = useStudentHomework();
  const exams = useExams({ limit: 100 });
  const achievements = useStudentAchievements(studentId);
  const [goalForm, setGoalForm] = useState(false);
  const [goalTitle, setGoalTitle] = useState('Study 4 hours this week');
  const [goalHours, setGoalHours] = useState('4');
  const [celebration, setCelebration] = useState<StudentAchievement | null>(null);
  const generated = useRef(new Set<string>());
  const tasks = board.data?.tasks ?? [];
  const goals = board.data?.goals ?? [];
  const student = board.data?.student;

  useEffect(() => {
    if (!studentId || !board.data || !homework.data || !exams.data) return;
    const start = new Date(`${isoToday()}T00:00:00`);
    const end = new Date(start);
    end.setDate(start.getDate() + 7);
    const inWeek = (date: string | null) => !date || (new Date(`${date.slice(0, 10)}T23:59:59`).getTime() >= start.getTime() && new Date(`${date.slice(0, 10)}T00:00:00`).getTime() < end.getTime());
    const planned = [
      ...exams.data.items.filter((exam) => exam.status !== 'draft' && exam.startsOn && exam.startsOn >= isoToday() && exam.startsOn < end.toISOString().slice(0, 10)).map((exam) => ({ title: `Revise: ${exam.name}`, notes: `Prepare for ${exam.name}`, dueOn: exam.startsOn, subjectId: exam.subjectId ?? null, sourceId: exam.id })),
      ...homework.data.filter((item) => item.submissionStatus === 'pending' && inWeek(item.dueAt)).map((item) => ({ title: `Finish: ${item.title}`, notes: item.subjectName ? `${item.subjectName} homework` : 'Pending homework', dueOn: item.dueAt?.slice(0, 10) ?? null, subjectId: null, sourceId: item.id })),
    ];
    const existing = new Set(tasks.map((task) => task.title));
    const batchKey = `${studentId}:${planned.map((item) => item.sourceId).sort().join('|')}`;
    if (generated.current.has(batchKey)) return;
    generated.current.add(batchKey);
    for (const item of planned) {
      if (existing.has(item.title)) continue;
      void board.saveTask({ studentId, title: item.title, notes: item.notes, dueOn: item.dueOn, subjectId: item.subjectId, priority: 'medium', status: 'todo', source: 'system' });
    }
  }, [studentId, board.data, homework.data, exams.data, tasks, board.saveTask]);

  useEffect(() => {
    const firstUnseen = achievements.data?.find((item) => !item.celebratedAt);
    if (!firstUnseen || celebration) return;
    const firstEarned = achievements.data?.[0];
    if (!firstEarned || firstEarned.celebratedAt || celebration) return;
    void achievements.markCelebrated({ studentId: firstEarned.studentId, achievementId: firstEarned.id }).then((result) => {
      if (result.ok && result.data) setCelebration(firstEarned);
    });
  }, [achievements.data, achievements.markCelebrated, celebration]);

  const weekTasks = useMemo(() => [...tasks].sort((a, b) => Number(a.status === 'done') - Number(b.status === 'done') || (a.dueOn ?? '').localeCompare(b.dueOn ?? '')), [tasks]);
  const refresh = async () => { await Promise.all([students.refetch(), board.refetch(), homework.refetch(), exams.refetch(), achievements.refetch()]); };
  const saveNewGoal = async () => {
    if (!studentId || !goalTitle.trim() || Number(goalHours) < 1) return;
    const saved = await board.saveGoal({ studentId, title: goalTitle.trim(), description: 'A personal weekly study goal', metric: 'study_hours', targetValue: Number(goalHours), currentValue: 0, startsOn: isoToday(), targetDate: null, status: 'active', createdBy: null });
    if (saved.ok) setGoalForm(false);
  };
  const completeGoal = async (goal: StudentGoal) => board.saveGoal({ ...goal, currentValue: goal.targetValue ?? goal.currentValue, status: 'achieved' });
  const toggleTask = async (task: StudyTask) => board.saveTask({ ...task, status: task.status === 'done' ? 'todo' : 'done', completedAt: task.status === 'done' ? null : new Date().toISOString() });

  const head = <View style={{ gap: 18, paddingBottom: 16 }}>
    <View style={{ gap: 4 }}><Text variant="h2" weight={800}>Progress</Text><Text variant="caption" c={C.secondary}>Small steps add up. Keep your rhythm.</Text></View>
    <Card flat pad={17} style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
      <Ring value={board.data?.attendance.percent ?? 0} size={104} stroke={7} tone={C.primaryInk} label="attendance" />
      <View style={{ flex: 1, gap: 7 }}>
        <Text variant="label" c={C.muted}>YOUR AVERAGE</Text>
        <Text variant="h2" weight={800} tabular>{board.data?.snapshot.examPercent === null || !board.data ? '—' : `${Math.round(board.data.snapshot.examPercent)}%`}</Text>
        <Text variant="caption" c={C.secondary} tabular>{board.data?.attendance.total ?? 0} classes tracked</Text>
      </View>
    </Card>
    {celebration ? <View style={{ backgroundColor: C.accentSoft, borderWidth: 1, borderColor: C.accent, borderRadius: R.card, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
      <Ionicons name="sparkles" size={25} color={C.accent} /><View style={{ flex: 1, gap: 3 }}><Text variant="body" weight={800}>Your first milestone!</Text><Text variant="caption" c={C.secondary}>{celebration.title} — {celebration.description}. Keep it going.</Text></View>
    </View> : null}
    <View style={{ gap: 10 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text variant="title" weight={800}>Goals</Text><Pressable onPress={() => setGoalForm(true)} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Ionicons name="add-circle" size={20} color={C.primaryInk} /><Text variant="caption" weight={700} c={C.primaryInk}>Add goal</Text></Pressable></View>
      {goals.length ? goals.map((goal) => <GoalCard key={goal.id} goal={goal} onComplete={() => void completeGoal(goal)} />) : <Card flat pad={14}><Text variant="caption" c={C.secondary}>Set one small goal to start building a routine.</Text></Card>}
    </View>
    <View style={{ gap: 10 }}><Text variant="title" weight={800}>Study planner</Text><Text variant="caption" c={C.secondary}>This week · exams and pending homework</Text></View>
  </View>;
  if ((students.loading || board.loading) && !board.data) return <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}><ListSkeleton rows={4} h={90} /></View>;
  if (students.error && !student) return <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}><ErrorState message={students.error.message} onRetry={() => void students.refetch()} /></View>;
  if (board.error && !board.data) return <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }}><ErrorState message={board.error.message} onRetry={() => void board.refetch()} /></View>;
  return <>
    <FlatList
      style={{ flex: 1, backgroundColor: C.canvas }}
      contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 132, flexGrow: 1 }}
      data={weekTasks}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => <View style={{ backgroundColor: C.surface, borderBottomColor: C.hairline, borderBottomWidth: 1 }}><StudyTaskRow task={item} onToggle={() => void toggleTask(item)} /></View>}
      ListHeaderComponent={head}
      ListEmptyComponent={<Card flat pad={16}><EmptyState icon="calendar-outline" title="A clear week" text="Upcoming exams and assigned homework will show up here." /></Card>}
      ListFooterComponent={<View style={{ gap: 10, paddingTop: 22 }}><Text variant="title" weight={800}>Achievements</Text><Text variant="caption" c={C.secondary}>Earned milestones glow in saffron.</Text><FlatList horizontal showsHorizontalScrollIndicator={false} data={MILESTONES} keyExtractor={(item) => item.key} renderItem={({ item }) => <AchievementCard item={item} earned={achievements.data?.find((achievement) => achievement.key === item.key)} />} /></View>}
      refreshControl={<Refresh refreshing={board.loading && Boolean(board.data)} onRefresh={() => void refresh()} />}
      showsVerticalScrollIndicator={false}
    />
    <Modal visible={goalForm} transparent animationType="slide" onRequestClose={() => setGoalForm(false)}>
      <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: C.scrim }}>
        <View style={{ backgroundColor: C.surface, padding: 22, paddingBottom: 34, borderTopLeftRadius: 28, borderTopRightRadius: 28, gap: 14 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><View style={{ gap: 3 }}><Text variant="title" weight={800}>A goal of your own</Text><Text variant="caption" c={C.secondary}>Make it yours. You can adjust it later.</Text></View><Pressable onPress={() => setGoalForm(false)} hitSlop={10}><Ionicons name="close" size={22} color={C.secondary} /></Pressable></View>
          <TextInput value={goalTitle} onChangeText={setGoalTitle} placeholder="Study 4 hours this week" returnKeyType="next" style={{ minHeight: 50, borderWidth: 1, borderColor: C.hairline, borderRadius: R.field, paddingHorizontal: 14, color: C.ink }} />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><Text variant="caption" c={C.secondary}>Hours this week</Text><TextInput value={goalHours} onChangeText={setGoalHours} keyboardType="number-pad" returnKeyType="done" style={{ width: 76, height: 46, borderWidth: 1, borderColor: C.hairline, borderRadius: R.field, paddingHorizontal: 12, textAlign: 'center', color: C.ink }} /></View>
          <Button title="Add personal goal" icon="flag-outline" onPress={() => void saveNewGoal()} loading={board.saving} />
        </View>
      </View>
    </Modal>
  </>;
}
