import React, { useMemo, useState } from 'react';
import { FlatList, Share, View, useWindowDimensions } from 'react-native';
import Svg, { Circle, Polyline } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { ExamAnalysis, ID } from '@/core/contracts/models';
import { dateShort } from '@/lib/format';
import { LAYOUT, R, useColors } from '@/lib/theme';
import { useExamAnalysis, useStudentExamList, type StudentExamRow } from '../exams/analysis-hooks';

import { Pressable } from '@/components/ui/Pressable';
import { Refresh } from '@/components/ui/Refresh';
function Trend({ rows, width }: { rows: StudentExamRow[]; width: number }) {
  const C = useColors();
  const points = rows.slice(0, 5).reverse();
  if (!points.length) return <Text variant="caption" c={C.muted}>Scores will appear as tests are published.</Text>;
  const height = 94;
  const pad = 12;
  const usableWidth = Math.max(120, width - 48);
  const coords = points.map((row, index) => {
    const x = points.length === 1 ? usableWidth / 2 : pad + index * (usableWidth - pad * 2) / (points.length - 1);
    const y = height - pad - Math.max(0, Math.min(100, row.percentage)) / 100 * (height - pad * 2);
    return `${x},${y}`;
  }).join(' ');
  const last = points[points.length - 1];
  const xLast = points.length === 1 ? usableWidth / 2 : usableWidth - pad;
  const yLast = height - pad - Math.max(0, Math.min(100, last.percentage)) / 100 * (height - pad * 2);
  return <View style={{ gap: 6 }}>
    <Svg width={usableWidth} height={height}>
      <Polyline points={coords} fill="none" stroke={C.primaryInk} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
      <Circle cx={xLast} cy={yLast} r={5} fill={C.accent} stroke={C.onFill} strokeWidth={2} />
    </Svg>
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <Text variant="label" c={C.muted} numberOfLines={1}>{points[0]?.name ?? ''}</Text>
      <Text variant="label" c={C.secondary} numberOfLines={1}>{last.name}</Text>
    </View>
  </View>;
}

function SubjectRow({ name, score }: { name: string; score: number }) {
  const C = useColors();
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 40 }}>
    <Text variant="caption" weight={600} numberOfLines={1} style={{ width: 100 }}>{name}</Text>
    <View style={{ flex: 1, height: 5, borderRadius: R.chip, backgroundColor: C.track, overflow: 'hidden' }}>
      <View style={{ width: `${Math.max(0, Math.min(100, score))}%`, height: '100%', backgroundColor: C.primary, borderRadius: R.chip }} />
    </View>
    <Text variant="caption" weight={700} tabular style={{ width: 42, textAlign: 'right' }}>{Math.round(score)}%</Text>
  </View>;
}

function HistoryRow({ item, onPress }: { item: StudentExamRow; onPress: () => void }) {
  const C = useColors();
  return <Pressable onPress={onPress} accessibilityRole="button" style={({ pressed }) => ({ minHeight: 64, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 12, opacity: pressed ? 0.7 : 1 })}>
    <View style={{ flex: 1, gap: 3 }}>
      <Text variant="body" weight={700} numberOfLines={1}>{item.name}</Text>
      <Text variant="label" c={C.muted}>{item.date ? dateShort(item.date) : 'Date not set'}</Text>
    </View>
    <Text variant="body" weight={800} tabular>{item.marksObtained}/{item.maxMarks}</Text>
    <Ionicons name="chevron-forward" size={17} color={C.muted} />
  </Pressable>;
}

function ResultsHeader({
  exam, score, analysis, trend, width, onReport,
}: {
  exam: StudentExamRow | null; score: ExamAnalysis['students'][number] | null;
  analysis: ExamAnalysis | null; trend: StudentExamRow[]; width: number; onReport: () => void;
}) {
  const C = useColors();
  if (!exam || !analysis || !score) return null;
  return <View style={{ gap: 18, paddingBottom: 8 }}>
    <View style={{ gap: 4 }}>
      <Text variant="h2" weight={800}>Results</Text>
      <Text variant="caption" c={C.secondary}>Your results, one test at a time.</Text>
    </View>
    <View style={{ borderRadius: R.card, backgroundColor: C.primary, padding: 20, gap: 12 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1, gap: 3 }}>
          <Text variant="label" c={C.navyPale}>EXAM REPORT</Text>
          <Text variant="title" weight={700} c={C.onFill} numberOfLines={1}>{analysis.examName}</Text>
        </View>
        <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: C.heroGlass, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="school-outline" size={19} color={C.onFill} />
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
        <Text variant="h1" weight={800} c={C.onFill} tabular style={{ fontSize: 44, lineHeight: 52 }}>{score.marksObtained}</Text>
        <Text variant="title" weight={600} c={C.navyPale} tabular>/ {score.maxMarks}</Text>
        <Text variant="caption" weight={700} c={C.onFill} style={{ marginLeft: 'auto' }}>{Math.round(score.percentage)}%</Text>
      </View>
      <Text variant="caption" c={C.navyPale} tabular>Class average {analysis.averagePct === null ? '—' : `${Math.round(analysis.averagePct)}%`} · Rank {score.rank ?? '—'} of {analysis.totalStudents}</Text>
      <Button title="Report card" icon="document-text-outline" variant="secondary" size="md" onPress={onReport} />
    </View>
    <View style={{ gap: 10 }}>
      <Text variant="title" weight={800}>Your trend</Text>
      <Card flat pad={14}><Trend rows={trend} width={width} /></Card>
    </View>
    <View style={{ gap: 10 }}>
      <Text variant="title" weight={800}>Subject-wise</Text>
      <Card flat pad={14} style={{ gap: 7 }}>
        {analysis.subjectAverages.slice(0, 4).map((subject) => <SubjectRow key={subject.subjectId} name={subject.subjectName} score={subject.averagePct} />)}
      </Card>
    </View>
    <Text variant="title" weight={800}>Exam history</Text>
  </View>;
}

export function StudentResultsScreen() {
  const C = useColors();
  const list = useStudentExamList();
  const [selected, setSelected] = useState<ID | null>(null);
  const { width } = useWindowDimensions();
  const rows = useMemo(() => list.data ?? [], [list.data]);
  const examRows = useMemo(() => {
    const seen = new Set<ID>();
    return rows.filter((row) => !seen.has(row.examId) && Boolean(seen.add(row.examId)));
  }, [rows]);
  const selectedId = selected && examRows.some((row) => row.examId === selected) ? selected : examRows[0]?.examId ?? null;
  const analysisQuery = useExamAnalysis(selectedId);
  const exam = examRows.find((row) => row.examId === selectedId) ?? null;
  const score = analysisQuery.data?.students.find((student) => student.studentId === exam?.studentId) ?? null;
  const trend = [...rows].sort((a, b) => (b.date ?? '').localeCompare(a.date ?? '')).slice(0, 5);
  const report = async () => {
    if (!exam || !score || !analysisQuery.data) return;
    const summary = `${analysisQuery.data.examName}\nScore: ${score.marksObtained}/${score.maxMarks} (${Math.round(score.percentage)}%)\nClass average: ${Math.round(analysisQuery.data.averagePct ?? 0)}%\nRank: ${score.rank ?? '—'} of ${analysisQuery.data.totalStudents}`;
    await Share.share({ title: `${analysisQuery.data.examName} report card`, message: summary });
  };
  const header = list.loading && !list.data ? <ListSkeleton rows={4} h={84} />
    : list.error && !list.data ? <ErrorState message={list.error.message} onRetry={() => void list.refetch()} />
      : rows.length === 0 ? <View><Text variant="h2" weight={800}>Results</Text><EmptyState icon="ribbon-outline" title="No results yet" text="Your results will appear when an exam is published." /></View>
        : analysisQuery.loading && !analysisQuery.data ? <ListSkeleton rows={4} h={84} />
          : analysisQuery.error && !analysisQuery.data ? <ErrorState message={analysisQuery.error.message} onRetry={() => void analysisQuery.refetch()} />
            : <ResultsHeader exam={exam} score={score} analysis={analysisQuery.data ?? null} trend={trend} width={width} onReport={() => void report()} />;
  return <FlatList
    style={{ flex: 1, backgroundColor: C.canvas }}
    contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 136, gap: 0, flexGrow: 1 }}
    data={header && rows.length > 0 && analysisQuery.data && !analysisQuery.loading ? examRows : []}
    keyExtractor={(item) => item.examId}
    renderItem={({ item }) => <View style={{ borderBottomWidth: 1, borderBottomColor: C.hairline }}><HistoryRow item={item} onPress={() => setSelected(item.examId)} /></View>}
    ListHeaderComponent={<View style={{ gap: 16 }}>{header}</View>}
    refreshControl={<Refresh refreshing={list.loading && Boolean(list.data)} onRefresh={() => void list.refetch()} />}
    ListEmptyComponent={rows.length > 0 && !list.loading && analysisQuery.data ? <Card flat pad={14}><Text variant="caption" c={C.secondary}>Exam records will appear here.</Text></Card> : null}
    showsVerticalScrollIndicator={false}
  />;
}
