import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Platform, useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  PALETTES,
  ThemeContext,
  setActiveScheme,
  type Scheme,
  type ThemePreference,
  type ThemeState,
} from './theme';

/** Device-level, like the other on-device settings (recent searches, outbox). */
const PREFERENCE_KEY = 'guruflow.settings.appearance';

const isPreference = (value: unknown): value is ThemePreference =>
  value === 'system' || value === 'light' || value === 'dark';

/**
 * Web only: page background, native form controls and a visible keyboard
 * focus ring, all from the palette so no colour is written outside theme.ts.
 */
function useWebChrome(scheme: Scheme) {
  useEffect(() => {
    if (Platform.OS !== 'web' || typeof document === 'undefined') return;
    const C = PALETTES[scheme];
    const id = 'guruflow-theme';
    const tag = document.getElementById(id) ?? document.head.appendChild(Object.assign(document.createElement('style'), { id }));
    tag.textContent = [
      `html, body { background-color: ${C.canvas}; color-scheme: ${scheme}; }`,
      // Mouse and touch presses stay clean; keyboard focus is always visible.
      `:focus { outline: none; }`,
      `:focus-visible { outline: 2px solid ${C.focusRing} !important; outline-offset: 2px; border-radius: 6px; }`,
      `input:focus-visible, textarea:focus-visible { outline-offset: 0; }`,
    ].join('\n');
  }, [scheme]);
}

/**
 * Resolves the colour scheme for the whole app: the system scheme by default,
 * or the System / Light / Dark choice made in Settings, which is remembered on
 * this device. Mounted once in app/_layout.
 */
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [preference, setPreferenceState] = useState<ThemePreference>('system');

  useEffect(() => {
    let alive = true;
    void AsyncStorage.getItem(PREFERENCE_KEY)
      .then((stored) => {
        if (alive && isPreference(stored)) setPreferenceState(stored);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, []);

  const setPreference = useCallback((next: ThemePreference) => {
    setPreferenceState(next);
    void AsyncStorage.setItem(PREFERENCE_KEY, next).catch(() => undefined);
  }, []);

  const scheme: Scheme = preference === 'system' ? (system === 'dark' ? 'dark' : 'light') : preference;
  // Set while rendering, so every child below reads the right palette on this pass.
  setActiveScheme(scheme);
  useWebChrome(scheme);

  const value = useMemo<ThemeState>(() => ({ scheme, preference, setPreference }), [scheme, preference, setPreference]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}
