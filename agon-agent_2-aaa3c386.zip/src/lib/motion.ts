import { useSyncExternalStore } from 'react';
import { AccessibilityInfo, Platform } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Easing, ReduceMotion, withDelay, withSpring, withTiming } from 'react-native-reanimated';

/**
 * The app's whole motion vocabulary: every duration, easing, spring and
 * haptic lives here. No screen hardcodes a duration or imports expo-haptics.
 * See docs/DESIGN-LOG.md § Premium polish.
 */
export const DUR = {
  /** Press-in feedback. */
  tap: 90,
  /** Icon cross-fades, reduced-motion fades, small state changes. */
  quick: 180,
  /** Scrims, screen slides, skeleton → content cross-fades, row entrances. */
  base: 240,
  /** Skeleton shimmer sweep and other slow, ambient motion. */
  slow: 320,
} as const;

export const EASE = {
  out: Easing.out(Easing.cubic),
  inOut: Easing.inOut(Easing.cubic),
} as const;

/**
 * `mass: 1` is spelled out because Reanimated 4 defaults to mass 4, which
 * would turn these figures into a long wobble.
 */
export const SPRING = {
  /** Press scale, tab pill, segmented thumb, badge pop. */
  press: { damping: 18, stiffness: 320, mass: 1 },
  /** Sheets, dialogs, toasts and the undo bar. */
  sheet: { damping: 24, stiffness: 220, mass: 1 },
} as const;

/** Press-in scale for every pressable. */
export const PRESS_SCALE = 0.97;

/** List entrance: fade + rise, one row after another, first rows only. */
export const STAGGER = {
  step: 40,
  cap: 12,
  rise: 8,
} as const;

/** Lifetimes that are not animations but still must not be scattered about. */
export const LIFE = {
  /** A success or info toast. Errors stay until dismissed. */
  toast: 4000,
  /** How long an Undo offer stays. */
  undo: 5000,
  /** Splash hold before the first route. */
  splash: 900,
  /** Skeleton shimmer: one sweep, then a rest of the same length. */
  shimmerRest: DUR.slow * 3,
  /** Long-press before a row menu opens. */
  longPress: 350,
} as const;

/** At most this many toasts on screen; the oldest non-error leaves first. */
export const TOAST_MAX = 2;

// ── Reduced motion ───────────────────────────────────────────────────────

let reduceMotion = false;
const reduceListeners = new Set<() => void>();

function setReduceMotion(next: boolean) {
  if (reduceMotion === next) return;
  reduceMotion = next;
  reduceListeners.forEach((listener) => listener());
}

if (Platform.OS === 'web') {
  const media =
    typeof globalThis.matchMedia === 'function' ? globalThis.matchMedia('(prefers-reduced-motion: reduce)') : null;
  if (media) {
    reduceMotion = media.matches;
    media.addEventListener?.('change', (event) => setReduceMotion(event.matches));
  }
} else {
  void AccessibilityInfo.isReduceMotionEnabled()
    .then(setReduceMotion)
    .catch(() => undefined);
  AccessibilityInfo.addEventListener('reduceMotionChanged', setReduceMotion);
}

/** True while the OS "reduce motion" setting is on. Read outside React. */
export function isReduceMotion(): boolean {
  return reduceMotion;
}

/** True while the OS "reduce motion" setting is on. Re-renders when it changes. */
export function useReduceMotion(): boolean {
  return useSyncExternalStore(
    (listener) => {
      reduceListeners.add(listener);
      return () => {
        reduceListeners.delete(listener);
      };
    },
    isReduceMotion,
    () => false,
  );
}

/**
 * Every animation below opts out of Reanimated's own reduced-motion handling
 * (which would snap to the end) because the reduced path here is a designed
 * one: a DUR.quick fade instead of a spring.
 */
const KEEP = { reduceMotion: ReduceMotion.Never } as const;

export type SpringName = keyof typeof SPRING;

/** A spring, or a DUR.quick ease when reduce motion is on. */
export function springTo(value: number, spring: SpringName = 'press', reduced = reduceMotion) {
  return reduced
    ? withTiming(value, { duration: DUR.quick, easing: EASE.out, ...KEEP })
    : withSpring(value, { ...SPRING[spring], ...KEEP });
}

/** A timed ease. Durations come from `DUR`. */
export function timeTo(value: number, duration: number = DUR.base, easing = EASE.out) {
  return withTiming(value, { duration, easing, ...KEEP });
}

/** A timed ease after a delay (list stagger). */
export function timeToAfter(delay: number, value: number, duration: number = DUR.base) {
  return withDelay(delay, withTiming(value, { duration, easing: EASE.out, ...KEEP }));
}

// ── Haptics ──────────────────────────────────────────────────────────────

export type HapticKind = 'light' | 'medium' | 'success' | 'warning';

const silent = () => undefined;

/**
 * The one place haptics are fired from.
 *   light   — every tile, chip, tab, row and primary button tap
 *   medium  — destructive actions (delete, archive, reject)
 *   success — a completed save (attendance, marks, fee collect)
 *   warning — an action that was refused
 * A no-op on web. Haptics are kept when reduce motion is on.
 */
export function haptic(kind: HapticKind = 'light'): void {
  if (Platform.OS === 'web') return;
  switch (kind) {
    case 'medium':
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(silent);
      return;
    case 'success':
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(silent);
      return;
    case 'warning':
      void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(silent);
      return;
    default:
      void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(silent);
  }
}

/** Kept for the attendance code that already called these by name. */
export const tapHaptic = (): void => haptic('light');
export const successHaptic = (): void => haptic('success');
