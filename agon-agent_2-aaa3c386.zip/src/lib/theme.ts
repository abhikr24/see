import { createContext, useContext } from 'react';
import { Platform } from 'react-native';

/**
 * Single source of truth for every colour, radius, spacing and shadow.
 * No component or file may hardcode a hex value outside this module.
 * See AGENTS.md § Design system and docs/DESIGN-LOG.md § Premium polish.
 *
 * Colours come in two palettes with identical keys. Components read them
 * through `useColors()` (or `useTheme()`), which follows the ThemeProvider
 * mounted in app/_layout. The exported `C` is a live view of the active
 * palette for code that cannot call a hook (models, module-level tables).
 */
const LIGHT = {
  canvas: '#F5F6FA',
  surface: '#FFFFFF',
  ink: '#0B1220',
  /** Deepened from #5A6684 so it still reads as a step above `muted`. */
  secondary: '#4E5A78',
  /** Darkened from #94A0BC so labels reach 4.5:1 on canvas, surface, track and navySoft. */
  muted: '#5F6A88',
  hairline: '#E9EDF6',
  /** Brand fill: buttons, selected chips, navy cards. Use `primaryInk` for text and icons. */
  primary: '#101B4C',
  primary2: '#1E3A8A',
  accent: '#FF7A1A',
  accentSoft: '#FFF1E6',
  teal: '#0D9488',
  tealSoft: '#E4F7F4',
  /** Heatmap teal tints between the full teal and the surface (strong → light). */
  tealMid: '#56B4AC',
  tealLight: '#92CFC9',
  success: '#16A34A',
  successSoft: '#DCF5E5',
  warning: '#F59E0B',
  warningSoft: '#FEF1D6',
  danger: '#DC2626',
  dangerSoft: '#FEECEC',
  track: '#EFF2F8',
  navySoft: '#E8EEFF',
  /** Softer than navySoft: the wash behind an unread notification. */
  navyTint: '#F4F7FF',
  navyMid: '#93B4FF',
  navyBright: '#3B66D6',
  navyPale: '#B9C1DE',
  heroLine: '#2B3561',
  heroGlass: '#26315D',
  duesInk: '#8A5A0F',
  cardDash: '#D7DDEB',
  createCanvas: '#F2F4F9',
  archiveCanvas: '#F0F2F7',
  scrim: 'rgba(11, 18, 32, 0.45)',
  transparent: 'transparent',

  // ── Role tokens (same meaning in both schemes) ─────────────────────────
  /** Text and icons sitting on a brand or semantic fill (navy, red, teal, the hero). */
  onFill: '#FFFFFF',
  /** Text on the saffron accent fill. White on saffron is 2.6:1; navy is 6.3:1. */
  onAccent: '#101B4C',
  /** Navy as a foreground: headings, links, selected icons, selected borders. */
  primaryInk: '#101B4C',
  /** Semantic tones as text. Darker than the fills so they hold 4.5:1 on their soft washes. */
  accentInk: '#B8400A',
  tealInk: '#0F766E',
  successInk: '#166534',
  warningInk: '#92400E',
  dangerInk: '#B91C1C',
  /** Muted copy on the navy hero, where the surface-side `muted` would be too dark. */
  onHeroMuted: '#B9C1DE',
  /** The hero stays navy in both schemes. */
  heroStart: '#101B4C',
  heroMid: '#1E3A8A',
  heroEnd: '#22307A',
  /** 1px inner top highlight on stat cards and the tab bar. */
  highlight: 'rgba(255,255,255,0.06)',
  /** Skeleton shimmer band. */
  shimmer: 'rgba(255,255,255,0.72)',
  shimmerEdge: 'rgba(255,255,255,0)',
  /** Keyboard focus ring (web). */
  focusRing: '#3B66D6',
  /** Shadow tint. Navy in light; pure black in dark, where navy would glow. */
  shadow: '#101B4C',

  // Contract-check & legacy dark-mode support tokens (kept for the dev screens)
  darkCanvas: '#0B1020',
  darkSurface: '#151B2E',
  darkBorder: '#28324D',
  darkText: '#F3F4F6',
  darkMuted: '#A3ACBD',
  darkPassText: '#BBF7D0',
  darkPassFill: '#14532D',
  darkPassBar: '#4ADE80',
  darkFailText: '#FECACA',
  darkFailFill: '#7F1D1D',
  darkFailBar: '#F87171',
} as const;

export type ColorToken = keyof typeof LIGHT;
export type Palette = { readonly [K in ColorToken]: string };

const DARK: Palette = {
  ...LIGHT,
  canvas: '#0B1020',
  surface: '#151B2E',
  ink: '#F3F4F6',
  secondary: '#A3ACBD',
  muted: '#929BB3',
  hairline: '#28324D',
  primary: '#3454C4',
  primary2: '#1E3A8A',
  accent: '#FF7A1A',
  accentSoft: '#3B2413',
  teal: '#0D9488',
  tealSoft: '#0F2E2B',
  tealMid: '#0B6A62',
  tealLight: '#0C4742',
  success: '#16A34A',
  successSoft: '#12301E',
  warning: '#F59E0B',
  warningSoft: '#3A2B0A',
  /** Kept at the light value: white on it must hold 4.5:1. Red text uses `dangerInk`. */
  danger: '#DC2626',
  dangerSoft: '#3A1719',
  track: '#1C2440',
  navySoft: '#1E2A52',
  navyTint: '#131A33',
  navyBright: '#7C9BF2',
  duesInk: '#F2C063',
  cardDash: '#33405F',
  createCanvas: '#0E1426',
  archiveCanvas: '#101629',
  scrim: 'rgba(2, 5, 12, 0.66)',

  onFill: '#FFFFFF',
  onAccent: '#101B4C',
  primaryInk: '#A9C0FF',
  accentInk: '#FF9A4D',
  tealInk: '#2DD4BF',
  successInk: '#4ADE80',
  warningInk: '#FBBF24',
  dangerInk: '#F87171',
  highlight: 'rgba(255,255,255,0.06)',
  shimmer: 'rgba(255,255,255,0.10)',
  shimmerEdge: 'rgba(255,255,255,0)',
  focusRing: '#93B4FF',
  shadow: '#000000',
};

export type Scheme = 'light' | 'dark';
export type ThemePreference = 'system' | Scheme;

export const PALETTES: Record<Scheme, Palette> = { light: LIGHT, dark: DARK };

let activeScheme: Scheme = 'light';

/** Called by ThemeProvider while it renders, before any child reads a colour. */
export function setActiveScheme(scheme: Scheme): void {
  activeScheme = scheme;
}

export function getActiveScheme(): Scheme {
  return activeScheme;
}

function live<T extends object>(read: () => T, shape: T): T {
  const out = {} as T;
  for (const key of Object.keys(shape) as (keyof T)[]) {
    Object.defineProperty(out, key, { enumerable: true, get: () => read()[key] });
  }
  return out;
}

/**
 * Live view of the active palette. Reading `C.surface` returns the colour for
 * the scheme the ThemeProvider last rendered with. Components should prefer
 * `const C = useColors()` so they re-render when the scheme changes; this
 * export is for models and helpers that run outside React.
 */
export const C: Palette = live(() => PALETTES[activeScheme], LIGHT);

/**
 * Wraps a module-level table or StyleSheet that reads `C`, so it is rebuilt
 * once per scheme instead of freezing the colours it saw at import time.
 */
export function themed<T extends object>(build: () => T): T {
  const cache: Partial<Record<Scheme, T>> = {};
  const current = (): T => (cache[activeScheme] ??= build());
  const seed = build();
  cache[activeScheme] = seed;
  return new Proxy(seed, {
    get: (_t, key) => Reflect.get(current(), key),
    has: (_t, key) => Reflect.has(current(), key),
    ownKeys: () => Reflect.ownKeys(current()),
    getOwnPropertyDescriptor: (_t, key) => {
      const d = Reflect.getOwnPropertyDescriptor(current(), key);
      return d ? { ...d, configurable: true } : undefined;
    },
  });
}

/** The hero keeps its navy in both schemes: primary → primary2 → #22307A at 135°. */
export const GRADIENT = [LIGHT.heroStart, LIGHT.heroMid, LIGHT.heroEnd] as const;
export const GRADIENT_START = { x: 0, y: 0 } as const;
export const GRADIENT_END = { x: 1, y: 1 } as const;

export const FONT_SIZE = {
  h1: 34,
  h2: 22,
  title: 17,
  body: 15,
  caption: 13,
  label: 11,
} as const;

/** Type rhythm. Ratios multiply the font size; spacing is in points. */
export const TYPE = {
  headingLine: 1.15,
  bodyLine: 1.45,
  captionLine: 1.35,
  headingTracking: -0.3,
  /** Applied to any text at `displayMin` points and above (figures and big headings). */
  displayTracking: -0.5,
  displayMin: 22,
} as const;

/** One vertical rhythm for every screen. */
export const RHYTHM = {
  screenTop: 12,
  section: 24,
  card: 12,
} as const;

export const hit = 44;

export const R = {
  card: 20,
  btn: 16,
  field: 14,
  sheet: 28,
  chip: 999,
  cell: 8,
} as const;

export const S = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
} as const;

/** Screen side margin, card padding, and minimum touch target. */
export const LAYOUT = {
  margin: 20,
  cardPad: 18,
  hit: 44,
  row: 68,
  /** Height the floating tab bar occupies above the bottom safe-area inset. */
  tabBar: 72,
} as const;

export const FONT = {
  heading: 'Heading',
  body: 'Jakarta',
  mono: 'Courier',
} as const;

type ShadowStyle = {
  shadowColor: string;
  shadowOpacity: number;
  shadowRadius: number;
  shadowOffset: { width: number; height: number };
  elevation: number;
};

const shadowScale = (): { raised: ShadowStyle; overlay: ShadowStyle; flat: ShadowStyle } => {
  const tint = PALETTES[activeScheme].shadow;
  const boost = activeScheme === 'dark' ? 3 : 1;
  return {
    /** Cards. y8 blur20 primary@0.10 */
    raised: { shadowColor: tint, shadowOpacity: 0.1 * boost, shadowRadius: 20, shadowOffset: { width: 0, height: 8 }, elevation: 3 },
    /** Sheets, dialogs, toasts and the floating tab bar. y16 blur32 primary@0.16 */
    overlay: { shadowColor: tint, shadowOpacity: 0.16 * boost, shadowRadius: 32, shadowOffset: { width: 0, height: 16 }, elevation: 12 },
    /** Explicitly no shadow: resets one inherited from a base style. */
    flat: { shadowColor: tint, shadowOpacity: 0, shadowRadius: 0, shadowOffset: { width: 0, height: 0 }, elevation: 0 },
  };
};

/** The only shadows in the app. `raised` on cards, `overlay` on sheets and the tab bar. */
export const SHADOW = live(shadowScale, shadowScale());

export type Tone = 'neutral' | 'success' | 'warning' | 'danger' | 'teal' | 'accent' | 'primary';

export interface ToneColors {
  /** Text on `bg`. Holds 4.5:1 against it in both schemes. */
  fg: string;
  /** The soft wash. */
  bg: string;
  /** The saturated tone itself: progress bars, dots, chart marks. */
  fill: string;
  /** Glyphs on `bg`: the vivid tone in light, the brighter ink in dark. */
  icon: string;
}

const toneTable = (): Record<Tone, ToneColors> => {
  const p = PALETTES[activeScheme];
  const dark = activeScheme === 'dark';
  return {
    neutral: { fg: p.secondary, bg: p.track, fill: p.secondary, icon: p.secondary },
    success: { fg: p.successInk, bg: p.successSoft, fill: p.success, icon: dark ? p.successInk : p.success },
    warning: { fg: p.warningInk, bg: p.warningSoft, fill: p.warning, icon: dark ? p.warningInk : p.warning },
    danger: { fg: p.dangerInk, bg: p.dangerSoft, fill: p.danger, icon: dark ? p.dangerInk : p.danger },
    teal: { fg: p.tealInk, bg: p.tealSoft, fill: p.teal, icon: dark ? p.tealInk : p.teal },
    accent: { fg: p.accentInk, bg: p.accentSoft, fill: p.accent, icon: dark ? p.accentInk : p.accent },
    primary: { fg: p.primaryInk, bg: p.navySoft, fill: p.primary, icon: p.primaryInk },
  };
};

/** Live per scheme, like `C`. */
export const TONE: Record<Tone, ToneColors> = live(toneTable, toneTable());

export interface Theme {
  dark: boolean;
  scheme: Scheme;
  /** The full palette for this scheme. */
  colors: Palette;
  background: string;
  surface: string;
  border: string;
  text: string;
  muted: string;
  primary: string;
  onPrimary: string;
  passText: string;
  passFill: string;
  passBar: string;
  failText: string;
  failFill: string;
  failBar: string;
}

const lightTheme: Theme = {
  dark: false,
  scheme: 'light',
  colors: LIGHT,
  background: LIGHT.canvas,
  surface: LIGHT.surface,
  border: LIGHT.hairline,
  text: LIGHT.ink,
  muted: LIGHT.secondary,
  primary: LIGHT.primary,
  onPrimary: LIGHT.onFill,
  passText: LIGHT.successInk,
  passFill: LIGHT.successSoft,
  passBar: LIGHT.success,
  failText: LIGHT.dangerInk,
  failFill: LIGHT.dangerSoft,
  failBar: LIGHT.danger,
};

const darkTheme: Theme = {
  dark: true,
  scheme: 'dark',
  colors: DARK,
  background: DARK.canvas,
  surface: DARK.surface,
  border: DARK.hairline,
  text: DARK.ink,
  muted: DARK.secondary,
  primary: DARK.navyMid,
  onPrimary: DARK.canvas,
  passText: DARK.darkPassText,
  passFill: DARK.darkPassFill,
  passBar: DARK.darkPassBar,
  failText: DARK.darkFailText,
  failFill: DARK.darkFailFill,
  failBar: DARK.darkFailBar,
};

export const THEMES: Record<Scheme, Theme> = { light: lightTheme, dark: darkTheme };

export interface ThemeState {
  scheme: Scheme;
  preference: ThemePreference;
  setPreference: (next: ThemePreference) => void;
}

export const ThemeContext = createContext<ThemeState>({
  scheme: 'light',
  preference: 'system',
  setPreference: () => undefined,
});

/** The palette for the active scheme. Every component reads colours through this. */
export function useColors(): Palette {
  return PALETTES[useContext(ThemeContext).scheme];
}

export function useTheme(): Theme {
  return THEMES[useContext(ThemeContext).scheme];
}

/** The System / Light / Dark choice and its setter, for the Settings switch. */
export function useThemePreference(): ThemeState {
  return useContext(ThemeContext);
}

export const MONO = Platform.select({
  ios: 'Menlo',
  android: 'monospace',
  default: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
});
