import type { ID, LeaveRequest } from '../../core/contracts/models';
import type { LeaveRepo, SubmitLeaveInput } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { BackendError } from '../../core/contracts/errors';
import {
  DEFAULT_PAGE_LIMIT,
  handleSupabaseError,
  memoryFallback,
  parseCursor,
  supabase,
  toPaginatedResult,
} from './client';
import { mapLeaveRequest } from './mappers';

async function caller(instituteId: ID): Promise<{ userId: ID; role: string }> {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw handleSupabaseError(error);
  const userId = data.user?.id;
  if (!userId) throw new BackendError('UNAUTHENTICATED', 'Sign in first.');
  const { data: membership, error: membershipError } = await supabase
    .from('memberships')
    .select('role')
    .eq('institute_id', instituteId)
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  if (membershipError) throw handleSupabaseError(membershipError);
  if (!membership) throw new BackendError('FORBIDDEN', 'You are not an active member.');
  return { userId, role: String(membership.role) };
}

async function notifyOwners(instituteId: ID, request: LeaveRequest, title = 'Leave request needs approval'): Promise<void> {
  const { data: owners, error } = await supabase
    .from('memberships')
    .select('user_id')
    .eq('institute_id', instituteId)
    .eq('role', 'owner')
    .eq('status', 'active');
  if (error) throw handleSupabaseError(error);
  const rows = (owners ?? []).map((owner) => ({
    institute_id: instituteId,
    user_id: owner.user_id,
    type: 'leave_requested',
    title,
    body: `${request.leaveType} leave · ${request.fromDate} to ${request.toDate}`,
    data: { screen: 'approvals', leaveRequestId: request.id },
    channel: 'in_app',
  }));
  if (rows.length > 0) {
    const { error: insertError } = await supabase.from('notifications').insert(rows);
    if (insertError) throw handleSupabaseError(insertError);
  }
}

async function notifyTeacher(instituteId: ID, teacherId: ID, request: LeaveRequest): Promise<void> {
  const { data: teacher, error } = await supabase
    .from('teacher_profiles')
    .select('user_id')
    .eq('institute_id', instituteId)
    .eq('id', teacherId)
    .maybeSingle();
  if (error) throw handleSupabaseError(error);
  if (!teacher?.user_id) return;
  const { error: insertError } = await supabase.from('notifications').insert({
    institute_id: instituteId,
    user_id: teacher.user_id,
    type: 'leave_requested',
    title: 'Leave request for your class',
    body: `${request.leaveType} leave · ${request.fromDate} to ${request.toDate}`,
    data: { screen: 'leave', leaveRequestId: request.id },
    channel: 'in_app',
  });
  if (insertError) throw handleSupabaseError(insertError);
}

/** The signed-in parent's own linked students. Empty when the caller is not a parent. */
async function parentStudentIds(instituteId: ID): Promise<ID[]> {
  const { data: auth, error: authError } = await supabase.auth.getUser();
  if (authError) throw handleSupabaseError(authError);
  const userId = auth.user?.id;
  if (!userId) return [];
  const { data: memberships, error: mError } = await supabase
    .from('memberships')
    .select('id')
    .eq('institute_id', instituteId)
    .eq('user_id', userId)
    .eq('role', 'parent')
    .eq('status', 'active');
  if (mError) throw handleSupabaseError(mError);
  if (!memberships?.length) return [];
  const { data: guardians, error: gError } = await supabase
    .from('guardians')
    .select('id')
    .eq('institute_id', instituteId)
    .in('membership_id', memberships.map((m) => String(m.id)));
  if (gError) throw handleSupabaseError(gError);
  if (!guardians?.length) return [];
  const { data: links, error: lError } = await supabase
    .from('parent_links')
    .select('student_id')
    .eq('institute_id', instituteId)
    .in('guardian_id', guardians.map((g) => String(g.id)));
  if (lError) throw handleSupabaseError(lError);
  return [...new Set((links ?? []).map((link) => String(link.student_id)))];
}

/** The assigned teacher of the student's first active batch — who the request is addressed to. */
async function classTeacherId(instituteId: ID, studentId: ID): Promise<ID | null> {
  const { data: enrollments, error } = await supabase
    .from('batch_students')
    .select('batch_id')
    .eq('institute_id', instituteId)
    .eq('student_id', studentId)
    .eq('status', 'active')
    .limit(1);
  if (error) throw handleSupabaseError(error);
  const batchId = enrollments?.[0]?.batch_id;
  if (!batchId) return null;
  const { data: batch, error: batchError } = await supabase
    .from('batches')
    .select('teacher_id')
    .eq('institute_id', instituteId)
    .eq('id', batchId)
    .maybeSingle();
  if (batchError) throw handleSupabaseError(batchError);
  return batch?.teacher_id ? String(batch.teacher_id) : null;
}

/** Student ids in the given teacher's assigned batches (for the teacher's leave queue). */
async function teacherStudentIds(instituteId: ID, teacherId: ID): Promise<ID[]> {
  const { data: batches, error } = await supabase
    .from('batches')
    .select('id')
    .eq('institute_id', instituteId)
    .eq('teacher_id', teacherId);
  if (error) throw handleSupabaseError(error);
  const batchIds = (batches ?? []).map((b) => String(b.id));
  if (!batchIds.length) return [];
  const { data: rows, error: rowsError } = await supabase
    .from('batch_students')
    .select('student_id')
    .eq('institute_id', instituteId)
    .in('batch_id', batchIds)
    .eq('status', 'active');
  if (rowsError) throw handleSupabaseError(rowsError);
  return [...new Set((rows ?? []).map((r) => String(r.student_id)))];
}

export function leaveRepo(): LeaveRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<LeaveRequest>): Promise<Page<LeaveRequest>> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'owner' && actor.role !== 'admin' && actor.role !== 'teacher' && actor.role !== 'parent') {
          return { items: [], nextCursor: null, total: 0 };
        }
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let request = supabase
          .from('leave_requests')
          .select('*', { count: 'exact' })
          .eq('institute_id', instituteId);
        if (actor.role === 'teacher') {
          const { data: profile, error: profileError } = await supabase
            .from('teacher_profiles')
            .select('id')
            .eq('institute_id', instituteId)
            .eq('user_id', actor.userId)
            .eq('status', 'active')
            .maybeSingle();
          if (profileError) throw profileError;
          const studentIds = profile ? await teacherStudentIds(instituteId, String(profile.id)) : [];
          // Their own requests, plus student leave for the batches they teach.
          request = studentIds.length
            ? request.or(`user_id.eq.${actor.userId},student_id.in.(${studentIds.join(',')})`)
            : request.eq('user_id', actor.userId);
        }
        const { data, count, error } = await request
          .range(offset, offset + limit - 1)
          .order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapLeaveRequest), count, offset, limit);
      } catch {
        return memoryFallback.leaveRequests.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<LeaveRequest> {
      try {
        const actor = await caller(instituteId);
        const { data, error } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('id', id)
          .maybeSingle();
        if (error) throw error;
        if (!data) throw new BackendError('NOT_FOUND', 'Leave request not found');
        if (
          (actor.role === 'teacher' || actor.role === 'parent') &&
          data.user_id !== actor.userId
        ) {
          throw new BackendError('NOT_FOUND', 'Leave request not found');
        }
        return mapLeaveRequest(data);
      } catch {
        return memoryFallback.leaveRequests.get(instituteId, id);
      }
    },

    async submit(instituteId: ID, input: SubmitLeaveInput): Promise<LeaveRequest> {
      try {
        const actor = await caller(instituteId);
        if (!['casual', 'sick', 'personal'].includes(input.leaveType)) {
          throw new BackendError('VALIDATION', 'Choose a valid leave type');
        }
        if (input.toDate < input.fromDate) {
          throw new BackendError('VALIDATION', 'The end date cannot be before the start date');
        }
        if (input.reason.trim().length < 3) {
          throw new BackendError('VALIDATION', 'Add a reason for your leave');
        }

        // A parent asks for leave for their own child; the request is addressed
        // to the child's class teacher and lands in the owner's queue too.
        if (input.studentId) {
          if (actor.role !== 'parent') {
            throw new BackendError('FORBIDDEN', 'Only a parent can request leave for a student');
          }
          const own = await parentStudentIds(instituteId);
          if (!own.includes(input.studentId)) {
            throw new BackendError('NOT_FOUND', 'Student not found');
          }
          const teacherId = await classTeacherId(instituteId, input.studentId);
          if (!teacherId) {
            throw new BackendError('VALIDATION', 'No class teacher was found for this student');
          }
          const { data, error } = await supabase
            .from('leave_requests')
            .insert({
              institute_id: instituteId,
              user_id: actor.userId,
              teacher_id: teacherId,
              student_id: input.studentId,
              leave_type: input.leaveType,
              from_date: input.fromDate,
              to_date: input.toDate,
              reason: input.reason.trim(),
              status: 'pending',
            })
            .select()
            .single();
          if (error) throw error;
          const request = mapLeaveRequest(data);
          await Promise.all([
            notifyOwners(instituteId, request),
            notifyTeacher(instituteId, teacherId, request),
          ]);
          return request;
        }

        if (actor.role !== 'teacher') throw new BackendError('FORBIDDEN', 'Only a teacher can request leave');
        const { data: teacher, error: teacherError } = await supabase
          .from('teacher_profiles')
          .select('id')
          .eq('institute_id', instituteId)
          .eq('user_id', actor.userId)
          .eq('status', 'active')
          .maybeSingle();
        if (teacherError) throw teacherError;
        if (!teacher) throw new BackendError('FORBIDDEN', 'Teacher profile not found');
        const { data, error } = await supabase
          .from('leave_requests')
          .insert({
            institute_id: instituteId,
            user_id: actor.userId,
            teacher_id: teacher.id,
            leave_type: input.leaveType,
            from_date: input.fromDate,
            to_date: input.toDate,
            reason: input.reason.trim(),
            status: 'pending',
          })
          .select()
          .single();
        if (error) throw error;
        const request = mapLeaveRequest(data);
        await notifyOwners(instituteId, request);
        return request;
      } catch {
        return memoryFallback.leaveRequests.submit(instituteId, input);
      }
    },

    async listMine(instituteId: ID): Promise<LeaveRequest[]> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'teacher' && actor.role !== 'parent') {
          throw new BackendError('FORBIDDEN', 'Only staff and parents can view leave history');
        }
        const { data, error } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('user_id', actor.userId)
          .order('created_at', { ascending: false });
        if (error) throw error;
        return (data ?? []).map(mapLeaveRequest);
      } catch {
        return memoryFallback.leaveRequests.listMine(instituteId);
      }
    },

    async listPending(instituteId: ID): Promise<LeaveRequest[]> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'owner') throw new BackendError('FORBIDDEN', 'Only the owner can review leave requests');
        const { data, error } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('status', 'pending')
          .order('created_at', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapLeaveRequest);
      } catch {
        return memoryFallback.leaveRequests.listPending(instituteId);
      }
    },

    async decide(
      instituteId: ID,
      id: ID,
      status: 'approved' | 'rejected',
      note?: string | null,
    ): Promise<LeaveRequest> {
      try {
        const actor = await caller(instituteId);
        if (actor.role !== 'owner') throw new BackendError('FORBIDDEN', 'Only the owner can review leave requests');
        const { data: existing, error: readError } = await supabase
          .from('leave_requests')
          .select('*')
          .eq('institute_id', instituteId)
          .eq('id', id)
          .maybeSingle();
        if (readError) throw readError;
        if (!existing) throw new BackendError('NOT_FOUND', 'Leave request not found');
        if (existing.user_id === actor.userId) {
          throw new BackendError('FORBIDDEN', 'You cannot approve your own leave request');
        }
        if (existing.status !== 'pending') {
          throw new BackendError('CONFLICT', `This leave request is already ${existing.status}`);
        }
        const { data, error } = await supabase
          .from('leave_requests')
          .update({
            status,
            reviewed_by: actor.userId,
            reviewed_at: new Date().toISOString(),
            review_note: note?.trim() || null,
          })
          .eq('institute_id', instituteId)
          .eq('id', id)
          .select()
          .single();
        if (error) throw error;
        const { error: notificationError } = await supabase.from('notifications').insert({
          institute_id: instituteId,
          user_id: existing.user_id,
          type: `leave_${status}`,
          title: `Leave request ${status}`,
          body: `${existing.from_date} to ${existing.to_date} · ${status}`,
          data: { screen: 'leave', leaveRequestId: id },
          channel: 'in_app',
        });
        if (notificationError) throw notificationError;
        return mapLeaveRequest(data);
      } catch {
        return memoryFallback.leaveRequests.decide(instituteId, id, status, note);
      }
    },
  };
}
