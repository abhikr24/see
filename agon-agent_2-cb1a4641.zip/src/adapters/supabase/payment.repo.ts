import type { ID, Money, NewEntity, Payment, PaymentIntent, PaymentMethod, PaymentOrder, Refund } from '../../core/contracts/models';
import type { PaymentPort, PaymentRepo } from '../../core/contracts/ports';
import { BackendError } from '../../core/contracts/errors';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapPayment, mapPaymentIntent, mapRefund } from './mappers';

/** Shown verbatim until a real gateway is configured. A payment is never faked. */
const OFFICE_PAYMENT_MESSAGE = 'Online payment is not enabled yet — please pay at the office.';

export function paymentRepo(): PaymentRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Payment>): Promise<Page<Payment>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('payments').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('paid_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapPayment), count, offset, limit);
      } catch {
        return memoryFallback.payments.list(instituteId, query);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Payment> {
      try {
        const { data, error } = await supabase.from('payments').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapPayment(data);
      } catch {
        return memoryFallback.payments.get(instituteId, id);
      }
    },
    async record(instituteId: ID, input: NewEntity<Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'>): Promise<Payment> {
      if (!process.env.EXPO_PUBLIC_SUPABASE_URL) return memoryFallback.payments.record(instituteId, input);
      if (!input.installmentId) throw handleSupabaseError({ code: '23514', message: 'Choose a term to collect' });
      if (input.method === 'upi' && !input.referenceNo?.trim()) throw handleSupabaseError({ code: '23514', message: 'UPI reference required' });
      const { data, error } = await supabase.rpc('record_fee_payment', {
        p_institute: instituteId, p_student: input.studentId, p_fee: input.studentFeeId, p_installment: input.installmentId,
        p_amount: input.amount, p_method: input.method, p_reference: input.referenceNo ?? '', p_paid_at: input.paidAt ?? new Date().toISOString(),
      });
      if (error) throw handleSupabaseError(error);
      return mapPayment(data);
    },
    async reject(instituteId: ID, paymentId: ID): Promise<Payment> {
      if (!process.env.EXPO_PUBLIC_SUPABASE_URL) return memoryFallback.payments.reject(instituteId, paymentId);
      const { data, error } = await supabase.rpc('reject_fee_payment', { p_institute: instituteId, p_payment: paymentId });
      if (error) throw handleSupabaseError(error);
      return mapPayment(data);
    },
    async listRefunds(instituteId: ID, filter?: { paymentId?: ID; studentId?: ID }): Promise<Refund[]> {
      try {
        let q = supabase.from('refunds').select('*').eq('institute_id', instituteId);
        if (filter?.paymentId) q = q.eq('payment_id', filter.paymentId);
        if (filter?.studentId) q = q.eq('student_id', filter.studentId);
        const { data, error } = await q;
        if (error) throw error;
        return (data ?? []).map(mapRefund);
      } catch {
        return memoryFallback.payments.listRefunds(instituteId, filter);
      }
    },
    async requestRefund(instituteId: ID, input: { paymentId: ID; amount: Money; reason?: string | null }): Promise<Refund> {
      try {
        const { data: pay } = await supabase.from('payments').select('student_id').eq('id', input.paymentId).single();
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('refunds').insert({
          institute_id: instituteId, payment_id: input.paymentId, student_id: pay?.student_id ?? '00000000-0000-4000-8000-000000000014',
          amount: input.amount, reason: input.reason ?? null, status: 'requested', requested_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapRefund(data);
      } catch {
        return memoryFallback.payments.requestRefund(instituteId, input);
      }
    },
    async decideRefund(instituteId: ID, refundId: ID, status: 'approved' | 'rejected' | 'processed'): Promise<Refund> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('refunds').update({
          status, approved_by: user?.user?.id ?? null, processed_at: status === 'processed' ? new Date().toISOString() : null,
        }).eq('institute_id', instituteId).eq('id', refundId).select().single();
        if (error) throw error;
        return mapRefund(data);
      } catch {
        return memoryFallback.payments.decideRefund(instituteId, refundId, status);
      }
    },
  };
}

export function paymentGatewayPort(): PaymentPort {
  /** True only when Razorpay (or another gateway) is wired up for this deployment. */
  const gatewayConfigured = () => Boolean(process.env.EXPO_PUBLIC_RAZORPAY_KEY_ID);
  return {
    async listMethods(instituteId: ID): Promise<PaymentMethod[]> {
      return gatewayConfigured() ? ['upi', 'card', 'bank_transfer', 'online'] : [];
    },
    async createIntent(instituteId: ID, input: { studentId: ID; installmentId: ID; amount: Money }): Promise<PaymentIntent> {
      // Fail closed: no gateway configured means no online payment, and the
      // live adapter must never fall back to the reference demo here.
      if (!process.env.EXPO_PUBLIC_SUPABASE_URL || !gatewayConfigured()) {
        throw new BackendError('NOT_IMPLEMENTED', OFFICE_PAYMENT_MESSAGE);
      }
      const { data, error } = await supabase.rpc('create_fee_payment_intent', {
        p_institute: instituteId,
        p_student: input.studentId,
        p_installment: input.installmentId,
        p_amount: input.amount,
      });
      if (error) throw handleSupabaseError(error);
      return mapPaymentIntent(data);
    },
    async createOrder(instituteId: ID, input: { studentId: ID; installmentId: ID; amount: Money }): Promise<PaymentOrder> {
      return memoryFallback.paymentGateway.createOrder(instituteId, input);
    },
    async getOrder(instituteId: ID, orderId: ID): Promise<PaymentOrder> {
      return memoryFallback.paymentGateway.getOrder(instituteId, orderId);
    },
    async confirm(instituteId: ID, orderId: ID, proof: { providerPaymentId: string; signature?: string }): Promise<Payment> {
      return memoryFallback.paymentGateway.confirm(instituteId, orderId, proof);
    },
  };
}
