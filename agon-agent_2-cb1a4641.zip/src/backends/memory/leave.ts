import type { ID, LeaveRequest } from '../../core/contracts/models';
import type { LeaveRepo, SubmitLeaveInput } from '../../core/contracts/ports';
import { emit, requireUser, type Db } from './db';
import * as D from './defaults';
import { parentChildIds } from './parent';
import { assignmentOf, batchesAssignedTo, callerRole, callerTeacher } from './teacher-scope';
import { fail, merge, nowIso } from './store';

const LEAVE_TYPES = new Set<SubmitLeaveInput['leaveType']>(['casual', 'sick', 'personal']);

function ownerIds(db: Db, instituteId: ID): ID[] {
  return db.memberships
    .all(instituteId, { role: 'owner', status: 'active' })
    .map((membership) => membership.userId);
}

function notify(db: Db, instituteId: ID, userId: ID, request: LeaveRequest, title: string): void {
  const sent = db.notifications.insert(
    instituteId,
    merge(D.notification(), {
      userId,
      type: 'leave_requested',
      title,
      body: `${request.leaveType} leave · ${request.fromDate} to ${request.toDate}`,
      data: { screen: 'approvals', leaveRequestId: request.id },
    }),
  );
  emit(db, instituteId, 'notifications', 'created', sent.id);
}

function notifyOwners(db: Db, instituteId: ID, request: LeaveRequest): void {
  for (const userId of ownerIds(db, instituteId)) {
    notify(db, instituteId, userId, request, 'Leave request needs approval');
  }
}

/** The active enrollments behind one leave request: student leaves carry the student. */
function enrolledBatchIds(db: Db, instituteId: ID, request: LeaveRequest): ID[] {
  if (!request.studentId) return [];
  return db.enrollments
    .all(instituteId, { studentId: request.studentId, status: 'active' })
    .map((enrollment) => enrollment.batchId);
}

/** Every class teacher of the batches a student leave touches. */
function studentTeacherUserIds(db: Db, instituteId: ID, request: LeaveRequest): ID[] {
  const userIds: ID[] = [];
  for (const batchId of enrolledBatchIds(db, instituteId, request)) {
    const batch = db.batches.find(instituteId, { id: batchId });
    if (!batch) continue;
    const teacherId = assignmentOf(db, instituteId, batch).teacherId;
    const teacher = teacherId ? db.teachers.find(instituteId, { id: teacherId }) : null;
    if (teacher?.userId && !userIds.includes(teacher.userId)) userIds.push(teacher.userId);
  }
  return userIds;
}

/** True when the student named on the request is in one of the caller's assigned batches. */
function teacherSeesStudentLeave(db: Db, instituteId: ID, request: LeaveRequest, teacherId: ID | null): boolean {
  if (!request.studentId || !teacherId) return false;
  const ownBatchIds = new Set(batchesAssignedTo(db, instituteId, teacherId).map((batch) => batch.id));
  return enrolledBatchIds(db, instituteId, request).some((batchId) => ownBatchIds.has(batchId));
}

function validateDates(input: SubmitLeaveInput): void {
  if (!LEAVE_TYPES.has(input.leaveType)) fail('VALIDATION', 'Choose a valid leave type');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.fromDate) || !/^\d{4}-\d{2}-\d{2}$/.test(input.toDate)) {
    fail('VALIDATION', 'Choose valid leave dates');
  }
  if (input.toDate < input.fromDate) fail('VALIDATION', 'The end date cannot be before the start date');
  if (input.reason.trim().length < 3) fail('VALIDATION', 'Add a reason for the leave');
}

export function leaveRepo(db: Db): LeaveRepo {
  return {
    list: async (instituteId, query) => {
      const role = callerRole(db, instituteId);
      if (role === 'owner' || role === 'admin') return db.leaveRequests.page(instituteId, query);
      const userId = requireUser(db);
      if (role === 'parent') return db.leaveRequests.page(instituteId, query, { userId });
      if (role !== 'teacher') return { items: [], nextCursor: null, total: 0 };
      const teacher = callerTeacher(db, instituteId);
      return db.leaveRequests.page(instituteId, query, {}, (request) =>
        request.userId === userId || teacherSeesStudentLeave(db, instituteId, request, teacher?.id ?? null),
      );
    },

    get: async (instituteId, id) => {
      const request = db.leaveRequests.get(instituteId, id);
      const role = callerRole(db, instituteId);
      if (role === 'owner' || role === 'admin') return request;
      const userId = requireUser(db);
      if (request.userId === userId) return request;
      if (role === 'teacher') {
        const teacher = callerTeacher(db, instituteId);
        if (teacherSeesStudentLeave(db, instituteId, request, teacher?.id ?? null)) return request;
      }
      fail('NOT_FOUND', 'Leave request not found');
    },

    submit: async (instituteId, input) => {
      const userId = requireUser(db);
      const role = callerRole(db, instituteId);
      validateDates(input);

      // A parent asks for leave for their own child; the request is addressed
      // to the child's class teacher and lands in the owner's queue too.
      if (input.studentId) {
        if (role !== 'parent') fail('FORBIDDEN', 'Only a parent can request leave for a student');
        if (!parentChildIds(db, instituteId).includes(input.studentId)) {
          fail('NOT_FOUND', 'Student not found');
        }
        const batchIds = db.enrollments
          .all(instituteId, { studentId: input.studentId, status: 'active' })
          .map((enrollment) => enrollment.batchId);
        const teacherId = batchIds
          .map((batchId) => db.batches.find(instituteId, { id: batchId }))
          .find(Boolean)
          ?.teacherId ?? null;
        if (!teacherId || !db.teachers.find(instituteId, { id: teacherId })) {
          fail('VALIDATION', 'No class teacher was found for this student');
        }
        const request = db.leaveRequests.insert(
          instituteId,
          merge(D.leaveRequest(), {
            leaveType: input.leaveType,
            fromDate: input.fromDate,
            toDate: input.toDate,
            reason: input.reason.trim(),
            studentId: input.studentId,
            userId,
            teacherId,
          }),
        );
        notifyOwners(db, instituteId, request);
        for (const teacherUserId of studentTeacherUserIds(db, instituteId, request)) {
          notify(db, instituteId, teacherUserId, request, 'Leave request for your class');
        }
        emit(db, instituteId, 'leave_requests', 'created', request.id);
        return request;
      }

      if (role !== 'teacher') fail('FORBIDDEN', 'Only a teacher can request leave');
      const teacher = callerTeacher(db, instituteId);
      if (!teacher) fail('FORBIDDEN', 'Teacher profile not found');
      const request = db.leaveRequests.insert(
        instituteId,
        merge(D.leaveRequest(), {
          leaveType: input.leaveType,
          fromDate: input.fromDate,
          toDate: input.toDate,
          reason: input.reason.trim(),
          studentId: null,
          userId,
          teacherId: teacher.id,
        }),
      );
      notifyOwners(db, instituteId, request);
      emit(db, instituteId, 'leave_requests', 'created', request.id);
      return request;
    },

    listMine: async (instituteId) => {
      const role = callerRole(db, instituteId);
      const userId = requireUser(db);
      if (role === 'teacher') {
        const teacher = callerTeacher(db, instituteId);
        return db.leaveRequests
          .all(instituteId)
          .filter((request) => request.userId === userId || teacherSeesStudentLeave(db, instituteId, request, teacher?.id ?? null))
          .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      }
      if (role === 'parent') {
        return db.leaveRequests
          .all(instituteId, { userId })
          .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      }
      return db.leaveRequests
        .all(instituteId, { userId })
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },

    listPending: async (instituteId) => {
      if (callerRole(db, instituteId) !== 'owner') {
        fail('FORBIDDEN', 'Only the owner can review leave requests');
      }
      return db.leaveRequests
        .all(instituteId, { status: 'pending' })
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    },

    decide: async (instituteId, id, status, note = null) => {
      if (callerRole(db, instituteId) !== 'owner') {
        fail('FORBIDDEN', 'Only the owner can review leave requests');
      }
      const reviewerId = requireUser(db);
      const request = db.leaveRequests.get(instituteId, id);
      if (request.userId === reviewerId) {
        fail('FORBIDDEN', 'You cannot approve your own leave request');
      }
      if (request.status !== 'pending') {
        fail('CONFLICT', `This leave request is already ${request.status}`);
      }
      const updated = db.leaveRequests.update(instituteId, id, {
        status,
        reviewedBy: reviewerId,
        reviewedAt: nowIso(),
        reviewNote: note?.trim() || null,
      });
      const sent = db.notifications.insert(
        instituteId,
        merge(D.notification(), {
          userId: request.userId,
          type: `leave_${status}`,
          title: `Leave request ${status}`,
          body: `${request.fromDate} to ${request.toDate} · ${status}`,
          data: { screen: 'leave', leaveRequestId: request.id },
        }),
      );
      emit(db, instituteId, 'notifications', 'created', sent.id);
      emit(db, instituteId, 'leave_requests', 'updated', id);
      return updated;
    },
  };
}
