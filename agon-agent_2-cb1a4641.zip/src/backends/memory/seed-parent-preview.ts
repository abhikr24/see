import type { Db } from './db';
import * as D from './defaults';
import { addDays, nowIso, todayIso } from './store';

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
export const PARENT_PREVIEW = { userId: sid(92000), aaravId: sid(14), siyaId: sid(92003), instituteId: sid(1) };
/** Explicitly opt-in reference fixture. Never runs in a connected/live backend. */
export function seedParentPreview(db: Db): void {
  const inst = sid(1);
  if (db.auditLogs.find(inst, { action: 'preview.parent.seed.v2' })) return;
  const at = nowIso();
  const today = todayIso();
  const month = today.slice(0, 7);
  const date = (day: number) => `${month}-${String(day).padStart(2, '0')}`;
  const row = (n: number) => ({ id: sid(n), instituteId: inst, createdAt: at, updatedAt: at });
  db.profiles.set(sid(92000), { ...D.profile(), id: sid(92001), userId: sid(92000), fullName: 'Rahul Sharma', email: 'rahul.parent@sunrise.test', avatarUrl: 'bundled:rahul', createdAt: at, updatedAt: at });
  db.memberships.put({ ...row(92002), userId: sid(92000), role: 'parent', status: 'active', branchId: sid(8), permissions: [], requestNote: null, requestedAt: at, decidedAt: at, decidedBy: sid(2) });
  db.guardians.put({ ...D.guardian(), ...row(92004), fullName: 'Rahul Sharma', membershipId: sid(92002), relation: 'father' });
  db.students.put({ ...D.student(), ...row(92003), fullName: 'Siya Sharma', classGrade: '9', photoUrl: 'bundled:siya', admissionNo: 'SCC-0920' });
  db.students.update(inst, sid(14), { photoUrl: 'bundled:aarav' });
  db.enrollments.put({ ...row(92005), studentId: sid(92003), batchId: sid(10), rollNumber: 11, joinedOn: date(1), leftOn: null, status: 'active' });
  [sid(14), sid(92003)].forEach((studentId, ci) => {
    db.parentLinks.put({ ...row(92006 + ci), studentId, guardianId: sid(92004), isPrimary: true });
    const batchId = sid(ci ? 10 : 9);
    const existingMonthSessions = new Set(db.attendanceSessions.all(inst).filter(s => s.date.startsWith(month)).map(s => s.id));
    for (const rec of db.attendanceRecords.all(inst, { studentId })) if (existingMonthSessions.has(rec.sessionId)) db.attendanceRecords.remove(inst, rec.id);
    for (let n = 0; n < 25; n++) {
      const sessionId = sid(93000 + ci * 100 + n);
      const day = Math.min(15, Math.floor(n / 2) + 1);
      db.attendanceSessions.put({ ...row(93000 + ci * 100 + n), batchId, subjectId: sid(44), teacherId: sid(3), date: date(day), period: n % 2 + 1, status: 'submitted', markedBy: sid(3), markedAt: at, notes: null });
      db.attendanceRecords.put({ ...row(93500 + ci * 100 + n), sessionId, batchId, studentId, status: n === 21 || n === 7 || (ci === 1 && n === 15) ? 'absent' : 'present', remark: null, markedBy: sid(3) });
    }
    // Five published, student-owned mark rows make the preview figures reproducible.
    for (const mark of db.marks.all(inst, { studentId })) db.marks.remove(inst, mark.id);
    const values = ci ? [68, 72, 70, 78, 82] : [65, 72, 82, 81, 90];
    values.forEach((value, n) => {
      const examId = sid(94000 + ci * 100 + n);
      db.exams.put({ ...D.exam(), ...row(94000 + ci * 100 + n), batchId, name: `Unit Test ${n + 1}`, startsOn: date([2, 5, 7, 10, 13][n]), status: 'published', subjectId: sid(44 + n % 3), publishedAt: at, totalMarks: 100 });
      db.marks.put({ ...row(94500 + ci * 100 + n), examId, batchId, studentId, subjectId: sid(44 + n % 3), marksObtained: value, maxMarks: 100, isAbsent: false, grade: null, remark: null, enteredBy: sid(3) });
    });
    const feeId = ci ? sid(92010) : sid(5000);
    if (ci) db.studentFees.put({ ...row(92010), studentId, feeStructureId: sid(51), grossAmount: 6799, netAmount: 6799, academicYear: '2026-27', discountAmount: 0, discountReason: null, discountIds: [], status: 'active' });
    const installmentId = ci ? sid(92011) : sid(6001);
    if (!ci) for (const p of db.payments.all(inst, { installmentId })) db.payments.remove(inst, p.id);
    db.installments.put({ ...row(ci ? 92011 : 6001), studentId, studentFeeId: feeId, termNo: 3, label: 'Term 3', amount: 4999, paidAmount: 0, dueDate: date(20), paidOn: null, status: 'upcoming' });
    // Aarav's settled terms, each backed by one completed payment and its receipt,
    // so the fees screen has a term breakdown and a real payment history to show.
    if (!ci) {
      const settled: { label: string; paidOn: string; method: 'upi' | 'cash'; ref: string; receipt: string }[] = [
        { label: 'Term 1', paidOn: addDays(today, -150), method: 'upi', ref: 'UPI-91001', receipt: 'SCB/26-27/9901' },
        { label: 'Term 2', paidOn: addDays(today, -60), method: 'cash', ref: '', receipt: 'SCB/26-27/9902' },
      ];
      settled.forEach((term, index) => {
        const installmentId = sid(96000 + index);
        for (const p of db.payments.all(inst, { installmentId })) db.payments.remove(inst, p.id);
        db.installments.put({ ...row(96000 + index), studentId, studentFeeId: feeId, termNo: index + 1, label: term.label, amount: 4999, paidAmount: 4999, dueDate: addDays(today, -210 + index * 90), paidOn: term.paidOn, status: 'paid' });
        db.payments.put({ ...row(96010 + index), studentId, studentFeeId: feeId, installmentId, amount: 4999, method: term.method, referenceNo: term.ref || null, paidAt: `${term.paidOn}T10:30:00.000Z`, status: 'completed', receivedBy: sid(2), notes: null });
        db.receipts.put({ ...row(96020 + index), paymentId: sid(96010 + index), studentId, receiptNo: term.receipt, amount: 4999, issuedAt: `${term.paidOn}T10:31:00.000Z`, issuedBy: sid(2), pdfPath: null });
      });
    }
    if (ci) db.installments.put({ ...row(92012), studentId, studentFeeId: feeId, termNo: 2, label: 'Term 2', amount: 1800, paidAmount: 0, dueDate: date(10), paidOn: null, status: 'overdue' });
    const assignmentId = sid(95000 + ci);
    db.assignments.put({ ...D.assignment(), ...row(95000 + ci), batchId, subjectId: sid(ci ? 45 : 44), title: ci ? 'Motion & forces worksheet' : 'Quadratic equations', instructions: ci ? 'Practice questions 1–10 on motion and forces. Bring your working to our next class.' : 'Complete exercises 4.1 and 4.2 on quadratic equations. Show each step of your working. Your teacher will share feedback in class.', status: 'published', dueAt: `${date(17)}T14:30:00Z` });
    db.submissions.put({ ...row(95100 + ci), assignmentId, studentId, batchId, content: 'Completed worksheet', status: 'submitted', submittedAt: `${date(15)}T09:30:00Z` });
    db.notices.put({ ...D.notice(), ...row(95200 + ci), batchId, title: ci ? 'Science exhibition this Friday' : 'Parent–teacher meet', body: ci ? 'Join us on Friday, 20 November, from 3:00 PM for our Class 9 science exhibition. Families are welcome to celebrate the children’s projects.' : 'Let’s talk about your child’s progress. Our next parent–teacher meeting is on Saturday, 21 November, from 10:00 AM to 12:00 PM at Sunrise Coaching. Please bring any questions you’d like to discuss. We look forward to seeing you.', audience: ['parent'], publishedAt: at, category: 'event' });
  });
  db.auditLogs.insert(inst, { ...D.auditLog(), action: 'preview.parent.seed.v2' });
}
