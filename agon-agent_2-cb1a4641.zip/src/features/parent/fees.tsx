import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { C } from '@/lib/theme';
import { formatParentDate } from '@/core/contracts/parent';
import type { ParentTerm } from '@/core/contracts/models/parent';
import type { Payment } from '@/core/contracts/models';
import { useParentPaymentIntent, useParentPayments } from '@/core/backend';
import { useParent } from './context';
import { ParentState } from './ParentHome';
import { ChildStrip } from './child-strip';
import { currency, Icon, Label, Panel, styles } from './ui';
const TAB_BAR_INSET = 136;
/** Shown verbatim until a gateway is connected — mirrors the backend's fail-closed rule. */
const OFFICE_MESSAGE = 'Online payment is not enabled yet — please pay at the office.';

function heroDate(term: ParentTerm | null): string {
  if (!term) return 'You are all settled for now';
  const date = new Date(`${term.dueDate.slice(0, 10)}T12:00:00Z`);
  const label = date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
  return `${term.label.replace(/ fee$/i, '')} · due ${label}`;
}

function Pill({ tone, label }: { tone: 'paid' | 'due' | 'partial'; label: string }) {
  const map = { paid: [C.tealSoft, C.teal], due: [C.dangerSoft, C.danger], partial: [C.dangerSoft, C.danger] } as const;
  const [bg, fg] = map[tone];
  return <View style={{ backgroundColor: bg, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999 }}>
    <Label size={11} weight="700" color={fg}>{label}</Label>
  </View>;
}

/** The fee summary hero: amount due, its term, and the one action that matters. */
function DueHero({ child, due, next, notice, paying, onPay }: {
  child: { name: string; photoUrl: string | null };
  due: number;
  next: ParentTerm | null;
  notice: string | null;
  paying: boolean;
  onPay: () => void;
}) {
  return <View style={{ backgroundColor: C.primary, borderRadius: 20, padding: 24, paddingTop: 26, paddingBottom: 24, overflow: 'hidden' }}>
    <View pointerEvents="none" style={{ position: 'absolute', right: 70, top: -91, width: 330, height: 330, borderWidth: 1, borderRadius: 200, borderColor: C.heroLine, opacity: 0.6 }} />
    <View pointerEvents="none" style={{ position: 'absolute', right: 28, top: -50, width: 330, height: 330, borderWidth: 1, borderRadius: 200, borderColor: C.heroLine, opacity: 0.6 }} />
    <Label size={12} color={C.navyPale} style={{ letterSpacing: 1.4 }}>AMOUNT DUE</Label>
    <Label size={44} weight="800" color={C.surface} style={{ letterSpacing: -1.2, lineHeight: 54, marginTop: 6 }}>{currency(due)}</Label>
    <Label size={13} color={C.navyPale} style={{ marginTop: 4 }}>{heroDate(due > 0 ? next : null)}</Label>
    {notice && <View style={{ flexDirection: 'row', gap: 8, marginTop: 14, backgroundColor: C.heroGlass, borderRadius: 12, padding: 12 }}>
      <Icon name="information-circle-outline" size={17} color={C.accent} />
      <Label size={12} color={C.navyPale} style={{ flex: 1, lineHeight: 19 }}>{notice}</Label>
    </View>}
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Pay now ${currency(due)}`}
      disabled={due <= 0 || paying}
      onPress={onPay}
      style={({ pressed }) => ({
        height: 44, marginTop: 18, borderRadius: 13, backgroundColor: C.accent,
        opacity: pressed || paying || due <= 0 ? 0.75 : 1,
        alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9,
      })}
    >
      <Label size={14} weight="700" color={C.surface}>{paying ? 'Opening payment…' : 'Pay now'}</Label>
      {!paying && <Icon name="arrow-forward" size={16} color={C.surface} />}
    </Pressable>
    <Label size={11} color={C.navyPale} style={{ marginTop: 12, textAlign: 'center' }}>
      Paid for {child.name.split(' ')[0]}’s fees at the office recently? It shows here once verified.
    </Label>
  </View>;
}

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return <View style={{ marginTop: 10 }}>
    <Label size={17} weight="700">{title}</Label>
    {subtitle && <Label size={12} color={C.muted} style={{ marginTop: 2 }}>{subtitle}</Label>}
  </View>;
}

function TermRow({ term, payment, onReceipt }: { term: ParentTerm; payment: Payment | null; onReceipt: () => void }) {
  const paid = term.remaining <= 0;
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 15, borderBottomWidth: 1, borderColor: C.hairline }}>
    <View style={{ flex: 1 }}>
      <Label size={14} weight="700">{term.label.replace(/ fee$/i, '')}</Label>
      <Label size={12} color={C.muted} style={{ marginTop: 2 }}>Due {formatParentDate(term.dueDate)}</Label>
    </View>
    {payment && (
      <Pressable accessibilityRole="button" accessibilityLabel={`Open receipt for ${term.label}`} onPress={onReceipt}
        style={({ pressed }) => ({ width: 34, height: 34, borderRadius: 11, backgroundColor: C.tealSoft, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
        <Icon name="receipt-outline" size={17} color={C.teal} />
      </Pressable>
    )}
    <View style={{ alignItems: 'flex-end', gap: 5 }}>
      <Label size={15} weight="800">{currency(term.remaining || term.amount)}</Label>
      <Pill tone={paid ? 'paid' : 'due'} label={paid ? 'Paid' : term.paidAmount > 0 ? `Due ${currency(term.remaining)}` : 'Due'} />
    </View>
  </View>;
}

function HistoryRow({ payment, onReceipt }: { payment: Payment; onReceipt: () => void }) {
  const method = { cash: 'Cash', upi: 'UPI', card: 'Card', bank_transfer: 'Bank transfer', cheque: 'Cheque', online: 'Online' }[payment.method];
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderColor: C.hairline }}>
    <View style={{ width: 36, height: 36, borderRadius: 11, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name={payment.method === 'cash' ? 'cash-outline' : payment.method === 'upi' ? 'phone-portrait-outline' : 'card-outline'} size={17} color={C.muted} />
    </View>
    <View style={{ flex: 1 }}>
      <Label size={13} weight="700">{formatParentDate(payment.paidAt.slice(0, 10))}</Label>
      <Label size={11} color={C.muted} style={{ marginTop: 1 }}>{method}{payment.referenceNo ? ` · ${payment.referenceNo}` : ''}</Label>
    </View>
    <Label size={14} weight="800" style={{ marginRight: 2 }}>{currency(payment.amount)}</Label>
    <Pressable accessibilityRole="button" accessibilityLabel={`Download receipt for ${formatParentDate(payment.paidAt.slice(0, 10))}`} onPress={onReceipt}
      style={({ pressed }) => ({ width: 34, height: 34, borderRadius: 11, backgroundColor: C.track, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
      <Icon name="download-outline" size={17} color={C.primary} />
    </Pressable>
  </View>;
}

export function ParentFeesScreen() {
  const p = useParent();
  const child = p.child;
  const contentStyle = useFeesStyle();
  const payments = useParentPayments(child?.id);
  const payNow = useParentPaymentIntent();
  const [notice, setNotice] = useState<string | null>(null);
  const history = useMemo(
    () => (payments.data?.items ?? []).filter((payment) => payment.status === 'completed'),
    [payments.data],
  );
  const receiptFor = (installmentId: string) => {
    const payment = history.find((row) => row.installmentId === installmentId) ?? history[0];
    if (payment) router.push(`/(parent)/receipt/${payment.id}` as never);
  };
  const pay = async () => {
    if (!child || !child.nextFee || payNow.loading) return;
    setNotice(null);
    const result = await payNow.mutate({
      studentId: child.id,
      installmentId: child.nextFee.id,
      amount: child.nextFee.remaining,
    });
    if (!result.ok) setNotice(result.error.message || OFFICE_MESSAGE);
  };
  if (!child) {
    return <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList data={[]} renderItem={() => null} contentContainerStyle={[styles.page, { paddingBottom: TAB_BAR_INSET }]}
        ListHeaderComponent={<><ChildStrip /><View style={{ marginTop: 18 }}><ParentState /></View></>} />
    </View>;
  }
  return <View style={{ flex: 1, backgroundColor: C.canvas }}>
    <FlatList
      data={history}
      keyExtractor={(payment) => payment.id}
      contentContainerStyle={[...contentStyle, { gap: 16 }]}
      refreshControl={<RefreshControl refreshing={(p.loading && !!p.summary) || payments.loading} onRefresh={() => { void p.refresh(); void payments.refetch(); }} tintColor={C.teal} />}
      ListHeaderComponent={<>
        <ChildStrip />
        <DueHero child={child} due={child.totalOutstanding} next={child.nextFee} notice={notice} paying={payNow.loading} onPay={() => void pay()} />
        <SectionTitle title="Term breakdown" subtitle="Every term of this year, and where each one stands." />
        {child.terms.length ? <Panel style={{ paddingTop: 6, paddingBottom: 6 }}>
          {child.terms.map((term) => (
            <TermRow key={term.id} term={term} payment={history.find((row) => row.installmentId === term.id) ?? null} onReceipt={() => receiptFor(term.id)} />
          ))}
        </Panel> : <Panel><Label color={C.muted} size={13}>No fees have been assigned yet.</Label></Panel>}
        <SectionTitle title="Payment history" subtitle="Receipts for every verified payment." />
      </>}
      renderItem={({ item }) => <HistoryRow payment={item} onReceipt={() => receiptFor(String(item.installmentId))} />}
      ListEmptyComponent={<Panel><View style={[styles.row, { gap: 8 }]}><Icon name="receipt-outline" size={18} color={C.muted} /><Label color={C.muted} size={13} style={{ flex: 1 }}>No payments yet. Receipts appear here the moment the office verifies one.</Label></View></Panel>}
      ListFooterComponent={<>
        <View style={{ backgroundColor: C.tealSoft, borderRadius: 18, padding: 20, flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 8 }}>
          <Icon name="shield-checkmark-outline" size={22} color={C.teal} />
          <View style={{ flex: 1 }}>
            <Label size={13} weight="700" color={C.teal}>Payments are verified by the institute. You will get a receipt instantly.</Label>
            <Label size={11} color={C.secondary} style={{ marginTop: 4 }}>Every entry above comes from the office’s own records.</Label>
          </View>
        </View>
        <View style={[styles.row, { alignSelf: 'center', gap: 6, paddingTop: 8 }]}>
          <Icon name="heart-outline" size={12} color={C.muted} />
          <Label size={10} color={C.muted}>Supporting their journey, together.</Label>
        </View>
      </>}
    />
  </View>;
}

function useFeesStyle() {
  const mobile = useWindowDimensions().width < 980;
  return [styles.page, mobile && { paddingHorizontal: 20, paddingTop: 12 }, { paddingBottom: TAB_BAR_INSET }];
}
