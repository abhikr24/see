import React, { useMemo, useState } from 'react';
import { FlatList, RefreshControl, View } from 'react-native';
import { Button, Card, Chip, DateField, EmptyState, ErrorState, Input, ListSkeleton, Text } from '@/components/ui';
import type { ID, LeaveType } from '@/core/contracts/models';
import { C, LAYOUT, R } from '@/lib/theme';
import { useMyLeaveRequests, useSubmitLeave } from '@/core/backend';
import { useDomainQuery } from '@/core/hooks/domain';
import { dateShort } from '@/lib/format';
import { ChildStrip } from './child-strip';
import { useParent } from './context';

const TAB_INSET = 136;
const TYPES: { key: LeaveType; label: string }[] = [
  { key: 'sick', label: 'Sick' },
  { key: 'casual', label: 'Casual' },
  { key: 'personal', label: 'Personal' },
];
const STATUS: Record<string, { label: string; fg: string; bg: string }> = {
  pending: { label: 'Pending', fg: C.duesInk, bg: C.warningSoft },
  approved: { label: 'Approved', fg: C.teal, bg: C.tealSoft },
  rejected: { label: 'Declined', fg: C.danger, bg: C.dangerSoft },
};

export function leaveDayCount(from: string, to: string): number {
  if (!from || !to || to < from) return 0;
  const start = new Date(`${from}T00:00:00Z`).getTime();
  const end = new Date(`${to}T00:00:00Z`).getTime();
  return Math.max(1, Math.round((end - start) / 86_400_000) + 1);
}

function addDays(date: string, count: number): string {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + count);
  return value.toISOString().slice(0, 10);
}

/** Parent leave for one child: type, dates, reason, the classes it touches, and its history. */
export function ParentLeaveScreen() {
  const p = useParent();
  const studentId: ID | null = p.child?.id ?? null;
  const [leaveType, setLeaveType] = useState<LeaveType>('sick');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [reason, setReason] = useState('');
  const submit = useSubmitLeave();

  const requests = useMyLeaveRequests();
  const history = useMemo(
    () => (requests.data ?? []).sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    [requests.data],
  );

  // The child's own classes, and how many periods the leave window touches.
  const affected = useDomainQuery<{ batchId: ID; batchName: string; count: number }[]>(
    'timetable',
    ['parent-leave-affected', studentId, from, to],
    async (backend, instituteId) => {
      if (!studentId || !from || !to || to < from) return [];
      const [batches] = await Promise.all([
        backend.batches.listMine(instituteId),
        backend.timetable.list(instituteId, { limit: 200 }),
      ]);
      const own = new Map(batches.map((batch) => [batch.id, batch]));
      const days = Math.min(31, leaveDayCount(from, to));
      const counts = new Map<ID, number>();
      for (let index = 0; index < days; index += 1) {
        const weekday = new Date(`${addDays(from, index)}T00:00:00Z`).getUTCDay();
        for (const period of await backend.timetable.listForDay(instituteId, { dayOfWeek: weekday })) {
          if (own.has(period.batchId)) counts.set(period.batchId, (counts.get(period.batchId) ?? 0) + 1);
        }
      }
      return [...counts.entries()]
        .map(([batchId, count]) => ({ batchId, batchName: own.get(batchId)?.name ?? 'Class', count }))
        .sort((a, b) => b.count - a.count);
    },
    Boolean(studentId && from && to && to >= from),
  );

  const days = leaveDayCount(from, to);
  const canSubmit = Boolean(studentId && from && to && to >= from && reason.trim().length >= 3);

  const onSubmit = async () => {
    if (!studentId) return;
    const result = await submit.mutate({ leaveType, fromDate: from, toDate: to, reason, studentId });
    if (result.ok) setReason('');
  };

  const refresh = () => Promise.all([requests.refetch(), p.refresh()]);

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        data={history}
        keyExtractor={(request) => request.id}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: TAB_INSET, gap: 14 }}
        refreshControl={<RefreshControl refreshing={requests.loading && Boolean(requests.data)} onRefresh={() => void refresh()} tintColor={C.primary} />}
        ListHeaderComponent={
          <View style={{ gap: 14, paddingBottom: 4 }}>
            <ChildStrip />
            <View>
              <Text variant="h1" weight={800}>Leave</Text>
              <Text variant="caption" c={C.secondary}>Tell the class teacher why {p.child?.name.split(' ')[0] ?? 'your child'} will be away.</Text>
            </View>
            <Card pad={16} style={{ gap: 16 }}>
              <View style={{ gap: 8 }}>
                <Text variant="title" weight={700}>Type of leave</Text>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  {TYPES.map((item) => (
                    <Chip key={item.key} label={item.label} active={leaveType === item.key} onPress={() => setLeaveType(item.key)} />
                  ))}
                </View>
              </View>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <DateField label="From" value={from} onChange={(_, iso) => setFrom(iso)} />
                </View>
                <View style={{ flex: 1 }}>
                  <DateField label="To" value={to} onChange={(_, iso) => setTo(iso)} minDate={from || undefined} />
                </View>
              </View>
              {days > 0 ? (
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Text variant="caption" c={C.secondary}>Total duration</Text>
                  <Text variant="title" weight={700} c={C.primary} tabular>{days} {days === 1 ? 'day' : 'days'}</Text>
                </View>
              ) : null}
              <Input label="Reason" value={reason} onChangeText={setReason} placeholder="e.g. Fever, doctor has advised rest" multiline numberOfLines={3} />
              <View style={{ gap: 8 }}>
                <Text variant="title" weight={700}>Affected classes</Text>
                {affected.loading ? <ListSkeleton rows={1} h={44} /> : null}
                {!affected.loading && affected.data?.length ? affected.data.map((row) => (
                  <View key={row.batchId} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 44 }}>
                    <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
                      <Text weight={700} c={C.primary} style={{ fontSize: 12 }}>{row.batchName.replace(/[^0-9A-Za-z]/g, '').slice(-2)}</Text>
                    </View>
                    <Text variant="body" weight={600} style={{ flex: 1 }}>{row.batchName}</Text>
                    <View style={{ backgroundColor: C.warningSoft, paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.chip }}>
                      <Text variant="label" weight={700} c={C.duesInk} tabular>{row.count} {row.count === 1 ? 'class' : 'classes'}</Text>
                    </View>
                  </View>
                )) : null}
                {!affected.loading && from && to && to >= from && !affected.data?.length ? (
                  <Text variant="caption" c={C.muted}>No timetabled classes fall inside these dates.</Text>
                ) : null}
                {!from || !to || to < from ? (
                  <Text variant="caption" c={C.muted}>Pick the dates to see which classes are affected.</Text>
                ) : null}
              </View>
              <Button title={submit.loading ? 'Sending…' : 'Submit request'} onPress={() => void onSubmit()} disabled={!canSubmit || submit.loading} loading={submit.loading} />
              <Text variant="caption" c={C.muted} style={{ textAlign: 'center' }}>
                The class teacher and the office both receive this request.
              </Text>
            </Card>
            <Text variant="title" weight={800}>Requests</Text>
            {requests.error ? <ErrorState message={requests.error.message} onRetry={() => void refresh()} /> : null}
            {requests.loading && !requests.data ? <ListSkeleton rows={2} h={64} /> : null}
          </View>
        }
        renderItem={({ item }) => {
          const status = STATUS[item.status] ?? STATUS.pending;
          return (
            <Card pad={16} style={{ gap: 6 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Text variant="body" weight={700}>{TYPES.find((t) => t.key === item.leaveType)?.label ?? item.leaveType} leave</Text>
                  <Text variant="caption" c={C.secondary}>{dateShort(item.fromDate)} → {dateShort(item.toDate)} · {leaveDayCount(item.fromDate, item.toDate)} {leaveDayCount(item.fromDate, item.toDate) === 1 ? 'day' : 'days'}</Text>
                </View>
                <View style={{ backgroundColor: status.bg, paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.chip }}>
                  <Text variant="label" weight={700} c={status.fg}>{status.label}</Text>
                </View>
              </View>
              <Text variant="caption" c={C.secondary}>{item.reason}</Text>
              {item.reviewNote ? <Text variant="caption" c={C.muted}>Note from the office: {item.reviewNote}</Text> : null}
            </Card>
          );
        }}
        ListEmptyComponent={!requests.loading && !requests.error ? (
          <EmptyState icon="calendar-outline" title="No requests yet" text="Submitted leave requests and the school’s replies will appear here." />
        ) : null}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
