import React, { useMemo, useState } from 'react';
import { FlatList, RefreshControl, View } from 'react-native';
import { Button, Card, Chip, DateField, EmptyState, ErrorState, Input, ListSkeleton, Text } from '@/components/ui';
import type { ID, MeetingStatus } from '@/core/contracts/models';
import { C, LAYOUT, R } from '@/lib/theme';
import { useMeetings, useStaff, useTeachers } from '@/core/backend';
import { useMyBatches } from '@/core/backend';
import { dateShort } from '@/lib/format';
import { ChildStrip } from './child-strip';
import { useParent } from './context';

const TAB_INSET = 136;
const STATUS: Record<MeetingStatus, { label: string; fg: string; bg: string }> = {
  pending: { label: 'Requested', fg: C.duesInk, bg: C.warningSoft },
  accepted: { label: 'Confirmed', fg: C.teal, bg: C.tealSoft },
  declined: { label: 'Declined', fg: C.danger, bg: C.dangerSoft },
  completed: { label: 'Completed', fg: C.secondary, bg: C.track },
  cancelled: { label: 'Cancelled', fg: C.secondary, bg: C.track },
};

/** Parent–teacher meetings: one request form and the thread of replies. */
export function ParentMeetingsScreen() {
  const p = useParent();
  const studentId: ID | null = p.child?.id ?? null;
  const [teacherId, setTeacherId] = useState<ID | null>(null);
  const [date, setDate] = useState('');
  const [note, setNote] = useState('');

  const batches = useMyBatches();
  const teachers = useTeachers({ limit: 50 });
  const staff = useStaff({ limit: 50 });
  const meetings = useMeetings();

  // The teachers who actually teach this child: class teachers of their batches.
  const options = useMemo(() => {
    const batchTeacherIds = new Set(
      batches.data
        ?.filter((batch) => p.child?.classLabel.includes(batch.name) || batches.data?.length === 1)
        .map((batch) => batch.teacherId)
        .filter((id): id is ID => Boolean(id)) ?? [],
    );
    const rows = (teachers.data?.items ?? []).filter((teacher) => batchTeacherIds.has(teacher.id));
    return (rows.length ? rows : teachers.data?.items ?? []).map((teacher) => ({
      id: teacher.id,
      name: teacher.fullName,
      detail: teacher.specialization ?? (staff.data?.items ?? []).find((row) => row.teacherId === teacher.id)?.designation ?? 'Class teacher',
    }));
  }, [batches.data, teachers.data, staff.data, p.child]);

  const history = useMemo(
    () => (meetings.data?.items ?? []).sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
    [meetings.data],
  );

  const selected = options.find((option) => option.id === teacherId) ?? null;
  const canSubmit = Boolean(studentId && teacherId && date && note.trim().length >= 3);

  const submit = async () => {
    if (!studentId || !teacherId) return;
    const result = await meetings.request({
      studentId,
      teacherId,
      reason: note.trim(),
      preferredAt: `${date}T09:00:00.000Z`,
      mode: 'in_person',
    });
    if (result.ok) {
      setNote('');
      setDate('');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        data={history}
        keyExtractor={(meeting) => meeting.id}
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: TAB_INSET, gap: 14 }}
        refreshControl={<RefreshControl refreshing={meetings.loading && Boolean(meetings.data)} onRefresh={() => void meetings.refetch()} tintColor={C.primary} />}
        ListHeaderComponent={
          <View style={{ gap: 14, paddingBottom: 4 }}>
            <ChildStrip />
            <View>
              <Text variant="h1" weight={800}>Meetings</Text>
              <Text variant="caption" c={C.secondary}>Ask for a time to talk, and see the teacher’s reply.</Text>
            </View>
            <Card pad={16} style={{ gap: 16 }}>
              <View style={{ gap: 8 }}>
                <Text variant="title" weight={700}>Request a meeting</Text>
                <Text variant="caption" c={C.secondary}>Pick a teacher</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {options.map((option) => (
                    <Chip key={option.id} label={option.name.split(' ')[0]} active={teacherId === option.id} onPress={() => setTeacherId(option.id)} />
                  ))}
                </View>
                {options.length === 0 && !teachers.loading ? (
                  <Text variant="caption" c={C.muted}>No teachers were found for {p.child?.name.split(' ')[0] ?? 'your child'}’s classes yet.</Text>
                ) : null}
              </View>
              <DateField label="Preferred date" value={date} onChange={(_, iso) => setDate(iso)} />
              <Input
                label="What would you like to talk about?"
                value={note}
                onChangeText={setNote}
                placeholder="A short note for the teacher"
                multiline
                numberOfLines={3}
              />
              <Button title={meetings.saving ? 'Sending…' : 'Send request'} onPress={() => void submit()} disabled={!canSubmit || meetings.saving} loading={meetings.saving} />
              {selected ? (
                <Text variant="caption" c={C.muted} style={{ textAlign: 'center' }}>
                  Goes to {selected.name} · the reply appears below.
                </Text>
              ) : null}
            </Card>
            <Text variant="title" weight={800}>Requests</Text>
            {meetings.error ? <ErrorState message={meetings.error.message} onRetry={() => void meetings.refetch()} /> : null}
            {meetings.loading && !meetings.data ? <ListSkeleton rows={2} h={64} /> : null}
          </View>
        }
        renderItem={({ item }) => {
          const status = STATUS[item.status];
          const teacher = (teachers.data?.items ?? []).find((row) => row.id === item.teacherId);
          return (
            <Card pad={16} style={{ gap: 6 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Text variant="body" weight={700}>{teacher?.fullName ?? 'Teacher'}</Text>
                  <Text variant="caption" c={C.secondary}>
                    Preferred {item.preferredAt ? dateShort(item.preferredAt.slice(0, 10)) : '—'}
                    {item.scheduledAt ? ` · Confirmed for ${dateShort(item.scheduledAt.slice(0, 10))}` : ''}
                  </Text>
                </View>
                <View style={{ backgroundColor: status.bg, paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.chip }}>
                  <Text variant="label" weight={700} c={status.fg}>{status.label}</Text>
                </View>
              </View>
              {item.reason ? <Text variant="caption" c={C.secondary}>{item.reason}</Text> : null}
              {item.responseNote ? (
                <View style={{ backgroundColor: C.canvas, borderRadius: 12, padding: 12, gap: 3 }}>
                  <Text variant="label" c={C.muted}>Reply from the teacher</Text>
                  <Text variant="caption" weight={600}>{item.responseNote}</Text>
                </View>
              ) : null}
            </Card>
          );
        }}
        ListEmptyComponent={!meetings.loading && !meetings.error ? (
          <EmptyState icon="chatbubbles-outline" title="No meeting requests yet" text="When you ask for a meeting, the teacher’s reply will show up here." />
        ) : null}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
