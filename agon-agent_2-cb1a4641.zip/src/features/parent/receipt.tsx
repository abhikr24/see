import React, { useState } from 'react';
import { Linking, Platform, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { ErrorState, ListSkeleton, Text } from '@/components/ui';
import { toast, useInstitute, useParentReceipt } from '@/core/backend';
import { C, FONT, R } from '@/lib/theme';
import { receiptHtml } from '@/features/fees/receipt-document';
import { useParent } from './context';
import { currency } from './ui';

const METHOD: Record<string, string> = {
  cash: 'Cash', upi: 'UPI', card: 'Card', bank_transfer: 'Bank transfer', cheque: 'Cheque', online: 'Online',
};

/** The parent's copy of a receipt: the payment, exactly as the office recorded it. */
export function ParentReceiptScreen() {
  const { id = '' } = useLocalSearchParams<{ id: string }>();
  const detail = useParentReceipt(id);
  const institute = useInstitute();
  const p = useParent();
  const [busy, setBusy] = useState(false);
  const payment = detail.data?.payment ?? null;
  const receipt = detail.data?.receipt ?? null;
  const term = p.child?.terms.find((t) => t.id === payment?.installmentId);

  const download = async () => {
    if (!payment || busy) return;
    setBusy(true);
    try {
      const html = receiptHtml({
        institute: {
          name: institute.data?.name ?? p.child?.instituteName ?? 'Institute',
          city: institute.data?.city ?? null,
          state: institute.data?.state ?? null,
        },
        receiptNo: receipt?.receiptNo ?? `PAY-${payment.id.slice(0, 8).toUpperCase()}`,
        amount: payment.amount,
        student: p.child?.name ?? 'Student',
        term: term?.label.replace(/ fee$/i, '') ?? 'Term fee',
        date: new Date(payment.paidAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        method: payment.method,
      });
      if (Platform.OS === 'web') await Print.printAsync({ html });
      else {
        const file = await Print.printToFileAsync({ html });
        await Sharing.shareAsync(file.uri, { mimeType: 'application/pdf', UTI: '.pdf' });
      }
    } catch {
      toast.error('Could not create PDF. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const share = async () => {
    if (!payment) return;
    const name = p.child?.name ?? 'My child';
    const message = `Payment received by ${institute.data?.name ?? p.child?.instituteName ?? 'the institute'}: ${currency(payment.amount)} for ${name} (${term?.label.replace(/ fee$/i, '') ?? 'fees'}). Receipt ${receipt?.receiptNo ?? ''}. Thank you!`;
    try {
      await Linking.openURL(`https://wa.me/?text=${encodeURIComponent(message)}`);
    } catch {
      toast.error('Could not open WhatsApp');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4 }}>
        <Pressable accessibilityRole="button" accessibilityLabel="Back to fees" onPress={() => (router.canGoBack() ? router.back() : router.replace('/(parent)/fees' as never))}
          style={({ pressed }) => ({ width: 38, height: 38, borderRadius: 19, backgroundColor: C.surface, borderWidth: 1, borderColor: C.hairline, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}>
          <Ionicons name="chevron-back" size={20} color={C.primary} />
        </Pressable>
        <Text variant="title" weight={700}>Receipt</Text>
      </View>
      {detail.loading && !payment ? <View style={{ padding: 20 }}><ListSkeleton rows={4} h={72} /></View> : null}
      {detail.error && !payment ? <View style={{ padding: 20 }}><ErrorState message={detail.error.message} onRetry={() => void detail.refetch()} /></View> : null}
      {payment ? (
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40, gap: 20 }} showsVerticalScrollIndicator={false}>
          <View style={{ alignItems: 'center', gap: 10, marginTop: 8 }}>
            <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: C.tealSoft, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="checkmark" size={36} color={C.teal} />
            </View>
            <Text variant="h2" weight={800}>Payment successful</Text>
            <Text variant="caption" c={C.secondary}>A receipt has been issued to you</Text>
          </View>
          <View style={{ backgroundColor: C.surface, borderWidth: 1.5, borderColor: C.cardDash, borderStyle: 'dashed', borderRadius: R.card, padding: 24, gap: 14 }}>
            <View style={{ alignItems: 'center', gap: 3 }}>
              <Text variant="title" weight={800} style={{ textAlign: 'center' }}>{institute.data?.name ?? p.child?.instituteName}</Text>
              <Text variant="label" c={C.muted} style={{ letterSpacing: 2 }}>RECEIPT</Text>
            </View>
            <Text tabular weight={800} style={{ fontSize: 34, lineHeight: 42, textAlign: 'center', color: C.primary }}>{currency(payment.amount)}</Text>
            {([
              ['Student', p.child?.name ?? '—'],
              ['Class', p.child?.classLabel ?? '—'],
              ['Term', term?.label.replace(/ fee$/i, '') ?? 'Term fee'],
              ['Receipt no', receipt?.receiptNo ?? '—'],
              ['Date', new Date(payment.paidAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })],
              ['Method', METHOD[payment.method] ?? payment.method],
              ...(payment.referenceNo ? [['Reference', payment.referenceNo]] : []),
            ] as const).map(([label, value]) => (
              <View key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderColor: C.hairline, paddingTop: 11 }}>
                <Text variant="caption" c={C.secondary}>{label}</Text>
                <Text variant="caption" weight={700} tabular>{value}</Text>
              </View>
            ))}
          </View>
          <View style={{ gap: 10 }}>
            <Pressable accessibilityRole="button" accessibilityLabel="Download PDF" onPress={() => void download()} disabled={busy}
              style={({ pressed }) => ({ height: 52, borderRadius: 14, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9, opacity: pressed || busy ? 0.75 : 1 })}>
              <Ionicons name="download-outline" size={19} color={C.surface} />
              <Text weight={700} c={C.surface}>{busy ? 'Creating PDF…' : 'Download PDF'}</Text>
            </Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel="Share on WhatsApp" onPress={() => void share()}
              style={({ pressed }) => ({ height: 52, borderRadius: 14, borderWidth: 1.5, borderColor: C.primary, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9, opacity: pressed ? 0.75 : 1 })}>
              <Ionicons name="logo-whatsapp" size={19} color={C.primary} />
              <Text weight={700} c={C.primary}>Share on WhatsApp</Text>
            </Pressable>
          </View>
          <Text variant="caption" c={C.muted} style={{ textAlign: 'center', fontFamily: FONT.body }}>
            This receipt was generated from the institute’s own payment records.
          </Text>
        </ScrollView>
      ) : null}
    </SafeAreaView>
  );
}
