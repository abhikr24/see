import type { FeeStructure, ID, NewEntity, Payment, Receipt } from '../../core/contracts/models';
import type { FeeRepo, PaymentPort, PaymentRepo, ReceiptRepo } from '../../core/contracts/ports';
import { emit, upsert, type Db } from './db';
import * as D from './defaults';
import { feePlanMethods } from './fee-plan';
import { isOverdue, remaining, withStatus } from './fee-status';
import { addDays, fail, merge, nowIso, round2, sum, todayIso } from './store';

const GAP_DAYS: Record<FeeStructure['frequency'], number> = {
  one_time: 0,
  monthly: 30,
  quarterly: 91,
  term: 120,
  yearly: 365,
};

export { isOverdue, remaining };

export function feeRepo(db: Db): FeeRepo {
  const saveStructure = upsert<FeeStructure, 'name' | 'academicYear' | 'totalAmount'>(db.feeStructures, D.feeStructure);
  return {
    listStructures: async (instituteId, query) => db.feeStructures.page(instituteId, query),
    saveStructure: async (instituteId, input) => {
      if (input.totalAmount < 0) fail('VALIDATION', 'Total amount cannot be negative');
      if (input.installmentCount !== undefined && input.installmentCount < 1) {
        fail('VALIDATION', 'A fee needs at least one installment');
      }
      return saveStructure(instituteId, input);
    },
    listStudentFees: async (instituteId, query) => db.studentFees.page(instituteId, query),
    assign: async (instituteId, input) => {
      const { studentId, feeStructureId, discountAmount = 0, discountReason = null } = input;
      db.students.get(instituteId, studentId);
      const structure = db.feeStructures.get(instituteId, feeStructureId);
      if (!structure.isActive) fail('VALIDATION', 'This fee structure is no longer in use');
      if (db.studentFees.find(instituteId, { studentId, feeStructureId })) {
        fail('CONFLICT', 'This student already has that fee');
      }
      if (discountAmount < 0 || discountAmount > structure.totalAmount) {
        fail('VALIDATION', 'Discount must be between 0 and the total fee');
      }
      const netAmount = round2(structure.totalAmount - discountAmount);
      const fee = db.studentFees.insert(instituteId, {
        studentId,
        feeStructureId,
        academicYear: structure.academicYear,
        grossAmount: structure.totalAmount,
        discountAmount,
        discountReason,
        discountIds: [],
        netAmount,
        status: 'active',
      });
      const count = structure.installmentCount;
      const share = Math.floor((netAmount / count) * 100) / 100;
      const firstDue = input.firstDueDate ?? todayIso();
      for (let term = 1; term <= count; term++) {
        db.installments.insert(instituteId, {
          studentFeeId: fee.id,
          studentId,
          termNo: term,
          label: count === 1 ? structure.name : `Installment ${term} of ${count}`,
          // The last installment absorbs the rounding so the parts always add up to the net fee.
          amount: term === count ? round2(netAmount - share * (count - 1)) : share,
          dueDate: addDays(firstDue, GAP_DAYS[structure.frequency] * (term - 1)),
          paidAmount: 0,
          paidOn: null,
          status: 'upcoming',
        });
      }
      return fee;
    },
    listInstallments: async (instituteId, { status, ...filter } = {}) =>
      db.installments
        .all(instituteId, filter)
        .map((x) => withStatus(x))
        .filter((x) => !status || x.status === status)
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate)),
    waiveInstallment: async (instituteId, installmentId) => {
      const installment = db.installments.get(instituteId, installmentId);
      if (installment.paidAmount > 0) fail('CONFLICT', 'Refund what was paid before waiving this installment');
      return db.installments.update(instituteId, installmentId, { status: 'waived' });
    },
    summary: async (instituteId) => {
      const live = db.installments.all(instituteId).filter((x) => x.status !== 'waived');
      const billed = round2(sum(live.map((x) => x.amount)));
      const collected = round2(sum(live.map((x) => x.paidAmount)));
      const overdue = live.filter((x) => isOverdue(x));
      return {
        billed,
        collected,
        outstanding: round2(billed - collected),
        overdue: round2(sum(overdue.map(remaining))),
        overdueInstallments: overdue.length,
      };
    },
    ...feePlanMethods(db),
  };
}

function issueReceipt(db: Db, instituteId: ID, payment: Payment): Receipt {
  const existing = db.receipts.find(instituteId, { paymentId: payment.id });
  if (existing) return existing;
  if (payment.status !== 'completed') fail('CONFLICT', 'A receipt can only be issued for a completed payment');
  const prefix = db.institutes.get(instituteId, instituteId).settings.receiptPrefix ?? 'RCPT';
  const serial = db.receipts.all(instituteId).length + 1;
  return db.receipts.insert(instituteId, {
    paymentId: payment.id,
    studentId: payment.studentId,
    receiptNo: `${prefix}-${String(serial).padStart(4, '0')}`,
    amount: payment.amount,
    issuedAt: nowIso(),
    issuedBy: db.session.userId,
    pdfPath: null,
  });
}

/** Adds (or, with a negative amount, takes back) money on an installment. */
function applyToInstallment(db: Db, instituteId: ID, installmentId: ID, amount: number) {
  const installment = db.installments.get(instituteId, installmentId);
  const paidAmount = round2(installment.paidAmount + amount);
  const settled = paidAmount >= installment.amount;
  const updated = db.installments.update(instituteId, installmentId, { paidAmount, paidOn: settled ? todayIso() : null });
  db.installments.update(instituteId, installmentId, { status: withStatus(updated).status });
  const siblings = db.installments.all(instituteId, { studentFeeId: installment.studentFeeId });
  const allSettled = siblings.every((x) => remaining(x) === 0);
  db.studentFees.update(instituteId, installment.studentFeeId, { status: allSettled ? 'settled' : 'active' });
}

type PaymentInput = NewEntity<Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'>;

function recordPayment(db: Db, instituteId: ID, input: PaymentInput): Payment {
  if (!(input.amount > 0)) fail('VALIDATION', 'Amount must be more than zero');
  const fee = db.studentFees.get(instituteId, input.studentFeeId);
  if (fee.studentId !== input.studentId) fail('VALIDATION', 'That fee belongs to a different student');
  if (input.installmentId) {
    const installment = db.installments.get(instituteId, input.installmentId);
    if (installment.studentFeeId !== fee.id) fail('VALIDATION', 'That installment belongs to a different fee');
    if (input.amount > remaining(installment)) fail('VALIDATION', 'Amount is more than what is due on this installment');
  }
  const payment = db.payments.insert(instituteId, merge({ ...D.payment(), receivedBy: db.session.userId }, input));
  if (payment.status === 'completed') {
    if (payment.installmentId) applyToInstallment(db, instituteId, payment.installmentId, payment.amount);
    issueReceipt(db, instituteId, payment);
  }
  emit(db, instituteId, 'payments', 'created', payment.id);
  return payment;
}

export function paymentRepo(db: Db): PaymentRepo {
  const refundedSoFar = (instituteId: ID, paymentId: ID) =>
    sum(db.refunds.all(instituteId, { paymentId }).filter((r) => r.status !== 'rejected').map((r) => r.amount));
  return {
    list: async (instituteId, query) => db.payments.page(instituteId, query),
    get: async (instituteId, id) => db.payments.get(instituteId, id),
    record: async (instituteId, input) => recordPayment(db, instituteId, input),
    listRefunds: async (instituteId, filter = {}) => db.refunds.all(instituteId, filter),
    requestRefund: async (instituteId, { paymentId, amount, reason = null }) => {
      const payment = db.payments.get(instituteId, paymentId);
      if (payment.status !== 'completed') fail('CONFLICT', 'Only a completed payment can be refunded');
      if (!(amount > 0) || amount > round2(payment.amount - refundedSoFar(instituteId, paymentId))) {
        fail('VALIDATION', 'Refund must be more than zero and no more than what was paid');
      }
      return db.refunds.insert(instituteId, {
        paymentId,
        studentId: payment.studentId,
        amount,
        reason,
        method: payment.method,
        referenceNo: null,
        status: 'requested',
        requestedBy: db.session.userId,
        approvedBy: null,
        processedAt: null,
      });
    },
    decideRefund: async (instituteId, refundId, status) => {
      const refund = db.refunds.get(instituteId, refundId);
      const allowed = refund.status === 'requested' ? status !== 'processed' : refund.status === 'approved' && status === 'processed';
      if (!allowed) fail('CONFLICT', `A ${refund.status} refund cannot be marked ${status}`);
      if (status !== 'processed') return db.refunds.update(instituteId, refundId, { status, approvedBy: db.session.userId });
      const payment = db.payments.get(instituteId, refund.paymentId);
      if (payment.installmentId) applyToInstallment(db, instituteId, payment.installmentId, -refund.amount);
      const processed = db.refunds.update(instituteId, refundId, { status, processedAt: nowIso() });
      const fullyRefunded = refundedSoFar(instituteId, payment.id) >= payment.amount;
      if (fullyRefunded) db.payments.update(instituteId, payment.id, { status: 'refunded' });
      return processed;
    },
  };
}

export function receiptRepo(db: Db): ReceiptRepo {
  return {
    list: async (instituteId, query) => db.receipts.page(instituteId, query),
    get: async (instituteId, id) => db.receipts.get(instituteId, id),
    getForPayment: async (instituteId, paymentId) => {
      db.payments.get(instituteId, paymentId);
      return db.receipts.find(instituteId, { paymentId }) ?? null;
    },
    issue: async (instituteId, paymentId) => issueReceipt(db, instituteId, db.payments.get(instituteId, paymentId)),
  };
}

/** A pretend gateway: orders are confirmed by whatever proof the caller passes. */
export function paymentGateway(db: Db): PaymentPort {
  return {
    listMethods: async (instituteId) => {
      db.institutes.get(instituteId, instituteId);
      return ['upi', 'card', 'online'];
    },
    createOrder: async (instituteId, { studentId, installmentId, amount }) => {
      const installment = db.installments.get(instituteId, installmentId);
      if (installment.studentId !== studentId) fail('VALIDATION', 'That installment belongs to a different student');
      if (!(amount > 0) || amount > remaining(installment)) fail('VALIDATION', 'Amount must be between 0 and what is due');
      const order = db.orders.insert(instituteId, {
        studentId,
        installmentId,
        amount,
        currency: db.institutes.get(instituteId, instituteId).settings.currency,
        provider: 'memory',
        providerOrderId: '',
        checkoutUrl: null,
        status: 'created',
        paymentId: null,
      });
      return db.orders.update(instituteId, order.id, { providerOrderId: `order_${order.id.slice(-6)}` });
    },
    getOrder: async (instituteId, orderId) => db.orders.get(instituteId, orderId),
    confirm: async (instituteId, orderId, proof) => {
      const order = db.orders.get(instituteId, orderId);
      if (order.status !== 'created') fail('CONFLICT', `This order is already ${order.status}`);
      if (!proof.providerPaymentId) fail('VALIDATION', 'Missing proof of payment');
      const payment = recordPayment(db, instituteId, {
        studentId: order.studentId,
        studentFeeId: db.installments.get(instituteId, order.installmentId).studentFeeId,
        installmentId: order.installmentId,
        amount: order.amount,
        method: 'online',
        referenceNo: proof.providerPaymentId,
      });
      db.orders.update(instituteId, orderId, { status: 'paid', paymentId: payment.id });
      return payment;
    },
  };
}
