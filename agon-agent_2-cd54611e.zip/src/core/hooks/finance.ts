import type {
  FeePlanView,
  FeeStatement,
  FeeStructure,
  ID,
  Installment,
  InstallmentStatus,
  Money,
  NewEntity,
  Payment,
  PaymentOrder,
  Receipt,
  Refund,
  SavePlanInput,
  SavePlanResult,
  StudentFee,
  Upsert,
} from '../contracts/models';
import type { AssignFeeInput } from '../contracts/ports';
import type { ListQuery } from '../contracts/query';
import { patchItem, useDomainMutation, useDomainQuery, useListEditor } from './domain';

/** Everything a payment touches: dues, receipts, dashboards and the student's risk picture. */
const MONEY_SCOPES = ['fees', 'payments', 'receipts', 'analytics', 'progress'];

/** FeeRepo · installments (optionally for one student or status) and assigning / waiving fees. */
export function useFees(filter: { studentId?: ID; studentFeeId?: ID; status?: InstallmentStatus } = {}) {
  const args = ['installments', filter];
  const installments = useDomainQuery('fees', args, (b, i) => b.fees.listInstallments(i, filter));
  const edit = useListEditor<Installment>('fees', args);

  const assign = useDomainMutation<AssignFeeInput, StudentFee>(
    MONEY_SCOPES,
    (b, i, input) => b.fees.assign(i, input),
    { success: 'Fee assigned', failure: 'Could not assign the fee' },
  );
  const waive = useDomainMutation<ID, Installment>(
    MONEY_SCOPES,
    (b, i, installmentId) => b.fees.waiveInstallment(i, installmentId),
    { success: 'Installment waived', failure: 'Could not waive the installment' },
    (installmentId) => edit(patchItem<Installment>(installmentId, { status: 'waived' })),
  );
  return { ...installments, assign: assign.mutate, waive: waive.mutate, saving: assign.loading || waive.loading };
}

/** FeeRepo · fee plans. */
export function useFeeStructures(query?: ListQuery<FeeStructure>) {
  const structures = useDomainQuery('fees', ['structures', query ?? null], (b, i) => b.fees.listStructures(i, query));
  const save = useDomainMutation<Upsert<FeeStructure, 'name' | 'academicYear' | 'totalAmount'>, FeeStructure>(
    'fees',
    (b, i, input) => b.fees.saveStructure(i, input),
    { success: 'Fee structure saved', failure: 'Could not save the fee structure' },
  );
  return { ...structures, save: save.mutate, saving: save.loading };
}

/** FeeRepo · billed / collected / outstanding / overdue for the institute. */
export function useFeeSummary() {
  return useDomainQuery('fees', ['summary'], (b, i) => b.fees.summary(i));
}

/** PaymentRepo · money received at the desk, and refunds. */
export function usePayments(query?: ListQuery<Payment>) {
  const payments = useDomainQuery('payments', ['list', query ?? null], (b, i) => b.payments.list(i, query));
  const record = useDomainMutation<NewEntity<Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'>, Payment>(
    MONEY_SCOPES,
    (b, i, input) => b.payments.record(i, input),
    { success: 'Payment recorded', failure: 'Could not record the payment' },
  );
  const requestRefund = useDomainMutation<{ paymentId: ID; amount: Money; reason?: string | null }, Refund>(
    MONEY_SCOPES,
    (b, i, input) => b.payments.requestRefund(i, input),
    { success: 'Refund requested', failure: 'Could not request the refund' },
  );
  const decideRefund = useDomainMutation<{ refundId: ID; status: 'approved' | 'rejected' | 'processed' }, Refund>(
    MONEY_SCOPES,
    (b, i, { refundId, status }) => b.payments.decideRefund(i, refundId, status),
    { success: (refund) => `Refund ${refund.status}`, failure: 'Could not update the refund' },
  );
  return {
    ...payments,
    record: record.mutate,
    requestRefund: requestRefund.mutate,
    decideRefund: decideRefund.mutate,
    saving: record.loading || requestRefund.loading || decideRefund.loading,
  };
}

/** ReceiptRepo */
export function useReceipts(query?: ListQuery<Receipt>) {
  const receipts = useDomainQuery('receipts', ['list', query ?? null], (b, i) => b.receipts.list(i, query));
  const issue = useDomainMutation<ID, Receipt>(
    'receipts',
    (b, i, paymentId) => b.receipts.issue(i, paymentId),
    { success: (receipt) => `Receipt ${receipt.receiptNo} issued`, failure: 'Could not issue the receipt' },
  );
  return { ...receipts, issue: issue.mutate, saving: issue.loading };
}

/** PaymentPort · online checkout. `data` is the list of online methods; empty means online payment is off. */
export function useCheckout() {
  const methods = useDomainQuery('checkout', ['methods'], (b, i) => b.paymentGateway.listMethods(i));
  const createOrder = useDomainMutation<{ studentId: ID; installmentId: ID; amount: Money }, PaymentOrder>(
    'checkout',
    (b, i, input) => b.paymentGateway.createOrder(i, input),
    { failure: 'Could not start the payment' },
  );
  const confirm = useDomainMutation<{ orderId: ID; providerPaymentId: string; signature?: string }, Payment>(
    [...MONEY_SCOPES, 'checkout'],
    (b, i, { orderId, ...proof }) => b.paymentGateway.confirm(i, orderId, proof),
    { success: 'Payment received', failure: 'Could not confirm the payment' },
  );
  return {
    ...methods,
    createOrder: createOrder.mutate,
    confirm: confirm.mutate,
    paying: createOrder.loading || confirm.loading,
  };
}

/** Caches a fee-plan change makes stale: dues everywhere, batch cards and the student roster too. */
const PLAN_SCOPES = [...MONEY_SCOPES, 'batches', 'students'];

/** FeeRepo · the plan screen's one read for a batch. */
export function useFeePlan(batchId: ID) {
  return useDomainQuery<FeePlanView>('fees', ['plan', batchId], (b, i) => b.fees.getPlan(i, batchId));
}

/** FeeRepo · save a batch plan. Creates a new version when payments exist. */
export function useSaveFeePlan() {
  const save = useDomainMutation<SavePlanInput, SavePlanResult>(
    PLAN_SCOPES,
    (b, i, input) => b.fees.savePlan(i, input),
    {
      success: (r) =>
        r.versioned
          ? `Version ${r.structure.version} saved. ${r.studentsKept} student${r.studentsKept === 1 ? '' : 's'} who already paid keep their fee`
          : r.studentsKept > 0
            ? `Fee plan saved. ${r.studentsKept} student${r.studentsKept === 1 ? '' : 's'} who already paid keep their current fee`
            : 'Fee plan saved',
      failure: 'Could not save the fee plan',
    },
  );
  return { save: save.mutate, saving: save.loading };
}

/** FeeRepo · one student's scholarship (the override stored on their own fee). */
export function useApplyDiscounts() {
  const apply = useDomainMutation<{ studentId: ID; discountIds: string[] }, StudentFee>(
    PLAN_SCOPES,
    (b, i, input) => b.fees.applyStudentDiscounts(i, input),
    { success: 'Scholarship updated', failure: 'Could not update the scholarship' },
  );
  return { apply: apply.mutate, applying: apply.loading };
}

/** FeeRepo · what one student owes: total, scholarship, paid, due. */
export function useFeeStatement(studentId: ID | null, enabled = true) {
  return useDomainQuery<FeeStatement | null>(
    'fees',
    ['statement', studentId],
    (b, i) => b.fees.studentStatement(i, studentId as ID),
    enabled && studentId !== null,
  );
}
