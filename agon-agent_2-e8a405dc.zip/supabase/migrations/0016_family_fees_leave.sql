-- P28 · Parent fees, receipts, leave and meetings.
-- Online payment attempts (one pending row per installment), student leave requests, and
-- family-scoped row access. Every parent path resolves the caller's linked children here,
-- never from the client.

-- ---------------------------------------------------------------------------
-- The caller's linked children. Active parent membership → guardian → parent_links.
-- ---------------------------------------------------------------------------
create or replace function public.my_child_ids()
returns setof uuid language sql stable security definer set search_path = '' as $$
  select pl.student_id
  from public.parent_links pl
  join public.guardians g on g.institute_id = pl.institute_id and g.id = pl.guardian_id
  join public.memberships m on m.institute_id = g.institute_id and m.id = g.membership_id
  where m.user_id = auth.uid() and m.role = 'parent' and m.status = 'active';
$$;

revoke all on function public.my_child_ids() from public;
grant execute on function public.my_child_ids() to authenticated;

-- ---------------------------------------------------------------------------
-- Online payment attempts. A row is 'pending' until a gateway confirms or fails it.
-- The partial unique index is what stops a retry from creating a second pending row.
-- ---------------------------------------------------------------------------
create table public.fee_payments (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  student_id        uuid not null,
  installment_id    uuid not null,
  amount            numeric(12, 2) not null check (amount > 0),
  provider          text not null,
  provider_order_id text not null default '',
  status            text not null default 'pending' check (status in ('pending', 'completed', 'failed')),
  payment_id        uuid,
  failure_reason    text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, installment_id, student_id)
    references public.installments (institute_id, id, student_id) on delete cascade
);

create unique index fee_payments_one_pending
  on public.fee_payments (institute_id, installment_id) where status = 'pending';

alter table public.fee_payments enable row level security;

create policy fee_payments_family_read on public.fee_payments for select to authenticated
  using (student_id in (select public.my_child_ids()));

create policy fee_payments_staff_read on public.fee_payments for select to authenticated
  using (exists (
    select 1 from public.memberships m
    where m.institute_id = fee_payments.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin') and m.status = 'active'
  ));

-- Creates the pending attempt, or returns the one that already exists. Only a linked parent can call it.
create or replace function public.ensure_pending_fee_payment(
  p_institute uuid, p_student uuid, p_installment uuid, p_amount numeric, p_provider text, p_order text
) returns public.fee_payments language plpgsql security definer set search_path = '' as $$
declare v_row public.fee_payments;
begin
  if p_student not in (select public.my_child_ids()) then
    raise exception 'Fee not found' using errcode = 'P0002';
  end if;
  insert into public.fee_payments (institute_id, student_id, installment_id, amount, provider, provider_order_id, status)
  values (p_institute, p_student, p_installment, p_amount, p_provider, p_order, 'pending')
  on conflict do nothing;
  select * into v_row from public.fee_payments
  where institute_id = p_institute and installment_id = p_installment and status = 'pending';
  return v_row;
end $$;

revoke all on function public.ensure_pending_fee_payment(uuid, uuid, uuid, numeric, text, text) from public;
grant execute on function public.ensure_pending_fee_payment(uuid, uuid, uuid, numeric, text, text) to authenticated;

-- ---------------------------------------------------------------------------
-- Leave requests for a student, from a parent. Reach the affected teachers and the owner.
-- ---------------------------------------------------------------------------
create table public.student_leave_requests (
  id                   uuid primary key default gen_random_uuid(),
  institute_id         uuid not null references public.institutes (id) on delete cascade,
  student_id           uuid not null,
  requested_by         uuid not null references public.users (id) on delete cascade,
  leave_type           text not null check (leave_type in ('sick', 'family', 'personal', 'other')),
  from_date            date not null,
  to_date              date not null,
  days                 integer not null check (days >= 1),
  reason               text not null check (char_length(reason) between 3 and 300),
  affected_batch_ids   uuid[] not null default '{}',
  affected_class_count integer not null default 0 check (affected_class_count >= 0),
  status               text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'cancelled')),
  review_note          text,
  reviewed_by          uuid references public.users (id) on delete set null,
  reviewed_at          timestamptz,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  unique (institute_id, id),
  check (to_date >= from_date),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade
);

create index student_leave_requests_student_idx on public.student_leave_requests (student_id);

alter table public.student_leave_requests enable row level security;

create policy student_leave_family_read on public.student_leave_requests for select to authenticated
  using (student_id in (select public.my_child_ids()));

create policy student_leave_family_insert on public.student_leave_requests for insert to authenticated
  with check (student_id in (select public.my_child_ids()) and requested_by = auth.uid() and status = 'pending');

create policy student_leave_teacher_read on public.student_leave_requests for select to authenticated
  using (affected_batch_ids && public.my_batch_ids());

create policy student_leave_staff_all on public.student_leave_requests for all to authenticated
  using (exists (
    select 1 from public.memberships m
    where m.institute_id = student_leave_requests.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin') and m.status = 'active'
  ))
  with check (exists (
    select 1 from public.memberships m
    where m.institute_id = student_leave_requests.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin') and m.status = 'active'
  ));
