-- P29 · Progress alerts: the intervention log.
-- What was tried for a student (a call home, an extra class, counselling), who
-- did it, when, and — once known — a three-way outcome. Alerts themselves stay
-- computed on read with no table; this is the only progress table.
-- my_child_ids() comes from 0016.

create table public.interventions (
  id              uuid primary key default gen_random_uuid(),
  institute_id    uuid not null references public.institutes (id) on delete cascade,
  student_id      uuid not null,
  batch_id        uuid,
  alert_id        uuid,
  kind            text not null check (kind in ('call_parent', 'extra_class', 'counselling', 'other')),
  note            text,
  done_by         text not null check (char_length(done_by) between 1 and 120),
  done_on         date not null check (done_on <= current_date),
  outcome         text check (outcome in ('improved', 'unchanged', 'escalated')),
  closed_at       timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (institute_id, id),
  check ((outcome is null and closed_at is null) or (outcome is not null and closed_at is not null))
);

create index interventions_institute_student on public.interventions (institute_id, student_id, done_on desc);

alter table public.interventions enable row level security;

-- Teaching staff see and write every intervention in their institute.
create policy interventions_staff_read on public.interventions for select to authenticated
  using (exists (
    select 1 from public.memberships m
    where m.institute_id = interventions.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin', 'teacher') and m.status = 'active'
  ));

create policy interventions_staff_write on public.interventions for insert to authenticated
  with check (exists (
    select 1 from public.memberships m
    where m.institute_id = interventions.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin', 'teacher') and m.status = 'active'
  ));

create policy interventions_staff_update on public.interventions for update to authenticated
  using (exists (
    select 1 from public.memberships m
    where m.institute_id = interventions.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin', 'teacher') and m.status = 'active'
  ))
  with check (exists (
    select 1 from public.memberships m
    where m.institute_id = interventions.institute_id and m.user_id = auth.uid()
      and m.role in ('owner', 'admin', 'teacher') and m.status = 'active'
  ));

-- A parent sees only their own children's log.
create policy interventions_family_read on public.interventions for select to authenticated
  using (student_id in (select public.my_child_ids()));
