import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';

import { Card, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';
import { HomePlaceholder } from '@/features/shell/HomePlaceholder';
import { useApprovals } from '@/features/approvals/hooks/useApprovals';

export default function OwnerHomeRoute() {
  const { count } = useApprovals();

  return (
    <HomePlaceholder
      prompt="PROMPT P9"
      title="Built in Prompt P9 (Owner dashboard)"
      description="Enrolment, attendance and collection KPIs, plus shortcuts to every owner tool, will replace this card."
      extra={
        <Card
          onPress={() => router.push('/(owner)/approvals' as never)}
          style={{ marginTop: S.md, flexDirection: 'row', alignItems: 'center', gap: 12 }}
        >
          <View style={{ flex: 1, gap: 2 }}>
            <Text variant="label" c={C.secondary}>
              Join requests
            </Text>
            <Text variant="title">
              {count === 0 ? 'No pending requests' : `${count} pending ${count === 1 ? 'request' : 'requests'}`}
            </Text>
          </View>
          <Text variant="body" c={C.primary} weight={700}>
            Review →
          </Text>
        </Card>
      }
    />
  );
}
