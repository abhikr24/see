/**
 * The whole app's session, in one place.
 *
 * Every screen that needs "who is signed in / which institute / which role"
 * reads `useSessionStore()` instead of touching AuthPort, InstituteRepo or
 * MembershipRepo directly. It is built only on top of the existing hooks in
 * `src/core/backend.tsx` (never on a backend SDK), so it obeys the same
 * tenancy rule as every other screen: a user is not tied to one institute,
 * and switching institute never remounts the app.
 */
import { useCallback, useEffect, useMemo } from 'react';

import type { ID, Institute, Membership, Profile, Role } from '@/core/contracts/models';
import { useBackend, useMyInstitutes, useSession } from '@/core/backend';
import { queryKey } from '@/core/hooks/cache';
import { useQuery } from '@/core/hooks/useQuery';

export type RoleGroup = '/(owner)' | '/(teacher)' | '/(student)' | '/(parent)';

/** owner and admin share one shell; the other three roles each get their own. */
export function groupForRole(role: Role): RoleGroup {
  if (role === 'teacher') return '/(teacher)';
  if (role === 'student') return '/(student)';
  if (role === 'parent') return '/(parent)';
  return '/(owner)';
}

export interface InstituteMembership {
  institute: Institute;
  membership: Membership;
}

export type SessionStatus =
  /** Session + memberships are still loading for the first time. */
  | 'loading'
  /** No one is signed in. */
  | 'signed-out'
  /** Signed in, but every membership the person holds is awaiting approval. */
  | 'pending'
  /** Signed in, the institute they tried turned them down and they hold no other. */
  | 'rejected'
  /** Signed in, but has never requested to join or create an institute. */
  | 'no-membership'
  /** Signed in with at least one active membership — the normal case. */
  | 'ready';

export interface SessionStore {
  status: SessionStatus;
  loading: boolean;
  user: Profile | null;
  /** The role the active institute knows this person as. null until `status` is `ready`. */
  role: Role | null;
  group: RoleGroup | null;
  activeInstituteId: ID | null;
  /** Every institute this person can open right now, for the switcher. */
  institutes: InstituteMembership[];
  /** Moves the whole app to a different institute. Callers also navigate to `groupForRole`. */
  switchInstitute: (instituteId: ID) => void;
}

/** Where a signed-in-but-unresolved person should land. Shared by the resolver and every guard. */
export function destinationFor(status: SessionStatus, group: RoleGroup | null): string {
  switch (status) {
    case 'loading':
      return '';
    case 'signed-out':
      return '/(auth)/splash';
    case 'pending':
      return '/(pending)';
    case 'rejected':
    case 'no-membership':
      return '/(auth)/role';
    case 'ready':
      return group ?? '/(owner)';
  }
}

export function useSessionStore(): SessionStore {
  const { backend, instituteId, setInstituteId } = useBackend();
  const session = useSession();
  const myInstitutes = useMyInstitutes();

  const activeInstitutes = useMemo(() => myInstitutes.data ?? [], [myInstitutes.data]);
  const instituteIds = useMemo(() => activeInstitutes.map((i) => i.id).sort(), [activeInstitutes]);

  // One membership lookup per institute the person is active in, so the
  // switcher can show each one's role without guessing.
  const membershipsKey =
    session.data && instituteIds.length ? queryKey(backend.name, 'my-memberships', null, instituteIds) : null;
  const memberships = useQuery<Membership[]>(membershipsKey, async () => {
    const found = await Promise.all(instituteIds.map((id) => backend.memberships.getMine(id)));
    return found.filter((m): m is Membership => m !== null && m.status === 'active');
  });

  const institutes: InstituteMembership[] = useMemo(() => {
    const byId = new Map(activeInstitutes.map((institute) => [institute.id, institute]));
    return (memberships.data ?? [])
      .map((membership) => {
        const institute = byId.get(membership.instituteId);
        return institute ? { institute, membership } : null;
      })
      .filter((row): row is InstituteMembership => row !== null);
  }, [activeInstitutes, memberships.data]);

  const loading = session.loading || myInstitutes.loading || (membershipsKey !== null && memberships.loading);

  // If the institute currently open is not one the person is active in
  // (first launch, stale pick, got removed), hop to one that is — quietly,
  // no remount, no flash.
  useEffect(() => {
    if (loading || institutes.length === 0) return;
    if (!institutes.some((row) => row.institute.id === instituteId)) {
      setInstituteId(institutes[0].institute.id);
    }
  }, [loading, institutes, instituteId, setInstituteId]);

  const activeRow = institutes.find((row) => row.institute.id === instituteId) ?? institutes[0] ?? null;
  const role = activeRow?.membership.role ?? null;
  const group = role ? groupForRole(role) : null;

  let status: SessionStatus;
  if (!session.data) {
    status = loading ? 'loading' : 'signed-out';
  } else if (institutes.length > 0) {
    status = 'ready';
  } else if (loading) {
    status = 'loading';
  } else {
    const current = session.data.membership;
    status = current?.status === 'pending' ? 'pending' : current?.status === 'rejected' ? 'rejected' : 'no-membership';
  }

  const switchInstitute = useCallback((id: ID) => setInstituteId(id), [setInstituteId]);

  return {
    status,
    loading,
    user: session.data?.profile ?? null,
    role,
    group,
    activeInstituteId: instituteId,
    institutes,
    switchInstitute,
  };
}

export interface RouteResolution {
  status: SessionStatus;
  group: RoleGroup | null;
  /** Where to go. Empty while `status` is `loading` — render a loading state instead of redirecting. */
  destination: string;
}

/**
 * The single rule every guard shares: no session → (auth); every membership
 * pending → (pending); otherwise the group of the active membership's role.
 * Used by `app/index.tsx` and by each role layout to bounce a visitor who
 * lands on a group that is not theirs.
 */
export function useRouteResolution(): RouteResolution {
  const { status, group } = useSessionStore();
  return { status, group, destination: destinationFor(status, group) };
}
