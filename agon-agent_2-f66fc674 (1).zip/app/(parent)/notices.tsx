export { ParentNotices as default } from '@/features/parent/details';
