# Architecture

## The one rule

The UI never knows what database exists.

```
app/ + src/features/          ← screens. Call hooks & UI primitives. No SDK imports. Ever.
        │
        ▼
src/core/backend.tsx          ← useStudents(), useAttendance(), useFees(), …
        │
        ▼
src/core/contracts/ports.ts   ← 34 interfaces. The only vocabulary the app speaks.
        │
        ▼
src/adapters/supabase/        ← the only code that knows Postgres exists
src/backends/memory/          ← reference in-memory adapter for offline & contract checks
        │
        ▼
src/backends/index.ts         ← registers live & reference adapters
```

## Design system (`src/components/ui/` + `src/lib/theme.ts`)

Every visual primitive lives under `src/components/ui/` and reads tokens exclusively from `src/lib/theme.ts`:
- Zero hardcoded hex literals outside `src/lib/theme.ts`.
- Every component accepts a `className` passthrough for NativeWind composition.
- Charts are built on `react-native-gifted-charts` (flat, no gridlines, saffron spotlight).
- Sheets are built on `@gorhom/bottom-sheet`.
- The interactive QA gallery at `/dev/components` renders all 35 primitives across every variant and state.

## Teacher scoping

A teacher sees only the batches they are the assigned teacher of (`batches.teacherId`). The rule is enforced inside the adapters, never in a screen:
- memory: `src/backends/memory/teacher-scope.ts` (`teacherBatchScope`, `visibleBatch`);
- Supabase: `src/adapters/supabase/teacher-scope.ts` (`scopedBatchRepo`, `scopedAttendanceRepo`).

Another teacher's batch id returns `NOT_FOUND`, the same as an id that does not exist. The teacher home, My Classes and student-alert figures are computed once, in `src/core/contracts/teacher.ts`.

## Parent snapshot and family scoping

`AnalyticsRepo.childSummary(instituteId)` returns one `ParentSummary` containing only children linked to the authenticated parent. Both adapters resolve active parent memberships, their guardian IDs and institute-scoped `parent_links` before querying student data. The Supabase path fails closed and has no reference-backend fallback. `src/core/contracts/parent.ts` is the shared, pure calculation module.

`useParentSummary` keys the cache by backend, institute and signed-in user. `ParentProvider` keeps only the selected child ID, never independent attendance/marks/dues state. Switching uses one already-loaded child object so the header, all cards, chart, updates, switcher and checkout target change together. Losing a link removes the child from the next snapshot; an invalid selected ID falls back only to another authorized child.

The parent checkout uses `PaymentPort` in the explicitly labelled reference demo. It validates the owned child and current remaining balance, then invalidates analytics/fees/payments/receipts after confirmation. It never claims a real payment occurred. Live checkout fails closed until a real provider is connected. The parent preview is enabled only by both `EXPO_PUBLIC_PARENT_PREVIEW=true` and `EXPO_PUBLIC_BACKEND=memory`.

The compact parent trend follows the existing student results SVG approach. Parent modals use Gorhom sheets on native and accessible, responsive dialogs on web; all colors continue to come from theme tokens.
