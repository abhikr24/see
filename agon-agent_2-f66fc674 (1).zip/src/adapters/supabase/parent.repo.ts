import type { ID } from '../../core/contracts/models';
import type { ParentSummary } from '../../core/contracts/models/parent';
import { BackendError } from '../../core/contracts/errors';
import { buildChildSummary } from '../../core/contracts/parent';
import { handleSupabaseError, supabase } from './client';
import { mapAssignment, mapAttendanceRecord, mapAttendanceSession, mapBatch, mapExam, mapInstallment, mapMark, mapNotice, mapStudent, mapSubject, mapSubmission } from './mappers';

/** Never falls back to another identity or to demo data after a live error. */
export async function childSummary(instituteId: ID): Promise<ParentSummary> {
  const { data: auth, error: authError } = await supabase.auth.getUser();
  if (authError) throw handleSupabaseError(authError);
  if (!auth.user) throw new BackendError('UNAUTHENTICATED', 'Sign in to see your children');
  const userId = auth.user.id;
  const { data: memberships, error: mError } = await supabase.from('memberships').select('id').eq('institute_id', instituteId).eq('user_id', userId).eq('role', 'parent').eq('status', 'active');
  if (mError) throw handleSupabaseError(mError);
  if (!memberships?.length) throw new BackendError('FORBIDDEN', 'An active parent membership is required');
  const { data: guardians, error: gError } = await supabase.from('guardians').select('id').eq('institute_id', instituteId).in('membership_id', memberships.map(m => String(m.id)));
  if (gError) throw handleSupabaseError(gError);
  const [{ data: profile, error: pError }, { data: institute, error: iError }] = await Promise.all([
    supabase.from('profiles').select('full_name, avatar_url').eq('user_id', userId).single(),
    supabase.from('institutes').select('name').eq('id', instituteId).single(),
  ]);
  if (pError || iError) throw handleSupabaseError(pError ?? iError);
  const today = new Date().toISOString().slice(0, 10);
  const result: ParentSummary = { parentName: String(profile.full_name), parentPhotoUrl: profile.avatar_url ? String(profile.avatar_url) : null, month: new Date().toLocaleDateString('en-IN', { month: 'long', year: 'numeric', timeZone: 'UTC' }), asOf: today, children: [] };
  if (!guardians?.length) return result;
  const { data: links, error: lError } = await supabase.from('parent_links').select('student_id').eq('institute_id', instituteId).in('guardian_id', guardians.map(g => String(g.id)));
  if (lError) throw handleSupabaseError(lError);
  const ids = [...new Set((links ?? []).map(link => String(link.student_id)))];
  if (!ids.length) return result;
  const { data: enrollments, error: eError } = await supabase.from('batch_students').select('student_id, batch_id').eq('institute_id', instituteId).in('student_id', ids).eq('status', 'active');
  if (eError) throw handleSupabaseError(eError);
  const batchIds = [...new Set((enrollments ?? []).map(e => String(e.batch_id)))];
  const empty = Promise.resolve({ data: [], error: null });
  const queries = await Promise.all([
    supabase.from('student_profiles').select('*').eq('institute_id', instituteId).in('id', ids),
    batchIds.length ? supabase.from('batches').select('*').eq('institute_id', instituteId).in('id', batchIds) : empty,
    supabase.from('attendance_records').select('*').eq('institute_id', instituteId).in('student_id', ids),
    batchIds.length ? supabase.from('attendance_sessions').select('*').eq('institute_id', instituteId).in('batch_id', batchIds) : empty,
    batchIds.length ? supabase.from('exams').select('*').eq('institute_id', instituteId).in('batch_id', batchIds).eq('status', 'published') : empty,
    supabase.from('marks').select('*').eq('institute_id', instituteId).in('student_id', ids),
    supabase.from('installments').select('*').eq('institute_id', instituteId).in('student_id', ids),
    batchIds.length ? supabase.from('assignments').select('*').eq('institute_id', instituteId).in('batch_id', batchIds).neq('status', 'draft') : empty,
    supabase.from('submissions').select('*').eq('institute_id', instituteId).in('student_id', ids),
    supabase.from('subjects').select('*').eq('institute_id', instituteId),
    supabase.from('notices').select('*').eq('institute_id', instituteId).contains('audience', ['parent']).not('published_at', 'is', null),
    supabase.from('student_fees').select('id').eq('institute_id', instituteId).in('student_id', ids).neq('status', 'cancelled'),
  ]);
  for (const query of queries) if (query.error) throw handleSupabaseError(query.error);
  const [students, batches, records, sessions, exams, marks, installments, assignments, submissions, subjects, notices, fees] = queries.map(q => q.data ?? []);
  const feeIds = new Set(fees.map(f => String(f.id)));
  result.children = students.map(mapStudent).map(student => {
    const ownBatchIds = new Set((enrollments ?? []).filter(e => e.student_id === student.id).map(e => String(e.batch_id)));
    return buildChildSummary({ today, student, instituteName: String(institute.name), batches: batches.map(mapBatch).filter(b => ownBatchIds.has(b.id)), records: records.map(mapAttendanceRecord), sessions: sessions.map(mapAttendanceSession), exams: exams.map(mapExam), marks: marks.map(mapMark), installments: installments.map(mapInstallment).filter(t => feeIds.has(t.studentFeeId)), assignments: assignments.map(mapAssignment), submissions: submissions.map(mapSubmission), subjects: subjects.map(mapSubject), notices: notices.map(mapNotice) });
  });
  return result;
}
