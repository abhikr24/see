import type {
  AttendanceSummary, ID, InstituteSettings, ProgressSnapshot,
  RiskAlert, RiskKind, RiskLevel, Student360, StudentAchievement, StudentGoal, StudyTask, Upsert,
} from '../../core/contracts/models';
import type { ProgressPort } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapStudentGoal, mapStudyTask } from './mappers';
import { listFallingStudents } from './teacher.repo';

/** Configurable early-warning rules constants */
export const RISK_RULES = {
  /** Watch student whose exam average is within this margin of pass mark */
  MARKS_MARGIN: 10,
  /** Minimum homework completion rate percentage */
  HOMEWORK_MIN_PERCENT: 60,
  /** Critical attendance deficit triggering high severity */
  LOW_ATTENDANCE_DEFICIT_HIGH: 15,
  /** Critical homework threshold triggering medium severity */
  HOMEWORK_CRITICAL_PERCENT: 30,
  /** Overdue installments triggering high severity */
  OVERDUE_COUNT_HIGH: 1,
} as const;

export function progressRepo(): ProgressPort {
  return {
    async getStudent360(instituteId: ID, studentId: ID): Promise<Student360> {
      try {
        return await memoryFallback.progress.getStudent360(instituteId, studentId);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async computeSnapshot(instituteId: ID, studentId: ID): Promise<ProgressSnapshot> {
      try {
        return await memoryFallback.progress.computeSnapshot(instituteId, studentId);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listSnapshots(instituteId: ID, studentId: ID): Promise<ProgressSnapshot[]> {
      try {
        return await memoryFallback.progress.listSnapshots(instituteId, studentId);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listAlerts(instituteId: ID, query?: ListQuery<RiskAlert>): Promise<Page<RiskAlert>> {
      try {
        return await memoryFallback.progress.listAlerts(instituteId, query);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async computeAlerts(instituteId: ID, filter?: { batchId?: ID; studentId?: ID }): Promise<RiskAlert[]> {
      try {
        return await memoryFallback.progress.computeAlerts(instituteId, filter);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    listFallingStudents,

    async setAlertStatus(instituteId: ID, alertId: ID, status: RiskAlert['status']): Promise<RiskAlert> {
      try {
        return await memoryFallback.progress.setAlertStatus(instituteId, alertId, status);
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listTasks(instituteId: ID, studentId: ID): Promise<StudyTask[]> {
      try {
        const { data, error } = await supabase.from('study_tasks').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapStudyTask);
      } catch {
        return memoryFallback.progress.listTasks(instituteId, studentId);
      }
    },

    async saveTask(instituteId: ID, input: Upsert<StudyTask, 'studentId' | 'title'>): Promise<StudyTask> {
      try {
        const row = {
          institute_id: instituteId, student_id: input.studentId, title: input.title,
          subject_id: input.subjectId ?? null, notes: input.notes ?? null, due_on: input.dueOn ?? null,
          priority: input.priority ?? 'medium', status: input.status ?? 'todo',
          completed_at: input.status === 'done' ? new Date().toISOString() : null,
          source: input.source ?? 'self',
        };
        const op = input.id
          ? supabase.from('study_tasks').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('study_tasks').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapStudyTask(data);
      } catch {
        return memoryFallback.progress.saveTask(instituteId, input);
      }
    },

    async removeTask(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('study_tasks').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.progress.removeTask(instituteId, id);
      }
    },

    async listGoals(instituteId: ID, studentId: ID): Promise<StudentGoal[]> {
      try {
        const { data, error } = await supabase.from('student_goals').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapStudentGoal);
      } catch {
        return memoryFallback.progress.listGoals(instituteId, studentId);
      }
    },

    async syncAchievements(instituteId: ID, studentId: ID): Promise<StudentAchievement[]> {
      try {
        const now = new Date();
        const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString().slice(0, 10);
        const monthEnd = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1)).toISOString().slice(0, 10);
        const { data: sessionRows, error: sessionError } = await supabase.from('attendance_sessions').select('id,date').eq('institute_id', instituteId).gte('date', monthStart).lt('date', monthEnd).neq('status', 'open');
        if (sessionError) throw sessionError;
        const sessionIds = (sessionRows ?? []).map((row) => String(row.id));
        const { data: attendanceRows, error: attendanceError } = sessionIds.length
          ? await supabase.from('attendance_records').select('status').eq('institute_id', instituteId).eq('student_id', studentId).in('session_id', sessionIds)
          : { data: [], error: null };
        if (attendanceError) throw attendanceError;
        const { data: submissions, error: submissionsError } = await supabase.from('submissions').select('assignment_id,submitted_at').eq('institute_id', instituteId).eq('student_id', studentId).not('submitted_at', 'is', null);
        if (submissionsError) throw submissionsError;
        const assignmentIds = [...new Set((submissions ?? []).map((row) => String(row.assignment_id)))];
        const { data: assignmentRows, error: assignmentError } = assignmentIds.length
          ? await supabase.from('assignments').select('id,due_at').eq('institute_id', instituteId).in('id', assignmentIds)
          : { data: [], error: null };
        if (assignmentError) throw assignmentError;
        const dueById = new Map((assignmentRows ?? []).map((row) => [String(row.id), row.due_at ? String(row.due_at) : null]));
        const onTime = (submissions ?? []).filter((row) => {
          const dueAt = dueById.get(String(row.assignment_id));
          return Boolean(dueAt && row.submitted_at && String(row.submitted_at) <= dueAt);
        }).length;
        const { data: resultRows, error: resultsError } = await supabase.from('results').select('exam_id,percentage').eq('institute_id', instituteId).eq('student_id', studentId);
        if (resultsError) throw resultsError;
        const resultExamIds = [...new Set((resultRows ?? []).map((row) => String(row.exam_id)))];
        const { data: publishedExams, error: examsError } = resultExamIds.length
          ? await supabase.from('exams').select('id').eq('institute_id', instituteId).eq('status', 'published').in('id', resultExamIds)
          : { data: [], error: null };
        if (examsError) throw examsError;
        const publishedIds = new Set((publishedExams ?? []).map((row) => String(row.id)));
        const earned = [
          { key: 'perfect_attendance_month', title: 'Perfect attendance', description: 'Every class attended this month', ok: (attendanceRows ?? []).length > 0 && (attendanceRows ?? []).every((row) => row.status === 'present' || row.status === 'late') },
          { key: 'homework_streak_10', title: 'Homework hero', description: '10 homework assignments handed in on time', ok: onTime >= 10 },
          { key: 'first_90_score', title: 'First 90+', description: 'Earned 90% or higher on a published exam', ok: (resultRows ?? []).some((row) => publishedIds.has(String(row.exam_id)) && Number(row.percentage) >= 90) },
        ].filter((item) => item.ok);
        if (earned.length) {
          const rows = earned.map((item) => ({ institute_id: instituteId, student_id: studentId, achievement_key: item.key, title: item.title, description: item.description }));
          const { error } = await supabase.from('student_achievements').upsert(rows, { onConflict: 'institute_id,student_id,achievement_key', ignoreDuplicates: true });
          if (error) throw error;
        }
        const { data, error } = await supabase.from('student_achievements').select('*').eq('institute_id', instituteId).eq('student_id', studentId).order('earned_at', { ascending: true });
        if (error) throw error;
        return (data ?? []).map((row) => ({ id: String(row.id), instituteId: String(row.institute_id), studentId: String(row.student_id), key: row.achievement_key as StudentAchievement['key'], title: String(row.title), description: String(row.description), earnedAt: String(row.earned_at), celebratedAt: row.celebrated_at ? String(row.celebrated_at) : null, createdAt: String(row.created_at), updatedAt: String(row.updated_at) }));
      } catch {
        return memoryFallback.progress.syncAchievements(instituteId, studentId);
      }
    },

    async markAchievementCelebrated(instituteId: ID, studentId: ID, achievementId: ID): Promise<boolean> {
      try {
        const { data, error } = await supabase.from('student_achievements').update({ celebrated_at: new Date().toISOString() }).eq('institute_id', instituteId).eq('student_id', studentId).eq('id', achievementId).is('celebrated_at', null).select('id');
        if (error) throw error;
        return Boolean(data?.length);
      } catch {
        return memoryFallback.progress.markAchievementCelebrated(instituteId, studentId, achievementId);
      }
    },

    async saveGoal(instituteId: ID, input: Upsert<StudentGoal, 'studentId' | 'title'>): Promise<StudentGoal> {
      try {
        const row = {
          institute_id: instituteId, student_id: input.studentId, title: input.title,
          subject_id: input.subjectId ?? null, description: input.description ?? null,
          metric: input.metric ?? 'custom', target_value: input.targetValue ?? null,
          current_value: input.currentValue ?? null, starts_on: input.startsOn ?? new Date().toISOString().slice(0, 10),
          target_date: input.targetDate ?? null, status: input.status ?? 'active',
        };
        const op = input.id
          ? supabase.from('student_goals').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('student_goals').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapStudentGoal(data);
      } catch {
        return memoryFallback.progress.saveGoal(instituteId, input);
      }
    },
  };
}
