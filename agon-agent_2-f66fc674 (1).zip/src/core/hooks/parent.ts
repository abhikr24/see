import { useSession } from './tenant';
import { useDomainMutation, useDomainQuery } from './domain';
import { BackendError } from '../contracts/errors';
import type { ParentSummary } from '../contracts/models/parent';

export function useParentSummary() {
  const session = useSession();
  const userId = session.data?.user.id;
  return useDomainQuery<ParentSummary>('analytics', ['parent-summary', userId], (b, i) => b.analytics.childSummary(i), Boolean(userId));
}
/** A local demo checkout never presents itself as a real transfer. Live fails closed. */
export function useParentPayment() {
  return useDomainMutation<{ studentId: string; installmentId: string }, string>(
    ['analytics', 'fees', 'payments', 'receipts'],
    async (b, i, input) => {
      if (b.name !== 'memory') throw new BackendError('NOT_IMPLEMENTED', 'Online payments are not connected yet. Please contact your institute to arrange payment.');
      const summary = await b.analytics.childSummary(i);
      const child = summary.children.find(c => c.id === input.studentId);
      const term = child?.terms.find(t => t.id === input.installmentId);
      if (!term) throw new BackendError('NOT_FOUND', 'Fee not found');
      if (term.remaining <= 0) throw new BackendError('CONFLICT', 'This fee has already been paid');
      const order = await b.paymentGateway.createOrder(i, { studentId: child!.id, installmentId: term.id, amount: term.remaining });
      const payment = await b.paymentGateway.confirm(i, order.id, { providerPaymentId: `DEMO-${order.id}` });
      const receipt = await b.receipts.getForPayment(i, payment.id);
      return receipt?.receiptNo ?? payment.id;
    },
    { success: 'Demo payment complete. Your fee summary is up to date.', failure: 'Payment could not be completed' },
  );
}
