import React, { useState } from 'react';
import { FlatList, Pressable, RefreshControl, View, useWindowDimensions } from 'react-native';
import { C } from '@/lib/theme';
import { formatParentDate } from '@/core/contracts/parent';
import { useParent } from './context';
import { UpdateRow } from './cards';
import { ParentState } from './ParentHome';
import { Action, currency, Icon, Label, Panel, Photo, styles } from './ui';

const TAB_BAR_INSET = 136;

function Heading({ title, subtitle }: { title: string; subtitle: string }) {
  const p = useParent();
  return <View style={{ marginBottom: 24, gap: 12 }}><Label size={27} weight="800" style={{ letterSpacing: -0.7 }}>{title}</Label><Label color={C.muted} size={13}>{subtitle}</Label>{p.child && <Pressable accessibilityRole="button" disabled={(p.summary?.children.length ?? 0) <= 1} accessibilityLabel="Switch child" onPress={() => p.setSwitcherOpen(true)} style={[styles.row, { gap: 10, marginTop: 8, alignSelf: 'flex-start' }]}><Photo name={p.child.name} uri={p.child.photoUrl} size={30} /><Label size={13} weight="700">{p.child.name}</Label>{(p.summary?.children.length ?? 0) > 1 && <Icon name="chevron-down" size={14} color={C.muted} />}</Pressable>}</View>;
}
function Frame({ children }: { children: React.ReactNode }) {
  return <View style={{ flex: 1, backgroundColor: C.canvas }}>{children}</View>;
}
function useDetailStyle() { const mobile = useWindowDimensions().width < 980; return [styles.page, mobile && { paddingHorizontal: 20, paddingTop: 12 }, { paddingBottom: TAB_BAR_INSET }]; }
export function ParentFees() {
  const p = useParent();
  const contentStyle = useDetailStyle();
  return <Frame><FlatList data={p.child?.terms ?? []} keyExtractor={t => t.id} contentContainerStyle={[...contentStyle, { gap: 15 }]} refreshControl={<RefreshControl refreshing={p.loading && !!p.summary} onRefresh={() => void p.refresh()} />} ListHeaderComponent={<><Heading title="One less thing to think about" subtitle="Your child’s fees, with everything in its place." />{!p.child ? <ParentState /> : <Panel style={{ marginBottom: 8 }}><Label color={C.muted} size={12}>Due now</Label><Label size={40} color={p.child.dueNow ? C.duesInk : C.teal} weight="800">{currency(p.child.dueNow)}</Label><Label size={13} color={C.muted}>{p.child.totalOutstanding === 0 ? 'Everything is taken care of. Thank you.' : p.child.dueNow === 0 ? 'Nothing overdue. You can plan ahead for the next term.' : 'You can settle the outstanding term below.'}</Label></Panel>}</>}
    ListEmptyComponent={p.child ? <Panel><Label color={C.muted}>No fees have been assigned yet.</Label></Panel> : null}
    renderItem={({ item }) => <Panel><View style={styles.spread}><View><Label size={16} weight="700">{item.label}</Label><Label size={12} color={C.muted}>Due {formatParentDate(item.dueDate)}</Label></View><Label size={22} weight="800" color={C.primary}>{currency(item.remaining || item.paidAmount)}</Label></View><View style={[styles.spread, { marginTop: 20 }]}><View style={[styles.row, { gap: 6 }]}><Icon name={item.remaining ? 'time-outline' : 'checkmark-circle'} size={16} color={item.remaining ? C.duesInk : C.teal} /><Label size={12} color={item.remaining ? C.duesInk : C.teal}>{item.remaining ? 'To be paid' : 'Fully paid'}</Label></View>{item.remaining > 0 && p.child && <Action label="Pay now" onPress={() => p.open({ type: 'payment', term: item, child: p.child! })} />}</View></Panel>} />
  </Frame>;
}
export function ParentNotices() {
  const p = useParent();
  const [filter, setFilter] = useState('All');
  const contentStyle = useDetailStyle();
  const updates = p.child?.updates.filter(u => filter === 'All' || u.kind === filter.toLowerCase()) ?? [];
  return <Frame><FlatList data={updates} keyExtractor={u => u.id} contentContainerStyle={contentStyle} refreshControl={<RefreshControl refreshing={p.loading && !!p.summary} onRefresh={() => void p.refresh()} />} ListHeaderComponent={<><Heading title="A little window into their day" subtitle="Homework, class updates and things worth knowing." /><View style={{ flexDirection: 'row', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>{['All', 'Homework', 'Attendance', 'Notice'].map(label => <Pressable key={label} accessibilityRole="tab" accessibilityState={{ selected: filter === label }} accessibilityLabel={`Filter ${label}`} onPress={() => setFilter(label)} style={{ paddingHorizontal: 17, paddingVertical: 10, borderRadius: 22, backgroundColor: filter === label ? C.primary : C.surface, borderWidth: 1, borderColor: filter === label ? C.primary : C.hairline }}><Label size={12} weight="600" color={filter === label ? C.surface : C.muted}>{label === 'Notice' ? 'Notices' : label}</Label></Pressable>)}</View></>}
    renderItem={({ item }) => <Panel style={{ marginBottom: 14, paddingTop: 0, paddingBottom: 0 }}><UpdateRow update={item} last /></Panel>}
    ListEmptyComponent={p.child ? <Panel><Icon name="checkmark-circle-outline" color={C.teal} size={27} /><Label size={16} weight="700" style={{ marginTop: 12 }}>All quiet for now</Label><Label size={13} color={C.muted} style={{ marginTop: 5 }}>When there’s something to share, you’ll find it here.</Label></Panel> : <ParentState />} />
  </Frame>;
}
