import React from 'react';
import { View } from 'react-native';
import { C } from '@/lib/theme';
import { formatParentDate } from '@/core/contracts/parent';
import { ParentSheet } from './ParentSheet';
import { useParent, type ParentDialog } from './context';
import { Action, currency, Icon, Label, Photo, styles } from './ui';

export function ParentDialogs({ dialog, close, pay, paying, error }: { dialog: ParentDialog; close: () => void; pay: () => void; paying: boolean; error?: string }) {
  const { summary, demo } = useParent();
  if (!dialog) return null;
  const title = dialog.type === 'payment' ? 'One less thing to think about' : dialog.type === 'success' ? 'You’re all set' : dialog.type === 'profile' ? 'Your parent space' : dialog.type === 'support' ? 'We’re here for you' : dialog.update.title;
  return <ParentSheet visible close={close} title={title}>
    {dialog.type === 'update' && <View style={{ gap: 22 }}>
      <View style={[styles.row, { gap: 8 }]}><Icon name={dialog.update.kind === 'homework' ? 'book-outline' : dialog.update.kind === 'attendance' ? 'calendar-outline' : 'megaphone-outline'} color={C.muted} size={17} /><Label color={C.muted} size={12}>{formatParentDate(dialog.update.date)} · {dialog.update.kind}</Label></View>
      <Label size={15} style={{ lineHeight: 26 }}>{dialog.update.body}</Label>
      <Action label="Got it, thank you" onPress={close} />
    </View>}
    {dialog.type === 'payment' && <View style={{ gap: 21 }}>
      <View style={[styles.row, { gap: 12 }]}><Photo name={dialog.child.name} uri={dialog.child.photoUrl} size={42} /><View><Label weight="700">{dialog.child.name}</Label><Label size={12} color={C.muted}>{dialog.child.classLabel} · {dialog.child.instituteName.replace(' Classes', '')}</Label></View></View>
      <View style={{ padding: 22, backgroundColor: C.canvas, borderRadius: 16 }}><Label size={12} color={C.muted}>{dialog.term.label} fee · Due {formatParentDate(dialog.term.dueDate)}</Label><Label size={36} weight="800" color={C.primary}>{currency(dialog.term.remaining)}</Label><Label size={12} color={C.muted}>No additional fees</Label></View>
      <View style={[styles.row, { gap: 9, alignItems: 'flex-start' }]}><Icon name="information-circle-outline" size={18} color={C.duesInk} /><Label size={12} color={C.muted} style={{ flex: 1 }}>{demo ? 'This is a demo payment. No real money will be charged. Your demo fee balance and receipt will be updated.' : 'Your institute has not connected online checkout yet. Contact the office to arrange payment.'}</Label></View>
      {error && <Label color={C.danger} size={12}>{error}</Label>}
      {demo && <Action label={paying ? 'Confirming payment…' : 'Confirm demo payment'} disabled={paying} onPress={pay} icon="lock-closed-outline" />}
      <Action label={demo ? 'Maybe later' : 'Close'} onPress={close} secondary disabled={paying} />
    </View>}
    {dialog.type === 'success' && <View style={{ alignItems: 'center', gap: 18 }}><View style={{ padding: 18, backgroundColor: C.tealSoft, borderRadius: 40 }}><Icon name="checkmark" size={34} color={C.teal} /></View><Label size={30} weight="800">{currency(dialog.amount)}</Label><Label style={{ textAlign: 'center' }} color={C.muted}>Demo payment complete. Your fee reminder has been cleared.</Label><View style={{ backgroundColor: C.canvas, padding: 16, borderRadius: 12, width: '100%' }}><Label size={11} color={C.muted}>DEMO RECEIPT</Label><Label weight="700" size={14}>{dialog.receipt}</Label></View><Action label="Back to my child’s day" onPress={close} /></View>}
    {dialog.type === 'profile' && <View style={{ gap: 24 }}><View style={[styles.row, { gap: 15 }]}><Photo name={summary?.parentName ?? 'Parent'} uri={summary?.parentPhotoUrl} size={60} /><View><Label size={18} weight="700">{summary?.parentName}</Label><Label size={12} color={C.muted}>Parent · Sunrise Coaching</Label></View></View><View style={{ backgroundColor: C.canvas, padding: 18, borderRadius: 16 }}><Label weight="700">A space just for your family</Label><Label size={13} color={C.muted} style={{ marginTop: 6 }}>Only children linked to your parent account appear here. Your family’s details stay private.</Label></View>{demo && <Label size={12} color={C.muted}>You’re exploring the local demo. Changes are saved on this device.</Label>}<Action label="Back to overview" onPress={close} /></View>}
    {dialog.type === 'support' && <View style={{ gap: 22 }}><Label color={C.muted}>A question about attendance, homework or fees? Your child’s class teacher is the best place to start.</Label><View style={{ backgroundColor: C.canvas, padding: 20, borderRadius: 16, gap: 7 }}><Label weight="700">Sunrise Coaching Classes</Label><Label size={13} color={C.muted}>Boring Road, Patna, Bihar</Label><Label size={13} color={C.muted}>Speak with the office during your child’s next class.</Label></View><Label size={12} color={C.muted}>If an attendance entry seems incorrect, mention the date and class so the teacher can check it for you.</Label><Action label="Thanks, got it" onPress={close} /></View>}
  </ParentSheet>;
}
