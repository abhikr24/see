-- A student's milestones are append-once records. Unique keys guarantee that
-- refreshing a screen or retrying a sync can never grant the same reward twice.
create table public.student_achievements (
  id uuid primary key default gen_random_uuid(),
  institute_id uuid not null references public.institutes(id) on delete cascade,
  student_id uuid not null,
  achievement_key text not null check (achievement_key in ('perfect_attendance_month', 'homework_streak_10', 'first_90_score')),
  title text not null,
  description text not null,
  earned_at timestamptz not null default now(),
  celebrated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, student_id, achievement_key),
  foreign key (institute_id, student_id) references public.student_profiles(institute_id, id) on delete cascade
);
create index student_achievements_owner_idx on public.student_achievements(institute_id, student_id, earned_at);
alter table public.student_achievements enable row level security;
create policy student_achievements_select on public.student_achievements for select to authenticated
  using (institute_id = any ((select public.auth_institute_ids())::uuid[]) and student_id = any ((select public.my_student_ids())::uuid[]));
create policy student_achievements_insert on public.student_achievements for insert to authenticated
  with check (institute_id = any ((select public.auth_institute_ids())::uuid[]) and public.has_role(institute_id, array['student']) and student_id = any ((select public.my_student_ids())::uuid[]));
create policy student_achievements_update on public.student_achievements for update to authenticated
  using (institute_id = any ((select public.auth_institute_ids())::uuid[]) and public.has_role(institute_id, array['student']) and student_id = any ((select public.my_student_ids())::uuid[]))
  with check (institute_id = any ((select public.auth_institute_ids())::uuid[]) and public.has_role(institute_id, array['student']) and student_id = any ((select public.my_student_ids())::uuid[]));
