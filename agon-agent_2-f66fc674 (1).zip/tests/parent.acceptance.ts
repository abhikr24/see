import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed } from '../src/backends/memory/seed';
import { PARENT_PREVIEW, seedParentPreview } from '../src/backends/memory/seed-parent-preview';
import { analyticsRepo } from '../src/backends/memory/business';
import { paymentGateway } from '../src/backends/memory/finance';
import { capture, restore } from '../src/backends/memory/persist';

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const db = createDb();
seed(db);
seedParentPreview(db);
db.session.userId = PARENT_PREVIEW.userId;
const inst = PARENT_PREVIEW.instituteId;
const analytics = analyticsRepo(db);
let passed = 0;
async function check(name: string, run: () => Promise<void> | void) { await run(); passed++; console.log(`✓ ${name}`); }
async function main() {
  await check('one snapshot contains both children and all synchronized card figures', async () => {
    const home = await analytics.childSummary(inst);
    assert.equal(home.parentName, 'Rahul Sharma');
    assert.deepEqual(home.children.map(c => c.name), ['Aarav Sharma', 'Siya Sharma']);
    const [a, s] = home.children;
    assert.deepEqual([a.attendancePercent, a.averagePercent, a.dueNow], [92, 78, 0]);
    assert.deepEqual([s.attendancePercent, s.averagePercent, s.dueNow], [88, 74, 1800]);
    assert.equal(a.trend.length, 5);
    assert.equal(s.trend.length, 5);
    assert.equal(a.nextFee?.remaining, 4999);
    assert.equal(a.nextFee?.dueDate.slice(-2), '20');
    assert.deepEqual(a.updates.map(u => u.kind), ['homework', 'attendance', 'notice']);
    assert.notDeepEqual(a.updates, s.updates);
  });
  await check('a different family sees only its own linked student', async () => {
    db.session.userId = sid(11015);
    const home = await analytics.childSummary(inst);
    assert.deepEqual(home.children.map(c => c.name), ['Ishita Bose']);
    assert.equal(home.children.some(c => c.name.endsWith('Sharma')), false);
    db.session.userId = PARENT_PREVIEW.userId;
  });
  await check('one linked child returns a one-item list; an unlinked parent returns none', async () => {
    db.session.userId = sid(37);
    assert.equal((await analytics.childSummary(inst)).children.length, 1);
    const link = db.parentLinks.all(inst, { guardianId: sid(11314) })[0];
    db.parentLinks.remove(inst, link.id);
    assert.deepEqual((await analytics.childSummary(inst)).children, []);
    db.parentLinks.put(link);
    db.session.userId = PARENT_PREVIEW.userId;
  });
  await check('no session, wrong role, pending membership and wrong institute all fail closed', async () => {
    db.session.userId = null;
    await assert.rejects(() => analytics.childSummary(inst), { code: 'UNAUTHENTICATED' });
    db.session.userId = sid(2);
    await assert.rejects(() => analytics.childSummary(inst), { code: 'FORBIDDEN' });
    db.session.userId = PARENT_PREVIEW.userId;
    db.memberships.update(inst, sid(92002), { status: 'pending' });
    await assert.rejects(() => analytics.childSummary(inst), { code: 'FORBIDDEN' });
    db.memberships.update(inst, sid(92002), { status: 'active' });
    await assert.rejects(() => analytics.childSummary(sid(71001)), { code: 'FORBIDDEN' });
  });
  await check('tampered checkout cannot pay or inspect another family’s order', async () => {
    const gateway = paymentGateway(db);
    const other = db.installments.all(inst, { studentId: sid(15) }).find(t => t.amount > t.paidAmount)!;
    await assert.rejects(() => gateway.createOrder(inst, { studentId: sid(15), installmentId: other.id, amount: 1 }), { code: 'NOT_FOUND' });
    db.session.userId = sid(2);
    const order = await gateway.createOrder(inst, { studentId: sid(15), installmentId: other.id, amount: 1 });
    db.session.userId = PARENT_PREVIEW.userId;
    await assert.rejects(() => gateway.getOrder(inst, order.id), { code: 'NOT_FOUND' });
    await assert.rejects(() => gateway.confirm(inst, order.id, { providerPaymentId: 'tampered' }), { code: 'NOT_FOUND' });
  });
  await check('partial payment keeps reminder, full payment removes it without changing sibling', async () => {
    const gateway = paymentGateway(db);
    const before = await analytics.childSummary(inst);
    const [a, s] = before.children;
    const term = a.nextFee!;
    const first = await gateway.createOrder(inst, { studentId: a.id, installmentId: term.id, amount: 1000 });
    await gateway.confirm(inst, first.id, { providerPaymentId: 'DEMO-PARTIAL' });
    const partial = await analytics.childSummary(inst);
    assert.equal(partial.children[0].nextFee?.remaining, 3999);
    const final = await gateway.createOrder(inst, { studentId: a.id, installmentId: term.id, amount: 3999 });
    await gateway.confirm(inst, final.id, { providerPaymentId: 'DEMO-FINAL' });
    const after = await analytics.childSummary(inst);
    assert.equal(after.children[0].nextFee, null);
    assert.equal(after.children[0].totalOutstanding, 0);
    assert.deepEqual(after.children[1], s);
    assert.equal(after.children[0].averagePercent, 78);
    assert.equal(after.children[0].attendancePercent, 92);
    await assert.rejects(() => gateway.confirm(inst, final.id, { providerPaymentId: 'DUPLICATE' }), { code: 'CONFLICT' });
  });
  await check('paid state survives snapshot restoration and preview top-up', async () => {
    const restored = createDb();
    assert.ok(restore(restored, capture(db)));
    seedParentPreview(restored);
    restored.session.userId = PARENT_PREVIEW.userId;
    const home = await analyticsRepo(restored).childSummary(inst);
    assert.equal(home.children[0].nextFee, null);
    assert.equal(home.children[1].dueNow, 1800);
  });
  await check('revoking a parent link removes that child from the very next snapshot', async () => {
    db.parentLinks.remove(inst, sid(92007));
    assert.deepEqual((await analytics.childSummary(inst)).children.map(c => c.id), [PARENT_PREVIEW.aaravId]);
  });
  console.log(`\n${passed} parent acceptance checks passed.`);
}
main().catch(error => { console.error(error); process.exitCode = 1; });
