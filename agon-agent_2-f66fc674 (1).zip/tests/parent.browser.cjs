const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.join(process.cwd(), 'dist');
const shots = path.join(process.cwd(), '.shots');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png', '.jpg': 'image/jpeg' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8140);
const seen = (page, text) => page.getByText(text, { exact: true }).first().waitFor({ state: 'visible', timeout: 25000 });
const shot = async (page, name) => { fs.mkdirSync(shots, { recursive: true }); await page.screenshot({ path: path.join(shots, `parent-${name}.png`), fullPage: false }); };
(async () => {
  let browser;
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, colorScheme: 'light' });
    const errors = [];
    page.on('pageerror', e => { errors.push(e.message); console.error('PAGE ERROR:', e.message); });
    await page.goto('http://localhost:8140');
    await seen(page, 'Good evening');
    for (const text of ['92%', '78%', '₹0', 'Performance trend', 'Recent updates']) await seen(page, text);
    await page.waitForTimeout(600);
    await shot(page, 'desktop');
    console.log('PASS desktop dashboard renders from one snapshot');
    await page.getByRole('button', { name: /Switch child\. Aarav/ }).click();
    await seen(page, 'Your children');
    await seen(page, 'Tap a child to see their details.');
    assert.equal(await page.getByRole('button', { name: /^Select / }).count(), 2);
    await page.waitForTimeout(400);
    await shot(page, 'switcher');
    const beforeURL = page.url();
    await page.getByRole('button', { name: 'Select Siya Sharma' }).click();
    for (const text of ['88%', '74%', '₹1,800', 'Science exhibition this Friday']) await seen(page, text);
    assert.equal(page.url(), beforeURL);
    console.log('PASS child switch updates attendance, marks, dues, updates and trend with no navigation');
    await page.getByRole('button', { name: /Switch child\. Siya/ }).click();
    await page.getByRole('button', { name: 'Select Aarav Sharma' }).click();
    await page.getByRole('button', { name: 'An attendance heads-up', exact: true }).click();
    await seen(page, 'Got it, thank you');
    await page.getByRole('button', { name: 'Got it, thank you', exact: true }).click();
    await page.getByRole('tab', { name: 'Attendance', exact: true }).click();
    await seen(page, 'Every day is a little step forward');
    await page.getByRole('tab', { name: 'Notices', exact: true }).click();
    await seen(page, 'A little window into their day');
    await page.getByRole('tab', { name: 'Filter Notice' }).click();
    await seen(page, 'Parent–teacher meet');
    await page.getByRole('tab', { name: 'Fees & payments', exact: true }).click();
    await seen(page, 'One less thing to think about');
    await page.getByRole('tab', { name: 'Overview', exact: true }).click();
    console.log('PASS detail modal and all supporting navigation');
    await page.setViewportSize({ width: 390, height: 844 });
    await seen(page, 'Good evening');
    await page.waitForTimeout(400);
    await shot(page, 'mobile');
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= 390), 'No horizontal overflow');
    await page.getByRole('button', { name: /Switch child\. Aarav/ }).click();
    await seen(page, 'Your children');
    await page.waitForTimeout(400);
    await shot(page, 'mobile-switcher');
    await page.getByRole('button', { name: 'Select Siya Sharma' }).click();
    await seen(page, '88%');
    await page.getByRole('button', { name: /Switch child\. Siya/ }).click();
    await page.getByRole('button', { name: 'Select Aarav Sharma' }).click();
    await page.getByRole('button', { name: 'Pay now', exact: true }).click();
    await seen(page, 'Confirm demo payment');
    await page.getByRole('button', { name: 'Confirm demo payment', exact: true }).click();
    await seen(page, 'You’re all set');
    await page.getByRole('button', { name: 'Back to my child’s day', exact: true }).click();
    assert.equal(await page.getByTestId('fee-reminder').count(), 0);
    await page.reload();
    await seen(page, 'Good evening');
    assert.equal(await page.getByTestId('fee-reminder').count(), 0);
    console.log('PASS demo payment removes fee card and persists after reload');
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.emulateMedia({ colorScheme: 'dark' });
    await page.waitForTimeout(400);
    await shot(page, 'dark');
    await page.addInitScript(() => {
      const key = 'gf.memory.snapshot.v1';
      const snapshot = JSON.parse(localStorage.getItem(key));
      snapshot.tables.parentLinks = snapshot.tables.parentLinks.filter(link => link.id !== '00000000-0000-4000-8000-000000092007');
      localStorage.setItem(key, JSON.stringify(snapshot));
    });
    await page.reload();
    await seen(page, 'Good evening');
    assert.equal(await page.getByRole('button', { name: /Switch child/ }).count(), 0);
    console.log('PASS single-child family has no switcher');
    assert.deepEqual(errors, []);
    console.log('PASS mobile sizing, child switcher, dark theme, zero browser runtime errors');
  } catch (error) {
    console.error(error);
    if (browser) for (const context of browser.contexts()) for (const page of context.pages()) {
      await shot(page, 'failure').catch(() => {});
      console.error((await page.locator('body').innerText()).slice(0, 5000));
    }
    process.exitCode = 1;
  } finally {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
})();
