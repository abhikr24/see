// Expo Router owns the entry point. Kept for integrations that import App.
export { default } from './app/_layout';
