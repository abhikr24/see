# Studifi

**Plan. Organize. Learn. Grow.** A local-first Expo / React Native student workspace with a responsive web preview.

## Run

```sh
npm install --legacy-peer-deps
npx expo start
```

Use the SDK 57-compatible Expo Go client, or make a development build for your devices. To build the same artifacts as this delivery:

```sh
npm run typecheck
npm run build        # expo export --platform all
npx playwright install chromium
npm test            # finite-lived static server + Chromium integration tests
```

The installed SDK's native dependency versions are pinned. npm overrides avoid unpublished transitive patch versions in the supplied package registry. The lockfile is part of the handoff.

## What works

- A responsive dashboard and five native-style tabs, plus desktop navigation.
- Tasks with filters, subjects, due dates, priorities, subtasks, recurring completion, reminders, swipe deletion, and undo.
- Week/month/list planner, time labels, overlap warnings, and long-press drag rescheduling snapped to 15 minutes.
- Subjects, chapter checklists, syllabus progress, and related tasks, notes, and exams.
- Notes with formatting controls, native Markdown preview, pinned/searchable cards, image attachments, and debounced local drafts.
- Exams with chapter selection, countdowns, locations, and percentage results.
- Daily/weekly/monthly habits with historical completion, current and best streaks, and a one-missed-day allowance.
- Timestamp-based focus/break timer, custom lengths, persistent state, completion logging, and local reminders.
- Analytics calculated from recorded focus sessions and completed tasks; no fabricated counters.
- Editable flashcard decks, card flips, and Again/Hard/Good/Easy interval scheduling.
- Goals and milestone checklists; class attendance; weighted GPA calculation; daily/weekly reflections.
- Profile photo/name, light/dark/system theme, time format, week start, reminder preferences, privacy, feedback outbox, and developer connection checks.
- JSON backup/merge import, Markdown export, and PDF/print flows.
- Optional email/password Supabase authentication and curated content, quotes, announcements, count-only analytics, consent, and explicit feedback.

## Data boundary

`screen → feature hook / Zustand store → service → repository interface → storage`

- `src/lib/local/` uses **expo-sqlite** for every student-content record, preference, draft, and outbox item.
- `src/lib/remote/` uses **Supabase only for business data**. It never imports local code.
- `src/lib/services/container.ts` is the only wiring point that touches both implementations.
- Screens never import SQLite or the Supabase client.
- Each SQLite table stores a validated JSON payload with independent UUID, created/updated/deleted timestamps, and reserved `sync_state`. Schema migrations are versioned; soft deletion preserves undo.
- Each feature has its own Zustand store, created by the shared factory in `src/store/features.ts`; the focus timer has an additional dedicated store.
- SecureStore holds the native anonymous identity and native auth session. AsyncStorage is used only for the web auth session, never student content.
- Every remote HTTP request has a seven-second abort timeout; failures return safe results without replacing local state.
- Metrics enter a local outbox first and use a numeric-key allowlist. Upload requires configured cloud, authentication, and accepted privacy consent.
- Note attachments and profile photos are encoded locally so JSON backups include their image data. Large image-heavy backups can be large.
- No content sync is implemented. Signing in never uploads student content.

## Optional Supabase setup

See `supabase/README.md` (10 steps), `supabase/schema.sql` (single, idempotent transaction), and `.env.example`. With no environment variables, Settings shows **Cloud: not configured** and every local study tool remains available. Configuration rejects service-role and secret keys.

## Assumptions and deliberate departures

1. **Preview entry:** web opens the labeled Ayaan demo workspace directly so it can be explored immediately. Native first launch opens Welcome. Welcome, onboarding, privacy, and guest authentication are also accessible from Settings or deep links.
2. **Demo:** one transaction seeds six subjects and a small set of representative content exactly once. The dashboard labels the workspace as demo; Settings removes demo rows in one tap without removing user-created rows. Reset never reseeds.
3. **SDK:** retained the scaffold's Expo SDK 57, rather than upgrading the whole project to SDK 58. Reanimated **4.5.1** and Worklets **0.10.1** match SDK 57's native versions; Reanimated v3 was not forced onto this runtime.
4. **Notes:** the editor is a native TextInput + Markdown formatter/preview, not TenTap or Pell WYSIWYG. It supports bold, italic, headings, lists, checklist syntax, highlight, and images without embedding a browser editor. This is an explicit departure from the requested editor library.
5. **Planner:** drag moves a card's start time at one minute per vertical point, snapped to 15 minutes. The timeline is an ordered agenda, not a proportional 24-hour canvas. Classes are individual events; recurring task completion creates the next occurrence.
6. **Goals:** progress comes from explicit milestone checklists. A task can optionally contribute to a goal; its linked milestone stays in sync when completed from either screen.
7. **Resources:** external videos/textbooks open through Linking. Bundled guides work offline. The “Past Papers” category ships practice problems from OpenStax, clearly labeled as not institution-specific past exams; no access to a student's school portal is assumed.
8. **Grades:** users enter grade points and credits on one consistent institutional scale. No country-specific percentage-to-GPA conversion is invented.
9. **Syllabus:** Home shows “Behind” when the next exam is within seven days and that subject's coverage is below 80%; otherwise it shows “On track.” This is a planning heuristic, not an institutional assessment. **Streaks:** a completed habit entry counts once per day. Current habit streaks allow one missed day; best streaks count uninterrupted completed days. Monthly view shows the current calendar month, weekly view the trailing seven days.
10. **Notification delivery:** reminders are local, opt-in, and scheduled only on native devices after a pre-prompt. There is no remote push delivery service, billing flow, or content synchronization in this release.
11. **Web export:** JSON/Markdown use the system clipboard with a visible copyable backup; native devices use file sharing. Web PDF uses the print dialog. There is no app-authored DOM, localStorage, browser Notification, or HTML drag-and-drop code.
12. **Onboarding subjects:** selected subjects appear first on Home. The complete subject library is not destructively deleted by deselecting a favorite.
13. **Auth recovery:** requesting a password-reset email is wired to Supabase. Completing recovery through a production callback still requires the project's allowed redirect configuration and additional recovery-session handling; standard account signup/signin does not require it. This flow is not represented as fully verified.
14. **Large datasets:** FlashList is used for page scrolling and task/planner data. Some bounded dashboard/subject/settings sections render their children within a virtualized page. A 10,000-row performance audit and a measured 60fps mid-range Android benchmark have not been performed.

## Native / Expo Go notes

SQLite, font loading, SVG, image picker, haptics, SecureStore, local notification scheduling, document picking, printing, and sharing use Expo APIs. Their real permission and system-sheet behavior must be exercised on iOS and Android. A development build is needed to validate custom app identity/deep links, native splash/permissions configuration, and any future remote push registration. Android remote push is not provided by this app. `expo-av` is installed as requested but not used; no audio playback control is presented.

Web SQLite is Expo's WASM implementation. Deployment includes WASM MIME handling and COOP/COEP headers. Some browsers, private modes, or embedded frames may limit persistent storage; use a compatible top-level browser or the native app and export backups. Reopening a hosted web app with absolutely no network is not an offline-PWA guarantee; native bundles are local.

## Verification status

Verified against the exported production web bundle in Chromium:
- Guest launch without `.env` and no page/console errors.
- Task create, completion, done filter, delete/undo, and reload persistence.
- Note creation, formatting preview, and reload persistence.
- Planner event creation and reload persistence.
- All major feature routes render.
- Timer start, timestamp recovery after reload, pause, and reset.
- Flashcard reveal and interval rating.
- Disabled cloud state and table-by-table connection check.
- JSON export includes newly created records.
- Guest sign-in, five-tab navigation, and screenshots at **360px and 430px**.
- Task creation while the browser context is offline; saved data survives reconnect and reload.
- `expo export --platform all` produces web, iOS, and Android bundles.

`artifacts/qa-results.json` records the automated assertions. **Not claimed as tested:** a live Supabase project and two-user RLS isolation, email delivery/recovery, physical-device kill/relaunch in airplane mode, OS notification delivery, native photo/print/share permission sheets, or measured device performance. The three acceptance scenarios in the brief are therefore not all certified as passed. The cloud schema/setup and native artifacts are delivered for those final environment-specific checks.

## Useful routes

`/`, `/tasks`, `/study`, `/planner`, `/more`, `/notes`, `/exams`, `/habits`, `/focus`, `/analytics`, `/resources`, `/goals`, `/settings`, `/timetable`, `/grades`, `/review`, `/search`, `/updates`, `/motivation`, `/welcome`, `/onboarding`, `/auth`, `/subject/:id`, `/deck/:id`.

Brand illustration and logo were created for this app. Demo avatar and mountain photograph are bundled from Unsplash. The supplied design-board image is a reference only and is not used as app UI.
