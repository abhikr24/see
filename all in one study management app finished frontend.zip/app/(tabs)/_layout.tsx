import React from 'react';
import { Tabs } from 'expo-router';
import { BottomTabs } from '../../src/components/BottomTabs';
import { useTheme } from '../../src/theme/tokens';
export default function TabLayout(){const t=useTheme();return <Tabs tabBar={props=><BottomTabs {...props}/>} screenOptions={{headerShown:false,sceneStyle:{backgroundColor:t.background}}}><Tabs.Screen name="index" options={{title:'Home'}}/><Tabs.Screen name="tasks" options={{title:'Tasks'}}/><Tabs.Screen name="study" options={{title:'Study'}}/><Tabs.Screen name="planner" options={{title:'Planner'}}/><Tabs.Screen name="more" options={{title:'More'}}/></Tabs>;}
