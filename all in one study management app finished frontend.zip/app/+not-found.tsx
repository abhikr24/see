import React from 'react';
import { router } from 'expo-router';
import { Page } from '../src/components/ui/Page';
import { EmptyState } from '../src/components/ui/primitives';
export default function NotFound(){return <Page><EmptyState title="A little off the study path." description="This page doesn’t exist, but your workspace is right where you left it." action="Back to my workspace" onPress={()=>router.replace('/' as never)}/></Page>;}
