import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import NotesScreen from '../src/features/notes/screens/NotesScreen';
import ExamsScreen from '../src/features/exams/screens/ExamsScreen';
import HabitsScreen from '../src/features/habits/screens/HabitsScreen';
import AnalyticsScreen from '../src/features/analytics/screens/AnalyticsScreen';
import FocusScreen from '../src/features/focus/screens/FocusScreen';
import ResourcesScreen from '../src/features/resources/screens/ResourcesScreen';
import GoalsScreen from '../src/features/goals/screens/GoalsScreen';
import SettingsScreen from '../src/features/settings/screens/SettingsScreen';
import TimetableScreen from '../src/features/more/screens/TimetableScreen';
import GradesScreen from '../src/features/more/screens/GradesScreen';
import ReviewScreen from '../src/features/more/screens/ReviewScreen';
import SearchScreen from '../src/features/more/screens/SearchScreen';
import UpdatesScreen from '../src/features/more/screens/UpdatesScreen';
import MotivationScreen from '../src/features/more/screens/MotivationScreen';
import NotFound from './+not-found';
const screens:Record<string,React.ComponentType>={notes:NotesScreen,exams:ExamsScreen,habits:HabitsScreen,analytics:AnalyticsScreen,focus:FocusScreen,resources:ResourcesScreen,goals:GoalsScreen,settings:SettingsScreen,timetable:TimetableScreen,grades:GradesScreen,review:ReviewScreen,search:SearchScreen,updates:UpdatesScreen,motivation:MotivationScreen};
export default function FeatureRoute(){const {feature}=useLocalSearchParams<{feature:string}>();const Screen=screens[feature]||NotFound;return <Screen/>;}
