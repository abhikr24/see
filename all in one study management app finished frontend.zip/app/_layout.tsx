import '../global.css';
import React,{useEffect} from 'react';
import { View,ActivityIndicator,Platform } from 'react-native';
import { Stack,router,usePathname } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import { Inter_400Regular } from '@expo-google-fonts/inter/400Regular';
import { Inter_500Medium } from '@expo-google-fonts/inter/500Medium';
import { Inter_600SemiBold } from '@expo-google-fonts/inter/600SemiBold';
import { Inter_700Bold } from '@expo-google-fonts/inter/700Bold';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Shell } from '../src/components/Shell';
import { ErrorBoundary } from '../src/components/ui/ErrorBoundary';
import { Toast } from '../src/components/ui/Toast';
import { T,Button } from '../src/components/ui/primitives';
import { Editor } from '../src/features/shared/components/Editor';
import { useBootstrap } from '../src/features/shared/hooks/useBootstrap';
import { useTheme } from '../src/theme/tokens';
import { useFocusClock } from '../src/store/focus';
import { usePreference } from '../src/store/features';
function Runtime(){useFocusClock();const t=useTheme();const onboarding=usePreference('onboarding','');const guest=usePreference('guest','true');const path=usePathname();useEffect(()=>{if(Platform.OS!=='web'&&!onboarding&&guest==='true'&&path==='/')router.replace('/welcome' as never);},[onboarding,guest,path]);return <><StatusBar style={t.dark?'light':'dark'}/><Shell><Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:t.background},animation:'fade',animationDuration:180}}><Stack.Screen name="(tabs)"/><Stack.Screen name="modals/editor" options={{presentation:'modal'}}/></Stack></Shell><Editor/><Toast/></>;}
function Root(){const [fontsLoaded,fontError]=useFonts({Inter_400Regular,Inter_500Medium,Inter_600SemiBold,Inter_700Bold});const {ready,error,retry}=useBootstrap();const t=useTheme();if(error)return <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:t.background,padding:32,gap:18}}><T size={23} weight="bold">Let’s reopen your workspace.</T><T size={12} color={t.muted} style={{maxWidth:500,textAlign:'center'}}>{error}</T><Button title="Try again" icon="RefreshCw" onPress={()=>void retry()}/></View>;if(!ready||(!fontsLoaded&&!fontError))return <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'#F5F7FB',gap:20}}><View style={{width:60,height:60,borderRadius:20,backgroundColor:'#2563EB',alignItems:'center',justifyContent:'center'}}><ActivityIndicator color="#FFFFFF"/></View><T size={22} weight="bold">Studifi.</T><T size={12} color="#7C879C">Making room for your next chapter…</T></View>;return <Runtime/>;}
export default function RootLayout(){return <GestureHandlerRootView style={{flex:1}}><SafeAreaProvider><ErrorBoundary><Root/></ErrorBoundary></SafeAreaProvider></GestureHandlerRootView>;}
