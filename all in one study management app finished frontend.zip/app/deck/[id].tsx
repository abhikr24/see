export {default} from '../../src/features/resources/screens/DeckScreen';
