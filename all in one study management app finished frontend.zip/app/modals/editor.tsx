import React,{useEffect} from 'react';
import { router,useLocalSearchParams } from 'expo-router';
import { View } from 'react-native';
import { appStore } from '../../src/store/app';
import { Table,TABLES } from '../../src/lib/types/models';
export default function EditorRoute(){const {table}=useLocalSearchParams<{table?:string}>();useEffect(()=>{appStore.getState().edit({table:TABLES.includes(table as Table)?table as Table:'tasks'});router.back();},[]);return <View/>;}
