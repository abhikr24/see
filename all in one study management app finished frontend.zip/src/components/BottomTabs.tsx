import React from 'react';
import { View,Pressable,useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from './ui/Icon';
import { T } from './ui/primitives';
import { useTheme } from '../theme/tokens';
const icons=['LayoutDashboard','ListTodo','BookOpen','CalendarDays','MoreHorizontal'];
export function BottomTabs({state,navigation}:any){const {width}=useWindowDimensions();const t=useTheme();const insets=useSafeAreaInsets();if(width>=1000)return null;return <View style={{flexDirection:'row',backgroundColor:t.card,borderTopWidth:1,borderColor:t.line,paddingTop:8,paddingBottom:Math.max(insets.bottom,10)}}>{state.routes.map((route:any,i:number)=>{const active=state.index===i;return <Pressable key={route.key} accessibilityRole="tab" accessibilityState={{selected:active}} accessibilityLabel={['Home','Tasks','Study','Planner','More'][i]} onPress={()=>navigation.navigate(route.name)} style={{flex:1,alignItems:'center',gap:2}}><View style={{width:48,height:29,borderRadius:10,alignItems:'center',justifyContent:'center',backgroundColor:active?t.blueSoft:'transparent'}}><Icon name={icons[i]} color={active?t.primary:t.muted} size={20}/></View><T size={10} color={active?t.primary:t.muted} weight={active?'semibold':'regular'}>{['Home','Tasks','Study','Planner','More'][i]}</T></Pressable>;})}</View>;}
