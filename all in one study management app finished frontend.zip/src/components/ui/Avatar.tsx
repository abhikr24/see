import React from 'react';
import { View } from 'react-native';
import { Image } from 'expo-image';
import { usePreference } from '../../store/features';
import { useTheme } from '../../theme/tokens';
import { T } from './primitives';
export function Avatar({size=36}:{size?:number}){const t=useTheme();const photo=usePreference('avatar','');const name=usePreference('name','Student');const demoRemoved=usePreference('demo_removed','false');const source=photo?{uri:photo}:name==='Ayaan Khan'&&demoRemoved!=='true'?require('../../../assets/images/avatar.jpg'):null;return source?<Image accessibilityLabel={`${name}'s profile photo`} source={source} style={{width:size,height:size,borderRadius:size*.3}}/>:<View style={{width:size,height:size,borderRadius:size*.3,backgroundColor:t.blueSoft,alignItems:'center',justifyContent:'center'}}><T size={size*.36} weight="semibold" color={t.primary}>{name.split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase()}</T></View>;}
