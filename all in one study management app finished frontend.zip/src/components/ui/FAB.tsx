import React from 'react';
import { Pressable } from 'react-native';
import { Icon } from './Icon';
import { tokens } from '../../theme/tokens';
export function FAB({onPress,label='Add item'}:{onPress:()=>void;label?:string}){return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={{position:'absolute',right:24,bottom:24,width:54,height:54,borderRadius:18,backgroundColor:tokens.primary,alignItems:'center',justifyContent:'center',shadowColor:tokens.primary,shadowRadius:14,shadowOpacity:.3,shadowOffset:{width:0,height:5},elevation:5}}><Icon name="Plus" size={25} color="#FFFFFF"/></Pressable>;}
