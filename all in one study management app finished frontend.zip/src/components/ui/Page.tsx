import React,{ReactNode,useState} from 'react';
import { View,RefreshControl,useWindowDimensions } from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { T,s } from './primitives';
import { useTheme } from '../../theme/tokens';
import { reload } from '../../store/features';
export function Page({children,title,subtitle,action}:{children:ReactNode;title?:string;subtitle?:string;action?:ReactNode}){const t=useTheme();const {width}=useWindowDimensions();const [refreshing,setRefreshing]=useState(false);return <FlashList data={['content']} keyExtractor={i=>i} renderItem={()=> <View style={{width:'100%',maxWidth:1450,alignSelf:'center',padding:width>1100?30:20,paddingBottom:50}}>{title&&<View style={[s.between,{marginBottom:26,flexWrap:'wrap',gap:14}]}><View><T size={27} weight="bold" style={{letterSpacing:-.8}}>{title}</T>{subtitle&&<T size={13} color={t.muted} style={{marginTop:4}}>{subtitle}</T>}</View>{action}</View>}{children}</View>} refreshControl={<RefreshControl refreshing={refreshing} tintColor={t.primary} onRefresh={async()=>{setRefreshing(true);try{await reload();}finally{setRefreshing(false);}}}/>} showsVerticalScrollIndicator={false}/>;}
