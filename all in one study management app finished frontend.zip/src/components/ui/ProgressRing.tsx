import React from 'react';
import { View } from 'react-native';
import Svg,{Circle} from 'react-native-svg';
import { T } from './primitives';
import { useTheme } from '../../theme/tokens';
export function ProgressRing({progress,size=78,stroke=7,color='#2563EB',label,children}:{progress:number;size?:number;stroke?:number;color?:string;label?:string;children?:React.ReactNode}){const t=useTheme();const r=(size-stroke)/2;const c=2*Math.PI*r;return <View style={{width:size,height:size,alignItems:'center',justifyContent:'center'}}><Svg width={size} height={size} style={{position:'absolute'}}><Circle cx={size/2} cy={size/2} r={r} stroke={t.dark?'#2B3A52':'#EAF0FC'} strokeWidth={stroke} fill="none"/><Circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeDasharray={`${c} ${c}`} strokeDashoffset={c*(1-Math.min(1,Math.max(0,progress)))} strokeLinecap="round" rotation="-90" origin={`${size/2},${size/2}`}/></Svg>{children||<T size={size>100?28:18} weight="bold">{label??`${Math.round(progress*100)}%`}</T>}</View>;}
