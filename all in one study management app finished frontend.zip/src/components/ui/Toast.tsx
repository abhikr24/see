import React,{useEffect} from 'react';
import { View,Pressable } from 'react-native';
import { appStore } from '../../store/app';
import { T,IconButton,s } from './primitives';
import { Icon } from './Icon';
export function Toast(){const {toast,undo,notify}=appStore();useEffect(()=>{if(!toast)return;const id=setTimeout(()=>notify(''),6000);return()=>clearTimeout(id);},[toast]);if(!toast)return null;return <View accessibilityLiveRegion="polite" style={{position:'absolute',bottom:84,alignSelf:'center',maxWidth:'92%',backgroundColor:'#17243D',borderRadius:14,paddingLeft:18,paddingVertical:5,paddingRight:5,flexDirection:'row',alignItems:'center',gap:12,zIndex:1000,shadowOpacity:.15,shadowRadius:20}}><Icon name="CheckCircle2" color="#7DD7B5" size={18}/><T color="#FFFFFF" size={12} style={{flexShrink:1}}>{toast}</T>{undo&&<Pressable onPress={()=>{undo();notify('Restored.');}} style={{padding:10}}><T size={12} color="#8BB5FF" weight="bold">Undo</T></Pressable>}<IconButton name="X" color="#FFFFFF" onPress={()=>notify('')} label="Dismiss message"/></View>;}
