import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { Card,T,s } from '../../../components/ui/primitives';
import { ProgressRing } from '../../../components/ui/ProgressRing';
import { Icon } from '../../../components/ui/Icon';
import { useTheme } from '../../../theme/tokens';
import { useItems } from '../../../store/features';
import { dayKey } from '../../../lib/types/models';
export function FocusCard(){const t=useTheme();const tasks=useItems('tasks').filter(x=>x.due===dayKey());const done=tasks.filter(x=>x.done).length;const minutes=useItems('focus_sessions').filter(x=>x.date===dayKey()).reduce((sum,x)=>sum+(x.duration||0),0);return <Card onPress={()=>router.push('/analytics' as never)} style={{padding:22}}><View style={[s.between,{marginBottom:18}]}><T size={16} weight="semibold">Today’s focus</T><View style={{paddingHorizontal:7,paddingVertical:3,backgroundColor:'#EAF8F1',borderRadius:5}}><T size={9} color="#259975" weight="medium">You’ve got this</T></View></View><View style={[s.between,{marginBottom:20}]}><View><T size={28} weight="bold" style={{letterSpacing:-.8}}>{done}<T size={18} color="#A5AEBD"> / {tasks.length}</T></T><T size={11} color={t.muted} style={{marginTop:2}}>tasks completed</T><View style={[s.row,{gap:4,marginTop:9}]}><Icon name="Sparkles" size={12} color="#18A878"/><T size={10} color="#18A878">One step closer to your goals</T></View></View><ProgressRing size={83} stroke={7} progress={tasks.length?done/tasks.length:0}/></View><View style={[s.row,{borderTopWidth:1,borderColor:t.line,paddingTop:16,gap:8}]}><View style={{backgroundColor:t.blueSoft,padding:7,borderRadius:9}}><Icon name="Timer" size={17} color={t.primary}/></View><T size={11} color={t.muted} style={{flex:1}}>Time well spent</T><T size={13} weight="semibold">{Math.floor(minutes/60)>0?`${Math.floor(minutes/60)}h `:''}{minutes%60}m</T></View></Card>;}
