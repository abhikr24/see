import React from 'react';
import { View,useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { router } from 'expo-router';
import { T,Button,s } from '../../../components/ui/primitives';
import { Icon } from '../../../components/ui/Icon';
import { useTheme } from '../../../theme/tokens';
export function Hero(){const t=useTheme();const {width}=useWindowDimensions();const small=width<600;return <LinearGradient colors={t.dark?['#23385D','#1A2E50']:['#EAF2FF','#E9F0FF','#E4EEFF']} start={{x:0,y:0}} end={{x:1,y:1}} style={{borderRadius:22,minHeight:220,overflow:'hidden',padding:24,justifyContent:'center'}}><View style={{zIndex:2,maxWidth:small?'86%':'65%'}}><View style={[s.row,{gap:6,marginBottom:9}]}><Icon name="Sparkles" size={12} color={t.primary}/><T size={9} color={t.primary} weight="semibold" style={{letterSpacing:1.6}}>A LITTLE FOCUS. A LOT OF POSSIBILITY.</T></View><T size={small?25:28} weight="bold" color={t.dark?'#EAF2FF':'#18396E'} style={{lineHeight:34,letterSpacing:-1}}>Small steps today.{"\n"}Big possibilities tomorrow.</T><T size={11} color={t.dark?'#A5B8D6':'#6D81A4'} style={{marginTop:7,marginBottom:16}}>Your goals are closer than you think. Let’s get started.</T><Button title="Let’s focus" icon="Play" onPress={()=>router.push('/focus' as never)} small style={{alignSelf:'flex-start',paddingHorizontal:17,shadowColor:'#2563EB',shadowOpacity:.18,shadowOffset:{width:0,height:5},shadowRadius:10}}/></View><Image source={require('../../../../assets/images/study-illustration.svg')} contentFit="contain" style={{position:'absolute',width:small?220:310,height:230,right:small?-80:-24,bottom:-7,opacity:small?.4:1}}/></LinearGradient>;}
