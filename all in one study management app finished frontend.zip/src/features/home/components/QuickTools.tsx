import React from 'react';
import { View,Pressable,useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { T,Card } from '../../../components/ui/primitives';
import { Icon,IconName } from '../../../components/ui/Icon';
import { useTheme } from '../../../theme/tokens';
const tools:[string,IconName,string,string][]=[['Tasks','ListTodo','#11AD85','/tasks'],['Study','BookOpen','#269EAF','/study'],['Classes','CalendarDays','#8D66E7','/timetable'],['Notes','NotebookPen','#E4AC3E','/notes'],['Exams','ClipboardList','#ED7D72','/exams'],['Habits','Activity','#5488E8','/habits'],['Planner','Calendar','#8D73DE','/planner'],['More','MoreHorizontal','#78889D','/more']];
export function QuickTools(){const t=useTheme();const {width}=useWindowDimensions();return <Card style={{padding:width<600?13:18,flexDirection:'row',justifyContent:'space-between',gap:4,flexWrap:'wrap',borderRadius:18}}>{tools.map(([title,icon,color,path])=><Pressable key={title} onPress={()=>router.push(path as never)} accessibilityRole="button" style={({hovered}:any)=>({alignItems:'center',gap:9,width:width<500?'22%':'11%',paddingVertical:5,borderRadius:12,backgroundColor:hovered?t.soft:'transparent'})}><View style={{width:42,height:42,borderRadius:14,backgroundColor:color+'12',alignItems:'center',justifyContent:'center'}}><Icon name={icon} size={21} color={color}/></View><T size={10} color={t.muted} weight="medium">{title}</T></Pressable>)}</Card>;}
