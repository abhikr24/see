import { useEffect,useState } from 'react';
import { services } from '../../../lib/services/container';
export function useQuote(){const [quote,setQuote]=useState('You don’t have to be perfect.\nYou just have to keep going.');useEffect(()=>{let active=true;void services.business.content('quotes').then(rows=>{const body=rows[0]?.body;if(active&&typeof body==='string')setQuote(body);});return()=>{active=false;};},[]);return quote;}
