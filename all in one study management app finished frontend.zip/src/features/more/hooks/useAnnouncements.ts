import { useState,useEffect } from 'react';
import { services } from '../../../lib/services/container';
export function useAnnouncements(){const [items,setItems]=useState<Record<string,unknown>[]>([]);useEffect(()=>{void services.business.content('announcements').then(setItems);},[]);return items;}
