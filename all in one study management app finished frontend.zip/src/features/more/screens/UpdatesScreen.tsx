import React,{useEffect,useState} from 'react';
import { View } from 'react-native';
import { Page } from '../../../components/ui/Page';
import { T,Card,EmptyState,s } from '../../../components/ui/primitives';
import { Icon } from '../../../components/ui/Icon';
import { useItems } from '../../../store/features';
import { dayKey } from '../../../lib/types/models';
import { useTheme } from '../../../theme/tokens';
import { appStore } from '../../../store/app';
import { useAnnouncements } from '../hooks/useAnnouncements';
export default function UpdatesScreen(){const t=useTheme();const tasks=useItems('tasks').filter(x=>!x.done&&x.due&&x.due<=dayKey());const exams=useItems('exams').filter(x=>x.due&&x.due>=dayKey());const announcements=useAnnouncements();return <Page title="A few things to keep in mind." subtitle="Your study reminders and updates, without the noise."><View style={{gap:16}}>{tasks.map(task=><Card key={task.id} onPress={()=>appStore.getState().edit({table:'tasks',item:task})} style={{flexDirection:'row',gap:15}}><Icon name="Bell" color={t.primary}/><View style={{flex:1,gap:5}}><T weight="semibold">{task.title}</T><T size={12} color={t.muted}>{task.due!<dayKey()?'A little overdue. You can still take the next step.':'On your list for today.'}</T></View></Card>)}{exams.map(exam=><Card key={exam.id} onPress={()=>appStore.getState().edit({table:'exams',item:exam})} style={{flexDirection:'row',gap:15}}><Icon name="ClipboardList" color="#8B5CF6"/><View><T weight="semibold">{exam.title}</T><T size={12} color={t.muted}>Coming up on {exam.due}. A little preparation today helps.</T></View></Card>)}{announcements.map(a=><Card key={String(a.id)}><T weight="semibold">{String(a.title)}</T><T color={t.muted} style={{marginTop:9}}>{String(a.body)}</T></Card>)}{!tasks.length&&!exams.length&&!announcements.length&&<EmptyState title="You’re all caught up" description="No pending reminders. Enjoy the little bit of breathing room."/>}</View></Page>;}
