import React,{useEffect} from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { T,Button,s } from '../../../components/ui/primitives';
import { Icon } from '../../../components/ui/Icon';
import { usePreference,setPreference } from '../../../store/features';
export default function WelcomeScreen(){const guest=usePreference('guest','true');useEffect(()=>{if(guest==='false')router.replace('/' as never);},[guest]);return <LinearGradient colors={['#F4F8FF','#E9F0FF','#F5F7FB']} style={{flex:1,justifyContent:'center',alignItems:'center',padding:30}}><View style={{maxWidth:400,width:'100%',alignItems:'center',gap:19}}><View style={{width:85,height:85,borderRadius:26,backgroundColor:'#2563EB',alignItems:'center',justifyContent:'center',shadowColor:'#2563EB',shadowOpacity:.2,shadowRadius:24,shadowOffset:{width:0,height:10}}}><Icon name="GraduationCap" size={52} color="#FFF"/></View><T size={48} weight="bold" style={{letterSpacing:-2}}>Studifi.</T><T size={18} style={{textAlign:'center',maxWidth:270}}>Your Complete Student Companion</T><Image source={require('../../../../assets/images/study-illustration.svg')} style={{height:190,width:290}}/><View style={{width:'100%',gap:12}}><Button title="Get started" icon="ArrowRight" onPress={()=>router.push('/onboarding' as never)}/><Button title="Sign in" variant="secondary" onPress={()=>router.push('/auth' as never)}/><Button title="Explore the demo workspace" variant="ghost" onPress={()=>void setPreference('onboarding','preview').then(()=>router.replace('/' as never))}/></View><T size={11} color="#7C879C">Plan. Organize. Learn. Grow.</T></View></LinearGradient>;}
