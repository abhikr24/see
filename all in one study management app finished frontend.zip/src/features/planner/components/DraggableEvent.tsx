import React from 'react';
import { View,Pressable } from 'react-native';
import { Gesture,GestureDetector } from 'react-native-gesture-handler';
import Animated,{useSharedValue,useAnimatedStyle,withSpring,runOnJS} from 'react-native-reanimated';
import { Item } from '../../../lib/types/models';
import { saveItem } from '../../../store/features';
import { appStore } from '../../../store/app';
import { T,s } from '../../../components/ui/primitives';
import { Icon } from '../../../components/ui/Icon';
import { useClockFormat } from '../../shared/hooks/useClockFormat';
export const toMinutes=(time='09:00')=>{const [h,m]=time.split(':').map(Number);return h*60+m;};
export function DraggableEvent({item,color,overlap}:{item:Item;color:string;overlap:boolean}){const clock=useClockFormat();const y=useSharedValue(0);const active=useSharedValue(false);const save=(delta:number)=>{const minutes=Math.max(360,Math.min(1380,Math.round((toMinutes(item.time)+delta)/15)*15));const time=`${String(Math.floor(minutes/60)).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}`;void saveItem('planner_events',{...item,time}).then(()=>appStore.getState().notify(`Rescheduled to ${time}`));};const pan=Gesture.Pan().activateAfterLongPress(250).onStart(()=>{active.value=true;}).onUpdate(e=>{y.value=e.translationY;}).onEnd(e=>{runOnJS(save)(e.translationY);y.value=withSpring(0);active.value=false;});const animated=useAnimatedStyle(()=>({transform:[{translateY:y.value},{scale:withSpring(active.value?1.02:1)}],zIndex:active.value?100:1}));return <GestureDetector gesture={pan}><Animated.View style={[{marginVertical:7,borderRadius:14,backgroundColor:color+'12',borderLeftWidth:4,borderColor:color,padding:17},animated]}><Pressable onPress={()=>appStore.getState().edit({table:'planner_events',item})} style={[s.row,{gap:14}]}><View style={{flex:1,gap:5}}><T size={14} color={color} weight="semibold">{item.title}</T><T size={11} color="#7C879C">{clock(item.time)} · {item.duration||60} minutes{item.room?` · ${item.room}`:''}</T>{overlap&&<T size={10} color="#D47742">Overlaps another event. Tap to adjust.</T>}</View><Icon name="GripVertical" size={18} color={color}/></Pressable></Animated.View></GestureDetector>;}
