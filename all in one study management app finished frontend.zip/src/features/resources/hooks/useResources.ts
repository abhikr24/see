import { useState,useEffect } from 'react';
import { services } from '../../../lib/services/container';
import { bundledResources } from '../data/bundled';
import { reload } from '../../../store/features';
export function useResources(){const [resources,setResources]=useState(bundledResources);const [loading,setLoading]=useState(false);const [curated,setCurated]=useState<Record<string,unknown>[]>([]);useEffect(()=>{let active=true;if(services.business.enabled){setLoading(true);void services.business.content('content_flashcard_decks').then(rows=>{if(active)setCurated(rows);});void services.business.content('content_resources').then(rows=>{if(active&&rows.length)setResources(rows as unknown as typeof bundledResources);}).finally(()=>{if(active)setLoading(false);});}return()=>{active=false;};},[]);return {resources,loading,curated,async importDeck(id:string){const result=await services.importDeck(id);await reload();return result;}};}
