import { useState } from 'react';
import { services } from '../../../lib/services/container';
import { setPreference,reload } from '../../../store/features';
import { appStore } from '../../../store/app';
import { timerActions } from '../../../store/focus';
export function useAccount(){const [busy,setBusy]=useState(false);const [message,setMessage]=useState('');const [checks,setChecks]=useState<{table:string;ok:boolean;message:string}[]>([]);return {busy,message,checks,cloud:services.business.reason,enabled:services.business.enabled,
 async authenticate(mode:string,email:string,password:string){setBusy(true);setMessage('');try{const r=await (mode==='Sign up'?services.business.signUp(email,password):mode==='Reset password'?services.business.resetPassword(email):services.business.signIn(email,password));setMessage(r.message);if(r.ok&&mode==='Sign in'){await setPreference('guest','false');await setPreference('email',email);void services.flush();}return r.ok;}finally{setBusy(false);}},
 async signOut(){setBusy(true);try{const r=await services.business.signOut();if(r.ok){await setPreference('guest','true');await setPreference('email','');}appStore.getState().notify(r.message);}finally{setBusy(false);}},
 async check(){setBusy(true);setChecks(await services.business.connectionCheck());setBusy(false);},
 async feedback(message:string){await services.queue('feedback',{message,category:'support'});appStore.getState().notify(services.business.enabled?'Feedback saved. It will be sent when your account is online.':'Feedback saved locally. It will send after cloud setup and sign-in.');},
 async consent(){await services.consent();await reload();},
 async clearDemo(){await services.content.clearDemo();await reload();appStore.getState().notify('Demo content removed. This space is all yours.');},
 async reset(){await timerActions.reset();await services.content.reset();await reload();appStore.getState().notify('Local content reset. A fresh start.');}
};}
