import { useState } from 'react';
import { Platform } from 'react-native';
import * as Clipboard from 'expo-clipboard';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import * as FileSystem from 'expo-file-system';
import * as Print from 'expo-print';
import { services } from '../../../lib/services/container';
import { reload } from '../../../store/features';
import { appStore } from '../../../store/app';
export function useBackup(){const [text,setText]=useState('');const [busy,setBusy]=useState(false);const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]||c));return {text,setText,busy,
 async export(format:'json'|'md'|'pdf'){setBusy(true);try{const data=await services.content.exportData();const content=format==='json'?JSON.stringify({app:'Studifi',version:1,exported_at:new Date().toISOString(),data},null,2):data.notes.map(n=>`# ${n.title}\n\n${n.body||''}`).join('\n\n---\n\n');if(format==='pdf'){const html=`<html><body style="font-family:sans-serif;padding:36px"><h1>Studifi · Your notes</h1>${data.notes.map(n=>`<h2>${escape(n.title)}</h2><pre style="white-space:pre-wrap;font-family:sans-serif;line-height:1.6">${escape(n.body||'')}</pre>`).join('')}</body></html>`;if(Platform.OS==='web')await Print.printAsync({html});else{const file=await Print.printToFileAsync({html});await Sharing.shareAsync(file.uri,{mimeType:'application/pdf'});}return;}setText(content);if(Platform.OS!=='web'){const file=new FileSystem.File(FileSystem.Paths.cache,`studifi-backup.${format}`);file.write(content);await Sharing.shareAsync(file.uri,{mimeType:format==='json'?'application/json':'text/markdown'});}else{await Clipboard.setStringAsync(content);appStore.getState().notify(`${format==='json'?'JSON backup':'Markdown notes'} copied. Paste into a file to keep it safe.`);}}catch{appStore.getState().notify('Export could not complete. Your content is safe; try again.');}finally{setBusy(false);}},
 async copy(){try{await Clipboard.setStringAsync(text);appStore.getState().notify('Copied to clipboard. Keep your backup somewhere safe.');}catch{appStore.getState().notify('Select and copy the text below.');}},
 async importText(value:string){setBusy(true);try{await services.content.importData(JSON.parse(value));await reload();appStore.getState().notify('Backup imported. Welcome back to your workspace.');return true;}catch(e){appStore.getState().notify(e instanceof Error?e.message:'Invalid backup.');return false;}finally{setBusy(false);}},
 async choose(){try{const result=await DocumentPicker.getDocumentAsync({type:['application/json','text/plain'],copyToCacheDirectory:true});if(result.canceled)return;const asset=result.assets[0];let value:string;if(Platform.OS==='web'){value=await asset.file!.text();}else value=await new FileSystem.File(asset.uri).text();setText(value);}catch{appStore.getState().notify('Could not read this file. You can paste a JSON backup instead.');}}
};}
