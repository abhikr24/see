import { Platform } from 'react-native';
import { requestReminders } from '../../../lib/notifications/permissions';
import { cancelReminder } from '../../../lib/notifications/schedule';
import { setPreference,featureStores } from '../../../store/features';
import { services } from '../../../lib/services/container';
import { appStore } from '../../../store/app';
export function useReminders(){return {async enable(){const granted=await requestReminders();await setPreference('notifications',String(granted));appStore.getState().notify(granted?'Study reminders enabled.':Platform.OS==='web'?'Native reminders are available in the iOS and Android app.':'Permission was not granted. You can change this in device settings.');if(granted)for(const table of ['tasks','exams','planner_events'] as const)for(const item of featureStores[table].getState().items)if(item.reminder)await services.save(table,item);},async disable(){await setPreference('notifications','false');for(const table of ['tasks','exams','planner_events'] as const)for(const item of featureStores[table].getState().items)await cancelReminder(item.notification_id);},async reschedule(){for(const table of ['tasks','exams','planner_events'] as const)for(const item of featureStores[table].getState().items)if(item.reminder)await services.save(table,item);}};}
