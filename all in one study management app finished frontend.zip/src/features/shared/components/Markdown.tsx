import React from 'react';
import { View } from 'react-native';
import { T } from '../../../components/ui/primitives';
import { useTheme } from '../../../theme/tokens';
export function Markdown({text}:{text:string}){const t=useTheme();return <View style={{gap:10}}>{text.split('\n').map((line,i)=>{const heading=line.startsWith('#');const bullet=/^[-*] /.test(line);const check=/^- \[[ x]\]/.test(line);return <T key={i} size={heading?18:14} weight={heading?'semibold':'regular'} style={{lineHeight:24}}>{check?(line.includes('[x]')?'☑ ':'☐ ')+line.slice(6):bullet?'• ':''}{(check?'':line.replace(/^#{1,3} |^[-*] /,'')).split(/(\*\*.*?\*\*|\*.*?\*|==.*?==)/g).map((part,j)=>part.startsWith('**')?<T key={j} weight="bold">{part.slice(2,-2)}</T>:part.startsWith('*')?<T key={j} style={{fontStyle:'italic'}}>{part.slice(1,-1)}</T>:part.startsWith('==')?<T key={j} style={{backgroundColor:'#FFF0A8',color:'#4C432B'}}>{part.slice(2,-2)}</T>:part)}</T>;})}</View>;}
