import { useEffect } from 'react';
import { AppState } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import { services } from '../../../lib/services/container';
import { hydrate } from '../../../store/features';
import { appStore } from '../../../store/app';
export function useBootstrap(){
 const ready=appStore(s=>s.ready);const error=appStore(s=>s.error);
 const boot=async()=>{appStore.getState().setError('');try{hydrate(await services.bootstrap());appStore.getState().setReady(true);void services.flush();}catch(e){appStore.getState().setError(e instanceof Error?e.message:'Unable to open local storage.');}};
 useEffect(()=>{void boot();const listener=AppState.addEventListener('change',s=>{if(s==='active')void services.flush();});const unsubscribe=NetInfo.addEventListener(s=>{if(s.isConnected)void services.flush();});return()=>{listener.remove();unsubscribe();};},[]);
 return {ready,error,retry:boot};
}
