import { usePreference } from '../../../store/features';
export function useClockFormat(){const format=usePreference('time_format','12-hour');return (time?:string)=>{if(!time)return '';if(format==='24-hour')return time;const [h,m]=time.split(':').map(Number);return `${h%12||12}:${String(m||0).padStart(2,'0')} ${h>=12?'PM':'AM'}`;};}
