import React from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { FlashList } from '@shopify/flash-list';
import { Page } from '../../../components/ui/Page';
import { Card,T,Button,SectionHeading,EmptyState,s } from '../../../components/ui/primitives';
import { Icon } from '../../../components/ui/Icon';
import { SubjectCard } from '../components/SubjectCard';
import { useItems } from '../../../store/features';
import { appStore } from '../../../store/app';
import { useTheme } from '../../../theme/tokens';
export default function StudyScreen(){const t=useTheme();const subjects=useItems('subjects');const chapters=useItems('chapters');return <Page title="Your next chapter starts here." subtitle="All your subjects. One calm place to learn." action={<Button title="Add subject" icon="Plus" onPress={()=>appStore.getState().edit({table:'subjects'})}/>}><Card style={{flexDirection:'row',alignItems:'center',gap:18,marginBottom:28,backgroundColor:t.blueSoft,borderColor:'transparent'}}><View style={{padding:13,backgroundColor:t.card,borderRadius:14}}><Icon name="BookMarked" color={t.primary} size={26}/></View><View style={{flex:1}}><T size={17} weight="semibold">A little learning adds up.</T><T color={t.muted} size={12} style={{marginTop:4}}>{chapters.filter(c=>c.done).length} of {chapters.length} chapters covered across {subjects.length} subjects.</T></View><Button small title="Explore resources" variant="secondary" onPress={()=>router.push('/resources' as never)}/></Card><SectionHeading title="My subjects" subtitle="Keep your syllabus, notes, and tasks together"/>{subjects.length?<View style={[s.wrap,{gap:18}]}>{subjects.map(subject=><View key={subject.id} style={{flexGrow:1,flexBasis:270,maxWidth:450}}><SubjectCard subject={subject}/></View>)}</View>:<EmptyState title="Make space for learning" description="Add your subjects, then break each one into chapters." action="Add your first subject" onPress={()=>appStore.getState().edit({table:'subjects'})}/>}</Page>;}
