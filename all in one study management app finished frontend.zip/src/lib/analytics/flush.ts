import { services } from '../services/container';
export const flush = ()=>services.flush();
