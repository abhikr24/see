import { services } from '../services/container';
export const pendingEvents = ()=>services.content.all('outbox');
