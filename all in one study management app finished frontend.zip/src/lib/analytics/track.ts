import { services } from '../services/container';
export const track = (counts:Record<string,number>)=>services.track(counts);
