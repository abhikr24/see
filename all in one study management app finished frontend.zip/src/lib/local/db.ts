import * as SQLite from 'expo-sqlite';
import { migrate } from './migrations';
let promise: Promise<SQLite.SQLiteDatabase> | undefined;
export function database() {
  if (!promise) promise = open().catch(e => { promise = undefined; throw e; });
  return promise;
}
async function open() {
  const db = await SQLite.openDatabaseAsync('studifi-v1.db');
  await db.execAsync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  await migrate(db);
  return db;
}
