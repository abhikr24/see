import type { SQLiteDatabase } from 'expo-sqlite';
import { TABLES } from '../types/models';
export const SCHEMA_VERSION=1;
export async function migrate(db:SQLiteDatabase){
 const result=await db.getFirstAsync<{user_version:number}>('PRAGMA user_version');
 if((result?.user_version||0)>=SCHEMA_VERSION)return;
 await db.withTransactionAsync(async()=>{
  for(const table of TABLES)await db.execAsync(`CREATE TABLE IF NOT EXISTS ${table} (
    id TEXT PRIMARY KEY NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    deleted_at TEXT, sync_state TEXT NOT NULL DEFAULT 'local', data TEXT NOT NULL CHECK(json_valid(data))
  ); CREATE INDEX IF NOT EXISTS idx_${table}_active ON ${table}(deleted_at,updated_at);`);
  await db.execAsync(`PRAGMA user_version = ${SCHEMA_VERSION}`);
 });
}
