import { randomUUID } from 'expo-crypto';
import { database } from './db';
import { ContentRepository } from '../types/repositories';
import { Item, NewItem, Table, TABLES } from '../types/models';
type Stored = { id: string; created_at: string; updated_at: string; deleted_at: string|null; data: string };
const assertTable = (table: Table) => { if (!TABLES.includes(table)) throw new Error('Unknown content type'); return table; };
export const localRepository: ContentRepository = {
  async init() { await database(); },
  async all(table, includeDeleted = false) {
    const rows = await (await database()).getAllAsync<Stored>(`SELECT * FROM ${assertTable(table)} ${includeDeleted ? '' : 'WHERE deleted_at IS NULL'} ORDER BY created_at ASC`);
    return rows.map(r => ({ ...JSON.parse(r.data), id:r.id, created_at:r.created_at, updated_at:r.updated_at, deleted_at:r.deleted_at, sync_state:'local' } as Item));
  },
  async save(table, data: NewItem) {
    const now = new Date().toISOString();
    const item: Item = { ...data, id: data.id || randomUUID(), title: data.title, created_at: data.created_at || now, updated_at: now, deleted_at: data.deleted_at || null, sync_state:'local' };
    await (await database()).runAsync(`INSERT INTO ${assertTable(table)} (id,created_at,updated_at,deleted_at,sync_state,data) VALUES (?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated_at=excluded.updated_at,deleted_at=excluded.deleted_at,data=excluded.data`, item.id,item.created_at,now,item.deleted_at,'local',JSON.stringify(item));
    return item;
  },
  async remove(table,id) { await (await database()).runAsync(`UPDATE ${assertTable(table)} SET deleted_at=?, updated_at=? WHERE id=?`,new Date().toISOString(),new Date().toISOString(),id); },
  async restore(table,id) { await (await database()).runAsync(`UPDATE ${assertTable(table)} SET deleted_at=NULL, updated_at=? WHERE id=?`,new Date().toISOString(),id); },
  async setting(key) { const rows = await this.all('settings'); return rows.find(r=>r.title===key)?.value ?? null; },
  async setSetting(key,value) { const existing = (await this.all('settings')).find(r=>r.title===key); await this.save('settings',{...existing,title:key,value}); },
  async clearDemo() { for (const table of TABLES) { if (table==='settings') continue; for (const row of await this.all(table)) if(row.demo) await this.remove(table,row.id); } await this.setSetting('demo_removed','true'); },
  async exportData() { const result: Record<string,Item[]> = {}; for(const table of TABLES) if(table!=='outbox') result[table]=await this.all(table); return result; },
  async importData(input) {
    if (!input || typeof input!=='object') throw new Error('Choose a valid Studifi JSON backup.');
    const data = input as Record<string,unknown>; const values = (data.data || data) as Record<string,unknown>;
    for(const [table,rows] of Object.entries(values)) {
      if(!TABLES.includes(table as Table) || table==='outbox' || !Array.isArray(rows)) throw new Error('Unsupported backup format.');
      for(const row of rows) if(typeof row.id!=='string'||typeof row.title!=='string'||!row.created_at) throw new Error('Backup contains invalid records.');
    }
    await (await database()).withTransactionAsync(async()=>{ for(const [table,rows] of Object.entries(values)) for(const row of rows as Item[]) await this.save(table as Table,row); });
  },
  async reset() { const db=await database(); await db.withTransactionAsync(async()=>{for(const table of TABLES) await db.execAsync(`DELETE FROM ${table}`);}); await this.setSetting('seeded','true'); }
};
