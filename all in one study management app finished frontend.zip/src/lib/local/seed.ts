import { ContentRepository } from '../types/repositories';
import { offsetDay, dayKey, NewItem, Table } from '../types/models';
import { database } from './db';
export async function seedDemo(repo: ContentRepository) {
  if(await repo.setting('seeded')) return;
  await (await database()).withTransactionAsync(async()=>{
  const add = (table: Table,value: NewItem)=>repo.save(table,{...value,demo:true});
  const specs = [['Mathematics','#12A477','Sigma'],['Physics','#8B5CF6','Atom'],['Chemistry','#3B82F6','FlaskConical'],['Biology','#0F9F99','Leaf'],['History','#F08A45','Landmark'],['English','#6366F1','BookOpen']];
  const subjects = [];
  for(const [title,color,icon] of specs) subjects.push(await add('subjects',{title,color,icon}));
  const chapters = [['Sets & relations','Linear equations','Differentiation','Integrals'],['Units & measurements','Laws of motion','Work, energy & power','Gravitation'],['Atomic structure','Chemical bonding','Thermodynamics','Equilibrium'],['The living world','Cell structure','Biomolecules','Plant physiology'],['The Renaissance','Industrial revolution','World wars','The modern world'],['Poetry','Short stories','Grammar','Essay writing']];
  for(let s=0;s<subjects.length;s++) for(let c=0;c<chapters[s].length;c++) await add('chapters',{title:chapters[s][c],subject_id:subjects[s].id,done:c<(s===0?3:2)});
  const taskTitles=['Complete calculus assignment','Revise laws of motion','Read chapter 4: Cell structure','Practice organic chemistry','Outline English essay'];
  for(let i=0;i<taskTitles.length;i++) await add('tasks',{title:taskTitles[i],subject_id:subjects[[0,1,3,2,5][i]].id,due:dayKey(),time:['10:00','11:30','14:00','16:30','18:00'][i],priority:i===0?'High':i===1?'Medium':'Low',done:i>2,completed_at:i>2?new Date().toISOString():undefined});
  await add('tasks',{title:'Prepare history presentation',subject_id:subjects[4].id,due:offsetDay(2),priority:'Medium',done:false});
  for(const [i,time,title,room] of [[0,'09:00','Mathematics','Room 204'],[1,'11:00','Physics lab','Science block'],[5,'14:00','English literature','Room 108']] as const) await add('planner_events',{title,subject_id:subjects[i].id,date:dayKey(),time,duration:60,room,kind:'Class'});
  await add('exams',{title:'Mathematics midterm',subject_id:subjects[0].id,due:offsetDay(5),time:'09:00',room:'Hall A',chapter_ids:[]});
  await add('exams',{title:'Physics unit test',subject_id:subjects[1].id,due:offsetDay(9),time:'10:00',room:'Room 204'});
  const noteData=[['Integration essentials','## The power rule\nFor n ≠ −1, ∫xⁿ dx = xⁿ⁺¹ / (n + 1) + C.\n\n**Remember:** always include the constant of integration.\n\n- Identify the function\n- Apply the correct rule\n- Check by differentiating'],['Newton’s laws of motion','## Three laws, one foundation\n1. An object stays at rest or in uniform motion unless acted on by a force.\n2. Force equals mass times acceleration: F = ma.\n3. Every action has an equal and opposite reaction.'],['Cell structure & function','## The building blocks of life\nThe nucleus stores genetic material. Mitochondria release energy through respiration.\n\n- Cell membrane: controls transport\n- Ribosomes: protein synthesis\n- Cytoplasm: site of chemical reactions']];
  for(let i=0;i<noteData.length;i++) await add('notes',{title:noteData[i][0],body:noteData[i][1],subject_id:subjects[[0,1,3][i]].id,pinned:i===0});
  const habits=[];
  for(const [title,icon,color] of [['Read for 20 minutes','BookOpen','#8B5CF6'],['Drink enough water','Droplets','#3B82F6'],['Review today’s notes','NotebookPen','#12A477']]) habits.push(await add('habits',{title,icon,color,days:[0,1,2,3,4,5,6],target:7}));
  for(let d=-4;d<=0;d++) for(let h=0;h<habits.length;h++) if(d<0||h===1) await add('habit_entries',{title:'Completed',parent_id:habits[h].id,date:offsetDay(d),done:true});
  for(let d=-6;d<=0;d++) { await add('focus_sessions',{title:'Focus session',duration:[25,50,75,25,100,50,90][d+6],subject_id:subjects[(d+6)%3].id,date:offsetDay(d)}); }
  const goal=await add('goals',{title:'Build a consistent study routine',due:offsetDay(30)});
  for(const [title,done] of [['Organize my subjects',true],['Complete my first focus session',true],['Review notes every week',false],['Finish the term syllabus',false]] as const) await add('goal_steps',{title,parent_id:goal.id,done});
  const deck=await add('flashcard_decks',{title:'Physics fundamentals',subject_id:subjects[1].id});
  for(const [title,answer] of [['What is Newton’s second law?','F = ma. The net force equals mass multiplied by acceleration.'],['What is the SI unit of energy?','The joule (J). One joule equals one newton-metre.'],['How do you calculate kinetic energy?','KE = ½mv², where m is mass and v is velocity.']]) await add('flashcards',{title,answer,parent_id:deck.id,interval:0,due:dayKey()});
  await repo.setSetting('name','Ayaan Khan'); await repo.setSetting('seeded','true'); await repo.setSetting('guest','true');
  });
}
