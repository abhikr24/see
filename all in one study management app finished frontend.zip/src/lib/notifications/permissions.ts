import { Platform } from 'react-native';
export async function requestReminders():Promise<boolean> {
  if(Platform.OS==='web')return false;
  try {const Notifications=await import('expo-notifications');
    if(Platform.OS==='android')await Notifications.setNotificationChannelAsync('study',{name:'Study reminders',importance:Notifications.AndroidImportance.DEFAULT});
    const current=await Notifications.getPermissionsAsync();
    return current.granted || (await Notifications.requestPermissionsAsync()).granted;
  }catch{return false;}
}
