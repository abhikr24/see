import { Platform } from 'react-native';
export async function scheduleReminder(title:string,date:Date):Promise<string|undefined> {
  if(Platform.OS==='web'||date.getTime()<=Date.now())return undefined;
  try{const N=await import('expo-notifications');const p=await N.getPermissionsAsync();if(!p.granted)return undefined;return await N.scheduleNotificationAsync({content:{title:'Studifi · A little nudge',body:title,sound:true},trigger:{type:N.SchedulableTriggerInputTypes.DATE,date,channelId:'study'}});}catch{return undefined;}
}
export async function cancelReminder(id?:string){if(!id||Platform.OS==='web')return;try{await (await import('expo-notifications')).cancelScheduledNotificationAsync(id);}catch{}}
