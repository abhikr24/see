import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { remoteConfig, remoteEnabled } from './config';
const authStorage = {
  getItem: (key:string) => Platform.OS==='web'?AsyncStorage.getItem(key):SecureStore.getItemAsync(key),
  setItem: (key:string,value:string) => Platform.OS==='web'?AsyncStorage.setItem(key,value):SecureStore.setItemAsync(key,value),
  removeItem: (key:string) => Platform.OS==='web'?AsyncStorage.removeItem(key):SecureStore.deleteItemAsync(key)
};
export const client = remoteEnabled ? createClient(remoteConfig.url,remoteConfig.key, {
  auth:{storage:authStorage,persistSession:true,autoRefreshToken:true,detectSessionInUrl:false},
  global:{fetch:async(input,init)=>{const controller=new AbortController();const t=setTimeout(()=>controller.abort(),7000);try{return await fetch(input,{...init,signal:controller.signal});}finally{clearTimeout(t);}}}
}) : null;
