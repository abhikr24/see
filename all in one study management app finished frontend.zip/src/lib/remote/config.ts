const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.trim();
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY?.trim();
function isPublicKey(value?:string){
 if(!value)return false;
 if(value.startsWith('sb_publishable_'))return value.length>24;
 if(!value.startsWith('eyJ'))return false;
 try{const input=value.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';let bits=0,buffer=0,output='';for(const char of input){if(char==='=')break;const n=alphabet.indexOf(char);if(n<0)return false;buffer=(buffer<<6)|n;bits+=6;if(bits>=8){bits-=8;output+=String.fromCharCode((buffer>>bits)&255);}}return JSON.parse(output).role==='anon';}catch{return false;}
}
const validUrl = !!url && /^https:\/\/[a-z0-9.-]+\.supabase\.co$/i.test(url);
export const remoteEnabled = validUrl && isPublicKey(key);
export const remoteReason = remoteEnabled ? 'Cloud: configured' : !url&&!key?'Cloud: not configured':'Cloud: invalid public configuration';
export const remoteConfig = { url: remoteEnabled?url!:'', key: remoteEnabled?key! : '' };
