import { client } from './client';
import { remoteEnabled,remoteReason } from './config';
import { BusinessRepository, REMOTE_TABLES, RemoteResult } from '../types/repositories';
const offline = {ok:false,message:'Cloud is not configured. You can use every study tool as a guest.'};
async function auth(action:()=>Promise<{error: {message:string}|null}>,success:string):Promise<RemoteResult> {
  try { const result=await action(); return {ok:!result.error,message:result.error?.message||success}; } catch {return {ok:false,message:'Unable to connect. Your local work is safe. Try again when online.'};}
}
export const businessRepository:BusinessRepository = {
  enabled:remoteEnabled,reason:remoteReason,
  async signIn(email,password){if(!client)return offline;return auth(()=>client!.auth.signInWithPassword({email,password}),'Signed in successfully.');},
  async signUp(email,password){if(!client)return offline;return auth(()=>client!.auth.signUp({email,password}),'Account created. Check your email to confirm your account, then sign in.');},
  async resetPassword(email){if(!client)return offline;return auth(()=>client!.auth.resetPasswordForEmail(email,{redirectTo:'studifi://auth'}),'Check your email for password reset instructions.');},
  async signOut(){if(!client)return {ok:true,message:'You are now using guest mode.'};return auth(()=>client!.auth.signOut(),'Signed out. Local content stays on this device.');},
  async connectionCheck(){return Promise.all(REMOTE_TABLES.map(async table=>{if(!client)return {table,ok:false,message:remoteReason};try{const r=await client.from(table).select('id',{head:true,count:'exact'}).limit(1);return {table,ok:!r.error,message:r.error?.message||'Reachable · RLS enabled by schema'};}catch{return {table,ok:false,message:'Connection timed out'};}}));},
  async content(table){if(!client)return [];try{const {data,error}=await client.from(table).select('*').limit(100);return error?[]:data||[];}catch{return [];}},
  async send(kind,payload){if(!client)return false;try{const {data:{session}}=await client.auth.getSession();if(!session)return false;const {error}=await client.from(kind).upsert({...payload,user_id:session.user.id},{onConflict:'id'});return !error;}catch{return false;}}
};
