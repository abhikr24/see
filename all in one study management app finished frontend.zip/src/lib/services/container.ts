import { localRepository } from '../local/repositories';
import { seedDemo } from '../local/seed';
import { businessRepository } from '../remote/repositories';
import { Item, NewItem, Table, TABLES, dayKey } from '../types/models';
import { randomUUID } from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { cancelReminder,scheduleReminder } from '../notifications/schedule';
let flushing=false;
export const services = {
  content:localRepository, business:businessRepository,
  async bootstrap(){await localRepository.init();await seedDemo(localRepository);let id=await localRepository.setting('anonymous_id');if(!id){id=randomUUID();await localRepository.setSetting('anonymous_id',id);}if(Platform.OS!=='web')await SecureStore.setItemAsync('studifi-anonymous-id',id);return this.load();},
  async load(){const pairs=await Promise.all(TABLES.map(async t=>[t,await localRepository.all(t)] as const));return Object.fromEntries(pairs) as Record<Table,Item[]>;},
  async save(table:Table,data:NewItem):Promise<Item>{
    const previous=data.id?(await localRepository.all(table)).find(i=>i.id===data.id):undefined;
    const completed=table==='tasks' && data.done && !previous?.done;
    const item=await localRepository.save(table,completed?{...data,completed_at:new Date().toISOString()}:data);
    if(table==='tasks'||table==='exams'||table==='planner_events'){
      await cancelReminder(item.notification_id);
      if(item.reminder && !item.done && await localRepository.setting('notifications')==='true'){const lead=Number(await localRepository.setting('lead_time')||'15');const when=new Date(`${item.due||item.date}T${item.time||'09:00'}:00`);when.setMinutes(when.getMinutes()-lead);const id=await scheduleReminder(item.title,when);if(id)await localRepository.save(table,{...item,notification_id:id});}
    }
    if(table==='tasks'){const linked=(await localRepository.all('goal_steps')).filter(s=>s.value===item.id);for(const step of linked)if(step.parent_id!==item.goal_id)await localRepository.remove('goal_steps',step.id);if(item.goal_id){const step=linked.find(s=>s.parent_id===item.goal_id);await localRepository.save('goal_steps',{...step,title:item.title,parent_id:item.goal_id,value:item.id,kind:'task',done:!!item.done});}}
    if(table==='goal_steps'&&item.kind==='task'&&item.value){const task=(await localRepository.all('tasks')).find(task=>task.id===item.value);if(task&&task.done!==item.done)await this.save('tasks',{...task,done:!!item.done});}
    if(completed){await this.track({tasks_completed:1});if(item.repeat==='Daily'||item.repeat==='Weekly'){const due=new Date((item.due||dayKey())+'T12:00:00');due.setDate(due.getDate()+(item.repeat==='Daily'?1:7));await this.save('tasks',{...item,id:undefined,created_at:undefined,title:item.title,due:dayKey(due),done:false,completed_at:undefined,notification_id:undefined});}}
    if(table==='notes'&&!previous)await this.track({notes_created:1});
    return item;
  },
  async importDeck(id:string):Promise<string|null>{const existing=(await localRepository.all('flashcard_decks')).find(d=>d.value===id);if(existing)return existing.id;const [decks,cards]=await Promise.all([businessRepository.content('content_flashcard_decks'),businessRepository.content('content_flashcards')]);const deck=decks.find(d=>d.id===id);if(!deck)return null;const subject=(await localRepository.all('subjects')).find(s=>s.title===deck.subject);const created=await localRepository.save('flashcard_decks',{title:String(deck.title),value:id,subject_id:subject?.id});for(const card of cards.filter(c=>c.deck_id===id))await localRepository.save('flashcards',{title:String(card.question),answer:String(card.answer),parent_id:created.id,due:dayKey(),interval:0});return created.id;},
  async remove(table:Table,id:string){const item=(await localRepository.all(table)).find(i=>i.id===id);await cancelReminder(item?.notification_id);await localRepository.remove(table,id);},
  async restore(table:Table,id:string){await localRepository.restore(table,id);const item=(await localRepository.all(table)).find(i=>i.id===id);if(item?.reminder)await this.save(table,item);},
  async track(counts:Record<string,number>){const safe=Object.fromEntries(Object.entries(counts).filter(([k,v])=>['tasks_completed','focus_minutes','notes_created','sessions_completed'].includes(k)&&Number.isFinite(v)));if(!Object.keys(safe).length)return;await localRepository.save('outbox',{title:'events',body:JSON.stringify({metrics:safe,anonymous_id:await localRepository.setting('anonymous_id')})});},
  async queue(kind:'feedback'|'consents',payload:Record<string,unknown>){await localRepository.save('outbox',{title:kind,body:JSON.stringify(payload)});void this.flush();},
  async flush(){if(flushing||!businessRepository.enabled)return;flushing=true;try{for(const item of (await localRepository.all('outbox')).slice(0,30)){if(!['events','feedback','consents'].includes(item.title))continue;if(item.title==='events'&&!(await localRepository.setting('consent')))continue;const ok=await businessRepository.send(item.title as 'events'|'feedback'|'consents',{id:item.id,...JSON.parse(item.body||'{}')});if(ok)await localRepository.remove('outbox',item.id);else break;}}finally{flushing=false;}},
  async consent(){const accepted_at=new Date().toISOString();await localRepository.setSetting('consent',accepted_at);await this.queue('consents',{doc:'privacy',version:'1.0',accepted_at});}
};
