export const TABLES = ['subjects','chapters','tasks','subtasks','notes','note_attachments','planner_events','exams','habits','habit_entries','goals','goal_steps','focus_sessions','flashcard_decks','flashcards','settings','drafts','outbox'] as const;
export type Table = typeof TABLES[number];
export interface BaseRow { id: string; created_at: string; updated_at: string; deleted_at: string | null; sync_state: 'local'; demo?: boolean }
export interface Item extends BaseRow {
  title: string; subject_id?: string; parent_id?: string; body?: string; color?: string; icon?: string;
  done?: boolean; completed_at?: string; due?: string; time?: string; duration?: number; priority?: string;
  repeat?: string; reminder?: boolean; pinned?: boolean; room?: string; result?: number; total?: number;
  target?: number; days?: number[]; date?: string; answer?: string; interval?: number; ease?: number;
  value?: string; uri?: string; end_at?: number; paused?: number; kind?: string; attended?: boolean;
  credits?: number; chapter_ids?: string[]; notification_id?: string; goal_id?: string;
}
export interface Subject extends Item { color: string; icon: string }
export interface Chapter extends Item { subject_id: string; done: boolean }
export interface Task extends Item { done: boolean; priority: string }
export interface Subtask extends Item { parent_id: string; done: boolean }
export interface Note extends Item { body: string }
export interface NoteAttachment extends Item { parent_id: string; uri: string }
export interface PlannerEvent extends Item { date: string; time: string; duration: number }
export interface Exam extends Item { due: string }
export interface Habit extends Item { days: number[] }
export interface HabitEntry extends Item { parent_id: string; date: string; done: boolean }
export interface Goal extends Item { due: string }
export interface GoalStep extends Item { parent_id: string; done: boolean }
export interface FocusSession extends Item { duration: number; date: string }
export interface FlashcardDeck extends Item { subject_id: string }
export interface Flashcard extends Item { parent_id: string; answer: string }
export interface Settings extends Item { value: string }
export interface Draft extends Item { body: string }
export interface OutboxEvent extends Item { body: string }
export type NewItem = Partial<Item> & { title: string };
export const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
export const offsetDay = (n: number) => { const d = new Date(); d.setDate(d.getDate()+n); return dayKey(d); };
