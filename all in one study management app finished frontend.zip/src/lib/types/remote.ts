export interface BusinessRow {id:string;created_at:string;updated_at:string}
export interface Profile extends BusinessRow {display_name:string;email:string|null}
export interface Subscription extends BusinessRow {user_id:string;plan:'free'|'plus';status:string;expires_at:string|null}
export interface AppConfig extends BusinessRow {key:string;value:Record<string,unknown>}
export interface FeatureFlag extends BusinessRow {key:string;enabled:boolean}
export interface ContentResource extends BusinessRow {slug:string;title:string;description:string;category:string;url?:string;body?:string;icon:string;color:string}
export interface ContentFlashcardDeck extends BusinessRow {slug:string;title:string;subject:string}
export interface ContentFlashcard extends BusinessRow {deck_id:string;question:string;answer:string;position:number}
export interface Quote extends BusinessRow {slug:string;body:string;attribution:string}
export interface Announcement extends BusinessRow {slug:string;title:string;body:string;published_at:string;expires_at:string|null}
export interface MetricsEvent extends BusinessRow {user_id:string;anonymous_id:string;metrics:Partial<Record<'tasks_completed'|'focus_minutes'|'notes_created'|'sessions_completed',number>>}
export interface NotificationToken extends BusinessRow {user_id:string;token:string;platform:'ios'|'android'}
export interface Feedback extends BusinessRow {user_id:string;message:string;category:string}
export interface Consent extends BusinessRow {user_id:string;doc:string;version:string;accepted_at:string}
