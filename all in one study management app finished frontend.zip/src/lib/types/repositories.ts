import { Item, NewItem, Table } from './models';
export interface ContentRepository {
  init(): Promise<void>; all(table: Table, includeDeleted?: boolean): Promise<Item[]>;
  save(table: Table, value: NewItem): Promise<Item>; remove(table: Table, id: string): Promise<void>;
  restore(table: Table, id: string): Promise<void>; setting(key: string): Promise<string | null>;
  setSetting(key: string, value: string): Promise<void>; clearDemo(): Promise<void>;
  exportData(): Promise<Record<string, Item[]>>; importData(data: unknown): Promise<void>; reset(): Promise<void>;
}
export const REMOTE_TABLES = ['profiles','subscriptions','app_config','feature_flags','content_resources','content_flashcard_decks','content_flashcards','quotes','announcements','events','notification_tokens','feedback','consents'] as const;
export interface RemoteResult { ok: boolean; message: string }
export interface BusinessRepository {
  enabled: boolean; reason: string;
  signIn(email: string,password: string): Promise<RemoteResult>;
  signUp(email: string,password: string): Promise<RemoteResult>;
  resetPassword(email: string): Promise<RemoteResult>; signOut(): Promise<RemoteResult>;
  connectionCheck(): Promise<{table: string; ok: boolean; message: string}[]>;
  content(table: 'content_resources'|'quotes'|'announcements'|'content_flashcard_decks'|'content_flashcards'): Promise<Record<string, unknown>[]>;
  send(kind: 'events'|'feedback'|'consents',payload: Record<string, unknown>): Promise<boolean>;
}
