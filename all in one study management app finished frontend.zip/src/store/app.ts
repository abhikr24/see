import { create } from 'zustand';
import { NewItem,Table } from '../lib/types/models';
interface Editor {table:Table;item?:NewItem;defaults?:Partial<NewItem>}
interface AppState {ready:boolean;error:string;editor:Editor|null;toast:string;undo:(()=>void)|null;search:string;
 setReady:(v:boolean)=>void;setError:(v:string)=>void;edit:(v:Editor|null)=>void;notify:(text:string,undo?:(()=>void))=>void;setSearch:(v:string)=>void;}
export const appStore=create<AppState>(set=>({ready:false,error:'',editor:null,toast:'',undo:null,search:'',setReady:ready=>set({ready}),setError:error=>set({error}),edit:editor=>set({editor}),notify:(toast,undo)=>set({toast,undo:undo||null}),setSearch:search=>set({search})}));
