import { createStore,useStore } from 'zustand';
import { Item,NewItem,Table,TABLES } from '../lib/types/models';
import { services } from '../lib/services/container';
import { appStore } from './app';
interface FeatureState {items:Item[];setItems:(items:Item[])=>void}
const createFeatureStore=()=>createStore<FeatureState>(set=>({items:[],setItems:items=>set({items})}));
export const featureStores=Object.fromEntries(TABLES.map(t=>[t,createFeatureStore()])) as Record<Table,ReturnType<typeof createFeatureStore>>;
export const useItems=(table:Table)=>useStore(featureStores[table],s=>s.items);
export function hydrate(data:Record<Table,Item[]>){for(const t of TABLES)featureStores[t].getState().setItems(data[t]||[]);}
export async function reload(){hydrate(await services.load());}
export async function saveItem(table:Table,data:NewItem){
  const store=featureStores[table];const before=store.getState().items;
  if(data.id)store.getState().setItems(before.map(i=>i.id===data.id?{...i,...data}:i));
  try{const item=await services.save(table,data);store.getState().setItems([...store.getState().items.filter(i=>i.id!==item.id),item]);if(table==='tasks'||table==='goal_steps'){featureStores.tasks.getState().setItems(await services.content.all('tasks'));featureStores.goal_steps.getState().setItems(await services.content.all('goal_steps'));}return item;}
  catch(e){store.getState().setItems(before);appStore.getState().notify('Could not save. Your previous data is safe.');throw e;}
}
export async function removeItem(table:Table,id:string){const store=featureStores[table];const before=store.getState().items;store.getState().setItems(before.filter(i=>i.id!==id));try{await services.remove(table,id);appStore.getState().notify('Deleted. Changed your mind?',async()=>{await services.restore(table,id);await reload();});}catch{store.getState().setItems(before);appStore.getState().notify('Unable to delete. Please try again.');}}
export async function setPreference(key:string,value:string){await services.content.setSetting(key,value);featureStores.settings.getState().setItems(await services.content.all('settings'));}
export function usePreference(key:string,fallback=''){return useItems('settings').find(s=>s.title===key)?.value||fallback;}
