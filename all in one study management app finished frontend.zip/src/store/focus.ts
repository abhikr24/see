import { create } from 'zustand';
import { useEffect } from 'react';
import { randomUUID } from 'expo-crypto';
import { usePreference,setPreference,saveItem } from './features';
import { appStore } from './app';
import { dayKey } from '../lib/types/models';
import { scheduleReminder,cancelReminder } from '../lib/notifications/schedule';
import { services } from '../lib/services/container';
interface TimerState {mode:string;work:number;breakLength:number;phase:'Focus'|'Break';remaining:number;end:number|null;subject:string;sessionId:string;notificationId?:string;loaded:boolean;}
const defaults:TimerState={mode:'Pomodoro',work:25,breakLength:5,phase:'Focus',remaining:1500,end:null,subject:'',sessionId:'',loaded:false};
export const useFocusStore=create<TimerState>(()=>defaults);
const persist=()=>setPreference('focus_timer',JSON.stringify(useFocusStore.getState()));
let finishing=false;
export const timerActions={
 async start(){const s=useFocusStore.getState();const id=s.sessionId||randomUUID();const end=Date.now()+s.remaining*1000;useFocusStore.setState({sessionId:id,end});await persist();const notificationId=(await services.content.setting('notifications'))==='true'?await scheduleReminder(s.phase==='Focus'?'Well done. Your focus session is complete. Time for a break.':'Break complete. Ready for another small step?',new Date(end)):undefined;useFocusStore.setState({notificationId});await persist();},
 async pause(){const s=useFocusStore.getState();await cancelReminder(s.notificationId);useFocusStore.setState({end:null,remaining:Math.max(0,Math.ceil(((s.end||Date.now())-Date.now())/1000)),notificationId:undefined});await persist();},
 async reset(){await cancelReminder(useFocusStore.getState().notificationId);const s=useFocusStore.getState();useFocusStore.setState({end:null,phase:'Focus',remaining:s.work*60,sessionId:'',notificationId:undefined});await persist();},
 async configure(values:Partial<TimerState>){const s=useFocusStore.getState();if(s.end)await this.pause();useFocusStore.setState({...values,phase:'Focus',sessionId:'',remaining:(values.work??s.work)*60,end:null});await persist();},
 async complete(){if(finishing)return;finishing=true;try{const s=useFocusStore.getState();if(s.phase==='Focus'){await saveItem('focus_sessions',{id:s.sessionId||randomUUID(),title:'Focus session',duration:s.work,subject_id:s.subject||undefined,date:dayKey()});await services.track({focus_minutes:s.work,sessions_completed:1});appStore.getState().notify('You showed up. Session saved — enjoy your break.');}else appStore.getState().notify('A fresh mind. Ready when you are.');useFocusStore.setState({phase:s.phase==='Focus'?'Break':'Focus',remaining:(s.phase==='Focus'?s.breakLength:s.work)*60,end:null,sessionId:'',notificationId:undefined});await persist();}finally{finishing=false;}}
};
export function useFocusClock(){const value=usePreference('focus_timer','');useEffect(()=>{if(useFocusStore.getState().loaded)return;try{if(value)useFocusStore.setState({...JSON.parse(value),loaded:true});else useFocusStore.setState({loaded:true});}catch{useFocusStore.setState({loaded:true});}},[value]);useEffect(()=>{const id=setInterval(()=>{const s=useFocusStore.getState();if(!s.end)return;const remaining=Math.max(0,Math.ceil((s.end-Date.now())/1000));useFocusStore.setState({remaining});if(remaining===0)void timerActions.complete();},500);return()=>clearInterval(id);},[]);}
