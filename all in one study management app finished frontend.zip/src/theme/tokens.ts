import { useColorScheme } from 'react-native';
import { usePreference } from '../store/features';
export const tokens={primary:'#2563EB',radius:22,space:8,font:{regular:'Inter_400Regular',medium:'Inter_500Medium',semibold:'Inter_600SemiBold',bold:'Inter_700Bold'},shadow:{shadowColor:'#152749',shadowOffset:{width:0,height:4},shadowOpacity:0.035,shadowRadius:16,elevation:2}};
const light={background:'#F5F7FB',card:'#FFFFFF',text:'#0F172A',muted:'#64748B',line:'#EDF0F5',soft:'#F7F9FC',primary:'#2563EB',blueSoft:'#ECF3FF',green:'#12A477',dark:false};
const dark={background:'#0E1525',card:'#172135',text:'#EEF3FF',muted:'#9CAEC8',line:'#27334B',soft:'#1D2B43',primary:'#74A4FF',blueSoft:'#213657',green:'#34D399',dark:true};
export function useTheme(){const system=useColorScheme();const selected=usePreference('appearance','System');return selected==='Dark'||(selected==='System'&&system==='dark')?dark:light;}
export const subjectColors={Mathematics:'#12A477',Physics:'#8B5CF6',Chemistry:'#3B82F6',Biology:'#0F9F99',History:'#F08A45',English:'#6366F1',Personal:'#D89A19'};
