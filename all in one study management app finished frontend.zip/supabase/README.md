# Studifi cloud handoff (optional, under 10 minutes)

Local study content NEVER uploads. The app works without this setup.

1. Create a Supabase project and wait for its database to be ready.
2. Open **SQL Editor → New query**.
3. Paste the entire `supabase/schema.sql` file, unchanged.
4. Click **Run**. The script is idempotent and may be run again.
5. Open **Project Settings → API / API Keys** and copy the project URL and **anon** (or publishable) key. Never use a service-role/secret key.
6. Copy `.env.example` to `.env` in the project root.
7. Uncomment `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`, then replace the values with your two keys.
8. Restart Expo with `npx expo start --clear`.
9. Open **Settings → Developer → Connection check**. All 13 tables should show Ready. Public content is readable without login; private tables only expose the authenticated user's rows.
10. Open **Settings → Sign in or create an account**. Create an email/password account, confirm its email if requested, then sign in. Consent/metrics/feedback queued locally flush on foreground and network return.

## Security and behavior
- No buckets, Edge Functions, CLI migrations, or additional dashboard configuration are needed for standard signup/signin.
- Default email verification stays enabled. The app never pretends an unconfirmed account is signed in.
- A database trigger creates a profile on account creation. RLS protects all tables; curated resources are client read-only.
- `events.metrics` accepts only numeric count fields. User titles, note bodies, study files, and habit/goal text are absent from the remote schema.
- Feedback is explicitly submitted by the student and may contain their support message. It is never collected from notes.
- Anonymous identities are associated with authenticated users through queued event records, not by uploading student content.
- Connection checks establish table reachability. A complete RLS/security audit still requires testing with two real accounts.
- Reset-email requests use Supabase auth. Redirect-based recovery requires registering a permitted callback for a deployed app; that is deliberately not required for standard signup/signin.
