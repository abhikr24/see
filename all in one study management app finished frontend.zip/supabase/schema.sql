-- Studifi v1: BUSINESS DATA ONLY. Paste this entire file into the SQL editor.
-- Student content (notes/tasks/files/habits/exams/goals) never belongs here.
begin;
create extension if not exists pgcrypto;
create or replace function public.studifi_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null default 'Student', email text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.subscriptions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 plan text not null default 'free' check (plan in ('free','plus')), status text not null default 'active',
 expires_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.app_config (
 id uuid primary key default gen_random_uuid(), key text not null unique, value jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.feature_flags (
 id uuid primary key default gen_random_uuid(), key text not null unique, enabled boolean not null default false,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.content_resources (
 id uuid primary key default gen_random_uuid(), slug text not null unique, title text not null,
 description text not null, category text not null, url text, body text, icon text default 'BookOpen', color text default '#2563EB',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.content_flashcard_decks (
 id uuid primary key default gen_random_uuid(), slug text not null unique, title text not null, subject text not null,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.content_flashcards (
 id uuid primary key default gen_random_uuid(), deck_id uuid not null references public.content_flashcard_decks(id) on delete cascade,
 question text not null, answer text not null, position integer not null default 0,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(deck_id,position)
);
create table if not exists public.quotes (
 id uuid primary key default gen_random_uuid(), slug text not null unique, body text not null, attribution text default 'Studifi',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.announcements (
 id uuid primary key default gen_random_uuid(), slug text not null unique, title text not null, body text not null,
 published_at timestamptz not null default now(), expires_at timestamptz,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create or replace function public.studifi_valid_metrics(metrics jsonb) returns boolean language sql immutable as $$
 select jsonb_typeof(metrics) = 'object' and not exists (
 select 1 from jsonb_each(case when jsonb_typeof(metrics)='object' then metrics else '{}'::jsonb end) e
 where e.key not in ('tasks_completed','focus_minutes','notes_created','sessions_completed') or jsonb_typeof(e.value) <> 'number'
 ); $$;
create table if not exists public.events (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 anonymous_id uuid, metrics jsonb not null default '{}'::jsonb check (public.studifi_valid_metrics(metrics)),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.notification_tokens (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 token text not null unique, platform text not null check (platform in ('ios','android')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.feedback (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 message text not null check (char_length(message) between 1 and 10000), category text not null default 'support',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.consents (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 doc text not null, version text not null, accepted_at timestamptz not null,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

-- Database-managed profiles: no client can create another user's profile.
create or replace function public.studifi_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
 insert into public.profiles(id,email,display_name) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'display_name','Student')) on conflict(id) do nothing;
 insert into public.subscriptions(user_id,plan,status) values(new.id,'free','active');
 return new;
end; $$;
drop trigger if exists studifi_on_auth_user on auth.users;
create trigger studifi_on_auth_user after insert on auth.users for each row execute function public.studifi_new_user();
insert into public.profiles(id,email) select id,email from auth.users on conflict(id) do nothing;

-- Every table has RLS, timestamps, and a useful index. No service key is shipped.
do $$ declare t text; begin
 foreach t in array array['profiles','subscriptions','app_config','feature_flags','content_resources','content_flashcard_decks','content_flashcards','quotes','announcements','events','notification_tokens','feedback','consents'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('drop trigger if exists studifi_touch on public.%I',t);
 execute format('create trigger studifi_touch before update on public.%I for each row execute function public.studifi_updated_at()',t);
 execute format('create index if not exists %I on public.%I(updated_at)',t||'_updated_idx',t);
 end loop;
end $$;

-- Public curated/business configuration is client READ ONLY.
do $$ declare t text; begin
 foreach t in array array['app_config','feature_flags','content_resources','content_flashcard_decks','content_flashcards','quotes','announcements'] loop
 execute format('drop policy if exists curated_read on public.%I',t);
 execute format('create policy curated_read on public.%I for select to anon, authenticated using (true)',t);
 execute format('grant select on public.%I to anon, authenticated',t);
 execute format('revoke insert,update,delete on public.%I from anon,authenticated',t);
 end loop;
end $$;

-- Own-row access only. Private data is not readable or writable by anonymous clients.
drop policy if exists own_profile_read on public.profiles;
create policy own_profile_read on public.profiles for select to authenticated using (id=(select auth.uid()));
drop policy if exists own_profile_update on public.profiles;
create policy own_profile_update on public.profiles for update to authenticated using (id=(select auth.uid())) with check (id=(select auth.uid()));
grant select,update on public.profiles to authenticated;
revoke insert,delete on public.profiles from anon,authenticated;
drop policy if exists own_subscription_read on public.subscriptions;
create policy own_subscription_read on public.subscriptions for select to authenticated using (user_id=(select auth.uid()));
grant select on public.subscriptions to authenticated;
revoke insert,update,delete on public.subscriptions from anon,authenticated;
create index if not exists subscriptions_user_idx on public.subscriptions(user_id);

do $$ declare t text; begin
 foreach t in array array['events','notification_tokens','feedback','consents'] loop
 execute format('drop policy if exists own_read on public.%I',t);
 execute format('create policy own_read on public.%I for select to authenticated using (user_id=(select auth.uid()))',t);
 execute format('drop policy if exists own_insert on public.%I',t);
 execute format('create policy own_insert on public.%I for insert to authenticated with check (user_id=(select auth.uid()))',t);
 execute format('drop policy if exists own_update on public.%I',t);
 execute format('create policy own_update on public.%I for update to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()))',t);
 execute format('drop policy if exists own_delete on public.%I',t);
 execute format('create policy own_delete on public.%I for delete to authenticated using (user_id=(select auth.uid()))',t);
 execute format('grant select,insert,update,delete on public.%I to authenticated',t);
 execute format('revoke all on public.%I from anon',t);
 execute format('create index if not exists %I on public.%I(user_id,created_at)',t||'_user_created_idx',t);
 end loop;
end $$;
create index if not exists content_cards_deck_idx on public.content_flashcards(deck_id,position);
create index if not exists resources_category_idx on public.content_resources(category);
create index if not exists events_anonymous_idx on public.events(anonymous_id);
create index if not exists consent_document_idx on public.consents(user_id,doc,version);

insert into public.app_config(key,value) values ('app', '{"name":"Studifi","privacy_version":"1.0","content_sync":false}') on conflict(key) do nothing;
insert into public.feature_flags(key,enabled) values ('curated_resources',true),('content_sync',false) on conflict(key) do nothing;
insert into public.content_resources(slug,title,description,category,url,icon,color) values
 ('khan-math','Build your mathematics foundation','Free lessons and practice, from algebra to calculus.','Video Lectures','https://www.khanacademy.org/math','Video','#5A79BD'),
 ('openstax-physics','College Physics · OpenStax','An openly licensed textbook with worked examples and practice problems.','Past Papers','https://openstax.org/details/books/college-physics-2e','FileText','#ED8A67'),
 ('khan-science','Science, one concept at a time','Explore biology, chemistry, and physics with Khan Academy.','Video Lectures','https://www.khanacademy.org/science','Video','#5A79BD') on conflict(slug) do nothing;
insert into public.content_resources(slug,title,description,category,body,icon,color) values
 ('active-recall','The active recall method','Close your notes. Recall. Check your gaps. Repeat.','Quick Revision',E'## Make your revision active\n1. Read one short section.\n2. Close the book and explain it.\n3. Check what you missed.\n4. Make a flashcard for each gap.\n5. Review tomorrow, in three days, and in a week.','Lightbulb','#12A477'),
 ('concept-map','Make a concept map that connects','Turn a chapter into a network of ideas.','Mind Maps',E'## Build connections\n- Start with the central idea.\n- Add three to five major concepts.\n- Label why they connect.\n- Include a concrete example.\n- Recreate your map from memory.','Network','#8B5CF6') on conflict(slug) do nothing;
insert into public.content_flashcard_decks(slug,title,subject) values ('physics-basics','Physics fundamentals','Physics') on conflict(slug) do nothing;
insert into public.content_flashcards(deck_id,question,answer,position)
 select id,'What is Newton’s second law?','F = ma. Net force equals mass times acceleration.',0 from public.content_flashcard_decks where slug='physics-basics' on conflict(deck_id,position) do nothing;
insert into public.content_flashcards(deck_id,question,answer,position)
 select id,'What is the SI unit of energy?','The joule (J). One joule equals one newton-metre.',1 from public.content_flashcard_decks where slug='physics-basics' on conflict(deck_id,position) do nothing;
insert into public.quotes(slug,body) values ('keep-going','You don’t have to be perfect. You just have to keep going.') on conflict(slug) do nothing;
insert into public.announcements(slug,title,body) values ('welcome','A calmer place to learn','Welcome to Studifi. Your student content stays on your device. Remember to export a backup before switching phones.') on conflict(slug) do nothing;
commit;
