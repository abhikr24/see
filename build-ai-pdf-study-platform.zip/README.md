# Recall — turn any PDF into memory that sticks

A working, mobile-first study application. Upload a PDF (or paste text) and get flashcards,
cloze deletions, a graded multiple-choice quiz, concept notes, a day-by-day study plan and a
spaced-repetition review queue.

**Two engines, one product:**

- **Rules engine — free, unlimited, default.** Fully deterministic: PDF text extraction, cleaning,
  sentence segmentation, TF/proper-noun/bigram concept ranking, card generation, distractor
  selection and SM-2 scheduling. No API key, no credits, no network calls.
- **AI engine — Pro, metered.** Optional. Rewrites and expands the deck with a server-side LLM call
  (OpenAI / Anthropic / Groq / OpenRouter / custom OpenAI-compatible endpoint). Input and output are
  validated; on provider failure the free engine finishes the job and the credit is not charged.

## Run it

```bash
npm install
cp .env.example .env      # DATABASE_URL is the only required value
npx drizzle-kit push      # create tables
npm run dev               # http://localhost:3000
```

Demo account (seeded automatically on first visit): `demo@recall.studio` / `recall1234`.

Production check:

```bash
npx next typegen && npx tsc --noEmit && npm run build && npm start
```

## Architecture

```
src/app/                 routes: marketing, auth, pricing, app shell, study workspace, APIs
src/components/          LiveStudio (client-side engine demo), AppShell, ReviewRunner, QuizPanel…
src/lib/memory/          pure deterministic engine: cleaning, analysis, card generation, SM-2, CSV
src/lib/ai/provider.ts   provider abstraction, JSON validation, AI merge (server only)
src/lib/auth/            provider switch: local (Postgres sessions) or Supabase (server-only)
src/lib/pdf.ts           unpdf/PDF.js extraction, page by page (server only)
src/lib/repository.ts    all database reads/writes, demo seed
src/db/                  Drizzle schema + client
```

### Security model

- All credentials are read from `process.env` in server modules. No `NEXT_PUBLIC_*` secrets exist,
  and no AI/Supabase key is ever serialised into a client component.
- Sessions are HTTP-only, `sameSite=lax`, secure in production; the local provider stores only
  SHA-256 hashes of session tokens and scrypt password hashes.
- Every document, card, review, quiz attempt and export is scoped by the authenticated user ID and
  verified on the server.
- Paid AI access is enforced in `/api/documents`: plan + credit checks happen before a provider call,
  and credits are decremented only after a successful generation.

### Switching the backend to Supabase

See [`SUPABASE_SETUP.md`](./SUPABASE_SETUP.md) — set three server environment variables, run
`drizzle-kit push`, and the identical routes authenticate against Supabase Auth. The local provider
stays available as an offline/demo fallback.

## Open source used

| Project | License | Role |
| --- | --- | --- |
| [unpdf](https://github.com/unjs/unpdf) | MIT | Serverless PDF text extraction |
| [PDF.js](https://github.com/mozilla/pdf.js) | Apache-2.0 | Underlying PDF parser |
| [Next.js](https://github.com/vercel/next.js) | MIT | App Router, server actions/routes |
| [React](https://github.com/facebook/react) | MIT | UI runtime |
| [Drizzle ORM](https://github.com/drizzle-team/drizzle-orm) | Apache-2.0 | Typed SQL, migrations |
| [PostgreSQL](https://www.postgresql.org/) | PostgreSQL License | Durable storage |
| [Tailwind CSS](https://github.com/tailwindlabs/tailwindcss) | MIT | Styling |
| [Zod](https://github.com/colinhacks/zod) | MIT | Validation of inputs and AI output |
| [Lucide](https://github.com/lucide-icons/lucide) | ISC | Icons |
| SM-2 (SuperMemo 2) | Published research | Spaced-repetition intervals |

Not affiliated with Anki; decks export to its documented CSV import format.
