# Supabase in ~5 minutes

Recall ships with two auth providers behind one server-only interface:

| Provider | When it is used | Storage |
| --- | --- | --- |
| `local` (default) | No configuration | Your PostgreSQL database (Drizzle) |
| `supabase` | `AUTH_PROVIDER=supabase` + Supabase env vars | Supabase Auth + your PostgreSQL database |

Credentials are **only** read with `process.env` in server code (`src/lib/auth/*`, `src/lib/ai/*`).
The browser never receives a Supabase URL, anon key or service key. Session cookies are
`httpOnly`, `sameSite=lax`, `secure` in production, and the DB session tokens are stored hashed.

## 1. Create the Supabase project

Create a project at <https://supabase.com>, then copy from **Project Settings → API**:

- `SUPABASE_URL` (e.g. `https://abcdxyz.supabase.co`) — keep it server-side.
- `SUPABASE_ANON_KEY` (or `SUPABASE_SERVICE_ROLE_KEY` for admin work) — server-side only.

> Do **not** create `NEXT_PUBLIC_SUPABASE_*` variables. Auth is proxied through this app's own route
> handlers (`/api/auth/login`, `/api/auth/signup`, `/api/auth/logout`), so nothing leaks to the client.

## 2. Add server environment variables

```bash
# .env (never commit)
AUTH_PROVIDER=supabase
SUPABASE_URL=https://YOUR-PROJECT.supabase.co
SUPABASE_ANON_KEY=your-anon-key
AUTH_SECRET=any-long-random-string      # optional; used by the local provider
DATABASE_URL=postgresql://...           # your Postgres / Supabase database connection
```

In **Supabase → Authentication → Providers**, enable Email. If you want instant demo logins, turn
off "Confirm email" for the project (otherwise users must click the confirmation link first).

## 3. Keep the app tables (recommended: same Postgres)

Recall stores documents, cards and reviews in Postgres via Drizzle. Point `DATABASE_URL` at the
Supabase database (Project Settings → Database → Connection string → Session/Transaction pooler) and
run:

```bash
npx drizzle-kit push
```

Alternatively keep a separate Postgres for app data — auth is mirrored into `users` by email so the
foreign keys stay valid either way (`upsertExternalUser` in `src/lib/auth/index.ts`).

## 4. Optional: Row Level Security

Because all data access happens server-side with one connection, RLS is optional. If you prefer
defence in depth, enable RLS on `documents`, `cards`, `reviews`, `quiz_attempts` and add:

```sql
alter table public.documents enable row level security;

create policy "own documents" on public.documents
  for all using (user_id = auth.uid()::uuid)
  with check (user_id = auth.uid()::uuid);
```

To make `users.id` equal `auth.uid()`, set the local mirror id from the Supabase user id
(`upsertExternalUser` accepts the remote identity) before enabling these policies.

## 5. Verify

1. Restart the app: `npm run build && npm start`.
2. Visit `/login` — sign up with a real email (or disable confirmation first).
3. Open `/app/billing` — the deployment panel shows `Auth provider: Supabase`.
4. Sign out: the refresh token is revoked server-side and both HTTP-only cookies are cleared.

## AI provider (independent of auth)

```bash
# pick one
OPENAI_API_KEY=sk-...            # + optional OPENAI_MODEL, OPENAI_BASE_URL
ANTHROPIC_API_KEY=sk-ant-...
GROQ_API_KEY=gsk_...
OPENROUTER_API_KEY=sk-or-...
# or a generic OpenAI-compatible endpoint
AI_PROVIDER=custom
AI_API_KEY=...
AI_BASE_URL=https://your-endpoint/v1
AI_MODEL=your-model
```

Without a key the AI engine reports itself as unconfigured, the paid route still refuses to burn a
credit, and every upload keeps working through the deterministic engine.
