import { NextResponse } from "next/server";
import { z } from "zod";
import { signIn } from "@/lib/auth";
import { attachSessionCookie, attachSupabaseCookies } from "@/lib/auth/http";

const schema = z.object({
  email: z.string().min(3),
  password: z.string().min(1),
});

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Enter your email and password." }, { status: 400 });
  }

  const result = await signIn(parsed.data.email, parsed.data.password);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 401 });
  }

  const response = NextResponse.json({ ok: true, user: result.user });
  if (result.sessionToken) attachSessionCookie(response, result.sessionToken);
  if (result.tokens) attachSupabaseCookies(response, result.tokens);
  return response;
}
