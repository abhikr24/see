import { NextResponse } from "next/server";
import { z } from "zod";
import { signUp } from "@/lib/auth";
import { attachSessionCookie, attachSupabaseCookies } from "@/lib/auth/http";

const schema = z.object({
  name: z.string().min(1).max(80),
  email: z.string().min(3),
  password: z.string().min(8).max(200),
});

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Use a valid email and a password of at least 8 characters." },
      { status: 400 },
    );
  }

  const result = await signUp(parsed.data.name, parsed.data.email, parsed.data.password);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  const response = NextResponse.json({ ok: true, user: result.user });
  if (result.sessionToken) attachSessionCookie(response, result.sessionToken);
  if (result.tokens) attachSupabaseCookies(response, result.tokens);
  return response;
}
