import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { activateDemoPro } from "@/lib/repository";

/**
 * Demo checkout. It is intentionally server-side only and it is the single place
 * to swap in Stripe / Lemon Squeezy: replace the body with a checkout-session call
 * and move activateDemoPro() into the webhook handler.
 */
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in first." }, { status: 401 });

  const body = (await request.json().catch(() => ({}))) as { credits?: number };
  const updated = await activateDemoPro(user.id, body.credits ?? 40);
  if (!updated) return NextResponse.json({ error: "Could not activate Pro." }, { status: 500 });

  return NextResponse.json({
    ok: true,
    mode: "demo",
    plan: updated.plan,
    aiCredits: updated.aiCredits,
    message: "Pro is active for this demo account. Payments are simulated — add Stripe before launch.",
  });
}
