import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { reviewCard } from "@/lib/repository";
import type { ReviewGrade } from "@/lib/memory/types";

const GRADES: ReviewGrade[] = [0, 1, 2, 3];

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = (await request.json().catch(() => null)) as { grade?: number } | null;
  const grade = body?.grade;
  if (typeof grade !== "number" || !GRADES.includes(grade as ReviewGrade)) {
    return NextResponse.json({ error: "Grade must be 0-3." }, { status: 400 });
  }

  const { id } = await context.params;
  const result = await reviewCard(user.id, id, grade as ReviewGrade);
  if (!result) return NextResponse.json({ error: "Card not found." }, { status: 404 });

  return NextResponse.json({ ok: true, next: result });
}
