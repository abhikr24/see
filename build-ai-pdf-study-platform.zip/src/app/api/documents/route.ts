import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { aiStatus, generateWithAi, mergeAiAnalysis } from "@/lib/ai/provider";
import { analyzeSource } from "@/lib/memory/engine";
import { extractPdfPages } from "@/lib/pdf";
import { createSource, listDocuments } from "@/lib/repository";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_PDF_BYTES = 12 * 1024 * 1024;
const MAX_TEXT_CHARS = 400_000;

const jsonSchema = z.object({
  title: z.string().max(160).optional(),
  text: z.string().min(1),
  engine: z.enum(["rules", "ai"]).default("rules"),
  cardCount: z.number().int().min(8).max(60).optional(),
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ documents: await listDocuments(user.id) });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in first." }, { status: 401 });

  const contentType = request.headers.get("content-type") ?? "";
  let title = "Untitled source";
  let pages: string[] = [];
  let sourceType: "pdf" | "txt" | "paste" = "paste";
  let fileName: string | null = null;
  let engine: "rules" | "ai" = "rules";
  let cardCount: number | undefined;
  const warnings: string[] = [];

  if (contentType.includes("multipart/form-data")) {
    const form = await request.formData();
    const file = form.get("file");
    const engineField = String(form.get("engine") ?? "rules");
    engine = engineField === "ai" ? "ai" : "rules";
    const titleField = String(form.get("title") ?? "").trim();
    const cardCountField = Number(form.get("cardCount") ?? 0);
    if (cardCountField >= 8 && cardCountField <= 60) cardCount = cardCountField;

    if (!(file instanceof File) || file.size === 0) {
      return NextResponse.json({ error: "Choose a PDF, TXT or Markdown file." }, { status: 400 });
    }
    if (file.size > MAX_PDF_BYTES) {
      return NextResponse.json({ error: "That file is larger than 12 MB." }, { status: 413 });
    }

    fileName = file.name;
    title = titleField || file.name.replace(/\.[^.]+$/, "").slice(0, 140) || "Untitled source";
    const lower = file.name.toLowerCase();

    if (lower.endsWith(".pdf")) {
      sourceType = "pdf";
      try {
        const extracted = await extractPdfPages(await file.arrayBuffer());
        pages = extracted.pages;
        warnings.push(...extracted.warnings);
      } catch {
        return NextResponse.json(
          {
            error:
              "This PDF could not be read. It may be encrypted or damaged — try exporting it again, or paste the text.",
          },
          { status: 422 },
        );
      }
    } else if (lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".markdown")) {
      sourceType = "txt";
      pages = [(await file.text()).slice(0, MAX_TEXT_CHARS)];
    } else {
      return NextResponse.json(
        { error: "Supported files: PDF, TXT, MD. For anything else, paste the text." },
        { status: 415 },
      );
    }
  } else {
    const parsed = jsonSchema.safeParse(await request.json().catch(() => null));
    if (!parsed.success) {
      return NextResponse.json({ error: "Paste some text first." }, { status: 400 });
    }
    title = (parsed.data.title ?? "Untitled source").slice(0, 140) || "Untitled source";
    pages = [parsed.data.text.slice(0, MAX_TEXT_CHARS)];
    engine = parsed.data.engine;
    cardCount = parsed.data.cardCount;
    sourceType = "paste";
  }

  const joined = pages.join(" ").trim();
  if (joined.length < 60) {
    return NextResponse.json(
      { error: "We need at least 60 characters of readable text to build memory material." },
      { status: 422 },
    );
  }

  let aiOverlay: Parameters<typeof createSource>[0]["aiOverlay"] = null;
  let aiMeta: Parameters<typeof createSource>[0]["aiMeta"] = null;
  let aiNote: string | null = null;

  if (engine === "ai") {
    if (user.plan !== "pro") {
      return NextResponse.json(
        {
          error:
            "The AI engine is part of Pro. The rules engine is free and unlimited — or upgrade to unlock AI cards.",
          code: "UPGRADE_REQUIRED",
        },
        { status: 402 },
      );
    }
    if (user.aiCredits <= 0) {
      return NextResponse.json(
        { error: "You are out of AI credits. Top up in Billing, or switch to the free rules engine.", code: "NO_CREDITS" },
        { status: 402 },
      );
    }

    const base = analyzeSource({ title, pages });
    const ai = await generateWithAi({
      title,
      text: pages.join("\n\n"),
      cardCount: Math.min(cardCount ?? Math.max(14, Math.round(base.analysis.stats.words / 55)), 45),
      pages,
    });

    if (ai.ok) {
      aiOverlay = {
        cards: ai.cards,
        analysis: mergeAiAnalysis(base.analysis, ai),
        provider: `${ai.provider} · ${ai.model}`,
      };
      aiMeta = { provider: ai.provider, model: ai.model, tokens: 0 };
    } else {
      aiNote = `${ai.message} Your credits were not charged and every card below came from the deterministic engine.`;
      warnings.push(aiNote);
    }
  }

  const doc = await createSource({
    userId: user.id,
    title,
    sourceType,
    fileName,
    pages,
    engine,
    cardCount,
    aiOverlay,
    aiMeta,
  });

  return NextResponse.json({
    ok: true,
    id: doc.id,
    engine: aiOverlay ? "ai" : "rules",
    aiNote,
    aiConfigured: aiStatus().configured,
    warnings,
  });
}
