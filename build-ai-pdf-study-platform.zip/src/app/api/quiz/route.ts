import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { getDocument, recordQuizAttempt } from "@/lib/repository";

const schema = z.object({
  documentId: z.string().uuid(),
  score: z.number().int().min(0).max(100),
  total: z.number().int().min(1).max(100),
});

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid attempt." }, { status: 400 });

  const doc = await getDocument(user.id, parsed.data.documentId);
  if (!doc) return NextResponse.json({ error: "Document not found." }, { status: 404 });

  await recordQuizAttempt(user.id, doc.id, parsed.data.score, parsed.data.total);
  return NextResponse.json({ ok: true });
}
