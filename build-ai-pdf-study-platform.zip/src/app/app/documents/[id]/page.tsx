import { notFound, redirect } from "next/navigation";
import StudyWorkspace from "@/components/app/StudyWorkspace";
import { getCurrentUser } from "@/lib/auth";
import { getDocument, getDocumentCards } from "@/lib/repository";
import { serializeCard } from "@/lib/ui-types";

export const dynamic = "force-dynamic";

export default async function DocumentPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const { id } = await params;
  const doc = await getDocument(user.id, id);
  if (!doc) notFound();

  const cards = await getDocumentCards(user.id, doc.id);

  return (
    <StudyWorkspace
      doc={{
        id: doc.id,
        title: doc.title,
        engine: doc.engine,
        sourceType: doc.sourceType,
        pageCount: doc.pageCount,
        wordCount: doc.wordCount,
        createdAt: doc.createdAt.toISOString(),
        rawText: doc.rawText,
        analysis: doc.analysis,
      }}
      cards={cards.map(serializeCard)}
    />
  );
}
