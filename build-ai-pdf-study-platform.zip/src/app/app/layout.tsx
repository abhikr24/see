import { redirect } from "next/navigation";
import { and, eq, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { cards } from "@/db/schema";
import AppShell from "@/components/app/AppShell";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const [due] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(cards)
    .where(and(eq(cards.userId, user.id), lte(cards.dueAt, new Date())));

  return (
    <AppShell
      user={{
        name: user.name,
        email: user.email,
        plan: user.plan,
        aiCredits: user.aiCredits,
        streak: user.streak,
      }}
      dueCount={due?.count ?? 0}
    >
      {children}
    </AppShell>
  );
}
