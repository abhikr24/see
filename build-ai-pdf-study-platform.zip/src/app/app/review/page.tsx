import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, CircleCheck, Repeat } from "lucide-react";
import ReviewRunner from "@/components/app/ReviewRunner";
import { getCurrentUser } from "@/lib/auth";
import { getDueQueue, listDocuments } from "@/lib/repository";
import { serializeCard } from "@/lib/ui-types";

export const dynamic = "force-dynamic";

export default async function ReviewPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const due = await getDueQueue(user.id, 40);
  const docs = await listDocuments(user.id);
  const cards = due.map((row) => serializeCard(row.card));

  return (
    <div className="space-y-5">
      <div>
        <p className="eyebrow">Daily practice</p>
        <h1 className="display mt-2 text-3xl sm:text-4xl">Your review queue.</h1>
        <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-muted">
          Cards appear here when their interval expires. Grade honestly — an inflated answer pushes
          the card further away than it deserves.
        </p>
      </div>

      {cards.length === 0 ? (
        <div className="card grid place-items-center p-10 text-center">
          <div>
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-lime/30 bg-lime/10 text-lime">
              <CircleCheck className="h-5 w-5" />
            </span>
            <h2 className="mt-4 text-base font-semibold text-cream">Nothing due right now</h2>
            <p className="mx-auto mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-muted">
              Your next batch is scheduled. You can still study ahead by opening a specific deck and
              choosing &ldquo;All cards&rdquo;.
            </p>
            <div className="mt-5 flex flex-col justify-center gap-2 sm:flex-row">
              <Link href="/app/new" className="btn btn-primary btn-sm">
                Add a new source <ArrowRight className="h-3.5 w-3.5" />
              </Link>
              <Link href="/app" className="btn btn-ghost btn-sm">
                Browse decks
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <span className="chip chip-lime">
              <Repeat className="h-3 w-3" /> {cards.length} due now
            </span>
            <span className="chip">{docs.length} decks</span>
          </div>
          <ReviewRunner cards={cards} showDocument />
        </>
      )}
    </div>
  );
}
