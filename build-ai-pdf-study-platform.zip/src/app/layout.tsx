import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Recall — Turn any PDF into memory that sticks",
  description:
    "Recall converts PDFs, notes and pasted text into flashcards, cloze deletions, quizzes and a spaced-repetition plan. A deterministic rules engine is free forever; AI is an optional upgrade.",
  applicationName: "Recall",
  keywords: [
    "PDF to flashcards",
    "spaced repetition",
    "active recall",
    "study app",
    "memory",
    "Anki export",
  ],
  openGraph: {
    title: "Recall — Turn any PDF into memory",
    description:
      "Free, deterministic study material generation from any PDF. AI polish available as an optional paid upgrade.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#08080d",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <div className="relative min-h-dvh">{children}</div>
      </body>
    </html>
  );
}
