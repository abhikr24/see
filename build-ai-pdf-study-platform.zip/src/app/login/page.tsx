import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Brain, FileUp, Lock, ShieldCheck, Sparkles } from "lucide-react";
import AuthForm from "@/components/AuthForm";
import { Logo } from "@/components/site/SiteChrome";
import { getCurrentUser } from "@/lib/auth";
import { DEMO_EMAIL, DEMO_PASSWORD, ensureDemoSeed } from "@/lib/repository";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Sign in · Recall",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ mode?: string }>;
}) {
  const user = await getCurrentUser();
  if (user) redirect("/app");

  await ensureDemoSeed();
  const { mode } = await searchParams;

  return (
    <div className="relative min-h-dvh overflow-hidden">
      <div className="aurora opacity-70" />
      <div className="shell relative flex min-h-dvh flex-col py-6">
        <div className="flex items-center justify-between">
          <Logo />
          <Link href="/" className="btn btn-ghost btn-sm">
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </Link>
        </div>

        <div className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[1fr_0.9fr] lg:gap-16">
          <div className="max-w-lg">
            <p className="eyebrow">Your memory workspace</p>
            <h1 className="display mt-3 text-4xl sm:text-5xl">
              The PDF is closed.
              <span className="block text-lime">The recall is just starting.</span>
            </h1>
            <p className="mt-4 text-[14px] leading-relaxed text-muted">
              Sign in to save documents, generate decks, review due cards and export to Anki. The
              deterministic engine is free and unlimited — AI credits are an optional upgrade.
            </p>

            <ul className="mt-7 space-y-3">
              {[
                { icon: FileUp, text: "Upload a PDF or paste any text. 12 MB per file." },
                { icon: Brain, text: "Get flashcards, cloze deletions, MCQs and a study plan." },
                { icon: Sparkles, text: "Optional AI polish on top of the free engine." },
                { icon: Lock, text: "HTTP-only sessions. Keys never reach the browser." },
              ].map((item) => (
                <li key={item.text} className="flex items-start gap-3 text-[13px] text-muted">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-line bg-white/5 text-lime">
                    <item.icon className="h-3.5 w-3.5" />
                  </span>
                  {item.text}
                </li>
              ))}
            </ul>

            <div className="mt-7 flex flex-wrap gap-2">
              <span className="chip chip-lime">
                <ShieldCheck className="h-3 w-3" /> Supabase-ready auth
              </span>
              <span className="chip">Demo billing</span>
            </div>
          </div>

          <div className="w-full max-w-md lg:justify-self-end">
            <AuthForm
              initialMode={mode === "signup" ? "signup" : "signin"}
              demoEmail={DEMO_EMAIL}
              demoPassword={DEMO_PASSWORD}
            />
            <p className="mt-4 text-center text-[11px] leading-relaxed text-muted">
              By continuing you agree that this is a demo environment. Payments are simulated and the
              demo account is shared.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
