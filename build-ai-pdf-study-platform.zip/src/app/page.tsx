import Link from "next/link";
import {
  ArrowRight,
  Boxes,
  Brain,
  CircleCheck,
  ClipboardCheck,
  Download,
  FileUp,
  Flame,
  Layers,
  ListChecks,
  Lock,
  Repeat,
  ShieldCheck,
  Sparkles,
  Timer,
  Wand2,
} from "lucide-react";
import LiveStudio from "@/components/LiveStudio";
import { SiteFooter, SiteNav } from "@/components/site/SiteChrome";
import { ensureDemoSeed } from "@/lib/repository";
import { aiStatus } from "@/lib/ai/provider";

export const dynamic = "force-dynamic";

const PIPELINE = [
  {
    step: "01",
    title: "Extract",
    body: "PDF.js (via unpdf) pulls text page by page on the server — so every card can cite the page it came from.",
  },
  {
    step: "02",
    title: "Clean",
    body: "Repeated headers, footers, page numbers and hyphenated line breaks are detected and removed before anything is scored.",
  },
  {
    step: "03",
    title: "Segment",
    body: "Sentences are split with abbreviation guards (e.g., i.e., Fig., Dr.), then filtered for length and substance.",
  },
  {
    step: "04",
    title: "Rank concepts",
    body: "TF-weighted term scoring with proper-noun, heading and bigram boosts. Deterministic, explainable, no model required.",
  },
  {
    step: "05",
    title: "Generate",
    body: "Definitions, quantified facts, sequences and cloze deletions, plus four-option MCQs with distractors drawn from the source.",
  },
  {
    step: "06",
    title: "Schedule",
    body: "SM-2 scheduling gives every card an ease factor and next due date. Weak cards return sooner, strong ones stretch out.",
  },
];

const METHOD = [
  {
    icon: Brain,
    title: "Retrieval, not rereading",
    body: "Every card forces you to produce the answer. The struggle is the learning event — recognition is not.",
  },
  {
    icon: Timer,
    title: "Spacing that adapts",
    body: "Cards return just before you would forget them. Grade honestly and intervals respond: Again, Hard, Good, Easy.",
  },
  {
    icon: Layers,
    title: "Interleaving by default",
    body: "Reviews mix cloze, definition, fact and list cards from across the document instead of drilling one block.",
  },
  {
    icon: Wand2,
    title: "Elaboration prompts",
    body: "Teach-it-back prompts ask you to connect, compare and break ideas — the cues that make recall findable.",
  },
];

const BUILT_ON = [
  { name: "unpdf", note: "server PDF extraction", license: "MIT" },
  { name: "PDF.js", note: "text-layer parsing", license: "Apache-2.0" },
  { name: "Next.js", note: "App Router runtime", license: "MIT" },
  { name: "Drizzle ORM", note: "typed SQL", license: "Apache-2.0" },
  { name: "PostgreSQL", note: "source of truth", license: "PostgreSQL" },
  { name: "Zod", note: "input + AI output validation", license: "MIT" },
  { name: "Lucide", note: "icon system", license: "ISC" },
  { name: "SM-2", note: "spaced repetition research", license: "Public" },
];

const DELIVERABLES = [
  { icon: Layers, title: "Flashcards", body: "Definition, fact, sequence and concept cards with a hint and a source quote." },
  { icon: ClipboardCheck, title: "Cloze deletions", body: "High-value keywords removed from real sentences, never invented ones." },
  { icon: ListChecks, title: "Graded quiz", body: "Multiple choice with plausible distractors, scored and saved to your history." },
  { icon: Repeat, title: "Review queue", body: "A single daily queue across every document, ordered by what decays first." },
  { icon: Sparkles, title: "Recall prompts", body: "Open-ended prompts that make you explain, compare and stress-test the ideas." },
  { icon: Download, title: "Portable decks", body: "Anki-compatible CSV, structured JSON and a Markdown study sheet. No lock-in." },
];

const FAQ = [
  {
    q: "Does the no-AI mode actually work?",
    a: "Yes — it is the default and it is complete. Every card, quiz option, source citation, study plan and review interval is produced by deterministic rules running on the server. Nothing is faked and there is no hidden paywall. AI only rewrites and expands the card set; it is never required to use the product.",
  },
  {
    q: "What exactly do I pay for?",
    a: "Only AI credits. Pro adds AI-generated cards, tighter summaries and extra recall prompts on top of the free engine. When you are out of credits, or the AI provider is unavailable, the rules engine finishes the job and you are not charged.",
  },
  {
    q: "What happens to a scanned PDF?",
    a: "Scanned pages are images, so there is no text to extract. Recall detects this and tells you instead of generating nonsense. Export the PDF with a text layer, or paste the text — it all flows through the same engine.",
  },
  {
    q: "How are my API keys and data protected?",
    a: "All AI and auth credentials live in server-only environment variables. Sessions are HTTP-only cookies backed by hashed tokens. Uploads are processed in memory and never sent to a third party unless you explicitly choose the AI engine.",
  },
  {
    q: "Can I switch the backend to Supabase?",
    a: "Yes. The auth layer is provider-based: set AUTH_PROVIDER=supabase plus your Supabase URL and server key, and the same routes authenticate against Supabase Auth while keeping Row Level Security possible. The included local provider is for this demo environment.",
  },
];

export default async function LandingPage() {
  await ensureDemoSeed();
  const ai = aiStatus();

  return (
    <div className="relative">
      <SiteNav />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="aurora" />
        <div className="shell relative grid gap-10 py-12 lg:grid-cols-[1.02fr_1fr] lg:items-center lg:py-20">
          <div className="animate-rise">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip chip-lime">
                <CircleCheck className="h-3 w-3" /> Rules engine free forever
              </span>
              <span className="chip">
                <Sparkles className="h-3 w-3" /> AI is optional
              </span>
            </div>
            <h1 className="display mt-5 text-[2.6rem] leading-[0.98] sm:text-6xl lg:text-[4.1rem]">
              Turn any PDF into
              <span className="block text-lime text-glow">memory that sticks.</span>
            </h1>
            <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-muted sm:text-base">
              Recall reads your document, finds what actually matters, and builds flashcards,
              cloze deletions, a graded quiz and a spaced-repetition plan. The deterministic engine
              is free and unlimited. Add AI only if you want it.
            </p>
            <div className="mt-7 flex flex-col gap-2.5 sm:flex-row sm:items-center">
              <Link href="/login?mode=signup" className="btn btn-primary">
                Start free — no card <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/login" className="btn btn-ghost">
                Try the demo account
              </Link>
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[12px] text-muted">
              <span className="inline-flex items-center gap-1.5">
                <FileUp className="h-3.5 w-3.5 text-lime" /> PDF, TXT, MD or paste
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Lock className="h-3.5 w-3.5 text-lime" /> Server-side keys only
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Download className="h-3.5 w-3.5 text-lime" /> Anki-compatible export
              </span>
            </div>
          </div>

          <div className="animate-rise lg:pl-4">
            <LiveStudio />
          </div>
        </div>

        <div className="shell relative grid gap-4 border-y border-line py-6 sm:grid-cols-3">
          {[
            { value: "4", label: "chunks in working memory", note: "so cards must stay atomic" },
            { value: "~60%", label: "forgotten inside a day", note: "the curve every review fights" },
            { value: "0", label: "AI calls required", note: "the free engine is deterministic" },
          ].map((stat) => (
            <div key={stat.label} className="flex items-baseline gap-3">
              <span className="display text-3xl text-lime">{stat.value}</span>
              <span className="text-[12.5px] leading-snug text-muted">
                {stat.label}
                <span className="block text-[11px] text-muted/70">{stat.note}</span>
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* ENGINES */}
      <section id="engine" className="shell scroll-mt-20 py-16 lg:py-24">
        <div className="max-w-2xl">
          <p className="eyebrow">Two engines, one workspace</p>
          <h2 className="display mt-3 text-3xl sm:text-4xl lg:text-[2.9rem]">
            The free engine is not a teaser. It is the product.
          </h2>
          <p className="mt-4 text-[15px] leading-relaxed text-muted">
            Most study tools hide the useful part behind a subscription. Recall splits cleanly: the
            deterministic pipeline below is free and unlimited. AI is a paid layer stacked on top of
            it — and if AI fails, the free layer still delivers a full deck.
          </p>
        </div>

        <div className="mt-9 grid gap-5 lg:grid-cols-[1.35fr_1fr]">
          <div className="card p-5 sm:p-7">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-xl border border-lime/30 bg-lime/10 text-lime">
                  <Boxes className="h-4 w-4" />
                </span>
                <div>
                  <h3 className="text-base font-semibold text-cream">Deterministic engine</h3>
                  <p className="text-[11.5px] text-muted">Rules · no model · unlimited</p>
                </div>
              </div>
              <span className="chip chip-lime">Free forever</span>
            </div>

            <ol className="mt-6 space-y-4">
              {PIPELINE.map((item) => (
                <li key={item.step} className="relative flex gap-3.5">
                  <div className="flex flex-col items-center">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-line bg-white/5 font-mono text-[10.5px] text-lime">
                      {item.step}
                    </span>
                    <span className="mt-1 w-px flex-1 bg-line" />
                  </div>
                  <div className="pb-1">
                    <h4 className="text-[13.5px] font-semibold text-cream">{item.title}</h4>
                    <p className="mt-0.5 text-[12.5px] leading-relaxed text-muted">{item.body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          <div className="space-y-5">
            <div className="card relative overflow-hidden p-5 sm:p-6">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-9 w-9 place-items-center rounded-xl border border-violet/30 bg-violet/10 text-violet">
                    <Wand2 className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="text-base font-semibold text-cream">AI enhancement</h3>
                    <p className="text-[11.5px] text-muted">Pro · metered credits</p>
                  </div>
                </div>
                <span className="chip">Paid</span>
              </div>
              <ul className="mt-4 space-y-2.5 text-[12.5px] leading-relaxed text-muted">
                {[
                  "Rewrites cards into tighter, exam-ready questions.",
                  "Adds summaries and extra teach-it-back prompts.",
                  "Every AI card is validated and grounded in your source.",
                  "Falls back to the free engine on failure — credits untouched.",
                ].map((line) => (
                  <li key={line} className="flex gap-2">
                    <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-violet" />
                    {line}
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex items-center justify-between gap-3 rounded-xl border border-line bg-ink-2/70 px-3 py-2.5">
                <p className="text-[11.5px] text-muted">
                  Provider status:{" "}
                  <span className={ai.configured ? "text-lime" : "text-coral"}>
                    {ai.configured ? `${ai.provider} connected` : "not configured"}
                  </span>
                </p>
                <Link href="/pricing" className="text-[11.5px] font-semibold text-cream hover:text-lime">
                  See pricing →
                </Link>
              </div>
            </div>

            <div className="card p-5 sm:p-6">
              <h3 className="text-[13px] font-semibold uppercase tracking-[0.14em] text-cream">
                Why this order matters
              </h3>
              <p className="mt-3 text-[12.5px] leading-relaxed text-muted">
                A rules engine never hallucinates a statistic, never renames a term, and never needs
                an API key. That makes it safe for medical notes, legal text and course material —
                and it is the reason the AI layer can be optional instead of load-bearing.
              </p>
              <dl className="mt-4 grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-line bg-white/[0.03] p-3">
                  <dt className="text-[10px] uppercase tracking-[0.12em] text-muted">Cost per doc</dt>
                  <dd className="mt-1 text-sm font-semibold text-cream">$0.00</dd>
                </div>
                <div className="rounded-xl border border-line bg-white/[0.03] p-3">
                  <dt className="text-[10px] uppercase tracking-[0.12em] text-muted">Works offline</dt>
                  <dd className="mt-1 text-sm font-semibold text-cream">Always</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>
      </section>

      {/* METHOD */}
      <section id="method" className="scroll-mt-20 border-y border-line bg-ink-2/40">
        <div className="shell py-16 lg:py-24">
          <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
            <div className="max-w-2xl">
              <p className="eyebrow">Built on learning science</p>
              <h2 className="display mt-3 text-3xl sm:text-4xl lg:text-[2.9rem]">
                Four principles. Every card obeys them.
              </h2>
            </div>
            <p className="max-w-sm text-[13px] leading-relaxed text-muted">
              The generator is opinionated on purpose: atomic cards, honest grading, mixed sessions
              and prompts that force explanation.
            </p>
          </div>

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {METHOD.map((item) => (
              <div key={item.title} className="card p-5">
                <span className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-white/5 text-lime">
                  <item.icon className="h-4 w-4" />
                </span>
                <h3 className="mt-4 text-[14.5px] font-semibold text-cream">{item.title}</h3>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">{item.body}</p>
              </div>
            ))}
          </div>

          <div className="mt-5 grid gap-4 lg:grid-cols-2">
            <div className="card-flat p-5">
              <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted">
                Example recall prompt generated from a source
              </p>
              <p className="mt-3 font-display text-lg leading-snug text-cream">
                “How are <span className="text-lime">working memory</span> and{" "}
                <span className="text-lime">long-term memory</span> connected? Which one depends on
                the other?”
              </p>
              <p className="mt-3 text-[11.5px] leading-relaxed text-muted">
                Answer out loud, then check the source. Recall marks the card against your own
                honesty, not a keyword match.
              </p>
            </div>
            <div className="card-flat p-5">
              <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted">
                Grading drives the interval
              </p>
              <div className="mt-3 grid grid-cols-4 gap-2 text-center">
                {[
                  { label: "Again", tone: "text-coral", value: "10 min" },
                  { label: "Hard", tone: "text-cream", value: "×1.2" },
                  { label: "Good", tone: "text-lime", value: "×ease" },
                  { label: "Easy", tone: "text-violet", value: "×ease×1.3" },
                ].map((grade) => (
                  <div key={grade.label} className="rounded-lg border border-line bg-ink/60 px-1 py-2">
                    <p className={`text-[11px] font-semibold ${grade.tone}`}>{grade.label}</p>
                    <p className="mt-0.5 font-mono text-[10px] text-muted">{grade.value}</p>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] leading-relaxed text-muted">
                Ease is clamped between 1.3 and 3.2, intervals cap at a year. A lapsed card resets to
                ten minutes — no pretending you knew it.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* DELIVERABLES */}
      <section className="shell py-16 lg:py-24">
        <div className="max-w-2xl">
          <p className="eyebrow">One upload, seven artefacts</p>
          <h2 className="display mt-3 text-3xl sm:text-4xl lg:text-[2.9rem]">
            What you get out of a single PDF.
          </h2>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {DELIVERABLES.map((item) => (
            <div key={item.title} className="card p-5">
              <span className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-white/5 text-lime">
                <item.icon className="h-4 w-4" />
              </span>
              <h3 className="mt-4 text-[14.5px] font-semibold text-cream">{item.title}</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* BUILT ON */}
      <section id="built-on" className="scroll-mt-20 border-y border-line bg-ink-2/40">
        <div className="shell py-16 lg:py-20">
          <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div className="max-w-xl">
              <p className="eyebrow">Open source first</p>
              <h2 className="display mt-3 text-3xl sm:text-4xl">
                Standing on proven, permissively licensed work.
              </h2>
            </div>
            <p className="max-w-sm text-[12.5px] leading-relaxed text-muted">
              No black-box parsers. Each dependency below is auditable, and the learning algorithm is
              published research rather than a proprietary score.
            </p>
          </div>
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {BUILT_ON.map((item) => (
              <div
                key={item.name}
                className="flex items-start justify-between gap-3 rounded-xl border border-line bg-white/[0.03] p-3.5"
              >
                <div>
                  <p className="text-[13px] font-semibold text-cream">{item.name}</p>
                  <p className="mt-0.5 text-[11.5px] text-muted">{item.note}</p>
                </div>
                <span className="shrink-0 rounded-md border border-line px-1.5 py-0.5 font-mono text-[9.5px] text-muted">
                  {item.license}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING TEASER */}
      <section className="shell py-16 lg:py-24">
        <div className="grid gap-5 lg:grid-cols-2">
          <div className="card p-6 sm:p-8">
            <span className="chip">Free · forever</span>
            <h3 className="display mt-4 text-3xl text-cream">$0</h3>
            <p className="mt-2 text-[13px] leading-relaxed text-muted">
              Everything the rules engine can produce, with no document cap and no watermark.
            </p>
            <ul className="mt-5 space-y-2 text-[12.5px] text-muted">
              {[
                "Unlimited PDFs and pasted text",
                "Flashcards, cloze, quiz, study plan",
                "Spaced repetition + daily queue",
                "CSV / JSON / Markdown export",
              ].map((line) => (
                <li key={line} className="flex gap-2">
                  <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime" /> {line}
                </li>
              ))}
            </ul>
            <Link href="/login?mode=signup" className="btn btn-ghost mt-6 w-full sm:w-auto">
              Create free account
            </Link>
          </div>

          <div className="card glow-lime relative overflow-hidden p-6 sm:p-8">
            <div className="flex items-center justify-between gap-2">
              <span className="chip chip-lime">
                <Flame className="h-3 w-3" /> Pro
              </span>
              <span className="text-[11px] text-muted">AI credits included</span>
            </div>
            <h3 className="display mt-4 text-3xl text-cream">
              $9<span className="ml-1 text-base text-muted">/month</span>
            </h3>
            <p className="mt-2 text-[13px] leading-relaxed text-muted">
              Adds the AI layer on top of everything above. Cancel anytime; the free engine and your
              decks stay.
            </p>
            <ul className="mt-5 space-y-2 text-[12.5px] text-muted">
              {[
                "40 AI credits per month, 1 per document",
                "AI-rewritten cards + tighter summaries",
                "Extra teach-it-back prompts",
                "Priority processing",
              ].map((line) => (
                <li key={line} className="flex gap-2">
                  <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-violet" /> {line}
                </li>
              ))}
            </ul>
            <Link href="/pricing" className="btn btn-primary mt-6 w-full sm:w-auto">
              View plans <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="shell pb-8">
        <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr]">
          <div>
            <p className="eyebrow">Straight answers</p>
            <h2 className="display mt-3 text-3xl sm:text-4xl">Questions worth asking.</h2>
            <p className="mt-3 text-[13px] leading-relaxed text-muted">
              This build is a working product with a demo auth and billing layer. The architecture is
              ready for Supabase and Stripe.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <span className="chip">
                <ShieldCheck className="h-3 w-3" /> HTTP-only sessions
              </span>
              <span className="chip">
                <Lock className="h-3 w-3" /> No keys in the bundle
              </span>
            </div>
          </div>
          <div className="space-y-2.5">
            {FAQ.map((item) => (
              <details
                key={item.q}
                className="group rounded-2xl border border-line bg-white/[0.025] px-4 py-3.5 sm:px-5"
              >
                <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-[13.5px] font-medium text-cream">
                  {item.q}
                  <span className="text-lime transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-2.5 text-[12.5px] leading-relaxed text-muted">{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="shell pb-8">
        <div className="card relative overflow-hidden px-6 py-10 text-center sm:px-10 sm:py-14">
          <div className="aurora opacity-60" />
          <div className="relative">
            <p className="eyebrow">Close the PDF. Open the deck.</p>
            <h2 className="display mx-auto mt-3 max-w-2xl text-3xl sm:text-4xl lg:text-[2.9rem]">
              You already have the material. Start remembering it.
            </h2>
            <div className="mt-6 flex flex-col justify-center gap-2.5 sm:flex-row">
              <Link href="/login?mode=signup" className="btn btn-primary">
                Create a free account <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/login" className="btn btn-ghost">
                Use the demo login
              </Link>
            </div>
            <p className="mt-4 text-[11.5px] text-muted">
              Demo credentials are pre-filled on the sign-in page. No email, no card.
            </p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
