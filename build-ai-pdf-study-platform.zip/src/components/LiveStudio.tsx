"use client";

import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Eraser, RotateCcw, Sparkles, Wand2 } from "lucide-react";
import { previewAnalysis } from "@/lib/memory/engine";
import { SAMPLE_TEXT, SAMPLE_TITLE } from "@/lib/memory/sample";

const KIND_TONE: Record<string, string> = {
  cloze: "text-lime border-lime/30 bg-lime/10",
  definition: "text-violet border-violet/30 bg-violet/10",
  fact: "text-coral border-coral/30 bg-coral/10",
  list: "text-cream border-white/15 bg-white/5",
  concept: "text-muted border-line bg-white/5",
};

export default function LiveStudio() {
  const [text, setText] = useState(SAMPLE_TEXT.slice(0, 1450));
  const [title, setTitle] = useState("Paste your own notes");
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);

  const result = useMemo(() => previewAnalysis(text || " ", title || "Untitled"), [text, title]);
  const cards = result.cards.slice(0, 8);
  const card = cards[Math.min(index, cards.length - 1)];

  const reset = (value: string) => {
    setText(value);
    setIndex(0);
    setRevealed(false);
  };

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-lime shadow-[0_0_12px_rgba(201,242,107,.8)]" />
          <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted">
            Live · no account
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="chip chip-lime">
            <Wand2 className="h-3 w-3" /> Rules engine
          </span>
          <span className="chip hidden sm:inline-flex">0 API calls</span>
        </div>
      </div>

      <div className="grid gap-0 lg:grid-cols-[0.95fr_1.05fr]">
        <div className="border-b border-line p-4 sm:p-5 lg:border-b-0 lg:border-r">
          <label className="label" htmlFor="demo-title">
            Source title
          </label>
          <input
            id="demo-title"
            className="field mb-3"
            value={title}
            maxLength={90}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Chapter 4 — Cognitive load"
          />
          <label className="label" htmlFor="demo-text">
            Paste any text
          </label>
          <textarea
            id="demo-text"
            value={text}
            onChange={(event) => reset(event.target.value)}
            rows={7}
            spellCheck={false}
            className="field min-h-[150px] resize-y font-mono text-[12.5px] leading-relaxed"
            placeholder="Paste notes, an abstract, a lecture transcript…"
          />
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => {
                setTitle(SAMPLE_TITLE);
                reset(SAMPLE_TEXT.slice(0, 1450));
              }}
            >
              <RotateCcw className="h-3.5 w-3.5" /> Load sample
            </button>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => {
                setTitle("My notes");
                reset("");
              }}
            >
              <Eraser className="h-3.5 w-3.5" /> Clear
            </button>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 border-t border-line pt-4">
            {[
              { label: "Cards", value: result.cards.length },
              { label: "Concepts", value: result.analysis.concepts.length },
              { label: "Read time", value: `${result.analysis.stats.readingMinutes}m` },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-xl leading-none text-cream">{stat.value}</p>
                <p className="mt-1 text-[10px] uppercase tracking-[0.14em] text-muted">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 sm:p-5">
          {card ? (
            <>
              <div className="mb-3 flex items-center justify-between">
                <span
                  className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] ${
                    KIND_TONE[card.kind] ?? KIND_TONE.concept
                  }`}
                >
                  {card.kind}
                </span>
                <span className="text-[11px] text-muted">
                  {index + 1} / {cards.length}
                </span>
              </div>

              <div
                className="animate-flip-in flex min-h-[190px] flex-col justify-between rounded-2xl border border-line bg-ink-2/70 p-4 sm:p-5"
                key={`${card.prompt}-${revealed}`}
              >
                <p className="whitespace-pre-line text-[15px] leading-relaxed text-cream">
                  {card.prompt}
                </p>
                {revealed ? (
                  <div className="mt-4 border-t border-line pt-3">
                    <p className="text-[11px] uppercase tracking-[0.14em] text-muted">Answer</p>
                    <p className="mt-1 text-[15px] font-medium text-lime">{card.answer}</p>
                    <p className="mt-2 text-[11.5px] leading-relaxed text-muted">
                      Hint: {card.hint} · source page {card.page}
                    </p>
                  </div>
                ) : (
                  <div className="mt-4">
                    <p className="text-[12px] text-muted">{card.hint}</p>
                    <button
                      type="button"
                      onClick={() => setRevealed(true)}
                      className="btn btn-primary btn-sm mt-3 w-full sm:w-auto"
                    >
                      Reveal answer
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-3 flex items-center gap-2">
                <button
                  type="button"
                  aria-label="Previous card"
                  className="btn btn-ghost btn-sm"
                  onClick={() => {
                    setIndex((current) => Math.max(0, current - 1));
                    setRevealed(false);
                  }}
                  disabled={index === 0}
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  className="btn btn-ghost btn-sm flex-1"
                  onClick={() => {
                    setIndex((current) => (current + 1) % cards.length);
                    setRevealed(false);
                  }}
                >
                  Next card <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </>
          ) : (
            <div className="grid min-h-[220px] place-items-center rounded-2xl border border-dashed border-line p-6 text-center">
              <div>
                <Sparkles className="mx-auto mb-2 h-5 w-5 text-muted" />
                <p className="text-sm text-muted">
                  Add at least a paragraph and cards appear instantly.
                </p>
              </div>
            </div>
          )}

          <p className="mt-4 text-[11.5px] leading-relaxed text-muted">
            This is the production engine, running locally. Sign in to save the deck, get spaced
            repetition scheduling, a graded quiz and Anki export.
          </p>
        </div>
      </div>
    </div>
  );
}
