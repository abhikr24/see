"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CircleCheck, Loader2, Sparkles, Zap } from "lucide-react";

export default function BillingPanel({
  plan,
  credits,
  aiConfigured,
  provider,
  usage,
}: {
  plan: string;
  credits: number;
  aiConfigured: boolean;
  provider: string | null;
  usage: { id: string; provider: string; model: string; credits: number; status: string; createdAt: string }[];
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function activate() {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ credits: 40 }),
      });
      const data = (await response.json()) as { message?: string; error?: string };
      if (!response.ok) {
        setError(data.error ?? "Could not activate Pro.");
        return;
      }
      setMessage(data.message ?? "Pro activated.");
      router.refresh();
    } catch {
      setError("Network error. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="card p-5">
          <span className="chip">{plan === "pro" ? "Current plan" : "Included"}</span>
          <h2 className="mt-3 text-lg font-semibold text-cream">Free</h2>
          <p className="mt-1 text-[12px] text-muted">
            Deterministic generation. No document limit, no expiry.
          </p>
          <ul className="mt-4 space-y-1.5 text-[11.5px] text-muted">
            {["Unlimited PDFs", "Cards, cloze, quiz", "SM-2 scheduling", "CSV / JSON / MD export"].map(
              (line) => (
                <li key={line} className="flex gap-1.5">
                  <CircleCheck className="mt-0.5 h-3 w-3 shrink-0 text-lime" /> {line}
                </li>
              ),
            )}
          </ul>
        </div>

        <div className="card glow-lime relative overflow-hidden p-5">
          <div className="flex items-center justify-between">
            <span className="chip chip-lime">{plan === "pro" ? "Active" : "Upgrade"}</span>
            <span className="text-[10.5px] text-muted">demo checkout</span>
          </div>
          <h2 className="mt-3 text-lg font-semibold text-cream">Pro</h2>
          <p className="mt-1 text-[12px] text-muted">
            AI-enhanced cards on top of the free engine. One credit per AI document.
          </p>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="display text-2xl">{credits}</span>
            <span className="text-[11px] text-muted">AI credits available</span>
          </div>
          <button type="button" onClick={() => void activate()} className="btn btn-primary btn-sm mt-4 w-full" disabled={busy}>
            {busy ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Activating…
              </>
            ) : (
              <>
                <Zap className="h-3.5 w-3.5" /> Add 40 credits (simulated)
              </>
            )}
          </button>
          <p className="mt-2 text-[10.5px] text-muted">
            No card is charged. Replace this endpoint with Stripe Checkout in production.
          </p>
        </div>
      </div>

      {message && (
        <p className="rounded-xl border border-lime/30 bg-lime/[0.08] px-3 py-2.5 text-[12px] text-lime">
          {message}
        </p>
      )}
      {error && (
        <p className="rounded-xl border border-coral/30 bg-coral/[0.08] px-3 py-2.5 text-[12px] text-coral">
          {error}
        </p>
      )}

      <div className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
            AI provider
          </h2>
          <span className={`text-[11px] ${aiConfigured ? "text-lime" : "text-coral"}`}>
            {aiConfigured ? `${provider} connected` : "No provider key configured"}
          </span>
        </div>
        <p className="mt-2 text-[11.5px] leading-relaxed text-muted">
          {aiConfigured
            ? "AI generations route through your server only. Keys never reach the browser. Provider errors refund the credit automatically."
            : "Add OPENAI_API_KEY (or ANTHROPIC_API_KEY, GROQ_API_KEY, OPENROUTER_API_KEY) to the server environment to turn the AI engine on. The free rules engine keeps working either way."}
        </p>

        <h3 className="mt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted">
          Recent AI usage
        </h3>
        {usage.length === 0 ? (
          <p className="mt-2 text-[11.5px] text-muted">No AI generations yet.</p>
        ) : (
          <ul className="mt-2 divide-y divide-line/60">
            {usage.map((event) => (
              <li key={event.id} className="flex items-center justify-between gap-2 py-2 text-[11.5px]">
                <span className="inline-flex items-center gap-1.5 text-cream/85">
                  <Sparkles className="h-3 w-3 text-violet" /> {event.provider}
                  <span className="text-muted">· {event.model}</span>
                </span>
                <span className="text-muted">
                  {event.credits} credit · {new Date(event.createdAt).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
