"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, CircleCheck, CircleX, Loader2, RotateCcw, Trophy } from "lucide-react";
import type { StudyCard } from "@/lib/ui-types";
import { KIND_LABEL } from "@/lib/ui-types";

type Props = { cards: StudyCard[]; documentId: string };

function hash(value: string) {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export default function QuizPanel({ cards, documentId }: Props) {
  const questions = useMemo(() => {
    const eligible = cards.filter((card) => card.options.length >= 3 && card.answer.length > 0);
    return [...eligible]
      .sort((a, b) => hash(a.id) - hash(b.id))
      .slice(0, 10)
      .map((card) => ({
        ...card,
        options: [...card.options].sort((a, b) => hash(a + card.id) - hash(b + card.id)).slice(0, 4),
      }));
  }, [cards]);

  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answers, setAnswers] = useState<{ id: string; correct: boolean }[]>([]);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  const done = index >= questions.length;
  const score = answers.filter((answer) => answer.correct).length;

  useEffect(() => {
    if (!done || saved || saving || questions.length === 0) return;
    setSaving(true);
    fetch("/api/quiz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ documentId, score, total: questions.length }),
    })
      .catch(() => null)
      .finally(() => {
        setSaving(false);
        setSaved(true);
      });
  }, [done, saved, saving, score, questions.length, documentId]);

  if (questions.length === 0) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm text-muted">
          Quiz questions need multiple-choice options. Add a longer source to unlock this tab.
        </p>
      </div>
    );
  }

  const question = questions[index];

  function choose(option: string) {
    if (selected) return;
    setSelected(option);
    setAnswers((current) => [
      ...current,
      { id: question.id, correct: option.trim().toLowerCase() === question.answer.trim().toLowerCase() },
    ]);
  }

  if (done) {
    const pct = Math.round((score / questions.length) * 100);
    return (
      <div className="card p-6 text-center sm:p-8">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-lime/30 bg-lime/10 text-lime">
          <Trophy className="h-5 w-5" />
        </span>
        <h3 className="display mt-4 text-3xl">
          {score} / {questions.length}
        </h3>
        <p className="mt-1 text-[12.5px] text-muted">
          {pct >= 80
            ? "Strong first pass. The cards you missed are already scheduled sooner."
            : pct >= 50
              ? "Reasonable. Run the review queue once more before moving on."
              : "Below half means the material needs another pass — that is data, not failure."}
        </p>
        <div className="mx-auto mt-5 h-2 max-w-sm overflow-hidden rounded-full bg-white/8">
          <div className="h-full rounded-full bg-lime" style={{ width: `${pct}%` }} />
        </div>
        <button
          type="button"
          className="btn btn-ghost btn-sm mt-5"
          onClick={() => {
            setIndex(0);
            setAnswers([]);
            setSelected(null);
            setSaved(false);
          }}
        >
          <RotateCcw className="h-3.5 w-3.5" /> Retake quiz
        </button>
      </div>
    );
  }

  const correct = selected?.trim().toLowerCase() === question.answer.trim().toLowerCase();

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-[11px] text-muted">
        <span>
          Question {index + 1} of {questions.length} · {KIND_LABEL[question.kind] ?? question.kind}
        </span>
        <span>{score} correct</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/8">
        <div
          className="h-full rounded-full bg-lime transition-all"
          style={{ width: `${Math.round((index / questions.length) * 100)}%` }}
        />
      </div>

      <div className="card p-4 sm:p-6">
        <p className="whitespace-pre-line text-[15px] leading-relaxed text-cream">{question.prompt}</p>

        <div className="mt-4 space-y-2">
          {question.options.map((option) => {
            const isAnswer = option.trim().toLowerCase() === question.answer.trim().toLowerCase();
            const isPicked = selected === option;
            const tone = !selected
              ? "border-line bg-white/[0.025] hover:border-white/25 hover:bg-white/[0.05]"
              : isAnswer
                ? "border-lime/50 bg-lime/10"
                : isPicked
                  ? "border-coral/50 bg-coral/10"
                  : "border-line bg-white/[0.02] opacity-60";
            return (
              <button
                key={option}
                type="button"
                onClick={() => choose(option)}
                disabled={Boolean(selected)}
                className={`flex w-full items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left text-[13px] leading-relaxed text-cream transition ${tone}`}
              >
                <span className="mt-0.5">
                  {selected ? (
                    isAnswer ? (
                      <CircleCheck className="h-4 w-4 text-lime" />
                    ) : isPicked ? (
                      <CircleX className="h-4 w-4 text-coral" />
                    ) : (
                      <span className="block h-4 w-4 rounded-full border border-line" />
                    )
                  ) : (
                    <span className="block h-4 w-4 rounded-full border border-line" />
                  )}
                </span>
                {option}
              </button>
            );
          })}
        </div>

        {selected && (
          <div className="animate-flip-in mt-4 space-y-2">
            <p className={`text-[12.5px] font-semibold ${correct ? "text-lime" : "text-coral"}`}>
              {correct ? "Correct." : `Not quite — the answer is “${question.answer}”.`}
            </p>
            {question.quote && (
              <p className="rounded-lg border border-line bg-white/[0.02] p-2.5 text-[11.5px] leading-relaxed text-muted">
                Source, page {question.page}: {question.quote}
              </p>
            )}
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => {
                setIndex((current) => current + 1);
                setSelected(null);
              }}
            >
              {index + 1 === questions.length ? "See results" : "Next question"}
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {saving && (
          <p className="mt-3 flex items-center gap-1.5 text-[11px] text-muted">
            <Loader2 className="h-3 w-3 animate-spin" /> Saving attempt…
          </p>
        )}
      </div>
    </div>
  );
}
