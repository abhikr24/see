"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowRight,
  CircleCheck,
  FileText,
  FileUp,
  Loader2,
  Lock,
  Sparkles,
  Upload,
  Wand2,
  X,
} from "lucide-react";

type Props = {
  plan: string;
  aiCredits: number;
  aiConfigured: boolean;
  provider: string | null;
};

export default function UploadStudio({ plan, aiCredits, aiConfigured, provider }: Props) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [tab, setTab] = useState<"file" | "paste">("file");
  const [file, setFile] = useState<File | null>(null);
  const [text, setText] = useState("");
  const [title, setTitle] = useState("");
  const [engine, setEngine] = useState<"rules" | "ai">("rules");
  const [cardCount, setCardCount] = useState(24);
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  const canUseAi = plan === "pro" && aiCredits > 0;
  const stages = [
    "Reading the document",
    "Cleaning headers and page artefacts",
    "Ranking concepts",
    "Writing cards + distractors",
    engine === "ai" ? "Enhancing with AI" : "Scheduling with SM-2",
  ];

  function pickFile(next: File | null) {
    setError(null);
    if (!next) return;
    const lower = next.name.toLowerCase();
    if (!/\.(pdf|txt|md|markdown)$/.test(lower)) {
      setError("Use a PDF, TXT or Markdown file. For anything else, paste the text.");
      return;
    }
    if (next.size > 12 * 1024 * 1024) {
      setError("That file is larger than 12 MB. Split it or paste the useful chapters.");
      return;
    }
    setFile(next);
    if (!title) setTitle(next.name.replace(/\.[^.]+$/, ""));
  }

  async function generate() {
    setError(null);
    setNote(null);

    if (tab === "file" && !file) {
      setError("Choose a PDF, TXT or Markdown file first.");
      return;
    }
    if (tab === "paste" && text.trim().length < 60) {
      setError("Paste at least a few sentences so the engine has something to work with.");
      return;
    }
    if (engine === "ai" && !canUseAi) {
      setError(
        plan === "pro"
          ? "You are out of AI credits. Switch to the free engine or top up in Billing."
          : "The AI engine is a Pro feature. The rules engine is free and unlimited.",
      );
      return;
    }

    setBusy(true);
    setStage(0);
    const ticker = setInterval(() => setStage((current) => Math.min(current + 1, stages.length - 1)), 900);

    try {
      let response: Response;
      if (tab === "file" && file) {
        const form = new FormData();
        form.set("file", file);
        form.set("title", title || file.name);
        form.set("engine", engine);
        form.set("cardCount", String(cardCount));
        response = await fetch("/api/documents", { method: "POST", body: form });
      } else {
        response = await fetch("/api/documents", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text, title: title || "Pasted notes", engine, cardCount }),
        });
      }

      const data = (await response.json()) as {
        id?: string;
        error?: string;
        aiNote?: string | null;
        warnings?: string[];
      };
      clearInterval(ticker);

      if (!response.ok || !data.id) {
        setError(data.error ?? "We could not process that source. Try a smaller file or paste the text.");
        setBusy(false);
        return;
      }

      if (data.aiNote) {
        setNote(data.aiNote);
        setBusy(false);
        router.push(`/app/documents/${data.id}`);
        return;
      }
      router.push(`/app/documents/${data.id}`);
      router.refresh();
    } catch {
      clearInterval(ticker);
      setError("Network error while generating. Please try again.");
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="card overflow-hidden">
        <div className="flex border-b border-line">
          {(["file", "paste"] as const).map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => {
                setTab(option);
                setError(null);
              }}
              className={`flex flex-1 items-center justify-center gap-2 px-4 py-3 text-[12.5px] font-semibold transition ${
                tab === option
                  ? "bg-lime/10 text-lime"
                  : "text-muted hover:bg-white/[0.03] hover:text-cream"
              }`}
            >
              {option === "file" ? <FileUp className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
              {option === "file" ? "Upload a file" : "Paste text"}
            </button>
          ))}
        </div>

        <div className="space-y-5 p-4 sm:p-6">
          {tab === "file" ? (
            <div>
              <div
                onDragOver={(event) => {
                  event.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={(event) => {
                  event.preventDefault();
                  setDragging(false);
                  pickFile(event.dataTransfer.files?.[0] ?? null);
                }}
                onClick={() => inputRef.current?.click()}
                role="button"
                tabIndex={0}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") inputRef.current?.click();
                }}
                className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed px-4 py-10 text-center transition ${
                  dragging
                    ? "border-lime/70 bg-lime/5"
                    : "border-line bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.04]"
                }`}
              >
                <span className="grid h-12 w-12 place-items-center rounded-2xl border border-line bg-white/5 text-lime">
                  <Upload className="h-5 w-5" />
                </span>
                <p className="mt-3.5 text-[13.5px] font-medium text-cream">
                  Drop a PDF here, or tap to browse
                </p>
                <p className="mt-1 text-[11.5px] text-muted">
                  PDF · TXT · MD · up to 12 MB · processed on the server
                </p>
                <input
                  ref={inputRef}
                  type="file"
                  accept=".pdf,.txt,.md,.markdown,application/pdf,text/plain,text/markdown"
                  className="hidden"
                  onChange={(event) => pickFile(event.target.files?.[0] ?? null)}
                />
              </div>

              {file && (
                <div className="mt-3 flex items-center gap-3 rounded-xl border border-line bg-white/[0.03] p-3">
                  <FileText className="h-4 w-4 shrink-0 text-lime" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-medium text-cream">{file.name}</p>
                    <p className="text-[10.5px] text-muted">{(file.size / 1024).toFixed(0)} KB</p>
                  </div>
                  <button
                    type="button"
                    aria-label="Remove file"
                    onClick={() => setFile(null)}
                    className="rounded-lg p-1.5 text-muted hover:bg-white/5 hover:text-coral"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div>
              <label className="label" htmlFor="paste-text">
                Source text
              </label>
              <textarea
                id="paste-text"
                value={text}
                onChange={(event) => setText(event.target.value)}
                rows={10}
                spellCheck={false}
                placeholder="Paste a chapter, lecture notes, an article, a transcript…"
                className="field min-h-[200px] resize-y text-[13px] leading-relaxed"
              />
              <p className="mt-1.5 text-[11px] text-muted">
                {text.trim().split(/\s+/).filter(Boolean).length.toLocaleString()} words ·{" "}
                {text.length.toLocaleString()} / 400,000 characters
              </p>
            </div>
          )}

          <div>
            <label className="label" htmlFor="doc-title">
              Title
            </label>
            <input
              id="doc-title"
              className="field"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="e.g. Neuroscience — Chapter 4"
              maxLength={140}
            />
          </div>

          <div>
            <span className="label">Engine</span>
            <div className="grid gap-2.5 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setEngine("rules")}
                className={`rounded-xl border p-3.5 text-left transition ${
                  engine === "rules"
                    ? "border-lime/60 bg-lime/[0.07]"
                    : "border-line bg-white/[0.02] hover:border-white/20"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-[12.5px] font-semibold text-cream">
                    <Wand2 className="h-4 w-4 text-lime" /> Rules engine
                  </span>
                  <span className="rounded-full bg-lime/15 px-2 py-0.5 text-[9.5px] font-bold uppercase text-lime">
                    Free
                  </span>
                </div>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-muted">
                  Deterministic cards, cloze, MCQs and scheduling. No credits, no limits.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setEngine("ai")}
                className={`rounded-xl border p-3.5 text-left transition ${
                  engine === "ai"
                    ? "border-violet/60 bg-violet/[0.08]"
                    : "border-line bg-white/[0.02] hover:border-white/20"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-[12.5px] font-semibold text-cream">
                    <Sparkles className="h-4 w-4 text-violet" /> AI enhanced
                  </span>
                  <span className="rounded-full bg-white/10 px-2 py-0.5 text-[9.5px] font-bold uppercase text-cream">
                    {plan === "pro" ? `${aiCredits} cr` : "Pro"}
                  </span>
                </div>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-muted">
                  {canUseAi
                    ? "AI rewrites and expands the deck on top of the rules engine. Uses 1 credit."
                    : plan === "pro"
                      ? "No credits left. Top up in Billing."
                      : "Paid upgrade. Falls back to the free engine if the provider fails."}
                </p>
              </button>
            </div>

            {engine === "ai" && !canUseAi && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-violet/30 bg-violet/[0.08] p-3">
                <p className="text-[11.5px] text-cream/85">
                  AI is a Pro feature. Your free deck is still one click away.
                </p>
                <Link href="/app/billing" className="btn btn-primary btn-sm">
                  Activate Pro (demo) <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            )}

            {engine === "ai" && canUseAi && !aiConfigured && (
              <p className="mt-3 rounded-xl border border-coral/25 bg-coral/[0.07] p-3 text-[11.5px] leading-relaxed text-coral">
                The server has no AI provider key configured. Recall will still generate a complete
                rules-based deck and will not charge a credit. Add OPENAI_API_KEY (or another
                provider key) to enable the AI layer.
              </p>
            )}
            {engine === "ai" && canUseAi && aiConfigured && (
              <p className="mt-3 text-[11px] text-muted">
                Provider connected: <span className="text-cream">{provider}</span>. One credit per
                successful generation.
              </p>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between">
              <span className="label mb-0">Cards to generate</span>
              <span className="font-mono text-[11.5px] text-lime">{cardCount}</span>
            </div>
            <input
              type="range"
              min={8}
              max={48}
              step={4}
              value={cardCount}
              onChange={(event) => setCardCount(Number(event.target.value))}
              className="mt-2 w-full accent-[#c9f26b]"
            />
            <div className="mt-1 flex justify-between text-[10px] text-muted">
              <span>Quick pass</span>
              <span>Full deck</span>
            </div>
          </div>

          {error && (
            <p className="rounded-xl border border-coral/30 bg-coral/[0.08] px-3 py-2.5 text-[12.5px] leading-relaxed text-coral">
              {error}
            </p>
          )}
          {note && (
            <p className="rounded-xl border border-line bg-white/[0.04] px-3 py-2.5 text-[12px] text-cream/80">
              {note}
            </p>
          )}

          <button type="button" onClick={() => void generate()} disabled={busy} className="btn btn-primary w-full">
            {busy ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Building your deck…
              </>
            ) : (
              <>
                Generate memory material <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>

          {busy && (
            <ul className="space-y-1.5 rounded-xl border border-line bg-white/[0.02] p-3">
              {stages.map((label, index) => (
                <li
                  key={label}
                  className={`flex items-center gap-2 text-[11.5px] ${
                    index <= stage ? "text-cream" : "text-muted/60"
                  }`}
                >
                  {index < stage ? (
                    <CircleCheck className="h-3.5 w-3.5 text-lime" />
                  ) : (
                    <Loader2 className={`h-3.5 w-3.5 ${index === stage ? "animate-spin text-lime" : ""}`} />
                  )}
                  {label}
                </li>
              ))}
            </ul>
          )}

          <p className="flex items-start gap-2 text-[11px] leading-relaxed text-muted">
            <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime" />
            {engine === "ai"
              ? "With AI selected, up to 18,000 characters of your document are sent to the configured provider. The free engine never leaves this server."
              : "The free engine processes everything on this server. Nothing is sent to a third party."}
          </p>
        </div>
      </div>
    </div>
  );
}
