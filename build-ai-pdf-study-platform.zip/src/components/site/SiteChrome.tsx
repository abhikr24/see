import Link from "next/link";
import { ArrowUpRight, Boxes, Lock } from "lucide-react";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label="Recall home">
      <span className="relative grid h-9 w-9 place-items-center rounded-[11px] bg-lime text-[15px] font-bold text-ink">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden>
          <path
            d="M6 4.5h8.2c2.6 0 4.3 1.6 4.3 4s-1.7 4.1-4.3 4.1H9.6V20H6V4.5Z"
            fill="currentColor"
            opacity="0.92"
          />
          <path d="M11 12.6 16.6 20H12.6L8.9 15.1 11 12.6Z" fill="currentColor" />
        </svg>
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="text-[17px] font-semibold tracking-tight text-cream">Recall</span>
          <span className="mt-0.5 text-[10px] uppercase tracking-[0.18em] text-muted">
            memory engine
          </span>
        </span>
      )}
    </Link>
  );
}

const NAV = [
  { href: "/#engine", label: "Engines" },
  { href: "/#method", label: "Method" },
  { href: "/#built-on", label: "Open source" },
  { href: "/pricing", label: "Pricing" },
];

export function SiteNav({ authed = false }: { authed?: boolean }) {
  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-ink/75 backdrop-blur-xl">
      <div className="shell flex h-16 items-center justify-between gap-4">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-full px-3.5 py-2 text-[13px] text-muted transition hover:bg-white/5 hover:text-cream"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {authed ? (
            <Link href="/app" className="btn btn-primary btn-sm">
              Open studio <ArrowUpRight className="h-4 w-4" />
            </Link>
          ) : (
            <>
              <Link href="/login" className="btn btn-ghost btn-sm hidden sm:inline-flex">
                Sign in
              </Link>
              <Link href="/login?mode=signup" className="btn btn-primary btn-sm">
                Start free
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-line bg-ink">
      <div className="shell grid gap-10 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
            Recall turns static documents into retrieval practice. The rules engine is free forever
            and works with any text. AI is an optional, metered upgrade.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <span className="chip">
              <Lock className="h-3 w-3" /> Server-side keys only
            </span>
            <span className="chip">
              <Boxes className="h-3 w-3" /> MIT / Apache components
            </span>
          </div>
        </div>
        <div>
          <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.16em] text-cream">
            Product
          </h3>
          <ul className="space-y-2 text-sm text-muted">
            <li>
              <Link className="hover:text-cream" href="/#engine">
                Two engines
              </Link>
            </li>
            <li>
              <Link className="hover:text-cream" href="/#method">
                Learning science
              </Link>
            </li>
            <li>
              <Link className="hover:text-cream" href="/pricing">
                Pricing
              </Link>
            </li>
            <li>
              <Link className="hover:text-cream" href="/login">
                Demo login
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.16em] text-cream">
            Deployment
          </h3>
          <ul className="space-y-2 text-sm text-muted">
            <li>Next.js App Router</li>
            <li>PostgreSQL + Drizzle (included)</li>
            <li>Supabase auth adapter (env switch)</li>
            <li>Provider-agnostic AI layer</li>
          </ul>
        </div>
      </div>
      <div className="shell flex flex-col gap-2 border-t border-line py-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>© {new Date().getFullYear()} Recall. Built for people who actually have to remember things.</p>
        <p>Demo environment · payments simulated</p>
      </div>
    </footer>
  );
}
