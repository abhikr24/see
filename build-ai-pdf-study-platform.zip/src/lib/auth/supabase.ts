/**
 * Optional Supabase auth adapter. Server-only.
 *
 * We talk to Supabase Auth (GoTrue) over HTTPS with the service credentials kept
 * in process.env. Nothing here is ever bundled for the browser: no NEXT_PUBLIC
 * variables are used, and our own httpOnly cookies wrap the Supabase tokens.
 *
 * Enable with: AUTH_PROVIDER=supabase + SUPABASE_URL + SUPABASE_ANON_KEY
 * (SUPABASE_SERVICE_ROLE_KEY is optional, for admin tasks).
 */

export type SupabaseTokens = {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
};

export type SupabaseUser = {
  id: string;
  email: string;
  name: string;
};

type SupabaseConfig = { url: string; key: string };

export function supabaseConfig(): SupabaseConfig | null {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  return { url: url.replace(/\/$/, ""), key };
}

export function supabaseEnabled(): boolean {
  return process.env.AUTH_PROVIDER === "supabase" && Boolean(supabaseConfig());
}

async function request(path: string, init: RequestInit = {}) {
  const config = supabaseConfig();
  if (!config) throw new Error("Supabase is not configured");
  const response = await fetch(`${config.url}/auth/v1${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      apikey: config.key,
      Authorization: `Bearer ${config.key}`,
      ...(init.headers ?? {}),
    },
    cache: "no-store",
  });
  const payload = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  if (!response.ok) {
    const message =
      (payload.msg as string) || (payload.error_description as string) || "Supabase auth failed";
    throw new Error(message);
  }
  return payload;
}

function toUser(payload: Record<string, unknown>): SupabaseUser {
  const raw = (payload.user ?? payload) as Record<string, unknown>;
  const email = String(raw.email ?? "");
  const metadata = (raw.user_metadata ?? {}) as Record<string, unknown>;
  return {
    id: String(raw.id ?? email),
    email,
    name: String(metadata.name ?? email.split("@")[0] ?? "Learner"),
  };
}

function toTokens(payload: Record<string, unknown>): SupabaseTokens {
  return {
    accessToken: String(payload.access_token ?? ""),
    refreshToken: String(payload.refresh_token ?? ""),
    expiresIn: Number(payload.expires_in ?? 3600),
  };
}

export async function supabaseSignIn(email: string, password: string) {
  const payload = await request("/token?grant_type=password", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
  return { user: toUser(payload), tokens: toTokens(payload) };
}

export async function supabaseSignUp(name: string, email: string, password: string) {
  const payload = await request("/signup", {
    method: "POST",
    body: JSON.stringify({ email, password, data: { name } }),
  });
  return { user: toUser(payload), tokens: payload.access_token ? toTokens(payload) : null };
}

export async function supabaseRefresh(refreshToken: string) {
  const payload = await request("/token?grant_type=refresh_token", {
    method: "POST",
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  return { user: toUser(payload), tokens: toTokens(payload) };
}

export async function supabaseGetUser(accessToken: string) {
  const payload = await request("/user", {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return toUser(payload);
}

export async function supabaseSignOut(accessToken: string) {
  try {
    await request("/logout", { method: "POST", headers: { Authorization: `Bearer ${accessToken}` } });
  } catch {
    // Logging out locally is always safe even if the remote call fails.
  }
}
