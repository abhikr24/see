import type {
  Analysis,
  AnalyzeResult,
  CardKind,
  Concept,
  MemoryCard,
  SourceInput,
} from "./types";

/* ------------------------------------------------------------------ */
/* Deterministic helpers (seeded, so SSR and client output always match) */
/* ------------------------------------------------------------------ */

export function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seededShuffle<T>(items: T[], seed: number): T[] {
  const rand = mulberry32(seed);
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

const STOPWORDS = new Set(
  `a about above after again against all am an and any are aren't as at be because been before being below between both but by can cannot could couldn't did didn't do does doesn't doing don't down during each few for from further had hadn't has hasn't have haven't having he her here hers herself him himself his how i if in into is isn't it its itself let's me more most mustn't my myself no nor not of off on once only or other ought our ours ourselves out over own same shan't she should shouldn't so some such than that the their theirs them themselves then there these they this those through to too under until up very was wasn't we were weren't what when where which while who whom why will with won't would wouldn't you your yours yourself yourselves also may might must shall can upon within without among across per via etc ie eg thus therefore however moreover furthermore although though since unless whether both either neither one two three many much several often always never sometimes usually new using used use based given able well make makes made first second third next last according example examples figure table chapter section page fig et al`
    .split(/\s+/)
    .filter(Boolean),
);

const GENERIC_TERMS = new Set(
  `material materials student students people person thing things way ways part parts kind kinds fact facts case cases number numbers example examples study studies research paper papers text source author authors chapter section figure table result results important different various many much often usually generally actually really simply problem problems question questions answer answers topic topics content contents point points idea ideas`.split(
    /\s+/,
  ),
);

const CLAUSE_WORDS =
  /\b(that|which|who|whom|whose|if|when|while|because|why|how|what|but|and|or|not|it|its|this|these|those|there|their|they|he|she|we|you|i|would|could|should|can|will|is|are|was|were|has|have|had|do|does|did|might|must|yourself|myself|themselves|itself|ourselves|yourself)\b/i;

const LOW_VALUE_ANSWERS = new Set(
  `time times year years day days week weeks month months people things thing way ways part parts kind kinds fact facts case cases number numbers student students someone something anyone everything nothing always often usually`.split(
    /\s+/,
  ),
);

const CUE_BOOSTS: Array<[RegExp, number]> = [
  [/\b(is|are|was|were) (defined|known) as\b/i, 2.4],
  [/\b(refers? to|means?|describes?|consists? of|comprises?)\b/i, 2.2],
  [/\b(because|therefore|as a result|consequently|leads? to|causes?|results? in)\b/i, 1.6],
  [/\b(important|key|critical|essential|fundamental|primary|core|principle)\b/i, 1.5],
  [/\b(first|second|third|finally|next|then)\b/i, 1.2],
  [/\b\d{1,4}(?:[.,]\d+)?\s?(?:%|percent|kg|km|m|cm|mm|ms|s|hours?|days?|years?|million|billion)\b/i, 1.5],
  [/\b(compare|contrast|difference|unlike|whereas|instead)\b/i, 1.3],
  [/\b(for example|such as|e\.g\.|including|includes?)\b/i, 1.1],
];

const ABBREVIATIONS = [
  "e.g.",
  "i.e.",
  "etc.",
  "vs.",
  "fig.",
  "no.",
  "dr.",
  "mr.",
  "mrs.",
  "ms.",
  "prof.",
  "inc.",
  "ltd.",
  "approx.",
  "cf.",
  "al.",
  "st.",
  "jr.",
  "sr.",
  "u.s.",
  "u.k.",
  "d.c.",
];

export function normalizeWhitespace(value: string): string {
  return value
    .replace(/\u00ad/g, "")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .trim();
}

/** Clean a PDF page: de-hyphenate line wraps, drop page numbers and repeated furniture. */
export function cleanPages(pages: string[]): { page: number; text: string }[] {
  const raw = pages.map((page) =>
    page
      .split(/\r?\n/)
      .map((line) => normalizeWhitespace(line))
      .filter((line) => line.length > 0)
      .filter((line) => !/^[\s\d.,|/\\:;•·\-–—_]+$/.test(line)),
  );

  const edgeCounts = new Map<string, number>();
  raw.forEach((lines) => {
    [lines[0], lines[lines.length - 1]].forEach((line) => {
      if (!line || line.length > 90) return;
      edgeCounts.set(line, (edgeCounts.get(line) ?? 0) + 1);
    });
  });

  return raw.map((lines, index) => {
    const kept = lines.filter((line) => {
      const count = edgeCounts.get(line) ?? 0;
      return !(count >= 2 && count >= Math.ceil(raw.length * 0.4));
    });
    let text = "";
    kept.forEach((line) => {
      if (!text) {
        text = line;
      } else if (text.endsWith("-")) {
        text = text.slice(0, -1) + line;
      } else {
        text = `${text} ${line}`;
      }
    });
    return { page: index + 1, text: normalizeWhitespace(text) };
  });
}

export function splitSentences(text: string): string[] {
  let guarded = text;
  ABBREVIATIONS.forEach((abbr) => {
    guarded = guarded.split(abbr).join(abbr.replace(/\./g, "\u2024"));
  });
  const parts = guarded
    .split(/(?<=[.!?])\s+(?=[A-Z0-9"'(\u2018\u201c])/g)
    .map((part) => normalizeWhitespace(part.replace(/\u2024/g, ".")))
    .filter((part) => part.length >= 28)
    .filter((part) => /[a-zA-Z]{3,}/.test(part))
    .filter((part) => (part.match(/[.!?]/g) ?? []).length <= 3);
  return parts;
}

function tokensOf(value: string): string[] {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s'-]/g, " ")
    .split(/\s+/)
    .filter((word) => word.length > 2)
    .filter((word) => !STOPWORDS.has(word));
}

type Indexed = Map<string, { count: number; proper: number; heading: number }>;

function buildIndex(sentences: { text: string; page: number }[], fullText: string): Indexed {
  const index: Indexed = new Map();
  const add = (raw: string, weightProper: number, weightHeading: number) => {
    const words = raw.match(/[A-Za-z][A-Za-z'-]{2,}/g) ?? [];
    words.forEach((word) => {
      const key = word.toLowerCase();
      if (STOPWORDS.has(key) || key.length < 3) return;
      const entry = index.get(key) ?? { count: 0, proper: 0, heading: 0 };
      entry.count += 1;
      if (/^[A-Z][a-z'-]+$/.test(word) && weightProper > 0) entry.proper += weightProper;
      if (weightHeading > 0) entry.heading += weightHeading;
      index.set(key, entry);
    });
  };

  sentences.forEach((sentence) => add(sentence.text, 0.35, 0));
  // Bigrams ("working memory", "spaced repetition") matter more than single words.
  fullText
    .split(/(?<=[.!?])\s+/)
    .forEach((sentence) => {
      const words = sentence.match(/[A-Za-z][A-Za-z'-]{2,}/g) ?? [];
      for (let i = 0; i < words.length - 1; i += 1) {
        const a = words[i];
        const b = words[i + 1];
        if (STOPWORDS.has(a.toLowerCase()) || STOPWORDS.has(b.toLowerCase())) continue;
        const bigram = `${a.toLowerCase()} ${b.toLowerCase()}`;
        const entry = index.get(bigram) ?? { count: 0, proper: 0, heading: 0 };
        entry.count += 1;
        if (/^[A-Z]/.test(a) && /^[A-Z]/.test(b)) entry.proper += 1;
        index.set(bigram, entry);
      }
    });

  // Headings: short titles / numbered sections get a boost.
  fullText.split(/\r?\n/).forEach((line) => {
    const trimmed = normalizeWhitespace(line);
    if (!trimmed || trimmed.length > 80) return;
    if (!/^(\d+(\.\d+)*\s|[A-Z][^.!?]{2,60}$)/.test(trimmed)) return;
    add(trimmed, 0.2, 2.5);
  });

  return index;
}

function termWeight(index: Indexed, term: string): number {
  const entry = index.get(term);
  if (!entry) return 0;
  return Math.log2(1 + entry.count) * (1 + entry.proper * 0.8 + entry.heading * 0.5);
}

function rankedTerms(index: Indexed, limit: number): { term: string; score: number; count: number }[] {
  return [...index.entries()]
    .filter(([term]) => term.length >= 4)
    .filter(([term]) => !GENERIC_TERMS.has(term))
    .filter(([term]) => term.split(/\s+/).some((word) => !GENERIC_TERMS.has(word) && !STOPWORDS.has(word)))
    .map(([term, entry]) => ({
      term,
      count: entry.count,
      score: Math.log2(1 + entry.count) * (1 + entry.proper * 1.1 + entry.heading * 0.7),
    }))
    .filter((entry) => entry.count >= 2)
    .sort((a, b) => b.score - a.score || a.term.localeCompare(b.term))
    .slice(0, limit);
}

function sentenceScore(sentence: string, index: Indexed): number {
  const words = tokensOf(sentence).slice(0, 26);
  const vocabulary = [...new Set(words)];
  const keywordWeight = vocabulary.reduce((total, word) => {
    const entry = index.get(word);
    return total + (entry ? termWeight(index, word) : 0);
  }, 0);
  const lengthScore = Math.min(1, Math.abs(words.length - 15) < 12 ? 1 : 0.6);
  const cue = CUE_BOOSTS.reduce(
    (total, [pattern, boost]) => total + (pattern.test(sentence) ? boost : 0),
    0,
  );
  const questionPenalty = /\?$/.test(sentence) ? 0.8 : 0;
  return keywordWeight * lengthScore + cue - questionPenalty;
}

function shorten(value: string, max = 220): string {
  const clean = normalizeWhitespace(value);
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${cut.slice(0, lastSpace > 40 ? lastSpace : max)}…`;
}

function key(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
}

function hintFor(answer: string): string {
  const letters = answer.match(/[A-Za-z]/g) ?? [];
  if (letters.length === 0) return "Numbers and symbols only.";
  return `Starts with “${answer.trim()[0]}” · ${letters.length} letters`;
}

const PRONOUN_START = /^(it|this|that|these|those|they|there|he|she|we|you|i|its|their|his|her|such)\b/i;

function definitionOf(sentence: string): { term: string; body: string } | null {
  const match = sentence.match(
    /^(.{3,90}?)\s(?:is|are|was|were|refers? to|means?|is defined as|is called|describes?)\s(.{12,320})$/i,
  );
  if (!match) return null;
  const rawTerm = normalizeWhitespace(match[1]).replace(/^[^A-Za-z]+/, "");
  const body = normalizeWhitespace(match[2]);
  const term = rawTerm.replace(/^(the|a|an)\s+/i, "").trim();
  const words = term.split(/\s+/);
  if (words.length === 0 || words.length > 6) return null;
  if (PRONOUN_START.test(term)) return null;
  if (CLAUSE_WORDS.test(term)) return null;
  if (STOPWORDS.has(term.toLowerCase())) return null;
  if (term.length < 4) return null;
  // Clause fragments usually carry participles or adverbs after the head noun.
  const tail = words.slice(1);
  if (tail.some((word) => /(ed|ly)$/i.test(word))) return null;
  if (words[0].length < 3) return null;
  return { term, body };
}

function pickClozeTerm(sentence: string, index: Indexed): string | null {
  const opening = (sentence.match(/[A-Za-z][A-Za-z'-]{3,}/g) ?? [""])[0].toLowerCase();
  const seenWords = new Set<string>();
  const candidates = (sentence.match(/[A-Za-z][A-Za-z'-]{3,}/g) ?? []).filter((word) => {
    const lower = word.toLowerCase();
    if (seenWords.has(lower)) return false;
    seenWords.add(lower);
    if (STOPWORDS.has(lower) || LOW_VALUE_ANSWERS.has(lower)) return false;
    if (lower === opening) return false;
    if (lower.length < 4) return false;
    return true;
  });
  if (candidates.length === 0) return null;
  const scored = candidates.map((word) => {
    const entry = index.get(word.toLowerCase());
    return {
      word,
      score:
        (entry ? termWeight(index, word.toLowerCase()) : 0.2) +
        (word.split(/\s+/).length > 1 ? 2 : 0) +
        (word.length > 6 ? 0.6 : 0),
    };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored[0].word;
}

export function buildCloze(sentence: string, target: string): string {
  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const replaced = sentence.replace(new RegExp(escaped, "i"), "_____");
  return replaced === sentence ? sentence : replaced;
}

/* ------------------------------------------------------------------ */
/* Card generators                                                     */
/* ------------------------------------------------------------------ */

function makeOptions(answer: string, pool: string[], seed: number): string[] {
  const cleanAnswer = normalizeWhitespace(answer);
  const seen = new Set([key(cleanAnswer)]);
  const distractors: string[] = [];
  for (const candidate of seededShuffle(pool, seed)) {
    const value = normalizeWhitespace(candidate);
    if (value.length < 2 || value.length > 90) continue;
    const k = key(value);
    if (seen.has(k)) continue;
    if (k.includes(key(cleanAnswer)) || key(cleanAnswer).includes(k)) continue;
    seen.add(k);
    distractors.push(value);
    if (distractors.length === 3) break;
  }
  const fallback = ["None of these", "Not stated in the source", "The opposite is true"];
  let fallbackIndex = 0;
  while (distractors.length < 3) {
    distractors.push(fallback[fallbackIndex % fallback.length]);
    fallbackIndex += 1;
  }
  return seededShuffle([cleanAnswer, ...distractors], seed + 7);
}

type ScoredSentence = { text: string; page: number; score: number; order: number };

export function extractConcepts(
  terms: { term: string; score: number; count: number }[],
  sentences: { text: string; page: number }[],
  limit = 12,
): Concept[] {
  return terms.slice(0, limit).map(({ term, score, count }) => {
    const definition = sentences.find((sentence) => {
      const def = definitionOf(sentence.text);
      if (!def) return false;
      return def.term.toLowerCase().includes(term) || term.includes(def.term.toLowerCase());
    });
    const definitionParsed = definition ? definitionOf(definition.text) : null;
    return {
      term: term.replace(/\b\w/g, (character) => character.toUpperCase()),
      count,
      score: Number(score.toFixed(2)),
      definition: definitionParsed ? shorten(definitionParsed.body, 200) : "",
      page: definition?.page ?? sentences[0]?.page ?? 1,
    };
  });
}

function generateCards(
  scored: ScoredSentence[],
  index: Indexed,
  terms: { term: string; score: number; count: number }[],
  target: number,
  seedBase: number,
): MemoryCard[] {
  const buckets: Record<"definition" | "fact" | "list" | "cloze" | "concept", MemoryCard[]> = {
    definition: [],
    fact: [],
    list: [],
    cloze: [],
    concept: [],
  };
  const seenPrompts = new Set<string>();
  const seenAnswers = new Set<string>();
  const conceptPool = terms.slice(0, 40).map((entry) => entry.term);
  // Generate more candidates than we need, then interleave kinds so every deck is varied.
  const candidateCap = Math.max(16, target * 2);
  const candidateCount = () =>
    buckets.definition.length +
    buckets.fact.length +
    buckets.list.length +
    buckets.cloze.length +
    buckets.concept.length;

  const push = (bucket: keyof typeof buckets, card: MemoryCard) => {
    const promptKey = key(card.prompt);
    const answerKey = key(card.answer);
    if (!promptKey || !answerKey) return false;
    if (seenPrompts.has(promptKey) || seenAnswers.has(answerKey)) return false;
    seenPrompts.add(promptKey);
    seenAnswers.add(answerKey);
    buckets[bucket].push(card);
    return true;
  };

  const ordered = [...scored].sort((a, b) => b.score - a.score);

  // 1. Definitions — highest value for recall.
  for (const sentence of ordered) {
    if (candidateCount() >= candidateCap) break;
    const definition = definitionOf(sentence.text);
    if (!definition) continue;
    const normalizedTerm = definition.term.toLowerCase();
    const recurrence =
      index.get(normalizedTerm)?.count ??
      Math.max(0, ...normalizedTerm.split(/\s+/).map((word) => index.get(word)?.count ?? 0));
    if (recurrence < 2) continue;
    const displayTerm = normalizedTerm.charAt(0).toUpperCase() + normalizedTerm.slice(1);
    const tags = tokensOf(definition.term).slice(0, 3);
    push("definition", {
      kind: "definition" satisfies CardKind,
      prompt: `What is ${displayTerm}?`,
      answer: shorten(definition.body, 230),
      hint: hintFor(definition.body),
      cloze: null,
      quote: shorten(sentence.text, 420),
      page: sentence.page,
      options: makeOptions(definition.body, conceptPool, hashString(definition.term) + seedBase),
      explanation: `The source defines this on page ${sentence.page}.`,
      tags,
    });
  }

  // 2. Quantified facts — blank the number, keep the sentence intact.
  const NUMBER_PATTERN =
    /(\d[\d.,]*\s?(?:%|percent|percentage|kg|km|cm|mm|ms|seconds?|minutes?|hours?|days?|weeks?|months?|years?|million|billion|thousand|times|x)?)/i;
  for (const sentence of ordered) {
    if (candidateCount() >= candidateCap) break;
    const match = sentence.text.match(NUMBER_PATTERN);
    if (!match || match.index === undefined) continue;
    const value = normalizeWhitespace(match[1]);
    if (value.replace(/\D/g, "").length === 0) continue;
    const blanked = `${sentence.text.slice(0, match.index)}_____${sentence.text.slice(match.index + match[1].length)}`;
    if (blanked.includes("_____ _____")) continue;
    push("fact", {
      kind: "fact",
      prompt: `Recall the exact figure:\n${shorten(blanked, 280)}`,
      answer: value,
      hint: hintFor(value),
      cloze: blanked,
      quote: shorten(sentence.text, 420),
      page: sentence.page,
      options: makeOptions(
        value,
        ["0", "1", "10", "50%", "100", "24 hours", "7 days", "1,000", "2.5", ...conceptPool],
        hashString(value + sentence.page) + seedBase,
      ),
      explanation: "Numbers are the easiest facts to lose — anchor this one to the sentence.",
      tags: tokensOf(sentence.text).slice(0, 3),
    });
  }

  // 3. Lists / processes.
  for (const sentence of ordered) {
    if (candidateCount() >= candidateCap) break;
    const isList = /\b(first|second|third|finally|steps?|stages?|phases?|types?|kinds?|categories|consists? of|includes?|such as)\b/i.test(
      sentence.text,
    );
    if (!isList) continue;
    const term = pickClozeTerm(sentence.text, index);
    if (!term) continue;
    push("list", {
      kind: "list",
      prompt: `Recall the sequence or grouping: ${shorten(sentence.text.replace(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"), "_____"), 200)}`,
      answer: term,
      hint: hintFor(term),
      cloze: buildCloze(sentence.text, term),
      quote: shorten(sentence.text, 420),
      page: sentence.page,
      options: makeOptions(term, conceptPool, hashString(term) + seedBase),
      explanation: "Rebuild the list out loud before flipping the card.",
      tags: tokensOf(sentence.text).slice(0, 3),
    });
  }

  // 4. Cloze deletions from the highest-value sentences.
  for (const sentence of ordered) {
    if (candidateCount() >= candidateCap) break;
    const term = pickClozeTerm(sentence.text, index);
    if (!term) continue;
    push("cloze", {
      kind: "cloze",
      prompt: `Fill the gap:\n${shorten(buildCloze(sentence.text, term), 260)}`,
      answer: term,
      hint: hintFor(term),
      cloze: buildCloze(sentence.text, term),
      quote: shorten(sentence.text, 420),
      page: sentence.page,
      options: makeOptions(term, [...conceptPool, ...tokensOf(sentence.text)], hashString(term) + seedBase),
      explanation: "Active fill-in-the-blank recall beats re-reading.",
      tags: tokensOf(sentence.text).slice(0, 3),
    });
  }

  // 5. Concepts without cards yet.
  for (const term of conceptPool) {
    if (candidateCount() >= candidateCap) break;
    const sentence = ordered.find((entry) =>
      new RegExp(`\\b${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(entry.text),
    );
    if (!sentence) continue;
    push("concept", {
      kind: "concept",
      prompt: `Explain “${term}” using one idea from the source.`,
      answer: shorten(sentence.text, 220),
      hint: `See page ${sentence.page}`,
      cloze: null,
      quote: shorten(sentence.text, 420),
      page: sentence.page,
      options: [],
      explanation: "Say it in your own words first, then compare with the source line.",
      tags: [term],
    });
  }

  // Interleave so a deck never becomes 100% definitions.
  const order: (keyof typeof buckets)[] = ["definition", "cloze", "fact", "list", "concept"];
  const mixed: MemoryCard[] = [];
  let guard = 0;
  while (mixed.length < target && guard < target * 6) {
    let added = false;
    for (const kind of order) {
      const next = buckets[kind].shift();
      if (next) {
        mixed.push(next);
        added = true;
      }
      if (mixed.length >= target) break;
    }
    guard += 1;
    if (!added) break;
  }
  return mixed;
}

/* ------------------------------------------------------------------ */
/* Main entry point                                                    */
/* ------------------------------------------------------------------ */

export function analyzeSource(input: SourceInput): AnalyzeResult {
  const cleaned = cleanPages(input.pages);
  const sentences: { text: string; page: number; order: number }[] = [];
  let order = 0;
  cleaned.forEach((page) => {
    splitSentences(page.text).forEach((sentence) => {
      sentences.push({ text: sentence, page: page.page, order: order++ });
    });
  });

  const fullText = cleaned.map((page) => page.text).join("\n");
  const words = fullText.split(/\s+/).filter(Boolean);
  const index = buildIndex(sentences.map(({ text, page }) => ({ text, page })), fullText);
  const terms = rankedTerms(index, 60);

  const scored: ScoredSentence[] = sentences.map((sentence) => ({
    ...sentence,
    score: sentenceScore(sentence.text, index),
  }));

  const wordCount = words.length;
  const targetCards = Math.max(8, Math.min(48, Math.round(wordCount / 30)));
  const seed = hashString(`${input.title}:${fullText.length}:${wordCount}`);
  const cards = generateCards(scored, index, terms, targetCards, seed);
  const concepts = extractConcepts(terms, sentences, 12);

  const topSentences = [...scored]
    .sort((a, b) => b.score - a.score)
    .slice(0, 7)
    .sort((a, b) => a.order - b.order);

  const summaryParts = topSentences.slice(0, 4).map((entry) => shorten(entry.text, 190));
  const summary = summaryParts.length
    ? summaryParts.join(" ")
    : "The source was too short to summarise. Paste at least a few paragraphs for the best results.";

  const keyPoints = [...scored]
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .sort((a, b) => a.order - b.order)
    .map((entry) => shorten(entry.text, 210));

  const recallPrompts = [
    `Explain “${concepts[0]?.term ?? input.title}” to someone who has never seen this material — no notes.`,
    concepts[1]
      ? `How are “${concepts[0]?.term ?? "the main idea"}” and “${concepts[1].term}” connected? Which one depends on the other?`
      : "What is the single most important claim in this source, and what evidence supports it?",
    `Where would the main argument in “${input.title}” break down? Name one assumption and one exception.`,
    "Close the source. Write the three facts you would be most annoyed to forget — then check them.",
  ];

  const totalMinutes = Math.max(15, Math.round(cards.length * 0.9 + wordCount / 220));
  const planDays = Math.max(3, Math.min(10, Math.ceil(cards.length / 12)));
  const perDay = Math.ceil(cards.length / planDays);
  const plan = Array.from({ length: planDays }, (_, dayIndex) => ({
    day: dayIndex + 1,
    focus:
      dayIndex === 0
        ? "First pass — learn the new cards"
        : dayIndex === planDays - 1
          ? "Consolidate + teach it back"
          : dayIndex % 3 === 0
            ? "Mixed recall + weak spots"
            : "Spaced review of earlier cards",
    minutes: Math.max(6, Math.round(perDay * 0.9)),
    cardCount: Math.min(perDay, Math.max(0, cards.length - dayIndex * perDay)),
  }));

  const covered = concepts.filter((concept) =>
    cards.some((card) =>
      `${card.prompt} ${card.answer} ${card.quote}`.toLowerCase().includes(concept.term.toLowerCase()),
    ),
  ).length;
  const coverage = concepts.length ? Math.round((covered / concepts.length) * 100) : 0;
  const avgSentenceLength = sentences.length ? wordCount / sentences.length : 0;

  const warnings: string[] = [];
  if (wordCount < 180) {
    warnings.push(
      "Short source detected. You still get cards, but 1,500+ words produces a much richer deck.",
    );
  }
  if (sentences.length === 0) {
    warnings.push(
      "No readable text found. If this is a scanned PDF, the pages are images — paste the text or run OCR first.",
    );
  }
  if (coverage < 60 && concepts.length > 4) {
    warnings.push("Some concepts are not yet covered by cards. Generate again after adding more text.");
  }

  const analysis: Analysis = {
    engine: "rules",
    summary,
    keyPoints,
    concepts,
    recallPrompts,
    plan,
    stats: {
      words: wordCount,
      sentences: sentences.length,
      pages: Math.max(cleaned.length, 1),
      concepts: concepts.length,
      readingMinutes: Math.max(1, Math.ceil(wordCount / 220)),
      coverage,
      difficulty: avgSentenceLength > 27 || wordCount / Math.max(concepts.length, 1) > 45 ? "Dense" : avgSentenceLength > 17 ? "Moderate" : "Light",
    },
    warnings,
    generatedAt: new Date().toISOString(),
  };

  return { analysis, cards };
}

/** Used by the landing-page demo and the paste flow before a document is saved. */
export function previewAnalysis(text: string, title = "Untitled source"): AnalyzeResult {
  return analyzeSource({ title, pages: [text] });
}

/** SM-2 style scheduler shared by the API and the UI. */
export function scheduleReview(
  state: { ease: number; intervalDays: number; reps: number; lapses: number },
  grade: 0 | 1 | 2 | 3,
  now = new Date(),
): { ease: number; intervalDays: number; reps: number; lapses: number; dueAt: Date } {
  const ease = Math.min(3.2, Math.max(1.3, state.ease));
  let nextEase = ease;
  let interval = state.intervalDays;
  let lapses = state.lapses;

  if (grade === 0) {
    nextEase = Math.max(1.3, ease - 0.2);
    lapses += 1;
    interval = 0;
  } else if (grade === 1) {
    nextEase = Math.max(1.3, ease - 0.15);
    interval = interval <= 0 ? 0.5 : Math.max(0.5, interval * 1.2);
  } else if (grade === 2) {
    interval = interval <= 0 ? 1 : interval * ease;
  } else {
    nextEase = Math.min(3.2, ease + 0.15);
    interval = interval <= 0 ? 2.5 : interval * ease * 1.3;
  }

  interval = Math.min(interval, 365);
  const minutes = grade === 0 ? 10 : Math.max(1, Math.round(interval * 24 * 60));
  const dueAt = new Date(now.getTime() + minutes * 60 * 1000);

  return {
    ease: Number(nextEase.toFixed(2)),
    intervalDays: Number(interval.toFixed(2)),
    reps: state.reps + 1,
    lapses,
    dueAt,
  };
}

export function cardsToCsv(
  title: string,
  cards: { prompt: string; answer: string; hint: string; tags: string[]; page: number }[],
): string {
  const head = "#separator:Comma\n#html:false\n#deck:" + title.replace(/[,:]/g, " ") + "\nFront,Back,Tags";
  const escape = (value: string) => `"${value.replace(/"/g, '""').replace(/\r?\n/g, "<br>")}"`;
  const rows = cards.map((card) =>
    [escape(card.prompt), escape(card.answer), escape(card.tags.join(" ")), escape(`page ${card.page}`)].join(","),
  );
  return [head, ...rows].join("\n");
}
