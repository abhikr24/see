import { getDocumentProxy, extractText } from "unpdf";

export type ExtractedPdf = {
  pages: string[];
  pageCount: number;
  warnings: string[];
};

/**
 * Server-side PDF text extraction (MIT licensed `unpdf`, a serverless build of PDF.js).
 * Returns one string per page so every flashcard can cite its source page.
 */
export async function extractPdfPages(buffer: ArrayBuffer): Promise<ExtractedPdf> {
  const warnings: string[] = [];
  const pdf = await getDocumentProxy(new Uint8Array(buffer));
  const result = await extractText(pdf, { mergePages: false });
  const rawPages = Array.isArray(result.text) ? result.text : [String(result.text ?? "")];
  const pages = rawPages.map((page) => page ?? "");
  const totalChars = pages.join("").trim().length;

  if (totalChars < 40) {
    warnings.push(
      "Almost no selectable text was found. This PDF is probably a scan or an image export — paste the text instead, or run OCR before uploading.",
    );
  }

  return {
    pages,
    pageCount: result.totalPages || pages.length,
    warnings,
  };
}
