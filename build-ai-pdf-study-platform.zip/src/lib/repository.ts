import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { aiEvents, cards, documents, quizAttempts, reviews, users } from "@/db/schema";
import { analyzeSource, hashString, scheduleReview } from "@/lib/memory/engine";
import type { Analysis, MemoryCard, ReviewGrade } from "@/lib/memory/types";
import { SAMPLE_TEXT, SAMPLE_TITLE } from "@/lib/memory/sample";
import { hashPassword } from "@/lib/auth/password";

export type SourceType = "pdf" | "txt" | "paste";

export type NewSourceInput = {
  userId: string;
  title: string;
  sourceType: SourceType;
  fileName?: string | null;
  pages: string[];
  engine: "rules" | "ai";
  cardCount?: number;
  aiOverlay?: {
    cards: MemoryCard[];
    analysis: Analysis;
    provider: string;
  } | null;
  aiMeta?: { provider: string; model: string; tokens: number } | null;
};

function fillOptions(cards: MemoryCard[]): MemoryCard[] {
  const pool = cards.map((card) => card.answer).filter((answer) => answer.length > 1);
  return cards.map((card, i) => {
    if (card.options.length >= 4) return card;
    const seen = new Set([card.answer.toLowerCase()]);
    const options: string[] = [card.answer];
    const candidates = [...pool.slice(i + 1), ...pool.slice(0, i)];
    for (const candidate of candidates) {
      const k = candidate.toLowerCase();
      if (seen.has(k) || k.includes(card.answer.toLowerCase())) continue;
      seen.add(k);
      options.push(candidate);
      if (options.length === 4) break;
    }
    const filler = ["Not stated in the source", "The opposite is true", "None of these"];
    let index = 0;
    while (options.length < 4) {
      options.push(filler[index % filler.length]);
      index += 1;
    }
    const rotation = hashString(card.answer) % 4;
    return { ...card, options: [...options.slice(rotation), ...options.slice(0, rotation)] };
  });
}

export async function createSource(input: NewSourceInput) {
  const base = analyzeSource({ title: input.title, pages: input.pages });
  const aiCards = input.aiOverlay?.cards ?? [];
  const allCards = fillOptions(
    [...aiCards, ...base.cards].slice(0, input.cardCount ?? 60),
  );
  const analysis: Analysis = input.aiOverlay
    ? {
        ...input.aiOverlay.analysis,
        stats: {
          ...base.analysis.stats,
          concepts: base.analysis.concepts.length,
          coverage: base.analysis.stats.coverage,
        },
      }
    : base.analysis;
  const rawText = input.pages.join("\n\n");

  const insertedDoc = await db
    .insert(documents)
    .values({
      userId: input.userId,
      title: input.title,
      sourceType: input.sourceType,
      fileName: input.fileName ?? null,
      pageCount: base.analysis.stats.pages,
      wordCount: base.analysis.stats.words,
      engine: input.engine,
      rawText,
      analysis,
    })
    .returning();

  const doc = insertedDoc[0];
  if (!doc) throw new Error("Could not save the document");

  if (allCards.length > 0) {
    await db.insert(cards).values(
      allCards.map((card, index) => ({
        documentId: doc.id,
        userId: input.userId,
        kind: card.kind,
        prompt: card.prompt,
        answer: card.answer,
        hint: card.hint,
        cloze: card.cloze,
        quote: card.quote,
        page: card.page,
        options: card.options,
        explanation: card.explanation,
        tags: card.tags,
        dueAt: new Date(Date.now() + index * 1000),
      })),
    );
  }

  if (input.aiMeta) {
    await db.insert(aiEvents).values({
      userId: input.userId,
      documentId: doc.id,
      provider: input.aiMeta.provider,
      model: input.aiMeta.model,
      credits: 1,
      tokens: input.aiMeta.tokens,
      status: "ok",
    });
    await db
      .update(users)
      .set({ aiCredits: sql`greatest(${users.aiCredits} - 1, 0)` })
      .where(eq(users.id, input.userId));
  }

  return doc;
}

export type DocumentSummary = {
  id: string;
  title: string;
  engine: string;
  sourceType: string;
  pageCount: number;
  wordCount: number;
  createdAt: Date;
  totalCards: number;
  dueCards: number;
  mastered: number;
};

export async function listDocuments(userId: string): Promise<DocumentSummary[]> {
  const rows = await db
    .select({
      id: documents.id,
      title: documents.title,
      engine: documents.engine,
      sourceType: documents.sourceType,
      pageCount: documents.pageCount,
      wordCount: documents.wordCount,
      createdAt: documents.createdAt,
      totalCards: sql<number>`count(${cards.id})::int`,
      dueCards: sql<number>`count(case when ${cards.dueAt} <= now() then 1 end)::int`,
      mastered: sql<number>`count(case when ${cards.reps} >= 2 and ${cards.intervalDays} >= 3 then 1 end)::int`,
    })
    .from(documents)
    .leftJoin(cards, eq(cards.documentId, documents.id))
    .where(eq(documents.userId, userId))
    .groupBy(documents.id)
    .orderBy(desc(documents.createdAt));
  return rows;
}

export async function getDashboard(userId: string) {
  const [counts] = await db
    .select({
      totalCards: sql<number>`count(*)::int`,
      dueCards: sql<number>`count(case when ${cards.dueAt} <= now() then 1 end)::int`,
      mastered: sql<number>`count(case when ${cards.reps} >= 2 and ${cards.intervalDays} >= 3 then 1 end)::int`,
      newCards: sql<number>`count(case when ${cards.reps} = 0 then 1 end)::int`,
    })
    .from(cards)
    .where(eq(cards.userId, userId));

  const [docCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(documents)
    .where(eq(documents.userId, userId));

  const [week] = await db
    .select({
      reviews: sql<number>`count(*)::int`,
      remembered: sql<number>`count(case when ${reviews.grade} >= 2 then 1 end)::int`,
    })
    .from(reviews)
    .where(
      and(eq(reviews.userId, userId), gte(reviews.reviewedAt, new Date(Date.now() - 7 * 86400000))),
    );

  const recentQuiz = await db
    .select()
    .from(quizAttempts)
    .where(eq(quizAttempts.userId, userId))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(3);

  return {
    documents: docCount?.count ?? 0,
    totalCards: counts?.totalCards ?? 0,
    dueCards: counts?.dueCards ?? 0,
    newCards: counts?.newCards ?? 0,
    mastered: counts?.mastered ?? 0,
    reviewsThisWeek: week?.reviews ?? 0,
    retentionThisWeek:
      week && week.reviews > 0 ? Math.round((week.remembered / week.reviews) * 100) : null,
    recentQuiz,
  };
}

export async function getDocument(userId: string, id: string) {
  const rows = await db
    .select()
    .from(documents)
    .where(and(eq(documents.id, id), eq(documents.userId, userId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function getDocumentCards(userId: string, documentId: string) {
  return db
    .select()
    .from(cards)
    .where(and(eq(cards.documentId, documentId), eq(cards.userId, userId)))
    .orderBy(cards.createdAt);
}

export async function getDueQueue(userId: string, limit = 25, documentId?: string) {
  const conditions = [eq(cards.userId, userId), lte(cards.dueAt, new Date())];
  if (documentId) conditions.push(eq(cards.documentId, documentId));
  return db
    .select({
      card: cards,
      documentTitle: documents.title,
    })
    .from(cards)
    .innerJoin(documents, eq(documents.id, cards.documentId))
    .where(and(...conditions))
    .orderBy(cards.dueAt)
    .limit(limit);
}

export async function reviewCard(
  userId: string,
  cardId: string,
  grade: ReviewGrade,
  seconds = 0,
) {
  const rows = await db
    .select()
    .from(cards)
    .where(and(eq(cards.id, cardId), eq(cards.userId, userId)))
    .limit(1);
  const card = rows[0];
  if (!card) return null;

  const next = scheduleReview(
    { ease: card.ease, intervalDays: card.intervalDays, reps: card.reps, lapses: card.lapses },
    grade,
  );

  await db
    .update(cards)
    .set({
      ease: next.ease,
      intervalDays: next.intervalDays,
      reps: next.reps,
      lapses: next.lapses,
      dueAt: next.dueAt,
      lastReviewedAt: new Date(),
    })
    .where(eq(cards.id, card.id));

  await db.insert(reviews).values({
    cardId: card.id,
    userId,
    documentId: card.documentId,
    grade,
    intervalDays: next.intervalDays,
  });

  await touchStreak(userId);

  return { ...next, seconds };
}

export async function touchStreak(userId: string) {
  const today = new Date().toISOString().slice(0, 10);
  const rows = await db
    .select({ streak: users.streak, lastStudiedOn: users.lastStudiedOn })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  const row = rows[0];
  if (!row) return;
  if (row.lastStudiedOn === today) return;
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const streak = row.lastStudiedOn === yesterday ? row.streak + 1 : 1;
  await db.update(users).set({ streak, lastStudiedOn: today }).where(eq(users.id, userId));
}

export async function recordQuizAttempt(
  userId: string,
  documentId: string,
  score: number,
  total: number,
) {
  await db.insert(quizAttempts).values({ userId, documentId, score, total });
  await touchStreak(userId);
}

export async function deleteDocument(userId: string, id: string) {
  await db.delete(documents).where(and(eq(documents.id, id), eq(documents.userId, userId)));
}

export async function activateDemoPro(userId: string, credits = 40) {
  const safeCredits = Math.max(5, Math.min(100, Math.floor(credits)));
  const rows = await db
    .update(users)
    .set({ plan: "pro", aiCredits: sql`${users.aiCredits} + ${safeCredits}` })
    .where(eq(users.id, userId))
    .returning();
  return rows[0] ?? null;
}

export async function getRecentAiEvents(userId: string, limit = 4) {
  return db
    .select()
    .from(aiEvents)
    .where(eq(aiEvents.userId, userId))
    .orderBy(desc(aiEvents.createdAt))
    .limit(limit);
}

/* ------------------------------------------------------------------ */
/* Demo account bootstrap — idempotent, safe to call on any page       */
/* ------------------------------------------------------------------ */

export const DEMO_EMAIL = "demo@recall.studio";
export const DEMO_PASSWORD = "recall1234";

let seedPromise: Promise<void> | null = null;

async function seedDemo() {
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, DEMO_EMAIL)).limit(1);
  if (existing[0]) return;

  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const inserted = await db
    .insert(users)
    .values({
      email: DEMO_EMAIL,
      name: "Demo Learner",
      passwordHash,
      plan: "free",
      aiCredits: 0,
      streak: 3,
      lastStudiedOn: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
    })
    .onConflictDoNothing()
    .returning();
  const demo = inserted[0];
  if (!demo) return;

  const source = analyzeSource({ title: SAMPLE_TITLE, pages: [SAMPLE_TEXT] });
  const docRows = await db
    .insert(documents)
    .values({
      userId: demo.id,
      title: SAMPLE_TITLE,
      sourceType: "paste",
      fileName: "memory-science.md",
      pageCount: source.analysis.stats.pages,
      wordCount: source.analysis.stats.words,
      engine: "rules",
      rawText: SAMPLE_TEXT,
      analysis: source.analysis,
    })
    .returning();
  const doc = docRows[0];
  if (!doc) return;

  const filled = fillOptions(source.cards);
  await db.insert(cards).values(
    filled.map((card, index) => {
      const reviewed = index % 4 === 0;
      const dueOffset = index % 5 === 0 ? -60 * 60 * 1000 : index * 45 * 1000;
      return {
        documentId: doc.id,
        userId: demo.id,
        kind: card.kind,
        prompt: card.prompt,
        answer: card.answer,
        hint: card.hint,
        cloze: card.cloze,
        quote: card.quote,
        page: card.page,
        options: card.options,
        explanation: card.explanation,
        tags: card.tags,
        ease: reviewed ? 2.65 : 2.5,
        intervalDays: reviewed ? 3 : 0,
        reps: reviewed ? 2 : 0,
        dueAt: new Date(Date.now() + dueOffset),
        lastReviewedAt: reviewed ? new Date(Date.now() - 86400000) : null,
      };
    }),
  );

  await db.insert(quizAttempts).values({
    userId: demo.id,
    documentId: doc.id,
    score: 4,
    total: 6,
  });
}

/** Called by public pages; never throws into render. */
export function ensureDemoSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedDemo().catch((error) => {
      seedPromise = null;
      console.error("Demo seed skipped:", error instanceof Error ? error.message : error);
    });
  }
  return seedPromise;
}
