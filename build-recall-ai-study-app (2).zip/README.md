# Recall

Recall turns a PDF (or pasted text) into flashcards, cloze deletions, a graded quiz,
concept notes, a study plan and a spaced-repetition queue.

Two engines:

| Engine              | Cost                         | Needs a key              | Works offline                      |
| ------------------- | ---------------------------- | ------------------------ | ---------------------------------- |
| **Rules** (default) | Free, unlimited              | No                       | Yes — deterministic, seeded output |
| **AI** (optional)   | 1 credit per successful deck | Server-side provider key | No                                 |

The free engine is never gated, never metered and never calls the network.

## Requirements

- **Node 22 or newer** (`engines` + `.nvmrc`). PDF extraction uses `unpdf@1.9.1`,
  which relies on the `Iterator` global added in Node 22. On an older runtime the
  API returns HTTP 503 `RUNTIME_UNSUPPORTED` naming the required version instead of
  a misleading "PDF is damaged" message.
- PostgreSQL 14+ with `DATABASE_URL` set.
- Optional: an AI provider key (OpenAI, Anthropic, Groq, OpenRouter or a custom
  OpenAI-compatible endpoint).

```bash
cp .env.example .env         # set DATABASE_URL
npm ci
npm run db:push              # creates the schema from DATABASE_URL alone
npm run dev                  # http://localhost:3000
```

Demo account (seeded on first visit): `demo@recall.studio` / `recall1234`.

## Architecture

```
src/app/api/…            route handlers: documents, cards, reviews, quiz, export, billing, health
src/app/app/…            authenticated workspace (overview, new source, deck, review, billing)
src/lib/memory/engine.ts rules engine: blocks → sentences → terms → cards → validator → interleave
src/lib/memory/scheduler.ts  FSRS v5 scheduling via ts-fsrs
src/lib/memory/porter.ts     original Porter stemmer (no dependency)
src/lib/repository.ts    every DB read/write, always scoped by user id
src/lib/auth/            local Postgres sessions + server-only Supabase adapter
src/lib/rate-limit.ts    Postgres fixed-window limiter
src/db/schema.ts         users, sessions, documents, cards, reviews, quiz_attempts, ai_events, rate_limits
tests/                   59 unit tests + five fixtures + reviewed snapshots
```

Every query is scoped by the authenticated user id on both reads and writes. A
request for another user's document, card, export or quiz attempt returns **404**,
never 403 and never 200.

### Card quality pipeline

1. **Block extraction** keeps lines: headings are separated from body text and can
   never leak into a card. References/bibliography sections and page furniture are
   dropped.
2. **Sentence splitting** uses `sbd` (abbreviations, decimals, initials), merging
   over-short fragments.
3. **Term ranking** uses `compromise` noun phrases, proper-noun and heading boosts,
   merged by a Porter stem.
4. **Generators**: subject-verified definitions, unit/currency/year fact cards
   (signs and whitespace preserved), meaning-bearing clozes (max 2 per sentence),
   lists, and one concept card per top-8 concept (coverage pass before any kind
   repeats).
5. **Validator**: prompt must end in `?` or contain `_____`; answers must be
   complete, ≤240 chars, not truncated with an ellipsis, not a heading, not a bare
   stopword, not already visible in the prompt, and unique across the deck.
6. Failed candidates are dropped and counted; `stats.qualityScore` is
   `passing / generated`. Below 70% the workspace shows a non-blocking notice.

Fixture coverage: textbook chapter, academic paper, lecture slides, contract and
an image-only scan. The scanner fixture asserts Recall produces **zero** cards and
an explanatory warning — OCR is not part of this build, and the UI never claims it is.

![Review flow at 390 px](docs/review-flow.png)

## Features

- PDF / TXT / Markdown upload and text paste; PDF error codes `ENCRYPTED`,
  `NO_TEXT_LAYER`, `PARSE_FAILED`, `RUNTIME_UNSUPPORTED`.
- **OCR for scans**: pages with <40 characters are rasterised with pdf.js and read
  with tesseract.js (eng, or `OCR_LANGUAGES=eng+hin`), capped by `OCR_MAX_PAGES`
  (default 25). A text PDF never invokes OCR. `/api/health` reports `ocr`.
- **Offline PWA**: installable manifest, service worker (app shell + static assets;
  `/api/*` is never cached), and reviews graded offline are queued in IndexedDB and
  replayed automatically with a "N reviews waiting to sync" badge.
- **i18n**: English and Hindi, cookie-based, no route changes; locale-aware dates
  and numbers; add a language by extending `src/lib/i18n/messages.ts`.
- Deck workspace: review, card manager, quiz, concepts, study plan, source view.
- Card management: edit prompt/answer/hint/tags, add, delete, suspend, flag,
  keyboard-accessible reorder; server-side filter by kind, page, tag, due state,
  flagged state and full-text search.
- Quiz scored **server-side** from the chosen answers; per-question results stored.
- FSRS v5 scheduling with a per-user desired-retention setting (default 90%).
- Exports: Anki CSV (`Front,Back,Tags,Page`, PapaParse-serialised), Quizlet TSV,
  JSON and Markdown. Download a deck, import it into Anki, and the columns line up.
- AI failures are reported with codes (`AI_TIMEOUT`, `AI_PROVIDER_ERROR`,
  `AI_INVALID_OUTPUT`, `AI_NOT_CONFIGURED`). Provider bodies, endpoints and keys
  stay in server logs; no credit is charged on failure and the deck is labelled with
  the engine that actually ran.
- Rate limits (Postgres): login 5/min/IP, signup 3/hour/IP, upload 30/hour/user,
  AI 20/hour/user, export 60/hour/user. 429 + `Retry-After`.
- Security: HTTP-only sameSite=lax cookies (secure in production), scrypt
  passwords, hashed session tokens, no `NEXT_PUBLIC_*` secrets.
- Accessibility: keyboard review flow (space, 1–4), `aria-live` announcements,
  visible focus rings, labelled inputs, segmented deck tabs that fit 390 px.
- 30-day review heatmap (pure CSS grid).

## Environment variables

See `.env.example`. `AUTH_PROVIDER=supabase` **requires** `SUPABASE_URL` and
`SUPABASE_ANON_KEY`; a missing value throws at boot and `/api/health` reports
`auth: "invalid"` with the missing names. There is no silent fallback.

`ALLOW_DEMO_BILLING=true` enables the demo Pro activation (production also requires
the demo account). Otherwise checkout returns 403. Real card payments are **not**
implemented in this build.

## Health

`GET /api/health` returns `{ status, db, auth, authProblem, aiConfigured, ocr, node, version }`.
`ocr` is `false` because OCR is not shipped.

## Commands

```bash
npm run dev            # development
npm run build          # production build
npm test               # vitest (unit + component)
npm run test:e2e       # Playwright: signup→deck→grade→export→delete, isolation, axe, i18n
npm run lint           # eslint
npm run typecheck      # tsc --noEmit
npm run db:push        # apply schema from DATABASE_URL
npm run db:generate    # generate SQL migrations
npm run db:studio      # inspect the database
npm run license:check  # commercial-licence gate (CI)
```

## Licences

See [`docs/DEPENDENCIES.md`](docs/DEPENDENCIES.md), `NOTICE`, `LICENSE` and the
in-app `/licences` page. All direct dependencies are MIT/ISC/BSD/Apache-2.0.
Apache-2.0 components (Drizzle ORM, TypeScript) are attributed in `NOTICE`.
`npm run license:check` fails on any unreviewed licence; the three reviewed
transitive exceptions (Next's optional sharp binaries, lightningcss, caniuse-lite)
are documented with their mitigations.

## Verification

[`docs/VERIFICATION.md`](docs/VERIFICATION.md) maps **every** item of the v2 brief to its
implementation or to an explicit "not built" verdict, with the command that proves it.
`docs/QUALITY.md` holds the engine/test evidence and `docs/FSRS_MIGRATION.md` the scheduler
migration. Coverage: 81 tests; `src/lib/memory` 93% lines; `src/lib/import` 94%;
`src/lib/rich` 95%; `src/lib/auth/config.ts` 94%.

## Not implemented in this build

Not implemented: a visible INR/USD toggle (currency is detected from
`Accept-Language` at checkout), Sentry telemetry (structured logs + `/api/health`
instead) and a Supabase-project integration test (RLS SQL is supplied, not executed
here). Stripe checkout, portal and signed idempotent webhooks are implemented but need
real keys and a registered endpoint, so this sandbox cannot prove a live payment.
See `docs/VERIFICATION.md` for the item-by-item matrix and test evidence.
