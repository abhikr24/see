# Supabase auth (server-side)

Recall keeps its own Postgres tables and reaches Supabase Auth (GoTrue) over HTTPS
from **server-only** code. No Supabase key is ever exposed to the browser: the app
issues its own HTTP-only cookies.

## 1. Environment (5 minutes)

```
AUTH_PROVIDER=supabase
SUPABASE_URL=https://YOUR-PROJECT.supabase.co
SUPABASE_ANON_KEY=YOUR-ANON-KEY
```

Restart the app. `GET /api/health` must show `"auth": "supabase"` and
`"authProblem": null`. If a variable is missing the app **throws at boot** and the
health endpoint reports `auth: "invalid"` naming the missing variable — it never
falls back to local passwords silently.

## 2. Email confirmation

If your project has "Confirm email" enabled, sign-up returns
`202 {"status":"confirm_email"}` and the form shows _"Check your inbox…"_. No
session cookie is set until Supabase returns tokens.

## 3. Row Level Security

Run `supabase/migrations/0001_recall_rls.sql` in the SQL editor. It adds
`users.auth_uid`, links it to `auth.uid()`, enables RLS on `documents`, `cards`,
`reviews`, `quiz_attempts`, `ai_events`, `subscriptions`, `users`, and revokes all
client access to `sessions` and `rate_limits`.

The application still scopes every query by its own server-verified user id
(defence in depth); the policies protect direct PostgREST/JS-client access.

## 4. Local fallback

`AUTH_PROVIDER=local` (the default) uses Postgres sessions, scrypt password hashes
and hashed session tokens, and seeds `demo@recall.studio / recall1234` on first
visit. This is the offline/demo path and is fully supported.
