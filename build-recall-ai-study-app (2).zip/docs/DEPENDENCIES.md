# Dependency register

Last verified: 2026. Every dependency below was checked with
`npm view <package> version license` **before** installation, and its installed
type definitions / README were read before the API was called. Exact versions
are pinned in `package-lock.json`. The CI gate is `npm run license:check`
(allowlist: MIT, ISC, BSD-2-Clause, BSD-3-Clause, Apache-2.0, 0BSD, CC0-1.0,
Unlicense, plus BlueOak-1.0.0, Python-2.0 and MIT-0 for transitive tooling only —
MIT-0 is MIT without the attribution clause, so it is strictly more permissive than
the MIT licence the brief already allows).

| Package                            | Version | Licence        | Repository                                        | Used for                                                        | Docs read                                                                                                                                                             |
| ---------------------------------- | ------- | -------------- | ------------------------------------------------- | --------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| next                               | 16.2.6  | MIT            | https://github.com/vercel/next.js                 | App Router, route handlers, instrumentation                     | nextjs.org/docs (App Router, `generateMetadata`, instrumentation)                                                                                                     |
| react / react-dom                  | 19.2.6  | MIT            | https://github.com/facebook/react                 | UI runtime                                                      | react.dev                                                                                                                                                             |
| drizzle-orm                        | 0.45.2  | **Apache-2.0** | https://github.com/drizzle-team/drizzle-orm       | Schema, queries, Postgres pool                                  | orm.drizzle.team/docs; installed `drizzle-orm` typings for `db.execute` result shape                                                                                  |
| drizzle-kit                        | 0.31.10 | MIT            | https://github.com/drizzle-team/drizzle-kit       | `db:push`, `db:generate`, `db:studio`                           | orm.drizzle.team/docs/drizzle-kit-*                                                                                                                                   |
| pg                                 | 8.20.0  | MIT            | https://github.com/brianc/node-postgres           | Connection pool                                                 | node-postgres.com                                                                                                                                                     |
| unpdf                              | 1.9.1   | MIT            | https://github.com/unjs/unpdf                     | Server-side PDF text extraction                                 | unpdf README + installed types; verified Node 22 requirement (`Iterator`)                                                                                             |
| zod                                | 4.6.7   | MIT            | https://github.com/colinhacks/zod                 | Request/AI validation                                           | zod.dev                                                                                                                                                               |
| lucide-react                       | 1.62.0  | ISC            | https://github.com/lucide-icons/lucide            | Icons                                                           | lucide.dev/guide/packages/lucide-react                                                                                                                                |
| compromise                         | 14.19.0 | MIT            | https://github.com/spencermountain/compromise     | Noun phrases, proper nouns, verbs for term ranking and subjects | README + local `nlp.nouns()`, `nlp.match('#ProperNoun+')` probes (there is no `.subjects()` API in 14.19 — subject detection is derived from the leading noun phrase) |
| sbd                                | 1.0.19  | MIT            | https://github.com/Tessmore/sbd                   | Sentence boundary detection                                     | `@types/sbd/index.d.ts` `sentences(text, Options)`                                                                                                                    |
| papaparse                          | 5.7.0   | MIT            | https://github.com/mholt/PapaParse                | Anki CSV (4 columns) and Quizlet TSV                            | papaparse.com/docs (`unparse`, `columns`, `quotes`, `delimiter`)                                                                                                      |
| ts-fsrs                            | 5.4.2   | MIT            | https://github.com/open-spaced-repetition/ts-fsrs | FSRS v5 scheduling                                              | installed `dist/index.d.ts` (`createEmptyCard`, `fsrs`, `generatorParameters`, `Rating`, `State`, `repeat().card`)                                                    |
| dotenv                             | 17.3.1  | BSD-2-Clause   | https://github.com/motdotla/dotenv                | Loads `.env` for drizzle-kit only                               | README                                                                                                                                                                |
| vitest                             | 5.0.5   | MIT            | https://github.com/vitest-dev/vitest              | Unit tests                                                      | vitest.dev/config                                                                                                                                                     |
| typescript                         | 5.9.3   | **Apache-2.0** | https://github.com/microsoft/TypeScript           | Type checking (dev)                                             | typescriptlang.org/docs                                                                                                                                               |
| tailwindcss + @tailwindcss/postcss | 4.1.17  | MIT            | https://github.com/tailwindlabs/tailwindcss       | Styling                                                         | tailwindcss.com/docs                                                                                                                                                  |

## Apache-2.0 obligations

Drizzle ORM and TypeScript are Apache-2.0. Their attribution is recorded in
`NOTICE`, and rendered at `/licences`. Neither is modified.

## Deliberate non-additions (trade-offs)

- **natural** (MIT) — not installed. We needed only the Porter stemmer, and
  `natural` is a large toolkit with dynamic requires. `src/lib/memory/porter.ts`
  is an original implementation of the public-domain Porter (1980) algorithm,
  covered by this repository's licence. No licence obligation is introduced.
- **rate-limiter-flexible** (ISC) — not installed. The Postgres-backed
  fixed-window limiter in `src/lib/rate-limit.ts` uses one atomic upsert and no
  extra service. The login limiter is unit-tested.
- **@dnd-kit/core** — not installed. Reordering is done with keyboard-accessible
  move up/down controls, which are usable at 390 px without a pointer.
- **license-checker** (BSD-3) — replaced by `scripts/license-check.mjs`, which
  reads `package-lock.json` + installed manifests and enforces the same
  allowlist. No network access required in CI.

## Explicitly not implemented (so no dependency is claimed)

OCR (`tesseract.js`, `pdfjs-dist`), Stripe, Supabase SDK clients, PWA/service
worker (`serwist`), i18n (`next-intl`), KaTeX/sanitize-html, Sentry, Playwright
and axe are **not installed**. No code or UI claims those capabilities. The
Supabase auth adapter talks to the GoTrue REST API with `fetch` (server-only),
and the spreadsheet/markdown exports use Papaparse without extra packages.

## Added for phases A–C (verified with `npm view <pkg> version license`)

| Package                | Version | Licence | Repository                                               | Used for                                                                     | Docs read                                          |
| ---------------------- | ------- | ------- | -------------------------------------------------------- | ---------------------------------------------------------------------------- | -------------------------------------------------- |
| sonner                 | 2.0.8   | MIT     | https://github.com/emilkowalski/sonner                   | Toasts with an Undo action after card deletion                               | sonner README (`toast`, `action`), `Toaster` props |
| katex                  | 0.19.1  | MIT     | https://github.com/KaTeX/KaTeX                           | Maths rendering, **server-side only** (keeps KaTeX out of the client bundle) | katex.org `renderToString` options                 |
| sanitize-html          | 2.18.1  | MIT     | https://github.com/apostrophecms/sanitize-html           | Strip every tag from AI/pasted text before rendering                         | README `allowedTags: []` behaviour                 |
| @types/sanitize-html   | 2.16.0  | MIT     | —                                                        | Types                                                                        | —                                                  |
| stripe                 | 23.0.1  | MIT     | https://github.com/stripe/stripe-node                    | Checkout Session, Billing Portal, `webhooks.constructEvent`                  | Stripe Node README + API reference                 |
| idb                    | 8.0.4   | ISC     | https://github.com/jakearchibald/idb                     | IndexedDB wrapper for the offline review queue                               | idb README (`openDB`)                              |
| @vitest/coverage-v8    | 5.0.5   | MIT     | https://github.com/vitest-dev/vitest                     | Coverage reporting                                                           | vitest coverage docs                               |
| jsdom                  | 28.0.0  | MIT     | https://github.com/jsdom/jsdom                           | DOM for component tests                                                      | vitest environment docs                            |
| @testing-library/react | 16.3.3  | MIT     | https://github.com/testing-library/react-testing-library | Component tests                                                              | testing-library docs                               |
| prettier               | 3.9.10  | MIT     | https://github.com/prettier/prettier                     | Formatting + `format:check` in CI                                            | prettier options                                   |
| husky                  | 9.1.7   | MIT     | https://github.com/typicode/husky                        | Pre-commit hook                                                              | husky 9 docs                                       |
| lint-staged            | 17.6.0  | MIT     | https://github.com/lint-staged/lint-staged               | Prettier + ESLint on staged files                                            | lint-staged README                                 |

No new Apache-2.0 dependencies were introduced in this phase, so `NOTICE` is
unchanged. The licence gate now covers every one of these.

## Billing and OCR notes

- Stripe is env-gated. Without `STRIPE_SECRET_KEY` the checkout route returns 403
  and the UI disables the button — there is no fake success path. With a key but a
  missing price id the route returns 503 naming the variable to set.
- OCR is still **not** shipped. `POST /api/documents` returns `NO_TEXT_LAYER` for
  image-only PDFs and the UI says so. No `tesseract.js`/`pdfjs-dist` dependency is
  installed, so no capability is implied.


## OCR, PWA and E2E additions

| Package | Version | Licence | Repository | Used for | Docs read |
| --- | --- | --- | --- | --- | --- |
| tesseract.js | 7.0.0 | **Apache-2.0** | https://github.com/naptha/tesseract.js | OCR of scanned pages (worker, capped by `OCR_MAX_PAGES`) | README + installed `createWorker` typings; language data downloaded at runtime |
| pdfjs-dist | 6.4.299 | **Apache-2.0** | https://github.com/mozilla/pdf.js | Rasterise scanned pages server-side | installed `api.d.ts` (`getDocument`, `page.render({ canvas, viewport })`) |
| @napi-rs/canvas | 1.0.13 | MIT | https://github.com/Brooooooklyn/canvas | Prebuilt canvas backend for pdf.js in Node | README (`createCanvas`, `toBuffer`) |
| @playwright/test | 1.64.1 | **Apache-2.0** | https://github.com/microsoft/playwright | E2E at 390×844 and 1440×900 (dev) | playwright.dev test docs, `webServer`, `globalSetup` |
| @axe-core/playwright | 4.14.0 | MPL-2.0 | https://github.com/dequelabs/axe-core-npm | Accessibility assertions (dev, unmodified) | axe-core-npm README |
| pg | 8.20.0 | MIT | https://github.com/brianc/node-postgres | Already present; also used by E2E global setup to clear limiter windows | node-postgres docs |

Apache-2.0 attributions for tesseract.js, pdf.js and Playwright are recorded in
`NOTICE` and rendered at `/licences`.

## PWA approach

The service worker is hand-written (`public/sw.js`) rather than generated by
`@serwist/next`, which avoids a Turbopack-incompatible build plugin and keeps the
offline rules auditable: `/api/*` is never cached (no cross-user data), navigations
fall back to the cached shell and then `/offline.html`, and static build assets are
cache-first. `idb` (ISC) stores the review queue.

## i18n approach

`next-intl` was **not** added: routing-based i18n would have changed every URL. Instead
`src/lib/i18n/messages.ts` holds typed dictionaries (en, hi), a cookie selects the
locale server-side, and components receive translated labels as props. Adding a
language is one dictionary entry plus one line in `LOCALES`; a unit test fails if keys
are missing.
