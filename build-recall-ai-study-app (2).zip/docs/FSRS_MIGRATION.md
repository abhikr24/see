# SM-2 → FSRS v5 migration

`ts-fsrs@5.4.2` (MIT) replaces the hand-rolled SM-2 scheduler.

## Schema

`cards` keeps the legacy columns (`ease`, `interval_days`, `reps`, `lapses`) and
adds `fsrs_state`, `stability`, `difficulty`, `scheduled_days`, `elapsed_days`
and `learning_steps`. Existing rows are backfilled on their **next review**,
without a destructive migration:

- `difficulty ≈ clamp(6.5 − ease, 1, 10)`
- `stability ≈ max(interval_days, 0.1)`
- `state` is derived from `lapses`/`reps` when not present (`review` for cards
  with a history, `new` otherwise).

## Behaviour

- The UI still exposes four grades: Again 0, Hard 1, Good 2, Easy 3.
- `ease` remains populated (`6.5 − difficulty`) so older screens and exports are
  unchanged; `interval_days` mirrors `scheduled_days`.
- Scheduling is deterministic when `enable_fuzz` is false and the clock is fixed;
  tests in `tests/scheduler.test.ts` cover a fixed clock, lapse handling, legacy
  backfill and the 365-day cap.
- Per-user desired retention (default 0.90) is stored in `users.desired_retention`
  and editable in Billing → Scheduling.
