# Quality evidence

Run locally with `npm test`. Results at the time of writing:

- 59 tests across 4 files, all passing.
- Five fixtures (`tests/fixtures/documents.ts`): textbook chapter, academic paper,
  lecture slides, legal contract and an image-only scan.
- Per fixture: card-count band, zero heading answers, zero trailing ellipses, every
  card passes `validateCard`, quality score ≥ the fixture threshold (85% for prose,
  80% for slides), top-concept coverage threshold (70–75% of the top 8).
- Reviewed snapshots: `tests/__snapshots__/engine.test.ts.snap` — any change to card
  selection or wording is visible in review.
- Anki CSV: uniform four-column rows, `Front,Back,Tags,Page` header, `<br>` for line
  breaks, quote escaping and a PapaParse round-trip test. Quizlet TSV: two columns.
- FSRS: fixed-clock determinism, lapse handling, legacy SM-2 backfill, 365-day cap.
- Login limiter: allows five attempts, blocks the sixth, fails open if the store is
  unavailable.
- Auth configuration: four provider/key combinations; supabase with a missing key
  throws instead of silently using local auth.

Known trade-offs:

- `natural` was not shipped; a local Porter stemmer reproduces the behaviour needed.
- Subject detection is derived from the leading noun phrase because compromise
  does not expose `.subjects()` in 14.19.
- OCR, Stripe, PWA and i18n are not implemented and are labelled as such.
