import { Client } from "pg";

/**
 * E2E setup: clears the rate-limit windows so repeated test runs from one IP are
 * not throttled. The limiter itself is unchanged (and unit-tested).
 */
export default async function globalSetup() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is required for E2E");
  const client = new Client({ connectionString });
  await client.connect();
  try {
    await client.query("delete from rate_limits");
  } finally {
    await client.end();
  }
}
