import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

const PASSWORD = "testing1234";

const CHAPTER = `Chapter 4 - Cell Transport

Diffusion is the net movement of particles from a region of higher concentration to a region of lower concentration. Diffusion stops when the concentration gradient disappears and the cell reaches equilibrium.

Osmosis

Osmosis is the diffusion of water across a selectively permeable membrane. Water moves from a dilute solution to a concentrated solution during osmosis. A red blood cell placed in a hypertonic solution loses water and shrinks.

Active Transport

Active transport moves substances against their concentration gradient and therefore requires energy from ATP. The sodium potassium pump moves three sodium ions out of the cell for every two potassium ions it brings in. The resting potential of a typical neuron is approximately -70 mV.`;

async function createAccount(page: Page, email: string): Promise<void> {
  await page.goto("/login");
  await page.getByRole("button", { name: "Create account", exact: true }).click();
  await page.getByLabel("Name").fill("E2E Learner");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(PASSWORD);
  await page.getByRole("button", { name: /create my workspace/i }).click();
  await page.waitForURL(/\/app/, { timeout: 60_000 });
}

async function loginAsDemo(page: Page): Promise<void> {
  await page.goto("/login");
  await page.getByLabel("Email").fill("demo@recall.studio");
  await page.getByLabel("Password").fill("recall1234");
  await page
    .getByRole("button", { name: /^sign in$/i })
    .last()
    .click();
  await page.waitForURL(/\/app/, { timeout: 60_000 });
}

async function generateDeck(page: Page): Promise<string> {
  await page.goto("/app/new");
  await page.getByRole("button", { name: "Paste text", exact: true }).click();
  await page.getByLabel("Title", { exact: true }).fill("E2E Cell Transport");
  await page.getByPlaceholder(/paste a chapter/i).fill(CHAPTER);
  await page.getByRole("button", { name: /generate memory material/i }).click();
  await page.waitForURL(/\/app\/documents\/[0-9a-f-]{36}/, { timeout: 120_000 });
  return page.url().split("/").pop() ?? "";
}

test.describe("Recall end to end", () => {
  test("signup → generate → grade → quiz → export → delete", async ({ page }) => {
    await createAccount(page, `e2e-${Date.now()}@example.com`);
    await generateDeck(page);

    // Deck badge and quality are shown.
    await expect(page.getByText(/quality/i).first()).toBeVisible();

    // Review: reveal with the keyboard, grade with "3" (Good).
    await page
      .getByRole("button", { name: /show answer/i })
      .first()
      .click();
    await page.keyboard.press("3");
    await expect(page.getByText(/answer/i).first()).toBeVisible();

    // Quiz tab renders a graded attempt.
    await page.getByRole("tab", { name: /quiz/i }).click();
    await expect(page.getByText(/question 1 of|no quiz|multiple-choice/i).first()).toBeVisible();

    // Export a real file.
    const download = page.waitForEvent("download");
    await page.getByRole("link", { name: /anki csv/i }).click();
    expect((await download).suggestedFilename()).toMatch(/\.csv$/);

    // Card management: filter, then import an extra card.
    await page.getByRole("tab", { name: /^cards$/i }).click();
    await page.getByPlaceholder(/search prompts/i).fill("membrane");
    await expect(page.getByText(/card(s)? shown/i)).toBeVisible();

    // Delete the deck from the overview (trash icon → confirm).
    await page.goto("/app");
    await page
      .getByRole("button", { name: /delete document/i })
      .first()
      .click();
    await page.getByRole("button", { name: "Delete", exact: true }).first().click();
    await page.waitForTimeout(1500);
    await page.reload();
    await expect(page.getByText("E2E Cell Transport")).toHaveCount(0, { timeout: 20_000 });
  });

  test("cross-user isolation returns 404 for another user's deck", async ({ page, playwright }) => {
    await createAccount(page, `owner-${Date.now()}@example.com`);
    const documentId = await generateDeck(page);

    // A completely separate cookie jar for the second learner.
    const intruder = await playwright.request.newContext();
    await intruder.post("/api/auth/signup", {
      data: { name: "Intruder", email: `intruder-${Date.now()}@example.com`, password: PASSWORD },
    });

    expect((await intruder.delete(`/api/documents/${documentId}`)).status()).toBe(404);
    expect((await intruder.get(`/api/documents/${documentId}/cards`)).status()).toBe(404);
    expect((await intruder.get(`/api/export/${documentId}?format=csv`)).status()).toBe(404);
    expect((await intruder.post("/api/quiz", { data: { documentId, answers: [] } })).status()).toBe(
      400,
    );

    // The owner still sees the deck.
    await page.goto(`/app/documents/${documentId}`);
    await expect(page.getByRole("tab", { name: /review/i })).toBeVisible();
    await intruder.dispose();
  });

  for (const path of ["/", "/login", "/pricing", "/licences", "/app"]) {
    test(`axe: no serious violations on ${path}`, async ({ page }) => {
      // Demo account avoids burning the signup limiter; it is seeded on first visit.
      await loginAsDemo(page);
      await page.goto(path);
      const results = await new AxeBuilder({ page }).analyze();
      const serious = results.violations
        .filter((violation) => ["serious", "critical"].includes(violation.impact ?? ""))
        .map((violation) => `${violation.id}: ${violation.help}`);
      expect(JSON.stringify(serious)).toBe("[]");
    });
  }

  test("language switch renders Hindi navigation and persists", async ({ page }) => {
    await loginAsDemo(page);
    const saved = page.waitForResponse((response) => response.url().includes("/api/locale"));
    await page
      .getByRole("combobox", { name: /language/i })
      .last()
      .selectOption("hi");
    expect((await saved).status()).toBe(200);
    // router.refresh() re-renders in place, so assert without navigating.
    // The desktop sidebar copy is hidden at 390 px, so target the visible node.
    await expect(page.locator("text=अवलोकन").locator("visible=true").first()).toBeVisible({
      timeout: 20_000,
    });
    await expect(page.locator("text=दोहराएँ").locator("visible=true").first()).toBeVisible({
      timeout: 20_000,
    });
  });
});
