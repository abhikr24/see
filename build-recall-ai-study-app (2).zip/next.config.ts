import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // OCR and rasterisation use native binaries and worker scripts; keep them out
  // of the bundler so they are resolved at runtime on the server only.
  serverExternalPackages: ["pdfjs-dist", "tesseract.js", "@napi-rs/canvas"],
  async headers() {
    return [
      {
        source: "/sw.js",
        headers: [
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
          { key: "Service-Worker-Allowed", value: "/" },
        ],
      },
    ];
  },
};

export default nextConfig;
