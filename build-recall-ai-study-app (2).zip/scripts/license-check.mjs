#!/usr/bin/env node
/**
 * CI licence gate. Checks every installed production dependency (direct and
 * transitive) against the permissive allowlist agreed for commercial use.
 * Run: npm run license:check
 */
import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const ALLOWED = new Set([
  "MIT",
  "ISC",
  "BSD-2-Clause",
  "BSD-3-Clause",
  "Apache-2.0",
  "0BSD",
  "CC0-1.0",
  "Unlicense",
  "BlueOak-1.0.0",
  "Python-2.0",
  // MIT-0 is MIT with the attribution clause removed — strictly more permissive.
  // Reached only through jsdom (component tests).
  "MIT-0",
]);

/**
 * Reviewed exceptions. Each entry is a transitive dependency that cannot be
 * removed without breaking the framework/toolchain. Keep this list short and
 * justify every line in docs/DEPENDENCIES.md. Nothing else may bypass the gate.
 */
const EXCEPTIONS = [
  {
    match: /^@img\/sharp-libvips-/,
    license: "LGPL-3.0-or-later",
    reason:
      "Optional binary for Next image optimisation. Never imported by Recall; exclude with `npm ci --omit=optional` on production hosts.",
  },
  {
    match: /^lightningcss/,
    license: "MPL-2.0",
    reason:
      "Build-time CSS transformer used by Tailwind; unmodified, not linked into application code.",
  },
  {
    match: /^caniuse-lite$/,
    license: "CC-BY-4.0",
    reason: "Browser support data used at build time; attributed to caniuse.com in NOTICE.",
  },
];

const packageJson = JSON.parse(readFileSync("package.json", "utf8"));
const lock = JSON.parse(readFileSync("package-lock.json", "utf8"));
const rootDeps = new Set(Object.keys(packageJson.dependencies ?? {}));
const devDeps = new Set(Object.keys(packageJson.devDependencies ?? {}));
const packages = lock.packages ?? {};

const violations = [];
const missing = [];
let checked = 0;
const exceptionsUsed = new Set();

for (const [path, meta] of Object.entries(packages)) {
  if (!path || meta.dev) continue;
  const name = path.replace(/^node_modules\//, "").replace(/.*node_modules\//, "");
  if (!name) continue;
  const manifestPath = join(path, "package.json");
  if (!existsSync(manifestPath)) continue;
  const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
  const license = typeof manifest.license === "string" ? manifest.license : manifest.license?.type;
  checked += 1;
  if (!license) {
    if (rootDeps.has(name)) missing.push(`${name}@${manifest.version ?? "?"}`);
    continue;
  }
  const normalized = license.replace(/[()]/g, "").trim();
  if (!ALLOWED.has(normalized)) {
    const exception = EXCEPTIONS.find((entry) => entry.match.test(name));
    if (exception && exception.license === normalized) {
      exceptionsUsed.add(`${name} (${normalized})`);
      continue;
    }
    violations.push(`${name}@${manifest.version ?? "?"} → ${license}`);
  }
}

const forbidden = [...rootDeps].filter((name) => devDeps.has(name) === false);
console.log(`Checked ${checked} production packages (${forbidden.length} direct dependencies).`);

if (missing.length > 0 || violations.length > 0) {
  if (missing.length) console.error(`Missing licence metadata:\n  ${missing.join("\n  ")}`);
  if (violations.length) console.error(`Disallowed licences:\n  ${violations.join("\n  ")}`);
  process.exit(1);
}

if (exceptionsUsed.size > 0) {
  console.log("Reviewed transitive exceptions applied:");
  for (const entry of [...exceptionsUsed].sort()) console.log(`  · ${entry}`);
}
console.log("All production dependency licences are commercially safe.");
