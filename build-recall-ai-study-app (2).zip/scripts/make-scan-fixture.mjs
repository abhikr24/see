#!/usr/bin/env node
/**
 * Builds tests/fixtures/scanned-handout.pdf: a real image-only PDF (no text
 * layer) so the OCR path can be exercised end to end in this sandbox.
 */
import { createCanvas } from "@napi-rs/canvas";
import { writeFileSync } from "node:fs";

const LINES = [
  "BIOLOGY 101 - OSMOSIS",
  "Osmosis is the diffusion of water",
  "across a selectively permeable membrane.",
  "Water moves from high water potential",
  "to low water potential.",
  "The membrane is selectively permeable.",
];

const width = 1240;
const height = 1600;
const canvas = createCanvas(width, height);
const ctx = canvas.getContext("2d");
ctx.fillStyle = "#ffffff";
ctx.fillRect(0, 0, width, height);
ctx.fillStyle = "#111111";
ctx.font = "bold 46px sans-serif";
ctx.fillText(LINES[0], 80, 160);
ctx.font = "38px sans-serif";
LINES.slice(1).forEach((line, index) => ctx.fillText(line, 80, 280 + index * 70));
const jpeg = canvas.toBuffer("image/jpeg", 92);

const objects = [];
objects.push("<< /Type /Catalog /Pages 2 0 R >>");
objects.push("<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
objects.push(
  `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`,
);
objects.push(
  `<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`,
);
objects.push("<< /Length 44 >>\nstream\nq 1240 0 0 1600 0 0 cm /Im0 Do Q\nendstream");

const chunks = [Buffer.from("%PDF-1.4\n", "latin1")];
const offsets = [0];
objects.forEach((body, index) => {
  offsets[index + 1] = chunks.reduce((total, chunk) => total + chunk.length, 0);
  if (index === 3) {
    chunks.push(
      Buffer.from(`${index + 1} 0 obj\n${body}`, "latin1"),
      jpeg,
      Buffer.from("\nendstream\nendobj\n", "latin1"),
    );
  } else {
    chunks.push(Buffer.from(`${index + 1} 0 obj\n${body}\nendobj\n`, "latin1"));
  }
});
const body = Buffer.concat(chunks);
const startxref = body.length;
const xref = [
  "xref",
  `0 ${objects.length + 1}`,
  "0000000000 65535 f ",
  ...offsets.slice(1).map((offset) => `${String(offset).padStart(10, "0")} 00000 n `),
  "trailer",
  `<< /Size ${objects.length + 1} /Root 1 0 R >>`,
  "startxref",
  String(startxref),
  "%%EOF",
  "",
].join("\n");

writeFileSync(
  "tests/fixtures/scanned-handout.pdf",
  Buffer.concat([body, Buffer.from(xref, "latin1")]),
);
console.log("wrote tests/fixtures/scanned-handout.pdf", (body.length + xref.length) / 1024, "KB");
