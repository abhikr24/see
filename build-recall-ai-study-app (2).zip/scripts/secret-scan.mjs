#!/usr/bin/env node
/**
 * Pre-commit secret scan. Fails on keys, service-role tokens and database URLs
 * committed to tracked files, and refuses .env files outright.
 */
import { execSync } from "node:child_process";
import { readFileSync, existsSync } from "node:fs";

const PATTERNS = [
  { name: "OpenAI-style key", regex: /\bsk-[A-Za-z0-9_-]{16,}/ },
  { name: "Anthropic key", regex: /\bsk-ant-[A-Za-z0-9_-]{16,}/ },
  { name: "Groq key", regex: /\bgsk_[A-Za-z0-9]{20,}/ },
  { name: "Stripe secret key", regex: /\bsk_(live|test)_[A-Za-z0-9]{10,}/ },
  { name: "Stripe webhook secret", regex: /\bwhsec_[A-Za-z0-9]{10,}/ },
  { name: "Supabase service role", regex: /service_role/ },
  { name: "Postgres URL with password", regex: /postgres(?:ql)?:\/\/[^\s:@"]+:[^\s@"]+@/ },
  { name: "Private key block", regex: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/ },
];

const ALLOWED_FILES = new Set([
  "src/app/api/health/route.ts",
  "scripts/secret-scan.mjs",
  ".env.example",
  "docs/DEPENDENCIES.md",
  "docs/VERIFICATION.md",
]);

let files = [];
try {
  files = execSync("git diff --cached --name-only --diff-filter=ACM", { encoding: "utf8" })
    .split("\n")
    .filter(Boolean);
} catch {
  console.log("secret-scan: git unavailable, skipping staged-file scan");
  process.exit(0);
}

const findings = [];
for (const file of files) {
  if (/(^|\/)\.env(\.|$)/.test(file) && !file.endsWith(".env.example")) {
    findings.push(`${file}: .env files must never be committed`);
    continue;
  }
  if (ALLOWED_FILES.has(file) || !existsSync(file)) continue;
  if (/\.(png|jpg|jpeg|pdf|lock)$/.test(file)) continue;
  const content = readFileSync(file, "utf8");
  for (const pattern of PATTERNS) {
    if (pattern.regex.test(content)) findings.push(`${file}: possible ${pattern.name}`);
  }
}

if (findings.length > 0) {
  console.error("Secret scan failed:\n  " + findings.join("\n  "));
  console.error("Remove the secret, rotate it, and use process.env instead.");
  process.exit(1);
}
console.log(`secret-scan: ${files.length} staged file(s) clean`);
