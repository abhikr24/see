import { NextResponse } from "next/server";
import { z } from "zod";
import { signIn } from "@/lib/auth";
import { attachSessionCookie, attachSupabaseCookies } from "@/lib/auth/http";
import { clientIp, consumeRateLimit, rateLimitResponse } from "@/lib/rate-limit";
import { jsonError, requestIdFor } from "@/lib/http";

export const runtime = "nodejs";

const schema = z.object({
  email: z.string().min(3),
  password: z.string().min(1),
});

export async function POST(request: Request) {
  const requestId = requestIdFor(request);
  const ip = clientIp(request);
  const limit = await consumeRateLimit("login", ip);
  if (!limit.allowed) return rateLimitResponse("login", limit);

  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Enter your email and password." }, { status: 400 });
  }

  const result = await signIn(parsed.data.email, parsed.data.password);
  if (!result.ok) {
    return jsonError(401, "INVALID_CREDENTIALS", result.error, requestId);
  }

  const response = NextResponse.json({ ok: true, status: "signed_in", user: result.user });
  if (result.sessionToken) attachSessionCookie(response, result.sessionToken);
  if (result.tokens) attachSupabaseCookies(response, result.tokens);
  return response;
}
