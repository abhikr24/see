import { NextResponse } from "next/server";
import { z } from "zod";
import { signUp } from "@/lib/auth";
import { attachSessionCookie, attachSupabaseCookies } from "@/lib/auth/http";
import { clientIp, consumeRateLimit, rateLimitResponse } from "@/lib/rate-limit";
import { jsonError, requestIdFor } from "@/lib/http";

export const runtime = "nodejs";

const schema = z.object({
  name: z.string().min(1).max(80),
  email: z.string().min(3),
  password: z.string().min(8).max(200),
});

export async function POST(request: Request) {
  const requestId = requestIdFor(request);
  const limit = await consumeRateLimit("signup", clientIp(request));
  if (!limit.allowed) return rateLimitResponse("signup", limit);

  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Use a valid email and a password of at least 8 characters." },
      { status: 400 },
    );
  }

  const result = await signUp(parsed.data.name, parsed.data.email, parsed.data.password);
  if (!result.ok) {
    return jsonError(400, "SIGNUP_REJECTED", result.error, requestId);
  }

  if (result.status === "confirm_email") {
    return NextResponse.json(
      {
        ok: true,
        status: "confirm_email",
        message: "Check your inbox to confirm your email, then sign in.",
      },
      { status: 202 },
    );
  }

  const response = NextResponse.json({ ok: true, status: "signed_in", user: result.user });
  if (result.sessionToken) attachSessionCookie(response, result.sessionToken);
  if (result.tokens) attachSupabaseCookies(response, result.tokens);
  return response;
}
