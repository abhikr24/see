import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import {
  billingConfigured,
  detectCurrency,
  PRICES,
  priceFor,
  stripeClient,
} from "@/lib/billing/stripe";
import { activateDemoPro, DEMO_EMAIL, getSubscription, setStripeCustomer } from "@/lib/repository";
import { jsonError, logServerError, requestIdFor } from "@/lib/http";

export const runtime = "nodejs";

const schema = z.object({
  currency: z.enum(["inr", "usd"]).optional(),
  interval: z.enum(["month", "year"]).optional(),
});

export async function POST(request: Request) {
  const requestId = requestIdFor(request);
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "UNAUTHENTICATED", "Please sign in first.", requestId);

  const parsed = schema.safeParse(await request.json().catch(() => ({})));
  const currency = detectCurrency(request, parsed.success ? parsed.data.currency : null);
  const interval = parsed.success ? (parsed.data.interval ?? "month") : "month";

  if (billingConfigured()) {
    const stripe = stripeClient();
    const price = priceFor(currency, interval);
    if (!stripe || !price) {
      return jsonError(
        503,
        "BILLING_PRICE_MISSING",
        `Stripe is configured but no price id is set for ${currency.toUpperCase()} ${interval}ly billing. Add STRIPE_PRICE_${currency.toUpperCase()}_${interval === "year" ? "YEAR" : "MONTH"}.`,
        requestId,
      );
    }

    try {
      const existing = await getSubscription(user.id);
      let customerId = existing?.stripeCustomerId ?? null;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: user.name,
          metadata: { userId: user.id },
        });
        customerId = customer.id;
        await setStripeCustomer(user.id, customerId);
      }

      const origin = new URL(request.url).origin;
      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        customer: customerId,
        line_items: [{ price, quantity: 1 }],
        allow_promotion_codes: true,
        client_reference_id: user.id,
        subscription_data: { metadata: { userId: user.id } },
        metadata: { userId: user.id },
        success_url: `${origin}/app/billing?checkout=success`,
        cancel_url: `${origin}/app/billing?checkout=cancelled`,
      });

      return NextResponse.json({ ok: true, mode: "stripe", url: session.url, currency, interval });
    } catch (error) {
      logServerError("stripe_checkout", requestId, error);
      return jsonError(
        502,
        "STRIPE_ERROR",
        "Stripe could not start the checkout. Nothing was charged — try again in a moment.",
        requestId,
      );
    }
  }

  const demoEnabled = process.env.ALLOW_DEMO_BILLING === "true";
  const demoAccountOnly = process.env.NODE_ENV === "production" && user.email !== DEMO_EMAIL;
  if (demoEnabled && !demoAccountOnly) {
    const updated = await activateDemoPro(user.id);
    if (!updated)
      return jsonError(500, "BILLING_FAILED", "Could not activate Pro. Try again.", requestId);
    return NextResponse.json({
      ok: true,
      mode: "demo",
      demo: true,
      plan: updated.plan,
      aiCredits: updated.aiCredits,
      price: PRICES[currency][interval === "year" ? "yearly" : "monthly"],
      currency,
      message: "Pro activated on this demo deployment. No payment was taken.",
    });
  }

  return jsonError(
    403,
    "BILLING_NOT_CONFIGURED",
    "Checkout is not connected in this deployment. The rules engine stays free and unlimited; Pro activation is managed by the operator.",
    requestId,
  );
}
