import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { billingConfigured, stripeClient } from "@/lib/billing/stripe";
import { getSubscription } from "@/lib/repository";
import { jsonError, logServerError, requestIdFor } from "@/lib/http";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const requestId = requestIdFor(request);
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "UNAUTHENTICATED", "Please sign in first.", requestId);

  const stripe = stripeClient();
  const subscription = await getSubscription(user.id);
  const customerId = subscription?.stripeCustomerId;
  if (!billingConfigured() || !stripe || !customerId) {
    return jsonError(
      403,
      "PORTAL_UNAVAILABLE",
      "There is no Stripe subscription to manage on this account. If you upgraded on a demo deployment, ask the operator to change the plan.",
      requestId,
    );
  }

  try {
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${new URL(request.url).origin}/app/billing`,
    });
    return NextResponse.json({ ok: true, url: session.url });
  } catch (error) {
    logServerError("stripe_portal", requestId, error);
    return jsonError(
      502,
      "STRIPE_ERROR",
      "Could not open the billing portal. Try again.",
      requestId,
    );
  }
}
