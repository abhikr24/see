import { NextResponse } from "next/server";
import {
  classifyEvent,
  customerIdOf,
  metadataUserId,
  periodEndOf,
  subscriptionFrom,
  subscriptionPriceOf,
} from "@/lib/billing/webhook";
import { stripeClient, stripeWebhookSecret, type Stripe } from "@/lib/billing/stripe";
import {
  claimStripeEvent,
  downgradeUser,
  findUserIdByCustomer,
  renewUserCredits,
  saveSubscription,
  upgradeUser,
} from "@/lib/repository";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Stripe webhook. Idempotent: each event id is claimed in stripe_events before
 * any mutation, so a replay or a double delivery cannot grant credits twice.
 * Never trusts the client for plan state.
 */
export async function POST(request: Request) {
  const stripe = stripeClient();
  const secret = stripeWebhookSecret();
  if (!stripe || !secret) {
    return NextResponse.json(
      { error: "Stripe is not configured on this server.", code: "STRIPE_NOT_CONFIGURED" },
      { status: 503 },
    );
  }

  const signature = request.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json({ error: "Missing stripe-signature." }, { status: 400 });
  }

  const payload = await request.text();
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(payload, signature, secret);
  } catch (error) {
    console.error(
      "stripe_webhook_signature_failed",
      error instanceof Error ? error.message : error,
    );
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  const claimed = await claimStripeEvent(event.id, event.type);
  if (!claimed) return NextResponse.json({ ok: true, duplicate: true });

  const outcome = classifyEvent(event);
  if (outcome.kind === "ignored") return NextResponse.json({ ok: true, ignored: outcome.reason });

  const subscription = subscriptionFrom(event);
  const customerId = subscription ? customerIdOf(subscription.customer) : null;
  const userId =
    metadataUserId(event) ?? (customerId ? await findUserIdByCustomer(customerId) : null);

  if (!userId || !customerId) {
    console.error("stripe_webhook_unmapped", { eventId: event.id, type: event.type });
    // 200 so Stripe stops retrying an event we can never map; the ledger keeps the record.
    return NextResponse.json({ ok: true, unmapped: true });
  }

  if (outcome.kind === "upgrade" || outcome.kind === "renewed") {
    if (outcome.kind === "upgrade") await upgradeUser(userId, outcome.credits);
    else await renewUserCredits(userId, outcome.credits);
  } else if (outcome.kind === "downgrade") {
    await downgradeUser(userId);
  }

  if (subscription) {
    const price = subscriptionPriceOf(subscription);
    await saveSubscription({
      userId,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscription.id,
      status: outcome.status,
      priceId: price.priceId,
      currency: price.currency,
      currentPeriodEnd: periodEndOf(subscription),
      cancelAtPeriodEnd: Boolean(subscription.cancel_at_period_end),
    });
  }

  return NextResponse.json({ ok: true, outcome: outcome.kind });
}
