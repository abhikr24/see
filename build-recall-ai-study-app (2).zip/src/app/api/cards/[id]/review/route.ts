import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { reviewCard } from "@/lib/repository";
import type { ReviewGrade } from "@/lib/memory/types";

const schema = z.object({
  grade: z.number().int().min(0).max(3),
  seconds: z.number().int().min(0).max(3600).optional(),
});

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Grade must be 0-3." }, { status: 400 });
  }

  const { id } = await context.params;
  const result = await reviewCard(
    user.id,
    id,
    parsed.data.grade as ReviewGrade,
    parsed.data.seconds ?? 0,
  );
  if (!result) return NextResponse.json({ error: "Card not found." }, { status: 404 });

  return NextResponse.json({ ok: true, next: result });
}
