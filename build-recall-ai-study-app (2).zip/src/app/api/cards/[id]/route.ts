import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { deleteCard, updateCard } from "@/lib/repository";
import { validateCard } from "@/lib/memory/engine";
import type { MemoryCard } from "@/lib/memory/types";

const patchSchema = z
  .object({
    prompt: z.string().min(8).max(500).optional(),
    answer: z.string().min(1).max(240).optional(),
    hint: z.string().max(200).optional(),
    tags: z.array(z.string().min(1).max(30)).max(6).optional(),
    suspended: z.boolean().optional(),
    flagged: z.boolean().optional(),
    flagNote: z.string().max(300).optional(),
  })
  .refine((value) => Object.keys(value).length > 0, { message: "Nothing to update." });

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;

  const parsed = patchSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Check the card fields and try again." }, { status: 400 });
  }

  if (parsed.data.prompt !== undefined || parsed.data.answer !== undefined) {
    const probe: MemoryCard = {
      kind: "ai",
      prompt: parsed.data.prompt ?? "Placeholder question?",
      answer: parsed.data.answer ?? "Placeholder answer",
      hint: "",
      cloze: null,
      quote: "",
      page: 1,
      options: [],
      explanation: "",
      tags: [],
    };
    const validation = validateCard(probe);
    if (!validation.ok) {
      return NextResponse.json(
        {
          error:
            "That edit would create an invalid card. Questions must end in ? or contain _____, and answers must be complete, under 240 characters and not copied from the prompt.",
          code: validation.reason,
        },
        { status: 422 },
      );
    }
  }

  const card = await updateCard(user.id, id, parsed.data);
  if (!card) return NextResponse.json({ error: "Card not found." }, { status: 404 });
  return NextResponse.json({ ok: true, card });
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  const deleted = await deleteCard(user.id, id);
  if (!deleted) return NextResponse.json({ error: "Card not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
