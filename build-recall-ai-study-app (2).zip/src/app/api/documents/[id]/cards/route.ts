import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { addCard, getDocument, getDocumentCards, reorderCards } from "@/lib/repository";
import { requestIdFor } from "@/lib/http";

export const dynamic = "force-dynamic";

const createSchema = z.object({
  prompt: z.string().min(8).max(500),
  answer: z.string().min(1).max(240),
  hint: z.string().max(200).optional(),
  tags: z.array(z.string().min(1).max(30)).max(6).optional(),
  page: z.number().int().min(1).max(10_000).optional(),
});

const orderSchema = z.object({ order: z.array(z.string().uuid()).min(1).max(500) });

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  const doc = await getDocument(user.id, id);
  if (!doc) return NextResponse.json({ error: "Document not found." }, { status: 404 });

  const url = new URL(request.url);
  const page = Number(url.searchParams.get("page") ?? "0");
  const rows = await getDocumentCards(user.id, doc.id, {
    kind: url.searchParams.get("kind") ?? undefined,
    page: Number.isFinite(page) && page > 0 ? page : undefined,
    tag: url.searchParams.get("tag") ?? undefined,
    due: url.searchParams.get("due") === "true",
    flagged: url.searchParams.get("flagged") === "true",
    search: url.searchParams.get("q") ?? undefined,
    includeSuspended: url.searchParams.get("includeSuspended") === "true",
  });

  return NextResponse.json({ cards: rows });
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const requestId = requestIdFor(request);
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;

  const parsed = createSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "A card needs a prompt (8+ characters) and an answer.", requestId },
      { status: 400 },
    );
  }

  const card = await addCard(user.id, id, parsed.data);
  if (!card) return NextResponse.json({ error: "Document not found." }, { status: 404 });
  return NextResponse.json({ ok: true, card }, { status: 201 });
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;

  const parsed = orderSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid card order." }, { status: 400 });

  const reordered = await reorderCards(user.id, id, parsed.data.order);
  if (!reordered) return NextResponse.json({ error: "Document not found." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
