import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { parseCardImport } from "@/lib/import/cards";
import { consumeRateLimit, rateLimitResponse } from "@/lib/rate-limit";
import { addImportedCards } from "@/lib/repository";

export const runtime = "nodejs";

const schema = z.object({
  content: z.string().min(8).max(400_000),
  format: z.enum(["csv", "tsv", "markdown"]).optional(),
});

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const limiter = await consumeRateLimit("upload", user.id);
  if (!limiter.allowed) return rateLimitResponse("upload", limiter);

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Paste a CSV, TSV or Markdown card list first." },
      { status: 400 },
    );
  }

  const { id } = await context.params;
  const result = parseCardImport(parsed.data.content, parsed.data.format);
  if (result.cards.length === 0) {
    return NextResponse.json(
      {
        error:
          "No usable cards found. Use two columns (Front,Back), an Anki/Quizlet export, or Markdown lines like “Q: …” followed by “A: …”.",
        detected: result.detected,
        skipped: result.skipped,
      },
      { status: 422 },
    );
  }

  const saved = await addImportedCards(user.id, id, result.cards);
  if (saved.imported === 0 && saved.skipped === result.cards.length) {
    return NextResponse.json(
      { error: "Those cards are already in this deck.", imported: 0, duplicates: saved.skipped },
      { status: 409 },
    );
  }

  return NextResponse.json({
    ok: true,
    imported: saved.imported,
    duplicates: saved.skipped,
    rejected: result.skipped,
    detected: result.detected,
  });
}
