import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { aiStatus } from "@/lib/ai/provider";
import { describeAuthProvider } from "@/lib/auth/config";
import { ocrStatus } from "@/lib/ocr";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let database = "down";
  try {
    await db.execute(sql`select 1`);
    database = "up";
  } catch (error) {
    console.error("health_db_check_failed", error instanceof Error ? error.message : error);
  }

  const auth = describeAuthProvider();
  const ai = aiStatus();
  const ocr = ocrStatus();
  const healthy = database === "up" && auth.problem === null;

  return NextResponse.json(
    {
      status: healthy ? "ok" : "degraded",
      db: database,
      auth: auth.auth,
      authProblem: auth.problem,
      aiConfigured: ai.configured,
      aiProvider: ai.provider,
      ocr: ocr.available,
      ocrLanguages: ocr.languages,
      node: process.versions.node,
      version: process.env.APP_VERSION ?? "1.0.0",
      time: new Date().toISOString(),
    },
    { status: database === "up" ? 200 : 503 },
  );
}
