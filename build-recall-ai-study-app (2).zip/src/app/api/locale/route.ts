import { NextResponse } from "next/server";
import { isLocale, LOCALES } from "@/lib/i18n/messages";
import { LOCALE_COOKIE } from "@/lib/i18n/server";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { locale?: string } | null;
  if (!isLocale(body?.locale)) {
    return NextResponse.json(
      { error: `Locale must be one of: ${LOCALES.join(", ")}.` },
      { status: 400 },
    );
  }
  const response = NextResponse.json({ ok: true, locale: body.locale });
  response.cookies.set(LOCALE_COOKIE, body.locale, {
    httpOnly: false,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
  return response;
}
