import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { getDocument, getDocumentCards, recordQuizAttempt } from "@/lib/repository";
import type { QuizQuestionResult } from "@/db/schema";

const schema = z.object({
  documentId: z.string().uuid(),
  answers: z
    .array(
      z.object({
        cardId: z.string().uuid(),
        choice: z.string().max(500),
      }),
    )
    .min(1)
    .max(50),
});

function normalise(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, "");
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Send the document id and the answers you chose — not a score." },
      { status: 400 },
    );
  }

  const doc = await getDocument(user.id, parsed.data.documentId);
  if (!doc) return NextResponse.json({ error: "Document not found." }, { status: 404 });

  const rows = await getDocumentCards(user.id, doc.id, { includeSuspended: true });
  const byId = new Map(rows.map((card) => [card.id, card]));

  // Every submitted card must belong to this user's document.
  if (!parsed.data.answers.every((answer) => byId.has(answer.cardId))) {
    return NextResponse.json({ error: "Document not found." }, { status: 404 });
  }

  // Score is recomputed server-side; the client's number is never trusted.
  const results: QuizQuestionResult[] = parsed.data.answers.map((answer) => {
    const card = byId.get(answer.cardId);
    const correctAnswer = card?.answer ?? "";
    return {
      cardId: answer.cardId,
      prompt: card?.prompt ?? "",
      chosen: answer.choice,
      correctAnswer,
      correct: normalise(answer.choice) === normalise(correctAnswer),
    };
  });

  const attempt = await recordQuizAttempt(user.id, doc.id, results);
  const score = results.filter((result) => result.correct).length;

  return NextResponse.json({
    ok: true,
    attemptId: attempt?.id ?? null,
    score,
    total: results.length,
    results,
  });
}
