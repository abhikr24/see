import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { getUserSettings, updateUserSettings } from "@/lib/repository";

const schema = z.object({
  desiredRetention: z.number().min(0.7).max(0.97),
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ settings: await getUserSettings(user.id) });
}

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Desired retention must be between 70% and 97%." },
      { status: 400 },
    );
  }

  const settings = await updateUserSettings(user.id, parsed.data);
  return NextResponse.json({ ok: true, settings });
}
