import { redirect } from "next/navigation";
import Link from "next/link";
import { Lock, ShieldCheck } from "lucide-react";
import BillingPanel from "@/components/app/BillingPanel";
import { getCurrentUser } from "@/lib/auth";
import { aiStatus } from "@/lib/ai/provider";
import { getAiSpendThisMonth, getRecentAiEvents, getUserSettings } from "@/lib/repository";
import { describeAuthProvider } from "@/lib/auth/config";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Billing & keys · Recall",
  description: "Plan, AI credits, spend and deployment status.",
};

export const dynamic = "force-dynamic";

export default async function BillingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const ai = aiStatus();
  const [events, spend, settings] = await Promise.all([
    getRecentAiEvents(user.id, 6),
    getAiSpendThisMonth(user.id),
    getUserSettings(user.id),
  ]);
  const auth = describeAuthProvider();
  const authProvider = auth.auth === "supabase" ? "Supabase" : "Local (Postgres sessions)";

  return (
    <div className="space-y-5">
      <div>
        <p className="eyebrow">Account</p>
        <h1 className="display mt-2 text-3xl sm:text-4xl">Plan, credits & keys.</h1>
        <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-muted">
          The free engine never expires. Pro exists to cover AI tokens — nothing else is gated.
        </p>
      </div>

      <BillingPanel
        plan={user.plan}
        credits={user.aiCredits}
        aiConfigured={ai.configured}
        provider={ai.configured ? `${ai.provider} · ${ai.model}` : null}
        authProvider={authProvider}
        authProblem={auth.problem}
        spend={spend}
        retention={settings?.desiredRetention ?? 0.9}
        demoBillingEnabled={process.env.ALLOW_DEMO_BILLING === "true"}
        usage={events.map((event) => ({
          id: event.id,
          provider: event.provider,
          model: event.model,
          credits: event.credits,
          status: event.status,
          createdAt: event.createdAt.toISOString(),
        }))}
      />

      <div className="card p-5">
        <h2 className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
          Deployment status
        </h2>
        <ul className="mt-3 space-y-2 text-[12px]">
          <li className="flex items-center justify-between gap-3 border-b border-line/60 pb-2">
            <span className="text-muted">Auth provider</span>
            <span className="text-cream">{authProvider}</span>
          </li>
          <li className="flex items-center justify-between gap-3 border-b border-line/60 pb-2">
            <span className="text-muted">AI provider</span>
            <span className={ai.configured ? "text-lime" : "text-cream"}>
              {ai.configured ? ai.provider : "Not configured (free engine active)"}
            </span>
          </li>
          <li className="flex items-center justify-between gap-3 border-b border-line/60 pb-2">
            <span className="text-muted">Sessions</span>
            <span className="text-cream">HTTP-only cookie · hashed token</span>
          </li>
          <li className="flex items-center justify-between gap-3">
            <span className="text-muted">Payments</span>
            <span className="text-cream">
              {process.env.ALLOW_DEMO_BILLING === "true"
                ? "Demo activation (no charge)"
                : "Not connected — operator managed"}
            </span>
          </li>
        </ul>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="chip">
            <Lock className="h-3 w-3" /> No secrets in client bundle
          </span>
          <span className="chip">
            <ShieldCheck className="h-3 w-3" /> Supabase adapter included
          </span>
          <Link href="/licences" className="chip">
            Open-source licences
          </Link>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-muted">
          Switch to Supabase by setting{" "}
          <span className="font-mono text-cream">AUTH_PROVIDER=supabase</span>,{" "}
          <span className="font-mono text-cream">SUPABASE_URL</span> and{" "}
          <span className="font-mono text-cream">SUPABASE_ANON_KEY</span> on the server, then run
          the included SQL migration. See{" "}
          <span className="font-mono text-cream">SUPABASE_SETUP.md</span>.
        </p>
      </div>
    </div>
  );
}
