import { notFound, redirect } from "next/navigation";
import StudyWorkspace from "@/components/app/StudyWorkspace";
import { getCurrentUser } from "@/lib/auth";
import { getDocument, getDocumentCards } from "@/lib/repository";
import { serializeCard } from "@/lib/ui-types";
import { renderRichText } from "@/lib/rich/render";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  const { id } = await params;
  if (!user) return { title: "Study deck · Recall" };
  const doc = await getDocument(user.id, id);
  return { title: doc ? `${doc.title} · Recall` : "Study deck · Recall" };
}

export default async function DocumentPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const { id } = await params;
  const doc = await getDocument(user.id, id);
  if (!doc) notFound();

  const cards = await getDocumentCards(user.id, doc.id);

  return (
    <StudyWorkspace
      doc={{
        id: doc.id,
        title: doc.title,
        engine: doc.engine,
        requestedEngine: doc.requestedEngine,
        qualityScore: doc.qualityScore,
        sourceType: doc.sourceType,
        pageCount: doc.pageCount,
        wordCount: doc.wordCount,
        createdAt: doc.createdAt.toISOString(),
        rawText: doc.rawText,
        rawHtml: renderRichText(doc.rawText),
        analysis: doc.analysis,
      }}
      cards={cards.map((card) => ({
        ...serializeCard(card),
        promptHtml: renderRichText(card.prompt),
        answerHtml: renderRichText(card.answer),
      }))}
    />
  );
}
