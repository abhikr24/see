"use client";

import { CircleAlert } from "lucide-react";

export default function AppError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="card p-6 text-center sm:p-8">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-coral/30 bg-coral/10 text-coral">
        <CircleAlert className="h-5 w-5" />
      </span>
      <h1 className="display mt-4 text-2xl">This view hit an error.</h1>
      <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-muted">
        Nothing was lost. Retry the view; if it repeats, share the reference with your operator.
      </p>
      {error.digest && (
        <p className="mt-2 font-mono text-[11px] text-muted">Reference: {error.digest}</p>
      )}
      <button type="button" onClick={reset} className="btn btn-primary mt-5">
        Retry
      </button>
    </div>
  );
}
