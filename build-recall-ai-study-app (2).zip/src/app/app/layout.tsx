import { redirect } from "next/navigation";
import { and, eq, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { cards } from "@/db/schema";
import AppShell from "@/components/app/AppShell";
import OfflineProvider from "@/components/offline/OfflineProvider";
import { getCurrentUser } from "@/lib/auth";
import { getTranslator } from "@/lib/i18n/server";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const { locale, t } = await getTranslator();

  const [due] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(cards)
    .where(and(eq(cards.userId, user.id), lte(cards.dueAt, new Date())));

  return (
    <OfflineProvider>
      <AppShell
        user={{
          name: user.name,
          email: user.email,
          plan: user.plan,
          aiCredits: user.aiCredits,
          streak: user.streak,
        }}
        dueCount={due?.count ?? 0}
        locale={locale}
        labels={{
          overview: t("nav.overview"),
          newSource: t("nav.new"),
          review: t("nav.review"),
          billing: t("nav.billing"),
          signOut: t("app.signOut"),
          language: t("common.language"),
        }}
      >
        {children}
      </AppShell>
    </OfflineProvider>
  );
}
