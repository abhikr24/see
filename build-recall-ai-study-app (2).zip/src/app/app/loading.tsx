export default function Loading() {
  return (
    <div className="space-y-4" aria-busy="true" aria-live="polite">
      <span className="sr-only">Loading your workspace</span>
      <div className="h-8 w-2/3 animate-pulse rounded-lg bg-white/[0.06]" />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[0, 1, 2, 3].map((key) => (
          <div key={key} className="card-flat h-20 animate-pulse" />
        ))}
      </div>
      <div className="card h-40 animate-pulse" />
      <div className="space-y-2">
        {[0, 1, 2].map((key) => (
          <div key={key} className="card-flat h-24 animate-pulse" />
        ))}
      </div>
    </div>
  );
}
