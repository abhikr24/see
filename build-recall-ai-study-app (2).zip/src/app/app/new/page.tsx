import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Brain, CircleCheck, Layers, ListChecks, Repeat, Sparkles } from "lucide-react";
import UploadStudio from "@/components/app/UploadStudio";
import { getCurrentUser } from "@/lib/auth";
import { aiStatus } from "@/lib/ai/provider";

export const metadata: Metadata = {
  title: "New source · Recall",
  description: "Turn a PDF, text file or pasted notes into cards.",
};

export const dynamic = "force-dynamic";

export default async function NewSourcePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const ai = aiStatus();

  return (
    <div className="space-y-5">
      <div>
        <Link
          href="/app"
          className="mb-3 inline-flex items-center gap-1.5 text-[11.5px] text-muted hover:text-cream"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to overview
        </Link>
        <h1 className="display text-3xl sm:text-4xl">Turn a source into memory material.</h1>
        <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-muted">
          Upload a PDF or paste text. Recall extracts, cleans and ranks the content, then generates
          flashcards, cloze deletions, a graded quiz and a study plan.
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.5fr_0.9fr] lg:items-start">
        <UploadStudio
          plan={user.plan}
          aiCredits={user.aiCredits}
          aiConfigured={ai.configured}
          provider={ai.configured ? `${ai.provider} · ${ai.model}` : null}
        />

        <aside className="space-y-4">
          <div className="card p-4 sm:p-5">
            <h2 className="text-[13px] font-semibold text-cream">What gets generated</h2>
            <ul className="mt-3 space-y-2.5 text-[12px] leading-relaxed text-muted">
              {[
                { icon: Layers, text: "Definition, fact and sequence cards with page citations" },
                { icon: Brain, text: "Cloze deletions on the highest-weight terms" },
                { icon: ListChecks, text: "Multiple-choice quiz with source-derived distractors" },
                { icon: Repeat, text: "FSRS schedule so reviews arrive before you forget" },
                { icon: Sparkles, text: "Teach-it-back prompts for elaboration" },
              ].map((item) => (
                <li key={item.text} className="flex gap-2">
                  <item.icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime" />
                  {item.text}
                </li>
              ))}
            </ul>
          </div>

          <div className="card p-4 sm:p-5">
            <h2 className="text-[13px] font-semibold text-cream">For the best deck</h2>
            <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-muted">
              <li>• 1,500+ words of prose beats a slide dump.</li>
              <li>• Native text PDFs work; scans need OCR first.</li>
              <li>• One topic per upload keeps cards focused.</li>
              <li>• Multi-column layouts may need a text paste.</li>
            </ul>
            <div className="mt-3 flex items-start gap-2 rounded-lg border border-line bg-white/[0.03] p-2.5">
              <CircleCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-lime" />
              <p className="text-[11px] leading-relaxed text-muted">
                The rules engine is the default and needs no credits. AI is optional and metered.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
