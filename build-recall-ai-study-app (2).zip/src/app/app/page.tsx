import Link from "next/link";
import {
  ArrowRight,
  BookMarked,
  Brain,
  CircleCheck,
  Clock,
  FileText,
  Flame,
  Plus,
  Repeat,
  Sparkles,
  Target,
  TrendingUp,
  Wand2,
} from "lucide-react";
import ActivityHeatmap from "@/components/app/ActivityHeatmap";
import DeleteDocumentButton from "@/components/app/DeleteDocumentButton";
import { getCurrentUser } from "@/lib/auth";
import { getDashboard, listDocuments } from "@/lib/repository";
import { getLocale, getTranslator } from "@/lib/i18n/server";
import { formatLongDate, formatNumber } from "@/lib/i18n/messages";
import { redirect } from "next/navigation";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Overview · Recall",
  description: "Your decks, due queue, streaks and AI credits.",
};

export const dynamic = "force-dynamic";

function daysAgo(date: Date) {
  const diff = Math.floor((Date.now() - date.getTime()) / 86400000);
  if (diff <= 0) return "today";
  if (diff === 1) return "yesterday";
  return `${diff} days ago`;
}

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const [{ locale, t }, stats, docs] = await Promise.all([
    getTranslator(),
    getDashboard(user.id),
    listDocuments(user.id),
  ]);
  const firstName = user.name.split(" ")[0];
  const masteredPct =
    stats.totalCards > 0 ? Math.round((stats.mastered / stats.totalCards) * 100) : 0;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-[11.5px] uppercase tracking-[0.16em] text-muted">
            {new Intl.DateTimeFormat("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
            }).format(new Date())}
          </p>
          <h1 className="display mt-1.5 text-3xl sm:text-4xl">Welcome back, {firstName}.</h1>
          <p className="mt-1.5 text-[13px] text-muted">
            {stats.dueCards > 0
              ? `${formatNumber(stats.dueCards, locale)} ${t("dashboard.subtitleDue")}`
              : t("dashboard.subtitleClear")}
          </p>
        </div>
        <Link href="/app/new" className="btn btn-primary">
          <Plus className="h-4 w-4" /> {t("dashboard.newSource")}
        </Link>
      </header>

      <section className="grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <div className="card relative overflow-hidden p-5 sm:p-6">
          <div className="absolute -right-16 -top-20 h-56 w-56 rounded-full bg-lime/10 blur-3xl" />
          <div className="relative flex flex-wrap items-start justify-between gap-4">
            <div>
              <span className="chip chip-lime">
                <Repeat className="h-3 w-3" /> Today&apos;s queue
              </span>
              <p className="display mt-4 text-5xl leading-none">{stats.dueCards}</p>
              <p className="mt-2 text-[13px] text-muted">
                {stats.dueCards > 0
                  ? `Includes ${stats.newCards} card${stats.newCards === 1 ? "" : "s"} you have never graded.`
                  : "Everything is scheduled into the future."}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="rounded-xl border border-line bg-white/[0.03] px-3 py-2.5">
                <Flame className="mx-auto h-4 w-4 text-coral" />
                <p className="mt-1 text-base font-semibold">{user.streak}d</p>
                <p className="text-[10px] text-muted">streak</p>
              </div>
              <div className="rounded-xl border border-line bg-white/[0.03] px-3 py-2.5">
                <Target className="mx-auto h-4 w-4 text-lime" />
                <p className="mt-1 text-base font-semibold">{masteredPct}%</p>
                <p className="text-[10px] text-muted">mature</p>
              </div>
            </div>
          </div>
          <div className="relative mt-5 flex flex-col gap-2 sm:flex-row">
            <Link
              href="/app/review"
              className="btn btn-primary"
              aria-disabled={stats.dueCards === 0}
            >
              {stats.dueCards > 0 ? "Start review session" : "Open review queue"}
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/app/new" className="btn btn-ghost">
              <FileText className="h-4 w-4" /> Turn a PDF into cards
            </Link>
          </div>
          <div className="relative mt-5 h-1.5 w-full overflow-hidden rounded-full bg-white/8">
            <div
              className="h-full rounded-full bg-lime transition-all"
              style={{ width: `${Math.max(masteredPct, stats.totalCards > 0 ? 3 : 0)}%` }}
            />
          </div>
          <p className="relative mt-2 text-[11px] text-muted">
            {stats.mastered} of {stats.totalCards} cards reached a 3+ day interval.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {[
            {
              icon: BookMarked,
              label: "Documents",
              value: stats.documents,
              hint: "sources imported",
            },
            {
              icon: Brain,
              label: "Total cards",
              value: stats.totalCards,
              hint: "across all decks",
            },
            {
              icon: TrendingUp,
              label: "Reviews / 7d",
              value: stats.reviewsThisWeek,
              hint: "graded answers",
            },
            {
              icon: CircleCheck,
              label: "Retention",
              value: stats.retentionThisWeek === null ? "—" : `${stats.retentionThisWeek}%`,
              hint: "Good or Easy rate",
            },
          ].map((item) => (
            <div key={item.label} className="card p-4">
              <item.icon className="h-4 w-4 text-lime" />
              <p className="stat-value mt-2.5">{item.value}</p>
              <p className="mt-1 text-[11.5px] font-medium text-cream/85">{item.label}</p>
              <p className="text-[10.5px] text-muted">{item.hint}</p>
            </div>
          ))}
        </div>
      </section>

      <ActivityHeatmap activity={stats.activity} />

      <section>
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <h2 className="text-[15px] font-semibold text-cream">Your sources</h2>
            <p className="text-[11.5px] text-muted">
              Every document keeps its own cards and schedule.
            </p>
          </div>
          {docs.length > 0 && (
            <Link href="/app/review" className="text-[11.5px] font-semibold text-lime">
              Review all →
            </Link>
          )}
        </div>

        {docs.length === 0 ? (
          <div className="card grid place-items-center p-10 text-center">
            <div>
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-line bg-white/5 text-lime">
                <Plus className="h-5 w-5" />
              </span>
              <h3 className="mt-4 text-base font-semibold text-cream">No sources yet</h3>
              <p className="mx-auto mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-muted">
                Upload a PDF, drop in a text file, or paste a chapter. The free engine will build
                your first deck in seconds.
              </p>
              <Link href="/app/new" className="btn btn-primary mt-5">
                Add your first source <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        ) : (
          <div className="space-y-2.5">
            {docs.map((doc) => {
              const progress =
                doc.totalCards > 0 ? Math.round((doc.mastered / doc.totalCards) * 100) : 0;
              return (
                <div key={doc.id} className="card p-4 transition hover:border-white/15 sm:p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <Link
                          href={`/app/documents/${doc.id}`}
                          className="truncate text-[14.5px] font-semibold text-cream hover:text-lime"
                        >
                          {doc.title}
                        </Link>
                        <span
                          className={`rounded-full border px-2 py-0.5 text-[9.5px] font-semibold uppercase tracking-[0.1em] ${
                            doc.engine === "ai"
                              ? "border-violet/30 bg-violet/10 text-violet"
                              : "border-lime/30 bg-lime/10 text-lime"
                          }`}
                        >
                          {doc.engine === "ai" ? "AI + rules" : "Rules"}
                        </span>
                        <span className="chip">{doc.qualityScore}% quality</span>
                        {doc.flaggedCards > 0 && (
                          <span className="chip border-coral/30 text-coral">
                            {doc.flaggedCards} flagged
                          </span>
                        )}
                        {doc.dueCards > 0 && (
                          <span className="rounded-full bg-coral/15 px-2 py-0.5 text-[9.5px] font-semibold text-coral">
                            {doc.dueCards} due
                          </span>
                        )}
                      </div>
                      <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted">
                        <span className="inline-flex items-center gap-1">
                          <FileText className="h-3 w-3" /> {doc.pageCount} page
                          {doc.pageCount === 1 ? "" : "s"}
                        </span>
                        <span>{doc.wordCount.toLocaleString()} words</span>
                        <span>{doc.totalCards} cards</span>
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3 w-3" /> {daysAgo(doc.createdAt)}
                        </span>
                      </div>
                      <div className="mt-3 flex items-center gap-2">
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/8">
                          <div
                            className="h-full rounded-full bg-lime"
                            style={{ width: `${Math.max(progress, 2)}%` }}
                          />
                        </div>
                        <span className="w-8 text-right text-[10px] text-muted">{progress}%</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <DeleteDocumentButton documentId={doc.id} />
                      <Link href={`/app/documents/${doc.id}`} className="btn btn-ghost btn-sm">
                        Study <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="grid gap-4 sm:grid-cols-2">
        <div className="card p-5">
          <span className="chip">
            <Sparkles className="h-3 w-3 text-violet" /> AI layer
          </span>
          <h3 className="mt-3 text-[14px] font-semibold text-cream">
            {user.plan === "pro" ? `${user.aiCredits} credits remaining` : "Optional upgrade"}
          </h3>
          <p className="mt-1.5 text-[12px] leading-relaxed text-muted">
            {user.plan === "pro"
              ? "Each AI-enhanced document uses one credit. Failures are refunded automatically."
              : "The free engine is complete. Pro adds AI-rewritten cards on top of it."}
          </p>
          <Link href="/app/billing" className="btn btn-ghost btn-sm mt-4">
            {user.plan === "pro" ? "Manage credits" : "See Pro"}{" "}
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
        <div className="card p-5">
          <span className="chip">
            <Wand2 className="h-3 w-3 text-lime" /> Free engine
          </span>
          <h3 className="mt-3 text-[14px] font-semibold text-cream">Unlimited, no credits</h3>
          <p className="mt-1.5 text-[12px] leading-relaxed text-muted">
            Every upload without AI still produces definitions, cloze cards, MCQs, a study plan and
            a spaced-repetition schedule.
          </p>
          <Link href="/app/new" className="btn btn-ghost btn-sm mt-4">
            Generate a deck <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
