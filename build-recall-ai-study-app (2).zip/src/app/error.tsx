"use client";

import { CircleAlert } from "lucide-react";

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="shell grid min-h-[60dvh] place-items-center py-16">
      <div className="card max-w-lg p-7 text-center">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-coral/30 bg-coral/10 text-coral">
          <CircleAlert className="h-5 w-5" />
        </span>
        <h1 className="display mt-4 text-2xl">Something broke on our side.</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted">
          Your decks and reviews are stored safely. Try again — if this keeps happening, the error
          reference below is what an operator needs.
        </p>
        {error.digest && (
          <p className="mt-2 font-mono text-[11px] text-muted">Reference: {error.digest}</p>
        )}
        <button type="button" onClick={reset} className="btn btn-primary mt-5">
          Try again
        </button>
      </div>
    </div>
  );
}
