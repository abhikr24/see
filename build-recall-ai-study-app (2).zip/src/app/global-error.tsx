"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body
        style={{
          background: "#08080d",
          color: "#f5f1e8",
          fontFamily: "system-ui, sans-serif",
          padding: "3rem 1.25rem",
        }}
      >
        <main style={{ maxWidth: "32rem", margin: "0 auto" }}>
          <h1 style={{ fontSize: "1.5rem", marginBottom: "0.75rem" }}>Recall could not load.</h1>
          <p style={{ color: "#a6a2b3", lineHeight: 1.6 }}>
            The application shell failed to boot. Reload the page; if the problem persists the
            deployment logs will hold the cause{error.digest ? ` (reference ${error.digest})` : ""}.
          </p>
          <button
            type="button"
            onClick={reset}
            style={{
              marginTop: "1.25rem",
              padding: "0.7rem 1.2rem",
              borderRadius: 999,
              background: "#c9f26b",
              border: 0,
              fontWeight: 600,
            }}
          >
            Reload
          </button>
        </main>
      </body>
    </html>
  );
}
