import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Toaster } from "sonner";
import { getLocale } from "@/lib/i18n/server";
import "./globals.css";

export const metadata: Metadata = {
  title: "Recall — Turn any PDF into memory that sticks",
  description:
    "Recall converts PDFs, notes and pasted text into flashcards, cloze deletions, quizzes and a spaced-repetition plan. A deterministic rules engine is free forever; AI is an optional upgrade.",
  applicationName: "Recall",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icons/icon-192.png", apple: "/icons/icon-192.png" },
  keywords: [
    "PDF to flashcards",
    "spaced repetition",
    "active recall",
    "study app",
    "memory",
    "Anki export",
  ],
  openGraph: {
    title: "Recall — Turn any PDF into memory",
    description:
      "Free, deterministic study material generation from any PDF. AI polish available as an optional paid upgrade.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#08080d",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const locale = await getLocale();
  return (
    <html lang={locale}>
      <body className="antialiased">
        <Toaster theme="dark" position="bottom-center" closeButton richColors />
        <div className="relative min-h-dvh">{children}</div>
      </body>
    </html>
  );
}
