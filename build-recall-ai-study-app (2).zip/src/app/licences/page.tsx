import type { Metadata } from "next";
import Link from "next/link";
import dependencies from "@/data/dependencies.json";

export const metadata: Metadata = {
  title: "Open-source licences · Recall",
  description: "Every third-party package Recall uses, with its licence and upstream repository.",
};

export default function LicencesPage() {
  return (
    <div className="shell max-w-4xl py-12">
      <p className="eyebrow">Licences</p>
      <h1 className="display mt-2 text-3xl sm:text-4xl">Built on permissive open source.</h1>
      <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted">
        Recall is a commercial product. Every direct dependency below is MIT, ISC, BSD-2-Clause,
        BSD-3-Clause or Apache-2.0. Apache-2.0 components are attributed in the repository{" "}
        <span className="font-mono text-cream">NOTICE</span> file. The CI gate{" "}
        <span className="font-mono text-cream">npm run license:check</span> fails the build if a
        disallowed licence appears.
      </p>

      <div className="card mt-6 overflow-x-auto">
        <table className="w-full border-collapse text-left text-[12px]">
          <caption className="sr-only">Third-party dependencies, versions and licences</caption>
          <thead>
            <tr className="border-b border-line text-[10px] uppercase tracking-[0.1em] text-muted">
              <th scope="col" className="px-3 py-2.5">
                Package
              </th>
              <th scope="col" className="px-3 py-2.5">
                Version
              </th>
              <th scope="col" className="px-3 py-2.5">
                Licence
              </th>
              <th scope="col" className="hidden px-3 py-2.5 sm:table-cell">
                Used for
              </th>
            </tr>
          </thead>
          <tbody>
            {dependencies.map((dependency) => (
              <tr key={dependency.package} className="border-b border-line/60 last:border-0">
                <td className="px-3 py-2.5 align-top">
                  <a
                    href={dependency.repo}
                    className="font-semibold text-cream underline decoration-line underline-offset-2 hover:text-lime"
                    rel="noreferrer noopener"
                    target="_blank"
                  >
                    {dependency.package}
                  </a>
                </td>
                <td className="px-3 py-2.5 align-top font-mono text-[11px] text-muted">
                  {dependency.version}
                </td>
                <td className="px-3 py-2.5 align-top text-cream">{dependency.license}</td>
                <td className="hidden px-3 py-2.5 align-top text-muted sm:table-cell">
                  {dependency.use}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 className="mt-6 text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
        Transitive build dependencies
      </h2>
      <p className="mt-2 text-[11.5px] leading-relaxed text-muted">
        Three transitive packages carry licences outside the direct allowlist and are recorded as
        reviewed exceptions: <span className="text-cream">@img/sharp-libvips-*</span> (LGPL-3.0,
        optional Next image-optimiser binary — not imported by Recall and removable with{" "}
        <span className="font-mono">npm ci --omit=optional</span>),{" "}
        <span className="text-cream">lightningcss</span> (MPL-2.0, build-time CSS transform,
        unmodified) and <span className="text-cream">caniuse-lite</span> (CC-BY-4.0 browser data,
        attributed to caniuse.com). Full reasoning lives in docs/DEPENDENCIES.md and NOTICE.
      </p>
      <p className="mt-4 text-[11.5px]">
        <Link href="/" className="text-lime">
          ← Back to Recall
        </Link>
      </p>
    </div>
  );
}
