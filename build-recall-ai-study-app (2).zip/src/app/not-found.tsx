import Link from "next/link";
import { ArrowLeft, Compass } from "lucide-react";
import { Logo } from "@/components/site/SiteChrome";

export default function NotFound() {
  return (
    <div className="relative grid min-h-dvh place-items-center overflow-hidden px-4">
      <div className="aurora opacity-60" />
      <div className="card relative w-full max-w-md p-8 text-center">
        <div className="flex justify-center">
          <Logo />
        </div>
        <span className="mx-auto mt-6 grid h-12 w-12 place-items-center rounded-2xl border border-line bg-white/5 text-lime">
          <Compass className="h-5 w-5" />
        </span>
        <h1 className="display mt-4 text-2xl">This page was not in the deck.</h1>
        <p className="mt-2 text-[12.5px] leading-relaxed text-muted">
          The link is broken, or the document belongs to another account. Your cards are safe.
        </p>
        <div className="mt-5 flex flex-col justify-center gap-2 sm:flex-row">
          <Link href="/app" className="btn btn-primary btn-sm">
            Back to studio
          </Link>
          <Link href="/" className="btn btn-ghost btn-sm">
            <ArrowLeft className="h-3.5 w-3.5" /> Home
          </Link>
        </div>
      </div>
    </div>
  );
}
