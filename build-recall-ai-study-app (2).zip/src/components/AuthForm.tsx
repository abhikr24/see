"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Loader2, Lock, Mail, User } from "lucide-react";

export default function AuthForm({
  initialMode = "signin",
  demoEmail,
  demoPassword,
}: {
  initialMode?: "signin" | "signup";
  demoEmail: string;
  demoPassword: string;
}) {
  const router = useRouter();
  const [mode, setMode] = useState<"signin" | "signup">(initialMode);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(
    payload: { name?: string; email: string; password: string },
    target = mode,
  ) {
    setLoading(true);
    setError(null);
    setNotice(null);
    try {
      const response = await fetch(`/api/auth/${target === "signin" ? "login" : "signup"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { error?: string; status?: string; message?: string };
      if (response.status === 202 || data.status === "confirm_email") {
        setError(null);
        setNotice(data.message ?? "Check your inbox to confirm your email, then sign in.");
        setMode("signin");
        setLoading(false);
        return;
      }
      if (!response.ok) {
        setError(data.error ?? "Something went wrong.");
        setLoading(false);
        return;
      }
      router.push("/app");
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  }

  return (
    <div className="card p-5 sm:p-7">
      <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl border border-line bg-ink-2/70 p-1">
        {(["signin", "signup"] as const).map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => {
              setMode(option);
              setError(null);
            }}
            className={`rounded-lg px-3 py-2 text-[12.5px] font-semibold transition ${
              mode === option ? "bg-lime text-ink" : "text-muted hover:text-cream"
            }`}
          >
            {option === "signin" ? "Sign in" : "Create account"}
          </button>
        ))}
      </div>

      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          void submit({ name, email, password });
        }}
      >
        {mode === "signup" && (
          <div>
            <label className="label" htmlFor="auth-name">
              Name
            </label>
            <div className="relative">
              <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <input
                id="auth-name"
                className="field pl-9"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Alex"
                autoComplete="name"
              />
            </div>
          </div>
        )}

        <div>
          <label className="label" htmlFor="auth-email">
            Email
          </label>
          <div className="relative">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <input
              id="auth-email"
              type="email"
              required
              className="field pl-9"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@university.edu"
              autoComplete="email"
            />
          </div>
        </div>

        <div>
          <label className="label" htmlFor="auth-password">
            Password
          </label>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <input
              id="auth-password"
              type="password"
              required
              minLength={mode === "signup" ? 8 : 1}
              className="field pl-9"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder={mode === "signup" ? "At least 8 characters" : "Your password"}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
            />
          </div>
        </div>

        {notice && (
          <p
            role="status"
            className="rounded-lg border border-lime/30 bg-lime/10 px-3 py-2 text-[12.5px] text-lime"
          >
            {notice}
          </p>
        )}

        {error && (
          <p
            role="alert"
            className="rounded-lg border border-coral/30 bg-coral/10 px-3 py-2 text-[12.5px] text-coral"
          >
            {error}
          </p>
        )}

        <button type="submit" className="btn btn-primary w-full" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Working…
            </>
          ) : (
            <>
              {mode === "signin" ? "Sign in" : "Create my workspace"}{" "}
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </button>
      </form>

      <div className="my-5 flex items-center gap-3">
        <span className="hairline" />
        <span className="text-[10.5px] uppercase tracking-[0.14em] text-muted">or</span>
        <span className="hairline" />
      </div>

      <button
        type="button"
        className="btn btn-ghost w-full"
        disabled={loading}
        onClick={() => {
          setMode("signin");
          setEmail(demoEmail);
          setPassword(demoPassword);
          void submit({ email: demoEmail, password: demoPassword }, "signin");
        }}
      >
        Enter the demo account <ArrowRight className="h-4 w-4" />
      </button>
      <p className="mt-3 text-center text-[11px] leading-relaxed text-muted">
        Demo: <span className="font-mono text-cream">{demoEmail}</span> /{" "}
        <span className="font-mono text-cream">{demoPassword}</span>
      </p>
    </div>
  );
}
