"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Languages } from "lucide-react";
import { LOCALE_LABELS, LOCALES, type Locale } from "@/lib/i18n/messages";

export default function LocaleSwitcher({ locale, label }: { locale: Locale; label: string }) {
  const router = useRouter();
  const [value, setValue] = useState<Locale>(locale);
  const [pending, startTransition] = useTransition();

  return (
    <label className="inline-flex items-center gap-1.5 text-[11px] text-muted">
      <Languages className="h-3.5 w-3.5" aria-hidden />
      <span className="sr-only">{label}</span>
      <select
        aria-label={label}
        value={value}
        disabled={pending}
        onChange={async (event) => {
          const next = event.target.value as Locale;
          setValue(next);
          const response = await fetch("/api/locale", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ locale: next }),
          });
          if (!response.ok) return;
          // A full reload guarantees every server component (including the
          // cached RSC payload) re-renders in the new locale.
          window.location.reload();
          startTransition(() => router.refresh());
        }}
        className="rounded-md border border-line bg-ink-2/60 px-1.5 py-1 text-[11px] text-cream"
      >
        {LOCALES.map((option) => (
          <option key={option} value={option}>
            {LOCALE_LABELS[option]}
          </option>
        ))}
      </select>
    </label>
  );
}
