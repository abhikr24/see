"use client";

/**
 * Renders server-sanitised HTML (KaTeX output + escaped text). No client-side
 * HTML parsing and no KaTeX in the browser bundle.
 */
export default function RichText({
  html,
  text,
  className = "",
}: {
  html?: string;
  text: string;
  className?: string;
}) {
  if (html) {
    return <span className={`rich-text ${className}`} dangerouslySetInnerHTML={{ __html: html }} />;
  }
  return <span className={`whitespace-pre-line ${className}`}>{text}</span>;
}
