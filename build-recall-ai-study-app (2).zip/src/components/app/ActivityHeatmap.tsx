import type { ActivityDay } from "@/lib/repository";

/** Pure CSS 30-day review heatmap — no chart library, no client JS. */
export default function ActivityHeatmap({ activity }: { activity: ActivityDay[] }) {
  const peak = Math.max(1, ...activity.map((day) => day.count));
  const total = activity.reduce((sum, day) => sum + day.count, 0);

  return (
    <section className="card p-4 sm:p-5" aria-labelledby="activity-heading">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2
          id="activity-heading"
          className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream"
        >
          Last 30 days
        </h2>
        <p className="text-[11px] text-muted">
          {total} review{total === 1 ? "" : "s"} graded
        </p>
      </div>
      <div
        className="mt-3 grid grid-cols-10 gap-1.5 sm:grid-cols-15"
        role="img"
        aria-label={`${total} reviews in the last 30 days`}
      >
        {activity.map((day) => {
          const intensity = day.count === 0 ? 0 : Math.max(1, Math.round((day.count / peak) * 4));
          const tone =
            intensity === 0
              ? "bg-white/[0.05]"
              : intensity === 1
                ? "bg-lime/25"
                : intensity === 2
                  ? "bg-lime/45"
                  : intensity === 3
                    ? "bg-lime/70"
                    : "bg-lime";
          return (
            <span
              key={day.date}
              title={`${day.date}: ${day.count} review${day.count === 1 ? "" : "s"}`}
              className={`aspect-square rounded-[4px] ${tone}`}
            >
              <span className="sr-only">
                {day.date}: {day.count} reviews
              </span>
            </span>
          );
        })}
      </div>
      <p className="mt-2 text-[10.5px] text-muted">
        Lighter squares are quiet days. Every graded card counts — including the ones you missed.
      </p>
    </section>
  );
}
