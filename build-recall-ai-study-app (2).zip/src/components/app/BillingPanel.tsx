"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { CircleCheck, Loader2, ShieldAlert, Sparkles, Zap } from "lucide-react";

export default function BillingPanel({
  plan,
  credits,
  aiConfigured,
  provider,
  usage,
  authProvider,
  authProblem,
  spend,
  retention,
  demoBillingEnabled,
}: {
  plan: string;
  credits: number;
  aiConfigured: boolean;
  provider: string | null;
  authProvider: string;
  authProblem: string | null;
  spend: { events: number; tokens: number; costUsd: number; failed: number };
  retention: number;
  demoBillingEnabled: boolean;
  usage: {
    id: string;
    provider: string;
    model: string;
    credits: number;
    status: string;
    createdAt: string;
  }[];
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [retentionValue, setRetentionValue] = useState(Math.round(retention * 100));
  const [savingRetention, setSavingRetention] = useState(false);
  const [retentionNote, setRetentionNote] = useState<string | null>(null);

  async function saveRetention() {
    setSavingRetention(true);
    setRetentionNote(null);
    try {
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ desiredRetention: retentionValue / 100 }),
      });
      const data = (await response.json()) as { error?: string };
      setRetentionNote(
        response.ok
          ? `Target retention set to ${retentionValue}%.`
          : (data.error ?? "Could not save."),
      );
      router.refresh();
    } catch {
      setRetentionNote("Network error while saving.");
    } finally {
      setSavingRetention(false);
    }
  }

  async function activate() {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ credits: 40 }),
      });
      const data = (await response.json()) as { message?: string; error?: string };
      if (!response.ok) {
        setError(data.error ?? "Could not activate Pro.");
        return;
      }
      setMessage(data.message ?? "Pro activated.");
      router.refresh();
    } catch {
      setError("Network error. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="card p-5">
          <span className="chip">{plan === "pro" ? "Current plan" : "Included"}</span>
          <h2 className="mt-3 text-lg font-semibold text-cream">Free</h2>
          <p className="mt-1 text-[12px] text-muted">
            Deterministic generation. No document limit, no expiry.
          </p>
          <ul className="mt-4 space-y-1.5 text-[11.5px] text-muted">
            {[
              "Unlimited PDFs and pastes",
              "Cards, cloze, quiz",
              "FSRS scheduling",
              "Edit, flag and reorder cards",
              "Anki CSV / Quizlet TSV / JSON / MD export",
            ].map((line) => (
              <li key={line} className="flex gap-1.5">
                <CircleCheck className="mt-0.5 h-3 w-3 shrink-0 text-lime" /> {line}
              </li>
            ))}
          </ul>
        </div>

        <div className="card glow-lime relative overflow-hidden p-5">
          <div className="flex items-center justify-between">
            <span className="chip chip-lime">{plan === "pro" ? "Active" : "Upgrade"}</span>
            <span className="text-[10.5px] text-muted">40 credits / 30 days</span>
          </div>
          <h2 className="mt-3 text-lg font-semibold text-cream">Pro</h2>
          <p className="mt-1 text-[12px] text-muted">
            AI-enhanced cards on top of the free engine. One credit per AI document.
          </p>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="display text-2xl">{credits}</span>
            <span className="text-[11px] text-muted">AI credits available</span>
          </div>
          <button
            type="button"
            onClick={() => void activate()}
            className="btn btn-primary btn-sm mt-4 w-full"
            disabled={busy || !demoBillingEnabled}
          >
            {busy ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Activating…
              </>
            ) : (
              <>
                <Zap className="h-3.5 w-3.5" /> Add 40 demo credits
              </>
            )}
          </button>
          <p className="mt-2 text-[10.5px] leading-relaxed text-muted">
            {demoBillingEnabled
              ? "No card is charged. This deployment allows demo activation (ALLOW_DEMO_BILLING=true)."
              : "Checkout is not connected in this deployment, so this button is disabled. AI activation is handled by the operator; the free engine is unaffected."}
          </p>
        </div>
      </div>

      {message && (
        <p className="rounded-xl border border-lime/30 bg-lime/[0.08] px-3 py-2.5 text-[12px] text-lime">
          {message}
        </p>
      )}
      {error && (
        <p className="rounded-xl border border-coral/30 bg-coral/[0.08] px-3 py-2.5 text-[12px] text-coral">
          {error}
        </p>
      )}

      <div className="card p-5">
        <h2 className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
          Scheduling
        </h2>
        <p className="mt-2 text-[11.5px] leading-relaxed text-muted">
          FSRS targets a retention level instead of following fixed intervals. Higher targets mean
          more reviews; 90% is a good default.
        </p>
        <div className="mt-3 flex flex-wrap items-end gap-3">
          <label className="flex-1 text-[11px] text-muted">
            Desired retention: <span className="font-semibold text-cream">{retentionValue}%</span>
            <input
              type="range"
              min={70}
              max={97}
              step={1}
              value={retentionValue}
              onChange={(event) => setRetentionValue(Number(event.target.value))}
              className="mt-1 w-full accent-lime"
            />
          </label>
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            disabled={savingRetention}
            onClick={() => void saveRetention()}
          >
            {savingRetention ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null} Save
          </button>
        </div>
        {retentionNote && (
          <p role="status" className="mt-2 text-[11px] text-lime">
            {retentionNote}
          </p>
        )}
        <p className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-muted">
          Auth provider: <span className="font-semibold text-cream">{authProvider}</span>
          <Link href="/licences" className="text-lime">
            Licences →
          </Link>
        </p>
        {authProblem && (
          <p className="mt-2 flex items-start gap-2 rounded-lg border border-coral/30 bg-coral/[0.08] px-3 py-2 text-[11.5px] text-coral">
            <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" /> {authProblem}
          </p>
        )}
      </div>

      <div className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
            AI provider
          </h2>
          <span className={`text-[11px] ${aiConfigured ? "text-lime" : "text-coral"}`}>
            {aiConfigured ? `${provider} connected` : "No provider key configured"}
          </span>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "AI events", value: String(spend.events) },
            { label: "Tokens", value: spend.tokens.toLocaleString() },
            { label: "Est. spend", value: `$${spend.costUsd.toFixed(3)}` },
            { label: "Failed runs", value: String(spend.failed) },
          ].map((item) => (
            <div
              key={item.label}
              className="rounded-lg border border-line bg-white/[0.02] px-2.5 py-2"
            >
              <p className="text-[13px] font-semibold text-cream">{item.value}</p>
              <p className="text-[10px] uppercase tracking-[0.08em] text-muted">{item.label}</p>
            </div>
          ))}
        </div>
        <p className="mt-2 text-[10.5px] text-muted">
          Spend is estimated from the provider&apos;s published per-token prices and the tokens
          returned by the API.
        </p>

        <p className="mt-2 text-[11.5px] leading-relaxed text-muted">
          {aiConfigured
            ? "AI generations route through your server only. Keys never reach the browser. Provider errors refund the credit automatically."
            : "Add OPENAI_API_KEY (or ANTHROPIC_API_KEY, GROQ_API_KEY, OPENROUTER_API_KEY) to the server environment to turn the AI engine on. The free rules engine keeps working either way."}
        </p>

        <h3 className="mt-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted">
          Recent AI usage
        </h3>
        {usage.length === 0 ? (
          <p className="mt-2 text-[11.5px] text-muted">No AI generations yet.</p>
        ) : (
          <ul className="mt-2 divide-y divide-line/60">
            {usage.map((event) => (
              <li
                key={event.id}
                className="flex items-center justify-between gap-2 py-2 text-[11.5px]"
              >
                <span className="inline-flex items-center gap-1.5 text-cream/85">
                  <Sparkles className="h-3 w-3 text-violet" /> {event.provider}
                  <span className="text-muted">· {event.model}</span>
                  {event.status !== "ok" && <span className="text-coral">· {event.status}</span>}
                </span>
                <span className="text-muted">
                  {event.credits} credit · {new Date(event.createdAt).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
