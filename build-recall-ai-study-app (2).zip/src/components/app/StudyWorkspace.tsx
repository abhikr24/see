"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  BookOpen,
  CalendarClock,
  CircleAlert,
  Download,
  FileText,
  Layers,
  Lightbulb,
  ListChecks,
  Quote,
  Repeat,
  Sparkles,
} from "lucide-react";
import CardManager from "@/components/app/CardManager";
import QuizPanel from "@/components/app/QuizPanel";
import ReviewRunner from "@/components/app/ReviewRunner";
import type { Analysis } from "@/lib/memory/types";
import type { StudyCard } from "@/lib/ui-types";

type Doc = {
  id: string;
  title: string;
  engine: string;
  requestedEngine?: string;
  qualityScore?: number;
  sourceType: string;
  pageCount: number;
  wordCount: number;
  createdAt: string;
  rawText: string;
  rawHtml?: string;
  analysis: Analysis;
};

const TABS = [
  { id: "review", label: "Review", icon: Repeat },
  { id: "cards", label: "Cards", icon: Layers },
  { id: "quiz", label: "Quiz", icon: ListChecks },
  { id: "concepts", label: "Concepts", icon: Lightbulb },
  { id: "plan", label: "Study plan", icon: CalendarClock },
  { id: "source", label: "Source", icon: FileText },
] as const;

type TabId = (typeof TABS)[number]["id"];

export default function StudyWorkspace({ doc, cards }: { doc: Doc; cards: StudyCard[] }) {
  const [tab, setTab] = useState<TabId>("review");
  const dueCount = cards.filter((card) => new Date(card.dueAt) <= new Date()).length;
  const analysis = doc.analysis;

  return (
    <div className="space-y-4">
      <div>
        <Link
          href="/app"
          className="mb-3 inline-flex items-center gap-1.5 text-[11.5px] text-muted hover:text-cream"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> All sources
        </Link>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h1 className="display text-2xl leading-tight sm:text-3xl">{doc.title}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span
                className={`rounded-full border px-2 py-0.5 text-[9.5px] font-semibold uppercase tracking-[0.1em] ${
                  doc.engine === "ai"
                    ? "border-violet/30 bg-violet/10 text-violet"
                    : "border-lime/30 bg-lime/10 text-lime"
                }`}
              >
                {doc.engine === "ai" ? "AI + rules" : "Rules engine"}
              </span>
              <span className="chip">
                <Layers className="h-3 w-3" /> {cards.length} cards
              </span>
              <span className="chip">{analysis.stats.pages} pages</span>
              <span className="chip">{analysis.stats.words.toLocaleString()} words</span>
              <span className="chip">{analysis.stats.concepts} concepts</span>
              <span
                className={`chip ${analysis.stats.qualityScore < 70 ? "border-coral/30 text-coral" : "border-lime/25 text-lime"}`}
                title="Share of generated cards that passed the quality validator"
              >
                {analysis.stats.qualityScore}% quality
              </span>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <a
              href={`/api/export/${doc.id}?format=csv`}
              className="btn btn-ghost btn-sm"
              title="Anki-compatible CSV"
            >
              <Download className="h-3.5 w-3.5" /> Anki CSV
            </a>
            <a
              href={`/api/export/${doc.id}?format=tsv`}
              className="btn btn-ghost btn-sm"
              title="Quizlet TSV"
            >
              Quizlet TSV
            </a>
            <a href={`/api/export/${doc.id}?format=md`} className="btn btn-ghost btn-sm">
              Markdown
            </a>
            <a href={`/api/export/${doc.id}?format=json`} className="btn btn-ghost btn-sm">
              JSON
            </a>
          </div>
        </div>
      </div>

      {doc.engine === "rules" && doc.requestedEngine === "ai" && (
        <p className="rounded-xl border border-violet/25 bg-violet/[0.07] px-3 py-2 text-[11.5px] leading-relaxed text-cream/85">
          AI was requested but did not complete, so this deck is entirely from the free rules
          engine. No credit was charged. The badge above always shows the engine that actually ran.
        </p>
      )}

      {analysis.stats.qualityScore < 70 && cards.length > 0 && (
        <div className="card p-4">
          <p className="text-[12px] font-semibold text-cream">
            This source is dense — {analysis.stats.droppedCards} candidate card
            {analysis.stats.droppedCards === 1 ? "" : "s"} failed the quality check.
          </p>
          <p className="mt-1 text-[11.5px] leading-relaxed text-muted">
            Your deck is kept. Adding more text usually helps; the AI engine is the other option.
          </p>
          <Link href="/app/new" className="btn btn-ghost btn-sm mt-2.5">
            Try another source
          </Link>
        </div>
      )}

      {analysis.warnings.length > 0 && (
        <div className="space-y-1.5">
          {analysis.warnings.map((warning) => (
            <p
              key={warning}
              className="flex items-start gap-2 rounded-xl border border-coral/25 bg-coral/[0.07] px-3 py-2 text-[11.5px] leading-relaxed text-coral"
            >
              <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              {warning}
            </p>
          ))}
        </div>
      )}

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {[
          { label: "Due now", value: dueCount, tone: "text-lime" },
          {
            label: "Mastered",
            value: cards.filter((card) => card.reps >= 2 && card.intervalDays >= 3).length,
            tone: "text-cream",
          },
          { label: "Coverage", value: `${analysis.stats.coverage}%`, tone: "text-cream" },
          { label: "Difficulty", value: analysis.stats.difficulty, tone: "text-cream" },
        ].map((stat) => (
          <div key={stat.label} className="card-flat px-3 py-2.5">
            <p className={`text-lg font-semibold ${stat.tone}`}>{stat.value}</p>
            <p className="text-[10px] uppercase tracking-[0.1em] text-muted">{stat.label}</p>
          </div>
        ))}
      </div>

      <div
        className="grid grid-cols-3 gap-1 rounded-xl border border-line bg-ink-2/60 p-1 sm:grid-cols-6"
        role="tablist"
        aria-label="Deck sections"
      >
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            role="tab"
            aria-selected={tab === item.id}
            className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-2 py-2 text-[11px] font-semibold transition sm:text-[12px] ${
              tab === item.id ? "bg-lime text-ink" : "text-muted hover:bg-white/5 hover:text-cream"
            }`}
          >
            <item.icon className="h-3.5 w-3.5" />
            {item.label}
          </button>
        ))}
      </div>

      {tab === "review" && <ReviewRunner cards={cards} showDocument />}
      {tab === "cards" && <CardManager documentId={doc.id} initialCards={cards} />}
      {tab === "quiz" && <QuizPanel cards={cards} documentId={doc.id} />}

      {tab === "concepts" && (
        <div className="space-y-4">
          <div className="card p-4 sm:p-5">
            <h2 className="flex items-center gap-2 text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
              <BookOpen className="h-4 w-4 text-lime" /> Source summary
            </h2>
            <p className="mt-2.5 text-[13px] leading-relaxed text-muted">{analysis.summary}</p>
            {analysis.recallPrompts.length > 0 && (
              <div className="mt-4">
                <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted">
                  Teach-it-back prompts
                </p>
                <ul className="mt-2 space-y-2">
                  {analysis.recallPrompts.map((prompt) => (
                    <li
                      key={prompt}
                      className="flex gap-2 rounded-lg border border-violet/25 bg-violet/[0.06] p-2.5 text-[12px] leading-relaxed text-cream/85"
                    >
                      <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-violet" />
                      {prompt}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="grid gap-2.5 sm:grid-cols-2">
            {analysis.concepts.map((concept) => (
              <div key={concept.term} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-[13.5px] font-semibold text-cream">{concept.term}</h3>
                  <span className="shrink-0 rounded-md border border-line px-1.5 py-0.5 font-mono text-[9.5px] text-muted">
                    p{concept.page} · ×{concept.count}
                  </span>
                </div>
                <p className="mt-1.5 text-[12px] leading-relaxed text-muted">
                  {concept.definition ||
                    "Key term in this source — see the card deck for its context."}
                </p>
              </div>
            ))}
          </div>

          <div className="card p-4 sm:p-5">
            <h2 className="flex items-center gap-2 text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
              <Quote className="h-4 w-4 text-lime" /> Key points
            </h2>
            <ul className="mt-3 space-y-2">
              {analysis.keyPoints.map((point, index) => (
                <li key={point} className="flex gap-2.5 text-[12.5px] leading-relaxed text-muted">
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border border-line font-mono text-[9.5px] text-lime">
                    {index + 1}
                  </span>
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {tab === "plan" && (
        <div className="space-y-4">
          <div className="card p-4 sm:p-5">
            <h2 className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
              {analysis.plan.length}-day plan
            </h2>
            <p className="mt-1 text-[11.5px] text-muted">
              Built from {cards.length} cards, about {analysis.stats.words.toLocaleString()} words
              of source material. Short daily sessions beat one long cram.
            </p>
            <ol className="mt-4 space-y-2.5">
              {analysis.plan.map((day) => (
                <li
                  key={day.day}
                  className="flex gap-3 rounded-xl border border-line bg-white/[0.025] p-3"
                >
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-lime/12 font-mono text-[11px] text-lime">
                    D{day.day}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[12.5px] font-medium text-cream">{day.focus}</p>
                    <p className="mt-0.5 text-[11px] text-muted">
                      {day.cardCount} cards · ~{day.minutes} min
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
          <div className="card-flat p-4">
            <p className="text-[11.5px] leading-relaxed text-muted">
              The plan is a scaffold, not a rule. The review queue always wins: if cards are due,
              clear them first, then continue with the next day&apos;s focus.
            </p>
          </div>
        </div>
      )}

      {tab === "source" && (
        <div className="card p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-[13px] font-semibold uppercase tracking-[0.12em] text-cream">
              Extracted text
            </h2>
            <span className="text-[10.5px] text-muted">
              {doc.sourceType} · {doc.pageCount} pages
            </span>
          </div>
          <div className="mt-3 max-h-[60vh] overflow-y-auto rounded-xl border border-line bg-ink/60 p-3.5">
            <p className="source-text">
              {doc.rawHtml ? (
                <span className="rich-text" dangerouslySetInnerHTML={{ __html: doc.rawHtml }} />
              ) : (
                doc.rawText || "No text was extracted."
              )}
            </p>
          </div>
          <p className="mt-2 text-[10.5px] leading-relaxed text-muted">
            Cards cite page numbers from this extraction. If your PDF has columns or tables, check a
            few cards against the original before trusting them.
          </p>
        </div>
      )}
    </div>
  );
}
