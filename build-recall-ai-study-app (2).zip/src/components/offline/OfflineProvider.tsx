"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { CloudOff, RefreshCw } from "lucide-react";
import { flushQueue, indexedDbStore, queueReview, type QueueStore } from "@/lib/offline/queue";
import type { ReviewGrade } from "@/lib/memory/types";

type OfflineContextValue = {
  online: boolean;
  pending: number;
  gradeLocally: (cardId: string, grade: ReviewGrade) => Promise<void>;
  sync: () => Promise<void>;
  store: QueueStore | null;
};

const OfflineContext = createContext<OfflineContextValue | null>(null);

export function useOffline(): OfflineContextValue {
  return (
    useContext(OfflineContext) ?? {
      online: true,
      pending: 0,
      gradeLocally: async () => {},
      sync: async () => {},
      store: null,
    }
  );
}

export default function OfflineProvider({ children }: { children: React.ReactNode }) {
  const storeRef = useRef<QueueStore | null>(null);
  const [online, setOnline] = useState(true);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const refresh = useCallback(async () => {
    const store = storeRef.current;
    if (!store) return;
    setPending((await store.all()).length);
  }, []);

  const sync = useCallback(async () => {
    const store = storeRef.current;
    if (!store || syncing || typeof navigator === "undefined" || !navigator.onLine) return;
    setSyncing(true);
    try {
      const result = await flushQueue(store, async (item) => {
        const response = await fetch(`/api/cards/${item.cardId}/review`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ grade: item.grade }),
        });
        return { ok: response.ok, status: response.status };
      });
      setPending(result.remaining);
      if (result.synced > 0) window.location.reload();
    } finally {
      setSyncing(false);
    }
  }, [syncing]);

  useEffect(() => {
    storeRef.current = indexedDbStore();
    setOnline(navigator.onLine);
    void refresh();

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // A failed registration must not break the app; the queue still works.
      });
    }

    const goOnline = () => {
      setOnline(true);
      void sync();
    };
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, [refresh, sync]);

  const gradeLocally = useCallback(async (cardId: string, grade: ReviewGrade) => {
    const store = storeRef.current;
    if (!store) return;
    await queueReview(store, { cardId, grade });
    setPending((await store.all()).length);
  }, []);

  return (
    <OfflineContext.Provider
      value={{ online, pending, gradeLocally, sync, store: storeRef.current }}
    >
      {children}
      {(!online || pending > 0) && (
        <div
          role="status"
          aria-live="polite"
          className="fixed inset-x-3 bottom-20 z-40 mx-auto flex max-w-md items-center gap-2 rounded-xl border border-violet/40 bg-ink-2/95 px-3 py-2.5 text-[11.5px] text-cream shadow-lg backdrop-blur lg:bottom-5"
        >
          <CloudOff className="h-4 w-4 shrink-0 text-violet" />
          <span className="flex-1">
            {pending > 0
              ? `${pending} review${pending === 1 ? "" : "s"} waiting to sync${online ? "" : " (offline)"}`
              : "You are offline. Reviews you grade are queued on this device."}
          </span>
          {pending > 0 && online && (
            <button
              type="button"
              onClick={() => void sync()}
              className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 font-semibold text-lime"
              disabled={syncing}
            >
              <RefreshCw className={`h-3 w-3 ${syncing ? "animate-spin" : ""}`} /> Sync
            </button>
          )}
        </div>
      )}
    </OfflineContext.Provider>
  );
}
