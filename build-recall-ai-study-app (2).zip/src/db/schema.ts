import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import type { Analysis } from "@/lib/memory/types";

export type QuizQuestionResult = {
  cardId: string;
  prompt: string;
  chosen: string;
  correctAnswer: string;
  correct: boolean;
};

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: text("email").notNull(),
    name: text("name").notNull(),
    passwordHash: text("password_hash").notNull(),
    plan: text("plan").notNull().default("free"), // free | pro
    aiCredits: integer("ai_credits").notNull().default(0),
    creditsResetAt: timestamp("credits_reset_at", { withTimezone: true }).defaultNow().notNull(),
    desiredRetention: real("desired_retention").notNull().default(0.9),
    stripeCustomerId: text("stripe_customer_id"),
    streak: integer("streak").notNull().default(0),
    lastStudiedOn: text("last_studied_on"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("users_email_unique").on(table.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    tokenHash: text("token_hash").notNull(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("sessions_token_unique").on(table.tokenHash)],
);

export const documents = pgTable(
  "documents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    sourceType: text("source_type").notNull(), // pdf | txt | paste
    fileName: text("file_name"),
    pageCount: integer("page_count").notNull().default(0),
    wordCount: integer("word_count").notNull().default(0),
    /** The engine that actually produced this deck. */
    engine: text("engine").notNull().default("rules"), // rules | ai
    /** What the user asked for — analytics only, never trusted for the badge. */
    requestedEngine: text("requested_engine").notNull().default("rules"),
    ocr: boolean("ocr").notNull().default(false),
    qualityScore: integer("quality_score").notNull().default(0),
    flaggedCards: integer("flagged_cards").notNull().default(0),
    rawText: text("raw_text").notNull(),
    analysis: jsonb("analysis").$type<Analysis>().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("documents_user_idx").on(table.userId)],
);

export const cards = pgTable(
  "cards",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(), // cloze | definition | fact | list | concept | ai
    prompt: text("prompt").notNull(),
    answer: text("answer").notNull(),
    hint: text("hint").notNull().default(""),
    cloze: text("cloze"),
    quote: text("quote").notNull().default(""),
    page: integer("page").notNull().default(1),
    options: jsonb("options").$type<string[]>().notNull().default([]),
    explanation: text("explanation").notNull().default(""),
    tags: jsonb("tags").$type<string[]>().notNull().default([]),
    /** Deck ordering controlled by the learner. */
    position: integer("position").notNull().default(0),
    suspended: boolean("suspended").notNull().default(false),
    flagged: boolean("flagged").notNull().default(false),
    flagNote: text("flag_note").notNull().default(""),
    // Legacy SM-2 state (kept for display + one-time FSRS backfill)
    ease: real("ease").notNull().default(2.5),
    intervalDays: real("interval_days").notNull().default(0),
    reps: integer("reps").notNull().default(0),
    lapses: integer("lapses").notNull().default(0),
    // FSRS v5 state (ts-fsrs, MIT)
    fsrsState: text("fsrs_state").notNull().default("new"), // new | learning | review | relearning
    stability: real("stability").notNull().default(0),
    difficulty: real("difficulty").notNull().default(0),
    scheduledDays: real("scheduled_days").notNull().default(0),
    elapsedDays: real("elapsed_days").notNull().default(0),
    learningSteps: integer("learning_steps").notNull().default(0),
    dueAt: timestamp("due_at", { withTimezone: true }).defaultNow().notNull(),
    lastReviewedAt: timestamp("last_reviewed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("cards_document_idx").on(table.documentId),
    index("cards_user_due_idx").on(table.userId, table.dueAt),
    index("cards_user_flags_idx").on(table.userId, table.flagged),
  ],
);

export const reviews = pgTable(
  "reviews",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    cardId: uuid("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    grade: integer("grade").notNull(), // 0 again | 1 hard | 2 good | 3 easy
    intervalDays: real("interval_days").notNull(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("reviews_user_idx").on(table.userId, table.reviewedAt)],
);

export const quizAttempts = pgTable(
  "quiz_attempts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    documentId: uuid("document_id")
      .notNull()
      .references(() => documents.id, { onDelete: "cascade" }),
    score: integer("score").notNull(),
    total: integer("total").notNull(),
    results: jsonb("results").$type<QuizQuestionResult[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("quiz_attempts_user_idx").on(table.userId, table.createdAt)],
);

export const aiEvents = pgTable(
  "ai_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    documentId: uuid("document_id"),
    provider: text("provider").notNull(),
    model: text("model").notNull(),
    credits: integer("credits").notNull().default(1),
    tokens: integer("tokens").notNull().default(0),
    inputTokens: integer("input_tokens").notNull().default(0),
    outputTokens: integer("output_tokens").notNull().default(0),
    costUsd: real("cost_usd").notNull().default(0),
    status: text("status").notNull().default("ok"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("ai_events_user_idx").on(table.userId, table.createdAt)],
);

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    stripeCustomerId: text("stripe_customer_id").notNull(),
    stripeSubscriptionId: text("stripe_subscription_id").notNull(),
    status: text("status").notNull(), // active | trialing | past_due | canceled | incomplete | unpaid
    priceId: text("price_id").notNull().default(""),
    currency: text("currency").notNull().default("inr"),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
    cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("subscriptions_stripe_id_unique").on(table.stripeSubscriptionId),
    index("subscriptions_user_idx").on(table.userId),
  ],
);

/** Idempotency ledger for Stripe webhook delivery (replay protection). */
export const stripeEvents = pgTable("stripe_events", {
  id: text("id").primaryKey(),
  type: text("type").notNull(),
  processedAt: timestamp("processed_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Postgres-backed fixed-window rate limiter (no extra infrastructure). */
export const rateLimits = pgTable(
  "rate_limits",
  {
    key: text("key").primaryKey(),
    points: integer("points").notNull().default(0),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (table) => [index("rate_limits_expiry_idx").on(table.expiresAt)],
);

export type UserRow = typeof users.$inferSelect;
export type DocumentRow = typeof documents.$inferSelect;
export type CardRow = typeof cards.$inferSelect;
export type SubscriptionRow = typeof subscriptions.$inferSelect;
