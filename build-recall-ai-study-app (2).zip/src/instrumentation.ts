/** Next.js boot hook: fail loudly on an unsupported runtime or auth misconfiguration. */
export async function register() {
  const { assertPdfRuntime } = await import("@/lib/pdf");
  const { assertAuthConfiguration } = await import("@/lib/auth/config");

  if (process.env.NEXT_RUNTIME === "nodejs") {
    assertPdfRuntime();
  }
  const provider = assertAuthConfiguration();
  console.log(
    JSON.stringify({
      event: "recall_boot",
      auth: provider,
      aiConfigured: Boolean(
        process.env.OPENAI_API_KEY ||
        process.env.ANTHROPIC_API_KEY ||
        process.env.GROQ_API_KEY ||
        process.env.OPENROUTER_API_KEY ||
        (process.env.AI_API_KEY && process.env.AI_BASE_URL),
      ),
      node: process.versions.node,
    }),
  );
}
