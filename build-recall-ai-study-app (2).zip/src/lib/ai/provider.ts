import { z } from "zod";
import { validateCard } from "@/lib/memory/engine";
import type { Analysis, MemoryCard } from "@/lib/memory/types";

/* ------------------------------------------------------------------ */
/* Provider-agnostic AI layer. Server-only.                            */
/* Keys are read from process.env and never leave the server.          */
/* ------------------------------------------------------------------ */

type Provider = {
  id: string;
  label: string;
  model: string;
  key: string;
};

const aiCardSchema = z.object({
  kind: z.string().optional(),
  prompt: z.string().min(4),
  answer: z.string().min(1),
  hint: z.string().optional(),
  quote: z.string().optional(),
  page: z.number().int().optional(),
  options: z.array(z.string()).optional(),
  explanation: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

const aiResponseSchema = z.object({
  summary: z.string().optional(),
  keyPoints: z.array(z.string()).optional(),
  recallPrompts: z.array(z.string()).optional(),
  cards: z.array(aiCardSchema).min(1),
});

export type AiUsage = {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  /** Estimated from a small, documented price table — shown as an estimate only. */
  costUsd: number;
};

export type AiErrorCode =
  "AI_NOT_CONFIGURED" | "AI_TIMEOUT" | "AI_PROVIDER_ERROR" | "AI_INVALID_OUTPUT";

export type AiResult = {
  ok: true;
  provider: string;
  model: string;
  cards: MemoryCard[];
  summary?: string;
  keyPoints?: string[];
  recallPrompts?: string[];
  usage: AiUsage;
  droppedCards: number;
};

export type AiFailure = {
  ok: false;
  provider: string;
  model: string;
  code: AiErrorCode;
  reason: "not_configured" | "provider_error" | "invalid_output" | "timeout";
  /** Safe to show in the UI: never contains provider response bodies, keys or endpoints. */
  message: string;
};

/** USD per million tokens. Estimates, used for the monthly spend figure only. */
const PRICE_TABLE: { match: RegExp; input: number; output: number }[] = [
  { match: /gpt-4o-mini/i, input: 0.15, output: 0.6 },
  { match: /gpt-4o/i, input: 2.5, output: 10 },
  { match: /claude-3-5-haiku/i, input: 0.8, output: 4 },
  { match: /claude-3-5-sonnet/i, input: 3, output: 15 },
  { match: /llama-3\.3-70b/i, input: 0.59, output: 0.79 },
];

export function estimateCostUsd(model: string, inputTokens: number, outputTokens: number): number {
  const price = PRICE_TABLE.find((entry) => entry.match.test(model));
  if (!price) return 0;
  const cost = (inputTokens / 1_000_000) * price.input + (outputTokens / 1_000_000) * price.output;
  return Number(cost.toFixed(6));
}

function usageOf(model: string, inputTokens: number, outputTokens: number): AiUsage {
  return {
    inputTokens,
    outputTokens,
    totalTokens: inputTokens + outputTokens,
    costUsd: estimateCostUsd(model, inputTokens, outputTokens),
  };
}

export class AiUpstreamError extends Error {
  readonly timeout: boolean;
  constructor(timeout: boolean) {
    super(timeout ? "AI provider timed out" : "AI provider returned an error");
    this.name = "AiUpstreamError";
    this.timeout = timeout;
  }
}

export function resolveAiProvider(): Provider | null {
  const explicit = process.env.AI_PROVIDER?.toLowerCase();

  if ((!explicit || explicit === "openai") && process.env.OPENAI_API_KEY) {
    return {
      id: "openai",
      label: "OpenAI",
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      key: process.env.OPENAI_API_KEY,
    };
  }
  if ((!explicit || explicit === "openrouter") && process.env.OPENROUTER_API_KEY) {
    return {
      id: "openrouter",
      label: "OpenRouter",
      model: process.env.AI_MODEL || "openai/gpt-4o-mini",
      key: process.env.OPENROUTER_API_KEY,
    };
  }
  if ((!explicit || explicit === "groq") && process.env.GROQ_API_KEY) {
    return {
      id: "groq",
      label: "Groq",
      model: process.env.AI_MODEL || "llama-3.3-70b-versatile",
      key: process.env.GROQ_API_KEY,
    };
  }
  if ((!explicit || explicit === "anthropic") && process.env.ANTHROPIC_API_KEY) {
    return {
      id: "anthropic",
      label: "Anthropic",
      model: process.env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest",
      key: process.env.ANTHROPIC_API_KEY,
    };
  }
  if ((!explicit || explicit === "custom") && process.env.AI_API_KEY && process.env.AI_BASE_URL) {
    return {
      id: "custom",
      label: "Custom endpoint",
      model: process.env.AI_MODEL || "gpt-4o-mini",
      key: process.env.AI_API_KEY,
    };
  }
  return null;
}

export function aiStatus(): { configured: boolean; provider: string | null; model: string | null } {
  const provider = resolveAiProvider();
  return {
    configured: Boolean(provider),
    provider: provider?.label ?? null,
    model: provider?.model ?? null,
  };
}

const SYSTEM_PROMPT = `You are an expert learning scientist. You convert source documents into high-quality spaced-repetition material.
Rules:
- Only use facts present in the source. Never invent statistics or names.
- Cards must be atomic: one idea per card, answerable without seeing the source.
- Prefer cloze deletions and definition questions over vague prompts.
- Questions must be specific, unambiguous and answerable in one or two sentences.
- Include the source page number when it is provided in the input markers.
Return ONLY valid JSON matching this shape:
{"summary":string,"keyPoints":string[],"recallPrompts":string[],"cards":[{"kind":"cloze|definition|fact|list|concept","prompt":string,"answer":string,"hint":string,"quote":string,"page":number,"explanation":string,"tags":string[]}]}`;

function buildUserPrompt(title: string, text: string, cardCount: number) {
  const trimmed = text.slice(0, 18000);
  return `Source title: ${title}
Target card count: ${cardCount}
Page boundaries are marked with [[page N]].

--- SOURCE START ---
${trimmed}
--- SOURCE END ---`;
}

function sanitizeCards(
  cards: z.infer<typeof aiCardSchema>[],
  fallbackPage: number,
): { cards: MemoryCard[]; dropped: number } {
  const allowedKinds = new Set(["cloze", "definition", "fact", "list", "concept", "ai"]);
  let dropped = 0;
  const accepted: MemoryCard[] = [];
  cards
    .filter((card) => card.prompt.trim().length > 5 && card.answer.trim().length > 0)
    .slice(0, 60)
    .forEach((card) => {
      const kind =
        card.kind && allowedKinds.has(card.kind) ? (card.kind as MemoryCard["kind"]) : "ai";
      const candidate: MemoryCard = {
        kind,
        prompt: card.prompt.trim(),
        answer: card.answer.trim(),
        hint: card.hint?.trim() || `Starts with “${card.answer.trim()[0] ?? "?"}”`,
        cloze: null,
        quote: (card.quote ?? "").trim().slice(0, 420),
        page:
          Number.isFinite(card.page) && (card.page ?? 0) > 0 ? (card.page as number) : fallbackPage,
        options: (card.options ?? []).filter((option) => typeof option === "string").slice(0, 5),
        explanation: card.explanation?.trim() ?? "Generated with AI, grounded in the source text.",
        tags: (card.tags ?? []).filter(Boolean).slice(0, 4),
      } satisfies MemoryCard;
      const validation = validateCard(candidate);
      if (validation.ok) accepted.push(candidate);
      else dropped += 1;
    });
  return { cards: accepted, dropped };
}

function parseJson(raw: string): unknown {
  const cleaned = raw
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/i, "")
    .trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON object found in AI response");
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function callOpenAiCompatible(
  provider: Provider,
  title: string,
  text: string,
  count: number,
) {
  const base =
    provider.id === "openrouter"
      ? "https://openrouter.ai/api/v1"
      : provider.id === "groq"
        ? "https://api.groq.com/openai/v1"
        : provider.id === "custom"
          ? (process.env.AI_BASE_URL ?? "").replace(/\/$/, "")
          : (process.env.OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");

  const response = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${provider.key}`,
      ...(provider.id === "openrouter" ? { "HTTP-Referer": "https://recall.study" } : {}),
    },
    body: JSON.stringify({
      model: provider.model,
      temperature: 0.3,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: buildUserPrompt(title, text, count) },
      ],
    }),
    signal: AbortSignal.timeout(45000),
  });

  if (!response.ok) {
    const detail = await response.text();
    console.error("ai_provider_http_error", {
      provider: provider.id,
      status: response.status,
      detail: detail.slice(0, 500),
    });
    throw new AiUpstreamError(false);
  }
  const payload = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
  };
  const inputTokens = payload.usage?.prompt_tokens ?? 0;
  const outputTokens = payload.usage?.completion_tokens ?? 0;
  return {
    content: payload.choices?.[0]?.message?.content ?? "",
    usage: usageOf(
      provider.model,
      inputTokens,
      outputTokens || Math.max(0, (payload.usage?.total_tokens ?? 0) - inputTokens),
    ),
  };
}

async function callAnthropic(provider: Provider, title: string, text: string, count: number) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": provider.key,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: provider.model,
      max_tokens: 4000,
      temperature: 0.3,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: buildUserPrompt(title, text, count) }],
    }),
    signal: AbortSignal.timeout(45000),
  });

  if (!response.ok) {
    const detail = await response.text();
    console.error("ai_provider_http_error", {
      provider: provider.id,
      status: response.status,
      detail: detail.slice(0, 500),
    });
    throw new AiUpstreamError(false);
  }
  const payload = (await response.json()) as {
    content?: { type: string; text?: string }[];
    usage?: { input_tokens?: number; output_tokens?: number };
  };
  const content = (payload.content ?? [])
    .filter((block) => block.type === "text")
    .map((block) => block.text ?? "")
    .join("\n");
  return {
    content,
    usage: usageOf(
      provider.model,
      payload.usage?.input_tokens ?? 0,
      payload.usage?.output_tokens ?? 0,
    ),
  };
}

export async function generateWithAi(input: {
  title: string;
  text: string;
  cardCount: number;
  pages?: string[];
}): Promise<AiResult | AiFailure> {
  const provider = resolveAiProvider();
  if (!provider) {
    return {
      ok: false,
      provider: "none",
      model: "none",
      code: "AI_NOT_CONFIGURED",
      reason: "not_configured",
      message:
        "The AI engine is not configured on this server. The deterministic rules engine is free and needs no key — switch to it to keep working.",
    };
  }

  const pageText = input.pages?.length
    ? input.pages.map((page, i) => `[[page ${i + 1}]]\n${page}`).join("\n\n")
    : input.text;

  try {
    const response =
      provider.id === "anthropic"
        ? await callAnthropic(provider, input.title, pageText, input.cardCount)
        : await callOpenAiCompatible(provider, input.title, pageText, input.cardCount);

    const parsed = aiResponseSchema.safeParse(parseJson(response.content));
    if (!parsed.success) {
      return {
        ok: false,
        provider: provider.label,
        model: provider.model,
        code: "AI_INVALID_OUTPUT",
        reason: "invalid_output",
        message:
          "The AI returned an unexpected shape, so nothing was charged. Every card shown came from the rules engine.",
      };
    }

    const { cards, dropped } = sanitizeCards(parsed.data.cards, 1);
    if (cards.length === 0) {
      return {
        ok: false,
        provider: provider.label,
        model: provider.model,
        code: "AI_INVALID_OUTPUT",
        reason: "invalid_output",
        message:
          "The AI cards failed our quality checks, so nothing was charged. The rules engine built this deck instead.",
      };
    }

    return {
      ok: true,
      provider: provider.label,
      model: provider.model,
      cards,
      summary: parsed.data.summary,
      keyPoints: parsed.data.keyPoints,
      recallPrompts: parsed.data.recallPrompts,
      usage: response.usage,
      droppedCards: dropped,
    };
  } catch (error) {
    const isTimeout =
      error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError");
    console.error("ai_generation_failed", {
      provider: provider.id,
      message: error instanceof Error ? error.message : "unknown",
    });
    return {
      ok: false,
      provider: provider.label,
      model: provider.model,
      code: isTimeout ? "AI_TIMEOUT" : "AI_PROVIDER_ERROR",
      reason: isTimeout ? "timeout" : "provider_error",
      message: isTimeout
        ? "The AI engine timed out, so nothing was charged. Your deck below came from the free rules engine."
        : "The AI provider had a problem, so nothing was charged. Your deck below came from the free rules engine.",
    };
  }
}

/** Merge AI output with the deterministic analysis without losing coverage. */
export function mergeAiAnalysis(base: Analysis, ai: AiResult): Analysis {
  return {
    ...base,
    engine: "ai",
    provider: `${ai.provider} · ${ai.model}`,
    summary: ai.summary?.trim() ? ai.summary.trim() : base.summary,
    keyPoints: ai.keyPoints?.length ? ai.keyPoints.slice(0, 8) : base.keyPoints,
    recallPrompts: ai.recallPrompts?.length ? ai.recallPrompts.slice(0, 5) : base.recallPrompts,
    generatedAt: new Date().toISOString(),
  };
}
