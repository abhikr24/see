export type AuthProviderName = "local" | "supabase";

export type AuthEnv = Record<string, string | undefined>;

export class AuthConfigurationError extends Error {
  readonly missing: string[];

  constructor(message: string, missing: string[] = []) {
    super(message);
    this.name = "AuthConfigurationError";
    this.missing = missing;
  }
}

export const SUPABASE_REQUIRED_VARS = ["SUPABASE_URL", "SUPABASE_ANON_KEY"] as const;

/**
 * Resolve the active auth provider, refusing to silently degrade.
 * AUTH_PROVIDER=supabase with a missing key is a deployment error, not a
 * reason to fall back to local password auth.
 */
export function assertAuthConfiguration(env: AuthEnv = process.env): AuthProviderName {
  const raw = (env.AUTH_PROVIDER ?? "local").trim().toLowerCase();
  if (raw !== "local" && raw !== "supabase") {
    throw new AuthConfigurationError(
      `AUTH_PROVIDER must be "local" or "supabase" (received "${raw || "(empty)"}").`,
    );
  }
  if (raw === "supabase") {
    const missing = SUPABASE_REQUIRED_VARS.filter((name) => !env[name]?.trim());
    if (missing.length > 0) {
      throw new AuthConfigurationError(
        `AUTH_PROVIDER=supabase requires ${missing.join(" and ")}. Set ${missing.join(" and ")} or switch AUTH_PROVIDER=local.`,
        [...missing],
      );
    }
  }
  return raw;
}

export function activeAuthProvider(env: AuthEnv = process.env): AuthProviderName {
  return assertAuthConfiguration(env);
}

export function describeAuthProvider(env: AuthEnv = process.env): {
  auth: AuthProviderName | "invalid";
  problem: string | null;
} {
  try {
    return { auth: assertAuthConfiguration(env), problem: null };
  } catch (error) {
    return {
      auth: "invalid",
      problem: error instanceof Error ? error.message : "Invalid auth configuration",
    };
  }
}
