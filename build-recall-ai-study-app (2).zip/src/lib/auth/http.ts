import type { NextResponse } from "next/server";
import { cookiePolicy } from "./index";

export function attachSessionCookie(response: NextResponse, token: string) {
  response.cookies.set(cookiePolicy.session.name, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: cookiePolicy.session.maxAge,
  });
  return response;
}

export function attachSupabaseCookies(
  response: NextResponse,
  tokens: { accessToken: string; refreshToken: string; expiresIn: number },
) {
  response.cookies.set(cookiePolicy.supabase.access, tokens.accessToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: Math.max(60, tokens.expiresIn),
  });
  response.cookies.set(cookiePolicy.supabase.refresh, tokens.refreshToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
  return response;
}
