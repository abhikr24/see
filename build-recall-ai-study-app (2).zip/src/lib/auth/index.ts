import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type UserRow } from "@/db/schema";
import { hashPassword, hashToken, newSessionToken, verifyPassword } from "./password";
import {
  supabaseEnabled,
  supabaseGetUser,
  supabaseRefresh,
  supabaseSignIn,
  supabaseSignOut,
  supabaseSignUp,
} from "./supabase";

export const SESSION_COOKIE = "recall_session";
export const SB_ACCESS_COOKIE = "recall_sb_at";
export const SB_REFRESH_COOKIE = "recall_sb_rt";
const SESSION_DAYS = 30;

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  plan: "free" | "pro";
  aiCredits: number;
  streak: number;
  lastStudiedOn: string | null;
};

export type AuthTokens = { accessToken: string; refreshToken: string; expiresIn: number };

export type AuthOutcomeStatus = "signed_in" | "confirm_email";

function toSessionUser(row: UserRow): SessionUser {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    plan: row.plan === "pro" ? "pro" : "free",
    aiCredits: row.aiCredits,
    streak: row.streak,
    lastStudiedOn: row.lastStudiedOn,
  };
}

/** Local mirror of a Supabase identity, so documents/cards keep their FK integrity. */
async function upsertExternalUser(input: { email: string; name: string }): Promise<UserRow> {
  const existing = await db.select().from(users).where(eq(users.email, input.email)).limit(1);
  if (existing[0]) return existing[0];
  const inserted = await db
    .insert(users)
    .values({
      email: input.email,
      name: input.name || input.email.split("@")[0],
      passwordHash: `external$${input.email}`,
      plan: "free",
      aiCredits: 0,
    })
    .onConflictDoNothing()
    .returning();
  if (inserted[0]) return inserted[0];
  const again = await db.select().from(users).where(eq(users.email, input.email)).limit(1);
  if (!again[0]) throw new Error("Could not mirror external user");
  return again[0];
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  const store = await cookies();

  if (supabaseEnabled()) {
    const accessToken = store.get(SB_ACCESS_COOKIE)?.value;
    const refreshToken = store.get(SB_REFRESH_COOKIE)?.value;
    try {
      if (accessToken) {
        const remote = await supabaseGetUser(accessToken);
        return toSessionUser(await upsertExternalUser(remote));
      }
      if (refreshToken) {
        const refreshed = await supabaseRefresh(refreshToken);
        const remote = refreshed.user;
        return toSessionUser(await upsertExternalUser(remote));
      }
    } catch {
      return null;
    }
    return null;
  }

  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!rows[0]) return null;
  const refreshed = await applyMonthlyCreditReset(rows[0].user);
  return toSessionUser(refreshed);
}

const CREDIT_RESET_MS = 30 * 24 * 60 * 60 * 1000;
const PRO_MONTHLY_CREDITS = 40;

/** Pro credits reset every 30 days. Free accounts never receive credits. */
async function applyMonthlyCreditReset(row: UserRow): Promise<UserRow> {
  if (row.plan !== "pro") return row;
  const due = Date.now() - row.creditsResetAt.getTime() >= CREDIT_RESET_MS;
  if (!due) return row;
  const updated = await db
    .update(users)
    .set({ aiCredits: PRO_MONTHLY_CREDITS, creditsResetAt: new Date() })
    .where(eq(users.id, row.id))
    .returning();
  return updated[0] ?? row;
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHENTICATED");
  return user;
}

type AuthOutcome =
  | {
      ok: true;
      user?: SessionUser;
      status: AuthOutcomeStatus;
      sessionToken?: string;
      tokens?: AuthTokens;
    }
  | { ok: false; error: string };

export async function signIn(emailRaw: string, password: string): Promise<AuthOutcome> {
  const email = emailRaw.trim().toLowerCase();
  if (!email || !password) return { ok: false, error: "Email and password are required." };

  if (supabaseEnabled()) {
    try {
      const { user, tokens } = await supabaseSignIn(email, password);
      const local = await upsertExternalUser(user);
      return { ok: true, status: "signed_in", user: toSessionUser(local), tokens };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : "Sign in failed." };
    }
  }

  const found = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const row = found[0];
  if (!row) return { ok: false, error: "No account with that email. Create one below." };
  const valid = await verifyPassword(password, row.passwordHash);
  if (!valid) return { ok: false, error: "That password does not match our records." };

  const token = newSessionToken();
  await db.insert(sessions).values({
    tokenHash: hashToken(token),
    userId: row.id,
    expiresAt: new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000),
  });
  return { ok: true, status: "signed_in", user: toSessionUser(row), sessionToken: token };
}

export async function signUp(
  nameRaw: string,
  emailRaw: string,
  password: string,
): Promise<AuthOutcome> {
  const email = emailRaw.trim().toLowerCase();
  const name = nameRaw.trim() || email.split("@")[0];
  if (!email.includes("@")) return { ok: false, error: "Enter a valid email address." };
  if (password.length < 8)
    return { ok: false, error: "Use at least 8 characters for the password." };

  if (supabaseEnabled()) {
    try {
      const { user, tokens } = await supabaseSignUp(name, email, password);
      const local = await upsertExternalUser(user);
      if (!tokens) {
        // Supabase has email confirmation enabled: no session exists yet.
        return { ok: true, status: "confirm_email", user: toSessionUser(local) };
      }
      return { ok: true, status: "signed_in", user: toSessionUser(local), tokens };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : "Sign up failed." };
    }
  }

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  if (existing[0])
    return { ok: false, error: "That email already has an account. Sign in instead." };

  const passwordHash = await hashPassword(password);
  const inserted = await db
    .insert(users)
    .values({ email, name, passwordHash, plan: "free", aiCredits: 0 })
    .returning();
  const row = inserted[0];
  if (!row) return { ok: false, error: "Could not create the account." };

  const token = newSessionToken();
  await db.insert(sessions).values({
    tokenHash: hashToken(token),
    userId: row.id,
    expiresAt: new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000),
  });
  return { ok: true, status: "signed_in", user: toSessionUser(row), sessionToken: token };
}

export async function signOut(): Promise<void> {
  const store = await cookies();
  if (supabaseEnabled()) {
    const accessToken = store.get(SB_ACCESS_COOKIE)?.value;
    if (accessToken) await supabaseSignOut(accessToken);
    store.delete(SB_ACCESS_COOKIE);
    store.delete(SB_REFRESH_COOKIE);
    return;
  }
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  }
  store.delete(SESSION_COOKIE);
}

export const cookiePolicy = {
  session: {
    name: SESSION_COOKIE,
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  },
  supabase: { access: SB_ACCESS_COOKIE, refresh: SB_REFRESH_COOKIE },
};
