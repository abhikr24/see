import Stripe from "stripe";

export type BillingInterval = "month" | "year";
export type Currency = "inr" | "usd";

export const PRO_CREDITS_PER_PERIOD = 40;
export const PRO_PERIOD_DAYS = 30;

export const PRICES: Record<Currency, { monthly: number; yearly: number; symbol: string }> = {
  inr: { monthly: 399, yearly: 3990, symbol: "₹" },
  usd: { monthly: 4.99, yearly: 49.9, symbol: "$" },
};

export function stripeSecret(): string | null {
  return process.env.STRIPE_SECRET_KEY?.trim() || null;
}

export function stripeWebhookSecret(): string | null {
  return process.env.STRIPE_WEBHOOK_SECRET?.trim() || null;
}

export function billingConfigured(): boolean {
  return stripeSecret() !== null;
}

let cached: Stripe | null = null;

/** Server-only Stripe client. Never imported into a client component. */
export function stripeClient(): Stripe | null {
  const key = stripeSecret();
  if (!key) return null;
  if (!cached) cached = new Stripe(key, { maxNetworkRetries: 1, timeout: 20_000 });
  return cached;
}

export function priceFor(currency: Currency, interval: BillingInterval): string | null {
  const name = `STRIPE_PRICE_${currency.toUpperCase()}_${interval === "year" ? "YEAR" : "MONTH"}`;
  return process.env[name]?.trim() || null;
}

export function detectCurrency(request: Request, override?: string | null): Currency {
  if (override === "inr" || override === "usd") return override;
  const accept = request.headers.get("accept-language") ?? "";
  return /(^|[,;])\s*(hi|en-IN)\b/i.test(accept) ? "inr" : "usd";
}

export function mapStripeStatus(status: string): { plan: "free" | "pro" } {
  const entitled = status === "active" || status === "trialing" || status === "past_due";
  return { plan: entitled ? "pro" : "free" };
}

export type WebhookOutcome =
  | { kind: "ignored"; reason: string }
  | { kind: "upgrade"; credits: number; status: string }
  | { kind: "renewed"; credits: number; status: string }
  | { kind: "downgrade"; status: string }
  | { kind: "sync"; status: string };

export { Stripe };
