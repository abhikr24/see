import { mapStripeStatus, PRO_CREDITS_PER_PERIOD, type WebhookOutcome } from "./stripe";

export type SubscriptionLike = {
  id: string;
  status: string;
  customer: string | { id: string };
  metadata?: Record<string, string> | null;
  items?: { data?: { price?: { id?: string; currency?: string } }[] };
  current_period_end?: number;
  cancel_at_period_end?: boolean;
};

type EventLike = { id: string; type: string; data: { object: unknown } };

export function customerIdOf(customer: string | { id: string }): string {
  return typeof customer === "string" ? customer : customer.id;
}

export function periodEndOf(subscription: SubscriptionLike): Date | null {
  return subscription.current_period_end ? new Date(subscription.current_period_end * 1000) : null;
}

export function subscriptionPriceOf(subscription: SubscriptionLike): {
  priceId: string;
  currency: string;
} {
  const price = subscription.items?.data?.[0]?.price;
  return { priceId: price?.id ?? "", currency: price?.currency ?? "inr" };
}

/** Pure classification of an event — unit-tested without Stripe or a database. */
export function classifyEvent(event: Pick<EventLike, "type" | "data">): WebhookOutcome {
  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as { subscription?: string | null };
      if (!session.subscription) return { kind: "ignored", reason: "no_subscription_in_session" };
      return { kind: "upgrade", credits: PRO_CREDITS_PER_PERIOD, status: "active" };
    }
    case "invoice.paid": {
      const invoice = event.data.object as { subscription?: string | null };
      if (!invoice.subscription) return { kind: "ignored", reason: "invoice_without_subscription" };
      return { kind: "renewed", credits: PRO_CREDITS_PER_PERIOD, status: "active" };
    }
    case "customer.subscription.updated": {
      const subscription = event.data.object as unknown as SubscriptionLike;
      return mapStripeStatus(subscription.status).plan === "pro"
        ? { kind: "sync", status: subscription.status }
        : { kind: "downgrade", status: subscription.status };
    }
    case "customer.subscription.deleted": {
      const subscription = event.data.object as unknown as SubscriptionLike;
      return { kind: "downgrade", status: subscription.status || "canceled" };
    }
    default:
      return { kind: "ignored", reason: "unhandled_event" };
  }
}

export function metadataUserId(event: Pick<EventLike, "data">): string | null {
  const object = event.data.object as {
    metadata?: Record<string, string> | null;
    subscription_details?: { metadata?: Record<string, string> | null };
  };
  return object.metadata?.userId ?? object.subscription_details?.metadata?.userId ?? null;
}

export function subscriptionFrom(event: Pick<EventLike, "data">): SubscriptionLike | null {
  const object = event.data.object as Record<string, unknown> | null;
  if (!object || typeof object !== "object") return null;
  const candidate = (object.subscription ?? object) as SubscriptionLike | null;
  if (!candidate || typeof candidate !== "object" || !candidate.id || !candidate.customer)
    return null;
  return candidate;
}
