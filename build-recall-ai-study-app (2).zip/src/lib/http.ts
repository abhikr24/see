import { NextResponse } from "next/server";

export function requestIdFor(request: Request): string {
  const supplied = request.headers.get("x-request-id");
  if (supplied && supplied.length <= 100) return supplied;
  return crypto.randomUUID();
}

export function jsonError(
  status: number,
  code: string,
  error: string,
  requestId: string,
): NextResponse {
  return NextResponse.json({ error, code, requestId }, { status });
}

/** Log the raw detail server-side only; the browser gets the human message. */
export function logServerError(scope: string, requestId: string, detail: unknown): void {
  console.error(
    `[${scope}] request=${requestId}`,
    detail instanceof Error ? detail.message : detail,
  );
}

export async function readJson<T>(request: Request): Promise<T | null> {
  try {
    return (await request.json()) as T;
  } catch {
    return null;
  }
}
