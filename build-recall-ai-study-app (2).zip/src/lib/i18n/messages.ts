export const LOCALES = ["en", "hi"] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "en";

export type MessageKey =
  | "nav.overview"
  | "nav.new"
  | "nav.review"
  | "nav.billing"
  | "nav.licences"
  | "app.signOut"
  | "app.signedOut"
  | "dashboard.greeting"
  | "dashboard.subtitleDue"
  | "dashboard.subtitleClear"
  | "dashboard.newSource"
  | "review.title"
  | "review.subtitle"
  | "review.emptyTitle"
  | "review.emptyBody"
  | "review.dueNow"
  | "review.reveal"
  | "review.gradeAgain"
  | "review.gradeHard"
  | "review.gradeGood"
  | "review.gradeEasy"
  | "review.offline"
  | "billing.title"
  | "billing.subtitle"
  | "common.language"
  | "common.online"
  | "common.offline";

const en: Record<MessageKey, string> = {
  "nav.overview": "Overview",
  "nav.new": "New source",
  "nav.review": "Review",
  "nav.billing": "Billing",
  "nav.licences": "Licences",
  "app.signOut": "Sign out",
  "app.signedOut": "Signed out.",
  "dashboard.greeting": "Welcome back",
  "dashboard.subtitleDue": "cards are waiting. Short session, real retention.",
  "dashboard.subtitleClear": "Nothing is due right now. Add a source or get ahead on a deck.",
  "dashboard.newSource": "New source",
  "review.title": "Your review queue.",
  "review.subtitle":
    "Cards appear here when their interval expires. Grade honestly — an inflated answer pushes the card further away than it deserves.",
  "review.emptyTitle": "Nothing due right now",
  "review.emptyBody":
    "Your next batch is scheduled. You can still study ahead by opening a specific deck.",
  "review.dueNow": "due now",
  "review.reveal": "Reveal answer",
  "review.gradeAgain": "Again",
  "review.gradeHard": "Hard",
  "review.gradeGood": "Good",
  "review.gradeEasy": "Easy",
  "review.offline": "Offline — graded cards are queued on this device.",
  "billing.title": "Plan, credits & keys.",
  "billing.subtitle":
    "The free engine never expires. Pro exists to cover AI tokens — nothing else is gated.",
  "common.language": "Language",
  "common.online": "Online",
  "common.offline": "Offline",
};

const hi: Record<MessageKey, string> = {
  "nav.overview": "अवलोकन",
  "nav.new": "नया स्रोत",
  "nav.review": "दोहराएँ",
  "nav.billing": "बिलिंग",
  "nav.licences": "लाइसेंस",
  "app.signOut": "साइन आउट",
  "app.signedOut": "साइन आउट हो गया।",
  "dashboard.greeting": "फिर से स्वागत है",
  "dashboard.subtitleDue": "कार्ड तैयार हैं। छोटा सत्र, पक्की याददाश्त।",
  "dashboard.subtitleClear": "अभी कुछ देय नहीं है। नया स्रोत जोड़ें या आगे की तैयारी करें।",
  "dashboard.newSource": "नया स्रोत",
  "review.title": "आपकी दोहराव सूची।",
  "review.subtitle":
    "अंतराल पूरा होने पर कार्ड यहाँ आते हैं। ईमानदारी से ग्रेड दें — बढ़ा-चढ़ा कर दिया गया उत्तर कार्ड को जल्दी लौटा देता है।",
  "review.emptyTitle": "अभी कुछ देय नहीं",
  "review.emptyBody": "अगला बैच निर्धारित है। किसी डेक को खोलकर आगे पढ़ सकते हैं।",
  "review.dueNow": "अभी देय",
  "review.reveal": "उत्तर दिखाएँ",
  "review.gradeAgain": "फिर से",
  "review.gradeHard": "कठिन",
  "review.gradeGood": "अच्छा",
  "review.gradeEasy": "आसान",
  "review.offline": "ऑफ़लाइन — ग्रेड किए कार्ड इस डिवाइस पर कतार में हैं।",
  "billing.title": "प्लान, क्रेडिट और कुंजियाँ।",
  "billing.subtitle": "मुफ़्त इंजन कभी समाप्त नहीं होता। Pro केवल AI टोकन के लिए है।",
  "common.language": "भाषा",
  "common.online": "ऑनलाइन",
  "common.offline": "ऑफ़लाइन",
};

export const MESSAGES: Record<Locale, Record<MessageKey, string>> = { en, hi };

export const LOCALE_LABELS: Record<Locale, string> = { en: "English", hi: "हिन्दी" };

export function isLocale(value: string | undefined | null): value is Locale {
  return value === "en" || value === "hi";
}

export function translate(locale: Locale, key: MessageKey): string {
  return MESSAGES[locale][key] ?? MESSAGES.en[key] ?? key;
}

export function formatNumber(value: number, locale: Locale): string {
  return new Intl.NumberFormat(locale === "hi" ? "hi-IN" : "en-US").format(value);
}

export function formatDate(value: Date | string, locale: Locale): string {
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat(locale === "hi" ? "hi-IN" : "en-US", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(date);
}

export function formatLongDate(value: Date, locale: Locale): string {
  return new Intl.DateTimeFormat(locale === "hi" ? "hi-IN" : "en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  }).format(value);
}
