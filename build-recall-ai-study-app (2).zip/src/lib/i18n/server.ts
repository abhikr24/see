import { cookies } from "next/headers";
import { DEFAULT_LOCALE, isLocale, translate, type Locale, type MessageKey } from "./messages";

export const LOCALE_COOKIE = "recall_locale";

export async function getLocale(): Promise<Locale> {
  const store = await cookies();
  const value = store.get(LOCALE_COOKIE)?.value;
  return isLocale(value) ? value : DEFAULT_LOCALE;
}

export type Translator = (key: MessageKey) => string;

export async function getTranslator(): Promise<{ locale: Locale; t: Translator }> {
  const locale = await getLocale();
  return { locale, t: (key: MessageKey) => translate(locale, key) };
}
