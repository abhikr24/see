import Papa from "papaparse";
import { validateCard } from "@/lib/memory/engine";
import type { CardKind, MemoryCard } from "@/lib/memory/types";

export type ImportFormat = "csv" | "tsv" | "markdown";
export type ImportResult = { cards: MemoryCard[]; skipped: number; detected: ImportFormat };

function toCard(
  prompt: string,
  answer: string,
  tags: string[],
  page: number,
  kind: CardKind,
): MemoryCard {
  const cleanedPrompt = prompt.replace(/\s+/g, " ").trim();
  // Anki/Quizlet fronts are often bare terms; make them valid prompts without
  // inventing content (the term itself becomes the question).
  const asQuestion =
    cleanedPrompt.endsWith("?") || cleanedPrompt.includes("_____")
      ? cleanedPrompt
      : `${cleanedPrompt}?`;
  return {
    kind,
    prompt: asQuestion,
    answer: answer.replace(/\s+/g, " ").trim(),
    hint: "",
    cloze: kind === "cloze" ? prompt : null,
    quote: "",
    page: Number.isFinite(page) && page > 0 ? page : 1,
    options: [],
    explanation: "Imported from your own deck.",
    tags: tags.slice(0, 6),
  };
}

/**
 * Import existing cards. Accepted shapes:
 *  - CSV/TSV with a header row: Front/Back/Tags/Page, Question/Answer, Term/Definition, prompt/answer
 *  - CSV/TSV with two columns and no header (Anki/Quizlet text export)
 *  - Markdown: table rows, or "Q: … / A: …" pairs, or "## Question" + answer block
 */
export function parseCardImport(content: string, format?: ImportFormat): ImportResult {
  const text = content.replace(/\r\n/g, "\n").trim();
  const detected: ImportFormat =
    format ??
    (text.startsWith("|") || /^Q:/im.test(text) || /^##\s+/m.test(text)
      ? "markdown"
      : text.split("\n")[0]?.includes("\t")
        ? "tsv"
        : "csv");

  const rows: { prompt: string; answer: string; tags: string[]; page: number; kind: CardKind }[] =
    [];

  if (detected === "markdown") {
    const lines = text.split("\n");
    const tableRows = lines.filter(
      (line) => line.trim().startsWith("|") && !/^\|[\s:|-]+\|$/.test(line.trim()),
    );
    if (tableRows.length > 1) {
      const cells = tableRows.map((line) =>
        line
          .trim()
          .replace(/^\||\|$/g, "")
          .split("|")
          .map((cell) => cell.trim()),
      );
      const header = cells[0].map((cell) => cell.toLowerCase());
      const isHeader = header.some((cell) =>
        ["front", "question", "term", "prompt", "back", "answer"].includes(cell),
      );
      const body = isHeader ? cells.slice(1) : cells;
      const promptIndex = isHeader
        ? header.findIndex((cell) => ["front", "question", "term", "prompt"].includes(cell))
        : 0;
      const answerIndex = isHeader
        ? header.findIndex((cell) => ["back", "answer", "definition", "response"].includes(cell))
        : 1;
      body.forEach((row) => {
        if (promptIndex < 0 || answerIndex < 0) return;
        rows.push({
          prompt: row[promptIndex] ?? "",
          answer: row[answerIndex] ?? "",
          tags: (row[3] ?? "").split(/[,;\s]+/).filter(Boolean),
          page: 1,
          kind: "ai",
        });
      });
    } else {
      let pending: { prompt: string; answer: string } | null = null;
      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line) continue;
        const q = /^(?:Q|Question)\s*[:\-]\s*(.+)$/i.exec(line);
        const a = /^(?:A|Answer)\s*[:\-]\s*(.+)$/i.exec(line);
        const heading = /^#{1,6}\s+(.+)$/.exec(line);
        if (q) pending = { prompt: q[1], answer: "" };
        else if (a && pending) {
          rows.push({ prompt: pending.prompt, answer: a[1], tags: [], page: 1, kind: "ai" });
          pending = null;
        } else if (heading) pending = { prompt: heading[1], answer: "" };
        else if (pending && !pending.answer) {
          rows.push({
            prompt: pending.prompt.endsWith("?") ? pending.prompt : `${pending.prompt}?`,
            answer: line,
            tags: [],
            page: 1,
            kind: "ai",
          });
          pending = null;
        }
      }
    }
  } else {
    const parsed = Papa.parse<string[]>(text, {
      delimiter: detected === "tsv" ? "\t" : ",",
      skipEmptyLines: true,
    });
    const data = parsed.data.filter((row) => row.length >= 2);
    if (data.length === 0) return { cards: [], skipped: 0, detected };
    const header = data[0].map((cell) => cell.trim().toLowerCase());
    const known = [
      "front",
      "back",
      "question",
      "answer",
      "term",
      "definition",
      "prompt",
      "tags",
      "page",
    ];
    const hasHeader = header.some((cell) => known.includes(cell)) && !/[?.]/.test(data[0][0] ?? "");
    const body = hasHeader ? data.slice(1) : data;
    const find = (names: string[], fallback: number) => {
      const index = header.findIndex((cell) => names.includes(cell));
      return index >= 0 ? index : fallback;
    };
    const promptIndex = find(["front", "question", "term", "prompt"], 0);
    const answerIndex = find(["back", "answer", "definition"], 1);
    const tagIndex = find(["tags"], -1);
    const pageIndex = find(["page"], -1);
    body.forEach((row) => {
      rows.push({
        prompt: (row[promptIndex] ?? "").replace(/<br\s*\/?>/gi, " "),
        answer: (row[answerIndex] ?? "").replace(/<br\s*\/?>/gi, " "),
        tags: tagIndex >= 0 ? (row[tagIndex] ?? "").split(/[,;\s]+/).filter(Boolean) : [],
        page: pageIndex >= 0 ? Number(row[pageIndex]) : 1,
        kind: "ai",
      });
    });
  }

  const cards: MemoryCard[] = [];
  let skipped = 0;
  for (const row of rows) {
    const card = toCard(row.prompt, row.answer, row.tags, row.page, row.kind);
    if (validateCard({ ...card, kind: card.prompt.includes("_____") ? "cloze" : "ai" }).ok)
      cards.push(card);
    else skipped += 1;
    if (cards.length >= 500) break;
  }
  return { cards, skipped, detected };
}
