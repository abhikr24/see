import nlp from "compromise";
import Papa from "papaparse";
import { sentences as sbdSentences } from "sbd";
import { porterStem } from "./porter";
import { scheduleReview } from "./scheduler";
import type { Analysis, AnalyzeResult, CardKind, Concept, MemoryCard, SourceInput } from "./types";

export { scheduleReview };

/* ------------------------------------------------------------------ */
/* Deterministic helpers (seeded, so SSR and client output always match) */
/* ------------------------------------------------------------------ */

export function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seededShuffle<T>(items: T[], seed: number): T[] {
  const rand = mulberry32(seed);
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

const STOPWORDS = new Set(
  `a about above after again against all am an and any are aren't as at be because been before being below between both but by can cannot could couldn't did didn't do does doesn't doing don't down during each few for from further had hadn't has hasn't have haven't having he her here hers herself him himself his how i if in into is isn't it its itself let's me more most mustn't my myself no nor not of off on once only or other ought our ours ourselves out over own same shan't she should shouldn't so some such than that the their theirs them themselves then there these they this those through to too under until up very was wasn't we were weren't what when where which while who whom why will with won't would wouldn't you your yours yourself yourselves also may might must shall can upon within without among across per via etc ie eg thus therefore however moreover furthermore although though since unless whether both either neither one two three many much several often always never sometimes usually new using used use based given able well make makes made first second third next last according example examples figure table chapter section page fig et al`
    .split(/\s+/)
    .filter(Boolean),
);

const PRONOUNS = new Set(
  `it its this that these those they them their he she his her we you i our your there here`.split(
    /\s+/,
  ),
);

const GENERIC_TERMS = new Set(
  `material materials student students people person thing things way ways part parts kind kinds fact facts case cases number numbers example examples study studies research paper papers text source author authors chapter section figure table result results important different various many much often usually generally actually really simply problem problems question questions answer answers topic topics content contents point points idea ideas main key basic general whole lot lots something anything everything nothing able need needs used using called known order process processes effect effects role however therefore thus also because within without during between through around across another other such same more most less least large small high low good bad better best`.split(
    /\s+/,
  ),
);

const LOW_VALUE_ANSWERS = new Set(
  `time times year years day days week weeks month months people things thing way ways part parts kind kinds fact facts case cases number numbers student students someone something anyone everything nothing always often usually`.split(
    /\s+/,
  ),
);

const CUE_BOOSTS: Array<[RegExp, number]> = [
  [/\b(is|are|was|were) (defined|known) as\b/i, 2.4],
  [/\b(refers? to|means?|describes?|consists? of|comprises?)\b/i, 2.2],
  [/\b(because|therefore|as a result|consequently|leads? to|causes?|results? in)\b/i, 1.6],
  [/\b(important|key|critical|essential|fundamental|primary|core|principle)\b/i, 1.5],
  [/\b(first|second|third|finally|next|then)\b/i, 1.2],
  [
    /\b\d{1,4}(?:[.,]\d+)?\s?(?:%|percent|kg|km|cm|mm|ms|mv|hours?|days?|years?|million|billion)\b/i,
    1.5,
  ],
  [/\b(compare|contrast|difference|unlike|whereas|instead)\b/i, 1.3],
  [/\b(for example|such as|e\.g\.|including|includes?)\b/i, 1.1],
];

const REFERENCES_HEADING =
  /^(references?|bibliography|works cited|literature cited|further reading|citations|notes and references)\b/i;

const DANGLING_END =
  /\b(and|or|but|of|to|with|from|the|a|an|in|on|for|by|that|which|who|as|than|at|into|onto|about|per|vs)$/i;

/* ------------------------------------------------------------------ */
/* Cleaning and block extraction                                       */
/* ------------------------------------------------------------------ */

export function normalizeWhitespace(value: string): string {
  return value
    .replace(/\u00ad/g, "")
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+/g, " ")
    .trim();
}

function isPageFurniture(line: string): boolean {
  return (
    /^(?:page\s+)?\d{1,4}(?:\s*(?:of|\/)\s*\d{1,4})?$/i.test(line) ||
    /^(?:chapter|section)\s+\d+$/i.test(line) ||
    /^[-–—\s\d.,|/\\:;•·_]+$/.test(line)
  );
}

function looksLikeCitation(line: string): boolean {
  if (/\b(doi|https?:\/\/|et al\.|retrieved from|isbn)\b/i.test(line)) return true;
  const commas = (line.match(/,/g) ?? []).length;
  return commas >= 3 && /\b(19|20)\d{2}\b/.test(line);
}

/**
 * Classify a single extracted line as a heading.
 * Deliberately conservative: a false negative (sentence treated as heading)
 * costs one card; a false positive produces the "heading glued to sentence"
 * cards this rewrite exists to remove.
 */
export function isHeadingLine(raw: string): boolean {
  const line = normalizeWhitespace(raw)
    .replace(/^#+\s*/, "")
    .replace(/^[-•*]\s+/, "");
  if (!line || line.length > 80) return false;
  if (/[.!?]$/.test(line)) return false;
  const words = line.split(/\s+/).filter(Boolean);
  if (words.length > 10) return false;

  if (/^(chapter|section|part|unit|module|lesson|appendix)\b/i.test(line)) return true;
  if (/^\d+(?:\.\d+)*[\s.:]/.test(line) && words.length <= 7) return true;
  if (!/^[A-Z][A-Za-z0-9 ,&/'-]{2,70}$/.test(line)) return false;
  if (words.length > 9) return false;
  if (/,.*,/.test(line)) return false;
  if (PRONOUNS.has(words[0].toLowerCase())) return false;

  const contentWords = words
    .map((word) => word.replace(/[^A-Za-z0-9]/g, ""))
    .filter((word) => word.length > 2 && !STOPWORDS.has(word.toLowerCase()));
  if (contentWords.length === 0) return false;
  return contentWords.every((word) => /^[A-Z0-9]/.test(word));
}

export type Block = {
  kind: "heading" | "body";
  text: string;
  page: number;
  topic: string;
  level: number;
};

type PageLines = { lines: string[]; page: number };

function preparePages(pages: string[]): PageLines[] {
  const perPage = pages.map((page, index) => {
    const lines = page
      .split(/\r?\n/)
      .map((line) => normalizeWhitespace(line))
      .filter((line) => line.length > 0)
      .filter((line) => !isPageFurniture(line));
    return { lines, page: index + 1 };
  });

  // Drop running headers/footers that repeat on most pages.
  const edgeCounts = new Map<string, number>();
  perPage.forEach(({ lines }) => {
    [lines[0], lines[lines.length - 1]].forEach((line) => {
      if (!line || line.length > 90) return;
      edgeCounts.set(line, (edgeCounts.get(line) ?? 0) + 1);
    });
  });
  const threshold = Math.max(2, Math.ceil(perPage.length * 0.4));
  return perPage.map(({ lines, page }) => ({
    page,
    lines: lines.filter((line) => (edgeCounts.get(line) ?? 0) < threshold),
  }));
}

/**
 * Turn PDF/text pages into heading and body blocks. Headings never enter a
 * body sentence, which is what fixes the "Chapter 2 - _____ and Osmosis
 * Diffusion is..." class of broken cards.
 */
export function extractBlocks(pages: string[]): Block[] {
  const blocks: Block[] = [];
  let topic = "";
  let inReferences = false;

  for (const { lines, page } of preparePages(pages)) {
    let buffer: string[] = [];
    const flush = () => {
      if (buffer.length === 0) return;
      const text = normalizeWhitespace(
        buffer
          .reduce((acc, line) => {
            if (!acc) return line;
            if (/[a-z]-$/.test(acc)) return `${acc.slice(0, -1)}${line}`;
            return `${acc} ${line}`;
          }, "")
          .replace(/\s+/g, " "),
      );
      if (text) blocks.push({ kind: "body", text, page, topic, level: 0 });
      buffer = [];
    };

    for (const line of lines) {
      if (REFERENCES_HEADING.test(line) && isHeadingLine(line)) {
        if (inReferences) continue;
        flush();
        blocks.push({ kind: "heading", text: line, page, topic, level: 1 });
        inReferences = true;
        topic = line;
        continue;
      }
      if (inReferences) {
        // Resume at a real section heading, not at reference entries.
        if (!isHeadingLine(line) || looksLikeCitation(line)) continue;
        inReferences = false;
      }
      if (looksLikeCitation(line) && line.length > 60) continue;
      if (/^(?:figure|fig\.|table|exhibit)\s+\d+/i.test(line) && line.length < 120) continue;

      if (isHeadingLine(line)) {
        flush();
        topic = line;
        blocks.push({ kind: "heading", text: line, page, topic, level: 1 });
      } else {
        buffer.push(line);
      }
    }
    flush();
  }

  return blocks;
}

/** Kept for backwards compatibility with the landing-page demo. */
export function cleanPages(pages: string[]): { page: number; text: string }[] {
  const byPage = new Map<number, string[]>();
  extractBlocks(pages).forEach((block) => {
    const list = byPage.get(block.page) ?? [];
    if (block.kind === "body") list.push(block.text);
    byPage.set(block.page, list);
  });
  const pagesCount = Math.max(pages.length, 1);
  return Array.from({ length: pagesCount }, (_, index) => ({
    page: index + 1,
    text: normalizeWhitespace((byPage.get(index + 1) ?? []).join(" ")),
  }));
}

const FALLBACK_SENTENCE_SPLIT = /(?<=[.!?])\s+(?=[A-Z0-9"'(])/g;

export function splitSentences(text: string): string[] {
  const clean = normalizeWhitespace(text);
  if (!clean) return [];
  let raw: string[] = [];
  try {
    raw = sbdSentences(clean, {
      newline_boundaries: false,
      html_boundaries: false,
      sanitize: true,
      preserve_whitespace: false,
      allowed_tags: false,
    });
  } catch {
    raw = clean.split(FALLBACK_SENTENCE_SPLIT);
  }

  const merged: string[] = [];
  let carry = "";
  for (const part of raw) {
    const piece = normalizeWhitespace(`${carry} ${part}`.trim());
    carry = "";
    const words = piece.split(/\s+/).filter(Boolean);
    if (words.length < 4) {
      carry = piece;
      continue;
    }
    merged.push(piece);
  }
  if (carry) {
    if (merged.length > 0)
      merged[merged.length - 1] = normalizeWhitespace(`${merged[merged.length - 1]} ${carry}`);
    else merged.push(carry);
  }

  return merged
    .filter((part) => part.length >= 20)
    .filter((part) => /[A-Za-z]{3}/.test(part))
    .filter((part) => (part.match(/[.!?]/g) ?? []).length <= 4);
}

/* ------------------------------------------------------------------ */
/* Terms: compromise noun phrases + Porter stems + heading boosts      */
/* ------------------------------------------------------------------ */

export type TermEntry = {
  term: string;
  display: string;
  count: number;
  proper: boolean;
  heading: boolean;
  score: number;
  pages: number[];
};

function cleanTerm(raw: string): string {
  return normalizeWhitespace(raw)
    .replace(/^["'(\[]+/, "")
    .replace(/["')\].,;:!?]+$/, "")
    .replace(/^(?:the|a|an)\s+/i, "")
    .trim();
}

function termKey(value: string): string {
  return cleanTerm(value)
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter(Boolean)
    .map(porterStem)
    .join(" ");
}

function isUsableTerm(term: string): boolean {
  const lower = term.toLowerCase();
  if (term.length < 4 || term.length > 48) return false;
  if (/^\d+$/.test(term)) return false;
  const words = lower.split(/\s+/);
  if (words.length > 4) return false;
  if (words.every((word) => STOPWORDS.has(word) || PRONOUNS.has(word))) return false;
  if (GENERIC_TERMS.has(lower)) return false;
  if (words.length === 1 && words[0].length < 4) return false;
  return true;
}

type SentenceRecord = { text: string; page: number; order: number; score: number };

function sentencesOf(
  pages: string[],
  blocks: Block[],
): { text: string; page: number; order: number }[] {
  const out: { text: string; page: number; order: number }[] = [];
  let order = 0;
  for (const block of blocks) {
    if (block.kind !== "body") continue;
    for (const sentence of splitSentences(block.text)) {
      out.push({ text: sentence, page: block.page, order: order++ });
    }
  }
  if (out.length > 0) return out;
  // Fallback for sources without a single body block.
  pages.forEach((page, index) => {
    splitSentences(page).forEach((sentence) =>
      out.push({ text: sentence, page: index + 1, order: order++ }),
    );
  });
  return out;
}

function buildTermIndex(
  sentences: { text: string; page: number }[],
  headings: string[],
): Map<string, TermEntry> {
  const index = new Map<string, TermEntry>();
  const add = (raw: string, page: number, seen: Set<string>) => {
    const display = cleanTerm(raw);
    if (!isUsableTerm(display)) return;
    const key = termKey(display);
    if (!key || seen.has(key)) return;
    seen.add(key);
    const entry =
      index.get(key) ??
      ({
        term: key,
        display,
        count: 0,
        proper: false,
        heading: false,
        score: 0,
        pages: [],
      } satisfies TermEntry);
    entry.count += 1;
    if (!entry.pages.includes(page)) entry.pages.push(page);
    if (/^[A-Z]/.test(display) && !/^[A-Z\s]+$/.test(display)) entry.proper = true;
    if (/^[A-Z]{2,}/.test(display)) entry.proper = true;
    index.set(key, entry);
  };

  for (const sentence of sentences) {
    const doc = nlp(sentence.text);
    const seen = new Set<string>();
    const phrases = [
      ...(doc.nouns().out("array") as string[]),
      ...(doc.match("#ProperNoun+").out("array") as string[]),
    ];
    for (const phrase of phrases) add(phrase, sentence.page, seen);
  }

  const headingText = headings.map((heading) => heading.toLowerCase());
  for (const entry of index.values()) {
    const needle = entry.display.toLowerCase();
    entry.heading = headingText.some(
      (heading) => heading.includes(needle) || termKey(heading).includes(entry.term),
    );
    entry.score =
      Math.log2(1 + entry.count) * (1 + (entry.proper ? 0.8 : 0) + (entry.heading ? 0.5 : 0)) +
      (entry.display.includes(" ") ? 0.4 : 0);
  }
  return index;
}

function rankedTerms(index: Map<string, TermEntry>, limit: number): TermEntry[] {
  return [...index.values()]
    .filter((entry) => entry.count >= 2)
    .filter((entry) => !GENERIC_TERMS.has(entry.display.toLowerCase()))
    .sort((a, b) => b.score - a.score || a.display.localeCompare(b.display))
    .slice(0, limit);
}

function sentenceScore(sentence: string, index: Map<string, TermEntry>): number {
  const tokens = [...new Set(tokensOf(sentence).slice(0, 26))];
  const keywordWeight = tokens.reduce((total, token) => {
    const entry = index.get(termKey(token));
    return total + (entry ? entry.score : 0);
  }, 0);
  const wordCount = sentence.split(/\s+/).length;
  const lengthScore = wordCount >= 7 && wordCount <= 34 ? 1 : 0.65;
  const cue = CUE_BOOSTS.reduce(
    (total, [pattern, boost]) => total + (pattern.test(sentence) ? boost : 0),
    0,
  );
  const questionPenalty = /\?$/.test(sentence) ? 0.8 : 0;
  return keywordWeight * lengthScore + cue - questionPenalty;
}

function tokensOf(value: string): string[] {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s'-]/g, " ")
    .split(/\s+/)
    .filter((word) => word.length > 2)
    .filter((word) => !STOPWORDS.has(word))
    .filter((word) => !GENERIC_TERMS.has(word));
}

function key(value: string): string {
  return normalizeWhitespace(value)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function hintFor(answer: string): string {
  const first = normalizeWhitespace(answer).split(/\s+/)[0] ?? "";
  const shape = /\d/.test(answer) ? "It contains a number." : "It starts with a capital letter.";
  return first ? `Starts with “${first.slice(0, 1)}”. ${shape}` : shape;
}

function isCompleteClause(value: string): boolean {
  const trimmed = normalizeWhitespace(value);
  if (trimmed.length < 12) return false;
  if (/(\.\.\.|…)$/.test(trimmed)) return false;
  if (/[,;:–—-]$/.test(trimmed)) return false;
  if (DANGLING_END.test(trimmed)) return false;
  return true;
}

/** Fit an answer to 240 chars on a sentence/clause boundary. Never truncates mid-word. */
function fitAnswer(value: string, max = 240): string | null {
  const clean = normalizeWhitespace(value);
  if (clean.length === 0) return null;
  if (clean.length <= max) return isCompleteClause(clean) ? clean : null;
  for (const boundary of [". ", "; ", " — "]) {
    const cut = clean.lastIndexOf(boundary, max);
    if (cut > 80) {
      const candidate = normalizeWhitespace(clean.slice(0, cut + (boundary === ". " ? 1 : 0)));
      if (isCompleteClause(candidate)) return candidate;
    }
  }
  return null;
}

function headingSet(headings: string[]): Set<string> {
  return new Set(headings.map((heading) => key(heading)).filter(Boolean));
}

function makeOptions(answer: string, pool: string[], seed: number): string[] {
  const cleanAnswer = normalizeWhitespace(answer);
  const seen = new Set([key(cleanAnswer)]);
  const distractors: string[] = [];
  for (const candidate of seededShuffle(pool, seed)) {
    const value = normalizeWhitespace(candidate);
    if (value.length < 2 || value.length > 90) continue;
    const candidateKey = key(value);
    if (seen.has(candidateKey)) continue;
    if (candidateKey.includes(key(cleanAnswer)) || key(cleanAnswer).includes(candidateKey))
      continue;
    seen.add(candidateKey);
    distractors.push(value);
    if (distractors.length === 3) break;
  }
  const fallback = ["None of these", "Not stated in the source", "The opposite is true"];
  let fallbackIndex = 0;
  while (distractors.length < 3) {
    distractors.push(fallback[fallbackIndex % fallback.length]);
    fallbackIndex += 1;
  }
  return seededShuffle([cleanAnswer, ...distractors], seed + 7);
}

/* ------------------------------------------------------------------ */
/* Subject / predicate analysis                                        */
/* ------------------------------------------------------------------ */

function subjectOf(sentence: string): string | null {
  const nouns = (nlp(sentence).nouns().out("array") as string[])
    .map(cleanTerm)
    .filter((noun) => noun.length > 1);
  const lower = sentence.toLowerCase();
  for (const noun of nouns) {
    const index = lower.indexOf(noun.toLowerCase());
    if (index < 0) continue;
    if (index > 40) break;
    const before = lower.slice(0, index).trim();
    if (
      before &&
      /\b(of|in|on|for|with|by|from|across|through|between|using|into|about|to|at)$/.test(before)
    )
      continue;
    if (STOPWORDS.has(noun.toLowerCase()) || PRONOUNS.has(noun.toLowerCase())) continue;
    return noun;
  }
  return null;
}

const DEF_CUE =
  /\b(is|are|was|were|means|refers? to|is defined as|is known as|denotes|consists? of)\b/i;

function definitionOf(sentence: string): { term: string; body: string } | null {
  const match = DEF_CUE.exec(sentence);
  if (!match || match.index === undefined) return null;
  const left = normalizeWhitespace(sentence.slice(0, match.index));
  const body = normalizeWhitespace(sentence.slice(match.index + match[0].length));
  if (!left || !body) return null;
  const leftWords = left.split(/\s+/);
  if (leftWords.length > 8) return null;
  if (/[,;:()]/.test(left)) return null;
  if (PRONOUNS.has(leftWords[0].toLowerCase())) return null;
  const subject = subjectOf(sentence);
  if (!subject) return null;
  if (!key(left).includes(key(subject)) && !key(subject).includes(key(left))) return null;
  if (body.split(/\s+/).length < 4) return null;
  if (!isCompleteClause(body)) return null;
  return { term: left, body };
}

/* ------------------------------------------------------------------ */
/* Card generators                                                     */
/* ------------------------------------------------------------------ */

const UNIT =
  "(?:%|percent|percentage|mV|kV|V|kg|mg|g|km|cm|mm|nm|ms|s|min|mins|minutes?|hours?|days?|weeks?|months?|years?|million|billion|trillion|thousand|Hz|kHz|MHz|GHz|GB|MB|KB|TB|°C|°F|mol|mph|km/h|dollars?|euros?|rupees?|yen)";

type Candidate = { card: MemoryCard; rank: number };

function buildDefinition(
  card: MemoryCard,
  term: TermEntry,
  seed: number,
  pool: string[],
): Candidate {
  const display = term.display.replace(/\b\w/g, (character) => character.toUpperCase());
  return {
    rank: term.score,
    card: {
      ...card,
      kind: "definition",
      prompt: `What is ${display}?`,
      tags: tokensOf(display).slice(0, 3),
      options: makeOptions(card.answer, pool, hashString(display) + seed),
      explanation: "Say the full definition before you flip the card.",
    },
  };
}

function buildClozeCard(
  sentence: string,
  target: string,
  page: number,
  kind: CardKind,
  index: Map<string, TermEntry>,
  seed: number,
  pool: string[],
): MemoryCard | null {
  const blanked = buildCloze(sentence, target);
  if (blanked === sentence) return null;
  const label = kind === "list" ? "Recall the sequence or grouping:" : "Fill the gap:";
  return {
    kind,
    prompt: `${label}\n${blanked}`,
    answer: target,
    hint: hintFor(target),
    cloze: blanked,
    quote: sentence,
    page,
    options: makeOptions(target, pool, hashString(`${target}:${page}`) + seed),
    explanation:
      kind === "list"
        ? "Rebuild the list out loud before flipping the card."
        : "Active fill-in-the-blank recall beats re-reading.",
    tags: tokensOf(sentence).slice(0, 3),
  };
}

function clozeCandidates(sentence: string, index: Map<string, TermEntry>): string[] {
  const doc = nlp(sentence);
  const raw = [
    ...(doc.nouns().out("array") as string[]),
    ...(doc.verbs().out("array") as string[]).filter((verb) => !/\s/.test(cleanTerm(verb))),
  ];
  const firstWord = sentence.split(/\s+/)[0]?.toLowerCase() ?? "";
  const seen = new Set<string>();
  const candidates: { term: string; score: number }[] = [];

  for (const item of raw) {
    const term = cleanTerm(item);
    if (!term || term.length < 4 || term.length > 40) continue;
    const lower = term.toLowerCase();
    if (lower === firstWord) continue;
    if (
      STOPWORDS.has(lower) ||
      PRONOUNS.has(lower) ||
      GENERIC_TERMS.has(lower) ||
      LOW_VALUE_ANSWERS.has(lower)
    )
      continue;
    if (/^\d[\d.,]*$/.test(term)) continue;
    if (seen.has(lower)) continue;
    const occurrences = sentence.match(new RegExp(`\\b${escapeRegExp(term)}\\b`, "gi")) ?? [];
    if (occurrences.length !== 1) continue;
    const entry = index.get(termKey(term));
    seen.add(lower);
    candidates.push({ term, score: (entry?.score ?? 0.2) + (lower.length > 6 ? 0.4 : 0) });
  }

  return candidates.sort((a, b) => b.score - a.score).map((entry) => entry.term);
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function buildCloze(sentence: string, target: string): string {
  return sentence.replace(new RegExp(`\\b${escapeRegExp(target)}\\b`, "i"), "_____");
}

function factMatch(sentence: string): { index: number; value: string } | null {
  const unitPattern = new RegExp(`[-+−]?\\s?[$€£₹]?\\d[\\d,]*(?:\\.\\d+)?\\s?${UNIT}`, "i");
  const yearPattern = /\b(?:1[5-9]\d{2}|20\d{2})\b/;
  const currencyPattern = /[$€£₹]\s?\d[\d,]*(?:\.\d+)?/;

  const candidates = [
    unitPattern.exec(sentence),
    yearPattern.exec(sentence),
    currencyPattern.exec(sentence),
  ]
    .filter((match): match is RegExpExecArray => Boolean(match && match.index !== undefined))
    .sort((a, b) => (a.index ?? 0) - (b.index ?? 0));

  for (const match of candidates) {
    if (match.index === undefined) continue;
    const raw = match[0];
    const value = normalizeWhitespace(raw).replace(/^([−])/, "-");
    if (!/\d/.test(value)) continue;
    if (value.length > 40) continue;
    // Never blank a list marker or a section number at the start of a sentence.
    const before = sentence.slice(0, match.index);
    if (before.trim().length === 0 && /^\d+(?:\.\d+)*[.)]?\s/.test(sentence)) continue;
    if (/^\d+(?:\.\d+)+$/.test(value)) continue;
    const blanked = `${before}_____${sentence.slice(match.index + raw.length)}`;
    if (blanked.split(/\s+/).length < 6) continue;
    return { index: match.index, value };
  }
  return null;
}

function conceptCardFor(
  term: TermEntry,
  sentences: SentenceRecord[],
  seed: number,
): { card: MemoryCard; rank: number } | null {
  const needle = term.display.toLowerCase();
  const found = sentences.find((sentence) => {
    const lower = sentence.text.toLowerCase();
    const position = lower.indexOf(needle);
    if (position < 0) return false;
    const subject = subjectOf(sentence.text);
    if (subject && key(subject).includes(key(term.display))) return true;
    return lower.slice(0, position).split(/\s+/).filter(Boolean).length <= 8;
  });
  if (!found) return null;
  const fitted = fitAnswer(found.text, 240);
  if (!fitted || !key(fitted).includes(key(term.display))) return null;
  const display = term.display.replace(/\b\w/g, (character) => character.toUpperCase());
  return {
    rank: term.score + 100,
    card: {
      kind: "concept",
      prompt: `What does the source say about “${display}”?`,
      answer: fitted,
      hint: `See page ${found.page}`,
      cloze: null,
      quote: found.text,
      page: found.page,
      options: [],
      explanation: "Say it in your own words first, then compare with the source line.",
      tags: tokensOf(display).slice(0, 3),
    },
  };
}

/* ------------------------------------------------------------------ */
/* Validator — every card, rules or AI, must pass this                 */
/* ------------------------------------------------------------------ */

export type CardValidationContext = { headings?: string[]; existingAnswers?: string[] };
export type CardValidationResult = { ok: true } | { ok: false; reason: string };

export const MAX_ANSWER_LENGTH = 240;

export function validateCard(
  card: MemoryCard,
  context: CardValidationContext = {},
): CardValidationResult {
  const prompt = normalizeWhitespace(card.prompt);
  const answer = normalizeWhitespace(card.answer);
  const headings = headingSet(context.headings ?? []);

  if (prompt.length < 8) return { ok: false, reason: "prompt_too_short" };
  if (!prompt.endsWith("?") && !prompt.includes("_____"))
    return { ok: false, reason: "prompt_not_a_question_or_cloze" };
  if (!answer) return { ok: false, reason: "answer_empty" };
  if (answer.length > MAX_ANSWER_LENGTH) return { ok: false, reason: "answer_too_long" };
  if (/(\.\.\.|…)\s*$/.test(answer)) return { ok: false, reason: "answer_truncated" };
  if (key(answer) === key(prompt)) return { ok: false, reason: "answer_equals_prompt" };
  if (!/[A-Za-z0-9]/.test(answer)) return { ok: false, reason: "answer_not_meaningful" };
  if (headings.has(key(answer))) return { ok: false, reason: "answer_is_heading" };
  if (/\b(and|or|but|of|to|with|from|the|a|an|in|on|for|by)$/i.test(answer)) {
    return { ok: false, reason: "answer_dangling" };
  }
  const answerWords = key(answer).split(/\s+/).filter(Boolean);
  if (answerWords.length === 0) return { ok: false, reason: "answer_not_meaningful" };
  if (answerWords.every((word) => STOPWORDS.has(word)))
    return { ok: false, reason: "answer_is_stopword" };

  const promptWithoutBlanks = prompt.replace(/_+/g, " ");
  if (key(promptWithoutBlanks).includes(key(answer))) {
    return { ok: false, reason: "answer_inside_prompt" };
  }
  if (card.kind === "cloze" || card.kind === "fact" || card.kind === "list") {
    if (new RegExp(`\\b${escapeRegExp(answer)}\\b`, "i").test(prompt)) {
      return { ok: false, reason: "cloze_answer_still_visible" };
    }
  }
  if (context.existingAnswers?.some((existing) => key(existing) === key(answer))) {
    return { ok: false, reason: "duplicate_answer" };
  }
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Concepts, summary, plan                                             */
/* ------------------------------------------------------------------ */

export function extractConcepts(
  terms: TermEntry[],
  sentences: { text: string; page: number }[],
  limit = 12,
): Concept[] {
  return terms.slice(0, limit).map((term) => {
    const found = sentences.find((sentence) => {
      const definition = definitionOf(sentence.text);
      if (!definition) return false;
      return (
        key(definition.term).includes(key(term.display)) ||
        key(term.display).includes(key(definition.term))
      );
    });
    const definition = found ? definitionOf(found.text) : null;
    return {
      term: term.display.replace(/\b\w/g, (character) => character.toUpperCase()),
      count: term.count,
      score: Number(term.score.toFixed(2)),
      definition: definition ? (fitAnswer(definition.body, 200) ?? "") : "",
      page: found?.page ?? term.pages[0] ?? 1,
    };
  });
}

function buildPlan(
  cardCount: number,
): { day: number; focus: string; minutes: number; cardCount: number }[] {
  const planDays = Math.max(3, Math.min(10, Math.ceil(cardCount / 12)));
  const perDay = Math.ceil(cardCount / planDays);
  return Array.from({ length: planDays }, (_, dayIndex) => ({
    day: dayIndex + 1,
    focus:
      dayIndex === 0
        ? "First pass — learn the new cards"
        : dayIndex === planDays - 1
          ? "Consolidate + teach it back"
          : dayIndex % 3 === 0
            ? "Mixed recall + weak spots"
            : "Spaced review of earlier cards",
    minutes: Math.max(6, Math.round(perDay * 0.9)),
    cardCount: Math.min(perDay, Math.max(0, cardCount - dayIndex * perDay)),
  }));
}

function shortSummary(value: string, max = 190): string {
  if (value.length <= max) return value;
  const cut = value.lastIndexOf(". ", max);
  return cut > 60 ? value.slice(0, cut + 1) : value.slice(0, max).trim();
}

/* ------------------------------------------------------------------ */
/* Main entry point                                                    */
/* ------------------------------------------------------------------ */

export function analyzeSource(input: SourceInput): AnalyzeResult {
  const blocks = extractBlocks(input.pages);
  const headings = blocks.filter((block) => block.kind === "heading").map((block) => block.text);
  const baseSentences = sentencesOf(input.pages, blocks);
  const fullText = normalizeWhitespace(
    blocks
      .filter((block) => block.kind === "body")
      .map((block) => block.text)
      .join(" ") || input.pages.join(" "),
  );
  const words = fullText.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  const index = buildTermIndex(baseSentences, headings);
  const terms = rankedTerms(index, 60);
  const topTerms = terms.slice(0, 8);
  const concepts = extractConcepts(terms, baseSentences, 12);

  const sentences: SentenceRecord[] = baseSentences.map((sentence) => ({
    ...sentence,
    score: sentenceScore(sentence.text, index),
  }));
  const ordered = [...sentences].sort((a, b) => b.score - a.score || a.order - b.order);

  const target = Math.max(8, Math.min(48, Math.round(wordCount / 30)));
  const seed = hashString(`${input.title}:${wordCount}:${sentences.length}`);
  const conceptPool = terms.slice(0, 40).map((term) => term.display);
  const headingKeys = headingSet(headings);
  const headingsNormalized = headings.map((heading) => normalizeWhitespace(heading));

  const buckets: Record<CardKind, Candidate[]> = {
    definition: [],
    cloze: [],
    fact: [],
    list: [],
    concept: [],
    ai: [],
  };
  const usedAnswers = new Set<string>();
  const usedPrompts = new Set<string>();
  const factSentences = new Set<string>();

  const register = (bucket: CardKind, card: MemoryCard, rank = 0): boolean => {
    const answerKey = key(card.answer);
    const promptKey = key(card.prompt);
    if (!answerKey || !promptKey) return false;
    if (usedAnswers.has(answerKey) || usedPrompts.has(promptKey)) return false;
    if (headingKeys.has(answerKey)) return false;
    usedAnswers.add(answerKey);
    usedPrompts.add(promptKey);
    buckets[bucket].push({ card, rank });
    return true;
  };

  /* Concepts first — coverage pass for the top 8 before any kind repeats. */
  const coverage: Candidate[] = [];
  for (const term of topTerms) {
    const existing = (Object.keys(buckets) as CardKind[])
      .flatMap((kind) => buckets[kind])
      .find((candidate) =>
        key(`${candidate.card.prompt} ${candidate.card.answer} ${candidate.card.quote}`).includes(
          key(term.display),
        ),
      );
    if (existing) continue;
    const concept = conceptCardFor(term, ordered, seed);
    if (concept && register("concept", concept.card, concept.rank)) {
      const created = buckets.concept[buckets.concept.length - 1];
      if (created) coverage.push(created);
    }
  }

  /* Definitions — term must be the subject, recur, and not be a heading. */
  for (const sentence of ordered) {
    const definition = definitionOf(sentence.text);
    if (!definition) continue;
    const entry = index.get(termKey(definition.term));
    if (!entry || entry.count < 2 || entry.heading) continue;
    if (headingKeys.has(key(definition.term))) continue;
    const answer = fitAnswer(definition.body, MAX_ANSWER_LENGTH);
    if (!answer) continue;
    const card: MemoryCard = {
      kind: "definition",
      prompt: `What is ${definition.term.replace(/\b\w/g, (c) => c.toUpperCase())}?`,
      answer,
      hint: hintFor(answer),
      cloze: null,
      quote: sentence.text,
      page: sentence.page,
      options: [],
      explanation: "Say the full definition before you flip the card.",
      tags: tokensOf(definition.term).slice(0, 3),
    };
    register("definition", buildDefinition(card, entry, seed, conceptPool).card, entry.score + 30);
  }

  /* Fact cards — numbers with units, currencies, years. */
  for (const sentence of ordered) {
    const match = factMatch(sentence.text);
    if (!match) continue;
    const blanked = `${sentence.text.slice(0, match.index)}_____${sentence.text.slice(match.index + match.value.length)}`;
    const card: MemoryCard = {
      kind: "fact",
      prompt: `Recall the exact figure:\n${blanked}`,
      answer: match.value,
      hint: hintFor(match.value),
      cloze: blanked,
      quote: sentence.text,
      page: sentence.page,
      options: makeOptions(
        match.value,
        ["0", "1", "10", "50%", "100", "24 hours", "7 days", "1,000", "2.5", ...conceptPool],
        hashString(match.value + sentence.page) + seed,
      ),
      explanation: "Numbers are the easiest facts to lose — anchor this one to the sentence.",
      tags: tokensOf(sentence.text).slice(0, 3),
    };
    if (register("fact", card, sentence.score + 20)) factSentences.add(key(sentence.text));
  }

  /* Lists / processes. */
  for (const sentence of ordered) {
    const isList =
      /\b(first|second|third|finally|steps?|stages?|phases?|types?|kinds?|categories|consists? of|includes?|such as)\b/i.test(
        sentence.text,
      );
    if (!isList) continue;
    const [target0] = clozeCandidates(sentence.text, index);
    if (!target0) continue;
    const card = buildClozeCard(
      sentence.text,
      target0,
      sentence.page,
      "list",
      index,
      seed,
      conceptPool,
    );
    if (card) register("list", card, sentence.score + 12);
  }

  /* Clozes — max 2 per sentence, never the first word or a used number. */
  for (const sentence of ordered) {
    if (factSentences.has(key(sentence.text))) continue;
    const targets = clozeCandidates(sentence.text, index).slice(0, 2);
    for (const target of targets) {
      const card = buildClozeCard(
        sentence.text,
        target,
        sentence.page,
        "cloze",
        index,
        seed,
        conceptPool,
      );
      if (card) register("cloze", card, sentence.score + 8);
    }
  }

  /* Remaining concept cards beyond the coverage pass. */
  for (const term of terms.slice(8, 24)) {
    const concept = conceptCardFor(term, ordered, seed);
    if (concept) register("concept", concept.card, concept.rank);
  }

  /* Select: coverage cards first, then round-robin across kinds. */
  const selected: Candidate[] = [...coverage];
  const coveredPrompts = new Set(selected.map((candidate) => key(candidate.card.prompt)));
  const remaining: Record<CardKind, Candidate[]> = {
    definition: buckets.definition.filter((c) => !coveredPrompts.has(key(c.card.prompt))),
    cloze: buckets.cloze.filter((c) => !coveredPrompts.has(key(c.card.prompt))),
    fact: buckets.fact.filter((c) => !coveredPrompts.has(key(c.card.prompt))),
    list: buckets.list.filter((c) => !coveredPrompts.has(key(c.card.prompt))),
    concept: buckets.concept.filter((c) => !coveredPrompts.has(key(c.card.prompt))),
    ai: [],
  };
  const order: CardKind[] = ["definition", "cloze", "fact", "list", "concept"];
  let cursor = 0;
  let guard = 0;
  while (selected.length < target && guard < target * 8) {
    guard += 1;
    const kind = order[cursor % order.length];
    cursor += 1;
    const next = remaining[kind].shift();
    if (next) selected.push(next);
    const exhausted = order.every((item) => remaining[item].length === 0);
    if (exhausted) break;
  }

  const cards: MemoryCard[] = [];
  const acceptedAnswers: string[] = [];
  let evaluated = 0;
  let dropped = 0;
  for (const candidate of selected) {
    evaluated += 1;
    const validation = validateCard(candidate.card, {
      headings: headingsNormalized,
      existingAnswers: acceptedAnswers,
    });
    if (!validation.ok) {
      dropped += 1;
      continue;
    }
    acceptedAnswers.push(candidate.card.answer);
    cards.push(candidate.card);
  }

  const qualityScore = evaluated > 0 ? Math.round((cards.length / evaluated) * 100) : 0;
  const coveredConcepts = concepts
    .slice(0, 8)
    .filter((concept) =>
      cards.some((card) =>
        key(`${card.prompt} ${card.answer} ${card.quote}`).includes(key(concept.term)),
      ),
    );
  const coveragePercent =
    Math.min(8, concepts.length) > 0
      ? Math.round((coveredConcepts.length / Math.min(8, concepts.length)) * 100)
      : 0;

  const topSentences = [...sentences]
    .sort((a, b) => b.score - a.score)
    .slice(0, 7)
    .sort((a, b) => a.order - b.order);
  const summaryParts = topSentences.slice(0, 4).map((entry) => shortSummary(entry.text));
  const summary = summaryParts.length
    ? summaryParts.join(" ")
    : "The source was too short to summarise. Paste at least a few paragraphs for the best results.";

  const keyPoints = [...sentences]
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .sort((a, b) => a.order - b.order)
    .map((entry) => shortSummary(entry.text, 210));

  const recallPrompts = [
    `Explain “${concepts[0]?.term ?? input.title}” to someone who has never seen this material — no notes.`,
    concepts[1]
      ? `How are “${concepts[0]?.term ?? "the main idea"}” and “${concepts[1].term}” connected? Which one depends on the other?`
      : "What is the single most important claim in this source, and what evidence supports it?",
    `Where would the main argument in “${input.title}” break down? Name one assumption and one exception.`,
    "Close the source. Write the three facts you would be most annoyed to forget — then check them.",
  ];

  const avgSentenceLength = sentences.length ? wordCount / sentences.length : 0;
  const warnings: string[] = [];
  if (wordCount < 180) {
    warnings.push(
      "Short source detected. You still get cards, but 1,500+ words produces a much richer deck.",
    );
  }
  if (sentences.length === 0) {
    warnings.push(
      "No readable text found. If this is a scanned PDF, the pages are images — paste the text or upload a text-based PDF.",
    );
  }
  if (qualityScore < 70 && cards.length > 0) {
    warnings.push(
      "This source is dense — try the AI engine or add more text. Your deck is saved as it is.",
    );
  }
  if (dropped > 0) {
    warnings.push(
      `${dropped} candidate${dropped === 1 ? "" : "s"} failed the card validator and ${dropped === 1 ? "was" : "were"} removed. Nothing incomplete was kept.`,
    );
  }

  const analysis: Analysis = {
    engine: "rules",
    summary,
    keyPoints,
    concepts,
    recallPrompts,
    plan: buildPlan(cards.length),
    stats: {
      words: wordCount,
      sentences: sentences.length,
      pages: Math.max(input.pages.length, 1),
      concepts: concepts.length,
      readingMinutes: Math.max(1, Math.ceil(wordCount / 220)),
      coverage: coveragePercent,
      difficulty:
        avgSentenceLength > 27 || wordCount / Math.max(concepts.length, 1) > 45
          ? "Dense"
          : avgSentenceLength > 17
            ? "Moderate"
            : "Light",
      qualityScore,
      generatedCards: evaluated,
      droppedCards: dropped,
      topConceptsCovered: coveredConcepts.length,
    },
    warnings,
    generatedAt: new Date().toISOString(),
  };

  return { analysis, cards };
}

/** Used by the landing-page demo and the paste flow before a document is saved. */
export function previewAnalysis(text: string, title = "Untitled source"): AnalyzeResult {
  return analyzeSource({ title, pages: [text] });
}

/* ------------------------------------------------------------------ */
/* Exports                                                             */
/* ------------------------------------------------------------------ */

const CSV_COLUMNS = ["Front", "Back", "Tags", "Page"] as const;

export type ExportCard = {
  prompt: string;
  answer: string;
  hint: string;
  tags: string[];
  page: number;
};

/**
 * Anki-ready CSV. PapaParse does the serialisation so the header and every row
 * always have the same field count (the old hand-rolled writer had four fields
 * per row but a three-field header).
 */
export function cardsToCsv(title: string, cards: ExportCard[]): string {
  const rows = cards.map((card) => ({
    Front: card.prompt.replace(/\r?\n/g, "<br>"),
    Back: card.answer.replace(/\r?\n/g, "<br>"),
    Tags: card.tags.join(" ").replace(/\s+/g, " ").trim(),
    Page: String(card.page),
  }));
  const csv = Papa.unparse(rows, {
    columns: [...CSV_COLUMNS],
    header: true,
    quotes: true,
    newline: "\n",
    skipEmptyLines: true,
  });
  const deck = title.replace(/[\r\n,:]/g, " ").trim() || "Recall deck";
  return `#separator:Comma\n#html:false\n#deck:${deck}\n${csv}\n`;
}

/** Quizlet-friendly TSV: two columns, no Anki preamble. */
export function cardsToTsv(cards: ExportCard[]): string {
  const rows = cards.map((card) => [
    card.prompt.replace(/\r?\n/g, " "),
    card.answer.replace(/\r?\n/g, " "),
  ]);
  return `Term\tDefinition\n${Papa.unparse(rows, { quotes: false, delimiter: "\t", newline: "\n" })}`;
}
