/**
 * A compact, dependency-free implementation of the Porter stemming algorithm
 * (M.F. Porter, 1980 — the algorithm itself is public domain).
 *
 * We implemented it locally rather than adding `natural` (MIT) to the server
 * bundle: `natural` is a large NLP toolkit and its dynamic requires are a
 * bundling liability in Next.js. The behaviour we need (merge inflections such
 * as "membranes" → "membran") is identical. Recorded in docs/DEPENDENCIES.md.
 */

const step2list: Record<string, string> = {
  ational: "ate",
  tional: "tion",
  enci: "ence",
  anci: "ance",
  izer: "ize",
  bli: "ble",
  alli: "al",
  entli: "ent",
  eli: "e",
  ousli: "ous",
  ization: "ize",
  ation: "ate",
  ator: "ate",
  alism: "al",
  iveness: "ive",
  fulness: "ful",
  ousness: "ous",
  aliti: "al",
  iviti: "ive",
  biliti: "ble",
  logi: "log",
};

const step3list: Record<string, string> = {
  icate: "ic",
  ative: "",
  alize: "al",
  iciti: "ic",
  ical: "ic",
  ful: "",
  ness: "",
};

const consonant = "[^aeiou]";
const vowel = "[aeiouy]";
const consonantSequence = `${consonant}[^aeiouy]*`;
const vowelSequence = `${vowel}[aeiou]*`;
const mgr0 = new RegExp(`^(${consonantSequence})?${vowelSequence}${consonantSequence}`);
const meq1 = new RegExp(
  `^(${consonantSequence})?${vowelSequence}${consonantSequence}(${vowelSequence})?$`,
);
const mgr1 = new RegExp(
  `^(${consonantSequence})?${vowelSequence}${consonantSequence}${vowelSequence}${consonantSequence}`,
);
const sV = new RegExp(`^(${consonantSequence})?${vowel}`);
const cvc = /^([^aeiou][^aeiouy]*)?[aeiouy][aeiou]*[^aeiou][^aeiouy]*$/;

function cvcWord(word: string): boolean {
  // "cvc" where the final consonant is not w, x or y.
  return cvc.test(word) && !/[wxy]$/.test(word);
}

export function porterStem(raw: string): string {
  const word = raw.toLowerCase();
  if (word.length < 3) return word;
  if (word.length > 40) return word;
  if (!/[a-z]/.test(word)) return word;

  let firstChar2 = "";
  let fp: RegExpExecArray | null = null;
  let re: RegExp;
  let re2: RegExp;
  let re3: RegExp;
  let re4: RegExp;
  let stem: string;
  let suffix: string;

  const initial = word[0];
  let working = initial === "y" ? `Y${word.slice(1)}` : word;

  /* Step 1a */
  re = /^(.+?)(ss|i)es$/;
  re2 = /^(.+?)([^s])s$/;
  if (re.test(working)) working = working.replace(re, "$1$2");
  else if (re2.test(working)) working = working.replace(re2, "$1$2");

  /* Step 1b */
  re = /^(.+?)eed$/;
  re2 = /^(.+?)(ed|ing)$/;
  if (re.test(working)) {
    fp = re.exec(working);
    if (fp && mgr0.test(fp[1])) {
      re = /.$/;
      working = working.replace(re, "");
    }
  } else if (re2.test(working)) {
    fp = re2.exec(working);
    stem = fp?.[1] ?? working;
    if (sV.test(stem)) {
      working = stem;
      re2 = /(at|bl|iz)$/;
      re3 = /([^aeiouylsz])\1$/;
      re4 = new RegExp(`^${consonantSequence}${vowel}[^aeiouwxy]$`);
      if (re2.test(working)) working = `${working}e`;
      else if (re3.test(working)) working = working.replace(re3, "$1");
      else if (re4.test(working)) working = `${working}e`;
    }
  }

  /* Step 1c */
  re = /^(.+?)y$/;
  if (re.test(working)) {
    fp = re.exec(working);
    stem = fp?.[1] ?? working;
    if (sV.test(stem)) working = `${stem}i`;
  }

  /* Step 2 */
  re =
    /^(.+?)(ational|tional|enci|anci|izer|bli|alli|entli|eli|ousli|ization|ation|ator|alism|iveness|fulness|ousness|aliti|iviti|biliti|logi)$/;
  if (re.test(working)) {
    fp = re.exec(working);
    stem = fp?.[1] ?? working;
    suffix = fp?.[2] ?? "";
    if (mgr0.test(stem)) working = stem + (step2list[suffix] ?? "");
  }

  /* Step 3 */
  re = /^(.+?)(icate|ative|alize|iciti|ical|ful|ness)$/;
  if (re.test(working)) {
    fp = re.exec(working);
    stem = fp?.[1] ?? working;
    suffix = fp?.[2] ?? "";
    if (mgr0.test(stem)) working = stem + (step3list[suffix] ?? "");
  }

  /* Step 4 */
  re = /^(.+?)(al|ance|ence|er|ic|able|ible|ant|ement|ment|ent|ou|ism|ate|iti|ous|ive|ize)$/;
  re2 = /^(.+?)(s|t)(ion)$/;
  if (re.test(working)) {
    fp = re.exec(working);
    stem = fp?.[1] ?? working;
    if (mgr1.test(stem)) working = stem;
  } else if (re2.test(working)) {
    fp = re2.exec(working);
    stem = (fp?.[1] ?? "") + (fp?.[2] ?? "");
    if (mgr1.test(stem)) working = stem;
  }

  /* Step 5 */
  re = /^(.+?)e$/;
  if (re.test(working)) {
    fp = re.exec(working);
    stem = fp?.[1] ?? working;
    re3 = new RegExp(`^${consonantSequence}${vowel}[^aeiouwxy]$`);
    if (mgr1.test(stem) || (meq1.test(stem) && !re3.test(stem))) working = stem;
  }
  re = /ll$/;
  re2 = /^(.+?)l$/;
  if (re.test(working)) {
    const candidate = working.replace(re2, "$1");
    if (mgr1.test(candidate)) working = candidate;
  }

  if (initial === "y") firstChar2 = "y";
  return firstChar2 + working.replace(/^Y/, "y");
}
