export const SAMPLE_TITLE = "The Forgetting Curve & How Memory Actually Works";

export const SAMPLE_TEXT = `Human memory is not a recording device. It is a reconstructive system that rebuilds an experience each time it is recalled, which is why two people can witness the same event and produce incompatible accounts of it.

Working memory is the small, temporary workspace where thinking happens. It holds roughly four chunks of information at once and decays within twenty to thirty seconds unless the material is actively rehearsed. Long-term memory has effectively unlimited capacity, but access depends on the strength of the retrieval route rather than the size of the store.

Hermann Ebbinghaus mapped the forgetting curve in 1885 by memorising nonsense syllables and testing himself at intervals. He found that roughly 60 percent of new material is lost within the first 24 hours, and that the curve flattens afterwards. The important discovery was not the speed of forgetting but its shape: each successful retrieval flattens the curve, so the same material decays far more slowly the second time.

Spaced repetition is a scheduling method that exploits this effect. Instead of reviewing everything every day, each item is shown just before the moment it would be forgotten. An item answered easily is pushed further into the future, while an item answered with difficulty returns tomorrow. Over weeks, this reduces total study time while increasing retention.

Active recall is the second principle. Testing yourself is far more effective than re-reading, because retrieval strengthens the memory trace itself. Students who read a chapter four times perform worse than students who read it once and then attempt to recall the main arguments. The act of struggling to retrieve an answer is the learning event, not a measurement of it.

Interleaving means mixing different topics or problem types inside one session. It feels harder and produces more errors during practice, but it improves discrimination between concepts and transfers better to new problems. Blocked practice, where one type is repeated many times, creates a pleasant feeling of fluency that is often mistaken for mastery.

Elaboration connects new material to what is already known. Asking why a fact is true, how it relates to an earlier idea, or what would happen if it were false forces the brain to encode more retrieval cues. A fact stored with three connections is easier to reach than a fact stored in isolation.

The illusion of fluency is the most common failure mode in self-study. Highlighting, rereading, and copying notes all increase familiarity without increasing retrieval strength. The reliable test of learning is simple: close the source and reproduce the idea from memory. If that is impossible, the material has been recognised but not learned.`;
