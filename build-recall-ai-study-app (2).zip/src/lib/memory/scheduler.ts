import {
  createEmptyCard,
  fsrs,
  generatorParameters,
  Rating,
  State,
  type Card as FsrsCard,
  type Grade,
} from "ts-fsrs";
import type { ReviewGrade } from "./types";

export type SchedulerState = {
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
  stability?: number | null;
  difficulty?: number | null;
  fsrsState?: string | null;
  scheduledDays?: number | null;
  learningSteps?: number | null;
  lastReviewedAt?: Date | null;
  dueAt?: Date | null;
};

export type ScheduleResult = {
  ease: number;
  intervalDays: number;
  reps: number;
  lapses: number;
  dueAt: Date;
  stability: number;
  difficulty: number;
  fsrsState: "new" | "learning" | "review" | "relearning";
  scheduledDays: number;
  elapsedDays: number;
  learningSteps: number;
  lastReviewedAt: Date;
};

const MAX_INTERVAL_DAYS = 365;

function stateFromName(name: string | null | undefined): State {
  switch ((name ?? "").toLowerCase()) {
    case "learning":
      return State.Learning;
    case "review":
      return State.Review;
    case "relearning":
      return State.Relearning;
    default:
      return State.New;
  }
}

function nameFromState(state: State): ScheduleResult["fsrsState"] {
  if (state === State.Learning) return "learning";
  if (state === State.Review) return "review";
  if (state === State.Relearning) return "relearning";
  return "new";
}

const GRADE_TO_RATING: Record<ReviewGrade, Grade> = {
  0: Rating.Again,
  1: Rating.Hard,
  2: Rating.Good,
  3: Rating.Easy,
};

/**
 * FSRS v5 scheduling via ts-fsrs (MIT, github.com/open-spaced-repetition/ts-fsrs).
 * Same 4-button API as the old SM-2 helper so the review UI does not change.
 * Cards created before FSRS are backfilled: difficulty ≈ 6.5 - ease,
 * stability ≈ the old interval in days.
 */
export function scheduleReview(
  state: SchedulerState,
  grade: ReviewGrade,
  now = new Date(),
  desiredRetention = 0.9,
): ScheduleResult {
  const scheduler = fsrs(
    generatorParameters({
      request_retention: Math.min(0.97, Math.max(0.7, desiredRetention)),
      maximum_interval: MAX_INTERVAL_DAYS,
      enable_fuzz: false,
      enable_short_term: true,
    }),
  );

  const legacyStability = Math.max(0.1, state.intervalDays || 0.1);
  const legacyDifficulty = Math.min(10, Math.max(1, 6.5 - (state.ease || 2.5)));
  const base: FsrsCard =
    state.reps > 0
      ? {
          due: state.dueAt ?? now,
          stability: state.stability && state.stability > 0 ? state.stability : legacyStability,
          difficulty:
            state.difficulty && state.difficulty > 0 ? state.difficulty : legacyDifficulty,
          elapsed_days: 0,
          scheduled_days: state.scheduledDays ?? state.intervalDays ?? 0,
          learning_steps: state.learningSteps ?? 0,
          reps: state.reps,
          lapses: state.lapses,
          state: stateFromName(state.fsrsState),
          last_review: state.lastReviewedAt ?? undefined,
        }
      : createEmptyCard(now);

  const item = scheduler.repeat(base, now)[GRADE_TO_RATING[grade]];
  const next = item.card;
  const scheduledDays = Math.min(MAX_INTERVAL_DAYS, Math.max(0, next.scheduled_days));
  // ts-fsrs can return a due date a couple of days past maximum_interval; clamp it.
  const hardCap = new Date(now.getTime() + MAX_INTERVAL_DAYS * 86_400_000);
  const dueAt =
    grade === 0 && next.scheduled_days === 0
      ? next.due
      : new Date(Math.min(next.due.getTime(), hardCap.getTime()));
  const ease = Math.min(3.2, Math.max(1.3, Number((6.5 - next.difficulty).toFixed(2))));

  return {
    ease,
    intervalDays: Number(scheduledDays.toFixed(2)),
    reps: next.reps,
    lapses: next.lapses,
    dueAt,
    stability: Number(next.stability.toFixed(4)),
    difficulty: Number(next.difficulty.toFixed(4)),
    fsrsState: nameFromState(next.state),
    scheduledDays: Number(scheduledDays.toFixed(2)),
    elapsedDays: Number(Math.max(0, next.elapsed_days).toFixed(2)),
    learningSteps: next.learning_steps,
    lastReviewedAt: now,
  };
}
