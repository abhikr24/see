export type CardKind = "cloze" | "definition" | "fact" | "list" | "concept" | "ai";

export type MemoryCard = {
  kind: CardKind;
  prompt: string;
  answer: string;
  hint: string;
  cloze: string | null;
  quote: string;
  page: number;
  options: string[];
  explanation: string;
  tags: string[];
};

export type Concept = {
  term: string;
  count: number;
  score: number;
  definition: string;
  page: number;
};

export type PlanDay = {
  day: number;
  focus: string;
  minutes: number;
  cardCount: number;
};

export type AnalysisStats = {
  words: number;
  sentences: number;
  pages: number;
  concepts: number;
  readingMinutes: number;
  coverage: number;
  difficulty: "Light" | "Moderate" | "Dense";
  /** Cards that passed the validator, 0-100. */
  qualityScore: number;
  generatedCards: number;
  droppedCards: number;
  topConceptsCovered: number;
};

export type Analysis = {
  engine: "rules" | "ai";
  summary: string;
  keyPoints: string[];
  concepts: Concept[];
  recallPrompts: string[];
  plan: PlanDay[];
  stats: AnalysisStats;
  warnings: string[];
  generatedAt: string;
  provider?: string;
};

export type SourceInput = {
  title: string;
  pages: string[];
};

export type AnalyzeResult = {
  analysis: Analysis;
  cards: MemoryCard[];
};

export type ReviewGrade = 0 | 1 | 2 | 3;

export const CARD_KINDS: CardKind[] = ["cloze", "definition", "fact", "list", "concept", "ai"];
