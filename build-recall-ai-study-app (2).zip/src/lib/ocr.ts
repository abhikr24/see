import { createCanvas } from "@napi-rs/canvas";

export type OcrProgress = (info: { page: number; pages: number; status: string }) => void;

export type OcrResult = { pages: string[]; pagesOcred: number; warnings: string[] };

export class OcrError extends Error {
  readonly code: "OCR_UNAVAILABLE" | "OCR_RUNTIME" | "OCR_FAILED";
  constructor(code: OcrError["code"], message: string) {
    super(message);
    this.name = "OcrError";
    this.code = code;
  }
}

const MAX_OCR_PAGES = Number(process.env.OCR_MAX_PAGES ?? 25);

export function ocrEnabled(): boolean {
  return process.env.OCR_DISABLED !== "true";
}

/** Reported by /api/health. True only when the deployment has not disabled OCR. */
export function ocrStatus(): { available: boolean; languages: string[]; maxPages: number } {
  return { available: ocrEnabled(), languages: ocrLanguages(), maxPages: MAX_OCR_PAGES };
}

export function ocrLanguages(): string[] {
  return (process.env.OCR_LANGUAGES ?? "eng")
    .split("+")
    .map((value) => value.trim())
    .filter(Boolean)
    .slice(0, 3);
}

export type OcrDeps = {
  renderPages: (
    buffer: ArrayBuffer,
    pages: number[],
  ) => Promise<{ page: number; image: Uint8Array }[]>;
  recognize: (image: Uint8Array, onProgress?: (status: string) => void) => Promise<string>;
};

/** Default renderer: pdfjs-dist rasterises each page onto an @napi-rs/canvas surface. */
async function renderPdfPages(
  buffer: ArrayBuffer,
  pageNumbers: number[],
  scale = 2,
): Promise<{ page: number; image: Uint8Array }[]> {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const pdf = await pdfjs.getDocument({
    data: new Uint8Array(buffer),
    disableFontFace: true,
    useSystemFonts: false,
  }).promise;

  const out: { page: number; image: Uint8Array }[] = [];
  try {
    for (const pageNumber of pageNumbers) {
      if (pageNumber < 1 || pageNumber > pdf.numPages) continue;
      const page = await pdf.getPage(pageNumber);
      const viewport = page.getViewport({ scale });
      const canvas = createCanvas(Math.ceil(viewport.width), Math.ceil(viewport.height));
      const context = canvas.getContext("2d");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, viewport.width, viewport.height);
      await page.render({
        canvas: canvas as unknown as HTMLCanvasElement,
        viewport,
      }).promise;
      out.push({ page: pageNumber, image: canvas.toBuffer("image/png") });
      page.cleanup();
    }
  } finally {
    // PDFDocumentProxy#destroy exists in newer builds; guard for older ones.
    const destroy = (pdf as unknown as { destroy?: () => Promise<void> }).destroy;
    if (typeof destroy === "function") await destroy.call(pdf);
  }
  return out;
}

/** Default recogniser: tesseract.js with the configured languages. */
async function recognizeWithTesseract(
  image: Uint8Array,
  onProgress?: (status: string) => void,
): Promise<string> {
  const { createWorker } = await import("tesseract.js");
  const languages = ocrLanguages().join("+");
  const worker = await createWorker(languages, 1, {
    logger: (message: { status?: string }) => {
      if (message.status) onProgress?.(message.status);
    },
  });
  try {
    const result = await worker.recognize(Buffer.from(image));
    return result.data.text ?? "";
  } finally {
    await worker.terminate();
  }
}

export const defaultOcrDeps: OcrDeps = {
  renderPages: renderPdfPages,
  recognize: recognizeWithTesseract,
};

/**
 * OCR only the pages that yielded little or no text. Never runs when the
 * deterministic text layer is good, so a text PDF never pays the OCR cost.
 */
export async function ocrPdfPages(
  buffer: ArrayBuffer,
  pageNumbers: number[],
  options: { onProgress?: OcrProgress; deps?: OcrDeps } = {},
): Promise<OcrResult> {
  if (!ocrEnabled()) {
    throw new OcrError(
      "OCR_UNAVAILABLE",
      "OCR is disabled on this deployment (OCR_DISABLED=true).",
    );
  }
  const major = Number(process.versions.node.split(".")[0]);
  if (!Number.isFinite(major) || major < 22) {
    throw new OcrError("OCR_RUNTIME", "OCR needs Node 22 or newer.");
  }
  const deps = options.deps ?? defaultOcrDeps;
  const unique = [...new Set(pageNumbers)].filter((page) => Number.isInteger(page) && page > 0);
  const capped = unique.slice(0, Math.max(0, MAX_OCR_PAGES));
  const warnings: string[] = [];
  if (unique.length > capped.length) {
    warnings.push(
      `Only the first ${capped.length} image-only page${capped.length === 1 ? "" : "s"} were read. Raise OCR_MAX_PAGES to include the rest.`,
    );
  }
  if (capped.length === 0) return { pages: [], pagesOcred: 0, warnings };

  let rendered: { page: number; image: Uint8Array }[] = [];
  try {
    rendered = await deps.renderPages(buffer, capped);
  } catch (error) {
    console.error("ocr_render_failed", error instanceof Error ? error.message : error);
    throw new OcrError("OCR_FAILED", "The scanned pages could not be rasterised for OCR.");
  }

  const pages: string[] = [];
  let pagesOcred = 0;
  for (const [index, item] of rendered.entries()) {
    options.onProgress?.({ page: item.page, pages: rendered.length, status: "reading" });
    try {
      const text = await deps.recognize(item.image, (status) =>
        options.onProgress?.({ page: item.page, pages: rendered.length, status }),
      );
      if (text.trim().length > 0) {
        pages.push(text.trim());
        pagesOcred += 1;
      } else {
        warnings.push(`OCR found no text on page ${item.page}.`);
      }
    } catch (error) {
      console.error("ocr_recognize_failed", {
        page: item.page,
        message: error instanceof Error ? error.message : error,
      });
      warnings.push(`OCR failed on page ${item.page}; that page was skipped.`);
    }
    options.onProgress?.({ page: index + 1, pages: rendered.length, status: "done" });
  }

  return { pages, pagesOcred, warnings };
}
