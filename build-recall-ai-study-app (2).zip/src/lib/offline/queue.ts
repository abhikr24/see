import type { ReviewGrade } from "@/lib/memory/types";

export type PendingReview = {
  id: string;
  cardId: string;
  grade: ReviewGrade;
  queuedAt: number;
  attempts: number;
};

export type QueueStore = {
  all(): Promise<PendingReview[]>;
  put(item: PendingReview): Promise<void>;
  delete(id: string): Promise<void>;
};

const DB_NAME = "recall-offline";
const STORE = "reviews";

/** IndexedDB store (idb, ISC). Falls back to memory when IndexedDB is missing. */
export function indexedDbStore(): QueueStore {
  let dbPromise: Promise<import("idb").IDBPDatabase<unknown>> | null = null;
  const open = async () => {
    if (!dbPromise) {
      dbPromise = import("idb").then(({ openDB }) =>
        openDB(DB_NAME, 1, {
          upgrade(db) {
            if (!db.objectStoreNames.contains(STORE))
              db.createObjectStore(STORE, { keyPath: "id" });
          },
        }),
      );
    }
    return dbPromise;
  };
  return {
    async all() {
      const db = await open();
      return (await db.getAll(STORE)) as PendingReview[];
    },
    async put(item) {
      const db = await open();
      await db.put(STORE, item);
    },
    async delete(id) {
      const db = await open();
      await db.delete(STORE, id);
    },
  };
}

export function memoryStore(initial: PendingReview[] = []): QueueStore {
  const map = new Map(initial.map((item) => [item.id, item]));
  return {
    async all() {
      return [...map.values()];
    },
    async put(item) {
      map.set(item.id, item);
    },
    async delete(id) {
      map.delete(id);
    },
  };
}

export function queueReview(
  store: QueueStore,
  input: { cardId: string; grade: ReviewGrade },
): Promise<void> {
  return store.put({
    id: `${input.cardId}:${input.grade}:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`,
    cardId: input.cardId,
    grade: input.grade,
    queuedAt: Date.now(),
    attempts: 0,
  });
}

export type FlushResult = { synced: number; failed: number; remaining: number };

/**
 * Replay queued reviews. A card id that is unknown (deleted) or rejected is
 * dropped; a network/5xx failure is kept for the next attempt.
 */
export async function flushQueue(
  store: QueueStore,
  send: (item: PendingReview) => Promise<{ ok: boolean; status: number }>,
): Promise<FlushResult> {
  const pending = await store.all();
  let synced = 0;
  let failed = 0;
  for (const item of pending) {
    try {
      const result = await send(item);
      if (result.ok || result.status === 404) {
        await store.delete(item.id);
        if (result.ok) synced += 1;
      } else {
        failed += 1;
      }
    } catch {
      failed += 1;
      if (item.attempts > 5) await store.delete(item.id);
      else await store.put({ ...item, attempts: item.attempts + 1 });
    }
  }
  const remaining = (await store.all()).length;
  return { synced, failed, remaining };
}
