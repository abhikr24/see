import { extractText, getDocumentProxy } from "unpdf";

export type PdfFailureCode = "ENCRYPTED" | "NO_TEXT_LAYER" | "RUNTIME_UNSUPPORTED" | "PARSE_FAILED";

export class PdfImportError extends Error {
  readonly code: PdfFailureCode;
  readonly status: number;
  readonly userMessage: string;

  constructor(code: PdfFailureCode, userMessage: string, status: number) {
    super(`${code}: ${userMessage}`);
    this.name = "PdfImportError";
    this.code = code;
    this.status = status;
    this.userMessage = userMessage;
  }
}

export type ExtractedPdf = {
  pages: string[];
  pageCount: number;
  warnings: string[];
  /** True when at least one page has almost no selectable text. */
  needsOcr: boolean;
  /** 1-based page numbers that produced little or no text. */
  thinPages: number[];
};

export const MIN_NODE_MAJOR = 22;
export const MIN_PAGE_CHARS = 40;

/** unpdf 1.9 uses the Iterator global, which only exists on Node 22+. */
export function assertPdfRuntime(): void {
  const major = Number(process.versions.node.split(".")[0]);
  if (!Number.isFinite(major) || major < MIN_NODE_MAJOR) {
    throw new PdfImportError(
      "RUNTIME_UNSUPPORTED",
      `PDF import needs Node ${MIN_NODE_MAJOR} or newer (this server is Node ${process.versions.node}). Upgrade Node, or paste the text instead.`,
      503,
    );
  }
}

function isEncryptedError(error: unknown): boolean {
  if (!(error instanceof Error)) return false;
  return /password|encrypt|PasswordException/i.test(`${error.name} ${error.message}`);
}

/**
 * Text-layer extraction. A page with fewer than MIN_PAGE_CHARS is reported as
 * "thin" so the caller can hand it to OCR; we never invent text and we never
 * treat a scan as a broken PDF.
 */
export async function extractPdfPages(buffer: ArrayBuffer): Promise<ExtractedPdf> {
  assertPdfRuntime();
  try {
    const pdf = await getDocumentProxy(new Uint8Array(buffer));
    const result = await extractText(pdf, { mergePages: false });
    const rawPages = Array.isArray(result.text) ? result.text : [String(result.text ?? "")];
    const pages = rawPages.map((page) => page ?? "");
    const thinPages = pages
      .map((page, index) => ({ index: index + 1, chars: page.trim().length }))
      .filter((entry) => entry.chars < MIN_PAGE_CHARS)
      .map((entry) => entry.index);
    const totalChars = pages.join("").trim().length;

    if (totalChars < 40) {
      throw new PdfImportError(
        "NO_TEXT_LAYER",
        "This PDF has no selectable text — it looks like a scan. OCR is available on this deployment: upload it again with OCR enabled, or paste the text.",
        422,
      );
    }

    const warnings: string[] = [];
    if (thinPages.length > 0) {
      warnings.push(
        `${thinPages.length} page${thinPages.length === 1 ? " has" : "s have"} almost no selectable text. Those pages were skipped; OCR can read them if enabled.`,
      );
    }

    return {
      pages,
      pageCount: result.totalPages || pages.length,
      warnings,
      needsOcr: thinPages.length > 0,
      thinPages,
    };
  } catch (error) {
    if (error instanceof PdfImportError) throw error;
    if (isEncryptedError(error)) {
      throw new PdfImportError(
        "ENCRYPTED",
        "This PDF is password-protected. Remove the password (or export an unlocked copy) and upload it again.",
        422,
      );
    }
    throw new PdfImportError(
      "PARSE_FAILED",
      "This PDF could not be parsed. Re-export it from the original app, or paste the text instead.",
      422,
    );
  }
}

export type PdfWithOcr = {
  pages: string[];
  pageCount: number;
  warnings: string[];
  ocr: boolean;
  pagesOcred: number;
};

/**
 * Text layer first; OCR only fills pages that produced no text. A scanned PDF
 * therefore yields a usable deck, while a text PDF never invokes OCR at all.
 */
export async function extractPdfWithOcr(
  buffer: ArrayBuffer,
  options: {
    enableOcr?: boolean;
    onProgress?: (info: { page: number; pages: number; status: string }) => void;
  } = {},
): Promise<PdfWithOcr> {
  const { ocrEnabled, ocrPdfPages, OcrError } = await import("@/lib/ocr");
  const enableOcr = (options.enableOcr ?? true) && ocrEnabled();

  let base: ExtractedPdf | null = null;
  let textError: PdfImportError | null = null;
  try {
    base = await extractPdfPages(buffer);
  } catch (error) {
    if (!(error instanceof PdfImportError) || error.code !== "NO_TEXT_LAYER") throw error;
    textError = error;
  }

  const needsOcr = textError !== null || (base?.thinPages.length ?? 0) > 0;
  if (!needsOcr) {
    return {
      pages: base?.pages ?? [],
      pageCount: base?.pageCount ?? 0,
      warnings: base?.warnings ?? [],
      ocr: false,
      pagesOcred: 0,
    };
  }

  if (!enableOcr) {
    if (textError) throw textError;
    return {
      pages: base?.pages ?? [],
      pageCount: base?.pageCount ?? 0,
      warnings: base?.warnings ?? [],
      ocr: false,
      pagesOcred: 0,
    };
  }

  const targetPages =
    base && base.thinPages.length > 0
      ? base.thinPages
      : Array.from({ length: base?.pageCount ?? 1 }, (_, index) => index + 1);

  try {
    const ocr = await ocrPdfPages(buffer, targetPages, { onProgress: options.onProgress });
    const pages = [...(base?.pages ?? targetPages.map(() => ""))];
    let offset = 0;
    for (const pageNumber of targetPages) {
      if (ocr.pages[offset] !== undefined) {
        pages[pageNumber - 1] = ocr.pages[offset];
        offset += 1;
      }
    }
    const warnings = [...(base?.warnings ?? []), ...ocr.warnings];
    if (ocr.pagesOcred > 0) {
      warnings.unshift(
        `OCR read ${ocr.pagesOcred} scanned page${ocr.pagesOcred === 1 ? "" : "s"} (${ocrLanguagesLabel()}). Check the source text — recognition is good but not perfect.`,
      );
    } else {
      warnings.push(
        "OCR ran but found no readable text. This PDF may be blank or too low-resolution to read.",
      );
    }
    return {
      pages,
      pageCount: base?.pageCount ?? pages.length,
      warnings,
      ocr: ocr.pagesOcred > 0,
      pagesOcred: ocr.pagesOcred,
    };
  } catch (error) {
    if (error instanceof OcrError) {
      if (textError) {
        throw new PdfImportError(
          "NO_TEXT_LAYER",
          `${textError.userMessage} OCR could not help: ${error.message}`,
          422,
        );
      }
      return {
        pages: base?.pages ?? [],
        pageCount: base?.pageCount ?? 0,
        warnings: [...(base?.warnings ?? []), `OCR was unavailable: ${error.message}`],
        ocr: false,
        pagesOcred: 0,
      };
    }
    throw error;
  }
}

function ocrLanguagesLabel(): string {
  const languages = (process.env.OCR_LANGUAGES ?? "eng").split("+").join(", ");
  return languages;
}
