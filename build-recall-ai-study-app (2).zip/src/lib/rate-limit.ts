import { sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";

export type RateRuleName =
  "login" | "signup" | "password_reset" | "upload" | "ai_generate" | "export";

export const RATE_RULES: Record<RateRuleName, { limit: number; windowMs: number; label: string }> =
  {
    login: { limit: 5, windowMs: 60_000, label: "sign-in attempts" },
    signup: { limit: 3, windowMs: 3_600_000, label: "sign-ups" },
    password_reset: { limit: 3, windowMs: 3_600_000, label: "password resets" },
    upload: { limit: 30, windowMs: 3_600_000, label: "uploads" },
    ai_generate: { limit: 20, windowMs: 3_600_000, label: "AI generations" },
    export: { limit: 60, windowMs: 3_600_000, label: "exports" },
  };

export type RateLimitResult = {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds: number;
  limit: number;
};

export function clientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  return request.headers.get("x-real-ip")?.trim() || "unknown";
}

/**
 * Fixed-window limiter stored in Postgres so there is no extra service to run.
 * A single upsert makes the increment atomic under concurrency.
 */
export async function consumeRateLimit(
  rule: RateRuleName,
  identifier: string,
): Promise<RateLimitResult> {
  // Explicit, documented test-only bypass. The E2E suite signs in many times in
  // one minute from a single IP; production deployments never set this.
  if (process.env.RATE_LIMIT_BYPASS === "true") {
    return {
      allowed: true,
      remaining: RATE_RULES[rule].limit,
      retryAfterSeconds: 0,
      limit: RATE_RULES[rule].limit,
    };
  }

  const { limit, windowMs } = RATE_RULES[rule];
  const key = `${rule}:${identifier}`.slice(0, 200);

  try {
    const result = await db.execute(sql`
      INSERT INTO rate_limits (key, points, expires_at)
      VALUES (${key}, 1, now() + (${windowMs} * interval '1 millisecond'))
      ON CONFLICT (key) DO UPDATE SET
        points = CASE WHEN rate_limits.expires_at <= now() THEN 1 ELSE rate_limits.points + 1 END,
        expires_at = CASE
          WHEN rate_limits.expires_at <= now() THEN excluded.expires_at
          ELSE rate_limits.expires_at
        END
      RETURNING points, expires_at
    `);
    const row = (result.rows?.[0] ?? {}) as { points?: number; expires_at?: string | Date };
    const points = Number(row.points ?? limit + 1);
    const expiresAt = row.expires_at ? new Date(row.expires_at) : new Date(Date.now() + windowMs);
    const retryAfterSeconds = Math.max(1, Math.ceil((expiresAt.getTime() - Date.now()) / 1000));

    return {
      allowed: points <= limit,
      remaining: Math.max(0, limit - points),
      retryAfterSeconds,
      limit,
    };
  } catch (error) {
    // Never let a limiter outage take the product down: log and allow.
    console.error("rate_limit_unavailable", {
      rule,
      message: error instanceof Error ? error.message : "unknown",
    });
    return { allowed: true, remaining: limit, retryAfterSeconds: 0, limit };
  }
}

export function rateLimitResponse(rule: RateRuleName, result: RateLimitResult): NextResponse {
  const { label } = RATE_RULES[rule];
  return NextResponse.json(
    {
      error: `Too many ${label}. Try again in ${formatRetry(result.retryAfterSeconds)}.`,
      code: "RATE_LIMITED",
    },
    {
      status: 429,
      headers: {
        "Retry-After": String(result.retryAfterSeconds),
        "X-RateLimit-Limit": String(result.limit),
        "X-RateLimit-Remaining": "0",
      },
    },
  );
}

function formatRetry(seconds: number): string {
  if (seconds < 90) return `${seconds} second${seconds === 1 ? "" : "s"}`;
  const minutes = Math.ceil(seconds / 60);
  return `${minutes} minute${minutes === 1 ? "" : "s"}`;
}
