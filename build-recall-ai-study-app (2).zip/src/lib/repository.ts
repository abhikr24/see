import { and, desc, eq, gte, ilike, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  aiEvents,
  cards,
  documents,
  quizAttempts,
  reviews,
  stripeEvents,
  subscriptions,
  users,
  type CardRow,
  type QuizQuestionResult,
  type UserRow,
} from "@/db/schema";
import { analyzeSource, hashString } from "@/lib/memory/engine";
import { scheduleReview } from "@/lib/memory/scheduler";
import type { Analysis, MemoryCard, ReviewGrade } from "@/lib/memory/types";
import { SAMPLE_TEXT, SAMPLE_TITLE } from "@/lib/memory/sample";
import { hashPassword } from "@/lib/auth/password";

export type SourceType = "pdf" | "txt" | "paste";

export type AiMeta = {
  provider: string;
  model: string;
  tokens: number;
  inputTokens: number;
  outputTokens: number;
  costUsd: number;
};

export type NewSourceInput = {
  userId: string;
  title: string;
  sourceType: SourceType;
  fileName?: string | null;
  pages: string[];
  /** Engine the user requested. Stored separately from the engine that ran. */
  engine: "rules" | "ai";
  cardCount?: number;
  ocr?: boolean;
  aiOverlay?: {
    cards: MemoryCard[];
    analysis: Analysis;
    provider: string;
  } | null;
  aiMeta?: AiMeta | null;
};

function fillOptions(cards: MemoryCard[]): MemoryCard[] {
  const pool = cards.map((card) => card.answer).filter((answer) => answer.length > 1);
  return cards.map((card, index) => {
    if (card.options.length >= 4) return card;
    const seen = new Set([card.answer.toLowerCase()]);
    const options: string[] = [card.answer];
    const candidates = [...pool.slice(index + 1), ...pool.slice(0, index)];
    for (const candidate of candidates) {
      const candidateKey = candidate.toLowerCase();
      if (seen.has(candidateKey) || candidateKey.includes(card.answer.toLowerCase())) continue;
      seen.add(candidateKey);
      options.push(candidate);
      if (options.length === 4) break;
    }
    const filler = ["Not stated in the source", "The opposite is true", "None of these"];
    let fillerIndex = 0;
    while (options.length < 4) {
      options.push(filler[fillerIndex % filler.length]);
      fillerIndex += 1;
    }
    const rotation = hashString(card.answer) % 4;
    return { ...card, options: [...options.slice(rotation), ...options.slice(0, rotation)] };
  });
}

export async function createSource(input: NewSourceInput) {
  const base = analyzeSource({ title: input.title, pages: input.pages });
  const aiCards = input.aiOverlay?.cards ?? [];
  const usedCards = input.aiOverlay && aiCards.length > 0 ? aiCards : base.cards;
  const analysis = input.aiOverlay?.analysis ?? base.analysis;
  // T8: store the engine that actually ran, never the one that was requested.
  const actualEngine: "rules" | "ai" = input.aiOverlay && aiCards.length > 0 ? "ai" : "rules";
  const finalAnalysis: Analysis = {
    ...analysis,
    engine: actualEngine,
    warnings: [
      ...base.analysis.warnings,
      ...analysis.warnings.filter((warning) => !base.analysis.warnings.includes(warning)),
    ],
    stats: {
      ...base.analysis.stats,
      ...analysis.stats,
    },
  };

  const docRows = await db
    .insert(documents)
    .values({
      userId: input.userId,
      title: input.title,
      sourceType: input.sourceType,
      fileName: input.fileName ?? null,
      pageCount: base.analysis.stats.pages,
      wordCount: base.analysis.stats.words,
      engine: actualEngine,
      requestedEngine: input.engine,
      ocr: input.ocr ?? false,
      qualityScore: base.analysis.stats.qualityScore,
      rawText: input.pages.join("\n\n").slice(0, 400_000),
      analysis: finalAnalysis,
    })
    .returning();
  const doc = docRows[0];
  if (!doc) throw new Error("Could not save the document.");

  const filled = fillOptions(usedCards);
  if (filled.length > 0) {
    await db.insert(cards).values(
      filled.map((card, index) => ({
        documentId: doc.id,
        userId: input.userId,
        kind: card.kind,
        prompt: card.prompt,
        answer: card.answer,
        hint: card.hint,
        cloze: card.cloze,
        quote: card.quote,
        page: card.page,
        options: card.options,
        explanation: card.explanation,
        tags: card.tags,
        position: index,
        dueAt: new Date(),
      })),
    );
  }

  if (input.aiMeta) {
    await db.insert(aiEvents).values({
      userId: input.userId,
      documentId: doc.id,
      provider: input.aiMeta.provider,
      model: input.aiMeta.model,
      credits: 1,
      tokens: input.aiMeta.tokens,
      inputTokens: input.aiMeta.inputTokens,
      outputTokens: input.aiMeta.outputTokens,
      costUsd: input.aiMeta.costUsd,
      status: "ok",
    });
    // Credits are charged only after a successful generation.
    await db
      .update(users)
      .set({ aiCredits: sql`greatest(${users.aiCredits} - 1, 0)` })
      .where(eq(users.id, input.userId));
  }

  return doc;
}

export async function recordAiFailure(input: {
  userId: string;
  provider: string;
  model: string;
  code: string;
}) {
  await db.insert(aiEvents).values({
    userId: input.userId,
    provider: input.provider,
    model: input.model,
    credits: 0,
    tokens: 0,
    status: `failed:${input.code}`,
  });
}

export type DocumentSummary = {
  id: string;
  title: string;
  engine: string;
  requestedEngine: string;
  sourceType: string;
  pageCount: number;
  wordCount: number;
  qualityScore: number;
  createdAt: Date;
  totalCards: number;
  dueCards: number;
  mastered: number;
  flaggedCards: number;
};

export async function listDocuments(userId: string): Promise<DocumentSummary[]> {
  const rows = await db
    .select({
      id: documents.id,
      title: documents.title,
      engine: documents.engine,
      requestedEngine: documents.requestedEngine,
      sourceType: documents.sourceType,
      pageCount: documents.pageCount,
      wordCount: documents.wordCount,
      qualityScore: documents.qualityScore,
      createdAt: documents.createdAt,
      totalCards: sql<number>`count(${cards.id})::int`,
      dueCards: sql<number>`count(case when ${cards.dueAt} <= now() and ${cards.suspended} = false then 1 end)::int`,
      mastered: sql<number>`count(case when ${cards.reps} >= 2 and ${cards.intervalDays} >= 3 then 1 end)::int`,
      flaggedCards: sql<number>`count(case when ${cards.flagged} then 1 end)::int`,
    })
    .from(documents)
    .leftJoin(cards, eq(cards.documentId, documents.id))
    .where(eq(documents.userId, userId))
    .groupBy(documents.id)
    .orderBy(desc(documents.createdAt));
  return rows;
}

export type ActivityDay = { date: string; count: number };

export async function getActivity(userId: string, days = 30): Promise<ActivityDay[]> {
  const since = new Date(Date.now() - (days - 1) * 86_400_000);
  since.setUTCHours(0, 0, 0, 0);
  const rows = await db
    .select({
      date: sql<string>`to_char(${reviews.reviewedAt}, 'YYYY-MM-DD')`,
      count: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(and(eq(reviews.userId, userId), gte(reviews.reviewedAt, since)))
    .groupBy(sql`to_char(${reviews.reviewedAt}, 'YYYY-MM-DD')`);

  const byDate = new Map(rows.map((row) => [row.date, row.count]));
  return Array.from({ length: days }, (_, index) => {
    const date = new Date(since.getTime() + index * 86_400_000).toISOString().slice(0, 10);
    return { date, count: byDate.get(date) ?? 0 };
  });
}

export async function getDashboard(userId: string) {
  const [counts] = await db
    .select({
      totalCards: sql<number>`count(*)::int`,
      dueCards: sql<number>`count(case when ${cards.dueAt} <= now() and ${cards.suspended} = false then 1 end)::int`,
      mastered: sql<number>`count(case when ${cards.reps} >= 2 and ${cards.intervalDays} >= 3 then 1 end)::int`,
      newCards: sql<number>`count(case when ${cards.reps} = 0 then 1 end)::int`,
      suspended: sql<number>`count(case when ${cards.suspended} then 1 end)::int`,
      flagged: sql<number>`count(case when ${cards.flagged} then 1 end)::int`,
    })
    .from(cards)
    .where(eq(cards.userId, userId));

  const [docCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(documents)
    .where(eq(documents.userId, userId));

  const [week] = await db
    .select({
      reviews: sql<number>`count(*)::int`,
      remembered: sql<number>`count(case when ${reviews.grade} >= 2 then 1 end)::int`,
    })
    .from(reviews)
    .where(
      and(eq(reviews.userId, userId), gte(reviews.reviewedAt, new Date(Date.now() - 7 * 86400000))),
    );

  const recentQuiz = await db
    .select()
    .from(quizAttempts)
    .where(eq(quizAttempts.userId, userId))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(3);

  const activity = await getActivity(userId);

  return {
    documents: docCount?.count ?? 0,
    totalCards: counts?.totalCards ?? 0,
    dueCards: counts?.dueCards ?? 0,
    newCards: counts?.newCards ?? 0,
    mastered: counts?.mastered ?? 0,
    suspended: counts?.suspended ?? 0,
    flagged: counts?.flagged ?? 0,
    reviewsThisWeek: week?.reviews ?? 0,
    retentionThisWeek:
      week && week.reviews > 0 ? Math.round((week.remembered / week.reviews) * 100) : null,
    recentQuiz,
    activity,
  };
}

export async function getDocument(userId: string, id: string) {
  const rows = await db
    .select()
    .from(documents)
    .where(and(eq(documents.id, id), eq(documents.userId, userId)))
    .limit(1);
  return rows[0] ?? null;
}

export type CardFilters = {
  kind?: string;
  page?: number;
  tag?: string;
  due?: boolean;
  flagged?: boolean;
  search?: string;
  includeSuspended?: boolean;
};

/** Server-side filter — the browser never downloads the whole deck to filter it. */
export async function getDocumentCards(
  userId: string,
  documentId: string,
  filters: CardFilters = {},
) {
  const conditions = [eq(cards.documentId, documentId), eq(cards.userId, userId)];
  if (filters.kind && filters.kind !== "all") conditions.push(eq(cards.kind, filters.kind));
  if (filters.page && Number.isFinite(filters.page)) conditions.push(eq(cards.page, filters.page));
  if (filters.flagged) conditions.push(eq(cards.flagged, true));
  if (filters.due) conditions.push(lte(cards.dueAt, new Date()));
  if (!filters.includeSuspended) conditions.push(eq(cards.suspended, false));
  if (filters.tag) {
    conditions.push(sql`${cards.tags} @> ${JSON.stringify([filters.tag])}::jsonb`);
  }
  if (filters.search) {
    const pattern = `%${filters.search.replace(/[%_]/g, "")}%`;
    const search = or(ilike(cards.prompt, pattern), ilike(cards.answer, pattern));
    if (search) conditions.push(search);
  }
  return db
    .select()
    .from(cards)
    .where(and(...conditions))
    .orderBy(cards.position, cards.createdAt);
}

export async function getDueQueue(userId: string, limit = 25, documentId?: string) {
  const conditions = [
    eq(cards.userId, userId),
    lte(cards.dueAt, new Date()),
    eq(cards.suspended, false),
  ];
  if (documentId) conditions.push(eq(cards.documentId, documentId));
  return db
    .select({ card: cards, documentTitle: documents.title })
    .from(cards)
    .innerJoin(documents, eq(documents.id, cards.documentId))
    .where(and(...conditions))
    .orderBy(cards.dueAt)
    .limit(limit);
}

export async function getCard(userId: string, cardId: string): Promise<CardRow | null> {
  const rows = await db
    .select()
    .from(cards)
    .where(and(eq(cards.id, cardId), eq(cards.userId, userId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function reviewCard(userId: string, cardId: string, grade: ReviewGrade, seconds = 0) {
  const card = await getCard(userId, cardId);
  if (!card) return null;

  const [account] = await db
    .select({ retention: users.desiredRetention })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  const next = scheduleReview(
    {
      ease: card.ease,
      intervalDays: card.intervalDays,
      reps: card.reps,
      lapses: card.lapses,
      stability: card.stability,
      difficulty: card.difficulty,
      fsrsState: card.fsrsState,
      scheduledDays: card.scheduledDays,
      learningSteps: card.learningSteps,
      lastReviewedAt: card.lastReviewedAt,
      dueAt: card.dueAt,
    },
    grade,
    new Date(),
    account?.retention ?? 0.9,
  );

  await db
    .update(cards)
    .set({
      ease: next.ease,
      intervalDays: next.intervalDays,
      reps: next.reps,
      lapses: next.lapses,
      dueAt: next.dueAt,
      lastReviewedAt: next.lastReviewedAt,
      stability: next.stability,
      difficulty: next.difficulty,
      fsrsState: next.fsrsState,
      scheduledDays: next.scheduledDays,
      elapsedDays: next.elapsedDays,
      learningSteps: next.learningSteps,
    })
    .where(and(eq(cards.id, card.id), eq(cards.userId, userId)));

  await db.insert(reviews).values({
    cardId: card.id,
    userId,
    documentId: card.documentId,
    grade,
    intervalDays: next.intervalDays,
  });

  await touchStreak(userId);

  return { ...next, seconds };
}

export async function touchStreak(userId: string) {
  const today = new Date().toISOString().slice(0, 10);
  const rows = await db
    .select({ streak: users.streak, lastStudiedOn: users.lastStudiedOn })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  const row = rows[0];
  if (!row) return;
  if (row.lastStudiedOn === today) return;
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const streak = row.lastStudiedOn === yesterday ? row.streak + 1 : 1;
  await db.update(users).set({ streak, lastStudiedOn: today }).where(eq(users.id, userId));
}

export async function recordQuizAttempt(
  userId: string,
  documentId: string,
  results: QuizQuestionResult[],
) {
  const total = results.length;
  const score = results.filter((result) => result.correct).length;
  const rows = await db
    .insert(quizAttempts)
    .values({ userId, documentId, score, total, results })
    .returning();
  await touchStreak(userId);
  return rows[0] ?? null;
}

export async function deleteDocument(userId: string, id: string): Promise<boolean> {
  const rows = await db
    .delete(documents)
    .where(and(eq(documents.id, id), eq(documents.userId, userId)))
    .returning({ id: documents.id });
  return rows.length > 0;
}

export type CardUpdate = {
  prompt?: string;
  answer?: string;
  hint?: string;
  tags?: string[];
  suspended?: boolean;
  flagged?: boolean;
  flagNote?: string;
};

export async function updateCard(
  userId: string,
  cardId: string,
  update: CardUpdate,
): Promise<CardRow | null> {
  const patch: Record<string, unknown> = {};
  if (update.prompt !== undefined) patch.prompt = update.prompt;
  if (update.answer !== undefined) patch.answer = update.answer;
  if (update.hint !== undefined) patch.hint = update.hint;
  if (update.tags !== undefined) patch.tags = update.tags;
  if (update.suspended !== undefined) patch.suspended = update.suspended;
  if (update.flagged !== undefined) patch.flagged = update.flagged;
  if (update.flagNote !== undefined) patch.flagNote = update.flagNote.slice(0, 300);
  if (Object.keys(patch).length === 0) return getCard(userId, cardId);

  const rows = await db
    .update(cards)
    .set(patch)
    .where(and(eq(cards.id, cardId), eq(cards.userId, userId)))
    .returning();
  const row = rows[0] ?? null;
  if (row && update.flagged !== undefined) {
    await refreshFlagCount(userId, row.documentId);
  }
  return row;
}

export async function deleteCard(userId: string, cardId: string): Promise<boolean> {
  const rows = await db
    .delete(cards)
    .where(and(eq(cards.id, cardId), eq(cards.userId, userId)))
    .returning({ id: cards.id, documentId: cards.documentId });
  const row = rows[0];
  if (!row) return false;
  await refreshFlagCount(userId, row.documentId);
  return true;
}

export async function refreshFlagCount(userId: string, documentId: string) {
  const [counted] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(cards)
    .where(
      and(eq(cards.userId, userId), eq(cards.documentId, documentId), eq(cards.flagged, true)),
    );
  await db
    .update(documents)
    .set({ flaggedCards: counted?.count ?? 0 })
    .where(and(eq(documents.id, documentId), eq(documents.userId, userId)));
}

export async function addCard(
  userId: string,
  documentId: string,
  input: { prompt: string; answer: string; hint?: string; tags?: string[]; page?: number },
): Promise<CardRow | null> {
  const doc = await getDocument(userId, documentId);
  if (!doc) return null;
  const [last] = await db
    .select({ position: sql<number>`coalesce(max(${cards.position}), -1)::int` })
    .from(cards)
    .where(and(eq(cards.userId, userId), eq(cards.documentId, documentId)));
  const rows = await db
    .insert(cards)
    .values({
      documentId,
      userId,
      kind: "ai",
      prompt: input.prompt,
      answer: input.answer,
      hint: input.hint ?? "",
      page: input.page && input.page > 0 ? input.page : 1,
      tags: input.tags ?? [],
      explanation: "Added by hand in Recall.",
      position: (last?.position ?? -1) + 1,
      dueAt: new Date(),
    })
    .returning();
  return rows[0] ?? null;
}

export async function reorderCards(
  userId: string,
  documentId: string,
  order: string[],
): Promise<boolean> {
  if (order.length === 0) return false;
  const owned = await db
    .select({ id: cards.id })
    .from(cards)
    .where(and(eq(cards.userId, userId), eq(cards.documentId, documentId)));
  const ownedIds = new Set(owned.map((row) => row.id));
  if (!order.every((id) => ownedIds.has(id))) return false;

  await db.transaction(async (tx) => {
    for (const [index, id] of order.entries()) {
      await tx
        .update(cards)
        .set({ position: index })
        .where(and(eq(cards.id, id), eq(cards.userId, userId)));
    }
  });
  return true;
}

export async function getUserSettings(userId: string) {
  const rows = await db
    .select({
      desiredRetention: users.desiredRetention,
      plan: users.plan,
      aiCredits: users.aiCredits,
      creditsResetAt: users.creditsResetAt,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  return rows[0] ?? null;
}

export async function updateUserSettings(userId: string, input: { desiredRetention: number }) {
  const rows = await db
    .update(users)
    .set({ desiredRetention: input.desiredRetention })
    .where(eq(users.id, userId))
    .returning({ desiredRetention: users.desiredRetention });
  return rows[0] ?? null;
}

export async function activateDemoPro(userId: string, credits = 40) {
  const safeCredits = Math.max(5, Math.min(100, Math.floor(credits)));
  const rows = await db
    .update(users)
    .set({
      plan: "pro",
      aiCredits: sql`${users.aiCredits} + ${safeCredits}`,
      creditsResetAt: new Date(),
    })
    .where(eq(users.id, userId))
    .returning();
  return rows[0] ?? null;
}

export async function getRecentAiEvents(userId: string, limit = 4) {
  return db
    .select()
    .from(aiEvents)
    .where(eq(aiEvents.userId, userId))
    .orderBy(desc(aiEvents.createdAt))
    .limit(limit);
}

export async function getAiSpendThisMonth(userId: string) {
  const monthStart = new Date();
  monthStart.setUTCDate(1);
  monthStart.setUTCHours(0, 0, 0, 0);
  const [row] = await db
    .select({
      events: sql<number>`count(*)::int`,
      tokens: sql<number>`coalesce(sum(${aiEvents.tokens}), 0)::int`,
      costUsd: sql<number>`coalesce(sum(${aiEvents.costUsd}), 0)::float`,
      failed: sql<number>`count(case when ${aiEvents.status} <> 'ok' then 1 end)::int`,
    })
    .from(aiEvents)
    .where(and(eq(aiEvents.userId, userId), gte(aiEvents.createdAt, monthStart)));
  return row ?? { events: 0, tokens: 0, costUsd: 0, failed: 0 };
}

/* ------------------------------------------------------------------ */
/* Billing                                                              */
/* ------------------------------------------------------------------ */

export async function getSubscription(userId: string) {
  const rows = await db
    .select()
    .from(subscriptions)
    .where(eq(subscriptions.userId, userId))
    .orderBy(desc(subscriptions.updatedAt))
    .limit(1);
  return rows[0] ?? null;
}

/** Returns false when this Stripe event id was already processed. */
export async function claimStripeEvent(eventId: string, type: string): Promise<boolean> {
  const inserted = await db
    .insert(stripeEvents)
    .values({ id: eventId, type })
    .onConflictDoNothing()
    .returning({ id: stripeEvents.id });
  return inserted.length > 0;
}

export async function setStripeCustomer(userId: string, customerId: string) {
  await db.update(users).set({ stripeCustomerId: customerId }).where(eq(users.id, userId));
}

export async function upgradeUser(userId: string, credits: number) {
  await db
    .update(users)
    .set({
      plan: "pro",
      aiCredits: credits,
      creditsResetAt: new Date(),
    })
    .where(eq(users.id, userId));
}

export async function renewUserCredits(userId: string, credits: number) {
  await db
    .update(users)
    .set({ aiCredits: credits, creditsResetAt: new Date(), plan: "pro" })
    .where(eq(users.id, userId));
}

export async function downgradeUser(userId: string) {
  await db.update(users).set({ plan: "free", aiCredits: 0 }).where(eq(users.id, userId));
}

export async function saveSubscription(input: {
  userId: string;
  stripeCustomerId: string;
  stripeSubscriptionId: string;
  status: string;
  priceId?: string;
  currency?: string;
  currentPeriodEnd?: Date | null;
  cancelAtPeriodEnd?: boolean;
}) {
  const rows = await db
    .insert(subscriptions)
    .values({
      userId: input.userId,
      stripeCustomerId: input.stripeCustomerId,
      stripeSubscriptionId: input.stripeSubscriptionId,
      status: input.status,
      priceId: input.priceId ?? "",
      currency: input.currency ?? "inr",
      currentPeriodEnd: input.currentPeriodEnd ?? null,
      cancelAtPeriodEnd: input.cancelAtPeriodEnd ?? false,
    })
    .onConflictDoUpdate({
      target: subscriptions.stripeSubscriptionId,
      set: {
        status: input.status,
        priceId: input.priceId ?? "",
        currency: input.currency ?? "inr",
        currentPeriodEnd: input.currentPeriodEnd ?? null,
        cancelAtPeriodEnd: input.cancelAtPeriodEnd ?? false,
        updatedAt: new Date(),
      },
    })
    .returning();
  return rows[0] ?? null;
}

export async function findUserIdByCustomer(customerId: string): Promise<string | null> {
  const rows = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.stripeCustomerId, customerId))
    .limit(1);
  return rows[0]?.id ?? null;
}

export async function addImportedCards(
  userId: string,
  documentId: string,
  incoming: MemoryCard[],
): Promise<{ imported: number; skipped: number }> {
  const doc = await getDocument(userId, documentId);
  if (!doc) return { imported: 0, skipped: incoming.length };

  const existing = await db
    .select({ prompt: cards.prompt, answer: cards.answer })
    .from(cards)
    .where(and(eq(cards.userId, userId), eq(cards.documentId, documentId)));
  const seen = new Set(
    existing.map((row) => `${row.prompt.toLowerCase()}::${row.answer.toLowerCase()}`),
  );

  const [max] = await db
    .select({ position: sql<number>`coalesce(max(${cards.position}), -1)::int` })
    .from(cards)
    .where(and(eq(cards.userId, userId), eq(cards.documentId, documentId)));
  let position = (max?.position ?? -1) + 1;

  const values: (typeof cards.$inferInsert)[] = [];
  for (const card of incoming) {
    const key = `${card.prompt.toLowerCase()}::${card.answer.toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    values.push({
      documentId,
      userId,
      kind: card.kind,
      prompt: card.prompt,
      answer: card.answer,
      hint: card.hint,
      cloze: card.cloze,
      quote: card.quote,
      page: card.page,
      options: card.options,
      explanation: card.explanation,
      tags: card.tags,
      position: position++,
      dueAt: new Date(),
    });
    if (values.length >= 500) break;
  }

  if (values.length > 0) await db.insert(cards).values(values);
  return { imported: values.length, skipped: incoming.length - values.length };
}

/* ------------------------------------------------------------------ */
/* Demo account bootstrap — idempotent, safe to call on any page       */
/* ------------------------------------------------------------------ */

export const DEMO_EMAIL = "demo@recall.studio";
export const DEMO_PASSWORD = "recall1234";

let seedPromise: Promise<void> | null = null;

async function seedDemo() {
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, DEMO_EMAIL))
    .limit(1);
  if (existing[0]) return;

  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const inserted = await db
    .insert(users)
    .values({
      email: DEMO_EMAIL,
      name: "Demo Learner",
      passwordHash,
      plan: "free",
      aiCredits: 0,
      streak: 3,
      lastStudiedOn: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
    })
    .onConflictDoNothing()
    .returning();
  const demo = inserted[0];
  if (!demo) return;

  const source = analyzeSource({ title: SAMPLE_TITLE, pages: [SAMPLE_TEXT] });
  const docRows = await db
    .insert(documents)
    .values({
      userId: demo.id,
      title: SAMPLE_TITLE,
      sourceType: "paste",
      fileName: "memory-science.md",
      pageCount: source.analysis.stats.pages,
      wordCount: source.analysis.stats.words,
      engine: "rules",
      requestedEngine: "rules",
      qualityScore: source.analysis.stats.qualityScore,
      rawText: SAMPLE_TEXT,
      analysis: source.analysis,
    })
    .returning();
  const doc = docRows[0];
  if (!doc) return;

  const filled = fillOptions(source.cards);
  await db.insert(cards).values(
    filled.map((card, index) => {
      const reviewed = index % 4 === 0;
      const dueOffset = index % 5 === 0 ? -60 * 60 * 1000 : index * 45 * 1000;
      return {
        documentId: doc.id,
        userId: demo.id,
        kind: card.kind,
        prompt: card.prompt,
        answer: card.answer,
        hint: card.hint,
        cloze: card.cloze,
        quote: card.quote,
        page: card.page,
        options: card.options,
        explanation: card.explanation,
        tags: card.tags,
        position: index,
        ease: reviewed ? 2.65 : 2.5,
        intervalDays: reviewed ? 3 : 0,
        reps: reviewed ? 2 : 0,
        dueAt: new Date(Date.now() + dueOffset),
        lastReviewedAt: reviewed ? new Date(Date.now() - 86400000) : null,
      };
    }),
  );

  await db.insert(quizAttempts).values({
    userId: demo.id,
    documentId: doc.id,
    score: 4,
    total: 6,
    results: [],
  });
}

/** Called by public pages; never throws into render. */
export function ensureDemoSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedDemo().catch((error) => {
      seedPromise = null;
      console.error("Demo seed skipped:", error instanceof Error ? error.message : error);
    });
  }
  return seedPromise;
}

export type DemoUser = UserRow;
