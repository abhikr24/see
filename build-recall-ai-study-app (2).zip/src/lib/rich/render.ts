import katex from "katex";
import sanitizeHtml from "sanitize-html";

const MATH_PATTERN = /\$\$([^$]{1,400})\$\$|\\\(([^)]{1,400})\\\)|\$([^$\n]{1,200})\$/g;

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderMath(source: string, displayMode: boolean): string | null {
  try {
    return katex.renderToString(source, {
      displayMode,
      throwOnError: false,
      strict: false,
      output: "html",
      trust: false,
    });
  } catch {
    return null;
  }
}

/**
 * Server-side rich text: strips every tag from untrusted text (AI output, pasted
 * HTML), then renders $…$, $$…$$ and \(…\) spans with KaTeX. The result is the
 * only HTML we ever put in dangerouslySetInnerHTML, and it is generated here
 * rather than in the browser so KaTeX stays out of the client bundle.
 */
export function renderRichText(input: string): string {
  const safe = sanitizeHtml(input, { allowedTags: [], allowedAttributes: {} });
  const withNewlines = safe.replace(/\r?\n/g, "\n");
  let html = "";
  let lastIndex = 0;
  for (const match of withNewlines.matchAll(MATH_PATTERN)) {
    const index = match.index ?? 0;
    html += escapeHtml(withNewlines.slice(lastIndex, index)).replace(/\n/g, "<br>");
    const [raw, block, paren, inline] = match;
    const rendered = renderMath(block ?? paren ?? inline ?? "", Boolean(block));
    html += rendered ?? escapeHtml(raw);
    lastIndex = index + raw.length;
  }
  html += escapeHtml(withNewlines.slice(lastIndex)).replace(/\n/g, "<br>");
  return html;
}

export function hasMath(input: string): boolean {
  MATH_PATTERN.lastIndex = 0;
  return MATH_PATTERN.test(input);
}
