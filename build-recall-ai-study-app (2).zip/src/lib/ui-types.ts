import type { CardRow } from "@/db/schema";
import type { CardKind } from "@/lib/memory/types";

export type StudyCard = {
  id: string;
  documentId: string;
  kind: CardKind | string;
  prompt: string;
  answer: string;
  hint: string;
  cloze: string | null;
  quote: string;
  page: number;
  options: string[];
  explanation: string;
  tags: string[];
  dueAt: string;
  intervalDays: number;
  reps: number;
  ease: number;
  /** Server-rendered, sanitised HTML with KaTeX maths. Optional. */
  promptHtml?: string;
  answerHtml?: string;
};

export function serializeCard(row: CardRow): StudyCard {
  return {
    id: row.id,
    documentId: row.documentId,
    kind: row.kind,
    prompt: row.prompt,
    answer: row.answer,
    hint: row.hint,
    cloze: row.cloze,
    quote: row.quote,
    page: row.page,
    options: row.options ?? [],
    explanation: row.explanation,
    tags: row.tags ?? [],
    dueAt: row.dueAt.toISOString(),
    intervalDays: row.intervalDays,
    reps: row.reps,
    ease: row.ease,
  };
}

export const KIND_LABEL: Record<string, string> = {
  cloze: "Cloze",
  definition: "Definition",
  fact: "Fact",
  list: "Sequence",
  concept: "Concept",
  ai: "AI card",
};
