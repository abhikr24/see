-- Recall ↔ Supabase: link local identity to auth.uid() and lock every table down.
-- Run once in the Supabase SQL editor or via `supabase db push`.
-- The app writes with its own server-side user id; these policies make the
-- browser-visible anon key useless for reading another user's data.

-- users.id must equal auth.uid() so policies can compare columns directly.
alter table users add column if not exists auth_uid uuid unique;

create or replace function recall_current_uid() returns uuid
language sql stable as $$ select auth.uid() $$;

alter table users enable row level security;
alter table documents enable row level security;
alter table cards enable row level security;
alter table reviews enable row level security;
alter table quiz_attempts enable row level security;
alter table ai_events enable row level security;
alter table subscriptions enable row level security;
alter table sessions enable row level security;
alter table rate_limits enable row level security;

create policy "users self read" on users for select using (auth_uid = recall_current_uid());
create policy "users self update" on users for update using (auth_uid = recall_current_uid());

create policy "documents owner" on documents for all
  using (user_id in (select id from users where auth_uid = recall_current_uid()))
  with check (user_id in (select id from users where auth_uid = recall_current_uid()));

create policy "cards owner" on cards for all
  using (user_id in (select id from users where auth_uid = recall_current_uid()))
  with check (user_id in (select id from users where auth_uid = recall_current_uid()));

create policy "reviews owner" on reviews for all
  using (user_id in (select id from users where auth_uid = recall_current_uid()))
  with check (user_id in (select id from users where auth_uid = recall_current_uid()));

create policy "quiz owner" on quiz_attempts for all
  using (user_id in (select id from users where auth_uid = recall_current_uid()))
  with check (user_id in (select id from users where auth_uid = recall_current_uid()));

create policy "ai events owner" on ai_events for all
  using (user_id in (select id from users where auth_uid = recall_current_uid()))
  with check (user_id in (select id from users where auth_uid = recall_current_uid()));

create policy "subscriptions owner" on subscriptions for select
  using (user_id in (select id from users where auth_uid = recall_current_uid()));

-- sessions and rate_limits are server-only: no policies means no client access.
revoke all on sessions from anon, authenticated;
revoke all on rate_limits from anon, authenticated;
