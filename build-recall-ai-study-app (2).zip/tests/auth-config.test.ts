import { describe, expect, it } from "vitest";
import { assertAuthConfiguration, describeAuthProvider } from "@/lib/auth/config";

describe("auth provider configuration", () => {
  it("defaults to local", () => {
    expect(assertAuthConfiguration({})).toBe("local");
  });

  it("accepts local explicitly", () => {
    expect(assertAuthConfiguration({ AUTH_PROVIDER: "local", SUPABASE_URL: "x" })).toBe("local");
  });

  it("accepts a fully configured supabase provider", () => {
    expect(
      assertAuthConfiguration({
        AUTH_PROVIDER: "supabase",
        SUPABASE_URL: "https://example.supabase.co",
        SUPABASE_ANON_KEY: "anon",
      }),
    ).toBe("supabase");
  });

  it("throws loudly when supabase keys are missing", () => {
    expect(() => assertAuthConfiguration({ AUTH_PROVIDER: "supabase" })).toThrow(
      /SUPABASE_URL and SUPABASE_ANON_KEY/,
    );
    expect(() =>
      assertAuthConfiguration({ AUTH_PROVIDER: "supabase", SUPABASE_URL: "https://x.supabase.co" }),
    ).toThrow(/SUPABASE_ANON_KEY/);
  });

  it("rejects unknown providers", () => {
    expect(() => assertAuthConfiguration({ AUTH_PROVIDER: "magic" })).toThrow(/AUTH_PROVIDER/);
  });

  it("reports a problem instead of silently degrading", () => {
    const described = describeAuthProvider({ AUTH_PROVIDER: "supabase" });
    expect(described.auth).toBe("invalid");
    expect(described.problem).toContain("SUPABASE_URL");
  });
});
