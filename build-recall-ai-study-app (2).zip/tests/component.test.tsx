// @vitest-environment jsdom
import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import ActivityHeatmap from "@/components/app/ActivityHeatmap";
import RichText from "@/components/RichText";

describe("ActivityHeatmap", () => {
  it("announces the review total and every day", () => {
    const activity = Array.from({ length: 30 }, (_, index) => ({
      date: `2026-01-${String(index + 1).padStart(2, "0")}`,
      count: index % 4,
    }));
    render(<ActivityHeatmap activity={activity} />);
    expect(screen.getByRole("img", { name: /reviews in the last 30 days/i })).toBeTruthy();
    expect(screen.getByText(/reviews graded/i)).toBeTruthy();
  });
});

describe("RichText", () => {
  it("falls back to plain text when no HTML is supplied", () => {
    render(<RichText text={"Fill the gap:\n_____ is the movement of water."} />);
    expect(screen.getByText(/movement of water/)).toBeTruthy();
  });

  it("renders server-sanitised HTML", () => {
    render(<RichText text="ignored" html={'The potential is <span class="katex">-70</span> mV'} />);
    expect(screen.getByText(/-70/)).toBeTruthy();
  });
});
