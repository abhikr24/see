import { describe, expect, it } from "vitest";
import Papa from "papaparse";
import {
  analyzeSource,
  cardsToCsv,
  cardsToTsv,
  extractBlocks,
  isHeadingLine,
  splitSentences,
  validateCard,
} from "@/lib/memory/engine";
import type { MemoryCard } from "@/lib/memory/types";
import { FIXTURES, LEGAL, PAPER, SCANNED, SLIDES, TEXTBOOK } from "./fixtures/documents";

function headingsOf(pages: string[]): string[] {
  return extractBlocks(pages)
    .filter((block) => block.kind === "heading")
    .map((block) =>
      block.text
        .toLowerCase()
        .replace(/[^a-z0-9 ]/g, "")
        .trim(),
    );
}

describe("heading detection", () => {
  it("recognises chapter and numbered headings", () => {
    expect(isHeadingLine("Chapter 2 - Diffusion and Osmosis")).toBe(true);
    expect(isHeadingLine("2. The Cell Membrane")).toBe(true);
    expect(isHeadingLine("The Cell Membrane")).toBe(true);
    expect(isHeadingLine("References")).toBe(true);
  });

  it("does not treat sentences or slide bullets as headings", () => {
    expect(isHeadingLine("Diffusion is the net movement of particles down a gradient.")).toBe(
      false,
    );
    expect(isHeadingLine("• Working memory holds information for a short period")).toBe(false);
    expect(isHeadingLine("Osmosis explains why a plant cell becomes turgid in pure water.")).toBe(
      false,
    );
  });
});

describe("sentence splitting", () => {
  it("keeps abbreviations, decimals and currency together", () => {
    const sentences = splitSentences(
      "Dr. Smith measured 3.5 litres of water. The cost was $5. Osmosis moved the water across the membrane. The U.S. team repeated the experiment at 37 degrees.",
    );
    expect(sentences.length).toBeGreaterThanOrEqual(3);
    expect(sentences[0].startsWith("Dr. Smith")).toBe(true);
    expect(sentences.some((sentence) => sentence.includes("3.5"))).toBe(true);
    expect(sentences.some((sentence) => sentence.startsWith("The U.S. team"))).toBe(true);
  });
});

describe("validator", () => {
  const base: MemoryCard = {
    kind: "definition",
    prompt: "What is osmosis?",
    answer: "The diffusion of water across a selectively permeable membrane.",
    hint: "",
    cloze: null,
    quote: "",
    page: 1,
    options: [],
    explanation: "",
    tags: [],
  };

  it("accepts a complete answer", () => {
    expect(validateCard(base).ok).toBe(true);
  });

  it("rejects truncated answers", () => {
    expect(validateCard({ ...base, answer: "The diffusion of water across a membrane…" }).ok).toBe(
      false,
    );
  });

  it("rejects a heading as the answer", () => {
    expect(
      validateCard({ ...base, answer: "The Cell Membrane" }, { headings: ["The Cell Membrane"] })
        .ok,
    ).toBe(false);
  });

  it("rejects an answer that is still visible in a cloze prompt", () => {
    const cloze: MemoryCard = {
      ...base,
      kind: "cloze",
      prompt: "Fill the gap:\nOsmosis moves water across the membrane.",
      answer: "membrane",
      cloze: "Fill the gap:\nOsmosis moves water across the membrane.",
    };
    expect(validateCard(cloze).ok).toBe(false);
  });

  it("rejects answers copied from the prompt", () => {
    expect(validateCard({ ...base, prompt: "Is water moving?", answer: "water" }).ok).toBe(false);
  });

  it("rejects prompts without a question mark or cloze blank", () => {
    expect(validateCard({ ...base, prompt: "Explain osmosis in your own words" }).ok).toBe(false);
  });
});

describe.each(FIXTURES)("fixture: $name", (fixture) => {
  const result = analyzeSource({ title: fixture.title, pages: fixture.pages });
  const headings = headingsOf(fixture.pages);

  it("generates a sane number of cards", () => {
    expect(result.cards.length).toBeGreaterThanOrEqual(fixture.minCards);
    expect(result.cards.length).toBeLessThanOrEqual(fixture.maxCards);
  });

  it("never uses a heading as an answer", () => {
    for (const card of result.cards) {
      const normalised = card.answer
        .toLowerCase()
        .replace(/[^a-z0-9 ]/g, "")
        .trim();
      expect(headings).not.toContain(normalised);
    }
  });

  it("never ends an answer in an ellipsis", () => {
    for (const card of result.cards) {
      expect(card.answer.endsWith("...")).toBe(false);
      expect(card.answer.endsWith("…")).toBe(false);
    }
  });

  it("passes the card validator at the required rate", () => {
    expect(result.analysis.stats.qualityScore).toBeGreaterThanOrEqual(fixture.minQuality);
    for (const card of result.cards) {
      expect(validateCard(card, { headings }).ok).toBe(true);
    }
  });

  it("covers the top concepts", () => {
    expect(result.analysis.stats.coverage).toBeGreaterThanOrEqual(fixture.minCoverage);
  });

  it("matches the reviewed snapshot", () => {
    expect(
      result.cards.map((card) => ({ kind: card.kind, prompt: card.prompt, answer: card.answer })),
    ).toMatchSnapshot();
  });
});

describe("scanned sources", () => {
  it("reports no text instead of fabricating cards", () => {
    const result = analyzeSource({ title: SCANNED.title, pages: SCANNED.pages });
    expect(result.cards).toHaveLength(0);
    expect(result.analysis.warnings.length).toBeGreaterThan(0);
    expect(result.analysis.stats.qualityScore).toBe(0);
  });
});

describe("Anki export", () => {
  const cards = analyzeSource({ title: TEXTBOOK.title, pages: TEXTBOOK.pages }).cards;
  const csv = cardsToCsv(TEXTBOOK.title, cards);
  const body = csv
    .split("\n")
    .filter((line) => !line.startsWith("#"))
    .join("\n");
  const parsed = Papa.parse<Record<string, string>>(body, { header: true, skipEmptyLines: true });

  it("starts with the Anki preamble", () => {
    expect(csv.startsWith("#separator:Comma\n#html:false\n#deck:")).toBe(true);
  });

  it("has the same field count on every row", () => {
    const counts = body
      .trim()
      .split("\n")
      .map((line) => Papa.parse<string[]>(line).data[0]?.length ?? 0);
    expect(new Set(counts).size).toBe(1);
    expect(counts[0]).toBe(4);
  });

  it("maps Front, Back, Tags and Page", () => {
    expect(parsed.meta.fields).toEqual(["Front", "Back", "Tags", "Page"]);
    expect(parsed.data.length).toBe(cards.length);
    expect(parsed.data[0].Front?.length).toBeGreaterThan(0);
    expect(parsed.data[0].Back?.length).toBeGreaterThan(0);
    expect(parsed.data[0].Page).toMatch(/^\d+$/);
  });

  it("escapes quotes and newlines inside fields", () => {
    const tricky = [
      {
        prompt: 'What is a "membrane"?',
        answer: "A barrier,\nwith two lines.",
        hint: "",
        tags: ["bio"],
        page: 2,
      },
    ];
    const roundTrip = Papa.parse<Record<string, string>>(
      cardsToCsv("Tricky", tricky)
        .split("\n")
        .filter((line) => !line.startsWith("#") && line.length > 0)
        .join("\n"),
      { header: true, skipEmptyLines: true },
    );
    expect(roundTrip.data[0].Front).toContain('"membrane"');
    expect(roundTrip.data[0].Back).toContain("<br>");
    expect(roundTrip.data[0].Back).toContain("A barrier,");
  });

  it("produces a two-column TSV for Quizlet", () => {
    const tsv = cardsToTsv(cards);
    expect(tsv.startsWith("Term\tDefinition\n")).toBe(true);
    const parsedTsv = Papa.parse<Record<string, string>>(tsv, {
      delimiter: "\t",
      skipEmptyLines: true,
      header: true,
    });
    expect(parsedTsv.meta.fields).toEqual(["Term", "Definition"]);
    expect(parsedTsv.data.length).toBe(cards.length);
    expect(parsedTsv.data.every((row) => Boolean(row.Term) && Boolean(row.Definition))).toBe(true);
  });
});

describe("fixture variety", () => {
  it("keeps a spread of card kinds across the paper and legal fixtures", () => {
    for (const fixture of [PAPER, SLIDES, LEGAL]) {
      const { cards } = analyzeSource({ title: fixture.title, pages: fixture.pages });
      const kinds = new Set(cards.map((card) => card.kind));
      expect(kinds.size).toBeGreaterThanOrEqual(2);
    }
  });
});
