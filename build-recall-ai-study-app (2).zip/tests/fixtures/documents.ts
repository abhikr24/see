export type Fixture = {
  name: string;
  title: string;
  pages: string[];
  minCards: number;
  maxCards: number;
  minQuality: number;
  minCoverage: number;
};

export const TEXTBOOK: Fixture = {
  name: "textbook chapter",
  title: "Chapter 2 - Diffusion and Osmosis",
  pages: [
    `Chapter 2 - Diffusion and Osmosis

Diffusion is the net movement of particles from a region of higher concentration to a region of lower concentration. Diffusion continues until the concentration gradient disappears and the system reaches equilibrium.

The Cell Membrane

The cell membrane is a selectively permeable barrier that controls which substances enter and leave the cell. The membrane consists of a phospholipid bilayer with embedded proteins. Membrane proteins act as channels that allow water and small ions to pass through the bilayer.

Passive Transport

Passive transport moves substances across the membrane without using cellular energy. Osmosis is the diffusion of water across a selectively permeable membrane. Water moves from a dilute solution to a concentrated solution during osmosis.

1. Diffusion and Osmosis in Cells

Osmosis explains why a plant cell becomes turgid when it is placed in pure water. A red blood cell placed in a hypertonic solution loses water and shrinks because the surrounding solution has a lower water concentration. The resting potential of a typical neuron is approximately -70 mV at 37 degrees.`,
    `Concentration gradients drive diffusion in living tissues. The concentration gradient is the difference in solute concentration between two regions. A steep concentration gradient produces a faster rate of diffusion than a shallow gradient.

Active Transport

Active transport moves substances against their concentration gradient and therefore requires energy from ATP. The sodium potassium pump is an active transport protein that moves three sodium ions out of the cell for every two potassium ions it brings in. This pump maintains the resting potential of the neuron.

Factors Affecting Diffusion

The rate of diffusion depends on the surface area of the membrane, the concentration gradient and the temperature. A larger surface area increases diffusion because more particles can cross the membrane at once. Temperature increases diffusion because particles carry more kinetic energy at higher temperatures.

Osmosis and Water Potential

Water potential measures the tendency of water to move across a membrane. Pure water has a water potential of zero, and adding solutes lowers the water potential below zero. Osmosis always moves water from a region of higher water potential to a region of lower water potential.`,
    `Summary

Diffusion and osmosis are passive processes that depend on concentration gradients. The cell membrane controls diffusion and osmosis because it is selectively permeable. Active transport differs from diffusion because it requires ATP and can move substances against a concentration gradient.

Review Questions

1. State the difference between diffusion and osmosis.
2. Explain why the sodium potassium pump requires ATP.
3. Describe what happens to a red blood cell in a hypertonic solution.

Answers

Diffusion moves any particle down its concentration gradient, while osmosis moves only water across a selectively permeable membrane. The sodium potassium pump requires ATP because it moves ions against their concentration gradient. A red blood cell shrinks in a hypertonic solution because water leaves the cell by osmosis.`,
  ],
  minCards: 10,
  maxCards: 60,
  minQuality: 85,
  minCoverage: 75,
};

export const PAPER: Fixture = {
  name: "academic paper",
  title: "Retrieval Practice and the Spacing Effect",
  pages: [
    `Abstract

Retrieval practice improves long-term retention more than repeated reading. This paper reports two experiments on spaced retrieval practice in undergraduate learners. Retrieval practice produced a large benefit on a delayed test administered after seven days.

1. Introduction

Working memory holds a limited amount of information during a learning episode. Retrieval practice is the act of recalling information from memory without looking at the source. The testing effect describes the finding that retrieval practice improves retention relative to restudying the same material.

2. Method

Participants studied a textbook chapter about diffusion and osmosis. Half of the participants completed three retrieval practice sessions, and the other half reread the chapter three times. Each retrieval practice session required participants to write everything they could recall.

3. Results

The retrieval practice group recalled 68 percent of the key concepts after seven days. The rereading group recalled 41 percent of the key concepts after seven days. Spacing the retrieval practice sessions across three days produced better retention than massing the sessions into one day.

4. Discussion

Working memory load during the first session predicted later retention. The spacing effect was strongest for learners who reported low confidence in their initial recall. Spaced retrieval practice is therefore a practical intervention for large courses.`,
    `5. Limitations

The sample size was limited to 120 participants at a single university. The retrieval practice materials were drawn from one chapter, so the findings may not transfer to other domains. Future work should test spaced retrieval practice in laboratory courses.

References

[1] Roediger, H. L., & Karpicke, J. D. (2006). Test-enhanced learning. Psychological Science, 17(3), 249-255. doi:10.1111/j.1467-9280.2006.01693.x

[2] Cepeda, N. J., Pashler, H., Vul, E., Wixted, J. T., & Rohrer, D. (2006). Distributed practice in verbal recall tasks. Psychological Bulletin, 132(3), 354-380.

[3] Dunlosky, J., Rawson, K. A., Marsh, E. J., Nathan, M. J., & Willingham, D. T. (2013). Improving students' learning. Psychological Science in the Public Interest, 14(1), 4-58.`,
  ],
  minCards: 8,
  maxCards: 60,
  minQuality: 85,
  minCoverage: 75,
};

export const SLIDES: Fixture = {
  name: "lecture slides",
  title: "Lecture 4 - Memory Systems",
  pages: [
    `Lecture 4 - Memory Systems

• Working memory holds information for a short period
• Long term memory stores information for years
• Encoding is the process of forming a memory trace
• Retrieval is the process of accessing a stored memory
• Consolidation stabilises a memory trace after learning

Types of Memory

• Declarative memory is memory for facts and events
• Procedural memory is memory for skills and actions
• Episodic memory stores personal events with context
• Semantic memory stores general knowledge without context

Evidence

• Patient H.M. could not form new declarative memories after surgery
• H.M. could still learn new procedural skills
• This dissociation supports separate memory systems
• Working memory capacity is about four chunks in young adults`,
    `Practical Implications

• Spaced retrieval practice strengthens long term memory
• Interleaving improves discrimination between similar concepts
• Sleep supports consolidation of declarative memory
• Testing yourself is more effective than rereading notes

Key Numbers

• Working memory capacity is about 4 chunks
• Short term memory lasts approximately 18 seconds without rehearsal
• Spacing practice across 7 days improves retention`,
  ],
  minCards: 6,
  maxCards: 60,
  minQuality: 80,
  minCoverage: 70,
};

export const LEGAL: Fixture = {
  name: "legal contract",
  title: "Services Agreement",
  pages: [
    `Services Agreement

1. Definitions

Confidential Information means any information disclosed by one party to the other party that is marked as confidential. The Services means the consulting services described in Schedule A. The Term means the period beginning on the Effective Date and ending twelve months later.

2. Payment Terms

The Client shall pay each invoice within 30 days of the invoice date. The Supplier may charge interest on any overdue amount at 2 percent per month. All amounts are stated in INR and exclude applicable taxes.

3. Confidentiality

The Supplier shall keep all Confidential Information confidential and shall not disclose it to any third party without prior written consent. Confidential Information does not include information that is already public through no fault of the Supplier. This confidentiality obligation survives termination for a period of three years.

4. Limitation of Liability

Neither party shall be liable for indirect or consequential loss arising from this agreement. The total liability of the Supplier under this agreement is limited to INR 50,000. This limitation does not apply to fraud or wilful misconduct.

5. Termination

Either party may terminate this agreement by giving 30 days written notice to the other party. The Client shall pay for all Services performed before the termination date. Termination does not affect any accrued rights of either party.`,
    `6. Data Protection

The Supplier shall process personal data only in accordance with the Client's written instructions. The Supplier shall notify the Client within 72 hours of becoming aware of a personal data breach. The Supplier shall delete all personal data upon termination of this agreement unless retention is required by law.

7. Governing Law

This agreement is governed by the laws of India and the courts of Bengaluru have exclusive jurisdiction. No variation of this agreement is effective unless it is made in writing and signed by both parties.`,
  ],
  minCards: 6,
  maxCards: 60,
  minQuality: 85,
  minCoverage: 70,
};

export const SCANNED: Fixture = {
  name: "scanned image-only PDF",
  title: "Scanned handout",
  pages: ["", "   ", ""],
  minCards: 0,
  maxCards: 0,
  minQuality: 0,
  minCoverage: 0,
};

export const FIXTURES = [TEXTBOOK, PAPER, SLIDES, LEGAL, SCANNED];
