import { describe, expect, it } from "vitest";
import {
  formatDate,
  formatLongDate,
  formatNumber,
  LOCALES,
  MESSAGES,
  isLocale,
  translate,
} from "@/lib/i18n/messages";

describe("i18n", () => {
  it("has every key in every locale", () => {
    const enKeys = Object.keys(MESSAGES.en).sort();
    for (const locale of LOCALES) {
      expect(Object.keys(MESSAGES[locale]).sort()).toEqual(enKeys);
      for (const key of enKeys) {
        expect(MESSAGES[locale][key as keyof typeof MESSAGES.en].length).toBeGreaterThan(0);
      }
    }
  });

  it("translates and falls back safely", () => {
    expect(translate("hi", "nav.review")).toBe("दोहराएँ");
    expect(translate("en", "nav.review")).toBe("Review");
    expect(isLocale("hi")).toBe(true);
    expect(isLocale("fr")).toBe(false);
  });

  it("formats numbers and dates per locale", () => {
    expect(formatNumber(1234, "en")).toBe("1,234");
    expect(formatNumber(1234, "hi")).toContain("1,234");
    expect(formatDate("2026-10-28", "en")).toContain("2026");
    expect(formatLongDate(new Date("2026-10-28T12:00:00Z"), "hi")).toContain("अक्टूबर");
    expect(formatLongDate(new Date("2026-10-28T12:00:00Z"), "en")).toContain("October");
  });
});
