import { describe, expect, it } from "vitest";
import { parseCardImport } from "@/lib/import/cards";

describe("card import", () => {
  it("parses a headed CSV with tags and page", () => {
    const result = parseCardImport(
      "Front,Back,Tags,Page\nWhat is osmosis?,The diffusion of water across a membrane.,biology,2\n" +
        "What is diffusion?,Net movement of particles down a gradient.,biology,2",
    );
    expect(result.detected).toBe("csv");
    expect(result.cards).toHaveLength(2);
    expect(result.cards[0].tags).toContain("biology");
    expect(result.cards[0].page).toBe(2);
    expect(result.cards[1].page).toBe(2);
  });

  it("parses a headerless Quizlet TSV", () => {
    const result = parseCardImport("Term\tDefinition\nMitochondria\tProduces ATP for the cell");
    expect(result.detected).toBe("tsv");
    expect(result.cards).toHaveLength(1);
    expect(result.cards[0].answer).toContain("ATP");
  });

  it("parses markdown Q/A pairs and table rows", () => {
    const pairs = parseCardImport(
      "Q: What is diffusion?\nA: Movement of particles down a gradient.",
    );
    expect(pairs.detected).toBe("markdown");
    expect(pairs.cards).toHaveLength(1);

    const table = parseCardImport(
      "| Question | Answer |\n| --- | --- |\n| What is osmosis? | Diffusion of water across a membrane |",
    );
    expect(table.cards).toHaveLength(1);
  });

  it("rejects cards whose answer repeats the prompt", () => {
    const result = parseCardImport("Front,Back\nWhat is osmosis?,osmosis");
    expect(result.cards).toHaveLength(0);
    expect(result.skipped).toBe(1);
  });

  it("turns a bare Anki front into a valid prompt", () => {
    const result = parseCardImport("Front,Back\nOsmosis,The diffusion of water across a membrane.");
    expect(result.cards[0].prompt).toBe("Osmosis?");
  });
});
