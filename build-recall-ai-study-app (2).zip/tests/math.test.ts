import { describe, expect, it } from "vitest";
import { hasMath, renderRichText } from "@/lib/rich/render";

describe("rich text and maths", () => {
  it("renders inline and display maths with KaTeX", () => {
    const html = renderRichText("The potential is $-70\\,\\mathrm{mV}$ at rest.");
    expect(html).toContain("katex");
    expect(html).toContain("70");
    expect(html).not.toContain("$-70");
  });

  it("renders \\( \\) delimiters", () => {
    expect(renderRichText("Area \\(\\pi r^2\\) grows fast")).toContain("katex");
  });

  it("escapes and strips HTML from untrusted text", () => {
    const html = renderRichText('<script>alert("x")</script><b>bold</b>');
    expect(html).not.toContain("<script");
    expect(html).not.toContain("<b>");
    expect(html).toContain("bold");
  });

  it("detects paired maths spans only", () => {
    expect(hasMath("The energy is $E=mc^2$")).toBe(true);
    expect(hasMath("no maths here")).toBe(false);
    expect(hasMath("an unpaired $5 price")).toBe(false);
  });
});
