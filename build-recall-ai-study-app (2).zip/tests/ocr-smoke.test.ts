import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { defaultOcrDeps, ocrPdfPages } from "@/lib/ocr";

describe("real OCR", () => {
  it("rasterises and recognises an image-only PDF", async () => {
    const buffer = readFileSync("tests/fixtures/scanned-handout.pdf");
    const array = buffer.buffer.slice(
      buffer.byteOffset,
      buffer.byteOffset + buffer.byteLength,
    ) as ArrayBuffer;
    const pages = await defaultOcrDeps.renderPages(array, [1]);
    console.log("rendered pages:", pages.length, "bytes:", pages[0]?.image.length);
    const text = await defaultOcrDeps.recognize(pages[0].image);
    console.log("OCR TEXT >>>", text.replace(/\s+/g, " ").slice(0, 220));
    expect(pages.length).toBe(1);
    expect(text.toLowerCase()).toContain("osmo");
  }, 300_000);
});
