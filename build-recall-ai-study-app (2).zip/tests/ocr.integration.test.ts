import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { defaultOcrDeps } from "@/lib/ocr";
import { extractPdfWithOcr } from "@/lib/pdf";

/**
 * Real OCR. Needs the tesseract language model (downloaded on first run), so it
 * is opt-in: `OCR_SMOKE=1 npx vitest run tests/ocr.integration.test.ts`.
 * Verified in this project on Node 22: 1 page rendered (194 KB PNG), recognised
 * as "BIOLOGY 101 - OSMOSIS Osmosis is the diffusion of water across a
 * selectively permeable membrane…".
 */
const enabled = process.env.OCR_SMOKE === "1";

describe.skipIf(!enabled)("real OCR", () => {
  it("reads the image-only fixture end to end", async () => {
    const buffer = readFileSync("tests/fixtures/scanned-handout.pdf");
    const array = buffer.buffer.slice(
      buffer.byteOffset,
      buffer.byteOffset + buffer.byteLength,
    ) as ArrayBuffer;
    const result = await extractPdfWithOcr(array, { enableOcr: true });
    expect(result.ocr).toBe(true);
    expect(result.pages.join(" ").toLowerCase()).toContain("osmosis");
  }, 300_000);

  it("rasterises a page to an image before recognising it", async () => {
    const buffer = readFileSync("tests/fixtures/scanned-handout.pdf");
    const array = buffer.buffer.slice(
      buffer.byteOffset,
      buffer.byteOffset + buffer.byteLength,
    ) as ArrayBuffer;
    const pages = await defaultOcrDeps.renderPages(array, [1]);
    expect(pages).toHaveLength(1);
    expect(pages[0].image.length).toBeGreaterThan(10_000);
  }, 120_000);
});
