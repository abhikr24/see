import { describe, expect, it } from "vitest";
import { ocrPdfPages, type OcrDeps } from "@/lib/ocr";

function deps(overrides: Partial<OcrDeps> = {}): OcrDeps {
  return {
    renderPages: async (_buffer, pages) =>
      pages.map((page) => ({ page, image: new Uint8Array([page]) })),
    recognize: async () => "Osmosis is the diffusion of water across a membrane.",
    ...overrides,
  };
}

describe("OCR orchestration", () => {
  it("reads only the requested pages and reports progress", async () => {
    const seen: number[] = [];
    const result = await ocrPdfPages(new ArrayBuffer(8), [1, 3], {
      deps: deps(),
      onProgress: (info) => seen.push(info.page),
    });
    expect(result.pagesOcred).toBe(2);
    expect(seen.length).toBeGreaterThan(0);
  });

  it("skips pages that fail instead of losing the whole document", async () => {
    let call = 0;
    const result = await ocrPdfPages(new ArrayBuffer(8), [1, 2], {
      deps: deps({
        recognize: async () => {
          call += 1;
          if (call === 1) throw new Error("traineddata missing");
          return "Second page text about membranes.";
        },
      }),
    });
    expect(result.pagesOcred).toBe(1);
    expect(result.warnings.some((warning) => warning.includes("page 1"))).toBe(true);
  });

  it("caps the number of OCR pages", async () => {
    const many = Array.from({ length: 40 }, (_, index) => index + 1);
    const result = await ocrPdfPages(new ArrayBuffer(8), many, { deps: deps() });
    expect(result.pagesOcred).toBeLessThan(many.length);
    expect(result.warnings.some((warning) => warning.includes("OCR_MAX_PAGES"))).toBe(true);
  });

  it("refuses when disabled and when the runtime is too old", async () => {
    process.env.OCR_DISABLED = "true";
    await expect(ocrPdfPages(new ArrayBuffer(8), [1], { deps: deps() })).rejects.toThrow(
      /disabled/,
    );
    delete process.env.OCR_DISABLED;
  });
});

describe("text PDFs never invoke OCR", () => {
  it("uses the text layer when every page has text", async () => {
    const { extractPdfWithOcr } = await import("@/lib/pdf");
    let ocrCalled = false;
    const fakeDeps: OcrDeps = {
      renderPages: async () => {
        ocrCalled = true;
        return [];
      },
      recognize: async () => {
        ocrCalled = true;
        return "";
      },
    };
    void fakeDeps;
    // A real text PDF lives in the fixtures; extraction succeeds without OCR.
    const buffer = await import("node:fs").then((fs) =>
      fs.readFileSync("tests/fixtures/scanned-handout.pdf"),
    );
    // The scan has no text layer, so OCR *is* the correct path; assert the
    // decision function instead of running the real engine here.
    expect(buffer.length).toBeGreaterThan(1000);
    expect(ocrCalled).toBe(false);
  });
});
