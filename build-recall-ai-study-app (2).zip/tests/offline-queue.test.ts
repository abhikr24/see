import { describe, expect, it } from "vitest";
import { flushQueue, memoryStore, queueReview, type PendingReview } from "@/lib/offline/queue";

function item(overrides: Partial<PendingReview> = {}): PendingReview {
  return { id: "r1", cardId: "c1", grade: 2, queuedAt: Date.now(), attempts: 0, ...overrides };
}

describe("offline review queue", () => {
  it("queues a review and replays it when the server accepts", async () => {
    const store = memoryStore();
    await queueReview(store, { cardId: "card-1", grade: 2 });
    expect(await store.all()).toHaveLength(1);

    const result = await flushQueue(store, async () => ({ ok: true, status: 200 }));
    expect(result).toEqual({ synced: 1, failed: 0, remaining: 0 });
  });

  it("keeps the review when the network fails, and drops deleted cards", async () => {
    const store = memoryStore([item({ id: "keep" }), item({ id: "gone", cardId: "deleted" })]);
    const result = await flushQueue(store, async (pending) => {
      if (pending.cardId === "deleted") return { ok: false, status: 404 };
      throw new Error("offline");
    });
    expect(result.synced).toBe(0);
    expect(result.failed).toBe(1);
    expect((await store.all()).map((entry) => entry.id)).toEqual(["keep"]);
    expect((await store.all())[0].attempts).toBe(1);
  });

  it("never replays the same review twice", async () => {
    const store = memoryStore();
    await queueReview(store, { cardId: "card-1", grade: 3 });
    let calls = 0;
    await flushQueue(store, async () => {
      calls += 1;
      return { ok: true, status: 200 };
    });
    await flushQueue(store, async () => {
      calls += 1;
      return { ok: true, status: 200 };
    });
    expect(calls).toBe(1);
  });
});
