import { beforeEach, describe, expect, it, vi } from "vitest";

const execute = vi.fn();

vi.mock("@/db", () => ({
  db: { execute: (...args: unknown[]) => execute(...args) },
}));

import { consumeRateLimit, RATE_RULES } from "@/lib/rate-limit";

function result(points: number, expiresInMs = 60_000) {
  return { rows: [{ points, expires_at: new Date(Date.now() + expiresInMs).toISOString() }] };
}

describe("login rate limiter", () => {
  beforeEach(() => {
    execute.mockReset();
  });

  it("allows the first five attempts and blocks the sixth", async () => {
    expect(RATE_RULES.login.limit).toBe(5);
    for (let attempt = 1; attempt <= 5; attempt += 1) {
      execute.mockResolvedValueOnce(result(attempt));
      const outcome = await consumeRateLimit("login", "203.0.113.7");
      expect(outcome.allowed).toBe(true);
      expect(outcome.remaining).toBe(5 - attempt);
    }

    execute.mockResolvedValueOnce(result(6));
    const blocked = await consumeRateLimit("login", "203.0.113.7");
    expect(blocked.allowed).toBe(false);
    expect(blocked.retryAfterSeconds).toBeGreaterThan(0);
  });

  it("fails open if the limiter store is unavailable", async () => {
    execute.mockRejectedValueOnce(new Error("db down"));
    const outcome = await consumeRateLimit("login", "203.0.113.8");
    expect(outcome.allowed).toBe(true);
  });
});
