import { describe, expect, it } from "vitest";
import { scheduleReview } from "@/lib/memory/scheduler";

const NOW = new Date("2026-01-01T09:00:00.000Z");

function fresh() {
  return {
    ease: 2.5,
    intervalDays: 0,
    reps: 0,
    lapses: 0,
    stability: 0,
    difficulty: 0,
    fsrsState: "new",
  };
}

describe("FSRS scheduling", () => {
  it("schedules a new card into the future on Good", () => {
    const next = scheduleReview(fresh(), 2, NOW, 0.9);
    expect(next.reps).toBe(1);
    expect(next.dueAt.getTime()).toBeGreaterThan(NOW.getTime());
    expect(next.stability).toBeGreaterThan(0);
    expect(next.difficulty).toBeGreaterThan(0);
    expect(["learning", "review"]).toContain(next.fsrsState);
  });

  it("is deterministic with a fixed clock and no fuzz", () => {
    const a = scheduleReview(fresh(), 2, NOW, 0.9);
    const b = scheduleReview(fresh(), 2, NOW, 0.9);
    expect(a.dueAt.toISOString()).toBe(b.dueAt.toISOString());
    expect(a.stability).toBe(b.stability);
  });

  it("reviews a mature card further out than Again", () => {
    const graduated = scheduleReview(
      {
        ...fresh(),
        reps: 3,
        intervalDays: 10,
        stability: 10,
        difficulty: 4,
        fsrsState: "review",
        dueAt: NOW,
      },
      2,
      NOW,
      0.9,
    );
    const lapsed = scheduleReview(
      {
        ...fresh(),
        reps: 3,
        intervalDays: 10,
        stability: 10,
        difficulty: 4,
        fsrsState: "review",
        dueAt: NOW,
      },
      0,
      NOW,
      0.9,
    );
    expect(graduated.dueAt.getTime()).toBeGreaterThan(lapsed.dueAt.getTime());
    expect(lapsed.lapses).toBeGreaterThanOrEqual(0);
  });

  it("never schedules beyond the 365-day cap", () => {
    let state = {
      ...fresh(),
      reps: 4,
      intervalDays: 200,
      stability: 200,
      difficulty: 2,
      fsrsState: "review",
      dueAt: NOW,
    };
    let due = NOW;
    for (let i = 0; i < 25; i += 1) {
      const next = scheduleReview(state, 3, due, 0.9);
      expect(next.intervalDays).toBeLessThanOrEqual(365);
      expect(next.dueAt.getTime() - due.getTime()).toBeLessThanOrEqual(366 * 86_400_000);
      due = next.dueAt;
      state = {
        ...state,
        reps: next.reps,
        intervalDays: next.intervalDays,
        stability: next.stability,
        difficulty: next.difficulty,
        fsrsState: next.fsrsState,
      };
    }
  });

  it("backfills legacy SM-2 state instead of resetting it", () => {
    const next = scheduleReview(
      {
        ease: 2.6,
        intervalDays: 21,
        reps: 4,
        lapses: 1,
        fsrsState: "review",
        dueAt: NOW,
        lastReviewedAt: new Date(NOW.getTime() - 30 * 86_400_000),
      },
      2,
      NOW,
      0.9,
    );
    expect(next.reps).toBe(5);
    expect(next.stability).toBeGreaterThan(1);
  });
});
