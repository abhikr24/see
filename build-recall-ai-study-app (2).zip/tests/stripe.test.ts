import { describe, expect, it } from "vitest";
import { classifyEvent, metadataUserId, subscriptionFrom } from "@/lib/billing/webhook";
import { mapStripeStatus, PRICES, priceFor, PRO_CREDITS_PER_PERIOD } from "@/lib/billing/stripe";

describe("stripe status mapping", () => {
  it("entitles active, trialing and past_due subscriptions", () => {
    for (const status of ["active", "trialing", "past_due"]) {
      expect(mapStripeStatus(status).plan).toBe("pro");
    }
  });

  it("downgrades canceled, unpaid and incomplete subscriptions", () => {
    for (const status of ["canceled", "unpaid", "incomplete", "incomplete_expired"]) {
      expect(mapStripeStatus(status).plan).toBe("free");
    }
  });
});

describe("webhook classification", () => {
  it("grants credits on a completed checkout", () => {
    const outcome = classifyEvent({
      type: "checkout.session.completed",
      data: {
        object: { subscription: "sub_123", customer: "cus_123", metadata: { userId: "u1" } },
      },
    });
    expect(outcome).toEqual({ kind: "upgrade", credits: PRO_CREDITS_PER_PERIOD, status: "active" });
  });

  it("resets credits on invoice.paid", () => {
    const outcome = classifyEvent({
      type: "invoice.paid",
      data: { object: { subscription: "sub_123" } },
    });
    expect(outcome.kind).toBe("renewed");
  });

  it("downgrades on cancellation", () => {
    const outcome = classifyEvent({
      type: "customer.subscription.deleted",
      data: { object: { id: "sub_123", status: "canceled", customer: "cus_123" } },
    });
    expect(outcome).toEqual({ kind: "downgrade", status: "canceled" });
  });

  it("ignores invoices without a subscription", () => {
    const outcome = classifyEvent({
      type: "invoice.paid",
      data: { object: { subscription: null } },
    });
    expect(outcome).toEqual({ kind: "ignored", reason: "invoice_without_subscription" });
  });

  it("ignores unrelated events", () => {
    expect(classifyEvent({ type: "customer.created", data: { object: {} } }).kind).toBe("ignored");
  });

  it("reads the user id from metadata and the subscription object", () => {
    expect(metadataUserId({ data: { object: { metadata: { userId: "u9" } } } })).toBe("u9");
    const subscription = subscriptionFrom({
      data: {
        object: {
          id: "sub_1",
          status: "active",
          customer: "cus_1",
          items: { data: [{ price: { id: "price_1", currency: "inr" } }] },
        },
      },
    });
    expect(subscription?.id).toBe("sub_1");
  });
});

describe("pricing config", () => {
  it("exposes INR and USD prices", () => {
    expect(PRICES.inr.symbol).toBe("₹");
    expect(PRICES.usd.symbol).toBe("$");
    expect(PRICES.inr.monthly).toBeGreaterThan(0);
  });

  it("returns null when a price id is not configured", () => {
    expect(priceFor("inr", "month")).toBeNull();
  });
});
