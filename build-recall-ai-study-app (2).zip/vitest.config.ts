import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  test: {
    environment: "node",
    include: ["tests/**/*.test.{ts,tsx}"],
    reporters: ["default"],
    coverage: {
      provider: "v8",
      reporter: ["text", "json-summary"],
      include: [
        "src/lib/memory/**",
        "src/lib/auth/**",
        "src/lib/billing/**",
        "src/lib/import/**",
        "src/lib/rich/**",
      ],
      exclude: ["src/lib/auth/password.ts", "src/lib/auth/http.ts", "src/lib/auth/supabase.ts"],
    },
  },
});
