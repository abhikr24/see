// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Generator verification harness
//
// Run with:  npx tsx scripts/verify-maze.ts
//
// Proves the hard guarantees of the generation engine across the entire
// shipping content set plus thousands of randomised configurations.
// ─────────────────────────────────────────────────────────────

import {
  generateMaze,
  placeCoins,
  coinCountForSize,
  getSeededRandom,
  getSeedFromKey,
  type MazeAlgorithm,
} from '../src/lib/maze/generator';
import {
  validateMaze,
  solveMaze,
  reachableAvoiding,
  findDeadEnds,
  cellDegree,
  bfsCells,
} from '../src/lib/maze/solver';
import { getLevelConfig, getDailyConfig, getInfiniteConfig, WORLDS } from '../src/lib/maze/constants';
import type { Point } from '../src/lib/maze/solver';
import type { Difficulty, MazeGrid, MazeVariant } from '../src/lib/maze/types';

let failures = 0;
let checks = 0;

function assert(cond: boolean, label: string, detail = ''): void {
  checks++;
  if (!cond) {
    failures++;
    console.error(`  ✗ ${label} ${detail}`);
  }
}

/**
 * A copy of the maze with every shifting gate in its open phase.
 * Closed gates are a transient runtime state driven by the level rhythm;
 * the *structural* invariant is that the maze is fully connected once the
 * gates are open, which is what we audit here.
 */
function withGatesOpen(maze: MazeGrid): MazeGrid {
  const copy: MazeGrid = {
    ...maze,
    cells: maze.cells.map((row) =>
      row.map((c) => ({ ...c, walls: { ...c.walls }, metadata: c.metadata ? { ...c.metadata } : undefined })),
    ),
    gates: maze.gates.map((g) => ({ ...g, open: true })),
  };
  for (const g of copy.gates) {
    const cell = copy.cells[g.y][g.x];
    const saved = cell.metadata?.gateWalls as MazeGrid['cells'][number][number]['walls'] | undefined;
    if (saved) cell.walls = { ...saved };
  }
  return copy;
}

/** Every invariant a shipped maze must satisfy. */
function auditMaze(maze: MazeGrid, label: string): void {
  const report = validateMaze(maze);
  const openReport = validateMaze(withGatesOpen(maze));

  // Solvable the instant the player spawns, with gates in their start phase.
  assert(report.solvable, `${label} · solvable at t=0`);
  // And structurally sound once the gate rhythm opens everything.
  assert(openReport.solvable, `${label} · solvable with gates open`);
  assert(
    openReport.coverage === 1,
    `${label} · fully connected`,
    `coverage=${openReport.coverage.toFixed(3)}`,
  );
  assert(report.shortestPath > 0, `${label} · non-trivial route`, `len=${report.shortestPath}`);

  // Start/exit corner discipline (within 3 cells of their corners).
  assert(maze.start.x <= 2 && maze.start.y <= 2, `${label} · start in top-left region`);
  assert(
    maze.exit.x >= maze.width - 3 && maze.exit.y >= maze.height - 3,
    `${label} · exit in bottom-right region`,
  );
  assert(maze.cells[maze.start.y][maze.start.x].type === 'start', `${label} · start tagged`);
  assert(maze.cells[maze.exit.y][maze.exit.x].type === 'exit', `${label} · exit tagged`);

  // Key fairness, per lock colour.
  const doors: Array<Point & { lock: string }> = [];
  const keys: Array<Point & { lock: string }> = [];
  let coins = 0;
  let torches = 0;
  for (const row of maze.cells) {
    for (const c of row) {
      const lock = String(c.metadata?.lock ?? 'gold');
      if (c.type === 'door') doors.push({ x: c.x, y: c.y, lock });
      if (c.type === 'key') keys.push({ x: c.x, y: c.y, lock });
      if (c.type === 'coin') coins++;
      if (c.type === 'torch') torches++;
    }
  }
  assert(keys.length >= doors.length, `${label} · every door has a key`, `${keys.length}k/${doors.length}d`);

  // Each door's own colour must have a matching key.
  for (const d of doors) {
    assert(
      keys.some((k) => k.lock === d.lock),
      `${label} · ${d.lock} door has a ${d.lock} key`,
    );
  }

  if (doors.length > 0) {
    const allDoors = doors.map((d) => ({ x: d.x, y: d.y }));
    const reach = reachableAvoiding(maze.cells, maze.width, maze.height, maze.start, allDoors);
    // At least one key must be obtainable before touching any door, otherwise
    // the run is soft-locked from the first step.
    assert(
      keys.some((k) => reach[k.y][k.x]),
      `${label} · a key is reachable before any door`,
    );

    // Stronger guarantee: solving door-by-door must always be possible.
    // Repeatedly collect every key reachable behind the still-locked doors
    // and open whatever those keys unlock; the exit must become reachable.
    const held = new Set<string>();
    const opened = new Set<string>();
    for (let pass = 0; pass <= doors.length; pass++) {
      const blocking = doors.filter((d) => !opened.has(`${d.x},${d.y}`));
      const field = reachableAvoiding(
        maze.cells,
        maze.width,
        maze.height,
        maze.start,
        blocking.map((d) => ({ x: d.x, y: d.y })),
      );
      for (const k of keys) if (field[k.y][k.x]) held.add(k.lock);
      let progressed = false;
      for (const d of blocking) {
        if (held.has(d.lock) && field[d.y]?.[d.x] !== undefined) {
          opened.add(`${d.x},${d.y}`);
          progressed = true;
        }
      }
      if (!progressed) break;
    }
    const finalField = reachableAvoiding(
      maze.cells,
      maze.width,
      maze.height,
      maze.start,
      doors.filter((d) => !opened.has(`${d.x},${d.y}`)).map((d) => ({ x: d.x, y: d.y })),
    );
    assert(
      finalField[maze.exit.y][maze.exit.x],
      `${label} · exit reachable after unlocking obtainable doors`,
    );
  }

  // Fogged worlds must ship with torches to stay navigable.
  if (maze.fogRadius < 90) {
    assert(torches >= 2, `${label} · fogged maze has torch landmarks`, `${torches}`);
  }

  // Coin bookkeeping must match reality.
  assert(coins === maze.coinsTotal, `${label} · coinsTotal matches grid`, `${coins} vs ${maze.coinsTotal}`);
  assert(maze.coinsLeft === maze.coinsTotal, `${label} · coinsLeft initialised`);

  // Nothing may share a cell with start/exit.
  const startType = maze.cells[maze.start.y][maze.start.x].type;
  const exitType = maze.cells[maze.exit.y][maze.exit.x].type;
  assert(startType === 'start' && exitType === 'exit', `${label} · endpoints unpolluted`);

  // Gates must remember their carved walls.
  for (const g of maze.gates) {
    const meta = maze.cells[g.y][g.x].metadata;
    assert(!!meta?.gateWalls, `${label} · gate remembers walls`);
    assert(meta?.gateOpen === g.open, `${label} · gate metadata in sync`);
  }

  // Teleporters always come in complete pairs.
  const pairCounts = new Map<number, number>();
  for (const row of maze.cells) {
    for (const c of row) {
      if (c.type !== 'teleporter') continue;
      const id = c.metadata?.pairId as number;
      pairCounts.set(id, (pairCounts.get(id) ?? 0) + 1);
    }
  }
  for (const [id, n] of pairCounts) {
    assert(n === 2, `${label} · teleporter pair ${id} complete`, `count=${n}`);
  }

  // Ice must never sit on a dead end (sliding into an inescapable pocket).
  for (const de of findDeadEnds(maze)) {
    assert(
      maze.cells[de.y][de.x].type !== 'ice',
      `${label} · no ice in dead end`,
      `(${de.x},${de.y})`,
    );
  }
}

console.log('\n═══ MAZE UNIVERSE · generator verification ═══\n');

// ── 1. Every shipping story level ──
console.log('1 · Story levels (all 9 finite worlds)');
let levelCount = 0;
for (const world of WORLDS) {
  for (let n = 1; n <= world.totalLevels; n++) {
    const cfg = getLevelConfig(world.id, n);
    auditMaze(generateMaze(cfg), `w${world.id}-l${n}`);
    levelCount++;
  }
}
console.log(`   ${levelCount} levels audited`);

// ── 2. A year of daily challenges ──
console.log('2 · Daily challenges (365 days)');
for (let d = 0; d < 365; d++) {
  const date = new Date(2026, 0, 1 + d);
  const dk = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  auditMaze(generateMaze(getDailyConfig(dk)), `daily-${dk}`);
}
console.log('   365 dailies audited');

// ── 3. Deep endless descent ──
console.log('3 · Endless floors 1–120');
for (let f = 1; f <= 120; f++) {
  auditMaze(generateMaze(getInfiniteConfig(f)), `floor-${f}`);
}
console.log('   120 floors audited');

// ── 4. Randomised fuzzing across the whole parameter space ──
console.log('4 · Fuzzing 1200 random configurations');
const variants: MazeVariant[] = ['classic', 'dark', 'ice', 'shifting', 'mirror', 'chase', 'memory'];
const difficulties: Difficulty[] = ['easy', 'medium', 'hard', 'expert'];
const algorithms: MazeAlgorithm[] = ['dfs', 'prims'];
const rng = getSeededRandom(20260418);

for (let i = 0; i < 1200; i++) {
  const w = 3 + Math.floor(rng() * 20);
  const h = 3 + Math.floor(rng() * 20);
  const maze = generateMaze({
    width: w,
    height: h,
    algorithm: algorithms[Math.floor(rng() * algorithms.length)],
    seed: Math.floor(rng() * 1e9),
    difficulty: difficulties[Math.floor(rng() * difficulties.length)],
    variant: variants[Math.floor(rng() * variants.length)],
    features: ['coins', 'keys', 'teleporters', 'powerups', 'enemies', 'gates'],
  });
  auditMaze(maze, `fuzz-${i}(${w}x${h})`);
}
console.log('   1200 random mazes audited');

// ── 5. Degenerate / edge-case inputs ──
console.log('5 · Edge cases');
for (const [w, h] of [[1, 1], [0, 5], [3, 3], [2, 40], [1, 100], [-4, 7]]) {
  const maze = generateMaze({
    width: w,
    height: h,
    seed: 7,
    difficulty: 'expert',
    variant: 'chase',
    features: ['coins', 'keys', 'teleporters', 'powerups', 'enemies', 'gates'],
  });
  assert(maze.width >= 3 && maze.height >= 3, `clamped ${w}x${h}`);
  assert(validateMaze(maze).solvable, `solvable ${w}x${h}`);
}
// Zero coins requested
const noCoins = placeCoins(
  generateMaze({ width: 9, height: 9, seed: 1, difficulty: 'easy', variant: 'classic', features: [] }),
  0,
);
assert(noCoins.coinsTotal === 0, 'zero-coin request honoured');
// Absurd coin request must not loop or overflow the grid
const manyCoins = placeCoins(
  generateMaze({ width: 7, height: 7, seed: 2, difficulty: 'easy', variant: 'classic', features: [] }),
  9999,
);
assert(manyCoins.coinsTotal < 49, 'over-request clamped to free cells', `${manyCoins.coinsTotal}`);
console.log('   edge cases handled');

// ── 6. Determinism: same seed ⇒ identical maze ──
console.log('6 · Determinism');
const fingerprint = (m: MazeGrid) =>
  JSON.stringify({
    s: m.start,
    e: m.exit,
    c: m.cells.map((r) => r.map((c) => `${c.type}${+c.walls.top}${+c.walls.right}${+c.walls.bottom}${+c.walls.left}`)),
    g: m.gates,
    coins: m.coinsTotal,
  });

for (let i = 0; i < 40; i++) {
  const cfg = {
    width: 13,
    height: 15,
    seed: 4242 + i,
    difficulty: 'hard' as Difficulty,
    variant: 'shifting' as MazeVariant,
    features: ['coins', 'keys', 'teleporters', 'powerups', 'gates'],
  };
  assert(fingerprint(generateMaze(cfg)) === fingerprint(generateMaze(cfg)), `seed ${cfg.seed} reproducible`);
}
// Different seeds must actually differ
assert(
  fingerprint(generateMaze({ width: 11, height: 11, seed: 1, difficulty: 'medium', variant: 'classic', features: ['coins'] })) !==
    fingerprint(generateMaze({ width: 11, height: 11, seed: 2, difficulty: 'medium', variant: 'classic', features: ['coins'] })),
  'different seeds produce different mazes',
);
// Daily seed is stable per date key
assert(getSeedFromKey('2026-04-18') === getSeedFromKey('2026-04-18'), 'daily seed stable');
assert(getSeedFromKey('2026-04-18') !== getSeedFromKey('2026-04-19'), 'daily seed varies by day');
console.log('   determinism verified');

// ── 7. Design-target statistics ──
console.log('7 · Design targets');
const coinTargets: Array<[number, number]> = [
  [7, 5],
  [11, 10],
  [15, 18],
  [21, 30],
];
for (const [size, want] of coinTargets) {
  const got = coinCountForSize(size, size);
  assert(got === want, `coin curve ${size}x${size} = ${want}`, `got ${got}`);
}

// Path-length goal: 40% of cells for medium+
let met = 0;
let sampled = 0;
for (let i = 0; i < 160; i++) {
  const size = 9 + (i % 11);
  const maze = generateMaze({
    width: size,
    height: size,
    seed: 900 + i,
    difficulty: 'medium',
    variant: 'classic',
    features: ['coins'],
  });
  const r = validateMaze(maze);
  sampled++;
  if (r.shortestPath >= Math.floor(size * size * 0.4)) met++;
}
console.log(`   route-length goal met on ${((met / sampled) * 100).toFixed(0)}% of medium mazes`);

// Algorithm personality: Prim's should yield more dead ends than DFS.
const deadEndRatio = (algorithm: MazeAlgorithm) => {
  let total = 0;
  for (let i = 0; i < 40; i++) {
    const m = generateMaze({
      width: 15,
      height: 15,
      algorithm,
      seed: 5000 + i,
      difficulty: 'medium',
      variant: 'classic',
      features: [],
    });
    total += findDeadEnds(m).length;
  }
  return total / 40;
};
const dfsDE = deadEndRatio('dfs');
const primsDE = deadEndRatio('prims');
console.log(`   avg dead ends on 15x15 — dfs: ${dfsDE.toFixed(1)}, prims: ${primsDE.toFixed(1)}`);
assert(primsDE > dfsDE, 'Prim\'s branches more than DFS');

// Hard adds dead ends relative to medium.
const avgDeadEnds = (difficulty: Difficulty) => {
  let t = 0;
  for (let i = 0; i < 40; i++) {
    t += findDeadEnds(
      generateMaze({ width: 15, height: 15, algorithm: 'dfs', seed: 7000 + i, difficulty, variant: 'classic', features: [] }),
    ).length;
  }
  return t / 40;
};
console.log(
  `   avg dead ends by difficulty — easy: ${avgDeadEnds('easy').toFixed(1)}, medium: ${avgDeadEnds('medium').toFixed(1)}, hard: ${avgDeadEnds('hard').toFixed(1)}`,
);

// Solver sanity: the returned path must be a legal walk.
console.log('8 · Solver path legality');
for (let i = 0; i < 120; i++) {
  const m = generateMaze({
    width: 11,
    height: 13,
    seed: 11000 + i,
    difficulty: 'hard',
    variant: 'classic',
    features: ['coins', 'keys'],
  });
  const path = solveMaze(m);
  assert(path !== null, `path ${i} exists`);
  if (!path) continue;
  assert(path[0].x === m.start.x && path[0].y === m.start.y, `path ${i} starts at start`);
  assert(path[path.length - 1].x === m.exit.x && path[path.length - 1].y === m.exit.y, `path ${i} ends at exit`);
  for (let s = 1; s < path.length; s++) {
    const a = path[s - 1];
    const b = path[s];
    const step = Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
    assert(step === 1, `path ${i} step ${s} adjacent`);
    const dir = b.y < a.y ? 'top' : b.y > a.y ? 'bottom' : b.x > a.x ? 'right' : 'left';
    assert(!m.cells[a.y][a.x].walls[dir], `path ${i} step ${s} passes no wall`);
  }
  assert(cellDegree(m.cells[m.start.y][m.start.x]) >= 1, `start not sealed`);
}
console.log('   solver paths legal');

// ── 9. Playability simulation: can a good player actually clear & 3-star? ──
console.log('9 · Playability simulation (greedy coin-collecting bot)');

/** Cells/second a skilled player sustains, plus a small junction tax. */
const CELLS_PER_SEC = 5.5;

/**
 * Simulates a strong run: greedily hop to the nearest uncollected coin,
 * then head for the exit. Returns the number of steps walked.
 */
function simulateRun(maze: MazeGrid, coinGoal: number): { steps: number; coins: number } {
  const coins: Point[] = [];
  for (const row of maze.cells) {
    for (const c of row) if (c.type === 'coin') coins.push({ x: c.x, y: c.y });
  }

  let cur: Point = { x: maze.start.x, y: maze.start.y };
  let steps = 0;
  let collected = 0;
  const remaining = [...coins];

  while (collected < coinGoal && remaining.length > 0) {
    const { dist } = bfsCells(maze.cells, maze.width, maze.height, cur.x, cur.y);
    let bestIdx = -1;
    let bestDist = Infinity;
    for (let i = 0; i < remaining.length; i++) {
      const d = dist[remaining[i].y][remaining[i].x];
      if (d >= 0 && d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    if (bestIdx === -1) break;
    steps += bestDist;
    cur = remaining[bestIdx];
    remaining.splice(bestIdx, 1);
    collected++;
  }

  const { dist } = bfsCells(maze.cells, maze.width, maze.height, cur.x, cur.y);
  const toExit = dist[maze.exit.y][maze.exit.x];
  if (toExit >= 0) steps += toExit;
  return { steps, coins: collected };
}

let clearable = 0;
let threeStarable = 0;
let simulated = 0;
const tightest: Array<{ id: string; ratio: number }> = [];

for (const world of WORLDS) {
  for (let n = 1; n <= world.totalLevels; n++) {
    const cfg = getLevelConfig(world.id, n);
    const maze = generateMaze(cfg);

    // Bare clear: straight to the exit.
    const bare = validateMaze(maze).shortestPath / CELLS_PER_SEC;
    // 3-star attempt: 80% of coins, then exit.
    const goal = maze.coinsTotal <= 5 ? maze.coinsTotal : Math.ceil(maze.coinsTotal * 0.8);
    const run = simulateRun(maze, goal);
    const starTime = run.steps / CELLS_PER_SEC;

    simulated++;
    if (bare < cfg.timeLimit) clearable++;
    if (starTime <= cfg.targetTime3Star && run.coins >= goal) threeStarable++;

    tightest.push({ id: cfg.id, ratio: bare / cfg.timeLimit });

    assert(bare < cfg.timeLimit * 0.9, `${cfg.id} · clearable within time limit`,
      `needs ${bare.toFixed(1)}s of ${cfg.timeLimit}s`);
  }
}

tightest.sort((a, b) => b.ratio - a.ratio);
console.log(`   ${clearable}/${simulated} levels clearable on a direct run`);
console.log(`   ${threeStarable}/${simulated} levels 3-starable by a greedy bot (${((threeStarable / simulated) * 100).toFixed(0)}%)`);
console.log(`   tightest time budgets: ${tightest.slice(0, 3).map((t) => `${t.id} ${(t.ratio * 100).toFixed(0)}%`).join(', ')}`);
assert(clearable === simulated, 'every level is clearable');
assert(threeStarable / simulated > 0.5, '3 stars reachable on most levels', `${threeStarable}/${simulated}`);

console.log(
  `\n${failures === 0 ? '✅ ALL CHECKS PASSED' : `❌ ${failures} FAILURES`} — ${checks.toLocaleString()} assertions\n`,
);
process.exit(failures === 0 ? 0 : 1);
