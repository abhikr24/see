'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { CalendarClock, ChevronLeft, Flame, Gift, Play, RotateCcw } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/Button';
import { StarRating } from '@/components/ui/StarRating';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { GameSession } from '@/components/game/GameSession';
import type { RunStats } from '@/lib/maze/types';
import { LevelComplete } from '@/components/game/LevelComplete';
import { GameOver } from '@/components/game/GameOver';
import { getDailyConfig, dailyReward } from '@/lib/maze/constants';
import { todayKey } from '@/lib/utils/helpers';
import { useGameStore, type CompleteLevelSummary } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { formatElapsed } from '@/lib/game/timer';
import { cn } from '@/lib/utils/helpers';

const VARIANT_META: Record<string, { label: string; color: string }> = {
  classic: { label: 'Classic', color: '#3b82f6' },
  dark: { label: 'Fog of War', color: '#8b5cf6' },
  ice: { label: 'Frozen', color: '#22d3ee' },
  shifting: { label: 'Shifting Gates', color: '#f59e0b' },
  mirror: { label: 'Mirrored Controls', color: '#e879f9' },
  chase: { label: 'Hunters', color: '#ef4444' },
  memory: { label: 'Memory', color: '#fb923c' },
  paint: { label: 'Paint', color: '#34d399' },
  snake: { label: 'Serpent', color: '#a3e635' },
};

export default function DailyPage() {
  const router = useRouter();
  const hydrated = useHydrated();
  const dateKey = todayKey();
  const config = useMemo(() => getDailyConfig(dateKey), [dateKey]);

  const streak = useGameStore((s) => s.progress.dailyStreak);
  const historyEntry = useGameStore((s) => s.progress.dailyHistory[dateKey]);
  const markDailyCompleted = useGameStore((s) => s.markDailyCompleted);

  const [phase, setPhase] = useState<'menu' | 'playing'>('menu');
  const [runId, setRunId] = useState(0);
  const [result, setResult] = useState<{ stats: RunStats; summary: CompleteLevelSummary } | null>(null);
  const [over, setOver] = useState<RunStats | null>(null);

  const meta = VARIANT_META[config.variant] ?? VARIANT_META.classic;
  const alreadyDone = hydrated && !!historyEntry;

  if (phase === 'playing') {
    return (
      <div className="fixed inset-0 z-50 bg-[#0a0f1e]">
        <GameSession
          key={`${config.id}:${runId}`}
          level={config}
          color={meta.color}
          tag={`Daily · ${dateKey}`}
          onComplete={(stats: RunStats) => {
            const awarded = markDailyCompleted(dateKey, {
              stars: stats.stars,
              time: stats.time,
              coins: stats.coinsCollected,
            });
            setResult({
              stats,
              summary: {
                starsEarned: stats.stars,
                coinsEarned: awarded > 0 ? awarded : stats.coinsCollected * 2,
                xpEarned: 60,
                leveledTo: 0,
                newBest: false,
                newlyUnlockedWorlds: [],
                newAchievements: [],
              },
            });
          }}
          onGameOver={(stats) => setOver(stats)}
          onExit={() => setPhase('menu')}
        />
        <LevelComplete
          open={result !== null}
          stats={result?.stats ?? null}
          summary={result?.summary ?? null}
          hasNext={false}
          onReplay={() => {
            setResult(null);
            setRunId((r) => r + 1);
          }}
          onHome={() => setPhase('menu')}
        />
        <GameOver
          open={over !== null}
          stats={over}
          onRetry={() => {
            setOver(null);
            setRunId((r) => r + 1);
          }}
          onHome={() => setPhase('menu')}
        />
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[#0a0f1e]">
      <Header />
      <main className="mx-auto max-w-xl px-4 pb-28 pt-4 md:pb-10">
        <div className="mb-5 flex items-center gap-3">
          <button
            onClick={() => router.push('/')}
            aria-label="Back"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 transition-all hover:bg-white/10 hover:text-white active:scale-95"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-black tracking-wide text-white">DAILY CHALLENGE</h1>
            <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
              One maze · everyone gets the same one
            </p>
          </div>
        </div>

        {/* Streak card */}
        <div className="relative mb-4 overflow-hidden rounded-3xl border border-amber-400/25 bg-gradient-to-br from-amber-500/15 via-slate-900 to-slate-950 p-5">
          <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-amber-400/10 blur-2xl" />
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-orange-600 shadow-lg shadow-amber-500/40">
              <Flame className="h-8 w-8 text-white" />
            </span>
            <div>
              <p className="text-3xl font-black text-white">
                {hydrated ? streak : 0}
                <span className="ml-2 text-sm font-bold uppercase tracking-widest text-amber-300">
                  day streak
                </span>
              </p>
              <p className="mt-0.5 text-xs text-slate-400">
                Play every day to grow the flame. Streaks boost rewards.
              </p>
            </div>
          </div>
        </div>

        {/* Today's card */}
        <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04]">
          <div className="border-b border-white/10 p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.35em] text-slate-400">
                  {dateKey}
                </p>
                <h2 className="mt-1 text-xl font-black text-white">Today&apos;s Maze</h2>
              </div>
              <span
                className="rounded-full border px-3 py-1.5 text-xs font-black uppercase tracking-wider"
                style={{
                  color: meta.color,
                  borderColor: `${meta.color}55`,
                  background: `${meta.color}14`,
                }}
              >
                {meta.label}
              </span>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <p className="text-sm font-extrabold tabular-nums text-white">
                  {config.mazeWidth}×{config.mazeHeight}
                </p>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Size</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <p className="text-sm font-extrabold tabular-nums text-white">{config.timeLimit}s</p>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Limit</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <p className="text-sm font-extrabold text-amber-300">
                  +{dailyReward(hydrated ? streak : 1)}
                  <CoinIcon size={13} className="ml-1 inline" />
                </p>
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Reward
                </p>
              </div>
            </div>
          </div>

          {alreadyDone ? (
            <div className="p-5 text-center">
              <p className="text-[10px] font-black uppercase tracking-[0.35em] text-emerald-400">
                Completed today
              </p>
              <StarRating stars={historyEntry!.stars} size="lg" className="mt-3 justify-center" />
              <p className="mt-2 text-sm text-slate-400">
                Best today: <span className="font-bold tabular-nums text-white">{formatElapsed(historyEntry!.time)}</span>
              </p>
              <Button
                size="lg"
                fullWidth
                variant="ghost"
                icon={RotateCcw}
                className="mt-5"
                onClick={() => setPhase('playing')}
              >
                Replay (glory only)
              </Button>
              <p className="mt-3 text-xs text-slate-500">
                A new challenge lands at midnight.
              </p>
            </div>
          ) : (
            <div className="p-5">
              <Button
                size="lg"
                fullWidth
                variant="gold"
                icon={Play}
                onClick={() => setPhase('playing')}
              >
                Start today&apos;s challenge
              </Button>
              <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-slate-500">
                <Gift className="h-3.5 w-3.5" /> One reward claim per day · replays are free
              </p>
            </div>
          )}
        </div>

        <div className="mt-4 flex items-start gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] p-4">
          <CalendarClock className="mt-0.5 h-5 w-5 shrink-0 text-blue-300" />
          <p className="text-xs leading-relaxed text-slate-400">
            Every wanderer on the planet gets the exact same maze each day. Clear it fast, grab
            every coin, and protect your streak — day-one rewards start at 60 coins and climb to
            400.
          </p>
        </div>
      </main>
    </div>
  );
}
