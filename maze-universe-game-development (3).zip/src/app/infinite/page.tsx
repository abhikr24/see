'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronLeft, Infinity as InfinityIcon, Play, TrendingUp } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/Button';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { GameSession } from '@/components/game/GameSession';
import type { RunStats } from '@/lib/maze/types';
import { LevelComplete } from '@/components/game/LevelComplete';
import { GameOver } from '@/components/game/GameOver';
import { getInfiniteConfig } from '@/lib/maze/constants';
import { useGameStore, type CompleteLevelSummary } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { useSoundEffects } from '@/hooks/useSoundEffects';

const FLOOR_COLORS = ['#38bdf8', '#8b5cf6', '#f472b6', '#10b981', '#f59e0b', '#22d3ee', '#e879f9'];

export default function InfinitePage() {
  const router = useRouter();
  const hydrated = useHydrated();
  const playSfx = useSoundEffects();
  const best = useGameStore((s) => s.progress.infiniteBestFloor);
  const recordInfiniteFloor = useGameStore((s) => s.recordInfiniteFloor);
  const addCoins = useGameStore((s) => s.addCoins);
  const addXP = useGameStore((s) => s.addXP);

  const [started, setStarted] = useState(false);
  const [floor, setFloor] = useState(1);
  const [runId, setRunId] = useState(0);
  const [result, setResult] = useState<{ stats: RunStats; summary: CompleteLevelSummary } | null>(null);
  const [over, setOver] = useState<RunStats | null>(null);

  const config = getInfiniteConfig(floor);
  const color = FLOOR_COLORS[(floor - 1) % FLOOR_COLORS.length];

  if (started) {
    return (
      <div className="fixed inset-0 z-50 bg-[#0a0f1e]">
        <GameSession
          key={`${config.id}:${runId}`}
          level={config}
          color={color}
          tag={`The Infinite · Floor ${floor}`}
          onComplete={(stats: RunStats) => {
            const isBest = recordInfiniteFloor(floor);
            const coins = 10 + floor * 4 + stats.coinsCollected * 5;
            addCoins(coins);
            addXP(12 + floor * 4);
            if (isBest) playSfx('levelup');
            setResult({
              stats,
              summary: {
                starsEarned: stats.stars,
                coinsEarned: coins,
                xpEarned: 12 + floor * 4,
                leveledTo: 0,
                newBest: isBest,
                newlyUnlockedWorlds: [],
                newAchievements: [],
              },
            });
          }}
          onGameOver={(stats) => setOver(stats)}
          onExit={() => {
            setStarted(false);
            setFloor(1);
          }}
        />
        <LevelComplete
          open={result !== null}
          stats={result?.stats ?? null}
          summary={result?.summary ?? null}
          hasNext
          nextLabel={`Descend to floor ${floor + 1}`}
          onNext={() => {
            setResult(null);
            setFloor((f) => f + 1);
            setRunId((r) => r + 1);
          }}
          onReplay={() => {
            setResult(null);
            setRunId((r) => r + 1);
          }}
          onHome={() => {
            setStarted(false);
            setFloor(1);
          }}
        />
        <GameOver
          open={over !== null}
          stats={over}
          headline="THE DESCENT ENDS"
          subline={`You reached floor ${floor}${best > 0 ? ` · personal best: floor ${best}` : ''}. The Infinite remembers.`}
          retryLabel="Start a new descent"
          onRetry={() => {
            setOver(null);
            setFloor(1);
            setRunId((r) => r + 1);
          }}
          onHome={() => {
            setStarted(false);
            setFloor(1);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[#0a0f1e]">
      <Header />
      <main className="mx-auto max-w-xl px-4 pb-28 pt-4 md:pb-10">
        <div className="mb-5 flex items-center gap-3">
          <button
            onClick={() => router.push('/')}
            aria-label="Back"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 transition-all hover:bg-white/10 hover:text-white active:scale-95"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-black tracking-wide text-white">THE INFINITE</h1>
            <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
              Endless procedural descent
            </p>
          </div>
        </div>

        <div className="relative mb-4 overflow-hidden rounded-3xl border border-violet-400/25 bg-gradient-to-br from-violet-500/15 via-slate-900 to-slate-950 p-6 text-center">
          <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-violet-500/15 blur-3xl" />
          <div className="absolute -bottom-10 -right-10 h-40 w-40 rounded-full bg-fuchsia-500/10 blur-3xl" />
          <span className="mx-auto flex h-20 w-20 animate-float items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 shadow-2xl shadow-violet-500/40">
            <InfinityIcon className="h-10 w-10 text-white" />
          </span>
          <h2 className="mt-4 text-2xl font-black text-white">How deep can you go?</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-slate-400">
            Every floor is generated fresh — bigger, stranger, deadlier. Ice, darkness, hunters
            and shifting gates rotate in as you descend. One mistake ends the run.
          </p>

          <div className="mt-5 inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/30 px-5 py-3">
            <TrendingUp className="h-5 w-5 text-emerald-400" />
            <span className="text-sm font-bold text-slate-300">Personal best</span>
            <span className="text-2xl font-black tabular-nums text-white">
              {hydrated && best > 0 ? `Floor ${best}` : '—'}
            </span>
          </div>

          <Button
            size="lg"
            fullWidth
            variant="purple"
            icon={Play}
            className="mt-5"
            onClick={() => setStarted(true)}
          >
            Begin the descent
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-white/[0.07] bg-white/[0.03] p-4">
            <p className="text-lg font-black text-white">+4 coins</p>
            <p className="text-xs text-slate-500">extra payout per floor cleared</p>
          </div>
          <div className="rounded-2xl border border-white/[0.07] bg-white/[0.03] p-4">
            <p className="inline-flex items-center gap-1 text-lg font-black text-amber-300">
              <CoinIcon size={16} /> +5 / coin
            </p>
            <p className="text-xs text-slate-500">for every coin grabbed mid-descent</p>
          </div>
        </div>
      </main>
    </div>
  );
}
