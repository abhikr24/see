import type { Metadata, Viewport } from 'next';
import './globals.css';
import { ToastProvider } from '@/components/ui/Toast';
import { BottomNav } from '@/components/layout/BottomNav';
import { AudioGate } from '@/components/AudioGate';

export const metadata: Metadata = {
  title: 'MAZE UNIVERSE — Chart the Impossible',
  description:
    'A premium maze-puzzle odyssey. Ten worlds, hundreds of corridors, one way out. Dark mazes, sliding ice, shifting walls, hunters, and the endless Infinite.',
  applicationName: 'MAZE UNIVERSE',
  keywords: ['maze', 'puzzle', 'game', 'labyrinth', 'maze universe'],
};

export const viewport: Viewport = {
  themeColor: '#0a0f1e',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-dvh bg-[#0a0f1e] antialiased">
        <ToastProvider>
          <AudioGate />
          {children}
          <BottomNav />
        </ToastProvider>
      </body>
    </html>
  );
}
