'use client';

import { useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronLeft, Crown, Medal, Star, Trophy } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { WORLDS } from '@/lib/maze/constants';
import { useGameStore } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { hashSeed, mulberry32 } from '@/lib/utils/helpers';
import type { LeaderboardEntry } from '@/lib/maze/types';
import { cn } from '@/lib/utils/helpers';

const RIVALS: Array<{ name: string; title: string }> = [
  { name: 'VOID_WALKER_7', title: 'Abyss Cartographer' },
  { name: 'neonfox', title: 'Gate Dancer' },
  { name: 'QuasarKid', title: 'Star Sprinter' },
  { name: 'mnemo_sine', title: 'Palace Mind' },
  { name: 'GridlockGal', title: 'Wall Whisperer' },
  { name: 'PhotonPilot', title: 'Light Runner' },
  { name: 'drift.king', title: 'Ice Baron' },
  { name: 'UmbraFox', title: 'Shadow Tamer' },
  { name: 'ChronoSage', title: 'Time Binder' },
  { name: 'MIRROR_MK_II', title: 'Inverted One' },
  { name: 'gl1tch', title: 'Phase Breaker' },
  { name: 'TesseractTom', title: '4D Tourist' },
  { name: 'LabyrinthLuna', title: 'Moon Mapper' },
  { name: 'ApexProwler', title: 'Hunter Hunter' },
  { name: 'singul8rity', title: 'Well Diver' },
];

function buildEntries(playerStars: number, playerCoins: number, playerLevel: number): LeaderboardEntry[] {
  const weekSeed = hashSeed(`lb:${Math.floor(Date.now() / (7 * 24 * 3600 * 1000))}`);
  const rng = mulberry32(weekSeed);
  const fake = RIVALS.map((r, i) => {
    const curve = 1 - i / (RIVALS.length + 2);
    const stars = Math.round(30 + curve * 640 + rng() * 40);
    return {
      name: r.name,
      title: r.title,
      stars,
      coins: Math.round(stars * (6 + rng() * 6)),
      level: Math.max(2, Math.round(stars / 16)),
      isPlayer: false,
    };
  });
  const entries: LeaderboardEntry[] = [
    ...fake,
    {
      name: 'YOU',
      title: 'Maze Wanderer',
      stars: playerStars,
      coins: playerCoins,
      level: playerLevel,
      isPlayer: true,
    },
  ];
  entries.sort((a, b) => b.stars - a.stars || b.coins - a.coins);
  return entries;
}

export default function LeaderboardPage() {
  const router = useRouter();
  const hydrated = useHydrated();
  const stars = useGameStore((s) => s.progress.totalStars);
  const coins = useGameStore((s) => s.progress.totalCoins);
  const level = useGameStore((s) => s.progress.playerLevel);
  const completedLevels = useGameStore((s) => s.progress.completedLevels);
  const infiniteBest = useGameStore((s) => s.progress.infiniteBestFloor);
  const dailyStreak = useGameStore((s) => s.progress.dailyStreak);

  const entries = useMemo(
    () => buildEntries(hydrated ? stars : 0, hydrated ? coins : 0, hydrated ? level : 1),
    [hydrated, stars, coins, level],
  );
  const playerRank = entries.findIndex((e) => e.isPlayer) + 1;

  return (
    <div className="min-h-dvh bg-[#0a0f1e]">
      <Header />
      <main className="mx-auto max-w-xl px-4 pb-28 pt-4 md:pb-10">
        <div className="mb-5 flex items-center gap-3">
          <button
            onClick={() => router.push('/')}
            aria-label="Back"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 transition-all hover:bg-white/10 hover:text-white active:scale-95"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-black tracking-wide text-white">LEADERBOARD</h1>
            <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
              Galactic rankings · resets weekly
            </p>
          </div>
        </div>

        {/* Your rank card */}
        <div className="mb-4 flex items-center gap-4 rounded-3xl border border-blue-400/25 bg-gradient-to-br from-blue-500/15 to-slate-950 p-4">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 text-2xl font-black text-white shadow-lg shadow-blue-500/30">
            #{playerRank}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-extrabold text-white">Your galactic rank</p>
            <p className="text-xs text-slate-400">
              {hydrated ? stars : 0} stars · {hydrated ? coins : 0} coins · pilot level {hydrated ? level : 1}
            </p>
          </div>
          <Star className="h-6 w-6 fill-amber-400 text-amber-400" />
        </div>

        {/* Table */}
        <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03]">
          {entries.map((e, i) => {
            const rank = i + 1;
            return (
              <div
                key={e.name}
                className={cn(
                  'flex items-center gap-3 border-b border-white/[0.05] px-4 py-3 last:border-0',
                  e.isPlayer && 'bg-blue-500/10',
                )}
              >
                <span className="flex w-9 shrink-0 justify-center">
                  {rank === 1 ? (
                    <Crown className="h-5 w-5 fill-amber-400 text-amber-400" />
                  ) : rank === 2 ? (
                    <Medal className="h-5 w-5 text-slate-300" />
                  ) : rank === 3 ? (
                    <Medal className="h-5 w-5 text-amber-700" />
                  ) : (
                    <span className="text-sm font-black tabular-nums text-slate-500">{rank}</span>
                  )}
                </span>
                <div className="min-w-0 flex-1">
                  <p
                    className={cn(
                      'truncate text-sm font-extrabold',
                      e.isPlayer ? 'text-blue-300' : 'text-white',
                    )}
                  >
                    {e.name}
                  </p>
                  <p className="truncate text-[10px] font-semibold uppercase tracking-wider text-slate-500">
                    {e.title} · Lv {e.level}
                  </p>
                </div>
                <span className="inline-flex shrink-0 items-center gap-1 text-xs font-bold text-slate-400">
                  <CoinIcon size={13} />
                  {e.coins.toLocaleString()}
                </span>
                <span className="inline-flex w-16 shrink-0 items-center justify-end gap-1 text-sm font-black tabular-nums text-amber-300">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  {e.stars}
                </span>
              </div>
            );
          })}
        </div>

        {/* Personal records */}
        <h2 className="mb-3 mt-7 flex items-center gap-2 text-sm font-black uppercase tracking-[0.25em] text-slate-400">
          <Trophy className="h-4 w-4 text-amber-400" /> Your records
        </h2>
        <div className="flex flex-col gap-3">
          {WORLDS.slice(0, 9).map((w) => {
            const cleared = hydrated
              ? Object.keys(completedLevels).filter((id) => id.startsWith(`w${w.id}-`)).length
              : 0;
            const wStars = hydrated
              ? Object.entries(completedLevels).reduce(
                  (acc, [id, v]) => (id.startsWith(`w${w.id}-`) ? acc + v.stars : acc),
                  0,
                )
              : 0;
            return (
              <div
                key={w.id}
                className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] p-3.5"
              >
                <span
                  className="h-9 w-9 shrink-0 rounded-xl"
                  style={{
                    background: `radial-gradient(circle at 30% 30%, ${w.gradientTo}, ${w.gradientFrom})`,
                    boxShadow: `0 0 14px ${w.color}44`,
                  }}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-xs font-extrabold uppercase tracking-widest text-white">
                      {w.name}
                    </p>
                    <p className="shrink-0 text-[10px] font-bold tabular-nums text-slate-500">
                      {cleared}/{w.totalLevels} cleared · {wStars}★
                    </p>
                  </div>
                  <ProgressBar
                    value={cleared}
                    max={w.totalLevels}
                    height={5}
                    variant="gold"
                    className="mt-2"
                    animated={false}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-violet-400/20 bg-violet-500/10 p-4 text-center">
            <p className="text-2xl font-black tabular-nums text-white">
              {hydrated && infiniteBest > 0 ? `Floor ${infiniteBest}` : '—'}
            </p>
            <p className="text-[10px] font-bold uppercase tracking-widest text-violet-300">
              Deepest descent
            </p>
          </div>
          <div className="rounded-2xl border border-amber-400/20 bg-amber-500/10 p-4 text-center">
            <p className="text-2xl font-black tabular-nums text-white">
              {hydrated ? dailyStreak : 0} days
            </p>
            <p className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
              Daily streak
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
