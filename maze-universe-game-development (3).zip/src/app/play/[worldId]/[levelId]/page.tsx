import { redirect } from 'next/navigation';
import { getWorld } from '@/lib/maze/constants';
import { PlayScreen } from '@/components/screens/PlayScreen';

interface PlayPageProps {
  params: Promise<{ worldId: string; levelId: string }>;
}

export default async function PlayPage({ params }: PlayPageProps) {
  const { worldId, levelId } = await params;
  const world = Number(worldId);
  const level = Number(levelId);
  const config = getWorld(world);
  if (!Number.isFinite(world) || !Number.isFinite(level) || world < 1 || world > 10) {
    redirect('/');
  }
  if (config.totalLevels === 0) redirect('/infinite');
  if (level < 1 || level > config.totalLevels) redirect('/');
  return <PlayScreen worldId={world} levelNumber={level} />;
}
