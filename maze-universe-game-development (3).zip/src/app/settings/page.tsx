'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Bell,
  Check,
  ChevronLeft,
  Compass,
  Eye,
  Ghost,
  Hammer,
  Hand,
  Hourglass,
  MousePointerClick,
  Music,
  Palette,
  Shield,
  Sparkles,
  Timer,
  Trash2,
  Volume2,
  Vibrate,
  Zap,
  type LucideIcon,
} from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { useToast } from '@/components/ui/Toast';
import { useGameStore } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { POWERUPS, SKINS } from '@/lib/maze/constants';
import type { PlayerSettings, PowerUpId } from '@/lib/maze/types';
import { cn } from '@/lib/utils/helpers';

const POWERUP_ICONS: Record<PowerUpId, LucideIcon> = {
  compass: Compass,
  mapReveal: Eye,
  wallBreaker: Hammer,
  timeFreeze: Hourglass,
  ghostMode: Ghost,
  speedBoost: Zap,
  shield: Shield,
};

export default function SettingsPage() {
  const router = useRouter();
  const hydrated = useHydrated();
  const playSfx = useSoundEffects();
  const { toast } = useToast();

  const settings = useGameStore((s) => s.progress.settings);
  const updateSettings = useGameStore((s) => s.updateSettings);
  const coins = useGameStore((s) => s.progress.totalCoins);
  const powerUps = useGameStore((s) => s.progress.powerUps);
  const purchasePowerUp = useGameStore((s) => s.purchasePowerUp);
  const unlockedSkins = useGameStore((s) => s.progress.unlockedSkins);
  const activeSkin = useGameStore((s) => s.progress.activeSkin);
  const buySkin = useGameStore((s) => s.buySkin);
  const setSkin = useGameStore((s) => s.setSkin);
  const resetProgress = useGameStore((s) => s.resetProgress);

  const [confirmReset, setConfirmReset] = useState(false);

  const toggle = (key: keyof PlayerSettings) => {
    playSfx('click');
    updateSettings({ [key]: !settings[key] } as Partial<PlayerSettings>);
  };

  return (
    <div className="min-h-dvh bg-[#0a0f1e]">
      <Header />
      <main className="mx-auto max-w-xl px-4 pb-28 pt-4 md:pb-10">
        <div className="mb-5 flex items-center gap-3">
          <button
            onClick={() => router.push('/')}
            aria-label="Back"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 transition-all hover:bg-white/10 hover:text-white active:scale-95"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-black tracking-wide text-white">SETTINGS</h1>
            <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
              Tune your experience
            </p>
          </div>
          <span className="ml-auto inline-flex items-center gap-1.5 rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-1.5 text-sm font-bold text-amber-300">
            <CoinIcon size={15} />
            {hydrated ? coins.toLocaleString() : '—'}
          </span>
        </div>

        {/* Audio & feedback */}
        <Section title="Audio & Feedback">
          <ToggleRow
            icon={Volume2}
            label="Sound effects"
            desc="Coins, doors, hunters and more"
            active={settings.soundEnabled}
            onClick={() => {
              toggle('soundEnabled');
              setTimeout(() => playSfx('coin'), 60);
            }}
          />
          <ToggleRow
            icon={Music}
            label="Ambient music"
            desc="Synthesized cosmic pad loop"
            active={settings.musicEnabled}
            onClick={() => toggle('musicEnabled')}
          />
          <ToggleRow
            icon={Vibrate}
            label="Haptic feedback"
            desc="Vibration on touch devices"
            active={settings.hapticFeedback}
            onClick={() => toggle('hapticFeedback')}
          />
        </Section>

        {/* Gameplay */}
        <Section title="Gameplay">
          <ToggleRow
            icon={Timer}
            label="Show timer"
            desc="Untimed feel · numbers blur, urgency stays"
            active={settings.showTimer}
            onClick={() => toggle('showTimer')}
          />
          <ToggleRow
            icon={Bell}
            label="Show move count"
            desc="Track steps in the HUD"
            active={settings.showMoveCount}
            onClick={() => toggle('showMoveCount')}
          />
          <div className="p-4">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/[0.06] text-blue-300">
                <Hand className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-extrabold text-white">Control method</p>
                <p className="text-xs text-slate-500">Swipe gestures · on-screen D-pad</p>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-1.5 rounded-2xl border border-white/10 bg-black/30 p-1.5">
              {(['swipe', 'both', 'tap'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    playSfx('click');
                    updateSettings({ controlMethod: m });
                  }}
                  className={cn(
                    'flex h-11 items-center justify-center gap-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all active:scale-95',
                    settings.controlMethod === m
                      ? 'bg-gradient-to-br from-blue-500 to-violet-600 text-white shadow-lg shadow-blue-500/30'
                      : 'text-slate-400 hover:text-slate-200',
                  )}
                >
                  {m === 'tap' && <MousePointerClick className="h-3.5 w-3.5" />}
                  {m}
                </button>
              ))}
            </div>
          </div>
        </Section>

        {/* Skins */}
        <Section title="Pilot skins" icon={Palette}>
          <div className="grid grid-cols-2 gap-2.5 p-4 sm:grid-cols-3">
            {SKINS.map((skin) => {
              const owned = hydrated && unlockedSkins.includes(skin.id);
              const active = hydrated && activeSkin === skin.id;
              const affordable = hydrated && coins >= skin.cost;
              return (
                <button
                  key={skin.id}
                  onClick={() => {
                    if (active) return;
                    if (owned) {
                      setSkin(skin.id);
                      playSfx('click');
                      toast({ title: `${skin.name} equipped`, variant: 'success' });
                    } else if (buySkin(skin.id)) {
                      playSfx('powerup');
                      toast({ title: `${skin.name} unlocked!`, variant: 'success' });
                    } else {
                      playSfx('bump');
                      toast({ title: 'Not enough coins', variant: 'error' });
                    }
                  }}
                  className={cn(
                    'flex min-h-[104px] flex-col items-center justify-center gap-2 rounded-2xl border p-3 transition-all active:scale-95',
                    active
                      ? 'border-white/40 bg-white/[0.08] shadow-lg'
                      : 'border-white/[0.08] bg-white/[0.03] hover:border-white/20',
                  )}
                  style={active ? { boxShadow: `0 0 18px ${skin.color}66`, borderColor: skin.color } : undefined}
                >
                  <span
                    className="h-9 w-9 rounded-full"
                    style={{
                      background: `radial-gradient(circle at 35% 30%, #fff, ${skin.color} 45%, ${skin.glow})`,
                      boxShadow: `0 0 14px ${skin.color}88`,
                    }}
                  />
                  <span className="text-xs font-extrabold text-white">{skin.name}</span>
                  {active ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-wider text-emerald-300">
                      <Check className="h-3 w-3" /> Active
                    </span>
                  ) : owned ? (
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                      Equip
                    </span>
                  ) : (
                    <span
                      className={cn(
                        'inline-flex items-center gap-1 text-[11px] font-bold tabular-nums',
                        affordable ? 'text-amber-300' : 'text-slate-600',
                      )}
                    >
                      <CoinIcon size={12} />
                      {skin.cost}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </Section>

        {/* Power-up shop */}
        <Section title="Power-up shop" icon={Sparkles}>
          <div className="flex flex-col divide-y divide-white/[0.06]">
            {POWERUPS.map((def) => {
              const Icon = POWERUP_ICONS[def.id];
              const count = hydrated ? powerUps[def.id] : 0;
              const affordable = hydrated && coins >= def.cost;
              return (
                <div key={def.id} className="flex items-center gap-3 px-4 py-3.5">
                  <span
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
                    style={{ background: `${def.color}1f`, color: def.color }}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-extrabold text-white">
                      {def.name}
                      <span className="ml-2 rounded-full border border-white/10 bg-white/[0.05] px-2 py-0.5 text-[10px] font-black text-slate-300">
                        ×{count}
                      </span>
                    </p>
                    <p className="line-clamp-1 text-xs text-slate-500">{def.description}</p>
                  </div>
                  <button
                    onClick={() => {
                      if (purchasePowerUp(def.id)) {
                        playSfx('coin');
                        toast({ title: `${def.name} +1`, variant: 'success' });
                      } else {
                        playSfx('bump');
                        toast({ title: 'Not enough coins', variant: 'error' });
                      }
                    }}
                    className={cn(
                      'inline-flex h-11 shrink-0 items-center gap-1.5 rounded-xl border px-3 text-sm font-bold tabular-nums transition-all active:scale-95',
                      affordable
                        ? 'border-amber-400/40 bg-amber-400/10 text-amber-300 hover:bg-amber-400/20'
                        : 'border-white/10 bg-white/[0.03] text-slate-500',
                    )}
                  >
                    <CoinIcon size={15} />
                    {def.cost}
                  </button>
                </div>
              );
            })}
          </div>
        </Section>

        {/* Danger zone */}
        <Section title="Danger zone">
          <div className="p-4">
            <Button
              variant="danger"
              fullWidth
              icon={Trash2}
              onClick={() => setConfirmReset(true)}
            >
              Reset all progress
            </Button>
            <p className="mt-2 text-center text-xs text-slate-600">
              Stars, coins, skins, streaks — everything returns to zero.
            </p>
          </div>
        </Section>

        <p className="mt-8 text-center text-[11px] font-semibold uppercase tracking-[0.3em] text-slate-700">
          Maze Universe · crafted among the stars
        </p>
      </main>

      <Modal
        open={confirmReset}
        onClose={() => setConfirmReset(false)}
        title="Reset everything?"
        size="sm"
      >
        <p className="text-sm leading-relaxed text-slate-400">
          This permanently erases your save: every star, coin, unlocked world, skin, power-up and
          streak. There is no undo.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2.5">
          <Button variant="ghost" onClick={() => setConfirmReset(false)}>
            Keep my save
          </Button>
          <Button
            variant="danger"
            icon={Trash2}
            onClick={() => {
              resetProgress();
              setConfirmReset(false);
              toast({ title: 'Progress reset', message: 'A fresh universe awaits.', variant: 'warning' });
            }}
          >
            Erase all
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function Section({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon?: LucideIcon;
  children: React.ReactNode;
}) {
  return (
    <section className="mb-4 overflow-hidden rounded-3xl border border-white/[0.08] bg-white/[0.03]">
      <h2 className="flex items-center gap-2 px-4 pb-1 pt-3.5 text-[11px] font-black uppercase tracking-[0.28em] text-slate-400">
        {Icon && <Icon className="h-3.5 w-3.5 text-blue-300" />}
        {title}
      </h2>
      {children}
    </section>
  );
}

function ToggleRow({
  icon: Icon,
  label,
  desc,
  active,
  onClick,
}: {
  icon: LucideIcon;
  label: string;
  desc: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 px-4 py-3.5 text-left transition-colors hover:bg-white/[0.03]"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/[0.06] text-blue-300">
        <Icon className="h-5 w-5" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-extrabold text-white">{label}</span>
        <span className="block text-xs text-slate-500">{desc}</span>
      </span>
      <span
        className={cn(
          'relative h-7 w-12 shrink-0 rounded-full border transition-colors duration-200',
          active ? 'border-emerald-400/40 bg-emerald-500/80' : 'border-white/10 bg-slate-800',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-5.5 w-5.5 rounded-full bg-white shadow transition-all duration-200',
            active ? 'left-[24px]' : 'left-0.5',
          )}
          style={{ height: 22, width: 22 }}
        />
      </span>
    </button>
  );
}
