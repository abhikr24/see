'use client';

// Unlocks the Web Audio context on the very first user gesture and
// keeps the sound manager synced with persisted settings.

import { useEffect } from 'react';
import { soundManager } from '@/lib/audio/soundManager';
import { useGameStore } from '@/stores/gameStore';

export function AudioGate() {
  const soundEnabled = useGameStore((s) => s.progress.settings.soundEnabled);
  const musicEnabled = useGameStore((s) => s.progress.settings.musicEnabled);

  useEffect(() => {
    soundManager.setSoundEnabled(soundEnabled);
    soundManager.setMusicEnabled(musicEnabled);
  }, [soundEnabled, musicEnabled]);

  useEffect(() => {
    const unlock = () => soundManager.unlock();
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  return null;
}
