'use client';

// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Game HUD
// Timer / coins / moves chips, power-up belt, optional D-pad.
// ─────────────────────────────────────────────────────────────

import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Compass,
  Eye,
  Ghost,
  Hammer,
  Hourglass,
  Key,
  Pause,
  Shield,
  Zap,
  type LucideIcon,
} from 'lucide-react';
import type { Direction, KeyColor, PowerUpId, PowerUpInventory } from '@/lib/maze/types';
import { KEY_PALETTE } from '@/lib/maze/types';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { formatTime, timePct, urgencyColor } from '@/lib/game/timer';
import { POWERUPS } from '@/lib/maze/constants';
import { cn } from '@/lib/utils/helpers';

const POWERUP_ICONS: Record<PowerUpId, LucideIcon> = {
  compass: Compass,
  mapReveal: Eye,
  wallBreaker: Hammer,
  timeFreeze: Hourglass,
  ghostMode: Ghost,
  speedBoost: Zap,
  shield: Shield,
};

export interface ActiveEffects {
  compass: boolean;
  mapReveal: boolean;
  timeFreeze: boolean;
  ghostMode: boolean;
  speedBoost: boolean;
  shield: boolean;
}

interface GameHUDProps {
  tag: string;
  levelName: string;
  color: string;
  timeLeft: number;
  timeLimit: number;
  showTimer: boolean;
  showMoves: boolean;
  coinsCollected: number;
  totalCoins: number;
  moves: number;
  /** Keys currently held, by colour. */
  heldKeys: Array<[KeyColor, number]>;
  effects: ActiveEffects;
  inventory: PowerUpInventory;
  onUsePowerUp: (id: PowerUpId) => void;
  onPause: () => void;
  onMove: (dir: Direction) => void;
  showDPad: boolean;
}

export function GameHUD(props: GameHUDProps) {
  const {
    tag,
    levelName,
    color,
    timeLeft,
    timeLimit,
    showTimer,
    coinsCollected,
    totalCoins,
    moves,
    heldKeys,
    effects,
    inventory,
    onUsePowerUp,
    onPause,
    onMove,
    showDPad,
  } = props;

  const pct = timePct(timeLeft, timeLimit);
  const urgent = pct <= 0.25;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      {/* ── Top cluster ── */}
      <div className="flex flex-col gap-2">
        <div className="flex items-start justify-between gap-2">
          <div className="rounded-2xl border border-white/10 bg-slate-900/70 px-3.5 py-2 backdrop-blur-xl">
            <p
              className="text-[9px] font-black uppercase tracking-[0.3em]"
              style={{ color }}
            >
              {tag}
            </p>
            <p className="text-sm font-extrabold text-white">{levelName}</p>
          </div>

          {/* Timer */}
          <div
            className={cn(
              'rounded-2xl border bg-slate-900/70 px-4 py-2 text-center backdrop-blur-xl transition-colors',
              urgent ? 'border-rose-400/50 animate-pulse' : 'border-white/10',
            )}
          >
            <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-400">
              Time
            </p>
            <p
              className={cn(
                'text-xl font-black tabular-nums leading-tight',
                !showTimer && 'blur-md select-none',
              )}
              style={{ color: urgencyColor(pct) }}
            >
              {showTimer ? formatTime(timeLeft) : '0:00'}
            </p>
            <div className="mt-1 h-1 w-24 overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${pct * 100}%`, background: urgencyColor(pct) }}
              />
            </div>
          </div>

          <button
            onClick={onPause}
            aria-label="Pause"
            className="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-slate-900/70 text-white backdrop-blur-xl transition-all hover:bg-white/10 active:scale-95"
          >
            <Pause className="h-5 w-5" />
          </button>
        </div>

        {/* Stat chips */}
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-slate-900/70 px-3 py-1.5 text-xs font-bold text-amber-300 backdrop-blur-xl">
            <CoinIcon size={14} />
            <span className="tabular-nums">
              {coinsCollected}/{totalCoins}
            </span>
          </span>
          {props.showMoves && (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-slate-900/70 px-3 py-1.5 text-xs font-bold text-slate-300 backdrop-blur-xl">
              MOVES <span className="tabular-nums text-white">{moves}</span>
            </span>
          )}
          {heldKeys.map(([color, n]) => (
            <span
              key={color}
              className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold backdrop-blur-xl"
              style={{
                color: KEY_PALETTE[color].light,
                borderColor: `${KEY_PALETTE[color].base}66`,
                background: `${KEY_PALETTE[color].base}1f`,
              }}
            >
              <Key className="h-3.5 w-3.5" /> {n}
            </span>
          ))}
        </div>
      </div>

      {/* ── Bottom cluster ── */}
      <div className="flex items-end justify-between gap-2">
        {/* Power-up belt */}
        <div className="pointer-events-auto flex max-w-[70%] flex-wrap gap-1.5">
          {POWERUPS.map((def) => {
            const Icon = POWERUP_ICONS[def.id];
            const count = inventory[def.id];
            const active = effects[def.id as keyof ActiveEffects];
            return (
              <button
                key={def.id}
                onClick={() => onUsePowerUp(def.id)}
                aria-label={`${def.name} (${count} left)`}
                className={cn(
                  'relative flex h-12 w-12 items-center justify-center rounded-2xl border backdrop-blur-xl transition-all active:scale-90',
                  active
                    ? 'border-white/60 bg-white/15 shadow-lg'
                    : 'border-white/10 bg-slate-900/70 hover:bg-white/10',
                )}
                style={active ? { boxShadow: `0 0 16px ${def.color}88`, borderColor: def.color } : undefined}
              >
                <Icon className="h-5 w-5" style={{ color: count > 0 || active ? def.color : '#64748b' }} />
                <span
                  className={cn(
                    'absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[10px] font-black',
                    count > 0 ? 'bg-white text-slate-900' : 'bg-slate-700/90 text-slate-300',
                  )}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* D-pad */}
        {showDPad && (
          <div className="pointer-events-auto grid grid-cols-3 gap-1 opacity-90">
            <span />
            <DPadButton onPress={() => onMove('up')} label="Up">
              <ChevronUp className="h-6 w-6" />
            </DPadButton>
            <span />
            <DPadButton onPress={() => onMove('left')} label="Left">
              <ChevronLeft className="h-6 w-6" />
            </DPadButton>
            <DPadButton onPress={() => onMove('down')} label="Down">
              <ChevronDown className="h-6 w-6" />
            </DPadButton>
            <DPadButton onPress={() => onMove('right')} label="Right">
              <ChevronRight className="h-6 w-6" />
            </DPadButton>
          </div>
        )}
      </div>
    </div>
  );
}

function DPadButton({
  children,
  onPress,
  label,
}: {
  children: React.ReactNode;
  onPress: () => void;
  label: string;
}) {
  return (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        onPress();
      }}
      aria-label={label}
      className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-slate-900/70 text-slate-200 backdrop-blur-xl transition-all hover:bg-white/10 active:scale-90 active:bg-white/20"
    >
      {children}
    </button>
  );
}
