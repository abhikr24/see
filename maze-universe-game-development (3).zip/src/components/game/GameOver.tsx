'use client';

import { Crosshair, Home, RotateCcw, TimerOff } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { formatElapsed } from '@/lib/game/timer';
import type { RunStats } from '@/lib/maze/types';

interface GameOverProps {
  open: boolean;
  stats: RunStats | null;
  headline?: string;
  subline?: string;
  retryLabel?: string;
  onRetry: () => void;
  onHome: () => void;
}

export function GameOver({
  open,
  stats,
  headline,
  subline,
  retryLabel = 'Try again',
  onRetry,
  onHome,
}: GameOverProps) {
  const reason = stats?.reason ?? 'time';
  const Icon = reason === 'enemy' ? Crosshair : TimerOff;
  const title =
    headline ?? (reason === 'enemy' ? 'HUNTED DOWN' : 'TIME COLLAPSED');
  const sub =
    subline ??
    (reason === 'enemy'
      ? 'The hunters of the maze claimed another wanderer.'
      : 'The corridor sealed itself before you escaped.');

  return (
    <Modal open={open} dismissible={false} size="sm">
      <div className="text-center">
        <span className="mx-auto flex h-16 w-16 animate-pulse items-center justify-center rounded-3xl bg-gradient-to-br from-rose-500 to-red-700 shadow-lg shadow-rose-500/40">
          <Icon className="h-8 w-8 text-white" />
        </span>
        <h2 className="mt-5 text-3xl font-black tracking-tight text-white">{title}</h2>
        <p className="mt-2 text-sm text-slate-400">{sub}</p>

        {stats && (
          <div className="mt-5 grid grid-cols-3 gap-2">
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
              <p className="text-base font-extrabold tabular-nums text-white">
                {formatElapsed(stats.time)}
              </p>
              <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Survived
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
              <p className="inline-flex items-center gap-1 text-base font-extrabold tabular-nums text-amber-300">
                <CoinIcon size={14} />
                {stats.coinsCollected}
              </p>
              <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Coins
              </p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
              <p className="text-base font-extrabold tabular-nums text-white">{stats.moves}</p>
              <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Moves
              </p>
            </div>
          </div>
        )}

        <div className="mt-6 flex flex-col gap-2.5">
          <Button size="lg" fullWidth variant="danger" icon={RotateCcw} onClick={onRetry}>
            {retryLabel}
          </Button>
          <Button variant="ghost" icon={Home} onClick={onHome}>
            Back to menu
          </Button>
        </div>
      </div>
    </Modal>
  );
}
