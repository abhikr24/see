'use client';

// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Game Session
//
// The orchestrator: owns the authoritative runtime state, steps the
// simulation each frame, resolves input, power-ups, hunters and gates —
// then hands the state to <MazeCanvas /> for rendering.
// ─────────────────────────────────────────────────────────────

import { useCallback, useMemo, useRef, useState } from 'react';
import { Flag, Key, Play, Sparkles, Timer as TimerIcon } from 'lucide-react';
import type {
  Direction,
  Enemy,
  KeyColor,
  LevelConfig,
  MazeGrid,
  Player,
  PowerUpId,
  RunStats,
  WorldConfig,
} from '@/lib/maze/types';
import { asKeyColor, KEY_PALETTE } from '@/lib/maze/types';
import {
  COMPASS_DURATION_MS,
  GHOST_DURATION_MS,
  MAP_REVEAL_DURATION_MS,
  SPEED_BOOST_DURATION_MS,
  TIME_FREEZE_DURATION_MS,
  GATE_INTERVAL_MS,
  POWERUPS,
  getSkin,
} from '@/lib/maze/constants';
import { generateMaze } from '@/lib/maze/generator';
import { findPath, nextStepToward } from '@/lib/maze/solver';
import { computeSlidePath, invertDirection, smashWall, wallTowardExit } from '@/lib/game/physics';
import { enemyHitsPlayer, resolveArrival, tryOpenDoor } from '@/lib/game/collision';
import { createEnemies, createPlayer, scatterEnemies, tickGates } from '@/lib/game/engine';
import { computeStars } from '@/lib/game/scoring';
import { MazeCanvas, type MazeCanvasHandle } from './MazeCanvas';
import type { RenderEffects } from './MazeRenderer';
import { PlayerController } from './PlayerController';
import { GameHUD } from './GameHUD';
import { PauseMenu } from './PauseMenu';
import { Button } from '@/components/ui/Button';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { useToast } from '@/components/ui/Toast';
import { useGameStore } from '@/stores/gameStore';
import { soundManager } from '@/lib/audio/soundManager';

export type { RunStats };

interface GameSessionProps {
  level: LevelConfig;
  world?: WorldConfig;
  color?: string;
  /** Eyebrow label shown in the HUD and intro card. */
  tag: string;
  onComplete: (stats: RunStats) => void;
  onGameOver: (stats: RunStats) => void;
  onExit: () => void;
}

interface Runtime {
  maze: MazeGrid;
  player: Player;
  enemies: Enemy[];
  slideQueue: Array<{ x: number; y: number }>;
  queuedDir: Direction | null;
  timeLeft: number;
  elapsed: number;
  moves: number;
  lastGateAt: number;
  hintUntil: number;
  hintComputedAt: number;
  revealUntil: number;
  freezeUntil: number;
  ghostUntil: number;
  speedUntil: number;
  shieldActive: boolean;
  invulnUntil: number;
  lastTickSecond: number;
}

type Phase = 'intro' | 'playing' | 'paused' | 'won' | 'dead';

const DIRS: Record<Direction, { dx: number; dy: number }> = {
  up: { dx: 0, dy: -1 },
  down: { dx: 0, dy: 1 },
  left: { dx: -1, dy: 0 },
  right: { dx: 1, dy: 0 },
};

export function GameSession({
  level,
  world,
  color,
  tag,
  onComplete,
  onGameOver,
  onExit,
}: GameSessionProps) {
  const playSfx = useSoundEffects();
  const { toast } = useToast();
  const settings = useGameStore((s) => s.progress.settings);
  const inventory = useGameStore((s) => s.progress.powerUps);
  const activeSkinId = useGameStore((s) => s.progress.activeSkin);
  const usePowerUp = useGameStore((s) => s.usePowerUp);
  const purchasePowerUp = useGameStore((s) => s.purchasePowerUp);
  const grantPowerUp = useGameStore((s) => s.grantPowerUp);
  const skin = useMemo(() => getSkin(activeSkinId), [activeSkinId]);

  const canvasRef = useRef<MazeCanvasHandle>(null);
  /** Swipe surface — the full-screen gameplay area. */
  const surfaceRef = useRef<HTMLDivElement>(null);

  // ── Runtime state (mutated in place; never triggers re-render) ──
  const build = useCallback((): Runtime => {
    const maze = generateMaze(level);
    return {
      maze,
      player: createPlayer(maze),
      enemies: createEnemies(maze, level.difficulty),
      slideQueue: [],
      queuedDir: null,
      timeLeft: level.timeLimit,
      elapsed: 0,
      moves: 0,
      lastGateAt: performance.now(),
      hintUntil: 0,
      hintComputedAt: 0,
      revealUntil: 0,
      freezeUntil: 0,
      ghostUntil: 0,
      speedUntil: 0,
      shieldActive: false,
      invulnUntil: 0,
      lastTickSecond: Math.ceil(level.timeLimit),
    };
  }, [level]);

  const rtRef = useRef<Runtime | null>(null);
  if (!rtRef.current) rtRef.current = build();

  /** Mutable effects object — the canvas reads it live every frame. */
  const effectsRef = useRef<RenderEffects>({
    revealAll: false,
    ghost: false,
    shield: false,
    frozen: false,
    speedBoost: false,
    hintPath: null,
  });

  const [phase, setPhase] = useState<Phase>('intro');
  const phaseRef = useRef<Phase>('intro');
  const setPhaseAll = useCallback((p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  }, []);

  // Structure version invalidates the renderer's cached wall layer.
  const [structureVersion, setStructureVersion] = useState(0);
  const bumpStructure = useCallback(() => setStructureVersion((v) => v + 1), []);

  // Throttled HUD refresh (the canvas animates independently).
  const [, setHudTick] = useState(0);
  const lastHudAt = useRef(0);
  const bumpHud = useCallback((force = false) => {
    const now = performance.now();
    if (force || now - lastHudAt.current > 150) {
      lastHudAt.current = now;
      setHudTick((v) => v + 1);
    }
  }, []);

  const completeRef = useRef(onComplete);
  completeRef.current = onComplete;
  const gameOverRef = useRef(onGameOver);
  gameOverRef.current = onGameOver;

  const haptic = useCallback(
    (ms: number) => {
      if (settings.hapticFeedback && typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(ms);
      }
    },
    [settings.hapticFeedback],
  );

  // ── Outcomes ──
  const die = useCallback(
    (reason: 'time' | 'enemy') => {
      const rt = rtRef.current!;
      if (phaseRef.current !== 'playing') return;
      setPhaseAll('dead');
      rt.player.alive = false;
      canvasRef.current?.shake(1);
      playSfx('lose');
      haptic(140);
      const stats: RunStats = {
        time: rt.elapsed,
        timeLeft: Math.max(0, rt.timeLeft),
        coinsCollected: rt.player.coins,
        totalCoins: rt.maze.coinsTotal,
        moves: rt.moves,
        stars: 0,
        victory: false,
        reason,
      };
      setTimeout(() => gameOverRef.current(stats), 900);
    },
    [haptic, playSfx, setPhaseAll],
  );

  const win = useCallback(() => {
    const rt = rtRef.current!;
    if (phaseRef.current !== 'playing') return;
    setPhaseAll('won');
    canvasRef.current?.victoryBurst(rt.maze.exit.x, rt.maze.exit.y);
    playSfx('win');
    haptic(60);
    const stars = computeStars(level, rt.elapsed, rt.player.coins, rt.maze.coinsTotal);
    const stats: RunStats = {
      time: rt.elapsed,
      timeLeft: Math.max(0, rt.timeLeft),
      coinsCollected: rt.player.coins,
      totalCoins: rt.maze.coinsTotal,
      moves: rt.moves,
      stars,
      victory: true,
    };
    setTimeout(() => completeRef.current(stats), 900);
  }, [haptic, level, playSfx, setPhaseAll]);

  // ── Movement ──
  const tryMove = useCallback(
    (dir: Direction) => {
      const rt = rtRef.current!;
      const now = performance.now();
      const p = rt.player;
      p.direction = dir;
      const ghost = now < rt.ghostUntil;
      const { dx, dy } = DIRS[dir];

      // Locked door in the way?
      const nextCell = rt.maze.cells[p.targetY + dy]?.[p.targetX + dx];
      if (nextCell?.type === 'door' && !ghost) {
        const lock = asKeyColor(nextCell.metadata?.lock);
        if (tryOpenDoor(rt.maze, p, dx, dy)) {
          playSfx('door');
          haptic(28);
          canvasRef.current?.keyBurst(p.targetX + dx, p.targetY + dy, lock);
          bumpStructure();
          bumpHud(true);
        } else {
          playSfx('bump');
          canvasRef.current?.bumpDust(p.targetX, p.targetY, dx, dy);
          canvasRef.current?.shake(0.2);
          toast({
            title: `${KEY_PALETTE[lock].label} door is locked`,
            message: `Find the ${KEY_PALETTE[lock].label.toLowerCase()} key.`,
            variant: 'warning',
          });
          bumpHud(true);
          return;
        }
      }

      const path = computeSlidePath(rt.maze, p.targetX, p.targetY, dir, ghost);
      if (path.length === 0) {
        playSfx('bump');
        canvasRef.current?.bumpDust(p.targetX, p.targetY, dx, dy);
        canvasRef.current?.shake(0.16);
        return;
      }

      rt.slideQueue = path;
      p.x = p.targetX;
      p.y = p.targetY;
      p.targetX = path[0].x;
      p.targetY = path[0].y;
      p.animProgress = 0;
      rt.moves += 1;
      playSfx(path.length > 1 ? 'slide' : 'move');
      haptic(8);
    },
    [bumpHud, bumpStructure, haptic, playSfx, toast],
  );

  const handleInput = useCallback(
    (raw: Direction) => {
      const rt = rtRef.current!;
      if (phaseRef.current === 'intro') {
        soundManager.unlock();
        setPhaseAll('playing');
        return;
      }
      if (phaseRef.current !== 'playing') return;
      const dir = level.variant === 'mirror' ? invertDirection(raw) : raw;
      // Buffer input while a move is still resolving — feels responsive.
      if (rt.slideQueue.length > 0 || rt.player.animProgress < 0.82) {
        rt.queuedDir = dir;
        return;
      }
      rt.queuedDir = null;
      tryMove(dir);
    },
    [level.variant, setPhaseAll, tryMove],
  );

  const doPause = useCallback(() => {
    if (phaseRef.current === 'playing') setPhaseAll('paused');
  }, [setPhaseAll]);

  // ── Power-up activation ──
  const activatePowerUp = useCallback(
    (id: PowerUpId) => {
      const rt = rtRef.current!;
      if (phaseRef.current !== 'playing') {
        toast({ title: 'Not now', message: 'Power-ups work while playing.', variant: 'info' });
        return;
      }
      const def = POWERUPS.find((p) => p.id === id)!;

      if (inventory[id] <= 0) {
        if (purchasePowerUp(id)) {
          toast({
            title: `${def.name} purchased`,
            message: `-${def.cost} coins · activated!`,
            variant: 'success',
          });
        } else {
          playSfx('bump');
          toast({
            title: 'Not enough coins',
            message: `${def.name} costs ${def.cost} coins.`,
            variant: 'error',
          });
          return;
        }
      } else {
        toast({ title: `${def.name} active`, variant: 'success' });
      }
      if (!usePowerUp(id)) return;

      const now = performance.now();
      const p = rt.player;
      canvasRef.current?.powerUpBurst(p.targetX, p.targetY, def.color);

      switch (id) {
        case 'compass':
          effectsRef.current.hintPath = findPath(
            rt.maze.cells,
            rt.maze.width,
            rt.maze.height,
            { x: p.targetX, y: p.targetY },
            rt.maze.exit,
          );
          rt.hintComputedAt = now;
          rt.hintUntil = now + COMPASS_DURATION_MS;
          playSfx('powerup');
          break;
        case 'mapReveal':
          rt.revealUntil = now + MAP_REVEAL_DURATION_MS;
          for (const row of rt.maze.cells) for (const c of row) c.visible = true;
          playSfx('powerup');
          break;
        case 'wallBreaker': {
          const dir = wallTowardExit(rt.maze, p.targetX, p.targetY, rt.maze.exit);
          if (dir) {
            smashWall(rt.maze, p.targetX, p.targetY, dir);
            bumpStructure();
          }
          playSfx('door');
          canvasRef.current?.shake(0.4);
          break;
        }
        case 'timeFreeze':
          rt.freezeUntil = now + TIME_FREEZE_DURATION_MS;
          playSfx('freeze');
          break;
        case 'ghostMode':
          rt.ghostUntil = now + GHOST_DURATION_MS;
          playSfx('powerup');
          break;
        case 'speedBoost':
          rt.speedUntil = now + SPEED_BOOST_DURATION_MS;
          playSfx('powerup');
          break;
        case 'shield':
          rt.shieldActive = true;
          playSfx('shield');
          break;
      }
      bumpHud(true);
    },
    [bumpHud, bumpStructure, inventory, playSfx, purchasePowerUp, toast, usePowerUp],
  );

  // ── Simulation step (called by MazeCanvas once per frame) ──
  const step = useCallback(
    (dt: number, now: number) => {
      const rt = rtRef.current!;
      const p = rt.player;
      const fx = effectsRef.current;

      const frozen = now < rt.freezeUntil;
      const boosted = now < rt.speedUntil;
      const ghost = now < rt.ghostUntil;

      // Keep the live effects object in sync for the renderer + HUD.
      fx.frozen = frozen;
      fx.speedBoost = boosted;
      fx.ghost = ghost;
      fx.shield = rt.shieldActive;
      fx.revealAll = now < rt.revealUntil;
      if (now >= rt.hintUntil) fx.hintPath = null;

      if (phaseRef.current !== 'playing') return;

      rt.elapsed += dt;

      // Timer
      if (!frozen) rt.timeLeft -= dt;
      if (rt.timeLeft <= 0) {
        rt.timeLeft = 0;
        die('time');
        return;
      }
      const sec = Math.ceil(rt.timeLeft);
      if (sec !== rt.lastTickSecond) {
        rt.lastTickSecond = sec;
        if (sec <= 5 && sec > 0) playSfx('tick');
      }

      // ── Movement resolution ──
      if (rt.slideQueue.length > 0) {
        const onIce = rt.maze.cells[p.y]?.[p.x]?.type === 'ice';
        // Spec: 120ms per tile. Ice slides faster, boost faster still.
        const perCell = boosted ? 0.075 : onIce ? 0.1 : 0.12;
        p.animProgress += dt / perCell;

        let guard = 0;
        while (p.animProgress >= 1 && guard++ < 24) {
          p.animProgress -= 1;
          p.x = p.targetX;
          p.y = p.targetY;

          const arrival = resolveArrival(rt.maze, p);

          if (arrival.coin) {
            canvasRef.current?.coinBurst(p.x, p.y);
            playSfx('coin');
            haptic(10);
            bumpHud(true);
          }
          if (arrival.key) {
            const lock = asKeyColor(arrival.keyColor);
            canvasRef.current?.keyBurst(p.x, p.y, lock);
            playSfx('key');
            toast({ title: `${KEY_PALETTE[lock].label} key found!`, variant: 'success' });
            bumpHud(true);
          }
          if (arrival.powerUp) {
            const def = POWERUPS.find((pu) => pu.id === arrival.powerUp);
            grantPowerUp(arrival.powerUp);
            canvasRef.current?.powerUpBurst(p.x, p.y, def?.color);
            playSfx('powerup');
            toast({
              title: `${def?.name ?? 'Power-up'} acquired!`,
              message: 'Added to your belt — tap to activate.',
              variant: 'success',
            });
            haptic(18);
            bumpHud(true);
          }
          if (arrival.teleported) {
            canvasRef.current?.teleportBurst(p.x, p.y);
            p.x = arrival.teleported.x;
            p.y = arrival.teleported.y;
            p.targetX = p.x;
            p.targetY = p.y;
            rt.slideQueue = [];
            p.animProgress = 1;
            rt.maze.cells[p.y][p.x].visited = true;
            canvasRef.current?.teleportBurst(p.x, p.y);
            playSfx('teleport');
            haptic(30);
            break;
          }

          rt.slideQueue.shift();

          if (arrival.win) {
            p.animProgress = 1;
            rt.slideQueue = [];
            win();
            return;
          }

          if (rt.slideQueue.length === 0) {
            p.animProgress = 1;
            if (rt.queuedDir) {
              const qd = rt.queuedDir;
              rt.queuedDir = null;
              tryMove(qd);
            }
            break;
          }
          p.targetX = rt.slideQueue[0].x;
          p.targetY = rt.slideQueue[0].y;
        }
      } else if (p.animProgress < 1) {
        p.animProgress = Math.min(1, p.animProgress + dt / 0.12);
      }

      // ── Hunters ──
      if (rt.enemies.length > 0) {
        for (const e of rt.enemies) {
          e.frozen = frozen;
          if (frozen) continue;
          if (e.animProgress < 1) e.animProgress = Math.min(1, e.animProgress + dt / 0.18);
          if (now - e.lastStep >= e.stepInterval && e.animProgress >= 0.7) {
            const next = nextStepToward(
              rt.maze.cells,
              rt.maze.width,
              rt.maze.height,
              { x: e.targetX, y: e.targetY },
              { x: p.targetX, y: p.targetY },
            );
            e.x = e.targetX;
            e.y = e.targetY;
            e.targetX = next.x;
            e.targetY = next.y;
            e.animProgress = 0;
            e.lastStep = now;
          }
        }

        if (!ghost && now >= rt.invulnUntil && enemyHitsPlayer(rt.enemies, p.targetX, p.targetY)) {
          if (rt.shieldActive) {
            rt.shieldActive = false;
            rt.invulnUntil = now + 1800;
            scatterEnemies(rt.enemies, now);
            canvasRef.current?.powerUpBurst(p.targetX, p.targetY, '#22d3ee');
            canvasRef.current?.shake(0.5);
            playSfx('shield');
            haptic(40);
            toast({ title: 'Shield absorbed the hit!', variant: 'success' });
            bumpHud(true);
          } else {
            die('enemy');
            return;
          }
        }
      }

      // ── Shifting gates ──
      if (rt.maze.gates.length > 0 && !frozen && now - rt.lastGateAt >= GATE_INTERVAL_MS) {
        rt.lastGateAt = now;
        const occupied = [
          { x: p.x, y: p.y },
          { x: p.targetX, y: p.targetY },
          ...rt.enemies.map((e) => ({ x: e.targetX, y: e.targetY })),
        ];
        if (tickGates(rt.maze, occupied)) {
          playSfx('gate');
          bumpStructure();
        }
      }

      // ── Compass follows the player ──
      if (fx.hintPath && now < rt.hintUntil && now - rt.hintComputedAt > 380) {
        if (rt.slideQueue.length === 0) {
          fx.hintPath = findPath(
            rt.maze.cells,
            rt.maze.width,
            rt.maze.height,
            { x: p.targetX, y: p.targetY },
            rt.maze.exit,
          );
          rt.hintComputedAt = now;
        }
      }

      bumpHud(false);
    },
    [bumpHud, bumpStructure, die, grantPowerUp, haptic, playSfx, toast, tryMove, win],
  );

  const restart = useCallback(() => {
    rtRef.current = build();
    effectsRef.current = {
      revealAll: false,
      ghost: false,
      shield: false,
      frozen: false,
      speedBoost: false,
      hintPath: null,
    };
    canvasRef.current?.reset();
    setPhaseAll('intro');
    bumpStructure();
    bumpHud(true);
  }, [build, bumpHud, bumpStructure, setPhaseAll]);

  const rt = rtRef.current;
  const fx = effectsRef.current;
  const heldKeys = Object.entries(rt.player.keys).filter(([, n]) => n > 0) as Array<
    [KeyColor, number]
  >;

  return (
    <div ref={surfaceRef} className="absolute inset-0 overflow-hidden bg-[#0a0f1e]">
      <MazeCanvas
        ref={canvasRef}
        maze={rt.maze}
        player={rt.player}
        enemies={rt.enemies}
        gameState={{
          isPlaying: phase === 'playing',
          isPaused: phase === 'paused',
          isComplete: phase === 'won',
          isDead: phase === 'dead',
        }}
        worldTheme={world}
        themeColor={color}
        skin={skin}
        effects={fx}
        structureVersion={structureVersion}
        showTrail
        onFrame={step}
      />

      <PlayerController
        containerRef={surfaceRef}
        onMove={handleInput}
        onPauseKey={doPause}
        enabled={phase === 'playing' || phase === 'intro'}
      />

      {phase !== 'intro' && (
        <GameHUD
          tag={tag}
          levelName={level.name}
          color={color ?? world?.color ?? '#38bdf8'}
          timeLeft={rt.timeLeft}
          timeLimit={level.timeLimit}
          showTimer={settings.showTimer}
          showMoves={settings.showMoveCount}
          coinsCollected={rt.player.coins}
          totalCoins={rt.maze.coinsTotal}
          moves={rt.moves}
          heldKeys={heldKeys}
          effects={{
            compass: fx.hintPath !== null,
            mapReveal: fx.revealAll,
            timeFreeze: fx.frozen,
            ghostMode: fx.ghost,
            speedBoost: fx.speedBoost,
            shield: fx.shield,
          }}
          inventory={inventory}
          onUsePowerUp={activatePowerUp}
          onPause={doPause}
          onMove={handleInput}
          showDPad={settings.controlMethod !== 'swipe'}
        />
      )}

      {/* Intro card */}
      {phase === 'intro' && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/60 p-5 backdrop-blur-sm">
          <div className="animate-pop-in w-full max-w-sm rounded-3xl border border-white/10 bg-slate-900/85 p-6 text-center shadow-2xl backdrop-blur-2xl">
            <p
              className="text-[10px] font-black uppercase tracking-[0.4em]"
              style={{ color: color ?? world?.color ?? '#38bdf8' }}
            >
              {tag}
            </p>
            <h1 className="mt-1.5 text-3xl font-black tracking-tight text-white">{level.name}</h1>
            <p className="mt-1 text-xs font-semibold uppercase tracking-widest text-slate-400">
              {level.variant} · {level.mazeWidth}×{level.mazeHeight} · {level.difficulty}
            </p>

            <div className="mt-5 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <Flag className="mx-auto h-5 w-5 text-emerald-400" />
                <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Reach exit
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <TimerIcon className="mx-auto h-5 w-5 text-blue-400" />
                <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {level.timeLimit}s limit
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                <Sparkles className="mx-auto h-5 w-5 text-amber-400" />
                <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {rt.maze.coinsTotal} coins
                </p>
              </div>
            </div>

            {(level.features.includes('keys') || level.features.includes('enemies')) && (
              <div className="mt-3 flex flex-wrap justify-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
                {level.features.includes('keys') && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-1 text-amber-300">
                    <Key className="h-3 w-3" /> Locked doors inside
                  </span>
                )}
                {level.features.includes('enemies') && (
                  <span className="rounded-full border border-rose-400/30 bg-rose-400/10 px-2.5 py-1 text-rose-300">
                    Hunters patrolling
                  </span>
                )}
              </div>
            )}

            <Button
              size="lg"
              fullWidth
              icon={Play}
              className="mt-6"
              onClick={() => {
                soundManager.unlock();
                playSfx('click');
                setPhaseAll('playing');
              }}
            >
              Tap to start
            </Button>
            <p className="mt-3 text-[11px] text-slate-500">
              Swipe · Arrow keys · or D-pad to move
            </p>
            <button
              onClick={onExit}
              className="mt-3 min-h-11 px-4 text-xs font-bold uppercase tracking-widest text-slate-500 transition-colors hover:text-slate-300"
            >
              Quit level
            </button>
          </div>
        </div>
      )}

      {phase === 'dead' && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center bg-rose-950/25">
          <p className="animate-pop-in text-4xl font-black tracking-widest text-rose-400 drop-shadow-[0_0_20px_rgba(244,63,94,0.8)]">
            SYSTEM FAILURE
          </p>
        </div>
      )}

      <PauseMenu
        open={phase === 'paused'}
        onResume={() => setPhaseAll('playing')}
        onRestart={restart}
        onQuit={onExit}
      />
    </div>
  );
}
