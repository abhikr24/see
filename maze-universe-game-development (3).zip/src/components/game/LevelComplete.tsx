'use client';

import { ArrowRight, Home, RotateCcw, TrendingUp } from 'lucide-react';
import { useMemo } from 'react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { StarRating } from '@/components/ui/StarRating';
import { CoinIcon } from '@/components/ui/CoinCounter';
import { formatElapsed } from '@/lib/game/timer';
import { starLabel } from '@/lib/game/scoring';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import type { RunStats } from '@/lib/maze/types';
import type { CompleteLevelSummary } from '@/stores/gameStore';
import { cn } from '@/lib/utils/helpers';

interface LevelCompleteProps {
  open: boolean;
  stats: RunStats | null;
  summary: CompleteLevelSummary | null;
  hasNext: boolean;
  nextLabel?: string;
  onNext?: () => void;
  onReplay: () => void;
  onHome: () => void;
}

export function LevelComplete({
  open,
  stats,
  summary,
  hasNext,
  nextLabel = 'Next level',
  onNext,
  onReplay,
  onHome,
}: LevelCompleteProps) {
  const playSfx = useSoundEffects();
  if (!stats) return <Modal open={open} dismissible={false} size="sm" />;
  return (
    <Modal open={open} dismissible={false} size="sm" className="overflow-hidden">
      {open && <Confetti intensity={stats.stars} />}

      <div className="relative text-center">
        <p className="text-[10px] font-black uppercase tracking-[0.45em] text-emerald-400">
          Level complete
        </p>
        <h2
          className={cn(
            'mt-2 text-4xl font-black tracking-tight',
            stats.stars === 3
              ? 'bg-gradient-to-br from-amber-200 via-yellow-400 to-orange-400 bg-clip-text text-transparent drop-shadow-[0_0_24px_rgba(251,191,36,0.4)]'
              : 'text-white',
          )}
        >
          {starLabel(stats.stars)}
        </h2>

        <StarRating
          stars={stats.stars}
          size="xl"
          animated
          className="mt-5 justify-center"
          onStarShown={(i) => {
            if (i < stats.stars) playSfx('star');
          }}
        />

        {summary?.newBest && (
          <span className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-blue-400/30 bg-blue-400/10 px-3 py-1 text-xs font-bold text-blue-300">
            <TrendingUp className="h-3.5 w-3.5" /> New personal best
          </span>
        )}

        <div className="mt-6 grid grid-cols-3 gap-2 text-center">
          <Stat label="Time" value={formatElapsed(stats.time)} mono />
          <Stat
            label="Coins"
            value={`${stats.coinsCollected}/${stats.totalCoins}`}
            mono
          />
          <Stat label="Moves" value={String(stats.moves)} mono />
        </div>

        {summary && (
          <div className="mt-3 flex items-center justify-center gap-4 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3">
            <span className="inline-flex items-center gap-1.5 text-sm font-bold text-amber-300">
              <CoinIcon size={18} /> +{summary.coinsEarned}
            </span>
            <span className="h-4 w-px bg-white/10" />
            <span className="text-sm font-bold text-violet-300">+{summary.xpEarned} XP</span>
            {summary.leveledTo > 0 && (
              <>
                <span className="h-4 w-px bg-white/10" />
                <span className="animate-coin-pop text-sm font-black text-emerald-300">
                  LEVEL {summary.leveledTo}!
                </span>
              </>
            )}
          </div>
        )}

        {summary && summary.newlyUnlockedWorlds.length > 0 && (
          <p className="mt-3 text-xs font-bold uppercase tracking-widest text-fuchsia-300">
            New world unlocked!
          </p>
        )}

        <div className="mt-6 flex flex-col gap-2.5">
          {hasNext && onNext && (
            <Button size="lg" fullWidth iconRight={ArrowRight} onClick={onNext}>
              {nextLabel}
            </Button>
          )}
          <div className="grid grid-cols-2 gap-2.5">
            <Button variant="ghost" icon={RotateCcw} onClick={onReplay}>
              Replay
            </Button>
            <Button variant="ghost" icon={Home} onClick={onHome}>
              Menu
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function Stat({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
      <p className={cn('text-base font-extrabold text-white', mono && 'tabular-nums')}>{value}</p>
      <p className="mt-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
        {label}
      </p>
    </div>
  );
}

/** Lightweight DOM confetti burst. */
function Confetti({ intensity }: { intensity: number }) {
  const pieces = useMemo(() => {
    const n = 20 + intensity * 14;
    const colors = ['#3b82f6', '#8b5cf6', '#10b981', '#fbbf24', '#f472b6', '#22d3ee'];
    return Array.from({ length: n }, (_, i) => ({
      left: (i * 997) % 100,
      delay: ((i * 613) % 100) / 100,
      dur: 2.2 + ((i * 431) % 100) / 55,
      size: 6 + ((i * 271) % 8),
      color: colors[i % colors.length],
      rot: (i * 173) % 360,
    }));
  }, [intensity]);

  return (
    <div className="pointer-events-none absolute inset-x-0 -top-6 bottom-0 overflow-hidden" aria-hidden>
      {pieces.map((p, i) => (
        <span
          key={i}
          className="animate-confetti absolute top-[-12px] rounded-[2px]"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 0.62,
            background: p.color,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.dur}s`,
            transform: `rotate(${p.rot}deg)`,
          }}
        />
      ))}
    </div>
  );
}
