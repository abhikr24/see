'use client';

// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · MazeCanvas
//
// The React surface for the rendering engine. It owns:
//   • a device-pixel-ratio aware <canvas> that fills its container
//   • the single requestAnimationFrame loop (render + optional sim step)
//   • lifecycle (start / stop / pause) and resize observation
//   • touch-gesture suppression so the page never scrolls mid-run
//   • an imperative handle for firing particle effects
//
// All drawing lives in MazeRenderer; this component is the host.
// ─────────────────────────────────────────────────────────────

import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
} from 'react';
import type {
  Enemy,
  GameState,
  KeyColor,
  MazeGrid,
  Player,
  SkinDef,
  WorldConfig,
} from '@/lib/maze/types';
import { KEY_PALETTE } from '@/lib/maze/types';
import { MazeRenderer, NO_EFFECTS, resolveTheme } from './MazeRenderer';
import type { Layout, RenderEffects } from './MazeRenderer';
import { getSkin } from '@/lib/maze/constants';
import { cn } from '@/lib/utils/helpers';

/**
 * Subset of GameState the canvas needs. A full `GameState` is structurally
 * assignable, so callers may pass one directly.
 */
export type CanvasGameState = Pick<
  GameState,
  'isPlaying' | 'isPaused' | 'isComplete' | 'isDead'
>;

export interface MazeCanvasProps {
  maze: MazeGrid;
  player: Player;
  gameState: CanvasGameState;
  /** World theme. Omit for Daily/Endless and pass `themeColor` instead. */
  worldTheme?: WorldConfig | null;
  /** Accent override used by Daily Challenge and Endless floors. */
  themeColor?: string;
  enemies?: Enemy[];
  skin?: SkinDef;
  effects?: RenderEffects;
  /** Draw the player's breadcrumb trail. */
  showTrail?: boolean;
  /** Increment whenever walls change (gates, wall breaker) to rebuild caches. */
  structureVersion?: number;
  /** Fired once each time the player settles onto a new cell. */
  onCellReached?: (x: number, y: number) => void;
  /** Simulation step, invoked before rendering while the game is running. */
  onFrame?: (dt: number, now: number) => void;
  className?: string;
}

/** Imperative surface for triggering juice from the game session. */
export interface MazeCanvasHandle {
  coinBurst: (x: number, y: number) => void;
  keyBurst: (x: number, y: number, color: KeyColor) => void;
  victoryBurst: (x: number, y: number) => void;
  bumpDust: (x: number, y: number, dx: number, dy: number) => void;
  powerUpBurst: (x: number, y: number, color?: string) => void;
  teleportBurst: (x: number, y: number) => void;
  shake: (amount: number) => void;
  reset: () => void;
  getLayout: () => Layout | null;
}

export const MazeCanvas = forwardRef<MazeCanvasHandle, MazeCanvasProps>(function MazeCanvas(
  props,
  ref,
) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<MazeRenderer | null>(null);

  // Props are read from a ref inside the loop so that mutable game objects
  // (the runtime player/maze) stay live without forcing React re-renders.
  const propsRef = useRef(props);
  propsRef.current = props;

  const lastCellRef = useRef<string>('');

  // ── Canvas sizing (devicePixelRatio aware) ──
  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;

    const applySize = () => {
      const rect = wrap.getBoundingClientRect();
      const cssW = Math.max(1, rect.width);
      const cssH = Math.max(1, rect.height);
      const dpr = Math.min(3, Math.max(1, window.devicePixelRatio || 1));

      canvas.width = Math.floor(cssW * dpr);
      canvas.height = Math.floor(cssH * dpr);
      canvas.style.width = `${cssW}px`;
      canvas.style.height = `${cssH}px`;

      const ctx = canvas.getContext('2d', { alpha: false });
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      if (!rendererRef.current) rendererRef.current = new MazeRenderer(ctx);
      else rendererRef.current.setContext(ctx);
      rendererRef.current.resize(cssW, cssH, dpr);
    };

    applySize();
    const ro = new ResizeObserver(applySize);
    ro.observe(wrap);
    window.addEventListener('orientationchange', applySize);
    return () => {
      ro.disconnect();
      window.removeEventListener('orientationchange', applySize);
    };
  }, []);

  // ── Suppress native touch scrolling / pinch during play ──
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const stop = (e: TouchEvent) => {
      if (e.cancelable) e.preventDefault();
    };
    el.addEventListener('touchstart', stop, { passive: false });
    el.addEventListener('touchmove', stop, { passive: false });
    return () => {
      el.removeEventListener('touchstart', stop);
      el.removeEventListener('touchmove', stop);
    };
  }, []);

  // ── The single animation loop ──
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let disposed = false;

    const frame = (now: number) => {
      if (disposed) return;
      const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
      last = now;

      const p = propsRef.current;
      const renderer = rendererRef.current;

      // Simulation first, so rendering always reflects the newest state.
      if (!p.gameState.isPaused) p.onFrame?.(dt, now);

      if (renderer) {
        renderer.render({
          maze: p.maze,
          player: p.player,
          enemies: p.enemies ?? [],
          theme: resolveTheme(p.worldTheme, p.themeColor),
          skin: p.skin ?? getSkin('default'),
          effects: p.effects ?? NO_EFFECTS,
          now,
          dt,
          structureVersion: p.structureVersion ?? 0,
          showTrail: p.showTrail ?? true,
        });
      }

      // Report settled cell transitions exactly once.
      if (p.onCellReached && p.player.animProgress >= 1) {
        const key = `${p.player.targetX},${p.player.targetY}`;
        if (key !== lastCellRef.current) {
          lastCellRef.current = key;
          p.onCellReached(p.player.targetX, p.player.targetY);
        }
      }

      raf = requestAnimationFrame(frame);
    };

    raf = requestAnimationFrame(frame);
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
    };
  }, []);

  // ── Imperative effects API ──
  const emit = useCallback(
    (fn: (r: MazeRenderer) => void) => {
      const r = rendererRef.current;
      if (r) fn(r);
    },
    [],
  );

  useImperativeHandle(
    ref,
    (): MazeCanvasHandle => ({
      coinBurst: (x, y) => emit((r) => r.particles.emitCoin(x + 0.5, y + 0.5)),
      keyBurst: (x, y, color) =>
        emit((r) => r.particles.emitKey(x + 0.5, y + 0.5, KEY_PALETTE[color].base)),
      victoryBurst: (x, y) => emit((r) => r.particles.emitVictory(x + 0.5, y + 0.5)),
      bumpDust: (x, y, dx, dy) => emit((r) => r.particles.emitBump(x + 0.5, y + 0.5, dx, dy)),
      powerUpBurst: (x, y, color = '#2dd4bf') =>
        emit((r) => r.particles.emitPowerUp(x + 0.5, y + 0.5, color)),
      teleportBurst: (x, y) => emit((r) => r.particles.emitTeleport(x + 0.5, y + 0.5)),
      shake: (amount) => emit((r) => r.addShake(amount)),
      reset: () => emit((r) => r.reset()),
      getLayout: () => rendererRef.current?.getLayout() ?? null,
    }),
    [emit],
  );

  return (
    <div
      ref={wrapRef}
      className={cn('absolute inset-0 overflow-hidden bg-[#0a0f1e]', props.className)}
      style={{ touchAction: 'none', WebkitUserSelect: 'none', userSelect: 'none' }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 block" />
    </div>
  );
});
