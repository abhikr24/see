'use client';

// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Canvas Rendering Engine
//
// A stateful renderer that owns everything visual: layout, camera,
// layer caching, particles, fog-of-war and screen shake.
//
// Performance architecture
//   • STATIC LAYER  — floor texture + walls are rasterised once into an
//                     offscreen canvas and blitted each frame. Rebuilt only
//                     when the cell size or the maze structure changes.
//   • VIEWPORT CULL — dynamic tiles iterate only the visible cell range.
//   • FOG PATH      — the expensive offscreen composite is used *only* when
//                     fog is active; lit worlds draw straight to the screen.
//   • NO ALLOCATION — no per-frame object/array churn in the hot loop.
// ─────────────────────────────────────────────────────────────

import type {
  Cell,
  Enemy,
  KeyColor,
  MazeGrid,
  Player,
  SkinDef,
  WorldConfig,
} from '@/lib/maze/types';
import { KEY_PALETTE, asKeyColor } from '@/lib/maze/types';
import { ParticleSystem } from '@/lib/game/particles';
import { clamp, lerp, easeOutCubic } from '@/lib/utils/helpers';

// ═════════════════════════════════════════════════════════════
// Layout constants
// ═════════════════════════════════════════════════════════════

/** Smallest readable cell. Below this the camera starts scrolling. */
export const MIN_CELL = 28;
/** Largest cell — keeps tiny mazes from looking like a toy board. */
export const MAX_CELL = 60;
/** Mazes larger than this on either axis always use a follow-camera. */
export const FOLLOW_THRESHOLD = 15;

const TAU = Math.PI * 2;
const CANVAS_PAD = 10;

// ═════════════════════════════════════════════════════════════
// Theming
// ═════════════════════════════════════════════════════════════

export interface RenderTheme {
  /** Crisp wall stroke colour. */
  wall: string;
  /** Outer glow colour bled around walls. */
  wallGlow: string;
  /** Glow strength in pixels. */
  glowBlur: number;
  /** Background gradient. */
  bgTop: string;
  bgBottom: string;
  /** Floor plate colour (slightly lighter than the background). */
  floor: string;
  /** Faint grid/noise ink. */
  floorInk: string;
  /** World accent used for visited paint and board edging. */
  accent: string;
  /** Crystalline sparkle overlay (Ice Kingdom). */
  sparkle: boolean;
  /** Pure-black backdrop (Shadow Realm). */
  voidBlack: boolean;
}

const DEFAULT_THEME: RenderTheme = {
  wall: '#dbeafe',
  wallGlow: 'rgba(59,130,246,0.55)',
  glowBlur: 10,
  bgTop: '#0a0f1e',
  bgBottom: '#070b16',
  floor: '#111a30',
  floorInk: 'rgba(148,163,184,0.10)',
  accent: '#3b82f6',
  sparkle: false,
  voidBlack: false,
};

/** Hand-tuned per-world looks. Worlds not listed derive from their config. */
const WORLD_THEMES: Record<number, Partial<RenderTheme>> = {
  1: {
    wall: '#f1f6ff',
    wallGlow: 'rgba(96,165,250,0.5)',
    glowBlur: 9,
    bgTop: '#0b1328',
    bgBottom: '#070d1c',
    floor: '#121c35',
    accent: '#3b82f6',
  },
  2: {
    wall: '#a78bfa',
    wallGlow: 'rgba(139,92,246,0.85)',
    glowBlur: 16,
    bgTop: '#000000',
    bgBottom: '#000000',
    floor: '#0a0612',
    floorInk: 'rgba(167,139,250,0.10)',
    accent: '#8b5cf6',
    voidBlack: true,
  },
  3: {
    wall: '#fcd34d',
    wallGlow: 'rgba(245,158,11,0.6)',
    glowBlur: 11,
    bgTop: '#1a1206',
    bgBottom: '#0d0903',
    floor: '#241a08',
    floorInk: 'rgba(252,211,77,0.10)',
    accent: '#f59e0b',
  },
  4: {
    wall: '#cffafe',
    wallGlow: 'rgba(34,211,238,0.7)',
    glowBlur: 14,
    bgTop: '#06212e',
    bgBottom: '#03121c',
    floor: '#0a2a3a',
    floorInk: 'rgba(186,230,253,0.14)',
    accent: '#22d3ee',
    sparkle: true,
  },
  5: {
    wall: '#f5d0fe',
    wallGlow: 'rgba(232,121,249,0.75)',
    glowBlur: 15,
    bgTop: '#1a0a20',
    bgBottom: '#0c0410',
    floor: '#210d2a',
    floorInk: 'rgba(240,171,252,0.12)',
    accent: '#e879f9',
  },
  6: {
    wall: '#fecaca',
    wallGlow: 'rgba(239,68,68,0.7)',
    glowBlur: 13,
    bgTop: '#1c0708',
    bgBottom: '#0b0304',
    floor: '#260a0c',
    floorInk: 'rgba(254,202,202,0.10)',
    accent: '#ef4444',
  },
  7: {
    wall: '#fed7aa',
    wallGlow: 'rgba(251,146,60,0.6)',
    glowBlur: 12,
    bgTop: '#1a1008',
    bgBottom: '#0c0704',
    floor: '#241608',
    accent: '#fb923c',
  },
  8: {
    wall: '#a7f3d0',
    wallGlow: 'rgba(16,185,129,0.65)',
    glowBlur: 12,
    bgTop: '#04201a',
    bgBottom: '#02110e',
    floor: '#07291f',
    accent: '#34d399',
  },
  9: {
    wall: '#ddd6fe',
    wallGlow: 'rgba(167,139,250,0.75)',
    glowBlur: 16,
    bgTop: '#0f0820',
    bgBottom: '#06030f',
    floor: '#160c2c',
    accent: '#a78bfa',
    sparkle: true,
  },
  10: {
    wall: '#fbcfe8',
    wallGlow: 'rgba(244,114,182,0.7)',
    glowBlur: 15,
    bgTop: '#1a0a1a',
    bgBottom: '#0a040a',
    floor: '#230e23',
    accent: '#f472b6',
    sparkle: true,
  },
};

/** Converts `#rrggbb` to `rgba()` with the given alpha. */
function rgba(hex: string, alpha: number): string {
  const h = hex.replace('#', '');
  const v = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
  const r = parseInt(v.slice(0, 2), 16);
  const g = parseInt(v.slice(2, 4), 16);
  const b = parseInt(v.slice(4, 6), 16);
  if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b)) return `rgba(148,163,184,${alpha})`;
  return `rgba(${r},${g},${b},${alpha})`;
}

/**
 * Builds the render theme for a world, optionally tinted by an override
 * colour (used by Daily Challenge and Endless floors).
 */
export function resolveTheme(world?: WorldConfig | null, override?: string): RenderTheme {
  const preset = world ? WORLD_THEMES[world.id] : undefined;
  const base: RenderTheme = { ...DEFAULT_THEME, ...(preset ?? {}) };
  if (!preset && world) {
    base.wall = world.gradientTo;
    base.wallGlow = rgba(world.color, 0.6);
    base.accent = world.color;
  }
  if (override) {
    base.wall = override;
    base.wallGlow = rgba(override, 0.65);
    base.accent = override;
  }
  return base;
}

// ═════════════════════════════════════════════════════════════
// Frame contract
// ═════════════════════════════════════════════════════════════

export interface RenderEffects {
  /** Map Reveal — lifts the fog entirely. */
  revealAll: boolean;
  /** Ghost Mode — player is translucent and phases through walls. */
  ghost: boolean;
  /** Hunter Shield — dashed ring around the player. */
  shield: boolean;
  /** Time Freeze — icy vignette, hunters crystallised. */
  frozen: boolean;
  /** Speed Boost — motion streaks. */
  speedBoost: boolean;
  /** Compass — golden breadcrumb trail to the exit. */
  hintPath: Array<{ x: number; y: number }> | null;
}

export const NO_EFFECTS: RenderEffects = {
  revealAll: false,
  ghost: false,
  shield: false,
  frozen: false,
  speedBoost: false,
  hintPath: null,
};

export interface RenderFrame {
  maze: MazeGrid;
  player: Player;
  enemies: Enemy[];
  theme: RenderTheme;
  skin: SkinDef;
  effects: RenderEffects;
  /** Timestamp in ms (performance.now). */
  now: number;
  /** Delta time in seconds. */
  dt: number;
  /** Bump to invalidate the cached wall/floor layer. */
  structureVersion: number;
  /** Draw the player's breadcrumb trail. */
  showTrail: boolean;
}

/** Live layout snapshot, exposed for hit-testing and debugging. */
export interface Layout {
  cell: number;
  ox: number;
  oy: number;
  follow: boolean;
}

// ═════════════════════════════════════════════════════════════
// Renderer
// ═════════════════════════════════════════════════════════════

export class MazeRenderer {
  private ctx: CanvasRenderingContext2D;
  private cssW = 0;
  private cssH = 0;
  private dpr = 1;

  /** Cached floor + wall raster, in world pixels. */
  private staticLayer: HTMLCanvasElement | null = null;
  private staticKey = '';

  /** Offscreen buffers used only on the fog path. */
  private worldLayer: HTMLCanvasElement | null = null;
  private maskLayer: HTMLCanvasElement | null = null;

  /** Repeating noise tile that gives the floor its texture. */
  private noise: CanvasPattern | null = null;

  private camX = 0;
  private camY = 0;
  private camReady = false;

  private shakeAmount = 0;

  readonly particles = new ParticleSystem();

  private layout: Layout = { cell: MIN_CELL, ox: 0, oy: 0, follow: false };

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
    this.noise = this.buildNoisePattern();
  }

  /** Swaps in a new context (canvas remount). */
  setContext(ctx: CanvasRenderingContext2D): void {
    this.ctx = ctx;
    this.noise = this.buildNoisePattern();
    this.staticLayer = null;
    this.staticKey = '';
  }

  /** Updates the backing-store size. Invalidates size-dependent caches. */
  resize(cssW: number, cssH: number, dpr: number): void {
    this.cssW = cssW;
    this.cssH = cssH;
    this.dpr = dpr;
    this.worldLayer = null;
    this.maskLayer = null;
  }

  /** Current layout (cell size + world origin). */
  getLayout(): Layout {
    return this.layout;
  }

  /** Adds screen shake (0–1). */
  addShake(amount: number): void {
    this.shakeAmount = Math.min(1, this.shakeAmount + amount);
  }

  /** Clears transient visual state between runs. */
  reset(): void {
    this.particles.clear();
    this.camReady = false;
    this.shakeAmount = 0;
    this.staticKey = '';
  }

  /** Converts a cell coordinate to canvas pixels (for particle emission). */
  cellCenter(x: number, y: number): { x: number; y: number } {
    return { x: x + 0.5, y: y + 0.5 };
  }

  // ── Noise texture ──────────────────────────────────────────

  /**
   * Builds a small deterministic noise tile. Gives the floor a subtle
   * grain so it never reads as flat colour.
   */
  private buildNoisePattern(): CanvasPattern | null {
    if (typeof document === 'undefined') return null;
    const size = 64;
    const c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    const g = c.getContext('2d');
    if (!g) return null;

    // Deterministic LCG so the grain never shimmers between rebuilds.
    let s = 0x2f6e2b1;
    const rnd = () => {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 0x100000000;
    };

    const img = g.createImageData(size, size);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = rnd();
      const a = v > 0.86 ? 26 : v > 0.7 ? 12 : 0;
      img.data[i] = 255;
      img.data[i + 1] = 255;
      img.data[i + 2] = 255;
      img.data[i + 3] = a;
    }
    g.putImageData(img, 0, 0);
    return this.ctx.createPattern(c, 'repeat');
  }

  // ── Layout & camera ────────────────────────────────────────

  /**
   * Computes cell size and camera offset for this frame.
   *
   * Small mazes are centred and static; large mazes (or any fogged maze)
   * get a smoothly lerping follow-camera that leads the player slightly in
   * their direction of travel.
   */
  private updateLayout(frame: RenderFrame): void {
    const { maze, player } = frame;
    const fogged = maze.fogRadius < 90 && !frame.effects.revealAll;

    const fitCell = Math.min(
      (this.cssW - CANVAS_PAD * 2) / maze.width,
      (this.cssH - CANVAS_PAD * 2) / maze.height,
    );
    const cell = Math.max(MIN_CELL, Math.min(MAX_CELL, Math.floor(fitCell)));

    const worldW = cell * maze.width;
    const worldH = cell * maze.height;
    const fits = worldW <= this.cssW - CANVAS_PAD && worldH <= this.cssH - CANVAS_PAD;
    const big = maze.width > FOLLOW_THRESHOLD || maze.height > FOLLOW_THRESHOLD;
    const follow = fogged || big || !fits;

    let targetX: number;
    let targetY: number;

    if (!follow) {
      targetX = (this.cssW - worldW) / 2;
      targetY = (this.cssH - worldH) / 2;
    } else {
      const ease = this.visualProgress(frame);
      const px = (lerp(player.x, player.targetX, ease) + 0.5) * cell;
      const py = (lerp(player.y, player.targetY, ease) + 0.5) * cell;

      // Lead the camera into the direction of travel.
      const lead = cell * 1.15;
      const lx = player.direction === 'left' ? -lead : player.direction === 'right' ? lead : 0;
      const ly = player.direction === 'up' ? -lead : player.direction === 'down' ? lead : 0;

      targetX = this.cssW / 2 - (px + lx);
      targetY = this.cssH / 2 - (py + ly);

      // Clamp so we never show empty space beyond the board.
      targetX = worldW <= this.cssW
        ? (this.cssW - worldW) / 2
        : clamp(targetX, this.cssW - worldW, 0);
      targetY = worldH <= this.cssH
        ? (this.cssH - worldH) / 2
        : clamp(targetY, this.cssH - worldH, 0);
    }

    if (!this.camReady) {
      this.camX = targetX;
      this.camY = targetY;
      this.camReady = true;
    } else {
      // Frame-rate independent equivalent of "lerp 0.1 per 60fps frame".
      const k = 1 - Math.pow(0.9, Math.max(0.0001, frame.dt) * 60);
      this.camX += (targetX - this.camX) * k;
      this.camY += (targetY - this.camY) * k;
    }

    this.layout = { cell, ox: this.camX, oy: this.camY, follow };
  }

  /** Eased animation progress — linear while sliding on ice. */
  private visualProgress(frame: RenderFrame): number {
    const { player, maze } = frame;
    const onIce = maze.cells[player.y]?.[player.x]?.type === 'ice';
    const t = clamp(player.animProgress, 0, 1);
    return onIce ? t : easeOutCubic(t);
  }

  // ── Static layer (floor + walls) ───────────────────────────

  /**
   * Rasterises floor texture and walls once, then reuses the bitmap every
   * frame. This is what keeps big mazes at a locked 60fps.
   */
  private ensureStaticLayer(frame: RenderFrame): void {
    const { maze, theme } = frame;
    const { cell } = this.layout;
    const key = `${maze.width}x${maze.height}:${cell}:${frame.structureVersion}:${theme.wall}:${this.dpr}`;
    if (this.staticLayer && this.staticKey === key) return;

    const worldW = cell * maze.width;
    const worldH = cell * maze.height;
    const canvas = this.staticLayer ?? document.createElement('canvas');
    canvas.width = Math.ceil(worldW * this.dpr);
    canvas.height = Math.ceil(worldH * this.dpr);
    const g = canvas.getContext('2d');
    if (!g) return;
    g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    g.clearRect(0, 0, worldW, worldH);

    // ── Floor plate ──
    g.fillStyle = theme.floor;
    this.roundRect(g, 0, 0, worldW, worldH, Math.min(18, cell * 0.4));
    g.fill();

    // Noise grain for depth.
    if (this.noise) {
      g.save();
      g.globalAlpha = 0.55;
      g.fillStyle = this.noise;
      g.fillRect(0, 0, worldW, worldH);
      g.restore();
    }

    // Faint per-cell grid — reads as tiling, not as a wireframe.
    g.strokeStyle = theme.floorInk;
    g.lineWidth = 1;
    g.beginPath();
    for (let x = 1; x < maze.width; x++) {
      g.moveTo(Math.round(x * cell) + 0.5, 0);
      g.lineTo(Math.round(x * cell) + 0.5, worldH);
    }
    for (let y = 1; y < maze.height; y++) {
      g.moveTo(0, Math.round(y * cell) + 0.5);
      g.lineTo(worldW, Math.round(y * cell) + 0.5);
    }
    g.stroke();

    // ── Terrain tile bases ──
    for (let y = 0; y < maze.height; y++) {
      for (let x = 0; x < maze.width; x++) {
        const c = maze.cells[y][x];
        if (c.type === 'ice') this.paintIceBase(g, x * cell, y * cell, cell);
        else if (c.type === 'sticky') this.paintStickyBase(g, x * cell, y * cell, cell);
      }
    }

    // ── Walls ──
    // Pass 1: wide, blurred glow. Pass 2: crisp stroke.
    const inner = Math.max(2, cell * 0.07);
    const outer = Math.max(3, cell * 0.1);

    for (const pass of ['glow', 'solid'] as const) {
      g.save();
      g.lineCap = 'round';
      g.lineJoin = 'round';
      if (pass === 'glow') {
        g.strokeStyle = theme.wallGlow;
        g.shadowColor = theme.wallGlow;
        g.shadowBlur = theme.glowBlur;
        g.globalAlpha = 0.9;
      } else {
        g.strokeStyle = theme.wall;
        g.shadowBlur = 0;
      }

      // Inner walls.
      g.lineWidth = inner;
      g.beginPath();
      for (let y = 0; y < maze.height; y++) {
        for (let x = 0; x < maze.width; x++) {
          const c = maze.cells[y][x];
          const px = x * cell;
          const py = y * cell;
          if (c.walls.top && y > 0) {
            g.moveTo(px, py);
            g.lineTo(px + cell, py);
          }
          if (c.walls.left && x > 0) {
            g.moveTo(px, py);
            g.lineTo(px, py + cell);
          }
        }
      }
      g.stroke();

      // Outer border — thicker, framing the board.
      g.lineWidth = outer;
      g.beginPath();
      this.roundRect(g, 0, 0, worldW, worldH, Math.min(14, cell * 0.3));
      g.stroke();
      g.restore();
    }

    this.staticLayer = canvas;
    this.staticKey = key;
  }

  /** Crystalline ice base: pale wash plus refracted facets. */
  private paintIceBase(g: CanvasRenderingContext2D, px: number, py: number, cell: number): void {
    g.save();
    const grad = g.createLinearGradient(px, py, px + cell, py + cell);
    grad.addColorStop(0, 'rgba(186,230,253,0.26)');
    grad.addColorStop(0.5, 'rgba(103,232,249,0.14)');
    grad.addColorStop(1, 'rgba(224,242,254,0.24)');
    g.fillStyle = grad;
    g.fillRect(px, py, cell, cell);
    g.strokeStyle = 'rgba(224,242,254,0.4)';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(px + cell * 0.16, py + cell * 0.8);
    g.lineTo(px + cell * 0.82, py + cell * 0.2);
    g.moveTo(px + cell * 0.5, py + cell * 0.86);
    g.lineTo(px + cell * 0.86, py + cell * 0.52);
    g.stroke();
    g.restore();
  }

  /** Sticky tar base: rough, matte, obviously *not* ice. */
  private paintStickyBase(g: CanvasRenderingContext2D, px: number, py: number, cell: number): void {
    g.save();
    g.fillStyle = 'rgba(120,53,15,0.55)';
    g.fillRect(px, py, cell, cell);
    g.fillStyle = 'rgba(69,26,3,0.6)';
    let s = ((px * 73856093) ^ (py * 19349663)) >>> 0;
    const rnd = () => {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 0x100000000;
    };
    for (let i = 0; i < 7; i++) {
      const bx = px + rnd() * cell;
      const by = py + rnd() * cell;
      g.beginPath();
      g.arc(bx, by, cell * (0.04 + rnd() * 0.07), 0, TAU);
      g.fill();
    }
    g.restore();
  }

  // ── Public entry point ─────────────────────────────────────

  /**
   * Draws one complete frame.
   * Safe to call while paused — animations simply keep breathing.
   */
  render(frame: RenderFrame): void {
    if (this.cssW <= 0 || this.cssH <= 0) return;

    this.particles.update(frame.dt);
    if (this.shakeAmount > 0) {
      this.shakeAmount = Math.max(0, this.shakeAmount - frame.dt * 2.4);
    }

    this.updateLayout(frame);
    this.ensureStaticLayer(frame);

    const fogged = frame.maze.fogRadius < 90 && !frame.effects.revealAll;
    const main = this.ctx;

    main.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    main.clearRect(0, 0, this.cssW, this.cssH);

    if (fogged) {
      // Pure black beneath — anything the torch misses stays invisible.
      main.fillStyle = '#000000';
      main.fillRect(0, 0, this.cssW, this.cssH);

      const world = this.ensureBuffer('world');
      const wctx = world?.getContext('2d');
      if (!world || !wctx) return;
      wctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      wctx.clearRect(0, 0, this.cssW, this.cssH);

      this.drawScene(wctx, frame);
      this.applyFogMask(wctx, frame);

      main.drawImage(world, 0, 0, this.cssW, this.cssH);
    } else {
      this.drawScene(main, frame);
    }

    this.drawVignette(main, frame);
  }

  /** Lazily allocates a full-canvas offscreen buffer. */
  private ensureBuffer(which: 'world' | 'mask'): HTMLCanvasElement | null {
    if (typeof document === 'undefined') return null;
    const existing = which === 'world' ? this.worldLayer : this.maskLayer;
    const w = Math.ceil(this.cssW * this.dpr);
    const h = Math.ceil(this.cssH * this.dpr);
    if (existing && existing.width === w && existing.height === h) return existing;

    const c = existing ?? document.createElement('canvas');
    c.width = w;
    c.height = h;
    if (which === 'world') this.worldLayer = c;
    else this.maskLayer = c;
    return c;
  }

  // ── Scene composition ──────────────────────────────────────

  /** Background + board + tiles + actors, in draw order. */
  private drawScene(g: CanvasRenderingContext2D, frame: RenderFrame): void {
    const { theme } = frame;
    const { cell } = this.layout;

    // Background gradient.
    const bg = g.createLinearGradient(0, 0, 0, this.cssH);
    bg.addColorStop(0, theme.bgTop);
    bg.addColorStop(1, theme.bgBottom);
    g.fillStyle = bg;
    g.fillRect(0, 0, this.cssW, this.cssH);

    if (!theme.voidBlack) {
      // Soft world-coloured aura behind the board.
      const aura = g.createRadialGradient(
        this.cssW / 2,
        this.cssH / 2,
        0,
        this.cssW / 2,
        this.cssH / 2,
        Math.max(this.cssW, this.cssH) * 0.62,
      );
      aura.addColorStop(0, rgba(theme.accent, 0.1));
      aura.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = aura;
      g.fillRect(0, 0, this.cssW, this.cssH);
    }

    g.save();

    // Screen shake.
    if (this.shakeAmount > 0.01) {
      const a = this.shakeAmount * 6;
      g.translate((Math.random() - 0.5) * a, (Math.random() - 0.5) * a);
    }

    const ox = Math.round(this.layout.ox);
    const oy = Math.round(this.layout.oy);

    // Cached floor + walls.
    if (this.staticLayer) {
      g.drawImage(
        this.staticLayer,
        ox,
        oy,
        cell * frame.maze.width,
        cell * frame.maze.height,
      );
    }

    this.drawVisited(g, frame, ox, oy);
    this.drawTiles(g, frame, ox, oy);
    this.drawHintPath(g, frame, ox, oy);
    if (frame.showTrail) this.drawTrail(g, frame, ox, oy);
    this.drawEnemies(g, frame, ox, oy);
    this.drawPlayer(g, frame, ox, oy);
    this.particles.draw(g, cell, ox, oy);

    g.restore();
  }

  /** Visible cell range for the current camera — the culling window. */
  private viewRange(frame: RenderFrame, ox: number, oy: number) {
    const { cell } = this.layout;
    const pad = 1;
    return {
      x0: Math.max(0, Math.floor(-ox / cell) - pad),
      x1: Math.min(frame.maze.width - 1, Math.ceil((this.cssW - ox) / cell) + pad),
      y0: Math.max(0, Math.floor(-oy / cell) - pad),
      y1: Math.min(frame.maze.height - 1, Math.ceil((this.cssH - oy) / cell) + pad),
    };
  }

  /** Faint paint showing where the player has already been. */
  private drawVisited(
    g: CanvasRenderingContext2D,
    frame: RenderFrame,
    ox: number,
    oy: number,
  ): void {
    const { cell } = this.layout;
    const { maze, theme } = frame;
    const paintVariant = maze.variant === 'paint' || maze.variant === 'snake';
    const r = this.viewRange(frame, ox, oy);

    g.save();
    g.fillStyle = paintVariant ? rgba(theme.accent, 0.2) : 'rgba(255,255,255,0.035)';
    for (let y = r.y0; y <= r.y1; y++) {
      for (let x = r.x0; x <= r.x1; x++) {
        if (!maze.cells[y][x].visited) continue;
        g.fillRect(ox + x * cell + 1, oy + y * cell + 1, cell - 2, cell - 2);
      }
    }
    g.restore();
  }

  /** All animated tile content inside the viewport. */
  private drawTiles(
    g: CanvasRenderingContext2D,
    frame: RenderFrame,
    ox: number,
    oy: number,
  ): void {
    const { cell } = this.layout;
    const { maze, now, theme } = frame;
    const r = this.viewRange(frame, ox, oy);

    for (let y = r.y0; y <= r.y1; y++) {
      for (let x = r.x0; x <= r.x1; x++) {
        const c = maze.cells[y][x];
        const cx = ox + (x + 0.5) * cell;
        const cy = oy + (y + 0.5) * cell;

        // Animated overlays on terrain.
        if (c.type === 'ice' && theme.sparkle) this.drawFrostSparkle(g, cx, cy, cell, now, x, y);

        if (c.metadata?.gate) {
          this.drawGate(g, cx, cy, cell, now, c.metadata.gateOpen === true);
          continue;
        }

        switch (c.type) {
          case 'start':
            this.drawStart(g, cx, cy, cell, now);
            break;
          case 'exit':
            this.drawExit(g, cx, cy, cell, now);
            break;
          case 'coin':
            this.drawCoin(g, cx, cy, cell, now, x, y);
            break;
          case 'key':
            this.drawKey(g, cx, cy, cell, now, asKeyColor(c.metadata?.lock));
            break;
          case 'door':
            this.drawDoor(g, cx, cy, cell, asKeyColor(c.metadata?.lock));
            break;
          case 'teleporter':
            this.drawTeleporter(g, cx, cy, cell, now, Number(c.metadata?.pairId ?? 1));
            break;
          case 'powerup':
            this.drawPowerUp(g, cx, cy, cell, now);
            break;
          case 'torch':
            this.drawTorch(g, cx, cy, cell, now, x, y);
            break;
          case 'checkpoint':
            this.drawCheckpoint(g, cx, cy, cell, c.metadata?.activated === true);
            break;
          case 'arrow':
            this.drawArrow(g, cx, cy, cell, now, String(c.metadata?.dir ?? 'right'));
            break;
          default:
            break;
        }
      }
    }
  }

  // ── Individual tiles ───────────────────────────────────────

  /** Pulsing green spawn disc. */
  private drawStart(g: CanvasRenderingContext2D, cx: number, cy: number, cell: number, now: number): void {
    const pulse = 1 + Math.sin(now / 520) * 0.1;
    g.save();
    const grad = g.createRadialGradient(cx, cy, 1, cx, cy, cell * 0.4 * pulse);
    grad.addColorStop(0, 'rgba(52,211,153,0.5)');
    grad.addColorStop(0.65, 'rgba(16,185,129,0.2)');
    grad.addColorStop(1, 'rgba(16,185,129,0)');
    g.fillStyle = grad;
    g.beginPath();
    g.arc(cx, cy, cell * 0.4 * pulse, 0, TAU);
    g.fill();
    g.strokeStyle = 'rgba(167,243,208,0.75)';
    g.lineWidth = Math.max(1.5, cell * 0.045);
    g.beginPath();
    g.arc(cx, cy, cell * 0.24, 0, TAU);
    g.stroke();
    g.restore();
  }

  /** Radiating golden exit portal — the visual anchor of every level. */
  private drawExit(g: CanvasRenderingContext2D, cx: number, cy: number, cell: number, now: number): void {
    // 2-second 1.0 → 1.2 → 1.0 breathing cycle.
    const t = (now % 2000) / 2000;
    const pulse = 1 + Math.sin(t * TAU) * 0.1;
    const r = cell * 0.42 * pulse;

    g.save();
    const halo = g.createRadialGradient(cx, cy, 1, cx, cy, r * 1.5);
    halo.addColorStop(0, 'rgba(253,230,138,0.95)');
    halo.addColorStop(0.42, 'rgba(251,191,36,0.55)');
    halo.addColorStop(1, 'rgba(245,158,11,0)');
    g.fillStyle = halo;
    g.beginPath();
    g.arc(cx, cy, r * 1.5, 0, TAU);
    g.fill();

    // Radiating light spokes.
    g.strokeStyle = 'rgba(254,243,199,0.5)';
    g.lineWidth = Math.max(1, cell * 0.035);
    g.lineCap = 'round';
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU + now / 1600;
      const inner = r * 0.78;
      const outer = r * (1.08 + Math.sin(now / 320 + i) * 0.1);
      g.beginPath();
      g.moveTo(cx + Math.cos(a) * inner, cy + Math.sin(a) * inner);
      g.lineTo(cx + Math.cos(a) * outer, cy + Math.sin(a) * outer);
      g.stroke();
    }

    // Rotating golden square core.
    g.translate(cx, cy);
    g.rotate(now / 2400);
    g.shadowColor = '#fbbf24';
    g.shadowBlur = cell * 0.3;
    const core = g.createLinearGradient(-r * 0.5, -r * 0.5, r * 0.5, r * 0.5);
    core.addColorStop(0, '#fffbeb');
    core.addColorStop(0.5, '#fbbf24');
    core.addColorStop(1, '#f59e0b');
    g.fillStyle = core;
    const s = r * 0.52;
    this.roundRect(g, -s, -s, s * 2, s * 2, s * 0.32);
    g.fill();
    g.restore();
  }

  /** Spinning coin with a sweeping specular highlight. */
  private drawCoin(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    gx: number,
    gy: number,
  ): void {
    const phase = gx * 1.7 + gy * 2.3;
    const bob = Math.sin(now / 420 + phase) * cell * 0.05;
    // Simulated 3D spin: the coin squashes horizontally.
    const spin = Math.abs(Math.cos(now / 620 + phase));
    const r = cell * 0.2;
    const y = cy + bob;

    g.save();
    g.shadowColor = 'rgba(251,191,36,0.85)';
    g.shadowBlur = cell * 0.22;
    const grad = g.createRadialGradient(cx - r * 0.35, y - r * 0.4, 1, cx, y, r);
    grad.addColorStop(0, '#fffbeb');
    grad.addColorStop(0.45, '#fcd34d');
    grad.addColorStop(1, '#b45309');
    g.fillStyle = grad;
    g.beginPath();
    g.ellipse(cx, y, Math.max(1, r * spin), r, 0, 0, TAU);
    g.fill();

    if (spin > 0.35) {
      g.shadowBlur = 0;
      g.fillStyle = 'rgba(120,53,15,0.55)';
      g.beginPath();
      g.ellipse(cx, y, Math.max(0.5, r * 0.42 * spin), r * 0.42, 0, 0, TAU);
      g.fill();
      // Rotating shine.
      g.globalAlpha = 0.65 * spin;
      g.fillStyle = '#fffdf5';
      g.beginPath();
      g.ellipse(cx - r * 0.3 * spin, y - r * 0.35, r * 0.2 * spin, r * 0.3, -0.5, 0, TAU);
      g.fill();
    }
    g.restore();
  }

  /** Floating coloured key. */
  private drawKey(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    color: KeyColor,
  ): void {
    const pal = KEY_PALETTE[color];
    const bob = Math.sin(now / 480) * cell * 0.055;
    g.save();
    g.translate(cx, cy + bob);
    g.rotate(-0.5 + Math.sin(now / 760) * 0.16);
    g.shadowColor = pal.base;
    g.shadowBlur = cell * 0.26;
    g.strokeStyle = pal.light;
    g.lineWidth = Math.max(2, cell * 0.085);
    g.lineCap = 'round';
    g.beginPath();
    g.arc(-cell * 0.12, -cell * 0.12, cell * 0.12, 0, TAU);
    g.stroke();
    g.beginPath();
    g.moveTo(-cell * 0.04, -cell * 0.04);
    g.lineTo(cell * 0.2, cell * 0.2);
    g.moveTo(cell * 0.11, cell * 0.11);
    g.lineTo(cell * 0.2, cell * 0.03);
    g.moveTo(cell * 0.165, cell * 0.165);
    g.lineTo(cell * 0.25, cell * 0.09);
    g.stroke();
    g.restore();
  }

  /** Locked door — a coloured barricade with a lock plate. */
  private drawDoor(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    color: KeyColor,
  ): void {
    const pal = KEY_PALETTE[color];
    g.save();
    g.shadowColor = pal.base;
    g.shadowBlur = cell * 0.24;
    const grad = g.createLinearGradient(cx, cy - cell * 0.4, cx, cy + cell * 0.4);
    grad.addColorStop(0, pal.base);
    grad.addColorStop(1, pal.dark);
    g.fillStyle = grad;
    this.roundRect(g, cx - cell * 0.38, cy - cell * 0.42, cell * 0.76, cell * 0.84, cell * 0.12);
    g.fill();
    g.shadowBlur = 0;
    g.strokeStyle = pal.light;
    g.lineWidth = Math.max(1.4, cell * 0.04);
    this.roundRect(g, cx - cell * 0.38, cy - cell * 0.42, cell * 0.76, cell * 0.84, cell * 0.12);
    g.stroke();

    // Lock plate.
    g.fillStyle = 'rgba(15,23,42,0.6)';
    g.beginPath();
    g.arc(cx, cy, cell * 0.13, 0, TAU);
    g.fill();
    g.strokeStyle = pal.light;
    g.lineWidth = Math.max(1.4, cell * 0.045);
    g.beginPath();
    g.arc(cx, cy - cell * 0.03, cell * 0.07, Math.PI, 0);
    g.stroke();
    g.fillStyle = pal.light;
    this.roundRect(g, cx - cell * 0.055, cy - cell * 0.03, cell * 0.11, cell * 0.13, cell * 0.02);
    g.fill();
    g.restore();
  }

  /** Swirling portal. Paired portals share a hue. */
  private drawTeleporter(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    pairId: number,
  ): void {
    const hues = ['#c4b5fd', '#67e8f9', '#f0abfc', '#86efac'];
    const color = hues[(pairId - 1) % hues.length];
    const rot = now / 520;

    g.save();
    g.translate(cx, cy);
    g.shadowColor = color;
    g.shadowBlur = cell * 0.3;

    // Swirling gradient disc.
    const grad = g.createRadialGradient(0, 0, cell * 0.04, 0, 0, cell * 0.36);
    grad.addColorStop(0, '#ffffff');
    grad.addColorStop(0.35, color);
    grad.addColorStop(1, 'rgba(15,23,42,0)');
    g.globalAlpha = 0.5;
    g.fillStyle = grad;
    g.beginPath();
    g.arc(0, 0, cell * 0.36, 0, TAU);
    g.fill();
    g.globalAlpha = 1;

    // Counter-rotating arcs.
    g.strokeStyle = color;
    g.lineWidth = Math.max(1.6, cell * 0.055);
    g.lineCap = 'round';
    g.beginPath();
    g.arc(0, 0, cell * 0.3, rot, rot + Math.PI * 1.25);
    g.stroke();
    g.beginPath();
    g.arc(0, 0, cell * 0.18, -rot * 1.4, -rot * 1.4 + Math.PI * 1.25);
    g.stroke();

    g.fillStyle = '#ffffff';
    g.beginPath();
    g.arc(0, 0, cell * 0.06, 0, TAU);
    g.fill();
    g.restore();
  }

  /** Floating power-up crystal inside a golden ring. */
  private drawPowerUp(g: CanvasRenderingContext2D, cx: number, cy: number, cell: number, now: number): void {
    const bob = Math.sin(now / 430) * cell * 0.06;
    const spin = now / 760;
    g.save();
    g.translate(cx, cy + bob);

    g.strokeStyle = 'rgba(251,191,36,0.85)';
    g.lineWidth = Math.max(1.4, cell * 0.04);
    g.setLineDash([cell * 0.12, cell * 0.08]);
    g.lineDashOffset = -now / 26;
    g.beginPath();
    g.arc(0, 0, cell * 0.33, 0, TAU);
    g.stroke();
    g.setLineDash([]);

    g.rotate(spin);
    g.shadowColor = '#5eead4';
    g.shadowBlur = cell * 0.3;
    const r = cell * 0.2;
    const grad = g.createLinearGradient(-r, -r, r, r);
    grad.addColorStop(0, '#f0fdfa');
    grad.addColorStop(0.5, '#2dd4bf');
    grad.addColorStop(1, '#0d9488');
    g.fillStyle = grad;
    g.beginPath();
    g.moveTo(0, -r);
    g.lineTo(r * 0.7, 0);
    g.lineTo(0, r);
    g.lineTo(-r * 0.7, 0);
    g.closePath();
    g.fill();
    g.restore();
  }

  /** Wall torch with a flickering flame (also a fog light source). */
  private drawTorch(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    gx: number,
    gy: number,
  ): void {
    const flick = 0.82 + Math.sin(now / 90 + gx * 3.1 + gy * 1.7) * 0.1 + Math.sin(now / 37) * 0.07;
    g.save();
    g.translate(cx, cy);

    // Sconce.
    g.fillStyle = '#44403c';
    this.roundRect(g, -cell * 0.05, cell * 0.02, cell * 0.1, cell * 0.26, cell * 0.03);
    g.fill();

    // Flame.
    g.shadowColor = 'rgba(251,146,60,0.95)';
    g.shadowBlur = cell * 0.5 * flick;
    const h = cell * 0.3 * flick;
    const grad = g.createLinearGradient(0, cell * 0.04, 0, -h);
    grad.addColorStop(0, '#f97316');
    grad.addColorStop(0.55, '#fbbf24');
    grad.addColorStop(1, '#fef3c7');
    g.fillStyle = grad;
    g.beginPath();
    g.moveTo(0, cell * 0.05);
    g.quadraticCurveTo(cell * 0.14, -h * 0.25, 0, -h);
    g.quadraticCurveTo(-cell * 0.14, -h * 0.25, 0, cell * 0.05);
    g.fill();
    g.restore();
  }

  /** Checkpoint flag — grey until activated. */
  private drawCheckpoint(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    active: boolean,
  ): void {
    const color = active ? '#34d399' : '#64748b';
    g.save();
    g.translate(cx - cell * 0.08, cy + cell * 0.22);
    if (active) {
      g.shadowColor = color;
      g.shadowBlur = cell * 0.26;
    }
    g.strokeStyle = active ? '#e2e8f0' : '#94a3b8';
    g.lineWidth = Math.max(1.6, cell * 0.05);
    g.lineCap = 'round';
    g.beginPath();
    g.moveTo(0, 0);
    g.lineTo(0, -cell * 0.46);
    g.stroke();
    g.fillStyle = color;
    g.beginPath();
    g.moveTo(0, -cell * 0.46);
    g.lineTo(cell * 0.3, -cell * 0.37);
    g.lineTo(0, -cell * 0.27);
    g.closePath();
    g.fill();
    g.restore();
  }

  /** One-way arrow chevron on the floor. */
  private drawArrow(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    dir: string,
  ): void {
    const angle =
      dir === 'up' ? -Math.PI / 2 : dir === 'down' ? Math.PI / 2 : dir === 'left' ? Math.PI : 0;
    const pulse = 0.55 + Math.sin(now / 380) * 0.3;
    g.save();
    g.translate(cx, cy);
    g.rotate(angle);
    g.globalAlpha = pulse;
    g.strokeStyle = '#7dd3fc';
    g.shadowColor = '#38bdf8';
    g.shadowBlur = cell * 0.18;
    g.lineWidth = Math.max(1.8, cell * 0.07);
    g.lineCap = 'round';
    g.lineJoin = 'round';
    for (let i = -1; i <= 1; i++) {
      const off = i * cell * 0.14;
      g.beginPath();
      g.moveTo(off - cell * 0.08, -cell * 0.13);
      g.lineTo(off + cell * 0.06, 0);
      g.lineTo(off - cell * 0.08, cell * 0.13);
      g.stroke();
    }
    g.restore();
  }

  /** Shifting-sands gate: barred when closed, dashed outline when open. */
  private drawGate(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    open: boolean,
  ): void {
    g.save();
    if (open) {
      g.strokeStyle = 'rgba(251,191,36,0.4)';
      g.setLineDash([cell * 0.1, cell * 0.1]);
      g.lineDashOffset = now / 70;
      g.lineWidth = Math.max(1.2, cell * 0.04);
      this.roundRect(g, cx - cell * 0.4, cy - cell * 0.4, cell * 0.8, cell * 0.8, cell * 0.1);
      g.stroke();
      g.setLineDash([]);
    } else {
      g.shadowColor = 'rgba(245,158,11,0.8)';
      g.shadowBlur = cell * 0.26;
      const grad = g.createLinearGradient(cx, cy - cell * 0.5, cx, cy + cell * 0.5);
      grad.addColorStop(0, '#b45309');
      grad.addColorStop(1, '#78350f');
      g.fillStyle = grad;
      this.roundRect(g, cx - cell * 0.46, cy - cell * 0.46, cell * 0.92, cell * 0.92, cell * 0.08);
      g.fill();
      g.shadowBlur = 0;
      g.strokeStyle = '#fbbf24';
      g.lineWidth = Math.max(1.6, cell * 0.055);
      g.lineCap = 'round';
      for (let i = 1; i <= 3; i++) {
        const bx = cx - cell * 0.46 + (cell * 0.92 * i) / 4;
        g.beginPath();
        g.moveTo(bx, cy - cell * 0.36);
        g.lineTo(bx, cy + cell * 0.36);
        g.stroke();
      }
    }
    g.restore();
  }

  /** Twinkling frost motes on ice tiles (Ice Kingdom / Gravity Well). */
  private drawFrostSparkle(
    g: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    cell: number,
    now: number,
    gx: number,
    gy: number,
  ): void {
    const seed = gx * 12.9898 + gy * 78.233;
    g.save();
    for (let i = 0; i < 2; i++) {
      const phase = seed + i * 2.4;
      const tw = Math.sin(now / 500 + phase);
      if (tw < 0.55) continue;
      const a = phase * 1.7;
      const px = cx + Math.cos(a) * cell * 0.26;
      const py = cy + Math.sin(a * 1.3) * cell * 0.26;
      g.globalAlpha = (tw - 0.55) * 2;
      g.fillStyle = '#f0f9ff';
      const s = cell * 0.035;
      g.beginPath();
      g.moveTo(px, py - s);
      g.lineTo(px + s * 0.4, py);
      g.lineTo(px, py + s);
      g.lineTo(px - s * 0.4, py);
      g.closePath();
      g.fill();
    }
    g.restore();
  }

  // ── Path hint, trail, actors ───────────────────────────────

  /** Compass breadcrumbs toward the exit. */
  private drawHintPath(
    g: CanvasRenderingContext2D,
    frame: RenderFrame,
    ox: number,
    oy: number,
  ): void {
    const path = frame.effects.hintPath;
    if (!path || path.length < 2) return;
    const { cell } = this.layout;

    g.save();
    g.shadowColor = '#fbbf24';
    g.shadowBlur = cell * 0.25;
    for (let i = 1; i < path.length; i++) {
      const p = path[i];
      const wave = Math.sin(frame.now / 190 - i * 0.55);
      g.globalAlpha = 0.45 + wave * 0.3;
      g.fillStyle = i === path.length - 1 ? '#a7f3d0' : '#fcd34d';
      g.beginPath();
      g.arc(ox + (p.x + 0.5) * cell, oy + (p.y + 0.5) * cell, cell * 0.085, 0, TAU);
      g.fill();
    }
    g.restore();
  }

  /** Dotted breadcrumb trail of recent player positions. */
  private drawTrail(
    g: CanvasRenderingContext2D,
    frame: RenderFrame,
    ox: number,
    oy: number,
  ): void {
    const { cell } = this.layout;
    const trail = frame.player.trail;
    const span = frame.maze.variant === 'snake' ? 24 : 7;
    const from = Math.max(0, trail.length - span);

    g.save();
    for (let i = from; i < trail.length; i++) {
      const k = (i - from + 1) / (trail.length - from + 1);
      g.globalAlpha = k * 0.3;
      g.fillStyle = frame.skin.color;
      g.beginPath();
      g.arc(
        ox + (trail[i].x + 0.5) * cell,
        oy + (trail[i].y + 0.5) * cell,
        cell * 0.09 * k + cell * 0.02,
        0,
        TAU,
      );
      g.fill();
    }
    g.restore();
  }

  /** Spiky hunter orbs with a tracking eye. */
  private drawEnemies(
    g: CanvasRenderingContext2D,
    frame: RenderFrame,
    ox: number,
    oy: number,
  ): void {
    const { cell } = this.layout;
    const { now, effects } = frame;

    for (const e of frame.enemies) {
      const t = easeOutCubic(clamp(e.animProgress, 0, 1));
      const ex = ox + (lerp(e.x, e.targetX, t) + 0.5) * cell;
      const ey = oy + (lerp(e.y, e.targetY, t) + 0.5) * cell;
      const frozen = effects.frozen || e.frozen;
      const r = cell * 0.27;

      g.save();
      const color = frozen ? '#7dd3fc' : '#ef4444';
      g.shadowColor = frozen ? 'rgba(125,211,252,0.9)' : 'rgba(239,68,68,0.9)';
      g.shadowBlur = cell * 0.3;

      // Rotating spikes.
      g.fillStyle = color;
      g.beginPath();
      const spikes = 9;
      const spin = frozen ? 0 : now / 620;
      for (let i = 0; i < spikes; i++) {
        const a = (i / spikes) * TAU + spin;
        const a2 = a + Math.PI / spikes;
        g.lineTo(ex + Math.cos(a) * r * 1.3, ey + Math.sin(a) * r * 1.3);
        g.lineTo(ex + Math.cos(a2) * r * 0.78, ey + Math.sin(a2) * r * 0.78);
      }
      g.closePath();
      g.fill();

      // Core.
      g.shadowBlur = 0;
      const core = g.createRadialGradient(ex - r * 0.3, ey - r * 0.3, 1, ex, ey, r);
      core.addColorStop(0, frozen ? '#f0f9ff' : '#fee2e2');
      core.addColorStop(0.55, color);
      core.addColorStop(1, frozen ? '#0c4a6e' : '#7f1d1d');
      g.fillStyle = core;
      g.beginPath();
      g.arc(ex, ey, r * 0.84, 0, TAU);
      g.fill();

      // Eye tracking the player.
      const px = lerp(frame.player.x, frame.player.targetX, frame.player.animProgress);
      const py = lerp(frame.player.y, frame.player.targetY, frame.player.animProgress);
      const ang = Math.atan2(py - (ey - oy) / cell + 0.5, px - (ex - ox) / cell + 0.5);
      const look = frozen ? 0 : r * 0.14;
      g.fillStyle = frozen ? '#0c4a6e' : '#ffffff';
      g.beginPath();
      g.arc(ex + Math.cos(ang) * look, ey + Math.sin(ang) * look, r * 0.3, 0, TAU);
      g.fill();
      g.fillStyle = '#0f172a';
      g.beginPath();
      g.arc(ex + Math.cos(ang) * look * 1.7, ey + Math.sin(ang) * look * 1.7, r * 0.14, 0, TAU);
      g.fill();

      if (frozen) {
        g.strokeStyle = 'rgba(224,242,254,0.8)';
        g.lineWidth = Math.max(1, cell * 0.03);
        g.beginPath();
        g.arc(ex, ey, r * 1.18, 0, TAU);
        g.stroke();
      }
      g.restore();
    }
  }

  /**
   * The player: a smooth skinned orb with eyes that look where they walk,
   * a determined mouth, idle breathing and optional effect decorations.
   */
  private drawPlayer(
    g: CanvasRenderingContext2D,
    frame: RenderFrame,
    ox: number,
    oy: number,
  ): void {
    const { cell } = this.layout;
    const { player, skin, effects, now } = frame;

    const t = this.visualProgress(frame);
    const px = ox + (lerp(player.x, player.targetX, t) + 0.5) * cell;
    const py = oy + (lerp(player.y, player.targetY, t) + 0.5) * cell;

    const moving = player.animProgress < 1;
    // Idle breathing 1.0 → 1.05; slight squash while moving.
    const breathe = moving ? 1 : 1 + Math.sin(now / 620) * 0.05;
    const r = cell * 0.3 * breathe;

    g.save();
    if (effects.ghost) g.globalAlpha = 0.55;

    // Speed streaks behind the direction of travel.
    if (effects.speedBoost) {
      const bx = player.direction === 'left' ? 1 : player.direction === 'right' ? -1 : 0;
      const by = player.direction === 'up' ? 1 : player.direction === 'down' ? -1 : 0;
      g.strokeStyle = rgba(skin.color, 0.45);
      g.lineWidth = Math.max(1.5, cell * 0.05);
      g.lineCap = 'round';
      for (let i = 1; i <= 3; i++) {
        const o = r * (0.9 + i * 0.5);
        const perp = (i - 2) * r * 0.42;
        g.beginPath();
        g.moveTo(px + bx * o - by * perp, py + by * o + bx * perp);
        g.lineTo(px + bx * (o + r * 0.6) - by * perp, py + by * (o + r * 0.6) + bx * perp);
        g.stroke();
      }
    }

    // Shield ring.
    if (effects.shield) {
      g.strokeStyle = '#22d3ee';
      g.shadowColor = '#22d3ee';
      g.shadowBlur = cell * 0.3;
      g.lineWidth = Math.max(1.5, cell * 0.05);
      g.setLineDash([cell * 0.18, cell * 0.14]);
      g.lineDashOffset = -now / 28;
      g.beginPath();
      g.arc(px, py, r * 1.4, 0, TAU);
      g.stroke();
      g.setLineDash([]);
      g.shadowBlur = 0;
    }

    // Contact shadow.
    g.fillStyle = 'rgba(0,0,0,0.35)';
    g.beginPath();
    g.ellipse(px, py + r * 0.9, r * 0.75, r * 0.26, 0, 0, TAU);
    g.fill();

    // Body.
    g.shadowColor = skin.glow;
    g.shadowBlur = cell * 0.42;
    const body = g.createRadialGradient(px - r * 0.35, py - r * 0.4, r * 0.08, px, py, r);
    body.addColorStop(0, '#ffffff');
    body.addColorStop(0.32, skin.color);
    body.addColorStop(1, skin.glow);
    g.fillStyle = body;
    g.beginPath();
    g.arc(px, py, r, 0, TAU);
    g.fill();
    g.shadowBlur = 0;

    // Glossy rim light.
    g.strokeStyle = 'rgba(255,255,255,0.35)';
    g.lineWidth = Math.max(1, cell * 0.025);
    g.beginPath();
    g.arc(px, py, r * 0.93, Math.PI * 1.1, Math.PI * 1.85);
    g.stroke();

    // ── Face ──
    const dx = player.direction === 'left' ? -1 : player.direction === 'right' ? 1 : 0;
    const dy = player.direction === 'up' ? -1 : player.direction === 'down' ? 1 : 0;
    const lookX = dx * r * 0.17;
    const lookY = dy * r * 0.17;
    // Eyes sit perpendicular to the direction of travel.
    const sepX = dy !== 0 ? r * 0.3 : 0;
    const sepY = dx !== 0 ? r * 0.3 : 0;
    const eyeR = r * 0.17;

    // Blink every ~4s.
    const blinkPhase = (now % 4200) / 4200;
    const blink = blinkPhase > 0.965 ? 0.12 : 1;

    g.fillStyle = '#ffffff';
    for (const s of [-1, 1]) {
      g.beginPath();
      g.ellipse(
        px + lookX + sepX * s,
        py + lookY + sepY * s,
        eyeR,
        eyeR * blink,
        0,
        0,
        TAU,
      );
      g.fill();
    }
    g.fillStyle = '#0b1120';
    for (const s of [-1, 1]) {
      g.beginPath();
      g.ellipse(
        px + lookX * 1.45 + sepX * s,
        py + lookY * 1.45 + sepY * s,
        eyeR * 0.5,
        eyeR * 0.5 * blink,
        0,
        0,
        TAU,
      );
      g.fill();
    }

    // Determined mouth — a small confident arc.
    g.strokeStyle = 'rgba(11,17,32,0.75)';
    g.lineWidth = Math.max(1, r * 0.11);
    g.lineCap = 'round';
    g.beginPath();
    g.arc(px + lookX * 0.6, py + lookY * 0.5 + r * 0.3, r * 0.26, Math.PI * 1.12, Math.PI * 1.88);
    g.stroke();

    g.restore();
  }

  // ── Fog & vignette ─────────────────────────────────────────

  /**
   * Builds a union of light sources on a mask layer, then keeps only the
   * lit pixels of the world via `destination-in`. Everything else is left
   * as pure black by the caller.
   */
  private applyFogMask(wctx: CanvasRenderingContext2D, frame: RenderFrame): void {
    const mask = this.ensureBuffer('mask');
    const mctx = mask?.getContext('2d');
    if (!mask || !mctx) return;

    const { cell } = this.layout;
    const ox = Math.round(this.layout.ox);
    const oy = Math.round(this.layout.oy);

    mctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    mctx.clearRect(0, 0, this.cssW, this.cssH);
    // 'lighter' unions overlapping lights instead of intersecting them.
    mctx.globalCompositeOperation = 'lighter';

    const t = this.visualProgress(frame);
    const px = ox + (lerp(frame.player.x, frame.player.targetX, t) + 0.5) * cell;
    const py = oy + (lerp(frame.player.y, frame.player.targetY, t) + 0.5) * cell;

    // Player torch — gentle breathing radius.
    const flicker = 1 + Math.sin(frame.now / 380) * 0.025;
    this.paintLight(mctx, px, py, frame.maze.fogRadius * cell * flicker, 1);

    // Nearby torches add warm pools of light (radius 5 cells).
    const r = this.viewRange(frame, ox, oy);
    for (let y = r.y0; y <= r.y1; y++) {
      for (let x = r.x0; x <= r.x1; x++) {
        if (frame.maze.cells[y][x].type !== 'torch') continue;
        const tf = 0.86 + Math.sin(frame.now / 110 + x * 3.1 + y * 1.7) * 0.14;
        this.paintLight(
          mctx,
          ox + (x + 0.5) * cell,
          oy + (y + 0.5) * cell,
          5 * cell * tf,
          0.85,
        );
      }
    }

    mctx.globalCompositeOperation = 'source-over';

    wctx.globalCompositeOperation = 'destination-in';
    wctx.setTransform(1, 0, 0, 1, 0, 0);
    wctx.drawImage(mask, 0, 0);
    wctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    wctx.globalCompositeOperation = 'source-over';
  }

  /** One soft-edged circular light on the fog mask. */
  private paintLight(
    g: CanvasRenderingContext2D,
    x: number,
    y: number,
    radius: number,
    intensity: number,
  ): void {
    const grad = g.createRadialGradient(x, y, radius * 0.08, x, y, radius);
    // Long tail so walls at the edge stay dimly readable, never a hard circle.
    grad.addColorStop(0, `rgba(255,255,255,${intensity})`);
    grad.addColorStop(0.55, `rgba(255,255,255,${intensity * 0.92})`);
    grad.addColorStop(0.78, `rgba(255,255,255,${intensity * 0.42})`);
    grad.addColorStop(0.92, `rgba(255,255,255,${intensity * 0.13})`);
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grad;
    g.beginPath();
    g.arc(x, y, radius, 0, TAU);
    g.fill();
  }

  /** Darkened corners plus effect tints. */
  private drawVignette(g: CanvasRenderingContext2D, frame: RenderFrame): void {
    g.save();
    g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);

    if (frame.effects.frozen) {
      g.fillStyle = 'rgba(56,189,248,0.1)';
      g.fillRect(0, 0, this.cssW, this.cssH);
    }
    if (frame.effects.ghost) {
      g.fillStyle = 'rgba(232,121,249,0.07)';
      g.fillRect(0, 0, this.cssW, this.cssH);
    }

    const cx = this.cssW / 2;
    const cy = this.cssH / 2;
    const inner = Math.min(this.cssW, this.cssH) * 0.38;
    const outer = Math.max(this.cssW, this.cssH) * 0.78;
    const vg = g.createRadialGradient(cx, cy, inner, cx, cy, outer);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(0.7, 'rgba(2,4,10,0.28)');
    vg.addColorStop(1, 'rgba(2,4,10,0.62)');
    g.fillStyle = vg;
    g.fillRect(0, 0, this.cssW, this.cssH);
    g.restore();
  }

  // ── Small helpers ──────────────────────────────────────────

  /** Rounded rectangle path (no fill/stroke applied). */
  private roundRect(
    g: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number,
  ): void {
    const rr = Math.max(0, Math.min(r, w / 2, h / 2));
    g.beginPath();
    g.moveTo(x + rr, y);
    g.arcTo(x + w, y, x + w, y + h, rr);
    g.arcTo(x + w, y + h, x, y + h, rr);
    g.arcTo(x, y + h, x, y, rr);
    g.arcTo(x, y, x + w, y, rr);
    g.closePath();
  }
}

/** Convenience re-export so callers can type cells without a second import. */
export type { Cell };
