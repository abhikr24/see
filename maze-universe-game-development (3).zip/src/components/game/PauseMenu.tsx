'use client';

import { Home, Pause, Play, RotateCcw, Volume2, VolumeX, Music } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import { useGameStore } from '@/stores/gameStore';
import { cn } from '@/lib/utils/helpers';

interface PauseMenuProps {
  open: boolean;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
}

export function PauseMenu({ open, onResume, onRestart, onQuit }: PauseMenuProps) {
  const settings = useGameStore((s) => s.progress.settings);
  const updateSettings = useGameStore((s) => s.updateSettings);

  return (
    <Modal open={open} dismissible={false} size="sm">
      <div className="text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-blue-500/30">
          <Pause className="h-7 w-7 text-white" />
        </span>
        <h2 className="mt-4 text-2xl font-black tracking-wide text-white">PAUSED</h2>
        <p className="mt-1 text-sm text-slate-400">The maze waits for no one… except now.</p>
      </div>

      <div className="mt-6 flex flex-col gap-2.5">
        <Button size="lg" fullWidth icon={Play} onClick={onResume}>
          Resume
        </Button>
        <Button size="md" fullWidth variant="ghost" icon={RotateCcw} onClick={onRestart}>
          Restart level
        </Button>
        <Button size="md" fullWidth variant="ghost" icon={Home} onClick={onQuit}>
          Quit to menu
        </Button>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-2.5 border-t border-white/10 pt-5">
        <ToggleRow
          active={settings.soundEnabled}
          onClick={() => updateSettings({ soundEnabled: !settings.soundEnabled })}
          label="Sound FX"
          icon={settings.soundEnabled ? Volume2 : VolumeX}
        />
        <ToggleRow
          active={settings.musicEnabled}
          onClick={() => updateSettings({ musicEnabled: !settings.musicEnabled })}
          label="Music"
          icon={Music}
        />
      </div>
    </Modal>
  );
}

function ToggleRow({
  active,
  onClick,
  label,
  icon: Icon,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  icon: typeof Volume2;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex h-12 items-center justify-center gap-2 rounded-xl border text-sm font-bold transition-all active:scale-95',
        active
          ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-300'
          : 'border-white/10 bg-white/[0.04] text-slate-400',
      )}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}
