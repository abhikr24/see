'use client';

import { Fragment, type RefObject } from 'react';
import type { Direction } from '@/lib/maze/types';
import { invertDirection } from '@/lib/game/physics';
import { useKeyboardControls, useSwipeControls } from '@/hooks/useSwipeControls';

interface PlayerControllerProps {
  containerRef: RefObject<HTMLElement | null>;
  onMove: (dir: Direction) => void;
  onPauseKey?: () => void;
  enabled: boolean;
  invert?: boolean; // mirror dimension
}

/** Invisible input layer: swipe gestures + keyboard. Renders nothing. */
export function PlayerController({
  containerRef,
  onMove,
  onPauseKey,
  enabled,
  invert = false,
}: PlayerControllerProps) {
  const map = (dir: Direction) => (invert ? invertDirection(dir) : dir);
  useSwipeControls({ ref: containerRef, onSwipe: (d) => onMove(map(d)), enabled });
  useKeyboardControls((d) => onMove(map(d)), { enabled, onPauseKey });
  return <Fragment />;
}
