'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { CalendarClock, Home, Infinity as InfinityIcon, Settings, Trophy } from 'lucide-react';
import { cn } from '@/lib/utils/helpers';

const ITEMS = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/daily', label: 'Daily', icon: CalendarClock },
  { href: '/infinite', label: 'Endless', icon: InfinityIcon },
  { href: '/leaderboard', label: 'Ranks', icon: Trophy },
  { href: '/settings', label: 'Settings', icon: Settings },
];

/** Mobile bottom navigation — hidden during gameplay routes. */
export function BottomNav() {
  const pathname = usePathname();
  if (pathname.startsWith('/play')) return null;

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/[0.06] bg-[#0a0f1e]/85 backdrop-blur-xl md:hidden">
      <div className="grid grid-cols-5 pb-[env(safe-area-inset-bottom)]">
        {ITEMS.map(({ href, label, icon: Icon }) => {
          const active = href === '/' ? pathname === '/' : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'relative flex h-16 flex-col items-center justify-center gap-1 transition-colors',
                active ? 'text-blue-300' : 'text-slate-500 hover:text-slate-300',
              )}
            >
              {active && (
                <span className="absolute -top-px h-0.5 w-10 rounded-full bg-gradient-to-r from-blue-400 to-violet-400" />
              )}
              <Icon className={cn('h-5 w-5', active && 'drop-shadow-[0_0_8px_rgba(96,165,250,0.8)]')} />
              <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
