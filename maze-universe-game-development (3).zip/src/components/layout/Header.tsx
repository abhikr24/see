'use client';

import Link from 'next/link';
import { Star } from 'lucide-react';
import { CoinCounter } from '@/components/ui/CoinCounter';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { useGameStore } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { xpToNext } from '@/lib/maze/constants';
import { cn } from '@/lib/utils/helpers';

/** Brand mark — stylized maze glyph. */
export function LogoMark({ size = 30, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" className={className} aria-hidden>
      <defs>
        <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="55%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <rect x="3" y="3" width="42" height="42" rx="11" fill="none" stroke="url(#logoGrad)" strokeWidth="3.4" />
      <path
        d="M13 13h12v8h-8v6h8v8h-12M35 13v22M13 35v-6"
        fill="none"
        stroke="url(#logoGrad)"
        strokeWidth="3.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="35" cy="13" r="3.6" fill="#34d399" />
    </svg>
  );
}

interface HeaderProps {
  className?: string;
}

/** Top stats bar: coins, stars, level + XP. */
export function Header({ className }: HeaderProps) {
  const hydrated = useHydrated();
  const coins = useGameStore((s) => s.progress.totalCoins);
  const stars = useGameStore((s) => s.progress.totalStars);
  const level = useGameStore((s) => s.progress.playerLevel);
  const xp = useGameStore((s) => s.progress.playerXP);

  return (
    <header
      className={cn(
        'sticky top-0 z-40 border-b border-white/[0.06] bg-[#0a0f1e]/80 backdrop-blur-xl',
        className,
      )}
    >
      <div className="mx-auto flex h-16 max-w-4xl items-center gap-3 px-4">
        <Link href="/" className="flex items-center gap-2.5 rounded-xl transition-transform active:scale-95">
          <LogoMark size={30} />
          <div className="hidden leading-tight sm:block">
            <p className="text-[13px] font-black tracking-[0.22em] text-white">MAZE</p>
            <p className="text-[10px] font-bold tracking-[0.34em] text-blue-400">UNIVERSE</p>
          </div>
        </Link>

        <div className="flex-1" />

        {hydrated ? (
          <>
            <span className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.05] px-3">
              <CoinCounter amount={coins} size="sm" />
            </span>
            <span className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-sm font-bold text-amber-300">
              <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
              <span className="tabular-nums">{stars}</span>
            </span>
            <div className="flex h-11 items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.05] px-3">
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-purple-700 text-xs font-black text-white shadow-md shadow-violet-500/30">
                {level}
              </span>
              <div className="hidden w-20 sm:block">
                <p className="mb-1 text-[9px] font-bold uppercase tracking-widest text-slate-400">
                  Level
                </p>
                <ProgressBar value={xp} max={xpToNext(level)} variant="purple" height={5} />
              </div>
            </div>
          </>
        ) : (
          <div className="h-11 w-40 animate-pulse rounded-xl bg-white/[0.06]" />
        )}
      </div>
    </header>
  );
}
