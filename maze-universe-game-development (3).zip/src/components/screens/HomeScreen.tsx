'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  CalendarClock,
  ChevronRight,
  Flame,
  Infinity as InfinityIcon,
  Rocket,
  Settings,
  Trophy,
  type LucideIcon,
} from 'lucide-react';
import { Header, LogoMark } from '@/components/layout/Header';
import { Starfield } from './Starfield';
import { WorldMap } from './WorldMap';
import { LevelSelect } from './LevelSelect';
import { useToast } from '@/components/ui/Toast';
import { useGameStore } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { todayKey } from '@/lib/utils/helpers';
import { soundManager } from '@/lib/audio/soundManager';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import type { WorldConfig } from '@/lib/maze/types';
import { cn } from '@/lib/utils/helpers';

type View = 'home' | 'worlds' | 'levels';

interface MenuItem {
  id: string;
  title: string;
  subtitle: string;
  icon: LucideIcon;
  tileClass: string;
  action: 'view' | 'href';
  href?: string;
  badge?: string;
}

export function HomeScreen() {
  const router = useRouter();
  const hydrated = useHydrated();
  const playSfx = useSoundEffects();
  const { toast } = useToast();
  const [view, setView] = useState<View>('home');
  const [selectedWorld, setSelectedWorld] = useState<WorldConfig | null>(null);

  const totalStars = useGameStore((s) => s.progress.totalStars);
  const dailyStreak = useGameStore((s) => s.progress.dailyStreak);
  const completedCount = useGameStore((s) => Object.keys(s.progress.completedLevels).length);
  const infiniteBest = useGameStore((s) => s.progress.infiniteBestFloor);
  const checkInToday = useGameStore((s) => s.checkInToday);

  // Daily login streak check-in
  useEffect(() => {
    if (!hydrated) return;
    const { streak, isNewDay } = checkInToday(todayKey());
    if (isNewDay) {
      toast({
        title: streak > 1 ? `Day ${streak} streak!` : 'Welcome back, wanderer!',
        message: 'A new Daily Challenge awaits in the cosmos.',
        variant: 'success',
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  const menu: MenuItem[] = [
    {
      id: 'adventure',
      title: 'Adventure',
      subtitle: hydrated ? `${completedCount} levels cleared · ${totalStars}★ earned` : '10 worlds await',
      icon: Rocket,
      tileClass: 'from-blue-500 to-cyan-400 shadow-blue-500/40',
      action: 'view',
    },
    {
      id: 'daily',
      title: 'Daily Challenge',
      subtitle: hydrated && dailyStreak > 0 ? `Day ${dailyStreak} streak · fresh maze today` : 'A new maze every day',
      icon: CalendarClock,
      tileClass: 'from-amber-400 to-orange-500 shadow-amber-500/40',
      action: 'href',
      href: '/daily',
      badge: hydrated && dailyStreak > 1 ? `${dailyStreak} day${dailyStreak > 1 ? 's' : ''}` : undefined,
    },
    {
      id: 'endless',
      title: 'Endless Mode',
      subtitle: hydrated && infiniteBest > 0 ? `Best descent: floor ${infiniteBest}` : 'How deep can you go?',
      icon: InfinityIcon,
      tileClass: 'from-violet-500 to-fuchsia-500 shadow-violet-500/40',
      action: 'href',
      href: '/infinite',
    },
    {
      id: 'ranks',
      title: 'Leaderboard',
      subtitle: 'Galactic rankings & your records',
      icon: Trophy,
      tileClass: 'from-emerald-500 to-teal-400 shadow-emerald-500/40',
      action: 'href',
      href: '/leaderboard',
    },
    {
      id: 'settings',
      title: 'Settings',
      subtitle: 'Sound, controls & skins',
      icon: Settings,
      tileClass: 'from-slate-500 to-slate-700 shadow-slate-500/40',
      action: 'href',
      href: '/settings',
    },
  ];

  const onMenu = (item: MenuItem) => {
    soundManager.unlock();
    playSfx('click');
    if (item.action === 'href' && item.href) router.push(item.href);
    else setView('worlds');
  };

  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-[#0a0f1e]">
      <Starfield className="pointer-events-none absolute inset-0 opacity-90" />

      <div className="relative z-10">
        <Header />
      </div>

      <main className="relative z-10 flex-1">
        {view === 'home' && (
          <div key="home" className="animate-view-in mx-auto flex w-full max-w-md flex-col items-center px-5 pb-28 pt-8 md:pb-12">
            {/* Logo */}
            <div className="relative mb-3 flex h-36 w-36 items-center justify-center">
              <div className="absolute inset-0 animate-spin-slow rounded-full border border-dashed border-blue-400/25" />
              <div className="absolute inset-3 animate-spin-reverse rounded-full border border-violet-400/20" />
              <div className="absolute inset-0 rounded-full bg-blue-500/10 blur-2xl" />
              <LogoMark size={92} className="animate-float drop-shadow-[0_0_30px_rgba(59,130,246,0.45)]" />
            </div>

            <h1 className="text-center text-5xl font-black leading-none tracking-tight">
              <span className="bg-gradient-to-br from-sky-300 via-blue-400 to-violet-500 bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(59,130,246,0.35)]">
                MAZE
              </span>
            </h1>
            <p className="mt-1.5 text-center text-sm font-black tracking-[0.62em] text-blue-300/80">
              UNIVERSE
            </p>
            <p className="mt-3 max-w-xs text-center text-sm leading-relaxed text-slate-400">
              Ten worlds. Hundreds of corridors. One way out.
            </p>

            {/* Menu */}
            <nav className="mt-9 flex w-full flex-col gap-3">
              {menu.map((item, i) => (
                <button
                  key={item.id}
                  onClick={() => onMenu(item)}
                  onMouseEnter={() => playSfx('hover')}
                  className={cn(
                    'group flex min-h-[68px] w-full items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.05] px-4 py-3 text-left backdrop-blur-xl',
                    'shadow-lg shadow-black/25 transition-all duration-250 ease-out',
                    'hover:-translate-y-0.5 hover:border-white/25 hover:bg-white/[0.09] hover:shadow-xl',
                    'active:translate-y-0 active:scale-[0.98]',
                  )}
                  style={{ animationDelay: `${i * 60 + 100}ms` }}
                >
                  <span
                    className={cn(
                      'flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br shadow-lg transition-transform duration-250 group-hover:scale-110 group-hover:rotate-3',
                      item.tileClass,
                    )}
                  >
                    <item.icon className="h-6 w-6 text-white" strokeWidth={2.2} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2 text-lg font-extrabold text-white">
                      {item.title}
                      {item.badge && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-orange-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-orange-300">
                          <Flame className="h-3 w-3" />
                          {item.badge}
                        </span>
                      )}
                    </span>
                    <span className="block truncate text-xs font-medium text-slate-400">
                      {item.subtitle}
                    </span>
                  </span>
                  <ChevronRight className="h-5 w-5 shrink-0 text-slate-500 transition-all duration-250 group-hover:translate-x-1 group-hover:text-white" />
                </button>
              ))}
            </nav>

            <p className="mt-10 text-center text-[11px] font-semibold uppercase tracking-[0.3em] text-slate-600">
              Maze Universe · v1.0 · Chart the impossible
            </p>
          </div>
        )}

        {view === 'worlds' && (
          <div key="worlds" className="animate-view-in">
            <WorldMap
              onBack={() => setView('home')}
              onSelectWorld={(world) => {
                playSfx('click');
                if (world.id === 10) {
                  router.push('/infinite');
                  return;
                }
                setSelectedWorld(world);
                setView('levels');
              }}
            />
          </div>
        )}

        {view === 'levels' && selectedWorld && (
          <div key="levels" className="animate-view-in">
            <LevelSelect
              world={selectedWorld}
              onBack={() => setView('worlds')}
              onPlay={(n) => {
                playSfx('click');
                router.push(`/play/${selectedWorld.id}/${n}`);
              }}
            />
          </div>
        )}
      </main>
    </div>
  );
}
