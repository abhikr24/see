'use client';

import { ChevronLeft, Lock, Play, Star } from 'lucide-react';
import type { WorldConfig } from '@/lib/maze/types';
import { useGameStore } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { levelId as makeLevelId } from '@/lib/utils/helpers';
import { getLevelConfig } from '@/lib/maze/constants';
import { formatElapsed } from '@/lib/game/timer';
import { cn } from '@/lib/utils/helpers';

interface LevelSelectProps {
  world: WorldConfig;
  onBack: () => void;
  onPlay: (levelNumber: number) => void;
}

/** Level grid for one world — stars, locks, best times. */
export function LevelSelect({ world, onBack, onPlay }: LevelSelectProps) {
  const hydrated = useHydrated();
  const completedLevels = useGameStore((s) => s.progress.completedLevels);

  const firstIncomplete = (() => {
    for (let n = 1; n <= world.totalLevels; n++) {
      if (!completedLevels[makeLevelId(world.id, n)]) return n;
    }
    return world.totalLevels + 1;
  })();

  const starsEarned = Object.entries(completedLevels).reduce(
    (acc, [id, v]) => (id.startsWith(`w${world.id}-`) ? acc + v.stars : acc),
    0,
  );

  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-28 pt-4 md:pb-10">
      {/* World header */}
      <div
        className="relative mb-5 overflow-hidden rounded-3xl border border-white/10 p-5"
        style={{
          background: `linear-gradient(135deg, ${world.gradientFrom}dd, #0a0f1e 65%)`,
        }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            aria-label="Back to worlds"
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/15 bg-black/25 text-white backdrop-blur transition-all hover:bg-black/40 active:scale-95"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-black uppercase tracking-[0.35em] text-white/60">
              World {world.id} · {world.subtitle}
            </p>
            <h1 className="truncate text-2xl font-black tracking-wide text-white">
              {world.name}
            </h1>
          </div>
          <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-white/20 bg-black/30 px-3 py-1.5 text-sm font-bold text-amber-300 backdrop-blur">
            <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
            {hydrated ? starsEarned : '—'}/{world.totalLevels * 3}
          </span>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {world.mechanics.map((m) => (
            <span
              key={m}
              className="rounded-full border border-white/15 bg-black/25 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white/80 backdrop-blur"
            >
              {m}
            </span>
          ))}
        </div>
      </div>

      {/* Level grid */}
      <div className="grid grid-cols-4 gap-2.5 sm:grid-cols-5">
        {Array.from({ length: world.totalLevels }, (_, i) => {
          const n = i + 1;
          const id = makeLevelId(world.id, n);
          const entry = hydrated ? completedLevels[id] : undefined;
          const unlocked = n === 1 || n <= firstIncomplete;
          const isNext = n === firstIncomplete;
          const cfg = getLevelConfig(world.id, n);
          return (
            <button
              key={n}
              disabled={!unlocked}
              onClick={() => onPlay(n)}
              aria-label={
                unlocked
                  ? `Play level ${n}: ${cfg.name}`
                  : `Level ${n} locked`
              }
              title={cfg.name}
              className={cn(
                'group relative flex aspect-square flex-col items-center justify-center gap-1 rounded-2xl border transition-all duration-200',
                entry
                  ? 'border-white/15 bg-gradient-to-br from-white/[0.08] to-white/[0.03] hover:border-white/30'
                  : isNext
                    ? 'border-transparent text-white shadow-lg active:scale-95'
                    : 'cursor-not-allowed border-white/[0.06] bg-white/[0.02]',
                unlocked && 'hover:-translate-y-0.5',
              )}
              style={
                isNext
                  ? {
                      background: `linear-gradient(135deg, ${world.gradientFrom}, ${world.gradientTo})`,
                      boxShadow: `0 0 22px ${world.color}55`,
                    }
                  : undefined
              }
            >
              {entry ? (
                <>
                  <span className="text-base font-black tabular-nums text-white">{n}</span>
                  <span className="flex gap-0.5">
                    {[0, 1, 2].map((s) => (
                      <Star
                        key={s}
                        className={cn(
                          'h-2.5 w-2.5',
                          s < entry.stars
                            ? 'fill-amber-400 text-amber-400'
                            : 'fill-slate-700 text-slate-600',
                        )}
                      />
                    ))}
                  </span>
                  <span className="text-[9px] font-semibold tabular-nums text-slate-500">
                    {formatElapsed(entry.bestTime)}
                  </span>
                </>
              ) : isNext ? (
                <>
                  <Play className="h-5 w-5 fill-white text-white" />
                  <span className="text-xs font-black tabular-nums">{n}</span>
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4 text-slate-600" />
                  <span className="text-xs font-bold tabular-nums text-slate-600">{n}</span>
                </>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
