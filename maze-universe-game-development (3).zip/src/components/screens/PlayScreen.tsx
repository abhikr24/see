'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { LevelResult, RunStats } from '@/lib/maze/types';
import { getLevelConfig, getWorld } from '@/lib/maze/constants';
import { coinsReward, xpReward } from '@/lib/game/scoring';
import { GameSession } from '@/components/game/GameSession';
import { LevelComplete } from '@/components/game/LevelComplete';
import { GameOver } from '@/components/game/GameOver';
import { useToast } from '@/components/ui/Toast';
import { useSoundEffects } from '@/hooks/useSoundEffects';
import { useGameStore, type CompleteLevelSummary } from '@/stores/gameStore';

interface PlayScreenProps {
  worldId: number;
  levelNumber: number;
}

export function PlayScreen({ worldId, levelNumber }: PlayScreenProps) {
  const router = useRouter();
  const { toast } = useToast();
  const playSfx = useSoundEffects();
  const completeLevel = useGameStore((s) => s.completeLevel);

  const world = getWorld(worldId);
  const level = useMemo(() => getLevelConfig(worldId, levelNumber), [worldId, levelNumber]);

  const [runId, setRunId] = useState(0);
  const [result, setResult] = useState<{
    stats: RunStats;
    summary: CompleteLevelSummary;
  } | null>(null);
  const [over, setOver] = useState<RunStats | null>(null);

  const handleComplete = (stats: RunStats) => {
    const firstClear = !useGameStore.getState().progress.completedLevels[level.id];
    const resultData: LevelResult = {
      levelId: level.id,
      worldId,
      levelNumber,
      stars: stats.stars,
      time: stats.time,
      coins: coinsReward(level, stats.stars, stats.coinsCollected, firstClear),
      totalCoins: stats.totalCoins,
      xp: xpReward(level, stats.stars, firstClear),
      moves: stats.moves,
      victory: true,
    };
    const summary = completeLevel(resultData);
    if (summary.leveledTo > 0) {
      playSfx('levelup');
      toast({
        title: `Pilot level ${summary.leveledTo}!`,
        message: 'Bonus coins added to your vault.',
        variant: 'success',
      });
    }
    for (const w of summary.newlyUnlockedWorlds) {
      const worldCfg = getWorld(w);
      toast({
        title: `New world unlocked: ${worldCfg.name}`,
        message: worldCfg.description,
        variant: 'success',
      });
    }
    setResult({ stats, summary });
  };

  const hasNext = levelNumber < world.totalLevels;

  return (
    <div className="fixed inset-0 z-50 bg-[#0a0f1e]">
      <GameSession
        key={`${level.id}:${runId}`}
        level={level}
        world={world}
        tag={`World ${worldId} · ${world.name}`}
        onComplete={handleComplete}
        onGameOver={(stats: RunStats) => setOver(stats)}
        onExit={() => router.push('/')}
      />

      <LevelComplete
        open={result !== null}
        stats={result?.stats ?? null}
        summary={result?.summary ?? null}
        hasNext={hasNext}
        onNext={hasNext ? () => router.push(`/play/${worldId}/${levelNumber + 1}`) : undefined}
        onReplay={() => {
          setResult(null);
          setRunId((r) => r + 1);
        }}
        onHome={() => router.push('/')}
      />

      <GameOver
        open={over !== null}
        stats={over}
        onRetry={() => {
          setOver(null);
          setRunId((r) => r + 1);
        }}
        onHome={() => router.push('/')}
      />
    </div>
  );
}
