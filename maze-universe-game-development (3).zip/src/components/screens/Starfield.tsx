'use client';

import { useEffect, useRef } from 'react';
import { mulberry32 } from '@/lib/utils/helpers';

interface StarfieldProps {
  density?: number;
  className?: string;
}

interface Star {
  x: number;
  y: number;
  r: number;
  phase: number;
  speed: number;
  color: string;
}

interface Meteor {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

/** Animated deep-space starfield with twinkling stars and shooting meteors. */
export function Starfield({ density = 1, className }: StarfieldProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rng = mulberry32(1337);
    let stars: Star[] = [];
    let meteors: Meteor[] = [];
    const palette = ['#ffffff', '#bfdbfe', '#ddd6fe', '#a5f3fc', '#fef3c7'];
    let w = 0;
    let h = 0;
    let raf = 0;
    const dpr = Math.min(2, window.devicePixelRatio || 1);

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      w = rect?.width ?? window.innerWidth;
      h = rect?.height ?? window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.floor(((w * h) / 2600) * density);
      stars = Array.from({ length: count }, () => ({
        x: rng() * w,
        y: rng() * h,
        r: 0.4 + rng() * 1.5,
        phase: rng() * Math.PI * 2,
        speed: 0.4 + rng() * 1.2,
        color: palette[Math.floor(rng() * palette.length)],
      }));
    };

    resize();
    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    let last = performance.now();
    let meteorTimer = 2.5;

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      ctx.clearRect(0, 0, w, h);

      // nebula washes
      const neb1 = ctx.createRadialGradient(w * 0.18, h * 0.22, 0, w * 0.18, h * 0.22, w * 0.5);
      neb1.addColorStop(0, 'rgba(59,130,246,0.10)');
      neb1.addColorStop(1, 'rgba(59,130,246,0)');
      ctx.fillStyle = neb1;
      ctx.fillRect(0, 0, w, h);
      const neb2 = ctx.createRadialGradient(w * 0.85, h * 0.7, 0, w * 0.85, h * 0.7, w * 0.55);
      neb2.addColorStop(0, 'rgba(139,92,246,0.10)');
      neb2.addColorStop(1, 'rgba(139,92,246,0)');
      ctx.fillStyle = neb2;
      ctx.fillRect(0, 0, w, h);

      // stars
      for (const s of stars) {
        const tw = 0.45 + 0.55 * Math.sin(s.phase + (now / 1000) * s.speed);
        ctx.globalAlpha = tw;
        ctx.fillStyle = s.color;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
        if (s.r > 1.3 && tw > 0.85) {
          ctx.globalAlpha = (tw - 0.8) * 0.9;
          ctx.strokeStyle = s.color;
          ctx.lineWidth = 0.6;
          ctx.beginPath();
          ctx.moveTo(s.x - s.r * 3, s.y);
          ctx.lineTo(s.x + s.r * 3, s.y);
          ctx.moveTo(s.x, s.y - s.r * 3);
          ctx.lineTo(s.x, s.y + s.r * 3);
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;

      // meteors
      meteorTimer -= dt;
      if (meteorTimer <= 0) {
        meteorTimer = 3 + rng() * 5;
        meteors.push({
          x: rng() * w * 0.9 + w * 0.05,
          y: rng() * h * 0.3,
          vx: -(160 + rng() * 220),
          vy: 120 + rng() * 160,
          life: 0,
          maxLife: 0.9 + rng() * 0.5,
        });
      }
      for (const m of meteors) {
        m.life += dt;
        m.x += m.vx * dt;
        m.y += m.vy * dt;
        const k = 1 - m.life / m.maxLife;
        if (k <= 0) continue;
        const grad = ctx.createLinearGradient(m.x, m.y, m.x - m.vx * 0.14, m.y - m.vy * 0.14);
        grad.addColorStop(0, `rgba(226,240,255,${0.85 * k})`);
        grad.addColorStop(1, 'rgba(226,240,255,0)');
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(m.x, m.y);
        ctx.lineTo(m.x - m.vx * 0.14, m.y - m.vy * 0.14);
        ctx.stroke();
      }
      meteors = meteors.filter((m) => m.life < m.maxLife);

      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [density]);

  return <canvas ref={canvasRef} className={className ?? 'absolute inset-0'} aria-hidden />;
}
