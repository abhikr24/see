'use client';

import { ChevronLeft, Lock, Star } from 'lucide-react';
import type { WorldConfig } from '@/lib/maze/types';
import { WORLDS } from '@/lib/maze/constants';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { useGameStore } from '@/stores/gameStore';
import { useHydrated } from '@/hooks/useGameState';
import { levelTag } from '@/lib/utils/helpers';
import { cn } from '@/lib/utils/helpers';

interface WorldMapProps {
  onSelectWorld: (world: WorldConfig) => void;
  onBack: () => void;
}

/** Scrollable planet list — the adventure world map. */
export function WorldMap({ onSelectWorld, onBack }: WorldMapProps) {
  const hydrated = useHydrated();
  const completedLevels = useGameStore((s) => s.progress.completedLevels);
  const unlockedWorlds = useGameStore((s) => s.progress.unlockedWorlds);
  const totalStars = useGameStore((s) => s.progress.totalStars);

  const starsInWorld = (worldId: number) =>
    Object.entries(completedLevels).reduce(
      (acc, [id, v]) => (id.startsWith(`w${worldId}-`) ? acc + v.stars : acc),
      0,
    );

  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-28 pt-4 md:pb-10">
      <div className="mb-5 flex items-center gap-3">
        <button
          onClick={onBack}
          aria-label="Back"
          className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-slate-300 transition-all hover:bg-white/10 hover:text-white active:scale-95"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-2xl font-black tracking-wide text-white">ADVENTURE</h1>
          <p className="text-xs font-semibold uppercase tracking-widest text-slate-400">
            Choose your galaxy
          </p>
        </div>
        <span className="ml-auto inline-flex items-center gap-1.5 rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-1.5 text-sm font-bold text-amber-300">
          <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
          {hydrated ? totalStars : '—'}
        </span>
      </div>

      <div className="flex flex-col gap-4">
        {WORLDS.map((world, i) => {
          const unlocked = hydrated && unlockedWorlds.includes(world.id);
          const earned = starsInWorld(world.id);
          const max = world.totalLevels * 3;
          const isInfinite = world.id === 10;
          return (
            <button
              key={world.id}
              onClick={() => unlocked && onSelectWorld(world)}
              disabled={!unlocked}
              className={cn(
                'group relative flex w-full items-center gap-4 overflow-hidden rounded-3xl border p-4 text-left transition-all duration-300',
                unlocked
                  ? 'border-white/10 bg-white/[0.04] hover:border-white/25 hover:bg-white/[0.07] active:scale-[0.985]'
                  : 'cursor-not-allowed border-white/[0.06] bg-white/[0.02] opacity-70',
              )}
              style={{ animationDelay: `${i * 55}ms` }}
            >
              {/* Planet orb */}
              <div className="relative shrink-0">
                <div
                  className={cn(
                    'flex h-20 w-20 items-center justify-center rounded-full shadow-xl transition-transform duration-300',
                    unlocked && 'group-hover:scale-105',
                  )}
                  style={{
                    background: `radial-gradient(circle at 32% 28%, ${world.gradientTo}, ${world.gradientFrom} 70%)`,
                    boxShadow: unlocked ? `0 0 34px ${world.color}55, inset -6px -8px 18px rgba(0,0,0,0.45)` : 'inset -6px -8px 18px rgba(0,0,0,0.45)',
                    filter: unlocked ? 'none' : 'grayscale(0.85) brightness(0.7)',
                  }}
                >
                  <span className="text-xl font-black text-white/90 drop-shadow-md">
                    {levelTag(world.id)}
                  </span>
                </div>
                {!unlocked && (
                  <span className="absolute inset-0 flex items-center justify-center">
                    <Lock className="h-6 w-6 text-white/80" />
                  </span>
                )}
                <span
                  className="absolute -inset-1.5 -z-10 rounded-full border border-dashed opacity-30"
                  style={{ borderColor: world.color }}
                />
              </div>

              {/* Info */}
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <h3 className="truncate text-lg font-black tracking-wide text-white">
                    {world.name}
                  </h3>
                  <span className="shrink-0 text-[10px] font-bold uppercase tracking-widest text-slate-500">
                    {world.subtitle}
                  </span>
                </div>
                <p className="mt-0.5 line-clamp-1 text-xs text-slate-400">{world.description}</p>
                {unlocked ? (
                  <div className="mt-2.5">
                    <ProgressBar
                      value={starsInWorld(world.id)}
                      max={isInfinite ? 1 : max}
                      label={isInfinite ? 'Endless descent' : undefined}
                      showLabel={!isInfinite}
                      variant="gold"
                      height={6}
                    />
                  </div>
                ) : (
                  <p className="mt-2.5 inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] font-bold text-slate-300">
                    <Star className="h-3 w-3 text-amber-400" />
                    Requires {world.requiredStars} stars · you have {hydrated ? totalStars : '—'}
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
