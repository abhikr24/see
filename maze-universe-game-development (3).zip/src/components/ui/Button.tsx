'use client';

import { forwardRef, type ButtonHTMLAttributes } from 'react';
import Link from 'next/link';
import { Loader2, type LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils/helpers';

type Variant = 'primary' | 'purple' | 'success' | 'danger' | 'gold' | 'ghost' | 'outline';
type Size = 'sm' | 'md' | 'lg' | 'icon';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: LucideIcon;
  iconRight?: LucideIcon;
  loading?: boolean;
  fullWidth?: boolean;
  href?: string;
  glow?: boolean;
}

const VARIANTS: Record<Variant, string> = {
  primary:
    'bg-gradient-to-br from-blue-500 to-blue-700 text-white shadow-lg shadow-blue-500/30 hover:shadow-blue-400/40 hover:from-blue-400 hover:to-blue-600 border border-blue-400/40',
  purple:
    'bg-gradient-to-br from-violet-500 to-purple-700 text-white shadow-lg shadow-violet-500/30 hover:shadow-violet-400/40 hover:from-violet-400 hover:to-purple-600 border border-violet-400/40',
  success:
    'bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-lg shadow-emerald-500/30 hover:shadow-emerald-400/40 hover:from-emerald-400 hover:to-emerald-600 border border-emerald-400/40',
  danger:
    'bg-gradient-to-br from-rose-500 to-red-700 text-white shadow-lg shadow-rose-500/30 hover:shadow-rose-400/40 hover:from-rose-400 hover:to-red-600 border border-rose-400/40',
  gold:
    'bg-gradient-to-br from-amber-400 to-orange-600 text-amber-950 shadow-lg shadow-amber-500/30 hover:shadow-amber-300/40 hover:from-amber-300 hover:to-orange-500 border border-amber-300/50',
  ghost:
    'bg-white/[0.06] text-slate-100 border border-white/10 backdrop-blur-md hover:bg-white/[0.12] hover:border-white/20 shadow-lg shadow-black/20',
  outline:
    'bg-transparent text-blue-300 border border-blue-400/40 hover:bg-blue-500/10 hover:border-blue-300/60 shadow-none',
};

const SIZES: Record<Size, string> = {
  sm: 'h-11 px-4 text-sm gap-2 rounded-xl',
  md: 'h-12 px-6 text-base gap-2.5 rounded-xl',
  lg: 'h-14 px-8 text-lg gap-3 rounded-2xl',
  icon: 'h-11 w-11 rounded-xl',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    variant = 'primary',
    size = 'md',
    icon: Icon,
    iconRight: IconRight,
    loading = false,
    fullWidth = false,
    className,
    children,
    href,
    disabled,
    glow = false,
    ...rest
  },
  ref,
) {
  const classes = cn(
    'relative inline-flex items-center justify-center font-semibold tracking-wide select-none',
    'transition-all duration-200 ease-out active:scale-[0.96] touch-manipulation',
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950',
    'disabled:pointer-events-none disabled:opacity-40 disabled:saturate-50',
    VARIANTS[variant],
    SIZES[size],
    fullWidth && 'w-full',
    glow && 'before:absolute before:inset-0 before:rounded-[inherit] before:bg-white/10 before:opacity-0 hover:before:opacity-100 before:transition-opacity',
    className,
  );

  const content = (
    <>
      {loading ? (
        <Loader2 className="h-5 w-5 animate-spin" aria-hidden />
      ) : (
        Icon && <Icon className={cn(size === 'lg' ? 'h-6 w-6' : 'h-5 w-5')} aria-hidden />
      )}
      {children && <span className="truncate">{children}</span>}
      {IconRight && !loading && (
        <IconRight className={cn(size === 'lg' ? 'h-6 w-6' : 'h-5 w-5')} aria-hidden />
      )}
    </>
  );

  if (href && !disabled) {
    return (
      <Link href={href} className={classes}>
        {content}
      </Link>
    );
  }

  return (
    <button ref={ref} className={classes} disabled={disabled || loading} {...rest}>
      {content}
    </button>
  );
});
