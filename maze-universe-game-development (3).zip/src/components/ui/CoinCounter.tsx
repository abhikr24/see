'use client';

import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils/helpers';

interface CoinCounterProps {
  amount: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/** Inline SVG gold coin (no emoji). */
export function CoinIcon({ size = 18, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={className} aria-hidden>
      <defs>
        <radialGradient id="coinGrad" cx="35%" cy="30%" r="80%">
          <stop offset="0%" stopColor="#fde68a" />
          <stop offset="55%" stopColor="#fbbf24" />
          <stop offset="100%" stopColor="#b45309" />
        </radialGradient>
      </defs>
      <circle cx="12" cy="12" r="10" fill="url(#coinGrad)" />
      <circle cx="12" cy="12" r="7" fill="none" stroke="#92400e" strokeOpacity="0.55" strokeWidth="1.4" />
      <path d="M12 7.6l1.5 3 3.3.5-2.4 2.3.6 3.3-3-1.6-3 1.6.6-3.3-2.4-2.3 3.3-.5z" fill="#78350f" fillOpacity="0.72" />
      <ellipse cx="9.2" cy="7.6" rx="2.6" ry="1.5" fill="#fff7ed" opacity="0.5" transform="rotate(-24 9.2 7.6)" />
    </svg>
  );
}

const SIZES = {
  sm: { text: 'text-sm', icon: 16 },
  md: { text: 'text-base', icon: 20 },
  lg: { text: 'text-xl', icon: 26 },
};

/** Coin counter with animated value tween and pop feedback. */
export function CoinCounter({ amount, size = 'md', className }: CoinCounterProps) {
  const [display, setDisplay] = useState(amount);
  const [pulse, setPulse] = useState(false);
  const prevRef = useRef(amount);
  const rafRef = useRef(0);

  useEffect(() => {
    const from = prevRef.current;
    const to = amount;
    prevRef.current = amount;
    if (from === to) return;
    cancelAnimationFrame(rafRef.current);
    const startT = performance.now();
    const dur = 550;
    const tick = (t: number) => {
      const k = Math.min(1, (t - startT) / dur);
      const eased = 1 - Math.pow(1 - k, 3);
      setDisplay(Math.round(from + (to - from) * eased));
      if (k < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    if (to > from) {
      setPulse(true);
      const t = setTimeout(() => setPulse(false), 420);
      return () => {
        cancelAnimationFrame(rafRef.current);
        clearTimeout(t);
      };
    }
    return () => cancelAnimationFrame(rafRef.current);
  }, [amount]);

  const s = SIZES[size];

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 font-bold tabular-nums text-amber-300',
        s.text,
        pulse && 'animate-coin-pop',
        className,
      )}
    >
      <CoinIcon size={s.icon} className={cn('shrink-0', pulse && 'animate-coin-spin')} />
      {display.toLocaleString()}
    </span>
  );
}
