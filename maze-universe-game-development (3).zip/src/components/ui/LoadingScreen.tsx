'use client';

import { LogoMark } from '@/components/layout/Header';

interface LoadingScreenProps {
  message?: string;
}

/** Full-screen branded loader with orbit animation. */
export function LoadingScreen({ message = 'Charting the maze…' }: LoadingScreenProps) {
  return (
    <div className="fixed inset-0 z-[90] flex flex-col items-center justify-center gap-8 bg-[#0a0f1e]">
      <div className="relative flex items-center justify-center">
        <div className="absolute h-40 w-40 rounded-full bg-blue-500/15 blur-3xl" />
        <div className="absolute h-40 w-40 animate-spin-slow rounded-full border border-dashed border-blue-400/20" />
        <div className="absolute h-28 w-28 animate-spin-reverse rounded-full border border-violet-400/25" />
        <LogoMark size={56} />
        <span className="absolute -right-5 -top-5 h-2.5 w-2.5 animate-ping rounded-full bg-cyan-300" />
      </div>
      <div className="flex flex-col items-center gap-3">
        <p className="text-xs font-bold uppercase tracking-[0.5em] text-blue-300/90">
          Maze Universe
        </p>
        <p className="text-sm text-slate-400">{message}</p>
        <div className="h-1 w-44 overflow-hidden rounded-full bg-slate-800">
          <div className="animate-load-slide h-full w-1/3 rounded-full bg-gradient-to-r from-blue-500 via-violet-400 to-emerald-400" />
        </div>
      </div>
    </div>
  );
}
