'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils/helpers';

interface ModalProps {
  open: boolean;
  onClose?: () => void;
  title?: string;
  children?: ReactNode;
  dismissible?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/** Glass-morphism modal with smooth scale/fade transitions. */
export function Modal({
  open,
  onClose,
  title,
  children,
  dismissible = true,
  size = 'md',
  className,
}: ModalProps) {
  const [render, setRender] = useState(open);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    if (open) {
      setRender(true);
      const t = requestAnimationFrame(() => setShown(true));
      return () => cancelAnimationFrame(t);
    }
    setShown(false);
    const t = setTimeout(() => setRender(false), 240);
    return () => clearTimeout(t);
  }, [open]);

  useEffect(() => {
    if (!render || !dismissible || !onClose) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [render, dismissible, onClose]);

  if (!render) return null;

  const widths = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-2xl' };

  return (
    <div
      className={cn(
        'fixed inset-0 z-[80] flex items-end sm:items-center justify-center p-4 transition-opacity duration-200',
        shown ? 'opacity-100' : 'opacity-0',
      )}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="absolute inset-0 bg-slate-950/70 backdrop-blur-md"
        onClick={dismissible ? onClose : undefined}
      />
      <div
        className={cn(
          'relative w-full rounded-3xl border border-white/10 bg-slate-900/85 backdrop-blur-2xl',
          'shadow-2xl shadow-black/50 p-6 transition-all duration-300 ease-out',
          shown ? 'translate-y-0 scale-100 opacity-100' : 'translate-y-6 scale-95 opacity-0',
          widths[size],
          className,
        )}
      >
        {(title || (dismissible && onClose)) && (
          <div className="mb-4 flex items-center justify-between gap-4">
            {title && (
              <h2 className="text-xl font-extrabold tracking-wide text-white">{title}</h2>
            )}
            {dismissible && onClose && (
              <button
                onClick={onClose}
                aria-label="Close"
                className="ml-auto flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-slate-300 transition-all hover:bg-white/10 hover:text-white active:scale-95"
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
