'use client';

import { cn } from '@/lib/utils/helpers';

interface ProgressBarProps {
  value: number;
  max: number;
  variant?: 'blue' | 'purple' | 'emerald' | 'gold' | 'danger';
  height?: number;
  showLabel?: boolean;
  label?: string;
  className?: string;
  animated?: boolean;
}

const GRADIENTS: Record<NonNullable<ProgressBarProps['variant']>, string> = {
  blue: 'from-blue-400 via-sky-400 to-cyan-300',
  purple: 'from-violet-400 via-purple-400 to-fuchsia-300',
  emerald: 'from-emerald-400 via-teal-300 to-cyan-300',
  gold: 'from-amber-300 via-yellow-400 to-orange-400',
  danger: 'from-rose-400 via-red-400 to-orange-400',
};

/** Animated progress bar with shimmer sheen. */
export function ProgressBar({
  value,
  max,
  variant = 'blue',
  height = 8,
  showLabel = false,
  label,
  className,
  animated = true,
}: ProgressBarProps) {
  const pct = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;
  return (
    <div className={cn('w-full', className)}>
      {(showLabel || label) && (
        <div className="mb-1.5 flex items-center justify-between text-xs font-semibold tracking-wide text-slate-300">
          <span>{label}</span>
          {showLabel && (
            <span className="tabular-nums text-slate-400">
              {Math.round(value)}/{Math.round(max)}
            </span>
          )}
        </div>
      )}
      <div
        className="relative w-full overflow-hidden rounded-full border border-white/10 bg-slate-800/80"
        style={{ height }}
        role="progressbar"
        aria-valuenow={Math.round(value)}
        aria-valuemax={Math.round(max)}
      >
        <div
          className={cn(
            'h-full rounded-full bg-gradient-to-r transition-all duration-300 ease-out',
            GRADIENTS[variant],
          )}
          style={{ width: `${pct}%` }}
        >
          {animated && pct > 6 && (
            <div className="animate-shimmer absolute inset-y-0 right-0 w-16 bg-gradient-to-r from-transparent via-white/40 to-transparent" />
          )}
        </div>
      </div>
    </div>
  );
}
