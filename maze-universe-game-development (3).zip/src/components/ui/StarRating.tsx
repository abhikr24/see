'use client';

import { useEffect, useState } from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils/helpers';

interface StarRatingProps {
  stars: number; // 0..3 earned
  size?: 'sm' | 'md' | 'lg' | 'xl';
  animated?: boolean;
  className?: string;
  onStarShown?: (index: number) => void;
}

const PX: Record<NonNullable<StarRatingProps['size']>, number> = {
  sm: 14,
  md: 20,
  lg: 34,
  xl: 46,
};

/** Three-star display with staggered pop-in animation. */
export function StarRating({
  stars,
  size = 'md',
  animated = false,
  className,
  onStarShown,
}: StarRatingProps) {
  const [shown, setShown] = useState(animated ? 0 : 3);

  useEffect(() => {
    if (!animated) return;
    setShown(0);
    let i = 0;
    const timers: ReturnType<typeof setTimeout>[] = [];
    const step = () => {
      i += 1;
      setShown(i);
      onStarShown?.(i - 1);
      if (i < 3) timers.push(setTimeout(step, 420));
    };
    timers.push(setTimeout(step, 350));
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [animated, stars]);

  const px = PX[size];

  return (
    <div className={cn('flex items-center gap-1.5', className)} aria-label={`${stars} of 3 stars`}>
      {[0, 1, 2].map((i) => {
        const earned = i < stars;
        const visible = i < shown;
        const big = size === 'lg' || size === 'xl';
        return (
          <span
            key={i}
            className={cn(
              'relative inline-flex transition-all duration-300 ease-out',
              visible ? 'scale-100 opacity-100' : 'scale-0 opacity-0',
              earned && big && 'drop-shadow-[0_0_10px_rgba(251,191,36,0.65)]',
            )}
            style={i === 1 && big ? { transform: `translateY(-${px * 0.18}px) scale(${visible ? 1.15 : 0})` } : undefined}
          >
            <Star
              width={px}
              height={px}
              className={cn(
                'transition-colors duration-300',
                earned ? 'fill-amber-400 text-amber-300' : 'fill-slate-700/40 text-slate-600',
              )}
              strokeWidth={1.5}
            />
          </span>
        );
      })}
    </div>
  );
}
