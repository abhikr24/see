'use client';

import { useEffect, useRef } from 'react';

/**
 * requestAnimationFrame loop with delta-time (seconds).
 * `running=false` keeps the loop mounted but skips callbacks.
 */
export function useGameLoop(
  callback: (dt: number, now: number) => void,
  opts: { running?: boolean; maxDelta?: number } = {},
): void {
  const { running = true, maxDelta = 0.05 } = opts;
  const cbRef = useRef(callback);
  cbRef.current = callback;
  const runningRef = useRef(running);
  runningRef.current = running;

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const frame = (now: number) => {
      const dt = Math.min((now - last) / 1000, maxDelta);
      last = now;
      if (runningRef.current) {
        cbRef.current(dt, now);
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [maxDelta]);
}
