'use client';

import { useEffect, useState } from 'react';
import { useGameStore } from '@/stores/gameStore';

/**
 * True after first client mount — guard for SSR/hydration mismatches
 * when rendering persisted store values.
 */
export function useHydrated(): boolean {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  return hydrated;
}

/** Convenience bundle of the most-used progress slices. */
export function useGameState() {
  const hydrated = useHydrated();
  const progress = useGameStore((s) => s.progress);
  return { hydrated, progress };
}
