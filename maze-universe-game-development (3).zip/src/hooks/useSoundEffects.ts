'use client';

import { useCallback, useEffect } from 'react';
import { soundManager } from '@/lib/audio/soundManager';
import { useGameStore } from '@/stores/gameStore';
import type { SfxName } from '@/lib/maze/types';

/** Settings-aware SFX player. Keeps the sound manager in sync. */
export function useSoundEffects(): (name: SfxName) => void {
  const soundEnabled = useGameStore((s) => s.progress.settings.soundEnabled);
  const musicEnabled = useGameStore((s) => s.progress.settings.musicEnabled);

  useEffect(() => {
    soundManager.setSoundEnabled(soundEnabled);
  }, [soundEnabled]);

  useEffect(() => {
    soundManager.setMusicEnabled(musicEnabled);
  }, [musicEnabled]);

  return useCallback(
    (name: SfxName) => {
      if (soundEnabled) soundManager.play(name);
    },
    [soundEnabled],
  );
}
