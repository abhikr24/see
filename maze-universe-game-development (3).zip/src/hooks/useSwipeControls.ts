'use client';

import { RefObject, useEffect, useRef } from 'react';
import type { Direction } from '@/lib/maze/types';

interface SwipeOptions {
  ref: RefObject<HTMLElement | null>;
  onSwipe: (dir: Direction) => void;
  enabled?: boolean;
  threshold?: number;
}

/**
 * Pointer-based swipe detector (touch, stylus, mouse-drag).
 * Attach `touch-action: none` styling to the target element.
 */
export function useSwipeControls({
  ref,
  onSwipe,
  enabled = true,
  threshold = 24,
}: SwipeOptions): void {
  const cbRef = useRef(onSwipe);
  cbRef.current = onSwipe;
  const startRef = useRef<{ x: number; y: number; id: number } | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || !enabled) return;

    const down = (e: PointerEvent) => {
      if (startRef.current) return;
      startRef.current = { x: e.clientX, y: e.clientY, id: e.pointerId };
    };

    const up = (e: PointerEvent) => {
      const start = startRef.current;
      if (!start || e.pointerId !== start.id) return;
      startRef.current = null;
      const dx = e.clientX - start.x;
      const dy = e.clientY - start.y;
      const adx = Math.abs(dx);
      const ady = Math.abs(dy);
      if (Math.max(adx, ady) < threshold) return;
      const dir: Direction =
        adx > ady ? (dx > 0 ? 'right' : 'left') : dy > 0 ? 'down' : 'up';
      cbRef.current(dir);
    };

    const cancel = () => {
      startRef.current = null;
    };

    el.addEventListener('pointerdown', down);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', cancel);
    return () => {
      el.removeEventListener('pointerdown', down);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', cancel);
    };
  }, [ref, enabled, threshold]);
}

/** Arrow-key / WASD movement. */
export function useKeyboardControls(
  onMove: (dir: Direction) => void,
  opts: { enabled?: boolean; onPauseKey?: () => void } = {},
): void {
  const { enabled = true, onPauseKey } = opts;
  const cbRef = useRef(onMove);
  cbRef.current = onMove;
  const pauseRef = useRef(onPauseKey);
  pauseRef.current = onPauseKey;

  useEffect(() => {
    if (!enabled) return;
    const handler = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const map: Record<string, Direction | undefined> = {
        arrowup: 'up',
        w: 'up',
        arrowdown: 'down',
        s: 'down',
        arrowleft: 'left',
        a: 'left',
        arrowright: 'right',
        d: 'right',
      };
      const dir = map[k];
      if (dir) {
        e.preventDefault();
        cbRef.current(dir);
        return;
      }
      if (k === 'escape' || k === 'p') {
        pauseRef.current?.();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [enabled]);
}
