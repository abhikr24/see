// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Procedural Sound Manager (Web Audio API)
// All SFX + ambient music are synthesized — zero asset files.
// ─────────────────────────────────────────────────────────────

import type { SfxName } from '@/lib/maze/types';

class SoundManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private soundEnabled = true;
  private musicEnabled = true;
  private musicTimer: ReturnType<typeof setInterval> | null = null;
  private musicStep = 0;
  private unlocked = false;

  /** Must be called from a user gesture at least once. */
  unlock(): void {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AC =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.16;
      this.musicGain.connect(this.master);
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
    if (!this.unlocked) {
      this.unlocked = true;
      if (this.musicEnabled) this.startMusic();
    }
  }

  setSoundEnabled(on: boolean): void {
    this.soundEnabled = on;
  }

  setMusicEnabled(on: boolean): void {
    this.musicEnabled = on;
    if (on) this.startMusic();
    else this.stopMusic();
  }

  private tone(
    freq: number,
    dur: number,
    opts: {
      type?: OscillatorType;
      gain?: number;
      slideTo?: number;
      delay?: number;
      dest?: GainNode | null;
    } = {},
  ): void {
    if (!this.ctx || !this.master) return;
    const { type = 'sine', gain = 0.25, slideTo, delay = 0, dest } = opts;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo != null) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(dest ?? this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  play(name: SfxName): void {
    if (!this.soundEnabled || !this.ctx) return;
    switch (name) {
      case 'click':
        this.tone(720, 0.06, { type: 'triangle', gain: 0.18 });
        break;
      case 'hover':
        this.tone(440, 0.04, { type: 'sine', gain: 0.06 });
        break;
      case 'move':
        this.tone(180, 0.05, { type: 'sine', gain: 0.07 });
        break;
      case 'bump':
        this.tone(110, 0.09, { type: 'sawtooth', gain: 0.12, slideTo: 60 });
        break;
      case 'slide':
        this.tone(320, 0.14, { type: 'sine', gain: 0.08, slideTo: 520 });
        break;
      case 'coin':
        this.tone(880, 0.07, { type: 'square', gain: 0.1 });
        this.tone(1320, 0.12, { type: 'square', gain: 0.1, delay: 0.07 });
        break;
      case 'key':
        this.tone(620, 0.08, { type: 'triangle', gain: 0.14 });
        this.tone(930, 0.08, { type: 'triangle', gain: 0.14, delay: 0.08 });
        this.tone(1240, 0.14, { type: 'triangle', gain: 0.14, delay: 0.16 });
        break;
      case 'door':
        this.tone(200, 0.3, { type: 'sawtooth', gain: 0.1, slideTo: 70 });
        this.tone(90, 0.3, { type: 'square', gain: 0.08, delay: 0.05 });
        break;
      case 'teleport':
        this.tone(300, 0.22, { type: 'sine', gain: 0.16, slideTo: 1800 });
        this.tone(1800, 0.25, { type: 'sine', gain: 0.1, slideTo: 240, delay: 0.12 });
        break;
      case 'powerup':
        [523, 659, 784].forEach((f, i) =>
          this.tone(f, 0.16, { type: 'triangle', gain: 0.13, delay: i * 0.06 }),
        );
        break;
      case 'freeze':
        this.tone(1600, 0.35, { type: 'sine', gain: 0.1, slideTo: 3200 });
        this.tone(2400, 0.3, { type: 'sine', gain: 0.06, slideTo: 900, delay: 0.08 });
        break;
      case 'shield':
        this.tone(340, 0.18, { type: 'triangle', gain: 0.16, slideTo: 540 });
        this.tone(680, 0.2, { type: 'triangle', gain: 0.1, delay: 0.1 });
        break;
      case 'gate':
        this.tone(140, 0.22, { type: 'square', gain: 0.07, slideTo: 90 });
        this.tone(460, 0.14, { type: 'sine', gain: 0.05, delay: 0.05 });
        break;
      case 'win':
        [523, 659, 784, 1046, 1318].forEach((f, i) =>
          this.tone(f, 0.34, { type: 'triangle', gain: 0.16, delay: i * 0.11 }),
        );
        break;
      case 'lose':
        [392, 370, 330, 262].forEach((f, i) =>
          this.tone(f, 0.34, { type: 'sawtooth', gain: 0.09, delay: i * 0.16 }),
        );
        break;
      case 'star':
        this.tone(1568, 0.5, { type: 'sine', gain: 0.14 });
        this.tone(784, 0.4, { type: 'sine', gain: 0.08, delay: 0.02 });
        break;
      case 'tick':
        this.tone(1100, 0.04, { type: 'square', gain: 0.06 });
        break;
      case 'levelup':
        [660, 880, 1100, 1320].forEach((f, i) =>
          this.tone(f, 0.22, { type: 'square', gain: 0.1, delay: i * 0.08 }),
        );
        break;
    }
  }

  /** Slow ambient arpeggio — synthwave-ish pad loop. */
  startMusic(): void {
    if (!this.musicEnabled || !this.ctx || this.musicTimer) return;
    const scale = [220, 261.6, 329.6, 392, 440, 523.2, 659.2, 784];
    const pattern = [0, 2, 4, 7, 4, 2, 5, 3, 0, 4, 2, 6];
    this.musicTimer = setInterval(() => {
      if (!this.ctx || !this.musicGain) return;
      const n = pattern[this.musicStep % pattern.length];
      const f = scale[n % scale.length];
      this.tone(f, 0.5, { type: 'sine', gain: 0.2, dest: this.musicGain });
      if (this.musicStep % 2 === 0) {
        this.tone(f / 2, 0.9, { type: 'triangle', gain: 0.14, dest: this.musicGain });
      }
      if (this.musicStep % 4 === 2) {
        this.tone(f * 2, 0.4, { type: 'sine', gain: 0.07, dest: this.musicGain });
      }
      this.musicStep++;
    }, 420);
  }

  stopMusic(): void {
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

export const soundManager = new SoundManager();
