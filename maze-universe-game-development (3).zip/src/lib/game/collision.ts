// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Arrival / Collision Resolution
// What happens when the player lands on a cell.
// ─────────────────────────────────────────────────────────────

import type { Cell, KeyColor, MazeGrid, Player, PowerUpId } from '@/lib/maze/types';
import { asKeyColor } from '@/lib/maze/types';

export interface ArrivalResult {
  coin: boolean;
  key: boolean;
  /** Colour of the key collected this step, if any. */
  keyColor: KeyColor | null;
  teleported: { x: number; y: number } | null;
  win: boolean;
  landedOnIce: boolean;
  /** Power-up picked up off the floor this step, if any. */
  powerUp: PowerUpId | null;
}

/** Resolve everything about landing on a cell (mutates maze/player). */
export function resolveArrival(maze: MazeGrid, player: Player): ArrivalResult {
  const res: ArrivalResult = {
    coin: false,
    key: false,
    keyColor: null,
    teleported: null,
    win: false,
    landedOnIce: false,
    powerUp: null,
  };

  const cell = maze.cells[player.targetY]?.[player.targetX];
  if (!cell) return res;

  // Mark exploration
  cell.visited = true;
  cell.visible = true;

  // Trail bookkeeping (cap length; snake variant keeps longer)
  const maxTrail = maze.variant === 'snake' ? 120 : 10;
  const last = player.trail[player.trail.length - 1];
  if (!last || last.x !== player.targetX || last.y !== player.targetY) {
    player.trail.push({ x: player.targetX, y: player.targetY });
    if (player.trail.length > maxTrail) player.trail.shift();
  }

  switch (cell.type) {
    case 'coin':
      cell.type = 'path';
      player.coins += 1;
      maze.coinsLeft = Math.max(0, maze.coinsLeft - 1);
      res.coin = true;
      break;

    case 'key': {
      const lock = asKeyColor(cell.metadata?.lock);
      cell.type = 'path';
      player.keys[lock] = (player.keys[lock] ?? 0) + 1;
      res.key = true;
      res.keyColor = lock;
      break;
    }

    case 'teleporter': {
      const partner = findTeleporterPartner(maze, cell);
      if (partner) res.teleported = { x: partner.x, y: partner.y };
      break;
    }

    case 'exit':
      res.win = true;
      break;

    case 'powerup': {
      const id = cell.metadata?.powerUp as PowerUpId | undefined;
      cell.type = 'path';
      if (id) {
        res.powerUp = id;
        player.powerUps[id] = (player.powerUps[id] ?? 0) + 1;
      }
      break;
    }

    case 'ice':
      res.landedOnIce = true;
      break;

    default:
      break;
  }

  return res;
}

/** Teleporters pair via metadata.pairId. */
export function findTeleporterPartner(
  maze: MazeGrid,
  cell: Cell,
): { x: number; y: number } | null {
  const pairId = cell.metadata?.pairId;
  if (pairId == null) return null;
  for (const row of maze.cells) {
    for (const c of row) {
      if (c.type === 'teleporter' && c !== cell && c.metadata?.pairId === pairId) {
        return { x: c.x, y: c.y };
      }
    }
  }
  return null;
}

/** Try to unlock an adjacent door with a held key. Returns true if opened. */
export function tryOpenDoor(
  maze: MazeGrid,
  player: Player,
  dirX: number,
  dirY: number,
): boolean {
  const nx = player.targetX + dirX;
  const ny = player.targetY + dirY;
  const cell = maze.cells[ny]?.[nx];
  if (!cell || cell.type !== 'door') return false;
  const lock = asKeyColor(cell.metadata?.lock);
  if ((player.keys[lock] ?? 0) <= 0) return false;
  player.keys[lock] -= 1;
  // Only the lock is removed — the cell keeps its carved walls so opening a
  // door can never punch an illegal passage through solid rock.
  cell.type = 'path';
  return true;
}

/** Is there an (unopened) door at this position? */
export function isDoor(maze: MazeGrid, x: number, y: number): boolean {
  return maze.cells[y]?.[x]?.type === 'door';
}

/** Check enemy/player overlap (post-move). */
export function enemyHitsPlayer(
  enemies: Array<{ x: number; y: number; frozen: boolean }>,
  px: number,
  py: number,
): boolean {
  return enemies.some((e) => e.x === px && e.y === py);
}
