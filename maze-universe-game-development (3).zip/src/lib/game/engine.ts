// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Engine Helpers
// Runtime state construction, enemies, gate rhythm.
// ─────────────────────────────────────────────────────────────

import type { Enemy, GameState, LevelConfig, MazeGrid, Player } from '@/lib/maze/types';
import { DEFAULT_POWERUPS } from '@/lib/maze/constants';

export function createPlayer(maze: MazeGrid): Player {
  return {
    x: maze.start.x,
    y: maze.start.y,
    targetX: maze.start.x,
    targetY: maze.start.y,
    animProgress: 1,
    direction: 'right',
    alive: true,
    coins: 0,
    keys: {},
    powerUps: { ...DEFAULT_POWERUPS },
    trail: [{ x: maze.start.x, y: maze.start.y }],
  };
}

export function createEnemies(maze: MazeGrid, difficulty: LevelConfig['difficulty']): Enemy[] {
  const interval =
    difficulty === 'expert' ? 430 : difficulty === 'hard' ? 520 : difficulty === 'medium' ? 640 : 760;
  const enemies: Enemy[] = [];
  let id = 0;
  for (const row of maze.cells) {
    for (const c of row) {
      if (c.type === 'enemy_spawn') {
        enemies.push({
          id: id++,
          x: c.x,
          y: c.y,
          targetX: c.x,
          targetY: c.y,
          animProgress: 1,
          spawnX: c.x,
          spawnY: c.y,
          stepInterval: interval,
          lastStep: 0,
          frozen: false,
        });
      }
    }
  }
  return enemies;
}

export function createGameState(config: LevelConfig, maze: MazeGrid): GameState {
  return {
    currentLevel: config,
    player: createPlayer(maze),
    maze,
    timer: config.timeLimit,
    isPlaying: false,
    isPaused: false,
    isComplete: false,
    isDead: false,
    coinsCollected: 0,
    totalCoins: maze.coinsTotal,
    starsEarned: 0,
    moveCount: 0,
    startTime: 0,
    elapsedTime: 0,
  };
}

/**
 * Advances the shifting-gate rhythm.
 *
 * Opening restores the gate's original carved walls (saved by the generator
 * in `metadata.gateWalls`) so the maze's real topology is never violated.
 * A gate is never closed while an actor stands on it — it simply waits for
 * the next cycle, which makes the mechanic tense but always fair.
 *
 * @returns true when at least one gate changed state.
 */
export function tickGates(
  maze: MazeGrid,
  occupied: Array<{ x: number; y: number }>,
): boolean {
  let changed = false;
  const SEALED = { top: true, right: true, bottom: true, left: true };

  for (const gate of maze.gates) {
    const cell = maze.cells[gate.y]?.[gate.x];
    if (!cell) continue;
    const isOccupied = occupied.some((o) => o.x === gate.x && o.y === gate.y);

    if (gate.open) {
      if (isOccupied) continue; // never trap the player
      gate.open = false;
      cell.walls = { ...SEALED };
    } else {
      gate.open = true;
      const saved = cell.metadata?.gateWalls as MazeGrid['cells'][number][number]['walls'] | undefined;
      cell.walls = saved ? { ...saved } : { top: false, right: false, bottom: false, left: false };
    }
    cell.metadata = { ...(cell.metadata ?? {}), gateOpen: gate.open };
    changed = true;
  }
  return changed;
}

/** Respawn enemies at their spawn points (shield knockback). */
export function scatterEnemies(enemies: Enemy[], now: number): void {
  for (const e of enemies) {
    e.x = e.spawnX;
    e.y = e.spawnY;
    e.targetX = e.spawnX;
    e.targetY = e.spawnY;
    e.animProgress = 1;
    e.lastStep = now + 1500; // brief stun
  }
}
