// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Particle System
//
// Lightweight, allocation-conscious particle engine used for juice:
// coin sparkles, key bursts, victory confetti, wall dust and
// expanding power-up rings.
//
// Coordinates are stored in CELL SPACE (fractional cell units) so that
// particles stay glued to the maze while the camera pans and the cell
// size changes on resize.
// ─────────────────────────────────────────────────────────────

export type ParticleKind = 'sparkle' | 'dust' | 'confetti' | 'ring' | 'shard';

export interface Particle {
  kind: ParticleKind;
  /** Position in cell units (1.0 = one maze cell). */
  x: number;
  y: number;
  /** Velocity in cells per second. */
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  /** Radius / half-size in cell units. */
  size: number;
  color: string;
  rot: number;
  vr: number;
  gravity: number;
  drag: number;
}

/** Hard cap so a frantic run can never degrade the frame rate. */
const MAX_PARTICLES = 420;

const TAU = Math.PI * 2;

/**
 * Pooled particle emitter + renderer.
 * One instance lives inside the MazeRenderer.
 */
export class ParticleSystem {
  private items: Particle[] = [];

  /** Current live particle count (diagnostics / tests). */
  get count(): number {
    return this.items.length;
  }

  /** Removes every active particle (level restart). */
  clear(): void {
    this.items.length = 0;
  }

  /** Pushes a particle unless the pool is saturated. */
  private add(p: Particle): void {
    if (this.items.length >= MAX_PARTICLES) return;
    this.items.push(p);
  }

  /**
   * Golden sparkle burst — fired when a coin is collected.
   * 5–8 particles radiating outward, fading over ~0.5s.
   */
  emitCoin(cx: number, cy: number): void {
    const n = 5 + Math.floor(Math.random() * 4);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + Math.random() * 0.5;
      const speed = 1.6 + Math.random() * 1.6;
      this.add({
        kind: 'sparkle',
        x: cx,
        y: cy,
        vx: Math.cos(a) * speed,
        vy: Math.sin(a) * speed,
        life: 0,
        maxLife: 0.42 + Math.random() * 0.18,
        size: 0.05 + Math.random() * 0.045,
        color: i % 3 === 0 ? '#fef3c7' : i % 3 === 1 ? '#fbbf24' : '#f59e0b',
        rot: Math.random() * TAU,
        vr: (Math.random() - 0.5) * 10,
        gravity: 1.6,
        drag: 2.2,
      });
    }
  }

  /** Coloured sparkle burst matching a key's colour. */
  emitKey(cx: number, cy: number, color: string): void {
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * TAU + Math.random() * 0.4;
      const speed = 1.4 + Math.random() * 2;
      this.add({
        kind: 'shard',
        x: cx,
        y: cy,
        vx: Math.cos(a) * speed,
        vy: Math.sin(a) * speed,
        life: 0,
        maxLife: 0.55 + Math.random() * 0.2,
        size: 0.055 + Math.random() * 0.04,
        color: i % 2 === 0 ? color : '#ffffff',
        rot: a,
        vr: (Math.random() - 0.5) * 12,
        gravity: 1.1,
        drag: 1.9,
      });
    }
    this.emitRing(cx, cy, color, 0.95);
  }

  /** Large celebratory confetti burst for reaching the exit. */
  emitVictory(cx: number, cy: number): void {
    const colors = ['#3b82f6', '#8b5cf6', '#10b981', '#fbbf24', '#f472b6', '#22d3ee', '#ffffff'];
    for (let i = 0; i < 70; i++) {
      const a = Math.random() * TAU;
      const speed = 2 + Math.random() * 5.5;
      this.add({
        kind: 'confetti',
        x: cx,
        y: cy,
        vx: Math.cos(a) * speed,
        vy: Math.sin(a) * speed - 2,
        life: 0,
        maxLife: 1.1 + Math.random() * 0.9,
        size: 0.07 + Math.random() * 0.06,
        color: colors[i % colors.length],
        rot: Math.random() * TAU,
        vr: (Math.random() - 0.5) * 16,
        gravity: 5.5,
        drag: 0.55,
      });
    }
    this.emitRing(cx, cy, '#a7f3d0', 1.6);
  }

  /**
   * Small grey dust puff when the player bumps a wall.
   * @param dx Unit direction of the attempted move (x).
   * @param dy Unit direction of the attempted move (y).
   */
  emitBump(cx: number, cy: number, dx: number, dy: number): void {
    for (let i = 0; i < 3; i++) {
      const spread = (Math.random() - 0.5) * 1.4;
      this.add({
        kind: 'dust',
        x: cx + dx * 0.34,
        y: cy + dy * 0.34,
        vx: dx * 0.7 + -dy * spread,
        vy: dy * 0.7 + dx * spread,
        life: 0,
        maxLife: 0.3 + Math.random() * 0.16,
        size: 0.06 + Math.random() * 0.05,
        color: '#94a3b8',
        rot: 0,
        vr: 0,
        gravity: 0.6,
        drag: 3.4,
      });
    }
  }

  /** Expanding ring of light — power-ups, teleports, shields. */
  emitRing(cx: number, cy: number, color: string, scale = 1): void {
    this.add({
      kind: 'ring',
      x: cx,
      y: cy,
      vx: 0,
      vy: 0,
      life: 0,
      maxLife: 0.55,
      size: 0.18 * scale,
      color,
      rot: scale, // reused as growth multiplier
      vr: 0,
      gravity: 0,
      drag: 0,
    });
  }

  /** Power-up pickup: ring plus a shower of themed sparks. */
  emitPowerUp(cx: number, cy: number, color: string): void {
    this.emitRing(cx, cy, color, 1.2);
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * TAU;
      this.add({
        kind: 'sparkle',
        x: cx,
        y: cy,
        vx: Math.cos(a) * 2.4,
        vy: Math.sin(a) * 2.4,
        life: 0,
        maxLife: 0.5,
        size: 0.05,
        color,
        rot: 0,
        vr: 0,
        gravity: 0,
        drag: 2.6,
      });
    }
  }

  /** Portal jump: inward-collapsing violet motes at the entry point. */
  emitTeleport(cx: number, cy: number, color = '#c4b5fd'): void {
    this.emitRing(cx, cy, color, 1.1);
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * TAU;
      this.add({
        kind: 'shard',
        x: cx + Math.cos(a) * 0.45,
        y: cy + Math.sin(a) * 0.45,
        vx: -Math.cos(a) * 1.8,
        vy: -Math.sin(a) * 1.8,
        life: 0,
        maxLife: 0.42,
        size: 0.045,
        color,
        rot: a,
        vr: 6,
        gravity: 0,
        drag: 0.4,
      });
    }
  }

  /**
   * Advances the simulation.
   * @param dt Delta time in seconds.
   */
  update(dt: number): void {
    const items = this.items;
    let write = 0;
    for (let read = 0; read < items.length; read++) {
      const p = items[read];
      p.life += dt;
      if (p.life >= p.maxLife) continue; // drop

      if (p.kind !== 'ring') {
        const damp = Math.max(0, 1 - p.drag * dt);
        p.vx *= damp;
        p.vy *= damp;
        p.vy += p.gravity * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.vr * dt;
      }

      items[write++] = p; // compact in place (no allocation)
    }
    items.length = write;
  }

  /**
   * Draws every particle.
   *
   * @param ctx Target context, already translated to canvas space.
   * @param cell Current cell size in pixels.
   * @param ox World origin x in canvas pixels.
   * @param oy World origin y in canvas pixels.
   */
  draw(ctx: CanvasRenderingContext2D, cell: number, ox: number, oy: number): void {
    if (this.items.length === 0) return;
    ctx.save();
    for (const p of this.items) {
      const t = p.life / p.maxLife;
      const fade = 1 - t * t; // ease-out alpha
      const px = ox + p.x * cell;
      const py = oy + p.y * cell;

      switch (p.kind) {
        case 'ring': {
          const r = p.size * cell * (1 + t * 3.4);
          ctx.globalAlpha = fade * 0.85;
          ctx.strokeStyle = p.color;
          ctx.lineWidth = Math.max(1, cell * 0.05 * (1 - t));
          ctx.beginPath();
          ctx.arc(px, py, r, 0, TAU);
          ctx.stroke();
          break;
        }
        case 'confetti': {
          const w = p.size * cell;
          const h = w * 0.6;
          ctx.globalAlpha = fade;
          ctx.fillStyle = p.color;
          ctx.translate(px, py);
          ctx.rotate(p.rot);
          ctx.fillRect(-w / 2, -h / 2, w, h);
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          break;
        }
        case 'shard': {
          const s = p.size * cell * (1 - t * 0.4);
          ctx.globalAlpha = fade;
          ctx.fillStyle = p.color;
          ctx.translate(px, py);
          ctx.rotate(p.rot);
          ctx.beginPath();
          ctx.moveTo(0, -s);
          ctx.lineTo(s * 0.6, 0);
          ctx.lineTo(0, s);
          ctx.lineTo(-s * 0.6, 0);
          ctx.closePath();
          ctx.fill();
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          break;
        }
        case 'dust': {
          ctx.globalAlpha = fade * 0.5;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(px, py, p.size * cell * (1 + t), 0, TAU);
          ctx.fill();
          break;
        }
        default: {
          // sparkle — four-point star
          const s = p.size * cell * (1 - t * 0.5);
          ctx.globalAlpha = fade;
          ctx.fillStyle = p.color;
          ctx.translate(px, py);
          ctx.rotate(p.rot);
          ctx.beginPath();
          ctx.moveTo(0, -s);
          ctx.quadraticCurveTo(0, 0, s, 0);
          ctx.quadraticCurveTo(0, 0, 0, s);
          ctx.quadraticCurveTo(0, 0, -s, 0);
          ctx.quadraticCurveTo(0, 0, 0, -s);
          ctx.fill();
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          break;
        }
      }
    }
    ctx.restore();
  }
}
