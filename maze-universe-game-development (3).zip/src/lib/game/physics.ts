// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Movement Physics
// Grid movement, inertia slides, gate/door blocking rules.
// ─────────────────────────────────────────────────────────────

import type { Direction, MazeGrid } from '@/lib/maze/types';

export const DIRS: Record<Direction, { dx: number; dy: number }> = {
  up: { dx: 0, dy: -1 },
  down: { dx: 0, dy: 1 },
  left: { dx: -1, dy: 0 },
  right: { dx: 1, dy: 0 },
};

export function invertDirection(dir: Direction): Direction {
  switch (dir) {
    case 'up':
      return 'down';
    case 'down':
      return 'up';
    case 'left':
      return 'right';
    case 'right':
      return 'left';
  }
}

/** Is this cell solid to walkers (door art = solid until unlocked)? */
export function cellSolid(maze: MazeGrid, x: number, y: number): boolean {
  const cell = maze.cells[y]?.[x];
  if (!cell) return true;
  return cell.type === 'door' || cell.type === 'wall';
}

/** Wall-side key for a direction. */
const WALL_KEY: Record<Direction, 'top' | 'right' | 'bottom' | 'left'> = {
  up: 'top',
  right: 'right',
  down: 'bottom',
  left: 'left',
};

/**
 * Can an actor at (x,y) step one cell in `dir`?
 * - ghost=true ignores walls (and closed gates)
 * - doors block unless unlockDoor=true (engine peeks before calling)
 */
export function canMove(
  maze: MazeGrid,
  x: number,
  y: number,
  dir: Direction,
  ghost = false,
): boolean {
  const { dx, dy } = DIRS[dir];
  const nx = x + dx;
  const ny = y + dy;
  if (nx < 0 || ny < 0 || nx >= maze.width || ny >= maze.height) return false;
  if (ghost) return true;
  const cell = maze.cells[y][x];
  if (cell.walls[WALL_KEY[dir]]) return false;
  if (cellSolid(maze, nx, ny)) return false;
  return true;
}

/**
 * Compute the full step path for one input.
 * Normal tiles: single step. Ice: keep sliding until blocked or off-ice.
 * Returns the ordered list of cells to traverse (may be empty = bump).
 */
export function computeSlidePath(
  maze: MazeGrid,
  x: number,
  y: number,
  dir: Direction,
  ghost = false,
): Array<{ x: number; y: number }> {
  const path: Array<{ x: number; y: number }> = [];
  let cx = x;
  let cy = y;
  let guard = 0;
  while (guard < maze.width * maze.height) {
    guard++;
    if (!canMove(maze, cx, cy, dir, ghost)) break;
    const { dx, dy } = DIRS[dir];
    cx += dx;
    cy += dy;
    path.push({ x: cx, y: cy });
    if (ghost) break; // ghost always single-cell taps
    const landed = maze.cells[cy][cx];
    if (landed.type !== 'ice') break;
  }
  return path;
}

/** Direction that most reduces manhattan distance to a target and has a wall. */
export function wallTowardExit(
  maze: MazeGrid,
  x: number,
  y: number,
  exit: { x: number; y: number },
): Direction | null {
  const order: Direction[] = (['up', 'down', 'left', 'right'] as Direction[]).sort((a, b) => {
    const da = DIRS[a];
    const db = DIRS[b];
    const distA = Math.abs(x + da.dx - exit.x) + Math.abs(y + da.dy - exit.y);
    const distB = Math.abs(x + db.dx - exit.x) + Math.abs(y + db.dy - exit.y);
    return distA - distB;
  });
  for (const d of order) {
    const { dx, dy } = DIRS[d];
    const nx = x + dx;
    const ny = y + dy;
    if (nx < 0 || ny < 0 || nx >= maze.width || ny >= maze.height) continue;
    if (maze.cells[y][x].walls[WALL_KEY[d]]) return d;
  }
  return null;
}

/** Remove a wall between two adjacent cells (wallBreaker power-up). */
export function smashWall(maze: MazeGrid, x: number, y: number, dir: Direction): void {
  const { dx, dy } = DIRS[dir];
  const nx = x + dx;
  const ny = y + dy;
  if (nx < 0 || ny < 0 || nx >= maze.width || ny >= maze.height) return;
  const cell = maze.cells[y][x];
  const next = maze.cells[ny][nx];
  cell.walls[WALL_KEY[dir]] = false;
  const opposite: Record<Direction, Direction> = {
    up: 'down',
    down: 'up',
    left: 'right',
    right: 'left',
  };
  next.walls[WALL_KEY[opposite[dir]]] = false;
}
