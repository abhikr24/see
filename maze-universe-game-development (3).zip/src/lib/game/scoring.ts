// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Scoring & Rewards
// ─────────────────────────────────────────────────────────────

import type { LevelConfig } from '@/lib/maze/types';

/**
 * Share of a maze's coins required for the third star. Coins are placed in
 * dead ends and off-route detours, so demanding literally every last one on
 * a 30-coin maze would be punishing rather than challenging.
 */
export const STAR_COIN_RATIO = 0.8;

/**
 * Star rating:
 * ★         finish the level
 * ★★        finish under targetTime2Star
 * ★★★       under targetTime3Star AND collect at least 80% of the coins
 *           (small mazes still require every coin)
 */
export function computeStars(
  level: LevelConfig,
  elapsedSec: number,
  coinsCollected: number,
  totalCoins: number,
): number {
  if (!Number.isFinite(elapsedSec) || elapsedSec < 0) return 1;
  const coinGoal =
    totalCoins <= 5 ? totalCoins : Math.ceil(totalCoins * STAR_COIN_RATIO);
  let stars = 1;
  if (elapsedSec <= level.targetTime2Star) stars = 2;
  if (elapsedSec <= level.targetTime3Star && coinsCollected >= coinGoal) stars = 3;
  return stars;
}

/** Coin payout for a finished run. */
export function coinsReward(
  level: LevelConfig,
  stars: number,
  coinsCollected: number,
  firstClear: boolean,
): number {
  const base = coinsCollected * 5 + stars * 15;
  const first = firstClear ? 25 + level.worldId * 5 : 0;
  const flawless = stars === 3 ? 15 : 0;
  return base + first + flawless;
}

/** XP payout for a finished run. */
export function xpReward(level: LevelConfig, stars: number, firstClear: boolean): number {
  return 20 + level.worldId * 6 + stars * 18 + (firstClear ? 40 : 0);
}

export function starLabel(stars: number): string {
  return stars === 3 ? 'PERFECT' : stars === 2 ? 'GREAT' : stars === 1 ? 'CLEARED' : 'FAILED';
}
