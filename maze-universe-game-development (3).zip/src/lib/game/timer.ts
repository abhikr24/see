// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Timer Utilities
// ─────────────────────────────────────────────────────────────

/** mm:ss (or m:ss.t under 10 seconds for drama). */
export function formatTime(seconds: number, precise = false): string {
  const s = Math.max(0, seconds);
  const m = Math.floor(s / 60);
  const rest = s - m * 60;
  if (precise) {
    return `${m}:${rest.toFixed(1).padStart(4, '0')}`;
  }
  return `${m}:${String(Math.ceil(rest)).padStart(2, '0')}`;
}

export function formatElapsed(seconds: number): string {
  const s = Math.max(0, seconds);
  const m = Math.floor(s / 60);
  const rest = s - m * 60;
  return `${m}:${rest.toFixed(1).padStart(4, '0')}`;
}

/** 0..1 fraction of time remaining. */
export function timePct(remaining: number, limit: number): number {
  if (limit <= 0) return 0;
  return Math.max(0, Math.min(1, remaining / limit));
}

/** Color cue for timer urgency. */
export function urgencyColor(pct: number): string {
  if (pct > 0.5) return '#34d399'; // emerald
  if (pct > 0.25) return '#fbbf24'; // amber
  return '#ef4444'; // red
}
