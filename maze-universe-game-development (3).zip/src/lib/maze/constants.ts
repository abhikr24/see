// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Game Constants
// Worlds, level configs, power-ups, skins, XP curve.
// ─────────────────────────────────────────────────────────────

import type {
  Difficulty,
  LevelConfig,
  PowerUpId,
  PowerUpInventory,
  WorldConfig,
  SkinDef,
} from './types';
import { clamp, hashSeed, levelId, mulberry32, randInt } from '@/lib/utils/helpers';
import { coinCountForSize } from './generator';

// ── Theme ────────────────────────────────────────────────────
export const THEME = {
  bg: '#0a0f1e',
  bgSoft: '#101830',
  electric: '#3b82f6',
  neon: '#8b5cf6',
  emerald: '#10b981',
  gold: '#f59e0b',
  danger: '#ef4444',
} as const;

// ── Worlds ───────────────────────────────────────────────────
export const WORLDS: WorldConfig[] = [
  {
    id: 1,
    name: 'THE BASICS',
    subtitle: 'Genesis Sector',
    description: 'Learn the ways of the maze. Clean corridors, generous timers, endless possibility.',
    icon: 'Rocket',
    color: '#3b82f6',
    gradientFrom: '#1d4ed8',
    gradientTo: '#38bdf8',
    requiredStars: 0,
    totalLevels: 20,
    variant: 'classic',
    mechanics: ['Classic mazes', 'Coins', 'Keys & doors', 'Teleporters'],
  },
  {
    id: 2,
    name: 'SHADOW REALM',
    subtitle: 'Veil of Night',
    description: 'Darkness swallows the corridors. Trust your torch and nothing else.',
    icon: 'Moon',
    color: '#8b5cf6',
    gradientFrom: '#4c1d95',
    gradientTo: '#a78bfa',
    requiredStars: 30,
    totalLevels: 25,
    variant: 'dark',
    mechanics: ['Limited vision', 'Torch radius', 'Memory of explored paths'],
  },
  {
    id: 3,
    name: 'SHIFTING SANDS',
    subtitle: 'The Living Labyrinth',
    description: 'The maze breathes. Ancient gates rise and fall with the desert wind.',
    icon: 'Hourglass',
    color: '#f59e0b',
    gradientFrom: '#b45309',
    gradientTo: '#fbbf24',
    requiredStars: 65,
    totalLevels: 25,
    variant: 'shifting',
    mechanics: ['Timed gates', 'Opening & closing walls', 'Route planning'],
  },
  {
    id: 4,
    name: 'ICE KINGDOM',
    subtitle: 'Frozen Expanse',
    description: 'One push and you slide until the ice lets go. Momentum is your master.',
    icon: 'Snowflake',
    color: '#22d3ee',
    gradientFrom: '#0e7490',
    gradientTo: '#a5f3fc',
    requiredStars: 100,
    totalLevels: 25,
    variant: 'ice',
    mechanics: ['Sliding movement', 'Ice tiles', 'Inertia puzzles'],
  },
  {
    id: 5,
    name: 'MIRROR DIMENSION',
    subtitle: 'Inverted Reality',
    description: 'Left is right. Up is down. Your instincts will betray you here.',
    icon: 'FlipHorizontal2',
    color: '#e879f9',
    gradientFrom: '#a21caf',
    gradientTo: '#f0abfc',
    requiredStars: 140,
    totalLevels: 25,
    variant: 'mirror',
    mechanics: ['Reversed controls', 'Glitch visuals', 'Mind-bending routes'],
  },
  {
    id: 6,
    name: 'THE HUNT',
    subtitle: 'Crimson Pursuit',
    description: 'Something else walks these halls — and it knows where you are.',
    icon: 'Crosshair',
    color: '#ef4444',
    gradientFrom: '#991b1b',
    gradientTo: '#f87171',
    requiredStars: 180,
    totalLevels: 25,
    variant: 'chase',
    mechanics: ['Hunter entities', 'Relentless pursuit', 'Shield power-ups'],
  },
  {
    id: 7,
    name: 'MIND PALACE',
    subtitle: 'Sanctum of Memory',
    description: 'Paths fade behind you. Map the palace inside your mind — or be lost forever.',
    icon: 'Brain',
    color: '#fb923c',
    gradientFrom: '#9a3412',
    gradientTo: '#fdba74',
    requiredStars: 220,
    totalLevels: 25,
    variant: 'memory',
    mechanics: ['Tiny torch radius', 'Fading paths', 'Waypoint recall'],
  },
  {
    id: 8,
    name: 'CHRONO LABS',
    subtitle: 'Temporal Division',
    description: 'Every second is currency. Corridors calibrated for maximum urgency.',
    icon: 'Timer',
    color: '#34d399',
    gradientFrom: '#065f46',
    gradientTo: '#6ee7b7',
    requiredStars: 260,
    totalLevels: 25,
    variant: 'classic',
    mechanics: ['Brutal timers', 'Keys & gates', 'Precision routing'],
  },
  {
    id: 9,
    name: 'GRAVITY WELL',
    subtitle: 'Event Horizon',
    description: 'Friction fails near the singularity. Drift across the void with perfect aim.',
    icon: 'Orbit',
    color: '#a78bfa',
    gradientFrom: '#5b21b6',
    gradientTo: '#c4b5fd',
    requiredStars: 300,
    totalLevels: 25,
    variant: 'ice',
    mechanics: ['Zero-friction drift', 'Gravity ice', 'Cosmic scale mazes'],
  },
  {
    id: 10,
    name: 'THE INFINITE',
    subtitle: 'Eventide of Stars',
    description: 'The maze never ends. Descend floor by floor into forever. How deep can you go?',
    icon: 'Infinity',
    color: '#f472b6',
    gradientFrom: '#7c3aed',
    gradientTo: '#f472b6',
    requiredStars: 340,
    totalLevels: 0, // endless — handled by /infinite
    variant: 'classic',
    mechanics: ['Procedural floors', 'Escalating scale', 'Rotating variants', 'High-score chase'],
  },
];

export function getWorld(worldId: number): WorldConfig {
  return WORLDS.find((w) => w.id === worldId) ?? WORLDS[0];
}

// ── XP curve ─────────────────────────────────────────────────
export function xpToNext(level: number): number {
  return 200 + level * 120;
}

// ── Power-ups ────────────────────────────────────────────────
export interface PowerUpDef {
  id: PowerUpId;
  name: string;
  short: string;
  description: string;
  icon: string;
  cost: number; // coins to buy one
  color: string;
}

export const POWERUPS: PowerUpDef[] = [
  { id: 'compass', name: 'Compass', short: 'Path', description: 'Reveals the golden path to the exit for 5 seconds.', icon: 'Compass', cost: 40, color: '#3b82f6' },
  { id: 'mapReveal', name: 'Map Reveal', short: 'Vision', description: 'Lifts the darkness and reveals the whole maze for 8 seconds.', icon: 'Eye', cost: 50, color: '#8b5cf6' },
  { id: 'wallBreaker', name: 'Wall Breaker', short: 'Break', description: 'Smashes one wall between you and the exit.', icon: 'Hammer', cost: 60, color: '#f59e0b' },
  { id: 'timeFreeze', name: 'Time Freeze', short: 'Freeze', description: 'Stops the clock and freezes hunters for 6 seconds.', icon: 'Hourglass', cost: 55, color: '#22d3ee' },
  { id: 'ghostMode', name: 'Ghost Mode', short: 'Ghost', description: 'Pass through walls for 4 seconds. Untouchable.', icon: 'Ghost', cost: 90, color: '#e879f9' },
  { id: 'speedBoost', name: 'Speed Boost', short: 'Speed', description: 'Move twice as fast for 8 seconds.', icon: 'Zap', cost: 35, color: '#10b981' },
  { id: 'shield', name: 'Hunter Shield', short: 'Shield', description: 'Survive one hit from a hunter. Auto-activates.', icon: 'Shield', cost: 70, color: '#ef4444' },
];

export const DEFAULT_POWERUPS: PowerUpInventory = {
  compass: 2,
  mapReveal: 1,
  wallBreaker: 1,
  timeFreeze: 1,
  ghostMode: 0,
  speedBoost: 1,
  shield: 1,
};

// ── Skins ────────────────────────────────────────────────────
export const SKINS: SkinDef[] = [
  { id: 'default', name: 'Nova', color: '#38bdf8', glow: '#0ea5e9', cost: 0 },
  { id: 'emerald', name: 'Verdant', color: '#34d399', glow: '#10b981', cost: 200 },
  { id: 'solar', name: 'Solar Flare', color: '#fbbf24', glow: '#f59e0b', cost: 350 },
  { id: 'void', name: 'Void Walker', color: '#c084fc', glow: '#8b5cf6', cost: 500 },
  { id: 'crimson', name: 'Crimson Comet', color: '#fb7185', glow: '#e11d48', cost: 750 },
  { id: 'prism', name: 'Prism', color: '#f0abfc', glow: '#d946ef', cost: 1200 },
];

export function getSkin(id: string): SkinDef {
  return SKINS.find((s) => s.id === id) ?? SKINS[0];
}

// ── Level config generation (deterministic per world/level) ──
const DIFFICULTY_BY_TIER: Difficulty[] = ['easy', 'medium', 'hard', 'expert'];

const LEVEL_NAMES: Record<number, string[]> = {
  1: ['First Steps', 'Wide Awake', 'Cold Open', 'The Long Hall', 'Cornered', 'Switchback', 'Double Down', 'Crossroads', 'The Weave', 'Detour', 'Serpentine', 'Four Winds', 'The Gauntlet', 'Roundabout', 'Needle Eye', 'Crossfire', 'Grand Spiral', 'The Maze of Yes', 'Over Under', 'Genesis Finale'],
  2: ['Dusk Falls', 'Candlelight', 'Blind Turn', 'Whisper Hall', 'Blackout', 'Ember Path', 'Night Shift', 'Hollow Dark', 'Umbra', 'Shadowboxing', 'Tenebris', 'Nocturne', 'Deep Shade', 'Twilight Veil', 'Dark Fiber', 'Starless', 'Midnight Oil', 'Eventide', 'Pitch', 'Obsidian', 'Gloaming', 'Eclipse', 'Nightmare Fuel', 'Lights Out', 'Umbral Crown'],
  3: ['First Tremor', 'Sirocco', 'Dune Runner', 'The Breathing Wall', 'Sandglass', 'Dervish', 'Fault Line', 'Gold Rush', 'Rising Pillars', 'Mirage', 'Quicksand', 'The Selector', 'Rhythm of Ruin', 'Carousel', 'Chokehold', 'Tectonic', 'The Metronome', 'Hour of Glass', 'Crucible', 'Sandstorm', 'The Divider', 'Avalanche', 'Final Shift', 'Collapsing Star', 'Heart of the Desert'],
  4: ['First Frost', 'Slipstream', 'Cold Snap', 'Glide Path', 'Icicle Alley', 'Momentum', 'Rink of Ruin', 'Polar Drift', 'The Slide Rule', 'Frictionless', 'Whiteout', 'Avalanche Run', 'Frozen Veins', 'Crystal Corridor', 'The Long Slide', 'Hailstorm', 'Thermidor', 'Glacier Gate', 'Absolute Zero', 'Permafrost', 'Icebreaker', 'The Cold Equations', 'Winterfall', 'Fractal Frost', 'Heart of Winter'],
  5: ['Reflection', 'Left Behind', 'Opposite Day', 'The Flip Side', 'Inverted', 'Parallax', 'Phase Shift', 'Backwards', 'Seeing Double', 'Anti-Matter', 'Retrograde', 'The Wrong Way', 'Negative Space', 'Handedness', 'Palindrome', 'Mirror Maze', 'Chiral', 'Reflectionless', 'The Glitch', 'Antipodes', 'Reversal of Fortune', 'Looking Glass', 'Bizarro', 'Upside Down', 'The Other You'],
  6: ['First Blood', 'Footsteps', 'The Stalker', 'Nowhere to Hide', 'Bloodhound', 'Corner Prey', 'Relentless', 'Predator', 'The Chase', 'Pack Tactics', 'Dead Sprint', 'No Escape', 'Red Harvest', 'Hunted', 'Surrounded', 'Adrenaline', 'Point Blank', 'Feral', 'Apex', 'Run for It', 'The Gauntlet', 'Close Quarters', 'Final Pursuit', 'Night of Hunters', "Hunter's Moon"],
  7: ['First Thought', 'Mnemonic', 'Recollection', 'Wayfinding', 'The Archive', 'Déjà Vu', 'Retention', 'Fading Echo', 'Cartographer', 'Palace of Mind', 'Total Recall', 'The Keep', 'Oubliette', 'Synapse', 'Echo Location', 'The Census', 'Lost and Found', 'Cerebral', 'The Long Memory', 'Hyperthymesia', 'Labyrinth Mind', 'Wax Tablet', 'The Anamnesis', 'Recall or Ruin', 'The Grand Palace'],
  8: ['Second Hand', 'Tick Tock', 'Deadline', 'Rush Hour', 'Split Second', 'Overtime', 'The Sprint', 'Time Trial', '.Time.Is.Money', 'Blitz', 'Zero Hour', 'The Countdown', 'Late Again', 'Nanosecond', 'Tempo', 'Chronometer', 'Minute Man', 'Against Time', 'Hair Trigger', 'The Crucible', "Time's Up", 'Last Second', 'Photo Finish', 'Speedrun', 'Eternity in an Hour'],
  9: ['Free Fall', 'Orbit Decay', 'Zero-G', 'Drift Away', 'Slingshot', 'Escape Velocity', 'Periapsis', 'Void Walk', 'Singularity Sight', 'Weightless', 'Tidal Lock', 'The Well Deepens', 'Gravity Assist', 'Terminal Drift', 'Dark Matter', 'Accretion', 'Event Approach', 'Photon Sphere', 'Spaghettified', 'Deep Field', 'Relativistic', 'The Abyss Gazes', 'Infinite Mass', 'Hawking Point', 'The Event Horizon'],
};

function levelName(world: number, n: number): string {
  const list = LEVEL_NAMES[world];
  if (list && list[n - 1]) return list[n - 1];
  return `Sector ${String(n).padStart(2, '0')}`;
}

/** Build the deterministic config for any story level. */
export function getLevelConfig(worldId: number, levelNumber: number): LevelConfig {
  const world = getWorld(worldId);
  const rng = mulberry32(hashSeed(`config:${worldId}:${levelNumber}`));
  const t = (levelNumber - 1) / Math.max(1, world.totalLevels - 1); // 0..1 progress in world

  // Grid size: 7x7 → up to ~17x19 within a world; bigger worlds cap higher.
  const baseW = 7 + Math.floor(t * (5 + Math.min(worldId, 5))) + (worldId > 4 ? 1 : 0);
  const baseH = 7 + Math.floor(t * (6 + Math.min(worldId, 6))) + (worldId > 4 ? 1 : 0);
  const mazeWidth = clamp(baseW + randInt(rng, 0, 2), 7, 19);
  const mazeHeight = clamp(baseH + randInt(rng, 1, 3), 7, 21);

  const difficulty: Difficulty =
    worldId <= 2 ? DIFFICULTY_BY_TIER[Math.min(Math.floor(t * 3), 2)]
    : DIFFICULTY_BY_TIER[clamp(Math.floor(worldId / 3) + (t > 0.66 ? 1 : 0) - 1, 0, 3)];

  const area = mazeWidth * mazeHeight;
  const urgency = worldId === 8 ? 0.74 : worldId === 6 ? 0.86 : 1; // chrono labs tighter
  // Coins now sit in dead ends and off-route detours, so budgets are generous
  // enough that a 3-star run is a skill expression rather than a coin flip.
  const timeLimit = clamp(Math.round((area * 0.62 + 20) * urgency), 40, 340);
  const targetTime3Star = Math.round(timeLimit * 0.42);
  const targetTime2Star = Math.round(timeLimit * 0.66);

  const totalCoins = coinCountForSize(mazeWidth, mazeHeight);

  const features: string[] = ['coins'];
  if (levelNumber >= 3) features.push('keys');
  if (levelNumber >= 6) features.push('teleporters');
  if (levelNumber >= 8) features.push('powerups');
  if (world.variant === 'shifting') features.push('gates');
  if (world.variant === 'ice') features.push('ice');
  if (world.variant === 'chase') features.push('enemies');
  if (world.variant === 'dark' || world.variant === 'memory') features.push('fog');
  if (worldId === 8 && levelNumber >= 5) features.push('gates');

  return {
    id: levelId(worldId, levelNumber),
    worldId,
    levelNumber,
    name: levelName(worldId, levelNumber),
    mazeWidth,
    mazeHeight,
    variant: world.variant,
    timeLimit: world.variant === 'memory' ? Math.round(timeLimit * 1.25) : timeLimit,
    targetTime2Star,
    targetTime3Star,
    totalCoins,
    features,
    seed: hashSeed(`maze:${worldId}:${levelNumber}`),
    difficulty,
  };
}

/** Daily challenge config — one deterministic maze per calendar day. */
export function getDailyConfig(dateKey: string): LevelConfig {
  const rng = mulberry32(hashSeed(`daily:${dateKey}`));
  const variants: LevelConfig['variant'][] = ['classic', 'dark', 'ice', 'shifting', 'chase', 'memory', 'mirror'];
  const variant = variants[Math.floor(rng() * variants.length)];
  const w = 11 + Math.floor(rng() * 5);
  const h = 12 + Math.floor(rng() * 6);
  const area = w * h;
  const timeLimit = clamp(Math.round(area * 0.62 + 20), 70, 280);
  const features = ['coins', 'keys', 'teleporters', 'powerups'];
  if (variant === 'shifting') features.push('gates');
  if (variant === 'ice') features.push('ice');
  if (variant === 'chase') features.push('enemies');
  if (variant === 'dark' || variant === 'memory') features.push('fog');
  return {
    id: `daily-${dateKey}`,
    worldId: 0,
    levelNumber: 1,
    name: 'Daily Challenge',
    mazeWidth: w,
    mazeHeight: h,
    variant,
    timeLimit,
    targetTime2Star: Math.round(timeLimit * 0.66),
    targetTime3Star: Math.round(timeLimit * 0.42),
    totalCoins: coinCountForSize(w, h),
    features,
    seed: hashSeed(`dailymaze:${dateKey}`),
    difficulty: 'medium',
  };
}

/** Endless mode floor config — scales forever. */
export function getInfiniteConfig(floor: number): LevelConfig {
  const rng = mulberry32(hashSeed(`infinite:${floor}`));
  const variants: LevelConfig['variant'][] = ['classic', 'classic', 'ice', 'shifting', 'dark', 'chase', 'memory', 'mirror'];
  const variant = floor <= 2 ? 'classic' : variants[Math.floor(rng() * variants.length)];
  const w = clamp(8 + Math.floor(floor * 0.8), 8, 19);
  const h = clamp(9 + Math.floor(floor * 1.0), 9, 21);
  const area = w * h;
  const timeLimit = clamp(Math.round(area * 0.62 + 18), 45, 300);
  const features = ['coins'];
  if (floor >= 2) features.push('keys');
  if (floor >= 3) features.push('teleporters');
  if (floor >= 4) features.push('powerups');
  if (variant === 'shifting') features.push('gates');
  if (variant === 'ice') features.push('ice');
  if (variant === 'chase') features.push('enemies');
  if (variant === 'dark' || variant === 'memory') features.push('fog');
  return {
    id: `infinite-${floor}`,
    worldId: 10,
    levelNumber: floor,
    name: `Floor ${floor}`,
    mazeWidth: w,
    mazeHeight: h,
    variant,
    timeLimit,
    targetTime2Star: Math.round(timeLimit * 0.66),
    targetTime3Star: Math.round(timeLimit * 0.42),
    totalCoins: coinCountForSize(w, h),
    features,
    seed: hashSeed(`infinitemaze:${floor}`),
    difficulty: floor < 4 ? 'easy' : floor < 8 ? 'medium' : floor < 14 ? 'hard' : 'expert',
  };
}

/** Daily reward coins by streak length. */
export function dailyReward(streak: number): number {
  return clamp(60 + streak * 20, 60, 400);
}

export const GATE_INTERVAL_MS = 5200; // shifting world wall rhythm
export const COMPASS_DURATION_MS = 5000;
export const MAP_REVEAL_DURATION_MS = 8000;
export const TIME_FREEZE_DURATION_MS = 6000;
export const GHOST_DURATION_MS = 4000;
export const SPEED_BOOST_DURATION_MS = 8000;
