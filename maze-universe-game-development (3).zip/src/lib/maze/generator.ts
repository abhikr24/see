// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Maze Generation Engine
//
// Every maze the player ever touches is born here. The contract is strict:
//
//   • DETERMINISTIC — same seed ⇒ byte-identical maze, forever.
//   • SOLVABLE      — every maze is BFS-validated before it is returned.
//   • FAIR          — keys are always collectable before their doors,
//                     gates never trap the player, items never overlap.
//   • PURE          — no function mutates its arguments. Placement passes
//                     clone the grid and return a new MazeGrid.
//
// Pipeline:
//   seed → carve (DFS | Prim's) → difficulty shaping → start/exit search
//        → terrain (ice) → gates → keys+doors → teleporters → power-ups
//        → enemy spawns → coins → final validation
// ─────────────────────────────────────────────────────────────

import type {
  Cell,
  Difficulty,
  Gate,
  LevelConfig,
  MazeGrid,
  MazeVariant,
  PowerUpId,
} from './types';
import { KEY_ORDER } from './types';
import { hashSeed, mulberry32, randInt, shuffle, todayKey } from '@/lib/utils/helpers';
import {
  bfsCells,
  cellDegree,
  countReachable,
  distanceFromSet,
  findDeadEnds,
  findIntersections,
  longestPath,
  reachableAvoiding,
  solveMaze,
  validateMaze,
  type MazeAnalysis,
  type Point,
} from './solver';

// ═════════════════════════════════════════════════════════════
// Types & configuration
// ═════════════════════════════════════════════════════════════

/** Carving algorithms available to the engine. */
export type MazeAlgorithm = 'dfs' | 'prims';

/** Full generator input. Only `width`/`height`/`difficulty` are essential. */
export interface MazeGenConfig {
  width: number;
  height: number;
  /** Carving algorithm. Defaults to a variant-aware choice. */
  algorithm?: MazeAlgorithm;
  /** Deterministic seed. Omit for a random (non-reproducible) maze. */
  seed?: number;
  difficulty: Difficulty;
  variant: MazeVariant;
  /** Feature switches: coins, keys, teleporters, gates, ice, enemies, powerups. */
  features: string[];
  /** Explicit coin count. Defaults to the size-based curve. */
  coinCount?: number;
  /** Key/door pairs to place. Defaults by difficulty. */
  keyCount?: number;
  /** Teleporter pairs to place. Defaults to 1. */
  teleporterPairs?: number;
  /** Hunter spawn points. Defaults by difficulty. */
  enemyCount?: number;
  /** Power-up pickups to scatter on junctions. */
  powerUpTypes?: string[];
  /** How many carve attempts may be made to satisfy the path-length goal. */
  maxAttempts?: number;
}

/** Union accepted by {@link generateMaze} — generic config or a LevelConfig. */
export type AnyMazeConfig = MazeGenConfig | LevelConfig;

const MIN_DIM = 3;
const MAX_DIM = 64;

/** Bounded, integral grid dimension. */
function safeDim(v: number): number {
  if (!Number.isFinite(v)) return MIN_DIM;
  return Math.max(MIN_DIM, Math.min(MAX_DIM, Math.floor(v)));
}

// ── Direction tables (index 0=up, 1=right, 2=down, 3=left) ──
const DX = [0, 1, 0, -1] as const;
const DY = [-1, 0, 1, 0] as const;
const SIDE = ['top', 'right', 'bottom', 'left'] as const;
const OPPOSITE_SIDE = ['bottom', 'left', 'top', 'right'] as const;

// ═════════════════════════════════════════════════════════════
// 3 · SEEDED RANDOM
// ═════════════════════════════════════════════════════════════

/**
 * Returns a deterministic pseudo-random generator (Mulberry32).
 * Identical seeds always produce identical number streams, which is what
 * makes Daily Challenges fair for every player on the planet.
 *
 * @param seed 32-bit integer seed.
 * @returns A function producing floats in [0, 1).
 */
export function getSeededRandom(seed: number): () => number {
  return mulberry32(seed >>> 0);
}

/**
 * Today's date collapsed into a stable 32-bit seed (local calendar day).
 * The only clock-reading function in this module.
 *
 * @returns Seed for today's Daily Challenge maze.
 */
export function getDailySeed(): number {
  return hashSeed(`maze-universe-daily:${todayKey()}`);
}

/**
 * Pure variant of {@link getDailySeed} for any date key or arbitrary string.
 *
 * @param dateKey e.g. `"2026-04-18"`.
 */
export function getSeedFromKey(dateKey: string): number {
  return hashSeed(`maze-universe-daily:${dateKey}`);
}

/**
 * Derives an independent sub-stream from a master seed so that each
 * placement pass can draw randomness without disturbing the others.
 */
function subSeed(seed: number, salt: string): number {
  return (seed ^ hashSeed(salt)) >>> 0;
}

/** Sub-stream RNG helper. */
function streamOf(seed: number | undefined, salt: string): () => number {
  const base = seed ?? Math.floor(Math.random() * 0x7fffffff);
  return getSeededRandom(subSeed(base, salt));
}

// ═════════════════════════════════════════════════════════════
// Grid primitives
// ═════════════════════════════════════════════════════════════

/**
 * Allocates a fully walled grid — the blank canvas both algorithms carve.
 */
function createGrid(w: number, h: number): Cell[][] {
  const cells: Cell[][] = [];
  for (let y = 0; y < h; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < w; x++) {
      row.push({
        x,
        y,
        type: 'path',
        walls: { top: true, right: true, bottom: true, left: true },
        visited: false,
        visible: false,
      });
    }
    cells.push(row);
  }
  return cells;
}

/** Deep copy of a cell (walls and metadata included). */
function cloneCell(c: Cell): Cell {
  return {
    ...c,
    walls: { ...c.walls },
    metadata: c.metadata ? { ...c.metadata } : undefined,
  };
}

/**
 * Deep copy of a whole maze. Every pure placement pass starts with this so
 * callers never observe mutation of the grid they passed in.
 */
export function cloneMaze(maze: MazeGrid): MazeGrid {
  return {
    ...maze,
    cells: maze.cells.map((row) => row.map(cloneCell)),
    start: { ...maze.start },
    exit: { ...maze.exit },
    gates: maze.gates.map((g) => ({ ...g })),
  };
}

/** Removes the wall between a cell and its neighbour in direction `d`. */
function carveEdge(cells: Cell[][], x: number, y: number, d: number): void {
  const nx = x + DX[d];
  const ny = y + DY[d];
  cells[y][x].walls[SIDE[d]] = false;
  cells[ny][nx].walls[OPPOSITE_SIDE[d]] = false;
}

/** Restores the wall between a cell and its neighbour in direction `d`. */
function blockEdge(cells: Cell[][], x: number, y: number, d: number): void {
  const nx = x + DX[d];
  const ny = y + DY[d];
  cells[y][x].walls[SIDE[d]] = true;
  cells[ny][nx].walls[OPPOSITE_SIDE[d]] = true;
}

/** True when the neighbour in direction `d` lies inside the grid. */
function inBounds(w: number, h: number, x: number, y: number, d: number): boolean {
  const nx = x + DX[d];
  const ny = y + DY[d];
  return nx >= 0 && ny >= 0 && nx < w && ny < h;
}

/** Stable "x,y" key for set membership. */
function key(p: Point): string {
  return `${p.x},${p.y}`;
}

/** Cells that are still plain, unoccupied floor (valid item hosts). */
function isFreeFloor(cell: Cell): boolean {
  return cell.type === 'path';
}

// ═════════════════════════════════════════════════════════════
// 1 · RECURSIVE BACKTRACKER (DFS)
// ═════════════════════════════════════════════════════════════

/**
 * Carves a **perfect maze** with the recursive backtracker (iterative DFS).
 *
 * Algorithm:
 *   1. Start from a random cell, mark it visited, push it on the stack.
 *   2. While the stack is not empty, look at the cell on top:
 *      • if it has unvisited neighbours, pick one at random, knock out the
 *        wall between them, mark it visited and push it;
 *      • otherwise pop (backtrack).
 *   3. Finish when the stack empties — every cell has been visited exactly
 *      once, so there is exactly one path between any two cells.
 *
 * Character: long, winding, river-like corridors with deep dead ends.
 * This is the primary algorithm and the default for most worlds.
 *
 * @param cells Grid to carve in place (private working copy).
 * @param w Grid width.
 * @param h Grid height.
 * @param rng Seeded random source.
 */
function carveRecursiveBacktracker(
  cells: Cell[][],
  w: number,
  h: number,
  rng: () => number,
): void {
  const visited: boolean[][] = Array.from({ length: h }, () => new Array<boolean>(w).fill(false));
  const startX = randInt(rng, 0, w - 1);
  const startY = randInt(rng, 0, h - 1);

  const stack: Point[] = [{ x: startX, y: startY }];
  visited[startY][startX] = true;

  while (stack.length > 0) {
    const current = stack[stack.length - 1];
    const candidates: number[] = [];
    for (let d = 0; d < 4; d++) {
      if (!inBounds(w, h, current.x, current.y, d)) continue;
      if (visited[current.y + DY[d]][current.x + DX[d]]) continue;
      candidates.push(d);
    }

    if (candidates.length === 0) {
      stack.pop(); // backtrack
      continue;
    }

    const d = candidates[Math.floor(rng() * candidates.length)];
    const nx = current.x + DX[d];
    const ny = current.y + DY[d];
    carveEdge(cells, current.x, current.y, d);
    visited[ny][nx] = true;
    stack.push({ x: nx, y: ny });
  }
}

// ═════════════════════════════════════════════════════════════
// 2 · RANDOMISED PRIM'S ALGORITHM
// ═════════════════════════════════════════════════════════════

interface WallRef {
  x: number;
  y: number;
  d: number;
}

/**
 * Carves a **perfect maze** with randomised Prim's algorithm.
 *
 * Algorithm:
 *   1. Start from a random cell; mark it as part of the maze and add all of
 *      its walls to a frontier list.
 *   2. While the list is not empty, pull out a random wall:
 *      • if exactly one of the two cells it divides is already in the maze,
 *        carve it into a passage, add the new cell to the maze and append
 *        its own walls to the list;
 *      • otherwise discard the wall.
 *   3. Finish when the frontier empties.
 *
 * Character: bushy, highly branched mazes with many short dead ends and no
 * long snaking corridors — noticeably more open and forgiving. Used for the
 * chase and ice worlds where visibility and reaction time matter.
 *
 * @param cells Grid to carve in place (private working copy).
 * @param w Grid width.
 * @param h Grid height.
 * @param rng Seeded random source.
 */
function carvePrims(cells: Cell[][], w: number, h: number, rng: () => number): void {
  const inMaze: boolean[][] = Array.from({ length: h }, () => new Array<boolean>(w).fill(false));
  const frontier: WallRef[] = [];

  const addWalls = (x: number, y: number) => {
    for (let d = 0; d < 4; d++) {
      if (!inBounds(w, h, x, y, d)) continue;
      if (inMaze[y + DY[d]][x + DX[d]]) continue;
      frontier.push({ x, y, d });
    }
  };

  const sx = randInt(rng, 0, w - 1);
  const sy = randInt(rng, 0, h - 1);
  inMaze[sy][sx] = true;
  addWalls(sx, sy);

  while (frontier.length > 0) {
    const idx = Math.floor(rng() * frontier.length);
    const wall = frontier[idx];
    // O(1) removal — order is already randomised by the pick above.
    frontier[idx] = frontier[frontier.length - 1];
    frontier.pop();

    const nx = wall.x + DX[wall.d];
    const ny = wall.y + DY[wall.d];
    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
    // Carve only when exactly one side is already part of the maze.
    if (inMaze[ny][nx] === inMaze[wall.y][wall.x]) continue;

    carveEdge(cells, wall.x, wall.y, wall.d);
    inMaze[ny][nx] = true;
    addWalls(nx, ny);
  }
}

/**
 * Picks the algorithm that best suits a world when none was requested.
 * Open, branchy Prim's mazes keep hunters and ice slides readable; winding
 * DFS mazes make exploration and fog-of-war worlds feel vast.
 */
function defaultAlgorithm(variant: MazeVariant, difficulty: Difficulty): MazeAlgorithm {
  if (variant === 'chase' || variant === 'ice') return 'prims';
  if (variant === 'memory' || variant === 'dark') return 'dfs';
  return difficulty === 'easy' ? 'prims' : 'dfs';
}

// ═════════════════════════════════════════════════════════════
// A · DIFFICULTY SHAPING
// ═════════════════════════════════════════════════════════════

/** Every interior edge of the grid, listed once. */
function interiorEdges(w: number, h: number): WallRef[] {
  const edges: WallRef[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (x + 1 < w) edges.push({ x, y, d: 1 }); // right
      if (y + 1 < h) edges.push({ x, y, d: 2 }); // down
    }
  }
  return edges;
}

/**
 * Knocks out a share of walls to braid the maze — creating loops, shortcuts
 * and multiple viable routes. Removing walls can never disconnect a maze,
 * so no validation is required.
 *
 * @param ratio Fraction of interior walls to remove (0–1).
 * @returns Number of walls actually removed.
 */
function removeWalls(
  cells: Cell[][],
  w: number,
  h: number,
  rng: () => number,
  ratio: number,
): number {
  const closed = interiorEdges(w, h).filter((e) => cells[e.y][e.x].walls[SIDE[e.d]]);
  shuffle(rng, closed);
  const target = Math.floor(closed.length * ratio);
  let removed = 0;
  for (const e of closed) {
    if (removed >= target) break;
    carveEdge(cells, e.x, e.y, e.d);
    removed++;
  }
  return removed;
}

/**
 * Adds walls back **safely**: an edge is only sealed when the maze stays
 * fully connected afterwards, verified with a BFS flood fill.
 *
 * Note: in a perfect maze every edge is a bridge, so nothing can be added
 * without splitting it. That is why the `hard` preset braids the maze first
 * and then seals edges — the net result is more dead ends than `medium`
 * while remaining 100% connected.
 *
 * @param ratio Fraction of open interior edges to attempt to seal.
 * @returns Number of walls actually added.
 */
function addWallsSafely(
  cells: Cell[][],
  w: number,
  h: number,
  rng: () => number,
  ratio: number,
): number {
  const open = interiorEdges(w, h).filter((e) => !cells[e.y][e.x].walls[SIDE[e.d]]);
  shuffle(rng, open);
  const target = Math.floor(open.length * ratio);
  const totalCells = w * h;
  let added = 0;

  for (const e of open) {
    if (added >= target) break;
    // Never isolate a cell: both endpoints must keep at least two exits.
    const a = cells[e.y][e.x];
    const b = cells[e.y + DY[e.d]][e.x + DX[e.d]];
    if (cellDegree(a) <= 1 || cellDegree(b) <= 1) continue;

    blockEdge(cells, e.x, e.y, e.d);
    if (countReachable(cells, w, h, { x: 0, y: 0 }) !== totalCells) {
      carveEdge(cells, e.x, e.y, e.d); // revert — it was a bridge
      continue;
    }
    added++;
  }
  return added;
}

/**
 * Applies the difficulty personality to a freshly carved perfect maze.
 *
 *   easy   — remove 10% of walls → shortcuts, loops, very forgiving
 *   medium — untouched perfect maze (exactly one route everywhere)
 *   hard   — braid 4%, then seal 5% of edges → extra dead ends & bait routes
 *   expert — untouched perfect maze, maximum corridor length, zero mercy
 *
 * Connectivity is guaranteed in every branch.
 */
export function applyDifficulty(
  cells: Cell[][],
  w: number,
  h: number,
  difficulty: Difficulty,
  rng: () => number,
): void {
  switch (difficulty) {
    case 'easy':
      removeWalls(cells, w, h, rng, 0.1);
      break;
    case 'medium':
      break;
    case 'hard':
      removeWalls(cells, w, h, rng, 0.04);
      addWallsSafely(cells, w, h, rng, 0.05);
      break;
    case 'expert':
      break;
  }
}

// ═════════════════════════════════════════════════════════════
// B · START & EXIT PLACEMENT
// ═════════════════════════════════════════════════════════════

/** Corner-region candidates, nearest-to-corner first. */
function cornerCandidates(w: number, h: number, corner: 'tl' | 'br', span = 3): Point[] {
  const pts: Point[] = [];
  for (let dy = 0; dy < span; dy++) {
    for (let dx = 0; dx < span; dx++) {
      const x = corner === 'tl' ? dx : w - 1 - dx;
      const y = corner === 'tl' ? dy : h - 1 - dy;
      if (x < 0 || y < 0 || x >= w || y >= h) continue;
      pts.push({ x, y });
    }
  }
  pts.sort((a, b) => {
    const da = corner === 'tl' ? a.x + a.y : w - 1 - a.x + (h - 1 - a.y);
    const db = corner === 'tl' ? b.x + b.y : w - 1 - b.x + (h - 1 - b.y);
    return da - db;
  });
  return pts;
}

/**
 * Chooses the start (top-left region) and exit (bottom-right region) pair
 * that maximises the shortest route between them.
 *
 * Start is always within 3 cells of the top-left corner and exit within
 * 3 cells of the bottom-right corner, so the player always reads the maze
 * the same way. Among those candidates the engine picks the hardest pair.
 *
 * @returns The chosen endpoints plus the resulting shortest-path length.
 */
export function placeStartAndExit(
  cells: Cell[][],
  w: number,
  h: number,
): { start: Point; exit: Point; shortestPath: number } {
  const starts = cornerCandidates(w, h, 'tl');
  const exits = cornerCandidates(w, h, 'br');

  let best = { start: starts[0], exit: exits[0], shortestPath: -1 };

  for (const s of starts) {
    const { dist } = bfsCells(cells, w, h, s.x, s.y);
    for (const e of exits) {
      if (e.x === s.x && e.y === s.y) continue;
      const d = dist[e.y][e.x];
      if (d > best.shortestPath) best = { start: s, exit: e, shortestPath: d };
    }
  }

  return best;
}

/**
 * Minimum acceptable route length: 40% of all cells for medium and above,
 * relaxed to 22% on easy so tutorial worlds stay breezy.
 */
function requiredPathLength(w: number, h: number, difficulty: Difficulty): number {
  const ratio = difficulty === 'easy' ? 0.22 : 0.4;
  return Math.floor(w * h * ratio);
}

// ═════════════════════════════════════════════════════════════
// C · COIN PLACEMENT
// ═════════════════════════════════════════════════════════════

/**
 * Coin budget for a maze, interpolated across the design targets:
 * 7×7 → 5, 11×11 → 10, 15×15 → 18, 21×21 → 30.
 *
 * @param w Maze width.
 * @param h Maze height.
 * @returns Recommended coin count.
 */
export function coinCountForSize(w: number, h: number): number {
  const size = (safeDim(w) + safeDim(h)) / 2;
  const anchors: Array<[number, number]> = [
    [7, 5],
    [11, 10],
    [15, 18],
    [21, 30],
  ];
  if (size <= anchors[0][0]) {
    return Math.max(1, Math.round((size / anchors[0][0]) * anchors[0][1]));
  }
  for (let i = 0; i < anchors.length - 1; i++) {
    const [s0, c0] = anchors[i];
    const [s1, c1] = anchors[i + 1];
    if (size <= s1) {
      const t = (size - s0) / (s1 - s0);
      return Math.round(c0 + (c1 - c0) * t);
    }
  }
  const [sLast, cLast] = anchors[anchors.length - 1];
  return Math.round(cLast + (size - sLast) * 2);
}

/**
 * Scatters coins so that collecting them all is a *decision*, not a stroll.
 *
 * Priority order:
 *   1. Dead ends — rewards thorough exploration.
 *   2. Cells on the maze's longest path that are **not** on the shortest
 *      start→exit route — forces deliberate detours.
 *   3. Remaining floor, farthest from the solution route first.
 *
 * Start and exit never receive a coin, and occupied cells are skipped.
 *
 * @param maze Source maze (not mutated).
 * @param count How many coins to place.
 * @param seed Optional seed for reproducible scattering.
 * @returns New maze with coins placed and `coinsTotal`/`coinsLeft` updated.
 */
export function placeCoins(maze: MazeGrid, count: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  const wanted = Math.max(0, Math.floor(count));
  if (wanted === 0) {
    next.coinsTotal = 0;
    next.coinsLeft = 0;
    return next;
  }

  const rng = streamOf(seed, 'coins');
  const { cells, width: w, height: h } = next;

  const reserved = new Set<string>([key(next.start), key(next.exit)]);
  const usable = (p: Point) => !reserved.has(key(p)) && isFreeFloor(cells[p.y][p.x]);

  // Tier 1 — dead ends.
  const tier1 = shuffle(rng, findDeadEnds(next).filter(usable));

  // Tier 2 — the long way round (diameter path, minus the optimal route).
  const solution = solveMaze(next) ?? [];
  const onSolution = new Set(solution.map(key));
  const tier2 = shuffle(
    rng,
    longestPath(next).path.filter((p) => usable(p) && !onSolution.has(key(p))),
  );

  // Tier 3 — everything else, farthest from the solution route first.
  const awayField = solution.length > 0 ? distanceFromSet(cells, w, h, solution) : null;
  const tier3: Point[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = { x, y };
      if (!usable(p)) continue;
      tier3.push(p);
    }
  }
  shuffle(rng, tier3);
  if (awayField) tier3.sort((a, b) => awayField[b.y][b.x] - awayField[a.y][a.x]);

  const placed = new Set<string>();
  let total = 0;
  for (const tier of [tier1, tier2, tier3]) {
    for (const p of tier) {
      if (total >= wanted) break;
      const k = key(p);
      if (placed.has(k)) continue;
      if (!isFreeFloor(cells[p.y][p.x])) continue;
      cells[p.y][p.x].type = 'coin';
      placed.add(k);
      total++;
    }
    if (total >= wanted) break;
  }

  next.coinsTotal = total;
  next.coinsLeft = total;
  return next;
}

/** @deprecated Spelling alias kept for API compatibility. Use {@link placeCoins}. */
export const placeCoinss = placeCoins;

// ═════════════════════════════════════════════════════════════
// D · KEYS, DOORS, TELEPORTERS, POWER-UPS, ENEMIES
// ═════════════════════════════════════════════════════════════

/**
 * Places key + door pairs with a hard fairness guarantee.
 *
 * Doors are dropped **on the shortest route** so they cannot be ignored,
 * then each key is placed in a cell that is provably reachable while all
 * doors (including its own) are treated as solid — verified by BFS. Dead
 * ends and off-route cells are preferred so keys feel earned, never free.
 *
 * A pair is skipped rather than placed unfairly if no safe key cell exists.
 *
 * @param maze Source maze (not mutated).
 * @param keyCount Number of key/door pairs to place.
 * @param seed Optional seed for reproducible placement.
 * @returns New maze containing the key/door pairs.
 */
export function placeKeys(maze: MazeGrid, keyCount: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  const pairs = Math.max(0, Math.floor(keyCount));
  if (pairs === 0) return next;

  const rng = streamOf(seed, 'keys');
  const { cells, width: w, height: h } = next;
  const solution = solveMaze(next);
  if (!solution || solution.length < 6) return next;

  const reserved = new Set<string>([key(next.start), key(next.exit)]);
  const deadEnds = new Set(findDeadEnds(next).map(key));
  const doorsPlaced: Point[] = [];

  for (let i = 0; i < pairs; i++) {
    // Spread doors across the back half of the route: 55%, 70%, 85% …
    const frac = 0.55 + (i * 0.3) / Math.max(1, pairs);
    const wanted = Math.min(solution.length - 2, Math.max(2, Math.round(solution.length * frac)));

    // Nearest valid door seat to the wanted index.
    let door: Point | null = null;
    for (let off = 0; off < solution.length && !door; off++) {
      for (const idx of [wanted - off, wanted + off]) {
        if (idx < 2 || idx > solution.length - 2) continue;
        const p = solution[idx];
        if (reserved.has(key(p))) continue;
        if (!isFreeFloor(cells[p.y][p.x])) continue;
        door = p;
        break;
      }
    }
    if (!door) break;

    // Which cells can still be reached with every door sealed?
    const blocked = [...doorsPlaced, door];
    const reachable = reachableAvoiding(cells, w, h, next.start, blocked);

    const candidates: Point[] = [];
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!reachable[y][x]) continue;
        const p = { x, y };
        if (reserved.has(key(p))) continue;
        if (!isFreeFloor(cells[y][x])) continue;
        candidates.push(p);
      }
    }
    if (candidates.length === 0) break;

    // Prefer dead ends, then cells off the optimal route.
    const onSolution = new Set(solution.map(key));
    shuffle(rng, candidates);
    candidates.sort((a, b) => score(b) - score(a));
    function score(p: Point): number {
      let s = 0;
      if (deadEnds.has(key(p))) s += 10;
      if (!onSolution.has(key(p))) s += 5;
      return s;
    }

    // Each pair gets its own lock colour so the HUD reads unambiguously.
    const lock = KEY_ORDER[i % KEY_ORDER.length];
    const keyCell = candidates[0];
    cells[door.y][door.x].type = 'door';
    cells[door.y][door.x].metadata = {
      ...(cells[door.y][door.x].metadata ?? {}),
      lock,
    };
    cells[keyCell.y][keyCell.x].type = 'key';
    cells[keyCell.y][keyCell.x].metadata = {
      ...(cells[keyCell.y][keyCell.x].metadata ?? {}),
      lock,
    };
    reserved.add(key(door));
    reserved.add(key(keyCell));
    doorsPlaced.push(door);
  }

  return next;
}

/**
 * Places teleporter pairs, each half in a **different quadrant** so a jump
 * always means real progress across the map.
 *
 * @param maze Source maze (not mutated).
 * @param pairCount Number of linked pairs.
 * @param seed Optional seed for reproducible placement.
 * @returns New maze containing the teleporter pairs.
 */
export function placeTeleporters(maze: MazeGrid, pairCount: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  const pairs = Math.max(0, Math.floor(pairCount));
  if (pairs === 0) return next;

  const rng = streamOf(seed, 'teleporters');
  const { cells, width: w, height: h } = next;
  const midX = w / 2;
  const midY = h / 2;

  /** Quadrant index: 0=TL, 1=TR, 2=BL, 3=BR. */
  const quadrantOf = (p: Point): number => (p.x < midX ? 0 : 1) + (p.y < midY ? 0 : 2);

  const reserved = new Set<string>([key(next.start), key(next.exit)]);
  const buckets: Point[][] = [[], [], [], []];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = { x, y };
      if (reserved.has(key(p)) || !isFreeFloor(cells[y][x])) continue;
      // Keep portals away from the spawn so players never teleport instantly.
      if (Math.abs(x - next.start.x) + Math.abs(y - next.start.y) < 3) continue;
      buckets[quadrantOf(p)].push(p);
    }
  }
  buckets.forEach((b) => shuffle(rng, b));

  // Opposite quadrants first (TL↔BR, TR↔BL), then any distinct pair.
  const quadPairs: Array<[number, number]> = [
    [0, 3],
    [1, 2],
    [0, 1],
    [2, 3],
  ];

  let placed = 0;
  for (let i = 0; i < quadPairs.length && placed < pairs; i++) {
    const [qa, qb] = quadPairs[i];
    const a = buckets[qa].pop();
    const b = buckets[qb].pop();
    if (!a || !b) continue;

    const pairId = placed + 1;
    for (const p of [a, b]) {
      cells[p.y][p.x].type = 'teleporter';
      cells[p.y][p.x].metadata = { ...(cells[p.y][p.x].metadata ?? {}), pairId };
    }
    placed++;
  }

  return next;
}

/**
 * Drops power-up pickups on **intersections** (cells with 3+ open sides) so
 * the player grabs them while actively choosing a route. Falls back to any
 * free floor when the maze has too few junctions.
 *
 * Each pickup stores its power-up id in `metadata.powerUp`.
 *
 * @param maze Source maze (not mutated).
 * @param types Power-up ids to place (one pickup each).
 * @param seed Optional seed for reproducible placement.
 * @returns New maze containing the pickups.
 */
export function placePowerUps(maze: MazeGrid, types: string[], seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  if (types.length === 0) return next;

  const rng = streamOf(seed, 'powerups');
  const { cells, width: w, height: h } = next;
  const reserved = new Set<string>([key(next.start), key(next.exit)]);

  const junctions = shuffle(
    rng,
    findIntersections(next).filter(
      (p) => !reserved.has(key(p)) && isFreeFloor(cells[p.y][p.x]),
    ),
  );

  const fallback: Point[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = { x, y };
      if (reserved.has(key(p)) || !isFreeFloor(cells[y][x])) continue;
      fallback.push(p);
    }
  }
  shuffle(rng, fallback);

  const seats = [...junctions, ...fallback];
  let i = 0;
  for (const type of types) {
    while (i < seats.length && !isFreeFloor(cells[seats[i].y][seats[i].x])) i++;
    if (i >= seats.length) break;
    const p = seats[i++];
    cells[p.y][p.x].type = 'powerup';
    cells[p.y][p.x].metadata = { ...(cells[p.y][p.x].metadata ?? {}), powerUp: type };
  }

  return next;
}

/**
 * Seeds hunter spawn points far enough from the player to be survivable,
 * biased onto the solution route so they actually contest it, and spread
 * apart from one another so they never arrive as a single blob.
 *
 * @param maze Source maze (not mutated).
 * @param count How many spawn points to create.
 * @param seed Optional seed for reproducible placement.
 * @returns New maze containing the spawns.
 */
export function placeEnemySpawns(maze: MazeGrid, count: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  const wanted = Math.max(0, Math.floor(count));
  if (wanted === 0) return next;

  const rng = streamOf(seed, 'enemies');
  const { cells, width: w, height: h } = next;
  const { dist } = bfsCells(cells, w, h, next.start.x, next.start.y);
  const safeRadius = Math.max(4, Math.floor((w + h) * 0.3));

  const solution = solveMaze(next) ?? [];
  const onSolution = new Set(solution.map(key));
  const reserved = new Set<string>([key(next.start), key(next.exit)]);

  const candidates: Point[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = { x, y };
      if (reserved.has(key(p)) || !isFreeFloor(cells[y][x])) continue;
      if (dist[y][x] < safeRadius) continue;
      candidates.push(p);
    }
  }

  // Relax the safety radius on tiny mazes rather than spawning nothing.
  if (candidates.length === 0) {
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const p = { x, y };
        if (reserved.has(key(p)) || !isFreeFloor(cells[y][x])) continue;
        if (dist[y][x] < Math.floor(safeRadius / 2)) continue;
        candidates.push(p);
      }
    }
  }
  if (candidates.length === 0) return next;

  shuffle(rng, candidates);
  candidates.sort((a, b) => {
    const sa = (onSolution.has(key(a)) ? 1000 : 0) + dist[a.y][a.x];
    const sb = (onSolution.has(key(b)) ? 1000 : 0) + dist[b.y][b.x];
    return sb - sa;
  });

  const chosen: Point[] = [];
  const minGap = Math.max(3, Math.floor((w + h) / 6));
  for (const p of candidates) {
    if (chosen.length >= wanted) break;
    const tooClose = chosen.some((c) => Math.abs(c.x - p.x) + Math.abs(c.y - p.y) < minGap);
    if (tooClose) continue;
    chosen.push(p);
  }
  // Top up ignoring the spacing rule if the maze is cramped.
  for (const p of candidates) {
    if (chosen.length >= wanted) break;
    if (chosen.some((c) => c.x === p.x && c.y === p.y)) continue;
    chosen.push(p);
  }

  for (const p of chosen) cells[p.y][p.x].type = 'enemy_spawn';
  return next;
}

/**
 * Freezes a share of the floor into sliding ice. Dead ends are never iced
 * (sliding into an inescapable pocket is not fun) and the spawn area stays
 * solid so the first move is always controlled.
 *
 * @param maze Source maze (not mutated).
 * @param ratio Fraction of floor cells to freeze (0–1).
 * @param seed Optional seed for reproducible placement.
 * @returns New maze with ice terrain.
 */
export function placeIce(maze: MazeGrid, ratio: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  if (ratio <= 0) return next;

  const rng = streamOf(seed, 'ice');
  const { cells, width: w, height: h } = next;
  const reserved = new Set<string>([key(next.start), key(next.exit)]);

  const candidates: Point[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = { x, y };
      if (reserved.has(key(p)) || !isFreeFloor(cells[y][x])) continue;
      if (cellDegree(cells[y][x]) < 2) continue; // keep dead ends solid
      if (Math.abs(x - next.start.x) + Math.abs(y - next.start.y) < 2) continue;
      candidates.push(p);
    }
  }

  shuffle(rng, candidates);
  const target = Math.floor(candidates.length * ratio);
  for (let i = 0; i < target; i++) {
    const p = candidates[i];
    cells[p.y][p.x].type = 'ice';
  }
  return next;
}

/**
 * Scatters wall torches through a fogged maze. Each torch becomes a warm
 * pool of light in the renderer's fog mask, turning navigation into a
 * series of readable landmarks instead of uniform darkness.
 *
 * Torches favour junctions (visible from several corridors) and are kept
 * spaced apart so they never merge into one bright blob.
 *
 * @param maze Source maze (not mutated).
 * @param count How many torches to place.
 * @param seed Optional seed for reproducible placement.
 * @returns New maze containing the torches.
 */
export function placeTorches(maze: MazeGrid, count: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  const wanted = Math.max(0, Math.floor(count));
  if (wanted === 0) return next;

  const rng = streamOf(seed, 'torches');
  const { cells } = next;
  const reserved = new Set<string>([key(next.start), key(next.exit)]);

  const junctions = shuffle(
    rng,
    findIntersections(next).filter((p) => !reserved.has(key(p)) && isFreeFloor(cells[p.y][p.x])),
  );
  const deadEnds = shuffle(
    rng,
    findDeadEnds(next).filter((p) => !reserved.has(key(p)) && isFreeFloor(cells[p.y][p.x])),
  );
  // Corridor-only mazes may have no junctions at all — fall back to any floor.
  const anyFloor: Point[] = [];
  for (let y = 0; y < next.height; y++) {
    for (let x = 0; x < next.width; x++) {
      const p = { x, y };
      if (reserved.has(key(p)) || !isFreeFloor(cells[y][x])) continue;
      anyFloor.push(p);
    }
  }
  shuffle(rng, anyFloor);
  const seats = [...junctions, ...deadEnds, ...anyFloor];

  const minGap = Math.max(2, Math.floor((next.width + next.height) / 7));
  const chosen: Point[] = [];
  const taken = new Set<string>();

  // Pass 1 — well-spaced landmarks.
  for (const p of seats) {
    if (chosen.length >= wanted) break;
    if (taken.has(key(p)) || !isFreeFloor(cells[p.y][p.x])) continue;
    if (chosen.some((c) => Math.abs(c.x - p.x) + Math.abs(c.y - p.y) < minGap)) continue;
    chosen.push(p);
    taken.add(key(p));
  }
  // Pass 2 — tiny mazes: relax spacing rather than ship an unlit level.
  for (const p of seats) {
    if (chosen.length >= wanted) break;
    if (taken.has(key(p)) || !isFreeFloor(cells[p.y][p.x])) continue;
    chosen.push(p);
    taken.add(key(p));
  }

  for (const p of chosen) cells[p.y][p.x].type = 'torch';
  return next;
}

/**
 * Installs rhythmic shifting gates along the solution route.
 *
 * Each gate remembers its carved walls in `metadata.gateWalls`, so opening
 * restores the maze's true topology instead of punching holes through solid
 * rock, and `metadata.gateOpen` drives both the renderer and the engine.
 * Gates alternate phase so the player can always read the rhythm.
 *
 * @param maze Source maze (not mutated).
 * @param count How many gates to install.
 * @param seed Optional seed for reproducible placement.
 * @returns New maze with gates registered in `maze.gates`.
 */
export function placeGates(maze: MazeGrid, count: number, seed?: number): MazeGrid {
  const next = cloneMaze(maze);
  const wanted = Math.max(0, Math.floor(count));
  if (wanted === 0) return next;

  const rng = streamOf(seed, 'gates');
  const { cells } = next;
  const solution = solveMaze(next);
  if (!solution || solution.length < 6) return next;

  const reserved = new Set<string>([key(next.start), key(next.exit)]);
  const window = solution.slice(
    Math.max(1, Math.floor(solution.length * 0.2)),
    Math.max(2, Math.floor(solution.length * 0.9)),
  );
  if (window.length === 0) return next;

  const step = Math.max(2, Math.floor(window.length / wanted));
  const gates: Gate[] = [];
  const jitter = randInt(rng, 0, 1);

  for (let i = jitter; i < window.length && gates.length < wanted; i += step) {
    const p = window[i];
    if (reserved.has(key(p))) continue;
    if (!isFreeFloor(cells[p.y][p.x])) continue;

    const open = gates.length % 2 === 0; // alternate starting phase
    const cell = cells[p.y][p.x];
    cell.metadata = {
      ...(cell.metadata ?? {}),
      gate: true,
      gateOpen: open,
      gateWalls: { ...cell.walls },
    };
    if (!open) cell.walls = { top: true, right: true, bottom: true, left: true };
    gates.push({ x: p.x, y: p.y, open });
    reserved.add(key(p));
  }

  next.gates = gates;
  return next;
}

// ═════════════════════════════════════════════════════════════
// Feature budgets
// ═════════════════════════════════════════════════════════════

/** Default hunter count per difficulty. */
function defaultEnemyCount(difficulty: Difficulty): number {
  return difficulty === 'expert' ? 3 : difficulty === 'hard' ? 2 : difficulty === 'medium' ? 2 : 1;
}

/** Default key/door pairs per difficulty. */
function defaultKeyCount(difficulty: Difficulty): number {
  return difficulty === 'expert' || difficulty === 'hard' ? 2 : 1;
}

/** Fog-of-war torch radius in cells (99 = fully lit). */
function fogRadiusFor(variant: MazeVariant, difficulty: Difficulty): number {
  if (variant === 'memory') return difficulty === 'expert' ? 1.9 : 2.3;
  if (variant === 'dark') {
    return difficulty === 'expert' ? 2.3 : difficulty === 'hard' ? 2.7 : 3.1;
  }
  return 99;
}

/** Ice coverage per variant. */
function iceRatioFor(variant: MazeVariant, features: string[]): number {
  if (variant === 'ice') return 0.34;
  return features.includes('ice') ? 0.18 : 0;
}

/** Power-up pickups a maze should contain, chosen to suit the variant. */
function defaultPowerUpTypes(variant: MazeVariant, difficulty: Difficulty): PowerUpId[] {
  const pool: PowerUpId[] =
    variant === 'chase'
      ? ['shield', 'speedBoost', 'timeFreeze']
      : variant === 'dark' || variant === 'memory'
        ? ['mapReveal', 'compass']
        : variant === 'ice'
          ? ['ghostMode', 'compass']
          : ['compass', 'speedBoost'];
  const n = difficulty === 'easy' ? 1 : 2;
  return pool.slice(0, n);
}

/** Normalises a LevelConfig or generic config into one internal shape. */
function normalizeConfig(config: AnyMazeConfig): Required<
  Pick<MazeGenConfig, 'width' | 'height' | 'difficulty' | 'variant' | 'features' | 'maxAttempts'>
> &
  MazeGenConfig {
  const isLevel = 'mazeWidth' in config;
  const base: MazeGenConfig = isLevel
    ? {
        width: config.mazeWidth,
        height: config.mazeHeight,
        seed: config.seed,
        difficulty: config.difficulty,
        variant: config.variant,
        features: config.features ?? [],
        coinCount: config.totalCoins,
      }
    : config;

  return {
    ...base,
    width: safeDim(base.width),
    height: safeDim(base.height),
    difficulty: base.difficulty ?? 'medium',
    variant: base.variant ?? 'classic',
    features: base.features ?? [],
    maxAttempts: Math.max(1, base.maxAttempts ?? 14),
  };
}

// ═════════════════════════════════════════════════════════════
// MAIN ENTRY POINT
// ═════════════════════════════════════════════════════════════

/**
 * Generates a complete, validated, ready-to-play maze.
 *
 * Accepts either a generic {@link MazeGenConfig} or a game {@link LevelConfig}
 * (the two are normalised internally), so level, daily and endless content
 * all flow through the same battle-tested pipeline.
 *
 * Guarantees:
 *   • the exit is always reachable from the start (BFS-proven);
 *   • keys are always collectable before the doors they open;
 *   • items, gates and terrain never overlap;
 *   • identical seeds always produce identical mazes.
 *
 * The engine carves up to `maxAttempts` candidate mazes and keeps the one
 * with the longest shortest-path, stopping early once the 40%-of-cells
 * route-length goal is met (22% on easy).
 *
 * @param config Generation parameters.
 * @returns A fully decorated, solvable MazeGrid.
 */
export function generateMaze(config: AnyMazeConfig): MazeGrid {
  const cfg = normalizeConfig(config);
  const { width: w, height: h, difficulty, variant, features } = cfg;
  const masterSeed = cfg.seed ?? Math.floor(Math.random() * 0x7fffffff);
  const algorithm = cfg.algorithm ?? defaultAlgorithm(variant, difficulty);
  const goal = requiredPathLength(w, h, difficulty);

  // ── Phase 1: carve candidates, keep the most interesting one ──
  let bestCells: Cell[][] | null = null;
  let bestStart: Point = { x: 0, y: 0 };
  let bestExit: Point = { x: w - 1, y: h - 1 };
  let bestLength = -1;

  for (let attempt = 0; attempt < cfg.maxAttempts; attempt++) {
    const rng = getSeededRandom(subSeed(masterSeed, `carve:${attempt}`));
    const cells = createGrid(w, h);

    if (algorithm === 'prims') carvePrims(cells, w, h, rng);
    else carveRecursiveBacktracker(cells, w, h, rng);

    applyDifficulty(cells, w, h, difficulty, rng);

    const { start, exit, shortestPath } = placeStartAndExit(cells, w, h);
    if (shortestPath > bestLength) {
      bestCells = cells;
      bestStart = start;
      bestExit = exit;
      bestLength = shortestPath;
    }
    if (bestLength >= goal) break; // good enough — stop burning cycles
  }

  // Defensive fallback: an unusable grid should be impossible, but never crash.
  const cells = bestCells ?? createGrid(w, h);
  if (!bestCells) {
    const rng = getSeededRandom(subSeed(masterSeed, 'fallback'));
    carveRecursiveBacktracker(cells, w, h, rng);
    const placement = placeStartAndExit(cells, w, h);
    bestStart = placement.start;
    bestExit = placement.exit;
  }

  cells[bestStart.y][bestStart.x].type = 'start';
  cells[bestExit.y][bestExit.x].type = 'exit';

  let maze: MazeGrid = {
    width: w,
    height: h,
    cells,
    start: bestStart,
    exit: bestExit,
    variant,
    gates: [],
    coinsTotal: 0,
    coinsLeft: 0,
    fogRadius: fogRadiusFor(variant, difficulty),
  };

  // ── Phase 2: terrain, then items (order prevents overlap) ──
  const iceRatio = iceRatioFor(variant, features);
  if (iceRatio > 0) maze = placeIce(maze, iceRatio, masterSeed);

  if (features.includes('gates') || variant === 'shifting') {
    const gateCount = variant === 'shifting' ? (difficulty === 'easy' ? 2 : 4) : 2;
    maze = placeGates(maze, gateCount, masterSeed);
  }

  // Torches light the way in fogged worlds.
  if (variant === 'dark' || variant === 'memory' || features.includes('torches')) {
    const torchCount = Math.max(2, Math.round((w * h) / 46));
    maze = placeTorches(maze, torchCount, masterSeed);
  }

  if (features.includes('keys')) {
    maze = placeKeys(maze, cfg.keyCount ?? defaultKeyCount(difficulty), masterSeed);
  }

  if (features.includes('teleporters')) {
    maze = placeTeleporters(maze, cfg.teleporterPairs ?? 1, masterSeed);
  }

  if (features.includes('powerups')) {
    const types = cfg.powerUpTypes ?? defaultPowerUpTypes(variant, difficulty);
    maze = placePowerUps(maze, types, masterSeed);
  }

  if (features.includes('enemies') || variant === 'chase') {
    maze = placeEnemySpawns(maze, cfg.enemyCount ?? defaultEnemyCount(difficulty), masterSeed);
  }

  // Coins last so they fill whatever good floor is left over.
  const coins = cfg.coinCount ?? coinCountForSize(w, h);
  maze = placeCoins(maze, coins, masterSeed);

  // ── Phase 3: prove it ──
  const report = validateMaze(maze);
  if (!report.solvable) {
    // Should never happen: carving + safe wall-adding keep the graph connected
    // and no placement pass ever seals a passage. Recover by stripping gates,
    // which are the only objects that can temporarily block the route.
    maze = openAllGates(maze);
  }

  return maze;
}

/**
 * Emergency valve: forces every gate open and restores its carved walls.
 * Used only if a maze somehow fails final validation.
 */
function openAllGates(maze: MazeGrid): MazeGrid {
  const next = cloneMaze(maze);
  for (const gate of next.gates) {
    const cell = next.cells[gate.y][gate.x];
    const saved = cell.metadata?.gateWalls as Cell['walls'] | undefined;
    if (saved) cell.walls = { ...saved };
    cell.metadata = { ...(cell.metadata ?? {}), gateOpen: true };
    gate.open = true;
  }
  return next;
}

/**
 * Convenience helper: today's Daily Challenge maze.
 *
 * @param overrides Optional tweaks to the default daily shape.
 */
export function generateDailyMaze(overrides: Partial<MazeGenConfig> = {}): MazeGrid {
  return generateMaze({
    width: 13,
    height: 15,
    difficulty: 'medium',
    variant: 'classic',
    features: ['coins', 'keys', 'teleporters'],
    seed: getDailySeed(),
    ...overrides,
  });
}

// Re-exported so callers can reach the analysis tools through the generator.
export { validateMaze, solveMaze };
export type { MazeAnalysis, Point };
