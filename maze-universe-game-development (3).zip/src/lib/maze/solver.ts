// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Maze Solver (Breadth-First Search)
//
// This module is the analytical brain behind the generator and the
// runtime. Everything here is PURE: no input is ever mutated.
//
// Used for:
//   1. Validating every generated maze is solvable
//   2. The Compass power-up (golden path to the exit)
//   3. Calculating optimal / par time for star ratings
//   4. Enemy (hunter) pathfinding
//   5. Placement heuristics (dead ends, intersections, diameter)
// ─────────────────────────────────────────────────────────────

import type { Cell, Direction, MazeGrid } from './types';

export interface Point {
  x: number;
  y: number;
}

/** Result of a full-grid breadth-first sweep from a single origin. */
export interface BfsResult {
  /** Step distance from the origin, or -1 when unreachable. */
  dist: number[][];
  /** Predecessor of each cell on its shortest path ({x:-1,y:-1} = none). */
  prev: Point[][];
  /** How many cells were reachable from the origin (origin included). */
  reachable: number;
}

/** Combined shortest/longest analysis of a maze. */
export interface MazeAnalysis {
  solvable: boolean;
  /** Step count of the start → exit shortest path (-1 when unsolvable). */
  shortestPath: number;
  /** Step count of the maze diameter (longest shortest-path in the graph). */
  longestPath: number;
  /** Cells reachable from the start. */
  reachableCells: number;
  /** Total cells in the grid. */
  totalCells: number;
  /** reachableCells / totalCells — 1 means no orphaned regions. */
  coverage: number;
  /** Number of degree-1 cells (dead ends). */
  deadEnds: number;
  /** Number of cells with 3+ open sides (junctions). */
  intersections: number;
}

// ── Direction tables ─────────────────────────────────────────
const DX = [0, 1, 0, -1] as const;
const DY = [-1, 0, 1, 0] as const;
const WALL_SIDE = ['top', 'right', 'bottom', 'left'] as const;
const DIRECTION_OF: readonly Direction[] = ['up', 'right', 'down', 'left'];

/**
 * Returns true when the edge between (x,y) and its neighbour in direction
 * index `d` is carved open and the neighbour is inside the grid.
 *
 * @param cells Grid of cells.
 * @param w Grid width.
 * @param h Grid height.
 * @param x Source cell x.
 * @param y Source cell y.
 * @param d Direction index (0=up, 1=right, 2=down, 3=left).
 */
function isOpen(cells: Cell[][], w: number, h: number, x: number, y: number, d: number): boolean {
  const nx = x + DX[d];
  const ny = y + DY[d];
  if (nx < 0 || ny < 0 || nx >= w || ny >= h) return false;
  return !cells[y][x].walls[WALL_SIDE[d]];
}

/**
 * Lists every traversable neighbour of a cell (walls respected).
 *
 * @returns Array of neighbouring coordinates reachable in one step.
 */
export function openNeighbors(cells: Cell[][], w: number, h: number, x: number, y: number): Point[] {
  const out: Point[] = [];
  for (let d = 0; d < 4; d++) {
    if (isOpen(cells, w, h, x, y, d)) out.push({ x: x + DX[d], y: y + DY[d] });
  }
  return out;
}

/**
 * Number of open sides of a single cell (its graph degree).
 * 1 = dead end, 2 = corridor, 3+ = intersection.
 */
export function cellDegree(cell: Cell): number {
  let d = 0;
  if (!cell.walls.top) d++;
  if (!cell.walls.right) d++;
  if (!cell.walls.bottom) d++;
  if (!cell.walls.left) d++;
  return d;
}

/**
 * Core breadth-first sweep across the whole grid from one origin.
 * Runs in O(width × height) and never mutates its inputs.
 *
 * @param cells Grid of cells.
 * @param w Grid width.
 * @param h Grid height.
 * @param sx Origin x.
 * @param sy Origin y.
 * @returns Distance field, predecessor field and reachable-cell count.
 */
export function bfsCells(cells: Cell[][], w: number, h: number, sx: number, sy: number): BfsResult {
  const dist: number[][] = Array.from({ length: h }, () => new Array<number>(w).fill(-1));
  const prev: Point[][] = Array.from({ length: h }, () =>
    Array.from({ length: w }, () => ({ x: -1, y: -1 })),
  );

  // Guard against out-of-range origins (defensive: callers may pass stale coords).
  if (sx < 0 || sy < 0 || sx >= w || sy >= h) {
    return { dist, prev, reachable: 0 };
  }

  const queue: Point[] = [{ x: sx, y: sy }];
  dist[sy][sx] = 0;
  let head = 0;
  let reachable = 1;

  while (head < queue.length) {
    const { x, y } = queue[head++];
    for (let d = 0; d < 4; d++) {
      if (!isOpen(cells, w, h, x, y, d)) continue;
      const nx = x + DX[d];
      const ny = y + DY[d];
      if (dist[ny][nx] !== -1) continue;
      dist[ny][nx] = dist[y][x] + 1;
      prev[ny][nx] = { x, y };
      reachable++;
      queue.push({ x: nx, y: ny });
    }
  }

  return { dist, prev, reachable };
}

/**
 * Convenience wrapper: BFS sweep from any point of a MazeGrid.
 */
export function bfsFrom(maze: MazeGrid, origin: Point): BfsResult {
  return bfsCells(maze.cells, maze.width, maze.height, origin.x, origin.y);
}

/**
 * Walks a predecessor field backwards to rebuild a concrete path.
 *
 * @returns Ordered `from → to` coordinate list, or null when unreachable.
 */
function reconstruct(prev: Point[][], from: Point, to: Point, limit: number): Point[] | null {
  if (from.x === to.x && from.y === to.y) return [{ x: from.x, y: from.y }];
  if (prev[to.y]?.[to.x] === undefined || prev[to.y][to.x].x === -1) return null;

  const out: Point[] = [{ x: to.x, y: to.y }];
  let cx = to.x;
  let cy = to.y;
  let guard = 0;

  while (!(cx === from.x && cy === from.y)) {
    if (guard++ > limit) return null; // corrupt field — fail safe
    const p = prev[cy][cx];
    if (p.x === -1) return null;
    cx = p.x;
    cy = p.y;
    out.push({ x: cx, y: cy });
  }

  return out.reverse();
}

/**
 * THE solver: shortest start → exit route through a maze.
 *
 * @param maze Maze to solve.
 * @returns Ordered coordinate list including both endpoints,
 *          or **null** when the exit cannot be reached.
 */
export function solveMaze(maze: MazeGrid): Point[] | null {
  const { prev } = bfsCells(maze.cells, maze.width, maze.height, maze.start.x, maze.start.y);
  return reconstruct(prev, maze.start, maze.exit, maze.width * maze.height + 4);
}

/**
 * Shortest path between any two points of a grid.
 * Kept tolerant for runtime callers (compass / hunter AI): when the target
 * is unreachable it returns `[from]` instead of throwing or returning null.
 */
export function findPath(
  cells: Cell[][],
  w: number,
  h: number,
  from: Point,
  to: Point,
): Point[] {
  const { prev } = bfsCells(cells, w, h, from.x, from.y);
  const path = reconstruct(prev, from, to, w * h + 4);
  return path ?? [{ x: from.x, y: from.y }];
}

/** Strict variant of {@link findPath} operating on a MazeGrid. Null when unreachable. */
export function findPathInMaze(maze: MazeGrid, from: Point, to: Point): Point[] | null {
  const { prev } = bfsCells(maze.cells, maze.width, maze.height, from.x, from.y);
  return reconstruct(prev, from, to, maze.width * maze.height + 4);
}

/**
 * Next cell a chaser should step onto to close in on a target.
 * Returns `from` unchanged when already adjacent-blocked or co-located.
 */
export function nextStepToward(
  cells: Cell[][],
  w: number,
  h: number,
  from: Point,
  to: Point,
): Point {
  const path = findPath(cells, w, h, from, to);
  return path.length >= 2 ? path[1] : from;
}

/**
 * Cardinal direction of travel between two adjacent cells.
 * Returns null when the cells are not orthogonally adjacent.
 */
export function directionBetween(from: Point, to: Point): Direction | null {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  for (let d = 0; d < 4; d++) {
    if (DX[d] === dx && DY[d] === dy) return DIRECTION_OF[d];
  }
  return null;
}

/**
 * Farthest reachable cell from an origin (graph eccentricity endpoint).
 *
 * @returns The farthest point and its step distance (dist -1 if nothing reachable).
 */
export function findFarthestCell(
  cells: Cell[][],
  w: number,
  h: number,
  from: Point,
): { x: number; y: number; dist: number } {
  const { dist } = bfsCells(cells, w, h, from.x, from.y);
  let best = { x: from.x, y: from.y, dist: 0 };
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (dist[y][x] > best.dist) best = { x, y, dist: dist[y][x] };
    }
  }
  return best;
}

/**
 * Longest path in the maze — the graph diameter — found with the classic
 * double-BFS technique: farthest cell from the start, then farthest cell
 * from *that* cell.
 *
 * Exact for perfect mazes (trees). For braided mazes containing loops it is
 * a very tight lower bound, which is all the placement heuristics need.
 *
 * @returns The endpoints, the full ordered path and its step length.
 */
export function longestPath(maze: MazeGrid): {
  from: Point;
  to: Point;
  path: Point[];
  length: number;
} {
  const { cells, width: w, height: h } = maze;
  const a = findFarthestCell(cells, w, h, maze.start);
  const b = findFarthestCell(cells, w, h, { x: a.x, y: a.y });
  const path = findPath(cells, w, h, { x: a.x, y: a.y }, { x: b.x, y: b.y });
  return {
    from: { x: a.x, y: a.y },
    to: { x: b.x, y: b.y },
    path,
    length: Math.max(0, path.length - 1),
  };
}

/**
 * Every dead end in the maze (cells with exactly one open side).
 * Perfect spots for coins and keys — they reward exploration.
 */
export function findDeadEnds(maze: MazeGrid): Point[] {
  const out: Point[] = [];
  for (let y = 0; y < maze.height; y++) {
    for (let x = 0; x < maze.width; x++) {
      if (cellDegree(maze.cells[y][x]) === 1) out.push({ x, y });
    }
  }
  return out;
}

/**
 * Every junction in the maze (cells with 3 or more open sides).
 * Ideal power-up pedestals — the player passes them while choosing a route.
 */
export function findIntersections(maze: MazeGrid): Point[] {
  const out: Point[] = [];
  for (let y = 0; y < maze.height; y++) {
    for (let x = 0; x < maze.width; x++) {
      if (cellDegree(maze.cells[y][x]) >= 3) out.push({ x, y });
    }
  }
  return out;
}

/**
 * Counts cells reachable from an origin — the fast connectivity probe used
 * when the generator tentatively adds a wall and must prove it did not
 * split the maze into islands.
 */
export function countReachable(cells: Cell[][], w: number, h: number, origin: Point): number {
  return bfsCells(cells, w, h, origin.x, origin.y).reachable;
}

/** True when every cell of the grid can be reached from `origin`. */
export function isFullyConnected(cells: Cell[][], w: number, h: number, origin: Point): boolean {
  return countReachable(cells, w, h, origin) === w * h;
}

/**
 * Multi-source BFS: step distance from the *nearest* of several origins.
 * Used to push coins and hunters away from the main solution route.
 *
 * @returns Distance grid (-1 = unreachable from every source).
 */
export function distanceFromSet(
  cells: Cell[][],
  w: number,
  h: number,
  sources: Point[],
): number[][] {
  const dist: number[][] = Array.from({ length: h }, () => new Array<number>(w).fill(-1));
  const queue: Point[] = [];
  for (const s of sources) {
    if (s.x < 0 || s.y < 0 || s.x >= w || s.y >= h) continue;
    if (dist[s.y][s.x] !== -1) continue;
    dist[s.y][s.x] = 0;
    queue.push(s);
  }
  let head = 0;
  while (head < queue.length) {
    const { x, y } = queue[head++];
    for (let d = 0; d < 4; d++) {
      if (!isOpen(cells, w, h, x, y, d)) continue;
      const nx = x + DX[d];
      const ny = y + DY[d];
      if (dist[ny][nx] !== -1) continue;
      dist[ny][nx] = dist[y][x] + 1;
      queue.push({ x: nx, y: ny });
    }
  }
  return dist;
}

/**
 * Cells reachable from the start while treating a set of coordinates as
 * impassable. Powers the key/door guarantee: a key must be collectable
 * *before* the door it unlocks.
 *
 * @returns Boolean grid of reachable cells.
 */
export function reachableAvoiding(
  cells: Cell[][],
  w: number,
  h: number,
  origin: Point,
  blocked: Point[],
): boolean[][] {
  const blockedSet = new Set(blocked.map((b) => `${b.x},${b.y}`));
  const seen: boolean[][] = Array.from({ length: h }, () => new Array<boolean>(w).fill(false));
  if (origin.x < 0 || origin.y < 0 || origin.x >= w || origin.y >= h) return seen;
  if (blockedSet.has(`${origin.x},${origin.y}`)) return seen;

  const queue: Point[] = [origin];
  seen[origin.y][origin.x] = true;
  let head = 0;
  while (head < queue.length) {
    const { x, y } = queue[head++];
    for (let d = 0; d < 4; d++) {
      if (!isOpen(cells, w, h, x, y, d)) continue;
      const nx = x + DX[d];
      const ny = y + DY[d];
      if (seen[ny][nx]) continue;
      if (blockedSet.has(`${nx},${ny}`)) continue;
      seen[ny][nx] = true;
      queue.push({ x: nx, y: ny });
    }
  }
  return seen;
}

/**
 * Full health report for a maze: solvability, shortest route, diameter,
 * coverage and topology counts. Every generated maze is run through this
 * before it is ever handed to the player.
 */
export function validateMaze(maze: MazeGrid): MazeAnalysis {
  const { cells, width: w, height: h } = maze;
  const totalCells = w * h;
  const { dist, reachable } = bfsCells(cells, w, h, maze.start.x, maze.start.y);
  const shortest = dist[maze.exit.y]?.[maze.exit.x] ?? -1;
  const diameter = longestPath(maze);

  let deadEnds = 0;
  let intersections = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const deg = cellDegree(cells[y][x]);
      if (deg === 1) deadEnds++;
      else if (deg >= 3) intersections++;
    }
  }

  return {
    solvable: shortest >= 0,
    shortestPath: shortest,
    longestPath: diameter.length,
    reachableCells: reachable,
    totalCells,
    coverage: totalCells > 0 ? reachable / totalCells : 0,
    deadEnds,
    intersections,
  };
}

/** Quick boolean solvability probe. */
export function isSolvable(maze: MazeGrid): boolean {
  const { dist } = bfsCells(maze.cells, maze.width, maze.height, maze.start.x, maze.start.y);
  return (dist[maze.exit.y]?.[maze.exit.x] ?? -1) !== -1;
}

/** Step count of the optimal start → exit route (-1 when unsolvable). */
export function optimalSteps(maze: MazeGrid): number {
  const { dist } = bfsCells(maze.cells, maze.width, maze.height, maze.start.x, maze.start.y);
  return dist[maze.exit.y]?.[maze.exit.x] ?? -1;
}

/**
 * Suggested "par" completion time in seconds, derived from the real maze
 * rather than guessed from its dimensions. Assumes a skilled player moves
 * ~5.5 cells/second and wastes a little time at junctions.
 */
export function estimateParSeconds(maze: MazeGrid): number {
  const steps = optimalSteps(maze);
  if (steps < 0) return 0;
  const junctionTax = validateMaze(maze).intersections * 0.05;
  return Math.max(4, steps / 5.5 + junctionTax);
}
