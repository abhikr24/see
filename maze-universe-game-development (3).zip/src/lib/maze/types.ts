// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Core Type Definitions
// ─────────────────────────────────────────────────────────────

export type CellType =
  | 'wall'
  | 'path'
  | 'start'
  | 'exit'
  | 'coin'
  | 'key'
  | 'door'
  | 'teleporter'
  | 'arrow'
  | 'ice'
  | 'sticky'
  | 'dark'
  | 'enemy_spawn'
  | 'powerup'
  | 'torch'
  | 'checkpoint';

export type Direction = 'up' | 'down' | 'left' | 'right';

export type MazeVariant =
  | 'classic'
  | 'dark'
  | 'ice'
  | 'shifting'
  | 'mirror'
  | 'chase'
  | 'memory'
  | 'paint'
  | 'snake';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'expert';

/** The four lock colours used by key/door pairs. */
export type KeyColor = 'gold' | 'crimson' | 'azure' | 'verdant';

/** Display colours for each lock type (keys, doors, particles, HUD chips). */
export const KEY_PALETTE: Record<KeyColor, { base: string; light: string; dark: string; label: string }> = {
  gold: { base: '#fbbf24', light: '#fde68a', dark: '#b45309', label: 'Gold' },
  crimson: { base: '#f43f5e', light: '#fda4af', dark: '#9f1239', label: 'Crimson' },
  azure: { base: '#38bdf8', light: '#bae6fd', dark: '#0369a1', label: 'Azure' },
  verdant: { base: '#34d399', light: '#a7f3d0', dark: '#047857', label: 'Verdant' },
};

/** Ordered lock colours — generators cycle through these. */
export const KEY_ORDER: KeyColor[] = ['gold', 'crimson', 'azure', 'verdant'];

/** Normalises an arbitrary lock string to a known key colour. */
export function asKeyColor(value: unknown): KeyColor {
  return typeof value === 'string' && value in KEY_PALETTE ? (value as KeyColor) : 'gold';
}

export interface Cell {
  x: number;
  y: number;
  type: CellType;
  walls: { top: boolean; right: boolean; bottom: boolean; left: boolean };
  color?: string;
  metadata?: Record<string, unknown>;
  visited?: boolean;
  visible?: boolean;
}

export interface Gate {
  x: number;
  y: number;
  open: boolean;
}

export interface MazeGrid {
  width: number;
  height: number;
  cells: Cell[][];
  start: { x: number; y: number };
  exit: { x: number; y: number };
  variant: MazeVariant;
  gates: Gate[];
  coinsTotal: number;
  coinsLeft: number;
  fogRadius: number; // cells, used by dark/memory variants
}

export interface Player {
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  animProgress: number; // 0..1 between (x,y) -> (targetX,targetY)
  direction: Direction;
  alive: boolean;
  coins: number;
  keys: Record<string, number>;
  powerUps: PowerUpInventory;
  trail: Array<{ x: number; y: number }>;
}

export interface Enemy {
  id: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  animProgress: number;
  spawnX: number;
  spawnY: number;
  stepInterval: number; // ms between steps
  lastStep: number; // timestamp
  frozen: boolean;
}

export interface PowerUpInventory {
  compass: number;
  mapReveal: number;
  wallBreaker: number;
  timeFreeze: number;
  ghostMode: number;
  speedBoost: number;
  shield: number;
}

export type PowerUpId = keyof PowerUpInventory;

export interface LevelConfig {
  id: string;
  worldId: number;
  levelNumber: number;
  name: string;
  mazeWidth: number;
  mazeHeight: number;
  variant: MazeVariant;
  timeLimit: number; // seconds
  targetTime2Star: number;
  targetTime3Star: number;
  totalCoins: number;
  features: string[];
  seed: number;
  difficulty: Difficulty;
}

export interface GameState {
  currentLevel: LevelConfig | null;
  player: Player;
  maze: MazeGrid;
  timer: number;
  isPlaying: boolean;
  isPaused: boolean;
  isComplete: boolean;
  isDead: boolean;
  coinsCollected: number;
  totalCoins: number;
  starsEarned: number;
  moveCount: number;
  startTime: number;
  elapsedTime: number;
}

export interface PlayerProgress {
  totalStars: number;
  totalCoins: number;
  highestWorld: number;
  highestLevel: number;
  playerLevel: number;
  playerXP: number;
  completedLevels: Record<string, { stars: number; bestTime: number; coins: number }>;
  unlockedWorlds: number[];
  unlockedSkins: string[];
  activeSkin: string;
  powerUps: PowerUpInventory;
  dailyStreak: number;
  lastLoginDate: string;
  settings: PlayerSettings;
  achievements: string[];
  infiniteBestFloor: number;
  dailyHistory: Record<string, { stars: number; time: number; coins: number }>;
  soundtracks?: never;
}

export interface PlayerSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  controlMethod: 'swipe' | 'tap' | 'both';
  hapticFeedback: boolean;
  darkMode: boolean;
  showTimer: boolean;
  showMoveCount: boolean;
}

export interface WorldConfig {
  id: number;
  name: string;
  subtitle: string;
  description: string;
  icon: string;
  color: string;
  gradientFrom: string;
  gradientTo: string;
  requiredStars: number;
  totalLevels: number;
  variant: MazeVariant;
  mechanics: string[];
}

/** Outcome of a single play session, produced by the game session. */
export interface RunStats {
  time: number;
  timeLeft: number;
  coinsCollected: number;
  totalCoins: number;
  moves: number;
  stars: number;
  victory: boolean;
  reason?: 'time' | 'enemy';
}

export interface LevelResult {
  levelId: string;
  worldId: number;
  levelNumber: number;
  stars: number;
  time: number;
  coins: number;
  totalCoins: number;
  xp: number;
  moves: number;
  victory: boolean;
  reason?: 'time' | 'enemy';
  newBest?: boolean;
}

export type SfxName =
  | 'click'
  | 'hover'
  | 'move'
  | 'bump'
  | 'coin'
  | 'key'
  | 'door'
  | 'teleport'
  | 'powerup'
  | 'freeze'
  | 'shield'
  | 'win'
  | 'lose'
  | 'star'
  | 'tick'
  | 'gate'
  | 'slide'
  | 'levelup';

export interface ToastItem {
  id: number;
  title: string;
  message?: string;
  variant?: 'info' | 'success' | 'warning' | 'error';
}

export interface LeaderboardEntry {
  name: string;
  stars: number;
  coins: number;
  level: number;
  title: string;
  isPlayer?: boolean;
}

export interface SkinDef {
  id: string;
  name: string;
  color: string;
  glow: string;
  cost: number;
}
