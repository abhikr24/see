// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Local Storage Persistence Layer
// ─────────────────────────────────────────────────────────────

export const STORAGE_KEYS = {
  save: 'maze-universe-save-v1',
  toasts: 'maze-universe-muted-toasts',
} as const;

export function loadJSON<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function saveJSON<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full / private mode — fail silently
  }
}

export function clearKey(key: string): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(key);
  } catch {
    // noop
  }
}
