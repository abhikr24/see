// ─────────────────────────────────────────────────────────────
// MAZE UNIVERSE · Global Game Store (Zustand + persist)
// ─────────────────────────────────────────────────────────────

'use client';

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type {
  LevelResult,
  PlayerProgress,
  PlayerSettings,
  PowerUpId,
} from '@/lib/maze/types';
import {
  DEFAULT_POWERUPS,
  POWERUPS,
  SKINS,
  WORLDS,
  dailyReward,
  xpToNext,
} from '@/lib/maze/constants';
import { STORAGE_KEYS } from '@/lib/storage/gameState';
import { soundManager } from '@/lib/audio/soundManager';

export function defaultProgress(): PlayerProgress {
  return {
    totalStars: 0,
    totalCoins: 150,
    highestWorld: 1,
    highestLevel: 1,
    playerLevel: 1,
    playerXP: 0,
    completedLevels: {},
    unlockedWorlds: [1],
    unlockedSkins: ['default'],
    activeSkin: 'default',
    powerUps: { ...DEFAULT_POWERUPS },
    dailyStreak: 0,
    lastLoginDate: '',
    settings: {
      soundEnabled: true,
      musicEnabled: true,
      controlMethod: 'both',
      hapticFeedback: true,
      darkMode: true,
      showTimer: true,
      showMoveCount: true,
    },
    achievements: [],
    infiniteBestFloor: 0,
    dailyHistory: {},
  };
}

export interface CompleteLevelSummary {
  starsEarned: number;
  coinsEarned: number;
  xpEarned: number;
  leveledTo: number; // 0 = no level-up, else new level
  newBest: boolean;
  newlyUnlockedWorlds: number[];
  newAchievements: string[];
}

interface GameStore {
  progress: PlayerProgress;

  completeLevel: (result: LevelResult) => CompleteLevelSummary;
  addCoins: (n: number) => void;
  spendCoins: (n: number) => boolean;
  addXP: (n: number) => number;
  unlockWorld: (id: number) => void;
  purchasePowerUp: (id: PowerUpId) => boolean;
  usePowerUp: (id: PowerUpId) => boolean;
  /** Grants a power-up found inside a maze (no coin cost). */
  grantPowerUp: (id: PowerUpId, amount?: number) => void;
  buySkin: (id: string) => boolean;
  setSkin: (id: string) => void;
  updateSettings: (partial: Partial<PlayerSettings>) => void;
  checkInToday: (dateKey: string) => { streak: number; isNewDay: boolean };
  markDailyCompleted: (
    dateKey: string,
    stats: { stars: number; time: number; coins: number },
  ) => number; // returns coins awarded
  recordInfiniteFloor: (floor: number) => boolean;
  saveProgress: () => void;
  loadProgress: () => void;
  resetProgress: () => void;
}

function starsOf(progress: PlayerProgress): number {
  return Object.values(progress.completedLevels).reduce((acc, l) => acc + l.stars, 0);
}

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      progress: defaultProgress(),

      completeLevel: (result) => {
        const p = { ...get().progress, completedLevels: { ...get().progress.completedLevels } };
        const prev = p.completedLevels[result.levelId];
        const firstClear = !prev;
        const newBest = !prev || result.time < prev.bestTime;
        const starsEarned = Math.max(prev?.stars ?? 0, result.stars);

        p.completedLevels[result.levelId] = {
          stars: starsEarned,
          bestTime: Math.min(prev?.bestTime ?? Infinity, result.time),
          coins: Math.max(prev?.coins ?? 0, result.coins),
        };

        p.totalStars = starsOf(p);
        const coinsEarned = result.coins > 0 || prev ? resultCoins(prev, result) : result.coins;
        p.totalCoins += coinsEarned;

        // world progression
        p.highestWorld = Math.max(p.highestWorld, result.worldId);
        p.highestLevel = Math.max(p.highestLevel, result.levelNumber);

        const leveledTo = applyXP(p, result.xp);

        // world unlocks by total stars
        const newlyUnlockedWorlds: number[] = [];
        for (const w of WORLDS) {
          if (p.totalStars >= w.requiredStars && !p.unlockedWorlds.includes(w.id)) {
            p.unlockedWorlds.push(w.id);
            newlyUnlockedWorlds.push(w.id);
          }
        }
        p.unlockedWorlds.sort((a, b) => a - b);

        // achievements
        const newAchievements: string[] = [];
        const grant = (id: string) => {
          if (!p.achievements.includes(id)) {
            p.achievements.push(id);
            newAchievements.push(id);
          }
        };
        if (firstClear) grant('first-clear');
        if (result.stars === 3) grant('perfect-run');
        if (p.totalStars >= 30) grant('star-30');
        if (p.totalStars >= 100) grant('star-100');
        if (p.totalStars >= 200) grant('star-200');
        if (Object.keys(p.completedLevels).length >= 25) grant('explorer-25');
        if (leveledTo > 0 && leveledTo >= 5) grant('level-5');

        set({ progress: p });
        return {
          starsEarned,
          coinsEarned,
          xpEarned: result.xp,
          leveledTo,
          newBest,
          newlyUnlockedWorlds,
          newAchievements,
        };
      },

      addCoins: (n) => set((s) => ({ progress: { ...s.progress, totalCoins: s.progress.totalCoins + n } })),

      spendCoins: (n) => {
        const p = get().progress;
        if (p.totalCoins < n) return false;
        set({ progress: { ...p, totalCoins: p.totalCoins - n } });
        return true;
      },

      addXP: (n) => {
        const p = { ...get().progress, playerXP: get().progress.playerXP };
        const leveledTo = applyXP(p, n);
        set({ progress: p });
        return leveledTo;
      },

      unlockWorld: (id) =>
        set((s) => ({
          progress: {
            ...s.progress,
            unlockedWorlds: s.progress.unlockedWorlds.includes(id)
              ? s.progress.unlockedWorlds
              : [...s.progress.unlockedWorlds, id].sort((a, b) => a - b),
          },
        })),

      purchasePowerUp: (id) => {
        const def = POWERUPS.find((p) => p.id === id);
        if (!def) return false;
        const p = get().progress;
        if (p.totalCoins < def.cost) return false;
        set({
          progress: {
            ...p,
            totalCoins: p.totalCoins - def.cost,
            powerUps: { ...p.powerUps, [id]: p.powerUps[id] + 1 },
          },
        });
        return true;
      },

      usePowerUp: (id) => {
        const p = get().progress;
        if (p.powerUps[id] <= 0) return false;
        set({
          progress: { ...p, powerUps: { ...p.powerUps, [id]: p.powerUps[id] - 1 } },
        });
        return true;
      },

      grantPowerUp: (id, amount = 1) => {
        const p = get().progress;
        set({
          progress: { ...p, powerUps: { ...p.powerUps, [id]: p.powerUps[id] + amount } },
        });
      },

      buySkin: (id) => {
        const skin = SKINS.find((s) => s.id === id);
        const p = get().progress;
        if (!skin || p.unlockedSkins.includes(id) || p.totalCoins < skin.cost) return false;
        set({
          progress: {
            ...p,
            totalCoins: p.totalCoins - skin.cost,
            unlockedSkins: [...p.unlockedSkins, id],
            activeSkin: id,
          },
        });
        return true;
      },

      setSkin: (id) =>
        set((s) => ({
          progress: s.progress.unlockedSkins.includes(id)
            ? { ...s.progress, activeSkin: id }
            : s.progress,
        })),

      updateSettings: (partial) => {
        const p = get().progress;
        const settings = { ...p.settings, ...partial };
        set({ progress: { ...p, settings } });
        soundManager.setSoundEnabled(settings.soundEnabled);
        soundManager.setMusicEnabled(settings.musicEnabled);
      },

      checkInToday: (dateKey) => {
        const p = get().progress;
        if (p.lastLoginDate === dateKey) return { streak: p.dailyStreak, isNewDay: false };
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yKey = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
        const streak = p.lastLoginDate === yKey ? p.dailyStreak + 1 : 1;
        set({ progress: { ...p, dailyStreak: streak, lastLoginDate: dateKey } });
        return { streak, isNewDay: true };
      },

      markDailyCompleted: (dateKey, stats) => {
        const p = get().progress;
        if (p.dailyHistory[dateKey]) return 0;
        const coins = dailyReward(p.dailyStreak) + stats.coins * 5;
        set({
          progress: {
            ...p,
            totalCoins: p.totalCoins + coins,
            dailyHistory: { ...p.dailyHistory, [dateKey]: stats },
          },
        });
        applyXPSet(set, get, 60);
        return coins;
      },

      recordInfiniteFloor: (floor) => {
        const p = get().progress;
        if (floor <= p.infiniteBestFloor) return false;
        set({ progress: { ...p, infiniteBestFloor: floor } });
        return true;
      },

      saveProgress: () => {
        // zustand/persist writes on every mutation; kept for API completeness.
        get().progress;
      },

      loadProgress: () => {
        // persist rehydrates automatically on client init.
      },

      resetProgress: () => {
        set({ progress: defaultProgress() });
      },
    }),
    {
      name: STORAGE_KEYS.save,
      version: 1,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ progress: state.progress }),
      merge: (persisted, current) => {
        const saved = (persisted as { progress?: Partial<PlayerProgress> } | undefined)?.progress;
        if (!saved) return current;
        const base = defaultProgress();
        return {
          ...current,
          progress: {
            ...base,
            ...saved,
            settings: { ...base.settings, ...(saved.settings ?? {}) },
            powerUps: { ...base.powerUps, ...(saved.powerUps ?? {}) },
            completedLevels: saved.completedLevels ?? {},
            dailyHistory: saved.dailyHistory ?? {},
            unlockedWorlds: saved.unlockedWorlds ?? [1],
            unlockedSkins: saved.unlockedSkins ?? ['default'],
            achievements: saved.achievements ?? [],
          },
        };
      },
    },
  ),
);

function resultCoins(
  prev: { stars: number; bestTime: number; coins: number } | undefined,
  result: LevelResult,
): number {
  // Reward based on banked result coins (already computed by caller incl. bonuses).
  if (!prev) return result.coins;
  return result.coins;
}

function applyXP(p: PlayerProgress, n: number): number {
  p.playerXP += n;
  let leveledTo = 0;
  while (p.playerXP >= xpToNext(p.playerLevel)) {
    p.playerXP -= xpToNext(p.playerLevel);
    p.playerLevel += 1;
    leveledTo = p.playerLevel;
  }
  if (leveledTo > 0) {
    p.totalCoins += 30 * leveledTo; // level-up coin shower
  }
  return leveledTo;
}

function applyXPSet(
  set: (partial: Partial<GameStore>) => void,
  get: () => GameStore,
  n: number,
): number {
  const p = { ...get().progress };
  const leveledTo = applyXP(p, n);
  set({ progress: p });
  return leveledTo;
}
