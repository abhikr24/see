"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Camera, CameraOff, Check, ImagePlus, RefreshCcw, ScanLine } from "lucide-react";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { addItem, type NewItemPayload } from "@/app/actions";
import { colorById, nearestColour, PALETTE } from "@/lib/palette";
import { CATEGORIES, OCCASIONS, SUBCATEGORIES, type Category } from "@/lib/presets";
import { cn, vibrate } from "@/lib/utils";
import { Screen } from "@/components/shell/Screen";
import { Chip, ColorDots, FieldLabel, Segmented } from "@/components/ui/Fields";
import { useToast } from "@/components/ui/Toast";
import { GarmentArt } from "@/components/wardrobe/GarmentArt";

type Step = "capture" | "analyzing" | "review";
type CamState = "starting" | "live" | "denied" | "unavailable";

const SUBS_BY_CAT: Record<Category, string[]> = {
  top: ["tshirt", "shirt", "polo", "blouse", "knit", "turtleneck", "hoodie", "tank", "cardigan"],
  bottom: ["jeans", "trousers", "chinos", "shorts", "skirt"],
  footwear: ["sneakers", "boots", "loafers", "heels", "sandals"],
  outerwear: ["jacket", "blazer", "coat"],
  accessory: ["watch", "belt", "scarf", "bag", "cap", "beanie", "sunglasses", "necklace"],
};

export default function AddPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [step, setStep] = useState<Step>("capture");
  const [camState, setCamState] = useState<CamState>("starting");
  const [photo, setPhoto] = useState<string | null>(null);
  const [detected, setDetected] = useState<string[]>([]);
  const [scanMsg, setScanMsg] = useState(0);
  const [saving, setSaving] = useState(false);

  // review fields
  const [name, setName] = useState("");
  const [category, setCategory] = useState<Category>("top");
  const [subcategory, setSubcategory] = useState("tshirt");
  const [colorId, setColorId] = useState("white");
  const [pattern, setPattern] = useState("solid");
  const [formality, setFormality] = useState(0);
  const [warmth, setWarmth] = useState(1);
  const [occasions, setOccasions] = useState<string[]>([]);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCamState("unavailable");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setCamState("live");
      } catch {
        setCamState("denied");
      }
    })();
    return () => {
      cancelled = true;
      stopStream();
    };
  }, [stopStream]);

  /** Downscale an image source to a compact data URL. */
  const toDataUrl = (source: CanvasImageSource, w: number, h: number): string | null => {
    const max = 720;
    const scale = Math.min(1, max / Math.max(w, h));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.82);
  };

  /** Average colours from two sample zones of the (already small) canvas. */
  const extractColours = (source: CanvasImageSource, w: number, h: number): string[] => {
    const canvas = document.createElement("canvas");
    const scale = Math.min(1, 240 / Math.max(w, h));
    canvas.width = Math.max(1, Math.round(w * scale));
    canvas.height = Math.max(1, Math.round(h * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) return [];
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    const zones = [
      { x: 0.2, y: 0.2, s: 0.6 },
      { x: 0.3, y: 0.45, s: 0.4 },
    ];
    const found: string[] = [];
    for (const z of zones) {
      try {
        const sx = Math.round(canvas.width * z.x);
        const sy = Math.round(canvas.height * z.y);
        const sw = Math.max(1, Math.round(canvas.width * z.s));
        const sh = Math.max(1, Math.round(canvas.height * z.s));
        const data = ctx.getImageData(sx, sy, sw, sh).data;
        let r = 0, g = 0, b = 0, n = 0;
        for (let i = 0; i < data.length; i += 16) {
          r += data[i];
          g += data[i + 1];
          b += data[i + 2];
          n++;
        }
        const hex = `#${((1 << 24) + (Math.round(r / n) << 16) + (Math.round(g / n) << 8) + Math.round(b / n)).toString(16).slice(1)}`;
        const match = nearestColour(hex);
        if (!found.includes(match.id)) found.push(match.id);
      } catch {
        /* tainted canvas etc. */
      }
    }
    return found.slice(0, 2);
  };

  const beginAnalysis = (dataUrl: string, colours: string[]) => {
    vibrate(14);
    stopStream();
    setPhoto(dataUrl);
    setDetected(colours);
    const primary = colours[0] ?? "white";
    setColorId(primary);
    setName(`${colorById(primary).name} ${SUBCATEGORIES.tshirt.label}`);
    setCategory("top");
    setSubcategory("tshirt");
    setStep("analyzing");
    setScanMsg(0);
  };

  useEffect(() => {
    if (step !== "analyzing") return;
    const msgs = 3;
    let i = 0;
    const t = setInterval(() => {
      i++;
      if (i >= msgs) {
        clearInterval(t);
        setTimeout(() => setStep("review"), 420);
      } else setScanMsg(i);
    }, 700);
    return () => clearInterval(t);
  }, [step]);

  const captureFromCamera = () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0) return;
    const url = toDataUrl(video, video.videoWidth, video.videoHeight);
    if (!url) return;
    beginAnalysis(url, extractColours(video, video.videoWidth, video.videoHeight));
  };

  const onFile = (file: File | null) => {
    if (!file) return;
    const img = new Image();
    img.onload = () => {
      const url = toDataUrl(img, img.naturalWidth, img.naturalHeight);
      if (!url) return;
      beginAnalysis(url, extractColours(img, img.naturalWidth, img.naturalHeight));
      URL.revokeObjectURL(img.src);
    };
    img.src = URL.createObjectURL(file);
  };

  const pickCategory = (c: Category) => {
    setCategory(c);
    const first = SUBS_BY_CAT[c][0];
    setSubcategory(first);
    setName(`${colorById(colorId).name} ${SUBCATEGORIES[first].label}`);
  };

  const pickColor = (id: string) => {
    setColorId(id);
    setName((n) => {
      const sub = SUBCATEGORIES[subcategory]?.label ?? "";
      const withoutColour = n.replace(/^.*? (?=[A-Z])/, "");
      return `${colorById(id).name} ${withoutColour || sub}`;
    });
  };

  const save = async () => {
    setSaving(true);
    vibrate([10, 40, 10]);
    const payload: NewItemPayload = {
      name,
      category,
      subcategory,
      colors: [colorId, ...detected.filter((d) => d !== colorId)].slice(0, 2),
      pattern,
      formality,
      warmth,
      occasions,
      imageUrl: photo,
      source: photo ? (camState === "denied" || camState === "unavailable" ? "upload" : "camera") : "manual",
    };
    if (!photo) payload.source = "manual";
    await addItem(payload);
    setSaving(false);
    toast("Added to your closet");
    router.push("/wardrobe");
    router.refresh();
  };

  return (
    <Screen eyebrow="New piece" title="Add to closet">
      <div className="px-5 pt-1">
        <AnimatePresence mode="wait">
          {step === "capture" && (
            <motion.div key="capture" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.3 }}>
              {/* viewfinder */}
              <div className="relative aspect-[4/4.6] w-full overflow-hidden rounded-[28px] bg-ink shadow-lift">
                {camState === "live" ? (
                  <>
                    <video ref={videoRef} playsInline muted className="absolute inset-0 h-full w-full object-cover" />
                    <div className="pointer-events-none absolute inset-6 rounded-[20px] border border-cream/50">
                      <div className="absolute -left-px -top-px h-6 w-6 rounded-tl-[20px] border-l-[3px] border-t-[3px] border-cream" />
                      <div className="absolute -right-px -top-px h-6 w-6 rounded-tr-[20px] border-r-[3px] border-t-[3px] border-cream" />
                      <div className="absolute -bottom-px -left-px h-6 w-6 rounded-bl-[20px] border-b-[3px] border-l-[3px] border-cream" />
                      <div className="absolute -bottom-px -right-px h-6 w-6 rounded-br-[20px] border-b-[3px] border-r-[3px] border-cream" />
                    </div>
                    <div className="absolute inset-x-0 top-6 text-center">
                      <span className="rounded-full bg-ink/55 px-3.5 py-1.5 text-[11px] font-semibold tracking-wide text-cream backdrop-blur">
                        Lay the garment flat · good light helps
                      </span>
                    </div>
                  </>
                ) : camState === "starting" ? (
                  <div className="flex h-full flex-col items-center justify-center gap-3 bg-ink">
                    <div className="skeleton h-16 w-16 rounded-full !bg-cream/10" />
                    <span className="text-[12px] font-semibold tracking-wide text-cream/60">Waking the camera…</span>
                  </div>
                ) : (
                  <div className="flex h-full flex-col items-center justify-center gap-4 bg-[linear-gradient(165deg,#26211a,#191510)] px-8 text-center">
                    <span className="flex h-16 w-16 items-center justify-center rounded-full bg-cream/10">
                      <CameraOff className="h-7 w-7 text-cream/80" strokeWidth={1.6} />
                    </span>
                    <div>
                      <p className="font-display text-[21px] text-cream">Camera isn't available</p>
                      <p className="mt-1.5 text-[12.5px] leading-relaxed text-cream/60">
                        {camState === "denied"
                          ? "Permission was declined — you can allow it in browser settings, or just upload a photo instead."
                          : "This browser can't open the camera — a photo from your library works perfectly."}
                      </p>
                    </div>
                    <button
                      onClick={() => fileRef.current?.click()}
                      className="rounded-full bg-cream px-6 py-3 text-[13.5px] font-bold text-ink active:scale-95"
                    >
                      Upload a photo
                    </button>
                  </div>
                )}
              </div>

              {/* shutter row */}
              <div className="mt-5 flex items-center justify-between px-2">
                <button
                  onClick={() => fileRef.current?.click()}
                  className="flex h-12 w-12 items-center justify-center rounded-full bg-cream ring-1 ring-ink/10 active:scale-90"
                  aria-label="Upload from library"
                >
                  <ImagePlus className="h-5 w-5 text-ink" strokeWidth={1.9} />
                </button>
                <button
                  onClick={captureFromCamera}
                  disabled={camState !== "live"}
                  aria-label="Capture"
                  className={cn(
                    "flex h-[76px] w-[76px] items-center justify-center rounded-full ring-4 ring-ink/15 transition-all active:scale-90",
                    camState === "live" ? "bg-ink shadow-lift" : "bg-ink/25",
                  )}
                >
                  <Camera className="h-7 w-7 text-cream" strokeWidth={1.8} />
                </button>
                <button
                  onClick={() => {
                    stopStream();
                    setPhoto(null);
                    setDetected([]);
                    setColorId("white");
                    setName("New piece");
                    setStep("review");
                  }}
                  className="flex h-12 w-12 items-center justify-center rounded-full bg-cream ring-1 ring-ink/10 active:scale-90"
                  aria-label="Add manually"
                >
                  <span className="text-[11px] font-bold text-ink">SKIP</span>
                </button>
              </div>
              <p className="mt-3 text-center text-[11.5px] font-medium text-muted">
                Capture, upload, or skip the photo entirely
              </p>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => onFile(e.target.files?.[0] ?? null)}
              />
            </motion.div>
          )}

          {step === "analyzing" && (
            <motion.div key="analyzing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-2">
              <div className="relative mx-auto aspect-[4/4.6] w-full overflow-hidden rounded-[28px] bg-ink shadow-lift">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                {photo && <img src={photo} alt="Captured garment" className="absolute inset-0 h-full w-full object-cover opacity-90" />}
                <motion.div
                  className="absolute inset-x-0 h-[3px] bg-cream/90 shadow-[0_0_24px_rgba(251,248,241,0.9)]"
                  animate={{ top: ["6%", "92%", "6%"] }}
                  transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                />
                <div className="absolute inset-x-0 bottom-0 bg-ink/65 px-5 py-4 backdrop-blur-sm">
                  <div className="flex items-center gap-2.5">
                    <ScanLine className="h-4 w-4 text-cream" strokeWidth={2} />
                    <span className="text-[12px] font-bold tracking-[0.14em] text-cream">
                      {["READING THE FABRIC…", "DETECTING COLOUR…", "MATCHING OCCASIONS…"][scanMsg]}
                    </span>
                  </div>
                  <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-cream/20">
                    <motion.div className="h-full bg-cream" animate={{ width: ["8%", "45%", "82%"] }} transition={{ duration: 2.1, ease: "easeInOut" }} />
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === "review" && (
            <motion.div key="review" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
              <div className="flex items-start gap-4">
                {photo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={photo} alt="Garment" className="h-28 w-28 shrink-0 rounded-[20px] object-cover ring-1 ring-ink/10" />
                ) : (
                  <div className="flex h-28 w-28 shrink-0 items-center justify-center rounded-[20px] bg-bronze-soft/40 ring-1 ring-ink/[0.06]">
                    <GarmentArt art={SUBCATEGORIES[subcategory]?.art ?? "folded"} hex={colorById(colorId).hex} className="h-full w-full p-3" />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <div className="micro-label mb-1.5 text-olive">Analysis complete</div>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border-b border-ink/15 bg-transparent pb-1 font-display text-[22px] tracking-tight text-ink outline-none focus:border-ink"
                    placeholder="Name this piece"
                  />
                  {detected.length > 0 && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[11px] font-medium text-muted">Picked up:</span>
                      {detected.map((d) => (
                        <span key={d} className="flex items-center gap-1 rounded-full bg-cream py-0.5 pl-1 pr-2 ring-1 ring-ink/[0.08]">
                          <span className="h-3 w-3 rounded-full ring-1 ring-ink/10" style={{ backgroundColor: colorById(d).hex }} />
                          <span className="text-[10px] font-semibold text-ink-2">{colorById(d).name}</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => {
                    setStep("capture");
                    setPhoto(null);
                  }}
                  aria-label="Retake"
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-cream ring-1 ring-ink/10 active:scale-90"
                >
                  <RefreshCcw className="h-4 w-4 text-ink" strokeWidth={2} />
                </button>
              </div>
              <p className="mt-2 text-[11.5px] font-medium text-muted">Anything off? Tap to correct it — the stylist learns.</p>

              <div className="mt-6 space-y-6">
                <div>
                  <FieldLabel>Category</FieldLabel>
                  <div className="flex flex-wrap gap-1.5">
                    {CATEGORIES.map((c) => (
                      <Chip key={c.id} small selected={category === c.id} onClick={() => pickCategory(c.id)}>
                        {c.plural}
                      </Chip>
                    ))}
                  </div>
                </div>
                <div>
                  <FieldLabel>Type</FieldLabel>
                  <div className="flex flex-wrap gap-1.5">
                    {SUBS_BY_CAT[category].map((s) => (
                      <Chip key={s} small selected={subcategory === s} onClick={() => {
                        setSubcategory(s);
                        setName(`${colorById(colorId).name} ${SUBCATEGORIES[s].label}`);
                      }}>
                        {SUBCATEGORIES[s].label}
                      </Chip>
                    ))}
                  </div>
                </div>
                <div>
                  <FieldLabel>Main colour</FieldLabel>
                  <ColorDots selected={[colorId]} onToggle={pickColor} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <FieldLabel>Pattern</FieldLabel>
                    <Segmented
                      options={[
                        { value: "solid", label: "Solid" },
                        { value: "striped", label: "Striped" },
                        { value: "print", label: "Print" },
                      ]}
                      value={pattern}
                      onChange={(v) => setPattern(v)}
                    />
                  </div>
                  <div>
                    <FieldLabel>Weight</FieldLabel>
                    <Segmented
                      options={[
                        { value: 0, label: "Light" },
                        { value: 1, label: "Mid" },
                        { value: 2, label: "Cozy" },
                      ]}
                      value={warmth}
                      onChange={setWarmth}
                    />
                  </div>
                </div>
                <div>
                  <FieldLabel>Formality</FieldLabel>
                  <Segmented
                    options={[
                      { value: 0, label: "Casual" },
                      { value: 1, label: "Smart" },
                      { value: 2, label: "Formal" },
                    ]}
                    value={formality}
                    onChange={setFormality}
                  />
                </div>
                <div>
                  <FieldLabel>Wears well to</FieldLabel>
                  <div className="flex flex-wrap gap-1.5">
                    {OCCASIONS.map((o) => (
                      <Chip
                        key={o.id}
                        small
                        selected={occasions.includes(o.id)}
                        onClick={() =>
                          setOccasions((cur) => (cur.includes(o.id) ? cur.filter((x) => x !== o.id) : [...cur, o.id]))
                        }
                      >
                        {o.label}
                      </Chip>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={save}
                disabled={saving || !name.trim()}
                className="mt-8 flex w-full items-center justify-center gap-2 rounded-full bg-ink py-[17px] text-[15px] font-bold text-cream shadow-lift transition-all active:scale-[0.97] disabled:opacity-40"
              >
                <Check className="h-4.5 w-4.5" strokeWidth={2.4} />
                {saving ? "Hanging it up…" : "Add to my closet"}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Screen>
  );
}
