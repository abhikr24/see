"use client";

import { RefreshCcw, Unlink } from "lucide-react";

/** Native-feeling error state — no spinner, a calm way back. */
export default function AppError({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-8 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-ink/[0.05]">
        <Unlink className="h-8 w-8 text-ink/40" strokeWidth={1.5} />
      </div>
      <h2 className="mt-6 font-display text-[26px] tracking-tight text-ink">A loose thread</h2>
      <p className="mt-2 max-w-[260px] text-[13px] leading-relaxed text-muted">
        Something snagged while dressing this screen. It happens — try once more.
      </p>
      <button
        onClick={reset}
        className="mt-8 flex items-center gap-2 rounded-full bg-ink px-8 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
      >
        <RefreshCcw className="h-4 w-4" strokeWidth={2.2} />
        Try again
      </button>
    </div>
  );
}
