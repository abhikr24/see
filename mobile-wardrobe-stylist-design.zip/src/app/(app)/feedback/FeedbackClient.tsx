"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, Send } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { submitFeedback } from "@/app/actions";
import { cn, vibrate } from "@/lib/utils";
import { Screen } from "@/components/shell/Screen";

const RATINGS = ["Way off", "Not quite", "Decent", "Close", "Spot on"];

export default function FeedbackClient() {
  const router = useRouter();
  const [rating, setRating] = useState(0);
  const [note, setNote] = useState("");
  const [sent, setSent] = useState(false);
  const [pending, start] = useTransition();

  const submit = () =>
    start(async () => {
      await submitFeedback(rating, note, "app");
      vibrate([10, 40, 10]);
      setSent(true);
    });

  return (
    <Screen back eyebrow="Feedback" title="Tell your stylist" padForTab={false}>
      <div className="px-5 pt-2">
        <AnimatePresence mode="wait">
          {sent ? (
            <motion.div
              key="done"
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center pb-16 pt-20 text-center"
            >
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 18, delay: 0.1 }}
                className="flex h-20 w-20 items-center justify-center rounded-full bg-olive/15"
              >
                <Check className="h-9 w-9 text-olive" strokeWidth={2.4} />
              </motion.div>
              <h2 className="mt-6 font-display text-[26px] tracking-tight text-ink">Noted. Tomorrow gets sharper.</h2>
              <p className="mt-2 max-w-[260px] text-[13px] leading-relaxed text-muted">
                Every note tunes the recommendations you wake up to.
              </p>
              <button
                onClick={() => router.push("/today")}
                className="mt-8 rounded-full bg-ink px-8 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
              >
                Back to today
              </button>
            </motion.div>
          ) : (
            <motion.div key="form" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
              <p className="text-[13.5px] leading-relaxed text-muted">
                How are the recommendations landing? This goes straight into how tomorrow's look is chosen.
              </p>

              <div className="mt-6">
                <div className="micro-label mb-3 text-muted">Overall hit rate</div>
                <div className="flex items-center gap-2.5">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      onClick={() => {
                        vibrate(8);
                        setRating(n);
                      }}
                      className={cn(
                        "flex h-12 w-12 items-center justify-center rounded-full font-display text-[17px] transition-all active:scale-90",
                        rating === n
                          ? "bg-ink text-cream shadow-soft"
                          : rating >= n
                            ? "bg-bronze-soft text-bronze-deep ring-1 ring-bronze/30"
                            : "bg-cream text-muted ring-1 ring-ink/10",
                      )}
                    >
                      {n}
                    </button>
                  ))}
                </div>
                <div className="mt-2.5 h-5 text-[12.5px] font-semibold text-bronze">
                  {rating > 0 && <motion.span initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>{RATINGS[rating - 1]}</motion.span>}
                </div>
              </div>

              <div className="mt-4">
                <div className="micro-label mb-2.5 text-muted">Say more, if you like</div>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={5}
                  placeholder="“More colour on Fridays”, “stop showing me the white sneakers”, “the interview look was perfect”…"
                  className="w-full resize-none rounded-[22px] bg-cream p-4.5 text-[14px] font-medium leading-relaxed text-ink outline-none ring-1 ring-ink/10 placeholder:text-muted/60 focus:ring-ink/25"
                />
              </div>

              <button
                onClick={submit}
                disabled={rating === 0 || pending}
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-ink py-[17px] text-[15px] font-bold text-cream shadow-lift transition-all active:scale-[0.97] disabled:opacity-35"
              >
                <Send className="h-4 w-4" strokeWidth={2.2} />
                {pending ? "Sending…" : "Send it over"}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Screen>
  );
}
