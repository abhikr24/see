import { redirect } from "next/navigation";
import { getProfile } from "@/db/queries";
import FeedbackClient from "./FeedbackClient";

export const dynamic = "force-dynamic";

export default async function FeedbackPage() {
  const profile = await getProfile();
  if (!profile.onboarded) redirect("/onboarding");
  return <FeedbackClient />;
}
