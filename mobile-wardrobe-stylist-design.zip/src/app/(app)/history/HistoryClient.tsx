"use client";

import { motion } from "framer-motion";
import { Clock3, Sparkle } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import type { OutfitBundle } from "@/db/queries";
import { occasionLabel } from "@/lib/presets";
import { cn, formatDay } from "@/lib/utils";
import { Screen } from "@/components/shell/Screen";
import { EmptyState } from "@/components/ui/EmptyState";
import { OutfitFlatLay } from "@/components/wardrobe/OutfitFlatLay";

type Filter = "all" | "worn" | "saved" | "passed";

export default function HistoryClient({ history }: { history: OutfitBundle[] }) {
  const [filter, setFilter] = useState<Filter>("all");

  const visible = useMemo(
    () =>
      history.filter((b) => {
        if (filter === "worn") return Boolean(b.outfit.wornAt);
        if (filter === "saved") return Boolean(b.outfit.savedAt);
        if (filter === "passed") return Boolean(b.outfit.dismissedAt) && !b.outfit.wornAt;
        return true;
      }),
    [history, filter],
  );

  return (
    <Screen eyebrow="The record" title="Style history">
      <div className="sticky top-0 z-20 bg-paper/90 pb-3 pt-1 backdrop-blur-lg">
        <div className="flex gap-2 px-5">
          {(
            [
              { id: "all", label: "All looks" },
              { id: "worn", label: "Worn" },
              { id: "saved", label: "Saved" },
              { id: "passed", label: "Passed" },
            ] as { id: Filter; label: string }[]
          ).map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={cn(
                "rounded-full px-3.5 py-2 text-[12px] font-semibold transition-all active:scale-95",
                filter === f.id ? "bg-ink text-cream" : "bg-cream text-ink-2 ring-1 ring-ink/[0.08]",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <EmptyState
          icon={Clock3}
          title={filter === "all" ? "No looks yet — day one starts now" : `Nothing ${filter} yet`}
          body={
            filter === "all"
              ? "Every morning your stylist logs the look of the day here, along with what you actually wore."
              : "Looks you mark will collect here."
          }
        >
          {filter === "all" && (
            <Link
              href="/today"
              className="flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
            >
              <Sparkle className="h-4 w-4" strokeWidth={2} />
              Get today's look
            </Link>
          )}
        </EmptyState>
      ) : (
        <div className="space-y-3.5 px-5">
          {visible.map((b, i) => (
            <Row key={b.outfit.id} bundle={b} index={i} />
          ))}
        </div>
      )}
    </Screen>
  );
}

function Row({ bundle: b, index }: { bundle: OutfitBundle; index: number }) {
  const o = b.outfit;
  const status = o.wornAt
    ? { label: "Worn", cls: "bg-olive/15 text-olive" }
    : o.savedAt
      ? { label: "Saved", cls: "bg-bronze/12 text-bronze" }
      : o.dismissedAt
        ? { label: "Passed", cls: "bg-ink/[0.07] text-muted" }
        : { label: "Suggested", cls: "bg-ink/[0.05] text-ink-2" };
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index, 8) * 0.04, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      <Link
        href={`/outfit/${o.id}`}
        className="flex gap-4 overflow-hidden rounded-[24px] bg-cream p-3 ring-1 ring-ink/[0.06] shadow-soft transition-transform active:scale-[0.98]"
      >
        <OutfitFlatLay items={b.items} variant="mini" className="w-[104px] shrink-0 !rounded-[18px]" />
        <div className="min-w-0 flex-1 py-1">
          <div className="flex items-center gap-2">
            <span className="font-display text-[16px] tracking-tight text-ink">{formatDay(o.date)}</span>
            <span className={cn("rounded-full px-2.5 py-0.5 text-[9.5px] font-bold tracking-wide", status.cls)}>
              {status.label.toUpperCase()}
            </span>
          </div>
          <div className="mt-1 text-[12px] font-semibold text-ink-2">
            {occasionLabel(o.occasion)}
            {o.tempC != null && <span className="text-muted"> · {o.tempC}°</span>}
          </div>
          <div className="mt-1.5 line-clamp-2 text-[11.5px] leading-snug text-muted">
            {b.items
              .filter((i) => i.category !== "accessory")
              .map((i) => i.name)
              .join(" · ")}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
