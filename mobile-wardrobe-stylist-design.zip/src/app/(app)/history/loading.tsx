import { Screen } from "@/components/shell/Screen";
import { RowsSkeleton } from "@/components/ui/Skeletons";

export default function Loading() {
  return (
    <Screen eyebrow="…" title="Style history">
      <RowsSkeleton />
    </Screen>
  );
}
