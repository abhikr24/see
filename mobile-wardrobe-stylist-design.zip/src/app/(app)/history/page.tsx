import { redirect } from "next/navigation";
import { getHistory, getProfile } from "@/db/queries";
import HistoryClient from "./HistoryClient";

export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  const profile = await getProfile();
  if (!profile.onboarded) redirect("/onboarding");
  const history = await getHistory();
  return <HistoryClient history={history} />;
}
