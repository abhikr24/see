import type { ReactNode } from "react";
import { BottomTabBar } from "@/components/shell/BottomTabBar";

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-0 flex-1">
      <div className="absolute inset-0">{children}</div>
      <BottomTabBar />
    </div>
  );
}
