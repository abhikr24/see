"use client";

import { motion } from "framer-motion";
import { ArrowLeftRight } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { swapOutfitItem } from "@/app/actions";
import type { ClothingItem, Outfit, Profile } from "@/db/schema";
import { colorById } from "@/lib/palette";
import { CATEGORIES, SUBCATEGORIES, occasionLabel } from "@/lib/presets";
import { formatDay } from "@/lib/utils";
import { OutfitDock } from "@/components/outfit/OutfitDock";
import { WhyItWorks } from "@/components/outfit/WhyItWorks";
import { Screen } from "@/components/shell/Screen";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";
import { GarmentThumb } from "@/components/wardrobe/GarmentThumb";
import { OutfitFlatLay } from "@/components/wardrobe/OutfitFlatLay";

type Bundle = { outfit: Outfit; items: ClothingItem[]; profile: Profile };

export default function OutfitClient({
  bundle,
  allItems,
  canRemix,
}: {
  bundle: Bundle;
  allItems: ClothingItem[];
  canRemix: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [swapSlot, setSwapSlot] = useState<ClothingItem | null>(null);
  const [, start] = useTransition();
  const o = bundle.outfit;

  const alternatives = swapSlot
    ? allItems.filter((i) => i.category === swapSlot.category && i.id !== swapSlot.id)
    : [];

  return (
    <Screen
      back
      eyebrow={`${formatDay(o.date)} · ${o.tempC != null ? `${o.tempC}° ${o.weatherLabel?.toLowerCase() ?? ""}` : o.weatherLabel ?? ""}`}
      title={`The ${occasionLabel(o.occasion).toLowerCase()} look`}
      padForTab={false}
    >
      <div className="px-5 pb-10 pt-1">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="overflow-hidden rounded-[32px] shadow-lift"
        >
          <OutfitFlatLay items={bundle.items} />
        </motion.div>

        <div className="mt-3.5 flex items-center gap-2 px-1">
          {o.wornAt && (
            <span className="rounded-full bg-olive/15 px-3 py-1 text-[10.5px] font-bold tracking-wide text-olive">WORN</span>
          )}
          {o.savedAt && (
            <span className="rounded-full bg-bronze/12 px-3 py-1 text-[10.5px] font-bold tracking-wide text-bronze">SAVED</span>
          )}
          {o.dismissedAt && (
            <span className="rounded-full bg-ink/[0.07] px-3 py-1 text-[10.5px] font-bold tracking-wide text-muted">PASSED</span>
          )}
          {!o.isMain && (
            <span className="rounded-full bg-ink/[0.07] px-3 py-1 text-[10.5px] font-bold tracking-wide text-muted">ALTERNATIVE TAKE</span>
          )}
        </div>

        <div className="mt-6">
          <WhyItWorks reasons={o.reasons} />
        </div>

        {/* the pieces */}
        <section className="mt-8">
          <div className="micro-label mb-3 text-muted">The pieces — tap to swap</div>
          <div className="overflow-hidden rounded-[24px] bg-cream ring-1 ring-ink/[0.06]">
            {bundle.items.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setSwapSlot(item)}
                className="flex w-full items-center gap-3.5 px-4 py-3 text-left transition-colors active:bg-ink/[0.03]"
                style={idx > 0 ? { boxShadow: "0 -1px 0 rgba(25,21,16,0.06)" } : undefined}
              >
                <GarmentThumb item={item} className="h-14 w-14 shrink-0 rounded-2xl bg-bronze-soft/25 ring-1 ring-ink/[0.04]" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13.5px] font-semibold text-ink">{item.name}</div>
                  <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-muted">
                    <span
                      className="inline-block h-2 w-2 rounded-full ring-1 ring-ink/10"
                      style={{ backgroundColor: colorById(item.colors[0]).hex }}
                    />
                    {CATEGORIES.find((c) => c.id === item.category)?.label}
                    <span className="text-muted/60">·</span>
                    {SUBCATEGORIES[item.subcategory]?.label ?? item.subcategory}
                  </div>
                </div>
                <span className="flex items-center gap-1 rounded-full bg-paper px-3 py-1.5 text-[11px] font-bold text-ink-2 ring-1 ring-ink/[0.07]">
                  <ArrowLeftRight className="h-3 w-3" strokeWidth={2.2} />
                  Swap
                </span>
              </button>
            ))}
          </div>
        </section>

        <div className="mt-8">
          <OutfitDock
            outfitId={o.id}
            occasion={o.occasion}
            reaction={o.reaction}
            saved={Boolean(o.savedAt)}
            worn={Boolean(o.wornAt)}
            canRemix={canRemix}
          />
        </div>
      </div>

      {/* per-slot swap sheet */}
      <Sheet
        open={Boolean(swapSlot)}
        onClose={() => setSwapSlot(null)}
        title={swapSlot ? `Swap the ${(CATEGORIES.find((c) => c.id === swapSlot.category)?.label ?? "").toLowerCase()}` : ""}
        subtitle="Everything else in your closet playing that role."
      >
        {alternatives.length === 0 ? (
          <p className="px-6 pb-6 pt-1 text-[13px] leading-relaxed text-muted">
            Nothing else in this category yet — add another from the Wardrobe tab and it shows up here.
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-2.5 px-5 pb-4 pt-1">
            {alternatives.map((alt) => (
              <button
                key={alt.id}
                onClick={() => {
                  const slot = swapSlot;
                  setSwapSlot(null);
                  start(async () => {
                    await swapOutfitItem(o.id, alt.id);
                    toast(`${alt.name} swapped in`);
                    router.refresh();
                  });
                  void slot;
                }}
                className="overflow-hidden rounded-2xl bg-paper ring-1 ring-ink/[0.06] transition-transform active:scale-[0.94]"
              >
                <GarmentThumb item={alt} className="aspect-square w-full" />
                <div className="px-2 pb-2 pt-1.5">
                  <div className="truncate text-[11px] font-semibold text-ink">{alt.name}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </Sheet>
    </Screen>
  );
}
