import { notFound } from "next/navigation";
import { getOutfitBundle, listItems } from "@/db/queries";
import { todayKey } from "@/lib/utils";
import OutfitClient from "./OutfitClient";

export const dynamic = "force-dynamic";

export default async function OutfitPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const bundle = await getOutfitBundle(id);
  if (!bundle) notFound();
  const allItems = await listItems();
  const canRemix = bundle.outfit.isMain && bundle.outfit.date === todayKey() && !bundle.outfit.dismissedAt;
  return <OutfitClient bundle={bundle} allItems={allItems} canRemix={canRemix} />;
}
