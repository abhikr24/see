"use client";

import { motion } from "framer-motion";
import {
  ChevronRight,
  Info,
  MapPin,
  MessageSquareHeart,
  Smartphone,
  Trash2,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { resetEverything, updateProfile } from "@/app/actions";
import type { Profile } from "@/db/schema";
import type { ProfileStats } from "@/db/queries";
import { colorById } from "@/lib/palette";
import { OCCASIONS, STYLE_TAGS, occasionLabel } from "@/lib/presets";
import { cn, vibrate } from "@/lib/utils";
import { Screen } from "@/components/shell/Screen";
import { Chip, ColorDots, FieldLabel } from "@/components/ui/Fields";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";

export default function ProfileClient({ profile, stats }: { profile: Profile; stats: ProfileStats }) {
  const router = useRouter();
  const { toast } = useToast();
  const [editOpen, setEditOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [, start] = useTransition();

  // edit sheet state
  const [name, setName] = useState(profile.name);
  const [styles, setStyles] = useState<string[]>(profile.styles);
  const [love, setLove] = useState<string[]>(profile.loveColors);
  const [avoid, setAvoid] = useState<string[]>(profile.avoidColors);
  const [occs, setOccs] = useState<string[]>(profile.occasions);
  const [city, setCity] = useState(profile.city);

  const openEdit = () => {
    setName(profile.name);
    setStyles(profile.styles);
    setLove(profile.loveColors);
    setAvoid(profile.avoidColors);
    setOccs(profile.occasions);
    setCity(profile.city);
    setEditOpen(true);
  };

  const saveEdit = () =>
    start(async () => {
      await updateProfile({ name, styles, loveColors: love, avoidColors: avoid, occasions: occs, city });
      setEditOpen(false);
      toast("Style profile updated — tomorrow's look knows");
      router.refresh();
    });

  const toggle = (list: string[], set: (v: string[]) => void, id: string) => {
    vibrate(6);
    set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  };

  return (
    <Screen eyebrow="You, on record" title="Style profile">
      <div className="px-5 pt-1">
        {/* identity */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-center gap-4"
        >
          <div className="flex h-[68px] w-[68px] items-center justify-center rounded-full bg-ink shadow-soft">
            <span className="font-display text-[30px] italic text-cream">{profile.name[0]?.toUpperCase()}</span>
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="truncate font-display text-[26px] leading-tight tracking-tight text-ink">{profile.name}</h2>
            <p className="truncate text-[12.5px] text-muted">
              {profile.styles.length ? profile.styles.slice(0, 3).join(" · ") : "Defining your aesthetic"}
            </p>
          </div>
          <button
            onClick={openEdit}
            className="rounded-full bg-cream px-4 py-2 text-[12px] font-bold text-ink ring-1 ring-ink/10 active:scale-95"
          >
            Edit
          </button>
        </motion.div>

        {/* stats */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.06, ease: [0.22, 1, 0.36, 1] }}
          className="mt-5 grid grid-cols-3 gap-2.5"
        >
          {[
            { label: "Pieces", value: String(stats.itemCount) },
            { label: "Wears logged", value: String(stats.totalWears) },
            { label: "Day streak", value: String(stats.streak) },
          ].map((s) => (
            <div key={s.label} className="rounded-[20px] bg-cream px-4 py-3.5 ring-1 ring-ink/[0.06]">
              <div className="font-display text-[26px] leading-none tracking-tight text-ink tabular">{s.value}</div>
              <div className="micro-label mt-1.5 text-muted">{s.label}</div>
            </div>
          ))}
        </motion.div>

        {/* colour balance */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
          className="mt-3 overflow-hidden rounded-[24px] bg-cream p-5 ring-1 ring-ink/[0.06]"
        >
          <div className="micro-label text-muted">Your closet, by colour</div>
          {stats.colourCounts.length ? (
            <>
              <div className="mt-3.5 flex h-9 w-full gap-1 overflow-hidden rounded-full">
                {stats.colourCounts.map((c) => (
                  <div
                    key={c.id}
                    className="h-full rounded-full first:rounded-l-full last:rounded-r-full"
                    style={{
                      backgroundColor: colorById(c.id).hex,
                      width: `${(c.count / Math.max(1, stats.itemCount)) * 100}%`,
                      minWidth: 18,
                      boxShadow: "inset 0 0 0 1px rgba(25,21,16,0.08)",
                    }}
                    title={`${colorById(c.id).name} — ${c.count}`}
                  />
                ))}
              </div>
              <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1">
                {stats.colourCounts.slice(0, 4).map((c) => (
                  <span key={c.id} className="flex items-center gap-1.5 text-[11px] font-medium text-ink-2">
                    <span className="h-2 w-2 rounded-full ring-1 ring-ink/10" style={{ backgroundColor: colorById(c.id).hex }} />
                    {colorById(c.id).name}
                  </span>
                ))}
              </div>
            </>
          ) : (
            <p className="mt-3 text-[12.5px] text-muted">Colour palette appears once your closet has pieces.</p>
          )}
          {stats.mostWorn && (
            <p className="mt-4 border-t border-ink/[0.06] pt-3 text-[12.5px] text-ink-2">
              Hardest worker: <span className="font-bold">{stats.mostWorn.name}</span>
              <span className="text-muted"> · {stats.mostWorn.times} wears</span>
            </p>
          )}
        </motion.div>

        {/* style DNA summary */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
          className="mt-3 rounded-[24px] bg-cream p-5 ring-1 ring-ink/[0.06]"
        >
          <div className="mb-3 flex items-center justify-between">
            <span className="micro-label text-muted">Style DNA</span>
            <button onClick={openEdit} className="text-[12px] font-bold text-bronze active:scale-95">
              Tune
            </button>
          </div>
          <div className="space-y-4">
            <DnaRow label="Aesthetic">
              {profile.styles.length ? profile.styles.join("  ·  ") : "Not set"}
            </DnaRow>
            <DnaRow label="Colours you love">
              {profile.loveColors.length ? (
                <span className="inline-flex flex-wrap items-center gap-1.5">
                  {profile.loveColors.map((c) => (
                    <span key={c} className="h-3.5 w-3.5 rounded-full ring-1 ring-ink/10" style={{ backgroundColor: colorById(c).hex }} />
                  ))}
                </span>
              ) : (
                "All colours welcome"
              )}
            </DnaRow>
            <DnaRow label="Never suggests">
              {profile.avoidColors.length ? (
                <span className="inline-flex flex-wrap items-center gap-1.5">
                  {profile.avoidColors.map((c) => (
                    <span key={c} className="h-3.5 w-3.5 rounded-full ring-1 ring-ink/10" style={{ backgroundColor: colorById(c).hex }} />
                  ))}
                </span>
              ) : (
                "Nothing ruled out"
              )}
            </DnaRow>
            <DnaRow label="Life occasions">
              {profile.occasions.length ? profile.occasions.map(occasionLabel).join("  ·  ") : "Everyday life"}
            </DnaRow>
            <DnaRow label="Weather city">{profile.city || "General forecast"}</DnaRow>
          </div>
        </motion.div>

        {/* settings list */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.24, ease: [0.22, 1, 0.36, 1] }}
          className="mt-3 overflow-hidden rounded-[24px] bg-cream ring-1 ring-ink/[0.06]"
        >
          <SettingsRow
            icon={Smartphone}
            label="Add to Home Screen"
            onClick={() => window.dispatchEvent(new Event("veste:install"))}
          />
          <SettingsRowLink icon={MessageSquareHeart} label="Tell your stylist" href="/feedback" />
          <SettingsRow icon={Info} label="About Veste" onClick={() => setAboutOpen(true)} />
        </motion.div>

        <button
          onClick={() => setResetOpen(true)}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-full py-3 text-[12.5px] font-bold text-muted active:scale-[0.97]"
        >
          <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
          Start over with a fresh closet
        </button>
        <div className="micro-label mt-2 pb-4 text-center text-muted/60">VESTE · YOUR PERSONAL STYLIST</div>
      </div>

      {/* edit sheet */}
      <Sheet open={editOpen} onClose={() => setEditOpen(false)} title="Tune your style DNA" subtitle="Every change reshapes tomorrow's recommendation.">
        <div className="space-y-6 px-6 pb-6 pt-2">
          <div>
            <FieldLabel>Your name</FieldLabel>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-2xl bg-paper px-4 py-3.5 text-[15px] font-semibold text-ink outline-none ring-1 ring-ink/10 focus:ring-ink/30"
            />
          </div>
          <div>
            <FieldLabel>Aesthetic</FieldLabel>
            <div className="flex flex-wrap gap-1.5">
              {STYLE_TAGS.map((s) => (
                <Chip key={s} small selected={styles.includes(s)} onClick={() => toggle(styles, setStyles, s)}>
                  {s}
                </Chip>
              ))}
            </div>
          </div>
          <div>
            <FieldLabel>Colours you love</FieldLabel>
            <ColorDots selected={love} onToggle={(id) => toggle(love, setLove, id)} />
          </div>
          <div>
            <FieldLabel>Never suggest</FieldLabel>
            <ColorDots selected={avoid} onToggle={(id) => toggle(avoid, setAvoid, id)} />
          </div>
          <div>
            <FieldLabel>Life occasions</FieldLabel>
            <div className="flex flex-wrap gap-1.5">
              {OCCASIONS.map((o) => (
                <Chip key={o.id} small selected={occs.includes(o.id)} onClick={() => toggle(occs, setOccs, o.id)}>
                  {o.label}
                </Chip>
              ))}
            </div>
          </div>
          <div>
            <FieldLabel>Weather city</FieldLabel>
            <div className="flex items-center gap-2 rounded-2xl bg-paper px-4 ring-1 ring-ink/10 focus-within:ring-ink/30">
              <MapPin className="h-4 w-4 text-muted" strokeWidth={2} />
              <input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. Mumbai, Berlin, Austin"
                className="min-w-0 flex-1 bg-transparent py-3.5 text-[15px] font-medium text-ink outline-none placeholder:text-muted/70"
              />
            </div>
          </div>
          <button
            onClick={saveEdit}
            className="w-full rounded-full bg-ink py-4 text-[14.5px] font-bold text-cream shadow-lift active:scale-[0.97]"
          >
            Save my style DNA
          </button>
        </div>
      </Sheet>

      {/* about sheet */}
      <Sheet open={aboutOpen} onClose={() => setAboutOpen(false)} title="About Veste">
        <div className="px-6 pb-6 pt-1">
          <p className="text-[13.5px] leading-relaxed text-ink-2">
            Veste is a personal stylist that lives on your phone. It knows every piece you own, reads the
            weather and your calendar of occasions, and composes one considered look each morning — with
            the reasoning written down, like a stylist would.
          </p>
          <p className="mt-3 text-[13.5px] leading-relaxed text-muted">
            No feeds, no ads, no accounts. Your closet never leaves this device.
          </p>
        </div>
      </Sheet>

      {/* reset sheet */}
      <Sheet open={resetOpen} onClose={() => setResetOpen(false)} title="Start completely over?" subtitle="Closet, history and style profile are erased. This can't be undone.">
        <div className="flex gap-2.5 px-6 pb-6 pt-2">
          <button
            onClick={() => setResetOpen(false)}
            className="flex-1 rounded-full bg-paper py-3.5 text-[14px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.97]"
          >
            Keep everything
          </button>
          <button
            onClick={() =>
              start(async () => {
                await resetEverything();
                setResetOpen(false);
                router.push("/onboarding");
                router.refresh();
              })
            }
            className="flex-1 rounded-full bg-[#7a2e27] py-3.5 text-[14px] font-bold text-cream active:scale-[0.97]"
          >
            Erase & reset
          </button>
        </div>
      </Sheet>
    </Screen>
  );
}

function DnaRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="shrink-0 pt-px text-[11px] font-semibold uppercase tracking-[0.08em] text-muted/80">{label}</span>
      <span className="text-right text-[13px] font-semibold leading-snug text-ink">{children}</span>
    </div>
  );
}

function SettingsRow({ icon: Icon, label, onClick }: { icon: typeof Info; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3.5 px-5 py-4 text-left active:bg-ink/[0.03]">
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-paper ring-1 ring-ink/[0.07]">
        <Icon className="h-4 w-4 text-ink-2" strokeWidth={1.9} />
      </span>
      <span className="flex-1 text-[13.5px] font-semibold text-ink">{label}</span>
      <ChevronRight className="h-4 w-4 text-muted" strokeWidth={2} />
    </button>
  );
}

function SettingsRowLink({ icon: Icon, label, href }: { icon: typeof Info; label: string; href: string }) {
  return (
    <Link href={href} className="flex w-full items-center gap-3.5 px-5 py-4 text-left active:bg-ink/[0.03]" style={{ boxShadow: "0 -1px 0 rgba(25,21,16,0.06)" }}>
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-paper ring-1 ring-ink/[0.07]">
        <Icon className="h-4 w-4 text-ink-2" strokeWidth={1.9} />
      </span>
      <span className="flex-1 text-[13.5px] font-semibold text-ink">{label}</span>
      <ChevronRight className="h-4 w-4 text-muted" strokeWidth={2} />
    </Link>
  );
}
