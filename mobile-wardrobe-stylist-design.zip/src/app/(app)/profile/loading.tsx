import { Screen } from "@/components/shell/Screen";
import { ProfileSkeleton } from "@/components/ui/Skeletons";

export default function Loading() {
  return (
    <Screen eyebrow="…" title="Style profile">
      <ProfileSkeleton />
    </Screen>
  );
}
