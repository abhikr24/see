import { redirect } from "next/navigation";
import { getProfile, getProfileStats } from "@/db/queries";
import ProfileClient from "./ProfileClient";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const profile = await getProfile();
  if (!profile.onboarded) redirect("/onboarding");
  const stats = await getProfileStats();
  return <ProfileClient profile={profile} stats={stats} />;
}
