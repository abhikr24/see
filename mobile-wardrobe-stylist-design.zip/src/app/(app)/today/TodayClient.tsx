"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Camera, ChevronDown, MapPin, Shirt, Wand2 } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { curateCapsule, dismissOutfit, saveOutfit, setOccasion, swapAltIn, updateProfile } from "@/app/actions";
import type { TodayData } from "@/db/queries";
import { occasionLabel } from "@/lib/presets";
import { cn, greeting, longToday, vibrate } from "@/lib/utils";
import { OccasionSheet, occasionIcon } from "@/components/outfit/OccasionSheet";
import { OutfitDock } from "@/components/outfit/OutfitDock";
import { SwipeableLook } from "@/components/outfit/SwipeableLook";
import { WeatherChip } from "@/components/outfit/WeatherChip";
import { WhyItWorks } from "@/components/outfit/WhyItWorks";
import { Screen } from "@/components/shell/Screen";
import { EmptyState } from "@/components/ui/EmptyState";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";
import { OutfitFlatLay } from "@/components/wardrobe/OutfitFlatLay";

export default function TodayClient({ data }: { data: TodayData }) {
  const router = useRouter();
  const { toast } = useToast();
  const [occasionOpen, setOccasionOpen] = useState(false);
  const [cityOpen, setCityOpen] = useState(false);
  const [city, setCity] = useState(data.profile.city);
  const [pending, start] = useTransition();
  const OccIcon = occasionIcon(data.occasion);

  const run = (fn: () => Promise<unknown>, then?: () => void) =>
    start(async () => {
      await fn();
      then?.();
      router.refresh();
    });

  return (
    <Screen
      eyebrow={longToday()}
      title={
        <span>
          Veste<span className="text-bronze">.</span>
        </span>
      }
      right={<WeatherChip weather={data.weather} onClick={() => setCityOpen(true)} />}
    >
      <div className={cn("px-5 pt-1 transition-opacity", pending && "opacity-60")}>
        {/* greeting + context */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}>
          <h1 className="font-display text-[30px] leading-[1.12] tracking-tight text-ink">
            {greeting(data.profile.name).replace(",", "")},
            <br />
            <span className="italic text-bronze">{data.profile.name}.</span>
          </h1>
          <div className="mt-3.5 flex flex-wrap items-center gap-2">
            <button
              onClick={() => setOccasionOpen(true)}
              className="flex items-center gap-2 rounded-full bg-ink py-2 pl-3 pr-3.5 text-cream shadow-soft transition-transform active:scale-95"
            >
              <OccIcon className="h-3.5 w-3.5" strokeWidth={2} />
              <span className="text-[12.5px] font-bold tracking-wide">{occasionLabel(data.occasion)}</span>
              <ChevronDown className="h-3.5 w-3.5 opacity-70" strokeWidth={2.4} />
            </button>
            <span className="text-[12.5px] font-medium text-muted">
              {data.weather.tempC}° · {data.weather.label.toLowerCase()}
              {data.profile.city ? ` · ${data.profile.city}` : ""}
            </span>
          </div>
        </motion.div>

        {data.main ? (
          <div className="mt-5">
            <motion.div
              key={data.main.outfit.id}
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: 0.08 }}
            >
              <SwipeableLook
                outfitId={data.main.outfit.id}
                items={data.main.items}
                onSave={() =>
                  run(() => saveOutfit(data.main!.outfit.id), () => toast("Saved to your looks"))
                }
                onPass={() =>
                  run(() => dismissOutfit(data.main!.outfit.id, data.occasion), () =>
                    toast("Showing you another take…"),
                  )
                }
              />
            </motion.div>

            {/* status strip */}
            <div className="mt-3 flex items-center gap-2 px-1">
              {data.main.outfit.wornAt && (
                <span className="rounded-full bg-olive/15 px-3 py-1 text-[10.5px] font-bold tracking-wide text-olive">
                  WEARING TODAY
                </span>
              )}
              {data.main.outfit.savedAt && (
                <span className="rounded-full bg-bronze/12 px-3 py-1 text-[10.5px] font-bold tracking-wide text-bronze">
                  SAVED
                </span>
              )}
              <span className="ml-auto text-[11px] font-medium text-muted/80">tap the look for details</span>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
              className="mt-5"
            >
              <WhatYoureWearing data={data} />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.24, ease: [0.22, 1, 0.36, 1] }}
              className="mt-7"
            >
              <WhyItWorks reasons={data.main.outfit.reasons} />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="mt-7"
            >
              <OutfitDock
                outfitId={data.main.outfit.id}
                occasion={data.occasion}
                reaction={data.main.outfit.reaction}
                saved={Boolean(data.main.outfit.savedAt)}
                worn={Boolean(data.main.outfit.wornAt)}
                canRemix
              />
            </motion.div>

            {data.alts.length > 0 && (
              <motion.section
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.36, ease: [0.22, 1, 0.36, 1] }}
                className="mt-10"
              >
                <div className="mb-3 px-0.5">
                  <h2 className="font-display text-[21px] tracking-tight text-ink">Other takes</h2>
                  <p className="mt-0.5 text-[12.5px] text-muted">Same closet, different moods.</p>
                </div>
                <div className="no-scrollbar -mx-5 flex snap-x snap-mandatory gap-3.5 overflow-x-auto px-5 pb-2">
                  {data.alts.map((alt) => (
                    <div
                      key={alt.outfit.id}
                      className="w-[64%] shrink-0 snap-center overflow-hidden rounded-[26px] bg-cream ring-1 ring-ink/[0.06] shadow-soft odd:rotate-[-1deg] even:rotate-[1deg]"
                    >
                      <OutfitFlatLay items={alt.items} variant="mini" />
                      <div className="px-4 pb-4 pt-3">
                        <div className="truncate text-[12.5px] font-semibold leading-snug text-ink-2">
                          {alt.items
                            .filter((i) => i.category !== "accessory")
                            .map((i) => i.name)
                            .slice(0, 3)
                            .join(" · ")}
                        </div>
                        <button
                          onClick={() => {
                            vibrate(10);
                            run(
                              () => swapAltIn(alt.outfit.id, data.occasion),
                              () => toast("Swapped in — that's the one"),
                            );
                          }}
                          className="mt-2.5 w-full rounded-full bg-ink py-2.5 text-[12.5px] font-bold text-cream active:scale-[0.96]"
                        >
                          Wear this instead
                        </button>
                      </div>
                    </div>
                  ))}
                  <div className="w-1 shrink-0" />
                </div>
              </motion.section>
            )}
          </div>
        ) : (
          <NoLookState data={data} onCurate={() => run(curateCapsule, () => toast("Your capsule is ready"))} />
        )}
      </div>

      <OccasionSheet
        open={occasionOpen}
        selected={data.occasion}
        onClose={() => setOccasionOpen(false)}
        onSelect={(occ) => {
          setOccasionOpen(false);
          run(
            () => setOccasion(occ),
            () => toast(`Styled for ${occasionLabel(occ).toLowerCase()}`),
          );
        }}
      />

      <Sheet open={cityOpen} onClose={() => setCityOpen(false)} title="Where are you dressing?" subtitle="Weather reads your forecast to calibrate layers.">
        <div className="px-6 pb-4 pt-2">
          <div className="flex items-center gap-2 rounded-2xl bg-paper p-2 pl-4 ring-1 ring-ink/10">
            <MapPin className="h-4 w-4 shrink-0 text-muted" strokeWidth={2} />
            <input
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="City — e.g. Mumbai, Berlin, Austin"
              className="min-w-0 flex-1 bg-transparent text-[14px] font-medium text-ink outline-none placeholder:text-muted/70"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  setCityOpen(false);
                  run(() => updateProfile({ city }), () => toast("Forecast locked to " + city));
                }
              }}
            />
          </div>
          <button
            onClick={() => {
              setCityOpen(false);
              run(() => updateProfile({ city }), () => toast(city ? `Forecast locked to ${city}` : "Using a general forecast"));
            }}
            className="mt-3 w-full rounded-full bg-ink py-4 text-[14px] font-bold text-cream active:scale-[0.97]"
          >
            Set location
          </button>
        </div>
      </Sheet>
    </Screen>
  );
}

/** Compact "what you're wearing" strip under the hero. */
function WhatYoureWearing({ data }: { data: TodayData }) {
  const items = data.main!.items;
  return (
    <div className="flex flex-wrap gap-x-4 gap-y-1.5 px-1">
      {items.map((i) => (
        <span key={i.id} className="flex items-center gap-1.5 text-[12px] font-medium text-ink-2">
          <span className="h-1.5 w-1.5 rounded-full bg-bronze/60" />
          {i.name}
        </span>
      ))}
    </div>
  );
}

/** The closet-starts-here moment, with both doors open: curate or capture. */
function NoLookState({ data, onCurate }: { data: TodayData; onCurate: () => void }) {
  const missing = data.missing;
  return (
    <div className="mt-10">
      <EmptyState
        icon={Shirt}
        title={data.itemCount === 0 ? "Your closet is a blank page" : "Almost dressed"}
        body={
          data.itemCount === 0
            ? "Add a few pieces and your stylist takes it from there — a look every morning, built from what you own."
            : `Your stylist needs a ${missing.join(", ")} before composing a look. Add one and it's handled.`
        }
      >
        <button
          onClick={onCurate}
          className="flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
        >
          <Wand2 className="h-4 w-4" strokeWidth={2} />
          Curate my starter capsule
        </button>
        <Link
          href="/add"
          className="flex items-center gap-2 rounded-full bg-cream px-7 py-4 text-[14px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.96]"
        >
          <Camera className="h-4 w-4" strokeWidth={2} />
          Add with camera
        </Link>
      </EmptyState>
      <AnimatePresence>{null}</AnimatePresence>
    </div>
  );
}
