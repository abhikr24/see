import { Screen } from "@/components/shell/Screen";
import { TodaySkeleton } from "@/components/ui/Skeletons";

export default function Loading() {
  return (
    <Screen eyebrow="…" title="Veste.">
      <TodaySkeleton />
    </Screen>
  );
}
