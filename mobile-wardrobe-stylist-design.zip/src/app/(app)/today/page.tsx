import { redirect } from "next/navigation";
import { getTodayData } from "@/db/queries";
import TodayClient from "./TodayClient";

export const dynamic = "force-dynamic";

export default async function TodayPage() {
  const data = await getTodayData();
  if (!data.profile.onboarded) redirect("/onboarding");
  return <TodayClient data={data} />;
}
