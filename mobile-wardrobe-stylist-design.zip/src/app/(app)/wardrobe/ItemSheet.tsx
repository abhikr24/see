"use client";

import { Check, Heart, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import {
  deleteItem,
  markItemWorn,
  toggleFavorite,
  updateItemOccasions,
} from "@/app/actions";
import type { ClothingItem } from "@/db/schema";
import { colorById } from "@/lib/palette";
import { OCCASIONS, SUBCATEGORIES } from "@/lib/presets";
import { cn, daysSince, timeAgo, vibrate } from "@/lib/utils";
import { Chip, FieldLabel } from "@/components/ui/Fields";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";
import { GarmentThumb } from "@/components/wardrobe/GarmentThumb";

const FORMALITY = ["Casual", "Smart", "Dressy"];
const WARMTH = ["Featherlight", "Midweight", "Cozy"];

export function ItemSheet({ item, onClose }: { item: ClothingItem | null; onClose: () => void }) {
  const router = useRouter();
  const { toast } = useToast();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [, start] = useTransition();

  useEffect(() => setConfirmDelete(false), [item?.id]);

  if (!item) return <Sheet open={false} onClose={onClose}>{null}</Sheet>;

  const wornDays = daysSince(item.lastWornAt);

  const act = (fn: () => Promise<unknown>, then?: () => void) =>
    start(async () => {
      await fn();
      then?.();
      router.refresh();
    });

  const toggleOccasion = (id: string) => {
    vibrate(6);
    const next = item.occasions.includes(id)
      ? item.occasions.filter((o) => o !== id)
      : [...item.occasions, id];
    act(() => updateItemOccasions(item.id, next));
  };

  return (
    <Sheet open={Boolean(item)} onClose={onClose}>
      <div className="px-6 pt-1">
        <div className="flex gap-4">
          <GarmentThumb item={item} className="h-28 w-28 shrink-0 rounded-[20px] bg-bronze-soft/30 ring-1 ring-ink/[0.05]" />
          <div className="min-w-0 flex-1 pt-1">
            <h3 className="font-display text-[23px] leading-tight tracking-tight text-ink">{item.name}</h3>
            <p className="mt-0.5 text-[12.5px] text-muted">
              {SUBCATEGORIES[item.subcategory]?.label ?? item.subcategory}
              {item.pattern !== "solid" && " · patterned"}
            </p>
            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
              {item.colors.map((c) => (
                <span
                  key={c}
                  className="flex items-center gap-1.5 rounded-full bg-paper py-1 pl-1.5 pr-2.5 ring-1 ring-ink/[0.08]"
                >
                  <span className="h-3.5 w-3.5 rounded-full ring-1 ring-ink/10" style={{ backgroundColor: colorById(c).hex }} />
                  <span className="text-[10.5px] font-semibold text-ink-2">{colorById(c).name}</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* meta strip */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          {[
            { label: "Formality", value: FORMALITY[item.formality] ?? "Casual" },
            { label: "Weight", value: WARMTH[item.warmth] ?? "Mid" },
            {
              label: "Rotation",
              value: item.timesWorn === 0 ? "Not worn yet" : `${item.timesWorn}×${wornDays != null ? ` · ${wornDays}d ago` : ""}`,
            },
          ].map((m) => (
            <div key={m.label} className="rounded-2xl bg-paper px-3 py-2.5 ring-1 ring-ink/[0.06]">
              <div className="micro-label text-muted/80">{m.label}</div>
              <div className="mt-0.5 truncate text-[12.5px] font-bold text-ink">{m.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* occasions editor */}
      <div className="mt-5 px-6">
        <FieldLabel>Wears well to</FieldLabel>
        <div className="flex flex-wrap gap-1.5">
          {OCCASIONS.map((o) => (
            <Chip key={o.id} small selected={item.occasions.includes(o.id)} onClick={() => toggleOccasion(o.id)}>
              {o.label}
            </Chip>
          ))}
        </div>
      </div>

      {/* actions */}
      <div className="mt-6 grid grid-cols-2 gap-2.5 px-6 pb-2">
        <button
          onClick={() =>
            act(() => markItemWorn(item.id), () => toast(`${item.name} logged as worn`))
          }
          className="flex items-center justify-center gap-2 rounded-full bg-ink py-3.5 text-[13.5px] font-bold text-cream active:scale-[0.96]"
        >
          <Check className="h-4 w-4" strokeWidth={2.4} />
          Wore this
        </button>
        <button
          onClick={() => {
            vibrate(8);
            act(() => toggleFavorite(item.id));
          }}
          className={cn(
            "flex items-center justify-center gap-2 rounded-full py-3.5 text-[13.5px] font-bold ring-1 active:scale-[0.96]",
            item.favorite ? "bg-bronze/15 text-bronze ring-bronze/30" : "bg-cream text-ink ring-ink/10",
          )}
        >
          <Heart className={cn("h-4 w-4", item.favorite && "fill-bronze")} strokeWidth={2.2} />
          {item.favorite ? "Favorited" : "Favorite"}
        </button>
        <button
          onClick={() => {
            if (!confirmDelete) {
              vibrate(8);
              setConfirmDelete(true);
              return;
            }
            act(() => deleteItem(item.id), () => {
              toast("Removed from your closet");
              onClose();
            });
          }}
          className={cn(
            "col-span-2 rounded-full py-3 text-[12.5px] font-bold transition-all active:scale-[0.97]",
            confirmDelete ? "bg-[#7a2e27]/10 text-[#7a2e27] ring-1 ring-[#7a2e27]/25" : "text-muted",
          )}
        >
          <span className="flex items-center justify-center gap-2">
            <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
            {confirmDelete ? "Tap again — this removes it for good" : "Remove from closet"}
          </span>
        </button>
        <div className="col-span-2 pt-1 text-center text-[10.5px] font-medium text-muted/70">
          Added {timeAgo(item.createdAt)}
          {item.source !== "capsule" && ` · via ${item.source === "camera" ? "camera" : item.source === "upload" ? "upload" : "manual entry"}`}
        </div>
      </div>
    </Sheet>
  );
}
