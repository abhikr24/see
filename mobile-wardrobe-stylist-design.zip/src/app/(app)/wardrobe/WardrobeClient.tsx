"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Camera, Plus, Search, Shirt, Wand2, X } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { curateCapsule } from "@/app/actions";
import type { ClothingItem } from "@/db/schema";
import { colorById } from "@/lib/palette";
import { CATEGORIES, SUBCATEGORIES, type Category } from "@/lib/presets";
import { cn } from "@/lib/utils";
import { Screen } from "@/components/shell/Screen";
import { EmptyState } from "@/components/ui/EmptyState";
import { useToast } from "@/components/ui/Toast";
import { ItemTile } from "@/components/wardrobe/ItemTile";
import { ItemSheet } from "./ItemSheet";

type Filter = "all" | Category;

export default function WardrobeClient({ items }: { items: ClothingItem[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [active, setActive] = useState<ClothingItem | null>(null);
  const [, start] = useTransition();

  const counts = useMemo(() => {
    const m = new Map<string, number>();
    for (const i of items) m.set(i.category, (m.get(i.category) ?? 0) + 1);
    return m;
  }, [items]);

  const visible = useMemo(() => {
    let list = items;
    if (filter !== "all") list = list.filter((i) => i.category === filter);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          (SUBCATEGORIES[i.subcategory]?.label ?? "").toLowerCase().includes(q) ||
          i.colors.some((c) => colorById(c).name.toLowerCase().includes(q)),
      );
    }
    return list;
  }, [items, filter, query]);

  return (
    <Screen
      eyebrow={items.length ? `${items.length} piece${items.length === 1 ? "" : "s"}` : "The closet"}
      title="Wardrobe"
      right={
        <button
          aria-label="Search wardrobe"
          onClick={() => {
            setSearchOpen(!searchOpen);
            if (searchOpen) setQuery("");
          }}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-cream ring-1 ring-ink/[0.08] active:scale-90"
        >
          {searchOpen ? (
            <X className="h-[18px] w-[18px] text-ink" strokeWidth={2} />
          ) : (
            <Search className="h-[18px] w-[18px] text-ink" strokeWidth={2} />
          )}
        </button>
      }
    >
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden px-5"
          >
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search “navy”, “linen”, “boots”…"
              className="mb-3 w-full rounded-full bg-cream px-5 py-3 text-[14px] font-medium text-ink outline-none ring-1 ring-ink/10 placeholder:text-muted/70 focus:ring-ink/25"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* category rail */}
      <div className="sticky top-0 z-20 -mx-0 bg-paper/90 pb-3 pt-1 backdrop-blur-lg">
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-5">
          {[{ id: "all" as Filter, label: "All", plural: "All" }, ...CATEGORIES].map((c) => {
            const on = filter === c.id;
            const n = c.id === "all" ? items.length : (counts.get(c.id) ?? 0);
            if (c.id !== "all" && n === 0) return null;
            return (
              <button
                key={c.id}
                onClick={() => setFilter(c.id as Filter)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-[12.5px] font-semibold transition-all active:scale-95",
                  on ? "bg-ink text-cream shadow-soft" : "bg-cream text-ink-2 ring-1 ring-ink/[0.08]",
                )}
              >
                {c.id === "all" ? "All" : c.plural}
                <span className={cn("text-[10px] tabular", on ? "text-cream/60" : "text-muted")}>{n}</span>
              </button>
            );
          })}
        </div>
      </div>

      {visible.length > 0 ? (
        <div className="grid grid-cols-2 gap-3 px-5 pt-1">
          <AddTile />
          <AnimatePresence mode="popLayout">
            {visible.map((item, i) => (
              <motion.div key={item.id} layout exit={{ opacity: 0, scale: 0.9 }}>
                <ItemTile item={item} index={Math.min(i, 12)} onClick={() => setActive(item)} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : items.length === 0 ? (
        <div className="pt-8">
          <EmptyState
            icon={Shirt}
            title="Nothing here yet — and that's exciting"
            body="Every great wardrobe starts with a first hanger. Add a piece, or let us curate a capsule for you."
          >
            <button
              onClick={() =>
                start(async () => {
                  await curateCapsule();
                  toast("Your capsule is ready");
                  router.refresh();
                })
              }
              className="flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
            >
              <Wand2 className="h-4 w-4" strokeWidth={2} />
              Curate my capsule
            </button>
            <Link
              href="/add"
              className="flex items-center gap-2 rounded-full bg-cream px-7 py-4 text-[14px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.96]"
            >
              <Camera className="h-4 w-4" strokeWidth={2} />
              Add with camera
            </Link>
          </EmptyState>
        </div>
      ) : (
        <div className="pt-10">
          <EmptyState
            icon={Search}
            title="Nothing matches"
            body={query ? `No pieces found for “${query}”.` : "This rail is empty for now."}
          >
            <Link
              href="/add"
              className="flex items-center gap-2 rounded-full bg-ink px-7 py-3.5 text-[13.5px] font-bold text-cream active:scale-[0.96]"
            >
              <Plus className="h-4 w-4" strokeWidth={2.4} />
              Add a piece
            </Link>
          </EmptyState>
        </div>
      )}

      <ItemSheet item={active} onClose={() => setActive(null)} />
    </Screen>
  );
}

function AddTile() {
  return (
    <Link
      href="/add"
      className="flex aspect-[5/6.9] flex-col items-center justify-center gap-2.5 rounded-[22px] border-[1.5px] border-dashed border-ink/20 text-muted transition-colors active:scale-[0.97] active:border-ink/40"
    >
      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-ink/[0.06]">
        <Plus className="h-5 w-5 text-ink/60" strokeWidth={2.2} />
      </span>
      <span className="text-[12px] font-bold tracking-wide text-ink/50">ADD PIECE</span>
    </Link>
  );
}
