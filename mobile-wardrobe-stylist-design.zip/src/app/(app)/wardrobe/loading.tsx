import { Screen } from "@/components/shell/Screen";
import { GridSkeleton } from "@/components/ui/Skeletons";

export default function Loading() {
  return (
    <Screen eyebrow="…" title="Wardrobe">
      <GridSkeleton />
    </Screen>
  );
}
