import { redirect } from "next/navigation";
import { getProfile, listItems } from "@/db/queries";
import WardrobeClient from "./WardrobeClient";

export const dynamic = "force-dynamic";

export default async function WardrobePage() {
  const profile = await getProfile();
  if (!profile.onboarded) redirect("/onboarding");
  const items = await listItems();
  return <WardrobeClient items={items} />;
}
