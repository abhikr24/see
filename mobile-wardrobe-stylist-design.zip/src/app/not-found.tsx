import { ArrowLeft } from "lucide-react";
import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex h-full flex-col items-center justify-center px-8 text-center">
      <div className="font-display text-[64px] italic leading-none text-ink/20">No. 404</div>
      <h2 className="mt-4 font-display text-[24px] tracking-tight text-ink">This look has moved on</h2>
      <p className="mt-2 max-w-[250px] text-[13px] leading-relaxed text-muted">
        The page you were after isn't in the closet anymore.
      </p>
      <Link
        href="/today"
        className="mt-8 flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={2.2} />
        Back to today
      </Link>
    </div>
  );
}
