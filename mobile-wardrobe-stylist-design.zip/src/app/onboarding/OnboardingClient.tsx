"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, MapPin, Sparkle } from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { completeOnboarding } from "@/app/actions";
import { colorById } from "@/lib/palette";
import { CAPSULE, DEFAULT_CAPSULE_KEYS, OCCASIONS, STYLE_TAGS } from "@/lib/presets";
import { cn, vibrate } from "@/lib/utils";
import { Chip, ColorDots, FieldLabel } from "@/components/ui/Fields";
import { GarmentThumb } from "@/components/wardrobe/GarmentThumb";

const STEPS = 4;

/** Capsule pieces offered in the picker — the essential core plus a few statements. */
const PICK_KEYS = Array.from(new Set([...DEFAULT_CAPSULE_KEYS, "evening-shirt", "navy-polo", "camel-cardigan", "slip-skirt", "stone-shorts", "black-heels"]));
const PICKS = CAPSULE.filter((c) => PICK_KEYS.includes(c.key));

export default function OnboardingClient({ defaultName }: { defaultName: string }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [pending, start] = useTransition();

  const [name, setName] = useState(defaultName);
  const [styles, setStyles] = useState<string[]>([]);
  const [love, setLove] = useState<string[]>([]);
  const [avoid, setAvoid] = useState<string[]>([]);
  const [occs, setOccs] = useState<string[]>(["daily"]);
  const [city, setCity] = useState("");
  const [picks, setPicks] = useState<string[]>(DEFAULT_CAPSULE_KEYS);

  const toggle = (list: string[], set: (v: string[]) => void, id: string) => {
    vibrate(7);
    set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  };

  const next = () => {
    vibrate(8);
    setDir(1);
    setStep((s) => Math.min(STEPS - 1, s + 1));
  };
  const back = () => {
    vibrate(6);
    setDir(-1);
    setStep((s) => Math.max(0, s - 1));
  };

  const finish = (capsuleKeys: string[]) =>
    start(async () => {
      localStorage.removeItem("veste_a2hs_until"); // allow the install nudge on Today
      await completeOnboarding({
        name: name.trim(),
        styles,
        loveColors: love,
        avoidColors: avoid,
        occasions: occs.length ? occs : ["daily"],
        city,
        capsuleKeys,
      });
      router.push("/today");
      router.refresh();
    });

  const canNext = step !== 1 || name.trim().length > 0;

  return (
    <div className="flex h-full flex-col">
      {/* progress chrome */}
      <div className="safe-top flex items-center gap-3 px-5 pb-2 pt-4">
        {step > 0 ? (
          <button onClick={back} aria-label="Back" className="flex h-9 w-9 items-center justify-center rounded-full bg-cream ring-1 ring-ink/10 active:scale-90">
            <ArrowLeft className="h-4 w-4 text-ink" strokeWidth={2.2} />
          </button>
        ) : (
          <span className="w-9" />
        )}
        <div className="flex flex-1 items-center justify-center gap-1.5">
          {Array.from({ length: STEPS }).map((_, i) => (
            <span
              key={i}
              className={cn(
                "h-1 rounded-full transition-all duration-300",
                i === step ? "w-7 bg-ink" : i < step ? "w-3 bg-ink/45" : "w-3 bg-ink/15",
              )}
            />
          ))}
        </div>
        {step > 0 && step < STEPS - 1 ? (
          <button onClick={next} className="w-9 text-[12px] font-bold text-muted active:scale-90">
            Skip
          </button>
        ) : (
          <span className="w-9" />
        )}
      </div>

      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto">
        <AnimatePresence mode="wait" custom={dir}>
          <motion.div
            key={step}
            custom={dir}
            initial={{ opacity: 0, x: 44 * dir }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -44 * dir }}
            transition={{ duration: 0.34, ease: [0.22, 1, 0.36, 1] }}
            className="px-5 pb-6"
          >
            {step === 0 && <Welcome />}
            {step === 1 && (
              <div className="pt-4">
                <Prompt index="01" title={<>First — what should<br />your stylist call you?</>} />
                <input
                  autoFocus
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  maxLength={20}
                  className="mt-7 w-full border-b-2 border-ink/20 bg-transparent pb-2 font-display text-[34px] tracking-tight text-ink outline-none placeholder:text-ink/25 focus:border-ink"
                />
                <div className="mt-9">
                  <FieldLabel>Your aesthetic — pick what resonates</FieldLabel>
                  <div className="flex flex-wrap gap-2">
                    {STYLE_TAGS.map((s) => (
                      <Chip key={s} selected={styles.includes(s)} onClick={() => toggle(styles, setStyles, s)}>
                        {s}
                      </Chip>
                    ))}
                  </div>
                </div>
              </div>
            )}
            {step === 2 && (
              <div className="pt-4">
                <Prompt index="02" title={<>Colour, weather<br />and where life happens.</>} />
                <div className="mt-7 space-y-7">
                  <div>
                    <FieldLabel>Colours you love wearing</FieldLabel>
                    <ColorDots selected={love} onToggle={(id) => {
                      toggle(love, setLove, id);
                      if (!love.includes(id) && avoid.includes(id)) setAvoid(avoid.filter((x) => x !== id));
                    }} />
                  </div>
                  <div>
                    <FieldLabel>Never show you</FieldLabel>
                    <ColorDots selected={avoid} onToggle={(id) => {
                      toggle(avoid, setAvoid, id);
                      if (!avoid.includes(id) && love.includes(id)) setLove(love.filter((x) => x !== id));
                    }} />
                  </div>
                  <div>
                    <FieldLabel>Where does life take you?</FieldLabel>
                    <div className="flex flex-wrap gap-1.5">
                      {OCCASIONS.map((o) => (
                        <Chip key={o.id} small selected={occs.includes(o.id)} onClick={() => toggle(occs, setOccs, o.id)}>
                          {o.label}
                        </Chip>
                      ))}
                    </div>
                  </div>
                  <div>
                    <FieldLabel>Your city — for the forecast</FieldLabel>
                    <div className="flex items-center gap-2 rounded-2xl bg-cream px-4 ring-1 ring-ink/10 focus-within:ring-ink/30">
                      <MapPin className="h-4 w-4 shrink-0 text-muted" strokeWidth={2} />
                      <input
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        placeholder="e.g. Mumbai, Berlin, Austin"
                        className="min-w-0 flex-1 bg-transparent py-3.5 text-[14.5px] font-medium text-ink outline-none placeholder:text-muted/70"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
            {step === 3 && (
              <div className="pt-4">
                <Prompt index="03" title={<>Pick what you own —<br />we'll hang the rest later.</>} />
                <p className="mt-2 text-[13px] leading-relaxed text-muted">
                  A starter capsule is pre-picked. Tap to remove or add — you can photograph your real pieces any time.
                </p>
                <div className="mt-5 grid grid-cols-3 gap-2.5">
                  {PICKS.map((c, i) => {
                    const on = picks.includes(c.key);
                    const item = { name: c.name, subcategory: c.subcategory, colors: c.colors, imageUrl: null };
                    return (
                      <motion.button
                        key={c.key}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: Math.min(i, 15) * 0.03, duration: 0.35 }}
                        onClick={() => toggle(picks, setPicks, c.key)}
                        className={cn(
                          "relative overflow-hidden rounded-[18px] bg-cream text-left ring-1 transition-all active:scale-[0.94]",
                          on ? "ring-2 ring-ink shadow-soft" : "ring-ink/[0.07] opacity-80",
                        )}
                      >
                        <GarmentThumb item={item} className="aspect-square w-full" />
                        <div className="px-2 pb-2 pt-1">
                          <div className="truncate text-[10.5px] font-semibold leading-tight text-ink">{c.name}</div>
                        </div>
                        {on && (
                          <span className="absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-ink">
                            <Check className="h-3 w-3 text-cream" strokeWidth={3} />
                          </span>
                        )}
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* footer CTA */}
      <div className="shrink-0 px-5 pb-[max(env(safe-area-inset-bottom),18px)] pt-2">
        {step < STEPS - 1 ? (
          <button
            onClick={next}
            disabled={!canNext}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-ink py-[17px] text-[15px] font-bold text-cream shadow-lift transition-all active:scale-[0.97] disabled:opacity-30"
          >
            {step === 0 ? "Meet your stylist" : "Continue"}
            <ArrowRight className="h-4 w-4" strokeWidth={2.4} />
          </button>
        ) : (
          <div>
            <button
              onClick={() => finish(picks)}
              disabled={pending}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-ink py-[17px] text-[15px] font-bold text-cream shadow-lift transition-all active:scale-[0.97] disabled:opacity-60"
            >
              <Sparkle className="h-4 w-4" strokeWidth={2.2} />
              {pending ? "Curating your closet…" : `Build my closet · ${picks.length} pieces`}
            </button>
            <button
              onClick={() => finish([])}
              disabled={pending}
              className="mt-2.5 w-full py-2 text-center text-[12.5px] font-bold text-muted active:scale-[0.97]"
            >
              I'll photograph my own pieces instead
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Welcome() {
  return (
    <div className="pt-2">
      <div className="relative overflow-hidden rounded-[30px] shadow-lift">
        <div className="relative aspect-[4/4.4] w-full">
          <Image src="/images/onboarding.jpg" alt="A calm, curated wardrobe" fill priority className="object-cover" sizes="430px" />
          <div className="absolute inset-0 bg-[linear-gradient(to_top,rgba(20,16,10,0.72),transparent_55%)]" />
          <div className="absolute inset-x-0 bottom-0 p-6">
            <div className="micro-label mb-2 text-cream/70">Veste · personal stylist</div>
            <h1 className="font-display text-[34px] leading-[1.08] tracking-tight text-cream">
              Get dressed<br />
              in <span className="italic">one glance.</span>
            </h1>
          </div>
        </div>
      </div>
      <div className="mt-5 space-y-2 px-1">
        {["Knows the clothes you already own", "Reads the weather and the occasion", "One considered look, every morning"].map((t) => (
          <div key={t} className="flex items-center gap-2.5 text-[13.5px] font-medium text-ink-2">
            <span className="h-1 w-1 rounded-full bg-bronze" />
            {t}
          </div>
        ))}
      </div>
    </div>
  );
}

function Prompt({ index, title }: { index: string; title: React.ReactNode }) {
  return (
    <div>
      <div className="micro-label text-bronze">{index}</div>
      <h1 className="mt-2 font-display text-[30px] leading-[1.14] tracking-tight text-ink">{title}</h1>
    </div>
  );
}
