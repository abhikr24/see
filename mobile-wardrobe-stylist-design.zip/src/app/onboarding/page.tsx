import { redirect } from "next/navigation";
import { getProfile } from "@/db/queries";
import OnboardingClient from "./OnboardingClient";

export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  const profile = await getProfile();
  if (profile.onboarded) redirect("/today");
  return <OnboardingClient defaultName={profile.name === "Avery" ? "" : profile.name} />;
}
