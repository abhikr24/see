import { redirect } from "next/navigation";
import { getProfile } from "@/db/queries";

export const dynamic = "force-dynamic";

export default async function Root() {
  const profile = await getProfile();
  redirect(profile.onboarded ? "/today" : "/onboarding");
}
