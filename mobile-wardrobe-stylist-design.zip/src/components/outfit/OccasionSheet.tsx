"use client";

import {
  Award,
  Briefcase,
  Check,
  Coffee,
  Dumbbell,
  Gem,
  GraduationCap,
  Heart,
  PartyPopper,
  PenLine,
  Plane,
  Sparkles,
  Users,
  UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import { useState } from "react";
import { OCCASIONS, occasionLabel } from "@/lib/presets";
import { cn, vibrate } from "@/lib/utils";
import { Sheet } from "@/components/ui/Sheet";

export const OCCASION_ICONS: Record<string, LucideIcon> = {
  daily: Coffee,
  college: GraduationCap,
  office: Briefcase,
  interview: Award,
  date: Heart,
  wedding: Gem,
  party: PartyPopper,
  family: Users,
  travel: Plane,
  dinner: UtensilsCrossed,
  gym: Dumbbell,
  festival: Sparkles,
};

export function occasionIcon(id: string): LucideIcon {
  return OCCASION_ICONS[id] ?? PenLine;
}

export function OccasionSheet({
  open,
  selected,
  onClose,
  onSelect,
}: {
  open: boolean;
  selected: string;
  onClose: () => void;
  onSelect: (occasion: string) => void;
}) {
  const [customMode, setCustomMode] = useState(false);
  const [custom, setCustom] = useState("");

  const pick = (id: string) => {
    vibrate(10);
    onSelect(id);
    setCustomMode(false);
    setCustom("");
  };

  return (
    <Sheet open={open} onClose={onClose} title="What's the occasion?" subtitle="The look rebuilds itself around the plan.">
      <div className="grid grid-cols-2 gap-2 px-5 pt-1">
        {OCCASIONS.map((o) => {
          const Icon = OCCASION_ICONS[o.id] ?? Coffee;
          const on = selected === o.id;
          return (
            <button
              key={o.id}
              onClick={() => pick(o.id)}
              className={cn(
                "flex items-center gap-3 rounded-2xl px-3.5 py-3 text-left transition-all active:scale-[0.96]",
                on ? "bg-ink text-cream shadow-soft" : "bg-paper ring-1 ring-ink/[0.07]",
              )}
            >
              <span
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                  on ? "bg-cream/15" : "bg-cream ring-1 ring-ink/[0.06]",
                )}
              >
                <Icon className={cn("h-4 w-4", on ? "text-cream" : "text-ink-2")} strokeWidth={1.9} />
              </span>
              <span className="min-w-0 flex-1">
                <span className={cn("block truncate text-[13px] font-semibold", on ? "text-cream" : "text-ink")}>
                  {o.label}
                </span>
                <span className={cn("block truncate text-[10.5px]", on ? "text-cream/60" : "text-muted")}>
                  {o.blurb}
                </span>
              </span>
              {on && <Check className="h-4 w-4 shrink-0 text-cream" strokeWidth={2.5} />}
            </button>
          );
        })}
      </div>
      <div className="px-5 pt-2 pb-2">
        {customMode ? (
          <div className="flex items-center gap-2 rounded-2xl bg-paper p-2 pl-4 ring-1 ring-ink/10">
            <input
              autoFocus
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Housewarming, brunch, pitch day…"
              className="min-w-0 flex-1 bg-transparent text-[14px] font-medium text-ink outline-none placeholder:text-muted/70"
              onKeyDown={(e) => {
                if (e.key === "Enter" && custom.trim()) pick(`custom:${custom.trim()}`);
              }}
            />
            <button
              onClick={() => custom.trim() && pick(`custom:${custom.trim()}`)}
              className="rounded-full bg-ink px-5 py-2.5 text-[13px] font-semibold text-cream active:scale-95"
            >
              Set
            </button>
          </div>
        ) : (
          <button
            onClick={() => setCustomMode(true)}
            className={cn(
              "flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left ring-1 transition-all active:scale-[0.98]",
              selected.startsWith("custom:")
                ? "bg-ink text-cream ring-ink"
                : "bg-paper ring-ink/[0.07]",
            )}
          >
            <span className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
              selected.startsWith("custom:") ? "bg-cream/15" : "bg-cream ring-1 ring-ink/[0.06]",
            )}>
              <PenLine className={cn("h-4 w-4", selected.startsWith("custom:") ? "text-cream" : "text-ink-2")} strokeWidth={1.9} />
            </span>
            <span className="min-w-0 flex-1">
              <span className={cn("block truncate text-[13px] font-semibold", selected.startsWith("custom:") ? "text-cream" : "text-ink")}>
                {selected.startsWith("custom:") ? occasionLabel(selected) : "Custom occasion"}
              </span>
              <span className={cn("block text-[10.5px]", selected.startsWith("custom:") ? "text-cream/60" : "text-muted")}>
                Name it yourself
              </span>
            </span>
          </button>
        )}
      </div>
    </Sheet>
  );
}
