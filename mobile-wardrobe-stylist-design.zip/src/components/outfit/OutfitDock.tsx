"use client";

import { Bookmark, Shuffle, ThumbsDown, ThumbsUp } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import {
  reactOutfit,
  remixToday,
  saveOutfit,
  submitFeedback,
  unsaveOutfit,
  wearOutfit,
} from "@/app/actions";
import { cn, vibrate } from "@/lib/utils";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";

/**
 * The thumb-reachable action dock: dislike · remix · like · save, plus the
 * primary "wear it" commit. Disliking opens an optional why-note that feeds
 * the stylist's memory.
 */
export function OutfitDock({
  outfitId,
  occasion,
  reaction: initialReaction,
  saved: initialSaved,
  worn: initialWorn,
  canRemix,
}: {
  outfitId: string;
  occasion: string;
  reaction: string | null;
  saved: boolean;
  worn: boolean;
  canRemix: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [reaction, setReaction] = useState(initialReaction);
  const [saved, setSaved] = useState(initialSaved);
  const [worn, setWorn] = useState(initialWorn);
  const [whyOpen, setWhyOpen] = useState(false);
  const [note, setNote] = useState("");
  const [pending, start] = useTransition();

  const act = (fn: () => Promise<unknown>, after?: () => void) => {
    start(async () => {
      await fn();
      after?.();
      router.refresh();
    });
  };

  const onLike = () => {
    vibrate(10);
    const next = reaction === "like" ? null : "like";
    setReaction(next);
    act(() => reactOutfit(outfitId, next));
    if (next === "like") toast("Noted — more of this energy");
  };

  const onDislike = () => {
    vibrate(10);
    const next = reaction === "dislike" ? null : "dislike";
    setReaction(next);
    act(() => reactOutfit(outfitId, next));
    if (next === "dislike") setWhyOpen(true);
  };

  const onSave = () => {
    vibrate(10);
    setSaved(!saved);
    act(() => (saved ? unsaveOutfit(outfitId) : saveOutfit(outfitId)));
    toast(saved ? "Removed from saved" : "Saved to your looks", {
      action: saved ? undefined : { label: "Nice", onClick: () => {} },
    });
  };

  const onWear = () => {
    vibrate([12, 40, 12]);
    setWorn(true);
    act(() => wearOutfit(outfitId));
    toast("Logged. Go get the compliments.");
  };

  const onRemix = () => {
    vibrate(10);
    act(() => remixToday(occasion));
    toast("Shuffling a fresh take…");
  };

  return (
    <>
      <div className="flex items-center justify-between gap-3">
        <DockButton
          label="Nope"
          active={reaction === "dislike"}
          activeClass="bg-ink text-cream"
          onClick={onDislike}
        >
          <ThumbsDown className="h-[18px] w-[18px]" strokeWidth={2} />
        </DockButton>
        {canRemix && (
          <DockButton label="Remix" onClick={onRemix} busy={pending}>
            <Shuffle className="h-[18px] w-[18px]" strokeWidth={2} />
          </DockButton>
        )}
        <DockButton label="Love" active={reaction === "like"} activeClass="bg-ink text-cream" onClick={onLike}>
          <ThumbsUp className="h-[18px] w-[18px]" strokeWidth={2} />
        </DockButton>
        <DockButton label={saved ? "Saved" : "Save"} active={saved} activeClass="bg-bronze text-cream" onClick={onSave}>
          <Bookmark className={cn("h-[18px] w-[18px]", saved && "fill-cream")} strokeWidth={2} />
        </DockButton>
      </div>

      <button
        onClick={onWear}
        disabled={pending}
        className={cn(
          "mt-4 w-full rounded-full py-[17px] text-[15px] font-bold tracking-wide transition-all active:scale-[0.97]",
          worn
            ? "bg-olive/15 text-olive ring-1 ring-olive/30"
            : "bg-ink text-cream shadow-lift",
        )}
      >
        {worn ? "Worn — logged in your style history" : "I'm wearing this today"}
      </button>

      <Sheet open={whyOpen} onClose={() => setWhyOpen(false)} title="What felt off?" subtitle="Optional — it sharpens every future pick.">
        <div className="px-6 pb-4 pt-2">
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={3}
            placeholder="Too formal, wrong colour for today, tired of that jacket…"
            className="w-full resize-none rounded-2xl bg-paper p-4 text-[14px] font-medium text-ink outline-none ring-1 ring-ink/10 placeholder:text-muted/70 focus:ring-ink/30"
          />
          <div className="mt-3 flex gap-2.5">
            <button
              onClick={() => setWhyOpen(false)}
              className="flex-1 rounded-full py-3.5 text-[14px] font-semibold text-muted active:scale-95"
            >
              Skip
            </button>
            <button
              onClick={() => {
                act(() => submitFeedback(0, note || "Disliked today's look", `outfit:${outfitId}`));
                setWhyOpen(false);
                setNote("");
                toast("Heard — adjusting");
              }}
              className="flex-1 rounded-full bg-ink py-3.5 text-[14px] font-bold text-cream active:scale-95"
            >
              Send
            </button>
          </div>
        </div>
      </Sheet>
    </>
  );
}

function DockButton({
  label,
  active,
  activeClass,
  onClick,
  busy,
  children,
}: {
  label: string;
  active?: boolean;
  activeClass?: string;
  onClick: () => void;
  busy?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      disabled={busy}
      className={cn(
        "flex flex-1 flex-col items-center gap-1.5 rounded-[20px] py-3 ring-1 transition-all active:scale-[0.94]",
        active
          ? cn("ring-transparent", activeClass)
          : "bg-cream text-ink-2 ring-ink/[0.08]",
      )}
    >
      {children}
      <span className={cn("text-[10px] font-bold tracking-[0.06em]", active ? "opacity-90" : "text-muted")}>
        {label}
      </span>
    </button>
  );
}
