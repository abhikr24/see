"use client";

import { motion, useMotionValue, useTransform } from "framer-motion";
import { Archive, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef } from "react";
import type { ClothingItem } from "@/db/schema";
import { vibrate } from "@/lib/utils";
import { OutfitFlatLay } from "@/components/wardrobe/OutfitFlatLay";

/**
 * Today's hero look. Swipe right to save it, swipe left to pass — the card
 * carries real momentum and the overlays fade in with the drag.
 */
export function SwipeableLook({
  outfitId,
  items,
  onSave,
  onPass,
}: {
  outfitId: string;
  items: ClothingItem[];
  onSave: () => void;
  onPass: () => void;
}) {
  const router = useRouter();
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-220, 220], [-7, 7]);
  const saveOpacity = useTransform(x, [30, 120], [0, 1]);
  const passOpacity = useTransform(x, [-120, -30], [1, 0]);
  const dragged = useRef(false);

  return (
    <motion.div
      style={{ x, rotate }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.72}
      onDragStart={() => {
        dragged.current = true;
      }}
      onDragEnd={(_, info) => {
        const dx = info.offset.x;
        setTimeout(() => (dragged.current = false), 60);
        if (dx > 105) {
          vibrate([10, 30, 10]);
          onSave();
        } else if (dx < -105) {
          vibrate(10);
          onPass();
        }
      }}
      whileTap={{ scale: 0.985 }}
      onTap={() => {
        if (!dragged.current) router.push(`/outfit/${outfitId}`);
      }}
      className="relative cursor-grab touch-pan-y select-none rounded-[32px] active:cursor-grabbing"
    >
      <div className="relative overflow-hidden rounded-[32px] shadow-lift">
        <OutfitFlatLay items={items} />

        {/* swipe overlays */}
        <motion.div
          style={{ opacity: saveOpacity }}
          className="absolute inset-0 z-40 flex items-start bg-olive/85 p-6"
        >
          <span className="flex items-center gap-2 rounded-full bg-cream px-4 py-2 text-[13px] font-bold tracking-wide text-olive">
            <Archive className="h-4 w-4" strokeWidth={2.2} /> SAVE THIS LOOK
          </span>
        </motion.div>
        <motion.div
          style={{ opacity: passOpacity }}
          className="absolute inset-0 z-40 flex items-start justify-end bg-ink/80 p-6"
        >
          <span className="flex items-center gap-2 rounded-full bg-cream px-4 py-2 text-[13px] font-bold tracking-wide text-ink">
            NEXT ONE <X className="h-4 w-4" strokeWidth={2.2} />
          </span>
        </motion.div>

        {/* hint ticks */}
        <div className="pointer-events-none absolute inset-x-0 bottom-3 z-30 flex items-center justify-between px-5">
          <span className="micro-label text-ink/35">← pass</span>
          <span className="micro-label text-ink/35">save →</span>
        </div>
      </div>
    </motion.div>
  );
}
