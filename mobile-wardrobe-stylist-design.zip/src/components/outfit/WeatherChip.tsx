import {
  Cloud,
  CloudDrizzle,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  Sun,
  type LucideIcon,
} from "lucide-react";
import type { Weather } from "@/lib/weather";

const ICONS: Record<Weather["icon"], LucideIcon> = {
  sun: Sun,
  partly: CloudSun,
  cloud: Cloud,
  fog: CloudFog,
  drizzle: CloudDrizzle,
  rain: CloudRain,
  snow: CloudSnow,
  storm: CloudLightning,
};

export function WeatherChip({ weather, onClick }: { weather: Weather; onClick?: () => void }) {
  const Icon = ICONS[weather.icon];
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 rounded-full bg-cream py-1.5 pl-2.5 pr-3.5 ring-1 ring-ink/[0.08] shadow-soft active:scale-95 transition-transform"
    >
      <Icon className="h-3.5 w-3.5 text-bronze" strokeWidth={2} />
      <span className="text-[12.5px] font-bold tabular text-ink">{weather.tempC}°</span>
      <span className="text-[11.5px] font-medium text-muted">{weather.label}</span>
      {weather.source === "estimate" && <span className="h-1.5 w-1.5 rounded-full bg-bronze/70" />}
    </button>
  );
}

export function WeatherInlineIcon({ weather, className }: { weather: Weather; className?: string }) {
  const Icon = ICONS[weather.icon];
  return <Icon className={className} strokeWidth={1.8} />;
}
