import { Sparkle } from "lucide-react";

/** The stylist's reasoning — editorial numerals, one thought per line. */
export function WhyItWorks({ reasons }: { reasons: string[] }) {
  if (!reasons.length) return null;
  return (
    <section>
      <div className="mb-3 flex items-center gap-2">
        <Sparkle className="h-3.5 w-3.5 text-bronze" strokeWidth={2} />
        <span className="micro-label text-muted">Why it works</span>
      </div>
      <ul className="space-y-2.5">
        {reasons.map((r, i) => (
          <li key={i} className="flex items-baseline gap-3.5">
            <span className="font-display text-[13px] italic text-bronze">{String(i + 1).padStart(2, "0")}</span>
            <span className="text-[14.5px] leading-snug text-ink-2">{r}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
