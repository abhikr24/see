"use client";

import { useEffect, type ReactNode } from "react";
import { ToastProvider } from "@/components/ui/Toast";
import { InstallPrompt } from "@/components/shell/InstallPrompt";
import { Splash } from "@/components/shell/Splash";

/**
 * The device frame. On phones: full-bleed, edge-to-edge, safe-area aware.
 * On desktop: a presented mobile column — the app is phone-first by design.
 */
export function AppFrame({ children }: { children: ReactNode }) {
  useEffect(() => {
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);

  return (
    <div className="min-h-dvh w-full bg-paper md:flex md:items-center md:justify-center md:bg-[#14110c] md:py-8">
      {/* ambient stage typography for wide screens */}
      <div className="pointer-events-none fixed inset-0 hidden select-none md:block">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-[26vw] italic leading-none text-cream/[0.03]">
          Veste
        </div>
        <div className="micro-label absolute bottom-6 left-1/2 -translate-x-1/2 text-cream/30">
          Best experienced on your phone
        </div>
      </div>
      <div className="relative z-10 mx-auto flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-paper md:h-[min(920px,94dvh)] md:rounded-[44px] md:shadow-[0_80px_160px_-40px_rgba(0,0,0,0.7)] md:ring-1 md:ring-cream/15">
        <ToastProvider>
          <Splash />
          {children}
          <InstallPrompt />
        </ToastProvider>
      </div>
    </div>
  );
}
