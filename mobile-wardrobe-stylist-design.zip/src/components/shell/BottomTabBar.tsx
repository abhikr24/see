"use client";

import { motion } from "framer-motion";
import { Clock3, Plus, Shirt, Sparkle, UserRound } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn, vibrate } from "@/lib/utils";

const TABS = [
  { href: "/today", label: "Today", icon: Sparkle },
  { href: "/wardrobe", label: "Wardrobe", icon: Shirt },
  { href: "/add", label: "Add", icon: Plus, center: true },
  { href: "/history", label: "History", icon: Clock3 },
  { href: "/profile", label: "Profile", icon: UserRound },
];

const HIDDEN_ON = ["/outfit", "/feedback"];

export function BottomTabBar() {
  const pathname = usePathname();
  if (HIDDEN_ON.some((p) => pathname.startsWith(p))) return null;

  return (
    <nav className="absolute inset-x-0 bottom-0 z-40">
      <div className="border-t border-line bg-cream/88 pb-[max(env(safe-area-inset-bottom),10px)] pt-2 shadow-bar backdrop-blur-xl">
        <div className="grid grid-cols-5 items-end">
          {TABS.map((tab) => {
            const active = pathname === tab.href || (tab.href !== "/today" && pathname.startsWith(tab.href));
            const Icon = tab.icon;
            if (tab.center) {
              return (
                <Link
                  key={tab.href}
                  href={tab.href}
                  onClick={() => vibrate(8)}
                  aria-label="Add clothing"
                  className="relative flex flex-col items-center justify-end pb-1"
                >
                  <motion.span
                    whileTap={{ scale: 0.88 }}
                    className={cn(
                      "flex h-[54px] w-[54px] -translate-y-4 items-center justify-center rounded-full shadow-lift transition-colors",
                      active ? "bg-bronze" : "bg-ink",
                    )}
                  >
                    <Icon className="h-6 w-6 text-cream" strokeWidth={2.2} />
                  </motion.span>
                </Link>
              );
            }
            return (
              <Link
                key={tab.href}
                href={tab.href}
                onClick={() => vibrate(6)}
                className="flex flex-col items-center gap-[3px] pb-1 pt-1.5"
              >
                <motion.span whileTap={{ scale: 0.82 }} className="relative flex flex-col items-center">
                  <Icon
                    className={cn("h-[22px] w-[22px] transition-colors", active ? "text-ink" : "text-muted")}
                    strokeWidth={active ? 2.3 : 1.8}
                  />
                </motion.span>
                <span
                  className={cn(
                    "text-[9.5px] font-semibold tracking-[0.08em] transition-colors",
                    active ? "text-ink" : "text-muted",
                  )}
                >
                  {tab.label}
                </span>
                <span className="relative h-1">
                  {active && (
                    <motion.span
                      layoutId="tab-dot"
                      className="absolute -left-0.5 top-0 h-1 w-1 rounded-full bg-bronze"
                      transition={{ type: "spring", stiffness: 500, damping: 34 }}
                    />
                  )}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
