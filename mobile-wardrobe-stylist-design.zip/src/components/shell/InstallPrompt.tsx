"use client";

import { Check, Plus, Share, Smartphone } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { vibrate } from "@/lib/utils";
import { Sheet } from "@/components/ui/Sheet";

type BIPEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

function isIOS() {
  if (typeof navigator === "undefined") return false;
  return /iphone|ipad|ipod/i.test(navigator.userAgent);
}

export function isInstalled(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

const DISMISS_KEY = "veste_a2hs_until";

export function InstallPrompt() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const deferred = useRef<BIPEvent | null>(null);
  const ios = useRef(false);

  useEffect(() => {
    ios.current = isIOS();
    const onBIP = (e: Event) => {
      e.preventDefault();
      deferred.current = e as BIPEvent;
    };
    const onManual = () => setOpen(true);
    window.addEventListener("beforeinstallprompt", onBIP);
    window.addEventListener("veste:install", onManual);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBIP);
      window.removeEventListener("veste:install", onManual);
    };
  }, []);

  // Auto-suggest once, only on Today, only if installable & not recently dismissed
  useEffect(() => {
    if (pathname !== "/today" || isInstalled()) return;
    const dismissedUntil = Number(localStorage.getItem(DISMISS_KEY) ?? 0);
    if (Date.now() < dismissedUntil) return;
    const t = setTimeout(() => {
      if (deferred.current || ios.current) setOpen(true);
    }, 5200);
    return () => clearTimeout(t);
  }, [pathname]);

  const dismiss = (days = 14) => {
    localStorage.setItem(DISMISS_KEY, String(Date.now() + days * 86400000));
    setOpen(false);
  };

  const install = async () => {
    vibrate(12);
    if (deferred.current) {
      await deferred.current.prompt();
      const choice = await deferred.current.userChoice;
      deferred.current = null;
      if (choice.outcome === "accepted") {
        localStorage.setItem(DISMISS_KEY, String(Date.now() + 365 * 86400000));
        setOpen(false);
        return;
      }
    }
    dismiss(14);
  };

  return (
    <Sheet open={open} onClose={() => dismiss(3)}>
      <div className="px-6 pb-2 pt-1">
        <div className="flex h-14 w-14 items-center justify-center rounded-[18px] bg-ink shadow-soft">
          <span className="font-display text-[26px] text-cream">V.</span>
        </div>
        <h3 className="mt-4 font-display text-[24px] leading-tight tracking-tight text-ink">
          Keep your stylist one tap away
        </h3>
        <p className="mt-1.5 text-[13.5px] leading-relaxed text-muted">
          Add Veste to your home screen — it opens full-screen, works offline, and never asks for an account.
        </p>
      </div>
      <div className="px-6 pb-4 pt-3">
        {ios.current && !deferred.current ? (
          <div className="space-y-3">
            {[
              { icon: Share, text: "Tap the Share button in Safari" },
              { icon: Plus, text: "Scroll and choose “Add to Home Screen”" },
              { icon: Check, text: "Tap Add — Veste appears on your home screen" },
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-3.5">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-paper ring-1 ring-ink/[0.08]">
                  <step.icon className="h-4.5 w-4.5 text-ink" strokeWidth={1.9} />
                </span>
                <span className="text-[13.5px] font-medium leading-snug text-ink-2">{step.text}</span>
              </div>
            ))}
          </div>
        ) : deferred.current ? (
          <button
            onClick={install}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-ink py-4 text-[15px] font-bold text-cream shadow-lift active:scale-[0.97]"
          >
            <Smartphone className="h-4.5 w-4.5" strokeWidth={2} />
            Add to Home Screen
          </button>
        ) : (
          <p className="rounded-2xl bg-paper px-4 py-3.5 text-[13px] leading-relaxed text-muted ring-1 ring-ink/[0.06]">
            Open your browser menu and choose <span className="font-semibold text-ink">“Add to Home Screen”</span> or <span className="font-semibold text-ink">“Install app”</span>.
          </p>
        )}
        <button
          onClick={() => dismiss(3)}
          className="mt-3 w-full py-2 text-center text-[13px] font-semibold text-muted active:scale-[0.97]"
        >
          Not now
        </button>
      </div>
    </Sheet>
  );
}
