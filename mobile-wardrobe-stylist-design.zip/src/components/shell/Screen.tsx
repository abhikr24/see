"use client";

import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * A screen = collapsing top bar + its own scroll column, sized to the app frame.
 * The bottom spacer reserves room for the floating tab bar.
 */
export function Screen({
  eyebrow,
  title,
  right,
  back,
  children,
  className,
  contentClassName,
  padForTab = true,
}: {
  eyebrow?: string;
  title?: ReactNode;
  right?: ReactNode;
  back?: boolean;
  children: ReactNode;
  className?: string;
  contentClassName?: string;
  padForTab?: boolean;
}) {
  const router = useRouter();
  const [hidden, setHidden] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const lastY = useRef(0);

  const onScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const y = e.currentTarget.scrollTop;
    setScrolled(y > 10);
    if (y > 72 && y > lastY.current + 4) setHidden(true);
    else if (y < lastY.current - 4 || y < 72) setHidden(false);
    lastY.current = y;
  };

  return (
    <div className={cn("flex h-full flex-col", className)}>
      {(title || eyebrow || right || back) && (
        <header
          className={cn(
            "safe-top z-30 shrink-0 transition-transform duration-300 ease-out",
            hidden ? "-translate-y-[110%]" : "translate-y-0",
            scrolled ? "border-b border-line bg-paper/85 backdrop-blur-xl" : "bg-transparent",
          )}
        >
          <div className="flex items-center gap-1 px-4 pt-3 pb-2.5">
            {back && (
              <button
                onClick={() => {
                  if (window.history.length > 1) router.back();
                  else router.push("/today");
                }}
                aria-label="Back"
                className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full active:scale-90"
              >
                <ChevronLeft className="h-[22px] w-[22px] text-ink" strokeWidth={2} />
              </button>
            )}
            <div className="min-w-0 flex-1">
              {eyebrow && <div className="micro-label text-muted">{eyebrow}</div>}
              {title && (
                <div className="truncate font-display text-[22px] leading-tight tracking-tight text-ink">
                  {title}
                </div>
              )}
            </div>
            {right}
          </div>
        </header>
      )}
      <div
        onScroll={onScroll}
        className={cn("no-scrollbar flex-1 overflow-y-auto overscroll-contain", contentClassName)}
      >
        {children}
        {padForTab && <div className="h-32" />}
      </div>
    </div>
  );
}
