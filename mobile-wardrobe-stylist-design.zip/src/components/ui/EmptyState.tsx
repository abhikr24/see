import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

/** Quiet, native-feeling empty state — big type, soft icon medallion. */
export function EmptyState({
  icon: Icon,
  title,
  body,
  children,
}: {
  icon: LucideIcon;
  title: string;
  body?: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center px-8 pb-16 pt-16 text-center">
      <div className="relative mb-6">
        <div className="flex h-24 w-24 items-center justify-center rounded-full bg-ink/[0.05]">
          <Icon className="h-9 w-9 text-ink/35" strokeWidth={1.4} />
        </div>
        <div className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-bronze/15" />
        <div className="absolute -bottom-1 -left-2 h-2.5 w-2.5 rounded-full bg-bronze/25" />
      </div>
      <h3 className="max-w-[260px] font-display text-[24px] leading-snug tracking-tight text-ink">{title}</h3>
      {body && <p className="mt-2 max-w-[270px] text-[13px] leading-relaxed text-muted">{body}</p>}
      {children && <div className="mt-7 flex flex-col items-center gap-3">{children}</div>}
    </div>
  );
}
