"use client";

import { AnimatePresence, motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Native-feeling bottom sheet with drag-to-dismiss and safe-area padding. */
export function Sheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  className,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="absolute inset-0 z-[70] bg-ink/45 backdrop-blur-[3px]"
          />
          <motion.div
            initial={{ y: "104%" }}
            animate={{ y: 0 }}
            exit={{ y: "104%" }}
            transition={{ type: "spring", stiffness: 380, damping: 38 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.55 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 110 || info.velocity.y > 600) onClose();
            }}
            className={cn(
              "absolute inset-x-0 bottom-0 z-[75] flex max-h-[88%] flex-col overflow-hidden rounded-t-[28px] bg-cream shadow-lift",
              className,
            )}
          >
            <div className="flex justify-center pb-1 pt-2.5">
              <div className="h-1.5 w-11 rounded-full bg-ink/15" />
            </div>
            {(title || subtitle) && (
              <div className="px-6 pb-2 pt-1">
                {title && <h3 className="font-display text-[22px] tracking-tight text-ink">{title}</h3>}
                {subtitle && <p className="mt-0.5 text-[13px] leading-snug text-muted">{subtitle}</p>}
              </div>
            )}
            <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto pb-[max(env(safe-area-inset-bottom),20px)]">
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
