export function TodaySkeleton() {
  return (
    <div className="px-5 pt-2">
      <div className="skeleton h-3 w-24 rounded-full" />
      <div className="skeleton mt-3 h-8 w-56 rounded-xl" />
      <div className="mt-3 flex gap-2">
        <div className="skeleton h-8 w-28 rounded-full" />
        <div className="skeleton h-8 w-32 rounded-full" />
      </div>
      <div className="skeleton mt-5 aspect-[4/5] w-full rounded-[28px]" />
      <div className="skeleton mt-5 h-3 w-20 rounded-full" />
      <div className="skeleton mt-3 h-4 w-full rounded-full" />
      <div className="skeleton mt-2 h-4 w-4/5 rounded-full" />
      <div className="skeleton mt-2 h-4 w-3/5 rounded-full" />
      <div className="skeleton mt-6 h-14 w-full rounded-full" />
    </div>
  );
}

export function GridSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-3 px-5 pt-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i}>
          <div className="skeleton aspect-[5/5.4] w-full rounded-[22px]" />
          <div className="skeleton mt-2.5 h-3 w-3/4 rounded-full" />
        </div>
      ))}
    </div>
  );
}

export function RowsSkeleton() {
  return (
    <div className="space-y-4 px-5 pt-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="flex gap-4">
          <div className="skeleton h-24 w-24 shrink-0 rounded-[20px]" />
          <div className="flex-1 space-y-2.5 py-2">
            <div className="skeleton h-3 w-16 rounded-full" />
            <div className="skeleton h-4 w-full rounded-full" />
            <div className="skeleton h-3 w-2/3 rounded-full" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ProfileSkeleton() {
  return (
    <div className="px-5 pt-3">
      <div className="flex items-center gap-4">
        <div className="skeleton h-16 w-16 rounded-full" />
        <div className="space-y-2">
          <div className="skeleton h-5 w-32 rounded-full" />
          <div className="skeleton h-3 w-44 rounded-full" />
        </div>
      </div>
      <div className="mt-6 grid grid-cols-3 gap-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="skeleton h-20 rounded-2xl" />
        ))}
      </div>
      <div className="skeleton mt-6 h-40 rounded-[24px]" />
      <div className="skeleton mt-4 h-14 rounded-2xl" />
      <div className="skeleton mt-3 h-14 rounded-2xl" />
    </div>
  );
}
