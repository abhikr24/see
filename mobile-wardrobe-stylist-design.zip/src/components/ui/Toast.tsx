"use client";

import { AnimatePresence, motion } from "framer-motion";
import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";

type ToastOpts = { action?: { label: string; onClick: () => void } };
type ToastCtx = { toast: (msg: string, opts?: ToastOpts) => void };

const Ctx = createContext<ToastCtx>({ toast: () => {} });
export const useToast = () => useContext(Ctx);

type Live = { id: number; msg: string; action?: ToastOpts["action"] };

export function ToastProvider({ children }: { children: ReactNode }) {
  const [live, setLive] = useState<Live | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const toast = useCallback((msg: string, opts?: ToastOpts) => {
    if (timer.current) clearTimeout(timer.current);
    setLive({ id: Date.now(), msg, action: opts?.action });
    timer.current = setTimeout(() => setLive(null), 2600);
  }, []);

  return (
    <Ctx.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none absolute inset-x-0 bottom-28 z-[90] flex justify-center px-6">
        <AnimatePresence>
          {live && (
            <motion.div
              key={live.id}
              initial={{ opacity: 0, y: 16, scale: 0.94 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 8, scale: 0.96 }}
              transition={{ type: "spring", stiffness: 420, damping: 30 }}
              className="pointer-events-auto flex items-center gap-3 rounded-full bg-ink py-2.5 pl-5 pr-2.5 text-[13px] font-medium text-cream shadow-lift"
            >
              <span className="max-w-[220px] leading-snug">{live.msg}</span>
              {live.action && (
                <button
                  onClick={() => {
                    live.action?.onClick();
                    setLive(null);
                  }}
                  className="rounded-full bg-cream/15 px-3.5 py-1.5 text-[12px] font-semibold text-cream active:scale-95"
                >
                  {live.action.label}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  );
}
