/**
 * GarmentArt — a cohesive, hand-drawn-feeling SVG wardrobe. Every garment is a
 * clean silhouette tinted in its real colour with tonal shading + stitch detail.
 * This makes a closet of mixed items read like one curated archive.
 */
import { isDark, shade } from "@/lib/palette";

type Tones = { b: string; d: string; l: string; stitch: string };

type ArtProps = { art: string; hex: string; className?: string };

function teeBody(b: string, d: string, _l: string, stitch: string) {
  return (
    <g>
      <path
        d="M41 34 L49 27 Q60 35 71 27 L79 34 L91 45 L82.5 56 L78 49.5 L78 90 Q78 94 74 94 L46 94 Q42 94 42 90 L42 49.5 L37.5 56 L29 45 Z"
        fill={b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M49 27 Q60 38 71 27 Q60 33 49 27 Z" fill={d} />
      <path d="M44 88 L76 88" stroke={stitch} strokeWidth={1.4} strokeDasharray="3 3" />
      <path d="M42 49.5 L37.5 56 M78 49.5 L82.5 56" stroke={d} strokeWidth={1.2} opacity={0.6} />
    </g>
  );
}

function shirtBody(b: string, d: string, l: string, stitch: string) {
  return (
    <g>
      <path
        d="M42 32 L51 26 L60 31 L69 26 L78 32 L88 44 L80 54 L76.5 47 L76.5 92 Q76.5 96 72.5 96 L47.5 96 Q43.5 96 43.5 92 L43.5 47 L40 54 L32 44 Z"
        fill={b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M51 26 L60 31 L54.5 38 L48 30 Z" fill={l} stroke={d} strokeWidth={0.8} />
      <path d="M69 26 L60 31 L65.5 38 L72 30 Z" fill={l} stroke={d} strokeWidth={0.8} />
      <path d="M60 34 L60 94" stroke={d} strokeWidth={1.4} opacity={0.5} />
      <circle cx="60" cy="46" r="1.6" fill={d} />
      <circle cx="60" cy="58" r="1.6" fill={d} />
      <circle cx="60" cy="70" r="1.6" fill={d} />
      <path d="M45.5 90 L74.5 90" stroke={stitch} strokeWidth={1.2} strokeDasharray="3 3" />
    </g>
  );
}

const ARTS: Record<string, (t: Tones) => React.ReactNode> = {
  tshirt: (t) => teeBody(t.b, t.d, t.l, t.stitch),
  shirt: (t) => shirtBody(t.b, t.d, t.l, t.stitch),
  polo: (t) => (
    <g>
      {teeBody(t.b, t.d, t.l, t.stitch)}
      <path d="M51 26 L60 33 L54 39 L47.5 29 Z" fill={t.l} stroke={t.d} strokeWidth={0.8} />
      <path d="M69 26 L60 33 L66 39 L72.5 29 Z" fill={t.l} stroke={t.d} strokeWidth={0.8} />
      <path d="M60 34 L60 44" stroke={t.d} strokeWidth={1.6} />
      <circle cx="60" cy="40" r="1.4" fill={t.d} />
    </g>
  ),
  blouse: (t) => (
    <g>
      <path
        d="M43 34 L50 27 Q60 34 70 27 L77 34 L86 43 L78 53 L75 47 L75 86 Q75 90 71 90 L49 90 Q45 90 45 86 L45 47 L42 53 L34 43 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M52 27 Q60 42 68 27 L60 58 Z" fill={t.d} opacity={0.55} />
      <path d="M56 34 Q60 44 64 34" fill="none" stroke={t.d} strokeWidth={1.2} />
      <path d="M47 84 L73 84" stroke={t.stitch} strokeWidth={1.2} strokeDasharray="3 3" />
    </g>
  ),
  knit: (t) => (
    <g>
      <path
        d="M40 36 L48 28 Q60 36 72 28 L80 36 L92 48 L83 59 L78.5 52 L78.5 88 L76 88 L76 95 L44 95 L44 88 L41.5 88 L41.5 52 L37 59 L28 48 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M44 90 L76 90 M44 92.5 L76 92.5 M44 95 L76 95" stroke={t.d} strokeWidth={1.1} />
      <path d="M48 28 Q60 38 72 28" fill="none" stroke={t.d} strokeWidth={2.4} strokeLinecap="round" />
      <path d="M52 44 Q60 50 68 44 M50 56 Q60 62 70 56 M50 68 Q60 74 70 68" stroke={t.stitch} strokeWidth={1.1} fill="none" />
    </g>
  ),
  turtleneck: (t) => (
    <g>
      <path d="M51 18 L69 18 L69 30 L51 30 Z" fill={t.d} />
      <path d="M51 21.5 L69 21.5 M51 25.5 L69 25.5" stroke={t.b} strokeWidth={1} opacity={0.5} />
      <path
        d="M41 38 L51 30 L69 30 L79 38 L91 50 L82 60 L78 53 L78 90 Q78 94 74 94 L46 94 Q42 94 42 90 L42 53 L38 60 L29 50 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M46 88 L74 88" stroke={t.stitch} strokeWidth={1.2} strokeDasharray="3 3" />
    </g>
  ),
  hoodie: (t) => (
    <g>
      <path d="M48 30 Q60 14 72 30 L70 36 Q60 28 50 36 Z" fill={t.d} />
      <path
        d="M40 38 L48 32 Q60 40 72 32 L80 38 L92 50 L83 61 L78.5 54 L78.5 88 L76 88 L76 94 L44 94 L44 88 L41.5 88 L41.5 54 L37 61 L28 50 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M50 74 L70 74 L72 88 L48 88 Z" fill={t.d} opacity={0.5} stroke={t.d} strokeWidth={1} />
      <path d="M55 38 L55 48 M65 38 L65 48" stroke={t.d} strokeWidth={1.5} strokeLinecap="round" />
      <path d="M44 91 L76 91" stroke={t.d} strokeWidth={1.1} />
    </g>
  ),
  tank: (t) => (
    <g>
      <path
        d="M48 26 L52 26 L54 40 Q57 46 66 46 L66 26 L70 26 L72 42 L72 88 Q72 92 68 92 L52 92 Q48 92 48 88 L48 42 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M54 40 Q60 48 66 40" fill="none" stroke={t.d} strokeWidth={1.6} />
      <path d="M50 86 L70 86" stroke={t.stitch} strokeWidth={1.2} strokeDasharray="3 3" />
    </g>
  ),
  cardigan: (t) => (
    <g>
      <path
        d="M41 34 L49 27 Q60 35 71 27 L79 34 L91 45 L82.5 56 L78 49.5 L78 92 Q78 96 74 96 L46 96 Q42 96 42 92 L42 49.5 L37.5 56 L29 45 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M50 28 L60 55 L60 96 M70 28 L60 55" fill="none" stroke={t.d} strokeWidth={2} />
      <circle cx="60" cy="64" r="1.7" fill={t.d} />
      <circle cx="60" cy="74" r="1.7" fill={t.d} />
      <circle cx="60" cy="84" r="1.7" fill={t.d} />
      <path d="M46 92 L74 92" stroke={t.d} strokeWidth={1} />
    </g>
  ),
  jeans: (t) => (
    <g>
      <path
        d="M40 26 L80 26 L80 36 L76.5 96 Q76.5 99 73.5 99 L63 99 L60 52 L57 99 L46.5 99 Q43.5 99 43.5 96 L40 36 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M40 34 L80 34" stroke={t.d} strokeWidth={1.6} />
      <rect x="56.5" y="26" width="7" height="8" rx="1" fill={t.d} opacity={0.6} />
      <path d="M42 38 Q48 38 49 46 M78 38 Q72 38 71 46" fill="none" stroke={t.stitch} strokeWidth={1.4} />
      <path d="M46.5 94 L57 94 M63 94 L73.5 94" stroke={t.stitch} strokeWidth={1.3} strokeDasharray="3 3" />
      <path d="M60 34 L60 44" stroke={t.d} strokeWidth={1.2} />
    </g>
  ),
  trousers: (t) => (
    <g>
      <path
        d="M41 25 L79 25 L79 34 L75 97 Q75 100 72 100 L62.5 100 L60 54 L57.5 100 L47.5 100 Q44.5 100 44.5 97 L41 34 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M41 33 L79 33" stroke={t.d} strokeWidth={1.4} />
      <path d="M52 38 L49 96 M68 38 L71 96" stroke={t.d} strokeWidth={1} opacity={0.55} />
      <path d="M47.5 96 L57.5 96 M62.5 96 L72 96" stroke={t.stitch} strokeWidth={1.2} strokeDasharray="3 3" />
    </g>
  ),
  shorts: (t) => (
    <g>
      <path
        d="M41 30 L79 30 L79 39 L76 68 Q76 71 73 71 L62 71 L60 52 L58 71 L47 71 Q44 71 44 68 L41 39 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M41 38 L79 38" stroke={t.d} strokeWidth={1.5} />
      <path d="M45 66 L57 66 M63 66 L75 66" stroke={t.stitch} strokeWidth={1.3} strokeDasharray="3 3" />
      <path d="M43 42 Q49 42 50 49 M77 42 Q71 42 70 49" fill="none" stroke={t.stitch} strokeWidth={1.3} />
    </g>
  ),
  skirt: (t) => (
    <g>
      <path
        d="M46 28 L74 28 L74 34 L86 88 Q87 92 83 92 L37 92 Q33 92 34 88 L46 34 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M46 33 L74 33" stroke={t.d} strokeWidth={1.6} />
      <path d="M53 36 L47 88 M67 36 L73 88 M60 36 L60 88" stroke={t.d} strokeWidth={0.9} opacity={0.4} />
    </g>
  ),
  sneakers: (t) => (
    <g>
      <path
        d="M26 78 Q26 70 34 68 L52 62 Q66 58 74 64 L90 72 Q96 74 96 80 L96 84 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M24 84 L98 84 Q99 84 99 86 Q99 92 93 92 L29 92 Q23 92 23 87 Q23 84 24 84 Z" fill={t.l} stroke="#191510" strokeOpacity={0.12} strokeWidth={1} />
      <path d="M92 84 L92 92" stroke="#191510" strokeOpacity={0.12} strokeWidth={1} />
      <path d="M56 62 L54 56 M64 61 L62 55" stroke={t.d} strokeWidth={1.3} opacity={0} />
      <path d="M52 66 Q60 62 66 66 M48 70 Q57 65 64 69" fill="none" stroke={t.d} strokeWidth={1.5} strokeLinecap="round" />
      <path d="M34 70 Q30 74 30 80" fill="none" stroke={t.d} strokeWidth={1.4} opacity={0.6} />
    </g>
  ),
  boots: (t) => (
    <g>
      <path
        d="M40 30 L62 30 L62 62 L88 72 Q95 74 95 81 L95 84 L38 84 Q34 84 34 80 L38 34 Q38 30 40 30 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M33 84 L96 84 L96 88 Q96 92 91 92 L46 92 L46 95 L37 95 Q33 95 33 91 Z" fill={t.d} />
      <path d="M38 36 L62 36 M38 44 L62 44" stroke={t.d} strokeWidth={1.2} opacity={0.5} />
      <path d="M62 56 L62 74" stroke={t.d} strokeWidth={1.3} opacity={0.6} />
    </g>
  ),
  loafers: (t) => (
    <g>
      <path
        d="M28 74 Q28 67 36 65 L58 60 Q70 58 78 63 L92 70 Q97 72 97 78 L97 82 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.09}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M26 82 L99 82 Q100 82 100 84 L99 88 Q98 90 94 90 L30 90 Q25 90 24 86 Q24 82 26 82 Z" fill={t.d} />
      <path d="M54 64 Q62 61 70 64 L68 70 Q61 67 55 70 Z" fill={t.d} opacity={0.65} />
      <path d="M36 67 Q33 71 33 76" fill="none" stroke={t.d} strokeWidth={1.3} opacity={0.6} />
    </g>
  ),
  heels: (t) => (
    <g>
      <path d="M30 66 Q42 58 56 66 Q72 74 88 76 Q94 77 94 82 L94 84 L62 84 L58 92 L54 92 L56 84 L32 84 Q27 84 27 79 Q27 70 30 66 Z" fill={t.b} stroke="#191510" strokeOpacity={0.09} strokeWidth={1} strokeLinejoin="round" />
      <path d="M27 84 L94 84 L94 87 Q94 89 91 89 L68 89 L66 84 L58 84 L56 92 L52 92 L54 84 L30 84 Z" fill={t.d} opacity={0.85} />
      <path d="M36 66 Q50 60 60 68" fill="none" stroke={t.d} strokeWidth={1.4} opacity={0.6} />
    </g>
  ),
  sandals: (t) => (
    <g>
      <path d="M28 84 Q26 92 34 92 L90 92 Q97 92 95 84 Q94 78 86 78 L36 78 Q29 78 28 84 Z" fill={t.d} />
      <path d="M34 78 Q40 66 52 66 L54 70 Q45 71 42 78 Z" fill={t.b} stroke="#191510" strokeOpacity={0.08} strokeWidth={1} />
      <path d="M58 78 Q62 68 74 68 L75 72 Q67 72 65 78 Z" fill={t.b} stroke="#191510" strokeOpacity={0.08} strokeWidth={1} />
      <circle cx="53" cy="68" r="2" fill={t.d} />
    </g>
  ),
  jacket: (t) => (
    <g>
      <path
        d="M39 34 L48 26 L60 30 L72 26 L81 34 L92 45 L83.5 57 L79 50 L79 84 L45 84 L41 84 L41 50 L36.5 57 L28 45 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.1}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M45 84 L75 84 M45 87.5 L75 87.5 M45 91 L75 91" stroke={t.d} strokeWidth={1.5} />
      <path d="M41.5 84 L78.5 84 L78.5 94 L41.5 94 Z" fill={t.d} opacity={0.35} />
      <path d="M60 30 L60 84" stroke={t.d} strokeWidth={1.8} />
      <path d="M48 26 L60 30 L54 37 Z M72 26 L60 30 L66 37 Z" fill={t.d} opacity={0.8} />
      <path d="M47 62 L47 72 M73 62 L73 72" stroke={t.d} strokeWidth={1.5} opacity={0.7} />
    </g>
  ),
  blazer: (t) => (
    <g>
      <path
        d="M40 32 L49 25 L60 30 L71 25 L80 32 L90 43 L82 54 L78 47 L78 94 Q78 97 75 97 L45 97 Q42 97 42 94 L42 47 L38 54 L30 43 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.1}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M49 25 L60 30 L52 62 L44 40 Z" fill={t.l} stroke={t.d} strokeWidth={1} />
      <path d="M71 25 L60 30 L68 62 L76 40 Z" fill={t.l} stroke={t.d} strokeWidth={1} />
      <circle cx="64" cy="72" r="2" fill={t.d} />
      <path d="M45 84 L52 84 M68 84 L75 84" stroke={t.d} strokeWidth={1.4} opacity={0.6} />
      <path d="M60 30 L60 40" stroke={t.d} strokeWidth={1.2} />
    </g>
  ),
  coat: (t) => (
    <g>
      <path
        d="M39 32 L48 24 L60 29 L72 24 L81 32 L91 43 L83 55 L79 48 L79 102 Q79 105 76 105 L44 105 Q41 105 41 102 L41 48 L37 55 L29 43 Z"
        fill={t.b}
        stroke="#191510"
        strokeOpacity={0.1}
        strokeWidth={1}
        strokeLinejoin="round"
      />
      <path d="M48 24 L60 29 L53 50 L45 34 Z M72 24 L60 29 L67 50 L75 34 Z" fill={t.d} opacity={0.75} />
      <path d="M60 29 L60 104" stroke={t.d} strokeWidth={1.5} opacity={0.55} />
      <circle cx="65" cy="60" r="1.8" fill={t.d} />
      <circle cx="65" cy="70" r="1.8" fill={t.d} />
      <path d="M46 78 L52 78 M68 78 L74 78" stroke={t.d} strokeWidth={1.5} opacity={0.6} />
      <path d="M42 72 L78 72" stroke={t.d} strokeWidth={1} opacity={0.35} />
    </g>
  ),
  watch: (t) => (
    <g>
      <path d="M52 22 L68 22 L66 42 L54 42 Z M54 78 L66 78 L68 98 L52 98 Z" fill={t.d} />
      <circle cx="60" cy="60" r="21" fill={t.b} stroke="#191510" strokeOpacity={0.12} strokeWidth={1.2} />
      <circle cx="60" cy="60" r="16.5" fill={t.l} />
      <path d="M60 50 L60 60 L67 64" stroke={isDark(t.l) ? "#faf8f2" : "#191510"} strokeWidth={2} strokeLinecap="round" fill="none" opacity={0.8} />
      <rect x="80" y="56" width="5" height="8" rx="2" fill={t.d} />
    </g>
  ),
  belt: (t) => (
    <g>
      <path d="M22 54 L98 54 Q100 54 100 58 L100 62 Q100 66 98 66 L22 66 Q20 66 20 62 L20 58 Q20 54 22 54 Z" fill={t.b} stroke="#191510" strokeOpacity="0.1" strokeWidth={1} />
      <rect x="30" y="50" width="16" height="20" rx="3" fill="none" stroke={t.d} strokeWidth={3.4} />
      <path d="M46 60 L68 60" stroke={t.d} strokeWidth={2.4} />
      <circle cx="76" cy="60" r="1.8" fill={t.d} />
      <circle cx="86" cy="60" r="1.8" fill={t.d} />
      <path d="M22 57 L22 63 M98 57 L98 63" stroke={t.stitch} strokeWidth={1.2} strokeDasharray="2 3" />
    </g>
  ),
  scarf: (t) => (
    <g>
      <path d="M42 30 Q60 22 78 30 L82 44 Q60 52 38 44 Z" fill={t.b} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} />
      <path d="M50 46 L46 88 Q46 92 50 92 L58 92 Q61 92 61 88 L64 48 Z" fill={t.b} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} />
      <path d="M64 46 L72 80 Q73 84 69 85 L62 86 Z" fill={t.d} opacity={0.7} />
      <path d="M47 84 L60 84 M47.5 88 L59.5 88" stroke={t.d} strokeWidth={1.2} />
      <path d="M44 34 Q60 28 76 34" fill="none" stroke={t.d} strokeWidth={1.3} opacity={0.6} />
    </g>
  ),
  bag: (t) => (
    <g>
      <path d="M48 46 Q48 30 60 30 Q72 30 72 46" fill="none" stroke={t.d} strokeWidth={3.2} strokeLinecap="round" />
      <path d="M34 46 L86 46 L90 94 Q90.5 98 86 98 L34 98 Q29.5 98 30 94 Z" fill={t.b} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} strokeLinejoin="round" />
      <path d="M34 56 L88 56" stroke={t.d} strokeWidth={1.4} opacity={0.5} />
      <circle cx="48" cy="46" r="2.4" fill={t.d} />
      <circle cx="72" cy="46" r="2.4" fill={t.d} />
      <path d="M40 92 L80 92" stroke={t.stitch} strokeWidth={1.3} strokeDasharray="3 3" />
    </g>
  ),
  cap: (t) => (
    <g>
      <path d="M36 66 Q36 42 60 42 Q84 42 84 66 Z" fill={t.b} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} />
      <path d="M32 66 L88 66 Q98 66 102 72 L100 75 Q80 71 60 71 Q44 71 28 74 Z" fill={t.d} />
      <path d="M60 42 L60 66 M47 44 Q44 54 44 66 M73 44 Q76 54 76 66" stroke={t.d} strokeWidth={1.1} opacity={0.55} />
      <circle cx="60" cy="40" r="2.6" fill={t.d} />
    </g>
  ),
  beanie: (t) => (
    <g>
      <path d="M38 66 Q38 38 60 38 Q82 38 82 66 Z" fill={t.b} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} />
      <rect x="36" y="64" width="48" height="14" rx="6" fill={t.d} opacity={0.85} />
      <path d="M42 66 L42 76 M50 66 L50 76 M58 66 L58 76 M66 66 L66 76 M74 66 L74 76" stroke={t.b} strokeWidth={1.4} opacity={0.7} />
      <circle cx="60" cy="34" r="6.5" fill={t.d} />
    </g>
  ),
  sunglasses: (t) => (
    <g>
      <rect x="30" y="52" width="24" height="20" rx="9" fill={t.b} stroke="#191510" strokeOpacity={0.15} strokeWidth={1} />
      <rect x="66" y="52" width="24" height="20" rx="9" fill={t.b} stroke="#191510" strokeOpacity={0.15} strokeWidth={1} />
      <path d="M54 58 Q60 54 66 58" fill="none" stroke={t.d} strokeWidth={2.6} />
      <path d="M30 56 L20 50 M90 56 L100 50" stroke={t.d} strokeWidth={2.6} strokeLinecap="round" />
      <path d="M35 56 L47 66 M71 56 L83 66" stroke={t.l} strokeWidth={2.4} opacity={0.7} strokeLinecap="round" />
    </g>
  ),
  necklace: (t) => (
    <g>
      <path d="M42 30 Q42 62 60 70 Q78 62 78 30" fill="none" stroke={t.b} strokeWidth={2.6} strokeLinecap="round" />
      <path d="M60 70 L60 78" stroke={t.b} strokeWidth={2.2} />
      <path d="M60 78 L66 86 L60 94 L54 86 Z" fill={t.b} stroke="#191510" strokeOpacity={0.12} strokeWidth={1} />
      <circle cx="42" cy="30" r="2" fill={t.d} />
      <circle cx="78" cy="30" r="2" fill={t.d} />
    </g>
  ),
  folded: (t) => (
    <g>
      <rect x="36" y="40" width="48" height="14" rx="4" fill={t.d} opacity={0.9} />
      <rect x="34" y="56" width="52" height="14" rx="4" fill={t.b} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} />
      <rect x="36" y="72" width="48" height="14" rx="4" fill={t.l} stroke="#191510" strokeOpacity={0.1} strokeWidth={1} />
    </g>
  ),
};

export function GarmentArt({ art, hex, className }: ArtProps) {
  const tones: Tones = {
    b: hex,
    d: shade(hex, -0.22),
    l: shade(hex, 0.2),
    stitch: isDark(hex) ? "rgba(255,255,255,0.35)" : "rgba(25,21,16,0.25)",
  };
  const draw = ARTS[art] ?? ARTS.folded;
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true">
      <ellipse cx="60" cy="101" rx="34" ry="5.5" fill="#191510" opacity="0.07" />
      {draw(tones)}
    </svg>
  );
}
