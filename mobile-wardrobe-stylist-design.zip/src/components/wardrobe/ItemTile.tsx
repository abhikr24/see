"use client";

import { Heart } from "lucide-react";
import { motion } from "framer-motion";
import type { ClothingItem } from "@/db/schema";
import { colorById } from "@/lib/palette";
import { SUBCATEGORIES } from "@/lib/presets";
import { cn } from "@/lib/utils";
import { GarmentThumb } from "./GarmentThumb";

export function ItemTile({
  item,
  onClick,
  index = 0,
}: {
  item: ClothingItem;
  onClick?: () => void;
  index?: number;
}) {
  const colour = colorById(item.colors[0]);
  return (
    <motion.button
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index, 10) * 0.035, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      whileTap={{ scale: 0.965 }}
      onClick={onClick}
      className="group flex flex-col overflow-hidden rounded-[22px] bg-cream text-left ring-1 ring-ink/[0.05] transition-shadow active:shadow-none"
    >
      <div className="relative aspect-[5/5.4] w-full overflow-hidden">
        {item.imageUrl ? (
          <GarmentThumb item={item} className="absolute inset-0" padded={false} />
        ) : (
          <div className="absolute inset-0 bg-[linear-gradient(160deg,#fbf8f1,#f1ebdd)]">
            <GarmentThumb item={item} className="absolute inset-0" />
          </div>
        )}
        {item.favorite && (
          <span className="absolute right-2.5 top-2.5 flex h-6 w-6 items-center justify-center rounded-full bg-cream/90 backdrop-blur">
            <Heart className="h-3 w-3 fill-bronze text-bronze" />
          </span>
        )}
      </div>
      <div className="flex items-center gap-1.5 px-3.5 pb-3 pt-2.5">
        <span
          className="h-2 w-2 shrink-0 rounded-full ring-1 ring-ink/10"
          style={{ backgroundColor: colour.hex }}
        />
        <div className="min-w-0">
          <div className="truncate text-[12.5px] font-semibold leading-tight text-ink">{item.name}</div>
          <div className="truncate text-[10.5px] leading-tight text-muted">
            {SUBCATEGORIES[item.subcategory]?.label ?? item.subcategory}
            {item.timesWorn > 0 && (
              <span className="text-muted/70"> · worn {item.timesWorn}×</span>
            )}
          </div>
        </div>
      </div>
    </motion.button>
  );
}
