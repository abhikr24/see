import type { ClothingItem } from "@/db/schema";
import { cn } from "@/lib/utils";
import { GarmentThumb } from "./GarmentThumb";

/**
 * Editorial flat-lay — composes the garments of an outfit like a stylist's
 * moodboard card: layered, slightly rotated, softly shadowed.
 */
export function OutfitFlatLay({
  items,
  variant = "hero",
  className,
}: {
  items: ClothingItem[];
  variant?: "hero" | "mini";
  className?: string;
}) {
  const by = (cat: string) => items.find((i) => i.category === cat);
  const outer = by("outerwear");
  const top = by("top");
  const bottom = by("bottom");
  const footwear = by("footwear");
  const accessory = by("accessory");

  const mini = variant === "mini";

  const piece = (
    item: ClothingItem | undefined,
    pos: string,
    rotate: string,
    z: string,
  ) => {
    if (!item) return null;
    return (
      <div className={cn("absolute", pos, rotate, z)}>
        <div className={cn("relative overflow-hidden bg-cream ring-1 ring-ink/[0.06]", mini ? "rounded-xl" : "rounded-[20px]")}
             style={{ boxShadow: "0 14px 28px -14px rgba(25,21,16,0.30)" }}>
          <GarmentThumb item={item} className="aspect-square w-full" />
        </div>
      </div>
    );
  };

  if (mini) {
    return (
      <div className={cn("relative aspect-square w-full overflow-hidden rounded-[22px] bg-[linear-gradient(155deg,#f3ede0,#ece4d3)]", className)}>
        {piece(outer, "left-[6%] top-[8%] w-[52%]", "-rotate-[3deg]", "z-10")}
        {piece(top, "right-[8%] top-[12%] w-[46%]", "rotate-[2deg]", "z-20")}
        {piece(bottom, "left-[10%] bottom-[8%] w-[44%]", "rotate-[2deg]", "z-20")}
        {piece(footwear, "right-[10%] bottom-[7%] w-[38%]", "-rotate-[2deg]", "z-30")}
        {piece(accessory, "right-[30%] top-[38%] w-[24%]", "rotate-[4deg]", "z-30")}
      </div>
    );
  }

  return (
    <div className={cn("relative aspect-[4/5] w-full overflow-hidden bg-[linear-gradient(165deg,#f6f1e5,#ebe2cf)]", className)}>
      {/* faint atelier gridline */}
      <div className="absolute inset-x-8 top-[38%] h-px bg-ink/[0.05]" />
      <div className="absolute inset-x-8 top-[70%] h-px bg-ink/[0.05]" />
      {piece(outer, "left-[5%] top-[5%] w-[56%]", "-rotate-[2.5deg]", "z-10")}
      {piece(top, outer ? "right-[7%] top-[10%] w-[52%]" : "left-[24%] top-[6%] w-[52%]", "rotate-[1.5deg]", "z-20")}
      {piece(bottom, "left-[9%] top-[44%] w-[46%]", "-rotate-[1deg]", "z-20")}
      {piece(footwear, "right-[9%] bottom-[5%] w-[42%]", "rotate-[1.8deg]", "z-30")}
      {piece(accessory, outer ? "right-[5%] top-[2%] w-[25%]" : "right-[6%] top-[7%] w-[25%]", "rotate-[3deg]", "z-30")}
    </div>
  );
}
