import { sql } from "drizzle-orm";
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

/** Single-row profile for the owner of the closet. */
export const profiles = pgTable("profiles", {
  id: integer("id").primaryKey().default(1),
  name: text("name").notNull().default("Avery"),
  styles: jsonb("styles").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  loveColors: jsonb("love_colors").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  avoidColors: jsonb("avoid_colors").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  occasions: jsonb("occasions").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  lastOccasion: text("last_occasion").notNull().default("daily"),
  city: text("city").notNull().default(""),
  lat: real("lat"),
  lon: real("lon"),
  onboarded: boolean("onboarded").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const clothingItems = pgTable("clothing_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  category: text("category").notNull(), // top | bottom | footwear | outerwear | accessory
  subcategory: text("subcategory").notNull(),
  colors: jsonb("colors").$type<string[]>().notNull().default(sql`'[]'::jsonb`), // palette ids
  pattern: text("pattern").notNull().default("solid"),
  formality: integer("formality").notNull().default(0), // 0 casual · 1 smart · 2 formal
  warmth: integer("warmth").notNull().default(1), // 0 light · 1 mid · 2 warm
  occasions: jsonb("occasions").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  favorite: boolean("favorite").notNull().default(false),
  timesWorn: integer("times_worn").notNull().default(0),
  lastWornAt: timestamp("last_worn_at", { withTimezone: true }),
  imageUrl: text("image_url"),
  source: text("source").notNull().default("capsule"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const outfits = pgTable("outfits", {
  id: uuid("id").primaryKey().defaultRandom(),
  date: text("date").notNull(), // YYYY-MM-DD
  occasion: text("occasion").notNull().default("daily"),
  tempC: integer("temp_c"),
  weatherLabel: text("weather_label"),
  weatherCode: integer("weather_code"),
  isMain: boolean("is_main").notNull().default(true),
  itemIds: jsonb("item_ids").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  reasons: jsonb("reasons").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  reaction: text("reaction"), // like | dislike | null
  savedAt: timestamp("saved_at", { withTimezone: true }),
  wornAt: timestamp("worn_at", { withTimezone: true }),
  dismissedAt: timestamp("dismissed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const wearLogs = pgTable("wear_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  itemId: uuid("item_id").notNull(),
  outfitId: uuid("outfit_id"),
  date: text("date").notNull(),
  wornAt: timestamp("worn_at", { withTimezone: true }).notNull().defaultNow(),
});

export const feedback = pgTable("feedback", {
  id: uuid("id").primaryKey().defaultRandom(),
  rating: integer("rating").notNull().default(0),
  note: text("note").notNull().default(""),
  context: text("context").notNull().default("app"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Profile = typeof profiles.$inferSelect;
export type ClothingItem = typeof clothingItems.$inferSelect;
export type Outfit = typeof outfits.$inferSelect;
export type WearLog = typeof wearLogs.$inferSelect;
