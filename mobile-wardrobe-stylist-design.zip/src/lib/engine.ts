/**
 * The stylist brain. Scores every garment for the day's context, then composes
 * a look the way a human stylist would: anchor piece first, then colour-check
 * every layer against it, then write down *why* it works.
 */
import type { ClothingItem, Profile } from "@/db/schema";
import { bestHarmonyPhrase, colorById, colourFit } from "./palette";
import { occasionFormality, occasionLabel, type Category } from "./presets";
import { daysSince } from "./utils";

export type StylistContext = {
  occasion: string;
  tempC: number | null;
  weatherCode?: number | null;
  profile: Profile;
  /** Items that just got dismissed/remixed — penalised so a remix feels new. */
  avoidIds?: string[];
  /** Lock specific slots to specific item ids (used by per-slot swap). */
  fixed?: Partial<Record<Category, string>>;
  /** Deterministic variation knob. */
  salt?: number;
};

export type BuiltOutfit = {
  items: ClothingItem[];
  reasons: string[];
  missing: Category[];
};

let seed = 42;
function rand() {
  // mulberry32 — small deterministic PRNG so a render stays stable per salt
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function tempNeed(tempC: number | null): number {
  if (tempC == null) return 1;
  if (tempC >= 27) return 0;
  if (tempC >= 21) return 0.4;
  if (tempC >= 15) return 1;
  if (tempC >= 8) return 1.6;
  return 2;
}

const WARMTH_WEIGHT: Record<Category, number> = {
  top: 1,
  outerwear: 1,
  bottom: 0.55,
  footwear: 0.45,
  accessory: 0.35,
};

function scoreItem(item: ClothingItem, ctx: StylistContext, need: number): number {
  const target = occasionFormality(ctx.occasion);
  const isGym = ctx.occasion === "gym";
  let s = 0;

  // Occasion alignment
  if (item.occasions.includes(ctx.occasion)) s += 3.2;
  else if (isGym) s -= 5;
  else if (item.occasions.length === 0) s += 0.4; // untagged = versatile

  // Formality alignment
  const diff = Math.abs(item.formality - target);
  s += 2 - diff * 1.35;
  if (target === 2 && item.formality === 0 && item.category !== "accessory") s -= 1.4;

  // Weather / warmth alignment
  const w = WARMTH_WEIGHT[(item.category as Category) ?? "top"] ?? 1;
  s += (2 - Math.abs(item.warmth - need)) * w;
  if (need <= 0.4 && item.warmth === 2 && item.category !== "accessory") s -= 1.6; // too hot for heavy knits

  // Taste profile
  if (item.colors.some((c) => ctx.profile.loveColors.includes(c))) s += 1.3;
  if (item.colors.some((c) => ctx.profile.avoidColors.includes(c))) s -= 6;

  // Rotation — reward pieces resting in the closet
  const d = daysSince(item.lastWornAt);
  if (d == null) s += 1.4;
  else s += Math.min(d, 16) / 16 * 1.7;

  if (item.favorite) s += 0.5;
  if (ctx.avoidIds?.includes(item.id)) s -= 8;

  // Stable pseudo-random jitter for variety across remixes
  const jitterSeed = item.id.charCodeAt(0) + item.id.charCodeAt(5) + (ctx.salt ?? 0) * 131;
  seed = jitterSeed;
  s += rand() * 1.1 - 0.4;

  return s;
}

function pick(
  candidates: ClothingItem[],
  ctx: StylistContext,
  need: number,
  anchored: string[],
): ClothingItem | null {
  let best: ClothingItem | null = null;
  let bestScore = -Infinity;
  for (const item of candidates) {
    let s = scoreItem(item, ctx, need);
    if (anchored.length) {
      const main = item.colors[0];
      s += colourFit(main, anchored) * 1.1;
      // Two loud patterns rarely work
      if (item.pattern !== "solid") s -= 0.3;
    }
    if (s > bestScore) {
      bestScore = s;
      best = item;
    }
  }
  return best;
}

export function buildOutfit(all: ClothingItem[], ctx: StylistContext): BuiltOutfit {
  const byCat = (c: Category) => all.filter((i) => i.category === c);
  const need = tempNeed(ctx.tempC);
  const target = occasionFormality(ctx.occasion);
  const chosen: ClothingItem[] = [];
  const missing: Category[] = [];
  const anchoredColours: string[] = [];

  const fixedItem = (c: Category): ClothingItem | null => {
    const id = ctx.fixed?.[c];
    return id ? all.find((i) => i.id === id) ?? null : null;
  };

  // 1 — anchor top
  const top = fixedItem("top") ?? pick(byCat("top"), ctx, need, []);
  if (!top) missing.push("top");
  else {
    chosen.push(top);
    anchoredColours.push(top.colors[0]);
  }

  // 2 — bottom, colour-checked against the top
  const bottom = fixedItem("bottom") ?? pick(byCat("bottom"), ctx, need / 2, anchoredColours);
  if (!bottom) missing.push("bottom");
  else {
    chosen.push(bottom);
    anchoredColours.push(bottom.colors[0]);
  }

  // 3 — footwear
  const shoePool = byCat("footwear");
  const footwear = fixedItem("footwear") ?? pick(shoePool, ctx, need / 2, anchoredColours);
  if (!footwear) missing.push("footwear");
  else {
    chosen.push(footwear);
    anchoredColours.push(footwear.colors[0]);
  }

  // 4 — outerwear when the weather or the dress code asks for it
  const wantsLayer =
    (ctx.tempC != null && ctx.tempC < 17) || target === 2 || (ctx.tempC != null && ctx.tempC < 21 && target === 1);
  const outerPool = ctx.tempC != null && ctx.tempC >= 24 ? [] : byCat("outerwear");
  if (wantsLayer && outerPool.length) {
    const outer = fixedItem("outerwear") ?? pick(outerPool, ctx, need, anchoredColours);
    if (outer) {
      chosen.push(outer);
      anchoredColours.push(outer.colors[0]);
    }
  }

  // 5 — one considered accessory
  const acc = fixedItem("accessory") ?? pick(byCat("accessory"), ctx, need, anchoredColours);
  if (acc) {
    const s = scoreItem(acc, ctx, need);
    if (target >= 1 || s > 2.6 || ctx.occasion === "festival") chosen.push(acc);
  }

  return { items: chosen, reasons: reason(chosen, ctx, need), missing };
}

/* ------------------------------------------------------------------ */
/* Reasoning — the "why it works" voice                                */
/* ------------------------------------------------------------------ */

const OCCASION_LINES: Record<string, string[]> = {
  daily: ["Low-effort pieces that still read intentional — the everyday sweet spot"],
  college: ["Built for long days: soft, durable, and easy to move in"],
  office: ["Sharp enough for the meeting, relaxed enough for the after-work plan"],
  interview: ["Structured pieces signal competence before you say a word"],
  date: ["One considered detail does the flirting for you"],
  wedding: ["Ceremony-ready without upstaging anyone"],
  party: ["After-dark energy — a little bolder than your usual"],
  family: ["Polished but warm — the relatives will approve"],
  travel: ["Soft layers that survive a long ride and still land well"],
  dinner: ["Quietly refined — evening lighting loves these tones"],
  gym: ["Breathable and movable — nothing here fights a workout"],
  festival: ["Expressive and easy — made for being out all day"],
};

function weatherLine(tempC: number, code: number | null | undefined, items: ClothingItem[]): string | null {
  const rainy = code != null && ((code >= 51 && code <= 67) || (code >= 80 && code <= 99));
  const names = items.map((i) => i.name.toLowerCase());
  if (rainy && code != null && code >= 95) return `${tempC}° with storms — sturdy layers, nothing precious`;
  if (rainy) return `${tempC}° and wet — covered shoes and an easy layer for the rain`;
  if (tempC >= 27) return `${tempC}° outside — breathable, light, nothing clinging`;
  if (tempC >= 21) return names.some((n) => n.includes("linen")) ? `${tempC}° and mild — linen earns its keep today` : `${tempC}° and mild — light layers, open collar`;
  if (tempC >= 15) return `${tempC}° — one good layer over a simple base`;
  if (tempC >= 8) return `${tempC}° — the knit and the coat get to work together`;
  return `${tempC}° out there — every layer here keeps the warmth in`;
}

function rotationLine(items: ClothingItem[]): string | null {
  let best: ClothingItem | null = null;
  let bestDays = -1;
  for (const i of items) {
    const d = daysSince(i.lastWornAt);
    if (d == null) {
      if (!best) best = i;
      bestDays = Math.max(bestDays, 999);
      continue;
    }
    if (d > bestDays && d >= 5) {
      bestDays = d;
      best = i;
    }
  }
  if (!best) return null;
  if (bestDays >= 999) return `The ${best.name.toLowerCase()} hasn't had its debut yet — today's the day`;
  return `It's been ${bestDays} days since the ${best.name.toLowerCase()} saw daylight — time to bring it back`;
}

function reason(items: ClothingItem[], ctx: StylistContext, need: number): string[] {
  const out: string[] = [];
  const colours = items.flatMap((i) => i.colors.slice(0, 1));
  const harmonyPhrase = bestHarmonyPhrase(colours);
  if (harmonyPhrase) out.push(harmonyPhrase);

  if (ctx.occasion.startsWith("custom:")) {
    out.push(`Dressed with “${occasionLabel(ctx.occasion)}” in mind — smart, flexible pieces`);
  } else {
    const lines = OCCASION_LINES[ctx.occasion];
    if (lines) out.push(lines[Math.floor(rand() * lines.length)]);
  }

  if (ctx.tempC != null) {
    const w = weatherLine(ctx.tempC, ctx.weatherCode, items);
    if (w) out.push(w);
  } else {
    const r = rotationLine(items);
    if (r) out.push(r);
  }

  if (out.length < 3) {
    const r = rotationLine(items);
    if (r) out.push(r);
  }
  if (out.length < 3 && ctx.profile.loveColors.length) {
    const loved = items.find((i) => i.colors.some((c) => ctx.profile.loveColors.includes(c)));
    if (loved) {
      out.push(
        `${colorById(loved.colors[0]).name} is one of your colours — it keeps the look unmistakably yours`,
      );
    }
  }
  return Array.from(new Set(out)).slice(0, 3);
}

/** Two alternative takes on the same day — force different anchors. */
export function buildAlternatives(
  all: ClothingItem[],
  ctx: StylistContext,
  main: BuiltOutfit,
): BuiltOutfit[] {
  const alts: BuiltOutfit[] = [];
  let avoid = main.items.map((i) => i.id);
  for (let n = 0; n < 2; n++) {
    const alt = buildOutfit(all, { ...ctx, avoidIds: avoid, salt: (ctx.salt ?? 0) + 7 + n * 13 });
    if (alt.items.length >= 3) alts.push(alt);
    avoid = [...avoid, ...alt.items.map((i) => i.id)];
  }
  return alts;
}
