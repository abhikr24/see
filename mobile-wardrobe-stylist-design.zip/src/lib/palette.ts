/**
 * The Veste color system — a curated wardrobe palette with a harmony matrix.
 * Every garment color in the app is one of these ids, which lets the stylist
 * reason about pairings like a human would.
 */

export type ColorFamily = "neutral" | "cool" | "warm" | "earth" | "jewel" | "pastel";

export type ColorDef = {
  id: string;
  name: string;
  hex: string;
  family: ColorFamily;
};

export const PALETTE: ColorDef[] = [
  { id: "black", name: "Ink Black", hex: "#1D1A16", family: "neutral" },
  { id: "charcoal", name: "Charcoal", hex: "#3B3833", family: "neutral" },
  { id: "slate", name: "Slate Grey", hex: "#716E67", family: "neutral" },
  { id: "stone", name: "Stone", hex: "#B3AFA2", family: "neutral" },
  { id: "ivory", name: "Ivory", hex: "#EFE9DC", family: "neutral" },
  { id: "white", name: "Crisp White", hex: "#FAFAF7", family: "neutral" },
  { id: "navy", name: "Midnight Navy", hex: "#26334C", family: "cool" },
  { id: "denim", name: "Washed Denim", hex: "#54708F", family: "cool" },
  { id: "sky", name: "Soft Sky", hex: "#A9C3D6", family: "cool" },
  { id: "steel", name: "Steel Blue", hex: "#6C7F8E", family: "cool" },
  { id: "forest", name: "Deep Forest", hex: "#33483B", family: "earth" },
  { id: "olive", name: "Olive", hex: "#6E7053", family: "earth" },
  { id: "sage", name: "Sage", hex: "#ABB49C", family: "earth" },
  { id: "camel", name: "Camel", hex: "#B8875A", family: "earth" },
  { id: "tan", name: "Warm Tan", hex: "#C9A579", family: "earth" },
  { id: "chocolate", name: "Chocolate", hex: "#5C4433", family: "earth" },
  { id: "rust", name: "Rust", hex: "#A9542E", family: "warm" },
  { id: "mustard", name: "Mustard", hex: "#C99A36", family: "warm" },
  { id: "blush", name: "Blush", hex: "#E2C0B2", family: "pastel" },
  { id: "lavender", name: "Lavender", hex: "#B3A6C9", family: "pastel" },
  { id: "burgundy", name: "Burgundy", hex: "#6E2C38", family: "jewel" },
  { id: "crimson", name: "Crimson", hex: "#9E2B38", family: "jewel" },
];

export const colorById = (id: string): ColorDef =>
  PALETTE.find((c) => c.id === id) ?? PALETTE[0];

/** Curated pairings with editorial phrasing, keyed by sorted ids. */
const PAIRS: Record<string, string> = {
  "camel|navy": "Navy and camel — the old-money pairing that never misses",
  "ivory|navy": "Crisp ivory against deep navy keeps it sharp without trying",
  "black|white": "Black and white — graphic, clean, impossible to get wrong",
  "black|camel": "Black grounds the camel so it reads luxe, not loud",
  "black|ivory": "Ivory softens the black — quiet contrast, very put-together",
  "denim|white": "Denim and white — the easiest form of looking considered",
  "chocolate|ivory": "Chocolate and cream — warm, tonal, and quietly expensive",
  "denim|rust": "Rust warms up the denim like late-afternoon light",
  "forest|ivory": "Forest green and cream — bookish in the best way",
  "burgundy|charcoal": "Burgundy with charcoal — moody but polished",
  "navy|white": "Navy and white is a classic for a reason — it always works",
  "black|burgundy": "Black lets the burgundy read rich instead of loud",
  "chocolate|denim": "Brown and blue — the most forgiving pairing in any closet",
  "olive|white": "Olive and white — utilitarian, but make it chic",
  "ivory|olive": "Olive with ivory is soft, earthy, and calm",
  "charcoal|white": "Charcoal over white — the minimalist's uniform",
  "camel|white": "Camel over white is peak quiet luxury",
  "charcoal|sky": "Soft sky lifts the charcoal — light meets structure",
  "blush|navy": "Blush against navy — soft, but with a spine",
  "mustard|navy": "A hit of mustard wakes the whole look up",
  "slate|white": "Grey and white — tonal, calm, effortless",
  "crimson|navy": "Crimson on navy — confident without shouting",
  "black|denim": "Black with denim — the off-duty uniform",
  "denim|ivory": "Washed denim and ivory — weekend, but considered",
  "camel|ivory": "Head-to-toe warm neutrals — tonal dressing at its best",
  "chocolate|tan": "Two shades of brown — tonal, rich, intentional",
  "forest|tan": "Forest and tan — heritage colours that belong together",
  "burgundy|white": "White keeps the burgundy feeling fresh, not heavy",
  "olive|tan": "Olive and tan — field-jacket energy, city polish",
};

export type Harmony = { score: number; phrase: string };

/** Score 0 (clash / boring) → 3 (perfect), with a stylist's phrase. */
export function harmony(aId: string, bId: string): Harmony {
  if (aId === bId) {
    return { score: 2, phrase: `Tonal ${colorById(aId).name.toLowerCase()} — one colour, done deliberately` };
  }
  const a = colorById(aId);
  const b = colorById(bId);
  const key = [aId, bId].sort().join("|");
  const known = PAIRS[key];
  if (known) return { score: 3, phrase: known };

  const aNeutral = a.family === "neutral";
  const bNeutral = b.family === "neutral";
  if (aNeutral && bNeutral) {
    return { score: 2, phrase: `Layered neutrals — ${a.name.toLowerCase()} meeting ${b.name.toLowerCase()}` };
  }
  if (aNeutral !== bNeutral) {
    const colour = aNeutral ? b : a;
    return {
      score: 2.5,
      phrase: `A neutral base lets the ${colour.name.toLowerCase()} do the talking`,
    };
  }
  if (a.family === b.family) {
    return { score: 2, phrase: `Tonal ${a.family} tones — cohesive from head to toe` };
  }
  const warmA = a.family === "warm" || a.family === "earth";
  const warmB = b.family === "warm" || b.family === "earth";
  if (warmA === warmB) return { score: 1.5, phrase: "" };
  return { score: 1.8, phrase: "" };
}

/** Best harmony phrase among the dominant colours of an outfit. */
export function bestHarmonyPhrase(colorIds: string[]): string {
  const uniq = Array.from(new Set(colorIds)).slice(0, 4);
  let best = { score: -1, phrase: "" };
  for (let i = 0; i < uniq.length; i++) {
    for (let j = i + 1; j < uniq.length; j++) {
      const h = harmony(uniq[i], uniq[j]);
      if (h.phrase && h.score > best.score) best = h;
    }
  }
  return best.phrase;
}

/** Aggregate compatibility of one colour against a set of colours. */
export function colourFit(candidate: string, existing: string[]): number {
  if (existing.includes(candidate)) return 2;
  let total = 0;
  for (const e of existing) total += harmony(candidate, e).score;
  return total / Math.max(1, existing.length);
}

/** Map an arbitrary hex (from camera analysis) to the nearest palette colour. */
export function nearestColour(hex: string): ColorDef {
  const target = hexToRgb(hex);
  let best = PALETTE[0];
  let bestDist = Infinity;
  for (const c of PALETTE) {
    const rgb = hexToRgb(c.hex);
    const d =
      (rgb.r - target.r) ** 2 + (rgb.g - target.g) ** 2 + (rgb.b - target.b) ** 2;
    if (d < bestDist) {
      bestDist = d;
      best = c;
    }
  }
  return best;
}

export function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const m = hex.replace("#", "");
  const v = parseInt(m.length === 3 ? m.split("").map((x) => x + x).join("") : m, 16);
  return { r: (v >> 16) & 255, g: (v >> 8) & 255, b: v & 255 };
}

/** Darken or lighten a hex by amount -1..1 — used for garment shading. */
export function shade(hex: string, amt: number): string {
  const { r, g, b } = hexToRgb(hex);
  const f = (v: number) =>
    Math.max(0, Math.min(255, Math.round(amt < 0 ? v * (1 + amt) : v + (255 - v) * amt)));
  return `#${((f(r) << 16) | (f(g) << 8) | f(b)).toString(16).padStart(6, "0")}`;
}

/** Relative luminance — to pick ink vs cream overlays on a colour. */
export function isDark(hex: string): boolean {
  const { r, g, b } = hexToRgb(hex);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.55;
}
