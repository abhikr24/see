/**
 * Weather via Open-Meteo (free, keyless) with a graceful seasonal fallback so
 * the stylist always has something sensible to say, even fully offline.
 */
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles, type Profile } from "@/db/schema";

export type Weather = {
  tempC: number;
  code: number;
  label: string;
  icon: "sun" | "partly" | "cloud" | "fog" | "drizzle" | "rain" | "snow" | "storm";
  source: "live" | "estimate";
};

export function describeCode(code: number): Pick<Weather, "label" | "icon"> {
  if (code === 0) return { label: "Clear", icon: "sun" };
  if (code === 1 || code === 2) return { label: "Partly cloudy", icon: "partly" };
  if (code === 3) return { label: "Overcast", icon: "cloud" };
  if (code === 45 || code === 48) return { label: "Foggy", icon: "fog" };
  if (code >= 51 && code <= 57) return { label: "Drizzle", icon: "drizzle" };
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return { label: "Rain", icon: "rain" };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { label: "Snow", icon: "snow" };
  if (code >= 95) return { label: "Storm", icon: "storm" };
  return { label: "Mild", icon: "partly" };
}

/** Seasonal estimate — northern hemisphere baseline, used when offline. */
function estimate(): Weather {
  const month = new Date().getMonth();
  const temps = [6, 8, 12, 17, 22, 26, 29, 28, 24, 18, 12, 7];
  const codes = [3, 3, 2, 2, 1, 1, 0, 1, 2, 2, 3, 3];
  const code = codes[month];
  return { tempC: temps[month], code, source: "estimate", ...describeCode(code) };
}

async function geocode(city: string): Promise<{ lat: number; lon: number } | null> {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`;
  const res = await fetch(url, { signal: AbortSignal.timeout(4000), cache: "no-store" });
  if (!res.ok) return null;
  const json = (await res.json()) as { results?: { latitude: number; longitude: number }[] };
  const hit = json.results?.[0];
  return hit ? { lat: hit.latitude, lon: hit.longitude } : null;
}

export async function getWeather(profile: Profile): Promise<Weather> {
  try {
    let lat = profile.lat;
    let lon = profile.lon;
    if ((lat == null || lon == null) && profile.city) {
      const geo = await geocode(profile.city);
      if (geo) {
        lat = geo.lat;
        lon = geo.lon;
        await db.update(profiles).set({ lat, lon }).where(eq(profiles.id, profile.id));
      }
    }
    if (lat == null || lon == null) return estimate();
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&timezone=auto`;
    const res = await fetch(url, { signal: AbortSignal.timeout(4500), cache: "no-store" });
    if (!res.ok) return estimate();
    const json = (await res.json()) as {
      current?: { temperature_2m?: number; weather_code?: number };
    };
    const temp = json.current?.temperature_2m;
    const code = json.current?.weather_code;
    if (temp == null || code == null) return estimate();
    return { tempC: Math.round(temp), code, source: "live", ...describeCode(code) };
  } catch {
    return estimate();
  }
}
