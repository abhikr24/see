# Changelog

All notable changes to FocusFlow are documented here. The format follows Keep a Changelog, and versions use semantic versioning.

## [2.1.0] - 2026-11-08

### Added

- System / English / Hindi language selection, with complete catalogues for Today, Planner, Focus, and Review.
- Per-day Week number and Place fields on Today.
- Independently completable five-minute breaks created after completed focus blocks, visible in day and week views.
- Google OAuth through `expo-auth-session` using the private `drive.appdata` scope, SecureStore refresh-token persistence, and automatic access-token refresh.
- Additional regression tests for localisation, daily metadata, break completion, and the unified streak.

### Changed

- Renamed the native app and slug to **FocusFlow** / **focusflow** and incremented Android `versionCode` and iOS `buildNumber` to 3.
- Unified Today, Insights, and reports on one **day streak**: a day counts when it has a completed block or a recorded focus session.
- Moved raw Google access-token entry behind an **Advanced (developer)** disclosure.
- Rewrote the README to match the implemented 24-hour grid, SQLite persistence, notifications, revision tools, backup/sync behavior, and verification commands.

### Removed

- Previous Expo owner, EAS project ID, and updates URL. A new project ID must be generated in the app owner’s own Expo account.

### Declined

- No Android home-screen widget is included: this managed source-only build cannot reliably ship and verify the required native `AppWidgetProvider`, so no imitation widget or placeholder was added.

## [2.0.0] - 2026-11-08

### Added

- Offline-first Today, Planner, Focus, Review, and Insights workflows.
- SQLite persistence with versioned migrations and legacy local-data import.
- Draggable 24-hour day/week time grid, recurring tasks, skipped occurrences, auto-placement, and quick add.
- Class timetable, subjects, exam topic checklists, and generated revision plans.
- Persistent Pomodoro state machine, focus sounds, strict mode, and parked distractions flowing into evening review.
- Notification channels, scheduled reminders, and start-break/snooze actions.
- Sentence-based insights, streak metrics, heatmaps, and shareable report images.
- JSON backup with restore preview, CSV export, optional Drive backup, and Supabase sync planning with conflict detection.
- Sixty-four passing Vitest tests and a clean strict TypeScript check.
