# FocusFlow

FocusFlow is an offline-first study planner for Android, iOS, and web, built with Expo SDK 57, React Native, and strict TypeScript. It combines the paper planner’s daily priorities and separate focus/break checkboxes with a full timetable, Pomodoro timer, reviews, revision planning, and local-first backups.

## What this build includes

- **Today** — a seven-day date strip, per-day **Week number** and **Place**, Top 3 priorities, the next scheduled block, daily focus progress, completed blocks, water tracking, exam countdown, evening-review shortcut, and the shared **day streak**.
- **Planner** — day, week, and list views; a draggable **24-hour time grid**; resize/move/create gestures; anytime blocks; conflict-aware auto-placement; priorities, notes, subjects, and per-occurrence completion; recurring study blocks with skipped dates.
- **Separate breaks** — completing a focus block creates its five-minute break as a distinct item. Focus and break completion can be ticked independently in the day list and week grid.
- **Class timetable** — recurring classes, term start/end dates, selected weekdays, and individual skipped or restored occurrences.
- **Quick add** — natural-language block creation with subject, duration, date, time, priority, and recurrence parsing.
- **Focus room** — an absolute-end-time Pomodoro timer, pause/resume/reset, early session saving, short/long breaks, cycles, linked tasks and subjects, persistent timer state, optional focus sounds, and strict-mode interruption tracking.
- **Notifications** — Android channels, focus/break/block reminders, lock-screen alerts, and notification actions for starting a break or snoozing.
- **Parked distractions** — capture thoughts during focus, group them in the evening review, and convert them into tomorrow’s tasks.
- **Daily review** — what worked, what to fix, gratitude, quick notes, distraction notes, mood, energy, productivity, water, sleep, steps, tomorrow’s Top 3, and past reviews.
- **Insights and reports** — 7/30-day charts, completion metrics, subject balance, a 35-day heatmap, sentence-based insights, the same **day streak** used on Today, and a shareable report image.
- **Subjects and exams** — subject colors/icons, archive/restore, weekly targets, exam countdowns, topic checklists, readiness, and generated revision plans at D-30, D-14, D-7, and D-2.
- **Languages** — System, English, and Hindi. System follows the phone language and falls back to English; Today, Planner, Focus, and Review use the selected catalogue.
- **Backup and export** — versioned JSON backup, restore preview with before/after counts, CSV task/session exports, and optional Google Drive app-data backup. Drive uses `expo-auth-session`; a refresh token is kept in SecureStore. A raw-token field remains only under **Advanced (developer)**.
- **Optional Supabase sync** — explicit upload/download, automatic safe uploads, a sync preview with local/remote counts, conflict detection, and row-level security in the included schema.
- **Personalisation** — light/dark/system themes, language and week-start preferences, configurable Pomodoro lengths, notification choices, daily goals, planning hours, and confirmed data reset.

All planning, timer, review, insight, import/export, and settings features work without an account. Native data is stored in **SQLite with versioned migrations**, including import from legacy local storage; web uses local storage. Network access is needed only for the optional Drive or Supabase actions.

## Install, check, and run

```bash
npm install --legacy-peer-deps
npm run typecheck
npm test
npx expo start
```

Scan with Expo Go for managed development, or use `npm run android`, `npm run ios`, or `npm run web`. Notification behavior, sharing, SecureStore, and SQLite should also be verified in a native development/standalone build on a physical device.

To produce all export targets:

```bash
npm run build
```

## Optional Google Drive setup

Drive backup is optional and disabled until OAuth client IDs are supplied. In Google Cloud Console, create an OAuth client for the app, allow the `https://www.googleapis.com/auth/drive.appdata` scope, and provide the IDs before starting Expo:

```bash
cp .env.example .env
# Set EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID and/or EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID.
# Set EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID for web.
npx expo start -c
```

Then open **Settings → Backup & export → Google Drive backup → Connect Drive**. FocusFlow requests only private app-data access, keeps the refresh token in SecureStore on native devices, and refreshes access tokens when needed. The app never asks for a token outside **Advanced (developer)**.

## Optional Supabase sync

### Configure in the app

1. Create a Supabase project and wait until it is active.
2. In **SQL Editor**, run all of [`supabase/schema.sql`](supabase/schema.sql).
3. Copy the project URL and **anon public** key from the project’s API settings.
4. Open **Today → Settings → Cloud sync**, paste both values, and tap **Save & continue**.
5. Create an account or sign in, inspect the sync preview, and run the chosen direction.

Only the anon public key belongs in the app; never use a `service_role` key. If email confirmation is enabled, confirm the email before signing in.

Alternatively, copy `.env.example` to `.env` and set `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY`, then restart Expo with its cache cleared.

### Sync behavior

- **Sync preview** compares timestamps and local/remote data counts before transferring anything.
- **Upload** explicitly replaces the account’s cloud snapshot with this device.
- **Download** explicitly replaces local planner data with the cloud snapshot.
- **Auto-sync** waits 12 seconds after editing and uploads only when the sync plan is safe.
- Tasks, sessions, subjects, exams, reviews, settings, and metadata sync together; the active timer remains local.
- Conflicts are surfaced rather than silently overwriting unsynced work. This is snapshot sync, not collaborative editing.

## Build Android with your own Expo project

The repository intentionally contains no owner or EAS project ID. Run these once in your own Expo account:

```bash
npx eas-cli@latest login
npx eas-cli@latest init
```

`eas init` creates and writes your own `extra.eas.projectId`; do not copy an ID from another project. Then build an installable preview APK:

```bash
npx eas-cli@latest build --platform android --profile preview
```

For Google Play, use `--profile production`. The Android application ID and iOS bundle identifier are both `com.abhikr24.focusflow`; native build numbers are currently 3.

## Project map

```text
App.tsx                         app providers and icon-font preload
src/navigation/                 stack + five-tab native navigation
src/screens/                    product screens and forms
src/components/                 native UI, task rows, notifications, 24-hour TimeGrid
src/store/AppContext.tsx        persistence, planner actions, timer, and cloud sync
src/lib/                        SQLite, migrations, notifications, Drive, backup, sharing
src/i18n/                       centralised English and Hindi catalogues
src/utils/                      date, recurrence, streak, quick-add, and insight logic
src/__tests__/                  Vitest unit tests
supabase/schema.sql             table, grants, and row-level security policies
```

## Release verification

Run `npm run typecheck` and `npm test` before every release. On a physical phone, verify process-restored timers, notification actions, Hindi layout, separate break ticks, backup restore previews, and airplane-mode startup. Optional cloud features must be tested separately with the corresponding account and network access.
