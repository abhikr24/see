import { describe, expect, it } from 'vitest';
import {
  GOOGLE_DRIVE_SCOPE, googleClientIdFor, hasGoogleClientId, isDriveTokenFresh,
} from '../lib/driveAuthUtils';

const ids = { android: ' android-id ', ios: 'ios-id', web: '' };

describe('Google Drive auth', () => {
  it('requests only private application data', () => {
    expect(GOOGLE_DRIVE_SCOPE).toBe('https://www.googleapis.com/auth/drive.appdata');
  });
  it('selects and trims the OAuth client for the current platform', () => {
    expect(googleClientIdFor(ids, 'android')).toBe('android-id');
    expect(googleClientIdFor(ids, 'ios')).toBe('ios-id');
    expect(hasGoogleClientId(ids, 'web')).toBe(false);
  });
  it('refreshes near-expiry access tokens', () => {
    expect(isDriveTokenFresh({ accessToken: 'token', expiresAt: 1100 }, 1000)).toBe(true);
    expect(isDriveTokenFresh({ accessToken: 'token', expiresAt: 1050 }, 1000)).toBe(false);
    expect(isDriveTokenFresh({ accessToken: '', expiresAt: 2000 }, 1000)).toBe(false);
  });
});
