import { describe, expect, it } from 'vitest';
import { resolveLocale } from '../i18n/locale';
import { englishCatalog } from '../i18n/catalog';
import { hindiCatalog } from '../i18n/hindi';

describe('language selection', () => {
  it('honours explicit English and Hindi choices', () => {
    expect(resolveLocale('english', 'hi')).toBe('en');
    expect(resolveLocale('hindi', 'en')).toBe('hi');
  });
  it('follows Hindi phone locales and falls back to English', () => {
    expect(resolveLocale('system', 'hi')).toBe('hi');
    expect(resolveLocale('system', 'hi-IN')).toBe('hi');
    expect(resolveLocale('system', 'fr-FR')).toBe('en');
    expect(resolveLocale('system', undefined)).toBe('en');
  });
  it('provides translated core screen labels and the shared day-streak wording', () => {
    expect(hindiCatalog.nav.today).toBe('आज');
    expect(hindiCatalog.planner.viewWeek).toBe('सप्ताह');
    expect(hindiCatalog.focus.begin).toBe('फ़ोकस शुरू करें');
    expect(hindiCatalog.review.tabCheckin).toBe('दैनिक समीक्षा');
    expect(englishCatalog.today.streak(4)).toBe('4 day streak');
    expect(hindiCatalog.today.streak(4)).not.toContain('day streak');
  });
});
