import React, { useMemo, useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { StudyTask } from '../types';
import { makeId, todayKey } from '../utils/date';
import { parseQuickAdd } from '../utils/quickAdd';
import { useI18n } from '../i18n';
import { MAX_FONT_SCALE, Text } from './Text';
import { useDialog } from './DialogHost';

/** One-line natural-language entry: "Physics 45m tomorrow 6pm high". */
export default function QuickAddBar({ onAdded }: { onAdded?: (date: string) => void }) {
  const theme = useTheme();
  const { planner: P, shared: S, formatDuration, formatShortDate, formatTime, relativeDay } = useI18n();
  const dialog = useDialog();
  const { data, saveTask } = useApp();
  const [text, setText] = useState('');
  const [focused, setFocused] = useState(false);
  const parsed = useMemo(() => (text.trim() ? parseQuickAdd(text, { subjects: data.subjects, today: todayKey(), defaultDuration: data.settings.focusMinutes }) : null), [text, data.subjects, data.settings.focusMinutes]);

  const submit = async () => {
    if (!parsed) return;
    const now = new Date().toISOString();
    const task: StudyTask = {
      id: makeId('task'), title: parsed.title === 'Study block' ? S.defaultStudyBlock : parsed.title, notes: '', subjectId: parsed.subjectId ?? data.subjects.find((s) => !s.archived)?.id, date: parsed.date,
      startMinute: parsed.startMinute, durationMinutes: parsed.durationMinutes, estimatedPomodoros: Math.max(1, Math.ceil(parsed.durationMinutes / data.settings.focusMinutes)),
      priority: parsed.priority, recurrence: parsed.recurrence, recurDays: parsed.recurDays, skippedDates: [], completedDates: [], topThreeDates: [],
      kind: 'study', createdAt: now, updatedAt: now,
    };
    saveTask(task);
    setText('');
    const when = `${formatShortDate(parsed.date)}${parsed.startMinute === undefined ? ` · ${P.quickWhenUnscheduled}` : ` · ${formatTime(parsed.startMinute)}`}`;
    onAdded?.(parsed.date);
    await dialog.alert(P.quickAdded(parsed.title === 'Study block' ? S.defaultStudyBlock : parsed.title, when));
  };

  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: theme.surfaceAlt, borderRadius: 16, borderWidth: 1, borderColor: focused ? theme.primary : theme.border, paddingLeft: 12, paddingRight: 6 }}>
        <Ionicons name="flash" size={17} color={theme.primary} />
        <TextInput value={text} onChangeText={setText} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} placeholder={P.quickPlaceholder}
          placeholderTextColor={theme.faint} returnKeyType="done" onSubmitEditing={submit} maxFontSizeMultiplier={MAX_FONT_SCALE} accessibilityLabel={P.quickPlaceholder}
          style={{ flex: 1, minHeight: 46, color: theme.text, fontSize: 14 }} />
        <Pressable onPress={submit} disabled={!parsed} accessibilityRole="button" accessibilityLabel={P.quickAdd}
          style={{ minWidth: 44, minHeight: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12, backgroundColor: parsed ? theme.primary : theme.border }}>
          <Ionicons name="arrow-up" size={18} color={parsed ? (theme.dark ? '#102019' : '#FFF') : theme.faint} />
        </Pressable>
      </View>
      {parsed && <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
        {[
          parsed.title === 'Study block' ? S.defaultStudyBlock : parsed.title,
          relativeDay(parsed.date), formatDuration(parsed.durationMinutes),
          parsed.startMinute === undefined ? P.quickWhenUnscheduled : formatTime(parsed.startMinute),
          parsed.priority === 'high' ? S.priorityHigh : parsed.priority === 'low' ? S.priorityLow : S.priorityMedium,
          parsed.recurrence === 'daily' ? S.repeatDaily : parsed.recurrence === 'weekdays' ? S.repeatWeekdays : parsed.recurrence === 'none' ? '' : S.repeatWeekly,
          data.subjects.find((subject) => subject.id === parsed.subjectId)?.name ?? '',
        ].filter(Boolean).map((chip, index) => (
          <View key={`${chip}_${index}`} style={{ backgroundColor: index === 0 ? theme.primary : theme.primarySoft, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 4 }}>
            <Text numberOfLines={1} style={{ color: index === 0 ? (theme.dark ? '#102019' : '#FFF') : theme.primary, fontSize: 12, fontWeight: '800', maxWidth: 220 }}>{chip}</Text>
          </View>
        ))}
      </View>}
      {!parsed && focused && <Text style={{ color: theme.muted, fontSize: 12 }}>{P.quickHint}</Text>}
    </View>
  );
}
