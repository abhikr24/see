import React from 'react';
import { Pressable, View } from 'react-native';
import { Text } from './Text';
import Ionicons from '@expo/vector-icons/Ionicons';
import { StudyTask, Subject } from '../types';
import { useTheme } from '../theme';
import { useI18n } from '../i18n';
import { isTaskComplete } from '../utils/selectors';
import { IconButton } from './ui';

export default function TaskItem({ task, date, subject, onToggle, onPress, onFocus, compact = false }: {
  task: StudyTask; date: string; subject?: Subject; onToggle: () => void; onPress: () => void; onFocus: () => void; compact?: boolean;
}) {
  const theme = useTheme();
  const { shared: S, formatTime, formatDuration } = useI18n();
  const complete = isTaskComplete(task, date);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: compact ? 9 : 12 }}>
      <Pressable onPress={onToggle} hitSlop={8} accessibilityLabel={complete ? S.markIncomplete : S.markComplete}
        style={{ width: 26, height: 26, borderRadius: 9, borderWidth: 2, borderColor: complete ? theme.primary : theme.border,
          backgroundColor: complete ? theme.primary : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
        {complete && <Ionicons name="checkmark" size={17} color={theme.dark ? '#102019' : '#FFFFFF'} />}
      </Pressable>
      <Pressable onPress={onPress} style={{ flex: 1, gap: 5 }}>
        <Text numberOfLines={2} style={{ color: complete ? theme.muted : theme.text, fontWeight: '700', fontSize: 15, lineHeight: 20,
          textDecorationLine: complete ? 'line-through' : 'none' }}>{task.title}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 7 }}>
          {task.startMinute !== undefined && <Text style={{ color: theme.muted, fontSize: 12 }}>{formatTime(task.startMinute)}</Text>}
          {!!subject && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: subject.color }} />
            <Text style={{ color: theme.muted, fontSize: 12 }}>{subject.name}</Text>
          </View>}
          {task.priority === 'high' && <Ionicons name="flag" size={12} color={theme.warning} />}
          {task.recurrence !== 'none' && <Ionicons name="repeat" size={13} color={theme.muted} />}
        </View>
      </Pressable>
      <Text style={{ color: theme.muted, fontSize: 12, fontWeight: '700' }}>{formatDuration(task.durationMinutes)}</Text>
      {!complete && <IconButton icon="play" onPress={onFocus} label={S.focusOn(task.title)} color={theme.primary} size={17} filled />}
    </View>
  );
}
