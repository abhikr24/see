import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  GestureResponderEvent, PanResponder, Pressable, ScrollView, StyleSheet, TextInput, View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../theme';
import { StudyTask, Subject } from '../types';
import { clamp, fromDateKey, nowMinutes, snapTo, todayKey } from '../utils/date';
import { occursOn } from '../utils/recurrence';
import { layoutLanes } from '../utils/layout';
import { isTaskComplete } from '../utils/selectors';
import { useI18n } from '../i18n';
import { Text } from './Text';

export interface GridDraft { date: string; start: number; duration: number }

interface Occurrence { task: StudyTask; date: string; col: number; start: number; end: number }

interface Props {
  dates: string[];
  tasks: StudyTask[];
  subjects: Subject[];
  defaultDuration: number;
  onOpenTask: (task: StudyTask, date: string) => void;
  onPlay?: (task: StudyTask, date: string) => void;
  onCreate: (draft: GridDraft, title: string | null) => void;
  onMove: (task: StudyTask, fromDate: string, toDate: string, startMinute: number) => void;
  onSelectDate?: (date: string) => void;
}

const LABEL_W = 46;
const TOP_PAD = 12;
const MIN_H = 36;
const MAX_H = 168;
const SNAP = 15;
const FONT_CAP = 1.15;

function touchDistance(e: GestureResponderEvent): number {
  const [a, b] = e.nativeEvent.touches;
  return Math.hypot(a.pageX - b.pageX, a.pageY - b.pageY);
}

interface DragCallbacks {
  start: (occ: Occurrence) => void;
  move: (occ: Occurrence, dx: number, dy: number) => void;
  end: (occ: Occurrence, dx: number, dy: number) => void;
  cancel: () => void;
  open: (occ: Occurrence) => void;
}

function BlockView({ occ, style, color, done, hidden, callbacks, onPlay, showPlay, children }: {
  occ: Occurrence; style: object; color: string; done: boolean; hidden: boolean; callbacks: React.MutableRefObject<DragCallbacks>;
  onPlay?: () => void; showPlay: boolean; children: React.ReactNode;
}) {
  const theme = useTheme();
  const { shared: S } = useI18n();
  const timeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const armed = useRef(false);
  const moved = useRef(false);
  const occRef = useRef(occ);
  occRef.current = occ;
  const clear = () => { if (timeout.current) { clearTimeout(timeout.current); timeout.current = null; } };

  const pan = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => !armed.current,
    onPanResponderGrant: () => {
      armed.current = false;
      moved.current = false;
      clear();
      timeout.current = setTimeout(() => { armed.current = true; callbacks.current.start(occRef.current); }, 380);
    },
    onPanResponderMove: (_, g) => {
      if (!armed.current) {
        if (Math.hypot(g.dx, g.dy) > 8) { moved.current = true; clear(); }
        return;
      }
      callbacks.current.move(occRef.current, g.dx, g.dy);
    },
    onPanResponderRelease: (_, g) => {
      clear();
      if (armed.current) callbacks.current.end(occRef.current, g.dx, g.dy);
      else if (!moved.current) callbacks.current.open(occRef.current);
      armed.current = false;
    },
    onPanResponderTerminate: () => {
      clear();
      if (armed.current) callbacks.current.cancel();
      armed.current = false;
    },
  }), [callbacks]);

  useEffect(() => clear, []);

  return (
    <View {...pan.panHandlers} accessibilityRole="button" accessibilityLabel={occ.task.title}
      style={[styles.block, style, { backgroundColor: `${color}${theme.dark ? '40' : '30'}`, borderLeftColor: color, opacity: hidden ? 0.3 : done ? 0.6 : 1 }]}>
      {children}
      {showPlay && onPlay && !done && (
        <Pressable onPress={onPlay} hitSlop={8} accessibilityLabel={S.focusOn(occ.task.title)} style={[styles.playBtn, { backgroundColor: color }]}>
          <Ionicons name="play" size={12} color="#FFFFFF" />
        </Pressable>
      )}
    </View>
  );
}

export default function TimeGrid(props: Props) {
  const { dates, tasks, subjects, defaultDuration } = props;
  const theme = useTheme();
  const { planner: P, shared: S, formatDuration, formatHourLabel, formatShortDate, formatTime, weekdayShort } = useI18n();
  const cols = dates.length;
  const weekMode = cols > 1;
  const [hourH, setHourH] = useState(weekMode ? 44 : 64);
  const [width, setWidth] = useState(0);
  const [viewH, setViewH] = useState(0);
  const [draft, setDraft] = useState<GridDraft | null>(null);
  const [ghost, setGhost] = useState<{ taskId: string; date: string; start: number } | null>(null);
  const [locked, setLocked] = useState(false);
  const [title, setTitle] = useState('');
  const [now, setNow] = useState(() => new Date());
  const scrollRef = useRef<ScrollView>(null);
  const scrollY = useRef(0);
  const prevHour = useRef(hourH);
  const didInitialScroll = useRef(false);
  const pinch = useRef<{ dist: number; h: number } | null>(null);

  const colW = Math.max(0, (width - LABEL_W) / cols);
  const ppm = hourH / 60;
  const live = useRef({ hourH, colW, ppm, cols, dates, draft });
  live.current = { hourH, colW, ppm, cols, dates, draft };
  const today = todayKey(now);

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  // Clear the selection when the visible dates change.
  const datesKey = dates.join('|');
  useEffect(() => { setDraft(null); setTitle(''); }, [datesKey]);

  // First scroll: near "now" if today is visible, otherwise to 7 AM.
  useEffect(() => {
    if (didInitialScroll.current || width === 0 || viewH === 0) return;
    didInitialScroll.current = true;
    const target = dates.includes(todayKey()) ? Math.max(0, nowMinutes() - 90) : 7 * 60;
    const y = Math.max(0, target * ppm);
    requestAnimationFrame(() => scrollRef.current?.scrollTo({ y, animated: false }));
  }, [width, viewH, dates, ppm]);

  // Keep the centre of the viewport steady while zooming.
  useEffect(() => {
    if (prevHour.current === hourH) return;
    const ratio = hourH / prevHour.current;
    const y = Math.max(0, (scrollY.current + viewH / 2) * ratio - viewH / 2);
    prevHour.current = hourH;
    scrollRef.current?.scrollTo({ y, animated: false });
  }, [hourH, viewH]);

  const subjectColor = useCallback((task: StudyTask) => subjects.find((s) => s.id === task.subjectId)?.color ?? theme.primary, [subjects, theme.primary]);

  const occurrences = useMemo<Occurrence[]>(() => dates.flatMap((date, col) => tasks
    .filter((task) => task.startMinute !== undefined && occursOn(task, date))
    .map((task) => ({ task, date, col, start: task.startMinute as number, end: Math.min(1440, (task.startMinute as number) + task.durationMinutes) }))), [dates, tasks]);

  const lanes = useMemo(() => dates.map((_, col) => layoutLanes(occurrences.filter((o) => o.col === col).map((o) => ({ id: o.task.id, start: o.start, end: o.end })))), [dates, occurrences]);

  // ----- selection draft: tap to select, drag handles to resize, drag body to move -----
  const tapColumn = (col: number, y: number) => {
    const minute = clamp(Math.floor(y / ppm / SNAP) * SNAP, 0, 1440 - SNAP);
    setDraft({ date: dates[col], start: minute, duration: Math.min(defaultDuration, 1440 - minute) });
  };

  const draftOrigin = useRef<GridDraft | null>(null);
  const makeHandle = (mode: 'top' | 'bottom' | 'body') => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: () => { draftOrigin.current = live.current.draft ? { ...live.current.draft } : null; setLocked(true); },
    onPanResponderMove: (_, g) => {
      const o = draftOrigin.current;
      if (!o) return;
      const { ppm: p, colW: w, dates: ds, cols: c } = live.current;
      const end = o.start + o.duration;
      if (mode === 'bottom') {
        const newEnd = clamp(snapTo(end + g.dy / p, SNAP), o.start + SNAP, 1440);
        setDraft({ ...o, duration: newEnd - o.start });
      } else if (mode === 'top') {
        const newStart = clamp(snapTo(o.start + g.dy / p, SNAP), 0, end - SNAP);
        setDraft({ ...o, start: newStart, duration: end - newStart });
      } else {
        const col = clamp(ds.indexOf(o.date) + (w > 0 ? Math.round(g.dx / w) : 0), 0, c - 1);
        const start = clamp(snapTo(o.start + g.dy / p, SNAP), 0, 1440 - o.duration);
        setDraft({ ...o, date: ds[col], start });
      }
    },
    onPanResponderRelease: () => setLocked(false),
    onPanResponderTerminate: () => setLocked(false),
  });
  const topHandle = useMemo(() => makeHandle('top'), []); // eslint-disable-line react-hooks/exhaustive-deps
  const bottomHandle = useMemo(() => makeHandle('bottom'), []); // eslint-disable-line react-hooks/exhaustive-deps
  const bodyHandle = useMemo(() => makeHandle('body'), []); // eslint-disable-line react-hooks/exhaustive-deps

  // ----- long-press drag of existing blocks -----
  const target = (occ: Occurrence, dx: number, dy: number) => {
    const { ppm: p, colW: w, dates: ds, cols: c } = live.current;
    const duration = Math.min(occ.task.durationMinutes, 1440);
    const col = clamp(occ.col + (w > 0 ? Math.round(dx / w) : 0), 0, c - 1);
    const start = clamp(snapTo(occ.start + dy / p, SNAP), 0, 1440 - Math.min(duration, 1440 - SNAP));
    return { date: ds[col], start };
  };
  const callbacks = useRef<DragCallbacks>({ start: () => undefined, move: () => undefined, end: () => undefined, cancel: () => undefined, open: () => undefined });
  callbacks.current = {
    start: (occ) => { setLocked(true); setGhost({ taskId: occ.task.id, date: occ.date, start: occ.start }); },
    move: (occ, dx, dy) => setGhost({ taskId: occ.task.id, ...target(occ, dx, dy) }),
    end: (occ, dx, dy) => {
      const t = target(occ, dx, dy);
      setGhost(null);
      setLocked(false);
      if (t.date !== occ.date || t.start !== occ.start) props.onMove(occ.task, occ.date, t.date, t.start);
    },
    cancel: () => { setGhost(null); setLocked(false); },
    open: (occ) => props.onOpenTask(occ.task, occ.date),
  };

  const submitQuick = () => {
    if (!draft) return;
    props.onCreate(draft, title.trim() || null);
    if (title.trim()) { setDraft(null); setTitle(''); }
  };
  const draftEnd = draft ? draft.start + draft.duration : 0;
  const draftCol = draft ? dates.indexOf(draft.date) : -1;

  return (
    <View style={{ flex: 1 }}>
      {weekMode && (
        <View style={[styles.weekHeader, { borderBottomColor: theme.border, backgroundColor: theme.background }]}>
          <View style={{ width: LABEL_W }} />
          {dates.map((date) => {
            const isToday = date === today;
            return (
              <Pressable key={date} onPress={() => props.onSelectDate?.(date)} style={styles.weekHeaderCell} accessibilityRole="button" accessibilityLabel={formatShortDate(date)}>
                <Text maxFontSizeMultiplier={FONT_CAP} style={{ color: isToday ? theme.primary : theme.muted, fontSize: 10, fontWeight: '800' }}>{weekdayShort(date).toUpperCase()}</Text>
                <View style={[styles.dateBubble, isToday && { backgroundColor: theme.primary }]}>
                  <Text maxFontSizeMultiplier={FONT_CAP} style={{ color: isToday ? (theme.dark ? '#102019' : '#FFF') : theme.text, fontSize: 14, fontWeight: '900' }}>{fromDateKey(date).getDate()}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>
      )}

      <ScrollView ref={scrollRef} style={{ flex: 1 }} scrollEnabled={!locked} showsVerticalScrollIndicator
        scrollEventThrottle={16} onScroll={(e) => { scrollY.current = e.nativeEvent.contentOffset.y; }}
        onLayout={(e) => { setWidth(e.nativeEvent.layout.width); setViewH(e.nativeEvent.layout.height); }}
        contentContainerStyle={{ paddingBottom: draft ? 168 : 72 }}>
        <View
          style={{ height: TOP_PAD + 24 * hourH + 8 }}
          onTouchStart={(e) => { if (e.nativeEvent.touches.length === 2) { pinch.current = { dist: touchDistance(e), h: live.current.hourH }; setLocked(true); } }}
          onTouchMove={(e) => {
            if (pinch.current && e.nativeEvent.touches.length === 2) {
              setHourH(clamp(pinch.current.h * (touchDistance(e) / Math.max(1, pinch.current.dist)), MIN_H, MAX_H));
            }
          }}
          onTouchEnd={(e) => { if (pinch.current && e.nativeEvent.touches.length < 2) { pinch.current = null; setLocked(false); } }}
        >
          {/* hour lines + labels */}
          {Array.from({ length: 25 }, (_, h) => (
            <React.Fragment key={h}>
              <View pointerEvents="none" style={[styles.hourLine, { top: TOP_PAD + h * hourH, left: LABEL_W, backgroundColor: theme.border }]} />
              <Text pointerEvents="none" maxFontSizeMultiplier={FONT_CAP} style={[styles.hourLabel, { top: TOP_PAD + h * hourH - 7, color: theme.faint }]}>
                {h === 24 ? '' : formatHourLabel(h)}
              </Text>
              {hourH >= 84 && h < 24 && [15, 30, 45].map((m) => (
                <View key={m} pointerEvents="none" style={[styles.hourLine, { top: TOP_PAD + h * hourH + (m / 60) * hourH, left: LABEL_W, backgroundColor: theme.border, opacity: m === 30 ? 0.45 : 0.22 }]} />
              ))}
            </React.Fragment>
          ))}

          {/* column tap areas + separators */}
          {dates.map((date, col) => (
            <React.Fragment key={date}>
              {weekMode && <View pointerEvents="none" style={{ position: 'absolute', left: LABEL_W + col * colW, top: TOP_PAD, height: 24 * hourH, width: StyleSheet.hairlineWidth, backgroundColor: theme.border }} />}
              <Pressable
                accessibilityRole="button" accessibilityLabel={S.selectTimeOn(formatShortDate(date))}
                onPress={(e) => tapColumn(col, e.nativeEvent.locationY)}
                style={{ position: 'absolute', left: LABEL_W + col * colW, width: colW, top: TOP_PAD, height: 24 * hourH, backgroundColor: date === today && weekMode ? `${theme.primary}0F` : 'transparent' }}
              />
            </React.Fragment>
          ))}

          {/* existing blocks */}
          {occurrences.map((occ) => {
            const lane = lanes[occ.col].get(occ.task.id) ?? { lane: 0, lanes: 1 };
            const laneW = (colW - 4) / lane.lanes;
            const height = Math.max(18, (occ.end - occ.start) * ppm - 1);
            const color = subjectColor(occ.task);
            const done = isTaskComplete(occ.task, occ.date);
            const roomy = height >= 34;
            const tall = height >= 52;
            return (
              <BlockView key={`${occ.task.id}_${occ.date}`} occ={occ} color={color} done={done} callbacks={callbacks}
                hidden={ghost?.taskId === occ.task.id} showPlay={!weekMode && height >= 40} onPlay={() => props.onPlay?.(occ.task, occ.date)}
                style={{ left: LABEL_W + occ.col * colW + 2 + lane.lane * laneW, width: laneW - 2, top: TOP_PAD + occ.start * ppm, height }}>
                <Text maxFontSizeMultiplier={FONT_CAP} numberOfLines={tall && !weekMode ? 2 : 1}
                  style={{ color: theme.text, fontSize: weekMode ? 10 : 12, fontWeight: '800', textDecorationLine: done ? 'line-through' : 'none', paddingRight: !weekMode && height >= 40 ? 22 : 0 }}>
                  {occ.task.kind === 'class' ? '🎓 ' : ''}{occ.task.title}
                </Text>
                {roomy && !weekMode && (
                  <Text maxFontSizeMultiplier={FONT_CAP} numberOfLines={1} style={{ color: theme.muted, fontSize: 10, marginTop: 1 }}>
                    {formatTime(occ.start)} – {formatTime(occ.start + occ.task.durationMinutes)}{occ.task.recurrence !== 'none' ? ' ↻' : ''}
                  </Text>
                )}
              </BlockView>
            );
          })}

          {/* drag ghost */}
          {ghost && (() => {
            const occ = occurrences.find((o) => o.task.id === ghost.taskId);
            if (!occ) return null;
            const col = dates.indexOf(ghost.date);
            const height = Math.max(18, (occ.end - occ.start) * ppm - 1);
            return (
              <View pointerEvents="none" style={[styles.ghost, { left: LABEL_W + col * colW + 2, width: colW - 4, top: TOP_PAD + ghost.start * ppm, height, borderColor: theme.primary, backgroundColor: `${theme.primary}33` }]}>
                <Text maxFontSizeMultiplier={FONT_CAP} numberOfLines={1} style={{ color: theme.text, fontSize: 10, fontWeight: '900' }}>{formatTime(ghost.start)}</Text>
              </View>
            );
          })()}

          {/* selection draft (outer box is 15px taller on both ends so the handles stay inside it — Android only delivers touches inside a parent's bounds) */}
          {draft && draftCol >= 0 && (
            <View style={{ position: 'absolute', left: LABEL_W + draftCol * colW + 2, width: colW - 4, top: TOP_PAD + draft.start * ppm - 15, height: Math.max(20, draft.duration * ppm) + 30 }}>
              <View {...bodyHandle.panHandlers} accessibilityLabel={S.selectedTimeRange}
                style={[styles.draftBody, { borderColor: theme.primary, backgroundColor: `${theme.primary}2E`, top: 15, bottom: 15 }]}>
                <Text maxFontSizeMultiplier={FONT_CAP} numberOfLines={1} style={{ color: theme.primary, fontSize: weekMode ? 9 : 12, fontWeight: '900' }}>
                  {formatTime(draft.start)}{weekMode ? '' : ` – ${formatTime(draftEnd)}`}
                </Text>
                {!weekMode && draft.duration * ppm >= 40 && <Text maxFontSizeMultiplier={FONT_CAP} style={{ color: theme.primary, fontSize: 11, fontWeight: '700' }}>{formatDuration(draft.duration)}</Text>}
              </View>
              <View {...topHandle.panHandlers} accessibilityLabel={S.dragStart} style={[styles.handleZone, { top: 0 }]}>
                <View style={[styles.knob, { backgroundColor: theme.surface, borderColor: theme.primary }]} />
              </View>
              <View {...bottomHandle.panHandlers} accessibilityLabel={S.dragEnd} style={[styles.handleZone, { bottom: 0 }]}>
                <View style={[styles.knob, { backgroundColor: theme.primary, borderColor: theme.primary }]} />
              </View>
            </View>
          )}

          {/* live "now" line */}
          {dates.map((date, col) => date === today ? (
            <View key={`now_${date}`} pointerEvents="none" style={{ position: 'absolute', left: LABEL_W + col * colW - 4, width: colW + 4, top: TOP_PAD + (now.getHours() * 60 + now.getMinutes()) * ppm - 1, flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: theme.danger }} />
              <View style={{ flex: 1, height: 2, backgroundColor: theme.danger }} />
            </View>
          ) : null)}
        </View>
      </ScrollView>

      {/* zoom */}
      <View style={[styles.zoom, { bottom: draft ? 176 : 16 }]}>
        <Pressable accessibilityLabel={P.zoomIn} onPress={() => setHourH((h) => clamp(Math.round(h * 1.25), MIN_H, MAX_H))} style={[styles.zoomBtn, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <Ionicons name="add" size={20} color={theme.text} />
        </Pressable>
        <Pressable accessibilityLabel={P.zoomOut} onPress={() => setHourH((h) => clamp(Math.round(h / 1.25), MIN_H, MAX_H))} style={[styles.zoomBtn, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <Ionicons name="remove" size={20} color={theme.text} />
        </Pressable>
      </View>

      {/* selection action bar */}
      {draft && (
        <View style={[styles.bar, { backgroundColor: theme.surface, borderColor: theme.border, shadowColor: theme.shadow }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.text, fontWeight: '900', fontSize: 14 }}>
                {P.draftSummary(formatShortDate(draft.date), formatTime(draft.start), formatTime(draftEnd), formatDuration(draft.duration))}
              </Text>
              <Text style={{ color: theme.muted, fontSize: 11, marginTop: 2 }}>{P.draftHint}</Text>
            </View>
            <Pressable accessibilityLabel={P.draftCancel} hitSlop={10} onPress={() => { setDraft(null); setTitle(''); }} style={styles.barClose}>
              <Ionicons name="close" size={20} color={theme.muted} />
            </Pressable>
          </View>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TextInput value={title} onChangeText={setTitle} placeholder={P.draftTitlePlaceholder} placeholderTextColor={theme.faint}
              returnKeyType="done" onSubmitEditing={submitQuick} maxFontSizeMultiplier={1.3}
              style={[styles.barInput, { backgroundColor: theme.surfaceAlt, color: theme.text, borderColor: theme.border }]} />
            <Pressable onPress={submitQuick} disabled={!title.trim()} accessibilityRole="button"
              style={[styles.barBtn, { backgroundColor: theme.primary, opacity: title.trim() ? 1 : 0.4 }]}>
              <Text maxFontSizeMultiplier={1.2} style={{ color: theme.dark ? '#102019' : '#FFF', fontWeight: '900', fontSize: 13 }}>{P.draftAdd}</Text>
            </Pressable>
            <Pressable onPress={() => props.onCreate(draft, null)} accessibilityLabel={P.draftDetails} accessibilityRole="button"
              style={[styles.barBtn, { backgroundColor: theme.primarySoft }]}>
              <Ionicons name="options-outline" size={18} color={theme.primary} />
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  weekHeader: { flexDirection: 'row', borderBottomWidth: StyleSheet.hairlineWidth, paddingBottom: 6, paddingTop: 2 },
  weekHeaderCell: { flex: 1, alignItems: 'center', gap: 2 },
  dateBubble: { minWidth: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  hourLine: { position: 'absolute', right: 0, height: StyleSheet.hairlineWidth },
  hourLabel: { position: 'absolute', left: 0, width: LABEL_W - 8, textAlign: 'right', fontSize: 10, fontWeight: '600' },
  block: { position: 'absolute', borderRadius: 8, borderLeftWidth: 4, paddingHorizontal: 6, paddingVertical: 3, overflow: 'hidden' },
  playBtn: { position: 'absolute', right: 4, top: 4, width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  ghost: { position: 'absolute', borderRadius: 8, borderWidth: 2, borderStyle: 'dashed', paddingHorizontal: 6, paddingVertical: 3 },
  draftBody: { position: 'absolute', left: 0, right: 0, borderRadius: 10, borderWidth: 2, paddingHorizontal: 8, paddingVertical: 4, overflow: 'hidden' },
  handleZone: { position: 'absolute', left: '50%', marginLeft: -32, width: 64, height: 30, alignItems: 'center', justifyContent: 'center' },
  knob: { width: 16, height: 16, borderRadius: 8, borderWidth: 3 },
  zoom: { position: 'absolute', right: 12, gap: 8 },
  zoomBtn: { width: 38, height: 38, borderRadius: 19, borderWidth: 1, alignItems: 'center', justifyContent: 'center', shadowOpacity: 0.12, shadowRadius: 6, shadowOffset: { width: 0, height: 2 }, elevation: 3 },
  bar: { position: 'absolute', left: 10, right: 10, bottom: 10, borderRadius: 20, borderWidth: 1, padding: 12, gap: 10, shadowOpacity: 0.14, shadowRadius: 14, shadowOffset: { width: 0, height: 4 }, elevation: 8 },
  barClose: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  barInput: { flex: 1, minHeight: 44, borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, fontSize: 14 },
  barBtn: { minWidth: 44, minHeight: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 14 },
});
