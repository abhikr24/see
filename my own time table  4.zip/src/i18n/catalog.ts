import { common } from './base';
import { nav, review, today } from './screens';
import { planner } from './planner';
import { focus, overlay } from './focus';

export const shared = {
  goBack: 'Go back', close: 'Close',
  markComplete: 'Mark complete', markIncomplete: 'Mark incomplete',
  focusOn: (title: string) => `Focus on ${title}`,
  selectTimeOn: (date: string) => `Select a time on ${date}`,
  selectedTimeRange: 'Selected time range',
  dragStart: 'Drag to change start time', dragEnd: 'Drag to change end time',
  classTimetable: 'Class timetable',
  moreInList: (count: number) => `+${count} more in List view`,
  timerMinutesSeconds: (minutes: number, seconds: number) => `${minutes} minutes ${seconds} seconds`,
  minutesFocused: (minutes: number) => `${minutes} minutes focused`,
  priorityHigh: 'High priority', priorityMedium: 'Medium priority', priorityLow: 'Low priority',
  repeatDaily: 'Daily', repeatWeekdays: 'Weekdays', repeatWeekly: 'Weekly',
  defaultStudyBlock: 'Study block',
};

export const dateText = {
  today: 'Today', tomorrow: 'Tomorrow', yesterday: 'Yesterday',
  am: 'AM', pm: 'PM', hourShort: 'h', minuteShort: 'm', secondShort: 's',
};

export const languageText = {
  title: 'Language', subtitle: 'System follows your phone and falls back to English.',
  system: 'System', english: 'English', hindi: 'Hindi',
};

export interface TextCatalog {
  common: typeof common;
  nav: typeof nav;
  today: typeof today;
  review: typeof review;
  planner: typeof planner;
  focus: typeof focus;
  overlay: typeof overlay;
  shared: typeof shared;
  dates: typeof dateText;
  language: typeof languageText;
}

export const englishCatalog: TextCatalog = {
  common, nav, today, review, planner, focus, overlay, shared, dates: dateText, language: languageText,
};
