import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { AppState } from 'react-native';
import { getLocales } from 'expo-localization';
import { useApp } from '../store/AppContext';
import { addDays, fromDateKey, todayKey } from '../utils/date';
import { englishCatalog, TextCatalog } from './catalog';
import { hindiCatalog } from './hindi';
import { Locale, resolveLocale } from './locale';

export interface I18nValue extends TextCatalog {
  locale: Locale;
  formatLongDate: (key: string) => string;
  formatShortDate: (key: string) => string;
  weekdayShort: (key: string) => string;
  formatTime: (minutes: number) => string;
  formatHourLabel: (hour: number) => string;
  formatDuration: (minutes: number) => string;
  formatElapsed: (seconds: number) => string;
  relativeDay: (key: string, today?: string) => string;
}

const I18nContext = createContext<I18nValue | null>(null);

function phoneLocale(): Locale {
  return resolveLocale('system', getLocales()[0]?.languageCode);
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const { data } = useApp();
  const [systemLocale, setSystemLocale] = useState<Locale>(phoneLocale);
  const locale = resolveLocale(data.settings.language, systemLocale);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') setSystemLocale(phoneLocale());
    });
    return () => subscription.remove();
  }, []);

  const value = useMemo<I18nValue>(() => {
    const catalog = locale === 'hi' ? hindiCatalog : englishCatalog;
    const tag = locale === 'hi' ? 'hi-IN' : 'en-US';
    const formatLongDate = (key: string) => fromDateKey(key).toLocaleDateString(tag, { weekday: 'long', month: 'long', day: 'numeric' });
    const formatShortDate = (key: string) => fromDateKey(key).toLocaleDateString(tag, { month: 'short', day: 'numeric' });
    const weekdayShort = (key: string) => fromDateKey(key).toLocaleDateString(tag, { weekday: 'short' });
    const formatTime = (totalMinutes: number) => {
      const normalized = ((Math.round(totalMinutes) % 1440) + 1440) % 1440;
      const hours = Math.floor(normalized / 60);
      const minutes = normalized % 60;
      const suffix = hours >= 12 ? catalog.dates.pm : catalog.dates.am;
      return `${hours % 12 || 12}:${String(minutes).padStart(2, '0')} ${suffix}`;
    };
    const formatDuration = (minutes: number) => {
      const rounded = Math.round(minutes);
      if (rounded < 60) return `${rounded}${locale === 'hi' ? ' ' : ''}${catalog.dates.minuteShort}`;
      const hours = Math.floor(rounded / 60);
      const rest = rounded % 60;
      const hourLabel = `${hours}${locale === 'hi' ? ' ' : ''}${catalog.dates.hourShort}`;
      return rest ? `${hourLabel} ${rest}${locale === 'hi' ? ' ' : ''}${catalog.dates.minuteShort}` : hourLabel;
    };
    const formatElapsed = (seconds: number) => {
      const total = Math.max(0, Math.round(seconds));
      if (total < 60) return `${total}${locale === 'hi' ? ' ' : ''}${catalog.dates.secondShort}`;
      if (total < 3600) {
        const minutes = Math.floor(total / 60);
        const rest = total % 60;
        const minuteLabel = `${minutes}${locale === 'hi' ? ' ' : ''}${catalog.dates.minuteShort}`;
        return rest >= 30 && total < 300
          ? `${minuteLabel} ${rest}${locale === 'hi' ? ' ' : ''}${catalog.dates.secondShort}`
          : `${Math.round(total / 60)}${locale === 'hi' ? ' ' : ''}${catalog.dates.minuteShort}`;
      }
      return formatDuration(total / 60);
    };
    const relativeDay = (key: string, today: string = todayKey()) => {
      if (key === today) return catalog.dates.today;
      if (key === addDays(today, 1)) return catalog.dates.tomorrow;
      if (key === addDays(today, -1)) return catalog.dates.yesterday;
      return formatShortDate(key);
    };
    return {
      ...catalog, locale, formatLongDate, formatShortDate, weekdayShort, formatTime,
      formatHourLabel: (hour: number) => formatTime(hour * 60).replace(':00', ''),
      formatDuration, formatElapsed, relativeDay,
    };
  }, [locale]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const value = useContext(I18nContext);
  if (!value) throw new Error('useI18n must be used inside I18nProvider');
  return value;
}
