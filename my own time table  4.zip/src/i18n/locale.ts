import { LanguagePreference } from '../types';

export type Locale = 'en' | 'hi';

/** Only Hindi has a separate catalogue; every other phone language deliberately falls back to English. */
export function resolveLocale(preference: LanguagePreference, phoneLanguageCode?: string | null): Locale {
  if (preference === 'hindi') return 'hi';
  if (preference === 'english') return 'en';
  return phoneLanguageCode?.toLowerCase().split(/[-_]/)[0] === 'hi' ? 'hi' : 'en';
}
