// Optional Google Drive backup using the REST API and the private "appDataFolder" space.
// Callers obtain a short-lived token through driveAuth; this module only performs the requested transfer.
const FILE_NAME = 'focusflow-backup.json';
const API = 'https://www.googleapis.com/drive/v3';
const UPLOAD = 'https://www.googleapis.com/upload/drive/v3';

export class DriveError extends Error {}

async function request(token: string, url: string, init: RequestInit = {}): Promise<Response> {
  const response = await fetch(url, { ...init, headers: { Authorization: `Bearer ${token}`, ...(init.headers ?? {}) } });
  if (!response.ok) throw new DriveError(`Google Drive replied ${response.status}`);
  return response;
}

async function findBackupId(token: string): Promise<string | null> {
  const query = encodeURIComponent(`name='${FILE_NAME}'`);
  const response = await request(token, `${API}/files?spaces=appDataFolder&q=${query}&fields=files(id,modifiedTime)&orderBy=modifiedTime desc`);
  const body = (await response.json()) as { files?: { id: string }[] };
  return body.files && body.files.length > 0 ? body.files[0].id : null;
}

export async function uploadBackupToDrive(token: string, json: string): Promise<void> {
  const existing = await findBackupId(token);
  if (existing) {
    await request(token, `${UPLOAD}/files/${existing}?uploadType=media`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: json });
    return;
  }
  const boundary = 'focusflow_boundary';
  const metadata = JSON.stringify({ name: FILE_NAME, parents: ['appDataFolder'], mimeType: 'application/json' });
  const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${json}\r\n--${boundary}--`;
  await request(token, `${UPLOAD}/files?uploadType=multipart`, { method: 'POST', headers: { 'Content-Type': `multipart/related; boundary=${boundary}` }, body });
}

export async function downloadBackupFromDrive(token: string): Promise<string | null> {
  const id = await findBackupId(token);
  if (!id) return null;
  const response = await request(token, `${API}/files/${id}?alt=media`);
  return response.text();
}
