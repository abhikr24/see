import AsyncStorage from '@react-native-async-storage/async-storage';
import * as AuthSession from 'expo-auth-session';
import * as Google from 'expo-auth-session/providers/google';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import {
  GOOGLE_DRIVE_SCOPE, GoogleClientIds, OAuthPlatform, StoredDriveSession, googleClientIdFor, hasGoogleClientId, isDriveTokenFresh,
} from './driveAuthUtils';

const SESSION_KEY = 'focusflow_google_drive_session_v1';

export const googleClientIds: GoogleClientIds = {
  android: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID ?? '',
  ios: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ?? '',
  web: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID ?? '',
};

function platform(): OAuthPlatform {
  return Platform.OS === 'android' || Platform.OS === 'ios' ? Platform.OS : 'web';
}

export function currentGoogleClientId(): string {
  return googleClientIdFor(googleClientIds, platform());
}

export function isGoogleOAuthConfigured(): boolean {
  return hasGoogleClientId(googleClientIds, platform());
}

async function readSession(): Promise<StoredDriveSession | null> {
  const raw = Platform.OS === 'web'
    ? await AsyncStorage.getItem(SESSION_KEY)
    : await SecureStore.getItemAsync(SESSION_KEY);
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<StoredDriveSession>;
    if (typeof value.accessToken !== 'string' || typeof value.expiresAt !== 'number') return null;
    return {
      accessToken: value.accessToken,
      refreshToken: typeof value.refreshToken === 'string' ? value.refreshToken : undefined,
      expiresAt: value.expiresAt,
    };
  } catch {
    return null;
  }
}

export async function saveDriveSession(tokens: AuthSession.TokenResponse): Promise<StoredDriveSession> {
  const previous = await readSession();
  const session: StoredDriveSession = {
    accessToken: tokens.accessToken,
    refreshToken: tokens.refreshToken ?? previous?.refreshToken,
    expiresAt: tokens.issuedAt + (tokens.expiresIn ?? 3600),
  };
  const value = JSON.stringify(session);
  // On Android/iOS both tokens, including the refresh token, live only in SecureStore.
  if (Platform.OS === 'web') await AsyncStorage.setItem(SESSION_KEY, value);
  else await SecureStore.setItemAsync(SESSION_KEY, value);
  return session;
}

export async function hasDriveSession(): Promise<boolean> {
  const session = await readSession();
  return Boolean(session?.refreshToken || isDriveTokenFresh(session ?? { accessToken: '', expiresAt: 0 }, Date.now() / 1000));
}

/** Return a usable access token, refreshing it locally through Google only when necessary. */
export async function getValidDriveAccessToken(): Promise<string | null> {
  const session = await readSession();
  if (!session) return null;
  if (isDriveTokenFresh(session, Date.now() / 1000)) return session.accessToken;
  if (!session.refreshToken) return null;
  const clientId = currentGoogleClientId();
  if (!clientId) throw new Error('Google OAuth client ID is not configured for this platform.');
  const refreshed = await AuthSession.refreshAsync({
    clientId,
    refreshToken: session.refreshToken,
    scopes: [GOOGLE_DRIVE_SCOPE],
  }, Google.discovery);
  // Google normally omits refresh_token on refresh; preserve the original SecureStore value.
  if (!refreshed.refreshToken) refreshed.refreshToken = session.refreshToken;
  await saveDriveSession(refreshed);
  return refreshed.accessToken;
}

export async function disconnectDrive(): Promise<void> {
  if (Platform.OS === 'web') await AsyncStorage.removeItem(SESSION_KEY);
  else await SecureStore.deleteItemAsync(SESSION_KEY);
}
