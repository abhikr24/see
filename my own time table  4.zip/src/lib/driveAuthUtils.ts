export const GOOGLE_DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.appdata';

export type OAuthPlatform = 'android' | 'ios' | 'web';

export interface GoogleClientIds {
  android: string;
  ios: string;
  web: string;
}

export interface StoredDriveSession {
  accessToken: string;
  refreshToken?: string;
  /** Unix timestamp in seconds. */
  expiresAt: number;
}

export function googleClientIdFor(ids: GoogleClientIds, platform: OAuthPlatform): string {
  return ids[platform].trim();
}

export function hasGoogleClientId(ids: GoogleClientIds, platform: OAuthPlatform): boolean {
  return googleClientIdFor(ids, platform).length > 0;
}

/** Keep a small safety margin so an access token cannot expire during a Drive request. */
export function isDriveTokenFresh(session: Pick<StoredDriveSession, 'accessToken' | 'expiresAt'>, nowSeconds: number): boolean {
  return Boolean(session.accessToken) && session.expiresAt - nowSeconds > 60;
}
