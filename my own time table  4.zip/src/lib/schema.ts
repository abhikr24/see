import {
  AppData, AppSettings, BlockKind, DailyReview, Exam, ExamTopic, FocusSession, FocusSoundKind, Priority,
  Recurrence, StudyTask, Subject, ThemeMode, LanguagePreference,
} from '../types';

export const DATA_SCHEMA_VERSION = 2;

export const defaultSettings: AppSettings = {
  name: 'Scholar', focusMinutes: 25, shortBreakMinutes: 5, longBreakMinutes: 15, longBreakEvery: 4,
  dailyGoalMinutes: 120, waterGoal: 8, theme: 'system', language: 'system', autoSync: false, weekStartsMonday: true,
  notifyFocusEnd: true, notifyBreakEnd: true, notifyBlockStart: true, blockLeadMinutes: 5,
  notificationsPrompted: false, focusSound: 'none', strictMode: false, planStartMinute: 360, planEndMinute: 1320,
};

export function emptyData(settings: Partial<AppSettings> = {}): AppData {
  return {
    tasks: [], subjects: [], sessions: [], reviews: [], exams: [],
    settings: { ...defaultSettings, ...settings },
    meta: { updatedAt: new Date(0).toISOString(), dirty: false, edited: false },
  };
}

type Rec = Record<string, unknown>;
const isRec = (v: unknown): v is Rec => typeof v === 'object' && v !== null && !Array.isArray(v);
const str = (v: unknown, d = ''): string => (typeof v === 'string' ? v : d);
const optStr = (v: unknown): string | undefined => (typeof v === 'string' && v ? v : undefined);
const num = (v: unknown, d: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const bool = (v: unknown, d: boolean): boolean => (typeof v === 'boolean' ? v : d);
const strArr = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);
const numArr = (v: unknown): number[] => (Array.isArray(v) ? v.filter((x): x is number => typeof x === 'number') : []);
const oneOf = <T extends string>(v: unknown, options: readonly T[], d: T): T => (typeof v === 'string' && (options as readonly string[]).includes(v) ? (v as T) : d);
const nowIso = () => new Date().toISOString();

function normalizeSubject(v: unknown): Subject | null {
  if (!isRec(v) || !str(v.id)) return null;
  return {
    id: str(v.id), name: str(v.name, 'Subject'), color: str(v.color, '#5D8F7B'), icon: str(v.icon, 'book'),
    weeklyGoalMinutes: num(v.weeklyGoalMinutes, 180), archived: bool(v.archived, false), createdAt: str(v.createdAt, nowIso()),
  };
}

function normalizeTask(v: unknown): StudyTask | null {
  if (!isRec(v) || !str(v.id)) return null;
  const duration = Math.max(5, num(v.durationMinutes, 50));
  const start = typeof v.startMinute === 'number' && Number.isFinite(v.startMinute)
    ? Math.min(1439, Math.max(0, Math.round(v.startMinute))) : undefined;
  return {
    id: str(v.id), title: str(v.title, 'Untitled block'), notes: str(v.notes), subjectId: optStr(v.subjectId),
    date: str(v.date, nowIso().slice(0, 10)), startMinute: start, durationMinutes: duration,
    estimatedPomodoros: Math.max(1, num(v.estimatedPomodoros, Math.round(duration / 25))),
    priority: oneOf<Priority>(v.priority, ['low', 'medium', 'high'], 'medium'),
    recurrence: oneOf<Recurrence>(v.recurrence, ['none', 'daily', 'weekdays', 'weekly', 'custom'], 'none'),
    recurDays: numArr(v.recurDays).filter((d) => d >= 0 && d <= 6), recurUntil: optStr(v.recurUntil),
    skippedDates: strArr(v.skippedDates), completedDates: strArr(v.completedDates), topThreeDates: strArr(v.topThreeDates),
    kind: oneOf<BlockKind>(v.kind, ['study', 'class', 'revision'], 'study'), examId: optStr(v.examId),
    createdAt: str(v.createdAt, nowIso()), updatedAt: str(v.updatedAt, nowIso()),
  };
}

function normalizeSession(v: unknown): FocusSession | null {
  if (!isRec(v) || !str(v.id) || !str(v.startedAt)) return null;
  const actualMinutes = Math.max(0, num(v.actualMinutes, 0));
  const interruptions = Math.max(0, num(v.interruptions, 0));
  return {
    id: str(v.id), taskId: optStr(v.taskId), subjectId: optStr(v.subjectId), startedAt: str(v.startedAt),
    endedAt: str(v.endedAt, str(v.startedAt)), plannedMinutes: num(v.plannedMinutes, actualMinutes), actualMinutes,
    actualSeconds: num(v.actualSeconds, actualMinutes * 60), completed: bool(v.completed, true),
    interrupted: bool(v.interrupted, interruptions > 0), interruptions, distractions: strArr(v.distractions),
  };
}

function normalizeReview(v: unknown): DailyReview | null {
  if (!isRec(v) || !str(v.date)) return null;
  return {
    date: str(v.date), worked: str(v.worked), fix: str(v.fix), gratitude: str(v.gratitude), quickNotes: str(v.quickNotes),
    distractionNotes: str(v.distractionNotes), convertedDistractions: strArr(v.convertedDistractions),
    mood: num(v.mood, 0), energy: num(v.energy, 0), water: num(v.water, 0), sleepHours: num(v.sleepHours, 0),
    steps: num(v.steps, 0), productivity: num(v.productivity, 0), updatedAt: str(v.updatedAt, nowIso()),
  };
}

/** Turn legacy free-text syllabus ("Algebra, quadratics\nFunctions") into checklist topics. */
export function topicsFromSyllabus(text: string, idPrefix: string): ExamTopic[] {
  return text.split(/[\n,;•]+/).map((part) => part.trim()).filter(Boolean)
    .map((title, index) => ({ id: `${idPrefix}_t${index + 1}`, title, done: false }));
}

function normalizeExam(v: unknown): Exam | null {
  if (!isRec(v) || !str(v.id)) return null;
  const syllabus = str(v.syllabus);
  const topics: ExamTopic[] = Array.isArray(v.topics)
    ? v.topics.filter(isRec).map((t, index) => ({ id: str(t.id, `${str(v.id)}_t${index + 1}`), title: str(t.title, 'Topic'), done: bool(t.done, false) }))
    : topicsFromSyllabus(syllabus, str(v.id));
  return {
    id: str(v.id), title: str(v.title, 'Exam'), subjectId: optStr(v.subjectId), date: str(v.date, nowIso().slice(0, 10)),
    time: str(v.time, '09:00'), syllabus: Array.isArray(v.topics) ? syllabus : '', topics, createdAt: str(v.createdAt, nowIso()),
  };
}

export function normalizeSettings(v: unknown): AppSettings {
  const s = isRec(v) ? v : {};
  const d = defaultSettings;
  return {
    name: str(s.name, d.name), focusMinutes: num(s.focusMinutes, d.focusMinutes), shortBreakMinutes: num(s.shortBreakMinutes, d.shortBreakMinutes),
    longBreakMinutes: num(s.longBreakMinutes, d.longBreakMinutes), longBreakEvery: Math.max(2, num(s.longBreakEvery, d.longBreakEvery)),
    dailyGoalMinutes: num(s.dailyGoalMinutes, d.dailyGoalMinutes), waterGoal: num(s.waterGoal, d.waterGoal),
    theme: oneOf<ThemeMode>(s.theme, ['system', 'light', 'dark'], d.theme),
    language: oneOf<LanguagePreference>(s.language, ['system', 'english', 'hindi'], d.language), autoSync: bool(s.autoSync, d.autoSync),
    weekStartsMonday: bool(s.weekStartsMonday, d.weekStartsMonday), notifyFocusEnd: bool(s.notifyFocusEnd, d.notifyFocusEnd),
    notifyBreakEnd: bool(s.notifyBreakEnd, d.notifyBreakEnd), notifyBlockStart: bool(s.notifyBlockStart, d.notifyBlockStart),
    blockLeadMinutes: num(s.blockLeadMinutes, d.blockLeadMinutes), notificationsPrompted: bool(s.notificationsPrompted, d.notificationsPrompted),
    focusSound: oneOf<FocusSoundKind>(s.focusSound, ['none', 'white', 'rain', 'ambience'], d.focusSound),
    strictMode: bool(s.strictMode, d.strictMode), planStartMinute: num(s.planStartMinute, d.planStartMinute), planEndMinute: num(s.planEndMinute, d.planEndMinute),
  };
}

function compact<T>(items: (T | null)[]): T[] {
  return items.filter((item): item is T => item !== null);
}

/** Validate and upgrade any supported data shape to the current AppData. Returns null if unusable. */
export function normalizeData(raw: unknown): AppData | null {
  if (!isRec(raw)) return null;
  const hasCollections = ['tasks', 'subjects', 'sessions', 'reviews', 'exams'].every((key) => Array.isArray(raw[key]));
  if (!hasCollections || !isRec(raw.settings)) return null;
  const list = (key: string): unknown[] => (Array.isArray(raw[key]) ? (raw[key] as unknown[]) : []);
  const meta = isRec(raw.meta) ? raw.meta : {};
  const hasContent = ['tasks', 'sessions', 'reviews', 'exams', 'subjects'].some((key) => list(key).length > 0);
  return {
    tasks: compact(list('tasks').map(normalizeTask)),
    subjects: compact(list('subjects').map(normalizeSubject)),
    sessions: compact(list('sessions').map(normalizeSession)),
    reviews: compact(list('reviews').map(normalizeReview)),
    exams: compact(list('exams').map(normalizeExam)),
    settings: normalizeSettings(raw.settings),
    meta: {
      updatedAt: str(meta.updatedAt, nowIso()), lastSyncedAt: optStr(meta.lastSyncedAt), dirty: bool(meta.dirty, false),
      edited: bool(meta.edited, hasContent),
    },
  };
}

export interface DataCounts {
  tasks: number; subjects: number; sessions: number; reviews: number; exams: number; topics: number;
}

export function countData(data: Pick<AppData, 'tasks' | 'subjects' | 'sessions' | 'reviews' | 'exams'>): DataCounts {
  return {
    tasks: data.tasks.length, subjects: data.subjects.length, sessions: data.sessions.length,
    reviews: data.reviews.length, exams: data.exams.length, topics: data.exams.reduce((sum, e) => sum + e.topics.length, 0),
  };
}

export function hasAnyContent(counts: DataCounts): boolean {
  return counts.tasks + counts.subjects + counts.sessions + counts.reviews + counts.exams > 0;
}

/**
 * Detects the untouched sample workspace that early FocusFlow builds created on first run
 * (ids task_1…task_10 / subject_1…subject_4 / exam_1…exam_2) so it can be dropped on upgrade.
 */
export function isDemoData(data: AppData): boolean {
  if (!data.tasks.length && !data.subjects.length) return false;
  const demoTask = /^task_(\d+)$/;
  const demoSubject = /^subject_[1-4]$/;
  const demoExam = /^exam_[12]$/;
  return data.tasks.every((t) => demoTask.test(t.id)) && data.subjects.every((s) => demoSubject.test(s.id))
    && data.exams.every((e) => demoExam.test(e.id)) && data.subjects.length > 0 && data.subjects.length <= 4;
}

import { TimerState, TimerStatus, TimerMode } from '../types';

/** Upgrade a stored timer (new or legacy v1 shape) to the current TimerState. */
export function normalizeTimer(raw: unknown, focusMinutes: number): TimerState | null {
  if (!isRec(raw)) return null;
  const mode = oneOf<TimerMode>(raw.mode, ['focus', 'shortBreak', 'longBreak'], 'focus');
  const duration = num(raw.durationSeconds, focusMinutes * 60);
  const base = {
    mode, taskId: optStr(raw.taskId), subjectId: optStr(raw.subjectId), durationSeconds: duration,
    remainingSeconds: num(raw.remainingSeconds, duration), endAt: typeof raw.endAt === 'number' ? raw.endAt : undefined,
    startedAt: optStr(raw.startedAt), distractions: strArr(raw.distractions),
  };
  if (typeof raw.status === 'string') {
    const status = oneOf<TimerStatus>(raw.status, ['idle', 'running', 'paused', 'completed'], 'idle');
    return {
      ...base, status, completedFocus: Math.max(0, num(raw.completedFocus, 0)), lastCompletedDay: optStr(raw.lastCompletedDay),
      interruptions: Math.max(0, num(raw.interruptions, 0)),
      summary: isRec(raw.summary) ? (raw.summary as unknown as TimerState['summary']) : undefined,
    };
  }
  // legacy shape: isRunning / cycle
  const running = raw.isRunning === true && base.endAt !== undefined;
  const paused = !running && Boolean(base.startedAt) && base.remainingSeconds > 0;
  return {
    ...base, status: running ? 'running' : paused ? 'paused' : 'idle', completedFocus: Math.max(0, num(raw.cycle, 0)),
    interruptions: 0, endAt: running ? base.endAt : undefined,
    ...(running || paused ? {} : { remainingSeconds: focusMinutes * 60, durationSeconds: focusMinutes * 60, startedAt: undefined }),
  };
}
