import React, { useMemo, useState } from 'react';
import { FlatList, View } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { MainTabParamList, RootStackParamList } from '../navigation/types';
import { StudyTask } from '../types';
import { addDays, makeId, todayKey, weekDates } from '../utils/date';
import { isTaskComplete, tasksForDate } from '../utils/selectors';
import { Badge, Button, Card, EmptyState, Header, IconButton, Screen, Segmented } from '../components/ui';
import { Text } from '../components/Text';
import WeekStrip from '../components/WeekStrip';
import TaskItem from '../components/TaskItem';
import TimeGrid, { GridDraft } from '../components/TimeGrid';
import QuickAddBar from '../components/QuickAddBar';
import { useDialog } from '../components/DialogHost';
import { useFocusLauncher } from '../components/FocusLauncher';
import { useI18n } from '../i18n';

type View3 = 'day' | 'week' | 'list';

export default function PlannerScreen() {
  const theme = useTheme();
  const { planner: P, shared: S, formatDuration, formatShortDate, relativeDay } = useI18n();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const route = useRoute<RouteProp<MainTabParamList, 'Planner'>>();
  const dialog = useDialog();
  const launch = useFocusLauncher();
  const { data, toggleTask, autoSchedule, saveTask, saveTasks } = useApp();
  const [selectedDate, setSelectedDate] = useState(route.params?.date || todayKey());
  const [view, setView] = useState<View3>('day');
  const tasks = useMemo(() => tasksForDate(data.tasks, selectedDate), [data.tasks, selectedDate]);
  const unscheduled = tasks.filter((task) => task.startMinute === undefined);
  const plannedMinutes = tasks.reduce((sum, task) => sum + task.durationMinutes, 0);
  const done = tasks.filter((task) => isTaskComplete(task, selectedDate)).length;
  const days = useMemo(() => weekDates(selectedDate, data.settings.weekStartsMonday), [selectedDate, data.settings.weekStartsMonday]);
  const gridDates = useMemo(() => (view === 'week' ? days : [selectedDate]), [view, days, selectedDate]);
  const subjectOf = (task: StudyTask) => data.subjects.find((s) => s.id === task.subjectId);
  const hasAnything = data.tasks.length > 0;

  React.useEffect(() => {
    if (route.params?.date) setSelectedDate(route.params.date);
  }, [route.params?.date]);

  const openTask = (task: StudyTask, date: string) => navigation.navigate('TaskForm', { taskId: task.id, date });
  const create = (draft: GridDraft, title: string | null) => {
    if (title === null) {
      navigation.navigate('TaskForm', { date: draft.date, startMinute: draft.start, duration: draft.duration });
      return;
    }
    const now = new Date().toISOString();
    saveTask({
      id: makeId('task'), title, notes: '', subjectId: data.subjects.find((s) => !s.archived)?.id, date: draft.date, startMinute: draft.start,
      durationMinutes: draft.duration, estimatedPomodoros: Math.max(1, Math.ceil(draft.duration / data.settings.focusMinutes)), priority: 'medium',
      recurrence: 'none', recurDays: [], skippedDates: [], completedDates: [], topThreeDates: [], kind: 'study', createdAt: now, updatedAt: now,
    });
  };

  const moveTask = async (task: StudyTask, fromDate: string, toDate: string, startMinute: number) => {
    const now = new Date().toISOString();
    if (task.recurrence === 'none') {
      saveTask({ ...task, date: toDate, startMinute });
      return;
    }
    const choice = await dialog.choose({
      title: P.moveRecurringTitle, message: P.moveRecurringMessage(task.title),
      options: [{ id: 'one', label: P.moveOnlyThis, tone: 'primary' }, { id: 'all', label: P.moveAll }, { id: 'cancel', label: P.moveCancel }],
    });
    if (choice === 'one') {
      // the series skips this day; a one-off copy carries the new day/time
      const skipped: StudyTask = { ...task, skippedDates: [...task.skippedDates, fromDate].sort() };
      const copy: StudyTask = {
        ...task, id: makeId('task'), date: toDate, startMinute, recurrence: 'none', recurDays: [], recurUntil: undefined,
        skippedDates: [], completedDates: [], topThreeDates: [], createdAt: now, updatedAt: now,
      };
      saveTasks([skipped, copy]);
    } else if (choice === 'all') {
      const shift = Math.round((new Date(`${toDate}T12:00:00`).getTime() - new Date(`${fromDate}T12:00:00`).getTime()) / 86400000);
      if (task.recurrence === 'custom') {
        const moved = task.recurDays.map((d) => (((d + shift) % 7) + 7) % 7);
        saveTask({ ...task, startMinute, recurDays: moved, date: occursOnCustomStart(task, moved) });
      } else if (task.recurrence === 'weekly') saveTask({ ...task, startMinute, date: addDays(task.date, shift) });
      else saveTask({ ...task, startMinute });
    }
  };

  const runAutoSchedule = async () => {
    const count = autoSchedule(selectedDate);
    if (count) await dialog.alert(P.autoPlacedTitle, P.autoPlaced(count));
    else await dialog.alert(P.nothingToPlace, P.nothingToPlaceMessage);
  };

  const shift = view === 'week' ? 7 : 1;
  const rangeLabel = view === 'week' ? P.weekRange(formatShortDate(days[0]), formatShortDate(days[6])) : relativeDay(selectedDate);

  const controls = (
    <View style={{ paddingHorizontal: 16, gap: 10, paddingBottom: 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 2, flex: 1 }}>
          <IconButton icon="chevron-back" label={view === 'week' ? P.prevWeek : P.prevDay} onPress={() => setSelectedDate(addDays(selectedDate, -shift))} />
          <View style={{ flexShrink: 1 }}>
            <Text numberOfLines={1} style={{ color: theme.text, fontSize: 18, fontWeight: '900' }}>{rangeLabel}</Text>
            <Text numberOfLines={1} style={{ color: theme.muted, fontSize: 12 }}>{P.blocksSummary(tasks.length, done)}</Text>
          </View>
          <IconButton icon="chevron-forward" label={view === 'week' ? P.nextWeek : P.nextDay} onPress={() => setSelectedDate(addDays(selectedDate, shift))} />
        </View>
        <Badge text={formatDuration(plannedMinutes)} />
        <IconButton icon="today-outline" label={P.jumpToday} filled onPress={() => setSelectedDate(todayKey())} />
      </View>
      <Segmented<View3> value={view} onChange={setView} options={[
        { value: 'day', label: P.viewDay, icon: 'today' }, { value: 'week', label: P.viewWeek, icon: 'calendar' }, { value: 'list', label: P.viewList, icon: 'list' },
      ]} />
    </View>
  );

  return (
    <Screen>
      <Header title={P.title} right={<View style={{ flexDirection: 'row', gap: 4 }}>
        <IconButton icon="school-outline" label={S.classTimetable} filled onPress={() => navigation.navigate('Timetable')} />
        <IconButton icon="add" label={P.addBlock} filled onPress={() => navigation.navigate('TaskForm', { date: selectedDate })} />
      </View>} />
      {view === 'day' && <WeekStrip selected={selectedDate} monday={data.settings.weekStartsMonday} onSelect={setSelectedDate} />}
      <View style={{ paddingHorizontal: 16, paddingBottom: 8 }}><QuickAddBar onAdded={(date) => setSelectedDate(date)} /></View>
      {controls}

      {view === 'list' ? (
        <FlatList data={tasks} keyExtractor={(item) => item.id} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 30, gap: 8 }}
          renderItem={({ item }) => (
            <Card style={{ paddingVertical: 2, paddingHorizontal: 12, borderLeftWidth: 4, borderLeftColor: subjectOf(item)?.color || theme.primary }}>
              <TaskItem task={item} date={selectedDate} subject={subjectOf(item)} onToggle={() => toggleTask(item.id, selectedDate)}
                onPress={() => openTask(item, selectedDate)} onFocus={() => { launch(item.id, item.subjectId); }} />
            </Card>
          )}
          ListEmptyComponent={hasAnything
            ? <Text style={{ color: theme.muted, textAlign: 'center', paddingVertical: 28 }}>{P.listEmpty}</Text>
            : <EmptyState icon="calendar-outline" title={P.emptyTitle} message={P.emptyMessage} action={P.emptyAction} onAction={() => navigation.navigate('TaskForm', { date: selectedDate })} />}
        />
      ) : (
        <View style={{ flex: 1 }}>
          {unscheduled.length > 0 && (
            <View style={{ paddingHorizontal: 16, paddingBottom: 8, gap: 6 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <Text style={{ color: theme.muted, fontSize: 12, fontWeight: '800' }}>{P.anytime.toUpperCase()} · {P.anytimeOpen(unscheduled.length)}</Text>
                <Button title={P.autoPlace} icon="sparkles" variant="secondary" onPress={runAutoSchedule} style={{ minHeight: 38, paddingHorizontal: 12 }} />
              </View>
              {unscheduled.slice(0, 3).map((task) => (
                <Card key={task.id} style={{ paddingVertical: 0, paddingHorizontal: 12 }}>
                  <TaskItem compact task={task} date={selectedDate} subject={subjectOf(task)} onToggle={() => toggleTask(task.id, selectedDate)}
                    onPress={() => openTask(task, selectedDate)} onFocus={() => { launch(task.id, task.subjectId); }} />
                </Card>
              ))}
              {unscheduled.length > 3 && <Text style={{ color: theme.muted, fontSize: 12 }}>{S.moreInList(unscheduled.length - 3)}</Text>}
            </View>
          )}
          <TimeGrid key={view} dates={gridDates} tasks={data.tasks} subjects={data.subjects} defaultDuration={data.settings.focusMinutes}
            onOpenTask={openTask} onPlay={(task) => { launch(task.id, task.subjectId); }} onCreate={create} onMove={moveTask}
            onSelectDate={(date) => { setSelectedDate(date); setView('day'); }} />
        </View>
      )}
    </Screen>
  );
}

/** When a custom weekly pattern is shifted, keep the series start date on a day that is part of the pattern. */
function occursOnCustomStart(task: StudyTask, days: number[]): string {
  for (let i = 0; i < 7; i += 1) {
    const candidate = addDays(task.date, i);
    if (days.includes(new Date(`${candidate}T12:00:00`).getDay())) return candidate;
  }
  return task.date;
}

