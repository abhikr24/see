import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { RootStackParamList } from '../navigation/types';
import { DailyReview, StudyTask } from '../types';
import { addDays, makeId, todayKey } from '../utils/date';
import { focusMinutesForDate, isTaskComplete, reviewForDate, tasksForDate } from '../utils/selectors';
import { distractionKey, groupDistractions } from '../utils/distractions';
import { Badge, Button, Card, Divider, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, Segmented } from '../components/ui';
import { Text } from '../components/Text';
import { IconName } from '../components/icons';
import { useI18n } from '../i18n';

function blankReview(date: string): DailyReview {
  return { date, worked: '', fix: '', gratitude: '', quickNotes: '', distractionNotes: '', convertedDistractions: [], mood: 0, energy: 0,
    water: 0, sleepHours: 0, steps: 0, productivity: 0, updatedAt: new Date().toISOString() };
}

export default function ReviewScreen() {
  const theme = useTheme();
  const { review: R, formatDuration, formatLongDate, formatShortDate, relativeDay } = useI18n();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data, timer, saveReview, saveTask, toggleTopThree, toggleTask } = useApp();
  const [date, setDate] = useState(todayKey());
  const [tab, setTab] = useState<'checkin' | 'history'>('checkin');
  const [draft, setDraft] = useState<DailyReview>(() => reviewForDate(data.reviews, todayKey()) || blankReview(todayKey()));
  const [sleepInput, setSleepInput] = useState(() => {
    const hours = reviewForDate(data.reviews, todayKey())?.sleepHours;
    return hours ? String(hours) : '';
  });
  const [saved, setSaved] = useState(false);
  const tomorrow = addDays(date, 1);
  const tomorrowTasks = tasksForDate(data.tasks, tomorrow);
  const topTomorrow = tomorrowTasks.filter((task) => task.topThreeDates.includes(tomorrow));
  const history = [...data.reviews].sort((a, b) => b.date.localeCompare(a.date));
  const groups = useMemo(() => groupDistractions(data.sessions, date, date === todayKey() ? timer.distractions : []), [data.sessions, date, timer.distractions]);

  useEffect(() => {
    const stored = reviewForDate(data.reviews, date);
    setDraft(stored || blankReview(date));
    setSleepInput(stored?.sleepHours ? String(stored.sleepHours) : '');
    setSaved(false);
    // Loading a different day intentionally resets the form from storage.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const patch = (value: Partial<DailyReview>) => { setDraft((previous) => ({ ...previous, ...value })); setSaved(false); };
  const save = () => { saveReview({ ...draft, date, updatedAt: new Date().toISOString() }); setSaved(true); };

  const makeTask = (label: string, key: string) => {
    const now = new Date().toISOString();
    const task: StudyTask = {
      id: makeId('task'), title: R.taskFromDistraction(label), notes: '', date: tomorrow, durationMinutes: 15, estimatedPomodoros: 1, priority: 'low',
      recurrence: 'none', recurDays: [], skippedDates: [], completedDates: [], topThreeDates: [], kind: 'study', createdAt: now, updatedAt: now,
    };
    saveTask(task);
    const next = { ...draft, convertedDistractions: [...draft.convertedDistractions, key], date, updatedAt: now };
    setDraft(next);
    saveReview(next);
  };

  const moods: { label: string; icon: IconName }[] = [
    { label: R.moods[0], icon: 'sad-outline' }, { label: R.moods[1], icon: 'cloudy-outline' }, { label: R.moods[2], icon: 'remove-outline' },
    { label: R.moods[3], icon: 'happy-outline' }, { label: R.moods[4], icon: 'sunny-outline' },
  ];
  const dayTasks = tasksForDate(data.tasks, date);

  return (
    <Screen>
      <Header title={R.title} subtitle={R.subtitle} right={tab === 'checkin' ? <IconButton icon="checkmark" label={R.save} filled onPress={save} /> : undefined} />
      <View style={{ paddingHorizontal: 20, paddingBottom: 16 }}><Segmented value={tab} onChange={setTab} options={[{ value: 'checkin', label: R.tabCheckin, icon: 'create-outline' }, { value: 'history', label: R.tabHistory, icon: 'time-outline' }]} /></View>
      {tab === 'checkin' ? <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 18 }}>
        <Card style={{ paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <IconButton icon="chevron-back" label={R.prevDay} onPress={() => setDate(addDays(date, -1))} />
          <View style={{ alignItems: 'center', flexShrink: 1 }}><Text style={{ color: theme.text, fontSize: 16, fontWeight: '900' }}>{relativeDay(date)}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3, textAlign: 'center' }}>{formatLongDate(date)}</Text></View>
          <IconButton icon="chevron-forward" label={R.nextDay} onPress={() => date < todayKey() && setDate(addDays(date, 1))} color={date < todayKey() ? theme.text : theme.faint} />
        </Card>

        <Card style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 10 }}><View><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{R.glance}</Text>
            <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900', marginTop: 7 }}>{formatDuration(focusMinutesForDate(data.sessions, date))}</Text></View>
            <View style={{ alignItems: 'flex-end' }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{R.blocksDoneLabel}</Text>
              <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900', marginTop: 7 }}>{dayTasks.filter((task) => isTaskComplete(task, date)).length}/{dayTasks.length}</Text></View></View>
        </Card>

        <Card style={{ gap: 10 }}>
          <SectionTitle title={R.parked} icon="car-outline" />
          <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18 }}>{R.parkedHint}</Text>
          {groups.length === 0 && <Text style={{ color: theme.muted, fontStyle: 'italic', paddingVertical: 6 }}>{R.parkedNone}</Text>}
          {groups.map((group) => {
            const done = draft.convertedDistractions.includes(group.key) || draft.convertedDistractions.includes(distractionKey(group.label));
            return (
              <View key={group.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6 }}>
                <Badge text={R.parkedCount(group.count)} color={theme.warning} />
                <Text style={{ color: theme.text, flex: 1, fontWeight: '600' }}>{group.label}</Text>
                {done
                  ? <View style={{ flexDirection: 'row', gap: 4, alignItems: 'center' }}><Ionicons name="checkmark-circle" size={18} color={theme.success} /><Text style={{ color: theme.success, fontSize: 12, fontWeight: '700' }}>{R.converted}</Text></View>
                  : <Button title={R.toTask} icon="add" variant="secondary" onPress={() => makeTask(group.label, group.key)} style={{ minHeight: 40, paddingHorizontal: 12 }} />}
              </View>
            );
          })}
          {groups.some((g) => draft.convertedDistractions.includes(g.key)) && <Text style={{ color: theme.muted, fontSize: 12 }}>{R.taskCreated(formatShortDate(tomorrow))}</Text>}
        </Card>

        <Field label={R.worked} value={draft.worked} onChangeText={(worked) => patch({ worked })} multiline placeholder={R.workedPh} />
        <Field label={R.fix} value={draft.fix} onChangeText={(fix) => patch({ fix })} multiline placeholder={R.fixPh} />
        <Field label={R.gratitude} value={draft.gratitude} onChangeText={(gratitude) => patch({ gratitude })} multiline placeholder={R.gratitudePh} />

        <Card style={{ gap: 15 }}>
          <SectionTitle title={R.moodEnergy} icon="happy-outline" />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            {moods.map((mood, index) => <Pressable key={mood.label} accessibilityRole="button" accessibilityLabel={mood.label} onPress={() => patch({ mood: index + 1 })} style={{ alignItems: 'center', gap: 6, opacity: draft.mood === index + 1 ? 1 : 0.45 }}>
              <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: draft.mood === index + 1 ? theme.accent : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={mood.icon} size={24} color={draft.mood === index + 1 ? theme.accentText : theme.muted} /></View>
              <Text maxFontSizeMultiplier={1.2} style={{ color: theme.text, fontSize: 10, fontWeight: '700' }}>{mood.label}</Text></Pressable>)}
          </View>
          <Divider />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ color: theme.text, fontWeight: '700' }}>{R.energy}</Text><Badge text={draft.energy ? `${draft.energy}/5` : R.notSet} /></View>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', minHeight: 42 }}>
            {[1, 2, 3, 4, 5].map((level) => <Pressable key={level} accessibilityRole="button" accessibilityLabel={`${R.energy} ${level}`} onPress={() => patch({ energy: level })} style={{ flex: 1, height: 12 + level * 6, borderRadius: 6, backgroundColor: level <= draft.energy ? theme.primary : theme.surfaceAlt }} />)}
          </View>
          <Divider />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ color: theme.text, fontWeight: '700' }}>{R.productivity}</Text><Badge text={draft.productivity ? `${draft.productivity}/5` : R.notSet} /></View>
          <View style={{ flexDirection: 'row', gap: 7 }}>{[1, 2, 3, 4, 5].map((level) => <Pressable key={level} accessibilityRole="button" accessibilityLabel={`${R.productivity} ${level}`} onPress={() => patch({ productivity: level })}
            style={{ flex: 1, minHeight: 40, borderRadius: 11, backgroundColor: level <= draft.productivity ? theme.primarySoft : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="star" size={17} color={level <= draft.productivity ? theme.primary : theme.faint} /></Pressable>)}</View>
        </Card>

        <Card style={{ gap: 14 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}><SectionTitle title={R.water} icon="water-outline" /><Badge text={R.glasses(draft.water, data.settings.waterGoal)} /></View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {Array.from({ length: data.settings.waterGoal }, (_, index) => <Pressable key={index} accessibilityRole="button" onPress={() => patch({ water: index + 1 === draft.water ? index : index + 1 })}
              style={{ width: 40, minHeight: 44, borderRadius: 10, borderWidth: 1, borderColor: index < draft.water ? '#4D91A8' : theme.border, backgroundColor: index < draft.water ? '#4D91A833' : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name={index < draft.water ? 'water' : 'water-outline'} color="#4D91A8" size={21} /></Pressable>)}
          </View>
          <ProgressBar value={draft.water} max={data.settings.waterGoal} color="#4D91A8" />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Field label={R.sleep} value={sleepInput} onChangeText={(text) => {
              const clean = text.replace(/[^0-9.]/g, '');
              if ((clean.match(/\./g) || []).length > 1) return;
              setSleepInput(clean);
              patch({ sleepHours: Math.min(24, Math.max(0, Number.parseFloat(clean) || 0)) });
            }} onBlur={() => setSleepInput(draft.sleepHours ? String(draft.sleepHours) : '')} keyboardType="decimal-pad" placeholder="7.5" /></View>
            <View style={{ flex: 1 }}><Field label={R.steps} value={draft.steps ? String(draft.steps) : ''} onChangeText={(text) => patch({ steps: Number(text.replace(/\D/g, '')) || 0 })} keyboardType="number-pad" placeholder="6000" /></View>
          </View>
        </Card>

        <Field label={R.quickNotes} value={draft.quickNotes} onChangeText={(quickNotes) => patch({ quickNotes })} multiline placeholder={R.quickNotesPh} />
        <Field label={R.distractionNotes} value={draft.distractionNotes} onChangeText={(distractionNotes) => patch({ distractionNotes })} multiline placeholder={R.distractionNotesPh} />

        <Card style={{ gap: 8 }}>
          <SectionTitle title={R.tomorrowTitle} icon="sunny-outline" action={R.add} onAction={() => navigation.navigate('TaskForm', { date: tomorrow })} />
          <Text style={{ color: theme.muted, fontSize: 12, marginBottom: 5 }}>{R.tomorrowHint}</Text>
          {tomorrowTasks.map((task) => {
            const selected = task.topThreeDates.includes(tomorrow);
            return <Pressable key={task.id} accessibilityRole="button" onPress={() => { if (!selected && topTomorrow.length >= 3) return; toggleTopThree(task.id, tomorrow); }}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9, opacity: !selected && topTomorrow.length >= 3 ? 0.4 : 1 }}>
              <Ionicons name={selected ? 'star' : 'star-outline'} color={selected ? theme.warning : theme.muted} size={21} />
              <Text style={{ color: theme.text, flex: 1, fontWeight: selected ? '800' : '500' }}>{task.title}</Text>
              <Pressable hitSlop={8} onPress={() => toggleTask(task.id, tomorrow)}><Ionicons name={isTaskComplete(task, tomorrow) ? 'checkmark-circle' : 'ellipse-outline'} size={20} color={theme.primary} /></Pressable>
            </Pressable>;
          })}
          {!tomorrowTasks.length && <Text style={{ color: theme.muted, fontStyle: 'italic', paddingVertical: 10 }}>{R.tomorrowEmpty}</Text>}
        </Card>
        <Button title={saved ? R.saved : R.saveDaily} icon={saved ? 'checkmark-circle' : 'checkmark'} variant={saved ? 'secondary' : 'primary'} onPress={save} />
      </ScrollView> : <FlatList data={history} keyExtractor={(item) => item.date} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 35, gap: 12 }}
        renderItem={({ item }) => <Card onPress={() => { setDate(item.date); setTab('checkin'); }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}><View><Text style={{ color: theme.text, fontSize: 16, fontWeight: '900' }}>{relativeDay(item.date)}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{formatShortDate(item.date)}</Text></View>
            <View style={{ flexDirection: 'row', gap: 7 }}><Badge text={R.focusBadge(formatDuration(focusMinutesForDate(data.sessions, item.date)))} />{item.productivity > 0 && <Badge text={`${item.productivity}/5`} color={theme.warning} />}</View></View>
          {!!item.worked && <><Divider /><Text style={{ color: theme.primary, fontSize: 11, fontWeight: '900' }}>{R.worked2}</Text><Text style={{ color: theme.text, lineHeight: 20, marginTop: 5 }}>{item.worked}</Text></>}
          {!!item.fix && <View style={{ marginTop: 12 }}><Text style={{ color: theme.warning, fontSize: 11, fontWeight: '900' }}>{R.fix2}</Text><Text style={{ color: theme.muted, lineHeight: 20, marginTop: 5 }}>{item.fix}</Text></View>}
          <View style={{ flexDirection: 'row', gap: 15, marginTop: 14, flexWrap: 'wrap' }}><Text style={{ color: theme.muted, fontSize: 12 }}>{R.water2(item.water)}</Text><Text style={{ color: theme.muted, fontSize: 12 }}>{R.sleep2(String(item.sleepHours || '—'))}</Text><Text style={{ color: theme.muted, fontSize: 12 }}>{R.mood2(String(item.mood || '—'))}</Text></View>
        </Card>}
        ListEmptyComponent={<EmptyState icon="journal-outline" title={R.historyEmptyTitle} message={R.historyEmptyMessage} action={R.historyEmptyAction} onAction={() => setTab('checkin')} />}
      />}
    </Screen>
  );
}
