export type Priority = 'low' | 'medium' | 'high';
export type Recurrence = 'none' | 'daily' | 'weekdays' | 'weekly' | 'custom';
export type ThemeMode = 'system' | 'light' | 'dark';
export type LanguagePreference = 'system' | 'english' | 'hindi';
export type BlockKind = 'study' | 'class' | 'revision';
export type FocusSoundKind = 'none' | 'white' | 'rain' | 'ambience';

export interface Subject {
  id: string;
  name: string;
  color: string;
  icon: string;
  weeklyGoalMinutes: number;
  archived: boolean;
  createdAt: string;
}

export interface StudyTask {
  id: string;
  title: string;
  notes: string;
  subjectId?: string;
  /** First (or only) date of the block. */
  date: string;
  /** Minutes from midnight, 0..1439. Undefined means "anytime". */
  startMinute?: number;
  durationMinutes: number;
  estimatedPomodoros: number;
  priority: Priority;
  recurrence: Recurrence;
  /** Weekdays (0 = Sunday … 6 = Saturday) used when recurrence === 'custom'. */
  recurDays: number[];
  /** Last date (inclusive) a recurring block can occur. */
  recurUntil?: string;
  /** Individual occurrences that were cancelled without deleting the series. */
  skippedDates: string[];
  completedDates: string[];
  topThreeDates: string[];
  kind: BlockKind;
  examId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface FocusSession {
  id: string;
  taskId?: string;
  subjectId?: string;
  startedAt: string;
  endedAt: string;
  plannedMinutes: number;
  actualMinutes: number;
  actualSeconds: number;
  completed: boolean;
  interrupted: boolean;
  interruptions: number;
  distractions: string[];
}

export interface DailyReview {
  date: string;
  worked: string;
  fix: string;
  gratitude: string;
  quickNotes: string;
  distractionNotes: string;
  /** Parked distractions already turned into tasks (normalised text). */
  convertedDistractions: string[];
  mood: number;
  energy: number;
  water: number;
  sleepHours: number;
  steps: number;
  productivity: number;
  updatedAt: string;
}

export interface ExamTopic {
  id: string;
  title: string;
  done: boolean;
}

export interface Exam {
  id: string;
  title: string;
  subjectId?: string;
  date: string;
  time: string;
  /** Legacy free-text syllabus; kept for old backups and as extra notes. */
  syllabus: string;
  topics: ExamTopic[];
  createdAt: string;
}

export interface AppSettings {
  name: string;
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakEvery: number;
  dailyGoalMinutes: number;
  waterGoal: number;
  theme: ThemeMode;
  language: LanguagePreference;
  autoSync: boolean;
  weekStartsMonday: boolean;
  notifyFocusEnd: boolean;
  notifyBreakEnd: boolean;
  notifyBlockStart: boolean;
  blockLeadMinutes: number;
  notificationsPrompted: boolean;
  focusSound: FocusSoundKind;
  strictMode: boolean;
  planStartMinute: number;
  planEndMinute: number;
}

export interface AppMeta {
  updatedAt: string;
  lastSyncedAt?: string;
  /** Local changes not yet uploaded. */
  dirty: boolean;
  /** True once the user (or a cloud download) put real data on this device. */
  edited: boolean;
}

export interface AppData {
  tasks: StudyTask[];
  subjects: Subject[];
  sessions: FocusSession[];
  reviews: DailyReview[];
  exams: Exam[];
  settings: AppSettings;
  meta: AppMeta;
}

export type TimerMode = 'focus' | 'shortBreak' | 'longBreak';
export type TimerStatus = 'idle' | 'running' | 'paused' | 'completed';

export interface TimerSummary {
  mode: TimerMode;
  plannedMinutes: number;
  actualMinutes: number;
  actualSeconds: number;
  early: boolean;
  saved: boolean;
  interruptions: number;
  distractionCount: number;
  nextBreak: 'shortBreak' | 'longBreak';
}

export interface TimerState {
  mode: TimerMode;
  status: TimerStatus;
  taskId?: string;
  subjectId?: string;
  durationSeconds: number;
  remainingSeconds: number;
  endAt?: number;
  startedAt?: string;
  /** Number of fully completed focus sessions in the current Pomodoro set. */
  completedFocus: number;
  lastCompletedDay?: string;
  distractions: string[];
  interruptions: number;
  summary?: TimerSummary;
}

export type SyncStrategy = 'sync' | 'upload' | 'download';
