import 'react-native-url-polyfill/auto';
import React from 'react';
import { StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AppProvider } from './src/store/AppContext';
import RootNavigator from './src/navigation/RootNavigator';
import { DialogProvider } from './src/components/DialogHost';
import { NotificationBridge } from './src/components/NotificationBridge';
import { FocusSoundWatcher, StrictModeWatcher } from './src/components/SessionWatchers';
import CompletionOverlay from './src/components/CompletionOverlay';
import { common } from './src/i18n/base';

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={styles.root}>
      <SafeAreaProvider>
        <AppProvider>
          <DialogProvider okLabel={common.ok}>
            <NotificationBridge>
              <RootNavigator />
              <CompletionOverlay />
              <StrictModeWatcher />
              <FocusSoundWatcher />
            </NotificationBridge>
          </DialogProvider>
        </AppProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({ root: { flex: 1 } });
