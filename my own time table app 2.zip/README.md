# FocusFlow

A finished, offline-first study planner built with Expo, React Native, and TypeScript. It turns the supplied paper **Focus Planner** into a real Android app and adds planning, focus, reflection, analytics, and optional Supabase sync.

## Included

- **Today dashboard** — week navigation, Top 3 priorities, next study block, daily focus goal, completion count, water tracking, streak, exam countdown, and evening-review shortcut.
- **Smart timetable** — 5:00 AM–10:00 PM schedule in 30-minute rows, 25+5-friendly blocks, week overview, anytime backlog, recurring tasks, priorities, notes, durations, subjects, completion per occurrence, and conflict-aware auto-placement.
- **Pomodoro focus room** — precise absolute-end-time timer, pause/resume/reset, early session saving, short/long breaks, cycles, linked task and subject, persistent timer state, session history, and distraction parking.
- **Daily and evening review** — worked/fix, gratitude, quick notes, distraction review, mood, energy, productivity, water, sleep, steps, tomorrow's Top 3, and searchable-by-date history.
- **Progress insights** — 7/30-day focus chart, completion metrics, subject balance, 35-day heatmap, streaks, best day, recurring distractions, practical recommendations, and a shareable text report.
- **Subjects and exams** — colors, icons, archive/restore, weekly subject targets, exam countdowns, syllabus notes, and related-task readiness.
- **Personalization and safety** — light/dark/system themes, configurable Pomodoro durations and goals, Monday/Sunday week start, full JSON export, sample workspace restore, and confirmed data reset.
- **Offline first** — all features and local persistence work without an account or network.

## Run the app

```bash
npm install --legacy-peer-deps
npx expo start
```

Scan with Expo Go for development. For a standalone Android build, use the EAS commands below.

## Connect Supabase in about 5 minutes

### Option A — paste credentials in the app (fastest)

1. Create a project at Supabase and wait until it is active.
2. Open **SQL Editor → New query**, paste all of [`supabase/schema.sql`](supabase/schema.sql), and press **Run**.
3. Open **Project Settings → API** (or **Settings → Data API / API Keys**) and copy the project URL and **anon public** key.
4. In FocusFlow open **Today → Settings → Supabase cloud sync**. Paste both values and tap **Save & continue**.
5. Create an account or sign in, then tap **Sync now**.

The URL/key are stored using Expo SecureStore on Android/iOS. The login session is persisted separately. Only the anon key belongs in the app; **never use a service_role key**.

If email confirmation is enabled in Supabase Auth, confirm the email and then sign in. For immediate testing, you can disable **Confirm email** under **Authentication → Sign In / Providers → Email** in your own project.

### Option B — environment variables

```bash
cp .env.example .env
# Fill in EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY
npx expo start -c
```

The in-app form is unnecessary when both environment variables are present.

### Sync behavior

- **Sync now** compares local and remote timestamps and keeps the newest complete planner snapshot.
- **Upload** explicitly replaces the account's cloud copy with this device.
- **Download** explicitly replaces local planner data with the cloud copy.
- **Auto-sync** waits 12 seconds after editing and then performs smart sync.
- Tasks, sessions, subjects, exams, reviews, settings, and metadata sync together. The active timer stays local.
- This is intentionally last-write-wins snapshot sync, not collaborative multi-user editing. The included Row Level Security policies ensure one account cannot access another account's row.

### Backend troubleshooting

- `relation ... focusflow_state does not exist`: run the complete SQL file in the same project whose URL you pasted.
- `row-level security` error: re-run the policy section and make sure you are signed in.
- `Invalid login credentials`: check the email/password and complete email confirmation if required.
- `No valid cloud backup exists yet`: choose **Upload** once, then **Download** on another device.

## Build a real Android APK

1. Create/log into an Expo account and connect this project to your own account if needed:

   ```bash
   npx eas-cli@latest login
   npx eas-cli@latest init
   ```

2. Build the installable preview APK:

   ```bash
   npx eas-cli@latest build --platform android --profile preview
   ```

3. Download the APK from the build result and install it on an Android device. Allow installation from your browser/file manager when Android asks.

For Google Play, build an Android App Bundle:

```bash
npx eas-cli@latest build --platform android --profile production
```

The Android application ID is `com.focusflow.planner`; change it in `app.json` before your first store upload if you want a different unique ID.

## Project structure

```text
App.tsx                         app providers and icon-font preload
src/navigation/                 stack + five-tab native navigation
src/screens/                    all product screens and forms
src/components/                 reusable native UI, task rows, week strip
src/store/AppContext.tsx        persistence, actions, timer, cloud sync
src/lib/supabase.ts             secure runtime/env Supabase configuration
src/data/seed.ts                first-run guided workspace
src/utils/                      date logic and derived study metrics
supabase/schema.sql             complete table, grants, and RLS policies
```

## Production notes

- The timer stores an absolute end timestamp and catches up correctly after app switching or process restoration. Completion is handled when the app is active; this version does not claim background alarms.
- Data is saved to AsyncStorage after each change. Supabase configuration uses SecureStore on native platforms.
- Export a JSON backup before **Restore sample workspace** or **Clear all planner data**.
- Verify release behavior on a physical Android device before store submission, especially keyboard, sharing, authentication email delivery, and network-off startup.
