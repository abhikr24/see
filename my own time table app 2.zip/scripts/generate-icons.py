"""Generates FocusFlow brand icons (leaf inside a focus ring). Run: python3 scripts/generate-icons.py"""
from PIL import Image, ImageDraw
import math

GREEN = (36, 75, 62, 255)
LIME = (221, 243, 167, 255)
WHITE = (255, 255, 255, 255)
SS = 4  # supersampling

def leaf_polygon(cx, cy, size, angle_deg=-35):
    """Leaf outline: pointed at both ends, bulging in the middle."""
    pts = []
    n = 60
    for i in range(n + 1):
        t = i / n
        x = (t - 0.5) * size
        w = math.sin(math.pi * t) ** 0.8 * size * 0.30
        pts.append((x, -w))
    for i in range(n, -1, -1):
        t = i / n
        x = (t - 0.5) * size
        w = math.sin(math.pi * t) ** 0.8 * size * 0.30
        pts.append((x, w))
    a = math.radians(angle_deg)
    return [(cx + x * math.cos(a) - y * math.sin(a), cy + x * math.sin(a) + y * math.cos(a)) for x, y in pts]

def draw_mark(size, fg, vein, ring=True, ring_color=None, scale=1.0):
    big = size * SS
    img = Image.new('RGBA', (big, big), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = big / 2
    if ring:
        r = big * 0.36 * scale
        d.ellipse([c - r, c - r, c + r, c + r], outline=ring_color or fg, width=int(big * 0.035 * scale))
    d.polygon(leaf_polygon(c, c, big * 0.56 * scale), fill=fg)
    # vein
    a = math.radians(-35)
    half = big * 0.56 * scale * 0.40
    d.line([(c - half * math.cos(a), c - half * math.sin(a)), (c + half * math.cos(a), c + half * math.sin(a))], fill=vein, width=max(2, int(big * 0.012 * scale)))
    return img.resize((size, size), Image.LANCZOS)

def save(img, path):
    img.save(path)
    print(path, img.size)

# App icon: green rounded-square background, lime leaf
size = 1024
bg = Image.new('RGBA', (size, size), GREEN)
mark = draw_mark(size, LIME, GREEN, ring=True, ring_color=(255, 255, 255, 120))
bg.alpha_composite(mark)
save(bg.convert('RGB'), 'assets/icon.png')

# Android adaptive: foreground (safe zone ~ 66%), background plain, monochrome
save(draw_mark(512, LIME, GREEN, ring=True, ring_color=(255, 255, 255, 140), scale=0.8), 'assets/android-icon-foreground.png')
save(Image.new('RGBA', (512, 512), GREEN), 'assets/android-icon-background.png')
save(draw_mark(432, WHITE, (0, 0, 0, 0), ring=True, scale=0.78), 'assets/android-icon-monochrome.png')

# Splash + favicon + notification icon (all-white silhouette, 96x96)
save(draw_mark(1024, LIME, GREEN, ring=True, ring_color=(255, 255, 255, 120), scale=0.7), 'assets/splash-icon.png')
fav = Image.new('RGBA', (48, 48), GREEN)
fav.alpha_composite(draw_mark(48, LIME, GREEN, ring=False, scale=1.25))
save(fav, 'assets/favicon.png')
save(draw_mark(96, WHITE, (0, 0, 0, 0), ring=True, scale=0.95), 'assets/notification-icon.png')
