// Generates the royalty-free sounds used by FocusFlow (run: node scripts/generate-sounds.js).
const fs = require('fs');
const path = require('path');

const RATE = 22050;
const out = path.join(__dirname, '..', 'assets', 'sounds');
fs.mkdirSync(out, { recursive: true });

function writeWav(name, samples) {
  const data = Buffer.alloc(samples.length * 2);
  samples.forEach((s, i) => data.writeInt16LE(Math.max(-1, Math.min(1, s)) * 32767 | 0, i * 2));
  const header = Buffer.alloc(44);
  header.write('RIFF', 0); header.writeUInt32LE(36 + data.length, 4); header.write('WAVE', 8);
  header.write('fmt ', 12); header.writeUInt32LE(16, 16); header.writeUInt16LE(1, 20); header.writeUInt16LE(1, 22);
  header.writeUInt32LE(RATE, 24); header.writeUInt32LE(RATE * 2, 28); header.writeUInt16LE(2, 32); header.writeUInt16LE(16, 34);
  header.write('data', 36); header.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(out, name), Buffer.concat([header, data]));
  console.log(name, (header.length + data.length) / 1024 | 0, 'KB');
}

let seed = 1337;
const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const gauss = () => (rand() + rand() + rand() + rand() - 2) / 0.58;

// Cross-fade the tail into the head so the loop has no click.
function loopable(samples, fade) {
  const n = samples.length - fade;
  const res = samples.slice(0, n);
  for (let i = 0; i < fade; i += 1) {
    const t = i / fade;
    res[i] = samples[i] * t + samples[n + i] * (1 - t);
  }
  return res;
}

// 1. Notification chime: two soft bell strikes.
{
  const len = Math.floor(RATE * 1.8);
  const s = new Array(len).fill(0);
  const strike = (start, base) => {
    for (let i = 0; i < len - start; i += 1) {
      const t = i / RATE;
      const env = Math.exp(-t * 3.2) * Math.min(1, t * 400);
      const v = Math.sin(2 * Math.PI * base * t) + 0.5 * Math.sin(2 * Math.PI * base * 2.01 * t) * Math.exp(-t * 2) + 0.25 * Math.sin(2 * Math.PI * base * 3.97 * t) * Math.exp(-t * 5);
      s[start + i] += v * env * 0.42;
    }
  };
  strike(0, 784);
  strike(Math.floor(RATE * 0.42), 1046.5);
  writeWav('chime.wav', s);
}

const SECONDS = 10;
const total = RATE * SECONDS;
const FADE = Math.floor(RATE * 0.6);

// 2. White noise (softened with a gentle low-pass so it is easy on the ears).
{
  const s = new Array(total + FADE);
  let last = 0;
  for (let i = 0; i < s.length; i += 1) { last = last * 0.35 + gauss() * 0.65; s[i] = last * 0.22; }
  writeWav('white.wav', loopable(s, FADE));
}

// 3. Rain: hissy noise bed + random droplets.
{
  const s = new Array(total + FADE);
  let lp = 0; let hp = 0;
  for (let i = 0; i < s.length; i += 1) {
    const n = gauss();
    lp = lp * 0.6 + n * 0.4;
    hp = lp - hp * 0.0; // keep the mid/high hiss
    s[i] = (lp * 0.5) * (0.17 + 0.04 * Math.sin(i / RATE * 0.9));
  }
  for (let d = 0; d < SECONDS * 55; d += 1) {
    const at = Math.floor(rand() * (s.length - 600));
    const amp = 0.05 + rand() * 0.12;
    const decay = 90 + rand() * 160;
    const tone = 1200 + rand() * 2600;
    for (let i = 0; i < 500; i += 1) s[at + i] += Math.sin(2 * Math.PI * tone * i / RATE) * Math.exp(-i / decay) * amp * (rand() * 0.6 + 0.4);
  }
  writeWav('rain.wav', loopable(s, FADE));
}

// 4. Study ambience: slow, warm pad with a very soft airy bed. All partials are whole cycles per loop => seamless.
{
  const s = new Array(total).fill(0);
  const notes = [110, 164.8, 220, 277.2, 329.6, 440];
  const gains = [0.16, 0.12, 0.12, 0.07, 0.06, 0.03];
  notes.forEach((f, k) => {
    const freq = Math.round(f * 10) / 10; // multiple of 0.1 Hz => integer cycles in 10 s
    const lfo = 0.1 * (k + 1);
    for (let i = 0; i < total; i += 1) {
      const t = i / RATE;
      const swell = 0.65 + 0.35 * Math.sin(2 * Math.PI * lfo * t + k);
      s[i] += Math.sin(2 * Math.PI * freq * t + Math.sin(2 * Math.PI * 0.2 * t) * 0.4) * gains[k] * swell;
    }
  });
  let lp = 0;
  for (let i = 0; i < total; i += 1) { lp = lp * 0.9 + gauss() * 0.1; s[i] += lp * 0.05; }
  writeWav('ambience.wav', loopable(s.concat(s.slice(0, FADE)), FADE).slice(0, total - 0));
}
