import { describe, expect, it } from 'vitest';
import { BACKUP_SCHEMA_VERSION, parseBackup, serializeBackup } from '../lib/backup';
import { countData, emptyData, isDemoData, normalizeData, topicsFromSyllabus } from '../lib/schema';
import { AppData } from '../types';
import { generateRevisionPlan } from '../utils/revision';
import { tasksCsv, sessionsCsv, csvEscape } from '../lib/csv';
import { pendingMigrations, MIGRATIONS } from '../lib/migrations';

function sample(): AppData {
  const data = emptyData({ name: 'Abhi' });
  data.subjects.push({ id: 's1', name: 'Physics', color: '#fff', icon: 'planet', weeklyGoalMinutes: 240, archived: false, createdAt: '2026-11-01T00:00:00.000Z' });
  data.tasks.push({
    id: 't1', title: 'Late block', notes: 'n', subjectId: 's1', date: '2026-11-08', startMinute: 22 * 60 + 30, durationMinutes: 45, estimatedPomodoros: 2,
    priority: 'high', recurrence: 'custom', recurDays: [1, 3], recurUntil: '2026-12-01', skippedDates: ['2026-11-11'], completedDates: [], topThreeDates: [],
    kind: 'class', createdAt: '', updatedAt: '',
  });
  data.sessions.push({ id: 'x1', startedAt: '2026-11-08T10:00:00.000Z', endedAt: '2026-11-08T10:02:00.000Z', plannedMinutes: 25, actualMinutes: 2, actualSeconds: 120, completed: false, interrupted: true, interruptions: 1, distractions: ['phone'] });
  data.reviews.push({ date: '2026-11-08', worked: 'w', fix: 'f', gratitude: 'g', quickNotes: '', distractionNotes: '', convertedDistractions: ['phone'], mood: 4, energy: 3, water: 5, sleepHours: 7.5, steps: 4000, productivity: 4, updatedAt: '' });
  data.exams.push({ id: 'e1', title: 'Physics midterm', subjectId: 's1', date: '2026-12-08', time: '10:30', syllabus: '', topics: [{ id: 'a', title: 'Waves', done: true }, { id: 'b', title: 'Optics', done: false }], createdAt: '' });
  data.meta = { updatedAt: '2026-11-08T10:00:00.000Z', dirty: true, edited: true };
  return data;
}

describe('backup export / import', () => {
  it('round-trips everything including reviews, exams and topics', () => {
    const original = sample();
    const parsed = parseBackup(serializeBackup(original));
    expect(parsed.ok).toBe(true);
    if (!parsed.ok) return;
    expect(parsed.data).toEqual(original);
    expect(parsed.counts).toEqual(countData(original));
    expect(parsed.counts.reviews).toBe(1);
    expect(parsed.counts.exams).toBe(1);
    expect(parsed.sourceVersion).toBe(BACKUP_SCHEMA_VERSION);
  });
  it('includes a schema version in the file', () => {
    expect(JSON.parse(serializeBackup(sample())).schemaVersion).toBe(BACKUP_SCHEMA_VERSION);
  });
  it('imports the old v1 export format and upgrades missing fields', () => {
    const v1 = {
      app: 'FocusFlow', version: 1, exportedAt: '2026-10-01T00:00:00.000Z',
      data: {
        tasks: [{ id: 'task_a', title: 'Old', notes: '', date: '2026-10-01', durationMinutes: 30, estimatedPomodoros: 1, priority: 'low', recurrence: 'weekly', completedDates: [], topThreeDates: [], createdAt: '', updatedAt: '' }],
        subjects: [], sessions: [{ id: 's', startedAt: '2026-10-01T09:00:00.000Z', endedAt: '2026-10-01T09:25:00.000Z', plannedMinutes: 25, actualMinutes: 25, completed: true, distractions: [] }],
        reviews: [], exams: [{ id: 'e', title: 'Old exam', date: '2026-12-01', time: '09:00', syllabus: 'Algebra, Geometry', createdAt: '' }],
        settings: { name: 'Old' }, meta: { updatedAt: '2026-10-01T00:00:00.000Z', dirty: true },
      },
    };
    const parsed = parseBackup(JSON.stringify(v1));
    expect(parsed.ok).toBe(true);
    if (!parsed.ok) return;
    expect(parsed.sourceVersion).toBe(1);
    expect(parsed.data.tasks[0]).toMatchObject({ skippedDates: [], recurDays: [], kind: 'study' });
    expect(parsed.data.sessions[0]).toMatchObject({ actualSeconds: 1500, interrupted: false, interruptions: 0 });
    expect(parsed.data.exams[0].topics.map((t) => t.title)).toEqual(['Algebra', 'Geometry']);
    expect(parsed.data.settings.notifyFocusEnd).toBe(true);
  });
  it('rejects garbage and newer formats with a readable message', () => {
    expect(parseBackup('not json').ok).toBe(false);
    expect(parseBackup('{"hello":1}').ok).toBe(false);
    const newer = parseBackup(JSON.stringify({ app: 'FocusFlow', schemaVersion: 99, data: sample() }));
    expect(newer.ok).toBe(false);
    if (!newer.ok) expect(newer.error).toContain('newer');
    expect(parseBackup(JSON.stringify({ app: 'Other', schemaVersion: 2, data: sample() })).ok).toBe(false);
  });
});

describe('data hygiene', () => {
  it('detects the old untouched demo workspace so it can be dropped', () => {
    const demo = emptyData();
    demo.subjects.push({ id: 'subject_1', name: 'Mathematics', color: '', icon: '', weeklyGoalMinutes: 300, archived: false, createdAt: '' });
    demo.tasks.push({ ...sample().tasks[0], id: 'task_1' });
    expect(isDemoData(demo)).toBe(true);
    expect(isDemoData(sample())).toBe(false);
  });
  it('a fresh install is empty, clean and unedited', () => {
    const fresh = emptyData();
    expect(fresh.tasks).toHaveLength(0);
    expect(fresh.meta.dirty).toBe(false);
    expect(fresh.meta.edited).toBe(false);
  });
  it('normalizeData rejects non-planner objects', () => {
    expect(normalizeData(null)).toBeNull();
    expect(normalizeData({ tasks: [] })).toBeNull();
  });
  it('splits a legacy syllabus into topics', () => {
    expect(topicsFromSyllabus('A, B\nC', 'x').map((t) => t.title)).toEqual(['A', 'B', 'C']);
  });
});

describe('revision planning', () => {
  it('generates blocks backwards from the exam date and spreads pending topics', () => {
    const exam = sample().exams[0];
    const plan = generateRevisionPlan(exam, '2026-11-08', []);
    expect(plan.map((p) => p.offset)).toEqual([30, 14, 7, 2]);
    expect(plan.map((p) => p.date)).toEqual(['2026-11-08', '2026-11-24', '2026-12-01', '2026-12-06']);
    expect(plan[0].notes).toContain('Optics'); // done topic "Waves" is not scheduled
    expect(plan[0].notes).not.toContain('Waves');
  });
  it('skips offsets that are already in the past and existing blocks', () => {
    const exam = sample().exams[0];
    const near = generateRevisionPlan(exam, '2026-11-30', []);
    expect(near.map((p) => p.offset)).toEqual([7, 2]);
    const existing = { ...sample().tasks[0], examId: exam.id, title: near[0].title, date: near[0].date, recurrence: 'none' as const };
    expect(generateRevisionPlan(exam, '2026-11-30', [existing]).map((p) => p.offset)).toEqual([2]);
    expect(generateRevisionPlan(exam, '2026-12-07', [])).toHaveLength(0);
  });
});

describe('csv and migrations', () => {
  it('escapes csv fields', () => {
    expect(csvEscape('a,b')).toBe('"a,b"');
    expect(csvEscape('say "hi"')).toBe('"say ""hi"""');
    expect(tasksCsv(sample()).split('\r\n')[0]).toContain('title');
    expect(sessionsCsv(sample())).toContain('Physics'.slice(0, 0));
    expect(sessionsCsv(sample()).split('\r\n')).toHaveLength(3);
  });
  it('migrations are ordered and only run once', () => {
    expect(MIGRATIONS.map((m) => m.version)).toEqual([...MIGRATIONS.map((m) => m.version)].sort((a, b) => a - b));
    expect(pendingMigrations(0)).toHaveLength(MIGRATIONS.length);
    expect(pendingMigrations(1).map((m) => m.version)).toEqual([2]);
    expect(pendingMigrations(MIGRATIONS.length)).toHaveLength(0);
  });
});
