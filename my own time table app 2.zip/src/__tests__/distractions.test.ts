import { describe, expect, it } from 'vitest';
import { groupDistractions } from '../utils/distractions';
import { FocusSession } from '../types';

const session = (id: string, startedAt: string, distractions: string[]): FocusSession => ({
  id, startedAt, endedAt: startedAt, plannedMinutes: 25, actualMinutes: 25, actualSeconds: 1500, completed: true, interrupted: false, interruptions: 0, distractions,
});

describe('parked distractions for the evening review', () => {
  it('groups case-insensitively, counts, and ignores other days', () => {
    const noon = new Date(2026, 10, 8, 12).toISOString();
    const other = new Date(2026, 10, 7, 12).toISOString();
    const groups = groupDistractions([
      session('a', noon, ['Check messages', 'reply to Sam']), session('b', noon, ['check messages ', 'Buy milk']), session('c', other, ['Old one']),
    ], '2026-11-08', ['CHECK MESSAGES']);
    expect(groups[0]).toMatchObject({ key: 'check messages', count: 3 });
    expect(groups).toHaveLength(3);
    expect(groups.find((g) => g.key === 'old one')).toBeUndefined();
  });
});
