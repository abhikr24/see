import { describe, expect, it } from 'vitest';
import { autoPlace } from '../utils/placement';
import { layoutLanes } from '../utils/layout';

describe('auto placement', () => {
  it('places by real duration on a 15-minute grid and avoids existing blocks', () => {
    const placed = autoPlace(
      [{ id: 'a', durationMinutes: 50, priority: 'high' }, { id: 'b', durationMinutes: 25, priority: 'low' }],
      [{ start: 360, end: 420 }],
      { windowStart: 360, windowEnd: 1320 },
    );
    expect(placed.get('a')).toBe(435); // 7:00 + 5 min buffer, rounded up to the next 15-min mark
    expect(placed.get('b')! % 15).toBe(0);
    expect(placed.get('b')! >= 360 + 60).toBe(true);
  });

  it('honours the not-before time and window end', () => {
    const placed = autoPlace([{ id: 'a', durationMinutes: 60, priority: 'medium' }], [], { windowStart: 360, windowEnd: 1320, notBefore: 1290 });
    expect(placed.has('a')).toBe(false);
    const ok = autoPlace([{ id: 'a', durationMinutes: 30, priority: 'medium' }], [], { windowStart: 360, windowEnd: 1440, notBefore: 1290 });
    expect(ok.get('a')).toBe(1290);
  });

  it('can use late-night hours when the window allows it', () => {
    const placed = autoPlace([{ id: 'late', durationMinutes: 30, priority: 'high' }], [{ start: 0, end: 1380 }], { windowStart: 0, windowEnd: 1440 });
    expect(placed.get('late')).toBe(1395);
  });

  it('never overlaps blocks it places itself', () => {
    const placed = autoPlace(Array.from({ length: 5 }, (_, i) => ({ id: `t${i}`, durationMinutes: 45, priority: 'medium' as const })), [], { windowStart: 480, windowEnd: 1200 });
    const starts = [...placed.values()].sort((a, b) => a - b);
    for (let i = 1; i < starts.length; i += 1) expect(starts[i] - starts[i - 1]).toBeGreaterThanOrEqual(45);
  });
});

describe('lane layout', () => {
  it('puts overlapping blocks side by side and leaves others full width', () => {
    const lanes = layoutLanes([
      { id: 'a', start: 600, end: 660 }, { id: 'b', start: 630, end: 700 }, { id: 'c', start: 900, end: 960 },
    ]);
    expect(lanes.get('a')).toEqual({ lane: 0, lanes: 2 });
    expect(lanes.get('b')).toEqual({ lane: 1, lanes: 2 });
    expect(lanes.get('c')).toEqual({ lane: 0, lanes: 1 });
  });
  it('draws tasks at any time, including after 10 PM', () => {
    const lanes = layoutLanes([{ id: 'late', start: 22 * 60 + 30, end: 23 * 60 + 15 }, { id: 'eve', start: 18 * 60 + 15, end: 19 * 60 }]);
    expect(lanes.size).toBe(2);
    expect(lanes.get('late')?.lanes).toBe(1);
  });
});
