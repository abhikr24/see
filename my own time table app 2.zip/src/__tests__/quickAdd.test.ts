import { describe, expect, it } from 'vitest';
import { parseQuickAdd } from '../utils/quickAdd';
import { Subject } from '../types';

const subject = (id: string, name: string): Subject => ({ id, name, color: '#000', icon: 'book', weeklyGoalMinutes: 120, archived: false, createdAt: '' });
const ctx = { subjects: [subject('p', 'Physics'), subject('m', 'Mathematics'), subject('cs', 'Computer Science')], today: '2026-11-08', defaultDuration: 25 }; // a Sunday

describe('quick add in plain language', () => {
  it('turns "Physics 45m tomorrow 6pm high" into a scheduled block', () => {
    const r = parseQuickAdd('Physics 45m tomorrow 6pm high', ctx);
    expect(r).toMatchObject({ title: 'Physics', subjectId: 'p', durationMinutes: 45, date: '2026-11-09', startMinute: 18 * 60, priority: 'high' });
  });
  it('uses the default duration and today when nothing is said', () => {
    const r = parseQuickAdd('Read chapter 4', ctx);
    expect(r).toMatchObject({ title: 'Read chapter 4', durationMinutes: 25, date: '2026-11-08', startMinute: undefined, priority: 'medium' });
  });
  it('understands hours, minutes and 24-hour times', () => {
    expect(parseQuickAdd('maths past paper 1h30m 22:30', ctx)).toMatchObject({ durationMinutes: 90, startMinute: 22 * 60 + 30, subjectId: 'm' });
    expect(parseQuickAdd('revise 2 hours at 7pm', ctx)).toMatchObject({ durationMinutes: 120, startMinute: 19 * 60, title: 'Revise' });
    expect(parseQuickAdd('cs notes 6:15 PM 30 min', ctx)).toMatchObject({ durationMinutes: 30, startMinute: 18 * 60 + 15, subjectId: 'cs' });
  });
  it('understands weekdays and calendar dates', () => {
    expect(parseQuickAdd('essay friday 5pm', ctx).date).toBe('2026-11-13');
    expect(parseQuickAdd('essay next sunday', ctx).date).toBe('2026-11-15');
    expect(parseQuickAdd('lab report 12 nov', ctx).date).toBe('2026-11-12');
    expect(parseQuickAdd('lab report nov 3', ctx).date).toBe('2027-11-03');
    expect(parseQuickAdd('lab report 2026-12-01', ctx).date).toBe('2026-12-01');
  });
  it('understands recurrence', () => {
    expect(parseQuickAdd('Physics class every monday 9am', ctx)).toMatchObject({ recurrence: 'custom', recurDays: [1], startMinute: 540, date: '2026-11-09' });
    expect(parseQuickAdd('flashcards daily', ctx).recurrence).toBe('daily');
  });
  it('never produces an empty title and lists what it understood', () => {
    const r = parseQuickAdd('45m tomorrow', ctx);
    expect(r.title).toBe('Study block');
    expect(r.recognized).toContain('Tomorrow');
    expect(r.recognized).toContain('45m');
  });
});
