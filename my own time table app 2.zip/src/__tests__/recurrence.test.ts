import { describe, expect, it } from 'vitest';
import { StudyTask } from '../types';
import { occursOn, restoreOccurrence, skipOccurrence, upcomingOccurrences } from '../utils/recurrence';

const base: StudyTask = {
  id: 't1', title: 'Physics lecture', notes: '', date: '2026-11-02', startMinute: 600, durationMinutes: 60, estimatedPomodoros: 2,
  priority: 'medium', recurrence: 'custom', recurDays: [1, 3], recurUntil: '2026-12-16', skippedDates: [], completedDates: [], topThreeDates: [],
  kind: 'class', createdAt: '', updatedAt: '',
};

describe('class timetable recurrence', () => {
  it('occurs only on the chosen weekdays between start and end date', () => {
    expect(occursOn(base, '2026-11-02')).toBe(true);  // Monday
    expect(occursOn(base, '2026-11-04')).toBe(true);  // Wednesday
    expect(occursOn(base, '2026-11-03')).toBe(false); // Tuesday
    expect(occursOn(base, '2026-10-26')).toBe(false); // before start
    expect(occursOn(base, '2026-12-14')).toBe(true);
    expect(occursOn(base, '2026-12-21')).toBe(false); // after end
  });

  it('skips one occurrence without deleting the series', () => {
    const skipped = skipOccurrence(base, '2026-11-11');
    expect(occursOn(skipped, '2026-11-11')).toBe(false);
    expect(occursOn(skipped, '2026-11-09')).toBe(true);
    expect(occursOn(skipped, '2026-11-16')).toBe(true);
    expect(skipOccurrence(skipped, '2026-11-11').skippedDates).toEqual(['2026-11-11']);
    expect(occursOn(restoreOccurrence(skipped, '2026-11-11'), '2026-11-11')).toBe(true);
  });

  it('lists upcoming occurrences while honouring skips', () => {
    const skipped = skipOccurrence(base, '2026-11-04');
    expect(upcomingOccurrences(skipped, '2026-11-02', 3)).toEqual(['2026-11-02', '2026-11-09', '2026-11-11']);
  });

  it('supports daily, weekday, weekly and one-off blocks', () => {
    const once: StudyTask = { ...base, recurrence: 'none', date: '2026-11-05' };
    expect(occursOn(once, '2026-11-05')).toBe(true);
    expect(occursOn(once, '2026-11-12')).toBe(false);
    expect(occursOn({ ...base, recurrence: 'weekdays', recurUntil: undefined }, '2026-11-07')).toBe(false); // Saturday
    expect(occursOn({ ...base, recurrence: 'weekdays', recurUntil: undefined }, '2026-11-06')).toBe(true);
    expect(occursOn({ ...base, recurrence: 'weekly', recurUntil: undefined }, '2026-11-09')).toBe(true);
    expect(occursOn({ ...base, recurrence: 'weekly', recurUntil: undefined }, '2026-11-10')).toBe(false);
    expect(occursOn({ ...base, recurrence: 'daily', recurUntil: undefined }, '2027-01-01')).toBe(true);
  });

  it('never skips a non-recurring block', () => {
    const once: StudyTask = { ...base, recurrence: 'none', date: '2026-11-05' };
    expect(skipOccurrence(once, '2026-11-05')).toBe(once);
  });
});
