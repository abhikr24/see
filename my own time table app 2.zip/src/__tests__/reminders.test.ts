import { describe, expect, it } from 'vitest';
import { buildNotificationPlan } from '../utils/reminders';
import { createIdleTimer, pause, startBreak, startFocus } from '../lib/timerMachine';
import { defaultSettings } from '../lib/schema';
import { StudyTask } from '../types';
import { buildInsights, bestStudyHour, subjectProgress } from '../utils/insights';
import { emptyData } from '../lib/schema';
import { buildReportCard } from '../utils/report';

const now = new Date(2026, 10, 8, 9, 0, 0).getTime();
const block = (over: Partial<StudyTask>): StudyTask => ({
  id: 'b', title: 'Block', notes: '', date: '2026-11-08', startMinute: 600, durationMinutes: 45, estimatedPomodoros: 2, priority: 'medium',
  recurrence: 'none', recurDays: [], skippedDates: [], completedDates: [], topThreeDates: [], kind: 'study', createdAt: '', updatedAt: '', ...over,
});

describe('notification plan', () => {
  it('schedules the end of a running focus session at its absolute end time', () => {
    const timer = startFocus(createIdleTimer(1), { focusMinutes: 1, now });
    const plan = buildNotificationPlan({ timer, tasks: [], settings: defaultSettings, now });
    expect(plan).toHaveLength(1);
    expect(plan[0]).toMatchObject({ id: 'timer-end', kind: 'focus-end', fireAt: now + 60_000 });
  });
  it('announces the long break when the fourth focus session ends', () => {
    let timer = createIdleTimer(25, 3);
    timer = startFocus(timer, { focusMinutes: 25, now });
    const plan = buildNotificationPlan({ timer, tasks: [], settings: defaultSettings, now });
    expect(plan[0].data.nextBreak).toBe('longBreak');
  });
  it('schedules the end of a break and nothing while paused', () => {
    const brk = startBreak(createIdleTimer(25), 'shortBreak', defaultSettings, now);
    expect(buildNotificationPlan({ timer: brk, tasks: [], settings: defaultSettings, now })[0].kind).toBe('break-end');
    const paused = pause(startFocus(createIdleTimer(25), { focusMinutes: 25, now }), now + 1000);
    expect(buildNotificationPlan({ timer: paused, tasks: [], settings: defaultSettings, now })).toHaveLength(0);
  });
  it('reminds 5 minutes before a scheduled block, including late evening blocks', () => {
    const tasks = [block({ id: 'a', startMinute: 600 }), block({ id: 'late', startMinute: 22 * 60 + 30 }), block({ id: 'past', startMinute: 8 * 60 })];
    const plan = buildNotificationPlan({ timer: createIdleTimer(25), tasks, settings: defaultSettings, now });
    const a = plan.find((p) => p.id === 'block-a-2026-11-08');
    expect(a?.fireAt).toBe(new Date(2026, 10, 8, 9 + 0, 55).getTime());
    expect(plan.find((p) => p.id === 'block-late-2026-11-08')).toBeDefined();
    expect(plan.find((p) => p.id.startsWith('block-past'))).toBeUndefined();
  });
  it('respects each per-type switch and skips completed or skipped occurrences', () => {
    const timer = startFocus(createIdleTimer(25), { focusMinutes: 25, now });
    const off = { ...defaultSettings, notifyFocusEnd: false, notifyBreakEnd: false, notifyBlockStart: false };
    expect(buildNotificationPlan({ timer, tasks: [block({})], settings: off, now })).toHaveLength(0);
    const done = block({ completedDates: ['2026-11-08'] });
    const skipped = block({ id: 'c', recurrence: 'daily', skippedDates: ['2026-11-08'] });
    const plan = buildNotificationPlan({ timer: createIdleTimer(25), tasks: [done, skipped], settings: defaultSettings, now });
    expect(plan.find((p) => p.id === 'block-b-2026-11-08')).toBeUndefined();
    expect(plan.find((p) => p.id === 'block-c-2026-11-08')).toBeUndefined();
    expect(plan.find((p) => p.id === 'block-c-2026-11-09')).toBeDefined();
  });
});

describe('insights', () => {
  it('finds the best study hour from real elapsed time and avoids sentence-less output on empty data', () => {
    const data = emptyData();
    expect(bestStudyHour(data.sessions)).toBeNull();
    const start = new Date(2026, 10, 7, 19, 10, 0);
    data.sessions.push({ id: 's', startedAt: start.toISOString(), endedAt: start.toISOString(), plannedMinutes: 40, actualMinutes: 40, actualSeconds: 2400, completed: true, interrupted: false, interruptions: 0, distractions: [] });
    const best = bestStudyHour(data.sessions);
    expect(best?.hour).toBe(19);
    const sentences = buildInsights(data, '2026-11-08');
    expect(sentences.length).toBeGreaterThanOrEqual(5);
    expect(sentences[0].text).toContain('7 PM');
  });
  it('warns about an avoided subject', () => {
    const data = emptyData();
    data.subjects.push({ id: 'p', name: 'Physics', color: '', icon: '', weeklyGoalMinutes: 300, archived: false, createdAt: '' });
    // Thursday: three days into a Monday-start week with zero minutes
    const progress = subjectProgress(data, '2026-11-05');
    expect(progress[0].avoided).toBe(true);
    expect(buildInsights(data, '2026-11-05')[0].tone).toBe('warn');
    expect(buildReportCard(data, '2026-11-05').recommendation.length).toBeGreaterThan(10);
  });
});
