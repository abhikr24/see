import { describe, expect, it } from 'vitest';
import { FocusSession, StudyTask } from '../types';
import { completionStreak, focusStreak } from '../utils/selectors';
import { toDateKey } from '../utils/date';

function session(date: string, minutes = 25): FocusSession {
  const start = new Date(`${date}T10:00:00`);
  return {
    id: `s_${date}_${minutes}`, startedAt: start.toISOString(), endedAt: new Date(start.getTime() + minutes * 60000).toISOString(),
    plannedMinutes: minutes, actualMinutes: minutes, actualSeconds: minutes * 60, completed: true, interrupted: false, interruptions: 0, distractions: [],
  };
}

describe('streaks', () => {
  const today = '2026-11-08';
  it('counts consecutive days ending today', () => {
    expect(focusStreak([session('2026-11-08'), session('2026-11-07'), session('2026-11-06')], today)).toBe(3);
  });
  it('does not break the streak just because today has no session yet', () => {
    expect(focusStreak([session('2026-11-07'), session('2026-11-06')], today)).toBe(2);
  });
  it('breaks on a gap', () => {
    expect(focusStreak([session('2026-11-08'), session('2026-11-06')], today)).toBe(1);
    expect(focusStreak([session('2026-11-05')], today)).toBe(0);
  });
  it('returns 0 with no data', () => {
    expect(focusStreak([], today)).toBe(0);
    expect(completionStreak({ tasks: [], sessions: [] }, today)).toBe(0);
  });
  it('counts completed blocks as a win for the completion streak', () => {
    const task: StudyTask = {
      id: 't', title: 'x', notes: '', date: '2026-11-07', durationMinutes: 30, estimatedPomodoros: 1, priority: 'low', recurrence: 'none',
      recurDays: [], skippedDates: [], completedDates: ['2026-11-07'], topThreeDates: [], kind: 'study', createdAt: '', updatedAt: '',
    };
    expect(completionStreak({ tasks: [task], sessions: [session('2026-11-06')] }, today)).toBe(2);
  });
  it('toDateKey is local-date based', () => {
    expect(toDateKey(new Date(2026, 10, 8, 23, 59))).toBe('2026-11-08');
  });
});
