import { describe, expect, it } from 'vitest';
import { isSafeForAuto, planSync, SyncLocalInfo, SyncRemoteInfo } from '../lib/syncPlan';
import { DataCounts } from '../lib/schema';

const empty: DataCounts = { tasks: 0, subjects: 0, sessions: 0, reviews: 0, exams: 0, topics: 0 };
const full: DataCounts = { tasks: 12, subjects: 4, sessions: 30, reviews: 6, exams: 2, topics: 9 };
const local = (over: Partial<SyncLocalInfo> = {}): SyncLocalInfo => ({ edited: true, dirty: false, counts: full, ...over });
const remote = (over: Partial<SyncRemoteInfo> = {}): SyncRemoteInfo => ({ exists: true, valid: true, updatedAt: '2026-11-08T10:00:00.000Z', counts: full, ...over });

describe('sync direction', () => {
  it('downloads when the local copy was never edited, regardless of timestamps', () => {
    const plan = planSync(local({ edited: false, dirty: false, counts: empty, lastSyncedAt: undefined }), remote({ updatedAt: '2020-01-01T00:00:00.000Z' }));
    expect(plan).toEqual({ direction: 'download', reason: 'local-pristine' });
  });
  it('a fresh install can never upload over a real backup', () => {
    // even if the device somehow reports newer timestamps and dirty state, pristine => download
    const plan = planSync(local({ edited: false, dirty: true, lastSyncedAt: '2030-01-01T00:00:00.000Z' }), remote());
    expect(plan.direction).toBe('download');
  });
  it('does nothing when both sides are empty', () => {
    expect(planSync(local({ edited: false, counts: empty }), remote({ exists: false }))).toEqual({ direction: 'none', reason: 'nothing-to-upload' });
  });
  it('uploads local data to an empty cloud', () => {
    expect(planSync(local({ dirty: true }), remote({ exists: false }))).toEqual({ direction: 'upload', reason: 'first-upload' });
  });
  it('uploads when only local changed since last sync', () => {
    const plan = planSync(local({ dirty: true, lastSyncedAt: '2026-11-08T10:00:00.000Z' }), remote());
    expect(plan).toEqual({ direction: 'upload', reason: 'local-changes' });
  });
  it('downloads when only the cloud changed since last sync', () => {
    const plan = planSync(local({ dirty: false, lastSyncedAt: '2026-11-07T10:00:00.000Z' }), remote());
    expect(plan).toEqual({ direction: 'download', reason: 'remote-newer' });
  });
  it('reports a conflict instead of silently picking a winner', () => {
    expect(planSync(local({ dirty: true, lastSyncedAt: '2026-11-07T10:00:00.000Z' }), remote()).direction).toBe('conflict');
    expect(planSync(local({ dirty: true }), remote()).reason).toBe('never-synced-both-have-data');
  });
  it('never overwrites a real cloud backup with an empty device', () => {
    const plan = planSync(local({ counts: empty, dirty: true, lastSyncedAt: '2026-11-07T10:00:00.000Z' }), remote({ updatedAt: '2026-11-06T10:00:00.000Z' }));
    expect(plan).toEqual({ direction: 'download', reason: 'local-empty' });
  });
  it('is a no-op when in sync', () => {
    expect(planSync(local({ lastSyncedAt: '2026-11-08T10:00:00.000Z' }), remote()).direction).toBe('none');
  });
  it('treats an unreadable cloud copy as a no-op', () => {
    expect(planSync(local({ dirty: true }), remote({ valid: false })).reason).toBe('remote-invalid');
  });
  it('auto-sync only runs actions that cannot lose data', () => {
    expect(isSafeForAuto({ direction: 'upload', reason: 'local-changes' })).toBe(true);
    expect(isSafeForAuto({ direction: 'download', reason: 'remote-newer' })).toBe(true);
    expect(isSafeForAuto({ direction: 'download', reason: 'local-pristine' })).toBe(false);
    expect(isSafeForAuto({ direction: 'conflict', reason: 'both-changed' })).toBe(false);
  });
});
