import { describe, expect, it } from 'vitest';
import {
  breakAfter, createIdleTimer, dotsFilled, elapsedSecondsAt, finish, markInterruption, pause, primaryAction,
  remainingSecondsAt, reset, resume, settleIfElapsed, startBreak, startFocus, TimerSettings,
} from '../lib/timerMachine';

const settings: TimerSettings = { focusMinutes: 25, shortBreakMinutes: 5, longBreakMinutes: 15, longBreakEvery: 4 };
const T0 = new Date(2026, 10, 8, 9, 0, 0).getTime();
const min = (n: number) => n * 60_000;

describe('timer state machine', () => {
  it('counts down from an absolute end time and survives pause/resume', () => {
    let t = startFocus(createIdleTimer(25), { focusMinutes: 25, now: T0 });
    expect(remainingSecondsAt(t, T0 + min(10))).toBe(15 * 60);
    t = pause(t, T0 + min(10));
    expect(t.status).toBe('paused');
    expect(remainingSecondsAt(t, T0 + min(60))).toBe(15 * 60);
    t = resume(t, T0 + min(60));
    expect(remainingSecondsAt(t, T0 + min(65))).toBe(10 * 60);
  });

  it('ending a 25-minute session after 2 minutes records 2 minutes, not 25', () => {
    const t = startFocus(createIdleTimer(25), { focusMinutes: 25, now: T0 });
    const { state, session } = finish(t, T0 + min(2), true, 4);
    expect(session?.actualMinutes).toBe(2);
    expect(session?.plannedMinutes).toBe(25);
    expect(state.summary?.actualMinutes).toBe(2);
    expect(state.summary?.early).toBe(true);
    expect(state.completedFocus).toBe(0); // an early stop is not a completed Pomodoro
  });

  it('does not save sessions shorter than 30 seconds', () => {
    const t = startFocus(createIdleTimer(25), { focusMinutes: 25, now: T0 });
    const { session, state } = finish(t, T0 + 10_000, true, 4);
    expect(session).toBeUndefined();
    expect(state.summary?.saved).toBe(false);
  });

  it('offers the long break after the fourth completed focus using only the primary button', () => {
    let t = createIdleTimer(25);
    let now = T0;
    const seen: string[] = [];
    for (let i = 0; i < 4; i += 1) {
      const action = primaryAction(t, 4);
      expect(action.kind).toBe('start-focus');
      t = startFocus(t, { focusMinutes: 25, now });
      now += min(25);
      const result = settleIfElapsed(t, now, 4);
      expect(result).not.toBeNull();
      t = result!.state;
      const next = primaryAction(t, 4);
      expect(next.kind).toBe('start-break');
      if (next.kind === 'start-break') {
        seen.push(next.breakKind);
        t = startBreak(t, next.breakKind, settings, now);
        now += min(next.breakKind === 'longBreak' ? 15 : 5);
        t = settleIfElapsed(t, now, 4)!.state;
      }
    }
    expect(seen).toEqual(['shortBreak', 'shortBreak', 'shortBreak', 'longBreak']);
    expect(t.completedFocus).toBe(4);
  });

  it('keeps counting when the next focus is started by a different path (skip break)', () => {
    let t = startFocus(createIdleTimer(25), { focusMinutes: 25, now: T0 });
    t = settleIfElapsed(t, T0 + min(25), 4)!.state;
    expect(t.completedFocus).toBe(1);
    t = startFocus(t, { focusMinutes: 25, now: T0 + min(26) }); // "skip break" button
    t = settleIfElapsed(t, T0 + min(52), 4)!.state;
    expect(t.completedFocus).toBe(2);
    expect(breakAfter(4, 4)).toBe('longBreak');
    expect(breakAfter(3, 4)).toBe('shortBreak');
    expect(breakAfter(8, 4)).toBe('longBreak');
  });

  it('reflects completed cycles in the dot strip', () => {
    let t = createIdleTimer(25);
    expect(dotsFilled(t, 4)).toBe(0);
    let now = T0;
    const filled: number[] = [];
    for (let i = 0; i < 4; i += 1) {
      t = startFocus(t, { focusMinutes: 25, now });
      now += min(25);
      t = settleIfElapsed(t, now, 4)!.state;
      filled.push(dotsFilled(t, 4));
      t = reset(t, 25);
    }
    expect(filled).toEqual([1, 2, 3, 4]);
    expect(dotsFilled(startFocus(t, { focusMinutes: 25, now }), 4)).toBe(0);
  });

  it('starts a new set on a new calendar day', () => {
    let t = startFocus(createIdleTimer(25), { focusMinutes: 25, now: T0 });
    t = settleIfElapsed(t, T0 + min(25), 4)!.state;
    const nextDay = T0 + 24 * 60 * min(1);
    expect(startFocus(t, { focusMinutes: 25, now: nextDay }).completedFocus).toBe(0);
  });

  it('settles a timer that expired while the app was closed (locked phone)', () => {
    const t = startFocus(createIdleTimer(1), { focusMinutes: 1, now: T0 });
    const result = settleIfElapsed(t, T0 + min(30), 4);
    expect(result?.state.status).toBe('completed');
    expect(result?.session?.actualMinutes).toBe(1);
    expect(result?.session?.completed).toBe(true);
    expect(elapsedSecondsAt(t, T0 + 30_000)).toBe(30);
  });

  it('records strict-mode interruptions on the saved session', () => {
    let t = startFocus(createIdleTimer(25), { focusMinutes: 25, now: T0 });
    t = markInterruption(markInterruption(t));
    const { session, state } = finish(t, T0 + min(10), true, 4);
    expect(session?.interrupted).toBe(true);
    expect(session?.interruptions).toBe(2);
    expect(state.summary?.interruptions).toBe(2);
  });

  it('does not count interruptions during breaks or while paused', () => {
    const idle = createIdleTimer(25);
    expect(markInterruption(idle).interruptions).toBe(0);
    const brk = startBreak(idle, 'shortBreak', settings, T0);
    expect(markInterruption(brk).interruptions).toBe(0);
  });
});
