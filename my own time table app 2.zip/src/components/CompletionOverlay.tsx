import React, { useEffect, useRef, useState } from 'react';
import { Modal, ScrollView, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { formatElapsed } from '../utils/date';
import { overlay as O } from '../i18n/focus';
import { Text } from './Text';
import { Button } from './ui';
import { useNotifications } from './NotificationBridge';

/**
 * Full-screen alert shown when a timer ends while the app is open (or when it is opened after the
 * timer ended). It always offers the next step: start the break, snooze 5 minutes, or close.
 */
export default function CompletionOverlay() {
  const theme = useTheme();
  const { timer, data, startBreak, startFocus } = useApp();
  const { snooze } = useNotifications();
  const [dismissedKey, setDismissedKey] = useState<string | null>(null);
  const snoozeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const summary = timer.summary;
  const key = `${timer.startedAt ?? ''}|${timer.mode}|${timer.status}`;
  const visible = timer.status === 'completed' && Boolean(summary) && dismissedKey !== key;

  useEffect(() => () => { if (snoozeTimer.current) clearTimeout(snoozeTimer.current); }, []);

  if (!summary) return null;
  const isBreak = summary.mode !== 'focus';
  const long = summary.nextBreak === 'longBreak';
  const naturalFocus = !isBreak && !summary.early;
  const breakMinutes = long ? data.settings.longBreakMinutes : data.settings.shortBreakMinutes;
  const title = isBreak ? O.breakDoneTitle : summary.early ? O.focusEarlyTitle : O.focusDoneTitle;
  const elapsed = formatElapsed(summary.actualSeconds);
  const body = isBreak ? O.breakDoneBody
    : !summary.saved ? O.focusTooShort
    : summary.early ? O.focusEarlyBody(elapsed, summary.plannedMinutes)
    : O.focusDoneBody(elapsed, summary.distractionCount);

  const close = () => setDismissedKey(key);
  const doSnooze = () => {
    close();
    snooze(5).catch(() => undefined);
    if (snoozeTimer.current) clearTimeout(snoozeTimer.current);
    snoozeTimer.current = setTimeout(() => setDismissedKey(null), 5 * 60 * 1000);
  };
  const next = () => {
    close();
    if (naturalFocus) startBreak(summary.nextBreak);
    else startFocus(timer.taskId, timer.subjectId, true);
  };
  const skipBreak = () => { close(); startFocus(timer.taskId, timer.subjectId, true); };

  return (
    <Modal visible={visible} animationType="fade" presentationStyle="fullScreen" onRequestClose={close} statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: theme.dark ? '#0E1F17' : '#244B3E' }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 28, gap: 18 }}>
          <View style={{ alignItems: 'center', gap: 14 }}>
            <View style={{ width: 92, height: 92, borderRadius: 46, backgroundColor: theme.accent, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name={isBreak ? 'battery-charging' : 'checkmark-done'} size={46} color={theme.accentText} />
            </View>
            <Text accessibilityRole="header" style={{ color: '#FFFFFF', fontSize: 30, fontWeight: '900', textAlign: 'center', letterSpacing: -0.6 }}>{title}</Text>
            {!isBreak && summary.saved && (
              <View style={{ flexDirection: 'row', gap: 12, alignSelf: 'stretch' }}>
                <View style={{ flex: 1, backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: 20, padding: 16, alignItems: 'center' }}>
                  <Text style={{ color: '#C4D8CD', fontSize: 11, fontWeight: '800', letterSpacing: 1 }}>{O.actualLabel}</Text>
                  <Text accessibilityLabel={`${summary.actualMinutes} minutes focused`} style={{ color: '#FFFFFF', fontSize: 34, fontWeight: '900', marginTop: 4 }}>{elapsed}</Text>
                </View>
                {summary.early && <View style={{ flex: 1, backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 20, padding: 16, alignItems: 'center' }}>
                  <Text style={{ color: '#C4D8CD', fontSize: 11, fontWeight: '800', letterSpacing: 1 }}>{O.plannedLabel}</Text>
                  <Text style={{ color: '#FFFFFF', fontSize: 34, fontWeight: '900', marginTop: 4 }}>{summary.plannedMinutes}m</Text>
                </View>}
              </View>
            )}
            <Text style={{ color: '#D9E7DE', fontSize: 16, lineHeight: 24, textAlign: 'center' }}>{body}</Text>
            {naturalFocus && long && <Text style={{ color: theme.accent, fontWeight: '800', textAlign: 'center' }}>{O.longBreakEarned}</Text>}
            {summary.interruptions > 0 && <Text style={{ color: '#F5C98A', fontWeight: '700', textAlign: 'center' }}>{O.interrupted(summary.interruptions)}</Text>}
          </View>
          <Button title={naturalFocus ? O.startBreak(breakMinutes, long) : O.startFocus} icon={naturalFocus ? 'cafe' : 'play'} variant="accent" onPress={next} />
          {naturalFocus && <Button title={O.skipBreak} variant="ghost" onPress={skipBreak} style={{ borderColor: 'rgba(255,255,255,0.3)' }} />}
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button title={O.snooze} icon="alarm-outline" variant="ghost" style={{ flex: 1, borderColor: 'rgba(255,255,255,0.3)' }} onPress={doSnooze} />
            <Button title={O.close} variant="ghost" style={{ flex: 1, borderColor: 'rgba(255,255,255,0.3)' }} onPress={close} />
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}
