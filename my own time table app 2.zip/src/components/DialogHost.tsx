import React, { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';
import { Modal, Pressable, StyleSheet, View } from 'react-native';
import { radius, useTheme } from '../theme';
import { Text } from './Text';

export interface DialogOption {
  id: string;
  label: string;
  tone?: 'default' | 'primary' | 'destructive';
}

interface DialogRequest {
  title: string;
  message?: string;
  options: DialogOption[];
  resolve: (id: string | null) => void;
}

interface DialogApi {
  /** Shows a message with one OK button. */
  alert: (title: string, message?: string) => Promise<void>;
  /** Resolves true when the user confirms. */
  confirm: (o: { title: string; message?: string; confirmLabel: string; cancelLabel: string; destructive?: boolean }) => Promise<boolean>;
  /** Resolves with the chosen option id, or null if the dialog is dismissed. */
  choose: (o: { title: string; message?: string; options: DialogOption[] }) => Promise<string | null>;
}

const DialogContext = createContext<DialogApi | null>(null);

export function DialogProvider({ children, okLabel }: { children: React.ReactNode; okLabel: string }) {
  const theme = useTheme();
  const [request, setRequest] = useState<DialogRequest | null>(null);
  const queue = useRef<DialogRequest[]>([]);

  const show = useCallback((next: DialogRequest) => {
    setRequest((current) => {
      if (current) {
        queue.current.push(next);
        return current;
      }
      return next;
    });
  }, []);

  const close = (id: string | null) => {
    request?.resolve(id);
    const upcoming = queue.current.shift() ?? null;
    setRequest(upcoming);
  };

  const api = useMemo<DialogApi>(() => ({
    alert: (title, message) => new Promise<void>((resolve) => show({ title, message, options: [{ id: 'ok', label: okLabel, tone: 'primary' }], resolve: () => resolve() })),
    confirm: (o) => new Promise<boolean>((resolve) => show({
      title: o.title, message: o.message,
      options: [{ id: 'yes', label: o.confirmLabel, tone: o.destructive ? 'destructive' : 'primary' }, { id: 'no', label: o.cancelLabel }],
      resolve: (id) => resolve(id === 'yes'),
    })),
    choose: (o) => new Promise<string | null>((resolve) => show({ title: o.title, message: o.message, options: o.options, resolve })),
  }), [show, okLabel]);

  return (
    <DialogContext.Provider value={api}>
      {children}
      <Modal visible={request !== null} transparent animationType="fade" onRequestClose={() => close(null)} statusBarTranslucent>
        <Pressable style={styles.backdrop} onPress={() => close(null)}>
          <Pressable style={[styles.sheet, { backgroundColor: theme.surface, borderColor: theme.border }]} onPress={() => undefined}>
            <Text style={[styles.title, { color: theme.text }]} accessibilityRole="header">{request?.title}</Text>
            {!!request?.message && <Text style={[styles.message, { color: theme.muted }]}>{request.message}</Text>}
            <View style={styles.options}>
              {request?.options.map((option) => {
                const bg = option.tone === 'primary' ? theme.primary : option.tone === 'destructive' ? (theme.dark ? '#3B2224' : '#FCE8E8') : theme.surfaceAlt;
                const fg = option.tone === 'primary' ? (theme.dark ? '#102019' : '#FFFFFF') : option.tone === 'destructive' ? theme.danger : theme.text;
                return (
                  <Pressable key={option.id} onPress={() => close(option.id)} accessibilityRole="button"
                    style={({ pressed }) => [styles.option, { backgroundColor: bg }, pressed && { opacity: 0.75 }]}>
                    <Text style={[styles.optionText, { color: fg }]}>{option.label}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </DialogContext.Provider>
  );
}

export function useDialog(): DialogApi {
  const ctx = useContext(DialogContext);
  if (!ctx) throw new Error('useDialog must be used inside DialogProvider');
  return ctx;
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  sheet: { width: '100%', maxWidth: 420, borderRadius: radius.xl, borderWidth: 1, padding: 22, gap: 10 },
  title: { fontSize: 19, fontWeight: '900', letterSpacing: -0.3 },
  message: { fontSize: 14, lineHeight: 21 },
  options: { gap: 8, marginTop: 10 },
  option: { minHeight: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, paddingVertical: 10 },
  optionText: { fontWeight: '800', fontSize: 14, textAlign: 'center' },
});
