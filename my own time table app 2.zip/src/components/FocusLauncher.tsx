import { useCallback } from 'react';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../store/AppContext';
import { useDialog } from './DialogHost';
import { remainingSecondsAt } from '../lib/timerMachine';
import { focus as F } from '../i18n/focus';

export type LaunchResult = 'started' | 'resumed' | 'cancelled';

/**
 * Starts a focus session for a task. Never leaves the user with a dead button: when a session is already
 * paused or running they get an explicit choice. Navigation to the Focus tab happens only if something started.
 */
export function useFocusLauncher() {
  const { timer, data, startFocus, resumeTimer, finishTimer } = useApp();
  const dialog = useDialog();
  const navigation = useNavigation<{ navigate: (name: string) => void }>();

  return useCallback(async (taskId?: string, subjectId?: string, options: { navigate?: boolean } = {}): Promise<LaunchResult> => {
    const go = options.navigate ?? true;
    const open = () => { if (go) navigation.navigate('Focus'); };

    if (timer.status === 'running' || timer.status === 'paused') {
      const paused = timer.status === 'paused';
      const sameTask = taskId !== undefined && taskId === timer.taskId;
      if (sameTask && paused) { resumeTimer(); open(); return 'resumed'; }
      const left = remainingSecondsAt(timer, Date.now());
      const title = data.tasks.find((t) => t.id === timer.taskId)?.title ?? F.unassignedName;
      const minutes = left < 60 ? F.lessThanMinute : F.minutesLeft(Math.ceil(left / 60));
      const choice = await dialog.choose({
        title: paused ? F.conflictPausedTitle : F.conflictRunningTitle,
        message: F.conflictMessage(title, minutes),
        options: [
          ...(paused ? [{ id: 'resume', label: F.conflictResume, tone: 'primary' as const }] : [{ id: 'keep', label: F.conflictKeep, tone: 'primary' as const }]),
          { id: 'save', label: F.conflictSave },
          { id: 'discard', label: F.conflictDiscard, tone: 'destructive' as const },
          { id: 'cancel', label: F.conflictCancel },
        ],
      });
      if (choice === 'resume') { resumeTimer(); open(); return 'resumed'; }
      if (choice === 'keep') { open(); return 'resumed'; }
      if (choice === 'save' || choice === 'discard') {
        if (choice === 'save') finishTimer(true);
        if (startFocus(taskId, subjectId, true) === 'started') { open(); return 'started'; }
      }
      return 'cancelled';
    }
    if (startFocus(taskId, subjectId) === 'started') { open(); return 'started'; }
    return 'cancelled';
  }, [timer, data.tasks, dialog, navigation, resumeTimer, finishTimer, startFocus]);
}
