import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { useApp } from '../store/AppContext';
import { useDialog } from './DialogHost';
import { notifications } from '../lib/notifications';
import { NotifPermission } from '../lib/notificationTypes';
import { buildNotificationPlan } from '../utils/reminders';
import { formatTime } from '../utils/date';
import { notify } from '../i18n/base';

interface NotificationsContextValue {
  permission: NotifPermission;
  supported: boolean;
  /**
   * Makes sure we may notify. Shows our plain-language explanation once (before the system prompt) and never nags again.
   * Resolves true when notifications are allowed.
   */
  ensurePermission: () => Promise<boolean>;
  snooze: (minutes: number) => Promise<void>;
}

const NotificationsContext = createContext<NotificationsContextValue | null>(null);

export function NotificationBridge({ children }: { children: React.ReactNode }) {
  const { data, timer, hydrated, updateSettings, startBreak, startFocus, resumeTimer } = useApp();
  const dialog = useDialog();
  const [permission, setPermission] = useState<NotifPermission>('undetermined');
  const supported = notifications.isSupported();
  const dataRef = useRef(data);
  const timerRef = useRef(timer);
  dataRef.current = data;
  timerRef.current = timer;

  useEffect(() => {
    if (!supported) { setPermission('unsupported'); return; }
    notifications.getPermission().then(setPermission).catch(() => setPermission('undetermined'));
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') notifications.getPermission().then(setPermission).catch(() => undefined);
    });
    return () => sub.remove();
  }, [supported]);

  const ensurePermission = useCallback(async (): Promise<boolean> => {
    if (!supported) return false;
    const current = await notifications.getPermission();
    setPermission(current);
    if (current === 'granted') return true;
    if (current === 'denied') return false;
    if (!dataRef.current.settings.notificationsPrompted) {
      updateSettings({ notificationsPrompted: true });
      const choice = await dialog.choose({
        title: notify.primerTitle, message: notify.primerBody,
        options: [{ id: 'allow', label: notify.primerAllow, tone: 'primary' }, { id: 'later', label: notify.primerLater }],
      });
      if (choice !== 'allow') return false;
    }
    const result = await notifications.requestPermission();
    setPermission(result);
    return result === 'granted';
  }, [supported, dialog, updateSettings]);

  const snooze = useCallback(async (minutes: number) => { await notifications.snooze(minutes); }, []);

  // Ask once, with an explanation, the first time a timer is started.
  const wasRunning = useRef(false);
  useEffect(() => {
    if (!hydrated) return;
    const running = timer.status === 'running';
    if (running && !wasRunning.current && supported && !data.settings.notificationsPrompted) ensurePermission().catch(() => undefined);
    wasRunning.current = running;
  }, [timer.status, hydrated, supported, data.settings.notificationsPrompted, ensurePermission]);

  // Keep the OS-level schedule in step with the timer, tasks and per-type switches.
  useEffect(() => {
    if (!hydrated || !supported || permission !== 'granted') return;
    const timeout = setTimeout(() => {
      const plan = buildNotificationPlan({ timer, tasks: data.tasks, settings: data.settings, now: Date.now() });
      notifications.syncScheduled(plan).catch(() => undefined);
    }, 400);
    return () => clearTimeout(timeout);
  }, [hydrated, supported, permission, timer.status, timer.endAt, timer.mode, timer.completedFocus, data.tasks, data.settings]);

  // Lock-screen friendly "timer is running" notification.
  useEffect(() => {
    if (!hydrated || !supported || permission !== 'granted') return;
    if (timer.status === 'running' && timer.endAt !== undefined) {
      const end = new Date(timer.endAt);
      notifications.showOngoing(notify.ongoingTitle, notify.ongoingBody(formatTime(end.getHours() * 60 + end.getMinutes()))).catch(() => undefined);
    } else notifications.dismissOngoing().catch(() => undefined);
  }, [hydrated, supported, permission, timer.status, timer.endAt]);

  // Actions from the notification buttons (also fired when the app was opened by tapping them).
  useEffect(() => {
    if (!hydrated || !supported) return;
    return notifications.subscribe((action) => {
      const t = timerRef.current;
      if (action.type === 'start-break') startBreak(action.breakKind);
      else if (action.type === 'start-focus') startFocus(t.taskId, t.subjectId, t.status === 'completed' || t.status === 'idle');
      else if (action.type === 'snooze') notifications.snooze(5).catch(() => undefined);
      else if (action.type === 'open' && t.status === 'paused') resumeTimer();
    });
  }, [hydrated, supported, startBreak, startFocus, resumeTimer]);

  const value = useMemo(() => ({ permission, supported, ensurePermission, snooze }), [permission, supported, ensurePermission, snooze]);
  return <NotificationsContext.Provider value={value}>{children}</NotificationsContext.Provider>;
}

export function useNotifications(): NotificationsContextValue {
  const ctx = useContext(NotificationsContext);
  if (!ctx) throw new Error('useNotifications must be used inside NotificationBridge');
  return ctx;
}
