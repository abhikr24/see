import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useTheme } from '../theme';
import { addDays, formatHourLabel, formatTime, fromDateKey, toDateKey, todayKey, weekdayShort } from '../utils/date';
import { taskForm as TF } from '../i18n/planner';
import { common as C } from '../i18n/base';
import { Text } from './Text';
import { Button, IconButton, SheetModal } from './ui';

export function TimePickerSheet({ visible, value, onClose, onPick }: {
  visible: boolean; value: number; onClose: () => void; onPick: (minute: number) => void;
}) {
  const theme = useTheme();
  const [hour, setHour] = useState(Math.floor(value / 60));
  const [minute, setMinute] = useState(value % 60);
  useEffect(() => { if (visible) { setHour(Math.floor(value / 60)); setMinute(value % 60); } }, [visible, value]);
  const cell = (selected: boolean) => ({
    minWidth: 58, minHeight: 44, borderRadius: 12, alignItems: 'center' as const, justifyContent: 'center' as const, paddingHorizontal: 6,
    backgroundColor: selected ? theme.primary : theme.surfaceAlt,
  });
  return (
    <SheetModal visible={visible} onClose={onClose} title={TF.pickTime}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 18 }}>
        <View style={{ alignItems: 'center', paddingVertical: 8 }}>
          <Text style={{ color: theme.text, fontSize: 40, fontWeight: '900', letterSpacing: -1 }}>{formatTime(hour * 60 + minute)}</Text>
        </View>
        <Text style={{ color: theme.muted, fontWeight: '800', fontSize: 12 }}>{TF.hourLabel.toUpperCase()}</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {Array.from({ length: 24 }, (_, h) => (
            <Pressable key={h} onPress={() => setHour(h)} accessibilityRole="button" accessibilityLabel={formatHourLabel(h)} style={cell(h === hour)}>
              <Text style={{ color: h === hour ? (theme.dark ? '#102019' : '#FFF') : theme.text, fontWeight: '800', fontSize: 13 }}>{formatHourLabel(h)}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={{ color: theme.muted, fontWeight: '800', fontSize: 12 }}>{TF.minuteLabel.toUpperCase()}</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {Array.from({ length: 12 }, (_, i) => i * 5).map((m) => (
            <Pressable key={m} onPress={() => setMinute(m)} accessibilityRole="button" style={cell(m === minute)}>
              <Text style={{ color: m === minute ? (theme.dark ? '#102019' : '#FFF') : theme.text, fontWeight: '800', fontSize: 14 }}>{`:${String(m).padStart(2, '0')}`}</Text>
            </Pressable>
          ))}
        </View>
        <Button title={C.done} icon="checkmark" onPress={() => { onPick(hour * 60 + minute); onClose(); }} />
      </ScrollView>
    </SheetModal>
  );
}

export function DatePickerSheet({ visible, value, onClose, onPick, monday = true }: {
  visible: boolean; value: string; onClose: () => void; onPick: (date: string) => void; monday?: boolean;
}) {
  const theme = useTheme();
  const [cursor, setCursor] = useState(value.slice(0, 7));
  useEffect(() => { if (visible) setCursor(value.slice(0, 7)); }, [visible, value]);
  const first = `${cursor}-01`;
  const monthLabel = fromDateKey(first).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  const cells = useMemo(() => {
    const firstDow = fromDateKey(first).getDay();
    const lead = monday ? (firstDow + 6) % 7 : firstDow;
    const start = addDays(first, -lead);
    return Array.from({ length: 42 }, (_, i) => addDays(start, i));
  }, [first, monday]);
  const shiftMonth = (delta: number) => {
    const d = fromDateKey(first);
    d.setMonth(d.getMonth() + delta);
    setCursor(toDateKey(d).slice(0, 7));
  };
  const heads = cells.slice(0, 7).map((d) => weekdayShort(d).slice(0, 2));
  const today = todayKey();
  return (
    <SheetModal visible={visible} onClose={onClose} title={TF.pickDate}>
      <View style={{ padding: 20, gap: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <IconButton icon="chevron-back" label="Previous month" filled onPress={() => shiftMonth(-1)} />
          <Text style={{ color: theme.text, fontWeight: '900', fontSize: 17 }}>{monthLabel}</Text>
          <IconButton icon="chevron-forward" label="Next month" filled onPress={() => shiftMonth(1)} />
        </View>
        <View style={{ flexDirection: 'row' }}>
          {heads.map((h, i) => <Text key={i} style={{ flex: 1, textAlign: 'center', color: theme.muted, fontSize: 11, fontWeight: '800' }}>{h}</Text>)}
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {cells.map((date) => {
            const inMonth = date.startsWith(cursor);
            const selected = date === value;
            return (
              <Pressable key={date} onPress={() => { onPick(date); onClose(); }} accessibilityRole="button" accessibilityLabel={date}
                style={{ width: `${100 / 7}%`, height: 46, alignItems: 'center', justifyContent: 'center' }}>
                <View style={{ width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: selected ? theme.primary : 'transparent', borderWidth: date === today && !selected ? 1.5 : 0, borderColor: theme.primary }}>
                  <Text style={{ color: selected ? (theme.dark ? '#102019' : '#FFF') : inMonth ? theme.text : theme.faint, fontWeight: selected ? '900' : '600' }}>{fromDateKey(date).getDate()}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>
        <Button title={C.today} variant="secondary" icon="today-outline" onPress={() => { onPick(today); onClose(); }} />
      </View>
    </SheetModal>
  );
}

export function PickerField({ label, value, icon, onPress, onClear, clearLabel }: {
  label: string; value: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void; onClear?: () => void; clearLabel?: string;
}) {
  const theme = useTheme();
  return (
    <View style={{ gap: 6, flex: 1 }}>
      <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800', letterSpacing: 0.6 }}>{label}</Text>
      <Pressable onPress={onPress} accessibilityRole="button" style={{ minHeight: 50, borderRadius: 14, backgroundColor: theme.surfaceAlt, borderWidth: 1, borderColor: theme.border, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 13 }}>
        <Ionicons name={icon} size={18} color={theme.primary} />
        <Text style={{ color: theme.text, fontWeight: '800', fontSize: 15, flex: 1 }}>{value}</Text>
        {onClear && <Pressable onPress={onClear} hitSlop={10} accessibilityLabel={clearLabel}><Ionicons name="close-circle" size={18} color={theme.faint} /></Pressable>}
      </Pressable>
    </View>
  );
}

