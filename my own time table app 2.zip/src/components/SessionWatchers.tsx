import { useEffect, useRef } from 'react';
import { AppState } from 'react-native';
import { useApp } from '../store/AppContext';
import { remainingSecondsAt } from '../lib/timerMachine';
import { soundSources } from '../lib/soundSources';
import { focusSoundPlayer } from '../lib/focusSound';

/** Strict mode: leaving the app during a running focus session records an interruption. */
export function StrictModeWatcher() {
  const { data, timer, recordInterruption } = useApp();
  const stateRef = useRef({ strict: data.settings.strictMode, running: timer.status === 'running' && timer.mode === 'focus' });
  stateRef.current = { strict: data.settings.strictMode, running: timer.status === 'running' && timer.mode === 'focus' };
  const leftAt = useRef<number | null>(null);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (next) => {
      if (next === 'background') {
        if (stateRef.current.strict && stateRef.current.running && leftAt.current === null) {
          leftAt.current = Date.now();
          recordInterruption();
        }
      } else if (next === 'active') leftAt.current = null;
    });
    return () => subscription.remove();
  }, [recordInterruption]);
  return null;
}

/** Plays the chosen focus sound while a focus session runs, with a gentle fade in and out. */
export function FocusSoundWatcher() {
  const { data, timer } = useApp();
  const kind = data.settings.focusSound;
  const active = timer.status === 'running' && timer.mode === 'focus' && kind !== 'none';

  useEffect(() => {
    if (!active) { focusSoundPlayer.stop(); return; }
    focusSoundPlayer.start(soundSources[kind]);
    const interval = setInterval(() => {
      const remaining = remainingSecondsAt(timer, Date.now());
      const elapsed = timer.durationSeconds - remaining;
      const fadeIn = Math.min(1, elapsed / 3);
      const fadeOut = Math.min(1, remaining / 8);
      focusSoundPlayer.setVolume(0.7 * Math.max(0, Math.min(fadeIn, fadeOut)));
    }, 250);
    return () => { clearInterval(interval); };
  }, [active, kind, timer]);

  useEffect(() => () => focusSoundPlayer.stop(), []);
  return null;
}
