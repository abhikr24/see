import React from 'react';
import { Text as RNText, TextProps } from 'react-native';

/** Text that follows the phone's font-size setting but caps extreme scaling so layouts stay intact. */
export const MAX_FONT_SCALE = 1.6;

export function Text(props: TextProps) {
  return <RNText maxFontSizeMultiplier={MAX_FONT_SCALE} {...props} />;
}
