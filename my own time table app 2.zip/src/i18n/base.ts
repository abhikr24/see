// All user-facing text lives in this folder (assembled in strings.ts) so the app can be translated.
export const weekdayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const weekdayLong = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export const common = {
  appName: 'FocusFlow',
  cancel: 'Cancel', ok: 'OK', save: 'Save', delete: 'Delete', close: 'Close', back: 'Go back', done: 'Done', add: 'Add',
  edit: 'Edit', continue: 'Continue', yes: 'Yes', no: 'No', today: 'Today', tomorrow: 'Tomorrow', anytime: 'Anytime',
  min: 'min', minutesShort: (n: number) => `${n}m`, loading: 'Loading…', retry: 'Try again', none: 'None',
  preview: 'Preview', share: 'Share', copy: 'Copy', restore: 'Restore', discard: 'Discard', resume: 'Resume',
};

export const notify = {
  channelName: 'Timers & reminders',
  channelDescription: 'Focus session, break and study block alerts',
  focusEndTitle: 'Focus session complete',
  focusEndBody: (breakMinutes: number, long: boolean) => `Great work. Time for a ${breakMinutes}-minute ${long ? 'long' : 'short'} break.`,
  breakEndTitle: 'Break is over',
  breakEndBody: 'Ready for your next focus session?',
  blockTitle: (title: string) => `Up next: ${title}`,
  blockBody: (lead: number, time: string, duration: string) => `Starts in ${lead} min · ${time} · ${duration}`,
  actionStartBreak: 'Start break',
  actionSnooze: 'Snooze 5 min',
  actionStartFocus: 'Start focus',
  snoozeTitle: 'Reminder',
  snoozeBody: 'Your timer finished a few minutes ago. Ready to continue?',
  ongoingTitle: 'Focus session running',
  ongoingBody: (time: string) => `Ends at ${time}. Open FocusFlow to pause.`,
  primerTitle: 'Allow reminders?',
  primerBody: 'FocusFlow can alert you when a focus session or break ends — even when your phone is locked — and 5 minutes before a planned study block. You can switch each type off in Settings. We ask only once.',
  primerAllow: 'Allow reminders',
  primerLater: 'Not now',
  deniedHint: 'Notifications are blocked for FocusFlow. Turn them on in your phone settings to get alerts when the screen is locked.',
};
