const hourLabel = (h: number): string => (h === 0 ? '12 AM' : h === 12 ? '12 PM' : h < 12 ? `${h} AM` : `${h - 12} PM`);

export const insightText = {
  title: 'Your patterns',
  subtitle: 'Plain-language findings from your own sessions, reviews and plans.',
  sectionFindings: 'What your data says',
  sectionSubjects: 'Weekly goals by subject',
  needMore: (what: string) => `Not enough data yet for ${what}. Keep logging and it will appear here.`,
  bestHour: (hourLabel: string, share: number) => `You focus best around ${hourLabel} — ${share}% of your focus time happens in that hour. Put your hardest subject there.`,
  bestWeekday: (day: string, avg: number, worstDay: string, worstAvg: number) =>
    `${day} is your strongest day (about ${avg} min of focus on average). ${worstDay} is the weakest at ${worstAvg} min.`,
  bestWeekdayOnly: (day: string, avg: number) => `${day} is your strongest day, with about ${avg} min of focus on average.`,
  sleep: (goodAvg: number, shortAvg: number, goodDays: number, shortDays: number) =>
    goodAvg >= shortAvg
      ? `After 7+ hours of sleep you focus about ${goodAvg} min a day, versus ${shortAvg} min after shorter nights (${goodDays} vs ${shortDays} days). Protect your sleep before exam weeks.`
      : `Surprisingly, shorter nights (${shortAvg} min) match longer ones (${goodAvg} min) in your data so far — but only ${Math.min(goodDays, shortDays)} days to compare.`,
  energy: (highRate: number, lowRate: number, highDays: number, lowDays: number) =>
    `On days you rate your energy 4–5 you finish ${highRate}% of planned blocks (${highDays} days); at 1–2 it is ${lowRate}% (${lowDays} days). On low-energy days, plan fewer, shorter blocks.`,
  mood: (lowAvg: string, highAvg: string) =>
    `On low-mood days you park ${lowAvg} distractions per focus day, versus ${highAvg} on good days. When mood dips, shorten sessions and park thoughts early.`,
  subjectLine: (name: string, minutes: number, goal: number, pct: number) => `${name}: ${minutes} of ${goal} min this week (${pct}%).`,
  avoided: (name: string, minutes: number, undone: number) =>
    `You may be avoiding ${name}: ${minutes} min logged this week${undone ? ` and ${undone} planned ${undone === 1 ? 'block' : 'blocks'} left undone` : ''}. Schedule a short 25-minute block for it first thing tomorrow.`,
  onTrack: (name: string) => `${name} is on track for its weekly goal.`,
  noSubjects: 'Add subjects with weekly goals to see progress here.',
  hour: hourLabel,
  hourRange: (h: number) => `${hourLabel(h)}–${hourLabel((h + 1) % 24)}`,
  strictTitle: 'Strict mode',
  strictLine: (interrupted: number, total: number) => `${interrupted} of ${total} sessions were interrupted because you left the app.`,
  stats: { totalFocus: 'TOTAL FOCUS', blocksDone: 'BLOCKS DONE', streak: 'FOCUS STREAK', mood: 'AVERAGE MOOD', days: (n: number) => `${n} days` },
  range7: 'Last 7 days', range30: 'Last 30 days',
  rhythm: 'Focus rhythm', goal: (v: string) => `Daily goal ${v}`, best: (v: string) => `Best ${v}`,
  bestDay: 'BEST FOCUS DAY', noSessions: 'No sessions yet',
  balance: 'Subject balance', balanceEmpty: 'Complete a focus session with a subject to see your study balance.',
  consistency: '35-day consistency', less: 'Less', more: 'More',
  recs: 'What to try next',
  recCompletionLow: (pct: number) => `Your completion rate is ${pct}%. Plan fewer blocks and protect your Top 3 first.`,
  recCompletionOk: (pct: number) => `You completed ${pct}% of planned work. Keep protecting the priorities that matter.`,
  recGoalLow: (minutes: number) => `Add one ${minutes}-minute block on your most reliable day instead of changing the whole routine.`,
  recGoalOk: 'Your focus goal is within reach. Raise the difficulty, not necessarily the hours.',
  recDistractHigh: 'Distractions are recurring: keep your phone out of reach and use parking before opening another app.',
  recDistractLow: 'Your distraction log is light. Keep the same simple environment reset before each session.',
  recurring: 'Recurring distractions',
  reportCta: 'Weekly report card',
  reportCtaHint: 'A shareable image of your week.',
  footer: 'Analytics are calculated on your device from real sessions and reviews.',
};

export const reportText = {
  title: 'Weekly report card',
  heading: 'My FocusFlow week',
  focused: 'Minutes focused', blocks: 'Blocks completed', streak: 'Day streak', bestDay: 'Best day', topSubject: 'Top subject',
  recommendation: 'Next week, try this',
  none: '—',
  shareImage: 'Share as image', shareText: 'Share as text', saving: 'Preparing image…',
  shareError: 'Could not create the image on this device. Sharing as text instead.',
  recAvoided: (name: string) => `Book two 25-minute blocks for ${name} early in the week — it is the subject you have been avoiding.`,
  recBestHour: (hour: string) => `Move your hardest block to ${hour}, when you focus best.`,
  recLowFocus: (goal: number) => `Aim for a ${goal}-minute focus day twice next week before adding more.`,
  recStrong: 'Strong week. Add one review session for yesterday’s hardest topic to lock it in.',
  recFirst: 'Complete your first focus session this week — even 25 minutes starts your streak.',
  textBody: (r: { minutes: string; blocks: number; streak: number; bestDay: string; top: string; rec: string }) =>
    `My FocusFlow week\n\n• ${r.minutes} focused\n• ${r.blocks} blocks completed\n• ${r.streak}-day streak\n• Best day: ${r.bestDay}\n• Top subject: ${r.top}\n\nNext: ${r.rec}`,
};
