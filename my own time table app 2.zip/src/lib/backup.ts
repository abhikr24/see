import { AppData } from '../types';
import { countData, DataCounts, DATA_SCHEMA_VERSION, normalizeData } from './schema';
import { APP_VERSION } from './version';

export const BACKUP_SCHEMA_VERSION = DATA_SCHEMA_VERSION;

export interface BackupFile {
  app: 'FocusFlow';
  schemaVersion: number;
  appVersion: string;
  exportedAt: string;
  data: AppData;
}

export function buildBackup(data: AppData, now: Date = new Date()): BackupFile {
  return { app: 'FocusFlow', schemaVersion: BACKUP_SCHEMA_VERSION, appVersion: APP_VERSION, exportedAt: now.toISOString(), data };
}

export function serializeBackup(data: AppData, now: Date = new Date()): string {
  return JSON.stringify(buildBackup(data, now), null, 2);
}

export type ParsedBackup =
  | { ok: true; data: AppData; sourceVersion: number; exportedAt?: string; counts: DataCounts }
  | { ok: false; error: string };

/** Accepts v2 backups, v1 backups ({version: 1}) and bare AppData objects. Never throws. */
export function parseBackup(text: string): ParsedBackup {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    return { ok: false, error: 'This is not valid JSON. Pick a file exported from FocusFlow.' };
  }
  if (typeof raw !== 'object' || raw === null) return { ok: false, error: 'The file does not look like a FocusFlow backup.' };
  const record = raw as Record<string, unknown>;
  const isWrapped = 'data' in record && typeof record.data === 'object' && record.data !== null;
  const payload = isWrapped ? record.data : raw;
  const version = typeof record.schemaVersion === 'number' ? record.schemaVersion : typeof record.version === 'number' ? record.version : 1;
  if (isWrapped && record.app !== undefined && record.app !== 'FocusFlow') return { ok: false, error: 'This backup was created by a different app.' };
  if (version > BACKUP_SCHEMA_VERSION) {
    return { ok: false, error: `This backup uses a newer format (v${version}). Update FocusFlow, then try again.` };
  }
  const data = normalizeData(payload);
  if (!data) return { ok: false, error: 'The backup is missing tasks, subjects, sessions, reviews, exams or settings.' };
  return {
    ok: true, data, sourceVersion: version, counts: countData(data),
    exportedAt: typeof record.exportedAt === 'string' ? record.exportedAt : undefined,
  };
}
