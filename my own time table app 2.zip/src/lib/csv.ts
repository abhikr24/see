import { AppData } from '../types';
import { formatTime } from '../utils/date';

export function csvEscape(value: string | number | boolean | undefined): string {
  const text = value === undefined ? '' : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function toCsv(rows: (string | number | boolean | undefined)[][]): string {
  return `${rows.map((row) => row.map(csvEscape).join(',')).join('\r\n')}\r\n`;
}

export function tasksCsv(data: AppData): string {
  const subject = (id?: string) => data.subjects.find((s) => s.id === id)?.name ?? '';
  return toCsv([
    ['id', 'title', 'subject', 'kind', 'date', 'start', 'duration_min', 'priority', 'repeats', 'repeat_until', 'skipped_dates', 'completed_dates', 'notes'],
    ...data.tasks.map((t) => [
      t.id, t.title, subject(t.subjectId), t.kind, t.date, t.startMinute === undefined ? '' : formatTime(t.startMinute),
      t.durationMinutes, t.priority, t.recurrence === 'custom' ? `custom:${t.recurDays.join('|')}` : t.recurrence, t.recurUntil,
      t.skippedDates.join(' '), t.completedDates.join(' '), t.notes,
    ]),
  ]);
}

export function sessionsCsv(data: AppData): string {
  const subject = (id?: string) => data.subjects.find((s) => s.id === id)?.name ?? '';
  const task = (id?: string) => data.tasks.find((t) => t.id === id)?.title ?? '';
  return toCsv([
    ['id', 'started_at', 'ended_at', 'subject', 'task', 'planned_min', 'actual_min', 'actual_sec', 'completed', 'interrupted', 'interruptions', 'distractions'],
    ...data.sessions.map((s) => [
      s.id, s.startedAt, s.endedAt, subject(s.subjectId), task(s.taskId), s.plannedMinutes, s.actualMinutes, s.actualSeconds,
      s.completed, s.interrupted, s.interruptions, s.distractions.join('; '),
    ]),
  ]);
}
