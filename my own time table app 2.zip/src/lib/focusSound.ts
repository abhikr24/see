import { AudioPlayer, createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import { Platform } from 'react-native';

/** Single looping player for the focus soundscape. All calls are safe no-ops if audio is unavailable. */
class FocusSoundPlayer {
  private player: AudioPlayer | null = null;
  private source: number | null = null;

  async start(source: number): Promise<void> {
    try {
      if (this.player && this.source === source) {
        if (!this.player.playing) this.player.play();
        return;
      }
      this.stop();
      await setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: true, interruptionMode: 'duckOthers' });
      const player = createAudioPlayer(source);
      player.loop = true;
      player.volume = 0;
      player.play();
      if (Platform.OS !== 'web') player.setActiveForLockScreen(true, { title: 'FocusFlow', artist: 'Focus sound' });
      this.player = player;
      this.source = source;
    } catch {
      this.player = null;
    }
  }

  setVolume(volume: number): void {
    try {
      if (this.player) this.player.volume = volume;
    } catch {
      // player already released
    }
  }

  stop(): void {
    const player = this.player;
    this.player = null;
    this.source = null;
    if (!player) return;
    try {
      player.pause();
      if (Platform.OS !== 'web') player.setActiveForLockScreen(false);
      player.remove();
    } catch {
      // already released
    }
  }
}

export const focusSoundPlayer = new FocusSoundPlayer();
