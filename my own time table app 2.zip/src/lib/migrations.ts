/**
 * Versioned SQLite migrations. `PRAGMA user_version` stores the last applied version, so a phone that
 * has v1 only runs v2+ on update and existing rows are never dropped.
 */
export interface Migration {
  version: number;
  description: string;
  statements: string[];
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    description: 'Create document tables for planner data and a key/value table for settings, meta and timer',
    statements: [
      'CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY NOT NULL, date TEXT NOT NULL, json TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS subjects (id TEXT PRIMARY KEY NOT NULL, json TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY NOT NULL, started_at TEXT NOT NULL, json TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS reviews (date TEXT PRIMARY KEY NOT NULL, json TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS exams (id TEXT PRIMARY KEY NOT NULL, date TEXT NOT NULL, json TEXT NOT NULL)',
      'CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)',
    ],
  },
  {
    version: 2,
    description: 'Indexes for date-range queries',
    statements: [
      'CREATE INDEX IF NOT EXISTS idx_tasks_date ON tasks(date)',
      'CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at)',
      'CREATE INDEX IF NOT EXISTS idx_exams_date ON exams(date)',
    ],
  },
];

export const LATEST_SCHEMA_VERSION = MIGRATIONS[MIGRATIONS.length - 1].version;

export function pendingMigrations(currentVersion: number): Migration[] {
  return MIGRATIONS.filter((m) => m.version > currentVersion).sort((a, b) => a.version - b.version);
}
