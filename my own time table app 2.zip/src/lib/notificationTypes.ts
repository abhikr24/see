import { PlannedNotification } from '../utils/reminders';

export type NotifPermission = 'granted' | 'denied' | 'undetermined' | 'unsupported';

export type NotificationAction =
  | { type: 'start-break'; breakKind: 'shortBreak' | 'longBreak' }
  | { type: 'start-focus' }
  | { type: 'snooze' }
  | { type: 'open-block'; taskId?: string; date?: string }
  | { type: 'open' };

export interface NotificationsApi {
  isSupported: () => boolean;
  getPermission: () => Promise<NotifPermission>;
  requestPermission: () => Promise<NotifPermission>;
  /** Make the OS schedule exactly this plan (works with the phone locked). */
  syncScheduled: (plan: PlannedNotification[]) => Promise<void>;
  snooze: (minutes: number) => Promise<void>;
  showOngoing: (title: string, body: string) => Promise<void>;
  dismissOngoing: () => Promise<void>;
  subscribe: (handler: (action: NotificationAction) => void) => () => void;
}
