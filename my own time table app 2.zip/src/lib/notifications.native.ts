import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { notify } from '../i18n/base';
import { NotificationAction, NotificationsApi, NotifPermission } from './notificationTypes';
import { PlannedNotification } from '../utils/reminders';

const ALERT_CHANNEL = 'focusflow_alerts_v2';
const RUNNING_CHANNEL = 'focusflow_running_v1';
const CATEGORY_FOCUS_END = 'timerfocusend';
const CATEGORY_BREAK_END = 'timerbreakend';
const SOUND_FILE = 'chime.wav';
const ACTION_START_BREAK = 'start_break';
const ACTION_START_FOCUS = 'start_focus';
const ACTION_SNOOZE = 'snooze';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true }),
});

let setup: Promise<void> | null = null;

function ensureSetup(): Promise<void> {
  if (!setup) {
    setup = (async () => {
      if (Platform.OS === 'android') {
        // Max importance => heads-up on the lock screen; custom chime + vibration pattern live on the channel.
        await Notifications.setNotificationChannelAsync(ALERT_CHANNEL, {
          name: notify.channelName, description: notify.channelDescription, importance: Notifications.AndroidImportance.MAX,
          sound: SOUND_FILE, vibrationPattern: [0, 400, 200, 400, 200, 700], enableVibrate: true, enableLights: true,
          lightColor: '#C7E991', lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC, showBadge: false,
        });
        await Notifications.setNotificationChannelAsync(RUNNING_CHANNEL, {
          name: notify.ongoingTitle, importance: Notifications.AndroidImportance.LOW, sound: null, enableVibrate: false,
          lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC, showBadge: false,
        });
      }
      await Notifications.setNotificationCategoryAsync(CATEGORY_FOCUS_END, [
        { identifier: ACTION_START_BREAK, buttonTitle: notify.actionStartBreak, options: { opensAppToForeground: true } },
        { identifier: ACTION_SNOOZE, buttonTitle: notify.actionSnooze, options: { opensAppToForeground: false } },
      ]);
      await Notifications.setNotificationCategoryAsync(CATEGORY_BREAK_END, [
        { identifier: ACTION_START_FOCUS, buttonTitle: notify.actionStartFocus, options: { opensAppToForeground: true } },
        { identifier: ACTION_SNOOZE, buttonTitle: notify.actionSnooze, options: { opensAppToForeground: false } },
      ]);
    })().catch(() => undefined);
  }
  return setup;
}

function mapPermission(status: Notifications.PermissionStatus): NotifPermission {
  if (status === Notifications.PermissionStatus.GRANTED) return 'granted';
  if (status === Notifications.PermissionStatus.DENIED) return 'denied';
  return 'undetermined';
}

function categoryFor(item: PlannedNotification): string | undefined {
  if (item.kind === 'focus-end') return CATEGORY_FOCUS_END;
  if (item.kind === 'break-end') return CATEGORY_BREAK_END;
  return undefined;
}

function toAction(response: Notifications.NotificationResponse): NotificationAction | null {
  const data = response.notification.request.content.data as { kind?: string; nextBreak?: string; taskId?: string; date?: string } | undefined;
  switch (response.actionIdentifier) {
    case ACTION_START_BREAK:
      return { type: 'start-break', breakKind: data?.nextBreak === 'longBreak' ? 'longBreak' : 'shortBreak' };
    case ACTION_START_FOCUS:
      return { type: 'start-focus' };
    case ACTION_SNOOZE:
      return { type: 'snooze' };
    default:
      if (data?.kind === 'block-start') return { type: 'open-block', taskId: data.taskId, date: data.date };
      return { type: 'open' };
  }
}

const handled = new Set<string>();

export const notifications: NotificationsApi = {
  isSupported: () => Platform.OS === 'android' || Platform.OS === 'ios',
  async getPermission() {
    await ensureSetup();
    return mapPermission((await Notifications.getPermissionsAsync()).status);
  },
  async requestPermission() {
    await ensureSetup();
    const current = await Notifications.getPermissionsAsync();
    if (current.status === Notifications.PermissionStatus.GRANTED) return 'granted';
    return mapPermission((await Notifications.requestPermissionsAsync()).status);
  },
  async syncScheduled(plan) {
    await ensureSetup();
    const existing = await Notifications.getAllScheduledNotificationsAsync();
    const wanted = new Set(plan.map((item) => item.id));
    await Promise.all(existing.filter((n) => n.identifier !== 'snooze' && !wanted.has(n.identifier))
      .map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)));
    await Promise.all(plan.map((item) => Notifications.scheduleNotificationAsync({
      identifier: item.id,
      content: {
        title: item.title, body: item.body, sound: SOUND_FILE, vibrate: [0, 400, 200, 400, 200, 700], priority: Notifications.AndroidNotificationPriority.MAX,
        categoryIdentifier: categoryFor(item), data: item.data, color: '#315C4D',
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(item.fireAt), channelId: ALERT_CHANNEL },
    })));
  },
  async snooze(minutes) {
    await ensureSetup();
    await Notifications.scheduleNotificationAsync({
      identifier: 'snooze',
      content: { title: notify.snoozeTitle, body: notify.snoozeBody, sound: SOUND_FILE, vibrate: [0, 400, 200, 400], priority: Notifications.AndroidNotificationPriority.MAX, data: { kind: 'snooze' } },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL, seconds: minutes * 60, channelId: ALERT_CHANNEL },
    });
  },
  async showOngoing(title, body) {
    await ensureSetup();
    await Notifications.scheduleNotificationAsync({
      identifier: 'ongoing',
      content: { title, body, sticky: true, autoDismiss: false, sound: false, priority: Notifications.AndroidNotificationPriority.LOW, data: { kind: 'ongoing' } },
      trigger: Platform.OS === 'android' ? { channelId: RUNNING_CHANNEL } : null,
    });
  },
  async dismissOngoing() {
    await Notifications.dismissNotificationAsync('ongoing').catch(() => undefined);
    await Notifications.cancelScheduledNotificationAsync('ongoing').catch(() => undefined);
  },
  subscribe(handler) {
    const deliver = (response: Notifications.NotificationResponse) => {
      const key = `${response.notification.request.identifier}:${response.actionIdentifier}:${response.notification.date}`;
      if (handled.has(key)) return;
      handled.add(key);
      const action = toAction(response);
      if (action) handler(action);
    };
    const last = Notifications.getLastNotificationResponse();
    if (last) deliver(last);
    const subscription = Notifications.addNotificationResponseReceivedListener(deliver);
    return () => subscription.remove();
  },
};
