// Web / unsupported-platform fallback: reminders only work in the installed Android/iOS app.
// The in-app completion alert (CompletionOverlay) still works everywhere.
import { NotificationsApi } from './notificationTypes';

export const notifications: NotificationsApi = {
  isSupported: () => false,
  getPermission: async () => 'unsupported',
  requestPermission: async () => 'unsupported',
  syncScheduled: async () => undefined,
  snooze: async () => undefined,
  showOngoing: async () => undefined,
  dismissOngoing: async () => undefined,
  subscribe: () => () => undefined,
};
