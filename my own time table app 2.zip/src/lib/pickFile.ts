import * as DocumentPicker from 'expo-document-picker';
import { File } from 'expo-file-system';
import { Platform } from 'react-native';

/** Lets the user pick a JSON file and returns its text, or null if cancelled. */
export async function pickTextFile(): Promise<string | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ['application/json', 'text/plain', '*/*'], copyToCacheDirectory: true, multiple: false });
  if (result.canceled || result.assets.length === 0) return null;
  const asset = result.assets[0];
  if (Platform.OS === 'web') {
    const web = (asset as unknown as { file?: Blob }).file;
    if (web) return web.text();
    const response = await fetch(asset.uri);
    return response.text();
  }
  return new File(asset.uri).text();
}
