import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Share } from 'react-native';

export interface ShareFileResult { name: string; method: 'download' | 'share' }

export async function shareTextFile(name: string, content: string, mime: string): Promise<ShareFileResult> {
  try {
    const file = new File(Paths.cache, name);
    if (file.exists) file.delete();
    file.create();
    file.write(content);
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(file.uri, { mimeType: mime, dialogTitle: name, UTI: mime === 'text/csv' ? 'public.comma-separated-values-text' : 'public.json' });
      return { name, method: 'share' };
    }
  } catch {
    // fall through to the plain-text share sheet
  }
  await Share.share({ title: name, message: content });
  return { name, method: 'share' };
}

export async function shareImageUri(uri: string, name: string): Promise<ShareFileResult> {
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(uri, { mimeType: 'image/png', dialogTitle: name, UTI: 'public.png' });
    return { name, method: 'share' };
  }
  await Share.share({ url: uri });
  return { name, method: 'share' };
}
