// Web / fallback: download via an anchor tag. Native version lives in shareFile.native.ts.
import { Share } from 'react-native';

export interface ShareFileResult { name: string; method: 'download' | 'share' }

export async function shareTextFile(name: string, content: string, mime: string): Promise<ShareFileResult> {
  if (typeof document !== 'undefined' && typeof Blob !== 'undefined') {
    const url = URL.createObjectURL(new Blob([content], { type: mime }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return { name, method: 'download' };
  }
  await Share.share({ title: name, message: content });
  return { name, method: 'share' };
}

export async function shareImageUri(uri: string, name: string): Promise<ShareFileResult> {
  if (typeof document !== 'undefined') {
    const anchor = document.createElement('a');
    anchor.href = uri;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    return { name, method: 'download' };
  }
  await Share.share({ url: uri });
  return { name, method: 'share' };
}
