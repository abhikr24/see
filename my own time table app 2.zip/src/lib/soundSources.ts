import { FocusSoundKind } from '../types';

type Playable = Exclude<FocusSoundKind, 'none'>;

export const soundSources: Record<Playable, number> = {
  white: require('../../assets/sounds/white.wav') as number,
  rain: require('../../assets/sounds/rain.wav') as number,
  ambience: require('../../assets/sounds/ambience.wav') as number,
};
