// Native engine: SQLite with versioned migrations (expo-sqlite).
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SQLite from 'expo-sqlite';
import { AppData, TimerState } from '../types';
import { emptyData, isDemoData, normalizeData, normalizeTimer } from './schema';
import { pendingMigrations } from './migrations';
import { diffById, LEGACY_DATA_KEY, LEGACY_TIMER_KEY, LoadedState, StorageEngine } from './storageTypes';

const DB_NAME = 'focusflow.db';

function parse(text: string): unknown {
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return null;
  }
}

async function runMigrations(db: SQLite.SQLiteDatabase): Promise<void> {
  const row = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
  const current = row?.user_version ?? 0;
  for (const migration of pendingMigrations(current)) {
    await db.withTransactionAsync(async () => {
      for (const statement of migration.statements) await db.execAsync(statement);
    });
    await db.execAsync(`PRAGMA user_version = ${migration.version}`);
  }
}

export function createStorage(): StorageEngine {
  let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;
  let queue: Promise<unknown> = Promise.resolve();

  const open = (): Promise<SQLite.SQLiteDatabase> => {
    if (!dbPromise) {
      dbPromise = (async () => {
        const db = await SQLite.openDatabaseAsync(DB_NAME);
        await db.execAsync('PRAGMA journal_mode = WAL');
        await runMigrations(db);
        return db;
      })();
    }
    return dbPromise;
  };

  /** All writes go through one queue so transactions never interleave. */
  const enqueue = <T,>(task: (db: SQLite.SQLiteDatabase) => Promise<T>): Promise<T> => {
    const next = queue.then(async () => task(await open()));
    queue = next.catch(() => undefined);
    return next;
  };

  const kvSetOn = (db: SQLite.SQLiteDatabase, key: string, value: string) =>
    db.runAsync('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)', [key, value]);

  async function writeCollections(db: SQLite.SQLiteDatabase, prev: AppData, next: AppData): Promise<void> {
    const taskDiff = diffById(prev.tasks, next.tasks, (t) => t.id);
    for (const t of taskDiff.upserts) await db.runAsync('INSERT OR REPLACE INTO tasks (id, date, json) VALUES (?, ?, ?)', [t.id, t.date, JSON.stringify(t)]);
    for (const id of taskDiff.deletes) await db.runAsync('DELETE FROM tasks WHERE id = ?', [id]);

    const subjectDiff = diffById(prev.subjects, next.subjects, (s) => s.id);
    for (const s of subjectDiff.upserts) await db.runAsync('INSERT OR REPLACE INTO subjects (id, json) VALUES (?, ?)', [s.id, JSON.stringify(s)]);
    for (const id of subjectDiff.deletes) await db.runAsync('DELETE FROM subjects WHERE id = ?', [id]);

    const sessionDiff = diffById(prev.sessions, next.sessions, (s) => s.id);
    for (const s of sessionDiff.upserts) await db.runAsync('INSERT OR REPLACE INTO sessions (id, started_at, json) VALUES (?, ?, ?)', [s.id, s.startedAt, JSON.stringify(s)]);
    for (const id of sessionDiff.deletes) await db.runAsync('DELETE FROM sessions WHERE id = ?', [id]);

    const reviewDiff = diffById(prev.reviews, next.reviews, (r) => r.date);
    for (const r of reviewDiff.upserts) await db.runAsync('INSERT OR REPLACE INTO reviews (date, json) VALUES (?, ?)', [r.date, JSON.stringify(r)]);
    for (const id of reviewDiff.deletes) await db.runAsync('DELETE FROM reviews WHERE date = ?', [id]);

    const examDiff = diffById(prev.exams, next.exams, (e) => e.id);
    for (const e of examDiff.upserts) await db.runAsync('INSERT OR REPLACE INTO exams (id, date, json) VALUES (?, ?, ?)', [e.id, e.date, JSON.stringify(e)]);
    for (const id of examDiff.deletes) await db.runAsync('DELETE FROM exams WHERE id = ?', [id]);

    if (prev.settings !== next.settings) await kvSetOn(db, 'settings', JSON.stringify(next.settings));
    if (prev.meta !== next.meta) await kvSetOn(db, 'meta', JSON.stringify(next.meta));
  }

  async function readAll(db: SQLite.SQLiteDatabase): Promise<AppData | null> {
    const rows = async (table: string) => (await db.getAllAsync<{ json: string }>(`SELECT json FROM ${table}`)).map((r) => parse(r.json));
    const kv = async (key: string) => {
      const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM kv WHERE key = ?', [key]);
      return row ? parse(row.value) : null;
    };
    const [tasks, subjects, sessions, reviews, exams, settings, meta] = await Promise.all([
      rows('tasks'), rows('subjects'), rows('sessions'), rows('reviews'), rows('exams'), kv('settings'), kv('meta'),
    ]);
    const hasRows = [tasks, subjects, sessions, reviews, exams].some((list) => list.length > 0);
    if (!hasRows && !settings) return null;
    return normalizeData({ tasks, subjects, sessions, reviews, exams, settings: settings ?? {}, meta: meta ?? {} });
  }

  return {
    async load(): Promise<LoadedState> {
      const db = await open();
      let data = await readAll(db);
      let migrated = false;
      const imported = await db.getFirstAsync<{ value: string }>("SELECT value FROM kv WHERE key = 'legacy_import_done'");
      if (!imported) {
        // One-time import from the old AsyncStorage blob so existing data survives the move to SQLite.
        if (!data) {
          try {
            const text = await AsyncStorage.getItem(LEGACY_DATA_KEY);
            const legacy = text ? normalizeData(parse(text)) : null;
            if (legacy) {
              migrated = true;
              data = isDemoData(legacy) ? emptyData(legacy.settings) : legacy;
              const imported = data;
              await enqueue(async (conn) => {
                await conn.withTransactionAsync(async () => {
                  await writeCollections(conn, emptyData(), imported);
                  await kvSetOn(conn, 'settings', JSON.stringify(imported.settings));
                  await kvSetOn(conn, 'meta', JSON.stringify(imported.meta));
                });
              });
            }
          } catch {
            // A damaged legacy blob must never block the app from opening.
          }
        }
        await enqueue((conn) => kvSetOn(conn, 'legacy_import_done', new Date().toISOString()));
      }
      const resolved = data ?? emptyData();
      let timerRaw: unknown = null;
      const timerRow = await db.getFirstAsync<{ value: string }>("SELECT value FROM kv WHERE key = 'timer'");
      if (timerRow) timerRaw = parse(timerRow.value);
      else {
        try {
          const text = await AsyncStorage.getItem(LEGACY_TIMER_KEY);
          timerRaw = text ? parse(text) : null;
        } catch {
          timerRaw = null;
        }
      }
      return { data: resolved, timer: normalizeTimer(timerRaw, resolved.settings.focusMinutes), engine: 'sqlite', migratedFromLegacy: migrated };
    },
    save: (prev: AppData, next: AppData) => enqueue((db) => db.withTransactionAsync(() => writeCollections(db, prev, next))),
    saveTimer: (timer: TimerState) => enqueue(async (db) => { await kvSetOn(db, 'timer', JSON.stringify(timer)); }),
    replaceAll: (data: AppData) => enqueue((db) => db.withTransactionAsync(async () => {
      for (const table of ['tasks', 'subjects', 'sessions', 'reviews', 'exams']) await db.runAsync(`DELETE FROM ${table}`);
      await writeCollections(db, emptyData(), data);
      await kvSetOn(db, 'settings', JSON.stringify(data.settings));
      await kvSetOn(db, 'meta', JSON.stringify(data.meta));
    })),
    kvGet: async (key: string) => {
      const db = await open();
      const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM kv WHERE key = ?', [key]);
      return row ? row.value : null;
    },
    kvSet: (key: string, value: string) => enqueue(async (db) => { await kvSetOn(db, key, value); }),
  };
}
