// Web / fallback engine: one JSON document in AsyncStorage (localStorage on web).
// Native builds use SQLite instead — see storage.native.ts.
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppData, TimerState } from '../types';
import { emptyData, isDemoData, normalizeData, normalizeTimer } from './schema';
import { LEGACY_DATA_KEY, LEGACY_TIMER_KEY, LoadedState, StorageEngine } from './storageTypes';

const DATA_KEY = '@focusflow_data_v2';
const TIMER_KEY = '@focusflow_timer_v2';
const KV_PREFIX = '@focusflow_kv_';

async function readJson(key: string): Promise<unknown> {
  try {
    const text = await AsyncStorage.getItem(key);
    return text ? (JSON.parse(text) as unknown) : null;
  } catch {
    return null;
  }
}

export function createStorage(): StorageEngine {
  return {
    async load(): Promise<LoadedState> {
      let migrated = false;
      let data: AppData | null = normalizeData(await readJson(DATA_KEY));
      if (!data) {
        const legacy = normalizeData(await readJson(LEGACY_DATA_KEY));
        if (legacy) {
          migrated = true;
          data = isDemoData(legacy) ? emptyData(legacy.settings) : legacy;
        }
      }
      const resolved = data ?? emptyData();
      const timerRaw = (await readJson(TIMER_KEY)) ?? (await readJson(LEGACY_TIMER_KEY));
      const timer = normalizeTimer(timerRaw, resolved.settings.focusMinutes);
      return { data: resolved, timer, engine: 'local', migratedFromLegacy: migrated };
    },
    async save(_prev: AppData, next: AppData): Promise<void> {
      await AsyncStorage.setItem(DATA_KEY, JSON.stringify(next));
    },
    async saveTimer(timer: TimerState): Promise<void> {
      await AsyncStorage.setItem(TIMER_KEY, JSON.stringify(timer));
    },
    async replaceAll(data: AppData): Promise<void> {
      await AsyncStorage.setItem(DATA_KEY, JSON.stringify(data));
    },
    kvGet: (key: string) => AsyncStorage.getItem(`${KV_PREFIX}${key}`),
    kvSet: (key: string, value: string) => AsyncStorage.setItem(`${KV_PREFIX}${key}`, value),
  };
}
