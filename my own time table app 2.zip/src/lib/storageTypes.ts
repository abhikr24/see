import { AppData, TimerState } from '../types';

export interface LoadedState {
  data: AppData;
  timer: TimerState | null;
  engine: 'sqlite' | 'local';
  /** True when data from the old single-JSON-blob storage was imported on this launch. */
  migratedFromLegacy: boolean;
}

export interface StorageEngine {
  load(): Promise<LoadedState>;
  /** Persist only what changed between `prev` and `next`. */
  save(prev: AppData, next: AppData): Promise<void>;
  saveTimer(timer: TimerState): Promise<void>;
  /** Replace everything (restore / cloud download / reset). */
  replaceAll(data: AppData): Promise<void>;
  kvGet(key: string): Promise<string | null>;
  kvSet(key: string, value: string): Promise<void>;
}

export const LEGACY_DATA_KEY = '@focusflow_data_v1';
export const LEGACY_TIMER_KEY = '@focusflow_timer_v1';

/** Row-level diff by id using reference equality (state updates are immutable, so unchanged rows keep identity). */
export function diffById<T>(prev: T[], next: T[], key: (item: T) => string): { upserts: T[]; deletes: string[] } {
  const before = new Map(prev.map((item) => [key(item), item]));
  const after = new Set<string>();
  const upserts: T[] = [];
  next.forEach((item) => {
    const id = key(item);
    after.add(id);
    if (before.get(id) !== item) upserts.push(item);
  });
  const deletes = [...before.keys()].filter((id) => !after.has(id));
  return { upserts, deletes };
}
