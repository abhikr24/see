import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const URL_KEY = 'focusflow_supabase_url';
const ANON_KEY = 'focusflow_supabase_anon_key';
const extra = Constants.expoConfig?.extra as Record<string, string> | undefined;
const envUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || extra?.supabaseUrl || '';
const envKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || extra?.supabaseAnonKey || '';

let client: SupabaseClient | null = null;

async function readSecret(key: string): Promise<string> {
  if (Platform.OS === 'web') return (await AsyncStorage.getItem(key)) || '';
  return (await SecureStore.getItemAsync(key)) || '';
}

async function writeSecret(key: string, value: string): Promise<void> {
  if (Platform.OS === 'web') await AsyncStorage.setItem(key, value);
  else await SecureStore.setItemAsync(key, value);
}

export async function getSupabase(): Promise<SupabaseClient | null> {
  if (client) return client;
  const url = envUrl || (await readSecret(URL_KEY));
  const key = envKey || (await readSecret(ANON_KEY));
  if (!url || !key) return null;
  client = createClient(url, key, {
    auth: {
      storage: AsyncStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  });
  return client;
}

export async function saveSupabaseConfig(url: string, anonKey: string): Promise<void> {
  const cleanUrl = url.trim().replace(/\/$/, '');
  const cleanKey = anonKey.trim();
  let parsed: URL;
  try {
    parsed = new URL(cleanUrl);
  } catch {
    throw new Error('Enter a valid Supabase project URL.');
  }
  if (parsed.protocol !== 'https:') throw new Error('The Supabase URL must use HTTPS.');
  if (cleanKey.length < 20) throw new Error('Enter the complete anon public key.');
  await writeSecret(URL_KEY, cleanUrl);
  await writeSecret(ANON_KEY, cleanKey);
  client = createClient(cleanUrl, cleanKey, {
    auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
  });
}

export function hasEnvironmentConfig(): boolean {
  return Boolean(envUrl && envKey);
}

export async function hasSavedConfig(): Promise<boolean> {
  if (hasEnvironmentConfig()) return true;
  return Boolean((await readSecret(URL_KEY)) && (await readSecret(ANON_KEY)));
}
