import { DataCounts, hasAnyContent } from './schema';

export interface SyncLocalInfo {
  /** The user has actually put data on this device (or downloaded a real backup). */
  edited: boolean;
  /** Changes made since the last successful sync. */
  dirty: boolean;
  lastSyncedAt?: string;
  counts: DataCounts;
}

export interface SyncRemoteInfo {
  exists: boolean;
  valid: boolean;
  updatedAt?: string;
  counts?: DataCounts;
}

export type SyncDirection = 'upload' | 'download' | 'none' | 'conflict';
export type SyncReason =
  | 'local-pristine'      // never edited here -> cloud wins whatever the timestamps say
  | 'local-empty'         // device was cleared but the cloud still has data -> never overwrite it with nothing
  | 'nothing-to-upload'   // empty cloud, empty device
  | 'first-upload'        // empty cloud, device has data
  | 'remote-invalid'
  | 'local-changes'
  | 'remote-newer'
  | 'both-changed'
  | 'never-synced-both-have-data'
  | 'in-sync';

export interface SyncPlan { direction: SyncDirection; reason: SyncReason }

/**
 * Decide which way a smart sync will go. Pure so it can be previewed in the UI and unit tested.
 * Safety rules: a device that was never edited can never overwrite the cloud, and two diverged
 * copies are never merged silently.
 */
export function planSync(local: SyncLocalInfo, remote: SyncRemoteInfo): SyncPlan {
  if (!remote.exists) {
    return local.edited && hasAnyContent(local.counts)
      ? { direction: 'upload', reason: 'first-upload' }
      : { direction: 'none', reason: 'nothing-to-upload' };
  }
  if (!remote.valid) return { direction: 'none', reason: 'remote-invalid' };
  if (!local.edited) return { direction: 'download', reason: 'local-pristine' };
  if (!hasAnyContent(local.counts) && remote.counts && hasAnyContent(remote.counts)) return { direction: 'download', reason: 'local-empty' };
  if (!local.lastSyncedAt) {
    return remote.counts && hasAnyContent(remote.counts)
      ? { direction: 'conflict', reason: 'never-synced-both-have-data' }
      : { direction: 'upload', reason: 'first-upload' };
  }
  const remoteChanged = Boolean(remote.updatedAt) && new Date(remote.updatedAt as string).getTime() > new Date(local.lastSyncedAt).getTime() + 1000;
  if (local.dirty && remoteChanged) return { direction: 'conflict', reason: 'both-changed' };
  if (local.dirty) return { direction: 'upload', reason: 'local-changes' };
  if (remoteChanged) return { direction: 'download', reason: 'remote-newer' };
  return { direction: 'none', reason: 'in-sync' };
}

/** Auto-sync may only run actions that cannot lose data. */
export function isSafeForAuto(plan: SyncPlan): boolean {
  return plan.direction === 'upload' || (plan.direction === 'download' && plan.reason === 'remote-newer');
}
