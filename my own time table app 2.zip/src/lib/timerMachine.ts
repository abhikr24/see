import { FocusSession, TimerMode, TimerState, TimerSummary } from '../types';
import { toDateKey } from '../utils/date';

export interface TimerSettings {
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakEvery: number;
}

export type SessionDraft = Omit<FocusSession, 'id'>;
export interface FinishResult { state: TimerState; session?: SessionDraft }
export type PrimaryAction =
  | { kind: 'pause' }
  | { kind: 'resume' }
  | { kind: 'start-focus' }
  | { kind: 'start-break'; breakKind: 'shortBreak' | 'longBreak' };

export const MIN_SAVED_SECONDS = 30;

export function createIdleTimer(focusMinutes: number, completedFocus = 0, lastCompletedDay?: string): TimerState {
  return {
    mode: 'focus', status: 'idle', durationSeconds: focusMinutes * 60, remainingSeconds: focusMinutes * 60,
    completedFocus, lastCompletedDay, distractions: [], interruptions: 0,
  };
}

export function isActive(t: TimerState): boolean {
  return t.status === 'running' || t.status === 'paused';
}

export function remainingSecondsAt(t: TimerState, now: number): number {
  if (t.status !== 'running' || t.endAt === undefined) return t.remainingSeconds;
  return Math.max(0, Math.ceil((t.endAt - now) / 1000));
}

export function elapsedSecondsAt(t: TimerState, now: number): number {
  return Math.max(0, t.durationSeconds - remainingSecondsAt(t, now));
}

/** Which break follows the Nth completed focus session. The 4th (every Nth) is always the long break. */
export function breakAfter(completedFocus: number, every: number): 'shortBreak' | 'longBreak' {
  return completedFocus > 0 && completedFocus % Math.max(2, every) === 0 ? 'longBreak' : 'shortBreak';
}

/** A new calendar day starts a new Pomodoro set. */
function carriedCompleted(t: TimerState, day: string): number {
  return t.lastCompletedDay && t.lastCompletedDay !== day ? 0 : t.completedFocus;
}

export function startFocus(t: TimerState, o: { taskId?: string; subjectId?: string; focusMinutes: number; now: number }): TimerState {
  const seconds = o.focusMinutes * 60;
  return {
    mode: 'focus', status: 'running', taskId: o.taskId, subjectId: o.subjectId, durationSeconds: seconds, remainingSeconds: seconds,
    endAt: o.now + seconds * 1000, startedAt: new Date(o.now).toISOString(),
    completedFocus: carriedCompleted(t, toDateKey(new Date(o.now))), lastCompletedDay: t.lastCompletedDay,
    distractions: [], interruptions: 0,
  };
}

export function startBreak(t: TimerState, kind: 'shortBreak' | 'longBreak', s: TimerSettings, now: number): TimerState {
  const seconds = (kind === 'longBreak' ? s.longBreakMinutes : s.shortBreakMinutes) * 60;
  return {
    ...t, mode: kind, status: 'running', durationSeconds: seconds, remainingSeconds: seconds, endAt: now + seconds * 1000,
    startedAt: new Date(now).toISOString(), distractions: [], interruptions: 0, summary: undefined,
  };
}

export function pause(t: TimerState, now: number): TimerState {
  if (t.status !== 'running') return t;
  return { ...t, status: 'paused', remainingSeconds: remainingSecondsAt(t, now), endAt: undefined };
}

export function resume(t: TimerState, now: number): TimerState {
  if (t.status !== 'paused') return t;
  return { ...t, status: 'running', endAt: now + t.remainingSeconds * 1000 };
}

/** Back to an idle focus timer. The Pomodoro set progress is kept. */
export function reset(t: TimerState, focusMinutes: number): TimerState {
  return createIdleTimer(focusMinutes, t.completedFocus, t.lastCompletedDay);
}

/** Number of filled dots in the four-dot strip. */
export function dotsFilled(t: TimerState, every: number): number {
  const n = Math.max(2, every);
  if (t.completedFocus === 0) return 0;
  const justFinishedFocus = t.status === 'completed' && t.mode === 'focus' && !t.summary?.early;
  const inLongBreak = t.mode === 'longBreak' && t.status !== 'idle';
  if (justFinishedFocus || inLongBreak || (t.mode === 'shortBreak' && t.status !== 'idle')) {
    return ((t.completedFocus - 1) % n) + 1;
  }
  return t.completedFocus % n;
}

export function finish(t: TimerState, now: number, early: boolean, every: number): FinishResult {
  if (t.status === 'idle' || t.status === 'completed') return { state: t };
  const remaining = early ? remainingSecondsAt(t, now) : 0;
  const elapsed = Math.max(0, t.durationSeconds - remaining);
  const natural = !early;
  const day = toDateKey(new Date(now));
  const isFocus = t.mode === 'focus';
  const saved = isFocus && elapsed >= MIN_SAVED_SECONDS;
  const completedFocus = carriedCompleted(t, day) + (isFocus && natural ? 1 : 0);
  const nextBreak = breakAfter(completedFocus, every);
  const actualMinutes = saved ? Math.max(1, Math.round(elapsed / 60)) : Math.round(elapsed / 60);
  const summary: TimerSummary = {
    mode: t.mode, plannedMinutes: Math.round(t.durationSeconds / 60), actualMinutes, actualSeconds: elapsed, early, saved,
    interruptions: t.interruptions, distractionCount: t.distractions.length, nextBreak,
  };
  const session: SessionDraft | undefined = saved && t.startedAt ? {
    taskId: t.taskId, subjectId: t.subjectId, startedAt: t.startedAt,
    endedAt: new Date(natural && t.endAt !== undefined ? t.endAt : now).toISOString(),
    plannedMinutes: summary.plannedMinutes, actualMinutes, actualSeconds: elapsed, completed: natural,
    interrupted: t.interruptions > 0, interruptions: t.interruptions, distractions: t.distractions,
  } : undefined;
  return {
    state: {
      ...t, status: 'completed', remainingSeconds: remaining, endAt: undefined, completedFocus,
      lastCompletedDay: isFocus && natural ? day : t.lastCompletedDay, summary,
    },
    session,
  };
}

/** If a running timer has reached zero, settle it (also used when restoring after the app was closed). */
export function settleIfElapsed(t: TimerState, now: number, every: number): FinishResult | null {
  if (t.status !== 'running' || remainingSecondsAt(t, now) > 0) return null;
  return finish(t, now, false, every);
}

/** Strict mode: record that the user left the app during a running focus session. */
export function markInterruption(t: TimerState): TimerState {
  if (t.status !== 'running' || t.mode !== 'focus') return t;
  return { ...t, interruptions: t.interruptions + 1 };
}

export function addDistraction(t: TimerState, text: string): TimerState {
  const clean = text.trim();
  return clean ? { ...t, distractions: [...t.distractions, clean] } : t;
}

/** What the big primary button does in the current state. */
export function primaryAction(t: TimerState, every: number): PrimaryAction {
  if (t.status === 'running') return { kind: 'pause' };
  if (t.status === 'paused') return { kind: 'resume' };
  if (t.status === 'completed' && t.mode === 'focus' && t.summary && !t.summary.early) {
    return { kind: 'start-break', breakKind: t.summary.nextBreak ?? breakAfter(t.completedFocus, every) };
  }
  return { kind: 'start-focus' };
}

export function modeLabelKey(mode: TimerMode): 'focus' | 'short' | 'long' {
  return mode === 'focus' ? 'focus' : mode === 'shortBreak' ? 'short' : 'long';
}
