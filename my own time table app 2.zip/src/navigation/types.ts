export type RootStackParamList = {
  Main: undefined;
  TaskForm: { taskId?: string; date?: string; startMinute?: number; duration?: number; title?: string; kind?: 'study' | 'class' | 'revision' } | undefined;
  Settings: undefined;
  Subjects: undefined;
  Exams: undefined;
  Cloud: undefined;
  Backup: undefined;
  Timetable: undefined;
  Report: undefined;
};

export type MainTabParamList = {
  Today: undefined;
  Planner: { date?: string } | undefined;
  Focus: undefined;
  Review: undefined;
  Insights: undefined;
};
