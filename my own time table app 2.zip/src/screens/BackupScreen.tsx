import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { AppData } from '../types';
import { parseBackup, serializeBackup } from '../lib/backup';
import { countData, DataCounts } from '../lib/schema';
import { sessionsCsv, tasksCsv } from '../lib/csv';
import { shareTextFile } from '../lib/shareFile';
import { pickTextFile } from '../lib/pickFile';
import { downloadBackupFromDrive, uploadBackupToDrive } from '../lib/drive';
import { toDateKey } from '../utils/date';
import { Button, Card, Divider, Field, Header, Screen, SectionTitle, SheetModal } from '../components/ui';
import { Text } from '../components/Text';
import { useDialog } from '../components/DialogHost';
import { backup as B } from '../i18n/screens';
import { common as C } from '../i18n/base';

interface Pending { data: AppData; counts: DataCounts; sourceVersion: number; exportedAt?: string }

export default function BackupScreen() {
  const theme = useTheme();
  const navigation = useNavigation();
  const dialog = useDialog();
  const { data, replaceData } = useApp();
  const [pending, setPending] = useState<Pending | null>(null);
  const [pasted, setPasted] = useState('');
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  const stamp = toDateKey(new Date());
  const current = countData(data);

  const share = async (name: string, content: string, mime: string) => {
    try {
      const result = await shareTextFile(name, content, mime);
      if (result.method === 'download') await dialog.alert(B.exportDone, B.exportSaved(result.name));
    } catch {
      await dialog.alert(B.exportFail, B.exportFailMessage);
    }
  };

  const preview = async (text: string) => {
    const parsed = parseBackup(text);
    if (!parsed.ok) { await dialog.alert(B.invalid, parsed.error); return; }
    setPending({ data: parsed.data, counts: parsed.counts, sourceVersion: parsed.sourceVersion, exportedAt: parsed.exportedAt });
  };

  const chooseFile = async () => {
    try {
      const text = await pickTextFile();
      if (text !== null) await preview(text);
    } catch {
      await dialog.alert(B.invalid, B.readFail);
    }
  };

  const confirmRestore = async () => {
    if (!pending) return;
    const ok = await dialog.confirm({ title: B.confirmTitle, message: B.confirmMessage, confirmLabel: B.confirm, cancelLabel: C.cancel, destructive: true });
    if (!ok) return;
    replaceData(pending.data);
    const counts = pending.counts;
    setPending(null);
    setPasted('');
    await dialog.alert(B.restored, B.restoredMessage(counts.tasks, counts.reviews, counts.exams));
  };

  const drive = async (action: 'up' | 'down') => {
    if (!token.trim()) { await dialog.alert(B.driveTitle, B.driveNeedToken); return; }
    setBusy(true);
    try {
      if (action === 'up') {
        await uploadBackupToDrive(token.trim(), serializeBackup(data));
        await dialog.alert(B.driveTitle, B.driveSaved);
      } else {
        const text = await downloadBackupFromDrive(token.trim());
        if (text === null) await dialog.alert(B.driveTitle, B.driveNone);
        else await preview(text);
      }
    } catch (error) {
      await dialog.alert(B.driveError, error instanceof Error ? error.message : '');
    } finally {
      setBusy(false);
    }
  };

  const rows: (keyof DataCounts)[] = ['tasks', 'subjects', 'sessions', 'reviews', 'exams', 'topics'];

  return (
    <Screen>
      <Header title={B.title} subtitle={B.subtitle} onBack={navigation.goBack} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 16 }}>
        <Card style={{ gap: 12 }}>
          <SectionTitle title={B.exportTitle} icon="download-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 19 }}>{B.exportHint}</Text>
          <Button title={B.exportTitle} icon="share-outline" onPress={() => share(`focusflow-backup-${stamp}.json`, serializeBackup(data), 'application/json')} />
        </Card>

        <Card style={{ gap: 12 }}>
          <SectionTitle title={B.importTitle} icon="push-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 19 }}>{B.importHint}</Text>
          <Button title={B.pickFile} icon="document-outline" variant="secondary" onPress={chooseFile} />
          <Divider />
          <Field label={B.pasteLabel} value={pasted} onChangeText={setPasted} multiline placeholder={B.pastePh} autoCapitalize="none" autoCorrect={false} />
          <Button title={B.previewPasted} icon="eye-outline" variant="ghost" disabled={!pasted.trim()} onPress={() => preview(pasted)} />
        </Card>

        <Card style={{ gap: 12 }}>
          <SectionTitle title={B.csvTitle} icon="grid-outline" />
          <Text style={{ color: theme.muted, fontSize: 13 }}>{B.csvHint}</Text>
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Button title={B.csvTasks} icon="list-outline" variant="secondary" style={{ flexGrow: 1 }} onPress={() => share(`focusflow-tasks-${stamp}.csv`, tasksCsv(data), 'text/csv')} />
            <Button title={B.csvSessions} icon="timer-outline" variant="secondary" style={{ flexGrow: 1 }} onPress={() => share(`focusflow-sessions-${stamp}.csv`, sessionsCsv(data), 'text/csv')} />
          </View>
        </Card>

        <Card style={{ gap: 12 }}>
          <SectionTitle title={B.driveTitle} icon="logo-google" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 19 }}>{B.driveHint}</Text>
          <Field label={B.driveToken} value={token} onChangeText={setToken} placeholder="ya29…" autoCapitalize="none" autoCorrect={false} secureTextEntry hint={B.driveTokenHint} />
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <Button title={B.driveUpload} icon="cloud-upload-outline" loading={busy} style={{ flexGrow: 1 }} onPress={() => drive('up')} />
            <Button title={B.driveRestore} icon="cloud-download-outline" variant="ghost" style={{ flexGrow: 1 }} disabled={busy} onPress={() => drive('down')} />
          </View>
        </Card>
        <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center' }}>{B.deviceNote}</Text>
      </ScrollView>

      <SheetModal visible={pending !== null} onClose={() => setPending(null)} title={B.previewTitle}>
        {pending && <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
          <Text style={{ color: theme.muted, lineHeight: 20 }}>
            {B.previewIntro(pending.exportedAt ? new Date(pending.exportedAt).toLocaleString() : B.previewUnknownDate, pending.sourceVersion)}
          </Text>
          <Card style={{ gap: 4 }}>
            <View style={{ flexDirection: 'row', paddingBottom: 8 }}>
              <Text style={{ flex: 1.4 }}> </Text>
              <Text style={{ flex: 1, color: theme.muted, fontSize: 11, fontWeight: '800', textAlign: 'right' }}>{B.colNow.toUpperCase()}</Text>
              <Text style={{ flex: 1, color: theme.primary, fontSize: 11, fontWeight: '800', textAlign: 'right' }}>{B.colBackup.toUpperCase()}</Text>
            </View>
            {rows.map((key) => (
              <View key={key} style={{ flexDirection: 'row', paddingVertical: 8, borderTopWidth: 1, borderTopColor: theme.border }}>
                <Text style={{ flex: 1.4, color: theme.text, fontWeight: '700' }}>{B.rows[key]}</Text>
                <Text style={{ flex: 1, color: theme.muted, textAlign: 'right', fontVariant: ['tabular-nums'] }}>{current[key]}</Text>
                <Text style={{ flex: 1, color: pending.counts[key] === current[key] ? theme.text : theme.primary, textAlign: 'right', fontWeight: '900', fontVariant: ['tabular-nums'] }}>{pending.counts[key]}</Text>
              </View>
            ))}
          </Card>
          <Text style={{ color: theme.warning, lineHeight: 20, fontWeight: '600' }}>{B.replaceWarning}</Text>
          <Button title={B.confirm} icon="refresh" variant="danger" onPress={confirmRestore} />
          <Button title={C.cancel} variant="ghost" onPress={() => setPending(null)} />
        </ScrollView>}
      </SheetModal>
    </Screen>
  );
}
