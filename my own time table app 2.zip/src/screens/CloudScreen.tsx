import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, Switch, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp, CloudPlan } from '../store/AppContext';
import { useTheme } from '../theme';
import { getSupabase, hasEnvironmentConfig, hasSavedConfig, saveSupabaseConfig } from '../lib/supabase';
import { SyncStrategy } from '../types';
import { DataCounts } from '../lib/schema';
import { Badge, Button, Card, Divider, Field, Header, Screen, SectionTitle } from '../components/ui';
import { Text } from '../components/Text';
import { useDialog } from '../components/DialogHost';
import { cloud as L } from '../i18n/screens';
import { sync as SY } from '../i18n/sync';
import { common as C } from '../i18n/base';

function CountsLine({ counts, label }: { counts?: DataCounts; label: string }) {
  const theme = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: theme.surfaceAlt, borderRadius: 14, padding: 12, gap: 4 }}>
      <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{label.toUpperCase()}</Text>
      <Text style={{ color: theme.text, fontWeight: '800' }}>{counts ? `${counts.tasks} blocks · ${counts.sessions} sessions` : L.cloudEmpty}</Text>
      {counts && <Text style={{ color: theme.muted, fontSize: 12 }}>{counts.reviews} reviews · {counts.exams} exams</Text>}
    </View>
  );
}

export default function CloudScreen() {
  const theme = useTheme();
  const dialog = useDialog();
  const navigation = useNavigation();
  const { data, updateSettings, syncCloud, planCloudSync, syncStatus, syncMessage } = useApp();
  const [configured, setConfigured] = useState(false);
  const [editingConfig, setEditingConfig] = useState(false);
  const [url, setUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [accountEmail, setAccountEmail] = useState('');
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [plan, setPlan] = useState<CloudPlan | null>(null);

  useEffect(() => {
    let unsubscribe: () => void = () => undefined;
    let mounted = true;
    (async () => {
      const isConfigured = await hasSavedConfig();
      if (!mounted) return;
      setConfigured(isConfigured);
      if (isConfigured) {
        const supabase = await getSupabase();
        if (supabase) {
          const { data: sessionData } = await supabase.auth.getSession();
          if (mounted) setAccountEmail(sessionData.session?.user.email || '');
          const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { if (mounted) setAccountEmail(session?.user.email || ''); });
          unsubscribe = () => listener.subscription.unsubscribe();
        }
      }
      if (mounted) setLoading(false);
    })().catch((error: unknown) => { if (mounted) { setMessage(error instanceof Error ? error.message : SY.failed); setLoading(false); } });
    return () => { mounted = false; unsubscribe(); };
  }, []);

  const saveConfig = async () => {
    setLoading(true); setMessage('');
    try {
      await saveSupabaseConfig(url, anonKey);
      setConfigured(true); setEditingConfig(false); setUrl(''); setAnonKey('');
      setMessage(L.connectionSaved);
    } catch (error) { setMessage(error instanceof Error ? error.message : SY.failed); }
    finally { setLoading(false); }
  };

  const authenticate = async () => {
    if (!email.trim() || password.length < 6) { setMessage(L.needCreds); return; }
    setLoading(true); setMessage('');
    try {
      const supabase = await getSupabase();
      if (!supabase) throw new Error(SY.needConfig);
      if (mode === 'signin') {
        const { data: result, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        setAccountEmail(result.user.email || email.trim());
        setMessage(L.signedIn);
      } else {
        const { data: result, error } = await supabase.auth.signUp({ email: email.trim(), password });
        if (error) throw error;
        if (result.session) setAccountEmail(result.user?.email || email.trim());
        setMessage(result.session ? L.created : L.createdConfirm);
        if (!result.session) setMode('signin');
      }
      setPassword('');
    } catch (error) { setMessage(error instanceof Error ? error.message : SY.failed); }
    finally { setLoading(false); }
  };

  const checkPlan = async () => {
    setLoading(true); setMessage(''); setPlan(null);
    try { setPlan(await planCloudSync()); }
    catch (error) { setMessage(error instanceof Error ? error.message : SY.failed); }
    finally { setLoading(false); }
  };

  const run = async (strategy: SyncStrategy) => {
    setLoading(true); setMessage('');
    try { setMessage(await syncCloud(strategy)); setPlan(null); }
    catch (error) { setMessage(error instanceof Error ? error.message : SY.failed); }
    finally { setLoading(false); }
  };

  const confirmForce = async (strategy: 'upload' | 'download') => {
    const upload = strategy === 'upload';
    const cloudTasks = plan?.remote.counts?.tasks ?? 0;
    const ok = await dialog.confirm({
      title: upload ? L.uploadTitle : L.downloadTitle, message: upload ? L.uploadMessage(cloudTasks) : L.downloadMessage,
      confirmLabel: upload ? L.upload : L.download, cancelLabel: C.cancel, destructive: !upload,
    });
    if (ok) await run(strategy);
  };

  const signOut = async () => {
    const supabase = await getSupabase();
    await supabase?.auth.signOut();
    setAccountEmail(''); setPlan(null); setMessage(L.signedOut);
  };

  const dirLabel = plan ? SY.directions[plan.direction] : '';
  const planColor = plan?.direction === 'conflict' ? theme.warning : plan?.direction === 'download' ? theme.primary : theme.success;

  return (
    <Screen>
      <Header title={L.title} subtitle={L.subtitle} onBack={navigation.goBack} right={<Badge text={hasEnvironmentConfig() ? L.badgeEnv : configured ? L.badgeConnected : L.badgeNone} />} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 16 }}>
        <Card style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent', flexDirection: 'row', alignItems: 'center', gap: 13 }}>
          <View style={{ width: 48, height: 48, borderRadius: 16, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="cloud-done-outline" size={26} color={theme.primary} /></View>
          <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{accountEmail ? L.heroSignedIn : L.heroOffline}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, marginTop: 3 }}>{accountEmail || L.heroOfflineHint}</Text></View>
        </Card>

        {(!configured || editingConfig) ? <Card style={{ gap: 14 }}>
          <SectionTitle title={L.step1} icon="link-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 20 }}>{L.step1Text}</Text>
          <Field label={L.url} value={url} onChangeText={setUrl} placeholder="https://your-project.supabase.co" autoCapitalize="none" autoCorrect={false} keyboardType="url" />
          <Field label={L.anon} value={anonKey} onChangeText={setAnonKey} placeholder="eyJhbGciOiJIUzI1NiIs…" autoCapitalize="none" autoCorrect={false} multiline hint={L.anonHint} />
          <Button title={L.saveContinue} icon="shield-checkmark-outline" loading={loading} onPress={saveConfig} />
          {configured && <Button title={L.cancel} variant="ghost" onPress={() => setEditingConfig(false)} />}
        </Card> : !accountEmail ? <Card style={{ gap: 14 }}>
          <SectionTitle title={L.step2} icon="person-outline" />
          <View style={{ flexDirection: 'row', gap: 8 }}><Button title={L.signIn} variant={mode === 'signin' ? 'secondary' : 'ghost'} style={{ flex: 1 }} onPress={() => setMode('signin')} /><Button title={L.createAccount} variant={mode === 'signup' ? 'secondary' : 'ghost'} style={{ flex: 1 }} onPress={() => setMode('signup')} /></View>
          <Field label={L.email} value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} />
          <Field label={L.password} value={password} onChangeText={setPassword} placeholder={L.passwordPh} secureTextEntry autoCapitalize="none" />
          <Button title={mode === 'signin' ? L.signInSecure : L.createSync} icon="lock-closed-outline" loading={loading} onPress={authenticate} />
          {!hasEnvironmentConfig() && <Pressable accessibilityRole="button" onPress={() => setEditingConfig(true)}><Text style={{ color: theme.primary, fontSize: 12, textAlign: 'center', fontWeight: '700' }}>{L.updateProject}</Text></Pressable>}
        </Card> : <>
          <Card style={{ gap: 14 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}><SectionTitle title={L.step3} icon="sync-outline" /><Badge text={syncStatus.toUpperCase()} color={syncStatus === 'error' ? theme.danger : theme.primary} /></View>
            <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 20 }}>{L.planIntro}</Text>
            <Button title={L.checkPlan} icon="eye-outline" loading={loading} onPress={checkPlan} />
            {plan && <View style={{ gap: 12, borderWidth: 1, borderColor: planColor, borderRadius: 18, padding: 14 }}>
              <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{L.planTitle.toUpperCase()} · {L.planDirection}</Text>
              <Text style={{ color: planColor, fontSize: 20, fontWeight: '900' }}>{dirLabel}</Text>
              <Text style={{ color: theme.text, lineHeight: 21 }}>{SY.reasons[plan.reason]}</Text>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <CountsLine label={L.thisDevice} counts={plan.local.counts} />
                <CountsLine label={L.theCloud} counts={plan.remote.exists ? plan.remote.counts : undefined} />
              </View>
              {(plan.direction === 'upload' || plan.direction === 'download') && <Button title={L.runPlan} icon={plan.direction === 'upload' ? 'cloud-upload-outline' : 'cloud-download-outline'} onPress={() => run(plan.direction === 'upload' ? 'upload' : 'download')} loading={loading} />}
              {plan.direction === 'none' && <Text style={{ color: theme.success, fontWeight: '800' }}>{L.planNoop}</Text>}
            </View>}
            {(plan?.direction === 'conflict' || plan?.direction === 'none') && <>
              <Text style={{ color: theme.muted, fontSize: 12 }}>{L.forceHint}</Text>
              <View style={{ flexDirection: 'row', gap: 9 }}><Button title={L.upload} icon="cloud-upload-outline" variant="ghost" style={{ flex: 1 }} onPress={() => confirmForce('upload')} /><Button title={L.download} icon="cloud-download-outline" variant="ghost" style={{ flex: 1 }} onPress={() => confirmForce('download')} /></View>
            </>}
            <Divider />
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{L.autoSync}</Text><Text style={{ color: theme.muted, fontSize: 12, marginTop: 3, lineHeight: 17 }}>{L.autoSyncHint}</Text></View>
              <Switch accessibilityLabel={L.autoSync} value={data.settings.autoSync} onValueChange={(autoSync) => updateSettings({ autoSync })} trackColor={{ false: theme.border, true: theme.primary }} thumbColor={theme.surface} /></View>
            <Button title={L.signOut} variant="ghost" onPress={signOut} />
          </Card>
          <Card>
            <SectionTitle title={L.statusTitle} icon="information-circle-outline" />
            <Text style={{ color: syncStatus === 'error' ? theme.danger : theme.text, fontSize: 13, lineHeight: 20 }}>{message || syncMessage}</Text>
            <Divider />
            <View style={{ gap: 8 }}><Text style={{ color: theme.muted, fontSize: 12 }}>{L.localChanges}: <Text style={{ color: theme.text, fontWeight: '800' }}>{data.meta.dirty ? L.waiting : L.allSynced}</Text></Text>
              <Text style={{ color: theme.muted, fontSize: 12 }}>{L.lastSynced}: <Text style={{ color: theme.text, fontWeight: '800' }}>{data.meta.lastSyncedAt ? new Date(data.meta.lastSyncedAt).toLocaleString() : L.never}</Text></Text></View>
          </Card>
        </>}

        {!!message && !accountEmail && <Card style={{ borderColor: theme.border }}><Text style={{ color: theme.text, lineHeight: 20 }}>{message}</Text></Card>}
        <Card style={{ gap: 10 }}>
          <SectionTitle title={L.protectedTitle} icon="shield-checkmark-outline" />
          {L.protectedItems.map((item) => <View key={item} style={{ flexDirection: 'row', gap: 9 }}><Ionicons name="checkmark-circle" color={theme.primary} size={17} /><Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, flex: 1 }}>{item}</Text></View>)}
        </Card>
      </ScrollView>
    </Screen>
  );
}
