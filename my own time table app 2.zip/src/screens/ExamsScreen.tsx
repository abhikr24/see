import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { Exam, ExamTopic, StudyTask } from '../types';
import { addDays, clamp, daysUntil, formatLongDate, formatShortDate, formatTime, makeId, parseClock, todayKey, toClock } from '../utils/date';
import { generateRevisionPlan, RevisionProposal } from '../utils/revision';
import { Badge, Button, Card, Chip, Divider, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, SheetModal } from '../components/ui';
import { Text } from '../components/Text';
import { DatePickerSheet, PickerField } from '../components/Pickers';
import { useDialog } from '../components/DialogHost';
import { exams as E } from '../i18n/screens';
import { common as C } from '../i18n/base';

export default function ExamsScreen() {
  const theme = useTheme();
  const navigation = useNavigation();
  const dialog = useDialog();
  const { data, saveExam, deleteExam, saveTasks } = useApp();
  const [editing, setEditing] = useState<Exam | null>(null);
  const [modal, setModal] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(addDays(todayKey(), 14));
  const [time, setTime] = useState('09:00');
  const [subjectId, setSubjectId] = useState<string | undefined>();
  const [notes, setNotes] = useState('');
  const [topics, setTopics] = useState<ExamTopic[]>([]);
  const [newTopic, setNewTopic] = useState('');
  const [error, setError] = useState('');
  const [datePicker, setDatePicker] = useState(false);
  const [planExam, setPlanExam] = useState<Exam | null>(null);
  const [proposals, setProposals] = useState<RevisionProposal[]>([]);

  const open = (exam?: Exam) => {
    setEditing(exam || null); setTitle(exam?.title || ''); setDate(exam?.date || addDays(todayKey(), 14));
    setTime(exam?.time || '09:00'); setSubjectId(exam ? exam.subjectId : data.subjects.find((s) => !s.archived)?.id);
    setNotes(exam?.syllabus || ''); setTopics(exam?.topics || []); setNewTopic(''); setError(''); setModal(true);
  };
  const addTopic = () => {
    const text = newTopic.trim();
    if (!text) return;
    setTopics((previous) => [...previous, { id: makeId('topic'), title: text, done: false }]);
    setNewTopic('');
  };
  const save = () => {
    if (!title.trim()) { setError(E.errName); return; }
    if (parseClock(time) === undefined) { setError(E.errTime); return; }
    const pending = newTopic.trim() ? [...topics, { id: makeId('topic'), title: newTopic.trim(), done: false }] : topics;
    saveExam({ id: editing?.id || makeId('exam'), title: title.trim(), date, time: toClock(parseClock(time) as number), subjectId, syllabus: notes.trim(), topics: pending, createdAt: editing?.createdAt || new Date().toISOString() });
    setModal(false);
  };
  const remove = async (exam: Exam) => {
    const ok = await dialog.confirm({ title: E.deleteTitle, message: exam.title, confirmLabel: C.delete, cancelLabel: C.cancel, destructive: true });
    if (ok) deleteExam(exam.id);
  };
  const toggleTopic = (exam: Exam, topicId: string) => {
    saveExam({ ...exam, topics: exam.topics.map((t) => (t.id === topicId ? { ...t, done: !t.done } : t)) });
  };
  const openPlan = (exam: Exam) => {
    setPlanExam(exam);
    setProposals(generateRevisionPlan(exam, todayKey(), data.tasks, 17 * 60));
  };
  const patchProposal = (key: string, patch: Partial<RevisionProposal>) => setProposals((previous) => previous.map((p) => (p.key === key ? { ...p, ...patch } : p)));
  const applyPlan = async () => {
    if (!planExam) return;
    const chosen = proposals.filter((p) => p.include);
    const now = new Date().toISOString();
    const tasks: StudyTask[] = chosen.map((p) => ({
      id: makeId('task'), title: p.title, notes: p.notes, subjectId: planExam.subjectId, date: p.date, startMinute: p.startMinute, durationMinutes: p.durationMinutes,
      estimatedPomodoros: Math.max(1, Math.ceil(p.durationMinutes / data.settings.focusMinutes)), priority: p.offset <= 7 ? 'high' : 'medium', recurrence: 'none',
      recurDays: [], skippedDates: [], completedDates: [], topThreeDates: [], kind: 'revision', examId: planExam.id, createdAt: now, updatedAt: now,
    }));
    if (tasks.length) saveTasks(tasks);
    setPlanExam(null);
    if (tasks.length) await dialog.alert(E.planTitle, E.planDone(tasks.length));
  };
  const sorted = useMemo(() => [...data.exams].sort((a, b) => a.date.localeCompare(b.date)), [data.exams]);

  return (
    <Screen>
      <Header title={E.title} subtitle={E.subtitle} onBack={navigation.goBack} right={<IconButton icon="add" label={E.addExam} filled onPress={() => open()} />} />
      <FlatList data={sorted} keyExtractor={(item) => item.id} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 35, gap: 12 }}
        renderItem={({ item }) => {
          const subject = data.subjects.find((s) => s.id === item.subjectId);
          const days = daysUntil(item.date);
          const doneTopics = item.topics.filter((t) => t.done).length;
          const readiness = item.topics.length ? Math.round((doneTopics / item.topics.length) * 100) : 0;
          const examTasks = data.tasks.filter((t) => t.examId === item.id);
          return <Card style={{ borderTopWidth: 4, borderTopColor: subject?.color || theme.primary, gap: 12 }}>
            <Pressable accessibilityRole="button" onPress={() => open(item)} style={{ flexDirection: 'row', gap: 14, alignItems: 'center' }}>
              <View style={{ minWidth: 66, minHeight: 70, borderRadius: 18, backgroundColor: days < 0 ? theme.surfaceAlt : theme.primarySoft, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 }}>
                <Text style={{ color: days < 0 ? theme.muted : theme.primary, fontSize: 27, fontWeight: '900' }}>{Math.abs(days)}</Text>
                <Text maxFontSizeMultiplier={1.1} style={{ color: theme.muted, fontSize: 9, fontWeight: '800' }}>{days < 0 ? E.daysAgo : days === 0 ? E.todayLabel : E.daysLeft}</Text>
              </View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>{item.title}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 5 }}>{formatLongDate(item.date)}</Text>
                <View style={{ flexDirection: 'row', gap: 7, marginTop: 8, flexWrap: 'wrap' }}><Badge text={formatTime(parseClock(item.time) ?? 540)} color={subject?.color} />{subject && <Badge text={subject.name.toUpperCase()} color={subject.color} />}</View>
              </View>
              <IconButton icon="trash-outline" label={E.deleteExam} color={theme.danger} onPress={() => remove(item)} />
            </Pressable>
            <Divider />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{E.topics}</Text>
              <Text style={{ color: theme.text, fontSize: 12, fontWeight: '800' }}>{item.topics.length ? E.topicsProgress(doneTopics, item.topics.length) : ''}</Text>
            </View>
            {item.topics.length === 0 && <Text style={{ color: theme.muted, fontSize: 13 }}>{E.noTopics}</Text>}
            {item.topics.map((topic) => (
              <Pressable key={topic.id} accessibilityRole="checkbox" accessibilityState={{ checked: topic.done }} onPress={() => toggleTopic(item, topic.id)} style={{ flexDirection: 'row', alignItems: 'center', gap: 11, minHeight: 40 }}>
                <View style={{ width: 24, height: 24, borderRadius: 8, borderWidth: 2, borderColor: topic.done ? theme.primary : theme.border, backgroundColor: topic.done ? theme.primary : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                  {topic.done && <Ionicons name="checkmark" size={16} color={theme.dark ? '#102019' : '#FFF'} />}
                </View>
                <Text style={{ color: topic.done ? theme.muted : theme.text, flex: 1, textDecorationLine: topic.done ? 'line-through' : 'none', fontWeight: '600' }}>{topic.title}</Text>
              </Pressable>
            ))}
            <ProgressBar value={doneTopics} max={Math.max(1, item.topics.length)} color={subject?.color || theme.primary} />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: theme.muted, fontSize: 12 }}>{E.readiness}</Text><Text style={{ color: theme.text, fontSize: 12, fontWeight: '800' }}>{readiness}%</Text>
            </View>
            <Button title={E.revisionPlan} icon="sparkles" variant="secondary" onPress={() => openPlan(item)} />
            <Text style={{ color: theme.muted, fontSize: 12 }}>{E.revisionHint}{examTasks.length ? ` · ${examTasks.length}` : ''}</Text>
          </Card>;
        }}
        ListEmptyComponent={<EmptyState icon="school-outline" title={E.emptyTitle} message={E.emptyMessage} action={E.emptyAction} onAction={() => open()} />}
      />

      <SheetModal visible={modal} onClose={() => setModal(false)} title={editing ? E.editExam : E.newExam}>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20, gap: 18 }}>
          <Field label={E.name} value={title} onChangeText={(text) => { setTitle(text); setError(''); }} placeholder={E.namePh} autoFocus={!editing} />
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexGrow: 1, flexBasis: 150 }}><PickerField label={E.dateLabel.toUpperCase()} value={`${formatLongDate(date)} · ${daysUntil(date)}d`} icon="calendar" onPress={() => setDatePicker(true)} /></View>
            <View style={{ flexGrow: 1, flexBasis: 120 }}><Field label={E.timeLabel} value={time} onChangeText={(t) => { setTime(t); setError(''); }} placeholder="09:00" keyboardType="numbers-and-punctuation" /></View>
          </View>
          <View><SectionTitle title={E.subject} /><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {data.subjects.filter((s) => !s.archived).map((subject) => <Chip key={subject.id} label={subject.name} selected={subject.id === subjectId} color={subject.color} onPress={() => setSubjectId(subject.id)} />)}
            <Chip label={E.noSubject} selected={!subjectId} onPress={() => setSubjectId(undefined)} />
          </ScrollView></View>
          <Card style={{ gap: 10 }}>
            <SectionTitle title={E.topics} icon="list-outline" />
            {topics.map((topic) => (
              <View key={topic.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Pressable onPress={() => setTopics(topics.map((t) => (t.id === topic.id ? { ...t, done: !t.done } : t)))} accessibilityRole="checkbox" accessibilityState={{ checked: topic.done }}
                  style={{ width: 26, height: 26, borderRadius: 9, borderWidth: 2, borderColor: topic.done ? theme.primary : theme.border, backgroundColor: topic.done ? theme.primary : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                  {topic.done && <Ionicons name="checkmark" size={17} color={theme.dark ? '#102019' : '#FFF'} />}
                </Pressable>
                <Text style={{ color: theme.text, flex: 1 }}>{topic.title}</Text>
                <IconButton icon="close-circle" label={C.delete} color={theme.faint} onPress={() => setTopics(topics.filter((t) => t.id !== topic.id))} />
              </View>
            ))}
            <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end' }}>
              <View style={{ flex: 1 }}><Field value={newTopic} onChangeText={setNewTopic} placeholder={E.addTopicPh} returnKeyType="done" onSubmitEditing={addTopic} /></View>
              <Button title={E.addTopic} icon="add" variant="secondary" onPress={addTopic} disabled={!newTopic.trim()} style={{ minHeight: 48 }} />
            </View>
          </Card>
          <Field label={E.notes} value={notes} onChangeText={setNotes} multiline placeholder={E.notesPh} />
          {!!error && <Text accessibilityRole="alert" style={{ color: theme.danger }}>{error}</Text>}
          <Button title={E.save} icon="checkmark" onPress={save} />
        </ScrollView>
      </SheetModal>
      <DatePickerSheet visible={datePicker} value={date} monday={data.settings.weekStartsMonday} onClose={() => setDatePicker(false)} onPick={setDate} />

      <SheetModal visible={planExam !== null} onClose={() => setPlanExam(null)} title={E.planTitle}>
        <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
          {planExam && <Text style={{ color: theme.muted, lineHeight: 20 }}>{E.planIntro(planExam.title, daysUntil(planExam.date))}</Text>}
          {proposals.length === 0 && <EmptyState icon="checkmark-done-outline" title={E.planTitle} message={E.planEmpty} />}
          {proposals.map((p) => (
            <Card key={p.key} style={{ gap: 10, opacity: p.include ? 1 : 0.55 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Pressable onPress={() => patchProposal(p.key, { include: !p.include })} accessibilityRole="checkbox" accessibilityState={{ checked: p.include }}
                  style={{ width: 26, height: 26, borderRadius: 9, borderWidth: 2, borderColor: theme.primary, backgroundColor: p.include ? theme.primary : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                  {p.include && <Ionicons name="checkmark" size={17} color={theme.dark ? '#102019' : '#FFF'} />}
                </Pressable>
                <Badge text={E.planOffset(p.offset)} />
                <Text style={{ color: theme.text, fontWeight: '900', flex: 1 }}>{formatShortDate(p.date)} · {formatTime(p.startMinute)}</Text>
              </View>
              <Text style={{ color: theme.text, fontWeight: '700' }}>{p.title}</Text>
              <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18 }}>{p.notes}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                <Chip label={`− ${E.planEarlier}`} onPress={() => patchProposal(p.key, { date: addDays(p.date, -1) })} />
                <Chip label={`${E.planLater} +`} onPress={() => patchProposal(p.key, { date: addDays(p.date, 1) })} />
                <Chip label="−30m" icon="time-outline" onPress={() => patchProposal(p.key, { startMinute: clamp(p.startMinute - 30, 0, 1410) })} />
                <Chip label="+30m" icon="time-outline" onPress={() => patchProposal(p.key, { startMinute: clamp(p.startMinute + 30, 0, 1410) })} />
                <Chip label={`− ${p.durationMinutes}m`} onPress={() => patchProposal(p.key, { durationMinutes: clamp(p.durationMinutes - 15, 15, 240) })} />
                <Chip label={`${p.durationMinutes}m +`} onPress={() => patchProposal(p.key, { durationMinutes: clamp(p.durationMinutes + 15, 15, 240) })} />
              </View>
            </Card>
          ))}
          {proposals.length > 0 && <Button title={E.planAdd(proposals.filter((p) => p.include).length)} icon="add-circle" disabled={!proposals.some((p) => p.include)} onPress={applyPlan} />}
        </ScrollView>
      </SheetModal>
    </Screen>
  );
}
