import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Linking, Platform, Pressable, ScrollView, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { RootStackParamList } from '../navigation/types';
import { FocusSoundKind } from '../types';
import { formatDuration, formatTime, todayKey } from '../utils/date';
import { focusMinutesForDate, isTaskComplete, sessionsForDate, tasksForDate } from '../utils/selectors';
import { dotsFilled, elapsedSecondsAt, primaryAction, remainingSecondsAt } from '../lib/timerMachine';
import { Badge, Button, Card, Chip, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SheetModal, ToggleRow } from '../components/ui';
import { Text } from '../components/Text';
import { useDialog } from '../components/DialogHost';
import { IconName } from '../components/icons';
import { focus as F } from '../i18n/focus';

export default function FocusScreen() {
  const theme = useTheme();
  const dialog = useDialog();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data, timer, startFocus, startBreak, pauseTimer, resumeTimer, resetTimer, finishTimer, addDistraction, updateSettings } = useApp();
  const [now, setNow] = useState(Date.now());
  const [selectedTaskId, setSelectedTaskId] = useState<string | undefined>();
  const [taskPicker, setTaskPicker] = useState(false);
  const [distractionOpen, setDistractionOpen] = useState(false);
  const [distraction, setDistraction] = useState('');
  const every = data.settings.longBreakEvery;

  const remaining = remainingSecondsAt(timer, now);
  const elapsed = elapsedSecondsAt(timer, now);
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const running = timer.status === 'running';
  const active = running || timer.status === 'paused';
  const isBreak = timer.mode !== 'focus';
  const activeTaskId = active || timer.status === 'completed' ? timer.taskId ?? selectedTaskId : selectedTaskId;
  const activeTask = data.tasks.find((t) => t.id === activeTaskId);
  const activeSubject = data.subjects.find((s) => s.id === (timer.subjectId || activeTask?.subjectId));
  const todayTasks = useMemo(() => tasksForDate(data.tasks, todayKey()).filter((t) => !isTaskComplete(t, todayKey())), [data.tasks]);
  const focusedToday = focusMinutesForDate(data.sessions, todayKey()) ;
  const todaySessions = sessionsForDate(data.sessions, todayKey());
  const action = primaryAction(timer, every);
  const filled = dotsFilled(timer, every);

  useEffect(() => {
    if (!running) return;
    setNow(Date.now());
    const interval = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(interval);
  }, [running, timer.endAt]);

  const bigLabel = action.kind === 'pause' ? F.pause
    : action.kind === 'resume' ? F.resume
    : action.kind === 'start-break' ? (action.breakKind === 'longBreak' ? F.startLongBreak(data.settings.longBreakMinutes) : F.startShortBreak(data.settings.shortBreakMinutes))
    : timer.status === 'completed' ? F.startFocusNext : F.begin;
  const bigIcon: IconName = action.kind === 'pause' ? 'pause' : action.kind === 'start-break' ? 'cafe' : 'play';

  const onBig = () => {
    switch (action.kind) {
      case 'pause': pauseTimer(); break;
      case 'resume': resumeTimer(); break;
      case 'start-break': startBreak(action.breakKind); break;
      default: startFocus(timer.status === 'completed' ? timer.taskId ?? selectedTaskId : selectedTaskId, activeTask?.subjectId);
    }
  };

  const reset = async () => {
    if (active && !isBreak && elapsed > 30) {
      const ok = await dialog.confirm({ title: F.discardTitle, message: F.discardMessage, confirmLabel: F.discardAction, cancelLabel: F.keepFocusing, destructive: true });
      if (ok) resetTimer();
    } else resetTimer();
  };
  const endEarly = async () => {
    if (elapsed < 30) { await dialog.alert(F.tooShortTitle, F.tooShortMessage); return; }
    finishTimer(true);
  };
  const park = () => {
    if (!distraction.trim()) return;
    addDistraction(distraction);
    setDistraction('');
  };
  const openDnd = async () => {
    try {
      if (Platform.OS === 'android') await Linking.sendIntent('android.settings.ZEN_MODE_SETTINGS');
      else await Linking.openSettings();
    } catch {
      await dialog.alert(F.dnd, F.dndWebNote);
    }
  };
  const sounds: [FocusSoundKind, string][] = [['none', F.soundNone], ['white', F.soundWhite], ['rain', F.soundRain], ['ambience', F.soundAmbience]];
  const modeLabel = timer.mode === 'focus' ? F.modeFocus : timer.mode === 'longBreak' ? F.modeLong : F.modeShort;
  const stateLabel = running ? F.stateRunning : timer.status === 'paused' ? F.statePaused : timer.status === 'completed' ? F.stateDone : F.stateReady;

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ paddingBottom: 32 }} showsVerticalScrollIndicator={false}>
        <Header title={F.title} subtitle={F.subtitle} right={<IconButton icon="options-outline" label={F.timerSettings} filled onPress={() => navigation.navigate('Settings')} />} />
        <View style={{ paddingHorizontal: 20, gap: 18 }}>
          <View style={{ alignItems: 'center' }}>
            <View style={{ flexDirection: 'row', gap: 7, marginBottom: 6 }} accessibilityLabel={F.cycleLabel(filled, every)}>
              {Array.from({ length: every }, (_, index) => <View key={index} style={{ width: 28, height: 6, borderRadius: 4, backgroundColor: index < filled ? theme.primary : theme.border }} />)}
            </View>
            <Text style={{ color: theme.muted, fontSize: 11, marginBottom: 14 }}>{F.cycleLabel(filled, every)}</Text>
            <View style={{ width: 270, height: 270, borderRadius: 135, backgroundColor: theme.surfaceAlt, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.border }}>
              <View style={{ width: 246, height: 246, borderRadius: 123, borderWidth: running ? 7 : 3, borderColor: isBreak ? theme.warning : theme.primary, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.surface }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name={isBreak ? 'cafe-outline' : 'leaf-outline'} size={15} color={isBreak ? theme.warning : theme.primary} />
                  <Text maxFontSizeMultiplier={1.15} style={{ color: isBreak ? theme.warning : theme.primary, fontSize: 11, fontWeight: '900', letterSpacing: 1.2 }}>{modeLabel}</Text>
                </View>
                <Text maxFontSizeMultiplier={1.1} accessibilityLabel={`${minutes} minutes ${seconds} seconds`} style={{ color: theme.text, fontSize: 59, fontWeight: '900', letterSpacing: -3, fontVariant: ['tabular-nums'], marginTop: 7 }}>
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </Text>
                <Text maxFontSizeMultiplier={1.15} style={{ color: theme.muted, fontSize: 13 }}>{stateLabel}</Text>
                {active && <View style={{ width: 110, marginTop: 17 }}><ProgressBar value={elapsed} max={timer.durationSeconds} height={5} color={isBreak ? theme.warning : theme.primary} /></View>}
              </View>
            </View>
            {data.settings.strictMode && <View style={{ marginTop: 12 }}><Badge text={timer.interruptions > 0 ? F.interruptedLine(timer.interruptions) : F.strictBadge} color={timer.interruptions > 0 ? theme.warning : theme.primary} /></View>}
          </View>

          {!isBreak && <Pressable accessibilityRole="button" onPress={async () => {
            if (active) await dialog.alert(F.inProgressTitle, F.inProgressMessage);
            else setTaskPicker(true);
          }}>
            <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 }}>
              <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: activeSubject?.color || theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={(activeSubject?.icon || 'book-outline') as IconName} size={20} color={activeSubject ? '#FFFFFF' : theme.primary} />
              </View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{F.focusingOn}</Text>
                <Text numberOfLines={2} style={{ color: theme.text, fontWeight: '800', marginTop: 3 }}>{activeTask?.title || F.chooseBlock}</Text></View>
              <Ionicons name="chevron-down" size={18} color={theme.muted} />
            </Card>
          </Pressable>}

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button title={bigLabel} icon={bigIcon} style={{ flex: 1 }} variant={isBreak || action.kind === 'start-break' ? 'accent' : 'primary'} onPress={onBig} />
            {(timer.status !== 'idle') && <IconButton icon="refresh" label={F.resetTimer} filled onPress={reset} />}
          </View>
          {active && isBreak && <Button title={F.skipBreak} icon="play-skip-forward" variant="ghost" onPress={() => startFocus(timer.taskId ?? selectedTaskId, timer.subjectId, true)} />}
          {active && !isBreak && <Button title={F.endAndSave} icon="checkmark" variant="ghost" onPress={endEarly} />}
          {timer.status === 'completed' && action.kind === 'start-break' && <Button title={F.skipBreak} icon="play-skip-forward" variant="ghost" onPress={() => startFocus(timer.taskId ?? selectedTaskId, timer.subjectId, true)} />}

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Card style={{ flex: 1, padding: 14 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{F.today}</Text>
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 6 }}>{formatDuration(focusedToday)}</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>{F.sessions(todaySessions.length)}</Text></Card>
            <Card style={{ flex: 1, padding: 14 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{F.goal}</Text>
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 6 }}>{Math.round((focusedToday / Math.max(1, data.settings.dailyGoalMinutes)) * 100)}%</Text>
              <View style={{ marginTop: 8 }}><ProgressBar value={focusedToday} max={data.settings.dailyGoalMinutes} height={5} /></View></Card>
          </View>

          <Card style={{ gap: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Ionicons name="musical-notes-outline" size={19} color={theme.primary} />
              <Text style={{ color: theme.text, fontWeight: '800', flex: 1 }}>{F.sound}</Text>
            </View>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {sounds.map(([value, label]) => <Chip key={value} label={label} selected={data.settings.focusSound === value} onPress={() => updateSettings({ focusSound: value })} />)}
            </View>
            <Text style={{ color: theme.muted, fontSize: 12 }}>{F.soundHint}</Text>
            <ToggleRow icon="shield-checkmark-outline" title={F.strictTitle} subtitle={F.strictHint} value={data.settings.strictMode} onChange={(strictMode) => updateSettings({ strictMode })} />
            <Pressable accessibilityRole="button" onPress={openDnd} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, opacity: pressed ? 0.6 : 1 })}>
              <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="moon-outline" size={19} color={theme.primary} /></View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800', fontSize: 14 }}>{F.dnd}</Text><Text style={{ color: theme.muted, fontSize: 12 }}>{F.dndHint}</Text></View>
              <Ionicons name="open-outline" size={17} color={theme.muted} />
            </Pressable>
          </Card>

          <Card onPress={async () => { if (active) setDistractionOpen(true); else await dialog.alert(F.parkStartFirstTitle, F.parkStartFirstMessage); }}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <Ionicons name="car-outline" size={25} color={theme.primary} />
            <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{F.parkTitle}</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{F.parkSubtitle}</Text></View>
            <Badge text={`${timer.distractions.length}`} />
          </Card>
          <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center', lineHeight: 18 }}>{F.absoluteNote}</Text>
        </View>
      </ScrollView>

      <SheetModal visible={taskPicker} onClose={() => setTaskPicker(false)} title={F.pickerTitle}>
        <FlatList data={todayTasks} keyExtractor={(item) => item.id} contentContainerStyle={{ padding: 20, gap: 10 }}
          ListHeaderComponent={<Pressable accessibilityRole="button" onPress={() => { setSelectedTaskId(undefined); setTaskPicker(false); }}>
            <Card style={{ borderColor: !selectedTaskId ? theme.primary : theme.border }}><Text style={{ color: theme.text, fontWeight: '800' }}>{F.pickerUnassigned}</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{F.pickerUnassignedHint}</Text></Card>
          </Pressable>}
          renderItem={({ item }) => {
            const subject = data.subjects.find((s) => s.id === item.subjectId);
            return <Card onPress={() => { setSelectedTaskId(item.id); setTaskPicker(false); }} style={{ borderColor: selectedTaskId === item.id ? theme.primary : theme.border }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><View style={{ width: 9, height: 36, borderRadius: 6, backgroundColor: subject?.color || theme.border }} />
                <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{item.title}</Text>
                  <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{subject?.name || F.noSubject} · {F.planned(item.durationMinutes)}{item.startMinute !== undefined ? ` · ${formatTime(item.startMinute)}` : ''}</Text></View>
                {selectedTaskId === item.id && <Ionicons name="checkmark-circle" color={theme.primary} size={22} />}</View>
            </Card>;
          }}
          ListEmptyComponent={<EmptyState icon="clipboard-outline" title={F.pickerEmptyTitle} message={F.pickerEmptyMessage} />}
        />
      </SheetModal>

      <SheetModal visible={distractionOpen} onClose={() => setDistractionOpen(false)} title={F.parkSheet}>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20, gap: 16 }}>
          <Text style={{ color: theme.muted, lineHeight: 20 }}>{F.parkExplain}</Text>
          <Field value={distraction} onChangeText={setDistraction} placeholder={F.parkPlaceholder} autoFocus returnKeyType="done" onSubmitEditing={park} />
          <Button title={F.parkAction} icon="add" onPress={park} disabled={!distraction.trim()} />
          {timer.distractions.map((item, index) => <Card key={`${item}_${index}`} style={{ padding: 13, flexDirection: 'row', gap: 9, alignItems: 'center' }}>
            <Ionicons name="checkmark" size={16} color={theme.primary} /><Text style={{ color: theme.text, flex: 1 }}>{item}</Text></Card>)}
          <Button title={F.backToFocus} variant="secondary" onPress={() => setDistractionOpen(false)} />
        </ScrollView>
      </SheetModal>
    </Screen>
  );
}
