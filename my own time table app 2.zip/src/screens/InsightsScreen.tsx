import React, { useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { RootStackParamList } from '../navigation/types';
import { addDays, dateFromIso, formatDuration, formatShortDate, fromDateKey, todayKey } from '../utils/date';
import { focusMinutesForDate, focusStreak, isTaskComplete, tasksForDate } from '../utils/selectors';
import { buildInsights, subjectProgress } from '../utils/insights';
import { Badge, Button, Card, Header, ProgressBar, Screen, SectionTitle, Segmented } from '../components/ui';
import { Text } from '../components/Text';
import { insightText as T } from '../i18n/insights';

export default function InsightsScreen() {
  const theme = useTheme();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data } = useApp();
  const [range, setRange] = useState<'7' | '30'>('7');
  const days = useMemo(() => Array.from({ length: Number(range) }, (_, index) => addDays(todayKey(), index - Number(range) + 1)), [range]);
  const values = days.map((date) => focusMinutesForDate(data.sessions, date));
  const total = values.reduce((sum, value) => sum + value, 0);
  const max = Math.max(data.settings.dailyGoalMinutes, ...values, 1);
  const bestValue = Math.max(...values);
  const bestDay = days[values.indexOf(bestValue)];
  const tasksDone = days.reduce((sum, date) => sum + tasksForDate(data.tasks, date).filter((task) => isTaskComplete(task, date)).length, 0);
  const tasksTotal = days.reduce((sum, date) => sum + tasksForDate(data.tasks, date).length, 0);
  const completion = tasksTotal ? Math.round((tasksDone / tasksTotal) * 100) : 0;
  const moodValues = data.reviews.filter((r) => days.includes(r.date) && r.mood > 0).map((r) => r.mood);
  const averageMood = moodValues.length ? (moodValues.reduce((a, b) => a + b, 0) / moodValues.length).toFixed(1) : '—';
  const streak = focusStreak(data.sessions);
  const rangeSessions = data.sessions.filter((s) => days.includes(dateFromIso(s.startedAt)));
  const subjectData = data.subjects.map((subject) => ({
    ...subject, minutes: rangeSessions.filter((s) => s.subjectId === subject.id).reduce((sum, s) => sum + s.actualMinutes, 0),
  })).filter((s) => s.minutes > 0).sort((a, b) => b.minutes - a.minutes);
  const distractions = rangeSessions.flatMap((s) => s.distractions);
  const distractionCounts = Object.entries(distractions.reduce<Record<string, number>>((counts, item) => {
    const key = item.trim().toLowerCase();
    if (key) counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {})).sort((a, b) => b[1] - a[1]).slice(0, 3);
  const interrupted = rangeSessions.filter((s) => s.interrupted).length;
  const heatDays = Array.from({ length: 35 }, (_, index) => addDays(todayKey(), index - 34));
  const findings = useMemo(() => buildInsights(data), [data]);
  const progress = useMemo(() => subjectProgress(data), [data]);
  const recommendations = [
    completion < 60 && tasksTotal > 0 ? T.recCompletionLow(completion) : T.recCompletionOk(completion),
    total / Number(range) < data.settings.dailyGoalMinutes ? T.recGoalLow(data.settings.focusMinutes) : T.recGoalOk,
    distractions.length > Number(range) / 2 ? T.recDistractHigh : T.recDistractLow,
  ];
  const toneColor = (tone: 'good' | 'warn' | 'info') => (tone === 'warn' ? theme.warning : tone === 'good' ? theme.success : theme.primary);

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ paddingBottom: 38 }} showsVerticalScrollIndicator={false}>
        <Header title={T.title} subtitle={T.subtitle} right={<View style={{ width: 40 }}><Ionicons name="analytics" size={25} color={theme.primary} /></View>} />
        <View style={{ paddingHorizontal: 20, gap: 18 }}>
          <Card style={{ gap: 12 }}>
            <SectionTitle title={T.sectionFindings} icon="bulb-outline" />
            {findings.map((item) => (
              <View key={item.id} style={{ flexDirection: 'row', gap: 12, alignItems: 'flex-start' }}>
                <View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: `${toneColor(item.tone)}22`, alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name={item.icon} size={18} color={toneColor(item.tone)} />
                </View>
                <Text style={{ color: item.tone === 'info' && item.text.startsWith('Not enough') ? theme.muted : theme.text, flex: 1, lineHeight: 21, fontSize: 14 }}>{item.text}</Text>
              </View>
            ))}
          </Card>

          <Card>
            <SectionTitle title={T.sectionSubjects} icon="flag-outline" />
            {progress.length === 0 && <Text style={{ color: theme.muted, lineHeight: 20 }}>{T.noSubjects}</Text>}
            {progress.map((p) => (
              <View key={p.subject.id} style={{ marginBottom: 16, gap: 7 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, flex: 1 }}>
                    <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: p.subject.color }} />
                    <Text style={{ color: theme.text, fontWeight: '700', flexShrink: 1 }}>{p.subject.name}</Text>
                    {p.avoided && <Ionicons name="warning" size={15} color={theme.warning} />}
                  </View>
                  <Text style={{ color: theme.muted, fontSize: 12 }}>{formatDuration(p.minutes)} / {formatDuration(p.goal)}</Text>
                </View>
                <ProgressBar value={p.minutes} max={p.goal} color={p.avoided ? theme.warning : p.subject.color} height={7} />
                <Text style={{ color: p.avoided ? theme.warning : theme.muted, fontSize: 12, lineHeight: 17 }}>
                  {p.avoided ? T.avoided(p.subject.name, p.minutes, p.undone) : p.pct >= 100 ? T.onTrack(p.subject.name) : T.subjectLine(p.subject.name, p.minutes, p.goal, p.pct)}
                </Text>
              </View>
            ))}
          </Card>

          <Card onPress={() => navigation.navigate('Report')} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <Ionicons name="image-outline" size={26} color={theme.primary} />
            <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '900' }}>{T.reportCta}</Text><Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{T.reportCtaHint}</Text></View>
            <Ionicons name="chevron-forward" size={18} color={theme.primary} />
          </Card>

          <Segmented value={range} onChange={setRange} options={[{ value: '7', label: T.range7 }, { value: '30', label: T.range30 }]} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {([
              { label: T.stats.totalFocus, value: formatDuration(total), icon: 'time-outline' },
              { label: T.stats.blocksDone, value: String(tasksDone), icon: 'checkmark-done-outline' },
              { label: T.stats.streak, value: T.stats.days(streak), icon: 'flame-outline' },
              { label: T.stats.mood, value: averageMood === '—' ? '—' : `${averageMood}/5`, icon: 'happy-outline' },
            ] as const).map((stat) => <Card key={stat.label} style={{ width: '48%', flexGrow: 1, padding: 14 }}>
              <Ionicons name={stat.icon} size={20} color={theme.primary} />
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 9 }}>{stat.value}</Text>
              <Text style={{ color: theme.muted, fontSize: 10, fontWeight: '800', marginTop: 3 }}>{stat.label}</Text>
            </Card>)}
          </View>

          {data.settings.strictMode && rangeSessions.length > 0 && <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <Ionicons name="shield-checkmark-outline" size={24} color={interrupted ? theme.warning : theme.success} />
            <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{T.strictTitle}</Text><Text style={{ color: theme.muted, fontSize: 13, marginTop: 3 }}>{T.strictLine(interrupted, rangeSessions.length)}</Text></View>
          </Card>}

          <Card>
            <SectionTitle title={T.rhythm} action={formatDuration(total)} />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15, gap: 8, flexWrap: 'wrap' }}><Text style={{ color: theme.muted, fontSize: 12 }}>{T.goal(formatDuration(data.settings.dailyGoalMinutes))}</Text>
              <Text style={{ color: theme.primary, fontSize: 12, fontWeight: '800' }}>{T.best(formatDuration(bestValue))}</Text></View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1, gap: range === '7' ? 8 : 5, alignItems: 'flex-end', height: 185 }}>
              {days.map((date, index) => <View key={date} style={{ flex: range === '7' ? 1 : undefined, width: range === '7' ? undefined : 25, height: 180, justifyContent: 'flex-end', alignItems: 'center', gap: 7 }}>
                <Text maxFontSizeMultiplier={1.1} style={{ color: theme.muted, fontSize: 9 }}>{values[index] ? `${Math.round(values[index] / 60 * 10) / 10}h` : ''}</Text>
                <View style={{ width: '100%', maxWidth: 32, height: 135, justifyContent: 'flex-end', backgroundColor: theme.surfaceAlt, borderRadius: 8, overflow: 'hidden' }}>
                  <View style={{ height: `${Math.max(values[index] ? 4 : 0, (values[index] / max) * 100)}%`, backgroundColor: date === todayKey() ? theme.primary : `${theme.primary}99`, borderRadius: 8 }} />
                </View>
                <Text maxFontSizeMultiplier={1.1} style={{ color: date === todayKey() ? theme.primary : theme.muted, fontSize: 10, fontWeight: date === todayKey() ? '900' : '600' }}>{range === '7' ? fromDateKey(date).toLocaleDateString(undefined, { weekday: 'short' }).slice(0, 2) : fromDateKey(date).getDate()}</Text>
              </View>)}
            </ScrollView>
          </Card>

          <Card style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="trophy-outline" size={24} color={theme.primary} /></View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{T.bestDay}</Text><Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginTop: 3 }}>{bestValue ? formatShortDate(bestDay) : T.noSessions}</Text></View>
              <Badge text={formatDuration(bestValue)} />
            </View>
          </Card>

          <Card>
            <SectionTitle title={T.balance} icon="pie-chart-outline" />
            {subjectData.length ? subjectData.map((subject) => <View key={subject.id} style={{ marginBottom: 16, gap: 7 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}><View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: subject.color }} /><Text style={{ color: theme.text, fontWeight: '700' }}>{subject.name}</Text></View>
                <Text style={{ color: theme.muted, fontSize: 12 }}>{formatDuration(subject.minutes)}</Text></View>
              <ProgressBar value={subject.minutes} max={subjectData[0].minutes} color={subject.color} height={7} />
            </View>) : <Text style={{ color: theme.muted, lineHeight: 20 }}>{T.balanceEmpty}</Text>}
          </Card>

          <Card>
            <SectionTitle title={T.consistency} icon="grid-outline" action={T.stats.days(streak)} />
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, justifyContent: 'center' }}>
              {heatDays.map((date) => {
                const minutes = focusMinutesForDate(data.sessions, date);
                const opacity = minutes === 0 ? 0 : minutes < 30 ? 0.25 : minutes < 75 ? 0.5 : minutes < 120 ? 0.75 : 1;
                return <View key={date} style={{ width: 34, height: 34, borderRadius: 9, backgroundColor: minutes ? theme.primary : theme.surfaceAlt, opacity: minutes ? Math.max(0.3, opacity) : 1, alignItems: 'center', justifyContent: 'center', borderWidth: date === todayKey() ? 2 : 0, borderColor: theme.accent }}>
                  <Text maxFontSizeMultiplier={1.1} style={{ color: opacity > 0.5 ? '#FFF' : theme.text, fontSize: 10, fontWeight: '700' }}>{fromDateKey(date).getDate()}</Text></View>;
              })}
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, marginTop: 13 }}><Text style={{ color: theme.muted, fontSize: 10 }}>{T.less}</Text>{[0.15, 0.3, 0.55, 0.8, 1].map((opacity) => <View key={opacity} style={{ width: 13, height: 13, borderRadius: 4, backgroundColor: theme.primary, opacity }} />)}<Text style={{ color: theme.muted, fontSize: 10 }}>{T.more}</Text></View>
          </Card>

          <Card>
            <SectionTitle title={T.recs} icon="rocket-outline" />
            {recommendations.map((recommendation, index) => <View key={recommendation} style={{ flexDirection: 'row', gap: 10, marginBottom: 14 }}>
              <View style={{ width: 23, height: 23, borderRadius: 12, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: theme.primary, fontSize: 11, fontWeight: '900' }}>{index + 1}</Text></View>
              <Text style={{ color: theme.text, flex: 1, lineHeight: 20, fontSize: 13 }}>{recommendation}</Text></View>)}
            <Button title={T.reportCta} icon="share-social-outline" variant="secondary" onPress={() => navigation.navigate('Report')} />
          </Card>

          {distractionCounts.length > 0 && <Card>
            <SectionTitle title={T.recurring} icon="notifications-off-outline" />
            {distractionCounts.map(([label, count]) => <View key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9, gap: 8 }}>
              <Text style={{ color: theme.text, textTransform: 'capitalize', flex: 1 }}>{label}</Text><Badge text={`${count}×`} color={theme.warning} /></View>)}
          </Card>}
          <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center', lineHeight: 18 }}>{T.footer}</Text>
        </View>
      </ScrollView>
    </Screen>
  );
}
