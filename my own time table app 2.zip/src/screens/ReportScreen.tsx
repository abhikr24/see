import React, { useMemo, useRef, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { captureRef } from 'react-native-view-shot';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { buildReportCard, reportAsText } from '../utils/report';
import { formatDuration, formatShortDate } from '../utils/date';
import { Button, Header, Screen } from '../components/ui';
import { Text } from '../components/Text';
import { useDialog } from '../components/DialogHost';
import { shareImageUri, shareTextFile } from '../lib/shareFile';
import { reportText as R } from '../i18n/insights';

export default function ReportScreen() {
  const theme = useTheme();
  const navigation = useNavigation();
  const dialog = useDialog();
  const { data } = useApp();
  const report = useMemo(() => buildReportCard(data), [data]);
  const cardRef = useRef<View>(null);
  const [busy, setBusy] = useState(false);

  const shareImage = async () => {
    setBusy(true);
    try {
      const uri = await captureRef(cardRef, { format: 'png', quality: 1, result: resultKind() });
      await shareImageUri(uri, 'focusflow-week.png');
    } catch {
      await dialog.alert(R.title, R.shareError);
      await shareTextFile('focusflow-week.txt', reportAsText(report), 'text/plain');
    } finally {
      setBusy(false);
    }
  };

  const stat = (label: string, value: string, icon: keyof typeof Ionicons.glyphMap) => (
    <View style={{ flex: 1, minWidth: 130, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 18, padding: 14, gap: 6 }}>
      <Ionicons name={icon} size={18} color="#DDF3A7" />
      <Text maxFontSizeMultiplier={1.2} style={{ color: '#FFFFFF', fontSize: 24, fontWeight: '900' }}>{value}</Text>
      <Text maxFontSizeMultiplier={1.2} style={{ color: '#C4D8CD', fontSize: 11, fontWeight: '700' }}>{label}</Text>
    </View>
  );

  return (
    <Screen>
      <Header title={R.title} onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 16 }}>
        <View ref={cardRef} collapsable={false} style={{ backgroundColor: '#244B3E', borderRadius: 28, padding: 22, gap: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: '#DDF3A7', alignItems: 'center', justifyContent: 'center' }}><Ionicons name="leaf" size={22} color="#233B24" /></View>
            <View style={{ flex: 1 }}>
              <Text maxFontSizeMultiplier={1.2} style={{ color: '#FFFFFF', fontWeight: '900', fontSize: 19 }}>{R.heading}</Text>
              <Text maxFontSizeMultiplier={1.2} style={{ color: '#C4D8CD', fontSize: 12 }}>{formatShortDate(report.rangeStart)} – {formatShortDate(report.rangeEnd)}</Text>
            </View>
          </View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {stat(R.focused, formatDuration(report.minutes), 'time-outline')}
            {stat(R.blocks, String(report.blocksDone), 'checkmark-done-outline')}
            {stat(R.streak, String(report.streak), 'flame-outline')}
            {stat(R.bestDay, report.bestDay ? `${formatShortDate(report.bestDay.date)}` : R.none, 'trophy-outline')}
          </View>
          <View style={{ backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 18, padding: 14, gap: 4 }}>
            <Text maxFontSizeMultiplier={1.2} style={{ color: '#C4D8CD', fontSize: 11, fontWeight: '800' }}>{R.topSubject.toUpperCase()}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              {report.topSubject && <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: report.topSubject.color }} />}
              <Text maxFontSizeMultiplier={1.2} style={{ color: '#FFFFFF', fontWeight: '900', fontSize: 18 }}>{report.topSubject ? `${report.topSubject.name} · ${formatDuration(report.topSubject.minutes)}` : R.none}</Text>
            </View>
          </View>
          <View style={{ backgroundColor: '#DDF3A7', borderRadius: 18, padding: 16, gap: 6 }}>
            <Text maxFontSizeMultiplier={1.2} style={{ color: '#233B24', fontSize: 11, fontWeight: '900', letterSpacing: 0.8 }}>{R.recommendation.toUpperCase()}</Text>
            <Text maxFontSizeMultiplier={1.2} style={{ color: '#233B24', fontSize: 15, lineHeight: 22, fontWeight: '700' }}>{report.recommendation}</Text>
          </View>
        </View>
        <Button title={busy ? R.saving : R.shareImage} icon="image-outline" loading={busy} onPress={shareImage} />
        <Button title={R.shareText} icon="document-text-outline" variant="secondary" onPress={() => shareTextFile('focusflow-week.txt', reportAsText(report), 'text/plain')} />
        <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center' }}>{reportAsText(report).split('\n')[0]}</Text>
      </ScrollView>
    </Screen>
  );
}

function resultKind(): 'tmpfile' | 'data-uri' {
  return typeof document !== 'undefined' ? 'data-uri' : 'tmpfile';
}
