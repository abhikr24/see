import React, { useState } from 'react';
import { Linking, ScrollView, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { RootStackParamList } from '../navigation/types';
import { ThemeMode } from '../types';
import { formatDuration, formatTime } from '../utils/date';
import { Badge, Button, Card, Chip, Divider, Field, Header, Screen, SectionTitle, Segmented, SettingsRow, Stepper, ToggleRow } from '../components/ui';
import { Text } from '../components/Text';
import { useDialog } from '../components/DialogHost';
import { useNotifications } from '../components/NotificationBridge';
import { APP_VERSION } from '../lib/version';
import { settingsText as S } from '../i18n/screens';
import { common as C } from '../i18n/base';

export default function SettingsScreen() {
  const theme = useTheme();
  const dialog = useDialog();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data, engine, updateSettings, resetData } = useApp();
  const { permission, supported, ensurePermission } = useNotifications();
  const [name, setName] = useState(data.settings.name);
  const s = data.settings;

  const toggleNotification = async (key: 'notifyFocusEnd' | 'notifyBreakEnd' | 'notifyBlockStart', value: boolean) => {
    updateSettings({ [key]: value });
    if (value && supported) await ensurePermission();
  };

  const clearAll = async () => {
    const choice = await dialog.choose({
      title: S.clearConfirmTitle, message: S.clearConfirmMessage,
      options: [
        { id: 'backup', label: S.clearBackupFirst, tone: 'primary' },
        { id: 'clear', label: S.clearConfirm, tone: 'destructive' },
        { id: 'cancel', label: C.cancel },
      ],
    });
    if (choice === 'backup') navigation.navigate('Backup');
    if (choice === 'clear') resetData();
  };

  const windowStarts = [0, 300, 360, 420, 480];
  const windowEnds = [1200, 1260, 1320, 1380, 1440];

  return (
    <Screen>
      <Header title={S.title} subtitle={S.subtitle} onBack={navigation.goBack} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 16 }}>
        <Card style={{ gap: 14 }}>
          <SectionTitle title={S.profile} icon="person-outline" />
          <Field label={S.displayName} value={name} onChangeText={setName} maxLength={30} returnKeyType="done" onSubmitEditing={() => name.trim() && updateSettings({ name: name.trim() })} />
          <Button title={S.saveProfile} variant="secondary" onPress={() => (name.trim() ? updateSettings({ name: name.trim() }) : dialog.alert(S.nameRequiredTitle, S.nameRequired))} />
        </Card>

        <Card>
          <SectionTitle title={S.notifications} icon="notifications-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 19, marginBottom: 4 }}>{S.notificationsIntro}</Text>
          <ToggleRow icon="timer-outline" title={S.notifFocusEnd} subtitle={S.notifFocusEndHint} value={s.notifyFocusEnd} onChange={(v) => toggleNotification('notifyFocusEnd', v)} />
          <Divider />
          <ToggleRow icon="cafe-outline" title={S.notifBreakEnd} subtitle={S.notifBreakEndHint} value={s.notifyBreakEnd} onChange={(v) => toggleNotification('notifyBreakEnd', v)} />
          <Divider />
          <ToggleRow icon="alarm-outline" title={S.notifBlockStart} subtitle={S.notifBlockStartHint} value={s.notifyBlockStart} onChange={(v) => toggleNotification('notifyBlockStart', v)} />
          {!supported && <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, marginTop: 8 }}>{S.notifWeb}</Text>}
          {supported && permission === 'denied' && <View style={{ gap: 10, marginTop: 8 }}>
            <Text style={{ color: theme.warning, fontSize: 12, lineHeight: 18 }}>{S.notifBlocked}</Text>
            <Button title={S.notifOpenSettings} variant="secondary" onPress={() => Linking.openSettings().catch(() => undefined)} />
          </View>}
        </Card>

        <Card>
          <SectionTitle title={S.pomodoro} icon="timer-outline" />
          <Stepper label={S.focusSession} value={s.focusMinutes} min={5} max={90} suffix={C.min} onChange={(focusMinutes) => updateSettings({ focusMinutes })} />
          <Stepper label={S.shortBreak} value={s.shortBreakMinutes} min={1} max={30} step={1} suffix={C.min} onChange={(shortBreakMinutes) => updateSettings({ shortBreakMinutes })} />
          <Stepper label={S.longBreak} value={s.longBreakMinutes} min={5} max={60} suffix={C.min} onChange={(longBreakMinutes) => updateSettings({ longBreakMinutes })} />
          <Stepper label={S.longBreakAfter} value={s.longBreakEvery} min={2} max={8} step={1} suffix={S.sessions} onChange={(longBreakEvery) => updateSettings({ longBreakEvery })} />
          <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, marginTop: 8 }}>{S.pomodoroNote}</Text>
        </Card>

        <Card style={{ gap: 14 }}>
          <SectionTitle title={S.focusTools} icon="shield-checkmark-outline" />
          <ToggleRow icon="lock-closed-outline" title={S.strict} subtitle={S.strictHint} value={s.strictMode} onChange={(strictMode) => updateSettings({ strictMode })} />
        </Card>

        <Card style={{ gap: 17 }}>
          <SectionTitle title={S.targets} icon="locate-outline" />
          <View style={{ gap: 9 }}><Text style={{ color: theme.text, fontWeight: '700' }}>{S.focusGoal}</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>
            {[60, 120, 180, 240, 360].map((m) => <Chip key={m} label={formatDuration(m)} selected={s.dailyGoalMinutes === m} onPress={() => updateSettings({ dailyGoalMinutes: m })} />)}
          </View></View>
          <View style={{ gap: 9 }}><Text style={{ color: theme.text, fontWeight: '700' }}>{S.waterGoal}</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>
            {[6, 8, 10, 12].map((n) => <Chip key={n} label={S.glasses(n)} selected={s.waterGoal === n} onPress={() => updateSettings({ waterGoal: n })} />)}
          </View></View>
        </Card>

        <Card style={{ gap: 12 }}>
          <SectionTitle title={S.schedule} icon="calendar-outline" />
          <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18 }}>{S.scheduleHint}</Text>
          <Text style={{ color: theme.text, fontWeight: '700' }}>{S.windowStart}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>{windowStarts.map((m) => <Chip key={m} label={formatTime(m)} selected={s.planStartMinute === m} onPress={() => updateSettings({ planStartMinute: m })} />)}</View>
          <Text style={{ color: theme.text, fontWeight: '700' }}>{S.windowEnd}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>{windowEnds.map((m) => <Chip key={m} label={m === 1440 ? '12:00 AM' : formatTime(m)} selected={s.planEndMinute === m} onPress={() => updateSettings({ planEndMinute: m })} />)}</View>
        </Card>

        <Card style={{ gap: 16 }}>
          <SectionTitle title={S.appearance} icon="color-palette-outline" />
          <Segmented<ThemeMode> value={s.theme} onChange={(theme_) => updateSettings({ theme: theme_ })} options={[{ value: 'system', label: S.themeSystem, icon: 'phone-portrait-outline' }, { value: 'light', label: S.themeLight, icon: 'sunny-outline' }, { value: 'dark', label: S.themeDark, icon: 'moon-outline' }]} />
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}><View style={{ flexShrink: 1 }}><Text style={{ color: theme.text, fontWeight: '700' }}>{S.weekStarts}</Text><Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{S.weekStartsHint}</Text></View>
            <View style={{ flexDirection: 'row', gap: 7 }}><Chip label={S.mon} selected={s.weekStartsMonday} onPress={() => updateSettings({ weekStartsMonday: true })} /><Chip label={S.sun} selected={!s.weekStartsMonday} onPress={() => updateSettings({ weekStartsMonday: false })} /></View></View>
        </Card>

        <Card style={{ paddingVertical: 4 }}>
          <SettingsRow icon="school-outline" title={S.timetable} subtitle={S.timetableHint} onPress={() => navigation.navigate('Timetable')} />
          <Divider />
          <SettingsRow icon="library-outline" title={S.subjects} subtitle={S.subjectsHint(data.subjects.length)} onPress={() => navigation.navigate('Subjects')} />
          <Divider />
          <SettingsRow icon="ribbon-outline" title={S.exams} subtitle={S.examsHint(data.exams.length)} onPress={() => navigation.navigate('Exams')} />
          <Divider />
          <SettingsRow icon="cloud-outline" title={S.cloud} subtitle={S.cloudHint} onPress={() => navigation.navigate('Cloud')}
            right={<Badge text={!data.meta.edited ? S.cloudNew : data.meta.dirty ? S.cloudLocal : S.cloudSynced} />} />
          <Divider />
          <SettingsRow icon="download-outline" title={S.backup} subtitle={S.backupHint} onPress={() => navigation.navigate('Backup')} />
        </Card>

        <Card style={{ gap: 12 }}>
          <SectionTitle title={S.storage} icon="phone-portrait-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 20 }}>{S.storageText} {engine === 'sqlite' ? S.engineSqlite : S.engineLocal}</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6 }}><Badge text={S.tasks(data.tasks.length)} /><Badge text={S.sessionsCount(data.sessions.length)} /><Badge text={S.reviews(data.reviews.length)} /></View>
        </Card>

        <Card style={{ paddingVertical: 4 }}>
          <SettingsRow icon="trash-outline" title={S.clearTitle} subtitle={S.clearHint} onPress={clearAll} />
        </Card>
        <View style={{ alignItems: 'center', gap: 5, paddingVertical: 8 }}><Ionicons name="leaf" size={23} color={theme.primary} /><Text style={{ color: theme.text, fontWeight: '900' }}>{C.appName}</Text><Text style={{ color: theme.muted, fontSize: 12, textAlign: 'center' }}>{S.version(APP_VERSION)}</Text></View>
      </ScrollView>
    </Screen>
  );
}
