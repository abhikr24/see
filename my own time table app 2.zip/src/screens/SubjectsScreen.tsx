import React, { useState } from 'react';
import { FlatList, Pressable, ScrollView, View } from 'react-native';
import { Text } from '../components/Text';
import { useDialog } from '../components/DialogHost';
import { IconName } from '../components/icons';
import { subjectsText as T } from '../i18n/screens';
import { common as C } from '../i18n/base';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../store/AppContext';
import { SUBJECT_COLORS, useTheme } from '../theme';
import { Subject } from '../types';
import { dateFromIso, formatDuration, makeId, todayKey, weekDates } from '../utils/date';
import { Badge, Button, Card, Chip, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, SheetModal } from '../components/ui';

const ICONS = ['book', 'calculator', 'planet', 'code-slash', 'flask', 'language', 'brush', 'musical-notes', 'fitness'];

export default function SubjectsScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const dialog = useDialog();
  const { data, saveSubject, deleteSubject } = useApp();
  const [editing, setEditing] = useState<Subject | null>(null);
  const [modal, setModal] = useState(false);
  const [name, setName] = useState('');
  const [color, setColor] = useState(SUBJECT_COLORS[0]);
  const [icon, setIcon] = useState('book');
  const [goal, setGoal] = useState(180);
  const [error, setError] = useState('');
  const week = weekDates(todayKey(), data.settings.weekStartsMonday);

  const open = (subject?: Subject) => {
    setEditing(subject || null); setName(subject?.name || ''); setColor(subject?.color || SUBJECT_COLORS[data.subjects.length % SUBJECT_COLORS.length]);
    setIcon(subject?.icon || 'book'); setGoal(subject?.weeklyGoalMinutes || 180); setError(''); setModal(true);
  };
  const save = () => {
    if (!name.trim()) { setError(T.errName); return; }
    saveSubject({ id: editing?.id || makeId('subject'), name: name.trim(), color, icon,
      weeklyGoalMinutes: goal, archived: editing?.archived || false, createdAt: editing?.createdAt || new Date().toISOString() });
    setModal(false);
  };
  const remove = async (subject: Subject) => {
    const ok = await dialog.confirm({ title: T.deleteTitle(subject.name), message: T.deleteMessage, confirmLabel: C.delete, cancelLabel: C.cancel, destructive: true });
    if (ok) deleteSubject(subject.id);
  };

  return (
    <Screen>
      <Header title={T.title} subtitle={T.subtitle} onBack={navigation.goBack} right={<IconButton icon="add" label={T.add} filled onPress={() => open()} />} />
      <FlatList data={[...data.subjects].sort((a, b) => Number(a.archived) - Number(b.archived))} keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 35, gap: 11 }}
        ListHeaderComponent={<Card style={{ marginBottom: 10, backgroundColor: theme.primarySoft, borderColor: 'transparent', flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Ionicons name="library-outline" size={26} color={theme.primary} /><View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{T.active(data.subjects.filter((item) => !item.archived).length)}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{T.weeklyTarget}</Text></View><Badge text={formatDuration(data.subjects.filter((s) => !s.archived).reduce((sum, s) => sum + s.weeklyGoalMinutes, 0))} />
        </Card>}
        renderItem={({ item }) => {
          const minutes = data.sessions.filter((session) => session.subjectId === item.id && week.includes(dateFromIso(session.startedAt))).reduce((sum, session) => sum + session.actualMinutes, 0);
          return <Card onPress={() => open(item)} style={{ opacity: item.archived ? 0.6 : 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ width: 48, height: 48, borderRadius: 15, backgroundColor: item.color, alignItems: 'center', justifyContent: 'center' }}><Ionicons name={item.icon as IconName} size={23} color="#FFF" /></View>
              <View style={{ flex: 1 }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}><Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{item.name}</Text>{item.archived && <Badge text={T.archived} />}</View>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{T.thisWeek(formatDuration(minutes), formatDuration(item.weeklyGoalMinutes))}</Text></View>
              <IconButton icon="trash-outline" label={`Delete ${item.name}`} color={theme.danger} onPress={() => remove(item)} />
            </View>
            <View style={{ marginTop: 14 }}><ProgressBar value={minutes} max={item.weeklyGoalMinutes} color={item.color} /></View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}><Text style={{ color: theme.muted, fontSize: 11 }}>{T.pctGoal(Math.round((minutes / Math.max(1, item.weeklyGoalMinutes)) * 100))}</Text>
              <Text style={{ color: theme.primary, fontSize: 11, fontWeight: '800' }}>{T.tapEdit}</Text></View>
          </Card>;
        }}
        ListEmptyComponent={<EmptyState icon="library-outline" title={T.emptyTitle} message={T.emptyMessage} action={T.emptyAction} onAction={() => open()} />}
      />
      <SheetModal visible={modal} onClose={() => setModal(false)} title={editing ? T.editSubject : T.newSubject}>
        <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }}>
          <Field label={T.name} value={name} onChangeText={(text) => { setName(text); setError(''); }} placeholder={T.namePh} autoFocus maxLength={50} />
          <View><SectionTitle title={T.color} /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>{SUBJECT_COLORS.map((item) => <Pressable key={item} onPress={() => setColor(item)}
            style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: item, alignItems: 'center', justifyContent: 'center', borderWidth: color === item ? 3 : 0, borderColor: theme.text }}>
            {color === item && <Ionicons name="checkmark" color="#FFF" size={20} />}</Pressable>)}</View></View>
          <View><SectionTitle title={T.icon} /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>{ICONS.map((item) => <Pressable key={item} onPress={() => setIcon(item)}
            style={{ width: 46, height: 46, borderRadius: 14, backgroundColor: icon === item ? color : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={item as IconName} size={22} color={icon === item ? '#FFF' : theme.muted} /></Pressable>)}</View></View>
          <View><SectionTitle title={T.goal} /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{[60, 120, 180, 240, 300, 420, 600].map((minutes) => <Chip key={minutes} label={formatDuration(minutes)} selected={goal === minutes} onPress={() => setGoal(minutes)} />)}</View></View>
          {editing && <Button title={editing.archived ? T.unarchive : T.archive} variant="ghost" icon="archive-outline"
            onPress={() => { saveSubject({ ...editing, archived: !editing.archived }); setModal(false); }} />}
          {!!error && <Text style={{ color: theme.danger }}>{error}</Text>}
          <Button title={T.save} icon="checkmark" onPress={save} />
        </ScrollView>
      </SheetModal>
    </Screen>
  );
}
