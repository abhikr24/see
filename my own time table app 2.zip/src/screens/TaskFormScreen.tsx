import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { RootStackParamList } from '../navigation/types';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { BlockKind, Priority, Recurrence, StudyTask } from '../types';
import { addDays, clamp, formatLongDate, formatShortDate, formatTime, isValidDateKey, makeId, todayKey } from '../utils/date';
import { occursOn } from '../utils/recurrence';
import { Button, Card, Chip, Divider, Field, Header, Screen, SectionTitle, Stepper } from '../components/ui';
import { Text } from '../components/Text';
import { DatePickerSheet, PickerField, TimePickerSheet } from '../components/Pickers';
import { useDialog } from '../components/DialogHost';
import { taskForm as TF } from '../i18n/planner';
import { common as C, weekdayNames } from '../i18n/base';

type Props = NativeStackScreenProps<RootStackParamList, 'TaskForm'>;

export default function TaskFormScreen({ route, navigation }: Props) {
  const theme = useTheme();
  const dialog = useDialog();
  const { data, saveTask, saveTasks, deleteTask, skipOccurrence, restoreOccurrence } = useApp();
  const params = route.params;
  const existing = data.tasks.find((task) => task.id === params?.taskId);
  const occDate = params?.date || existing?.date || todayKey();
  const [title, setTitle] = useState(existing?.title || params?.title || '');
  const [notes, setNotes] = useState(existing?.notes || '');
  const [date, setDate] = useState(existing?.date || occDate);
  const [subjectId, setSubjectId] = useState(existing ? existing.subjectId : data.subjects.find((s) => !s.archived)?.id);
  const [startMinute, setStartMinute] = useState<number | undefined>(existing ? existing.startMinute : params?.startMinute);
  const [duration, setDuration] = useState(existing?.durationMinutes || params?.duration || data.settings.focusMinutes);
  const [priority, setPriority] = useState<Priority>(existing?.priority || 'medium');
  const [kind, setKind] = useState<BlockKind>(existing?.kind || params?.kind || 'study');
  const [recurrence, setRecurrence] = useState<Recurrence>(existing?.recurrence || (params?.kind === 'class' ? 'custom' : 'none'));
  const [recurDays, setRecurDays] = useState<number[]>(existing?.recurDays?.length ? existing.recurDays : params?.kind === 'class' ? [new Date(`${occDate}T12:00:00`).getDay()] : []);
  const [recurUntil, setRecurUntil] = useState<string | undefined>(existing?.recurUntil);
  const [topThree, setTopThree] = useState(existing?.topThreeDates.includes(occDate) || false);
  const [error, setError] = useState('');
  const [picker, setPicker] = useState<null | 'time' | 'date' | 'until'>(null);
  const activeSubjects = useMemo(() => data.subjects.filter((s) => !s.archived), [data.subjects]);
  const topThreeCount = data.tasks.filter((t) => t.id !== existing?.id && t.topThreeDates.includes(occDate)).length;

  const overlaps = useMemo(() => {
    if (startMinute === undefined) return false;
    return data.tasks.some((t) => t.id !== existing?.id && t.startMinute !== undefined && occursOn(t, date)
      && startMinute < t.startMinute + t.durationMinutes && t.startMinute < startMinute + duration);
  }, [data.tasks, existing?.id, date, startMinute, duration]);

  const buildTask = (): StudyTask | null => {
    if (!title.trim()) { setError(TF.errorTitle); return null; }
    if (!isValidDateKey(date)) { setError(TF.errorDate); return null; }
    if (recurrence === 'custom' && recurDays.length === 0) { setError(TF.repeatNoDays); return null; }
    if (recurrence !== 'none' && recurUntil && recurUntil < date) { setError(TF.repeatEndBefore); return null; }
    const now = new Date().toISOString();
    return {
      id: existing?.id || makeId('task'), title: title.trim(), notes: notes.trim(), date, subjectId, startMinute,
      durationMinutes: duration, estimatedPomodoros: Math.max(1, Math.ceil(duration / data.settings.focusMinutes)),
      priority, recurrence, recurDays: recurrence === 'custom' ? [...recurDays].sort((a, b) => a - b) : [],
      recurUntil: recurrence === 'none' ? undefined : recurUntil, skippedDates: existing?.skippedDates || [],
      completedDates: existing?.completedDates || [],
      topThreeDates: topThree ? [...(existing?.topThreeDates || []).filter((d) => d !== occDate), occDate] : (existing?.topThreeDates || []).filter((d) => d !== occDate),
      kind, examId: existing?.examId, createdAt: existing?.createdAt || now, updatedAt: now,
    };
  };

  const save = () => {
    const task = buildTask();
    if (!task) return;
    saveTask(task);
    navigation.goBack();
  };

  const confirmDelete = async () => {
    if (!existing) return;
    if (existing.recurrence !== 'none') {
      const choice = await dialog.choose({
        title: TF.deleteSeriesTitle, message: TF.deleteSeriesMessage(formatShortDate(occDate)),
        options: [
          { id: 'one', label: TF.deleteThisOnly(formatShortDate(occDate)) },
          { id: 'all', label: TF.deleteWholeSeries, tone: 'destructive' },
          { id: 'cancel', label: C.cancel },
        ],
      });
      if (choice === 'one') { skipOccurrence(existing.id, occDate); navigation.goBack(); }
      if (choice === 'all') { deleteTask(existing.id); navigation.goBack(); }
      return;
    }
    const ok = await dialog.confirm({ title: TF.deleteTitle, message: TF.deleteMessage, confirmLabel: C.delete, cancelLabel: C.cancel, destructive: true });
    if (ok) { deleteTask(existing.id); navigation.goBack(); }
  };

  const duplicate = async () => {
    if (!existing) return;
    const choice = await dialog.choose({
      title: TF.duplicateTitle,
      options: [
        { id: 'after', label: TF.duplicateAfter }, { id: 'tomorrow', label: TF.duplicateTomorrow },
        { id: 'week', label: TF.duplicateNextWeek }, { id: 'cancel', label: C.cancel },
      ],
    });
    if (!choice || choice === 'cancel') return;
    const now = new Date().toISOString();
    const base: StudyTask = {
      ...existing, id: makeId('task'), recurrence: 'none', recurDays: [], recurUntil: undefined, skippedDates: [], completedDates: [],
      topThreeDates: [], date: occDate, createdAt: now, updatedAt: now,
    };
    if (choice === 'after') {
      const start = existing.startMinute === undefined ? undefined : Math.min(1439, existing.startMinute + existing.durationMinutes);
      saveTasks([{ ...base, startMinute: start }]);
    } else saveTasks([{ ...base, date: addDays(occDate, choice === 'tomorrow' ? 1 : 7) }]);
    await dialog.alert(TF.duplicateTitle, TF.duplicated);
  };

  const skipThis = async () => {
    if (!existing) return;
    skipOccurrence(existing.id, occDate);
    await dialog.alert(TF.skipThis(formatShortDate(occDate)), TF.skipDone(formatShortDate(occDate)));
    navigation.goBack();
  };

  const recurChips: [Recurrence, string][] = [['none', TF.never], ['daily', TF.daily], ['weekdays', TF.weekdays], ['weekly', TF.weekly], ['custom', TF.custom]];
  const endMinute = startMinute === undefined ? undefined : startMinute + duration;
  const isSkippable = existing && existing.recurrence !== 'none' && occursOn(existing, occDate);

  return (
    <Screen>
      <Header title={existing ? TF.titleEdit : kind === 'class' ? TF.titleNewClass : TF.titleNew} subtitle={TF.subtitle} onBack={navigation.goBack} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 48, gap: 18 }}>
        <Field label={TF.whatLabel} value={title} onChangeText={(text) => { setTitle(text); setError(''); }}
          placeholder={TF.whatPlaceholder} autoFocus={!existing && !params?.startMinute} returnKeyType="next" maxLength={100} />

        <Card style={{ gap: 14 }}>
          <SectionTitle title={TF.dateTime} icon="calendar-outline" />
          <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexGrow: 1, flexBasis: 150 }}>
              <PickerField label={recurrence === 'none' ? TF.dateLabel.toUpperCase() : TF.repeatStart.toUpperCase()} value={formatLongDate(date)} icon="calendar" onPress={() => setPicker('date')} />
            </View>
            <View style={{ flexGrow: 1, flexBasis: 150 }}>
              <PickerField label={TF.startLabel} value={startMinute === undefined ? C.anytime : formatTime(startMinute)} icon="time"
                onPress={() => setPicker('time')} onClear={startMinute === undefined ? undefined : () => setStartMinute(undefined)} clearLabel={TF.makeAnytime} />
            </View>
          </View>
          {endMinute !== undefined && <Text style={{ color: theme.muted, fontSize: 12 }}>{TF.endsAt(formatTime(endMinute))}{endMinute > 1440 ? ' (next day)' : ''}</Text>}
          {overlaps && <View style={{ flexDirection: 'row', gap: 7, alignItems: 'center' }}><Ionicons name="alert-circle-outline" size={16} color={theme.warning} /><Text style={{ color: theme.warning, fontSize: 12, flex: 1 }}>{TF.overlapWarning}</Text></View>}
        </Card>

        <View>
          <SectionTitle title={TF.kind} />
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            {([['study', TF.kindStudy, 'book-outline'], ['class', TF.kindClass, 'school-outline'], ['revision', TF.kindRevision, 'refresh-outline']] as const).map(([value, label, icon]) =>
              <Chip key={value} label={label} icon={icon} selected={kind === value} onPress={() => setKind(value)} />)}
          </View>
        </View>

        <View>
          <SectionTitle title={TF.subject} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {activeSubjects.map((subject) => <Chip key={subject.id} label={subject.name} selected={subjectId === subject.id} color={subject.color} onPress={() => setSubjectId(subject.id)} />)}
            <Chip label={TF.noSubject} selected={!subjectId} onPress={() => setSubjectId(undefined)} />
          </ScrollView>
        </View>

        <Card>
          <SectionTitle title={TF.duration} icon="hourglass-outline" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 6 }}>
            {[15, 25, 30, 45, 50, 60, 90, 120].map((m) => <Chip key={m} label={C.minutesShort(m)} selected={duration === m} onPress={() => setDuration(m)} />)}
          </View>
          <Stepper label={TF.durationCustom} value={duration} min={5} max={720} step={5} suffix={C.min} onChange={(v) => setDuration(clamp(v, 5, 720))} />
        </Card>

        <View>
          <SectionTitle title={TF.priority} />
          <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
            {([['high', TF.high], ['medium', TF.medium], ['low', TF.low]] as [Priority, string][]).map(([value, label]) =>
              <Chip key={value} label={label} icon="flag-outline" selected={priority === value} onPress={() => setPriority(value)} />)}
          </View>
        </View>

        <Card style={{ gap: 12 }}>
          <SectionTitle title={TF.repeats} icon="repeat" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {recurChips.map(([value, label]) => <Chip key={value} label={label} icon={value === 'none' ? undefined : 'repeat'} selected={recurrence === value} onPress={() => { setRecurrence(value); setError(''); }} />)}
          </View>
          {recurrence === 'custom' && <View style={{ gap: 8 }}>
            <Text style={{ color: theme.muted, fontSize: 12, fontWeight: '700' }}>{TF.repeatDays}</Text>
            <View style={{ flexDirection: 'row', gap: 6, flexWrap: 'wrap' }}>
              {[1, 2, 3, 4, 5, 6, 0].map((day) => {
                const on = recurDays.includes(day);
                return <Pressable key={day} accessibilityRole="button" accessibilityState={{ selected: on }} onPress={() => { setRecurDays(on ? recurDays.filter((d) => d !== day) : [...recurDays, day]); setError(''); }}
                  style={{ minWidth: 46, minHeight: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? theme.primary : theme.surfaceAlt }}>
                  <Text style={{ color: on ? (theme.dark ? '#102019' : '#FFF') : theme.text, fontWeight: '800', fontSize: 13 }}>{weekdayNames[day]}</Text></Pressable>;
              })}
            </View>
          </View>}
          {recurrence !== 'none' && <View style={{ flexDirection: 'row', gap: 10, flexWrap: 'wrap' }}>
            <View style={{ flexGrow: 1, flexBasis: 150 }}>
              <PickerField label={TF.repeatEnd.toUpperCase()} value={recurUntil ? formatLongDate(recurUntil) : TF.repeatEndNone} icon="flag" onPress={() => setPicker('until')}
                onClear={recurUntil ? () => setRecurUntil(undefined) : undefined} clearLabel={TF.repeatEndNone} />
            </View>
          </View>}
        </Card>

        {existing && existing.recurrence !== 'none' && <Card style={{ gap: 10 }}>
          <SectionTitle title={TF.skipped} icon="eye-off-outline" />
          <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18 }}>{TF.skippedNote}</Text>
          {isSkippable && <Button title={TF.skipThis(formatShortDate(occDate))} icon="remove-circle-outline" variant="secondary" onPress={skipThis} />}
          {existing.skippedDates.length > 0 && <>
            <Divider />
            {existing.skippedDates.map((d) => <View key={d} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
              <Text style={{ color: theme.text, fontWeight: '700', flex: 1 }}>{formatLongDate(d)}</Text>
              <Button title={TF.restoreDate} variant="ghost" onPress={() => restoreOccurrence(existing.id, d)} style={{ minHeight: 40 }} />
            </View>)}
          </>}
        </Card>}

        <Field label={TF.notes} value={notes} onChangeText={setNotes} multiline placeholder={TF.notesPlaceholder} maxLength={1000} />
        <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: topThree }} onPress={() => {
          if (!topThree && topThreeCount >= 3) { setError(TF.topThreeFull); return; }
          setError(''); setTopThree(!topThree);
        }} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 26, height: 26, borderRadius: 9, backgroundColor: topThree ? theme.primary : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
            {topThree && <Ionicons name="checkmark" color={theme.dark ? '#102019' : '#FFF'} size={18} />}</View>
          <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{TF.topThree}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{TF.topThreeHint}</Text></View>
        </Pressable>
        {!!error && <Text accessibilityRole="alert" style={{ color: theme.danger, fontSize: 13, fontWeight: '700' }}>{error}</Text>}
        <Button title={existing ? TF.save : TF.add} icon="checkmark" onPress={save} />
        {existing && <Button title={TF.duplicate} icon="copy-outline" variant="secondary" onPress={duplicate} />}
        {existing && <Button title={TF.delete} icon="trash-outline" variant="danger" onPress={confirmDelete} />}
      </ScrollView>

      <TimePickerSheet visible={picker === 'time'} value={startMinute ?? (existing?.startMinute ?? 9 * 60)} onClose={() => setPicker(null)} onPick={setStartMinute} />
      <DatePickerSheet visible={picker === 'date'} value={date} monday={data.settings.weekStartsMonday} onClose={() => setPicker(null)} onPick={setDate} />
      <DatePickerSheet visible={picker === 'until'} value={recurUntil ?? addDays(date, 90)} monday={data.settings.weekStartsMonday} onClose={() => setPicker(null)} onPick={(d) => setRecurUntil(d)} />
    </Screen>
  );
}
