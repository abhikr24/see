import React from 'react';
import { FlatList, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { RootStackParamList } from '../navigation/types';
import { formatLongDate, formatShortDate, formatTime, todayKey } from '../utils/date';
import { recurrenceSummary, upcomingOccurrences } from '../utils/recurrence';
import { Badge, Button, Card, EmptyState, Header, IconButton, Screen } from '../components/ui';
import { Text } from '../components/Text';
import { timetable as T, taskForm as TF } from '../i18n/planner';
import { weekdayNames } from '../i18n/base';

export default function TimetableScreen() {
  const theme = useTheme();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data, skipOccurrence } = useApp();
  const series = data.tasks.filter((t) => t.recurrence !== 'none')
    .sort((a, b) => (a.kind === 'class' ? 0 : 1) - (b.kind === 'class' ? 0 : 1) || (a.startMinute ?? 0) - (b.startMinute ?? 0));
  const today = todayKey();

  return (
    <Screen>
      <Header title={T.title} subtitle={T.subtitle} onBack={navigation.goBack}
        right={<IconButton icon="add" label={T.add} filled onPress={() => navigation.navigate('TaskForm', { date: today, kind: 'class' })} />} />
      <FlatList data={series} keyExtractor={(item) => item.id} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 36, gap: 12 }}
        renderItem={({ item }) => {
          const subject = data.subjects.find((s) => s.id === item.subjectId);
          const upcoming = upcomingOccurrences(item, today, 3);
          return (
            <Card style={{ gap: 12, borderLeftWidth: 5, borderLeftColor: subject?.color || theme.primary }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{item.title}</Text>
                  <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>
                    {recurrenceSummary(item, weekdayNames)}{item.startMinute !== undefined ? ` · ${formatTime(item.startMinute)}–${formatTime(item.startMinute + item.durationMinutes)}` : ''}
                  </Text>
                </View>
                <Badge text={item.kind === 'class' ? TF.kindClass.toUpperCase() : item.kind === 'revision' ? TF.kindRevision.toUpperCase() : TF.kindStudy.toUpperCase()} color={subject?.color} />
              </View>
              <Text style={{ color: theme.muted, fontSize: 12 }}>{T.term(formatShortDate(item.date), item.recurUntil ? formatShortDate(item.recurUntil) : T.noEnd)}{item.skippedDates.length ? ` · ${T.skippedCount(item.skippedDates.length)}` : ''}</Text>
              <Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{T.upcoming.toUpperCase()}</Text>
              {upcoming.map((date) => (
                <View key={date} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                  <Text style={{ color: theme.text, fontWeight: '700', flex: 1 }}>{formatLongDate(date)}</Text>
                  <Button title={T.skipNext(formatShortDate(date))} variant="ghost" onPress={() => skipOccurrence(item.id, date)} style={{ minHeight: 40, paddingHorizontal: 12 }} />
                </View>
              ))}
              {upcoming.length === 0 && <Text style={{ color: theme.muted, fontSize: 13 }}>—</Text>}
              <Button title={T.manage} icon="create-outline" variant="secondary" onPress={() => navigation.navigate('TaskForm', { taskId: item.id, date: upcoming[0] ?? item.date })} />
            </Card>
          );
        }}
        ListEmptyComponent={<EmptyState icon="school-outline" title={T.empty} message={T.emptyMessage} action={T.add} onAction={() => navigation.navigate('TaskForm', { date: today, kind: 'class' })} />}
      />
    </Screen>
  );
}
