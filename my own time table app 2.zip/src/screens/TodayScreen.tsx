import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { RootStackParamList } from '../navigation/types';
import { DailyReview } from '../types';
import { daysUntil, formatDuration, formatShortDate, formatTime, nowMinutes, todayKey } from '../utils/date';
import { completionStreak, focusMinutesForDate, isTaskComplete, reviewForDate, sessionsForDate, tasksForDate } from '../utils/selectors';
import { Badge, Button, Card, Header, IconButton, Screen, SectionTitle } from '../components/ui';
import { Text } from '../components/Text';
import WeekStrip from '../components/WeekStrip';
import TaskItem from '../components/TaskItem';
import QuickAddBar from '../components/QuickAddBar';
import { useFocusLauncher } from '../components/FocusLauncher';
import { today as T } from '../i18n/screens';

export default function TodayScreen() {
  const theme = useTheme();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList & { Focus: undefined; Review: undefined }>>();
  const launch = useFocusLauncher();
  const { data, timer, toggleTask, saveReview } = useApp();
  const today = todayKey();
  const [selectedDate, setSelectedDate] = useState(today);
  const [refreshing, setRefreshing] = useState(false);
  const tasks = useMemo(() => tasksForDate(data.tasks, selectedDate), [data.tasks, selectedDate]);
  const topThree = tasks.filter((task) => task.topThreeDates.includes(selectedDate)).slice(0, 3);
  const completed = tasks.filter((task) => isTaskComplete(task, selectedDate)).length;
  const minutes = focusMinutesForDate(data.sessions, selectedDate);
  const goal = data.settings.dailyGoalMinutes;
  const nextTask = tasks.find((task) => !isTaskComplete(task, selectedDate) && task.startMinute !== undefined && task.startMinute + task.durationMinutes >= (selectedDate === today ? nowMinutes() : 0));
  const review = reviewForDate(data.reviews, selectedDate);
  const nextExam = [...data.exams].filter((exam) => exam.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0];
  const streak = completionStreak(data);
  const parked = sessionsForDate(data.sessions, selectedDate).reduce((sum, s) => sum + s.distractions.length, 0) + (selectedDate === today ? timer.distractions.length : 0);
  const isFresh = data.tasks.length === 0 && data.sessions.length === 0;

  const openTask = (taskId?: string) => navigation.navigate('TaskForm', { taskId, date: selectedDate });
  const updateWater = (amount: number) => {
    const base: DailyReview = review || {
      date: selectedDate, worked: '', fix: '', gratitude: '', quickNotes: '', distractionNotes: '', convertedDistractions: [],
      mood: 0, energy: 0, water: 0, sleepHours: 0, steps: 0, productivity: 0, updatedAt: new Date().toISOString(),
    };
    saveReview({ ...base, water: Math.max(0, Math.min(data.settings.waterGoal, base.water + amount)) });
  };

  return (
    <Screen>
      <FlatList
        data={topThree}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} tintColor={theme.primary} onRefresh={() => { setRefreshing(true); setTimeout(() => { setSelectedDate((d) => d); setRefreshing(false); }, 350); }} />}
        contentContainerStyle={{ paddingBottom: 32 }}
        ListHeaderComponent={<>
          <Header eyebrow={formatShortDate(selectedDate)} title={T.title(T.greeting(new Date().getHours()), data.settings.name)} subtitle={T.subtitle}
            right={<IconButton icon="settings-outline" label={T.settings} filled onPress={() => navigation.navigate('Settings')} />} />
          <WeekStrip selected={selectedDate} monday={data.settings.weekStartsMonday} onSelect={setSelectedDate} />
          <View style={{ paddingHorizontal: 20, gap: 20 }}>
            {isFresh && <Card style={{ gap: 12, backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <View style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="sparkles" size={24} color={theme.primary} /></View>
                <Text style={{ color: theme.text, fontWeight: '900', fontSize: 18, flex: 1 }}>{T.welcomeTitle}</Text>
              </View>
              <Text style={{ color: theme.muted, lineHeight: 21, fontSize: 14 }}>{T.welcomeMessage}</Text>
              <Button title={T.welcomeAdd} icon="add-circle" onPress={() => navigation.navigate('TaskForm', { date: selectedDate })} />
              <QuickAddBar />
            </Card>}

            <Card style={{ backgroundColor: theme.dark ? '#263D31' : '#244B3E', borderColor: 'transparent', padding: 20 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10, flexWrap: 'wrap' }}>
                <View style={{ flexShrink: 1 }}>
                  <Text style={{ color: '#C4D8CD', fontSize: 12, fontWeight: '800', letterSpacing: 1 }}>{T.dailyFocus}</Text>
                  <Text style={{ color: '#FFFFFF', fontSize: 34, fontWeight: '900', letterSpacing: -1, marginTop: 8 }}>{formatDuration(minutes)}</Text>
                  <Text style={{ color: '#C4D8CD', fontSize: 13, marginTop: 2 }}>{T.ofGoal(formatDuration(goal))}</Text>
                </View>
                <View style={{ backgroundColor: theme.accent, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 7, flexDirection: 'row', gap: 5, alignItems: 'center' }}>
                  <Ionicons name="flame" size={15} color={theme.accentText} /><Text style={{ color: theme.accentText, fontWeight: '900', fontSize: 12 }}>{T.streak(streak)}</Text>
                </View>
              </View>
              <View style={{ height: 9, backgroundColor: '#476A5E', borderRadius: 8, marginVertical: 18, overflow: 'hidden' }}>
                <View style={{ height: 9, width: `${Math.min(100, (minutes / Math.max(1, goal)) * 100)}%`, backgroundColor: theme.accent, borderRadius: 8 }} />
              </View>
              <Pressable accessibilityRole="button" onPress={() => navigation.navigate('Focus')} style={({ pressed }) => ({ backgroundColor: theme.accent, borderRadius: 14, minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, opacity: pressed ? 0.8 : 1 })}>
                <Ionicons name="play" size={18} color={theme.accentText} /><Text style={{ color: theme.accentText, fontWeight: '900' }}>{T.startSession}</Text>
              </Pressable>
            </Card>

            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Card style={{ flex: 1, padding: 14 }}>
                <Ionicons name="checkmark-done" size={20} color={theme.primary} />
                <Text style={{ color: theme.text, fontWeight: '900', fontSize: 21, marginTop: 9 }}>{completed}/{tasks.length}</Text>
                <Text style={{ color: theme.muted, fontSize: 12 }}>{T.blocksDone}</Text>
              </Card>
              <Card style={{ flex: 1, padding: 14 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Ionicons name="water" size={20} color="#4D91A8" />
                  <View style={{ flexDirection: 'row' }}>
                    <IconButton icon="remove" size={14} label={T.removeWater} onPress={() => updateWater(-1)} />
                    <IconButton icon="add" size={14} label={T.addWater} onPress={() => updateWater(1)} />
                  </View>
                </View>
                <Text style={{ color: theme.text, fontWeight: '900', fontSize: 21, marginTop: 2 }}>{review?.water || 0}/{data.settings.waterGoal}</Text>
                <Text style={{ color: theme.muted, fontSize: 12 }}>{T.water}</Text>
              </Card>
            </View>

            {nextTask && <Card onPress={() => openTask(nextTask.id)} style={{ padding: 15, borderLeftWidth: 4, borderLeftColor: data.subjects.find((s) => s.id === nextTask.subjectId)?.color || theme.primary }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="time-outline" size={22} color={theme.primary} /></View>
                <View style={{ flex: 1 }}><Text style={{ color: theme.primary, fontSize: 11, fontWeight: '900', letterSpacing: 0.7 }}>{T.upNext(formatTime(nextTask.startMinute as number))}</Text>
                  <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800', marginTop: 4 }}>{nextTask.title}</Text></View>
                <Ionicons name="chevron-forward" color={theme.muted} size={18} />
              </View>
            </Card>}

            <SectionTitle title={T.topThree} icon="star" action={T.add} onAction={() => openTask()} />
          </View>
        </>}
        renderItem={({ item, index }) => <View style={{ marginHorizontal: 20, marginBottom: 8 }}>
          <Card style={{ paddingVertical: 3, paddingHorizontal: 14 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: theme.faint, fontSize: 12, fontWeight: '900', width: 22 }}>0{index + 1}</Text>
              <View style={{ flex: 1 }}><TaskItem task={item} date={selectedDate} subject={data.subjects.find((s) => s.id === item.subjectId)}
                onToggle={() => toggleTask(item.id, selectedDate)} onPress={() => openTask(item.id)} onFocus={() => { launch(item.id, item.subjectId); }} compact /></View>
            </View>
          </Card>
        </View>}
        ListEmptyComponent={<View style={{ marginHorizontal: 20 }}><Card style={{ alignItems: 'center', paddingVertical: 24 }}>
          <Ionicons name="star-outline" size={28} color={theme.primary} />
          <Text style={{ color: theme.text, fontWeight: '800', marginTop: 10 }}>{T.topThreeEmptyTitle}</Text>
          <Text style={{ color: theme.muted, textAlign: 'center', fontSize: 13, marginTop: 5, lineHeight: 19 }}>{T.topThreeEmptyMessage}</Text>
          <Button title={T.topThreeEmptyAction} variant="secondary" onPress={() => openTask()} style={{ marginTop: 14 }} />
        </Card></View>}
        ListFooterComponent={<View style={{ paddingHorizontal: 20, paddingTop: 20, gap: 18 }}>
          {nextExam && <Card onPress={() => navigation.navigate('Exams')} style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 13 }}>
              <View style={{ minWidth: 50, minHeight: 50, borderRadius: 15, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 }}>
                <Text style={{ color: theme.primary, fontSize: 20, fontWeight: '900' }}>{Math.max(0, daysUntil(nextExam.date))}</Text>
              </View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>{T.examDays}</Text>
                <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800', marginTop: 3 }}>{nextExam.title}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>{T.examMeta(formatShortDate(nextExam.date), nextExam.time)}</Text></View>
              <Ionicons name="chevron-forward" size={18} color={theme.primary} />
            </View>
          </Card>}
          <Card onPress={() => navigation.navigate('Review' as never)} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Ionicons name="moon-outline" size={24} color={theme.primary} />
            <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{T.reviewTitle}</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{T.reviewSubtitle}</Text></View>
            <Badge text={parked > 0 ? T.reviewParked(parked) : review ? T.reviewSaved : T.reviewTwoMin} />
          </Card>
          <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center', fontStyle: 'italic', paddingVertical: 6 }}>{T.quote}</Text>
        </View>}
      />
    </Screen>
  );
}
