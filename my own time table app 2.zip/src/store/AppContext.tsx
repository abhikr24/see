import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { getSupabase } from '../lib/supabase';
import { createStorage } from '../lib/storage';
import { StorageEngine } from '../lib/storageTypes';
import { countData, DataCounts, emptyData, hasAnyContent, normalizeData } from '../lib/schema';
import { isSafeForAuto, planSync, SyncDirection, SyncLocalInfo, SyncPlan, SyncRemoteInfo } from '../lib/syncPlan';
import * as machine from '../lib/timerMachine';
import {
  AppData, AppSettings, DailyReview, Exam, FocusSession, StudyTask, Subject, SyncStrategy, TimerState,
} from '../types';
import { makeId, todayKey } from '../utils/date';
import { autoPlace } from '../utils/placement';
import { isTaskComplete, occursOn } from '../utils/selectors';
import { restoreOccurrence as restoreOcc, skipOccurrence as skipOcc } from '../utils/recurrence';
import { nowMinutes } from '../utils/date';
import { sync as syncText } from '../i18n/sync';

export interface CloudPlan extends SyncPlan {
  local: SyncLocalInfo;
  remote: SyncRemoteInfo;
}

export type StartResult = 'started' | 'blocked';

interface AppContextValue {
  data: AppData;
  hydrated: boolean;
  engine: 'sqlite' | 'local';
  timer: TimerState;
  syncStatus: 'idle' | 'syncing' | 'success' | 'error';
  syncMessage: string;
  saveTask: (task: StudyTask) => void;
  saveTasks: (tasks: StudyTask[], removeIds?: string[]) => void;
  deleteTask: (id: string) => void;
  toggleTask: (id: string, date: string) => void;
  toggleTopThree: (id: string, date: string) => void;
  skipOccurrence: (id: string, date: string) => void;
  restoreOccurrence: (id: string, date: string) => void;
  autoSchedule: (date: string) => number;
  saveSubject: (subject: Subject) => void;
  deleteSubject: (id: string) => void;
  saveExam: (exam: Exam) => void;
  deleteExam: (id: string) => void;
  saveReview: (review: DailyReview) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  /** Replace all planner data (import / restore). Settings are replaced too. */
  replaceData: (incoming: AppData) => void;
  resetData: () => void;
  planCloudSync: () => Promise<CloudPlan>;
  syncCloud: (strategy?: SyncStrategy) => Promise<string>;
  /** Returns 'blocked' if a session is running/paused, unless `replace` is true (discarding it). */
  startFocus: (taskId?: string, subjectId?: string, replace?: boolean) => StartResult;
  startBreak: (kind: 'shortBreak' | 'longBreak') => void;
  pauseTimer: () => void;
  resumeTimer: () => void;
  resetTimer: () => void;
  /** Ends the current session. early = the user pressed "end". */
  finishTimer: (early?: boolean) => void;
  addDistraction: (text: string) => void;
  recordInterruption: () => void;
  getStorage: () => StorageEngine;
}

const AppContext = createContext<AppContextValue | null>(null);
const storage = createStorage();

function localInfo(data: AppData): SyncLocalInfo {
  return { edited: data.meta.edited, dirty: data.meta.dirty, lastSyncedAt: data.meta.lastSyncedAt, counts: countData(data) };
}

function directionLabel(direction: SyncDirection): string {
  return direction;
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData>(() => emptyData());
  const [hydrated, setHydrated] = useState(false);
  const [engineName, setEngineName] = useState<'sqlite' | 'local'>('local');
  const [timer, setTimer] = useState<TimerState>(() => machine.createIdleTimer(25));
  const [syncStatus, setSyncStatus] = useState<AppContextValue['syncStatus']>('idle');
  const [syncMessage, setSyncMessage] = useState<string>(syncText.notSynced);
  const dataRef = useRef(data);
  const timerRef = useRef(timer);
  const persistedRef = useRef<AppData | null>(null);
  const syncingRef = useRef(false);
  dataRef.current = data;
  timerRef.current = timer;

  // ---------- hydrate ----------
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const loaded = await storage.load();
        if (!mounted) return;
        let nextData = loaded.data;
        let nextTimer = loaded.timer ?? machine.createIdleTimer(nextData.settings.focusMinutes);
        // A timer that ran out while the app was closed (locked phone) is settled now and its session saved.
        const settled = machine.settleIfElapsed(nextTimer, Date.now(), nextData.settings.longBreakEvery);
        if (settled) {
          nextTimer = settled.state;
          if (settled.session) {
            const session: FocusSession = { id: makeId('session'), ...settled.session };
            nextData = { ...nextData, sessions: [...nextData.sessions, session], meta: { ...nextData.meta, updatedAt: new Date().toISOString(), dirty: true, edited: true } };
          }
        }
        persistedRef.current = loaded.data;
        setEngineName(loaded.engine);
        setData(nextData);
        setTimer(nextTimer);
        if (loaded.migratedFromLegacy) await storage.save(emptyData(), loaded.data).catch(() => undefined);
      } catch {
        // A damaged store must never keep the planner from opening: start empty.
        persistedRef.current = emptyData();
      } finally {
        if (mounted) setHydrated(true);
      }
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (!hydrated || persistedRef.current === null) return;
    const previous = persistedRef.current;
    if (previous === data) return;
    persistedRef.current = data;
    storage.save(previous, data).catch(() => undefined);
  }, [data, hydrated]);

  useEffect(() => {
    if (hydrated) storage.saveTimer(timer).catch(() => undefined);
  }, [timer, hydrated]);

  // Keep an idle timer in step with the focus length setting.
  useEffect(() => {
    if (!hydrated) return;
    setTimer((previous) => previous.status === 'idle' && previous.mode === 'focus' && previous.durationSeconds !== data.settings.focusMinutes * 60
      ? machine.createIdleTimer(data.settings.focusMinutes, previous.completedFocus, previous.lastCompletedDay) : previous);
  }, [data.settings.focusMinutes, hydrated]);

  const mutate = useCallback((recipe: (previous: AppData) => AppData) => {
    setData((previous) => {
      const next = recipe(previous);
      return { ...next, meta: { ...next.meta, updatedAt: new Date().toISOString(), dirty: true, edited: true } };
    });
  }, []);

  // ---------- planner CRUD ----------
  const saveTask = useCallback((task: StudyTask) => {
    const nextTask = { ...task, updatedAt: new Date().toISOString() };
    mutate((p) => ({ ...p, tasks: p.tasks.some((t) => t.id === task.id) ? p.tasks.map((t) => (t.id === task.id ? nextTask : t)) : [nextTask, ...p.tasks] }));
  }, [mutate]);

  const saveTasks = useCallback((tasks: StudyTask[], removeIds: string[] = []) => {
    const stamp = new Date().toISOString();
    mutate((p) => {
      const incoming = new Map(tasks.map((t) => [t.id, { ...t, updatedAt: stamp }]));
      const kept = p.tasks.filter((t) => !removeIds.includes(t.id)).map((t) => incoming.get(t.id) ?? t);
      const fresh = tasks.filter((t) => !p.tasks.some((x) => x.id === t.id)).map((t) => incoming.get(t.id) as StudyTask);
      return { ...p, tasks: [...fresh, ...kept] };
    });
  }, [mutate]);

  const deleteTask = useCallback((id: string) => mutate((p) => ({ ...p, tasks: p.tasks.filter((t) => t.id !== id) })), [mutate]);

  const toggleTask = useCallback((id: string, date: string) => {
    mutate((p) => ({ ...p, tasks: p.tasks.map((task) => {
      if (task.id !== id) return task;
      const done = task.completedDates.includes(date);
      return { ...task, updatedAt: new Date().toISOString(), completedDates: done ? task.completedDates.filter((d) => d !== date) : [...task.completedDates, date] };
    }) }));
  }, [mutate]);

  const toggleTopThree = useCallback((id: string, date: string) => {
    mutate((p) => {
      const selected = p.tasks.filter((t) => t.id !== id && t.topThreeDates.includes(date)).length;
      return { ...p, tasks: p.tasks.map((task) => {
        if (task.id !== id) return task;
        const included = task.topThreeDates.includes(date);
        if (!included && selected >= 3) return task;
        return { ...task, topThreeDates: included ? task.topThreeDates.filter((d) => d !== date) : [...task.topThreeDates, date] };
      }) };
    });
  }, [mutate]);

  const skipOccurrence = useCallback((id: string, date: string) => {
    mutate((p) => ({ ...p, tasks: p.tasks.map((t) => (t.id === id ? { ...skipOcc(t, date), updatedAt: new Date().toISOString() } : t)) }));
  }, [mutate]);

  const restoreOccurrence = useCallback((id: string, date: string) => {
    mutate((p) => ({ ...p, tasks: p.tasks.map((t) => (t.id === id ? { ...restoreOcc(t, date), updatedAt: new Date().toISOString() } : t)) }));
  }, [mutate]);

  const autoSchedule = useCallback((date: string) => {
    const current = dataRef.current;
    const todays = current.tasks.filter((t) => occursOn(t, date));
    const open = todays.filter((t) => t.startMinute === undefined && !isTaskComplete(t, date));
    if (!open.length) return 0;
    const busy = todays.filter((t) => t.startMinute !== undefined).map((t) => ({ start: t.startMinute as number, end: (t.startMinute as number) + t.durationMinutes }));
    const placed = autoPlace(open.map((t) => ({ id: t.id, durationMinutes: t.durationMinutes, priority: t.priority })), busy, {
      windowStart: current.settings.planStartMinute, windowEnd: current.settings.planEndMinute,
      notBefore: date === todayKey() ? nowMinutes() + 10 : undefined,
    });
    if (placed.size) {
      mutate((p) => ({ ...p, tasks: p.tasks.map((t) => (placed.has(t.id) ? { ...t, startMinute: placed.get(t.id), updatedAt: new Date().toISOString() } : t)) }));
    }
    return placed.size;
  }, [mutate]);

  const saveSubject = useCallback((subject: Subject) => {
    mutate((p) => ({ ...p, subjects: p.subjects.some((s) => s.id === subject.id) ? p.subjects.map((s) => (s.id === subject.id ? subject : s)) : [...p.subjects, subject] }));
  }, [mutate]);

  const deleteSubject = useCallback((id: string) => {
    mutate((p) => ({
      ...p, subjects: p.subjects.filter((s) => s.id !== id),
      tasks: p.tasks.map((t) => (t.subjectId === id ? { ...t, subjectId: undefined } : t)),
      exams: p.exams.map((e) => (e.subjectId === id ? { ...e, subjectId: undefined } : e)),
    }));
  }, [mutate]);

  const saveExam = useCallback((exam: Exam) => {
    mutate((p) => ({ ...p, exams: p.exams.some((e) => e.id === exam.id) ? p.exams.map((e) => (e.id === exam.id ? exam : e)) : [...p.exams, exam] }));
  }, [mutate]);

  const deleteExam = useCallback((id: string) => mutate((p) => ({ ...p, exams: p.exams.filter((e) => e.id !== id) })), [mutate]);

  const saveReview = useCallback((review: DailyReview) => {
    const stamped = { ...review, updatedAt: new Date().toISOString() };
    mutate((p) => ({ ...p, reviews: p.reviews.some((r) => r.date === review.date) ? p.reviews.map((r) => (r.date === review.date ? stamped : r)) : [...p.reviews, stamped] }));
  }, [mutate]);

  const updateSettings = useCallback((settings: Partial<AppSettings>) => {
    mutate((p) => ({ ...p, settings: { ...p.settings, ...settings } }));
  }, [mutate]);

  const replaceData = useCallback((incoming: AppData) => {
    const now = new Date().toISOString();
    setData((previous) => ({
      ...incoming,
      settings: { ...incoming.settings, notificationsPrompted: previous.settings.notificationsPrompted || incoming.settings.notificationsPrompted },
      meta: { updatedAt: now, lastSyncedAt: previous.meta.lastSyncedAt, dirty: true, edited: true },
    }));
    setTimer(machine.createIdleTimer(incoming.settings.focusMinutes));
  }, []);

  const resetData = useCallback(() => {
    setData((previous) => ({ ...emptyData(previous.settings), meta: { updatedAt: new Date().toISOString(), lastSyncedAt: previous.meta.lastSyncedAt, dirty: true, edited: true } }));
    setTimer(machine.createIdleTimer(dataRef.current.settings.focusMinutes));
  }, []);

  // ---------- cloud sync ----------
  const fetchRemote = useCallback(async () => {
    const supabase = await getSupabase();
    if (!supabase) throw new Error(syncText.needConfig);
    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) throw new Error(syncText.needSignIn);
    const { data: row, error } = await supabase.from('focusflow_state').select('data,updated_at').maybeSingle();
    if (error) throw new Error(error.message);
    const incoming = row ? normalizeData(row.data) : null;
    const remote: SyncRemoteInfo = {
      exists: Boolean(row), valid: Boolean(incoming), updatedAt: row?.updated_at as string | undefined,
      counts: incoming ? countData(incoming) : undefined,
    };
    return { supabase, userId: userData.user.id, remote, incoming };
  }, []);

  const planCloudSync = useCallback(async (): Promise<CloudPlan> => {
    const { remote } = await fetchRemote();
    const local = localInfo(dataRef.current);
    return { ...planSync(local, remote), local, remote };
  }, [fetchRemote]);

  const syncCloud = useCallback(async (strategy: SyncStrategy = 'sync'): Promise<string> => {
    if (syncingRef.current) throw new Error(syncText.alreadySyncing);
    syncingRef.current = true;
    setSyncStatus('syncing');
    setSyncMessage(syncText.connecting);
    try {
      const { supabase, userId, remote, incoming } = await fetchRemote();
      const local = localInfo(dataRef.current);
      let direction: SyncDirection;
      if (strategy === 'sync') {
        const plan = planSync(local, remote);
        if (plan.direction === 'conflict') throw new Error(syncText.conflict);
        direction = plan.direction;
      } else direction = strategy;

      let message: string = syncText.alreadyInSync;
      if (direction === 'upload') {
        if (!local.edited || !hasAnyContent(local.counts)) throw new Error(syncText.nothingToUpload);
        const timestamp = new Date().toISOString();
        const snapshot = dataRef.current;
        const payload: AppData = { ...snapshot, meta: { ...snapshot.meta, dirty: false, lastSyncedAt: timestamp } };
        const { error } = await supabase.from('focusflow_state').upsert({ user_id: userId, data: payload, updated_at: timestamp });
        if (error) throw new Error(error.message);
        setData((previous) => ({ ...previous, meta: { ...previous.meta, dirty: previous.meta.updatedAt !== snapshot.meta.updatedAt, lastSyncedAt: timestamp } }));
        message = syncText.uploaded;
      } else if (direction === 'download') {
        if (!incoming) throw new Error(remote.exists ? syncText.remoteInvalid : syncText.noBackup);
        const stamp = remote.updatedAt ?? new Date().toISOString();
        setData({
          ...incoming,
          meta: { updatedAt: stamp, lastSyncedAt: stamp, dirty: false, edited: hasAnyContent(countData(incoming)) },
        });
        message = syncText.downloaded;
      }
      setSyncStatus('success');
      setSyncMessage(message);
      return message;
    } catch (error) {
      const message = error instanceof Error ? error.message : syncText.failed;
      setSyncStatus('error');
      setSyncMessage(message);
      throw new Error(message);
    } finally {
      syncingRef.current = false;
    }
  }, [fetchRemote]);

  const syncRef = useRef({ planCloudSync, syncCloud });
  syncRef.current = { planCloudSync, syncCloud };
  useEffect(() => {
    if (!hydrated || !data.settings.autoSync || !data.meta.dirty || !data.meta.edited) return;
    const timeout = setTimeout(async () => {
      try {
        const plan = await syncRef.current.planCloudSync();
        if (isSafeForAuto(plan)) await syncRef.current.syncCloud(directionLabel(plan.direction) === 'download' ? 'download' : 'upload');
        else setSyncMessage(plan.direction === 'conflict' ? syncText.conflict : syncText.alreadyInSync);
      } catch {
        // offline or signed out: auto-sync quietly retries after the next edit
      }
    }, 12000);
    return () => clearTimeout(timeout);
  }, [data.meta.updatedAt, data.meta.dirty, data.meta.edited, data.settings.autoSync, hydrated]);

  // ---------- timer ----------
  const timerSettings = useCallback((): machine.TimerSettings => {
    const s = dataRef.current.settings;
    return { focusMinutes: s.focusMinutes, shortBreakMinutes: s.shortBreakMinutes, longBreakMinutes: s.longBreakMinutes, longBreakEvery: s.longBreakEvery };
  }, []);

  const startFocus = useCallback((taskId?: string, subjectId?: string, replace = false): StartResult => {
    if (!replace && machine.isActive(timerRef.current)) return 'blocked';
    const task = dataRef.current.tasks.find((t) => t.id === taskId);
    const next = machine.startFocus(timerRef.current, { taskId, subjectId: subjectId ?? task?.subjectId, focusMinutes: dataRef.current.settings.focusMinutes, now: Date.now() });
    timerRef.current = next;
    setTimer(next);
    return 'started';
  }, []);

  const startBreak = useCallback((kind: 'shortBreak' | 'longBreak') => {
    setTimer((previous) => machine.startBreak(previous, kind, timerSettings(), Date.now()));
  }, [timerSettings]);

  const pauseTimer = useCallback(() => setTimer((p) => machine.pause(p, Date.now())), []);
  const resumeTimer = useCallback(() => setTimer((p) => machine.resume(p, Date.now())), []);
  const resetTimer = useCallback(() => setTimer((p) => machine.reset(p, dataRef.current.settings.focusMinutes)), []);

  const finishTimer = useCallback((early = false) => {
    const current = timerRef.current;
    const result = machine.finish(current, Date.now(), early, dataRef.current.settings.longBreakEvery);
    if (result.state === current) return;
    timerRef.current = result.state;
    setTimer(result.state);
    if (result.session) {
      const session: FocusSession = { id: makeId('session'), ...result.session };
      mutate((p) => ({ ...p, sessions: [...p.sessions, session] }));
    }
  }, [mutate]);

  const addDistraction = useCallback((text: string) => setTimer((p) => machine.addDistraction(p, text)), []);
  const recordInterruption = useCallback(() => setTimer((p) => machine.markInterruption(p)), []);

  // Settle the timer when it reaches zero, on whichever screen the user is looking at.
  useEffect(() => {
    if (!hydrated || timer.status !== 'running') return;
    const check = () => {
      if (machine.settleIfElapsed(timerRef.current, Date.now(), dataRef.current.settings.longBreakEvery)) finishTimer(false);
    };
    check();
    const interval = setInterval(check, 500);
    const sub = AppState.addEventListener('change', (state) => { if (state === 'active') check(); });
    return () => { clearInterval(interval); sub.remove(); };
  }, [hydrated, timer.status, timer.endAt, finishTimer]);

  const value = useMemo<AppContextValue>(() => ({
    data, hydrated, engine: engineName, timer, syncStatus, syncMessage,
    saveTask, saveTasks, deleteTask, toggleTask, toggleTopThree, skipOccurrence, restoreOccurrence, autoSchedule,
    saveSubject, deleteSubject, saveExam, deleteExam, saveReview, updateSettings, replaceData, resetData,
    planCloudSync, syncCloud, startFocus, startBreak, pauseTimer, resumeTimer, resetTimer, finishTimer,
    addDistraction, recordInterruption, getStorage: () => storage,
  }), [data, hydrated, engineName, timer, syncStatus, syncMessage, saveTask, saveTasks, deleteTask, toggleTask, toggleTopThree,
    skipOccurrence, restoreOccurrence, autoSchedule, saveSubject, deleteSubject, saveExam, deleteExam, saveReview, updateSettings,
    replaceData, resetData, planCloudSync, syncCloud, startFocus, startBreak, pauseTimer, resumeTimer, resetTimer, finishTimer,
    addDistraction, recordInterruption]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside AppProvider');
  return context;
}
