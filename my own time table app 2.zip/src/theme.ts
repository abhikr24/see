import { useColorScheme } from 'react-native';
import { useApp } from './store/AppContext';

export interface AppTheme {
  dark: boolean;
  background: string;
  surface: string;
  surfaceAlt: string;
  text: string;
  muted: string;
  faint: string;
  border: string;
  primary: string;
  primarySoft: string;
  accent: string;
  accentText: string;
  warning: string;
  danger: string;
  success: string;
  shadow: string;
}

export const lightTheme: AppTheme = {
  dark: false,
  background: '#F5F6F1',
  surface: '#FFFFFF',
  surfaceAlt: '#ECEFE8',
  text: '#17211C',
  muted: '#66716A',
  faint: '#98A199',
  border: '#E1E6DF',
  primary: '#315C4D',
  primarySoft: '#DDEAE2',
  accent: '#DDF3A7',
  accentText: '#233B24',
  warning: '#D98B3A',
  danger: '#C95656',
  success: '#4D8A67',
  shadow: '#173B2B',
};

export const darkTheme: AppTheme = {
  dark: true,
  background: '#101512',
  surface: '#19211C',
  surfaceAlt: '#232D27',
  text: '#F2F6F1',
  muted: '#A2AFA6',
  faint: '#738078',
  border: '#2C3830',
  primary: '#9CC9B1',
  primarySoft: '#263D31',
  accent: '#C7E991',
  accentText: '#1C301E',
  warning: '#E8AC68',
  danger: '#F08A8A',
  success: '#8BC6A1',
  shadow: '#000000',
};

export const SUBJECT_COLORS = ['#5D8F7B', '#E49264', '#7C83C5', '#D3A847', '#B87591', '#4D91A8', '#8A9B55'];

export function useTheme(): AppTheme {
  const system = useColorScheme();
  const { data } = useApp();
  const mode = data.settings.theme;
  return mode === 'dark' || (mode === 'system' && system === 'dark') ? darkTheme : lightTheme;
}

export const radius = { sm: 10, md: 16, lg: 22, xl: 28 };
