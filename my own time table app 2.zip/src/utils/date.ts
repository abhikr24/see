export const DAY_MS = 24 * 60 * 60 * 1000;

export function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function fromDateKey(key: string): Date {
  const [year, month, day] = key.split('-').map(Number);
  return new Date(year, month - 1, day, 12, 0, 0, 0);
}

export function isValidDateKey(key: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(key) && !Number.isNaN(fromDateKey(key).getTime()) && toDateKey(fromDateKey(key)) === key;
}

export function todayKey(now: Date = new Date()): string {
  return toDateKey(now);
}

export function addDays(key: string, amount: number): string {
  const date = fromDateKey(key);
  date.setDate(date.getDate() + amount);
  return toDateKey(date);
}

/** 0 = Sunday … 6 = Saturday */
export function dayOfWeek(key: string): number {
  return fromDateKey(key).getDay();
}

export function startOfWeek(key: string, monday = true): string {
  const day = dayOfWeek(key);
  const diff = monday ? (day === 0 ? -6 : 1 - day) : -day;
  return addDays(key, diff);
}

export function weekDates(key: string, monday = true): string[] {
  const start = startOfWeek(key, monday);
  return Array.from({ length: 7 }, (_, index) => addDays(start, index));
}

export function formatLongDate(key: string): string {
  return fromDateKey(key).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });
}

export function formatShortDate(key: string): string {
  return fromDateKey(key).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function weekdayShort(key: string): string {
  return fromDateKey(key).toLocaleDateString(undefined, { weekday: 'short' });
}

export function formatTime(totalMinutes: number): string {
  const normalized = ((Math.round(totalMinutes) % 1440) + 1440) % 1440;
  const hours = Math.floor(normalized / 60);
  const minutes = normalized % 60;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  const hour = hours % 12 || 12;
  return `${hour}:${String(minutes).padStart(2, '0')} ${suffix}`;
}

export function formatHourLabel(hour: number): string {
  if (hour === 0 || hour === 24) return '12 AM';
  if (hour === 12) return '12 PM';
  return hour < 12 ? `${hour} AM` : `${hour - 12} PM`;
}

export function formatDuration(minutes: number): string {
  const rounded = Math.round(minutes);
  if (rounded < 60) return `${rounded}m`;
  const hours = Math.floor(rounded / 60);
  const rest = rounded % 60;
  return rest ? `${hours}h ${rest}m` : `${hours}h`;
}

/** Elapsed time with seconds precision for very short sessions: "45s", "2m", "1m 30s". */
export function formatElapsed(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  if (total < 60) return `${total}s`;
  if (total < 3600) {
    const m = Math.floor(total / 60);
    const s = total % 60;
    return s >= 30 && total < 300 ? `${m}m ${s}s` : `${Math.round(total / 60)}m`;
  }
  return formatDuration(total / 60);
}

export function relativeDay(key: string, today: string = todayKey()): string {
  if (key === today) return 'Today';
  if (key === addDays(today, 1)) return 'Tomorrow';
  if (key === addDays(today, -1)) return 'Yesterday';
  return formatShortDate(key);
}

export function daysUntil(key: string, today: string = todayKey()): number {
  return Math.round((fromDateKey(key).getTime() - fromDateKey(today).getTime()) / DAY_MS);
}

export function nowMinutes(now: Date = new Date()): number {
  return now.getHours() * 60 + now.getMinutes();
}

export function makeId(prefix = 'item'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

export function dateFromIso(iso: string): string {
  return toDateKey(new Date(iso));
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function snapTo(value: number, step: number): number {
  return Math.round(value / step) * step;
}

/** "HH:MM" (24h) → minutes, or undefined if invalid. */
export function parseClock(text: string): number | undefined {
  const match = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(text.trim());
  return match ? Number(match[1]) * 60 + Number(match[2]) : undefined;
}

export function toClock(minutes: number): string {
  const normalized = ((Math.round(minutes) % 1440) + 1440) % 1440;
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`;
}

/** Local Date for a day key and minutes-from-midnight. */
export function dateAtMinute(key: string, minute: number): Date {
  const date = fromDateKey(key);
  date.setHours(0, 0, 0, 0);
  date.setMinutes(minute);
  return date;
}
