import { FocusSession } from '../types';
import { dateFromIso } from './date';

export interface DistractionGroup {
  key: string;
  label: string;
  count: number;
}

export const distractionKey = (text: string): string => text.trim().toLowerCase().replace(/\s+/g, ' ');

/** Parked distractions from a day's sessions (plus any still on a running timer), grouped and counted. */
export function groupDistractions(sessions: FocusSession[], date: string, live: string[] = []): DistractionGroup[] {
  const groups = new Map<string, DistractionGroup>();
  const add = (text: string) => {
    const key = distractionKey(text);
    if (!key) return;
    const existing = groups.get(key);
    if (existing) existing.count += 1;
    else groups.set(key, { key, label: text.trim(), count: 1 });
  };
  sessions.filter((s) => dateFromIso(s.startedAt) === date).forEach((s) => s.distractions.forEach(add));
  live.forEach(add);
  return [...groups.values()].sort((a, b) => b.count - a.count || a.label.localeCompare(b.label));
}
