import { AppData, FocusSession, Subject } from '../types';
import { addDays, dateFromIso, dayOfWeek, startOfWeek, todayKey } from './date';
import { focusMinutesForDate, isTaskComplete, tasksForDate } from './selectors';
import { insightText as T } from '../i18n/insights';
import { weekdayLong } from '../i18n/base';
import type { IconName } from '../components/icons';

export interface Insight { id: string; icon: IconName; tone: 'good' | 'warn' | 'info'; text: string }

/** Distribute each session's real elapsed minutes across the clock hours it covered. */
export function minutesByHour(sessions: FocusSession[]): number[] {
  const buckets = new Array<number>(24).fill(0);
  sessions.forEach((session) => {
    let cursor = new Date(session.startedAt).getTime();
    let remaining = Math.max(0, session.actualSeconds || session.actualMinutes * 60);
    let guard = 0;
    while (remaining > 0 && guard < 30) {
      const date = new Date(cursor);
      const secondsLeftInHour = 3600 - (date.getMinutes() * 60 + date.getSeconds());
      const used = Math.min(remaining, secondsLeftInHour);
      buckets[date.getHours()] += used / 60;
      remaining -= used;
      cursor += used * 1000;
      guard += 1;
    }
  });
  return buckets;
}

export function bestStudyHour(sessions: FocusSession[]): { hour: number; minutes: number; share: number } | null {
  const buckets = minutesByHour(sessions);
  const total = buckets.reduce((a, b) => a + b, 0);
  if (total < 20) return null;
  const hour = buckets.indexOf(Math.max(...buckets));
  return { hour, minutes: buckets[hour], share: Math.round((buckets[hour] / total) * 100) };
}

/** Average focus minutes per calendar day for each weekday over the last 8 weeks. */
export function weekdayAverages(sessions: FocusSession[], today: string = todayKey()): number[] {
  const totals = new Array<number>(7).fill(0);
  const counts = new Array<number>(7).fill(0);
  for (let i = 0; i < 56; i += 1) {
    const date = addDays(today, -i);
    const day = dayOfWeek(date);
    counts[day] += 1;
    totals[day] += focusMinutesForDate(sessions, date);
  }
  return totals.map((total, day) => (counts[day] ? total / counts[day] : 0));
}

export function bestWeekday(sessions: FocusSession[], today: string = todayKey()): { best: number; worst: number; bestAvg: number; worstAvg: number } | null {
  if (sessions.length < 3) return null;
  const averages = weekdayAverages(sessions, today);
  const bestAvg = Math.max(...averages);
  if (bestAvg <= 0) return null;
  const worstAvg = Math.min(...averages);
  return { best: averages.indexOf(bestAvg), worst: averages.indexOf(worstAvg), bestAvg, worstAvg };
}

function mean(values: number[]): number {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}

export function sleepVsFocus(data: AppData, today: string = todayKey()) {
  const good: number[] = [];
  const short: number[] = [];
  data.reviews.forEach((review) => {
    if (review.sleepHours <= 0 || review.date > today || review.date < addDays(today, -90)) return;
    const minutes = focusMinutesForDate(data.sessions, review.date);
    (review.sleepHours >= 7 ? good : short).push(minutes);
  });
  if (!good.length || !short.length) return null;
  return { goodAvg: Math.round(mean(good)), shortAvg: Math.round(mean(short)), goodDays: good.length, shortDays: short.length };
}

export function energyVsCompletion(data: AppData, today: string = todayKey()) {
  const rate = (dates: string[]) => {
    let planned = 0;
    let done = 0;
    dates.forEach((date) => {
      const tasks = tasksForDate(data.tasks, date);
      planned += tasks.length;
      done += tasks.filter((t) => isTaskComplete(t, date)).length;
    });
    return planned ? Math.round((done / planned) * 100) : null;
  };
  const withTasks = data.reviews.filter((r) => r.energy > 0 && r.date <= today && tasksForDate(data.tasks, r.date).length > 0);
  const high = withTasks.filter((r) => r.energy >= 4).map((r) => r.date);
  const low = withTasks.filter((r) => r.energy <= 2).map((r) => r.date);
  const highRate = rate(high);
  const lowRate = rate(low);
  if (highRate === null || lowRate === null) return null;
  return { highRate, lowRate, highDays: high.length, lowDays: low.length };
}

export function moodVsDistractions(data: AppData, today: string = todayKey()) {
  const count = (date: string) => data.sessions.filter((s) => dateFromIso(s.startedAt) === date).reduce((sum, s) => sum + s.distractions.length, 0);
  const days = data.reviews.filter((r) => r.mood > 0 && r.date <= today && focusMinutesForDate(data.sessions, r.date) > 0);
  const low = days.filter((r) => r.mood <= 2).map((r) => count(r.date));
  const high = days.filter((r) => r.mood >= 4).map((r) => count(r.date));
  if (!low.length || !high.length) return null;
  return { lowAvg: mean(low), highAvg: mean(high), lowDays: low.length, highDays: high.length };
}

export interface SubjectProgress {
  subject: Subject;
  minutes: number;
  goal: number;
  pct: number;
  avoided: boolean;
  undone: number;
}

export function subjectProgress(data: AppData, today: string = todayKey()): SubjectProgress[] {
  const weekStart = startOfWeek(today, data.settings.weekStartsMonday);
  const daysIntoWeek = Math.round((new Date(`${today}T12:00:00`).getTime() - new Date(`${weekStart}T12:00:00`).getTime()) / 86400000) + 1;
  return data.subjects.filter((s) => !s.archived).map((subject) => {
    const minutes = data.sessions.filter((s) => s.subjectId === subject.id && dateFromIso(s.startedAt) >= weekStart && dateFromIso(s.startedAt) <= today)
      .reduce((sum, s) => sum + s.actualMinutes, 0);
    const goal = subject.weeklyGoalMinutes;
    const pct = goal ? Math.round((minutes / goal) * 100) : 0;
    let undone = 0;
    for (let i = 0; i < 14; i += 1) {
      const date = addDays(today, -i);
      undone += tasksForDate(data.tasks, date).filter((t) => t.subjectId === subject.id && !isTaskComplete(t, date) && date < today).length;
    }
    const expected = (daysIntoWeek / 7) * 100;
    const behind = goal > 0 && daysIntoWeek >= 3 && pct < expected * 0.35;
    const ignoredPlans = undone >= 2 && minutes === 0;
    return { subject, minutes, goal, pct, avoided: behind || ignoredPlans, undone };
  }).sort((a, b) => Number(b.avoided) - Number(a.avoided) || a.pct - b.pct);
}

export function buildInsights(data: AppData, today: string = todayKey()): Insight[] {
  const out: Insight[] = [];
  const hour = bestStudyHour(data.sessions);
  out.push(hour
    ? { id: 'hour', icon: 'time-outline', tone: 'good', text: T.bestHour(T.hourRange(hour.hour), hour.share) }
    : { id: 'hour', icon: 'time-outline', tone: 'info', text: T.needMore('your best study hour') });
  const weekday = bestWeekday(data.sessions, today);
  if (weekday) {
    out.push({ id: 'weekday', icon: 'calendar-outline', tone: 'good', text: weekday.best === weekday.worst
      ? T.bestWeekdayOnly(weekdayLong[weekday.best], Math.round(weekday.bestAvg))
      : T.bestWeekday(weekdayLong[weekday.best], Math.round(weekday.bestAvg), weekdayLong[weekday.worst], Math.round(weekday.worstAvg)) });
  } else out.push({ id: 'weekday', icon: 'calendar-outline', tone: 'info', text: T.needMore('your best weekday') });
  const sleep = sleepVsFocus(data, today);
  out.push(sleep
    ? { id: 'sleep', icon: 'moon-outline', tone: sleep.goodAvg >= sleep.shortAvg ? 'good' : 'info', text: T.sleep(sleep.goodAvg, sleep.shortAvg, sleep.goodDays, sleep.shortDays) }
    : { id: 'sleep', icon: 'moon-outline', tone: 'info', text: T.needMore('sleep versus focus (log sleep in a few evening reviews)') });
  const energy = energyVsCompletion(data, today);
  out.push(energy
    ? { id: 'energy', icon: 'flash-outline', tone: 'info', text: T.energy(energy.highRate, energy.lowRate, energy.highDays, energy.lowDays) }
    : { id: 'energy', icon: 'flash-outline', tone: 'info', text: T.needMore('energy versus completion') });
  const mood = moodVsDistractions(data, today);
  out.push(mood
    ? { id: 'mood', icon: 'happy-outline', tone: 'info', text: T.mood(mood.lowAvg.toFixed(1), mood.highAvg.toFixed(1)) }
    : { id: 'mood', icon: 'happy-outline', tone: 'info', text: T.needMore('mood versus distractions') });
  subjectProgress(data, today).filter((p) => p.avoided).forEach((p) => {
    out.unshift({ id: `avoid_${p.subject.id}`, icon: 'warning-outline', tone: 'warn', text: T.avoided(p.subject.name, p.minutes, p.undone) });
  });
  return out;
}
