export interface LaneItem { id: string; start: number; end: number }
export interface LanePlacement { lane: number; lanes: number }

/** Side-by-side column layout for overlapping blocks (Google-Calendar style). */
export function layoutLanes(items: LaneItem[]): Map<string, LanePlacement> {
  const result = new Map<string, LanePlacement>();
  const sorted = [...items].sort((a, b) => a.start - b.start || b.end - a.end || a.id.localeCompare(b.id));
  let cluster: { item: LaneItem; lane: number }[] = [];
  let laneEnds: number[] = [];
  let clusterEnd = -1;

  const flush = () => {
    cluster.forEach(({ item, lane }) => result.set(item.id, { lane, lanes: laneEnds.length }));
    cluster = [];
    laneEnds = [];
    clusterEnd = -1;
  };

  sorted.forEach((item) => {
    if (cluster.length && item.start >= clusterEnd) flush();
    let lane = laneEnds.findIndex((end) => end <= item.start);
    if (lane === -1) {
      lane = laneEnds.length;
      laneEnds.push(item.end);
    } else laneEnds[lane] = item.end;
    cluster.push({ item, lane });
    clusterEnd = Math.max(clusterEnd, item.end);
  });
  flush();
  return result;
}
