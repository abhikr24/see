import { Priority } from '../types';

export interface Interval { start: number; end: number }
export interface PlaceCandidate { id: string; durationMinutes: number; priority: Priority }
export interface PlaceOptions {
  windowStart: number;
  windowEnd: number;
  /** Earliest allowed start (e.g. "now" when planning today). */
  notBefore?: number;
  granularity?: number;
  bufferMinutes?: number;
}

const weight: Record<Priority, number> = { high: 0, medium: 1, low: 2 };

/**
 * Greedy auto-placement by real duration: each candidate takes the earliest free slot (on a 15-minute grid)
 * that does not collide with existing blocks, keeping a small buffer between blocks.
 */
export function autoPlace(candidates: PlaceCandidate[], busy: Interval[], options: PlaceOptions): Map<string, number> {
  const granularity = options.granularity ?? 15;
  const buffer = options.bufferMinutes ?? 5;
  const taken: Interval[] = busy.map((i) => ({ ...i }));
  const placed = new Map<string, number>();
  const first = Math.ceil(Math.max(options.windowStart, options.notBefore ?? 0) / granularity) * granularity;
  const ordered = [...candidates].sort((a, b) => weight[a.priority] - weight[b.priority] || b.durationMinutes - a.durationMinutes || a.id.localeCompare(b.id));

  ordered.forEach((candidate) => {
    for (let start = first; start + candidate.durationMinutes <= options.windowEnd; start += granularity) {
      const end = start + candidate.durationMinutes;
      const clash = taken.some((t) => start < t.end + buffer && t.start < end + buffer);
      if (!clash) {
        placed.set(candidate.id, start);
        taken.push({ start, end });
        return;
      }
    }
  });
  return placed;
}
