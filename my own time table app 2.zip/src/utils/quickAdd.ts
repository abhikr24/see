import { Priority, Recurrence, Subject } from '../types';
import { addDays, dayOfWeek, formatDuration, formatShortDate, formatTime, toDateKey } from './date';

export interface QuickAddContext {
  subjects: Subject[];
  today: string;
  defaultDuration: number;
}

export interface QuickAddResult {
  title: string;
  subjectId?: string;
  durationMinutes: number;
  date: string;
  startMinute?: number;
  priority: Priority;
  recurrence: Recurrence;
  recurDays: number[];
  /** Human-readable pieces that were understood, for preview chips. */
  recognized: string[];
}

const WEEKDAYS: Record<string, number> = {
  sunday: 0, sun: 0, monday: 1, mon: 1, tuesday: 2, tues: 2, tue: 2, wednesday: 3, wed: 3,
  thursday: 4, thurs: 4, thur: 4, thu: 4, friday: 5, fri: 5, saturday: 6, sat: 6,
};
const MONTHS: Record<string, number> = {
  january: 0, jan: 0, february: 1, feb: 1, march: 2, mar: 2, april: 3, apr: 3, may: 4, june: 5, jun: 5, july: 6, jul: 6,
  august: 7, aug: 7, september: 8, sept: 8, sep: 8, october: 9, oct: 9, november: 10, nov: 10, december: 11, dec: 11,
};
const WEEKDAY_ALT = Object.keys(WEEKDAYS).sort((a, b) => b.length - a.length).join('|');
const MONTH_ALT = Object.keys(MONTHS).sort((a, b) => b.length - a.length).join('|');

function nextWeekday(from: string, target: number, forceNext: boolean): string {
  const diff = (target - dayOfWeek(from) + 7) % 7;
  return addDays(from, diff === 0 && forceNext ? 7 : diff);
}

export function parseQuickAdd(input: string, ctx: QuickAddContext): QuickAddResult {
  let text = ` ${input.trim()} `;
  const recognized: string[] = [];
  const take = (re: RegExp): RegExpExecArray | null => {
    const match = re.exec(text);
    if (match) text = `${text.slice(0, match.index)} ${text.slice(match.index + match[0].length)}`;
    return match;
  };

  let recurrence: Recurrence = 'none';
  let recurDays: number[] = [];
  let date: string | undefined;
  let startMinute: number | undefined;
  let durationMinutes: number | undefined;
  let priority: Priority = 'medium';
  let hasPriority = false;

  // Recurrence
  const everyDay = take(new RegExp(`\\bevery\\s+(${WEEKDAY_ALT})s?\\b`, 'i'));
  if (everyDay) {
    const day = WEEKDAYS[everyDay[1].toLowerCase()];
    recurrence = 'custom'; recurDays = [day];
    date = nextWeekday(ctx.today, day, false);
    recognized.push(`Every ${everyDay[1]}`);
  } else if (take(/\b(daily|every\s*day|each\s*day)\b/i)) {
    recurrence = 'daily'; recognized.push('Daily');
  } else if (take(/\bweekdays\b/i)) {
    recurrence = 'weekdays'; recognized.push('Weekdays');
  }

  // Priority
  if (take(/(^|\s)!{2,3}(?=\s)/)) { priority = 'high'; hasPriority = true; }
  else {
    const p = take(/\b(?:priority\s+)?(high|urgent|important|low|medium|med)(?:\s+priority)?\b/i);
    if (p) {
      const word = p[1].toLowerCase();
      priority = word === 'low' ? 'low' : word === 'medium' || word === 'med' ? 'medium' : 'high';
      hasPriority = true;
    }
  }
  if (hasPriority) recognized.push(`${priority[0].toUpperCase()}${priority.slice(1)} priority`);

  // Duration: 1h30m, 2 hours, 1.5h, 45m, 90 min
  const hm = take(/\b(\d+(?:\.\d+)?)\s*h(?:ours?|rs?)?\s*(?:(\d{1,2})\s*m(?:in(?:ute)?s?)?)?(?!\w)/i);
  if (hm) durationMinutes = Math.round(parseFloat(hm[1]) * 60 + (hm[2] ? parseInt(hm[2], 10) : 0));
  else {
    const m = take(/\b(\d{1,3})\s*(?:m|mins?|minutes?)(?!\w)/i);
    if (m) durationMinutes = parseInt(m[1], 10);
  }
  if (durationMinutes !== undefined) {
    durationMinutes = Math.min(1440, Math.max(5, durationMinutes));
    recognized.push(formatDuration(durationMinutes));
  }

  // Time of day
  const ampm = take(/\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)(?!\w)/i);
  if (ampm) {
    let hour = parseInt(ampm[1], 10) % 12;
    if (ampm[3].toLowerCase().startsWith('p')) hour += 12;
    startMinute = hour * 60 + (ampm[2] ? parseInt(ampm[2], 10) : 0);
  } else {
    const h24 = take(/\b(?:at\s+)?([01]?\d|2[0-3]):([0-5]\d)\b/);
    if (h24) startMinute = parseInt(h24[1], 10) * 60 + parseInt(h24[2], 10);
    else if (take(/\bnoon\b/i)) startMinute = 720;
    else if (take(/\bmidnight\b/i)) startMinute = 0;
    else {
      const at = take(/\bat\s+(\d{1,2})(?!\w|:)/i);
      if (at) {
        const h = parseInt(at[1], 10);
        if (h >= 0 && h <= 23) startMinute = (h >= 1 && h <= 6 ? h + 12 : h) * 60;
      }
    }
  }
  if (startMinute !== undefined) recognized.push(formatTime(startMinute));

  // Date
  const iso = take(/\b(\d{4}-\d{2}-\d{2})\b/);
  if (iso) date = iso[1];
  if (!date) {
    if (take(/\b(tomorrow|tmrw|tmr)\b/i)) date = addDays(ctx.today, 1);
    else if (take(/\btonight\b/i)) { date = ctx.today; if (startMinute === undefined) startMinute = 19 * 60; }
    else if (take(/\btoday\b/i)) date = ctx.today;
    else {
      const inDays = take(/\bin\s+(\d{1,3})\s+days?\b/i);
      if (inDays) date = addDays(ctx.today, parseInt(inDays[1], 10));
    }
  }
  if (!date) {
    const dm = take(new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(${MONTH_ALT})\\b`, 'i'))
      ?? take(new RegExp(`\\b(${MONTH_ALT})\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b`, 'i'));
    if (dm) {
      const dayFirst = /^\d/.test(dm[1]);
      const day = parseInt(dayFirst ? dm[1] : dm[2], 10);
      const month = MONTHS[(dayFirst ? dm[2] : dm[1]).toLowerCase()];
      const year = parseInt(ctx.today.slice(0, 4), 10);
      let candidate = toDateKey(new Date(year, month, day, 12));
      if (candidate < ctx.today) candidate = toDateKey(new Date(year + 1, month, day, 12));
      date = candidate;
    }
  }
  if (!date) {
    const wd = take(new RegExp(`\\b(next\\s+|this\\s+|on\\s+)?(${WEEKDAY_ALT})\\b`, 'i'));
    if (wd) date = nextWeekday(ctx.today, WEEKDAYS[wd[2].toLowerCase()], Boolean(wd[1] && /next/i.test(wd[1])));
  }
  if (date) recognized.splice(0, 0, date === ctx.today ? 'Today' : date === addDays(ctx.today, 1) ? 'Tomorrow' : formatShortDate(date));

  // Subject (matched against the words left over; the name stays in the title)
  let subjectId: string | undefined;
  const lower = text.toLowerCase();
  const sortedSubjects = [...ctx.subjects].filter((s) => !s.archived).sort((a, b) => b.name.length - a.name.length);
  const exact = sortedSubjects.find((s) => new RegExp(`(^|[^a-z0-9])${s.name.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![a-z0-9])`).test(lower));
  const looseMatch = (word: string, name: string): boolean => {
    const n = name.toLowerCase();
    const initials = n.split(/\s+/).map((part) => part[0]).join('');
    if (word.length >= 3 && n.startsWith(word)) return true;
    if (word.length >= 4 && n.startsWith(word.slice(0, 4)) && n.length >= 4) return true;
    return word.length >= 2 && initials.length >= 2 && word === initials;
  };
  const prefix = exact ?? sortedSubjects.find((s) => lower.split(/\s+/).filter(Boolean).some((word) => looseMatch(word, s.name)));
  if (prefix) { subjectId = prefix.id; recognized.push(prefix.name); }

  let title = text.replace(/\s+/g, ' ').trim()
    .replace(/^(at|on|for|by|from|to|@)\s+/i, '').replace(/\s+(at|on|for|by|from|to|@|in)$/i, '').trim();
  if (!title) title = prefix ? prefix.name : 'Study block';
  title = title[0].toUpperCase() + title.slice(1);

  return {
    title, subjectId, durationMinutes: durationMinutes ?? ctx.defaultDuration, date: date ?? ctx.today, startMinute,
    priority, recurrence, recurDays, recognized,
  };
}
