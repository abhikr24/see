import { StudyTask } from '../types';
import { addDays, dayOfWeek } from './date';

/** Does this block (or its recurring series) occur on `date`? Honours end date and skipped occurrences. */
export function occursOn(task: StudyTask, date: string): boolean {
  if (date < task.date) return false;
  if (task.recurrence === 'none') return task.date === date;
  if (task.recurUntil && date > task.recurUntil) return false;
  if (task.skippedDates.includes(date)) return false;
  const day = dayOfWeek(date);
  switch (task.recurrence) {
    case 'daily': return true;
    case 'weekdays': return day !== 0 && day !== 6;
    case 'weekly': return day === dayOfWeek(task.date);
    case 'custom': return task.recurDays.includes(day);
    default: return false;
  }
}

export function isRecurring(task: StudyTask): boolean {
  return task.recurrence !== 'none';
}

export function skipOccurrence(task: StudyTask, date: string): StudyTask {
  if (task.recurrence === 'none' || task.skippedDates.includes(date)) return task;
  return { ...task, skippedDates: [...task.skippedDates, date].sort() };
}

export function restoreOccurrence(task: StudyTask, date: string): StudyTask {
  return { ...task, skippedDates: task.skippedDates.filter((d) => d !== date) };
}

/** Next `count` dates (from `from`, inclusive) on which the series occurs. */
export function upcomingOccurrences(task: StudyTask, from: string, count: number, horizonDays = 400): string[] {
  const out: string[] = [];
  for (let i = 0; i < horizonDays && out.length < count; i += 1) {
    const date = addDays(from, i);
    if (occursOn(task, date)) out.push(date);
  }
  return out;
}

export function recurrenceSummary(task: StudyTask, weekdayNames: string[]): string {
  switch (task.recurrence) {
    case 'daily': return 'Every day';
    case 'weekdays': return 'Weekdays';
    case 'weekly': return `Every ${weekdayNames[dayOfWeek(task.date)]}`;
    case 'custom': return task.recurDays.length ? [...task.recurDays].sort((a, b) => a - b).map((d) => weekdayNames[d]).join(' · ') : 'No days chosen';
    default: return 'Does not repeat';
  }
}
