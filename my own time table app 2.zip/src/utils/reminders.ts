import { AppSettings, StudyTask, TimerState } from '../types';
import { breakAfter } from '../lib/timerMachine';
import { addDays, dateAtMinute, formatDuration, formatTime, todayKey } from './date';
import { occursOn } from './recurrence';
import { notify } from '../i18n/base';

export type PlannedKind = 'focus-end' | 'break-end' | 'block-start';

export interface PlannedNotification {
  id: string;
  kind: PlannedKind;
  fireAt: number;
  title: string;
  body: string;
  data: { kind: PlannedKind; nextBreak?: 'shortBreak' | 'longBreak'; taskId?: string; date?: string };
}

export interface PlanInput {
  timer: TimerState;
  tasks: StudyTask[];
  settings: AppSettings;
  now: number;
  horizonDays?: number;
  maxBlocks?: number;
}

/** Everything that should currently be scheduled with the OS (so it rings with the phone locked). */
export function buildNotificationPlan(input: PlanInput): PlannedNotification[] {
  const { timer, tasks, settings, now } = input;
  const plan: PlannedNotification[] = [];

  if (timer.status === 'running' && timer.endAt !== undefined && timer.endAt > now) {
    if (timer.mode === 'focus' && settings.notifyFocusEnd) {
      const nextBreak = breakAfter(timer.completedFocus + 1, settings.longBreakEvery);
      const minutes = nextBreak === 'longBreak' ? settings.longBreakMinutes : settings.shortBreakMinutes;
      plan.push({
        id: 'timer-end', kind: 'focus-end', fireAt: timer.endAt, title: notify.focusEndTitle,
        body: notify.focusEndBody(minutes, nextBreak === 'longBreak'), data: { kind: 'focus-end', nextBreak },
      });
    } else if (timer.mode !== 'focus' && settings.notifyBreakEnd) {
      plan.push({ id: 'timer-end', kind: 'break-end', fireAt: timer.endAt, title: notify.breakEndTitle, body: notify.breakEndBody, data: { kind: 'break-end' } });
    }
  }

  if (settings.notifyBlockStart) {
    const horizon = input.horizonDays ?? 3;
    const maxBlocks = input.maxBlocks ?? 30;
    const startDay = todayKey(new Date(now));
    const blocks: PlannedNotification[] = [];
    for (let i = 0; i <= horizon; i += 1) {
      const date = addDays(startDay, i);
      tasks.forEach((task) => {
        if (task.startMinute === undefined || !occursOn(task, date) || task.completedDates.includes(date)) return;
        const fireAt = dateAtMinute(date, task.startMinute - settings.blockLeadMinutes).getTime();
        if (fireAt <= now) return;
        blocks.push({
          id: `block-${task.id}-${date}`, kind: 'block-start', fireAt, title: notify.blockTitle(task.title),
          body: notify.blockBody(settings.blockLeadMinutes, formatTime(task.startMinute), formatDuration(task.durationMinutes)),
          data: { kind: 'block-start', taskId: task.id, date },
        });
      });
    }
    blocks.sort((a, b) => a.fireAt - b.fireAt);
    plan.push(...blocks.slice(0, maxBlocks));
  }
  return plan;
}
