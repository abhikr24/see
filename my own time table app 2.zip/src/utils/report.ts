import { AppData } from '../types';
import { addDays, dateFromIso, formatDuration, formatShortDate, todayKey } from './date';
import { bestStudyHour, subjectProgress } from './insights';
import { focusMinutesForDate, focusStreak, isTaskComplete, tasksForDate } from './selectors';
import { reportText as R } from '../i18n/insights';
import { insightText as T } from '../i18n/insights';

export interface ReportCardData {
  rangeStart: string;
  rangeEnd: string;
  minutes: number;
  blocksDone: number;
  streak: number;
  bestDay?: { date: string; minutes: number };
  topSubject?: { name: string; color: string; minutes: number };
  recommendation: string;
}

export function buildReportCard(data: AppData, today: string = todayKey()): ReportCardData {
  const days = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
  const values = days.map((date) => focusMinutesForDate(data.sessions, date));
  const minutes = values.reduce((a, b) => a + b, 0);
  const bestIndex = values.indexOf(Math.max(...values));
  const blocksDone = days.reduce((sum, date) => sum + tasksForDate(data.tasks, date).filter((t) => isTaskComplete(t, date)).length, 0);
  const bySubject = data.subjects.map((subject) => ({
    name: subject.name, color: subject.color,
    minutes: data.sessions.filter((s) => s.subjectId === subject.id && days.includes(dateFromIso(s.startedAt))).reduce((sum, s) => sum + s.actualMinutes, 0),
  })).filter((s) => s.minutes > 0).sort((a, b) => b.minutes - a.minutes);

  const avoided = subjectProgress(data, today).find((p) => p.avoided);
  const hour = bestStudyHour(data.sessions);
  let recommendation: string;
  if (minutes === 0) recommendation = R.recFirst;
  else if (avoided) recommendation = R.recAvoided(avoided.subject.name);
  else if (minutes / 7 < data.settings.dailyGoalMinutes * 0.6) recommendation = R.recLowFocus(data.settings.dailyGoalMinutes);
  else if (hour) recommendation = R.recBestHour(T.hourRange(hour.hour));
  else recommendation = R.recStrong;

  return {
    rangeStart: days[0], rangeEnd: days[6], minutes, blocksDone, streak: focusStreak(data.sessions, today),
    bestDay: values[bestIndex] > 0 ? { date: days[bestIndex], minutes: values[bestIndex] } : undefined,
    topSubject: bySubject[0], recommendation,
  };
}

export function reportAsText(r: ReportCardData): string {
  return R.textBody({
    minutes: formatDuration(r.minutes), blocks: r.blocksDone, streak: r.streak,
    bestDay: r.bestDay ? `${formatShortDate(r.bestDay.date)} (${formatDuration(r.bestDay.minutes)})` : R.none,
    top: r.topSubject?.name ?? R.none, rec: r.recommendation,
  });
}
