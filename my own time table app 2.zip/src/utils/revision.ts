import { Exam, StudyTask } from '../types';
import { addDays, daysUntil } from './date';
import { occursOn } from './recurrence';

export const REVISION_OFFSETS = [30, 14, 7, 2] as const;

export interface RevisionProposal {
  key: string;
  offset: number;
  date: string;
  startMinute: number;
  durationMinutes: number;
  title: string;
  notes: string;
  include: boolean;
}

const DURATIONS: Record<number, number> = { 30: 60, 14: 60, 7: 90, 2: 45 };

export function revisionTitle(exam: Exam, offset: number): string {
  return `Revision D-${offset}: ${exam.title}`;
}

/**
 * Work backwards from the exam date: D-30, D-14, D-7 and D-2. Past dates are skipped, topics that are not
 * ticked off yet are shared out across the remaining blocks, and blocks that already exist are not duplicated.
 */
export function generateRevisionPlan(exam: Exam, today: string, existing: StudyTask[], startMinute = 17 * 60): RevisionProposal[] {
  const pendingTopics = exam.topics.filter((topic) => !topic.done);
  const offsets = REVISION_OFFSETS.filter((offset) => daysUntil(addDays(exam.date, -offset), today) >= 0 && offset <= daysUntil(exam.date, today));
  const proposals: RevisionProposal[] = [];
  offsets.forEach((offset, index) => {
    const date = addDays(exam.date, -offset);
    const title = revisionTitle(exam, offset);
    const alreadyThere = existing.some((task) => task.examId === exam.id && task.title === title && occursOn(task, date));
    if (alreadyThere) return;
    const isFinal = offset === 2;
    const share = pendingTopics.filter((_, topicIndex) => topicIndex % offsets.length === index).map((topic) => topic.title);
    const notes = isFinal
      ? `Final recap: weakest topics and one timed past paper.${pendingTopics.length ? ` Still open: ${pendingTopics.slice(0, 6).map((t) => t.title).join(', ')}.` : ''}`
      : share.length ? `Cover: ${share.join(', ')}.` : 'Review notes and practise questions.';
    proposals.push({ key: `${exam.id}_D${offset}`, offset, date, startMinute, durationMinutes: DURATIONS[offset] ?? 60, title, notes, include: true });
  });
  return proposals;
}
