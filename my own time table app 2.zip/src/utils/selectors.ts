import { AppData, DailyReview, FocusSession, StudyTask } from '../types';
import { addDays, dateFromIso, todayKey, weekDates } from './date';
import { occursOn } from './recurrence';

export { occursOn };

export function isTaskComplete(task: StudyTask, date: string): boolean {
  return task.completedDates.includes(date);
}

export function tasksForDate(tasks: StudyTask[], date: string): StudyTask[] {
  return tasks.filter((task) => occursOn(task, date)).sort((a, b) => {
    const aTime = a.startMinute ?? 5000;
    const bTime = b.startMinute ?? 5000;
    return aTime - bTime || a.title.localeCompare(b.title);
  });
}

export function sessionsForDate(sessions: FocusSession[], date: string): FocusSession[] {
  return sessions.filter((session) => dateFromIso(session.startedAt) === date);
}

export function focusMinutesForDate(sessions: FocusSession[], date: string): number {
  return sessionsForDate(sessions, date).reduce((sum, session) => sum + session.actualMinutes, 0);
}

export function reviewForDate(reviews: DailyReview[], date: string): DailyReview | undefined {
  return reviews.find((review) => review.date === date);
}

function streakFrom(hasWin: (date: string) => boolean, today: string): number {
  let streak = 0;
  let cursor = today;
  if (!hasWin(cursor)) cursor = addDays(cursor, -1);
  while (hasWin(cursor) && streak < 3660) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

/** Consecutive days with at least one focus session. Today does not break the streak until it ends. */
export function focusStreak(sessions: FocusSession[], today: string = todayKey()): number {
  return streakFrom((date) => focusMinutesForDate(sessions, date) > 0, today);
}

/** Consecutive days with a focus session or a completed block. */
export function completionStreak(data: Pick<AppData, 'tasks' | 'sessions'>, today: string = todayKey()): number {
  return streakFrom((date) => focusMinutesForDate(data.sessions, date) > 0
    || tasksForDate(data.tasks, date).some((task) => isTaskComplete(task, date)), today);
}

export function weekFocusMinutes(data: AppData, anchor: string): number {
  return weekDates(anchor, data.settings.weekStartsMonday).reduce((sum, date) => sum + focusMinutesForDate(data.sessions, date), 0);
}
