-- FocusFlow: complete, re-runnable Supabase backend
-- Run this entire file once in Supabase Dashboard → SQL Editor.
-- One JSONB snapshot keeps setup simple while RLS isolates every account.

create table if not exists public.focusflow_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  constraint focusflow_state_object check (jsonb_typeof(data) = 'object')
);

alter table public.focusflow_state enable row level security;

-- Policies are dropped by name first so this setup can be safely re-run.
drop policy if exists "FocusFlow users can read their own state" on public.focusflow_state;
drop policy if exists "FocusFlow users can insert their own state" on public.focusflow_state;
drop policy if exists "FocusFlow users can update their own state" on public.focusflow_state;
drop policy if exists "FocusFlow users can delete their own state" on public.focusflow_state;

create policy "FocusFlow users can read their own state"
on public.focusflow_state for select
to authenticated
using ((select auth.uid()) = user_id);

create policy "FocusFlow users can insert their own state"
on public.focusflow_state for insert
to authenticated
with check ((select auth.uid()) = user_id);

create policy "FocusFlow users can update their own state"
on public.focusflow_state for update
to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "FocusFlow users can delete their own state"
on public.focusflow_state for delete
to authenticated
using ((select auth.uid()) = user_id);

revoke all on table public.focusflow_state from anon;
grant select, insert, update, delete on table public.focusflow_state to authenticated;

create index if not exists focusflow_state_updated_at_idx
on public.focusflow_state (updated_at desc);

-- Optional verification: run while authenticated in your own project.
-- select user_id, updated_at, jsonb_typeof(data) from public.focusflow_state;
