import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { useTheme } from '../theme';
import { fromDateKey, todayKey, weekDates } from '../utils/date';

export default function WeekStrip({ selected, onSelect, monday = true }: { selected: string; onSelect: (date: string) => void; monday?: boolean }) {
  const theme = useTheme();
  const today = todayKey();
  return (
    <View style={{ flexDirection: 'row', gap: 6, paddingHorizontal: 16, paddingBottom: 14 }}>
      {weekDates(selected, monday).map((date) => {
        const active = date === selected;
        const day = fromDateKey(date);
        return (
          <Pressable key={date} onPress={() => onSelect(date)} style={{
            flex: 1, height: 66, borderRadius: 18, alignItems: 'center', justifyContent: 'center', gap: 5,
            backgroundColor: active ? theme.primary : 'transparent',
          }}>
            <Text style={{ fontSize: 10, fontWeight: '800', color: active ? (theme.dark ? '#102019' : '#E5F2E9') : theme.muted }}>
              {day.toLocaleDateString(undefined, { weekday: 'short' }).slice(0, 3).toUpperCase()}
            </Text>
            <Text style={{ fontSize: 17, fontWeight: '900', color: active ? (theme.dark ? '#102019' : '#FFFFFF') : theme.text }}>{day.getDate()}</Text>
            <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: date === today ? (active ? theme.accent : theme.primary) : 'transparent' }} />
          </Pressable>
        );
      })}
    </View>
  );
}
