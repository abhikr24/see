import React from 'react';
import {
  ActivityIndicator, KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet,
  Text, TextInput, TextInputProps, View, ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from '@expo/vector-icons/Ionicons';
import { radius, useTheme } from '../theme';

export function Screen({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const theme = useTheme();
  return <SafeAreaView edges={['top']} style={[{ flex: 1, backgroundColor: theme.background }, style]}>{children}</SafeAreaView>;
}

export function Header({ title, subtitle, onBack, right, eyebrow }: {
  title: string; subtitle?: string; onBack?: () => void; right?: React.ReactNode; eyebrow?: string;
}) {
  const theme = useTheme();
  return (
    <View style={styles.header}>
      {onBack && <IconButton icon="arrow-back" onPress={onBack} label="Go back" />}
      <View style={{ flex: 1 }}>
        {!!eyebrow && <Text style={[styles.eyebrow, { color: theme.primary }]}>{eyebrow}</Text>}
        <Text style={[styles.headerTitle, { color: theme.text }]}>{title}</Text>
        {!!subtitle && <Text style={[styles.headerSubtitle, { color: theme.muted }]}>{subtitle}</Text>}
      </View>
      {right}
    </View>
  );
}

export function Card({ children, style, onPress }: { children: React.ReactNode; style?: ViewStyle; onPress?: () => void }) {
  const theme = useTheme();
  const cardStyle = [styles.card, { backgroundColor: theme.surface, borderColor: theme.border, shadowColor: theme.shadow }, style];
  if (onPress) return <Pressable onPress={onPress} style={({ pressed }) => [cardStyle, pressed && { opacity: 0.82, transform: [{ scale: 0.995 }] }]}>{children}</Pressable>;
  return <View style={cardStyle}>{children}</View>;
}

export function SectionTitle({ title, action, onAction, icon }: { title: string; action?: string; onAction?: () => void; icon?: keyof typeof Ionicons.glyphMap }) {
  const theme = useTheme();
  return (
    <View style={styles.sectionTitleRow}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        {icon && <Ionicons name={icon} size={18} color={theme.primary} />}
        <Text style={[styles.sectionTitle, { color: theme.text }]}>{title}</Text>
      </View>
      {action && <Pressable onPress={onAction} hitSlop={8}><Text style={[styles.sectionAction, { color: theme.primary }]}>{action}</Text></Pressable>}
    </View>
  );
}

export function Button({ title, onPress, icon, variant = 'primary', loading, disabled, style }: {
  title: string; onPress: () => void; icon?: keyof typeof Ionicons.glyphMap;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'accent'; loading?: boolean; disabled?: boolean; style?: ViewStyle;
}) {
  const theme = useTheme();
  const colors = {
    primary: { bg: theme.primary, text: theme.dark ? '#102019' : '#FFFFFF', border: theme.primary },
    secondary: { bg: theme.primarySoft, text: theme.primary, border: theme.primarySoft },
    ghost: { bg: 'transparent', text: theme.text, border: theme.border },
    danger: { bg: theme.dark ? '#3B2224' : '#FCE8E8', text: theme.danger, border: theme.dark ? '#3B2224' : '#FCE8E8' },
    accent: { bg: theme.accent, text: theme.accentText, border: theme.accent },
  }[variant];
  return (
    <Pressable disabled={disabled || loading} onPress={onPress}
      style={({ pressed }) => [styles.button, { backgroundColor: colors.bg, borderColor: colors.border },
        (disabled || loading) && { opacity: 0.45 }, pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] }, style]}>
      {loading ? <ActivityIndicator color={colors.text} /> : <>
        {icon && <Ionicons name={icon} size={18} color={colors.text} />}
        <Text style={[styles.buttonText, { color: colors.text }]}>{title}</Text>
      </>}
    </Pressable>
  );
}

export function IconButton({ icon, onPress, label, color, size = 20, filled = false }: {
  icon: keyof typeof Ionicons.glyphMap; onPress: () => void; label: string; color?: string; size?: number; filled?: boolean;
}) {
  const theme = useTheme();
  return (
    <Pressable accessibilityLabel={label} onPress={onPress} hitSlop={6}
      style={({ pressed }) => [styles.iconButton, filled && { backgroundColor: theme.surfaceAlt }, pressed && { opacity: 0.55 }]}>
      <Ionicons name={icon} size={size} color={color || theme.text} />
    </Pressable>
  );
}

export function Chip({ label, selected, onPress, icon, color }: {
  label: string; selected?: boolean; onPress?: () => void; icon?: keyof typeof Ionicons.glyphMap; color?: string;
}) {
  const theme = useTheme();
  const activeColor = color || theme.primary;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.chip, {
      backgroundColor: selected ? activeColor : theme.surfaceAlt,
      borderColor: selected ? activeColor : theme.border,
    }, pressed && { opacity: 0.7 }]}>
      {icon && <Ionicons name={icon} size={14} color={selected ? (theme.dark ? '#102019' : '#FFF') : theme.muted} />}
      <Text style={[styles.chipText, { color: selected ? (theme.dark ? '#102019' : '#FFF') : theme.muted }]}>{label}</Text>
    </Pressable>
  );
}

export function ProgressBar({ value, max = 100, color, height = 8 }: { value: number; max?: number; color?: string; height?: number }) {
  const theme = useTheme();
  const percentage = Math.max(0, Math.min(100, max ? (value / max) * 100 : 0));
  return (
    <View style={{ height, backgroundColor: theme.surfaceAlt, borderRadius: height, overflow: 'hidden' }}>
      <View style={{ width: `${percentage}%`, height: '100%', backgroundColor: color || theme.primary, borderRadius: height }} />
    </View>
  );
}

export function Field({ label, hint, style, ...props }: TextInputProps & { label?: string; hint?: string }) {
  const theme = useTheme();
  return (
    <View style={{ gap: 7 }}>
      {!!label && <Text style={[styles.fieldLabel, { color: theme.text }]}>{label}</Text>}
      <TextInput placeholderTextColor={theme.faint} {...props}
        style={[styles.input, { backgroundColor: theme.surfaceAlt, color: theme.text, borderColor: theme.border },
          props.multiline && { minHeight: 96, textAlignVertical: 'top', paddingTop: 13 }, style]} />
      {!!hint && <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 17 }}>{hint}</Text>}
    </View>
  );
}

export function Segmented<T extends string>({ value, options, onChange }: {
  value: T; options: { value: T; label: string; icon?: keyof typeof Ionicons.glyphMap }[]; onChange: (value: T) => void;
}) {
  const theme = useTheme();
  return (
    <View style={[styles.segmented, { backgroundColor: theme.surfaceAlt }]}>
      {options.map((option) => {
        const selected = value === option.value;
        return <Pressable key={option.value} onPress={() => onChange(option.value)}
          style={[styles.segment, selected && { backgroundColor: theme.surface, shadowColor: theme.shadow }]}>
          {option.icon && <Ionicons name={option.icon} size={15} color={selected ? theme.primary : theme.muted} />}
          <Text style={{ color: selected ? theme.text : theme.muted, fontWeight: '700', fontSize: 13 }}>{option.label}</Text>
        </Pressable>;
      })}
    </View>
  );
}

export function SheetModal({ visible, onClose, title, children, full = false }: {
  visible: boolean; onClose: () => void; title: string; children: React.ReactNode; full?: boolean;
}) {
  const theme = useTheme();
  return (
    <Modal visible={visible} animationType="slide" presentationStyle={full ? 'fullScreen' : 'pageSheet'} onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: theme.background }}>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <View style={[styles.sheetHeader, { borderBottomColor: theme.border }]}>
            <Text style={[styles.sheetTitle, { color: theme.text }]}>{title}</Text>
            <IconButton icon="close" onPress={onClose} label="Close" filled />
          </View>
          {children}
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}

export function EmptyState({ icon, title, message, action, onAction }: {
  icon: keyof typeof Ionicons.glyphMap; title: string; message: string; action?: string; onAction?: () => void;
}) {
  const theme = useTheme();
  return (
    <View style={styles.empty}>
      <View style={[styles.emptyIcon, { backgroundColor: theme.primarySoft }]}><Ionicons name={icon} size={30} color={theme.primary} /></View>
      <Text style={[styles.emptyTitle, { color: theme.text }]}>{title}</Text>
      <Text style={[styles.emptyMessage, { color: theme.muted }]}>{message}</Text>
      {action && <Button title={action} onPress={onAction || (() => undefined)} variant="secondary" />}
    </View>
  );
}

export function Divider() {
  const theme = useTheme();
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: theme.border, marginVertical: 14 }} />;
}

export function Badge({ text, color }: { text: string; color?: string }) {
  const theme = useTheme();
  const tint = color || theme.primary;
  return <View style={{ backgroundColor: `${tint}20`, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 20 }}>
    <Text style={{ color: tint, fontSize: 11, fontWeight: '800' }}>{text}</Text>
  </View>;
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 16, flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 82 },
  eyebrow: { fontSize: 11, fontWeight: '900', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 3 },
  headerTitle: { fontSize: 29, fontWeight: '900', letterSpacing: -0.8 },
  headerSubtitle: { fontSize: 13, marginTop: 4, lineHeight: 18 },
  card: { borderRadius: radius.lg, borderWidth: 1, padding: 17, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.04, shadowRadius: 12, elevation: 1 },
  sectionTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, marginTop: 4 },
  sectionTitle: { fontSize: 17, fontWeight: '800', letterSpacing: -0.25 },
  sectionAction: { fontSize: 13, fontWeight: '800' },
  button: { minHeight: 48, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18, gap: 8 },
  buttonText: { fontWeight: '800', fontSize: 14 },
  iconButton: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  chip: { borderRadius: 20, paddingHorizontal: 13, paddingVertical: 8, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 5 },
  chipText: { fontSize: 12, fontWeight: '700' },
  fieldLabel: { fontSize: 13, fontWeight: '800' },
  input: { borderRadius: 13, borderWidth: 1, minHeight: 48, paddingHorizontal: 14, paddingVertical: 11, fontSize: 15 },
  segmented: { borderRadius: 13, padding: 4, flexDirection: 'row', gap: 3 },
  segment: { flex: 1, minHeight: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 5, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1 },
  sheetTitle: { fontSize: 21, fontWeight: '900', letterSpacing: -0.4 },
  empty: { alignItems: 'center', padding: 30, gap: 10 },
  emptyIcon: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  emptyTitle: { fontSize: 18, fontWeight: '800' },
  emptyMessage: { fontSize: 14, lineHeight: 20, textAlign: 'center', maxWidth: 300 },
});
