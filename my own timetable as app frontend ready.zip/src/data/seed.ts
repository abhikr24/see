import { AppData, DailyReview, FocusSession, StudyTask, Subject } from '../types';
import { addDays, makeId, todayKey } from '../utils/date';

const colors = ['#5D8F7B', '#7C83C5', '#E49264', '#B87591'];

export function createSeedData(): AppData {
  const now = new Date().toISOString();
  const today = todayKey();
  const subjects: Subject[] = ['Mathematics', 'Physics', 'Computer Science', 'English'].map((name, index) => ({
    id: `subject_${index + 1}`,
    name,
    color: colors[index],
    icon: ['calculator', 'planet', 'code-slash', 'book'][index],
    weeklyGoalMinutes: [300, 240, 300, 120][index],
    archived: false,
    createdAt: now,
  }));

  const task = (
    id: string,
    title: string,
    dayOffset: number,
    subjectId: string,
    startMinute: number | undefined,
    durationMinutes: number,
    priority: StudyTask['priority'] = 'medium',
    top = false,
    completed = false,
  ): StudyTask => {
    const date = addDays(today, dayOffset);
    return {
      id, title, notes: '', subjectId, date, startMinute, durationMinutes,
      estimatedPomodoros: Math.max(1, Math.round(durationMinutes / 25)), priority,
      recurrence: 'none', completedDates: completed ? [date] : [],
      topThreeDates: top ? [date] : [], createdAt: now, updatedAt: now,
    };
  };

  const tasks: StudyTask[] = [
    task('task_1', 'Revise quadratic equations', 0, 'subject_1', 390, 50, 'high', true),
    task('task_2', 'Physics numerical practice', 0, 'subject_2', 540, 50, 'high', true),
    task('task_3', 'Build programming notes', 0, 'subject_3', 990, 60, 'medium', true),
    task('task_4', 'Read and recall: chapter 4', 0, 'subject_4', undefined, 30, 'low'),
    task('task_5', 'Formula flashcard review', 1, 'subject_1', 420, 30, 'medium', true),
    task('task_6', 'Past paper: mechanics', 1, 'subject_2', 600, 90, 'high', true),
    task('task_7', 'Write essay outline', 1, 'subject_4', 1020, 40, 'medium', true),
    task('task_8', 'Algebra problem set', -1, 'subject_1', 480, 50, 'medium', false, true),
    task('task_9', 'Review JavaScript closures', -1, 'subject_3', 960, 50, 'medium', false, true),
    task('task_10', 'Weekly vocabulary recap', 0, 'subject_4', 1200, 20, 'low'),
  ];

  const sessions: FocusSession[] = [];
  const durations = [85, 120, 55, 145, 95, 130, 40];
  for (let offset = -6; offset <= 0; offset += 1) {
    const total = durations[offset + 6];
    const chunks = total > 90 ? [50, total - 50] : [total];
    chunks.forEach((minutes, index) => {
      const start = new Date();
      start.setDate(start.getDate() + offset);
      start.setHours(8 + index * 3, 0, 0, 0);
      const end = new Date(start.getTime() + minutes * 60000);
      sessions.push({
        id: makeId('session'), taskId: offset === 0 ? 'task_1' : undefined,
        subjectId: subjects[(offset + 6 + index) % subjects.length].id,
        startedAt: start.toISOString(), endedAt: end.toISOString(),
        plannedMinutes: minutes, actualMinutes: minutes, completed: true,
        distractions: index === 1 && offset % 2 === 0 ? ['Checked messages'] : [],
      });
    });
  }

  const reviews: DailyReview[] = [-3, -2, -1].map((offset, index) => ({
    date: addDays(today, offset),
    worked: ['Problem practice finally clicked.', 'Consistent morning focus.', 'Finished the difficult chapter.'][index],
    fix: ['Start before checking messages.', 'Shorter blocks after lunch.', 'Prepare materials the night before.'][index],
    gratitude: ['A quiet study space', 'A helpful classmate', 'Making steady progress'][index],
    quickNotes: '', distractionNotes: index === 0 ? 'Messages, noise' : '',
    mood: 4, energy: 3 + (index % 2), water: 6 + index, sleepHours: 7 + index * 0.5,
    steps: 5200 + index * 900, productivity: 3 + (index % 2), updatedAt: now,
  }));

  return {
    tasks, subjects, sessions, reviews,
    exams: [
      { id: 'exam_1', title: 'Mathematics unit test', subjectId: 'subject_1', date: addDays(today, 12), time: '09:00', syllabus: 'Algebra, quadratics, functions', createdAt: now },
      { id: 'exam_2', title: 'Physics midterm', subjectId: 'subject_2', date: addDays(today, 28), time: '10:30', syllabus: 'Mechanics and waves', createdAt: now },
    ],
    settings: {
      name: 'Scholar', focusMinutes: 25, shortBreakMinutes: 5, longBreakMinutes: 15,
      longBreakEvery: 4, dailyGoalMinutes: 120, waterGoal: 8, theme: 'system',
      autoSync: false, weekStartsMonday: true,
    },
    meta: { updatedAt: now, dirty: true },
  };
}
