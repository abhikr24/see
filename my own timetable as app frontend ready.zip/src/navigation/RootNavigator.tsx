import React from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from '@expo/vector-icons/Ionicons';
import { StatusBar } from 'expo-status-bar';
import { RootStackParamList, MainTabParamList } from './types';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import TodayScreen from '../screens/TodayScreen';
import PlannerScreen from '../screens/PlannerScreen';
import FocusScreen from '../screens/FocusScreen';
import ReviewScreen from '../screens/ReviewScreen';
import InsightsScreen from '../screens/InsightsScreen';
import TaskFormScreen from '../screens/TaskFormScreen';
import SettingsScreen from '../screens/SettingsScreen';
import SubjectsScreen from '../screens/SubjectsScreen';
import ExamsScreen from '../screens/ExamsScreen';
import CloudScreen from '../screens/CloudScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

const icons: Record<keyof MainTabParamList, [keyof typeof Ionicons.glyphMap, keyof typeof Ionicons.glyphMap]> = {
  Today: ['home', 'home-outline'],
  Planner: ['calendar', 'calendar-outline'],
  Focus: ['timer', 'timer-outline'],
  Review: ['journal', 'journal-outline'],
  Insights: ['analytics', 'analytics-outline'],
};

function MainTabs() {
  const theme = useTheme();
  return (
    <Tab.Navigator screenOptions={({ route }) => ({
      headerShown: false,
      tabBarActiveTintColor: theme.primary,
      tabBarInactiveTintColor: theme.faint,
      tabBarLabelStyle: { fontSize: 10, fontWeight: '800', marginTop: 2 },
      tabBarStyle: { backgroundColor: theme.surface, borderTopColor: theme.border, paddingTop: 5, minHeight: 60 },
      tabBarIcon: ({ focused, color, size }) => <Ionicons name={icons[route.name][focused ? 0 : 1]} size={size} color={color} />,
    })}>
      <Tab.Screen name="Today" component={TodayScreen} />
      <Tab.Screen name="Planner" component={PlannerScreen} options={{ title: 'Plan' }} />
      <Tab.Screen name="Focus" component={FocusScreen} />
      <Tab.Screen name="Review" component={ReviewScreen} />
      <Tab.Screen name="Insights" component={InsightsScreen} options={{ title: 'Progress' }} />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  const theme = useTheme();
  const { hydrated } = useApp();
  if (!hydrated) {
    return <View style={{ flex: 1, backgroundColor: theme.background, alignItems: 'center', justifyContent: 'center', gap: 16 }}>
      <View style={{ width: 72, height: 72, borderRadius: 24, backgroundColor: theme.primary, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="leaf" size={36} color={theme.dark ? '#102019' : '#FFFFFF'} /></View>
      <Text style={{ color: theme.text, fontSize: 25, fontWeight: '900' }}>FocusFlow</Text>
      <ActivityIndicator color={theme.primary} />
    </View>;
  }
  const navigationTheme = {
    ...(theme.dark ? DarkTheme : DefaultTheme),
    colors: {
      ...(theme.dark ? DarkTheme.colors : DefaultTheme.colors),
      primary: theme.primary, background: theme.background, card: theme.surface,
      text: theme.text, border: theme.border, notification: theme.warning,
    },
  };
  return (
    <NavigationContainer theme={navigationTheme}>
      <StatusBar style={theme.dark ? 'light' : 'dark'} />
      <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: theme.background } }}>
        <Stack.Screen name="Main" component={MainTabs} />
        <Stack.Screen name="TaskForm" component={TaskFormScreen} options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="Subjects" component={SubjectsScreen} options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="Exams" component={ExamsScreen} options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="Cloud" component={CloudScreen} options={{ animation: 'slide_from_bottom', presentation: 'modal' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
