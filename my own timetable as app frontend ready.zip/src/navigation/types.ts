export type RootStackParamList = {
  Main: undefined;
  TaskForm: { taskId?: string; date?: string; startMinute?: number } | undefined;
  Settings: undefined;
  Subjects: undefined;
  Exams: undefined;
  Cloud: undefined;
};

export type MainTabParamList = {
  Today: undefined;
  Planner: undefined;
  Focus: undefined;
  Review: undefined;
  Insights: undefined;
};
