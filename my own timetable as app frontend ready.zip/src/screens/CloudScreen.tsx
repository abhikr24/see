import React, { useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, Switch, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { getSupabase, hasEnvironmentConfig, hasSavedConfig, saveSupabaseConfig } from '../lib/supabase';
import { SyncStrategy } from '../types';
import { Badge, Button, Card, Divider, Field, Header, Screen, SectionTitle } from '../components/ui';

export default function CloudScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, updateSettings, syncCloud, syncStatus, syncMessage } = useApp();
  const [configured, setConfigured] = useState(false);
  const [editingConfig, setEditingConfig] = useState(false);
  const [url, setUrl] = useState('');
  const [anonKey, setAnonKey] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [accountEmail, setAccountEmail] = useState('');
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    let unsubscribe: () => void = () => undefined;
    let mounted = true;
    (async () => {
      const isConfigured = await hasSavedConfig();
      if (!mounted) return;
      setConfigured(isConfigured);
      if (isConfigured) {
        const supabase = await getSupabase();
        const { data: sessionData } = await supabase!.auth.getSession();
        if (mounted) setAccountEmail(sessionData.session?.user.email || '');
        const { data: listener } = supabase!.auth.onAuthStateChange((_event, session) => {
          if (mounted) setAccountEmail(session?.user.email || '');
        });
        unsubscribe = () => listener.subscription.unsubscribe();
      }
      if (mounted) setLoading(false);
    })().catch((error) => { if (mounted) { setMessage(error.message || 'Could not initialize Supabase.'); setLoading(false); } });
    return () => { mounted = false; unsubscribe(); };
  }, []);

  const saveConfig = async () => {
    setLoading(true); setMessage('');
    try {
      await saveSupabaseConfig(url, anonKey);
      setConfigured(true); setEditingConfig(false); setUrl(''); setAnonKey('');
      setMessage('Connection saved securely. Now sign in or create your account.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Invalid Supabase configuration.'); }
    finally { setLoading(false); }
  };

  const authenticate = async () => {
    if (!email.trim() || password.length < 6) { setMessage('Enter your email and a password of at least 6 characters.'); return; }
    setLoading(true); setMessage('');
    try {
      const supabase = await getSupabase();
      if (!supabase) throw new Error('Save your project connection first.');
      if (mode === 'signin') {
        const { data: result, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        setAccountEmail(result.user.email || email.trim());
        setMessage('Signed in. You can sync now.');
      } else {
        const { data: result, error } = await supabase.auth.signUp({ email: email.trim(), password });
        if (error) throw error;
        if (result.session) setAccountEmail(result.user?.email || email.trim());
        setMessage(result.session ? 'Account created. You can sync now.' : 'Account created. Confirm the email from Supabase, then return and sign in.');
        if (!result.session) setMode('signin');
      }
      setPassword('');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Authentication failed.'); }
    finally { setLoading(false); }
  };

  const runSync = async (strategy: SyncStrategy) => {
    setLoading(true); setMessage('');
    try { setMessage(await syncCloud(strategy)); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Sync failed.'); }
    finally { setLoading(false); }
  };
  const confirmSync = (strategy: 'upload' | 'download') => {
    const upload = strategy === 'upload';
    Alert.alert(upload ? 'Upload this device?' : 'Download cloud version?', upload ? 'This device will replace the cloud copy for your account.' : 'Local planner data will be replaced by your cloud copy. The timer is not affected.', [
      { text: 'Cancel', style: 'cancel' }, { text: upload ? 'Upload' : 'Download', style: upload ? 'default' : 'destructive', onPress: () => runSync(strategy) },
    ]);
  };
  const signOut = async () => {
    const supabase = await getSupabase();
    await supabase?.auth.signOut();
    setAccountEmail(''); setMessage('Signed out. Your local planner is unchanged.');
  };

  return (
    <Screen>
      <Header title="Supabase sync" subtitle="Optional, secure, and ready in about five minutes." onBack={navigation.goBack}
        right={<Badge text={hasEnvironmentConfig() ? 'ENV CONFIG' : configured ? 'CONNECTED' : 'NOT SET UP'} />} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 16 }}>
        <Card style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent', flexDirection: 'row', alignItems: 'center', gap: 13 }}>
          <View style={{ width: 48, height: 48, borderRadius: 16, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="cloud-done-outline" size={26} color={theme.primary} /></View>
          <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{accountEmail ? 'Cloud account connected' : 'Offline first. Cloud when ready.'}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, marginTop: 3 }}>{accountEmail || 'You can use every planner feature without signing in.'}</Text></View>
        </Card>

        {(!configured || editingConfig) ? <Card style={{ gap: 14 }}>
          <SectionTitle title="1. Connect your project" icon="link-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 20 }}>Create a free Supabase project, run <Text style={{ color: theme.text, fontWeight: '800' }}>supabase/schema.sql</Text> in its SQL Editor, then paste Project Settings → API values here.</Text>
          <Field label="Project URL" value={url} onChangeText={setUrl} placeholder="https://your-project.supabase.co" autoCapitalize="none" autoCorrect={false} keyboardType="url" />
          <Field label="Anon public key" value={anonKey} onChangeText={setAnonKey} placeholder="eyJhbGciOiJIUzI1NiIs…" autoCapitalize="none" autoCorrect={false} multiline hint="Use only the anon public key. Never put a service_role key in the app." />
          <Button title="Save & continue" icon="shield-checkmark-outline" loading={loading} onPress={saveConfig} />
          {configured && <Button title="Cancel" variant="ghost" onPress={() => setEditingConfig(false)} />}
        </Card> : !accountEmail ? <Card style={{ gap: 14 }}>
          <SectionTitle title="2. Your sync account" icon="person-outline" />
          <View style={{ flexDirection: 'row', gap: 8 }}><Button title="Sign in" variant={mode === 'signin' ? 'secondary' : 'ghost'} style={{ flex: 1 }} onPress={() => setMode('signin')} /><Button title="Create account" variant={mode === 'signup' ? 'secondary' : 'ghost'} style={{ flex: 1 }} onPress={() => setMode('signup')} /></View>
          <Field label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address" autoCapitalize="none" autoCorrect={false} />
          <Field label="Password" value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry autoCapitalize="none" />
          <Button title={mode === 'signin' ? 'Sign in securely' : 'Create sync account'} icon="lock-closed-outline" loading={loading} onPress={authenticate} />
          {!hasEnvironmentConfig() && <Pressable onPress={() => setEditingConfig(true)}><Text style={{ color: theme.primary, fontSize: 12, textAlign: 'center', fontWeight: '700' }}>Update project URL or anon key</Text></Pressable>}
        </Card> : <>
          <Card style={{ gap: 14 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><SectionTitle title="3. Sync your planner" icon="sync-outline" /><Badge text={syncStatus.toUpperCase()} color={syncStatus === 'error' ? theme.danger : theme.primary} /></View>
            <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 20 }}>Smart sync compares timestamps and keeps the newest version. Force upload or download when you want to choose a specific copy.</Text>
            <Button title="Sync now" icon="sync" loading={loading && syncStatus === 'syncing'} onPress={() => runSync('sync')} />
            <View style={{ flexDirection: 'row', gap: 9 }}><Button title="Upload" variant="ghost" style={{ flex: 1 }} onPress={() => confirmSync('upload')} /><Button title="Download" variant="ghost" style={{ flex: 1 }} onPress={() => confirmSync('download')} /></View>
            <Divider />
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}><View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>Auto-sync changes</Text><Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>Syncs 12 seconds after you stop editing</Text></View>
              <Switch value={data.settings.autoSync} onValueChange={(autoSync) => updateSettings({ autoSync })} trackColor={{ false: theme.border, true: theme.primary }} thumbColor={theme.surface} /></View>
            <Button title="Sign out" variant="ghost" onPress={signOut} />
          </Card>
          <Card>
            <SectionTitle title="Sync status" icon="information-circle-outline" />
            <Text style={{ color: syncStatus === 'error' ? theme.danger : theme.text, fontSize: 13, lineHeight: 20 }}>{message || syncMessage}</Text>
            <Divider />
            <View style={{ gap: 8 }}><Text style={{ color: theme.muted, fontSize: 12 }}>Local changes: <Text style={{ color: theme.text, fontWeight: '800' }}>{data.meta.dirty ? 'Waiting to sync' : 'All synced'}</Text></Text>
              <Text style={{ color: theme.muted, fontSize: 12 }}>Last synced: <Text style={{ color: theme.text, fontWeight: '800' }}>{data.meta.lastSyncedAt ? new Date(data.meta.lastSyncedAt).toLocaleString() : 'Never'}</Text></Text></View>
          </Card>
        </>}

        {!!message && (configured && !accountEmail || editingConfig) && <Card style={{ borderColor: message.toLowerCase().includes('invalid') || message.toLowerCase().includes('failed') ? theme.danger : theme.border }}><Text style={{ color: theme.text, lineHeight: 20 }}>{message}</Text></Card>}
        <Card style={{ gap: 10 }}>
          <SectionTitle title="What is protected?" icon="shield-checkmark-outline" />
          {['Each account can only read and write its own planner.', 'Row Level Security policies are included in schema.sql.', 'Tasks, sessions, reviews, subjects, exams, and settings sync together.', 'Your timer and login session remain on the device.'].map((item) => <View key={item} style={{ flexDirection: 'row', gap: 9 }}><Ionicons name="checkmark-circle" color={theme.primary} size={17} /><Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, flex: 1 }}>{item}</Text></View>)}
        </Card>
      </ScrollView>
    </Screen>
  );
}
