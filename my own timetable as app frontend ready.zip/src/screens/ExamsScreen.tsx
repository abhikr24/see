import React, { useState } from 'react';
import { Alert, FlatList, ScrollView, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { Exam } from '../types';
import { addDays, daysUntil, formatLongDate, isValidDateKey, makeId, todayKey } from '../utils/date';
import { isTaskComplete } from '../utils/selectors';
import { Badge, Button, Card, Chip, Divider, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, SheetModal } from '../components/ui';

export default function ExamsScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, saveExam, deleteExam } = useApp();
  const [editing, setEditing] = useState<Exam | null>(null);
  const [modal, setModal] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(addDays(todayKey(), 14));
  const [time, setTime] = useState('09:00');
  const [subjectId, setSubjectId] = useState<string | undefined>();
  const [syllabus, setSyllabus] = useState('');
  const [error, setError] = useState('');

  const open = (exam?: Exam) => {
    setEditing(exam || null); setTitle(exam?.title || ''); setDate(exam?.date || addDays(todayKey(), 14));
    setTime(exam?.time || '09:00'); setSubjectId(exam?.subjectId || data.subjects.find((item) => !item.archived)?.id);
    setSyllabus(exam?.syllabus || ''); setError(''); setModal(true);
  };
  const save = () => {
    if (!title.trim()) { setError('Enter an exam name.'); return; }
    if (!isValidDateKey(date)) { setError('Enter a valid YYYY-MM-DD date.'); return; }
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) { setError('Enter time in 24-hour HH:MM format.'); return; }
    saveExam({ id: editing?.id || makeId('exam'), title: title.trim(), date, time, subjectId, syllabus: syllabus.trim(), createdAt: editing?.createdAt || new Date().toISOString() });
    setModal(false);
  };
  const remove = (exam: Exam) => Alert.alert('Delete exam?', exam.title, [{ text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: () => deleteExam(exam.id) }]);
  const sorted = [...data.exams].sort((a, b) => a.date.localeCompare(b.date));

  return (
    <Screen>
      <Header title="Exam countdowns" subtitle="See what is coming and revise before the rush." onBack={navigation.goBack} right={<IconButton icon="add" label="Add exam" filled onPress={() => open()} />} />
      <FlatList data={sorted} keyExtractor={(item) => item.id} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 35, gap: 12 }}
        renderItem={({ item }) => {
          const subject = data.subjects.find((entry) => entry.id === item.subjectId);
          const days = daysUntil(item.date);
          const subjectTasks = data.tasks.filter((task) => task.subjectId === item.subjectId && task.date <= item.date);
          const readiness = subjectTasks.length ? Math.round((subjectTasks.filter((task) => task.completedDates.length > 0).length / subjectTasks.length) * 100) : 0;
          return <Card onPress={() => open(item)} style={{ borderTopWidth: 4, borderTopColor: subject?.color || theme.primary }}>
            <View style={{ flexDirection: 'row', gap: 14, alignItems: 'center' }}>
              <View style={{ width: 66, height: 70, borderRadius: 18, backgroundColor: days < 0 ? theme.surfaceAlt : theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: days < 0 ? theme.muted : theme.primary, fontSize: 27, fontWeight: '900' }}>{Math.abs(days)}</Text>
                <Text style={{ color: theme.muted, fontSize: 10, fontWeight: '800' }}>{days < 0 ? 'DAYS AGO' : days === 0 ? 'TODAY' : 'DAYS LEFT'}</Text>
              </View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>{item.title}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 5 }}>{formatLongDate(item.date)}</Text>
                <View style={{ flexDirection: 'row', gap: 7, marginTop: 8 }}><Badge text={item.time} color={subject?.color} />{subject && <Badge text={subject.name.toUpperCase()} color={subject.color} />}</View>
              </View>
              <IconButton icon="trash-outline" label="Delete exam" color={theme.danger} onPress={() => remove(item)} />
            </View>
            {!!item.syllabus && <><Divider /><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>SYLLABUS</Text><Text style={{ color: theme.text, fontSize: 13, lineHeight: 20, marginTop: 5 }}>{item.syllabus}</Text></>}
            <Divider />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}><Text style={{ color: theme.muted, fontSize: 12 }}>Related task completion</Text><Text style={{ color: theme.text, fontSize: 12, fontWeight: '800' }}>{readiness}%</Text></View>
            <ProgressBar value={readiness} color={subject?.color || theme.primary} />
          </Card>;
        }}
        ListEmptyComponent={<EmptyState icon="school-outline" title="No exams on the horizon" message="Add a date and syllabus to turn revision into a visible countdown." action="Add exam" onAction={() => open()} />}
      />
      <SheetModal visible={modal} onClose={() => setModal(false)} title={editing ? 'Edit exam' : 'New exam'}>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20, gap: 18 }}>
          <Field label="Exam name" value={title} onChangeText={(text) => { setTitle(text); setError(''); }} placeholder="e.g. Biology final" autoFocus />
          <Card style={{ gap: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><IconButton icon="chevron-back" label="Previous day" filled onPress={() => setDate(addDays(date, -1))} />
              <View style={{ alignItems: 'center' }}><Text style={{ color: theme.text, fontWeight: '800' }}>{formatLongDate(date)}</Text><Text style={{ color: theme.primary, fontSize: 12, marginTop: 3 }}>{daysUntil(date)} days away</Text></View>
              <IconButton icon="chevron-forward" label="Next day" filled onPress={() => setDate(addDays(date, 1))} /></View>
            <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} autoCorrect={false} />
            <Field label="Start time (24-hour)" value={time} onChangeText={setTime} placeholder="09:00" keyboardType="numbers-and-punctuation" />
          </Card>
          <View><SectionTitle title="Subject" /><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {data.subjects.filter((item) => !item.archived).map((subject) => <Chip key={subject.id} label={subject.name} selected={subject.id === subjectId} color={subject.color} onPress={() => setSubjectId(subject.id)} />)}
            <Chip label="No subject" selected={!subjectId} onPress={() => setSubjectId(undefined)} />
          </ScrollView></View>
          <Field label="Syllabus / topics" value={syllabus} onChangeText={setSyllabus} multiline placeholder="Chapters, units, formulas, and topics to cover…" />
          {!!error && <Text style={{ color: theme.danger }}>{error}</Text>}
          <Button title="Save exam" icon="checkmark" onPress={save} />
        </ScrollView>
      </SheetModal>
    </Screen>
  );
}
