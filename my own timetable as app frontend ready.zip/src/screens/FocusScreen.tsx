import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { formatDuration, formatTime, todayKey } from '../utils/date';
import { focusMinutesForDate, isTaskComplete, sessionsForDate, tasksForDate } from '../utils/selectors';
import { Badge, Button, Card, Chip, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, SheetModal } from '../components/ui';

export default function FocusScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, timer, startFocus, startBreak, pauseTimer, resumeTimer, resetTimer, finishTimer, addDistraction } = useApp();
  const [now, setNow] = useState(Date.now());
  const [selectedTaskId, setSelectedTaskId] = useState<string | undefined>();
  const [taskPicker, setTaskPicker] = useState(false);
  const [distractionOpen, setDistractionOpen] = useState(false);
  const [distraction, setDistraction] = useState('');
  const [endedEarly, setEndedEarly] = useState(false);
  const completionHandled = useRef(false);
  const remaining = timer.isRunning && timer.endAt ? Math.max(0, Math.ceil((timer.endAt - now) / 1000)) : timer.remainingSeconds;
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const elapsed = timer.durationSeconds - remaining;
  const activeTaskId = timer.taskId || selectedTaskId;
  const activeTask = data.tasks.find((task) => task.id === activeTaskId);
  const activeSubject = data.subjects.find((subject) => subject.id === (timer.subjectId || activeTask?.subjectId));
  const todayTasks = useMemo(() => tasksForDate(data.tasks, todayKey()).filter((task) => !isTaskComplete(task, todayKey())), [data.tasks]);
  const todaySessions = sessionsForDate(data.sessions, todayKey());
  const focusedToday = focusMinutesForDate(data.sessions, todayKey());
  const completedVisible = Boolean(timer.startedAt && remaining === 0 && !timer.isRunning);
  const isBreak = timer.mode !== 'focus';

  useEffect(() => {
    if (!timer.isRunning) return;
    setNow(Date.now());
    const interval = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(interval);
  }, [timer.isRunning, timer.endAt]);

  useEffect(() => {
    if (timer.isRunning) {
      completionHandled.current = false;
      setEndedEarly(false);
    }
    if (timer.isRunning && remaining <= 0 && !completionHandled.current) {
      completionHandled.current = true;
      finishTimer(false);
    }
  }, [remaining, timer.isRunning, finishTimer]);

  const begin = () => {
    setEndedEarly(false);
    startFocus(selectedTaskId, activeTask?.subjectId, timer.cycle);
  };
  const reset = () => {
    if (timer.isRunning && elapsed > 30) {
      Alert.alert('Discard this session?', 'Elapsed focus time will not be added to your stats.', [
        { text: 'Keep focusing', style: 'cancel' }, { text: 'Discard', style: 'destructive', onPress: resetTimer },
      ]);
    } else resetTimer();
  };
  const parkDistraction = () => {
    if (!distraction.trim()) return;
    addDistraction(distraction);
    setDistraction('');
  };
  const nextMode = (timer.cycle + 1) % data.settings.longBreakEvery === 0 ? 'longBreak' : 'shortBreak';

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ paddingBottom: 32 }} showsVerticalScrollIndicator={false}>
        <Header title="Focus room" subtitle="One thing. One timer. Nothing else."
          right={<IconButton icon="options-outline" label="Timer settings" filled onPress={() => navigation.navigate('Settings')} />} />
        <View style={{ paddingHorizontal: 20, gap: 18 }}>
          <View style={{ alignItems: 'center' }}>
            <View style={{ flexDirection: 'row', gap: 7, marginBottom: 18 }}>
              {Array.from({ length: data.settings.longBreakEvery }, (_, index) => <View key={index} style={{
                width: 28, height: 5, borderRadius: 4, backgroundColor: index < timer.cycle % data.settings.longBreakEvery ? theme.primary : theme.border,
              }} />)}
            </View>
            <View style={{ width: 270, height: 270, borderRadius: 135, backgroundColor: theme.surfaceAlt, alignItems: 'center', justifyContent: 'center',
              borderWidth: 1, borderColor: theme.border }}>
              <View style={{ width: 246, height: 246, borderRadius: 123, borderWidth: timer.isRunning ? 7 : 3,
                borderColor: isBreak ? theme.warning : theme.primary, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.surface }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name={isBreak ? 'cafe-outline' : 'leaf-outline'} size={15} color={isBreak ? theme.warning : theme.primary} />
                  <Text style={{ color: isBreak ? theme.warning : theme.primary, fontSize: 11, fontWeight: '900', letterSpacing: 1.2 }}>
                    {timer.mode === 'focus' ? 'DEEP FOCUS' : timer.mode === 'longBreak' ? 'LONG BREAK' : 'SHORT BREAK'}
                  </Text>
                </View>
                <Text style={{ color: theme.text, fontSize: 59, fontWeight: '900', letterSpacing: -3, fontVariant: ['tabular-nums'], marginTop: 7 }}>
                  {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                </Text>
                <Text style={{ color: theme.muted, fontSize: 13 }}>{timer.isRunning ? 'Stay with it' : remaining === 0 ? 'Well done' : 'Ready when you are'}</Text>
                {timer.isRunning && <View style={{ width: 110, marginTop: 17 }}><ProgressBar value={elapsed} max={timer.durationSeconds} height={5} color={isBreak ? theme.warning : theme.primary} /></View>}
              </View>
            </View>
          </View>

          {!isBreak && <Pressable onPress={() => {
            if (timer.startedAt && (timer.isRunning || remaining > 0)) Alert.alert('Session in progress', 'Finish or discard the current session before switching tasks.');
            else setTaskPicker(true);
          }}>
            <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 }}>
              <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: activeSubject?.color || theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={(activeSubject?.icon || 'book-outline') as any} size={20} color={activeSubject ? '#FFFFFF' : theme.primary} />
              </View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>FOCUSING ON</Text>
                <Text numberOfLines={1} style={{ color: theme.text, fontWeight: '800', marginTop: 3 }}>{activeTask?.title || 'Choose a study block'}</Text></View>
              <Ionicons name="chevron-down" size={18} color={theme.muted} />
            </Card>
          </Pressable>}

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button title={timer.isRunning ? 'Pause' : timer.startedAt && remaining > 0 ? 'Resume' : 'Begin focus'}
              icon={timer.isRunning ? 'pause' : 'play'} style={{ flex: 1 }} variant={isBreak ? 'accent' : 'primary'}
              onPress={timer.isRunning ? pauseTimer : timer.startedAt && remaining > 0 ? resumeTimer : isBreak ? () => startBreak(timer.mode === 'longBreak' ? 'longBreak' : 'shortBreak', timer.cycle) : begin} />
            {(timer.startedAt || remaining !== data.settings.focusMinutes * 60) && <IconButton icon="refresh" label="Reset timer" filled onPress={reset} />}
          </View>
          {timer.mode === 'focus' && timer.startedAt && remaining > 0 && <Button title="End & save session" icon="checkmark" variant="ghost"
            onPress={() => {
              if (elapsed < 30) Alert.alert('Keep going a little longer', 'Sessions shorter than 30 seconds are not added to your stats.');
              else { setEndedEarly(true); finishTimer(true); }
            }} />}

          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Card style={{ flex: 1, padding: 14 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>TODAY</Text>
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 6 }}>{formatDuration(focusedToday)}</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>{todaySessions.length} sessions</Text></Card>
            <Card style={{ flex: 1, padding: 14 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>GOAL</Text>
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 6 }}>{Math.round((focusedToday / data.settings.dailyGoalMinutes) * 100)}%</Text>
              <View style={{ marginTop: 8 }}><ProgressBar value={focusedToday} max={data.settings.dailyGoalMinutes} height={5} /></View></Card>
          </View>

          <Card onPress={() => timer.startedAt ? setDistractionOpen(true) : Alert.alert('Start a session first', 'Distraction parking helps you return to focus without following every thought.')}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <Ionicons name="car-outline" size={25} color={theme.primary} />
            <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>Distraction parking</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>Park the thought. Handle it after the bell.</Text></View>
            <Badge text={`${timer.distractions.length}`} />
          </Card>
          <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center', lineHeight: 18 }}>Your timer uses an absolute end time, so it stays accurate when you switch apps.</Text>
        </View>
      </ScrollView>

      <SheetModal visible={taskPicker} onClose={() => setTaskPicker(false)} title="Choose your one thing">
        <FlatList data={todayTasks} keyExtractor={(item) => item.id} contentContainerStyle={{ padding: 20, gap: 10 }}
          ListHeaderComponent={<Pressable onPress={() => { setSelectedTaskId(undefined); setTaskPicker(false); }}>
            <Card style={{ borderColor: !selectedTaskId ? theme.primary : theme.border }}><Text style={{ color: theme.text, fontWeight: '800' }}>Unassigned focus</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>For reading, revision, or a quick capture-free session.</Text></Card>
          </Pressable>}
          renderItem={({ item }) => {
            const subject = data.subjects.find((entry) => entry.id === item.subjectId);
            return <Card onPress={() => { setSelectedTaskId(item.id); setTaskPicker(false); }} style={{ borderColor: selectedTaskId === item.id ? theme.primary : theme.border }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}><View style={{ width: 9, height: 36, borderRadius: 6, backgroundColor: subject?.color || theme.border }} />
                <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>{item.title}</Text>
                  <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{subject?.name || 'No subject'} · {item.durationMinutes}m planned{item.startMinute !== undefined ? ` · ${formatTime(item.startMinute)}` : ''}</Text></View>
                {selectedTaskId === item.id && <Ionicons name="checkmark-circle" color={theme.primary} size={22} />}</View>
            </Card>;
          }}
          ListEmptyComponent={<EmptyState icon="clipboard-outline" title="No open study blocks" message="Add a task in Planner, or choose unassigned focus." />}
        />
      </SheetModal>

      <SheetModal visible={distractionOpen} onClose={() => setDistractionOpen(false)} title="Park it for later">
        <View style={{ padding: 20, gap: 16 }}>
          <Text style={{ color: theme.muted, lineHeight: 20 }}>Write the thought down without acting on it. It will be attached to this session for your evening review.</Text>
          <Field value={distraction} onChangeText={setDistraction} placeholder="e.g. Reply to Sam’s message" autoFocus returnKeyType="done" onSubmitEditing={parkDistraction} />
          <Button title="Park distraction" icon="add" onPress={parkDistraction} disabled={!distraction.trim()} />
          {timer.distractions.map((item, index) => <Card key={`${item}_${index}`} style={{ padding: 13, flexDirection: 'row', gap: 9, alignItems: 'center' }}>
            <Ionicons name="checkmark" size={16} color={theme.primary} /><Text style={{ color: theme.text, flex: 1 }}>{item}</Text></Card>)}
          <Button title="Return to focus" variant="secondary" onPress={() => setDistractionOpen(false)} />
        </View>
      </SheetModal>

      <SheetModal visible={completedVisible} onClose={resetTimer} title={isBreak ? 'Break complete' : endedEarly ? 'Session saved' : 'Focus complete'}>
        <View style={{ padding: 24, gap: 18, alignItems: 'center' }}>
          <View style={{ width: 84, height: 84, borderRadius: 42, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={isBreak ? 'battery-charging' : 'checkmark-done'} size={40} color={theme.primary} />
          </View>
          <Text style={{ color: theme.text, fontSize: 24, fontWeight: '900', textAlign: 'center' }}>{isBreak ? 'Recharged and ready?' : 'That was intentional work.'}</Text>
          <Text style={{ color: theme.muted, textAlign: 'center', lineHeight: 21 }}>{isBreak ? 'Return when you are ready. One clear block at a time.' : `${formatDuration(Math.round(elapsed / 60))} recorded${timer.distractions.length ? ` · ${timer.distractions.length} distractions parked` : ''}.`}</Text>
          {timer.mode === 'focus' ? <>
            <Button title={`Start ${nextMode === 'longBreak' ? data.settings.longBreakMinutes : data.settings.shortBreakMinutes} min ${nextMode === 'longBreak' ? 'long' : 'short'} break`} icon="cafe" style={{ alignSelf: 'stretch' }} onPress={() => startBreak(nextMode, timer.cycle)} />
            <Button title="Skip break · next focus" variant="ghost" style={{ alignSelf: 'stretch' }} onPress={() => startFocus(timer.taskId, timer.subjectId, timer.cycle + 1)} />
          </> : <Button title="Begin next focus" icon="play" style={{ alignSelf: 'stretch' }} onPress={() => startFocus(timer.taskId, timer.subjectId, timer.cycle + 1)} />}
          <Button title="Back to planner" variant="ghost" onPress={() => { resetTimer(); navigation.navigate('Planner'); }} />
        </View>
      </SheetModal>
    </Screen>
  );
}
