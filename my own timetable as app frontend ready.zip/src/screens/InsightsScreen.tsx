import React, { useMemo, useState } from 'react';
import { ScrollView, Share, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { addDays, dateFromIso, formatDuration, formatShortDate, fromDateKey, todayKey } from '../utils/date';
import { focusMinutesForDate, focusStreak, isTaskComplete, tasksForDate } from '../utils/selectors';
import { Badge, Button, Card, Divider, Header, ProgressBar, Screen, SectionTitle, Segmented } from '../components/ui';

export default function InsightsScreen() {
  const theme = useTheme();
  const { data } = useApp();
  const [range, setRange] = useState<'7' | '30'>('7');
  const days = useMemo(() => Array.from({ length: Number(range) }, (_, index) => addDays(todayKey(), index - Number(range) + 1)), [range]);
  const values = days.map((date) => focusMinutesForDate(data.sessions, date));
  const total = values.reduce((sum, value) => sum + value, 0);
  const max = Math.max(data.settings.dailyGoalMinutes, ...values, 1);
  const bestValue = Math.max(...values);
  const bestDay = days[values.indexOf(bestValue)];
  const tasksDone = days.reduce((sum, date) => sum + tasksForDate(data.tasks, date).filter((task) => isTaskComplete(task, date)).length, 0);
  const tasksTotal = days.reduce((sum, date) => sum + tasksForDate(data.tasks, date).length, 0);
  const completion = tasksTotal ? Math.round((tasksDone / tasksTotal) * 100) : 0;
  const rangeReviews = data.reviews.filter((review) => days.includes(review.date));
  const moodValues = rangeReviews.filter((review) => review.mood > 0).map((review) => review.mood);
  const averageMood = moodValues.length ? (moodValues.reduce((sum, value) => sum + value, 0) / moodValues.length).toFixed(1) : '—';
  const streak = focusStreak(data.sessions);
  const subjectData = data.subjects.map((subject) => ({
    ...subject,
    minutes: data.sessions.filter((session) => session.subjectId === subject.id && days.includes(dateFromIso(session.startedAt))).reduce((sum, session) => sum + session.actualMinutes, 0),
  })).filter((subject) => subject.minutes > 0).sort((a, b) => b.minutes - a.minutes);
  const topSubject = subjectData[0];
  const distractions = data.sessions.filter((session) => days.includes(dateFromIso(session.startedAt))).flatMap((session) => session.distractions);
  const distractionCounts = Object.entries(distractions.reduce<Record<string, number>>((counts, item) => {
    const key = item.trim().toLowerCase();
    if (key) counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {})).sort((a, b) => b[1] - a[1]).slice(0, 3);
  const heatDays = Array.from({ length: 35 }, (_, index) => addDays(todayKey(), index - 34));
  const recommendations = [
    completion < 60 && tasksTotal > 0 ? `Your completion rate is ${completion}%. Try planning fewer blocks and protect your Top 3 first.` : `You completed ${completion}% of planned work. Keep protecting the priorities that matter.`,
    total / Number(range) < data.settings.dailyGoalMinutes ? `Add one ${data.settings.focusMinutes}-minute block on your most reliable day, rather than changing the whole routine.` : `Your focus goal is consistently within reach. Increase difficulty, not necessarily hours.`,
    distractions.length > Number(range) / 2 ? 'Distractions are recurring: keep your phone outside arm’s reach and use parking before opening another app.' : 'Your distraction log is light. Keep the same simple environment reset before each session.',
  ];

  const shareReport = () => {
    Share.share({
      title: 'My FocusFlow review',
      message: `My ${range}-day FocusFlow review\n\n• ${formatDuration(total)} focused\n• ${tasksDone} study blocks completed\n• ${streak}-day focus streak\n• Best day: ${formatShortDate(bestDay)} (${formatDuration(bestValue)})${topSubject ? `\n• Top subject: ${topSubject.name}` : ''}\n\nNext adjustment: ${recommendations[1]}`,
    }).catch(() => undefined);
  };

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ paddingBottom: 38 }} showsVerticalScrollIndicator={false}>
        <Header title="Your patterns" subtitle="Turn your effort into a better system."
          right={<View style={{ width: 40 }}><Ionicons name="analytics" size={25} color={theme.primary} /></View>} />
        <View style={{ paddingHorizontal: 20, gap: 18 }}>
          <Segmented value={range} onChange={setRange} options={[{ value: '7', label: 'Last 7 days' }, { value: '30', label: 'Last 30 days' }]} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {[
              { label: 'TOTAL FOCUS', value: formatDuration(total), icon: 'time-outline' },
              { label: 'BLOCKS DONE', value: String(tasksDone), icon: 'checkmark-done-outline' },
              { label: 'FOCUS STREAK', value: `${streak} days`, icon: 'flame-outline' },
              { label: 'AVERAGE MOOD', value: averageMood === '—' ? '—' : `${averageMood}/5`, icon: 'happy-outline' },
            ].map((stat) => <Card key={stat.label} style={{ width: '48%', flexGrow: 1, padding: 14 }}>
              <Ionicons name={stat.icon as any} size={20} color={theme.primary} />
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 9 }}>{stat.value}</Text>
              <Text style={{ color: theme.muted, fontSize: 10, fontWeight: '800', marginTop: 3 }}>{stat.label}</Text>
            </Card>)}
          </View>

          <Card>
            <SectionTitle title="Focus rhythm" action={formatDuration(total)} />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 }}><Text style={{ color: theme.muted, fontSize: 12 }}>Daily goal {formatDuration(data.settings.dailyGoalMinutes)}</Text>
              <Text style={{ color: theme.primary, fontSize: 12, fontWeight: '800' }}>Best {formatDuration(bestValue)}</Text></View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1, gap: range === '7' ? 8 : 5, alignItems: 'flex-end', height: 185 }}>
              {days.map((date, index) => <View key={date} style={{ flex: range === '7' ? 1 : undefined, width: range === '7' ? undefined : 25, height: 180, justifyContent: 'flex-end', alignItems: 'center', gap: 7 }}>
                <Text style={{ color: theme.muted, fontSize: 9 }}>{values[index] ? `${Math.round(values[index] / 60 * 10) / 10}h` : ''}</Text>
                <View style={{ width: '100%', maxWidth: 32, height: 135, justifyContent: 'flex-end', backgroundColor: theme.surfaceAlt, borderRadius: 8, overflow: 'hidden' }}>
                  <View style={{ height: `${Math.max(values[index] ? 4 : 0, (values[index] / max) * 100)}%`, backgroundColor: date === todayKey() ? theme.primary : `${theme.primary}99`, borderRadius: 8 }} />
                </View>
                <Text style={{ color: date === todayKey() ? theme.primary : theme.muted, fontSize: 10, fontWeight: date === todayKey() ? '900' : '600' }}>{range === '7' ? fromDateKey(date).toLocaleDateString(undefined, { weekday: 'short' }).slice(0, 2) : fromDateKey(date).getDate()}</Text>
              </View>)}
            </ScrollView>
          </Card>

          <Card style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ width: 46, height: 46, borderRadius: 15, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}><Ionicons name="trophy-outline" size={24} color={theme.primary} /></View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>BEST FOCUS DAY</Text><Text style={{ color: theme.text, fontSize: 17, fontWeight: '900', marginTop: 3 }}>{bestValue ? formatShortDate(bestDay) : 'No sessions yet'}</Text></View>
              <Badge text={formatDuration(bestValue)} />
            </View>
          </Card>

          <Card>
            <SectionTitle title="Subject balance" icon="pie-chart-outline" />
            {subjectData.length ? subjectData.map((subject) => <View key={subject.id} style={{ marginBottom: 16, gap: 7 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}><View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: subject.color }} /><Text style={{ color: theme.text, fontWeight: '700' }}>{subject.name}</Text></View>
                <Text style={{ color: theme.muted, fontSize: 12 }}>{formatDuration(subject.minutes)}</Text></View>
              <ProgressBar value={subject.minutes} max={subjectData[0].minutes} color={subject.color} height={7} />
            </View>) : <Text style={{ color: theme.muted, lineHeight: 20 }}>Complete a focus session with a subject to see your study balance.</Text>}
          </Card>

          <Card>
            <SectionTitle title="35-day consistency" icon="grid-outline" action={`${streak} day streak`} />
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, justifyContent: 'center' }}>
              {heatDays.map((date) => {
                const minutes = focusMinutesForDate(data.sessions, date);
                const opacity = minutes === 0 ? 0 : minutes < 30 ? 0.25 : minutes < 75 ? 0.5 : minutes < 120 ? 0.75 : 1;
                return <View key={date} style={{ width: 34, height: 34, borderRadius: 9, backgroundColor: minutes ? theme.primary : theme.surfaceAlt,
                  opacity: minutes ? opacity : 1, alignItems: 'center', justifyContent: 'center', borderWidth: date === todayKey() ? 2 : 0, borderColor: theme.accent }}>
                  <Text style={{ color: opacity > 0.5 ? '#FFF' : theme.text, fontSize: 10, fontWeight: '700' }}>{fromDateKey(date).getDate()}</Text></View>;
              })}
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, marginTop: 13 }}><Text style={{ color: theme.muted, fontSize: 10 }}>Less</Text>{[0.15, 0.3, 0.55, 0.8, 1].map((opacity) => <View key={opacity} style={{ width: 13, height: 13, borderRadius: 4, backgroundColor: theme.primary, opacity }} />)}<Text style={{ color: theme.muted, fontSize: 10 }}>More</Text></View>
          </Card>

          <Card>
            <SectionTitle title="Weekly review — what next?" icon="bulb-outline" />
            {recommendations.map((recommendation, index) => <View key={recommendation} style={{ flexDirection: 'row', gap: 10, marginBottom: 14 }}>
              <View style={{ width: 23, height: 23, borderRadius: 12, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: theme.primary, fontSize: 11, fontWeight: '900' }}>{index + 1}</Text></View>
              <Text style={{ color: theme.text, flex: 1, lineHeight: 20, fontSize: 13 }}>{recommendation}</Text></View>)}
            <Button title="Share progress report" icon="share-social-outline" variant="secondary" onPress={shareReport} />
          </Card>

          {distractionCounts.length > 0 && <Card>
            <SectionTitle title="Recurring distractions" icon="notifications-off-outline" />
            {distractionCounts.map(([label, count]) => <View key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 9 }}>
              <Text style={{ color: theme.text, textTransform: 'capitalize', flex: 1 }}>{label}</Text><Badge text={`${count}×`} color={theme.warning} /></View>)}
          </Card>}
          <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center', lineHeight: 18 }}>Analytics are calculated on your device from real completed sessions and reviews.</Text>
        </View>
      </ScrollView>
    </Screen>
  );
}
