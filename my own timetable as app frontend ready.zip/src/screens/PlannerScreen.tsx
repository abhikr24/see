import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, RefreshControl, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { addDays, formatDuration, formatShortDate, formatTime, nowMinutes, todayKey, weekDates } from '../utils/date';
import { focusMinutesForDate, isTaskComplete, tasksForDate } from '../utils/selectors';
import { Badge, Button, Card, Header, IconButton, Screen, Segmented } from '../components/ui';
import WeekStrip from '../components/WeekStrip';
import TaskItem from '../components/TaskItem';

const SLOTS = Array.from({ length: 35 }, (_, index) => 300 + index * 30);

export default function PlannerScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, toggleTask, startFocus, autoSchedule } = useApp();
  const [selectedDate, setSelectedDate] = useState(todayKey());
  const [view, setView] = useState<'day' | 'week'>('day');
  const [refreshing, setRefreshing] = useState(false);
  const tasks = useMemo(() => tasksForDate(data.tasks, selectedDate), [data.tasks, selectedDate]);
  const scheduled = tasks.filter((task) => task.startMinute !== undefined);
  const unscheduled = tasks.filter((task) => task.startMinute === undefined);
  const plannedMinutes = scheduled.reduce((sum, task) => sum + task.durationMinutes, 0);
  const done = tasks.filter((task) => isTaskComplete(task, selectedDate)).length;
  const days = weekDates(selectedDate, data.settings.weekStartsMonday);

  const openTask = (taskId?: string, startMinute?: number) => navigation.navigate('TaskForm', { taskId, date: selectedDate, startMinute });
  const runAutoSchedule = () => {
    const count = autoSchedule(selectedDate);
    if (count) Alert.alert('Planner updated', `${count} open ${count === 1 ? 'block' : 'blocks'} placed in your available time.`);
    else Alert.alert('You’re all scheduled', 'Add an unscheduled study block first, or enjoy the clear space.');
  };

  const header = <>
    <Header title="Study planner" subtitle="25 minutes of focus + 5 minutes to reset"
      right={<IconButton icon="add" label="Add study block" filled onPress={() => openTask()} />} />
    <WeekStrip selected={selectedDate} monday={data.settings.weekStartsMonday} onSelect={setSelectedDate} />
    <View style={{ paddingHorizontal: 20, gap: 15, paddingBottom: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
          <IconButton icon="chevron-back" label="Previous day" onPress={() => setSelectedDate(addDays(selectedDate, -1))} />
          <View><Text style={{ color: theme.text, fontSize: 19, fontWeight: '900' }}>{selectedDate === todayKey() ? 'Today' : formatShortDate(selectedDate)}</Text>
            <Text style={{ color: theme.muted, fontSize: 12 }}>{tasks.length} blocks · {done} complete</Text></View>
          <IconButton icon="chevron-forward" label="Next day" onPress={() => setSelectedDate(addDays(selectedDate, 1))} />
        </View>
        <Badge text={formatDuration(plannedMinutes)} />
      </View>
      <Segmented value={view} onChange={setView} options={[{ value: 'day', label: 'Schedule', icon: 'list' }, { value: 'week', label: 'Week overview', icon: 'calendar' }]} />
      {view === 'day' && <View style={{ flexDirection: 'row', gap: 9 }}>
        <Button title="Auto-place backlog" icon="sparkles" variant="secondary" style={{ flex: 1 }} onPress={runAutoSchedule} />
        <IconButton icon="today-outline" label="Jump to today" filled onPress={() => setSelectedDate(todayKey())} />
      </View>}
    </View>
  </>;

  return (
    <Screen>
      {view === 'day' ? <FlatList
        data={SLOTS}
        keyExtractor={(item) => String(item)}
        ListHeaderComponent={header}
        contentContainerStyle={{ paddingBottom: 30 }}
        refreshControl={<RefreshControl refreshing={refreshing} tintColor={theme.primary} onRefresh={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 350); }} />}
        renderItem={({ item: minute }) => {
          const slotTasks = scheduled.filter((task) => task.startMinute === minute);
          const isCurrent = selectedDate === todayKey() && nowMinutes() >= minute && nowMinutes() < minute + 30;
          return (
            <View style={{ flexDirection: 'row', marginHorizontal: 20, minHeight: slotTasks.length ? undefined : 49 }}>
              <View style={{ width: 68, paddingTop: 3 }}><Text style={{ color: isCurrent ? theme.primary : theme.faint, fontSize: 11, fontWeight: isCurrent ? '900' : '600' }}>{formatTime(minute)}</Text></View>
              <View style={{ flex: 1, borderTopWidth: 1, borderTopColor: isCurrent ? theme.primary : theme.border, paddingBottom: slotTasks.length ? 10 : 0 }}>
                {isCurrent && <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: theme.primary, position: 'absolute', left: -4, top: -4 }} />}
                {slotTasks.map((task) => <Pressable key={task.id} onPress={() => openTask(task.id)} style={{ marginTop: 8 }}>
                  <Card style={{ paddingHorizontal: 12, paddingVertical: 2, borderLeftWidth: 4,
                    borderLeftColor: data.subjects.find((subject) => subject.id === task.subjectId)?.color || theme.primary,
                    backgroundColor: isTaskComplete(task, selectedDate) ? theme.surfaceAlt : theme.surface }}>
                    <TaskItem task={task} date={selectedDate} subject={data.subjects.find((subject) => subject.id === task.subjectId)}
                      onToggle={() => toggleTask(task.id, selectedDate)} onPress={() => openTask(task.id)}
                      onFocus={() => { startFocus(task.id, task.subjectId); navigation.navigate('Focus'); }} compact />
                  </Card>
                </Pressable>)}
                {minute % 60 === 0 && !slotTasks.length && <Pressable onPress={() => openTask(undefined, minute)} style={{ paddingTop: 9 }}>
                  <Text style={{ color: theme.faint, fontSize: 11 }}>+ add block</Text>
                </Pressable>}
              </View>
            </View>
          );
        }}
        ListFooterComponent={<View style={{ paddingHorizontal: 20, paddingTop: 22 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <Text style={{ color: theme.text, fontSize: 17, fontWeight: '900' }}>Anytime backlog</Text><Badge text={`${unscheduled.length} OPEN`} />
          </View>
          {unscheduled.length ? <Card style={{ paddingVertical: 4 }}>
            {unscheduled.map((task) => <TaskItem key={task.id} task={task} date={selectedDate}
              subject={data.subjects.find((subject) => subject.id === task.subjectId)} onToggle={() => toggleTask(task.id, selectedDate)}
              onPress={() => openTask(task.id)} onFocus={() => { startFocus(task.id, task.subjectId); navigation.navigate('Focus'); }} />)}
          </Card> : <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 19 }}>No loose ends. Unscheduled tasks will appear here for smart placement.</Text>}
        </View>}
      /> : <FlatList
        data={days}
        keyExtractor={(date) => date}
        ListHeaderComponent={header}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 30, gap: 10 }}
        renderItem={({ item: date }) => {
          const dayTasks = tasksForDate(data.tasks, date);
          const dayMinutes = dayTasks.reduce((sum, task) => sum + task.durationMinutes, 0);
          const dayDone = dayTasks.filter((task) => isTaskComplete(task, date)).length;
          return <Card onPress={() => { setSelectedDate(date); setView('day'); }} style={{ padding: 15 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
              <View style={{ width: 49, height: 54, borderRadius: 15, alignItems: 'center', justifyContent: 'center',
                backgroundColor: date === todayKey() ? theme.primary : theme.surfaceAlt }}>
                <Text style={{ color: date === todayKey() ? (theme.dark ? '#102019' : '#FFF') : theme.muted, fontSize: 10, fontWeight: '800' }}>{new Date(`${date}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short' }).toUpperCase()}</Text>
                <Text style={{ color: date === todayKey() ? (theme.dark ? '#102019' : '#FFF') : theme.text, fontSize: 20, fontWeight: '900' }}>{Number(date.slice(-2))}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.text, fontWeight: '800', fontSize: 15 }}>{dayTasks.length ? `${dayTasks.length} study blocks` : 'Open day'}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{formatDuration(dayMinutes)} planned · {formatDuration(focusMinutesForDate(data.sessions, date))} focused</Text>
                <View style={{ flexDirection: 'row', gap: 4, marginTop: 9 }}>
                  {dayTasks.slice(0, 5).map((task) => <View key={task.id} style={{ width: 20, height: 4, borderRadius: 3,
                    backgroundColor: data.subjects.find((subject) => subject.id === task.subjectId)?.color || theme.border }} />)}
                </View>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 8 }}><Badge text={`${dayDone}/${dayTasks.length}`} /><Ionicons name="chevron-forward" size={17} color={theme.muted} /></View>
            </View>
          </Card>;
        }}
      />}
    </Screen>
  );
}
