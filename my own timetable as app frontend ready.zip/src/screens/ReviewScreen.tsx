import React, { useEffect, useState } from 'react';
import { FlatList, Pressable, ScrollView, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { addDays, formatDuration, formatLongDate, formatShortDate, relativeDay, todayKey } from '../utils/date';
import { focusMinutesForDate, isTaskComplete, reviewForDate, tasksForDate } from '../utils/selectors';
import { DailyReview } from '../types';
import { Badge, Button, Card, Divider, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, Segmented } from '../components/ui';

function blankReview(date: string): DailyReview {
  return { date, worked: '', fix: '', gratitude: '', quickNotes: '', distractionNotes: '', mood: 0, energy: 0,
    water: 0, sleepHours: 0, steps: 0, productivity: 0, updatedAt: new Date().toISOString() };
}

export default function ReviewScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, saveReview, toggleTopThree, toggleTask } = useApp();
  const [date, setDate] = useState(todayKey());
  const [tab, setTab] = useState<'checkin' | 'history'>('checkin');
  const [draft, setDraft] = useState<DailyReview>(() => reviewForDate(data.reviews, todayKey()) || blankReview(todayKey()));
  const [sleepInput, setSleepInput] = useState(() => {
    const hours = reviewForDate(data.reviews, todayKey())?.sleepHours;
    return hours ? String(hours) : '';
  });
  const [saved, setSaved] = useState(false);
  const tomorrow = addDays(date, 1);
  const tomorrowTasks = tasksForDate(data.tasks, tomorrow);
  const topTomorrow = tomorrowTasks.filter((task) => task.topThreeDates.includes(tomorrow));
  const history = [...data.reviews].sort((a, b) => b.date.localeCompare(a.date));

  useEffect(() => {
    const stored = reviewForDate(data.reviews, date);
    setDraft(stored || blankReview(date));
    setSleepInput(stored?.sleepHours ? String(stored.sleepHours) : '');
    setSaved(false);
    // Loading a different day intentionally resets the form from local storage.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const patch = (value: Partial<DailyReview>) => { setDraft((previous) => ({ ...previous, ...value })); setSaved(false); };
  const save = () => {
    saveReview({ ...draft, date, updatedAt: new Date().toISOString() });
    setSaved(true);
  };
  const moods = [
    { label: 'Rough', icon: 'sad-outline' }, { label: 'Low', icon: 'cloudy-outline' },
    { label: 'Okay', icon: 'remove-outline' }, { label: 'Good', icon: 'happy-outline' }, { label: 'Great', icon: 'sunny-outline' },
  ];

  return (
    <Screen>
      <Header title="Reflect & reset" subtitle="Notice what worked. Adjust without judgment."
        right={tab === 'checkin' ? <IconButton icon="checkmark" label="Save review" filled onPress={save} /> : undefined} />
      <View style={{ paddingHorizontal: 20, paddingBottom: 16 }}><Segmented value={tab} onChange={setTab} options={[{ value: 'checkin', label: 'Daily review', icon: 'create-outline' }, { value: 'history', label: 'Past reviews', icon: 'time-outline' }]} /></View>
      {tab === 'checkin' ? <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 18 }}>
        <Card style={{ paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <IconButton icon="chevron-back" label="Previous day" onPress={() => setDate(addDays(date, -1))} />
          <View style={{ alignItems: 'center' }}><Text style={{ color: theme.text, fontSize: 16, fontWeight: '900' }}>{relativeDay(date)}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{formatLongDate(date)}</Text></View>
          <IconButton icon="chevron-forward" label="Next day" onPress={() => date < todayKey() && setDate(addDays(date, 1))} color={date < todayKey() ? theme.text : theme.faint} />
        </Card>

        <Card style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><View><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>TODAY AT A GLANCE</Text>
            <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900', marginTop: 7 }}>{formatDuration(focusMinutesForDate(data.sessions, date))}</Text></View>
            <View style={{ alignItems: 'flex-end' }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>BLOCKS DONE</Text>
              <Text style={{ color: theme.text, fontSize: 26, fontWeight: '900', marginTop: 7 }}>{tasksForDate(data.tasks, date).filter((task) => isTaskComplete(task, date)).length}/{tasksForDate(data.tasks, date).length}</Text></View></View>
        </Card>

        <Field label="What worked today?" value={draft.worked} onChangeText={(worked) => patch({ worked })} multiline placeholder="A win, a useful method, or something that finally clicked…" />
        <Field label="What will you fix tomorrow?" value={draft.fix} onChangeText={(fix) => patch({ fix })} multiline placeholder="One small, realistic adjustment…" />
        <Field label="Today’s win / grateful for" value={draft.gratitude} onChangeText={(gratitude) => patch({ gratitude })} multiline placeholder="Something worth carrying forward…" />

        <Card style={{ gap: 15 }}>
          <SectionTitle title="Mood & energy" icon="happy-outline" />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            {moods.map((mood, index) => <Pressable key={mood.label} onPress={() => patch({ mood: index + 1 })} style={{ alignItems: 'center', gap: 6, opacity: draft.mood === index + 1 ? 1 : 0.45 }}>
              <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: draft.mood === index + 1 ? theme.accent : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name={mood.icon as any} size={24} color={draft.mood === index + 1 ? theme.accentText : theme.muted} /></View>
              <Text style={{ color: theme.text, fontSize: 10, fontWeight: '700' }}>{mood.label}</Text></Pressable>)}
          </View>
          <Divider />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ color: theme.text, fontWeight: '700' }}>Energy level</Text><Badge text={draft.energy ? `${draft.energy}/5` : 'NOT SET'} /></View>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-end', height: 42 }}>
            {[1, 2, 3, 4, 5].map((level) => <Pressable key={level} onPress={() => patch({ energy: level })} style={{ flex: 1, height: 12 + level * 6, borderRadius: 6,
              backgroundColor: level <= draft.energy ? theme.primary : theme.surfaceAlt }} />)}
          </View>
          <Divider />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ color: theme.text, fontWeight: '700' }}>Productivity</Text><Badge text={draft.productivity ? `${draft.productivity}/5` : 'NOT SET'} /></View>
          <View style={{ flexDirection: 'row', gap: 7 }}>{[1, 2, 3, 4, 5].map((level) => <Pressable key={level} onPress={() => patch({ productivity: level })}
            style={{ flex: 1, height: 39, borderRadius: 11, backgroundColor: level <= draft.productivity ? theme.primarySoft : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="star" size={17} color={level <= draft.productivity ? theme.primary : theme.faint} /></Pressable>)}</View>
        </Card>

        <Card style={{ gap: 14 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><SectionTitle title="Water intake" icon="water-outline" /><Badge text={`${draft.water}/${data.settings.waterGoal} GLASSES`} /></View>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {Array.from({ length: data.settings.waterGoal }, (_, index) => <Pressable key={index} onPress={() => patch({ water: index + 1 === draft.water ? index : index + 1 })}
              style={{ width: 38, height: 44, borderRadius: 10, borderWidth: 1, borderColor: index < draft.water ? '#4D91A8' : theme.border,
                backgroundColor: index < draft.water ? '#4D91A833' : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name={index < draft.water ? 'water' : 'water-outline'} color="#4D91A8" size={21} /></Pressable>)}
          </View>
          <ProgressBar value={draft.water} max={data.settings.waterGoal} color="#4D91A8" />
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}><Field label="Sleep (hours)" value={sleepInput} onChangeText={(text) => {
              const clean = text.replace(/[^0-9.]/g, '');
              if ((clean.match(/\./g) || []).length > 1) return;
              setSleepInput(clean);
              patch({ sleepHours: Math.min(24, Math.max(0, Number.parseFloat(clean) || 0)) });
            }} onBlur={() => setSleepInput(draft.sleepHours ? String(draft.sleepHours) : '')} keyboardType="decimal-pad" placeholder="7.5" /></View>
            <View style={{ flex: 1 }}><Field label="Steps" value={draft.steps ? String(draft.steps) : ''} onChangeText={(text) => patch({ steps: Number(text.replace(/\D/g, '')) || 0 })} keyboardType="number-pad" placeholder="6000" /></View>
          </View>
        </Card>

        <Field label="Quick notes — new & important" value={draft.quickNotes} onChangeText={(quickNotes) => patch({ quickNotes })} multiline placeholder="Ideas, reminders, formulas to revisit…" />
        <Field label="Distraction parking review" value={draft.distractionNotes} onChangeText={(distractionNotes) => patch({ distractionNotes })} multiline placeholder="What pulled you away? How can you reduce it?" />

        <Card style={{ gap: 8 }}>
          <SectionTitle title="Tomorrow’s Top 3 — seeds" icon="sunny-outline" action="+ Add" onAction={() => navigation.navigate('TaskForm', { date: tomorrow })} />
          <Text style={{ color: theme.muted, fontSize: 12, marginBottom: 5 }}>Select up to three. Future-you will thank you.</Text>
          {tomorrowTasks.map((task) => {
            const selected = task.topThreeDates.includes(tomorrow);
            return <Pressable key={task.id} onPress={() => {
              if (!selected && topTomorrow.length >= 3) return;
              toggleTopThree(task.id, tomorrow);
            }} style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 9, opacity: !selected && topTomorrow.length >= 3 ? 0.4 : 1 }}>
              <Ionicons name={selected ? 'star' : 'star-outline'} color={selected ? theme.warning : theme.muted} size={21} />
              <Text style={{ color: theme.text, flex: 1, fontWeight: selected ? '800' : '500' }}>{task.title}</Text>
              <Pressable hitSlop={8} onPress={() => toggleTask(task.id, tomorrow)}><Ionicons name={isTaskComplete(task, tomorrow) ? 'checkmark-circle' : 'ellipse-outline'} size={20} color={theme.primary} /></Pressable>
            </Pressable>;
          })}
          {!tomorrowTasks.length && <Text style={{ color: theme.muted, fontStyle: 'italic', paddingVertical: 10 }}>No blocks planned tomorrow yet. Add one above.</Text>}
        </Card>
        <Button title={saved ? 'Review saved' : 'Save daily review'} icon={saved ? 'checkmark-circle' : 'checkmark'} variant={saved ? 'secondary' : 'primary'} onPress={save} />
      </ScrollView> : <FlatList data={history} keyExtractor={(item) => item.date} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 35, gap: 12 }}
        renderItem={({ item }) => <Card onPress={() => { setDate(item.date); setTab('checkin'); }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><View><Text style={{ color: theme.text, fontSize: 16, fontWeight: '900' }}>{relativeDay(item.date)}</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>{formatShortDate(item.date)}</Text></View>
            <View style={{ flexDirection: 'row', gap: 7 }}><Badge text={`${formatDuration(focusMinutesForDate(data.sessions, item.date))} FOCUS`} />{item.productivity > 0 && <Badge text={`${item.productivity}/5`} color={theme.warning} />}</View></View>
          {!!item.worked && <><Divider /><Text style={{ color: theme.primary, fontSize: 11, fontWeight: '900' }}>WORKED</Text><Text style={{ color: theme.text, lineHeight: 20, marginTop: 5 }}>{item.worked}</Text></>}
          {!!item.fix && <View style={{ marginTop: 12 }}><Text style={{ color: theme.warning, fontSize: 11, fontWeight: '900' }}>FIX NEXT</Text><Text style={{ color: theme.muted, lineHeight: 20, marginTop: 5 }}>{item.fix}</Text></View>}
          <View style={{ flexDirection: 'row', gap: 15, marginTop: 14 }}><Text style={{ color: theme.muted, fontSize: 12 }}>• Water {item.water}</Text><Text style={{ color: theme.muted, fontSize: 12 }}>• Sleep {item.sleepHours || '—'}h</Text><Text style={{ color: theme.muted, fontSize: 12 }}>• Mood {item.mood || '—'}/5</Text></View>
        </Card>}
        ListEmptyComponent={<EmptyState icon="journal-outline" title="Your reflections will live here" message="Save your first daily review to start noticing patterns." action="Write a review" onAction={() => setTab('checkin')} />}
      />}
    </Screen>
  );
}
