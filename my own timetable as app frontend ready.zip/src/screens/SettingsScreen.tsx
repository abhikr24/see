import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Share, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { formatDuration } from '../utils/date';
import { ThemeMode } from '../types';
import { Badge, Button, Card, Chip, Divider, Field, Header, IconButton, Screen, SectionTitle, Segmented } from '../components/ui';

function SettingsRow({ icon, title, subtitle, onPress, right }: { icon: string; title: string; subtitle: string; onPress: () => void; right?: React.ReactNode }) {
  const theme = useTheme();
  return <Pressable onPress={onPress} style={({ pressed }) => ({ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, opacity: pressed ? 0.65 : 1 })}>
    <View style={{ width: 39, height: 39, borderRadius: 12, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}><Ionicons name={icon as any} size={20} color={theme.primary} /></View>
    <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800', fontSize: 14 }}>{title}</Text><Text style={{ color: theme.muted, fontSize: 12, marginTop: 3, lineHeight: 17 }}>{subtitle}</Text></View>
    {right || <Ionicons name="chevron-forward" size={17} color={theme.muted} />}
  </Pressable>;
}

function Stepper({ label, value, min, max, step = 5, onChange, suffix = 'min' }: { label: string; value: number; min: number; max: number; step?: number; onChange: (value: number) => void; suffix?: string }) {
  const theme = useTheme();
  return <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 }}>
    <Text style={{ color: theme.text, fontWeight: '700', flex: 1 }}>{label}</Text>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><IconButton icon="remove" label={`Decrease ${label}`} filled onPress={() => onChange(Math.max(min, value - step))} />
      <Text style={{ color: theme.text, width: 70, textAlign: 'center', fontWeight: '900', fontVariant: ['tabular-nums'] }}>{value} {suffix}</Text>
      <IconButton icon="add" label={`Increase ${label}`} filled onPress={() => onChange(Math.min(max, value + step))} /></View>
  </View>;
}

export default function SettingsScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, updateSettings, resetData, restoreSampleData } = useApp();
  const [name, setName] = useState(data.settings.name);

  const exportBackup = async () => {
    try {
      await Share.share({ title: 'FocusFlow backup', message: JSON.stringify({ app: 'FocusFlow', version: 1, exportedAt: new Date().toISOString(), data }, null, 2) });
    } catch {
      Alert.alert('Could not open sharing', 'Your data is still safe on this device. Try again from your Android device.');
    }
  };

  return (
    <Screen>
      <Header title="Settings" subtitle="Make the system fit the way you study." onBack={navigation.goBack} />
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 16 }}>
        <Card style={{ gap: 14 }}>
          <SectionTitle title="Your planner" icon="person-outline" />
          <Field label="Display name" value={name} onChangeText={setName} maxLength={30} returnKeyType="done" onSubmitEditing={() => name.trim() && updateSettings({ name: name.trim() })} />
          <Button title="Save profile" variant="secondary" onPress={() => name.trim() ? updateSettings({ name: name.trim() }) : Alert.alert('Name required', 'Enter a display name first.')} />
        </Card>

        <Card>
          <SectionTitle title="Pomodoro rhythm" icon="timer-outline" />
          <Stepper label="Focus session" value={data.settings.focusMinutes} min={5} max={90} onChange={(focusMinutes) => updateSettings({ focusMinutes })} />
          <Stepper label="Short break" value={data.settings.shortBreakMinutes} min={1} max={30} step={1} onChange={(shortBreakMinutes) => updateSettings({ shortBreakMinutes })} />
          <Stepper label="Long break" value={data.settings.longBreakMinutes} min={5} max={60} onChange={(longBreakMinutes) => updateSettings({ longBreakMinutes })} />
          <Stepper label="Long break after" value={data.settings.longBreakEvery} min={2} max={8} step={1} onChange={(longBreakEvery) => updateSettings({ longBreakEvery })} suffix="sessions" />
          <Text style={{ color: theme.muted, fontSize: 12, lineHeight: 18, marginTop: 8 }}>Changes apply to the next timer. Your current session is never interrupted.</Text>
        </Card>

        <Card style={{ gap: 17 }}>
          <SectionTitle title="Daily targets" icon="locate-outline" />
          <View style={{ gap: 9 }}><Text style={{ color: theme.text, fontWeight: '700' }}>Focus goal</Text><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 7 }}>
            {[60, 120, 180, 240, 360].map((minutes) => <Chip key={minutes} label={formatDuration(minutes)} selected={data.settings.dailyGoalMinutes === minutes} onPress={() => updateSettings({ dailyGoalMinutes: minutes })} />)}
          </View></View>
          <View style={{ gap: 9 }}><Text style={{ color: theme.text, fontWeight: '700' }}>Water goal</Text><View style={{ flexDirection: 'row', gap: 7 }}>
            {[6, 8, 10, 12].map((count) => <Chip key={count} label={`${count} glasses`} selected={data.settings.waterGoal === count} onPress={() => updateSettings({ waterGoal: count })} />)}
          </View></View>
        </Card>

        <Card style={{ gap: 16 }}>
          <SectionTitle title="Appearance & week" icon="color-palette-outline" />
          <Segmented<ThemeMode> value={data.settings.theme} onChange={(themeMode) => updateSettings({ theme: themeMode })} options={[{ value: 'system', label: 'System', icon: 'phone-portrait-outline' }, { value: 'light', label: 'Light', icon: 'sunny-outline' }, { value: 'dark', label: 'Dark', icon: 'moon-outline' }]} />
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}><View><Text style={{ color: theme.text, fontWeight: '700' }}>Week starts on</Text><Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>Used by planner and subject goals</Text></View>
            <View style={{ flexDirection: 'row', gap: 7 }}><Chip label="Mon" selected={data.settings.weekStartsMonday} onPress={() => updateSettings({ weekStartsMonday: true })} /><Chip label="Sun" selected={!data.settings.weekStartsMonday} onPress={() => updateSettings({ weekStartsMonday: false })} /></View></View>
        </Card>

        <Card style={{ paddingVertical: 4 }}>
          <SettingsRow icon="cloud-outline" title="Supabase cloud sync" subtitle="Account, encrypted connection, backup & multi-device sync" onPress={() => navigation.navigate('Cloud')} right={<Badge text={data.meta.dirty ? 'LOCAL CHANGES' : 'SYNCED'} />} />
          <Divider />
          <SettingsRow icon="library-outline" title="Manage subjects" subtitle={`${data.subjects.length} subjects · colors, icons & weekly goals`} onPress={() => navigation.navigate('Subjects')} />
          <Divider />
          <SettingsRow icon="school-outline" title="Manage exams" subtitle={`${data.exams.length} exam countdowns & syllabus notes`} onPress={() => navigation.navigate('Exams')} />
          <Divider />
          <SettingsRow icon="download-outline" title="Export local backup" subtitle="Share a complete JSON backup of your planner" onPress={exportBackup} />
        </Card>

        <Card style={{ gap: 12 }}>
          <SectionTitle title="Storage" icon="phone-portrait-outline" />
          <Text style={{ color: theme.muted, fontSize: 13, lineHeight: 20 }}>Everything works without an account. Changes save automatically on this device. Supabase is optional and can be connected whenever you are ready.</Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Badge text={`${data.tasks.length} TASKS`} /><Badge text={`${data.sessions.length} SESSIONS`} /><Badge text={`${data.reviews.length} REVIEWS`} /></View>
        </Card>

        <Card style={{ paddingVertical: 4 }}>
          <SettingsRow icon="sparkles-outline" title="Restore sample workspace" subtitle="Replace current data with a fresh guided example" onPress={() => Alert.alert('Restore sample workspace?', 'This replaces all current tasks, sessions, reviews, subjects, and exams. Export a backup first if needed.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Restore', style: 'destructive', onPress: restoreSampleData }])} />
          <Divider />
          <SettingsRow icon="trash-outline" title="Clear all planner data" subtitle="Keep settings, but permanently remove local study data" onPress={() => Alert.alert('Clear all planner data?', 'This cannot be undone unless you have a cloud or JSON backup.', [{ text: 'Cancel', style: 'cancel' }, { text: 'Clear everything', style: 'destructive', onPress: resetData }])} />
        </Card>
        <View style={{ alignItems: 'center', gap: 5, paddingVertical: 8 }}><Ionicons name="leaf" size={23} color={theme.primary} /><Text style={{ color: theme.text, fontWeight: '900' }}>FocusFlow</Text><Text style={{ color: theme.muted, fontSize: 12 }}>Version 1.0.0 · Offline-first study planning</Text></View>
      </ScrollView>
    </Screen>
  );
}
