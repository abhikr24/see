import React, { useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../store/AppContext';
import { SUBJECT_COLORS, useTheme } from '../theme';
import { Subject } from '../types';
import { dateFromIso, formatDuration, makeId, todayKey, weekDates } from '../utils/date';
import { Badge, Button, Card, Chip, EmptyState, Field, Header, IconButton, ProgressBar, Screen, SectionTitle, SheetModal } from '../components/ui';

const ICONS = ['book', 'calculator', 'planet', 'code-slash', 'flask', 'language', 'brush', 'musical-notes', 'fitness'];

export default function SubjectsScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, saveSubject, deleteSubject } = useApp();
  const [editing, setEditing] = useState<Subject | null>(null);
  const [modal, setModal] = useState(false);
  const [name, setName] = useState('');
  const [color, setColor] = useState(SUBJECT_COLORS[0]);
  const [icon, setIcon] = useState('book');
  const [goal, setGoal] = useState(180);
  const [error, setError] = useState('');
  const week = weekDates(todayKey(), data.settings.weekStartsMonday);

  const open = (subject?: Subject) => {
    setEditing(subject || null); setName(subject?.name || ''); setColor(subject?.color || SUBJECT_COLORS[data.subjects.length % SUBJECT_COLORS.length]);
    setIcon(subject?.icon || 'book'); setGoal(subject?.weeklyGoalMinutes || 180); setError(''); setModal(true);
  };
  const save = () => {
    if (!name.trim()) { setError('Enter a subject name.'); return; }
    saveSubject({ id: editing?.id || makeId('subject'), name: name.trim(), color, icon,
      weeklyGoalMinutes: goal, archived: editing?.archived || false, createdAt: editing?.createdAt || new Date().toISOString() });
    setModal(false);
  };
  const remove = (subject: Subject) => Alert.alert(`Delete ${subject.name}?`, 'Your study blocks and focus history will remain, but become unassigned.', [
    { text: 'Cancel', style: 'cancel' }, { text: 'Delete', style: 'destructive', onPress: () => deleteSubject(subject.id) },
  ]);

  return (
    <Screen>
      <Header title="Subjects" subtitle="Set a weekly intention for every area." onBack={navigation.goBack} right={<IconButton icon="add" label="Add subject" filled onPress={() => open()} />} />
      <FlatList data={[...data.subjects].sort((a, b) => Number(a.archived) - Number(b.archived))} keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 35, gap: 11 }}
        ListHeaderComponent={<Card style={{ marginBottom: 10, backgroundColor: theme.primarySoft, borderColor: 'transparent', flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Ionicons name="library-outline" size={26} color={theme.primary} /><View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{data.subjects.filter((item) => !item.archived).length} active subjects</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>Weekly target across all subjects</Text></View><Badge text={formatDuration(data.subjects.filter((s) => !s.archived).reduce((sum, s) => sum + s.weeklyGoalMinutes, 0))} />
        </Card>}
        renderItem={({ item }) => {
          const minutes = data.sessions.filter((session) => session.subjectId === item.id && week.includes(dateFromIso(session.startedAt))).reduce((sum, session) => sum + session.actualMinutes, 0);
          return <Card onPress={() => open(item)} style={{ opacity: item.archived ? 0.6 : 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ width: 48, height: 48, borderRadius: 15, backgroundColor: item.color, alignItems: 'center', justifyContent: 'center' }}><Ionicons name={item.icon as any} size={23} color="#FFF" /></View>
              <View style={{ flex: 1 }}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 7 }}><Text style={{ color: theme.text, fontWeight: '900', fontSize: 16 }}>{item.name}</Text>{item.archived && <Badge text="ARCHIVED" />}</View>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>{formatDuration(minutes)} this week · {formatDuration(item.weeklyGoalMinutes)} goal</Text></View>
              <IconButton icon="trash-outline" label={`Delete ${item.name}`} color={theme.danger} onPress={() => remove(item)} />
            </View>
            <View style={{ marginTop: 14 }}><ProgressBar value={minutes} max={item.weeklyGoalMinutes} color={item.color} /></View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 }}><Text style={{ color: theme.muted, fontSize: 11 }}>{Math.round((minutes / item.weeklyGoalMinutes) * 100)}% of weekly goal</Text>
              <Text style={{ color: theme.primary, fontSize: 11, fontWeight: '800' }}>Tap to edit</Text></View>
          </Card>;
        }}
        ListEmptyComponent={<EmptyState icon="library-outline" title="Create your first subject" message="Subjects connect planner blocks, focus sessions, exams, and weekly insights." action="Add subject" onAction={() => open()} />}
      />
      <SheetModal visible={modal} onClose={() => setModal(false)} title={editing ? 'Edit subject' : 'New subject'}>
        <ScrollView contentContainerStyle={{ padding: 20, gap: 20 }}>
          <Field label="Subject name" value={name} onChangeText={(text) => { setName(text); setError(''); }} placeholder="e.g. Biology" autoFocus maxLength={50} />
          <View><SectionTitle title="Color" /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>{SUBJECT_COLORS.map((item) => <Pressable key={item} onPress={() => setColor(item)}
            style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: item, alignItems: 'center', justifyContent: 'center', borderWidth: color === item ? 3 : 0, borderColor: theme.text }}>
            {color === item && <Ionicons name="checkmark" color="#FFF" size={20} />}</Pressable>)}</View></View>
          <View><SectionTitle title="Icon" /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 9 }}>{ICONS.map((item) => <Pressable key={item} onPress={() => setIcon(item)}
            style={{ width: 46, height: 46, borderRadius: 14, backgroundColor: icon === item ? color : theme.surfaceAlt, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={item as any} size={22} color={icon === item ? '#FFF' : theme.muted} /></Pressable>)}</View></View>
          <View><SectionTitle title="Weekly focus goal" /><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{[60, 120, 180, 240, 300, 420, 600].map((minutes) => <Chip key={minutes} label={formatDuration(minutes)} selected={goal === minutes} onPress={() => setGoal(minutes)} />)}</View></View>
          {editing && <Button title={editing.archived ? 'Restore subject' : 'Archive subject'} variant="ghost" icon="archive-outline"
            onPress={() => { saveSubject({ ...editing, archived: !editing.archived }); setModal(false); }} />}
          {!!error && <Text style={{ color: theme.danger }}>{error}</Text>}
          <Button title="Save subject" icon="checkmark" onPress={save} />
        </ScrollView>
      </SheetModal>
    </Screen>
  );
}
