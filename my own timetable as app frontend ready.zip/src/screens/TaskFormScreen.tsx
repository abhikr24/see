import React, { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import Ionicons from '@expo/vector-icons/Ionicons';
import { RootStackParamList } from '../navigation/types';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { Priority, Recurrence, StudyTask } from '../types';
import { addDays, formatLongDate, formatTime, isValidDateKey, makeId, todayKey } from '../utils/date';
import { Button, Card, Chip, Divider, Field, Header, IconButton, Screen, SectionTitle } from '../components/ui';

type Props = NativeStackScreenProps<RootStackParamList, 'TaskForm'>;

export default function TaskFormScreen({ route, navigation }: Props) {
  const theme = useTheme();
  const { data, saveTask, deleteTask } = useApp();
  const existing = data.tasks.find((task) => task.id === route.params?.taskId);
  const initialDate = route.params?.date || existing?.date || todayKey();
  const [title, setTitle] = useState(existing?.title || '');
  const [notes, setNotes] = useState(existing?.notes || '');
  const [date, setDate] = useState(initialDate);
  const [subjectId, setSubjectId] = useState(existing?.subjectId || data.subjects.find((item) => !item.archived)?.id);
  const [startMinute, setStartMinute] = useState<number | undefined>(existing?.startMinute ?? route.params?.startMinute);
  const [duration, setDuration] = useState(existing?.durationMinutes || 50);
  const [priority, setPriority] = useState<Priority>(existing?.priority || 'medium');
  const [recurrence, setRecurrence] = useState<Recurrence>(existing?.recurrence || 'none');
  const [topThree, setTopThree] = useState(existing?.topThreeDates.includes(initialDate) || false);
  const [error, setError] = useState('');
  const activeSubjects = useMemo(() => data.subjects.filter((subject) => !subject.archived), [data.subjects]);
  const topThreeCount = data.tasks.filter((task) => task.id !== existing?.id && task.topThreeDates.includes(date)).length;

  const save = () => {
    if (!title.trim()) {
      setError('Give this study block a clear title.');
      return;
    }
    if (!isValidDateKey(date)) {
      setError('Use a valid date in YYYY-MM-DD format.');
      return;
    }
    const now = new Date().toISOString();
    const task: StudyTask = {
      id: existing?.id || makeId('task'), title: title.trim(), notes: notes.trim(), date, subjectId,
      startMinute, durationMinutes: duration, estimatedPomodoros: Math.max(1, Math.ceil(duration / data.settings.focusMinutes)),
      priority, recurrence, completedDates: existing?.completedDates || [],
      topThreeDates: topThree
        ? [...(existing?.topThreeDates || []).filter((item) => item !== date), date]
        : (existing?.topThreeDates || []).filter((item) => item !== date),
      createdAt: existing?.createdAt || now, updatedAt: now,
    };
    saveTask(task);
    navigation.goBack();
  };

  const confirmDelete = () => {
    if (!existing) return;
    Alert.alert('Delete study block?', 'Focus sessions already recorded will stay in your history.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { deleteTask(existing.id); navigation.goBack(); } },
    ]);
  };

  return (
    <Screen>
      <Header title={existing ? 'Edit study block' : 'New study block'} subtitle="Plan with purpose, then make it happen." onBack={navigation.goBack} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40, gap: 18 }}>
        <Field label="What will you work on?" value={title} onChangeText={(text) => { setTitle(text); setError(''); }}
          placeholder="e.g. Revise quadratic equations" autoFocus={!existing} returnKeyType="next" maxLength={100} />
        <Card style={{ gap: 14 }}>
          <SectionTitle title="Date & time" icon="calendar-outline" />
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <IconButton icon="chevron-back" onPress={() => setDate(addDays(date, -1))} label="Previous day" filled />
            <View style={{ alignItems: 'center' }}>
              <Text style={{ color: theme.text, fontWeight: '800', fontSize: 16 }}>{formatLongDate(date)}</Text>
              <Pressable onPress={() => setDate(todayKey())}><Text style={{ color: theme.primary, fontSize: 12, marginTop: 4, fontWeight: '700' }}>{date}</Text></Pressable>
            </View>
            <IconButton icon="chevron-forward" onPress={() => setDate(addDays(date, 1))} label="Next day" filled />
          </View>
          <Field label="Date (editable)" value={date} onChangeText={setDate} autoCapitalize="none" autoCorrect={false} keyboardType="numbers-and-punctuation" />
          <Divider />
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View>
              <Text style={{ color: theme.muted, fontSize: 12, fontWeight: '700' }}>START TIME</Text>
              <Text style={{ color: theme.text, fontSize: 22, fontWeight: '900', marginTop: 4 }}>{startMinute === undefined ? 'Anytime' : formatTime(startMinute)}</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 4 }}>
              <IconButton icon="remove" label="30 minutes earlier" filled onPress={() => setStartMinute(Math.max(300, (startMinute ?? 480) - 30))} />
              <IconButton icon="add" label="30 minutes later" filled onPress={() => setStartMinute(Math.min(1320, (startMinute ?? 480) + 30))} />
            </View>
          </View>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <Button title={startMinute === undefined ? 'Set 8:00 AM' : 'Make unscheduled'} variant="ghost" style={{ flex: 1 }}
              onPress={() => setStartMinute(startMinute === undefined ? 480 : undefined)} />
          </View>
        </Card>

        <View>
          <SectionTitle title="Subject" />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {activeSubjects.map((subject) => <Chip key={subject.id} label={subject.name} selected={subjectId === subject.id}
              color={subject.color} onPress={() => setSubjectId(subject.id)} />)}
            <Chip label="No subject" selected={!subjectId} onPress={() => setSubjectId(undefined)} />
          </ScrollView>
        </View>

        <View>
          <SectionTitle title="Duration" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {[20, 25, 30, 50, 60, 90, 120].map((minutes) => <Chip key={minutes} label={`${minutes} min`} selected={duration === minutes} onPress={() => setDuration(minutes)} />)}
          </View>
        </View>
        <View>
          <SectionTitle title="Priority" />
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {(['high', 'medium', 'low'] as Priority[]).map((item) => <Chip key={item} label={item[0].toUpperCase() + item.slice(1)}
              icon="flag-outline" selected={priority === item} onPress={() => setPriority(item)} />)}
          </View>
        </View>
        <View>
          <SectionTitle title="Repeats" />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {([['none', 'Never'], ['daily', 'Daily'], ['weekdays', 'Weekdays'], ['weekly', 'Weekly']] as [Recurrence, string][]).map(([value, label]) =>
              <Chip key={value} label={label} icon={value === 'none' ? undefined : 'repeat'} selected={recurrence === value} onPress={() => setRecurrence(value)} />)}
          </View>
        </View>
        <Field label="Notes & resources" value={notes} onChangeText={setNotes} multiline placeholder="Chapter, page numbers, links, or a definition of done…" maxLength={1000} />
        <Pressable onPress={() => {
          if (!topThree && topThreeCount >= 3) {
            setError('This day already has three priorities. Remove one before adding another.');
            return;
          }
          setError('');
          setTopThree(!topThree);
        }} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 26, height: 26, borderRadius: 9, backgroundColor: topThree ? theme.primary : theme.surfaceAlt,
            alignItems: 'center', justifyContent: 'center' }}>{topThree && <Ionicons name="checkmark" color={theme.dark ? '#102019' : '#FFF'} size={18} />}</View>
          <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>One of today’s Top 3</Text>
            <Text style={{ color: theme.muted, fontSize: 12, marginTop: 3 }}>Keep the work that matters most visible.</Text></View>
        </Pressable>
        {!!error && <Text style={{ color: theme.danger, fontSize: 13, fontWeight: '700' }}>{error}</Text>}
        <Button title={existing ? 'Save changes' : 'Add to planner'} icon="checkmark" onPress={save} />
        {existing && <Button title="Delete study block" icon="trash-outline" variant="danger" onPress={confirmDelete} />}
      </ScrollView>
    </Screen>
  );
}
