import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useApp } from '../store/AppContext';
import { useTheme } from '../theme';
import { addDays, formatDuration, formatShortDate, formatTime, greeting, nowMinutes, todayKey } from '../utils/date';
import { completionStreak, focusMinutesForDate, isTaskComplete, reviewForDate, tasksForDate } from '../utils/selectors';
import { Badge, Button, Card, Header, IconButton, ProgressBar, Screen, SectionTitle } from '../components/ui';
import WeekStrip from '../components/WeekStrip';
import TaskItem from '../components/TaskItem';
import { DailyReview } from '../types';

export default function TodayScreen() {
  const theme = useTheme();
  const navigation = useNavigation<any>();
  const { data, toggleTask, startFocus, saveReview } = useApp();
  const today = todayKey();
  const [selectedDate, setSelectedDate] = useState(today);
  const [refreshing, setRefreshing] = useState(false);
  const tasks = useMemo(() => tasksForDate(data.tasks, selectedDate), [data.tasks, selectedDate]);
  const topThree = tasks.filter((task) => task.topThreeDates.includes(selectedDate)).slice(0, 3);
  const completed = tasks.filter((task) => isTaskComplete(task, selectedDate)).length;
  const minutes = focusMinutesForDate(data.sessions, selectedDate);
  const goal = data.settings.dailyGoalMinutes;
  const nextTask = tasks.find((task) => !isTaskComplete(task, selectedDate) && task.startMinute !== undefined && task.startMinute >= nowMinutes() - task.durationMinutes);
  const review = reviewForDate(data.reviews, selectedDate);
  const nextExam = [...data.exams].filter((exam) => exam.date >= today).sort((a, b) => a.date.localeCompare(b.date))[0];
  const streak = completionStreak(data);

  const openTask = (taskId?: string) => navigation.navigate('TaskForm', { taskId, date: selectedDate });
  const focusTask = (taskId: string, subjectId?: string) => {
    startFocus(taskId, subjectId);
    navigation.navigate('Focus');
  };
  const updateWater = (amount: number) => {
    const base: DailyReview = review || {
      date: selectedDate, worked: '', fix: '', gratitude: '', quickNotes: '', distractionNotes: '',
      mood: 0, energy: 0, water: 0, sleepHours: 0, steps: 0, productivity: 0, updatedAt: new Date().toISOString(),
    };
    saveReview({ ...base, water: Math.max(0, Math.min(data.settings.waterGoal, base.water + amount)) });
  };

  return (
    <Screen>
      <FlatList
        data={topThree}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} tintColor={theme.primary} onRefresh={() => {
          setRefreshing(true); setTimeout(() => { setSelectedDate((date) => date); setRefreshing(false); }, 350);
        }} />}
        contentContainerStyle={{ paddingBottom: 32 }}
        ListHeaderComponent={<>
          <Header eyebrow={formatShortDate(selectedDate)} title={`${greeting()}, ${data.settings.name}`}
            subtitle="Small steps. Clear priorities. Real progress."
            right={<IconButton icon="settings-outline" label="Settings" filled onPress={() => navigation.navigate('Settings')} />} />
          <WeekStrip selected={selectedDate} monday={data.settings.weekStartsMonday} onSelect={setSelectedDate} />
          <View style={{ paddingHorizontal: 20, gap: 20 }}>
            <Card style={{ backgroundColor: theme.dark ? '#263D31' : '#244B3E', borderColor: 'transparent', padding: 20 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View>
                  <Text style={{ color: '#C4D8CD', fontSize: 12, fontWeight: '800', letterSpacing: 1 }}>DAILY FOCUS</Text>
                  <Text style={{ color: '#FFFFFF', fontSize: 34, fontWeight: '900', letterSpacing: -1, marginTop: 8 }}>{formatDuration(minutes)}</Text>
                  <Text style={{ color: '#C4D8CD', fontSize: 13, marginTop: 2 }}>of {formatDuration(goal)} intentional work</Text>
                </View>
                <View style={{ backgroundColor: theme.accent, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 7, flexDirection: 'row', gap: 5, alignItems: 'center' }}>
                  <Ionicons name="flame" size={15} color={theme.accentText} /><Text style={{ color: theme.accentText, fontWeight: '900', fontSize: 12 }}>{streak} day streak</Text>
                </View>
              </View>
              <View style={{ height: 9, backgroundColor: '#476A5E', borderRadius: 8, marginVertical: 18, overflow: 'hidden' }}>
                <View style={{ height: 9, width: `${Math.min(100, (minutes / Math.max(1, goal)) * 100)}%`, backgroundColor: theme.accent, borderRadius: 8 }} />
              </View>
              <Pressable onPress={() => navigation.navigate('Focus')} style={({ pressed }) => ({ backgroundColor: theme.accent, borderRadius: 14,
                minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, opacity: pressed ? 0.8 : 1 })}>
                <Ionicons name="play" size={18} color={theme.accentText} /><Text style={{ color: theme.accentText, fontWeight: '900' }}>Start a focus session</Text>
              </Pressable>
            </Card>

            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Card style={{ flex: 1, padding: 14 }}>
                <Ionicons name="checkmark-done" size={20} color={theme.primary} />
                <Text style={{ color: theme.text, fontWeight: '900', fontSize: 21, marginTop: 9 }}>{completed}/{tasks.length}</Text>
                <Text style={{ color: theme.muted, fontSize: 12 }}>blocks completed</Text>
              </Card>
              <Card style={{ flex: 1, padding: 14 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Ionicons name="water" size={20} color="#4D91A8" />
                  <View style={{ flexDirection: 'row' }}>
                    <IconButton icon="remove" size={14} label="Remove water" onPress={() => updateWater(-1)} />
                    <IconButton icon="add" size={14} label="Add water" onPress={() => updateWater(1)} />
                  </View>
                </View>
                <Text style={{ color: theme.text, fontWeight: '900', fontSize: 21, marginTop: 2 }}>{review?.water || 0}/{data.settings.waterGoal}</Text>
                <Text style={{ color: theme.muted, fontSize: 12 }}>glasses of water</Text>
              </Card>
            </View>

            {nextTask && <Card onPress={() => openTask(nextTask.id)} style={{ padding: 15, borderLeftWidth: 4, borderLeftColor: data.subjects.find((s) => s.id === nextTask.subjectId)?.color || theme.primary }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: theme.primarySoft, alignItems: 'center', justifyContent: 'center' }}>
                  <Ionicons name="time-outline" size={22} color={theme.primary} />
                </View>
                <View style={{ flex: 1 }}><Text style={{ color: theme.primary, fontSize: 11, fontWeight: '900', letterSpacing: 0.7 }}>UP NEXT · {formatTime(nextTask.startMinute!)}</Text>
                  <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800', marginTop: 4 }}>{nextTask.title}</Text></View>
                <Ionicons name="chevron-forward" color={theme.muted} size={18} />
              </View>
            </Card>}

            <SectionTitle title="Top 3 — must do" icon="star" action="+ Add" onAction={() => openTask()} />
          </View>
        </>}
        renderItem={({ item, index }) => <View style={{ marginHorizontal: 20, marginBottom: 8 }}>
          <Card style={{ paddingVertical: 3, paddingHorizontal: 14 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Text style={{ color: theme.faint, fontSize: 12, fontWeight: '900', width: 18 }}>0{index + 1}</Text>
              <View style={{ flex: 1 }}><TaskItem task={item} date={selectedDate} subject={data.subjects.find((s) => s.id === item.subjectId)}
                onToggle={() => toggleTask(item.id, selectedDate)} onPress={() => openTask(item.id)} onFocus={() => focusTask(item.id, item.subjectId)} compact /></View>
            </View>
          </Card>
        </View>}
        ListEmptyComponent={<View style={{ marginHorizontal: 20 }}><Card style={{ alignItems: 'center', paddingVertical: 24 }}>
          <Ionicons name="star-outline" size={28} color={theme.primary} />
          <Text style={{ color: theme.text, fontWeight: '800', marginTop: 10 }}>Choose your essential three</Text>
          <Text style={{ color: theme.muted, textAlign: 'center', fontSize: 13, marginTop: 5, lineHeight: 19 }}>Add a study block and mark it as a Top 3 priority.</Text>
          <Button title="Plan a priority" variant="secondary" onPress={() => openTask()} style={{ marginTop: 14 }} />
        </Card></View>}
        ListFooterComponent={<View style={{ paddingHorizontal: 20, paddingTop: 20, gap: 18 }}>
          {nextExam && <Card onPress={() => navigation.navigate('Exams')} style={{ backgroundColor: theme.primarySoft, borderColor: 'transparent' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 13 }}>
              <View style={{ width: 48, height: 48, borderRadius: 15, backgroundColor: theme.surface, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: theme.primary, fontSize: 20, fontWeight: '900' }}>{Math.max(0, Math.ceil((new Date(`${nextExam.date}T12:00:00`).getTime() - new Date(`${today}T12:00:00`).getTime()) / 86400000))}</Text>
              </View>
              <View style={{ flex: 1 }}><Text style={{ color: theme.muted, fontSize: 11, fontWeight: '800' }}>DAYS TO NEXT EXAM</Text>
                <Text style={{ color: theme.text, fontSize: 15, fontWeight: '800', marginTop: 3 }}>{nextExam.title}</Text>
                <Text style={{ color: theme.muted, fontSize: 12, marginTop: 2 }}>{formatShortDate(nextExam.date)} · {nextExam.time}</Text></View>
              <Ionicons name="chevron-forward" size={18} color={theme.primary} />
            </View>
          </Card>}
          <Card onPress={() => navigation.navigate('Review')} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Ionicons name="moon-outline" size={24} color={theme.primary} />
            <View style={{ flex: 1 }}><Text style={{ color: theme.text, fontWeight: '800' }}>Evening review</Text>
              <Text style={{ color: theme.muted, fontSize: 12, marginTop: 4 }}>Reflect, reset, and seed tomorrow’s Top 3.</Text></View>
            <Badge text={review ? 'SAVED' : '2 MIN'} />
          </Card>
          <Text style={{ color: theme.faint, fontSize: 12, textAlign: 'center', fontStyle: 'italic', paddingVertical: 6 }}>“Small steps every day lead to big results.”</Text>
        </View>}
      />
    </Screen>
  );
}
