import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createSeedData } from '../data/seed';
import { getSupabase } from '../lib/supabase';
import {
  AppData, AppSettings, DailyReview, Exam, FocusSession, StudyTask, Subject,
  SyncStrategy, TimerMode, TimerState,
} from '../types';
import { addDays, makeId, nowMinutes, todayKey } from '../utils/date';
import { isTaskComplete, occursOn } from '../utils/selectors';

const DATA_KEY = '@focusflow_data_v1';
const TIMER_KEY = '@focusflow_timer_v1';

interface AppContextValue {
  data: AppData;
  hydrated: boolean;
  timer: TimerState;
  syncStatus: 'idle' | 'syncing' | 'success' | 'error';
  syncMessage: string;
  saveTask: (task: StudyTask) => void;
  deleteTask: (id: string) => void;
  toggleTask: (id: string, date: string) => void;
  toggleTopThree: (id: string, date: string) => void;
  autoSchedule: (date: string) => number;
  saveSubject: (subject: Subject) => void;
  deleteSubject: (id: string) => void;
  saveExam: (exam: Exam) => void;
  deleteExam: (id: string) => void;
  saveReview: (review: DailyReview) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  resetData: () => void;
  restoreSampleData: () => void;
  syncCloud: (strategy?: SyncStrategy) => Promise<string>;
  startFocus: (taskId?: string, subjectId?: string, cycle?: number) => void;
  startBreak: (mode: 'shortBreak' | 'longBreak', cycle?: number) => void;
  pauseTimer: () => void;
  resumeTimer: () => void;
  resetTimer: () => void;
  finishTimer: (early?: boolean) => void;
  addDistraction: (text: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const idleTimer: TimerState = {
  mode: 'focus', durationSeconds: 25 * 60, remainingSeconds: 25 * 60,
  isRunning: false, cycle: 0, distractions: [],
};

function remainingFor(timer: TimerState): number {
  if (!timer.isRunning || !timer.endAt) return timer.remainingSeconds;
  return Math.max(0, Math.ceil((timer.endAt - Date.now()) / 1000));
}

function validCloudData(value: unknown): value is AppData {
  if (!value || typeof value !== 'object') return false;
  const data = value as Partial<AppData>;
  return Array.isArray(data.tasks) && Array.isArray(data.subjects) && Array.isArray(data.sessions)
    && Array.isArray(data.reviews) && Array.isArray(data.exams) && Boolean(data.settings);
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData>(() => createSeedData());
  const [hydrated, setHydrated] = useState(false);
  const [timer, setTimer] = useState<TimerState>(idleTimer);
  const [syncStatus, setSyncStatus] = useState<AppContextValue['syncStatus']>('idle');
  const [syncMessage, setSyncMessage] = useState('Not synced yet');
  const dataRef = useRef(data);
  const timerRef = useRef(timer);
  const syncingRef = useRef(false);
  dataRef.current = data;
  timerRef.current = timer;

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const [storedData, storedTimer] = await Promise.all([
          AsyncStorage.getItem(DATA_KEY), AsyncStorage.getItem(TIMER_KEY),
        ]);
        if (!mounted) return;
        if (storedData) {
          const parsed = JSON.parse(storedData) as AppData;
          if (validCloudData(parsed)) {
            const seed = createSeedData();
            setData({
              ...seed, ...parsed,
              settings: { ...seed.settings, ...parsed.settings },
              meta: { ...seed.meta, ...parsed.meta },
            });
          }
        }
        if (storedTimer) {
          const parsedTimer = { ...idleTimer, ...JSON.parse(storedTimer) } as TimerState;
          setTimer(parsedTimer);
        }
      } catch {
        // A damaged local cache should never prevent the planner from opening.
      } finally {
        if (mounted) setHydrated(true);
      }
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(DATA_KEY, JSON.stringify(data)).catch(() => undefined);
  }, [data, hydrated]);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(TIMER_KEY, JSON.stringify(timer)).catch(() => undefined);
  }, [timer, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    const seconds = data.settings.focusMinutes * 60;
    setTimer((previous) => !previous.startedAt && !previous.isRunning && previous.mode === 'focus'
      ? { ...previous, durationSeconds: seconds, remainingSeconds: seconds }
      : previous);
  }, [data.settings.focusMinutes, hydrated]);

  const mutate = useCallback((recipe: (previous: AppData) => AppData) => {
    setData((previous) => {
      const next = recipe(previous);
      return { ...next, meta: { ...next.meta, updatedAt: new Date().toISOString(), dirty: true } };
    });
  }, []);

  const saveTask = useCallback((task: StudyTask) => {
    mutate((previous) => {
      const exists = previous.tasks.some((item) => item.id === task.id);
      const nextTask = { ...task, updatedAt: new Date().toISOString() };
      return { ...previous, tasks: exists
        ? previous.tasks.map((item) => item.id === task.id ? nextTask : item)
        : [nextTask, ...previous.tasks] };
    });
  }, [mutate]);

  const deleteTask = useCallback((id: string) => {
    mutate((previous) => ({ ...previous, tasks: previous.tasks.filter((task) => task.id !== id) }));
  }, [mutate]);

  const toggleTask = useCallback((id: string, date: string) => {
    mutate((previous) => ({
      ...previous,
      tasks: previous.tasks.map((task) => {
        if (task.id !== id) return task;
        const done = task.completedDates.includes(date);
        return { ...task, completedDates: done
          ? task.completedDates.filter((item) => item !== date)
          : [...task.completedDates, date], updatedAt: new Date().toISOString() };
      }),
    }));
  }, [mutate]);

  const toggleTopThree = useCallback((id: string, date: string) => {
    mutate((previous) => {
      const selectedCount = previous.tasks.filter((task) => task.id !== id && task.topThreeDates.includes(date)).length;
      return {
        ...previous,
        tasks: previous.tasks.map((task) => {
          if (task.id !== id) return task;
          const included = task.topThreeDates.includes(date);
          if (!included && selectedCount >= 3) return task;
          return { ...task, topThreeDates: included
            ? task.topThreeDates.filter((item) => item !== date)
            : [...task.topThreeDates, date] };
        }),
      };
    });
  }, [mutate]);

  const autoSchedule = useCallback((date: string) => {
    const current = dataRef.current;
    const todaysTasks = current.tasks.filter((task) => occursOn(task, date));
    const unscheduled = todaysTasks.filter((task) => task.startMinute === undefined && !isTaskComplete(task, date));
    if (!unscheduled.length) return 0;
    const updates = new Map<string, number>();
    let cursor = date === todayKey() ? Math.max(300, Math.ceil((nowMinutes() + 30) / 30) * 30) : 390;
    const priorityWeight = { high: 0, medium: 1, low: 2 };
    [...unscheduled].sort((a, b) => priorityWeight[a.priority] - priorityWeight[b.priority]).forEach((task) => {
      const scheduled = todaysTasks.filter((item) => item.startMinute !== undefined || updates.has(item.id));
      while (cursor + task.durationMinutes <= 1320) {
        const overlaps = scheduled.some((item) => {
          const start = updates.get(item.id) ?? item.startMinute ?? -1;
          return cursor < start + item.durationMinutes && start < cursor + task.durationMinutes;
        });
        if (!overlaps) break;
        cursor += 30;
      }
      if (cursor + task.durationMinutes <= 1320) {
        updates.set(task.id, cursor);
        cursor += Math.max(30, Math.ceil(task.durationMinutes / 30) * 30);
      }
    });
    if (updates.size) {
      mutate((previous) => ({
        ...previous,
        tasks: previous.tasks.map((task) => updates.has(task.id)
          ? { ...task, startMinute: updates.get(task.id), updatedAt: new Date().toISOString() } : task),
      }));
    }
    return updates.size;
  }, [mutate]);

  const saveSubject = useCallback((subject: Subject) => {
    mutate((previous) => ({ ...previous, subjects: previous.subjects.some((item) => item.id === subject.id)
      ? previous.subjects.map((item) => item.id === subject.id ? subject : item)
      : [...previous.subjects, subject] }));
  }, [mutate]);

  const deleteSubject = useCallback((id: string) => {
    mutate((previous) => ({
      ...previous,
      subjects: previous.subjects.filter((subject) => subject.id !== id),
      tasks: previous.tasks.map((task) => task.subjectId === id ? { ...task, subjectId: undefined } : task),
      exams: previous.exams.map((exam) => exam.subjectId === id ? { ...exam, subjectId: undefined } : exam),
    }));
  }, [mutate]);

  const saveExam = useCallback((exam: Exam) => {
    mutate((previous) => ({ ...previous, exams: previous.exams.some((item) => item.id === exam.id)
      ? previous.exams.map((item) => item.id === exam.id ? exam : item)
      : [...previous.exams, exam] }));
  }, [mutate]);

  const deleteExam = useCallback((id: string) => {
    mutate((previous) => ({ ...previous, exams: previous.exams.filter((exam) => exam.id !== id) }));
  }, [mutate]);

  const saveReview = useCallback((review: DailyReview) => {
    mutate((previous) => ({ ...previous, reviews: previous.reviews.some((item) => item.date === review.date)
      ? previous.reviews.map((item) => item.date === review.date ? { ...review, updatedAt: new Date().toISOString() } : item)
      : [...previous.reviews, { ...review, updatedAt: new Date().toISOString() }] }));
  }, [mutate]);

  const updateSettings = useCallback((settings: Partial<AppSettings>) => {
    mutate((previous) => ({ ...previous, settings: { ...previous.settings, ...settings } }));
  }, [mutate]);

  const resetData = useCallback(() => {
    setData((previous) => ({
      tasks: [], subjects: [], sessions: [], reviews: [], exams: [],
      settings: previous.settings,
      meta: { updatedAt: new Date().toISOString(), dirty: true },
    }));
    setTimer(idleTimer);
  }, []);

  const restoreSampleData = useCallback(() => {
    setData((previous) => ({ ...createSeedData(), settings: { ...createSeedData().settings, ...previous.settings } }));
  }, []);

  const syncCloud = useCallback(async (strategy: SyncStrategy = 'sync'): Promise<string> => {
    if (syncingRef.current) throw new Error('A sync is already in progress.');
    syncingRef.current = true;
    setSyncStatus('syncing');
    setSyncMessage('Connecting to Supabase…');
    try {
      const supabase = await getSupabase();
      if (!supabase) throw new Error('Add your Supabase URL and anon key first.');
      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError || !userData.user) throw new Error('Sign in to your Supabase account first.');
      const upload = async () => {
        const timestamp = new Date().toISOString();
        const snapshot = dataRef.current;
        const snapshotUpdatedAt = snapshot.meta.updatedAt;
        const payload = { ...snapshot, meta: { ...snapshot.meta, dirty: false, lastSyncedAt: timestamp } };
        const { error } = await supabase.from('focusflow_state').upsert({
          user_id: userData.user!.id, data: payload, updated_at: timestamp,
        });
        if (error) throw new Error(error.message);
        setData((previous) => ({ ...previous, meta: {
          ...previous.meta,
          dirty: previous.meta.updatedAt !== snapshotUpdatedAt,
          lastSyncedAt: timestamp,
        } }));
        return 'Uploaded securely to Supabase.';
      };
      const download = async () => {
        const { data: row, error } = await supabase.from('focusflow_state').select('data,updated_at').maybeSingle();
        if (error) throw new Error(error.message);
        if (!row || !validCloudData(row.data)) throw new Error('No valid cloud backup exists yet. Upload this device first.');
        const incoming = row.data as AppData;
        setData({
          ...incoming,
          settings: { ...createSeedData().settings, ...incoming.settings },
          meta: { ...incoming.meta, updatedAt: row.updated_at, lastSyncedAt: row.updated_at, dirty: false },
        });
        return 'Cloud data downloaded to this device.';
      };
      let message: string;
      if (strategy === 'upload') message = await upload();
      else if (strategy === 'download') message = await download();
      else {
        const { data: row, error } = await supabase.from('focusflow_state').select('data,updated_at').maybeSingle();
        if (error) throw new Error(error.message);
        if (!row) message = await upload();
        else if (new Date(row.updated_at).getTime() > new Date(dataRef.current.meta.updatedAt).getTime() && validCloudData(row.data)) {
          const incoming = row.data as AppData;
          setData({ ...incoming, settings: { ...createSeedData().settings, ...incoming.settings },
            meta: { ...incoming.meta, updatedAt: row.updated_at, lastSyncedAt: row.updated_at, dirty: false } });
          message = 'Downloaded the newer cloud version.';
        } else message = await upload();
      }
      setSyncStatus('success');
      setSyncMessage(message);
      return message;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Sync failed. Check your connection and SQL setup.';
      setSyncStatus('error');
      setSyncMessage(message);
      throw new Error(message);
    } finally {
      syncingRef.current = false;
    }
  }, []);

  const startFocus = useCallback((taskId?: string, subjectId?: string, cycle = 0) => {
    if (timerRef.current.startedAt && remainingFor(timerRef.current) > 0) return;
    const task = dataRef.current.tasks.find((item) => item.id === taskId);
    const seconds = dataRef.current.settings.focusMinutes * 60;
    const now = Date.now();
    setTimer({
      mode: 'focus', taskId, subjectId: subjectId || task?.subjectId, durationSeconds: seconds,
      remainingSeconds: seconds, endAt: now + seconds * 1000, isRunning: true,
      startedAt: new Date(now).toISOString(), cycle, distractions: [],
    });
  }, []);

  const startBreak = useCallback((mode: 'shortBreak' | 'longBreak', cycle = 0) => {
    const settings = dataRef.current.settings;
    const seconds = (mode === 'longBreak' ? settings.longBreakMinutes : settings.shortBreakMinutes) * 60;
    setTimer({ mode, durationSeconds: seconds, remainingSeconds: seconds, endAt: Date.now() + seconds * 1000,
      isRunning: true, startedAt: new Date().toISOString(), cycle, distractions: [] });
  }, []);

  const pauseTimer = useCallback(() => {
    setTimer((previous) => ({ ...previous, remainingSeconds: remainingFor(previous), isRunning: false, endAt: undefined }));
  }, []);

  const resumeTimer = useCallback(() => {
    setTimer((previous) => ({ ...previous, endAt: Date.now() + previous.remainingSeconds * 1000, isRunning: true }));
  }, []);

  const resetTimer = useCallback(() => setTimer((previous) => ({
    ...idleTimer, durationSeconds: dataRef.current.settings.focusMinutes * 60,
    remainingSeconds: dataRef.current.settings.focusMinutes * 60, cycle: previous.cycle,
  })), []);

  const finishTimer = useCallback((early = false) => {
    const current = timerRef.current;
    if (!current.startedAt) return;
    const remaining = early ? remainingFor(current) : 0;
    const elapsedSeconds = Math.max(0, current.durationSeconds - remaining);
    if (current.mode === 'focus' && elapsedSeconds >= 30) {
      const endedAt = new Date().toISOString();
      const session: FocusSession = {
        id: makeId('session'), taskId: current.taskId, subjectId: current.subjectId,
        startedAt: current.startedAt, endedAt, plannedMinutes: Math.round(current.durationSeconds / 60),
        actualMinutes: Math.max(1, Math.round(elapsedSeconds / 60)), completed: !early && remaining === 0,
        distractions: current.distractions,
      };
      mutate((previous) => ({ ...previous, sessions: [...previous.sessions, session] }));
    }
    setTimer({ ...current, isRunning: false, endAt: undefined, remainingSeconds: 0 });
  }, [mutate]);

  const addDistraction = useCallback((text: string) => {
    const clean = text.trim();
    if (!clean) return;
    setTimer((previous) => ({ ...previous, distractions: [...previous.distractions, clean] }));
  }, []);

  const syncRef = useRef(syncCloud);
  syncRef.current = syncCloud;
  useEffect(() => {
    if (!hydrated || !data.settings.autoSync || !data.meta.dirty) return;
    const timeout = setTimeout(() => {
      syncRef.current('sync').catch(() => undefined);
    }, 12000);
    return () => clearTimeout(timeout);
  }, [data.meta.updatedAt, data.meta.dirty, data.settings.autoSync, hydrated]);

  return (
    <AppContext.Provider value={{
      data, hydrated, timer, syncStatus, syncMessage,
      saveTask, deleteTask, toggleTask, toggleTopThree, autoSchedule,
      saveSubject, deleteSubject, saveExam, deleteExam, saveReview, updateSettings,
      resetData, restoreSampleData, syncCloud,
      startFocus, startBreak, pauseTimer, resumeTimer, resetTimer, finishTimer, addDistraction,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside AppProvider');
  return context;
}
