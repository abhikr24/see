export type Priority = 'low' | 'medium' | 'high';
export type Recurrence = 'none' | 'daily' | 'weekdays' | 'weekly';
export type ThemeMode = 'system' | 'light' | 'dark';

export interface Subject {
  id: string;
  name: string;
  color: string;
  icon: string;
  weeklyGoalMinutes: number;
  archived: boolean;
  createdAt: string;
}

export interface StudyTask {
  id: string;
  title: string;
  notes: string;
  subjectId?: string;
  date: string;
  startMinute?: number;
  durationMinutes: number;
  estimatedPomodoros: number;
  priority: Priority;
  recurrence: Recurrence;
  completedDates: string[];
  topThreeDates: string[];
  createdAt: string;
  updatedAt: string;
}

export interface FocusSession {
  id: string;
  taskId?: string;
  subjectId?: string;
  startedAt: string;
  endedAt: string;
  plannedMinutes: number;
  actualMinutes: number;
  completed: boolean;
  distractions: string[];
}

export interface DailyReview {
  date: string;
  worked: string;
  fix: string;
  gratitude: string;
  quickNotes: string;
  distractionNotes: string;
  mood: number;
  energy: number;
  water: number;
  sleepHours: number;
  steps: number;
  productivity: number;
  updatedAt: string;
}

export interface Exam {
  id: string;
  title: string;
  subjectId?: string;
  date: string;
  time: string;
  syllabus: string;
  createdAt: string;
}

export interface AppSettings {
  name: string;
  focusMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakEvery: number;
  dailyGoalMinutes: number;
  waterGoal: number;
  theme: ThemeMode;
  autoSync: boolean;
  weekStartsMonday: boolean;
}

export interface AppData {
  tasks: StudyTask[];
  subjects: Subject[];
  sessions: FocusSession[];
  reviews: DailyReview[];
  exams: Exam[];
  settings: AppSettings;
  meta: {
    updatedAt: string;
    lastSyncedAt?: string;
    dirty: boolean;
  };
}

export type TimerMode = 'focus' | 'shortBreak' | 'longBreak';

export interface TimerState {
  mode: TimerMode;
  taskId?: string;
  subjectId?: string;
  durationSeconds: number;
  remainingSeconds: number;
  endAt?: number;
  isRunning: boolean;
  startedAt?: string;
  cycle: number;
  distractions: string[];
}

export type SyncStrategy = 'sync' | 'upload' | 'download';
