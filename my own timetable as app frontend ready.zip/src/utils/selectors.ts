import { AppData, DailyReview, FocusSession, StudyTask } from '../types';
import { addDays, dateFromIso, todayKey, weekDates } from './date';

export function occursOn(task: StudyTask, date: string): boolean {
  if (task.recurrence === 'none') return task.date === date;
  if (date < task.date) return false;
  if (task.recurrence === 'daily') return true;
  if (task.recurrence === 'weekdays') {
    const day = new Date(`${date}T12:00:00`).getDay();
    return day !== 0 && day !== 6;
  }
  if (task.recurrence === 'weekly') {
    return new Date(`${date}T12:00:00`).getDay() === new Date(`${task.date}T12:00:00`).getDay();
  }
  return false;
}

export function isTaskComplete(task: StudyTask, date: string): boolean {
  return task.completedDates.includes(date);
}

export function tasksForDate(tasks: StudyTask[], date: string): StudyTask[] {
  return tasks.filter((task) => occursOn(task, date)).sort((a, b) => {
    const aTime = a.startMinute ?? 2000;
    const bTime = b.startMinute ?? 2000;
    return aTime - bTime || a.title.localeCompare(b.title);
  });
}

export function sessionsForDate(sessions: FocusSession[], date: string): FocusSession[] {
  return sessions.filter((session) => dateFromIso(session.startedAt) === date);
}

export function focusMinutesForDate(sessions: FocusSession[], date: string): number {
  return sessionsForDate(sessions, date).reduce((sum, session) => sum + session.actualMinutes, 0);
}

export function reviewForDate(reviews: DailyReview[], date: string): DailyReview | undefined {
  return reviews.find((review) => review.date === date);
}

export function focusStreak(sessions: FocusSession[]): number {
  let streak = 0;
  let cursor = todayKey();
  if (focusMinutesForDate(sessions, cursor) === 0) cursor = addDays(cursor, -1);
  while (focusMinutesForDate(sessions, cursor) > 0 && streak < 3660) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

export function completionStreak(data: AppData): number {
  let streak = 0;
  let cursor = todayKey();
  const hasWin = (date: string) => {
    const tasks = tasksForDate(data.tasks, date);
    return focusMinutesForDate(data.sessions, date) > 0 || tasks.some((task) => isTaskComplete(task, date));
  };
  if (!hasWin(cursor)) cursor = addDays(cursor, -1);
  while (hasWin(cursor) && streak < 3660) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

export function weekFocusMinutes(data: AppData, anchor: string): number {
  return weekDates(anchor, data.settings.weekStartsMonday)
    .reduce((sum, date) => sum + focusMinutesForDate(data.sessions, date), 0);
}
