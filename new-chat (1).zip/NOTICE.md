# Third-party notices

PDF2Play only ships dependencies under permissive licences (MIT / Apache-2.0 / ISC / BSD). No AGPL or GPL code (for example PyMuPDF or marker) is vendored or linked.

| Package | Licence | Use |
|---|---|---|
| next | MIT | Framework (App Router) |
| react, react-dom | MIT | UI |
| typescript | Apache-2.0 | Type checking |
| tailwindcss, @tailwindcss/postcss, postcss | MIT | Styling |
| @radix-ui/react-dialog, @radix-ui/react-accordion, @radix-ui/react-slot | MIT | shadcn/ui primitives |
| class-variance-authority, clsx, tailwind-merge | Apache-2.0, MIT, MIT | Class utilities |
| lucide-react | ISC | Icons |
| framer-motion | MIT | Animation |
| **pdfjs-dist** (4.10.38) | **Apache-2.0** | Client-side PDF text extraction in a Web Worker. `pdf.min.mjs` and `pdf.worker.min.mjs` are copied unmodified into `public/pdfjs/` together with its LICENSE |
| **pdf-lib** | **MIT** | PDF structure checks (page count, encryption) |
| **zod** | **MIT** | Runtime validation of model output, API bodies and postMessage payloads |
| @supabase/supabase-js, @supabase/ssr | MIT | Database, auth |
| server-only | MIT | Prevents server code in client bundles |
| dotenv | BSD-2-Clause | Env loading for scripts |
| tsx | MIT | Runs `scripts/verify-setup.ts` |
| drizzle-orm, drizzle-kit, pg | Apache-2.0, MIT, MIT | Template health-check database connection only |
| eslint, eslint-config-next | MIT | Linting |

Services (not bundled): Supabase, DeepSeek API, Razorpay, Vercel - used under their own terms.

Optional components considered but **not** included: docling (MIT), GROBID (Apache-2.0), tesseract.js (Apache-2.0). OCR is therefore not available; pages without extractable text are reported and skipped.
