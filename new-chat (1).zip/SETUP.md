# PDF2Play - 10 minute setup runbook

You need: Node 20+, pnpm (or npm), and free accounts at Supabase, DeepSeek and Razorpay (test mode).

## 1. Create the Supabase project (2 min)
1. supabase.com > New project. Save the database password.
2. Project Settings > API: copy **Project URL**, **anon key**, **service_role key**.

## 2. Run the two SQL files (1 min)
SQL Editor > New query. Paste and run, in this order:
1. `supabase/01_schema.sql` - tables, `payment_status` enum, new-user trigger (profile with 3 free credits).
2. `supabase/02_rls_and_functions.sql` - RLS on every table, `increment_usage()`, `mark_payment_paid()`, `apply_refund()`, `hit_rate_limit()` (all SECURITY DEFINER, service role only).

## 3. Auth: magic link + Google (2 min)
1. Authentication > URL Configuration: **Site URL** = `http://localhost:3000`; **Redirect URLs** add `http://localhost:3000/auth/callback` (and later `https://YOUR-APP.vercel.app/auth/callback`).
2. Authentication > Providers: **Email** is on by default (magic link). For **Google**: create an OAuth client in Google Cloud Console (Web), set the authorised redirect URI to `https://YOUR-PROJECT.supabase.co/auth/v1/callback`, paste Client ID/Secret into Supabase > Providers > Google.

## 4. Razorpay TEST keys + webhook (2 min)
1. Razorpay Dashboard, switch to **Test Mode** > Account & Settings > API Keys > Generate. Copy `rzp_test_...` id and secret.
2. Settings > Webhooks > Add: URL `https://YOUR-PUBLIC-URL/api/razorpay/webhook` (locally use a tunnel such as `ngrok http 3000`), choose a secret, enable **payment.captured**, **payment.failed**, **refund.processed**.
3. Webhook secret = `RAZORPAY_WEBHOOK_SECRET`.

## 5. DeepSeek key (1 min)
platform.deepseek.com > API keys > Create. Copy it into `DEEPSEEK_API_KEY`.

## 6. Environment (1 min)
```bash
cp .env.example .env.local
# fill every value (each variable is documented in the file)
```

## 7. Run it (1 min)
```bash
pnpm install
npx tsx scripts/verify-setup.ts   # prints a pass/fail line for every service
pnpm dev                          # http://localhost:3000
```

## 8. Test a payment
1. Sign in with a magic link, open the dashboard, click **Upgrade to Pro**.
2. In Razorpay Checkout use card `4111 1111 1111 1111`, any future expiry, CVV `123`, OTP `1234`.
3. You return to the dashboard with "Payment confirmed". Plan = Pro, 300 games.
4. Replay safety: resend the `payment.captured` event from Razorpay > Webhooks > Logs. Credits do not change (`webhook_events` + `mark_payment_paid()` are idempotent).

Without Razorpay keys the pricing buttons become **Notify me** and store emails in `notify_requests`.

## 9. Check the sandbox
Open `/sandbox-test`. Every line (fetch, parent.document, top navigation, storage, cookies) must say **blocked**.

## 10. Deploy to Vercel
1. Push to GitHub, import in Vercel (framework: Next.js).
2. Add all variables from `.env.example` (`NEXT_PUBLIC_APP_URL` = your Vercel URL). Use **live** Razorpay keys only when you are ready.
3. Add the production URL to Supabase Redirect URLs and the Razorpay webhook URL.
4. `/api/generate` streams for up to 300 s (`maxDuration = 300`); this needs a Vercel plan that allows it (Pro, or Hobby with Fluid compute).

## Pipeline notes
- The PDF is validated (MIME, `%PDF-` bytes, 20MB, 30 pages, encryption) and read with pdfjs-dist in a Web Worker (`public/pdfjs/extract.worker.mjs`). Only extracted text is sent to the server.
- Server: brief (map-reduce when over ~22k tokens) > Stage A plan (zod, chunked per ~10 pages) > anti-shortcut repair (max 2) > Stage B game script > quote verification (85% token overlap + bigram order check) > one regeneration if more than 20% were dropped.
- If the model-written game script fails static checks, or never posts `ready` within 6 s, the player silently uses the built-in engine, which implements all six game types.
- Cache: the same PDF text + game type + difficulty hash reuses the game stored in the browser (INR 0).
- Cost guards: per-run ceiling, daily ceiling per plan, and an INR 8 per month ceiling for free users (`src/lib/plans.ts`).

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Redirected to `/login?error=not_configured` | Supabase env vars missing | Fill `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`, restart `pnpm dev` |
| Magic link opens `/login?error=auth` | Redirect URL not allow-listed, or link opened in a different browser than where you requested it (PKCE) | Add `.../auth/callback` to Supabase Redirect URLs; open the link in the same browser |
| Google sign-in: `redirect_uri_mismatch` | Google client missing Supabase callback | Add `https://PROJECT.supabase.co/auth/v1/callback` to the Google OAuth client |
| `new row violates row-level security policy` | Client tried to write a service-role-only table, or RLS SQL not run | Writes to `payments`, `subscriptions`, `usage_counters`, `generations` go through server routes; run file 02 |
| `plan, credits and period are managed by the server` | A client tried to change its own entitlement columns | Expected: only the service role can. Use the payment flow |
| `/api/generate` 503 `server_misconfigured` | `SUPABASE_SERVICE_ROLE_KEY` missing or SQL file 02 not run (`increment_usage` missing) | Set the key; run `02_rls_and_functions.sql` |
| `/api/generate` 503 `ai_unconfigured` | `DEEPSEEK_API_KEY` missing | Set it |
| 402 on a free user's 4th game | Working as designed: quota reached, upgrade prompt shown | Upgrade, or wait for the 30-day period reset |
| Webhook returns 400 `Invalid signature` | Wrong `RAZORPAY_WEBHOOK_SECRET`, or body modified by a proxy | The route reads the raw body; make sure the secret matches the dashboard and no middleware re-serialises JSON |
| Webhook returns 503 | `RAZORPAY_WEBHOOK_SECRET` or Supabase service key missing | Set both |
| Payment succeeded but plan not active | `verify` failed (network) | The webhook grants it; check `payments.status` and `webhook_events` |
| Checkout button says **Notify me** | Razorpay keys absent | Set `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` and restart |
| "The PDF reader worker failed to load" | `/pdfjs/*.mjs` not served or blocked by a CDN/CSP rule | Make sure `public/pdfjs/pdf.min.mjs`, `pdf.worker.min.mjs`, `extract.worker.mjs` exist; allow `worker-src 'self'` |
| `Setting up fake worker failed` in console | Browser lacks nested module workers | Use a current Chrome, Edge, Firefox or Safari 16+ |
| "No extractable text was found" | Scanned PDF (images only) | OCR is not built; export a text-based PDF |
| Game area stays blank | Model-written script failed | The player falls back to the built-in engine after 6 s; use **Report** if it persists |
