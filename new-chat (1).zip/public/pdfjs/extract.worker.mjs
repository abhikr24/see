// PDF2Play extraction worker (runs pdfjs-dist, Apache-2.0, off the main thread).
// Input : { buffer: ArrayBuffer, maxPages: number }
// Output: { type: 'progress', page, total } ... { type: 'done', pages: PageExtract[] } | { type: 'error', code, message }
import * as pdfjs from "./pdf.min.mjs";

pdfjs.GlobalWorkerOptions.workerSrc = new URL("./pdf.worker.min.mjs", import.meta.url).href;

const BULLET = /^\s*([\u2022\u25AA\u25CF\u25CB\u2013\-*]|\d{1,2}[.)]|[a-zA-Z][.)])\s+\S/;
const CAPTION = /^(figure|fig\.|table|chart|diagram|image|source)\s*\d*[.:)]?\s/i;
const FOOTNOTE = /^(\d{1,2}|\*|\u2020|\u2021)\s?\S/;

function median(nums) {
  if (!nums.length) return 0;
  const s = nums.slice().sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

function buildLines(items) {
  const lines = [];
  let cur = null;
  for (const it of items) {
    if (typeof it.str !== "string") continue;
    const size = Math.hypot(it.transform[0], it.transform[1]) || it.height || 0;
    const y = it.transform[5];
    if (cur && Math.abs(y - cur.y) <= Math.max(2, size * 0.45)) {
      cur.text += it.str;
      cur.size = Math.max(cur.size, size);
      cur.chars += it.str.length;
    } else {
      if (cur) lines.push(cur);
      cur = { text: it.str, size, y, chars: it.str.length };
    }
    if (it.hasEOL && cur) {
      lines.push(cur);
      cur = null;
    }
  }
  if (cur) lines.push(cur);
  return lines
    .map((l) => ({ ...l, text: l.text.replace(/\s+/g, " ").trim() }))
    .filter((l) => l.text.length > 0);
}

async function run(buffer, maxPages) {
  const task = pdfjs.getDocument({ data: new Uint8Array(buffer), isEvalSupported: false, disableFontFace: true });
  const doc = await task.promise;
  const total = doc.numPages;
  if (total > maxPages) {
    self.postMessage({ type: "error", code: "too_many_pages", message: `This PDF has ${total} pages. The limit is ${maxPages}.` });
    return;
  }
  const pages = [];
  for (let p = 1; p <= total; p++) {
    const page = await doc.getPage(p);
    const viewport = page.getViewport({ scale: 1 });
    const content = await page.getTextContent();
    const lines = buildLines(content.items);
    const sizes = [];
    for (const l of lines) for (let i = 0; i < Math.min(l.chars, 200); i++) sizes.push(l.size);
    const med = median(sizes);
    const headings = [];
    const lists = [];
    const captions = [];
    const footnotes = [];
    for (const l of lines) {
      const isCaption = CAPTION.test(l.text);
      if (isCaption) captions.push(l.text.slice(0, 200));
      else if (l.y < viewport.height * 0.12 && l.size < med * 0.92 && FOOTNOTE.test(l.text)) footnotes.push(l.text.slice(0, 240));
      else if (med > 0 && l.size >= med * 1.18 && l.text.length >= 3 && l.text.length <= 120) headings.push(l.text);
      else if (BULLET.test(l.text)) lists.push(l.text.slice(0, 240));
    }
    const text = lines
      .map((l) => l.text)
      .join("\n")
      .replace(/(\w)-\n(\w)/g, "$1$2")
      .replace(/[ \t]+/g, " ")
      .trim();
    pages.push({
      page: p,
      text,
      chars: text.length,
      headings: headings.slice(0, 8),
      lists: lists.slice(0, 20),
      captions: captions.slice(0, 6),
      footnotes: footnotes.slice(0, 6),
      needsOCR: text.length < 50,
    });
    page.cleanup();
    self.postMessage({ type: "progress", page: p, total });
  }
  await doc.destroy();
  self.postMessage({ type: "done", pages });
}

self.onmessage = async (e) => {
  try {
    await run(e.data.buffer, e.data.maxPages);
  } catch (err) {
    const name = err && err.name ? String(err.name) : "";
    if (name === "PasswordException") {
      self.postMessage({ type: "error", code: "encrypted", message: "This PDF is password-protected. Remove the password and try again." });
    } else {
      self.postMessage({ type: "error", code: "parse_failed", message: "We could not read this PDF. It may be corrupted." });
    }
  }
};
