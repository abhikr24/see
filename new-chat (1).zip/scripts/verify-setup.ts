/**
 * Prints a pass/fail line per service. Run: npx tsx scripts/verify-setup.ts
 * Reads .env.local (then .env). Makes only read-only calls (plus one rate-limit counter bump).
 */
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { join } from "node:path";

config({ path: ".env.local" });
config({ path: ".env" });

let failures = 0;
function report(ok: boolean, label: string, hint = ""): void {
  if (!ok) failures++;
  console.log((ok ? "\u2705 " : "\u274C ") + label + (ok || !hint ? "" : "\n     -> " + hint));
}

const env = (k: string): string => process.env[k] ?? "";

async function checkSupabase(): Promise<void> {
  const url = env("NEXT_PUBLIC_SUPABASE_URL");
  const anon = env("NEXT_PUBLIC_SUPABASE_ANON_KEY");
  const service = env("SUPABASE_SERVICE_ROLE_KEY");
  report(Boolean(url && anon), "Supabase URL + anon key set", "Fill NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in .env.local");
  report(Boolean(service), "Supabase service-role key set", "Fill SUPABASE_SERVICE_ROLE_KEY (server only)");
  if (!url || !service) return;
  const headers = { apikey: service, Authorization: "Bearer " + service };
  for (const table of ["profiles", "games", "generations", "subscriptions", "payments", "usage_counters", "webhook_events"]) {
    try {
      const res = await fetch(url + "/rest/v1/" + table + "?select=*&limit=1", { headers });
      report(res.ok, "Table public." + table + " exists", "Run supabase/01_schema.sql in the SQL editor (HTTP " + res.status + ")");
    } catch {
      report(false, "Table public." + table, "Could not reach Supabase. Check NEXT_PUBLIC_SUPABASE_URL");
    }
  }
  try {
    const res = await fetch(url + "/rest/v1/rpc/hit_rate_limit", {
      method: "POST",
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({ p_key: "verify-setup", p_window_seconds: 60, p_max: 1000 }),
    });
    report(res.ok, "SQL function hit_rate_limit() callable by service role", "Run supabase/02_rls_and_functions.sql (HTTP " + res.status + ")");
  } catch {
    report(false, "SQL function hit_rate_limit()");
  }
  if (anon) {
    try {
      const res = await fetch(url + "/rest/v1/payments?select=id&limit=1", { headers: { apikey: anon, Authorization: "Bearer " + anon } });
      const rows = res.ok ? ((await res.json()) as unknown[]) : [];
      report(res.ok && rows.length === 0, "RLS: anonymous users cannot read payments", "Enable RLS: run supabase/02_rls_and_functions.sql");
      const wr = await fetch(url + "/rest/v1/payments", {
        method: "POST",
        headers: { apikey: anon, Authorization: "Bearer " + anon, "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: "00000000-0000-0000-0000-000000000000", plan: "pro", amount_paise: 1, razorpay_order_id: "rls_probe" }),
      });
      report(!wr.ok, "RLS: anonymous users cannot write payments", "payments must have no insert policy for anon/authenticated");
    } catch {
      report(false, "RLS probe");
    }
  }
}

async function checkDeepSeek(): Promise<void> {
  const key = env("DEEPSEEK_API_KEY");
  report(Boolean(key), "DeepSeek API key set", "Create a key at platform.deepseek.com and set DEEPSEEK_API_KEY");
  if (!key) return;
  const base = (env("DEEPSEEK_BASE_URL") || "https://api.deepseek.com").replace(/\/$/, "");
  try {
    const res = await fetch(base + "/models", { headers: { Authorization: "Bearer " + key } });
    report(res.ok, "DeepSeek API reachable and key accepted", "HTTP " + res.status + " - check key and DEEPSEEK_BASE_URL");
  } catch {
    report(false, "DeepSeek API reachable", "Network error reaching " + base);
  }
}

async function checkRazorpay(): Promise<void> {
  const id = env("RAZORPAY_KEY_ID");
  const secret = env("RAZORPAY_KEY_SECRET");
  if (!id && !secret) {
    console.log("\u26A0\uFE0F  Razorpay keys not set: pricing will show \"Notify me\" (this is allowed).");
    return;
  }
  report(Boolean(id && secret), "Razorpay key id + secret set", "Both RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET are required");
  report(id.startsWith("rzp_test_") || id.startsWith("rzp_live_"), "Razorpay key id format (rzp_test_/rzp_live_)", "Copy the key id exactly from the dashboard");
  if (id && secret) {
    try {
      const res = await fetch("https://api.razorpay.com/v1/orders?count=1", {
        headers: { Authorization: "Basic " + Buffer.from(id + ":" + secret).toString("base64") },
      });
      report(res.ok, "Razorpay credentials accepted", "HTTP " + res.status + " - regenerate keys and update both values");
    } catch {
      report(false, "Razorpay reachable");
    }
  }
  report(Boolean(env("RAZORPAY_WEBHOOK_SECRET")), "Razorpay webhook secret set", "Set RAZORPAY_WEBHOOK_SECRET to the secret you typed when creating the webhook");
}

function checkLocal(): void {
  const dir = join(process.cwd(), "public", "pdfjs");
  report(existsSync(join(dir, "pdf.worker.min.mjs")) && existsSync(join(dir, "pdf.min.mjs")) && existsSync(join(dir, "extract.worker.mjs")), "pdf.js worker files present in public/pdfjs", "Copy node_modules/pdfjs-dist/build/pdf.min.mjs and pdf.worker.min.mjs into public/pdfjs/");
  report(Boolean(env("NEXT_PUBLIC_APP_URL")), "NEXT_PUBLIC_APP_URL set", "Set it to http://localhost:3000 locally or your production URL");
}

async function main(): Promise<void> {
  console.log("PDF2Play setup check\n");
  checkLocal();
  await checkSupabase();
  await checkDeepSeek();
  await checkRazorpay();
  console.log(failures === 0 ? "\nAll checks passed." : "\n" + failures + " check(s) failed. See SETUP.md troubleshooting.");
  process.exit(failures === 0 ? 0 : 1);
}

void main();
