import { z } from "zod";
import { getEntitlement } from "@/lib/entitlement";
import { hardenHtml } from "@/lib/game/shell";
import { GAME_TYPES, PLANS } from "@/lib/plans";
import { rateLimit } from "@/lib/rate-limit";
import { getAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("invite"), email: z.string().trim().toLowerCase().email().max(200) }),
  z.object({ action: z.literal("remove"), email: z.string().trim().toLowerCase().email().max(200) }),
  z.object({
    action: z.literal("share"),
    title: z.string().min(2).max(120),
    gameType: z.enum(GAME_TYPES as unknown as [string, ...string[]]),
    pageCount: z.number().int().min(1).max(30),
    plan: z.record(z.string(), z.unknown()),
    html: z.string().min(100).max(420_000),
  }),
]);

/** Classroom seats + shared library. Owner = classroom subscriber; members are invited by email. */
export async function POST(req: Request): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return Response.json({ message: "Please sign in." }, { status: 401 });
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return Response.json({ message: "Invalid request body." }, { status: 400 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return Response.json({ message: "Invalid request." }, { status: 400 });
  const rl = await rateLimit("classroom:" + user.id, 30, 600);
  if (!rl.ok) return Response.json({ message: "Too many requests." }, { status: 429 });
  const admin = getAdminClient();
  const ent = await getEntitlement(user);
  if (!admin || !ent) return Response.json({ message: "Classroom is not available on this server." }, { status: 503 });
  const b = parsed.data;

  if (b.action === "share") {
    if (ent.plan !== "classroom") return Response.json({ message: "The shared library is part of the Classroom plan.", upgrade: true }, { status: 402 });
    const ownerId = ent.seatOf ?? user.id;
    try {
      hardenHtml(b.html);
    } catch {
      return Response.json({ message: "That game is too large to share." }, { status: 400 });
    }
    const { count } = await admin.from("shared_games").select("id", { count: "exact", head: true }).eq("owner_id", ownerId);
    if ((count ?? 0) >= 100) return Response.json({ message: "The shared library is full (100 games)." }, { status: 400 });
    const { error } = await admin.from("shared_games").insert({ owner_id: ownerId, title: b.title, game_type: b.gameType, page_count: b.pageCount, plan: b.plan, html: b.html });
    if (error) return Response.json({ message: "Could not share the game." }, { status: 500 });
    return Response.json({ ok: true });
  }

  if (ent.ownPlan !== "classroom") return Response.json({ message: "Only Classroom owners can manage seats.", upgrade: true }, { status: 402 });
  if (b.action === "invite") {
    if (b.email === ent.email) return Response.json({ message: "You already hold the owner seat." }, { status: 400 });
    const { count } = await admin.from("classroom_members").select("id", { count: "exact", head: true }).eq("owner_id", user.id);
    if ((count ?? 0) >= PLANS.classroom.seats - 1) return Response.json({ message: "All 5 seats are in use." }, { status: 400 });
    const { error } = await admin.from("classroom_members").upsert({ owner_id: user.id, member_email: b.email }, { onConflict: "owner_id,member_email", ignoreDuplicates: true });
    if (error) return Response.json({ message: "Could not add the seat." }, { status: 500 });
    return Response.json({ ok: true });
  }
  await admin.from("classroom_members").delete().eq("owner_id", user.id).eq("member_email", b.email);
  return Response.json({ ok: true });
}
