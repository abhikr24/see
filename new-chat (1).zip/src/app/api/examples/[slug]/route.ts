import { getExample } from "@/data/examples";

export async function GET(_req: Request, ctx: { params: Promise<{ slug: string }> }): Promise<Response> {
  const { slug } = await ctx.params;
  const ex = getExample(slug);
  if (!ex) return Response.json({ message: "Example not found" }, { status: 404 });
  return Response.json({ title: ex.plan.title, html: ex.html, verified: ex.verified, gameType: ex.plan.game_type });
}
