import { randomUUID } from "node:crypto";
import { z } from "zod";
import { AiUnavailableError, BudgetError, Meter, aiConfigured } from "@/lib/ai/deepseek";
import { PipelineError, runPipeline } from "@/lib/ai/pipeline";
import { DIFFICULTIES, type StreamEvent } from "@/lib/ai/schema";
import { getEntitlement, spendSince } from "@/lib/entitlement";
import { sha256Hex } from "@/lib/hash";
import {
  DAILY_COST_CEILING_PAISE,
  FREE_MONTHLY_COST_CEILING_PAISE,
  GAME_TYPES,
  MAX_PDF_PAGES,
  PER_RUN_COST_CEILING_PAISE,
  PLANS,
  type PlanId,
} from "@/lib/plans";
import type { PageExtract } from "@/lib/pdf/types";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { getAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

const PageSchema = z.object({
  page: z.number().int().min(1).max(MAX_PDF_PAGES),
  text: z.string().max(60_000),
  headings: z.array(z.string().max(300)).max(12).default([]),
  lists: z.array(z.string().max(300)).max(30).default([]),
  captions: z.array(z.string().max(300)).max(10).default([]),
  footnotes: z.array(z.string().max(300)).max(10).default([]),
});

const BodySchema = z.object({
  pages: z.array(PageSchema).min(1).max(MAX_PDF_PAGES),
  gameType: z.enum(GAME_TYPES as unknown as [string, ...string[]]),
  difficulty: z.enum(DIFFICULTIES),
});

function fail(status: number, code: string, message: string, extra: Record<string, unknown> = {}) {
  return Response.json({ code, message, ...extra }, { status, headers: { "Cache-Control": "no-store" } });
}

export async function POST(req: Request): Promise<Response> {
  if (Number(req.headers.get("content-length") ?? 0) > 2_500_000) {
    return fail(413, "too_large", "That document is too large to process.");
  }

  // 1. auth
  const user = await getCurrentUser();

  // 2. validate
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return fail(400, "bad_request", "Invalid request body.");
  }
  const parsed = BodySchema.safeParse(json);
  if (!parsed.success) return fail(400, "bad_request", "Invalid request: " + parsed.error.issues[0]?.message);
  const body = parsed.data;
  const pages: PageExtract[] = body.pages.map((p) => ({
    ...p,
    text: p.text.trim(),
    chars: p.text.trim().length,
    needsOCR: p.text.trim().length < 50,
  }));
  const seen = new Set(pages.map((p) => p.page));
  if (seen.size !== pages.length) return fail(400, "bad_request", "Duplicate page numbers.");
  if (pages.reduce((n, p) => n + p.chars, 0) > 600_000) return fail(413, "too_large", "That document has too much text.");
  const gameType = body.gameType as (typeof GAME_TYPES)[number];

  // 3. rate limit (5 / 10 min guests, 20 / 10 min signed in)
  const ip = clientKey(req);
  const rl = await rateLimit(user ? "gen:u:" + user.id : "gen:ip:" + ip, user ? 20 : 5, 600);
  if (!rl.ok) return fail(429, "rate_limited", "You are generating too quickly. Please wait a few minutes.", { retryAfterSec: rl.retryAfterSec });
  if (!user) {
    const day = await rateLimit("gen-day:ip:" + ip, 3, 86_400);
    if (!day.ok) return fail(429, "guest_limit", "Guest limit reached for today. Create a free account to continue.");
  }

  // 4. limits BEFORE any model call
  if (!aiConfigured()) return fail(503, "ai_unconfigured", "AI generation is not configured on this server (missing DEEPSEEK_API_KEY).");
  let plan: PlanId = "free";
  let maxCost = PER_RUN_COST_CEILING_PAISE.guest;
  let ent: Awaited<ReturnType<typeof getEntitlement>> = null;
  const admin = getAdminClient();
  if (user) {
    ent = await getEntitlement(user);
    if (!ent || !admin) return fail(503, "server_misconfigured", "Accounts are not fully configured on this server.");
    plan = ent.plan;
    const dayStart = new Date();
    dayStart.setUTCHours(0, 0, 0, 0);
    const daily = DAILY_COST_CEILING_PAISE[plan] - (await spendSince(user.id, dayStart.toISOString()));
    let monthly = Number.POSITIVE_INFINITY;
    if (plan === "free") {
      monthly = FREE_MONTHLY_COST_CEILING_PAISE - (await spendSince(user.id, new Date(ent.period).toISOString()));
    }
    maxCost = Math.min(PER_RUN_COST_CEILING_PAISE[plan], daily, monthly);
    if (maxCost < 60) {
      return fail(402, "spend_ceiling", "You have used today's generation allowance for your plan. Upgrade for a higher allowance or try again tomorrow.", { upgrade: true });
    }
  }
  const planInfo = PLANS[plan];
  if (!planInfo.allowedTypes.includes(gameType)) {
    return fail(402, "plan_feature", "This game type is part of the Pro plan.", { upgrade: true });
  }
  if (pages.length > planInfo.maxPages) return fail(400, "too_many_pages", "Too many pages for your plan.");

  let consumed = false;
  if (user && ent && admin) {
    const { data, error } = await admin.rpc("increment_usage", { p_user: user.id, p_period: ent.period, p_limit: ent.limit });
    if (error) return fail(503, "server_misconfigured", "Usage tracking is unavailable. Run the Supabase SQL files from SETUP.md.");
    if (data === -1) {
      return fail(402, "quota_exceeded", "You have used all " + ent.limit + " games for this period. Upgrade to keep creating.", { upgrade: true });
    }
    consumed = true;
  }

  const hash = await sha256Hex(pages.map((p) => p.text).join("\n\n") + gameType + body.difficulty);
  const meter = new Meter(maxCost);
  const enc = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (e: StreamEvent) => controller.enqueue(enc.encode(JSON.stringify(e) + "\n"));
      try {
        const out = await runPipeline({
          pages,
          gameType,
          difficulty: body.difficulty,
          watermark: planInfo.watermark,
          meter,
          emit: (stage, message, pct) => send({ type: "progress", stage, message, pct }),
        });
        let gameId: string = randomUUID();
        if (user && admin) {
          const { data: game } = await admin
            .from("games")
            .insert({
              user_id: user.id,
              title: out.plan.title,
              game_type: gameType,
              page_count: pages.length,
              content_hash: hash,
              verified_count: out.verified.verified,
              total_count: out.verified.total,
              engine: out.engine,
            })
            .select("id")
            .single();
          if (game?.id) gameId = game.id as string;
          await admin.from("generations").insert({
            user_id: user.id,
            game_id: game?.id ?? null,
            game_type: gameType,
            page_count: pages.length,
            tokens_in: meter.tokensIn,
            tokens_out: meter.tokensOut,
            cost_paise: meter.cost(),
            status: "ok",
          });
        }
        send({ type: "done", result: { ...out, gameId, hash } });
      } catch (e) {
        if (consumed && user && ent && admin) {
          await admin.rpc("refund_usage", { p_user: user.id, p_period: ent.period, p_limit: ent.limit });
          await admin.from("generations").insert({
            user_id: user.id,
            game_type: gameType,
            page_count: pages.length,
            tokens_in: meter.tokensIn,
            tokens_out: meter.tokensOut,
            cost_paise: meter.cost(),
            status: "failed",
          });
        }
        if (e instanceof PipelineError) send({ type: "error", code: e.code, message: e.message });
        else if (e instanceof BudgetError) send({ type: "error", code: "budget", message: e.message });
        else if (e instanceof AiUnavailableError) send({ type: "error", code: "ai_unavailable", message: e.message });
        else send({ type: "error", code: "internal", message: "Something went wrong while generating. You were not charged a game." });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store", "X-Accel-Buffering": "no" },
  });
}
