import { z } from "zod";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { getAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.object({ email: z.string().trim().toLowerCase().email().max(200), plan: z.enum(["pro", "classroom"]) });

/** "Notify me" email capture, used when Razorpay keys are absent. */
export async function POST(req: Request): Promise<Response> {
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return Response.json({ message: "Invalid request body." }, { status: 400 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return Response.json({ message: "Please enter a valid email address." }, { status: 400 });
  const rl = await rateLimit("notify:" + clientKey(req), 5, 3600);
  if (!rl.ok) return Response.json({ message: "Too many requests. Try again later." }, { status: 429 });
  const admin = getAdminClient();
  if (!admin) return Response.json({ message: "Email capture is unavailable until the database is configured." }, { status: 503 });
  const { error } = await admin.from("notify_requests").upsert(parsed.data, { onConflict: "email,plan", ignoreDuplicates: true });
  if (error) return Response.json({ message: "Could not save your email. Please try again." }, { status: 500 });
  return Response.json({ ok: true });
}
