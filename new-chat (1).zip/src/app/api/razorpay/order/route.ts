import { z } from "zod";
import { PLANS } from "@/lib/plans";
import { rateLimit } from "@/lib/rate-limit";
import { createRazorpayOrder, razorpayConfigured } from "@/lib/razorpay";
import { getAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.object({ plan: z.enum(["pro", "classroom"]) });

export async function POST(req: Request): Promise<Response> {
  // auth
  const user = await getCurrentUser();
  if (!user) return Response.json({ message: "Please sign in to upgrade." }, { status: 401 });
  // validate
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return Response.json({ message: "Invalid request body." }, { status: 400 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return Response.json({ message: "Unknown plan." }, { status: 400 });
  // rate limit
  const rl = await rateLimit("order:" + user.id, 10, 600);
  if (!rl.ok) return Response.json({ message: "Too many attempts. Please wait a few minutes." }, { status: 429 });
  // act
  const admin = getAdminClient();
  if (!razorpayConfigured() || !admin) return Response.json({ message: "Payments are not enabled on this server." }, { status: 503 });

  const plan = PLANS[parsed.data.plan]; // price ALWAYS comes from lib/plans.ts
  try {
    const receipt = "p2p_" + Date.now().toString(36) + "_" + user.id.slice(0, 8);
    const order = await createRazorpayOrder(plan.pricePaise, receipt, { user_id: user.id, plan: plan.id });
    const { error } = await admin.from("payments").insert({
      user_id: user.id,
      plan: plan.id,
      amount_paise: plan.pricePaise,
      currency: "INR",
      razorpay_order_id: order.id,
      status: "created",
    });
    if (error) return Response.json({ message: "Could not record the payment. Please try again." }, { status: 500 });
    return Response.json({
      orderId: order.id,
      amount: plan.pricePaise,
      currency: "INR",
      keyId: process.env.RAZORPAY_KEY_ID,
      email: user.email ?? "",
      planName: plan.name,
    });
  } catch {
    return Response.json({ message: "Could not start checkout. Please try again." }, { status: 502 });
  }
}
