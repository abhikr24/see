import { razorpayConfigured } from "@/lib/razorpay";

export const dynamic = "force-dynamic";

/** Lets the pricing UI decide between "Buy" and "Notify me" without exposing any secret. */
export async function GET(): Promise<Response> {
  return Response.json({ enabled: razorpayConfigured() }, { headers: { "Cache-Control": "no-store" } });
}
