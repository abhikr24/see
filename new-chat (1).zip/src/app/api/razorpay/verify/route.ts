import { z } from "zod";
import { PLANS, PLAN_PERIOD_DAYS, isPaidPlan } from "@/lib/plans";
import { rateLimit } from "@/lib/rate-limit";
import { verifyPaymentSignature } from "@/lib/razorpay";
import { getAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.object({
  razorpay_order_id: z.string().min(5).max(64),
  razorpay_payment_id: z.string().min(5).max(64),
  razorpay_signature: z.string().min(10).max(128),
});

export async function POST(req: Request): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return Response.json({ message: "Please sign in." }, { status: 401 });
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return Response.json({ message: "Invalid request body." }, { status: 400 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return Response.json({ message: "Invalid payment response." }, { status: 400 });
  const rl = await rateLimit("verify:" + user.id, 20, 600);
  if (!rl.ok) return Response.json({ message: "Too many attempts." }, { status: 429 });

  const admin = getAdminClient();
  if (!admin) return Response.json({ message: "Payments are not enabled on this server." }, { status: 503 });
  const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature } = parsed.data;

  const { data: payment } = await admin.from("payments").select("user_id, plan, status").eq("razorpay_order_id", orderId).maybeSingle();
  if (!payment || payment.user_id !== user.id || !isPaidPlan(payment.plan as string)) {
    return Response.json({ message: "Order not found." }, { status: 404 });
  }
  if (!verifyPaymentSignature(orderId, paymentId, signature)) {
    return Response.json({ message: "Payment signature could not be verified." }, { status: 400 });
  }
  const plan = PLANS[payment.plan as "pro" | "classroom"];
  const { error } = await admin.rpc("mark_payment_paid", {
    p_order_id: orderId,
    p_payment_id: paymentId,
    p_credits: plan.gamesPerMonth,
    p_days: PLAN_PERIOD_DAYS,
  });
  if (error) return Response.json({ message: "Payment received but activation failed. It will be applied automatically." }, { status: 500 });
  // false (already paid) is fine: the grant is idempotent and was applied exactly once.
  return Response.json({ ok: true, plan: plan.id });
}
