import { createHash } from "node:crypto";
import { PLANS, PLAN_PERIOD_DAYS, isPaidPlan } from "@/lib/plans";
import { verifyWebhookSignature } from "@/lib/razorpay";
import { getAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface PaymentEntity {
  id?: string;
  order_id?: string;
  amount?: number;
}
interface WebhookPayload {
  event?: string;
  payload?: {
    payment?: { entity?: PaymentEntity };
    refund?: { entity?: { payment_id?: string } };
  };
}

export async function POST(req: Request): Promise<Response> {
  // RAW body first: the signature is computed over the exact bytes Razorpay sent.
  const raw = await req.text();
  const signature = req.headers.get("x-razorpay-signature") ?? "";
  if (!process.env.RAZORPAY_WEBHOOK_SECRET) return Response.json({ message: "Webhook not configured" }, { status: 503 });
  if (!signature || !verifyWebhookSignature(raw, signature)) return Response.json({ message: "Invalid signature" }, { status: 400 });

  let body: WebhookPayload;
  try {
    body = JSON.parse(raw) as WebhookPayload;
  } catch {
    return Response.json({ message: "Invalid JSON" }, { status: 400 });
  }
  const admin = getAdminClient();
  if (!admin) return Response.json({ message: "Database not configured" }, { status: 503 });

  const eventId = req.headers.get("x-razorpay-event-id") || "sha256:" + createHash("sha256").update(raw).digest("hex");
  const event = body.event ?? "unknown";

  // Idempotency: first writer wins, replays are acknowledged and ignored.
  const ins = await admin.from("webhook_events").insert({ id: eventId, event, payload: body });
  if (ins.error) {
    if (ins.error.code === "23505") return Response.json({ ok: true, duplicate: true });
    return Response.json({ message: "Could not record event" }, { status: 500 });
  }

  try {
    if (event === "payment.captured") {
      const p = body.payload?.payment?.entity;
      if (p?.order_id && p.id) {
        const { data: row } = await admin.from("payments").select("plan, amount_paise").eq("razorpay_order_id", p.order_id).maybeSingle();
        if (row && isPaidPlan(row.plan as string) && row.amount_paise === p.amount) {
          const { error } = await admin.rpc("mark_payment_paid", {
            p_order_id: p.order_id,
            p_payment_id: p.id,
            p_credits: PLANS[row.plan as "pro" | "classroom"].gamesPerMonth,
            p_days: PLAN_PERIOD_DAYS,
          });
          if (error) throw new Error(error.message);
        }
      }
    } else if (event === "payment.failed") {
      const p = body.payload?.payment?.entity;
      if (p?.order_id) {
        await admin.from("payments").update({ status: "failed", updated_at: new Date().toISOString() }).eq("razorpay_order_id", p.order_id).eq("status", "created");
      }
    } else if (event === "refund.processed") {
      const paymentId = body.payload?.refund?.entity?.payment_id;
      if (paymentId) {
        const { error } = await admin.rpc("apply_refund", { p_payment_id: paymentId });
        if (error) throw new Error(error.message);
      }
    }
    return Response.json({ ok: true });
  } catch {
    // Let Razorpay retry: forget the event so the retry is processed.
    await admin.from("webhook_events").delete().eq("id", eventId);
    return Response.json({ message: "Processing failed" }, { status: 500 });
  }
}
