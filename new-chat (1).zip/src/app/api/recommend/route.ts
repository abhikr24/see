import { z } from "zod";
import { AiUnavailableError, BudgetError, Meter, aiConfigured, chat, parseJsonLoose } from "@/lib/ai/deepseek";
import { GAME_TYPE_INFO, GAME_TYPES, type GameType } from "@/lib/plans";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.object({
  toc: z.array(z.string().max(160)).max(60).default([]),
  keyTerms: z.array(z.string().max(80)).max(30).default([]),
  summaries: z.array(z.string().max(200)).max(30).default([]),
  heuristic: z.array(z.enum(GAME_TYPES as unknown as [string, ...string[]])).min(1).max(6),
});

const Out = z.object({
  types: z.array(z.object({ type: z.enum(GAME_TYPES as unknown as [string, ...string[]]), reason: z.string().max(160) })).min(2).max(3),
});

export async function POST(req: Request): Promise<Response> {
  const user = await getCurrentUser();
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return Response.json({ message: "Invalid request body." }, { status: 400 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return Response.json({ message: "Invalid request." }, { status: 400 });
  const rl = await rateLimit(user ? "rec:u:" + user.id : "rec:ip:" + clientKey(req), user ? 40 : 10, 600);
  if (!rl.ok) return Response.json({ message: "Too many requests." }, { status: 429 });

  const { toc, keyTerms, summaries, heuristic } = parsed.data;
  const fallback = heuristic.slice(0, 3).map((t) => ({ type: t, reason: GAME_TYPE_INFO[t as GameType].blurb }));
  if (!aiConfigured()) return Response.json({ types: fallback, source: "heuristic" });
  try {
    const text = await chat(
      {
        system:
          "You pick the 2-3 learning game types that best fit a document. Allowed types: " + GAME_TYPES.join(", ") +
          '. Reply with JSON only: {"types":[{"type":"quiz_rush","reason":"max 15 words"}]}',
        user: ["TOC: " + toc.join("; "), "KEY TERMS: " + keyTerms.join("; "), "PAGE SUMMARIES: " + summaries.join(" | "), "LOCAL RANKING: " + heuristic.join(", ")].join("\n").slice(0, 6000),
        maxTokens: 300,
        json: true,
      },
      new Meter(30),
    );
    const out = Out.parse(parseJsonLoose(text));
    return Response.json({ types: out.types, source: "ai" });
  } catch (e) {
    if (e instanceof AiUnavailableError || e instanceof BudgetError || e instanceof Error) {
      return Response.json({ types: fallback, source: "heuristic" });
    }
    return Response.json({ types: fallback, source: "heuristic" });
  }
}
