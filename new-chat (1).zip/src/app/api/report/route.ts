import { z } from "zod";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { getAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.object({
  gameId: z.string().max(80).optional(),
  gameTitle: z.string().max(120).optional(),
  message: z.string().trim().min(3).max(1000),
});

export async function POST(req: Request): Promise<Response> {
  const user = await getCurrentUser();
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    return Response.json({ message: "Invalid request body." }, { status: 400 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return Response.json({ message: "Please describe the problem (3-1000 characters)." }, { status: 400 });
  const rl = await rateLimit(user ? "report:u:" + user.id : "report:ip:" + clientKey(req), 10, 3600);
  if (!rl.ok) return Response.json({ message: "Too many reports. Try again later." }, { status: 429 });
  const admin = getAdminClient();
  if (!admin) return Response.json({ message: "Reporting is unavailable until the database is configured." }, { status: 503 });
  const { error } = await admin.from("reports").insert({
    user_id: user?.id ?? null,
    game_id: parsed.data.gameId ?? null,
    game_title: parsed.data.gameTitle ?? null,
    message: parsed.data.message,
  });
  if (error) return Response.json({ message: "Could not send your report." }, { status: 500 });
  return Response.json({ ok: true });
}
