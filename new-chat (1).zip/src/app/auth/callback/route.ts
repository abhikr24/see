import { NextResponse } from "next/server";
import { getServerClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

/** Completes magic-link and Google OAuth sign-in (PKCE code exchange). */
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const nextParam = searchParams.get("next") ?? "/dashboard";
  const next = nextParam.startsWith("/") && !nextParam.startsWith("//") ? nextParam : "/dashboard";
  const base = (process.env.NEXT_PUBLIC_APP_URL || origin).replace(/\/$/, "");
  const supabase = await getServerClient();
  if (code && supabase) {
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(base + next);
  }
  return NextResponse.redirect(base + "/login?error=auth");
}
