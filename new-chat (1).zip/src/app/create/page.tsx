import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Creator } from "@/components/creator/creator";
import { PageShell } from "@/components/page-shell";
import { getEntitlement } from "@/lib/entitlement";
import { getCurrentUser } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Create a game" };
export const dynamic = "force-dynamic";

export default async function CreatePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/create");
  const ent = await getEntitlement(user);
  return (
    <PageShell>
      <h1 className="mb-6 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">Create a game</h1>
      <Creator mode="user" plan={ent?.plan ?? "free"} remaining={ent?.remaining} />
    </PageShell>
  );
}
