import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { CheckCircle2 } from "lucide-react";
import { ClassroomPanel } from "@/components/dashboard/classroom-panel";
import { Pricing } from "@/components/landing/pricing";
import { LocalLibrary } from "@/components/library/local-library";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { getEntitlement } from "@/lib/entitlement";
import { PLANS, formatINR } from "@/lib/plans";
import { getAdminClient } from "@/lib/supabase/admin";
import { getCurrentUser, getServerClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

interface PaymentRow {
  plan: string;
  amount_paise: number;
  status: string;
  created_at: string;
}

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ upgraded?: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard");
  const sp = await searchParams;
  const ent = await getEntitlement(user);
  const supabase = await getServerClient();
  const plan = ent?.plan ?? "free";

  const payments: PaymentRow[] = supabase
    ? (((await supabase.from("payments").select("plan, amount_paise, status, created_at").order("created_at", { ascending: false }).limit(8)).data as PaymentRow[] | null) ?? [])
    : [];

  const admin = getAdminClient();
  const ownerId = ent?.seatOf ?? (ent?.ownPlan === "classroom" ? user.id : null);
  let seats: string[] = [];
  let shared: { id: string; title: string; game_type: string; page_count: number }[] = [];
  if (ownerId && supabase && admin) {
    const s = await admin.from("classroom_members").select("member_email").eq("owner_id", ownerId);
    seats = (s.data ?? []).map((r) => r.member_email as string);
    const g = await supabase.from("shared_games").select("id, title, game_type, page_count").eq("owner_id", ownerId).order("created_at", { ascending: false }).limit(50);
    shared = (g.data ?? []) as typeof shared;
  }

  return (
    <PageShell wide>
      <div className="flex flex-wrap items-center gap-3">
        <div className="min-w-0 flex-1">
          <h1 className="text-3xl font-extrabold tracking-tight">Dashboard</h1>
          <p className="truncate text-sm text-muted">{user.email}</p>
        </div>
        <Button asChild><Link href="/create">Create a game</Link></Button>
        <form action="/auth/signout" method="post">
          <Button type="submit" variant="outline">Sign out</Button>
        </form>
      </div>

      {sp.upgraded && (
        <p role="status" className="mt-5 flex items-center gap-2 rounded-card bg-success/10 p-3 text-sm font-semibold text-success">
          <CheckCircle2 className="h-5 w-5" /> Payment confirmed - your plan is active.
        </p>
      )}

      <section className="mt-8 grid gap-4 sm:grid-cols-3" aria-label="Plan summary">
        <div className="rounded-card border border-line bg-lavender p-5">
          <p className="text-xs font-bold uppercase tracking-wide text-muted">Plan</p>
          <p className="mt-1 text-2xl font-extrabold">{PLANS[plan].name}{ent?.seatOf ? " (seat)" : ""}</p>
          {ent?.expiresAt && <p className="text-xs text-muted">Active until {new Date(ent.expiresAt).toLocaleDateString()}</p>}
        </div>
        <div className="rounded-card border border-line bg-lavender p-5">
          <p className="text-xs font-bold uppercase tracking-wide text-muted">Games this period</p>
          <p className="mt-1 text-2xl font-extrabold">{ent ? ent.used + " / " + ent.limit : "-"}</p>
          <p className="text-xs text-muted">{ent ? ent.remaining + " remaining" : "Usage unavailable"}</p>
        </div>
        <div className="rounded-card border border-line bg-lavender p-5">
          <p className="text-xs font-bold uppercase tracking-wide text-muted">Watermark</p>
          <p className="mt-1 text-2xl font-extrabold">{PLANS[plan].watermark ? "On" : "Off"}</p>
          <p className="text-xs text-muted">{PLANS[plan].watermark ? "Upgrade to remove it" : "Your games are clean"}</p>
        </div>
      </section>

      <section className="mt-10" aria-labelledby="lib">
        <h2 id="lib" className="mb-3 text-xl font-extrabold">My library</h2>
        <LocalLibrary mode="user" canShare={plan === "classroom"} />
      </section>

      {ownerId && (
        <section className="mt-10" aria-labelledby="class">
          <h2 id="class" className="mb-3 text-xl font-extrabold">Classroom</h2>
          <ClassroomPanel isOwner={ent?.ownPlan === "classroom"} seats={seats} shared={shared} />
        </section>
      )}

      <div id="plans" className="-mx-5 mt-10">
        <Pricing currentPlan={ent?.ownPlan} />
      </div>

      <section className="mt-4" aria-labelledby="pay">
        <h2 id="pay" className="mb-3 text-xl font-extrabold">Payments</h2>
        {payments.length === 0 ? (
          <p className="text-sm text-muted">No payments yet.</p>
        ) : (
          <div className="overflow-x-auto rounded-card border border-line">
            <table className="w-full text-left text-sm">
              <thead className="bg-lavender text-xs uppercase text-muted">
                <tr><th className="p-3">Date</th><th className="p-3">Plan</th><th className="p-3">Amount</th><th className="p-3">Status</th></tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.created_at + p.plan} className="border-t border-line">
                    <td className="p-3">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="p-3 capitalize">{p.plan}</td>
                    <td className="p-3">{formatINR(p.amount_paise)}</td>
                    <td className="p-3 capitalize">{p.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </PageShell>
  );
}
