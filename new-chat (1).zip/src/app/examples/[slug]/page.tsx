import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageShell } from "@/components/page-shell";
import { Player } from "@/components/player/player";
import { Button } from "@/components/ui/button";
import { EXAMPLE_META } from "@/data/examples-meta";
import { EXAMPLE_SLUGS, getExample } from "@/data/examples";

export function generateStaticParams() {
  return EXAMPLE_SLUGS.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const ex = getExample(slug);
  return { title: ex ? ex.plan.title : "Example game" };
}

export default async function ExamplePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const ex = getExample(slug);
  if (!ex) notFound();
  const meta = EXAMPLE_META.find((m) => m.slug === slug);
  return (
    <PageShell>
      <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-indigo">Example &middot; {meta?.pdfName ?? ex.plan.subject}</p>
      <h1 className="mb-5 mt-1 text-3xl font-extrabold tracking-tight">{ex.plan.title}</h1>
      <Player title={ex.plan.title} html={ex.html} plan={ex.plan} verified={ex.verified} />
      <div className="mt-6 flex flex-wrap items-center gap-3">
        <Button asChild><Link href="/try">Make a game from your own PDF</Link></Button>
        <Button asChild variant="outline"><Link href="/#examples">More examples</Link></Button>
      </div>
    </PageShell>
  );
}
