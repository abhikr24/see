import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"),
  title: { default: "PDF2Play - Turn any PDF into a playable game", template: "%s | PDF2Play" },
  description:
    "Upload a PDF and let AI turn your content into an engaging interactive game. Quizzes, flashcards, matching, boss battles and more - every question verified against your document.",
  openGraph: {
    title: "PDF2Play - Turn any PDF into a playable game",
    description: "Upload a PDF and play an AI-built game made only from your own content.",
    type: "website",
  },
};

export const viewport: Viewport = { themeColor: "#0A0E27", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-ink antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:rounded-full focus:bg-indigo focus:px-4 focus:py-2 focus:text-white"
        >
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
