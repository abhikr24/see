import type { Metadata } from "next";
import { LoginForm } from "@/components/auth/login-form";
import { PageShell } from "@/components/page-shell";

export const metadata: Metadata = { title: "Sign in" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; error?: string }> }) {
  const sp = await searchParams;
  const next = sp.next && sp.next.startsWith("/") && !sp.next.startsWith("//") ? sp.next : "/dashboard";
  return (
    <PageShell>
      <LoginForm next={next} error={sp.error} />
    </PageShell>
  );
}
