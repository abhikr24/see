import type { Metadata } from "next";
import { PlayLocal } from "@/components/library/play-local";
import { PageShell } from "@/components/page-shell";

export const metadata: Metadata = { title: "Play", robots: { index: false } };

export default async function PlayPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return (
    <PageShell>
      <PlayLocal id={id} />
    </PageShell>
  );
}
