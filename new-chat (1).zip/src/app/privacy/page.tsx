import type { Metadata } from "next";
import { LegalPage } from "@/components/legal";
import { SUPPORT_EMAIL } from "@/lib/site";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <LegalPage title="Privacy Policy" updated="1 January 2026">
      <p>PDF2Play turns the PDFs you choose into playable games. This policy explains what we handle and what we do not.</p>
      <h2>Your PDF stays in your browser</h2>
      <p>Your PDF file is opened and read on your own device. The file itself is never uploaded to our servers.</p>
      <h2>What we send to our servers</h2>
      <ul>
        <li>The text extracted from your PDF (page text, headings, lists), sent only when you press Generate, so that our AI provider (DeepSeek) can design your game. We do not store this text after the request finishes.</li>
        <li>Your chosen game type and difficulty.</li>
        <li>Optional problem reports you submit through the Report button.</li>
      </ul>
      <h2>What we store</h2>
      <ul>
        <li>Account data (email address, plan, remaining credits, usage counters) in Supabase.</li>
        <li>Game metadata (title, type, page count, content hash) for signed-in users. The game itself (HTML and plan) is stored only in your browser using IndexedDB.</li>
        <li>Payment records: Razorpay order and payment identifiers, plan, amount and status. We never see or store your card or UPI details; Razorpay handles them.</li>
        <li>Generation records: token counts and cost, used to enforce fair-use limits.</li>
        <li>Short-lived rate-limit counters keyed by a hash of your IP address (guests) or your account (signed-in users).</li>
      </ul>
      <h2>Third parties</h2>
      <p>We use Supabase (database and sign-in), DeepSeek (game generation), Razorpay (payments) and Google (optional sign-in). Each processes data under its own policy.</p>
      <h2>Your choices</h2>
      <p>You can delete any game, or clear your whole library, from your dashboard at any time. To delete your account and associated records, email {SUPPORT_EMAIL} from your registered address.</p>
      <h2>Contact</h2>
      <p>Questions about privacy: {SUPPORT_EMAIL}.</p>
    </LegalPage>
  );
}
