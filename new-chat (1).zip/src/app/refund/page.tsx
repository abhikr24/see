import type { Metadata } from "next";
import { LegalPage } from "@/components/legal";
import { SUPPORT_EMAIL } from "@/lib/site";

export const metadata: Metadata = { title: "Refund Policy" };

export default function RefundPage() {
  return (
    <LegalPage title="Refund Policy" updated="1 January 2026">
      <p>We want you to be happy with PDF2Play. This is how refunds work.</p>
      <h2>Eligibility</h2>
      <ul>
        <li>You can request a full refund within 7 days of a payment if you have created fewer than 10 games on the paid plan.</li>
        <li>If a payment succeeded but your plan was not activated, we will fix it or refund you in full, whichever you prefer.</li>
        <li>If you were charged twice for the same order, the duplicate is refunded in full.</li>
      </ul>
      <h2>How to ask</h2>
      <p>Email {SUPPORT_EMAIL} from your registered address with your Razorpay payment ID (shown in your dashboard under Payments).</p>
      <h2>What happens</h2>
      <p>Refunds are issued to the original payment method through Razorpay and usually reach you within 5 to 7 business days. When a refund is processed your account returns to the Free plan automatically.</p>
      <h2>No auto-renewal</h2>
      <p>Each payment buys 30 days of access and never renews on its own, so there is nothing to cancel.</p>
    </LegalPage>
  );
}
