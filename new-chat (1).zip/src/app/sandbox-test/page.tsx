import type { Metadata } from "next";
import { PageShell } from "@/components/page-shell";
import { Player } from "@/components/player/player";
import { SANDBOX_FIXTURE_HTML } from "@/data/sandbox-fixture";

export const metadata: Metadata = { title: "Sandbox self-test", robots: { index: false } };

export default function SandboxTestPage() {
  return (
    <PageShell>
      <h1 className="text-2xl font-extrabold">Sandbox self-test</h1>
      <p className="mb-4 mt-2 text-sm text-muted">
        The fixture below deliberately tries to call fetch(), read the parent document, redirect the top window and use storage.
        Every line should read &ldquo;blocked&rdquo;. If any line reads &ldquo;LEAKED&rdquo;, the sandbox is broken.
      </p>
      <Player title="Sandbox fixture" html={SANDBOX_FIXTURE_HTML} />
    </PageShell>
  );
}
