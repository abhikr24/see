import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageShell } from "@/components/page-shell";
import { Player } from "@/components/player/player";
import type { GamePlan } from "@/lib/ai/schema";
import { getServerClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Shared game", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function SharedPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const supabase = await getServerClient();
  if (!supabase) notFound();
  // RLS: only the owner and invited seat members can read this row.
  const { data } = await supabase.from("shared_games").select("id, title, plan, html").eq("id", id).maybeSingle();
  if (!data) notFound();
  const plan = data.plan as GamePlan;
  return (
    <PageShell>
      <Player title={data.title as string} html={data.html as string} plan={plan} gameId={id} verified={{ verified: plan.rounds.length, total: plan.rounds.length }} />
    </PageShell>
  );
}
