import type { Metadata } from "next";
import { LegalPage } from "@/components/legal";
import { SUPPORT_EMAIL } from "@/lib/site";

export const metadata: Metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <LegalPage title="Terms of Service" updated="1 January 2026">
      <p>By using PDF2Play you agree to these terms.</p>
      <h2>The service</h2>
      <p>PDF2Play converts text from PDFs you provide into interactive games using AI. Games are generated from your text only, and each question is checked against that text, but AI can still make mistakes. Use the Report button if you spot one and do not rely on the games as professional, legal or medical advice.</p>
      <h2>Your content</h2>
      <p>You must have the right to use any PDF you upload. You keep all rights to your content and to the games made from it. You grant us permission to process the extracted text solely to provide the service.</p>
      <h2>Acceptable use</h2>
      <ul>
        <li>Do not attempt to bypass limits, rate limits or the sandbox that runs games.</li>
        <li>Do not upload unlawful content or content that infringes others&apos; rights.</li>
        <li>Do not resell access to the service except through the Classroom plan seats.</li>
      </ul>
      <h2>Plans and payments</h2>
      <p>Free, Pro (INR 249 per month) and Classroom (INR 999 per month) are described on our pricing section. Prices are in Indian rupees and include applicable taxes. Each payment grants 30 days of access and does not renew automatically. Payments are processed by Razorpay. Monthly game allowances reset at the start of each plan period and do not roll over.</p>
      <h2>Fair use</h2>
      <p>To keep the service sustainable, each plan has daily and per-game compute limits. If you reach one, you will be told and can try again later or upgrade.</p>
      <h2>Availability and liability</h2>
      <p>The service is provided as is. To the extent permitted by law, we are not liable for indirect or consequential losses. Our total liability is limited to the amount you paid us in the three months before the claim.</p>
      <h2>Changes and contact</h2>
      <p>We may update these terms; continued use means you accept the update. Contact: {SUPPORT_EMAIL}.</p>
    </LegalPage>
  );
}
