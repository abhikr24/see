import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Creator } from "@/components/creator/creator";
import { LocalLibrary } from "@/components/library/local-library";
import { PageShell } from "@/components/page-shell";
import { getCurrentUser } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Try PDF2Play free" };
export const dynamic = "force-dynamic";

export default async function TryPage() {
  const user = await getCurrentUser();
  if (user) redirect("/create");
  return (
    <PageShell>
      <h1 className="mb-6 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">Turn your PDF into a game</h1>
      <Creator mode="guest" plan="free" />
      <section className="mt-12" aria-labelledby="guest-lib">
        <h2 id="guest-lib" className="mb-3 text-xl font-extrabold">Saved on this device</h2>
        <LocalLibrary mode="guest" />
      </section>
    </PageShell>
  );
}
