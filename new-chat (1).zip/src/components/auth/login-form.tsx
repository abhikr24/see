"use client";

import { useState } from "react";
import { Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getBrowserClient } from "@/lib/supabase/client";

const ERRORS: Record<string, string> = {
  not_configured: "Sign-in is not configured on this deployment yet (Supabase keys are missing). See SETUP.md.",
  auth: "Sign-in failed or the link expired. Please request a new one.",
};

export function LoginForm({ next, error }: { next: string; error?: string }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<{ kind: "idle" | "sending" | "sent" | "error"; text?: string }>({ kind: "idle" });

  const origin = () => (process.env.NEXT_PUBLIC_APP_URL || window.location.origin).replace(/\/$/, "");
  const redirectTo = () => origin() + "/auth/callback?next=" + encodeURIComponent(next);

  async function magicLink() {
    const supabase = getBrowserClient();
    if (!supabase) return setState({ kind: "error", text: ERRORS.not_configured });
    setState({ kind: "sending" });
    const { error: err } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: redirectTo() } });
    setState(err ? { kind: "error", text: err.message } : { kind: "sent" });
  }

  async function google() {
    const supabase = getBrowserClient();
    if (!supabase) return setState({ kind: "error", text: ERRORS.not_configured });
    const { error: err } = await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: redirectTo() } });
    if (err) setState({ kind: "error", text: err.message });
  }

  const initial = error ? ERRORS[error] ?? "Something went wrong. Please try again." : "";
  return (
    <div className="mx-auto max-w-md rounded-2xl border border-line bg-white p-6 shadow-sm sm:p-8">
      <h1 className="text-2xl font-extrabold">Sign in to PDF2Play</h1>
      <p className="mt-1 text-sm text-muted">New here? The same link creates your free account with 3 games a month.</p>
      {(initial || state.kind === "error") && (
        <p role="alert" className="mt-4 rounded-card bg-red-50 p-3 text-sm font-semibold text-red-700">{state.text ?? initial}</p>
      )}
      {state.kind === "sent" ? (
        <p role="status" className="mt-5 rounded-card bg-success/10 p-4 text-sm font-semibold text-success">
          Check your inbox - we sent a sign-in link to {email}.
        </p>
      ) : (
        <>
          <form
            className="mt-5 flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              void magicLink();
            }}
          >
            <label htmlFor="email" className="text-sm font-bold">Email address</label>
            <input
              id="email"
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="h-12 rounded-full border border-line px-5 text-sm focus:border-indigo focus:outline-none"
            />
            <Button type="submit" size="lg" disabled={state.kind === "sending"}>
              <Mail className="h-5 w-5" /> {state.kind === "sending" ? "Sending\u2026" : "Email me a magic link"}
            </Button>
          </form>
          <div className="my-5 flex items-center gap-3 text-xs text-muted"><span className="h-px flex-1 bg-line" /> or <span className="h-px flex-1 bg-line" /></div>
          <Button type="button" variant="outline" size="lg" className="w-full" onClick={() => void google()}>
            Continue with Google
          </Button>
        </>
      )}
    </div>
  );
}
