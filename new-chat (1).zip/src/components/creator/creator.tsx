"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { AlertTriangle, Check, FileText, Lock, Sparkles, Wand2 } from "lucide-react";
import { Dropzone } from "@/components/dropzone";
import { Player } from "@/components/player/player";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { DIFFICULTIES, type Difficulty, type GenerationResult, type StreamEvent } from "@/lib/ai/schema";
import { buildBrief } from "@/lib/brief";
import { sha256Hex } from "@/lib/hash";
import { bumpGuestUsed, findByHash, getGame, readGuestUsed, saveGame, updateBestScore } from "@/lib/library";
import { extractPdf, validatePdf } from "@/lib/pdf/extract-client";
import type { PageExtract } from "@/lib/pdf/types";
import { takePendingFile } from "@/lib/pending-file";
import { GAME_TYPES, GAME_TYPE_INFO, GUEST_FREE_GAMES, PLANS, type GameType, type PlanId } from "@/lib/plans";
import { heuristicRecommend, type Recommendation } from "@/lib/recommend";

type Phase = "idle" | "reading" | "configure" | "generating" | "done";

interface CreatorProps {
  mode: "guest" | "user";
  plan: PlanId;
  remaining?: number;
}

interface Prompt {
  kind: "upgrade" | "signup";
  message: string;
}

export function Creator({ mode, plan, remaining }: CreatorProps) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState("");
  const [fileName, setFileName] = useState("");
  const [pages, setPages] = useState<PageExtract[]>([]);
  const [recs, setRecs] = useState<Recommendation[]>([]);
  const [recSource, setRecSource] = useState<"ai" | "heuristic">("heuristic");
  const [gameType, setGameType] = useState<GameType>("quiz_rush");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [progress, setProgress] = useState({ pct: 0, message: "" });
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [prompt, setPrompt] = useState<Prompt | null>(null);
  const started = useRef(false);

  const allowed = PLANS[plan].allowedTypes;

  const handleFile = useCallback(
    async (file: File) => {
      setError("");
      setPhase("reading");
      setProgress({ pct: 0, message: "Checking your PDF\u2026" });
      const v = await validatePdf(file);
      if (!v.ok) {
        setError(v.message);
        setPhase("idle");
        return;
      }
      try {
        const extracted = await extractPdf(v.bytes, (page, total) =>
          setProgress({ pct: Math.round((page / total) * 100), message: "Reading page " + page + " of " + total + "\u2026" }),
        );
        if (extracted.every((p) => p.needsOCR)) {
          setError("No extractable text was found. This PDF looks scanned (image-only) and OCR is not available yet.");
          setPhase("idle");
          return;
        }
        const readable = extracted.filter((p) => !p.needsOCR);
        const heur = heuristicRecommend(readable);
        const ranked = [...heur].sort((a, b) => Number(allowed.includes(b.type)) - Number(allowed.includes(a.type)));
        setPages(extracted);
        setFileName(file.name);
        setRecs(heur.slice(0, 3));
        setGameType(ranked[0].type);
        setPhase("configure");
        const brief = buildBrief(readable);
        try {
          const res = await fetch("/api/recommend", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              toc: brief.toc.slice(0, 40).map((t) => "p." + t.page + " " + t.heading),
              keyTerms: brief.keyTerms,
              summaries: brief.pageSummaries.slice(0, 30).map((s) => "p." + s.page + ": " + s.summary.slice(0, 120)),
              heuristic: heur.map((h) => h.type),
            }),
          });
          if (res.ok) {
            const j = (await res.json()) as { types: Recommendation[]; source: "ai" | "heuristic" };
            if (Array.isArray(j.types) && j.types.length) {
              setRecs(j.types.filter((t) => GAME_TYPES.includes(t.type)).slice(0, 3));
              setRecSource(j.source);
              const first = j.types.find((t) => allowed.includes(t.type));
              if (first) setGameType(first.type);
            }
          }
        } catch {
          // Recommendation is optional; the local ranking stays.
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "We could not read this PDF.");
        setPhase("idle");
      }
    },
    [allowed],
  );

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const f = takePendingFile();
    if (f) {
      const t = setTimeout(() => void handleFile(f), 0);
      return () => clearTimeout(t);
    }
  }, [handleFile]);

  async function generate() {
    setError("");
    if (!allowed.includes(gameType)) {
      setPrompt({ kind: "upgrade", message: GAME_TYPE_INFO[gameType].label + " is part of the Pro plan. Upgrade to unlock all six game types." });
      return;
    }
    if (mode === "guest" && readGuestUsed() >= GUEST_FREE_GAMES) {
      setPrompt({ kind: "signup", message: "You have used your free guest game. Create a free account for more games every month." });
      return;
    }
    const slim = pages.map((p) => ({ page: p.page, text: p.text, headings: p.headings, lists: p.lists, captions: p.captions, footnotes: p.footnotes }));
    const hash = await sha256Hex(pages.map((p) => p.text).join("\n\n") + gameType + difficulty);
    const cached = findByHash(hash);
    if (cached) {
      const g = await getGame(cached.id);
      if (g) {
        setResult({
          gameId: g.id,
          hash,
          plan: g.plan,
          html: g.html,
          engine: "standard",
          watermark: g.watermark,
          verified: g.verified,
          coverage: { contentPages: 0, coveredPages: 0, failedPages: g.coverage.failedPages, ocrPages: g.coverage.ocrPages },
          cached: true,
        });
        setPhase("done");
        return;
      }
    }
    setPhase("generating");
    setProgress({ pct: 3, message: "Sending extracted text (your PDF stays on this device)\u2026" });
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pages: slim, gameType, difficulty }),
      });
      if (!res.ok || !res.body) {
        const j = (await res.json().catch(() => ({}))) as { code?: string; message?: string; upgrade?: boolean };
        setPhase("configure");
        if (j.code === "guest_limit") setPrompt({ kind: "signup", message: j.message ?? "Create a free account to continue." });
        else if (res.status === 402 || j.upgrade) setPrompt({ kind: "upgrade", message: j.message ?? "Upgrade to keep creating games." });
        else setError(j.message ?? "Generation failed. Please try again.");
        return;
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      let final: GenerationResult | null = null;
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let nl = buf.indexOf("\n");
        while (nl >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          nl = buf.indexOf("\n");
          if (!line) continue;
          const ev = JSON.parse(line) as StreamEvent;
          if (ev.type === "progress") setProgress({ pct: ev.pct, message: ev.message });
          else if (ev.type === "error") {
            setError(ev.message);
            setPhase("configure");
            return;
          } else if (ev.type === "done") final = ev.result;
        }
      }
      if (!final) {
        setError("The connection ended before your game was ready. Please try again.");
        setPhase("configure");
        return;
      }
      await saveGame(
        { id: final.gameId, title: final.plan.title, type: gameType, date: new Date().toISOString(), pageCount: pages.length, bestScore: 0, hash: final.hash },
        { id: final.gameId, html: final.html, plan: final.plan, verified: final.verified, watermark: final.watermark, coverage: { failedPages: final.coverage.failedPages, ocrPages: final.coverage.ocrPages } },
      ).catch(() => setError("Your game was created but could not be saved on this device."));
      if (mode === "guest") bumpGuestUsed();
      setResult(final);
      setPhase("done");
    } catch {
      setError("Network error while generating. Please try again.");
      setPhase("configure");
    }
  }

  function reset() {
    setPhase("idle");
    setResult(null);
    setPages([]);
    setError("");
  }

  const ocr = pages.filter((p) => p.needsOCR).map((p) => p.page);

  return (
    <div className="mx-auto w-full max-w-4xl">
      {phase === "idle" && (
        <div className="rounded-2xl border border-line bg-lavender p-5 sm:p-8">
          <h2 className="mb-1 text-center text-2xl font-extrabold">Upload your PDF</h2>
          <p className="mb-5 text-center text-sm text-muted">
            {mode === "guest" ? "Your first game is free - no account needed." : remaining !== undefined ? remaining + " game" + (remaining === 1 ? "" : "s") + " left this period." : ""}
          </p>
          <Dropzone onFile={(f) => void handleFile(f)} error={error} />
        </div>
      )}

      {phase === "reading" && (
        <ProgressCard title="Reading your PDF" pct={progress.pct} message={progress.message} />
      )}

      {phase === "configure" && (
        <div className="rounded-2xl border border-line bg-white p-5 shadow-sm sm:p-8">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-xl bg-lavender text-indigo"><FileText className="h-5 w-5" /></span>
            <div className="min-w-0">
              <p className="truncate font-extrabold">{fileName}</p>
              <p className="text-sm text-muted">
                {pages.length} pages read - {pages.filter((p) => !p.needsOCR).length} with text
              </p>
            </div>
            <Button variant="ghostLight" size="sm" className="ml-auto" onClick={reset}>Choose another</Button>
          </div>
          {ocr.length > 0 && (
            <p className="mt-4 flex gap-2 rounded-card bg-amber-50 p-3 text-sm text-amber-900">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
              <span>
                Page{ocr.length > 1 ? "s" : ""} {ocr.join(", ")} contain{ocr.length > 1 ? "" : "s"} almost no extractable text (scanned images?) and will be skipped. OCR is not available yet.
              </span>
            </p>
          )}
          <h3 className="mt-6 flex items-center gap-2 text-sm font-extrabold uppercase tracking-wide text-indigo">
            <Sparkles className="h-4 w-4" aria-hidden /> {recSource === "ai" ? "AI picks for this document" : "Best fits for this document"}
          </h3>
          <ul className="mt-2 grid gap-2 sm:grid-cols-3">
            {recs.map((r) => (
              <li key={r.type} className="rounded-card border border-line bg-lavender p-3 text-sm">
                <p className="font-bold">{GAME_TYPE_INFO[r.type].label}</p>
                <p className="text-muted">{r.reason}</p>
              </li>
            ))}
          </ul>
          <h3 className="mt-6 text-sm font-extrabold uppercase tracking-wide text-indigo">Choose a game type</h3>
          <div role="radiogroup" aria-label="Game type" className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {GAME_TYPES.map((t) => {
              const locked = !allowed.includes(t);
              const active = gameType === t;
              return (
                <button
                  key={t}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => (locked ? setPrompt({ kind: "upgrade", message: GAME_TYPE_INFO[t].label + " is part of the Pro plan." }) : setGameType(t))}
                  className={
                    "relative cursor-pointer rounded-card border p-3 text-left transition-colors " +
                    (active ? "border-indigo bg-lavender ring-2 ring-indigo/30" : "border-line bg-white hover:bg-lavender")
                  }
                >
                  <span className="flex items-center gap-2 font-bold">
                    {GAME_TYPE_INFO[t].label}
                    {locked && <Lock className="h-3.5 w-3.5 text-muted" aria-label="Pro plan" />}
                    {active && <Check className="ml-auto h-4 w-4 text-indigo" aria-hidden />}
                  </span>
                  <span className="text-xs text-muted">{GAME_TYPE_INFO[t].blurb}</span>
                </button>
              );
            })}
          </div>
          <h3 className="mt-6 text-sm font-extrabold uppercase tracking-wide text-indigo">Difficulty</h3>
          <div role="radiogroup" aria-label="Difficulty" className="mt-2 flex gap-2">
            {DIFFICULTIES.map((d) => (
              <button
                key={d}
                type="button"
                role="radio"
                aria-checked={difficulty === d}
                onClick={() => setDifficulty(d)}
                className={"cursor-pointer rounded-full border px-5 py-2 text-sm font-bold capitalize " + (difficulty === d ? "border-indigo bg-indigo text-white" : "border-line bg-white hover:bg-lavender")}
              >
                {d}
              </button>
            ))}
          </div>
          {error && <p role="alert" className="mt-4 rounded-card bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p>}
          <Button size="lg" className="mt-6 w-full sm:w-auto" onClick={() => void generate()}>
            <Wand2 className="h-5 w-5" /> Generate my game
          </Button>
          <p className="mt-2 text-xs text-muted">Only extracted text is sent to our AI. Re-uploading the same PDF with the same settings costs nothing.</p>
        </div>
      )}

      {phase === "generating" && <ProgressCard title="Creating your game" pct={progress.pct} message={progress.message} />}

      {phase === "done" && result && (
        <div>
          <ResultNotes result={result} ocr={ocr} />
          <Player
            key={result.gameId}
            title={result.plan.title}
            html={result.html}
            plan={result.plan}
            watermark={result.watermark}
            verified={result.verified}
            gameId={result.gameId}
            onComplete={(points) => updateBestScore(result.gameId, points)}
          />
          <div className="mt-4 flex flex-wrap gap-3">
            <Button variant="outline" onClick={reset}>Create another game</Button>
            {mode === "user" ? (
              <Button asChild><Link href="/dashboard">Open my library</Link></Button>
            ) : (
              <Button asChild><Link href="/login?next=/create">Create a free account</Link></Button>
            )}
          </div>
        </div>
      )}

      <Dialog open={prompt !== null} onOpenChange={(o) => !o && setPrompt(null)}>
        <DialogContent className="max-w-md text-center">
          <DialogTitle className="text-xl font-extrabold">{prompt?.kind === "signup" ? "Keep the fun going" : "Upgrade to keep creating"}</DialogTitle>
          <DialogDescription className="mt-2 text-sm text-muted">{prompt?.message}</DialogDescription>
          <div className="mt-5 flex flex-col gap-2">
            {prompt?.kind === "signup" ? (
              <Button asChild size="lg"><Link href="/login?next=/create">Sign up free</Link></Button>
            ) : (
              <Button asChild size="lg"><Link href="/dashboard#plans">See Pro and Classroom plans</Link></Button>
            )}
            <Button variant="ghostLight" onClick={() => setPrompt(null)}>Maybe later</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ProgressCard({ title, pct, message }: { title: string; pct: number; message: string }) {
  return (
    <div className="rounded-2xl border border-line bg-white p-8 text-center shadow-sm" role="status" aria-live="polite">
      <h2 className="text-xl font-extrabold">{title}</h2>
      <div className="mx-auto mt-5 h-3 max-w-md overflow-hidden rounded-full bg-line">
        <div className="h-full rounded-full bg-gradient-to-r from-indigo to-violet transition-all duration-500" style={{ width: Math.max(3, pct) + "%" }} />
      </div>
      <p className="mt-3 text-sm text-muted">{message}</p>
    </div>
  );
}

function ResultNotes({ result, ocr }: { result: GenerationResult; ocr: number[] }) {
  const { coverage } = result;
  const ocrPages = coverage.ocrPages.length ? coverage.ocrPages : ocr;
  return (
    <div className="mb-3 space-y-2 text-sm">
      {result.cached && <p className="rounded-card bg-lavender p-3 font-semibold text-indigo">Reused from your library - no credit used, no AI cost.</p>}
      {coverage.contentPages > 0 && (
        <p className="rounded-card bg-lavender p-3 text-muted">
          Covers <strong className="text-ink">{coverage.coveredPages} of {coverage.contentPages}</strong> content pages
          {result.engine === "standard" ? " using the standard PDF2Play game engine." : "."}
        </p>
      )}
      {coverage.failedPages.length > 0 && (
        <p className="flex gap-2 rounded-card bg-amber-50 p-3 text-amber-900">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
          <span>We could not produce verified questions for page{coverage.failedPages.length > 1 ? "s" : ""} {coverage.failedPages.join(", ")} after 2 repair attempts.</span>
        </p>
      )}
      {ocrPages.length > 0 && (
        <p className="flex gap-2 rounded-card bg-amber-50 p-3 text-amber-900">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
          <span>Page{ocrPages.length > 1 ? "s" : ""} {ocrPages.join(", ")} had no extractable text and {ocrPages.length > 1 ? "were" : "was"} skipped.</span>
        </p>
      )}
    </div>
  );
}
