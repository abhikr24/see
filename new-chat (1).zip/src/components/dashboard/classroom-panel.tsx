"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  isOwner: boolean;
  seats: string[];
  shared: { id: string; title: string; game_type: string; page_count: number }[];
}

export function ClassroomPanel({ isOwner, seats, shared }: Props) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");

  async function call(body: Record<string, string>) {
    setMsg("");
    const res = await fetch("/api/classroom", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = (await res.json().catch(() => ({}))) as { message?: string };
    if (!res.ok) setMsg(j.message ?? "Something went wrong.");
    else {
      setEmail("");
      router.refresh();
    }
  }

  return (
    <div className="grid gap-5 md:grid-cols-2">
      <div className="rounded-card border border-line bg-white p-5">
        <h3 className="font-extrabold">Seats ({seats.length + 1} of 5 used)</h3>
        <p className="text-sm text-muted">Invited people get Classroom access when they sign in with that email.</p>
        <ul className="mt-3 space-y-2 text-sm">
          {seats.map((s) => (
            <li key={s} className="flex items-center justify-between rounded-lg bg-lavender px-3 py-2">
              <span className="truncate">{s}</span>
              {isOwner && (
                <button type="button" aria-label={"Remove " + s} className="cursor-pointer text-muted hover:text-red-600" onClick={() => void call({ action: "remove", email: s })}>
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </li>
          ))}
        </ul>
        {isOwner && (
          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void call({ action: "invite", email });
            }}
          >
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="teammate@school.org" aria-label="Seat email" className="h-10 min-w-0 flex-1 rounded-full border border-line px-4 text-sm focus:border-indigo focus:outline-none" />
            <Button type="submit" size="sm">Add seat</Button>
          </form>
        )}
        {msg && <p role="alert" className="mt-2 text-sm text-red-600">{msg}</p>}
      </div>
      <div className="rounded-card border border-line bg-white p-5">
        <h3 className="font-extrabold">Shared library</h3>
        <p className="text-sm text-muted">Use Share on any game in your library to publish it here.</p>
        {shared.length === 0 ? (
          <p className="mt-3 text-sm text-muted">Nothing shared yet.</p>
        ) : (
          <ul className="mt-3 space-y-2 text-sm">
            {shared.map((g) => (
              <li key={g.id} className="flex items-center justify-between rounded-lg bg-lavender px-3 py-2">
                <span className="truncate font-semibold">{g.title}</span>
                <Link href={"/shared/" + g.id} className="ml-3 shrink-0 font-bold text-indigo underline">Play</Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
