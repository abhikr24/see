"use client";

import { useRef, useState } from "react";
import { UploadCloud } from "lucide-react";
import { cn } from "@/lib/utils";

interface DropzoneProps {
  onFile: (file: File) => void;
  busy?: boolean;
  error?: string;
  compact?: boolean;
}

/** Accessible PDF dropzone: drag and drop, click, or keyboard. Validation happens in the caller. */
export function Dropzone({ onFile, busy, error, compact }: DropzoneProps) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  function pick(files: FileList | null) {
    const f = files?.[0];
    if (f) onFile(f);
    if (input.current) input.current.value = "";
  }

  return (
    <div>
      <div
        role="button"
        tabIndex={0}
        aria-label="Drop your PDF here or click to browse"
        onClick={() => input.current?.click()}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            input.current?.click();
          }
        }}
        onDragOver={(e) => {
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setOver(false);
          pick(e.dataTransfer.files);
        }}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center rounded-card border-2 border-dashed bg-white text-center transition-colors",
          compact ? "px-4 py-8" : "px-6 py-14",
          over ? "border-indigo bg-lavender" : "border-indigo/40 hover:border-indigo hover:bg-lavender/60",
          busy && "pointer-events-none opacity-60",
        )}
      >
        <UploadCloud className="mb-3 h-9 w-9 text-indigo" aria-hidden />
        <p className="text-base font-extrabold text-ink">Drop your PDF here</p>
        <p className="text-sm text-muted">
          or <span className="font-bold text-indigo underline">click to browse</span>
        </p>
        <input ref={input} type="file" accept="application/pdf,.pdf" className="sr-only" tabIndex={-1} onChange={(e) => pick(e.target.files)} />
      </div>
      <p className="mt-2 text-center text-xs text-muted">PDF only - up to 20MB and 30 pages. Your file never leaves your browser.</p>
      {error && (
        <p role="alert" className="mt-2 rounded-card bg-red-50 p-3 text-center text-sm font-semibold text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
