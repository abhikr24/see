import Link from "next/link";
import { ArrowRight, BookOpen, Briefcase, FlaskConical, Languages } from "lucide-react";
import { EXAMPLE_META } from "@/data/examples-meta";

const ICONS = { "history-quest": BookOpen, "science-challenge": FlaskConical, "business-simulator": Briefcase, "language-quest": Languages } as const;

export function Examples() {
  return (
    <section id="examples" className="px-5 pb-16">
      <div className="mx-auto max-w-7xl">
        <p className="text-center text-xs font-extrabold uppercase tracking-[0.18em] text-indigo">Example transformations</p>
        <h2 className="mt-2 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">See PDFs Come to Life</h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-muted">From study notes to training manuals, the possibilities are endless. Every card opens a real, playable game.</p>
        <ul className="mt-10 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {EXAMPLE_META.map((ex) => {
            const Icon = ICONS[ex.slug as keyof typeof ICONS];
            return (
              <li key={ex.slug} className="rounded-card border border-line bg-white p-4 shadow-sm transition-shadow hover:shadow-lg">
                <div className="flex items-stretch gap-2">
                  <div className="w-[42%] rounded-lg border border-line bg-white p-2">
                    <span className="inline-block rounded bg-red-500 px-1 text-[8px] font-extrabold text-white">PDF</span>
                    <p className="mt-1 text-[10px] font-extrabold leading-tight">{ex.pdfName}</p>
                    <div className="mt-2 space-y-1">
                      {[100, 85, 95, 60, 80].map((w, i) => (
                        <div key={i} className="h-1 rounded bg-line" style={{ width: w + "%" }} />
                      ))}
                    </div>
                  </div>
                  <ArrowRight className="mt-9 h-4 w-4 shrink-0 text-violet" aria-hidden />
                  <div
                    className="flex flex-1 flex-col items-center justify-between rounded-lg p-2 text-center text-white"
                    style={{ background: "linear-gradient(145deg," + ex.from + "," + ex.to + ")" }}
                  >
                    <p className="text-[10px] font-extrabold leading-tight">{ex.gameName}</p>
                    <Icon className="h-8 w-8 opacity-90" aria-hidden />
                    <span className="h-1 w-8 rounded-full bg-white/60" />
                  </div>
                </div>
                <p className="mt-3 text-xs text-muted">{ex.blurb}</p>
                <Link
                  href={"/examples/" + ex.slug}
                  className="mt-3 inline-flex h-10 w-full items-center justify-center rounded-full bg-indigo text-sm font-bold text-white hover:bg-indigo-600"
                  aria-label={"Start Game: " + ex.gameName}
                >
                  Start Game
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
