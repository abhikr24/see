import Link from "next/link";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FAQS = [
  {
    q: "What types of PDFs can I upload?",
    a: "Any text-based PDF up to 20MB and 30 pages. Scanned, image-only pages have no extractable text, so we tell you exactly which pages were skipped instead of guessing. Password-protected PDFs are rejected with a clear message.",
  },
  {
    q: "Is my data secure?",
    a: "Your PDF file never leaves your browser. We read it on your device and send only the extracted text to our AI provider to design the game. Finished games are stored in your browser (IndexedDB), not on our servers. Account, plan and payment records are stored in Supabase.",
  },
  {
    q: "How do I know the questions are accurate?",
    a: "Every question must carry a word-for-word quote from a specific page. We check that quote against the text we extracted from your PDF and drop any question that does not match. You will see a badge like \"Verified 18 of 18 questions\" and a \"Source: p.N\" chip on each question.",
  },
  {
    q: "Can I share the games with others?",
    a: "Games live on your device. On the Classroom plan, up to 5 seats (invited by email) can publish games to a shared library that every seat can play.",
  },
  {
    q: "What does the free plan include?",
    a: "Guests get one free game with no account. A free account gets 3 games per month, up to 30 pages per PDF, Quiz Rush and Flashcards, and a small PDF2Play watermark. Pro unlocks 300 games a month, all six game types and no watermark.",
  },
  {
    q: "Do you offer refunds?",
    a: "Yes. If you have used fewer than 10 games, you can ask for a full refund within 7 days of payment. Refunds go back to your original payment method through Razorpay. The full terms are on our refund policy page.",
  },
];

export function Faq() {
  return (
    <section id="faqs" className="px-5 pb-16">
      <div className="mx-auto max-w-3xl">
        <p className="text-center text-xs font-extrabold uppercase tracking-[0.18em] text-indigo">Frequently asked questions</p>
        <h2 className="mt-2 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">Got Questions? We&apos;ve Got Answers.</h2>
        <Accordion type="single" collapsible className="mt-8 space-y-3">
          {FAQS.map((f, i) => (
            <AccordionItem key={f.q} value={"q" + i}>
              <AccordionTrigger>{f.q}</AccordionTrigger>
              <AccordionContent>
                {f.a}
                {i === 5 && (
                  <>
                    {" "}
                    <Link href="/refund" className="font-semibold text-indigo underline">Read the refund policy</Link>.
                  </>
                )}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
