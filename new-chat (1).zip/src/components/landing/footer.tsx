import Link from "next/link";
import { ArrowRight, Check } from "lucide-react";
import { Logo } from "@/components/landing/nav";
import { SUPPORT_EMAIL } from "@/lib/site";

export function CtaBanner() {
  return (
    <section className="px-3 pb-10 sm:px-5">
      <div className="hero-bg mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 rounded-[24px] px-6 py-10 text-white lg:flex-row lg:px-12">
        <div className="text-center lg:text-left">
          <h2 className="text-2xl font-extrabold sm:text-3xl">Ready to Turn Your PDFs into Games?</h2>
          <p className="mt-1 text-white/75">Make your first game free - no account needed.</p>
        </div>
        <div className="flex flex-col items-center gap-4 lg:items-end">
          <Link
            href="/try"
            className="inline-flex h-12 items-center gap-2 rounded-full bg-indigo px-7 text-base font-bold text-white shadow-[0_8px_24px_rgba(91,91,245,0.5)] hover:bg-indigo-600"
          >
            Get Started for Free <ArrowRight className="h-5 w-5" />
          </Link>
          <ul className="flex flex-wrap justify-center gap-x-5 gap-y-1 text-xs text-white/80">
            {["No credit card required", "Instant setup", "No auto-renewal"].map((t) => (
              <li key={t} className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-violet" strokeWidth={3} /> {t}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

const LINKS = [
  { label: "Features", href: "/#features" },
  { label: "Examples", href: "/#examples" },
  { label: "Pricing", href: "/#pricing" },
  { label: "FAQ", href: "/#faqs" },
  { label: "Privacy", href: "/privacy" },
  { label: "Terms", href: "/terms" },
  { label: "Refunds", href: "/refund" },
];

export function Footer() {
  return (
    <footer className="border-t border-line px-5 py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 lg:flex-row">
        <div>
          <Logo className="text-ink" />
          <p className="mt-1 text-xs text-muted">Learn Today. Play Tomorrow.</p>
        </div>
        <nav aria-label="Footer">
          <ul className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm font-semibold text-muted">
            {LINKS.map((l) => (
              <li key={l.label}><Link href={l.href} className="hover:text-indigo">{l.label}</Link></li>
            ))}
            <li><a href={"mailto:" + SUPPORT_EMAIL} className="hover:text-indigo">Contact</a></li>
          </ul>
        </nav>
        <p className="text-xs text-muted">&copy; {new Date().getFullYear()} PDF2Play. All rights reserved.</p>
      </div>
    </footer>
  );
}
