"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowRight, Check, Cpu, FileUp, Gamepad2, Play, Star } from "lucide-react";
import { Player } from "@/components/player/player";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { DEMO_SLUG } from "@/data/examples-meta";

const TRUST = ["No credit card required", "Instant results", "Works with any PDF", "Trusted by 50K+ users"];

interface DemoData {
  title: string;
  html: string;
  verified: { verified: number; total: number };
}

function DemoModal({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const [demo, setDemo] = useState<DemoData | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    if (!open || demo) return;
    let active = true;
    fetch("/api/examples/" + DEMO_SLUG)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("failed"))))
      .then((d: DemoData) => active && setDemo(d))
      .catch(() => active && setFailed(true));
    return () => {
      active = false;
    };
  }, [open, demo]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl bg-white">
        <DialogTitle className="pr-10 text-xl font-extrabold">Watch the demo - play a real game</DialogTitle>
        <DialogDescription className="mb-3 mt-1 text-sm text-muted">
          This game was generated from a short Cell Biology PDF. Every question links back to its page.
        </DialogDescription>
        {demo ? (
          <Player title={demo.title} html={demo.html} verified={demo.verified} />
        ) : failed ? (
          <p role="alert" className="p-6 text-center font-semibold text-red-600">The demo could not be loaded. Please try again.</p>
        ) : (
          <p className="p-10 text-center text-muted" role="status">Loading demo&hellip;</p>
        )}
      </DialogContent>
    </Dialog>
  );
}

function HeroArt() {
  const options = ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"];
  return (
    <div className="relative mx-auto w-full max-w-[620px]" aria-hidden="true">
      <div className="flex items-center justify-center gap-2 sm:gap-3">
        <div className="floaty w-[34%] shrink-0 -rotate-3 rounded-xl bg-white p-3 shadow-2xl">
          <span className="inline-block rounded bg-red-500 px-1.5 py-0.5 text-[10px] font-extrabold text-white">PDF</span>
          <p className="mt-1.5 text-[11px] font-extrabold leading-tight text-ink">Cell Biology</p>
          <p className="text-[11px] font-bold leading-tight text-ink">Study Notes.pdf</p>
          <div className="mt-3 space-y-1.5">
            {[100, 90, 95, 70, 85, 60].map((w, i) => (
              <div key={i} className="h-1.5 rounded bg-line" style={{ width: w + "%" }} />
            ))}
          </div>
          <div className="mt-3 grid h-14 place-items-center rounded-lg bg-lavender">
            <div className="h-8 w-8 rounded-full border-4 border-violet/50" />
          </div>
        </div>
        <div className="grid h-12 w-9 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-indigo to-violet text-white shadow-lg sm:h-14 sm:w-11">
          <ArrowRight className="h-6 w-6" />
        </div>
        <div className="glass w-[58%] rounded-2xl p-3 sm:p-4">
          <div className="mb-3 flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-full bg-white/10 text-[10px] text-white">&lsaquo;</span>
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/15">
              <div className="h-full w-1/3 rounded-full bg-success" />
            </div>
            <span className="text-[10px] font-bold leading-none text-white/70">Level 2</span>
            <span className="flex items-center gap-1 rounded-lg bg-white/10 px-2 py-1 text-[11px] font-extrabold text-white">
              <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> Score 850
            </span>
          </div>
          <p className="mb-3 text-center text-[13px] font-extrabold leading-snug text-white sm:text-sm">What is the powerhouse of the cell?</p>
          <div className="space-y-2">
            {options.map((o) => {
              const correct = o === "Mitochondria";
              return (
                <div
                  key={o}
                  className={
                    "flex items-center gap-2 rounded-lg border px-3 py-2 text-[11px] font-bold sm:text-xs " +
                    (correct ? "border-success bg-success text-white shadow-[0_0_18px_rgba(34,181,115,0.5)]" : "border-white/15 bg-white/5 text-white/85")
                  }
                >
                  <span className={"grid h-4 w-4 shrink-0 place-items-center rounded-full border " + (correct ? "border-white bg-white text-success" : "border-white/40")}>
                    {correct && <Check className="h-3 w-3" strokeWidth={3} />}
                  </span>
                  {o}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <div className="mt-5 flex justify-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-violet/40 bg-white/5 px-4 py-2 text-xs font-bold text-white sm:text-sm">
          <Gamepad2 className="h-4 w-4 text-violet" /> From boring PDFs&hellip; to exciting games!
        </span>
      </div>
      <ul className="absolute -right-2 top-2 hidden w-40 space-y-3 xl:block">
        {[
          { icon: FileUp, text: "Upload Any PDF" },
          { icon: Cpu, text: "Powered by AI" },
          { icon: Gamepad2, text: "Play & Learn" },
        ].map(({ icon: Icon, text }) => (
          <li key={text} className="flex items-center gap-3 rounded-xl border border-violet/30 bg-white/5 p-3 text-xs font-bold text-white backdrop-blur">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-indigo/40"><Icon className="h-4 w-4" /></span>
            {text}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Hero() {
  const [demoOpen, setDemoOpen] = useState(false);
  return (
    <section className="hero-bg relative overflow-hidden pb-24 pt-10 text-white lg:pb-28 lg:pt-14">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-[1fr_1.15fr]">
        <div>
          <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-violet">Turn documents into experiences</p>
          <h1 className="mt-4 text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
            Transform Any PDF
            <span className="text-gradient block">Into a Game</span>
          </h1>
          <p className="mt-5 max-w-lg text-lg leading-relaxed text-white/80">
            Upload a PDF and let AI turn your content into an engaging interactive game. Learn, teach, and play — like never before.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg"><Link href="/try">Start for Free <ArrowRight className="h-5 w-5" /></Link></Button>
            <Button size="lg" variant="dark" onClick={() => setDemoOpen(true)}>
              <span className="grid h-6 w-6 place-items-center rounded-full bg-white text-navy"><Play className="h-3 w-3 fill-current" /></span> Watch Demo
            </Button>
          </div>
          <ul className="mt-8 flex flex-wrap gap-x-5 gap-y-2 text-sm text-white/80">
            {TRUST.map((t) => (
              <li key={t} className="flex items-center gap-2">
                <span className="grid h-5 w-5 place-items-center rounded-full border border-violet/60 text-violet"><Check className="h-3 w-3" strokeWidth={3} /></span>
                {t}
              </li>
            ))}
          </ul>
        </div>
        <HeroArt />
      </div>
      <DemoModal open={demoOpen} onOpenChange={setDemoOpen} />
    </section>
  );
}
