"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Trophy } from "lucide-react";
import { Dropzone } from "@/components/dropzone";
import { validatePdf } from "@/lib/pdf/extract-client";
import { setPendingFile } from "@/lib/pending-file";
import { useUser } from "@/lib/use-user";

function StepHead({ n, title, text }: { n: number; title: string; text: string }) {
  return (
    <div className="mb-4 flex items-start gap-3">
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-indigo text-sm font-extrabold text-white">{n}</span>
      <div>
        <h3 className="text-lg font-extrabold">{title}</h3>
        <p className="text-sm text-muted">{text}</p>
      </div>
    </div>
  );
}

function Bar({ label, to, delay }: { label: string; to: number; delay: number }) {
  return (
    <div className="flex items-center gap-3">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-lavender text-indigo"><Sparkles className="h-4 w-4" aria-hidden /></span>
      <div className="flex-1">
        <p className="mb-1 text-xs font-semibold text-ink">{label}</p>
        <div className="h-2 overflow-hidden rounded-full bg-line">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-indigo to-violet"
            initial={{ width: "0%" }}
            whileInView={{ width: to + "%" }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 1.6, delay, ease: "easeOut" }}
          />
        </div>
      </div>
    </div>
  );
}

export function HowItWorks() {
  const router = useRouter();
  const { user } = useUser();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onFile(file: File) {
    setError("");
    setBusy(true);
    const v = await validatePdf(file);
    setBusy(false);
    if (!v.ok) {
      setError(v.message);
      return;
    }
    setPendingFile(file);
    router.push(user ? "/create" : "/try");
  }

  const confetti = ["#5B5BF5", "#22B573", "#f59e0b", "#8B7CF8", "#f43f5e", "#0ea5c6"];
  return (
    <section id="how-it-works" className="px-3 pb-16 sm:px-5">
      <div className="mx-auto max-w-7xl rounded-[28px] bg-[#F3F4FA] px-5 py-12 sm:px-10">
        <p className="text-center text-xs font-extrabold uppercase tracking-[0.18em] text-indigo">How it works</p>
        <h2 className="mt-2 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">From PDF to Play in 3 Simple Steps</h2>
        <div className="mt-10 grid gap-10 lg:grid-cols-3 lg:gap-8">
          <div>
            <StepHead n={1} title="Upload Your PDF" text="Choose any PDF - notes, textbooks, manuals, or reports." />
            <Dropzone compact onFile={(f) => void onFile(f)} busy={busy} error={error} />
          </div>
          <div>
            <StepHead n={2} title="AI Creates Your Game" text="Our AI analyzes your content and generates an interactive game instantly." />
            <div className="space-y-4 rounded-card border border-line bg-white p-5">
              <Bar label="Analyzing content…" to={88} delay={0} />
              <Bar label="Creating your game…" to={64} delay={0.5} />
            </div>
          </div>
          <div>
            <StepHead n={3} title="Play & Learn" text="Jump into your custom game and turn knowledge into an adventure!" />
            <div className="relative overflow-hidden rounded-card border border-line bg-white p-5 text-center">
              <div className="confetti pointer-events-none absolute inset-0" aria-hidden>
                {confetti.map((c, i) => (
                  <i key={c} style={{ background: c, left: 10 + i * 15 + "%", animationDelay: i * 0.35 + "s" }} />
                ))}
              </div>
              <Trophy className="mx-auto h-9 w-9 text-amber-500" aria-hidden />
              <p className="mt-1 text-lg font-extrabold">Great Job!</p>
              <p className="text-sm text-muted">You scored 100%</p>
              <Link
                href="/examples/history-quest"
                className="mt-4 inline-flex h-11 w-full items-center justify-center rounded-full bg-indigo text-sm font-bold text-white shadow-[0_8px_24px_rgba(91,91,245,0.35)] hover:bg-indigo-600"
              >
                Play Again
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
