"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Gamepad2, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useUser } from "@/lib/use-user";
import { cn } from "@/lib/utils";

export const NAV_LINKS = [
  { label: "Features", href: "/#features" },
  { label: "How It Works", href: "/#how-it-works" },
  { label: "Examples", href: "/#examples" },
  { label: "Pricing", href: "/#pricing" },
  { label: "FAQs", href: "/#faqs" },
];

export function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" className={cn("flex items-center gap-2 text-xl font-extrabold tracking-tight", className)} aria-label="PDF2Play home">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-indigo to-violet text-white shadow-lg">
        <Gamepad2 className="h-5 w-5" aria-hidden />
      </span>
      <span>
        PDF2<span className="text-violet">Play</span>
      </span>
    </Link>
  );
}

export function Nav({ solid = false }: { solid?: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { user } = useUser();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full text-white transition-all",
        scrolled || solid ? "border-b border-white/10 bg-navy/80 backdrop-blur-xl" : "bg-navy",
      )}
    >
      <nav aria-label="Main" className="mx-auto flex h-[72px] max-w-7xl items-center gap-6 px-5">
        <Logo />
        <ul className="ml-6 hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((l) => (
            <li key={l.href}>
              <Link href={l.href} className="rounded-full px-3 py-2 text-sm font-semibold text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <div className="ml-auto hidden items-center gap-2 lg:flex">
          {user ? (
            <>
              <Button asChild variant="ghost"><Link href="/dashboard">Dashboard</Link></Button>
              <Button asChild><Link href="/create">Create a game</Link></Button>
            </>
          ) : (
            <>
              <Button asChild variant="ghost"><Link href="/login">Sign In</Link></Button>
              <Button asChild><Link href="/try">Get Started</Link></Button>
            </>
          )}
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <button
            type="button"
            aria-label="Open menu"
            onClick={() => setOpen(true)}
            className="ml-auto grid h-10 w-10 cursor-pointer place-items-center rounded-full hover:bg-white/10 lg:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>
          <DialogContent side="right">
            <DialogTitle className="sr-only">Menu</DialogTitle>
            <div className="mt-8 flex flex-col gap-1">
              {NAV_LINKS.map((l) => (
                <DialogClose asChild key={l.href}>
                  <Link href={l.href} className="rounded-card px-3 py-3 text-lg font-bold hover:bg-lavender">{l.label}</Link>
                </DialogClose>
              ))}
              <div className="mt-4 flex flex-col gap-2">
                {user ? (
                  <>
                    <DialogClose asChild><Button asChild variant="outline"><Link href="/dashboard">Dashboard</Link></Button></DialogClose>
                    <DialogClose asChild><Button asChild><Link href="/create">Create a game</Link></Button></DialogClose>
                  </>
                ) : (
                  <>
                    <DialogClose asChild><Button asChild variant="outline"><Link href="/login">Sign In</Link></Button></DialogClose>
                    <DialogClose asChild><Button asChild><Link href="/try">Get Started</Link></Button></DialogClose>
                  </>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </nav>
    </header>
  );
}
