"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { PLAN_LIST, formatINR, type PaidPlanId, type Plan, type PlanId } from "@/lib/plans";
import { useUser } from "@/lib/use-user";
import { cn } from "@/lib/utils";

interface RazorpaySuccess {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}
interface RazorpayInstance {
  open: () => void;
  on: (event: string, cb: () => void) => void;
}
interface RazorpayOptions {
  key: string;
  amount: number;
  currency: string;
  order_id: string;
  name: string;
  description: string;
  prefill: { email: string };
  theme: { color: string };
  handler: (r: RazorpaySuccess) => void;
  modal: { ondismiss: () => void };
}
declare global {
  interface Window {
    Razorpay?: new (opts: RazorpayOptions) => RazorpayInstance;
  }
}

function loadCheckout(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (window.Razorpay) return resolve();
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("Could not load Razorpay Checkout."));
    document.body.appendChild(s);
  });
}

export function Pricing({ currentPlan }: { currentPlan?: PlanId }) {
  const router = useRouter();
  const { user } = useUser();
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [busy, setBusy] = useState<PaidPlanId | null>(null);
  const [message, setMessage] = useState("");
  const [notify, setNotify] = useState<PaidPlanId | null>(null);
  const [email, setEmail] = useState("");
  const [notifyState, setNotifyState] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    let active = true;
    fetch("/api/razorpay/status")
      .then((r) => r.json())
      .then((j: { enabled?: boolean }) => active && setEnabled(Boolean(j.enabled)))
      .catch(() => active && setEnabled(false));
    return () => {
      active = false;
    };
  }, []);

  async function checkout(planId: PaidPlanId) {
    setBusy(planId);
    setMessage("");
    try {
      await loadCheckout();
      const res = await fetch("/api/razorpay/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan: planId }),
      });
      const o = (await res.json()) as { message?: string; orderId: string; amount: number; currency: string; keyId: string; email: string; planName: string };
      if (!res.ok) {
        setMessage(o.message ?? "Could not start checkout.");
        setBusy(null);
        return;
      }
      const Razorpay = window.Razorpay;
      if (!Razorpay) throw new Error("Checkout unavailable");
      const rz = new Razorpay({
        key: o.keyId,
        amount: o.amount,
        currency: o.currency,
        order_id: o.orderId,
        name: "PDF2Play",
        description: o.planName + " plan - 30 days",
        prefill: { email: o.email },
        theme: { color: "#5B5BF5" },
        modal: { ondismiss: () => setBusy(null) },
        handler: async (r) => {
          setMessage("Payment received. Activating your plan\u2026");
          const v = await fetch("/api/razorpay/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(r),
          });
          const j = (await v.json().catch(() => ({}))) as { message?: string };
          setBusy(null);
          if (v.ok) {
            router.push("/dashboard?upgraded=1");
            router.refresh();
          } else setMessage(j.message ?? "Activation failed. If you were charged, your plan will be applied automatically.");
        },
      });
      rz.on("payment.failed", () => {
        setMessage("The payment failed. You have not been charged. Please try again.");
        setBusy(null);
      });
      rz.open();
    } catch {
      setMessage("Could not open checkout. Please try again.");
      setBusy(null);
    }
  }

  async function submitNotify() {
    if (!notify) return;
    setNotifyState(null);
    const res = await fetch("/api/notify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, plan: notify }),
    });
    const j = (await res.json().catch(() => ({}))) as { message?: string };
    setNotifyState(res.ok ? { ok: true, text: "Thanks! We will email you the moment payments open." } : { ok: false, text: j.message ?? "Something went wrong." });
  }

  function cta(plan: Plan) {
    const base = "w-full";
    if (plan.id === "free") {
      return (
        <Button asChild variant="outline" className={base}>
          <Link href={user ? "/create" : "/try"}>Get Started</Link>
        </Button>
      );
    }
    const pid = plan.id as PaidPlanId;
    const label = currentPlan === plan.id ? "Renew " + plan.name : "Upgrade to " + plan.name;
    if (enabled === null) return <Button className={base} variant={plan.popular ? "primary" : "outline"} disabled>Loading&hellip;</Button>;
    if (!enabled) {
      return (
        <Button className={base} variant={plan.popular ? "primary" : "outline"} onClick={() => { setNotifyState(null); setNotify(pid); }}>
          Notify me
        </Button>
      );
    }
    if (!user) {
      return (
        <Button asChild className={base} variant={plan.popular ? "primary" : "outline"}>
          <Link href="/login?next=/dashboard%23plans">Sign in to upgrade</Link>
        </Button>
      );
    }
    return (
      <Button className={base} variant={plan.popular ? "primary" : "outline"} onClick={() => void checkout(pid)} disabled={busy !== null}>
        {busy === pid ? "Opening checkout\u2026" : label}
      </Button>
    );
  }

  return (
    <section id="pricing" className="px-5 pb-16">
      <div className="mx-auto max-w-6xl">
        <p className="text-center text-xs font-extrabold uppercase tracking-[0.18em] text-indigo">Pricing</p>
        <h2 className="mt-2 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">Choose the Plan That Fits You</h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-muted">Simple, transparent pricing. No hidden fees.</p>
        <ul className="mt-10 grid items-stretch gap-5 md:grid-cols-3">
          {PLAN_LIST.map((plan) => (
            <li
              key={plan.id}
              className={cn(
                "relative flex flex-col rounded-card border bg-white p-6",
                plan.popular ? "border-indigo shadow-[0_20px_50px_rgba(91,91,245,0.18)] md:-mt-3 md:pb-9" : "border-line",
              )}
            >
              {plan.popular && (
                <span className="absolute -top-3 right-5 rounded-full bg-gradient-to-r from-indigo to-violet px-3 py-1 text-xs font-extrabold text-white">Most Popular</span>
              )}
              <h3 className="text-lg font-extrabold">{plan.name}</h3>
              <p className="text-sm text-muted">{plan.tagline}</p>
              <p className="mt-4 flex items-end gap-1">
                <span className="text-4xl font-extrabold">{formatINR(plan.pricePaise)}</span>
                <span className="pb-1 text-sm text-muted">/ {plan.interval === "forever" ? "forever" : "month"}</span>
              </p>
              <ul className="mt-5 flex-1 space-y-2.5 text-sm">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-indigo" strokeWidth={3} aria-hidden /> {f}
                  </li>
                ))}
              </ul>
              <div className="mt-6">{cta(plan)}</div>
            </li>
          ))}
        </ul>
        <p className="mt-5 text-center text-xs text-muted">
          Prices are in INR and include all taxes. Each payment buys 30 days of access (no auto-renewal). Payments are secured by Razorpay.{" "}
          <Link href="/refund" className="font-semibold text-indigo underline">Refund policy</Link>
        </p>
        {message && <p role="status" className="mx-auto mt-3 max-w-md rounded-card bg-lavender p-3 text-center text-sm font-semibold text-indigo">{message}</p>}
      </div>
      <Dialog open={notify !== null} onOpenChange={(o) => !o && setNotify(null)}>
        <DialogContent className="max-w-md">
          <DialogTitle className="text-xl font-extrabold">Get notified when payments open</DialogTitle>
          <DialogDescription className="mt-1 text-sm text-muted">
            Online payments are not switched on for this deployment yet. Leave your email and we will tell you when the {notify === "classroom" ? "Classroom" : "Pro"} plan is available.
          </DialogDescription>
          {notifyState?.ok ? (
            <p className="mt-4 rounded-card bg-success/10 p-3 text-sm font-semibold text-success">{notifyState.text}</p>
          ) : (
            <form
              className="mt-4 flex flex-col gap-3"
              onSubmit={(e) => {
                e.preventDefault();
                void submitNotify();
              }}
            >
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                aria-label="Email address"
                placeholder="you@example.com"
                className="h-11 rounded-full border border-line px-4 text-sm focus:border-indigo focus:outline-none"
              />
              {notifyState && !notifyState.ok && <p role="alert" className="text-sm text-red-600">{notifyState.text}</p>}
              <Button type="submit">Notify me</Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
