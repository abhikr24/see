import { GraduationCap, Gamepad2, Users, Zap } from "lucide-react";

const TILES = [
  { icon: Zap, title: "Instant Conversion", text: "Upload your PDF and get a playable game in seconds." },
  { icon: Gamepad2, title: "Multiple Game Types", text: "Quizzes, challenges, flashcards, simulations and more." },
  { icon: GraduationCap, title: "Learn Faster", text: "Make studying and training fun and effective." },
  { icon: Users, title: "For Everyone", text: "Students, teachers, professionals, and creators alike." },
];

export function Why() {
  return (
    <section id="features" className="relative -mt-10 rounded-t-[40px] bg-white px-5 pb-16 pt-16 sm:pb-20">
      <div className="mx-auto max-w-6xl">
        <p className="text-center text-xs font-extrabold uppercase tracking-[0.18em] text-indigo">Why PDF2Play</p>
        <h2 className="mt-2 text-center text-3xl font-extrabold tracking-tight sm:text-4xl">More Than a Reader. A Game Changer.</h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-muted">Turn static documents into interactive, engaging games in seconds.</p>
        <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {TILES.map(({ icon: Icon, title, text }) => (
            <li key={title} className="rounded-card border border-line bg-white p-6 text-center transition-shadow hover:shadow-lg">
              <span className="mx-auto grid h-14 w-14 place-items-center rounded-card bg-lavender text-indigo">
                <Icon className="h-7 w-7" aria-hidden />
              </span>
              <h3 className="mt-4 text-lg font-extrabold">{title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted">{text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
