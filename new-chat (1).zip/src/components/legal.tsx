import type { ReactNode } from "react";
import { PageShell } from "@/components/page-shell";

export function LegalPage({ title, updated, children }: { title: string; updated: string; children: ReactNode }) {
  return (
    <PageShell>
      <article className="mx-auto max-w-3xl [&_h2]:mt-8 [&_h2]:text-xl [&_h2]:font-extrabold [&_li]:mt-1.5 [&_p]:mt-3 [&_p]:leading-relaxed [&_p]:text-muted [&_ul]:mt-3 [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:text-muted">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{title}</h1>
        <p className="!mt-1 text-sm">Last updated: {updated}</p>
        {children}
      </article>
    </PageShell>
  );
}
