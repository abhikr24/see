"use client";

import Link from "next/link";
import { useMemo, useState, useSyncExternalStore } from "react";
import { Play, Share2, Trash2, Trophy } from "lucide-react";
import { Player } from "@/components/player/player";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { LIBRARY_EVENT, clearLibrary, deleteGame, getGame, parseIndex, readRawIndex, updateBestScore, type StoredGame } from "@/lib/library";
import { GAME_TYPE_INFO } from "@/lib/plans";

function subscribe(cb: () => void): () => void {
  window.addEventListener("storage", cb);
  window.addEventListener(LIBRARY_EVENT, cb);
  return () => {
    window.removeEventListener("storage", cb);
    window.removeEventListener(LIBRARY_EVENT, cb);
  };
}

interface Props {
  mode: "guest" | "user";
  canShare?: boolean;
}

/** Games saved in this browser (IndexedDB + localStorage index). Survives reloads. */
export function LocalLibrary({ mode, canShare }: Props) {
  const raw = useSyncExternalStore(subscribe, readRawIndex, () => "");
  const entries = useMemo(() => parseIndex(raw), [raw]);
  const [playing, setPlaying] = useState<StoredGame | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [note, setNote] = useState("");

  async function open(id: string) {
    const g = await getGame(id);
    if (g) setPlaying(g);
    else setNote("That game is no longer stored in this browser.");
  }

  async function share(id: string) {
    setNote("");
    const g = await getGame(id);
    const entry = entries.find((e) => e.id === id);
    if (!g || !entry) return setNote("That game is no longer stored in this browser.");
    const res = await fetch("/api/classroom", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "share", title: entry.title, gameType: entry.type, pageCount: entry.pageCount, plan: g.plan, html: g.html }),
    });
    const j = (await res.json().catch(() => ({}))) as { message?: string };
    setNote(res.ok ? "Shared with your classroom." : (j.message ?? "Could not share."));
  }

  if (entries.length === 0) {
    return (
      <div className="rounded-card border border-dashed border-line bg-lavender/50 p-8 text-center text-sm text-muted">
        Your library is empty. Games you create are saved in this browser and stay here after you reload.
      </div>
    );
  }

  return (
    <div>
      <ul className="grid gap-3 sm:grid-cols-2">
        {entries.map((g) => (
          <li key={g.id} className="rounded-card border border-line bg-white p-4">
            <p className="truncate font-extrabold">{g.title}</p>
            <p className="text-xs text-muted">
              {GAME_TYPE_INFO[g.type]?.label ?? g.type} &middot; {g.pageCount} pages &middot; {new Date(g.date).toLocaleDateString()}
            </p>
            <p className="mt-1 flex items-center gap-1 text-xs font-semibold text-indigo"><Trophy className="h-3.5 w-3.5" /> Best score: {g.bestScore}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {mode === "user" ? (
                <Button asChild size="sm"><Link href={"/play/" + g.id}><Play className="h-4 w-4" /> Play</Link></Button>
              ) : (
                <Button size="sm" onClick={() => void open(g.id)}><Play className="h-4 w-4" /> Play</Button>
              )}
              {canShare && (
                <Button size="sm" variant="outline" onClick={() => void share(g.id)}><Share2 className="h-4 w-4" /> Share</Button>
              )}
              <Button size="sm" variant="ghostLight" onClick={() => void deleteGame(g.id)} aria-label={"Delete " + g.title}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </li>
        ))}
      </ul>
      {note && <p role="status" className="mt-3 text-sm font-semibold text-indigo">{note}</p>}
      <div className="mt-4">
        <Button size="sm" variant="ghostLight" onClick={() => setConfirmClear(true)}>Clear all games on this device</Button>
      </div>
      <Dialog open={confirmClear} onOpenChange={setConfirmClear}>
        <DialogContent className="max-w-sm">
          <DialogTitle className="text-lg font-extrabold">Clear your library?</DialogTitle>
          <DialogDescription className="mt-1 text-sm text-muted">This permanently removes every saved game from this browser. It cannot be undone.</DialogDescription>
          <div className="mt-4 flex gap-2">
            <Button variant="outline" onClick={() => setConfirmClear(false)}>Cancel</Button>
            <Button onClick={() => { void clearLibrary().then(() => setConfirmClear(false)); }}>Clear all</Button>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={playing !== null} onOpenChange={(o) => !o && setPlaying(null)}>
        <DialogContent className="max-w-4xl">
          <DialogTitle className="sr-only">{playing?.plan.title ?? "Game"}</DialogTitle>
          {playing && (
            <Player title={playing.plan.title} html={playing.html} plan={playing.plan} watermark={playing.watermark} verified={playing.verified} gameId={playing.id} onComplete={(p) => updateBestScore(playing.id, p)} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
