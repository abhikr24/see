"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Player } from "@/components/player/player";
import { Button } from "@/components/ui/button";
import { getGame, updateBestScore, type StoredGame } from "@/lib/library";

/** Loads a game from this browser's IndexedDB and plays it in the sandbox. */
export function PlayLocal({ id }: { id: string }) {
  const [state, setState] = useState<{ status: "loading" | "missing" | "ready"; game?: StoredGame }>({ status: "loading" });
  useEffect(() => {
    let active = true;
    getGame(id).then((game) => {
      if (active) setState(game ? { status: "ready", game } : { status: "missing" });
    });
    return () => {
      active = false;
    };
  }, [id]);

  if (state.status === "loading") return <p className="p-10 text-center text-muted" role="status">Loading your game&hellip;</p>;
  if (state.status === "missing" || !state.game) {
    return (
      <div className="rounded-card border border-line bg-lavender p-8 text-center">
        <h2 className="text-xl font-extrabold">Game not found on this device</h2>
        <p className="mt-2 text-sm text-muted">Games are stored in the browser where you created them. Create it again or open it on that device.</p>
        <Button asChild className="mt-4"><Link href="/create">Create a game</Link></Button>
      </div>
    );
  }
  const g = state.game;
  return <Player title={g.plan.title} html={g.html} plan={g.plan} watermark={g.watermark} verified={g.verified} gameId={g.id} onComplete={(p) => updateBestScore(g.id, p)} />;
}
