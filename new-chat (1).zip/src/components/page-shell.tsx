import type { ReactNode } from "react";
import { Footer } from "@/components/landing/footer";
import { Nav } from "@/components/landing/nav";

/** Shared chrome for inner pages (solid nav + footer). */
export function PageShell({ children, wide = false }: { children: ReactNode; wide?: boolean }) {
  return (
    <>
      <Nav solid />
      <main id="main" className={"mx-auto w-full px-5 py-10 sm:py-14 " + (wide ? "max-w-6xl" : "max-w-4xl")}>
        {children}
      </main>
      <Footer />
    </>
  );
}
