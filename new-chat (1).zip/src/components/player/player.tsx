"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Flag, Maximize2, RotateCcw, ShieldCheck, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { GameMessageSchema, type GamePlan } from "@/lib/ai/schema";
import { buildStandardHtml } from "@/lib/game/engine";
import { hardenHtml } from "@/lib/game/shell";

export interface PlayerProps {
  title: string;
  html: string;
  plan?: GamePlan;
  watermark?: boolean;
  verified?: { verified: number; total: number };
  gameId?: string;
  onComplete?: (points: number) => void;
}

interface Score {
  points: number;
  correct: number;
  answered: number;
  total: number;
}

/**
 * Sandboxed player. The game runs in an iframe with sandbox="allow-scripts" (no same-origin, no top navigation)
 * and our CSP. We only accept postMessage events from that iframe's window and only with a valid payload shape.
 * The game source is never rendered as text anywhere in the UI.
 */
export function Player({ title, html, plan, watermark = false, verified, gameId, onComplete }: PlayerProps) {
  const frameRef = useRef<HTMLIFrameElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [useFallback, setUseFallback] = useState(false);
  const [score, setScore] = useState<Score | null>(null);
  const [done, setDone] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [note, setNote] = useState("");
  const [reportState, setReportState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [reportMsg, setReportMsg] = useState("");

  const doc = useMemo(() => {
    try {
      const source = useFallback && plan ? buildStandardHtml(plan, { watermark }) : html;
      return { html: hardenHtml(source), error: "" };
    } catch (e) {
      return { html: "", error: e instanceof Error ? e.message : "This game could not be loaded." };
    }
  }, [html, plan, useFallback, watermark]);

  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      if (e.source !== frameRef.current?.contentWindow) return;
      const parsed = GameMessageSchema.safeParse(e.data);
      if (!parsed.success) return;
      const m = parsed.data;
      if (m.type === "ready") {
        setReady(true);
        return;
      }
      setScore({ points: m.points, correct: m.correct, answered: m.answered, total: m.total });
      if (m.type === "complete") {
        setDone(true);
        onComplete?.(m.points);
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [onComplete]);

  // If the model-written game never reports "ready", silently switch to the standard engine.
  useEffect(() => {
    if (ready || useFallback || !plan) return;
    const t = setTimeout(() => setUseFallback(true), 6000);
    return () => clearTimeout(t);
  }, [ready, useFallback, plan, doc.html]);

  const restart = useCallback(() => {
    setDone(false);
    setScore(null);
    frameRef.current?.contentWindow?.postMessage({ type: "restart" }, "*");
  }, []);

  const fullscreen = useCallback(() => {
    const el = boxRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  }, []);

  async function sendReport() {
    setReportState("sending");
    try {
      const res = await fetch("/api/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gameId, gameTitle: title, message: note }),
      });
      const j = (await res.json().catch(() => ({}))) as { message?: string };
      if (!res.ok) {
        setReportState("error");
        setReportMsg(j.message ?? "Could not send your report.");
        return;
      }
      setReportState("sent");
      setNote("");
    } catch {
      setReportState("error");
      setReportMsg("Network error. Please try again.");
    }
  }

  const pct = score ? Math.min(100, Math.round((100 * score.answered) / Math.max(1, score.total))) : 0;

  return (
    <div ref={boxRef} className="flex flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-line bg-lavender px-4 py-3">
        <h2 className="min-w-0 flex-1 truncate text-base font-extrabold text-ink">{title}</h2>
        {verified && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-success/10 px-3 py-1 text-xs font-bold text-success">
            <ShieldCheck className="h-4 w-4" aria-hidden /> Verified {verified.verified} of {verified.total} questions
          </span>
        )}
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1 text-xs font-bold text-indigo ring-1 ring-line">
          <Trophy className="h-4 w-4" aria-hidden /> {score?.points ?? 0} pts
        </span>
      </div>
      <div className="flex items-center gap-3 px-4 py-2">
        <div
          className="h-2 flex-1 overflow-hidden rounded-full bg-line"
          role="progressbar"
          aria-label="Game progress"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={pct}
        >
          <div className="h-full rounded-full bg-gradient-to-r from-indigo to-violet transition-all" style={{ width: pct + "%" }} />
        </div>
        <span className="w-24 text-right text-xs font-semibold text-muted">
          {score ? score.answered + " / " + score.total : "Starting\u2026"}
        </span>
        <Button size="sm" variant="outline" onClick={restart} aria-label="Restart game">
          <RotateCcw className="h-4 w-4" /> Restart
        </Button>
        <Button size="sm" variant="outline" onClick={fullscreen} aria-label="Toggle fullscreen">
          <Maximize2 className="h-4 w-4" /> <span className="hidden sm:inline">Fullscreen</span>
        </Button>
        <Button size="sm" variant="ghostLight" onClick={() => { setReportState("idle"); setReportOpen(true); }} aria-label="Report a problem with this game">
          <Flag className="h-4 w-4" /> <span className="hidden sm:inline">Report</span>
        </Button>
      </div>
      {doc.error ? (
        <p role="alert" className="p-8 text-center font-semibold text-red-600">{doc.error}</p>
      ) : (
        <iframe
          key={useFallback ? "fallback" : "primary"}
          ref={frameRef}
          title={title + " (game)"}
          srcDoc={doc.html}
          sandbox="allow-scripts"
          referrerPolicy="no-referrer"
          className="h-[68vh] min-h-[480px] w-full flex-1 border-0 bg-navy"
        />
      )}
      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="max-w-md">
          <DialogTitle className="text-lg font-extrabold">Report a problem</DialogTitle>
          <DialogDescription className="mt-1 text-sm text-muted">
            Wrong answer, broken round or unclear question? Tell us what happened in &ldquo;{title}&rdquo;.
          </DialogDescription>
          {reportState === "sent" ? (
            <p className="mt-4 rounded-card bg-success/10 p-3 text-sm font-semibold text-success">Thanks - your report was sent.</p>
          ) : (
            <>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                maxLength={1000}
                rows={4}
                aria-label="What went wrong?"
                className="mt-4 w-full rounded-card border border-line p-3 text-sm focus:border-indigo focus:outline-none"
                placeholder="Describe the problem"
              />
              {reportState === "error" && <p role="alert" className="mt-2 text-sm text-red-600">{reportMsg}</p>}
              <Button className="mt-3" onClick={sendReport} disabled={note.trim().length < 3 || reportState === "sending"}>
                {reportState === "sending" ? "Sending\u2026" : "Send report"}
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>
      <span className="sr-only" aria-live="polite">{done ? "Game complete" : ""}</span>
    </div>
  );
}
