import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-bold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-60 cursor-pointer",
  {
    variants: {
      variant: {
        primary: "bg-indigo text-white shadow-[0_8px_24px_rgba(91,91,245,0.35)] hover:bg-indigo-600 hover:-translate-y-px",
        outline: "border border-indigo/40 bg-white text-indigo hover:bg-lavender",
        ghost: "text-current hover:bg-white/10",
        ghostLight: "text-ink hover:bg-lavender",
        dark: "border border-white/25 bg-white/5 text-white hover:bg-white/10",
        success: "bg-success text-white hover:brightness-95",
      },
      size: { sm: "h-9 px-4", md: "h-11 px-6", lg: "h-12 px-7 text-base", icon: "h-10 w-10" },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, asChild, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";
  return <Comp ref={ref} className={cn(buttonVariants({ variant, size }), className)} {...props} />;
});
Button.displayName = "Button";

export { buttonVariants };
