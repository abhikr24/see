import type { GameType } from "@/lib/plans";

export interface ExampleMeta {
  slug: string;
  pdfName: string;
  gameName: string;
  type: GameType;
  blurb: string;
  from: string;
  to: string;
}

/** Light metadata used by the landing page. Full game data lives in examples.ts (server only). */
export const EXAMPLE_META: ExampleMeta[] = [
  {
    slug: "history-quest",
    pdfName: "History Notes",
    gameName: "History Quest",
    type: "fill_gap",
    blurb: "Fill the Gap on the rise and fall of Rome.",
    from: "#7c3aed",
    to: "#f97316",
  },
  {
    slug: "science-challenge",
    pdfName: "Science Textbook",
    gameName: "Science Challenge",
    type: "boss_battle",
    blurb: "Boss Battle across the solar system.",
    from: "#0ea5c6",
    to: "#5B5BF5",
  },
  {
    slug: "business-simulator",
    pdfName: "Corporate Training",
    gameName: "Business Simulator",
    type: "order_steps",
    blurb: "Order the Steps of real workplace processes.",
    from: "#22B573",
    to: "#0ea5c6",
  },
  {
    slug: "language-quest",
    pdfName: "Language Guide",
    gameName: "Language Quest",
    type: "match_pairs",
    blurb: "Match French words with their meanings.",
    from: "#f43f5e",
    to: "#8B7CF8",
  },
];

export const DEMO_SLUG = "cell-biology";
