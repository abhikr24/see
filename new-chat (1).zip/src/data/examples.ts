import "server-only";
import type { GamePlan, Round } from "@/lib/ai/schema";
import type { PageExtract } from "@/lib/pdf/types";
import { buildStandardHtml } from "@/lib/game/engine";
import { verifyRounds } from "@/lib/verify";
import type { GameType } from "@/lib/plans";

interface ExampleSource {
  slug: string;
  title: string;
  subject: string;
  theme: GamePlan["theme"];
  type: GameType;
  pages: string[];
  rounds: Round[];
}

type Kind = Round["kind"];

function r(
  id: string,
  kind: Kind,
  prompt: string,
  options: string[],
  answer: string | string[],
  explanation: string,
  page: number,
  quote: string,
): Round {
  return { id, kind, prompt, options, answer, explanation, difficulty: "medium", source: { page, quote } };
}

const cell: ExampleSource = {
  slug: "cell-biology",
  title: "Cell Biology Challenge",
  subject: "Cell Biology",
  theme: "cosmic",
  type: "quiz_rush",
  pages: [
    "Cell Biology Study Notes. The cell is the basic structural and functional unit of all living organisms. Cells were first observed by Robert Hooke in 1665 when he examined thin slices of cork under a microscope. All cells come from pre-existing cells, and every living organism is made of one or more cells.",
    "The nucleus stores the cell's DNA and controls gene expression. Mitochondria are known as the powerhouse of the cell because they produce most of the cell's ATP through cellular respiration. Ribosomes assemble proteins by reading messenger RNA. The endoplasmic reticulum folds and transports proteins and lipids throughout the cell.",
    "Plant cells have a rigid cell wall made of cellulose and chloroplasts that carry out photosynthesis. Animal cells lack both a cell wall and chloroplasts. The large central vacuole in plant cells stores water and helps maintain turgor pressure.",
  ],
  rounds: [
    r("r1", "mcq", "Who first observed cells in 1665?", ["Robert Hooke", "Louis Pasteur", "Charles Darwin", "Gregor Mendel"], "Robert Hooke", "Hooke observed cork cells in 1665.", 1, "Cells were first observed by Robert Hooke in 1665 when he examined thin slices of cork under a microscope."),
    r("r2", "mcq", "What material did Hooke examine under his microscope?", ["Cork", "Onion skin", "Blood", "Pond water"], "Cork", "He looked at thin slices of cork.", 1, "Cells were first observed by Robert Hooke in 1665 when he examined thin slices of cork under a microscope."),
    r("r3", "mcq", "According to the notes, where do all cells come from?", ["Pre-existing cells", "Spontaneous generation", "Non-living matter", "Viruses"], "Pre-existing cells", "Every cell arises from an earlier cell.", 1, "All cells come from pre-existing cells, and every living organism is made of one or more cells."),
    r("r4", "mcq", "What is the powerhouse of the cell?", ["Nucleus", "Mitochondria", "Ribosome", "Endoplasmic Reticulum"], "Mitochondria", "Mitochondria produce most of the cell's ATP.", 2, "Mitochondria are known as the powerhouse of the cell because they produce most of the cell's ATP through cellular respiration."),
    r("r5", "mcq", "Which organelle stores the cell's DNA?", ["Nucleus", "Ribosome", "Vacuole", "Mitochondria"], "Nucleus", "The nucleus also controls gene expression.", 2, "The nucleus stores the cell's DNA and controls gene expression."),
    r("r6", "mcq", "What do ribosomes do?", ["Assemble proteins", "Produce ATP", "Store water", "Carry out photosynthesis"], "Assemble proteins", "They read messenger RNA to build proteins.", 2, "Ribosomes assemble proteins by reading messenger RNA. The endoplasmic reticulum folds and transports proteins and lipids throughout the cell."),
    r("r7", "mcq", "Which structure do plant cells have that animal cells lack?", ["A cellulose cell wall", "A nucleus", "Mitochondria", "Ribosomes"], "A cellulose cell wall", "Plant cells also have chloroplasts.", 3, "Plant cells have a rigid cell wall made of cellulose and chloroplasts that carry out photosynthesis."),
    r("r8", "mcq", "What does the large central vacuole of a plant cell do?", ["Stores water and maintains turgor pressure", "Makes ATP", "Stores DNA", "Assembles proteins"], "Stores water and maintains turgor pressure", "The vacuole keeps the cell firm.", 3, "The large central vacuole in plant cells stores water and helps maintain turgor pressure."),
  ],
};

const history: ExampleSource = {
  slug: "history-quest",
  title: "History Quest: Rome",
  subject: "Ancient Rome",
  theme: "sunset",
  type: "fill_gap",
  pages: [
    "Rome was founded, according to tradition, in 753 BC by Romulus. For about 244 years it was ruled by kings. In 509 BC the Romans expelled their last king and established a republic governed by elected officials called consuls.",
    "Julius Caesar crossed the Rubicon river in 49 BC, starting a civil war. He was declared dictator for life and was assassinated on the Ides of March in 44 BC by a group of senators.",
    "Augustus became the first Roman emperor in 27 BC after defeating Mark Antony and Cleopatra. His reign began the Pax Romana, a long period of relative peace and stability across the empire.",
    "The Western Roman Empire fell in 476 AD when the Germanic leader Odoacer deposed the emperor Romulus Augustulus. The Eastern Roman Empire, known as the Byzantine Empire, survived until 1453 AD.",
  ],
  rounds: [
    r("r1", "cloze", "According to tradition, Rome was founded in ____ BC by Romulus.", ["753", "509", "44", "27"], "753", "Rome's traditional founding date.", 1, "Rome was founded, according to tradition, in 753 BC by Romulus. For about 244 years it was ruled by kings."),
    r("r2", "cloze", "In 509 BC the Romans expelled their last king and set up a ____.", ["republic", "empire", "dictatorship", "theocracy"], "republic", "The Republic replaced the monarchy.", 1, "In 509 BC the Romans expelled their last king and established a republic governed by elected officials called consuls."),
    r("r3", "cloze", "The Roman Republic was governed by elected officials called ____.", ["consuls", "pharaohs", "satraps", "emperors"], "consuls", "Consuls were elected officials.", 1, "In 509 BC the Romans expelled their last king and established a republic governed by elected officials called consuls."),
    r("r4", "cloze", "Julius Caesar crossed the ____ river in 49 BC, starting a civil war.", ["Rubicon", "Tiber", "Danube", "Rhine"], "Rubicon", "Crossing it started the civil war.", 2, "Julius Caesar crossed the Rubicon river in 49 BC, starting a civil war."),
    r("r5", "cloze", "Caesar was assassinated on the Ides of March in ____ BC.", ["44", "49", "27", "753"], "44", "A group of senators carried it out.", 2, "He was declared dictator for life and was assassinated on the Ides of March in 44 BC by a group of senators."),
    r("r6", "cloze", "____ became the first Roman emperor in 27 BC.", ["Augustus", "Nero", "Trajan", "Caesar"], "Augustus", "He defeated Mark Antony and Cleopatra first.", 3, "Augustus became the first Roman emperor in 27 BC after defeating Mark Antony and Cleopatra."),
    r("r7", "cloze", "Augustus's reign began the ____, a long period of relative peace.", ["Pax Romana", "Dark Ages", "Renaissance", "Punic Wars"], "Pax Romana", "Peace and stability across the empire.", 3, "His reign began the Pax Romana, a long period of relative peace and stability across the empire."),
    r("r8", "cloze", "The Western Roman Empire fell in ____ AD.", ["476", "1453", "27", "410"], "476", "Odoacer deposed Romulus Augustulus.", 4, "The Western Roman Empire fell in 476 AD when the Germanic leader Odoacer deposed the emperor Romulus Augustulus."),
    r("r9", "cloze", "The Eastern Roman Empire is known as the ____ Empire.", ["Byzantine", "Ottoman", "Persian", "Carolingian"], "Byzantine", "It survived until 1453 AD.", 4, "The Eastern Roman Empire, known as the Byzantine Empire, survived until 1453 AD."),
  ],
};

const science: ExampleSource = {
  slug: "science-challenge",
  title: "Science Challenge: The Solar System",
  subject: "Astronomy",
  theme: "ocean",
  type: "boss_battle",
  pages: [
    "The Sun is a star at the center of our solar system and contains about 99.8 percent of the system's total mass. Its surface temperature is roughly 5,500 degrees Celsius. Sunlight takes about eight minutes to reach Earth.",
    "Mercury is the smallest planet and the closest to the Sun. Venus is the hottest planet because its thick carbon dioxide atmosphere traps heat. Earth is the only known planet that supports life.",
    "Mars is called the Red Planet because iron oxide, or rust, covers its surface. Jupiter is the largest planet and has a storm called the Great Red Spot that has lasted for centuries.",
    "Saturn is famous for its rings, which are made mostly of ice particles. Neptune is the farthest planet from the Sun and has the strongest winds in the solar system. Pluto was reclassified as a dwarf planet in 2006.",
  ],
  rounds: [
    r("r1", "mcq", "Roughly how much of the solar system's mass is in the Sun?", ["99.8 percent", "75 percent", "50 percent", "10 percent"], "99.8 percent", "The Sun dominates the system's mass.", 1, "The Sun is a star at the center of our solar system and contains about 99.8 percent of the system's total mass."),
    r("r2", "mcq", "About how long does sunlight take to reach Earth?", ["Eight minutes", "Eight seconds", "Eight hours", "One day"], "Eight minutes", "Light crosses the gap in about eight minutes.", 1, "Its surface temperature is roughly 5,500 degrees Celsius. Sunlight takes about eight minutes to reach Earth."),
    r("r3", "mcq", "What is the Sun's approximate surface temperature?", ["5,500 degrees Celsius", "500 degrees Celsius", "55,000 degrees Celsius", "100 degrees Celsius"], "5,500 degrees Celsius", "That is the surface, not the core.", 1, "Its surface temperature is roughly 5,500 degrees Celsius. Sunlight takes about eight minutes to reach Earth."),
    r("r4", "mcq", "Which planet is the smallest and closest to the Sun?", ["Mercury", "Venus", "Mars", "Earth"], "Mercury", "Mercury is both smallest and innermost.", 2, "Mercury is the smallest planet and the closest to the Sun."),
    r("r5", "mcq", "Why is Venus the hottest planet?", ["Its thick carbon dioxide atmosphere traps heat", "It is closest to the Sun", "It has no atmosphere", "It is covered in volcanoes only"], "Its thick carbon dioxide atmosphere traps heat", "A runaway greenhouse effect.", 2, "Venus is the hottest planet because its thick carbon dioxide atmosphere traps heat."),
    r("r6", "mcq", "Which is the only known planet that supports life?", ["Earth", "Mars", "Venus", "Jupiter"], "Earth", "No other planet is known to support life.", 2, "Earth is the only known planet that supports life."),
    r("r7", "mcq", "Why is Mars called the Red Planet?", ["Iron oxide covers its surface", "It is closest to the Sun", "Its oceans are red", "It has red clouds"], "Iron oxide covers its surface", "Iron oxide is rust.", 3, "Mars is called the Red Planet because iron oxide, or rust, covers its surface."),
    r("r8", "mcq", "Which planet is the largest?", ["Jupiter", "Saturn", "Neptune", "Earth"], "Jupiter", "Jupiter is also home to the Great Red Spot.", 3, "Jupiter is the largest planet and has a storm called the Great Red Spot that has lasted for centuries."),
    r("r9", "mcq", "What is Jupiter's Great Red Spot?", ["A storm that has lasted for centuries", "A volcano", "A moon", "An impact crater"], "A storm that has lasted for centuries", "It is a long-lived storm.", 3, "Jupiter is the largest planet and has a storm called the Great Red Spot that has lasted for centuries."),
    r("r10", "mcq", "What are Saturn's rings made of mostly?", ["Ice particles", "Solid rock", "Liquid water", "Gas clouds"], "Ice particles", "Mostly ice particles.", 4, "Saturn is famous for its rings, which are made mostly of ice particles."),
    r("r11", "mcq", "Which planet is the farthest from the Sun?", ["Neptune", "Saturn", "Uranus", "Mars"], "Neptune", "It also has the strongest winds.", 4, "Neptune is the farthest planet from the Sun and has the strongest winds in the solar system."),
    r("r12", "mcq", "When was Pluto reclassified as a dwarf planet?", ["2006", "1930", "1990", "2015"], "2006", "Pluto became a dwarf planet in 2006.", 4, "Pluto was reclassified as a dwarf planet in 2006."),
  ],
};

const business: ExampleSource = {
  slug: "business-simulator",
  title: "Business Simulator: Workplace Processes",
  subject: "Corporate Training",
  theme: "forest",
  type: "order_steps",
  pages: [
    "Handling a customer complaint follows five steps. First, listen to the customer without interrupting. Second, apologize and acknowledge the problem. Third, ask questions to understand the details. Fourth, offer a solution and agree on a timeline. Finally, follow up to confirm the customer is satisfied.",
    "A security incident response plan has four phases. Detect and report the incident immediately. Contain the threat by isolating affected systems. Eradicate the cause and restore normal operations. Finally, review what happened and update the procedures.",
    "New employee onboarding runs in order. Before day one, send the welcome email and prepare equipment. On day one, hold the orientation and introduce the team. During the first month, assign a mentor and set goals. At the ninety day mark, hold a formal performance review.",
    "Product launches follow a fixed sequence. Research the market and define the target audience. Build a prototype and test it with real users. Prepare marketing materials and train the sales team. Finally, launch publicly and measure results.",
  ],
  rounds: [
    r("r1", "order", "Put the steps of handling a customer complaint in order.", [], ["Listen without interrupting", "Apologize and acknowledge the problem", "Ask questions to understand the details", "Offer a solution and agree on a timeline", "Follow up to confirm satisfaction"], "Listening always comes first.", 1, "Handling a customer complaint follows five steps. First, listen to the customer without interrupting. Second, apologize and acknowledge the problem."),
    r("r2", "order", "Put the phases of a security incident response in order.", [], ["Detect and report the incident", "Contain the threat by isolating systems", "Eradicate the cause and restore operations", "Review and update the procedures"], "Contain before you eradicate.", 2, "A security incident response plan has four phases. Detect and report the incident immediately. Contain the threat by isolating affected systems."),
    r("r3", "order", "Put the stages of new employee onboarding in order.", [], ["Send welcome email and prepare equipment", "Hold orientation and introduce the team", "Assign a mentor and set goals", "Hold the ninety day performance review"], "Preparation starts before day one.", 3, "Before day one, send the welcome email and prepare equipment. On day one, hold the orientation and introduce the team."),
    r("r4", "order", "Put the stages of a product launch in order.", [], ["Research the market and define the audience", "Build a prototype and test it with users", "Prepare marketing and train sales", "Launch publicly and measure results"], "Test with users before marketing.", 4, "Product launches follow a fixed sequence. Research the market and define the target audience. Build a prototype and test it with real users."),
  ],
};

const language: ExampleSource = {
  slug: "language-quest",
  title: "Language Quest: French Basics",
  subject: "French vocabulary",
  theme: "royal",
  type: "match_pairs",
  pages: [
    "In French, Bonjour means hello and is used during the day. Bonsoir means good evening. Au revoir means goodbye. Merci means thank you, and s'il vous plait means please.",
    "The word chat means cat and chien means dog. Maison means house, and livre means book. Pain means bread, and eau means water.",
    "To say how are you, ask Comment allez-vous? A common reply is Je vais bien, which means I am well. Excusez-moi means excuse me.",
  ],
  rounds: [
    r("r1", "pair", "Bonjour", [], "Hello (daytime greeting)", "Used during the day.", 1, "In French, Bonjour means hello and is used during the day."),
    r("r2", "pair", "Bonsoir", [], "Good evening", "An evening greeting.", 1, "Bonsoir means good evening. Au revoir means goodbye. Merci means thank you, and s'il vous plait means please."),
    r("r3", "pair", "Au revoir", [], "Goodbye", "Said when leaving.", 1, "Bonsoir means good evening. Au revoir means goodbye. Merci means thank you, and s'il vous plait means please."),
    r("r4", "pair", "Merci", [], "Thank you", "Polite gratitude.", 1, "Bonsoir means good evening. Au revoir means goodbye. Merci means thank you, and s'il vous plait means please."),
    r("r5", "pair", "Chat", [], "Cat", "Not the English word for talking.", 2, "The word chat means cat and chien means dog. Maison means house, and livre means book."),
    r("r6", "pair", "Chien", [], "Dog", "A common pet.", 2, "The word chat means cat and chien means dog. Maison means house, and livre means book."),
    r("r7", "pair", "Maison", [], "House", "Where you live.", 2, "Maison means house, and livre means book. Pain means bread, and eau means water."),
    r("r8", "pair", "Livre", [], "Book", "Something you read.", 2, "Maison means house, and livre means book. Pain means bread, and eau means water."),
    r("r9", "pair", "Pain", [], "Bread", "Found in a boulangerie.", 2, "Maison means house, and livre means book. Pain means bread, and eau means water."),
    r("r10", "pair", "Excusez-moi", [], "Excuse me", "A polite way to get attention.", 3, "A common reply is Je vais bien, which means I am well. Excusez-moi means excuse me."),
  ],
};

const SOURCES: ExampleSource[] = [cell, history, science, business, language];

export interface BuiltExample {
  slug: string;
  plan: GamePlan;
  html: string;
  verified: { verified: number; total: number };
  pageCount: number;
}

function toPages(texts: string[]): PageExtract[] {
  return texts.map((text, i) => ({
    page: i + 1,
    text,
    chars: text.length,
    headings: [],
    lists: [],
    captions: [],
    footnotes: [],
    needsOCR: false,
  }));
}

const cache = new Map<string, BuiltExample>();

export function getExample(slug: string): BuiltExample | null {
  const hit = cache.get(slug);
  if (hit) return hit;
  const src = SOURCES.find((s) => s.slug === slug);
  if (!src) return null;
  const pages = toPages(src.pages);
  const { kept } = verifyRounds(src.rounds, pages);
  const pagesUsed = [...new Set(kept.map((k) => k.source.page))].sort((a, b) => a - b);
  const plan: GamePlan = {
    title: src.title,
    subject: src.subject,
    theme: src.theme,
    difficulty: "medium",
    game_type: src.type,
    pages_used: pagesUsed,
    coverage: pages.map((p) => ({
      page: p.page,
      rounds: kept.filter((k) => k.source.page === p.page).length,
      non_content: false,
      reason: "",
    })),
    rounds: kept,
    key_terms: [],
  };
  const built: BuiltExample = {
    slug,
    plan,
    html: buildStandardHtml(plan, { watermark: false }),
    verified: { verified: kept.length, total: src.rounds.length },
    pageCount: pages.length,
  };
  cache.set(slug, built);
  return built;
}

export const EXAMPLE_SLUGS = SOURCES.map((s) => s.slug);
