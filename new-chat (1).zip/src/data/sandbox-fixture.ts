/**
 * Hostile fixture used by /sandbox-test to PROVE the sandbox works: this "game" tries to call fetch(),
 * read parent.document, navigate the top window and touch storage. In a correctly sandboxed iframe
 * every attempt fails silently (caught), and the page reports "blocked" for each.
 */
export const SANDBOX_FIXTURE_HTML = `<!doctype html><html><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:">
<style>body{font-family:system-ui,sans-serif;background:#0A0E27;color:#fff;padding:24px}li{margin:8px 0;font-size:16px}.ok{color:#4ade80}.bad{color:#f87171;font-weight:700}</style></head>
<body><h2>Sandbox self-test</h2><ul id="out"></ul>
<script>
(function(){
var out=document.getElementById('out');
function line(name,leaked){var li=document.createElement('li');li.className=leaked?'bad':'ok';li.textContent=name+': '+(leaked?'LEAKED':'blocked');out.appendChild(li);}
function attempt(name,fn){try{var r=fn();if(r&&typeof r.then==='function'){r.then(function(){line(name,true);},function(){line(name,false);});}else{line(name,r===true);}}catch(e){line(name,false);}}
attempt('fetch("/api/health")',function(){return fetch('/api/health');});
attempt('parent.document',function(){return !!parent.document.body;});
attempt('top.location change',function(){top.location.href='https://example.com/';return false;});
attempt('localStorage',function(){return !!window.localStorage.getItem('pdf2play:games:v1');});
attempt('document.cookie',function(){return document.cookie.length>0;});
try{parent.postMessage({type:'ready'},'*');}catch(e){}
})();
</script></body></html>`;
