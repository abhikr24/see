import "server-only";
import { costPaise } from "@/lib/cost";

export class AiUnavailableError extends Error {}
export class BudgetError extends Error {}

/** Tracks tokens and enforces a per-run spend ceiling (integer paise). */
export class Meter {
  tokensIn = 0;
  tokensOut = 0;
  constructor(public readonly maxPaise: number) {}
  add(i: number, o: number): void {
    this.tokensIn += i;
    this.tokensOut += o;
    if (this.cost() > this.maxPaise) throw new BudgetError("This document needs more AI budget than your plan allows per game.");
  }
  cost(): number {
    return costPaise(this.tokensIn, this.tokensOut);
  }
}

interface ChatOptions {
  system: string;
  user: string;
  maxTokens: number;
  json?: boolean;
  temperature?: number;
}

interface DeepSeekResponse {
  choices?: { message?: { content?: string } }[];
  usage?: { prompt_tokens?: number; completion_tokens?: number };
}

export function aiConfigured(): boolean {
  return Boolean(process.env.DEEPSEEK_API_KEY);
}

export async function chat(opts: ChatOptions, meter: Meter): Promise<string> {
  const key = process.env.DEEPSEEK_API_KEY;
  if (!key) throw new AiUnavailableError("AI generation is not configured on this server.");
  const base = (process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com").replace(/\/$/, "");
  let lastError = "unknown error";
  for (let attempt = 0; attempt < 2; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 150_000);
    try {
      const res = await fetch(base + "/chat/completions", {
        method: "POST",
        signal: ctrl.signal,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + key },
        body: JSON.stringify({
          model: "deepseek-chat",
          temperature: opts.temperature ?? 0.2,
          max_tokens: opts.maxTokens,
          ...(opts.json ? { response_format: { type: "json_object" } } : {}),
          messages: [
            { role: "system", content: opts.system },
            { role: "user", content: opts.user },
          ],
        }),
      });
      if (res.status === 429 || res.status >= 500) {
        lastError = "model service returned " + res.status;
        await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
        continue;
      }
      if (!res.ok) throw new AiUnavailableError("Model service rejected the request (" + res.status + ").");
      const data = (await res.json()) as DeepSeekResponse;
      meter.add(data.usage?.prompt_tokens ?? 0, data.usage?.completion_tokens ?? 0);
      const content = data.choices?.[0]?.message?.content;
      if (!content) throw new AiUnavailableError("Model returned an empty response.");
      return content;
    } catch (e) {
      if (e instanceof AiUnavailableError || e instanceof BudgetError) throw e;
      lastError = e instanceof Error ? e.message : "request failed";
    } finally {
      clearTimeout(timer);
    }
  }
  throw new AiUnavailableError("The AI service is unavailable right now (" + lastError + "). Please try again.");
}

export function parseJsonLoose(text: string): unknown {
  const cleaned = text.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end < start) throw new Error("no JSON object found");
  return JSON.parse(cleaned.slice(start, end + 1));
}
