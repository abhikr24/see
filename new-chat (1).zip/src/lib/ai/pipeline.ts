import "server-only";
import { z } from "zod";
import { briefToText, buildBrief } from "@/lib/brief";
import { estimateTokens } from "@/lib/cost";
import { BudgetError, chat, parseJsonLoose, type Meter } from "@/lib/ai/deepseek";
import {
  CoverageSchema,
  GamePlanSchema,
  KIND_FOR_TYPE,
  RoundSchema,
  type Coverage,
  type Difficulty,
  type GamePlan,
  type GenerationResult,
  type Round,
} from "@/lib/ai/schema";
import { assembleDocument, validateGameScript } from "@/lib/game/shell";
import { ENGINE_SCRIPT } from "@/lib/game/engine";
import { CONTENT_PAGE_CHARS, type DocumentBrief, type PageExtract } from "@/lib/pdf/types";
import { GAME_TYPE_INFO, MAX_HTML_BYTES, type GameType } from "@/lib/plans";
import { clampQuote, quoteScores, verifyRounds } from "@/lib/verify";

export class PipelineError extends Error {
  constructor(
    public readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

export type Emit = (stage: string, message: string, pct: number) => void;

export interface PipelineParams {
  pages: PageExtract[];
  gameType: GameType;
  difficulty: Difficulty;
  watermark: boolean;
  meter: Meter;
  emit: Emit;
}

export type PipelineResult = Omit<GenerationResult, "gameId" | "hash" | "cached">;

const TOKEN_BUDGET = 22000;
const PAGE_CHAR_CAP = 7000;

const KIND_RULES: Record<GameType, string> = {
  quiz_rush: 'kind "mcq": exactly 4 options; "answer" is the exact text of one option; distractors must be plausible.',
  boss_battle: 'kind "mcq": exactly 4 options; "answer" is the exact text of one option; distractors must be plausible.',
  flashcards: 'kind "flashcard": "prompt" is the front (a term or question), "answer" is the back (max 25 words), "options" is [].',
  fill_gap: 'kind "cloze": "prompt" is one sentence from the page with the key term replaced by "____"; "options" has 4 choices including "answer" (exact text); "answer" is the missing term.',
  match_pairs: 'kind "pair": "prompt" is a term, "answer" is its definition (max 18 words), "options" is [].',
  order_steps: 'kind "order": "prompt" tells the player what to order; "answer" is an array of 3-6 short steps in the CORRECT order; "options" is []. If a page has no process, order its main ideas as presented or its events chronologically.',
};

const SYSTEM_A = [
  "You are a learning-game designer. You convert document text into a strict JSON game plan.",
  "ABSOLUTE RULES:",
  "1. Use ONLY the supplied page text. Never invent facts, names, numbers or dates.",
  "2. Every round MUST carry source:{page,quote}. The quote is a VERBATIM, contiguous excerpt of 8 to 25 words copied exactly from that page's text. Do not paraphrase.",
  "3. Every page that contains educational content MUST get at least one round (two for dense pages). Only mark a page non_content:true (with a reason) if it is a cover, table of contents, blank, copyright, index or reference list.",
  "4. Output JSON ONLY. No markdown, no commentary.",
].join("\n");

function userA(gameType: GameType, difficulty: Difficulty, pages: PageExtract[], brief: DocumentBrief, note: string): string {
  const per = Math.max(2, Math.round(pages.length * 1.6));
  return [
    "GAME TYPE: " + gameType + " - " + GAME_TYPE_INFO[gameType].blurb,
    "ROUND RULES: " + KIND_RULES[gameType],
    "DIFFICULTY: " + difficulty,
    "PAGES TO COVER NOW: " + pages.map((p) => p.page).join(", ") + " (aim for about " + per + " rounds in total, never fewer than one per content page)",
    note ? "NOTE: " + note : "",
    "",
    "JSON SHAPE:",
    '{"title":"","subject":"","theme":"cosmic|ocean|forest|sunset|royal","difficulty":"easy|medium|hard","game_type":"' + gameType + '","pages_used":[1],"coverage":[{"page":1,"rounds":2,"non_content":false,"reason":""}],"rounds":[{"id":"r1","kind":"' + KIND_FOR_TYPE[gameType] + '","prompt":"","options":[],"answer":"","explanation":"max 20 words","difficulty":"medium","source":{"page":1,"quote":"8-25 verbatim words"}}],"key_terms":[""]}',
    "",
    "DOCUMENT BRIEF (context only):",
    briefToText(brief).slice(0, 9000),
    "",
    "PAGE TEXT:",
    ...pages.map((p) => "=== PAGE " + p.page + " ===\n" + p.text.slice(0, PAGE_CHAR_CAP)),
  ]
    .filter((l) => l !== "")
    .join("\n");
}

function normaliseRound(raw: unknown, gameType: GameType, allowed: Set<number>): Round | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const src = (o.source ?? {}) as Record<string, unknown>;
  const page = Number(src.page);
  if (!allowed.has(page)) return null;
  const parsed = RoundSchema.safeParse({
    ...o,
    kind: KIND_FOR_TYPE[gameType],
    options: Array.isArray(o.options) ? o.options.map(String) : [],
    explanation: typeof o.explanation === "string" ? o.explanation : "",
    source: { page, quote: clampQuote(String(src.quote ?? "")) },
  });
  return parsed.success ? parsed.data : null;
}

function normalisePlan(raw: unknown, gameType: GameType, difficulty: Difficulty, chunk: PageExtract[]): GamePlan {
  if (!raw || typeof raw !== "object") throw new Error("plan is not an object");
  const o = raw as Record<string, unknown>;
  const allowed = new Set(chunk.map((p) => p.page));
  const rounds = (Array.isArray(o.rounds) ? o.rounds : [])
    .map((r) => normaliseRound(r, gameType, allowed))
    .filter((r): r is Round => r !== null);
  const coverage = (Array.isArray(o.coverage) ? o.coverage : [])
    .map((c) => CoverageSchema.safeParse(c))
    .filter((c) => c.success)
    .map((c) => (c as { success: true; data: Coverage }).data)
    .filter((c) => allowed.has(c.page));
  const parsed = GamePlanSchema.parse({
    title: o.title,
    subject: o.subject,
    theme: o.theme,
    difficulty,
    game_type: gameType,
    pages_used: [],
    coverage,
    rounds,
    key_terms: Array.isArray(o.key_terms) ? o.key_terms.map(String).slice(0, 40) : [],
  });
  return parsed as GamePlan;
}

async function planChunk(
  chunk: PageExtract[],
  gameType: GameType,
  difficulty: Difficulty,
  brief: DocumentBrief,
  meter: Meter,
  note = "",
): Promise<GamePlan> {
  let feedback = "";
  let last = "invalid output";
  for (let attempt = 0; attempt < 2; attempt++) {
    const text = await chat(
      { system: SYSTEM_A, user: userA(gameType, difficulty, chunk, brief, note + feedback), maxTokens: 7000, json: true },
      meter,
    );
    try {
      return normalisePlan(parseJsonLoose(text), gameType, difficulty, chunk);
    } catch (e) {
      last = e instanceof z.ZodError ? e.issues.map((i) => i.path.join(".") + " " + i.message).join("; ").slice(0, 300) : e instanceof Error ? e.message : "invalid";
      feedback = " Your previous answer failed validation (" + last + "). Return valid JSON that follows the shape exactly.";
    }
  }
  throw new PipelineError("plan_invalid", "The AI returned an invalid game plan twice (" + last + ").");
}

function chunkPages(pages: PageExtract[], maxPages = 10, maxChars = 24000): PageExtract[][] {
  const out: PageExtract[][] = [];
  let cur: PageExtract[] = [];
  let chars = 0;
  for (const p of pages) {
    const c = Math.min(p.chars, PAGE_CHAR_CAP);
    if (cur.length && (cur.length >= maxPages || chars + c > maxChars)) {
      out.push(cur);
      cur = [];
      chars = 0;
    }
    cur.push(p);
    chars += c;
  }
  if (cur.length) out.push(cur);
  return out;
}

async function inParallel<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const i = next++;
      results[i] = await fn(items[i]);
    }
  });
  await Promise.all(workers);
  return results;
}

/** Map-reduce for documents over the token budget: summarise per page, then synthesise. No page is skipped. */
async function condense(
  pages: PageExtract[],
  brief: DocumentBrief,
  meter: Meter,
): Promise<{ pages: PageExtract[]; brief: DocumentBrief }> {
  const batches = chunkPages(pages, 6, 16000);
  const MAP_SYSTEM =
    'For each page return its summary and up to 5 key sentences copied VERBATIM from that page. JSON only: {"pages":[{"page":1,"summary":"max 30 words","key_sentences":["..."]}]}';
  const maps = await inParallel(batches, 3, async (batch) => {
    try {
      const text = await chat(
        {
          system: MAP_SYSTEM,
          user: batch.map((p) => "=== PAGE " + p.page + " ===\n" + p.text.slice(0, PAGE_CHAR_CAP)).join("\n"),
          maxTokens: 3000,
          json: true,
        },
        meter,
      );
      const parsed = z
        .object({ pages: z.array(z.object({ page: z.number(), summary: z.string(), key_sentences: z.array(z.string()).default([]) })) })
        .parse(parseJsonLoose(text));
      return parsed.pages;
    } catch (e) {
      if (e instanceof BudgetError) throw e;
      return [];
    }
  });
  const byPage = new Map(maps.flat().map((m) => [m.page, m]));
  const condensed = pages.map((p) => {
    const m = byPage.get(p.page);
    if (!m) return { ...p, text: p.text.slice(0, 1800) };
    const sentences = m.key_sentences.filter((s) => quoteScores(s, p.text).unigram >= 0.9);
    return { ...p, text: (m.summary + "\n" + sentences.join("\n")).slice(0, 2400) };
  });
  const summaries = condensed.map((p) => "p." + p.page + ": " + (byPage.get(p.page)?.summary ?? p.text.slice(0, 120)));
  let overview = "";
  let terms = brief.keyTerms;
  try {
    const text = await chat(
      {
        system: 'Synthesise a document overview from page summaries. JSON only: {"overview":"max 60 words","key_terms":["max 25 terms"]}',
        user: summaries.join("\n").slice(0, 12000),
        maxTokens: 800,
        json: true,
      },
      meter,
    );
    const r = z.object({ overview: z.string(), key_terms: z.array(z.string()).default([]) }).parse(parseJsonLoose(text));
    overview = r.overview;
    if (r.key_terms.length) terms = r.key_terms.slice(0, 25);
  } catch {
    overview = "";
  }
  return { pages: condensed, brief: { ...brief, overview, keyTerms: terms } };
}

const NON_CONTENT_HINT = /(references?|bibliograph|copyright|table of contents|contents|index|acknowledg|appendix|blank|cover|title page|isbn)/i;

function failingPages(pages: PageExtract[], rounds: Round[], coverage: Coverage[]): number[] {
  const have = new Set(rounds.map((r) => r.source.page));
  return pages
    .filter((p) => p.chars > CONTENT_PAGE_CHARS && !have.has(p.page))
    .filter((p) => {
      const c = coverage.find((x) => x.page === p.page);
      if (!c || !c.non_content) return true;
      const plausible = p.chars <= 500 || NON_CONTENT_HINT.test(c.reason) || NON_CONTENT_HINT.test(p.text.slice(0, 200));
      return !plausible;
    })
    .map((p) => p.page);
}

function merge(parts: GamePlan[]): GamePlan {
  const first = parts[0];
  const coverage = new Map<number, Coverage>();
  for (const p of parts) for (const c of p.coverage) coverage.set(c.page, c);
  return {
    ...first,
    coverage: [...coverage.values()],
    rounds: parts.flatMap((p) => p.rounds),
    key_terms: [...new Set(parts.flatMap((p) => p.key_terms))].slice(0, 30),
  };
}

function reId(rounds: Round[]): Round[] {
  return rounds.map((r, i) => ({ ...r, id: "r" + (i + 1) }));
}

const SYSTEM_B = [
  "You write the JavaScript for ONE self-contained browser game. Output ONLY raw JavaScript - no markdown fences, no HTML, no comments longer than one line.",
  "The page already contains <div id=\"app\"></div>, our CSS and a runtime object P2P:",
  "- P2P.rounds: array of rounds {id,kind,prompt,options,answer,explanation,difficulty,source:{page,quote}} (already verified; use them exactly, never invent content).",
  "- P2P.plan: {title,subject,game_type,...}. P2P.shuffle(array) returns a shuffled copy. P2P.chip(round) returns a DOM element reading 'Source: p.N' - append it to EVERY question/answer feedback.",
  "- P2P.ready() call once after the first screen is rendered. P2P.score({points,correct,answered,total}) after every answer. P2P.complete({points,correct,answered,total}) at the end. P2P.onRestart(fn) registers fn to restart the game from scratch.",
  "CSS classes available: .hud>.pill, .card, .center, .q (question), .h, .muted, .opts, .opt (+.correct/.wrong), .btn(.ghost), .tile(.sel/.correct/.wrong), .bar>i, .fb (feedback box), .chip, .stats>.stat, .flip with .face.f/.face.b, .cols, .blank, input.txt, ol.steps.",
  "Build all DOM with document.createElement and textContent (never innerHTML with data). Use ES5/ES2015 syntax. Keyboard accessible (real <button>s).",
  "FORBIDDEN: network access, fetch, XMLHttpRequest, eval, new Function, import(), parent/top access other than via P2P, storage APIs, external URLs, extra <script>/<link>/<iframe> tags.",
  "Show a final results card with a 'Play again' button that restarts. Correct answers turn green (.correct).",
].join("\n");

const SPEC_B: Record<GameType, string> = {
  quiz_rush: "Timed multiple choice: 20 second bar per question, score 100 + streak bonus (+20 per streak step, max 5) + time bonus, show streak count, feedback with explanation and chip, results at the end.",
  boss_battle: "Boss Battle: pick 10 rounds spread across different source pages, player has 3 lives (hearts), a boss HP bar drops on every correct answer, wrong answer loses a life; victory if lives remain and at least 60% correct.",
  flashcards: "Flip cards: tapping the card flips it (prompt front, answer + explanation + chip on the back); after flipping show 'Still learning' and 'I know this'; track known count.",
  fill_gap: "Cloze: show the prompt with the ____ blank, answer by choosing an option (or typing when no options); reveal the answer in the blank; feedback with explanation and chip.",
  match_pairs: "Two columns of tiles per board of up to 5 pairs (terms left, definitions shuffled right). Select a term then a definition; correct pairs turn green and show the chip, wrong flashes red. Multiple boards until all rounds are matched.",
  order_steps: "For each round show the shuffled steps; the player taps steps to build the order, can tap to undo, then presses 'Check order'; mark each position correct/wrong, reveal the right order with the explanation and chip.",
};

async function stageB(plan: GamePlan, meter: Meter): Promise<string | null> {
  const sample = plan.rounds.slice(0, 2);
  const user = [
    "GAME TYPE: " + plan.game_type + " (" + GAME_TYPE_INFO[plan.game_type as GameType].label + ")",
    "TITLE: " + plan.title,
    "ROUND COUNT: " + plan.rounds.length,
    "BEHAVIOUR: " + SPEC_B[plan.game_type as GameType],
    "SAMPLE ROUNDS (shape only): " + JSON.stringify(sample),
  ].join("\n");
  try {
    const text = await chat({ system: SYSTEM_B, user, maxTokens: 5000, temperature: 0.3 }, meter);
    const js = text.replace(/^\s*```(?:javascript|js)?\s*/i, "").replace(/```\s*$/i, "").trim();
    const check = validateGameScript(js);
    return check.ok ? js : null;
  } catch (e) {
    if (e instanceof BudgetError) throw e;
    return null;
  }
}

export async function runPipeline(params: PipelineParams): Promise<PipelineResult> {
  const { pages, gameType, difficulty, meter, emit } = params;
  const readable = pages.filter((p) => !p.needsOCR);
  const ocrPages = pages.filter((p) => p.needsOCR).map((p) => p.page);
  if (readable.length === 0) {
    throw new PipelineError("no_text", "No readable text was found. This PDF looks scanned (image-only); OCR is not available yet.");
  }
  const contentPages = readable.filter((p) => p.chars > CONTENT_PAGE_CHARS);

  emit("brief", "Building a document brief from " + readable.length + " pages...", 8);
  let brief = buildBrief(pages);
  let modelPages = readable;
  const totalTokens = estimateTokens(readable.map((p) => p.text.slice(0, PAGE_CHAR_CAP)).join(""));
  if (totalTokens > TOKEN_BUDGET) {
    emit("brief", "Long document: summarising every page first (map-reduce)...", 12);
    const c = await condense(readable, brief, meter);
    modelPages = c.pages;
    brief = c.brief;
  }

  // STAGE A - game plan
  emit("plan", "Designing your " + GAME_TYPE_INFO[gameType].label + " game...", 20);
  const chunks = chunkPages(modelPages);
  const parts = await inParallel(chunks, 3, (c) => planChunk(c, gameType, difficulty, brief, meter));
  let plan = merge(parts);

  // Anti-shortcut rule: max 2 repair rounds.
  let missing = failingPages(readable, plan.rounds, plan.coverage);
  for (let attempt = 1; attempt <= 2 && missing.length > 0; attempt++) {
    emit("repair", "Repair " + attempt + "/2: covering pages " + missing.join(", ") + "...", 40 + attempt * 5);
    const redo = modelPages.filter((p) => missing.includes(p.page));
    const fixes = await inParallel(chunkPages(redo), 3, (c) =>
      planChunk(c, gameType, difficulty, brief, meter, "REPAIR: these pages were skipped before. Every one of them MUST get at least 2 rounds."),
    ).catch(() => [] as GamePlan[]);
    if (fixes.length) {
      const extra = fixes.flatMap((f) => f.rounds);
      plan = { ...plan, rounds: [...plan.rounds, ...extra], coverage: [...plan.coverage.filter((c) => !missing.includes(c.page)), ...fixes.flatMap((f) => f.coverage)] };
    }
    missing = failingPages(readable, plan.rounds, plan.coverage);
  }

  // STAGE B - game script
  emit("build", "Building the interactive game...", 60);
  const script = await stageB({ ...plan, rounds: reId(plan.rounds) }, meter);

  // Verify quotes against extracted page text.
  emit("verify", "Verifying every question against your PDF...", 82);
  let outcome = verifyRounds(plan.rounds, readable);
  let verifiedRounds = outcome.kept;
  const total = plan.rounds.length;
  if (outcome.dropped.length / Math.max(1, total) > 0.2) {
    emit("verify", "Too many unverifiable questions - regenerating once...", 86);
    const redoPages = [...new Set(outcome.dropped.map((d) => d.page))];
    const redo = modelPages.filter((p) => redoPages.includes(p.page));
    const fixes = await inParallel(chunkPages(redo), 3, (c) =>
      planChunk(c, gameType, difficulty, brief, meter, "STRICT: quotes MUST be copied character-for-character from the page text. Do not paraphrase or shorten words."),
    ).catch(() => [] as GamePlan[]);
    const second = verifyRounds(fixes.flatMap((f) => f.rounds), readable);
    verifiedRounds = [...verifiedRounds, ...second.kept];
    outcome = { kept: verifiedRounds, dropped: [...outcome.dropped, ...second.dropped] };
  }
  if (verifiedRounds.length < 3) {
    throw new PipelineError("verification_failed", "Fewer than 3 questions could be verified against your PDF text. Try a document with more readable text.");
  }
  const finalRounds = reId(verifiedRounds);
  const have = new Set(finalRounds.map((r) => r.source.page));
  const failed = contentPages.filter((p) => !have.has(p.page)).map((p) => p.page);
  const nonContentFlags = new Map(plan.coverage.map((c) => [c.page, c]));
  const finalPlan: GamePlan = {
    ...plan,
    rounds: finalRounds,
    pages_used: [...have].sort((a, b) => a - b),
    coverage: readable.map((p) => {
      const flagged = nonContentFlags.get(p.page);
      const n = finalRounds.filter((r) => r.source.page === p.page).length;
      return { page: p.page, rounds: n, non_content: n === 0 && Boolean(flagged?.non_content), reason: flagged?.reason ?? "" };
    }),
  };

  emit("finish", "Packaging your game...", 95);
  let html = assembleDocument(finalPlan, script ?? ENGINE_SCRIPT, { watermark: params.watermark });
  let engine: "ai" | "standard" = script ? "ai" : "standard";
  if (new TextEncoder().encode(html).length > MAX_HTML_BYTES) {
    html = assembleDocument(finalPlan, ENGINE_SCRIPT, { watermark: params.watermark });
    engine = "standard";
  }
  return {
    plan: finalPlan,
    html,
    engine,
    watermark: params.watermark,
    verified: { verified: finalRounds.length, total },
    coverage: {
      contentPages: contentPages.length,
      coveredPages: contentPages.length - failed.length,
      failedPages: failed,
      ocrPages,
    },
  };
}
