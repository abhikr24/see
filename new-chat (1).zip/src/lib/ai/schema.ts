import { z } from "zod";
import { GAME_TYPES } from "@/lib/plans";

export const DIFFICULTIES = ["easy", "medium", "hard"] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

export const THEMES = ["cosmic", "ocean", "forest", "sunset", "royal"] as const;

export const ROUND_KINDS = ["mcq", "flashcard", "cloze", "pair", "order"] as const;
export type RoundKind = (typeof ROUND_KINDS)[number];

export const KIND_FOR_TYPE = {
  quiz_rush: "mcq",
  boss_battle: "mcq",
  flashcards: "flashcard",
  fill_gap: "cloze",
  match_pairs: "pair",
  order_steps: "order",
} as const;

export const RoundSchema = z
  .object({
    id: z.string().min(1).max(24),
    kind: z.enum(ROUND_KINDS),
    prompt: z.string().min(3).max(500),
    options: z.array(z.string().min(1).max(240)).max(8).default([]),
    answer: z.union([z.string().min(1).max(500), z.array(z.string().min(1).max(240)).min(3).max(8)]),
    explanation: z.string().max(500).default(""),
    difficulty: z.enum(DIFFICULTIES).catch("medium"),
    source: z.object({
      page: z.number().int().min(1).max(30),
      quote: z.string().min(10).max(600),
    }),
  })
  .superRefine((r, ctx) => {
    const fail = (message: string) => ctx.addIssue({ code: "custom", message });
    if (r.kind === "mcq") {
      if (r.options.length < 3) fail("mcq needs at least 3 options");
      if (typeof r.answer !== "string" || !r.options.includes(r.answer)) fail("mcq answer must equal one option");
    } else if (r.kind === "order") {
      if (!Array.isArray(r.answer)) fail("order answer must be an array of steps in order");
    } else if (typeof r.answer !== "string") {
      fail("answer must be a string");
    }
    if (r.kind === "cloze" && !/_{3,}/.test(r.prompt)) fail("cloze prompt needs a ____ blank");
    if (r.kind === "cloze" && r.options.length > 0 && typeof r.answer === "string" && !r.options.includes(r.answer)) {
      fail("cloze answer must be among options");
    }
  });
export type Round = z.infer<typeof RoundSchema>;

export const CoverageSchema = z.object({
  page: z.number().int().min(1).max(30),
  rounds: z.number().int().min(0).default(0),
  non_content: z.boolean().default(false),
  reason: z.string().max(300).default(""),
});
export type Coverage = z.infer<typeof CoverageSchema>;

export const GamePlanSchema = z.object({
  title: z.string().min(2).max(90),
  subject: z.string().min(2).max(90),
  theme: z.enum(THEMES).catch("cosmic"),
  difficulty: z.enum(DIFFICULTIES).catch("medium"),
  game_type: z.enum(GAME_TYPES as unknown as [string, ...string[]]),
  pages_used: z.array(z.number().int().min(1).max(30)).default([]),
  coverage: z.array(CoverageSchema).default([]),
  rounds: z.array(RoundSchema).min(1),
  key_terms: z.array(z.string().max(80)).max(40).default([]),
});
export type GamePlan = Omit<z.infer<typeof GamePlanSchema>, "game_type"> & {
  game_type: (typeof GAME_TYPES)[number];
};

/** Messages a game may post to the player. Anything else is ignored. */
export const GameMessageSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("ready") }),
  z.object({
    type: z.literal("score"),
    points: z.number().int().min(0).max(1_000_000),
    correct: z.number().int().min(0).max(500),
    answered: z.number().int().min(0).max(500),
    total: z.number().int().min(1).max(500),
  }),
  z.object({
    type: z.literal("complete"),
    points: z.number().int().min(0).max(1_000_000),
    correct: z.number().int().min(0).max(500),
    answered: z.number().int().min(0).max(500),
    total: z.number().int().min(1).max(500),
  }),
]);
export type GameMessage = z.infer<typeof GameMessageSchema>;

export interface GenerationResult {
  gameId: string;
  hash: string;
  plan: GamePlan;
  html: string;
  engine: "ai" | "standard";
  watermark: boolean;
  verified: { verified: number; total: number };
  coverage: { contentPages: number; coveredPages: number; failedPages: number[]; ocrPages: number[] };
  cached?: boolean;
}

export type StreamEvent =
  | { type: "progress"; stage: string; message: string; pct: number }
  | { type: "done"; result: GenerationResult }
  | { type: "error"; code: string; message: string };
