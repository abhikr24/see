import type { DocumentBrief, PageExtract } from "@/lib/pdf/types";

const STOP = new Set(
  "the and for that with this from have been were which their there about would could should these those into than then them they what when where while will your also such more most other some only over under between through during before after because being each very much many can may might must not are was has had its our out per via use used using one two three first second".split(
    " ",
  ),
);

function firstSentence(text: string, max = 160): string {
  const clean = text.replace(/\s+/g, " ").trim();
  const m = clean.match(/^(.{20,}?[.!?])(\s|$)/);
  const s = m ? m[1] : clean;
  return s.length > max ? s.slice(0, max - 1).trimEnd() + "\u2026" : s;
}

function extractFacts(text: string): string[] {
  const out = new Set<string>();
  const patterns = [
    /\b(?:1[0-9]{3}|20[0-9]{2})\b(?:\s?(?:BC|BCE|AD|CE))?/g,
    /\b\d[\d,.]*\s?(?:%|percent|km|kg|mg|ml|cm|mm|m|s|years?|days?|hours?|million|billion|thousand|degrees?|\u00B0C)\b/gi,
    /[A-Za-z][A-Za-z0-9_ ]{0,20}\s=\s[^.;\n]{1,40}/g,
  ];
  for (const re of patterns) {
    for (const m of text.matchAll(re)) {
      out.add(m[0].trim());
      if (out.size >= 6) return [...out];
    }
  }
  return [...out];
}

function extractTerms(pages: PageExtract[]): string[] {
  const score = new Map<string, number>();
  const bump = (t: string, w: number) => {
    const k = t.trim();
    if (k.length < 4 || k.length > 60) return;
    score.set(k, (score.get(k) ?? 0) + w);
  };
  for (const p of pages) {
    for (const h of p.headings) bump(h.replace(/[:.]$/, ""), 4);
    for (const m of p.text.matchAll(/\b([A-Z][\w-]+(?:\s[A-Za-z][\w-]+){0,2})\s(?:is|are|refers to|means|describes)\s/g)) {
      bump(m[1], 3);
    }
    const counts = new Map<string, number>();
    for (const w of p.text.toLowerCase().match(/[a-z][a-z-]{6,}/g) ?? []) {
      if (!STOP.has(w)) counts.set(w, (counts.get(w) ?? 0) + 1);
    }
    for (const [w, c] of counts) if (c >= 3) bump(w, c * 0.5);
  }
  return [...score.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 25)
    .map(([t]) => t);
}

/** Deterministic Document Brief covering EVERY page (no page is skipped). */
export function buildBrief(pages: PageExtract[]): DocumentBrief {
  const toc: DocumentBrief["toc"] = [];
  const facts: DocumentBrief["facts"] = [];
  const pageSummaries: DocumentBrief["pageSummaries"] = [];
  for (const p of pages) {
    for (const h of p.headings.slice(0, 3)) toc.push({ page: p.page, heading: h });
    const f = extractFacts(p.text);
    if (f.length) facts.push({ page: p.page, items: f });
    pageSummaries.push({
      page: p.page,
      summary: p.needsOCR ? "(no extractable text)" : firstSentence(p.text),
    });
  }
  return { toc, keyTerms: extractTerms(pages), facts, pageSummaries };
}

/** Compact text form of the brief for prompts. */
export function briefToText(b: DocumentBrief): string {
  const lines: string[] = [];
  if (b.overview) lines.push("OVERVIEW: " + b.overview);
  lines.push("TABLE OF CONTENTS:");
  for (const t of b.toc.slice(0, 60)) lines.push("  p." + t.page + " " + t.heading);
  lines.push("KEY TERMS: " + b.keyTerms.join("; "));
  lines.push("NUMBERS/DATES/FORMULAS:");
  for (const f of b.facts.slice(0, 40)) lines.push("  p." + f.page + ": " + f.items.join(" | "));
  lines.push("PAGE SUMMARIES:");
  for (const s of b.pageSummaries) lines.push("  p." + s.page + ": " + s.summary);
  return lines.join("\n");
}
