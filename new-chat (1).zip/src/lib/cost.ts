/**
 * Conservative DeepSeek cost model in integer paise.
 * INR 25 per 1M input tokens, INR 100 per 1M output tokens (rounded up from list price).
 */
const PAISE_PER_M_INPUT = 2500;
const PAISE_PER_M_OUTPUT = 10000;

export function costPaise(tokensIn: number, tokensOut: number): number {
  return Math.ceil((tokensIn * PAISE_PER_M_INPUT + tokensOut * PAISE_PER_M_OUTPUT) / 1_000_000);
}

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}
