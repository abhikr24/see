import "server-only";
import type { User } from "@supabase/supabase-js";
import { getAdminClient } from "@/lib/supabase/admin";
import { PLANS, isPaidPlan, type PlanId } from "@/lib/plans";

export interface Entitlement {
  userId: string;
  email: string;
  /** Plan the user is actually entitled to right now (own plan or classroom seat). */
  plan: PlanId;
  ownPlan: PlanId;
  seatOf: string | null;
  period: string;
  limit: number;
  used: number;
  remaining: number;
  expiresAt: string | null;
}

interface ProfileRow {
  id: string;
  email: string | null;
  plan: string;
  credits: number;
  period_start: string;
  plan_expires_at: string | null;
}

const DAY = 86_400_000;

/** Server-side source of truth for what a user may do. Handles expiry, free-period rollover and seats. */
export async function getEntitlement(user: User): Promise<Entitlement | null> {
  const admin = getAdminClient();
  if (!admin) return null;
  const email = (user.email ?? "").toLowerCase();

  let { data: profile } = await admin.from("profiles").select("*").eq("id", user.id).maybeSingle<ProfileRow>();
  if (!profile) {
    const ins = await admin.from("profiles").insert({ id: user.id, email, credits: PLANS.free.gamesPerMonth }).select("*").single<ProfileRow>();
    profile = ins.data;
  }
  if (!profile) return null;

  const now = Date.now();
  let ownPlan = (isPaidPlan(profile.plan) ? profile.plan : "free") as PlanId;
  if (ownPlan !== "free" && (!profile.plan_expires_at || new Date(profile.plan_expires_at).getTime() < now)) {
    const periodStart = new Date(now).toISOString();
    await admin.from("profiles").update({ plan: "free", plan_expires_at: null, period_start: periodStart, credits: PLANS.free.gamesPerMonth }).eq("id", user.id);
    await admin.from("subscriptions").update({ status: "expired" }).eq("user_id", user.id).eq("status", "active").lt("current_period_end", periodStart);
    profile = { ...profile, plan: "free", plan_expires_at: null, period_start: periodStart };
    ownPlan = "free";
  }

  let plan: PlanId = ownPlan;
  let seatOf: string | null = null;
  if (ownPlan === "free" && email) {
    const { data: seats } = await admin.from("classroom_members").select("owner_id").eq("member_email", email).limit(5);
    for (const s of seats ?? []) {
      const { data: owner } = await admin.from("profiles").select("plan, plan_expires_at").eq("id", s.owner_id).maybeSingle();
      if (owner?.plan === "classroom" && owner.plan_expires_at && new Date(owner.plan_expires_at).getTime() > now) {
        plan = "classroom";
        seatOf = s.owner_id as string;
        break;
      }
    }
  }

  if (plan === "free" && now - new Date(profile.period_start).getTime() >= 30 * DAY) {
    const periodStart = new Date(now).toISOString();
    await admin.from("profiles").update({ period_start: periodStart, credits: PLANS.free.gamesPerMonth }).eq("id", user.id);
    profile = { ...profile, period_start: periodStart };
  }

  const period = String(profile.period_start);
  const { data: counter } = await admin.from("usage_counters").select("conversions").eq("user_id", user.id).eq("period", period).maybeSingle();
  const used = counter?.conversions ?? 0;
  const limit = PLANS[plan].gamesPerMonth;
  return {
    userId: user.id,
    email,
    plan,
    ownPlan,
    seatOf,
    period,
    limit,
    used,
    remaining: Math.max(0, limit - used),
    expiresAt: profile.plan_expires_at,
  };
}

/** Sum of cost_paise since a timestamp for a user. */
export async function spendSince(userId: string, sinceIso: string): Promise<number> {
  const admin = getAdminClient();
  if (!admin) return 0;
  const { data } = await admin.from("generations").select("cost_paise").eq("user_id", userId).gte("created_at", sinceIso).limit(2000);
  return (data ?? []).reduce((n, r) => n + (r.cost_paise as number), 0);
}
