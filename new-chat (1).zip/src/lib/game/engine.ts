import type { GamePlan } from "@/lib/ai/schema";
import { assembleDocument } from "@/lib/game/shell";

/**
 * Built-in standard engine: a real, complete implementation of all six game types on top of the
 * P2P runtime. Used (a) when the model-written game fails static checks or never reports "ready",
 * and (b) for the pre-generated example games shipped in the repo.
 * Written as a plain string with ES5-style syntax so it runs in any sandboxed iframe.
 */
export const ENGINE_SCRIPT = String.raw`(function(){
var P=window.P2P,R=P.rounds,T=P.plan.game_type,app=document.getElementById('app');
var S,readySent=false;
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=x;return e;}
function clear(){if(S&&S.timer){clearInterval(S.timer);S.timer=null;}while(app.firstChild)app.removeChild(app.firstChild);}
function norm(s){return String(s).toLowerCase().replace(/[^a-z0-9\u00C0-\u024F\s]/g,' ').replace(/\s+/g,' ').trim();}
function reset(){S={i:0,points:0,correct:0,answered:0,streak:0,lives:3,queue:[],total:0,timer:null,board:0};}
function report(){P.score({points:S.points,correct:S.correct,answered:S.answered,total:S.total});}
function hud(items){var h=el('div','hud');items.forEach(function(t){h.appendChild(el('span','pill',t));});app.appendChild(h);}
function feedback(card,ok,r,extra){
 var f=el('div','fb');
 f.appendChild(el('strong',null,(ok?'Correct! ':'Not quite. ')+(extra||'')));
 if(r.explanation){f.appendChild(document.createElement('br'));f.appendChild(document.createTextNode(r.explanation));}
 f.appendChild(document.createElement('br'));f.appendChild(P.chip(r));
 card.appendChild(f);return f;
}
function nextBtn(card,label,fn){var b=el('button','btn',label);b.onclick=fn;card.appendChild(b);b.focus();}
function finish(heading,sub){
 clear();
 var pct=Math.round(100*S.correct/Math.max(1,S.total));
 var c=el('div','card center');
 c.appendChild(el('div','trophy','\uD83C\uDFC6'));
 c.appendChild(el('h2','h',heading));
 c.appendChild(el('p','muted',sub));
 var st=el('div','stats');
 st.appendChild(el('div','stat',S.correct+' / '+S.total+' correct'));
 st.appendChild(el('div','stat',S.points+' points'));
 st.appendChild(el('div','stat',pct+'%'));
 c.appendChild(st);
 var b=el('button','btn','Play again');b.onclick=start;c.appendChild(b);
 app.appendChild(c);
 P.complete({points:S.points,correct:S.correct,answered:S.answered,total:S.total});
}
function advance(){S.i++;if(T==='boss_battle'&&S.lives<=0){finish('Defeated','You ran out of lives. The boss wins this round.');return;}if(S.i>=S.total){if(T==='boss_battle'){var won=S.correct>=Math.ceil(S.total*0.6);finish(won?'Boss defeated!':'The boss survived','You landed '+S.correct+' of '+S.total+' hits.');}else finish(S.correct===S.total?'Perfect run!':'Round complete','Here is how you did.');return;}render();}
function pickBoss(){
 var by={};R.forEach(function(r){(by[r.source.page]=by[r.source.page]||[]).push(r);});
 var pages=P.shuffle(Object.keys(by));var out=[],k=0;
 pages.forEach(function(p){by[p]=P.shuffle(by[p]);});
 while(out.length<10){var added=false;for(var i=0;i<pages.length&&out.length<10;i++){var q=by[pages[i]][k];if(q){out.push(q);added=true;}}k++;if(!added)break;}
 return P.shuffle(out);
}
function mcq(){
 var r=S.queue[S.i],boss=T==='boss_battle';
 var hearts='';for(var h=0;h<3;h++)hearts+=(h<S.lives?'\u2764\uFE0F':'\uD83D\uDDA4');
 hud(['Question '+(S.i+1)+' of '+S.total,S.points+' pts',boss?hearts:'Streak '+S.streak]);
 var card=el('div','card');
 var fill;
 if(boss){var bb=el('div','bar boss');fill=el('i');fill.style.width=Math.round(100*(S.total-S.correct)/S.total)+'%';bb.appendChild(fill);card.appendChild(el('div','muted','Boss HP'));card.appendChild(bb);}
 else{var tb=el('div','bar');fill=el('i');tb.appendChild(fill);card.appendChild(tb);}
 card.appendChild(el('h2','q',r.prompt));
 var opts=el('div','opts'),locked=false,left=20;
 function answer(choice){
  if(locked)return;locked=true;if(S.timer){clearInterval(S.timer);S.timer=null;}
  var ok=choice===r.answer;
  Array.prototype.forEach.call(opts.children,function(b){b.onclick=null;if(b.textContent===r.answer)b.classList.add('correct');else if(b.textContent===choice)b.classList.add('wrong');});
  S.answered++;
  if(ok){S.correct++;S.streak++;S.points+=100+Math.min(S.streak,5)*20+(boss?0:Math.round(left*3));}
  else{S.streak=0;if(boss)S.lives--;}
  report();
  feedback(card,ok,r,choice===null?'Time is up.':(ok&&S.streak>1?S.streak+' in a row!':''));
  nextBtn(card,(S.i+1>=S.total||(boss&&S.lives<=0))?'See results':'Next',advance);
 }
 P.shuffle(r.options).forEach(function(o){var b=el('button','opt',o);b.onclick=function(){answer(o);};opts.appendChild(b);});
 card.appendChild(opts);app.appendChild(card);
 if(!boss){S.timer=setInterval(function(){left-=0.1;fill.style.width=Math.max(0,left/20*100)+'%';if(left<=0)answer(null);},100);}
}
function flash(){
 var r=S.queue[S.i];
 hud(['Card '+(S.i+1)+' of '+S.total,S.correct+' known']);
 var card=el('div','card');
 var f=el('button','flip');f.setAttribute('aria-label','Flip card');
 var inner=el('div');var fr=el('div','face f',r.prompt);var bk=el('div','face b');
 bk.appendChild(el('div',null,String(r.answer)));
 if(r.explanation)bk.appendChild(el('div','muted',r.explanation));
 bk.appendChild(P.chip(r));
 inner.appendChild(fr);inner.appendChild(bk);f.appendChild(inner);card.appendChild(f);
 var row=el('div');row.style.display='none';
 function grade(known){S.answered++;if(known){S.correct++;S.points+=100;}report();advance();}
 var no=el('button','btn ghost','Still learning');no.onclick=function(){grade(false);};
 var yes=el('button','btn','I know this');yes.style.marginLeft='10px';yes.onclick=function(){grade(true);};
 row.appendChild(no);row.appendChild(yes);card.appendChild(row);
 f.onclick=function(){f.classList.toggle('flipped');row.style.display=f.classList.contains('flipped')?'block':'none';};
 app.appendChild(card);
}
function cloze(){
 var r=S.queue[S.i];
 hud(['Gap '+(S.i+1)+' of '+S.total,S.points+' pts']);
 var card=el('div','card');
 var parts=r.prompt.split(/_{3,}/);
 var q=el('h2','q');q.appendChild(document.createTextNode(parts[0]));
 var blank=el('span','blank','\u00A0\u00A0\u00A0\u00A0\u00A0');q.appendChild(blank);
 q.appendChild(document.createTextNode(parts.slice(1).join(' ____ ')));
 card.appendChild(q);
 var locked=false;
 function reveal(choice,node){
  if(locked)return;locked=true;
  var ok=norm(choice)===norm(r.answer);
  blank.textContent=String(r.answer);blank.classList.add('correct');
  if(node)node.classList.add(ok?'correct':'wrong');
  S.answered++;if(ok){S.correct++;S.points+=120;}report();
  feedback(card,ok,r,ok?'':'Answer: '+r.answer+'. ');
  nextBtn(card,S.i+1>=S.total?'See results':'Next',advance);
 }
 if(r.options&&r.options.length>1){
  var opts=el('div','opts');
  P.shuffle(r.options).forEach(function(o){var b=el('button','opt',o);b.onclick=function(){reveal(o,b);};opts.appendChild(b);});
  card.appendChild(opts);
 }else{
  var inp=el('input','txt');inp.type='text';inp.setAttribute('aria-label','Your answer');inp.autocomplete='off';
  var b2=el('button','btn','Check');b2.onclick=function(){reveal(inp.value,null);};
  inp.onkeydown=function(e){if(e.key==='Enter')reveal(inp.value,null);};
  card.appendChild(inp);card.appendChild(b2);
 }
 app.appendChild(card);
}
function pairs(){
 var size=5,start0=S.board*size,set=S.queue.slice(start0,start0+size);
 var boards=Math.ceil(S.total/size);
 hud(['Board '+(S.board+1)+' of '+boards,S.correct+' matched first try',S.points+' pts']);
 var card=el('div','card');card.appendChild(el('h2','q','Match each term with its definition'));
 var cols=el('div','cols'),left=el('div','opts'),right=el('div','opts');
 var sel=null,done=0,tried={};
 P.shuffle(set).forEach(function(r){var b=el('button','tile',r.prompt);b.onclick=function(){if(b.classList.contains('correct'))return;if(sel)sel.b.classList.remove('sel');sel={b:b,r:r};b.classList.add('sel');};left.appendChild(b);});
 P.shuffle(set).forEach(function(r){
  var b=el('button','tile',String(r.answer));
  b.onclick=function(){
   if(!sel||b.classList.contains('correct'))return;
   var cur=sel;
   if(cur.r===r){
    cur.b.classList.remove('sel');cur.b.classList.add('correct');b.classList.add('correct');
    b.appendChild(document.createElement('br'));b.appendChild(P.chip(r));
    S.answered++;if(!tried[r.id]){S.correct++;S.points+=100;}else S.points+=40;
    report();sel=null;done++;
    if(done===set.length){var more=(S.board+1)*size<S.total;nextBtn(card,more?'Next board':'See results',function(){if(more){S.board++;clear();pairs();}else finish('All pairs matched!','Every term found its definition.');});}
   }else{
    tried[cur.r.id]=true;cur.b.classList.add('wrong');b.classList.add('wrong');
    setTimeout(function(){cur.b.classList.remove('wrong','sel');b.classList.remove('wrong');},600);sel=null;
   }
  };
  right.appendChild(b);
 });
 cols.appendChild(left);cols.appendChild(right);card.appendChild(cols);app.appendChild(card);
}
function order(){
 var r=S.queue[S.i],steps=r.answer.slice();
 hud(['Sequence '+(S.i+1)+' of '+S.total,S.points+' pts']);
 var card=el('div','card');card.appendChild(el('h2','q',r.prompt));
 var pool=P.shuffle(steps),guard=0;while(pool.join('|')===steps.join('|')&&guard++<5)pool=P.shuffle(steps);
 var placed=[],locked=false;
 var poolBox=el('div','opts'),yours=el('ol','steps');
 card.appendChild(el('div','muted','Tap steps in the correct order:'));
 card.appendChild(poolBox);card.appendChild(el('div','muted','Your order:'));card.appendChild(yours);
 var check=el('button','btn','Check order');check.style.display='none';card.appendChild(check);
 function draw(){
  while(poolBox.firstChild)poolBox.removeChild(poolBox.firstChild);while(yours.firstChild)yours.removeChild(yours.firstChild);
  pool.forEach(function(s){var b=el('button','tile',s);b.onclick=function(){if(locked)return;pool.splice(pool.indexOf(s),1);placed.push(s);draw();};poolBox.appendChild(b);});
  placed.forEach(function(s,i){var li=el('li');var b=el('button','tile',s);b.style.width='95%';b.style.display='inline-block';
   if(locked)b.classList.add(s===steps[i]?'correct':'wrong');
   b.onclick=function(){if(locked)return;placed.splice(i,1);pool.push(s);draw();};li.appendChild(b);yours.appendChild(li);});
  check.style.display=(!locked&&pool.length===0)?'inline-block':'none';
 }
 check.onclick=function(){
  locked=true;var ok=placed.join('|')===steps.join('|');
  S.answered++;if(ok){S.correct++;S.points+=150;}report();draw();
  var f=feedback(card,ok,r,ok?'':'Correct order: '+steps.join(' \u2192 ')+'. ');
  nextBtn(f.parentNode,S.i+1>=S.total?'See results':'Next',advance);
 };
 draw();app.appendChild(card);
}
function render(){
 clear();
 if(T==='quiz_rush'||T==='boss_battle')mcq();
 else if(T==='flashcards')flash();
 else if(T==='fill_gap')cloze();
 else if(T==='match_pairs')pairs();
 else order();
}
function start(){
 reset();
 if(T==='boss_battle')S.queue=pickBoss();
 else if(T==='match_pairs')S.queue=R.slice().sort(function(a,b){return a.source.page-b.source.page;});
 else S.queue=P.shuffle(R);
 S.total=S.queue.length;
 render();report();
 if(!readySent){readySent=true;P.ready();}
}
P.onRestart(start);
start();
})();`;

/** Build the full sandboxed document for a plan using the built-in engine. */
export function buildStandardHtml(plan: GamePlan, opts: { watermark: boolean }): string {
  return assembleDocument(plan, ENGINE_SCRIPT, opts);
}
