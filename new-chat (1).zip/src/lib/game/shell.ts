import type { GamePlan } from "@/lib/ai/schema";
import { MAX_HTML_BYTES } from "@/lib/plans";

export const CSP =
  "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:";

/** Our own CSS shell: the model never has to write styling, which cuts output tokens. */
export const SHELL_CSS = String.raw`
*{box-sizing:border-box}
html,body{margin:0;min-height:100%}
body{font-family:"Avenir Next","Segoe UI","Century Gothic",system-ui,sans-serif;color:#fff;background:radial-gradient(1200px 600px at 20% -10%,var(--bg2),transparent),var(--bg1);display:flex;justify-content:center;padding:18px 14px 48px}
body.t-cosmic{--bg1:#0A0E27;--bg2:#2b2f7a;--acc:#5B5BF5;--acc2:#8B7CF8}
body.t-ocean{--bg1:#06202e;--bg2:#0e6b83;--acc:#0ea5c6;--acc2:#5eead4}
body.t-forest{--bg1:#0b1f17;--bg2:#1c6b4a;--acc:#22B573;--acc2:#86efac}
body.t-sunset{--bg1:#241026;--bg2:#9a3b4d;--acc:#f97316;--acc2:#fbbf24}
body.t-royal{--bg1:#120d2b;--bg2:#4a2fa0;--acc:#7c3aed;--acc2:#c4b5fd}
#app{width:100%;max-width:720px}
.hud{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.pill{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.14);border-radius:999px;padding:5px 12px;font-size:13px;font-weight:700}
.card{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);border-radius:16px;padding:22px;backdrop-filter:blur(6px)}
.center{text-align:center}
.q{font-size:clamp(19px,3.4vw,25px);line-height:1.3;margin:6px 0 18px;font-weight:800}
.h{font-size:28px;margin:8px 0;font-weight:800}
.muted{color:rgba(255,255,255,.7);margin:4px 0 14px}
.opts{display:grid;gap:10px}
.opt,.btn,.tile{font:inherit;color:#fff;cursor:pointer;text-align:left;border-radius:12px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);padding:13px 16px;font-weight:600;font-size:16px;transition:transform .12s,background .12s}
.opt:hover,.tile:hover{background:rgba(255,255,255,.16);transform:translateY(-1px)}
.opt:focus-visible,.btn:focus-visible,.tile:focus-visible,.flip:focus-visible{outline:3px solid var(--acc2);outline-offset:2px}
.btn{background:linear-gradient(135deg,var(--acc),var(--acc2));border:0;text-align:center;font-weight:800;margin-top:14px;padding:12px 22px;border-radius:999px}
.btn.ghost{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.25)}
.opt.correct,.tile.correct{background:#22B573;border-color:#22B573;color:#fff}
.opt.wrong,.tile.wrong{background:#e5484d;border-color:#e5484d}
.tile.sel{border-color:var(--acc2);background:rgba(139,124,248,.35)}
.bar{height:8px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden;margin-bottom:10px}
.bar>i{display:block;height:100%;width:100%;background:linear-gradient(90deg,var(--acc),var(--acc2))}
.bar.boss>i{background:linear-gradient(90deg,#e5484d,#f59e0b)}
.fb{margin-top:14px;padding:12px 14px;border-radius:12px;background:rgba(0,0,0,.28);font-size:15px;line-height:1.45}
.chip{display:inline-block;margin-top:8px;padding:3px 10px;border-radius:999px;background:rgba(139,124,248,.28);border:1px solid rgba(139,124,248,.6);font-size:12px;font-weight:700}
.trophy{font-size:54px}
.stats{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:12px 0}
.stat{background:rgba(255,255,255,.1);border-radius:12px;padding:10px 16px;font-weight:800}
.flip{display:block;width:100%;min-height:230px;perspective:900px;background:none;border:0;padding:0;cursor:pointer;color:#fff;font:inherit}
.flip>div{position:relative;min-height:230px;transition:transform .5s;transform-style:preserve-3d}
.flip.flipped>div{transform:rotateY(180deg)}
.face{position:absolute;inset:0;backface-visibility:hidden;-webkit-backface-visibility:hidden;border-radius:16px;padding:22px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;font-size:20px;font-weight:700;border:1px solid rgba(255,255,255,.2)}
.face.f{background:linear-gradient(135deg,rgba(91,91,245,.45),rgba(139,124,248,.25))}
.face.b{background:linear-gradient(135deg,rgba(34,181,115,.4),rgba(10,14,39,.4));transform:rotateY(180deg)}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.cols .tile{font-size:14px;padding:10px 12px}
.blank{display:inline-block;min-width:90px;border-bottom:3px solid var(--acc2);text-align:center;padding:0 6px}
.blank.correct{color:#4ade80;border-color:#4ade80}
input.txt{font:inherit;width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.25);background:rgba(0,0,0,.25);color:#fff;font-size:16px}
ol.steps{list-style:decimal inside;padding:0;margin:8px 0;display:grid;gap:8px}
ol.steps li{list-style:decimal inside}
.wm{position:fixed;right:10px;bottom:8px;font-size:11px;opacity:.6;font-weight:700}
@media (max-width:520px){.cols{grid-template-columns:1fr}}
`;

const RUNTIME = String.raw`(function(){
var data=JSON.parse(document.getElementById('p2p-data').textContent);
var restartCb=null;
function send(m){try{parent.postMessage(m,'*');}catch(e){}}
function n(v,min){v=Math.floor(Number(v));if(!isFinite(v)||v<min)return min;return v>1000000?1000000:v;}
function shuffle(a){var b=a.slice();for(var i=b.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var t=b[i];b[i]=b[j];b[j]=t;}return b;}
function chip(r){var s=document.createElement('span');s.className='chip';s.textContent='Source: p.'+r.source.page;s.title=r.source.quote;return s;}
function pack(type,o){o=o||{};return {type:type,points:n(o.points,0),correct:n(o.correct,0),answered:n(o.answered,0),total:n(o.total,1)};}
window.P2P={plan:data,rounds:data.rounds,shuffle:shuffle,chip:chip,
ready:function(){send({type:'ready'});},
score:function(o){send(pack('score',o));},
complete:function(o){send(pack('complete',o));},
onRestart:function(f){restartCb=f;}};
window.addEventListener('message',function(ev){if(ev.source!==parent)return;var d=ev.data;if(d&&d.type==='restart'&&typeof restartCb==='function')restartCb();});
})();`;

function safeJson(v: unknown): string {
  return JSON.stringify(v).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/** Wrap a game script (built-in engine or model-written) into the final sandboxed document. */
export function assembleDocument(plan: GamePlan, script: string, opts: { watermark: boolean }): string {
  const safeScript = script.replace(/<\/script/gi, "<\\/script");
  return (
    "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">" +
    "<meta http-equiv=\"Content-Security-Policy\" content=\"" + CSP + "\">" +
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
    "<title>" + escapeHtml(plan.title) + "</title><style>" + SHELL_CSS + "</style></head>" +
    "<body class=\"t-" + plan.theme + "\"><div id=\"app\"></div>" +
    (opts.watermark ? "<div class=\"wm\">Made with PDF2Play</div>" : "") +
    "<script type=\"application/json\" id=\"p2p-data\">" + safeJson(plan) + "</script>" +
    "<script>" + RUNTIME + "</script>" +
    "<script>" + safeScript + "</script></body></html>"
  );
}

const FORBIDDEN: RegExp[] = [
  /\bfetch\s*\(/,
  /XMLHttpRequest/,
  /WebSocket/,
  /EventSource/,
  /sendBeacon/,
  /\bimport\s*\(/,
  /\beval\s*\(/,
  /new\s+Function/,
  /\bparent\s*\.\s*(?!postMessage)/,
  /\btop\s*\./,
  /window\s*\.\s*open/,
  /document\s*\.\s*cookie/,
  /localStorage|sessionStorage|indexedDB/,
  /<iframe|<object|<embed|<link|<script/i,
  /https?:\/\//i,
  /@import/,
];

/** Static safety + contract check for model-written game scripts. */
export function validateGameScript(js: string): { ok: boolean; reason?: string } {
  if (js.length < 600) return { ok: false, reason: "script too short" };
  if (js.length > 120 * 1024) return { ok: false, reason: "script too large" };
  for (const re of FORBIDDEN) if (re.test(js)) return { ok: false, reason: "forbidden construct " + re.source };
  for (const needle of ["P2P.ready", "P2P.score", "P2P.complete", "P2P.chip", "P2P.onRestart", "P2P.rounds"]) {
    if (!js.includes(needle)) return { ok: false, reason: "missing " + needle };
  }
  return { ok: true };
}

/** Enforces the size cap and (re)injects our CSP into any stored game document. */
export function hardenHtml(html: string): string {
  const bytes = new TextEncoder().encode(html).length;
  if (bytes > MAX_HTML_BYTES) throw new Error("Game is larger than 400KB and was rejected.");
  const meta = "<meta http-equiv=\"Content-Security-Policy\" content=\"" + CSP + "\">";
  const stripped = html.replace(/<meta[^>]*http-equiv=["']?content-security-policy[^>]*>/gi, "");
  if (/<head[^>]*>/i.test(stripped)) return stripped.replace(/<head[^>]*>/i, (m) => m + meta);
  return meta + stripped;
}
