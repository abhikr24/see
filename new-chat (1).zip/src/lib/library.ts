/**
 * Browser-side library. Games (html + plan) live in IndexedDB store "games";
 * a small index lives in localStorage key "pdf2play:games:v1". The raw PDF is never stored.
 */
import type { GamePlan } from "@/lib/ai/schema";
import type { GameType } from "@/lib/plans";

export const INDEX_KEY = "pdf2play:games:v1";
export const GUEST_KEY = "pdf2play:guest:v1";
const DB_NAME = "pdf2play";
const DB_VERSION = 1;
const STORE = "games";

export interface GameIndexEntry {
  id: string;
  title: string;
  type: GameType;
  date: string;
  pageCount: number;
  bestScore: number;
  hash: string;
}

export interface StoredGame {
  id: string;
  html: string;
  plan: GamePlan;
  verified: { verified: number; total: number };
  watermark: boolean;
  coverage: { failedPages: number[]; ocrPages: number[] };
}

function isEntry(v: unknown): v is GameIndexEntry {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    typeof o.id === "string" &&
    typeof o.title === "string" &&
    typeof o.type === "string" &&
    typeof o.date === "string" &&
    typeof o.pageCount === "number" &&
    typeof o.bestScore === "number" &&
    typeof o.hash === "string"
  );
}

/** Parses the raw localStorage value defensively (corrupt or old-version data yields an empty library). */
export function parseIndex(raw: string | null): GameIndexEntry[] {
  try {
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || (parsed as { v?: unknown }).v !== 1) return [];
    const games = (parsed as { games?: unknown }).games;
    return Array.isArray(games) ? games.filter(isEntry) : [];
  } catch {
    return [];
  }
}

export function readRawIndex(): string {
  try {
    return window.localStorage.getItem(INDEX_KEY) ?? "";
  } catch {
    return "";
  }
}

export function readIndex(): GameIndexEntry[] {
  return parseIndex(readRawIndex());
}

export const LIBRARY_EVENT = "p2p-library";

function writeIndex(games: GameIndexEntry[]): void {
  try {
    if (games.length === 0) window.localStorage.removeItem(INDEX_KEY);
    else window.localStorage.setItem(INDEX_KEY, JSON.stringify({ v: 1, games }));
  } catch {
    // Storage full or blocked: the game is still in IndexedDB.
  }
  window.dispatchEvent(new Event(LIBRARY_EVENT));
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("This browser does not allow local storage for games."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE, { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open local game storage."));
  });
}

async function tx<T>(mode: IDBTransactionMode, run: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const r = run(t.objectStore(STORE));
    t.oncomplete = () => {
      db.close();
      resolve(r.result);
    };
    t.onerror = () => {
      db.close();
      reject(t.error ?? new Error("Local storage failed."));
    };
  });
}

export async function saveGame(entry: GameIndexEntry, game: StoredGame): Promise<void> {
  await tx("readwrite", (s) => s.put(game));
  const rest = readIndex().filter((g) => g.id !== entry.id);
  writeIndex([entry, ...rest]);
}

export async function getGame(id: string): Promise<StoredGame | null> {
  try {
    const g = await tx<StoredGame | undefined>("readonly", (s) => s.get(id) as IDBRequest<StoredGame | undefined>);
    return g ?? null;
  } catch {
    return null;
  }
}

export async function deleteGame(id: string): Promise<void> {
  try {
    await tx("readwrite", (s) => s.delete(id));
  } catch {
    // ignore: index cleanup below still removes the entry
  }
  writeIndex(readIndex().filter((g) => g.id !== id));
}

export async function clearLibrary(): Promise<void> {
  try {
    await tx("readwrite", (s) => s.clear());
  } catch {
    // ignore
  }
  writeIndex([]);
}

export function updateBestScore(id: string, score: number): GameIndexEntry[] {
  const next = readIndex().map((g) => (g.id === id && score > g.bestScore ? { ...g, bestScore: score } : g));
  writeIndex(next);
  return next;
}

export function findByHash(hash: string): GameIndexEntry | undefined {
  return readIndex().find((g) => g.hash === hash);
}

/** Guests get GUEST_FREE_GAMES local games; this counter survives "clear library". */
export function readGuestUsed(): number {
  try {
    const raw = window.localStorage.getItem(GUEST_KEY);
    if (!raw) return 0;
    const v: unknown = JSON.parse(raw);
    const used = v && typeof v === "object" ? (v as { used?: unknown }).used : 0;
    return typeof used === "number" && used >= 0 ? used : 0;
  } catch {
    return 0;
  }
}

export function bumpGuestUsed(): void {
  try {
    window.localStorage.setItem(GUEST_KEY, JSON.stringify({ v: 1, used: readGuestUsed() + 1 }));
  } catch {
    // ignore
  }
}
