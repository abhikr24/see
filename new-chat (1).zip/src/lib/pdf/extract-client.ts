import { MAX_PDF_BYTES, MAX_PDF_PAGES } from "@/lib/plans";
import type { PageExtract } from "@/lib/pdf/types";

export type ValidationResult =
  | { ok: true; bytes: ArrayBuffer; pageCount: number }
  | { ok: false; message: string };

/** Step 1 - validate on drop: MIME, %PDF- magic bytes, size, page count, encryption. */
export async function validatePdf(file: File): Promise<ValidationResult> {
  const looksPdf = file.type === "application/pdf" || (file.type === "" && /\.pdf$/i.test(file.name));
  if (!looksPdf) return { ok: false, message: "Only PDF files are supported. Please choose a .pdf file." };
  if (file.size === 0) return { ok: false, message: "This file is empty." };
  if (file.size > MAX_PDF_BYTES) {
    return { ok: false, message: "This PDF is larger than 20MB. Please compress it or split it." };
  }
  const bytes = await file.arrayBuffer();
  const head = new TextDecoder().decode(new Uint8Array(bytes.slice(0, 5)));
  if (head !== "%PDF-") return { ok: false, message: "This file is not a real PDF (missing %PDF- header)." };
  try {
    const { PDFDocument } = await import("pdf-lib");
    const doc = await PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false });
    if (doc.isEncrypted) {
      return { ok: false, message: "This PDF is encrypted or password-protected. Remove the protection and try again." };
    }
    const pageCount = doc.getPageCount();
    if (pageCount > MAX_PDF_PAGES) {
      return { ok: false, message: `This PDF has ${pageCount} pages. The limit is ${MAX_PDF_PAGES} pages.` };
    }
    if (pageCount === 0) return { ok: false, message: "This PDF has no pages." };
    return { ok: true, bytes, pageCount };
  } catch {
    return { ok: false, message: "We could not read this PDF. It may be corrupted or encrypted." };
  }
}

type WorkerMessage =
  | { type: "progress"; page: number; total: number }
  | { type: "done"; pages: PageExtract[] }
  | { type: "error"; code: string; message: string };

/** Step 2 - per-page extraction with pdfjs-dist inside a Web Worker. */
export function extractPdf(bytes: ArrayBuffer, onProgress: (page: number, total: number) => void): Promise<PageExtract[]> {
  return new Promise((resolve, reject) => {
    let worker: Worker;
    try {
      worker = new Worker("/pdfjs/extract.worker.mjs", { type: "module" });
    } catch {
      reject(new Error("Your browser could not start the PDF reader worker."));
      return;
    }
    worker.onmessage = (e: MessageEvent<WorkerMessage>) => {
      const m = e.data;
      if (m.type === "progress") onProgress(m.page, m.total);
      else if (m.type === "done") {
        worker.terminate();
        resolve(m.pages);
      } else {
        worker.terminate();
        reject(new Error(m.message));
      }
    };
    worker.onerror = () => {
      worker.terminate();
      reject(new Error("The PDF reader worker failed to load. Please refresh and try again."));
    };
    worker.postMessage({ buffer: bytes.slice(0), maxPages: MAX_PDF_PAGES });
  });
}
