export interface PageExtract {
  page: number;
  text: string;
  chars: number;
  headings: string[];
  lists: string[];
  captions: string[];
  footnotes: string[];
  /** True when the page has under 50 characters of text (scanned image, blank, cover art). */
  needsOCR: boolean;
}

export interface DocumentBrief {
  toc: { page: number; heading: string }[];
  keyTerms: string[];
  facts: { page: number; items: string[] }[];
  pageSummaries: { page: number; summary: string }[];
  overview?: string;
}

export const OCR_THRESHOLD_CHARS = 50;
export const CONTENT_PAGE_CHARS = 200;
