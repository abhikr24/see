/** In-memory hand-off of a validated PDF from the landing dropzone to the creator page (never persisted, never uploaded). */
let pending: File | null = null;

export function setPendingFile(file: File): void {
  pending = file;
}

export function takePendingFile(): File | null {
  const f = pending;
  pending = null;
  return f;
}
