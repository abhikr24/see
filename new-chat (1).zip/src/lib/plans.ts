/**
 * Single source of truth for plans, prices and limits.
 * All money is stored as integer paise and is tax-inclusive.
 * The server ALWAYS reads prices from here - never from the client.
 */
export type PlanId = "free" | "pro" | "classroom";
export type PaidPlanId = Exclude<PlanId, "free">;

export type GameType =
  | "quiz_rush"
  | "flashcards"
  | "fill_gap"
  | "match_pairs"
  | "order_steps"
  | "boss_battle";

export const GAME_TYPES: readonly GameType[] = [
  "quiz_rush",
  "flashcards",
  "fill_gap",
  "match_pairs",
  "order_steps",
  "boss_battle",
] as const;

export const GAME_TYPE_INFO: Record<GameType, { label: string; blurb: string }> = {
  quiz_rush: { label: "Quiz Rush", blurb: "Timed multiple choice with answer streaks." },
  flashcards: { label: "Flashcards", blurb: "Flip cards and mark what you know." },
  fill_gap: { label: "Fill the Gap", blurb: "Complete sentences taken from your document." },
  match_pairs: { label: "Match Pairs", blurb: "Connect each term with its definition." },
  order_steps: { label: "Order the Steps", blurb: "Put processes and sequences in the right order." },
  boss_battle: { label: "Boss Battle", blurb: "10 questions, 3 lives, defeat the boss." },
};

export interface Plan {
  id: PlanId;
  name: string;
  tagline: string;
  pricePaise: number;
  interval: "forever" | "month";
  gamesPerMonth: number;
  maxPages: number;
  watermark: boolean;
  savedLibrary: boolean;
  seats: number;
  allowedTypes: readonly GameType[];
  features: string[];
  popular?: boolean;
}

export const PLANS: Record<PlanId, Plan> = {
  free: {
    id: "free",
    name: "Free",
    tagline: "Perfect to get started",
    pricePaise: 0,
    interval: "forever",
    gamesPerMonth: 3,
    maxPages: 30,
    watermark: true,
    savedLibrary: false,
    seats: 1,
    allowedTypes: ["quiz_rush", "flashcards"],
    features: ["3 games / month", "Up to 30 pages per PDF", "Quiz Rush and Flashcards", "PDF2Play watermark"],
  },
  pro: {
    id: "pro",
    name: "Pro",
    tagline: "For students and professionals",
    pricePaise: 24900,
    interval: "month",
    gamesPerMonth: 300,
    maxPages: 30,
    watermark: false,
    savedLibrary: true,
    seats: 1,
    allowedTypes: GAME_TYPES,
    features: ["300 games / month", "All 6 game types", "No watermark", "Saved library on your device"],
    popular: true,
  },
  classroom: {
    id: "classroom",
    name: "Classroom",
    tagline: "For schools and teams",
    pricePaise: 99900,
    interval: "month",
    gamesPerMonth: 300,
    maxPages: 30,
    watermark: false,
    savedLibrary: true,
    seats: 5,
    allowedTypes: GAME_TYPES,
    features: ["Everything in Pro", "5 seats (300 games / month each)", "Shared library for all seats", "Owner manages seats by email"],
  },
};

export const PLAN_LIST: Plan[] = [PLANS.free, PLANS.pro, PLANS.classroom];

export function isPaidPlan(id: string): id is PaidPlanId {
  return id === "pro" || id === "classroom";
}

/** Access length granted by one successful monthly payment. */
export const PLAN_PERIOD_DAYS = 30;

/** Guests may create exactly one game locally before being asked to sign up. */
export const GUEST_FREE_GAMES = 1;

/** Hard limits enforced BEFORE any model call. */
export const MAX_PDF_BYTES = 20 * 1024 * 1024;
export const MAX_PDF_PAGES = 30;
export const MAX_HTML_BYTES = 400 * 1024;

/** Spend ceilings in paise. The free tier must never cost more than INR 8 / month. */
export const FREE_MONTHLY_COST_CEILING_PAISE = 800;
export const DAILY_COST_CEILING_PAISE: Record<PlanId | "guest", number> = {
  guest: 300,
  free: 800,
  pro: 800,
  classroom: 3000,
};
/** Maximum spend for a single generation run. */
export const PER_RUN_COST_CEILING_PAISE: Record<PlanId | "guest", number> = {
  guest: 300,
  free: 300,
  pro: 500,
  classroom: 500,
};

export function formatINR(paise: number): string {
  const rupees = paise / 100;
  return "\u20B9" + (Number.isInteger(rupees) ? rupees.toString() : rupees.toFixed(2));
}
