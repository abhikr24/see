import "server-only";
import { createHash } from "node:crypto";
import { getAdminClient } from "@/lib/supabase/admin";

export interface RateResult {
  ok: boolean;
  remaining: number;
  retryAfterSec: number;
}

const memory = new Map<string, { count: number; start: number }>();

function memoryHit(key: string, max: number, windowSec: number): RateResult {
  const now = Date.now();
  const entry = memory.get(key);
  if (!entry || now - entry.start > windowSec * 1000) {
    memory.set(key, { count: 1, start: now });
    return { ok: true, remaining: max - 1, retryAfterSec: 0 };
  }
  entry.count += 1;
  const retry = Math.ceil((entry.start + windowSec * 1000 - now) / 1000);
  return { ok: entry.count <= max, remaining: Math.max(0, max - entry.count), retryAfterSec: retry };
}

/**
 * Fixed-window rate limit. Uses the atomic hit_rate_limit() SQL function when Supabase is
 * configured (works across serverless instances) and falls back to in-memory otherwise.
 */
export async function rateLimit(key: string, max: number, windowSec: number): Promise<RateResult> {
  const admin = getAdminClient();
  if (admin) {
    const { data, error } = await admin.rpc("hit_rate_limit", {
      p_key: key,
      p_window_seconds: windowSec,
      p_max: max,
    });
    if (!error && typeof data === "number") {
      return { ok: data <= max, remaining: Math.max(0, max - data), retryAfterSec: windowSec };
    }
  }
  return memoryHit(key, max, windowSec);
}

export function clientKey(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
  return createHash("sha256").update(fwd).digest("hex").slice(0, 24);
}
