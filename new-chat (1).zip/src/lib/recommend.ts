import type { PageExtract } from "@/lib/pdf/types";
import type { GameType } from "@/lib/plans";

export interface Recommendation {
  type: GameType;
  reason: string;
}

/** Local heuristic ranking, used as input to - and fallback for - the AI recommendation. */
export function heuristicRecommend(pages: PageExtract[]): Recommendation[] {
  const text = pages.map((p) => p.text).join("\n");
  const count = (re: RegExp) => (text.match(re) ?? []).length;
  const steps = count(/^\s*(step\s*\d|\d{1,2}[.)]\s|first,|second,|third,|next,|then,|finally,)/gim);
  const defs = count(/\b(is defined as|refers to|means|is known as|are called)\b/gi) + count(/^[A-Z][\w -]{2,30}:\s\S/gm);
  const numbers = count(/\b\d{3,4}\b|\b\d+(\.\d+)?\s?%/g);
  const lists = pages.reduce((n, p) => n + p.lists.length, 0);
  const chars = pages.reduce((n, p) => n + p.chars, 0);

  const scores: Record<GameType, { s: number; r: string }> = {
    quiz_rush: { s: 3 + numbers * 0.05, r: "Facts, names and figures suit fast multiple choice." },
    boss_battle: { s: 2 + chars / 8000, r: "Substantial content makes a great 10-question boss fight." },
    flashcards: { s: 2 + defs * 0.3 + pages.reduce((n, p) => n + p.headings.length, 0) * 0.15, r: "Many terms and definitions are ideal for flip cards." },
    fill_gap: { s: 2 + chars / 12000, r: "Clear explanatory sentences work well as fill-in-the-gap." },
    match_pairs: { s: 1 + defs * 0.45, r: "Term and definition patterns make strong matching rounds." },
    order_steps: { s: 0.5 + steps * 0.5 + lists * 0.15, r: "Sequences and numbered steps suit an ordering game." },
  };
  return (Object.keys(scores) as GameType[])
    .sort((a, b) => scores[b].s - scores[a].s)
    .map((type) => ({ type, reason: scores[type].r }));
}
