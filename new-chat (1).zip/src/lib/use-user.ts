"use client";

import { useEffect, useState } from "react";
import { getBrowserClient } from "@/lib/supabase/client";

export interface ClientUser {
  id: string;
  email: string;
}

/** Current Supabase user in the browser. `loading` is true until the first check completes. */
export function useUser(): { user: ClientUser | null; loading: boolean } {
  const [state, setState] = useState<{ user: ClientUser | null; loading: boolean }>({ user: null, loading: true });
  useEffect(() => {
    const supabase = getBrowserClient();
    if (!supabase) {
      const t = setTimeout(() => setState({ user: null, loading: false }), 0);
      return () => clearTimeout(t);
    }
    let active = true;
    supabase.auth.getUser().then(({ data }) => {
      if (active) setState({ user: data.user ? { id: data.user.id, email: data.user.email ?? "" } : null, loading: false });
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setState({ user: session?.user ? { id: session.user.id, email: session.user.email ?? "" } : null, loading: false });
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);
  return state;
}
