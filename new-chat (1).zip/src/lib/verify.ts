import type { Round } from "@/lib/ai/schema";
import type { PageExtract } from "@/lib/pdf/types";

export function tokenize(s: string): string[] {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/-\s*\n\s*/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter(Boolean);
}

export function wordCount(s: string): number {
  return s.trim().split(/\s+/).filter(Boolean).length;
}

/** Trims a quote to at most 25 words (still a verbatim prefix). */
export function clampQuote(q: string): string {
  const words = q.trim().split(/\s+/);
  return words.length > 25 ? words.slice(0, 25).join(" ") : q.trim();
}

/** Share of quote tokens present on the page (unigram) and of quote bigrams present (order check). */
export function quoteScores(quote: string, pageText: string): { unigram: number; bigram: number } {
  const q = tokenize(quote);
  const p = tokenize(pageText);
  if (q.length === 0 || p.length === 0) return { unigram: 0, bigram: 0 };
  const pSet = new Set(p);
  const unigram = q.filter((t) => pSet.has(t)).length / q.length;
  const pBi = new Set<string>();
  for (let i = 0; i < p.length - 1; i++) pBi.add(p[i] + " " + p[i + 1]);
  let bi = 0;
  let biTotal = 0;
  for (let i = 0; i < q.length - 1; i++) {
    biTotal++;
    if (pBi.has(q[i] + " " + q[i + 1])) bi++;
  }
  return { unigram, bigram: biTotal === 0 ? unigram : bi / biTotal };
}

export const MIN_QUOTE_WORDS = 8;
export const MAX_QUOTE_WORDS = 25;
export const UNIGRAM_THRESHOLD = 0.85;
export const BIGRAM_THRESHOLD = 0.7;

export interface VerifyOutcome {
  kept: Round[];
  dropped: { id: string; page: number; reason: string }[];
}

export function verifyRounds(rounds: Round[], pages: PageExtract[]): VerifyOutcome {
  const byPage = new Map(pages.map((p) => [p.page, p.text]));
  const kept: Round[] = [];
  const dropped: VerifyOutcome["dropped"] = [];
  for (const r of rounds) {
    const text = byPage.get(r.source.page);
    const words = wordCount(r.source.quote);
    if (!text) {
      dropped.push({ id: r.id, page: r.source.page, reason: "page not in document" });
    } else if (words < MIN_QUOTE_WORDS || words > MAX_QUOTE_WORDS) {
      dropped.push({ id: r.id, page: r.source.page, reason: "quote length " + words });
    } else {
      const s = quoteScores(r.source.quote, text);
      if (s.unigram >= UNIGRAM_THRESHOLD && s.bigram >= BIGRAM_THRESHOLD) kept.push(r);
      else dropped.push({ id: r.id, page: r.source.page, reason: "quote not found on page" });
    }
  }
  return { kept, dropped };
}
