-- PDF2Play schema. Run this FIRST in the Supabase SQL editor, then 02_rls_and_functions.sql.
-- All money columns are integer paise (tax-inclusive).

create extension if not exists pgcrypto;

do $$ begin
  create type public.payment_status as enum ('created', 'paid', 'failed', 'refunded');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  plan text not null default 'free' check (plan in ('free', 'pro', 'classroom')),
  credits integer not null default 3 check (credits >= 0),
  period_start timestamptz not null default now(),
  plan_expires_at timestamptz,
  created_at timestamptz not null default now()
);

-- Game METADATA only. The game HTML and plan live in the user's browser (IndexedDB).
create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  game_type text not null,
  page_count integer not null check (page_count between 1 and 30),
  content_hash text not null,
  verified_count integer,
  total_count integer,
  engine text,
  created_at timestamptz not null default now()
);
create index if not exists games_user_idx on public.games(user_id, created_at desc);

create table if not exists public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  game_id uuid references public.games(id) on delete set null,
  game_type text,
  page_count integer,
  tokens_in integer not null default 0,
  tokens_out integer not null default 0,
  cost_paise integer not null default 0,
  status text not null default 'ok',
  created_at timestamptz not null default now()
);
create index if not exists generations_user_idx on public.generations(user_id, created_at desc);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan text not null check (plan in ('pro', 'classroom')),
  status text not null default 'active' check (status in ('active', 'expired', 'cancelled', 'refunded')),
  current_period_start timestamptz not null,
  current_period_end timestamptz not null,
  razorpay_order_id text,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan text not null check (plan in ('pro', 'classroom')),
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR',
  razorpay_order_id text not null unique,
  razorpay_payment_id text unique,
  status public.payment_status not null default 'created',
  created_at timestamptz not null default now(),
  paid_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.usage_counters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  period text not null,
  conversions integer not null default 0,
  updated_at timestamptz not null default now(),
  unique (user_id, period)
);

-- Razorpay webhook idempotency: one row per X-Razorpay-Event-Id.
create table if not exists public.webhook_events (
  id text primary key,
  event text not null,
  payload jsonb not null,
  received_at timestamptz not null default now()
);

create table if not exists public.rate_limits (
  key text primary key,
  window_start timestamptz not null default now(),
  count integer not null default 0
);

create table if not exists public.notify_requests (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  plan text not null,
  created_at timestamptz not null default now(),
  unique (email, plan)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  game_id text,
  game_title text,
  message text not null check (char_length(message) between 3 and 1000),
  created_at timestamptz not null default now()
);

create table if not exists public.classroom_members (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  member_email text not null,
  created_at timestamptz not null default now(),
  unique (owner_id, member_email)
);

create table if not exists public.shared_games (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  game_type text not null,
  page_count integer not null,
  plan jsonb not null,
  html text not null check (octet_length(html) <= 409600),
  created_at timestamptz not null default now()
);

-- New user => profile with 3 free credits.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, credits) values (new.id, lower(new.email), 3)
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
