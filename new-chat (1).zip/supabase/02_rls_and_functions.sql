-- PDF2Play RLS + SECURITY DEFINER functions. Run AFTER 01_schema.sql. Safe to re-run.

alter table public.profiles enable row level security;
alter table public.games enable row level security;
alter table public.generations enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;
alter table public.usage_counters enable row level security;
alter table public.webhook_events enable row level security;
alter table public.rate_limits enable row level security;
alter table public.notify_requests enable row level security;
alter table public.reports enable row level security;
alter table public.classroom_members enable row level security;
alter table public.shared_games enable row level security;

-- profiles: read/update own row; entitlement columns are protected by a trigger below.
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create or replace function public.protect_profile_columns()
returns trigger language plpgsql as $$
begin
  if coalesce(auth.role(), 'service_role') <> 'service_role' and (
       new.id <> old.id or new.plan <> old.plan or new.credits <> old.credits
    or new.period_start <> old.period_start
    or new.plan_expires_at is distinct from old.plan_expires_at) then
    raise exception 'plan, credits and period are managed by the server';
  end if;
  return new;
end $$;
drop trigger if exists protect_profile_columns on public.profiles;
create trigger protect_profile_columns before update on public.profiles
  for each row execute function public.protect_profile_columns();

-- games: users manage their own metadata rows.
drop policy if exists "games_select_own" on public.games;
create policy "games_select_own" on public.games for select using (auth.uid() = user_id);
drop policy if exists "games_insert_own" on public.games;
create policy "games_insert_own" on public.games for insert with check (auth.uid() = user_id);
drop policy if exists "games_update_own" on public.games;
create policy "games_update_own" on public.games for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "games_delete_own" on public.games;
create policy "games_delete_own" on public.games for delete using (auth.uid() = user_id);

-- generations, usage_counters: read own; written by service role only.
drop policy if exists "generations_select_own" on public.generations;
create policy "generations_select_own" on public.generations for select using (auth.uid() = user_id);
drop policy if exists "usage_select_own" on public.usage_counters;
create policy "usage_select_own" on public.usage_counters for select using (auth.uid() = user_id);

-- payments, subscriptions: read own; WRITTEN BY SERVICE ROLE ONLY (no insert/update/delete policies).
drop policy if exists "payments_select_own" on public.payments;
create policy "payments_select_own" on public.payments for select using (auth.uid() = user_id);
drop policy if exists "subscriptions_select_own" on public.subscriptions;
create policy "subscriptions_select_own" on public.subscriptions for select using (auth.uid() = user_id);

-- reports: read own. classroom + shared library: owner (and seat members for shared games) can read.
drop policy if exists "reports_select_own" on public.reports;
create policy "reports_select_own" on public.reports for select using (auth.uid() = user_id);
drop policy if exists "classroom_owner_select" on public.classroom_members;
create policy "classroom_owner_select" on public.classroom_members for select using (auth.uid() = owner_id);
drop policy if exists "shared_select_owner_or_member" on public.shared_games;
create policy "shared_select_owner_or_member" on public.shared_games for select using (
  auth.uid() = owner_id
  or exists (
    select 1 from public.classroom_members cm
    where cm.owner_id = shared_games.owner_id
      and cm.member_email = lower(coalesce(auth.jwt() ->> 'email', ''))
  )
);
-- webhook_events, rate_limits, notify_requests: RLS on with NO policies = service role only.

-- Atomic quota increment. Returns the new count, or -1 when the limit is already reached.
create or replace function public.increment_usage(p_user uuid, p_period text, p_limit integer)
returns integer language plpgsql security definer set search_path = public as $$
declare v integer;
begin
  insert into public.usage_counters as u (user_id, period, conversions)
  values (p_user, p_period, 1)
  on conflict (user_id, period)
  do update set conversions = u.conversions + 1, updated_at = now()
  where u.conversions < p_limit
  returning u.conversions into v;
  if v is null then return -1; end if;
  update public.profiles set credits = greatest(p_limit - v, 0) where id = p_user;
  return v;
end $$;

create or replace function public.refund_usage(p_user uuid, p_period text, p_limit integer)
returns void language plpgsql security definer set search_path = public as $$
declare v integer;
begin
  update public.usage_counters set conversions = greatest(conversions - 1, 0), updated_at = now()
  where user_id = p_user and period = p_period returning conversions into v;
  if v is not null then
    update public.profiles set credits = greatest(p_limit - v, 0) where id = p_user;
  end if;
end $$;

-- Atomic fixed-window rate limiter. Returns the hit count within the current window.
create or replace function public.hit_rate_limit(p_key text, p_window_seconds integer, p_max integer)
returns integer language plpgsql security definer set search_path = public as $$
declare v integer;
begin
  insert into public.rate_limits as r (key, window_start, count) values (p_key, now(), 1)
  on conflict (key) do update set
    count = case when r.window_start < now() - make_interval(secs => p_window_seconds) then 1 else r.count + 1 end,
    window_start = case when r.window_start < now() - make_interval(secs => p_window_seconds) then now() else r.window_start end
  returning r.count into v;
  return v;
end $$;

-- Marks a payment paid AND grants the plan in one transaction. Idempotent: a replay returns false
-- and changes nothing, so verify + webhook (or a replayed webhook) can never double-credit.
create or replace function public.mark_payment_paid(p_order_id text, p_payment_id text, p_credits integer, p_days integer)
returns boolean language plpgsql security definer set search_path = public as $$
declare pay public.payments%rowtype; cur_plan text; cur_exp timestamptz; base timestamptz; same_active boolean;
begin
  update public.payments
     set status = 'paid', razorpay_payment_id = p_payment_id, paid_at = now(), updated_at = now()
   where razorpay_order_id = p_order_id and status in ('created', 'failed')
  returning * into pay;
  if not found then return false; end if;

  select plan, plan_expires_at into cur_plan, cur_exp from public.profiles where id = pay.user_id for update;
  same_active := cur_plan = pay.plan and cur_exp is not null and cur_exp > now();
  base := case when same_active then cur_exp else now() end;

  update public.profiles set
    plan = pay.plan,
    plan_expires_at = base + make_interval(days => p_days),
    period_start = case when same_active then period_start else now() end,
    credits = case when same_active then credits else p_credits end
  where id = pay.user_id;

  insert into public.subscriptions (user_id, plan, status, current_period_start, current_period_end, razorpay_order_id)
  values (pay.user_id, pay.plan, 'active', base, base + make_interval(days => p_days), p_order_id);
  return true;
end $$;

-- Refund: mark refunded and drop the user back to free (only if that plan is still active).
create or replace function public.apply_refund(p_payment_id text)
returns boolean language plpgsql security definer set search_path = public as $$
declare pay public.payments%rowtype;
begin
  update public.payments set status = 'refunded', updated_at = now()
   where razorpay_payment_id = p_payment_id and status = 'paid'
  returning * into pay;
  if not found then return false; end if;
  update public.subscriptions set status = 'refunded' where razorpay_order_id = pay.razorpay_order_id;
  update public.profiles set plan = 'free', plan_expires_at = null, period_start = now(), credits = 3
   where id = pay.user_id and plan = pay.plan;
  return true;
end $$;

-- These run with elevated rights: only the service role may call them.
revoke all on function public.increment_usage(uuid, text, integer) from public, anon, authenticated;
revoke all on function public.refund_usage(uuid, text, integer) from public, anon, authenticated;
revoke all on function public.hit_rate_limit(text, integer, integer) from public, anon, authenticated;
revoke all on function public.mark_payment_paid(text, text, integer, integer) from public, anon, authenticated;
revoke all on function public.apply_refund(text) from public, anon, authenticated;
grant execute on function public.increment_usage(uuid, text, integer) to service_role;
grant execute on function public.refund_usage(uuid, text, integer) to service_role;
grant execute on function public.hit_rate_limit(text, integer, integer) to service_role;
grant execute on function public.mark_payment_paid(text, text, integer, integer) to service_role;
grant execute on function public.apply_refund(text) to service_role;
