# ARCHITECTURE

> Authored this session — no architecture doc existed in the design drop.
> Interface rule: **do not change the shapes below without updating this file
> and calling it out in HANDOFF.md.**

## Topology

```
repo root .................. apps/web role (Next.js 16 App Router, sandbox-pinned)
packages/shared ............ vision contract + pure attribute mapping (@shared/*)
services/vision ............ FastAPI: rembg(u2net) + FashionCLIP, cached extract
src/lib/storage.ts ......... storage provider interface (local | Supabase)
src/lib/vision/client.ts ... server-side vision client + cache orchestration
```

Mobile-first PWA: bottom tab bar, bottom sheets, safe areas, `100dvh` frame,
SW runtime-caches `/api/media/*` for offline wardrobe browsing. No hover-only
interactions; primary touch targets ≥ 44 px.

## The image→attributes contract (packages/shared/vision.ts)

`VisionAttributes` — everything auto-detected, everything editable:

| field       | type                                  | source                        |
| ----------- | ------------------------------------- | ----------------------------- |
| category    | top\|bottom\|footwear\|outerwear\|accessory | FashionCLIP (or user)     |
| subcategory | key from `SUBCATEGORIES`              | FashionCLIP phrases           |
| colors      | palette ids, `[0]`=primary            | FashionCLIP labels or on-device hex hints → culori OKLab nearest |
| pattern     | solid\|striped\|checked\|floral\|graphic\|dotted\|camo | FashionCLIP |
| formality   | 0\|1\|2                               | FashionCLIP                   |
| warmth      | 0\|1\|2 (engine-compat)               | derived from seasons          |
| seasons     | subset of spring/summer/autumn/winter | FashionCLIP season triplet    |
| material    | canonical list or "" (= unknown)      | FashionCLIP, score ≥ 0.30     |
| fit         | slim\|regular\|relaxed\|oversized      | NOT auto-detected (honest default) |
| confidence  | per-attribute 0..1                    | winning softmax score         |

`ExtractResponse` (both HTTP surfaces): `{ ok, cache: "hit"|"miss",
provider: "vision"|"fallback", hash, attributes, cutoutWebpB64, models:
{ segmenter: "u2net", classifier: "fashion-clip" } }`.

Mirrors that must stay 1:1: `packages/shared/vision.ts` ↔
`services/vision/app/labels.py`; `packages/shared/attributes.ts` ↔
`services/vision/app/mapping.py`.

## HTTP surface (web)

- `POST /api/wardrobe/extract` — multipart `image` (≤ 8 MB) + optional `hints`
  JSON `{ paletteHexes }`. Steps: sha-256 → `vision_extractions` cache hit?
  return → store original via storage provider → call
  `${VISION_SERVICE_URL}/extract` (45 s timeout) → fallback heuristics if
  absent/failed → persist cache row (provider-tagged) → respond.
  **Idempotent by content hash: the same image is never processed twice.**
- `POST /api/wardrobe/items` — zod-validated confirmed fields →
  `clothing_items` insert. References stored media by hash; no re-upload.
- `GET /api/media/<key>` — streams local uploads, `immutable` cache headers,
  path-traversal-guarded (`sanitizeKey`).

## Data model (new/changed this session)

- `clothing_items`: + `material`, `fit`, `seasons`, `notes`, `image_ref`,
  `cutout_url`, `image_hash`, `vision_status`, `vision_meta`. Legacy columns
  (`colors`, `warmth`, `occasions`, `times_worn`…) unchanged — the stylist
  engine (`src/lib/engine.ts`) depends on them and was not modified.
- `vision_extractions` (new): `hash` PK (`sha256:<hex>`), `attributes` jsonb,
  `cutout_ref`, `provider`, timestamps.

## Boundaries

- Engine packages/engine logic = `src/lib/engine.ts` + `palette.ts` harmony —
  **do not touch** (unchanged this session).
- Vision service must keep: u2net-only rembg, MIT/Apache-2.0 deps, cache-first
  semantics, the response contract above.
- Open-Meteo stays behind `src/lib/weather.ts` (free tier is non-commercial —
  swap providers via that boundary, never inline).
