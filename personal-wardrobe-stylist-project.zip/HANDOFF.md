# HANDOFF — Personal Wardrobe Stylist ("Veste")

> Updated: this session (wardrobe + image→attributes pipeline). Read this and
> `ARCHITECTURE.md` before touching anything.

## What this session shipped

The base was the `mobile-wardrobe-stylist-design` drop (Next.js app shell,
outfit engine, capsule closet, full design system). On top of it:

1. **Finalised `ClothingItem` model** (`src/db/schema.ts`) — additive columns only,
   engine-compatible: `material`, `fit`, `seasons[]`, `notes`, `imageRef`
   (original upload key), `cutoutUrl` (bg-removed WebP), `imageHash`
   (sha-256, vision cache key), `visionStatus`
   (`none|vision|cache|fallback|manual`), `visionMeta` (raw confidence).
   `colors[]` = `[primary, secondary]`; `timesWorn` = wearCount; `occasions[]` =
   occasionTags — kept those names so the outfit engine keeps working untouched.
2. **Add-clothing flow** (`/add`): live camera viewfinder + library upload +
   manual entry → **on-device compression to ~200 KB** (canvas quality ladder,
   `src/lib/imaging.ts`) + on-device dominant-colour hints →
   `POST /api/wardrobe/extract` (stores original, content-hash cache, vision
   service if configured, heuristic fallback otherwise) → **bottom-sheet review
   where every detected field is editable** (`DraftFields`) → save +
   **rapid multi-add loop** (saved-name ticker, camera restarts).
3. **`/services/vision`** — FastAPI: rembg background removal with
   **`u2net` explicitly** (never bria-rmbg) + FashionCLIP zero-shot
   (category → subcategory, colours, pattern, formality, season, material) +
   disk cache keyed by sha-256. `POST /extract`, `GET /health`. Dockerfile
   pre-downloads only the permitted weights.
4. **Wardrobe UI**: grid/browse + search + **filters (category, colour, season,
   favourites)** in a filter sheet, full **edit mode** in the item sheet
   (shared `DraftFields`), **delete** (2-tap confirm), **favourite toggle**,
   mark-worn. Cut-outs render `object-contain` on the paper tint.
5. **Storage provider interface** (`src/lib/storage.ts`): local disk
   (`.data/uploads` via `/api/media/*`) by default; Supabase Storage the moment
   `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` (+ optional bucket) are set.
   Same keys either way.
6. **PWA**: real icons generated, service worker now runtime-caches
   `/api/media/*` so wardrobe photos/cut-outs browse offline.
7. **Docs**: this file + new `ARCHITECTURE.md` (interfaces were created this
   session — none existed in the drop).

## Verification evidence (all green this session)

- `npx vitest run` → **26/26** (attribute mapping incl. culori palette
  round-trips, cache-key hashing, response contract guard, storage sanitising)
- `python3 -m unittest discover -s services/vision/tests -v` → **15/15**
  (score folding, season/material mapping, cache round-trip "same bytes, same
  key", atomic writes)
- `npx next typegen` ✓ · `tsc --noEmit` ✓ · `next build` ✓ · platform
  healthcheck ✓
- **Real image e2e (phone-style multipart)**: `public/images/e2e-sample-shirt.png`
  → `POST /api/wardrobe/extract` → `cache:"miss"`, colours `["rust","ivory"]`
  mapped via culori; **second identical upload → `cache:"hit"`** (never
  processed twice); `POST /api/wardrobe/items` → real row
  `vision_status=cache`; `GET /api/media/<hash>.png` → HTTP 200.

## How to run

```bash
# web
npm run dev                 # or build+start; DB: DATABASE_URL, npx drizzle-kit push
npx vitest run              # web unit tests
# vision service (optional — web falls back gracefully without it)
cd services/vision && pip install -r requirements.txt
uvicorn app.main:app --port 8100
python3 -m unittest discover -s tests -v
```

Env: `DATABASE_URL` (required) · `VISION_SERVICE_URL` (optional → vision
provider) · `SUPABASE_URL`/`SUPABASE_SERVICE_ROLE_KEY`/`SUPABASE_STORAGE_BUCKET`
(optional → Supabase Storage) · `UPLOAD_DIR` (optional override).

## Conscious decisions / deviations (say so, per workflow)

- **Monorepo layout**: the preview sandbox pins the Next app to the repo root;
  root = `apps/web` role. `packages/shared` and `services/vision` exist at root
  as specked. Engine logic untouched.
- **Prisma vs Drizzle**: stack allows either — Drizzle kept (pre-existing).
- **TanStack Query / Zustand / react-hook-form**: intentionally not wired — the
  shipped architecture is server-components + actions + zod-validated API
  routes; adding them now would violate "do not over-engineer". Revisit when
  offline mutation queues land.
- **Supabase Auth**: single profile (`profiles.id = 1`) preserved from the base;
  storage/auth sit behind env-gated providers.
- **No HANDOFF/ARCHITECTURE existed in the drop** — both authored here.

## Licence posture

MIT/Apache-2.0 only. rembg = **u2net only** (bria-rmbg never referenced).
FashionCLIP + CLIP weights MIT (audit table in `services/vision/README.md`).
Open-Meteo stays behind `src/lib/weather.ts`'s provider boundary (its free tier
is non-commercial). No Libre-Closet/MinIO/digidrobe code. No paid AI:
without `VISION_SERVICE_URL` the app silently uses on-device heuristics and
every auto field remains editable.

## Next up (recommended order)

1. Deploy `services/vision` (Dockerfile ready) and set `VISION_SERVICE_URL` —
   first u2net run downloads weights (~170 MB), then cut-outs flow into
   `/wardrobe` tiles automatically.
2. Wire POST /api/wardrobe/items' `visionMeta.confidence` into the item sheet
   (field-level "auto" badges — UI already supports it in DraftFields).
3. Fix crops larger than 8 MB on the extract route (currently 413s; phones
   compress client-side so this only affects raw API callers).
4. Offline mutation queue (add/edit while offline → sync), then TanStack
   Query becomes worth its bytes.
5. Auth (Supabase) to turn the single profile into accounts; storage provider
   is already shaped for it.
