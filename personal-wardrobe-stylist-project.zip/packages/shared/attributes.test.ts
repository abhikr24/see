/** Unit tests for the attribute mapping — the heart of the vision contract. */
import { describe, expect, it } from "vitest";
import {
  aboveThreshold,
  fallbackAttributes,
  nearestPaletteId,
  nearestPaletteIds,
  normalizeMaterial,
  PALETTE_HEX,
  scoresToAttributes,
  seasonsFromLabelScores,
  seasonsFromWarmth,
  topScore,
  warmthFromSeasons,
} from "./attributes";
import type { LabelScore } from "./vision";

describe("nearestPaletteId (culori OKLab mapping)", () => {
  it("maps obvious colours to their palette family", () => {
    expect(nearestPaletteId("#000000")).toBe("black");
    expect(nearestPaletteId("#ffffff")).toBe("white");
    expect(nearestPaletteId("#2b3a55")).toBe("navy"); // dark blue
    expect(nearestPaletteId("#A9542E")).toBe("rust"); // exact rust
  });

  it("round-trips every palette hex to its own id", () => {
    for (const [id, hex] of Object.entries(PALETTE_HEX)) {
      expect(nearestPaletteId(hex)).toBe(id);
    }
  });

  it("handles 3-digit and uppercase hex", () => {
    expect(nearestPaletteId("#FFF")).toBe("white");
    expect(nearestPaletteId("#1D1A16")).toBe("black");
  });

  it("falls back to stone for unparseable input", () => {
    expect(nearestPaletteId("not-a-colour")).toBe("stone");
  });
});

describe("nearestPaletteIds", () => {
  it("de-dupes and caps the list", () => {
    const ids = nearestPaletteIds(["#000000", "#111111", "#ffffff"], 2);
    expect(ids).toHaveLength(2);
    expect(new Set(ids).size).toBe(ids.length);
    expect(ids[0]).toBe("black");
  });
});

describe("season ↔ warmth derivations", () => {
  it("maps warmth buckets to seasons", () => {
    expect(seasonsFromWarmth(0)).toEqual(["spring", "summer"]);
    expect(seasonsFromWarmth(2)).toEqual(["autumn", "winter"]);
    expect(seasonsFromWarmth(1)).toHaveLength(4);
  });

  it("maps season sets back to warmth", () => {
    expect(warmthFromSeasons(["summer"])).toBe(0);
    expect(warmthFromSeasons(["winter"])).toBe(2);
    expect(warmthFromSeasons(["spring", "autumn"])).toBe(1);
    expect(warmthFromSeasons(["summer", "winter"])).toBe(1);
  });

  it("wins by highest season label score", () => {
    const s = (label: string, score: number): LabelScore => ({ label, score });
    expect(seasonsFromLabelScores([s("summer", 0.7), s("winter", 0.2), s("mid", 0.1)]).warmth).toBe(0);
    expect(seasonsFromLabelScores([s("winter", 0.62)]).seasons).toEqual(["autumn", "winter"]);
    expect(seasonsFromLabelScores([]).seasons).toHaveLength(4);
  });
});

describe("score helpers", () => {
  const scores: LabelScore[] = [
    { label: "a", score: 0.1 },
    { label: "b", score: 0.6 },
    { label: "c", score: 0.3 },
  ];

  it("topScore picks the argmax", () => {
    expect(topScore(scores)?.label).toBe("b");
    expect(topScore([])).toBeNull();
  });

  it("aboveThreshold sorts, filters and caps", () => {
    expect(aboveThreshold(scores, 0.2).map((s) => s.label)).toEqual(["b", "c"]);
    expect(aboveThreshold(scores, 0.2, 1).map((s) => s.label)).toEqual(["b"]);
    expect(aboveThreshold(scores, 0.9)).toEqual([]);
  });
});

describe("scoresToAttributes (FashionCLIP scores → typed attributes)", () => {
  const fixture = {
    category: [
      { label: "top", score: 0.71 },
      { label: "bottom", score: 0.12 },
    ],
    subcategory: [
      { label: "knit sweater", score: 0.55 },
      { label: "t-shirt", score: 0.2 },
    ],
    colour: [
      { label: "cream ivory", score: 0.5 },
      { label: "brown", score: 0.2 },
      { label: "pink", score: 0.02 }, // below threshold — dropped
    ],
    pattern: [
      { label: "solid plain", score: 0.8 },
      { label: "striped", score: 0.1 },
    ],
    formality: [
      { label: "0", score: 0.2 },
      { label: "1", score: 0.7 },
    ],
    season: [
      { label: "winter", score: 0.66 },
      { label: "summer", score: 0.1 },
      { label: "mid", score: 0.24 },
    ],
    material: [
      { label: "knitted wool", score: 0.4 },
      { label: "polyester", score: 0.2 },
    ],
  };

  it("folds the fixture into the contract shape", () => {
    const a = scoresToAttributes(fixture);
    expect(a.category).toBe("top");
    expect(a.subcategory).toBe("knit");
    expect(a.colors).toEqual(["ivory", "chocolate"]); // label→palette map, threshold applied
    expect(a.pattern).toBe("solid");
    expect(a.formality).toBe(1);
    expect(a.warmth).toBe(2);
    expect(a.seasons).toEqual(["autumn", "winter"]);
    expect(a.material).toBe("knit");
    expect(a.fit).toBe("regular"); // honest default — not reliably detectable
    expect(a.confidence.category).toBeCloseTo(0.71, 2);
    expect(a.confidence.color).toBeCloseTo(0.5, 2);
  });

  it("maps every colour label through the palette table", () => {
    const a = scoresToAttributes({
      ...fixture,
      colour: [{ label: "denim blue", score: 0.9 }],
    });
    expect(a.colors[0]).toBe("denim");
  });

  it("drops low-confidence material and defaults category safely", () => {
    const a = scoresToAttributes({
      ...fixture,
      category: [],
      material: [{ label: "leather", score: 0.1 }],
    });
    expect(a.category).toBe("top");
    expect(a.material).toBe("");
  });

  it("clamps unknown formality labels to casual", () => {
    const a = scoresToAttributes({
      ...fixture,
      formality: [{ label: "9", score: 1 }],
    });
    expect(a.formality).toBe(0);
  });
});

describe("normalizeMaterial", () => {
  it("canonicalises FashionCLIP phrases", () => {
    expect(normalizeMaterial("cotton jersey")).toBe("cotton");
    expect(normalizeMaterial("knitted wool")).toBe("knit");
    expect(normalizeMaterial("quilted nylon")).toBe("synthetic");
    expect(normalizeMaterial("mesh fabric")).toBe("mesh");
    expect(normalizeMaterial("wool")).toBe("wool");
    expect(normalizeMaterial("something alien")).toBe("");
  });
});

describe("fallbackAttributes (offline path, no paid AI)", () => {
  it("maps on-device hex hints to palette ids", () => {
    const a = fallbackAttributes({ paletteHexes: ["#26334C"], category: "bottom" });
    expect(a.colors[0]).toBe("navy");
    expect(a.category).toBe("bottom");
    expect(a.subcategory).toBe("trousers");
  });

  it("always returns a complete editable object", () => {
    const a = fallbackAttributes({ paletteHexes: [] });
    expect(a.colors.length).toBeGreaterThan(0);
    expect(a.seasons).toHaveLength(4);
    expect(a.pattern).toBe("solid");
    expect(a.confidence).toEqual({}); // nothing auto-claimed offline
  });
});
