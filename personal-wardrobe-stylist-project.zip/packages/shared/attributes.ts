/**
 * Pure attribute-mapping logic shared by the web app and mirrored by the
 * vision service. No I/O, no framework imports — safe to unit-test anywhere.
 * Colour maths uses culori (MIT) with OKLab perceptual distance.
 */
import { converter, differenceEuclidean } from "culori";
import {
  ALL_SEASONS,
  COLOUR_LABEL_TO_PALETTE,
  SUBCATEGORY_PHRASE_TO_KEY,
  type LabelScore,
  type Pattern,
  type Season,
  type VisionAttributes,
} from "./vision";

const toOklab = converter("oklab");
const delta = differenceEuclidean("oklab");

/** App palette — duplicated as plain data so this package stays import-light. */
export const PALETTE_HEX: Record<string, string> = {
  black: "#1D1A16", charcoal: "#3B3833", slate: "#716E67", stone: "#B3AFA2",
  ivory: "#EFE9DC", white: "#FAFAF7", navy: "#26334C", denim: "#54708F",
  sky: "#A9C3D6", steel: "#6C7F8E", forest: "#33483B", olive: "#6E7053",
  sage: "#ABB49C", camel: "#B8875A", tan: "#C9A579", chocolate: "#5C4433",
  rust: "#A9542E", mustard: "#C99A36", blush: "#E2C0B2", lavender: "#B3A6C9",
  burgundy: "#6E2C38", crimson: "#9E2B38",
};

/** Perceptually nearest palette id for a hex colour (OKLab euclidean). */
export function nearestPaletteId(hex: string): string {
  const target = toOklab(hex);
  if (!target) return "stone";
  let best = "stone";
  let bestDist = Infinity;
  for (const [id, h] of Object.entries(PALETTE_HEX)) {
    const c = toOklab(h);
    if (!c) continue;
    const d = delta(target, c);
    if (d < bestDist) {
      bestDist = d;
      best = id;
    }
  }
  return best;
}

/** Map a list of observed hex colours to unique palette ids (primary first). */
export function nearestPaletteIds(hexes: string[], max = 2): string[] {
  const out: string[] = [];
  for (const hex of hexes) {
    const id = nearestPaletteId(hex);
    if (!out.includes(id)) out.push(id);
    if (out.length >= max) break;
  }
  return out;
}

/** Winner takes all; returns null when scores are empty. */
export function topScore(scores: LabelScore[]): LabelScore | null {
  if (!scores.length) return null;
  return scores.reduce((a, b) => (b.score > a.score ? b : a));
}

/** Labels whose score clears `threshold`, best first, capped at `max`. */
export function aboveThreshold(scores: LabelScore[], threshold: number, max = 4): LabelScore[] {
  return [...scores]
    .sort((a, b) => b.score - a.score)
    .filter((s) => s.score >= threshold)
    .slice(0, max);
}

/* ------------------------------------------------------------------ seasons */

export function seasonsFromWarmth(warmth: 0 | 1 | 2): Season[] {
  if (warmth === 0) return ["spring", "summer"];
  if (warmth === 2) return ["autumn", "winter"];
  return [...ALL_SEASONS];
}

export function warmthFromSeasons(seasons: Season[]): 0 | 1 | 2 {
  const s = new Set(seasons);
  const hot = s.has("summer");
  const cold = s.has("winter");
  if (hot && cold) return 1;
  if (cold && !hot) return 2;
  if (hot && !cold) return 0;
  return 1;
}

/** FashionCLIP season triplet (summer / winter / mid) → warmth + seasons list. */
export function seasonsFromLabelScores(scores: LabelScore[]): {
  warmth: 0 | 1 | 2;
  seasons: Season[];
} {
  const win = topScore(scores);
  if (!win) return { warmth: 1, seasons: [...ALL_SEASONS] };
  if (win.label === "summer") return { warmth: 0, seasons: ["spring", "summer"] };
  if (win.label === "winter") return { warmth: 2, seasons: ["autumn", "winter"] };
  return { warmth: 1, seasons: [...ALL_SEASONS] };
}

/* ------------------------------------------------- label scores → attributes */

const DEFAULT_BY_CATEGORY: Record<string, { subcategory: string; material: string }> = {
  top: { subcategory: "tshirt", material: "" },
  bottom: { subcategory: "trousers", material: "" },
  footwear: { subcategory: "sneakers", material: "" },
  outerwear: { subcategory: "jacket", material: "" },
  accessory: { subcategory: "cap", material: "" },
};

export function isPattern(v: string): v is Pattern {
  return ["solid", "striped", "checked", "floral", "graphic", "dotted", "camo"].includes(v);
}

/** Canonical material vocabulary used by the review sheet. */
export const MATERIALS = [
  "cotton",
  "linen",
  "silk",
  "wool",
  "denim",
  "leather",
  "knit",
  "canvas",
  "suede",
  "fleece",
  "corduroy",
  "synthetic",
  "mesh",
  "rubber",
  "metal",
] as const;

/** Map FashionCLIP's descriptive material phrases to the canonical list. */
export function normalizeMaterial(phrase: string): string {
  const p = phrase.toLowerCase();
  const table: [RegExp, string][] = [
    [/cotton jersey/, "cotton"],
    [/knitted wool|knit/, "knit"],
    [/cotton twill|cotton/, "cotton"],
    [/quilted nylon|polyester|nylon/, "synthetic"],
    [/woven fabric|canvas/, "canvas"],
    [/mesh/, "mesh"],
    [/denim/, "denim"],
    [/leather/, "leather"],
    [/suede/, "suede"],
    [/fleece/, "fleece"],
    [/corduroy/, "corduroy"],
    [/linen/, "linen"],
    [/silk/, "silk"],
    [/wool/, "wool"],
    [/rubber/, "rubber"],
    [/metal/, "metal"],
  ];
  for (const [re, canonical] of table) if (re.test(p)) return canonical;
  return "";
}

const PATTERN_LABEL_TO_KEY: Record<string, Pattern> = {
  "solid plain": "solid",
  striped: "striped",
  "checked plaid": "checked",
  floral: "floral",
  "graphic print": "graphic",
  "polka dot": "dotted",
  camouflage: "camo",
};

/**
 * Fold raw zero-shot label scores into the typed attribute object.
 * Same algorithm as services/vision/app/mapping.py::scores_to_attributes.
 */
export function scoresToAttributes(input: {
  category: LabelScore[];
  subcategory: LabelScore[];
  colour: LabelScore[];
  pattern: LabelScore[];
  formality: LabelScore[]; // labels "0" | "1" | "2"
  season: LabelScore[]; // labels "summer" | "winter" | "mid"
  material: LabelScore[];
}): VisionAttributes {
  const cat = topScore(input.category);
  const category = cat?.label ?? "top";
  const defaults = DEFAULT_BY_CATEGORY[category] ?? DEFAULT_BY_CATEGORY.top;

  const sub = topScore(input.subcategory);
  const subcategory = sub ? (SUBCATEGORY_PHRASE_TO_KEY[sub.label] ?? defaults.subcategory) : defaults.subcategory;

  const colourIds: string[] = [];
  for (const s of aboveThreshold(input.colour, 0.08, 3)) {
    const id = COLOUR_LABEL_TO_PALETTE[s.label.toLowerCase()];
    if (id && !colourIds.includes(id)) colourIds.push(id);
    if (colourIds.length >= 2) break;
  }
  if (!colourIds.length) colourIds.push("stone");

  const pat = topScore(input.pattern);
  const pattern: Pattern = pat ? (PATTERN_LABEL_TO_KEY[pat.label] ?? "solid") : "solid";

  const form = topScore(input.formality);
  const formalityNum = form ? Number(form.label) : 0;
  const formality = (formalityNum === 2 ? 2 : formalityNum === 1 ? 1 : 0) as 0 | 1 | 2;

  const { warmth, seasons } = seasonsFromLabelScores(input.season);

  const mat = topScore(input.material);
  const material = mat && mat.score >= 0.3 ? normalizeMaterial(mat.label) : "";

  const confidence: VisionAttributes["confidence"] = {};
  if (cat) confidence.category = round2(cat.score);
  const colWin = topScore(input.colour);
  if (colWin) confidence.color = round2(colWin.score);
  if (pat) confidence.pattern = round2(pat.score);
  if (form) confidence.formality = round2(form.score);
  const seaWin = topScore(input.season);
  if (seaWin) confidence.season = round2(seaWin.score);

  return {
    category,
    subcategory,
    colors: colourIds,
    pattern,
    formality,
    warmth,
    seasons,
    material,
    fit: "regular",
    confidence,
  };
}

/**
 * Offline fallback: build attributes purely from on-device hints.
 * Used when services/vision is unreachable — no paid AI involved ever.
 * Category is caller-provided (chip default in UI); colours come from
 * canvas sampling; everything else stays editable.
 */
export function fallbackAttributes(input: {
  paletteHexes: string[];
  category?: string;
  subcategory?: string;
}): VisionAttributes {
  const colors = nearestPaletteIds(input.paletteHexes, 2);
  const category = input.category ?? "top";
  const defaults = DEFAULT_BY_CATEGORY[category] ?? DEFAULT_BY_CATEGORY.top;
  return {
    category,
    subcategory: input.subcategory ?? defaults.subcategory,
    colors: colors.length ? colors : ["stone"],
    pattern: "solid",
    formality: 0,
    warmth: 1,
    seasons: [...ALL_SEASONS],
    material: "",
    fit: "regular",
    confidence: {},
  };
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
