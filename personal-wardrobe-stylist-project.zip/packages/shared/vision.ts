/**
 * Shared contract between apps/web and services/vision.
 * These types are mirrored 1:1 in services/vision/app/mapping.py — keep both
 * sides in sync. Only MIT / Apache-2.0 components on the vision side
 * (rembg + u2net weights, FashionCLIP). Do NOT rename fields without
 * updating ARCHITECTURE.md.
 */

export type Season = "spring" | "summer" | "autumn" | "winter";
export const ALL_SEASONS: Season[] = ["spring", "summer", "autumn", "winter"];

export type Fit = "slim" | "regular" | "relaxed" | "oversized";
export const FITS: Fit[] = ["slim", "regular", "relaxed", "oversized"];

export type Pattern =
  | "solid"
  | "striped"
  | "checked"
  | "floral"
  | "graphic"
  | "dotted"
  | "camo";
export const PATTERNS: Pattern[] = [
  "solid",
  "striped",
  "checked",
  "floral",
  "graphic",
  "dotted",
  "camo",
];

/** A zero-shot candidate label with its CLIP score (softmax-normalised 0..1). */
export type LabelScore = { label: string; score: number };

/** Attributes the vision pipeline can populate. Every field stays user-editable. */
export type VisionAttributes = {
  /** top | bottom | footwear | outerwear | accessory */
  category: string;
  subcategory: string;
  /** Palette ids (from apps/web palette), index 0 = primary, 1 = secondary. */
  colors: string[];
  pattern: Pattern;
  /** 0 casual · 1 smart · 2 formal */
  formality: 0 | 1 | 2;
  /** 0 light · 1 mid · 2 warm — kept in sync with `seasons`. */
  warmth: 0 | 1 | 2;
  seasons: Season[];
  /** Best-effort free-text (e.g. "denim", "knit"); "" when not confidently detected. */
  material: string;
  fit: Fit;
  /** Per-attribute winning score, surfaced in the UI as "auto" confidence. */
  confidence: Partial<Record<"category" | "color" | "pattern" | "formality" | "season", number>>;
};

/** Successful payload of POST /extract (services/vision) and /api/wardrobe/extract. */
export type ExtractResponse = {
  ok: boolean;
  /** "miss" = freshly computed, "hit" = served from cache (never processed twice). */
  cache: "hit" | "miss";
  /** "vision" = FashionCLIP service, "fallback" = on-device/web heuristics. */
  provider: "vision" | "fallback";
  hash: string; // sha-256 of source bytes
  attributes: VisionAttributes;
  /** Background-removed cut-out. base64 WebP across the wire, stored as a file server-side. */
  cutoutWebpB64: string | null;
  models: { segmenter: "u2net"; classifier: "fashion-clip" | "none" };
  error?: string;
};

/** Candidate label sets used for zero-shot scoring — mirrored by the Python service. */
export const CANDIDATE_LABELS = {
  category: [
    { label: "top", phrase: "a photo of a shirt, t-shirt, blouse, sweater or other upper-body garment" },
    { label: "bottom", phrase: "a photo of trousers, jeans, shorts, a skirt or other lower-body garment" },
    { label: "footwear", phrase: "a photo of a shoe, sneaker, boot, sandal or other footwear" },
    { label: "outerwear", phrase: "a photo of a jacket, coat, blazer or other outerwear garment" },
    { label: "accessory", phrase: "a photo of a fashion accessory such as a bag, belt, hat, scarf or watch" },
  ],
  subcategory: {
    top: ["t-shirt", "button-up shirt", "polo shirt", "blouse", "knit sweater", "turtleneck", "hoodie", "tank top", "cardigan"],
    bottom: ["jeans", "tailored trousers", "chinos", "shorts", "skirt"],
    footwear: ["sneakers", "boots", "loafers", "high heels", "sandals"],
    outerwear: ["casual jacket", "blazer", "winter coat"],
    accessory: ["wristwatch", "belt", "scarf", "handbag", "baseball cap", "beanie", "sunglasses", "necklace"],
  } as Record<string, string[]>,
  colour: [
    "black", "grey", "white", "navy blue", "light blue", "denim blue",
    "dark green", "olive green", "sage green", "brown", "tan beige", "camel brown",
    "rust orange", "mustard yellow", "burgundy red", "red", "pink", "purple", "cream ivory",
  ],
  pattern: ["solid plain", "striped", "checked plaid", "floral", "graphic print", "polka dot", "camouflage"],
  formality: [
    { label: 0, phrase: "casual relaxed everyday clothing" },
    { label: 1, phrase: "smart casual polished clothing" },
    { label: 2, phrase: "formal elegant dressy clothing" },
  ],
  season: [
    { label: "summer", phrase: "lightweight summer clothing for hot weather" },
    { label: "winter", phrase: "warm heavy winter clothing for cold weather" },
    { label: "mid", phrase: "mid-weight clothing for spring or autumn" },
  ],
  material: {
    top: ["cotton jersey", "linen", "silk", "knitted wool", "polyester", "denim"],
    bottom: ["denim", "cotton twill", "wool", "linen", "corduroy"],
    footwear: ["leather", "canvas", "suede", "mesh fabric", "rubber"],
    outerwear: ["wool", "denim", "leather", "quilted nylon", "fleece"],
    accessory: ["leather", "metal", "canvas", "woven fabric"],
  } as Record<string, string[]>,
} as const;

/** Map free-text FashionCLIP colour labels onto the app's curated palette ids. */
export const COLOUR_LABEL_TO_PALETTE: Record<string, string> = {
  black: "black",
  grey: "slate",
  white: "white",
  "navy blue": "navy",
  "light blue": "sky",
  "denim blue": "denim",
  "dark green": "forest",
  "olive green": "olive",
  "sage green": "sage",
  brown: "chocolate",
  "tan beige": "tan",
  "camel brown": "camel",
  "rust orange": "rust",
  "mustard yellow": "mustard",
  "burgundy red": "burgundy",
  red: "crimson",
  pink: "blush",
  purple: "lavender",
  "cream ivory": "ivory",
};

/** FashionCLIP subcategory phrases → app subcategory keys (presets.ts). */
export const SUBCATEGORY_PHRASE_TO_KEY: Record<string, string> = {
  "t-shirt": "tshirt",
  "button-up shirt": "shirt",
  "polo shirt": "polo",
  blouse: "blouse",
  "knit sweater": "knit",
  turtleneck: "turtleneck",
  hoodie: "hoodie",
  "tank top": "tank",
  cardigan: "cardigan",
  jeans: "jeans",
  "tailored trousers": "trousers",
  chinos: "chinos",
  shorts: "shorts",
  skirt: "skirt",
  sneakers: "sneakers",
  boots: "boots",
  loafers: "loafers",
  "high heels": "heels",
  sandals: "sandals",
  "casual jacket": "jacket",
  blazer: "blazer",
  "winter coat": "coat",
  wristwatch: "watch",
  belt: "belt",
  scarf: "scarf",
  handbag: "bag",
  "baseball cap": "cap",
  beanie: "beanie",
  sunglasses: "sunglasses",
  necklace: "necklace",
};
