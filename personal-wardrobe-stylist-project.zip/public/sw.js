/* Veste service worker — app-shell caching with a graceful offline fallback. */
const CACHE = "veste-v2";
const OFFLINE_HTML = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>
body{margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#f5f1e8;color:#191510;font-family:Georgia,serif;text-align:center;padding:24px}
h1{font-weight:500;font-size:28px;margin:0 0 8px}p{font-family:system-ui;font-size:14px;color:#7d7666;max-width:280px;line-height:1.6}</style></head>
<body><h1>Veste is offline</h1><p>Your stylist will be back the moment you reconnect. Pull down to try again.</p></body></html>`;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) =>
      cache.addAll(["/icons/icon-192.png", "/icons/icon-512.png", "/images/onboarding.jpg"]).catch(() => undefined),
    ),
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))),
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  // Wardrobe photos & cut-outs: cache-first so the closet browses offline
  if (url.pathname.startsWith("/api/media/")) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ??
          fetch(req).then((res) => {
            if (res.ok) {
              const copy = res.clone();
              caches.open(CACHE).then((c) => c.put(req, copy));
            }
            return res;
          }),
      ),
    );
    return;
  }

  if (url.pathname.startsWith("/api")) return;

  // Static assets: cache-first
  if (url.pathname.startsWith("/icons/") || url.pathname.startsWith("/images/") || url.pathname.startsWith("/_next/static/")) {
    event.respondWith(
      caches.match(req).then(
        (hit) =>
          hit ??
          fetch(req).then((res) => {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
            return res;
          }),
      ),
    );
    return;
  }

  // Pages: network-first, fall back to cache, then offline card
  event.respondWith(
    fetch(req)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy));
        return res;
      })
      .catch(async () => {
        const hit = await caches.match(req);
        if (hit) return hit;
        if (req.mode === "navigate") {
          return new Response(OFFLINE_HTML, { headers: { "Content-Type": "text/html" } });
        }
        return new Response("", { status: 408 });
      }),
  );
});
