# veste-vision

Image → wardrobe attributes. MIT/Apache-2.0 stack only. No paid AI anywhere.

## What it does

`POST /extract` (multipart `image`) →

1. **Background removal** — `rembg` with the **`u2net` model explicitly**
   (`new_session("u2net")`). The rembg default `bria-rmbg` is never used
   (different licence family; do not switch).
2. **Attribute extraction** — FashionCLIP zero-shot, run **on the cut-out**:
   category → subcategory, colour(s), pattern, formality, season, material,
   each scored with candidate-label softmax, then folded through
   `app/mapping.py` into the shared attribute contract.
3. **Caching** — payload is content-addressed (`sha256:<hex>`). The same image
   is *never* processed twice; cache hits return instantly.

Response shape (mirrors `packages/shared/vision.ts`):

```jsonc
{
  "ok": true,
  "cache": "miss",            // or "hit"
  "provider": "vision",
  "hash": "<sha256 hex>",
  "attributes": { "category": "…", "subcategory": "…", "colors": ["palette", "ids"],
                  "pattern": "…", "formality": 0, "warmth": 1, "seasons": ["…"],
                  "material": "…", "fit": "regular", "confidence": { "category": 0.71 } },
  "cutoutWebpB64": "<base64 webp cut-out>",
  "models": { "segmenter": "u2net", "classifier": "fashion-clip" }
}
```

`GET /health` returns the model configuration.

## Run it

```bash
pip install -r requirements.txt
uvicorn app.main:app --port 8100
# then on the web side:
#   VISION_SERVICE_URL=http://localhost:8100
```

or with Docker:

```bash
docker build -t veste-vision . && docker run -p 8100:8100 veste-vision
```

## Tests

Pure-logic tests (mapping + caching) need only the stdlib:

```bash
python3 -m unittest discover -s tests -v
```

## Licence audit

| component                | licence            | notes                                   |
| ------------------------ | ------------------ | --------------------------------------- |
| rembg                    | MIT                | background removal runtime              |
| U^2-Net weights (`u2net`)| Apache-2.0         | requested explicitly; `bria-rmbg` = NO  |
| fashion-clip (code)      | MIT                | zero-shot classifier                    |
| FashionCLIP weights      | MIT                | `patrickjohncyh/fashion-clip` on HF     |
| base CLIP ViT-B/32       | MIT                | OpenAI                                  |
| fastapi / uvicorn        | MIT / BSD-3        | service surface                         |
| pillow / numpy           | HPND / BSD-3       | imaging                                 |
| onnxruntime              | MIT                | u2net inference                         |

Rejected on licence grounds: bria-rmbg weights (non-commercial terms),
Libre-Closet / MinIO / digidrobe code (not consulted, not copied).
The FashionCLIP authors released code + weights as MIT; as with any
CLIP-family model, review your jurisdiction's stance on training-data
provenance before commercial redistribution of the weights.
