"""veste-vision: MIT-stack image→attributes service (rembg u2net + FashionCLIP)."""
