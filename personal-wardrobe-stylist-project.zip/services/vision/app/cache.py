"""Content-hash disk cache: the same image bytes are never processed twice.

Stdlib-only so unit tests need no ML stack. Payloads are written atomically
(tmp + rename) so a crashed write can never poison a cache entry.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

DEFAULT_CACHE_DIR = Path(os.environ.get("VISION_CACHE_DIR", "data/cache"))


def make_key(image_bytes: bytes) -> str:
    """sha-256 content address — matches src/lib/vision/client.ts on the web."""
    return "sha256:" + hashlib.sha256(image_bytes).hexdigest()


class DiskCache:
    def __init__(self, root: str | Path = DEFAULT_CACHE_DIR):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe = key.replace(":", "_")
        return self.root / f"{safe}.json"

    def get(self, key: str) -> dict[str, Any] | None:
        path = self._path(key)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None

    def put(self, key: str, payload: dict[str, Any]) -> Path:
        fd, tmp_name = tempfile.mkstemp(dir=self.root, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
            os.replace(tmp_name, self._path(key))
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
        return self._path(key)

    def has(self, key: str) -> bool:
        return self.get(key) is not None
