"""Candidate label sets for zero-shot FashionCLIP scoring.

MIRROR of packages/shared/vision.ts — keep both sides in sync.
Only permissive licences involved: FashionCLIP code+weights MIT,
base CLIP (OpenAI) MIT, rembg MIT with U^2-Net weights (Apache-2.0).
"""

# attribute → candidate phrases / labels
CATEGORY_PHRASES = {
    "top": "a photo of a shirt, t-shirt, blouse, sweater or other upper-body garment",
    "bottom": "a photo of trousers, jeans, shorts, a skirt or other lower-body garment",
    "footwear": "a photo of a shoe, sneaker, boot, sandal or other footwear",
    "outerwear": "a photo of a jacket, coat, blazer or other outerwear garment",
    "accessory": "a photo of a fashion accessory such as a bag, belt, hat, scarf or watch",
}

SUBCATEGORY_PHRASES = {
    "top": [
        "t-shirt", "button-up shirt", "polo shirt", "blouse", "knit sweater",
        "turtleneck", "hoodie", "tank top", "cardigan",
    ],
    "bottom": ["jeans", "tailored trousers", "chinos", "shorts", "skirt"],
    "footwear": ["sneakers", "boots", "loafers", "high heels", "sandals"],
    "outerwear": ["casual jacket", "blazer", "winter coat"],
    "accessory": [
        "wristwatch", "belt", "scarf", "handbag", "baseball cap",
        "beanie", "sunglasses", "necklace",
    ],
}

COLOUR_LABELS = [
    "black", "grey", "white", "navy blue", "light blue", "denim blue",
    "dark green", "olive green", "sage green", "brown", "tan beige", "camel brown",
    "rust orange", "mustard yellow", "burgundy red", "red", "pink", "purple", "cream ivory",
]

PATTERN_LABELS = [
    "solid plain", "striped", "checked plaid", "floral",
    "graphic print", "polka dot", "camouflage",
]

FORMALITY_PHRASES = {
    "0": "casual relaxed everyday clothing",
    "1": "smart casual polished clothing",
    "2": "formal elegant dressy clothing",
}

SEASON_PHRASES = {
    "summer": "lightweight summer clothing for hot weather",
    "winter": "warm heavy winter clothing for cold weather",
    "mid": "mid-weight clothing for spring or autumn",
}

MATERIAL_PHRASES = {
    "top": ["cotton jersey", "linen", "silk", "knitted wool", "polyester", "denim"],
    "bottom": ["denim", "cotton twill", "wool", "linen", "corduroy"],
    "footwear": ["leather", "canvas", "suede", "mesh fabric", "rubber"],
    "outerwear": ["wool", "denim", "leather", "quilted nylon", "fleece"],
    "accessory": ["leather", "metal", "canvas", "woven fabric"],
}

# label/phrase → app taxonomy
COLOUR_LABEL_TO_PALETTE = {
    "black": "black", "grey": "slate", "white": "white", "navy blue": "navy",
    "light blue": "sky", "denim blue": "denim", "dark green": "forest",
    "olive green": "olive", "sage green": "sage", "brown": "chocolate",
    "tan beige": "tan", "camel brown": "camel", "rust orange": "rust",
    "mustard yellow": "mustard", "burgundy red": "burgundy", "red": "crimson",
    "pink": "blush", "purple": "lavender", "cream ivory": "ivory",
}

SUBCATEGORY_PHRASE_TO_KEY = {
    "t-shirt": "tshirt", "button-up shirt": "shirt", "polo shirt": "polo",
    "blouse": "blouse", "knit sweater": "knit", "turtleneck": "turtleneck",
    "hoodie": "hoodie", "tank top": "tank", "cardigan": "cardigan",
    "jeans": "jeans", "tailored trousers": "trousers", "chinos": "chinos",
    "shorts": "shorts", "skirt": "skirt", "sneakers": "sneakers", "boots": "boots",
    "loafers": "loafers", "high heels": "heels", "sandals": "sandals",
    "casual jacket": "jacket", "blazer": "blazer", "winter coat": "coat",
    "wristwatch": "watch", "belt": "belt", "scarf": "scarf", "handbag": "bag",
    "baseball cap": "cap", "beanie": "beanie", "sunglasses": "sunglasses",
    "necklace": "necklace",
}

PATTERN_LABEL_TO_KEY = {
    "solid plain": "solid", "striped": "striped", "checked plaid": "checked",
    "floral": "floral", "graphic print": "graphic", "polka dot": "dotted",
    "camouflage": "camo",
}
