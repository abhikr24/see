"""veste-vision — FastAPI surface.

    GET  /health                   → liveness + which models are configured
    POST /extract (multipart)      → typed attributes + u2net cut-out, cached
                                     by content hash (same image is never
                                     processed twice)

Contract mirrors packages/shared/vision.ts (ExtractResponse).
"""
from __future__ import annotations

import os

from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse

from .cache import DiskCache, make_key
from .mapping import scores_to_attributes  # noqa: F401  (re-exported contract)
from .pipeline import run_pipeline

MAX_BYTES = 12 * 1024 * 1024
CACHE = DiskCache(os.environ.get("VISION_CACHE_DIR", "data/cache"))

app = FastAPI(title="veste-vision", version="1.0.0")


@app.get("/health")
def health() -> dict:
    return {
        "ok": True,
        "service": "veste-vision",
        "models": {"segmenter": "u2net", "classifier": "fashion-clip"},
        "cache_dir": str(CACHE.root),
    }


@app.post("/extract")
async def extract(image: UploadFile = File(...)) -> JSONResponse:
    if not (image.content_type or "").startswith("image/"):
        return JSONResponse({"ok": False, "error": "Expected an image upload"}, status_code=415)

    data = await image.read()
    if not data:
        return JSONResponse({"ok": False, "error": "Empty upload"}, status_code=400)
    if len(data) > MAX_BYTES:
        return JSONResponse({"ok": False, "error": "Image exceeds 12 MB"}, status_code=413)

    key = make_key(data)
    hit = CACHE.get(key)
    if hit is not None:
        return JSONResponse({**hit, "cache": "hit"})

    try:
        result = run_pipeline(data)
    except Exception as exc:  # web app degrades to its offline fallback
        return JSONResponse({"ok": False, "error": f"pipeline failed: {exc.__class__.__name__}"}, status_code=502)

    payload = {
        "ok": True,
        "cache": "miss",
        "provider": "vision",
        "hash": key.split(":", 1)[1],
        "attributes": result["attributes"],
        "cutoutWebpB64": result["cutout_webp_b64"],
        "models": {"segmenter": "u2net", "classifier": "fashion-clip"},
    }
    CACHE.put(key, payload)
    return JSONResponse(payload)
