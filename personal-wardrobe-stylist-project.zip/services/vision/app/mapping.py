"""Pure attribute-mapping: raw zero-shot scores → typed attribute dict.

MIRROR of packages/shared/attributes.ts::scoresToAttributes. No heavy
imports here on purpose — this module is what the unit tests exercise.
"""
from __future__ import annotations

from .labels import (
    COLOUR_LABEL_TO_PALETTE,
    PATTERN_LABEL_TO_KEY,
    SUBCATEGORY_PHRASE_TO_KEY,
)

ALL_SEASONS = ["spring", "summer", "autumn", "winter"]

DEFAULT_BY_CATEGORY = {
    "top": {"subcategory": "tshirt"},
    "bottom": {"subcategory": "trousers"},
    "footwear": {"subcategory": "sneakers"},
    "outerwear": {"subcategory": "jacket"},
    "accessory": {"subcategory": "cap"},
}

MATERIAL_RULES = [
    ("cotton jersey", "cotton"),
    ("knitted wool", "knit"),
    ("cotton twill", "cotton"),
    ("cotton", "cotton"),
    ("quilted nylon", "synthetic"),
    ("polyester", "synthetic"),
    ("nylon", "synthetic"),
    ("woven fabric", "canvas"),
    ("canvas", "canvas"),
    ("mesh", "mesh"),
    ("denim", "denim"),
    ("leather", "leather"),
    ("suede", "suede"),
    ("fleece", "fleece"),
    ("corduroy", "corduroy"),
    ("linen", "linen"),
    ("silk", "silk"),
    ("knit", "knit"),
    ("wool", "wool"),
    ("rubber", "rubber"),
    ("metal", "metal"),
]


def top_score(scores: list[dict]) -> dict | None:
    """Winner takes all; None on empty input."""
    if not scores:
        return None
    return max(scores, key=lambda s: s.get("score", 0.0))


def above_threshold(scores: list[dict], threshold: float, cap: int = 4) -> list[dict]:
    out = sorted(scores, key=lambda s: s.get("score", 0.0), reverse=True)
    return [s for s in out if s.get("score", 0.0) >= threshold][:cap]


def seasons_from_label_scores(scores: list[dict]) -> tuple[int, list[str]]:
    """CLIP season triplet (summer / winter / mid) → (warmth, seasons)."""
    win = top_score(scores)
    if win is None:
        return 1, list(ALL_SEASONS)
    if win["label"] == "summer":
        return 0, ["spring", "summer"]
    if win["label"] == "winter":
        return 2, ["autumn", "winter"]
    return 1, list(ALL_SEASONS)


def normalize_material(phrase: str) -> str:
    """Map descriptive FashionCLIP phrases onto the canonical material list."""
    p = phrase.lower()
    for needle, canonical in MATERIAL_RULES:
        if needle in p:
            return canonical
    return ""


def _round2(x: float) -> float:
    return round(x + 1e-9, 2)


def scores_to_attributes(scores: dict[str, list[dict]]) -> dict:
    """Fold every attribute's label scores into the shared contract shape.

    Expected keys: category, subcategory, colour, pattern, formality
    (labels "0"|"1"|"2"), season (labels "summer"|"winter"|"mid"), material.
    """
    cat = top_score(scores.get("category", []))
    category = cat["label"] if cat else "top"
    defaults = DEFAULT_BY_CATEGORY.get(category, DEFAULT_BY_CATEGORY["top"])

    sub = top_score(scores.get("subcategory", []))
    subcategory = (
        SUBCATEGORY_PHRASE_TO_KEY.get(sub["label"], defaults["subcategory"])
        if sub
        else defaults["subcategory"]
    )

    colour_ids: list[str] = []
    for s in above_threshold(scores.get("colour", []), 0.08, 3):
        pid = COLOUR_LABEL_TO_PALETTE.get(str(s["label"]).lower())
        if pid and pid not in colour_ids:
            colour_ids.append(pid)
        if len(colour_ids) >= 2:
            break
    if not colour_ids:
        colour_ids = ["stone"]

    pat = top_score(scores.get("pattern", []))
    pattern = PATTERN_LABEL_TO_KEY.get(pat["label"], "solid") if pat else "solid"

    form = top_score(scores.get("formality", []))
    try:
        formality = int(form["label"]) if form else 0
    except (TypeError, ValueError):
        formality = 0
    formality = formality if formality in (0, 1, 2) else 0

    warmth, seasons = seasons_from_label_scores(scores.get("season", []))

    mat = top_score(scores.get("material", []))
    material = normalize_material(mat["label"]) if mat and mat.get("score", 0) >= 0.3 else ""

    confidence: dict[str, float] = {}
    if cat:
        confidence["category"] = _round2(cat["score"])
    col_win = top_score(scores.get("colour", []))
    if col_win:
        confidence["color"] = _round2(col_win["score"])
    if pat:
        confidence["pattern"] = _round2(pat["score"])
    if form:
        confidence["formality"] = _round2(form["score"])
    sea_win = top_score(scores.get("season", []))
    if sea_win:
        confidence["season"] = _round2(sea_win["score"])

    return {
        "category": category,
        "subcategory": subcategory,
        "colors": colour_ids,
        "pattern": pattern,
        "formality": formality,
        "warmth": warmth,
        "seasons": seasons,
        "material": material,
        "fit": "regular",  # fit is not reliably inferable — user picks it
        "confidence": confidence,
    }
