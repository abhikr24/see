"""The heavy pipeline: rembg (u2net ONLY — never the bria-rmbg default) for
background removal, then FashionCLIP zero-shot scoring over candidate labels.

Licence audit (all permissive — MIT / Apache-2.0):
  * rembg                      — MIT
  * U^2-Net weights (u2net)    — Apache-2.0 repo; we explicitly request them
  * fashion-clip package       — MIT
  * FashionCLIP weights        — MIT (patrickjohncyh/fashion-clip on HF)
  * base CLIP ViT-B/32 (OpenAI)— MIT

Heavy dependencies import lazily inside functions so that `mapping`/`cache`
(and their unit tests) import without torch/onnx installed.
"""
from __future__ import annotations

import base64
import io
import math
from typing import Any

from .labels import (
    CATEGORY_PHRASES,
    COLOUR_LABELS,
    FORMALITY_PHRASES,
    MATERIAL_PHRASES,
    PATTERN_LABELS,
    SEASON_PHRASES,
    SUBCATEGORY_PHRASES,
)
from .mapping import scores_to_attributes

SESSION = None
CLIP = None

# CLIP-style logit scale for calibrated zero-shot softmax
LOGIT_SCALE = 100.0


def _rembg_session():
    """Singleton u2net session — explicitly NEVER the default bria-rmbg."""
    global SESSION
    if SESSION is None:
        from rembg import new_session  # MIT

        SESSION = new_session("u2net")  # hard requirement, do not change
    return SESSION


def _fclip():
    global CLIP
    if CLIP is None:
        from fashion_clip.fashion_clip import FashionCLIP  # MIT

        CLIP = FashionCLIP("fashion-clip")
    return CLIP


def remove_background(image_bytes: bytes) -> bytes:
    """u2net background removal → RGBA PNG bytes."""
    from rembg import remove  # MIT

    return remove(image_bytes, session=_rembg_session())


def cutout_webp_b64(png_rgba_bytes: bytes, max_dim: int = 900, quality: int = 85) -> str:
    """Trim and encode the cut-out as WebP, base64 for the JSON payload."""
    from PIL import Image  # HPND (PIL licence) — permissive

    img = Image.open(io.BytesIO(png_rgba_bytes)).convert("RGBA")
    bbox = img.getbbox()
    if bbox:
        img = img.crop(bbox)
    if max(img.size) > max_dim:
        scale = max_dim / max(img.size)
        img = img.resize((max(1, round(img.width * scale)), max(1, round(img.height * scale))))
    buf = io.BytesIO()
    img.save(buf, format="WEBP", quality=quality, method=4)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _softmax(logits: list[float]) -> list[float]:
    hi = max(logits)
    exps = [math.exp(x - hi) for x in logits]
    total = sum(exps) or 1.0
    return [e / total for e in exps]


def zero_shot(image: Any, labels: list[str], templates: dict[str, str] | None = None) -> list[dict]:
    """Score candidate labels with FashionCLIP → [{label, score}] desc by score."""
    import numpy as np  # BSD-3

    fclip = _fclip()
    phrases = [templates[l] if templates else f"a photo of {l}" for l in labels]
    img_emb = fclip.encode_images([image], batch_size=1)
    txt_emb = fclip.encode_text(phrases, batch_size=32)
    img_emb = img_emb / np.linalg.norm(img_emb, ord=2, axis=-1, keepdims=True)
    txt_emb = txt_emb / np.linalg.norm(txt_emb, ord=2, axis=-1, keepdims=True)
    logits = (img_emb @ txt_emb.T)[0] * LOGIT_SCALE
    probs = _softmax([float(x) for x in logits])
    scored = [{"label": l, "score": p} for l, p in zip(labels, probs)]
    return sorted(scored, key=lambda s: s["score"], reverse=True)


def run_pipeline(image_bytes: bytes) -> dict:
    """Full extraction. Returns {attributes, cutout_webp_b64}."""
    from PIL import Image  # HPND (PIL licence)

    # 1) segment on the original photo
    cut_png = remove_background(image_bytes)
    cut_b64 = cutout_webp_b64(cut_png)

    # 2) classify the CUT-OUT (less background noise than the raw photo)
    garment = Image.open(io.BytesIO(cut_png)).convert("RGB")

    cat_scores = zero_shot(garment, list(CATEGORY_PHRASES), CATEGORY_PHRASES)
    category = cat_scores[0]["label"]
    sub_scores = zero_shot(garment, SUBCATEGORY_PHRASES[category])
    colour_scores = zero_shot(garment, COLOUR_LABELS)
    pattern_scores = zero_shot(garment, PATTERN_LABELS)
    formality_scores = zero_shot(garment, list(FORMALITY_PHRASES), FORMALITY_PHRASES)
    season_scores = zero_shot(garment, list(SEASON_PHRASES), SEASON_PHRASES)
    material_scores = zero_shot(garment, MATERIAL_PHRASES.get(category, MATERIAL_PHRASES["top"]))

    attributes = scores_to_attributes(
        {
            "category": cat_scores,
            "subcategory": sub_scores,
            "colour": colour_scores,
            "pattern": pattern_scores,
            "formality": formality_scores,
            "season": season_scores,
            "material": material_scores,
        }
    )
    return {"attributes": attributes, "cutout_webp_b64": cut_b64}
