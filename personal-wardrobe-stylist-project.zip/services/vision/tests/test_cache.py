"""Unit tests for the content-hash cache — never process the same image twice."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.cache import DiskCache, make_key  # noqa: E402


class TestMakeKey(unittest.TestCase):
    def test_same_bytes_same_key(self):
        a = b"a real garment photo"
        b = b"a real garment photo"
        self.assertEqual(make_key(a), make_key(b))
        self.assertTrue(make_key(a).startswith("sha256:"))
        self.assertEqual(len(make_key(a)), len("sha256:") + 64)

    def test_different_bytes_different_key(self):
        self.assertNotEqual(make_key(b"photo one"), make_key(b"photo two"))


class TestDiskCache(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cache = DiskCache(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_miss_returns_none(self):
        self.assertIsNone(self.cache.get("sha256:" + "0" * 64))
        self.assertFalse(self.cache.has("sha256:" + "0" * 64))

    def test_put_get_roundtrip(self):
        key = make_key(b"garment bytes")
        payload = {"ok": True, "attributes": {"category": "top", "colors": ["navy"]}, "cache": "miss"}
        self.cache.put(key, payload)
        self.assertTrue(self.cache.has(key))
        self.assertEqual(self.cache.get(key), payload)

    def test_second_write_wins_atomically(self):
        key = make_key(b"more bytes")
        self.cache.put(key, {"v": 1})
        self.cache.put(key, {"v": 2})
        self.assertEqual(self.cache.get(key), {"v": 2})

    def test_colon_keys_are_filename_safe(self):
        key = make_key(b"x")
        self.cache.put(key, {"ok": True})
        self.assertFalse(any(":" in p.name for p in Path(self.tmp.name).glob("*.json")))


if __name__ == "__main__":
    unittest.main()
