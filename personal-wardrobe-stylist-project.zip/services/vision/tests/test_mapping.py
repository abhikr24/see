"""Unit tests for the attribute mapping — runs with stdlib unittest only."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.mapping import (  # noqa: E402
    above_threshold,
    normalize_material,
    scores_to_attributes,
    seasons_from_label_scores,
    top_score,
)


def s(label: str, score: float) -> dict:
    return {"label": label, "score": score}


FIXTURE = {
    "category": [s("top", 0.71), s("bottom", 0.12)],
    "subcategory": [s("knit sweater", 0.55), s("t-shirt", 0.2)],
    "colour": [s("cream ivory", 0.5), s("brown", 0.2), s("pink", 0.02)],
    "pattern": [s("solid plain", 0.8), s("striped", 0.1)],
    "formality": [s("0", 0.2), s("1", 0.7)],
    "season": [s("winter", 0.66), s("mid", 0.24), s("summer", 0.1)],
    "material": [s("knitted wool", 0.4), s("polyester", 0.2)],
}


class TestScoreHelpers(unittest.TestCase):
    def test_top_score_argmax(self):
        self.assertEqual(top_score([s("a", 0.1), s("b", 0.6)])["label"], "b")
        self.assertIsNone(top_score([]))

    def test_above_threshold_sorts_filters_caps(self):
        scores = [s("a", 0.1), s("b", 0.6), s("c", 0.3)]
        self.assertEqual([x["label"] for x in above_threshold(scores, 0.2)], ["b", "c"])
        self.assertEqual(len(above_threshold(scores, 0.2, cap=1)), 1)
        self.assertEqual(above_threshold(scores, 0.9), [])


class TestSeasons(unittest.TestCase):
    def test_label_triplet_to_warmth(self):
        warmth, seasons = seasons_from_label_scores([s("summer", 0.7), s("winter", 0.2)])
        self.assertEqual(warmth, 0)
        self.assertEqual(seasons, ["spring", "summer"])
        warmth, seasons = seasons_from_label_scores([s("winter", 0.62)])
        self.assertEqual((warmth, seasons), (2, ["autumn", "winter"]))
        warmth, seasons = seasons_from_label_scores([])
        self.assertEqual(warmth, 1)
        self.assertEqual(len(seasons), 4)


class TestScoresToAttributes(unittest.TestCase):
    def test_fixture_fold(self):
        a = scores_to_attributes(FIXTURE)
        self.assertEqual(a["category"], "top")
        self.assertEqual(a["subcategory"], "knit")
        self.assertEqual(a["colors"], ["ivory", "chocolate"])  # threshold drops pink
        self.assertEqual(a["pattern"], "solid")
        self.assertEqual(a["formality"], 1)
        self.assertEqual(a["warmth"], 2)
        self.assertEqual(a["seasons"], ["autumn", "winter"])
        self.assertEqual(a["material"], "knit")
        self.assertEqual(a["fit"], "regular")  # honest default
        self.assertAlmostEqual(a["confidence"]["category"], 0.71, places=2)

    def test_unknown_category_defaults_to_top(self):
        a = scores_to_attributes({**FIXTURE, "category": []})
        self.assertEqual(a["category"], "top")
        self.assertEqual(a["subcategory"], "knit")

    def test_low_confidence_material_dropped(self):
        a = scores_to_attributes({**FIXTURE, "material": [s("leather", 0.1)]})
        self.assertEqual(a["material"], "")

    def test_bad_formality_label_clamps(self):
        a = scores_to_attributes({**FIXTURE, "formality": [s("9", 1.0)]})
        self.assertEqual(a["formality"], 0)

    def test_colour_label_table(self):
        a = scores_to_attributes({**FIXTURE, "colour": [s("denim blue", 0.9)]})
        self.assertEqual(a["colors"][0], "denim")


class TestNormalizeMaterial(unittest.TestCase):
    def test_canonicalisation(self):
        self.assertEqual(normalize_material("cotton jersey"), "cotton")
        self.assertEqual(normalize_material("knitted wool"), "knit")
        self.assertEqual(normalize_material("quilted nylon"), "synthetic")
        self.assertEqual(normalize_material("mesh fabric"), "mesh")
        self.assertEqual(normalize_material("something alien"), "")


if __name__ == "__main__":
    unittest.main()
