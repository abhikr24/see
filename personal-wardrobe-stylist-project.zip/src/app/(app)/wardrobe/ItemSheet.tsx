"use client";

import { Check, Heart, PencilLine, Sparkles, Trash2, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import {
  deleteItem,
  markItemWorn,
  toggleFavorite,
  updateItem,
  updateItemOccasions,
} from "@/app/actions";
import type { ClothingItem } from "@/db/schema";
import { draftFromItem, type ReviewDraft } from "@/lib/addDraft";
import { colorById } from "@/lib/palette";
import {
  FIT_LABELS,
  materialLabel,
  OCCASIONS,
  PATTERN_LABELS,
  SEASON_LABELS,
  SUBCATEGORIES,
} from "@/lib/presets";
import { cn, daysSince, timeAgo, vibrate } from "@/lib/utils";
import { Chip, FieldLabel } from "@/components/ui/Fields";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";
import { DraftFields } from "@/components/wardrobe/DraftFields";
import { GarmentThumb } from "@/components/wardrobe/GarmentThumb";

const FORMALITY = ["Casual", "Smart", "Dressy"];
const WARMTH = ["Featherlight", "Midweight", "Cozy"];

function seasonSummary(seasons: string[]): string {
  if (!seasons.length || seasons.length === 4) return "All-season";
  return seasons.map((s) => SEASON_LABELS[s] ?? s).join(" · ");
}

export function ItemSheet({ item, onClose }: { item: ClothingItem | null; onClose: () => void }) {
  const router = useRouter();
  const { toast } = useToast();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<ReviewDraft | null>(null);
  const [, start] = useTransition();

  useEffect(() => {
    setConfirmDelete(false);
    setEditing(false);
    setDraft(null);
  }, [item?.id]);

  if (!item) {
    return <Sheet open={false} onClose={onClose}>{null}</Sheet>;
  }

  const wornDays = daysSince(item.lastWornAt);
  const auto = item.visionStatus === "vision" || item.visionStatus === "cache";

  const act = (fn: () => Promise<unknown>, then?: () => void) =>
    start(async () => {
      await fn();
      then?.();
      router.refresh();
    });

  const toggleOccasion = (id: string) => {
    vibrate(6);
    const next = item.occasions.includes(id)
      ? item.occasions.filter((o) => o !== id)
      : [...item.occasions, id];
    act(() => updateItemOccasions(item.id, next));
  };

  const beginEdit = () => {
    vibrate(8);
    setDraft(draftFromItem(item));
    setEditing(true);
  };

  const saveEdit = () => {
    if (!draft) return;
    act(
      () =>
        updateItem(item.id, {
          name: draft.name.trim() || item.name,
          category: draft.category,
          subcategory: draft.subcategory,
          colors: draft.colors,
          pattern: draft.pattern,
          material: draft.material,
          fit: draft.fit,
          formality: draft.formality,
          seasons: draft.seasons,
          occasions: draft.occasions,
          notes: draft.notes,
        }),
      () => {
        toast("Piece updated");
        setEditing(false);
        onClose();
      },
    );
  };

  return (
    <Sheet open={Boolean(item)} onClose={onClose}>
      {editing && draft ? (
        /* ----------------------------------------------------- edit mode */
        <div className="px-6 pt-1 pb-8">
          <div className="flex items-center justify-between pb-4">
            <h3 className="font-display text-[22px] tracking-tight text-ink">Edit piece</h3>
            <button
              aria-label="Cancel editing"
              onClick={() => setEditing(false)}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-paper ring-1 ring-ink/10 active:scale-90"
            >
              <X className="h-4.5 w-4.5 text-ink" strokeWidth={2} />
            </button>
          </div>
          <DraftFields draft={draft} onChange={setDraft} />
          <div className="mt-6 flex gap-2.5">
            <button
              onClick={() => setEditing(false)}
              className="flex min-h-[52px] flex-1 items-center justify-center rounded-full bg-paper text-[14px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.97]"
            >
              Cancel
            </button>
            <button
              onClick={saveEdit}
              disabled={!draft.name.trim()}
              className="flex min-h-[52px] flex-[2] items-center justify-center gap-2 rounded-full bg-ink text-[14px] font-bold text-cream shadow-lift active:scale-[0.97] disabled:opacity-50"
            >
              <Check className="h-4.5 w-4.5" strokeWidth={2.4} />
              Save changes
            </button>
          </div>
        </div>
      ) : (
        /* ----------------------------------------------------- view mode */
        <>
          <div className="px-6 pt-1">
            <div className="flex gap-4">
              <GarmentThumb
                item={item}
                className="h-28 w-28 shrink-0 rounded-[20px] bg-bronze-soft/30 ring-1 ring-ink/[0.05]"
              />
              <div className="min-w-0 flex-1 pt-1">
                <h3 className="font-display text-[23px] leading-tight tracking-tight text-ink">{item.name}</h3>
                <p className="mt-0.5 text-[12.5px] text-muted">
                  {SUBCATEGORIES[item.subcategory]?.label ?? item.subcategory}
                  {item.pattern !== "solid" && ` · ${(PATTERN_LABELS[item.pattern] ?? item.pattern).toLowerCase()}`}
                </p>
                <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                  {item.colors.map((c) => (
                    <span
                      key={c}
                      className="flex items-center gap-1.5 rounded-full bg-paper py-1 pl-1.5 pr-2.5 ring-1 ring-ink/[0.07]"
                    >
                      <span
                        className="h-3 w-3 rounded-full ring-1 ring-ink/10"
                        style={{ backgroundColor: colorById(c).hex }}
                      />
                      <span className="text-[10.5px] font-semibold text-ink-2">{colorById(c).name}</span>
                    </span>
                  ))}
                  {auto && (
                    <span className="flex items-center gap-1 rounded-full bg-bronze-soft px-2.5 py-1 text-[10px] font-bold text-bronze-deep">
                      <Sparkles className="h-2.5 w-2.5" strokeWidth={2.5} />
                      Auto-scanned
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* meta grid */}
            <div className="mt-4 grid grid-cols-3 gap-2">
              {[
                { label: "Dress code", value: FORMALITY[item.formality] ?? "Casual" },
                { label: "Weight", value: WARMTH[item.warmth] ?? "Mid" },
                { label: "Seasons", value: seasonSummary(item.seasons) },
                { label: "Fit", value: FIT_LABELS[item.fit] ?? "Regular" },
                { label: "Material", value: item.material ? materialLabel(item.material) : "—" },
                {
                  label: "Rotation",
                  value:
                    item.timesWorn === 0
                      ? "Not worn yet"
                      : `${item.timesWorn}×${wornDays != null ? ` · ${wornDays}d ago` : ""}`,
                },
              ].map((m) => (
                <div key={m.label} className="rounded-2xl bg-paper px-3 py-2.5 ring-1 ring-ink/[0.06]">
                  <div className="micro-label text-muted/80">{m.label}</div>
                  <div className="mt-0.5 truncate text-[12.5px] font-bold text-ink">{m.value}</div>
                </div>
              ))}
            </div>

            {item.notes && (
              <div className="mt-3 rounded-2xl bg-paper px-4 py-3 ring-1 ring-ink/[0.06]">
                <div className="micro-label text-muted/80">Notes</div>
                <p className="mt-1 text-[12.5px] leading-snug text-ink-2">{item.notes}</p>
              </div>
            )}
          </div>

          {/* occasions quick editor */}
          <div className="mt-5 px-6">
            <FieldLabel>Wears well to</FieldLabel>
            <div className="flex flex-wrap gap-1.5">
              {OCCASIONS.map((o) => (
                <Chip key={o.id} small selected={item.occasions.includes(o.id)} onClick={() => toggleOccasion(o.id)}>
                  {o.label}
                </Chip>
              ))}
            </div>
          </div>

          {/* actions */}
          <div className="mt-6 grid grid-cols-2 gap-2.5 px-6 pb-2">
            <button
              onClick={() => act(() => markItemWorn(item.id), () => toast(`${item.name} logged as worn`))}
              className="flex min-h-[52px] items-center justify-center gap-2 rounded-full bg-ink py-3.5 text-[13.5px] font-bold text-cream active:scale-[0.96]"
            >
              <Check className="h-4 w-4" strokeWidth={2.4} />
              Wore this
            </button>
            <button
              onClick={() => {
                vibrate(8);
                act(() => toggleFavorite(item.id));
              }}
              className={cn(
                "flex min-h-[52px] items-center justify-center gap-2 rounded-full py-3.5 text-[13.5px] font-bold ring-1 active:scale-[0.96]",
                item.favorite ? "bg-bronze/15 text-bronze ring-bronze/30" : "bg-cream text-ink ring-ink/10",
              )}
            >
              <Heart className={cn("h-4 w-4", item.favorite && "fill-bronze")} strokeWidth={2.2} />
              {item.favorite ? "Favorited" : "Favorite"}
            </button>
            <button
              onClick={beginEdit}
              className="col-span-2 flex min-h-[48px] items-center justify-center gap-2 rounded-full bg-cream py-3 text-[13px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.97]"
            >
              <PencilLine className="h-4 w-4" strokeWidth={2.2} />
              Edit details — category, colours, fabric…
            </button>
            <button
              onClick={() => {
                if (!confirmDelete) {
                  vibrate(8);
                  setConfirmDelete(true);
                  return;
                }
                act(() => deleteItem(item.id), () => {
                  toast("Removed from your closet");
                  onClose();
                });
              }}
              className={cn(
                "col-span-2 min-h-[44px] rounded-full py-3 text-[12.5px] font-bold transition-all active:scale-[0.97]",
                confirmDelete ? "bg-[#7a2e27]/10 text-[#7a2e27] ring-1 ring-[#7a2e27]/25" : "text-muted",
              )}
            >
              <span className="flex items-center justify-center gap-2">
                <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
                {confirmDelete ? "Tap again — this removes it for good" : "Remove from closet"}
              </span>
            </button>
            <div className="col-span-2 pt-1 text-center text-[10.5px] font-medium text-muted/70">
              Added {timeAgo(item.createdAt)}
              {item.source !== "capsule" &&
                ` · via ${item.source === "camera" ? "camera" : item.source === "upload" ? "upload" : "manual entry"}`}
            </div>
          </div>
        </>
      )}
    </Sheet>
  );
}
