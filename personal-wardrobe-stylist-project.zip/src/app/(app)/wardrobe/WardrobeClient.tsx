"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Camera, Heart, Plus, Search, Shirt, SlidersHorizontal, Wand2, X } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { curateCapsule } from "@/app/actions";
import type { ClothingItem } from "@/db/schema";
import { colorById } from "@/lib/palette";
import { CATEGORIES, SEASON_LABELS, SUBCATEGORIES, type Category } from "@/lib/presets";
import { cn } from "@/lib/utils";
import { ALL_SEASONS } from "@shared/index";
import { Screen } from "@/components/shell/Screen";
import { EmptyState } from "@/components/ui/EmptyState";
import { Chip, ColorDots, FieldLabel } from "@/components/ui/Fields";
import { Sheet } from "@/components/ui/Sheet";
import { useToast } from "@/components/ui/Toast";
import { ItemTile } from "@/components/wardrobe/ItemTile";
import { ItemSheet } from "./ItemSheet";

type Filter = "all" | Category;

export default function WardrobeClient({ items }: { items: ClothingItem[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [active, setActive] = useState<ClothingItem | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [colourFilter, setColourFilter] = useState<string | null>(null);
  const [seasonFilter, setSeasonFilter] = useState<string | null>(null);
  const [favOnly, setFavOnly] = useState(false);
  const [, start] = useTransition();

  const counts = useMemo(() => {
    const m = new Map<string, number>();
    for (const i of items) m.set(i.category, (m.get(i.category) ?? 0) + 1);
    return m;
  }, [items]);

  const activeFilterCount = (colourFilter ? 1 : 0) + (seasonFilter ? 1 : 0) + (favOnly ? 1 : 0);

  const visible = useMemo(() => {
    let list = items;
    if (filter !== "all") list = list.filter((i) => i.category === filter);
    if (colourFilter) list = list.filter((i) => i.colors.includes(colourFilter));
    if (seasonFilter) list = list.filter((i) => i.seasons.includes(seasonFilter));
    if (favOnly) list = list.filter((i) => i.favorite);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          (SUBCATEGORIES[i.subcategory]?.label ?? "").toLowerCase().includes(q) ||
          i.material.toLowerCase().includes(q) ||
          i.colors.some((c) => colorById(c).name.toLowerCase().includes(q)),
      );
    }
    return list;
  }, [items, filter, query, colourFilter, seasonFilter, favOnly]);

  const clearFilters = () => {
    setColourFilter(null);
    setSeasonFilter(null);
    setFavOnly(false);
  };

  return (
    <Screen
      eyebrow={items.length ? `${items.length} piece${items.length === 1 ? "" : "s"}` : "The closet"}
      title="Wardrobe"
      right={
        <div className="flex items-center gap-2">
          <button
            aria-label="Filter wardrobe"
            onClick={() => setFiltersOpen(true)}
            className="relative flex h-10 w-10 items-center justify-center rounded-full bg-cream ring-1 ring-ink/[0.08] active:scale-90"
          >
            <SlidersHorizontal className="h-[18px] w-[18px] text-ink" strokeWidth={2} />
            {activeFilterCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-bronze text-[9px] font-bold text-cream">
                {activeFilterCount}
              </span>
            )}
          </button>
          <button
            aria-label="Search wardrobe"
            onClick={() => {
              setSearchOpen(!searchOpen);
              if (searchOpen) setQuery("");
            }}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-cream ring-1 ring-ink/[0.08] active:scale-90"
          >
            {searchOpen ? (
              <X className="h-[18px] w-[18px] text-ink" strokeWidth={2} />
            ) : (
              <Search className="h-[18px] w-[18px] text-ink" strokeWidth={2} />
            )}
          </button>
        </div>
      }
    >
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden px-5"
          >
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search “navy”, “linen”, “boots”…"
              className="mb-3 w-full rounded-full bg-cream px-5 py-3 text-[14px] font-medium text-ink outline-none ring-1 ring-ink/10 placeholder:text-muted/70 focus:ring-ink/25"
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* category rail */}
      <div className="sticky top-0 z-20 -mx-0 bg-paper/90 pb-3 pt-1 backdrop-blur-lg">
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-5">
          {[{ id: "all" as Filter, label: "All", plural: "All" }, ...CATEGORIES].map((c) => {
            const on = filter === c.id;
            const n = c.id === "all" ? items.length : (counts.get(c.id) ?? 0);
            if (c.id !== "all" && n === 0) return null;
            return (
              <button
                key={c.id}
                onClick={() => setFilter(c.id as Filter)}
                className={cn(
                  "flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-[12.5px] font-semibold transition-all active:scale-95",
                  on ? "bg-ink text-cream shadow-soft" : "bg-cream text-ink-2 ring-1 ring-ink/[0.08]",
                )}
              >
                {c.id === "all" ? "All" : c.plural}
                <span className={cn("text-[10px] tabular", on ? "text-cream/60" : "text-muted")}>{n}</span>
              </button>
            );
          })}
        </div>

        {/* active filter pills */}
        {activeFilterCount > 0 && (
          <div className="no-scrollbar mt-2 flex items-center gap-1.5 overflow-x-auto px-5">
            {colourFilter && (
              <Pill
                label={colorById(colourFilter).name}
                swatch={colorById(colourFilter).hex}
                onClear={() => setColourFilter(null)}
              />
            )}
            {seasonFilter && <Pill label={SEASON_LABELS[seasonFilter] ?? seasonFilter} onClear={() => setSeasonFilter(null)} />}
            {favOnly && <Pill label="Favourites" onClear={() => setFavOnly(false)} />}
            <button onClick={clearFilters} className="shrink-0 px-2 py-1 text-[11px] font-bold text-muted active:scale-95">
              Clear all
            </button>
          </div>
        )}
      </div>

      {visible.length > 0 ? (
        <div className="grid grid-cols-2 gap-3 px-5 pt-1">
          <AddTile />
          <AnimatePresence mode="popLayout">
            {visible.map((item, i) => (
              <motion.div key={item.id} layout exit={{ opacity: 0, scale: 0.9 }}>
                <ItemTile item={item} index={Math.min(i, 12)} onClick={() => setActive(item)} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : items.length === 0 ? (
        <div className="pt-8">
          <EmptyState
            icon={Shirt}
            title="Nothing here yet — and that's exciting"
            body="Every great wardrobe starts with a first hanger. Add a piece, or let us curate a capsule for you."
          >
            <button
              onClick={() =>
                start(async () => {
                  await curateCapsule();
                  toast("Your capsule is ready");
                  router.refresh();
                })
              }
              className="flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-[14px] font-bold text-cream shadow-lift active:scale-[0.96]"
            >
              <Wand2 className="h-4 w-4" strokeWidth={2} />
              Curate my capsule
            </button>
            <Link
              href="/add"
              className="flex items-center gap-2 rounded-full bg-cream px-7 py-4 text-[14px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.96]"
            >
              <Camera className="h-4 w-4" strokeWidth={2} />
              Add with camera
            </Link>
          </EmptyState>
        </div>
      ) : (
        <div className="pt-10">
          <EmptyState
            icon={Search}
            title="Nothing matches"
            body={query ? `No pieces found for “${query}”.` : "These filters leave an empty rail."}
          >
            {activeFilterCount > 0 ? (
              <button
                onClick={clearFilters}
                className="flex items-center gap-2 rounded-full bg-ink px-7 py-3.5 text-[13.5px] font-bold text-cream active:scale-[0.96]"
              >
                <X className="h-4 w-4" strokeWidth={2.4} />
                Clear filters
              </button>
            ) : (
              <Link
                href="/add"
                className="flex items-center gap-2 rounded-full bg-ink px-7 py-3.5 text-[13.5px] font-bold text-cream active:scale-[0.96]"
              >
                <Plus className="h-4 w-4" strokeWidth={2.4} />
                Add a piece
              </Link>
            )}
          </EmptyState>
        </div>
      )}

      {/* ------------------------------------------------ filter sheet */}
      <Sheet
        open={filtersOpen}
        onClose={() => setFiltersOpen(false)}
        title="Filters"
        subtitle="Narrow the rail by colour, season or favourites."
      >
        <div className="px-6 pb-8 pt-1">
          <FieldLabel>Colour</FieldLabel>
          <div className="rounded-[20px] bg-paper p-4 ring-1 ring-ink/[0.06]">
            <ColorDots
              selected={colourFilter ? [colourFilter] : []}
              onToggle={(id) => setColourFilter((cur) => (cur === id ? null : id))}
            />
          </div>

          <div className="pt-5">
            <FieldLabel>Season</FieldLabel>
            <div className="flex gap-2">
              {ALL_SEASONS.map((s) => (
                <Chip
                  key={s}
                  selected={seasonFilter === s}
                  onClick={() => setSeasonFilter((cur) => (cur === s ? null : s))}
                  className="flex-1 !px-0 !py-3 text-center"
                >
                  {SEASON_LABELS[s]}
                </Chip>
              ))}
            </div>
          </div>

          <div className="pt-5">
            <FieldLabel>Only show</FieldLabel>
            <Chip selected={favOnly} onClick={() => setFavOnly((v) => !v)} className="!px-5 !py-3">
              <span className="flex items-center gap-1.5">
                <Heart className={cn("h-3.5 w-3.5", favOnly && "fill-cream")} strokeWidth={2.2} />
                Favourites
              </span>
            </Chip>
          </div>

          <div className="mt-6 flex gap-2.5">
            <button
              onClick={clearFilters}
              className="min-h-[52px] flex-1 rounded-full bg-paper text-[14px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.97]"
            >
              Clear
            </button>
            <button
              onClick={() => setFiltersOpen(false)}
              className="min-h-[52px] flex-[2] rounded-full bg-ink text-[14px] font-bold text-cream shadow-lift active:scale-[0.97]"
            >
              Show {visible.length} piece{visible.length === 1 ? "" : "s"}
            </button>
          </div>
        </div>
      </Sheet>

      <ItemSheet item={active} onClose={() => setActive(null)} />
    </Screen>
  );
}

function Pill({ label, swatch, onClear }: { label: string; swatch?: string; onClear: () => void }) {
  return (
    <button
      onClick={onClear}
      className="flex min-h-[32px] shrink-0 items-center gap-1.5 rounded-full bg-ink/[0.07] py-1.5 pl-3 pr-2 text-[11px] font-bold text-ink-2 active:scale-95"
    >
      {swatch && <span className="h-2.5 w-2.5 rounded-full ring-1 ring-ink/15" style={{ backgroundColor: swatch }} />}
      {label}
      <X className="h-3 w-3 text-muted" strokeWidth={2.6} />
    </button>
  );
}

function AddTile() {
  return (
    <Link
      href="/add"
      className="flex aspect-[5/6.9] flex-col items-center justify-center gap-2.5 rounded-[22px] border-[1.5px] border-dashed border-ink/20 text-muted transition-colors active:scale-[0.97] active:border-ink/40"
    >
      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-ink/[0.06]">
        <Plus className="h-5 w-5 text-ink/60" strokeWidth={2.2} />
      </span>
      <span className="text-[12px] font-bold tracking-wide text-ink/50">ADD PIECE</span>
    </Link>
  );
}
