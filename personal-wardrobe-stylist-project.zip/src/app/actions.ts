"use server";

import { and, eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import {
  getProfile,
  itemsByIds,
  listItems,
  regenerateToday,
  seedCapsule,
  updateItemFields,
  type ItemPatch,
} from "@/db/queries";
import { clothingItems, feedback, outfits, profiles, wearLogs } from "@/db/schema";
import { buildOutfit } from "@/lib/engine";
import type { Category } from "@/lib/presets";
import { todayKey } from "@/lib/utils";

function refresh() {
  for (const p of ["/", "/today", "/wardrobe", "/history", "/profile", "/add"]) {
    revalidatePath(p);
  }
}

/* ------------------------------------------------------------- onboarding */

export type OnboardingPayload = {
  name: string;
  styles: string[];
  loveColors: string[];
  avoidColors: string[];
  occasions: string[];
  city: string;
  capsuleKeys: string[];
};

export async function completeOnboarding(payload: OnboardingPayload) {
  const profile = await getProfile();
  await db
    .update(profiles)
    .set({
      name: payload.name.trim() || "Avery",
      styles: payload.styles,
      loveColors: payload.loveColors,
      avoidColors: payload.avoidColors,
      occasions: payload.occasions,
      city: payload.city.trim(),
      lastOccasion: payload.occasions[0] ?? "daily",
      onboarded: true,
    })
    .where(eq(profiles.id, profile.id));
  await seedCapsule(payload.capsuleKeys);
  refresh();
  return { ok: true };
}

export async function curateCapsule() {
  const { DEFAULT_CAPSULE_KEYS } = await import("@/lib/presets");
  await seedCapsule(DEFAULT_CAPSULE_KEYS);
  refresh();
  return { ok: true };
}

/* ---------------------------------------------------------------- profile */

export async function updateProfile(partial: {
  name?: string;
  styles?: string[];
  loveColors?: string[];
  avoidColors?: string[];
  occasions?: string[];
  city?: string;
}) {
  const profile = await getProfile();
  const data: Record<string, unknown> = {};
  if (partial.name !== undefined) data.name = partial.name.trim() || profile.name;
  if (partial.styles !== undefined) data.styles = partial.styles;
  if (partial.loveColors !== undefined) data.loveColors = partial.loveColors;
  if (partial.avoidColors !== undefined) data.avoidColors = partial.avoidColors;
  if (partial.occasions !== undefined) data.occasions = partial.occasions;
  if (partial.city !== undefined) {
    data.city = partial.city.trim();
    data.lat = null;
    data.lon = null;
  }
  await db.update(profiles).set(data).where(eq(profiles.id, profile.id));
  refresh();
  return { ok: true };
}

/* ---------------------------------------------------------------- outfits */

export async function setOccasion(occasion: string) {
  const profile = await getProfile();
  await db.update(profiles).set({ lastOccasion: occasion }).where(eq(profiles.id, profile.id));
  await regenerateToday(occasion, 3);
  refresh();
}

export async function remixToday(occasion: string) {
  const profile = await getProfile();
  const date = todayKey();
  const rows = await db
    .select()
    .from(outfits)
    .where(and(eq(outfits.date, date), eq(outfits.isMain, true), eq(outfits.occasion, occasion)));
  const current = rows.find((o) => !o.dismissedAt);
  await regenerateToday(occasion, Math.floor(Math.random() * 1000), current?.itemIds ?? []);
  refresh();
}

export async function swapAltIn(altId: string, occasion: string) {
  const date = todayKey();
  await db
    .update(outfits)
    .set({ dismissedAt: new Date() })
    .where(and(eq(outfits.date, date), eq(outfits.isMain, true), eq(outfits.occasion, occasion)));
  await db.update(outfits).set({ isMain: true }).where(eq(outfits.id, altId));
  refresh();
}

export async function reactOutfit(outfitId: string, reaction: "like" | "dislike" | null) {
  await db.update(outfits).set({ reaction }).where(eq(outfits.id, outfitId));
  refresh();
}

export async function saveOutfit(outfitId: string) {
  await db.update(outfits).set({ savedAt: new Date() }).where(eq(outfits.id, outfitId));
  refresh();
}

export async function unsaveOutfit(outfitId: string) {
  await db.update(outfits).set({ savedAt: null }).where(eq(outfits.id, outfitId));
  refresh();
}

export async function dismissOutfit(outfitId: string, occasion: string) {
  await db.update(outfits).set({ dismissedAt: new Date() }).where(eq(outfits.id, outfitId));
  await regenerateToday(occasion, Math.floor(Math.random() * 1000));
  refresh();
}

export async function wearOutfit(outfitId: string) {
  const rows = await db.select().from(outfits).where(eq(outfits.id, outfitId));
  const outfit = rows[0];
  if (!outfit) return { ok: false };
  const now = new Date();
  await db
    .update(outfits)
    .set({ wornAt: now, savedAt: outfit.savedAt ?? now })
    .where(eq(outfits.id, outfitId));
  const date = todayKey();
  for (const itemId of outfit.itemIds) {
    await db.insert(wearLogs).values({ itemId, outfitId, date });
    await db
      .update(clothingItems)
      .set({ timesWorn: sql`${clothingItems.timesWorn} + 1`, lastWornAt: now })
      .where(eq(clothingItems.id, itemId));
  }
  refresh();
  return { ok: true };
}

/** Replace one slot of an outfit with another garment from the closet. */
export async function swapOutfitItem(outfitId: string, newItemId: string) {
  const bundle = await db.select().from(outfits).where(eq(outfits.id, outfitId));
  const outfit = bundle[0];
  if (!outfit) return { ok: false };
  const [items, all, profile] = await Promise.all([itemsByIds(outfit.itemIds), listItems(), getProfile()]);
  const newcomer = all.find((i) => i.id === newItemId);
  if (!newcomer) return { ok: false };
  const fixed: Partial<Record<Category, string>> = {};
  for (const item of items) {
    const cat = item.category as Category;
    if (cat === newcomer.category) fixed[cat] = newcomer.id;
    else fixed[cat] = item.id;
  }
  const rebuilt = buildOutfit(all, {
    profile,
    occasion: outfit.occasion,
    tempC: outfit.tempC,
    weatherCode: outfit.weatherCode,
    fixed,
  });
  if (!rebuilt.items.some((i) => i.id === newItemId)) {
    // force-include even if the stylist would not have picked it
    rebuilt.items = [
      ...rebuilt.items.filter((i) => i.category !== newcomer.category),
      newcomer,
    ];
  }
  await db
    .update(outfits)
    .set({ itemIds: rebuilt.items.map((i) => i.id), reasons: rebuilt.reasons })
    .where(eq(outfits.id, outfitId));
  refresh();
  return { ok: true };
}

/* ------------------------------------------------------------------ items */

export type NewItemPayload = {
  name: string;
  category: string;
  subcategory: string;
  colors: string[];
  pattern: string;
  formality: number;
  warmth: number;
  occasions: string[];
  imageUrl: string | null;
  source: string;
};

export async function addItem(payload: NewItemPayload) {
  const rows = await db
    .insert(clothingItems)
    .values({
      name: payload.name.trim() || "New piece",
      category: payload.category,
      subcategory: payload.subcategory,
      colors: payload.colors,
      pattern: payload.pattern,
      formality: payload.formality,
      warmth: payload.warmth,
      occasions: payload.occasions,
      imageUrl: payload.imageUrl,
      source: payload.source,
    })
    .returning({ id: clothingItems.id });
  refresh();
  return { ok: true, id: rows[0]?.id };
}

export async function toggleFavorite(itemId: string) {
  const rows = await db.select().from(clothingItems).where(eq(clothingItems.id, itemId));
  const item = rows[0];
  if (!item) return;
  await db.update(clothingItems).set({ favorite: !item.favorite }).where(eq(clothingItems.id, itemId));
  refresh();
}

export async function markItemWorn(itemId: string) {
  const now = new Date();
  await db.insert(wearLogs).values({ itemId, date: todayKey() });
  await db
    .update(clothingItems)
    .set({ timesWorn: (await wearCount(itemId)) + 1, lastWornAt: now })
    .where(eq(clothingItems.id, itemId));
  refresh();
}

async function wearCount(itemId: string): Promise<number> {
  const rows = await db.select().from(clothingItems).where(eq(clothingItems.id, itemId));
  return rows[0]?.timesWorn ?? 0;
}

export async function updateItemOccasions(itemId: string, occasions: string[]) {
  await db.update(clothingItems).set({ occasions }).where(eq(clothingItems.id, itemId));
  refresh();
}

/** Generic editable-fields update (edit mode in the item sheet). */
export async function updateItem(itemId: string, patch: ItemPatch) {
  await updateItemFields(itemId, patch);
  refresh();
  return { ok: true };
}

export async function deleteItem(itemId: string) {
  await db.delete(clothingItems).where(eq(clothingItems.id, itemId));
  refresh();
}

/* ---------------------------------------------------------------- feedback */

export async function submitFeedback(rating: number, note: string, context: string) {
  await db.insert(feedback).values({ rating, note: note.trim(), context });
  refresh();
  return { ok: true };
}

/* ------------------------------------------------------------------ reset */

export async function resetEverything() {
  await db.delete(wearLogs);
  await db.delete(outfits);
  await db.delete(feedback);
  await db.delete(clothingItems);
  await db.delete(profiles);
  refresh();
  return { ok: true };
}
