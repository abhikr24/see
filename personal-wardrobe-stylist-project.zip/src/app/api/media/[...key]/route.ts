/**
 * GET /api/media/<key> — streams locally-stored uploads with immutable cache
 * headers (keys are content hashes). The service worker runtime-caches these
 * responses, which is what makes wardrobe browsing work offline.
 */
import { createReadStream, existsSync } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { sanitizeKey, uploadDir } from "@/lib/storage";

export const runtime = "nodejs";

const TYPES: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
};

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ key: string[] }> },
) {
  const { key } = await params;
  const joined = sanitizeKey(key.join("/"));
  if (!joined) return new Response("Not found", { status: 404 });

  const file = path.join(uploadDir(), joined);
  if (!file.startsWith(uploadDir()) || !existsSync(file)) {
    return new Response("Not found", { status: 404 });
  }
  const info = await stat(file);
  const ext = path.extname(file).toLowerCase();
  const stream = Readable.toWeb(createReadStream(file)) as ReadableStream;
  return new Response(stream, {
    headers: {
      "Content-Type": TYPES[ext] ?? "application/octet-stream",
      "Content-Length": String(info.size),
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
