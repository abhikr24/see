/**
 * POST /api/wardrobe/extract
 * multipart/form-data: image (file, required, ≤ 8 MB), hints (JSON, optional:
 * { paletteHexes?: string[], category?: string, subcategory?: string })
 *
 * Stores the original upload, runs the image→attributes pipeline (content-hash
 * cached — the same image is never processed twice), and returns the typed
 * attribute object for the review sheet. Nothing is written to clothing_items
 * here; the user confirms first (POST /api/wardrobe/items).
 */
import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { visionExtractions } from "@/db/schema";
import { getStorage } from "@/lib/storage";
import {
  buildCacheKey,
  callVisionService,
  hashBytes,
  heuristicAttributes,
  type ClientHints,
} from "@/lib/vision/client";
import type { ExtractResponse, VisionAttributes } from "@shared/index";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 8 * 1024 * 1024;

type ExtractApiResponse = {
  ok: boolean;
  hash: string;
  imageRef: string | null;
  cutoutUrl: string | null;
  attributes: VisionAttributes | null;
  provider: "vision" | "fallback";
  cache: "hit" | "miss";
  error?: string;
};

export async function POST(req: Request): Promise<NextResponse<ExtractApiResponse>> {
  const fail = (error: string, status = 400) => {
    const body: ExtractApiResponse = {
      ok: false,
      hash: "",
      imageRef: null,
      cutoutUrl: null,
      attributes: null,
      provider: "fallback",
      cache: "miss",
      error,
    };
    return NextResponse.json(body, { status });
  };

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail("Expected multipart/form-data");
  }
  const image = form.get("image");
  if (!(image instanceof File)) return fail("Missing image file");
  if (image.size > MAX_BYTES) return fail("Image exceeds 8 MB", 413);

  let hints: ClientHints = {};
  const rawHints = form.get("hints");
  if (typeof rawHints === "string") {
    try {
      hints = JSON.parse(rawHints) as ClientHints;
    } catch {
      /* hints are optional */
    }
  }

  const bytes = Buffer.from(await image.arrayBuffer());
  const hash = hashBytes(bytes);
  const storage = getStorage();
  const originalKeyFor = (contentType: string) =>
    `${hash}.${contentType.includes("png") ? "png" : "jpg"}`;

  // ---- cache: derived attributes are content-addressed, computed once ----
  const cachedRows = await db
    .select()
    .from(visionExtractions)
    .where(eq(visionExtractions.hash, buildCacheKey(hash)))
    .limit(1);
  const cached = cachedRows[0];
  if (cached) {
    return NextResponse.json({
      ok: true,
      hash,
      imageRef: storage.url(originalKeyFor(image.type || "image/jpeg")),
      cutoutUrl: cached.cutoutRef ? storage.url(cached.cutoutRef) : null,
      attributes: cached.attributes as unknown as VisionAttributes,
      provider: cached.provider === "vision" ? "vision" : "fallback",
      cache: "hit",
    });
  }

  // ---- store original upload ----
  const originalKey = originalKeyFor(image.type || "image/jpeg");
  let imageRef: string;
  try {
    imageRef = (await storage.put(originalKey, bytes, image.type || "image/jpeg")).url;
  } catch {
    return fail("Could not store the upload", 500);
  }

  // ---- vision service → fallback (never paid AI) ----
  const vision: ExtractResponse | null = await callVisionService(bytes, image.type || "image/jpeg");

  let attributes: VisionAttributes;
  let provider: "vision" | "fallback";
  let cutoutUrl: string | null = null;
  let cutoutRef: string | null = null;

  if (vision) {
    attributes = vision.attributes;
    provider = "vision";
    if (vision.cutoutWebpB64) {
      try {
        const cutout = Buffer.from(vision.cutoutWebpB64, "base64");
        const stored = await storage.put(`${hash}.cutout.webp`, cutout, "image/webp");
        cutoutUrl = stored.url;
        cutoutRef = stored.key;
      } catch {
        /* cut-out is a nice-to-have; attributes still valid */
      }
    }
  } else {
    attributes = heuristicAttributes(hints);
    provider = "fallback";
  }

  try {
    await db
      .insert(visionExtractions)
      .values({
        hash: buildCacheKey(hash),
        attributes: attributes as unknown as Record<string, unknown>,
        cutoutRef,
        provider,
      })
      .onConflictDoNothing();
  } catch {
    /* cache is an optimisation — never fail the request on it */
  }

  return NextResponse.json({
    ok: true,
    hash,
    imageRef,
    cutoutUrl,
    attributes,
    provider,
    cache: "miss",
  });
}
