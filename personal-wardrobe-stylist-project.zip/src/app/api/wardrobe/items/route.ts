/**
 * POST /api/wardrobe/items — create a wardrobe item after the user confirms
 * the review sheet. Zod-validated; references the already-stored image via
 * its content hash (no re-upload). Every auto-detected field arrives after
 * user review, so what we persist is the *user's* truth.
 */
import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { clothingItems } from "@/db/schema";
import { revalidatePath } from "next/cache";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CATEGORIES = ["top", "bottom", "footwear", "outerwear", "accessory"] as const;
const FITS = ["slim", "regular", "relaxed", "oversized"] as const;
const SEASONS = ["spring", "summer", "autumn", "winter"] as const;

const ItemPayload = z.object({
  name: z.string().trim().min(1).max(80),
  category: z.enum(CATEGORIES),
  subcategory: z.string().trim().min(1).max(40),
  colors: z.array(z.string()).max(3).default([]),
  pattern: z.string().trim().max(24).default("solid"),
  material: z.string().trim().max(48).default(""),
  fit: z.enum(FITS).default("regular"),
  formality: z.union([z.literal(0), z.literal(1), z.literal(2)]).default(0),
  warmth: z.union([z.literal(0), z.literal(1), z.literal(2)]).default(1),
  seasons: z.array(z.enum(SEASONS)).min(1).max(4).default(["spring", "summer", "autumn", "winter"]),
  occasions: z.array(z.string()).max(16).default([]),
  notes: z.string().trim().max(500).default(""),
  imageHash: z.string().regex(/^[a-f0-9]{64}$/).nullable().default(null),
  imageRef: z.string().max(300).nullable().default(null),
  imageUrl: z.string().max(400).nullable().default(null),
  cutoutUrl: z.string().max(400).nullable().default(null),
  visionStatus: z.enum(["none", "vision", "cache", "fallback", "manual"]).default("manual"),
  visionMeta: z.record(z.string(), z.unknown()).nullable().default(null),
  source: z.enum(["camera", "upload", "manual"]).default("manual"),
});

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Expected JSON body" }, { status: 400 });
  }
  const parsed = ItemPayload.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid payload" },
      { status: 422 },
    );
  }
  const p = parsed.data;

  const rows = await db
    .insert(clothingItems)
    .values({
      name: p.name,
      category: p.category,
      subcategory: p.subcategory,
      colors: p.colors,
      pattern: p.pattern,
      material: p.material,
      fit: p.fit,
      formality: p.formality,
      warmth: p.warmth,
      seasons: p.seasons,
      occasions: p.occasions,
      notes: p.notes,
      imageHash: p.imageHash ? `sha256:${p.imageHash}` : null,
      imageRef: p.imageRef,
      cutoutUrl: p.cutoutUrl,
      imageUrl: p.cutoutUrl ?? p.imageUrl,
      visionStatus: p.visionStatus,
      visionMeta: p.visionMeta as Record<string, unknown> | null,
      source: p.source,
    })
    .returning({ id: clothingItems.id });

  for (const path of ["/", "/today", "/wardrobe", "/history", "/add"]) revalidatePath(path);
  return NextResponse.json({ ok: true, id: rows[0]?.id ?? null });
}
