"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, CheckCircle2, ScanLine } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { fallbackAttributes, warmthFromSeasons, type Season } from "@shared/index";
import { blankDraft, draftFromAttributes, type ReviewDraft } from "@/lib/addDraft";
import { nearestPaletteIds } from "@shared/index";
import type { PreparedImage } from "@/lib/imaging";
import { vibrate } from "@/lib/utils";
import { Screen } from "@/components/shell/Screen";
import { useToast } from "@/components/ui/Toast";
import { CaptureStage, type CaptureSource } from "./CaptureStage";
import { ReviewSheet } from "./ReviewSheet";

type Step = "capture" | "analyzing" | "review";

type ExtractApiResponse = {
  ok: boolean;
  hash: string;
  imageRef: string | null;
  cutoutUrl: string | null;
  attributes: ReturnType<typeof fallbackAttributes> | null;
  provider: "vision" | "fallback";
  cache: "hit" | "miss";
  error?: string;
};

const SCAN_STEPS = [
  "Trimming the background…",
  "Reading the colours…",
  "Cut, cloth and occasion…",
];

export default function AddFlow() {
  const router = useRouter();
  const { toast } = useToast();

  const [step, setStep] = useState<Step>("capture");
  const [captureSession, setCaptureSession] = useState(0);
  const [prepared, setPrepared] = useState<PreparedImage | null>(null);
  const [source, setSource] = useState<CaptureSource | "manual">("manual");
  const [extract, setExtract] = useState<ExtractApiResponse | null>(null);
  const [draft, setDraft] = useState<ReviewDraft>(blankDraft());
  const [saving, setSaving] = useState(false);
  const [savedFlash, setSavedFlash] = useState(false);
  const [savedNames, setSavedNames] = useState<string[]>([]);
  const [scanIdx, setScanIdx] = useState(0);
  const previewRef = useRef<string | null>(null);

  // staged scan messages while the pipeline runs
  useEffect(() => {
    if (step !== "analyzing") return;
    setScanIdx(0);
    const t = setInterval(() => setScanIdx((i) => Math.min(i + 1, SCAN_STEPS.length - 1)), 900);
    return () => clearInterval(t);
  }, [step]);

  const releasePreview = useCallback(() => {
    if (previewRef.current) {
      URL.revokeObjectURL(previewRef.current);
      previewRef.current = null;
    }
  }, []);

  const resetForNext = useCallback(() => {
    releasePreview();
    setPrepared(null);
    setExtract(null);
    setDraft(blankDraft());
    setStep("capture");
    setCaptureSession((n) => n + 1); // remount → camera restarts
  }, [releasePreview]);

  const onCapture = useCallback(
    async (img: PreparedImage, src: CaptureSource) => {
      vibrate(14);
      previewRef.current = img.previewUrl;
      setPrepared(img);
      setSource(src);
      setStep("analyzing");
      try {
        const form = new FormData();
        form.append("image", img.blob, "garment.jpg");
        form.append("hints", JSON.stringify({ paletteHexes: img.paletteHexes }));
        const res = await fetch("/api/wardrobe/extract", { method: "POST", body: form });
        const json = (await res.json()) as ExtractApiResponse;
        if (!json.ok || !json.attributes) throw new Error(json.error ?? "extract failed");
        setExtract(json);
        setDraft(draftFromAttributes(json.attributes));
      } catch {
        // network/server down → still let the user finish (fields editable anyway)
        setExtract(null);
        setDraft({
          ...draftFromAttributes(fallbackAttributes({ paletteHexes: [] })),
          colors: nearestPaletteIds(img.paletteHexes, 2).length
            ? nearestPaletteIds(img.paletteHexes, 2)
            : ["stone"],
        });
        toast("Offline scan — double-check the details");
      }
      setStep("review");
    },
    [toast],
  );

  const onManual = useCallback(() => {
    vibrate(8);
    setPrepared(null);
    setSource("manual");
    setExtract(null);
    setDraft(blankDraft());
    setStep("review");
  }, []);

  const save = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    vibrate([10, 40, 10]);
    const warmth = warmthFromSeasons((draft.seasons as Season[]).length ? (draft.seasons as Season[]) : ["spring", "summer", "autumn", "winter"]);
    const payload = {
      ...draft,
      warmth,
      imageHash: extract?.hash ?? prepared?.sha256 ?? null,
      imageRef: extract?.imageRef ?? null,
      // never persist session-local blob: URLs — only server-stored media
      imageUrl: extract?.cutoutUrl ?? extract?.imageRef ?? null,
      cutoutUrl: extract?.cutoutUrl ?? null,
      visionStatus:
        source === "manual"
          ? ("manual" as const)
          : extract
            ? extract.cache === "hit"
              ? ("cache" as const)
              : extract.provider === "vision"
                ? ("vision" as const)
                : ("fallback" as const)
            : ("fallback" as const),
      visionMeta: extract?.attributes?.confidence ? { confidence: extract.attributes.confidence } : null,
      source,
    };
    try {
      const res = await fetch("/api/wardrobe/items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { ok: boolean };
      if (!json.ok) throw new Error("save failed");
      setSavedFlash(true);
      setSavedNames((n) => [draft.name, ...n].slice(0, 3));
      toast("Added to your closet");
      router.refresh();
      setTimeout(() => {
        setSavedFlash(false);
        setSaving(false);
        resetForNext();
      }, 950);
    } catch {
      setSaving(false);
      toast("Could not save — try again");
    }
  }, [draft, extract, prepared, saving, source, toast, router, resetForNext]);

  return (
    <Screen eyebrow="New piece" title="Add to closet">
      <div className="px-5 pt-1">
        <AnimatePresence mode="wait">
          {step === "capture" && (
            <motion.div
              key={`capture-${captureSession}`}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3 }}
            >
              {savedNames.length > 0 && (
                <div className="mb-3">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {savedNames.map((n) => (
                      <span
                        key={n}
                        className="flex items-center gap-1 rounded-full bg-olive/10 px-2.5 py-1.5 text-[10.5px] font-bold text-olive"
                      >
                        <CheckCircle2 className="h-3 w-3" strokeWidth={2.4} />
                        {n}
                      </span>
                    ))}
                  </div>
                  <Link
                    href="/wardrobe"
                    className="mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-full bg-cream py-3 text-[12.5px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.98]"
                  >
                    Done for now — view wardrobe
                    <ArrowRight className="h-3.5 w-3.5" strokeWidth={2.4} />
                  </Link>
                </div>
              )}
              <CaptureStage busy={false} onCapture={onCapture} onManual={onManual} />
            </motion.div>
          )}

          {(step === "analyzing" || step === "review") && prepared && (
            <motion.div key="still" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.35 }}>
              <div className="relative aspect-[4/4.4] w-full overflow-hidden rounded-[28px] bg-ink shadow-lift">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={prepared.previewUrl} alt="Captured garment" className="absolute inset-0 h-full w-full object-cover" />
                {step === "analyzing" && (
                  <>
                    <motion.div
                      initial={{ top: "4%" }}
                      animate={{ top: ["4%", "88%", "4%"] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute inset-x-8 h-[3px] rounded-full bg-cream/90 shadow-[0_0_18px_4px_rgba(251,248,241,0.55)]"
                    />
                    <div className="absolute inset-0 bg-ink/25" />
                    <div className="absolute inset-x-0 bottom-0 flex flex-col items-center gap-2 bg-gradient-to-t from-ink/80 to-transparent pb-7 pt-14">
                      <ScanLine className="h-5 w-5 text-cream/90" strokeWidth={2} />
                      <AnimatePresence mode="wait">
                        <motion.span
                          key={scanIdx}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -8 }}
                          className="text-[12.5px] font-semibold tracking-wide text-cream"
                        >
                          {SCAN_STEPS[scanIdx]}
                        </motion.span>
                      </AnimatePresence>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <ReviewSheet
        open={step === "review"}
        draft={draft}
        confidence={extract?.attributes?.confidence ?? {}}
        provider={source === "manual" ? "manual" : (extract?.provider ?? (prepared ? "fallback" : "manual"))}
        imageUrl={extract?.cutoutUrl ?? prepared?.previewUrl ?? null}
        saving={saving}
        savedFlash={savedFlash}
        onChange={setDraft}
        onSave={save}
        onRetake={resetForNext}
        onClose={resetForNext}
      />
    </Screen>
  );
}
