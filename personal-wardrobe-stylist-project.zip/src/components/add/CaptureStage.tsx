"use client";

import { motion } from "framer-motion";
import { Camera, CameraOff, ImagePlus, Keyboard, Loader2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { prepareImage, type PreparedImage } from "@/lib/imaging";
import { vibrate } from "@/lib/utils";

export type CaptureSource = "camera" | "upload";
type CamState = "starting" | "live" | "denied" | "unavailable";

/**
 * Phone-first capture: live viewfinder with a native-feel shutter, library
 * upload, and a manual-details escape hatch. Images are compressed on-device
 * (~200 KB) before any upload happens.
 */
export function CaptureStage({
  busy,
  onCapture,
  onManual,
}: {
  busy: boolean;
  onCapture: (prepared: PreparedImage, source: CaptureSource) => void;
  onManual: () => void;
}) {
  const [camState, setCamState] = useState<CamState>("starting");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const libraryRef = useRef<HTMLInputElement>(null);
  const camFileRef = useRef<HTMLInputElement>(null);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCamState("unavailable");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }
        setCamState("live");
      } catch {
        setCamState("denied");
      }
    })();
    return () => {
      cancelled = true;
      stopStream();
    };
  }, [stopStream]);

  const handleBlob = async (blob: Blob, source: CaptureSource) => {
    try {
      const prepared = await prepareImage(blob);
      stopStream(); // still photo replaces the live feed either way
      onCapture(prepared, source);
    } catch {
      /* unreadable file — picker stays up */
    }
  };

  const shutter = () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0 || busy) return;
    vibrate(14);
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    canvas.toBlob((b) => b && handleBlob(b, "camera"), "image/jpeg", 0.92);
  };

  const picking = busy;

  return (
    <div>
      {/* ------------------------------------------------ viewfinder */}
      <div className="relative aspect-[4/4.4] w-full overflow-hidden rounded-[28px] bg-ink shadow-lift">
        {camState === "live" ? (
          <>
            <video ref={videoRef} playsInline muted className="absolute inset-0 h-full w-full object-cover" />
            <div className="pointer-events-none absolute inset-6 rounded-[20px] border border-cream/50">
              <div className="absolute -left-px -top-px h-6 w-6 rounded-tl-[20px] border-l-[3px] border-t-[3px] border-cream" />
              <div className="absolute -right-px -top-px h-6 w-6 rounded-tr-[20px] border-r-[3px] border-t-[3px] border-cream" />
              <div className="absolute -bottom-px -left-px h-6 w-6 rounded-bl-[20px] border-b-[3px] border-l-[3px] border-cream" />
              <div className="absolute -bottom-px -right-px h-6 w-6 rounded-br-[20px] border-b-[3px] border-r-[3px] border-cream" />
            </div>
            <div className="absolute inset-x-0 top-6 text-center">
              <span className="rounded-full bg-ink/55 px-3.5 py-1.5 text-[11px] font-semibold tracking-wide text-cream backdrop-blur">
                Lay the garment flat · good light helps
              </span>
            </div>
          </>
        ) : camState === "starting" ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 bg-ink">
            <div className="skeleton h-16 w-16 rounded-full !bg-cream/10" />
            <span className="text-[12px] font-semibold tracking-wide text-cream/60">Waking the camera…</span>
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-3 bg-ink px-8 text-center">
            <CameraOff className="h-8 w-8 text-cream/50" strokeWidth={1.6} />
            <p className="text-[13px] leading-relaxed text-cream/70">
              Camera is off. Upload a photo from your library, or open the camera app and attach the shot.
            </p>
          </div>
        )}

        {picking && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-ink/70 backdrop-blur-sm">
            <Loader2 className="h-7 w-7 animate-spin text-cream" strokeWidth={2.2} />
            <span className="text-[12px] font-semibold tracking-wide text-cream">
              Trimming on-device, never the full file…
            </span>
          </div>
        )}

        {camState === "live" && !picking && (
          <div className="absolute inset-x-0 bottom-5 flex items-center justify-center gap-8">
            <button
              aria-label="Pick from library"
              onClick={() => libraryRef.current?.click()}
              className="flex h-12 w-12 items-center justify-center rounded-full bg-cream/18 backdrop-blur active:scale-90"
            >
              <ImagePlus className="h-5 w-5 text-cream" strokeWidth={2} />
            </button>
            <motion.button
              aria-label="Take photo"
              whileTap={{ scale: 0.9 }}
              onClick={shutter}
              className="flex h-[72px] w-[72px] items-center justify-center rounded-full bg-cream shadow-lift"
            >
              <span className="h-[58px] w-[58px] rounded-full border-2 border-ink/80" />
            </motion.button>
            <span className="h-12 w-12" />
          </div>
        )}
      </div>

      {/* ------------------------------------------------ secondary actions */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        {camState !== "live" ? (
          <button
            onClick={() => camFileRef.current?.click()}
            className="flex h-14 items-center justify-center gap-2 rounded-[20px] bg-ink text-[13.5px] font-bold text-cream shadow-soft active:scale-[0.97]"
          >
            <Camera className="h-[18px] w-[18px]" strokeWidth={2} />
            Open camera
          </button>
        ) : (
          <button
            onClick={() => libraryRef.current?.click()}
            className="flex h-14 items-center justify-center gap-2 rounded-[20px] bg-ink text-[13.5px] font-bold text-cream shadow-soft active:scale-[0.97]"
          >
            <ImagePlus className="h-[18px] w-[18px]" strokeWidth={2} />
            From library
          </button>
        )}
        <button
          onClick={() => libraryRef.current?.click()}
          className="flex h-14 items-center justify-center gap-2 rounded-[20px] bg-cream text-[13.5px] font-bold text-ink ring-1 ring-ink/10 active:scale-[0.97]"
        >
          <ImagePlus className="h-[18px] w-[18px]" strokeWidth={2} />
          Choose photo
        </button>
      </div>

      <button
        onClick={onManual}
        className="mt-4 flex w-full items-center justify-center gap-2 py-3 text-[12.5px] font-semibold text-muted active:scale-[0.98]"
      >
        <Keyboard className="h-4 w-4" strokeWidth={2} />
        No photo handy? Type it in manually
      </button>

      {/* native fallbacks */}
      <input
        ref={libraryRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleBlob(f, "upload");
          e.target.value = "";
        }}
      />
      <input
        ref={camFileRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleBlob(f, "camera");
          e.target.value = "";
        }}
      />
    </div>
  );
}
