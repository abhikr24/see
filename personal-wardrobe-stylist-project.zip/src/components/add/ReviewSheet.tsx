"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, RotateCcw, ScanLine, Sparkles } from "lucide-react";
import type { VisionAttributes } from "@shared/index";
import type { ReviewDraft } from "@/lib/addDraft";
import { cn, vibrate } from "@/lib/utils";
import { Sheet } from "@/components/ui/Sheet";
import { DraftFields } from "@/components/wardrobe/DraftFields";

type Confidence = VisionAttributes["confidence"];

/**
 * Post-scan confirmation bottom sheet: background-removed preview on top,
 * every detected attribute editable below, one-tap save. Designed for
 * rapid multi-add sessions on a phone.
 */
export function ReviewSheet({
  open,
  draft,
  confidence,
  provider,
  imageUrl,
  saving,
  savedFlash,
  onChange,
  onSave,
  onRetake,
  onClose,
}: {
  open: boolean;
  draft: ReviewDraft;
  confidence: Confidence;
  provider: "vision" | "fallback" | "manual" | null;
  imageUrl: string | null;
  saving: boolean;
  savedFlash: boolean;
  onChange: (next: ReviewDraft) => void;
  onSave: () => void;
  onRetake: () => void;
  onClose: () => void;
}) {
  return (
    <Sheet
      open={open}
      onClose={saving ? () => undefined : onClose}
      title="Quick check"
      subtitle={
        provider === "vision"
          ? "Auto-scanned by the vision service — correct anything it missed."
          : provider === "fallback"
            ? "Scanned on-device — fill in what you know, everything edits."
            : "Add the details — everything stays editable later."
      }
    >
      <div className="px-6 pt-1">
        {/* preview */}
        <div className="flex items-center gap-4 pb-2">
          <div className="relative h-32 w-32 shrink-0 overflow-hidden rounded-[22px] bg-gradient-to-br from-cream to-bronze-soft/50 ring-1 ring-ink/[0.06]">
            {imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={imageUrl}
                alt="Garment preview"
                className="absolute inset-0 h-full w-full object-contain p-1.5"
              />
            ) : (
              <div className="flex h-full items-center justify-center">
                <ScanLine className="h-7 w-7 text-muted/50" strokeWidth={1.6} />
              </div>
            )}
          </div>
          {provider === "vision" && (
            <div className="flex items-center gap-1.5 rounded-full bg-bronze-soft/70 px-3 py-2 text-[10.5px] font-bold text-bronze-deep">
              <Sparkles className="h-3 w-3" strokeWidth={2.4} />
              u2net cut-out · FashionCLIP labels
            </div>
          )}
          {provider === "fallback" && (
            <p className="text-[11.5px] leading-snug text-muted">
              No vision service right now — colours were read on your phone. Category, type and fabric stay
              editable below.
            </p>
          )}
        </div>

        <DraftFields draft={draft} onChange={onChange} confidence={confidence} />

        {/* footer */}
        <div className="sticky bottom-0 -mx-6 mt-6 bg-gradient-to-t from-cream via-cream/95 to-transparent px-6 pb-[max(env(safe-area-inset-bottom),16px)] pt-6">
          <div className="flex gap-3">
            <button
              aria-label="Retake photo"
              onClick={() => {
                vibrate(8);
                onRetake();
              }}
              disabled={saving}
              className="flex min-h-[52px] min-w-[52px] items-center justify-center rounded-full bg-paper ring-1 ring-ink/12 active:scale-95 disabled:opacity-40"
            >
              <RotateCcw className="h-5 w-5 text-ink" strokeWidth={2} />
            </button>
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={onSave}
              disabled={saving || !draft.name.trim()}
              className={cn(
                "flex min-h-[52px] flex-1 items-center justify-center gap-2 rounded-full text-[15px] font-bold shadow-lift transition-colors",
                savedFlash ? "bg-olive text-cream" : "bg-ink text-cream",
                (!draft.name.trim() || saving) && "opacity-50",
              )}
            >
              <AnimatePresence mode="wait" initial={false}>
                {savedFlash ? (
                  <motion.span
                    key="saved"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2"
                  >
                    <Check className="h-5 w-5" strokeWidth={2.6} />
                    In your closet
                  </motion.span>
                ) : saving ? (
                  <motion.span
                    key="saving"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-2"
                  >
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-cream/30 border-t-cream" />
                    Hanging it up…
                  </motion.span>
                ) : (
                  <motion.span key="cta" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}>
                    Add to closet
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </div>
      </div>
    </Sheet>
  );
}
