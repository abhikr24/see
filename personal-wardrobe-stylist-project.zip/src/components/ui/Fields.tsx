"use client";

import { Check } from "lucide-react";
import { PALETTE, isDark } from "@/lib/palette";
import { cn, vibrate } from "@/lib/utils";

export function FieldLabel({ children }: { children: React.ReactNode }) {
  return <div className="micro-label mb-2.5 text-muted">{children}</div>;
}

export function Chip({
  selected,
  onClick,
  children,
  small,
  className,
}: {
  selected: boolean;
  onClick: () => void;
  children: React.ReactNode;
  small?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => {
        vibrate(6);
        onClick();
      }}
      className={cn(
        "rounded-full font-semibold transition-all duration-150 active:scale-[0.93]",
        small ? "px-3.5 py-[7px] text-[12px]" : "px-4 py-2 text-[13px]",
        selected
          ? "bg-ink text-cream shadow-soft"
          : "bg-cream text-ink-2 ring-1 ring-ink/10",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function ColorDots({
  selected,
  onToggle,
}: {
  selected: string[];
  onToggle: (id: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-x-3 gap-y-3.5">
      {PALETTE.map((c) => {
        const on = selected.includes(c.id);
        return (
          <button
            key={c.id}
            type="button"
            title={c.name}
            aria-label={c.name}
            onClick={() => {
              vibrate(6);
              onToggle(c.id);
            }}
            className={cn(
              "relative flex h-9 w-9 items-center justify-center rounded-full transition-transform active:scale-90",
              on && "scale-105",
            )}
            style={{
              backgroundColor: c.hex,
              boxShadow: on
                ? `0 0 0 2px var(--color-cream), 0 0 0 4px var(--color-ink)`
                : "0 0 0 1px rgba(25,21,16,0.12) inset",
            }}
          >
            {on && (
              <Check
                className="h-3.5 w-3.5"
                strokeWidth={3}
                style={{ color: isDark(c.hex) ? "#fbf8f1" : "#191510" }}
              />
            )}
          </button>
        );
      })}
    </div>
  );
}

export function Segmented<T extends string | number>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex rounded-full bg-ink/[0.06] p-1">
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          onClick={() => {
            vibrate(6);
            onChange(o.value);
          }}
          className={cn(
            "flex-1 rounded-full py-2 text-[12.5px] font-semibold transition-all active:scale-95",
            value === o.value ? "bg-cream text-ink shadow-soft" : "text-muted",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
