"use client";

import { Sparkles } from "lucide-react";
import { ALL_SEASONS, FITS, MATERIALS, PATTERNS, type VisionAttributes } from "@shared/index";
import { colorById } from "@/lib/palette";
import {
  suggestedName,
  withCategory,
  type ReviewDraft,
} from "@/lib/addDraft";
import {
  CATEGORIES,
  FIT_LABELS,
  materialLabel,
  OCCASIONS,
  PATTERN_LABELS,
  SEASON_LABELS,
  SUBCATEGORIES,
  subcategoriesFor,
  type Category,
} from "@/lib/presets";
import { Chip, ColorDots, FieldLabel, Segmented } from "@/components/ui/Fields";

type Confidence = VisionAttributes["confidence"];

function AutoBadge({ value }: { value?: number }) {
  if (value == null) return null;
  return (
    <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-bronze-soft px-2 py-[3px] align-middle text-[9.5px] font-bold tracking-[0.06em] text-bronze-deep">
      <Sparkles className="h-2.5 w-2.5" strokeWidth={2.5} />
      AUTO{value > 0 ? ` · ${Math.round(value * 100)}%` : ""}
    </span>
  );
}

/**
 * The full editable wardrobe-attribute form. Used by the add-flow review
 * sheet AND the wardrobe item editor — every auto-detected field is one of
 * these controls, so nothing the pipeline writes is locked away.
 */
export function DraftFields({
  draft,
  onChange,
  confidence = {},
}: {
  draft: ReviewDraft;
  onChange: (next: ReviewDraft) => void;
  confidence?: Confidence;
}) {
  const patch = (p: Partial<ReviewDraft>) => onChange({ ...draft, ...p });

  const toggleColour = (id: string) => {
    const cur = draft.colors;
    if (cur.includes(id)) {
      if (cur.length > 1) patch({ colors: cur.filter((c) => c !== id) });
    } else if (cur.length < 2) {
      patch({ colors: [...cur, id] });
    } else {
      patch({ colors: [cur[0], id] });
    }
  };

  const toggleSeason = (id: string) => {
    const cur = draft.seasons;
    const next = cur.includes(id) ? cur.filter((s) => s !== id) : [...cur, id];
    if (next.length) patch({ seasons: next });
  };

  const toggleOccasion = (id: string) => {
    const cur = draft.occasions;
    patch({ occasions: cur.includes(id) ? cur.filter((o) => o !== id) : [...cur, id] });
  };

  return (
    <div>
      {/* name */}
      <div>
        <FieldLabel>Name</FieldLabel>
        <input
          value={draft.name}
          onChange={(e) => patch({ name: e.target.value })}
          placeholder="e.g. Oatmeal Knit"
          maxLength={80}
          className="h-12 w-full rounded-[16px] bg-paper px-4 text-[14.5px] font-semibold text-ink outline-none ring-1 ring-ink/10 placeholder:font-medium placeholder:text-muted/60 focus:ring-ink/30"
        />
      </div>

      {/* category */}
      <div className="pt-5">
        <FieldLabel>
          Category
          <AutoBadge value={confidence.category} />
        </FieldLabel>
        <div className="no-scrollbar -mx-6 flex gap-2 overflow-x-auto px-6 pb-1">
          {CATEGORIES.map((c) => (
            <Chip
              key={c.id}
              selected={draft.category === c.id}
              onClick={() => onChange(withCategory(draft, c.id as Category))}
              className="!px-5 !py-3"
            >
              {c.label}
            </Chip>
          ))}
        </div>
      </div>

      {/* subcategory */}
      <div className="pt-4">
        <FieldLabel>Type</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {subcategoriesFor(draft.category).map((s) => (
            <Chip
              key={s}
              selected={draft.subcategory === s}
              onClick={() => patch({ subcategory: s })}
              className="!py-2.5"
            >
              {SUBCATEGORIES[s]?.label ?? s}
            </Chip>
          ))}
        </div>
      </div>

      {/* colours */}
      <div className="pt-5">
        <FieldLabel>
          Colours · first pick is the main one
          <AutoBadge value={confidence.color} />
        </FieldLabel>
        <div className="rounded-[20px] bg-paper p-4 ring-1 ring-ink/[0.06]">
          <ColorDots selected={draft.colors} onToggle={toggleColour} />
          <div className="mt-3 flex items-center gap-1.5 text-[11px] font-medium text-muted">
            {draft.colors.map((c, i) => (
              <span key={c} className="flex items-center gap-1.5">
                <span
                  className="h-2.5 w-2.5 rounded-full ring-1 ring-ink/10"
                  style={{ backgroundColor: colorById(c).hex }}
                />
                {colorById(c).name}
                {i === 0 && draft.colors.length > 1 && (
                  <span className="text-muted/60">
                    (main) <span className="mx-0.5 text-muted/40">·</span>
                  </span>
                )}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* pattern */}
      <div className="pt-5">
        <FieldLabel>
          Pattern
          <AutoBadge value={confidence.pattern} />
        </FieldLabel>
        <div className="flex flex-wrap gap-2">
          {PATTERNS.map((p) => (
            <Chip key={p} selected={draft.pattern === p} onClick={() => patch({ pattern: p })} className="!py-2.5">
              {PATTERN_LABELS[p]}
            </Chip>
          ))}
        </div>
      </div>

      {/* material */}
      <div className="pt-5">
        <FieldLabel>Material · best guess is fine</FieldLabel>
        <div className="flex flex-wrap gap-2">
          <Chip selected={!draft.material} onClick={() => patch({ material: "" })} className="!py-2.5">
            Not sure
          </Chip>
          {MATERIALS.map((m) => (
            <Chip key={m} selected={draft.material === m} onClick={() => patch({ material: m })} className="!py-2.5">
              {materialLabel(m)}
            </Chip>
          ))}
        </div>
      </div>

      {/* fit + formality */}
      <div className="grid grid-cols-1 gap-5 pt-5">
        <div>
          <FieldLabel>Fit</FieldLabel>
          <Segmented
            options={FITS.map((f) => ({ value: f as string, label: FIT_LABELS[f] }))}
            value={draft.fit}
            onChange={(fit) => patch({ fit })}
          />
        </div>
        <div>
          <FieldLabel>
            Dress code
            <AutoBadge value={confidence.formality} />
          </FieldLabel>
          <Segmented
            options={[
              { value: 0, label: "Casual" },
              { value: 1, label: "Smart" },
              { value: 2, label: "Dressy" },
            ]}
            value={draft.formality}
            onChange={(formality) => patch({ formality })}
          />
        </div>
      </div>

      {/* seasons */}
      <div className="pt-5">
        <FieldLabel>
          Seasons
          <AutoBadge value={confidence.season} />
        </FieldLabel>
        <div className="flex gap-2">
          {ALL_SEASONS.map((s) => (
            <Chip
              key={s}
              selected={draft.seasons.includes(s)}
              onClick={() => toggleSeason(s)}
              className="flex-1 !px-0 !py-3 text-center"
            >
              {SEASON_LABELS[s]}
            </Chip>
          ))}
        </div>
      </div>

      {/* occasions */}
      <div className="pt-5">
        <FieldLabel>Wear it for</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {OCCASIONS.slice(0, 10).map((o) => (
            <Chip
              key={o.id}
              selected={draft.occasions.includes(o.id)}
              onClick={() => toggleOccasion(o.id)}
              small
              className="!py-2"
            >
              {o.label}
            </Chip>
          ))}
        </div>
      </div>

      {/* notes */}
      <div className="pt-5">
        <FieldLabel>Notes · optional</FieldLabel>
        <textarea
          value={draft.notes}
          onChange={(e) => patch({ notes: e.target.value })}
          rows={2}
          maxLength={500}
          placeholder="Alterations, care quirks, where you got it…"
          className="w-full resize-none rounded-[16px] bg-paper px-4 py-3 text-[13.5px] font-medium text-ink outline-none ring-1 ring-ink/10 placeholder:text-muted/60 focus:ring-ink/30"
        />
      </div>
    </div>
  );
}
