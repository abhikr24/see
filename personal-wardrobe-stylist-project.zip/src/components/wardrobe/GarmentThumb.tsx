import type { ClothingItem } from "@/db/schema";
import { colorById } from "@/lib/palette";
import { SUBCATEGORIES } from "@/lib/presets";
import { cn } from "@/lib/utils";
import { GarmentArt } from "./GarmentArt";

/** Anything renderable: a stored closet piece or a capsule preset pick. */
export type ThumbLike = Pick<ClothingItem, "name" | "subcategory" | "colors" | "imageUrl"> &
  Partial<Pick<ClothingItem, "cutoutUrl">>;

/** Renders a real photo when one exists, otherwise the illustrated garment. */
export function GarmentThumb({
  item,
  className,
  padded = true,
}: {
  item: ThumbLike;
  className?: string;
  padded?: boolean;
}) {
  if (item.imageUrl) {
    // background-removed cut-outs (webp) read best contained on the paper tint
    const isCutout = Boolean(item.cutoutUrl) || /\.webp($|\?)/.test(item.imageUrl);
    return (
      <div className={cn("relative overflow-hidden bg-bronze-soft/40", className)}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.imageUrl}
          alt={item.name}
          className={cn(
            "absolute inset-0 h-full w-full",
            isCutout ? "object-contain p-[6%]" : "object-cover",
          )}
          draggable={false}
        />
      </div>
    );
  }
  const art = SUBCATEGORIES[item.subcategory]?.art ?? "folded";
  const hex = colorById(item.colors[0]).hex;
  return (
    <div className={cn("flex items-center justify-center", className)}>
      <GarmentArt art={art} hex={hex} className={cn("h-full w-full", padded && "p-[8%]")} />
    </div>
  );
}
