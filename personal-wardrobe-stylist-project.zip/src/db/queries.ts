import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  clothingItems,
  outfits,
  profiles,
  wearLogs,
  type ClothingItem,
  type Outfit,
  type Profile,
} from "@/db/schema";
import { buildAlternatives, buildOutfit, type StylistContext } from "@/lib/engine";
import { CAPSULE, type Category } from "@/lib/presets";
import { getWeather, type Weather } from "@/lib/weather";
import { todayKey } from "@/lib/utils";

/* ---------------------------------------------------------------- profile */

export async function getProfile(): Promise<Profile> {
  const rows = await db.select().from(profiles).where(eq(profiles.id, 1));
  if (rows[0]) return rows[0];
  await db.insert(profiles).values({ id: 1 }).onConflictDoNothing();
  const again = await db.select().from(profiles).where(eq(profiles.id, 1));
  return again[0];
}

/* ------------------------------------------------------------------ items */

export async function listItems(): Promise<ClothingItem[]> {
  return db.select().from(clothingItems).orderBy(clothingItems.createdAt);
}

export async function itemsByIds(ids: string[]): Promise<ClothingItem[]> {
  if (!ids.length) return [];
  const rows = await db.select().from(clothingItems);
  const map = new Map(rows.map((r) => [r.id, r]));
  return ids.map((id) => map.get(id)).filter((x): x is ClothingItem => Boolean(x));
}

export async function seedCapsule(keys: string[]): Promise<void> {
  const chosen = CAPSULE.filter((c) => keys.includes(c.key));
  if (!chosen.length) return;
  const existing = await db.select({ name: clothingItems.name }).from(clothingItems);
  const names = new Set(existing.map((e) => e.name));
  const fresh = chosen.filter((c) => !names.has(c.name));
  if (!fresh.length) return;
  await db.insert(clothingItems).values(
    fresh.map((c) => ({
      name: c.name,
      subcategory: c.subcategory,
      category: CAPSULE_CATEGORY(c.subcategory),
      colors: c.colors,
      formality: c.formality,
      warmth: c.warmth,
      occasions: c.occasions,
      source: "capsule",
    })),
  );
}

function CAPSULE_CATEGORY(sub: string): Category {
  const found = Object.entries({
    top: ["tshirt", "shirt", "polo", "blouse", "knit", "turtleneck", "hoodie", "tank", "cardigan"],
    bottom: ["jeans", "trousers", "chinos", "shorts", "skirt"],
    footwear: ["sneakers", "boots", "loafers", "heels", "sandals"],
    outerwear: ["jacket", "blazer", "coat"],
  }).find(([, list]) => list.includes(sub));
  return (found?.[0] as Category) ?? "accessory";
}

/** Editable wardrobe fields — every auto-detected attribute can be corrected. */
export type ItemPatch = Partial<
  Pick<
    ClothingItem,
    | "name"
    | "category"
    | "subcategory"
    | "colors"
    | "pattern"
    | "material"
    | "fit"
    | "formality"
    | "warmth"
    | "seasons"
    | "occasions"
    | "notes"
    | "favorite"
    | "imageUrl"
    | "cutoutUrl"
  >
>;

export async function getItem(id: string): Promise<ClothingItem | null> {
  const rows = await db.select().from(clothingItems).where(eq(clothingItems.id, id));
  return rows[0] ?? null;
}

export async function updateItemFields(id: string, patch: ItemPatch): Promise<void> {
  if (!Object.keys(patch).length) return;
  await db.update(clothingItems).set(patch).where(eq(clothingItems.id, id));
}

/* ---------------------------------------------------------------- outfits */

export type OutfitBundle = { outfit: Outfit; items: ClothingItem[] };

export type TodayData = {
  profile: Profile;
  weather: Weather;
  occasion: string;
  date: string;
  main: OutfitBundle | null;
  alts: OutfitBundle[];
  missing: Category[];
  itemCount: number;
};

function stylistCtx(profile: Profile, weather: Weather, occasion: string, salt = 0): StylistContext {
  return { profile, occasion, tempC: weather.tempC, weatherCode: weather.code, salt };
}

const ESSENTIALS: Category[] = ["top", "bottom", "footwear"];

async function insertOutfit(
  date: string,
  occasion: string,
  weather: Weather,
  items: ClothingItem[],
  reasons: string[],
  isMain: boolean,
): Promise<Outfit> {
  const rows = await db
    .insert(outfits)
    .values({
      date,
      occasion,
      tempC: weather.tempC,
      weatherLabel: weather.label,
      weatherCode: weather.code,
      isMain,
      itemIds: items.map((i) => i.id),
      reasons,
    })
    .returning();
  return rows[0];
}

export async function getTodayData(): Promise<TodayData> {
  const profile = await getProfile();
  const weather = await getWeather(profile);
  const date = todayKey();
  const occasion = profile.lastOccasion || "daily";
  const items = await listItems();

  const mains = await db
    .select()
    .from(outfits)
    .where(and(eq(outfits.date, date), eq(outfits.isMain, true), eq(outfits.occasion, occasion)))
    .orderBy(desc(outfits.createdAt));
  let mainRow = mains.find((o) => !o.dismissedAt) ?? null;

  if (!mainRow && items.length) {
    const built = buildOutfit(items, stylistCtx(profile, weather, occasion));
    const lacksEssentials = built.missing.some((m) => ESSENTIALS.includes(m));
    if (!lacksEssentials && built.items.length >= 3) {
      mainRow = await insertOutfit(date, occasion, weather, built.items, built.reasons, true);
      // Pre-compute two alternative takes and persist them quietly.
      for (const alt of buildAlternatives(items, stylistCtx(profile, weather, occasion), built)) {
        await insertOutfit(date, occasion, weather, alt.items, alt.reasons, false);
      }
    } else {
      return {
        profile,
        weather,
        occasion,
        date,
        main: null,
        alts: [],
        missing: built.missing.filter((m) => ESSENTIALS.includes(m)),
        itemCount: items.length,
      };
    }
  }

  const altRows = mainRow
    ? await db
        .select()
        .from(outfits)
        .where(and(eq(outfits.date, date), eq(outfits.isMain, false), eq(outfits.occasion, occasion)))
        .orderBy(outfits.createdAt)
    : [];

  const toBundle = async (o: Outfit): Promise<OutfitBundle> => ({
    outfit: o,
    items: await itemsByIds(o.itemIds),
  });

  return {
    profile,
    weather,
    occasion,
    date,
    main: mainRow ? await toBundle(mainRow) : null,
    alts: (await Promise.all(altRows.map(toBundle))).filter((b) => b.items.length >= 3),
    missing: [],
    itemCount: items.length,
  };
}

/** Dismiss today's mains + drop alts, then generate a fresh bundle. */
export async function regenerateToday(occasion: string, salt = 1, avoidIds: string[] = []) {
  const profile = await getProfile();
  const weather = await getWeather(profile);
  const date = todayKey();
  const items = await listItems();

  await db
    .update(outfits)
    .set({ dismissedAt: new Date() })
    .where(and(eq(outfits.date, date), eq(outfits.isMain, true), eq(outfits.occasion, occasion)));
  await db
    .delete(outfits)
    .where(and(eq(outfits.date, date), eq(outfits.isMain, false), eq(outfits.occasion, occasion)));

  if (!items.length) return;
  const ctx = { ...stylistCtx(profile, weather, occasion, salt), avoidIds };
  const built = buildOutfit(items, ctx);
  if (built.missing.some((m) => ESSENTIALS.includes(m)) || built.items.length < 3) return;
  await insertOutfit(date, occasion, weather, built.items, built.reasons, true);
  for (const alt of buildAlternatives(items, ctx, built)) {
    await insertOutfit(date, occasion, weather, alt.items, alt.reasons, false);
  }
}

export async function getOutfitBundle(id: string): Promise<(OutfitBundle & { profile: Profile }) | null> {
  const rows = await db.select().from(outfits).where(eq(outfits.id, id));
  const outfit = rows[0];
  if (!outfit) return null;
  const profile = await getProfile();
  return { outfit, items: await itemsByIds(outfit.itemIds), profile };
}

/* ---------------------------------------------------------------- history */

export async function getHistory(): Promise<OutfitBundle[]> {
  const rows = await db
    .select()
    .from(outfits)
    .where(eq(outfits.isMain, true))
    .orderBy(desc(outfits.date), desc(outfits.createdAt))
    .limit(60);
  return Promise.all(rows.map(async (o) => ({ outfit: o, items: await itemsByIds(o.itemIds) })));
}

/* ----------------------------------------------------------------- stats */

export type ProfileStats = {
  itemCount: number;
  totalWears: number;
  savedCount: number;
  streak: number;
  mostWorn: { name: string; times: number } | null;
  colourCounts: { id: string; count: number }[];
};

export async function getProfileStats(): Promise<ProfileStats> {
  const items = await db.select().from(clothingItems);
  const savedCount = await db
    .select({ n: sql<number>`count(*)` })
    .from(outfits)
    .where(sql`${outfits.savedAt} is not null`);
  const logs = await db.select({ date: wearLogs.date }).from(wearLogs);

  // streak of consecutive days with a worn log, ending today/yesterday
  const days = new Set(logs.map((l) => l.date));
  let streak = 0;
  const cursor = new Date();
  if (!days.has(todayKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  while (days.has(todayKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  const colourCounts = new Map<string, number>();
  for (const i of items) {
    const c = i.colors[0];
    if (c) colourCounts.set(c, (colourCounts.get(c) ?? 0) + 1);
  }

  const most = items.filter((i) => i.timesWorn > 0).sort((a, b) => b.timesWorn - a.timesWorn)[0];

  return {
    itemCount: items.length,
    totalWears: items.reduce((s, i) => s + i.timesWorn, 0),
    savedCount: Number(savedCount[0]?.n ?? 0),
    streak,
    mostWorn: most ? { name: most.name, times: most.timesWorn } : null,
    colourCounts: [...colourCounts.entries()]
      .map(([id, count]) => ({ id, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8),
  };
}
