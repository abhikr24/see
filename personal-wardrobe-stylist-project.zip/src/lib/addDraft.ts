/** Review-sheet draft state for the add flow, plus converters. */
import type { Season, VisionAttributes } from "@shared/index";
import { colorById } from "@/lib/palette";
import { subcategoriesFor, SUBCATEGORIES, type Category } from "@/lib/presets";

export type ReviewDraft = {
  name: string;
  category: Category;
  subcategory: string;
  colors: string[];
  pattern: string;
  material: string;
  fit: string;
  formality: 0 | 1 | 2;
  seasons: string[];
  occasions: string[];
  notes: string;
};

export function suggestedName(colors: string[], subcategory: string): string {
  const colour = colorById(colors[0] ?? "stone").name;
  const sub = SUBCATEGORIES[subcategory]?.label ?? "Piece";
  return `${colour} ${sub}`;
}

export function draftFromAttributes(a: VisionAttributes): ReviewDraft {
  const category = (["top", "bottom", "footwear", "outerwear", "accessory"].includes(a.category)
    ? a.category
    : "top") as Category;
  const subcategory =
    a.subcategory && SUBCATEGORIES[a.subcategory]?.category === category
      ? a.subcategory
      : subcategoriesFor(category)[0];
  const draft: ReviewDraft = {
    name: "",
    category,
    subcategory,
    colors: a.colors.slice(0, 2),
    pattern: a.pattern,
    material: a.material,
    fit: a.fit,
    formality: a.formality,
    seasons: [...a.seasons],
    occasions: [],
    notes: "",
  };
  draft.name = suggestedName(draft.colors, draft.subcategory);
  return draft;
}

export function blankDraft(): ReviewDraft {
  const draft: ReviewDraft = {
    name: "",
    category: "top",
    subcategory: "tshirt",
    colors: ["white"],
    pattern: "solid",
    material: "",
    fit: "regular",
    formality: 0,
    seasons: ["spring", "summer", "autumn", "winter"] as Season[],
    occasions: ["daily"],
    notes: "",
  };
  draft.name = suggestedName(draft.colors, draft.subcategory);
  return draft;
}

/** Keep category/subcategory consistent when the user switches category. */
export function withCategory(draft: ReviewDraft, category: Category): ReviewDraft {
  const sub = SUBCATEGORIES[draft.subcategory]?.category === category
    ? draft.subcategory
    : subcategoriesFor(category)[0];
  const next = { ...draft, category, subcategory: sub };
  next.name = suggestedName(next.colors, sub);
  return next;
}

/** Rehydrate a stored item into an editable draft (edit mode in the item sheet). */
export function draftFromItem(item: {
  name: string;
  category: string;
  subcategory: string;
  colors: string[];
  pattern: string;
  material: string;
  fit: string;
  formality: number;
  seasons: string[];
  occasions: string[];
  notes: string;
}): ReviewDraft {
  const category = (["top", "bottom", "footwear", "outerwear", "accessory"].includes(item.category)
    ? item.category
    : "top") as Category;
  return {
    name: item.name,
    category,
    subcategory: item.subcategory,
    colors: item.colors.slice(0, 2),
    pattern: item.pattern,
    material: item.material,
    fit: item.fit,
    formality: (item.formality === 2 ? 2 : item.formality === 1 ? 1 : 0) as 0 | 1 | 2,
    seasons: item.seasons.length ? [...item.seasons] : ["spring", "summer", "autumn", "winter"],
    occasions: [...item.occasions],
    notes: item.notes,
  };
}
