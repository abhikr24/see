/**
 * On-device image preparation for the add flow. Nothing leaves the phone until
 * the compressed ~200 KB payload is uploaded; the raw camera file never does.
 */

export type PreparedImage = {
  blob: Blob;
  /** object-URL for instant preview */
  previewUrl: string;
  width: number;
  height: number;
  bytes: number;
  sha256: string;
  /** Up to 2 dominant garment colours as hex — feeds the fallback mapper. */
  paletteHexes: string[];
};

const TARGET_BYTES = 200_000; // ~200 KB
const MAX_DIM = 1400;
const MIN_DIM = 480;
const QUALITY_LADDER = [0.86, 0.78, 0.68, 0.58, 0.48];

async function loadBitmap(file: Blob): Promise<ImageBitmap> {
  return createImageBitmap(file);
}

function drawScaled(bitmap: ImageBitmap, dim: number): HTMLCanvasElement {
  const scale = Math.min(1, dim / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  return canvas;
}

function toBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("encode failed"))),
      "image/jpeg",
      quality,
    );
  });
}

/** Compress to ≤ ~200 KB by walking quality down, then dimensions. */
export async function compressOnDevice(file: Blob): Promise<{
  blob: Blob;
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
}> {
  const bitmap = await loadBitmap(file);
  try {
    let dim = MAX_DIM;
    let canvas = drawScaled(bitmap, dim);
    for (const q of QUALITY_LADDER) {
      const blob = await toBlob(canvas, q);
      if (blob.size <= TARGET_BYTES) {
        return { blob, canvas, width: canvas.width, height: canvas.height };
      }
    }
    // still too large → shrink dimensions and retry top quality
    while (dim > MIN_DIM) {
      dim = Math.round(dim * 0.72);
      canvas = drawScaled(bitmap, dim);
      const blob = await toBlob(canvas, 0.6);
      if (blob.size <= TARGET_BYTES) {
        return { blob, canvas, width: canvas.width, height: canvas.height };
      }
    }
    const blob = await toBlob(canvas, 0.42);
    return { blob, canvas, width: canvas.width, height: canvas.height };
  } finally {
    bitmap.close();
  }
}

/**
 * Dominant colours via a coarse histogram on a tiny canvas. Mid-crop first
 * (garments get laid flat and centred), near-background pixels are ignored.
 * Returns up to `max` hex colours, most frequent first.
 */
export function dominantPalette(source: HTMLCanvasElement, max = 2): string[] {
  const ctx = source.getContext("2d", { willReadFrequently: true });
  if (!ctx) return [];
  const w = source.width;
  const h = source.height;
  // centre crop — the garment zone given the app's framing guidance
  const cw = Math.round(w * 0.62);
  const ch = Math.round(h * 0.62);
  const cx = Math.round((w - cw) / 2);
  const cy = Math.round((h - ch) / 2);
  let data: Uint8ClampedArray;
  try {
    data = ctx.getImageData(cx, cy, cw, ch).data;
  } catch {
    return [];
  }

  const buckets = new Map<string, { n: number; r: number; g: number; b: number }>();
  const total = data.length / 4;
  const step = Math.max(1, Math.floor(total / 2400));
  for (let i = 0; i < total; i += step) {
    const o = i * 4;
    const a = data[o + 3];
    if (a < 140) continue;
    const r = data[o];
    const g = data[o + 1];
    const b = data[o + 2];
    // quantise to 4 bits/channel
    const key = `${r >> 4}-${g >> 4}-${b >> 4}`;
    const bucket = buckets.get(key) ?? { n: 0, r: 0, g: 0, b: 0 };
    bucket.n += 1;
    bucket.r += r;
    bucket.g += g;
    bucket.b += b;
    buckets.set(key, bucket);
  }
  if (!buckets.size) return [];

  const ranked = [...buckets.values()]
    .map((b) => ({
      n: b.n,
      hex: rgbToHex(Math.round(b.r / b.n), Math.round(b.g / b.n), Math.round(b.b / b.n)),
    }))
    .sort((a, b) => b.n - a.n);

  // drop near-white background if it dominates the crop (flat-lay on a sheet)
  const head = ranked[0];
  if (head && isNearBackground(head.hex) && head.n / (total / step) > 0.42) ranked.shift();

  const picked: string[] = [];
  for (const r of ranked) {
    if (picked.every((p) => colourDistance(p, r.hex) > 0.14)) picked.push(r.hex);
    if (picked.length >= max) break;
  }
  return picked;
}

function rgbToHex(r: number, g: number, b: number): string {
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

function isNearBackground(hex: string): boolean {
  const v = parseInt(hex.slice(1), 16);
  const r = (v >> 16) & 255;
  const g = (v >> 8) & 255;
  const b = v & 255;
  return r > 232 && g > 230 && b > 222;
}

/** Cheap RGB distance 0..~1.7 — good enough for de-duping histogram peaks. */
function colourDistance(a: string, b: string): number {
  const pa = parseInt(a.slice(1), 16);
  const pb = parseInt(b.slice(1), 16);
  const dr = (((pa >> 16) & 255) - ((pb >> 16) & 255)) / 255;
  const dg = (((pa >> 8) & 255) - ((pb >> 8) & 255)) / 255;
  const db = ((pa & 255) - (pb & 255)) / 255;
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

export async function sha256Hex(buf: ArrayBuffer): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", buf.slice(0));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Full preparation pipeline for one picked/shot photo. */
export async function prepareImage(file: Blob): Promise<PreparedImage> {
  const { blob, canvas, width, height } = await compressOnDevice(file);
  const bytes = blob.size;
  const [sha256, paletteHexes] = await Promise.all([
    sha256Hex(await blob.arrayBuffer()),
    Promise.resolve(dominantPalette(canvas, 2)),
  ]);
  return {
    blob,
    previewUrl: URL.createObjectURL(blob),
    width,
    height,
    bytes,
    sha256,
    paletteHexes,
  };
}
