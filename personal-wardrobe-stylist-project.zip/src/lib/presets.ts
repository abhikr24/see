/**
 * Wardrobe taxonomy, occasion metadata and the starter capsule closet.
 */

export type Category = "top" | "bottom" | "footwear" | "outerwear" | "accessory";

export const CATEGORIES: { id: Category; label: string; plural: string }[] = [
  { id: "top", label: "Top", plural: "Tops" },
  { id: "bottom", label: "Bottom", plural: "Bottoms" },
  { id: "footwear", label: "Footwear", plural: "Footwear" },
  { id: "outerwear", label: "Outerwear", plural: "Outerwear" },
  { id: "accessory", label: "Accessory", plural: "Accessories" },
];

export const SUBCATEGORIES: Record<
  string,
  { label: string; category: Category; art: string }
> = {
  tshirt: { label: "T-Shirt", category: "top", art: "tshirt" },
  shirt: { label: "Shirt", category: "top", art: "shirt" },
  polo: { label: "Polo", category: "top", art: "polo" },
  blouse: { label: "Blouse", category: "top", art: "blouse" },
  knit: { label: "Knit Sweater", category: "top", art: "knit" },
  turtleneck: { label: "Turtleneck", category: "top", art: "turtleneck" },
  hoodie: { label: "Hoodie", category: "top", art: "hoodie" },
  tank: { label: "Tank", category: "top", art: "tank" },
  cardigan: { label: "Cardigan", category: "top", art: "cardigan" },
  jeans: { label: "Jeans", category: "bottom", art: "jeans" },
  trousers: { label: "Trousers", category: "bottom", art: "trousers" },
  chinos: { label: "Chinos", category: "bottom", art: "trousers" },
  shorts: { label: "Shorts", category: "bottom", art: "shorts" },
  skirt: { label: "Skirt", category: "bottom", art: "skirt" },
  sneakers: { label: "Sneakers", category: "footwear", art: "sneakers" },
  boots: { label: "Boots", category: "footwear", art: "boots" },
  loafers: { label: "Loafers", category: "footwear", art: "loafers" },
  heels: { label: "Heels", category: "footwear", art: "heels" },
  sandals: { label: "Sandals", category: "footwear", art: "sandals" },
  jacket: { label: "Jacket", category: "outerwear", art: "jacket" },
  blazer: { label: "Blazer", category: "outerwear", art: "blazer" },
  coat: { label: "Coat", category: "outerwear", art: "coat" },
  watch: { label: "Watch", category: "accessory", art: "watch" },
  belt: { label: "Belt", category: "accessory", art: "belt" },
  scarf: { label: "Scarf", category: "accessory", art: "scarf" },
  bag: { label: "Bag", category: "accessory", art: "bag" },
  cap: { label: "Cap", category: "accessory", art: "cap" },
  beanie: { label: "Beanie", category: "accessory", art: "beanie" },
  sunglasses: { label: "Sunglasses", category: "accessory", art: "sunglasses" },
  necklace: { label: "Necklace", category: "accessory", art: "necklace" },
};

export const STYLE_TAGS = [
  "Minimal",
  "Classic",
  "Smart casual",
  "Streetwear",
  "Quiet luxury",
  "Sporty",
  "Bohemian",
  "Formal",
  "Trendy",
  "Vintage",
];

export type OccasionDef = {
  id: string;
  label: string;
  blurb: string;
  formality: number; // style target 0 casual · 1 smart · 2 formal
  sport?: boolean;
};

export const OCCASIONS: OccasionDef[] = [
  { id: "daily", label: "Daily", blurb: "Easy, effortless", formality: 0 },
  { id: "college", label: "College", blurb: "Comfortable all day", formality: 0 },
  { id: "office", label: "Office", blurb: "Sharp, not stiff", formality: 1 },
  { id: "interview", label: "Interview", blurb: "Instant credibility", formality: 2 },
  { id: "date", label: "Date", blurb: "Considered, a little bold", formality: 1 },
  { id: "wedding", label: "Wedding", blurb: "Ceremony-ready", formality: 2 },
  { id: "party", label: "Party", blurb: "After-dark energy", formality: 1 },
  { id: "family", label: "Family function", blurb: "Polished, warm", formality: 1 },
  { id: "travel", label: "Travel", blurb: "Soft layers, long hours", formality: 0 },
  { id: "dinner", label: "Dinner", blurb: "Refined evening", formality: 1 },
  { id: "gym", label: "Gym", blurb: "Move, sweat, repeat", formality: 0, sport: true },
  { id: "festival", label: "Festival", blurb: "Expressive, playful", formality: 1 },
];

export const OCCASION_BY_ID: Record<string, OccasionDef> = Object.fromEntries(
  OCCASIONS.map((o) => [o.id, o]),
);

/** Subcategory keys that belong to a category, in display order. */
export function subcategoriesFor(category: Category): string[] {
  return Object.entries(SUBCATEGORIES)
    .filter(([, v]) => v.category === category)
    .map(([k]) => k);
}

export const PATTERN_LABELS: Record<string, string> = {
  solid: "Solid",
  striped: "Striped",
  checked: "Checked",
  floral: "Floral",
  graphic: "Graphic",
  dotted: "Dotted",
  camo: "Camo",
};

export const SEASON_LABELS: Record<string, string> = {
  spring: "Spring",
  summer: "Summer",
  autumn: "Autumn",
  winter: "Winter",
};

export const FIT_LABELS: Record<string, string> = {
  slim: "Slim",
  regular: "Regular",
  relaxed: "Relaxed",
  oversized: "Oversized",
};

export function materialLabel(id: string): string {
  if (!id) return "Not sure";
  return id.charAt(0).toUpperCase() + id.slice(1);
}

/** Occasion ids may be "custom:Something" — normalise for display + logic. */
export function occasionLabel(id: string): string {
  if (id.startsWith("custom:")) return id.slice(7);
  return OCCASION_BY_ID[id]?.label ?? "Daily";
}

export function occasionFormality(id: string): number {
  if (id.startsWith("custom:")) return 1;
  return OCCASION_BY_ID[id]?.formality ?? 1;
}

export type CapsulePreset = {
  key: string;
  name: string;
  subcategory: string;
  colors: string[];
  formality: number;
  warmth: number;
  occasions: string[];
  essential?: boolean;
};

export const CAPSULE: CapsulePreset[] = [
  { key: "white-tee", name: "White Tee", subcategory: "tshirt", colors: ["white"], formality: 0, warmth: 0, occasions: ["daily", "college", "travel", "gym", "festival"], essential: true },
  { key: "stripe-tee", name: "Breton Stripe Tee", subcategory: "tshirt", colors: ["navy", "white"], formality: 0, warmth: 0, occasions: ["daily", "college", "travel", "date"], essential: true },
  { key: "oxford", name: "Blue Oxford Shirt", subcategory: "shirt", colors: ["sky"], formality: 1, warmth: 1, occasions: ["office", "interview", "college", "dinner", "family"], essential: true },
  { key: "evening-shirt", name: "Black Evening Shirt", subcategory: "shirt", colors: ["black"], formality: 2, warmth: 1, occasions: ["party", "dinner", "date", "wedding"] },
  { key: "linen-shirt", name: "Sand Linen Shirt", subcategory: "shirt", colors: ["tan"], formality: 1, warmth: 0, occasions: ["daily", "travel", "dinner", "festival"], essential: true },
  { key: "navy-polo", name: "Navy Polo", subcategory: "polo", colors: ["navy"], formality: 1, warmth: 0, occasions: ["daily", "college", "office", "dinner"] },
  { key: "oat-knit", name: "Oatmeal Knit", subcategory: "knit", colors: ["ivory"], formality: 1, warmth: 2, occasions: ["daily", "office", "family", "travel", "date"], essential: true },
  { key: "black-tneck", name: "Black Turtleneck", subcategory: "turtleneck", colors: ["black"], formality: 2, warmth: 2, occasions: ["office", "interview", "date", "dinner", "party"] },
  { key: "grey-hoodie", name: "Grey Hoodie", subcategory: "hoodie", colors: ["slate"], formality: 0, warmth: 2, occasions: ["daily", "gym", "travel", "college", "festival"] },
  { key: "training-tee", name: "Training Tee", subcategory: "tshirt", colors: ["charcoal"], formality: 0, warmth: 0, occasions: ["gym", "daily"] },
  { key: "blouse", name: "Ivory Blouse", subcategory: "blouse", colors: ["ivory"], formality: 2, warmth: 1, occasions: ["office", "interview", "dinner", "wedding", "family"] },
  { key: "camel-cardigan", name: "Camel Cardigan", subcategory: "cardigan", colors: ["camel"], formality: 1, warmth: 2, occasions: ["daily", "office", "family", "dinner"] },
  { key: "indigo-jeans", name: "Indigo Jeans", subcategory: "jeans", colors: ["denim"], formality: 0, warmth: 1, occasions: ["daily", "college", "travel", "date", "party", "festival"], essential: true },
  { key: "black-trousers", name: "Black Trousers", subcategory: "trousers", colors: ["black"], formality: 2, warmth: 1, occasions: ["office", "interview", "wedding", "dinner", "party"], essential: true },
  { key: "khaki-chinos", name: "Khaki Chinos", subcategory: "chinos", colors: ["tan"], formality: 1, warmth: 1, occasions: ["office", "daily", "college", "family", "dinner"], essential: true },
  { key: "charcoal-trousers", name: "Charcoal Trousers", subcategory: "trousers", colors: ["charcoal"], formality: 2, warmth: 1, occasions: ["interview", "office", "wedding", "dinner"] },
  { key: "slip-skirt", name: "Blush Slip Skirt", subcategory: "skirt", colors: ["blush"], formality: 2, warmth: 0, occasions: ["date", "dinner", "wedding", "party"] },
  { key: "stone-shorts", name: "Stone Shorts", subcategory: "shorts", colors: ["stone"], formality: 0, warmth: 0, occasions: ["daily", "travel", "gym", "festival"] },
  { key: "track-shorts", name: "Track Shorts", subcategory: "shorts", colors: ["charcoal"], formality: 0, warmth: 0, occasions: ["gym"] },
  { key: "white-sneakers", name: "White Sneakers", subcategory: "sneakers", colors: ["white"], formality: 0, warmth: 1, occasions: ["daily", "college", "travel", "date", "festival"], essential: true },
  { key: "runners", name: "Running Shoes", subcategory: "sneakers", colors: ["slate"], formality: 0, warmth: 1, occasions: ["gym", "travel"] },
  { key: "chelsea-boots", name: "Chelsea Boots", subcategory: "boots", colors: ["chocolate"], formality: 1, warmth: 1, occasions: ["office", "date", "dinner", "party", "family"], essential: true },
  { key: "tan-loafers", name: "Tan Loafers", subcategory: "loafers", colors: ["tan"], formality: 1, warmth: 0, occasions: ["office", "interview", "dinner", "wedding", "family"] },
  { key: "black-heels", name: "Black Heels", subcategory: "heels", colors: ["black"], formality: 2, warmth: 0, occasions: ["wedding", "party", "dinner", "interview", "date"] },
  { key: "sandals", name: "Leather Sandals", subcategory: "sandals", colors: ["chocolate"], formality: 0, warmth: 0, occasions: ["daily", "travel", "festival"] },
  { key: "camel-trench", name: "Camel Trench", subcategory: "coat", colors: ["camel"], formality: 1, warmth: 1, occasions: ["office", "dinner", "date", "travel", "family"], essential: true },
  { key: "denim-jacket", name: "Denim Jacket", subcategory: "jacket", colors: ["denim"], formality: 0, warmth: 1, occasions: ["daily", "college", "travel", "festival", "party"], essential: true },
  { key: "navy-blazer", name: "Navy Blazer", subcategory: "blazer", colors: ["navy"], formality: 2, warmth: 1, occasions: ["office", "interview", "wedding", "dinner"], essential: true },
  { key: "olive-bomber", name: "Olive Bomber", subcategory: "jacket", colors: ["olive"], formality: 0, warmth: 1, occasions: ["daily", "college", "travel", "party", "festival"] },
  { key: "wool-coat", name: "Charcoal Wool Coat", subcategory: "coat", colors: ["charcoal"], formality: 2, warmth: 2, occasions: ["office", "interview", "wedding", "dinner", "date"] },
  { key: "watch", name: "Steel Watch", subcategory: "watch", colors: ["slate"], formality: 1, warmth: 0, occasions: ["office", "interview", "daily", "dinner", "wedding", "date", "family"] },
  { key: "belt", name: "Brown Leather Belt", subcategory: "belt", colors: ["chocolate"], formality: 1, warmth: 0, occasions: ["office", "interview", "dinner", "wedding", "family"] },
  { key: "tote", name: "Canvas Tote", subcategory: "bag", colors: ["ivory"], formality: 0, warmth: 0, occasions: ["daily", "college", "travel", "festival"] },
  { key: "scarf", name: "Burgundy Scarf", subcategory: "scarf", colors: ["burgundy"], formality: 1, warmth: 1, occasions: ["daily", "office", "date", "family", "dinner"] },
  { key: "sunglasses", name: "Round Sunglasses", subcategory: "sunglasses", colors: ["black"], formality: 0, warmth: 0, occasions: ["daily", "travel", "festival", "date"] },
  { key: "cap", name: "Wool Cap", subcategory: "cap", colors: ["black"], formality: 0, warmth: 1, occasions: ["daily", "college", "travel", "gym", "festival"] },
];

export const DEFAULT_CAPSULE_KEYS = CAPSULE.filter((c) => c.essential).map((c) => c.key);
