/** Storage key hygiene — guards the media route against traversal. */
import { describe, expect, it } from "vitest";
import { sanitizeKey, uploadDir } from "./storage";

describe("sanitizeKey", () => {
  it("accepts content-hash style keys", () => {
    expect(sanitizeKey("a94f8e.cutout.webp")).toBe("a94f8e.cutout.webp");
    expect(sanitizeKey("deadbeef.jpg")).toBe("deadbeef.jpg");
  });

  it("rejects traversal and nested paths", () => {
    expect(sanitizeKey("../etc/passwd")).toBeNull();
    expect(sanitizeKey("a/b")).toBeNull();
    expect(sanitizeKey("..")).toBeNull();
    expect(sanitizeKey("")).toBeNull();
    expect(sanitizeKey(".hidden")).toBeNull();
    expect(sanitizeKey(`x`.repeat(200))).toBeNull();
  });
});

describe("uploadDir", () => {
  it("defaults to .data/uploads inside the project", () => {
    expect(uploadDir()).toContain(".data");
  });
});
