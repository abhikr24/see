/**
 * Blob storage provider interface.
 *
 * Default: local disk under .data/uploads served through /api/media/*, so the
 * sandbox preview works with zero external services. When Supabase env vars
 * are present (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SUPABASE_STORAGE_BUCKET)
 * the same interface transparently targets Supabase Storage instead.
 */
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

export type StoredObject = {
  /** Public (or app-proxied) URL usable in <img src>. */
  url: string;
  /** Provider-internal key — stored on the item as imageRef / cutoutUrl. */
  key: string;
};

export interface StorageProvider {
  readonly kind: "local" | "supabase";
  put(key: string, bytes: Buffer, contentType: string): Promise<StoredObject>;
  /** Deterministic public URL for a previously-put key (no I/O). */
  url(key: string): string;
}

export function uploadDir(): string {
  return (
    process.env.UPLOAD_DIR ??
    path.join(/* turbopackIgnore: true */ process.cwd(), ".data", "uploads")
  );
}

/** Guards against path traversal — keys are flat sha-based names by contract. */
export function sanitizeKey(key: string): string | null {
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,120}$/.test(key)) return null;
  if (key.includes("..")) return null;
  return key;
}

class LocalDiskStorage implements StorageProvider {
  readonly kind = "local" as const;
  async put(key: string, bytes: Buffer): Promise<StoredObject> {
    const safe = sanitizeKey(key);
    if (!safe) throw new Error(`Unsafe storage key: ${key}`);
    const dir = uploadDir();
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, safe), bytes);
    return { url: this.url(safe), key: safe };
  }
  url(key: string): string {
    return `/api/media/${key}`;
  }
}

class SupabaseStorage implements StorageProvider {
  readonly kind = "supabase" as const;
  constructor(
    private baseUrl: string,
    private serviceKey: string,
    private bucket: string,
  ) {}
  async put(key: string, bytes: Buffer, contentType: string): Promise<StoredObject> {
    const safe = sanitizeKey(key);
    if (!safe) throw new Error(`Unsafe storage key: ${key}`);
    const res = await fetch(
      `${this.baseUrl}/storage/v1/object/${this.bucket}/wardrobe/${safe}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.serviceKey}`,
          apikey: this.serviceKey,
          "Content-Type": contentType,
          "x-upsert": "true",
        },
        body: new Uint8Array(bytes),
      },
    );
    if (!res.ok) throw new Error(`Supabase storage put failed: ${res.status}`);
    return { url: this.url(safe), key: safe };
  }
  url(key: string): string {
    return `${this.baseUrl}/storage/v1/object/public/${this.bucket}/wardrobe/${key}`;
  }
}

let cached: StorageProvider | null = null;

export function getStorage(): StorageProvider {
  if (cached) return cached;
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const bucket = process.env.SUPABASE_STORAGE_BUCKET ?? "wardrobe";
  cached = url && key ? new SupabaseStorage(url, key, bucket) : new LocalDiskStorage();
  return cached;
}
