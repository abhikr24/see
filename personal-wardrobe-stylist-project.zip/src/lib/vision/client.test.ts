/** Unit tests for the vision caching primitives and response validation. */
import { describe, expect, it } from "vitest";
import {
  buildCacheKey,
  hashBytes,
  heuristicAttributes,
  isExtractResponse,
} from "./client";
import type { ExtractResponse } from "@shared/index";

describe("content-hash caching primitives", () => {
  const a = Buffer.from("a real garment photo, round one");
  const b = Buffer.from("a real garment photo, round one");
  const c = Buffer.from("a different photo entirely");

  it("hashes identical bytes identically — same image, never processed twice", () => {
    expect(hashBytes(a)).toBe(hashBytes(b));
    expect(hashBytes(a)).toMatch(/^[a-f0-9]{64}$/);
  });

  it("hashes different bytes differently", () => {
    expect(hashBytes(a)).not.toBe(hashBytes(c));
  });

  it("namespaces cache keys with the algorithm prefix", () => {
    const key = buildCacheKey(hashBytes(a));
    expect(key.startsWith("sha256:")).toBe(true);
    expect(key).toBe(`sha256:${hashBytes(a)}`);
  });
});

describe("isExtractResponse (vision service contract guard)", () => {
  const valid: ExtractResponse = {
    ok: true,
    cache: "miss",
    provider: "vision",
    hash: "abc123",
    attributes: heuristicAttributes({ paletteHexes: ["#26334C"] }),
    cutoutWebpB64: null,
    models: { segmenter: "u2net", classifier: "fashion-clip" },
  };

  it("accepts a well-formed payload", () => {
    expect(isExtractResponse(valid)).toBe(true);
  });

  it("rejects malformed payloads so we degrade to the fallback", () => {
    expect(isExtractResponse(null)).toBe(false);
    expect(isExtractResponse({})).toBe(false);
    expect(isExtractResponse({ ok: true })).toBe(false);
    expect(isExtractResponse({ ok: true, hash: 1, attributes: {} })).toBe(false);
    expect(isExtractResponse("string")).toBe(false);
  });
});

describe("heuristicAttributes (offline fallback)", () => {
  it("honours caller hints and stays editable-shaped", () => {
    const attrs = heuristicAttributes({
      paletteHexes: ["#33483B"],
      category: "outerwear",
      subcategory: "coat",
    });
    expect(attrs.colors[0]).toBe("forest");
    expect(attrs.category).toBe("outerwear");
    expect(attrs.subcategory).toBe("coat");
    expect(attrs.material).toBe("");
  });
});
