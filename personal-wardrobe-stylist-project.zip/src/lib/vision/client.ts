/**
 * Server-side vision pipeline with content-hash caching.
 *
 * Flow: sha-256 the image → visionExtractions cache hit? return instantly →
 * else call services/vision (MIT stack: rembg u2net + FashionCLIP) when
 * VISION_SERVICE_URL is configured → otherwise fall back to on-device colour
 * hints mapped through packages/shared. Every returned field stays editable
 * in the review sheet; the same image bytes are never processed twice.
 */
import { createHash } from "node:crypto";
import {
  fallbackAttributes,
  type ExtractResponse,
  type VisionAttributes,
} from "@shared/index";

export type ClientHints = {
  /** Dominant hex colours sampled on-device during compression. */
  paletteHexes?: string[];
  category?: string;
  subcategory?: string;
};

export function hashBytes(bytes: Buffer): string {
  return createHash("sha256").update(bytes).digest("hex");
}

export function buildCacheKey(hash: string): string {
  return `sha256:${hash}`;
}

export function isExtractResponse(v: unknown): v is ExtractResponse {
  if (!v || typeof v !== "object") return false;
  const r = v as Record<string, unknown>;
  return (
    typeof r.ok === "boolean" &&
    typeof r.hash === "string" &&
    typeof r.attributes === "object" &&
    r.attributes !== null
  );
}

/**
 * Call the external vision service. Returns null when the service is not
 * configured, times out, or answers with an invalid payload — callers then
 * use the heuristic fallback. Never throws.
 */
export async function callVisionService(
  bytes: Buffer,
  contentType: string,
): Promise<ExtractResponse | null> {
  const base = process.env.VISION_SERVICE_URL;
  if (!base) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 45_000); // first u2net run can be slow
  try {
    const form = new FormData();
    form.append(
      "image",
      new Blob([new Uint8Array(bytes)], { type: contentType }),
      "garment.jpg",
    );
    const res = await fetch(`${base.replace(/\/$/, "")}/extract`, {
      method: "POST",
      body: form,
      signal: controller.signal,
    });
    if (!res.ok) return null;
    const json: unknown = await res.json();
    if (!isExtractResponse(json) || !json.ok) return null;
    return json;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** Heuristic attributes when the vision service is unavailable (no paid AI). */
export function heuristicAttributes(hints: ClientHints): VisionAttributes {
  return fallbackAttributes({
    paletteHexes: hints.paletteHexes ?? [],
    category: hints.category,
    subcategory: hints.subcategory,
  });
}
