import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Platform,
} from 'react-native';
import { useFonts } from 'expo-font';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Colors, Spacing, BorderRadius, FontSize } from './src/theme/colors';
import { HomeScreen } from './src/screens/HomeScreen';
import { IngredientPickerScreen } from './src/screens/IngredientPickerScreen';
import { PantryScreen } from './src/screens/PantryScreen';
import { RecipesScreen } from './src/screens/RecipesScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { usePantry } from './src/hooks/usePantry';

type TabId = 'home' | 'picker' | 'pantry' | 'recipes' | 'settings';

interface TabConfig {
  id: TabId;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  iconActive: keyof typeof Ionicons.glyphMap;
}

const TABS: TabConfig[] = [
  { id: 'home', label: 'Home', icon: 'home-outline', iconActive: 'home' },
  { id: 'picker', label: 'Picker', icon: 'search-outline', iconActive: 'search' },
  { id: 'pantry', label: 'Pantry', icon: 'basket-outline', iconActive: 'basket' },
  { id: 'recipes', label: 'Recipes', icon: 'book-outline', iconActive: 'book' },
  { id: 'settings', label: 'Settings', icon: 'settings-outline', iconActive: 'settings' },
];

export default function App() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
  });

  const [activeTab, setActiveTab] = useState<TabId>('home');
  const {
    pantryIngredients,
    isLoading: pantryLoading,
    bulkAdd,
    removeFromPantry,
    removeByIngredientId,
    clearAll,
    isInPantry,
    refresh,
    count: pantryCount,
  } = usePantry();

  const handleAddToPantry = useCallback(
    async (ingredientIds: string[]) => {
      await bulkAdd(ingredientIds);
    },
    [bulkAdd]
  );

  const handleNavigateToPicker = useCallback(() => {
    setActiveTab('picker');
  }, []);

  const handleNavigateToPantry = useCallback(() => {
    setActiveTab('pantry');
  }, []);

  if (!fontsLoaded) {
    return null;
  }

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeScreen
            pantryCount={pantryCount}
            onNavigateToPicker={handleNavigateToPicker}
            onNavigateToPantry={handleNavigateToPantry}
          />
        );
      case 'picker':
        return (
          <IngredientPickerScreen
            onAddToPantry={handleAddToPantry}
            isInPantry={isInPantry}
          />
        );
      case 'pantry':
        return (
          <PantryScreen
            pantryIngredients={pantryIngredients}
            isLoading={pantryLoading}
            onRemove={removeFromPantry}
            onClearAll={clearAll}
            onRefresh={refresh}
            onNavigateToPicker={handleNavigateToPicker}
          />
        );
      case 'recipes':
        return <RecipesScreen onNavigateToPicker={handleNavigateToPicker} />;
      case 'settings':
        return (
          <SettingsScreen
            pantryCount={pantryCount}
            onClearPantry={clearAll}
          />
        );
      default:
        return null;
    }
  };

  return (
    <SafeAreaProvider>
      <View style={styles.container}>
        {/* Screen Content */}
        <View style={styles.screenContainer}>
          {renderScreen()}
        </View>

        {/* Bottom Tab Bar */}
        <View style={styles.tabBar}>
          {TABS.map((tab) => {
            const isActive = activeTab === tab.id;
            const hasBadge = tab.id === 'pantry' && pantryCount > 0;

            return (
              <TouchableOpacity
                key={tab.id}
                style={styles.tabItem}
                onPress={() => setActiveTab(tab.id)}
                activeOpacity={0.7}
              >
                <View style={[styles.tabIconContainer, isActive && styles.tabIconActive]}>
                  <Ionicons
                    name={isActive ? tab.iconActive : tab.icon}
                    size={22}
                    color={isActive ? Colors.primary : Colors.textTertiary}
                  />
                  {hasBadge && (
                    <View style={styles.badge}>
                      <Text style={styles.badgeText}>{pantryCount}</Text>
                    </View>
                  )}
                </View>
                <Text
                  style={[
                    styles.tabLabel,
                    isActive && styles.tabLabelActive,
                  ]}
                >
                  {tab.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  screenContainer: {
    flex: 1,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    paddingBottom: Platform.OS === 'ios' ? 20 : 8,
    paddingTop: 8,
    paddingHorizontal: 4,
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
  },
  tabIconContainer: {
    width: 44,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  tabIconActive: {
    backgroundColor: Colors.primary + '12',
  },
  tabLabel: {
    fontSize: 10,
    fontWeight: '500',
    color: Colors.textTertiary,
    marginTop: 2,
  },
  tabLabelActive: {
    color: Colors.primary,
    fontWeight: '700',
  },
  badge: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: Colors.error,
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '800',
    color: '#FFF',
  },
});
