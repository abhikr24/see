# Rasoi - Project Development Tracker

## Project Overview
**Rasoi** (रसोई - Hindi for "Kitchen") is a comprehensive Indian cooking companion mobile application built with React Native + Expo + TypeScript.

## Development Stages

### ✅ Stage 1: Foundation (Complete)
- [x] Expo SDK 52+ project scaffold with TypeScript
- [x] React Navigation setup
- [x] AsyncStorage for local persistence
- [x] Expo Secure Store
- [x] Expo Image
- [x] React Native Reanimated
- [x] React Native Gesture Handler
- [x] @expo/vector-icons (Ionicons, FontAwesome, MaterialIcons)
- [x] Cross-platform build configuration (iOS, Android, Web)

### ✅ Stage 2: Ingredient Database + Visual Ingredient Picker (Complete)

#### 2.1 Canonical Ingredient System
- [x] **TypeScript Type Definitions** (`src/types/ingredient.ts`)
  - `CanonicalIngredient` interface with full metadata
  - `IngredientCategory` union type (16 categories)
  - `HouseholdRelevance` enum (essential/common/specialty)
  - `PantryItem` interface for user pantry records
  - `SelectionState` for multi-select management

- [x] **Canonical Ingredient Database** (`src/data/ingredients.ts`)
  - 100+ curated Indian-first ingredients
  - Each ingredient has: stable ID, canonical name, English name, Hindi name (Devanagari), Hindi transliteration, aliases array, category/subcategory, searchable keywords, unit options, emoji icon, cuisine relevance, household relevance, active status
  - Categories covered:
    - 🥬 Vegetables (24 items: tomato, onion, potato, garlic, ginger, chillies, capsicum, carrot, cauliflower, cabbage, peas, spinach, brinjal, lady finger, gourds, radish, beetroot, sweet potato, corn, mushroom, raw banana, drumstick, cluster beans)
    - 🍎 Fruits (8 items: lemon, mango, banana, apple, pomegranate, coconut, guava, tamarind)
    - 🌾 Grains & Cereals (8 items: wheat, ragi, bajra, jowar, oats, dalia, semolina, poha)
    - 🍚 Rice Varieties (5 items: basmati, sona masoori, idli rice, sticky rice, brown rice)
    - 🫓 Flours (7 items: wheat flour/atta, besan, rice flour, maida, ragi flour, bajra flour, jowar flour)
    - 🫘 Dals & Pulses (10 items: toor, moong, masoor, chana, urad, rajma, chickpeas, black eyed peas, moth, soya chunks)
    - 🌶️ Spices & Masalas (18 items: turmeric, red chilli, cumin, coriander, mustard seeds, garam masala, cardamom, cinnamon, cloves, black pepper, bay leaf, asafoetida, fennel, fenugreek, cumin powder, chaat masala, kasuri methi, sambar powder)
    - 🥛 Dairy (7 items: milk, curd, ghee, paneer, butter, cream, khoya)
    - 🫗 Oils & Fats (5 items: mustard, groundnut, sunflower, coconut, sesame)
    - 🥜 Nuts & Seeds (8 items: cashew, almond, peanut, pistachio, raisins, walnut, sesame seeds, flaxseed)
    - 🌿 Fresh Herbs (5 items: coriander leaves, mint, curry leaves, fenugreek leaves, dill)
    - 🫙 Condiments & Sauces (4 items: tamarind paste, ginger garlic paste, soy sauce, vinegar)
    - 🍯 Sweeteners (3 items: sugar, jaggery, honey)
    - 🍗 Meat & Poultry (2 items: chicken, mutton)
    - 🐟 Seafood (2 items: fish, prawns)
    - 🥚 Eggs (1 item)
    - 📦 Misc (6 items: salt, baking soda, baking powder, yeast, coconut milk, tomato paste)

- [x] **Category Metadata** (`src/data/categories.ts`)
  - 16 category definitions with labels, Hindi labels, emojis, descriptions

#### 2.2 Canonical Normalization & Alias Resolution
- [x] **Ingredient Service** (`src/services/ingredientService.ts`)
  - `buildSearchIndex()` - Builds normalized search index at startup
  - `searchIngredients()` - Offline search with scoring/ranking
  - `resolveCanonicalId()` - Resolves any name/alias to canonical ID
  - `getIngredientById()` / `getIngredientsByIds()` - Direct access
  - `getIngredientsByCategory()` - Category filtering
  - `getCategoryCounts()` - Stats per category
  - Supports search by: canonical name, English name, Hindi name (Devanagari), Hindi transliteration, aliases, keywords, subcategory

#### 2.3 Data Persistence Layer
- [x] **Pantry Repository** (`src/repositories/pantryRepository.ts`)
  - AsyncStorage-based persistent storage
  - CRUD operations: add, remove, update, clear, bulk add
  - Version tracking for data migrations
  - **Separation maintained**: Canonical catalogue (static, in-memory) vs User pantry (dynamic, persistent)

#### 2.4 React Hooks
- [x] **useIngredients** (`src/hooks/useIngredients.ts`)
  - Search state management with debounced filtering
  - Category selection state
  - Memoized results and category data
- [x] **useIngredientSelection** (`src/hooks/useIngredients.ts`)
  - Multi-select state with Set-based tracking
  - Toggle, clear, selectAll operations
  - Derived selected count and ingredient list
- [x] **usePantry** (`src/hooks/usePantry.ts`)
  - Full pantry CRUD with auto-refresh
  - Bulk add from picker selections
  - isInPantry check for UI state

#### 2.5 Visual Ingredient Picker UI
- [x] **SearchBar** (`src/components/SearchBar.tsx`)
  - Real-time search with clear button
  - Loading indicator during search
  - Hindi/English placeholder text
- [x] **CategoryChips** (`src/components/CategoryChips.tsx`)
  - Horizontal scrollable category filter
  - Active state with category-specific colors
  - Item count badges
  - "All" option
- [x] **IngredientCard** (`src/components/IngredientCard.tsx`)
  - Visual card with emoji icon, English name, Hindi name, transliteration
  - Category tag with color coding
  - Selection checkbox with category color
  - "In Pantry" indicator
- [x] **SelectionSummary** (`src/components/SelectionSummary.tsx`)
  - Floating bottom bar showing selection count
  - Emoji preview of selected items
  - View, Clear, and "Add to Pantry" actions
- [x] **SelectionModal** (`src/components/SelectionModal.tsx`)
  - Full-screen modal for reviewing selections
  - Remove individual items
  - Clear all / Confirm actions
- [x] **EmptyState** (`src/components/EmptyState.tsx`)
  - Configurable empty state with emoji/icon, title, subtitle, action button

#### 2.6 Screens
- [x] **HomeScreen** (`src/screens/HomeScreen.tsx`)
  - Dashboard with app branding ("Namaste! 🙏 Rasoi")
  - Quick stats (total ingredients, categories, pantry count)
  - Main action card for ingredient picker
  - Quick action buttons (Search, My Pantry, Essentials)
  - Category preview horizontal scroll
  - Info card about the ingredient database
- [x] **IngredientPickerScreen** (`src/screens/IngredientPickerScreen.tsx`)
  - Full visual picker with search + category filter + ingredient list
  - Multi-select with visual feedback
  - Selection summary bar at bottom
  - Confirmation flow with alert
  - Offline badge indicator
- [x] **PantryScreen** (`src/screens/PantryScreen.tsx`)
  - List of pantry items with ingredient details
  - Category grouping stats
  - Pull-to-refresh
  - Remove/clear functionality with confirmation
  - FAB to add more ingredients
  - Empty state with CTA
- [x] **RecipesScreen** (`src/screens/RecipesScreen.tsx`)
  - Placeholder for Stage 3+ recipe features
- [x] **SettingsScreen** (`src/screens/SettingsScreen.tsx`)
  - Database info (counts, mode)
  - Clear pantry action
  - App info and version
  - Stage 2 feature checklist

#### 2.7 Navigation & Theme
- [x] **Tab Navigation** (in `App.tsx`)
  - 5-tab bottom navigation: Home, Picker, Pantry, Recipes, Settings
  - Active state with icon change and background highlight
  - Pantry badge showing item count
  - Safe area handling
- [x] **Theme System** (`src/theme/colors.ts`)
  - Indian-inspired color palette (saffron, green, turmeric gold)
  - Category-specific colors for visual differentiation
  - Spacing, border radius, font size tokens
  - Shadow presets for card depth

### 🔲 Stage 3: Recipe Management (Planned)
- [ ] Recipe data model
- [ ] Recipe creation/editing
- [ ] Recipe-ingredient linking
- [ ] Step-by-step cooking mode

### 🔲 Stage 4: Smart Recipe Suggestions (Planned)
- [ ] Pantry-based recipe matching
- [ ] Missing ingredient indicators
- [ ] Recipe scoring

### 🔲 Stage 5: Meal Planning (Planned)
### 🔲 Stage 6: Shopping Lists (Planned)
### 🔲 Stage 7: Nutrition Tracking (Planned)
### 🔲 Stage 8: Social Features (Planned)
### 🔲 Stage 9: AI Integration (Planned)
### 🔲 Stage 10: Polish & Launch (Planned)

## Architecture

```
App.tsx (Root with Tab Navigation)
├── src/
│   ├── types/
│   │   └── ingredient.ts          # TypeScript interfaces
│   ├── data/
│   │   ├── ingredients.ts         # 100+ canonical ingredients
│   │   └── categories.ts          # 16 category definitions
│   ├── services/
│   │   └── ingredientService.ts   # Search, normalization, data access
│   ├── repositories/
│   │   └── pantryRepository.ts    # AsyncStorage persistence
│   ├── hooks/
│   │   ├── useIngredients.ts      # Browse/search/filter state
│   │   └── usePantry.ts           # Pantry CRUD state
│   ├── components/
│   │   ├── SearchBar.tsx          # Search input
│   │   ├── CategoryChips.tsx      # Category filter chips
│   │   ├── IngredientCard.tsx     # Ingredient list item
│   │   ├── SelectionSummary.tsx   # Bottom selection bar
│   │   ├── SelectionModal.tsx     # Selection review modal
│   │   └── EmptyState.tsx         # Empty state component
│   ├── screens/
│   │   ├── HomeScreen.tsx         # Dashboard
│   │   ├── IngredientPickerScreen.tsx  # Main picker
│   │   ├── PantryScreen.tsx       # User pantry
│   │   ├── RecipesScreen.tsx      # Placeholder
│   │   └── SettingsScreen.tsx     # Settings & info
│   └── theme/
│       └── colors.ts              # Theme tokens
```

## Key Design Decisions

1. **Canonical ID System**: Each ingredient has a stable, predictable ID format (`category_name`) that never changes, even if display names are updated.

2. **Alias Resolution**: The search index normalizes all names, aliases, and keywords into a flat lookup structure for O(1) resolution. This handles cases like "tamatar" → `veg_tomato`, "aloo" → `veg_potato`, etc.

3. **Separation of Concerns**: The canonical catalogue (read-only, in-memory) is completely separate from the user's pantry (read-write, persistent in AsyncStorage). This ensures the database integrity while allowing user customization.

4. **Offline-First**: All ingredient data is bundled with the app. No network requests needed for browsing, searching, or selecting ingredients.

5. **Indian-First Data**: Categories and ingredients prioritize Indian cooking needs, with Hindi names, transliterations, and region-specific items (like idli rice, curry leaves, asafoetida).

6. **Performance**: Search index is built once at startup. FlatList with windowing for smooth scrolling. Memoized hooks prevent unnecessary re-renders.

## Technology Stack
- React Native 0.86.3
- Expo SDK 57
- TypeScript 6.0
- @react-native-async-storage/async-storage
- @expo/vector-icons (Ionicons)
- expo-font
- react-native-safe-area-context

## Build & Deploy
- Export: `npx expo export --platform all`
- Platforms: iOS, Android, Web
- Deploy: Vercel
