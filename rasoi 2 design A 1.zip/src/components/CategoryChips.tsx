import React, { useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { IngredientCategory, IngredientCategoryMeta } from '../types/ingredient';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';

interface CategoryChipsProps {
  categories: IngredientCategoryMeta[];
  selectedCategory: IngredientCategory | 'all';
  onSelectCategory: (category: IngredientCategory | 'all') => void;
  categoryCounts?: Record<string, number>;
}

export function CategoryChips({
  categories,
  selectedCategory,
  onSelectCategory,
  categoryCounts = {},
}: CategoryChipsProps) {
  const scrollRef = useRef<ScrollView>(null);

  return (
    <View style={styles.wrapper}>
      <ScrollView
        ref={scrollRef}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        {/* All category chip */}
        <TouchableOpacity
          style={[
            styles.chip,
            selectedCategory === 'all' && styles.chipActive,
          ]}
          onPress={() => onSelectCategory('all')}
          activeOpacity={0.7}
        >
          <Text style={[styles.chipEmoji]}>🍳</Text>
          <Text
            style={[
              styles.chipText,
              selectedCategory === 'all' && styles.chipTextActive,
            ]}
          >
            All
          </Text>
        </TouchableOpacity>

        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          const count = categoryCounts[cat.id] || 0;

          return (
            <TouchableOpacity
              key={cat.id}
              style={[
                styles.chip,
                isActive && styles.chipActive,
                isActive && {
                  borderColor: Colors.categoryColors[cat.id] || Colors.primary,
                  backgroundColor: (Colors.categoryColors[cat.id] || Colors.primary) + '15',
                },
              ]}
              onPress={() => onSelectCategory(cat.id)}
              activeOpacity={0.7}
            >
              <Text style={styles.chipEmoji}>{cat.emoji}</Text>
              <Text
                style={[
                  styles.chipText,
                  isActive && styles.chipTextActive,
                  isActive && { color: Colors.categoryColors[cat.id] || Colors.primary },
                ]}
              >
                {cat.label}
              </Text>
              {count > 0 && (
                <View
                  style={[
                    styles.countBadge,
                    isActive && {
                      backgroundColor: Colors.categoryColors[cat.id] || Colors.primary,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.countText,
                      isActive && styles.countTextActive,
                    ]}
                  >
                    {count}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    paddingVertical: Spacing.sm,
  },
  container: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.surface,
    borderWidth: 1.5,
    borderColor: Colors.border,
    marginRight: Spacing.xs,
  },
  chipActive: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary + '12',
  },
  chipEmoji: {
    fontSize: FontSize.md,
    marginRight: Spacing.xs,
  },
  chipText: {
    fontSize: FontSize.sm,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  chipTextActive: {
    color: Colors.primary,
    fontWeight: '700',
  },
  countBadge: {
    marginLeft: Spacing.xs,
    backgroundColor: Colors.borderLight,
    borderRadius: BorderRadius.full,
    paddingHorizontal: 6,
    paddingVertical: 1,
    minWidth: 20,
    alignItems: 'center',
  },
  countText: {
    fontSize: FontSize.xs,
    fontWeight: '700',
    color: Colors.textTertiary,
  },
  countTextActive: {
    color: Colors.textOnPrimary,
  },
});
