import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { CanonicalIngredient } from '../types/ingredient';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';

interface IngredientCardProps {
  ingredient: CanonicalIngredient;
  isSelected: boolean;
  onToggle: (id: string) => void;
  isInPantry?: boolean;
}

export function IngredientCard({
  ingredient,
  isSelected,
  onToggle,
  isInPantry = false,
}: IngredientCardProps) {
  const categoryColor = Colors.categoryColors[ingredient.category] || Colors.primary;

  return (
    <TouchableOpacity
      style={[
        styles.card,
        isSelected && styles.cardSelected,
        isSelected && { borderColor: categoryColor },
      ]}
      onPress={() => onToggle(ingredient.id)}
      activeOpacity={0.7}
    >
      {/* Emoji Icon */}
      <View style={[styles.iconContainer, { backgroundColor: categoryColor + '18' }]}>
        <Text style={styles.emoji}>{ingredient.imageEmoji}</Text>
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Text style={styles.englishName} numberOfLines={1}>
          {ingredient.englishName}
        </Text>
        <Text style={styles.hindiName} numberOfLines={1}>
          {ingredient.hindiName} • {ingredient.hindiTransliteration}
        </Text>
        <View style={styles.metaRow}>
          <View style={[styles.categoryTag, { backgroundColor: categoryColor + '20' }]}>
            <Text style={[styles.categoryText, { color: categoryColor }]}>
              {ingredient.subcategory}
            </Text>
          </View>
          {isInPantry && (
            <View style={styles.pantryTag}>
              <Ionicons name="checkmark-circle" size={12} color={Colors.success} />
              <Text style={styles.pantryText}>In Pantry</Text>
            </View>
          )}
        </View>
      </View>

      {/* Selection indicator */}
      <View
        style={[
          styles.checkbox,
          isSelected && { backgroundColor: categoryColor, borderColor: categoryColor },
        ]}
      >
        {isSelected && <Ionicons name="checkmark" size={16} color="#FFF" />}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginHorizontal: Spacing.lg,
    marginVertical: Spacing.xs,
    borderWidth: 1.5,
    borderColor: Colors.borderLight,
    ...Colors.shadow.light,
  },
  cardSelected: {
    borderWidth: 2,
    backgroundColor: Colors.background,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  emoji: {
    fontSize: 24,
  },
  content: {
    flex: 1,
    marginRight: Spacing.sm,
  },
  englishName: {
    fontSize: FontSize.md,
    fontWeight: '700',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  hindiName: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flexWrap: 'wrap',
  },
  categoryTag: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: BorderRadius.sm,
  },
  categoryText: {
    fontSize: FontSize.xs,
    fontWeight: '600',
  },
  pantryTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  pantryText: {
    fontSize: FontSize.xs,
    color: Colors.success,
    fontWeight: '600',
  },
  checkbox: {
    width: 26,
    height: 26,
    borderRadius: BorderRadius.full,
    borderWidth: 2,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
