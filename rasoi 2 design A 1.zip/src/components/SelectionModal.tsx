import React from 'react';
import {
  View,
  Text,
  Modal,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { CanonicalIngredient } from '../types/ingredient';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';

interface SelectionModalProps {
  visible: boolean;
  selectedIngredients: CanonicalIngredient[];
  onClose: () => void;
  onRemove: (id: string) => void;
  onConfirm: () => void;
  onClear: () => void;
}

export function SelectionModal({
  visible,
  selectedIngredients,
  onClose,
  onRemove,
  onConfirm,
  onClear,
}: SelectionModalProps) {
  const renderItem = ({ item }: { item: CanonicalIngredient }) => (
    <View style={styles.item}>
      <View style={styles.itemIcon}>
        <Text style={styles.itemEmoji}>{item.imageEmoji}</Text>
      </View>
      <View style={styles.itemContent}>
        <Text style={styles.itemName}>{item.englishName}</Text>
        <Text style={styles.itemHindi}>{item.hindiName} • {item.hindiTransliteration}</Text>
      </View>
      <TouchableOpacity
        onPress={() => onRemove(item.id)}
        style={styles.removeButton}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="close-circle" size={24} color={Colors.error} />
      </TouchableOpacity>
    </View>
  );

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={24} color={Colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Selected Ingredients</Text>
          <TouchableOpacity onPress={onClear} style={styles.clearAllButton}>
            <Text style={styles.clearAllText}>Clear All</Text>
          </TouchableOpacity>
        </View>

        {/* Count */}
        <View style={styles.countBar}>
          <Text style={styles.countText}>
            {selectedIngredients.length}{' '}
            {selectedIngredients.length === 1 ? 'ingredient' : 'ingredients'} selected
          </Text>
        </View>

        {/* List */}
        <FlatList
          data={selectedIngredients}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
        />

        {/* Footer */}
        <View style={styles.footer}>
          <TouchableOpacity style={styles.confirmButton} onPress={onConfirm} activeOpacity={0.8}>
            <Ionicons name="checkmark-circle" size={22} color="#FFF" />
            <Text style={styles.confirmText}>
              Add {selectedIngredients.length} {selectedIngredients.length === 1 ? 'Item' : 'Items'} to Pantry
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    backgroundColor: Colors.surface,
  },
  closeButton: {
    padding: Spacing.xs,
  },
  headerTitle: {
    fontSize: FontSize.xl,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  clearAllButton: {
    padding: Spacing.xs,
  },
  clearAllText: {
    fontSize: FontSize.sm,
    color: Colors.error,
    fontWeight: '600',
  },
  countBar: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  countText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
  listContent: {
    paddingVertical: Spacing.sm,
    paddingBottom: Spacing.huge,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  itemIcon: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  itemEmoji: {
    fontSize: 20,
  },
  itemContent: {
    flex: 1,
  },
  itemName: {
    fontSize: FontSize.md,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  itemHindi: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  removeButton: {
    padding: Spacing.xs,
  },
  separator: {
    height: 1,
    backgroundColor: Colors.borderLight,
    marginHorizontal: Spacing.lg,
  },
  footer: {
    padding: Spacing.lg,
    paddingBottom: Spacing.xxl,
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  confirmButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary,
    paddingVertical: Spacing.lg,
    borderRadius: BorderRadius.lg,
  },
  confirmText: {
    fontSize: FontSize.lg,
    fontWeight: '700',
    color: '#FFF',
  },
});
