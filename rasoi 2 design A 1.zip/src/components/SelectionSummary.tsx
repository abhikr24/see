import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { CanonicalIngredient } from '../types/ingredient';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';

interface SelectionSummaryProps {
  selectedCount: number;
  selectedIngredients: CanonicalIngredient[];
  onConfirm: () => void;
  onClear: () => void;
  onViewSelection: () => void;
}

export function SelectionSummary({
  selectedCount,
  selectedIngredients,
  onConfirm,
  onClear,
  onViewSelection,
}: SelectionSummaryProps) {
  if (selectedCount === 0) return null;

  const previewItems = selectedIngredients.slice(0, 4);
  const remaining = selectedCount - previewItems.length;

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {/* Selection preview */}
        <View style={styles.previewRow}>
          <View style={styles.emojiRow}>
            {previewItems.map((item) => (
              <View key={item.id} style={styles.emojiBadge}>
                <Text style={styles.emoji}>{item.imageEmoji}</Text>
              </View>
            ))}
            {remaining > 0 && (
              <View style={styles.moreBadge}>
                <Text style={styles.moreText}>+{remaining}</Text>
              </View>
            )}
          </View>
          <Text style={styles.countText}>
            {selectedCount} {selectedCount === 1 ? 'item' : 'items'} selected
          </Text>
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={styles.viewButton}
            onPress={onViewSelection}
            activeOpacity={0.7}
          >
            <Ionicons name="eye-outline" size={18} color={Colors.primary} />
            <Text style={styles.viewButtonText}>View</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.clearButton}
            onPress={onClear}
            activeOpacity={0.7}
          >
            <Ionicons name="trash-outline" size={18} color={Colors.error} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.confirmButton}
            onPress={onConfirm}
            activeOpacity={0.8}
          >
            <Text style={styles.confirmText}>Add to Pantry</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFF" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.surface,
    borderTopLeftRadius: BorderRadius.xl,
    borderTopRightRadius: BorderRadius.xl,
    paddingBottom: Spacing.xxl,
    paddingTop: Spacing.lg,
    paddingHorizontal: Spacing.lg,
    ...Colors.shadow.heavy,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  content: {
    gap: Spacing.md,
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  emojiRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  emojiBadge: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  emoji: {
    fontSize: 16,
  },
  moreBadge: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  moreText: {
    fontSize: FontSize.xs,
    fontWeight: '700',
    color: Colors.primary,
  },
  countText: {
    fontSize: FontSize.sm,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  viewButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primary + '10',
    borderWidth: 1,
    borderColor: Colors.primary + '30',
  },
  viewButtonText: {
    fontSize: FontSize.sm,
    fontWeight: '600',
    color: Colors.primary,
  },
  clearButton: {
    padding: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.error + '10',
  },
  confirmButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    backgroundColor: Colors.primary,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  confirmText: {
    fontSize: FontSize.md,
    fontWeight: '700',
    color: '#FFF',
  },
});
