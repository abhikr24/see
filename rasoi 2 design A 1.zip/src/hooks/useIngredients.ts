import { useState, useEffect, useCallback, useMemo } from 'react';
import { CanonicalIngredient, IngredientCategory } from '../types/ingredient';
import {
  searchIngredients,
  getIngredientsByCategory,
  getAvailableCategories,
  getCategoryCounts,
  getIngredientById,
} from '../services/ingredientService';
import { INGREDIENT_CATEGORIES } from '../data/categories';

/**
 * useIngredients - Hook for ingredient browsing, searching, and filtering
 */
export function useIngredients() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<IngredientCategory | 'all'>('all');
  const [results, setResults] = useState<CanonicalIngredient[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const categories = useMemo(() => INGREDIENT_CATEGORIES, []);
  const categoryCounts = useMemo(() => getCategoryCounts(), []);

  const performSearch = useCallback(() => {
    setIsLoading(true);

    // Use requestAnimationFrame for smooth UI
    requestAnimationFrame(() => {
      let filtered: CanonicalIngredient[];

      if (searchQuery.trim().length > 0) {
        filtered = searchIngredients(searchQuery);
      } else if (selectedCategory !== 'all') {
        filtered = getIngredientsByCategory(selectedCategory);
      } else {
        filtered = searchIngredients('');
      }

      // Apply category filter on search results too
      if (searchQuery.trim().length > 0 && selectedCategory !== 'all') {
        filtered = filtered.filter((i) => i.category === selectedCategory);
      }

      setResults(filtered);
      setIsLoading(false);
    });
  }, [searchQuery, selectedCategory]);

  useEffect(() => {
    performSearch();
  }, [performSearch]);

  return {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    results,
    isLoading,
    categories,
    categoryCounts,
  };
}

/**
 * useIngredientSelection - Hook for multi-select ingredient picker
 */
export function useIngredientSelection(initialSelected: string[] = []) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set(initialSelected));

  const toggleSelection = useCallback((ingredientId: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(ingredientId)) {
        next.delete(ingredientId);
      } else {
        next.add(ingredientId);
      }
      return next;
    });
  }, []);

  const isSelected = useCallback(
    (ingredientId: string) => selectedIds.has(ingredientId),
    [selectedIds]
  );

  const clearSelection = useCallback(() => {
    setSelectedIds(new Set());
  }, []);

  const selectAll = useCallback((ids: string[]) => {
    setSelectedIds(new Set(ids));
  }, []);

  const selectedCount = selectedIds.size;
  const selectedIngredients = useMemo(
    () => Array.from(selectedIds).map((id) => getIngredientById(id)).filter(Boolean) as CanonicalIngredient[],
    [selectedIds]
  );

  return {
    selectedIds,
    toggleSelection,
    isSelected,
    clearSelection,
    selectAll,
    selectedCount,
    selectedIngredients,
  };
}
