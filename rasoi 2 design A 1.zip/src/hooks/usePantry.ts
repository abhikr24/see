import { useState, useEffect, useCallback } from 'react';
import { PantryItem } from '../types/ingredient';
import {
  getPantryItems,
  addPantryItem,
  removePantryItem,
  removePantryItemByIngredientId,
  clearPantry,
  bulkAddPantryItems,
  initializePantry,
} from '../repositories/pantryRepository';
import { getIngredientById } from '../services/ingredientService';
import { CanonicalIngredient } from '../types/ingredient';

/**
 * usePantry - Hook for managing user's pantry
 */
export function usePantry() {
  const [pantryItems, setPantryItems] = useState<PantryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadPantry = useCallback(async () => {
    setIsLoading(true);
    try {
      await initializePantry();
      const items = await getPantryItems();
      setPantryItems(items);
    } catch (error) {
      console.error('Error loading pantry:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPantry();
  }, [loadPantry]);

  const addToPantry = useCallback(
    async (ingredientId: string, quantity: number = 1, unit: string = 'unit') => {
      const newItem: PantryItem = {
        id: `pantry_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ingredientId,
        quantity,
        unit,
        addedAt: new Date().toISOString(),
      };
      await addPantryItem(newItem);
      await loadPantry();
    },
    [loadPantry]
  );

  const removeFromPantry = useCallback(
    async (itemId: string) => {
      await removePantryItem(itemId);
      await loadPantry();
    },
    [loadPantry]
  );

  const removeByIngredientId = useCallback(
    async (ingredientId: string) => {
      await removePantryItemByIngredientId(ingredientId);
      await loadPantry();
    },
    [loadPantry]
  );

  const bulkAdd = useCallback(
    async (ingredientIds: string[]) => {
      const items: PantryItem[] = ingredientIds.map((id, index) => ({
        id: `pantry_${Date.now()}_${index}_${Math.random().toString(36).substr(2, 9)}`,
        ingredientId: id,
        quantity: 1,
        unit: 'unit',
        addedAt: new Date().toISOString(),
      }));
      await bulkAddPantryItems(items);
      await loadPantry();
    },
    [loadPantry]
  );

  const clearAll = useCallback(async () => {
    await clearPantry();
    setPantryItems([]);
  }, []);

  const isInPantry = useCallback(
    (ingredientId: string) => pantryItems.some((i) => i.ingredientId === ingredientId),
    [pantryItems]
  );

  const pantryIngredients = pantryItems
    .map((item) => ({
      ...item,
      ingredient: getIngredientById(item.ingredientId),
    }))
    .filter((item) => item.ingredient !== undefined) as (PantryItem & { ingredient: CanonicalIngredient })[];

  return {
    pantryItems,
    pantryIngredients,
    isLoading,
    addToPantry,
    removeFromPantry,
    removeByIngredientId,
    bulkAdd,
    clearAll,
    isInPantry,
    refresh: loadPantry,
    count: pantryItems.length,
  };
}
