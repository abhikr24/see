import AsyncStorage from '@react-native-async-storage/async-storage';
import { PantryItem } from '../types/ingredient';

const PANTRY_STORAGE_KEY = '@rasoi_pantry_items';
const PANTRY_VERSION_KEY = '@rasoi_pantry_version';
const CURRENT_VERSION = '1.0';

/**
 * PantryRepository - Manages user's personal pantry items
 * Separate from the canonical ingredient catalogue
 */

/**
 * Get all pantry items
 */
export async function getPantryItems(): Promise<PantryItem[]> {
  try {
    const data = await AsyncStorage.getItem(PANTRY_STORAGE_KEY);
    if (!data) return [];
    return JSON.parse(data) as PantryItem[];
  } catch (error) {
    console.error('Error reading pantry:', error);
    return [];
  }
}

/**
 * Add an item to the pantry
 */
export async function addPantryItem(item: PantryItem): Promise<void> {
  try {
    const items = await getPantryItems();
    // Check if ingredient already exists in pantry
    const existingIndex = items.findIndex((i) => i.ingredientId === item.ingredientId);
    if (existingIndex >= 0) {
      // Update existing item
      items[existingIndex] = { ...items[existingIndex], ...item, id: items[existingIndex].id };
    } else {
      items.push(item);
    }
    await AsyncStorage.setItem(PANTRY_STORAGE_KEY, JSON.stringify(items));
  } catch (error) {
    console.error('Error adding pantry item:', error);
    throw error;
  }
}

/**
 * Remove an item from the pantry
 */
export async function removePantryItem(itemId: string): Promise<void> {
  try {
    const items = await getPantryItems();
    const filtered = items.filter((i) => i.id !== itemId);
    await AsyncStorage.setItem(PANTRY_STORAGE_KEY, JSON.stringify(filtered));
  } catch (error) {
    console.error('Error removing pantry item:', error);
    throw error;
  }
}

/**
 * Remove by ingredient ID
 */
export async function removePantryItemByIngredientId(ingredientId: string): Promise<void> {
  try {
    const items = await getPantryItems();
    const filtered = items.filter((i) => i.ingredientId !== ingredientId);
    await AsyncStorage.setItem(PANTRY_STORAGE_KEY, JSON.stringify(filtered));
  } catch (error) {
    console.error('Error removing pantry item:', error);
    throw error;
  }
}

/**
 * Update a pantry item
 */
export async function updatePantryItem(itemId: string, updates: Partial<PantryItem>): Promise<void> {
  try {
    const items = await getPantryItems();
    const index = items.findIndex((i) => i.id === itemId);
    if (index >= 0) {
      items[index] = { ...items[index], ...updates };
      await AsyncStorage.setItem(PANTRY_STORAGE_KEY, JSON.stringify(items));
    }
  } catch (error) {
    console.error('Error updating pantry item:', error);
    throw error;
  }
}

/**
 * Clear all pantry items
 */
export async function clearPantry(): Promise<void> {
  try {
    await AsyncStorage.setItem(PANTRY_STORAGE_KEY, JSON.stringify([]));
  } catch (error) {
    console.error('Error clearing pantry:', error);
    throw error;
  }
}

/**
 * Get pantry item count
 */
export async function getPantryCount(): Promise<number> {
  const items = await getPantryItems();
  return items.length;
}

/**
 * Check if ingredient is in pantry
 */
export async function isInPantry(ingredientId: string): Promise<boolean> {
  const items = await getPantryItems();
  return items.some((i) => i.ingredientId === ingredientId);
}

/**
 * Bulk add items to pantry
 */
export async function bulkAddPantryItems(items: PantryItem[]): Promise<void> {
  try {
    const existing = await getPantryItems();
    const existingIds = new Set(existing.map((i) => i.ingredientId));

    const newItems = items.filter((i) => !existingIds.has(i.ingredientId));
    const updated = [...existing, ...newItems];
    await AsyncStorage.setItem(PANTRY_STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Error bulk adding pantry items:', error);
    throw error;
  }
}

/**
 * Initialize pantry version tracking
 */
export async function initializePantry(): Promise<void> {
  try {
    const version = await AsyncStorage.getItem(PANTRY_VERSION_KEY);
    if (!version) {
      await AsyncStorage.setItem(PANTRY_VERSION_KEY, CURRENT_VERSION);
    }
  } catch (error) {
    console.error('Error initializing pantry:', error);
  }
}
