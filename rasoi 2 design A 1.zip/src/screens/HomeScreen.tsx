import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';
import { CANONICAL_INGREDIENTS } from '../data/ingredients';
import { INGREDIENT_CATEGORIES } from '../data/categories';

interface HomeScreenProps {
  pantryCount: number;
  onNavigateToPicker: () => void;
  onNavigateToPantry: () => void;
}

export function HomeScreen({
  pantryCount,
  onNavigateToPicker,
  onNavigateToPantry,
}: HomeScreenProps) {
  const totalIngredients = CANONICAL_INGREDIENTS.filter((i) => i.isActive).length;
  const totalCategories = INGREDIENT_CATEGORIES.length;
  const essentialCount = CANONICAL_INGREDIENTS.filter(
    (i) => i.isActive && i.householdRelevance === 'essential'
  ).length;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Namaste! 🙏</Text>
            <Text style={styles.appName}>Rasoi</Text>
            <Text style={styles.tagline}>Your Indian Kitchen Companion</Text>
          </View>
          <View style={styles.logoContainer}>
            <Text style={styles.logoEmoji}>🍛</Text>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{totalIngredients}</Text>
            <Text style={styles.statLabel}>Ingredients</Text>
            <Ionicons name="leaf" size={16} color={Colors.secondary} style={styles.statIcon} />
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{totalCategories}</Text>
            <Text style={styles.statLabel}>Categories</Text>
            <Ionicons name="grid" size={16} color={Colors.accent} style={styles.statIcon} />
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{pantryCount}</Text>
            <Text style={styles.statLabel}>In Pantry</Text>
            <Ionicons name="basket" size={16} color={Colors.primary} style={styles.statIcon} />
          </View>
        </View>

        {/* Main Action Card */}
        <TouchableOpacity style={styles.mainAction} onPress={onNavigateToPicker} activeOpacity={0.85}>
          <View style={styles.mainActionContent}>
            <Text style={styles.mainActionTitle}>Add Ingredients</Text>
            <Text style={styles.mainActionSubtitle}>
              {`Browse ${totalIngredients}+ Indian ingredients\nSearch by name, Hindi, or aliases`}
            </Text>
            <View style={styles.mainActionButton}>
              <Text style={styles.mainActionButtonText}>Open Picker</Text>
              <Ionicons name="arrow-forward" size={18} color="#FFF" />
            </View>
          </View>
          <View style={styles.mainActionVisual}>
            <Text style={styles.mainActionEmoji}>🥬</Text>
            <Text style={[styles.mainActionEmoji, { marginTop: -10 }]}>🌶️</Text>
            <Text style={[styles.mainActionEmoji, { marginTop: -10 }]}>🫘</Text>
          </View>
        </TouchableOpacity>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickActionCard} onPress={onNavigateToPicker} activeOpacity={0.7}>
            <View style={[styles.quickActionIcon, { backgroundColor: Colors.primary + '15' }]}>
              <Ionicons name="search" size={24} color={Colors.primary} />
            </View>
            <Text style={styles.quickActionText}>Search</Text>
            <Text style={styles.quickActionSubtext}>Find ingredients</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard} onPress={onNavigateToPantry} activeOpacity={0.7}>
            <View style={[styles.quickActionIcon, { backgroundColor: Colors.secondary + '15' }]}>
              <Ionicons name="basket" size={24} color={Colors.secondary} />
            </View>
            <Text style={styles.quickActionText}>My Pantry</Text>
            <Text style={styles.quickActionSubtext}>{pantryCount} items</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.quickActionCard} onPress={onNavigateToPicker} activeOpacity={0.7}>
            <View style={[styles.quickActionIcon, { backgroundColor: Colors.accent + '20' }]}>
              <Ionicons name="star" size={24} color={Colors.accentDark} />
            </View>
            <Text style={styles.quickActionText}>Essentials</Text>
            <Text style={styles.quickActionSubtext}>{essentialCount} items</Text>
          </TouchableOpacity>
        </View>

        {/* Category Preview */}
        <Text style={styles.sectionTitle}>Ingredient Categories</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryScroll}>
          {INGREDIENT_CATEGORIES.slice(0, 8).map((cat) => (
            <TouchableOpacity
              key={cat.id}
              style={styles.categoryCard}
              onPress={onNavigateToPicker}
              activeOpacity={0.7}
            >
              <Text style={styles.categoryEmoji}>{cat.emoji}</Text>
              <Text style={styles.categoryLabel} numberOfLines={1}>
                {cat.label}
              </Text>
              <Text style={styles.categoryHindi} numberOfLines={1}>
                {cat.hindiLabel}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Info Section */}
        <View style={styles.infoCard}>
          <Ionicons name="information-circle" size={20} color={Colors.info} />
          <View style={styles.infoContent}>
            <Text style={styles.infoTitle}>About the Ingredient Database</Text>
            <Text style={styles.infoText}>
              Rasoi's canonical ingredient system resolves different names for the same
              ingredient into a single ID. Search by English name, Hindi name, transliteration,
              or common aliases. All data works offline.
            </Text>
          </View>
        </View>

        <View style={{ height: Spacing.huge }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: Spacing.xl,
    marginBottom: Spacing.xxl,
  },
  greeting: {
    fontSize: FontSize.lg,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  appName: {
    fontSize: FontSize.display,
    fontWeight: '800',
    color: Colors.primary,
    letterSpacing: -1,
  },
  tagline: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
    marginTop: 2,
  },
  logoContainer: {
    width: 64,
    height: 64,
    borderRadius: 20,
    backgroundColor: Colors.primary + '12',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.primary + '20',
  },
  logoEmoji: {
    fontSize: 32,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    marginBottom: Spacing.xxl,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
    position: 'relative',
    ...Colors.shadow.light,
  },
  statNumber: {
    fontSize: FontSize.xxl,
    fontWeight: '800',
    color: Colors.textPrimary,
  },
  statLabel: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    fontWeight: '600',
    marginTop: 2,
  },
  statIcon: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  mainAction: {
    flexDirection: 'row',
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.xl,
    marginHorizontal: Spacing.lg,
    padding: Spacing.xl,
    marginBottom: Spacing.xxl,
    overflow: 'hidden',
    ...Colors.shadow.medium,
  },
  mainActionContent: {
    flex: 1,
  },
  mainActionTitle: {
    fontSize: FontSize.xxl,
    fontWeight: '800',
    color: '#FFF',
    marginBottom: Spacing.sm,
  },
  mainActionSubtitle: {
    fontSize: FontSize.sm,
    color: '#FFFFFFCC',
    lineHeight: 20,
    marginBottom: Spacing.lg,
  },
  mainActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: '#FFFFFF25',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    alignSelf: 'flex-start',
  },
  mainActionButtonText: {
    fontSize: FontSize.sm,
    fontWeight: '700',
    color: '#FFF',
  },
  mainActionVisual: {
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: Spacing.md,
  },
  mainActionEmoji: {
    fontSize: 36,
  },
  sectionTitle: {
    fontSize: FontSize.xl,
    fontWeight: '700',
    color: Colors.textPrimary,
    paddingHorizontal: Spacing.xl,
    marginBottom: Spacing.md,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    marginBottom: Spacing.xxl,
  },
  quickActionCard: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Colors.shadow.light,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  quickActionText: {
    fontSize: FontSize.sm,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  quickActionSubtext: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    marginTop: 2,
  },
  categoryScroll: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    paddingBottom: Spacing.md,
  },
  categoryCard: {
    width: 90,
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Colors.shadow.light,
  },
  categoryEmoji: {
    fontSize: 28,
    marginBottom: Spacing.xs,
  },
  categoryLabel: {
    fontSize: FontSize.xs,
    fontWeight: '600',
    color: Colors.textPrimary,
    textAlign: 'center',
  },
  categoryHindi: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    textAlign: 'center',
    marginTop: 2,
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: Colors.info + '08',
    borderRadius: BorderRadius.lg,
    marginHorizontal: Spacing.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.info + '20',
    gap: Spacing.md,
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: FontSize.md,
    fontWeight: '700',
    color: Colors.info,
    marginBottom: Spacing.xs,
  },
  infoText: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    lineHeight: 20,
  },
});
