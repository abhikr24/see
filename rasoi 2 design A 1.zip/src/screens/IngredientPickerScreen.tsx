import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';
import { CanonicalIngredient, IngredientCategory } from '../types/ingredient';
import { useIngredients, useIngredientSelection } from '../hooks/useIngredients';
import { SearchBar } from '../components/SearchBar';
import { CategoryChips } from '../components/CategoryChips';
import { IngredientCard } from '../components/IngredientCard';
import { SelectionSummary } from '../components/SelectionSummary';
import { SelectionModal } from '../components/SelectionModal';
import { EmptyState } from '../components/EmptyState';

interface IngredientPickerScreenProps {
  onAddToPantry: (ingredientIds: string[]) => void;
  isInPantry: (ingredientId: string) => boolean;
  onBack?: () => void;
}

export function IngredientPickerScreen({
  onAddToPantry,
  isInPantry,
}: IngredientPickerScreenProps) {
  const {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    results,
    isLoading,
    categories,
    categoryCounts,
  } = useIngredients();

  const {
    selectedIds,
    toggleSelection,
    isSelected,
    clearSelection,
    selectedCount,
    selectedIngredients,
  } = useIngredientSelection();

  const [showSelectionModal, setShowSelectionModal] = useState(false);

  const handleConfirm = useCallback(() => {
    if (selectedCount === 0) return;

    const ids = Array.from(selectedIds);
    onAddToPantry(ids);
    clearSelection();
    setShowSelectionModal(false);

    Alert.alert(
      'Added to Pantry! 🎉',
      `${ids.length} ingredient${ids.length > 1 ? 's' : ''} added to your pantry.`,
      [{ text: 'Great!', type: 'default' }]
    );
  }, [selectedIds, selectedCount, onAddToPantry, clearSelection]);

  const handleRemoveFromSelection = useCallback(
    (id: string) => {
      toggleSelection(id);
    },
    [toggleSelection]
  );

  const renderIngredient = useCallback(
    ({ item }: { item: CanonicalIngredient }) => (
      <IngredientCard
        ingredient={item}
        isSelected={isSelected(item.id)}
        onToggle={toggleSelection}
        isInPantry={isInPantry(item.id)}
      />
    ),
    [isSelected, toggleSelection, isInPantry]
  );

  const renderHeader = () => (
    <View>
      <SearchBar
        value={searchQuery}
        onChangeText={setSearchQuery}
        placeholder="Search: tamatar, aloo, jeera, dhaniya..."
        isLoading={isLoading}
      />
      <CategoryChips
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        categoryCounts={categoryCounts}
      />
      <View style={styles.resultCount}>
        <Text style={styles.resultCountText}>
          {results.length} ingredient{results.length !== 1 ? 's' : ''}
          {searchQuery ? ` matching "${searchQuery}"` : ''}
          {selectedCategory !== 'all' ? ` in category` : ''}
        </Text>
      </View>
    </View>
  );

  const renderEmpty = () => {
    if (isLoading) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>Searching ingredients...</Text>
        </View>
      );
    }
    return (
      <EmptyState
        emoji="🔍"
        title="No ingredients found"
        subtitle={`Try a different search term or category.\nYou can search by name, Hindi, or alias.`}
      />
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />

      {/* Screen Header */}
      <View style={styles.screenHeader}>
        <View style={styles.headerLeft}>
          <Text style={styles.screenTitle}>Ingredient Picker</Text>
          <Text style={styles.screenSubtitle}>Tap to select, then add to pantry</Text>
        </View>
        <View style={styles.headerBadge}>
          <Ionicons name="leaf" size={14} color={Colors.secondary} />
          <Text style={styles.headerBadgeText}>Offline</Text>
        </View>
      </View>

      {/* Ingredient List */}
      <FlatList
        data={results}
        renderItem={renderIngredient}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={[
          styles.listContent,
          results.length === 0 && styles.listContentEmpty,
        ]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        initialNumToRender={20}
        maxToRenderPerBatch={20}
        windowSize={10}
        removeClippedSubviews={false}
      />

      {/* Selection Summary Bar */}
      <SelectionSummary
        selectedCount={selectedCount}
        selectedIngredients={selectedIngredients}
        onConfirm={handleConfirm}
        onClear={clearSelection}
        onViewSelection={() => setShowSelectionModal(true)}
      />

      {/* Selection Detail Modal */}
      <SelectionModal
        visible={showSelectionModal}
        selectedIngredients={selectedIngredients}
        onClose={() => setShowSelectionModal(false)}
        onRemove={handleRemoveFromSelection}
        onConfirm={handleConfirm}
        onClear={() => {
          clearSelection();
          setShowSelectionModal(false);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  screenHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.sm,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  headerLeft: {},
  screenTitle: {
    fontSize: FontSize.xxl,
    fontWeight: '800',
    color: Colors.textPrimary,
  },
  screenSubtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginTop: 2,
  },
  headerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.secondary + '15',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
  },
  headerBadgeText: {
    fontSize: FontSize.xs,
    fontWeight: '600',
    color: Colors.secondary,
  },
  listContent: {
    paddingBottom: 120,
    paddingTop: Spacing.sm,
  },
  listContentEmpty: {
    flex: 1,
  },
  resultCount: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm,
  },
  resultCountText: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    fontWeight: '500',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.huge,
    gap: Spacing.md,
  },
  loadingText: {
    fontSize: FontSize.md,
    color: Colors.textTertiary,
  },
});
