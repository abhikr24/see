import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';
import { PantryItem, CanonicalIngredient } from '../types/ingredient';
import { EmptyState } from '../components/EmptyState';

interface PantryScreenProps {
  pantryIngredients: (PantryItem & { ingredient: CanonicalIngredient })[];
  isLoading: boolean;
  onRemove: (itemId: string) => void;
  onClearAll: () => void;
  onRefresh: () => void;
  onNavigateToPicker: () => void;
}

export function PantryScreen({
  pantryIngredients,
  isLoading,
  onRemove,
  onClearAll,
  onRefresh,
  onNavigateToPicker,
}: PantryScreenProps) {
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await onRefresh();
    setRefreshing(false);
  };

  const handleClearAll = () => {
    Alert.alert(
      'Clear Pantry?',
      'This will remove all items from your pantry. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: onClearAll,
        },
      ]
    );
  };

  const handleRemoveItem = (item: PantryItem & { ingredient: CanonicalIngredient }) => {
    Alert.alert(
      'Remove Item?',
      `Remove ${item.ingredient.englishName} from your pantry?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => onRemove(item.id),
        },
      ]
    );
  };

  // Group by category
  const groupedItems = pantryIngredients.reduce((acc, item) => {
    const cat = item.ingredient.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {} as Record<string, (PantryItem & { ingredient: CanonicalIngredient })[]>);

  const renderPantryItem = ({ item }: { item: PantryItem & { ingredient: CanonicalIngredient } }) => {
    const categoryColor = Colors.categoryColors[item.ingredient.category] || Colors.primary;
    const addedDate = new Date(item.addedAt);
    const dateStr = addedDate.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
    });

    return (
      <TouchableOpacity
        style={styles.itemCard}
        onLongPress={() => handleRemoveItem(item)}
        activeOpacity={0.8}
      >
        <View style={[styles.itemIcon, { backgroundColor: categoryColor + '18' }]}>
          <Text style={styles.itemEmoji}>{item.ingredient.imageEmoji}</Text>
        </View>
        <View style={styles.itemContent}>
          <Text style={styles.itemName} numberOfLines={1}>
            {item.ingredient.englishName}
          </Text>
          <Text style={styles.itemHindi} numberOfLines={1}>
            {item.ingredient.hindiName} • {item.ingredient.hindiTransliteration}
          </Text>
          <View style={styles.itemMeta}>
            <View style={[styles.itemTag, { backgroundColor: categoryColor + '15' }]}>
              <Text style={[styles.itemTagText, { color: categoryColor }]}>
                {item.ingredient.subcategory}
              </Text>
            </View>
            <Text style={styles.itemDate}>Added {dateStr}</Text>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => handleRemoveItem(item)}
          style={styles.removeBtn}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="close-circle-outline" size={22} color={Colors.textTertiary} />
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  const renderEmpty = () => (
    <EmptyState
      emoji="🧺"
      title="Your Pantry is Empty"
      subtitle="Add ingredients from the picker to build your virtual pantry. This helps track what you have at home."
      actionLabel="Browse Ingredients"
      onAction={onNavigateToPicker}
    />
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.screenTitle}>My Pantry</Text>
          <Text style={styles.screenSubtitle}>
            {pantryIngredients.length} {pantryIngredients.length === 1 ? 'item' : 'items'} stored
          </Text>
        </View>
        {pantryIngredients.length > 0 && (
          <TouchableOpacity onPress={handleClearAll} style={styles.clearButton}>
            <Ionicons name="trash-outline" size={18} color={Colors.error} />
            <Text style={styles.clearButtonText}>Clear</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Stats Bar */}
      {pantryIngredients.length > 0 && (
        <View style={styles.statsBar}>
          {Object.entries(groupedItems)
            .sort((a, b) => b[1].length - a[1].length)
            .slice(0, 4)
            .map(([cat, items]) => (
              <View key={cat} style={styles.statChip}>
                <Text style={styles.statChipEmoji}>
                  {items[0]?.ingredient.imageEmoji || '📦'}
                </Text>
                <Text style={styles.statChipCount}>{items.length}</Text>
              </View>
            ))}
        </View>
      )}

      {/* List */}
      <FlatList
        data={pantryIngredients}
        renderItem={renderPantryItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          pantryIngredients.length === 0 && styles.listContentEmpty,
        ]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={renderEmpty}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={Colors.primary}
          />
        }
      />

      {/* FAB */}
      {pantryIngredients.length > 0 && (
        <TouchableOpacity style={styles.fab} onPress={onNavigateToPicker} activeOpacity={0.85}>
          <Ionicons name="add" size={28} color="#FFF" />
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.md,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  screenTitle: {
    fontSize: FontSize.xxl,
    fontWeight: '800',
    color: Colors.textPrimary,
  },
  screenSubtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginTop: 2,
  },
  clearButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    padding: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.error + '10',
  },
  clearButtonText: {
    fontSize: FontSize.sm,
    fontWeight: '600',
    color: Colors.error,
  },
  statsBar: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  statChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: Colors.background,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    borderColor: Colors.borderLight,
  },
  statChipEmoji: {
    fontSize: 14,
  },
  statChipCount: {
    fontSize: FontSize.xs,
    fontWeight: '700',
    color: Colors.textSecondary,
  },
  listContent: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    paddingBottom: 100,
  },
  listContentEmpty: {
    flex: 1,
  },
  itemCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Colors.shadow.light,
  },
  itemIcon: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  itemEmoji: {
    fontSize: 22,
  },
  itemContent: {
    flex: 1,
  },
  itemName: {
    fontSize: FontSize.md,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  itemHindi: {
    fontSize: FontSize.sm,
    color: Colors.textSecondary,
    marginTop: 1,
  },
  itemMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginTop: 4,
  },
  itemTag: {
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: BorderRadius.sm,
  },
  itemTagText: {
    fontSize: FontSize.xs,
    fontWeight: '600',
  },
  itemDate: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
  },
  removeBtn: {
    padding: Spacing.xs,
  },
  fab: {
    position: 'absolute',
    bottom: Spacing.xxl,
    right: Spacing.xl,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Colors.shadow.heavy,
  },
});
