import React from 'react';
import { SafeAreaView, StatusBar } from 'react-native';
import { Colors } from '../theme/colors';
import { EmptyState } from '../components/EmptyState';

interface RecipesScreenProps {
  onNavigateToPicker: () => void;
}

export function RecipesScreen({ onNavigateToPicker }: RecipesScreenProps) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: Colors.background }}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />
      <EmptyState
        emoji="📖"
        title="Recipes Coming Soon"
        subtitle="Recipe discovery based on your pantry ingredients will be available in a future update. Build your pantry first!"
        actionLabel="Add Ingredients"
        onAction={onNavigateToPicker}
      />
    </SafeAreaView>
  );
}
