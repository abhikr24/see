import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, BorderRadius, FontSize } from '../theme/colors';
import { CANONICAL_INGREDIENTS } from '../data/ingredients';
import { INGREDIENT_CATEGORIES } from '../data/categories';

interface SettingsScreenProps {
  pantryCount: number;
  onClearPantry: () => void;
}

export function SettingsScreen({ pantryCount, onClearPantry }: SettingsScreenProps) {
  const totalIngredients = CANONICAL_INGREDIENTS.filter((i) => i.isActive).length;
  const totalCategories = INGREDIENT_CATEGORIES.length;

  const handleClearPantry = () => {
    Alert.alert(
      'Clear Pantry?',
      'This will remove all items from your pantry. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: onClearPantry,
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.screenTitle}>Settings</Text>
          <Text style={styles.screenSubtitle}>App preferences and information</Text>
        </View>

        {/* Database Info Section */}
        <Text style={styles.sectionTitle}>Database Info</Text>
        <View style={styles.card}>
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Ionicons name="leaf" size={20} color={Colors.secondary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Total Ingredients</Text>
              <Text style={styles.infoValue}>{totalIngredients}</Text>
            </View>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Ionicons name="grid" size={20} color={Colors.accent} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Categories</Text>
              <Text style={styles.infoValue}>{totalCategories}</Text>
            </View>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Ionicons name="basket" size={20} color={Colors.primary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Pantry Items</Text>
              <Text style={styles.infoValue}>{pantryCount}</Text>
            </View>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <View style={styles.infoIcon}>
              <Ionicons name="cloud-offline" size={20} color={Colors.info} />
            </View>
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>Data Mode</Text>
              <Text style={styles.infoValue}>Offline (Local)</Text>
            </View>
          </View>
        </View>

        {/* Actions Section */}
        <Text style={styles.sectionTitle}>Actions</Text>
        <View style={styles.card}>
          <TouchableOpacity style={styles.actionRow} onPress={handleClearPantry}>
            <View style={[styles.actionIcon, { backgroundColor: Colors.error + '15' }]}>
              <Ionicons name="trash" size={20} color={Colors.error} />
            </View>
            <View style={styles.actionContent}>
              <Text style={[styles.actionLabel, { color: Colors.error }]}>Clear Pantry</Text>
              <Text style={styles.actionSubtext}>Remove all pantry items</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={Colors.textTertiary} />
          </TouchableOpacity>
        </View>

        {/* About Section */}
        <Text style={styles.sectionTitle}>About</Text>
        <View style={styles.card}>
          <View style={styles.aboutRow}>
            <Text style={styles.aboutLabel}>App Name</Text>
            <Text style={styles.aboutValue}>Rasoi</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.aboutRow}>
            <Text style={styles.aboutLabel}>Version</Text>
            <Text style={styles.aboutValue}>2.0.0 (Stage 2)</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.aboutRow}>
            <Text style={styles.aboutLabel}>Stage</Text>
            <Text style={styles.aboutValue}>Ingredient Database + Visual Picker</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.aboutRow}>
            <Text style={styles.aboutLabel}>Framework</Text>
            <Text style={styles.aboutValue}>React Native + Expo</Text>
          </View>
        </View>

        {/* Features Section */}
        <Text style={styles.sectionTitle}>Stage 2 Features</Text>
        <View style={styles.card}>
          {[
            { icon: 'database', label: 'Canonical Ingredient Database', desc: `${totalIngredients}+ ingredients with full metadata` },
            { icon: 'search', label: 'Offline Search', desc: 'Search by name, Hindi, aliases, keywords' },
            { icon: 'swap-horizontal', label: 'Canonical Normalization', desc: 'Resolve aliases to single ingredient ID' },
            { icon: 'grid', label: 'Indian-First Categories', desc: 'Vegetables, dals, spices, rice, flours & more' },
            { icon: 'checkmark-done', label: 'Visual Ingredient Picker', desc: 'Browse, search, multi-select experience' },
            { icon: 'basket', label: 'Pantry Management', desc: 'Separate user pantry from canonical catalogue' },
            { icon: 'language', label: 'Multilingual Support', desc: 'English, Hindi, and transliteration' },
          ].map((feature, index) => (
            <React.Fragment key={feature.label}>
              {index > 0 && <View style={styles.divider} />}
              <View style={styles.featureRow}>
                <View style={styles.featureIcon}>
                  <Ionicons name={feature.icon as any} size={18} color={Colors.primary} />
                </View>
                <View style={styles.featureContent}>
                  <Text style={styles.featureLabel}>{feature.label}</Text>
                  <Text style={styles.featureDesc}>{feature.desc}</Text>
                </View>
                <Ionicons name="checkmark-circle" size={20} color={Colors.success} />
              </View>
            </React.Fragment>
          ))}
        </View>

        <View style={{ height: Spacing.huge }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: Spacing.lg,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    marginBottom: Spacing.xl,
  },
  screenTitle: {
    fontSize: FontSize.xxl,
    fontWeight: '800',
    color: Colors.textPrimary,
  },
  screenSubtitle: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginTop: 2,
  },
  sectionTitle: {
    fontSize: FontSize.md,
    fontWeight: '700',
    color: Colors.textSecondary,
    paddingHorizontal: Spacing.xl,
    marginBottom: Spacing.sm,
    marginTop: Spacing.md,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    marginHorizontal: Spacing.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    ...Colors.shadow.light,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  infoIcon: {
    width: 36,
    height: 36,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
  },
  infoValue: {
    fontSize: FontSize.md,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.borderLight,
    marginVertical: 2,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  actionIcon: {
    width: 36,
    height: 36,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  actionContent: {
    flex: 1,
  },
  actionLabel: {
    fontSize: FontSize.md,
    fontWeight: '600',
  },
  actionSubtext: {
    fontSize: FontSize.sm,
    color: Colors.textTertiary,
    marginTop: 1,
  },
  aboutRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  aboutLabel: {
    fontSize: FontSize.md,
    color: Colors.textSecondary,
  },
  aboutValue: {
    fontSize: FontSize.md,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  featureIcon: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.sm,
    backgroundColor: Colors.primary + '10',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  featureContent: {
    flex: 1,
  },
  featureLabel: {
    fontSize: FontSize.sm,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  featureDesc: {
    fontSize: FontSize.xs,
    color: Colors.textTertiary,
    marginTop: 1,
  },
});
