import { CanonicalIngredient, IngredientCategory } from '../types/ingredient';
import { CANONICAL_INGREDIENTS, getActiveIngredients } from '../data/ingredients';

/**
 * IngredientService - Core service for ingredient operations
 * Handles search, normalization, alias resolution, and data access
 */

// Build a normalized search index for fast offline lookups
interface SearchIndex {
  [normalizedTerm: string]: string[]; // term -> ingredient IDs
}

let searchIndex: SearchIndex | null = null;

/**
 * Normalize a string for search matching
 * Lowercase, trim, remove special chars
 */
function normalizeForSearch(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s\u0900-\u097F]/g, '') // keep alphanumeric + Devanagari
    .replace(/\s+/g, ' ');
}

/**
 * Build the search index from canonical ingredients
 * Maps normalized terms to ingredient IDs for O(1) lookups
 */
function buildSearchIndex(): SearchIndex {
  if (searchIndex) return searchIndex;

  const index: SearchIndex = {};

  CANONICAL_INGREDIENTS.forEach((ingredient) => {
    if (!ingredient.isActive) return;

    const terms = [
      ingredient.canonicalName,
      ingredient.englishName,
      ingredient.hindiName,
      ingredient.hindiTransliteration,
      ...ingredient.aliases,
      ...ingredient.keywords,
      ingredient.subcategory,
    ];

    terms.forEach((term) => {
      const normalized = normalizeForSearch(term);
      if (!normalized) return;

      // Index the full term
      if (!index[normalized]) {
        index[normalized] = [];
      }
      if (!index[normalized].includes(ingredient.id)) {
        index[normalized].push(ingredient.id);
      }

      // Index individual words for partial matching
      const words = normalized.split(' ').filter((w) => w.length > 1);
      words.forEach((word) => {
        if (!index[word]) {
          index[word] = [];
        }
        if (!index[word].includes(ingredient.id)) {
          index[word].push(ingredient.id);
        }
      });
    });
  });

  searchIndex = index;
  return index;
}

/**
 * Search ingredients by query string
 * Supports: canonical name, English name, Hindi name, aliases, keywords
 * Returns results ranked by match quality
 */
export function searchIngredients(query: string): CanonicalIngredient[] {
  if (!query || query.trim().length === 0) {
    return getActiveIngredients();
  }

  const index = buildSearchIndex();
  const normalizedQuery = normalizeForSearch(query);
  const queryWords = normalizedQuery.split(' ').filter((w) => w.length > 0);

  // Score each ingredient based on match quality
  const scores = new Map<string, number>();

  queryWords.forEach((word) => {
    Object.entries(index).forEach(([term, ids]) => {
      if (term.includes(word) || word.includes(term)) {
        const matchQuality = term === word ? 10 : term.startsWith(word) ? 7 : term.includes(word) ? 4 : 2;
        ids.forEach((id) => {
          scores.set(id, (scores.get(id) || 0) + matchQuality);
        });
      }
    });
  });

  // Get ingredients sorted by score
  const results = Array.from(scores.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([id]) => CANONICAL_INGREDIENTS.find((i) => i.id === id))
    .filter((i): i is CanonicalIngredient => i !== undefined && i.isActive);

  return results;
}

/**
 * Resolve a name/alias to a canonical ingredient ID
 * This is the core normalization function
 */
export function resolveCanonicalId(input: string): string | null {
  const index = buildSearchIndex();
  const normalized = normalizeForSearch(input);

  // Exact match first
  if (index[normalized] && index[normalized].length > 0) {
    return index[normalized][0];
  }

  // Try without spaces
  const noSpaces = normalized.replace(/\s/g, '');
  const matchKey = Object.keys(index).find((key) => key.replace(/\s/g, '') === noSpaces);
  if (matchKey && index[matchKey].length > 0) {
    return index[matchKey][0];
  }

  return null;
}

/**
 * Get an ingredient by its canonical ID
 */
export function getIngredientById(id: string): CanonicalIngredient | undefined {
  return CANONICAL_INGREDIENTS.find((i) => i.id === id);
}

/**
 * Get multiple ingredients by IDs
 */
export function getIngredientsByIds(ids: string[]): CanonicalIngredient[] {
  const idSet = new Set(ids);
  return CANONICAL_INGREDIENTS.filter((i) => idSet.has(i.id) && i.isActive);
}

/**
 * Get all ingredients for a category
 */
export function getIngredientsByCategory(category: IngredientCategory): CanonicalIngredient[] {
  return CANONICAL_INGREDIENTS.filter((i) => i.isActive && i.category === category);
}

/**
 * Get all unique categories from active ingredients
 */
export function getAvailableCategories(): IngredientCategory[] {
  const categories = new Set<IngredientCategory>();
  CANONICAL_INGREDIENTS.filter((i) => i.isActive).forEach((i) => categories.add(i.category));
  return Array.from(categories);
}

/**
 * Get essential/common ingredients for quick access
 */
export function getQuickAccessIngredients(): CanonicalIngredient[] {
  return CANONICAL_INGREDIENTS.filter(
    (i) => i.isActive && (i.householdRelevance === 'essential' || i.householdRelevance === 'common')
  ).slice(0, 30);
}

/**
 * Get ingredient count per category
 */
export function getCategoryCounts(): Record<string, number> {
  const counts: Record<string, number> = {};
  CANONICAL_INGREDIENTS.filter((i) => i.isActive).forEach((i) => {
    counts[i.category] = (counts[i.category] || 0) + 1;
  });
  return counts;
}
