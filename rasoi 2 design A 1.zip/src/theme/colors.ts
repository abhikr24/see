// Rasoi Theme Colors - Warm Indian-inspired palette

export const Colors = {
  // Primary - Saffron/Orange (Indian flag inspired)
  primary: '#E65100',
  primaryLight: '#FF8A50',
  primaryDark: '#AC1900',

  // Secondary - Deep Green
  secondary: '#2E7D32',
  secondaryLight: '#60AD5E',
  secondaryDark: '#005005',

  // Accent - Turmeric Gold
  accent: '#F9A825',
  accentLight: '#FFD95A',
  accentDark: '#C17900',

  // Backgrounds
  background: '#FAFAF5',
  surface: '#FFFFFF',
  surfaceElevated: '#FFFFFF',
  cardBg: '#FFFFFF',

  // Text
  textPrimary: '#1A1A2E',
  textSecondary: '#4A4A68',
  textTertiary: '#8E8EA0',
  textOnPrimary: '#FFFFFF',
  textOnAccent: '#1A1A2E',

  // Borders & Dividers
  border: '#E8E8E0',
  borderLight: '#F0F0E8',
  divider: '#E0E0D8',

  // Status
  success: '#4CAF50',
  warning: '#FF9800',
  error: '#F44336',
  info: '#2196F3',

  // Category Colors
  categoryColors: {
    vegetables: '#4CAF50',
    fruits: '#E91E63',
    grains: '#795548',
    rice: '#9E9E9E',
    flours: '#A1887F',
    dals_pulses: '#FF9800',
    spices: '#E65100',
    dairy: '#42A5F5',
    oils_fats: '#FDD835',
    nuts_seeds: '#6D4C41',
    herbs: '#66BB6A',
    condiments: '#EF5350',
    sweeteners: '#F48FB1',
    meat_poultry: '#C62828',
    seafood: '#0288D1',
    eggs: '#FFF176',
    beverages: '#80DEEA',
    misc: '#B0BEC5',
  } as Record<string, string>,

  // Shadows
  shadow: {
    light: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.08,
      shadowRadius: 4,
      elevation: 2,
    },
    medium: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.12,
      shadowRadius: 8,
      elevation: 4,
    },
    heavy: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.16,
      shadowRadius: 12,
      elevation: 8,
    },
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  huge: 48,
};

export const BorderRadius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 20,
  full: 999,
};

export const FontSize = {
  xs: 10,
  sm: 12,
  md: 14,
  lg: 16,
  xl: 18,
  xxl: 22,
  xxxl: 28,
  display: 34,
};
