// Canonical Ingredient Type Definitions for Rasoi App

export type IngredientCategory =
  | 'vegetables'
  | 'fruits'
  | 'grains'
  | 'rice'
  | 'flours'
  | 'dals_pulses'
  | 'spices'
  | 'dairy'
  | 'oils_fats'
  | 'nuts_seeds'
  | 'herbs'
  | 'condiments'
  | 'sweeteners'
  | 'meat_poultry'
  | 'seafood'
  | 'eggs'
  | 'beverages'
  | 'misc';

export type HouseholdRelevance = 'essential' | 'common' | 'specialty';

export interface CanonicalIngredient {
  id: string;
  canonicalName: string;
  englishName: string;
  hindiName: string;
  hindiTransliteration: string;
  aliases: string[];
  category: IngredientCategory;
  subcategory: string;
  keywords: string[];
  unitOptions: string[];
  imageEmoji: string;
  commonInCuisines: string[];
  householdRelevance: HouseholdRelevance;
  isActive: boolean;
  seasonalInfo?: {
    available: string[];
    peak: string[];
  };
}

export interface IngredientCategoryMeta {
  id: IngredientCategory;
  label: string;
  hindiLabel: string;
  emoji: string;
  description: string;
}

export interface PantryItem {
  id: string;
  ingredientId: string;
  quantity: number;
  unit: string;
  addedAt: string;
  expiresAt?: string;
  notes?: string;
}

export interface SelectionState {
  selectedIds: Set<string>;
  lastAdded?: string;
}
