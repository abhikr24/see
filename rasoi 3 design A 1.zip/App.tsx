import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import * as db from './src/data/db';
import { ThemeProvider, useTheme } from './src/theme';
import { I18nProvider } from './src/i18n';
import { PantryProvider } from './src/context/PantryContext';
import { RecipeProvider } from './src/context/RecipeContext';
import { AppNavigator } from './src/navigation/AppNavigator';

// Eagerly kick off repository initialization (migrations + seeding) so the
// database is warm by the time the user reaches a recipe screen.
db.getRecipeRepository().catch(() => {
  /* fallback handled lazily inside the provider */
});

function ThemedApp() {
  const { resolved } = useTheme();
  return (
    <>
      <StatusBar style={resolved === 'dark' ? 'light' : 'dark'} />
      <NavigationContainer>
        <AppNavigator />
      </NavigationContainer>
    </>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({ ...Ionicons.font });
  const [minBoot, setMinBoot] = useState(false);

  // Keep the splash visible briefly so providers hydrate without a flash.
  useEffect(() => {
    const id = setTimeout(() => setMinBoot(true), 250);
    return () => clearTimeout(id);
  }, []);

  if (!fontsLoaded || !minBoot) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FBF7F0' }}>
        <ActivityIndicator size="large" color="#E07A1F" />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <I18nProvider>
          <PantryProvider>
            <RecipeProvider>
              <ThemedApp />
            </RecipeProvider>
          </PantryProvider>
        </I18nProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
