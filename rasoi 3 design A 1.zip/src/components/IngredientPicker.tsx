import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Modal, StyleSheet, Text, View } from 'react-native';
import type { Ingredient, IngredientCategory } from '../data/ingredients';
import { CATEGORY_META, CATEGORY_ORDER, INGREDIENT_CATALOGUE, searchIngredients } from '../data/ingredients';
import { radius, spacing, typography, useTheme } from '../theme';
import { Chip } from './Chip';
import { IngredientTile } from './IngredientTile';
import { SearchBar } from './SearchBar';
import { Button } from './Button';

interface IngredientPickerProps {
  visible: boolean;
  onPick: (ingredient: Ingredient) => void;
  onClose: () => void;
  excludeIds?: string[];
}

const NUM_COLUMNS = 4;

export function IngredientPicker({ visible, onPick, onClose, excludeIds }: IngredientPickerProps) {
  const { colors } = useTheme();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<IngredientCategory | 'all'>('all');

  const exclude = useMemo(() => new Set(excludeIds ?? []), [excludeIds]);

  const results = useMemo(() => {
    const list = query
      ? searchIngredients(query, { category }).map((r) => r.ingredient)
      : (category === 'all' ? INGREDIENT_CATALOGUE : INGREDIENT_CATALOGUE.filter((i) => i.category === category));
    return list.filter((i) => !exclude.has(i.id));
  }, [query, category, exclude]);

  const handlePick = useCallback(
    (ing: Ingredient) => {
      onPick(ing);
      setQuery('');
      setCategory('all');
    },
    [onPick],
  );

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} transparent={false}>
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { borderBottomColor: colors.divider }]}>
          <Text style={[styles.title, { color: colors.textPrimary }]}>Select ingredient</Text>
          <Button label="Cancel" variant="ghost" onPress={onClose} style={styles.cancel} />
        </View>
        <View style={styles.searchWrap}>
          <SearchBar value={query} onChange={setQuery} placeholder="Search ingredients…" autoFocus />
        </View>
        <View style={styles.chips}>
          <Chip label="All" selected={category === 'all'} onPress={() => setCategory('all')} />
          {CATEGORY_ORDER.map((cat) => (
            <Chip
              key={cat}
              label={CATEGORY_META[cat].en}
              icon={CATEGORY_META[cat].emoji}
              selected={category === cat}
              onPress={() => setCategory(cat)}
            />
          ))}
        </View>
        {results.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>🔍</Text>
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>No ingredients found</Text>
          </View>
        ) : (
          <FlatList
            data={results}
            keyExtractor={(i) => i.id}
            numColumns={NUM_COLUMNS}
            contentContainerStyle={styles.list}
            columnWrapperStyle={styles.row}
            renderItem={({ item }) => (
              <IngredientTile ingredient={item} selected={false} onPress={() => handlePick(item)} />
            )}
          />
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: spacing.xxxl },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.edge,
    paddingBottom: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  title: { ...typography.h2 },
  cancel: { height: 36, paddingHorizontal: spacing.sm },
  searchWrap: { paddingHorizontal: spacing.edge, paddingTop: spacing.md },
  chips: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: spacing.edge, paddingTop: spacing.sm },
  list: { padding: spacing.edge, paddingTop: spacing.md },
  row: { marginBottom: spacing.xs },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyEmoji: { fontSize: 44, marginBottom: spacing.sm },
  emptyText: { ...typography.body },
});
