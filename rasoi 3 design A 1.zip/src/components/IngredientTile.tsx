import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import type { Ingredient } from '../data/ingredients';
import { radius, spacing, typography, useTheme } from '../theme';

interface IngredientTileProps {
  ingredient: Ingredient;
  selected: boolean;
  onPress: () => void;
}

export function IngredientTile({ ingredient, selected, onPress }: IngredientTileProps) {
  const { colors } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.tile,
        {
          backgroundColor: colors.surface,
          borderColor: selected ? colors.primary : colors.border,
          borderWidth: selected ? 2 : StyleSheet.hairlineWidth,
        },
        pressed && { opacity: 0.8, transform: [{ scale: 0.96 }] },
      ]}
    >
      <View style={[styles.emojiWrap, { backgroundColor: selected ? colors.primarySoft : colors.surfaceAlt }]}>
        <Text style={styles.emoji}>{ingredient.emoji}</Text>
        {selected ? (
          <View style={[styles.check, { backgroundColor: colors.primary }]}>
            <Ionicons name="checkmark" size={12} color="#fff" />
          </View>
        ) : null}
      </View>
      <Text style={[styles.name, { color: colors.textPrimary }]} numberOfLines={2}>
        {ingredient.name.en}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tile: {
    flex: 1,
    borderRadius: radius.md,
    padding: spacing.xs,
    alignItems: 'center',
  },
  emojiWrap: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs2,
  },
  emoji: { fontSize: 26 },
  check: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: { ...typography.micro, textAlign: 'center', lineHeight: 13 },
});
