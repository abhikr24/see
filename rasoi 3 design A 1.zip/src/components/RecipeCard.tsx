import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import type { RecipeSummary } from '../data/recipes';
import { formatMinutes } from '../lib/format';
import { radius, shadow, spacing, typography, useTheme } from '../theme';
import { CATEGORY_EMOJI, DIFFICULTY_META } from './recipeMeta';

interface RecipeCardProps {
  recipe: RecipeSummary;
  onPress: () => void;
}

export function RecipeCard({ recipe, onPress }: RecipeCardProps) {
  const { colors } = useTheme();
  const diff = DIFFICULTY_META[recipe.difficulty];
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: colors.surface },
        shadow(colors, 5, 0.1),
        pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
      ]}
    >
      <View style={[styles.header, { backgroundColor: recipe.accentColor }]}>
        <Text style={styles.headerEmoji}>{CATEGORY_EMOJI[recipe.category]}</Text>
        {recipe.isFavorite ? (
          <View style={styles.favBadge}>
            <Ionicons name="heart" size={14} color="#fff" />
          </View>
        ) : null}
        {typeof recipe.pantryMatch === 'number' && recipe.pantryMatch > 0 ? (
          <View style={styles.matchBadge}>
            <Text style={styles.matchText}>{recipe.pantryMatch}/{recipe.ingredientCount}</Text>
          </View>
        ) : null}
      </View>
      <View style={styles.body}>
        <Text style={[styles.title, { color: colors.textPrimary }]} numberOfLines={2}>
          {recipe.title}
        </Text>
        <Text style={[styles.cuisine, { color: colors.textSecondary }]} numberOfLines={1}>
          {recipe.cuisine} · {recipe.difficulty}
        </Text>
        <View style={styles.metaRow}>
          <View style={styles.metaItem}>
            <Ionicons name="time-outline" size={14} color={colors.textMuted} />
            <Text style={[styles.metaText, { color: colors.textMuted }]}>
              {formatMinutes(recipe.totalTimeMin)}
            </Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="flame-outline" size={14} color={colors.textMuted} />
            <Text style={[styles.metaText, { color: colors.textMuted }]}>
              {recipe.caloriesPerServing ?? '—'}
            </Text>
          </View>
          <View style={styles.metaItem}>
            <Text style={styles.diffDot}>{diff.emoji}</Text>
            <Text style={[styles.metaText, { color: colors.textMuted }]}>{recipe.servings}🥢</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    marginBottom: spacing.md,
  },
  header: {
    height: 92,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerEmoji: { fontSize: 38 },
  favBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: 'rgba(0,0,0,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  matchBadge: {
    position: 'absolute',
    top: 10,
    left: 10,
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  matchText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  body: { padding: spacing.md },
  title: { ...typography.h3, marginBottom: 2 },
  cuisine: { ...typography.caption, marginBottom: spacing.sm, textTransform: 'capitalize' },
  metaRow: { flexDirection: 'row', alignItems: 'center' },
  metaItem: { flexDirection: 'row', alignItems: 'center', marginRight: spacing.md },
  metaText: { ...typography.micro, marginLeft: 3 },
  diffDot: { fontSize: 10 },
});
