import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { spacing, typography, useTheme } from '../theme';

interface SectionHeaderProps {
  title: string;
  actionLabel?: string;
  onAction?: () => void;
  emoji?: string;
}

export function SectionHeader({ title, actionLabel, onAction, emoji }: SectionHeaderProps) {
  const { colors } = useTheme();
  return (
    <View style={styles.row}>
      <View style={styles.titleRow}>
        {emoji ? <Text style={styles.emoji}>{emoji}</Text> : null}
        <Text style={[styles.title, { color: colors.textPrimary }]}>{title}</Text>
      </View>
      {actionLabel && onAction ? (
        <Pressable onPress={onAction} hitSlop={8} style={({ pressed }) => pressed && { opacity: 0.5 }}>
          <Text style={[styles.action, { color: colors.primary }]}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.edge,
    marginTop: spacing.xl,
    marginBottom: spacing.sm,
  },
  titleRow: { flexDirection: 'row', alignItems: 'center' },
  emoji: { fontSize: 18, marginRight: spacing.xs },
  title: { ...typography.h2 },
  action: { ...typography.caption, fontWeight: '700' },
});
