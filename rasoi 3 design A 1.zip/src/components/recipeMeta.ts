import type { Difficulty, RecipeCategory } from '../data/recipes';
import type { Unit } from '../data/ingredients';

export const CATEGORY_EMOJI: Record<RecipeCategory, string> = {
  breakfast: '🍳',
  lunch: '🍱',
  dinner: '🍽️',
  snack: '🥨',
  dessert: '🍰',
  beverage: '☕',
  side: '🍚',
};

export const DIFFICULTY_META: Record<Difficulty, { emoji: string; tint: string }> = {
  easy: { emoji: '🟢', tint: '#2E7D5B' },
  medium: { emoji: '🟡', tint: '#E2A93B' },
  hard: { emoji: '🔴', tint: '#C0392B' },
};

const UNIT_LABEL: Record<Unit, string> = {
  g: 'g',
  kg: 'kg',
  ml: 'ml',
  l: 'l',
  tsp: 'tsp',
  tbsp: 'tbsp',
  cup: 'cup',
  piece: '',
  clove: 'clove',
  pinch: 'pinch',
  to_taste: 'to taste',
  slice: 'slice',
  handful: 'handful',
  stick: 'stick',
  can: 'can',
};

export function formatQuantity(qty: number, unit: Unit): string {
  const q = Number.isInteger(qty) ? String(qty) : String(Math.round(qty * 100) / 100);
  const u = UNIT_LABEL[unit];
  if (!u) return q;
  if (u === 'to taste') return u;
  return `${q} ${u}`;
}

export function unitLabel(unit: Unit): string {
  return UNIT_LABEL[unit] || unit;
}

export const UNIT_OPTIONS: Unit[] = [
  'g', 'kg', 'ml', 'l', 'tsp', 'tbsp', 'cup', 'piece', 'clove', 'pinch', 'handful', 'stick', 'slice', 'can', 'to_taste',
];
