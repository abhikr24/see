import React, { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { loadJSON, saveJSON } from '../lib/storage';

/**
 * PANTRY (Stage 2 — preserved).
 *
 * The user's selected pantry ingredients, persisted to AsyncStorage. This is
 * user-owned local data, fully separate from the static ingredient catalogue
 * and the SQLite recipe store. The pantry feeds the "What can I cook" flow in
 * Stage 3 by matching pantry ingredient ids against recipe ingredient links.
 */
interface PantryContextValue {
  ids: string[];
  ready: boolean;
  has: (id: string) => boolean;
  toggle: (id: string) => void;
  addMany: (ids: string[]) => void;
  remove: (id: string) => void;
  clear: () => void;
}

const PantryContext = createContext<PantryContextValue | null>(null);

export function PantryProvider({ children }: { children: ReactNode }) {
  const [ids, setIds] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    loadJSON<string[]>('pantry', []).then((stored) => {
      setIds(stored);
      setReady(true);
    });
  }, []);

  const persist = useCallback((next: string[]) => {
    setIds(next);
    saveJSON('pantry', next);
  }, []);

  const value = useMemo<PantryContextValue>(
    () => ({
      ids,
      ready,
      has: (id) => ids.includes(id),
      toggle: (id) =>
        persist(ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]),
      addMany: (incoming) =>
        persist(Array.from(new Set([...ids, ...incoming]))),
      remove: (id) => persist(ids.filter((x) => x !== id)),
      clear: () => persist([]),
    }),
    [ids, ready, persist],
  );

  return <PantryContext.Provider value={value}>{children}</PantryContext.Provider>;
}

export function usePantry(): PantryContextValue {
  const v = useContext(PantryContext);
  if (!v) throw new Error('usePantry must be used within PantryProvider');
  return v;
}
