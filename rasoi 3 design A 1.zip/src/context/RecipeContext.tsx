import React, { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { getRecipeRepository, getResolvedEngine } from '../data/db';
import type { RecipeRepository } from '../data/recipes/repository';
import type { DatabaseStats, RecipeSummary } from '../data/recipes/types';

/**
 * RECIPE DATA LAYER WIRING (Stage 3).
 *
 * Connects the repository/data layer into the existing Rasoi architecture for
 * retrieval/display. Holds the initialized repository, the current list of
 * recipe summaries, and live catalogue statistics. Screens read summaries from
 * here and call `repo` directly for detail/CRUD operations, then `refresh()`.
 */
interface RecipeContextValue {
  ready: boolean;
  engine: 'sqlite' | 'memory' | null;
  repo: RecipeRepository | null;
  summaries: RecipeSummary[];
  stats: DatabaseStats | null;
  error: string | null;
  refresh: () => Promise<void>;
  reseed: () => Promise<void>;
}

const RecipeContext = createContext<RecipeContextValue | null>(null);

export function RecipeProvider({ children }: { children: ReactNode }) {
  const [repo, setRepo] = useState<RecipeRepository | null>(null);
  const [engine, setEngine] = useState<'sqlite' | 'memory' | null>(null);
  const [summaries, setSummaries] = useState<RecipeSummary[]>([]);
  const [stats, setStats] = useState<DatabaseStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  const refresh = useCallback(async () => {
    if (!repo) return;
    try {
      const [list, s] = await Promise.all([repo.list(), repo.stats()]);
      setSummaries(list);
      setStats(s);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load recipes');
    }
  }, [repo]);

  const reseed = useCallback(async () => {
    if (!repo) return;
    await repo.reseedCatalogue();
    await refresh();
  }, [repo, refresh]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await getRecipeRepository();
        if (cancelled) return;
        setRepo(r);
        setEngine(getResolvedEngine());
        const [list, s] = await Promise.all([r.list(), r.stats()]);
        if (cancelled) return;
        setSummaries(list);
        setStats(s);
        setReady(true);
      } catch (e) {
        if (cancelled) return;
        setError(e instanceof Error ? e.message : 'Database initialization failed');
        setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const value = useMemo<RecipeContextValue>(
    () => ({ ready, engine, repo, summaries, stats, error, refresh, reseed }),
    [ready, engine, repo, summaries, stats, error, refresh, reseed],
  );

  return <RecipeContext.Provider value={value}>{children}</RecipeContext.Provider>;
}

export function useRecipes(): RecipeContextValue {
  const v = useContext(RecipeContext);
  if (!v) throw new Error('useRecipes must be used within RecipeProvider');
  return v;
}
