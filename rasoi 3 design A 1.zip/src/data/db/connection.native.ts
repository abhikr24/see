// NATIVE CONNECTION (Stage 3) — real on-device SQLite via expo-sqlite.
//
// This file is selected by Metro on iOS/Android/macOS. On web, the bundler
// resolves `connection.ts` instead (which throws, triggering the in-memory
// fallback). expo-sqlite is therefore never bundled for web.

import * as SQLite from 'expo-sqlite';
import type { SQLiteDatabase } from 'expo-sqlite';

const DB_NAME = 'rasoi.db';

let dbInstance: SQLiteDatabase | null = null;

export async function openDatabase(): Promise<SQLiteDatabase> {
  if (dbInstance) return dbInstance;
  const db = await SQLite.openDatabaseAsync(DB_NAME);
  // Database safety: enable WAL for concurrent reads + durability, and enforce
  // foreign keys so cascade deletes on recipe removal are honoured.
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
  `);
  dbInstance = db;
  return db;
}

export async function closeDatabase(): Promise<void> {
  if (dbInstance) {
    await dbInstance.closeAsync();
    dbInstance = null;
  }
}
