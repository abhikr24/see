// WEB FALLBACK (Stage 3).
//
// expo-sqlite's web backend requires wasm + SharedArrayBuffer + COOP/COEP
// headers, which are unreliable in preview environments. Rather than risk a
// broken preview, the web build never opens SQLite — `openDatabase()` always
// throws, and the repository factory falls back to `MemoryRecipeRepository`.
//
// On native (iOS/Android), Metro resolves `connection.native.ts` instead,
// which uses the real on-device SQLite. This keeps a single repository contract
// while guaranteeing the app works everywhere.
//
// TypeScript resolves THIS file (the non-platform variant) for type-checking,
// so the signature must match `connection.native.ts`.

import type { SQLiteDatabase } from 'expo-sqlite';

export class SqliteUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SqliteUnavailableError';
  }
}

export async function openDatabase(): Promise<SQLiteDatabase> {
  throw new SqliteUnavailableError(
    'On-device SQLite is unavailable in this environment — using in-memory repository fallback.',
  );
}

export async function closeDatabase(): Promise<void> {
  // No-op on web.
}
