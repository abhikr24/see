// Public data-layer barrel (Stage 3).
export { getRecipeRepository, getResolvedEngine, resetRepositoryCache, closeRepository } from './recipeRepository';
export type { RecipeRepository } from '../recipes/repository';
export { SqliteRecipeRepository } from './recipeRepository.sqlite';
export { MemoryRecipeRepository } from './recipeRepository.memory';
export { MIGRATIONS, LATEST_SCHEMA_VERSION } from './schema';
export type { Migration } from './schema';
