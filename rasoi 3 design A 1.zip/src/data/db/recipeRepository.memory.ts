import { INGREDIENT_CATALOGUE } from '../ingredients';
import { composeRecipe, toSummary } from '../recipes/mapper';
import { SEED_RECIPES } from '../recipes/seedRecipes';
import type { RecipeRepository } from '../recipes/repository';
import type {
  DatabaseStats,
  Recipe,
  RecipeFilters,
  RecipeInput,
  RecipeSummary,
} from '../recipes/types';
import { validateRecipe } from '../recipes/validation';
import { LATEST_SCHEMA_VERSION } from './schema';

interface PersistedState {
  user: Recipe[];
  favorites: string[];
  seededAt: number | null;
}

/**
 * Persister abstraction — decouples the in-memory repository from any storage
 * backend. The app supplies an AsyncStorage-backed persister (web); the node
 * test suite supplies none (pure in-memory). This keeps the repository free of
 * any react-native import so it runs in Node.
 */
export interface MemoryPersister {
  load(): Promise<PersistedState | null>;
  save(state: PersistedState): Promise<void>;
}

const EMPTY_STATE: PersistedState = { user: [], favorites: [], seededAt: null };

/**
 * In-memory repository (web fallback + test double).
 *
 * Implements the exact same `RecipeRepository` contract as the SQLite
 * implementation, but keeps data in Maps. Catalogue recipes are always derived
 * from the bundled seed (source of truth = code), while user-owned recipes and
 * favourites are optionally persisted via a `MemoryPersister` so the web
 * preview keeps user changes across reloads.
 */
export class MemoryRecipeRepository implements RecipeRepository {
  private catalogue = new Map<string, Recipe>();
  private userRecipes = new Map<string, Recipe>();
  private favorites = new Set<string>();
  private seededAt: number | null = null;
  private initialized = false;

  constructor(private readonly persister?: MemoryPersister) {}

  async init(): Promise<void> {
    if (this.initialized) return;
    // Catalogue is always re-derived from code (never persisted).
    this.reseedCatalogueData();
    if (this.persister) {
      const state = (await this.persister.load()) ?? EMPTY_STATE;
      for (const r of state.user) this.userRecipes.set(r.id, r);
      for (const id of state.favorites) this.favorites.add(id);
      this.seededAt = state.seededAt ?? Date.now();
    } else {
      this.seededAt = Date.now();
    }
    this.initialized = true;
  }

  private all(): Recipe[] {
    return [...this.userRecipes.values(), ...this.catalogue.values()];
  }

  private find(id: string): Recipe | undefined {
    return this.userRecipes.get(id) ?? this.catalogue.get(id);
  }

  private async persist(): Promise<void> {
    if (!this.persister) return;
    await this.persister.save({
      user: [...this.userRecipes.values()],
      favorites: [...this.favorites],
      seededAt: this.seededAt,
    });
  }

  private summary(r: Recipe, pantryIds?: string[]): RecipeSummary {
    const s = toSummary(r, pantryIds);
    s.isFavorite = this.favorites.has(r.id);
    return s;
  }

  private reseedCatalogueData(): void {
    this.catalogue.clear();
    for (const input of SEED_RECIPES) {
      if (!validateRecipe(input).valid) continue;
      this.catalogue.set(input.id!, composeRecipe(input));
    }
    this.seededAt = Date.now();
  }

  // ── Reads ──────────────────────────────────────────────────────────
  async list(): Promise<RecipeSummary[]> {
    return this.all()
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((r) => this.summary(r));
  }

  async search(filters: RecipeFilters): Promise<RecipeSummary[]> {
    let items = this.all();

    if (filters.query) {
      const q = filters.query.toLowerCase();
      items = items.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          r.description.toLowerCase().includes(q) ||
          r.cuisine.toLowerCase().includes(q) ||
          r.tags.some((tag) => tag.includes(q)),
      );
    }
    if (filters.category && filters.category !== 'all') {
      items = items.filter((r) => r.category === filters.category);
    }
    if (filters.cuisine) {
      const c = filters.cuisine.toLowerCase();
      items = items.filter((r) => r.cuisine === c);
    }
    if (filters.difficulty && filters.difficulty !== 'all') {
      items = items.filter((r) => r.difficulty === filters.difficulty);
    }
    if (filters.source && filters.source !== 'all') {
      items = items.filter((r) => r.source === filters.source);
    }
    if (filters.onlyFavorites) {
      items = items.filter((r) => this.favorites.has(r.id));
    }
    if (filters.ingredientIds && filters.ingredientIds.length > 0) {
      const need = new Set(filters.ingredientIds);
      items = items.filter((r) => r.ingredients.every((ri) => need.has(ri.ingredientId)));
    }

    const sort = filters.sort ?? 'relevance';
    items.sort((a, b) => {
      switch (sort) {
        case 'time': return a.totalTimeMin - b.totalTimeMin || (b.rating ?? 0) - (a.rating ?? 0);
        case 'rating': return (b.rating ?? 0) - (a.rating ?? 0) || a.totalTimeMin - b.totalTimeMin;
        case 'newest': return b.updatedAt - a.updatedAt;
        case 'alpha': return a.title.localeCompare(b.title);
        case 'relevance':
        default: return (b.rating ?? 0) - (a.rating ?? 0) || b.updatedAt - a.updatedAt;
      }
    });

    return items.map((r) => this.summary(r));
  }

  async getById(id: string): Promise<Recipe | null> {
    return this.find(id) ?? null;
  }

  async getFavorites(): Promise<RecipeSummary[]> {
    return this.all()
      .filter((r) => this.favorites.has(r.id))
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((r) => this.summary(r));
  }

  async getByIngredients(ingredientIds: string[]): Promise<RecipeSummary[]> {
    if (ingredientIds.length === 0) return [];
    const pantry = new Set(ingredientIds);
    return this.all()
      .map((r) => ({ r, match: r.ingredients.filter((ri) => pantry.has(ri.ingredientId)).length }))
      .filter((x) => x.match > 0)
      .sort((a, b) => b.match - a.match || (b.r.rating ?? 0) - (a.r.rating ?? 0) || a.r.totalTimeMin - b.r.totalTimeMin)
      .map((x) => this.summary(x.r, ingredientIds));
  }

  async count(): Promise<number> {
    return this.all().length;
  }

  async stats(): Promise<DatabaseStats> {
    return {
      engine: 'memory',
      schemaVersion: LATEST_SCHEMA_VERSION,
      recipeCount: this.all().length,
      catalogueCount: this.catalogue.size,
      userCount: this.userRecipes.size,
      favoriteCount: this.favorites.size,
      ingredientCount: INGREDIENT_CATALOGUE.length,
      seededAt: this.seededAt ?? undefined,
    };
  }

  // ── Writes ─────────────────────────────────────────────────────────
  async upsert(input: RecipeInput): Promise<string> {
    const result = validateRecipe(input);
    if (!result.valid) {
      throw new Error(`Invalid recipe: ${result.errors[0].field} — ${result.errors[0].message}`);
    }
    const recipe = composeRecipe(input);
    this.store(recipe);
    await this.persist();
    return recipe.id;
  }

  async bulkUpsert(inputs: RecipeInput[]): Promise<{ inserted: number; updated: number }> {
    let inserted = 0;
    let updated = 0;
    for (const input of inputs) {
      if (!validateRecipe(input).valid) continue;
      const recipe = composeRecipe(input);
      const existed = this.find(recipe.id) !== undefined;
      this.store(recipe);
      if (existed) updated++; else inserted++;
    }
    await this.persist();
    return { inserted, updated };
  }

  private store(recipe: Recipe): void {
    if (recipe.source === 'catalogue') this.catalogue.set(recipe.id, recipe);
    else this.userRecipes.set(recipe.id, recipe);
  }

  async remove(id: string): Promise<void> {
    this.userRecipes.delete(id);
    this.catalogue.delete(id);
    this.favorites.delete(id);
    await this.persist();
  }

  async setFavorite(id: string, favorite: boolean): Promise<void> {
    if (favorite) this.favorites.add(id);
    else this.favorites.delete(id);
    await this.persist();
  }

  // ── Catalogue admin ────────────────────────────────────────────────
  async isSeeded(): Promise<boolean> {
    return this.seededAt !== null && this.catalogue.size > 0;
  }

  async reseedCatalogue(): Promise<{ inserted: number; updated: number }> {
    const before = this.catalogue.size;
    this.reseedCatalogueData();
    return { inserted: this.catalogue.size, updated: before };
  }
}
