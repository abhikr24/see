import type { SQLiteDatabase } from 'expo-sqlite';
import { composeRecipe } from '../recipes/mapper';
import { SEED_RECIPES } from '../recipes/seedRecipes';
import type { RecipeRepository } from '../recipes/repository';
import type {
  DatabaseStats,
  NutritionInfo,
  Recipe,
  RecipeFilters,
  RecipeInput,
  RecipeIngredient,
  RecipeStep,
  RecipeSummary,
} from '../recipes/types';
import { deriveTotalTime, validateRecipe } from '../recipes/validation';
import {
  LATEST_SCHEMA_VERSION,
  META_SEEDED_AT,
  MIGRATIONS,
} from './schema';

// ── Row types (snake_case from SQLite) ────────────────────────────────
interface RecipeRow {
  id: string;
  title: string;
  description: string;
  cuisine: string;
  category: string;
  difficulty: string;
  servings: number;
  prep_time_min: number;
  cook_time_min: number;
  total_time_min: number;
  calories_per_serving: number | null;
  source: string;
  accent_color: string;
  rating: number | null;
  tags_text: string;
  title_localized: string | null;
  created_at: number;
  updated_at: number;
}
interface IngredientLinkRow {
  ingredient_id: string;
  quantity: number;
  unit: string;
  note: string | null;
  position: number;
}
interface StepRow {
  step_number: number;
  instruction: string;
  duration_min: number | null;
}
interface NutritionRow {
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  fiber_g: number | null;
}
interface CountRow {
  recipe_id: string;
  ingredient_count: number;
}

function placeholders(n: number): string {
  return new Array(n).fill('?').join(',');
}

/**
 * Real on-device SQLite repository (native only).
 *
 * All writes use parameterized queries (SQL-injection safe) and multi-row
 * writes run inside `withTransactionAsync` for atomicity. Migrations are
 * versioned & idempotent. The static catalogue is seeded once and can be
 * re-seeded without touching user-owned rows.
 */
export class SqliteRecipeRepository implements RecipeRepository {
  private initialized = false;

  constructor(private readonly db: SQLiteDatabase) {}

  /** Apply migrations + seed catalogue if needed. Safe to call repeatedly. */
  async init(): Promise<void> {
    if (this.initialized) return;
    await this.runMigrations();
    await this.seedIfMissing();
    this.initialized = true;
  }

  private async runMigrations(): Promise<void> {
    // Ensure the migrations table exists before querying it.
    await this.db.execAsync(
      `CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY NOT NULL, applied_at INTEGER NOT NULL);`,
    );
    const applied = await this.db.getAllAsync<{ version: number }>(
      'SELECT version FROM schema_migrations',
    );
    const appliedSet = new Set(applied.map((r) => r.version));
    for (const migration of MIGRATIONS) {
      if (appliedSet.has(migration.version)) continue;
      // Each migration is atomic: all statements + the version record commit
      // together, or roll back on any failure.
      await this.db.withTransactionAsync(async () => {
        for (const stmt of migration.statements) {
          await this.db.execAsync(stmt);
        }
        await this.db.runAsync(
          'INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)',
          [migration.version, Date.now()],
        );
      });
    }
  }

  private async seedIfMissing(): Promise<void> {
    if (await this.isSeeded()) return;
    await this.bulkUpsert(SEED_RECIPES);
    await this.setMeta(META_SEEDED_AT, String(Date.now()));
  }

  private async getMeta(key: string): Promise<string | null> {
    const row = await this.db.getFirstAsync<{ value: string }>(
      'SELECT value FROM recipe_meta WHERE key = ?',
      [key],
    );
    return row?.value ?? null;
  }

  private async setMeta(key: string, value: string): Promise<void> {
    await this.db.runAsync(
      'INSERT INTO recipe_meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
      [key, value],
    );
  }

  // ── Reads ──────────────────────────────────────────────────────────
  async list(): Promise<RecipeSummary[]> {
    const rows = await this.db.getAllAsync<RecipeRow>(
      'SELECT * FROM recipes ORDER BY updated_at DESC',
    );
    const favSet = await this.getFavoriteSet();
    const counts = await this.getIngredientCounts();
    return rows.map((r) => this.rowToSummary(r, favSet, counts.get(r.id) ?? 0));
  }

  async search(filters: RecipeFilters): Promise<RecipeSummary[]> {
    const where: string[] = [];
    const params: (string | number)[] = [];

    if (filters.query) {
      const q = `%${filters.query.toLowerCase()}%`;
      where.push('(LOWER(r.title) LIKE ? OR LOWER(r.description) LIKE ? OR LOWER(r.cuisine) LIKE ? OR LOWER(r.tags_text) LIKE ?)');
      params.push(q, q, q, q);
    }
    if (filters.category && filters.category !== 'all') {
      where.push('r.category = ?');
      params.push(filters.category);
    }
    if (filters.cuisine) {
      where.push('r.cuisine = ?');
      params.push(filters.cuisine.toLowerCase());
    }
    if (filters.difficulty && filters.difficulty !== 'all') {
      where.push('r.difficulty = ?');
      params.push(filters.difficulty);
    }
    if (filters.source && filters.source !== 'all') {
      where.push('r.source = ?');
      params.push(filters.source);
    }
    if (filters.onlyFavorites) {
      where.push('r.id IN (SELECT recipe_id FROM user_favorites)');
    }
    if (filters.ingredientIds && filters.ingredientIds.length > 0) {
      const ph = placeholders(filters.ingredientIds.length);
      where.push(
        `r.id IN (SELECT recipe_id FROM recipe_ingredients WHERE ingredient_id IN (${ph}) GROUP BY recipe_id HAVING COUNT(DISTINCT ingredient_id) = ?)`,
      );
      params.push(...filters.ingredientIds, filters.ingredientIds.length);
    }

    const order = this.orderClause(filters.sort ?? 'relevance');
    const sql = `SELECT r.* FROM recipes r${where.length ? ' WHERE ' + where.join(' AND ') : ''} ORDER BY ${order}`;
    const rows = await this.db.getAllAsync<RecipeRow>(sql, params);
    const favSet = await this.getFavoriteSet();
    const counts = await this.getIngredientCounts();
    return rows.map((r) => this.rowToSummary(r, favSet, counts.get(r.id) ?? 0));
  }

  async getById(id: string): Promise<Recipe | null> {
    const row = await this.db.getFirstAsync<RecipeRow>(
      'SELECT * FROM recipes WHERE id = ?',
      [id],
    );
    if (!row) return null;
    const [ingredients, steps, nutrition, isFav] = await Promise.all([
      this.db.getAllAsync<IngredientLinkRow>(
        'SELECT ingredient_id, quantity, unit, note, position FROM recipe_ingredients WHERE recipe_id = ? ORDER BY position',
        [id],
      ),
      this.db.getAllAsync<StepRow>(
        'SELECT step_number, instruction, duration_min FROM recipe_steps WHERE recipe_id = ? ORDER BY step_number',
        [id],
      ),
      this.db.getFirstAsync<NutritionRow>(
        'SELECT calories, protein_g, carbs_g, fat_g, fiber_g FROM recipe_nutrition WHERE recipe_id = ?',
        [id],
      ),
      this.db.getFirstAsync<{ recipe_id: string }>(
        'SELECT recipe_id FROM user_favorites WHERE recipe_id = ?',
        [id],
      ),
    ]);
    return this.rowToRecipe(row, ingredients, steps, nutrition, !!isFav);
  }

  async getFavorites(): Promise<RecipeSummary[]> {
    const rows = await this.db.getAllAsync<RecipeRow>(
      `SELECT r.* FROM recipes r JOIN user_favorites f ON f.recipe_id = r.id ORDER BY f.created_at DESC`,
    );
    const counts = await this.getIngredientCounts();
    return rows.map((r) => this.rowToSummary(r, new Set([r.id]), counts.get(r.id) ?? 0));
  }

  async getByIngredients(ingredientIds: string[]): Promise<RecipeSummary[]> {
    if (ingredientIds.length === 0) return [];
    const ph = placeholders(ingredientIds.length);
    const rows = await this.db.getAllAsync<RecipeRow & { pantry_match: number; ingredient_count: number }>(
      `SELECT r.*,
              (SELECT COUNT(*) FROM recipe_ingredients WHERE recipe_id = r.id) AS ingredient_count,
              COUNT(ri.ingredient_id) AS pantry_match
       FROM recipes r
       LEFT JOIN recipe_ingredients ri ON ri.recipe_id = r.id AND ri.ingredient_id IN (${ph})
       GROUP BY r.id
       HAVING pantry_match > 0
       ORDER BY pantry_match DESC, r.rating DESC, r.total_time_min ASC`,
      ingredientIds,
    );
    const favSet = await this.getFavoriteSet();
    return rows.map((r) =>
      this.rowToSummary(r, favSet, r.ingredient_count, r.pantry_match),
    );
  }

  async count(): Promise<number> {
    const row = await this.db.getFirstAsync<{ c: number }>('SELECT COUNT(*) AS c FROM recipes');
    return row?.c ?? 0;
  }

  async stats(): Promise<DatabaseStats> {
    const [total, catalogue, user, fav] = await Promise.all([
      this.db.getFirstAsync<{ c: number }>("SELECT COUNT(*) AS c FROM recipes"),
      this.db.getFirstAsync<{ c: number }>("SELECT COUNT(*) AS c FROM recipes WHERE source = 'catalogue'"),
      this.db.getFirstAsync<{ c: number }>("SELECT COUNT(*) AS c FROM recipes WHERE source = 'user'"),
      this.db.getFirstAsync<{ c: number }>('SELECT COUNT(*) AS c FROM user_favorites'),
    ]);
    const seededAtStr = await this.getMeta(META_SEEDED_AT);
    return {
      engine: 'sqlite',
      schemaVersion: LATEST_SCHEMA_VERSION,
      recipeCount: total?.c ?? 0,
      catalogueCount: catalogue?.c ?? 0,
      userCount: user?.c ?? 0,
      favoriteCount: fav?.c ?? 0,
      ingredientCount: 0, // filled by caller from the static catalogue
      seededAt: seededAtStr ? Number(seededAtStr) : undefined,
    };
  }

  // ── Writes ─────────────────────────────────────────────────────────
  async upsert(input: RecipeInput): Promise<string> {
    const result = validateRecipe(input);
    if (!result.valid) {
      throw new Error(`Invalid recipe: ${result.errors[0].field} — ${result.errors[0].message}`);
    }
    const recipe = composeRecipe(input);
    const existed = await this.exists(recipe.id);
    await this.writeRecipe(recipe, existed);
    return recipe.id;
  }

  async bulkUpsert(inputs: RecipeInput[]): Promise<{ inserted: number; updated: number }> {
    let inserted = 0;
    let updated = 0;
    // Validate + compose first so a bad input never corrupts the transaction.
    const recipes: Recipe[] = [];
    for (const input of inputs) {
      const result = validateRecipe(input);
      if (!result.valid) continue; // importer reports skips separately
      recipes.push(composeRecipe(input));
    }
    if (recipes.length === 0) return { inserted: 0, updated: 0 };

    await this.db.withTransactionAsync(async () => {
      for (const recipe of recipes) {
        const existed = await this.existsTx(recipe.id);
        await this.writeRecipeTx(recipe, existed);
        if (existed) updated++; else inserted++;
      }
    });
    return { inserted, updated };
  }

  async remove(id: string): Promise<void> {
    await this.db.withTransactionAsync(async () => {
      // Cascade deletes handle children; favourites reference the recipe.
      await this.db.runAsync('DELETE FROM user_favorites WHERE recipe_id = ?', [id]);
      await this.db.runAsync('DELETE FROM recipes WHERE id = ?', [id]);
    });
  }

  async setFavorite(id: string, favorite: boolean): Promise<void> {
    if (favorite) {
      await this.db.runAsync(
        'INSERT OR IGNORE INTO user_favorites (recipe_id, created_at) VALUES (?, ?)',
        [id, Date.now()],
      );
    } else {
      await this.db.runAsync('DELETE FROM user_favorites WHERE recipe_id = ?', [id]);
    }
  }

  // ── Catalogue admin ────────────────────────────────────────────────
  async isSeeded(): Promise<boolean> {
    return (await this.getMeta(META_SEEDED_AT)) !== null;
  }

  async reseedCatalogue(): Promise<{ inserted: number; updated: number }> {
    const result = await this.bulkUpsert(SEED_RECIPES);
    await this.setMeta(META_SEEDED_AT, String(Date.now()));
    return result;
  }

  // ── internals ──────────────────────────────────────────────────────
  private async exists(id: string): Promise<boolean> {
    const row = await this.db.getFirstAsync<{ id: string }>(
      'SELECT id FROM recipes WHERE id = ?',
      [id],
    );
    return !!row;
  }

  private async existsTx(id: string): Promise<boolean> {
    // Runs inside an open transaction — uses the same db connection.
    const row = await this.db.getFirstAsync<{ id: string }>(
      'SELECT id FROM recipes WHERE id = ?',
      [id],
    );
    return !!row;
  }

  private async writeRecipe(recipe: Recipe, existed: boolean): Promise<void> {
    await this.db.withTransactionAsync(async () => {
      await this.writeRecipeTx(recipe, existed);
    });
  }

  private async writeRecipeTx(recipe: Recipe, existed: boolean): Promise<void> {
    const now = recipe.updatedAt;
    if (existed) {
      // Replace the recipe row; children are wiped & re-inserted (cascade).
      await this.db.runAsync(
        `UPDATE recipes SET title=?, description=?, cuisine=?, category=?, difficulty=?, servings=?,
           prep_time_min=?, cook_time_min=?, total_time_min=?, calories_per_serving=?, source=?,
           accent_color=?, rating=?, tags_text=?, title_localized=?, updated_at=?
         WHERE id=?`,
        [
          recipe.title, recipe.description, recipe.cuisine, recipe.category, recipe.difficulty,
          recipe.servings, recipe.prepTimeMin, recipe.cookTimeMin, recipe.totalTimeMin,
          recipe.caloriesPerServing ?? null, recipe.source, recipe.accentColor,
          recipe.rating ?? null, recipe.tags.join(','), recipe.titleLocalized ? JSON.stringify(recipe.titleLocalized) : null,
          now, recipe.id,
        ],
      );
    } else {
      await this.db.runAsync(
        `INSERT INTO recipes (id, title, description, cuisine, category, difficulty, servings,
           prep_time_min, cook_time_min, total_time_min, calories_per_serving, source, accent_color,
           rating, tags_text, title_localized, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [
          recipe.id, recipe.title, recipe.description, recipe.cuisine, recipe.category,
          recipe.difficulty, recipe.servings, recipe.prepTimeMin, recipe.cookTimeMin,
          recipe.totalTimeMin, recipe.caloriesPerServing ?? null, recipe.source, recipe.accentColor,
          recipe.rating ?? null, recipe.tags.join(','),
          recipe.titleLocalized ? JSON.stringify(recipe.titleLocalized) : null, recipe.createdAt, now,
        ],
      );
    }

    // Children: delete then re-insert (keeps ordering & avoids partial state).
    await this.db.runAsync('DELETE FROM recipe_ingredients WHERE recipe_id = ?', [recipe.id]);
    await this.db.runAsync('DELETE FROM recipe_steps WHERE recipe_id = ?', [recipe.id]);
    await this.db.runAsync('DELETE FROM recipe_nutrition WHERE recipe_id = ?', [recipe.id]);

    for (let i = 0; i < recipe.ingredients.length; i++) {
      const ri = recipe.ingredients[i];
      await this.db.runAsync(
        'INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, unit, note, position) VALUES (?,?,?,?,?,?)',
        [recipe.id, ri.ingredientId, ri.quantity, ri.unit, ri.note ?? null, i],
      );
    }
    for (const step of recipe.steps) {
      await this.db.runAsync(
        'INSERT INTO recipe_steps (recipe_id, step_number, instruction, duration_min) VALUES (?,?,?,?)',
        [recipe.id, step.stepNumber, step.instruction, step.durationMin ?? null],
      );
    }
    if (recipe.nutrition) {
      await this.db.runAsync(
        'INSERT OR REPLACE INTO recipe_nutrition (recipe_id, calories, protein_g, carbs_g, fat_g, fiber_g) VALUES (?,?,?,?,?,?)',
        [
          recipe.id, recipe.nutrition.calories, recipe.nutrition.proteinG,
          recipe.nutrition.carbsG, recipe.nutrition.fatG, recipe.nutrition.fiberG ?? null,
        ],
      );
    }
  }

  private async getFavoriteSet(): Promise<Set<string>> {
    const rows = await this.db.getAllAsync<{ recipe_id: string }>(
      'SELECT recipe_id FROM user_favorites',
    );
    return new Set(rows.map((r) => r.recipe_id));
  }

  private async getIngredientCounts(): Promise<Map<string, number>> {
    const rows = await this.db.getAllAsync<CountRow>(
      'SELECT recipe_id, COUNT(*) AS ingredient_count FROM recipe_ingredients GROUP BY recipe_id',
    );
    return new Map(rows.map((r) => [r.recipe_id, r.ingredient_count]));
  }

  private orderClause(sort: NonNullable<RecipeFilters['sort']>): string {
    switch (sort) {
      case 'time': return 'r.total_time_min ASC, r.rating DESC';
      case 'rating': return 'r.rating DESC, r.total_time_min ASC';
      case 'newest': return 'r.updated_at DESC';
      case 'alpha': return 'r.title ASC';
      case 'relevance':
      default: return 'r.rating DESC, r.updated_at DESC';
    }
  }

  private rowToSummary(
    row: RecipeRow,
    favSet: Set<string>,
    ingredientCount: number,
    pantryMatch?: number,
  ): RecipeSummary {
    return {
      id: row.id,
      title: row.title,
      description: row.description,
      cuisine: row.cuisine,
      category: row.category as RecipeSummary['category'],
      difficulty: row.difficulty as RecipeSummary['difficulty'],
      servings: row.servings,
      prepTimeMin: row.prep_time_min,
      cookTimeMin: row.cook_time_min,
      totalTimeMin: row.total_time_min,
      caloriesPerServing: row.calories_per_serving ?? undefined,
      source: row.source as RecipeSummary['source'],
      accentColor: row.accent_color,
      tags: row.tags_text ? row.tags_text.split(',').filter(Boolean) : [],
      rating: row.rating ?? undefined,
      isFavorite: favSet.has(row.id),
      pantryMatch,
      ingredientCount,
    };
  }

  private rowToRecipe(
    row: RecipeRow,
    ingredients: IngredientLinkRow[],
    steps: StepRow[],
    nutrition: NutritionRow | null,
    isFavorite: boolean,
  ): Recipe {
    let titleLocalized: Recipe['titleLocalized'];
    if (row.title_localized) {
      try {
        titleLocalized = JSON.parse(row.title_localized);
      } catch {
        titleLocalized = undefined;
      }
    }
    return {
      id: row.id,
      title: row.title,
      titleLocalized,
      description: row.description,
      cuisine: row.cuisine,
      category: row.category as Recipe['category'],
      difficulty: row.difficulty as Recipe['difficulty'],
      servings: row.servings,
      prepTimeMin: row.prep_time_min,
      cookTimeMin: row.cook_time_min,
      totalTimeMin: deriveTotalTime(row.prep_time_min, row.cook_time_min),
      caloriesPerServing: row.calories_per_serving ?? undefined,
      source: row.source as Recipe['source'],
      accentColor: row.accent_color,
      tags: row.tags_text ? row.tags_text.split(',').filter(Boolean) : [],
      rating: row.rating ?? undefined,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      isFavorite,
      ingredients: ingredients.map<RecipeIngredient>((ri) => ({
        ingredientId: ri.ingredient_id,
        quantity: ri.quantity,
        unit: ri.unit as RecipeIngredient['unit'],
        note: ri.note ?? undefined,
      })),
      steps: steps.map<RecipeStep>((s) => ({
        stepNumber: s.step_number,
        instruction: s.instruction,
        durationMin: s.duration_min ?? undefined,
      })),
      nutrition: nutrition
        ? {
            calories: nutrition.calories,
            proteinG: nutrition.protein_g,
            carbsG: nutrition.carbs_g,
            fatG: nutrition.fat_g,
            fiberG: nutrition.fiber_g ?? undefined,
          }
        : undefined,
    };
  }
}
