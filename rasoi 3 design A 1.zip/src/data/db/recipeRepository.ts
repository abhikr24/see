import { Platform } from 'react-native';
import { closeDatabase, openDatabase } from './connection';
import { MemoryRecipeRepository } from './recipeRepository.memory';
import type { MemoryPersister } from './recipeRepository.memory';
import { SqliteRecipeRepository } from './recipeRepository.sqlite';
import type { RecipeRepository } from '../recipes/repository';
import { loadJSON, saveJSON } from '../../lib/storage';

/**
 * Repository factory (Stage 3).
 *
 * Resolution order:
 *  1. Open real on-device SQLite via expo-sqlite (native). If it opens, use the
 *     `SqliteRecipeRepository` (proper SQLite recipe architecture).
 *  2. If SQLite cannot be opened (e.g. web without SharedArrayBuffer), fall back
 *     to `MemoryRecipeRepository`, persisting user data to AsyncStorage on web.
 *
 * The rest of the app only ever sees the `RecipeRepository` interface, so the
 * engine is transparent to UI code and fully offline-capable either way.
 */
let cached: RecipeRepository | null = null;
let resolvedEngine: 'sqlite' | 'memory' | null = null;

export async function getRecipeRepository(): Promise<RecipeRepository> {
  if (cached) return cached;

  try {
    const db = await openDatabase();
    const repo = new SqliteRecipeRepository(db);
    await repo.init();
    cached = repo;
    resolvedEngine = 'sqlite';
    return repo;
  } catch {
    // SQLite unavailable — degrade gracefully to the in-memory implementation.
    const persistKey = Platform.OS === 'web' ? 'memoryRepo' : undefined;
    const persister: MemoryPersister | undefined = persistKey
      ? {
          load: async () => loadJSON(persistKey, { user: [], favorites: [], seededAt: null }),
          save: async (state) => saveJSON(persistKey, state),
        }
      : undefined;
    const repo = new MemoryRecipeRepository(persister);
    await repo.init();
    cached = repo;
    resolvedEngine = 'memory';
    return repo;
  }
}

/** Synchronously report which engine was resolved (null until first init). */
export function getResolvedEngine(): 'sqlite' | 'memory' | null {
  return resolvedEngine;
}

/** Reset the cache — used by the Data screen's reseed/admin flows & tests. */
export function resetRepositoryCache(): void {
  cached = null;
  resolvedEngine = null;
}

export async function closeRepository(): Promise<void> {
  await closeDatabase();
  resetRepositoryCache();
}

export type { RecipeRepository };
