/**
 * SQLite SCHEMA (Stage 3).
 *
 * Versioned migrations live in `MIGRATIONS`. Each migration is applied inside a
 * transaction and recorded in `schema_migrations` so re-runs are idempotent.
 *
 * Ownership separation is enforced at the table level:
 *  - `recipes.source = 'catalogue'`  → app-owned static catalogue (seeded)
 *  - `recipes.source = 'user'`       → user-owned, fully mutable
 *  - `user_favorites`                → always user-owned (never mutates catalogue)
 * Recipe-ingredient links reference the canonical ingredient catalogue by id;
 * the catalogue itself is NOT a table (single source of truth = code module).
 */

export interface Migration {
  version: number;
  description: string;
  statements: string[];
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    description: 'Initial recipe catalogue schema',
    statements: [
      `CREATE TABLE IF NOT EXISTS schema_migrations (
         version INTEGER PRIMARY KEY NOT NULL,
         applied_at INTEGER NOT NULL
       );`,
      `CREATE TABLE IF NOT EXISTS recipe_meta (
         key TEXT PRIMARY KEY NOT NULL,
         value TEXT NOT NULL
       );`,
      `CREATE TABLE IF NOT EXISTS recipes (
         id TEXT PRIMARY KEY NOT NULL,
         title TEXT NOT NULL,
         description TEXT NOT NULL,
         cuisine TEXT NOT NULL,
         category TEXT NOT NULL,
         difficulty TEXT NOT NULL,
         servings INTEGER NOT NULL,
         prep_time_min INTEGER NOT NULL,
         cook_time_min INTEGER NOT NULL,
         total_time_min INTEGER NOT NULL,
         calories_per_serving INTEGER,
         source TEXT NOT NULL DEFAULT 'user',
         accent_color TEXT NOT NULL,
         rating REAL,
         tags_text TEXT NOT NULL DEFAULT '',
         title_localized TEXT,
         created_at INTEGER NOT NULL,
         updated_at INTEGER NOT NULL
       );`,
      `CREATE TABLE IF NOT EXISTS recipe_ingredients (
         id INTEGER PRIMARY KEY AUTOINCREMENT,
         recipe_id TEXT NOT NULL,
         ingredient_id TEXT NOT NULL,
         quantity REAL NOT NULL,
         unit TEXT NOT NULL,
         note TEXT,
         position INTEGER NOT NULL DEFAULT 0,
         FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
       );`,
      `CREATE TABLE IF NOT EXISTS recipe_steps (
         id INTEGER PRIMARY KEY AUTOINCREMENT,
         recipe_id TEXT NOT NULL,
         step_number INTEGER NOT NULL,
         instruction TEXT NOT NULL,
         duration_min INTEGER,
         FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
       );`,
      `CREATE TABLE IF NOT EXISTS recipe_nutrition (
         recipe_id TEXT PRIMARY KEY,
         calories INTEGER NOT NULL,
         protein_g REAL NOT NULL,
         carbs_g REAL NOT NULL,
         fat_g REAL NOT NULL,
         fiber_g REAL,
         FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
       );`,
      `CREATE TABLE IF NOT EXISTS user_favorites (
         recipe_id TEXT PRIMARY KEY,
         created_at INTEGER NOT NULL,
         FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
       );`,
      `CREATE INDEX IF NOT EXISTS idx_recipes_source ON recipes(source);`,
      `CREATE INDEX IF NOT EXISTS idx_recipes_category ON recipes(category);`,
      `CREATE INDEX IF NOT EXISTS idx_recipes_cuisine ON recipes(cuisine);`,
      `CREATE INDEX IF NOT EXISTS idx_recipes_updated ON recipes(updated_at);`,
      `CREATE INDEX IF NOT EXISTS idx_ri_recipe ON recipe_ingredients(recipe_id);`,
      `CREATE INDEX IF NOT EXISTS idx_ri_ingredient ON recipe_ingredients(ingredient_id);`,
      `CREATE INDEX IF NOT EXISTS idx_rs_recipe ON recipe_steps(recipe_id);`,
    ],
  },
];

export const LATEST_SCHEMA_VERSION: number =
  MIGRATIONS[MIGRATIONS.length - 1].version;

export const META_SEEDED_AT = 'catalogue_seeded_at';
export const META_SCHEMA_VERSION = 'schema_version';
