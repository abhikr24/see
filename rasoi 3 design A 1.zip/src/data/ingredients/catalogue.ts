import type { Ingredient, IngredientCategory } from './types';

/**
 * CANONICAL INGREDIENT CATALOGUE (Stage 2).
 *
 * This is the single source of truth for ingredient identity in Rasoi. Ids are
 * stable forever — recipes in the SQLite catalogue reference these ids, so
 * renaming an id would orphan every recipe that uses it. To deprecate, mark
 * `deprecated` (future) rather than reusing an id.
 *
 * The catalogue is static and app-owned. It is NOT user-editable and does not
 * live in the database — this preserves a clean separation between the local
 * static catalogue (code) and user-owned local data (SQLite / AsyncStorage).
 */
export const INGREDIENT_CATALOGUE: Ingredient[] = [
  // ── Vegetables ───────────────────────────────────────────────
  { id: 'ing_tomato', name: { en: 'Tomato', hi: 'टमाटर' }, category: 'vegetable', emoji: '🍅', defaultUnit: 'piece', aliases: ['tamatar'], shelfLifeDays: 7 },
  { id: 'ing_onion', name: { en: 'Onion', hi: 'प्याज़' }, category: 'vegetable', emoji: '🧅', defaultUnit: 'piece', aliases: ['pyaz'], shelfLifeDays: 30 },
  { id: 'ing_garlic', name: { en: 'Garlic', hi: 'लहसुन' }, category: 'vegetable', emoji: '🧄', defaultUnit: 'clove', aliases: ['lehsun'], shelfLifeDays: 30 },
  { id: 'ing_ginger', name: { en: 'Ginger', hi: 'अदरक' }, category: 'vegetable', emoji: '🫚', defaultUnit: 'piece', aliases: ['adrak'], shelfLifeDays: 21 },
  { id: 'ing_potato', name: { en: 'Potato', hi: 'आलू' }, category: 'vegetable', emoji: '🥔', defaultUnit: 'piece', aliases: ['aloo'], shelfLifeDays: 30 },
  { id: 'ing_green_chili', name: { en: 'Green Chili', hi: 'हरी मिर्च' }, category: 'vegetable', emoji: '🌶️', defaultUnit: 'piece', aliases: ['mirch', 'chilli'], shelfLifeDays: 14 },
  { id: 'ing_bell_pepper', name: { en: 'Bell Pepper', hi: 'शिमला मिर्च' }, category: 'vegetable', emoji: '🫑', defaultUnit: 'piece', aliases: ['capsicum', 'shimla'], shelfLifeDays: 10 },
  { id: 'ing_carrot', name: { en: 'Carrot', hi: 'गाजर' }, category: 'vegetable', emoji: '🥕', defaultUnit: 'piece', aliases: ['gajar'], shelfLifeDays: 21 },
  { id: 'ing_cucumber', name: { en: 'Cucumber', hi: 'खीरा' }, category: 'vegetable', emoji: '🥒', defaultUnit: 'piece', aliases: ['kheera'], shelfLifeDays: 10 },
  { id: 'ing_spinach', name: { en: 'Spinach', hi: 'पालक' }, category: 'vegetable', emoji: '🥬', defaultUnit: 'cup', aliases: ['palak'], shelfLifeDays: 5 },
  { id: 'ing_cauliflower', name: { en: 'Cauliflower', hi: 'फूलगोभी' }, category: 'vegetable', emoji: '🥦', defaultUnit: 'piece', aliases: ['gobi', 'phool'], shelfLifeDays: 7 },
  { id: 'ing_cabbage', name: { en: 'Cabbage', hi: 'पत्तागोभी' }, category: 'vegetable', emoji: '🥬', defaultUnit: 'cup', aliases: ['patta'], shelfLifeDays: 14 },
  { id: 'ing_okra', name: { en: 'Okra', hi: 'भिंडी' }, category: 'vegetable', emoji: '🫛', defaultUnit: 'piece', aliases: ['bhindi', 'ladyfinger'], shelfLifeDays: 5 },
  { id: 'ing_eggplant', name: { en: 'Eggplant', hi: 'बैंगन' }, category: 'vegetable', emoji: '🍆', defaultUnit: 'piece', aliases: ['baingan', 'aubergine', 'brinjal'], shelfLifeDays: 7 },
  { id: 'ing_mushroom', name: { en: 'Mushroom', hi: 'मशरूम' }, category: 'vegetable', emoji: '🍄', defaultUnit: 'cup', aliases: ['khumbi'], shelfLifeDays: 5 },
  { id: 'ing_corn', name: { en: 'Corn', hi: 'मकई' }, category: 'vegetable', emoji: '🌽', defaultUnit: 'cup', aliases: ['makai', 'sweetcorn'], shelfLifeDays: 5 },
  { id: 'ing_peas', name: { en: 'Green Peas', hi: 'मटर' }, category: 'vegetable', emoji: '🫛', defaultUnit: 'cup', aliases: ['matar'], shelfLifeDays: 7 },
  { id: 'ing_pumpkin', name: { en: 'Pumpkin', hi: 'कद्दू' }, category: 'vegetable', emoji: '🎃', defaultUnit: 'g', aliases: ['kaddu'], shelfLifeDays: 30 },
  { id: 'ing_zucchini', name: { en: 'Zucchini', hi: 'तोरई' }, category: 'vegetable', emoji: '🥒', defaultUnit: 'piece', aliases: ['courgette'], shelfLifeDays: 7 },
  { id: 'ing_lettuce', name: { en: 'Lettuce', hi: 'सलाद पत्ता' }, category: 'vegetable', emoji: '🥬', defaultUnit: 'cup', aliases: ['salad'], shelfLifeDays: 5 },

  // ── Fruits ───────────────────────────────────────────────────
  { id: 'ing_lemon', name: { en: 'Lemon', hi: 'नींबू' }, category: 'fruit', emoji: '🍋', defaultUnit: 'piece', aliases: ['nimbu'], shelfLifeDays: 14 },
  { id: 'ing_lime', name: { en: 'Lime', hi: 'हरा नींबू' }, category: 'fruit', emoji: 'lime', defaultUnit: 'piece', aliases: ['kagzi'], shelfLifeDays: 14 },
  { id: 'ing_mango', name: { en: 'Mango', hi: 'आम' }, category: 'fruit', emoji: '🥭', defaultUnit: 'piece', aliases: ['aam'], shelfLifeDays: 7 },
  { id: 'ing_banana', name: { en: 'Banana', hi: 'केला' }, category: 'fruit', emoji: '🍌', defaultUnit: 'piece', aliases: ['kela'], shelfLifeDays: 5 },
  { id: 'ing_apple', name: { en: 'Apple', hi: 'सेब' }, category: 'fruit', emoji: '🍎', defaultUnit: 'piece', aliases: ['seb'], shelfLifeDays: 21 },
  { id: 'ing_coconut', name: { en: 'Coconut', hi: 'नारियल' }, category: 'fruit', emoji: '🥥', defaultUnit: 'cup', aliases: ['nariyal'], shelfLifeDays: 30 },
  { id: 'ing_avocado', name: { en: 'Avocado', hi: 'एवोकाडो' }, category: 'fruit', emoji: '🥑', defaultUnit: 'piece', aliases: ['makhanphal'], shelfLifeDays: 5 },

  // ── Spices ───────────────────────────────────────────────────
  { id: 'ing_turmeric', name: { en: 'Turmeric', hi: 'हल्दी' }, category: 'spice', emoji: '🟡', defaultUnit: 'tsp', aliases: ['haldi'], shelfLifeDays: 365 },
  { id: 'ing_cumin', name: { en: 'Cumin', hi: 'जीरा' }, category: 'spice', emoji: '🟤', defaultUnit: 'tsp', aliases: ['jeera'], shelfLifeDays: 365 },
  { id: 'ing_coriander_powder', name: { en: 'Coriander Powder', hi: 'धनिया पाउडर' }, category: 'spice', emoji: '🟫', defaultUnit: 'tsp', aliases: ['dhania'], shelfLifeDays: 365 },
  { id: 'ing_garam_masala', name: { en: 'Garam Masala', hi: 'गरम मसाला' }, category: 'spice', emoji: '🟫', defaultUnit: 'tsp', aliases: [], shelfLifeDays: 365 },
  { id: 'ing_red_chili_powder', name: { en: 'Red Chili Powder', hi: 'लाल मिर्च' }, category: 'spice', emoji: '🔴', defaultUnit: 'tsp', aliases: ['lal mirch'], shelfLifeDays: 365 },
  { id: 'ing_black_pepper', name: { en: 'Black Pepper', hi: 'काली मिर्च' }, category: 'spice', emoji: '⚫', defaultUnit: 'tsp', aliases: ['kali mirch'], shelfLifeDays: 365 },
  { id: 'ing_mustard_seeds', name: { en: 'Mustard Seeds', hi: 'सरसों' }, category: 'spice', emoji: '🟤', defaultUnit: 'tsp', aliases: ['sarson'], shelfLifeDays: 365 },
  { id: 'ing_cinnamon', name: { en: 'Cinnamon', hi: 'दालचीनी' }, category: 'spice', emoji: '🟫', defaultUnit: 'stick', aliases: ['dalchini'], shelfLifeDays: 365 },
  { id: 'ing_cardamom', name: { en: 'Cardamom', hi: 'इलायची' }, category: 'spice', emoji: '🟢', defaultUnit: 'piece', aliases: ['elaichi'], shelfLifeDays: 365 },
  { id: 'ing_cloves', name: { en: 'Cloves', hi: 'लौंग' }, category: 'spice', emoji: '🟤', defaultUnit: 'piece', aliases: ['laung'], shelfLifeDays: 365 },
  { id: 'ing_bay_leaf', name: { en: 'Bay Leaf', hi: 'तेज पत्ता' }, category: 'spice', emoji: '🍃', defaultUnit: 'piece', aliases: ['tej patta'], shelfLifeDays: 365 },
  { id: 'ing_saffron', name: { en: 'Saffron', hi: 'केसर' }, category: 'spice', emoji: '🔶', defaultUnit: 'pinch', aliases: ['kesar'], shelfLifeDays: 365 },
  { id: 'ing_paprika', name: { en: 'Paprika', hi: 'पैप्रिका' }, category: 'spice', emoji: '🔴', defaultUnit: 'tsp', aliases: [], shelfLifeDays: 365 },
  { id: 'ing_oregano', name: { en: 'Oregano', hi: 'ओरेगानो' }, category: 'spice', emoji: '🌿', defaultUnit: 'tsp', aliases: [], shelfLifeDays: 365 },

  // ── Grains ───────────────────────────────────────────────────
  { id: 'ing_rice', name: { en: 'Rice', hi: 'चावल' }, category: 'grain', emoji: '🍚', defaultUnit: 'cup', aliases: ['chawal', 'basmati'], shelfLifeDays: 365 },
  { id: 'ing_basmati_rice', name: { en: 'Basmati Rice', hi: 'बासमती चावल' }, category: 'grain', emoji: '🍚', defaultUnit: 'cup', aliases: ['basmati'], shelfLifeDays: 365 },
  { id: 'ing_wheat_flour', name: { en: 'Wheat Flour', hi: 'गेहूं आटा' }, category: 'grain', emoji: '🌾', defaultUnit: 'cup', aliases: ['atta', 'aata'], shelfLifeDays: 120 },
  { id: 'ing_all_purpose_flour', name: { en: 'All-Purpose Flour', hi: 'मैदा' }, category: 'grain', emoji: '🌾', defaultUnit: 'cup', aliases: ['maida', 'flour'], shelfLifeDays: 120 },
  { id: 'ing_bread', name: { en: 'Bread', hi: 'ब्रेड' }, category: 'grain', emoji: '🍞', defaultUnit: 'slice', aliases: [], shelfLifeDays: 5 },
  { id: 'ing_pasta', name: { en: 'Pasta', hi: 'पास्ता' }, category: 'grain', emoji: '🍝', defaultUnit: 'cup', aliases: ['macaroni', 'penne'], shelfLifeDays: 365 },
  { id: 'ing_oats', name: { en: 'Oats', hi: 'ओट्स' }, category: 'grain', emoji: '🥣', defaultUnit: 'cup', aliases: ['oatmeal'], shelfLifeDays: 180 },
  { id: 'ing_cornmeal', name: { en: 'Cornmeal', hi: 'मकई आटा' }, category: 'grain', emoji: '🌽', defaultUnit: 'cup', aliases: ['makai atta'], shelfLifeDays: 180 },

  // ── Legumes ──────────────────────────────────────────────────
  { id: 'ing_red_lentils', name: { en: 'Red Lentils', hi: 'मसूर दाल' }, category: 'legume', emoji: '🫘', defaultUnit: 'cup', aliases: ['masoor', 'dal'], shelfLifeDays: 365 },
  { id: 'ing_chickpeas', name: { en: 'Chickpeas', hi: 'चने' }, category: 'legume', emoji: '🟤', defaultUnit: 'cup', aliases: ['chana', 'garbanzo'], shelfLifeDays: 365 },
  { id: 'ing_black_gram', name: { en: 'Black Gram', hi: 'उड़द दाल' }, category: 'legume', emoji: '⚫', defaultUnit: 'cup', aliases: ['urad', 'urad dal'], shelfLifeDays: 365 },
  { id: 'ing_kidney_beans', name: { en: 'Kidney Beans', hi: 'राजमा' }, category: 'legume', emoji: '🫘', defaultUnit: 'cup', aliases: ['rajma'], shelfLifeDays: 365 },
  { id: 'ing_mung_beans', name: { en: 'Mung Beans', hi: 'मूंग दाल' }, category: 'legume', emoji: '🟢', defaultUnit: 'cup', aliases: ['moong', 'mung'], shelfLifeDays: 365 },

  // ── Dairy ────────────────────────────────────────────────────
  { id: 'ing_milk', name: { en: 'Milk', hi: 'दूध' }, category: 'dairy', emoji: '🥛', defaultUnit: 'cup', aliases: ['doodh'], shelfLifeDays: 5 },
  { id: 'ing_yogurt', name: { en: 'Yogurt', hi: 'दही' }, category: 'dairy', emoji: '🥛', defaultUnit: 'cup', aliases: ['dahi', 'curd'], shelfLifeDays: 7 },
  { id: 'ing_butter', name: { en: 'Butter', hi: 'मक्खन' }, category: 'dairy', emoji: '🧈', defaultUnit: 'tbsp', aliases: ['makhan'], shelfLifeDays: 30 },
  { id: 'ing_ghee', name: { en: 'Ghee', hi: 'घी' }, category: 'dairy', emoji: '🫙', defaultUnit: 'tbsp', aliases: [], shelfLifeDays: 180 },
  { id: 'ing_cheese', name: { en: 'Cheese', hi: 'पनीर' }, category: 'dairy', emoji: '🧀', defaultUnit: 'g', aliases: ['paneer', 'cheddar'], shelfLifeDays: 14 },
  { id: 'ing_paneer', name: { en: 'Paneer', hi: 'पनीर' }, category: 'dairy', emoji: '🧀', defaultUnit: 'g', aliases: ['cottage cheese'], shelfLifeDays: 5 },
  { id: 'ing_cream', name: { en: 'Cream', hi: 'क्रीम' }, category: 'dairy', emoji: '🥛', defaultUnit: 'cup', aliases: ['malai', 'heavy cream'], shelfLifeDays: 7 },

  // ── Protein (non-dairy) ─────────────────────────────────────
  { id: 'ing_chicken', name: { en: 'Chicken', hi: 'चिकन' }, category: 'protein', emoji: '🍗', defaultUnit: 'g', aliases: ['murga'], shelfLifeDays: 2 },
  { id: 'ing_egg', name: { en: 'Egg', hi: 'अंडा' }, category: 'protein', emoji: '🥚', defaultUnit: 'piece', aliases: ['anda'], shelfLifeDays: 21 },
  { id: 'ing_fish', name: { en: 'Fish', hi: 'मछली' }, category: 'protein', emoji: '🐟', defaultUnit: 'g', aliases: ['machli'], shelfLifeDays: 2 },
  { id: 'ing_beef', name: { en: 'Beef', hi: 'बीफ' }, category: 'protein', emoji: '🥩', defaultUnit: 'g', aliases: [], shelfLifeDays: 2 },
  { id: 'ing_pork', name: { en: 'Pork', hi: 'पोर्क' }, category: 'protein', emoji: '🥓', defaultUnit: 'g', aliases: [], shelfLifeDays: 2 },
  { id: 'ing_tofu', name: { en: 'Tofu', hi: 'टोफू' }, category: 'protein', emoji: '🧈', defaultUnit: 'g', aliases: ['soy'], shelfLifeDays: 7 },
  { id: 'ing_mince', name: { en: 'Mince', hi: 'कीमा' }, category: 'protein', emoji: '🥩', defaultUnit: 'g', aliases: ['ground meat', 'keema'], shelfLifeDays: 2 },

  // ── Herbs ────────────────────────────────────────────────────
  { id: 'ing_cilantro', name: { en: 'Cilantro', hi: 'हरा धनिया' }, category: 'herb', emoji: '🌿', defaultUnit: 'handful', aliases: ['coriander leaves', 'hara dhania'], shelfLifeDays: 5 },
  { id: 'ing_mint', name: { en: 'Mint', hi: 'पुदीना' }, category: 'herb', emoji: '🌿', defaultUnit: 'handful', aliases: ['pudina'], shelfLifeDays: 5 },
  { id: 'ing_basil', name: { en: 'Basil', hi: 'तुलसी' }, category: 'herb', emoji: '🌿', defaultUnit: 'handful', aliases: ['tulsi'], shelfLifeDays: 5 },
  { id: 'ing_curry_leaves', name: { en: 'Curry Leaves', hi: 'करी पत्ता' }, category: 'herb', emoji: '🍃', defaultUnit: 'handful', aliases: ['kadi patta'], shelfLifeDays: 7 },

  // ── Oils ─────────────────────────────────────────────────────
  { id: 'ing_vegetable_oil', name: { en: 'Vegetable Oil', hi: 'सब्ज़ी तेल' }, category: 'oil', emoji: '🫗', defaultUnit: 'tbsp', aliases: ['cooking oil'], shelfLifeDays: 365 },
  { id: 'ing_olive_oil', name: { en: 'Olive Oil', hi: 'जैतून का तेल' }, category: 'oil', emoji: '🫗', defaultUnit: 'tbsp', aliases: ['jaitun'], shelfLifeDays: 365 },
  { id: 'ing_sesame_oil', name: { en: 'Sesame Oil', hi: 'तिल का तेल' }, category: 'oil', emoji: '🫗', defaultUnit: 'tbsp', aliases: ['til'], shelfLifeDays: 365 },
  { id: 'ing_coconut_oil', name: { en: 'Coconut Oil', hi: 'नारियल तेल' }, category: 'oil', emoji: '🫗', defaultUnit: 'tbsp', aliases: [], shelfLifeDays: 365 },

  // ── Nuts & Seeds ─────────────────────────────────────────────
  { id: 'ing_cashew', name: { en: 'Cashew', hi: 'काजू' }, category: 'nut', emoji: '🥜', defaultUnit: 'g', aliases: ['kaju'], shelfLifeDays: 120 },
  { id: 'ing_almond', name: { en: 'Almond', hi: 'बादाम' }, category: 'nut', emoji: '🌰', defaultUnit: 'g', aliases: ['badam'], shelfLifeDays: 180 },
  { id: 'ing_peanut', name: { en: 'Peanut', hi: 'मूंगफली' }, category: 'nut', emoji: '🥜', defaultUnit: 'g', aliases: ['mungphali'], shelfLifeDays: 180 },
  { id: 'ing_sesame_seeds', name: { en: 'Sesame Seeds', hi: 'तिल' }, category: 'nut', emoji: '⚪', defaultUnit: 'tbsp', aliases: ['til'], shelfLifeDays: 180 },

  // ── Condiments ───────────────────────────────────────────────
  { id: 'ing_salt', name: { en: 'Salt', hi: 'नमक' }, category: 'condiment', emoji: '🧂', defaultUnit: 'tsp', aliases: ['namak'], shelfLifeDays: 3650 },
  { id: 'ing_sugar', name: { en: 'Sugar', hi: 'चीनी' }, category: 'condiment', emoji: '🍯', defaultUnit: 'tsp', aliases: ['cheeni'], shelfLifeDays: 3650 },
  { id: 'ing_honey', name: { en: 'Honey', hi: 'शहद' }, category: 'condiment', emoji: '🍯', defaultUnit: 'tbsp', aliases: ['shahad'], shelfLifeDays: 3650 },
  { id: 'ing_soy_sauce', name: { en: 'Soy Sauce', hi: 'सोया सॉस' }, category: 'condiment', emoji: '🥫', defaultUnit: 'tbsp', aliases: [], shelfLifeDays: 365 },
  { id: 'ing_vinegar', name: { en: 'Vinegar', hi: 'सिरका' }, category: 'condiment', emoji: '🫗', defaultUnit: 'tbsp', aliases: ['sirka'], shelfLifeDays: 365 },
  { id: 'ing_tomato_paste', name: { en: 'Tomato Paste', hi: 'टमाटर पेस्ट' }, category: 'condiment', emoji: '🥫', defaultUnit: 'tbsp', aliases: [], shelfLifeDays: 120 },
  { id: 'ing_yeast', name: { en: 'Yeast', hi: 'खमीर' }, category: 'condiment', emoji: '🟫', defaultUnit: 'tsp', aliases: ['khameer'], shelfLifeDays: 180 },
  { id: 'ing_baking_powder', name: { en: 'Baking Powder', hi: 'बेकिंग पाउडर' }, category: 'condiment', emoji: '🟫', defaultUnit: 'tsp', aliases: [], shelfLifeDays: 365 },
  { id: 'ing_vanilla', name: { en: 'Vanilla', hi: 'वनीला' }, category: 'condiment', emoji: '🟤', defaultUnit: 'tsp', aliases: [], shelfLifeDays: 365 },

  // ── Beverages ────────────────────────────────────────────────
  { id: 'ing_water', name: { en: 'Water', hi: 'पानी' }, category: 'beverage', emoji: '💧', defaultUnit: 'cup', aliases: ['paani'], shelfLifeDays: 3650 },
  { id: 'ing_tea_leaves', name: { en: 'Tea Leaves', hi: 'चाय पत्ती' }, category: 'beverage', emoji: '🍵', defaultUnit: 'tsp', aliases: ['chai'], shelfLifeDays: 365 },
  { id: 'ing_coffee', name: { en: 'Coffee', hi: 'कॉफ़ी' }, category: 'beverage', emoji: '☕', defaultUnit: 'tsp', aliases: [], shelfLifeDays: 365 },
];

/** Fast id → ingredient lookup map. Built once at module load. */
export const INGREDIENT_BY_ID: ReadonlyMap<string, Ingredient> = new Map(
  INGREDIENT_CATALOGUE.map((i) => [i.id, i]),
);

export function getIngredient(id: string): Ingredient | undefined {
  return INGREDIENT_BY_ID.get(id);
}

export function ingredientsByCategory(cat: IngredientCategory): Ingredient[] {
  return INGREDIENT_CATALOGUE.filter((i) => i.category === cat);
}
