import type { Ingredient, IngredientCategory } from './types';
import { INGREDIENT_CATALOGUE, getIngredient } from './catalogue';

export * from './types';
export { INGREDIENT_CATALOGUE, INGREDIENT_BY_ID, getIngredient, ingredientsByCategory } from './catalogue';

/** Normalize a search term (lowercase, trim). */
function norm(s: string): string {
  return s.trim().toLowerCase();
}

/** Score how well an ingredient matches a query (0 = no match). */
function matchScore(ing: Ingredient, q: string): number {
  if (!q) return 1;
  const term = norm(q);
  const nameEn = norm(ing.name.en);
  const nameHi = norm(ing.name.hi);
  if (nameEn === term || nameHi === term) return 100;
  if (nameEn.startsWith(term) || nameHi.startsWith(term)) return 80;
  if (ing.aliases.some((a) => norm(a) === term)) return 90;
  if (ing.aliases.some((a) => norm(a).startsWith(term))) return 70;
  if (nameEn.includes(term) || nameHi.includes(term)) return 50;
  if (ing.aliases.some((a) => norm(a).includes(term))) return 40;
  if (ing.id.includes(term)) return 20;
  return 0;
}

export interface IngredientSearchResult {
  ingredient: Ingredient;
  score: number;
}

export function searchIngredients(
  query: string,
  opts?: { category?: IngredientCategory | 'all'; limit?: number },
): IngredientSearchResult[] {
  const q = norm(query);
  const cat = opts?.category ?? 'all';
  const base = cat === 'all' ? INGREDIENT_CATALOGUE : INGREDIENT_CATALOGUE.filter((i) => i.category === cat);
  const scored = base
    .map((ingredient) => ({ ingredient, score: matchScore(ingredient, q) }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score || a.ingredient.name.en.localeCompare(b.ingredient.name.en));
  return opts?.limit ? scored.slice(0, opts.limit) : scored;
}

export function ingredientExists(id: string): boolean {
  return getIngredient(id) !== undefined;
}
