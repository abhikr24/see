import type { Localized } from '../../i18n';

// Canonical ingredient categories. Stable string union — referenced by
// catalogue entries and by recipe ingredient links.
export type IngredientCategory =
  | 'vegetable'
  | 'fruit'
  | 'spice'
  | 'grain'
  | 'legume'
  | 'dairy'
  | 'protein'
  | 'herb'
  | 'oil'
  | 'nut'
  | 'condiment'
  | 'beverage';

// Units recognised across the recipe model & UI. Stored verbatim on links.
export type Unit = 'g' | 'kg' | 'ml' | 'l' | 'tsp' | 'tbsp' | 'cup' | 'piece' | 'clove' | 'pinch' | 'to_taste' | 'slice' | 'handful' | 'stick' | 'can';

export interface Ingredient {
  /** Canonical, stable, never-changing id, e.g. `ing_tomato`. */
  id: string;
  name: Localized;
  category: IngredientCategory;
  /** Emoji glyph used by the visual picker (asset-free, renders everywhere). */
  emoji: string;
  /** Default unit suggested when adding to a recipe. */
  defaultUnit: Unit;
  /** English search aliases (lowercase). */
  aliases: string[];
  /** Approximate pantry shelf life in days, for future pantry intelligence. */
  shelfLifeDays?: number;
}

export const CATEGORY_ORDER: IngredientCategory[] = [
  'vegetable',
  'fruit',
  'spice',
  'grain',
  'legume',
  'dairy',
  'protein',
  'herb',
  'oil',
  'nut',
  'condiment',
  'beverage',
];

export const CATEGORY_META: Record<IngredientCategory, Localized & { emoji: string }> = {
  vegetable: { en: 'Vegetables', hi: 'सब्ज़ियाँ', emoji: '🥬' },
  fruit: { en: 'Fruits', hi: 'फल', emoji: '🍎' },
  spice: { en: 'Spices', hi: 'मसाले', emoji: '🌶️' },
  grain: { en: 'Grains', hi: 'अनाज', emoji: '🌾' },
  legume: { en: 'Legumes', hi: 'दालें', emoji: '🫘' },
  dairy: { en: 'Dairy', hi: 'डेयरी', emoji: '🥛' },
  protein: { en: 'Protein', hi: 'प्रोटीन', emoji: '🍗' },
  herb: { en: 'Herbs', hi: 'जड़ी-बूटियाँ', emoji: '🌿' },
  oil: { en: 'Oils', hi: 'तेल', emoji: '🫗' },
  nut: { en: 'Nuts & Seeds', hi: 'नट्स व बीज', emoji: '🥜' },
  condiment: { en: 'Condiments', hi: 'सॉस व मसाले', emoji: '🧂' },
  beverage: { en: 'Beverages', hi: 'पेय', emoji: '🍵' },
};
