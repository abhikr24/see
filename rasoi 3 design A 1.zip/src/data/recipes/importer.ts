import { composeRecipe } from './mapper';
import type { RecipeRepository } from './repository';
import type { ImportResult, RecipeInput } from './types';
import { validateRecipe } from './validation';

/**
 * DATA INGESTION (Stage 3).
 *
 * `importRecipes` is the public importer: it ingests an arbitrary batch of
 * `RecipeInput` through validation, composes the valid ones, and upserts them
 * via the repository. It is used both for first-run catalogue seeding and for
 * any future JSON/external import path — the ingestion contract is identical.
 *
 * Safety guarantees:
 *  - Invalid candidates are skipped, never crash the batch.
 *  - Each candidate is validated against the canonical ingredient catalogue.
 *  - Total time is always derived, never trusted from input.
 */
export async function importRecipes(
  repo: RecipeRepository,
  inputs: RecipeInput[],
  _opts?: { stopOnError?: boolean },
): Promise<ImportResult> {
  const errors: string[] = [];
  const valid: RecipeInput[] = [];
  let skipped = 0;

  for (let i = 0; i < inputs.length; i++) {
    const input = inputs[i];
    const result = validateRecipe(input);
    if (!result.valid) {
      skipped += 1;
      const idPart = input.id ?? `#${i}`;
      const firstErr = result.errors[0];
      errors.push(`[${idPart}] ${firstErr.field}: ${firstErr.message}`);
      continue;
    }
    valid.push(input);
  }

  const { inserted, updated } = await repo.bulkUpsert(valid);

  return { inserted, updated, skipped, errors };
}
