import { INGREDIENT_CATALOGUE, getIngredient } from '../ingredients';
import type {
  Recipe,
  RecipeInput,
  RecipeStep,
  RecipeSummary,
} from './types';
import { deriveTotalTime } from './validation';

// Accent palette used for recipe header gradients. Deterministic by id hash so
// the same recipe always renders the same color (no image assets required).
const ACCENT_PALETTE = [
  '#E07A1F', '#C0392B', '#2E7D5B', '#8E44AD', '#2980B9',
  '#D35400', '#16A085', '#C2185B', '#6A4C93', '#1B5E20',
];

function hashString(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

export function accentForId(id: string, fallback?: string): string {
  if (fallback) return fallback;
  return ACCENT_PALETTE[hashString(id) % ACCENT_PALETTE.length];
}

/** Compose a full `Recipe` from a `RecipeInput`, filling derived fields. */
export function composeRecipe(input: RecipeInput, now = Date.now()): Recipe {
  const id = input.id ?? `rcp_${now.toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  const createdAt = now;
  return {
    id,
    title: input.title.trim(),
    titleLocalized: input.titleLocalized,
    description: input.description.trim(),
    cuisine: input.cuisine.trim().toLowerCase(),
    category: input.category,
    difficulty: input.difficulty,
    servings: Math.round(input.servings),
    prepTimeMin: Math.round(input.prepTimeMin),
    cookTimeMin: Math.round(input.cookTimeMin),
    totalTimeMin: deriveTotalTime(input.prepTimeMin, input.cookTimeMin),
    caloriesPerServing: input.caloriesPerServing,
    source: input.source ?? 'user',
    accentColor: accentForId(id, input.accentColor),
    tags: input.tags.map((t) => t.trim().toLowerCase()).filter(Boolean),
    rating: input.rating,
    createdAt,
    updatedAt: createdAt,
    isFavorite: false,
    ingredients: input.ingredients.map((ri) => ({ ...ri })),
    steps: input.steps.map<RecipeStep>((s, idx) => ({
      stepNumber: idx + 1,
      instruction: s.instruction.trim(),
      durationMin: s.durationMin,
    })),
    nutrition: input.nutrition,
  };
}

/** Project a full recipe into a lightweight summary for lists/cards. */
export function toSummary(recipe: Recipe, pantryIngredientIds?: string[]): RecipeSummary {
  let pantryMatch: number | undefined;
  if (pantryIngredientIds && pantryIngredientIds.length > 0) {
    const pantry = new Set(pantryIngredientIds);
    pantryMatch = recipe.ingredients.filter((ri) => pantry.has(ri.ingredientId)).length;
  }
  return {
    id: recipe.id,
    title: recipe.titleLocalized?.en ?? recipe.title,
    description: recipe.description,
    cuisine: recipe.cuisine,
    category: recipe.category,
    difficulty: recipe.difficulty,
    servings: recipe.servings,
    prepTimeMin: recipe.prepTimeMin,
    cookTimeMin: recipe.cookTimeMin,
    totalTimeMin: recipe.totalTimeMin,
    caloriesPerServing: recipe.caloriesPerServing,
    source: recipe.source,
    accentColor: recipe.accentColor,
    tags: recipe.tags,
    rating: recipe.rating,
    isFavorite: recipe.isFavorite,
    pantryMatch,
    ingredientCount: recipe.ingredients.length,
  };
}

/** Resolve a recipe ingredient link to its catalogue name (English fallback). */
export function resolveIngredientName(ingredientId: string): string {
  return getIngredient(ingredientId)?.name.en ?? ingredientId;
}

export function totalIngredientCount(): number {
  return INGREDIENT_CATALOGUE.length;
}

/** Does a recipe use all of the given pantry ingredient ids? */
export function recipeUsesAll(recipe: Recipe, ingredientIds: string[]): boolean {
  if (ingredientIds.length === 0) return true;
  const have = new Set(recipe.ingredients.map((ri) => ri.ingredientId));
  return ingredientIds.every((id) => have.has(id));
}

/** How many of the recipe's ingredients are present in the pantry? */
export function pantryCoverage(recipe: Recipe, pantryIds: string[]): { match: number; total: number } {
  if (pantryIds.length === 0) return { match: 0, total: recipe.ingredients.length };
  const pantry = new Set(pantryIds);
  const match = recipe.ingredients.filter((ri) => pantry.has(ri.ingredientId)).length;
  return { match, total: recipe.ingredients.length };
}
