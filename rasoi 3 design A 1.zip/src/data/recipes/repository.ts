import type {
  DatabaseStats,
  ImportResult,
  Recipe,
  RecipeFilters,
  RecipeInput,
  RecipeSummary,
} from './types';

/**
 * REPOSITORY CONTRACT (Stage 3).
 *
 * A single interface implemented twice:
 *  - `SqliteRecipeRepository` — real on-device SQLite via expo-sqlite (native).
 *  - `MemoryRecipeRepository` — in-memory store (web preview fallback + test double).
 *
 * The rest of the app (contexts, screens, importer) depends only on this
 * interface, so the storage engine is swappable without touching UI code.
 */
export interface RecipeRepository {
  // ── Lifecycle ──────────────────────────────────────────────
  /** Apply migrations (SQLite) / hydrate persisted state (memory), then seed. */
  init(): Promise<void>;

  // ── Reads ──────────────────────────────────────────────────
  /** All recipes as lightweight summaries (favourites-aware). */
  list(): Promise<RecipeSummary[]>;
  /** Filtered + sorted search. */
  search(filters: RecipeFilters): Promise<RecipeSummary[]>;
  /** Full hydrated recipe by id, or null. */
  getById(id: string): Promise<Recipe | null>;
  /** Favourited recipe summaries. */
  getFavorites(): Promise<RecipeSummary[]>;
  /** Recipes that use ALL of the given ingredient ids (pantry matching). */
  getByIngredients(ingredientIds: string[]): Promise<RecipeSummary[]>;
  /** Total recipe count. */
  count(): Promise<number>;
  /** Engine + catalogue statistics for the Data screen. */
  stats(): Promise<DatabaseStats>;

  // ── Writes ─────────────────────────────────────────────────
  /** Insert-or-update a single recipe; returns its id. */
  upsert(input: RecipeInput): Promise<string>;
  /** Bulk insert-or-update; returns how many were inserted vs updated. */
  bulkUpsert(inputs: RecipeInput[]): Promise<{ inserted: number; updated: number }>;
  /** Delete a recipe by id (user recipes only — catalogue rows are restored on reseed). */
  remove(id: string): Promise<void>;
  /** Toggle favourite state for a recipe. */
  setFavorite(id: string, favorite: boolean): Promise<void>;

  // ── Catalogue admin ────────────────────────────────────────
  /** True once the static catalogue has been seeded. */
  isSeeded(): Promise<boolean>;
  /** Re-seed the static catalogue from the bundled seed data (idempotent upsert). */
  reseedCatalogue(): Promise<{ inserted: number; updated: number }>;
}

/**
 * Data-ingestion interface (Stage 3 requirement).
 *
 * Validates each candidate, composes valid ones into full recipes, and upserts
 * them through the repository. Invalid candidates are skipped with a report —
 * ingestion never throws on bad data; it reports it.
 */
export type Importer = (
  repo: RecipeRepository,
  inputs: RecipeInput[],
  opts?: { stopOnError?: boolean },
) => Promise<ImportResult>;

export type { Recipe, RecipeSummary, RecipeInput, RecipeFilters, DatabaseStats, ImportResult };
