import type { Localized } from '../../i18n';
import type { Unit } from '../ingredients';

/**
 * STRONGLY-TYPED RECIPE MODEL (Stage 3).
 *
 * Two flavours:
 *  - `Recipe`            : the full, hydrated document (with ingredients/steps/nutrition)
 *  - `RecipeSummary`     : a lightweight projection for lists/cards
 *  - `RecipeInput`       : the write shape used by the importer & add/edit screens
 *
 * Ownership separation (Stage 3 requirement):
 *  - `source: 'catalogue'` → app-owned, seeded, read-mostly static catalogue data
 *  - `source: 'user'`      → user-owned, fully mutable local data
 * Favorites are always user-owned and live in their own table, so favouriting a
 * catalogue recipe never mutates the static catalogue.
 */

export type RecipeCategory =
  | 'breakfast'
  | 'lunch'
  | 'dinner'
  | 'snack'
  | 'dessert'
  | 'beverage'
  | 'side';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type RecipeSource = 'catalogue' | 'user';

/** A link from a recipe to a canonical ingredient (by stable id). */
export interface RecipeIngredient {
  /** References `Ingredient.id` from the canonical catalogue. */
  ingredientId: string;
  quantity: number;
  unit: Unit;
  /** Optional prep note, e.g. "finely chopped". */
  note?: string;
}

export interface RecipeStep {
  stepNumber: number;
  instruction: string;
  /** Optional duration for this step in minutes (for timers). */
  durationMin?: number;
}

export interface NutritionInfo {
  calories: number;
  proteinG: number;
  carbsG: number;
  fatG: number;
  fiberG?: number;
}

/** The full hydrated recipe document. */
export interface Recipe {
  id: string;
  title: string;
  titleLocalized?: Localized;
  description: string;
  cuisine: string;
  category: RecipeCategory;
  difficulty: Difficulty;
  servings: number;
  prepTimeMin: number;
  cookTimeMin: number;
  /** Derived: prepTimeMin + cookTimeMin. Always recomputed, never stored as input. */
  totalTimeMin: number;
  caloriesPerServing?: number;
  source: RecipeSource;
  /** Color seed used to render a gradient header in lieu of a real photo. */
  accentColor: string;
  tags: string[];
  rating?: number;
  createdAt: number;
  updatedAt: number;
  isFavorite: boolean;
  ingredients: RecipeIngredient[];
  steps: RecipeStep[];
  nutrition?: NutritionInfo;
}

/** Lightweight projection for lists — no ingredients/steps arrays. */
export interface RecipeSummary {
  id: string;
  title: string;
  description: string;
  cuisine: string;
  category: RecipeCategory;
  difficulty: Difficulty;
  servings: number;
  prepTimeMin: number;
  cookTimeMin: number;
  totalTimeMin: number;
  caloriesPerServing?: number;
  source: RecipeSource;
  accentColor: string;
  tags: string[];
  rating?: number;
  isFavorite: boolean;
  /** Count of pantry ingredients that match, when computed. */
  pantryMatch?: number;
  ingredientCount: number;
}

/** Write shape — what the importer and the add/edit form produce. */
export interface RecipeInput {
  id?: string;
  title: string;
  titleLocalized?: Localized;
  description: string;
  cuisine: string;
  category: RecipeCategory;
  difficulty: Difficulty;
  servings: number;
  prepTimeMin: number;
  cookTimeMin: number;
  caloriesPerServing?: number;
  source?: RecipeSource;
  accentColor?: string;
  tags: string[];
  rating?: number;
  ingredients: RecipeIngredient[];
  steps: Omit<RecipeStep, 'stepNumber'>[];
  nutrition?: NutritionInfo;
}

export interface RecipeFilters {
  query?: string;
  category?: RecipeCategory | 'all';
  cuisine?: string;
  difficulty?: Difficulty | 'all';
  source?: RecipeSource | 'all';
  onlyFavorites?: boolean;
  /** Only recipes that use ALL of these ingredient ids. */
  ingredientIds?: string[];
  sort?: 'relevance' | 'time' | 'rating' | 'newest' | 'alpha';
}

export interface DatabaseStats {
  engine: 'sqlite' | 'memory';
  schemaVersion: number;
  recipeCount: number;
  catalogueCount: number;
  userCount: number;
  favoriteCount: number;
  ingredientCount: number;
  seededAt?: number;
}

export interface ImportResult {
  inserted: number;
  updated: number;
  skipped: number;
  errors: string[];
}

export interface ImportableRecipe extends RecipeInput {}
