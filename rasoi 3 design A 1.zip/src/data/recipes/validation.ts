import { isValidId } from '../../lib/id';
import { ingredientExists } from '../ingredients';
import type { Unit } from '../ingredients';
import type {
  Difficulty,
  NutritionInfo,
  RecipeCategory,
  RecipeInput,
  RecipeSource,
} from './types';

export const VALID_CATEGORIES: RecipeCategory[] = [
  'breakfast', 'lunch', 'dinner', 'snack', 'dessert', 'beverage', 'side',
];
export const VALID_DIFFICULTIES: Difficulty[] = ['easy', 'medium', 'hard'];
export const VALID_SOURCES: RecipeSource[] = ['catalogue', 'user'];
export const VALID_UNITS: Unit[] = [
  'g', 'kg', 'ml', 'l', 'tsp', 'tbsp', 'cup', 'piece', 'clove', 'pinch',
  'to_taste', 'slice', 'handful', 'stick', 'can',
];

export interface FieldError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: FieldError[];
}

function fail(field: string, message: string): FieldError {
  return { field, message };
}

function isFinitePositive(n: unknown): n is number {
  return typeof n === 'number' && Number.isFinite(n) && n > 0;
}
function isFiniteNonNeg(n: unknown): n is number {
  return typeof n === 'number' && Number.isFinite(n) && n >= 0;
}

/** Validate a single recipe input. Pure & side-effect free. */
export function validateRecipe(input: RecipeInput): ValidationResult {
  const errors: FieldError[] = [];

  if (!input || typeof input !== 'object') {
    return { valid: false, errors: [fail('root', 'Recipe input is required')] };
  }

  // Title
  const title = (input.title ?? '').trim();
  if (!title) errors.push(fail('title', 'Title is required'));
  else if (title.length > 120) errors.push(fail('title', 'Title must be 120 chars or fewer'));

  // Description
  const description = (input.description ?? '').trim();
  if (!description) errors.push(fail('description', 'Description is required'));
  else if (description.length > 600) errors.push(fail('description', 'Description must be 600 chars or fewer'));

  // Cuisine
  if (!(input.cuisine ?? '').trim()) errors.push(fail('cuisine', 'Cuisine is required'));

  // Category / difficulty / source enums
  if (!VALID_CATEGORIES.includes(input.category)) {
    errors.push(fail('category', `Invalid category: ${input.category}`));
  }
  if (!VALID_DIFFICULTIES.includes(input.difficulty)) {
    errors.push(fail('difficulty', `Invalid difficulty: ${input.difficulty}`));
  }
  if (input.source && !VALID_SOURCES.includes(input.source)) {
    errors.push(fail('source', `Invalid source: ${input.source}`));
  }

  // Numeric fields
  if (!isFinitePositive(input.servings)) errors.push(fail('servings', 'Servings must be a positive number'));
  if (!isFiniteNonNeg(input.prepTimeMin)) errors.push(fail('prepTimeMin', 'Prep time must be >= 0'));
  if (!isFiniteNonNeg(input.cookTimeMin)) errors.push(fail('cookTimeMin', 'Cook time must be >= 0'));
  if (input.caloriesPerServing !== undefined && !isFiniteNonNeg(input.caloriesPerServing)) {
    errors.push(fail('caloriesPerServing', 'Calories must be >= 0'));
  }
  if (input.rating !== undefined && (input.rating < 0 || input.rating > 5)) {
    errors.push(fail('rating', 'Rating must be between 0 and 5'));
  }

  // Tags
  if (input.tags.length > 12) errors.push(fail('tags', 'At most 12 tags allowed'));

  // Id (if provided — generated otherwise)
  if (input.id !== undefined && !isValidId(input.id)) {
    errors.push(fail('id', 'Invalid id format'));
  }

  // Ingredients
  if (!Array.isArray(input.ingredients) || input.ingredients.length === 0) {
    errors.push(fail('ingredients', 'At least one ingredient is required'));
  } else {
    const seen = new Set<string>();
    input.ingredients.forEach((ri, idx) => {
      const prefix = `ingredients[${idx}]`;
      if (!ri.ingredientId || !ingredientExists(ri.ingredientId)) {
        errors.push(fail(`${prefix}.ingredientId`, `Unknown ingredient: ${ri.ingredientId}`));
      }
      if (seen.has(ri.ingredientId)) {
        errors.push(fail(`${prefix}.ingredientId`, `Duplicate ingredient: ${ri.ingredientId}`));
      }
      seen.add(ri.ingredientId);
      if (!isFinitePositive(ri.quantity) && ri.unit !== 'to_taste') {
        errors.push(fail(`${prefix}.quantity`, 'Quantity must be positive'));
      }
      if (!VALID_UNITS.includes(ri.unit)) {
        errors.push(fail(`${prefix}.unit`, `Invalid unit: ${ri.unit}`));
      }
      if (ri.note !== undefined && ri.note.length > 80) {
        errors.push(fail(`${prefix}.note`, 'Note must be 80 chars or fewer'));
      }
    });
  }

  // Steps
  if (!Array.isArray(input.steps) || input.steps.length === 0) {
    errors.push(fail('steps', 'At least one step is required'));
  } else {
    input.steps.forEach((s, idx) => {
      const prefix = `steps[${idx}]`;
      if (!(s.instruction ?? '').trim()) {
        errors.push(fail(`${prefix}.instruction`, 'Step instruction is required'));
      } else if (s.instruction.length > 500) {
        errors.push(fail(`${prefix}.instruction`, 'Step must be 500 chars or fewer'));
      }
      if (s.durationMin !== undefined && !isFiniteNonNeg(s.durationMin)) {
        errors.push(fail(`${prefix}.durationMin`, 'Duration must be >= 0'));
      }
    });
  }

  // Nutrition (optional but if present must be sane)
  if (input.nutrition) errors.push(...validateNutrition(input.nutrition));

  return { valid: errors.length === 0, errors };
}

export function validateNutrition(n: NutritionInfo): FieldError[] {
  const errors: FieldError[] = [];
  const prefix = 'nutrition';
  if (!isFiniteNonNeg(n.calories)) errors.push(fail(`${prefix}.calories`, 'Calories must be >= 0'));
  if (!isFiniteNonNeg(n.proteinG)) errors.push(fail(`${prefix}.proteinG`, 'Protein must be >= 0'));
  if (!isFiniteNonNeg(n.carbsG)) errors.push(fail(`${prefix}.carbsG`, 'Carbs must be >= 0'));
  if (!isFiniteNonNeg(n.fatG)) errors.push(fail(`${prefix}.fatG`, 'Fat must be >= 0'));
  if (n.fiberG !== undefined && !isFiniteNonNeg(n.fiberG)) {
    errors.push(fail(`${prefix}.fiberG`, 'Fiber must be >= 0'));
  }
  return errors;
}

/** Compute total time — derived, never trusted from input. */
export function deriveTotalTime(prep: number, cook: number): number {
  const p = isFiniteNonNeg(prep) ? prep : 0;
  const c = isFiniteNonNeg(cook) ? cook : 0;
  return p + c;
}
