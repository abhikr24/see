import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { loadJSON, saveJSON } from '../lib/storage';

export type Locale = 'en' | 'hi';

export type Localized = { en: string; hi: string };

// Keep keys flat & typed so misuse is caught at compile time.
const en = {
  appName: 'Rasoi',
  tagline: 'Your kitchen, organized',
  // tabs
  tabHome: 'Home',
  tabRecipes: 'Recipes',
  tabIngredients: 'Ingredients',
  tabPantry: 'Pantry',
  tabData: 'Data',
  // common
  search: 'Search',
  save: 'Save',
  cancel: 'Cancel',
  delete: 'Delete',
  remove: 'Remove',
  edit: 'Edit',
  add: 'Add',
  done: 'Done',
  back: 'Back',
  close: 'Close',
  retry: 'Retry',
  loading: 'Loading…',
  empty: 'Nothing here yet',
  minutes: 'min',
  servings: 'servings',
  serving: 'serving',
  // recipe attributes
  ingredients: 'Ingredients',
  steps: 'Steps',
  nutrition: 'Nutrition',
  difficulty: 'Difficulty',
  category: 'Category',
  cuisine: 'Cuisine',
  prepTime: 'Prep',
  cookTime: 'Cook',
  totalTime: 'Total',
  calories: 'Calories',
  protein: 'Protein',
  carbs: 'Carbs',
  fat: 'Fat',
  fiber: 'Fiber',
  perServing: 'per serving',
  easy: 'Easy',
  medium: 'Medium',
  hard: 'Hard',
  // home
  homeGreeting: 'Namaste 👋',
  homeSub: 'What would you like to cook today?',
  homeBrowse: 'Browse recipes',
  homeWhatCanICook: 'What can I cook',
  homeWhatCanICookSub: 'Recipes using your pantry',
  homeFavorites: 'Favorites',
  homeAddRecipe: 'Add a recipe',
  homeCatalogue: 'Recipe catalogue',
  homeFeatured: 'Featured',
  homePantryEmpty: 'Add ingredients to your pantry to see matching recipes.',
  // recipes
  recipesTitle: 'Recipes',
  recipesSearch: 'Search recipes, cuisines, tags…',
  recipesAll: 'All',
  recipesNoResults: 'No recipes match your search.',
  recipesCount: '{n} recipes',
  recipesMatching: '{n} matching',
  // ingredients
  ingredientsTitle: 'Ingredients',
  ingredientsSearch: 'Search ingredients…',
  ingredientsAddToPantry: 'Add to pantry',
  ingredientsSelected: '{n} selected',
  ingredientsInPantry: 'In pantry',
  ingredientsAll: 'All',
  // pantry
  pantryTitle: 'Pantry',
  pantryEmpty: 'Your pantry is empty.',
  pantryEmptySub: 'Pick ingredients from the Ingredients tab to build your pantry.',
  pantryFindRecipes: 'Find recipes',
  pantryClear: 'Clear pantry',
  pantryCount: '{n} ingredients',
  // recipe detail
  detailSave: 'Save recipe',
  detailSaved: 'Saved',
  detailUserRecipe: 'Your recipe',
  detailCatalogueRecipe: 'Catalogue recipe',
  detailStep: 'Step {n}',
  detailSharePantryMatch: '{n}/{total} pantry ingredients',
  detailDeleteConfirm: 'Delete this recipe?',
  detailDeleteMsg: 'This cannot be undone.',
  // add recipe
  addTitle: 'New recipe',
  addEditTitle: 'Edit recipe',
  addTitleField: 'Title',
  addTitlePh: 'e.g. Paneer Butter Masala',
  addDescription: 'Description',
  addDescriptionPh: 'A short description…',
  addServings: 'Servings',
  addPrep: 'Prep time (min)',
  addCook: 'Cook time (min)',
  addCuisine: 'Cuisine',
  addCategory: 'Category',
  addDifficulty: 'Difficulty',
  addTags: 'Tags (comma separated)',
  addIngredients: 'Ingredients',
  addIngredient: 'Add ingredient',
  addSteps: 'Steps',
  addStep: 'Add step',
  addSave: 'Save recipe',
  addSelectIngredient: 'Select ingredient',
  addQuantity: 'Qty',
  addUnit: 'Unit',
  addStepText: 'Step instruction',
  addValidation: 'Please fix the highlighted fields.',
  addSavedToast: 'Recipe saved',
  // database / stage 3
  dataTitle: 'Data & Storage',
  dataHealth: 'Database health',
  dataStats: 'Catalogue statistics',
  dataMigrations: 'Schema migrations',
  dataTests: 'Validation tests',
  dataRunTests: 'Run tests',
  dataReseed: 'Re-seed catalogue',
  dataStorage: 'Storage engine',
  dataVersion: 'Schema version',
  dataRecipeCount: 'Recipes',
  dataUserCount: 'User recipes',
  dataFavCount: 'Favorites',
  dataIngCount: 'Ingredients',
  dataTestsPassed: '{passed}/{total} passed',
  dataTestsOk: 'All tests passed',
  dataTestsFail: 'Some tests failed',
  dataReseeded: 'Catalogue re-seeded',
  dataReseedConfirm: 'Re-seed the catalogue?',
  dataReseedMsg: 'User recipes & favorites are preserved.',
  dataStatusOk: 'Healthy',
  dataStatusWarn: 'Degraded',
  dataStatusDown: 'Unavailable',
  dataEngineSqlite: 'SQLite (on-device)',
  dataEngineMemory: 'In-memory (preview)',
  dataSeedApplied: 'Catalogue applied',
  // misc
  cookbook: 'Cookbook',
  viewAll: 'View all',
};

const hi: Record<keyof typeof en, string> = {
  appName: 'रसोई',
  tagline: 'आपकी रसोई, व्यवस्थित',
  tabHome: 'होम',
  tabRecipes: 'रेसिपी',
  tabIngredients: 'सामग्री',
  tabPantry: 'पेंट्री',
  tabData: 'डेटा',
  search: 'खोजें',
  save: 'सहेजें',
  cancel: 'रद्द करें',
  delete: 'हटाएं',
  remove: 'हटाएं',
  edit: 'संपादित करें',
  add: 'जोड़ें',
  done: 'हो गया',
  back: 'वापस',
  close: 'बंद करें',
  retry: 'पुनः प्रयास',
  loading: 'लोड हो रहा है…',
  empty: 'यहाँ कुछ नहीं है',
  minutes: 'मिनट',
  servings: 'सर्विंग',
  serving: 'सर्विंग',
  ingredients: 'सामग्री',
  steps: 'चरण',
  nutrition: 'पोषण',
  difficulty: 'कठिनाई',
  category: 'श्रेणी',
  cuisine: 'भोजन शैली',
  prepTime: 'तैयारी',
  cookTime: 'पकाना',
  totalTime: 'कुल',
  calories: 'कैलोरी',
  protein: 'प्रोटीन',
  carbs: 'कार्ब्स',
  fat: 'वसा',
  fiber: 'फाइबर',
  perServing: 'प्रति सर्विंग',
  easy: 'आसान',
  medium: 'मध्यम',
  hard: 'कठिन',
  homeGreeting: 'नमस्ते 👋',
  homeSub: 'आज आप क्या पकाना चाहेंगे?',
  homeBrowse: 'रेसिपी देखें',
  homeWhatCanICook: 'क्या बना सकते हैं',
  homeWhatCanICookSub: 'आपकी पेंट्री से रेसिपी',
  homeFavorites: 'पसंदीदा',
  homeAddRecipe: 'रेसिपी जोड़ें',
  homeCatalogue: 'रेसिपी संग्रह',
  homeFeatured: 'विशेष',
  homePantryEmpty: 'मैचिंग रेसिपी देखने के लिए सामग्री जोड़ें।',
  recipesTitle: 'रेसिपी',
  recipesSearch: 'रेसिपी, शैली, टैग खोजें…',
  recipesAll: 'सभी',
  recipesNoResults: 'कोई रेसिपी नहीं मिली।',
  recipesCount: '{n} रेसिपी',
  recipesMatching: '{n} मैच',
  ingredientsTitle: 'सामग्री',
  ingredientsSearch: 'सामग्री खोजें…',
  ingredientsAddToPantry: 'पेंट्री में जोड़ें',
  ingredientsSelected: '{n} चुने',
  ingredientsInPantry: 'पेंट्री में',
  ingredientsAll: 'सभी',
  pantryTitle: 'पेंट्री',
  pantryEmpty: 'आपकी पेंट्री खाली है।',
  pantryEmptySub: 'सामग्री टैब से चुनें।',
  pantryFindRecipes: 'रेसिपी खोजें',
  pantryClear: 'पेंट्री खाली करें',
  pantryCount: '{n} सामग्री',
  detailSave: 'सहेजें',
  detailSaved: 'सहेजा गया',
  detailUserRecipe: 'आपकी रेसिपी',
  detailCatalogueRecipe: 'संग्रह रेसिपी',
  detailStep: 'चरण {n}',
  detailSharePantryMatch: '{n}/{total} पेंट्री सामग्री',
  detailDeleteConfirm: 'यह रेसिपी हटाएं?',
  detailDeleteMsg: 'यह वापस नहीं होगा।',
  addTitle: 'नई रेसिपी',
  addEditTitle: 'रेसिपी संपादित करें',
  addTitleField: 'शीर्षक',
  addTitlePh: 'जैसे पनीर बटर मसाला',
  addDescription: 'विवरण',
  addDescriptionPh: 'संक्षिप्त विवरण…',
  addServings: 'सर्विंग',
  addPrep: 'तैयारी (मिनट)',
  addCook: 'पकाना (मिनट)',
  addCuisine: 'शैली',
  addCategory: 'श्रेणी',
  addDifficulty: 'कठिनाई',
  addTags: 'टैग (कॉमा से अलग)',
  addIngredients: 'सामग्री',
  addIngredient: 'सामग्री जोड़ें',
  addSteps: 'चरण',
  addStep: 'चरण जोड़ें',
  addSave: 'रेसिपी सहेजें',
  addSelectIngredient: 'सामग्री चुनें',
  addQuantity: 'मात्रा',
  addUnit: 'इकाई',
  addStepText: 'चरण निर्देश',
  addValidation: 'चिह्नित फ़ील्ड ठीक करें।',
  addSavedToast: 'रेसिपी सहेजी गई',
  dataTitle: 'डेटा व स्टोरेज',
  dataHealth: 'डेटाबेस स्थिति',
  dataStats: 'संग्रह आँकड़े',
  dataMigrations: 'स्कीमा माइग्रेशन',
  dataTests: 'सत्यापन परीक्षण',
  dataRunTests: 'परीक्षण चलाएं',
  dataReseed: 'संग्रह पुनः भरें',
  dataStorage: 'स्टोरेज इंजन',
  dataVersion: 'स्कीमा संस्करण',
  dataRecipeCount: 'रेसिपी',
  dataUserCount: 'उपयोगकर्ता रेसिपी',
  dataFavCount: 'पसंदीदा',
  dataIngCount: 'सामग्री',
  dataTestsPassed: '{passed}/{total} उत्तीर्ण',
  dataTestsOk: 'सभी परीक्षण उत्तीर्ण',
  dataTestsFail: 'कुछ परीक्षण असफल',
  dataReseeded: 'संग्रह पुनः भरा गया',
  dataReseedConfirm: 'संग्रह पुनः भरें?',
  dataReseedMsg: 'उपयोगकर्ता रेसिपी व पसंदीदा बनी रहेंगे।',
  dataStatusOk: 'स्वस्थ',
  dataStatusWarn: 'प्रभावित',
  dataStatusDown: 'अनुपलब्ध',
  dataEngineSqlite: 'SQLite (डिवाइस पर)',
  dataEngineMemory: 'इन-मेमरी (पूर्वावलोकन)',
  dataSeedApplied: 'संग्रह लागू',
  cookbook: 'कुकबुक',
  viewAll: 'सभी देखें',
};

export type TranslationKey = keyof typeof en;
export const dictionaries: Record<Locale, Record<TranslationKey, string>> = { en, hi };

interface I18nContextValue {
  locale: Locale;
  setLocale: (l: Locale) => void;
  t: (key: TranslationKey, vars?: Record<string, string | number>) => string;
  L: (loc: Localized) => string;
}

const I18nContext = createContext<I18nContextValue | null>(null);

function interpolate(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (_, k: string) =>
    vars[k] !== undefined ? String(vars[k]) : `{${k}}`,
  );
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('en');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadJSON<Locale>('locale', 'en').then((l) => {
      setLocaleState(l);
      setLoaded(true);
    });
  }, []);

  const setLocale = (l: Locale) => {
    setLocaleState(l);
    saveJSON('locale', l);
  };

  const value = useMemo<I18nContextValue>(
    () => ({
      locale,
      setLocale,
      t: (key, vars) => interpolate(dictionaries[locale][key] ?? dictionaries.en[key], vars),
      L: (loc) => loc[locale] ?? loc.en,
    }),
    [locale],
  );

  if (!loaded) return null;
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const v = useContext(I18nContext);
  if (!v) throw new Error('useI18n must be used within I18nProvider');
  return v;
}

export function useT() {
  return useI18n().t;
}
