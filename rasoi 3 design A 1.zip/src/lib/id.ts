// Stable id generation utilities. Canonical catalogue ids are hand-authored
// (e.g. `rcp_0001`, `ing_tomato`). User-owned ids are generated at runtime.

export function makeUserId(prefix = 'usr'): string {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${ts}${rand}`;
}

export function makeRecipeId(): string {
  return makeUserId('rcp');
}

const ID_RE = /^[a-z0-9_]{3,64}$/i;

export function isValidId(id: string): boolean {
  return ID_RE.test(id);
}
