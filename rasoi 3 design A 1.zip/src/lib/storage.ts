import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Thin, typed wrappers around AsyncStorage used for user-owned local data
 * (pantry, theme preference, recipe user-state). Static catalogue data lives
 * in code / SQLite, never here.
 */
const PREFIX = 'rasoi.';

export async function loadJSON<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(PREFIX + key);
    if (raw == null) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    // Never let a corrupt payload crash the app — fall back gracefully.
    return fallback;
  }
}

export async function saveJSON<T>(key: string, value: T): Promise<void> {
  try {
    await AsyncStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    // Storage failures are non-fatal for ephemeral user state.
  }
}

export async function removeKey(key: string): Promise<void> {
  try {
    await AsyncStorage.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}

export async function loadRaw(key: string): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(PREFIX + key);
  } catch {
    return null;
  }
}
