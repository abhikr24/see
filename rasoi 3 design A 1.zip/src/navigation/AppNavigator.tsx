import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { Ionicons as IoniconsType } from '@expo/vector-icons/Ionicons';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useI18n } from '../i18n';
import { useTheme } from '../theme';
import type { RootStackParamList, TabsParamList } from './types';
import { HomeScreen } from '../screens/HomeScreen';
import { RecipesScreen } from '../screens/RecipesScreen';
import { IngredientsScreen } from '../screens/IngredientsScreen';
import { PantryScreen } from '../screens/PantryScreen';
import { DatabaseScreen } from '../screens/DatabaseScreen';
import { RecipeDetailScreen } from '../screens/RecipeDetailScreen';
import { AddRecipeScreen } from '../screens/AddRecipeScreen';

const Tab = createBottomTabNavigator<TabsParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

type IconName = React.ComponentProps<typeof IoniconsType>['name'];

function Tabs() {
  const { colors } = useTheme();
  const { t } = useI18n();
  const tabs: {
    name: keyof TabsParamList;
    label: string;
    icon: IconName;
    component: React.ComponentType;
  }[] = [
    { name: 'Home', label: t('tabHome'), icon: 'home', component: HomeScreen },
    { name: 'Recipes', label: t('tabRecipes'), icon: 'book', component: RecipesScreen },
    { name: 'Ingredients', label: t('tabIngredients'), icon: 'nutrition', component: IngredientsScreen },
    { name: 'Pantry', label: t('tabPantry'), icon: 'basket', component: PantryScreen },
    { name: 'Data', label: t('tabData'), icon: 'server', component: DatabaseScreen },
  ];
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.tabBarInactive,
        tabBarStyle: {
          backgroundColor: colors.tabBar,
          borderTopColor: colors.border,
          height: 58,
          paddingBottom: 4,
          paddingTop: 4,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      }}
    >
      {tabs.map((tab) => (
        <Tab.Screen
          key={tab.name}
          name={tab.name}
          component={tab.component}
          options={{
            tabBarLabel: tab.label,
            tabBarIcon: ({ color, size }) => <Ionicons name={tab.icon} size={size} color={color} />,
          }}
        />
      ))}
    </Tab.Navigator>
  );
}

export function AppNavigator() {
  const { colors } = useTheme();
  const { t } = useI18n();
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.background },
        headerTintColor: colors.textPrimary,
        headerShadowVisible: false,
        headerTitleStyle: { fontWeight: '700' },
        contentStyle: { backgroundColor: colors.background },
      }}
    >
      <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
      <Stack.Screen
        name="RecipeDetail"
        component={RecipeDetailScreen}
        options={{ title: t('recipesTitle'), presentation: 'card' }}
      />
      <Stack.Screen
        name="AddRecipe"
        component={AddRecipeScreen}
        options={{ title: t('addTitle'), presentation: 'modal' }}
      />
    </Stack.Navigator>
  );
}
