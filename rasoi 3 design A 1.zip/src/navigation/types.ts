import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import type { CompositeNavigationProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

export type TabsParamList = {
  Home: undefined;
  Recipes: undefined;
  Ingredients: undefined;
  Pantry: undefined;
  Data: undefined;
};

export type RootStackParamList = {
  Tabs: undefined;
  RecipeDetail: { recipeId: string };
  AddRecipe: { recipeId?: string };
};

/** Navigation prop for a screen that lives inside the Tabs navigator. */
export type TabScreenNav<K extends keyof TabsParamList> = CompositeNavigationProp<
  BottomTabNavigationProp<TabsParamList, K>,
  NativeStackNavigationProp<RootStackParamList>
>;

/** Navigation prop for a screen that lives in the root stack (above tabs). */
export type StackScreenNav<K extends keyof RootStackParamList> = NativeStackNavigationProp<
  RootStackParamList,
  K
>;

export type RootStackNavigation = NativeStackNavigationProp<RootStackParamList>;

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
