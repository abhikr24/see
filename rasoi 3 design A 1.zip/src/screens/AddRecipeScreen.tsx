import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { getIngredient } from '../data/ingredients';
import type { Ingredient, Unit } from '../data/ingredients';
import type { Difficulty, RecipeCategory, RecipeInput, RecipeIngredient } from '../data/recipes';
import { VALID_CATEGORIES, VALID_DIFFICULTIES, validateRecipe } from '../data/recipes';
import { useI18n } from '../i18n';
import { useRecipes } from '../context/RecipeContext';
import { radius, spacing, typography, useTheme } from '../theme';
import { Button } from '../components/Button';
import { Chip } from '../components/Chip';
import { IngredientPicker } from '../components/IngredientPicker';
import { UNIT_OPTIONS, formatQuantity } from '../components/recipeMeta';
import type { StackScreenNav } from '../navigation/types';
import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '../navigation/types';

interface DraftIngredient {
  ingredientId: string;
  quantity: string;
  unit: Unit;
  note: string;
}
interface DraftStep {
  instruction: string;
  durationMin: string;
}

const CATEGORY_LABELS: Record<RecipeCategory, string> = {
  breakfast: 'Breakfast', lunch: 'Lunch', dinner: 'Dinner', snack: 'Snack',
  dessert: 'Dessert', beverage: 'Beverage', side: 'Side',
};
const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  easy: 'Easy', medium: 'Medium', hard: 'Hard',
};

export function AddRecipeScreen() {
  const { colors } = useTheme();
  const { t } = useI18n();
  const { repo, refresh } = useRecipes();
  const navigation = useNavigation<StackScreenNav<'AddRecipe'>>();
  const route = useRoute<RouteProp<RootStackParamList, 'AddRecipe'>>();
  const editId = route.params?.recipeId;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [cuisine, setCuisine] = useState('');
  const [category, setCategory] = useState<RecipeCategory>('dinner');
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [servings, setServings] = useState('2');
  const [prepTime, setPrepTime] = useState('10');
  const [cookTime, setCookTime] = useState('20');
  const [calories, setCalories] = useState('');
  const [tags, setTags] = useState('');
  const [ingredients, setIngredients] = useState<DraftIngredient[]>([]);
  const [steps, setSteps] = useState<DraftStep[]>([{ instruction: '', durationMin: '' }]);
  const [pickerVisible, setPickerVisible] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [loadedEdit, setLoadedEdit] = useState(!editId);

  useEffect(() => {
    if (!editId || !repo) return;
    repo.getById(editId).then((r) => {
      if (!r) return;
      setTitle(r.title);
      setDescription(r.description);
      setCuisine(r.cuisine);
      setCategory(r.category);
      setDifficulty(r.difficulty);
      setServings(String(r.servings));
      setPrepTime(String(r.prepTimeMin));
      setCookTime(String(r.cookTimeMin));
      setCalories(r.caloriesPerServing ? String(r.caloriesPerServing) : '');
      setTags(r.tags.join(', '));
      setIngredients(
        r.ingredients.map((ri) => ({
          ingredientId: ri.ingredientId,
          quantity: String(ri.quantity),
          unit: ri.unit,
          note: ri.note ?? '',
        })),
      );
      setSteps(r.steps.map((s) => ({ instruction: s.instruction, durationMin: s.durationMin ? String(s.durationMin) : '' })));
      setLoadedEdit(true);
    });
  }, [editId, repo]);

  const excludeIds = useMemo(() => ingredients.map((i) => i.ingredientId), [ingredients]);

  const addIngredient = useCallback((ing: Ingredient) => {
    setIngredients((prev) => [...prev, { ingredientId: ing.id, quantity: '1', unit: ing.defaultUnit, note: '' }]);
    setPickerVisible(false);
  }, []);

  const updateIngredient = useCallback((idx: number, patch: Partial<DraftIngredient>) => {
    setIngredients((prev) => prev.map((x, i) => (i === idx ? { ...x, ...patch } : x)));
  }, []);

  const removeIngredient = useCallback((idx: number) => {
    setIngredients((prev) => prev.filter((_, i) => i !== idx));
  }, []);

  const cycleUnit = useCallback((idx: number) => {
    setIngredients((prev) =>
      prev.map((x, i) => {
        if (i !== idx) return x;
        const next = (UNIT_OPTIONS.indexOf(x.unit) + 1) % UNIT_OPTIONS.length;
        return { ...x, unit: UNIT_OPTIONS[next] };
      }),
    );
  }, []);

  const updateStep = useCallback((idx: number, patch: Partial<DraftStep>) => {
    setSteps((prev) => prev.map((x, i) => (i === idx ? { ...x, ...patch } : x)));
  }, []);

  const removeStep = useCallback((idx: number) => {
    setSteps((prev) => prev.filter((_, i) => i !== idx));
  }, []);

  const handleSave = useCallback(async () => {
    if (!repo) return;
    const input: RecipeInput = {
      id: editId,
      title: title.trim(),
      description: description.trim(),
      cuisine: cuisine.trim(),
      category,
      difficulty,
      servings: Number(servings) || 0,
      prepTimeMin: Number(prepTime) || 0,
      cookTimeMin: Number(cookTime) || 0,
      caloriesPerServing: calories ? Number(calories) : undefined,
      source: 'user',
      tags: tags.split(',').map((s) => s.trim()).filter(Boolean),
      ingredients: ingredients
        .filter((i) => i.ingredientId)
        .map<RecipeIngredient>((i) => ({
          ingredientId: i.ingredientId,
          quantity: Number(i.quantity) || (i.unit === 'to_taste' ? 0 : 1),
          unit: i.unit,
          note: i.note.trim() || undefined,
        })),
      steps: steps
        .map((s) => ({ instruction: s.instruction.trim(), durationMin: s.durationMin ? Number(s.durationMin) : undefined }))
        .filter((s) => s.instruction.length > 0),
      nutrition: undefined,
    };
    const result = validateRecipe(input);
    if (!result.valid) {
      setErrors(result.errors.slice(0, 5).map((e) => `${e.field}: ${e.message}`));
      return;
    }
    setErrors([]);
    setSaving(true);
    try {
      await repo.upsert(input);
      await refresh();
      navigation.goBack();
    } catch (e) {
      setErrors([e instanceof Error ? e.message : 'Save failed']);
    } finally {
      setSaving(false);
    }
  }, [repo, editId, title, description, cuisine, category, difficulty, servings, prepTime, cookTime, calories, tags, ingredients, steps, refresh, navigation]);

  if (!loadedEdit) {
    return <View style={[styles.container, { backgroundColor: colors.background }]} />;
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <ScrollView style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Field label={t('addTitleField')}>
          <TextInput
            value={title}
            onChangeText={setTitle}
            placeholder={t('addTitlePh')}
            placeholderTextColor={colors.textMuted}
            style={[inputStyle(colors), styles.input]}
          />
        </Field>

        <Field label={t('addDescription')}>
          <TextInput
            value={description}
            onChangeText={setDescription}
            placeholder={t('addDescriptionPh')}
            placeholderTextColor={colors.textMuted}
            multiline
            style={[inputStyle(colors), styles.input, styles.textarea]}
          />
        </Field>

        <Field label={t('addCuisine')}>
          <TextInput
            value={cuisine}
            onChangeText={setCuisine}
            placeholder="e.g. indian"
            placeholderTextColor={colors.textMuted}
            autoCapitalize="none"
            style={[inputStyle(colors), styles.input]}
          />
        </Field>

        <Field label={t('addCategory')}>
          <View style={styles.chips}>
            {VALID_CATEGORIES.map((c) => (
              <Chip key={c} label={CATEGORY_LABELS[c]} selected={category === c} onPress={() => setCategory(c)} />
            ))}
          </View>
        </Field>

        <Field label={t('addDifficulty')}>
          <View style={styles.chips}>
            {VALID_DIFFICULTIES.map((d) => (
              <Chip key={d} label={DIFFICULTY_LABELS[d]} selected={difficulty === d} onPress={() => setDifficulty(d)} />
            ))}
          </View>
        </Field>

        <View style={styles.row2}>
          <Field label={t('addServings')} style={{ flex: 1, marginRight: spacing.sm }}>
            <NumInput value={servings} onChange={setServings} colors={colors} />
          </Field>
          <Field label={t('calories')} style={{ flex: 1 }}>
            <NumInput value={calories} onChange={setCalories} colors={colors} placeholder="—" />
          </Field>
        </View>

        <View style={styles.row2}>
          <Field label={`${t('addPrep')}`} style={{ flex: 1, marginRight: spacing.sm }}>
            <NumInput value={prepTime} onChange={setPrepTime} colors={colors} />
          </Field>
          <Field label={t('addCook')} style={{ flex: 1 }}>
            <NumInput value={cookTime} onChange={setCookTime} colors={colors} />
          </Field>
        </View>

        <Field label={t('addTags')}>
          <TextInput
            value={tags}
            onChangeText={setTags}
            placeholder="quick, vegetarian, spicy"
            placeholderTextColor={colors.textMuted}
            style={[inputStyle(colors), styles.input]}
          />
        </Field>

        {/* Ingredients */}
        <Field label={t('addIngredients')}>
          <View style={styles.ingList}>
            {ingredients.map((ing, idx) => {
              const i = getIngredient(ing.ingredientId);
              return (
                <View key={ing.ingredientId + idx} style={[styles.ingRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={styles.ingEmoji}>{i?.emoji ?? '•'}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.ingName, { color: colors.textPrimary }]} numberOfLines={1}>
                      {i ? i.name.en : ing.ingredientId}
                    </Text>
                    <View style={styles.ingControls}>
                      <TextInput
                        value={ing.quantity}
                        onChangeText={(v) => updateIngredient(idx, { quantity: v })}
                        keyboardType="decimal-pad"
                        style={[styles.qtyInput, { backgroundColor: colors.surfaceAlt, color: colors.textPrimary }]}
                      />
                      <Pressable
                        onPress={() => cycleUnit(idx)}
                        style={({ pressed }) => [styles.unitBtn, { backgroundColor: colors.surfaceAlt }, pressed && { opacity: 0.6 }]}
                      >
                        <Text style={[styles.unitText, { color: colors.textSecondary }]}>{ing.unit}</Text>
                      </Pressable>
                    </View>
                  </View>
                  <Pressable onPress={() => removeIngredient(idx)} hitSlop={8} style={styles.removeBtn}>
                    <Ionicons name="trash-outline" size={18} color={colors.danger} />
                  </Pressable>
                </View>
              );
            })}
            <Button label={t('addIngredient')} variant="secondary" icon="➕" onPress={() => setPickerVisible(true)} />
          </View>
        </Field>

        {/* Steps */}
        <Field label={t('addSteps')}>
          <View style={styles.ingList}>
            {steps.map((s, idx) => (
              <View key={idx} style={[styles.stepBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <View style={styles.stepHeader}>
                  <Text style={[styles.stepIndex, { color: colors.textMuted }]}>{idx + 1}</Text>
                  {steps.length > 1 ? (
                    <Pressable onPress={() => removeStep(idx)} hitSlop={8}>
                      <Ionicons name="close" size={18} color={colors.textMuted} />
                    </Pressable>
                  ) : null}
                </View>
                <TextInput
                  value={s.instruction}
                  onChangeText={(v) => updateStep(idx, { instruction: v })}
                  placeholder={t('addStepText')}
                  placeholderTextColor={colors.textMuted}
                  multiline
                  style={[inputStyle(colors), styles.input, styles.textarea]}
                />
                <View style={styles.stepDurRow}>
                  <Text style={[styles.stepDurLabel, { color: colors.textMuted }]}>{t('addPrep')} (min)</Text>
                  <TextInput
                    value={s.durationMin}
                    onChangeText={(v) => updateStep(idx, { durationMin: v })}
                    keyboardType="decimal-pad"
                    placeholder="0"
                    placeholderTextColor={colors.textMuted}
                    style={[styles.durInput, { backgroundColor: colors.surfaceAlt, color: colors.textPrimary }]}
                  />
                </View>
              </View>
            ))}
            <Button label={t('addStep')} variant="secondary" icon="➕" onPress={() => setSteps((p) => [...p, { instruction: '', durationMin: '' }])} />
          </View>
        </Field>

        {errors.length > 0 ? (
          <View style={[styles.errorBox, { backgroundColor: colors.surfaceAlt, borderColor: colors.danger }]}>
            <Text style={[styles.errorTitle, { color: colors.danger }]}>{t('addValidation')}</Text>
            {errors.map((e, i) => (
              <Text key={i} style={[styles.errorMsg, { color: colors.danger }]}>• {e}</Text>
            ))}
          </View>
        ) : null}

        <View style={{ height: spacing.xl }} />
      </ScrollView>

      <View style={[styles.saveBar, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
        <Button label={t('cancel')} variant="ghost" onPress={() => navigation.goBack()} style={{ flex: 0 }} />
        <Button label={t('addSave')} onPress={handleSave} loading={saving} style={{ flex: 1, marginLeft: spacing.sm }} />
      </View>

      <IngredientPicker
        visible={pickerVisible}
        onClose={() => setPickerVisible(false)}
        onPick={addIngredient}
        excludeIds={excludeIds}
      />
    </KeyboardAvoidingView>
  );
}

function Field({ label, children, style }: { label: string; children: React.ReactNode; style?: any }) {
  const { colors } = useTheme();
  return (
    <View style={[styles.field, style]}>
      <Text style={[styles.fieldLabel, { color: colors.textSecondary }]}>{label}</Text>
      {children}
    </View>
  );
}

function NumInput({ value, onChange, colors, placeholder }: { value: string; onChange: (v: string) => void; colors: any; placeholder?: string }) {
  return (
    <TextInput
      value={value}
      onChangeText={onChange}
      keyboardType="decimal-pad"
      placeholder={placeholder}
      placeholderTextColor={colors.textMuted}
      style={[inputStyle(colors), styles.input]}
    />
  );
}

function inputStyle(colors: any) {
  return {
    backgroundColor: colors.surface,
    borderColor: colors.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: radius.md,
    color: colors.textPrimary,
  } as const;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: spacing.edge, paddingTop: spacing.lg, paddingBottom: spacing.xxxl },
  field: { marginBottom: spacing.lg },
  fieldLabel: { ...typography.caption, fontWeight: '700', marginBottom: spacing.xs, textTransform: 'uppercase', fontSize: 11 },
  input: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm, height: 48, ...typography.body },
  textarea: { height: 80, textAlignVertical: 'top' },
  chips: { flexDirection: 'row', flexWrap: 'wrap' },
  row2: { flexDirection: 'row' },
  ingList: { gap: spacing.sm },
  ingRow: { flexDirection: 'row', alignItems: 'center', borderRadius: radius.md, borderWidth: StyleSheet.hairlineWidth, padding: spacing.sm, gap: spacing.sm },
  ingEmoji: { fontSize: 24 },
  ingName: { ...typography.bodyStrong, marginBottom: spacing.xs2 },
  ingControls: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs2 },
  qtyInput: { width: 56, height: 32, borderRadius: 8, paddingHorizontal: 8, ...typography.caption },
  unitBtn: { height: 32, borderRadius: 8, paddingHorizontal: spacing.sm, alignItems: 'center', justifyContent: 'center' },
  unitText: { ...typography.caption, fontWeight: '700' },
  removeBtn: { padding: spacing.xs2 },
  stepBox: { borderRadius: radius.md, borderWidth: StyleSheet.hairlineWidth, padding: spacing.sm },
  stepHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.xs },
  stepIndex: { ...typography.h3 },
  stepDurRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: spacing.xs },
  stepDurLabel: { ...typography.caption },
  durInput: { width: 60, height: 32, borderRadius: 8, paddingHorizontal: 8, ...typography.caption },
  errorBox: { borderRadius: radius.md, borderWidth: 1, padding: spacing.md, marginBottom: spacing.md },
  errorTitle: { ...typography.bodyStrong, marginBottom: spacing.xs },
  errorMsg: { ...typography.caption, marginBottom: 2 },
  saveBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.edge, paddingVertical: spacing.sm, borderTopWidth: StyleSheet.hairlineWidth },
});
