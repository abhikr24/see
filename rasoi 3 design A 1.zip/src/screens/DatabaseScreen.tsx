import React, { useCallback, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { LATEST_SCHEMA_VERSION, MIGRATIONS } from '../data/db';
import { useI18n } from '../i18n';
import { useRecipes } from '../context/RecipeContext';
import { radius, shadow, spacing, typography, useTheme } from '../theme';
import { Button } from '../components/Button';
import { SectionHeader } from '../components/SectionHeader';
import { StatCard } from '../components/StatCard';
import { Loading } from '../components/SearchBar';
import { runAllTests, type RunResult } from '../tests';

export function DatabaseScreen() {
  const { colors } = useTheme();
  const { t } = useI18n();
  const { engine, stats, repo, ready, reseed, refresh } = useRecipes();
  const [running, setRunning] = useState(false);
  const [testResult, setTestResult] = useState<RunResult | null>(null);

  const handleRunTests = useCallback(async () => {
    setRunning(true);
    try {
      const result = await runAllTests();
      setTestResult(result);
    } finally {
      setRunning(false);
    }
  }, []);

  const handleReseed = useCallback(() => {
    Alert.alert(t('dataReseedConfirm'), t('dataReseedMsg'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('dataReseed'),
        onPress: async () => {
          await reseed();
          await refresh();
        },
      },
    ]);
  }, [reseed, refresh, t]);

  if (!ready) return <Loading />;

  const isMemory = engine === 'memory';
  const statusLabel = isMemory ? t('dataStatusWarn') : t('dataStatusOk');
  const statusColor = isMemory ? colors.warning : colors.success;

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={[styles.title, { color: colors.textPrimary }]}>{t('dataTitle')}</Text>

      {/* Engine + health */}
      <SectionHeader emoji="🗄️" title={t('dataHealth')} />
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, shadow(colors, 4, 0.08)]}>
        <Row label={t('dataStorage')} value={isMemory ? t('dataEngineMemory') : t('dataEngineSqlite')} icon="cube" />
        <Row label={t('dataVersion')} value={`v${LATEST_SCHEMA_VERSION}`} icon="git-branch" />
        <Row label={t('dataHealth')} value={statusLabel} valueColor={statusColor} icon="pulse" />
        {stats?.seededAt ? (
          <Row label={t('dataSeedApplied')} value={new Date(stats.seededAt).toLocaleDateString()} icon="calendar" />
        ) : null}
      </View>

      {/* Stats */}
      <SectionHeader emoji="📊" title={t('dataStats')} />
      <View style={styles.statsGrid}>
        <StatCard emoji="📖" value={stats?.recipeCount ?? 0} label={t('dataRecipeCount')} />
        <StatCard emoji="👤" value={stats?.userCount ?? 0} label={t('dataUserCount')} tint={colors.primarySoft} />
        <StatCard emoji="❤️" value={stats?.favoriteCount ?? 0} label={t('dataFavCount')} tint={colors.accentSoft} />
        <StatCard emoji="🥕" value={stats?.ingredientCount ?? 0} label={t('dataIngCount')} />
      </View>

      {/* Migrations */}
      <SectionHeader emoji="🧩" title={t('dataMigrations')} />
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        {MIGRATIONS.map((m) => (
          <View key={m.version} style={styles.migRow}>
            <View style={[styles.migBadge, { backgroundColor: colors.accentSoft }]}>
              <Text style={[styles.migBadgeText, { color: colors.accent }]}>v{m.version}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.migDesc, { color: colors.textPrimary }]}>{m.description}</Text>
              <Text style={[styles.migMeta, { color: colors.textMuted }]}>{m.statements.length} statements · applied</Text>
            </View>
            <Ionicons name="checkmark-circle" size={20} color={colors.success} />
          </View>
        ))}
      </View>

      {/* Tests */}
      <SectionHeader emoji="🧪" title={t('dataTests')} />
      <Button label={running ? t('loading') : t('dataRunTests')} onPress={handleRunTests} loading={running} icon="🧪" />
      {testResult ? (
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: testResult.failed ? colors.danger : colors.border }, shadow(colors, 3, 0.06), { marginTop: spacing.md }]}>
          <View style={styles.testSummary}>
            <Text style={[styles.testCount, { color: testResult.failed ? colors.danger : colors.success }]}>
              {t('dataTestsPassed', { passed: testResult.passed, total: testResult.total })}
            </Text>
            <Text style={[styles.testTime, { color: colors.textMuted }]}>{testResult.durationMs}ms</Text>
          </View>
          {testResult.results.filter((r) => !r.passed).slice(0, 8).map((r, i) => (
            <View key={i} style={styles.testFail}>
              <Ionicons name="close-circle" size={14} color={colors.danger} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.testFailName, { color: colors.textPrimary }]}>{r.suite} › {r.name}</Text>
                <Text style={[styles.testFailMsg, { color: colors.danger }]}>{r.error}</Text>
              </View>
            </View>
          ))}
          {testResult.failed === 0 ? (
            <Text style={[styles.testOk, { color: colors.success }]}>✓ {t('dataTestsOk')}</Text>
          ) : null}
        </View>
      ) : null}

      {/* Admin */}
      <SectionHeader emoji="♻️" title="Catalogue" />
      <Button label={t('dataReseed')} variant="secondary" onPress={handleReseed} icon="♻️" style={{ marginTop: spacing.xs }} />

      <View style={{ height: spacing.xxxl }} />
    </ScrollView>
  );
}

function Row({ label, value, icon, valueColor }: { label: string; value: string; icon: string; valueColor?: string }) {
  const { colors } = useTheme();
  return (
    <View style={styles.row}>
      <Ionicons name={icon as any} size={18} color={colors.textMuted} />
      <Text style={[styles.rowLabel, { color: colors.textSecondary }]}>{label}</Text>
      <Text style={[styles.rowValue, { color: valueColor ?? colors.textPrimary }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: spacing.edge, paddingBottom: spacing.xxxl },
  title: { ...typography.h1, paddingTop: spacing.lg, paddingBottom: spacing.sm },
  card: { borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth, padding: spacing.md, marginBottom: 0 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm, gap: spacing.sm },
  rowLabel: { ...typography.body, flex: 1 },
  rowValue: { ...typography.bodyStrong },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  migRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm, gap: spacing.sm },
  migBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  migBadgeText: { ...typography.micro, fontWeight: '800' },
  migDesc: { ...typography.bodyStrong },
  migMeta: { ...typography.micro, marginTop: 1 },
  testSummary: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.xs },
  testCount: { ...typography.h3 },
  testTime: { ...typography.caption },
  testFail: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.xs, paddingVertical: spacing.xs2 },
  testFailName: { ...typography.caption, fontWeight: '700' },
  testFailMsg: { ...typography.micro, marginTop: 1 },
  testOk: { ...typography.bodyStrong, marginTop: spacing.sm },
});
