import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import type { RecipeSummary } from '../data/recipes';
import { useI18n } from '../i18n';
import { usePantry } from '../context/PantryContext';
import { useRecipes } from '../context/RecipeContext';
import { useTheme } from '../theme';
import { radius, shadow, spacing, typography } from '../theme';
import { Button } from '../components/Button';
import { EmptyState } from '../components/EmptyState';
import { RecipeCard } from '../components/RecipeCard';
import { SectionHeader } from '../components/SectionHeader';
import { StatCard } from '../components/StatCard';
import type { TabScreenNav } from '../navigation/types';
import { useNavigation } from '@react-navigation/native';

export function HomeScreen() {
  const { colors, resolved, toggle } = useTheme();
  const { t, locale, setLocale } = useI18n();
  const { summaries, stats, repo, ready } = useRecipes();
  const { ids: pantryIds } = usePantry();
  const navigation = useNavigation<TabScreenNav<'Home'>>();
  const [matches, setMatches] = useState<RecipeSummary[]>([]);
  const [loadingMatches, setLoadingMatches] = useState(false);

  useEffect(() => {
    let cancelled = false;
    if (!repo || pantryIds.length === 0) {
      setMatches([]);
      return;
    }
    setLoadingMatches(true);
    repo
      .getByIngredients(pantryIds)
      .then((m) => {
        if (!cancelled) setMatches(m);
      })
      .finally(() => {
        if (!cancelled) setLoadingMatches(false);
      });
    return () => {
      cancelled = true;
    };
  }, [repo, pantryIds]);

  const featured = useMemo(
    () => [...summaries].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0)).slice(0, 6),
    [summaries],
  );

  const openRecipe = useCallback(
    (id: string) => navigation.navigate('RecipeDetail', { recipeId: id }),
    [navigation],
  );

  if (!ready) {
    return <View style={[styles.container, { backgroundColor: colors.background }]} />;
  }

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.greeting, { color: colors.textPrimary }]}>{t('homeGreeting')}</Text>
          <Text style={[styles.sub, { color: colors.textSecondary }]}>{t('homeSub')}</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable
            onPress={() => setLocale(locale === 'en' ? 'hi' : 'en')}
            style={({ pressed }) => [styles.iconBtn, { backgroundColor: colors.surfaceAlt }, pressed && { opacity: 0.6 }]}
          >
            <Text style={[styles.iconBtnText, { color: colors.textPrimary }]}>
              {locale === 'en' ? 'EN' : 'हि'}
            </Text>
          </Pressable>
          <Pressable
            onPress={toggle}
            style={({ pressed }) => [styles.iconBtn, { backgroundColor: colors.surfaceAlt }, pressed && { opacity: 0.6 }]}
          >
            <Ionicons name={resolved === 'dark' ? 'sunny' : 'moon'} size={18} color={colors.textPrimary} />
          </Pressable>
        </View>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <StatCard emoji="📖" value={stats?.recipeCount ?? 0} label={t('dataRecipeCount')} onPress={() => navigation.navigate('Recipes')} />
        <StatCard emoji="❤️" value={stats?.favoriteCount ?? 0} label={t('dataFavCount')} tint={colors.primarySoft} />
        <StatCard emoji="🧺" value={pantryIds.length} label={t('tabPantry')} tint={colors.accentSoft} />
      </View>

      {/* What can I cook */}
      <SectionHeader emoji="🍳" title={t('homeWhatCanICook')} />
      {pantryIds.length === 0 ? (
        <View style={[styles.promptCard, { backgroundColor: colors.surface }, shadow(colors, 4, 0.08)]}>
          <Text style={styles.promptEmoji}>🧺</Text>
          <Text style={[styles.promptTitle, { color: colors.textPrimary }]}>{t('homeWhatCanICookSub')}</Text>
          <Text style={[styles.promptText, { color: colors.textSecondary }]}>{t('homePantryEmpty')}</Text>
          <Button label={t('tabIngredients')} variant="secondary" onPress={() => navigation.navigate('Ingredients')} style={{ marginTop: spacing.md }} />
        </View>
      ) : loadingMatches ? (
        <Text style={[styles.loadingText, { color: colors.textMuted }]}>{t('loading')}</Text>
      ) : matches.length === 0 ? (
        <View style={[styles.promptCard, { backgroundColor: colors.surface }, shadow(colors, 4, 0.08)]}>
          <Text style={styles.promptEmoji}>🤔</Text>
          <Text style={[styles.promptText, { color: colors.textSecondary }]}>
            No recipes match your current pantry. Try adding more ingredients.
          </Text>
        </View>
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hScroll}>
          {matches.slice(0, 8).map((m) => (
            <View key={m.id} style={styles.hCard}>
              <RecipeCard recipe={m} onPress={() => openRecipe(m.id)} />
            </View>
          ))}
        </ScrollView>
      )}

      {/* Featured */}
      <SectionHeader emoji="⭐" title={t('homeFeatured')} actionLabel={t('viewAll')} onAction={() => navigation.navigate('Recipes')} />
      {featured.length === 0 ? (
        <EmptyState emoji="🍽️" title={t('empty')} />
      ) : (
        featured.map((r) => <RecipeCard key={r.id} recipe={r} onPress={() => openRecipe(r.id)} />)
      )}

      <View style={{ height: spacing.xxl }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingBottom: spacing.xxxl },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.edge,
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  greeting: { ...typography.h1 },
  sub: { ...typography.body, marginTop: 2 },
  headerActions: { flexDirection: 'row', gap: spacing.xs },
  iconBtn: {
    width: 38,
    height: 38,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBtnText: { ...typography.caption, fontWeight: '700' },
  statsRow: { flexDirection: 'row', gap: spacing.sm, paddingHorizontal: spacing.edge, marginTop: spacing.sm },
  promptCard: {
    marginHorizontal: spacing.edge,
    borderRadius: radius.lg,
    padding: spacing.lg,
    alignItems: 'center',
  },
  promptEmoji: { fontSize: 40, marginBottom: spacing.sm },
  promptTitle: { ...typography.h3, marginBottom: spacing.xs },
  promptText: { ...typography.body, textAlign: 'center', lineHeight: 21 },
  hScroll: { paddingHorizontal: spacing.edge, gap: spacing.md, paddingBottom: spacing.xs },
  hCard: { width: 240 },
  loadingText: { ...typography.body, paddingHorizontal: spacing.edge, paddingVertical: spacing.lg },
});
