import React, { useMemo, useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';
import { CATEGORY_META, CATEGORY_ORDER, INGREDIENT_CATALOGUE, searchIngredients } from '../data/ingredients';
import type { Ingredient, IngredientCategory } from '../data/ingredients';
import { useI18n } from '../i18n';
import { usePantry } from '../context/PantryContext';
import { spacing, typography, useTheme } from '../theme';
import { Button } from '../components/Button';
import { Chip } from '../components/Chip';
import { EmptyState } from '../components/EmptyState';
import { IngredientTile } from '../components/IngredientTile';
import { SearchBar } from '../components/SearchBar';
import type { TabScreenNav } from '../navigation/types';
import { useNavigation } from '@react-navigation/native';

const NUM_COLUMNS = 4;

export function IngredientsScreen() {
  const { colors } = useTheme();
  const { t } = useI18n();
  const { ids, toggle, has } = usePantry();
  const navigation = useNavigation<TabScreenNav<'Ingredients'>>();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<IngredientCategory | 'all'>('all');

  const results: Ingredient[] = useMemo(() => {
    if (query.trim()) {
      return searchIngredients(query, { category }).map((r) => r.ingredient);
    }
    return category === 'all'
      ? INGREDIENT_CATALOGUE
      : INGREDIENT_CATALOGUE.filter((i) => i.category === category);
  }, [query, category]);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={results}
        keyExtractor={(i) => i.id}
        numColumns={NUM_COLUMNS}
        contentContainerStyle={styles.list}
        columnWrapperStyle={styles.row}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={[styles.title, { color: colors.textPrimary }]}>{t('ingredientsTitle')}</Text>
            <View style={styles.searchWrap}>
              <SearchBar value={query} onChange={setQuery} placeholder={t('ingredientsSearch')} />
            </View>
            <View style={styles.chips}>
              <Chip label={t('ingredientsAll')} selected={category === 'all'} onPress={() => setCategory('all')} />
              {CATEGORY_ORDER.map((cat) => (
                <Chip
                  key={cat}
                  label={CATEGORY_META[cat].en}
                  icon={CATEGORY_META[cat].emoji}
                  selected={category === cat}
                  onPress={() => setCategory(cat)}
                />
              ))}
            </View>
          </View>
        }
        ListEmptyComponent={<EmptyState emoji="🔍" title="No ingredients found" />}
        renderItem={({ item }) => (
          <IngredientTile
            ingredient={item}
            selected={has(item.id)}
            onPress={() => toggle(item.id)}
          />
        )}
      />

      {ids.length > 0 ? (
        <View style={[styles.footer, { backgroundColor: colors.surface, borderTopColor: colors.border }]}>
          <Text style={[styles.footerText, { color: colors.textPrimary }]}>
            {t('ingredientsSelected', { n: ids.length })}
          </Text>
          <Button
            label={t('pantryFindRecipes')}
            onPress={() => navigation.navigate('Pantry')}
            style={styles.footerBtn}
          />
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { paddingHorizontal: spacing.edge, paddingBottom: spacing.xxxl },
  header: { paddingTop: spacing.lg },
  title: { ...typography.h1, marginBottom: spacing.md },
  searchWrap: {},
  chips: { flexDirection: 'row', flexWrap: 'wrap', paddingTop: spacing.sm, paddingBottom: spacing.sm },
  row: { marginBottom: spacing.xs, gap: spacing.xs },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.edge,
    paddingVertical: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  footerText: { ...typography.bodyStrong },
  footerBtn: { flex: 0, paddingHorizontal: spacing.lg, height: 42 },
});
