import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { CATEGORY_META, getIngredient } from '../data/ingredients';
import type { IngredientCategory } from '../data/ingredients';
import type { RecipeSummary } from '../data/recipes';
import { useI18n } from '../i18n';
import { usePantry } from '../context/PantryContext';
import { useRecipes } from '../context/RecipeContext';
import { spacing, typography, useTheme } from '../theme';
import { Button } from '../components/Button';
import { EmptyState } from '../components/EmptyState';
import { RecipeCard } from '../components/RecipeCard';
import { SectionHeader } from '../components/SectionHeader';
import type { TabScreenNav } from '../navigation/types';
import { useNavigation } from '@react-navigation/native';

export function PantryScreen() {
  const { colors } = useTheme();
  const { t } = useI18n();
  const { ids, remove, clear } = usePantry();
  const { repo } = useRecipes();
  const navigation = useNavigation<TabScreenNav<'Pantry'>>();
  const [matches, setMatches] = useState<RecipeSummary[]>([]);

  useEffect(() => {
    let cancelled = false;
    if (!repo || ids.length === 0) {
      setMatches([]);
      return;
    }
    repo.getByIngredients(ids).then((m) => !cancelled && setMatches(m));
    return () => {
      cancelled = true;
    };
  }, [repo, ids]);

  const openRecipe = useCallback(
    (id: string) => navigation.navigate('RecipeDetail', { recipeId: id }),
    [navigation],
  );

  // Group pantry ingredients by category.
  const grouped = ids.reduce<Record<string, string[]>>((acc, id) => {
    const ing = getIngredient(id);
    const cat = ing?.category ?? 'condiment';
    (acc[cat] ??= []).push(id);
    return acc;
  }, {});
  const groups = Object.keys(grouped) as IngredientCategory[];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={matches}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View>
            <View style={styles.header}>
              <Text style={[styles.title, { color: colors.textPrimary }]}>{t('pantryTitle')}</Text>
              {ids.length > 0 ? (
                <Pressable onPress={clear} hitSlop={8}>
                  <Text style={[styles.clear, { color: colors.danger }]}>{t('pantryClear')}</Text>
                </Pressable>
              ) : null}
            </View>

            {ids.length === 0 ? (
              <EmptyState
                emoji="🧺"
                title={t('pantryEmpty')}
                subtitle={t('pantryEmptySub')}
              />
            ) : (
              <View>
                <Text style={[styles.count, { color: colors.textSecondary }]}>
                  {t('pantryCount', { n: ids.length })}
                </Text>
                {groups.map((cat) => (
                  <View key={cat} style={styles.group}>
                    <Text style={[styles.groupTitle, { color: colors.textPrimary }]}>
                      {CATEGORY_META[cat].emoji}  {CATEGORY_META[cat].en}
                    </Text>
                    <View style={styles.chipRow}>
                      {grouped[cat].map((id) => {
                        const ing = getIngredient(id);
                        if (!ing) return null;
                        return (
                          <View
                            key={id}
                            style={[styles.chip, { backgroundColor: colors.surfaceAlt, borderColor: colors.border }]}
                          >
                            <Text style={styles.chipEmoji}>{ing.emoji}</Text>
                            <Text style={[styles.chipText, { color: colors.textPrimary }]}>{ing.name.en}</Text>
                            <Pressable onPress={() => remove(id)} hitSlop={6} style={styles.chipRemove}>
                              <Ionicons name="close" size={14} color={colors.textMuted} />
                            </Pressable>
                          </View>
                        );
                      })}
                    </View>
                  </View>
                ))}
              </View>
            )}

            {ids.length > 0 && (
              <View>
                <SectionHeader emoji="🍳" title={t('homeWhatCanICook')} />
                <Text style={[styles.sub, { color: colors.textSecondary }]}>
                  {t('recipesMatching', { n: matches.length })}
                </Text>
              </View>
            )}
          </View>
        }
        ListEmptyComponent={
          ids.length === 0 ? (
            <View style={styles.cta}>
              <Button label={t('tabIngredients')} onPress={() => navigation.navigate('Ingredients')} />
            </View>
          ) : matches.length === 0 ? (
            <EmptyState emoji="🤔" title="No matching recipes" subtitle="Add more ingredients to your pantry." />
          ) : null
        }
        renderItem={({ item }) => <RecipeCard recipe={item} onPress={() => openRecipe(item.id)} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { paddingHorizontal: spacing.edge, paddingBottom: spacing.xxxl },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  title: { ...typography.h1 },
  clear: { ...typography.caption, fontWeight: '700' },
  count: { ...typography.caption, marginBottom: spacing.md },
  group: { marginBottom: spacing.md },
  groupTitle: { ...typography.bodyStrong, marginBottom: spacing.xs },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs2,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
  },
  chipEmoji: { fontSize: 15, marginRight: 4 },
  chipText: { ...typography.caption },
  chipRemove: { marginLeft: 4, padding: 2 },
  sub: { ...typography.caption, paddingHorizontal: 0, marginTop: -4, marginBottom: spacing.sm },
  cta: { paddingTop: spacing.md },
});
