import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { getIngredient } from '../data/ingredients';
import type { Recipe } from '../data/recipes';
import { formatMinutes } from '../lib/format';
import { useI18n } from '../i18n';
import { usePantry } from '../context/PantryContext';
import { useRecipes } from '../context/RecipeContext';
import { radius, shadow, spacing, typography, useTheme } from '../theme';
import { Button } from '../components/Button';
import { Loading } from '../components/SearchBar';
import { SectionHeader } from '../components/SectionHeader';
import { CATEGORY_EMOJI, DIFFICULTY_META, formatQuantity } from '../components/recipeMeta';
import type { StackScreenNav } from '../navigation/types';
import { useNavigation, useRoute, type RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '../navigation/types';

export function RecipeDetailScreen() {
  const { colors } = useTheme();
  const { t, L } = useI18n();
  const { repo, refresh } = useRecipes();
  const { has } = usePantry();
  const navigation = useNavigation<StackScreenNav<'RecipeDetail'>>();
  const route = useRoute<RouteProp<RootStackParamList, 'RecipeDetail'>>();
  const recipeId = route.params.recipeId;
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);
  const [favBusy, setFavBusy] = useState(false);

  const load = useCallback(async () => {
    if (!repo) return;
    try {
      const r = await repo.getById(recipeId);
      setRecipe(r);
    } finally {
      setLoading(false);
    }
  }, [repo, recipeId]);

  useEffect(() => {
    load();
  }, [load]);

  const toggleFavorite = useCallback(async () => {
    if (!repo || !recipe) return;
    setFavBusy(true);
    try {
      await repo.setFavorite(recipe.id, !recipe.isFavorite);
      setRecipe({ ...recipe, isFavorite: !recipe.isFavorite });
      refresh();
    } finally {
      setFavBusy(false);
    }
  }, [repo, recipe, refresh]);

  const handleDelete = useCallback(() => {
    if (!repo || !recipe) return;
    Alert.alert(t('detailDeleteConfirm'), t('detailDeleteMsg'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('delete'),
        style: 'destructive',
        onPress: async () => {
          await repo.remove(recipe.id);
          await refresh();
          navigation.goBack();
        },
      },
    ]);
  }, [repo, recipe, refresh, navigation, t]);

  if (loading) return <Loading />;
  if (!recipe) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={[{ color: colors.textSecondary }]}>{t('empty')}</Text>
      </View>
    );
  }

  const diff = DIFFICULTY_META[recipe.difficulty];
  const isUser = recipe.source === 'user';

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: recipe.accentColor }]}>
        <View style={styles.headerTop}>
          <View style={[styles.sourceBadge, { backgroundColor: 'rgba(0,0,0,0.25)' }]}>
            <Text style={styles.sourceText}>
              {isUser ? t('detailUserRecipe') : t('detailCatalogueRecipe')}
            </Text>
          </View>
          <Pressable onPress={toggleFavorite} disabled={favBusy} style={styles.favBtn}>
            <Ionicons name={recipe.isFavorite ? 'heart' : 'heart-outline'} size={26} color="#fff" />
          </Pressable>
        </View>
        <Text style={styles.headerEmoji}>{CATEGORY_EMOJI[recipe.category]}</Text>
        <Text style={styles.title}>{recipe.titleLocalized ? L(recipe.titleLocalized) : recipe.title}</Text>
        <Text style={styles.subtitle}>{recipe.cuisine} · {t(recipe.difficulty)} · {recipe.servings} {t(recipe.servings === 1 ? 'serving' : 'servings')}</Text>
      </View>

      {/* Meta grid */}
      <View style={styles.metaGrid}>
        <MetaCell label={t('prepTime')} value={formatMinutes(recipe.prepTimeMin)} />
        <MetaCell label={t('cookTime')} value={formatMinutes(recipe.cookTimeMin)} />
        <MetaCell label={t('totalTime')} value={formatMinutes(recipe.totalTimeMin)} />
        <MetaCell label={t('calories')} value={recipe.caloriesPerServing ? `${recipe.caloriesPerServing}` : '—'} />
      </View>

      {/* Description */}
      <Text style={[styles.description, { color: colors.textSecondary }]}>{recipe.description}</Text>

      {/* Ingredients */}
      <SectionHeader emoji="🥕" title={t('ingredients')} />
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, shadow(colors, 3, 0.06)]}>
        {recipe.ingredients.map((ri, idx) => {
          const ing = getIngredient(ri.ingredientId);
          const inPantry = has(ri.ingredientId);
          return (
            <View
              key={ri.ingredientId + idx}
              style={[styles.ingRow, idx > 0 && { borderTopColor: colors.divider, borderTopWidth: StyleSheet.hairlineWidth }]}
            >
              <Text style={styles.ingEmoji}>{ing?.emoji ?? '•'}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.ingName, { color: colors.textPrimary }]}>
                  {ing ? L(ing.name) : ri.ingredientId}
                </Text>
                {ri.note ? <Text style={[styles.ingNote, { color: colors.textMuted }]}>{ri.note}</Text> : null}
              </View>
              {inPantry ? (
                <View style={[styles.pantryTag, { backgroundColor: colors.accentSoft }]}>
                  <Ionicons name="checkmark-circle" size={13} color={colors.accent} />
                  <Text style={[styles.pantryTagText, { color: colors.accent }]}>{t('ingredientsInPantry')}</Text>
                </View>
              ) : null}
              <Text style={[styles.ingQty, { color: colors.textSecondary }]}>{formatQuantity(ri.quantity, ri.unit)}</Text>
            </View>
          );
        })}
      </View>

      {/* Steps */}
      <SectionHeader emoji="👨‍🍳" title={t('steps')} />
      <View style={styles.steps}>
        {recipe.steps.map((s) => (
          <View key={s.stepNumber} style={styles.stepRow}>
            <View style={[styles.stepNum, { backgroundColor: recipe.accentColor }]}>
              <Text style={styles.stepNumText}>{s.stepNumber}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.stepText, { color: colors.textPrimary }]}>{s.instruction}</Text>
              {s.durationMin ? (
                <Text style={[styles.stepDur, { color: colors.textMuted }]}>
                  <Ionicons name="time-outline" size={12} /> {formatMinutes(s.durationMin)}
                </Text>
              ) : null}
            </View>
          </View>
        ))}
      </View>

      {/* Nutrition */}
      {recipe.nutrition ? (
        <>
          <SectionHeader emoji="📊" title={t('nutrition')} />
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, shadow(colors, 3, 0.06)]}>
            <View style={styles.nutGrid}>
              <NutCell label={t('calories')} value={`${recipe.nutrition.calories}`} unit="kcal" color={colors.primary} />
              <NutCell label={t('protein')} value={`${recipe.nutrition.proteinG}`} unit="g" color={colors.accent} />
              <NutCell label={t('carbs')} value={`${recipe.nutrition.carbsG}`} unit="g" color="#E2A93B" />
              <NutCell label={t('fat')} value={`${recipe.nutrition.fatG}`} unit="g" color="#C0392B" />
            </View>
            <Text style={[styles.nutPer, { color: colors.textMuted }]}>{t('perServing')}</Text>
          </View>
        </>
      ) : null}

      {/* Tags */}
      {recipe.tags.length > 0 ? (
        <View style={styles.tags}>
          {recipe.tags.map((tag) => (
            <View key={tag} style={[styles.tag, { backgroundColor: colors.surfaceAlt }]}>
              <Text style={[styles.tagText, { color: colors.textSecondary }]}>#{tag}</Text>
            </View>
          ))}
        </View>
      ) : null}

      {/* Owner actions */}
      {isUser ? (
        <View style={styles.ownerActions}>
          <Button label={t('edit')} variant="secondary" icon="✏️" onPress={() => navigation.navigate('AddRecipe', { recipeId: recipe.id })} />
          <Button label={t('delete')} variant="danger" icon="🗑️" onPress={handleDelete} />
        </View>
      ) : null}

      <View style={{ height: spacing.xxxl }} />
    </ScrollView>
  );
}

function MetaCell({ label, value }: { label: string; value: string }) {
  const { colors } = useTheme();
  return (
    <View style={metaStyles.cell}>
      <Text style={[metaStyles.value, { color: colors.textPrimary }]}>{value}</Text>
      <Text style={[metaStyles.label, { color: colors.textMuted }]}>{label}</Text>
    </View>
  );
}

function NutCell({ label, value, unit, color }: { label: string; value: string; unit: string; color: string }) {
  const { colors } = useTheme();
  return (
    <View style={nutStyles.cell}>
      <Text style={[nutStyles.value, { color }]}>{value}{unit}</Text>
      <Text style={[nutStyles.label, { color: colors.textMuted }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { padding: spacing.lg, paddingTop: spacing.xl, borderBottomLeftRadius: radius.xl, borderBottomRightRadius: radius.xl },
  headerTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sourceBadge: { borderRadius: 999, paddingHorizontal: spacing.sm, paddingVertical: 3, alignSelf: 'flex-start' },
  sourceText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  favBtn: { padding: spacing.xs },
  headerEmoji: { fontSize: 46, textAlign: 'center', marginVertical: spacing.sm },
  title: { ...typography.h1, color: '#fff', textAlign: 'center' },
  subtitle: { ...typography.caption, color: 'rgba(255,255,255,0.9)', textAlign: 'center', marginTop: 4, textTransform: 'capitalize' },
  metaGrid: { flexDirection: 'row', paddingHorizontal: spacing.edge, paddingTop: spacing.lg },
  description: { ...typography.body, paddingHorizontal: spacing.edge, paddingTop: spacing.md, lineHeight: 22 },
  card: { marginHorizontal: spacing.edge, borderRadius: radius.lg, borderWidth: StyleSheet.hairlineWidth, overflow: 'hidden' },
  ingRow: { flexDirection: 'row', alignItems: 'center', padding: spacing.md, gap: spacing.sm },
  ingEmoji: { fontSize: 22, marginRight: spacing.sm },
  ingName: { ...typography.bodyStrong },
  ingNote: { ...typography.micro, marginTop: 1 },
  pantryTag: { flexDirection: 'row', alignItems: 'center', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 3, marginRight: spacing.sm },
  pantryTagText: { fontSize: 10, fontWeight: '700', marginLeft: 3 },
  ingQty: { ...typography.caption, fontWeight: '700', minWidth: 70, textAlign: 'right' },
  steps: { paddingHorizontal: spacing.edge },
  stepRow: { flexDirection: 'row', marginBottom: spacing.md, gap: spacing.sm },
  stepNum: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  stepNumText: { color: '#fff', fontWeight: '800', fontSize: 14 },
  stepText: { ...typography.body, lineHeight: 22 },
  stepDur: { ...typography.micro, marginTop: 4 },
  nutGrid: { flexDirection: 'row', padding: spacing.md },
  nutPer: { ...typography.micro, textAlign: 'center', paddingBottom: spacing.md },
  tags: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: spacing.edge, paddingTop: spacing.lg, gap: spacing.xs },
  tag: { borderRadius: 999, paddingHorizontal: spacing.sm, paddingVertical: 4 },
  tagText: { ...typography.micro },
  ownerActions: { flexDirection: 'row', gap: spacing.sm, paddingHorizontal: spacing.edge, paddingTop: spacing.xl },
});

const metaStyles = StyleSheet.create({
  cell: { flex: 1, alignItems: 'center' },
  value: { ...typography.h3 },
  label: { ...typography.micro, marginTop: 2 },
});

const nutStyles = StyleSheet.create({
  cell: { flex: 1, alignItems: 'center' },
  value: { ...typography.h2 },
  label: { ...typography.micro, marginTop: 2 },
});
