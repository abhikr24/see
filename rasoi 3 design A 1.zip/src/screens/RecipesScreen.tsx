import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import type { RecipeCategory, RecipeSummary } from '../data/recipes';
import { useI18n } from '../i18n';
import { useRecipes } from '../context/RecipeContext';
import { spacing, typography, useTheme } from '../theme';
import { Chip } from '../components/Chip';
import { EmptyState } from '../components/EmptyState';
import { Loading } from '../components/SearchBar';
import { RecipeCard } from '../components/RecipeCard';
import { SearchBar } from '../components/SearchBar';
import type { TabScreenNav } from '../navigation/types';
import { useNavigation } from '@react-navigation/native';

const CATEGORIES: (RecipeCategory | 'all')[] = [
  'all', 'breakfast', 'lunch', 'dinner', 'snack', 'dessert', 'beverage', 'side',
];

const CATEGORY_LABELS: Record<RecipeCategory | 'all', string> = {
  all: 'All',
  breakfast: 'Breakfast',
  lunch: 'Lunch',
  dinner: 'Dinner',
  snack: 'Snack',
  dessert: 'Dessert',
  beverage: 'Beverage',
  side: 'Side',
};

export function RecipesScreen() {
  const { colors } = useTheme();
  const { t } = useI18n();
  const { summaries, repo, ready, refresh } = useRecipes();
  const navigation = useNavigation<TabScreenNav<'Recipes'>>();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<RecipeCategory | 'all'>('all');
  const [results, setResults] = useState<RecipeSummary[]>(summaries);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    setResults(summaries);
  }, [summaries]);

  useEffect(() => {
    if (!repo) return;
    let cancelled = false;
    setSearching(true);
    repo
      .search({ query: query.trim() || undefined, category, sort: 'relevance' })
      .then((r) => {
        if (!cancelled) setResults(r);
      })
      .finally(() => {
        if (!cancelled) setSearching(false);
      });
    return () => {
      cancelled = true;
    };
  }, [repo, query, category]);

  const openRecipe = useCallback(
    (id: string) => navigation.navigate('RecipeDetail', { recipeId: id }),
    [navigation],
  );

  if (!ready) return <Loading />;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.background }]}>
        <View style={styles.titleRow}>
          <Text style={[styles.title, { color: colors.textPrimary }]}>{t('recipesTitle')}</Text>
          <Pressable
            onPress={() => navigation.navigate('AddRecipe', {})}
            style={({ pressed }) => [
              styles.addBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.8 },
            ]}
          >
            <Ionicons name="add" size={22} color="#fff" />
          </Pressable>
        </View>
        <View style={styles.searchWrap}>
          <SearchBar value={query} onChange={setQuery} placeholder={t('recipesSearch')} />
        </View>
        <View style={styles.chips}>
          {CATEGORIES.map((cat) => (
            <Chip
              key={cat}
              label={CATEGORY_LABELS[cat]}
              selected={category === cat}
              onPress={() => setCategory(cat)}
            />
          ))}
        </View>
      </View>

      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        onRefresh={refresh}
        refreshing={searching}
        ListEmptyComponent={
          searching ? null : (
            <EmptyState emoji="🔍" title={t('recipesNoResults')} subtitle={t('recipesSearch')} />
          )
        }
        renderItem={({ item }) => <RecipeCard recipe={item} onPress={() => openRecipe(item.id)} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: spacing.edge,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xs,
  },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { ...typography.h1 },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchWrap: { marginTop: spacing.md },
  chips: { flexDirection: 'row', flexWrap: 'wrap', paddingTop: spacing.sm, paddingBottom: spacing.xs },
  list: { paddingHorizontal: spacing.edge, paddingTop: spacing.sm, paddingBottom: spacing.xxxl },
});
