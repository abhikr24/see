// Minimal test harness — no external deps. Runs identically in-app (Data screen)
// and in Node (via tsx). Supports describe/it/expect with async tests.

type TestFn = () => void | Promise<void>;

interface TestCase {
  name: string;
  fn: TestFn;
}
interface Suite {
  name: string;
  tests: TestCase[];
}

const suites: Suite[] = [];
let currentSuite: Suite | null = null;

export function describe(name: string, fn: () => void): void {
  const suite: Suite = { name, tests: [] };
  currentSuite = suite;
  try {
    fn();
  } finally {
    currentSuite = null;
  }
  suites.push(suite);
}

export function it(name: string, fn: TestFn): void {
  if (!currentSuite) throw new Error(`it("${name}") called outside describe()`);
  currentSuite.tests.push({ name, fn });
}

function fmt(v: unknown): string {
  try {
    return typeof v === 'string' ? v : JSON.stringify(v);
  } catch {
    return String(v);
  }
}

export function expect<T>(actual: T) {
  return {
    toBe(expected: T) {
      if (actual !== expected) {
        throw new Error(`expected ${fmt(actual)} to be ${fmt(expected)}`);
      }
    },
    toEqual(expected: unknown) {
      if (JSON.stringify(actual) !== JSON.stringify(expected)) {
        throw new Error(`expected ${fmt(actual)} to equal ${fmt(expected)}`);
      }
    },
    toBeTruthy() {
      if (!actual) throw new Error(`expected truthy, got ${fmt(actual)}`);
    },
    toBeFalsy() {
      if (actual) throw new Error(`expected falsy, got ${fmt(actual)}`);
    },
    toBeNull() {
      if (actual !== null) throw new Error(`expected null, got ${fmt(actual)}`);
    },
    toBeGreaterThan(n: number) {
      if (!(Number(actual) > n)) throw new Error(`expected ${fmt(actual)} > ${n}`);
      return this;
    },
    toHaveLength(n: number) {
      const len = (actual as { length?: number })?.length;
      if (len !== n) throw new Error(`expected length ${n}, got ${len}`);
    },
    toContain(item: unknown) {
      if (!Array.isArray(actual) || !actual.includes(item)) {
        throw new Error(`expected ${fmt(actual)} to contain ${fmt(item)}`);
      }
    },
    async toResolveTo(expected: T) {
      const resolved = await (actual as Promise<T>);
      if (JSON.stringify(resolved) !== JSON.stringify(expected)) {
        throw new Error(`expected promise to resolve to ${fmt(expected)}, got ${fmt(resolved)}`);
      }
    },
  };
}

export function expectToThrow(fn: () => unknown, msgContains?: string) {
  let threw = false;
  let err: unknown;
  try {
    fn();
  } catch (e) {
    threw = true;
    err = e;
  }
  if (!threw) throw new Error('expected function to throw');
  if (msgContains) {
    const m = err instanceof Error ? err.message : String(err);
    if (!m.includes(msgContains)) throw new Error(`expected error to include "${msgContains}", got "${m}"`);
  }
}

export interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
}

export interface RunResult {
  results: TestResult[];
  passed: number;
  failed: number;
  total: number;
  durationMs: number;
}

export async function runAllSuites(): Promise<RunResult> {
  const results: TestResult[] = [];
  const start = Date.now();
  for (const suite of suites) {
    for (const tc of suite.tests) {
      try {
        await tc.fn();
        results.push({ suite: suite.name, name: tc.name, passed: true });
      } catch (e) {
        results.push({
          suite: suite.name,
          name: tc.name,
          passed: false,
          error: e instanceof Error ? e.message : String(e),
        });
      }
    }
  }
  const passed = results.filter((r) => r.passed).length;
  return {
    results,
    passed,
    failed: results.length - passed,
    total: results.length,
    durationMs: Date.now() - start,
  };
}

/** Suites register themselves on import via side-effect. */
export function registerSuites(modules: (() => void)[]): void {
  for (const m of modules) m();
}
