import { runAllSuites } from './harness';
import type { RunResult, TestResult } from './harness';
import { validationSuite, seedDataSuite } from './validation.test';
import { repositorySuite, importerSuite } from './repository.test';

// Suites register via side-effect; guard so re-runs don't duplicate.
let registered = false;
function ensureRegistered(): void {
  if (registered) return;
  validationSuite();
  seedDataSuite();
  repositorySuite();
  importerSuite();
  registered = true;
}

/** Run the full suite. Usable in-app (Data screen) and in Node. */
export async function runAllTests(): Promise<RunResult> {
  ensureRegistered();
  return runAllSuites();
}

export type { RunResult, TestResult };
