import { describe, it, expect } from './harness';
import { MemoryRecipeRepository } from '../data/db/recipeRepository.memory';
import { SEED_RECIPES } from '../data/recipes/seedRecipes';
import { importRecipes } from '../data/recipes/importer';
import type { RecipeInput } from '../data/recipes/types';

async function freshRepo(): Promise<MemoryRecipeRepository> {
  const repo = new MemoryRecipeRepository();
  await repo.init();
  return repo;
}

function userRecipe(id = 'rcp_user_test'): RecipeInput {
  return {
    id,
    title: 'My Test Bowl',
    description: 'A user-created recipe.',
    cuisine: 'asian',
    category: 'lunch',
    difficulty: 'easy',
    servings: 2,
    prepTimeMin: 5,
    cookTimeMin: 15,
    source: 'user',
    tags: ['test', 'user'],
    ingredients: [
      { ingredientId: 'ing_rice', quantity: 1, unit: 'cup' },
      { ingredientId: 'ing_egg', quantity: 2, unit: 'piece' },
      { ingredientId: 'ing_soy_sauce', quantity: 1, unit: 'tbsp' },
    ],
    steps: [
      { instruction: 'Cook rice.', durationMin: 15 },
      { instruction: 'Fry egg and combine.', durationMin: 5 },
    ],
    nutrition: { calories: 420, proteinG: 14, carbsG: 60, fatG: 12 },
  };
}

export function repositorySuite() {
  describe('Memory recipe repository', () => {
    it('seeds the catalogue on init', async () => {
      const repo = await freshRepo();
      const stats = await repo.stats();
      expect(stats.catalogueCount).toBe(SEED_RECIPES.length);
      expect(stats.engine).toBe('memory');
      expect(stats.recipeCount).toBeGreaterThan(0);
    });

    it('list() returns summaries for the catalogue', async () => {
      const repo = await freshRepo();
      const list = await repo.list();
      expect(list.length).toBe(SEED_RECIPES.length);
      for (const s of list) {
        expect(s.ingredientCount).toBeGreaterThan(0);
      }
    });

    it('getById() returns a fully hydrated recipe', async () => {
      const repo = await freshRepo();
      const r = await repo.getById('rcp_dal_tadka');
      expect(r).toBeTruthy();
      expect(r?.ingredients.length).toBeGreaterThan(0);
      expect(r?.steps.length).toBeGreaterThan(0);
      expect(r?.source).toBe('catalogue');
    });

    it('getById() returns null for unknown id', async () => {
      const repo = await freshRepo();
      const r = await repo.getById('nope');
      expect(r).toBeNull();
    });

    it('search() filters by query', async () => {
      const repo = await freshRepo();
      const res = await repo.search({ query: 'paneer' });
      expect(res.length).toBeGreaterThan(0);
      for (const r of res) {
        expect(r.title.toLowerCase().includes('paneer') || r.cuisine.includes('paneer')).toBe(true);
      }
    });

    it('search() filters by category', async () => {
      const repo = await freshRepo();
      const res = await repo.search({ category: 'beverage' });
      expect(res.length).toBeGreaterThan(0);
      for (const r of res) {
        expect(r.category === 'beverage').toBe(true);
      }
    });

    it('upsert() adds a user recipe', async () => {
      const repo = await freshRepo();
      const id = await repo.upsert(userRecipe());
      expect(id).toBe('rcp_user_test');
      const r = await repo.getById(id);
      expect(r?.source).toBe('user');
      const list = await repo.list();
      expect(list.length).toBe(SEED_RECIPES.length + 1);
    });

    it('upsert() throws on invalid input', async () => {
      const repo = await freshRepo();
      const bad = userRecipe();
      bad.title = '';
      let threw = false;
      try {
        await repo.upsert(bad);
      } catch {
        threw = true;
      }
      expect(threw).toBe(true);
    });

    it('upsert() updates an existing recipe (idempotent)', async () => {
      const repo = await freshRepo();
      await repo.upsert(userRecipe());
      const updated = userRecipe();
      updated.title = 'Renamed Bowl';
      await repo.upsert(updated);
      const r = await repo.getById('rcp_user_test');
      expect(r?.title).toBe('Renamed Bowl');
      const list = await repo.list();
      expect(list.length).toBe(SEED_RECIPES.length + 1);
    });

    it('setFavorite() + getFavorites() work', async () => {
      const repo = await freshRepo();
      await repo.setFavorite('rcp_dal_tadka', true);
      const favs = await repo.getFavorites();
      expect(favs.length).toBe(1);
      const list = await repo.list();
      const dal = list.find((r) => r.id === 'rcp_dal_tadka');
      expect(dal?.isFavorite).toBe(true);
      await repo.setFavorite('rcp_dal_tadka', false);
      expect((await repo.getFavorites()).length).toBe(0);
    });

    it('getByIngredients() ranks by pantry coverage', async () => {
      const repo = await freshRepo();
      const matches = await repo.getByIngredients(['ing_red_lentils', 'ing_tomato', 'ing_ghee']);
      expect(matches.length).toBeGreaterThan(0);
      const dal = matches.find((m) => m.id === 'rcp_dal_tadka');
      expect(dal).toBeTruthy();
      expect(dal?.pantryMatch).toBeGreaterThan(0);
    });

    it('getByIngredients() returns [] for empty pantry', async () => {
      const repo = await freshRepo();
      const matches = await repo.getByIngredients([]);
      expect(matches.length).toBe(0);
    });

    it('remove() deletes a recipe', async () => {
      const repo = await freshRepo();
      await repo.upsert(userRecipe());
      await repo.remove('rcp_user_test');
      expect(await repo.getById('rcp_user_test')).toBeNull();
    });

    it('reseedCatalogue() preserves user recipes', async () => {
      const repo = await freshRepo();
      await repo.upsert(userRecipe());
      await repo.reseedCatalogue();
      expect(await repo.getById('rcp_user_test')).toBeTruthy();
      const stats = await repo.stats();
      expect(stats.userCount).toBe(1);
      expect(stats.catalogueCount).toBe(SEED_RECIPES.length);
    });

    it('isSeeded() is true after init', async () => {
      const repo = await freshRepo();
      expect(await repo.isSeeded()).toBe(true);
    });
  });
}

export function importerSuite() {
  describe('Data ingestion (importer)', () => {
    it('inserts a valid batch', async () => {
      const repo = await freshRepo();
      const before = await repo.count();
      const result = await importRecipes(repo, [userRecipe('rcp_imp_1'), userRecipe('rcp_imp_2')]);
      expect(result.inserted).toBe(2);
      expect(result.skipped).toBe(0);
      expect(await repo.count()).toBe(before + 2);
    });

    it('skips invalid candidates and reports errors', async () => {
      const repo = await freshRepo();
      const bad = userRecipe('rcp_imp_bad');
      bad.ingredients[0].ingredientId = 'ing_nope';
      const result = await importRecipes(repo, [bad]);
      expect(result.skipped).toBe(1);
      expect(result.errors.length).toBe(1);
    });

    it('is idempotent (re-import updates, not duplicates)', async () => {
      const repo = await freshRepo();
      await importRecipes(repo, [userRecipe('rcp_imp_idem')]);
      const r2 = await importRecipes(repo, [userRecipe('rcp_imp_idem')]);
      expect(r2.inserted).toBe(0);
      expect(r2.updated).toBe(1);
      const list = await repo.list();
      expect(list.filter((r) => r.id === 'rcp_imp_idem').length).toBe(1);
    });

    it('seeds the full catalogue via the importer', async () => {
      const repo = await freshRepo();
      for (const s of SEED_RECIPES) {
        await repo.remove(s.id as string);
      }
      const result = await importRecipes(repo, SEED_RECIPES);
      expect(result.inserted).toBe(SEED_RECIPES.length);
    });
  });
}
