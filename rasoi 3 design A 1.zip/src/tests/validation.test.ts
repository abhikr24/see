import { describe, it, expect } from './harness';
import { SEED_RECIPES } from '../data/recipes/seedRecipes';
import { ingredientExists } from '../data/ingredients';
import { validateRecipe, deriveTotalTime, VALID_CATEGORIES } from '../data/recipes/validation';
import type { RecipeInput } from '../data/recipes/types';

function validBase(): RecipeInput {
  return {
    title: 'Test Curry',
    description: 'A test recipe.',
    cuisine: 'indian',
    category: 'dinner',
    difficulty: 'easy',
    servings: 4,
    prepTimeMin: 10,
    cookTimeMin: 20,
    source: 'user',
    tags: ['test'],
    ingredients: [
      { ingredientId: 'ing_tomato', quantity: 2, unit: 'piece' },
      { ingredientId: 'ing_onion', quantity: 1, unit: 'piece' },
    ],
    steps: [{ instruction: 'Cook it.', durationMin: 10 }],
  };
}

export function validationSuite() {
  describe('Recipe validation', () => {
    it('accepts a well-formed recipe', () => {
      expect(validateRecipe(validBase()).valid).toBe(true);
    });

    it('accepts every seed recipe', () => {
      for (const r of SEED_RECIPES) {
        const res = validateRecipe(r);
        if (!res.valid) {
          throw new Error(`${r.id}: ${res.errors[0].field} — ${res.errors[0].message}`);
        }
      }
    });

    it('rejects a missing title', () => {
      const r = validBase();
      r.title = '  ';
      expect(validateRecipe(r).valid).toBe(false);
    });

    it('rejects an invalid category', () => {
      const r = validBase();
      (r as unknown as { category: string }).category = 'brunch';
      expect(validateRecipe(r).valid).toBe(false);
    });

    it('rejects an unknown ingredient id', () => {
      const r = validBase();
      r.ingredients[0].ingredientId = 'ing_does_not_exist';
      const res = validateRecipe(r);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.field.startsWith('ingredients'))).toBe(true);
    });

    it('rejects a duplicate ingredient', () => {
      const r = validBase();
      r.ingredients.push({ ingredientId: 'ing_tomato', quantity: 1, unit: 'piece' });
      expect(validateRecipe(r).valid).toBe(false);
    });

    it('rejects empty steps', () => {
      const r = validBase();
      r.steps = [];
      expect(validateRecipe(r).valid).toBe(false);
    });

    it('rejects non-positive servings', () => {
      const r = validBase();
      r.servings = 0;
      expect(validateRecipe(r).valid).toBe(false);
    });

    it('allows quantity 0 only for to_taste unit', () => {
      const r = validBase();
      r.ingredients = [{ ingredientId: 'ing_salt', quantity: 0, unit: 'to_taste' }];
      expect(validateRecipe(r).valid).toBe(true);
    });

    it('rejects a bad rating', () => {
      const r = validBase();
      r.rating = 6;
      expect(validateRecipe(r).valid).toBe(false);
    });

    it('derivesTotalTime sums prep + cook', () => {
      expect(deriveTotalTime(10, 25)).toBe(35);
      expect(deriveTotalTime(0, 0)).toBe(0);
    });

    it('VALID_CATEGORIES is non-empty', () => {
      expect(VALID_CATEGORIES.length).toBeGreaterThan(0);
    });
  });
}

export function seedDataSuite() {
  describe('Seed data integrity', () => {
    it('has a non-empty catalogue', () => {
      expect(SEED_RECIPES.length).toBeGreaterThan(10);
    });

    it('has unique recipe ids', () => {
      const ids = SEED_RECIPES.map((r) => r.id);
      expect(new Set(ids).size).toBe(ids.length);
    });

    it('every seed ingredient id exists in the catalogue', () => {
      for (const r of SEED_RECIPES) {
        for (const ri of r.ingredients) {
          if (!ingredientExists(ri.ingredientId)) {
            throw new Error(`${r.id} references unknown ingredient ${ri.ingredientId}`);
          }
        }
      }
    });

    it('every seed recipe has at least one step', () => {
      for (const r of SEED_RECIPES) {
        expect(r.steps.length).toBeGreaterThan(0);
      }
    });

    it('reports invalid when cuisine is missing', () => {
      const r = validBase();
      r.cuisine = '';
      expect(validateRecipe(r).valid).toBe(false);
    });
  });
}
