import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useColorScheme, type ViewStyle } from 'react-native';
import { loadJSON, saveJSON } from '../lib/storage';

export type ThemeMode = 'light' | 'dark' | 'system';

export interface Palette {
  background: string;
  surface: string;
  surfaceAlt: string;
  surfaceElevated: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  textInverse: string;
  primary: string;
  primaryDark: string;
  primarySoft: string;
  accent: string;
  accentSoft: string;
  danger: string;
  warning: string;
  success: string;
  border: string;
  divider: string;
  overlay: string;
  shadowRgb: string;
  tabBar: string;
  tabBarInactive: string;
}

export const lightPalette: Palette = {
  background: '#FBF7F0',
  surface: '#FFFFFF',
  surfaceAlt: '#F4ECE0',
  surfaceElevated: '#FFFFFF',
  textPrimary: '#2A2118',
  textSecondary: '#6B5D4F',
  textMuted: '#9C8D7C',
  textInverse: '#FBF7F0',
  primary: '#E07A1F',
  primaryDark: '#B85F12',
  primarySoft: '#FBE6D1',
  accent: '#2E7D5B',
  accentSoft: '#DCEFE3',
  danger: '#C0392B',
  warning: '#E2A93B',
  success: '#2E7D5B',
  border: '#E8DDCC',
  divider: '#EFE6D7',
  overlay: 'rgba(42,33,24,0.45)',
  shadowRgb: '42,33,24',
  tabBar: '#FFFFFF',
  tabBarInactive: '#9C8D7C',
};

export const darkPalette: Palette = {
  background: '#15110E',
  surface: '#221C17',
  surfaceAlt: '#2B231D',
  surfaceElevated: '#2F2620',
  textPrimary: '#F5EFE6',
  textSecondary: '#C9BCAB',
  textMuted: '#8A7C6D',
  textInverse: '#15110E',
  primary: '#F2A23C',
  primaryDark: '#E07A1F',
  primarySoft: '#3A2A18',
  accent: '#4CAE7E',
  accentSoft: '#1E3329',
  danger: '#E55A4A',
  warning: '#F0B94A',
  success: '#4CAE7E',
  border: '#3A3128',
  divider: '#322A23',
  overlay: 'rgba(0,0,0,0.6)',
  shadowRgb: '0,0,0',
  tabBar: '#1C1713',
  tabBarInactive: '#7A6D5E',
};

export const spacing = {
  xs4: 2,
  xs3: 4,
  xs2: 6,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 40,
  edge: 16,
} as const;

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  pill: 999,
} as const;

export const typography = {
  display: { fontSize: 30, fontWeight: '800' as const },
  h1: { fontSize: 24, fontWeight: '800' as const },
  h2: { fontSize: 20, fontWeight: '700' as const },
  h3: { fontSize: 17, fontWeight: '700' as const },
  body: { fontSize: 15, fontWeight: '400' as const },
  bodyStrong: { fontSize: 15, fontWeight: '600' as const },
  caption: { fontSize: 13, fontWeight: '500' as const },
  micro: { fontSize: 11, fontWeight: '600' as const },
} as const;

export interface ShadowStyle {
  shadowColor: string;
  shadowOffset: { width: number; height: number };
  shadowOpacity: number;
  shadowRadius: number;
  elevation: number;
}

export function shadow(colors: Palette, elevation = 6, opacity = 0.12): ShadowStyle {
  return {
    shadowColor: `rgba(${colors.shadowRgb}, 1)`,
    shadowOffset: { width: 0, height: elevation / 3 },
    shadowOpacity: opacity,
    shadowRadius: elevation,
    elevation,
  };
}

interface ThemeContextValue {
  mode: ThemeMode;
  resolved: 'light' | 'dark';
  colors: Palette;
  setMode: (m: ThemeMode) => void;
  toggle: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('system');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadJSON<ThemeMode>('theme', 'system').then((m) => {
      setModeState(m);
      setLoaded(true);
    });
  }, []);

  const setMode = (m: ThemeMode) => {
    setModeState(m);
    saveJSON('theme', m);
  };

  const resolved: 'light' | 'dark' =
    mode === 'system' ? (system === 'dark' ? 'dark' : 'light') : mode;
  const colors = resolved === 'dark' ? darkPalette : lightPalette;

  const value = useMemo<ThemeContextValue>(
    () => ({
      mode,
      resolved,
      colors,
      setMode,
      toggle: () => setMode(resolved === 'dark' ? 'light' : 'dark'),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [mode, resolved, colors],
  );

  if (!loaded) {
    // Avoid a flash of the wrong theme before the persisted preference loads.
    return null;
  }

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const v = useContext(ThemeContext);
  if (!v) throw new Error('useTheme must be used within ThemeProvider');
  return v;
}

export type CardStyle = ViewStyle;
