// Node entry for the Rasoi test suite. Run with: npx tsx tests/run.ts
import { runAllTests } from '../src/tests';

async function main() {
  const result = await runAllTests();
  for (const r of result.results) {
    const icon = r.passed ? '✓' : '✗';
    const line = `  ${icon} ${r.suite} > ${r.name}`;
    if (r.passed) {
      console.log('\x1b[32m' + line + '\x1b[0m');
    } else {
      console.log('\x1b[31m' + line + '\x1b[0m');
      console.log('\x1b[31m      ' + r.error + '\x1b[0m');
    }
  }
  const color = result.failed === 0 ? '\x1b[32m' : '\x1b[31m';
  console.log('');
  console.log(color + result.passed + '/' + result.total + ' passed (' + result.failed + ' failed) in ' + result.durationMs + 'ms\x1b[0m');
  process.exit(result.failed === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
