# Verification matrix — brief vs repository

Legend: **Done** = implemented and proven by a command you can re-run.
**Partial** = implemented with a documented external dependency (live credentials).
**Not built** = absent, and the UI/docs say so. There are no remaining "not built" items
from the brief except the two explicitly partial ones.

## P0 / P1

| Item                                                       | State | Evidence                                                                                      |
| ---------------------------------------------------------- | ----- | --------------------------------------------------------------------------------------------- |
| T1 PDF import, typed failures, Node 22                     | Done  | `src/lib/pdf.ts`; `engines`, `.nvmrc`, `instrumentation.ts`; `/api/health`                    |
| T2 Anki CSV + Quizlet TSV                                  | Done  | PapaParse, 4 headers, round-trip + field-count tests; live CSV header verified                |
| T3 engine rewrite, validator, fixtures                     | Done  | 5 fixtures, snapshots, validator tests, quality score in the UI                               |
| T4 drizzle from `DATABASE_URL`                             | Done  | `drizzle.config.ts`; `db:push` created this database                                          |
| T5 loud Supabase misconfiguration                          | Done  | `tests/auth-config.test.ts`; `/api/health` `authProblem`                                      |
| T6 confirm-email signup                                    | Done  | `202 {status:"confirm_email"}` + UI notice                                                    |
| T7 demo billing gating                                     | Done  | 403 unless `ALLOW_DEMO_BILLING=true`; UI button disabled otherwise                            |
| T8 actual engine stored                                    | Done  | `engine` vs `requested_engine`; workspace explanation                                         |
| T9 safe AI errors                                          | Done  | 4 error codes, server-side detail logging                                                     |
| T10 rate limiting                                          | Done  | Postgres limiter + `tests/rate-limit.test.ts`; E2E needs `RATE_LIMIT_BYPASS` for its own runs |
| T11 repo hygiene                                           | Done  | `.gitignore`, husky pre-commit, lint-staged, secret scan                                      |
| T12 token usage + spend                                    | Done  | `ai_events` tokens/cost; billing panel                                                        |
| T13 quiz integrity, 404s, metadata, errors, robots/sitemap | Done  | server-side scoring, scoped 404s, error boundaries, `robots.ts`, `sitemap.ts`                 |

## Phase A–C

| Item                                      | State       | Evidence                                                                                                                                                                                                                                                                                                                                                                                              |
| ----------------------------------------- | ----------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| T14 card CRUD/suspend/flag/reorder + undo | Done        | card API + `CardManager` + sonner Undo                                                                                                                                                                                                                                                                                                                                                                |
| T15 filters/search server-side            | Done        | SQL filters in `getDocumentCards`                                                                                                                                                                                                                                                                                                                                                                     |
| T16 import CSV/TSV/Markdown               | Done        | `tests/import.test.ts`; live import returned `{"imported":2}`                                                                                                                                                                                                                                                                                                                                         |
| T17 FSRS v5                               | Done        | `tests/scheduler.test.ts`; retention setting                                                                                                                                                                                                                                                                                                                                                          |
| **T18 OCR for scans**                     | **Done**    | `src/lib/ocr.ts` + `extractPdfWithOcr`. Real proof: `tests/fixtures/scanned-handout.pdf` (image-only, generated by `scripts/make-scan-fixture.mjs`) rendered to a 194 KB PNG and read as “BIOLOGY 101 - OSMOSIS Osmosis is the diffusion of water across a selectively permeable membrane…”. `/api/health` → `"ocr": true`. Opt-in re-run: `OCR_SMOKE=1 npx vitest run tests/ocr.integration.test.ts` |
| T19 maths + sanitising                    | Done        | `src/lib/rich/render.ts`, KaTeX server-side, `tests/math.test.ts`                                                                                                                                                                                                                                                                                                                                     |
| T20 Stripe                                | **Partial** | Checkout, portal, signed webhook, `stripe_events` replay protection, subscriptions, credit reset, downgrade. Needs live keys + endpoint; without them the API returns 403/503 (verified live)                                                                                                                                                                                                         |
| T21 Supabase                              | **Partial** | Server-only GoTrue adapter + `supabase/migrations/0001_recall_rls.sql`. RLS cannot be executed without a Supabase project                                                                                                                                                                                                                                                                             |
| **T22 offline PWA**                       | **Done**    | `public/sw.js`, `manifest.webmanifest`, `public/offline.html`, IndexedDB queue, sync badge. `tests/offline-queue.test.ts` (queue, replay, idempotency, 404 drop)                                                                                                                                                                                                                                      |
| T23 observability                         | **Partial** | Structured request-id logs, `/api/health` (db/auth/AI/OCR/node/version). Sentry SDK intentionally not bundled                                                                                                                                                                                                                                                                                         |
| **T24 i18n**                              | **Done**    | English + Hindi dictionaries, cookie locale, `LocaleSwitcher` (44 px, labelled), locale-aware dates/numbers, `tests/i18n.test.ts`, E2E language test                                                                                                                                                                                                                                                  |

## P2 polish

Segmented mobile deck tab strip · bottom nav active state + safe area · empty states ·
skeletons · keyboard help sheet · 30-day heatmap · reduced motion · template rename ·
focus rings/contrast fixes (axe) · **README screenshot** (`docs/review-flow.png`,
captured from the running app with Playwright). Currency is detected from
`Accept-Language`; there is no visible INR/USD toggle.

## Test evidence

- `npm test` → **95 tests / 13 files** (93 run + 2 opt-in OCR integration), plus
  `@vitest/coverage-v8`: memory engine 93% lines.
- `npm run test:e2e` → **8/8 passing** on the mobile project (390×844, Chromium):
  signup → generate → reveal/grade → quiz → CSV download → card filter → delete;
  cross-user isolation (delete, cards, export all 404; owner still 200);
  axe (no serious/critical) on `/`, `/login`, `/pricing`, `/licences`, `/app`;
  English → Hindi switch. The desktop project (1440×900) is configured and runs in CI.
- Accessibility fixes found by axe and applied: logo accessible-name mismatch,
  `text-muted/70` contrast, missing label on the language select, hidden mobile
  switcher, `aria-current` on nav.
- Licence gate: `npm run license:check` passes; Apache-2.0 additions (tesseract.js,
  pdf.js, Playwright) are attributed in `NOTICE` and rendered at `/licences`.

## Remaining external verification

1. A live Stripe payment + webhook delivery (code paths verified by unit tests and by
   the configured-but-keyless failure modes).
2. Running `supabase/migrations/0001_recall_rls.sql` against a real Supabase project.
3. Optional Sentry DSN wiring (telemetry is env-gated and absent by design).
