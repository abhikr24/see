import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

const PASSWORD = "testing1234";
const TEXT_PDF = "tests/fixtures/text-chapter.pdf";

async function signUp(page: Page, email: string): Promise<void> {
  await page.goto("/login");
  await page.getByRole("button", { name: "Create account", exact: true }).click();
  await page.getByLabel("Name").fill("E2E Learner");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(PASSWORD);
  await page.getByRole("button", { name: /create my workspace/i }).click();
  await page.waitForURL(/\/app$/, { timeout: 60_000 });
}

async function loginAsDemo(page: Page): Promise<void> {
  await page.goto("/login");
  await page.getByLabel("Email").fill("demo@recall.studio");
  await page.getByLabel("Password").fill("recall1234");
  await page
    .getByRole("button", { name: /^sign in$/i })
    .last()
    .click();
  await page.waitForURL(/\/app/, { timeout: 60_000 });
}

/** Uploads the real 2-page text PDF and returns the document id. */
async function uploadPdf(page: Page): Promise<string> {
  await page.goto("/app/new");
  await page.getByRole("button", { name: "Upload a file", exact: true }).click();
  await page.getByLabel("Source file").setInputFiles(TEXT_PDF);
  await page.getByLabel("Title", { exact: true }).fill("E2E Membrane Transport");
  await page.getByRole("button", { name: /generate memory material/i }).click();
  await page.waitForURL(/\/app\/documents\/[0-9a-f-]{36}/, { timeout: 120_000 });
  return page.url().split("/").pop() ?? "";
}

test.describe("Recall end to end", () => {
  test("signup → upload PDF → deck → grade → quiz → export → delete", async ({ page }) => {
    await signUp(page, `e2e-${Date.now()}@example.com`);
    await uploadPdf(page);

    // Deck generated from the real PDF.
    await expect(page.getByRole("tab", { name: /^review$/i })).toBeVisible();
    await expect(page.getByText(/quality/i).first()).toBeVisible();
    await expect(page.getByText(/cards$/i).first()).toBeVisible();

    // Reveal and grade with the keyboard (space / 3 = Good).
    await page
      .getByRole("button", { name: /show answer/i })
      .first()
      .click();
    await page.keyboard.press("3");
    await expect(page.getByText(/answer/i).first()).toBeVisible();

    // Quiz renders a graded attempt.
    await page.getByRole("tab", { name: /^quiz$/i }).click();
    await expect(page.getByText(/question 1 of|no quiz|multiple-choice/i).first()).toBeVisible();

    // Export downloads a real CSV file.
    const download = page.waitForEvent("download");
    await page.getByRole("link", { name: /anki csv/i }).click();
    expect((await download).suggestedFilename()).toMatch(/\.csv$/);

    // Card manager: server-side search.
    await page.getByRole("tab", { name: /^cards$/i }).click();
    await page.getByPlaceholder(/search prompts/i).fill("membrane");
    await expect(page.getByText(/card(s)? shown/i)).toBeVisible();

    // Delete the deck and confirm it is gone.
    await page.goto("/app");
    await page
      .getByRole("button", { name: /delete document/i })
      .first()
      .click();
    await page.getByRole("button", { name: "Delete", exact: true }).first().click();
    await page.waitForTimeout(1200);
    await page.reload();
    await expect(page.getByText("E2E Membrane Transport")).toHaveCount(0, { timeout: 20_000 });
  });

  test("isolation: user B cannot read, export, edit or delete user A's deck (all 404)", async ({
    page,
    playwright,
  }) => {
    await signUp(page, `owner-${Date.now()}@example.com`);
    const documentId = await uploadPdf(page);

    const intruder = await playwright.request.newContext();
    await intruder.post("/api/auth/signup", {
      data: { name: "Intruder", email: `intruder-${Date.now()}@example.com`, password: PASSWORD },
    });

    expect((await intruder.delete(`/api/documents/${documentId}`)).status()).toBe(404);
    expect((await intruder.get(`/api/documents/${documentId}/cards`)).status()).toBe(404);
    expect((await intruder.get(`/api/export/${documentId}?format=csv`)).status()).toBe(404);

    const cards = await page.request.get(`/api/documents/${documentId}/cards`);
    const cardId = (await cards.json()).cards[0].id as string;
    expect(
      (await intruder.patch(`/api/cards/${cardId}`, { data: { answer: "Hijacked" } })).status(),
    ).toBe(404);

    // The page route itself must be a real 404, not a 200 with not-found content.
    const pageResponse = await intruder.get(`/app/documents/${documentId}`);
    expect(pageResponse.status()).toBe(404);

    // The owner still has access.
    await page.goto(`/app/documents/${documentId}`);
    await expect(page.getByRole("tab", { name: /^review$/i })).toBeVisible();
    await intruder.dispose();
  });

  for (const path of ["/", "/login", "/app", "/app/documents/[deck]"]) {
    test(`axe: no serious violations on ${path}`, async ({ page }) => {
      await loginAsDemo(page);
      let target = path;
      if (path.includes("[deck]")) {
        await page.goto("/app");
        const deck = page.locator('a[href^="/app/documents/"]').first();
        expect(await deck.count()).toBeGreaterThan(0);
        target = (await deck.getAttribute("href")) ?? "/app";
      }
      await page.goto(target);
      const results = await new AxeBuilder({ page }).analyze();
      const serious = results.violations
        .filter((violation) => ["serious", "critical"].includes(violation.impact ?? ""))
        .map((violation) => `${violation.id}: ${violation.help}`);
      expect(JSON.stringify(serious)).toBe("[]");
    });
  }

  test("language switch renders Hindi navigation", async ({ page }) => {
    await loginAsDemo(page);
    const saved = page.waitForResponse((response) => response.url().includes("/api/locale"));
    await page
      .getByRole("combobox", { name: /language/i })
      .last()
      .selectOption("hi");
    expect((await saved).status()).toBe(200);
    await expect(page.locator("text=अवलोकन").locator("visible=true").first()).toBeVisible({
      timeout: 20_000,
    });
    await expect(page.locator("text=दोहराएँ").locator("visible=true").first()).toBeVisible({
      timeout: 20_000,
    });
  });
});
