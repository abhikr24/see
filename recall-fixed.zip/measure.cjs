const { chromium } = require('playwright');
const B = process.env.BASE;
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  await page.goto(B + '/login', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /demo/i }).first().click();
  await page.waitForURL('**/app', { timeout: 25000 });
  await page.goto(B + '/app/new', { waitUntil: 'networkidle' });
  await page.setInputFiles('input[type=file]', '/scratch/work/test-biology.pdf');
  await page.waitForTimeout(400);
  await page.getByRole('button', { name: /Generate memory material/i }).click();
  await page.waitForURL(/\/app\/documents\//, { timeout: 90000 });
  await page.waitForTimeout(1500);
  const m = await page.evaluate(() => {
    const h = document.querySelector('header');
    const h1 = document.querySelector('h1');
    const nav = document.querySelector('nav');
    const r = (el) => el ? el.getBoundingClientRect().toJSON() : null;
    return { scrollY: window.scrollY, header: r(h), h1: r(h1), nav: r(nav), innerH: window.innerHeight };
  });
  console.log('header.bottom', Math.round(m.header.bottom), '| h1.top', Math.round(m.h1.top), '| overlap', m.h1.top < m.header.bottom);
  // reveal answer then measure grade buttons at scroll 0 and at bottom
  const rev = page.getByRole('button', { name: /Show answer|Reveal/i }).first();
  if (await rev.isVisible().catch(()=>false)) await rev.click();
  await page.waitForTimeout(400);
  const geo = await page.evaluate(() => {
    const nav = document.querySelector('nav');
    const btns = [...document.querySelectorAll('button')].filter(b => /^(Again|Hard|Good|Easy)/.test(b.textContent.trim()));
    const r = (el) => el ? el.getBoundingClientRect().toJSON() : null;
    return { navTop: nav ? nav.getBoundingClientRect().top : null, btns: btns.map(b => ({ t: b.textContent.trim().slice(0,6), top: Math.round(b.getBoundingClientRect().top), bottom: Math.round(b.getBoundingClientRect().bottom) })), scrollY: window.scrollY, docH: document.documentElement.scrollHeight };
  });
  console.log('nav.top', Math.round(geo.navTop), 'buttons', JSON.stringify(geo.btns), 'scrollY', geo.scrollY, 'docH', geo.docH);
  await page.screenshot({ path: '/scratch/work/shots_fix/review-top.png' });
  await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
  await page.waitForTimeout(500);
  const after = await page.evaluate(() => {
    const nav = document.querySelector('nav');
    const btns = [...document.querySelectorAll('button')].filter(b => /^(Again|Hard|Good|Easy)/.test(b.textContent.trim()));
    return { navTop: nav ? Math.round(nav.getBoundingClientRect().top) : null, btns: btns.map(b => ({ t: b.textContent.trim().slice(0,6), bottom: Math.round(b.getBoundingClientRect().bottom) })) };
  });
  console.log('after scroll: nav.top', after.navTop, 'button bottoms', JSON.stringify(after.btns), 'all clear:', after.btns.every(b => b.bottom <= after.navTop));
  await page.screenshot({ path: '/scratch/work/shots_fix/review-bottom.png' });
  await browser.close();
})();
