const { chromium } = require('playwright');
const B = process.env.BASE;
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  await page.goto(B + '/login', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /demo/i }).first().click();
  await page.waitForURL('**/app', { timeout: 25000 });
  const hrefs = await page.locator('a[href^="/app/documents/"]').first().getAttribute('href').catch(()=>null);
  if (hrefs) { await page.goto(B + hrefs, { waitUntil: 'networkidle' }); }
  await page.waitForTimeout(1200);
  const rev = page.getByRole('button', { name: /Show answer|Reveal/i }).first();
  if (await rev.isVisible().catch(()=>false)) await rev.click();
  await page.waitForTimeout(400);
  const r = await page.evaluate(() => {
    const nav = document.querySelector('nav.safe-bottom');
    const navRect = nav ? nav.getBoundingClientRect() : null;
    const btns = [...document.querySelectorAll('button')].filter(b => /^(Again|Hard|Good|Easy)/.test(b.textContent.trim()));
    const info = btns.map(b => {
      const rect = b.getBoundingClientRect();
      const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
      const hit = document.elementFromPoint(cx, Math.min(cy, window.innerHeight - 2));
      return { label: b.textContent.trim().slice(0,6), top: Math.round(rect.top), bottom: Math.round(rect.bottom), coveredByNav: hit ? !!hit.closest('nav.safe-bottom') : null };
    });
    return { navTop: navRect ? Math.round(navRect.top) : null, navH: navRect ? Math.round(navRect.height) : null, vh: window.innerHeight, scrollY: window.scrollY, info };
  });
  console.log(JSON.stringify(r, null, 1));
  await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
  await page.waitForTimeout(400);
  const r2 = await page.evaluate(() => {
    const nav = document.querySelector('nav.safe-bottom');
    const navTop = nav ? Math.round(nav.getBoundingClientRect().top) : null;
    const btns = [...document.querySelectorAll('button')].filter(b => /^(Again|Hard|Good|Easy)/.test(b.textContent.trim()));
    return { navTop, bottoms: btns.map(b => Math.round(b.getBoundingClientRect().bottom)), clear: btns.every(b => b.getBoundingClientRect().bottom <= (navTop ?? 844)) };
  });
  console.log('at bottom:', JSON.stringify(r2));
  await page.screenshot({ path: '/scratch/work/shots_fix/review-bottom.png' });
  await browser.close();
})();
