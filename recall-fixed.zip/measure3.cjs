const { chromium } = require('playwright');
const B = process.env.BASE;
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  await page.goto(B + '/login', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: /demo/i }).first().click();
  await page.waitForURL('**/app', { timeout: 25000 });
  const href = await page.locator('a[href^="/app/documents/"]').first().getAttribute('href').catch(()=>null);
  if (href) await page.goto(B + href, { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(400);
  const r = await page.evaluate(() => {
    const h = document.querySelector('header');
    const h1 = document.querySelector('h1');
    return { scrollY: window.scrollY, headerBottom: h ? Math.round(h.getBoundingClientRect().bottom) : null, h1Top: h1 ? Math.round(h1.getBoundingClientRect().top) : null };
  });
  console.log('at scroll 0:', JSON.stringify(r), 'overlap:', r.h1Top < r.headerBottom);
  await page.screenshot({ path: '/scratch/work/shots_fix/doc-top.png' });
  await browser.close();
})();
