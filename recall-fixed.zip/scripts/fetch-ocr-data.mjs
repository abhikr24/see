#!/usr/bin/env node
/**
 * Download tesseract language models into the deployment cache so OCR never
 * fetches from a CDN at request time.
 *
 *   npm run ocr:fetch-data            # eng
 *   OCR_LANGUAGES=eng+hin npm run ocr:fetch-data
 *
 * Files land in TESSERACT_CACHE_PATH (default .tesseract/) and are gitignored.
 */
import { mkdir, writeFile, readFile } from "node:fs/promises";
import path from "node:path";

const cachePath = process.env.TESSERACT_CACHE_PATH
  ? path.resolve(process.env.TESSERACT_CACHE_PATH)
  : path.join(process.cwd(), ".tesseract");
const languages = (process.env.OCR_LANGUAGES ?? "eng")
  .split("+")
  .map((value) => value.trim())
  .filter(Boolean);

const BASE = process.env.OCR_LANG_BASE ?? "https://cdn.jsdelivr.net/npm/@tesseract.js-data";

await mkdir(cachePath, { recursive: true });

for (const language of languages) {
  const target = path.join(cachePath, `${language}.traineddata`);
  try {
    const existing = await readFile(target);
    if (existing.length > 1000) {
      console.log(
        `✓ ${language}.traineddata already cached (${Math.round(existing.length / 1024)} KB)`,
      );
      continue;
    }
  } catch {
    // Not cached yet.
  }

  const url = `${BASE}/${language}/4.0.0_best_int/${language}.traineddata.gz`;
  process.stdout.write(`↓ ${language} ← ${url} ... `);
  const response = await fetch(url);
  if (!response.ok) {
    console.error(
      `\nFailed: HTTP ${response.status}. Set OCR_LANG_BASE to a mirror that hosts ${language}.`,
    );
    process.exitCode = 1;
    continue;
  }
  const compressed = new Uint8Array(await response.arrayBuffer());
  const data =
    compressed[0] === 31 && compressed[1] === 139 ? await gunzip(compressed) : compressed;
  await writeFile(target, data);
  console.log(`${Math.round(data.length / 1024)} KB → ${target}`);
}

async function gunzip(bytes) {
  const { gunzipSync } = await import("node:zlib");
  return gunzipSync(bytes);
}

console.log(`OCR language cache: ${cachePath} (${languages.join(", ")})`);
