#!/usr/bin/env node
/**
 * Builds tests/fixtures/text-chapter.pdf: a real 2-page text PDF used by the
 * API and E2E suites, so upload tests exercise the actual unpdf text path.
 */
import { writeFileSync } from "node:fs";

const PAGES = [
  [
    "Chapter 3 - Membrane Transport",
    "",
    "Diffusion is the net movement of particles from a region of higher",
    "concentration to a region of lower concentration. Diffusion stops when",
    "the concentration gradient disappears and the system reaches equilibrium.",
    "",
    "Osmosis is the diffusion of water across a selectively permeable",
    "membrane. Water moves from a dilute solution to a concentrated solution.",
    "A red blood cell placed in a hypertonic solution loses water and shrinks.",
  ],
  [
    "Active Transport",
    "",
    "Active transport moves substances against their concentration gradient",
    "and therefore requires energy from ATP. The sodium potassium pump moves",
    "three sodium ions out of the cell for every two potassium ions it brings in.",
    "The resting potential of a typical neuron is approximately -70 mV.",
    "",
    "The cell membrane is a phospholipid bilayer with embedded proteins that",
    "control which substances enter and leave the cell.",
  ],
];

const escape = (line) => line.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
const contentStreams = PAGES.map((lines) =>
  [
    "BT",
    "/F1 12 Tf",
    "14 TL",
    "56 760 Td",
    ...lines.map((line) => `(${escape(line)}) Tj T*`),
    "ET",
  ].join("\n"),
);

const objects = [
  "<< /Type /Catalog /Pages 2 0 R >>",
  `<< /Type /Pages /Kids [${PAGES.map((_, index) => `${index + 3} 0 R`).join(" ")}] /Count ${PAGES.length} >>`,
  ...contentStreams.map(
    (_, index) =>
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 ${PAGES.length + 3} 0 R >> >> /Contents ${PAGES.length + 4 + index} 0 R >>`,
  ),
  "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ...contentStreams.map(
    (stream) =>
      `<< /Length ${Buffer.byteLength(stream, "latin1")} >>\nstream\n${stream}\nendstream`,
  ),
];

const chunks = [Buffer.from("%PDF-1.7\n", "latin1")];
const offsets = [0];
objects.forEach((body, index) => {
  offsets[index + 1] = chunks.reduce((total, chunk) => total + chunk.length, 0);
  chunks.push(Buffer.from(`${index + 1} 0 obj\n${body}\nendobj\n`, "latin1"));
});
const body = Buffer.concat(chunks);
const xref = [
  "xref",
  `0 ${objects.length + 1}`,
  "0000000000 65535 f ",
  ...offsets.slice(1).map((offset) => `${String(offset).padStart(10, "0")} 00000 n `),
  "trailer",
  `<< /Size ${objects.length + 1} /Root 1 0 R >>`,
  "startxref",
  String(body.length),
  "%%EOF",
  "",
].join("\n");
writeFileSync(
  "tests/fixtures/text-chapter.pdf",
  Buffer.concat([body, Buffer.from(xref, "latin1")]),
);
console.log("wrote tests/fixtures/text-chapter.pdf");
