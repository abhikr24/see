import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { aiStatus, generateWithAi, mergeAiAnalysis } from "@/lib/ai/provider";
import { analyzeSource } from "@/lib/memory/engine";
import { extractPdfWithOcr, PdfImportError } from "@/lib/pdf";
import { ocrStatus } from "@/lib/ocr";
import { clientIp, consumeRateLimit, rateLimitResponse } from "@/lib/rate-limit";
import { jsonError, logServerError, requestIdFor } from "@/lib/http";
import { createSource, listDocuments, recordAiFailure } from "@/lib/repository";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_PDF_BYTES = 12 * 1024 * 1024;
const MAX_TEXT_CHARS = 400_000;

const jsonSchema = z.object({
  title: z.string().max(160).optional(),
  text: z.string().min(1),
  engine: z.enum(["rules", "ai"]).default("rules"),
  cardCount: z.number().int().min(8).max(60).optional(),
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ documents: await listDocuments(user.id) });
}

export async function POST(request: Request) {
  const requestId = requestIdFor(request);
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "UNAUTHENTICATED", "Please sign in first.", requestId);

  const limiter = await consumeRateLimit("upload", `${user.id}:${clientIp(request)}`);
  if (!limiter.allowed) return rateLimitResponse("upload", limiter);

  const contentType = request.headers.get("content-type") ?? "";
  let title = "Untitled source";
  let pages: string[] = [];
  let sourceType: "pdf" | "txt" | "paste" = "paste";
  let fileName: string | null = null;
  let engine: "rules" | "ai" = "rules";
  let cardCount: number | undefined;
  let needsOcr = false;
  const warnings: string[] = [];

  try {
    if (contentType.includes("multipart/form-data")) {
      const form = await request.formData();
      const file = form.get("file");
      const engineField = String(form.get("engine") ?? "rules");
      engine = engineField === "ai" ? "ai" : "rules";
      const titleField = String(form.get("title") ?? "").trim();
      const cardCountField = Number(form.get("cardCount") ?? 0);
      if (cardCountField >= 8 && cardCountField <= 60) cardCount = cardCountField;

      if (!(file instanceof File) || file.size === 0) {
        return jsonError(400, "NO_FILE", "Choose a PDF, TXT or Markdown file.", requestId);
      }
      if (file.size > MAX_PDF_BYTES) {
        return jsonError(413, "FILE_TOO_LARGE", "That file is larger than 12 MB.", requestId);
      }

      fileName = file.name;
      title = titleField || file.name.replace(/\.[^.]+$/, "").slice(0, 140) || "Untitled source";
      const lower = file.name.toLowerCase();

      if (lower.endsWith(".pdf")) {
        sourceType = "pdf";
        // Scanned pages are handled by the asynchronous OCR job API so this
        // request never blocks for minutes. Text PDFs (the common case) never
        // touch OCR at all.
        const extracted = await extractPdfWithOcr(await file.arrayBuffer(), {
          enableOcr: false,
        });
        pages = extracted.pages;
        needsOcr = extracted.ocr;
        warnings.push(...extracted.warnings);
      } else if (lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".markdown")) {
        sourceType = "txt";
        pages = [(await file.text()).slice(0, MAX_TEXT_CHARS)];
      } else {
        return jsonError(
          415,
          "UNSUPPORTED_FILE",
          "Supported files: PDF, TXT, MD. For anything else, paste the text.",
          requestId,
        );
      }
    } else {
      const parsed = jsonSchema.safeParse(await request.json().catch(() => null));
      if (!parsed.success) {
        return jsonError(400, "INVALID_BODY", "Paste some text first.", requestId);
      }
      title = (parsed.data.title ?? "Untitled source").slice(0, 140) || "Untitled source";
      pages = [parsed.data.text.slice(0, MAX_TEXT_CHARS)];
      engine = parsed.data.engine;
      cardCount = parsed.data.cardCount;
      sourceType = "paste";
    }
  } catch (error) {
    if (error instanceof PdfImportError) {
      logServerError("pdf_import", requestId, error);
      const ocr = ocrStatus();
      return NextResponse.json(
        {
          error: error.userMessage,
          code: error.code,
          requestId,
          ocrAvailable: error.code === "NO_TEXT_LAYER" && ocr.available,
          ocrLanguages: ocr.languages,
        },
        { status: error.status },
      );
    }
    logServerError("document_parse", requestId, error);
    return jsonError(
      500,
      "PARSE_FAILED",
      "Something went wrong while reading that file. Try again, or paste the text instead.",
      requestId,
    );
  }

  const joined = pages.join(" ").trim();
  if (joined.length < 60) {
    return jsonError(
      422,
      "TOO_SHORT",
      "We need at least 60 characters of readable text to build memory material.",
      requestId,
    );
  }

  let aiOverlay: Parameters<typeof createSource>[0]["aiOverlay"] = null;
  let aiMeta: Parameters<typeof createSource>[0]["aiMeta"] = null;
  let aiNote: string | null = null;
  let aiCode: string | null = null;

  if (engine === "ai") {
    const aiLimiter = await consumeRateLimit("ai_generate", user.id);
    if (!aiLimiter.allowed) return rateLimitResponse("ai_generate", aiLimiter);

    if (user.plan !== "pro") {
      return jsonError(
        402,
        "UPGRADE_REQUIRED",
        "The AI engine is part of Pro. The rules engine is free and unlimited — or upgrade to unlock AI cards.",
        requestId,
      );
    }
    if (user.aiCredits <= 0) {
      return jsonError(
        402,
        "NO_CREDITS",
        "You are out of AI credits. Top up in Billing, or switch to the free rules engine.",
        requestId,
      );
    }

    const base = analyzeSource({ title, pages });
    const ai = await generateWithAi({
      title,
      text: pages.join("\n\n"),
      cardCount: Math.min(
        cardCount ?? Math.max(14, Math.round(base.analysis.stats.words / 55)),
        45,
      ),
      pages,
    });

    if (ai.ok) {
      aiOverlay = {
        cards: ai.cards,
        analysis: mergeAiAnalysis(base.analysis, ai),
        provider: `${ai.provider} · ${ai.model}`,
      };
      aiMeta = {
        provider: ai.provider,
        model: ai.model,
        tokens: ai.usage.totalTokens,
        inputTokens: ai.usage.inputTokens,
        outputTokens: ai.usage.outputTokens,
        costUsd: ai.usage.costUsd,
      };
      if (ai.droppedCards > 0) {
        warnings.push(
          `${ai.droppedCards} AI card${ai.droppedCards === 1 ? "" : "s"} failed the quality validator and ${ai.droppedCards === 1 ? "was" : "were"} removed.`,
        );
      }
    } else {
      aiCode = ai.code;
      aiNote = ai.message;
      warnings.push(ai.message);
      await recordAiFailure({
        userId: user.id,
        provider: ai.provider,
        model: ai.model,
        code: ai.code,
      }).catch((error: unknown) => logServerError("ai_event_log", requestId, error));
      logServerError("ai_generation", requestId, `${ai.code} ${ai.provider} ${ai.model}`);
    }
  }

  const doc = await createSource({
    userId: user.id,
    title,
    sourceType,
    fileName,
    pages,
    engine,
    cardCount,
    ocr: needsOcr,
    aiOverlay,
    aiMeta,
  });

  return NextResponse.json({
    ok: true,
    id: doc.id,
    engine: doc.engine,
    requestedEngine: doc.requestedEngine,
    aiNote,
    aiCode,
    aiConfigured: aiStatus().configured,
    qualityScore: doc.qualityScore,
    warnings,
    requestId,
  });
}
