import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getOcrJob, publicJob } from "@/lib/ocr/jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Poll OCR progress. Scoped by user id: another user's job returns 404. */
export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await context.params;
  const job = getOcrJob(user.id, id);
  if (!job) return NextResponse.json({ error: "OCR job not found." }, { status: 404 });

  return NextResponse.json({ job: publicJob(job) }, { headers: { "Cache-Control": "no-store" } });
}
