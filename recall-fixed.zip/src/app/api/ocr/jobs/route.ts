import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { jsonError, requestIdFor } from "@/lib/http";
import { ocrStatus } from "@/lib/ocr";
import { createOcrJob, publicJob, startOcrJob } from "@/lib/ocr/jobs";
import { consumeRateLimit, rateLimitResponse } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const maxDuration = 300;

const MAX_PDF_BYTES = 12 * 1024 * 1024;

/** Start an OCR job for a scanned PDF. Returns immediately with a job id. */
export async function POST(request: Request) {
  const requestId = requestIdFor(request);
  const user = await getCurrentUser();
  if (!user) return jsonError(401, "UNAUTHENTICATED", "Please sign in first.", requestId);

  const limiter = await consumeRateLimit("upload", user.id);
  if (!limiter.allowed) return rateLimitResponse("upload", limiter);

  const status = ocrStatus();
  if (!status.available) {
    return jsonError(
      503,
      "OCR_UNAVAILABLE",
      `OCR is not available on this deployment (${status.reason ?? "unknown reason"}). Paste the text instead.`,
      requestId,
    );
  }

  const form = await request.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return jsonError(400, "NO_FILE", "Choose the scanned PDF to read.", requestId);
  }
  if (!file.name.toLowerCase().endsWith(".pdf")) {
    return jsonError(415, "UNSUPPORTED_FILE", "OCR accepts PDFs only.", requestId);
  }
  if (file.size > MAX_PDF_BYTES) {
    return jsonError(413, "FILE_TOO_LARGE", "That file is larger than 12 MB.", requestId);
  }

  const title =
    String(form?.get("title") ?? "").trim() ||
    file.name.replace(/\.pdf$/i, "").slice(0, 140) ||
    "Scanned source";

  const job = createOcrJob({ userId: user.id, title });
  const bytes = await file.arrayBuffer();
  startOcrJob(job, { userId: user.id, title, buffer: bytes });

  return NextResponse.json({ ok: true, job: publicJob(job) }, { status: 202 });
}

/** Capability probe used by the upload UI before offering OCR. */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const status = ocrStatus();
  return NextResponse.json({
    available: status.available,
    reason: status.reason,
    languages: status.languages,
    maxPages: status.maxPages,
    lastSmokeAt: status.lastSmokeAt,
  });
}
