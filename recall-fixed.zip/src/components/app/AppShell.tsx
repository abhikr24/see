"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import {
  CreditCard,
  Flame,
  LayoutDashboard,
  Loader2,
  LogOut,
  Plus,
  Repeat,
  Sparkles,
} from "lucide-react";
import { Logo } from "@/components/site/SiteChrome";
import LocaleSwitcher from "@/components/LocaleSwitcher";
import { useOffline } from "@/components/offline/OfflineProvider";
import type { Locale } from "@/lib/i18n/messages";

export type ShellUser = {
  name: string;
  email: string;
  plan: string;
  aiCredits: number;
  streak: number;
};

const NAV = [
  { href: "/app", labelKey: "overview", icon: LayoutDashboard },
  { href: "/app/new", labelKey: "newSource", icon: Plus },
  { href: "/app/review", labelKey: "review", icon: Repeat },
  { href: "/app/billing", labelKey: "billing", icon: CreditCard },
] as const;

export type ShellLabels = {
  overview: string;
  newSource: string;
  review: string;
  billing: string;
  signOut: string;
  language: string;
};

export default function AppShell({
  user,
  dueCount,
  locale,
  labels,
  children,
}: {
  user: ShellUser;
  dueCount: number;
  locale: Locale;
  labels: ShellLabels;
  children: React.ReactNode;
}) {
  const { online, pending } = useOffline();
  const pathname = usePathname();
  const router = useRouter();
  const [signingOut, setSigningOut] = useState(false);

  const isActive = (href: string) =>
    href === "/app" ? pathname === "/app" : pathname.startsWith(href);

  async function signOut() {
    setSigningOut(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[236px_1fr]">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-dvh flex-col border-r border-line bg-ink-2/40 px-3.5 py-5 lg:flex">
        <div className="px-2">
          <Logo />
        </div>

        <nav className="mt-7 space-y-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="app-link"
              data-active={isActive(item.href)}
            >
              <item.icon className="h-4 w-4" />
              {labels[item.labelKey]}
              {item.href === "/app/review" && dueCount > 0 && (
                <span className="ml-auto rounded-full bg-lime px-1.5 py-0.5 text-[10px] font-bold text-ink">
                  {dueCount > 99 ? "99+" : dueCount}
                </span>
              )}
            </Link>
          ))}
        </nav>

        <div className="mt-5 space-y-2 px-2">
          <LocaleSwitcher locale={locale} label={labels.language} />
          <p className="text-[10px] text-muted">
            {online ? "● Online" : "○ Offline"}
            {pending > 0 ? ` · ${pending} queued` : ""}
          </p>
        </div>

        <div className="mt-auto space-y-3">
          <div className="rounded-xl border border-line bg-white/[0.03] p-3">
            <div className="flex items-center justify-between text-[11px] text-muted">
              <span className="inline-flex items-center gap-1.5">
                <Flame className="h-3 w-3 text-coral" /> Streak
              </span>
              <span className="font-semibold text-cream">{user.streak}d</span>
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-muted">
              <span className="inline-flex items-center gap-1.5">
                <Sparkles className="h-3 w-3 text-violet" /> AI credits
              </span>
              <span className="font-semibold text-cream">{user.aiCredits}</span>
            </div>
            <Link href="/app/billing" className="mt-2.5 block text-[11px] font-semibold text-lime">
              {user.plan === "pro" ? "Pro plan" : "Upgrade to Pro"} →
            </Link>
          </div>

          <div className="flex items-center gap-2.5 rounded-xl border border-line bg-white/[0.03] p-2.5">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-lime/15 text-[12px] font-bold text-lime">
              {user.name.slice(0, 1).toUpperCase()}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12.5px] font-medium text-cream">{user.name}</p>
              <p className="truncate text-[10.5px] text-muted">{user.email}</p>
            </div>
            <button
              type="button"
              onClick={() => void signOut()}
              aria-label={labels.signOut}
              className="rounded-lg p-1.5 text-muted transition hover:bg-white/5 hover:text-coral"
            >
              {signingOut ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <LogOut className="h-4 w-4" />
              )}
            </button>
          </div>
        </div>
      </aside>

      <div className="flex min-h-dvh flex-col">
        {/* Mobile header */}
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-ink/85 px-4 backdrop-blur-xl lg:hidden">
          <Logo compact />
          <div className="flex items-center gap-2">
            <LocaleSwitcher locale={locale} label={labels.language} />
            <span className="chip">
              <Flame className="h-3 w-3 text-coral" /> {user.streak}d
            </span>
            <Link href="/app/billing" className="chip chip-lime">
              <Sparkles className="h-3 w-3" /> {user.aiCredits}
            </Link>
            <button
              type="button"
              onClick={() => void signOut()}
              aria-label={labels.signOut}
              className="rounded-lg border border-line p-1.5 text-muted"
            >
              {signingOut ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <LogOut className="h-4 w-4" />
              )}
            </button>
          </div>
        </header>

        <main className="app-main flex-1 px-4 pt-5 sm:px-6 lg:px-8 lg:pt-8">
          <div className="mx-auto w-full max-w-5xl">{children}</div>
        </main>

        {/* Mobile bottom nav */}
        <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-line bg-ink/95 px-2 pt-1.5 backdrop-blur-xl lg:hidden">
          <div className="mx-auto flex max-w-md items-stretch justify-between">
            {NAV.map((item) => {
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  className={`relative flex flex-1 flex-col items-center gap-1 rounded-lg px-1 py-1.5 text-[10px] font-medium transition ${
                    active ? "text-lime" : "text-muted"
                  }`}
                >
                  <item.icon className="h-[18px] w-[18px]" />
                  {labels[item.labelKey]}
                  {item.href === "/app/review" && dueCount > 0 && (
                    <span className="absolute right-2 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-lime px-1 text-[9px] font-bold text-ink">
                      {dueCount > 9 ? "9+" : dueCount}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
