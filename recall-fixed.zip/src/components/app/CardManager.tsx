"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  CircleCheck,
  Flag,
  Loader2,
  Pause,
  Pencil,
  Play,
  Plus,
  Search,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import RichText from "@/components/RichText";
import type { StudyCard } from "@/lib/ui-types";
import { KIND_LABEL } from "@/lib/ui-types";

type ManagedCard = StudyCard & { suspended: boolean; flagged: boolean; position: number };

const KINDS = ["all", "definition", "cloze", "fact", "list", "concept", "ai"] as const;

export default function CardManager({
  documentId,
  initialCards,
}: {
  documentId: string;
  initialCards: StudyCard[];
}) {
  const [cards, setCards] = useState<ManagedCard[]>(
    initialCards.map((card) => ({ ...card, suspended: false, flagged: false, position: 0 })),
  );
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [kind, setKind] = useState<(typeof KINDS)[number]>("all");
  const [page, setPage] = useState("");
  const [dueOnly, setDueOnly] = useState(false);
  const [flaggedOnly, setFlaggedOnly] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState({ prompt: "", answer: "", hint: "", tags: "" });
  const [adding, setAdding] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [importNote, setImportNote] = useState<string | null>(null);
  const [newCard, setNewCard] = useState({ prompt: "", answer: "", hint: "", tags: "" });
  const requestSeq = useRef(0);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 250);
    return () => clearTimeout(timer);
  }, [query]);

  const reorderable = !debouncedQuery && kind === "all" && !page && !dueOnly && !flaggedOnly;

  const load = useCallback(
    async (isCancelled?: () => boolean) => {
      const seq = ++requestSeq.current;
      const stale = () => seq !== requestSeq.current || Boolean(isCancelled?.());
      setLoading(true);
      setError(null);
      try {
        const params = new URLSearchParams({ includeSuspended: "true" });
        if (debouncedQuery) params.set("q", debouncedQuery);
        if (kind !== "all") params.set("kind", kind);
        if (page) params.set("page", page);
        if (dueOnly) params.set("due", "true");
        if (flaggedOnly) params.set("flagged", "true");
        const response = await fetch(`/api/documents/${documentId}/cards?${params.toString()}`, {
          cache: "no-store",
        });
        const data = (await response.json()) as { cards?: ManagedCard[]; error?: string };
        if (stale()) return;
        if (!response.ok) {
          setError(data.error ?? "Could not load cards.");
          return;
        }
        setCards(data.cards ?? []);
      } catch {
        if (!stale()) setError("Network error while loading cards.");
      } finally {
        if (!stale()) setLoading(false);
      }
    },
    [documentId, debouncedQuery, kind, page, dueOnly, flaggedOnly],
  );

  // Filter changes trigger a server fetch. State is only updated from the async
  // callback (guarded by a cancelled flag), never synchronously in the effect body.
  useEffect(() => {
    let cancelled = false;
    // Deferred to a microtask: the loader sets loading state on entry, and
    // react-hooks/set-state-in-effect rejects a synchronous setState in an effect.
    queueMicrotask(() => {
      if (!cancelled) void load(() => cancelled);
    });
    return () => {
      cancelled = true;
    };
  }, [load]);

  const pages = useMemo(
    () => [...new Set(cards.map((card) => card.page))].sort((a, b) => a - b),
    [cards],
  );

  function startEdit(card: ManagedCard) {
    setEditingId(card.id);
    setDraft({
      prompt: card.prompt,
      answer: card.answer,
      hint: card.hint,
      tags: card.tags.join(", "),
    });
    setError(null);
    setMessage(null);
  }

  async function patch(construct: string, body: Record<string, unknown>, success: string) {
    setBusyId(construct);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(construct, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "That change could not be saved.");
        return false;
      }
      setMessage(success);
      await load();
      return true;
    } catch {
      setError("Network error while saving.");
      return false;
    } finally {
      setBusyId(null);
    }
  }

  async function saveEdit(card: ManagedCard) {
    const tags = draft.tags
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean)
      .slice(0, 6);
    const saved = await patch(
      `/api/cards/${card.id}`,
      { prompt: draft.prompt, answer: draft.answer, hint: draft.hint, tags },
      "Card saved.",
    );
    if (saved) setEditingId(null);
  }

  async function remove(card: ManagedCard) {
    if (!window.confirm("Delete this card? This cannot be undone.")) return;
    setBusyId(card.id);
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`/api/cards/${card.id}`, { method: "DELETE" });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Could not delete the card.");
        return;
      }
      await load();
      const snapshot = card;
      toast("Card deleted", {
        description: "You can put it straight back.",
        action: {
          label: "Undo",
          onClick: () => {
            void (async () => {
              const restore = await fetch(`/api/documents/${documentId}/cards`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  prompt: snapshot.prompt,
                  answer: snapshot.answer,
                  hint: snapshot.hint,
                  tags: snapshot.tags,
                  page: snapshot.page,
                }),
              });
              if (!restore.ok) {
                setError("Could not undo the delete.");
                return;
              }
              setMessage("Card restored.");
              await load();
            })();
          },
        },
      });
    } catch {
      setError("Network error while deleting.");
    } finally {
      setBusyId(null);
    }
  }

  async function importCards() {
    setBusyId("import");
    setError(null);
    setImportNote(null);
    try {
      const response = await fetch(`/api/documents/${documentId}/import`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: importText }),
      });
      const data = (await response.json()) as {
        error?: string;
        imported?: number;
        duplicates?: number;
        rejected?: number;
        detected?: string;
      };
      if (!response.ok) {
        setError(data.error ?? "Could not import those cards.");
        return;
      }
      setImportNote(
        `Imported ${data.imported ?? 0} card${data.imported === 1 ? "" : "s"} from ${data.detected ?? "text"}. ${data.duplicates ?? 0} duplicate(s) skipped, ${data.rejected ?? 0} invalid line(s) ignored.`,
      );
      setImportText("");
      await load();
    } catch {
      setError("Network error while importing.");
    } finally {
      setBusyId(null);
    }
  }

  async function createCard() {
    setBusyId("new");
    setError(null);
    setMessage(null);
    try {
      const response = await fetch(`/api/documents/${documentId}/cards`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: newCard.prompt,
          answer: newCard.answer,
          hint: newCard.hint,
          tags: newCard.tags
            .split(",")
            .map((tag) => tag.trim())
            .filter(Boolean)
            .slice(0, 6),
        }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) {
        setError(data.error ?? "Could not add the card.");
        return;
      }
      setNewCard({ prompt: "", answer: "", hint: "", tags: "" });
      setAdding(false);
      setMessage("Card added to the deck.");
      await load();
    } catch {
      setError("Network error while adding the card.");
    } finally {
      setBusyId(null);
    }
  }

  async function move(card: ManagedCard, direction: -1 | 1) {
    const index = cards.findIndex((item) => item.id === card.id);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= cards.length) return;
    const next = [...cards];
    [next[index], next[target]] = [next[target], next[index]];
    setCards(next.map((item, position) => ({ ...item, position })));
    await patch(
      `/api/documents/${documentId}/cards`,
      { order: next.map((item) => item.id) },
      "Deck order saved.",
    );
  }

  return (
    <div className="space-y-3">
      <div className="card p-3 sm:p-4">
        <div className="flex flex-wrap items-center gap-2">
          <label className="relative min-w-[160px] flex-1">
            <span className="sr-only">Search cards</span>
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search prompts and answers"
              className="w-full rounded-lg border border-line bg-ink-2/60 py-2 pl-8 pr-2.5 text-[12px] text-cream placeholder:text-muted/70"
            />
          </label>
          <label className="text-[11px] text-muted">
            <span className="sr-only">Card kind</span>
            <select
              value={kind}
              onChange={(event) => setKind(event.target.value as (typeof KINDS)[number])}
              className="rounded-lg border border-line bg-ink-2/60 px-2 py-2 text-[12px] text-cream"
            >
              {KINDS.map((option) => (
                <option key={option} value={option}>
                  {option === "all" ? "All kinds" : (KIND_LABEL[option] ?? option)}
                </option>
              ))}
            </select>
          </label>
          <label className="text-[11px] text-muted">
            <span className="sr-only">Page</span>
            <select
              value={page}
              onChange={(event) => setPage(event.target.value)}
              className="rounded-lg border border-line bg-ink-2/60 px-2 py-2 text-[12px] text-cream"
            >
              <option value="">All pages</option>
              {pages.map((value) => (
                <option key={value} value={value}>
                  Page {value}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            aria-pressed={dueOnly}
            onClick={() => setDueOnly((current) => !current)}
            className={`rounded-full border px-2.5 py-1.5 text-[11px] font-semibold ${
              dueOnly ? "border-lime/40 bg-lime/15 text-lime" : "border-line text-muted"
            }`}
          >
            Due
          </button>
          <button
            type="button"
            aria-pressed={flaggedOnly}
            onClick={() => setFlaggedOnly((current) => !current)}
            className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1.5 text-[11px] font-semibold ${
              flaggedOnly ? "border-coral/40 bg-coral/15 text-coral" : "border-line text-muted"
            }`}
          >
            <Flag className="h-3 w-3" /> Flagged
          </button>
          <button
            type="button"
            onClick={() => setImportOpen((current) => !current)}
            className="btn btn-ghost btn-sm ml-auto"
          >
            Import
          </button>
          <button
            type="button"
            onClick={() => setAdding((current) => !current)}
            className="btn btn-primary btn-sm"
          >
            <Plus className="h-3.5 w-3.5" /> Add card
          </button>
        </div>
        <p className="mt-2 text-[10.5px] text-muted">
          {loading
            ? "Filtering on the server…"
            : `${cards.length} card${cards.length === 1 ? "" : "s"} shown`}
          {!reorderable && " · clear search and kind/page filters to reorder"}
        </p>
      </div>

      <div aria-live="polite" className="min-h-[1px]">
        {message && (
          <p className="mb-2 flex items-center gap-1.5 rounded-lg border border-lime/30 bg-lime/[0.08] px-3 py-2 text-[11.5px] text-lime">
            <CircleCheck className="h-3.5 w-3.5" /> {message}
          </p>
        )}
        {error && (
          <p
            role="alert"
            className="mb-2 rounded-lg border border-coral/30 bg-coral/[0.08] px-3 py-2 text-[11.5px] text-coral"
          >
            {error}
          </p>
        )}
      </div>

      {importOpen && (
        <div className="card space-y-2 p-4">
          <h3 className="text-[12px] font-semibold uppercase tracking-[0.12em] text-cream">
            Import cards
          </h3>
          <p className="text-[11px] leading-relaxed text-muted">
            Paste an Anki/Quizlet export, a two-column CSV/TSV (
            <span className="font-mono">Front,Back</span>
            ), or Markdown (<span className="font-mono">Q: …</span> /{" "}
            <span className="font-mono">A: …</span>). Every imported card runs through the same
            validator; duplicates are skipped.
          </p>
          <label className="block text-[11px] text-muted">
            <span className="sr-only">Card list to import</span>
            <textarea
              value={importText}
              onChange={(event) => setImportText(event.target.value)}
              rows={5}
              placeholder={
                "Front,Back,Tags,Page\nWhat is osmosis?,The diffusion of water across a membrane.,biology,2"
              }
              className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 font-mono text-[11.5px] text-cream"
            />
          </label>
          <label className="block text-[11px] text-muted">
            Or choose a .csv / .tsv / .md file
            <input
              type="file"
              accept=".csv,.tsv,.md,.markdown,.txt"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = () => setImportText(String(reader.result ?? ""));
                reader.readAsText(file);
              }}
              className="mt-1 block w-full text-[11px] text-muted"
            />
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="btn btn-primary btn-sm"
              disabled={busyId === "import" || importText.trim().length < 8}
              onClick={() => void importCards()}
            >
              {busyId === "import" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null} Import
              cards
            </button>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => setImportOpen(false)}
            >
              Close
            </button>
          </div>
          {importNote && (
            <p role="status" className="text-[11.5px] text-lime">
              {importNote}
            </p>
          )}
        </div>
      )}

      {adding && (
        <div className="card space-y-2 p-4">
          <h3 className="text-[12px] font-semibold uppercase tracking-[0.12em] text-cream">
            New card
          </h3>
          <label className="block text-[11px] text-muted">
            Prompt (end with ? or include _____)
            <textarea
              value={newCard.prompt}
              onChange={(event) => setNewCard({ ...newCard, prompt: event.target.value })}
              rows={2}
              className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
            />
          </label>
          <label className="block text-[11px] text-muted">
            Answer
            <textarea
              value={newCard.answer}
              onChange={(event) => setNewCard({ ...newCard, answer: event.target.value })}
              rows={2}
              className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
            />
          </label>
          <div className="grid gap-2 sm:grid-cols-2">
            <label className="block text-[11px] text-muted">
              Hint (optional)
              <input
                value={newCard.hint}
                onChange={(event) => setNewCard({ ...newCard, hint: event.target.value })}
                className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
              />
            </label>
            <label className="block text-[11px] text-muted">
              Tags (comma separated)
              <input
                value={newCard.tags}
                onChange={(event) => setNewCard({ ...newCard, tags: event.target.value })}
                className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
              />
            </label>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              className="btn btn-primary btn-sm"
              disabled={busyId === "new"}
              onClick={() => void createCard()}
            >
              {busyId === "new" ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Plus className="h-3.5 w-3.5" />
              )}
              Add to deck
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAdding(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {cards.length === 0 && !loading && (
        <div className="card p-8 text-center">
          <p className="text-[13px] font-semibold text-cream">No cards match those filters.</p>
          <p className="mt-1 text-[12px] text-muted">Clear the filters, or add a card by hand.</p>
        </div>
      )}

      <ul className="space-y-2">
        {cards.map((card, index) => {
          const editing = editingId === card.id;
          return (
            <li key={card.id} className={`card p-3.5 sm:p-4 ${card.suspended ? "opacity-60" : ""}`}>
              {editing ? (
                <div className="space-y-2">
                  <label className="block text-[11px] text-muted">
                    Prompt
                    <textarea
                      value={draft.prompt}
                      onChange={(event) => setDraft({ ...draft, prompt: event.target.value })}
                      rows={2}
                      className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
                    />
                  </label>
                  <label className="block text-[11px] text-muted">
                    Answer
                    <textarea
                      value={draft.answer}
                      onChange={(event) => setDraft({ ...draft, answer: event.target.value })}
                      rows={2}
                      className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
                    />
                  </label>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <label className="block text-[11px] text-muted">
                      Hint
                      <input
                        value={draft.hint}
                        onChange={(event) => setDraft({ ...draft, hint: event.target.value })}
                        className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
                      />
                    </label>
                    <label className="block text-[11px] text-muted">
                      Tags
                      <input
                        value={draft.tags}
                        onChange={(event) => setDraft({ ...draft, tags: event.target.value })}
                        className="mt-1 w-full rounded-lg border border-line bg-ink-2/60 p-2 text-[12.5px] text-cream"
                      />
                    </label>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      disabled={busyId === card.id}
                      onClick={() => void saveEdit(card)}
                    >
                      {busyId === card.id ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        "Save"
                      )}
                    </button>
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm"
                      onClick={() => setEditingId(null)}
                    >
                      <X className="h-3.5 w-3.5" /> Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-muted">
                    <span className="rounded border border-line px-1.5 py-0.5 uppercase tracking-[0.08em]">
                      {KIND_LABEL[card.kind] ?? card.kind}
                    </span>
                    <span>page {card.page}</span>
                    {card.suspended && <span className="text-coral">suspended</span>}
                    {card.flagged && <span className="text-coral">flagged</span>}
                    {card.tags.map((tag) => (
                      <span key={tag} className="rounded bg-white/5 px-1.5 py-0.5">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <p className="mt-2 text-[13px] leading-relaxed text-cream">
                    <RichText html={card.promptHtml} text={card.prompt} />
                  </p>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-muted">
                    <span className="font-semibold text-cream/80">Answer:</span>{" "}
                    <RichText html={card.answerHtml} text={card.answer} />
                  </p>
                  <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => startEdit(card)}
                      className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 text-[11px] text-muted hover:text-cream"
                    >
                      <Pencil className="h-3 w-3" /> Edit
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        void patch(
                          `/api/cards/${card.id}`,
                          { suspended: !card.suspended },
                          card.suspended ? "Card resumed." : "Card suspended.",
                        )
                      }
                      className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 text-[11px] text-muted hover:text-cream"
                    >
                      {card.suspended ? (
                        <Play className="h-3 w-3" />
                      ) : (
                        <Pause className="h-3 w-3" />
                      )}
                      {card.suspended ? "Resume" : "Suspend"}
                    </button>
                    <button
                      type="button"
                      aria-pressed={card.flagged}
                      onClick={() =>
                        void patch(
                          `/api/cards/${card.id}`,
                          {
                            flagged: !card.flagged,
                            flagNote: card.flagged ? "" : "Flagged from the deck",
                          },
                          card.flagged ? "Flag removed." : "Thanks — flagged for engine tuning.",
                        )
                      }
                      className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] ${
                        card.flagged
                          ? "border-coral/40 text-coral"
                          : "border-line text-muted hover:text-cream"
                      }`}
                    >
                      <Flag className="h-3 w-3" /> {card.flagged ? "Unflag" : "Flag"}
                    </button>
                    <button
                      type="button"
                      onClick={() => void remove(card)}
                      className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 text-[11px] text-muted hover:border-coral/40 hover:text-coral"
                    >
                      <Trash2 className="h-3 w-3" /> Delete
                    </button>
                    {reorderable && (
                      <span className="ml-auto inline-flex items-center gap-1">
                        <button
                          type="button"
                          aria-label={`Move card ${index + 1} up`}
                          disabled={index === 0}
                          onClick={() => void move(card, -1)}
                          className="rounded-md border border-line p-1 text-muted disabled:opacity-30"
                        >
                          <ArrowUp className="h-3 w-3" />
                        </button>
                        <button
                          type="button"
                          aria-label={`Move card ${index + 1} down`}
                          disabled={index === cards.length - 1}
                          onClick={() => void move(card, 1)}
                          className="rounded-md border border-line p-1 text-muted disabled:opacity-30"
                        >
                          <ArrowDown className="h-3 w-3" />
                        </button>
                      </span>
                    )}
                  </div>
                </>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
