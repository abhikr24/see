"use client";

import RichText from "@/components/RichText";
import { useOffline } from "@/components/offline/OfflineProvider";
import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Check,
  CircleCheck,
  Loader2,
  Quote,
  RotateCcw,
  Sparkles,
  Timer,
} from "lucide-react";
import type { StudyCard } from "@/lib/ui-types";
import { KIND_LABEL } from "@/lib/ui-types";

const GRADES = [
  { grade: 0, label: "Again", tone: "border-coral/40 bg-coral/10 text-coral", hint: "10 min" },
  { grade: 1, label: "Hard", tone: "border-white/15 bg-white/5 text-cream", hint: "shorter" },
  { grade: 2, label: "Good", tone: "border-lime/40 bg-lime/10 text-lime", hint: "on track" },
  { grade: 3, label: "Easy", tone: "border-violet/40 bg-violet/10 text-violet", hint: "longer" },
] as const;

type Props = { cards: StudyCard[]; showDocument?: boolean };

function sortQueue(cards: StudyCard[]) {
  return [...cards].sort((a, b) => a.dueAt.localeCompare(b.dueAt) || a.id.localeCompare(b.id));
}

export default function ReviewRunner({ cards, showDocument = false }: Props) {
  const router = useRouter();
  const due = useMemo(() => cards.filter((card) => new Date(card.dueAt) <= new Date()), [cards]);
  const [mode, setMode] = useState<"due" | "all">(due.length > 0 ? "due" : "all");
  const queue = useMemo(() => sortQueue(mode === "due" ? due : cards), [mode, due, cards]);
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [stats, setStats] = useState({ again: 0, hard: 0, good: 0, easy: 0 });
  const [lastInterval, setLastInterval] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { online, gradeLocally } = useOffline();
  const [queued, setQueued] = useState(0);

  const card = queue[index];
  const finished = index >= queue.length;

  const grade = useCallback(
    async (value: 0 | 1 | 2 | 3) => {
      if (!card || busy) return;
      setBusy(true);
      setError(null);
      try {
        const response = await fetch(`/api/cards/${card.id}/review`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ grade: value }),
        });
        if (!response.ok) {
          if (response.status >= 500) {
            // Server trouble: keep the review on this device and move on.
            await gradeLocally(card.id, value);
            setQueued((current) => current + 1);
            setRevealed(false);
            setIndex((current) => current + 1);
            return;
          }
          setError("Could not save that grade. Check your connection and try again.");
          return;
        }
        const data = (await response.json()) as { next?: { intervalDays: number } };
        setLastInterval(data.next?.intervalDays ?? null);
        setStats((current) => ({
          ...current,
          again: current.again + (value === 0 ? 1 : 0),
          hard: current.hard + (value === 1 ? 1 : 0),
          good: current.good + (value === 2 ? 1 : 0),
          easy: current.easy + (value === 3 ? 1 : 0),
        }));
        setRevealed(false);
        setIndex((current) => current + 1);
        router.refresh();
      } catch {
        // Offline: queue the grade in IndexedDB; it replays when the network returns.
        await gradeLocally(card.id, value);
        setQueued((current) => current + 1);
        setRevealed(false);
        setIndex((current) => current + 1);
      } finally {
        setBusy(false);
      }
    },
    [busy, card, router, gradeLocally],
  );

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (!card) return;
      if (event.code === "Space") {
        event.preventDefault();
        if (!revealed) setRevealed(true);
      }
      if (["1", "2", "3", "4"].includes(event.key) && revealed) {
        event.preventDefault();
        void grade((Number(event.key) - 1) as 0 | 1 | 2 | 3);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [card, grade, revealed]);

  if (cards.length === 0) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm text-muted">This deck has no cards yet.</p>
      </div>
    );
  }

  if (finished) {
    const total = stats.again + stats.hard + stats.good + stats.easy;
    const remembered = stats.good + stats.easy;
    return (
      <div className="card p-6 text-center sm:p-8">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl border border-lime/30 bg-lime/10 text-lime">
          <CircleCheck className="h-5 w-5" />
        </span>
        <h3 className="mt-4 text-lg font-semibold text-cream">
          {total > 0 ? `${total} card${total === 1 ? "" : "s"} reviewed` : "Session complete"}
        </h3>
        <p className="mt-1.5 text-[12.5px] text-muted">
          {total > 0
            ? `${remembered} of ${total} came back without a lapse. Cards you graded Again return in ten minutes.`
            : "Nothing left in this queue."}
        </p>
        <div className="mx-auto mt-5 grid max-w-sm grid-cols-4 gap-2">
          {[
            { label: "Again", value: stats.again, tone: "text-coral" },
            { label: "Hard", value: stats.hard, tone: "text-cream" },
            { label: "Good", value: stats.good, tone: "text-lime" },
            { label: "Easy", value: stats.easy, tone: "text-violet" },
          ].map((item) => (
            <div key={item.label} className="rounded-lg border border-line bg-white/[0.03] py-2">
              <p className={`text-base font-semibold ${item.tone}`}>{item.value}</p>
              <p className="text-[10px] text-muted">{item.label}</p>
            </div>
          ))}
        </div>
        <div className="mt-5 flex flex-col justify-center gap-2 sm:flex-row">
          <button
            type="button"
            className="btn btn-primary btn-sm"
            onClick={() => {
              setIndex(0);
              setStats({ again: 0, hard: 0, good: 0, easy: 0 });
              setMode("all");
            }}
          >
            <RotateCcw className="h-3.5 w-3.5" /> Practice all cards
          </button>
          <Link href="/app" className="btn btn-ghost btn-sm">
            Back to overview
          </Link>
        </div>
      </div>
    );
  }

  const progress = Math.round((index / queue.length) * 100);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              setMode("due");
              setIndex(0);
              setRevealed(false);
            }}
            className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition ${
              mode === "due" ? "bg-lime text-ink" : "border border-line text-muted hover:text-cream"
            }`}
          >
            Due now ({due.length})
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("all");
              setIndex(0);
              setRevealed(false);
            }}
            className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition ${
              mode === "all" ? "bg-lime text-ink" : "border border-line text-muted hover:text-cream"
            }`}
          >
            All cards ({cards.length})
          </button>
        </div>
        <p className="text-[11px] text-muted">
          {index + 1} / {queue.length}
        </p>
      </div>

      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/8">
        <div
          className="h-full rounded-full bg-lime transition-all"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="card overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="rounded-full border border-line bg-white/5 px-2 py-0.5 text-[9.5px] font-semibold uppercase tracking-[0.1em] text-muted">
              {KIND_LABEL[card.kind] ?? card.kind}
            </span>
            {showDocument && <span className="text-[10.5px] text-muted">page {card.page}</span>}
            {card.reps === 0 && <span className="chip chip-lime py-0.5">new</span>}
          </div>
          <span className="inline-flex items-center gap-1 text-[10.5px] text-muted">
            <Timer className="h-3 w-3" /> eases {card.ease.toFixed(2)}
          </span>
        </div>

        <div className="p-4 sm:p-6">
          <p className="whitespace-pre-line text-[15.5px] leading-relaxed text-cream sm:text-base">
            <RichText html={card.promptHtml} text={card.prompt} />
          </p>

          {!revealed ? (
            <div className="mt-5">
              <p className="inline-flex items-center gap-1.5 rounded-lg border border-line bg-white/[0.03] px-2.5 py-1.5 text-[11.5px] text-muted">
                <Sparkles className="h-3 w-3 text-lime" /> {card.hint}
              </p>
              <button
                type="button"
                className="btn btn-primary mt-4 w-full sm:w-auto"
                onClick={() => setRevealed(true)}
              >
                Show answer <span className="ml-1 font-mono text-[10px] opacity-60">space</span>
              </button>
              <p className="mt-3 text-[12px] leading-relaxed text-muted">
                Say the answer out loud before revealing it. Recognition feels like knowledge;
                recall is the real test.
              </p>
            </div>
          ) : (
            <div className="animate-flip-in mt-5">
              <div className="rounded-xl border border-lime/25 bg-lime/[0.06] p-3.5">
                <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-lime">
                  Answer
                </p>
                <p className="mt-1 whitespace-pre-line text-[14.5px] font-medium leading-relaxed text-cream">
                  <RichText html={card.answerHtml} text={card.answer} />
                </p>
              </div>

              {card.quote && (
                <div className="mt-3 rounded-xl border border-line bg-white/[0.02] p-3">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted">
                    From your source · page {card.page}
                  </p>
                  <p className="mt-1 flex gap-1.5 text-[11.5px] leading-relaxed text-muted">
                    <Quote className="mt-0.5 h-3 w-3 shrink-0" />
                    {card.quote}
                  </p>
                </div>
              )}

              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {GRADES.map((option) => (
                  <button
                    key={option.grade}
                    type="button"
                    disabled={busy}
                    onClick={() => void grade(option.grade)}
                    className={`rounded-xl border px-2 py-2.5 text-center transition hover:brightness-110 disabled:opacity-50 ${option.tone}`}
                  >
                    <span className="block text-[12px] font-semibold">{option.label}</span>
                    <span className="mt-0.5 block text-[9.5px] uppercase tracking-[0.1em] opacity-70">
                      {option.grade + 1} · {option.hint}
                    </span>
                  </button>
                ))}
              </div>
              {busy && (
                <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted">
                  <Loader2 className="h-3 w-3 animate-spin" /> Saving grade…
                </p>
              )}
              {lastInterval !== null && !busy && (
                <p className="mt-2 inline-flex items-center gap-1.5 text-[11px] text-lime">
                  <Check className="h-3 w-3" /> Scheduled — next interval{" "}
                  {lastInterval < 1 ? "under a day" : `${lastInterval.toFixed(1)} days`}
                </p>
              )}
            </div>
          )}

          {error && (
            <p role="alert" className="mt-3 text-[11.5px] text-coral">
              {error}
            </p>
          )}
          {(queued > 0 || !online) && (
            <p
              role="status"
              aria-live="polite"
              className="mt-3 rounded-lg border border-violet/30 bg-violet/10 px-2.5 py-2 text-[11px] text-violet"
            >
              Saved on this device
              {queued > 0 ? ` (${queued} review${queued === 1 ? "" : "s"} queued)` : ""}. They sync
              automatically when you are back online.
            </p>
          )}
        </div>
      </div>

      <details className="card-flat px-3.5 py-2.5 text-[11.5px] text-muted">
        <summary className="cursor-pointer font-semibold text-cream/85">Keyboard shortcuts</summary>
        <ul className="mt-2 space-y-1">
          <li>
            <kbd className="rounded border border-line px-1">Space</kbd> reveal the answer
          </li>
          <li>
            <kbd className="rounded border border-line px-1">1</kbd> Again ·{" "}
            <kbd className="rounded border border-line px-1">2</kbd> Hard ·{" "}
            <kbd className="rounded border border-line px-1">3</kbd> Good ·{" "}
            <kbd className="rounded border border-line px-1">4</kbd> Easy
          </li>
          <li>
            <kbd className="rounded border border-line px-1">?</kbd> open this sheet (browser find
            is disabled while reviewing)
          </li>
        </ul>
      </details>

      <p className="sr-only" aria-live="polite">
        {revealed ? "Answer revealed. Grade with 1 to 4." : "Answer hidden. Press space to reveal."}
      </p>

      <div
        className="flex items-center justify-between gap-2"
        style={{ scrollMarginBottom: "var(--bottom-nav-clearance)" }}
      >
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={() => {
            setIndex((current) => Math.max(0, current - 1));
            setRevealed(false);
          }}
          disabled={index === 0}
        >
          Previous
        </button>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={() => {
            setIndex((current) => Math.min(queue.length, current + 1));
            setRevealed(false);
          }}
          disabled={index >= queue.length - 1}
        >
          Skip <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
