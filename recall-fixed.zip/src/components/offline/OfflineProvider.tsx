"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import { CloudOff, RefreshCw } from "lucide-react";
import { flushQueue, indexedDbStore, queueReview, type QueueStore } from "@/lib/offline/queue";
import type { ReviewGrade } from "@/lib/memory/types";

type OfflineContextValue = {
  online: boolean;
  pending: number;
  gradeLocally: (cardId: string, grade: ReviewGrade) => Promise<void>;
  sync: () => Promise<void>;
};

const OfflineContext = createContext<OfflineContextValue | null>(null);

export function useOffline(): OfflineContextValue {
  return (
    useContext(OfflineContext) ?? {
      online: true,
      pending: 0,
      gradeLocally: async () => {},
      sync: async () => {},
    }
  );
}

/** Subscribe to the browser's online/offline events without setState-in-effect. */
function useOnlineStatus(): boolean {
  return useSyncExternalStore(
    (onChange) => {
      window.addEventListener("online", onChange);
      window.addEventListener("offline", onChange);
      return () => {
        window.removeEventListener("online", onChange);
        window.removeEventListener("offline", onChange);
      };
    },
    () => navigator.onLine,
    () => true,
  );
}

export default function OfflineProvider({ children }: { children: React.ReactNode }) {
  // The store is created on first use and never read during render.
  const storeRef = useRef<QueueStore | null>(null);
  const store = useCallback((): QueueStore => {
    if (!storeRef.current) storeRef.current = indexedDbStore();
    return storeRef.current;
  }, []);
  const online = useOnlineStatus();
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const refresh = useCallback(async () => {
    setPending((await store().all()).length);
  }, [store]);

  const sync = useCallback(async () => {
    if (syncing || typeof navigator === "undefined" || !navigator.onLine) return;
    setSyncing(true);
    try {
      const result = await flushQueue(store(), async (item) => {
        const response = await fetch(`/api/cards/${item.cardId}/review`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ grade: item.grade }),
        });
        return { ok: response.ok, status: response.status };
      });
      setPending(result.remaining);
      if (result.synced > 0) window.location.reload();
    } finally {
      setSyncing(false);
    }
  }, [store, syncing]);

  // Mount: register the worker, count queued reviews and replay when reconnected.
  // State is only set from async callbacks, never synchronously in the effect body.
  useEffect(() => {
    let cancelled = false;
    void refresh();

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
        // A failed registration must not break the app; the queue still works.
      });
    }

    const goOnline = () => {
      if (!cancelled) void sync();
    };
    window.addEventListener("online", goOnline);
    return () => {
      cancelled = true;
      window.removeEventListener("online", goOnline);
    };
  }, [refresh, sync]);

  const gradeLocally = useCallback(
    async (cardId: string, grade: ReviewGrade) => {
      await queueReview(store(), { cardId, grade });
      setPending((await store().all()).length);
    },
    [store],
  );

  const value = useMemo(
    () => ({ online, pending, gradeLocally, sync }),
    [online, pending, gradeLocally, sync],
  );

  return (
    <OfflineContext.Provider value={value}>
      {children}
      {(!online || pending > 0) && (
        <div
          role="status"
          aria-live="polite"
          className="fixed inset-x-3 bottom-20 z-40 mx-auto flex max-w-md items-center gap-2 rounded-xl border border-violet/40 bg-ink-2/95 px-3 py-2.5 text-[11.5px] text-cream shadow-lg backdrop-blur lg:bottom-5"
        >
          <CloudOff className="h-4 w-4 shrink-0 text-violet" />
          <span className="flex-1">
            {pending > 0
              ? `${pending} review${pending === 1 ? "" : "s"} waiting to sync${online ? "" : " (offline)"}`
              : "You are offline. Reviews you grade are queued on this device."}
          </span>
          {pending > 0 && online && (
            <button
              type="button"
              onClick={() => void sync()}
              className="inline-flex items-center gap-1 rounded-md border border-line px-2 py-1 font-semibold text-lime"
              disabled={syncing}
            >
              <RefreshCw className={`h-3 w-3 ${syncing ? "animate-spin" : ""}`} /> Sync
            </button>
          )}
        </div>
      )}
    </OfflineContext.Provider>
  );
}
