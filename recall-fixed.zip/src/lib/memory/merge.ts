import type { MemoryCard } from "./types";

/** Normalised identity for duplicate detection: case/punctuation-insensitive. */
export function deckKey(card: Pick<MemoryCard, "prompt" | "answer">): string {
  const normalise = (value: string) =>
    value
      .toLowerCase()
      .replace(/[_]+/g, " ")
      .replace(/[^a-z0-9\s]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  return `${normalise(card.answer)}::${normalise(card.prompt)}`;
}

/**
 * Combine AI cards with the deterministic rules deck.
 *
 * AI cards come first (they are the reason the user paid), then every rules card
 * that does not duplicate an AI card. The rules deck is never discarded: a small
 * or partial AI response can only add to it, never shrink it. The merged deck is
 * capped at the requested card count when one was given.
 *
 * This is the single behaviour ported from the older build, rewritten to keep
 * rule-card ordering stable and to dedupe on a normalised answer+prompt key.
 */
export function mergeDecks(
  aiCards: MemoryCard[],
  ruleCards: MemoryCard[],
  targetCount?: number,
): { cards: MemoryCard[]; aiCount: number; ruleCount: number; duplicates: number } {
  const seen = new Set<string>();
  const merged: MemoryCard[] = [];

  for (const card of aiCards) {
    const key = deckKey(card);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    merged.push(card);
  }
  const aiCount = merged.length;

  let duplicates = 0;
  for (const card of ruleCards) {
    const key = deckKey(card);
    if (!key) continue;
    if (seen.has(key)) {
      duplicates += 1;
      continue;
    }
    seen.add(key);
    merged.push(card);
  }

  const cap =
    typeof targetCount === "number" && Number.isFinite(targetCount) && targetCount > 0
      ? Math.max(targetCount, aiCount)
      : merged.length;
  const cards = merged.slice(0, cap);

  return {
    cards,
    aiCount: cards.filter((card) => aiCards.includes(card)).length,
    ruleCount: cards.length - cards.filter((card) => aiCards.includes(card)).length,
    duplicates,
  };
}
