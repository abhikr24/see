import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import path from "node:path";

/**
 * Tesseract language data is cached on disk, never fetched from a CDN at request
 * time (tesseract.js checks `cachePath` first and only falls back to `langPath`).
 * Populate it at deploy time with `npm run ocr:fetch-data` (eng, or eng+hin).
 */
export function ocrCachePath(): string {
  const configured = process.env.TESSERACT_CACHE_PATH?.trim();
  return configured ? path.resolve(configured) : path.join(process.cwd(), ".tesseract");
}

export function languageFile(language: string): string {
  return path.join(ocrCachePath(), `${language}.traineddata`);
}

export function hasLanguageData(language: string): boolean {
  try {
    return existsSync(languageFile(language)) && readFileSync(languageFile(language)).length > 1000;
  } catch {
    return false;
  }
}

export function cachedLanguages(languages: string[]): string[] {
  return languages.filter(hasLanguageData);
}

export type SmokeRecord = { at: string; languages: string[]; sample: string };

function smokeFile(): string {
  return path.join(ocrCachePath(), "smoke.json");
}

export function readSmokeRecord(): SmokeRecord | null {
  try {
    return JSON.parse(readFileSync(smokeFile(), "utf8")) as SmokeRecord;
  } catch {
    return null;
  }
}

export function writeSmokeRecord(record: SmokeRecord): void {
  try {
    mkdirSync(ocrCachePath(), { recursive: true });
    writeFileSync(smokeFile(), JSON.stringify(record, null, 2));
  } catch {
    // Recording the smoke result is best-effort; OCR itself already succeeded.
  }
}

export function cacheSummary(): { path: string; files: string[] } {
  try {
    return { path: ocrCachePath(), files: readdirSync(ocrCachePath()) };
  } catch {
    return { path: ocrCachePath(), files: [] };
  }
}
