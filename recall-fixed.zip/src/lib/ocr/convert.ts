import { analyzeSource } from "@/lib/memory/engine";
import { extractPdfWithOcr } from "@/lib/pdf";
import { createSource } from "@/lib/repository";

export type OcrConversionResult = {
  documentId: string;
  pagesOcred: number;
  warnings: string[];
  cardCount: number;
};

/**
 * OCR a scanned PDF, then run the normal deterministic pipeline and persist the
 * deck. Text extraction and rasterisation each receive their own byte copy
 * (see renderPdfPages) because pdf.js detaches the buffers it is given.
 */
export async function convertPdfToDeck(input: {
  userId: string;
  title: string;
  buffer: ArrayBuffer;
  onProgress: (info: { page: number; pages: number; status: string }) => void;
}): Promise<OcrConversionResult> {
  const extracted = await extractPdfWithOcr(input.buffer.slice(0), {
    enableOcr: true,
    onProgress: input.onProgress,
  });

  const pages = extracted.pages.filter((page) => page.trim().length > 0);
  if (pages.length === 0) {
    throw Object.assign(new Error("OCR found no readable text in this PDF."), {
      code: "OCR_FAILED",
    });
  }

  const preview = analyzeSource({ title: input.title, pages });
  const document = await createSource({
    userId: input.userId,
    title: input.title,
    sourceType: "pdf",
    fileName: `${input.title}.pdf`,
    pages,
    engine: "rules",
    ocr: true,
  });

  return {
    documentId: document.id,
    pagesOcred: extracted.pagesOcred,
    warnings: extracted.warnings,
    cardCount: preview.cards.length,
  };
}
