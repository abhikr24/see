import { randomUUID } from "node:crypto";
import { convertPdfToDeck, type OcrConversionResult } from "./convert";

export type OcrJobStatus = "queued" | "reading" | "done" | "failed";

export type OcrJob = {
  id: string;
  userId: string;
  status: OcrJobStatus;
  page: number;
  pages: number;
  stage: string;
  createdAt: number;
  updatedAt: number;
  title: string;
  result?: OcrConversionResult;
  error?: { code: string; message: string };
};

const JOB_TTL_MS = 30 * 60 * 1000;
const jobs = new Map<string, OcrJob>();

function sweep(): void {
  const cutoff = Date.now() - JOB_TTL_MS;
  for (const [id, job] of jobs) {
    if (job.updatedAt < cutoff) jobs.delete(id);
  }
}

export function createOcrJob(input: { userId: string; title: string }): OcrJob {
  sweep();
  const job: OcrJob = {
    id: randomUUID(),
    userId: input.userId,
    status: "queued",
    page: 0,
    pages: 0,
    stage: "Queued",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    title: input.title,
  };
  jobs.set(job.id, job);
  return job;
}

/** Ownership-scoped: another user's job is indistinguishable from a missing one. */
export function getOcrJob(userId: string, id: string): OcrJob | null {
  const job = jobs.get(id);
  if (!job || job.userId !== userId) return null;
  return job;
}

export function updateOcrJob(id: string, patch: Partial<Omit<OcrJob, "id" | "userId">>): void {
  const job = jobs.get(id);
  if (!job) return;
  jobs.set(id, { ...job, ...patch, updatedAt: Date.now() });
}

export function publicJob(job: OcrJob) {
  return {
    id: job.id,
    status: job.status,
    page: job.page,
    pages: job.pages,
    stage: job.stage,
    title: job.title,
    documentId: job.result?.documentId ?? null,
    pagesOcred: job.result?.pagesOcred ?? 0,
    warnings: job.result?.warnings ?? [],
    error: job.error ?? null,
  };
}

export type JobRunnerDeps = {
  convert: (input: {
    userId: string;
    title: string;
    buffer: ArrayBuffer;
    onProgress: (info: { page: number; pages: number; status: string }) => void;
  }) => Promise<OcrConversionResult>;
};

export const defaultJobRunnerDeps: JobRunnerDeps = { convert: convertPdfToDeck };

/**
 * Run OCR out-of-band so the upload request returns immediately. The browser
 * polls GET /api/ocr/jobs/[id] and shows "Reading page 4 of 12".
 */
export function startOcrJob(
  job: OcrJob,
  input: { userId: string; title: string; buffer: ArrayBuffer },
  deps: JobRunnerDeps = defaultJobRunnerDeps,
): void {
  updateOcrJob(job.id, { status: "reading", stage: "Opening the PDF" });
  void (async () => {
    try {
      const result = await deps.convert({
        userId: input.userId,
        title: input.title,
        buffer: input.buffer.slice(0),
        onProgress: (info) => {
          const stage =
            info.status === "reading"
              ? `Reading page ${info.page} of ${info.pages}`
              : info.status === "done"
                ? `Finished page ${info.page} of ${info.pages}`
                : info.status;
          updateOcrJob(job.id, { page: info.page, pages: info.pages, stage });
        },
      });
      updateOcrJob(job.id, {
        status: "done",
        stage: "Done",
        result,
        page: result.pagesOcred,
        pages: result.pagesOcred,
      });
    } catch (error) {
      const code =
        error && typeof error === "object" && "code" in error
          ? String((error as { code?: unknown }).code)
          : "OCR_FAILED";
      const message = error instanceof Error ? error.message : "OCR failed.";
      console.error("ocr_job_failed", { jobId: job.id, code, message });
      updateOcrJob(job.id, {
        status: "failed",
        stage: "Failed",
        error: { code, message },
      });
    }
  })();
}
