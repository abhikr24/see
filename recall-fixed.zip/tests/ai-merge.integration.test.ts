import { beforeEach, describe, expect, it, vi } from "vitest";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { aiEvents, cards, documents, users } from "@/db/schema";
import type { MemoryCard } from "@/lib/memory/types";
import type { SessionUser } from "@/lib/auth";

/**
 * Task 4 acceptance at the API level, with a stand-in AI provider:
 *  - 2 AI cards + the rules deck (≈13) and exactly one credit charged
 *  - provider failure → rules-only deck, no charge, engine label = rules
 */
const session = vi.hoisted(() => ({ user: null as SessionUser | null }));
const generate = vi.hoisted(() => vi.fn());

vi.mock("@/lib/auth", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/auth")>();
  return { ...actual, getCurrentUser: async () => session.user };
});

vi.mock("@/lib/ai/provider", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/ai/provider")>();
  return { ...actual, generateWithAi: generate };
});

const { resetDatabase } = await import("./setup/db");
const { POST: uploadDocument } = await import("@/app/api/documents/route");

const TEXT = `Chapter 5 - Membranes

Diffusion is the net movement of particles from a region of higher concentration to a region of lower concentration. Diffusion stops when the concentration gradient disappears and the system reaches equilibrium.

Osmosis is the diffusion of water across a selectively permeable membrane. Water moves from a dilute solution to a concentrated solution during osmosis. A red blood cell placed in a hypertonic solution loses water and shrinks.

Active transport moves substances against their concentration gradient and therefore requires energy from ATP. The sodium potassium pump moves three sodium ions out of the cell for every two potassium ions it brings in. The resting potential of a typical neuron is approximately -70 mV.`;

function aiCard(prompt: string, answer: string): MemoryCard {
  return {
    kind: "ai",
    prompt,
    answer,
    hint: "",
    cloze: null,
    quote: "",
    page: 1,
    options: [],
    explanation: "",
    tags: ["ai"],
  };
}

async function proUser(): Promise<SessionUser> {
  const [row] = await db
    .insert(users)
    .values({ email: "pro@example.com", name: "Pro", passwordHash: "x", plan: "pro", aiCredits: 2 })
    .returning();
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    plan: "pro",
    aiCredits: row.aiCredits,
    streak: 0,
    lastStudiedOn: null,
  };
}

const request = () =>
  new Request("http://localhost/api/documents", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ title: "AI merge deck", text: TEXT, engine: "ai", cardCount: 13 }),
  });

beforeEach(async () => {
  await resetDatabase();
  generate.mockReset();
  session.user = await proUser();
});

describe("AI merge acceptance", () => {
  it("adds two AI cards to the rules deck and charges exactly one credit", async () => {
    generate.mockResolvedValue({
      ok: true,
      provider: "Stub",
      model: "stub-1",
      cards: [
        aiCard("What is a membrane?", "A phospholipid bilayer"),
        aiCard("What is ATP?", "Cellular energy"),
      ],
      summary: "Stub summary",
      keyPoints: [],
      recallPrompts: [],
      usage: { inputTokens: 100, outputTokens: 20, totalTokens: 120, costUsd: 0.0001 },
      droppedCards: 0,
    });

    const response = await uploadDocument(request());
    const body = (await response.json()) as { id: string; engine: string };
    expect(response.status).toBe(200);
    expect(body.engine).toBe("ai");

    const rows = await db.select().from(cards).where(eq(cards.documentId, body.id));
    expect(rows.length).toBeGreaterThanOrEqual(3);
    expect(rows.filter((row) => row.kind === "ai")).toHaveLength(2);
    // The rules deck survives: the merged deck is far larger than the 2 AI cards.
    expect(rows.filter((row) => row.kind !== "ai").length).toBeGreaterThanOrEqual(2);

    const [account] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.user?.id ?? ""));
    expect(account.aiCredits).toBe(1);

    const events = await db.select().from(aiEvents).where(eq(aiEvents.userId, account.id));
    expect(events).toHaveLength(1);
    expect(events[0].credits).toBe(1);
    expect(events[0].tokens).toBe(120);

    const [doc] = await db.select().from(documents).where(eq(documents.id, body.id));
    expect(doc.engine).toBe("ai");
    expect(doc.requestedEngine).toBe("ai");
    expect(doc.analysis.warnings.some((warning) => warning.includes("AI added 2"))).toBe(true);
  });

  it("falls back to rules with no charge when the provider returns 500", async () => {
    generate.mockResolvedValue({
      ok: false,
      provider: "Stub",
      model: "stub-1",
      code: "AI_PROVIDER_ERROR",
      reason: "provider_error",
      message: "The AI provider had a problem, so nothing was charged.",
    });

    const response = await uploadDocument(request());
    const body = (await response.json()) as { id: string; engine: string; aiCode: string };
    expect(response.status).toBe(200);
    expect(body.engine).toBe("rules");
    expect(body.aiCode).toBe("AI_PROVIDER_ERROR");

    const rows = await db.select().from(cards).where(eq(cards.documentId, body.id));
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.every((row) => row.kind !== "ai")).toBe(true);

    const [account] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.user?.id ?? ""));
    expect(account.aiCredits).toBe(2);

    const [doc] = await db.select().from(documents).where(eq(documents.id, body.id));
    expect(doc.engine).toBe("rules");
    expect(doc.requestedEngine).toBe("ai");
  });
});
