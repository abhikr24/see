import { readFileSync } from "node:fs";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { cards, documents, reviews, users } from "@/db/schema";
import type { SessionUser } from "@/lib/auth";

/**
 * API-level tests: the route handlers run for real against the PostgreSQL
 * service container. Only authentication is mocked (there is no browser cookie
 * jar inside vitest); every query, scope and mutation is real.
 */
const session = vi.hoisted(() => ({ user: null as SessionUser | null }));

vi.mock("@/lib/auth", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/auth")>();
  return {
    ...actual,
    getCurrentUser: async () => session.user,
    requireUser: async () => {
      if (!session.user) throw new Error("UNAUTHENTICATED");
      return session.user;
    },
  };
});

const { resetDatabase } = await import("./setup/db");
const { POST: uploadDocument } = await import("@/app/api/documents/route");
const {
  GET: getCards,
  POST: createCard,
  PATCH: reorderCards,
} = await import("@/app/api/documents/[id]/cards/route");
const { PATCH: patchCard, DELETE: deleteCard } = await import("@/app/api/cards/[id]/route");
const { POST: postReview } = await import("@/app/api/cards/[id]/review/route");
const { POST: postQuiz } = await import("@/app/api/quiz/route");
const { GET: exportDeck } = await import("@/app/api/export/[id]/route");
const { POST: loginRoute } = await import("@/app/api/auth/login/route");
const { POST: checkoutRoute } = await import("@/app/api/billing/checkout/route");
const { POST: webhookRoute } = await import("@/app/api/billing/webhook/route");
const { DELETE: deleteDocument } = await import("@/app/api/documents/[id]/route");
const { GET: getJob } = await import("@/app/api/ocr/jobs/[id]/route");
const { POST: importCards } = await import("@/app/api/documents/[id]/import/route");

const CONTENT = readFileSync("tests/fixtures/text-chapter.pdf");
const SCANNED = readFileSync("tests/fixtures/scanned-handout.pdf");
const TEXT = `Diffusion is the net movement of particles from a region of higher concentration to a region of lower concentration. Osmosis is the diffusion of water across a selectively permeable membrane. The cell membrane is a phospholipid bilayer with embedded proteins that control transport.`;

let owner: SessionUser;
let intruder: SessionUser;

async function makeUser(email: string): Promise<SessionUser> {
  const [row] = await db
    .insert(users)
    .values({ email, name: email.split("@")[0], passwordHash: "unused-in-tests", plan: "free" })
    .returning();
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    plan: "free",
    aiCredits: 0,
    streak: 0,
    lastStudiedOn: null,
  };
}

function jsonRequest(body: unknown, headers: Record<string, string> = {}): Request {
  return new Request("http://localhost/api", {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
  });
}

function pdfRequest(bytes: Buffer, name: string, extra: Record<string, string> = {}): Request {
  const form = new FormData();
  // Copy into a plain ArrayBuffer: Buffer's backing store is ArrayBufferLike and
  // is not a valid BlobPart under strict lib.dom typings.
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  form.set("file", new File([copy.buffer], name, { type: "application/pdf" }));
  form.set("engine", "rules");
  for (const [key, value] of Object.entries(extra)) form.set(key, value);
  return new Request("http://localhost/api/documents", { method: "POST", body: form });
}

const params = (id: string) => ({ params: Promise.resolve({ id }) });

async function createDeck(): Promise<string> {
  const response = await uploadDocument(
    jsonRequest({ title: "Integration deck", text: TEXT, engine: "rules" }),
  );
  const body = (await response.json()) as { id: string };
  expect(response.status).toBe(200);
  return body.id;
}

beforeEach(async () => {
  await resetDatabase();
  delete process.env.STRIPE_SECRET_KEY;
  delete process.env.STRIPE_WEBHOOK_SECRET;
  process.env.ALLOW_DEMO_BILLING = "false";
  owner = await makeUser("owner@example.com");
  intruder = await makeUser("intruder@example.com");
  session.user = owner;
});

describe("upload API", () => {
  it("creates a deck from pasted text", async () => {
    const id = await createDeck();
    const rows = await db.select().from(cards).where(eq(cards.documentId, id));
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.every((row) => row.userId === owner.id)).toBe(true);
  });

  it("rejects text that is too short", async () => {
    const response = await uploadDocument(jsonRequest({ text: "Too short.", title: "x" }));
    expect(response.status).toBe(422);
    expect((await response.json()).code).toBe("TOO_SHORT");
  });

  it("rejects an invalid JSON body", async () => {
    const response = await uploadDocument(jsonRequest({ title: "no text" }));
    expect(response.status).toBe(400);
  });

  it("extracts a real text PDF", async () => {
    const response = await uploadDocument(
      pdfRequest(CONTENT, "chapter.pdf", { title: "PDF deck" }),
    );
    const body = (await response.json()) as { id: string; engine: string };
    expect(response.status).toBe(200);
    expect(body.engine).toBe("rules");
    const [doc] = await db.select().from(documents).where(eq(documents.id, body.id));
    expect(doc.pageCount).toBe(2);
    expect(doc.ocr).toBe(false);
  });

  it("returns NO_TEXT_LAYER with ocrAvailable for a scanned PDF", async () => {
    const response = await uploadDocument(pdfRequest(SCANNED, "scan.pdf", { title: "Scan" }));
    const body = (await response.json()) as { code: string; ocrAvailable: boolean };
    expect(response.status).toBe(422);
    expect(body.code).toBe("NO_TEXT_LAYER");
    expect(typeof body.ocrAvailable).toBe("boolean");
  });

  it("rejects a file that is too large", async () => {
    const huge = Buffer.alloc(12 * 1024 * 1024 + 10, 0);
    const response = await uploadDocument(pdfRequest(huge, "huge.pdf"));
    expect(response.status).toBe(413);
  });

  it("rejects an unsupported file type", async () => {
    const form = new FormData();
    form.set(
      "file",
      new File([Buffer.from("hello")], "notes.exe", { type: "application/octet-stream" }),
    );
    const response = await uploadDocument(
      new Request("http://localhost/api/documents", { method: "POST", body: form }),
    );
    expect(response.status).toBe(415);
  });

  it("requires authentication", async () => {
    session.user = null;
    const response = await uploadDocument(jsonRequest({ text: TEXT }));
    expect(response.status).toBe(401);
  });
});

describe("card CRUD and isolation", () => {
  it("lists, edits, suspends and flags a card", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string }[] };
    expect(rows.length).toBeGreaterThan(0);

    const edited = await patchCard(
      jsonRequest({ answer: "Updated answer text", suspended: true, flagged: true }),
      params(rows[0].id),
    );
    expect(edited.status).toBe(200);
    const updated = (await edited.json()) as { card: { answer: string; suspended: boolean } };
    expect(updated.card.answer).toBe("Updated answer text");
    expect(updated.card.suspended).toBe(true);
  });

  it("rejects an edit that would produce an invalid card", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string; answer: string }[] };
    const response = await patchCard(
      jsonRequest({ prompt: "No question mark or blank" }),
      params(rows[0].id),
    );
    expect(response.status).toBe(422);
  });

  it("adds a card by hand and reorders the deck", async () => {
    const documentId = await createDeck();
    const created = await createCard(
      jsonRequest({ prompt: "What is a phospholipid bilayer?", answer: "The cell membrane" }),
      params(documentId),
    );
    expect(created.status).toBe(201);
    const body = (await created.json()) as { card: { id: string } };

    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string }[] };
    const order = [
      body.card.id,
      ...rows.filter((row) => row.id !== body.card.id).map((row) => row.id),
    ];
    const reordered = await reorderCards(jsonRequest({ order }), params(documentId));
    expect(reordered.status).toBe(200);
  });

  it("deletes a card and refuses another user's card", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string }[] };

    session.user = intruder;
    expect(
      (
        await deleteCard(
          new Request("http://localhost/api", { method: "DELETE" }),
          params(rows[0].id),
        )
      ).status,
    ).toBe(404);
    expect(
      (await getCards(new Request("http://localhost/api/cards"), params(documentId))).status,
    ).toBe(404);

    session.user = owner;
    expect(
      await deleteCard(
        new Request("http://localhost/api", { method: "DELETE" }),
        params(rows[0].id),
      ),
    ).toBeTruthy();
  });

  it("imports cards from CSV and skips duplicates", async () => {
    const documentId = await createDeck();
    const csv = "Front,Back\nWhat is a phospholipid bilayer?,The cell membrane";
    const first = await importCards(jsonRequest({ content: csv }), params(documentId));
    expect(first.status).toBe(200);
    expect((await first.json()).imported).toBe(1);
    const second = await importCards(jsonRequest({ content: csv }), params(documentId));
    expect(second.status).toBe(409);
  });
});

describe("review scheduling", () => {
  it("advances FSRS state and records a review", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string }[] };

    const response = await postReview(jsonRequest({ grade: 2, seconds: 12 }), params(rows[0].id));
    const body = (await response.json()) as { next: { intervalDays: number; stability: number } };
    expect(response.status).toBe(200);
    expect(body.next.stability).toBeGreaterThan(0);

    const stored = await db.select().from(reviews).where(eq(reviews.cardId, rows[0].id));
    expect(stored).toHaveLength(1);
    const [card] = await db.select().from(cards).where(eq(cards.id, rows[0].id));
    expect(card.reps).toBe(1);
  });

  it("refuses another user's card", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string }[] };
    session.user = intruder;
    const response = await postReview(jsonRequest({ grade: 3 }), params(rows[0].id));
    expect(response.status).toBe(404);
  });

  it("rejects an out-of-range grade", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as { cards: { id: string }[] };
    expect((await postReview(jsonRequest({ grade: 9 }), params(rows[0].id))).status).toBe(400);
  });
});

describe("quiz scoring", () => {
  it("recomputes the score server-side from choices", async () => {
    const documentId = await createDeck();
    const listed = await getCards(new Request("http://localhost/api/cards"), params(documentId));
    const { cards: rows } = (await listed.json()) as {
      cards: { id: string; answer: string }[];
    };
    const answers = [
      { cardId: rows[0].id, choice: rows[0].answer },
      { cardId: rows[1].id, choice: "definitely wrong" },
    ];
    const response = await postQuiz(jsonRequest({ documentId, answers }));
    const body = (await response.json()) as { score: number; total: number };
    expect(response.status).toBe(200);
    expect(body.total).toBe(2);
    expect(body.score).toBeGreaterThanOrEqual(1);
  });

  it("rejects a client-supplied score", async () => {
    const documentId = await createDeck();
    const response = await postQuiz(jsonRequest({ documentId, score: 100, total: 10 }));
    expect(response.status).toBe(400);
  });

  it("returns 404 for another user's document", async () => {
    const documentId = await createDeck();
    session.user = intruder;
    const response = await postQuiz(
      jsonRequest({ documentId, answers: [{ cardId: crypto.randomUUID(), choice: "x" }] }),
    );
    expect(response.status).toBe(404);
  });
});

describe("exports", () => {
  it("serves CSV with Anki headers", async () => {
    const documentId = await createDeck();
    const response = await exportDeck(
      new Request("http://localhost/api/export/x?format=csv"),
      params(documentId),
    );
    const text = await response.text();
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toContain("text/csv");
    expect(response.headers.get("content-disposition")).toContain(".csv");
    expect(text).toContain("#separator:Comma");
    expect(text).toContain('"Front","Back","Tags","Page"');
  });

  it("serves TSV, JSON and Markdown exports", async () => {
    const documentId = await createDeck();
    for (const [format, type] of [
      ["tsv", "text/tab-separated-values"],
      ["json", "application/json"],
      ["md", "text/markdown"],
    ]) {
      const response = await exportDeck(
        new Request(`http://localhost/api/export/x?format=${format}`),
        params(documentId),
      );
      expect(response.status).toBe(200);
      expect(response.headers.get("content-type")).toContain(type);
    }
  });

  it("returns 404 for another user's deck", async () => {
    const documentId = await createDeck();
    session.user = intruder;
    const response = await exportDeck(
      new Request("http://localhost/api/export/x?format=csv"),
      params(documentId),
    );
    expect(response.status).toBe(404);
  });
});

describe("document deletion and OCR job scoping", () => {
  it("deletes only the owner's document", async () => {
    const documentId = await createDeck();
    session.user = intruder;
    expect(
      (await deleteDocument(new Request("http://localhost/api"), params(documentId))).status,
    ).toBe(404);
    session.user = owner;
    expect(
      (await deleteDocument(new Request("http://localhost/api"), params(documentId))).status,
    ).toBe(200);
  });

  it("hides other users' OCR jobs", async () => {
    const response = await getJob(new Request("http://localhost/api"), params(crypto.randomUUID()));
    expect(response.status).toBe(404);
  });
});

describe("rate limiting", () => {
  it("returns 429 after five failed logins from one IP", async () => {
    delete process.env.RATE_LIMIT_BYPASS;
    const attempt = () =>
      loginRoute(
        jsonRequest(
          { email: "nobody@example.com", password: "wrong-password" },
          { "x-forwarded-for": "203.0.113.42" },
        ),
      );
    const statuses: number[] = [];
    for (let index = 0; index < 6; index += 1) {
      const response = await attempt();
      statuses.push(response.status);
      if (response.status === 429) {
        expect(response.headers.get("retry-after")).toBeTruthy();
      }
    }
    expect(statuses.slice(0, 5).every((status) => status === 401)).toBe(true);
    expect(statuses[5]).toBe(429);
  });
});

describe("billing gates", () => {
  it("requires authentication", async () => {
    session.user = null;
    const response = await checkoutRoute(jsonRequest({ currency: "inr" }));
    expect(response.status).toBe(401);
  });

  it("refuses checkout when Stripe and demo billing are not configured", async () => {
    const response = await checkoutRoute(jsonRequest({ currency: "inr" }));
    expect(response.status).toBe(403);
    expect((await response.json()).code).toBe("BILLING_NOT_CONFIGURED");
  });

  it("refuses an unsigned webhook when Stripe is not configured", async () => {
    const response = await webhookRoute(
      new Request("http://localhost/api/billing/webhook", {
        method: "POST",
        body: "{}",
        headers: { "content-type": "application/json" },
      }),
    );
    expect(response.status).toBe(503);
    expect((await response.json()).code).toBe("STRIPE_NOT_CONFIGURED");
  });

  it("refuses a webhook with a bad signature when keys are set", async () => {
    process.env.STRIPE_SECRET_KEY = "sk_test_not_a_real_key";
    process.env.STRIPE_WEBHOOK_SECRET = "whsec_not_a_real_secret";
    const response = await webhookRoute(
      new Request("http://localhost/api/billing/webhook", {
        method: "POST",
        body: "{}",
        headers: { "content-type": "application/json", "stripe-signature": "t=1,v1=deadbeef" },
      }),
    );
    expect(response.status).toBe(400);
    delete process.env.STRIPE_SECRET_KEY;
    delete process.env.STRIPE_WEBHOOK_SECRET;
  });
});
