import { beforeEach, describe, expect, it, vi } from "vitest";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

/**
 * Supabase auth adapter branches. The network adapter is mocked (no real
 * Supabase project), but the outcome handling — including the email-confirmation
 * path that must NOT set cookies — is the production code.
 */
const jar = vi.hoisted(() => {
  const store = new Map<string, string>();
  return {
    store,
    cookies: async () => ({
      get: (name: string) =>
        store.has(name) ? { name, value: store.get(name) as string } : undefined,
      set: (name: string, value: string) => void store.set(name, value),
      delete: (name: string) => void store.delete(name),
    }),
  };
});

const adapter = vi.hoisted(() => ({
  enabled: true,
  signIn: vi.fn(),
  signUp: vi.fn(),
  getUser: vi.fn(),
  refresh: vi.fn(),
  signOut: vi.fn(),
}));

vi.mock("next/headers", () => ({ cookies: jar.cookies }));

vi.mock("@/lib/auth/supabase", () => ({
  supabaseEnabled: () => adapter.enabled,
  supabaseSignIn: adapter.signIn,
  supabaseSignUp: adapter.signUp,
  supabaseGetUser: adapter.getUser,
  supabaseRefresh: adapter.refresh,
  supabaseSignOut: adapter.signOut,
}));

const { resetDatabase } = await import("./setup/db");
const { signIn, signUp, signOut, getCurrentUser, SB_ACCESS_COOKIE, SB_REFRESH_COOKIE } =
  await import("@/lib/auth");

const remoteUser = { id: "remote-1", email: "remote@example.com", name: "Remote Learner" };
const tokens = { accessToken: "at-1", refreshToken: "rt-1", expiresIn: 3600 };

beforeEach(async () => {
  await resetDatabase();
  jar.store.clear();
  adapter.enabled = true;
  adapter.signIn.mockReset();
  adapter.signUp.mockReset();
  adapter.getUser.mockReset();
  adapter.refresh.mockReset();
  adapter.signOut.mockReset();
});

describe("supabase auth adapter", () => {
  it("signs in, mirrors the identity locally and returns tokens", async () => {
    adapter.signIn.mockResolvedValue({ user: remoteUser, tokens });
    const outcome = await signIn("remote@example.com", "password123");
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) return;
    expect(outcome.status).toBe("signed_in");
    expect(outcome.tokens?.accessToken).toBe("at-1");

    const mirrored = await db.select().from(users).where(eq(users.email, "remote@example.com"));
    expect(mirrored).toHaveLength(1);
    expect(mirrored[0].passwordHash).toContain("external$");
  });

  it("returns confirm_email with no tokens when Supabase requires confirmation", async () => {
    adapter.signUp.mockResolvedValue({ user: remoteUser, tokens: null });
    const outcome = await signUp("Remote", "remote@example.com", "password123");
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) return;
    expect(outcome.status).toBe("confirm_email");
    expect(outcome.tokens).toBeUndefined();
    expect(outcome.sessionToken).toBeUndefined();
  });

  it("returns tokens on an immediate signup", async () => {
    adapter.signUp.mockResolvedValue({ user: remoteUser, tokens });
    const outcome = await signUp("Remote", "remote@example.com", "password123");
    expect(outcome.ok && outcome.status).toBe("signed_in");
  });

  it("reports adapter failures without leaking internals", async () => {
    adapter.signIn.mockRejectedValue(new Error("Invalid login credentials"));
    const outcome = await signIn("remote@example.com", "bad-password");
    expect(outcome.ok).toBe(false);
    if (!outcome.ok) expect(outcome.error).toContain("Invalid login credentials");

    adapter.signUp.mockRejectedValue(new Error("User already registered"));
    const signup = await signUp("Remote", "remote@example.com", "password123");
    expect(signup.ok).toBe(false);
  });

  it("authenticates from the access-token cookie and refreshes when needed", async () => {
    adapter.signIn.mockResolvedValue({ user: remoteUser, tokens });
    await signIn("remote@example.com", "password123");

    adapter.getUser.mockResolvedValue(remoteUser);
    jar.store.set(SB_ACCESS_COOKIE, "at-1");
    expect((await getCurrentUser())?.email).toBe("remote@example.com");

    jar.store.clear();
    adapter.refresh.mockResolvedValue({ user: remoteUser, tokens });
    jar.store.set(SB_REFRESH_COOKIE, "rt-1");
    expect((await getCurrentUser())?.email).toBe("remote@example.com");

    adapter.getUser.mockRejectedValue(new Error("token expired"));
    jar.store.set(SB_ACCESS_COOKIE, "expired");
    expect(await getCurrentUser()).toBeNull();

    jar.store.clear();
    expect(await getCurrentUser()).toBeNull();
  });

  it("signs out by revoking the remote session and clearing cookies", async () => {
    adapter.signOut.mockResolvedValue(undefined);
    jar.store.set(SB_ACCESS_COOKIE, "at-1");
    jar.store.set(SB_REFRESH_COOKIE, "rt-1");
    await signOut();
    expect(adapter.signOut).toHaveBeenCalledWith("at-1");
    expect(jar.store.size).toBe(0);
  });

  it("falls back to local auth when the Supabase adapter is disabled", async () => {
    adapter.enabled = false;
    const outcome = await signUp("Local", "local@example.com", "password123");
    expect(outcome.ok).toBe(true);
    const rows = await db.select().from(users).where(eq(users.email, "local@example.com"));
    expect(rows[0].passwordHash).not.toContain("external$");
  });
});
