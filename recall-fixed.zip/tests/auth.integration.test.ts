import { beforeEach, describe, expect, it, vi } from "vitest";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { cards, documents, sessions, users } from "@/db/schema";
import { hashToken } from "@/lib/auth/password";

/**
 * Auth flows against the real database. `next/headers` cookies are replaced with
 * an in-memory jar; everything else (scrypt hashing, hashed session tokens,
 * expiry, Supabase-vs-local selection) runs for real.
 */
const jar = vi.hoisted(() => {
  const store = new Map<string, string>();
  return {
    store,
    cookies: async () => ({
      get: (name: string) =>
        store.has(name) ? { name, value: store.get(name) as string } : undefined,
      set: (name: string, value: string) => void store.set(name, value),
      delete: (name: string) => void store.delete(name),
    }),
  };
});

vi.mock("next/headers", () => ({ cookies: jar.cookies }));

const { resetDatabase } = await import("./setup/db");
const { signIn, signUp, signOut, getCurrentUser, cookiePolicy } = await import("@/lib/auth");
const { ensureDemoSeed, DEMO_EMAIL, DEMO_PASSWORD } = await import("@/lib/repository");

beforeEach(async () => {
  await resetDatabase();
  jar.store.clear();
  process.env.AUTH_PROVIDER = "local";
});

describe("signup / signin / sessions", () => {
  it("creates an account, stores a hashed token and authenticates the cookie", async () => {
    const outcome = await signUp("Ada", "ada@example.com", "correct-horse");
    expect(outcome.ok).toBe(true);
    if (!outcome.ok) return;
    expect(outcome.sessionToken).toBeTruthy();

    const token = outcome.sessionToken ?? "";
    const [session] = await db.select().from(sessions);
    expect(session.tokenHash).toBe(hashToken(token));
    expect(session.tokenHash).not.toBe(token);

    jar.store.set(cookiePolicy.session.name, token);
    const user = await getCurrentUser();
    expect(user?.email).toBe("ada@example.com");
  });

  it("rejects a duplicate email and a weak password", async () => {
    await signUp("Ada", "ada@example.com", "correct-horse");
    const duplicate = await signUp("Ada", "ada@example.com", "correct-horse");
    expect(duplicate.ok).toBe(false);

    const weak = await signUp("Bo", "bo@example.com", "short");
    expect(weak.ok).toBe(false);
    const invalid = await signUp("Bo", "not-an-email", "correct-horse");
    expect(invalid.ok).toBe(false);
  });

  it("signs in with the right password and rejects the wrong one", async () => {
    await signUp("Ada", "ada@example.com", "correct-horse");
    const wrong = await signIn("ada@example.com", "wrong-password");
    expect(wrong.ok).toBe(false);

    const right = await signIn("ADA@example.com", "correct-horse");
    expect(right.ok).toBe(true);
    const unknown = await signIn("nobody@example.com", "correct-horse");
    expect(unknown.ok).toBe(false);
  });

  it("signs out by deleting the session row and cookie", async () => {
    const outcome = await signUp("Ada", "ada@example.com", "correct-horse");
    if (!outcome.ok) throw new Error("signup failed");
    jar.store.set(cookiePolicy.session.name, outcome.sessionToken ?? "");

    await signOut();
    expect(jar.store.has(cookiePolicy.session.name)).toBe(false);
    expect(await db.select().from(sessions)).toHaveLength(0);
    expect(await getCurrentUser()).toBeNull();
  });

  it("ignores expired and unknown session tokens", async () => {
    const outcome = await signUp("Ada", "ada@example.com", "correct-horse");
    if (!outcome.ok) throw new Error("signup failed");
    jar.store.set(cookiePolicy.session.name, "not-a-real-token");
    expect(await getCurrentUser()).toBeNull();

    await db.update(sessions).set({ expiresAt: new Date(Date.now() - 1000) });
    jar.store.set(cookiePolicy.session.name, outcome.sessionToken ?? "");
    expect(await getCurrentUser()).toBeNull();
  });

  it("returns null without a cookie", async () => {
    expect(await getCurrentUser()).toBeNull();
  });
});

describe("demo account", () => {
  it("seeds the demo user and a deck idempotently", async () => {
    await ensureDemoSeed();
    await ensureDemoSeed();

    const rows = await db.select().from(users).where(eq(users.email, DEMO_EMAIL));
    expect(rows).toHaveLength(1);
    const demoDocs = await db.select().from(documents).where(eq(documents.userId, rows[0].id));
    expect(demoDocs.length).toBe(1);
    const demoCards = await db.select().from(cards).where(eq(cards.userId, rows[0].id));
    expect(demoCards.length).toBeGreaterThan(0);

    const login = await signIn(DEMO_EMAIL, DEMO_PASSWORD);
    expect(login.ok).toBe(true);
  });

  it("does not duplicate an existing demo account", async () => {
    await db.insert(users).values({
      email: DEMO_EMAIL,
      name: "Existing demo",
      passwordHash: "existing",
    });
    await ensureDemoSeed();
    expect(await db.select().from(users)).toHaveLength(1);
  });
});
