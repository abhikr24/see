import { describe, expect, it } from "vitest";
import { mergeDecks, deckKey } from "@/lib/memory/merge";
import type { MemoryCard } from "@/lib/memory/types";

function card(prompt: string, answer: string, kind: MemoryCard["kind"] = "definition"): MemoryCard {
  return {
    kind,
    prompt,
    answer,
    hint: "",
    cloze: null,
    quote: "",
    page: 1,
    options: [],
    explanation: "",
    tags: [],
  };
}

const rulesDeck = Array.from({ length: 11 }, (_, index) =>
  card(`Question ${index}?`, `Rule answer ${index}`),
);

describe("AI merge", () => {
  it("keeps all rules cards when the AI returns two cards", () => {
    const ai = [
      card("What is a membrane?", "A phospholipid bilayer"),
      card("What is ATP?", "Cellular energy"),
    ];
    const merged = mergeDecks(ai, rulesDeck, 13);
    expect(merged.cards.length).toBe(13);
    expect(merged.aiCount).toBe(2);
    expect(merged.ruleCount).toBe(11);
    expect(merged.cards[0]).toBe(ai[0]);
    expect(merged.cards[1]).toBe(ai[1]);
  });

  it("never returns fewer cards than the free deck alone", () => {
    const ai = [card("What is ATP?", "Cellular energy")];
    expect(mergeDecks(ai, rulesDeck).cards.length).toBeGreaterThanOrEqual(rulesDeck.length);
    expect(mergeDecks(ai, rulesDeck, 5).cards.length).toBe(5);
    expect(mergeDecks([], rulesDeck).cards).toEqual(rulesDeck);
  });

  it("drops duplicates on a normalised answer+prompt key", () => {
    // Same prompt, different punctuation/case in the answer.
    const duplicate = card("Question 0?", "RULE ANSWER, 0!");
    const merged = mergeDecks([duplicate], rulesDeck);
    expect(merged.duplicates).toBe(1);
    expect(merged.cards.filter((entry) => deckKey(entry) === deckKey(duplicate))).toHaveLength(1);
  });

  it("prefers the AI version when both describe the same card", () => {
    const ai = [card("Question 0?", "Rule answer 0")];
    const merged = mergeDecks(ai, rulesDeck);
    expect(merged.cards[0]).toEqual(ai[0]);
    expect(merged.duplicates).toBe(1);
  });

  it("never truncates away the AI cards the user paid for", () => {
    const ai = [card("AI one?", "Alpha"), card("AI two?", "Beta"), card("AI three?", "Gamma")];
    const merged = mergeDecks(ai, rulesDeck, 2);
    expect(merged.cards.length).toBe(3);
    expect(merged.aiCount).toBe(3);
  });

  it("tolerates empty AI output", () => {
    const merged = mergeDecks([], rulesDeck, 4);
    expect(merged.cards.length).toBe(4);
    expect(merged.aiCount).toBe(0);
  });
});
