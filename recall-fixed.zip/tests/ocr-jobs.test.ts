import { describe, expect, it, vi } from "vitest";
import { createOcrJob, getOcrJob, publicJob, startOcrJob, updateOcrJob } from "@/lib/ocr/jobs";

vi.mock("@/lib/ocr/convert", () => ({
  convertPdfToDeck: vi.fn(),
}));

function waitFor(check: () => boolean, timeoutMs = 2000): Promise<void> {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    const timer = setInterval(() => {
      if (check()) {
        clearInterval(timer);
        resolve();
      } else if (Date.now() - started > timeoutMs) {
        clearInterval(timer);
        reject(new Error("timeout"));
      }
    }, 10);
  });
}

describe("OCR jobs", () => {
  it("is scoped to the user who created it", () => {
    const job = createOcrJob({ userId: "user-a", title: "Scan" });
    expect(getOcrJob("user-a", job.id)?.id).toBe(job.id);
    expect(getOcrJob("user-b", job.id)).toBeNull();
  });

  it("reports page-by-page progress and the created document", async () => {
    const job = createOcrJob({ userId: "user-a", title: "Scan" });
    startOcrJob(
      job,
      { userId: "user-a", title: "Scan", buffer: new ArrayBuffer(8) },
      {
        convert: async ({ onProgress }) => {
          onProgress({ page: 1, pages: 2, status: "reading" });
          onProgress({ page: 2, pages: 2, status: "done" });
          return { documentId: "doc-1", pagesOcred: 2, warnings: [], cardCount: 7 };
        },
      },
    );
    await waitFor(() => publicJob(getOcrJob("user-a", job.id) ?? job).status === "done");
    const state = publicJob(getOcrJob("user-a", job.id) ?? job);
    expect(state.status).toBe("done");
    expect(state.documentId).toBe("doc-1");
    expect(state.pages).toBe(2);
    expect(state.stage).toBe("Done");
  });

  it("records a typed failure instead of throwing", async () => {
    const job = createOcrJob({ userId: "user-a", title: "Scan" });
    startOcrJob(
      job,
      { userId: "user-a", title: "Scan", buffer: new ArrayBuffer(8) },
      {
        convert: async () => {
          throw Object.assign(new Error("OCR found no readable text"), { code: "OCR_FAILED" });
        },
      },
    );
    await waitFor(() => publicJob(getOcrJob("user-a", job.id) ?? job).status === "failed");
    const state = publicJob(getOcrJob("user-a", job.id) ?? job);
    expect(state.error?.code).toBe("OCR_FAILED");
    expect(state.documentId).toBeNull();
  });

  it("never leaks another user's job details", () => {
    const job = createOcrJob({ userId: "owner", title: "Private scan" });
    updateOcrJob(job.id, { status: "reading", page: 3, pages: 9 });
    expect(getOcrJob("intruder", job.id)).toBeNull();
  });
});
