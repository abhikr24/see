import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { defaultOcrDeps, ocrPdfPages, ocrStatus } from "@/lib/ocr";
import { extractPdfWithOcr } from "@/lib/pdf";
import { writeSmokeRecord } from "@/lib/ocr/cache";

/**
 * Real OCR against an image-only PDF. This is the acceptance smoke test for the
 * OCR path: it rasterises with pdf.js + @napi-rs/canvas and recognises with
 * tesseract.js. Language data is read from `.tesseract/` (npm run ocr:fetch-data).
 */
describe("real OCR", () => {
  const buffer = readFileSync("tests/fixtures/scanned-handout.pdf");
  const array = buffer.buffer.slice(
    buffer.byteOffset,
    buffer.byteOffset + buffer.byteLength,
  ) as ArrayBuffer;

  it("reports available only with cached language data", () => {
    const status = ocrStatus();
    expect(status.cachedLanguages).toContain("eng");
    expect(status.maxPages).toBeGreaterThan(0);
  });

  it("rasterises and recognises an image-only PDF", async () => {
    const pages = await defaultOcrDeps.renderPages(array, [1]);
    expect(pages).toHaveLength(1);
    expect(pages[0].image.length).toBeGreaterThan(10_000);

    const text = await defaultOcrDeps.recognize(pages[0].image);
    expect(text.toLowerCase()).toContain("osmo");
    writeSmokeRecord({
      at: new Date().toISOString(),
      languages: ["eng"],
      sample: text.slice(0, 120),
    });
  }, 300_000);

  it("survives the text pass having already detached the buffer", async () => {
    // Regression: the upload path parsed the text layer first (pdf.js detaches the
    // ArrayBuffer) and OCR then failed with "Cannot perform Construct on a
    // detached ArrayBuffer". extractPdfWithOcr now copies for each pass.
    const result = await extractPdfWithOcr(array, { enableOcr: true });
    expect(result.ocr).toBe(true);
    expect(result.pagesOcred).toBeGreaterThan(0);
    expect(result.pages.join(" ").toLowerCase()).toContain("osmosis");
  }, 300_000);

  it("produces text for a page-limited OCR request", async () => {
    const result = await ocrPdfPages(array, [1]);
    expect(result.pagesOcred).toBe(1);
  }, 120_000);
});
