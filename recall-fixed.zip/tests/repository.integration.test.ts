import { beforeEach, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { aiEvents, cards, documents, quizAttempts, users } from "@/db/schema";
import type { SessionUser } from "@/lib/auth";
import type { MemoryCard } from "@/lib/memory/types";

const { resetDatabase, hasDatabase } = await import("./setup/db");
const repo = await import("@/lib/repository");

const TEXT = `Diffusion is the net movement of particles from a region of higher concentration to a region of lower concentration. Osmosis is the diffusion of water across a selectively permeable membrane. The cell membrane is a phospholipid bilayer with embedded proteins that control transport. Active transport requires ATP.`;

function aiCard(prompt: string, answer: string): MemoryCard {
  return {
    kind: "ai",
    prompt,
    answer,
    hint: "",
    cloze: null,
    quote: "",
    page: 1,
    options: [],
    explanation: "",
    tags: ["ai"],
  };
}

async function makeUser(
  email = "owner@example.com",
  plan: "free" | "pro" = "free",
): Promise<SessionUser> {
  const [row] = await db
    .insert(users)
    .values({ email, name: "Owner", passwordHash: "x", plan, aiCredits: plan === "pro" ? 5 : 0 })
    .returning();
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    plan,
    aiCredits: row.aiCredits,
    streak: 0,
    lastStudiedOn: null,
  };
}

async function createDeck(userId: string, title = "Deck"): Promise<string> {
  const doc = await repo.createSource({
    userId,
    title,
    sourceType: "paste",
    pages: [TEXT],
    engine: "rules",
  });
  return doc.id;
}

beforeEach(async () => {
  await resetDatabase();
});

describe.skipIf(!hasDatabase)("repository", () => {
  it("merges AI cards into the rules deck and charges one credit", async () => {
    const user = await makeUser("pro@example.com", "pro");
    const doc = await repo.createSource({
      userId: user.id,
      title: "AI deck",
      sourceType: "paste",
      pages: [TEXT],
      engine: "ai",
      aiOverlay: {
        cards: [
          aiCard("What is a membrane?", "A phospholipid bilayer"),
          aiCard("What is ATP?", "Cellular energy"),
        ],
        analysis: (await import("@/lib/memory/engine")).analyzeSource({
          title: "AI deck",
          pages: [TEXT],
        }).analysis,
        provider: "Stub · stub-1",
      },
      aiMeta: {
        provider: "Stub",
        model: "stub-1",
        tokens: 120,
        inputTokens: 100,
        outputTokens: 20,
        costUsd: 0.0001,
      },
    });

    const rows = await db.select().from(cards).where(eq(cards.documentId, doc.id));
    expect(rows.length).toBeGreaterThan(2);
    expect(rows.filter((row) => row.kind === "ai").length).toBe(2);
    expect(doc.engine).toBe("ai");
    expect(doc.requestedEngine).toBe("ai");

    const [account] = await db.select().from(users).where(eq(users.id, user.id));
    expect(account.aiCredits).toBe(4);
    const events = await db.select().from(aiEvents).where(eq(aiEvents.userId, user.id));
    expect(events).toHaveLength(1);
    expect(events[0].tokens).toBe(120);
  });

  it("keeps the rules engine label and charges nothing when AI fails", async () => {
    const user = await makeUser("pro2@example.com", "pro");
    const doc = await repo.createSource({
      userId: user.id,
      title: "Fallback deck",
      sourceType: "paste",
      pages: [TEXT],
      engine: "ai",
      aiOverlay: null,
    });
    expect(doc.engine).toBe("rules");
    expect(doc.requestedEngine).toBe("ai");
    const [account] = await db.select().from(users).where(eq(users.id, user.id));
    expect(account.aiCredits).toBe(5);
  });

  it("records failed AI runs without charging", async () => {
    const user = await makeUser("pro3@example.com", "pro");
    await repo.recordAiFailure({
      userId: user.id,
      provider: "Stub",
      model: "stub-1",
      code: "AI_TIMEOUT",
    });
    const events = await db.select().from(aiEvents).where(eq(aiEvents.userId, user.id));
    expect(events[0].credits).toBe(0);
    expect(events[0].status).toBe("failed:AI_TIMEOUT");
  });

  it("lists documents and builds dashboard/activity stats", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);
    const [card] = await db.select().from(cards).where(eq(cards.documentId, documentId));

    await repo.reviewCard(user.id, card.id, 2);

    const list = await repo.listDocuments(user.id);
    expect(list).toHaveLength(1);
    expect(list[0].totalCards).toBeGreaterThan(0);

    const dashboard = await repo.getDashboard(user.id);
    expect(dashboard.documents).toBe(1);
    expect(dashboard.reviewsThisWeek).toBe(1);
    expect(dashboard.activity).toHaveLength(30);
    expect(dashboard.retentionThisWeek).toBe(100);

    const activity = await repo.getActivity(user.id, 7);
    expect(activity.reduce((sum, day) => sum + day.count, 0)).toBe(1);
  });

  it("filters cards server-side and serves the due queue", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);
    const all = await repo.getDocumentCards(user.id, documentId, { includeSuspended: true });
    expect(all.length).toBeGreaterThan(0);

    const due = await repo.getDueQueue(user.id, 50, documentId);
    expect(due.length).toBeGreaterThan(0);
    expect(due[0].documentTitle).toBe("Deck");

    const search = await repo.getDocumentCards(user.id, documentId, { search: "membrane" });
    expect(
      search.every((card) => `${card.prompt} ${card.answer}`.toLowerCase().includes("membrane")),
    ).toBe(true);

    const byPage = await repo.getDocumentCards(user.id, documentId, { page: 1 });
    expect(byPage.every((card) => card.page === 1)).toBe(true);

    expect(
      await repo.getDocumentCards("00000000-0000-4000-8000-000000000000", documentId),
    ).toHaveLength(0);
  });

  it("updates, flags, suspends, reorders and deletes cards", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);
    const rows = await repo.getDocumentCards(user.id, documentId, { includeSuspended: true });

    const updated = await repo.updateCard(user.id, rows[0].id, {
      answer: "Edited answer",
      suspended: true,
      flagged: true,
      flagNote: "Unclear",
    });
    expect(updated?.answer).toBe("Edited answer");
    expect(updated?.suspended).toBe(true);

    const doc = await repo.getDocument(user.id, documentId);
    expect(doc?.flaggedCards).toBe(1);

    expect(
      await repo.updateCard("00000000-0000-4000-8000-000000000000", rows[0].id, {
        suspended: false,
      }),
    ).toBeNull();

    const order = rows.map((row) => row.id).reverse();
    expect(await repo.reorderCards(user.id, documentId, order)).toBe(true);
    expect(
      await repo.reorderCards(user.id, documentId, ["00000000-0000-4000-8000-000000000000"]),
    ).toBe(false);

    const added = await repo.addCard(user.id, documentId, {
      prompt: "What is the membrane?",
      answer: "A phospholipid bilayer",
    });
    expect(added?.kind).toBe("ai");
    expect(
      await repo.addCard(user.id, "00000000-0000-4000-8000-000000000000", {
        prompt: "x?",
        answer: "y",
      }),
    ).toBeNull();

    expect(await repo.deleteCard(user.id, added?.id ?? "")).toBe(true);
    expect(await repo.deleteCard(user.id, added?.id ?? "")).toBe(false);
  });

  it("imports cards, skipping duplicates", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);
    const incoming = [aiCard("What is the membrane?", "A phospholipid bilayer")];
    const first = await repo.addImportedCards(user.id, documentId, incoming);
    expect(first.imported).toBe(1);
    const second = await repo.addImportedCards(user.id, documentId, incoming);
    expect(second.imported).toBe(0);
  });

  it("stores settings and quiz attempts with per-question results", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);

    const settings = await repo.updateUserSettings(user.id, { desiredRetention: 0.85 });
    expect(settings?.desiredRetention).toBeCloseTo(0.85);
    expect((await repo.getUserSettings(user.id))?.desiredRetention).toBeCloseTo(0.85);

    const attempt = await repo.recordQuizAttempt(user.id, documentId, [
      { cardId: "a", prompt: "Q1", chosen: "x", correctAnswer: "x", correct: true },
      { cardId: "b", prompt: "Q2", chosen: "y", correctAnswer: "z", correct: false },
    ]);
    expect(attempt?.score).toBe(1);
    expect(attempt?.total).toBe(2);
    expect(attempt?.results).toHaveLength(2);

    const dashboard = await repo.getDashboard(user.id);
    expect(dashboard.recentQuiz.length).toBe(1);
  });

  it("tracks AI spend and recent events", async () => {
    const user = await makeUser("pro4@example.com", "pro");
    await repo.createSource({
      userId: user.id,
      title: "Spend deck",
      sourceType: "paste",
      pages: [TEXT],
      engine: "ai",
      aiOverlay: {
        cards: [aiCard("What is ATP?", "Cellular energy")],
        analysis: (await import("@/lib/memory/engine")).analyzeSource({
          title: "Spend",
          pages: [TEXT],
        }).analysis,
        provider: "Stub",
      },
      aiMeta: {
        provider: "Stub",
        model: "stub-1",
        tokens: 500,
        inputTokens: 400,
        outputTokens: 100,
        costUsd: 0.002,
      },
    });
    const spend = await repo.getAiSpendThisMonth(user.id);
    expect(spend.events).toBe(1);
    expect(spend.tokens).toBe(500);
    expect(spend.costUsd).toBeCloseTo(0.002);
    expect(await repo.getRecentAiEvents(user.id, 5)).toHaveLength(1);
  });

  it("handles subscriptions, stripe events and plan changes idempotently", async () => {
    const user = await makeUser("sub@example.com");
    await repo.setStripeCustomer(user.id, "cus_123");
    expect(await repo.findUserIdByCustomer("cus_123")).toBe(user.id);
    expect(await repo.findUserIdByCustomer("cus_missing")).toBeNull();

    const saved = await repo.saveSubscription({
      userId: user.id,
      stripeCustomerId: "cus_123",
      stripeSubscriptionId: "sub_123",
      status: "active",
      priceId: "price_123",
      currency: "inr",
      currentPeriodEnd: new Date(Date.now() + 86400000),
    });
    expect(saved?.status).toBe("active");
    expect((await repo.getSubscription(user.id))?.stripeSubscriptionId).toBe("sub_123");

    expect(await repo.claimStripeEvent("evt_1", "invoice.paid")).toBe(true);
    expect(await repo.claimStripeEvent("evt_1", "invoice.paid")).toBe(false);

    await repo.upgradeUser(user.id, 40);
    let [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.plan).toBe("pro");
    expect(row.aiCredits).toBe(40);

    await repo.renewUserCredits(user.id, 40);
    [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.aiCredits).toBe(40);

    await repo.downgradeUser(user.id);
    [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.plan).toBe("free");
    expect(row.aiCredits).toBe(0);

    const pro = await repo.activateDemoPro(user.id, 40);
    expect(pro?.plan).toBe("pro");
    expect(pro?.aiCredits).toBe(40);
  });

  it("deletes a document with its cards and reports missing documents", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);
    expect(await repo.deleteDocument("00000000-0000-4000-8000-000000000000", documentId)).toBe(
      false,
    );
    expect(await repo.deleteDocument(user.id, documentId)).toBe(true);
    expect(await db.select().from(documents)).toHaveLength(0);
    expect(await db.select().from(cards)).toHaveLength(0);
    expect(await db.select().from(quizAttempts)).toHaveLength(0);
  });

  it("refreshes flag counts and returns the card by id", async () => {
    const user = await makeUser();
    const documentId = await createDeck(user.id);
    const [card] = await repo.getDocumentCards(user.id, documentId, { includeSuspended: true });
    await repo.updateCard(user.id, card.id, { flagged: true });
    await repo.refreshFlagCount(user.id, documentId);
    expect((await repo.getDocument(user.id, documentId))?.flaggedCards).toBe(1);
    expect((await repo.getCard(user.id, card.id))?.id).toBe(card.id);
    expect(await repo.getCard("00000000-0000-4000-8000-000000000000", card.id)).toBeNull();
  });
});
