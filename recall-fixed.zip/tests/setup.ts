import "dotenv/config";

// Integration tests talk to the real database; make sure a missing
// DATABASE_URL fails with a sentence a human can act on.
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set. Copy .env.example to .env (or export DATABASE_URL) before running npm test.",
  );
}
