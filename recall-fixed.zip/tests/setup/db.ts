import "dotenv/config";
import { sql } from "drizzle-orm";
import { db } from "@/db";

export const hasDatabase = Boolean(process.env.DATABASE_URL);

/** Truncate every table so each API test starts from a known state. */
export async function resetDatabase(): Promise<void> {
  await db.execute(
    sql`truncate table rate_limits, stripe_events, reviews, quiz_attempts, ai_events, cards, documents, sessions, subscriptions, users restart identity cascade`,
  );
}
