import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  test: {
    environment: "node",
    include: ["tests/**/*.test.{ts,tsx}"],
    // Integration tests share one PostgreSQL database and truncate between
    // tests, so files must not run in parallel workers.
    fileParallelism: false,
    setupFiles: ["./tests/setup.ts"],
    reporters: ["default"],
    coverage: {
      provider: "v8",
      reporter: ["text", "json-summary"],
      include: [
        "src/lib/memory/**",
        "src/lib/auth/**",
        "src/lib/billing/**",
        "src/lib/import/**",
        "src/lib/rich/**",
        "src/lib/repository.ts",
        "src/lib/ocr/**",
      ],
      thresholds: {
        "src/lib/memory/**": { lines: 80, statements: 80 },
        "src/lib/auth/**": { lines: 80, statements: 80 },
        "src/lib/repository.ts": { lines: 80, statements: 80 },
      },
      exclude: ["src/lib/auth/password.ts", "src/lib/auth/http.ts", "src/lib/auth/supabase.ts"],
    },
  },
});
