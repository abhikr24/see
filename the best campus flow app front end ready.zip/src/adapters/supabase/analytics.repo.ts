import type { AnalyticsReport, AnalyticsReportQuery, AuditLog, DateRange, FunnelStage, ID, InstituteOverview, LeadStage, NewEntity, TrendPoint } from '../../core/contracts/models';
import type { AnalyticsRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { dashboard } from './dashboard.repo';
import { mapAuditLog } from './mappers';
import { studentHome } from './student-home.repo';
import { teacherHome } from './teacher.repo';
import { childSummary } from './parent.repo';

export function analyticsRepo(): AnalyticsRepo {
  return {
    async overview(instituteId: ID): Promise<InstituteOverview> {
      try {
        const { count: activeStudents } = await supabase.from('student_profiles').select('*', { count: 'exact', head: true }).eq('institute_id', instituteId).eq('status', 'active');
        const { count: activeTeachers } = await supabase.from('teacher_profiles').select('*', { count: 'exact', head: true }).eq('institute_id', instituteId).eq('status', 'active');
        const { count: activeBatches } = await supabase.from('batches').select('*', { count: 'exact', head: true }).eq('institute_id', instituteId).eq('status', 'active');
        const { count: pendingMembers } = await supabase.from('memberships').select('*', { count: 'exact', head: true }).eq('institute_id', instituteId).eq('status', 'pending');
        const { count: openLeads } = await supabase.from('admission_leads').select('*', { count: 'exact', head: true }).eq('institute_id', instituteId).not('stage', 'in', '("enrolled","lost")');
        return {
          activeStudents: activeStudents ?? 0,
          activeTeachers: activeTeachers ?? 0,
          activeBatches: activeBatches ?? 0,
          pendingMembers: pendingMembers ?? 0,
          attendancePercent: null,
          feesCollected: 0,
          feesOutstanding: 0,
          openLeads: openLeads ?? 0,
          openAlerts: 0,
        };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    dashboard,
    teacherHome,
    studentHome,
    childSummary,

    async attendanceTrend(instituteId: ID, range: DateRange): Promise<TrendPoint[]> {
      const { data, error } = await supabase.rpc('analytics_trend', { p_institute_id: instituteId, p_kind: 'attendance', p_from: range.from, p_to: range.to });
      if (error) throw handleSupabaseError(error);
      return (data ?? []) as TrendPoint[];
    },

    async feeCollection(instituteId: ID, range: DateRange): Promise<TrendPoint[]> {
      const { data, error } = await supabase.rpc('analytics_trend', { p_institute_id: instituteId, p_kind: 'fees', p_from: range.from, p_to: range.to });
      if (error) throw handleSupabaseError(error);
      return (data ?? []) as TrendPoint[];
    },

    async report(instituteId: ID, query: AnalyticsReportQuery): Promise<AnalyticsReport> {
      const { data, error } = await supabase.rpc('analytics_report', {
        p_institute_id: instituteId,
        p_type: query.type,
        p_period: query.period,
        p_batch_id: query.batchId ?? null,
      });
      if (error) throw handleSupabaseError(error);
      if (!data) throw handleSupabaseError(new Error('The report query returned no result.'));
      return data as AnalyticsReport;
    },

    async leadFunnel(instituteId: ID): Promise<FunnelStage[]> {
      try {
        const stages: LeadStage[] = ['new', 'contacted', 'interested', 'demo_scheduled', 'demo_attended', 'negotiation', 'enrolled', 'lost'];
        const result: FunnelStage[] = [];
        for (const stage of stages) {
          const { count } = await supabase.from('admission_leads').select('*', { count: 'exact', head: true }).eq('institute_id', instituteId).eq('stage', stage);
          result.push({ stage, count: count ?? 0 });
        }
        return result;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listAuditLogs(instituteId: ID, query?: ListQuery<AuditLog>): Promise<Page<AuditLog>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('audit_logs').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapAuditLog), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async recordAudit(instituteId: ID, input: NewEntity<AuditLog, 'action'>): Promise<AuditLog> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('audit_logs').insert({
          institute_id: instituteId, action: input.action, actor_id: user?.user?.id ?? null,
          target_type: input.targetType ?? null, target_id: input.targetId ?? null,
          old_data: input.before ?? null, new_data: input.after ?? null,
        }).select().single();
        if (error) throw error;
        return mapAuditLog(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
