/**
 * Client-side rate limiter for the calls that hit Supabase Auth.
 *
 * Defence in depth on top of the platform's own per-IP / per-factor
 * limits on the auth endpoints: a runaway retry loop, a broken button or
 * a scripted client is refused locally before it can hammer the auth
 * service. It is not a security boundary by itself (a modified client
 * can drop it) — the server-side limits and the database join-request
 * trigger (supabase/migrations/0021_join_rate_limit.sql) are.
 *
 * Pure module: no React Native imports, so it is unit-testable in node.
 */

import { BackendError } from '../../core/contracts/errors';

const WINDOW_MS = 60_000;
const MAX_ATTEMPTS = 5;

const attempts = new Map<string, number[]>();

function recent(list: number[], now: number): number[] {
  return list.filter((t) => now - t < WINDOW_MS);
}

/**
 * Records one attempt and throws RATE_LIMITED once the action has been
 * tried MAX_ATTEMPTS times inside the sliding window. `now` is
 * injectable for tests.
 */
export function checkAuthRateLimit(action: string, now: number = Date.now()): void {
  const list = recent(attempts.get(action) ?? [], now);
  if (list.length >= MAX_ATTEMPTS) {
    throw new BackendError('RATE_LIMITED', 'Too many attempts. Please wait a minute and try again.');
  }
  attempts.set(action, [...list, now]);
}

/** Clears an action's history (used by tests and by sign-out). */
export function resetAuthRateLimit(action: string): void {
  attempts.delete(action);
}
