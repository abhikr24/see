import type { AuthSession, ID, OtpChallenge, Patch, Profile } from '../../core/contracts/models';
import type { AuthPort, Credentials, InstituteScope } from '../../core/contracts/ports';
import { checkAuthRateLimit, resetAuthRateLimit } from './auth-rate-limit';
import { handleSupabaseError, supabase } from './client';
import { mapMembership, mapProfile } from './mappers';

export function authAdapter(): AuthPort {
  return {
    async getSession(instituteId: InstituteScope): Promise<AuthSession | null> {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        if (!session?.user) return null;

        const userId = session.user.id;
        const { data: profileRow, error: profileError } = await supabase.from('profiles').select('*').eq('user_id', userId).maybeSingle();
        if (profileError) throw profileError;
        const profile = profileRow ? mapProfile(profileRow) : {
          id: userId, userId, fullName: session.user.user_metadata?.full_name ?? session.user.email?.split('@')[0] ?? 'User',
          email: session.user.email ?? null, phone: session.user.phone ?? null, avatarUrl: null, gender: null, dateOfBirth: null,
          city: null, state: null, bio: null, createdAt: session.user.created_at, updatedAt: session.user.created_at,
        };

        let membership = null;
        if (instituteId) {
          const { data: mRow, error: membershipError } = await supabase.from('memberships').select('*').eq('institute_id', instituteId).eq('user_id', userId).maybeSingle();
          if (membershipError) throw membershipError;
          if (mRow) membership = mapMembership(mRow);
        }

        return {
          user: { id: userId, email: session.user.email ?? null, phone: session.user.phone ?? null },
          profile,
          membership,
          expiresAt: session.expires_at ? new Date(session.expires_at * 1000).toISOString() : null,
        };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async signIn(instituteId: InstituteScope, credentials: Credentials): Promise<AuthSession> {
      checkAuthRateLimit('sign-in');
      try {
        const { data, error } = await supabase.auth.signInWithPassword(credentials);
        if (error) throw error;
        const session = await this.getSession(instituteId);
        if (!session) throw new Error('Failed to retrieve session after login');
        return session;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async signUp(instituteId: InstituteScope, input: Credentials & { fullName: string }): Promise<AuthSession> {
      checkAuthRateLimit('sign-up');
      try {
        const { error } = await supabase.auth.signUp({
          email: input.email,
          password: input.password,
          options: { data: { full_name: input.fullName } },
        });
        if (error) throw error;
        return await this.signIn(instituteId, { email: input.email, password: input.password });
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async signOut(instituteId: InstituteScope): Promise<void> {
      resetAuthRateLimit('sign-in');
      resetAuthRateLimit('sign-up');
      resetAuthRateLimit('otp');
      resetAuthRateLimit('password-reset');
      try {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async requestPasswordReset(instituteId: InstituteScope, email: string): Promise<void> {
      checkAuthRateLimit('password-reset');
      try {
        const { error } = await supabase.auth.resetPasswordForEmail(email);
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async getProfile(instituteId: InstituteScope, userId: ID): Promise<Profile> {
      try {
        const { data, error } = await supabase.from('profiles').select('*').eq('user_id', userId).single();
        if (error) throw error;
        return mapProfile(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async updateProfile(instituteId: InstituteScope, userId: ID, patch: Patch<Profile>): Promise<Profile> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.fullName !== undefined) row.full_name = patch.fullName;
        if (patch.avatarUrl !== undefined) row.avatar_url = patch.avatarUrl;
        if (patch.gender !== undefined) row.gender = patch.gender;
        if (patch.dateOfBirth !== undefined) row.date_of_birth = patch.dateOfBirth;
        if (patch.city !== undefined) row.city = patch.city;
        if (patch.state !== undefined) row.state = patch.state;
        if (patch.bio !== undefined) row.bio = patch.bio;
        const { data, error } = await supabase.from('profiles').update(row).eq('user_id', userId).select().single();
        if (error) throw error;
        return mapProfile(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async requestOtp(instituteId: InstituteScope, credentials: Credentials): Promise<OtpChallenge> {
      checkAuthRateLimit('otp');
      throw handleSupabaseError(new Error('OTP sign-in is not configured for Supabase.'));
    },

    async verifyOtp(instituteId: InstituteScope, input: { challengeId: string; code: string }): Promise<AuthSession> {
      throw handleSupabaseError(new Error('OTP verification is not configured for Supabase.'));
    },

    async resendOtp(instituteId: InstituteScope, challengeId: string): Promise<OtpChallenge> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },

    async signInWithGoogle(instituteId: InstituteScope): Promise<AuthSession> {
      try {
        const { data, error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: undefined } });
        if (error) throw error;
        throw handleSupabaseError(new Error('Complete Google sign-in in the browser, then retry.'));
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
