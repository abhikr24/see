import type {
  Batch, Classroom, Enrollment, ID, NewEntity, Patch, Subject, Timetable, Upsert,
} from '../../core/contracts/models';
import type { BatchRepo, SubjectRepo, TimetableRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { mapBatch, mapClassroom, mapEnrollment, mapSubject, mapTimetable } from './mappers';

import { validateBatch } from '../../core/contracts/batch-validation';
import { listBatchSummaries, listBatchRoster } from './batch-summary.repo';
import { listMyClasses } from './teacher.repo';
const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

export function batchRepo(): BatchRepo {
  return {
    listSummaries: listBatchSummaries,
    listRoster: listBatchRoster,
    listMyClasses,
    async list(instituteId: ID, query?: ListQuery<Batch>): Promise<Page<Batch>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('batches').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        if (query?.where?.academicYear) q = q.eq('academic_year', query.where.academicYear);
        if (query?.search) q = q.ilike('name', `%${query.search}%`);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('name', { ascending: true });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapBatch), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Batch> {
      try {
        const { data, error } = await supabase.from('batches').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapBatch(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async create(instituteId: ID, input: NewEntity<Batch, 'name' | 'academicYear'>): Promise<Batch> {
      validateBatch(input);
      if (!live) throw handleSupabaseError(new Error('Supabase is not configured for this operation.'));
      try {
        const { data, error } = await supabase.from('batches').insert({
          institute_id: instituteId, name: input.name, academic_year: input.academicYear,
          branch_id: input.branchId ?? null, classroom_id: input.classroomId ?? null,
          grade: input.grade ?? null, section: input.section ?? null, capacity: input.capacity ?? null,
          starts_on: input.startsOn ?? null, ends_on: input.endsOn ?? null, status: input.status ?? 'active',
          subject_id: input.subjectId ?? null, teacher_id: input.teacherId ?? null,
          days: input.days ?? [], starts_at: input.startsAt ?? null, ends_at: input.endsAt ?? null,
          fee_plan: input.feePlan ?? 'monthly', fee_amount: input.feeAmount ?? 0,
        }).select().single();
        if (error) throw error;
        return mapBatch(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Batch>): Promise<Batch> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.name !== undefined) row.name = patch.name;
        if (patch.academicYear !== undefined) row.academic_year = patch.academicYear;
        if (patch.branchId !== undefined) row.branch_id = patch.branchId;
        if (patch.classroomId !== undefined) row.classroom_id = patch.classroomId;
        if (patch.grade !== undefined) row.grade = patch.grade;
        if (patch.section !== undefined) row.section = patch.section;
        if (patch.capacity !== undefined) row.capacity = patch.capacity;
        if (patch.startsOn !== undefined) row.starts_on = patch.startsOn;
        if (patch.endsOn !== undefined) row.ends_on = patch.endsOn;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('batches').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapBatch(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      if (!live) throw handleSupabaseError(new Error('Supabase is not configured for this operation.'));
      try {
        const { error } = await supabase.from('batches').update({ status: 'archived' }).eq('institute_id', instituteId).eq('id', id).select('id').single();
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async listMine(instituteId: ID): Promise<Batch[]> {
      try {
        const { data, error } = await supabase.from('batches').select('*').eq('institute_id', instituteId);
        if (error) throw error;
        return (data ?? []).map(mapBatch);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async listEnrollments(instituteId: ID, batchId: ID): Promise<Enrollment[]> {
      try {
        const { data, error } = await supabase.from('batch_students')
          .select('*').eq('institute_id', instituteId).eq('batch_id', batchId).order('roll_number', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapEnrollment);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async enroll(instituteId: ID, batchId: ID, input: { studentId: ID; rollNumber?: number | null }): Promise<Enrollment> {
      try {
        const { data, error } = await supabase.from('batch_students').insert({
          institute_id: instituteId, batch_id: batchId, student_id: input.studentId,
          roll_number: input.rollNumber ?? null, status: 'active',
        }).select().single();
        if (error) throw error;
        return mapEnrollment(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async unenroll(instituteId: ID, enrollmentId: ID): Promise<Enrollment> {
      try {
        const { data, error } = await supabase.from('batch_students').update({
          status: 'left', left_on: new Date().toISOString().slice(0, 10),
        }).eq('institute_id', instituteId).eq('id', enrollmentId).select().single();
        if (error) throw error;
        return mapEnrollment(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}

export function subjectRepo(): SubjectRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Subject>): Promise<Page<Subject>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('subjects').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('name', { ascending: true });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapSubject), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Subject> {
      try {
        const { data, error } = await supabase.from('subjects').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapSubject(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async create(instituteId: ID, input: NewEntity<Subject, 'name' | 'code'>): Promise<Subject> {
      try {
        const { data, error } = await supabase.from('subjects').insert({
          institute_id: instituteId, name: input.name, code: input.code.toUpperCase(),
          color: input.color ?? null, description: input.description ?? null, is_active: input.isActive ?? true,
        }).select().single();
        if (error) throw error;
        return mapSubject(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Subject>): Promise<Subject> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.name !== undefined) row.name = patch.name;
        if (patch.code !== undefined) row.code = patch.code;
        if (patch.color !== undefined) row.color = patch.color;
        if (patch.description !== undefined) row.description = patch.description;
        if (patch.isActive !== undefined) row.is_active = patch.isActive;
        const { data, error } = await supabase.from('subjects').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapSubject(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('subjects').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}

export function timetableRepo(): TimetableRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Timetable>): Promise<Page<Timetable>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('timetables').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const { data, count, error } = await q.range(offset, offset + limit - 1);
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapTimetable), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Timetable> {
      try {
        const { data, error } = await supabase.from('timetables').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapTimetable(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async create(instituteId: ID, input: NewEntity<Timetable, 'batchId' | 'dayOfWeek' | 'startsAt' | 'endsAt'>): Promise<Timetable> {
      try {
        const { data, error } = await supabase.from('timetables').insert({
          institute_id: instituteId, batch_id: input.batchId, day_of_week: input.dayOfWeek,
          starts_at: input.startsAt, ends_at: input.endsAt, subject_id: input.subjectId ?? null,
          teacher_id: input.teacherId ?? null, classroom_id: input.classroomId ?? null,
        }).select().single();
        if (error) throw error;
        return mapTimetable(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async update(instituteId: ID, id: ID, patch: Patch<Timetable>): Promise<Timetable> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.dayOfWeek !== undefined) row.day_of_week = patch.dayOfWeek;
        if (patch.startsAt !== undefined) row.starts_at = patch.startsAt;
        if (patch.endsAt !== undefined) row.ends_at = patch.endsAt;
        const { data, error } = await supabase.from('timetables').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapTimetable(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('timetables').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async listForDay(instituteId: ID, filter: { dayOfWeek: number; batchId?: ID; teacherId?: ID }): Promise<Timetable[]> {
      try {
        let q = supabase.from('timetables').select('*').eq('institute_id', instituteId).eq('day_of_week', filter.dayOfWeek);
        if (filter.batchId) q = q.eq('batch_id', filter.batchId);
        if (filter.teacherId) q = q.eq('teacher_id', filter.teacherId);
        const { data, error } = await q.order('starts_at', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapTimetable);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async listClassrooms(instituteId: ID): Promise<Classroom[]> {
      try {
        const { data, error } = await supabase.from('classrooms').select('*').eq('institute_id', instituteId);
        if (error) throw error;
        return (data ?? []).map(mapClassroom);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async saveClassroom(instituteId: ID, input: Upsert<Classroom, 'name'>): Promise<Classroom> {
      try {
        const row = { institute_id: instituteId, name: input.name, branch_id: input.branchId ?? null, capacity: input.capacity ?? null, facilities: input.facilities ?? [], status: input.status ?? 'active' };
        const op = input.id ? supabase.from('classrooms').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single() : supabase.from('classrooms').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapClassroom(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async removeClassroom(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('classrooms').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
