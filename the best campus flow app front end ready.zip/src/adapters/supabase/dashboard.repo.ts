import type { DashboardBatch, ID, OwnerDashboard } from '../../core/contracts/models';
import type { AnalyticsRepo } from '../../core/contracts/ports';
import { supabase, handleSupabaseError } from './client';
import { progressRepo } from './progress.repo';

/** "This week" on the dashboard: the seven days ending today. */
const ALERT_WINDOW_DAYS = 7;

type Row = Record<string, unknown>;
type Query = PromiseLike<{ data: unknown; error: unknown }>;

async function rows(query: Query): Promise<Row[]> {
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as Row[];
}

const text = (value: unknown): string => String(value ?? '');
const time = (value: unknown): string => text(value).slice(0, 5);
const round2 = (value: number): number => Math.round(value * 100) / 100;

function shiftDays(date: string, days: number): string {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function clock(at = new Date()): string {
  return `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;
}

/**
 * AnalyticsRepo.dashboard for Postgres. Dates follow the same rule as the rest
 * of this adapter (UTC calendar day). Ten small selects for now; the natural
 * next step is one SQL function so the whole screen is a single round trip.
 */
async function load(instituteId: ID): Promise<OwnerDashboard> {
  const today = new Date().toISOString().slice(0, 10);
  const dayOfWeek = new Date(`${today}T00:00:00Z`).getUTCDay();
  const scoped = (table: string, columns: string) => supabase.from(table).select(columns).eq('institute_id', instituteId);

  const [batches, periods, totalsResult, pending] = await Promise.all([
    rows(scoped('batches', 'id, name, status').in('status', ['active', 'upcoming'])),
    rows(
      scoped('timetables', 'batch_id, teacher_id, starts_at, ends_at, valid_from, valid_to')
        .eq('day_of_week', dayOfWeek)
        .order('starts_at', { ascending: true }),
    ),
    supabase.rpc('dashboard_totals', { p_institute: instituteId, p_day: today }),
    supabase
      .from('memberships')
      .select('id', { count: 'exact', head: true })
      .eq('institute_id', instituteId)
      .eq('status', 'pending'),
  ]);
  if (pending.error) throw pending.error;
  if (totalsResult.error) throw totalsResult.error;
  const totals = (totalsResult.data ?? {}) as Row;
  const enrolledByBatch = (totals.enrolled_by_batch ?? {}) as Record<string, number>;

  const activeNames = new Map(batches.filter((b) => b.status === 'active').map((b) => [text(b.id), text(b.name)]));
  const todays = periods.filter(
    (p) =>
      activeNames.has(text(p.batch_id)) &&
      (!p.valid_from || text(p.valid_from) <= today) &&
      (!p.valid_to || text(p.valid_to) >= today),
  );
  const teacherIds = [...new Set(todays.filter((p) => p.teacher_id).map((p) => text(p.teacher_id)))];

  const [teachers, alerts] = await Promise.all([
    teacherIds.length ? rows(scoped('teacher_profiles', 'id, full_name, photo_url').in('id', teacherIds)) : [],
    progressRepo().computeAlerts(instituteId),
  ]);

  const byBatch = new Map<ID, DashboardBatch>();
  for (const period of todays) {
    const batchId = text(period.batch_id);
    const row = byBatch.get(batchId) ?? {
      batchId,
      name: activeNames.get(batchId) ?? '',
      startsAt: time(period.starts_at),
      endsAt: time(period.ends_at),
      teachers: [],
      studentCount: Number(enrolledByBatch[batchId] ?? 0),
    };
    if (time(period.ends_at) > row.endsAt) row.endsAt = time(period.ends_at);
    const teacher = teachers.find((t) => text(t.id) === text(period.teacher_id));
    if (teacher && !row.teachers.some((t) => t.id === text(teacher.id))) {
      row.teachers.push({
        id: text(teacher.id),
        fullName: text(teacher.full_name),
        photoUrl: teacher.photo_url ? text(teacher.photo_url) : null,
      });
    }
    byBatch.set(batchId, row);
  }
  const batchesToday = [...byBatch.values()];
  const now = clock();
  const current = batchesToday.find((batch) => batch.endsAt > now) ?? batchesToday[batchesToday.length - 1];

  const attendanceTotal = Number(totals.attendance_total ?? 0);
  const attended = Number(totals.attendance_present ?? 0);
  const weekStart = shiftDays(today, 1 - ALERT_WINDOW_DAYS);

  return {
    date: today,
    batchCount: batches.length,
    collectedToday: round2(Number(totals.collected ?? 0)),
    attendancePercent: attendanceTotal ? Math.round((attended / attendanceTotal) * 1000) / 10 : null,
    pendingApprovals: pending.count ?? 0,
    overdueAmount: round2(Number(totals.overdue_amount ?? 0)),
    overdueStudents: Number(totals.overdue_students ?? 0),
    lowAttendanceAlerts: alerts.filter(
      (a) => a.kind === 'low_attendance' && a.status === 'open' && a.detectedAt.slice(0, 10) >= weekStart,
    ).length,
    batchesToday,
    currentBatchId: current?.batchId ?? null,
  };
}

/** Same fallback rule as every repo in this adapter: unreachable database → the bundled reference data. */
export const dashboard: AnalyticsRepo['dashboard'] = async (instituteId) => {
  try {
    return await load(instituteId);
  } catch (error) {
        throw handleSupabaseError(error);
      }
};
