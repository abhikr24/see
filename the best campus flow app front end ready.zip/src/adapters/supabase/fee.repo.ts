import type { FeeStructure, FeeSummary, ID, Installment, InstallmentStatus, StudentFee, Upsert } from '../../core/contracts/models';
import type { AssignFeeInput, FeeRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { feePlanRepo } from './fee-plan.repo';
import { collectionOverview } from '../../core/contracts/fee-collection';
import { mapBatch, mapEnrollment, mapGuardian, mapPayment, mapReceipt, mapStudent } from './mappers';
import { mapFeeStructure, mapInstallment, mapStudentFee } from './mappers';

export function feeRepo(): FeeRepo {
  return {
    async listStructures(instituteId: ID, query?: ListQuery<FeeStructure>): Promise<Page<FeeStructure>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('fee_structures').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapFeeStructure), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async saveStructure(instituteId: ID, input: Upsert<FeeStructure, 'name' | 'academicYear' | 'totalAmount'>): Promise<FeeStructure> {
      try {
        const row = {
          institute_id: instituteId, name: input.name, academic_year: input.academicYear,
          total_amount: input.totalAmount, batch_id: input.batchId ?? null,
          installment_count: input.installmentCount ?? 1, frequency: input.frequency ?? 'term',
          components: input.components ?? [], late_fee_per_day: input.lateFeePerDay ?? 0,
          is_active: input.isActive ?? true,
        };
        const op = input.id
          ? supabase.from('fee_structures').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('fee_structures').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapFeeStructure(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listStudentFees(instituteId: ID, query?: ListQuery<StudentFee>): Promise<Page<StudentFee>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('student_fees').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapStudentFee), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async assign(instituteId: ID, input: AssignFeeInput): Promise<StudentFee> {
      try {
        const { data: st } = await supabase.from('fee_structures').select('*').eq('id', input.feeStructureId).single();
        const gross = st?.total_amount ?? 0;
        const discount = input.discountAmount ?? 0;
        const { data, error } = await supabase.from('student_fees').insert({
          institute_id: instituteId, student_id: input.studentId, fee_structure_id: input.feeStructureId,
          academic_year: st?.academic_year ?? '2026-27', gross_amount: gross,
          discount_amount: discount, discount_reason: input.discountReason ?? null, status: 'active',
        }).select().single();
        if (error) throw error;
        return mapStudentFee(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listInstallments(instituteId: ID, filter?: { studentId?: ID; studentFeeId?: ID; status?: InstallmentStatus }): Promise<Installment[]> {
      try {
        let q = supabase.from('installments').select('*').eq('institute_id', instituteId);
        if (filter?.studentId) q = q.eq('student_id', filter.studentId);
        if (filter?.studentFeeId) q = q.eq('student_fee_id', filter.studentFeeId);
        if (filter?.status) q = q.eq('status', filter.status);
        const { data, error } = await q.order('due_date', { ascending: true });
        if (error) throw error;
        return (data ?? []).map(mapInstallment);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async waiveInstallment(instituteId: ID, installmentId: ID): Promise<Installment> {
      try {
        const { data, error } = await supabase.from('installments').update({
          status: 'waived',
        }).eq('institute_id', instituteId).eq('id', installmentId).select().single();
        if (error) throw error;
        return mapInstallment(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async totals(instituteId: ID) {
      try {
        const tables = ['installments', 'students', 'student_fees', 'batches', 'enrollments', 'guardians', 'parent_links', 'payments', 'receipts'] as const;
        const results = await Promise.all(tables.map(table => supabase.from(table).select('*').eq('institute_id', instituteId)));
        if (results.some(result => result.error)) throw results.find(result => result.error)?.error;
        const [installments, students, fees, batches, enrollments, guardians, links, payments, receipts] = results.map(result => result.data ?? []);
        const overview = collectionOverview({
          installments: installments.map(mapInstallment), students: students.map(mapStudent), fees: fees.map(mapStudentFee),
          batches: batches.map(mapBatch), enrollments: enrollments.map(mapEnrollment), guardians: guardians.map(mapGuardian),
          links: links.map(row => ({ ...row, studentId: String(row.student_id), guardianId: String(row.guardian_id), isPrimary: Boolean(row.is_primary) })) as import('../../core/contracts/models').ParentLink[],
          payments: payments.map(mapPayment), receipts: receipts.map(mapReceipt),
        });
        const { data: totals, error: totalsError } = await supabase.rpc('fee_collection_summary', { p_institute_id: instituteId });
        if (totalsError) throw totalsError;
        if (!totals) throw new Error('Fee totals query returned no result');
        const exact = totals as { expected: number; collected: number; pending: number; overdue: number; overdueCount: number };
        return { ...overview, totals: { expected: Number(exact.expected), collected: Number(exact.collected), pending: Number(exact.pending), overdue: Number(exact.overdue), overdueCount: Number(exact.overdueCount) } };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async summary(instituteId: ID): Promise<FeeSummary> {
      try {
        const insts = await this.listInstallments(instituteId);
        let billed = 0, collected = 0, outstanding = 0, overdue = 0, overdueCount = 0;
        const today = new Date().toISOString().slice(0, 10);
        for (const inst of insts) {
          if (inst.status === 'waived') continue;
          billed += inst.amount;
          collected += inst.paidAmount;
          const rem = Math.max(0, inst.amount - inst.paidAmount);
          outstanding += rem;
          if (rem > 0 && inst.dueDate < today) {
            overdue += rem;
            overdueCount++;
          }
        }
        return { billed, collected, outstanding, overdue, overdueInstallments: overdueCount };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    ...feePlanRepo(),
  };
}
