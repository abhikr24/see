import { computeAdmissionsSummary, normalizePhone10, segmentForStage } from '../../core/contracts/admissions';
import { BackendError } from '../../core/contracts/errors';
import type {
  AdmissionLead, AdmissionsPipeline, ConvertLeadInput, ConvertLeadResult, ID, LeadAssigneeOption, LeadDetail, LeadFollowup, LeadStage, LeadStageChange, NewEntity, Patch, Role, } from '../../core/contracts/models';
import type { AddFollowupInput, LeadRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, parseCursor, supabase, toPaginatedResult, handleSupabaseError } from './client';
import { mapEnrollment, mapGuardian, mapLead, mapLeadFollowup, mapStudent, mapStudentFee } from './mappers';

export function leadRepo(): LeadRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<AdmissionLead>): Promise<Page<AdmissionLead>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('admission_leads').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.stage) q = q.eq('stage', query.where.stage);
        if (query?.search) q = q.ilike('student_name', `%${query.search}%`);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapLead), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async get(instituteId: ID, id: ID): Promise<AdmissionLead> {
      try {
        const { data, error } = await supabase.from('admission_leads').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapLead(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async pipeline(instituteId: ID): Promise<AdmissionsPipeline> {
      try {
        const [leadsRes, followupsRes, membersRes] = await Promise.all([
          supabase.from('admission_leads').select('*').eq('institute_id', instituteId).order('created_at', { ascending: false }),
          supabase.from('lead_followups').select('*').eq('institute_id', instituteId).order('followup_at', { ascending: false }),
          supabase.from('memberships').select('user_id, role, profiles(full_name)').eq('institute_id', instituteId).eq('status', 'active').in('role', ['owner', 'admin', 'teacher']),
        ]);
        if (leadsRes.error) throw leadsRes.error;
        if (followupsRes.error) throw followupsRes.error;
        if (membersRes.error) throw membersRes.error;

        const leads = (leadsRes.data ?? []).map(mapLead);
        const followups = (followupsRes.data ?? []).map(mapLeadFollowup);
        const latestByLead = new Map<ID, LeadFollowup>();
        for (const f of followups) if (!latestByLead.has(f.leadId)) latestByLead.set(f.leadId, f);

        const assignees: LeadAssigneeOption[] = (membersRes.data ?? []).map((row: Record<string, unknown>) => {
          const prof = row.profiles as { full_name?: string } | null;
          return { userId: String(row.user_id), fullName: prof?.full_name ?? 'Staff member', role: String(row.role) as Role };
        });
        const nameById = new Map(assignees.map((a) => [a.userId, a.fullName]));

        return {
          summary: computeAdmissionsSummary(leads, followups),
          items: leads.map((lead) => {
            const latest = latestByLead.get(lead.id) ?? null;
            return {
              lead,
              segment: segmentForStage(lead.stage),
              lastFollowupAt: latest?.followupAt ?? null,
              lastFollowupChannel: latest?.channel ?? null,
              assignedToName: lead.assignedTo ? (nameById.get(lead.assignedTo) ?? null) : null,
            };
          }),
          assignees,
        };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async detail(instituteId: ID, leadId: ID): Promise<LeadDetail> {
      try {
        const [leadRes, followupsRes, logsRes] = await Promise.all([
          supabase.from('admission_leads').select('*').eq('institute_id', instituteId).eq('id', leadId).single(),
          supabase.from('lead_followups').select('*').eq('institute_id', instituteId).eq('lead_id', leadId).order('followup_at', { ascending: false }),
          supabase.from('audit_logs').select('*').eq('institute_id', instituteId).eq('entity_type', 'admission_lead').eq('entity_id', leadId).order('created_at', { ascending: false }),
        ]);
        if (leadRes.error) throw leadRes.error;
        if (followupsRes.error) throw followupsRes.error;
        if (logsRes.error) throw logsRes.error;

        const lead = mapLead(leadRes.data);
        const followups = (followupsRes.data ?? []).map(mapLeadFollowup);
        const userIds = [...new Set([lead.assignedTo, ...followups.map((f) => f.doneBy), ...(logsRes.data ?? []).map((l: Record<string, unknown>) => (l.actor_id ? String(l.actor_id) : null))].filter((x): x is string => Boolean(x)))];
        const nameMap = new Map<string, string>();
        if (userIds.length > 0) {
          const { data: profiles } = await supabase.from('profiles').select('id, full_name').in('id', userIds);
          for (const p of profiles ?? []) nameMap.set(String(p.id), String(p.full_name));
        }

        const stageChanges: LeadStageChange[] = (logsRes.data ?? [])
          .filter((l: Record<string, unknown>) => ['lead.created', 'lead.stage_changed', 'lead.converted'].includes(String(l.action)))
          .map((l: Record<string, unknown>) => {
            const oldData = (l.old_data ?? {}) as Record<string, unknown>;
            const newData = (l.new_data ?? {}) as Record<string, unknown>;
            return {
              id: String(l.id),
              fromStage: (oldData.stage as LeadStage | undefined) ?? null,
              toStage: (newData.stage as LeadStage | undefined) ?? lead.stage,
              lostReason: (newData.lostReason as string | null | undefined) ?? null,
              actorName: l.actor_id ? (nameMap.get(String(l.actor_id)) ?? null) : null,
              changedAt: String(l.created_at),
            };
          });

        return {
          lead,
          segment: segmentForStage(lead.stage),
          assignedToName: lead.assignedTo ? (nameMap.get(lead.assignedTo) ?? null) : null,
          followups: followups.map((followup) => ({ followup, doneByName: followup.doneBy ? (nameMap.get(followup.doneBy) ?? null) : null })),
          stageChanges,
        };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async create(instituteId: ID, input: NewEntity<AdmissionLead, 'studentName'>): Promise<AdmissionLead> {
      try {
        const { data, error } = await supabase.from('admission_leads').insert({
          institute_id: instituteId, student_name: input.studentName.trim(), branch_id: input.branchId ?? null,
          guardian_name: input.guardianName ?? null, phone: input.phone ? normalizePhone10(input.phone) : null,
          email: input.email ?? null, class_interested: input.classInterested ?? null,
          subject_interest: input.subjectInterest ?? null, school_name: input.schoolName ?? null,
          source: input.source ?? 'walk_in', stage: input.stage ?? 'new', assigned_to: input.assignedTo ?? null,
          expected_fee: input.expectedFee ?? null, next_followup_at: input.nextFollowupAt ?? null,
          next_followup_note: input.nextFollowupNote ?? null, notes: input.notes ?? null,
        }).select().single();
        if (error) throw error;
        return mapLead(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<AdmissionLead>): Promise<AdmissionLead> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.studentName !== undefined) row.student_name = patch.studentName;
        if (patch.guardianName !== undefined) row.guardian_name = patch.guardianName;
        if (patch.phone !== undefined) row.phone = patch.phone;
        if (patch.email !== undefined) row.email = patch.email;
        if (patch.classInterested !== undefined) row.class_interested = patch.classInterested;
        if (patch.subjectInterest !== undefined) row.subject_interest = patch.subjectInterest;
        if (patch.stage !== undefined) row.stage = patch.stage;
        if (patch.nextFollowupAt !== undefined) row.next_followup_at = patch.nextFollowupAt;
        if (patch.nextFollowupNote !== undefined) row.next_followup_note = patch.nextFollowupNote;
        if (patch.lostReason !== undefined) row.lost_reason = patch.lostReason;
        if (patch.notes !== undefined) row.notes = patch.notes;
        const { data, error } = await supabase.from('admission_leads').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapLead(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async remove(): Promise<void> {
      throw new BackendError('CONFLICT', 'Leads cannot be deleted; mark as lost with a reason');
    },

    async moveStage(instituteId: ID, id: ID, stage: LeadStage, lostReason?: string | null): Promise<AdmissionLead> {
      try {
        const { data, error } = await supabase.rpc('move_admission_lead_stage', { p_institute: instituteId, p_lead: id, p_stage: stage, p_lost_reason: lostReason ?? null });
        if (error) throw error;
        return mapLead(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listFollowups(instituteId: ID, leadId: ID): Promise<LeadFollowup[]> {
      try {
        const { data, error } = await supabase.from('lead_followups').select('*').eq('institute_id', instituteId).eq('lead_id', leadId).order('followup_at', { ascending: false });
        if (error) throw error;
        return (data ?? []).map(mapLeadFollowup);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async addFollowup(instituteId: ID, input: AddFollowupInput): Promise<LeadFollowup> {
      try {
        const { data, error } = await supabase.rpc('add_admission_followup', {
          p_institute: instituteId, p_lead: input.leadId, p_channel: input.channel ?? 'call',
          p_summary: input.summary ?? null, p_outcome: input.outcome ?? null,
          p_followup_at: input.followupAt ?? new Date().toISOString(),
          p_next_followup_at: input.nextFollowupAt ?? null, p_next_followup_note: input.nextFollowupNote ?? null,
        });
        if (error) throw error;
        return mapLeadFollowup(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async convert(instituteId: ID, input: ConvertLeadInput): Promise<ConvertLeadResult> {
      try {
        const { data, error } = await supabase.rpc('convert_admission_lead', {
          p_institute: instituteId, p_lead: input.leadId, p_student_name: input.studentName,
          p_phone: normalizePhone10(input.phone), p_guardian_name: input.guardianName ?? null,
          p_guardian_phone: input.guardianPhone ? normalizePhone10(input.guardianPhone) : null,
          p_guardian_relation: input.guardianRelation ?? 'guardian', p_batch: input.batchId,
          p_roll_number: input.rollNumber ?? null, p_monthly_fee: input.monthlyFee ?? null,
          p_fee_structure: input.feeStructureId ?? null, p_discount_ids: input.discountIds ?? [],
          p_first_due_date: input.firstDueDate ?? new Date().toISOString().slice(0, 10),
        });
        if (error) throw error;
        const payload = data as Record<string, Record<string, unknown> | null>;
        return {
          lead: mapLead(payload.lead!), student: mapStudent(payload.student!), guardian: mapGuardian(payload.guardian!),
          enrollment: mapEnrollment(payload.enrollment!), studentFee: payload.studentFee ? mapStudentFee(payload.studentFee) : null,
        };
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
