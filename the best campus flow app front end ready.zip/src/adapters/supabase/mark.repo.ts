import type { ID, Mark } from '../../core/contracts/models';
import type { MarkEntry, MarkRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { mapMark } from './mappers';
import { assertOwnBatch, ownBatchIds, teacherScope } from './teacher-scope';

export function markRepo(): MarkRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Mark>): Promise<Page<Mark>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('marks').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        const scope = await teacherScope(instituteId);
        if (scope) {
          const batchIds = await ownBatchIds(instituteId, scope);
          if (batchIds.length === 0) return toPaginatedResult<Mark>([], 0, offset, limit);
          q = q.in('batch_id', batchIds);
        }
        if (query?.where?.examId) q = q.eq('exam_id', query.where.examId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapMark), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Mark> {
      try {
        const { data, error } = await supabase.from('marks').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        const scope = await teacherScope(instituteId);
        if (scope) await assertOwnBatch(instituteId, String(data.batch_id));
        return mapMark(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async saveMany(instituteId: ID, examId: ID, entries: MarkEntry[]): Promise<Mark[]> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const userId = user?.user?.id ?? null;
        const { data: exam, error: examError } = await supabase
          .from('exams')
          .select('batch_id')
          .eq('institute_id', instituteId)
          .eq('id', examId)
          .single();
        if (examError) throw examError;
        const scope = await teacherScope(instituteId);
        if (scope) await assertOwnBatch(instituteId, String(exam.batch_id));
        const batchId = exam.batch_id as string;

        const rows = entries.map((e) => ({
          institute_id: instituteId, exam_id: examId, batch_id: batchId, student_id: e.studentId,
          subject_id: e.subjectId, marks_obtained: e.marksObtained, max_marks: e.maxMarks,
          is_absent: e.isAbsent ?? false, remark: e.remark ?? null, entered_by: userId,
        }));

        const { data, error } = await supabase.from('marks').upsert(rows, { onConflict: 'exam_id,student_id,subject_id' }).select();
        if (error) throw error;
        return (data ?? []).map(mapMark);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
