import type { BackupStatus, ExportJob, ID, ImportResult, RealtimeEvent, RealtimeStatus, RealtimeTopic } from '../../core/contracts/models';
import type { ExportRepo, ExportRequest, RealtimePort, RealtimeSubscription } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { supabase, handleSupabaseError } from './client';

export function exportRepo(): ExportRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<ExportJob>): Promise<Page<ExportJob>> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    async start(instituteId: ID, request: ExportRequest): Promise<ExportJob> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    async get(instituteId: ID, jobId: ID): Promise<ExportJob> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    status(instituteId: ID): Promise<BackupStatus> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    recordBackup(instituteId: ID): Promise<BackupStatus> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    content(instituteId: ID, jobId: ID): Promise<string> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    importJson(instituteId: ID, payload: string): Promise<ImportResult> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    clearAll(instituteId: ID, confirmation: string) {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
  };
}

/** The table whose row changes feed each topic. */
const TOPIC_TABLE: Record<RealtimeTopic, string> = {
  memberships: 'memberships',
  attendance: 'attendance_records',
  notices: 'notices',
  notifications: 'notifications',
  doubts: 'doubts',
  leave_requests: 'leave_requests',
  conversations: 'conversations',
  payments: 'payments',
};

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

/** Two screens may follow the same topic at once (the tab badge and the inbox); each gets its own channel. */
let channelSeq = 0;

export function realtimePort(): RealtimePort {
  return {
    async status(instituteId: ID): Promise<RealtimeStatus> {
      return 'connected';
    },
    async subscribe(instituteId: ID, topic: RealtimeTopic, onEvent: (event: RealtimeEvent) => void): Promise<RealtimeSubscription> {
      // No project configured: writes land in the bundled reference data, so its change feed is the live one.
      if (!live) throw handleSupabaseError(new Error('Supabase is not configured for this operation.'));
      channelSeq += 1;
      const channel = supabase.channel(`institute_${instituteId}_${topic}_${channelSeq}`)
        // Row policies still apply: a person only ever hears about rows they may read (their own notifications).
        .on('postgres_changes', { event: '*', schema: 'public', table: TOPIC_TABLE[topic], filter: `institute_id=eq.${instituteId}` }, (payload) => {
          onEvent({
            topic,
            change: payload.eventType === 'INSERT' ? 'created' : payload.eventType === 'DELETE' ? 'removed' : 'updated',
            id: (payload.new as any)?.id ?? (payload.old as any)?.id ?? '',
            at: new Date().toISOString(),
          });
        })
        .subscribe();
      return {
        topic,
        unsubscribe: async () => {
          await supabase.removeChannel(channel);
        },
      };
    },
  };
}
