import { BackendError } from '../../core/contracts/errors';
import type { AppNotification, ID, NewEntity } from '../../core/contracts/models';
import type { NotificationRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { mapNotification } from './mappers';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

export function notificationRepo(): NotificationRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<AppNotification>): Promise<Page<AppNotification>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('notifications').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.userId) q = q.eq('user_id', query.where.userId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapNotification), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async unreadCount(instituteId: ID): Promise<number> {
      try {
        const { count, error } = await supabase.from('notifications').select('*', { count: 'exact', head: true })
          .eq('institute_id', instituteId).is('read_at', null);
        if (error) throw error;
        return count ?? 0;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async markRead(instituteId: ID, id: ID): Promise<AppNotification> {
      try {
        const { data, error } = await supabase.from('notifications').update({
          read_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapNotification(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async markAllRead(instituteId: ID): Promise<number> {
      try {
        const { data, error } = await supabase.from('notifications').update({
          read_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).is('read_at', null).select();
        if (error) throw error;
        return data?.length ?? 0;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async dismiss(instituteId: ID, id: ID): Promise<void> {
      if (!live) throw handleSupabaseError(new Error('Supabase is not configured for this operation.'));
      // Row policy (0008): a person may delete only their own notifications. `select` proves a row went.
      const { data, error } = await supabase.from('notifications').delete()
        .eq('institute_id', instituteId).eq('id', id).select('id');
      if (error) throw handleSupabaseError(error, 'Could not dismiss the notification');
      if (!data || data.length === 0) throw new BackendError('NOT_FOUND', 'Notification not found');
    },

    async send(instituteId: ID, input: NewEntity<AppNotification, 'userId' | 'title'>): Promise<AppNotification> {
      try {
        const { data, error } = await supabase.from('notifications').insert({
          institute_id: instituteId, user_id: input.userId, title: input.title,
          type: input.type ?? 'general', body: input.body ?? null, data: input.data ?? {},
          channel: input.channel ?? 'in_app', sent_at: new Date().toISOString(),
        }).select().single();
        if (error) throw error;
        return mapNotification(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
