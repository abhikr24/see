import type { ID, Money, NewEntity, Payment, PaymentMethod, PaymentOrder, Refund } from '../../core/contracts/models';
import type { PaymentPort, PaymentRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { BackendError } from '../../core/contracts/errors';
import { ONLINE_PAYMENT_OFF } from '../../core/contracts/family';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { assertLinkedChild } from './family-context';
import { mapPayment, mapRefund } from './mappers';

export function paymentRepo(): PaymentRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Payment>): Promise<Page<Payment>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('payments').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('paid_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapPayment), count, offset, limit);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async get(instituteId: ID, id: ID): Promise<Payment> {
      try {
        const { data, error } = await supabase.from('payments').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapPayment(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async record(instituteId: ID, input: NewEntity<Payment, 'studentId' | 'studentFeeId' | 'amount' | 'method'>): Promise<Payment> {
      if (!process.env.EXPO_PUBLIC_SUPABASE_URL) throw handleSupabaseError(new Error('Supabase is not configured for this operation.'));
      if (!input.installmentId) throw handleSupabaseError({ code: '23514', message: 'Choose a term to collect' });
      if (input.method === 'upi' && !input.referenceNo?.trim()) throw handleSupabaseError({ code: '23514', message: 'UPI reference required' });
      const { data, error } = await supabase.rpc('record_fee_payment', {
        p_institute: instituteId, p_student: input.studentId, p_fee: input.studentFeeId, p_installment: input.installmentId,
        p_amount: input.amount, p_method: input.method, p_reference: input.referenceNo ?? '', p_paid_at: input.paidAt ?? new Date().toISOString(),
      });
      if (error) throw handleSupabaseError(error);
      return mapPayment(data);
    },
    async reject(instituteId: ID, paymentId: ID): Promise<Payment> {
      if (!process.env.EXPO_PUBLIC_SUPABASE_URL) throw handleSupabaseError(new Error('Supabase is not configured for this operation.'));
      const { data, error } = await supabase.rpc('reject_fee_payment', { p_institute: instituteId, p_payment: paymentId });
      if (error) throw handleSupabaseError(error);
      return mapPayment(data);
    },
    async listRefunds(instituteId: ID, filter?: { paymentId?: ID; studentId?: ID }): Promise<Refund[]> {
      try {
        let q = supabase.from('refunds').select('*').eq('institute_id', instituteId);
        if (filter?.paymentId) q = q.eq('payment_id', filter.paymentId);
        if (filter?.studentId) q = q.eq('student_id', filter.studentId);
        const { data, error } = await q;
        if (error) throw error;
        return (data ?? []).map(mapRefund);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async requestRefund(instituteId: ID, input: { paymentId: ID; amount: Money; reason?: string | null }): Promise<Refund> {
      try {
        const { data: pay } = await supabase.from('payments').select('student_id').eq('id', input.paymentId).single();
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('refunds').insert({
          institute_id: instituteId, payment_id: input.paymentId, student_id: pay?.student_id ?? '00000000-0000-4000-8000-000000000014',
          amount: input.amount, reason: input.reason ?? null, status: 'requested', requested_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapRefund(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
    async decideRefund(instituteId: ID, refundId: ID, status: 'approved' | 'rejected' | 'processed'): Promise<Refund> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('refunds').update({
          status, approved_by: user?.user?.id ?? null, processed_at: status === 'processed' ? new Date().toISOString() : null,
        }).eq('institute_id', instituteId).eq('id', refundId).select().single();
        if (error) throw error;
        return mapRefund(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}

export function paymentGatewayPort(): PaymentPort {
  return {
    async createIntent(instituteId: ID, input: { studentId: ID; installmentId: ID }) {
      // Access first: a parent may only start a payment for their own child's installment.
      await assertLinkedChild(instituteId, input.studentId);
      const { data, error } = await supabase.from('installments').select('student_id, amount, paid_amount, status')
        .eq('institute_id', instituteId).eq('id', input.installmentId).maybeSingle();
      if (error) throw handleSupabaseError(error);
      if (!data || String(data.student_id) !== input.studentId) throw new BackendError('NOT_FOUND', 'Fee not found');
      if (data.status === 'paid' || data.status === 'waived') throw new BackendError('CONFLICT', 'This fee has already been paid');
      // No gateway is configured yet. Nothing is started and no pending row is written.
      throw new BackendError('NOT_IMPLEMENTED', ONLINE_PAYMENT_OFF);
    },
    async listMethods(instituteId: ID): Promise<PaymentMethod[]> {
      return ['upi', 'card', 'bank_transfer', 'online'];
    },
    async createOrder(instituteId: ID, input: { studentId: ID; installmentId: ID; amount: Money }): Promise<PaymentOrder> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    async getOrder(instituteId: ID, orderId: ID): Promise<PaymentOrder> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    async confirm(instituteId: ID, orderId: ID, proof: { providerPaymentId: string; signature?: string }): Promise<Payment> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
  };
}
