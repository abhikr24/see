import type {
  AttendanceSummary, ID, InstituteSettings, Intervention, InterventionOutcome, NewEntity, ProgressSnapshot,
  RiskAlert, RiskKind, RiskLevel, Student360, StudentAchievement, StudentGoal, StudyTask, Upsert,
} from '../../core/contracts/models';
import type { ProgressPort } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { mapIntervention, mapStudentGoal, mapStudyTask } from './mappers';
import { listFallingStudents } from './teacher.repo';

/**
 * Progress early-warning rules. Values mirror PROGRESS_RULES in
 * src/core/contracts/progress.ts (the source of truth the reference backend
 * evaluates); keep the two in sync.
 */
export const PROGRESS_RULES = {
  /** low_attendance: below this % over the last 30 days. */
  LOW_ATTENDANCE_PCT: 75,
  /** low_attendance + sudden_absence look-back window. */
  ATTENDANCE_WINDOW_DAYS: 30,
  /** Fewer records than this in the window is too little to call a trend. */
  ATTENDANCE_MIN_RECORDS: 5,
  /** declining_marks: the oldest of the last 3 tests minus the latest, in points. */
  MARKS_DROP_POINTS: 10,
  /** declining_marks compares exactly this many published tests. */
  MARKS_TEST_COUNT: 3,
  /** work_incomplete: below this % of homework submitted in the last 14 days. */
  HOMEWORK_MIN_PCT: 60,
  /** work_incomplete look-back window for due dates. */
  HOMEWORK_WINDOW_DAYS: 14,
  /** sudden_absence: this many absent days in a row. */
  SUDDEN_ABSENCE_DAYS: 3,
  /** improving: the latest test minus the one before it, in points. */
  IMPROVING_MARKS_POINTS: 10,
  /** improving: attendance at or above this % in the last fortnight, after a dip. */
  IMPROVING_ATTENDANCE_PCT: 90,
  /** improving: the fortnight before must have been below this % (the dip). */
  IMPROVING_PRIOR_PCT: 75,
  /** improving compares two windows of this many days. */
  IMPROVING_WINDOW_DAYS: 14,
  /** Fewer records than this in either improving window is too little to compare. */
  IMPROVING_MIN_RECORDS: 3,
} as const;

export function progressRepo(): ProgressPort {
  return {
    async getStudent360(instituteId: ID, studentId: ID): Promise<Student360> {
      try {
        throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async computeSnapshot(instituteId: ID, studentId: ID): Promise<ProgressSnapshot> {
      try {
        throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listSnapshots(instituteId: ID, studentId: ID): Promise<ProgressSnapshot[]> {
      try {
        throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listAlerts(instituteId: ID, query?: ListQuery<RiskAlert>): Promise<Page<RiskAlert>> {
      try {
        throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async computeAlerts(instituteId: ID, filter?: { batchId?: ID; studentId?: ID }): Promise<RiskAlert[]> {
      try {
        throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    listFallingStudents,

    async setAlertStatus(instituteId: ID, alertId: ID, status: RiskAlert['status']): Promise<RiskAlert> {
      try {
        throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
      } catch (err) {
        throw handleSupabaseError(err);
      }
    },

    async listInterventions(instituteId: ID, filter?: { studentId?: ID }): Promise<Intervention[]> {
      try {
        let query = supabase
          .from('interventions')
          .select('*')
          .eq('institute_id', instituteId)
          .order('done_on', { ascending: false })
          .order('created_at', { ascending: false });
        if (filter?.studentId) query = query.eq('student_id', filter.studentId);
        const { data, error } = await query;
        if (error) throw error;
        return (data ?? []).map(mapIntervention);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async logIntervention(
      instituteId: ID,
      input: NewEntity<Intervention, 'studentId' | 'kind' | 'doneBy' | 'doneOn'>,
    ): Promise<Intervention> {
      try {
        const { data, error } = await supabase
          .from('interventions')
          .insert({
            institute_id: instituteId,
            student_id: input.studentId,
            batch_id: input.batchId ?? null,
            alert_id: input.alertId ?? null,
            kind: input.kind,
            note: input.note ?? null,
            done_by: input.doneBy,
            done_on: input.doneOn,
            outcome: null,
            closed_at: null,
          })
          .select()
          .single();
        if (error) throw error;
        return mapIntervention(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async setInterventionOutcome(instituteId: ID, id: ID, outcome: InterventionOutcome): Promise<Intervention> {
      try {
        const { data, error } = await supabase
          .from('interventions')
          .update({ outcome, closed_at: new Date().toISOString() })
          .eq('institute_id', instituteId)
          .eq('id', id)
          .select()
          .single();
        if (error) throw error;
        return mapIntervention(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listTasks(instituteId: ID, studentId: ID): Promise<StudyTask[]> {
      try {
        const { data, error } = await supabase.from('study_tasks').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapStudyTask);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async saveTask(instituteId: ID, input: Upsert<StudyTask, 'studentId' | 'title'>): Promise<StudyTask> {
      try {
        const row = {
          institute_id: instituteId, student_id: input.studentId, title: input.title,
          subject_id: input.subjectId ?? null, notes: input.notes ?? null, due_on: input.dueOn ?? null,
          priority: input.priority ?? 'medium', status: input.status ?? 'todo',
          completed_at: input.status === 'done' ? new Date().toISOString() : null,
          source: input.source ?? 'self',
        };
        const op = input.id
          ? supabase.from('study_tasks').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('study_tasks').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapStudyTask(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async removeTask(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('study_tasks').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listGoals(instituteId: ID, studentId: ID): Promise<StudentGoal[]> {
      try {
        const { data, error } = await supabase.from('student_goals').select('*').eq('institute_id', instituteId).eq('student_id', studentId);
        if (error) throw error;
        return (data ?? []).map(mapStudentGoal);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async syncAchievements(instituteId: ID, studentId: ID): Promise<StudentAchievement[]> {
      try {
        const now = new Date();
        const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString().slice(0, 10);
        const monthEnd = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1)).toISOString().slice(0, 10);
        const { data: sessionRows, error: sessionError } = await supabase.from('attendance_sessions').select('id,date').eq('institute_id', instituteId).gte('date', monthStart).lt('date', monthEnd).neq('status', 'open');
        if (sessionError) throw sessionError;
        const sessionIds = (sessionRows ?? []).map((row) => String(row.id));
        const { data: attendanceRows, error: attendanceError } = sessionIds.length
          ? await supabase.from('attendance_records').select('status').eq('institute_id', instituteId).eq('student_id', studentId).in('session_id', sessionIds)
          : { data: [], error: null };
        if (attendanceError) throw attendanceError;
        const { data: submissions, error: submissionsError } = await supabase.from('submissions').select('assignment_id,submitted_at').eq('institute_id', instituteId).eq('student_id', studentId).not('submitted_at', 'is', null);
        if (submissionsError) throw submissionsError;
        const assignmentIds = [...new Set((submissions ?? []).map((row) => String(row.assignment_id)))];
        const { data: assignmentRows, error: assignmentError } = assignmentIds.length
          ? await supabase.from('assignments').select('id,due_at').eq('institute_id', instituteId).in('id', assignmentIds)
          : { data: [], error: null };
        if (assignmentError) throw assignmentError;
        const dueById = new Map((assignmentRows ?? []).map((row) => [String(row.id), row.due_at ? String(row.due_at) : null]));
        const onTime = (submissions ?? []).filter((row) => {
          const dueAt = dueById.get(String(row.assignment_id));
          return Boolean(dueAt && row.submitted_at && String(row.submitted_at) <= dueAt);
        }).length;
        const { data: resultRows, error: resultsError } = await supabase.from('results').select('exam_id,percentage').eq('institute_id', instituteId).eq('student_id', studentId);
        if (resultsError) throw resultsError;
        const resultExamIds = [...new Set((resultRows ?? []).map((row) => String(row.exam_id)))];
        const { data: publishedExams, error: examsError } = resultExamIds.length
          ? await supabase.from('exams').select('id').eq('institute_id', instituteId).eq('status', 'published').in('id', resultExamIds)
          : { data: [], error: null };
        if (examsError) throw examsError;
        const publishedIds = new Set((publishedExams ?? []).map((row) => String(row.id)));
        const earned = [
          { key: 'perfect_attendance_month', title: 'Perfect attendance', description: 'Every class attended this month', ok: (attendanceRows ?? []).length > 0 && (attendanceRows ?? []).every((row) => row.status === 'present' || row.status === 'late') },
          { key: 'homework_streak_10', title: 'Homework hero', description: '10 homework assignments handed in on time', ok: onTime >= 10 },
          { key: 'first_90_score', title: 'First 90+', description: 'Earned 90% or higher on a published exam', ok: (resultRows ?? []).some((row) => publishedIds.has(String(row.exam_id)) && Number(row.percentage) >= 90) },
        ].filter((item) => item.ok);
        if (earned.length) {
          const rows = earned.map((item) => ({ institute_id: instituteId, student_id: studentId, achievement_key: item.key, title: item.title, description: item.description }));
          const { error } = await supabase.from('student_achievements').upsert(rows, { onConflict: 'institute_id,student_id,achievement_key', ignoreDuplicates: true });
          if (error) throw error;
        }
        const { data, error } = await supabase.from('student_achievements').select('*').eq('institute_id', instituteId).eq('student_id', studentId).order('earned_at', { ascending: true });
        if (error) throw error;
        return (data ?? []).map((row) => ({ id: String(row.id), instituteId: String(row.institute_id), studentId: String(row.student_id), key: row.achievement_key as StudentAchievement['key'], title: String(row.title), description: String(row.description), earnedAt: String(row.earned_at), celebratedAt: row.celebrated_at ? String(row.celebrated_at) : null, createdAt: String(row.created_at), updatedAt: String(row.updated_at) }));
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async markAchievementCelebrated(instituteId: ID, studentId: ID, achievementId: ID): Promise<boolean> {
      try {
        const { data, error } = await supabase.from('student_achievements').update({ celebrated_at: new Date().toISOString() }).eq('institute_id', instituteId).eq('student_id', studentId).eq('id', achievementId).is('celebrated_at', null).select('id');
        if (error) throw error;
        return Boolean(data?.length);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async saveGoal(instituteId: ID, input: Upsert<StudentGoal, 'studentId' | 'title'>): Promise<StudentGoal> {
      try {
        const row = {
          institute_id: instituteId, student_id: input.studentId, title: input.title,
          subject_id: input.subjectId ?? null, description: input.description ?? null,
          metric: input.metric ?? 'custom', target_value: input.targetValue ?? null,
          current_value: input.currentValue ?? null, starts_on: input.startsOn ?? new Date().toISOString().slice(0, 10),
          target_date: input.targetDate ?? null, status: input.status ?? 'active',
        };
        const op = input.id
          ? supabase.from('student_goals').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('student_goals').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapStudentGoal(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },
  };
}
