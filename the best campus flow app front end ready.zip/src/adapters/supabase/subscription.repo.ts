import type { BillingCycle, BillingMethod, ID, Invoice, Plan, Subscription, UsageRecord } from '../../core/contracts/models';
import type { SubscriptionRepo } from '../../core/contracts/ports';
import type { SubscriptionAccess } from '../../core/contracts/subscription-access';
import { supabase, handleSupabaseError } from './client';
import { mapPlan, mapSubscription, mapUsageRecord } from './mappers';

export function subscriptionRepo(): SubscriptionRepo {
  return {
    async getCurrent(instituteId: ID): Promise<Subscription | null> {
      try {
        const { data, error } = await supabase.from('subscriptions').select('*').eq('institute_id', instituteId).in('status', ['trialing', 'active', 'past_due']).maybeSingle();
        if (error) throw error;
        return data ? mapSubscription(data) : null;
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listPlans(instituteId: ID): Promise<Plan[]> {
      try {
        const { data, error } = await supabase.from('plans').select('*').eq('institute_id', instituteId);
        if (error) throw error;
        if (!data || data.length === 0) return [];
        return data.map(mapPlan);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async changePlan(instituteId: ID, planId: ID, billingCycle: BillingCycle): Promise<Subscription> {
      try {
        const { data, error } = await supabase.from('subscriptions').upsert({
          institute_id: instituteId, plan_id: planId, billing_cycle: billingCycle,
          status: 'active', current_period_start: new Date().toISOString(),
        }).select().single();
        if (error) throw error;
        return mapSubscription(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async cancel(instituteId: ID): Promise<Subscription> {
      try {
        const { data, error } = await supabase.from('subscriptions').update({
          status: 'cancelled', cancelled_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).select().single();
        if (error) throw error;
        return mapSubscription(data);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    async listUsage(instituteId: ID): Promise<UsageRecord[]> {
      try {
        const { data, error } = await supabase.from('usage_records').select('*').eq('institute_id', instituteId);
        if (error) throw error;
        if (!data || data.length === 0) return [];
        return data.map(mapUsageRecord);
      } catch (error) {
        throw handleSupabaseError(error);
      }
    },

    latest(instituteId: ID): Promise<Subscription | null> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    lapse(instituteId: ID) {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    access(instituteId: ID): Promise<SubscriptionAccess> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    billingMethod(instituteId: ID): Promise<BillingMethod> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    setAutopay(instituteId: ID, autopay: boolean): Promise<BillingMethod> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
    listInvoices(instituteId: ID): Promise<Invoice[]> {
      throw handleSupabaseError(new Error('This operation is unavailable in the Supabase backend.'));
    },
  };
}
