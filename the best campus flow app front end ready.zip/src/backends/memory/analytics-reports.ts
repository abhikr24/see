import type { AnalyticsReport, AnalyticsReportQuery, ID, ISODate, AnalyticsReportBar, AnalyticsReportRow } from '../../core/contracts/models';
import type { Db } from './db';
import { addDays, round1, round2, sum, todayIso } from './store';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const title: Record<AnalyticsReportQuery['type'], string> = {
  'student-strength': 'Student strength', 'fee-collection': 'Fee collection', attendance: 'Attendance',
  'academic-performance': 'Academic performance', 'teacher-performance': 'Teacher performance', 'admissions-funnel': 'Admissions funnel',
};
function range(period: AnalyticsReportQuery['period'], today = todayIso()) {
  if (period === 'week') return { from: addDays(today, -6), to: today, days: 7, label: 'Last 7 days' };
  if (period === 'month') return { from: addDays(today, -29), to: today, days: 30, label: 'Last 30 days' };
  const [year, month] = today.split('-').map(Number);
  const startYear = month >= 4 ? year : year - 1;
  return { from: `${startYear}-04-01`, to: today, days: Math.floor((Date.parse(`${today}T00:00:00Z`) - Date.parse(`${startYear}-04-01T00:00:00Z`)) / 86400000) + 1, label: `${startYear}–${String(startYear + 1).slice(-2)} academic year` };
}
const monthBucket = (iso: string) => MONTHS[Number(iso.slice(5, 7)) - 1];
const safePercent = (part: number, total: number) => total ? round1(part * 100 / total) : 0;
const currency = (value: number) => `₹${Math.round(value).toLocaleString('en-IN')}`;
const makeBars = (from: string, to: string, days: number, values: Map<string, number>, monthly = false): AnalyticsReportBar[] => {
  if (monthly) {
    const result: AnalyticsReportBar[] = [];
    const fromDate = new Date(`${from}T00:00:00Z`);
    const toDate = new Date(`${to}T00:00:00Z`);
    const first = new Date(Date.UTC(Math.max(fromDate.getUTCFullYear(), toDate.getUTCFullYear()), toDate.getUTCMonth() - Math.min(5, (toDate.getUTCFullYear() - fromDate.getUTCFullYear()) * 12 + toDate.getUTCMonth() - fromDate.getUTCMonth()), 1));
    for (let step = 0; step < 6; step++) {
      const date = new Date(Date.UTC(first.getUTCFullYear(), first.getUTCMonth() + step, 1));
      const key = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
      result.push({ label: MONTHS[date.getUTCMonth()], value: round2(values.get(key) ?? 0) });
    }
    return result;
  }
  const buckets = Math.min(7, Math.max(1, days));
  return Array.from({ length: buckets }, (_, index) => {
    const bucketFrom = addDays(from, Math.floor(index * days / buckets));
    const bucketTo = index === buckets - 1 ? to : addDays(from, Math.floor((index + 1) * days / buckets) - 1);
    let value = 0;
    for (const [date, amount] of values) if (date >= bucketFrom && date <= bucketTo) value += amount;
    return { label: bucketFrom.slice(8, 10), value: round2(value) };
  });
};

export async function buildMemoryReport(db: Db, instituteId: ID, query: AnalyticsReportQuery): Promise<AnalyticsReport> {
  db.institutes.get(instituteId, instituteId);
  const r = range(query.period);
  const priorFrom = addDays(r.from, -r.days);
  const batchMatches = (id: ID) => !query.batchId || query.batchId === id;
  const studentsById = new Map(db.students.all(instituteId).map((student) => [student.id, student]));
  const batches = db.batches.all(instituteId).filter((batch) => batchMatches(batch.id));
  const batchById = new Map(batches.map((batch) => [batch.id, batch]));
  const enrollments = db.enrollments.all(instituteId).filter((enrollment) => enrollment.status === 'active' && batchMatches(enrollment.batchId));
  const enrolledByStudent = new Map<ID, ID[]>();
  for (const enrollment of enrollments) enrolledByStudent.set(enrollment.studentId, [...(enrolledByStudent.get(enrollment.studentId) ?? []), enrollment.batchId]);
  let headlineLabel = 'Total'; let headlineValue = '0'; let deltaLabel = 'No change vs previous period'; let deltaValue: number | null = 0; let deltaUnit: AnalyticsReport['deltaUnit'] = 'count';
  let columns: AnalyticsReport['columns'] = []; let rows: AnalyticsReportRow[] = []; let bars: AnalyticsReportBar[] = [];

  if (query.type === 'student-strength') {
    const activeEnrollments = enrollments.filter((enrollment) => studentsById.get(enrollment.studentId)?.status === 'active');
    const studentIds = new Set(activeEnrollments.map((e) => e.studentId));
    const newCurrent = activeEnrollments.filter((e) => e.joinedOn >= r.from && e.joinedOn <= r.to).length;
    const newPrior = activeEnrollments.filter((e) => e.joinedOn >= priorFrom && e.joinedOn < r.from).length;
    headlineLabel = 'Active students'; headlineValue = studentIds.size.toLocaleString('en-IN'); deltaValue = newCurrent - newPrior; deltaLabel = `${deltaValue >= 0 ? '+' : ''}${deltaValue} new enrolments vs previous period`;
    columns = [{ key: 'students', title: 'Students', align: 'right' }, { key: 'capacity', title: 'Capacity', align: 'right' }];
    rows = batches.filter((b) => b.status === 'active').map<AnalyticsReportRow>((batch) => {
      const count = activeEnrollments.filter((e) => e.batchId === batch.id).length;
      return { id: batch.id, label: batch.name, detail: `${batch.grade ? `Class ${batch.grade} · ` : ''}${batch.academicYear}`, values: [count, batch.capacity ?? '—'], status: 'neutral' };
    });
    const values = new Map<string, number>();
    for (const enrollment of activeEnrollments) { const key = query.period === 'term' ? enrollment.joinedOn.slice(0, 7) : enrollment.joinedOn; values.set(key, (values.get(key) ?? 0) + 1); }
    bars = makeBars(r.from, r.to, r.days, values, query.period === 'term');
  } else if (query.type === 'fee-collection') {
    const cancelledFees = new Set(db.studentFees.all(instituteId).filter((fee) => fee.status === 'cancelled').map((fee) => fee.id));
    const installments = db.installments.all(instituteId).filter((inst) => inst.status !== 'waived' && !cancelledFees.has(inst.studentFeeId) && batchMatches(enrolledByStudent.get(inst.studentId)?.[0] ?? ''));
    const useTermLedger = query.period === 'term';
    const selected = installments.filter((inst) => useTermLedger || (inst.paidOn && inst.paidOn >= r.from && inst.paidOn <= r.to));
    const collected = round2(sum(selected.map((inst) => inst.paidAmount)));
    const prior = round2(sum(installments.filter((inst) => inst.paidOn && inst.paidOn >= priorFrom && inst.paidOn < r.from).map((inst) => inst.paidAmount)));
    headlineLabel = 'Fees collected'; headlineValue = currency(collected); deltaValue = round2(collected - prior); deltaUnit = 'currency'; deltaLabel = `${deltaValue >= 0 ? '+' : '−'}${currency(Math.abs(deltaValue))} vs previous period`;
    columns = [{ key: 'collected', title: 'Collected', align: 'right' }, { key: 'outstanding', title: 'Outstanding', align: 'right' }];
    rows = [...new Set(selected.map((inst) => inst.studentId))].map<AnalyticsReportRow>((studentId) => {
      const student = studentsById.get(studentId); const mine = selected.filter((inst) => inst.studentId === studentId);
      const paid = round2(sum(mine.map((inst) => inst.paidAmount))); const due = round2(sum(mine.map((inst) => Math.max(0, inst.amount - inst.paidAmount))));
      const batchName = batchById.get(enrolledByStudent.get(studentId)?.[0] ?? '')?.name ?? '—';
      return { id: studentId, label: student?.fullName ?? 'Student', detail: batchName, values: [paid * 100, due * 100], status: due > 0 ? 'bad' : 'good' };
    }).filter((row) => Number(row.values[0]) > 0).sort((a, b) => Number(b.values[0]) - Number(a.values[0]));
    const byMonth = new Map<string, number>();
    for (const inst of selected) if (inst.paidOn) { const key = query.period === 'term' ? inst.paidOn.slice(0, 7) : inst.paidOn; byMonth.set(key, (byMonth.get(key) ?? 0) + inst.paidAmount); }
    bars = makeBars(r.from, r.to, r.days, byMonth, query.period === 'term').map((bar) => ({ ...bar, value: bar.value * 100 }));
  } else if (query.type === 'attendance') {
    const sessions = db.attendanceSessions.all(instituteId).filter((session) => session.status !== 'open' && session.date >= r.from && session.date <= r.to && batchMatches(session.batchId));
    const sessionIds = new Set(sessions.map((session) => session.id));
    const records = db.attendanceRecords.all(instituteId).filter((record) => sessionIds.has(record.sessionId));
    const attended = records.filter((record) => record.status === 'present' || record.status === 'late').length;
    const pct = safePercent(attended, records.length);
    headlineLabel = 'Attendance marked'; headlineValue = records.length ? `${pct.toFixed(1)}%` : '—'; deltaValue = null; deltaUnit = 'points'; deltaLabel = records.length ? `${attended.toLocaleString('en-IN')} present or late out of ${records.length.toLocaleString('en-IN')} marks` : 'No attendance records in this period';
    columns = [{ key: 'attendance', title: 'Attendance', align: 'right' }, { key: 'classes', title: 'Classes', align: 'right' }];
    const byStudent = new Map<ID, { attended: number; total: number; absences: number }>();
    for (const record of records) { const value = byStudent.get(record.studentId) ?? { attended: 0, total: 0, absences: 0 }; value.total++; if (record.status === 'present' || record.status === 'late') value.attended++; if (record.status === 'absent') value.absences++; byStudent.set(record.studentId, value); }
    rows = [...byStudent].map<AnalyticsReportRow>(([studentId, value]) => ({ id: studentId, label: studentsById.get(studentId)?.fullName ?? 'Student', detail: enrolledByStudent.get(studentId)?.map((id) => batchById.get(id)?.name).filter(Boolean).join(', ') ?? '—', values: [safePercent(value.attended, value.total), value.total], status: value.absences ? 'bad' : 'good' })).sort((a, b) => Number(a.values[0]) - Number(b.values[0]));
    const daily = new Map<string, number>();
    for (const session of sessions) { const sessionRecords = records.filter((record) => record.sessionId === session.id); const dayAttendance = safePercent(sessionRecords.filter((record) => record.status === 'present' || record.status === 'late').length, sessionRecords.length); daily.set(session.date, dayAttendance); }
    bars = makeBars(r.from, r.to, r.days, daily);
  } else if (query.type === 'academic-performance') {
    const exams = db.exams.all(instituteId).filter((exam) => exam.status === 'published' && exam.startsOn && exam.startsOn >= r.from && exam.startsOn <= r.to && batchMatches(exam.batchId));
    const examIds = new Set(exams.map((exam) => exam.id)); const marks = db.marks.all(instituteId).filter((mark) => examIds.has(mark.examId) && mark.marksObtained !== null && !mark.isAbsent);
    const percentages = marks.map((mark) => mark.maxMarks ? (Number(mark.marksObtained) / mark.maxMarks) * 100 : 0);
    const average = percentages.length ? round1(sum(percentages) / percentages.length) : null;
    headlineLabel = 'Average score'; headlineValue = average === null ? '—' : `${average.toFixed(1)}%`; deltaValue = null; deltaUnit = 'points'; deltaLabel = `${percentages.length.toLocaleString('en-IN')} published scores in this period`;
    columns = [{ key: 'average', title: 'Average', align: 'right' }, { key: 'tests', title: 'Scores', align: 'right' }];
    rows = [...new Set(marks.map((mark) => mark.studentId))].map<AnalyticsReportRow>((studentId) => { const values = marks.filter((mark) => mark.studentId === studentId); const avg = round1(sum(values.map((m) => (Number(m.marksObtained) / m.maxMarks) * 100)) / values.length); return { id: studentId, label: studentsById.get(studentId)?.fullName ?? 'Student', detail: `${values.length} published ${values.length === 1 ? 'score' : 'scores'}`, values: [avg, values.length], status: avg >= 75 ? 'good' : avg < 50 ? 'bad' : 'neutral' }; }).sort((a, b) => Number(b.values[0]) - Number(a.values[0]));
    const byMonth = new Map<string, number>(); for (const exam of exams) { const all = marks.filter((mark) => mark.examId === exam.id); const score = all.length ? sum(all.map((mark) => (Number(mark.marksObtained) / mark.maxMarks) * 100)) / all.length : 0; const key = query.period === 'term' ? exam.startsOn!.slice(0, 7) : exam.startsOn!; byMonth.set(key, (byMonth.get(key) ?? 0) + score); }
    const averageByPeriod = new Map([...byMonth].map(([key, value]) => [key, value / Math.max(1, exams.filter((exam) => (query.period === 'term' ? exam.startsOn?.slice(0, 7) : exam.startsOn) === key).length)]));
    bars = makeBars(r.from, r.to, r.days, averageByPeriod, query.period === 'term');
  } else if (query.type === 'teacher-performance') {
    const teachers = db.teachers.all(instituteId).filter((teacher) => teacher.status === 'active');
    const scopedBatches = new Set(batches.map((batch) => batch.id));
    const sessions = db.attendanceSessions.all(instituteId).filter((session) => session.status !== 'open' && session.date >= r.from && session.date <= r.to && scopedBatches.has(session.batchId));
    const records = db.attendanceRecords.all(instituteId); const exams = db.exams.all(instituteId).filter((exam) => exam.status === 'published' && exam.startsOn && exam.startsOn >= r.from && exam.startsOn <= r.to && scopedBatches.has(exam.batchId)); const marks = db.marks.all(instituteId);
    const metrics = teachers.map((teacher) => { const assigned = new Set(batches.filter((batch) => batch.teacherId === teacher.id).map((batch) => batch.id)); const mineSessions = sessions.filter((session) => assigned.has(session.batchId)); const mineRecords = records.filter((record) => mineSessions.some((session) => session.id === record.sessionId)); const pct = safePercent(mineRecords.filter((record) => record.status === 'present' || record.status === 'late').length, mineRecords.length); const mineExamIds = new Set(exams.filter((exam) => assigned.has(exam.batchId)).map((exam) => exam.id)); const mineMarks = marks.filter((mark) => mineExamIds.has(mark.examId) && mark.marksObtained !== null && !mark.isAbsent); const avg = mineMarks.length ? round1(sum(mineMarks.map((mark) => (Number(mark.marksObtained) / mark.maxMarks) * 100)) / mineMarks.length) : null; return { teacher, assigned, pct, classes: mineSessions.length, avg }; });
    const marked = metrics.filter((metric) => metric.pct > 0); const overall = marked.length ? round1(sum(marked.map((metric) => metric.pct)) / marked.length) : null;
    headlineLabel = 'Average attendance'; headlineValue = overall === null ? '—' : `${overall.toFixed(1)}%`; deltaValue = null; deltaUnit = 'points'; deltaLabel = `${teachers.length} active teachers across ${batches.length} batches`;
    columns = [{ key: 'attendance', title: 'Attendance', align: 'right' }, { key: 'average', title: 'Average', align: 'right' }, { key: 'classes', title: 'Classes', align: 'right' }];
    rows = metrics.map(({ teacher, assigned, pct, classes, avg }) => ({ id: teacher.id, label: teacher.fullName, detail: [...assigned].map((id) => batchById.get(id)?.name).filter(Boolean).join(', ') || 'No assigned batch', values: [pct || '—', avg ?? '—', classes], status: pct >= 85 ? 'good' : pct ? 'bad' : 'neutral' }));
    bars = metrics.map(({ teacher, pct }) => ({ label: teacher.fullName.split(' ')[0], value: pct }));
  } else {
    const leads = db.leads.all(instituteId).filter((lead) => lead.createdAt.slice(0, 10) >= r.from && lead.createdAt.slice(0, 10) <= r.to);
    const stages = ['new', 'contacted', 'interested', 'demo_scheduled', 'demo_attended', 'negotiation', 'enrolled', 'lost'];
    headlineLabel = 'New enquiries'; headlineValue = leads.filter((lead) => lead.createdAt.slice(0, 10) >= r.from && lead.createdAt.slice(0, 10) <= r.to).length.toLocaleString('en-IN');
    const currentConversions = leads.filter((lead) => lead.stage === 'enrolled' && lead.updatedAt.slice(0, 10) >= r.from && lead.updatedAt.slice(0, 10) <= r.to).length;
    const prevConversions = leads.filter((lead) => lead.stage === 'enrolled' && lead.updatedAt.slice(0, 10) >= priorFrom && lead.updatedAt.slice(0, 10) < r.from).length;
    deltaValue = currentConversions - prevConversions; deltaLabel = `${currentConversions} converted · ${deltaValue >= 0 ? '+' : ''}${deltaValue} vs previous period`;
    columns = [{ key: 'leads', title: 'Leads', align: 'right' }, { key: 'share', title: 'Share', align: 'right' }];
    rows = stages.map((stage) => { const matching = leads.filter((lead) => lead.stage === stage); return { id: stage, label: stage.replaceAll('_', ' ').replace(/\b\w/g, (char) => char.toUpperCase()), detail: stage === 'enrolled' ? 'Enrolled' : stage === 'lost' ? 'Closed lost' : 'In progress', values: [matching.length, leads.length ? round1(matching.length * 100 / leads.length) : 0], status: stage === 'lost' ? 'bad' : stage === 'enrolled' ? 'good' : 'neutral' }; });
    bars = rows.map((row) => ({ label: row.label.slice(0, 5), value: Number(row.values[0]) }));
  }
  const periodLabel = r.label;
  return { type: query.type, title: title[query.type], periodLabel, from: r.from as ISODate, to: r.to as ISODate, headlineLabel, headlineValue, deltaLabel, deltaValue, deltaUnit, columns, bars, rows };
}
