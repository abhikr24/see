import type { ID, LeadStage, TrendPoint } from '../../core/contracts/models';
import { buildMemoryReport } from './analytics-reports';
import type {
  AnalyticsRepo,
  StoragePort,
} from '../../core/contracts/ports';
import { attendanceRecords, summarize } from './academics';
import { admissionsLeadRepo } from './admissions';
import { ownerDashboard } from './dashboard';
import { studentHome } from './student-home';
import { childSummary } from './parent';
import { teacherHome } from './teacher';
import { type Db } from './db';
import * as D from './defaults';
import { addDays, fail, merge, round1, round2, sum, todayIso } from './store';

const STAGES: LeadStage[] = [
  'new',
  'contacted',
  'interested',
  'demo_scheduled',
  'demo_attended',
  'negotiation',
  'enrolled',
  'lost',
];

export const leadRepo = admissionsLeadRepo;

export function analyticsRepo(db: Db): AnalyticsRepo {
  return {
    overview: async (instituteId) => {
      db.institutes.get(instituteId, instituteId);
      const today = todayIso();
      const recent = summarize(attendanceRecords(db, instituteId, { from: addDays(today, -30), to: today }));
      const installments = db.installments.all(instituteId).filter((x) => x.status !== 'waived');
      const collected = sum(installments.map((x) => x.paidAmount));
      return {
        activeStudents: db.students.all(instituteId, { status: 'active' }).length,
        activeTeachers: db.teachers.all(instituteId, { status: 'active' }).length,
        activeBatches: db.batches.all(instituteId, { status: 'active' }).length,
        pendingMembers: db.memberships.all(instituteId, { status: 'pending' }).length,
        attendancePercent: recent.total ? recent.percent : null,
        feesCollected: round2(collected),
        feesOutstanding: round2(sum(installments.map((x) => x.amount)) - collected),
        openLeads: db.leads.all(instituteId).filter((l) => l.stage !== 'enrolled' && l.stage !== 'lost').length,
        openAlerts: db.alerts.all(instituteId, { status: 'open' }).length,
      };
    },
    dashboard: (instituteId) => ownerDashboard(db, instituteId),
    teacherHome: async (instituteId) => teacherHome(db, instituteId),
    studentHome: async (instituteId) => studentHome(db, instituteId),
    childSummary: async (instituteId) => childSummary(db, instituteId),
    attendanceTrend: async (instituteId, { from, to }) => {
      if (to < from) fail('VALIDATION', 'The range ends before it starts');
      const sessions = db.attendanceSessions.all(instituteId).filter((s) => s.date >= from && s.date <= to);
      return [...new Set(sessions.map((s) => s.date))].sort().map((date): TrendPoint => {
        const ids = sessions.filter((s) => s.date === date).map((s) => s.id);
        const records = db.attendanceRecords.all(instituteId).filter((r) => ids.includes(r.sessionId));
        const attended = records.filter((r) => r.status === 'present' || r.status === 'late').length;
        return { date, value: records.length ? round1((attended / records.length) * 100) : 0 };
      });
    },
    report: (instituteId, query) => buildMemoryReport(db, instituteId, query),
    feeCollection: async (instituteId, { from, to }) => {
      if (to < from) fail('VALIDATION', 'The range ends before it starts');
      const byDay = new Map<string, number>();
      for (const payment of db.payments.all(instituteId, { status: 'completed' })) {
        const date = payment.paidAt.slice(0, 10);
        if (date >= from && date <= to) byDay.set(date, round2((byDay.get(date) ?? 0) + payment.amount));
      }
      return [...byDay].sort(([a], [b]) => a.localeCompare(b)).map(([date, value]) => ({ date, value }));
    },
    leadFunnel: async (instituteId) => {
      const leads = db.leads.all(instituteId);
      return STAGES.map((stage) => ({ stage, count: leads.filter((l) => l.stage === stage).length }));
    },
    listAuditLogs: async (instituteId, query) =>
      db.auditLogs.page(instituteId, { sort: { field: 'createdAt', direction: 'desc' }, ...query }),
    recordAudit: async (instituteId, input) => {
      const actorId = db.session.userId;
      const actorRole = actorId ? (db.memberships.find(instituteId, { userId: actorId })?.role ?? null) : null;
      return db.auditLogs.insert(instituteId, merge({ ...D.auditLog(), actorId, actorRole }, input));
    },
  };
}

export { exportRepo } from './exports';
export { subscriptionRepo } from './billing';

/** Records the attachment but keeps no bytes; URLs use a `memory://` scheme that opens nothing. */
export function storagePort(db: Db): StoragePort {
  return {
    upload: async (instituteId, input) => {
      const { ownerType, ownerId, fileName, uri } = input;
      if (!fileName.trim() || !uri) fail('VALIDATION', 'A file is required');
      return db.attachments.insert(instituteId, {
        ownerType,
        ownerId,
        fileName,
        storagePath: `${instituteId}/${ownerType}/${ownerId}/${fileName}`,
        mimeType: input.mimeType ?? null,
        sizeBytes: input.sizeBytes ?? null,
        batchId: input.batchId ?? null,
        studentId: input.studentId ?? null,
        uploadedBy: db.session.userId,
      });
    },
    listAttachments: async (instituteId, ownerType, ownerId) =>
      db.attachments.all(instituteId, { ownerType, ownerId }),
    getUrl: async (instituteId, storagePath) => {
      if (/^(https?:|data:|blob:)/.test(storagePath)) return storagePath;
      if (!storagePath.startsWith(`${instituteId}/`)) fail('NOT_FOUND', 'File not found');
      return `memory://${storagePath}`;
    },
    remove: async (instituteId, attachmentId) => db.attachments.remove(instituteId, attachmentId),
  };
}
