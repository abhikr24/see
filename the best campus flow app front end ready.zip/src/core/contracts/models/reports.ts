import type { ID, ISODate } from './common';

export type AnalyticsReportType =
  | 'student-strength'
  | 'fee-collection'
  | 'attendance'
  | 'academic-performance'
  | 'teacher-performance'
  | 'admissions-funnel';
export type AnalyticsReportPeriod = 'week' | 'month' | 'term';

export interface AnalyticsReportQuery {
  type: AnalyticsReportType;
  period: AnalyticsReportPeriod;
  batchId?: ID | null;
}

export interface AnalyticsReportColumn {
  key: string;
  title: string;
  align: 'left' | 'right';
}

export interface AnalyticsReportBar {
  label: string;
  value: number;
}

export interface AnalyticsReportRow {
  id: ID | string;
  label: string;
  detail: string;
  values: Array<string | number>;
  status: 'good' | 'bad' | 'neutral';
}

/** Fully aggregated report; screens never query or calculate business totals. */
export interface AnalyticsReport {
  type: AnalyticsReportType;
  title: string;
  periodLabel: string;
  from: ISODate;
  to: ISODate;
  headlineLabel: string;
  headlineValue: string;
  deltaLabel: string;
  deltaValue: number | null;
  deltaUnit: 'count' | 'currency' | 'points' | 'percent';
  columns: AnalyticsReportColumn[];
  bars: AnalyticsReportBar[];
  rows: AnalyticsReportRow[];
}
