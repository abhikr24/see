import { useCallback, useState } from 'react';
import { useRouter } from 'expo-router';
import { useBackend } from '@/core/backend';
import type { OtpChallenge } from '@/core/contracts/models';
import type { Credentials } from '@/core/contracts/ports';
import { queryCache } from '@/core/hooks/cache';
import { resolveAuthenticatedDestination } from '@/store/session';

/**
 * Who is signed in changes what every query returns — the dashboard, the
 * roster, the unread badge. So signing in or out drops the backend's whole
 * cache: mounted queries reload for the new person, everything else is
 * forgotten, and nobody ever sees the previous person's numbers.
 */
export function authCacheScopes(backendName: string): string[] {
  return [`${backendName}|`];
}

/** Reload mounted queries and forget the rest. Existing helper — no new cache. */
export function invalidateAuthCaches(backendName: string): Promise<void> {
  return queryCache.invalidate(authCacheScopes(backendName));
}

export function useAuth() {
  const { backend } = useBackend();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [fieldError, setFieldError] = useState<string | null>(null);

  const afterAuth = useCallback(async () => {
    await invalidateAuthCaches(backend.name);
    const href = await resolveAuthenticatedDestination(backend, null);
    router.replace(href as never);
  }, [backend, router]);

  const requestOtp = useCallback(
    async (identifier: string, password: string): Promise<OtpChallenge | null> => {
      if (!identifier.trim()) {
        setFieldError('Enter your mobile or email');
        return null;
      }
      if (!password) {
        setFieldError('Enter your password');
        return null;
      }
      setLoading(true);
      setFieldError(null);
      try {
        return await backend.auth.requestOtp(null, { email: identifier.trim(), password });
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Wrong email or password';
        setFieldError(msg.includes('Wrong') ? msg : 'Wrong email or password');
        return null;
      } finally {
        setLoading(false);
      }
    },
    [backend],
  );

  const signIn = useCallback(
    async (credentials: Credentials) => {
      setLoading(true);
      setFieldError(null);
      try {
        await backend.auth.signIn(null, credentials);
        await afterAuth();
        return true;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Wrong email or password';
        setFieldError(msg.includes('Wrong') ? msg : 'Wrong email or password');
        return false;
      } finally {
        setLoading(false);
      }
    },
    [afterAuth, backend],
  );

  const signUp = useCallback(
    async (input: Credentials & { fullName: string }) => {
      setLoading(true);
      setFieldError(null);
      try {
        await backend.auth.signUp(null, input);
        await afterAuth();
        return true;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Could not create the account';
        setFieldError(msg);
        return false;
      } finally {
        setLoading(false);
      }
    },
    [afterAuth, backend],
  );

  const signInWithGoogle = useCallback(async () => {
    setLoading(true);
    setFieldError(null);
    try {
      await backend.auth.signInWithGoogle(null);
      await afterAuth();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Google sign-in failed';
      setFieldError(msg);
    } finally {
      setLoading(false);
    }
  }, [afterAuth, backend]);

  const signOut = useCallback(async () => {
    setLoading(true);
    setFieldError(null);
    try {
      await backend.auth.signOut(null);
      await invalidateAuthCaches(backend.name);
      router.replace('/(auth)/login' as never);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Could not sign out';
      setFieldError(msg);
    } finally {
      setLoading(false);
    }
  }, [backend, router]);

  return { requestOtp, signIn, signUp, signInWithGoogle, signOut, loading, fieldError, setFieldError };
}

export function useOtp(challengeId: string) {
  const { backend } = useBackend();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resendIn, setResendIn] = useState(30);

  const verify = useCallback(
    async (code: string) => {
      if (code.length !== 6) {
        setError('Enter the 6-digit code');
        return false;
      }
      setLoading(true);
      setError(null);
      try {
        await backend.auth.verifyOtp(null, { challengeId, code });
        // Drop the signed-out snapshot before the screen navigates, so the
        // resolver reads a live session instead of an empty institute list.
        await invalidateAuthCaches(backend.name);
        return true;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Wrong code — try again';
        const friendly = msg.includes('expired') ? 'Code expired — request a new one' : 'Wrong code — try again';
        setError(friendly);
        return false;
      } finally {
        setLoading(false);
      }
    },
    [backend, challengeId],
  );

  const resend = useCallback(async (): Promise<string | null> => {
    try {
      const c = await backend.auth.resendOtp(null, challengeId);
      setResendIn(30);
      setError(null);
      return c.challengeId;
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Could not resend';
      setError(msg);
      return null;
    }
  }, [backend, challengeId]);

  return { verify, resend, loading, error, setError, resendIn, setResendIn };
}
