import React from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R, S } from '@/lib/theme';
import { Text } from '@/components/ui';

interface Props {
  value: string;
  onChange: (v: string) => void;
  onSubmit?: () => void;
  onCancel: () => void;
  autoFocus?: boolean;
}

export function SearchField({ value, onChange, onSubmit, onCancel, autoFocus }: Props) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 16, paddingTop: 10, paddingBottom: 12 }}>
      <View
        style={{
          flex: 1,
          height: 44,
          borderRadius: R.field,
          backgroundColor: C.surface,
          borderWidth: 1,
          borderColor: C.hairline,
          paddingHorizontal: 12,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <Ionicons name="search-outline" size={18} color={C.muted} />
        <TextInput
          value={value}
          onChangeText={onChange}
          onSubmitEditing={onSubmit}
          placeholder="Search students, batches, materials…"
          placeholderTextColor={C.muted}
          returnKeyType="search"
          autoFocus={autoFocus}
          autoCorrect={false}
          autoCapitalize="none"
          clearButtonMode="never"
          accessibilityLabel="Search field"
          style={{ flex: 1, fontSize: 15, color: C.ink, paddingVertical: 0 }}
        />
        {value.length > 0 ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Clear search"
            onPress={() => onChange('')}
            hitSlop={10}
            style={({ pressed }) => ({
              width: 24,
              height: 24,
              borderRadius: 12,
              backgroundColor: C.track,
              alignItems: 'center',
              justifyContent: 'center',
              opacity: pressed ? 0.7 : 1,
            })}
          >
            <Ionicons name="close" size={14} color={C.secondary} />
          </Pressable>
        ) : null}
      </View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Cancel search"
        onPress={onCancel}
        hitSlop={10}
        style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1, paddingHorizontal: 2 })}
      >
        <Text variant="body" weight={600} c={C.primary}>
          Cancel
        </Text>
      </Pressable>
    </View>
  );
}
