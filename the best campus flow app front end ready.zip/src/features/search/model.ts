import type { Batch, Material, Student } from '@/core/contracts/models';

export type SearchGroupKey = 'students' | 'batches' | 'materials';

export interface StudentHit {
  id: string;
  title: string;
  subtitle: string;
  photoUrl?: string | null;
  raw: Student;
}

export interface BatchHit {
  id: string;
  title: string;
  subtitle: string;
  raw: Batch;
}

export interface MaterialHit {
  id: string;
  title: string;
  subtitle: string;
  raw: Material;
}

export interface SearchResults {
  students: StudentHit[];
  batches: BatchHit[];
  materials: MaterialHit[];
  total: number;
}

export function emptyResults(): SearchResults {
  return { students: [], batches: [], materials: [], total: 0 };
}

export function includesHaystack(haystack: string, needle: string): boolean {
  return haystack.toLowerCase().includes(needle.toLowerCase());
}

export function highlightParts(text: string, query: string): { text: string; match: boolean }[] {
  if (!query) return [{ text, match: false }];
  const lower = text.toLowerCase();
  const q = query.toLowerCase();
  const idx = lower.indexOf(q);
  if (idx === -1) return [{ text, match: false }];
  const parts: { text: string; match: boolean }[] = [];
  if (idx > 0) parts.push({ text: text.slice(0, idx), match: false });
  parts.push({ text: text.slice(idx, idx + q.length), match: true });
  if (idx + q.length < text.length) parts.push({ text: text.slice(idx + q.length), match: false });
  return parts;
}
