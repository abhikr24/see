import { useCallback, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useBackend } from '@/core/hooks/context';
import { type SearchResults, emptyResults, includesHaystack } from './model';

const RECENT_KEY = 'gf.search.recent.v1';
const MAX_RECENT = 8;

export function useDebounced<T>(value: T, ms: number): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setV(value), ms);
    return () => clearTimeout(id);
  }, [value, ms]);
  return v;
}

export function useRecentSearches() {
  const [recent, setRecent] = useState<string[]>([]);
  useEffect(() => {
    void AsyncStorage.getItem(RECENT_KEY).then((raw) => {
      try {
        const parsed = raw ? (JSON.parse(raw) as string[]) : [];
        if (Array.isArray(parsed)) setRecent(parsed.slice(0, MAX_RECENT));
      } catch {}
    });
  }, []);
  const push = useCallback(async (term: string) => {
    const clean = term.trim();
    if (!clean) return;
    setRecent((prev) => {
      const next = [clean, ...prev.filter((x) => x.toLowerCase() !== clean.toLowerCase())].slice(0, MAX_RECENT);
      void AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch(() => undefined);
      return next;
    });
  }, []);
  const clear = useCallback(async () => {
    setRecent([]);
    await AsyncStorage.removeItem(RECENT_KEY).catch(() => undefined);
  }, []);
  const remove = useCallback(async (term: string) => {
    setRecent((prev) => {
      const next = prev.filter((x) => x !== term);
      void AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch(() => undefined);
      return next;
    });
  }, []);
  return { recent, push, clear, remove };
}

export function useSearch(query: string) {
  const { backend, instituteId } = useBackend();
  const debounced = useDebounced(query.trim(), 250);
  const [results, setResults] = useState<SearchResults>(emptyResults());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async () => {
    if (!instituteId || !debounced) {
      setResults(emptyResults());
      setLoading(false);
      setError(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const needle = debounced.toLowerCase();
      const [studentsPage, batchesPage, materialsPage] = await Promise.all([
        backend.students.list(instituteId, { limit: 200 } as never).catch(() => ({ items: [] as never[], total: 0 } as never)),
        backend.batches.list(instituteId, { limit: 100 } as never).catch(() => ({ items: [] as never[], total: 0 } as never)),
        backend.materials.list(instituteId, { limit: 100 } as never).catch(() => ({ items: [] as never[], total: 0 } as never)),
      ]);
      const students = (studentsPage as { items: { id: string; fullName: string; admissionNo?: string|null; classGrade?: string }[] }).items
        .filter((s) => includesHaystack(s.fullName, needle) || (s.admissionNo ? includesHaystack(s.admissionNo, needle) : false))
        .slice(0, 8)
        .map((s) => ({
          id: s.id,
          title: s.fullName,
          subtitle: `Roll ${s.admissionNo ?? ''} · Class ${s.classGrade ?? ''}`.trim(),
          raw: s as unknown as SearchResults['students'][number]['raw'],
        }));
      const batches = (batchesPage as { items: { id: string; name: string; grade?: string }[] }).items
        .filter((b) => includesHaystack(b.name, needle) || (b.grade ? includesHaystack(b.grade, needle) : false))
        .slice(0, 6)
        .map((b) => ({
          id: b.id,
          title: b.name,
          subtitle: b.grade ? `Grade ${b.grade}` : 'Batch',
          raw: b as unknown as SearchResults['batches'][number]['raw'],
        }));
      const materials = (materialsPage as { items: { id: string; title: string; kind?: string }[] }).items
        .filter((m) => includesHaystack(m.title, needle))
        .slice(0, 8)
        .map((m) => ({
          id: m.id,
          title: m.title,
          subtitle: m.kind ? m.kind : 'Material',
          raw: m as unknown as SearchResults['materials'][number]['raw'],
        }));
      setResults({ students, batches, materials, total: students.length + batches.length + materials.length });
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Could not search');
      setResults(emptyResults());
    } finally {
      setLoading(false);
    }
  }, [backend, instituteId, debounced]);

  useEffect(() => {
    void search();
  }, [search]);

  const refresh = useCallback(() => {
    void search();
  }, [search]);

  return { query: debounced, results, loading, error, refresh };
}
