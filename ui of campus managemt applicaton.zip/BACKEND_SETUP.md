# GuruFlow — Backend integration guide

The prototype runs entirely on a **Demo adapter** (in-memory, shared by all four roles). Nothing needs credentials.

```
UI screens (src/screens)
   ↓
Use-case layer (src/features/usecases.ts)      ← permission checks + cross-role effects (notifications, activity)
   ↓
GuruRepository interface (src/data/repository.ts)
   ↓
Provider factory (src/data/factory.ts)         ← NEXT_PUBLIC_GURUFLOW_BACKEND = demo | supabase | custom
   ↓
DemoAdapter  |  SupabaseAdapter (stub)  |  CustomAdapter (to be written)
```

Rules that already hold in the code:

- Screens never import a backend SDK; they call `uc.*` use-cases and read the snapshot through `useDB()` / `useScope()`.
- Demo data lives in `src/data/seed.ts`, separate from screens.
- Role checks in the UI (`can()`, hidden buttons, `Denied` states) are **convenience only**. Production security must be enforced by the backend.

## Implementing a real adapter

1. Implement `GuruRepository` (`getSnapshot`, `subscribe`, `upsert`, `remove`, `setAttendance`, `setMarks`, `setPermissions`, `reset`). Keep the snapshot/subscribe contract so the UI re-renders when data changes (use realtime subscriptions or polling).
2. Register it in `src/data/factory.ts` and set `NEXT_PUBLIC_GURUFLOW_BACKEND`.
3. Replace the `DemoAdapter` notification/activity side-effects in `usecases.ts` with server-side triggers or edge functions where appropriate.

## Suggested Supabase layout

| Domain collection | Table | RLS rule of thumb |
|---|---|---|
| institutes, memberships | `institutes`, `memberships (user_id, institute_id, role[])` | user sees only institutes they belong to |
| students, guardians | `students`, `guardians (verified, consent)` | owner: all; teacher: batches they teach; student: self; parent: **only verified + consented** links |
| attendance | `attendance (date, student_id, status)` + `attendance_log` | teacher write for assigned batches; parent read for linked children |
| homework, submissions | `homework`, `submissions` | student writes own; teacher reviews assigned batches |
| exams, marks | `exams`, `marks` | results visible to students/parents only when `status = 'published'` |
| fees, payments | `fee_structures`, `fee_accounts`, `payments` | owner/permitted staff only; parent read own child |
| notices, notifications | `notices`, `notifications` | filtered by audience / role |

## Things that must stay server-side

- **Never** ship the Supabase **service-role key**, payment-gateway secrets, SMS/OTP provider keys or webhook secrets in the client. Only the public anon key and URL may be exposed.
- **OTP / SMS / email**: use a provider from a server function. The demo code `123456` exists only in demo mode.
- **Payments**: create orders and verify webhooks on the server with a trusted provider; the app should only display the result. Demo payments are labelled `DEMO` everywhere and never simulate UPI/bank transfers.
- **File uploads**: use signed upload URLs to private storage; today's file pickers only keep metadata on the device.
- **Data export / account closure**: implement as audited server jobs; the UI currently records a demo request only.

## Environment

See `.env.example`. Only `NEXT_PUBLIC_*` variables are visible to the client bundle.
