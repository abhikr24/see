# GuruFlow — premium institute management & learning app (interactive prototype)

India-first app for **Owners / Admins, Teachers, Students and Parents**, with 82 screens (S01–S82), a shared demo data store, role-aware navigation and a backend-ready architecture.

> **Important — platform note.** This workspace can only build and preview a **Next.js (App Router) + Tailwind** project. It cannot run Expo / React Native. GuruFlow is therefore delivered as a **mobile-first web app that behaves like a native Android app**: its own stack navigator, role-specific bottom tabs, bottom sheets, dialogs, toasts, an Android-style back-button handler (browser/hardware back via `popstate`), unsaved-changes guard, safe-area padding and 44 px+ touch targets. On desktop a phone frame is drawn around it purely for preview; on a phone it fills the screen. It is **not** a React Native build and has not been tested on a device. The data/use-case/repository layering is framework-independent and can be reused in an Expo app.

## Run

```bash
npm install
npm run dev            # http://localhost:3000
# production
npm run build && npm run start
```

Demo sign-in: any valid mobile/email + a 6+ character password (e.g. `9876543210` / `guruflow`). Demo OTP / recovery code: **123456** (no SMS or email is ever sent). Pick *Aarohan Learning Institute* and then a role (the demo account holds all four roles there; *Saraswati Science Academy* has a teacher role; *Gyan Setu Tutorials* is a pending request).

Quick access: on desktop use the side panel (role buttons, **All 82 screens**, **Reset data**); on mobile open **More → All screens**.

## Validation commands

```bash
npx next typegen && npx tsc --noEmit && npm run build   # type generation, TypeScript, production build
npx eslint src                                          # lint
npx --yes tsx scripts/smoke-render.tsx                  # server-renders all screens with the correct role
npm i --no-save jsdom && npx --yes tsx scripts/e2e-jsdom.tsx   # scripted interaction test (jsdom)
```

## Structure

```
src/domain/types.ts        entities and permission types
src/data/                  repository interface, DemoAdapter, Supabase stub, factory, seed, questions
src/features/              selectors (permissions, attendance, fees…) and use-cases (cross-role effects)
src/state/app.tsx          navigator, session/role/institute, toasts, confirm, offline, shared-store hooks
src/ui/                    design system: kit, forms, charts, cards
src/shell/                 phone-frame shell, bottom navigation, tab config
src/screens/               shared-auth, shared-core, owner-a/b, teacher, student, parent, registry
docs/                      SCREENS.md, PERMISSIONS.md, TESTING.md
BACKEND_SETUP.md           how to plug in Supabase / a custom backend
```

## Cross-role consistency (one shared store)

Teacher marks absent → owner attendance reports, student calendar and verified-parent calendar change, and the parent gets a notification. Student submits homework → teacher review queue and notification. Owner publishes results → student and parent results update. Owner publishes a notice to a batch → only matching teachers/students/parents see it. Owner records a **DEMO** payment → ledger and parent fees stay in sync. Parent leave/meeting requests appear in owner/teacher views. Owner revokes a guardian → the parent loses access to that child immediately.

## Known limitations

See `docs/TESTING.md` for the tested list and honest limitations (demo-only OTP, payments, uploads, exports; web-based rather than React Native; visual QA on real Android devices not performed).
