# GuruFlow — Permission matrix

> These checks drive **UI behaviour only** in this prototype (`can()` in `src/features/selectors.ts`, hidden actions, `Denied` states, and guards inside use-cases). Real security must be enforced by backend authorisation and database policies (RLS).

| Capability | Owner / Admin | Teacher | Student | Parent / Guardian |
|---|---|---|---|---|
| Institute dashboard, admissions, staff, sessions, batches | ✅ | ❌ | ❌ | ❌ |
| Student records | All students | **Only students in batches they teach** (others → permission-denied state) | Own record only | **Only verified, consented, linked children** |
| Mark / correct attendance | ✅ (`attendance.edit`) | ✅ if `attendance.edit` (corrections need a reason and are logged) | ❌ | ❌ (read-only for own child) |
| Create homework | ✅ | ✅ own batches/subjects | ❌ | ❌ |
| Submit homework | ❌ | ❌ | ✅ own | ❌ |
| Review homework | ✅ | ✅ assigned | ❌ | ❌ (reads feedback) |
| Enter marks | ✅ | ✅ own exams | ❌ | ❌ |
| **Publish results** | ✅ `results.publish` | ❌ by default (submits for owner review; owner can enable it) | ❌ | ❌ |
| Fees, ledger, receipts | ✅ `fees.view` / `fees.record` | ❌ by default | ❌ | Own child's fees and receipts (read-only) |
| Publish notices | ✅ `notices.publish` | ❌ by default | ❌ | ❌ |
| Notices (read) | All | Audience-filtered | Audience-filtered | Audience-filtered by child's batch |
| Leave | Approve staff & student leave | Request own leave; see leave of own students | ❌ | Request leave for linked children |
| Doubts | ❌ | Reply to own | Ask own teacher | ❌ |
| Meeting requests | Approve | Approve | ❌ | Request |
| Permissions & members | ✅ `staff.manage` | ❌ | ❌ | ❌ |

## Guardian verification

A guardian record has `status` (`pending` → `invited` → `verified`) and `consent`. The parent experience lists only guardians with `linked = true`, `status = verified` **and** `consent = true`. Revoking access in **Guardian linking (S24)** removes the child from the parent's view immediately.

## Configurable switches (S41 → Permissions)

Owner can toggle, for Teachers: view fees, record payments, edit students, edit attendance, publish results, publish notices, manage staff, view reports. Students and parents have fixed rules.
