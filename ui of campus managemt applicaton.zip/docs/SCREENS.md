# GuruFlow — Screen inventory (S01–S82)

Status legend: ✅ implemented and render-tested (all 82 render with shared demo data); ◐ = partly demo-only behaviour (noted).

Every screen is also reachable from **More → All screens (demo directory)** or the side panel's **All 82 screens** button on desktop.

| ID | Screen | Role | Status | How to reach |
|---|---|---|---|---|
| S01 | Splash | All | ✅ | Launch flow / Welcome |
| S02 | Welcome / Onboarding | All | ✅ | Launch flow / Welcome |
| S03 | Sign In | All | ✅ | Launch flow / Welcome |
| S04 | Create Account | All | ✅ | Launch flow / Welcome |
| S05 | OTP Verification | All | ◐ | Launch flow / Welcome |
| S06 | Forgot / Reset Password | All | ◐ | Launch flow / Welcome |
| S07 | Profile Setup | All | ✅ | Launch flow / Welcome |
| S08 | Institute Selection | All | ✅ | Launch flow / Welcome |
| S09 | Create Institute | All | ✅ | Launch flow / Welcome |
| S10 | Join Institute | All | ✅ | Launch flow / Welcome |
| S11 | Notifications Inbox | All | ✅ | Bell, search and profile icons; More → Account |
| S12 | Global Search | All | ✅ | Bell, search and profile icons; More → Account |
| S13 | User Profile | All | ✅ | Bell, search and profile icons; More → Account |
| S14 | Preferences / Help / Privacy | All | ✅ | Bell, search and profile icons; More → Account |
| S15 | Global Application States | All | ✅ | Preferences → Demo tools → App states gallery |
| S16 | Owner Dashboard | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S17 | Admissions Overview | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S18 | Enquiry Pipeline | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S19 | Add / Edit Enquiry | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S20 | Enquiry Details | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S21 | Student Directory | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S22 | Add / Edit Student | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S23 | Student 360 Profile | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S24 | Guardian Linking / Verification | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S25 | Staff Directory | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S26 | Staff Profile | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S27 | Academic Sessions | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S28 | Batches / Classes | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S29 | Batch Details / Roster | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S30 | Subjects / Classrooms | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S31 | Timetable Management | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S32 | Attendance Reports | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S33 | Exam Management | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S34 | Exam Details / Marks Overview | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S35 | Fees Dashboard | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S36 | Fee Structures / Assignments | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S37 | Payments / Ledger / Receipts | owner | ◐ | Owner tabs: Home / Admissions / Students / Academics / More |
| S38 | Study Resources Management | owner | ◐ | Owner tabs: Home / Admissions / Students / Academics / More |
| S39 | Notices / Communication | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S40 | Insights / Reports | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S41 | Institute Settings / Members / Permissions | owner | ✅ | Owner tabs: Home / Admissions / Students / Academics / More |
| S42 | Teacher Home / My Work | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S43 | Teacher Timetable | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S44 | My Classes | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S45 | Class Detail / Class Diary | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S46 | Attendance Marking | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S47 | Homework List / Review Queue | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S48 | Create / Edit Homework | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S49 | Submission Review | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S50 | Exam / Marks Entry | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S51 | Assigned Students / Detail | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S52 | Teacher Resources | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S53 | Doubt Inbox / Detail | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S54 | Leave Request / Calendar | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S55 | Notices / Notifications / Profile | teacher | ✅ | Teacher tabs: Home / Classes / Attendance / Homework / More |
| S56 | Student Home / My Day | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S57 | Timetable / Class Detail | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S58 | My Attendance | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S59 | Homework List | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S60 | Homework Detail / Submission | student | ◐ | Student tabs: Home / Timetable / Homework / Practice / More |
| S61 | Homework Feedback | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S62 | Exams / Exam Schedule | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S63 | My Results | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S64 | Study Planner | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S65 | Practice Zone | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S66 | Quiz Attempt / Results / Mistake Review | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S67 | My Progress | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S68 | Learning Library | student | ◐ | Student tabs: Home / Timetable / Homework / Practice / More |
| S69 | Resource Detail / Reader | student | ◐ | Student tabs: Home / Timetable / Homework / Practice / More |
| S70 | Ask Your Teacher / Doubt Detail | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S71 | Achievements / Milestones / Profile | student | ✅ | Student tabs: Home / Timetable / Homework / Practice / More |
| S72 | Parent Home / Child Overview | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S73 | Child Attendance | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S74 | Child Results / Progress | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S75 | Child Homework | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S76 | Weekly Progress Digest | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S77 | Fees / Dues / Instalments | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S78 | Payment History / Receipt | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S79 | Institute Notices | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S80 | Leave Request | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S81 | Teacher Contact / Meeting Request | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |
| S82 | Parent Notifications / Preferences / Profile | parent | ✅ | Parent tabs: Home / Academics / Fees / Notices / More |

◐ notes: S05/S06 use a documented demo code (123456, no SMS/email); S37/S78 payments are DEMO records; S38/S60 file picks are not uploaded anywhere; S68/S69 show sample previews and have no offline download.

Extra navigation screens (not counted in the 82): Academics hub, Owner/Teacher/Student/Parent *More* hubs, Parent Academics hub, Screen directory.
