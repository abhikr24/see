# Testing report

All results below come from commands actually run in this workspace.

## Automated checks

| Check | Command | Result |
|---|---|---|
| Next type generation | `npx next typegen` | pass |
| TypeScript | `npx tsc --noEmit` | pass (0 errors) |
| Production build | `npm run build` | pass |
| ESLint | `npx eslint src` | pass (0 problems; `react/no-unescaped-entities` and `no-img-element` rules disabled on purpose) |
| Render smoke test | `npx --yes tsx scripts/smoke-render.tsx` | all 82 screens (+ 7 hub/directory screens) server-render with the correct role and shared data, 0 failures |
| Interaction test (jsdom) | `npx --yes tsx scripts/e2e-jsdom.tsx` | 23 assertions passed (see below) |

### Interaction test coverage (jsdom — simulated browser, not a device)

Splash → onboarding → sign-in (blocked while invalid, then success) → institute selection → multi-role sheet → teacher home → attendance tab → mark all present → mark one absent → confirm dialog → store updated + parent notification created → switch to student → homework detail → submit confirmation → submission stored + teacher notified → Practice zone: subject → chapter → topic → answer 3 questions → submit → score and mistake review shown, attempt stored → owner publishes exam → student results updated → teacher publishing blocked by permission → parent child selector switches displayed child → owner revokes guardian → parent loses access.

## Not tested (be aware)

- **No real-browser or visual verification was possible**: a headless Chromium download succeeded but could not launch in this sandbox (missing system library `libnspr4`), so no screenshots were taken and layouts have not been visually inspected.
- No visual QA on real Android devices or at multiple physical screen sizes; layouts were built for 360–430 px widths using responsive utility classes.
- No automated accessibility audit (labels, roles and 44 px targets were applied manually).
- Hardware back button behaviour relies on browser history (`popstate`) and was not exercised on a device.
- Date/time pickers use the browser's native pickers.

## Known limitations

- Delivered as a Next.js mobile-first web app, **not** React Native / Expo (the workspace cannot run Expo).
- Demo data is in memory: it resets on page reload (use **Reset data** to restore mid-session).
- OTP/recovery code (`123456`), payments (`DEMO` records, no UPI/bank simulation), file uploads (metadata only), data export and account closure are demo interactions and are labelled as such.
- Resource preview is a sample placeholder; there is no real PDF/image rendering, offline download or video.
- Language preference is stored as a preference only; the UI text is English.
- Institutes created in-app start empty (useful to check empty states).
