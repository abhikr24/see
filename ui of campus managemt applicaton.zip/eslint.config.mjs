import { defineConfig, globalIgnores } from "eslint/config";
import nextCoreWebVitals from "eslint-config-next/core-web-vitals";

export default defineConfig([
  // Keep the starter on the flat config export that actually runs under the pinned ESLint/Next toolchain.
  ...nextCoreWebVitals,
  globalIgnores([".next/**", "out/**", "build/**", "next-env.d.ts", "scripts/**"]),
  {
    rules: {
      // Apostrophes in JSX copy are intentional; blob: previews for picked files cannot use next/image.
      "react/no-unescaped-entities": "off",
      "@next/next/no-img-element": "off",
    },
  },
]);
