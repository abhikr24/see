// Interaction smoke test in jsdom (not a real device test). Run: npx tsx scripts/e2e-jsdom.tsx
import { JSDOM } from "jsdom";
const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", { url: "http://localhost/", pretendToBeVisual: true });
const g = globalThis as any;
g.window = dom.window; g.document = dom.window.document; g.HTMLElement = dom.window.HTMLElement; g.Node = dom.window.Node; g.IS_REACT_ACT_ENVIRONMENT = true;
Object.defineProperty(g, "navigator", { value: dom.window.navigator, configurable: true });
g.requestAnimationFrame = (f: any) => setTimeout(f, 0); g.getComputedStyle = dom.window.getComputedStyle;
(dom.window as any).HTMLElement.prototype.showPicker = () => {};
import React from "react";
import { act } from "react";

const results: string[] = []; let failed = 0;
const ok = (c: any, m: string) => { if (c) results.push("PASS " + m); else { results.push("FAIL " + m); failed++; } };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const wait = async (ms = 50) => { await act(async () => { await sleep(ms); }); };
const $$ = (sel: string) => Array.from(document.querySelectorAll(sel)) as HTMLElement[];
const byText = (txt: string, sel = "button") => $$(sel).find((e) => (e.textContent ?? "").trim() === txt || e.getAttribute("aria-label") === txt);
const hasText = (t: string) => (document.body.textContent ?? "").includes(t);
const click = async (el?: HTMLElement | null, label = "") => { if (!el) throw new Error("not found: " + label); await act(async () => { el.dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true })); }); await wait(30); };
const setVal = async (el: HTMLInputElement | HTMLTextAreaElement, v: string) => { const proto = el.tagName === "TEXTAREA" ? dom.window.HTMLTextAreaElement.prototype : dom.window.HTMLInputElement.prototype; await act(async () => { Object.getOwnPropertyDescriptor(proto, "value")!.set!.call(el, v); el.dispatchEvent(new dom.window.Event("input", { bubbles: true })); }); };

async function main() {
  const { createRoot } = await import("react-dom/client");
  const { default: Shell } = await import("@/shell/Shell");
  const { getRepository } = await import("@/data/factory");
  const { uc } = await import("@/features/usecases");
  const { today } = await import("@/lib/fmt");
  const { resultsFor, parentChildren } = await import("@/features/selectors");
  const repo = getRepository();
  const root = createRoot(document.getElementById("root")!);
  await act(async () => { root.render(<Shell />); });
  await wait(2300);
  ok(hasText("Create account"), "splash → welcome");
  await click(byText("Skip")); await click(byText("Sign in")); ok(hasText("Fill demo credentials"), "welcome → sign in");
  await click(byText("Sign in", "button")); // disabled until valid
  ok(hasText("Fill demo credentials"), "sign in blocked while invalid");
  await click(byText("Fill demo credentials")); await click(byText("Sign in", "button")); await wait(1200);
  ok(hasText("Choose institute"), "sign in → institute selection");
  await click($$("button").find((b) => (b.textContent ?? "").includes("Aarohan Learning Institute"))); ok(hasText("Continue as"), "multi-role sheet opens");
  await click($$("button").find((b) => (b.textContent ?? "").startsWith("Teacher") && (b.textContent ?? "").includes("Classes")));
  ok(hasText("Attendance pending"), "teacher home");
  await click(byText("Attendance")); ok(hasText("Mark all present"), "attendance tab");
  await click(byText("Mark all present"));
  const grp = document.querySelector('[aria-label="Attendance for Aarav Sharma"]')!;
  await click(Array.from(grp.querySelectorAll("button")).find((b) => b.getAttribute("aria-label") === "Absent") as HTMLElement);
  await click(byText("Save attendance")); ok(hasText("Save attendance?"), "confirm dialog before saving attendance");
  await click(byText("Save")); await wait(100);
  ok(repo.getSnapshot().attendance[`${today()}|s1`] === "A", "teacher marked Aarav absent (shared store)");
  ok(repo.getSnapshot().notifications.some((n) => n.studentId === "s1" && n.cat === "attendance" && n.title.includes("absent on")), "parent notification created for the absence");

  // student submits homework
  await click(byText("Student"), "side student"); await wait(50);
  ok(hasText("Homework to do"), "student home");
  await click(byText("Homework")); await click($$("button").find((b) => (b.textContent ?? "").includes("Quadratic Equations Worksheet 4")));
  const ta = document.querySelector("textarea") as HTMLTextAreaElement; await setVal(ta, "x = 3 and x = 4 because the discriminant is 1.");
  console.log("DBG0", ta.value, ta.isConnected, document.querySelector("textarea") === ta, hasText("Your answer"), hasText("Your submission"));
  console.log("DBG", (byText("Submit homework") as HTMLButtonElement | undefined)?.disabled, document.querySelectorAll("textarea").length, (document.querySelector("h1")?.textContent));
  await click(byText("Submit homework")); ok(hasText("Submit homework?"), "submit confirmation");
  await click(byText("Submit")); await wait(100);
  ok(repo.getSnapshot().submissions.find((s) => s.id === "sub-h1-s1")?.status === "submitted", "student submission stored");
  ok(repo.getSnapshot().notifications.some((n) => n.roles.includes("teacher") && n.title.includes("Aarav Sharma")), "teacher notified of submission");

  // practice quiz
  await click(byText("Go back")); await wait(80);
  await click(byText("Practice")); await click($$("button").find((b) => (b.textContent ?? "").startsWith("Mathematics") && (b.textContent ?? "").includes("questions")));
  await click($$("button").find((b) => (b.textContent ?? "").startsWith("Quadratic Equations"))); await click($$("button").find((b) => (b.textContent ?? "").includes("Roots & Discriminant") && (b.textContent ?? "").includes("Start")));
  ok(hasText("Question 1 of 3"), "quiz opens");
  for (let i = 0; i < 3; i++) { await click($$('[role="radio"]')[i === 0 ? 0 : 2]); if (i < 2) await click(byText("Next")); }
  await click(byText("Submit")); await click($$("button").filter((b) => (b.textContent ?? "").trim() === "Submit").pop(), "dialog submit"); await wait(80);
  ok(hasText("correct") && hasText("Mistakes"), "quiz score + mistake review shown");
  ok(repo.getSnapshot().attempts.filter((a) => a.studentId === "s1").length === 3, "attempt recorded");

  // publish marks → student + parent results
  const before = resultsFor(repo.getSnapshot(), "s1").length;
  await uc.publishExam("x2", "owner");
  ok(resultsFor(repo.getSnapshot(), "s1").length === before + 1, "owner publish → student results updated");
  let denied = false; try { await uc.publishExam("x3", "teacher"); } catch { denied = true; }
  ok(denied, "teacher blocked from publishing (permission)");

  // parent child switcher
  await click(byText("Parent"), "side parent"); await wait(50);
  ok(hasText("Viewing") && hasText("Aarav attended"), "parent home shows verified child (Aarav)");
  await click($$('[role="radio"]').find((r) => (r.textContent ?? "").includes("Ananya"))); await wait(50);
  ok(hasText("Ananya attended") && !hasText("Aarav attended"), "child selector switches displayed data");
  const g = repo.getSnapshot().guardians.find((x) => x.studentId === "s2")!; await uc.revokeGuardian(g); await wait(50);
  ok(parentChildren(repo.getSnapshot(), "i1").length === 1, "revoked guardian loses child access");
  await wait(80); ok(hasText("Aarav attended") && !hasText("Ananya attended"), "parent UI falls back to the only verified child");

  console.log(results.join("\n")); console.log(failed ? `\n${failed} FAILED` : "\nALL PASSED");
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.log(results.join("\n")); console.error("ERROR", e); process.exit(1); });
