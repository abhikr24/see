import { SCREENS, SCREEN_IDS } from "@/screens/registry";
const route: Record<string, string> = { shared: "Welcome → Sign in / Create account → Institute selection (S01–S10); bell/search/profile from any Home (S11–S14); Preferences → Demo tools → App states (S15)" };
const lines = ["# GuruFlow — Screen inventory (S01–S82)", "", "Status legend: ✅ implemented and render-tested (all 82 render with shared demo data); ◐ = partly demo-only behaviour (noted).", "", "Every screen is also reachable from **More → All screens (demo directory)** or the side panel's **All 82 screens** button on desktop.", "", "| ID | Screen | Role | Status | How to reach |", "|---|---|---|---|---|"];
const reach = (id: string, role: string) => {
  const n = Number(id.slice(1));
  if (n <= 10) return "Launch flow / Welcome";
  if (n <= 14) return "Bell, search and profile icons; More → Account";
  if (n === 15) return "Preferences → App states link in directory";
  if (role === "owner") return "Owner tabs: Home / Admissions / Students / Academics / More";
  if (role === "teacher") return "Teacher tabs: Home / Classes / Attendance / Homework / More";
  if (role === "student") return "Student tabs: Home / Timetable / Homework / Practice / More";
  return "Parent tabs: Home / Academics / Fees / Notices / More";
};
for (const id of SCREEN_IDS) { const s = SCREENS[id]; const partial = ["S05", "S06", "S37", "S38", "S60", "S69", "S68"].includes(id) ? "◐" : "✅"; lines.push(`| ${id} | ${s?.title ?? "MISSING"} | ${s?.role === "shared" ? "All" : s?.role} | ${s ? partial : "❌"} | ${reach(id, s?.role ?? "")} |`); }
lines.push("", "◐ notes: S05/S06 use a documented demo code (123456, no SMS/email); S37/S78 payments are DEMO records; S38/S60 file picks are not uploaded anywhere; S68/S69 show sample previews and have no offline download.", "", "Extra navigation screens (not counted in the 82): Academics hub, Owner/Teacher/Student/Parent *More* hubs, Parent Academics hub, Screen directory.");
console.log(lines.join("\n"));
