// Smoke test: server-render every screen S01–S82 (+ hubs) with the correct role and the shared demo data.
import React from "react";
import { renderToString } from "react-dom/server";
import { AppProvider } from "@/state/app";
import { SCREENS, SCREEN_IDS } from "@/screens/registry";

const params: Record<string, any> = { S49: {}, S53: {}, S66: { subject: "Mathematics", chapter: "Quadratic Equations" }, S70: {} };
let fail = 0;
const ids = [...SCREEN_IDS, ...Object.keys(SCREENS).filter((k) => !SCREEN_IDS.includes(k))];
for (const id of ids) {
  const d = SCREENS[id];
  if (!d) { console.log("MISSING", id); fail++; continue; }
  const role = d.role === "shared" ? "owner" : d.role;
  for (const extra of [{}, ...(id === "S66" ? [{ topic: "Roots & Discriminant" }] : [])]) {
    try {
      const html = renderToString(<AppProvider initialSession={{ authed: true, role: role as any }}><d.C params={{ ...(params[id] ?? {}), ...extra }} /></AppProvider>);
      if (html.length < 200) { console.log("SHORT", id, html.length); fail++; }
    } catch (e) { console.log("FAIL", id, d.title, (e as Error).message.split("\n")[0]); fail++; }
  }
}
console.log(`rendered ${ids.length} screens, failures: ${fail}`);
process.exit(fail ? 1 : 0);
