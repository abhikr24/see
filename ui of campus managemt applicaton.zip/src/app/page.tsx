import ClientRoot from "@/shell/ClientRoot";

export default function HomePage() {
  return <ClientRoot />;
}
