import type { CollectionKey, DB, Item, PermMatrix, AttStatus } from "@/domain/types";
import type { GuruRepository } from "../repository";
import { createSeed } from "../seed";

/** In-memory adapter powering the prototype. One shared store → every role sees the same records. */
export class DemoAdapter implements GuruRepository {
  readonly kind = "demo" as const;
  private db: DB = createSeed();
  private listeners = new Set<() => void>();

  getSnapshot = () => this.db;

  subscribe = (l: () => void) => {
    this.listeners.add(l);
    return () => {
      this.listeners.delete(l);
    };
  };

  private commit(next: DB) {
    this.db = next;
    this.listeners.forEach((l) => l());
  }

  async upsert<K extends CollectionKey>(key: K, item: Item<K>): Promise<Item<K>> {
    const list = this.db[key] as unknown as { id: string }[];
    const exists = list.some((x) => x.id === (item as { id: string }).id);
    const nextList = exists ? list.map((x) => (x.id === (item as { id: string }).id ? (item as { id: string }) : x)) : [item as { id: string }, ...list];
    this.commit({ ...this.db, [key]: nextList } as DB);
    return item;
  }

  async remove<K extends CollectionKey>(key: K, id: string) {
    const list = this.db[key] as unknown as { id: string }[];
    this.commit({ ...this.db, [key]: list.filter((x) => x.id !== id) } as DB);
  }

  async setAttendance(entries: { date: string; studentId: string; status: AttStatus }[]) {
    const attendance = { ...this.db.attendance };
    entries.forEach((e) => (attendance[`${e.date}|${e.studentId}`] = e.status));
    this.commit({ ...this.db, attendance });
  }

  async setMarks(entries: { examId: string; studentId: string; marks: number | null }[]) {
    const marks = { ...this.db.marks };
    entries.forEach((e) => {
      const k = `${e.examId}|${e.studentId}`;
      if (e.marks === null) delete marks[k];
      else marks[k] = e.marks;
    });
    this.commit({ ...this.db, marks });
  }

  async setPermissions(permissions: PermMatrix) {
    this.commit({ ...this.db, permissions });
  }

  async reset() {
    this.commit(createSeed());
  }
}
