import type { GuruRepository } from "../repository";

/**
 * Integration boundary for a future Supabase backend. Intentionally NOT implemented in this prototype.
 *
 * To implement: create a client with the public anon key only (`EXPO_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_URL`),
 * map each collection in `DB` to a table protected by Row Level Security, and implement every `GuruRepository` method.
 * Never ship the service-role key or payment secrets in the client — see BACKEND_SETUP.md.
 */
export function createSupabaseAdapter(): GuruRepository {
  throw new Error("SupabaseAdapter is not implemented yet. Set NEXT_PUBLIC_GURUFLOW_BACKEND=demo or follow BACKEND_SETUP.md.");
}
