import type { GuruRepository } from "./repository";
import { DemoAdapter } from "./adapters/demo";
import { createSupabaseAdapter } from "./adapters/supabase";

/** Provider factory — picks the backend adapter from NEXT_PUBLIC_GURUFLOW_BACKEND ("demo" | "supabase" | "custom"). */
function create(): GuruRepository {
  const kind = process.env.NEXT_PUBLIC_GURUFLOW_BACKEND ?? "demo";
  if (kind === "supabase") return createSupabaseAdapter();
  if (kind === "custom") throw new Error("CustomAdapter not implemented — implement GuruRepository and register it here.");
  return new DemoAdapter();
}

let repo: GuruRepository | null = null;
export const getRepository = (): GuruRepository => (repo ??= create());
