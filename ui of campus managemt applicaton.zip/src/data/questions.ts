import type { Question } from "@/domain/types";

// Locally stored practice questions (no runtime AI). Tuple: [subject, chapter, topic, question, options, answerIndex, explanation]
type T = [string, string, string, string, string[], number, string];
const RAW: T[] = [
  ["Mathematics", "Quadratic Equations", "Roots & Discriminant", "What is the discriminant of x² − 5x + 6 = 0?", ["1", "5", "25", "−1"], 0, "D = b² − 4ac = 25 − 24 = 1."],
  ["Mathematics", "Quadratic Equations", "Roots & Discriminant", "If the discriminant is negative, the roots are…", ["Real and equal", "Real and distinct", "Not real", "Always zero"], 2, "A negative discriminant means no real roots."],
  ["Mathematics", "Quadratic Equations", "Roots & Discriminant", "Roots of x² − 7x + 12 = 0 are…", ["3 and 4", "2 and 6", "−3 and −4", "1 and 12"], 0, "Sum 7 and product 12 give 3 and 4."],
  ["Mathematics", "Quadratic Equations", "Word Problems", "The product of two consecutive positive integers is 56. The smaller integer is…", ["6", "7", "8", "9"], 1, "n(n+1)=56 → n=7."],
  ["Mathematics", "Quadratic Equations", "Word Problems", "A rectangle has area 48 cm² and length 2 cm more than width. Its width is…", ["6 cm", "7 cm", "8 cm", "4 cm"], 0, "w(w+2)=48 → w=6."],
  ["Mathematics", "Quadratic Equations", "Word Problems", "Sum of a number and its square is 30. A positive such number is…", ["4", "5", "6", "7"], 1, "n² + n − 30 = 0 → n = 5."],
  ["Mathematics", "Trigonometry", "Ratios", "sin 30° equals…", ["1/2", "√3/2", "1", "0"], 0, "Standard value: sin 30° = 1/2."],
  ["Mathematics", "Trigonometry", "Ratios", "tan 45° equals…", ["0", "1", "√3", "1/√3"], 1, "tan 45° = 1."],
  ["Mathematics", "Trigonometry", "Ratios", "cos 60° equals…", ["√3/2", "1", "1/2", "0"], 2, "cos 60° = 1/2."],
  ["Mathematics", "Trigonometry", "Identities", "sin²θ + cos²θ equals…", ["0", "1", "2", "tan²θ"], 1, "Fundamental Pythagorean identity."],
  ["Mathematics", "Trigonometry", "Identities", "1 + tan²θ equals…", ["sec²θ", "cosec²θ", "cot²θ", "sin²θ"], 0, "Divide sin²θ + cos²θ = 1 by cos²θ."],
  ["Mathematics", "Trigonometry", "Identities", "sec²θ − tan²θ equals…", ["0", "1", "−1", "2"], 1, "sec²θ = 1 + tan²θ."],
  ["Science", "Chemical Reactions", "Types of Reactions", "Rusting of iron is an example of…", ["Oxidation", "Reduction", "Neutralisation", "Decomposition"], 0, "Iron reacts with oxygen and moisture."],
  ["Science", "Chemical Reactions", "Types of Reactions", "Which is a decomposition reaction?", ["2H₂O → 2H₂ + O₂", "C + O₂ → CO₂", "NaOH + HCl → NaCl + H₂O", "Fe + CuSO₄ → FeSO₄ + Cu"], 0, "One compound breaks into simpler substances."],
  ["Science", "Chemical Reactions", "Balancing Equations", "Balanced form of H₂ + O₂ → H₂O needs coefficients…", ["1,1,1", "2,1,2", "1,2,2", "2,2,1"], 1, "2H₂ + O₂ → 2H₂O."],
  ["Science", "Chemical Reactions", "Balancing Equations", "A balanced equation obeys the law of…", ["Conservation of mass", "Gravitation", "Reflection", "Inertia"], 0, "Mass is neither created nor destroyed."],
  ["Science", "Light", "Reflection", "The angle of incidence equals…", ["Angle of refraction", "Angle of reflection", "Critical angle", "Zero"], 1, "First law of reflection."],
  ["Science", "Light", "Reflection", "A plane mirror forms an image that is…", ["Real and inverted", "Virtual and erect", "Real and erect", "Virtual and inverted"], 1, "Plane mirror images are virtual, erect, laterally inverted."],
  ["Science", "Light", "Refraction", "Light bends towards the normal when it enters…", ["A denser medium", "A rarer medium", "Vacuum", "Air from water"], 0, "Speed decreases in a denser medium."],
  ["Science", "Light", "Refraction", "SI unit of power of a lens is…", ["Metre", "Dioptre", "Watt", "Candela"], 1, "P = 1/f (in metres) is measured in dioptre."],
  ["English", "Grammar Essentials", "Tenses", "Choose the correct sentence.", ["She go to school.", "She goes to school.", "She going to school.", "She gone to school."], 1, "Third person singular takes 'goes'."],
  ["English", "Grammar Essentials", "Tenses", "'They ___ dinner when I arrived.' Fill the blank.", ["were having", "have", "has had", "having"], 0, "Past continuous for an action in progress."],
  ["English", "Grammar Essentials", "Vocabulary", "Synonym of 'Rapid' is…", ["Slow", "Quick", "Late", "Weak"], 1, "Rapid means quick."],
  ["English", "Grammar Essentials", "Vocabulary", "Antonym of 'Generous' is…", ["Kind", "Selfish", "Polite", "Brave"], 1, "Generous ↔ selfish."],
];

export const QUESTIONS: Question[] = RAW.map((r, i) => ({
  id: `q${i + 1}`, subject: r[0], chapter: r[1], topic: r[2], q: r[3], options: r[4], answer: r[5], explanation: r[6],
}));
