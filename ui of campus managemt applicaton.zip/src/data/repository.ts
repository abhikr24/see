import type { AttStatus, CollectionKey, DB, Item, PermMatrix } from "@/domain/types";

/**
 * Typed repository boundary. UI screens never talk to a backend SDK directly:
 *
 *   Screens → use-cases (src/features/usecases.ts) → GuruRepository → Provider factory → Demo | Supabase | Custom adapter
 *
 * Any backend adapter has to implement this contract. Reads are exposed as an immutable snapshot plus a subscription so
 * screens re-render when another role changes shared data (e.g. teacher marks absent → parent view updates).
 */
export interface GuruRepository {
  readonly kind: "demo" | "supabase" | "custom";
  getSnapshot(): DB;
  subscribe(listener: () => void): () => void;
  upsert<K extends CollectionKey>(key: K, item: Item<K>): Promise<Item<K>>;
  remove<K extends CollectionKey>(key: K, id: string): Promise<void>;
  setAttendance(entries: { date: string; studentId: string; status: AttStatus }[]): Promise<void>;
  setMarks(entries: { examId: string; studentId: string; marks: number | null }[]): Promise<void>;
  setPermissions(matrix: PermMatrix): Promise<void>;
  reset(): Promise<void>;
}
