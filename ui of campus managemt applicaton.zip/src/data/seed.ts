import type {
  AcademicSession, ActivityItem, AppNotification, Attempt, AttStatus, Batch, DB, Doubt, Enquiry, EnquiryStatus, Exam, FeeAccount,
  FeeStructure, Guardian, Homework, LeaveRequest, MeetingRequest, Notice, Payment, PermMatrix, PlannerTask, Resource, Room, Staff,
  Student, Submission, TimetableEntry,
} from "@/domain/types";
import { academicYear, addDays, iso, pad } from "@/lib/fmt";

const dt = (daysAgo: number, h = 10, m = 0) => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(h, m, 0, 0);
  return d.toISOString();
};
const hash = (s: string) => {
  let h = 7;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return h;
};

export const DEMO_PARENT_PHONE = "9822011234";

export function createSeed(): DB {
  const ay = academicYear();
  const sessions: AcademicSession[] = [
    { id: "ss1", inst: "i1", label: ay.label, start: ay.start, end: ay.end, active: true },
    { id: "ss0", inst: "i1", label: ay.prev, start: addDays(-365, ay.start), end: addDays(-365, ay.end), active: false },
    { id: "ss2", inst: "i2", label: ay.label, start: ay.start, end: ay.end, active: true },
  ];
  const rooms: Room[] = [
    { id: "r1", inst: "i1", name: "Room 101", capacity: 40, kind: "Classroom" },
    { id: "r2", inst: "i1", name: "Room 102", capacity: 30, kind: "Classroom" },
    { id: "r3", inst: "i1", name: "Science Lab A", capacity: 24, kind: "Laboratory" },
    { id: "r4", inst: "i2", name: "Hall A", capacity: 35, kind: "Classroom" },
  ];
  const batches: Batch[] = [
    { id: "b1", inst: "i1", name: "Class 10 – Science (Morning)", course: "SSC Board Foundation", session: "ss1", roomId: "r1", status: "active", subjectTeachers: { Mathematics: "st1", Science: "st2", English: "st3" } },
    { id: "b2", inst: "i1", name: "Class 8 – All Subjects", course: "Middle School Excellence", session: "ss1", roomId: "r2", status: "active", subjectTeachers: { Mathematics: "st1", English: "st3", "Social Science": "st5" } },
    { id: "b3", inst: "i1", name: "Class 12 – PCM (Evening)", course: "JEE Foundation", session: "ss1", roomId: "r3", status: "active", subjectTeachers: { Physics: "st2", Chemistry: "st4", Mathematics: "st4" } },
    { id: "b4", inst: "i2", name: "Class 9 – Science", course: "Science Stream", session: "ss2", roomId: "r4", status: "active", subjectTeachers: { Science: "st6", Mathematics: "st6", English: "st7" } },
  ];
  const sp = (...a: string[]) => a;
  const staff: Staff[] = [
    { id: "st1", inst: "i1", name: "Priya Deshmukh", role: "Senior Teacher", subjects: sp("Mathematics"), batchIds: ["b1", "b2"], status: "active", phone: "9890123456", email: "priya.d@aarohan.example", joined: "2021-06-14", weeklyHours: 18 },
    { id: "st2", inst: "i1", name: "Rahul Iyer", role: "Teacher", subjects: sp("Science", "Physics"), batchIds: ["b1", "b3"], status: "active", phone: "9822334455", email: "rahul.i@aarohan.example", joined: "2022-07-01", weeklyHours: 16 },
    { id: "st3", inst: "i1", name: "Farah Khan", role: "Teacher", subjects: sp("English"), batchIds: ["b1", "b2"], status: "active", phone: "9765432109", email: "farah.k@aarohan.example", joined: "2023-01-09", weeklyHours: 14 },
    { id: "st4", inst: "i1", name: "Suresh Patil", role: "Senior Teacher", subjects: sp("Chemistry", "Mathematics"), batchIds: ["b3"], status: "on-leave", phone: "9923456781", email: "suresh.p@aarohan.example", joined: "2020-04-20", weeklyHours: 12 },
    { id: "st5", inst: "i1", name: "Meera Kulkarni", role: "Teacher", subjects: sp("Social Science"), batchIds: ["b2"], status: "active", phone: "9657012345", email: "meera.k@aarohan.example", joined: "2024-02-12", weeklyHours: 9 },
    { id: "st6", inst: "i2", name: "Priya Deshmukh", role: "Teacher", subjects: sp("Science", "Mathematics"), batchIds: ["b4"], status: "active", phone: "9890123456", email: "priya.d@saraswati.example", joined: "2024-06-03", weeklyHours: 10 },
    { id: "st7", inst: "i2", name: "Anjali Bapat", role: "Teacher", subjects: sp("English"), batchIds: ["b4"], status: "active", phone: "9604556677", email: "anjali.b@saraswati.example", joined: "2023-08-21", weeklyHours: 6 },
  ];

  const sRows: [string, string, string, string][] = [
    ["s1", "i1", "Aarav Sharma", "b1"], ["s2", "i1", "Ananya Sharma", "b2"], ["s3", "i1", "Ishita Verma", "b1"], ["s4", "i1", "Mohammed Zaid Ansari", "b1"],
    ["s5", "i1", "Kavya Nair", "b1"], ["s6", "i1", "Rohan Gupta", "b1"], ["s7", "i1", "Simran Kaur", "b1"], ["s8", "i1", "Aditya Patil", "b1"],
    ["s9", "i1", "Vihaan Reddy", "b2"], ["s10", "i1", "Diya Mehta", "b2"], ["s11", "i1", "Arjun Singh", "b2"], ["s12", "i1", "Sneha Joshi", "b2"],
    ["s13", "i1", "Yash Chavan", "b2"], ["s14", "i1", "Tanvi Bhosale", "b3"], ["s15", "i1", "Karthik Menon", "b3"], ["s16", "i1", "Nisha Rao", "b3"],
    ["s17", "i1", "Harsh Agarwal", "b3"], ["s18", "i2", "Pranav Deshpande", "b4"], ["s19", "i2", "Riya Thakur", "b4"], ["s20", "i2", "Omkar Wagh", "b4"], ["s21", "i2", "Fatima Sheikh", "b4"],
  ];
  const cities = ["Kothrud, Pune", "Baner, Pune", "Wakad, Pune", "Aundh, Pune", "Hadapsar, Pune", "Dharampeth, Nagpur"];
  const students: Student[] = sRows.map(([id, inst, name, batchId], i) => {
    const b = batches.find((x) => x.id === batchId)!;
    const yrs = batchId === "b1" ? 15 : batchId === "b2" ? 13 : batchId === "b3" ? 17 : 14;
    return {
      id, inst, name, batchId, sid: `${inst === "i1" ? "AL" : "SS"}-${ay.label.slice(2, 4)}-${pad(i + 1).padStart(3, "0")}`,
      dob: `${new Date().getFullYear() - yrs - (i % 2)}-${pad((i % 11) + 1)}-${pad(((i * 3) % 27) + 1)}`,
      phone: `98${pad(20 + (i % 70))}${pad(100 + i).slice(0, 2)}${pad(10 + i)}${pad(40 + i)}`.slice(0, 10),
      address: `${12 + i}, ${cities[i % cities.length]}`, admDate: addDays(-120 - i * 9), status: "active", session: b.session,
      subjects: Object.keys(b.subjectTeachers),
    };
  });
  students[11].status = "inactive";

  const surname = (n: string) => n.split(" ").slice(-1)[0];
  const guardians: Guardian[] = students.map((s, i) => ({
    id: `g-${s.id}`, inst: s.inst, studentId: s.id,
    name: s.id === "s1" || s.id === "s2" ? "Rajesh Sharma" : `${["Sunil", "Anita", "Vikram", "Deepa", "Imran", "Lakshmi", "Manoj"][i % 7]} ${surname(s.name)}`,
    relation: i % 3 === 1 ? "Mother" : "Father", phone: s.id === "s1" || s.id === "s2" ? DEMO_PARENT_PHONE : `9${pad(700 + i)}${pad(10 + i)}${pad(20 + i)}${pad(i)}`.slice(0, 10),
    status: i % 7 === 4 ? "invited" : i % 9 === 8 ? "pending" : "verified", consent: i % 7 !== 4 && i % 9 !== 8, linked: s.id === "s1" || s.id === "s2",
  }));

  const mk = (id: string, student: string, guardian: string, course: string, source: string, status: EnquiryStatus, ago: number, notes: string, followUp?: string, demoDate?: string): Enquiry => ({
    id, inst: "i1", student, guardian, phone: `9${pad(800 + ago)}${pad(40 + ago)}${pad(11 + ago)}${pad(ago)}`.slice(0, 10), course, source, status, notes, followUp, demoDate, createdAt: dt(ago),
    timeline: [{ at: dt(ago), text: "Enquiry received" }, ...(status !== "New" ? [{ at: dt(Math.max(ago - 1, 0), 12), text: "Guardian contacted by phone" }] : []), ...(demoDate ? [{ at: dt(Math.max(ago - 2, 0), 15), text: `Demo class scheduled for ${demoDate.split("-").reverse().join("/")}` }] : []), ...(status === "Converted" ? [{ at: dt(0, 9), text: "Converted to student" }] : []), ...(status === "Lost" ? [{ at: dt(1, 9), text: "Marked lost — fees out of budget" }] : [])],
  });
  const enquiries: Enquiry[] = [
    mk("e1", "Meghna Kale", "Prakash Kale", "Class 10 – Science", "Walk-in", "New", 0, "Interested in morning batch. Asked about board test series."),
    mk("e2", "Rishi Bansal", "Neeta Bansal", "JEE Foundation", "Instagram", "New", 1, "Wants Saturday doubt sessions."),
    mk("e3", "Aisha Siddiqui", "Farooq Siddiqui", "Class 8 – All Subjects", "Referral", "Contacted", 3, "Referred by Vihaan Reddy's parents.", addDays(1)),
    mk("e4", "Tejas Pawar", "Sandeep Pawar", "Class 10 – Science", "Website", "Demo Scheduled", 4, "Demo requested before admission.", undefined, addDays(2)),
    mk("e5", "Navya Krishnan", "Hari Krishnan", "Class 12 – PCM", "Newspaper", "Follow-up", 6, "Comparing with another institute. Call after the demo.", addDays(0)),
    mk("e6", "Dev Malhotra", "Anil Malhotra", "Class 8 – All Subjects", "Walk-in", "Converted", 9, "Admission confirmed."),
    mk("e7", "Pooja Rane", "Kishor Rane", "Class 10 – Science", "Hoarding", "Lost", 12, "Joined a school-run coaching programme."),
    mk("e8", "Samar Jain", "Rekha Jain", "JEE Foundation", "WhatsApp", "Follow-up", 5, "Needs fee instalment details.", addDays(-1)),
    mk("e9", "Kritika Sen", "Dipak Sen", "Class 8 – All Subjects", "Referral", "Contacted", 2, "Visit planned on weekend.", addDays(3)),
  ];

  // Timetable
  const slots: Record<string, [string, string][]> = {
    b1: [["09:00", "10:00"], ["10:15", "11:15"], ["11:30", "12:30"]],
    b2: [["15:00", "16:00"], ["16:15", "17:15"], ["17:30", "18:30"]],
    b3: [["17:00", "18:15"], ["18:30", "19:45"]],
    b4: [["16:00", "17:00"], ["17:15", "18:15"]],
  };
  const timetable: TimetableEntry[] = [];
  batches.forEach((b) => {
    const subs = Object.keys(b.subjectTeachers);
    for (let day = 1; day <= 6; day++)
      slots[b.id].forEach(([start, end], i) => {
        const subject = subs[(day + i) % subs.length];
        timetable.push({ id: `t-${b.id}-${day}-${i}`, inst: b.inst, batchId: b.id, subject, teacherId: b.subjectTeachers[subject], roomId: b.roomId, day, start, end });
      });
  });

  // Attendance for last 35 days
  const attendance: Record<string, AttStatus> = {};
  const todayIso = iso(new Date());
  for (let n = 35; n >= 0; n--) {
    const d = new Date();
    d.setDate(d.getDate() - n);
    if (d.getDay() === 0) continue;
    const key = iso(d);
    students.forEach((s) => {
      if (key === todayIso && (s.batchId === "b1" || s.batchId === "b2")) return;
      const r = hash(s.id + key) % 100;
      attendance[`${key}|${s.id}`] = r < 85 ? "P" : r < 93 ? "L" : "A";
    });
  }
  attendance[`${addDays(-1)}|s1`] = "A";

  // Homework
  const hwMk = (id: string, title: string, subject: string, batchId: string, due: number, max: number, instructions: string, status: "published" | "draft" = "published", file?: boolean): Homework => ({
    id, inst: batches.find((b) => b.id === batchId)!.inst, title, subject, batchId, teacherId: batches.find((b) => b.id === batchId)!.subjectTeachers[subject], instructions, due: addDays(due), max, status,
    attachment: file ? { name: `${title.replace(/\s+/g, "_")}.pdf`, size: 482000, type: "application/pdf" } : undefined, createdAt: dt(Math.max(3, 3 - due)),
  });
  const homework: Homework[] = [
    hwMk("h1", "Quadratic Equations Worksheet 4", "Mathematics", "b1", 2, 20, "Solve Q1–Q12. Show the discriminant step for every question.", "published", true),
    hwMk("h2", "Light: Refraction Lab Report", "Science", "b1", 4, 25, "Write the aim, observation table and conclusion for the glass-slab experiment.", "published", true),
    hwMk("h3", "Essay: My Role Model", "English", "b1", -2, 15, "250-word essay. Focus on paragraph structure and tenses."),
    hwMk("h4", "Trigonometry Practice Set", "Mathematics", "b1", -5, 20, "Complete exercise 8.2 questions 1–10."),
    hwMk("h5", "Algebraic Identities Drill", "Mathematics", "b2", 1, 15, "Solve the 15 identity questions from the handout.", "published", true),
    hwMk("h6", "Letter Writing Practice", "English", "b2", 3, 10, "Write one formal and one informal letter."),
    hwMk("h7", "Kinematics Numericals", "Physics", "b3", 5, 30, "Solve problems 1–8 on motion in a straight line.", "published", true),
    hwMk("h8", "Chapter 6 Summary (Draft)", "Social Science", "b2", 7, 10, "Summarise the chapter in 10 bullet points.", "draft"),
    hwMk("h9", "Force & Motion Questions", "Science", "b4", 3, 20, "Answer questions 1–6 from the textbook."),
  ];
  const submissions: Submission[] = [];
  homework.filter((h) => h.status === "published").forEach((h) => {
    students.filter((s) => s.batchId === h.batchId).forEach((s) => {
      const r = hash(h.id + s.id) % 10;
      const past = h.due < todayIso;
      const status: Submission["status"] = past ? (r < 5 ? "reviewed" : r < 8 ? "submitted" : "pending") : r < 3 ? "submitted" : "pending";
      const sub: Submission = { id: `sub-${h.id}-${s.id}`, hwId: h.id, studentId: s.id, status, history: [] };
      if (status !== "pending") {
        sub.submittedAt = dt(Math.max(1, -(diffRel(h.due)) + 1), 17, 20);
        sub.file = { name: `${s.name.split(" ")[0]}_${h.subject}.pdf`, size: 300000 + r * 41000, type: "application/pdf" };
        sub.history.push({ at: sub.submittedAt, text: "Submitted (demo upload)" });
      }
      if (status === "reviewed") {
        sub.marks = Math.round(h.max * (0.62 + (r % 4) * 0.09));
        sub.feedback = "Good effort. Keep writing the intermediate steps clearly.";
        sub.history.push({ at: dt(1, 11), text: "Reviewed by teacher" });
      }
      submissions.push(sub);
    });
  });
  const setSub = (id: string, patch: Partial<Submission>) => {
    const s = submissions.find((x) => x.id === id);
    if (s) Object.assign(s, patch);
  };
  setSub("sub-h1-s1", { status: "pending", submittedAt: undefined, file: undefined, history: [] });
  setSub("sub-h2-s1", { status: "returned", submittedAt: dt(1, 18), file: { name: "Aarav_Lab_Report.pdf", size: 612000, type: "application/pdf" }, feedback: "Please add the observation table and resubmit.", history: [{ at: dt(1, 18), text: "Submitted (demo upload)" }, { at: dt(0, 9), text: "Returned for correction" }] });
  setSub("sub-h3-s1", { status: "pending", submittedAt: undefined, file: undefined, history: [] });
  setSub("sub-h4-s1", { status: "reviewed", marks: 18, feedback: "Excellent work, Aarav. Accurate use of identities.", submittedAt: dt(6, 16), file: { name: "Aarav_Trig_Set.pdf", size: 402000, type: "application/pdf" }, history: [{ at: dt(6, 16), text: "Submitted (demo upload)" }, { at: dt(5, 12), text: "Reviewed by teacher" }] });
  setSub("sub-h5-s2", { status: "submitted", submittedAt: dt(0, 8), file: { name: "Ananya_Identities.pdf", size: 355000, type: "application/pdf" }, history: [{ at: dt(0, 8), text: "Submitted (demo upload)" }] });

  // Exams and marks
  const exMk = (id: string, name: string, subject: string, batchId: string, dayOff: number, max: number, status: Exam["status"], syllabus: string): Exam => ({
    id, inst: batches.find((b) => b.id === batchId)!.inst, name, subject, batchId, date: addDays(dayOff), time: "10:00", duration: 90, max, status, syllabus,
    instructions: "Carry your ID card, blue/black pens and a geometry box. Mobile phones are not allowed inside the exam room.",
  });
  const exams: Exam[] = [
    exMk("x1", "Maths Unit Test 2", "Mathematics", "b1", -10, 40, "published", "Quadratic Equations, Arithmetic Progressions"),
    exMk("x2", "Science Mid-term", "Science", "b1", -3, 50, "completed", "Chemical Reactions, Light, Electricity"),
    exMk("x3", "English Reading & Grammar Test", "English", "b1", 6, 30, "scheduled", "Unseen passage, Tenses, Letter writing"),
    exMk("x4", "Maths Weekly Test", "Mathematics", "b2", -6, 25, "published", "Algebraic expressions, Identities"),
    exMk("x5", "Physics Unit Test 1", "Physics", "b3", 9, 50, "draft", "Kinematics, Laws of motion"),
    exMk("x6", "Science Practical Assessment", "Science", "b1", 12, 25, "scheduled", "Refraction, Reflection experiments"),
    exMk("x7", "Maths Unit Test 1", "Mathematics", "b1", -42, 40, "published", "Real numbers, Polynomials"),
    exMk("x8", "Science Unit Test 1", "Science", "b1", -35, 30, "published", "Acids, Bases and Salts"),
    exMk("x9", "English Unit Test 1", "English", "b1", -28, 30, "published", "Prose, Grammar basics"),
    exMk("x10", "Science Term Test", "Science", "b4", -8, 40, "published", "Motion, Force"),
  ];
  const marks: Record<string, number> = {};
  exams.forEach((x) => {
    if (x.status === "scheduled" || x.status === "draft") return;
    students.filter((s) => s.batchId === x.batchId).forEach((s, i) => {
      if (x.id === "x2" && (i === 2 || i === 5)) return;
      const base = 0.5 + (hash(x.id + s.id) % 45) / 100;
      marks[`${x.id}|${s.id}`] = Math.round(x.max * Math.min(base, 0.98));
    });
  });
  marks["x1|s1"] = 34; marks["x7|s1"] = 29; marks["x8|s1"] = 24; marks["x9|s1"] = 26; marks["x2|s1"] = 41; marks["x4|s2"] = 21;

  // Fees
  const fsMk = (id: string, inst: string, name: string, course: string, n: number, each: number, offs: number[]): FeeStructure => ({
    id, inst, name, course, total: n * each, installments: offs.map((o, i) => ({ label: `Instalment ${i + 1}`, amount: each, due: addDays(o) })),
  });
  const feeStructures: FeeStructure[] = [
    fsMk("fs1", "i1", "Class 10 Annual – Science", "SSC Board Foundation", 4, 12000, [-75, -15, 30, 90]),
    fsMk("fs2", "i1", "Class 8 Annual", "Middle School Excellence", 3, 12000, [-60, 5, 65]),
    fsMk("fs3", "i1", "JEE Foundation Annual", "JEE Foundation", 4, 18000, [-70, -10, 40, 100]),
    fsMk("fs4", "i2", "Class 9 Science Annual", "Science Stream", 2, 15000, [-30, 45]),
  ];
  const feeAccounts: FeeAccount[] = [];
  const payments: Payment[] = [];
  let rc = 0;
  students.forEach((s) => {
    const fs = feeStructures.find((f) => (s.batchId === "b1" ? f.id === "fs1" : s.batchId === "b2" ? f.id === "fs2" : s.batchId === "b3" ? f.id === "fs3" : f.id === "fs4"))!;
    const disc = s.id === "s1" || s.id === "s2" ? 2000 : s.id === "s3" ? 3000 : 0;
    feeAccounts.push({ id: `fa-${s.id}`, inst: s.inst, studentId: s.id, structureId: fs.id, discount: disc, discountReason: s.id === "s3" ? "Merit scholarship" : disc ? "Sibling discount" : "" });
    const paidN = s.id === "s1" ? 2 : s.id === "s2" ? 1 : hash(s.id) % (fs.installments.length);
    for (let i = 0; i < paidN; i++) {
      rc++;
      const methods: Payment["method"][] = ["Cash", "UPI (demo)", "Cheque", "Bank Transfer (demo)"];
      payments.push({
        id: `p${rc}`, inst: s.inst, studentId: s.id, amount: fs.installments[i].amount - (i === 0 ? disc : 0), date: addDays(fs.installments[i].due.length ? -(fs.installments.length - i) * 12 - 3 : 0),
        method: methods[(hash(s.id) + i) % 4], ref: `DEMO-${10400 + rc * 7}`, receipt: `GF-DEMO-${String(rc).padStart(4, "0")}`, status: "received", demo: true,
      });
    }
  });

  // Notices
  const nMk = (id: string, title: string, body: string, category: Notice["category"], type: Notice["audience"]["type"], batchIds: string[], ago: number, status: Notice["status"] = "published", by = "Dr. Anil Joshi"): Notice => ({
    id, inst: "i1", title, body, category, audience: { type, batchIds }, status, publishAt: status === "scheduled" ? dt(-2, 9) : dt(ago, 9), expiry: addDays(30), readBy: [], by,
  });
  const notices: Notice[] = [
    nMk("n1", "Diwali break: institute closed", "Classes will remain closed from Thursday to Sunday for the Diwali break. Regular batches resume on Monday. Wishing every family a safe and bright festival.", "Holiday", "all", [], 1),
    nMk("n2", "Science Mid-term results — review window", "Class 10 Science mid-term answer sheets will be discussed in class. Parents may request a re-check within 3 days.", "Exam", "batches", ["b1"], 2),
    nMk("n3", "Fee instalment reminder", "The next instalment is due soon. Please check the Fees section for the exact amount and due date. Demo records only in this prototype.", "Fee", "parents", [], 3),
    nMk("n4", "Staff meeting: Friday 4:30 PM", "All teachers to attend the monthly academic review. Bring batch progress notes.", "General", "teachers", [], 2),
    nMk("n5", "Parent–Teacher Meeting for Class 8", "PTM is scheduled on Saturday between 10:00 AM and 1:00 PM. Please book a slot through the app.", "Academic", "batches", ["b2"], 4),
    nMk("n6", "Weekend revision camp (scheduled)", "A free revision camp for Class 10 will be held next Saturday. This notice is scheduled for publishing.", "Academic", "batches", ["b1"], 0, "scheduled"),
    nMk("n7", "New resource library is live", "Chapter-wise PDFs and notes are now available in the Learning Library for all batches.", "General", "students", [], 5),
  ];
  notices[2].attachment = { name: "Fee_Schedule.pdf", size: 210000, type: "application/pdf" };

  // Resources
  const rs = (id: string, title: string, type: Resource["type"], subject: string, chapter: string, folder: string, batchIds: string[], size: number, by: string, ago: number, url?: string): Resource => ({
    id, inst: batches.find((b) => b.id === batchIds[0])?.inst ?? "i1", title, type, subject, chapter, folder, batchIds, size, by, at: dt(ago), url, bookmarked: false,
  });
  const resources: Resource[] = [
    rs("rs1", "Quadratic Equations — Formula Sheet", "pdf", "Mathematics", "Quadratic Equations", "Mathematics", ["b1"], 840000, "Priya Deshmukh", 4),
    rs("rs2", "Trigonometry Identities Cheat Sheet", "pdf", "Mathematics", "Trigonometry", "Mathematics", ["b1"], 560000, "Priya Deshmukh", 9),
    rs("rs3", "Light — Ray Diagrams (Class Notes)", "doc", "Science", "Light", "Science", ["b1"], 1250000, "Rahul Iyer", 6),
    rs("rs4", "Refraction Experiment Setup", "image", "Science", "Light", "Science", ["b1"], 940000, "Rahul Iyer", 5),
    rs("rs5", "Chemical Reactions — Practice Questions", "pdf", "Science", "Chemical Reactions", "Science", ["b1"], 720000, "Rahul Iyer", 12),
    rs("rs6", "Grammar: Tenses Worksheet", "pdf", "English", "Grammar Essentials", "English", ["b1", "b2"], 390000, "Farah Khan", 7),
    rs("rs7", "NCERT Textbook Portal (external)", "link", "Science", "General", "Reference Links", ["b1", "b2"], 0, "Rahul Iyer", 14, "https://ncert.nic.in/textbook.php"),
    rs("rs8", "Algebraic Identities Notes", "doc", "Mathematics", "Algebra", "Mathematics", ["b2"], 460000, "Priya Deshmukh", 3),
    rs("rs9", "Kinematics Formula Booklet", "pdf", "Physics", "Kinematics", "Physics", ["b3"], 1100000, "Rahul Iyer", 8),
    rs("rs10", "Map Skills — India Political", "image", "Social Science", "Geography", "Social Science", ["b2"], 1800000, "Meera Kulkarni", 10),
  ];
  resources[0].bookmarked = true; resources[0].recent = true; resources[2].recent = true;

  // Doubts
  const doubts: Doubt[] = [
    { id: "d1", inst: "i1", studentId: "s1", subject: "Mathematics", teacherId: "st1", batchId: "b1", status: "answered", title: "Why does the discriminant decide the nature of roots?", hasImage: false, messages: [{ from: "student", text: "Ma'am, I understand the formula but not why a negative discriminant means no real roots.", at: dt(2, 18) }, { from: "teacher", text: "Because the square root of a negative number is not real. Try plotting y = x² + 1 — it never touches the x-axis. See Formula Sheet page 2.", at: dt(1, 10) }] },
    { id: "d2", inst: "i1", studentId: "s3", subject: "Science", teacherId: "st2", batchId: "b1", status: "open", title: "Image formed by a concave mirror at 2F", hasImage: true, messages: [{ from: "student", text: "Sir, please check my ray diagram. Is the image real and same size?", at: dt(0, 8) }] },
    { id: "d3", inst: "i1", studentId: "s4", subject: "Mathematics", teacherId: "st1", batchId: "b1", status: "open", title: "Step 3 of Q7 in worksheet", hasImage: false, messages: [{ from: "student", text: "How did we get (x − 3) as a factor in Q7?", at: dt(0, 7) }] },
    { id: "d4", inst: "i1", studentId: "s9", subject: "English", teacherId: "st3", batchId: "b2", status: "resolved", title: "Past perfect vs simple past", hasImage: false, messages: [{ from: "student", text: "When do we use had + verb?", at: dt(5, 17) }, { from: "teacher", text: "Use it for the earlier of two past actions.", at: dt(4, 9) }] },
  ];

  const leaves: LeaveRequest[] = [
    { id: "lv1", inst: "i1", kind: "staff", personId: "st1", from: addDays(-20), to: addDays(-19), reason: "Family function", status: "approved", at: dt(25), by: "Priya Deshmukh", substitute: "Farah Khan" },
    { id: "lv2", inst: "i1", kind: "staff", personId: "st1", from: addDays(10), to: addDays(11), reason: "Medical appointment", status: "pending", at: dt(1), by: "Priya Deshmukh" },
    { id: "lv3", inst: "i1", kind: "student", personId: "s1", from: addDays(-14), to: addDays(-13), reason: "Fever", status: "approved", at: dt(15), by: "Rajesh Sharma" },
    { id: "lv4", inst: "i1", kind: "student", personId: "s2", from: addDays(4), to: addDays(4), reason: "Family wedding", status: "pending", at: dt(0, 8), by: "Rajesh Sharma" },
    { id: "lv5", inst: "i1", kind: "staff", personId: "st4", from: addDays(-2), to: addDays(3), reason: "Health recovery", status: "approved", at: dt(5), by: "Suresh Patil", substitute: "Rahul Iyer" },
  ];
  const meetings: MeetingRequest[] = [
    { id: "m1", inst: "i1", studentId: "s2", teacherId: "st1", date: addDays(3), time: "11:00", reason: "Discuss weekly test performance", status: "pending", at: dt(1) },
  ];

  const nt = (id: string, roles: AppNotification["roles"], cat: AppNotification["cat"], title: string, body: string, ago: number, dest: AppNotification["dest"], studentId?: string, h = 9): AppNotification => ({ id, inst: "i1", roles, cat, title, body, at: dt(ago, h), dest, studentId, readRoles: [] });
  const notifications: AppNotification[] = [
    nt("nf1", ["owner"], "fee", "Instalment overdue for 4 students", "Total overdue ₹60,000. Review the ledger.", 0, { name: "S35" }, undefined, 8),
    nt("nf2", ["owner"], "general", "2 new enquiries today", "Meghna Kale and Rishi Bansal enquired about Class 10 and JEE.", 0, { name: "S18" }, undefined, 9),
    nt("nf3", ["owner"], "general", "Leave request from Priya Deshmukh", "Medical appointment · 2 days. Awaiting approval.", 1, { name: "S26", params: { id: "st1" } }),
    nt("nf4", ["teacher"], "homework", "New doubt from Ishita Verma", "Science · Image formed by a concave mirror at 2F.", 0, { name: "S53", params: { id: "d2" } }, undefined, 8),
    nt("nf5", ["teacher"], "attendance", "Attendance pending: Class 10 – Science", "Mark today's attendance to keep parents informed.", 0, { name: "S46", params: { batchId: "b1" } }, undefined, 9),
    nt("nf6", ["teacher"], "homework", "Homework submitted: Ananya Sharma", "Algebraic Identities Drill is ready for review.", 0, { name: "S49", params: { id: "sub-h5-s2" } }, undefined, 8),
    nt("nf7", ["student"], "homework", "Homework due in 2 days", "Quadratic Equations Worksheet 4 — Mathematics.", 0, { name: "S60", params: { id: "h1" } }, "s1", 7),
    nt("nf8", ["student"], "homework", "Homework returned for correction", "Light: Refraction Lab Report needs an observation table.", 0, { name: "S61", params: { id: "h2" } }, "s1", 9),
    nt("nf9", ["student"], "exam", "Test scheduled: English Reading & Grammar", "Check syllabus and instructions.", 1, { name: "S62" }, "s1"),
    nt("nf10", ["parent"], "attendance", "Aarav was marked absent yesterday", "Marked by class teacher. You can view the attendance calendar.", 1, { name: "S73" }, "s1", 12),
    nt("nf11", ["parent"], "fee", "Instalment due in 5 days for Ananya", "Instalment 2 of ₹12,000. Demo records only.", 0, { name: "S77" }, "s2", 8),
    nt("nf12", ["parent"], "exam", "Result published: Maths Unit Test 2 (Aarav)", "Aarav scored 34/40.", 9, { name: "S74" }, "s1"),
    nt("nf13", ["parent", "student", "teacher", "owner"], "notice", "Diwali break: institute closed", "Tap to read the full notice.", 1, { name: "S79", params: { id: "n1" } }, undefined, 10),
  ];

  const tasks: PlannerTask[] = [
    { id: "pt1", studentId: "s1", title: "Revise Quadratic Equations formulae", kind: "revision", due: addDays(1), done: false, subject: "Mathematics" },
    { id: "pt2", studentId: "s1", title: "Finish refraction lab report", kind: "task", due: addDays(2), done: false, subject: "Science" },
    { id: "pt3", studentId: "s1", title: "Score 80%+ in the English test", kind: "goal", due: addDays(6), done: false, subject: "English" },
    { id: "pt4", studentId: "s1", title: "Solve 10 trigonometry MCQs", kind: "task", due: addDays(0), done: true, subject: "Mathematics" },
    { id: "pt5", studentId: "s1", title: "Read Chapter 3 summary", kind: "revision", due: addDays(3), done: false, subject: "English" },
  ];
  const attempts: Attempt[] = [
    { id: "at1", studentId: "s1", subject: "Mathematics", chapter: "Trigonometry", topic: "Ratios", score: 3, total: 3, at: dt(3), wrong: [] },
    { id: "at2", studentId: "s1", subject: "Science", chapter: "Light", topic: "Refraction", score: 1, total: 2, at: dt(2), wrong: ["q20"] },
  ];

  const ac = (id: string, text: string, ago: number, kind: string, inst = "i1", h = 10): ActivityItem => ({ id, inst, text, at: dt(ago, h), kind });
  const activity: ActivityItem[] = [
    ac("ac1", "Attendance marked for Class 12 – PCM by Suresh Patil", 0, "attendance", "i1", 9),
    ac("ac2", "Homework submitted by Ananya Sharma", 0, "homework", "i1", 8),
    ac("ac3", "New enquiry: Meghna Kale (Class 10)", 0, "admission", "i1", 9),
    ac("ac4", "Notice published: Diwali break", 1, "notice"),
    ac("ac5", "Payment received (demo) from Vihaan Reddy", 1, "fee"),
    ac("ac6", "Results published: Maths Unit Test 2", 9, "exam"),
  ];
  const audit: ActivityItem[] = [
    ac("au1", "Dr. Anil Joshi updated academic session settings", 6, "settings"),
    ac("au2", "Permission changed: Teacher · Publish results = Off", 14, "permissions"),
    ac("au3", "Demo data export previewed", 20, "export"),
  ];

  const p = (...v: boolean[]) => ({ "fees.view": v[0], "fees.record": v[1], "students.edit": v[2], "attendance.edit": v[3], "results.publish": v[4], "notices.publish": v[5], "staff.manage": v[6], "reports.view": v[7] });
  const permissions: PermMatrix = {
    owner: p(true, true, true, true, true, true, true, true),
    teacher: p(false, false, false, true, false, false, false, false),
    student: p(false, false, false, false, false, false, false, false),
    parent: p(false, false, false, false, false, false, false, false),
  };

  return {
    institutes: [
      { id: "i1", name: "Aarohan Learning Institute", city: "Pune", state: "Maharashtra", type: "Coaching Centre", code: "AARO-2026", invite: "AARO-JOIN" },
      { id: "i2", name: "Saraswati Science Academy", city: "Nagpur", state: "Maharashtra", type: "Tuition Organisation", code: "SARA-5521", invite: "SARA-JOIN" },
      { id: "i3", name: "Gyan Setu Tutorials", city: "Jaipur", state: "Rajasthan", type: "Coaching Centre", code: "GYAN-7710", invite: "GYAN-JOIN" },
    ],
    memberships: [
      { id: "i1", instId: "i1", roles: ["owner", "teacher", "student", "parent"], status: "active" },
      { id: "i2", instId: "i2", roles: ["teacher"], status: "active" },
      { id: "i3", instId: "i3", roles: ["student"], status: "pending" },
    ],
    subjects: [["Mathematics","MAT"],["Science","SCI"],["English","ENG"],["Social Science","SST"],["Physics","PHY"],["Chemistry","CHE"]].map(([name, code], i) => ({ id: `sb${i + 1}`, inst: "i1", name, code })).concat([["Science","SCI"],["Mathematics","MAT"],["English","ENG"]].map(([name, code], i) => ({ id: `sb${i + 20}`, inst: "i2", name, code }))),
    rooms, sessions, batches, students, guardians, staff, enquiries, timetable, homework, submissions, exams, feeStructures, feeAccounts,
    payments, notices, resources, doubts, leaves, meetings, notifications, tasks, attempts, activity, diary: [
      { id: "dy1", inst: "i1", batchId: "b1", subject: "Mathematics", date: addDays(-2), topic: "Nature of roots", notes: "Discussed discriminant and worked through 6 examples. Homework: worksheet 4.", by: "Priya Deshmukh" },
      { id: "dy2", inst: "i1", batchId: "b2", subject: "Mathematics", date: addDays(-1), topic: "Algebraic identities", notes: "Covered (a+b)² and (a−b)². Students struggled with negative terms — revise tomorrow.", by: "Priya Deshmukh" },
    ], attLog: [
      { id: "al1", inst: "i1", date: addDays(-3), studentId: "s6", from: "A", to: "L", by: "Priya Deshmukh", at: dt(3, 14), reason: "Arrived after roll call" },
    ], audit, attendance, marks, permissions,
  };
}

function diffRel(dueIso: string) {
  return Math.round((new Date(dueIso).getTime() - new Date(iso(new Date())).getTime()) / 86400000);
}
