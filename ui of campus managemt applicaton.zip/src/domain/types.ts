// Domain model shared by every role. All dates are ISO "YYYY-MM-DD", date-times are full ISO strings.
export type Role = "owner" | "teacher" | "student" | "parent";
export type AttStatus = "P" | "A" | "L";

export interface Institute { id: string; name: string; city: string; state: string; type: string; code: string; invite: string }
export interface Membership { id: string; instId: string; roles: Role[]; status: "active" | "pending" }
export interface Subject { id: string; inst: string; name: string; code: string }
export interface Room { id: string; inst: string; name: string; capacity: number; kind: string }
export interface AcademicSession { id: string; inst: string; label: string; start: string; end: string; active: boolean }
export interface Batch {
  id: string; inst: string; name: string; course: string; session: string;
  subjectTeachers: Record<string, string>; roomId: string; status: "active" | "inactive";
}
export interface Student {
  id: string; inst: string; name: string; sid: string; batchId: string; dob: string; phone: string;
  address: string; admDate: string; status: "active" | "inactive" | "alumni"; session: string; subjects: string[];
}
export interface Guardian {
  id: string; inst: string; studentId: string; name: string; relation: string; phone: string;
  status: "verified" | "invited" | "pending"; consent: boolean; linked: boolean; invitedAt?: string;
}
export interface Staff {
  id: string; inst: string; name: string; role: string; subjects: string[]; batchIds: string[];
  status: "active" | "on-leave" | "inactive"; phone: string; email: string; joined: string; weeklyHours: number;
}
export type EnquiryStatus = "New" | "Contacted" | "Demo Scheduled" | "Follow-up" | "Converted" | "Lost";
export interface Enquiry {
  id: string; inst: string; student: string; guardian: string; phone: string; course: string; source: string;
  status: EnquiryStatus; notes: string; followUp?: string; demoDate?: string; createdAt: string;
  timeline: { at: string; text: string }[];
}
export interface TimetableEntry { id: string; inst: string; batchId: string; subject: string; teacherId: string; roomId: string; day: number; start: string; end: string }
export interface FileMeta { name: string; size: number; type: string }
export interface Homework {
  id: string; inst: string; title: string; subject: string; batchId: string; teacherId: string; instructions: string;
  due: string; max: number; status: "published" | "draft"; attachment?: FileMeta; createdAt: string;
}
export interface Submission {
  id: string; hwId: string; studentId: string; status: "pending" | "submitted" | "reviewed" | "returned";
  text?: string; file?: FileMeta; submittedAt?: string; feedback?: string; marks?: number;
  history: { at: string; text: string }[];
}
export interface Exam {
  id: string; inst: string; name: string; subject: string; batchId: string; date: string; time: string; duration: number;
  max: number; status: "draft" | "scheduled" | "completed" | "published"; syllabus: string; instructions: string;
}
export interface FeeStructure { id: string; inst: string; name: string; course: string; total: number; installments: { label: string; amount: number; due: string }[] }
export interface FeeAccount { id: string; inst: string; studentId: string; structureId: string; discount: number; discountReason: string }
export interface Payment {
  id: string; inst: string; studentId: string; amount: number; date: string; method: "Cash" | "UPI (demo)" | "Cheque" | "Bank Transfer (demo)";
  ref: string; receipt: string; status: "received" | "refund-requested" | "refunded"; note?: string; demo: true;
}
export interface Notice {
  id: string; inst: string; title: string; body: string; category: "Academic" | "Holiday" | "Exam" | "Fee" | "General";
  audience: { type: "all" | "students" | "teachers" | "parents" | "batches"; batchIds: string[] };
  status: "published" | "scheduled" | "archived"; publishAt: string; expiry?: string; attachment?: FileMeta; readBy: Role[]; by: string;
}
export interface Resource {
  id: string; inst: string; title: string; type: "pdf" | "doc" | "image" | "link"; subject: string; chapter: string;
  folder: string; batchIds: string[]; size: number; by: string; at: string; url?: string; bookmarked: boolean; recent?: boolean;
}
export interface DoubtMsg { from: "student" | "teacher"; text: string; at: string }
export interface Doubt {
  id: string; inst: string; studentId: string; subject: string; teacherId: string; batchId: string; status: "open" | "answered" | "resolved";
  title: string; hasImage: boolean; messages: DoubtMsg[];
}
export interface LeaveRequest {
  id: string; inst: string; kind: "staff" | "student"; personId: string; from: string; to: string; reason: string;
  status: "pending" | "approved" | "rejected"; at: string; by: string; substitute?: string;
}
export interface MeetingRequest {
  id: string; inst: string; studentId: string; teacherId: string; date: string; time: string; reason: string;
  status: "pending" | "accepted" | "declined"; at: string;
}
export interface AppNotification {
  id: string; inst: string; roles: Role[]; studentId?: string; batchId?: string; title: string; body: string;
  cat: "attendance" | "homework" | "exam" | "fee" | "notice" | "general"; at: string;
  dest: { name: string; params?: Record<string, unknown> }; readRoles: Role[];
}
export interface PlannerTask { id: string; studentId: string; title: string; kind: "task" | "goal" | "revision"; due: string; done: boolean; subject?: string }
export interface Attempt { id: string; studentId: string; subject: string; chapter: string; topic: string; score: number; total: number; at: string; wrong: string[] }
export interface ActivityItem { id: string; inst: string; text: string; at: string; kind: string }
export interface AttCorrection { id: string; inst: string; date: string; studentId: string; from: AttStatus | "-"; to: AttStatus; by: string; at: string; reason: string }
export interface ClassDiary { id: string; inst: string; batchId: string; subject: string; date: string; topic: string; notes: string; by: string }
export interface Question { id: string; subject: string; chapter: string; topic: string; q: string; options: string[]; answer: number; explanation: string }

export type Perm = "fees.view" | "fees.record" | "students.edit" | "attendance.edit" | "results.publish" | "notices.publish" | "staff.manage" | "reports.view";
export type PermMatrix = Record<Role, Record<Perm, boolean>>;

export interface DB {
  institutes: Institute[]; memberships: Membership[]; subjects: Subject[]; rooms: Room[]; sessions: AcademicSession[]; batches: Batch[];
  students: Student[]; guardians: Guardian[]; staff: Staff[]; enquiries: Enquiry[]; timetable: TimetableEntry[];
  homework: Homework[]; submissions: Submission[]; exams: Exam[]; feeStructures: FeeStructure[]; feeAccounts: FeeAccount[];
  payments: Payment[]; notices: Notice[]; resources: Resource[]; doubts: Doubt[]; leaves: LeaveRequest[];
  meetings: MeetingRequest[]; notifications: AppNotification[]; tasks: PlannerTask[]; attempts: Attempt[];
  diary: ClassDiary[]; activity: ActivityItem[]; attLog: AttCorrection[]; audit: ActivityItem[];
  attendance: Record<string, AttStatus>;
  marks: Record<string, number>;
  permissions: PermMatrix;
}
export type CollectionKey = { [K in keyof DB]: DB[K] extends { id: string }[] ? K : never }[keyof DB];
export type Item<K extends CollectionKey> = DB[K] extends (infer U)[] ? U : never;
