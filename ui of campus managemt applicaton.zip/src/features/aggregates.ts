import { addDays, iso, MONTHS, pct, today } from "@/lib/fmt";
import { batchAttOn, feeSummary, instAttToday, resultsFor, Scope, studentAtt } from "./selectors";

export function instFees(sc: Scope) {
  let expected = 0, collected = 0, overdue = 0, overdueCount = 0;
  sc.students.filter((s) => s.status === "active").forEach((s) => {
    const f = feeSummary(sc.db, s.id);
    if (!f) return;
    expected += f.total; collected += f.paid; overdue += f.overdue; if (f.overdue > 0) overdueCount++;
  });
  return { expected, collected, outstanding: Math.max(expected - collected, 0), overdue, overdueCount, rate: pct(collected, expected) };
}
export function monthlyCollection(sc: Scope, months = 4) {
  const out: { label: string; value: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(); d.setMonth(d.getMonth() - i, 1);
    const key = iso(d).slice(0, 7);
    const sum = sc.payments.filter((p) => p.status !== "refunded" && p.date.startsWith(key)).reduce((a, p) => a + p.amount, 0);
    out.push({ label: MONTHS[d.getMonth()], value: Math.round(sum / 1000) });
  }
  return out;
}
export function attendanceTrend(sc: Scope, days = 7) {
  const labels: string[] = [], points: number[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const date = addDays(-i);
    const d = new Date(date + "T00:00:00");
    const r = instAttToday(sc, date);
    if (r.marked === 0) continue;
    labels.push(["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"][d.getDay()]); points.push(r.pct);
  }
  return { labels, points };
}
export function batchPerformance(sc: Scope) {
  return sc.batches.map((b) => {
    const ss = sc.students.filter((s) => s.batchId === b.id && s.status === "active");
    const vals = ss.flatMap((s) => resultsFor(sc.db, s.id).map((r) => r.pct));
    const att = ss.map((s) => studentAtt(sc.db, s.id).pct).filter((x) => x > 0);
    return { batch: b, students: ss.length, examAvg: vals.length ? Math.round(vals.reduce((a, c) => a + c, 0) / vals.length) : 0, attAvg: att.length ? Math.round(att.reduce((a, c) => a + c, 0) / att.length) : 0 };
  });
}
export const pendingAttendanceBatches = (sc: Scope, date = today()) => sc.batches.filter((b) => b.status === "active").filter((b) => batchAttOn(sc.db, b.id, date).marked < batchAttOn(sc.db, b.id, date).total);
