import type { AppNotification, AttStatus, DB, Exam, Homework, Notice, Perm, Role, TimetableEntry } from "@/domain/types";
import { addDays, iso, parse, pct, today } from "@/lib/fmt";

export const HOME: Record<Role, string> = { owner: "S16", teacher: "S42", student: "S56", parent: "S72" };
export const ROLE_LABEL: Record<Role, string> = { owner: "Owner / Admin", teacher: "Teacher", student: "Student", parent: "Parent / Guardian" };
export const TEACHER_ID: Record<string, string> = { i1: "st1", i2: "st6" };
export const STUDENT_ID = "s1";
export const OWNER_NAME = "Dr. Anil Joshi";
export const PERMS: { key: Perm; label: string }[] = [
  { key: "fees.view", label: "View fee records" },
  { key: "fees.record", label: "Record payments & adjustments" },
  { key: "students.edit", label: "Add / edit students" },
  { key: "attendance.edit", label: "Mark & correct attendance" },
  { key: "results.publish", label: "Publish exam results" },
  { key: "notices.publish", label: "Publish notices" },
  { key: "staff.manage", label: "Manage staff & members" },
  { key: "reports.view", label: "View institute reports" },
];

/** UI-level permission check. NOTE: prototype only — production security must be enforced by backend/RLS policies. */
export const can = (db: DB, role: Role, perm: Perm) => !!db.permissions[role]?.[perm];

export function scopeOf(db: DB, instId: string) {
  const f = <T extends { inst: string }>(a: T[]) => a.filter((x) => x.inst === instId);
  const homework = f(db.homework);
  const hwIds = new Set(homework.map((h) => h.id));
  return {
    db, instId,
    inst: db.institutes.find((i) => i.id === instId) ?? db.institutes[0],
    students: f(db.students), batches: f(db.batches), staff: f(db.staff), guardians: f(db.guardians), enquiries: f(db.enquiries),
    timetable: f(db.timetable), homework, submissions: db.submissions.filter((s) => hwIds.has(s.hwId)), exams: f(db.exams),
    feeStructures: f(db.feeStructures), feeAccounts: f(db.feeAccounts), payments: f(db.payments), notices: f(db.notices),
    resources: f(db.resources), doubts: f(db.doubts), leaves: f(db.leaves), meetings: f(db.meetings), rooms: f(db.rooms),
    sessions: f(db.sessions), subjects: f(db.subjects), activity: f(db.activity), diary: f(db.diary), audit: f(db.audit), attLog: f(db.attLog),
  };
}
export type Scope = ReturnType<typeof scopeOf>;

export const parentChildren = (db: DB, instId: string) => {
  const ids = db.guardians.filter((g) => g.inst === instId && g.linked && g.status === "verified" && g.consent).map((g) => g.studentId);
  return db.students.filter((s) => ids.includes(s.id));
};
export const lockedChildren = (db: DB, instId: string) => {
  const ids = db.guardians.filter((g) => g.inst === instId && g.linked && !(g.status === "verified" && g.consent)).map((g) => g.studentId);
  return db.students.filter((s) => ids.includes(s.id));
};

export function studentAtt(db: DB, studentId: string, from?: string, to?: string) {
  const byDate: Record<string, AttStatus> = {};
  let p = 0, a = 0, l = 0;
  for (const k in db.attendance) {
    const [d, sid] = k.split("|");
    if (sid !== studentId) continue;
    if ((from && d < from) || (to && d > to)) continue;
    const v = db.attendance[k];
    byDate[d] = v;
    if (v === "P") p++;
    else if (v === "A") a++;
    else l++;
  }
  const total = p + a + l;
  return { byDate, p, a, l, total, pct: pct(p + l, total) };
}

export function batchAttOn(db: DB, batchId: string, date: string) {
  const ss = db.students.filter((s) => s.batchId === batchId && s.status === "active");
  const rec: Record<string, AttStatus | undefined> = {};
  let marked = 0, p = 0, a = 0, l = 0;
  ss.forEach((s) => {
    const v = db.attendance[`${date}|${s.id}`];
    rec[s.id] = v;
    if (v) { marked++; if (v === "P") p++; else if (v === "A") a++; else l++; }
  });
  return { students: ss, rec, marked, p, a, l, total: ss.length };
}

export function instAttToday(sc: Scope, date = today()) {
  let marked = 0, present = 0, total = 0;
  sc.batches.forEach((b) => { const r = batchAttOn(sc.db, b.id, date); marked += r.marked; present += r.p + r.l; total += r.total; });
  return { marked, present, total, pct: pct(present, marked) };
}

export function resultsFor(db: DB, studentId: string) {
  const st = db.students.find((s) => s.id === studentId);
  if (!st) return [];
  return db.exams
    .filter((x) => x.batchId === st.batchId && x.status === "published" && db.marks[`${x.id}|${studentId}`] !== undefined)
    .map((x) => { const m = db.marks[`${x.id}|${studentId}`]; return { exam: x, marks: m, pct: pct(m, x.max) }; })
    .sort((a, b) => (a.exam.date < b.exam.date ? 1 : -1));
}

export function examStats(db: DB, exam: Exam) {
  const ss = db.students.filter((s) => s.batchId === exam.batchId && s.status === "active");
  const vals = ss.map((s) => db.marks[`${exam.id}|${s.id}`]).filter((v) => v !== undefined) as number[];
  const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  return { total: ss.length, entered: vals.length, missing: ss.length - vals.length, avg: Math.round(avg * 10) / 10, avgPct: pct(avg, exam.max), high: vals.length ? Math.max(...vals) : 0, low: vals.length ? Math.min(...vals) : 0 };
}

export function feeSummary(db: DB, studentId: string) {
  const acc = db.feeAccounts.find((a) => a.studentId === studentId);
  if (!acc) return null;
  const fs = db.feeStructures.find((f) => f.id === acc.structureId);
  if (!fs) return null;
  const pays = db.payments.filter((p) => p.studentId === studentId && p.status !== "refunded");
  const paid = pays.reduce((s, p) => s + p.amount, 0);
  let rem = acc.discount;
  const net = fs.installments.map((i) => ({ ...i }));
  for (let i = net.length - 1; i >= 0 && rem > 0; i--) { const t = Math.min(rem, net[i].amount); net[i].amount -= t; rem -= t; }
  let left = paid;
  const t0 = today();
  const installments = net.map((i) => {
    const got = Math.min(left, i.amount);
    left -= got;
    const status: "paid" | "partial" | "due" | "overdue" = got >= i.amount ? "paid" : i.due < t0 ? "overdue" : got > 0 ? "partial" : "due";
    return { ...i, paid: got, status: got > 0 && got < i.amount && i.due < t0 ? "overdue" as const : status };
  });
  const total = fs.total - acc.discount;
  const overdue = installments.filter((i) => i.status === "overdue").reduce((s, i) => s + (i.amount - i.paid), 0);
  const next = installments.find((i) => i.status !== "paid");
  return { acc, fs, total, paid, outstanding: Math.max(total - paid, 0), overdue, installments, next, payments: db.payments.filter((p) => p.studentId === studentId) };
}

export type SubStatus = "pending" | "submitted" | "reviewed" | "returned" | "overdue";
export function subFor(db: DB, hw: Homework, studentId: string) {
  const sub = db.submissions.find((s) => s.hwId === hw.id && s.studentId === studentId);
  const status: SubStatus = !sub ? (hw.due < today() ? "overdue" : "pending") : sub.status === "pending" && hw.due < today() ? "overdue" : sub.status;
  return { sub, status };
}
export function hwCounts(db: DB, hw: Homework) {
  const ss = db.students.filter((s) => s.batchId === hw.batchId && s.status === "active");
  let submitted = 0, reviewed = 0, returned = 0;
  ss.forEach((s) => { const x = db.submissions.find((q) => q.hwId === hw.id && q.studentId === s.id); if (x?.status === "submitted") submitted++; if (x?.status === "reviewed") reviewed++; if (x?.status === "returned") returned++; });
  return { total: ss.length, submitted, reviewed, returned, toReview: submitted, missing: ss.length - submitted - reviewed - returned };
}

export function noticeVisible(n: Notice, role: Role, batchIds: string[]) {
  if (role === "owner") return true;
  if (n.status !== "published") return false;
  const a = n.audience;
  if (a.type === "all") return true;
  if (a.type === "teachers") return role === "teacher";
  if (a.type === "parents") return role === "parent";
  if (a.type === "students") return role === "student";
  return a.batchIds.some((b) => batchIds.includes(b));
}

export function notificationVisible(n: AppNotification, role: Role, studentIds: string[], batchIds: string[], instId: string) {
  if (n.inst !== instId || !n.roles.includes(role)) return false;
  if ((role === "student" || role === "parent") && n.studentId && !studentIds.includes(n.studentId)) return false;
  if ((role === "student" || role === "parent") && n.batchId && !batchIds.includes(n.batchId)) return false;
  return true;
}

export const classStatus = (e: TimetableEntry, date = today()) => {
  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  if (date !== today()) return date < today() ? "Completed" : "Upcoming";
  return hhmm >= e.end ? "Completed" : hhmm >= e.start ? "Ongoing" : "Upcoming";
};
export const dayOf = (date: string) => parse(date).getDay();

const overlaps = (a: TimetableEntry, b: TimetableEntry) => a.day === b.day && a.start < b.end && b.start < a.end;
/** Conflict detection for timetable: teacher, room or batch double-booked. */
export function findConflict(db: DB, e: TimetableEntry) {
  const others = db.timetable.filter((x) => x.id !== e.id && overlaps(x, e));
  const t = others.find((x) => x.teacherId === e.teacherId);
  if (t) { const n = db.staff.find((s) => s.id === e.teacherId)?.name; return `${n} already teaches ${t.subject} to ${db.batches.find((b) => b.id === t.batchId)?.name} at this time.`; }
  const r = others.find((x) => x.roomId === e.roomId);
  if (r) return `${db.rooms.find((x) => x.id === e.roomId)?.name} is already booked for ${db.batches.find((b) => b.id === r.batchId)?.name}.`;
  const b = others.find((x) => x.batchId === e.batchId);
  if (b) return `This batch already has ${b.subject} scheduled at this time.`;
  return null;
}

export const lastDays = (n: number) => Array.from({ length: n }, (_, i) => addDays(-(n - 1 - i)));
export const monthKey = (d: Date) => iso(new Date(d.getFullYear(), d.getMonth(), 1)).slice(0, 7);

export const teacherBatches = (sc: Scope, teacherId?: string) => sc.batches.filter((b) => Object.values(b.subjectTeachers).includes(teacherId ?? ""));
export const teacherSubjects = (b: { subjectTeachers: Record<string, string> }, teacherId?: string) => Object.entries(b.subjectTeachers).filter(([, t]) => t === teacherId).map(([s]) => s);
