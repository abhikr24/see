import { getRepository } from "@/data/factory";
import type {
  AppNotification, AttStatus, CollectionKey, DoubtMsg, Enquiry, EnquiryStatus, FileMeta, Guardian, Homework, Item, LeaveRequest, MeetingRequest,
  Notice, Payment, PermMatrix, Resource, Role, Student, Submission,
} from "@/domain/types";
import { feeSummary } from "./selectors";
import { can } from "./selectors";
import { addDays, nowISO, today, uid, dmy } from "@/lib/fmt";

type NotifyIn = Omit<AppNotification, "id" | "at" | "readRoles">;
const repo = () => getRepository();
const snap = () => repo().getSnapshot();

async function notify(n: NotifyIn) {
  await repo().upsert("notifications", { ...n, id: uid("nf"), at: nowISO(), readRoles: [] });
}
async function log(inst: string, text: string, kind: string) {
  await repo().upsert("activity", { id: uid("ac"), inst, text, at: nowISO(), kind });
}
function allow(role: Role, perm: Parameters<typeof can>[2]) {
  if (!can(snap(), role, perm)) throw new Error("Permission denied for this role. (UI check — real enforcement belongs to the backend.)");
}

export const uc = {
  // ---------- generic ----------
  save: <K extends CollectionKey>(key: K, item: Item<K>) => repo().upsert(key, item),
  remove: <K extends CollectionKey>(key: K, id: string) => repo().remove(key, id),
  reset: () => repo().reset(),
  setPermissions: async (m: PermMatrix, inst: string) => { await repo().setPermissions(m); await repo().upsert("audit", { id: uid("au"), inst, text: "Permission matrix updated by Dr. Anil Joshi", at: nowISO(), kind: "permissions" }); },

  // ---------- attendance ----------
  async markAttendance(o: { inst: string; role: Role; date: string; entries: Record<string, AttStatus>; by: string; reason?: string }) {
    allow(o.role, "attendance.edit");
    const db = snap();
    const changes: { date: string; studentId: string; status: AttStatus }[] = [];
    let newAbsences = 0;
    for (const [studentId, status] of Object.entries(o.entries)) {
      const prev = db.attendance[`${o.date}|${studentId}`];
      if (prev === status) continue;
      changes.push({ date: o.date, studentId, status });
      if (prev) await repo().upsert("attLog", { id: uid("al"), inst: o.inst, date: o.date, studentId, from: prev, to: status, by: o.by, at: nowISO(), reason: o.reason || "Correction" });
      if (status === "A") {
        newAbsences++;
        const st = db.students.find((s) => s.id === studentId);
        await notify({ inst: o.inst, roles: ["parent"], studentId, cat: "attendance", title: `${st?.name.split(" ")[0]} was marked absent on ${dmy(o.date)}`, body: "Marked by the class teacher. Open the attendance calendar for details.", dest: { name: "S73" } });
      }
    }
    await repo().setAttendance(changes);
    await log(o.inst, `Attendance saved by ${o.by} · ${changes.length} record(s) updated${newAbsences ? `, ${newAbsences} absent` : ""}`, "attendance");
    return changes.length;
  },

  // ---------- admissions ----------
  saveEnquiry: (e: Enquiry) => repo().upsert("enquiries", e),
  async setEnquiryStatus(id: string, status: EnquiryStatus, text?: string) {
    const e = snap().enquiries.find((x) => x.id === id);
    if (!e) return;
    await repo().upsert("enquiries", { ...e, status, timeline: [...e.timeline, { at: nowISO(), text: text ?? `Status changed to ${status}` }] });
  },
  async convertEnquiry(id: string) {
    const db = snap();
    const e = db.enquiries.find((x) => x.id === id);
    if (!e) return null;
    const batch = db.batches.find((b) => b.inst === e.inst && (e.course.includes(b.name.split(" – ")[0]) || b.course === e.course)) ?? db.batches.find((b) => b.inst === e.inst)!;
    const n = db.students.filter((s) => s.inst === e.inst).length + 1;
    const st: Student = { id: uid("s"), inst: e.inst, name: e.student, sid: `AL-${String(n).padStart(3, "0")}`, batchId: batch.id, dob: "", phone: e.phone, address: "", admDate: today(), status: "active", session: batch.session, subjects: Object.keys(batch.subjectTeachers) };
    await repo().upsert("students", st);
    await repo().upsert("guardians", { id: uid("g"), inst: e.inst, studentId: st.id, name: e.guardian, relation: "Guardian", phone: e.phone, status: "pending", consent: false, linked: false });
    await uc.setEnquiryStatus(id, "Converted", `Converted to student ${st.sid} in ${batch.name}`);
    await log(e.inst, `Enquiry converted: ${e.student} admitted to ${batch.name}`, "admission");
    return st;
  },

  // ---------- people ----------
  saveStudent: (s: Student) => repo().upsert("students", s),
  async inviteGuardian(g: Guardian) {
    await repo().upsert("guardians", { ...g, status: "invited", consent: false, invitedAt: nowISO() });
  },
  async verifyGuardian(g: Guardian) {
    await repo().upsert("guardians", { ...g, status: "verified", consent: true });
  },
  async revokeGuardian(g: Guardian) {
    await repo().upsert("guardians", { ...g, status: "pending", consent: false });
  },

  // ---------- homework ----------
  async saveHomework(h: Homework) {
    const was = snap().homework.find((x) => x.id === h.id);
    await repo().upsert("homework", h);
    if (h.status === "published" && (!was || was.status === "draft")) {
      await notify({ inst: h.inst, roles: ["student", "parent"], batchId: h.batchId, cat: "homework", title: `New homework: ${h.title}`, body: `${h.subject} · due ${dmy(h.due)}`, dest: { name: "S60", params: { id: h.id } } });
      await log(h.inst, `Homework published: ${h.title}`, "homework");
    }
  },
  async submitHomework(o: { hwId: string; studentId: string; text?: string; file?: FileMeta | null }) {
    const db = snap();
    const hw = db.homework.find((h) => h.id === o.hwId)!;
    const prev = db.submissions.find((s) => s.hwId === o.hwId && s.studentId === o.studentId);
    const at = nowISO();
    const sub: Submission = {
      id: prev?.id ?? `sub-${o.hwId}-${o.studentId}`, hwId: o.hwId, studentId: o.studentId, status: "submitted", text: o.text, file: o.file ?? prev?.file, submittedAt: at,
      feedback: prev?.feedback, marks: undefined, history: [...(prev?.history ?? []), { at, text: prev ? "Resubmitted (demo upload)" : "Submitted (demo upload)" }],
    };
    await repo().upsert("submissions", sub);
    const st = db.students.find((s) => s.id === o.studentId);
    await notify({ inst: hw.inst, roles: ["teacher"], cat: "homework", title: `Homework submitted: ${st?.name}`, body: `${hw.title} is ready for review.`, dest: { name: "S49", params: { id: sub.id } } });
    await log(hw.inst, `${st?.name} submitted ${hw.title}`, "homework");
  },
  async reviewSubmission(o: { id: string; status: "reviewed" | "returned"; marks?: number; feedback: string }) {
    const db = snap();
    const sub = db.submissions.find((s) => s.id === o.id);
    if (!sub) return;
    const hw = db.homework.find((h) => h.id === sub.hwId)!;
    await repo().upsert("submissions", { ...sub, status: o.status, marks: o.status === "reviewed" ? o.marks : undefined, feedback: o.feedback, history: [...sub.history, { at: nowISO(), text: o.status === "reviewed" ? "Reviewed by teacher" : "Returned for correction" }] });
    await notify({ inst: hw.inst, roles: ["student", "parent"], studentId: sub.studentId, cat: "homework", title: o.status === "reviewed" ? `Homework reviewed: ${hw.title}` : `Homework returned for correction: ${hw.title}`, body: o.feedback || "Open to see the teacher's feedback.", dest: { name: "S61", params: { id: hw.id } } });
  },

  // ---------- exams ----------
  async saveMarks(examId: string, entries: Record<string, number | null>) {
    await repo().setMarks(Object.entries(entries).map(([studentId, marks]) => ({ examId, studentId, marks })));
    const x = snap().exams.find((e) => e.id === examId);
    if (x && x.status === "scheduled") await repo().upsert("exams", { ...x, status: "completed" });
  },
  async publishExam(examId: string, role: Role) {
    allow(role, "results.publish");
    const x = snap().exams.find((e) => e.id === examId);
    if (!x) return;
    await repo().upsert("exams", { ...x, status: "published" });
    await notify({ inst: x.inst, roles: ["student", "parent"], batchId: x.batchId, cat: "exam", title: `Result published: ${x.name}`, body: `${x.subject} results are now available.`, dest: { name: "S63" } });
    await log(x.inst, `Results published: ${x.name}`, "exam");
  },

  // ---------- fees ----------
  async recordPayment(p: Omit<Payment, "id" | "receipt" | "demo" | "status">, role: Role) {
    allow(role, "fees.record");
    const n = snap().payments.length + 1;
    const pay: Payment = { ...p, id: uid("p"), receipt: `GF-DEMO-${String(n).padStart(4, "0")}`, status: "received", demo: true };
    await repo().upsert("payments", pay);
    const st = snap().students.find((s) => s.id === p.studentId);
    await notify({ inst: p.inst, roles: ["parent"], studentId: p.studentId, cat: "fee", title: `Payment recorded (demo) for ${st?.name.split(" ")[0]}`, body: `Receipt ${pay.receipt}. Demo record — no real money moved.`, dest: { name: "S78" } });
    await log(p.inst, `Demo payment recorded for ${st?.name}`, "fee");
    return pay;
  },
  async refund(id: string, step: "request" | "approve" | "reject", role: Role) {
    allow(role, "fees.record");
    const p = snap().payments.find((x) => x.id === id);
    if (!p) return;
    await repo().upsert("payments", { ...p, status: step === "request" ? "refund-requested" : step === "approve" ? "refunded" : "received" });
  },
  async adjustFee(studentId: string, discount: number, reason: string, role: Role) {
    allow(role, "fees.record");
    const acc = snap().feeAccounts.find((a) => a.studentId === studentId);
    if (acc) await repo().upsert("feeAccounts", { ...acc, discount, discountReason: reason });
    return feeSummary(snap(), studentId);
  },

  // ---------- notices ----------
  async publishNotice(n: Notice, role: Role) {
    allow(role, "notices.publish");
    await repo().upsert("notices", n);
    if (n.status === "published") {
      const roles: Role[] = n.audience.type === "teachers" ? ["teacher"] : n.audience.type === "parents" ? ["parent"] : n.audience.type === "students" ? ["student"] : ["teacher", "student", "parent"];
      await notify({ inst: n.inst, roles, batchId: n.audience.type === "batches" ? n.audience.batchIds[0] : undefined, cat: "notice", title: n.title, body: n.body.slice(0, 90), dest: { name: "S79", params: { id: n.id } } });
      await log(n.inst, `Notice published: ${n.title}`, "notice");
    }
  },
  markNoticeRead: async (id: string, role: Role) => {
    const n = snap().notices.find((x) => x.id === id);
    if (n && !n.readBy.includes(role)) await repo().upsert("notices", { ...n, readBy: [...n.readBy, role] });
  },

  // ---------- resources ----------
  saveResource: (r: Resource) => repo().upsert("resources", r),
  async toggleBookmark(id: string) {
    const r = snap().resources.find((x) => x.id === id);
    if (r) await repo().upsert("resources", { ...r, bookmarked: !r.bookmarked });
  },
  async openResource(id: string) {
    const r = snap().resources.find((x) => x.id === id);
    if (r && !r.recent) await repo().upsert("resources", { ...r, recent: true });
  },

  // ---------- leave & meetings ----------
  async requestLeave(l: Omit<LeaveRequest, "id" | "status" | "at">) {
    const leave: LeaveRequest = { ...l, id: uid("lv"), status: "pending", at: nowISO() };
    await repo().upsert("leaves", leave);
    await notify({ inst: l.inst, roles: l.kind === "staff" ? ["owner"] : ["owner", "teacher"], cat: "general", title: `${l.kind === "staff" ? "Staff" : "Student"} leave request: ${l.by}`, body: `${dmy(l.from)} – ${dmy(l.to)} · ${l.reason}`, dest: l.kind === "staff" ? { name: "S26", params: { id: l.personId } } : { name: "S39", params: { tab: "requests" } } });
    return leave;
  },
  async decideLeave(id: string, status: "approved" | "rejected", substitute?: string) {
    const l = snap().leaves.find((x) => x.id === id);
    if (!l) return;
    await repo().upsert("leaves", { ...l, status, substitute: substitute ?? l.substitute });
    await notify({ inst: l.inst, roles: l.kind === "staff" ? ["teacher"] : ["parent"], studentId: l.kind === "student" ? l.personId : undefined, cat: "general", title: `Leave request ${status}`, body: `${dmy(l.from)} – ${dmy(l.to)}`, dest: { name: l.kind === "staff" ? "S54" : "S80" } });
  },
  async requestMeeting(m: Omit<MeetingRequest, "id" | "status" | "at">) {
    await repo().upsert("meetings", { ...m, id: uid("m"), status: "pending", at: nowISO() });
    await notify({ inst: m.inst, roles: ["teacher", "owner"], cat: "general", title: "Parent meeting request", body: m.reason, dest: { name: "S39", params: { tab: "requests" } } });
  },
  async decideMeeting(id: string, status: "accepted" | "declined") {
    const m = snap().meetings.find((x) => x.id === id);
    if (m) {
      await repo().upsert("meetings", { ...m, status });
      await notify({ inst: m.inst, roles: ["parent"], studentId: m.studentId, cat: "general", title: `Meeting request ${status}`, body: `${dmy(m.date)}`, dest: { name: "S81" } });
    }
  },

  // ---------- doubts ----------
  async askDoubt(d: { inst: string; studentId: string; subject: string; teacherId: string; batchId: string; title: string; text: string; hasImage: boolean }) {
    const id = uid("d");
    await repo().upsert("doubts", { id, inst: d.inst, studentId: d.studentId, subject: d.subject, teacherId: d.teacherId, batchId: d.batchId, status: "open", title: d.title, hasImage: d.hasImage, messages: [{ from: "student", text: d.text, at: nowISO() }] });
    await notify({ inst: d.inst, roles: ["teacher"], cat: "homework", title: "New doubt received", body: d.title, dest: { name: "S53", params: { id } } });
    return id;
  },
  async replyDoubt(id: string, from: DoubtMsg["from"], text: string) {
    const d = snap().doubts.find((x) => x.id === id);
    if (!d) return;
    await repo().upsert("doubts", { ...d, status: from === "teacher" ? "answered" : "open", messages: [...d.messages, { from, text, at: nowISO() }] });
    if (from === "teacher") await notify({ inst: d.inst, roles: ["student"], studentId: d.studentId, cat: "homework", title: "Your teacher replied to your doubt", body: d.title, dest: { name: "S70", params: { id } } });
  },
  async resolveDoubt(id: string) {
    const d = snap().doubts.find((x) => x.id === id);
    if (d) await repo().upsert("doubts", { ...d, status: "resolved" });
  },

  // ---------- notifications ----------
  async markRead(id: string, role: Role) {
    const n = snap().notifications.find((x) => x.id === id);
    if (n && !n.readRoles.includes(role)) await repo().upsert("notifications", { ...n, readRoles: [...n.readRoles, role] });
  },
  async markAllRead(ids: string[], role: Role) {
    for (const id of ids) await uc.markRead(id, role);
  },

  // ---------- learning ----------
  async saveAttempt(a: Omit<import("@/domain/types").Attempt, "id" | "at">) {
    await repo().upsert("attempts", { ...a, id: uid("at"), at: nowISO() });
  },
};

export const futureDate = (n: number) => addDays(n);
