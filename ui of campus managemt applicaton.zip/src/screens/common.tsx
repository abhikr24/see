"use client";
import React, { ReactNode, useMemo, useState } from "react";
import { Bell, Check, ChevronDown, Search } from "lucide-react";
import type { Role } from "@/domain/types";
import { notificationVisible, ROLE_LABEL } from "@/features/selectors";
import { useApp, useDB, useMe, useScope } from "@/state/app";
import { Avatar, Badge, IconBtn, Sheet } from "@/ui/kit";

export const STATES = ["Andhra Pradesh", "Assam", "Bihar", "Chhattisgarh", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Odisha", "Punjab", "Rajasthan", "Tamil Nadu", "Telangana", "Uttar Pradesh", "Uttarakhand", "West Bengal"];
export const SUBJECT_LIST = ["Mathematics", "Science", "English", "Social Science", "Physics", "Chemistry"];

export function useNotifs() {
  const db = useDB();
  const { session } = useApp();
  const me = useMe();
  return useMemo(() => {
    const list = db.notifications.filter((n) => notificationVisible(n, session.role, me.studentIds, me.batchIds, session.instId)).sort((a, b) => (a.at < b.at ? 1 : -1));
    return { list, unread: list.filter((n) => !n.readRoles.includes(session.role)).length };
  }, [db.notifications, session.role, session.instId, me.studentIds, me.batchIds]);
}

/** Institute / role switcher bottom sheet. Changing context resets to that role's home with that institute's data. */
export function ContextSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const db = useDB();
  const { session, switchContext, toast } = useApp();
  return (
    <Sheet open={open} onClose={onClose} title="Switch institute or role">
      <div className="space-y-3">
        {db.memberships.filter((m) => m.status === "active").map((m) => {
          const inst = db.institutes.find((i) => i.id === m.instId)!;
          return (
            <div key={m.id} className="rounded-2xl border border-line p-3">
              <div className="flex items-center gap-3"><Avatar name={inst.name} tone="violet" /><div className="min-w-0"><div className="truncate text-[14.5px] font-semibold">{inst.name}</div><div className="text-[12px] text-mute">{inst.city}, {inst.state}</div></div></div>
              <div className="mt-3 flex flex-wrap gap-2">
                {m.roles.map((r) => {
                  const cur = session.instId === m.instId && session.role === r;
                  return (
                    <button key={r} onClick={() => { switchContext(m.instId, r); onClose(); toast(`Switched to ${ROLE_LABEL[r]} · ${inst.name}`, "info"); }} className={`flex min-h-10 items-center gap-1.5 rounded-full border px-3.5 text-[13px] font-semibold ${cur ? "border-brand bg-brand text-white" : "border-line text-ink"}`}>
                      {cur ? <Check size={14} /> : null}{ROLE_LABEL[r].split(" /")[0]}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </Sheet>
  );
}

/** Colourful-but-restrained home frame used by all four role dashboards. */
export function HomeFrame({ greeting, sub, children, extra }: { greeting: string; sub?: string; children: ReactNode; extra?: ReactNode }) {
  const sc = useScope();
  const { session, push } = useApp();
  const { unread } = useNotifs();
  const [ctx, setCtx] = useState(false);
  return (
    <div className="flex h-full flex-col bg-bg">
      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto overscroll-contain">
        <div className="bg-gradient-to-br from-brand-dark via-brand-dark to-brand px-4 pb-16 pt-3 text-white">
          <div className="flex items-center justify-between gap-2">
            <button onClick={() => setCtx(true)} aria-label="Switch institute or role" className="flex min-h-10 min-w-0 items-center gap-2 rounded-full bg-white/12 py-1.5 pl-3 pr-2.5 text-[12.5px] font-semibold">
              <span className="truncate">{sc.inst.name}</span><ChevronDown size={15} className="shrink-0" />
            </button>
            <div className="flex shrink-0">
              <IconBtn icon={Search} label="Search" tone="dark" onClick={() => push("S12")} />
              <IconBtn icon={Bell} label="Notifications" tone="dark" badge={unread} onClick={() => push("S11")} />
            </div>
          </div>
          <div className="mt-4 flex items-end justify-between gap-3">
            <div className="min-w-0"><h1 className="text-[24px] font-bold leading-tight tracking-tight">{greeting}</h1>{sub ? <p className="mt-0.5 text-[13px] text-white/75">{sub}</p> : null}</div>
            <Badge tone="brand">{ROLE_LABEL[session.role].split(" /")[0]}</Badge>
          </div>
          {extra}
        </div>
        <div className="-mt-10 px-4 pb-8">{children}</div>
      </div>
      <ContextSheet open={ctx} onClose={() => setCtx(false)} />
    </div>
  );
}

export const roleHomeLabel = (r: Role) => ROLE_LABEL[r];
export { Search };
