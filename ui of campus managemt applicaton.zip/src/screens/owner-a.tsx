"use client";
import React, { useMemo, useRef, useState } from "react";
import { AlertTriangle, Calendar, CalendarCheck, CalendarPlus, CheckSquare, ChevronDown, ClipboardList, Download, GraduationCap, IndianRupee, Megaphone, Phone, Plus, Receipt, Trash2, UserCheck, UserPlus, Users, Wallet, Pencil, Search, Building, DoorOpen, BookOpen, Clock, SlidersHorizontal, XCircle, Send, ShieldCheck, ShieldOff, BadgeCheck, MoveRight } from "lucide-react";
import type { Batch, Enquiry, EnquiryStatus, Guardian, Staff, Student } from "@/domain/types";
import { useApp, useDB, useMe, useScope, useUnsaved } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Chips, Denied, Empty, FilterBar, IconBtn, IconTile, Kv, List, Page, Progress, Row, Section, Segmented, Sheet, Stat, Tabs } from "@/ui/kit";
import { Checkbox, DatePicker, Select, SearchInput, TextInput, useForm } from "@/ui/forms";
import { Bars, Donut, LineChart, StackBar, AttPill } from "@/ui/charts";
import { BatchCard, HomeworkCard, StatusBadge, StudentCard, TeacherCard, label as lab } from "@/ui/cards";
import { HomeFrame } from "./common";
import { def, P, ScreenMap } from "./types";
import { addDays, ago, dmy, dtLabel, inr, longDate, nowISO, pct, relDay, time12, today, uid, validPhone, validEmail, DAYS, academicYear, DAYS_LONG } from "@/lib/fmt";
import { attendanceTrend, instFees, monthlyCollection, pendingAttendanceBatches } from "@/features/aggregates";
import { batchAttOn, can, feeSummary, instAttToday, resultsFor, studentAtt, subFor } from "@/features/selectors";
import { uc } from "@/features/usecases";
import { DEMO_OTP } from "./shared-auth";

const ENQ_STATUS: EnquiryStatus[] = ["New", "Contacted", "Demo Scheduled", "Follow-up", "Converted", "Lost"];
const SOURCES = ["Walk-in", "Referral", "Website", "Instagram", "WhatsApp", "Newspaper", "Hoarding"];

/* S16 */
function OwnerDashboard(_: P) {
  const sc = useScope();
  const me = useMe();
  const { push } = useApp();
  const [date, setDate] = useState(today());
  const ref = useRef<HTMLInputElement>(null);
  const fees = useMemo(() => instFees(sc), [sc]);
  const att = instAttToday(sc, date);
  const trend = useMemo(() => attendanceTrend(sc), [sc]);
  const coll = useMemo(() => monthlyCollection(sc), [sc]);
  const newEnq = sc.enquiries.filter((e) => e.status === "New").length;
  const upcoming = sc.exams.filter((x) => x.date >= today() && x.status !== "published").length;
  const pendingBatches = pendingAttendanceBatches(sc);
  const leavesPending = sc.leaves.filter((l) => l.status === "pending").length;
  const unverified = sc.guardians.filter((g) => g.status !== "verified" && sc.students.find((s) => s.id === g.studentId)?.status === "active").length;
  const alerts = [
    fees.overdueCount ? { t: `${fees.overdueCount} students have overdue fees`, s: `${inr(fees.overdue)} overdue`, to: "S35", tone: "bad" as const } : null,
    pendingBatches.length ? { t: `Attendance pending for ${pendingBatches.length} batch${pendingBatches.length > 1 ? "es" : ""}`, s: pendingBatches.map((b) => b.name.split(" – ")[0]).join(", "), to: "S32", tone: "warn" as const } : null,
    leavesPending ? { t: `${leavesPending} leave request${leavesPending > 1 ? "s" : ""} awaiting approval`, s: "Review in Notices & requests", to: "S39", tone: "warn" as const } : null,
    unverified ? { t: `${unverified} guardians not verified`, s: "They can't see records yet", to: "S24", tone: "sky" as const } : null,
  ].filter(Boolean) as { t: string; s: string; to: string; tone: "bad" | "warn" | "sky" }[];
  const open = () => { try { ref.current?.showPicker(); } catch { ref.current?.focus(); } };
  return (
    <HomeFrame greeting={`Namaste, ${me.first}`} sub={`${sc.inst.name} · ${sc.inst.city}`}
      extra={<div className="relative mt-4"><button onClick={open} aria-label="Select date" className="flex min-h-10 items-center gap-2 rounded-full bg-white/12 px-3.5 text-[13px] font-semibold"><Calendar size={15} />{date === today() ? "Today" : dmy(date)} · {longDate(date)}<ChevronDown size={14} /></button><input ref={ref} type="date" value={date} max={today()} onChange={(e) => e.target.value && setDate(e.target.value)} tabIndex={-1} aria-hidden className="pointer-events-none absolute left-0 top-0 h-10 w-full opacity-0" /></div>}>
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Active students" value={sc.students.filter((s) => s.status === "active").length} sub={`${sc.batches.length} batches`} icon={Users} onClick={() => push("S21")} />
        <Stat label="Total staff" value={sc.staff.length} sub={`${sc.staff.filter((s) => s.status === "on-leave").length} on leave`} icon={UserCheck} tone="violet" onClick={() => push("S25")} />
        <Stat label="New enquiries" value={newEnq} sub={`${sc.enquiries.length} total`} icon={UserPlus} tone="sky" onClick={() => push("S17")} />
        <Stat label={`Attendance${date === today() ? " today" : ""}`} value={att.marked ? `${att.pct}%` : "—"} sub={att.marked ? `${att.marked}/${att.total} marked` : "Not marked yet"} icon={CalendarCheck} tone={att.marked ? "ok" : "warn"} onClick={() => push("S32", { date })} />
        <Stat label="Fees collected" value={inr(fees.collected)} sub={`${fees.rate}% of ${inr(fees.expected)}`} icon={Wallet} tone="ok" onClick={() => push("S35")} />
        <Stat label="Pending dues" value={inr(fees.outstanding)} sub={fees.overdue ? `${inr(fees.overdue)} overdue` : "Nothing overdue"} icon={IndianRupee} tone={fees.overdue ? "bad" : "mute"} onClick={() => push("S37")} />
      </div>
      <Card className="mt-3" onClick={() => push("S33")}><div className="flex items-center gap-3"><IconTile icon={GraduationCap} tone="violet" /><div className="flex-1"><div className="text-[14.5px] font-semibold">Upcoming exams</div><div className="text-[12.5px] text-mute">{upcoming} scheduled or awaiting results</div></div><span className="text-[22px] font-bold">{upcoming}</span></div></Card>

      <Section title="Quick actions">
        <div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4">
          {[{ i: UserPlus, l: "Add enquiry", to: "S19" }, { i: Plus, l: "Add student", to: "S22" }, { i: Megaphone, l: "New notice", to: "S39" }, { i: Receipt, l: "Record payment", to: "S37" }, { i: GraduationCap, l: "Create exam", to: "S33" }].map((a) => (
            <button key={a.l} onClick={() => push(a.to)} className="flex min-h-[78px] w-[84px] shrink-0 flex-col items-center justify-center gap-1.5 rounded-2xl border border-line bg-white px-1 text-center active:bg-slate-50"><a.i size={20} className="text-brand" /><span className="text-[11.5px] font-medium leading-tight text-ink">{a.l}</span></button>
          ))}
        </div>
      </Section>

      {alerts.length ? <Section title="Needs your attention"><List>{alerts.map((a) => <Row key={a.t} icon={AlertTriangle} tone={a.tone} title={a.t} sub={a.s} onClick={() => push(a.to)} />)}</List></Section> : null}

      <Section title="Attendance this week" action="Report" onAction={() => push("S32")}>
        <Card>{trend.points.length ? <LineChart points={trend.points} labels={trend.labels} min={50} max={100} /> : <p className="py-6 text-center text-[13px] text-mute">No attendance has been marked this week.</p>}</Card>
      </Section>
      <Section title="Fee collection (₹ thousands)" action="Fees" onAction={() => push("S35")}><Card><Bars data={coll} height={90} suffix="K" /></Card></Section>
      <Section title="Recent activity"><List>{sc.activity.slice().sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 5).map((a) => <Row key={a.id} lead={<span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand"><Clock size={18} /></span>} title={<span className="whitespace-normal text-[13.5px] leading-snug">{a.text}</span>} sub={ago(a.at)} noChevron />)}</List></Section>
    </HomeFrame>
  );
}

/* S17 */
function Admissions(_: P) {
  const sc = useScope();
  const { push } = useApp();
  const cnt = (s: EnquiryStatus) => sc.enquiries.filter((e) => e.status === s).length;
  const due = sc.enquiries.filter((e) => e.followUp && e.followUp <= today() && !["Converted", "Lost"].includes(e.status));
  const conv = pct(cnt("Converted"), sc.enquiries.length);
  return (
    <Page title="Admissions" subtitle="Enquiries to enrolments" right={<IconBtn icon={Plus} label="Add enquiry" tone="soft" onClick={() => push("S19")} />}>
      <div className="grid grid-cols-2 gap-3 pt-2">
        <Stat label="Total enquiries" value={sc.enquiries.length} onClick={() => push("S18")} /><Stat label="New" value={cnt("New")} tone="sky" onClick={() => push("S18", { status: "New" })} />
        <Stat label="Follow-ups due" value={due.length} tone={due.length ? "warn" : "mute"} sub="Today or overdue" onClick={() => push("S18", { status: "Follow-up" })} /><Stat label="Demo classes" value={cnt("Demo Scheduled")} tone="violet" onClick={() => push("S18", { status: "Demo Scheduled" })} />
        <Stat label="Converted" value={cnt("Converted")} tone="ok" onClick={() => push("S18", { status: "Converted" })} /><Stat label="Lost" value={cnt("Lost")} tone="bad" onClick={() => push("S18", { status: "Lost" })} />
      </div>
      <Section title="Pipeline summary"><Card><StackBar parts={ENQ_STATUS.map((s) => ({ label: s, value: cnt(s), tone: s === "Converted" ? "ok" : s === "Lost" ? "bad" : s === "New" ? "brand" : s === "Contacted" ? "sky" : s === "Demo Scheduled" ? "violet" : "warn" }))} /></Card></Section>
      <Section title="Conversion"><Card><div className="flex items-center gap-4"><Donut value={conv} tone="ok" sub="converted" /><p className="text-[13.5px] leading-relaxed text-mute"><b className="text-ink">{cnt("Converted")}</b> of {sc.enquiries.length} enquiries became admissions. This is a simple count of enquiries to date — not a prediction.</p></div></Card></Section>
      <Section title="Follow-ups due" action="Open pipeline" onAction={() => push("S18")}>
        {due.length ? <List>{due.map((e) => <Row key={e.id} icon={Phone} tone="warn" title={e.student} sub={`${e.status} · follow up ${relDay(e.followUp!)}`} onClick={() => push("S20", { id: e.id })} />)}</List> : <Card><p className="text-[13.5px] text-mute">No follow-ups are due. Nice work.</p></Card>}
      </Section>
    </Page>
  );
}

/* S18 */
function Pipeline({ params }: P) {
  const sc = useScope();
  const { push, toast } = useApp();
  const [q, setQ] = useState("");
  const [view, setView] = useState<"pipeline" | "list">("pipeline");
  const [status, setStatus] = useState<string>(params.status ?? "All");
  const [src, setSrc] = useState("All");
  const [sort, setSort] = useState("Newest");
  const [fs, setFs] = useState(false);
  const [mv, setMv] = useState<Enquiry | null>(null);
  const filtered = sc.enquiries.filter((e) => (status === "All" || e.status === status) && (src === "All" || e.source === src) && (e.student + e.guardian + e.course + e.phone).toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => sort === "Newest" ? (a.createdAt < b.createdAt ? 1 : -1) : sort === "Oldest" ? (a.createdAt > b.createdAt ? 1 : -1) : sort === "Name" ? a.student.localeCompare(b.student) : (a.followUp ?? "9") < (b.followUp ?? "9") ? -1 : 1);
  const applied = (src !== "All" ? 1 : 0) + (sort !== "Newest" ? 1 : 0) + (status !== "All" ? 1 : 0);
  const card = (e: Enquiry) => (
    <Card key={e.id} className="!p-3.5" onClick={() => push("S20", { id: e.id })}>
      <div className="flex items-start gap-3"><Avatar name={e.student} /><div className="min-w-0 flex-1"><div className="text-[15px] font-semibold">{e.student}</div><div className="text-[12.5px] text-mute">{e.course} · {e.source}</div>{e.followUp ? <div className="mt-1 flex items-center gap-1 text-[12px] font-medium text-warn"><Clock size={12} />Follow-up {relDay(e.followUp)}</div> : null}</div><StatusBadge status={e.status} /></div>
      <div className="mt-3 flex gap-2" onClick={(ev) => ev.stopPropagation()}><Btn size="sm" variant="soft" icon={MoveRight} onClick={() => setMv(e)}>Update status</Btn></div>
    </Card>
  );
  return (
    <Page title="Enquiry pipeline" subtitle={`${filtered.length} enquiries`} right={<IconBtn icon={Plus} label="Add enquiry" tone="soft" onClick={() => push("S19")} />}>
      <div className="space-y-2 pt-1">
        <div className="flex gap-2"><div className="flex-1"><SearchInput value={q} onChange={setQ} placeholder="Search name, phone, course" /></div><button onClick={() => setFs(true)} aria-label="Filters" className="relative grid h-11 w-11 place-items-center rounded-xl border border-line bg-white text-brand"><SlidersHorizontal size={19} />{applied ? <span className="absolute -right-1 -top-1 grid h-4.5 min-w-4 place-items-center rounded-full bg-brand px-1 text-[10px] font-bold text-white">{applied}</span> : null}</button></div>
        <Chips value={status} onChange={setStatus} options={["All", ...ENQ_STATUS]} />
        <Segmented value={view} onChange={setView} options={[{ value: "pipeline", label: "Pipeline" }, { value: "list", label: "List" }]} />
      </div>
      {filtered.length === 0 ? <Empty icon={Search} title="No enquiries match" body="Try clearing filters or changing the search." action="Clear filters" onAction={() => { setQ(""); setStatus("All"); setSrc("All"); setSort("Newest"); }} /> : view === "list" ? <div className="mt-3 space-y-2.5">{filtered.map(card)}</div> : (
        <div className="mt-3">{ENQ_STATUS.filter((s) => filtered.some((e) => e.status === s)).map((s) => (
          <div key={s} className="mb-4"><div className="mb-2 flex items-center justify-between px-0.5"><span className="text-[13px] font-semibold text-ink">{s}</span><Badge tone="mute">{filtered.filter((e) => e.status === s).length}</Badge></div><div className="space-y-2.5">{filtered.filter((e) => e.status === s).map(card)}</div></div>))}</div>)}
      <Sheet open={fs} onClose={() => setFs(false)} title="Filter & sort">
        <div className="space-y-4"><Select label="Source" value={src} onChange={setSrc} options={["All", ...SOURCES]} /><Select label="Sort by" value={sort} onChange={setSort} options={["Newest", "Oldest", "Name", "Follow-up date"]} />
          <div className="flex gap-2"><Btn variant="secondary" onClick={() => { setSrc("All"); setSort("Newest"); setStatus("All"); }}>Clear all</Btn><Btn onClick={() => setFs(false)}>Apply</Btn></div></div>
      </Sheet>
      <Sheet open={!!mv} onClose={() => setMv(null)} title={`Move ${mv?.student ?? ""}`}>
        <div className="space-y-1">{ENQ_STATUS.map((s) => <button key={s} onClick={async () => { if (mv) { if (s === "Converted") { await uc.convertEnquiry(mv.id); } else await uc.setEnquiryStatus(mv.id, s); toast(`Moved to ${s}`); } setMv(null); }} className={`flex min-h-12 w-full items-center justify-between rounded-xl px-3 text-left ${mv?.status === s ? "bg-brand-soft" : "active:bg-slate-50"}`}><span className="text-[15px]">{s}</span>{mv?.status === s ? <Badge tone="brand">Current</Badge> : null}</button>)}</div>
      </Sheet>
    </Page>
  );
}

/* S19 */
function EnquiryForm({ params }: P) {
  const sc = useScope();
  const { back, toast } = useApp();
  const ex = sc.enquiries.find((e) => e.id === params.id);
  const [loading, setLoading] = useState(false);
  const courses = Array.from(new Set(sc.batches.map((b) => b.name)));
  const f = useForm({ student: ex?.student ?? "", guardian: ex?.guardian ?? "", phone: ex?.phone ?? "", course: ex?.course ?? "", source: ex?.source ?? "Walk-in", notes: ex?.notes ?? "", followUp: ex?.followUp ?? "", demoDate: ex?.demoDate ?? "", status: (ex?.status ?? "New") as string }, (v) => ({
    student: v.student.trim().length < 2 ? "Enter student name" : undefined, guardian: v.guardian.trim().length < 2 ? "Enter guardian name" : undefined, phone: validPhone(v.phone) ? undefined : "Enter a valid 10-digit mobile number",
    course: v.course ? undefined : "Select a course or batch", followUp: v.followUp && !ex && v.followUp < today() ? "Follow-up date can't be in the past" : undefined,
    demoDate: v.status === "Demo Scheduled" && !v.demoDate ? "Pick the demo class date" : undefined,
  }));
  useUnsaved(f.dirty && !loading);
  const save = async () => {
    f.touchAll(); if (!f.valid) return; setLoading(true);
    const e: Enquiry = { id: ex?.id ?? uid("e"), inst: sc.instId, student: f.v.student.trim(), guardian: f.v.guardian.trim(), phone: f.v.phone.replace(/\D/g, "").slice(-10), course: f.v.course, source: f.v.source, status: f.v.status as EnquiryStatus, notes: f.v.notes, followUp: f.v.followUp || undefined, demoDate: f.v.demoDate || undefined, createdAt: ex?.createdAt ?? nowISO(), timeline: ex ? [...ex.timeline, { at: nowISO(), text: "Enquiry details updated" }] : [{ at: nowISO(), text: "Enquiry created" }] };
    await uc.saveEnquiry(e); setLoading(false); toast(ex ? "Enquiry updated" : "Enquiry added"); back();
  };
  return (
    <Page title={ex ? "Edit enquiry" : "Add enquiry"} footer={<Btn loading={loading} disabled={!f.valid} onClick={save}>{ex ? "Save changes" : "Save enquiry"}</Btn>}>
      <div className="space-y-4 pt-2">
        <TextInput label="Student name" required {...f.bind("student")} /><TextInput label="Guardian name" required {...f.bind("guardian")} />
        <TextInput label="Phone number" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("phone")} />
        <Select label="Interested course / batch" required options={courses} {...f.bind("course")} />
        <Select label="Source" options={SOURCES} value={f.v.source} onChange={(v) => f.set("source", v)} />
        <Select label="Status" options={ENQ_STATUS} value={f.v.status} onChange={(v) => f.set("status", v)} />
        <DatePicker label="Follow-up date" value={f.v.followUp} onChange={(v) => f.set("followUp", v)} error={f.errors.followUp} />
        <DatePicker label="Demo class date" required={f.v.status === "Demo Scheduled"} value={f.v.demoDate} onChange={(v) => f.set("demoDate", v)} error={f.errors.demoDate} />
        <TextInput label="Notes" multiline rows={3} placeholder="What did the family ask for?" {...f.bind("notes")} />
      </div>
    </Page>
  );
}

/* S20 */
function EnquiryDetail({ params }: P) {
  const sc = useScope();
  const { push, confirm, toast, replace } = useApp();
  const e = sc.enquiries.find((x) => x.id === params.id) ?? sc.enquiries[0];
  const [note, setNote] = useState("");
  const [ns, setNs] = useState(false);
  if (!e) return <Page title="Enquiry"><Empty title="No enquiries yet" body="Add your first enquiry to see it here." action="Add enquiry" onAction={() => push("S19")} /></Page>;
  const closed = e.status === "Converted" || e.status === "Lost";
  return (
    <Page title="Enquiry details" right={<IconBtn icon={Pencil} label="Edit enquiry" onClick={() => push("S19", { id: e.id })} />}
      footer={!closed ? <div className="flex gap-2"><Btn variant="secondary" icon={XCircle} onClick={() => confirm({ title: "Mark enquiry as lost?", body: `${e.student} will move to Lost. You can still reopen it later.`, confirmLabel: "Mark lost", danger: true, onConfirm: async () => { await uc.setEnquiryStatus(e.id, "Lost"); toast("Marked as lost", "info"); } })}>Mark lost</Btn><Btn icon={UserCheck} onClick={() => confirm({ title: "Convert to student?", body: `This creates a student record for ${e.student} and a pending guardian invite.`, confirmLabel: "Convert", onConfirm: async () => { const s = await uc.convertEnquiry(e.id); toast("Student admitted"); if (s) replace("S23", { id: s.id }); } })}>Convert</Btn></div> : undefined}>
      <Card className="mt-2"><div className="flex items-center gap-3"><Avatar name={e.student} size={52} /><div className="min-w-0 flex-1"><h2 className="text-[18px] font-bold">{e.student}</h2><p className="text-[13px] text-mute">Guardian: {e.guardian}</p></div><StatusBadge status={e.status} /></div>
        <div className="mt-3 divide-y divide-line"><Kv k="Phone" v={`+91 ${e.phone}`} /><Kv k="Interested in" v={e.course} /><Kv k="Source" v={e.source} />{e.followUp ? <Kv k="Next follow-up" v={`${dmy(e.followUp)} (${relDay(e.followUp)})`} /> : null}{e.demoDate ? <Kv k="Demo class" v={dmy(e.demoDate)} /> : null}</div>
        <div className="mt-3 flex gap-2"><Btn variant="soft" size="sm" icon={Phone} onClick={() => toast(`Demo: dialling +91 ${e.phone}`, "info")}>Call</Btn><Btn variant="soft" size="sm" icon={Calendar} onClick={() => setNs(true)}>Change status</Btn></div></Card>
      <Section title="Notes"><Card><p className="text-[14px] leading-relaxed text-ink">{e.notes || "No notes yet."}</p></Card></Section>
      <Section title="Activity timeline"><Card><ol className="space-y-4">{e.timeline.slice().reverse().map((t, i) => <li key={i} className="flex gap-3"><span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-brand" /><div><div className="text-[13.5px] text-ink">{t.text}</div><div className="text-[11.5px] text-mute">{dtLabel(t.at)}</div></div></li>)}</ol>
        <div className="mt-4 flex gap-2"><div className="flex-1"><TextInput value={note} onChange={setNote} placeholder="Add a follow-up note" /></div><Btn full={false} disabled={!note.trim()} onClick={async () => { await uc.save("enquiries", { ...e, timeline: [...e.timeline, { at: nowISO(), text: `Note: ${note.trim()}` }] }); setNote(""); toast("Note added"); }}>Add</Btn></div></Card></Section>
      <Sheet open={ns} onClose={() => setNs(false)} title="Change status"><div className="space-y-1">{ENQ_STATUS.filter((s) => s !== "Converted").map((s) => <button key={s} onClick={async () => { await uc.setEnquiryStatus(e.id, s); setNs(false); toast(`Status: ${s}`); }} className="flex min-h-12 w-full items-center rounded-xl px-3 text-left text-[15px] active:bg-slate-50">{s}</button>)}</div></Sheet>
    </Page>
  );
}

/* S21 */
function StudentDirectory(_: P) {
  const sc = useScope();
  const { push, confirm, toast } = useApp();
  const [q, setQ] = useState("");
  const [batch, setBatch] = useState("All");
  const [status, setStatus] = useState("All");
  const [sort, setSort] = useState<"name" | "id">("name");
  const [sel, setSel] = useState<string[] | null>(null);
  const list = sc.students.filter((s) => (batch === "All" || s.batchId === batch) && (status === "All" || s.status === status.toLowerCase()) && (s.name + s.sid).toLowerCase().includes(q.toLowerCase())).sort((a, b) => (sort === "name" ? a.name.localeCompare(b.name) : a.sid.localeCompare(b.sid)));
  const bn = (id: string) => sc.batches.find((b) => b.id === id)?.name.split(" – ")[0] ?? "";
  const toggle = (id: string) => setSel((s) => (s ? (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]) : [id]));
  const bulk = (to: Student["status"]) => confirm({ title: `Mark ${sel?.length} student(s) ${to}?`, body: "You can change this again at any time.", confirmLabel: "Confirm", onConfirm: async () => { for (const id of sel ?? []) { const s = sc.students.find((x) => x.id === id); if (s) await uc.saveStudent({ ...s, status: to }); } toast("Updated"); setSel(null); } });
  return (
    <Page title="Students" subtitle={`${list.length} of ${sc.students.length}`} right={<><IconBtn icon={CheckSquare} label={sel ? "Exit selection" : "Select students"} onClick={() => setSel(sel ? null : [])} /><IconBtn icon={Plus} label="Add student" tone="soft" onClick={() => push("S22")} /></>}
      footer={sel && sel.length ? <div className="flex gap-2"><Btn variant="secondary" onClick={() => bulk("inactive")}>Mark inactive</Btn><Btn onClick={() => bulk("active")}>Mark active</Btn></div> : undefined}>
      <div className="space-y-2 pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search name or student ID" />
        <Chips value={batch} onChange={setBatch} options={[{ value: "All", label: "All batches" }, ...sc.batches.map((b) => ({ value: b.id, label: b.name.split(" – ")[0] + (b.name.includes("Morning") ? " · AM" : b.name.includes("Evening") ? " · PM" : "") }))]} />
        <div className="flex items-center gap-2"><div className="min-w-0 flex-1"><Chips value={status} onChange={setStatus} options={["All", "Active", "Inactive"]} /></div><button onClick={() => setSort(sort === "name" ? "id" : "name")} className="min-h-9 shrink-0 rounded-full border border-line bg-white px-3 text-[12.5px] font-medium">Sort: {sort === "name" ? "Name" : "ID"}</button></div>
        {(batch !== "All" || status !== "All" || q) ? <FilterBar active={(batch !== "All" ? 1 : 0) + (status !== "All" ? 1 : 0) + (q ? 1 : 0)} onClear={() => { setBatch("All"); setStatus("All"); setQ(""); }}><span className="text-[12px] text-mute">Filters applied</span></FilterBar> : null}</div>
      {list.length === 0 ? <Empty icon={Users} title={sc.students.length ? "No students match" : "No students yet"} body={sc.students.length ? "Adjust your search or filters." : "Add your first student or convert an enquiry."} action="Add student" onAction={() => push("S22")} /> : (
        <div className="mt-3 space-y-2.5">{list.map((s) => sel ? (
          <button key={s.id} onClick={() => toggle(s.id)} className="flex w-full items-center gap-3 text-left"><span className={`grid h-6 w-6 shrink-0 place-items-center rounded-md border ${sel.includes(s.id) ? "border-brand bg-brand text-white" : "border-slate-300 bg-white"}`}>{sel.includes(s.id) ? "✓" : ""}</span><div className="flex-1"><StudentCard s={s} batch={bn(s.batchId)} /></div></button>
        ) : <StudentCard key={s.id} s={s} batch={bn(s.batchId)} onClick={() => push("S23", { id: s.id })} />)}</div>)}
    </Page>
  );
}

/* S22 */
function StudentForm({ params }: P) {
  const sc = useScope();
  const { back, toast } = useApp();
  const ex = sc.students.find((s) => s.id === params.id);
  const g0 = sc.guardians.find((g) => g.studentId === ex?.id);
  const [loading, setLoading] = useState(false);
  const f = useForm({ name: ex?.name ?? "", sid: ex?.sid ?? `AL-${academicYear().label.slice(2, 4)}-${String(sc.students.length + 1).padStart(3, "0")}`, dob: ex?.dob ?? "", phone: ex?.phone ?? "", gName: g0?.name ?? "", gRel: g0?.relation ?? "Father", gPhone: g0?.phone ?? "", address: ex?.address ?? "", batchId: ex?.batchId ?? "", subjects: ex?.subjects ?? ([] as string[]), admDate: ex?.admDate ?? today(), status: (ex?.status ?? "active") as string }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter the student's full name" : undefined, sid: v.sid.trim() ? undefined : "Student ID is required", batchId: v.batchId ? undefined : "Select a batch",
    phone: v.phone && !validPhone(v.phone) ? "Enter a valid mobile number" : undefined, gName: v.gName.trim().length < 2 ? "Guardian name is required" : undefined, gPhone: validPhone(v.gPhone) ? undefined : "Enter guardian's valid mobile number",
    subjects: v.subjects.length ? undefined : "Choose at least one subject", dob: v.dob && v.dob > today() ? "Date of birth can't be in the future" : undefined,
  }));
  useUnsaved(f.dirty && !loading);
  const batch = sc.batches.find((b) => b.id === f.v.batchId);
  const subs = batch ? Object.keys(batch.subjectTeachers) : [];
  const save = async () => {
    f.touchAll(); if (!f.valid) return; setLoading(true);
    const id = ex?.id ?? uid("s");
    await uc.saveStudent({ id, inst: sc.instId, name: f.v.name.trim(), sid: f.v.sid.trim(), batchId: f.v.batchId, dob: f.v.dob, phone: f.v.phone, address: f.v.address, admDate: f.v.admDate, status: f.v.status as Student["status"], session: batch?.session ?? "", subjects: f.v.subjects });
    const g: Guardian = { id: g0?.id ?? uid("g"), inst: sc.instId, studentId: id, name: f.v.gName.trim(), relation: f.v.gRel, phone: f.v.gPhone, status: g0?.status ?? "pending", consent: g0?.consent ?? false, linked: g0?.linked ?? false };
    await uc.save("guardians", g);
    setLoading(false); toast(ex ? "Student updated" : "Student added"); back();
  };
  return (
    <Page title={ex ? "Edit student" : "Add student"} footer={<Btn loading={loading} disabled={!f.valid} onClick={save}>{ex ? "Save changes" : "Add student"}</Btn>}>
      <div className="space-y-4 pt-2">
        <TextInput label="Student name" required {...f.bind("name")} /><TextInput label="Student ID" required {...f.bind("sid")} />
        <DatePicker label="Date of birth" value={f.v.dob} onChange={(v) => f.set("dob", v)} max={today()} error={f.errors.dob} />
        <TextInput label="Student's phone" inputMode="tel" prefix="+91" maxLength={10} hint="Only if the student has their own number" {...f.bind("phone")} />
        <Section title="Guardian"><div className="space-y-4"><TextInput label="Guardian name" required {...f.bind("gName")} /><Select label="Relationship" options={["Father", "Mother", "Guardian", "Other"]} value={f.v.gRel} onChange={(v) => f.set("gRel", v)} /><TextInput label="Guardian mobile" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("gPhone")} /></div></Section>
        <Section title="Academics"><div className="space-y-4">
          <Select label="Batch" required options={sc.batches.map((b) => ({ value: b.id, label: b.name, sub: b.course }))} value={f.v.batchId} onChange={(v) => { f.set("batchId", v); f.set("subjects", Object.keys(sc.batches.find((b) => b.id === v)?.subjectTeachers ?? {})); }} error={f.errors.batchId && f.v.batchId === "" ? f.errors.batchId : undefined} />
          {subs.length ? <div><div className="mb-1.5 text-[13px] font-semibold">Subjects <span className="text-bad">*</span></div><div className="flex flex-wrap gap-2">{subs.map((s) => <button key={s} onClick={() => f.set("subjects", f.v.subjects.includes(s) ? f.v.subjects.filter((x) => x !== s) : [...f.v.subjects, s])} aria-pressed={f.v.subjects.includes(s)} className={`min-h-10 rounded-full border px-3.5 text-[13px] font-medium ${f.v.subjects.includes(s) ? "border-brand bg-brand text-white" : "border-line bg-white text-mute"}`}>{s}</button>)}</div></div> : null}
          <DatePicker label="Admission date" required value={f.v.admDate} onChange={(v) => f.set("admDate", v)} /><Select label="Status" options={["active", "inactive", "alumni"]} value={f.v.status} onChange={(v) => f.set("status", v)} />
          <TextInput label="Address" multiline rows={2} {...f.bind("address")} /></div></Section>
      </div>
    </Page>
  );
}

/* S23 */
function Student360({ params }: P) {
  const sc = useScope();
  const me = useMe();
  const { push, session } = useApp();
  const s = sc.students.find((x) => x.id === params.id) ?? sc.students[0];
  const [tab, setTab] = useState("overview");
  if (!s) return <Page title="Student"><Empty title="No students yet" /></Page>;
  const db = sc.db;
  const att = studentAtt(db, s.id), res = resultsFor(db, s.id), fee = feeSummary(db, s.id);
  const batch = sc.batches.find((b) => b.id === s.batchId);
  const hws = sc.homework.filter((h) => h.batchId === s.batchId && h.status === "published");
  const hwDone = hws.filter((h) => ["submitted", "reviewed"].includes(subFor(db, h, s.id).status)).length;
  const avg = res.length ? Math.round(res.reduce((a, r) => a + r.pct, 0) / res.length) : 0;
  const guardians = sc.guardians.filter((g) => g.studentId === s.id);
  const subsFb = db.submissions.filter((x) => x.studentId === s.id && x.feedback);
  const attempts = db.attempts.filter((a) => a.studentId === s.id);
  const timeline = [
    ...db.attLog.filter((l) => l.studentId === s.id).map((l) => ({ at: l.at, t: `Attendance corrected ${l.from}→${l.to} (${dmy(l.date)})` })),
    ...db.submissions.filter((x) => x.studentId === s.id).flatMap((x) => x.history.map((h) => ({ at: h.at, t: `${h.text}: ${sc.homework.find((hh) => hh.id === x.hwId)?.title}` }))),
    ...db.payments.filter((p) => p.studentId === s.id).map((p) => ({ at: p.date, t: `Payment ${inr(p.amount)} (demo) · ${p.method}` })),
    ...db.doubts.filter((d) => d.studentId === s.id).map((d) => ({ at: d.messages[0].at, t: `Doubt asked: ${d.title}` })),
  ].sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 12);
  return (
    <Page title="Student profile" right={<IconBtn icon={Pencil} label="Edit student" onClick={() => push("S22", { id: s.id })} />}>
      <Card className="mt-2"><div className="flex items-center gap-3"><Avatar name={s.name} size={56} /><div className="min-w-0 flex-1"><h2 className="text-[18px] font-bold leading-tight">{s.name}</h2><p className="text-[12.5px] text-mute">{s.sid} · {batch?.name}</p></div><StatusBadge status={s.status} /></div></Card>
      <div className="mt-3"><Tabs value={tab} onChange={setTab} options={[{ value: "overview", label: "Overview" }, { value: "attendance", label: "Attendance" }, { value: "homework", label: "Homework" }, { value: "exams", label: "Exams" }, { value: "practice", label: "Practice" }, { value: "feedback", label: "Feedback" }, { value: "fees", label: "Fees" }, { value: "timeline", label: "Timeline" }]} /></div>
      <div className="mt-3">
        {tab === "overview" && <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3"><Stat label="Attendance" value={`${att.pct}%`} tone={att.pct >= 85 ? "ok" : "warn"} sub={`${att.total} days recorded`} onClick={() => setTab("attendance")} /><Stat label="Exam average" value={res.length ? `${avg}%` : "—"} tone="violet" sub={`${res.length} results`} onClick={() => setTab("exams")} /><Stat label="Homework done" value={`${hwDone}/${hws.length}`} tone="sky" onClick={() => setTab("homework")} /><Stat label="Fee balance" value={fee ? inr(fee.outstanding) : "—"} tone={fee?.overdue ? "bad" : "mute"} onClick={() => setTab("fees")} /></div>
          <Card><Kv k="Date of birth" v={dmy(s.dob)} /><Kv k="Phone" v={s.phone ? `+91 ${s.phone}` : "—"} /><Kv k="Admission date" v={dmy(s.admDate)} /><Kv k="Address" v={s.address || "—"} /><Kv k="Subjects" v={s.subjects.join(", ")} /></Card>
          <Section title="Guardians" action="Manage" onAction={() => push("S24", { studentId: s.id })}><List>{guardians.map((g) => <Row key={g.id} icon={ShieldCheck} tone={g.status === "verified" ? "ok" : "warn"} title={g.name} sub={`${g.relation} · +91 ${g.phone}`} right={<StatusBadge status={g.status} />} noChevron />)}</List></Section></div>}
        {tab === "attendance" && <div className="space-y-3"><Card><div className="flex items-center gap-4"><Donut value={att.pct} tone={att.pct >= 85 ? "ok" : "warn"} sub="attended" /><div className="grid flex-1 grid-cols-3 text-center"><div><div className="text-[20px] font-bold text-ok">{att.p}</div><div className="text-[11px] text-mute">Present</div></div><div><div className="text-[20px] font-bold text-bad">{att.a}</div><div className="text-[11px] text-mute">Absent</div></div><div><div className="text-[20px] font-bold text-warn">{att.l}</div><div className="text-[11px] text-mute">Late</div></div></div></div><p className="mt-3 text-[12px] text-mute">Late arrivals count as attended.</p></Card>
          <List>{Object.entries(att.byDate).sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 10).map(([d, v]) => <Row key={d} title={`${longDate(d)}`} sub={dmy(d)} right={<AttPill status={v} />} noChevron />)}</List></div>}
        {tab === "homework" && (hws.length ? <div className="space-y-2.5">{hws.map((h) => <HomeworkCard key={h.id} h={h} status={subFor(db, h, s.id).status} />)}</div> : <Empty title="No homework assigned" />)}
        {tab === "exams" && (res.length ? <List>{res.map((r) => <Row key={r.exam.id} icon={GraduationCap} tone="violet" title={r.exam.name} sub={`${r.exam.subject} · ${dmy(r.exam.date)}`} right={<div className="text-right"><div className="text-[15px] font-bold">{r.marks}/{r.exam.max}</div><div className="text-[11.5px] text-mute">{r.pct}%</div></div>} noChevron />)}</List> : <Empty title="No published results" body="Results appear once published." />)}
        {tab === "practice" && (attempts.length ? <List>{attempts.map((a) => <Row key={a.id} icon={ClipboardList} tone="sky" title={`${a.subject} · ${a.topic}`} sub={`${a.chapter} · ${ago(a.at)}`} right={<Badge tone={a.score / a.total >= 0.7 ? "ok" : "warn"}>{a.score}/{a.total}</Badge>} noChevron />)}</List> : <Empty title="No practice yet" body="Practice attempts will appear here." />)}
        {tab === "feedback" && (subsFb.length ? <div className="space-y-2.5">{subsFb.map((x) => <Card key={x.id}><div className="text-[12px] text-mute">{sc.homework.find((h) => h.id === x.hwId)?.title}</div><p className="mt-1 text-[14px] leading-relaxed">“{x.feedback}”</p></Card>)}</div> : <Empty title="No feedback yet" />)}
        {tab === "fees" && (can(db, session.role, "fees.view") ? (fee ? <div className="space-y-3"><Card><Kv k="Structure" v={fee.fs.name} /><Kv k="Total (after discount)" v={inr(fee.total)} /><Kv k="Paid" v={inr(fee.paid)} /><Kv k="Outstanding" v={inr(fee.outstanding)} />{fee.acc.discount ? <Kv k={fee.acc.discountReason} v={`− ${inr(fee.acc.discount)}`} /> : null}</Card><Btn variant="secondary" onClick={() => push("S37", { studentId: s.id })}>Open ledger</Btn></div> : <Empty title="No fee structure assigned" />) : <Denied body="Fee details are hidden for your role. The institute owner can change this in permissions." />)}
        {tab === "timeline" && (timeline.length ? <Card><ol className="space-y-4">{timeline.map((t, i) => <li key={i} className="flex gap-3"><span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-brand" /><div><div className="text-[13.5px]">{t.t}</div><div className="text-[11.5px] text-mute">{ago(t.at)}</div></div></li>)}</ol></Card> : <Empty title="No activity yet" />)}
      </div>
    </Page>
  );
}

/* S24 */
function GuardianLinking({ params }: P) {
  const sc = useScope();
  const { toast, confirm } = useApp();
  const [sid, setSid] = useState<string>(params.studentId ?? sc.students.find((s) => s.id === "s1")?.id ?? sc.students[0]?.id ?? "");
  const [add, setAdd] = useState(false);
  const [verify, setVerify] = useState<Guardian | null>(null);
  const [code, setCode] = useState("");
  const [consent, setConsent] = useState(false);
  const gs = sc.guardians.filter((g) => g.studentId === sid);
  const f = useForm({ name: "", rel: "Mother", phone: "" }, (v) => ({ name: v.name.trim().length < 2 ? "Enter guardian name" : undefined, phone: validPhone(v.phone) ? undefined : "Enter a valid mobile number" }));
  return (
    <Page title="Guardian linking" subtitle="Verify before sharing records" right={<IconBtn icon={Plus} label="Add guardian" tone="soft" onClick={() => setAdd(true)} />}>
      <div className="space-y-3 pt-2">
        <Banner tone="warn" icon={ShieldCheck}>An unverified guardian can never see a child's private records. Verification needs the guardian's code <b>and</b> consent.</Banner>
        <Select label="Student" options={sc.students.map((s) => ({ value: s.id, label: s.name, sub: s.sid }))} value={sid} onChange={setSid} />
        {gs.length === 0 ? <Empty icon={ShieldOff} title="No guardian linked" body="Add a guardian to send an invitation." action="Add guardian" onAction={() => setAdd(true)} /> : gs.map((g) => (
          <Card key={g.id}><div className="flex items-start gap-3"><Avatar name={g.name} tone="violet" /><div className="min-w-0 flex-1"><div className="text-[15px] font-semibold">{g.name}</div><div className="text-[12.5px] text-mute">{g.relation} · +91 {g.phone}</div></div><StatusBadge status={g.status} /></div>
            <div className="mt-3 divide-y divide-line"><Kv k="Invitation" v={g.invitedAt ? `Sent ${ago(g.invitedAt)}` : g.status === "verified" ? "Accepted" : "Not sent"} /><Kv k="Verification" v={g.status === "verified" ? "Verified" : "Pending"} /><Kv k="Guardian consent" v={g.consent ? "Given" : "Not given"} /><Kv k="Can see child's records" v={g.status === "verified" && g.consent ? "Yes" : "No"} /></div>
            <div className="mt-3 flex flex-wrap gap-2">
              {g.status !== "verified" ? <><Btn size="sm" variant="secondary" full={false} icon={Send} onClick={async () => { await uc.inviteGuardian(g); toast(g.status === "invited" ? "Invitation re-sent (demo — no SMS)" : "Invitation sent (demo — no SMS)", "info"); }}>{g.status === "invited" ? "Resend invite" : "Send invite"}</Btn><Btn size="sm" full={false} icon={BadgeCheck} onClick={() => { setVerify(g); setCode(""); setConsent(false); }}>Verify</Btn></> : <Btn size="sm" variant="secondary" full={false} onClick={() => confirm({ title: "Revoke guardian access?", body: `${g.name} will immediately lose access to ${sc.students.find((s) => s.id === sid)?.name}'s records.`, confirmLabel: "Revoke", danger: true, onConfirm: async () => { await uc.revokeGuardian(g); toast("Access revoked", "info"); } })}>Revoke access</Btn>}
            </div></Card>))}
      </div>
      <Sheet open={add} onClose={() => setAdd(false)} title="Add guardian"><div className="space-y-4"><TextInput label="Name" required {...f.bind("name")} /><Select label="Relationship" options={["Father", "Mother", "Guardian", "Other"]} value={f.v.rel} onChange={(v) => f.set("rel", v)} /><TextInput label="Mobile number" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("phone")} />
        <Btn disabled={!f.valid} onClick={async () => { await uc.inviteGuardian({ id: uid("g"), inst: sc.instId, studentId: sid, name: f.v.name.trim(), relation: f.v.rel, phone: f.v.phone, status: "pending", consent: false, linked: false }); setAdd(false); f.setV({ name: "", rel: "Mother", phone: "" }); toast("Guardian added and invited (demo)", "info"); }}>Add & send invite</Btn></div></Sheet>
      <Sheet open={!!verify} onClose={() => setVerify(null)} title="Verify guardian"><div className="space-y-4"><p className="text-[13.5px] text-mute">Ask <b className="text-ink">{verify?.name}</b> for the 6-digit code from their invitation. Demo code: <b>{DEMO_OTP}</b>.</p><TextInput label="Verification code" inputMode="numeric" maxLength={6} value={code} onChange={setCode} placeholder="6-digit code" /><Checkbox checked={consent} onChange={setConsent}>The guardian has consented to view this child's attendance, results, homework and fees.</Checkbox>
        <Btn disabled={code !== DEMO_OTP || !consent} onClick={async () => { if (verify) await uc.verifyGuardian(verify); setVerify(null); toast("Guardian verified"); }}>Verify & grant access</Btn></div></Sheet>
    </Page>
  );
}

/* Staff form (shared by S25 add and S26 edit) */
export function StaffForm({ open, onClose, ex }: { open: boolean; onClose: () => void; ex?: Staff }) {
  const sc = useScope();
  const { toast } = useApp();
  const f = useForm({ name: ex?.name ?? "", role: ex?.role ?? "Teacher", phone: ex?.phone ?? "", email: ex?.email ?? "", subjects: ex?.subjects ?? ([] as string[]), status: (ex?.status ?? "active") as string }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter full name" : undefined, phone: validPhone(v.phone) ? undefined : "Enter a valid mobile number", email: validEmail(v.email) ? undefined : "Enter a valid email", subjects: v.subjects.length ? undefined : "Pick at least one subject",
  }));
  return (
    <Sheet open={open} onClose={onClose} title={ex ? "Edit staff" : "Add staff"}>
      <div className="space-y-4"><TextInput label="Full name" required {...f.bind("name")} /><Select label="Role" options={["Teacher", "Senior Teacher", "Coordinator", "Accountant"]} value={f.v.role} onChange={(v) => f.set("role", v)} />
        <TextInput label="Mobile" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("phone")} /><TextInput label="Email" required inputMode="email" {...f.bind("email")} />
        <div><div className="mb-1.5 text-[13px] font-semibold">Subjects <span className="text-bad">*</span></div><div className="flex flex-wrap gap-2">{sc.subjects.map((s) => <button key={s.id} onClick={() => f.set("subjects", f.v.subjects.includes(s.name) ? f.v.subjects.filter((x) => x !== s.name) : [...f.v.subjects, s.name])} className={`min-h-10 rounded-full border px-3.5 text-[13px] font-medium ${f.v.subjects.includes(s.name) ? "border-brand bg-brand text-white" : "border-line bg-white text-mute"}`}>{s.name}</button>)}</div></div>
        <Select label="Employment status" options={["active", "on-leave", "inactive"]} value={f.v.status} onChange={(v) => f.set("status", v)} />
        <Btn disabled={!f.valid} onClick={async () => { await uc.save("staff", { id: ex?.id ?? uid("st"), inst: sc.instId, name: f.v.name.trim(), role: f.v.role, subjects: f.v.subjects, batchIds: ex?.batchIds ?? [], status: f.v.status as Staff["status"], phone: f.v.phone, email: f.v.email, joined: ex?.joined ?? today(), weeklyHours: ex?.weeklyHours ?? 0 }); toast(ex ? "Staff updated" : "Staff added"); onClose(); }}>{ex ? "Save changes" : "Add staff"}</Btn></div>
    </Sheet>
  );
}

/* S25 */
function StaffDirectory(_: P) {
  const sc = useScope();
  const { push, session } = useApp();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("All");
  const [subj, setSubj] = useState("All");
  const [add, setAdd] = useState(false);
  const list = sc.staff.filter((s) => (status === "All" || s.status === status) && (subj === "All" || s.subjects.includes(subj)) && (s.name + s.subjects.join()).toLowerCase().includes(q.toLowerCase()));
  const canManage = can(sc.db, session.role, "staff.manage");
  return (
    <Page title="Staff" subtitle={`${list.length} members`} right={canManage ? <IconBtn icon={Plus} label="Add staff" tone="soft" onClick={() => setAdd(true)} /> : undefined}>
      <div className="space-y-2 pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search staff or subject" /><Chips value={status} onChange={setStatus} options={["All", "active", "on-leave", "inactive"]} /><Chips value={subj} onChange={setSubj} options={["All", ...sc.subjects.map((s) => s.name)]} /></div>
      {list.length === 0 ? <Empty icon={Users} title="No staff found" body="Try different filters." action="Clear" onAction={() => { setQ(""); setStatus("All"); setSubj("All"); }} /> : <div className="mt-3 space-y-2.5">{list.map((t) => <div key={t.id}><TeacherCard t={t} onClick={() => push("S26", { id: t.id })} /><div className="px-2 pt-1 text-[11.5px] text-mute">{t.batchIds.map((b) => sc.batches.find((x) => x.id === b)?.name.split(" – ")[0]).join(" · ") || "No batches assigned"}</div></div>)}</div>}
      <StaffForm open={add} onClose={() => setAdd(false)} />
    </Page>
  );
}

/* S26 */
function StaffProfile({ params }: P) {
  const sc = useScope();
  const { toast, confirm, session } = useApp();
  const t = sc.staff.find((x) => x.id === params.id) ?? sc.staff[0];
  const [tab, setTab] = useState("overview");
  const [edit, setEdit] = useState(false);
  const [sub, setSub] = useState<string>("");
  const [dec, setDec] = useState<string | null>(null);
  if (!t) return <Page title="Staff"><Empty title="No staff yet" /></Page>;
  const tt = sc.timetable.filter((e) => e.teacherId === t.id);
  const leaves = sc.leaves.filter((l) => l.kind === "staff" && l.personId === t.id);
  const approvedDays = leaves.filter((l) => l.status === "approved").reduce((a, l) => a + (new Date(l.to).getTime() - new Date(l.from).getTime()) / 86400000 + 1, 0);
  return (
    <Page title="Staff profile" right={can(sc.db, session.role, "staff.manage") ? <IconBtn icon={Pencil} label="Edit staff" onClick={() => setEdit(true)} /> : undefined}>
      <Card className="mt-2"><div className="flex items-center gap-3"><Avatar name={t.name} size={56} tone="violet" /><div className="min-w-0 flex-1"><h2 className="text-[18px] font-bold">{t.name}</h2><p className="text-[12.5px] text-mute">{t.role} · Joined {dmy(t.joined)}</p></div><StatusBadge status={t.status} /></div>
        <div className="mt-3 flex gap-2"><Btn size="sm" variant="soft" icon={Phone} onClick={() => toast(`Demo: calling +91 ${t.phone}`, "info")}>Call</Btn></div></Card>
      <div className="mt-3"><Tabs value={tab} onChange={setTab} options={[{ value: "overview", label: "Overview" }, { value: "timetable", label: "Timetable" }, { value: "workload", label: "Workload" }, { value: "leave", label: "Leave" }]} /></div>
      <div className="mt-3">
        {tab === "overview" && <div className="space-y-3"><Card><Kv k="Mobile" v={`+91 ${t.phone}`} /><Kv k="Email" v={t.email} /><Kv k="Subjects" v={t.subjects.join(", ")} /></Card><Section title="Assigned batches"><List>{t.batchIds.map((b) => <Row key={b} icon={BookOpen} title={sc.batches.find((x) => x.id === b)?.name ?? b} sub={sc.batches.find((x) => x.id === b)?.course} noChevron />)}</List></Section></div>}
        {tab === "timetable" && (tt.length ? [1, 2, 3, 4, 5, 6].map((d) => { const es = tt.filter((e) => e.day === d).sort((a, b) => (a.start < b.start ? -1 : 1)); return es.length ? <div key={d} className="mb-3"><div className="mb-1.5 text-[13px] font-semibold">{DAYS_LONG[d]}</div><List>{es.map((e) => <Row key={e.id} icon={Clock} title={`${e.subject} · ${sc.batches.find((b) => b.id === e.batchId)?.name.split(" – ")[0]}`} sub={`${time12(e.start)} – ${time12(e.end)} · ${sc.rooms.find((r) => r.id === e.roomId)?.name}`} noChevron />)}</List></div> : null; }) : <Empty title="No classes scheduled" />)}
        {tab === "workload" && <div className="space-y-3"><Card><div className="flex items-center justify-between"><span className="text-[13px] text-mute">Weekly teaching hours</span><b className="text-[17px]">{t.weeklyHours} h</b></div><div className="mt-2"><Progress value={(t.weeklyHours / 24) * 100} tone={t.weeklyHours > 18 ? "warn" : "brand"} label="Workload" /></div><p className="mt-2 text-[12px] text-mute">Out of a 24-hour recommended weekly maximum · {tt.length} periods per week</p></Card><Card><Kv k="Approved leave days (all time)" v={`${approvedDays}`} /><Kv k="Attendance this month" v={`${Math.max(0, 24 - Math.round(approvedDays))} of 24 working days`} /></Card></div>}
        {tab === "leave" && (leaves.length ? <div className="space-y-2.5">{leaves.map((l) => <Card key={l.id}><div className="flex items-start justify-between gap-2"><div><div className="text-[14.5px] font-semibold">{dmy(l.from)} – {dmy(l.to)}</div><div className="text-[12.5px] text-mute">{l.reason}</div>{l.substitute ? <div className="mt-1 text-[12px] text-ink">Substitute: <b>{l.substitute}</b></div> : null}</div><StatusBadge status={l.status} /></div>
          {l.status === "pending" ? <div className="mt-3 flex gap-2"><Btn size="sm" variant="secondary" onClick={() => confirm({ title: "Reject this leave?", confirmLabel: "Reject", danger: true, onConfirm: async () => { await uc.decideLeave(l.id, "rejected"); toast("Leave rejected", "info"); } })}>Reject</Btn><Btn size="sm" onClick={() => setDec(l.id)}>Approve</Btn></div> : null}</Card>)}</div> : <Empty title="No leave history" />)}
      </div>
      <StaffForm open={edit} onClose={() => setEdit(false)} ex={t} />
      <Sheet open={!!dec} onClose={() => setDec(null)} title="Approve leave"><div className="space-y-4"><Select label="Substitute teacher" options={sc.staff.filter((s) => s.id !== t.id && s.status === "active").map((s) => s.name)} value={sub} onChange={setSub} placeholder="Choose a substitute" /><Btn disabled={!sub} onClick={async () => { await uc.decideLeave(dec!, "approved", sub); setDec(null); toast("Leave approved"); }}>Approve with substitute</Btn></div></Sheet>
    </Page>
  );
}

/* S27 */
function Sessions(_: P) {
  const sc = useScope();
  const { toast, confirm } = useApp();
  const [add, setAdd] = useState(false);
  const f = useForm({ label: "", start: "", end: "" }, (v) => ({ label: v.label.trim() ? undefined : "Enter a label like 2027–28", start: v.start ? undefined : "Pick a start date", end: !v.end ? "Pick an end date" : v.end <= v.start ? "End date must be after the start date" : undefined }));
  const cur = sc.sessions.find((s) => s.active);
  return (
    <Page title="Academic sessions" right={<IconBtn icon={Plus} label="Create session" tone="soft" onClick={() => setAdd(true)} />}>
      <div className="space-y-3 pt-2">
        {cur ? <Card className="!bg-brand !text-white"><div className="text-[12px] text-white/70">Current session</div><div className="mt-1 text-[24px] font-bold">{cur.label}</div><div className="text-[13px] text-white/80">{dmy(cur.start)} – {dmy(cur.end)}</div></Card> : <Banner tone="warn">No active session. Create one to start.</Banner>}
        <Section title="All sessions"><List>{sc.sessions.slice().sort((a, b) => (a.start < b.start ? 1 : -1)).map((s) => <Row key={s.id} icon={Calendar} tone={s.active ? "ok" : "mute"} title={s.label} sub={`${dmy(s.start)} – ${dmy(s.end)} · ${sc.batches.filter((b) => b.session === s.id).length} batches`} right={s.active ? <Badge tone="ok">Active</Badge> : <Btn size="sm" variant="secondary" full={false} onClick={() => confirm({ title: `Switch to ${s.label}?`, body: "This becomes the active session. Other sessions become inactive but their records are kept.", confirmLabel: "Switch", onConfirm: async () => { for (const x of sc.sessions) await uc.save("sessions", { ...x, active: x.id === s.id }); toast(`${s.label} is now active`); } })}>Activate</Btn>} noChevron />)}</List></Section>
      </div>
      <Sheet open={add} onClose={() => setAdd(false)} title="Create session"><div className="space-y-4"><TextInput label="Session label" required placeholder="2027–28" {...f.bind("label")} /><DatePicker label="Start date" required value={f.v.start} onChange={(v) => f.set("start", v)} error={f.errors.start && f.v.start === "" ? undefined : undefined} /><DatePicker label="End date" required value={f.v.end} onChange={(v) => f.set("end", v)} error={f.v.end ? f.errors.end : undefined} />
        <Btn disabled={!f.valid} onClick={async () => { await uc.save("sessions", { id: uid("ss"), inst: sc.instId, label: f.v.label, start: f.v.start, end: f.v.end, active: false }); setAdd(false); f.setV({ label: "", start: "", end: "" }); toast("Session created"); }}>Create session</Btn></div></Sheet>
    </Page>
  );
}

/* Batch form */
export function BatchForm({ open, onClose, ex }: { open: boolean; onClose: () => void; ex?: Batch }) {
  const sc = useScope();
  const { toast } = useApp();
  const f = useForm({ name: ex?.name ?? "", course: ex?.course ?? "", session: ex?.session ?? sc.sessions.find((s) => s.active)?.id ?? "", roomId: ex?.roomId ?? "", status: (ex?.status ?? "active") as string, st: ex?.subjectTeachers ?? ({} as Record<string, string>) }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter batch name" : undefined, course: v.course.trim() ? undefined : "Enter the course", session: v.session ? undefined : "Choose session", roomId: v.roomId ? undefined : "Choose a classroom", st: Object.keys(v.st).length ? undefined : "Add at least one subject",
  }));
  const subjects = sc.subjects.map((s) => s.name);
  return (
    <Sheet open={open} onClose={onClose} title={ex ? "Edit batch" : "Create batch"}>
      <div className="space-y-4"><TextInput label="Batch name" required placeholder="e.g. Class 9 – Science (Morning)" {...f.bind("name")} /><TextInput label="Course" required {...f.bind("course")} />
        <Select label="Academic session" required options={sc.sessions.map((s) => ({ value: s.id, label: s.label }))} value={f.v.session} onChange={(v) => f.set("session", v)} /><Select label="Primary classroom" required options={sc.rooms.map((r) => ({ value: r.id, label: r.name, sub: `Capacity ${r.capacity}` }))} value={f.v.roomId} onChange={(v) => f.set("roomId", v)} />
        <div><div className="mb-1.5 text-[13px] font-semibold">Subjects & teachers <span className="text-bad">*</span></div>
          <div className="space-y-2">{subjects.map((s) => { const on = s in f.v.st; return <div key={s} className="rounded-xl border border-line p-2.5"><Checkbox checked={on} onChange={(v) => { const n = { ...f.v.st }; if (v) n[s] = sc.staff.find((t) => t.subjects.includes(s))?.id ?? ""; else delete n[s]; f.set("st", n); }}>{s}</Checkbox>{on ? <div className="mt-2"><Select options={sc.staff.filter((t) => t.subjects.includes(s)).map((t) => ({ value: t.id, label: t.name }))} value={f.v.st[s]} onChange={(v) => f.set("st", { ...f.v.st, [s]: v })} placeholder="Assign teacher" /></div> : null}</div>; })}</div></div>
        <Select label="Status" options={["active", "inactive"]} value={f.v.status} onChange={(v) => f.set("status", v)} />
        <Btn disabled={!f.valid} onClick={async () => { await uc.save("batches", { id: ex?.id ?? uid("b"), inst: sc.instId, name: f.v.name.trim(), course: f.v.course.trim(), session: f.v.session, roomId: f.v.roomId, status: f.v.status as Batch["status"], subjectTeachers: f.v.st }); toast(ex ? "Batch updated" : "Batch created"); onClose(); }}>{ex ? "Save changes" : "Create batch"}</Btn></div>
    </Sheet>
  );
}

/* S28 */
function Batches(_: P) {
  const sc = useScope();
  const { push } = useApp();
  const [q, setQ] = useState("");
  const [st, setSt] = useState("All");
  const [sess, setSess] = useState("All");
  const [add, setAdd] = useState(false);
  const list = sc.batches.filter((b) => (st === "All" || b.status === st) && (sess === "All" || b.session === sess) && (b.name + b.course).toLowerCase().includes(q.toLowerCase()));
  return (
    <Page title="Batches" subtitle={`${list.length} batches`} right={<IconBtn icon={Plus} label="Create batch" tone="soft" onClick={() => setAdd(true)} />}>
      <div className="space-y-2 pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search batch or course" /><Chips value={st} onChange={setSt} options={["All", "active", "inactive"]} /><Chips value={sess} onChange={setSess} options={[{ value: "All", label: "All sessions" }, ...sc.sessions.map((s) => ({ value: s.id, label: s.label }))]} /></div>
      {list.length === 0 ? <Empty icon={BookOpen} title="No batches" body="Create a batch to organise students and timetable." action="Create batch" onAction={() => setAdd(true)} /> : <div className="mt-3 space-y-2.5">{list.map((b) => <BatchCard key={b.id} b={b} count={sc.students.filter((s) => s.batchId === b.id).length} onClick={() => push("S29", { id: b.id })} extra={<div className="mt-1 text-[12px] text-mute">{Object.entries(b.subjectTeachers).map(([s, t]) => `${s} (${sc.staff.find((x) => x.id === t)?.name.split(" ")[0] ?? "—"})`).join(" · ")}</div>} />)}</div>}
      <BatchForm open={add} onClose={() => setAdd(false)} />
    </Page>
  );
}

/* S29 */
function BatchDetail({ params }: P) {
  const sc = useScope();
  const { push, toast } = useApp();
  const b = sc.batches.find((x) => x.id === params.id) ?? sc.batches[0];
  const [tab, setTab] = useState("roster");
  const [edit, setEdit] = useState(false);
  const [assign, setAssign] = useState(false);
  const [pick, setPick] = useState("");
  if (!b) return <Page title="Batch"><Empty title="No batches" /></Page>;
  const roster = sc.students.filter((s) => s.batchId === b.id);
  const a = batchAttOn(sc.db, b.id, today());
  const tt = sc.timetable.filter((e) => e.batchId === b.id);
  const week = Array.from({ length: 7 }, (_, i) => addDays(-6 + i));
  const wk = week.map((d) => batchAttOn(sc.db, b.id, d)).filter((x) => x.marked);
  const res = sc.resources.filter((r) => r.batchIds.includes(b.id));
  return (
    <Page title="Batch details" right={<IconBtn icon={Pencil} label="Edit batch" onClick={() => setEdit(true)} />}>
      <Card className="mt-2"><div className="flex items-start justify-between gap-2"><div><h2 className="text-[17px] font-bold leading-snug">{b.name}</h2><p className="text-[12.5px] text-mute">{b.course} · {sc.rooms.find((r) => r.id === b.roomId)?.name} · {sc.sessions.find((s) => s.id === b.session)?.label}</p></div><StatusBadge status={b.status} /></div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-center"><div className="rounded-xl bg-bg py-2"><div className="text-[18px] font-bold">{roster.length}</div><div className="text-[11px] text-mute">Students</div></div><div className="rounded-xl bg-bg py-2"><div className="text-[18px] font-bold">{Object.keys(b.subjectTeachers).length}</div><div className="text-[11px] text-mute">Subjects</div></div><div className="rounded-xl bg-bg py-2"><div className="text-[18px] font-bold">{tt.length}</div><div className="text-[11px] text-mute">Weekly classes</div></div></div></Card>
      <div className="mt-3"><Tabs value={tab} onChange={setTab} options={[{ value: "roster", label: "Roster" }, { value: "teachers", label: "Teachers" }, { value: "timetable", label: "Timetable" }, { value: "attendance", label: "Attendance" }, { value: "resources", label: "Resources" }]} /></div>
      <div className="mt-3">
        {tab === "roster" && <div className="space-y-2.5"><Btn variant="secondary" size="sm" icon={Plus} onClick={() => setAssign(true)}>Assign student to this batch</Btn>{roster.length ? roster.map((s) => <StudentCard key={s.id} s={s} onClick={() => push("S23", { id: s.id })} />) : <Empty title="No students in this batch" />}</div>}
        {tab === "teachers" && <List>{Object.entries(b.subjectTeachers).map(([sub, tid]) => { const t = sc.staff.find((x) => x.id === tid); return <Row key={sub} lead={<Avatar name={t?.name ?? "?"} tone="violet" />} title={t?.name ?? "Unassigned"} sub={sub} onClick={t ? () => push("S26", { id: t.id }) : undefined} />; })}</List>}
        {tab === "timetable" && (tt.length ? [1, 2, 3, 4, 5, 6].map((d) => <div key={d} className="mb-3"><div className="mb-1 text-[13px] font-semibold">{DAYS_LONG[d]}</div><List>{tt.filter((e) => e.day === d).sort((x, y) => (x.start < y.start ? -1 : 1)).map((e) => <Row key={e.id} icon={Clock} title={e.subject} sub={`${time12(e.start)} – ${time12(e.end)} · ${sc.staff.find((s) => s.id === e.teacherId)?.name}`} noChevron />)}</List></div>) : <Empty title="No classes scheduled" action="Open timetable" onAction={() => push("S31")} />)}
        {tab === "attendance" && <div className="space-y-3"><Card><div className="text-[13px] text-mute">Today</div>{a.marked ? <div className="mt-1 flex gap-4 text-[14px]"><span><b className="text-ok">{a.p}</b> present</span><span><b className="text-bad">{a.a}</b> absent</span><span><b className="text-warn">{a.l}</b> late</span></div> : <p className="mt-1 text-[14px] text-warn">Not marked yet</p>}</Card>{wk.length ? <Card><div className="mb-2 text-[13px] font-semibold">Last 7 days</div><Bars height={70} suffix="%" data={wk.map((x, i) => ({ label: dmy(week.filter((d) => batchAttOn(sc.db, b.id, d).marked)[i]).slice(0, 5), value: pct(x.p + x.l, x.marked), tone: "ok" as const }))} max={100} /></Card> : null}<Btn variant="secondary" onClick={() => push("S32", { batchId: b.id })}>Open attendance report</Btn></div>}
        {tab === "resources" && (res.length ? <List>{res.map((r) => <Row key={r.id} icon={BookOpen} title={r.title} sub={`${r.subject} · ${r.type.toUpperCase()}`} onClick={() => push("S38", { id: r.id })} />)}</List> : <Empty title="No resources shared" />)}
      </div>
      <BatchForm open={edit} onClose={() => setEdit(false)} ex={b} />
      <Sheet open={assign} onClose={() => setAssign(false)} title="Assign student"><div className="space-y-4"><Select label="Student" options={sc.students.filter((s) => s.batchId !== b.id).map((s) => ({ value: s.id, label: s.name, sub: bn(sc.batches, s.batchId) }))} value={pick} onChange={setPick} placeholder="Choose a student" /><Btn disabled={!pick} onClick={async () => { const s = sc.students.find((x) => x.id === pick)!; await uc.saveStudent({ ...s, batchId: b.id, session: b.session, subjects: Object.keys(b.subjectTeachers) }); setAssign(false); setPick(""); toast(`${s.name} moved to this batch`); }}>Move to batch</Btn></div></Sheet>
    </Page>
  );
}
const bn = (batches: Batch[], id: string) => batches.find((b) => b.id === id)?.name ?? "";

/* S30 */
function SubjectsRooms(_: P) {
  const sc = useScope();
  const { toast, confirm } = useApp();
  const [tab, setTab] = useState<"subjects" | "rooms">("subjects");
  const [sheet, setSheet] = useState<null | { kind: "subject" | "room"; id?: string }>(null);
  const [open, setOpen] = useState<string | null>(null);
  const sub = sheet?.kind === "subject" ? sc.subjects.find((s) => s.id === sheet.id) : undefined;
  const room = sheet?.kind === "room" ? sc.rooms.find((r) => r.id === sheet.id) : undefined;
  const f = useForm({ name: "", code: "", cap: "30", kind: "Classroom" });
  const [seed, setSeed] = useState("");
  const key = `${sheet?.kind}${sheet?.id}`;
  if (seed !== key) { setSeed(key); f.setV({ name: sub?.name ?? room?.name ?? "", code: sub?.code ?? "", cap: String(room?.capacity ?? 30), kind: room?.kind ?? "Classroom" }); }
  const valid = f.v.name.trim().length >= 2 && (sheet?.kind === "subject" ? f.v.code.trim().length >= 2 : Number(f.v.cap) > 0);
  const now = new Date(); const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const inUse = (rid: string) => sc.timetable.find((e) => e.roomId === rid && e.day === now.getDay() && e.start <= hhmm && hhmm < e.end);
  return (
    <Page title="Subjects & classrooms" right={<IconBtn icon={Plus} label={tab === "subjects" ? "Add subject" : "Add classroom"} tone="soft" onClick={() => setSheet({ kind: tab === "subjects" ? "subject" : "room" })} />}>
      <div className="pt-2"><Segmented value={tab} onChange={setTab} options={[{ value: "subjects", label: "Subjects" }, { value: "rooms", label: "Classrooms" }]} /></div>
      <div className="mt-3 space-y-2.5">
        {tab === "subjects" ? (sc.subjects.length ? sc.subjects.map((s) => { const bs = sc.batches.filter((b) => s.name in b.subjectTeachers); return (
          <Card key={s.id} className="!p-0"><button onClick={() => setOpen(open === s.id ? null : s.id)} className="flex w-full items-center gap-3 p-3.5 text-left"><IconTile icon={BookOpen} /><div className="min-w-0 flex-1"><div className="text-[15px] font-semibold">{s.name}</div><div className="text-[12.5px] text-mute">{s.code} · {bs.length} batches</div></div><ChevronDown size={18} className={`text-mute transition-transform ${open === s.id ? "rotate-180" : ""}`} /></button>
            {open === s.id ? <div className="anim-fade border-t border-line p-3.5"><div className="space-y-1.5">{bs.length ? bs.map((b) => <div key={b.id} className="flex justify-between text-[13px]"><span>{b.name.split(" – ")[0]}</span><b>{sc.staff.find((t) => t.id === b.subjectTeachers[s.name])?.name}</b></div>) : <p className="text-[13px] text-mute">Not used in any batch yet.</p>}</div>
              <div className="mt-3 flex gap-2"><Btn size="sm" variant="secondary" icon={Pencil} onClick={() => setSheet({ kind: "subject", id: s.id })}>Edit</Btn><Btn size="sm" variant="secondary" icon={Trash2} disabled={bs.length > 0} onClick={() => confirm({ title: `Delete ${s.name}?`, body: "This removes the subject from the institute.", confirmLabel: "Delete", danger: true, onConfirm: async () => { await uc.remove("subjects", s.id); toast("Subject deleted", "info"); } })}>Delete</Btn></div>{bs.length ? <p className="mt-2 text-[11.5px] text-mute">Subjects used by a batch can't be deleted.</p> : null}</div> : null}</Card>); }) : <Empty title="No subjects" action="Add subject" onAction={() => setSheet({ kind: "subject" })} />)
        : sc.rooms.map((r) => { const u = inUse(r.id); return (
          <Card key={r.id}><div className="flex items-center gap-3"><IconTile icon={DoorOpen} tone="violet" /><div className="min-w-0 flex-1"><div className="text-[15px] font-semibold">{r.name}</div><div className="text-[12.5px] text-mute">{r.kind} · Capacity {r.capacity}</div></div>{u ? <Badge tone="warn">In use now</Badge> : <Badge tone="ok">Available</Badge>}</div>
            {u ? <p className="mt-2 text-[12.5px] text-mute">{u.subject} · {sc.batches.find((b) => b.id === u.batchId)?.name.split(" – ")[0]} until {time12(u.end)}</p> : null}
            <div className="mt-3 flex gap-2"><Btn size="sm" variant="secondary" icon={Pencil} onClick={() => setSheet({ kind: "room", id: r.id })}>Edit</Btn><Btn size="sm" variant="secondary" icon={Trash2} disabled={sc.batches.some((b) => b.roomId === r.id)} onClick={() => confirm({ title: `Delete ${r.name}?`, confirmLabel: "Delete", danger: true, onConfirm: async () => { await uc.remove("rooms", r.id); toast("Classroom deleted", "info"); } })}>Delete</Btn></div></Card>); })}
      </div>
      <Sheet open={!!sheet} onClose={() => setSheet(null)} title={`${sheet?.id ? "Edit" : "Add"} ${sheet?.kind === "room" ? "classroom" : "subject"}`}>
        <div className="space-y-4"><TextInput label="Name" required value={f.v.name} onChange={(v) => f.set("name", v)} />
          {sheet?.kind === "subject" ? <TextInput label="Code" required maxLength={5} value={f.v.code} onChange={(v) => f.set("code", v.toUpperCase())} /> : <><TextInput label="Capacity" required inputMode="numeric" value={f.v.cap} onChange={(v) => f.set("cap", v.replace(/\D/g, ""))} /><Select label="Type" options={["Classroom", "Laboratory", "Hall"]} value={f.v.kind} onChange={(v) => f.set("kind", v)} /></>}
          <Btn disabled={!valid} onClick={async () => { if (sheet?.kind === "subject") await uc.save("subjects", { id: sheet.id ?? uid("sb"), inst: sc.instId, name: f.v.name.trim(), code: f.v.code }); else await uc.save("rooms", { id: sheet?.id ?? uid("r"), inst: sc.instId, name: f.v.name.trim(), capacity: Number(f.v.cap), kind: f.v.kind }); toast("Saved"); setSheet(null); }}>Save</Btn></div>
      </Sheet>
    </Page>
  );
}

export const ownerA: ScreenMap = {
  S16: def("Owner Dashboard", "owner", OwnerDashboard), S17: def("Admissions Overview", "owner", Admissions), S18: def("Enquiry Pipeline", "owner", Pipeline), S19: def("Add / Edit Enquiry", "owner", EnquiryForm),
  S20: def("Enquiry Details", "owner", EnquiryDetail), S21: def("Student Directory", "owner", StudentDirectory), S22: def("Add / Edit Student", "owner", StudentForm), S23: def("Student 360 Profile", "owner", Student360),
  S24: def("Guardian Linking / Verification", "owner", GuardianLinking), S25: def("Staff Directory", "owner", StaffDirectory), S26: def("Staff Profile", "owner", StaffProfile), S27: def("Academic Sessions", "owner", Sessions),
  S28: def("Batches / Classes", "owner", Batches), S29: def("Batch Details / Roster", "owner", BatchDetail), S30: def("Subjects / Classrooms", "owner", SubjectsRooms),
};
export { Download, Building, Megaphone, Wallet, Receipt, Trash2, CalendarPlus, IconTile };
