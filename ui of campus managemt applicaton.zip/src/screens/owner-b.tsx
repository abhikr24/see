"use client";
import React, { useMemo, useState } from "react";
import { Archive, Calendar, Copy, Download, Edit3, Eye, FileText, FolderOpen, GraduationCap, IndianRupee, Link2, Megaphone, Pencil, Plus, Receipt, RotateCcw, Search, Settings2, ShieldCheck, Trash2, Undo2, UserX, Wallet, Clock, AlertTriangle, CheckCircle2, Plug, Ban } from "lucide-react";
import type { Batch, Exam, FeeStructure, Notice, Payment, Resource, Role, TimetableEntry } from "@/domain/types";
import { useApp, useScope, useMe } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Chips, DemoTag, Denied, Divider, Empty, IconBtn, IconTile, Kv, List, Page, Progress, Row, Section, Segmented, Sheet, Stat, Tabs, Tone } from "@/ui/kit";
import { Checkbox, DatePicker, FilePicker, FileItem, Select, SearchInput, Switch, TextInput, TimePicker, useForm, fileIcon } from "@/ui/forms";
import { AttPill, Bars, Donut, LineChart, StackBar } from "@/ui/charts";
import { ExamCard, NoticeCard, StatusBadge, label as lab } from "@/ui/cards";
import { def, P, ScreenMap } from "./types";
import { addDays, ago, dmy, DAYS, DAYS_LONG, dtLabel, fileSize, inr, longDate, nowISO, parse, pct, relDay, time12, today, uid, validPhone } from "@/lib/fmt";
import { batchAttOn, can, examStats, feeSummary, findConflict, instAttToday, PERMS, resultsFor, ROLE_LABEL, studentAtt, subFor } from "@/features/selectors";
import { batchPerformance, instFees, monthlyCollection } from "@/features/aggregates";
import { uc } from "@/features/usecases";

/* S31 */
function TimetableMgmt(_: P) {
  const sc = useScope();
  const { toast, confirm } = useApp();
  const [view, setView] = useState<"day" | "week">("day");
  const [day, setDay] = useState(Math.min(Math.max(new Date().getDay(), 1), 6));
  const [batch, setBatch] = useState("All");
  const [teacher, setTeacher] = useState("All");
  const [sheet, setSheet] = useState<null | { ex?: TimetableEntry }>(null);
  const list = sc.timetable.filter((e) => (batch === "All" || e.batchId === batch) && (teacher === "All" || e.teacherId === teacher));
  const f = useForm({ batchId: "", subject: "", teacherId: "", roomId: "", day: "1", start: "", end: "" });
  const [seed, setSeed] = useState<string | null>(null);
  const k = sheet ? (sheet.ex?.id ?? "new") : null;
  if (seed !== k) { setSeed(k); if (sheet) { const e = sheet.ex; f.setV({ batchId: e?.batchId ?? sc.batches[0]?.id ?? "", subject: e?.subject ?? "", teacherId: e?.teacherId ?? "", roomId: e?.roomId ?? "", day: String(e?.day ?? day), start: e?.start ?? "", end: e?.end ?? "" }); } }
  const b = sc.batches.find((x) => x.id === f.v.batchId);
  const draft: TimetableEntry = { id: sheet?.ex?.id ?? "new", inst: sc.instId, batchId: f.v.batchId, subject: f.v.subject, teacherId: f.v.teacherId, roomId: f.v.roomId, day: Number(f.v.day), start: f.v.start, end: f.v.end };
  const complete = !!(draft.batchId && draft.subject && draft.teacherId && draft.roomId && draft.start && draft.end);
  const timeErr = draft.start && draft.end && draft.end <= draft.start ? "End time must be after start time" : "";
  const conflict = complete && !timeErr ? findConflict(sc.db, draft) : null;
  const row = (e: TimetableEntry) => <Row key={e.id} icon={Clock} title={`${e.subject} · ${sc.batches.find((x) => x.id === e.batchId)?.name.split(" – ")[0]}`} sub={`${time12(e.start)} – ${time12(e.end)} · ${sc.staff.find((t) => t.id === e.teacherId)?.name} · ${sc.rooms.find((r) => r.id === e.roomId)?.name}`} onClick={() => setSheet({ ex: e })} />;
  return (
    <Page title="Timetable" subtitle="Conflicts are blocked automatically" right={<IconBtn icon={Plus} label="Add class" tone="soft" onClick={() => setSheet({})} />}>
      <div className="space-y-2 pt-1">
        <Segmented value={view} onChange={setView} options={[{ value: "day", label: "Day view" }, { value: "week", label: "Week view" }]} />
        <div className="grid grid-cols-2 gap-2"><Select options={[{ value: "All", label: "All batches" }, ...sc.batches.map((x) => ({ value: x.id, label: x.name }))]} value={batch} onChange={setBatch} /><Select options={[{ value: "All", label: "All teachers" }, ...sc.staff.map((x) => ({ value: x.id, label: x.name }))]} value={teacher} onChange={setTeacher} /></div>
        {view === "day" && <Chips value={String(day)} onChange={(v) => setDay(Number(v))} options={[1, 2, 3, 4, 5, 6].map((d) => ({ value: String(d), label: DAYS[d] }))} />}
      </div>
      <div className="mt-2">{view === "day" ? (list.filter((e) => e.day === day).length ? <List>{list.filter((e) => e.day === day).sort((a, c) => (a.start < c.start ? -1 : 1)).map(row)}</List> : <Empty icon={Calendar} title={`No classes on ${DAYS_LONG[day]}`} body="Change filters or add a class." action="Add class" onAction={() => setSheet({})} />) : [1, 2, 3, 4, 5, 6].map((d) => { const es = list.filter((e) => e.day === d).sort((a, c) => (a.start < c.start ? -1 : 1)); return es.length ? <div key={d} className="mb-3"><div className="mb-1.5 text-[13px] font-semibold">{DAYS_LONG[d]}</div><List>{es.map(row)}</List></div> : null; })}</div>
      <Sheet open={!!sheet} onClose={() => setSheet(null)} title={sheet?.ex ? "Edit class" : "Add class"}>
        <div className="space-y-4">
          <Select label="Batch" required options={sc.batches.map((x) => ({ value: x.id, label: x.name }))} value={f.v.batchId} onChange={(v) => f.setV({ ...f.v, batchId: v, subject: "", teacherId: "", roomId: sc.batches.find((x) => x.id === v)?.roomId ?? "" })} />
          <Select label="Subject" required options={Object.keys(b?.subjectTeachers ?? {})} value={f.v.subject} onChange={(v) => f.setV({ ...f.v, subject: v, teacherId: b?.subjectTeachers[v] ?? f.v.teacherId })} />
          <Select label="Teacher" required options={sc.staff.map((t) => ({ value: t.id, label: t.name, sub: t.subjects.join(", ") }))} value={f.v.teacherId} onChange={(v) => f.set("teacherId", v)} />
          <Select label="Classroom" required options={sc.rooms.map((r) => ({ value: r.id, label: r.name, sub: `Capacity ${r.capacity}` }))} value={f.v.roomId} onChange={(v) => f.set("roomId", v)} />
          <Select label="Day" required options={[1, 2, 3, 4, 5, 6].map((d) => ({ value: String(d), label: DAYS_LONG[d] }))} value={f.v.day} onChange={(v) => f.set("day", v)} />
          <div className="grid grid-cols-2 gap-3"><TimePicker label="Start" required value={f.v.start} onChange={(v) => f.set("start", v)} /><TimePicker label="End" required value={f.v.end} onChange={(v) => f.set("end", v)} error={timeErr || undefined} /></div>
          {conflict ? <div role="alert" className="flex gap-2.5 rounded-xl bg-bad-soft p-3.5 text-[13px] leading-snug text-bad"><AlertTriangle size={18} className="mt-0.5 shrink-0" /><div><b>Scheduling conflict.</b> {conflict}</div></div> : complete && !timeErr ? <Banner tone="ok" icon={CheckCircle2}>No conflicts found for teacher, classroom or batch.</Banner> : null}
          <Btn disabled={!complete || !!timeErr || !!conflict} onClick={async () => { await uc.save("timetable", { ...draft, id: sheet?.ex?.id ?? uid("t") }); toast(sheet?.ex ? "Class updated" : "Class added"); setSheet(null); }}>{sheet?.ex ? "Save changes" : "Add class"}</Btn>
          {sheet?.ex ? <Btn variant="secondary" icon={Trash2} onClick={() => confirm({ title: "Delete this class?", body: "It will be removed from every timetable.", confirmLabel: "Delete", danger: true, onConfirm: async () => { await uc.remove("timetable", sheet.ex!.id); toast("Class deleted", "info"); setSheet(null); } })}>Delete class</Btn> : null}
        </div>
      </Sheet>
    </Page>
  );
}

/* S32 */
function AttendanceReports({ params }: P) {
  const sc = useScope();
  const { toast, push } = useApp();
  const [from, setFrom] = useState(addDays(-6));
  const [to, setTo] = useState(params.date ?? today());
  const [batch, setBatch] = useState<string>(params.batchId ?? "All");
  const [student, setStudent] = useState("All");
  const [tab, setTab] = useState("daily");
  const [exp, setExp] = useState(false);
  const students = sc.students.filter((s) => (batch === "All" || s.batchId === batch) && (student === "All" || s.id === student));
  const stats = useMemo(() => students.map((s) => ({ s, a: studentAtt(sc.db, s.id, from, to) })), [students, sc.db, from, to]);
  const tot = stats.reduce((x, y) => ({ p: x.p + y.a.p, a: x.a + y.a.a, l: x.l + y.a.l }), { p: 0, a: 0, l: 0 });
  const all = tot.p + tot.a + tot.l;
  const days: string[] = []; for (let d = from; d <= to && days.length < 31; d = addDays(1, d)) days.push(d);
  const trend = days.map((d) => { let p = 0, m = 0; students.forEach((s) => { const v = sc.db.attendance[`${d}|${s.id}`]; if (v) { m++; if (v !== "A") p++; } }); return { d, v: m ? pct(p, m) : null }; }).filter((x) => x.v !== null) as { d: string; v: number }[];
  const csv = ["Student,Present,Absent,Late,Attendance %", ...stats.map((x) => `${x.s.name},${x.a.p},${x.a.a},${x.a.l},${x.a.pct}`)].join("\n");
  const logs = sc.attLog.filter((l) => l.date >= from && l.date <= to && students.some((s) => s.id === l.studentId));
  return (
    <Page title="Attendance reports" right={<IconBtn icon={Download} label="Export preview" onClick={() => setExp(true)} />}>
      <div className="space-y-2 pt-1">
        <div className="grid grid-cols-2 gap-3"><DatePicker label="From" value={from} max={to} onChange={(v) => v && setFrom(v)} /><DatePicker label="To" value={to} min={from} max={today()} onChange={(v) => v && setTo(v)} /></div>
        <div className="grid grid-cols-2 gap-2"><Select options={[{ value: "All", label: "All batches" }, ...sc.batches.map((b) => ({ value: b.id, label: b.name }))]} value={batch} onChange={(v) => { setBatch(v); setStudent("All"); }} /><Select options={[{ value: "All", label: "All students" }, ...sc.students.filter((s) => batch === "All" || s.batchId === batch).map((s) => ({ value: s.id, label: s.name }))]} value={student} onChange={setStudent} /></div>
      </div>
      <div className="mt-3 grid grid-cols-4 gap-2 text-center">{[["Overall", all ? pct(tot.p + tot.l, all) + "%" : "—", "text-ink"], ["Present", tot.p, "text-ok"], ["Absent", tot.a, "text-bad"], ["Late", tot.l, "text-warn"]].map(([l, v, c]) => <div key={l as string} className="rounded-xl border border-line bg-white py-2.5"><div className={`text-[18px] font-bold ${c}`}>{v}</div><div className="text-[11px] text-mute">{l}</div></div>)}</div>
      <div className="mt-3"><Tabs value={tab} onChange={setTab} options={[{ value: "daily", label: "Students" }, { value: "trend", label: "Trends" }, { value: "log", label: "Corrections", count: logs.length }]} /></div>
      <div className="mt-3">
        {tab === "daily" && (stats.length ? <List>{stats.sort((a, b) => a.a.pct - b.a.pct).map(({ s, a }) => <Row key={s.id} lead={<Avatar name={s.name} />} title={s.name} sub={`${a.p} present · ${a.a} absent · ${a.l} late`} right={<div className="w-14"><div className="text-right text-[14px] font-bold">{a.total ? `${a.pct}%` : "—"}</div><Progress value={a.pct} tone={a.pct >= 85 ? "ok" : "warn"} height={5} /></div>} onClick={() => push("S23", { id: s.id })} />)}</List> : <Empty title="No students selected" />)}
        {tab === "trend" && (trend.length ? <Card><div className="mb-2 text-[13px] font-semibold">Daily attendance %</div><LineChart points={trend.slice(-8).map((t) => t.v)} labels={trend.slice(-8).map((t) => dmy(t.d).slice(0, 5))} min={40} max={100} /><p className="mt-2 text-[12px] text-mute">Shows the share of marked students who attended (present or late) each day.</p></Card> : <Empty title="No attendance in this range" body="Choose a wider date range." />)}
        {tab === "log" && (logs.length ? <List>{logs.map((l) => <Row key={l.id} icon={Undo2} tone="warn" title={sc.students.find((s) => s.id === l.studentId)?.name} sub={`${dmy(l.date)} · ${l.from} → ${l.to} by ${l.by}. ${l.reason}`} noChevron />)}</List> : <Empty title="No corrections" body="Changes to saved attendance are logged here." />)}
      </div>
      <Sheet open={exp} onClose={() => setExp(false)} title="Export preview">
        <Banner tone="warn">Demo preview — no file is generated or sent anywhere.</Banner>
        <pre className="mt-3 max-h-56 overflow-auto rounded-xl bg-slate-900 p-3 text-[11.5px] leading-relaxed text-slate-100">{csv}</pre>
        <div className="mt-3"><Btn icon={Copy} onClick={() => { navigator.clipboard?.writeText(csv).catch(() => undefined); toast("CSV copied to clipboard"); setExp(false); }}>Copy CSV</Btn></div>
      </Sheet>
    </Page>
  );
}

/* Exam form */
export function ExamForm({ open, onClose, ex }: { open: boolean; onClose: () => void; ex?: Exam }) {
  const sc = useScope();
  const { toast } = useApp();
  const f = useForm({ name: ex?.name ?? "", batchId: ex?.batchId ?? "", subject: ex?.subject ?? "", date: ex?.date ?? "", time: ex?.time ?? "10:00", duration: String(ex?.duration ?? 90), max: String(ex?.max ?? 50), syllabus: ex?.syllabus ?? "", status: ex?.status ?? "scheduled" }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter exam name" : undefined, batchId: v.batchId ? undefined : "Choose a batch", subject: v.subject ? undefined : "Choose a subject", date: v.date ? undefined : "Pick the exam date", max: Number(v.max) > 0 && Number(v.max) <= 200 ? undefined : "Enter marks between 1 and 200",
  }));
  const b = sc.batches.find((x) => x.id === f.v.batchId);
  return (
    <Sheet open={open} onClose={onClose} title={ex ? "Edit exam" : "Create exam"}>
      <div className="space-y-4"><TextInput label="Exam name" required placeholder="e.g. Science Unit Test 2" {...f.bind("name")} />
        <Select label="Batch" required options={sc.batches.map((x) => ({ value: x.id, label: x.name }))} value={f.v.batchId} onChange={(v) => f.setV({ ...f.v, batchId: v, subject: "" })} />
        <Select label="Subject" required options={Object.keys(b?.subjectTeachers ?? {})} value={f.v.subject} onChange={(v) => f.set("subject", v)} placeholder={b ? "Select subject" : "Choose a batch first"} />
        <div className="grid grid-cols-2 gap-3"><DatePicker label="Date" required value={f.v.date} onChange={(v) => f.set("date", v)} /><TimePicker label="Start time" required value={f.v.time} onChange={(v) => f.set("time", v)} /></div>
        <div className="grid grid-cols-2 gap-3"><TextInput label="Maximum marks" required inputMode="numeric" {...f.bind("max")} /><TextInput label="Duration (min)" inputMode="numeric" {...f.bind("duration")} /></div>
        <TextInput label="Syllabus" multiline rows={2} {...f.bind("syllabus")} />
        <Select label="Status" options={ex?.status === "published" ? ["published"] : ["draft", "scheduled", "completed"]} value={f.v.status} onChange={(v) => f.set("status", v as Exam["status"])} />
        <Btn disabled={!f.valid} onClick={async () => { await uc.save("exams", { id: ex?.id ?? uid("x"), inst: sc.instId, name: f.v.name.trim(), batchId: f.v.batchId, subject: f.v.subject, date: f.v.date, time: f.v.time, duration: Number(f.v.duration) || 60, max: Number(f.v.max), status: f.v.status as Exam["status"], syllabus: f.v.syllabus, instructions: ex?.instructions ?? "Carry your ID card and stationery. Mobile phones are not allowed." }); toast(ex ? "Exam updated" : "Exam created"); onClose(); }}>{ex ? "Save changes" : "Create exam"}</Btn></div>
    </Sheet>
  );
}

/* S33 */
function ExamMgmt(_: P) {
  const sc = useScope();
  const { push } = useApp();
  const [tab, setTab] = useState("upcoming");
  const [add, setAdd] = useState(false);
  const [batch, setBatch] = useState("All");
  const groups: Record<string, Exam[]> = { upcoming: sc.exams.filter((x) => x.status === "scheduled"), completed: sc.exams.filter((x) => x.status === "completed" || x.status === "published"), draft: sc.exams.filter((x) => x.status === "draft") };
  const list = (tab === "all" ? sc.exams : groups[tab]).filter((x) => batch === "All" || x.batchId === batch).sort((a, b) => (tab === "upcoming" ? (a.date < b.date ? -1 : 1) : a.date < b.date ? 1 : -1));
  return (
    <Page title="Exams" right={<IconBtn icon={Plus} label="Create exam" tone="soft" onClick={() => setAdd(true)} />}>
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "upcoming", label: "Upcoming", count: groups.upcoming.length }, { value: "completed", label: "Completed", count: groups.completed.length }, { value: "draft", label: "Draft", count: groups.draft.length }, { value: "all", label: "All" }]} /></div>
      <div className="mt-2"><Chips value={batch} onChange={setBatch} options={[{ value: "All", label: "All batches" }, ...sc.batches.map((b) => ({ value: b.id, label: b.name.split(" – ")[0] }))]} /></div>
      {list.length ? <div className="mt-2 space-y-2.5">{list.map((x) => <ExamCard key={x.id} x={x} batch={sc.batches.find((b) => b.id === x.batchId)?.name.split(" – ")[0]} onClick={() => push("S34", { id: x.id })} />)}</div> : <Empty icon={GraduationCap} title="No exams here" body="Create an exam to schedule it for a batch." action="Create exam" onAction={() => setAdd(true)} />}
      <ExamForm open={add} onClose={() => setAdd(false)} />
    </Page>
  );
}

/* S34 */
function ExamDetail({ params }: P) {
  const sc = useScope();
  const { session, confirm, toast, push } = useApp();
  const x = sc.exams.find((e) => e.id === params.id) ?? sc.exams[0];
  const [edit, setEdit] = useState(false);
  if (!x) return <Page title="Exam"><Empty title="No exams" /></Page>;
  const st = examStats(sc.db, x);
  const roster = sc.students.filter((s) => s.batchId === x.batchId && s.status === "active");
  const canPub = can(sc.db, session.role, "results.publish");
  const siblings = sc.exams.filter((e) => e.batchId === x.batchId && e.status === "published").map((e) => ({ label: e.subject.slice(0, 5), value: examStats(sc.db, e).avgPct, tone: "violet" as Tone }));
  return (
    <Page title="Exam details" right={<IconBtn icon={Pencil} label="Edit exam" onClick={() => setEdit(true)} />}
      footer={x.status !== "published" && canPub ? <Btn disabled={st.entered === 0} onClick={() => confirm({ title: "Publish results?", body: st.missing ? `${st.missing} student(s) have no marks yet. Students and parents will see the published results immediately.` : "Students and verified parents will see these results immediately and be notified.", confirmLabel: "Publish", onConfirm: async () => { await uc.publishExam(x.id, session.role); toast("Results published"); } })}>Publish results</Btn> : undefined}>
      <ExamCard x={x} batch={sc.batches.find((b) => b.id === x.batchId)?.name} />
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">{[["Average", st.entered ? `${st.avgPct}%` : "—"], ["Highest", st.entered ? st.high : "—"], ["Lowest", st.entered ? st.low : "—"]].map(([l, v]) => <div key={l} className="rounded-xl border border-line bg-white py-2.5"><div className="text-[18px] font-bold">{v}</div><div className="text-[11px] text-mute">{l}</div></div>)}</div>
      {st.missing > 0 && x.status !== "scheduled" && x.status !== "draft" ? <div className="mt-3"><Banner tone="warn" icon={AlertTriangle}>{st.missing} student(s) are missing marks.</Banner></div> : null}
      {x.status !== "published" && !canPub ? <div className="mt-3"><Banner>Your role can't publish results. Ask the owner or enable the permission in settings.</Banner></div> : null}
      {siblings.length > 1 ? <Section title="Subject-wise average (published exams in this batch)"><Card><Bars data={siblings.slice(0, 5)} max={100} height={80} suffix="%" /></Card></Section> : null}
      <Section title={`Student results · ${st.entered}/${st.total} entered`}><List>{roster.map((s) => { const m = sc.db.marks[`${x.id}|${s.id}`]; return <Row key={s.id} lead={<Avatar name={s.name} />} title={s.name} sub={m === undefined ? "Marks missing" : `${pct(m, x.max)}%`} right={m === undefined ? <Badge tone="warn">Missing</Badge> : <b className="text-[15px]">{m}/{x.max}</b>} onClick={() => push("S23", { id: s.id })} />; })}</List></Section>
      <ExamForm open={edit} onClose={() => setEdit(false)} ex={x} />
    </Page>
  );
}

/* S35 */
function FeesDashboard(_: P) {
  const sc = useScope();
  const { push, session } = useApp();
  if (!can(sc.db, session.role, "fees.view")) return <Page title="Fees"><Denied /></Page>;
  const fees = instFees(sc);
  const coll = monthlyCollection(sc);
  const recent = sc.payments.slice().sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 5);
  const upcoming = sc.students.flatMap((s) => { const f = feeSummary(sc.db, s.id); return f?.next && f.next.due >= today() && f.next.due <= addDays(30) ? [{ s, n: f.next }] : []; }).sort((a, b) => (a.n.due < b.n.due ? -1 : 1));
  const overdue = sc.students.map((s) => ({ s, f: feeSummary(sc.db, s.id) })).filter((x) => x.f && x.f.overdue > 0);
  return (
    <Page title="Fees" subtitle="Demo records only" right={<IconBtn icon={Receipt} label="Ledger" tone="soft" onClick={() => push("S37")} />}>
      <div className="pt-2"><Card className="!bg-gradient-to-br !from-brand-dark !to-brand !text-white"><div className="flex items-center justify-between"><div><div className="text-[12px] text-white/70">Collected of {inr(fees.expected)}</div><div className="mt-1 text-[30px] font-bold tracking-tight">{inr(fees.collected)}</div></div><Donut value={fees.rate} size={78} tone="sky" /></div></Card></div>
      <div className="mt-3 grid grid-cols-2 gap-3"><Stat label="Expected" value={inr(fees.expected)} onClick={() => push("S36")} /><Stat label="Outstanding" value={inr(fees.outstanding)} tone="warn" onClick={() => push("S37")} /><Stat label="Overdue" value={inr(fees.overdue)} tone={fees.overdue ? "bad" : "mute"} sub={`${fees.overdueCount} students`} onClick={() => push("S37", { filter: "overdue" })} /><Stat label="Structures" value={sc.feeStructures.length} tone="violet" onClick={() => push("S36")} /></div>
      {overdue.length ? <Section title="Fee alerts"><List>{overdue.map(({ s, f }) => <Row key={s.id} icon={AlertTriangle} tone="bad" title={s.name} sub={`${inr(f!.overdue)} overdue`} onClick={() => push("S37", { studentId: s.id })} />)}</List></Section> : null}
      <Section title="Collection trend (₹ thousands)"><Card><Bars data={coll} height={90} suffix="K" /></Card></Section>
      <Section title="Upcoming dues (30 days)">{upcoming.length ? <List>{upcoming.map(({ s, n }) => <Row key={s.id} lead={<Avatar name={s.name} />} title={s.name} sub={`${n.label} · due ${dmy(n.due)}`} right={<b>{inr(n.amount - n.paid)}</b>} onClick={() => push("S37", { studentId: s.id })} />)}</List> : <Card><p className="text-[13.5px] text-mute">No instalments fall due in the next 30 days.</p></Card>}</Section>
      <Section title="Recent payments" action="Ledger" onAction={() => push("S37")}><List>{recent.map((p) => <Row key={p.id} icon={Wallet} tone="ok" title={sc.students.find((s) => s.id === p.studentId)?.name} sub={`${dmy(p.date)} · ${p.method}`} right={<div className="text-right"><b>{inr(p.amount)}</b><div><DemoTag /></div></div>} onClick={() => push("S37", { studentId: p.studentId })} />)}</List></Section>
    </Page>
  );
}

/* S36 */
function FeeStructures(_: P) {
  const sc = useScope();
  const { session, toast } = useApp();
  const [edit, setEdit] = useState<null | { ex?: FeeStructure }>(null);
  const [assign, setAssign] = useState<FeeStructure | null>(null);
  const [sel, setSel] = useState<string[]>([]);
  const [disc, setDisc] = useState("0");
  const [reason, setReason] = useState("");
  const f = useForm({ name: "", course: "", total: "", n: "3", first: "", gap: "30" });
  const [seed, setSeed] = useState<string | null>(null);
  const k = edit ? edit.ex?.id ?? "new" : null;
  if (seed !== k) { setSeed(k); if (edit) { const e = edit.ex; f.setV({ name: e?.name ?? "", course: e?.course ?? "", total: e ? String(e.total) : "", n: String(e?.installments.length ?? 3), first: e?.installments[0].due ?? "", gap: "30" }); } }
  if (!can(sc.db, session.role, "fees.view")) return <Page title="Fee structures"><Denied /></Page>;
  const manage = can(sc.db, session.role, "fees.record");
  const valid = f.v.name.trim().length >= 3 && f.v.course && Number(f.v.total) > 0 && Number(f.v.n) >= 1 && Number(f.v.n) <= 12 && f.v.first;
  return (
    <Page title="Fee structures" right={manage ? <IconBtn icon={Plus} label="Create structure" tone="soft" onClick={() => setEdit({})} /> : undefined}>
      <div className="mt-2 space-y-3">{sc.feeStructures.map((s) => { const n = sc.feeAccounts.filter((a) => a.structureId === s.id).length; return (
        <Card key={s.id}><div className="flex items-start justify-between gap-2"><div><div className="text-[15px] font-semibold">{s.name}</div><div className="text-[12.5px] text-mute">{s.course} · {n} students</div></div><b className="text-[17px]">{inr(s.total)}</b></div>
          <div className="mt-3 space-y-1.5">{s.installments.map((i) => <div key={i.label} className="flex justify-between text-[13px]"><span className="text-mute">{i.label} · due {dmy(i.due)}</span><b>{inr(i.amount)}</b></div>)}</div>
          {manage ? <div className="mt-3 flex gap-2"><Btn size="sm" variant="secondary" icon={Pencil} onClick={() => setEdit({ ex: s })}>Edit</Btn><Btn size="sm" onClick={() => { setAssign(s); setSel([]); setDisc("0"); setReason(""); }}>Assign to students</Btn></div> : null}</Card>); })}
        {sc.feeStructures.length === 0 ? <Empty title="No fee structures" action={manage ? "Create structure" : undefined} onAction={() => setEdit({})} /> : null}</div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} title={edit?.ex ? "Edit fee structure" : "Create fee structure"}>
        <div className="space-y-4"><TextInput label="Structure name" required value={f.v.name} onChange={(v) => f.set("name", v)} /><Select label="Course" required options={Array.from(new Set(sc.batches.map((b) => b.course)))} value={f.v.course} onChange={(v) => f.set("course", v)} />
          <TextInput label="Total fee" required prefix="₹" inputMode="numeric" value={f.v.total} onChange={(v) => f.set("total", v.replace(/\D/g, ""))} />
          <div className="grid grid-cols-2 gap-3"><TextInput label="Instalments" required inputMode="numeric" value={f.v.n} onChange={(v) => f.set("n", v.replace(/\D/g, ""))} /><TextInput label="Gap (days)" inputMode="numeric" value={f.v.gap} onChange={(v) => f.set("gap", v.replace(/\D/g, ""))} /></div>
          <DatePicker label="First due date" required value={f.v.first} onChange={(v) => f.set("first", v)} />
          {valid ? <Banner>{f.v.n} × {inr(Math.round(Number(f.v.total) / Number(f.v.n)))} instalments, every {f.v.gap || 30} days from {dmy(f.v.first)}.</Banner> : null}
          <Btn disabled={!valid} onClick={async () => { const n = Number(f.v.n), total = Number(f.v.total); const each = Math.floor(total / n); await uc.save("feeStructures", { id: edit?.ex?.id ?? uid("fs"), inst: sc.instId, name: f.v.name.trim(), course: f.v.course, total, installments: Array.from({ length: n }, (_, i) => ({ label: `Instalment ${i + 1}`, amount: i === n - 1 ? total - each * (n - 1) : each, due: addDays(i * (Number(f.v.gap) || 30), f.v.first) })) }); toast("Fee structure saved"); setEdit(null); }}>Save structure</Btn></div>
      </Sheet>
      <Sheet open={!!assign} onClose={() => setAssign(null)} title={`Assign: ${assign?.name ?? ""}`}>
        <div className="space-y-3"><div className="max-h-52 overflow-y-auto rounded-xl border border-line px-3 py-1">{sc.students.map((s) => <Checkbox key={s.id} checked={sel.includes(s.id)} onChange={(v) => setSel(v ? [...sel, s.id] : sel.filter((x) => x !== s.id))}>{s.name}</Checkbox>)}</div>
          <div className="grid grid-cols-2 gap-3"><TextInput label="Discount (₹)" prefix="₹" inputMode="numeric" value={disc} onChange={(v) => setDisc(v.replace(/\D/g, ""))} /><TextInput label="Reason" value={reason} onChange={setReason} placeholder="e.g. Scholarship" /></div>
          <Btn disabled={!sel.length || (Number(disc) > 0 && !reason.trim()) || Number(disc) > (assign?.total ?? 0)} onClick={async () => { for (const id of sel) await uc.save("feeAccounts", { id: `fa-${id}`, inst: sc.instId, studentId: id, structureId: assign!.id, discount: Number(disc) || 0, discountReason: reason }); toast(`Assigned to ${sel.length} student(s)`); setAssign(null); }}>Assign to {sel.length || ""} student{sel.length === 1 ? "" : "s"}</Btn></div>
      </Sheet>
    </Page>
  );
}

/* Receipt */
export function Receipt_({ p, studentName, onClose, actions }: { p: Payment | null; studentName?: string; onClose: () => void; actions?: React.ReactNode }) {
  const sc = useScope();
  return (
    <Sheet open={!!p} onClose={onClose} title="Receipt preview">
      {p ? <div className="relative overflow-hidden rounded-2xl border border-dashed border-slate-300 p-4">
        <div className="pointer-events-none absolute inset-0 grid place-items-center"><span className="-rotate-25 text-[56px] font-black tracking-widest text-warn/10">DEMO</span></div>
        <div className="text-center"><div className="text-[15px] font-bold">{sc.inst.name}</div><div className="text-[12px] text-mute">{sc.inst.city}, {sc.inst.state}</div><div className="mt-2 inline-block"><DemoTag /></div></div>
        <Divider />
        <div className="mt-2"><Kv k="Receipt no." v={p.receipt} /><Kv k="Date" v={dmy(p.date)} /><Kv k="Student" v={studentName ?? "—"} /><Kv k="Method" v={p.method} /><Kv k="Reference" v={p.ref} /><Kv k="Status" v={lab(p.status)} /><Kv k="Amount" v={<b className="text-[17px]">{inr(p.amount)}</b>} /></div>
        <p className="mt-3 text-center text-[11px] leading-snug text-mute">Demo record for prototype only. No real payment was made and this is not a valid tax receipt.</p>
      </div> : null}
      {p && actions ? <div className="mt-3 flex flex-wrap gap-2">{actions}</div> : null}
    </Sheet>
  );
}

/* S37 */
function Ledger({ params }: P) {
  const sc = useScope();
  const { session, confirm, toast } = useApp();
  const [sid, setSid] = useState<string>(params.studentId ?? "All");
  const [status, setStatus] = useState("All");
  const [method, setMethod] = useState("All");
  const [from, setFrom] = useState("");
  const [tab, setTab] = useState(params.filter === "overdue" ? "dues" : "payments");
  const [rec, setRec] = useState(false);
  const [view, setView] = useState<Payment | null>(null);
  const [adj, setAdj] = useState(false);
  const f = useForm({ sid: params.studentId ?? "", amount: "", method: "Cash", note: "" }, (v) => ({ sid: v.sid ? undefined : "Choose a student", amount: Number(v.amount) > 0 ? undefined : "Enter an amount" }));
  const [adjV, setAdjV] = useState({ d: "", r: "" });
  if (!can(sc.db, session.role, "fees.view")) return <Page title="Payments"><Denied /></Page>;
  const manage = can(sc.db, session.role, "fees.record");
  const name = (id: string) => sc.students.find((s) => s.id === id)?.name ?? "—";
  const list = sc.payments.filter((p) => (sid === "All" || p.studentId === sid) && (status === "All" || p.status === status) && (method === "All" || p.method === method) && (!from || p.date >= from)).sort((a, b) => (a.date < b.date ? 1 : -1));
  const sum = sid !== "All" ? feeSummary(sc.db, sid) : null;
  const dues = sc.students.map((s) => ({ s, f: feeSummary(sc.db, s.id) })).filter((x) => x.f && x.f.outstanding > 0 && (sid === "All" || x.s.id === sid)).sort((a, b) => b.f!.overdue - a.f!.overdue);
  const methods = ["Cash", "UPI (demo)", "Cheque", "Bank Transfer (demo)"];
  return (
    <Page title="Payments & ledger" subtitle="All payments are DEMO records" right={manage ? <IconBtn icon={Plus} label="Record payment" tone="soft" onClick={() => setRec(true)} /> : undefined}>
      <div className="space-y-2 pt-1"><Banner tone="warn" icon={ShieldCheck}>Demo ledger: no money moves. Real UPI/bank payments will use a trusted server-side provider later.</Banner>
        <Select options={[{ value: "All", label: "All students" }, ...sc.students.map((s) => ({ value: s.id, label: s.name, sub: s.sid }))]} value={sid} onChange={setSid} />
        {sum ? <Card><div className="flex justify-between text-[13px]"><span className="text-mute">Total {inr(sum.total)}</span><span className="text-mute">Paid {inr(sum.paid)}</span></div><div className="mt-1 text-[22px] font-bold">{inr(sum.outstanding)} <span className="text-[12px] font-medium text-mute">outstanding</span></div>{manage ? <div className="mt-2"><Btn size="sm" variant="secondary" onClick={() => { setAdjV({ d: String(sum.acc.discount), r: sum.acc.discountReason }); setAdj(true); }}>Issue fee adjustment</Btn></div> : null}</Card> : null}</div>
      <div className="mt-3"><Tabs value={tab} onChange={setTab} options={[{ value: "payments", label: "Payments" }, { value: "dues", label: "Outstanding", count: dues.length }, { value: "recon", label: "Reconciliation" }]} /></div>
      {tab === "payments" && <div className="mt-2"><div className="grid grid-cols-2 gap-2"><Select options={["All", "received", "refund-requested", "refunded"]} value={status} onChange={setStatus} /><Select options={["All", ...methods]} value={method} onChange={setMethod} /></div><div className="mt-2"><DatePicker label="Since" value={from} onChange={setFrom} /></div>
        {list.length ? <div className="mt-3"><List>{list.map((p) => <Row key={p.id} icon={Receipt} tone={p.status === "refunded" ? "mute" : p.status === "refund-requested" ? "warn" : "ok"} title={`${name(p.studentId)} · ${inr(p.amount)}`} sub={`${dmy(p.date)} · ${p.method} · ${p.ref}`} right={<div className="flex flex-col items-end gap-1"><DemoTag />{p.status !== "received" ? <StatusBadge status={p.status} /> : null}</div>} onClick={() => setView(p)} />)}</List></div> : <Empty icon={Search} title="No payments" body="Adjust filters or record a demo payment." />}</div>}
      {tab === "dues" && <div className="mt-3">{dues.length ? <List>{dues.map(({ s, f: ff }) => <Row key={s.id} lead={<Avatar name={s.name} />} title={s.name} sub={ff!.overdue ? `${inr(ff!.overdue)} overdue` : `Next due ${dmy(ff!.next?.due)}`} right={<b>{inr(ff!.outstanding)}</b>} onClick={() => setSid(s.id)} />)}</List> : <Empty title="No outstanding balances" />}</div>}
      {tab === "recon" && <div className="mt-3 space-y-3"><Banner>Group demo payments by method to check against your cash book or bank statement.</Banner><List>{methods.map((m) => { const ps = sc.payments.filter((p) => p.method === m && p.status !== "refunded"); return <Row key={m} icon={Wallet} title={m} sub={`${ps.length} payments`} right={<b>{inr(ps.reduce((a, p) => a + p.amount, 0))}</b>} noChevron />; })}</List><Card><Kv k="Refund requests pending" v={sc.payments.filter((p) => p.status === "refund-requested").length} /><Kv k="Refunded" v={inr(sc.payments.filter((p) => p.status === "refunded").reduce((a, p) => a + p.amount, 0))} /></Card></div>}
      <Receipt_ p={view} studentName={view ? name(view.studentId) : undefined} onClose={() => setView(null)} actions={view && manage ? <RefundActions p={view} onDone={() => setView(null)} /> : undefined} />
      <Sheet open={rec} onClose={() => setRec(false)} title="Record payment (demo)">
        <div className="space-y-4"><Banner tone="warn">This only creates a demo record. It does not charge anyone.</Banner>
          <Select label="Student" required options={sc.students.map((s) => ({ value: s.id, label: s.name, sub: s.sid }))} value={f.v.sid} onChange={(v) => f.set("sid", v)} /><TextInput label="Amount" required prefix="₹" inputMode="numeric" value={f.v.amount} onChange={(v) => f.set("amount", v.replace(/\D/g, ""))} />
          <Select label="Method" options={methods} value={f.v.method} onChange={(v) => f.set("method", v)} /><TextInput label="Note" value={f.v.note} onChange={(v) => f.set("note", v)} />
          <Btn disabled={!f.valid} onClick={async () => { const p = await uc.recordPayment({ inst: sc.instId, studentId: f.v.sid, amount: Number(f.v.amount), date: today(), method: f.v.method as Payment["method"], ref: `DEMO-${Math.floor(10000 + Math.random() * 89999)}`, note: f.v.note }, session.role); setRec(false); setView(p); toast("Demo payment recorded"); f.setV({ sid: "", amount: "", method: "Cash", note: "" }); }}>Record demo payment</Btn></div>
      </Sheet>
      <Sheet open={adj} onClose={() => setAdj(false)} title="Fee adjustment"><div className="space-y-4"><TextInput label="Total discount / scholarship" prefix="₹" inputMode="numeric" value={adjV.d} onChange={(v) => setAdjV({ ...adjV, d: v.replace(/\D/g, "") })} /><TextInput label="Reason" required value={adjV.r} onChange={(v) => setAdjV({ ...adjV, r: v })} />
        <Btn disabled={!adjV.r.trim() || Number(adjV.d) > (sum?.fs.total ?? 0)} onClick={() => confirm({ title: "Issue fee adjustment?", body: `The discount becomes ${inr(Number(adjV.d))}. The parent will see the updated balance.`, confirmLabel: "Issue", onConfirm: async () => { await uc.adjustFee(sid, Number(adjV.d), adjV.r, session.role); setAdj(false); toast("Fee adjusted"); } })}>Review adjustment</Btn></div></Sheet>
    </Page>
  );
}
function RefundActions({ p, onDone }: { p: Payment; onDone: () => void }) {
  const { session, confirm, toast } = useApp();
  return (
    <>
      {p.status === "received" ? <Btn variant="secondary" size="sm" icon={RotateCcw} onClick={() => confirm({ title: "Request a refund?", body: "A refund request will be created for approval.", confirmLabel: "Request refund", danger: true, onConfirm: async () => { await uc.refund(p.id, "request", session.role); toast("Refund requested", "info"); onDone(); } })}>Request refund</Btn> : null}
      {p.status === "refund-requested" ? <><Btn variant="secondary" size="sm" onClick={async () => { await uc.refund(p.id, "reject", session.role); toast("Refund rejected", "info"); onDone(); }}>Reject</Btn><Btn size="sm" onClick={() => confirm({ title: "Approve refund?", body: "The payment will be marked refunded and the outstanding balance will increase.", confirmLabel: "Approve", danger: true, onConfirm: async () => { await uc.refund(p.id, "approve", session.role); toast("Refund approved (demo)", "info"); onDone(); } })}>Approve refund</Btn></> : null}
    </>
  );
}

/* Resource viewer (also used by S52, S68, S69) */
export function ResourceViewer({ r, onClose }: { r: Resource | null; onClose: () => void }) {
  const { toast } = useApp();
  return (
    <Sheet open={!!r} onClose={onClose} title={r?.title}>
      {r ? <div className="space-y-3">
        {r.type === "image" ? <div className="grid h-52 place-items-center rounded-2xl bg-gradient-to-br from-sky-soft to-violet-soft text-sky"><div className="text-center"><div className="text-[13px] font-semibold text-ink">Image preview</div><div className="text-[12px] text-mute">Sample placeholder — {fileSize(r.size)}</div></div></div>
          : r.type === "link" ? <Card><div className="flex items-center gap-3"><IconTile icon={Link2} tone="sky" /><div className="min-w-0 text-[13px]"><div className="font-semibold">External link</div><div className="truncate text-mute">{r.url}</div></div></div><div className="mt-3"><Btn variant="secondary" size="sm" onClick={() => { window.open(r.url, "_blank", "noopener,noreferrer"); }}>Open in browser</Btn></div></Card>
          : <div className="rounded-2xl bg-slate-100 p-3"><div className="mx-auto h-48 max-w-[240px] rounded-lg bg-white p-4 shadow"><div className="h-3 w-3/4 rounded bg-slate-300" /><div className="mt-3 space-y-1.5">{Array.from({ length: 9 }).map((_, i) => <div key={i} className="h-1.5 rounded bg-slate-200" style={{ width: `${95 - (i % 3) * 12}%` }} />)}</div></div><p className="mt-2 text-center text-[11.5px] text-mute">Sample page preview — the real file viewer arrives with cloud storage.</p></div>}
        <Card><Kv k="Subject" v={r.subject} /><Kv k="Chapter" v={r.chapter} /><Kv k="Shared by" v={r.by} /><Kv k="Type" v={r.type.toUpperCase()} />{r.size ? <Kv k="Size" v={fileSize(r.size)} /> : null}<Kv k="Added" v={dmy(r.at.slice(0, 10))} /></Card>
        <Btn variant="secondary" icon={Download} onClick={() => toast("Demo: download isn't connected — nothing was saved", "info")}>Download (demo)</Btn>
      </div> : null}
    </Sheet>
  );
}

/* S38 */
function ResourcesMgmt({ params }: P) {
  const sc = useScope();
  const { toast, confirm } = useApp();
  const [q, setQ] = useState("");
  const [folder, setFolder] = useState("All");
  const [view, setView] = useState<Resource | null>(sc.resources.find((r) => r.id === params.id) ?? null);
  const [add, setAdd] = useState<null | { ex?: Resource }>(null);
  const [file, setFile] = useState<import("@/domain/types").FileMeta | null>(null);
  const folders = ["All", ...Array.from(new Set(sc.resources.map((r) => r.folder)))];
  const f = useForm({ title: "", subject: "", type: "pdf", url: "", batches: [] as string[] }, (v) => ({ title: v.title.trim().length < 3 ? "Enter a title" : undefined, subject: v.subject ? undefined : "Choose a subject", batches: v.batches.length ? undefined : "Share with at least one batch", url: v.type === "link" && !/^https?:\/\/\S+\.\S+/.test(v.url) ? "Enter a valid link starting with https://" : undefined }));
  const [seed, setSeed] = useState<string | null>(null);
  const k = add ? add.ex?.id ?? "new" : null;
  if (seed !== k) { setSeed(k); if (add) { const e = add.ex; f.setV({ title: e?.title ?? "", subject: e?.subject ?? "", type: e?.type ?? "pdf", url: e?.url ?? "", batches: e?.batchIds ?? [] }); setFile(null); } }
  const list = sc.resources.filter((r) => (folder === "All" || r.folder === folder) && r.title.toLowerCase().includes(q.toLowerCase()));
  const icon = (t: string) => fileIcon(t === "link" ? "link" : t === "image" ? "image/png" : t === "pdf" ? "application/pdf" : "doc");
  const canSave = f.valid && (f.v.type === "link" || add?.ex || file);
  return (
    <Page title="Study resources" right={<IconBtn icon={Plus} label="Upload resource" tone="soft" onClick={() => setAdd({})} />}>
      <div className="space-y-2 pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search resources" /><Chips value={folder} onChange={setFolder} options={folders} /></div>
      {list.length ? <div className="mt-2"><List>{list.map((r) => { const I = icon(r.type); return <Row key={r.id} lead={<span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand"><I size={20} /></span>} title={r.title} sub={`${r.subject} · ${r.type.toUpperCase()}${r.size ? ` · ${fileSize(r.size)}` : ""} · ${r.batchIds.length} batch${r.batchIds.length > 1 ? "es" : ""}`} onClick={() => setView(r)} />; })}</List></div> : <Empty icon={FolderOpen} title="No resources found" body="Upload a PDF, document, image or link." action="Upload resource" onAction={() => setAdd({})} />}
      <ResourceViewer r={view} onClose={() => setView(null)} />
      {view ? <Sheet open onClose={() => setView(null)} title="Manage"><div className="flex gap-2"><Btn variant="secondary" icon={Edit3} onClick={() => { setAdd({ ex: view }); setView(null); }}>Edit</Btn><Btn variant="danger" icon={Trash2} onClick={() => confirm({ title: "Delete this resource?", body: `“${view.title}” will be removed for all batches.`, confirmLabel: "Delete", danger: true, onConfirm: async () => { await uc.remove("resources", view.id); toast("Resource deleted", "info"); setView(null); } })}>Delete</Btn></div></Sheet> : null}
      <Sheet open={!!add} onClose={() => setAdd(null)} title={add?.ex ? "Edit resource" : "Upload resource"}>
        <div className="space-y-4"><TextInput label="Title" required {...f.bind("title")} /><Select label="Subject" required options={sc.subjects.map((s) => s.name)} {...f.bind("subject")} /><Select label="Type" options={["pdf", "doc", "image", "link"]} value={f.v.type} onChange={(v) => f.set("type", v)} />
          {f.v.type === "link" ? <TextInput label="Link" required inputMode="text" placeholder="https://" {...f.bind("url")} /> : !add?.ex ? <FilePicker label="File" required value={file} onChange={setFile} /> : null}
          <div><div className="mb-1.5 text-[13px] font-semibold">Share with batches <span className="text-bad">*</span></div>{sc.batches.map((b) => <Checkbox key={b.id} checked={f.v.batches.includes(b.id)} onChange={(v) => f.set("batches", v ? [...f.v.batches, b.id] : f.v.batches.filter((x) => x !== b.id))}>{b.name}</Checkbox>)}</div>
          <Btn disabled={!canSave} onClick={async () => { const e = add?.ex; await uc.saveResource({ id: e?.id ?? uid("rs"), inst: sc.instId, title: f.v.title.trim(), type: f.v.type as Resource["type"], subject: f.v.subject, chapter: e?.chapter ?? "General", folder: f.v.subject, batchIds: f.v.batches, size: file?.size ?? e?.size ?? 0, by: "Dr. Anil Joshi", at: e?.at ?? nowISO(), url: f.v.type === "link" ? f.v.url : undefined, bookmarked: e?.bookmarked ?? false }); toast(e ? "Resource updated" : "Added (demo — file not stored in cloud)"); setAdd(null); }}>{add?.ex ? "Save changes" : "Add resource"}</Btn></div>
      </Sheet>
    </Page>
  );
}

/* S39 */
function NoticesMgmt({ params }: P) {
  const sc = useScope();
  const { session, confirm, toast } = useApp();
  const [tab, setTab] = useState<string>(params.tab ?? "notices");
  const [status, setStatus] = useState("All");
  const [view, setView] = useState<Notice | null>(sc.notices.find((n) => n.id === params.id) ?? null);
  const [add, setAdd] = useState<null | { ex?: Notice }>(null);
  const [file, setFile] = useState<import("@/domain/types").FileMeta | null>(null);
  const canPub = can(sc.db, session.role, "notices.publish");
  const f = useForm({ title: "", body: "", category: "General", aud: "all", batches: [] as string[], mode: "now", date: "", time: "09:00", expiry: "" }, (v) => ({
    title: v.title.trim().length < 4 ? "Enter a title" : undefined, body: v.body.trim().length < 10 ? "Write at least 10 characters" : undefined, batches: v.aud === "batches" && !v.batches.length ? "Select at least one batch" : undefined,
    date: v.mode === "schedule" && !v.date ? "Pick a publish date" : v.mode === "schedule" && v.date < today() ? "Schedule date can't be in the past" : undefined, expiry: v.expiry && v.expiry < today() ? "Expiry can't be in the past" : undefined,
  }));
  const [seed, setSeed] = useState<string | null>(null);
  const k = add ? add.ex?.id ?? "new" : null;
  if (seed !== k) { setSeed(k); if (add) { const e = add.ex; f.setV({ title: e?.title ?? "", body: e?.body ?? "", category: e?.category ?? "General", aud: e?.audience.type ?? "all", batches: e?.audience.batchIds ?? [], mode: e?.status === "scheduled" ? "schedule" : "now", date: e?.status === "scheduled" ? e.publishAt.slice(0, 10) : "", time: "09:00", expiry: e?.expiry ?? "" }); setFile(null); } }
  const list = sc.notices.filter((n) => status === "All" || n.status === status).sort((a, b) => (a.publishAt < b.publishAt ? 1 : -1));
  const pendingLeaves = sc.leaves.filter((l) => l.kind === "student" && l.status === "pending");
  const pendingMeet = sc.meetings.filter((m) => m.status === "pending");
  const audLabel = (n: Notice) => n.audience.type === "batches" ? n.audience.batchIds.map((b) => sc.batches.find((x) => x.id === b)?.name.split(" – ")[0]).join(", ") : lab(n.audience.type);
  const publish = () => { const ex = add?.ex; const sch = f.v.mode === "schedule"; confirm({ title: sch ? "Schedule this notice?" : "Publish this notice now?", body: sch ? `It will go live on ${dmy(f.v.date)}.` : "The selected audience will see it immediately and get a notification.", confirmLabel: sch ? "Schedule" : "Publish", onConfirm: async () => { await uc.publishNotice({ id: ex?.id ?? uid("n"), inst: sc.instId, title: f.v.title.trim(), body: f.v.body.trim(), category: f.v.category as Notice["category"], audience: { type: f.v.aud as Notice["audience"]["type"], batchIds: f.v.aud === "batches" ? f.v.batches : [] }, status: sch ? "scheduled" : "published", publishAt: sch ? `${f.v.date}T${f.v.time}:00` : nowISO(), expiry: f.v.expiry || undefined, attachment: file ?? ex?.attachment, readBy: ex?.readBy ?? [], by: "Dr. Anil Joshi" }, session.role); toast(sch ? "Notice scheduled" : "Notice published"); setAdd(null); } }); };
  return (
    <Page title="Notices" right={canPub ? <IconBtn icon={Plus} label="Create notice" tone="soft" onClick={() => setAdd({})} /> : undefined}>
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "notices", label: "Notices" }, { value: "requests", label: "Requests", count: pendingLeaves.length + pendingMeet.length }]} /></div>
      {tab === "notices" && <><div className="mt-2"><Chips value={status} onChange={setStatus} options={["All", "published", "scheduled", "archived"]} /></div>
        {list.length ? <div className="space-y-2.5">{list.map((n) => <NoticeCard key={n.id} n={n} onClick={() => setView(n)} />)}</div> : <Empty icon={Megaphone} title="No notices" body="Create a notice to reach students, parents or teachers." action={canPub ? "Create notice" : undefined} onAction={() => setAdd({})} />}</>}
      {tab === "requests" && <div className="mt-3 space-y-4">
        <Section title="Student leave requests">{pendingLeaves.length ? pendingLeaves.map((l) => <Card key={l.id} className="mb-2.5"><div className="font-semibold">{sc.students.find((s) => s.id === l.personId)?.name}</div><div className="text-[12.5px] text-mute">{dmy(l.from)} – {dmy(l.to)} · {l.reason} · by {l.by}</div><div className="mt-3 flex gap-2"><Btn size="sm" variant="secondary" onClick={async () => { await uc.decideLeave(l.id, "rejected"); toast("Rejected", "info"); }}>Reject</Btn><Btn size="sm" onClick={async () => { await uc.decideLeave(l.id, "approved"); toast("Approved"); }}>Approve</Btn></div></Card>) : <Card><p className="text-[13.5px] text-mute">No pending leave requests.</p></Card>}</Section>
        <Section title="Parent meeting requests">{pendingMeet.length ? pendingMeet.map((m) => <Card key={m.id} className="mb-2.5"><div className="font-semibold">{sc.students.find((s) => s.id === m.studentId)?.name} · {sc.staff.find((t) => t.id === m.teacherId)?.name}</div><div className="text-[12.5px] text-mute">{dmy(m.date)} at {time12(m.time)} · {m.reason}</div><div className="mt-3 flex gap-2"><Btn size="sm" variant="secondary" onClick={async () => { await uc.decideMeeting(m.id, "declined"); toast("Declined", "info"); }}>Decline</Btn><Btn size="sm" onClick={async () => { await uc.decideMeeting(m.id, "accepted"); toast("Accepted"); }}>Accept</Btn></div></Card>) : <Card><p className="text-[13.5px] text-mute">No pending meeting requests.</p></Card>}</Section></div>}
      <Sheet open={!!view} onClose={() => setView(null)} title={view?.title}>{view ? <div className="space-y-3"><div className="flex flex-wrap gap-2"><Badge tone="brand">{view.category}</Badge><StatusBadge status={view.status} /></div><p className="text-[14px] leading-relaxed">{view.body}</p>{view.attachment ? <FileItem file={view.attachment} /> : null}<Card><Kv k="Audience" v={audLabel(view)} /><Kv k="Publish" v={dtLabel(view.publishAt)} />{view.expiry ? <Kv k="Expires" v={dmy(view.expiry)} /> : null}<Kv k="Read by roles" v={view.readBy.length ? view.readBy.map((r) => lab(r)).join(", ") : "No one yet"} /></Card>
        {canPub ? <div className="flex gap-2"><Btn variant="secondary" icon={Edit3} onClick={() => { setAdd({ ex: view }); setView(null); }}>Edit</Btn>{view.status !== "archived" ? <Btn variant="secondary" icon={Archive} onClick={() => confirm({ title: "Archive this notice?", body: "It will disappear for students, parents and teachers.", confirmLabel: "Archive", onConfirm: async () => { await uc.save("notices", { ...view, status: "archived" }); toast("Notice archived", "info"); setView(null); } })}>Archive</Btn> : null}</div> : null}</div> : null}</Sheet>
      <Sheet open={!!add} onClose={() => setAdd(null)} title={add?.ex ? "Edit notice" : "Create notice"}>
        <div className="space-y-4"><TextInput label="Title" required {...f.bind("title")} /><TextInput label="Message" required multiline rows={4} {...f.bind("body")} /><Select label="Category" options={["General", "Academic", "Exam", "Fee", "Holiday"]} value={f.v.category} onChange={(v) => f.set("category", v)} />
          <Select label="Audience" required options={[{ value: "all", label: "Everyone" }, { value: "students", label: "All students" }, { value: "parents", label: "All parents" }, { value: "teachers", label: "Teachers" }, { value: "batches", label: "Selected batches" }]} value={f.v.aud} onChange={(v) => f.set("aud", v)} />
          {f.v.aud === "batches" ? <div>{sc.batches.map((b) => <Checkbox key={b.id} checked={f.v.batches.includes(b.id)} onChange={(v) => f.set("batches", v ? [...f.v.batches, b.id] : f.v.batches.filter((x) => x !== b.id))}>{b.name}</Checkbox>)}{f.errors.batches ? <p className="mt-1 text-[12px] text-bad">{f.errors.batches}</p> : null}</div> : null}
          <FilePicker label="Attachment" value={file} onChange={setFile} />
          <Segmented value={f.v.mode} onChange={(v) => f.set("mode", v)} options={[{ value: "now", label: "Publish now" }, { value: "schedule", label: "Schedule" }]} />
          {f.v.mode === "schedule" ? <div className="grid grid-cols-2 gap-3"><DatePicker label="Date" required value={f.v.date} onChange={(v) => f.set("date", v)} error={f.v.date ? f.errors.date : undefined} /><TimePicker label="Time" required value={f.v.time} onChange={(v) => f.set("time", v)} /></div> : null}
          <DatePicker label="Expiry date" value={f.v.expiry} onChange={(v) => f.set("expiry", v)} error={f.errors.expiry} />
          <Btn disabled={!f.valid} onClick={publish}>{f.v.mode === "schedule" ? "Schedule notice" : "Publish notice"}</Btn></div>
      </Sheet>
    </Page>
  );
}

/* S40 */
function Insights(_: P) {
  const sc = useScope();
  const { session } = useApp();
  const [range, setRange] = useState("30");
  if (!can(sc.db, session.role, "reports.view")) return <Page title="Insights"><Denied /></Page>;
  const from = addDays(-Number(range));
  const fees = instFees(sc);
  const perf = batchPerformance(sc);
  const conv = pct(sc.enquiries.filter((e) => e.status === "Converted").length, sc.enquiries.length);
  const wd: Record<number, { p: number; m: number }> = {};
  Object.entries(sc.db.attendance).forEach(([k, v]) => { const [d, sid] = k.split("|"); if (d < from || !sc.students.some((s) => s.id === sid)) return; const w = parse(d).getDay(); (wd[w] ??= { p: 0, m: 0 }).m++; if (v !== "A") wd[w].p++; });
  const wdData = [1, 2, 3, 4, 5, 6].filter((d) => wd[d]).map((d) => ({ label: DAYS[d], value: pct(wd[d].p, wd[d].m), tone: "sky" as Tone }));
  const exams = sc.exams.filter((x) => x.status === "published" && x.date >= from).map((x) => ({ x, st: examStats(sc.db, x) }));
  const Note = ({ children }: { children: React.ReactNode }) => <p className="mt-2 border-t border-line pt-2 text-[11.5px] leading-snug text-mute"><b>How it's calculated:</b> {children}</p>;
  return (
    <Page title="Insights" subtitle="Clear numbers, no guesswork">
      <div className="pt-1"><Chips value={range} onChange={setRange} options={[{ value: "7", label: "Last 7 days" }, { value: "30", label: "Last 30 days" }, { value: "90", label: "Last 90 days" }]} /></div>
      <Section title="Admission conversion"><Card><div className="flex items-center gap-4"><Donut value={conv} tone="ok" sub="converted" /><div className="text-[13px] text-mute"><b className="text-ink">{sc.enquiries.filter((e) => e.status === "Converted").length}</b> admissions from <b className="text-ink">{sc.enquiries.length}</b> enquiries</div></div><Note>converted enquiries ÷ all enquiries recorded to date.</Note></Card></Section>
      <Section title="Fee collection & dues"><Card><div className="flex items-center gap-4"><Donut value={fees.rate} tone="brand" sub="collected" /><div className="flex-1 text-[13px]"><Kv k="Collected" v={inr(fees.collected)} /><Kv k="Outstanding" v={inr(fees.outstanding)} /><Kv k="Overdue" v={inr(fees.overdue)} /></div></div><Note>sum of paid demo payments ÷ total fees after discounts for active students.</Note></Card></Section>
      <Section title="Attendance by weekday">{wdData.length ? <Card><Bars data={wdData} max={100} height={90} suffix="%" /><Note>students present or late ÷ students marked, for each weekday in the selected period.</Note></Card> : <Card><p className="text-[13px] text-mute">No attendance recorded in this period.</p></Card>}</Section>
      <Section title="Batch performance"><Card>{perf.map((p) => <div key={p.batch.id} className="mb-3 last:mb-0"><div className="flex justify-between text-[13px]"><b>{p.batch.name.split(" – ")[0]}</b><span className="text-mute">Exams {p.examAvg || "—"}% · Attendance {p.attAvg || "—"}%</span></div><div className="mt-1.5"><Progress value={p.examAvg} tone="violet" height={6} /></div></div>)}<Note>average of published exam percentages and attendance for active students in each batch.</Note></Card></Section>
      <Section title="Exam performance">{exams.length ? <Card><Bars height={80} max={100} suffix="%" data={exams.slice(0, 5).map((e) => ({ label: e.x.subject.slice(0, 5), value: e.st.avgPct, tone: "violet" as Tone }))} /><Note>class average percentage for exams whose results were published in this period.</Note></Card> : <Card><p className="text-[13px] text-mute">No results were published in this period.</p></Card>}</Section>
      <Section title="Staff workload"><Card><Bars height={80} max={24} suffix="h" data={sc.staff.slice(0, 6).map((s) => ({ label: s.name.split(" ")[0], value: s.weeklyHours, tone: s.weeklyHours > 18 ? "warn" : "brand" }))} /><Note>scheduled weekly teaching hours per staff member (24 h is the suggested weekly maximum).</Note></Card></Section>
    </Page>
  );
}

/* S41 */
function Settings(_: P) {
  const sc = useScope();
  const { session, confirm, toast } = useApp();
  const me = useMe();
  const [tab, setTab] = useState("profile");
  const [edit, setEdit] = useState(false);
  const [logo, setLogo] = useState<import("@/domain/types").FileMeta | null>(null);
  const [exp, setExp] = useState(false);
  const f = useForm({ name: sc.inst.name, city: sc.inst.city, phone: "9822000111", email: "office@aarohan.example" }, (v) => ({ name: v.name.trim().length < 3 ? "Enter name" : undefined, phone: validPhone(v.phone) ? undefined : "Invalid phone" }));
  const manage = can(sc.db, session.role, "staff.manage");
  if (!manage) return <Page title="Institute settings"><Denied /></Page>;
    return (
    <Page title="Settings" subtitle={sc.inst.name}>
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "profile", label: "Institute" }, { value: "members", label: "Members" }, { value: "perms", label: "Permissions" }, { value: "more", label: "Plan & more" }]} /></div>
      <div className="mt-3">
        {tab === "profile" && <div className="space-y-3"><Card><div className="flex items-center gap-3"><Avatar name={sc.inst.name} size={56} tone="violet" /><div className="min-w-0 flex-1"><div className="text-[16px] font-semibold">{sc.inst.name}</div><div className="text-[12.5px] text-mute">{sc.inst.type} · {sc.inst.city}, {sc.inst.state}</div></div></div><div className="mt-3"><Btn variant="secondary" size="sm" icon={Pencil} onClick={() => setEdit(true)}>Edit profile</Btn></div></Card>
          <Card><Kv k="Institute code" v={sc.inst.code} /><Kv k="Invite code" v={sc.inst.invite} /><Kv k="Active session" v={sc.sessions.find((s) => s.active)?.label ?? "—"} /><Kv k="Batches" v={sc.batches.length} /></Card>
          <Card><FilePicker label="Institute logo" accept="image/*" value={logo} onChange={setLogo} /></Card></div>}
        {tab === "members" && <div className="space-y-3"><Banner>Members are the owner, staff and any account linked to the institute. Remove access when someone leaves.</Banner><List><Row lead={<Avatar name={me.name} tone="brand" />} title="Dr. Anil Joshi" sub="Owner · full access" right={<Badge tone="brand">Owner</Badge>} noChevron />{sc.staff.map((s) => <Row key={s.id} lead={<Avatar name={s.name} tone="violet" />} title={s.name} sub={`${s.role} · ${s.status}`} right={s.status === "inactive" ? <Badge tone="mute">Removed</Badge> : <IconBtn icon={UserX} label={`Remove ${s.name}`} onClick={() => confirm({ title: `Remove ${s.name}?`, body: "They lose access to the institute immediately. Their past records are kept.", confirmLabel: "Remove", danger: true, onConfirm: async () => { await uc.save("staff", { ...s, status: "inactive" }); toast("Member removed", "info"); } })} />} noChevron />)}</List>
          <Section title="Role assignments"><List>{(["owner", "teacher", "student", "parent"] as Role[]).map((r) => <Row key={r} icon={ShieldCheck} title={ROLE_LABEL[r]} sub={r === "owner" ? "Full access to all modules" : r === "teacher" ? "Assigned classes and students only" : r === "student" ? "Own records only" : "Verified linked children only"} noChevron />)}</List></Section></div>}
        {tab === "perms" && <div className="space-y-3"><Banner tone="warn" icon={ShieldCheck}>These switches control what the app shows. In production, the backend must enforce the same rules.</Banner>
          <Card pad={false}><div className="border-b border-line px-4 py-3 text-[14px] font-semibold">Teacher permissions</div>{PERMS.map((p) => <Switch key={p.key} checked={sc.db.permissions.teacher[p.key]} label={p.label} onChange={async (v) => { await uc.setPermissions({ ...sc.db.permissions, teacher: { ...sc.db.permissions.teacher, [p.key]: v } }, sc.instId); toast(`Teacher: ${p.label} ${v ? "on" : "off"}`, "info"); }} />)}</Card>
          <Card><div className="text-[13px] leading-relaxed text-mute"><b className="text-ink">Students</b> can only see their own records. <b className="text-ink">Parents</b> can only see verified, linked children. These rules are fixed.</div></Card></div>}
        {tab === "more" && <div className="space-y-3">
          <Card><div className="flex items-center justify-between"><div><div className="text-[12px] text-mute">Plan</div><div className="text-[17px] font-bold">Prototype (demo)</div></div><Badge tone="warn">Not billable</Badge></div><p className="mt-2 text-[12.5px] text-mute">No subscription is active. Real plans and billing will be offered in the production product.</p></Card>
          <Section title="Integrations"><List>{[["SMS / OTP provider", Plug], ["Online payment gateway", Wallet], ["WhatsApp notifications", Megaphone]].map(([n, I]) => <Row key={n as string} icon={I as typeof Plug} tone="mute" title={n as string} sub="Placeholder — not connected" right={<Badge tone="mute" icon={Ban}>Not connected</Badge>} noChevron />)}</List></Section>
          <Section title="Audit activity"><List>{sc.audit.slice().sort((a, b) => (a.at < b.at ? 1 : -1)).map((a) => <Row key={a.id} icon={Clock} title={<span className="whitespace-normal text-[13.5px]">{a.text}</span>} sub={ago(a.at)} noChevron />)}</List></Section>
          <Section title="Data & support"><List><Row icon={Download} title="Export institute data" sub="Preview only" onClick={() => setExp(true)} /><Row icon={Settings2} title="Contact support" sub="support@guruflow.example" onClick={() => toast("Demo: email app would open", "info")} /></List></Section></div>}
      </div>
      <Sheet open={edit} onClose={() => setEdit(false)} title="Edit institute"><div className="space-y-4"><TextInput label="Institute name" required {...f.bind("name")} /><TextInput label="City" {...f.bind("city")} /><TextInput label="Contact number" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("phone")} /><Btn disabled={!f.valid} onClick={async () => { await uc.save("institutes", { ...sc.inst, name: f.v.name.trim(), city: f.v.city }); toast("Institute profile saved"); setEdit(false); }}>Save</Btn></div></Sheet>
      <Sheet open={exp} onClose={() => setExp(false)} title="Export preview"><Banner tone="warn">Demo preview — not a real export from a production database.</Banner><div className="mt-3"><Kv k="Students" v={sc.students.length} /><Kv k="Staff" v={sc.staff.length} /><Kv k="Attendance records" v={Object.keys(sc.db.attendance).length} /><Kv k="Payments (demo)" v={sc.payments.length} /></div></Sheet>
    </Page>
  );
}

export const ownerB: ScreenMap = {
  S31: def("Timetable Management", "owner", TimetableMgmt), S32: def("Attendance Reports", "owner", AttendanceReports), S33: def("Exam Management", "owner", ExamMgmt), S34: def("Exam Details / Marks Overview", "owner", ExamDetail),
  S35: def("Fees Dashboard", "owner", FeesDashboard), S36: def("Fee Structures / Assignments", "owner", FeeStructures), S37: def("Payments / Ledger / Receipts", "owner", Ledger), S38: def("Study Resources Management", "owner", ResourcesMgmt),
  S39: def("Notices / Communication", "owner", NoticesMgmt), S40: def("Insights / Reports", "owner", Insights), S41: def("Institute Settings / Members / Permissions", "owner", Settings),
};
export { Wallet, GraduationCap, FileText, IndianRupee, Calendar, Undo2, Copy, Search, AttPill, StackBar, Progress, IconTile, Archive, Link2, FolderOpen, Receipt, longDate, relDay, batchAttOn, instAttToday, resultsFor, studentAtt, subFor, Batch };
