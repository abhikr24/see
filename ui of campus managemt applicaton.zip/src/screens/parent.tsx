"use client";
import React, { useState } from "react";
import { Bell, CalendarOff, CheckCircle2, ClipboardList, CreditCard, GraduationCap, HelpCircle, Info, LogOut, Megaphone, Handshake, Phone, Plus, Receipt, ShieldCheck, Sparkles, Users, Lock, FileText, Clock } from "lucide-react";
import type { Notice } from "@/domain/types";
import { useApp, useMe, useScope } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Chips, Denied, DemoTag, Empty, IconTile, Kv, List, Page, Progress, Row, Section, Segmented, Sheet, Stat, Tabs, Tone } from "@/ui/kit";
import { DatePicker, FileItem, Select, Switch, TextInput, useForm } from "@/ui/forms";
import { AttPill, Bars, Donut, LineChart, MonthCalendar } from "@/ui/charts";
import { ExamCard, FeeCard, HomeworkCard, NoticeCard, NotificationItem, StatusBadge } from "@/ui/cards";
import { HomeFrame, useNotifs } from "./common";
import { resolveDest } from "./shared-core";
import { Receipt_ } from "./owner-b";
import { def, P, ScreenMap } from "./types";
import { addDays, ago, dmy, gradeOf, inr, longDate, pct, relDay, time12, today } from "@/lib/fmt";
import { feeSummary, lockedChildren, noticeVisible, resultsFor, studentAtt, subFor } from "@/features/selectors";
import { uc } from "@/features/usecases";

function usePar() {
  const sc = useScope();
  const me = useMe();
  const child = me.child;
  const batch = child ? sc.batches.find((b) => b.id === child.batchId) : undefined;
  return { sc, me, child, children: me.children, batch };
}
function ChildPicker() {
  const { children, child } = usePar();
  const { setChild, toast } = useApp();
  if (children.length < 2) return child ? <div className="flex items-center gap-3 px-1"><Avatar name={child.name} size={34} /><div className="text-[13px]"><b>{child.name}</b><span className="text-mute"> · {child.sid}</span></div></div> : null;
  return (
    <div role="radiogroup" aria-label="Select child" className="flex gap-2">
      {children.map((c) => (
        <button key={c.id} role="radio" aria-checked={c.id === child?.id} onClick={() => { setChild(c.id); toast(`Showing ${c.name.split(" ")[0]}'s records`, "info"); }} className={`flex min-h-12 flex-1 items-center gap-2 rounded-2xl border px-2.5 text-left ${c.id === child?.id ? "border-brand bg-brand-soft" : "border-line bg-white"}`}>
          <Avatar name={c.name} size={32} tone={c.id === child?.id ? "brand" : "mute"} /><span className="min-w-0"><span className="block truncate text-[13px] font-semibold">{c.name.split(" ")[0]}</span><span className="block truncate text-[11px] text-mute">{c.batchId === "b1" ? "Class 10" : "Class 8"}</span></span>
        </button>))}
    </div>
  );
}
function NoChild() {
  const { sc } = usePar();
  const locked = lockedChildren(sc.db, sc.instId);
  return <Page title="Your children"><Denied body={locked.length ? `${locked.map((l) => l.name).join(", ")} isn't linked to your account yet. The institute must verify you and record your consent first.` : "No verified child is linked to your account. Ask the institute to link you."} /></Page>;
}

/* S72 */
function ParentHome(_: P) {
  const { sc, me, child, batch } = usePar();
  const { push, session } = useApp();
  if (!child) return <HomeFrame greeting={`Namaste, ${me.first}`}><Card><NoChildInline /></Card></HomeFrame>;
  const db = sc.db;
  const att = studentAtt(db, child.id), rs = resultsFor(db, child.id).slice(0, 2);
  const hws = sc.homework.filter((h) => h.batchId === child.batchId && h.status === "published").map((h) => ({ h, s: subFor(db, h, child.id).status }));
  const pend = hws.filter((x) => ["pending", "returned"].includes(x.s)).length, over = hws.filter((x) => x.s === "overdue").length;
  const tests = sc.exams.filter((x) => x.batchId === child.batchId && x.status === "scheduled" && x.date >= today()).sort((a, b) => (a.date < b.date ? -1 : 1));
  const notices = sc.notices.filter((n) => noticeVisible(n, "parent", [child.batchId])).sort((a, b) => (a.publishAt < b.publishAt ? 1 : -1)).slice(0, 2);
  const fee = feeSummary(db, child.id);
  const todayAtt = db.attendance[`${today()}|${child.id}`];
  const week = studentAtt(db, child.id, addDays(-6));
  return (
    <HomeFrame greeting={`Namaste, ${me.first}`} sub={sc.inst.name}>
      <Card><div className="mb-2 text-[12px] font-semibold uppercase tracking-wide text-mute">Viewing</div><ChildPicker /></Card>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Card onClick={() => push("S73")} className="!p-3.5"><div className="flex items-center gap-3"><Donut value={att.pct} size={62} tone={att.pct >= 85 ? "ok" : "warn"} /><div><div className="text-[12px] text-mute">Attendance</div><div className="mt-0.5"><AttPill status={todayAtt} /></div></div></div></Card>
        <Card onClick={() => push("S75")} className="!p-3.5"><div className="text-[12px] text-mute">Homework</div><div className="mt-1 text-[22px] font-bold leading-none">{pend + over}</div><div className={`mt-1 text-[12px] font-medium ${over ? "text-bad" : "text-mute"}`}>{over ? `${over} overdue` : "to be done"}</div></Card>
      </div>
      {fee && fee.outstanding > 0 ? <Card onClick={() => push("S77")} className="mt-3 !bg-warn-soft !border-warn/20"><div className="flex items-center gap-3"><IconTile icon={CreditCard} tone="warn" /><div className="min-w-0 flex-1"><div className="text-[14px] font-semibold text-warn">{fee.overdue ? "Fee overdue" : "Fee reminder"}</div><div className="text-[12.5px] text-ink">{fee.next ? `${inr(fee.next.amount - fee.next.paid)} due ${dmy(fee.next.due)} (${relDay(fee.next.due)})` : `${inr(fee.outstanding)} outstanding`}</div></div></div></Card> : null}
      <Section title="Latest results" action="All results" onAction={() => push("S74")}>{rs.length ? <div className="space-y-2.5">{rs.map((r) => <Card key={r.exam.id} onClick={() => push("S74")} className="!p-3.5"><div className="flex items-center gap-3"><IconTile icon={GraduationCap} tone="violet" /><div className="min-w-0 flex-1"><div className="text-[14.5px] font-semibold">{r.exam.name}</div><div className="text-[12px] text-mute">{r.exam.subject} · {dmy(r.exam.date)}</div></div><div className="text-right"><div className="text-[16px] font-bold">{r.marks}/{r.exam.max}</div><div className="text-[11.5px] text-mute">{r.pct}%</div></div></div></Card>)}</div> : <Card><p className="text-[13.5px] text-mute">No published results yet.</p></Card>}</Section>
      {tests.length ? <Section title="Upcoming tests"><div className="space-y-2.5">{tests.slice(0, 2).map((x) => <ExamCard key={x.id} x={x} right={<Badge tone="violet">{relDay(x.date)}</Badge>} />)}</div></Section> : null}
      <Section title="Important notices" action="All" onAction={() => push("S79")}><div className="space-y-2.5">{notices.map((n) => <NoticeCard key={n.id} n={n} read={n.readBy.includes(session.role)} onClick={() => push("S79", { id: n.id })} />)}</div></Section>
      <Section title="This week at a glance"><Card onClick={() => push("S76")}><p className="text-[14px] leading-relaxed">{child.name.split(" ")[0]} attended <b>{week.p + week.l}</b> of <b>{week.total}</b> classes this week{week.a ? `, with ${week.a} absence${week.a > 1 ? "s" : ""}` : ""}. {pend + over ? `${pend + over} homework item${pend + over > 1 ? "s are" : " is"} still pending.` : "All homework is up to date."}</p><div className="mt-2 text-[13px] font-semibold text-brand">Open weekly digest →</div></Card></Section>
      <span className="hidden">{batch?.name}</span>
    </HomeFrame>
  );
}
function NoChildInline() { return <div className="text-[14px] text-mute">No verified child is linked yet. The institute needs to verify you and record your consent before records are shown.</div>; }

/* S73 */
function ChildAttendance(_: P) {
  const { sc, child } = usePar();
  const [m, setM] = useState({ y: new Date().getFullYear(), m: new Date().getMonth() });
  const { push } = useApp();
  if (!child) return <NoChild />;
  const att = studentAtt(sc.db, child.id);
  const absences = Object.entries(att.byDate).filter(([, v]) => v === "A").sort((a, b) => (a[0] < b[0] ? 1 : -1));
  const notifs = sc.db.notifications.filter((n) => n.studentId === child.id && n.cat === "attendance").slice(0, 3);
  return (
    <Page title="Attendance"><div className="space-y-3 pt-1"><ChildPicker />
      <Card><div className="flex items-center gap-4"><Donut value={att.pct} size={92} tone={att.pct >= 85 ? "ok" : "warn"} sub="attended" /><div className="grid flex-1 grid-cols-3 text-center"><div><div className="text-[22px] font-bold text-ok">{att.p}</div><div className="text-[11px] text-mute">Present</div></div><div><div className="text-[22px] font-bold text-bad">{att.a}</div><div className="text-[11px] text-mute">Absent</div></div><div><div className="text-[22px] font-bold text-warn">{att.l}</div><div className="text-[11px] text-mute">Late</div></div></div></div><p className="mt-3 text-[12px] text-mute">Based on {att.total} class days. Late arrivals count as attended.</p></Card>
      <Card><MonthCalendar year={m.y} month={m.m} marks={att.byDate} onChange={(y, mo) => setM({ y, m: mo })} /></Card>
      <Section title="Absence history">{absences.length ? <List>{absences.slice(0, 8).map(([d]) => <Row key={d} icon={CalendarOff} tone="bad" title={longDate(d)} sub={dmy(d)} right={<Badge tone="bad">Absent</Badge>} noChevron />)}</List> : <Card><p className="text-[13.5px] text-mute">No absences recorded. Wonderful!</p></Card>}<div className="mt-3"><Btn variant="secondary" icon={CalendarOff} onClick={() => push("S80")}>Apply for leave</Btn></div></Section>
      {notifs.length ? <Section title="Attendance alerts"><List>{notifs.map((n) => <Row key={n.id} icon={Bell} tone="warn" title={<span className="whitespace-normal text-[13.5px]">{n.title}</span>} sub={ago(n.at)} noChevron />)}</List></Section> : null}</div></Page>
  );
}

/* S74 */
function ChildResults(_: P) {
  const { sc, child, batch } = usePar();
  if (!child) return <NoChild />;
  const rs = resultsFor(sc.db, child.id);
  const subjects = Object.keys(batch?.subjectTeachers ?? {});
  const bySub = subjects.map((s) => { const x = rs.filter((r) => r.exam.subject === s); return { s, v: x.length ? Math.round(x.reduce((a, r) => a + r.pct, 0) / x.length) : null }; });
  const timeline = rs.slice().reverse();
  const fb = sc.submissions.filter((x) => x.studentId === child.id && x.feedback).slice(0, 3);
  const attention = bySub.filter((x) => x.v !== null && x.v < 65);
  const avg = rs.length ? Math.round(rs.reduce((a, r) => a + r.pct, 0) / rs.length) : 0;
  return (
    <Page title="Results & progress"><div className="space-y-3 pt-1"><ChildPicker />
      {rs.length === 0 ? <Empty icon={GraduationCap} title="No results published yet" body="Results show up here as soon as the teacher publishes them." /> : <>
        <Card className="!bg-gradient-to-br !from-brand-dark !to-brand !text-white"><div className="text-[12px] text-white/70">Overall average</div><div className="mt-1 text-[32px] font-bold leading-none">{avg}%</div><div className="mt-1 text-[13px] text-white/80">Grade {gradeOf(avg)} · {rs.length} tests</div></Card>
        <Banner icon={Info}>{avg >= 75 ? `${child.name.split(" ")[0]} is doing very well. Keep encouraging regular study.` : avg >= 60 ? `${child.name.split(" ")[0]} is making steady progress. A little extra practice can help.` : `${child.name.split(" ")[0]} may need some extra support. Consider speaking with the teacher.`}</Banner>
        <Section title="Recent exams"><List>{rs.slice(0, 5).map((r) => <Row key={r.exam.id} icon={GraduationCap} tone="violet" title={r.exam.name} sub={`${r.exam.subject} · ${dmy(r.exam.date)}`} right={<div className="text-right"><div className="text-[15px] font-bold">{r.marks}/{r.exam.max}</div><div className="text-[11.5px] text-mute">{r.pct}%</div></div>} noChevron />)}</List></Section>
        <Section title="Subject-wise performance"><Card className="space-y-3">{bySub.map((x) => <div key={x.s}><div className="flex justify-between text-[13px]"><b>{x.s}</b><span className="text-mute">{x.v === null ? "No result yet" : `${x.v}%`}</span></div><div className="mt-1.5"><Progress value={x.v ?? 0} tone={x.v !== null && x.v < 65 ? "warn" : "violet"} height={7} label={x.s} /></div></div>)}</Card></Section>
        {timeline.length > 1 ? <Section title="Progress over time"><Card><LineChart points={timeline.map((r) => r.pct)} labels={timeline.map((r) => dmy(r.exam.date).slice(0, 5))} /></Card></Section> : null}
        <Section title="Areas that need attention">{attention.length ? <Card className="space-y-2">{attention.map((x) => <div key={x.s} className="text-[13.5px] leading-snug"><b>{x.s}</b> — average is {x.v}%. Revising basics for 15 minutes a day usually helps.</div>)}</Card> : <Card><p className="text-[13.5px] text-mute">No subject needs special attention right now.</p></Card>}</Section>
        {fb.length ? <Section title="Teacher feedback">{fb.map((x) => <Card key={x.id} className="mb-2"><div className="text-[11.5px] text-mute">{sc.homework.find((h) => h.id === x.hwId)?.subject}</div><p className="text-[13.5px]">“{x.feedback}”</p></Card>)}</Section> : null}</>}</div></Page>
  );
}

/* S75 */
function ChildHomework(_: P) {
  const { sc, child } = usePar();
  const [tab, setTab] = useState("all");
  const [open, setOpen] = useState<string | null>(null);
  if (!child) return <NoChild />;
  const items = sc.homework.filter((h) => h.batchId === child.batchId && h.status === "published").map((h) => ({ h, ...subFor(sc.db, h, child.id) })).sort((a, b) => (a.h.due < b.h.due ? 1 : -1));
  const list = items.filter((x) => tab === "all" || (tab === "pending" && ["pending", "returned"].includes(x.status)) || (tab === "overdue" && x.status === "overdue") || (tab === "done" && ["submitted", "reviewed"].includes(x.status)));
  const o = items.find((x) => x.h.id === open);
  return (
    <Page title="Homework"><div className="space-y-2 pt-1"><ChildPicker /><Tabs value={tab} onChange={setTab} options={[{ value: "all", label: "All" }, { value: "pending", label: "Pending" }, { value: "overdue", label: "Overdue" }, { value: "done", label: "Completed" }]} />
      {list.length ? <div className="space-y-2.5 pt-1">{list.map((x) => <HomeworkCard key={x.h.id} h={x.h} status={x.status} onClick={() => setOpen(x.h.id)} />)}</div> : <Empty icon={ClipboardList} title="Nothing here" body="No homework in this view." />}</div>
      <Sheet open={!!o} onClose={() => setOpen(null)} title={o?.h.title}>{o ? <div className="space-y-3"><div className="flex items-center justify-between"><span className="text-[13px] text-mute">{o.h.subject} · due {dmy(o.h.due)}</span><StatusBadge status={o.status} /></div><Card><p className="text-[13.5px] leading-relaxed">{o.h.instructions}</p></Card>{o.sub?.submittedAt ? <Card><Kv k="Submitted" v={ago(o.sub.submittedAt)} />{o.sub.marks !== undefined ? <Kv k="Marks" v={`${o.sub.marks}/${o.h.max}`} /> : null}</Card> : <Banner tone={o.status === "overdue" ? "bad" : "warn"}>{o.status === "overdue" ? "This homework is overdue." : "Not submitted yet."}</Banner>}{o.sub?.feedback ? <Card><div className="text-[12px] font-semibold text-mute">Teacher feedback</div><p className="mt-1 text-[14px]">“{o.sub.feedback}”</p></Card> : null}</div> : null}</Sheet>
    </Page>
  );
}

/* S76 */
function WeeklyDigest(_: P) {
  const { sc, child } = usePar();
  const { push } = useApp();
  if (!child) return <NoChild />;
  const db = sc.db;
  const from = addDays(-6);
  const att = studentAtt(db, child.id, from);
  const hws = sc.homework.filter((h) => h.batchId === child.batchId && h.status === "published" && h.due >= from && h.due <= addDays(7)).map((h) => ({ h, ...subFor(db, h, child.id) }));
  const done = hws.filter((x) => ["submitted", "reviewed"].includes(x.status)).length;
  const tests = resultsFor(db, child.id).filter((r) => r.exam.date >= addDays(-14));
  const mats = sc.resources.filter((r) => r.batchIds.includes(child.batchId) && r.at.slice(0, 10) >= from);
  const fb = sc.submissions.filter((x) => x.studentId === child.id && x.feedback).slice(0, 2);
  const events = sc.exams.filter((x) => x.batchId === child.batchId && x.status === "scheduled" && x.date >= today() && x.date <= addDays(14));
  const fee = feeSummary(db, child.id);
  const actions: { t: string; to: string; tone: Tone }[] = [];
  if (hws.some((x) => x.status === "overdue")) actions.push({ t: "Help with overdue homework", to: "S75", tone: "bad" });
  if (fee?.next && fee.next.due <= addDays(14)) actions.push({ t: `Fee instalment ${fee.overdue ? "overdue" : "due"} ${dmy(fee.next.due)}`, to: "S77", tone: "warn" });
  if (events[0]) actions.push({ t: `Prepare for ${events[0].name} (${dmy(events[0].date)})`, to: "S62", tone: "sky" as Tone });
  return (
    <Page title="Weekly digest" subtitle={`${dmy(from)} – ${dmy(today())}`}><div className="space-y-3 pt-1"><ChildPicker />
      <Card><div className="flex items-center gap-3"><IconTile icon={CheckCircle2} tone="ok" /><div className="flex-1"><div className="text-[14.5px] font-semibold">Attendance</div><div className="text-[12.5px] text-mute">{att.p} present · {att.l} late · {att.a} absent</div></div><Donut value={att.pct} size={54} tone={att.pct >= 85 ? "ok" : "warn"} /></div></Card>
      <Card><div className="flex items-center gap-3"><IconTile icon={ClipboardList} /><div className="flex-1"><div className="text-[14.5px] font-semibold">Homework</div><div className="text-[12.5px] text-mute">{done} of {hws.length} completed</div><div className="mt-1.5"><Progress value={pct(done, hws.length)} tone="ok" height={6} /></div></div></div></Card>
      <Section title="Recent tests">{tests.length ? <List>{tests.map((r) => <Row key={r.exam.id} icon={GraduationCap} tone="violet" title={r.exam.name} sub={r.exam.subject} right={<b>{r.marks}/{r.exam.max}</b>} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No tests in the last two weeks.</p></Card>}</Section>
      <Section title="New learning materials">{mats.length ? <List>{mats.map((r) => <Row key={r.id} icon={FileText} title={r.title} sub={r.subject} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No new materials this week.</p></Card>}</Section>
      {fb.length ? <Section title="Teacher feedback">{fb.map((x) => <Card key={x.id} className="mb-2"><p className="text-[13.5px]">“{x.feedback}”</p></Card>)}</Section> : null}
      <Section title="Coming up">{events.length ? <List>{events.map((x) => <Row key={x.id} icon={Clock} tone="sky" title={x.name} sub={`${dmy(x.date)} · ${time12(x.time)}`} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No tests in the next two weeks.</p></Card>}</Section>
      <Section title="What you can do">{actions.length ? <List>{actions.map((a) => <Row key={a.t} icon={Sparkles} tone={a.tone} title={<span className="whitespace-normal text-[13.5px]">{a.t}</span>} onClick={() => push(a.to)} />)}</List> : <Card><p className="text-[13.5px] text-mute">Nothing needs your action this week. 🎉</p></Card>}</Section></div></Page>
  );
}

/* S77 */
function ParentFees(_: P) {
  const { sc, child } = usePar();
  const { push } = useApp();
  const [how, setHow] = useState(false);
  if (!child) return <NoChild />;
  const f = feeSummary(sc.db, child.id);
  return (
    <Page title="Fees" subtitle="Demo records"><div className="space-y-3 pt-1"><ChildPicker />
      {!f ? <Empty icon={CreditCard} title="No fee plan assigned" body="The institute hasn't assigned a fee structure yet." /> : <>
        <FeeCard total={f.total} paid={f.paid} due={f.next?.due} overdue={f.overdue} />
        <Card><Kv k="Fee plan" v={f.fs.name} /><Kv k="Plan total" v={inr(f.fs.total)} />{f.acc.discount ? <Kv k={f.acc.discountReason || "Discount"} v={`− ${inr(f.acc.discount)}`} /> : null}<Kv k="You pay" v={<b>{inr(f.total)}</b>} /><Kv k="Paid so far" v={inr(f.paid)} /></Card>
        <Section title="Instalment schedule"><List>{f.installments.map((i) => <Row key={i.label} icon={i.status === "paid" ? CheckCircle2 : Clock} tone={i.status === "paid" ? "ok" : i.status === "overdue" ? "bad" : "warn"} title={`${i.label} · ${inr(i.amount)}`} sub={`Due ${dmy(i.due)}${i.paid && i.status !== "paid" ? ` · paid ${inr(i.paid)}` : ""}`} right={<StatusBadge status={i.status} />} noChevron />)}</List></Section>
        {f.outstanding > 0 ? <Btn onClick={() => setHow(true)}>How to pay</Btn> : null}<Btn variant="secondary" icon={Receipt} onClick={() => push("S78")}>Payment history & receipts</Btn></>}</div>
      <Sheet open={how} onClose={() => setHow(false)} title="How to pay"><div className="space-y-3"><Banner tone="warn" icon={Info}>Online payment isn't enabled in this prototype. When enabled, it will use a secure, trusted payment provider.</Banner><p className="text-[13.5px] leading-relaxed text-mute">For now, please pay at the institute office ({sc.inst.name}) by cash, cheque or bank transfer and ask for a receipt. The office will record it here.</p></div></Sheet>
    </Page>
  );
}

/* S78 */
function PaymentHistory(_: P) {
  const { sc, child } = usePar();
  const [view, setView] = useState<import("@/domain/types").Payment | null>(null);
  if (!child) return <NoChild />;
  const ps = sc.payments.filter((p) => p.studentId === child.id).sort((a, b) => (a.date < b.date ? 1 : -1));
  return (
    <Page title="Payments & receipts"><div className="space-y-3 pt-1"><ChildPicker /><Banner tone="warn" icon={Info}>These are <b>DEMO</b> records for the prototype. They are not real payments.</Banner>
      {ps.length ? <List>{ps.map((p) => <Row key={p.id} icon={Receipt} tone={p.status === "refunded" ? "mute" : "ok"} title={`${inr(p.amount)} · ${p.method}`} sub={`${dmy(p.date)} · Ref ${p.ref}`} right={<div className="flex flex-col items-end gap-1"><DemoTag />{p.status !== "received" ? <StatusBadge status={p.status} /> : null}</div>} onClick={() => setView(p)} />)}</List> : <Empty icon={Receipt} title="No payments yet" body="Payments recorded by the institute will appear here." />}</div>
      <Receipt_ p={view} studentName={child.name} onClose={() => setView(null)} />
    </Page>
  );
}

/* S79 — role-aware notices (also used by owner/teacher/student deep links) */
function Notices({ params }: P) {
  const { sc, me } = usePar();
  const { session } = useApp();
  const [cat, setCat] = useState("All");
  const [unread, setUnread] = useState(false);
  const notices = sc.notices.filter((n) => noticeVisible(n, session.role, me.batchIds) && n.status !== "archived").sort((a, b) => (a.publishAt < b.publishAt ? 1 : -1));
  const [view, setView] = useState<Notice | null>(notices.find((n) => n.id === params.id) ?? null);
  const open = (n: Notice) => { setView(n); uc.markNoticeRead(n.id, session.role); };
  const list = notices.filter((n) => (cat === "All" || n.category === cat) && (!unread || !n.readBy.includes(session.role)));
  return (
    <Page title="Notices" subtitle={`${notices.filter((n) => !n.readBy.includes(session.role)).length} unread`}><div className="pt-1"><Chips value={cat} onChange={setCat} options={["All", "Academic", "Holiday", "Exam", "Fee", "General"]} /><div className="mt-1"><Switch checked={unread} onChange={setUnread} label="Unread only" /></div></div>
      {list.length ? <div className="mt-1 space-y-2.5">{list.map((n) => <NoticeCard key={n.id} n={n} read={n.readBy.includes(session.role)} onClick={() => open(n)} />)}</div> : <Empty icon={Megaphone} title="No notices" body="Announcements from the institute will appear here." />}
      <Sheet open={!!view} onClose={() => setView(null)} title={view?.title}>{view ? <div className="space-y-3"><div className="flex items-center gap-2"><Badge tone="brand">{view.category}</Badge><span className="text-[12px] text-mute">{dmy(view.publishAt.slice(0, 10))} · {view.by}</span></div><p className="text-[14px] leading-relaxed">{view.body}</p>{view.attachment ? <FileItem file={view.attachment} /> : null}</div> : null}</Sheet>
    </Page>
  );
}

/* S80 */
function ParentLeave(_: P) {
  const { sc, child, children } = usePar();
  const { toast } = useApp();
  const [kid, setKid] = useState<string>(child?.id ?? "");
  const f = useForm({ from: "", to: "", reason: "" }, (v) => ({ from: v.from ? (v.from < today() ? "Start date can't be in the past" : undefined) : "Pick start date", to: !v.to ? "Pick end date" : v.to < v.from ? "End date must be on or after start" : undefined, reason: v.reason.trim().length < 5 ? "Please add a short reason" : undefined }));
  if (!child) return <NoChild />;
  const mine = sc.leaves.filter((l) => l.kind === "student" && children.some((c) => c.id === l.personId)).sort((a, b) => (a.at < b.at ? 1 : -1));
  return (
    <Page title="Apply for leave"><div className="space-y-4 pt-2"><Select label="Child" required options={children.map((c) => ({ value: c.id, label: c.name, sub: c.sid }))} value={kid} onChange={setKid} />
      <div className="grid grid-cols-2 gap-3"><DatePicker label="From" required min={today()} value={f.v.from} onChange={(v) => f.set("from", v)} error={f.v.from ? f.errors.from : undefined} /><DatePicker label="To" required min={f.v.from || today()} value={f.v.to} onChange={(v) => f.set("to", v)} error={f.v.to ? f.errors.to : undefined} /></div>
      <TextInput label="Reason" required multiline rows={3} placeholder="e.g. Fever, family function" {...f.bind("reason")} />
      <Btn disabled={!f.valid || !kid} onClick={async () => { await uc.requestLeave({ inst: sc.instId, kind: "student", personId: kid, from: f.v.from, to: f.v.to, reason: f.v.reason.trim(), by: sc.guardians.find((g) => g.studentId === kid)?.name ?? "Parent" }); f.setV({ from: "", to: "", reason: "" }); toast("Leave request sent to the institute"); }}>Submit request</Btn>
      <Section title="Request history">{mine.length ? <List>{mine.map((l) => <Row key={l.id} lead={<Avatar name={sc.students.find((s) => s.id === l.personId)?.name ?? "?"} size={36} />} title={`${sc.students.find((s) => s.id === l.personId)?.name.split(" ")[0]} · ${dmy(l.from)}${l.to !== l.from ? ` – ${dmy(l.to)}` : ""}`} sub={l.reason} right={<StatusBadge status={l.status} />} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No leave requests yet.</p></Card>}</Section></div></Page>
  );
}

/* S81 */
function TeacherContact(_: P) {
  const { sc, child, batch } = usePar();
  const { toast } = useApp();
  const [add, setAdd] = useState<string | null>(null);
  const f = useForm({ teacher: "", date: "", time: "", reason: "" }, (v) => ({ teacher: v.teacher ? undefined : "Choose a teacher", date: v.date ? (v.date <= today() ? "Choose a future date" : undefined) : "Pick a date", time: v.time ? undefined : "Choose a time", reason: v.reason.trim().length < 5 ? "Add a short reason" : undefined }));
  if (!child || !batch) return <NoChild />;
  const teachers = Array.from(new Set(Object.values(batch.subjectTeachers))).map((id) => ({ t: sc.staff.find((s) => s.id === id)!, subs: Object.entries(batch.subjectTeachers).filter(([, x]) => x === id).map(([s]) => s) })).filter((x) => x.t);
  const reqs = sc.meetings.filter((m) => m.studentId === child.id).sort((a, b) => (a.at < b.at ? 1 : -1));
  return (
    <Page title="Teachers & meetings"><div className="space-y-3 pt-1"><ChildPicker />
      <Banner icon={Lock}>For safety, teachers' personal phone numbers are private. Send a meeting request and the teacher will respond.</Banner>
      <List>{teachers.map(({ t, subs }) => <Row key={t.id} lead={<Avatar name={t.name} tone="violet" />} title={t.name} sub={subs.join(", ")} right={<Btn size="sm" variant="soft" full={false} onClick={() => { f.setV({ teacher: t.id, date: "", time: "", reason: "" }); setAdd(t.id); }}>Request</Btn>} noChevron />)}</List>
      <Section title="Your requests">{reqs.length ? <List>{reqs.map((m) => <Row key={m.id} icon={Handshake} tone="sky" title={`${sc.staff.find((t) => t.id === m.teacherId)?.name} · ${dmy(m.date)} ${time12(m.time)}`} sub={m.reason} right={<StatusBadge status={m.status} />} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No meeting requests yet. Replies from teachers appear here as status updates.</p></Card>}</Section></div>
      <Sheet open={!!add} onClose={() => setAdd(null)} title="Request a meeting"><div className="space-y-4"><Select label="Teacher" required options={teachers.map((x) => ({ value: x.t.id, label: x.t.name, sub: x.subs.join(", ") }))} value={f.v.teacher} onChange={(v) => f.set("teacher", v)} /><DatePicker label="Preferred date" required min={addDays(1)} value={f.v.date} onChange={(v) => f.set("date", v)} error={f.v.date ? f.errors.date : undefined} /><Select label="Preferred time" required options={["10:00", "11:00", "12:00", "16:00", "17:00", "18:00"].map((x) => ({ value: x, label: time12(x) }))} value={f.v.time} onChange={(v) => f.set("time", v)} /><TextInput label="Reason" required multiline rows={3} {...f.bind("reason")} />
        <Btn disabled={!f.valid} onClick={async () => { await uc.requestMeeting({ inst: sc.instId, studentId: child.id, teacherId: f.v.teacher, date: f.v.date, time: f.v.time, reason: f.v.reason.trim() }); setAdd(null); toast("Meeting request sent"); }}>Send request</Btn></div></Sheet>
    </Page>
  );
}

/* S82 */
function ParentProfile(_: P) {
  const { sc, me, children } = usePar();
  const { session, push, signOut, confirm, toast } = useApp();
  const { list } = useNotifs();
  const [tab, setTab] = useState("notifs");
  const [p, setP] = useState({ att: true, hw: true, exam: true, fee: true, notice: true });
  return (
    <Page title="Notifications & profile"><div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "notifs", label: "Notifications" }, { value: "prefs", label: "Preferences" }, { value: "profile", label: "Profile" }]} /></div>
      <div className="mt-3">
        {tab === "notifs" && (list.length ? <><List>{list.slice(0, 10).map((n) => <NotificationItem key={n.id} n={n} read={n.readRoles.includes(session.role)} onClick={async () => { await uc.markRead(n.id, session.role); const d = resolveDest(session.role, n.dest); push(d.name, d.params as Record<string, any>); }} />)}</List><div className="mt-3"><Btn variant="secondary" onClick={() => push("S11")}>Open all notifications</Btn></div></> : <Empty icon={Bell} title="No notifications" />)}
        {tab === "prefs" && <List><Switch checked={p.att} onChange={(v) => setP({ ...p, att: v })} label="Attendance alerts" sub="When your child is marked absent" /><Switch checked={p.hw} onChange={(v) => setP({ ...p, hw: v })} label="Homework notifications" /><Switch checked={p.exam} onChange={(v) => setP({ ...p, exam: v })} label="Exam & result alerts" /><Switch checked={p.fee} onChange={(v) => setP({ ...p, fee: v })} label="Fee reminders" /><Switch checked={p.notice} onChange={(v) => { setP({ ...p, notice: v }); toast(v ? "Notice alerts on" : "Notice alerts off", "info"); }} label="Institute notices" /></List>}
        {tab === "profile" && <div className="space-y-3"><Card><div className="flex items-center gap-3"><Avatar name={me.name} size={54} /><div><div className="text-[17px] font-bold">{me.name}</div><div className="text-[12.5px] text-mute">Parent / Guardian · {sc.inst.name}</div></div></div></Card>
          <Section title="Verified children"><List>{children.map((c) => <Row key={c.id} lead={<Avatar name={c.name} />} title={c.name} sub={`${c.sid} · ${sc.batches.find((b) => b.id === c.batchId)?.name}`} right={<Badge tone="ok" icon={ShieldCheck}>Verified</Badge>} noChevron />)}</List></Section>
          <List><Row icon={Users} title="Account profile" onClick={() => push("S13")} /><Row icon={HelpCircle} title="Help & privacy" onClick={() => push("S14", { tab: "help" })} /><Row icon={LogOut} tone="bad" title="Sign out" noChevron onClick={() => confirm({ title: "Sign out?", confirmLabel: "Sign out", danger: true, onConfirm: signOut })} /></List></div>}
      </div>
    </Page>
  );
}

export const parentScreens: ScreenMap = {
  S72: def("Parent Home / Child Overview", "parent", ParentHome), S73: def("Child Attendance", "parent", ChildAttendance), S74: def("Child Results / Progress", "parent", ChildResults), S75: def("Child Homework", "parent", ChildHomework),
  S76: def("Weekly Progress Digest", "parent", WeeklyDigest), S77: def("Fees / Dues / Instalments", "parent", ParentFees), S78: def("Payment History / Receipt", "parent", PaymentHistory), S79: def("Institute Notices", "parent", Notices),
  S80: def("Leave Request", "parent", ParentLeave), S81: def("Teacher Contact / Meeting Request", "parent", TeacherContact), S82: def("Parent Notifications / Preferences / Profile", "parent", ParentProfile),
};
export { Bars, Plus, Stat, Segmented, longDate };
