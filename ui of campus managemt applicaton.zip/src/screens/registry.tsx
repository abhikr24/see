"use client";
import React, { useState } from "react";
import { Layers } from "lucide-react";
import type { Role } from "@/domain/types";
import { useApp } from "@/state/app";
import { Badge, Banner, Chips, List, Page, Row } from "@/ui/kit";
import { ROLE_LABEL } from "@/features/selectors";
import { authScreens } from "./shared-auth";
import { coreScreens, hubScreens } from "./shared-core";
import { ownerA } from "./owner-a";
import { ownerB } from "./owner-b";
import { teacherScreens } from "./teacher";
import { studentScreens } from "./student";
import { parentScreens } from "./parent";
import { def, P, ScreenMap } from "./types";

/** Demo directory: documented route to every one of the 82 screens (S01–S82). */
function Directory(_: P) {
  const { jump, push, session } = useApp();
  const [f, setF] = useState("all");
  const ids = Array.from({ length: 82 }, (_, i) => `S${String(i + 1).padStart(2, "0")}`);
  const groups: { key: string; label: string; ids: string[] }[] = [
    { key: "shared", label: "Shared / Account · S01–S15", ids: ids.slice(0, 15) },
    { key: "owner", label: "Owner / Admin · S16–S41", ids: ids.slice(15, 41) },
    { key: "teacher", label: "Teacher · S42–S55", ids: ids.slice(41, 55) },
    { key: "student", label: "Student · S56–S71", ids: ids.slice(55, 71) },
    { key: "parent", label: "Parent · S72–S82", ids: ids.slice(71) },
  ];
  const shown = groups.filter((g) => f === "all" || g.key === f);
  return (
    <Page title="All screens" subtitle="Demo directory · 82 screens">
      <div className="space-y-2 pt-1"><Banner>Tap any screen to open it. Role-specific screens switch to that role first (demo only).</Banner>
        <Chips value={f} onChange={setF} options={[{ value: "all", label: "All" }, { value: "shared", label: "Shared" }, { value: "owner", label: "Owner" }, { value: "teacher", label: "Teacher" }, { value: "student", label: "Student" }, { value: "parent", label: "Parent" }]} /></div>
      {shown.map((g) => (
        <div key={g.key} className="mt-3"><div className="mb-1.5 px-0.5 text-[13px] font-semibold">{g.label}</div>
          <List>{g.ids.map((id) => { const s = SCREENS[id]; return <Row key={id} lead={<span className="grid h-10 w-12 shrink-0 place-items-center rounded-xl bg-brand-soft text-[12px] font-bold text-brand">{id}</span>} title={s?.title ?? "Missing"} sub={s && s.role !== "shared" ? ROLE_LABEL[s.role as Role] : "Any role"} right={s ? undefined : <Badge tone="bad">Missing</Badge>} onClick={() => { if (!s) return; if (s.role === "shared") push(id); else jump(id, s.role as Role); }} />; })}</List></div>
      ))}
      <p className="mt-4 text-center text-[11.5px] text-mute">Current role: {ROLE_LABEL[session.role]}</p>
    </Page>
  );
}

export const SCREENS: ScreenMap = {
  ...authScreens, ...coreScreens, ...hubScreens, ...ownerA, ...ownerB, ...teacherScreens, ...studentScreens, ...parentScreens,
  DIR: def("Screen directory", "shared", Directory),
};
export const SCREEN_IDS = Array.from({ length: 82 }, (_, i) => `S${String(i + 1).padStart(2, "0")}`);
export { Layers };
