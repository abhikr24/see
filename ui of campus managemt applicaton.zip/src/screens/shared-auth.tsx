"use client";
import React, { useEffect, useRef, useState } from "react";
import { ArrowRight, Building2, Camera, CheckCircle2, ClipboardCheck, GraduationCap, KeyRound, MailCheck, ShieldCheck, Users, Wallet, BookOpenCheck, Hourglass, SearchX } from "lucide-react";
import { useApp, useDB, useUnsaved } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Page } from "@/ui/kit";
import { Checkbox, DatePicker, FilePicker, OtpInput, PasswordInput, Select, TextInput, useForm } from "@/ui/forms";
import { def, P, ScreenMap } from "./types";
import { STATES } from "./common";
import { academicYear, uid, validEmail, validPhone } from "@/lib/fmt";
import { uc } from "@/features/usecases";
import { ROLE_LABEL } from "@/features/selectors";
import { Sheet } from "@/ui/kit";
import type { FileMeta, Role } from "@/domain/types";

export const DEMO_OTP = "123456";

/* S01 */
function Splash(_: P) {
  const { reset } = useApp();
  useEffect(() => { const t = setTimeout(() => reset("S02"), 2000); return () => clearTimeout(t); }, [reset]);
  return (
    <div className="relative flex h-full flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-brand-dark via-[#252a7a] to-brand text-white">
      <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-violet/25 blur-3xl" />
      <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-sky/20 blur-3xl" />
      <div className="anim-logo grid h-24 w-24 place-items-center rounded-[28px] bg-white text-brand shadow-2xl"><GraduationCap size={52} strokeWidth={2.2} /></div>
      <h1 className="anim-fade mt-6 text-[36px] font-bold tracking-tight" style={{ animationDelay: "0.4s" }}>GuruFlow</h1>
      <p className="anim-fade mt-1.5 text-[14px] text-white/75" style={{ animationDelay: "0.7s" }}>Every classroom, beautifully connected.</p>
      <p className="absolute bottom-8 text-[11.5px] text-white/50">Made for institutes across India</p>
    </div>
  );
}

/* S02 */
function Welcome(_: P) {
  const { push } = useApp();
  const [i, setI] = useState(0);
  const slides = [
    { icon: Building2, title: "Run your whole institute from one app", body: "Admissions, attendance, exams, fees and notices — organised, searchable and always up to date.", tone: "from-brand to-violet" },
    { icon: ClipboardCheck, title: "Teachers finish classroom work in minutes", body: "Mark attendance in a few taps, review homework and enter marks without paper registers.", tone: "from-sky to-brand" },
    { icon: Users, title: "Students stay on track, parents stay informed", body: "Clear timetables, progress and fee reminders — without endless WhatsApp groups.", tone: "from-violet to-brand-dark" },
  ];
  const s = slides[i];
  return (
    <div className="flex h-full flex-col bg-bg">
      <div className="flex justify-end px-4 pt-3"><Btn variant="ghost" size="sm" full={false} onClick={() => setI(2)}>Skip</Btn></div>
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center px-7 text-center">
        <div key={i} className={`anim-pop grid h-44 w-44 place-items-center rounded-[44px] bg-gradient-to-br ${s.tone} text-white shadow-xl`}><s.icon size={74} strokeWidth={1.6} /></div>
        <h1 key={`t${i}`} className="anim-fade mt-9 text-[25px] font-bold leading-tight tracking-tight text-ink">{s.title}</h1>
        <p className="mt-3 max-w-[300px] text-[14.5px] leading-relaxed text-mute">{s.body}</p>
        <div className="mt-6 flex gap-2" role="tablist" aria-label="Onboarding pages">
          {slides.map((_, k) => <button key={k} aria-label={`Page ${k + 1}`} onClick={() => setI(k)} className={`h-2 rounded-full transition-all ${k === i ? "w-6 bg-brand" : "w-2 bg-slate-300"}`} />)}
        </div>
      </div>
      <div className="space-y-2.5 px-5 pb-6">
        {i < 2 ? <Btn icon={ArrowRight} onClick={() => setI(i + 1)}>Next</Btn> : <Btn onClick={() => push("S03")}>Sign in</Btn>}
        <Btn variant="secondary" onClick={() => push("S04")}>Create account</Btn>
        <p className="text-center text-[11.5px] text-mute">Prototype in demo mode — no real accounts or messages.</p>
      </div>
    </div>
  );
}

/* S03 */
function SignIn(_: P) {
  const { push, signIn, reset, toast } = useApp();
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const f = useForm({ id: "", pw: "" }, (v) => ({
    id: !v.id.trim() ? "Enter your mobile number or email" : /^[\d\s+]+$/.test(v.id) ? (validPhone(v.id) ? undefined : "Enter a valid 10-digit Indian mobile number") : validEmail(v.id) ? undefined : "Enter a valid email address",
    pw: v.pw.length < 6 ? "Password must be at least 6 characters" : undefined,
  }));
  const submit = () => {
    f.touchAll(); if (!f.valid) return;
    setLoading(true); setErr("");
    setTimeout(() => { setLoading(false); if (f.v.pw.toLowerCase() === "wrong123") { setErr("Incorrect password. Please try again or reset it."); return; } signIn(); toast("Signed in (demo account)"); reset("S08"); }, 900);
  };
  return (
    <Page title="Sign in" subtitle="Welcome back to GuruFlow">
      <div className="space-y-4 pt-2">
        <Banner>Demo mode: any valid mobile/email with a 6+ character password signs in. Try <b>9876543210</b> / <b>guruflow</b>.</Banner>
        <TextInput label="Mobile number or email" required inputMode="text" placeholder="98765 43210 or you@example.com" autoComplete="username" {...f.bind("id")} />
        <PasswordInput required {...f.bind("pw")} />
        {err ? <p role="alert" className="rounded-lg bg-bad-soft px-3 py-2 text-[13px] font-medium text-bad">{err}</p> : null}
        <div className="flex justify-end"><Btn variant="ghost" size="sm" full={false} onClick={() => push("S06")}>Forgot password?</Btn></div>
        <Btn loading={loading} disabled={!f.valid} onClick={submit}>Sign in</Btn>
        <Btn variant="soft" onClick={() => { f.setV({ id: "9876543210", pw: "guruflow" }); }}>Fill demo credentials</Btn>
        <p className="text-center text-[14px] text-mute">New to GuruFlow? <button onClick={() => push("S04")} className="min-h-10 font-semibold text-brand">Create account</button></p>
      </div>
    </Page>
  );
}

/* S04 */
function CreateAccount(_: P) {
  const { push } = useApp();
  const [terms, setTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const f = useForm({ name: "", phone: "", email: "", pw: "", pw2: "" }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter your full name" : undefined,
    phone: validPhone(v.phone) ? undefined : "Enter a valid 10-digit mobile number",
    email: v.email && !validEmail(v.email) ? "Enter a valid email address" : undefined,
    pw: v.pw.length < 8 ? "Use at least 8 characters" : !/\d/.test(v.pw) ? "Include at least one number" : undefined,
    pw2: v.pw2 !== v.pw ? "Passwords do not match" : undefined,
  }));
  useUnsaved(f.dirty && !loading);
  const submit = () => { f.touchAll(); if (!f.valid || !terms) return; setLoading(true); setTimeout(() => { setLoading(false); push("S05", { dest: `+91 ${f.v.phone.replace(/\D/g, "").slice(-10)}`, flow: "signup", name: f.v.name, phone: f.v.phone, email: f.v.email }); }, 800); };
  return (
    <Page title="Create account" subtitle="It takes less than a minute">
      <div className="space-y-4 pt-2">
        <TextInput label="Full name" required placeholder="e.g. Rajesh Sharma" autoComplete="name" {...f.bind("name")} />
        <TextInput label="Mobile number" required inputMode="tel" prefix="+91" maxLength={10} placeholder="98765 43210" {...f.bind("phone")} />
        <TextInput label="Email" inputMode="email" placeholder="you@example.com" {...f.bind("email")} />
        <PasswordInput label="Password" required hint="At least 8 characters with a number" {...f.bind("pw")} />
        <PasswordInput label="Confirm password" required placeholder="Re-enter password" {...f.bind("pw2")} />
        <Checkbox checked={terms} onChange={setTerms}>I agree to the <b className="text-brand">Terms of Use</b> and <b className="text-brand">Privacy Policy</b>. Student data is never used for advertising.</Checkbox>
        <Btn loading={loading} disabled={!f.valid || !terms} onClick={submit}>Create account</Btn>
      </div>
    </Page>
  );
}

/* S05 */
function Otp({ params }: P) {
  const { push, reset, toast } = useApp();
  const dest = params.dest ?? "+91 98765 43210";
  const [code, setCode] = useState("");
  const [bad, setBad] = useState(false);
  const [left, setLeft] = useState(30);
  const [ok, setOk] = useState(false);
  const [loading, setLoading] = useState(false);
  useEffect(() => { if (left <= 0) return; const t = setTimeout(() => setLeft(left - 1), 1000); return () => clearTimeout(t); }, [left]);
  const verify = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); if (code === DEMO_OTP) { setBad(false); setOk(true); setTimeout(() => reset("S07", { name: params.name, phone: params.phone, email: params.email }), 1100); } else setBad(true); }, 700);
  };
  if (ok) return (
    <Page title="Verified">
      <div className="anim-pop flex flex-col items-center py-16 text-center"><span className="grid h-20 w-20 place-items-center rounded-full bg-ok-soft text-ok"><CheckCircle2 size={44} /></span><h2 className="mt-5 text-[21px] font-bold">Number verified</h2><p className="mt-1 text-[14px] text-mute">Setting up your profile…</p></div>
    </Page>
  );
  return (
    <Page title="Verify your number">
      <div className="space-y-5 pt-2">
        <div className="flex items-center gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-soft text-brand"><MailCheck size={24} /></span><p className="text-[14px] text-mute">Enter the 6-digit code for <b className="text-ink">{dest}</b></p></div>
        <Banner tone="warn" icon={ShieldCheck}><b>Demo mode:</b> no SMS or email is sent. Use the code <b>{DEMO_OTP}</b>.</Banner>
        <OtpInput value={code} onChange={(v) => { setCode(v); setBad(false); }} error={bad} />
        {bad ? <p role="alert" className="text-[13px] font-medium text-bad">That code isn't correct. Please check and try again.</p> : null}
        <Btn disabled={code.length !== 6} loading={loading} onClick={verify}>Verify</Btn>
        <div className="text-center text-[13.5px] text-mute">{left > 0 ? <>Resend code in <b className="text-ink">0:{String(left).padStart(2, "0")}</b></> : <Btn variant="ghost" size="sm" full={false} onClick={() => { setLeft(30); setCode(""); toast("Demo code re-issued: 123456", "info"); }}>Resend code</Btn>}</div>
        <Btn variant="ghost" size="sm" onClick={() => push("S03")}>Use a different number</Btn>
      </div>
    </Page>
  );
}

/* S06 */
function Forgot(_: P) {
  const { reset, toast } = useApp();
  const [step, setStep] = useState(1);
  const [id, setId] = useState("");
  const [code, setCode] = useState("");
  const [badCode, setBadCode] = useState(false);
  const f = useForm({ pw: "", pw2: "" }, (v) => ({ pw: v.pw.length < 8 || !/\d/.test(v.pw) ? "Use 8+ characters including a number" : undefined, pw2: v.pw !== v.pw2 ? "Passwords do not match" : undefined }));
  const idErr = id && !(validPhone(id) || validEmail(id)) ? "Enter a valid mobile number or email" : undefined;
  return (
    <Page title="Reset password" subtitle={`Step ${Math.min(step, 3)} of 3`}>
      <div className="space-y-4 pt-2">
        {step === 1 && (<>
          <TextInput label="Mobile number or email" required value={id} onChange={setId} error={idErr} placeholder="98765 43210 or you@example.com" />
          <Banner>We'll send a recovery code. In demo mode no message is sent — the code is <b>{DEMO_OTP}</b>.</Banner>
          <Btn disabled={!id || !!idErr} onClick={() => setStep(2)}>Send recovery code</Btn></>)}
        {step === 2 && (<>
          <p className="text-[14px] text-mute">Enter the recovery code for <b className="text-ink">{id}</b></p>
          <OtpInput value={code} onChange={(v) => { setCode(v); setBadCode(false); }} error={badCode} />
          {badCode ? <p role="alert" className="text-[13px] font-medium text-bad">Invalid recovery code.</p> : null}
          <Btn disabled={code.length !== 6} onClick={() => (code === DEMO_OTP ? setStep(3) : setBadCode(true))}>Continue</Btn></>)}
        {step === 3 && (<>
          <PasswordInput label="New password" required {...f.bind("pw")} />
          <PasswordInput label="Confirm new password" required {...f.bind("pw2")} />
          <Btn disabled={!f.valid} onClick={() => { f.touchAll(); setStep(4); }}>Update password</Btn></>)}
        {step === 4 && (
          <div className="anim-pop flex flex-col items-center py-10 text-center"><span className="grid h-20 w-20 place-items-center rounded-full bg-ok-soft text-ok"><KeyRound size={38} /></span><h2 className="mt-5 text-[21px] font-bold">Password updated</h2><p className="mt-1 text-[14px] text-mute">You can now sign in with your new password. (Demo — nothing was stored.)</p><div className="mt-6 w-full"><Btn onClick={() => { toast("Back to sign in"); reset("S03"); }}>Back to sign in</Btn></div></div>)}
      </div>
    </Page>
  );
}

/* S07 */
function ProfileSetup({ params }: P) {
  const { reset, toast } = useApp();
  const [img, setImg] = useState<string | null>(null);
  const ref = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const f = useForm({ name: params.name ?? "", phone: params.phone ?? "", email: params.email ?? "", dob: "", city: "", lang: "English" }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter your full name" : undefined, phone: validPhone(v.phone) ? undefined : "Enter a valid mobile number", email: v.email && !validEmail(v.email) ? "Invalid email" : undefined,
  }));
  useUnsaved(f.dirty && !loading);
  return (
    <Page title="Set up your profile" subtitle="Help your institute recognise you" footer={<Btn loading={loading} disabled={!f.valid} onClick={() => { setLoading(true); setTimeout(() => { toast("Profile saved"); reset("S08"); }, 700); }}>Save & continue</Btn>}>
      <div className="space-y-4 pt-2">
        <div className="flex justify-center">
          <button onClick={() => ref.current?.click()} aria-label="Choose profile photo" className="relative">
            {img ? <img src={img} alt="Profile preview" className="h-24 w-24 rounded-full object-cover" /> : <Avatar name={f.v.name || "G F"} size={96} />}
            <span className="absolute bottom-0 right-0 grid h-9 w-9 place-items-center rounded-full border-2 border-white bg-brand text-white"><Camera size={16} /></span>
          </button>
          <input ref={ref} type="file" accept="image/*" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (file) setImg(URL.createObjectURL(file)); }} />
        </div>
        <TextInput label="Full name" required {...f.bind("name")} />
        <TextInput label="Mobile number" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("phone")} />
        <TextInput label="Email" inputMode="email" {...f.bind("email")} />
        <DatePicker label="Date of birth" value={f.v.dob} onChange={(v) => f.set("dob", v)} max={new Date().toISOString().slice(0, 10)} />
        <TextInput label="City" placeholder="e.g. Pune" {...f.bind("city")} />
        <Select label="Preferred language" value={f.v.lang} onChange={(v) => f.set("lang", v)} options={["English", "हिन्दी (Hindi)", "मराठी (Marathi)", "ગુજરાતી (Gujarati)", "தமிழ் (Tamil)"]} />
      </div>
    </Page>
  );
}

/* S08 */
function InstituteSelect(_: P) {
  const db = useDB();
  const { push, switchContext, toast } = useApp();
  const [pick, setPick] = useState<string | null>(null);
  const inst = db.institutes.find((i) => i.id === pick);
  const mem = db.memberships.find((m) => m.instId === pick);
  const roles = mem?.roles ?? [];
  const roleHint: Record<Role, string> = { owner: "Manage the institute", teacher: "Classes, attendance & marks", student: "Timetable, homework & practice", parent: "Child's progress & fees" };
  return (
    <Page title="Choose institute" subtitle="You can belong to more than one">
      <div className="space-y-3 pt-2">
        {db.memberships.map((m) => {
          const i = db.institutes.find((x) => x.id === m.instId);
          if (!i) return null;
          const pending = m.status === "pending";
          return (
            <Card key={m.id} onClick={() => (pending ? push("S10", { pending: i.id }) : m.roles.length === 1 ? (switchContext(i.id, m.roles[0]), toast(`Opened ${i.name}`, "info")) : setPick(i.id))}>
              <div className="flex items-center gap-3">
                <Avatar name={i.name} size={48} tone={pending ? "mute" : "violet"} />
                <div className="min-w-0 flex-1"><div className="text-[15px] font-semibold leading-snug text-ink">{i.name}</div><div className="text-[12.5px] text-mute">{i.city}, {i.state}</div>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">{pending ? <Badge tone="warn" icon={Hourglass}>Pending approval</Badge> : m.roles.map((r) => <Badge key={r} tone="brand">{ROLE_LABEL[r].split(" /")[0]}</Badge>)}</div></div>
              </div>
            </Card>
          );
        })}
        <Btn variant="secondary" onClick={() => push("S10")}>Join an institute</Btn>
        <Btn variant="soft" onClick={() => push("S09")}>Create a new institute</Btn>
      </div>
      <Sheet open={!!pick} onClose={() => setPick(null)} title={inst?.name}>
        <p className="mb-3 text-[13.5px] text-mute">You have {roles.length} roles here. Continue as:</p>
        <div className="space-y-2">{roles.map((r) => (
          <button key={r} onClick={() => { switchContext(pick!, r); toast(`Continuing as ${ROLE_LABEL[r]}`, "info"); }} className="flex min-h-14 w-full items-center justify-between rounded-xl border border-line px-4 text-left active:bg-brand-soft">
            <span><span className="block text-[15px] font-semibold">{ROLE_LABEL[r]}</span><span className="text-[12.5px] text-mute">{roleHint[r]}</span></span><ArrowRight size={18} className="text-brand" />
          </button>))}</div>
      </Sheet>
    </Page>
  );
}

/* S09 */
function CreateInstitute(_: P) {
  const { reset, push, switchContext, toast } = useApp();
  const [logo, setLogo] = useState<FileMeta | null>(null);
  const [loading, setLoading] = useState(false);
  const ay = academicYear();
  const f = useForm({ name: "", type: "", address: "", city: "", state: "", pin: "", phone: "", year: ay.label }, (v) => ({
    name: v.name.trim().length < 3 ? "Enter the institute name" : undefined, type: v.type ? undefined : "Choose a type", address: v.address.trim().length < 5 ? "Enter the address" : undefined,
    city: v.city.trim() ? undefined : "Enter the city", state: v.state ? undefined : "Choose a state", pin: /^[1-9]\d{5}$/.test(v.pin) ? undefined : "Enter a 6-digit PIN code",
    phone: validPhone(v.phone) ? undefined : "Enter a valid contact number",
  }));
  useUnsaved(f.dirty && !loading);
  const create = async () => {
    f.touchAll(); if (!f.valid) return;
    setLoading(true);
    const id = uid("i");
    await uc.save("institutes", { id, name: f.v.name, city: f.v.city, state: f.v.state, type: f.v.type, code: `${f.v.name.replace(/[^A-Za-z]/g, "").slice(0, 4).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`, invite: "JOIN-" + id.slice(-4).toUpperCase() });
    await uc.save("memberships", { id, instId: id, roles: ["owner"], status: "active" });
    await uc.save("sessions", { id: uid("ss"), inst: id, label: f.v.year, start: ay.start, end: ay.end, active: true });
    setLoading(false); toast("Institute created. It starts empty — add batches and students."); switchContext(id, "owner");
  };
  return (
    <Page title="Create institute" subtitle="Set up your institute profile" footer={<Btn loading={loading} disabled={!f.valid} onClick={create}>Create institute</Btn>}>
      <div className="space-y-4 pt-2">
        <TextInput label="Institute name" required placeholder="e.g. Vidya Mandir Classes" {...f.bind("name")} />
        <Select label="Institute type" required options={["Coaching Centre", "School", "Tuition Organisation", "Skill Institute"]} {...f.bind("type")} />
        <TextInput label="Address" required multiline rows={2} placeholder="Building, street, area" {...f.bind("address")} />
        <div className="grid grid-cols-2 gap-3"><TextInput label="City" required {...f.bind("city")} /><TextInput label="PIN code" required inputMode="numeric" maxLength={6} {...f.bind("pin")} /></div>
        <Select label="State" required options={STATES} {...f.bind("state")} />
        <TextInput label="Contact number" required inputMode="tel" prefix="+91" maxLength={10} {...f.bind("phone")} />
        <Select label="Academic year" required options={[ay.label, ay.prev]} value={f.v.year} onChange={(v) => f.set("year", v)} />
        <FilePicker label="Institute logo" accept="image/*" value={logo} onChange={setLogo} />
        <Btn variant="ghost" size="sm" onClick={() => push("S10")}>I'd rather join an existing institute</Btn>
      </div>
    </Page>
  );
}

/* S10 */
function JoinInstitute({ params }: P) {
  const db = useDB();
  const { toast, reset, push } = useApp();
  const [code, setCode] = useState("");
  const [state, setState] = useState<"idle" | "notfound" | "found">("idle");
  const [loading, setLoading] = useState(false);
  const found = db.institutes.find((i) => [i.code, i.invite].includes(code.trim().toUpperCase()));
  const pendingId = params.pending as string | undefined;
  const pending = db.institutes.find((i) => i.id === pendingId);
  const lookup = () => { setLoading(true); setTimeout(() => { setLoading(false); setState(found ? "found" : "notfound"); }, 600); };
  if (pending) return (
    <Page title="Request status">
      <div className="flex flex-col items-center px-2 py-10 text-center">
        <span className="grid h-20 w-20 place-items-center rounded-full bg-warn-soft text-warn"><Hourglass size={38} /></span>
        <h2 className="mt-5 text-[20px] font-bold">Waiting for approval</h2>
        <p className="mt-2 text-[14px] leading-relaxed text-mute">Your request to join <b className="text-ink">{pending.name}</b> has been sent to the institute admin. You'll be notified once it's approved.</p>
        <div className="mt-6 w-full space-y-2.5">
          <Btn variant="soft" onClick={async () => { const m = db.memberships.find((x) => x.instId === pending.id)!; await uc.save("memberships", { ...m, status: "active" }); toast("Demo: request approved"); reset("S08"); }}>Demo: simulate admin approval</Btn>
          <Btn variant="secondary" onClick={() => reset("S08")}>Back to institutes</Btn>
        </div>
      </div>
    </Page>
  );
  return (
    <Page title="Join an institute" subtitle="Use the code shared by your institute">
      <div className="space-y-4 pt-2">
        <TextInput label="Invite or institute code" required value={code} onChange={(v) => { setCode(v); setState("idle"); }} placeholder="e.g. SARA-5521" hint="Demo codes: GYAN-7710, SARA-JOIN" />
        <Btn loading={loading} disabled={code.trim().length < 4} onClick={lookup}>Find institute</Btn>
        {state === "notfound" ? <div role="alert" className="flex flex-col items-center rounded-2xl bg-bad-soft px-4 py-6 text-center text-bad"><SearchX size={28} /><b className="mt-2">No institute found</b><span className="mt-1 text-[13px]">Check the code with your institute and try again.</span></div> : null}
        {state === "found" && found ? (() => {
          const m = db.memberships.find((x) => x.instId === found.id);
          return (
            <Card><div className="flex items-center gap-3"><Avatar name={found.name} size={48} tone="violet" /><div><div className="font-semibold">{found.name}</div><div className="text-[12.5px] text-mute">{found.city}, {found.state} · {found.type}</div></div></div>
              <div className="mt-4">{m ? <Badge tone={m.status === "active" ? "ok" : "warn"}>{m.status === "active" ? "You're already a member" : "Request pending"}</Badge> : <Btn onClick={async () => { await uc.save("memberships", { id: found.id, instId: found.id, roles: ["student"], status: "pending" }); toast("Access requested"); push("S10", { pending: found.id }); }}>Request access</Btn>}</div></Card>);
        })() : null}
        <Banner icon={BookOpenCheck}>An institute admin must approve every request before you can see any records.</Banner>
      </div>
    </Page>
  );
}

export const authScreens: ScreenMap = {
  S01: def("Splash", "shared", Splash), S02: def("Welcome / Onboarding", "shared", Welcome), S03: def("Sign In", "shared", SignIn),
  S04: def("Create Account", "shared", CreateAccount), S05: def("OTP Verification", "shared", Otp), S06: def("Forgot / Reset Password", "shared", Forgot),
  S07: def("Profile Setup", "shared", ProfileSetup), S08: def("Institute Selection", "shared", InstituteSelect), S09: def("Create Institute", "shared", CreateInstitute),
  S10: def("Join Institute", "shared", JoinInstitute),
};
export { Wallet };
