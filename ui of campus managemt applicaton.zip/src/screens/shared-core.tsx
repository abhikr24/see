"use client";
import React, { useMemo, useState } from "react";
import { Bell, CheckCheck, Clock, Download, FileText, HelpCircle, Languages, LifeBuoy, Lock, LogOut, Mail, Phone, Pencil, RefreshCw, Repeat, Search, SearchX, Settings, ShieldCheck, Trash2, UserCircle, WifiOff, Wrench, Hourglass, Loader2, Inbox, Building2, Layers, Info } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { Role } from "@/domain/types";
import { useApp, useDB, useMe, useScope, useUnsaved } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Chips, Denied, Empty, ErrorState, IconBtn, IconTile, Kv, List, Page, Row, Section, Segmented, Sheet, SkeletonList, Tabs } from "@/ui/kit";
import { SearchInput, Switch, TextInput, useForm, Select } from "@/ui/forms";
import { NotificationItem } from "@/ui/cards";
import { def, P, ScreenMap } from "./types";
import { ContextSheet, useNotifs } from "./common";
import { uc } from "@/features/usecases";
import { ROLE_LABEL, can, noticeVisible, subFor } from "@/features/selectors";
import { phoneIN, validEmail, validPhone, dmy } from "@/lib/fmt";

/** Map a stored deep link to the correct screen for the *current* role. */
export function resolveDest(role: Role, d: { name: string; params?: Record<string, unknown> }) {
  const map: Partial<Record<Role, Record<string, string>>> = {
    parent: { S60: "S75", S61: "S75", S62: "S74", S63: "S74", S58: "S73", S59: "S75", S49: "S75", S53: "S75" },
    student: { S73: "S58", S74: "S63", S75: "S59", S77: "S56", S78: "S56" },
    teacher: { S39: "S54", S35: "S42", S26: "S55" },
    owner: { S54: "S26", S49: "S47", S46: "S32" },
  };
  return { name: map[role]?.[d.name] ?? d.name, params: d.params };
}

/* S11 */
function Notifications(_: P) {
  const { session, push, toast } = useApp();
  const { list, unread } = useNotifs();
  const [filter, setFilter] = useState("All");
  const cats = ["All", "Unread", "Attendance", "Homework", "Exam", "Fee", "Notice"];
  const shown = list.filter((n) => (filter === "All" ? true : filter === "Unread" ? !n.readRoles.includes(session.role) : n.cat === filter.toLowerCase()));
  return (
    <Page title="Notifications" subtitle={unread ? `${unread} unread` : "You're all caught up"} right={<IconBtn icon={CheckCheck} label="Mark all as read" onClick={async () => { await uc.markAllRead(list.map((n) => n.id), session.role); toast("All notifications marked as read"); }} />}>
      <Chips value={filter} onChange={setFilter} options={cats} />
      <div className="mt-2">
        {shown.length === 0 ? <Empty icon={Bell} title="Nothing here" body={filter === "Unread" ? "You have no unread notifications." : "Notifications for this category will appear here."} /> : (
          <List>{shown.map((n) => (
            <NotificationItem key={n.id} n={n} read={n.readRoles.includes(session.role)} onClick={async () => { await uc.markRead(n.id, session.role); const d = resolveDest(session.role, n.dest); push(d.name, d.params as Record<string, any>); }} />
          ))}</List>
        )}
      </div>
    </Page>
  );
}

/* S12 */
const RECENT: string[] = ["Aarav", "Fee", "Homework"];
function GlobalSearch(_: P) {
  const sc = useScope();
  const me = useMe();
  const { session, push } = useApp();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const [recent, setRecent] = useState(RECENT);
  type R = { cat: string; title: string; sub: string; name: string; params?: Record<string, any> };
  const index = useMemo<R[]>(() => {
    const r: R[] = [];
    const role = session.role;
    const bName = (id: string) => sc.batches.find((b) => b.id === id)?.name ?? "";
    if (role === "owner") {
      sc.students.forEach((s) => r.push({ cat: "Students", title: s.name, sub: `${s.sid} · ${bName(s.batchId)}`, name: "S23", params: { id: s.id } }));
      sc.staff.forEach((s) => r.push({ cat: "Staff", title: s.name, sub: s.subjects.join(", "), name: "S26", params: { id: s.id } }));
      sc.batches.forEach((b) => r.push({ cat: "Batches", title: b.name, sub: b.course, name: "S29", params: { id: b.id } }));
      sc.enquiries.forEach((e) => r.push({ cat: "Enquiries", title: e.student, sub: `${e.status} · ${e.course}`, name: "S20", params: { id: e.id } }));
    }
    if (role === "teacher") {
      const t = me.teacher;
      sc.students.filter((s) => t?.batchIds.includes(s.batchId)).forEach((s) => r.push({ cat: "Students", title: s.name, sub: `${s.sid} · ${bName(s.batchId)}`, name: "S51", params: { id: s.id } }));
      sc.batches.filter((b) => t?.batchIds.includes(b.id)).forEach((b) => r.push({ cat: "Batches", title: b.name, sub: b.course, name: "S45", params: { id: b.id } }));
      sc.homework.filter((h) => h.teacherId === t?.id).forEach((h) => r.push({ cat: "Homework", title: h.title, sub: h.subject, name: "S47" }));
    }
    if (role === "student") sc.homework.filter((h) => h.batchId === me.student.batchId && h.status === "published").forEach((h) => r.push({ cat: "Homework", title: h.title, sub: `${h.subject} · due ${dmy(h.due)}`, name: "S60", params: { id: h.id } }));
    if (role === "parent") sc.homework.filter((h) => me.batchIds.includes(h.batchId) && h.status === "published").forEach((h) => r.push({ cat: "Homework", title: h.title, sub: `${h.subject} · due ${dmy(h.due)}`, name: "S75" }));
    sc.resources.filter((x) => role === "owner" || x.batchIds.some((b) => me.batchIds.includes(b))).forEach((x) => r.push({ cat: "Resources", title: x.title, sub: `${x.subject} · ${x.type.toUpperCase()}`, name: role === "owner" ? "S38" : role === "teacher" ? "S52" : "S69", params: { id: x.id } }));
    sc.notices.filter((n) => noticeVisible(n, role, me.batchIds)).forEach((n) => r.push({ cat: "Notices", title: n.title, sub: n.category, name: role === "owner" ? "S39" : "S79", params: { id: n.id } }));
    return r;
  }, [sc, me, session.role]);
  const ql = q.trim().toLowerCase();
  const cats = ["All", ...Array.from(new Set(index.map((i) => i.cat)))];
  const res = ql ? index.filter((i) => (cat === "All" || i.cat === cat) && (i.title + " " + i.sub).toLowerCase().includes(ql)) : [];
  const go = (r: R) => { if (ql) setRecent([q.trim(), ...recent.filter((x) => x !== q.trim())].slice(0, 6)); RECENT.splice(0, RECENT.length, ...[q.trim(), ...RECENT.filter((x) => x !== q.trim())].slice(0, 6)); push(r.name, r.params); };
  return (
    <Page title="Search" subtitle={`Searching as ${ROLE_LABEL[session.role]}`}>
      <SearchInput autoFocus value={q} onChange={setQ} placeholder="Students, homework, notices…" />
      {!ql ? (
        <Section title="Recent searches">
          {recent.length ? <><div className="flex flex-wrap gap-2">{recent.map((r) => <button key={r} onClick={() => setQ(r)} className="flex min-h-10 items-center gap-1.5 rounded-full border border-line bg-white px-3.5 text-[13px] text-ink"><Clock size={13} className="text-mute" />{r}</button>)}</div><div className="mt-2"><Btn variant="ghost" size="sm" full={false} onClick={() => { setRecent([]); RECENT.length = 0; }}>Clear recent searches</Btn></div></> : <p className="text-[13px] text-mute">No recent searches yet.</p>}
        </Section>
      ) : (
        <>
          <Chips value={cat} onChange={setCat} options={cats} />
          {res.length === 0 ? <Empty icon={SearchX} title={`No results for “${q}”`} body="Try a different spelling or search in another category." action="Clear search" onAction={() => setQ("")} /> : (
            <div className="mt-2"><div className="mb-2 text-[12.5px] text-mute">{res.length} result{res.length > 1 ? "s" : ""}</div>
              <List>{res.slice(0, 40).map((r, i) => <Row key={i} title={r.title} sub={r.sub} onClick={() => go(r)} right={<Badge tone="brand">{r.cat}</Badge>} lead={<Avatar name={r.title} size={36} />} />)}</List></div>
          )}
        </>
      )}
    </Page>
  );
}

/* S13 */
const PROFILE = { phone: "9876543210", email: "demo@guruflow.app", name: "Demo Account", city: "Pune" };
function UserProfile(_: P) {
  const sc = useScope();
  const me = useMe();
  const { session, push, signOut, confirm } = useApp();
  const [p, setP] = useState(PROFILE);
  const [edit, setEdit] = useState(false);
  const [ctx, setCtx] = useState(false);
  const f = useForm({ name: p.name, phone: p.phone, email: p.email }, (v) => ({ name: v.name.trim().length < 3 ? "Enter your name" : undefined, phone: validPhone(v.phone) ? undefined : "Invalid mobile number", email: validEmail(v.email) ? undefined : "Invalid email" }));
  return (
    <Page title="Profile">
      <Card className="mt-2 text-center">
        <div className="flex justify-center"><Avatar name={p.name} size={76} /></div>
        <h2 className="mt-3 text-[19px] font-bold">{p.name}</h2>
        <p className="text-[13px] text-mute">Signed in as <b className="text-ink">{me.name}</b></p>
        <div className="mt-2 flex justify-center gap-2"><Badge tone="brand">{ROLE_LABEL[session.role]}</Badge></div>
        <div className="mt-4"><Btn variant="secondary" size="sm" full={false} icon={Pencil} onClick={() => { f.setV({ name: p.name, phone: p.phone, email: p.email }); setEdit(true); }}>Edit profile</Btn></div>
      </Card>
      <Section title="Contact"><List>
        <Row icon={Phone} title={phoneIN(p.phone)} sub="Mobile" tone="sky" /><Row icon={Mail} title={p.email} sub="Email" tone="sky" /><Row icon={Building2} title={sc.inst.name} sub={`${sc.inst.city}, ${sc.inst.state} · Active institute`} tone="violet" onClick={() => setCtx(true)} />
      </List></Section>
      <Section title="Account"><List>
        <Row icon={Repeat} title="Switch institute or role" onClick={() => setCtx(true)} />
        <Row icon={Bell} title="Notifications" onClick={() => push("S11")} /><Row icon={Settings} title="Preferences, help & privacy" onClick={() => push("S14")} />
        <Row icon={LogOut} title="Sign out" tone="bad" onClick={() => confirm({ title: "Sign out of GuruFlow?", body: "You'll return to the welcome screen. Demo data stays available.", confirmLabel: "Sign out", danger: true, onConfirm: signOut })} noChevron />
      </List></Section>
      <Sheet open={edit} onClose={() => setEdit(false)} title="Edit profile">
        <div className="space-y-4"><TextInput label="Full name" required {...f.bind("name")} /><TextInput label="Mobile number" required inputMode="tel" maxLength={10} {...f.bind("phone")} /><TextInput label="Email" required inputMode="email" {...f.bind("email")} />
          <Btn disabled={!f.valid} onClick={() => { Object.assign(PROFILE, { ...f.v }); setP({ ...PROFILE }); setEdit(false); }}>Save changes</Btn></div>
      </Sheet>
      <ContextSheet open={ctx} onClose={() => setCtx(false)} />
    </Page>
  );
}

/* S14 */
function Preferences({ params }: P) {
  const { toast, confirm, setOffline, offline, session, push } = useApp();
  const db = useDB();
  const [tab, setTab] = useState<"prefs" | "help" | "privacy">((params.tab as any) ?? "prefs");
  const [n, setN] = useState({ push: true, att: true, hw: true, exam: true, fee: true, quiet: false });
  const [lang, setLang] = useState("English");
  const [faq, setFaq] = useState<number | null>(null);
  const [terms, setTerms] = useState<string | null>(null);
  const [exp, setExp] = useState(false);
  const [closed, setClosed] = useState(false);
  const faqs = [["How do I reset my password?", "On the sign-in screen tap “Forgot password?”. In demo mode the recovery code is 123456."], ["Why can't I see some records?", "Access depends on your role and assignments. Parents only see verified, linked children."], ["How are fees recorded?", "In this prototype all payments are DEMO records. Real online payments will use a secure server-side provider."], ["Is my child's data safe?", "Student data is never used for advertising and is visible only to authorised people. Production security is enforced by the backend."]];
  return (
    <Page title="Preferences & help">
      <Tabs value={tab} onChange={setTab} options={[{ value: "prefs", label: "Preferences" }, { value: "help", label: "Help" }, { value: "privacy", label: "Privacy" }]} />
      {tab === "prefs" && <>
        <Section title="Notifications"><List>
          <Switch checked={n.push} onChange={(v) => setN({ ...n, push: v })} label="Push notifications" sub="Preference only — push delivery isn't connected in demo" />
          <Switch checked={n.att} onChange={(v) => setN({ ...n, att: v })} label="Attendance alerts" /><Switch checked={n.hw} onChange={(v) => setN({ ...n, hw: v })} label="Homework updates" />
          <Switch checked={n.exam} onChange={(v) => setN({ ...n, exam: v })} label="Exams & results" /><Switch checked={n.fee} onChange={(v) => setN({ ...n, fee: v })} label="Fee reminders" />
          <Switch checked={n.quiet} onChange={(v) => setN({ ...n, quiet: v })} label="Quiet hours" sub="Pause alerts 9 PM – 7 AM" />
        </List></Section>
        <Section title="Language"><Select value={lang} onChange={(v) => { setLang(v); toast(`Language set to ${v} (interface text stays English in this prototype)`, "info"); }} options={["English", "हिन्दी (Hindi)", "मराठी (Marathi)", "ગુજરાતી (Gujarati)"]} /></Section>
        <Section title="Appearance"><Card><div className="flex items-center justify-between"><span className="text-[14.5px] font-medium">Theme</span><Badge tone="brand">Light</Badge></div><p className="mt-1 text-[12.5px] text-mute">Dark mode is not available in this version.</p></Card></Section>
        <Section title="Demo tools"><List><Switch checked={offline} onChange={(v) => { setOffline(v); toast(v ? "Offline mode simulated" : "Back online", "info"); }} label="Simulate offline mode" sub="Shows the offline indicator" /><Row icon={Layers} title="App states gallery" sub="Loading, empty, error, offline, permission & more" onClick={() => push("S15")} /></List></Section>
        <div className="mt-4"><Btn variant="secondary" onClick={() => { uc.reset(); toast("Demo data reset to the original records"); }}>Reset demo data</Btn></div>
      </>}
      {tab === "help" && <>
        <Section title="Frequently asked questions"><List>{faqs.map((f, i) => (
          <div key={i}><Row icon={HelpCircle} title={f[0]} onClick={() => setFaq(faq === i ? null : i)} />{faq === i ? <p className="anim-fade px-4 pb-4 pl-[68px] text-[13px] leading-relaxed text-mute">{f[1]}</p> : null}</div>))}</List></Section>
        <Section title="Contact support"><List>
          <Row icon={Mail} title="support@guruflow.example" sub="Reply within 1 working day" tone="sky" onClick={() => toast("Demo: email app would open here", "info")} />
          <Row icon={Phone} title="+91 80 4000 1234" sub="Mon–Sat, 9:00 AM – 6:00 PM" tone="sky" onClick={() => toast("Demo: dialer would open here", "info")} />
        </List></Section>
      </>}
      {tab === "privacy" && <>
        <Section><Banner icon={ShieldCheck} tone="ok">Children's data is only visible to authorised staff and verified guardians. We never use student data for advertising.</Banner></Section>
        <Section title="Legal"><List><Row icon={FileText} title="Terms of Use" onClick={() => setTerms("Terms of Use")} /><Row icon={Lock} title="Privacy Policy" onClick={() => setTerms("Privacy Policy")} /></List></Section>
        <Section title="Your data"><List>
          <Row icon={Download} title="Export my data" sub="Preview what an export would contain" onClick={() => setExp(true)} />
          <Row icon={Trash2} title="Request account closure" sub="Sends a closure request to the institute" tone="bad" onClick={() => confirm({ title: "Request account closure?", body: "This records a closure request (demo). No data is deleted in this prototype.", confirmLabel: "Send request", danger: true, onConfirm: () => { setClosed(true); toast("Closure request recorded (demo)", "info"); } })} />
        </List>{closed ? <div className="mt-3"><Banner tone="warn" icon={Hourglass}>Closure request recorded (demo). In production, an administrator would confirm before any deletion.</Banner></div> : null}</Section>
      </>}
      <Sheet open={!!terms} onClose={() => setTerms(null)} title={terms ?? ""}><p className="text-[13.5px] leading-relaxed text-mute">This is a prototype document. In the released product this page will show the institute's legal text: how data is collected, who can see it, how long it is kept, and how to request export or deletion. Student information is processed only to provide education services and is never sold or used for behavioural advertising.</p></Sheet>
      <Sheet open={exp} onClose={() => setExp(false)} title="Data export preview">
        <Banner tone="warn">Demo preview only — this is not a real export from a production database.</Banner>
        <div className="mt-3"><Kv k="Profile" v="1 record" /><Kv k="Memberships" v={`${db.memberships.length} institutes`} /><Kv k="Notifications" v={`${db.notifications.length} items`} /><Kv k="Role in view" v={ROLE_LABEL[session.role]} /></div>
        <div className="mt-3"><Btn onClick={() => { setExp(false); toast("Export request noted (demo)", "info"); }}>Request export file</Btn></div>
      </Sheet>
    </Page>
  );
}

/* S15 */
function States(_: P) {
  const { toast, confirm, setOffline, offline, reset } = useApp();
  const [s, setS] = useState("Skeleton");
  const [retrying, setRetrying] = useState(false);
  const [done, setDone] = useState(false);
  const opts = ["Loading", "Skeleton", "Empty", "Network error", "Offline", "Retry", "Permission denied", "Session expired", "Maintenance", "Unsaved changes"];
  const retry = () => { setRetrying(true); setDone(false); setTimeout(() => { setRetrying(false); setDone(true); }, 1200); };
  return (
    <Page title="App states" subtitle="Reusable states used across GuruFlow">
      <Chips value={s} onChange={(v) => { setS(v); setDone(false); }} options={opts} />
      <Card className="mt-3 !p-2" pad={false}>
        {s === "Loading" && <div className="flex flex-col items-center py-14"><Loader2 size={34} className="animate-spin text-brand" /><p className="mt-3 text-[14px] text-mute">Loading your data…</p></div>}
        {s === "Skeleton" && <div className="p-3"><SkeletonList rows={3} /></div>}
        {s === "Empty" && <Empty icon={Inbox} title="No homework yet" body="When your teacher assigns homework it will show up here." action="Refresh" onAction={() => toast("Refreshed", "info")} />}
        {s === "Network error" && <ErrorState icon={WifiOff} title="No connection" body="Check your internet connection and try again." onRetry={() => toast("Still offline (demo)", "bad")} />}
        {s === "Offline" && <div className="p-5 text-center"><WifiOff className="mx-auto text-warn" size={32} /><p className="mt-3 text-[14px] text-mute">Offline mode shows saved data and a banner at the top of the app.</p><div className="mt-4"><Btn variant={offline ? "secondary" : "primary"} onClick={() => setOffline(!offline)}>{offline ? "Go back online" : "Simulate offline mode"}</Btn></div></div>}
        {s === "Retry" && (retrying ? <div className="flex flex-col items-center py-14"><Loader2 size={34} className="animate-spin text-brand" /><p className="mt-3 text-[14px] text-mute">Retrying…</p></div> : done ? <Empty icon={RefreshCw} title="Loaded successfully" body="The retry worked." action="Run again" onAction={() => setDone(false)} /> : <ErrorState onRetry={retry} />)}
        {s === "Permission denied" && <Denied />}
        {s === "Session expired" && <ErrorState icon={Clock} title="Session expired" body="For your security you've been signed out. Please sign in again to continue." onRetry={() => reset("S03")} />}
        {s === "Maintenance" && <ErrorState icon={Wrench} title="Down for maintenance" body="GuruFlow is being upgraded and will be back shortly. Your data is safe." />}
        {s === "Unsaved changes" && <div className="p-5 text-center"><Info className="mx-auto text-brand" size={32} /><p className="mt-3 text-[14px] text-mute">Forms ask for confirmation before discarding edits. Try it:</p><div className="mt-4"><Btn onClick={() => confirm({ title: "Discard unsaved changes?", body: "You have changes that haven't been saved.", confirmLabel: "Discard", danger: true, onConfirm: () => toast("Changes discarded", "info") })}>Show unsaved-changes dialog</Btn></div></div>}
      </Card>
    </Page>
  );
}

export const coreScreens: ScreenMap = {
  S11: def("Notifications Inbox", "shared", Notifications), S12: def("Global Search", "shared", GlobalSearch), S13: def("User Profile", "shared", UserProfile),
  S14: def("Preferences / Help / Privacy", "shared", Preferences), S15: def("Global Application States", "shared", States),
};

/* ───────── Navigation hubs (tab roots, not counted in the 82) ───────── */
interface Item { icon: LucideIcon; label: string; sub?: string; to?: string; params?: Record<string, any>; act?: "switch" | "signout" | "dir"; tone?: any }
function Hub({ title, sections }: { title: string; sections: { title?: string; items: Item[] }[] }) {
  const { push, signOut, confirm } = useApp();
  const me = useMe();
  const { unread } = useNotifs();
  const [ctx, setCtx] = useState(false);
  return (
    <Page title={title} right={<IconBtn icon={Bell} label="Notifications" badge={unread} onClick={() => push("S11")} />}>
      {title === "More" ? <Card className="mt-2" onClick={() => push("S13")}><div className="flex items-center gap-3"><Avatar name={me.name} size={46} /><div className="min-w-0 flex-1"><div className="truncate text-[15px] font-semibold">{me.name}</div><div className="text-[12.5px] text-mute">{ROLE_LABEL[me.role]} · View profile</div></div></div></Card> : null}
      {sections.map((s, i) => (
        <Section key={i} title={s.title}><List>{s.items.map((it) => (
          <Row key={it.label} icon={it.icon} title={it.label} sub={it.sub} tone={it.tone} noChevron={it.act === "signout"}
            onClick={() => it.act === "switch" ? setCtx(true) : it.act === "signout" ? confirm({ title: "Sign out of GuruFlow?", confirmLabel: "Sign out", danger: true, onConfirm: signOut }) : it.act === "dir" ? push("DIR") : push(it.to!, it.params)} />))}</List></Section>
      ))}
      <ContextSheet open={ctx} onClose={() => setCtx(false)} />
    </Page>
  );
}
import { BookOpen, BarChart3, CalendarDays, ClipboardList, DoorOpen, FileBarChart, FolderOpen, GraduationCap, IndianRupee, LineChart as LC, Megaphone, MessageCircleQuestion, ShieldCheck as SC, Target, Trophy, UserCheck, Users, UserCog, Library, CalendarOff, Handshake, Receipt, BookMarked, School, Notebook } from "lucide-react";

const common = (extra?: Item[]): { title?: string; items: Item[] }[] => [
  { title: "Account", items: [{ icon: UserCircle, label: "Profile", to: "S13" }, { icon: Settings, label: "Preferences, help & privacy", to: "S14" }, { icon: Repeat, label: "Switch institute or role", act: "switch" }, { icon: Layers, label: "All screens (demo directory)", act: "dir" }, ...(extra ?? []), { icon: LogOut, label: "Sign out", act: "signout", tone: "bad" }] },
];
const OwnerAcademics = (_: P) => <Hub title="Academics" sections={[
  { title: "Structure", items: [{ icon: BookOpen, label: "Batches & classes", sub: "Create, edit and view rosters", to: "S28" }, { icon: CalendarDays, label: "Academic sessions", to: "S27" }, { icon: DoorOpen, label: "Subjects & classrooms", to: "S30" }, { icon: ClipboardList, label: "Timetable", sub: "With conflict detection", to: "S31" }, { icon: ClipboardList, label: "Assign homework", sub: "Publish to a batch", to: "S48", tone: "sky" }] },
  { title: "Monitoring", items: [{ icon: UserCheck, label: "Attendance reports", to: "S32" }, { icon: GraduationCap, label: "Exams & results", to: "S33" }, { icon: FolderOpen, label: "Study resources", to: "S38" }] },
]} />;
const OwnerMore = (_: P) => <Hub title="More" sections={[
  { title: "Manage", items: [{ icon: IndianRupee, label: "Fees dashboard", to: "S35", tone: "warn" }, { icon: Megaphone, label: "Notices & requests", to: "S39", tone: "sky" }, { icon: BarChart3, label: "Insights & reports", to: "S40", tone: "violet" }, { icon: Users, label: "Staff directory", to: "S25" }, { icon: ShieldCheck, label: "Guardian verification", to: "S24", tone: "ok" }, { icon: UserCog, label: "Institute settings & permissions", to: "S41" }] },
  ...common(),
]} />;
const TeacherMore = (_: P) => <Hub title="More" sections={[
  { title: "My work", items: [{ icon: CalendarDays, label: "Timetable", to: "S43" }, { icon: Users, label: "My students", to: "S51" }, { icon: GraduationCap, label: "Marks entry", to: "S50", tone: "violet" }, { icon: FolderOpen, label: "Resources", to: "S52" }, { icon: MessageCircleQuestion, label: "Student doubts", to: "S53", tone: "sky" }, { icon: CalendarOff, label: "Leave & calendar", to: "S54", tone: "warn" }, { icon: Megaphone, label: "Notices & notifications", to: "S55" }] },
  ...common(),
]} />;
const StudentMore = (_: P) => <Hub title="More" sections={[
  { title: "Learning", items: [{ icon: UserCheck, label: "My attendance", to: "S58", tone: "ok" }, { icon: GraduationCap, label: "Exams & schedule", to: "S62", tone: "violet" }, { icon: FileBarChart, label: "My results", to: "S63" }, { icon: Target, label: "Study planner", to: "S64", tone: "sky" }, { icon: LC, label: "My progress", to: "S67" }, { icon: Library, label: "Learning library", to: "S68" }, { icon: MessageCircleQuestion, label: "Ask your teacher", to: "S70", tone: "sky" }, { icon: Trophy, label: "Milestones & profile", to: "S71", tone: "warn" }] },
  ...common(),
]} />;
const ParentAcademics = (_: P) => <Hub title="Academics" sections={[
  { title: "My child's learning", items: [{ icon: UserCheck, label: "Attendance", to: "S73", tone: "ok" }, { icon: GraduationCap, label: "Results & progress", to: "S74", tone: "violet" }, { icon: ClipboardList, label: "Homework", to: "S75" }, { icon: Notebook, label: "Weekly digest", sub: "Everything in one place", to: "S76", tone: "sky" }] },
  { title: "Requests", items: [{ icon: CalendarOff, label: "Apply for leave", to: "S80", tone: "warn" }, { icon: Handshake, label: "Teachers & meetings", to: "S81" }] },
]} />;
const ParentMore = (_: P) => <Hub title="More" sections={[
  { title: "Family", items: [{ icon: Receipt, label: "Payment history & receipts", to: "S78", tone: "warn" }, { icon: CalendarOff, label: "Apply for leave", to: "S80" }, { icon: Handshake, label: "Teachers & meetings", to: "S81" }, { icon: Bell, label: "Notifications & profile", to: "S82" }] },
  ...common(),
]} />;
export const hubScreens: ScreenMap = {
  "H-owner-academics": def("Academics hub", "owner", OwnerAcademics), "H-owner-more": def("Owner More", "owner", OwnerMore), "H-teacher-more": def("Teacher More", "teacher", TeacherMore),
  "H-student-more": def("Student More", "student", StudentMore), "H-parent-academics": def("Parent Academics hub", "parent", ParentAcademics), "H-parent-more": def("Parent More", "parent", ParentMore),
};
export { Search, School, BookMarked, LifeBuoy, Languages, can, subFor, useUnsaved, Segmented, IconTile };
