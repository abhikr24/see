"use client";
import React, { useMemo, useState } from "react";
import { Award, BookOpen, Bookmark, CalendarDays, Check, CheckCircle2, ClipboardList, Clock, Download, FileText, GraduationCap, Image as ImageIcon, Link2, LogOut, MessageCircleQuestion, Plus, RotateCcw, Send, Settings, Sparkles, Target, Trash2, Trophy, Users, ChevronLeft, ChevronRight, Dumbbell, Lock } from "lucide-react";
import type { Homework, Question, Resource } from "@/domain/types";
import { QUESTIONS } from "@/data/questions";
import { useApp, useMe, useScope } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Chips, Empty, IconBtn, IconTile, Kv, List, Page, Progress, Row, Section, Segmented, Sheet, Stat, Tabs, Tone } from "@/ui/kit";
import { DatePicker, FileItem, FilePicker, Select, SearchInput, Switch, TextInput, useForm, Checkbox } from "@/ui/forms";
import { AttPill, Bars, Donut, LineChart, MonthCalendar } from "@/ui/charts";
import { ExamCard, HomeworkCard, NoticeCard, StatusBadge } from "@/ui/cards";
import { HomeFrame } from "./common";
import { Chat } from "./teacher";
import { def, P, ScreenMap } from "./types";
import { addDays, ago, dmy, DAYS, DAYS_LONG, dtLabel, fileSize, gradeOf, longDate, nowISO, pct, relDay, time12, today, uid, validPhone } from "@/lib/fmt";
import { batchAttOn, classStatus, noticeVisible, resultsFor, studentAtt, subFor } from "@/features/selectors";
import { uc } from "@/features/usecases";

export function ProfileCard() { return null; }
const bShort = (n?: string) => n?.split(" – ")[0] ?? "";
function useS() {
  const sc = useScope();
  const me = useMe();
  const st = me.student;
  const batch = sc.batches.find((b) => b.id === st.batchId);
  return { sc, me, st, batch };
}

/* S56 */
function StudentHome(_: P) {
  const { sc, me, st, batch } = useS();
  const { push, session } = useApp();
  const db = sc.db;
  const dow = new Date().getDay();
  const tt = sc.timetable.filter((e) => e.batchId === st.batchId);
  const todays = tt.filter((e) => e.day === dow).sort((a, b) => (a.start < b.start ? -1 : 1));
  const nextUp = todays.find((e) => classStatus(e) !== "Completed");
  const hws = sc.homework.filter((h) => h.batchId === st.batchId && h.status === "published").map((h) => ({ h, s: subFor(db, h, st.id).status })).filter((x) => x.s === "pending" || x.s === "returned" || x.s === "overdue").sort((a, b) => (a.h.due < b.h.due ? -1 : 1));
  const tests = sc.exams.filter((x) => x.batchId === st.batchId && x.status === "scheduled" && x.date >= today()).sort((a, b) => (a.date < b.date ? -1 : 1));
  const res = sc.resources.filter((r) => r.batchIds.includes(st.batchId)).sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 3);
  const notices = sc.notices.filter((n) => noticeVisible(n, "student", me.batchIds)).sort((a, b) => (a.publishAt < b.publishAt ? 1 : -1)).slice(0, 2);
  const att = studentAtt(db, st.id);
  const rs = resultsFor(db, st.id);
  const avg = rs.length ? Math.round(rs.reduce((a, r) => a + r.pct, 0) / rs.length) : 0;
  return (
    <HomeFrame greeting={`Hi, ${me.first} 👋`} sub={`${bShort(batch?.name)} · ${longDate(today())}`}>
      {nextUp ? <Card onClick={() => push("S57")}><div className="flex items-center justify-between"><Badge tone={classStatus(nextUp) === "Ongoing" ? "ok" : "brand"}>{classStatus(nextUp) === "Ongoing" ? "Happening now" : "Next class"}</Badge><span className="text-[12.5px] font-semibold text-mute">{time12(nextUp.start)}</span></div><div className="mt-2 text-[19px] font-bold">{nextUp.subject}</div><div className="text-[13px] text-mute">{sc.staff.find((t) => t.id === nextUp.teacherId)?.name} · {sc.rooms.find((r) => r.id === nextUp.roomId)?.name}</div></Card> : <Card><div className="text-[15px] font-semibold">{todays.length ? "Classes are done for today" : "No classes today"}</div><p className="mt-1 text-[13px] text-mute">A good time to practise or revise.</p></Card>}
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Card onClick={() => push("S58")} className="!p-3.5"><div className="flex items-center gap-3"><Donut value={att.pct} size={62} tone={att.pct >= 85 ? "ok" : "warn"} /><div><div className="text-[12px] text-mute">Attendance</div><div className="text-[13px] font-semibold">{att.a} absent</div></div></div></Card>
        <Card onClick={() => push("S67")} className="!p-3.5"><div className="flex items-center gap-3"><Donut value={avg} size={62} tone="violet" /><div><div className="text-[12px] text-mute">Test average</div><div className="text-[13px] font-semibold">{rs.length} results</div></div></div></Card>
      </div>
      <Section title="Today's timetable" action="Full week" onAction={() => push("S57")}>{todays.length ? <List>{todays.map((e) => <Row key={e.id} icon={Clock} tone={classStatus(e) === "Completed" ? "mute" : "brand"} title={e.subject} sub={`${time12(e.start)} – ${time12(e.end)} · ${sc.staff.find((t) => t.id === e.teacherId)?.name}`} right={<StatusBadge status={classStatus(e) === "Completed" ? "completed" : classStatus(e) === "Ongoing" ? "active" : "scheduled"} text={classStatus(e)} />} onClick={() => push("S57", { entry: e.id })} />)}</List> : <Card><p className="text-[13.5px] text-mute">No classes scheduled today.</p></Card>}</Section>
      <Section title="Homework to do" action="All homework" onAction={() => push("S59")}>{hws.length ? <div className="space-y-2.5">{hws.slice(0, 3).map(({ h, s }) => <HomeworkCard key={h.id} h={h} status={s} onClick={() => push("S60", { id: h.id })} />)}</div> : <Card><div className="flex items-center gap-2 text-[14px] font-medium text-ok"><CheckCircle2 size={18} />You're all caught up!</div></Card>}</Section>
      {tests.length ? <Section title="Upcoming tests" action="Schedule" onAction={() => push("S62")}><div className="space-y-2.5">{tests.slice(0, 2).map((x) => <ExamCard key={x.id} x={x} onClick={() => push("S62", { id: x.id })} right={<Badge tone="violet">{relDay(x.date)}</Badge>} />)}</div></Section> : null}
      <Section title="New in your library" action="Library" onAction={() => push("S68")}><List>{res.map((r) => <Row key={r.id} icon={FileText} title={r.title} sub={`${r.subject} · ${ago(r.at)}`} onClick={() => push("S69", { id: r.id })} />)}</List></Section>
      <Section title="Notices" action="All" onAction={() => push("S79")}><div className="space-y-2.5">{notices.map((n) => <NoticeCard key={n.id} n={n} read={n.readBy.includes(session.role)} onClick={() => push("S79", { id: n.id })} />)}</div></Section>
    </HomeFrame>
  );
}

/* S57 */
function StudentTimetable({ params }: P) {
  const { sc, st } = useS();
  const [v, setV] = useState<"day" | "week">("day");
  const [day, setDay] = useState(Math.min(Math.max(new Date().getDay(), 1), 6));
  const [open, setOpen] = useState(sc.timetable.find((e) => e.id === params.entry) ?? null);
  const tt = sc.timetable.filter((e) => e.batchId === st.batchId).sort((a, b) => (a.start < b.start ? -1 : 1));
  const row = (e: (typeof tt)[number]) => <Row key={e.id} icon={Clock} title={e.subject} sub={`${time12(e.start)} – ${time12(e.end)} · ${sc.staff.find((t) => t.id === e.teacherId)?.name} · ${sc.rooms.find((r) => r.id === e.roomId)?.name}`} onClick={() => setOpen(e)} />;
  const res = open ? sc.resources.filter((r) => r.batchIds.includes(st.batchId) && r.subject === open.subject) : [];
  const { push } = useApp();
  return (
    <Page title="Timetable" subtitle={bShort(sc.batches.find((b) => b.id === st.batchId)?.name)}>
      <div className="space-y-2 pt-2"><Segmented value={v} onChange={setV} options={[{ value: "day", label: "Day" }, { value: "week", label: "Week" }]} />{v === "day" ? <Chips value={String(day)} onChange={(x) => setDay(Number(x))} options={[1, 2, 3, 4, 5, 6].map((d) => ({ value: String(d), label: DAYS[d] }))} /> : null}</div>
      <div className="mt-2">{v === "day" ? (tt.filter((e) => e.day === day).length ? <List>{tt.filter((e) => e.day === day).map(row)}</List> : <Empty icon={CalendarDays} title="No classes" />) : [1, 2, 3, 4, 5, 6].map((d) => <div key={d} className="mb-3"><div className="mb-1.5 flex items-center gap-2 text-[13px] font-semibold">{DAYS_LONG[d]}{d === new Date().getDay() ? <Badge tone="brand">Today</Badge> : null}</div><List>{tt.filter((e) => e.day === d).map(row)}</List></div>)}</div>
      <Sheet open={!!open} onClose={() => setOpen(null)} title={open?.subject}>{open ? <div className="space-y-3"><Card><Kv k="When" v={`${DAYS_LONG[open.day]}, ${time12(open.start)} – ${time12(open.end)}`} /><Kv k="Teacher" v={sc.staff.find((t) => t.id === open.teacherId)?.name} /><Kv k="Classroom" v={sc.rooms.find((r) => r.id === open.roomId)?.name} /></Card><Section title="Related resources">{res.length ? <List>{res.map((r) => <Row key={r.id} icon={FileText} title={r.title} sub={r.type.toUpperCase()} onClick={() => { setOpen(null); push("S69", { id: r.id }); }} />)}</List> : <Card><p className="text-[13px] text-mute">No resources for this subject yet.</p></Card>}</Section></div> : null}</Sheet>
    </Page>
  );
}

/* S58 */
function MyAttendance(_: P) {
  const { sc, st, me } = useS();
  const [m, setM] = useState({ y: new Date().getFullYear(), m: new Date().getMonth() });
  const att = studentAtt(sc.db, st.id);
  const notices = sc.notices.filter((n) => noticeVisible(n, "student", me.batchIds) && ["Holiday", "Academic"].includes(n.category)).slice(0, 2);
  return (
    <Page title="My attendance">
      <div className="space-y-3 pt-2"><Card><div className="flex items-center gap-4"><Donut value={att.pct} size={92} tone={att.pct >= 85 ? "ok" : "warn"} sub="attended" /><div className="grid flex-1 grid-cols-3 text-center"><div><div className="text-[22px] font-bold text-ok">{att.p}</div><div className="text-[11px] text-mute">Present</div></div><div><div className="text-[22px] font-bold text-bad">{att.a}</div><div className="text-[11px] text-mute">Absent</div></div><div><div className="text-[22px] font-bold text-warn">{att.l}</div><div className="text-[11px] text-mute">Late</div></div></div></div><p className="mt-3 text-[12px] text-mute">{att.pct >= 85 ? "Great consistency — keep it up!" : "Try to attend regularly; reach out to your teacher if something is making it hard."} Late counts as attended.</p></Card>
        <Card><MonthCalendar year={m.y} month={m.m} marks={att.byDate} onChange={(y, mo) => setM({ y, m: mo })} /></Card>
        <Section title="Recent history"><List>{Object.entries(att.byDate).sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 8).map(([d, s]) => <Row key={d} title={longDate(d)} sub={dmy(d)} right={<AttPill status={s} />} noChevron />)}</List></Section>
        {notices.length ? <Section title="Institute notices">{notices.map((n) => <NoticeCard key={n.id} n={n} />)}</Section> : null}</div>
    </Page>
  );
}

/* S59 */
function StudentHomework({ params }: P) {
  const { sc, st } = useS();
  const { push } = useApp();
  const [tab, setTab] = useState<string>(params.tab ?? "all");
  const [subj, setSubj] = useState("All");
  const [asc, setAsc] = useState(true);
  const items = sc.homework.filter((h) => h.batchId === st.batchId && h.status === "published").map((h) => ({ h, s: subFor(sc.db, h, st.id).status }));
  const f = (x: (typeof items)[number]) => tab === "all" ? true : tab === "soon" ? x.h.due >= today() && x.h.due <= addDays(3) && ["pending", "returned"].includes(x.s) : tab === "pending" ? ["pending", "returned"].includes(x.s) : tab === "submitted" ? x.s === "submitted" : tab === "overdue" ? x.s === "overdue" : x.s === "reviewed";
  const list = items.filter((x) => f(x) && (subj === "All" || x.h.subject === subj)).sort((a, b) => (a.h.due < b.h.due ? (asc ? -1 : 1) : asc ? 1 : -1));
  return (
    <Page title="Homework" right={<button onClick={() => setAsc(!asc)} className="min-h-10 rounded-full px-3 text-[12.5px] font-semibold text-brand">Due {asc ? "↑" : "↓"}</button>}>
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "all", label: "All" }, { value: "soon", label: "Due soon" }, { value: "pending", label: "To do" }, { value: "submitted", label: "Submitted" }, { value: "overdue", label: "Overdue" }, { value: "done", label: "Completed" }]} /></div>
      <Chips value={subj} onChange={setSubj} options={["All", ...Array.from(new Set(items.map((x) => x.h.subject)))]} />
      {list.length ? <div className="mt-2 space-y-2.5">{list.map(({ h, s }) => <HomeworkCard key={h.id} h={h} status={s} onClick={() => push("S60", { id: h.id })} />)}</div> : <Empty icon={ClipboardList} title="Nothing here" body="No homework in this view." />}
    </Page>
  );
}

/* S60 */
function HomeworkDetail({ params }: P) {
  const { sc, st } = useS();
  const { push, confirm, toast, back } = useApp();
  const items = sc.homework.filter((h) => h.batchId === st.batchId && h.status === "published");
  const hw = items.find((h) => h.id === params.id) ?? items[0];
  const [file, setFile] = useState<import("@/domain/types").FileMeta | null>(null);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  if (!hw) return <Page title="Homework"><Empty title="No homework" /></Page>;
  const { sub, status } = subFor(sc.db, hw, st.id);
  const teacher = sc.staff.find((t) => t.id === hw.teacherId);
  const canSubmit = status === "pending" || status === "overdue" || status === "returned";
  return (
    <Page title="Homework" footer={canSubmit ? <Btn loading={loading} disabled={!file && text.trim().length < 5} onClick={() => confirm({ title: status === "returned" ? "Resubmit homework?" : "Submit homework?", body: status === "overdue" ? "This is past the due date. Your teacher will see it as late." : "Your teacher will be notified. In demo mode the file isn't uploaded to any cloud.", confirmLabel: "Submit", onConfirm: async () => { setLoading(true); await uc.submitHomework({ hwId: hw.id, studentId: st.id, text: text.trim(), file }); setLoading(false); toast("Homework submitted (demo)"); } })}>{status === "returned" ? "Resubmit" : "Submit homework"}</Btn> : undefined}>
      <div className="space-y-3 pt-2">
        <Card><div className="flex items-start justify-between gap-2"><h2 className="text-[17px] font-bold leading-snug">{hw.title}</h2><StatusBadge status={status} /></div><div className="mt-2 divide-y divide-line"><Kv k="Subject" v={hw.subject} /><Kv k="Teacher" v={teacher?.name} /><Kv k="Due" v={`${dmy(hw.due)} (${relDay(hw.due)})`} /><Kv k="Marks" v={`${hw.max}`} /></div></Card>
        <Section title="Instructions"><Card><p className="text-[14px] leading-relaxed">{hw.instructions}</p></Card></Section>
        {hw.attachment ? <Section title="Attachment"><FileItem file={hw.attachment} right={<Download size={18} className="text-mute" />} /></Section> : null}
        {sub && status !== "pending" && status !== "overdue" ? <Section title="Your submission"><Card>{sub.file ? <FileItem file={sub.file} /> : null}{sub.text ? <p className="mt-2 text-[13.5px]">{sub.text}</p> : null}<p className="mt-2 text-[12px] text-mute">Submitted {sub.submittedAt ? dtLabel(sub.submittedAt) : ""}</p>{(status === "reviewed" || status === "returned") ? <div className="mt-3"><Btn size="sm" variant="secondary" onClick={() => push("S61", { id: hw.id })}>View feedback</Btn></div> : null}</Card></Section> : null}
        {status === "returned" ? <Banner tone="warn">Your teacher asked for a correction. Update your answer and resubmit.</Banner> : null}
        {canSubmit ? <Section title="Your answer"><div className="space-y-4"><FilePicker label="Upload your work" value={file} onChange={setFile} /><TextInput label="Written response" multiline rows={4} placeholder="Type your answer or notes (optional if you upload a file)" value={text} onChange={setText} /></div></Section> : null}
        <span className="hidden" onClick={back} />
      </div>
    </Page>
  );
}

/* S61 */
function HomeworkFeedback({ params }: P) {
  const { sc, st } = useS();
  const { push } = useApp();
  const subs = sc.submissions.filter((s) => s.studentId === st.id && (s.feedback || s.status === "reviewed" || s.status === "returned"));
  const sub = subs.find((s) => s.hwId === params.id) ?? subs[0];
  const hw = sub ? sc.homework.find((h) => h.id === sub.hwId) : undefined;
  if (!sub || !hw) return <Page title="Feedback"><Empty icon={Sparkles} title="No feedback yet" body="When your teacher reviews your homework, their feedback shows up here." /></Page>;
  return (
    <Page title="Homework feedback" footer={sub.status === "returned" ? <Btn icon={RotateCcw} onClick={() => push("S60", { id: hw.id })}>Resubmit homework</Btn> : undefined}>
      <div className="space-y-3 pt-2"><Card><div className="flex items-center justify-between gap-2"><div><div className="text-[16px] font-semibold">{hw.title}</div><div className="text-[12.5px] text-mute">{hw.subject}</div></div><StatusBadge status={sub.status} /></div>{sub.marks !== undefined ? <div className="mt-3 flex items-end gap-2"><span className="text-[34px] font-bold leading-none text-brand">{sub.marks}</span><span className="pb-1 text-[14px] text-mute">/ {hw.max} marks</span></div> : null}</Card>
        {sub.status === "returned" ? <Banner tone="warn">Correction requested — please update and resubmit.</Banner> : null}
        <Section title="Teacher's feedback"><Card><div className="flex gap-3"><Avatar name={sc.staff.find((t) => t.id === hw.teacherId)?.name ?? "T"} tone="violet" /><div><div className="text-[13px] font-semibold">{sc.staff.find((t) => t.id === hw.teacherId)?.name}</div><p className="mt-1 text-[14px] leading-relaxed">{sub.feedback || "No written feedback."}</p></div></div></Card></Section>
        <Section title="Submission history"><Card><ol className="space-y-3">{sub.history.map((h, i) => <li key={i} className="flex gap-3 text-[13px]"><span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand" /><div>{h.text}<div className="text-[11.5px] text-mute">{dtLabel(h.at)}</div></div></li>)}</ol></Card></Section></div>
    </Page>
  );
}

/* S62 */
function ExamsSchedule({ params }: P) {
  const { sc, st } = useS();
  const [tab, setTab] = useState("upcoming");
  const [open, setOpen] = useState(sc.exams.find((x) => x.id === params.id) ?? null);
  const mine = sc.exams.filter((x) => x.batchId === st.batchId && x.status !== "draft");
  const up = mine.filter((x) => x.status === "scheduled" && x.date >= today()).sort((a, b) => (a.date < b.date ? -1 : 1));
  const past = mine.filter((x) => !(x.status === "scheduled" && x.date >= today())).sort((a, b) => (a.date < b.date ? 1 : -1));
  const list = tab === "upcoming" ? up : past;
  const { push } = useApp();
  return (
    <Page title="Exams">
      <div className="pt-1"><Segmented value={tab} onChange={setTab} options={[{ value: "upcoming", label: `Upcoming (${up.length})` }, { value: "past", label: "Past" }]} /></div>
      {list.length ? <div className="mt-3 space-y-2.5">{list.map((x) => <ExamCard key={x.id} x={x} onClick={() => setOpen(x)} right={x.status === "scheduled" ? <Badge tone="violet">{relDay(x.date)}</Badge> : <StatusBadge status={x.status === "published" ? "published" : "completed"} text={x.status === "published" ? "Result out" : "Awaiting result"} />} />)}</div> : <Empty icon={GraduationCap} title="No exams" body={tab === "upcoming" ? "No upcoming tests are scheduled." : "Past exams will appear here."} />}
      <Sheet open={!!open} onClose={() => setOpen(null)} title={open?.name}>{open ? <div className="space-y-3"><Card><Kv k="Subject" v={open.subject} /><Kv k="Date" v={`${longDate(open.date)} · ${dmy(open.date)}`} /><Kv k="Time" v={`${time12(open.time)} · ${open.duration} min`} /><Kv k="Maximum marks" v={open.max} /></Card><Section title="Syllabus"><Card><p className="text-[14px]">{open.syllabus}</p></Card></Section><Section title="Instructions"><Card><p className="text-[13.5px] leading-relaxed text-mute">{open.instructions}</p></Card></Section>
        {sc.resources.filter((r) => r.batchIds.includes(st.batchId) && r.subject === open.subject).length ? <Section title="Study resources"><List>{sc.resources.filter((r) => r.batchIds.includes(st.batchId) && r.subject === open.subject).map((r) => <Row key={r.id} icon={FileText} title={r.title} onClick={() => { setOpen(null); push("S69", { id: r.id }); }} />)}</List></Section> : null}</div> : null}</Sheet>
    </Page>
  );
}

/* S63 */
function MyResults(_: P) {
  const { sc, st } = useS();
  const rs = resultsFor(sc.db, st.id);
  const avg = rs.length ? Math.round(rs.reduce((a, r) => a + r.pct, 0) / rs.length) : 0;
  const subjects = Array.from(new Set(rs.map((r) => r.exam.subject)));
  const bySub = subjects.map((s) => { const x = rs.filter((r) => r.exam.subject === s); return { label: s.slice(0, 5), value: Math.round(x.reduce((a, r) => a + r.pct, 0) / x.length), tone: "violet" as Tone }; });
  const totalM = rs.reduce((a, r) => a + r.marks, 0), totalMax = rs.reduce((a, r) => a + r.exam.max, 0);
  return (
    <Page title="My results">
      {rs.length === 0 ? <Empty icon={GraduationCap} title="No results yet" body="Your published results will appear here. Only you and your verified guardians can see them." /> : <div className="space-y-3 pt-2">
        <Card className="!bg-gradient-to-br !from-brand-dark !to-brand !text-white"><div className="flex items-center justify-between"><div><div className="text-[12px] text-white/70">Overall</div><div className="mt-1 text-[32px] font-bold leading-none">{avg}%</div><div className="mt-1 text-[13px] text-white/80">{totalM}/{totalMax} marks · Grade {gradeOf(avg)}</div></div><Award size={44} className="text-white/60" /></div></Card>
        <Banner tone="ok" icon={Sparkles}>{avg >= 75 ? "Excellent work! You're doing really well across your subjects." : avg >= 60 ? "Good progress. A little regular practice can lift your scores even more." : "Every test is a chance to learn. Try the Practice Zone to build confidence."}</Banner>
        <Section title="Subject-wise average"><Card><Bars data={bySub} max={100} height={90} suffix="%" /></Card></Section>
        <Section title="All results"><List>{rs.map((r) => <Row key={r.exam.id} icon={GraduationCap} tone="violet" title={r.exam.name} sub={`${r.exam.subject} · ${dmy(r.exam.date)}`} right={<div className="text-right"><div className="text-[15px] font-bold">{r.marks}/{r.exam.max}</div><div className="text-[11.5px] text-mute">{r.pct}% · {gradeOf(r.pct)}</div></div>} noChevron />)}</List></Section></div>}
    </Page>
  );
}

/* S64 */
function Planner(_: P) {
  const { sc, st } = useS();
  const { toast, confirm } = useApp();
  const [v, setV] = useState<"list" | "cal">("list");
  const [add, setAdd] = useState(false);
  const [m, setM] = useState({ y: new Date().getFullYear(), m: new Date().getMonth() });
  const tasks = sc.db.tasks.filter((t) => t.studentId === st.id).sort((a, b) => (a.done === b.done ? (a.due < b.due ? -1 : 1) : a.done ? 1 : -1));
  const done = tasks.filter((t) => t.done).length;
  const f = useForm({ title: "", kind: "task", subject: "", due: today(), remind: true }, (x) => ({ title: x.title.trim().length < 3 ? "Enter what you plan to do" : undefined, due: !x.due ? "Pick a date" : undefined }));
  const marks: Record<string, "H"> = {};
  tasks.filter((t) => !t.done).forEach((t) => (marks[t.due] = "H"));
  return (
    <Page title="Study planner" right={<IconBtn icon={Plus} label="Add task" tone="soft" onClick={() => { f.setV({ title: "", kind: "task", subject: "", due: today(), remind: true }); setAdd(true); }} />}>
      <div className="space-y-3 pt-2"><Card><div className="flex items-center justify-between text-[13px]"><span className="text-mute">Progress</span><b>{done} of {tasks.length} done</b></div><div className="mt-2"><Progress value={pct(done, tasks.length)} tone="ok" label="Tasks completed" /></div></Card>
        <Segmented value={v} onChange={setV} options={[{ value: "list", label: "List" }, { value: "cal", label: "Calendar" }]} />
        {v === "cal" ? <Card><MonthCalendar year={m.y} month={m.m} marks={marks} onChange={(y, mo) => setM({ y, m: mo })} /><p className="mt-3 text-center text-[12px] text-mute">“Off” marks days with pending tasks.</p></Card> : null}
        {tasks.length === 0 ? <Empty icon={Target} title="Plan your study time" body="Add tasks, revision plans and goals to stay on track." action="Add task" onAction={() => setAdd(true)} /> : <List>{tasks.map((t) => (
          <div key={t.id} className="flex items-center gap-3 px-4 py-3"><button role="checkbox" aria-checked={t.done} aria-label={`Mark ${t.title} ${t.done ? "not done" : "done"}`} onClick={() => uc.save("tasks", { ...t, done: !t.done })} className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg border-2 ${t.done ? "border-ok bg-ok text-white" : "border-slate-300"}`}>{t.done ? <Check size={16} /> : null}</button>
            <div className="min-w-0 flex-1"><div className={`text-[14.5px] font-medium ${t.done ? "text-mute line-through" : ""}`}>{t.title}</div><div className="mt-0.5 flex flex-wrap items-center gap-2 text-[12px] text-mute"><Badge tone={t.kind === "goal" ? "warn" : t.kind === "revision" ? "violet" : "sky"}>{t.kind}</Badge>{t.subject ? <span>{t.subject}</span> : null}<span>{t.done ? "Done" : relDay(t.due)}</span></div></div>
            <IconBtn icon={Trash2} label={`Delete ${t.title}`} onClick={() => confirm({ title: "Delete this task?", confirmLabel: "Delete", danger: true, onConfirm: async () => { await uc.remove("tasks", t.id); toast("Task deleted", "info"); } })} /></div>))}</List>}</div>
      <Sheet open={add} onClose={() => setAdd(false)} title="Add to planner"><div className="space-y-4"><TextInput label="What will you do?" required placeholder="e.g. Revise Light chapter" {...f.bind("title")} /><Segmented value={f.v.kind} onChange={(x) => f.set("kind", x)} options={[{ value: "task", label: "Task" }, { value: "revision", label: "Revision" }, { value: "goal", label: "Goal" }]} /><Select label="Subject" options={sc.batches.find((b) => b.id === st.batchId) ? Object.keys(sc.batches.find((b) => b.id === st.batchId)!.subjectTeachers) : []} value={f.v.subject} onChange={(x) => f.set("subject", x)} /><DatePicker label="Date" required min={today()} value={f.v.due} onChange={(x) => f.set("due", x)} />
        <div className="-mx-4 rounded-xl border border-line"><Switch checked={f.v.remind} onChange={(x) => f.set("remind", x)} label="Remind me" sub="In-app reminder on the day" /></div><Btn disabled={!f.valid} onClick={async () => { await uc.save("tasks", { id: uid("pt"), studentId: st.id, title: f.v.title.trim(), kind: f.v.kind as "task", due: f.v.due, done: false, subject: f.v.subject || undefined }); setAdd(false); toast("Added to your planner"); }}>Add</Btn></div></Sheet>
    </Page>
  );
}

/* S65 */
function PracticeZone(_: P) {
  const { sc, st, batch } = useS();
  const { push } = useApp();
  const subjects = Array.from(new Set(QUESTIONS.map((q) => q.subject))).filter((s) => !batch || s in batch.subjectTeachers || true);
  const [subject, setSubject] = useState<string>("");
  const [chapter, setChapter] = useState("");
  const chapters = Array.from(new Set(QUESTIONS.filter((q) => q.subject === subject).map((q) => q.chapter)));
  const topics = Array.from(new Set(QUESTIONS.filter((q) => q.subject === subject && q.chapter === chapter).map((q) => q.topic)));
  const attempts = sc.db.attempts.filter((a) => a.studentId === st.id).sort((a, b) => (a.at < b.at ? 1 : -1));
  const count = (s: string, c?: string, t?: string) => QUESTIONS.filter((q) => q.subject === s && (!c || q.chapter === c) && (!t || q.topic === t)).length;
  return (
    <Page title="Practice zone" subtitle="Practise at your own pace">
      <div className="space-y-3 pt-2">
        <Banner icon={Sparkles}>No timers, no rankings — just practice with instant explanations.</Banner>
        <Section title="1 · Choose a subject"><div className="grid grid-cols-3 gap-2.5">{subjects.map((s) => <button key={s} onClick={() => { setSubject(s); setChapter(""); }} aria-pressed={subject === s} className={`min-h-[84px] rounded-2xl border p-3 text-center ${subject === s ? "border-brand bg-brand-soft" : "border-line bg-white"}`}><BookOpen className={`mx-auto ${subject === s ? "text-brand" : "text-mute"}`} size={22} /><div className="mt-1.5 text-[13px] font-semibold">{s}</div><div className="text-[11px] text-mute">{count(s)} questions</div></button>)}</div></Section>
        {subject ? <Section title="2 · Choose a chapter"><List>{chapters.map((c) => <Row key={c} icon={FileText} tone={chapter === c ? "brand" : "mute"} title={c} sub={`${count(subject, c)} questions`} right={chapter === c ? <Badge tone="brand">Selected</Badge> : undefined} onClick={() => setChapter(c)} noChevron />)}</List></Section> : null}
        {chapter ? <Section title="3 · Choose a topic"><div className="space-y-2.5">{topics.map((t) => <Card key={t} onClick={() => push("S66", { subject, chapter, topic: t })} className="!p-3.5"><div className="flex items-center gap-3"><IconTile icon={Dumbbell} tone="sky" /><div className="flex-1"><div className="text-[14.5px] font-semibold">{t}</div><div className="text-[12px] text-mute">{count(subject, chapter, t)} questions</div></div><Badge tone="brand">Start</Badge></div></Card>)}<Btn variant="secondary" onClick={() => push("S66", { subject, chapter })}>Practise the whole chapter ({count(subject, chapter)})</Btn></div></Section> : null}
        <Section title="Recent attempts">{attempts.length ? <List>{attempts.slice(0, 5).map((a) => <Row key={a.id} icon={ClipboardList} tone={a.score / a.total >= 0.7 ? "ok" : "warn"} title={`${a.subject} · ${a.topic || a.chapter}`} sub={ago(a.at)} right={<Badge tone={a.score / a.total >= 0.7 ? "ok" : "warn"}>{a.score}/{a.total}</Badge>} onClick={() => push("S66", { subject: a.subject, chapter: a.chapter, topic: a.topic || undefined })} />)}</List> : <Card><p className="text-[13px] text-mute">No attempts yet. Pick a topic above to begin.</p></Card>}</Section>
      </div>
    </Page>
  );
}

/* S66 */
function Quiz({ params }: P) {
  const { st, sc } = useS();
  const { confirm, toast, back, push } = useApp();
  const pool = useMemo(() => QUESTIONS.filter((q) => q.subject === (params.subject ?? "Mathematics") && (!params.chapter || q.chapter === params.chapter) && (!params.topic || q.topic === params.topic) && (!params.ids || (params.ids as string[]).includes(q.id))), [params]);
  const [round, setRound] = useState(0);
  const [qs, setQs] = useState<Question[]>(pool);
  const [i, setI] = useState(0);
  const [ans, setAns] = useState<Record<string, number>>({});
  const [done, setDone] = useState(false);
  const [review, setReview] = useState<"all" | "wrong">("all");
  void round; void sc;
  if (!qs.length) return <Page title="Practice"><Empty icon={Dumbbell} title="No questions" body="Pick a topic from the Practice zone." action="Back" onAction={back} /></Page>;
  const score = qs.filter((q) => ans[q.id] === q.answer).length;
  const wrong = qs.filter((q) => ans[q.id] !== q.answer);
  const submit = () => confirm({ title: "Submit your answers?", body: Object.keys(ans).length < qs.length ? `You've left ${qs.length - Object.keys(ans).length} question(s) unanswered. They'll count as incorrect.` : "You can review every explanation afterwards.", confirmLabel: "Submit", onConfirm: async () => { await uc.saveAttempt({ studentId: st.id, subject: qs[0].subject, chapter: params.chapter ?? qs[0].chapter, topic: params.topic ?? "", score, total: qs.length, wrong: wrong.map((q) => q.id) }); setDone(true); toast("Practice saved"); } });
  const restart = (list: Question[]) => { setQs(list); setAns({}); setI(0); setDone(false); setReview("all"); setRound((r) => r + 1); };
  if (done) {
    const p = pct(score, qs.length);
    return (
      <Page title="Results" footer={<div className="flex gap-2">{wrong.length ? <Btn variant="secondary" icon={RotateCcw} onClick={() => restart(wrong)}>Retry {wrong.length} incorrect</Btn> : null}<Btn onClick={() => restart(pool)}>Practise again</Btn></div>}>
        <div className="space-y-3 pt-2"><Card className="text-center"><div className="flex justify-center"><Donut value={p} size={110} tone={p >= 70 ? "ok" : "warn"} sub="score" /></div><div className="mt-3 text-[22px] font-bold">{score} / {qs.length} correct</div><p className="mt-1 text-[13.5px] text-mute">{p === 100 ? "Perfect! Brilliant work." : p >= 70 ? "Great job! You have a solid understanding." : "Good effort — review the explanations below and try again."}</p></Card>
          <Segmented value={review} onChange={setReview} options={[{ value: "all", label: `All (${qs.length})` }, { value: "wrong", label: `Mistakes (${wrong.length})` }]} />
          {(review === "all" ? qs : wrong).length === 0 ? <Empty title="No mistakes!" body="You answered everything correctly." /> : (review === "all" ? qs : wrong).map((q, n) => { const ok = ans[q.id] === q.answer; return <Card key={q.id}><div className="flex items-start gap-2"><Badge tone={ok ? "ok" : "bad"}>{ok ? "Correct" : ans[q.id] === undefined ? "Skipped" : "Incorrect"}</Badge><span className="text-[12px] text-mute">{q.topic}</span></div><p className="mt-2 text-[14.5px] font-semibold leading-snug">{n + 1}. {q.q}</p><div className="mt-2 space-y-1 text-[13px]">{ans[q.id] !== undefined && !ok ? <div className="text-bad">Your answer: {q.options[ans[q.id]]}</div> : null}<div className="text-ok">Correct answer: {q.options[q.answer]}</div></div><div className="mt-2 rounded-lg bg-brand-soft p-2.5 text-[12.5px] leading-snug text-brand"><b>Why:</b> {q.explanation}</div></Card>; })}
          <Btn variant="ghost" onClick={() => push("S67")}>See my progress</Btn></div>
      </Page>
    );
  }
  const q = qs[i];
  return (
    <Page title={params.topic ?? params.chapter ?? q.subject} subtitle={`Question ${i + 1} of ${qs.length}`} footer={<div className="flex gap-2"><Btn variant="secondary" icon={ChevronLeft} disabled={i === 0} onClick={() => setI(i - 1)}>Previous</Btn>{i < qs.length - 1 ? <Btn disabled={ans[q.id] === undefined} onClick={() => setI(i + 1)}>Next<ChevronRight size={18} /></Btn> : <Btn onClick={submit}>Submit</Btn>}</div>}>
      <div className="pt-2"><Progress value={((i + 1) / qs.length) * 100} label="Quiz progress" /><div className="mt-5"><Badge tone="brand">{q.topic}</Badge><h2 className="mt-3 text-[19px] font-bold leading-snug">{q.q}</h2></div>
        <div className="mt-5 space-y-2.5" role="radiogroup" aria-label="Answer choices">{q.options.map((o, k) => <button key={k} role="radio" aria-checked={ans[q.id] === k} onClick={() => setAns({ ...ans, [q.id]: k })} className={`flex min-h-14 w-full items-center gap-3 rounded-2xl border-2 px-4 py-3 text-left text-[15px] ${ans[q.id] === k ? "border-brand bg-brand-soft font-semibold text-brand" : "border-line bg-white"}`}><span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-[12px] font-bold ${ans[q.id] === k ? "bg-brand text-white" : "bg-slate-100 text-mute"}`}>{String.fromCharCode(65 + k)}</span>{o}</button>)}</div>
        <div className="mt-5 flex flex-wrap justify-center gap-1.5">{qs.map((x, k) => <button key={x.id} aria-label={`Go to question ${k + 1}`} onClick={() => setI(k)} className={`h-8 w-8 rounded-lg text-[12px] font-semibold ${k === i ? "bg-brand text-white" : ans[x.id] !== undefined ? "bg-brand-soft text-brand" : "bg-slate-100 text-mute"}`}>{k + 1}</button>)}</div></div>
    </Page>
  );
}

/* S67 */
function MyProgress(_: P) {
  const { sc, st, batch } = useS();
  const { push } = useApp();
  const rs = resultsFor(sc.db, st.id);
  const subjects = Object.keys(batch?.subjectTeachers ?? {});
  const subj = subjects.map((s) => { const x = rs.filter((r) => r.exam.subject === s); return { s, v: x.length ? Math.round(x.reduce((a, r) => a + r.pct, 0) / x.length) : null }; });
  const timeline = rs.slice().reverse();
  const strengths = subj.filter((x) => x.v !== null && x.v >= 75);
  const practise = subj.filter((x) => x.v !== null && x.v < 75);
  const weeks = [4, 3, 2, 1, 0].map((w) => { const a = studentAtt(sc.db, st.id, addDays(-(w * 7 + 6)), addDays(-w * 7)); return { label: w === 0 ? "This wk" : `${w}w ago`, value: a.pct, tone: "ok" as Tone }; });
  const att = sc.db.attempts.filter((a) => a.studentId === st.id);
  return (
    <Page title="My progress" subtitle="Your learning journey">
      {rs.length === 0 ? <Empty icon={Trophy} title="Progress will show here" body="Once your first results are published you'll see trends and tips." /> : <div className="space-y-3 pt-2">
        <Section title="Test performance over time"><Card><LineChart points={timeline.map((r) => r.pct)} labels={timeline.map((r) => dmy(r.exam.date).slice(0, 5))} min={0} max={100} /><p className="mt-2 text-[12px] text-mute">Each point is one of your published tests (percentage).</p></Card></Section>
        <Section title="Subject-wise progress"><Card className="space-y-3">{subj.map((x) => <div key={x.s}><div className="flex justify-between text-[13px]"><b>{x.s}</b><span className="text-mute">{x.v === null ? "No result yet" : `${x.v}%`}</span></div><div className="mt-1.5"><Progress value={x.v ?? 0} tone="violet" height={7} label={x.s} /></div></div>)}</Card></Section>
        <Section title="Attendance trend"><Card><Bars data={weeks} max={100} height={70} suffix="%" /></Card></Section>
        <Section title="Your strengths">{strengths.length ? <Card><div className="flex flex-wrap gap-2">{strengths.map((x) => <Badge key={x.s} tone="ok" icon={Sparkles}>{x.s} · {x.v}%</Badge>)}</div><p className="mt-2 text-[12.5px] text-mute">You're doing well here — keep it up!</p></Card> : <Card><p className="text-[13px] text-mute">Keep practising — your strengths will show up as you progress.</p></Card>}</Section>
        <Section title="Areas to practise">{practise.length ? <List>{practise.map((x) => <Row key={x.s} icon={Dumbbell} tone="sky" title={x.s} sub="A little practice here can make a big difference" onClick={() => push("S65")} />)}</List> : <Card><p className="text-[13px] text-mute">Nothing needs special attention right now.</p></Card>}</Section>
        <Card><Kv k="Practice sessions" v={att.length} /><Kv k="Questions answered" v={att.reduce((a, x) => a + x.total, 0)} /></Card></div>}
    </Page>
  );
}

/* S68 */
function Library(_: P) {
  const { sc, st } = useS();
  const { push } = useApp();
  const [q, setQ] = useState("");
  const [tab, setTab] = useState("all");
  const [subj, setSubj] = useState("All");
  const [chap, setChap] = useState("All");
  const [type, setType] = useState("All");
  const mine = sc.resources.filter((r) => r.batchIds.includes(st.batchId));
  const list = mine.filter((r) => (tab === "all" || (tab === "bm" && r.bookmarked) || (tab === "recent" && r.recent)) && (subj === "All" || r.subject === subj) && (chap === "All" || r.chapter === chap) && (type === "All" || r.type === type) && r.title.toLowerCase().includes(q.toLowerCase()));
  const icon = (t: Resource["type"]) => (t === "link" ? Link2 : t === "image" ? ImageIcon : FileText);
  return (
    <Page title="Learning library">
      <div className="pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search notes, PDFs, links" /><Tabs value={tab} onChange={setTab} options={[{ value: "all", label: "All" }, { value: "bm", label: "Bookmarks", count: mine.filter((r) => r.bookmarked).length }, { value: "recent", label: "Recently opened" }]} />
        <Chips value={subj} onChange={(v) => { setSubj(v); setChap("All"); }} options={["All", ...Array.from(new Set(mine.map((r) => r.subject)))]} />{subj !== "All" ? <Chips value={chap} onChange={setChap} options={["All", ...Array.from(new Set(mine.filter((r) => r.subject === subj).map((r) => r.chapter)))]} /> : null}<Chips value={type} onChange={setType} options={[{ value: "All", label: "All types" }, { value: "pdf", label: "PDF" }, { value: "doc", label: "Docs" }, { value: "image", label: "Images" }, { value: "link", label: "Links" }]} /></div>
      {list.length ? <div className="mt-2"><List>{list.map((r) => { const I = icon(r.type); return <Row key={r.id} lead={<span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand"><I size={20} /></span>} title={r.title} sub={`${r.subject} · ${r.chapter}${r.size ? ` · ${fileSize(r.size)}` : ""}`} right={<IconBtn icon={Bookmark} label={r.bookmarked ? "Remove bookmark" : "Bookmark"} tone={r.bookmarked ? "soft" : "plain"} onClick={() => uc.toggleBookmark(r.id)} />} onClick={() => push("S69", { id: r.id })} noChevron />; })}</List></div> : <Empty icon={BookOpen} title={tab === "bm" ? "No bookmarks yet" : tab === "recent" ? "Nothing opened yet" : "No resources found"} body="Try a different filter or search." />}
      <p className="mt-4 px-2 text-center text-[11.5px] text-mute">Offline downloads aren't available in this version.</p>
    </Page>
  );
}

/* S69 */
function ResourceReader({ params }: P) {
  const { sc, st } = useS();
  const { toast } = useApp();
  const mine = sc.resources.filter((r) => r.batchIds.includes(st.batchId));
  const r = mine.find((x) => x.id === params.id) ?? mine[0];
  const [seen, setSeen] = useState("");
  if (r && seen !== r.id) { setSeen(r.id); uc.openResource(r.id); }
  if (!r) return <Page title="Resource"><Empty title="Resource not available" /></Page>;
  return (
    <Page title={r.type === "link" ? "Link" : "Reader"} subtitle={r.subject} right={<IconBtn icon={Bookmark} label={r.bookmarked ? "Remove bookmark" : "Bookmark"} tone={r.bookmarked ? "soft" : "plain"} onClick={() => uc.toggleBookmark(r.id)} />}>
      <div className="space-y-3 pt-2"><h2 className="text-[19px] font-bold leading-snug">{r.title}</h2>
        {r.type === "image" ? <div className="grid h-60 place-items-center rounded-2xl bg-gradient-to-br from-sky-soft to-violet-soft"><div className="text-center"><ImageIcon className="mx-auto text-sky" size={36} /><div className="mt-2 text-[13px] font-semibold">Image preview</div><div className="text-[12px] text-mute">Sample placeholder</div></div></div>
          : r.type === "link" ? <Card><div className="flex items-center gap-3"><IconTile icon={Link2} tone="sky" /><div className="min-w-0 text-[13px]"><div className="font-semibold">Opens outside GuruFlow</div><div className="truncate text-mute">{r.url}</div></div></div><div className="mt-3"><Btn onClick={() => window.open(r.url, "_blank", "noopener,noreferrer")}>Open link</Btn></div></Card>
          : <div className="rounded-2xl bg-slate-100 p-4"><div className="mx-auto h-64 max-w-[260px] rounded-lg bg-white p-5 shadow"><div className="h-3.5 w-2/3 rounded bg-slate-300" /><div className="mt-4 space-y-2">{Array.from({ length: 11 }).map((_, i) => <div key={i} className="h-1.5 rounded bg-slate-200" style={{ width: `${96 - (i % 4) * 11}%` }} />)}</div></div><p className="mt-3 text-center text-[11.5px] text-mute">Sample preview — real document viewing arrives with cloud storage.</p></div>}
        <Card><Kv k="Subject" v={r.subject} /><Kv k="Chapter" v={r.chapter} /><Kv k="Shared by" v={r.by} /><Kv k="Type" v={r.type.toUpperCase()} />{r.size ? <Kv k="File size" v={fileSize(r.size)} /> : null}<Kv k="Added" v={dmy(r.at.slice(0, 10))} /></Card>
        {r.type !== "link" ? <Btn variant="secondary" icon={Download} onClick={() => toast("Offline download isn't available in this version", "info")}>Download for offline</Btn> : null}</div>
    </Page>
  );
}

/* S70 */
function AskTeacher({ params }: P) {
  const { sc, st, batch } = useS();
  const { toast, push } = useApp();
  const [tab, setTab] = useState("ask");
  const [reply, setReply] = useState("");
  const [img, setImg] = useState<import("@/domain/types").FileMeta | null>(null);
  const subjects = Object.keys(batch?.subjectTeachers ?? {});
  const f = useForm({ subject: "", title: "", text: "" }, (v) => ({ subject: v.subject ? undefined : "Choose a subject", title: v.title.trim().length < 5 ? "Add a short title" : undefined, text: v.text.trim().length < 10 ? "Describe your doubt (10+ characters)" : undefined }));
  const mine = sc.doubts.filter((d) => d.studentId === st.id);
  const tid = batch?.subjectTeachers[f.v.subject];
  if (params.id) {
    const d = mine.find((x) => x.id === params.id);
    if (!d) return <Page title="Doubt"><Empty title="Doubt not found" /></Page>;
    return (
      <Page title="Your doubt" subtitle={`${d.subject} · ${sc.staff.find((t) => t.id === d.teacherId)?.name}`} footer={d.status !== "resolved" ? <div className="flex gap-2"><div className="flex-1"><TextInput value={reply} onChange={setReply} placeholder="Write a message…" /></div><Btn full={false} icon={Send} disabled={!reply.trim()} label="Send" onClick={async () => { await uc.replyDoubt(d.id, "student", reply.trim()); setReply(""); }}>Send</Btn></div> : undefined}>
        <div className="space-y-3 pt-2"><Card><div className="flex items-start justify-between gap-2"><div className="text-[15px] font-semibold leading-snug">{d.title}</div><StatusBadge status={d.status} /></div></Card><Chat msgs={d.messages} me="student" />{d.status === "answered" ? <Btn variant="secondary" size="sm" icon={Check} onClick={() => uc.resolveDoubt(d.id)}>Mark as resolved</Btn> : null}</div>
      </Page>
    );
  }
  return (
    <Page title="Ask your teacher">
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "ask", label: "Ask a doubt" }, { value: "mine", label: "My doubts", count: mine.length }]} /></div>
      {tab === "ask" ? <div className="mt-3 space-y-4"><Select label="Subject" required options={subjects} {...f.bind("subject")} />{tid ? <Card className="!p-3"><div className="flex items-center gap-3"><Avatar name={sc.staff.find((t) => t.id === tid)?.name ?? ""} tone="violet" /><div className="text-[13px]">Goes to <b>{sc.staff.find((t) => t.id === tid)?.name}</b></div></div></Card> : null}<TextInput label="Title" required placeholder="e.g. Step 3 of Question 7" {...f.bind("title")} /><TextInput label="Your question" required multiline rows={4} {...f.bind("text")} /><FilePicker label="Photo of your work" accept="image/*" value={img} onChange={setImg} />
        <Btn disabled={!f.valid || !tid} onClick={async () => { const id = await uc.askDoubt({ inst: sc.instId, studentId: st.id, subject: f.v.subject, teacherId: tid!, batchId: st.batchId, title: f.v.title.trim(), text: f.v.text.trim(), hasImage: !!img }); toast("Doubt sent to your teacher"); f.setV({ subject: "", title: "", text: "" }); setImg(null); push("S70", { id }); }}>Send to teacher</Btn></div>
        : mine.length ? <div className="mt-3 space-y-2.5">{mine.map((d) => <Card key={d.id} onClick={() => push("S70", { id: d.id })}><div className="flex items-start gap-3"><IconTile icon={MessageCircleQuestion} tone="sky" /><div className="min-w-0 flex-1"><div className="text-[14.5px] font-semibold leading-snug">{d.title}</div><div className="text-[12.5px] text-mute">{d.subject} · {ago(d.messages[d.messages.length - 1].at)}</div></div><StatusBadge status={d.status} /></div></Card>)}</div> : <Empty icon={MessageCircleQuestion} title="No doubts yet" body="Ask your teacher anything — they'll reply here." action="Ask a doubt" onAction={() => setTab("ask")} />}
    </Page>
  );
}

/* S71 */
function Achievements(_: P) {
  const { sc, st, batch, me } = useS();
  const { push, signOut, confirm } = useApp();
  const db = sc.db;
  const att = studentAtt(db, st.id, addDays(-30));
  const done = sc.homework.filter((h) => h.batchId === st.batchId && ["submitted", "reviewed"].includes(subFor(db, h, st.id).status)).length;
  const attempts = db.attempts.filter((a) => a.studentId === st.id);
  const goals = db.tasks.filter((t) => t.studentId === st.id && t.kind === "goal");
  const ms = [
    { t: "First practice session", d: "Completed your first practice quiz", ok: attempts.length >= 1, icon: Dumbbell },
    { t: "Practice regular", d: "Finished 3 practice sessions", ok: attempts.length >= 3, icon: Target },
    { t: "Homework helper", d: "Submitted 3 pieces of homework", ok: done >= 3, icon: ClipboardList },
    { t: "Steady attendance", d: "90%+ attendance in the last 30 days", ok: att.pct >= 90, icon: CheckCircle2 },
    { t: "Strong score", d: "Scored 80%+ in a test", ok: resultsFor(db, st.id).some((r) => r.pct >= 80), icon: Award },
    { t: "Set a goal", d: "Added a goal to your planner", ok: goals.length > 0, icon: Sparkles },
  ];
  const guardian = sc.guardians.find((g) => g.studentId === st.id);
  return (
    <Page title="Milestones & profile">
      <div className="space-y-3 pt-2"><Card><div className="flex items-center gap-3"><Avatar name={st.name} size={58} /><div className="min-w-0 flex-1"><div className="text-[18px] font-bold">{st.name}</div><div className="text-[12.5px] text-mute">{st.sid} · {bShort(batch?.name)}</div></div></div></Card>
        <Section title={`Your milestones · ${ms.filter((m) => m.ok).length}/${ms.length}`}><div className="grid grid-cols-2 gap-3">{ms.map((m) => <div key={m.t} className={`rounded-2xl border p-3.5 ${m.ok ? "border-ok/30 bg-ok-soft" : "border-line bg-white"}`}><div className="flex items-center justify-between"><m.icon size={22} className={m.ok ? "text-ok" : "text-slate-400"} />{m.ok ? <Badge tone="ok">Done</Badge> : <Lock size={14} className="text-slate-400" />}</div><div className="mt-2 text-[13.5px] font-semibold leading-snug">{m.t}</div><div className="mt-0.5 text-[11.5px] leading-snug text-mute">{m.d}</div></div>)}</div></Section>
        <Section title="Completed goals">{goals.filter((g) => g.done).length ? <List>{goals.filter((g) => g.done).map((g) => <Row key={g.id} icon={Target} tone="ok" title={g.title} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">Finished goals will appear here. Set one in your planner.</p><div className="mt-2"><Btn variant="soft" size="sm" onClick={() => push("S64")}>Open planner</Btn></div></Card>}</Section>
        <Section title="Account"><Card><Kv k="Institute" v={sc.inst.name} /><Kv k="Batch" v={batch?.name} /><Kv k="Guardian" v={guardian?.name ?? "—"} /><Kv k="Signed in as" v={me.name} /></Card></Section>
        <List><Row icon={Settings} title="Preferences & privacy" onClick={() => push("S14")} /><Row icon={Users} title="Account profile" onClick={() => push("S13")} /><Row icon={LogOut} tone="bad" title="Sign out" noChevron onClick={() => confirm({ title: "Sign out?", confirmLabel: "Sign out", danger: true, onConfirm: signOut })} /></List></div>
    </Page>
  );
}

export const studentScreens: ScreenMap = {
  S56: def("Student Home / My Day", "student", StudentHome), S57: def("Timetable / Class Detail", "student", StudentTimetable), S58: def("My Attendance", "student", MyAttendance), S59: def("Homework List", "student", StudentHomework),
  S60: def("Homework Detail / Submission", "student", HomeworkDetail), S61: def("Homework Feedback", "student", HomeworkFeedback), S62: def("Exams / Exam Schedule", "student", ExamsSchedule), S63: def("My Results", "student", MyResults),
  S64: def("Study Planner", "student", Planner), S65: def("Practice Zone", "student", PracticeZone), S66: def("Quiz Attempt / Results / Mistake Review", "student", Quiz), S67: def("My Progress", "student", MyProgress),
  S68: def("Learning Library", "student", Library), S69: def("Resource Detail / Reader", "student", ResourceReader), S70: def("Ask Your Teacher / Doubt Detail", "student", AskTeacher), S71: def("Achievements / Milestones / Profile", "student", Achievements),
};
export type { Homework };
export { Checkbox, validPhone, DAYS, DAYS_LONG, nowISO, Chat };
