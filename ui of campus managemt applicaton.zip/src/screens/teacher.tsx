"use client";
import React, { useMemo, useState } from "react";
import { Bell, BookOpen, Bookmark, CalendarDays, CheckCheck, ClipboardList, Clock, FileText, GraduationCap, HelpCircle, LogOut, MessageCircleQuestion, Plus, Send, Settings, UserCheck, Users, Search, Megaphone, Check, Undo2 } from "lucide-react";
import type { AttStatus, Homework, Notice, Submission } from "@/domain/types";
import { useApp, useMe, useNav, useScope } from "@/state/app";
import { Avatar, Badge, Banner, Btn, Card, Chips, Denied, Empty, IconBtn, IconTile, Kv, List, Page, Progress, Row, Section, Segmented, Sheet, Stat, Tabs, Tone } from "@/ui/kit";
import { DatePicker, FileItem, FilePicker, Select, SearchInput, TextInput, useForm } from "@/ui/forms";
import { ATT_META, AttPill, Donut, MonthCalendar } from "@/ui/charts";
import { HomeworkCard, NoticeCard, NotificationItem, StatusBadge, StudentCard } from "@/ui/cards";
import { HomeFrame, useNotifs } from "./common";
import { resolveDest } from "./shared-core";
import { ResourceViewer } from "./owner-b";
import { def, P, ScreenMap } from "./types";
import { addDays, ago, dmy, DAYS, DAYS_LONG, dtLabel, fileSize, iso, longDate, nowISO, pct, relDay, time12, today, uid, MONTHS_LONG } from "@/lib/fmt";
import { batchAttOn, can, classStatus, examStats, hwCounts, noticeVisible, resultsFor, studentAtt, subFor, teacherBatches, teacherSubjects } from "@/features/selectors";
import { uc } from "@/features/usecases";

function useT() {
  const sc = useScope();
  const me = useMe();
  const t = me.teacher;
  const batches = useMemo(() => teacherBatches(sc, t?.id), [sc, t?.id]);
  const students = useMemo(() => sc.students.filter((s) => batches.some((b) => b.id === s.batchId) && s.status === "active"), [sc.students, batches]);
  return { sc, t, batches, students, me };
}
const bShort = (n?: string) => n?.split(" – ")[0] ?? "";

/* S42 */
function TeacherHome(_: P) {
  const { sc, t, batches, students } = useT();
  const me = useMe();
  const { push, session } = useApp();
  const dow = new Date().getDay();
  const todays = sc.timetable.filter((e) => e.teacherId === t?.id && e.day === dow).sort((a, b) => (a.start < b.start ? -1 : 1));
  const next = todays.find((e) => classStatus(e) !== "Completed");
  const pendAtt = batches.filter((b) => todays.some((e) => e.batchId === b.id) || true).filter((b) => { const r = batchAttOn(sc.db, b.id, today()); return r.marked < r.total; });
  const toReview = sc.homework.filter((h) => h.teacherId === t?.id).reduce((a, h) => a + hwCounts(sc.db, h).toReview, 0);
  const pendMarks = sc.exams.filter((x) => batches.some((b) => b.id === x.batchId && b.subjectTeachers[x.subject] === t?.id) && (x.status === "completed" || (x.status === "scheduled" && x.date < today())) && examStats(sc.db, x).missing > 0);
  const doubts = sc.doubts.filter((d) => d.teacherId === t?.id && d.status === "open");
  const notices = sc.notices.filter((n) => noticeVisible(n, "teacher", me.batchIds)).sort((a, b) => (a.publishAt < b.publishAt ? 1 : -1)).slice(0, 2);
  const h = new Date().getHours();
  return (
    <HomeFrame greeting={`${h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"}, ${me.first}`} sub={`${longDate(today())} · ${dmy(today())}`}>
      {next ? <Card onClick={() => push("S45", { batchId: next.batchId, subject: next.subject })} className="!bg-white"><div className="flex items-center justify-between"><Badge tone={classStatus(next) === "Ongoing" ? "ok" : "brand"}>{classStatus(next) === "Ongoing" ? "Ongoing now" : "Next class"}</Badge><span className="text-[12.5px] font-semibold text-mute">{time12(next.start)} – {time12(next.end)}</span></div><div className="mt-2 text-[19px] font-bold">{next.subject}</div><div className="text-[13px] text-mute">{bShort(sc.batches.find((b) => b.id === next.batchId)?.name)} · {sc.rooms.find((r) => r.id === next.roomId)?.name}</div></Card> : <Card><div className="text-[15px] font-semibold">{todays.length ? "All of today's classes are done 🎉" : "No classes scheduled today"}</div><p className="mt-1 text-[13px] text-mute">Use the time to review homework or enter marks.</p></Card>}
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Stat label="Attendance pending" value={pendAtt.length} sub="batches today" tone={pendAtt.length ? "warn" : "ok"} icon={UserCheck} onClick={() => push("S46")} />
        <Stat label="Homework to review" value={toReview} tone="sky" icon={ClipboardList} onClick={() => push("S47", { tab: "review" })} />
        <Stat label="Marks pending" value={pendMarks.length} tone="violet" icon={GraduationCap} onClick={() => push("S50")} />
        <Stat label="New doubts" value={doubts.length} tone="sky" icon={MessageCircleQuestion} onClick={() => push("S53")} />
      </div>
      <Section title="Quick actions"><div className="grid grid-cols-4 gap-2">{[{ i: UserCheck, l: "Attendance", to: "S46" }, { i: Plus, l: "Homework", to: "S48" }, { i: GraduationCap, l: "Marks", to: "S50" }, { i: Users, l: "Students", to: "S51" }].map((a) => <button key={a.l} onClick={() => push(a.to)} className="flex min-h-[74px] flex-col items-center justify-center gap-1.5 rounded-2xl border border-line bg-white active:bg-slate-50"><a.i size={20} className="text-brand" /><span className="text-[11.5px] font-medium">{a.l}</span></button>)}</div></Section>
      <Section title="Today's timetable" action="Week" onAction={() => push("S43")}>{todays.length ? <List>{todays.map((e) => <Row key={e.id} icon={Clock} tone={classStatus(e) === "Completed" ? "mute" : "brand"} title={`${e.subject} · ${bShort(sc.batches.find((b) => b.id === e.batchId)?.name)}`} sub={`${time12(e.start)} – ${time12(e.end)} · ${sc.rooms.find((r) => r.id === e.roomId)?.name}`} right={<StatusBadge status={classStatus(e) === "Completed" ? "completed" : classStatus(e) === "Ongoing" ? "active" : "scheduled"} text={classStatus(e)} />} onClick={() => push("S45", { batchId: e.batchId, subject: e.subject })} />)}</List> : <Card><p className="text-[13.5px] text-mute">Nothing scheduled.</p></Card>}</Section>
      <Section title="My batches" action="All classes" onAction={() => push("S44")}><div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4">{batches.map((b) => <button key={b.id} onClick={() => push("S45", { batchId: b.id })} className="w-[160px] shrink-0 rounded-2xl border border-line bg-white p-3.5 text-left active:bg-slate-50"><IconTile icon={BookOpen} /><div className="mt-2 text-[14px] font-semibold leading-snug">{bShort(b.name)}</div><div className="text-[12px] text-mute">{teacherSubjects(b, t?.id).join(", ")} · {students.filter((s) => s.batchId === b.id).length} students</div></button>)}</div></Section>
      <Section title="Notices" action="See all" onAction={() => push("S55")}><div className="space-y-2.5">{notices.map((n) => <NoticeCard key={n.id} n={n} read={n.readBy.includes(session.role)} onClick={() => push("S55", { id: n.id })} />)}</div></Section>
    </HomeFrame>
  );
}

/* S43 */
function TeacherTimetable(_: P) {
  const { sc, t } = useT();
  const { push } = useApp();
  const [v, setV] = useState<"today" | "week">("today");
  const dow = new Date().getDay();
  const mine = sc.timetable.filter((e) => e.teacherId === t?.id).sort((a, b) => (a.start < b.start ? -1 : 1));
  const row = (e: (typeof mine)[number], withStatus: boolean) => <Row key={e.id} icon={Clock} tone={withStatus && classStatus(e) === "Completed" ? "mute" : "brand"} title={e.subject} sub={`${time12(e.start)} – ${time12(e.end)} · ${bShort(sc.batches.find((b) => b.id === e.batchId)?.name)} · ${sc.rooms.find((r) => r.id === e.roomId)?.name}`} right={withStatus ? <StatusBadge status={classStatus(e) === "Completed" ? "completed" : classStatus(e) === "Ongoing" ? "active" : "scheduled"} text={classStatus(e)} /> : undefined} onClick={() => push("S45", { batchId: e.batchId, subject: e.subject })} />;
  return (
    <Page title="My timetable" subtitle={t?.name}>
      <div className="pt-2"><Segmented value={v} onChange={setV} options={[{ value: "today", label: "Today" }, { value: "week", label: "This week" }]} /></div>
      <div className="mt-3">{v === "today" ? (mine.filter((e) => e.day === dow).length ? <List>{mine.filter((e) => e.day === dow).map((e) => row(e, true))}</List> : <Empty icon={CalendarDays} title={dow === 0 ? "It's Sunday" : "No classes today"} body="Switch to the week view to see upcoming classes." action="View week" onAction={() => setV("week")} />) : [1, 2, 3, 4, 5, 6].map((d) => { const es = mine.filter((e) => e.day === d); return <div key={d} className="mb-3"><div className="mb-1.5 flex items-center gap-2 text-[13px] font-semibold">{DAYS_LONG[d]}{d === dow ? <Badge tone="brand">Today</Badge> : null}</div>{es.length ? <List>{es.map((e) => row(e, false))}</List> : <Card><p className="text-[13px] text-mute">No classes</p></Card>}</div>; })}</div>
    </Page>
  );
}

/* S44 */
function MyClasses(_: P) {
  const { sc, t, batches, students } = useT();
  const { push } = useApp();
  const [q, setQ] = useState("");
  const [sub, setSub] = useState("All");
  const subjects = Array.from(new Set(batches.flatMap((b) => teacherSubjects(b, t?.id))));
  const list = batches.filter((b) => (sub === "All" || teacherSubjects(b, t?.id).includes(sub)) && b.name.toLowerCase().includes(q.toLowerCase()));
  const nextOf = (id: string) => { const dow = new Date().getDay(); const es = sc.timetable.filter((e) => e.batchId === id && e.teacherId === t?.id).sort((a, b) => (a.day - dow + 7) % 7 - (b.day - dow + 7) % 7 || (a.start < b.start ? -1 : 1)); return es.find((e) => e.day !== dow || classStatus(e) !== "Completed") ?? es[0]; };
  return (
    <Page title="My classes" subtitle={`${batches.length} assigned batches`}>
      <div className="space-y-2 pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search batches" /><Chips value={sub} onChange={setSub} options={["All", ...subjects]} /></div>
      {list.length ? <div className="mt-2 space-y-2.5">{list.map((b) => { const n = nextOf(b.id); return <Card key={b.id} onClick={() => push("S45", { batchId: b.id })}><div className="flex items-start gap-3"><IconTile icon={BookOpen} /><div className="min-w-0 flex-1"><div className="text-[15px] font-semibold leading-snug">{b.name}</div><div className="mt-0.5 text-[12.5px] text-mute">{teacherSubjects(b, t?.id).join(", ")} · {students.filter((s) => s.batchId === b.id).length} students</div>{n ? <div className="mt-1.5 flex items-center gap-1 text-[12px] font-medium text-brand"><Clock size={12} />Next: {DAYS[n.day]} {time12(n.start)}</div> : null}</div><StatusBadge status={b.status} /></div></Card>; })}</div> : <Empty icon={BookOpen} title="No batches found" body="You'll see batches here once the owner assigns them to you." />}
    </Page>
  );
}

/* S45 */
function ClassDetail({ params }: P) {
  const { sc, t, batches, students } = useT();
  const { push, toast } = useApp();
  const b = batches.find((x) => x.id === params.batchId) ?? batches[0];
  const mySubs = b ? teacherSubjects(b, t?.id) : [];
  const [subject, setSubject] = useState<string>(params.subject ?? mySubs[0] ?? "");
  const f = useForm({ topic: "", notes: "" }, (v) => ({ topic: v.topic.trim().length < 3 ? "Enter today's topic" : undefined }));
  if (!b) return <Page title="Class"><Empty title="No class assigned" /></Page>;
  const roster = students.filter((s) => s.batchId === b.id);
  const diary = sc.diary.filter((d) => d.batchId === b.id && d.subject === subject).sort((a, c) => (a.date < c.date ? 1 : -1));
  const sched = sc.timetable.filter((e) => e.batchId === b.id && e.subject === subject);
  const res = sc.resources.filter((r) => r.batchIds.includes(b.id) && r.subject === subject);
  return (
    <Page title={bShort(b.name)} subtitle={b.course}>
      <div className="space-y-3 pt-2">
        {mySubs.length > 1 ? <Chips value={subject} onChange={setSubject} options={mySubs} /> : null}
        <Card><div className="flex items-center justify-between"><div><div className="text-[18px] font-bold">{subject}</div><div className="text-[12.5px] text-mute">{roster.length} students · {sc.rooms.find((r) => r.id === b.roomId)?.name}</div></div><Donut value={pct(roster.length ? batchAttOn(sc.db, b.id, today()).p + batchAttOn(sc.db, b.id, today()).l : 0, Math.max(batchAttOn(sc.db, b.id, today()).marked, 1))} size={66} sub="today" tone="ok" /></div>
          <div className="mt-3 flex flex-wrap gap-1.5">{sched.sort((a, c) => a.day - c.day).map((e) => <Badge key={e.id} tone="brand">{DAYS[e.day]} {time12(e.start)}</Badge>)}</div>
          <div className="mt-3 grid grid-cols-2 gap-2"><Btn size="sm" icon={UserCheck} onClick={() => push("S46", { batchId: b.id })}>Take attendance</Btn><Btn size="sm" variant="secondary" icon={Plus} onClick={() => push("S48", { batchId: b.id, subject })}>Assign homework</Btn></div></Card>
        <Section title="Today's class diary"><Card><div className="space-y-3"><TextInput label="Lesson topic" required placeholder="e.g. Nature of roots" {...f.bind("topic")} /><TextInput label="Notes" multiline rows={3} placeholder="What was covered? Anything to revise next class?" {...f.bind("notes")} /><Btn size="sm" disabled={!f.valid} onClick={async () => { await uc.save("diary", { id: uid("dy"), inst: sc.instId, batchId: b.id, subject, date: today(), topic: f.v.topic.trim(), notes: f.v.notes.trim(), by: t?.name ?? "" }); f.setV({ topic: "", notes: "" }); toast("Diary entry saved"); }}>Save diary entry</Btn></div></Card></Section>
        <Section title="Previous class notes">{diary.length ? <List>{diary.slice(0, 4).map((d) => <Row key={d.id} icon={FileText} title={d.topic} sub={<span className="whitespace-normal">{dmy(d.date)} · {d.notes || "No notes"}</span>} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No diary entries for this subject yet.</p></Card>}</Section>
        <Section title="Resources" action="All" onAction={() => push("S52")}>{res.length ? <List>{res.map((r) => <Row key={r.id} icon={BookOpen} title={r.title} sub={r.type.toUpperCase()} onClick={() => push("S52", { id: r.id })} />)}</List> : <Card><p className="text-[13px] text-mute">No resources shared for this subject.</p></Card>}</Section>
        <Section title={`Student roster (${roster.length})`}><div className="space-y-2">{roster.map((s) => <StudentCard key={s.id} s={s} right={<AttPill status={sc.db.attendance[`${today()}|${s.id}`]} />} onClick={() => push("S51", { id: s.id })} />)}</div></Section>
      </div>
    </Page>
  );
}

/* S46 */
function AttendanceMarking({ params }: P) {
  const { sc, t, batches } = useT();
  const { session, toast, confirm } = useApp();
  const [batchId, setBatchId] = useState<string>(params.batchId ?? batches[0]?.id ?? "");
  const [date, setDate] = useState<string>(params.date ?? today());
  const [marks, setMarks] = useState<Record<string, AttStatus | undefined>>({});
  const [loaded, setLoaded] = useState("");
  const [reasonSheet, setReasonSheet] = useState(false);
  const [reason, setReason] = useState("");
  const [saved, setSaved] = useState(false);
  const key = `${batchId}|${date}`;
  const cur = batchAttOn(sc.db, batchId, date);
  if (loaded !== key) { setLoaded(key); setMarks({ ...cur.rec }); setSaved(false); }
  if (!can(sc.db, session.role, "attendance.edit")) return <Page title="Attendance"><Denied body="Marking attendance is switched off for your role." /></Page>;
  if (!batches.length) return <Page title="Attendance"><Empty title="No batches assigned" /></Page>;
  const list = cur.students;
  const counts = { P: 0, A: 0, L: 0, none: 0 };
  list.forEach((s) => { const m = marks[s.id]; if (m) counts[m]++; else counts.none++; });
  const changedExisting = list.filter((s) => cur.rec[s.id] && marks[s.id] && cur.rec[s.id] !== marks[s.id]).length;
  const dirty = list.some((s) => marks[s.id] !== cur.rec[s.id]);
  const doSave = async (why?: string) => { const entries = Object.fromEntries(list.filter((s) => marks[s.id]).map((s) => [s.id, marks[s.id] as AttStatus])); const n = await uc.markAttendance({ inst: sc.instId, role: session.role, date, entries, by: t?.name ?? "Teacher", reason: why }); setSaved(true); toast(n ? `Attendance saved · ${n} change${n > 1 ? "s" : ""}` : "No changes to save", n ? "ok" : "info"); };
  const save = () => { if (changedExisting > 0) { setReason(""); setReasonSheet(true); } else confirm({ title: "Save attendance?", body: `${counts.P} present, ${counts.A} absent, ${counts.L} late. Parents of absent students are notified.`, confirmLabel: "Save", onConfirm: () => doSave() }); };
  return (
    <Page title="Attendance" subtitle={`${cur.marked}/${cur.total} saved for ${dmy(date)}`}
      footer={<div className="space-y-2"><div className="flex justify-between text-[12.5px]"><span><b className="text-ok">{counts.P}</b> Present</span><span><b className="text-bad">{counts.A}</b> Absent</span><span><b className="text-warn">{counts.L}</b> Late</span><span className="text-mute">{counts.none} unmarked</span></div><Btn disabled={counts.none > 0 || !dirty} onClick={save}>{changedExisting ? "Save correction" : "Save attendance"}</Btn></div>}>
      <div className="space-y-3 pt-1">
        <Select options={batches.map((b) => ({ value: b.id, label: b.name }))} value={batchId} onChange={setBatchId} /><DatePicker value={date} max={today()} onChange={(v) => v && setDate(v)} />
        {cur.marked > 0 ? <Banner tone="warn" icon={Undo2}>Attendance is already saved for this date. Changes will be recorded as corrections and need a reason.</Banner> : null}
        {saved && !dirty ? <Banner tone="ok" icon={Check}>Saved. Owner reports and verified parents now show this attendance.</Banner> : null}
        <Btn variant="soft" size="sm" icon={CheckCheck} onClick={() => setMarks(Object.fromEntries(list.map((s) => [s.id, "P" as AttStatus])))}>Mark all present</Btn>
        {list.length === 0 ? <Empty title="No active students" /> : <List>{list.map((s) => (
          <div key={s.id} className="flex items-center gap-3 px-4 py-3"><Avatar name={s.name} size={36} /><div className="min-w-0 flex-1"><div className="truncate text-[14.5px] font-medium">{s.name}</div><div className="text-[11.5px] text-mute">{s.sid}</div></div>
            <div className="flex gap-1.5" role="group" aria-label={`Attendance for ${s.name}`}>{(["P", "A", "L"] as AttStatus[]).map((k) => { const on = marks[s.id] === k; const tone = ATT_META[k].tone; return <button key={k} aria-label={ATT_META[k].label} aria-pressed={on} onClick={() => setMarks({ ...marks, [s.id]: k })} className={`grid h-11 w-11 place-items-center rounded-xl border text-[14px] font-bold ${on ? (tone === "ok" ? "border-ok bg-ok text-white" : tone === "bad" ? "border-bad bg-bad text-white" : "border-warn bg-warn text-white") : "border-line bg-white text-mute"}`}>{k}</button>; })}</div></div>))}</List>}
      </div>
      <Sheet open={reasonSheet} onClose={() => setReasonSheet(false)} title="Reason for correction"><div className="space-y-4"><p className="text-[13.5px] text-mute">{changedExisting} saved record(s) will change. This is logged for the owner.</p><Select label="Reason" required options={["Marked wrongly by mistake", "Student arrived late", "Parent informed in advance", "Medical reason", "Other"]} value={reason} onChange={setReason} /><Btn disabled={!reason} onClick={async () => { setReasonSheet(false); await doSave(reason); }}>Confirm correction</Btn></div></Sheet>
    </Page>
  );
}

/* S47 */
function HomeworkList({ params }: P) {
  const { sc, t, batches } = useT();
  const { push, session } = useApp();
  const [tab, setTab] = useState<string>(params.tab ?? "assigned");
  const [batch, setBatch] = useState("All");
  const [subj, setSubj] = useState("All");
  const [due, setDue] = useState("All");
  const [open, setOpen] = useState<Homework | null>(null);
  const mine = sc.homework.filter((h) => session.role === "owner" || batches.some((b) => b.id === h.batchId && b.subjectTeachers[h.subject] === t?.id));
  const subjects = Array.from(new Set(mine.map((h) => h.subject)));
  const cnt = (h: Homework) => hwCounts(sc.db, h);
  const base = mine.filter((h) => (batch === "All" || h.batchId === batch) && (subj === "All" || h.subject === subj) && (due === "All" || (due === "week" ? h.due >= today() && h.due <= addDays(7) : due === "past" ? h.due < today() : h.due >= today())));
  const lists: Record<string, Homework[]> = { assigned: base.filter((h) => h.status === "published"), review: base.filter((h) => cnt(h).toReview > 0), done: base.filter((h) => h.status === "published" && cnt(h).toReview === 0 && cnt(h).reviewed > 0), overdue: base.filter((h) => h.status === "published" && h.due < today() && cnt(h).missing > 0), draft: base.filter((h) => h.status === "draft") };
  const list = lists[tab] ?? [];
  return (
    <Page title="Homework" right={<IconBtn icon={Plus} label="Create homework" tone="soft" onClick={() => push("S48")} />}>
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "assigned", label: "Assigned" }, { value: "review", label: "To review", count: lists.review.length }, { value: "done", label: "Reviewed" }, { value: "overdue", label: "Overdue" }, { value: "draft", label: "Drafts" }]} /></div>
      <div className="mt-2 space-y-0.5"><Chips value={batch} onChange={setBatch} options={[{ value: "All", label: "All batches" }, ...batches.map((b) => ({ value: b.id, label: bShort(b.name) }))]} /><Chips value={subj} onChange={setSubj} options={["All", ...subjects]} /><Chips value={due} onChange={setDue} options={[{ value: "All", label: "Any due date" }, { value: "week", label: "Due this week" }, { value: "upcoming", label: "Upcoming" }, { value: "past", label: "Past due" }]} /></div>
      {list.length ? <div className="mt-2 space-y-2.5">{list.map((h) => { const c = cnt(h); return <HomeworkCard key={h.id} h={h} onClick={() => setOpen(h)} right={h.status === "draft" ? <StatusBadge status="draft" /> : <Badge tone={c.toReview ? "warn" : "ok"}>{c.toReview ? `${c.toReview} to review` : "Up to date"}</Badge>} extra={h.status === "published" ? <div className="mt-2"><Progress value={pct(c.submitted + c.reviewed + c.returned, c.total)} tone="sky" height={5} /><div className="mt-1 text-[11.5px] text-mute">{c.submitted + c.reviewed + c.returned}/{c.total} submitted · {sc.batches.find((b) => b.id === h.batchId)?.name.split(" – ")[0]}</div></div> : undefined} />; })}</div> : <Empty icon={ClipboardList} title="Nothing here" body="No homework matches this view." action="Create homework" onAction={() => push("S48")} />}
      <Sheet open={!!open} onClose={() => setOpen(null)} title={open?.title}>{open ? <div className="space-y-3"><div className="text-[12.5px] text-mute">{open.subject} · due {dmy(open.due)}</div>
        <List>{sc.students.filter((s) => s.batchId === open.batchId && s.status === "active").map((s) => { const x = subFor(sc.db, open, s.id); return <Row key={s.id} lead={<Avatar name={s.name} size={36} />} title={s.name} right={<StatusBadge status={x.status} />} onClick={x.sub && x.sub.status !== "pending" ? () => { setOpen(null); push("S49", { id: x.sub!.id }); } : undefined} noChevron={!(x.sub && x.sub.status !== "pending")} />; })}</List>
        <Btn variant="secondary" onClick={() => { push("S48", { id: open.id }); setOpen(null); }}>Edit homework</Btn></div> : null}</Sheet>
    </Page>
  );
}

/* S48 */
function HomeworkForm({ params }: P) {
  const { sc, t, batches } = useT();
  const { session, back, toast } = useApp();
  const ex = sc.homework.find((h) => h.id === params.id);
  const bs = session.role === "owner" ? sc.batches : batches;
  const [file, setFile] = useState(ex?.attachment ?? null);
  const [loading, setLoading] = useState(false);
  const f = useForm({ title: ex?.title ?? "", batchId: ex?.batchId ?? params.batchId ?? "", subject: ex?.subject ?? params.subject ?? "", instructions: ex?.instructions ?? "", due: ex?.due ?? "", max: String(ex?.max ?? 20) }, (v) => ({
    title: v.title.trim().length < 4 ? "Enter a title (at least 4 characters)" : undefined, batchId: v.batchId ? undefined : "Choose a batch", subject: v.subject ? undefined : "Choose a subject", instructions: v.instructions.trim().length < 10 ? "Add clear instructions (10+ characters)" : undefined,
    due: !v.due ? "Pick a due date" : v.due < today() ? "Due date can't be in the past" : undefined, max: Number(v.max) >= 0 && Number(v.max) <= 100 ? undefined : "Marks must be between 0 and 100",
  }));
  const b = sc.batches.find((x) => x.id === f.v.batchId);
  const subs = b ? (session.role === "owner" ? Object.keys(b.subjectTeachers) : teacherSubjects(b, t?.id)) : [];
  const save = async (status: "draft" | "published") => {
    f.touchAll(); if (!f.valid) return; setLoading(true);
    const h: Homework = { id: ex?.id ?? uid("h"), inst: sc.instId, title: f.v.title.trim(), subject: f.v.subject, batchId: f.v.batchId, teacherId: b?.subjectTeachers[f.v.subject] ?? t?.id ?? "", instructions: f.v.instructions.trim(), due: f.v.due, max: Number(f.v.max), status, attachment: file ?? undefined, createdAt: ex?.createdAt ?? nowISO() };
    await uc.saveHomework(h); setLoading(false); toast(status === "draft" ? "Draft saved" : "Homework published to students and parents"); back();
  };
  return (
    <Page title={ex ? "Edit homework" : "New homework"} footer={<div className="flex gap-2"><Btn variant="secondary" loading={loading} disabled={!f.valid} onClick={() => save("draft")}>Save draft</Btn><Btn loading={loading} disabled={!f.valid} onClick={() => save("published")}>Publish</Btn></div>}>
      <div className="space-y-4 pt-2"><TextInput label="Title" required placeholder="e.g. Quadratic Equations Worksheet 5" {...f.bind("title")} />
        <Select label="Batch" required options={bs.map((x) => ({ value: x.id, label: x.name }))} value={f.v.batchId} onChange={(v) => f.setV({ ...f.v, batchId: v, subject: "" })} />
        <Select label="Subject" required options={subs} value={f.v.subject} onChange={(v) => f.set("subject", v)} placeholder={b ? "Select subject" : "Choose a batch first"} />
        <TextInput label="Instructions" required multiline rows={4} {...f.bind("instructions")} />
        <FilePicker label="Attachment" value={file} onChange={setFile} />
        <div className="grid grid-cols-2 gap-3"><DatePicker label="Due date" required min={today()} value={f.v.due} onChange={(v) => f.set("due", v)} error={f.v.due ? f.errors.due : undefined} /><TextInput label="Max marks" inputMode="numeric" {...f.bind("max")} /></div>
      </div>
    </Page>
  );
}

/* S49 */
function SubmissionReview({ params }: P) {
  const { sc, t } = useT();
  const { toast, back } = useApp();
  const mineHw = sc.homework.filter((h) => h.teacherId === t?.id).map((h) => h.id);
  const sub = sc.submissions.find((s) => s.id === params.id) ?? sc.submissions.find((s) => mineHw.includes(s.hwId) && s.status === "submitted");
  const hw = sub ? sc.homework.find((h) => h.id === sub.hwId) : undefined;
  const st = sub ? sc.students.find((s) => s.id === sub.studentId) : undefined;
  const f = useForm({ marks: sub?.marks !== undefined ? String(sub.marks) : "", feedback: sub?.feedback ?? "" }, (v) => ({ marks: hw && hw.max > 0 && (v.marks === "" || Number(v.marks) > hw.max || Number(v.marks) < 0) ? `Enter marks between 0 and ${hw.max}` : undefined }));
  if (!sub || !hw || !st) return <Page title="Review"><Empty icon={ClipboardList} title="Nothing to review" body="Submitted homework will appear here." /></Page>;
  const done = (status: "reviewed" | "returned") => uc.reviewSubmission({ id: sub.id, status, marks: hw.max > 0 ? Number(f.v.marks) : undefined, feedback: f.v.feedback.trim() }).then(() => { toast(status === "reviewed" ? "Marked as reviewed" : "Returned for correction"); back(); });
  return (
    <Page title="Review submission" footer={sub.status !== "pending" ? <div className="flex gap-2"><Btn variant="secondary" disabled={!f.v.feedback.trim()} onClick={() => done("returned")}>Return</Btn><Btn disabled={!f.valid} onClick={() => done("reviewed")}>Accept & save</Btn></div> : undefined}>
      <div className="space-y-3 pt-2">
        <Card><div className="flex items-center gap-3"><Avatar name={st.name} size={46} /><div className="min-w-0 flex-1"><div className="text-[16px] font-semibold">{st.name}</div><div className="text-[12.5px] text-mute">{st.sid}</div></div><StatusBadge status={sub.status} /></div></Card>
        <Card><div className="text-[15px] font-semibold">{hw.title}</div><div className="text-[12.5px] text-mute">{hw.subject} · due {dmy(hw.due)} · max {hw.max}</div><p className="mt-2 text-[13px] leading-relaxed text-mute">{hw.instructions}</p></Card>
        {sub.status === "pending" ? <Banner tone="warn">This student hasn't submitted yet.</Banner> : <>
          <Section title="Submission">{sub.file ? <FileItem file={sub.file} /> : null}{sub.text ? <Card className="mt-2"><p className="text-[13.5px]">{sub.text}</p></Card> : null}<p className="mt-2 text-[12px] text-mute">Submitted {sub.submittedAt ? dtLabel(sub.submittedAt) : "—"} · demo upload</p></Section>
          <Section title="Feedback"><div className="space-y-4">{hw.max > 0 ? <TextInput label={`Marks (out of ${hw.max})`} required inputMode="numeric" value={f.v.marks} onChange={(v) => f.set("marks", v.replace(/\D/g, ""))} error={f.v.marks ? f.errors.marks : undefined} /> : null}<TextInput label="Feedback for the student" multiline rows={3} placeholder="What went well? What should they fix?" value={f.v.feedback} onChange={(v) => f.set("feedback", v)} /></div></Section>
          <Section title="History"><Card><ol className="space-y-3">{sub.history.map((h, i) => <li key={i} className="flex gap-3 text-[13px]"><span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand" /><div>{h.text}<div className="text-[11.5px] text-mute">{dtLabel(h.at)}</div></div></li>)}</ol></Card></Section></>}
      </div>
    </Page>
  );
}

/* S50 */
function MarksEntry({ params }: P) {
  const { sc, t, batches } = useT();
  const { session, toast, confirm, back } = useApp();
  const exams = sc.exams.filter((x) => session.role === "owner" || batches.some((b) => b.id === x.batchId && b.subjectTeachers[x.subject] === t?.id)).filter((x) => x.status !== "draft");
  const [xid, setXid] = useState<string>(params.id ?? exams.find((x) => x.status === "completed")?.id ?? exams[0]?.id ?? "");
  const x = exams.find((e) => e.id === xid);
  const [vals, setVals] = useState<Record<string, string>>({});
  const [loaded, setLoaded] = useState("");
  const roster = x ? sc.students.filter((s) => s.batchId === x.batchId && s.status === "active") : [];
  if (x && loaded !== x.id) { setLoaded(x.id); setVals(Object.fromEntries(roster.map((s) => [s.id, sc.db.marks[`${x.id}|${s.id}`] !== undefined ? String(sc.db.marks[`${x.id}|${s.id}`]) : ""]))); }
  if (!exams.length) return <Page title="Marks entry"><Empty icon={GraduationCap} title="No exams to enter marks for" body="Exams for your batches appear here once scheduled." /></Page>;
  const locked = x?.status === "published";
  const bad = (id: string) => vals[id] !== "" && vals[id] !== undefined && (Number(vals[id]) > (x?.max ?? 0));
  const missing = roster.filter((s) => (vals[s.id] ?? "") === "").length;
  const anyBad = roster.some((s) => bad(s.id));
  const entries = () => Object.fromEntries(roster.map((s) => [s.id, vals[s.id] === "" || vals[s.id] === undefined ? null : Number(vals[s.id])]));
  const canPub = can(sc.db, session.role, "results.publish");
  return (
    <Page title="Marks entry" subtitle={x ? `${x.subject} · max ${x.max}` : ""}
      footer={x && !locked ? <div className="flex gap-2"><Btn variant="secondary" disabled={anyBad} onClick={async () => { await uc.saveMarks(x.id, entries()); toast("Draft saved"); }}>Save draft</Btn><Btn disabled={anyBad || missing > 0} onClick={() => confirm({ title: canPub ? "Publish results?" : "Submit for publication?", body: canPub ? "Students and verified parents will see these marks immediately." : "The owner will review and publish these marks.", confirmLabel: canPub ? "Publish" : "Submit", onConfirm: async () => { await uc.saveMarks(x.id, entries()); if (canPub) { await uc.publishExam(x.id, session.role); toast("Results published"); } else { await uc.save("notifications", { id: uid("nf"), inst: sc.instId, roles: ["owner"], cat: "exam", title: `Marks submitted: ${x.name}`, body: "Awaiting your review and publication.", at: nowISO(), dest: { name: "S34", params: { id: x.id } }, readRoles: [] }); toast("Submitted for owner review", "info"); } back(); } })}>{canPub ? "Publish" : "Submit"}</Btn></div> : undefined}>
      <div className="space-y-3 pt-1"><Select label="Exam" options={exams.map((e) => ({ value: e.id, label: e.name, sub: `${bShort(sc.batches.find((b) => b.id === e.batchId)?.name)} · ${lab2(e.status)}` }))} value={xid} onChange={setXid} />
        {x ? <><Card><div className="flex items-center justify-between"><div><div className="text-[13px] text-mute">{sc.batches.find((b) => b.id === x.batchId)?.name}</div><div className="text-[12.5px] text-mute">{dmy(x.date)}</div></div><StatusBadge status={x.status} /></div></Card>
          {locked ? <Banner tone="ok" icon={Check}>Results are published and locked.</Banner> : missing ? <Banner tone="warn">{missing} student(s) still missing marks.</Banner> : <Banner tone="ok" icon={Check}>All marks entered.</Banner>}
          <List>{roster.map((s) => <div key={s.id} className="flex items-center gap-3 px-4 py-2.5"><Avatar name={s.name} size={36} /><div className="min-w-0 flex-1"><div className="truncate text-[14.5px] font-medium">{s.name}</div>{bad(s.id) ? <div className="text-[11.5px] font-medium text-bad">Max {x.max}</div> : (vals[s.id] ?? "") === "" ? <div className="text-[11.5px] font-medium text-warn">Missing</div> : null}</div>
            <div className="flex items-center gap-1.5"><input aria-label={`Marks for ${s.name}`} disabled={locked} inputMode="numeric" value={vals[s.id] ?? ""} onChange={(e) => setVals({ ...vals, [s.id]: e.target.value.replace(/\D/g, "").slice(0, 3) })} className={`h-11 w-16 rounded-xl border text-center text-[16px] font-semibold outline-none focus:ring-2 focus:ring-brand/20 disabled:bg-slate-50 ${bad(s.id) ? "border-bad text-bad" : "border-line"}`} /><span className="text-[12px] text-mute">/{x.max}</span></div></div>)}</List></> : null}
      </div>
    </Page>
  );
}
const lab2 = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/* S51 */
function AssignedStudents({ params }: P) {
  const { sc, t, batches, students } = useT();
  const { push } = useApp();
  const [q, setQ] = useState("");
  const [batch, setBatch] = useState("All");
  const list = students.filter((s) => (batch === "All" || s.batchId === batch) && s.name.toLowerCase().includes(q.toLowerCase()));
  if (params.id) {
    const s = sc.students.find((x) => x.id === params.id);
    if (!s || !students.some((x) => x.id === s.id)) return <Page title="Student"><Denied body="This student isn't in a batch assigned to you. Teachers can only open their own students." /></Page>;
    const att = studentAtt(sc.db, s.id), res = resultsFor(sc.db, s.id);
    const b = sc.batches.find((x) => x.id === s.batchId)!;
    const mySubs = teacherSubjects(b, t?.id);
    const hws = sc.homework.filter((h) => h.batchId === s.batchId && mySubs.includes(h.subject) && h.status === "published");
    const fb = sc.submissions.filter((x) => x.studentId === s.id && x.feedback && hws.some((h) => h.id === x.hwId));
    return (
      <Page title="Student" subtitle={`${s.sid} · ${bShort(b.name)}`}>
        <div className="space-y-3 pt-2"><Card><div className="flex items-center gap-3"><Avatar name={s.name} size={54} /><div><div className="text-[17px] font-bold">{s.name}</div><div className="text-[12.5px] text-mute">Teaching: {mySubs.join(", ")}</div></div></div></Card>
          <div className="grid grid-cols-2 gap-3"><Stat label="Attendance" value={`${att.pct}%`} tone={att.pct >= 85 ? "ok" : "warn"} sub={`${att.a} absent · ${att.l} late`} /><Stat label="Homework" value={`${hws.filter((h) => ["submitted", "reviewed"].includes(subFor(sc.db, h, s.id).status)).length}/${hws.length}`} tone="sky" sub="submitted" /></div>
          <Section title="Homework">{hws.length ? <div className="space-y-2">{hws.map((h) => <HomeworkCard key={h.id} h={h} status={subFor(sc.db, h, s.id).status} onClick={() => { const x = subFor(sc.db, h, s.id).sub; if (x && x.status !== "pending") push("S49", { id: x.id }); }} />)}</div> : <Card><p className="text-[13px] text-mute">No homework yet.</p></Card>}</Section>
          <Section title="Exam performance">{res.filter((r) => mySubs.includes(r.exam.subject)).length ? <List>{res.filter((r) => mySubs.includes(r.exam.subject)).map((r) => <Row key={r.exam.id} icon={GraduationCap} tone="violet" title={r.exam.name} sub={dmy(r.exam.date)} right={<b>{r.marks}/{r.exam.max} · {r.pct}%</b>} noChevron />)}</List> : <Card><p className="text-[13px] text-mute">No published results in your subjects.</p></Card>}</Section>
          <Section title="Your feedback">{fb.length ? fb.map((x) => <Card key={x.id} className="mb-2"><p className="text-[13.5px]">“{x.feedback}”</p></Card>) : <Card><p className="text-[13px] text-mute">No feedback given yet.</p></Card>}</Section></div>
      </Page>
    );
  }
  return (
    <Page title="My students" subtitle={`${list.length} in your batches`}>
      <div className="space-y-2 pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search students" /><Chips value={batch} onChange={setBatch} options={[{ value: "All", label: "All batches" }, ...batches.map((b) => ({ value: b.id, label: bShort(b.name) }))]} /></div>
      {list.length ? <div className="mt-2 space-y-2.5">{list.map((s) => <StudentCard key={s.id} s={s} batch={bShort(sc.batches.find((b) => b.id === s.batchId)?.name)} right={<AttPill status={sc.db.attendance[`${today()}|${s.id}`]} />} onClick={() => push("S51", { id: s.id })} />)}</div> : <Empty icon={Users} title="No students found" />}
      <p className="mt-4 px-1 text-center text-[11.5px] text-mute">Only students in your assigned batches are shown.</p>
    </Page>
  );
}

/* S52 */
function TeacherResources({ params }: P) {
  const { sc, t, batches } = useT();
  const { session } = useApp();
  const [q, setQ] = useState("");
  const [subj, setSubj] = useState("All");
  const [batch, setBatch] = useState("All");
  const [type, setType] = useState("All");
  const [view, setView] = useState(sc.resources.find((r) => r.id === params.id) ?? null);
  const mine = sc.resources.filter((r) => r.batchIds.some((b) => batches.some((x) => x.id === b)) || r.by === t?.name);
  const list = mine.filter((r) => (subj === "All" || r.subject === subj) && (batch === "All" || r.batchIds.includes(batch)) && (type === "All" || r.type === type) && r.title.toLowerCase().includes(q.toLowerCase()));
  void session;
  return (
    <Page title="Resources" subtitle={`${list.length} shared with your batches`}>
      <div className="pt-1"><SearchInput value={q} onChange={setQ} placeholder="Search resources" /><Chips value={subj} onChange={setSubj} options={["All", ...Array.from(new Set(mine.map((r) => r.subject)))]} /><Chips value={batch} onChange={setBatch} options={[{ value: "All", label: "All batches" }, ...batches.map((b) => ({ value: b.id, label: bShort(b.name) }))]} /><Chips value={type} onChange={setType} options={[{ value: "All", label: "All types" }, { value: "pdf", label: "PDF" }, { value: "doc", label: "Docs" }, { value: "image", label: "Images" }, { value: "link", label: "Links" }]} /></div>
      {list.length ? <div className="mt-2"><List>{list.map((r) => <Row key={r.id} icon={r.type === "link" ? BookOpen : FileText} title={r.title} sub={`${r.subject} · ${r.type.toUpperCase()}${r.size ? ` · ${fileSize(r.size)}` : ""}`} right={<IconBtn icon={Bookmark} label={r.bookmarked ? "Remove bookmark" : "Bookmark"} onClick={() => uc.toggleBookmark(r.id)} tone={r.bookmarked ? "soft" : "plain"} />} onClick={() => { uc.openResource(r.id); setView(r); }} noChevron />)}</List></div> : <Empty icon={Search} title="No resources match" body="Try another subject, batch or type." />}
      <ResourceViewer r={view} onClose={() => setView(null)} />
    </Page>
  );
}

/* Chat */
export function Chat({ msgs, me }: { msgs: { from: "student" | "teacher"; text: string; at: string }[]; me: "student" | "teacher" }) {
  return <div className="space-y-2.5">{msgs.map((m, i) => <div key={i} className={`flex ${m.from === me ? "justify-end" : "justify-start"}`}><div className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-[14px] leading-snug ${m.from === me ? "rounded-br-md bg-brand text-white" : "rounded-bl-md bg-white text-ink shadow-sm"}`}>{m.text}<div className={`mt-1 text-[10.5px] ${m.from === me ? "text-white/70" : "text-mute"}`}>{ago(m.at)}</div></div></div>)}</div>;
}

/* S53 */
function Doubts({ params }: P) {
  const { sc, t } = useT();
  const { push, toast } = useApp();
  const [filter, setFilter] = useState("open");
  const [reply, setReply] = useState("");
  const mine = sc.doubts.filter((d) => d.teacherId === t?.id);
  if (params.id) {
    const d = mine.find((x) => x.id === params.id);
    if (!d) return <Page title="Doubt"><Denied body="This doubt isn't addressed to you." /></Page>;
    const s = sc.students.find((x) => x.id === d.studentId);
    return (
      <Page title="Doubt" subtitle={`${d.subject} · ${s?.name}`} footer={d.status !== "resolved" ? <div className="space-y-2"><div className="flex gap-2"><div className="flex-1"><TextInput value={reply} onChange={setReply} placeholder="Write a reply…" /></div><Btn full={false} icon={Send} disabled={!reply.trim()} label="Send reply" onClick={async () => { await uc.replyDoubt(d.id, "teacher", reply.trim()); setReply(""); toast("Reply sent"); }}>Send</Btn></div><Btn variant="secondary" size="sm" icon={Check} onClick={async () => { await uc.resolveDoubt(d.id); toast("Marked as resolved"); }}>Mark resolved</Btn></div> : undefined}>
        <div className="space-y-3 pt-2"><Card><div className="flex items-start justify-between gap-2"><div className="text-[15px] font-semibold leading-snug">{d.title}</div><StatusBadge status={d.status} /></div><div className="mt-1 text-[12.5px] text-mute">{sc.batches.find((b) => b.id === d.batchId)?.name}{d.hasImage ? " · 1 image attached" : ""}</div></Card>
          {d.hasImage ? <div className="grid h-36 place-items-center rounded-2xl bg-sky-soft text-[12.5px] text-sky">Attached image (demo placeholder)</div> : null}
          <Chat msgs={d.messages} me="teacher" /></div>
      </Page>
    );
  }
  const list = mine.filter((d) => filter === "all" || d.status === filter);
  return (
    <Page title="Student doubts" subtitle={`${mine.filter((d) => d.status === "open").length} open`}>
      <div className="pt-1"><Chips value={filter} onChange={setFilter} options={[{ value: "open", label: "Open" }, { value: "answered", label: "Answered" }, { value: "resolved", label: "Resolved" }, { value: "all", label: "All" }]} /></div>
      {list.length ? <div className="mt-2 space-y-2.5">{list.map((d) => <Card key={d.id} onClick={() => push("S53", { id: d.id })}><div className="flex items-start gap-3"><Avatar name={sc.students.find((s) => s.id === d.studentId)?.name ?? "?"} /><div className="min-w-0 flex-1"><div className="text-[14.5px] font-semibold leading-snug">{d.title}</div><div className="text-[12.5px] text-mute">{sc.students.find((s) => s.id === d.studentId)?.name} · {d.subject}</div><p className="mt-1 line-clamp-1 text-[12.5px] text-mute">{d.messages[d.messages.length - 1].text}</p></div><StatusBadge status={d.status} /></div></Card>)}</div> : <Empty icon={MessageCircleQuestion} title="No doubts here" body="Student questions will show up in this inbox." />}
    </Page>
  );
}

/* S54 */
function TeacherLeave(_: P) {
  const { sc, t } = useT();
  const { toast, push } = useApp();
  const [tab, setTab] = useState("requests");
  const [add, setAdd] = useState(false);
  const [m, setM] = useState({ y: new Date().getFullYear(), m: new Date().getMonth() });
  const mine = sc.leaves.filter((l) => l.kind === "staff" && l.personId === t?.id).sort((a, b) => (a.from < b.from ? 1 : -1));
  const used = mine.filter((l) => l.status === "approved").reduce((a, l) => a + Math.round((new Date(l.to).getTime() - new Date(l.from).getTime()) / 86400000) + 1, 0);
  const f = useForm({ from: "", to: "", reason: "" }, (v) => ({ from: v.from ? (v.from < today() ? "Start date can't be in the past" : undefined) : "Pick start date", to: !v.to ? "Pick end date" : v.to < v.from ? "End date must be on or after start" : undefined, reason: v.reason.trim().length < 5 ? "Add a short reason" : undefined }));
  const overlap = f.v.from && f.v.to ? mine.find((l) => l.status !== "rejected" && l.from <= f.v.to && f.v.from <= l.to) : undefined;
  const marks: Record<string, "H" | "P"> = {};
  mine.filter((l) => l.status === "approved").forEach((l) => { for (let d = l.from; d <= l.to; d = addDays(1, d)) marks[d] = "H"; });
  const studentLeaves = sc.leaves.filter((l) => l.kind === "student" && sc.students.some((s) => s.id === l.personId && sc.batches.some((b) => b.id === s.batchId && Object.values(b.subjectTeachers).includes(t?.id ?? ""))));
  return (
    <Page title="Leave" right={<IconBtn icon={Plus} label="Request leave" tone="soft" onClick={() => { f.setV({ from: "", to: "", reason: "" }); setAdd(true); }} />}>
      <div className="pt-2"><Card><div className="flex items-center gap-4"><Donut value={pct(12 - used, 12)} size={72} sub="left" tone="ok" /><div><div className="text-[13px] text-mute">Annual leave balance</div><div className="text-[22px] font-bold">{Math.max(12 - used, 0)} <span className="text-[13px] font-medium text-mute">of 12 days</span></div></div></div></Card></div>
      <div className="mt-3"><Tabs value={tab} onChange={setTab} options={[{ value: "requests", label: "My requests" }, { value: "calendar", label: "Calendar" }, { value: "students", label: "Student leave", count: studentLeaves.length }]} /></div>
      <div className="mt-3">
        {tab === "requests" && (mine.length ? <div className="space-y-2.5">{mine.map((l) => <Card key={l.id}><div className="flex items-start justify-between gap-2"><div><div className="text-[14.5px] font-semibold">{dmy(l.from)} – {dmy(l.to)}</div><div className="text-[12.5px] text-mute">{l.reason}</div>{l.substitute ? <div className="mt-1 text-[12px]">Substitute: <b>{l.substitute}</b></div> : l.status === "approved" ? <div className="mt-1 text-[12px] text-mute">No substitute assigned yet</div> : null}</div><StatusBadge status={l.status} /></div></Card>)}</div> : <Empty icon={CalendarDays} title="No leave requests" body="Request leave and the owner will approve it." action="Request leave" onAction={() => setAdd(true)} />)}
        {tab === "calendar" && <Card><MonthCalendar year={m.y} month={m.m} marks={marks} onChange={(y, mo) => setM({ y, m: mo })} /><p className="mt-3 text-center text-[12px] text-mute">“Off” marks your approved leave days.</p></Card>}
        {tab === "students" && (studentLeaves.length ? <List>{studentLeaves.map((l) => <Row key={l.id} lead={<Avatar name={sc.students.find((s) => s.id === l.personId)?.name ?? "?"} />} title={sc.students.find((s) => s.id === l.personId)?.name} sub={`${dmy(l.from)} – ${dmy(l.to)} · ${l.reason}`} right={<StatusBadge status={l.status} />} noChevron />)}</List> : <Empty title="No student leave requests" />)}
      </div>
      <Sheet open={add} onClose={() => setAdd(false)} title="Request leave"><div className="space-y-4"><div className="grid grid-cols-2 gap-3"><DatePicker label="From" required min={today()} value={f.v.from} onChange={(v) => f.set("from", v)} error={f.v.from ? f.errors.from : undefined} /><DatePicker label="To" required min={f.v.from || today()} value={f.v.to} onChange={(v) => f.set("to", v)} error={f.v.to ? f.errors.to : undefined} /></div><TextInput label="Reason" required multiline rows={3} {...f.bind("reason")} />
        {overlap ? <Banner tone="warn">This overlaps with your request for {dmy(overlap.from)} – {dmy(overlap.to)}.</Banner> : null}
        <Btn disabled={!f.valid || !!overlap} onClick={async () => { await uc.requestLeave({ inst: sc.instId, kind: "staff", personId: t?.id ?? "", from: f.v.from, to: f.v.to, reason: f.v.reason.trim(), by: t?.name ?? "" }); setAdd(false); toast("Leave request sent to the owner"); }}>Send request</Btn></div></Sheet>
      <span className="hidden" onClick={() => push("S11")} />
    </Page>
  );
}

/* S55 */
function TeacherNotices({ params }: P) {
  const { sc, me, t } = useT();
  const { session, push, signOut, confirm } = useApp();
  const { list } = useNotifs();
  const [tab, setTab] = useState("notices");
  const notices = sc.notices.filter((n) => noticeVisible(n, "teacher", me.batchIds)).sort((a, b) => (a.publishAt < b.publishAt ? 1 : -1));
  const [view, setView] = useState<Notice | null>(notices.find((n) => n.id === params.id) ?? null);
  return (
    <Page title="Notices & profile">
      <div className="pt-1"><Tabs value={tab} onChange={setTab} options={[{ value: "notices", label: "Notices" }, { value: "notifs", label: "Notifications" }, { value: "profile", label: "Profile" }]} /></div>
      <div className="mt-3">
        {tab === "notices" && (notices.length ? <div className="space-y-2.5">{notices.map((n) => <NoticeCard key={n.id} n={n} read={n.readBy.includes(session.role)} onClick={() => { setView(n); uc.markNoticeRead(n.id, session.role); }} />)}</div> : <Empty icon={Megaphone} title="No notices" />)}
        {tab === "notifs" && (list.length ? <><List>{list.slice(0, 12).map((n) => <NotificationItem key={n.id} n={n} read={n.readRoles.includes(session.role)} onClick={async () => { await uc.markRead(n.id, session.role); const d = resolveDest(session.role, n.dest); push(d.name, d.params as Record<string, any>); }} />)}</List><div className="mt-3"><Btn variant="secondary" onClick={() => push("S11")}>Open full notification history</Btn></div></> : <Empty icon={Bell} title="No notifications" />)}
        {tab === "profile" && <div className="space-y-3"><Card><div className="flex items-center gap-3"><Avatar name={t?.name ?? "T"} size={56} tone="violet" /><div><div className="text-[17px] font-bold">{t?.name}</div><div className="text-[12.5px] text-mute">{t?.role} · {t?.subjects.join(", ")}</div></div></div></Card>
          <List><Row icon={Settings} title="Preferences" onClick={() => push("S14")} /><Row icon={HelpCircle} title="Help & support" onClick={() => push("S14", { tab: "help" })} /><Row icon={Users} title="Full profile" onClick={() => push("S13")} /><Row icon={LogOut} tone="bad" title="Sign out" noChevron onClick={() => confirm({ title: "Sign out?", confirmLabel: "Sign out", danger: true, onConfirm: signOut })} /></List></div>}
      </div>
      <Sheet open={!!view} onClose={() => setView(null)} title={view?.title}>{view ? <div className="space-y-3"><div className="flex gap-2"><Badge tone="brand">{view.category}</Badge><span className="text-[12px] text-mute">{ago(view.publishAt)} · {view.by}</span></div><p className="text-[14px] leading-relaxed">{view.body}</p>{view.attachment ? <FileItem file={view.attachment} /> : null}</div> : null}</Sheet>
    </Page>
  );
}

export const teacherScreens: ScreenMap = {
  S42: def("Teacher Home / My Work", "teacher", TeacherHome), S43: def("Teacher Timetable", "teacher", TeacherTimetable), S44: def("My Classes", "teacher", MyClasses), S45: def("Class Detail / Class Diary", "teacher", ClassDetail),
  S46: def("Attendance Marking", "teacher", AttendanceMarking), S47: def("Homework List / Review Queue", "teacher", HomeworkList), S48: def("Create / Edit Homework", "teacher", HomeworkForm), S49: def("Submission Review", "teacher", SubmissionReview),
  S50: def("Exam / Marks Entry", "teacher", MarksEntry), S51: def("Assigned Students / Detail", "teacher", AssignedStudents), S52: def("Teacher Resources", "teacher", TeacherResources), S53: def("Doubt Inbox / Detail", "teacher", Doubts),
  S54: def("Leave Request / Calendar", "teacher", TeacherLeave), S55: def("Notices / Notifications / Profile", "teacher", TeacherNotices),
};
