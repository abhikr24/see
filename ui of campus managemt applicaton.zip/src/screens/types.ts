import type React from "react";
import type { Role } from "@/domain/types";

export type P = { params: Record<string, any> };
export interface ScreenDef { title: string; role: Role | "shared"; C: React.ComponentType<P> }
export type ScreenMap = Record<string, ScreenDef>;
export const def = (title: string, role: ScreenDef["role"], C: ScreenDef["C"]): ScreenDef => ({ title, role, C });
