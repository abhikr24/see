"use client";
import dynamic from "next/dynamic";

const Shell = dynamic(() => import("./Shell"), {
  ssr: false,
  loading: () => (
    <div className="grid min-h-dvh place-items-center bg-brand-dark text-white">
      <span className="text-[22px] font-bold tracking-tight">GuruFlow</span>
    </div>
  ),
});

export default function ClientRoot() {
  return <Shell />;
}
