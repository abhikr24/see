"use client";
import React, { useEffect, useState } from "react";
import { BatteryFull, GraduationCap, RotateCcw, Signal, Wifi } from "lucide-react";
import { AppProvider, useApp, useDB } from "@/state/app";
import { Overlays, OfflineBanner, Btn, Empty } from "@/ui/kit";
import { TABS } from "./tabs";
import { SCREENS } from "@/screens/registry";
import { HOME, ROLE_LABEL } from "@/features/selectors";
import { uc } from "@/features/usecases";
import type { Role } from "@/domain/types";

function StatusBar() {
  const [t, setT] = useState("");
  useEffect(() => {
    const f = () => { const d = new Date(); setT(`${d.getHours() % 12 || 12}:${String(d.getMinutes()).padStart(2, "0")}`); };
    f(); const i = setInterval(f, 20000); return () => clearInterval(i);
  }, []);
  return (
    <div className="hidden shrink-0 items-center justify-between bg-bg px-7 pb-1 pt-3 text-[12px] font-semibold text-ink sm:flex" aria-hidden>
      <span>{t}</span>
      <div className="absolute left-1/2 top-2 h-5 w-5 -translate-x-1/2 rounded-full bg-[#0c0f2b]" />
      <span className="flex items-center gap-1.5"><Signal size={13} /><Wifi size={13} /><BatteryFull size={16} /></span>
    </div>
  );
}

function BottomNav() {
  const { session, route, reset } = useApp();
  const tabs = TABS[session.role];
  return (
    <nav aria-label="Primary" className="shrink-0 border-t border-line bg-white px-1 pb-[max(env(safe-area-inset-bottom),6px)] pt-1.5">
      <ul className="flex">
        {tabs.map((t) => {
          const active = route.name === t.name;
          return (
            <li key={t.name} className="flex-1">
              <button aria-label={t.label} aria-current={active ? "page" : undefined} onClick={() => !active && reset(t.name)} className="flex min-h-14 w-full flex-col items-center justify-center gap-0.5">
                <span className={`grid h-7 w-14 place-items-center rounded-full transition-colors ${active ? "bg-brand-soft text-brand" : "text-mute"}`}><t.icon size={21} strokeWidth={active ? 2.4 : 2} /></span>
                <span className={`text-[11px] ${active ? "font-bold text-brand" : "font-medium text-mute"}`}>{t.label}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

function SidePanel() {
  const { jump, toast, session, push } = useApp();
  useDB();
  return (
    <aside className="hidden w-[300px] shrink-0 lg:block">
      <div className="flex items-center gap-3">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand text-white"><GraduationCap size={26} /></span>
        <div><div className="text-[22px] font-bold tracking-tight text-ink">GuruFlow</div><div className="text-[13px] text-mute">Interactive prototype · Demo mode</div></div>
      </div>
      <p className="mt-5 text-[13.5px] leading-relaxed text-mute">A premium institute management & learning app for owners, teachers, students and parents. The phone frame is only a preview device — the app itself is full-screen on mobile.</p>
      <div className="mt-6 text-[12px] font-semibold uppercase tracking-wider text-mute">Jump into a role</div>
      <div className="mt-2 grid grid-cols-2 gap-2">
        {(["owner", "teacher", "student", "parent"] as Role[]).map((r) => (
          <button key={r} onClick={() => jump(HOME[r], r)} className={`min-h-11 rounded-xl border px-3 text-[13px] font-semibold ${session.authed && session.role === r ? "border-brand bg-brand text-white" : "border-line bg-white text-ink"}`}>{ROLE_LABEL[r].split(" /")[0]}</button>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <Btn variant="secondary" size="sm" onClick={() => push("DIR")}>All 82 screens</Btn>
        <Btn variant="secondary" size="sm" icon={RotateCcw} onClick={async () => { await uc.reset(); toast("Demo data reset"); }}>Reset data</Btn>
      </div>
    </aside>
  );
}

function Screen() {
  const { route } = useApp();
  const def = SCREENS[route.name];
  if (!def) return <Empty title="Screen not found" body={`No screen is registered for “${route.name}”.`} />;
  const C = def.C;
  return <C params={route.params ?? {}} />;
}

function Frame() {
  const { route, session, stack, setHost } = useApp();
  const showNav = session.authed && TABS[session.role].some((t) => t.name === route.name);
  return (
    <div className="flex min-h-dvh items-center justify-center gap-12 bg-[#e9ebf5] sm:p-4">
      <SidePanel />
      <div className="relative flex h-dvh w-full flex-col overflow-hidden bg-bg sm:h-[820px] sm:max-h-[calc(100dvh-32px)] sm:w-[392px] sm:rounded-[48px] sm:border-[10px] sm:border-[#0c0f2b] sm:shadow-[0_30px_80px_rgba(20,24,51,0.35)]">
        <StatusBar />
        <OfflineBanner />
        <main className="relative min-h-0 flex-1">
          <div key={route.key} className={`${stack.length > 1 ? "anim-slide" : "anim-fade"} h-full`}><Screen /></div>
        </main>
        {showNav ? <BottomNav /> : null}
        <div className="hidden shrink-0 justify-center bg-white pb-2 pt-1 sm:flex" aria-hidden><div className="h-1.5 w-28 rounded-full bg-slate-300" /></div>
        <div ref={setHost} className="pointer-events-none absolute inset-0 z-30 [&>*]:pointer-events-auto" />
        <Overlays />
      </div>
    </div>
  );
}

export default function Shell() {
  return (
    <AppProvider>
      <Frame />
    </AppProvider>
  );
}
