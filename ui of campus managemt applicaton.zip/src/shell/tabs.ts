import type { LucideIcon } from "lucide-react";
import { BookOpen, ClipboardList, Dumbbell, Home, IndianRupee, LayoutGrid, Megaphone, UserCheck, UserPlus, Users, CalendarDays, School } from "lucide-react";
import type { Role } from "@/domain/types";

export interface Tab { name: string; label: string; icon: LucideIcon }
export const TABS: Record<Role, Tab[]> = {
  owner: [
    { name: "S16", label: "Home", icon: Home }, { name: "S17", label: "Admissions", icon: UserPlus }, { name: "S21", label: "Students", icon: Users },
    { name: "H-owner-academics", label: "Academics", icon: BookOpen }, { name: "H-owner-more", label: "More", icon: LayoutGrid },
  ],
  teacher: [
    { name: "S42", label: "Home", icon: Home }, { name: "S44", label: "Classes", icon: School }, { name: "S46", label: "Attendance", icon: UserCheck },
    { name: "S47", label: "Homework", icon: ClipboardList }, { name: "H-teacher-more", label: "More", icon: LayoutGrid },
  ],
  student: [
    { name: "S56", label: "Home", icon: Home }, { name: "S57", label: "Timetable", icon: CalendarDays }, { name: "S59", label: "Homework", icon: ClipboardList },
    { name: "S65", label: "Practice", icon: Dumbbell }, { name: "H-student-more", label: "More", icon: LayoutGrid },
  ],
  parent: [
    { name: "S72", label: "Home", icon: Home }, { name: "H-parent-academics", label: "Academics", icon: BookOpen }, { name: "S77", label: "Fees", icon: IndianRupee },
    { name: "S79", label: "Notices", icon: Megaphone }, { name: "H-parent-more", label: "More", icon: LayoutGrid },
  ],
};
