"use client";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { getRepository } from "@/data/factory";
import type { DB, Role } from "@/domain/types";
import { HOME, TEACHER_ID, STUDENT_ID, OWNER_NAME, parentChildren, scopeOf } from "@/features/selectors";

export interface Route { key: string; name: string; params?: Record<string, any> }
export interface Session { authed: boolean; instId: string; role: Role; childId: string }
export interface ConfirmOpts { title: string; body?: string; confirmLabel?: string; danger?: boolean; onConfirm: () => void | Promise<void> }
export interface ToastItem { id: number; text: string; tone: "ok" | "bad" | "info" }

interface Ctx {
  stack: Route[]; route: Route; session: Session;
  push: (name: string, params?: Record<string, any>) => void;
  back: () => void;
  replace: (name: string, params?: Record<string, any>) => void;
  reset: (name: string, params?: Record<string, any>) => void;
  signIn: () => void; signOut: () => void;
  switchContext: (instId: string, role: Role) => void;
  setChild: (id: string) => void;
  jump: (name: string, role?: Role, params?: Record<string, any>) => void;
  host: HTMLElement | null; setHost: (el: HTMLElement | null) => void;
  toasts: ToastItem[]; toast: (text: string, tone?: ToastItem["tone"]) => void;
  confirmState: ConfirmOpts | null; confirm: (o: ConfirmOpts) => void; closeConfirm: () => void;
  offline: boolean; setOffline: (v: boolean) => void; online: boolean;
  setDirty: (v: boolean) => void;
}
const AppCtx = createContext<Ctx | null>(null);
let keyN = 0;
const mk = (name: string, params?: Record<string, any>): Route => ({ key: `r${++keyN}`, name, params });

export function AppProvider({ children, initialSession }: { children: React.ReactNode; initialSession?: Partial<Session> }) {
  const [session, setSession] = useState<Session>({ authed: false, instId: "i1", role: "owner", childId: "s1", ...initialSession });
  const [stack, setStack] = useState<Route[]>(() => [mk("S01")]);
  const [host, setHost] = useState<HTMLElement | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [confirmState, setConfirmState] = useState<ConfirmOpts | null>(null);
  const [offline, setOffline] = useState(false);
  const [online, setOnline] = useState(true);
  const dirty = useRef(false);
  const popByUs = useRef(false);
  const stackLen = useRef(1);
  useEffect(() => { stackLen.current = stack.length; }, [stack.length]);
  const toastId = useRef(0);

  const toast = useCallback((text: string, tone: ToastItem["tone"] = "ok") => {
    const id = ++toastId.current;
    setToasts((t) => [...t, { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2600);
  }, []);
  const confirm = useCallback((o: ConfirmOpts) => setConfirmState(o), []);
  const closeConfirm = useCallback(() => setConfirmState(null), []);
  const setDirty = useCallback((v: boolean) => { dirty.current = v; }, []);

  const push = useCallback((name: string, params?: Record<string, any>) => {
    window.history.pushState({ gf: 1 }, "");
    setStack((s) => [...s, mk(name, params)]);
  }, []);
  const replace = useCallback((name: string, params?: Record<string, any>) => setStack((s) => [...s.slice(0, -1), mk(name, params)]), []);
  const reset = useCallback((name: string, params?: Record<string, any>) => { dirty.current = false; setStack([mk(name, params)]); }, []);

  const askDiscard = useCallback((then: () => void) => {
    setConfirmState({ title: "Discard unsaved changes?", body: "You have changes that haven't been saved. If you leave now they will be lost.", confirmLabel: "Discard", danger: true, onConfirm: () => { dirty.current = false; then(); } });
  }, []);

  const back = useCallback(() => {
    if (stackLen.current <= 1) return;
    const go = () => { popByUs.current = true; window.history.back(); };
    if (dirty.current) askDiscard(go);
    else go();
  }, [askDiscard]);

  useEffect(() => {
    window.history.replaceState({ gf: 0 }, "");
    const onPop = () => {
      if (popByUs.current) { popByUs.current = false; setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)); return; }
      if (stackLen.current <= 1) { window.history.pushState({ gf: 1 }, ""); return; }
      if (dirty.current) { window.history.pushState({ gf: 1 }, ""); askDiscard(() => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s))); return; }
      setStack((s) => (s.length > 1 ? s.slice(0, -1) : s));
    };
    window.addEventListener("popstate", onPop);
    const on = () => setOnline(navigator.onLine);
    window.addEventListener("online", on); window.addEventListener("offline", on);
    on();
    return () => { window.removeEventListener("popstate", onPop); window.removeEventListener("online", on); window.removeEventListener("offline", on); };
  }, [askDiscard]);

  const switchContext = useCallback((instId: string, role: Role) => {
    setSession((s) => ({ ...s, instId, role, authed: true }));
    reset(HOME[role]);
  }, [reset]);
  const signIn = useCallback(() => setSession((s) => ({ ...s, authed: true })), []);
  const signOut = useCallback(() => { setSession((s) => ({ ...s, authed: false })); reset("S02"); }, [reset]);
  const setChild = useCallback((id: string) => setSession((s) => ({ ...s, childId: id })), []);
  const jump = useCallback((name: string, role?: Role, params?: Record<string, any>) => {
    const r = role ?? session.role;
    setSession((s) => ({ ...s, authed: true, role: r, instId: r === "owner" || r === "student" || r === "parent" ? "i1" : s.instId }));
    setStack([mk(HOME[r]), ...(name === HOME[r] ? [] : [mk(name, params)])]);
    if (name !== HOME[r]) window.history.pushState({ gf: 1 }, "");
  }, [session.role]);

  const value = useMemo<Ctx>(() => ({
    stack, route: stack[stack.length - 1], session, push, back, replace, reset, signIn, signOut, switchContext, setChild, jump, host, setHost,
    toasts, toast, confirmState, confirm, closeConfirm, offline, setOffline, online, setDirty,
  }), [stack, session, push, back, replace, reset, signIn, signOut, switchContext, setChild, jump, host, toasts, toast, confirmState, confirm, closeConfirm, offline, online, setDirty]);

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export const useApp = () => {
  const c = useContext(AppCtx);
  if (!c) throw new Error("AppProvider missing");
  return c;
};
export const useNav = useApp;
export const useUI = useApp;

/** Register unsaved-changes state for the current screen. Back navigation will ask for confirmation. */
export function useUnsaved(dirty: boolean) {
  const { setDirty } = useApp();
  useEffect(() => { setDirty(dirty); return () => setDirty(false); }, [dirty, setDirty]);
}

/** Live snapshot of the shared repository (re-renders when any role changes data). */
export function useDB(): DB {
  const repo = getRepository();
  return useSyncExternalStore(repo.subscribe, repo.getSnapshot, repo.getSnapshot);
}

export function useScope() {
  const db = useDB();
  const { session } = useApp();
  return useMemo(() => scopeOf(db, session.instId), [db, session.instId]);
}

/** Identity of the signed-in persona for the active institute + role. */
export function useMe() {
  const sc = useScope();
  const { session } = useApp();
  const { db, instId } = sc;
  return useMemo(() => {
    const role = session.role;
    const teacher = db.staff.find((s) => s.id === TEACHER_ID[instId]) ?? sc.staff[0];
    const children = parentChildren(db, instId);
    const child = children.find((c) => c.id === session.childId) ?? children[0];
    const student = db.students.find((s) => s.id === STUDENT_ID) ?? sc.students[0];
    const guardian = child ? db.guardians.find((g) => g.studentId === child.id) : undefined;
    const name = role === "owner" ? OWNER_NAME : role === "teacher" ? teacher?.name : role === "student" ? student?.name : guardian?.name ?? "Parent";
    const studentIds = role === "student" ? [student.id] : role === "parent" ? children.map((c) => c.id) : [];
    const batchIds = role === "student" ? [student.batchId] : role === "parent" ? children.map((c) => c.batchId) : role === "teacher" ? teacher?.batchIds ?? [] : sc.batches.map((b) => b.id);
    return { role, name: name ?? "User", first: (name ?? "User").replace("Dr. ", "").split(" ")[0], teacher, student, children, child, studentIds, batchIds, instId };
  }, [db, instId, session.role, session.childId, sc.staff, sc.students, sc.batches]);
}
