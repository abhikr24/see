"use client";
import React from "react";
import { Bell, BookOpen, CalendarDays, CheckCircle2, ClipboardList, FileText, GraduationCap, IndianRupee, Megaphone, Paperclip, Clock } from "lucide-react";
import type { AppNotification, Exam, Homework, Notice, Role, Staff, Student, Batch } from "@/domain/types";
import { ago, dmy, inr, relDay, time12 } from "@/lib/fmt";
import type { SubStatus } from "@/features/selectors";
import { Avatar, Badge, Card, IconTile, Progress, Tone } from "./kit";

export const statusTone = (s: string): Tone =>
  ({ active: "ok", verified: "ok", published: "ok", paid: "ok", approved: "ok", reviewed: "ok", accepted: "ok", received: "ok", Converted: "ok", resolved: "ok", answered: "sky",
     pending: "warn", due: "warn", partial: "warn", scheduled: "sky", submitted: "sky", invited: "sky", "on-leave": "warn", completed: "violet", draft: "mute", inactive: "mute", alumni: "mute",
     overdue: "bad", rejected: "bad", declined: "bad", returned: "warn", Lost: "bad", open: "warn", refunded: "mute", "refund-requested": "warn", New: "brand", Contacted: "sky", "Demo Scheduled": "violet", "Follow-up": "warn", archived: "mute" } as Record<string, Tone>)[s] ?? "mute";
export const label = (s: string) => s.replace(/-/g, " ").replace(/^./, (c) => c.toUpperCase());
export const StatusBadge = ({ status, text }: { status: string; text?: string }) => <Badge tone={statusTone(status)}>{text ?? label(status)}</Badge>;

export function StudentCard({ s, batch, onClick, right }: { s: Student; batch?: string; onClick?: () => void; right?: React.ReactNode }) {
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex items-center gap-3">
        <Avatar name={s.name} />
        <div className="min-w-0 flex-1"><div className="truncate text-[15px] font-semibold text-ink">{s.name}</div><div className="truncate text-[12.5px] text-mute">{s.sid}{batch ? ` · ${batch}` : ""}</div></div>
        {right ?? <StatusBadge status={s.status} />}
      </div>
    </Card>
  );
}
export function TeacherCard({ t, onClick }: { t: Staff; onClick?: () => void }) {
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex items-center gap-3">
        <Avatar name={t.name} tone="violet" />
        <div className="min-w-0 flex-1"><div className="truncate text-[15px] font-semibold text-ink">{t.name}</div><div className="truncate text-[12.5px] text-mute">{t.role} · {t.subjects.join(", ")}</div></div>
        <StatusBadge status={t.status} />
      </div>
    </Card>
  );
}
export function NoticeCard({ n, read, onClick }: { n: Notice; read?: boolean; onClick?: () => void }) {
  const tone: Tone = n.category === "Holiday" ? "ok" : n.category === "Exam" ? "violet" : n.category === "Fee" ? "warn" : n.category === "Academic" ? "sky" : "brand";
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex gap-3">
        <IconTile icon={Megaphone} tone={tone} />
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2"><div className="text-[14.5px] font-semibold leading-snug text-ink">{n.title}</div>{read === false ? <span aria-label="Unread" className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-brand" /> : null}</div>
          <p className="mt-1 line-clamp-2 text-[12.5px] leading-snug text-mute">{n.body}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2"><Badge tone={tone}>{n.category}</Badge>{n.attachment ? <Badge tone="mute" icon={Paperclip}>1 file</Badge> : null}{n.status !== "published" ? <StatusBadge status={n.status} /> : null}<span className="text-[11.5px] text-mute">{ago(n.publishAt)}</span></div>
        </div>
      </div>
    </Card>
  );
}
export function HomeworkCard({ h, status, right, onClick, extra }: { h: Homework; status?: SubStatus; right?: React.ReactNode; onClick?: () => void; extra?: React.ReactNode }) {
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex items-start gap-3">
        <IconTile icon={ClipboardList} tone={status === "overdue" ? "bad" : "brand"} />
        <div className="min-w-0 flex-1">
          <div className="text-[14.5px] font-semibold leading-snug text-ink">{h.title}</div>
          <div className="mt-0.5 text-[12.5px] text-mute">{h.subject} · Due {dmy(h.due)} <span className="font-medium">({relDay(h.due)})</span></div>
          {extra}
        </div>
        {right ?? (status ? <StatusBadge status={status} /> : h.status === "draft" ? <StatusBadge status="draft" /> : null)}
      </div>
    </Card>
  );
}
export function ExamCard({ x, batch, right, onClick }: { x: Exam; batch?: string; right?: React.ReactNode; onClick?: () => void }) {
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex items-start gap-3">
        <IconTile icon={GraduationCap} tone="violet" />
        <div className="min-w-0 flex-1">
          <div className="text-[14.5px] font-semibold leading-snug text-ink">{x.name}</div>
          <div className="mt-0.5 text-[12.5px] text-mute">{x.subject}{batch ? ` · ${batch}` : ""}</div>
          <div className="mt-1 flex items-center gap-3 text-[12px] text-mute"><span className="flex items-center gap-1"><CalendarDays size={12} />{dmy(x.date)}</span><span className="flex items-center gap-1"><Clock size={12} />{time12(x.time)}</span><span>{x.max} marks</span></div>
        </div>
        {right ?? <StatusBadge status={x.status} />}
      </div>
    </Card>
  );
}
export function FeeCard({ total, paid, due, overdue }: { total: number; paid: number; due?: string; overdue?: number }) {
  const outstanding = Math.max(total - paid, 0);
  return (
    <Card>
      <div className="flex items-center justify-between"><span className="text-[12.5px] font-medium text-mute">Outstanding balance</span>{overdue ? <Badge tone="bad">Overdue {inr(overdue)}</Badge> : outstanding === 0 ? <Badge tone="ok" icon={CheckCircle2}>Fully paid</Badge> : <Badge tone="warn">Pending</Badge>}</div>
      <div className="mt-1 text-[28px] font-bold tracking-tight text-ink">{inr(outstanding)}</div>
      <div className="mt-3"><Progress value={(paid / (total || 1)) * 100} tone="ok" label="Fee paid" /></div>
      <div className="mt-2 flex justify-between text-[12px] text-mute"><span>Paid {inr(paid)}</span><span>Total {inr(total)}</span></div>
      {due ? <div className="mt-2 text-[12.5px] text-ink">Next due: <b>{dmy(due)}</b></div> : null}
    </Card>
  );
}
export function NotificationItem({ n, read, onClick }: { n: AppNotification; read: boolean; onClick: () => void }) {
  const icon = { attendance: CheckCircle2, homework: ClipboardList, exam: GraduationCap, fee: IndianRupee, notice: Megaphone, general: Bell }[n.cat];
  const tone: Tone = { attendance: "ok", homework: "brand", exam: "violet", fee: "warn", notice: "sky", general: "mute" }[n.cat] as Tone;
  return (
    <button onClick={onClick} className={`flex w-full gap-3 px-4 py-3.5 text-left active:bg-slate-50 ${read ? "" : "bg-brand-soft/40"}`}>
      <IconTile icon={icon} tone={tone} />
      <div className="min-w-0 flex-1">
        <div className={`text-[14px] leading-snug text-ink ${read ? "font-medium" : "font-semibold"}`}>{n.title}</div>
        <div className="mt-0.5 text-[12.5px] leading-snug text-mute">{n.body}</div>
        <div className="mt-1 text-[11.5px] text-mute">{ago(n.at)}</div>
      </div>
      {read ? null : <span aria-label="Unread" className="mt-2 h-2.5 w-2.5 shrink-0 rounded-full bg-brand" />}
    </button>
  );
}
export function BatchCard({ b, count, extra, onClick }: { b: Batch; count: number; extra?: React.ReactNode; onClick?: () => void }) {
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex items-start gap-3"><IconTile icon={BookOpen} tone="brand" />
        <div className="min-w-0 flex-1"><div className="text-[14.5px] font-semibold leading-snug text-ink">{b.name}</div><div className="text-[12.5px] text-mute">{b.course} · {count} students</div>{extra}</div>
        <StatusBadge status={b.status} />
      </div>
    </Card>
  );
}
export const FileTextIcon = FileText;
export type { Role };
