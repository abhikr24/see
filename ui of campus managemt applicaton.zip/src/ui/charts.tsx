"use client";
import React from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { AttStatus } from "@/domain/types";
import { iso, MONTHS_LONG, pad, today } from "@/lib/fmt";
import { Tone, TONE } from "./kit";

const HEX: Record<Tone, string> = { brand: "#2f3392", ok: "#16784f", warn: "#a96a0c", bad: "#b83227", sky: "#1d9bd8", violet: "#6d5dfb", mute: "#94a3b8" };

export function Bars({ data, max, height = 120, suffix = "" }: { data: { label: string; value: number; tone?: Tone }[]; max?: number; height?: number; suffix?: string }) {
  const m = max ?? Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="flex items-end justify-between gap-2" style={{ height: height + 38 }} role="img" aria-label={data.map((d) => `${d.label} ${d.value}${suffix}`).join(", ")}>
      {data.map((d) => (
        <div key={d.label} className="flex min-w-0 flex-1 flex-col items-center justify-end gap-1">
          <span className="text-[11px] font-semibold text-ink">{d.value}{suffix}</span>
          <div className={`w-full max-w-9 rounded-t-lg ${TONE[d.tone ?? "brand"].bar}`} style={{ height: Math.max(4, (d.value / m) * height) }} />
          <span className="w-full truncate text-center text-[10.5px] text-mute">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

export function LineChart({ points, labels, max = 100, min = 0, height = 120, tone = "brand", suffix = "%" }: { points: number[]; labels?: string[]; max?: number; min?: number; height?: number; tone?: Tone; suffix?: string }) {
  const W = 300, H = height, pad_ = 14;
  if (!points.length) return null;
  const xs = (i: number) => pad_ + (points.length === 1 ? (W - 2 * pad_) / 2 : (i * (W - 2 * pad_)) / (points.length - 1));
  const ys = (v: number) => H - pad_ - ((v - min) / (max - min || 1)) * (H - 2 * pad_);
  const d = points.map((p, i) => `${i ? "L" : "M"}${xs(i).toFixed(1)},${ys(p).toFixed(1)}`).join(" ");
  const area = `${d} L${xs(points.length - 1)},${H - pad_} L${xs(0)},${H - pad_} Z`;
  const c = HEX[tone];
  return (
    <div role="img" aria-label={`Trend: ${points.map((p, i) => `${labels?.[i] ?? i + 1} ${p}${suffix}`).join(", ")}`}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full overflow-visible">
        {[0, 0.5, 1].map((g) => <line key={g} x1={pad_} x2={W - pad_} y1={pad_ + g * (H - 2 * pad_)} y2={pad_ + g * (H - 2 * pad_)} stroke="#e5e8f1" strokeDasharray="3 4" />)}
        <path d={area} fill={c} opacity={0.08} />
        <path d={d} fill="none" stroke={c} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => <g key={i}><circle cx={xs(i)} cy={ys(p)} r={4} fill="#fff" stroke={c} strokeWidth={2} /><text x={xs(i)} y={ys(p) - 9} fontSize="10" textAnchor="middle" fill="#141833" fontWeight={600}>{p}</text></g>)}
      </svg>
      {labels ? <div className="mt-1 flex justify-between px-1 text-[10.5px] text-mute">{labels.map((l, i) => <span key={i} className="truncate">{l}</span>)}</div> : null}
    </div>
  );
}

export function Donut({ value, size = 84, tone = "brand", label, sub }: { value: number; size?: number; tone?: Tone; label?: string; sub?: string }) {
  const r = size / 2 - 7, c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }} role="img" aria-label={`${label ?? "Value"} ${value}%`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#eceef6" strokeWidth={7} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={HEX[tone]} strokeWidth={7} fill="none" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c - (Math.min(100, value) / 100) * c} style={{ transition: "stroke-dashoffset .6s" }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center"><div><div className="text-[17px] font-bold leading-none text-ink">{value}%</div>{sub ? <div className="mt-0.5 text-[9.5px] text-mute">{sub}</div> : null}</div></div>
    </div>
  );
}

export function StackBar({ parts }: { parts: { label: string; value: number; tone: Tone }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0) || 1;
  return (
    <div>
      <div className="flex h-3 w-full overflow-hidden rounded-full bg-slate-100">{parts.map((p) => <div key={p.label} className={TONE[p.tone].bar} style={{ width: `${(p.value / total) * 100}%` }} />)}</div>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">{parts.map((p) => <span key={p.label} className="flex items-center gap-1.5 text-[12px] text-mute"><span className={`h-2.5 w-2.5 rounded-full ${TONE[p.tone].bar}`} />{p.label} <b className="text-ink">{p.value}</b></span>)}</div>
    </div>
  );
}

export const ATT_META: Record<AttStatus, { label: string; tone: Tone; letter: string }> = {
  P: { label: "Present", tone: "ok", letter: "P" }, A: { label: "Absent", tone: "bad", letter: "A" }, L: { label: "Late", tone: "warn", letter: "L" },
};
export function AttPill({ status }: { status?: AttStatus }) {
  if (!status) return <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-semibold text-mute">Not marked</span>;
  const m = ATT_META[status];
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold ${TONE[m.tone].bg} ${TONE[m.tone].fg}`}><b>{m.letter}</b> {m.label}</span>;
}

export function MonthCalendar({ year, month, marks, onChange }: { year: number; month: number; marks: Record<string, AttStatus | "H">; onChange: (y: number, m: number) => void }) {
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const t = today();
  const nav = (d: number) => { const n = new Date(year, month + d, 1); onChange(n.getFullYear(), n.getMonth()); };
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <button aria-label="Previous month" onClick={() => nav(-1)} className="grid h-10 w-10 place-items-center rounded-full active:bg-slate-100"><ChevronLeft size={20} /></button>
        <span className="text-[15px] font-semibold text-ink">{MONTHS_LONG[month]} {year}</span>
        <button aria-label="Next month" onClick={() => nav(1)} className="grid h-10 w-10 place-items-center rounded-full active:bg-slate-100"><ChevronRight size={20} /></button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-medium text-mute">{["S", "M", "T", "W", "T", "F", "S"].map((d, i) => <div key={i} className="py-1">{d}</div>)}</div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((c, i) => {
          if (!c) return <div key={i} />;
          const key = iso(new Date(year, month, c));
          const m = marks[key];
          const tone = m === "P" ? "bg-ok-soft text-ok" : m === "A" ? "bg-bad-soft text-bad" : m === "L" ? "bg-warn-soft text-warn" : "bg-transparent text-ink";
          return (
            <div key={i} aria-label={`${c} ${MONTHS_LONG[month]}${m ? `: ${m === "H" ? "Holiday" : ATT_META[m].label}` : ""}`} className={`flex h-11 flex-col items-center justify-center rounded-lg text-[13px] font-medium ${tone} ${key === t ? "ring-2 ring-brand" : ""}`}>
              <span>{pad(c).replace(/^0/, "")}</span>
              {m && m !== "H" ? <span className="text-[9px] font-bold leading-none">{m}</span> : m === "H" ? <span className="text-[9px] leading-none text-mute">Off</span> : null}
            </div>
          );
        })}
      </div>
      <div className="mt-3 flex justify-center gap-4 text-[11.5px] text-mute">{(["P", "A", "L"] as AttStatus[]).map((s) => <span key={s} className="flex items-center gap-1.5"><span className={`grid h-5 w-5 place-items-center rounded text-[10px] font-bold ${TONE[ATT_META[s].tone].bg} ${TONE[ATT_META[s].tone].fg}`}>{s}</span>{ATT_META[s].label}</span>)}</div>
    </div>
  );
}
