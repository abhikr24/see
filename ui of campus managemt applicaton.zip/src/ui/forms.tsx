"use client";
import React, { ReactNode, useEffect, useRef, useState } from "react";
import { Calendar, Check, ChevronDown, Clock, Eye, EyeOff, File as FileIcon, FileText, Image as ImageIcon, Link2, Paperclip, RotateCcw, Search, X } from "lucide-react";
import type { FileMeta } from "@/domain/types";
import { dmy, fileSize, time12 } from "@/lib/fmt";
import { Sheet } from "./kit";

/* ───────── form state helper ───────── */
export function useForm<T extends Record<string, any>>(init: T, validate?: (v: T) => Partial<Record<keyof T, string | undefined>>) {
  const [v, setV] = useState<T>(init);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [all, setAll] = useState(false);
  const errs = (validate ? validate(v) : {}) as Record<string, string | undefined>;
  const errors = Object.fromEntries(Object.entries(errs).filter(([, m]) => !!m)) as Record<string, string>;
  const set = <K extends keyof T>(k: K, val: T[K]) => setV((p) => ({ ...p, [k]: val }));
  const bind = <K extends keyof T>(k: K) => ({
    value: v[k] as any, onChange: (x: any) => set(k, x), onBlur: () => setTouched((p) => ({ ...p, [k as string]: true })),
    error: touched[k as string] || all ? errors[k as string] : undefined,
  });
  return { v, set, setV, bind, errors, valid: Object.keys(errors).length === 0, touchAll: () => setAll(true), dirty: JSON.stringify(v) !== JSON.stringify(init) };
}

/* ───────── fields ───────── */
export function Field({ label, required, error, hint, children }: { label?: string; required?: boolean; error?: string; hint?: string; children: ReactNode }) {
  return (
    <div className="block">
      {label ? <div className="mb-1.5 text-[13px] font-semibold text-ink">{label}{required ? <span className="ml-0.5 text-bad" aria-label="required">*</span> : <span className="ml-1 text-[11px] font-normal text-mute">(optional)</span>}</div> : null}
      {children}
      {error ? <p role="alert" className="mt-1.5 text-[12px] font-medium text-bad">{error}</p> : hint ? <p className="mt-1.5 text-[12px] text-mute">{hint}</p> : null}
    </div>
  );
}
const inputCls = (error?: string) => `w-full rounded-xl border bg-white px-3.5 text-[15px] text-ink outline-none placeholder:text-slate-400 focus:border-brand focus:ring-2 focus:ring-brand/15 ${error ? "border-bad" : "border-line"}`;

export function TextInput({ label, required, value, onChange, onBlur, error, hint, placeholder, inputMode, type = "text", multiline, rows = 3, prefix, maxLength, autoFocus, disabled, autoComplete }: {
  label?: string; required?: boolean; value: string; onChange: (v: string) => void; onBlur?: () => void; error?: string; hint?: string; placeholder?: string;
  inputMode?: "text" | "numeric" | "tel" | "email" | "decimal"; type?: string; multiline?: boolean; rows?: number; prefix?: string; maxLength?: number; autoFocus?: boolean; disabled?: boolean; autoComplete?: string;
}) {
  return (
    <Field label={label} required={required} error={error} hint={hint}>
      <div className="relative flex">
        {prefix ? <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[15px] font-medium text-mute">{prefix}</span> : null}
        {multiline ? (
          <textarea value={value} rows={rows} maxLength={maxLength} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} onBlur={onBlur} disabled={disabled} aria-label={label} className={`${inputCls(error)} py-3 leading-relaxed`} />
        ) : (
          <input value={value} type={type} inputMode={inputMode} maxLength={maxLength} placeholder={placeholder} autoFocus={autoFocus} disabled={disabled} autoComplete={autoComplete} aria-label={label} aria-invalid={!!error}
            onChange={(e) => onChange(e.target.value)} onBlur={onBlur} className={`${inputCls(error)} h-12 disabled:bg-slate-50 ${prefix ? "pl-14" : ""}`} />
        )}
      </div>
    </Field>
  );
}
export function PasswordInput({ label = "Password", ...p }: { label?: string; required?: boolean; value: string; onChange: (v: string) => void; onBlur?: () => void; error?: string; hint?: string; placeholder?: string }) {
  const [show, setShow] = useState(false);
  return (
    <Field label={label} required={p.required} error={p.error} hint={p.hint}>
      <div className="relative">
        <input value={p.value} type={show ? "text" : "password"} placeholder={p.placeholder ?? "Enter password"} aria-label={label} autoComplete="current-password"
          onChange={(e) => p.onChange(e.target.value)} onBlur={p.onBlur} className={`${inputCls(p.error)} h-12 pr-12`} />
        <button type="button" onClick={() => setShow(!show)} aria-label={show ? "Hide password" : "Show password"} className="absolute right-1 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center text-mute">
          {show ? <EyeOff size={19} /> : <Eye size={19} />}
        </button>
      </div>
    </Field>
  );
}
export function SearchInput({ value, onChange, placeholder = "Search", autoFocus, onSubmit }: { value: string; onChange: (v: string) => void; placeholder?: string; autoFocus?: boolean; onSubmit?: () => void }) {
  return (
    <div className="relative">
      <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
      <input value={value} autoFocus={autoFocus} placeholder={placeholder} aria-label={placeholder} enterKeyHint="search" onChange={(e) => onChange(e.target.value)} onKeyDown={(e) => e.key === "Enter" && onSubmit?.()}
        className="h-11 w-full rounded-xl border border-line bg-white pl-10 pr-10 text-[15px] outline-none placeholder:text-slate-400 focus:border-brand focus:ring-2 focus:ring-brand/15" />
      {value ? <button onClick={() => onChange("")} aria-label="Clear search" className="absolute right-1 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center text-mute"><X size={17} /></button> : null}
    </div>
  );
}

type Opt = string | { value: string; label: string; sub?: string };
export function Select({ label, required, value, onChange, options, placeholder = "Select", error, onBlur, hint }: { label?: string; required?: boolean; value: string; onChange: (v: string) => void; options: Opt[]; placeholder?: string; error?: string; onBlur?: () => void; hint?: string }) {
  const [open, setOpen] = useState(false);
  const opts = options.map((o) => (typeof o === "string" ? { value: o, label: o, sub: undefined as string | undefined } : { sub: undefined as string | undefined, ...o }));
  const cur = opts.find((o) => o.value === value);
  return (
    <Field label={label} required={required} error={error} hint={hint}>
      <button type="button" onClick={() => setOpen(true)} aria-haspopup="listbox" aria-label={label ?? placeholder} className={`${inputCls(error)} flex h-12 items-center justify-between text-left`}>
        <span className={`truncate ${cur ? "text-ink" : "text-slate-400"}`}>{cur?.label ?? placeholder}</span>
        <ChevronDown size={18} className="shrink-0 text-mute" />
      </button>
      <Sheet open={open} onClose={() => { setOpen(false); onBlur?.(); }} title={label ?? placeholder}>
        <div role="listbox" className="-mx-1">
          {opts.length === 0 ? <p className="py-6 text-center text-[13px] text-mute">No options available.</p> : null}
          {opts.map((o) => (
            <button key={o.value} role="option" aria-selected={o.value === value} onClick={() => { onChange(o.value); setOpen(false); onBlur?.(); }} className="flex min-h-12 w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-left active:bg-slate-50">
              <span className="min-w-0"><span className={`block text-[15px] ${o.value === value ? "font-semibold text-brand" : "text-ink"}`}>{o.label}</span>{o.sub ? <span className="block text-[12px] text-mute">{o.sub}</span> : null}</span>
              {o.value === value ? <Check size={18} className="shrink-0 text-brand" /> : null}
            </button>
          ))}
        </div>
      </Sheet>
    </Field>
  );
}

function NativePicker({ kind, label, required, value, onChange, error, min, max, onBlur }: { kind: "date" | "time"; label?: string; required?: boolean; value: string; onChange: (v: string) => void; error?: string; min?: string; max?: string; onBlur?: () => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const open = () => { try { ref.current?.showPicker?.(); } catch { ref.current?.focus(); } };
  const Icon = kind === "date" ? Calendar : Clock;
  return (
    <Field label={label} required={required} error={error}>
      <div className="relative">
        <button type="button" onClick={open} aria-label={label ?? kind} className={`${inputCls(error)} flex h-12 items-center justify-between text-left`}>
          <span className={value ? "text-ink" : "text-slate-400"}>{value ? (kind === "date" ? dmy(value) : time12(value)) : kind === "date" ? "DD/MM/YYYY" : "HH:MM AM/PM"}</span>
          <Icon size={18} className="text-mute" />
        </button>
        <input ref={ref} type={kind} value={value} min={min} max={max} tabIndex={-1} aria-hidden onChange={(e) => onChange(e.target.value)} onBlur={onBlur} className="pointer-events-none absolute inset-0 h-full w-full opacity-0" />
      </div>
    </Field>
  );
}
export const DatePicker = (p: Omit<Parameters<typeof NativePicker>[0], "kind">) => <NativePicker kind="date" {...p} />;
export const TimePicker = (p: Omit<Parameters<typeof NativePicker>[0], "kind">) => <NativePicker kind="time" {...p} />;

export function Switch({ checked, onChange, label, sub }: { checked: boolean; onChange: (v: boolean) => void; label: string; sub?: string }) {
  return (
    <button role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className="flex min-h-14 w-full items-center gap-3 px-4 py-2.5 text-left">
      <span className="min-w-0 flex-1"><span className="block text-[15px] font-medium text-ink">{label}</span>{sub ? <span className="block text-[12.5px] text-mute">{sub}</span> : null}</span>
      <span className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${checked ? "bg-brand" : "bg-slate-300"}`}>
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? "left-6" : "left-1"}`} />
      </span>
    </button>
  );
}
export function Checkbox({ checked, onChange, children }: { checked: boolean; onChange: (v: boolean) => void; children: ReactNode }) {
  return (
    <button type="button" role="checkbox" aria-checked={checked} onClick={() => onChange(!checked)} className="flex min-h-11 items-start gap-3 text-left">
      <span className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md border ${checked ? "border-brand bg-brand text-white" : "border-slate-300 bg-white"}`}>{checked ? <Check size={14} /> : null}</span>
      <span className="text-[13.5px] leading-snug text-ink">{children}</span>
    </button>
  );
}
export function OtpInput({ value, onChange, error, length = 6 }: { value: string; onChange: (v: string) => void; error?: boolean; length?: number }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="relative" onClick={() => ref.current?.focus()}>
      <div className="flex justify-between gap-2">
        {Array.from({ length }).map((_, i) => (
          <div key={i} className={`grid h-14 flex-1 place-items-center rounded-xl border-2 bg-white text-[22px] font-bold ${error ? "border-bad text-bad" : value.length === i ? "border-brand" : "border-line"}`}>{value[i] ?? ""}</div>
        ))}
      </div>
      <input ref={ref} value={value} inputMode="numeric" autoComplete="one-time-code" maxLength={length} aria-label="One-time code" autoFocus
        onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, length))} className="absolute inset-0 h-full w-full opacity-0" />
    </div>
  );
}

/* ───────── files ───────── */
export const fileIcon = (t: string) => (t.includes("pdf") ? FileText : t.startsWith("image") ? ImageIcon : t === "link" ? Link2 : FileIcon);
export function FileItem({ file, right, onClick }: { file: FileMeta; right?: ReactNode; onClick?: () => void }) {
  const inner = (
    <>
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand">{file.type.includes("pdf") ? <FileText size={20} /> : file.type.startsWith("image") ? <ImageIcon size={20} /> : <FileIcon size={20} />}</span>
      <span className="min-w-0 flex-1 text-left"><span className="block truncate text-[14px] font-medium text-ink">{file.name}</span><span className="text-[12px] text-mute">{file.type.split("/")[1]?.toUpperCase() || "FILE"} · {fileSize(file.size)}</span></span>
      {right}
    </>
  );
  const cls = "flex w-full items-center gap-3 rounded-xl border border-line bg-white p-3";
  return onClick ? <button onClick={onClick} className={cls}>{inner}</button> : <div className={cls}>{inner}</div>;
}
export function FilePicker({ label = "Attachment", required, value, onChange, accept }: { label?: string; required?: boolean; value: FileMeta | null; onChange: (f: FileMeta | null) => void; accept?: string }) {
  const ref = useRef<HTMLInputElement>(null);
  const [progress, setProgress] = useState(100);
  const [failed, setFailed] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => () => { if (timer.current) clearInterval(timer.current); }, []);
  const run = () => {
    setProgress(0);
    timer.current = setInterval(() => setProgress((p) => { if (p >= 100) { if (timer.current) clearInterval(timer.current); return 100; } return p + 20; }), 220);
  };
  const pick = (f?: File) => {
    if (!f) return;
    if (f.size > 10 * 1048576) { setFailed("File is larger than 10 MB. Choose a smaller file."); onChange(null); return; }
    setFailed(null); onChange({ name: f.name, size: f.size, type: f.type || "application/octet-stream" }); run();
  };
  return (
    <Field label={label} required={required}>
      <input ref={ref} type="file" accept={accept} className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ""; }} />
      {value ? (
        <div className="rounded-xl border border-line bg-white p-3">
          <FileItem file={value} right={<button onClick={() => { onChange(null); setProgress(100); }} aria-label="Remove file" className="grid h-9 w-9 place-items-center text-mute"><X size={18} /></button>} />
          <div className="mt-2.5 flex items-center gap-2 text-[11.5px] text-mute">
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-brand transition-all" style={{ width: `${progress}%` }} /></div>
            <span>{progress < 100 ? `${progress}%` : "Ready"}</span>
          </div>
          <p className="mt-1.5 text-[11.5px] text-warn">Demo only — this file is kept on your device and not uploaded to any cloud.</p>
        </div>
      ) : (
        <button type="button" onClick={() => ref.current?.click()} className="flex min-h-14 w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-300 bg-white text-[14px] font-semibold text-brand active:bg-brand-soft">
          <Paperclip size={18} /> Choose file
        </button>
      )}
      {failed ? <div className="mt-2 flex items-center justify-between rounded-lg bg-bad-soft px-3 py-2 text-[12.5px] text-bad"><span>{failed}</span><button onClick={() => ref.current?.click()} className="flex items-center gap-1 font-semibold"><RotateCcw size={13} />Retry</button></div> : null}
    </Field>
  );
}
