"use client";
import React, { ReactNode, useState } from "react";
import { createPortal } from "react-dom";
import type { LucideIcon } from "lucide-react";
import { AlertTriangle, ChevronLeft, ChevronRight, Info, Inbox, Loader2, Lock, RefreshCw, WifiOff, X, CheckCircle2 } from "lucide-react";
import { useApp } from "@/state/app";
import { initials } from "@/lib/fmt";

export type Tone = "brand" | "ok" | "warn" | "bad" | "sky" | "mute" | "violet";
export const TONE: Record<Tone, { bg: string; fg: string; bar: string }> = {
  brand: { bg: "bg-brand-soft", fg: "text-brand", bar: "bg-brand" },
  ok: { bg: "bg-ok-soft", fg: "text-ok", bar: "bg-ok" },
  warn: { bg: "bg-warn-soft", fg: "text-warn", bar: "bg-warn" },
  bad: { bg: "bg-bad-soft", fg: "text-bad", bar: "bg-bad" },
  sky: { bg: "bg-sky-soft", fg: "text-sky", bar: "bg-sky" },
  violet: { bg: "bg-violet-soft", fg: "text-violet", bar: "bg-violet" },
  mute: { bg: "bg-slate-100", fg: "text-mute", bar: "bg-slate-400" },
};

/* ───────── Buttons ───────── */
export function Btn({ children, onClick, variant = "primary", size = "md", loading, disabled, icon: Icon, full = true, type = "button", className = "", label }: {
  children?: ReactNode; onClick?: () => void; variant?: "primary" | "secondary" | "ghost" | "danger" | "soft"; size?: "sm" | "md"; loading?: boolean; disabled?: boolean;
  icon?: LucideIcon; full?: boolean; type?: "button" | "submit"; className?: string; label?: string;
}) {
  const v = {
    primary: "bg-brand text-white active:bg-brand-dark disabled:bg-slate-300",
    secondary: "bg-white text-brand border border-brand/25 active:bg-brand-soft disabled:text-slate-400 disabled:border-line",
    soft: "bg-brand-soft text-brand active:bg-indigo-100 disabled:text-slate-400",
    ghost: "bg-transparent text-brand active:bg-brand-soft disabled:text-slate-400",
    danger: "bg-bad text-white active:bg-red-800 disabled:bg-slate-300",
  }[variant];
  return (
    <button type={type} aria-label={label} onClick={onClick} disabled={disabled || loading}
      className={`${full ? "w-full" : ""} ${size === "sm" ? "min-h-10 px-3.5 text-[13px]" : "min-h-12 px-5 text-[15px]"} inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-colors ${v} ${className}`}>
      {loading ? <Loader2 size={18} className="animate-spin" /> : Icon ? <Icon size={size === "sm" ? 16 : 18} /> : null}
      {children}
    </button>
  );
}
export function IconBtn({ icon: Icon, onClick, label, tone = "plain", badge }: { icon: LucideIcon; onClick?: () => void; label: string; tone?: "plain" | "soft" | "dark"; badge?: number }) {
  return (
    <button aria-label={label} onClick={onClick} className={`relative grid h-11 w-11 shrink-0 place-items-center rounded-full ${tone === "soft" ? "bg-brand-soft text-brand" : tone === "dark" ? "bg-white/15 text-white" : "text-ink active:bg-slate-200/70"}`}>
      <Icon size={22} />
      {badge ? <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-bad px-1 text-[10px] font-bold text-white">{badge > 9 ? "9+" : badge}</span> : null}
    </button>
  );
}

/* ───────── Surfaces ───────── */
export function Card({ children, className = "", onClick, pad = true }: { children: ReactNode; className?: string; onClick?: () => void; pad?: boolean }) {
  const cls = `block w-full rounded-2xl border border-line bg-white text-left shadow-[0_1px_2px_rgba(20,24,51,0.04)] ${pad ? "p-4" : ""} ${onClick ? "active:bg-slate-50" : ""} ${className}`;
  return onClick ? <button onClick={onClick} className={cls}>{children}</button> : <div className={cls}>{children}</div>;
}
export function Badge({ children, tone = "mute", icon: Icon }: { children: ReactNode; tone?: Tone; icon?: LucideIcon }) {
  const t = TONE[tone];
  return <span className={`inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-semibold ${t.bg} ${t.fg}`}>{Icon ? <Icon size={12} /> : null}{children}</span>;
}
export function Avatar({ name, size = 40, tone = "brand" }: { name: string; size?: number; tone?: Tone }) {
  const t = TONE[tone];
  return <span aria-hidden className={`grid shrink-0 place-items-center rounded-full font-semibold ${t.bg} ${t.fg}`} style={{ width: size, height: size, fontSize: size * 0.36 }}>{initials(name)}</span>;
}
export function IconTile({ icon: Icon, tone = "brand", size = 40 }: { icon: LucideIcon; tone?: Tone; size?: number }) {
  const t = TONE[tone];
  return <span className={`grid shrink-0 place-items-center rounded-xl ${t.bg} ${t.fg}`} style={{ width: size, height: size }}><Icon size={size * 0.5} /></span>;
}
export function Divider() { return <div className="h-px w-full bg-line" />; }

export function Section({ title, action, onAction, children, className = "" }: { title?: string; action?: string; onAction?: () => void; children: ReactNode; className?: string }) {
  return (
    <section className={`mt-5 ${className}`}>
      {title ? (
        <div className="mb-2 flex items-center justify-between px-0.5">
          <h2 className="text-[15px] font-semibold text-ink">{title}</h2>
          {action ? <button onClick={onAction} className="min-h-8 text-[13px] font-semibold text-brand">{action}</button> : null}
        </div>
      ) : null}
      {children}
    </section>
  );
}
export function Row({ icon, title, sub, right, onClick, tone = "brand", lead, noChevron }: { icon?: LucideIcon; title: ReactNode; sub?: ReactNode; right?: ReactNode; onClick?: () => void; tone?: Tone; lead?: ReactNode; noChevron?: boolean }) {
  const inner = (
    <>
      {lead ?? (icon ? <IconTile icon={icon} tone={tone} /> : null)}
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[15px] font-medium text-ink">{title}</span>
        {sub ? <span className="mt-0.5 block text-[12.5px] leading-snug text-mute">{sub}</span> : null}
      </span>
      {right}
      {onClick && !noChevron ? <ChevronRight size={18} className="shrink-0 text-slate-400" /> : null}
    </>
  );
  const cls = "flex min-h-14 w-full items-center gap-3 px-4 py-3 text-left";
  return onClick ? <button onClick={onClick} className={`${cls} active:bg-slate-50`}>{inner}</button> : <div className={cls}>{inner}</div>;
}
export function List({ children }: { children: ReactNode }) {
  const items = React.Children.toArray(children).filter(Boolean);
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-white shadow-[0_1px_2px_rgba(20,24,51,0.04)]">
      {items.map((c, i) => <div key={i} className={i ? "border-t border-line" : ""}>{c}</div>)}
    </div>
  );
}
export function Stat({ label, value, sub, tone = "brand", icon: Icon, onClick }: { label: string; value: ReactNode; sub?: ReactNode; tone?: Tone; icon?: LucideIcon; onClick?: () => void }) {
  return (
    <Card onClick={onClick} className="!p-3.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[12px] font-medium text-mute">{label}</span>
        {Icon ? <Icon size={16} className={TONE[tone].fg} /> : null}
      </div>
      <div className="mt-1.5 text-[24px] font-bold leading-none tracking-tight text-ink">{value}</div>
      {sub ? <div className={`mt-1.5 text-[11.5px] font-medium ${tone === "mute" || tone === "brand" ? "text-mute" : TONE[tone].fg}`}>{sub}</div> : null}
    </Card>
  );
}
export function Kv({ k, v }: { k: string; v: ReactNode }) {
  return <div className="flex items-start justify-between gap-4 py-2 text-[14px]"><span className="text-mute">{k}</span><span className="text-right font-medium text-ink">{v}</span></div>;
}
export function Progress({ value, tone = "brand", label, height = 8 }: { value: number; tone?: Tone; label?: string; height?: number }) {
  return (
    <div role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100} aria-label={label} className="w-full overflow-hidden rounded-full bg-slate-100" style={{ height }}>
      <div className={`h-full rounded-full transition-all duration-500 ${TONE[tone].bar}`} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}
export function Banner({ children, tone = "sky", icon: Icon = Info }: { children: ReactNode; tone?: Tone; icon?: LucideIcon }) {
  return <div className={`flex gap-2.5 rounded-xl px-3.5 py-3 text-[12.5px] leading-snug ${TONE[tone].bg} ${TONE[tone].fg}`}><Icon size={16} className="mt-0.5 shrink-0" /><div className="min-w-0">{children}</div></div>;
}
export const DemoTag = () => <Badge tone="warn">DEMO</Badge>;

/* ───────── Page / header ───────── */
export function Page({ title, subtitle, right, children, footer, pad = true, hero }: { title: string; subtitle?: string; right?: ReactNode; children: ReactNode; footer?: ReactNode; pad?: boolean; hero?: ReactNode }) {
  const { stack, back } = useApp();
  const canBack = stack.length > 1;
  return (
    <div className="flex h-full flex-col bg-bg">
      <header className="flex shrink-0 items-center gap-1 bg-bg px-2 pb-1 pt-2">
        {canBack ? <IconBtn icon={ChevronLeft} label="Go back" onClick={back} /> : <span className="w-2" />}
        <div className="min-w-0 flex-1 px-1">
          <h1 className={`truncate font-bold tracking-tight text-ink ${canBack ? "text-[18px]" : "text-[24px]"}`}>{title}</h1>
          {subtitle ? <p className="truncate text-[12.5px] text-mute">{subtitle}</p> : null}
        </div>
        {right}
      </header>
      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto overscroll-contain">
        {hero}
        <div className={pad ? "px-4 pb-8 pt-1" : ""}>{children}</div>
      </div>
      {footer ? <div className="shrink-0 border-t border-line bg-white px-4 py-3">{footer}</div> : null}
    </div>
  );
}

/* ───────── States ───────── */
export function Empty({ icon: Icon = Inbox, title, body, action, onAction }: { icon?: LucideIcon; title: string; body?: string; action?: string; onAction?: () => void }) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-soft text-brand"><Icon size={28} /></span>
      <h3 className="mt-4 text-[16px] font-semibold text-ink">{title}</h3>
      {body ? <p className="mt-1 max-w-[260px] text-[13px] leading-relaxed text-mute">{body}</p> : null}
      {action ? <div className="mt-5"><Btn full={false} size="sm" onClick={onAction}>{action}</Btn></div> : null}
    </div>
  );
}
export function ErrorState({ title = "Something went wrong", body = "We couldn't load this right now. Please check your connection and try again.", onRetry, icon: Icon = AlertTriangle }: { title?: string; body?: string; onRetry?: () => void; icon?: LucideIcon }) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-2xl bg-bad-soft text-bad"><Icon size={28} /></span>
      <h3 className="mt-4 text-[16px] font-semibold text-ink">{title}</h3>
      <p className="mt-1 max-w-[270px] text-[13px] leading-relaxed text-mute">{body}</p>
      {onRetry ? <div className="mt-5"><Btn full={false} size="sm" icon={RefreshCw} onClick={onRetry}>Try again</Btn></div> : null}
    </div>
  );
}
export const Denied = ({ body = "Your role doesn't have access to this area. Ask the institute owner if you need it." }: { body?: string }) => (
  <ErrorState icon={Lock} title="Access not permitted" body={body} />
);
export function Skeleton({ className = "h-4 w-full" }: { className?: string }) { return <div className={`skeleton rounded-lg ${className}`} />; }
export function SkeletonList({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-3" aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 rounded-2xl border border-line bg-white p-4">
          <Skeleton className="h-10 w-10 !rounded-full" />
          <div className="flex-1 space-y-2"><Skeleton className="h-3.5 w-2/3" /><Skeleton className="h-3 w-1/2" /></div>
        </div>
      ))}
    </div>
  );
}

/* ───────── Overlays (rendered inside the phone frame) ───────── */
export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: ReactNode }) {
  const { host } = useApp();
  if (!open || !host) return null;
  return createPortal(
    <div className="absolute inset-0 z-40 flex items-end" role="dialog" aria-modal="true" aria-label={title}>
      <div className="anim-fade absolute inset-0 bg-ink/45" onClick={onClose} />
      <div className="anim-up relative max-h-[86%] w-full overflow-y-auto rounded-t-3xl bg-white px-4 pb-6 pt-2 shadow-2xl">
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-slate-200" />
        {title ? (
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-[17px] font-bold text-ink">{title}</h3>
            <IconBtn icon={X} label="Close" onClick={onClose} />
          </div>
        ) : null}
        {children}
      </div>
    </div>,
    host,
  );
}
export function Dialog({ open, onClose, title, body, children }: { open: boolean; onClose: () => void; title: string; body?: ReactNode; children?: ReactNode }) {
  const { host } = useApp();
  if (!open || !host) return null;
  return createPortal(
    <div className="absolute inset-0 z-50 grid place-items-center p-6" role="alertdialog" aria-modal="true" aria-label={title}>
      <div className="anim-fade absolute inset-0 bg-ink/50" onClick={onClose} />
      <div className="anim-pop relative w-full rounded-3xl bg-white p-5 shadow-2xl">
        <h3 className="text-[17px] font-bold text-ink">{title}</h3>
        {body ? <p className="mt-1.5 text-[13.5px] leading-relaxed text-mute">{body}</p> : null}
        <div className="mt-4">{children}</div>
      </div>
    </div>,
    host,
  );
}
export function Overlays() {
  const { toasts, confirmState, closeConfirm } = useApp();
  const [busy, setBusy] = useState(false);
  return (
    <>
      <Dialog open={!!confirmState} onClose={closeConfirm} title={confirmState?.title ?? ""} body={confirmState?.body}>
        <div className="flex gap-2">
          <Btn variant="secondary" onClick={closeConfirm}>Cancel</Btn>
          <Btn variant={confirmState?.danger ? "danger" : "primary"} loading={busy} onClick={async () => { setBusy(true); try { await confirmState?.onConfirm(); } finally { setBusy(false); closeConfirm(); } }}>
            {confirmState?.confirmLabel ?? "Confirm"}
          </Btn>
        </div>
      </Dialog>
      <div className="pointer-events-none absolute inset-x-0 bottom-24 z-[60] flex flex-col items-center gap-2 px-4" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className="anim-pop flex max-w-full items-center gap-2 rounded-xl bg-ink px-4 py-3 text-[13px] font-medium text-white shadow-xl">
            {t.tone === "ok" ? <CheckCircle2 size={16} className="shrink-0 text-emerald-300" /> : t.tone === "bad" ? <AlertTriangle size={16} className="shrink-0 text-red-300" /> : <Info size={16} className="shrink-0 text-sky-300" />}
            <span>{t.text}</span>
          </div>
        ))}
      </div>
    </>
  );
}
export function OfflineBanner() {
  const { offline, online } = useApp();
  if (!offline && online) return null;
  return <div className="flex items-center justify-center gap-2 bg-warn px-3 py-1.5 text-[12px] font-semibold text-white"><WifiOff size={14} />You're offline — showing saved data</div>;
}

/* ───────── Selection controls ───────── */
export function Segmented<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: string }[] }) {
  return (
    <div role="tablist" className="flex rounded-xl bg-slate-200/60 p-1">
      {options.map((o) => (
        <button key={o.value} role="tab" aria-selected={value === o.value} onClick={() => onChange(o.value)}
          className={`min-h-9 flex-1 rounded-lg px-2 text-[13px] font-semibold transition-all ${value === o.value ? "bg-white text-brand shadow-sm" : "text-mute"}`}>{o.label}</button>
      ))}
    </div>
  );
}
export function Tabs<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: string; count?: number }[] }) {
  return (
    <div role="tablist" className="no-scrollbar -mx-4 flex gap-1 overflow-x-auto border-b border-line px-4">
      {options.map((o) => (
        <button key={o.value} role="tab" aria-selected={value === o.value} onClick={() => onChange(o.value)}
          className={`relative min-h-11 shrink-0 px-3 text-[14px] font-semibold ${value === o.value ? "text-brand" : "text-mute"}`}>
          {o.label}{o.count !== undefined ? <span className="ml-1 text-[11px] opacity-70">{o.count}</span> : null}
          {value === o.value ? <span className="absolute inset-x-2 bottom-0 h-0.5 rounded-full bg-brand" /> : null}
        </button>
      ))}
    </div>
  );
}
export function Chips<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: string }[] | readonly T[] }) {
  const opts = (options as any[]).map((o) => (typeof o === "string" ? { value: o as T, label: o } : o)) as { value: T; label: string }[];
  return (
    <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 py-1">
      {opts.map((o) => (
        <button key={o.value} onClick={() => onChange(o.value)} aria-pressed={value === o.value}
          className={`min-h-9 shrink-0 rounded-full border px-3.5 text-[13px] font-medium ${value === o.value ? "border-brand bg-brand text-white" : "border-line bg-white text-mute"}`}>{o.label}</button>
      ))}
    </div>
  );
}
export function FilterBar({ active, onClear, children }: { active: number; onClear: () => void; children: ReactNode }) {
  return (
    <div className="mt-2 flex items-center gap-2">
      <div className="flex min-w-0 flex-1 gap-2">{children}</div>
      {active > 0 ? <button onClick={onClear} className="min-h-9 shrink-0 text-[12.5px] font-semibold text-bad">Clear ({active})</button> : null}
    </div>
  );
}
export function Back({ label = "Back" }: { label?: string }) {
  const { back } = useApp();
  return <Btn variant="ghost" icon={ChevronLeft} full={false} size="sm" onClick={back}>{label}</Btn>;
}
