# GuruFlow — project rules

## What this is
Coaching-management app for India. One Expo app, four roles: owner, teacher,
student, parent. A student can belong to MULTIPLE institutes.

## Architecture — non-negotiable
- File-based routes under app/. TypeScript strict, no `any`.
- UI NEVER imports a backend SDK. UI calls domain hooks only.
- All data access goes through src/core/contracts/ interfaces, implemented in
  src/adapters/<vendor>/ and src/backends/.
- Domain types are plain TS objects. Never expose a DB row type or SDK type
  above the adapter layer.
- All errors normalise to BackendError { code, message } before reaching UI.
- NativeWind classes + theme tokens from src/lib/theme.ts. No hex outside theme.ts.

## Tenancy rule (the most important rule in the project)
A user is NOT tied to one institute. Never store org_id on profiles.
Membership lives in memberships(user_id, institute_id, role, status).
status = pending | active | rejected. Pending users see only the waiting
screen. One user may hold 3 active memberships and switch between them.
Every tenant table has institute_id, and every query is institute-scoped.

## Design system — never deviate
canvas #F5F6FA · surface #FFFFFF · ink #0B1220 · secondary #5A6684
muted #94A0BC · hairline #E7EBF5 · primary #101B4C · accent #FF7A1A
teal #0D9488 · success #16A34A · warning #F59E0B · danger #DC2626
card radius 20 · button 16 · input 14 · chip full · side margin 20
card padding 18 · shadow 0 8px 24px rgba(16,27,76,.08)
Headings: Satoshi / General Sans 700–800. Body: Plus Jakarta Sans.
Tabular numerals. ₹ with Indian grouping (₹1,24,500).

Three design laws:
1. One focal point per screen. Everything else is quieter than it.
2. Depth from 1px hairlines and whitespace, never from stacked shadows.
3. On a data screen the biggest element is a number, not an icon.

Colour roles: navy = structure (hero, primary button, active state).
Saffron = spotlight, maximum two per screen. Teal/amber/red = data state only,
never decoration. White cards on #F5F6FA; never a white background.

## Seed data — the single source of truth
Names and numbers live in supabase/seed.sql only.
Institute: Sunrise Coaching Classes, Patna, Bihar, code SUNRISE-PAT
Owner: Rahul Sharma
Teachers: Rohit Verma (Maths), Priya Nair (Physics), Meera Iyer (Chemistry),
          Sneha Iyer (English), Arun Kumar (Biology)
Students (Class 10-A): Aarav Sharma (Roll 14), Ishita Bose (15),
  Kabir Singh (16), Ananya Gupta (17), Ritesh Mehta (18), Zoya Ahmed (19),
  Kabeer Singh (20), Diya Patel (21), Manav Sethi (22), Priya Menon (23),
  Rohan Das (24), Sara Khan (25)

Attendance: 46 present / 1 late / 3 absent of 50 = 92%
Class 10-A: 12 students seeded, 92% attendance, 12 pending fees
Fees: Term 1 ₹4,999 paid · Term 2 ₹4,999 paid · Term 3 ₹4,999 due
Unit Test 3 (Mathematics, max 100): Aarav 86, Ishita 74, Kabir 62,
  Ananya 88, Ritesh 55, Zoya 79, Kabeer 41, Diya 93, Manav 71
  → average 72%, highest 93, lowest 41, pass rate 100%

## Behaviour rules
- Every list: skeleton, empty state, error state with retry.
- Every mutation: optimistic update, toast, rollback on failure.
- No file over 300 lines. No business logic inside a screen file.
