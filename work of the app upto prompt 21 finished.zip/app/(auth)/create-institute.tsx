import { RegisterInstituteScreen } from '@/features/onboarding/screens/RegisterInstituteScreen';
import React from 'react';

export default function CreateInstituteRoute() { return <RegisterInstituteScreen />; }
