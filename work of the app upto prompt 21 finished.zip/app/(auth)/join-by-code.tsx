import { JoinByCodeScreen } from '@/features/onboarding/screens/JoinByCodeScreen';
import React from 'react';

export default function JoinByCodeRoute() { return <JoinByCodeScreen />; }
