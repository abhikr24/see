import { LoginScreen } from '@/features/auth/screens/LoginScreen';
import React from 'react';

export default function LoginRoute() { return <LoginScreen />; }
