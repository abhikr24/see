import { OnboardingScreen } from '@/features/auth/screens/OnboardingScreen';
import React from 'react';

export default function OnboardingRoute() { return <OnboardingScreen />; }
