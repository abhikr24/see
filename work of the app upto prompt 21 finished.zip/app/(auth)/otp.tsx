import { OtpScreen } from '@/features/auth/screens/OtpScreen';
import React from 'react';

export default function OtpRoute() { return <OtpScreen />; }
