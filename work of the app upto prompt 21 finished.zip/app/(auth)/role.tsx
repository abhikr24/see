import { RoleScreen } from '@/features/auth/screens/RoleScreen';
import React from 'react';

export default function RoleRoute() { return <RoleScreen />; }
