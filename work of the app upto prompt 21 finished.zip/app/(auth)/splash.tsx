import { SplashScreen } from '@/features/auth/screens/SplashScreen';
import React from 'react';

export default function SplashRoute() { return <SplashScreen />; }
