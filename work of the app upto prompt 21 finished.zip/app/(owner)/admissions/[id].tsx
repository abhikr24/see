import React from 'react';
import { useLocalSearchParams } from 'expo-router';
import { LeadDetailScreen } from '@/features/admissions/screens/LeadDetailScreen';

export default function AdmissionDetailRoute() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  return <LeadDetailScreen id={typeof id === 'string' ? id : ''} />;
}
