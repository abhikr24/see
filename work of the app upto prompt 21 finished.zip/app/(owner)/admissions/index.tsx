export { AdmissionsListScreen as default } from '@/features/admissions/screens/AdmissionsListScreen';
