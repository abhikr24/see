export { CreateEnquiryScreen as default } from '@/features/admissions/screens/CreateEnquiryScreen';
