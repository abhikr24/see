import React from 'react';

import { ApprovalsQueueScreen } from '@/features/approvals/screens/ApprovalsQueueScreen';

export default function OwnerApprovalsRoute() {
  return <ApprovalsQueueScreen />;
}
