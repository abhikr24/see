import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { takeParamsFromRoute, type TakeRouteParams } from '@/features/attendance/links';
import { TakeAttendanceScreen } from '@/features/attendance/take';
import { todayIso } from '@/features/attendance/model';

/** Take Attendance for one batch. `date`, `period` and `subjectId` are prefilled by the caller. */
export default function TakeAttendanceRoute() {
  const params = useLocalSearchParams<TakeRouteParams & { batchId: string }>();
  return <TakeAttendanceScreen {...takeParamsFromRoute(params, todayIso())} />;
}
