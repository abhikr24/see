import React from 'react';
import { Redirect, useLocalSearchParams } from 'expo-router';

import { PickBatchScreen } from '@/features/attendance/PickBatchScreen';
import { takeAttendanceHref } from '@/features/attendance/links';
import { todayIso } from '@/features/attendance/model';

/**
 * Target of the dashboard's "Take attendance" shortcut. With `?batchId=` it
 * goes straight to that batch's register for today; without, it lists batches.
 */
export default function OwnerAttendanceRoute() {
  const { batchId, date } = useLocalSearchParams<{ batchId?: string; date?: string }>();
  if (batchId) return <Redirect href={takeAttendanceHref({ batchId, date: date || todayIso() }) as never} />;
  return <PickBatchScreen />;
}
