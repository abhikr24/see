import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { AttendanceRegisterScreen } from '@/features/attendance/register';

/** Monthly register for one batch. `?batchId=` and `?month=YYYY-MM` are optional. */
export default function AttendanceRegisterRoute() {
  const { batchId, month } = useLocalSearchParams<{ batchId?: string; month?: string }>();
  return <AttendanceRegisterScreen batchId={batchId ? String(batchId) : undefined} month={month ? String(month) : undefined} />;
}
