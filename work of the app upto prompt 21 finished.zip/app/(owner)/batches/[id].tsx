export { BatchDetailScreen as default } from '@/features/batches/BatchDetailScreen';
