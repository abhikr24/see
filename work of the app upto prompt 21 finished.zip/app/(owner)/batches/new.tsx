export { BatchCreateScreen as default } from '@/features/batches/BatchCreateScreen';
