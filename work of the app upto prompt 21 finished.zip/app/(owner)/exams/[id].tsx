export { ExamDetailScreen as default } from '@/features/exams/[id]';
