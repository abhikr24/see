import React from 'react';

import { ExamAnalysisScreen } from '@/features/exams/analysis';

export default function ExamAnalysisRoute() {
  return <ExamAnalysisScreen />;
}
