import React from 'react';
import { MarksScreen } from '@/features/exams/marks';

export default function ExamMarksRoute() {
  return <MarksScreen />;
}
