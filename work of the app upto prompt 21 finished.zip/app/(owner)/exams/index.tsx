export { ExamsListScreen as default } from '@/features/exams';
