export { ExamCreateScreen as default } from '@/features/exams/new';
