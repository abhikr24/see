export { default } from '@/features/fees/index';
