export { default } from '@/features/fees/receipt';
