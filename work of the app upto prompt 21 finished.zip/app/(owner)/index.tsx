import React from 'react';

import { OwnerDashboardScreen } from '@/features/dashboard/screens/OwnerDashboardScreen';

export default function OwnerHomeRoute() {
  return <OwnerDashboardScreen />;
}
