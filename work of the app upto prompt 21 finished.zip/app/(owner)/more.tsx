import React from 'react';
import { ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import { Badge, Card, IconBox, ListRow, Text } from '@/components/ui';
import { useAdmissionsPipeline } from '@/core/backend';
import { C, LAYOUT, S } from '@/lib/theme';

const ITEMS = [
  {
    key: 'admissions',
    title: 'Admissions',
    subtitle: 'Enquiries, follow-ups and conversions',
    icon: 'funnel-outline' as const,
    tone: 'accent' as const,
    route: '/(owner)/admissions',
  },
  {
    key: 'attendance',
    title: 'Attendance',
    subtitle: 'Take daily roll call and view registers',
    icon: 'checkbox-outline' as const,
    tone: 'primary' as const,
    route: '/(owner)/attendance',
  },
  {
    key: 'exams',
    title: 'Exams & Marks',
    subtitle: 'Schedule tests, enter marks and publish results',
    icon: 'document-text-outline' as const,
    tone: 'primary' as const,
    route: '/(owner)/exams',
  },
  {
    key: 'timetable',
    title: 'Timetable',
    subtitle: 'Weekly schedule and classroom clashes',
    icon: 'calendar-outline' as const,
    tone: 'primary' as const,
    route: '/(owner)/timetable',
  },
  {
    key: 'approvals',
    title: 'Join Approvals',
    subtitle: 'Approve pending student, parent and teacher requests',
    icon: 'person-add-outline' as const,
    tone: 'primary' as const,
    route: '/(owner)/approvals',
  },
  {
    key: 'notices',
    title: 'Notices',
    subtitle: 'Broadcast announcements to batches',
    icon: 'megaphone-outline' as const,
    tone: 'primary' as const,
    route: '/(owner)/notices',
  },
] as const;

export default function OwnerMoreRoute() {
  const pipeline = useAdmissionsPipeline();
  const openLeads = (pipeline.data?.items ?? []).filter(
    (item) => item.lead.stage !== 'enrolled' && item.lead.stage !== 'lost',
  ).length;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: C.canvas }}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 136, gap: S.lg }}
      showsVerticalScrollIndicator={false}
    >
      <View style={{ gap: 2 }}>
        <Text variant="h2">More</Text>
        <Text variant="caption" c={C.secondary}>
          Admissions, academics and institute operations
        </Text>
      </View>

      <Card pad={6}>
        {ITEMS.map((item, idx) => (
          <ListRow
            key={item.key}
            title={item.title}
            subtitle={item.subtitle}
            leading={<IconBox name={item.icon} tone={item.tone} />}
            right={
              item.key === 'admissions' && openLeads > 0 ? (
                <Badge label={`${openLeads} open`} tone="accent" small />
              ) : undefined
            }
            chevron
            divider={idx < ITEMS.length - 1}
            onPress={() => router.push(item.route as never)}
          />
        ))}
      </Card>
    </ScrollView>
  );
}
