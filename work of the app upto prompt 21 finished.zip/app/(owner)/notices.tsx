import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

/** Target of the dashboard's "Send notice" shortcut. Receives `?action=compose&batchId=` for the audience. */
export default function OwnerNoticesRoute() {
  return (
    <TabPlaceholder
      tabLabel="Send notice"
      prompt="NOT BUILT YET"
      title="Notices land here"
      description="The dashboard already opens this screen with the batch to address (batchId). Composing and sending notices is built by a later prompt."
    />
  );
}
