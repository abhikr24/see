import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { StudentProfileScreen } from '@/features/students/[id]';

export default function StudentDetailRoute() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  return <StudentProfileScreen id={typeof id === 'string' ? id : ''} />;
}
