import React from 'react';

import { StudentListScreen } from '@/features/students/screens/StudentListScreen';

export default function OwnerStudentsRoute() {
  return <StudentListScreen />;
}
