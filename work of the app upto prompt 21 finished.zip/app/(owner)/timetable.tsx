import React from 'react';

import { TimetableScreen } from '@/features/timetable';

export default function OwnerTimetableRoute() {
  return <TimetableScreen />;
}
