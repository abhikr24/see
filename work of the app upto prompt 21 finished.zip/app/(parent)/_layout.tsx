import React from 'react';

import { RoleTabShell } from '@/features/shell/RoleTabShell';

export default function ParentLayout() {
  return <RoleTabShell role="parent" />;
}
