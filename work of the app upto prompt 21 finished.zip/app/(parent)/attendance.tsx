import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function ParentAttendanceRoute() {
  return (
    <TabPlaceholder
      tabLabel="Attendance"
      prompt="PROMPT P17"
      title="Built in Prompt P17 (Parent screens)"
      description="Child attendance tracking will be built here by Prompt P17."
    />
  );
}
