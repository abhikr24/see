import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function ParentFeesRoute() {
  return (
    <TabPlaceholder
      tabLabel="Fees"
      prompt="PROMPT P17"
      title="Built in Prompt P17 (Parent screens)"
      description="Fee installments and payment history will be built here by Prompt P17."
    />
  );
}
