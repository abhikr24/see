import React from 'react';

import { HomePlaceholder } from '@/features/shell/HomePlaceholder';

export default function ParentHomeRoute() {
  return (
    <HomePlaceholder
      prompt="PROMPT P17"
      title="Built in Prompt P17 (Parent screens)"
      description="Your child's attendance, dues and the latest notice will replace this card."
    />
  );
}
