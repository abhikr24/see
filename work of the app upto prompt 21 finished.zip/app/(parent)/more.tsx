import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function ParentMoreRoute() {
  return (
    <TabPlaceholder
      tabLabel="More"
      prompt="PROMPT P17"
      title="Built in Prompt P17 (Parent screens)"
      description="Meeting requests, doubts and profile settings will be built here by Prompt P17."
    />
  );
}
