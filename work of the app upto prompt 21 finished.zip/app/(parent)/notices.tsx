import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function ParentNoticesRoute() {
  return (
    <TabPlaceholder
      tabLabel="Notices"
      prompt="PROMPT P17"
      title="Built in Prompt P17 (Parent screens)"
      description="Institute notices and announcements will be built here by Prompt P17."
    />
  );
}
