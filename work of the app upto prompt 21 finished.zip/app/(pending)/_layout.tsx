import React from 'react';
import { Redirect, Stack } from 'expo-router';

import { ShellLoading } from '@/features/shell/ShellLoading';
import { useRouteResolution } from '@/store/session';

/**
 * A pending member is locked to the waiting screen. Anyone else who lands
 * here (already active, signed out, never applied) is bounced to where they
 * actually belong.
 */
export default function PendingLayout() {
  const { status, destination } = useRouteResolution();

  if (status === 'loading' || destination.length === 0) return <ShellLoading />;
  if (status !== 'pending') return <Redirect href={destination as never} />;

  return <Stack screenOptions={{ headerShown: false }} />;
}
