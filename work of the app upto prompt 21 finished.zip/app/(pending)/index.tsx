import React from 'react';
import { PendingScreen } from '@/features/pending/screens/PendingScreen';

export default function PendingRoute() {
  return <PendingScreen />;
}
