import React from 'react';

import { RoleTabShell } from '@/features/shell/RoleTabShell';

export default function StudentLayout() {
  return <RoleTabShell role="student" />;
}
