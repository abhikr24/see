import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function StudentAttendanceRoute() {
  return (
    <TabPlaceholder
      tabLabel="Attendance"
      prompt="PROMPT P15"
      title="Built in Prompt P15 (Student screens)"
      description="Attendance history and the monthly summary will be built here by Prompt P15."
    />
  );
}
