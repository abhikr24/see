import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function StudentHomeworkRoute() {
  return (
    <TabPlaceholder
      tabLabel="Homework"
      prompt="PROMPT P15"
      title="Built in Prompt P15 (Student screens)"
      description="Homework and submissions will be built here by Prompt P15."
    />
  );
}
