import React from 'react';

import { TodayScheduleScreen } from '@/features/timetable';

/**
 * The student's "My Day" reads today's periods for their batches straight
 * from the institute timetable (TimetableRepo) — no duplicated data.
 * P15 grows the rest of the student home around this.
 */
export default function StudentHomeRoute() {
  return <TodayScheduleScreen role="student" />;
}
