import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function StudentMoreRoute() {
  return (
    <TabPlaceholder
      tabLabel="More"
      prompt="PROMPT P15"
      title="Built in Prompt P15 (Student screens)"
      description="Study materials, practice quizzes and profile settings will be built here by Prompt P15."
    />
  );
}
