import React from 'react';

import { StudentResultsScreen } from '@/features/exams/student-results';

export default function StudentResultsRoute() {
  return <StudentResultsScreen />;
}
