import React from 'react';

import { TeacherAttendanceScreen } from '@/features/teacher/screens/TeacherAttendanceScreen';

/**
 * Take Attendance for one of the teacher's own batches:
 * `/(teacher)/[batchId]?date=YYYY-MM-DD&period=1&subjectId=…`.
 * Full-screen (no tab bar): see `app/(teacher)/_layout.tsx`.
 */
export default function TeacherAttendanceRoute() {
  return <TeacherAttendanceScreen />;
}
