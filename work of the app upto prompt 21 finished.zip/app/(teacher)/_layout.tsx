import React from 'react';
import { useSegments } from 'expo-router';

import { ChromelessGate } from '@/features/shell/ChromelessGate';
import { RoleTabShell } from '@/features/shell/RoleTabShell';

export default function TeacherLayout() {
  const segments = useSegments() as string[];
  // Take Attendance (/(teacher)/[batchId]) is full-screen: the same role guard, no header and no tab bar.
  if (segments[1] === '[batchId]') return <ChromelessGate group="/(teacher)" />;
  return <RoleTabShell role="teacher" />;
}
