import React from 'react';

import { MyClassesScreen } from '@/features/teacher/screens/MyClassesScreen';

/** Teacher Classes tab: only the batches this teacher is the assigned teacher of. */
export default function TeacherClassesRoute() {
  return <MyClassesScreen />;
}
