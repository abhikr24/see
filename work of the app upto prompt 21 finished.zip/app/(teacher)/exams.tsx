import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function TeacherExamsRoute() {
  return (
    <TabPlaceholder
      tabLabel="Exams"
      prompt="PROMPT P13"
      title="Built in Prompt P13 (Teacher screens)"
      description="Exam schedules and marks entry will be built here by Prompt P13."
    />
  );
}
