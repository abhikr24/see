import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function TeacherHomeworkRoute() {
  return (
    <TabPlaceholder
      tabLabel="Homework"
      prompt="PROMPT P13"
      title="Built in Prompt P13 (Teacher screens)"
      description="Assigning, collecting and grading homework will be built here by Prompt P13."
    />
  );
}
