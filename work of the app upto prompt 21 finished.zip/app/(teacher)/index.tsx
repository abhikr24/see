import React from 'react';

import { TeacherHomeScreen } from '@/features/teacher/screens/TeacherHomeScreen';

/** Teacher Home tab. */
export default function TeacherHomeRoute() {
  return <TeacherHomeScreen />;
}
