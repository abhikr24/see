import React from 'react';

import { TabPlaceholder } from '@/features/shell/TabPlaceholder';

export default function TeacherMoreRoute() {
  return (
    <TabPlaceholder
      tabLabel="More"
      prompt="PROMPT P13"
      title="Built in Prompt P13 (Teacher screens)"
      description="Materials, doubts and profile settings will be built here by Prompt P13."
    />
  );
}
