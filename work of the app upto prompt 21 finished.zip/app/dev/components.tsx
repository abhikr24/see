import React, { useState } from 'react';
import { View } from 'react-native';
import {
  Avatar, AvatarStack, Badge, BarChart, Button, Card, Chip, ConfirmDialog,
  DateField, Divider, EmptyArt, EmptyState, ErrorState, GradientHeader,
  Heatmap, IconBox, Input, ListRow, ListSkeleton, OverlapCard, ProgressBar,
  Ring, Screen, SearchBar, SegmentedControl, Select, Sheet, Skeleton,
  StatCard, Stepper, TabBar, Table, Tabs, Text, Toast, TrendLine,
} from '@/components/ui';
import { copy } from '@/lib/copy';
import { inr } from '@/lib/format';
import { TABS } from '@/lib/nav';
import {
  QA_ATTENDANCE_TREND, QA_BATCH_OPTIONS, QA_DETAIL_TABS_ACCENT,
  QA_DETAIL_TABS_PRIMARY, QA_FEE_BARS, QA_FEE_COLUMNS, QA_FEE_ROWS,
  QA_HEATMAP_ATTENDANCE, QA_HEATMAP_INTENSITY, QA_MARK_COLUMNS, QA_MARK_ROWS,
  QA_SCORE_TREND, QA_STUDENTS, QA_TEACHERS, QA_TEACHER_OPTIONS, QA_UT3_BARS,
} from '@/lib/qa-data';
import { C, S } from '@/lib/theme';

const d = copy.dev;
const Row = ({ children }: { children: React.ReactNode }) => (
  <View style={{ flexDirection: 'row', gap: S.sm }}>{children}</View>
);
const Col = ({ children }: { children: React.ReactNode }) => (
  <View style={{ flex: 1 }}>{children}</View>
);
const Section = ({ index, title, children }: { index: string; title: string; children: React.ReactNode }) => (
  <View style={{ marginTop: S.xxl, gap: S.md }}>
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: S.sm }}>
      <Text variant="label" c={C.accent} tabular>{index}</Text>
      <Text variant="label" c={C.secondary}>{title}</Text>
      <View style={{ flex: 1, height: 1, backgroundColor: C.hairline }} />
    </View>
    {children}
  </View>
);

export default function ComponentsScreen() {
  const [chip, setChip] = useState('All');
  const [segA, setSegA] = useState<'all' | 'present' | 'absent'>('all');
  const [segB, setSegB] = useState<'t1' | 't2' | 't3' | 'yr'>('t3');
  const [detailTabA, setDetailTabA] = useState('overview');
  const [detailTabB, setDetailTabB] = useState('ut3');
  const [ownerTab, setOwnerTab] = useState('home');
  const [studentTab, setStudentTab] = useState('attendance');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [liveToast, setLiveToast] = useState<'success' | 'error' | 'info' | null>(null);
  const [name, setName] = useState('Aarav Sharma');
  const [password, setPassword] = useState('Sunrise2026');
  const [searchA, setSearchA] = useState('');
  const [searchB, setSearchB] = useState('Roll 14');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [dateA, setDateA] = useState('12/11/2026');
  const [dateB, setDateB] = useState('');
  const [batch, setBatch] = useState('10-a');
  const [teacher, setTeacher] = useState('rohit');
  const [feeStep, setFeeStep] = useState(4999);
  const [marksStep, setMarksStep] = useState(86);

  return (
    <Screen title={d.title} subtitle={d.subtitle} right={<Badge label="35 PRIMITIVES" tone="accent" />}>
      <Section index="01" title="Hero Headers, OverlapCard & Ring">
        <View>
          <GradientHeader style={{ paddingVertical: 24 }}>
            <Text variant="label" c={C.surface}>{d.eyebrow}</Text>
            <Text variant="h2" c={C.surface} style={{ marginTop: S.xs }}>{d.heroTitle}</Text>
            <Text variant="caption" c={C.surface} style={{ marginTop: 4 }}>{d.heroBody}</Text>
            <View style={{ height: 26 }} />
          </GradientHeader>
          <OverlapCard>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flex: 1, gap: 4 }}>
                <Text variant="label" c={C.muted}>{d.heroStat}</Text>
                <Text variant="h1" tabular>92%</Text>
                <Text variant="caption" c={C.secondary}>{d.heroNote}</Text>
              </View>
              <Ring value={92} size={86} stroke={7} tone={C.teal} label="PRESENT" />
            </View>
          </OverlapCard>
        </View>
        <View>
          <GradientHeader style={{ paddingVertical: 18 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View>
                <Text variant="label" c={C.surface}>CLASS 10-A · MATHEMATICS</Text>
                <Text variant="title" c={C.surface} style={{ marginTop: 2 }}>Unit Test 3 Summary</Text>
              </View>
              <Badge label="PASS 100%" tone="teal" />
            </View>
            <View style={{ height: 22 }} />
          </GradientHeader>
          <OverlapCard>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <View style={{ flex: 1, gap: 2 }}>
                <Text variant="label" c={C.muted}>BATCH AVERAGE</Text>
                <Text variant="h2" tabular>72 / 100</Text>
                <Text variant="caption" c={C.secondary}>Highest 93 (Diya) · Lowest 41 (Kabeer)</Text>
              </View>
              <Ring value={72} size={74} stroke={6} tone={C.primary} label="AVG" />
            </View>
          </OverlapCard>
        </View>
      </Section>

      <Section index="02" title="Text (Typography Scale & Tabular Numerals)">
        <Card flat>
          <View style={{ gap: S.sm }}>
            <Text variant="h1">H1 · 34 / 800 Page Title</Text>
            <Text variant="h2">H2 · 22 / 700 Section Heading</Text>
            <Text variant="title">Title · 17 / 700 Card Heading</Text>
            <Text variant="body">Body · 15 / 500 Rahul Sharma · Sunrise Coaching Classes</Text>
            <Text variant="caption" c={C.secondary}>Caption · 13 / 500 Secondary metadata & helper line</Text>
            <Text variant="label" c={C.muted}>LABEL · 11 / 600 UPPERCASE TRACKING</Text>
            <Text variant="title" tabular c={C.primary}>Tabular · {inr(124500)} · 46/50 (92%)</Text>
          </View>
        </Card>
      </Section>

      <Section index="03" title="StatCard (Trends & Deltas)">
        <Row>
          <Col><StatCard label="ATTENDANCE" value="92%" delta="+4.2%" trend="up" subtitle="46 of 50 present" /></Col>
          <Col><StatCard label="PENDING FEES" value="12" delta="Term 3" trend="down" subtitle="Class 10-A due" /></Col>
        </Row>
        <Row>
          <Col><StatCard label="TERM 3 DUE" value={inr(4999)} delta="Due 15 Nov" trend="warning" subtitle="Per student" /></Col>
          <Col><StatCard label="UT 3 AVERAGE" value="72%" delta="Max 93" trend="neutral" subtitle="100% pass rate" tint={C.navySoft} /></Col>
        </Row>
      </Section>

      <Section index="04" title="Button (Variants, Sizes & States)">
        <Button title="Primary · Record Fee Payment" icon="wallet-outline" onPress={() => setLiveToast('success')} />
        <Row>
          <Col><Button title="Secondary" variant="secondary" size="md" onPress={() => setLiveToast('info')} /></Col>
          <Col><Button title="Outline" variant="outline" size="md" onPress={() => setSheetOpen(true)} /></Col>
        </Row>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm }}>
          <Button title="Small Primary" size="sm" full={false} onPress={() => setLiveToast('info')} />
          <Button title="Ghost Action" variant="ghost" size="sm" full={false} onPress={() => setLiveToast('info')} />
          <Button title="Destructive" variant="danger" size="sm" full={false} onPress={() => setConfirmOpen(true)} />
        </View>
        <Row>
          <Col><Button title="Saving…" loading size="md" /></Col>
          <Col><Button title="Disabled" disabled size="md" /></Col>
        </Row>
      </Section>

      <Section index="05" title="Input, SearchBar, DateField, Select & Stepper">
        <Input label="Student Full Name" value={name} onChangeText={setName} icon="person-outline" hint="Matched against Class 10-A roll register" />
        <Input label="Guardian Mobile" value="98765" keyboardType="phone-pad" error="Enter a valid 10-digit Indian mobile number" icon="call-outline" />
        <Input label="Institute Passcode" value={password} onChangeText={setPassword} secure hint="Tap eye icon to reveal" />
        <SearchBar value={searchA} onChangeText={setSearchA} onDebouncedChange={setDebouncedQuery} placeholder="Search 12 students in Class 10-A…" />
        <SearchBar value={searchB} onChangeText={setSearchB} compact loading placeholder="Compact loading search…" />
        {debouncedQuery ? <Text variant="caption" c={C.secondary}>Debounced query: &ldquo;{debouncedQuery}&rdquo;</Text> : null}
        <Row>
          <Col><DateField label="Attendance Date" value={dateA} onChange={(dmy) => setDateA(dmy)} hint="Tap to open calendar" /></Col>
          <Col><DateField label="Term 3 Due Date" value={dateB} onChange={(dmy) => setDateB(dmy)} error={dateB ? undefined : 'Date required'} /></Col>
        </Row>
        <Select label="Active Batch (Searchable Sheet)" options={QA_BATCH_OPTIONS} value={batch} onChange={setBatch} hint="Opens @gorhom/bottom-sheet with SearchBar" />
        <Select label="Subject Faculty (Compact Sheet)" options={QA_TEACHER_OPTIONS} value={teacher} onChange={setTeacher} searchable={false} />
        <Stepper label="Term 3 Installment Amount (₹)" value={feeStep} onChange={setFeeStep} min={1000} max={25000} step={500} suffix="₹" />
        <Stepper label="Unit Test 3 Marks Scored" value={marksStep} onChange={setMarksStep} min={0} max={100} step={1} suffix="marks" />
      </Section>

      <Section index="06" title="SegmentedControl, Tabs, Chip & Badge">
        <SegmentedControl
          options={[{ key: 'all', label: 'All', count: 50 }, { key: 'present', label: 'Present', count: 46 }, { key: 'absent', label: 'Absent', count: 3 }]}
          value={segA}
          onChange={setSegA}
        />
        <SegmentedControl
          size="sm"
          options={[{ key: 't1', label: 'Term 1' }, { key: 't2', label: 'Term 2' }, { key: 't3', label: 'Term 3' }, { key: 'yr', label: 'Annual' }]}
          value={segB}
          onChange={setSegB}
        />
        <Card flat pad={0}>
          <Tabs tabs={QA_DETAIL_TABS_PRIMARY} activeKey={detailTabA} onChange={setDetailTabA} variant="primary" />
          <View style={{ padding: S.md }}><Text variant="caption" c={C.secondary}>Primary underline tab: {detailTabA.toUpperCase()}</Text></View>
        </Card>
        <Card flat pad={0}>
          <Tabs tabs={QA_DETAIL_TABS_ACCENT} activeKey={detailTabB} onChange={setDetailTabB} variant="accent" scrollable />
          <View style={{ padding: S.md }}><Text variant="caption" c={C.secondary}>Saffron underline tab: {detailTabB.toUpperCase()}</Text></View>
        </Card>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm }}>
          {['All', 'Class 10-A', 'Overdue', 'Toppers'].map((item) => (
            <Chip key={item} label={item} count={item === 'Class 10-A' ? 12 : undefined} active={chip === item} onPress={() => setChip(item)} />
          ))}
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm, alignItems: 'center' }}>
          <Badge label="Paid · Term 1" tone="teal" />
          <Badge label={`Due ${inr(4999)}`} tone="danger" />
          <Badge label="1 Late" tone="warning" />
          <Badge label="SUNRISE-PAT" tone="primary" />
          <Badge label="Highest 93" tone="accent" />
          <Badge label="Compact" tone="neutral" small />
        </View>
      </Section>

      <Section index="07" title="Card, ListRow, Avatar, AvatarStack, IconBox & Divider">
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.md, alignItems: 'center', justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row', gap: S.sm, alignItems: 'center' }}>
            <Avatar name="Aarav Sharma" size={40} />
            <Avatar name="Diya Patel" size={48} />
            <Avatar name="Rohit Verma" size={56} />
          </View>
          <View style={{ flexDirection: 'row', gap: S.sm }}>
            <IconBox name="school-outline" tone="primary" />
            <IconBox name="checkmark-done-outline" tone="teal" />
            <IconBox name="flame-outline" tone="accent" />
            <IconBox name="alert-circle-outline" tone="danger" />
          </View>
        </View>
        <Card flat>
          <View style={{ gap: S.md }}>
            <AvatarStack users={QA_STUDENTS} max={5} totalCount={12} size={36} label="Class 10-A · 12 enrolled" />
            <Divider />
            <AvatarStack users={QA_TEACHERS} max={3} totalCount={5} size={32} label="Sunrise Faculty · 5 teachers" />
          </View>
        </Card>
        <Card flat pad={0}>
          <ListRow leading={<Avatar name="Diya Patel" size={44} />} title="Diya Patel" subtitle="Roll 21 · Class 10-A · Unit Test 3 Topper" right={<Badge label="93 / 100" tone="accent" />} onPress={() => setLiveToast('info')} divider />
          <ListRow leading={<IconBox name="wallet-outline" tone="danger" size={44} />} title="Term 3 Tuition Installment" subtitle="Aarav Sharma · Roll 14 · Due 15 Nov 2026" right={<Text variant="title" weight={800} c={C.danger} tabular>{inr(4999)}</Text>} onPress={() => setLiveToast('error')} divider />
          <ListRow leading={<IconBox name="calculator-outline" tone="primary" size={44} />} title="Rohit Verma" subtitle="Mathematics Faculty · Class 10-A" right={<Badge label="FACULTY" tone="primary" small />} chevron={false} />
        </Card>
      </Section>

      <Section index="08" title="TrendLine, BarChart & ProgressBar">
        <TrendLine title="WEEKLY ATTENDANCE TREND" subtitle="Thin line, no gridlines, saffron last dot" headlineValue="92%" data={QA_ATTENDANCE_TREND} color={C.primary} curved />
        <TrendLine title="MATHEMATICS ASSESSMENT PROGRESSION" subtitle="Linear variant · Class 10-A average" headlineValue="72%" data={QA_SCORE_TREND} color={C.teal} curved={false} />
        <BarChart title="UNIT TEST 3 · MATHEMATICS (MAX 100)" subtitle="Diya Patel (93) highlighted in saffron · Avg 72%" headlineValue="93 MAX" data={QA_UT3_BARS} baseTone="primary" />
        <BarChart title="FEE COLLECTIONS (₹ THOUSANDS)" subtitle="Soft navy bars with November spotlight in saffron" headlineValue="₹60k" data={QA_FEE_BARS} baseTone="soft" />
        <Card flat>
          <View style={{ gap: S.md }}>
            <Text variant="label" c={C.muted}>PROGRESS BARS BY TONE</Text>
            <ProgressBar value={92} tone="teal" />
            <ProgressBar value={72} tone="primary" />
            <ProgressBar value={55} tone="warning" />
            <ProgressBar value={33} tone="danger" />
          </View>
        </Card>
      </Section>

      <Section index="09" title="Table & Heatmap (Sticky Header, Tabular, 7-Col Grid)">
        <Table columns={QA_MARK_COLUMNS} data={QA_MARK_ROWS} footerRow={{ roll: 'AVG', student: '9 Students · Pass 100%', marks: '72.1', pct: '72%' }} />
        <Table columns={QA_FEE_COLUMNS} data={QA_FEE_ROWS} footerRow={{ term: 'Total Annual Fee', status: '2 Paid · 1 Due', amount: inr(14997) }} />
        <Heatmap monthLabel="November 2026 · Attendance" subtitle="46P · 1L · 3A (92%)" days={QA_HEATMAP_ATTENDANCE} startOffset={6} variant="attendance" />
        <Heatmap monthLabel="Practice Streak · Intensity" subtitle="Class 10-A Daily Quiz Volume" days={QA_HEATMAP_INTENSITY} startOffset={2} variant="intensity" />
      </Section>

      <Section index="10" title="EmptyArt, EmptyState, ErrorState & Skeleton">
        <Card flat>
          <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', paddingVertical: S.sm }}>
            <EmptyArt icon="people-outline" tone="primary" badgeIcon="add" size={76} />
            <EmptyArt icon="checkmark-done-outline" tone="teal" size={76} />
            <EmptyArt icon="sparkles-outline" tone="accent" size={76} />
          </View>
        </Card>
        <Card flat><EmptyState icon="people-outline" tone="primary" title="No students in Batch 10-B" text="Enrol students or import from Class 10-A to start marking attendance." actionLabel="Add student" onAction={() => setSheetOpen(true)} /></Card>
        <Card flat><EmptyState icon="checkmark-circle-outline" tone="teal" title="All doubts resolved" text="Rohit Verma answered all 9 Mathematics doubts from Unit Test 3." /></Card>
        <Card flat><ErrorState message="Could not sync Term 3 fee ledger. Check your connection and retry." onRetry={() => setLiveToast('info')} /></Card>
        <Card flat><ErrorState title="Session expired" message="Please re-verify your SUNRISE-PAT membership to view marks." /></Card>
        <Card flat><View style={{ gap: S.sm }}><Skeleton h={16} w="68%" /><Skeleton h={12} w="42%" /></View></Card>
        <ListSkeleton rows={2} />
      </Section>

      <Section index="11" title="Toast, ConfirmDialog, Sheet & TabBar">
        <Toast kind="success" message="Attendance saved for Class 10-A" subtitle="46 present · 1 late · 3 absent (92%)" autoDismissMs={0} />
        <Toast kind="error" message="Term 3 payment failed" subtitle="UPI collect request timed out for Roll 14" autoDismissMs={0} />
        <Toast kind="info" message="Unit Test 3 marks published" subtitle="Average 72% · Highest 93 (Diya Patel)" autoDismissMs={0} />
        <ConfirmDialog visible inline title="Remove student from Class 10-A?" description="This archives Kabir Singh (Roll 16) and unlinks pending Term 3 fee installments." confirmText="REMOVE" confirmLabel="Confirm removal" onConfirm={() => setLiveToast('success')} onCancel={() => setLiveToast('info')} />
        <Row>
          <Col><Button title="Open Modal Confirm" variant="outline" size="md" onPress={() => setConfirmOpen(true)} /></Col>
          <Col><Button title="Open Bottom Sheet" variant="secondary" size="md" onPress={() => setSheetOpen(true)} /></Col>
        </Row>
        <Text variant="label" c={C.muted}>OWNER ROLE TAB BAR</Text>
        <TabBar tabs={TABS.owner.map((t) => (t.key === 'fees' ? { ...t, badge: 12 } : t))} selectedKey={ownerTab} onSelect={setOwnerTab} />
        <Text variant="label" c={C.muted}>STUDENT ROLE TAB BAR</Text>
        <TabBar tabs={TABS.student} selectedKey={studentTab} onSelect={setStudentTab} />
      </Section>

      <ConfirmDialog visible={confirmOpen} title="Delete draft Unit Test 4?" description="This action cannot be undone. Published Unit Test 3 marks remain untouched." confirmLabel="Delete draft" onConfirm={() => { setConfirmOpen(false); setLiveToast('error'); }} onCancel={() => setConfirmOpen(false)} />
      <Sheet visible={sheetOpen} onClose={() => setSheetOpen(false)} title="Sunrise Coaching Classes" subtitle="Patna, Bihar · Code SUNRISE-PAT">
        <View style={{ gap: S.md }}>
          <Text variant="body" c={C.secondary}>Powered by @gorhom/bottom-sheet with pan-down dismissal and theme tokens.</Text>
          <Button title="Done" onPress={() => setSheetOpen(false)} />
        </View>
      </Sheet>
      <Toast visible={liveToast !== null} kind={liveToast ?? 'info'} message={liveToast === 'success' ? 'Payment recorded (₹4,999)' : liveToast === 'error' ? 'Draft exam deleted' : 'Action previewed in QA gallery'} floating bottomOffset={24} onDismiss={() => setLiveToast(null)} />
    </Screen>
  );
}
