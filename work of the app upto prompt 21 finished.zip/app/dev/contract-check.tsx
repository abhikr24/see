/**
 * /dev/contract-check – verifies a backend against the contracts.
 *
 * Calls one safe, read-only method on every port (see src/core/contracts/checks.ts)
 * and prints pass / fail with the error code. Point it at a new backend and
 * work down the list until everything is green.
 */

import Ionicons from '@expo/vector-icons/Ionicons';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';

import { useBackend } from '../../src/core/backend';
import {
  ALL_CHECKS,
  CONTRACT_CHECKS,
  OTP_CHECK_INFOS,
  runAllChecks,
  runCheck,
  runOtpCheck,
  type CheckInfo,
  type CheckResult,
} from '../../src/core/contracts/checks';
import type { Backend, PortKey } from '../../src/core/contracts/ports';
import { MONO, useTheme, type Theme } from '../../src/lib/theme';

type Results = Record<string, CheckResult>;
const TOTAL = ALL_CHECKS.length;
const keyOf = (info: CheckInfo) => `${info.port}:${info.method}`;

export default function ContractCheckScreen() {
  const theme = useTheme();
  const { backend, backends, instituteId } = useBackend();
  const [targetName, setTargetName] = useState(backend.name);
  const [institute, setInstitute] = useState(instituteId ?? '');
  const [results, setResults] = useState<Results>({});
  const [running, setRunning] = useState<PortKey | 'all' | null>(null);
  const [failuresOnly, setFailuresOnly] = useState(false);
  const target = backends.find((b) => b.name === targetName) ?? backend;

  // Only the newest run may write results; an older one finishing late is ignored.
  const runId = useRef(0);
  const scope = useRef(institute);
  scope.current = institute;

  const runAll = useCallback(async (against: Backend) => {
    const id = ++runId.current;
    setResults({});
    setRunning('all');
    await runAllChecks(against, { instituteId: scope.current.trim() }, (result) => {
      if (runId.current === id) setResults((previous) => ({ ...previous, [keyOf(result)]: result }));
    });
    if (runId.current === id) setRunning(null);
  }, []);

  const runOne = async (info: CheckInfo) => {
    const id = ++runId.current;
    setRunning(info.port);
    const isOtpMethod = ['requestOtp', 'verifyOtp', 'resendOtp', 'signInWithGoogle'].includes(info.method) && !CONTRACT_CHECKS.some((c) => c.method === info.method && c.port === info.port);
    const result = isOtpMethod
      ? await runOtpCheck(target, info.method, { instituteId: scope.current.trim() })
      : await runCheck(target, info.port, { instituteId: scope.current.trim() });
    if (runId.current !== id) return;
    setResults((previous) => ({ ...previous, [keyOf(info)]: result }));
    setRunning(null);
  };

  // Runs on open and when another backend is picked – not on every keystroke in the institute field.
  useEffect(() => {
    void runAll(target);
  }, [target, runAll]);

  const finished = Object.values(results);
  const failed = finished.filter((r) => r.status === 'fail').length;
  const passed = finished.length - failed;
  const complete = finished.length === TOTAL && running === null;
  const rows = failuresOnly ? ALL_CHECKS.filter((c) => results[keyOf(c)]?.status === 'fail') : ALL_CHECKS;

  let verdict = `Checked ${finished.length} of ${TOTAL} ports…`;
  if (complete) verdict = failed === 0 ? `All ${TOTAL} ports pass` : `${failed} of ${TOTAL} ports fail`;
  const verdictColor = !complete ? theme.muted : failed === 0 ? theme.passText : theme.failText;

  const header = (
    <View style={styles.header}>
      <Text style={[styles.label, { color: theme.muted }]}>Backend</Text>
      <View style={styles.chips}>
        {backends.map((b) => (
          <Chip key={b.name} label={b.name} selected={b.name === target.name} theme={theme} onPress={() => setTargetName(b.name)} />
        ))}
      </View>

      <Text style={[styles.label, { color: theme.muted }]}>Institute id</Text>
      <TextInput
        value={institute}
        onChangeText={setInstitute}
        onSubmitEditing={() => void runAll(target)}
        placeholder="Institute id to scope every call to"
        placeholderTextColor={theme.muted}
        accessibilityLabel="Institute id"
        autoCapitalize="none"
        autoCorrect={false}
        returnKeyType="go"
        style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.surface }]}
      />

      <Pressable
        accessibilityRole="button"
        accessibilityState={{ busy: running === 'all' }}
        disabled={running !== null}
        onPress={() => void runAll(target)}
        style={({ pressed }) => [styles.run, { backgroundColor: theme.primary, opacity: running !== null || pressed ? 0.6 : 1 }]}
      >
        {running === 'all' ? <ActivityIndicator color={theme.onPrimary} /> : <Ionicons name="play" size={16} color={theme.onPrimary} />}
        <Text style={[styles.runText, { color: theme.onPrimary }]}>{running === 'all' ? 'Running…' : 'Run all checks'}</Text>
      </Pressable>

      <View style={[styles.summary, { backgroundColor: theme.surface, borderColor: theme.border }]}>
        <Text accessibilityLiveRegion="polite" style={[styles.verdict, { color: verdictColor }]}>
          {verdict}
        </Text>
        <Text style={[styles.counts, { color: theme.muted }]}>
          {passed} pass · {failed} fail · {TOTAL - finished.length} to go
        </Text>
        <View style={[styles.track, { backgroundColor: theme.border }]}>
          <View style={{ flex: passed, backgroundColor: theme.passBar }} />
          <View style={{ flex: failed, backgroundColor: theme.failBar }} />
          <View style={{ flex: TOTAL - finished.length }} />
        </View>
      </View>

      <View style={styles.chips}>
        <Chip label={`All ${TOTAL}`} selected={!failuresOnly} theme={theme} onPress={() => setFailuresOnly(false)} />
        <Chip label={`Failures ${failed}`} selected={failuresOnly} theme={theme} onPress={() => setFailuresOnly(true)} />
      </View>
    </View>
  );

  return (
    <FlatList
      data={rows}
      keyExtractor={(item) => keyOf(item)}
      style={{ backgroundColor: theme.background }}
      contentContainerStyle={styles.content}
      ListHeaderComponent={header}
      // Short, fixed list: render it whole so every port is on the page (and findable) at once.
      initialNumToRender={TOTAL}
      ListEmptyComponent={
        <Text style={[styles.empty, { color: theme.muted }]}>
          {complete ? 'No failures. Every port answered as the contract promises.' : 'No failures so far.'}
        </Text>
      }
      refreshing={false}
      onRefresh={() => void runAll(target)}
      keyboardShouldPersistTaps="handled"
      renderItem={({ item }) => (
        <Row
          info={item}
          result={results[keyOf(item)]}
          busy={running === item.port || (running === 'all' && !results[keyOf(item)])}
          disabled={running !== null}
          theme={theme}
          onPress={() => void runOne(item)}
        />
      )}
    />
  );
}

function Chip(props: { label: string; selected: boolean; theme: Theme; onPress: () => void }) {
  const { label, selected, theme, onPress } = props;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[styles.chip, { borderColor: selected ? theme.primary : theme.border, backgroundColor: selected ? theme.primary : theme.surface }]}
    >
      <Text style={[styles.chipText, { color: selected ? theme.onPrimary : theme.text }]}>{label}</Text>
    </Pressable>
  );
}

interface RowProps {
  info: CheckInfo;
  result: CheckResult | undefined;
  busy: boolean;
  disabled: boolean;
  theme: Theme;
  onPress: () => void;
}

function Row({ info, result, busy, disabled, theme, onPress }: RowProps) {
  const failed = result?.status === 'fail';
  const badge = result ? (failed ? `FAIL · ${result.code}` : 'PASS') : busy ? 'RUNNING' : 'WAITING';
  const badgeText = result ? (failed ? theme.failText : theme.passText) : theme.muted;
  const badgeFill = result ? (failed ? theme.failFill : theme.passFill) : theme.background;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${info.portName}, ${badge}. Run again.`}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [styles.row, { backgroundColor: theme.surface, borderColor: theme.border, opacity: pressed ? 0.7 : 1 }]}
    >
      <View style={styles.rowTop}>
        <Text style={[styles.port, { color: theme.text }]}>{info.portName}</Text>
        <View style={[styles.badge, { backgroundColor: badgeFill }]}>
          <Text style={[styles.badgeText, { color: badgeText }]}>{badge}</Text>
        </View>
      </View>
      <Text style={[styles.call, { color: theme.muted }]}>
        {info.port}.{info.method}()
      </Text>
      {result ? (
        <Text style={[styles.message, { color: failed ? theme.failText : theme.muted }]}>
          {result.message} · {result.durationMs} ms
        </Text>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 40, gap: 8, width: '100%', maxWidth: 720, alignSelf: 'center' },
  header: { gap: 8, marginBottom: 8 },
  label: { fontSize: 13, fontWeight: '600', marginTop: 8 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { minHeight: 44, paddingHorizontal: 16, borderRadius: 22, borderWidth: 1, justifyContent: 'center' },
  chipText: { fontSize: 14, fontWeight: '600' },
  input: { minHeight: 48, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, fontSize: 13, fontFamily: MONO },
  run: { minHeight: 48, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 8 },
  runText: { fontSize: 16, fontWeight: '700' },
  summary: { borderWidth: 1, borderRadius: 12, padding: 16, gap: 4, marginTop: 8, marginBottom: 4 },
  verdict: { fontSize: 20, fontWeight: '700' },
  counts: { fontSize: 13 },
  track: { height: 8, borderRadius: 4, flexDirection: 'row', overflow: 'hidden', marginTop: 8 },
  empty: { textAlign: 'center', padding: 32, fontSize: 14 },
  row: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, gap: 4 },
  rowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  port: { fontSize: 16, fontWeight: '700', flexShrink: 1 },
  badge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  badgeText: { fontSize: 12, fontWeight: '700', fontFamily: MONO },
  call: { fontSize: 13, fontFamily: MONO },
  message: { fontSize: 13, lineHeight: 18 },
});
