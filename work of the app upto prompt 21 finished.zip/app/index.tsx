import React from 'react';
import { Redirect } from 'expo-router';

import { ShellLoading } from '@/features/shell/ShellLoading';
import { useRouteResolution } from '@/store/session';

/**
 * The route resolver. No session → (auth). Every membership pending →
 * (pending). Otherwise the group of the active membership's role.
 */
export default function Index() {
  const { status, destination } = useRouteResolution();

  // 'loading' has an empty destination. Never Redirect to '' — that paints a
  // blank screen instead of the shell spinner.
  if (status === 'loading' || destination.length === 0) return <ShellLoading />;
  return <Redirect href={destination as never} />;
}
