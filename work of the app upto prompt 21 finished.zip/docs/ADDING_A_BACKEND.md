# Adding a backend

A backend is one object that implements `Backend` from `src/core/contracts/ports.ts`: 34 ports, every method async, every method scoped to an institute. The UI never learns which backend it is talking to.

```
app/, src/features        screens – import only src/core/backend
        │
src/core/backend.tsx      BackendProvider + one hook per port
src/core/hooks/           query cache, optimistic updates, rollback, toasts
        │
src/core/contracts/       models · ports · query · errors · checks     ← the contract
        │
src/backends/<name>/      your adapter – the only code that may import an SDK
```

Two backends ship today:

| Name | File | What it is |
|---|---|---|
| `memory` | `src/backends/memory/` | Reference implementation over in-process maps. Seeded demo data, lost on reload. Read it to see what each method is expected to do. |
| `stub` | `src/backends/stub.ts` | Every method rejects with `NOT_IMPLEMENTED`. The starting point for a new adapter. |

## Steps

### 1. Start from the stub

```ts
// src/backends/supabase/index.ts
import type { Backend } from '../../core/contracts/ports';
import { createStubBackend } from '../stub';
import { studentRepo } from './students';

export function createSupabaseBackend(): Backend {
  return {
    ...createStubBackend('supabase'),
    students: studentRepo(client), // replace one port at a time
  };
}
```

Remove the stub spread once every port is in place – from then on the compiler tells you when a port is missing.

### 2. Register it

Add it to the array in `src/backends/index.ts`. That file and `App.tsx` are the only places that know which backends exist.

```ts
export function createBackends(): Backend[] {
  return [createMemoryBackend(), createSupabaseBackend(), createStubBackend('stub')];
}
```

Launch on it with `EXPO_PUBLIC_BACKEND=supabase` and, until sign-in and institute selection exist, `EXPO_PUBLIC_INSTITUTE_ID=<uuid>`.

### 3. Check it

Open **`/dev/contract-check`**, pick your backend, enter an institute id that exists in it, and run. Work down the list until it reads "All 34 ports pass".

| Result | Meaning |
|---|---|
| `PASS` | The method resolved with the shape the contract promises. |
| `FAIL · NOT_IMPLEMENTED` | Still the stub. |
| `FAIL · <other code>` | Your adapter rejected with that `BackendError` – e.g. `FORBIDDEN` usually means a row-level-security policy, `UNAUTHENTICATED` that nobody is signed in. |
| `FAIL · BAD_SHAPE` | It resolved, but not with a `Page`, array, object… as declared. |
| `FAIL · UNTYPED_ERROR` | It threw something that is not a `BackendError`. Wrap it (rule 3). |
| `FAIL · NO_RESPONSE` | Neither resolved nor rejected within 8 seconds. |

What the check does **not** prove: it calls one read-only method per port and looks only at the shape of the answer. It writes nothing, so creates, updates, validation, permissions per role and tenant isolation still need their own tests against your backend.

## Rules every adapter follows

1. **Async, institute first.** Every method returns a promise and takes `instituteId` as its first argument. Filter by it on every read and stamp it on every write, even if the database also enforces it. On `AuthPort`, and on `InstituteRepo.listMine / findByCode / create`, it may be `null` – those run before an institute is chosen.
2. **Another institute's row does not exist.** `get`, `update` and `remove` on a row from a different institute reject with `NOT_FOUND`. Lists simply do not contain it.
3. **Reject only with `BackendError`.** Catch whatever the SDK throws and translate it (table below). Put the original in `origin` for logging. The hooks show `error.message` to the user, so make it a sentence a person can act on.
4. **Speak in models.** Return the camelCase types from `models.ts`, with every field present; use `null`, never `undefined`, for "no value". Dates are `YYYY-MM-DD`, instants ISO 8601, money a number in major units.
5. **Default on create.** `NewEntity<T, Req>` makes only the `Req` fields mandatory. Fill the rest the way `src/backends/memory/defaults.ts` does, or let the database defaults do it and read the row back.
6. **Honour `ListQuery`.** `where` is equality on model field names (ignore keys whose value is `undefined`), `search` is free text, `sort.field` is a model field name, `limit` defaults to 50 and is capped at 200 (`pageSize()`), `cursor` is whatever you returned as `nextCursor`. Return `total: null` if counting is expensive.
7. **Derived values belong to the backend.** `StudentFee.netAmount`, installment status, result totals and ranks, attendance percentages, `ProgressSnapshot` and `RiskAlert` are computed behind the port. The UI does no arithmetic on them.

### Error mapping

| Situation | Code |
|---|---|
| No session / expired token | `UNAUTHENTICATED` |
| Permission or row-level-security denial | `FORBIDDEN` |
| No row, or a row in another institute | `NOT_FOUND` |
| Unique violation, stale update, illegal state change | `CONFLICT` |
| Check-constraint, foreign-key or input validation failure | `VALIDATION` |
| HTTP 429 | `RATE_LIMITED` |
| Request never reached the server | `NETWORK` |
| Request timed out | `TIMEOUT` |
| 5xx, maintenance | `UNAVAILABLE` |
| Method not built yet | `NOT_IMPLEMENTED` |
| Anything else | `UNKNOWN` |

## What the hooks expect

Screens call hooks, hooks call ports. Knowing how the hooks behave tells you what a port must get right.

- A query hook returns `{ data, loading, error, refetch }`. It loads on mount, keeps the last good `data` when a reload fails, and is switched off while no institute is selected.
- An action (`create`, `save`, `publish` …) never throws. It applies an optimistic change to the cached list, calls the port, then either reloads the affected domains and shows a success toast, or restores the cache and shows `error.message` in an error toast. So: reject quickly and with a useful message; do not resolve with a partial result.
- After a write the hook reloads rather than trusting the returned row, so a port may return the row as written without re-reading related data.
- `useRealtime(topic)` reloads the matching domain on every event. Events carry only `{ topic, change, id, at }`.

## Port → models → tables

For adapter authors only – nothing above `src/backends/` uses these names. Tables are those of `supabase/migrations/0003–0008` (see `docs/DATA_MODEL.md`).

| Port (key on `Backend`) | Models | Tables |
|---|---|---|
| `AuthPort` (`auth`) | AuthSession, Profile | `auth.users`, `users`, `profiles` |
| `InstituteRepo` (`institutes`) | Institute (+ settings) | `institutes`, `institute_settings` |
| `BranchRepo` (`branches`) | Branch | `branches` |
| `MembershipRepo` (`memberships`) | Membership | `memberships` |
| `InvitationRepo` (`invitations`) | Invitation | `invitations` |
| `StaffRepo` (`staff`) | StaffRecord, Teacher, Workload | `staff_records`, `teacher_profiles`, `workloads` |
| `StudentRepo` (`students`) | Student, StudentMembership | `student_profiles`, `student_memberships`, `batch_students` |
| `GuardianRepo` (`guardians`) | Guardian, ParentLink | `guardians`, `parent_links` |
| `BatchRepo` (`batches`) | Batch, Enrollment | `batches`, `batch_students`, `batch_teachers` |
| `SubjectRepo` (`subjects`) | Subject | `subjects` |
| `TimetableRepo` (`timetable`) | Timetable, Classroom | `timetables`, `classrooms` |
| `AttendanceRepo` (`attendance`) | AttendanceSession, AttendanceRecord | `attendance_sessions`, `attendance_records` |
| `AssignmentRepo` (`assignments`) | Assignment | `assignments` |
| `SubmissionRepo` (`submissions`) | Submission, Feedback | `submissions`, `feedback` |
| `ExamRepo` (`exams`) | Exam, ExamQuestion | `exams`, `exam_questions` |
| `MarkRepo` (`marks`) | Mark | `marks` |
| `ResultRepo` (`results`) | Result | `results` |
| `MaterialRepo` (`materials`) | Material, Bookmark | `materials`, `bookmarks` |
| `PracticeRepo` (`practice`) | PracticeQuestion, Quiz, QuizAttempt | `practice_questions`, `quizzes`, `quiz_attempts` |
| `FeeRepo` (`fees`) | FeeStructure, StudentFee, Installment | `fee_structures`, `student_fees`, `installments` |
| `PaymentRepo` (`payments`) | Payment, Refund | `payments`, `refunds` |
| `ReceiptRepo` (`receipts`) | Receipt | `receipts` |
| `NoticeRepo` (`notices`) | Notice | `notices` |
| `NotificationRepo` (`notifications`) | AppNotification | `notifications` |
| `DoubtRepo` (`doubts`) | Doubt | `doubts` |
| `MeetingRepo` (`meetings`) | MeetingRequest, Conversation | `meeting_requests`, `conversations` |
| `LeadRepo` (`leads`) | AdmissionLead, LeadFollowup | `admission_leads`, `lead_followups` |
| `AnalyticsRepo` (`analytics`) | InstituteOverview, TrendPoint, AuditLog | aggregates; `audit_logs` |
| `SubscriptionRepo` (`subscriptions`) | Subscription, Plan, UsageRecord | `subscriptions`, `plans`, `usage_records` |
| `ExportRepo` (`exports`) | ExportJob | none yet – edge function or client-side file |
| `StoragePort` (`storage`) | Attachment | `attachments` + a storage bucket |
| `PaymentPort` (`paymentGateway`) | PaymentOrder, Payment | gateway API; `payments` |
| `RealtimePort` (`realtime`) | RealtimeEvent | change feed on the tables above |
| `ProgressPort` (`progress`) | ProgressSnapshot, RiskAlert, Student360, StudyTask, StudentGoal | `study_tasks`, `student_goals`; snapshots and alerts have no table yet |

### Where a model is not a row

| Model field | Stored as |
|---|---|
| `Institute.settings` | the institute's `institute_settings` row |
| `Profile.email`, `Profile.phone` | `users.email`, `users.phone` |
| `Invitation` | has no `token` – the token is a secret and stays on the server |
| `AttendanceSession.date` | `session_date` |
| `Attachment.ownerType`, `ownerId` | `entity_type`, `entity_id` |
| `ExamQuestion.text`, `PracticeQuestion.text` | `question_text` |
| `Result.status` | `result_status` |
| `AuditLog.targetType`, `targetId`, `before`, `after` | `entity_type`, `entity_id`, `old_data`, `new_data` |
| `Conversation.messages` | the `messages` jsonb array |
| `Installment.status` | derive from amounts and due date; do not trust a stored value that can go stale |

### Known gaps for a Supabase adapter

From `docs/DATA_MODEL.md` → Known limits, plus what this contract adds:

- `InstituteRepo.findByCode` is called by someone who cannot read `institutes` yet – it needs a `security definer` RPC or an edge function.
- `InvitationRepo.accept` needs the service role.
- `PracticeRepo.submitAttempt` and `PaymentPort.confirm` must score / verify on the server, not in the client.
- `ProgressPort` needs either SQL views / functions or two new tables for snapshots and alerts.
- `attendance_corrections` is modelled (`AttendanceCorrection`) and written only through `AttendanceRepo.correctAttendance`, which a live adapter must run as one transaction (see `supabase/migrations/0010_attendance_corrections.sql`: role check, 7-day owner rule, correction row + audit row per record).
- No model exists yet for `sessions`, `user_preferences`, `student_history`, `teacher_assignments`, `batch_teachers`, `leave_requests`, `material_access`, `teacher_feedback`. Add the model and port method first, then the adapter.

## Adding a port or a model

1. Add the type under `src/core/contracts/models/` and the interface under `ports/`.
2. Add the port to `Backend` in `ports.ts`. The compiler will then require an entry in `PORTS` (same file) and in `CHECKS` (`checks.ts`), and an implementation in every backend that does not spread the stub.
3. Implement it in `src/backends/memory/` first, then add its hook under `src/core/hooks/` and export it from `backend.tsx`.
4. Keep every file under 300 lines – split by domain as the existing folders do.
