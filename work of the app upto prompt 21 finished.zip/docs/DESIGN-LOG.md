# Design Log — GuruFlow UI System

## 2026-11-12 · Complete 35-Primitive Design System (`src/components/ui/`)

### 1. Design Laws Enforced
1. **One focal point per screen:** Hero headers (`GradientHeader` + `OverlapCard`) or a single saffron spotlight (`C.accent`) anchor visual hierarchy; surrounding cards use flat `1px` hairlines (`C.hairline`) on `#F5F6FA` (`C.canvas`).
2. **Depth from borders and space, not stacked shadows:** Cards default to `1px` hairline borders and `18pt` padding (`LAYOUT.cardPad`), reserving `SHADOW` for floating overlays (`OverlapCard`, `TabBar`, `Toast`, `ConfirmDialog` modal, `SegmentedControl` active thumb).
3. **Data is the decoration:** Metrics use `22–34pt` bold tabular numerals (`tabular-nums`) with Indian digit grouping (`₹1,24,500`, `₹4,999`).

### 2. Token Architecture (`src/lib/theme.ts`)
- Every colour literal in the repository lives in `src/lib/theme.ts` (`C`, `TONE`, `GRADIENT`, `SHADOW`).
- `grep -rn "#[0-9A-Fa-f]\{3,8\}" app/ src/` matches only `src/lib/theme.ts`.
- Every component in `src/components/ui/` accepts a `className?: string` passthrough for NativeWind composition.

### 3. Component Inventory (35 Components)

| Category | Components | Notes |
|---|---|---|
| Structure & Navigation | `Screen`, `GradientHeader`, `OverlapCard`, `Card`, `Divider`, `Tabs`, `TabBar`, `SegmentedControl` | `SegmentedControl` uses a Reanimated sliding pill thumb; `Tabs` provides `primary` and `accent` underline variants |
| Typography & Status | `Text`, `Badge`, `Chip`, `Avatar`, `AvatarStack`, `IconBox` | `AvatarStack` overlaps circles with `2px` surface rings and a tabular `+N` overflow chip |
| Forms & Pickers | `Button`, `Input`, `SearchBar`, `DateField`, `Select`, `Stepper` | `DateField` (`DD/MM/YYYY`) and `Select` (searchable) open `@gorhom/bottom-sheet` sheets; `Stepper` formats `₹` with Indian grouping |
| Data Display & Charts | `StatCard`, `ListRow`, `Table`, `Heatmap`, `ProgressBar`, `Ring`, `TrendLine`, `BarChart` | `TrendLine` and `BarChart` use `react-native-gifted-charts` (flat, no gridlines, saffron spotlight on last point / highlighted bar); `Heatmap` renders a 7-column month grid of rounded squares with legend |
| Feedback & Overlays | `EmptyArt`, `EmptyState`, `ErrorState`, `Skeleton`, `ListSkeleton`, `Sheet`, `Toast`, `ConfirmDialog` | `EmptyState` & `ErrorState` compose `EmptyArt`; `ConfirmDialog` supports typed phrase verification (`confirmText`) |

### 4. Design QA Verification (`/dev/components`)
- Renders all 35 components in 11 labelled sections with at least 2 variants/states per component.
- Uses canonical seed figures from `supabase/seed.sql` (Sunrise Coaching Classes, `SUNRISE-PAT`, Class 10-A 92% attendance, Unit Test 3 average 72% with Diya Patel 93 highest, Term 3 `₹4,999` due).
