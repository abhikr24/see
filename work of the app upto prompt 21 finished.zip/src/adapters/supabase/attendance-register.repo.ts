import {
  buildMonthRegister,
  buildRegisterDay,
  inMonth,
  monthBounds,
  type RegisterStudent,
} from '../../core/contracts/attendance-register';
import type {
  AttendanceCorrection,
  AttendanceCorrectionEntry,
  ID,
  ISODate,
  Role,
} from '../../core/contracts/models';
import type { AttendanceRepo } from '../../core/contracts/ports';
import { batchRepo } from './batch.repo';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { mapAttendanceRecord, mapAttendanceSession, toCamel } from './mappers';

type RegisterPorts = Pick<AttendanceRepo, 'monthRegister' | 'registerDay' | 'correctAttendance'>;
type Row = Record<string, unknown>;

/** Only a configured project is queried; otherwise the reference backend answers, as everywhere in this adapter. */
const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);
const today = (): ISODate => new Date().toISOString().slice(0, 10);
const must = <T>(result: { data: T | null; error: unknown }): T => {
  if (result.error) throw handleSupabaseError(result.error);
  return (result.data ?? []) as T;
};

const mapCorrection = (row: Row): AttendanceCorrection => toCamel<AttendanceCorrection>(row);

async function students(instituteId: ID, batchId: ID, extraIds: ID[]): Promise<RegisterStudent[]> {
  const enrolments = must<Row[]>(
    await supabase.from('batch_students').select('student_id, roll_number').eq('institute_id', instituteId).eq('batch_id', batchId),
  );
  const roll = new Map<ID, number | null>(
    enrolments.map((e) => [String(e.student_id), e.roll_number === null ? null : Number(e.roll_number)]),
  );
  for (const id of extraIds) if (!roll.has(id)) roll.set(id, null);
  if (roll.size === 0) return [];
  const names = must<Row[]>(
    await supabase.from('student_profiles').select('id, full_name').eq('institute_id', instituteId).in('id', [...roll.keys()]),
  );
  const nameOf = new Map(names.map((n) => [String(n.id), String(n.full_name)]));
  return [...roll].map(([studentId, rollNumber]) => ({ studentId, rollNumber, fullName: nameOf.get(studentId) ?? 'Student' }));
}

async function sessionsAndRecords(instituteId: ID, batchId: ID, from: ISODate, to: ISODate) {
  const sessions = must<Row[]>(
    await supabase
      .from('attendance_sessions').select('*')
      .eq('institute_id', instituteId).eq('batch_id', batchId).gte('session_date', from).lte('session_date', to),
  ).map(mapAttendanceSession);
  const ids = sessions.map((s) => s.id);
  const records = ids.length
    ? must<Row[]>(await supabase.from('attendance_records').select('*').eq('institute_id', instituteId).in('session_id', ids)).map(mapAttendanceRecord)
    : [];
  return { sessions, records };
}

async function currentRole(instituteId: ID): Promise<Role | null> {
  const { data: user } = await supabase.auth.getUser();
  const userId = user?.user?.id;
  if (!userId) return null;
  const rows = must<Row[]>(
    await supabase.from('memberships').select('role').eq('institute_id', instituteId).eq('user_id', userId).eq('status', 'active').limit(1),
  );
  return rows[0] ? (String(rows[0].role) as Role) : null;
}

/** Joins correction rows to the names and date a reader needs. */
async function entries(instituteId: ID, rows: AttendanceCorrection[], date: ISODate, names: Map<ID, string>, periodOf: Map<ID, number>) {
  const actorIds = [...new Set(rows.map((r) => r.requestedBy).filter((id): id is ID => Boolean(id)))];
  const profiles = actorIds.length
    ? must<Row[]>(await supabase.from('profiles').select('user_id, full_name').in('user_id', actorIds))
    : [];
  const members = actorIds.length
    ? must<Row[]>(await supabase.from('memberships').select('user_id, role').eq('institute_id', instituteId).in('user_id', actorIds))
    : [];
  const profileName = new Map(profiles.map((p) => [String(p.user_id), String(p.full_name)]));
  const roleOf = new Map(members.map((m) => [String(m.user_id), String(m.role) as Role]));
  return rows.map<AttendanceCorrectionEntry>((row) => ({
    ...row,
    date,
    period: periodOf.get(row.recordId) ?? 1,
    studentName: names.get(row.studentId) ?? 'Student',
    changedByName: row.requestedBy ? (profileName.get(row.requestedBy) ?? null) : null,
    changedByRole: row.requestedBy ? (roleOf.get(row.requestedBy) ?? null) : null,
  }));
}

export function attendanceRegisterPorts(): RegisterPorts {
  const batches = batchRepo();
  return {
    async monthRegister(instituteId, input) {
      if (!live) return memoryFallback.attendance.monthRegister(instituteId, input);
      const { batchId, month } = input;
      const { from, to } = monthBounds(month);
      const [batch, data] = await Promise.all([batches.get(instituteId, batchId), sessionsAndRecords(instituteId, batchId, from, to)]);
      const corrections = must<Row[]>(
        await supabase.from('attendance_corrections').select('*').eq('institute_id', instituteId).eq('batch_id', batchId),
      ).map(mapCorrection);
      return buildMonthRegister({
        batchId,
        batchName: batch.name,
        month,
        today: today(),
        students: await students(instituteId, batchId, data.records.map((r) => r.studentId)),
        sessions: data.sessions.filter((s) => inMonth(s.date, month)),
        records: data.records,
        corrections,
      });
    },

    async registerDay(instituteId, input) {
      if (!live) return memoryFallback.attendance.registerDay(instituteId, input);
      const { batchId, date } = input;
      const [batch, data, role] = await Promise.all([
        batches.get(instituteId, batchId),
        sessionsAndRecords(instituteId, batchId, date, date),
        currentRole(instituteId),
      ]);
      const roster = await students(instituteId, batchId, data.records.map((r) => r.studentId));
      const recordIds = data.records.map((r) => r.id);
      const rows = recordIds.length
        ? must<Row[]>(await supabase.from('attendance_corrections').select('*').eq('institute_id', instituteId).in('record_id', recordIds)).map(mapCorrection)
        : [];
      const sessionOf = new Map(data.records.map((r) => [r.id, r.sessionId]));
      const periodOf = new Map(data.sessions.map((s) => [s.id, s.period]));
      const subjectIds = [...new Set(data.sessions.map((s) => s.subjectId).filter((id): id is ID => Boolean(id)))];
      const subjects = subjectIds.length
        ? must<Row[]>(await supabase.from('subjects').select('id, name').eq('institute_id', instituteId).in('id', subjectIds))
        : [];
      const subjectName = new Map(subjects.map((s) => [String(s.id), String(s.name)]));
      return buildRegisterDay({
        batchId,
        batchName: batch.name,
        date,
        today: today(),
        role,
        students: roster,
        sheets: data.sessions.map((session) => ({
          session,
          subjectName: session.subjectId ? (subjectName.get(session.subjectId) ?? null) : null,
          records: data.records.filter((r) => r.sessionId === session.id),
        })),
        corrections: await entries(
          instituteId,
          rows,
          date,
          new Map(roster.map((s) => [s.studentId, s.fullName])),
          new Map(rows.map((r) => [r.recordId, periodOf.get(sessionOf.get(r.recordId) ?? '') ?? 1])),
        ),
      });
    },

    async correctAttendance(instituteId, input) {
      // No silent fallback here: an audit row must only ever claim what the live database did.
      if (!live) return memoryFallback.attendance.correctAttendance(instituteId, input);
      const { batchId, date, changes, reason } = input;
      const { data, error } = await supabase.rpc('correct_attendance', {
        p_institute_id: instituteId,
        p_batch_id: batchId,
        p_date: date,
        p_changes: changes.map((c) => ({ recordId: c.recordId, status: c.status })),
        p_reason: reason,
      });
      if (error) throw handleSupabaseError(error);
      const rows = ((data ?? []) as Row[]).map(mapCorrection);
      const roster = await students(instituteId, batchId, rows.map((r) => r.studentId));
      return entries(instituteId, rows, date, new Map(roster.map((s) => [s.studentId, s.fullName])), new Map());
    },
  };
}
