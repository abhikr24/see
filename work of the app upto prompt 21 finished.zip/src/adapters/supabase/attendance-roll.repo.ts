import type {
  AbsenceAlertResult,
  AttendanceRollStudent,
  AttendanceSheet,
  ID,
} from '../../core/contracts/models';
import type { AttendanceRepo } from '../../core/contracts/ports';
import { batchRepo, subjectRepo, timetableRepo } from './batch.repo';
import { memoryFallback, supabase } from './client';
import { instituteRepo } from './institute.repo';
import { mapAttendanceRecord, mapAttendanceSession } from './mappers';
import { guardianRepo } from './student.repo';

type RollPorts = Pick<AttendanceRepo, 'openRoll' | 'listSheets' | 'notifyAbsentParents'>;

async function sheetsWhere(instituteId: ID, filter: { date: string; batchId?: ID; period?: number }): Promise<AttendanceSheet[]> {
  let q = supabase.from('attendance_sessions').select('*').eq('institute_id', instituteId).eq('session_date', filter.date);
  if (filter.batchId) q = q.eq('batch_id', filter.batchId);
  if (filter.period !== undefined) q = q.eq('period', filter.period);
  const { data: sessions, error } = await q;
  if (error) throw error;
  if (!sessions?.length) return [];
  const ids = sessions.map((row) => String(row.id));
  const { data: records, error: rErr } = await supabase
    .from('attendance_records')
    .select('*')
    .eq('institute_id', instituteId)
    .in('session_id', ids);
  if (rErr) throw rErr;
  const all = (records ?? []).map(mapAttendanceRecord);
  return sessions.map((row) => {
    const session = mapAttendanceSession(row);
    return { session, records: all.filter((record) => record.sessionId === session.id) };
  });
}

/**
 * Roll-call reads and the absence alert, composed from this adapter's own repos
 * plus direct selects. Like every method in this adapter, an unreachable
 * project falls back to the reference backend (where saveSheet also landed).
 */
export function attendanceRollPorts(): RollPorts {
  const batches = batchRepo();
  const subjects = subjectRepo();
  const timetable = timetableRepo();
  const guardians = guardianRepo();
  const institutes = instituteRepo();

  return {
    async openRoll(instituteId, { batchId, date, period = 1, subjectId }) {
      try {
        const dayOfWeek = new Date(`${date}T00:00:00Z`).getUTCDay();
        const [batch, roster, periods, institute, [existing]] = await Promise.all([
          batches.get(instituteId, batchId),
          batches.listRoster(instituteId, batchId),
          timetable.listForDay(instituteId, { dayOfWeek, batchId }),
          institutes.get(instituteId),
          sheetsWhere(instituteId, { date, batchId, period }),
        ]);
        const subject = subjectId ?? existing?.session.subjectId ?? periods[0]?.subjectId ?? batch.subjectId ?? null;
        const subjectRow = subject ? await subjects.get(instituteId, subject).catch(() => null) : null;
        const students: AttendanceRollStudent[] = await Promise.all(
          roster.map(async (row) => {
            const [parent] = await guardians.listForStudent(instituteId, row.studentId);
            return {
              studentId: row.studentId,
              fullName: row.fullName,
              photoUrl: row.photoUrl,
              rollNumber: row.rollNumber,
              parentName: parent?.fullName ?? null,
              parentPhone: parent?.phone ?? null,
            };
          }),
        );
        students.sort((a, b) => (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999) || a.fullName.localeCompare(b.fullName));
        return {
          batchId,
          batchName: batch.name,
          subjectId: subjectRow?.id ?? null,
          subjectName: subjectRow?.name ?? null,
          date,
          period,
          students,
          existing: existing ?? null,
          alertsEnabled: institute.settings.features?.attendanceAlerts === true,
        };
      } catch {
        return memoryFallback.attendance.openRoll(instituteId, { batchId, date, period, subjectId });
      }
    },

    async listSheets(instituteId, filter) {
      try {
        return await sheetsWhere(instituteId, filter);
      } catch {
        return memoryFallback.attendance.listSheets(instituteId, filter);
      }
    },

    async notifyAbsentParents(instituteId, sessionId) {
      const result: AbsenceAlertResult = { sent: 0, alreadySent: 0, unreachable: 0, disabled: false };
      try {
        const institute = await institutes.get(instituteId);
        if (institute.settings.features?.attendanceAlerts !== true) return { ...result, disabled: true };
        const { data: session, error } = await supabase
          .from('attendance_sessions').select('*').eq('institute_id', instituteId).eq('id', sessionId).single();
        if (error) throw error;
        const { data: absent, error: aErr } = await supabase
          .from('attendance_records').select('student_id')
          .eq('institute_id', instituteId).eq('session_id', sessionId).eq('status', 'absent');
        if (aErr) throw aErr;
        const batch = await batches.get(instituteId, String(session.batch_id));

        for (const row of absent ?? []) {
          const studentId = String(row.student_id);
          const parents = await guardians.listForStudent(instituteId, studentId);
          const membershipIds = parents.map((p) => p.membershipId).filter((id): id is ID => Boolean(id));
          const { data: members } = membershipIds.length
            ? await supabase.from('memberships').select('user_id').in('id', membershipIds).eq('status', 'active')
            : { data: [] as { user_id: string }[] };
          const userIds = [...new Set((members ?? []).map((m) => String(m.user_id)))];
          if (!userIds.length) {
            result.unreachable += 1;
            continue;
          }
          const { data: student } = await supabase
            .from('student_profiles').select('full_name').eq('institute_id', instituteId).eq('id', studentId).single();
          const name = String(student?.full_name ?? 'Your child');
          for (const userId of userIds) {
            const { count } = await supabase
              .from('notifications').select('id', { count: 'exact', head: true })
              .eq('institute_id', instituteId).eq('user_id', userId).eq('type', 'attendance_absent')
              .contains('data', { sessionId, studentId });
            if ((count ?? 0) > 0) {
              result.alreadySent += 1;
              continue;
            }
            const { error: nErr } = await supabase.from('notifications').insert({
              institute_id: instituteId, user_id: userId, type: 'attendance_absent', channel: 'in_app',
              title: `${name} was absent today`,
              body: `${name} was marked absent in ${batch.name} on ${session.session_date}.`,
              data: { screen: 'attendance', sessionId, studentId, batchId: batch.id, date: session.session_date },
              sent_at: new Date().toISOString(),
            });
            if (nErr) throw nErr;
            result.sent += 1;
          }
        }
        return result;
      } catch {
        // Same convention as this adapter's saveSheet: an unreachable project lands in the reference backend.
        return memoryFallback.attendance.notifyAbsentParents(instituteId, sessionId);
      }
    },
  };
}
