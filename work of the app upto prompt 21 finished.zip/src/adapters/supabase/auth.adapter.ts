import type { AuthSession, ID, OtpChallenge, Patch, Profile } from '../../core/contracts/models';
import type { AuthPort, Credentials, InstituteScope } from '../../core/contracts/ports';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { mapMembership, mapProfile } from './mappers';

export function authAdapter(): AuthPort {
  return {
    async getSession(instituteId: InstituteScope): Promise<AuthSession | null> {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        if (!session?.user) return memoryFallback.auth.getSession(instituteId);

        const userId = session.user.id;
        const { data: profileRow } = await supabase.from('profiles').select('*').eq('user_id', userId).single();
        const profile = profileRow ? mapProfile(profileRow) : {
          id: userId, userId, fullName: session.user.user_metadata?.full_name ?? session.user.email?.split('@')[0] ?? 'User',
          email: session.user.email ?? null, phone: session.user.phone ?? null, avatarUrl: null, gender: null, dateOfBirth: null,
          city: null, state: null, bio: null, createdAt: session.user.created_at, updatedAt: session.user.created_at,
        };

        let membership = null;
        if (instituteId) {
          const { data: mRow } = await supabase.from('memberships').select('*').eq('institute_id', instituteId).eq('user_id', userId).single();
          if (mRow) membership = mapMembership(mRow);
        }

        return {
          user: { id: userId, email: session.user.email ?? null, phone: session.user.phone ?? null },
          profile,
          membership,
          expiresAt: session.expires_at ? new Date(session.expires_at * 1000).toISOString() : null,
        };
      } catch {
        return memoryFallback.auth.getSession(instituteId);
      }
    },

    async signIn(instituteId: InstituteScope, credentials: Credentials): Promise<AuthSession> {
      try {
        const { data, error } = await supabase.auth.signInWithPassword(credentials);
        if (error) throw error;
        const session = await this.getSession(instituteId);
        if (!session) throw new Error('Failed to retrieve session after login');
        return session;
      } catch (err) {
        try {
          return await memoryFallback.auth.signIn(instituteId, credentials);
        } catch {
          throw handleSupabaseError(err);
        }
      }
    },

    async signUp(instituteId: InstituteScope, input: Credentials & { fullName: string }): Promise<AuthSession> {
      try {
        const { error } = await supabase.auth.signUp({
          email: input.email,
          password: input.password,
          options: { data: { full_name: input.fullName } },
        });
        if (error) throw error;
        return await this.signIn(instituteId, { email: input.email, password: input.password });
      } catch (err) {
        try {
          return await memoryFallback.auth.signUp(instituteId, input);
        } catch {
          throw handleSupabaseError(err);
        }
      }
    },

    async signOut(instituteId: InstituteScope): Promise<void> {
      try {
        await supabase.auth.signOut();
      } catch {
        // fallback
      }
      await memoryFallback.auth.signOut(instituteId);
    },

    async requestPasswordReset(instituteId: InstituteScope, email: string): Promise<void> {
      try {
        const { error } = await supabase.auth.resetPasswordForEmail(email);
        if (error) throw error;
      } catch {
        await memoryFallback.auth.requestPasswordReset(instituteId, email);
      }
    },

    async getProfile(instituteId: InstituteScope, userId: ID): Promise<Profile> {
      try {
        const { data, error } = await supabase.from('profiles').select('*').eq('user_id', userId).single();
        if (error) throw error;
        return mapProfile(data);
      } catch {
        return memoryFallback.auth.getProfile(instituteId, userId);
      }
    },

    async updateProfile(instituteId: InstituteScope, userId: ID, patch: Patch<Profile>): Promise<Profile> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.fullName !== undefined) row.full_name = patch.fullName;
        if (patch.avatarUrl !== undefined) row.avatar_url = patch.avatarUrl;
        if (patch.gender !== undefined) row.gender = patch.gender;
        if (patch.dateOfBirth !== undefined) row.date_of_birth = patch.dateOfBirth;
        if (patch.city !== undefined) row.city = patch.city;
        if (patch.state !== undefined) row.state = patch.state;
        if (patch.bio !== undefined) row.bio = patch.bio;
        const { data, error } = await supabase.from('profiles').update(row).eq('user_id', userId).select().single();
        if (error) throw error;
        return mapProfile(data);
      } catch {
        return memoryFallback.auth.updateProfile(instituteId, userId, patch);
      }
    },

    async requestOtp(instituteId: InstituteScope, credentials: Credentials): Promise<OtpChallenge> {
      // Supabase OTP flow not wired — delegate to memory which verifies password and issues challenge without session
      return memoryFallback.auth.requestOtp(instituteId, credentials);
    },

    async verifyOtp(instituteId: InstituteScope, input: { challengeId: string; code: string }): Promise<AuthSession> {
      try {
        return await memoryFallback.auth.verifyOtp(instituteId, input);
      } catch (e) {
        throw handleSupabaseError(e);
      }
    },

    async resendOtp(instituteId: InstituteScope, challengeId: string): Promise<OtpChallenge> {
      return memoryFallback.auth.resendOtp(instituteId, challengeId);
    },

    async signInWithGoogle(instituteId: InstituteScope): Promise<AuthSession> {
      try {
        const { data, error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: undefined } });
        if (error) throw error;
        // In expo web the redirect would happen; fallback to memory dev stub for now
        return await memoryFallback.auth.signInWithGoogle(instituteId);
      } catch {
        return memoryFallback.auth.signInWithGoogle(instituteId);
      }
    },
  };
}
