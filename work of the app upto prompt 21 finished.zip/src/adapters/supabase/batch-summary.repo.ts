import type { BatchSummary, BatchRosterRow, ID } from '../../core/contracts/models';
import { supabase, memoryFallback, handleSupabaseError } from './client';
import { mapBatch } from './mappers';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);
export async function listBatchSummaries(i: ID): Promise<BatchSummary[]> {
  if (!live) return memoryFallback.batches.listSummaries(i);
  const { data, error } = await supabase.from('batch_summaries').select('*').eq('institute_id', i).order('name');
  if (error) throw handleSupabaseError(error);
  return (data ?? []).map((r: Record<string, unknown>) => ({ ...mapBatch(r),
    subjectName: String(r.subject_name ?? 'General'), teacherName: String(r.teacher_name ?? 'Unassigned'),
    teacherPhoto: r.teacher_photo ? String(r.teacher_photo) : null,
    studentCount: Number(r.student_count), attendanceTotal: Number(r.attendance_total), attendancePct: Number(r.attendance_pct), pendingFees: Number(r.pending_fees),
  }));
}
export async function listBatchRoster(i: ID, batchId: ID): Promise<BatchRosterRow[]> {
  if (!live) return memoryFallback.batches.listRoster(i, batchId);
  const { data, error } = await supabase.from('batch_roster').select('*').eq('institute_id', i).eq('batch_id', batchId).order('roll_number');
  if (error) throw handleSupabaseError(error);
  return (data ?? []).map((r: Record<string, unknown>) => ({ studentId: String(r.student_id),
    fullName: String(r.full_name), photoUrl: r.photo_url ? String(r.photo_url) : null,
    rollNumber: r.roll_number === null ? null : Number(r.roll_number),
    attendancePct: Number(r.attendance_pct), attendanceTotal: Number(r.attendance_total),
  }));
}
