import type { Branch, ID, NewEntity, Patch } from '../../core/contracts/models';
import type { BranchRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapBranch } from './mappers';

export function branchRepo(): BranchRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Branch>): Promise<Page<Branch>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('branches').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        if (query?.search) q = q.ilike('name', `%${query.search}%`);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('name', { ascending: true });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapBranch), count, offset, limit);
      } catch {
        return memoryFallback.branches.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Branch> {
      try {
        const { data, error } = await supabase.from('branches').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapBranch(data);
      } catch {
        return memoryFallback.branches.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<Branch, 'name' | 'code'>): Promise<Branch> {
      try {
        const { data, error } = await supabase.from('branches').insert({
          institute_id: instituteId, name: input.name, code: input.code.toUpperCase(), address: input.address ?? null,
          city: input.city ?? null, state: input.state ?? null, pincode: input.pincode ?? null, phone: input.phone ?? null,
          is_main: input.isMain ?? false, status: input.status ?? 'active',
        }).select().single();
        if (error) throw error;
        return mapBranch(data);
      } catch {
        return memoryFallback.branches.create(instituteId, input);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<Branch>): Promise<Branch> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.name !== undefined) row.name = patch.name;
        if (patch.code !== undefined) row.code = patch.code;
        if (patch.address !== undefined) row.address = patch.address;
        if (patch.city !== undefined) row.city = patch.city;
        if (patch.state !== undefined) row.state = patch.state;
        if (patch.pincode !== undefined) row.pincode = patch.pincode;
        if (patch.phone !== undefined) row.phone = patch.phone;
        if (patch.isMain !== undefined) row.is_main = patch.isMain;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('branches').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapBranch(data);
      } catch {
        return memoryFallback.branches.update(instituteId, id, patch);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('branches').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.branches.remove(instituteId, id);
      }
    },
  };
}
