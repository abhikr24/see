import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { BackendError, isBackendError } from '../../core/contracts/errors';
import type { ID } from '../../core/contracts/models';
import type { ListQuery, Page } from '../../core/contracts/query';
import { createMemoryBackend } from '../../backends/memory';

export const AppError = BackendError;
export type AppError = BackendError;

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://placeholder-guruflow.supabase.co';
const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.placeholder';

export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true },
});

export function handleSupabaseError(error: unknown, fallbackMessage?: string): BackendError {
  if (isBackendError(error)) return error;
  if (!error) return new BackendError('UNKNOWN', fallbackMessage ?? 'Unknown error occurred');

  const err = error as { code?: string; message?: string; details?: string; hint?: string; status?: number; name?: string };
  const code = String(err.code ?? '');
  const message = String(err.message ?? fallbackMessage ?? 'Database error');
  const msgLower = message.toLowerCase();

  if (code === 'PGRST116' || msgLower.includes('no rows') || msgLower.includes('not found')) {
    return new BackendError('NOT_FOUND', 'That record could not be found.', { origin: error });
  }
  if (code === '23505' || msgLower.includes('duplicate key') || msgLower.includes('unique constraint') || msgLower.includes('already exists')) {
    return new BackendError('CONFLICT', 'That conflicts with an existing record.', { origin: error });
  }
  if (code === '42501' || msgLower.includes('row-level security') || msgLower.includes('permission denied') || msgLower.includes('unauthorized') || msgLower.includes('forbidden')) {
    return new BackendError('FORBIDDEN', 'You do not have permission to do that.', { origin: error });
  }
  if (code === '23514' || code === '23503' || code === '22P02' || msgLower.includes('check constraint') || msgLower.includes('foreign key') || msgLower.includes('invalid input')) {
    return new BackendError('VALIDATION', 'Some of the details are not valid.', { origin: error });
  }
  if (err.name === 'AbortError' || msgLower.includes('timeout') || err.status === 504) {
    return new BackendError('TIMEOUT', 'That took too long. Try again.', { origin: error });
  }
  if (msgLower.includes('network') || msgLower.includes('failed to fetch') || msgLower.includes('fetch failed') || msgLower.includes('networkrequestfailed')) {
    return new BackendError('NETWORK', 'No connection. Check your internet and try again.', { origin: error });
  }
  if (err.status === 429 || msgLower.includes('rate limit')) {
    return new BackendError('RATE_LIMITED', 'Too many requests. Try again shortly.', { origin: error });
  }
  if (err.status && err.status >= 500) {
    return new BackendError('UNAVAILABLE', 'The service is unavailable right now.', { origin: error });
  }

  return new BackendError('UNKNOWN', message || 'Something went wrong.', { origin: error });
}

export interface PaginatedResult<T> extends Page<T> {
  rows: T[];
  total: number | null;
  hasMore: boolean;
}

export const DEFAULT_PAGE_LIMIT = 20;

export function parseCursor(cursor?: string | null): number {
  if (!cursor) return 0;
  const parsed = parseInt(cursor, 10);
  return Number.isNaN(parsed) || parsed < 0 ? 0 : parsed;
}

export function toPaginatedResult<T>(items: T[], total: number | null, offset: number, limit: number): PaginatedResult<T> {
  const hasMore = total !== null ? offset + items.length < total : items.length === limit;
  const nextCursor = hasMore ? String(offset + items.length) : null;
  return {
    items,
    rows: items,
    total,
    hasMore,
    nextCursor,
  };
}

// Fallback seed delegate for contract check and offline execution when no remote DB is reachable
export const memoryFallback = createMemoryBackend();
