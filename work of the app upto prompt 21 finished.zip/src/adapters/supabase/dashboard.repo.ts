import type { DashboardBatch, ID, OwnerDashboard } from '../../core/contracts/models';
import type { AnalyticsRepo } from '../../core/contracts/ports';
import { memoryFallback, supabase } from './client';
import { progressRepo } from './progress.repo';

/** "This week" on the dashboard: the seven days ending today. */
const ALERT_WINDOW_DAYS = 7;

type Row = Record<string, unknown>;
type Query = PromiseLike<{ data: unknown; error: unknown }>;

async function rows(query: Query): Promise<Row[]> {
  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as Row[];
}

const text = (value: unknown): string => String(value ?? '');
const time = (value: unknown): string => text(value).slice(0, 5);
const round2 = (value: number): number => Math.round(value * 100) / 100;
const sum = (values: number[]): number => values.reduce((a, b) => a + b, 0);

function shiftDays(date: string, days: number): string {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function clock(at = new Date()): string {
  return `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;
}

/**
 * AnalyticsRepo.dashboard for Postgres. Dates follow the same rule as the rest
 * of this adapter (UTC calendar day). Ten small selects for now; the natural
 * next step is one SQL function so the whole screen is a single round trip.
 */
async function load(instituteId: ID): Promise<OwnerDashboard> {
  const today = new Date().toISOString().slice(0, 10);
  const dayOfWeek = new Date(`${today}T00:00:00Z`).getUTCDay();
  const scoped = (table: string, columns: string) => supabase.from(table).select(columns).eq('institute_id', instituteId);

  const [batches, periods, payments, sessions, overdue, pending] = await Promise.all([
    rows(scoped('batches', 'id, name, status').in('status', ['active', 'upcoming'])),
    rows(
      scoped('timetables', 'batch_id, teacher_id, starts_at, ends_at, valid_from, valid_to')
        .eq('day_of_week', dayOfWeek)
        .order('starts_at', { ascending: true }),
    ),
    rows(
      scoped('payments', 'amount')
        .eq('status', 'completed')
        .gte('paid_at', `${today}T00:00:00.000Z`)
        .lt('paid_at', `${shiftDays(today, 1)}T00:00:00.000Z`),
    ),
    rows(scoped('attendance_sessions', 'id').eq('session_date', today)),
    rows(scoped('installments', 'student_id, amount, paid_amount').neq('status', 'waived').lt('due_date', today)),
    supabase
      .from('memberships')
      .select('id', { count: 'exact', head: true })
      .eq('institute_id', instituteId)
      .eq('status', 'pending'),
  ]);
  if (pending.error) throw pending.error;

  const activeNames = new Map(batches.filter((b) => b.status === 'active').map((b) => [text(b.id), text(b.name)]));
  const todays = periods.filter(
    (p) =>
      activeNames.has(text(p.batch_id)) &&
      (!p.valid_from || text(p.valid_from) <= today) &&
      (!p.valid_to || text(p.valid_to) >= today),
  );
  const batchIds = [...new Set(todays.map((p) => text(p.batch_id)))];
  const teacherIds = [...new Set(todays.filter((p) => p.teacher_id).map((p) => text(p.teacher_id)))];
  const sessionIds = sessions.map((s) => text(s.id));

  const [records, enrolled, teachers, alerts] = await Promise.all([
    sessionIds.length ? rows(scoped('attendance_records', 'status').in('session_id', sessionIds)) : [],
    batchIds.length ? rows(scoped('batch_students', 'batch_id').eq('status', 'active').in('batch_id', batchIds)) : [],
    teacherIds.length ? rows(scoped('teacher_profiles', 'id, full_name, photo_url').in('id', teacherIds)) : [],
    progressRepo().computeAlerts(instituteId),
  ]);

  const byBatch = new Map<ID, DashboardBatch>();
  for (const period of todays) {
    const batchId = text(period.batch_id);
    const row = byBatch.get(batchId) ?? {
      batchId,
      name: activeNames.get(batchId) ?? '',
      startsAt: time(period.starts_at),
      endsAt: time(period.ends_at),
      teachers: [],
      studentCount: enrolled.filter((e) => text(e.batch_id) === batchId).length,
    };
    if (time(period.ends_at) > row.endsAt) row.endsAt = time(period.ends_at);
    const teacher = teachers.find((t) => text(t.id) === text(period.teacher_id));
    if (teacher && !row.teachers.some((t) => t.id === text(teacher.id))) {
      row.teachers.push({
        id: text(teacher.id),
        fullName: text(teacher.full_name),
        photoUrl: teacher.photo_url ? text(teacher.photo_url) : null,
      });
    }
    byBatch.set(batchId, row);
  }
  const batchesToday = [...byBatch.values()];
  const now = clock();
  const current = batchesToday.find((batch) => batch.endsAt > now) ?? batchesToday[batchesToday.length - 1];

  const attended = records.filter((r) => r.status === 'present' || r.status === 'late').length;
  const owed = overdue
    .map((x) => ({ studentId: text(x.student_id), due: round2(Number(x.amount) - Number(x.paid_amount)) }))
    .filter((x) => x.due > 0);
  const weekStart = shiftDays(today, 1 - ALERT_WINDOW_DAYS);

  return {
    date: today,
    batchCount: batches.length,
    collectedToday: round2(sum(payments.map((p) => Number(p.amount)))),
    attendancePercent: records.length ? Math.round((attended / records.length) * 1000) / 10 : null,
    pendingApprovals: pending.count ?? 0,
    overdueAmount: round2(sum(owed.map((x) => x.due))),
    overdueStudents: new Set(owed.map((x) => x.studentId)).size,
    lowAttendanceAlerts: alerts.filter(
      (a) => a.kind === 'low_attendance' && a.status === 'open' && a.detectedAt.slice(0, 10) >= weekStart,
    ).length,
    batchesToday,
    currentBatchId: current?.batchId ?? null,
  };
}

/** Same fallback rule as every repo in this adapter: unreachable database → the bundled reference data. */
export const dashboard: AnalyticsRepo['dashboard'] = async (instituteId) => {
  try {
    return await load(instituteId);
  } catch {
    return memoryFallback.analytics.dashboard(instituteId);
  }
};
