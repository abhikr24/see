/**
 * The live (Postgres) exam analysis.
 *
 * Reads the exam, its marks, the batch roster and the other exams of the
 * batch, then hands everything to the shared `buildExamAnalysis` — the same
 * calculation the reference backend uses. If Postgres cannot be reached the
 * adapter falls back to the reference backend, like every other read here.
 */

import type { Exam, ExamAnalysis, ID, Mark } from '../../core/contracts/models';
import {
  buildExamAnalysis,
  round1,
  type AnalysisHistoryPoint,
  type AnalysisSubjectInput,
} from '../../core/contracts/exam-analysis';
import { memoryFallback, supabase } from './client';
import { mapEnrollment, mapExam, mapMark, mapStudent, mapSubject } from './mappers';

type Row = Record<string, unknown>;

function examDate(exam: Exam): string {
  return exam.startsOn ?? exam.createdAt.slice(0, 10);
}

function averageOf(rows: Mark[]): number | null {
  const scored = rows.filter((row) => !row.isAbsent && row.marksObtained !== null);
  if (!scored.length) return null;
  const total = scored.reduce((sum, row) => sum + (row.marksObtained ?? 0) / (row.maxMarks || 1) * 100, 0);
  return round1(total / scored.length);
}

export async function supabaseExamAnalysis(instituteId: ID, examId: ID): Promise<ExamAnalysis> {
  try {
    const { data: examRow, error: examError } = await supabase
      .from('exams')
      .select('*')
      .eq('institute_id', instituteId)
      .eq('id', examId)
      .single();
    if (examError) throw examError;
    const exam = mapExam(examRow as Row);

    const [{ data: batchRow }, { data: subjectRows }] = await Promise.all([
      supabase.from('batches').select('*').eq('institute_id', instituteId).eq('id', exam.batchId).single(),
      supabase.from('subjects').select('*').eq('institute_id', instituteId),
    ]);
    const batchName = String((batchRow as Row | null)?.name ?? 'Batch');

    const { data: enrollmentRows } = await supabase
      .from('enrollments')
      .select('*')
      .eq('institute_id', instituteId)
      .eq('batch_id', exam.batchId)
      .eq('status', 'active');
    const enrollments = (enrollmentRows ?? []).map((row) => mapEnrollment(row as Row));
    const studentIds = enrollments.map((enrollment) => enrollment.studentId);

    const { data: studentRows } = studentIds.length
      ? await supabase.from('students').select('*').eq('institute_id', instituteId).in('id', studentIds)
      : { data: [] as Row[] };
    const students = (studentRows ?? []).map((row) => mapStudent(row as Row));
    const studentById = new Map(students.map((student) => [student.id, student]));

    const { data: examRows } = await supabase
      .from('exams')
      .select('*')
      .eq('institute_id', instituteId)
      .eq('batch_id', exam.batchId);
    const batchExams = (examRows ?? []).map((row) => mapExam(row as Row));
    const batchExamIds = batchExams.map((other) => other.id);

    const { data: markRows } = batchExamIds.length
      ? await supabase.from('marks').select('*').eq('institute_id', instituteId).in('exam_id', batchExamIds)
      : { data: [] as Row[] };
    const allMarks = (markRows ?? []).map((row) => mapMark(row as Row));

    const marksByExam = new Map<ID, Mark[]>();
    for (const mark of allMarks) {
      const list = marksByExam.get(mark.examId) ?? [];
      list.push(mark);
      marksByExam.set(mark.examId, list);
    }
    const marks = marksByExam.get(exam.id) ?? [];

    const history: AnalysisHistoryPoint[] = [];
    for (const other of batchExams) {
      if (other.id === exam.id) continue;
      const averagePct = averageOf(marksByExam.get(other.id) ?? []);
      if (averagePct === null) continue;
      history.push({ examId: other.id, examName: other.name, averagePct, date: examDate(other) });
    }

    const latestBySubject = new Map<ID, Exam>();
    for (const other of [...batchExams].sort((a, b) => examDate(a).localeCompare(examDate(b)))) {
      for (const mark of marksByExam.get(other.id) ?? []) latestBySubject.set(mark.subjectId, other);
    }

    const subjectNames = new Map((subjectRows ?? []).map((row) => mapSubject(row as Row)).map((subject) => [subject.id, subject.name]));
    const subjectAverages: AnalysisSubjectInput[] = [];
    for (const [subjectId, owner] of latestBySubject) {
      const rows = (marksByExam.get(owner.id) ?? []).filter((mark) => mark.subjectId === subjectId);
      const scored = rows.filter((row) => !row.isAbsent && row.marksObtained !== null);
      subjectAverages.push({
        subjectId,
        subjectName: subjectNames.get(subjectId) ?? 'Subject',
        averagePct: averageOf(rows) ?? 0,
        students: scored.length,
        maxMarks: rows[0]?.maxMarks ?? 0,
      });
    }

    const subjectName =
      subjectNames.get(exam.subjectId ?? marks[0]?.subjectId ?? '') ?? 'General';

    return buildExamAnalysis({
      exam,
      subjectName,
      batchName,
      marks,
      students: enrollments.map((enrollment) => {
        const student = studentById.get(enrollment.studentId);
        return {
          studentId: enrollment.studentId,
          fullName: student?.fullName ?? 'Student',
          rollNumber: enrollment.rollNumber,
          photoUrl: student?.photoUrl ?? null,
        };
      }),
      history,
      subjectAverages,
      passPercent: exam.passPercent,
    });
  } catch {
    return memoryFallback.results.analysis(instituteId, examId);
  }
}
