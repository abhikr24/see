import { buildPlanView, buildStatement, type PlanSource } from '../../core/contracts/fee-plan';
import { BackendError, type ErrorCode } from '../../core/contracts/errors';
import type { ID, SavePlanResult } from '../../core/contracts/models';
import type { FeeRepo } from '../../core/contracts/ports';
import { batchRepo } from './batch.repo';
import { memoryFallback, supabase } from './client';
import { mapFeeStructure, mapInstallment, mapPayment, mapStudentFee, toCamel } from './mappers';

type PlanPorts = Pick<FeeRepo, 'getPlan' | 'savePlan' | 'applyStudentDiscounts' | 'studentStatement'>;
type Row = Record<string, unknown>;

/** Only a configured project is queried; otherwise the reference backend answers, as everywhere in this adapter. */
const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);
const today = (): string => new Date().toISOString().slice(0, 10);

const CODES: Record<string, ErrorCode> = {
  '42501': 'FORBIDDEN',
  '23514': 'VALIDATION',
  '23505': 'CONFLICT',
  '40001': 'CONFLICT',
  P0002: 'NOT_FOUND',
};

/** Keeps the database's own sentence: the fee-plan functions word their errors for the owner. */
function plain(error: { code?: string; message?: string }): BackendError {
  return new BackendError(CODES[error.code ?? ''] ?? 'UNKNOWN', error.message || 'Could not save the fee plan');
}

const must = <T>(result: { data: T | null; error: { code?: string; message?: string } | null }): T => {
  if (result.error) throw plain(result.error);
  return (result.data ?? []) as T;
};

async function source(instituteId: ID): Promise<PlanSource> {
  const [structures, fees, installments, payments] = await Promise.all([
    supabase.from('fee_structures').select('*').eq('institute_id', instituteId),
    supabase.from('student_fees').select('*').eq('institute_id', instituteId),
    supabase.from('installments').select('*').eq('institute_id', instituteId),
    supabase.from('payments').select('*').eq('institute_id', instituteId),
  ]);
  return {
    structures: must<Row[]>(structures).map(mapFeeStructure),
    studentFees: must<Row[]>(fees).map(mapStudentFee),
    installments: must<Row[]>(installments).map(mapInstallment),
    payments: must<Row[]>(payments).map(mapPayment),
  };
}

export function feePlanRepo(): PlanPorts {
  const batches = batchRepo();
  return {
    async getPlan(instituteId, batchId) {
      if (!live) return memoryFallback.fees.getPlan(instituteId, batchId);
      const [list, roster, src] = await Promise.all([
        batches.listSummaries(instituteId),
        batches.listRoster(instituteId, batchId),
        source(instituteId),
      ]);
      const batch = list.find((b) => b.id === batchId);
      if (!batch) throw new BackendError('NOT_FOUND', 'Batch not found');
      return buildPlanView(
        {
          batchId,
          batchName: batch.name,
          batches: list.filter((b) => b.status !== 'archived').map((b) => ({ id: b.id, name: b.name, studentCount: b.studentCount })),
          roster: roster.map((r) => ({ studentId: r.studentId, fullName: r.fullName, rollNumber: r.rollNumber })),
          feeAmount: batch.feeAmount ?? 0,
          feeFrequency: batch.feePlan ?? 'term',
          today: today(),
        },
        src,
      );
    },

    async savePlan(instituteId, input) {
      if (!live) return memoryFallback.fees.savePlan(instituteId, input);
      const data = must<Row>(await supabase.rpc('save_fee_plan', { p_institute_id: instituteId, p_input: input }));
      const out = toCamel<{ structureId: ID; versioned: boolean; previousId: ID | null; studentsUpdated: number; studentsKept: number }>(data);
      const { data: row, error } = await supabase.from('fee_structures').select('*').eq('id', out.structureId).single();
      if (error) throw plain(error);
      const result: SavePlanResult = {
        structure: mapFeeStructure(row as Row),
        versioned: out.versioned,
        previousId: out.previousId,
        studentsUpdated: out.studentsUpdated,
        studentsKept: out.studentsKept,
      };
      return result;
    },

    async applyStudentDiscounts(instituteId, { studentId, discountIds }) {
      if (!live) return memoryFallback.fees.applyStudentDiscounts(instituteId, { studentId, discountIds });
      const data = must<Row>(
        await supabase.rpc('apply_student_discounts', { p_institute_id: instituteId, p_student_id: studentId, p_ids: discountIds }),
      );
      return mapStudentFee(data);
    },

    async studentStatement(instituteId, studentId) {
      if (!live) return memoryFallback.fees.studentStatement(instituteId, studentId);
      return buildStatement(studentId, await source(instituteId));
    },
  };
}
