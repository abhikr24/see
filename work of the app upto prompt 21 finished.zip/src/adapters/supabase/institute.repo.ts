import type { ID, Institute, InstituteSettings, NewEntity, Patch } from '../../core/contracts/models';
import type { InstituteRepo, InstituteScope } from '../../core/contracts/ports';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { mapInstitute } from './mappers';

export function instituteRepo(): InstituteRepo {
  return {
    async listMine(instituteId: InstituteScope): Promise<Institute[]> {
      try {
        const { data, error } = await supabase.from('institutes').select('*, institute_settings(*)');
        if (error) throw error;
        return (data ?? []).map((row) => mapInstitute(row, Array.isArray(row.institute_settings) ? row.institute_settings[0] : row.institute_settings));
      } catch {
        return memoryFallback.institutes.listMine(instituteId);
      }
    },

    async findByCode(instituteId: InstituteScope, code: string): Promise<Institute | null> {
      try {
        const { data, error } = await supabase.from('institutes').select('*, institute_settings(*)').eq('code', code.trim().toUpperCase()).maybeSingle();
        if (error) throw error;
        if (!data) return null;
        return mapInstitute(data, Array.isArray(data.institute_settings) ? data.institute_settings[0] : data.institute_settings);
      } catch {
        return memoryFallback.institutes.findByCode(instituteId, code);
      }
    },

    async search(instituteId: InstituteScope, query: string): Promise<Institute[]> {
      const q = query.trim();
      if (!q) return [];
      try {
        // Try exact code first
        const { data: exact } = await supabase.from('institutes').select('*, institute_settings(*)').eq('code', q.toUpperCase()).maybeSingle();
        if (exact) return [mapInstitute(exact, Array.isArray(exact.institute_settings) ? exact.institute_settings[0] : exact.institute_settings)];
        const { data, error } = await supabase
          .from('institutes')
          .select('*, institute_settings(*)')
          .or(`name.ilike.%${q}%,code.ilike.%${q}%,city.ilike.%${q}%`)
          .limit(12);
        if (error) throw error;
        return (data ?? []).map((row) => mapInstitute(row, Array.isArray(row.institute_settings) ? row.institute_settings[0] : row.institute_settings));
      } catch {
        return memoryFallback.institutes.search(instituteId, query);
      }
    },

    async create(instituteId: InstituteScope, input: NewEntity<Institute, 'name' | 'code'>): Promise<Institute> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const ownerId = user?.user?.id ?? '00000000-0000-4000-8000-000000000002';
        // Let memory fallback handle code generation & atomic side-effects if supabase insert fails or code missing
        const fallbackCode = (input.code ?? '').trim();
        if (!fallbackCode) {
          return memoryFallback.institutes.create(instituteId, input);
        }
        const { data, error } = await supabase.from('institutes').insert({
          name: input.name, code: input.code.toUpperCase(), owner_id: ownerId, tagline: input.tagline ?? null,
          phone: input.phone ?? null, email: input.email ?? null, address: input.address ?? null, city: input.city ?? null,
          state: input.state ?? null, pincode: input.pincode ?? null, country: input.country ?? 'IN', logo_url: input.logoUrl ?? null,
        }).select('*, institute_settings(*)').single();
        if (error) throw error;
        const institute = mapInstitute(data, Array.isArray(data.institute_settings) ? data.institute_settings[0] : data.institute_settings);
        // Best-effort: create fee terms + audit via RPC/fallback; supabase triggers may handle this server-side
        try {
          const ay = (input as unknown as { settings?: { academicYear?: string } }).settings?.academicYear ?? '2026-27';
          for (let t = 1; t <= 3; t++) {
            await supabase.from('fee_structures').insert({ institute_id: institute.id, name: `Term ${t}`, academic_year: ay, total_amount: 0, installment_count: 1, frequency: 'term', is_active: true });
          }
          await supabase.from('audit_logs').insert({ institute_id: institute.id, action: 'institute.created', actor_id: ownerId, target_type: 'institute', target_id: institute.id });
        } catch {}
        return institute;
      } catch {
        return memoryFallback.institutes.create(instituteId, input);
      }
    },

    async get(instituteId: ID): Promise<Institute> {
      try {
        const { data, error } = await supabase.from('institutes').select('*, institute_settings(*)').eq('id', instituteId).single();
        if (error) throw error;
        return mapInstitute(data, Array.isArray(data.institute_settings) ? data.institute_settings[0] : data.institute_settings);
      } catch {
        return memoryFallback.institutes.get(instituteId);
      }
    },

    async update(instituteId: ID, patch: Omit<Patch<Institute>, 'settings'>): Promise<Institute> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.name !== undefined) row.name = patch.name;
        if (patch.code !== undefined) row.code = patch.code;
        if (patch.tagline !== undefined) row.tagline = patch.tagline;
        if (patch.phone !== undefined) row.phone = patch.phone;
        if (patch.email !== undefined) row.email = patch.email;
        if (patch.address !== undefined) row.address = patch.address;
        if (patch.city !== undefined) row.city = patch.city;
        if (patch.state !== undefined) row.state = patch.state;
        if (patch.pincode !== undefined) row.pincode = patch.pincode;
        if (patch.logoUrl !== undefined) row.logo_url = patch.logoUrl;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('institutes').update(row).eq('id', instituteId).select('*, institute_settings(*)').single();
        if (error) throw error;
        return mapInstitute(data, Array.isArray(data.institute_settings) ? data.institute_settings[0] : data.institute_settings);
      } catch {
        return memoryFallback.institutes.update(instituteId, patch);
      }
    },

    async updateSettings(instituteId: ID, patch: Partial<InstituteSettings>): Promise<Institute> {
      try {
        const sRow: Record<string, unknown> = {};
        if (patch.academicYear !== undefined) sRow.academic_year = patch.academicYear;
        if (patch.timezone !== undefined) sRow.timezone = patch.timezone;
        if (patch.currency !== undefined) sRow.currency = patch.currency;
        if (patch.locale !== undefined) sRow.locale = patch.locale;
        if (patch.workingDays !== undefined) sRow.working_days = patch.workingDays;
        if (patch.attendanceMode !== undefined) sRow.attendance_mode = patch.attendanceMode;
        if (patch.minAttendancePercent !== undefined) sRow.min_attendance_percent = patch.minAttendancePercent;
        if (patch.passPercent !== undefined) sRow.pass_percent = patch.passPercent;
        if (patch.lateFeePerDay !== undefined) sRow.late_fee_per_day = patch.lateFeePerDay;
        if (patch.receiptPrefix !== undefined) sRow.receipt_prefix = patch.receiptPrefix;
        if (patch.allowJoinRequests !== undefined) sRow.allow_join_requests = patch.allowJoinRequests;
        if (patch.features !== undefined) sRow.features = patch.features;
        await supabase.from('institute_settings').update(sRow).eq('institute_id', instituteId);
        return await this.get(instituteId);
      } catch {
        return memoryFallback.institutes.updateSettings(instituteId, patch);
      }
    },
  };
}
