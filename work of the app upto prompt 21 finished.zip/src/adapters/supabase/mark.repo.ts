import type { ID, Mark } from '../../core/contracts/models';
import type { MarkEntry, MarkRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapMark } from './mappers';

export function markRepo(): MarkRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Mark>): Promise<Page<Mark>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('marks').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.examId) q = q.eq('exam_id', query.where.examId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapMark), count, offset, limit);
      } catch {
        return memoryFallback.marks.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Mark> {
      try {
        const { data, error } = await supabase.from('marks').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapMark(data);
      } catch {
        return memoryFallback.marks.get(instituteId, id);
      }
    },

    async saveMany(instituteId: ID, examId: ID, entries: MarkEntry[]): Promise<Mark[]> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const userId = user?.user?.id ?? null;
        const { data: exam } = await supabase.from('exams').select('batch_id').eq('id', examId).single();
        const batchId = exam?.batch_id ?? '00000000-0000-4000-8000-000000000009';

        const rows = entries.map((e) => ({
          institute_id: instituteId, exam_id: examId, batch_id: batchId, student_id: e.studentId,
          subject_id: e.subjectId, marks_obtained: e.marksObtained, max_marks: e.maxMarks,
          is_absent: e.isAbsent ?? false, remark: e.remark ?? null, entered_by: userId,
        }));

        const { data, error } = await supabase.from('marks').upsert(rows, { onConflict: 'exam_id,student_id,subject_id' }).select();
        if (error) throw error;
        return (data ?? []).map(mapMark);
      } catch {
        return memoryFallback.marks.saveMany(instituteId, examId, entries);
      }
    },
  };
}
