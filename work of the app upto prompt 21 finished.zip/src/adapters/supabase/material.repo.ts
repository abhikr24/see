import type { Bookmark, ID, Material, NewEntity, Patch } from '../../core/contracts/models';
import type { MaterialRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapBookmark, mapMaterial } from './mappers';

export function materialRepo(): MaterialRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Material>): Promise<Page<Material>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('materials').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        if (query?.where?.subjectId) q = q.eq('subject_id', query.where.subjectId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapMaterial), count, offset, limit);
      } catch {
        return memoryFallback.materials.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Material> {
      try {
        const { data, error } = await supabase.from('materials').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapMaterial(data);
      } catch {
        return memoryFallback.materials.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<Material, 'title'>): Promise<Material> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('materials').insert({
          institute_id: instituteId, title: input.title, batch_id: input.batchId ?? null,
          subject_id: input.subjectId ?? null, teacher_id: input.teacherId ?? null,
          description: input.description ?? null, material_type: input.materialType ?? 'notes',
          url: input.url ?? null, storage_path: input.storagePath ?? null, topic: input.topic ?? null,
          is_published: input.isPublished ?? true, uploaded_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapMaterial(data);
      } catch {
        return memoryFallback.materials.create(instituteId, input);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<Material>): Promise<Material> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.title !== undefined) row.title = patch.title;
        if (patch.description !== undefined) row.description = patch.description;
        if (patch.materialType !== undefined) row.material_type = patch.materialType;
        if (patch.url !== undefined) row.url = patch.url;
        if (patch.storagePath !== undefined) row.storage_path = patch.storagePath;
        if (patch.topic !== undefined) row.topic = patch.topic;
        if (patch.isPublished !== undefined) row.is_published = patch.isPublished;
        const { data, error } = await supabase.from('materials').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapMaterial(data);
      } catch {
        return memoryFallback.materials.update(instituteId, id, patch);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('materials').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.materials.remove(instituteId, id);
      }
    },

    async listBookmarks(instituteId: ID, userId: ID): Promise<Bookmark[]> {
      try {
        const { data, error } = await supabase.from('bookmarks').select('*').eq('institute_id', instituteId).eq('user_id', userId);
        if (error) throw error;
        return (data ?? []).map(mapBookmark);
      } catch {
        return memoryFallback.materials.listBookmarks(instituteId, userId);
      }
    },

    async addBookmark(instituteId: ID, input: NewEntity<Bookmark, 'userId' | 'targetType' | 'targetId'>): Promise<Bookmark> {
      try {
        const { data, error } = await supabase.from('bookmarks').insert({
          institute_id: instituteId, user_id: input.userId, target_type: input.targetType,
          target_id: input.targetId, note: input.note ?? null,
        }).select().single();
        if (error) throw error;
        return mapBookmark(data);
      } catch {
        return memoryFallback.materials.addBookmark(instituteId, input);
      }
    },

    async removeBookmark(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('bookmarks').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.materials.removeBookmark(instituteId, id);
      }
    },
  };
}
