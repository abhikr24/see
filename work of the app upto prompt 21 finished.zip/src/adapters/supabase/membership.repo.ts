import type { ID, Invitation, JoinRole, Membership, NewEntity, Permission, Role } from '../../core/contracts/models';
import type { InvitationRepo, MembershipRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapInvitation, mapMembership } from './mappers';

export function membershipRepo(): MembershipRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Membership>): Promise<Page<Membership>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('memberships').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.role) q = q.eq('role', query.where.role);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapMembership), count, offset, limit);
      } catch {
        return memoryFallback.memberships.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Membership> {
      try {
        const { data, error } = await supabase.from('memberships').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapMembership(data);
      } catch {
        return memoryFallback.memberships.get(instituteId, id);
      }
    },

    async getMine(instituteId: ID): Promise<Membership | null> {
      try {
        const { data: user } = await supabase.auth.getUser();
        if (!user?.user) return memoryFallback.memberships.getMine(instituteId);
        const { data, error } = await supabase.from('memberships').select('*').eq('institute_id', instituteId).eq('user_id', user.user.id).maybeSingle();
        if (error) throw error;
        return data ? mapMembership(data) : null;
      } catch {
        return memoryFallback.memberships.getMine(instituteId);
      }
    },

    async requestToJoin(instituteId: ID, input: { role: JoinRole; note?: string | null }): Promise<Membership> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const userId = user?.user?.id ?? '00000000-0000-4000-8000-000000000038';
        const { data, error } = await supabase.from('memberships').insert({
          institute_id: instituteId, user_id: userId, role: input.role, status: 'pending', request_note: input.note ?? null,
        }).select().single();
        if (error) throw error;
        return mapMembership(data);
      } catch {
        return memoryFallback.memberships.requestToJoin(instituteId, input);
      }
    },

    async decide(instituteId: ID, id: ID, status: 'active' | 'rejected' | 'suspended'): Promise<Membership> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('memberships').update({
          status, decided_by: user?.user?.id ?? null, decided_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapMembership(data);
      } catch {
        return memoryFallback.memberships.decide(instituteId, id, status);
      }
    },

    async setRole(instituteId: ID, id: ID, role: Role, permissions: Permission[] = []): Promise<Membership> {
      try {
        const { data, error } = await supabase.from('memberships').update({
          role, permissions,
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapMembership(data);
      } catch {
        return memoryFallback.memberships.setRole(instituteId, id, role, permissions);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('memberships').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.memberships.remove(instituteId, id);
      }
    },
  };
}

export function invitationRepo(): InvitationRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Invitation>): Promise<Page<Invitation>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('invitations').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapInvitation), count, offset, limit);
      } catch {
        return memoryFallback.invitations.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Invitation> {
      try {
        const { data, error } = await supabase.from('invitations').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapInvitation(data);
      } catch {
        return memoryFallback.invitations.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<Invitation, 'role'>): Promise<Invitation> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('invitations').insert({
          institute_id: instituteId, role: input.role, email: input.email ?? null, phone: input.phone ?? null,
          full_name: input.fullName ?? null, invited_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapInvitation(data);
      } catch {
        return memoryFallback.invitations.create(instituteId, input);
      }
    },

    async resend(instituteId: ID, id: ID): Promise<Invitation> {
      try {
        const expiresAt = new Date(Date.now() + 7 * 86400000).toISOString();
        const { data, error } = await supabase.from('invitations').update({ expires_at: expiresAt, status: 'pending' }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapInvitation(data);
      } catch {
        return memoryFallback.invitations.resend(instituteId, id);
      }
    },

    async revoke(instituteId: ID, id: ID): Promise<Invitation> {
      try {
        const { data, error } = await supabase.from('invitations').update({ status: 'revoked' }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapInvitation(data);
      } catch {
        return memoryFallback.invitations.revoke(instituteId, id);
      }
    },

    async accept(instituteId: ID, token: string): Promise<Membership> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const userId = user?.user?.id ?? '00000000-0000-4000-8000-000000000038';
        const { data: inv, error: invErr } = await supabase.from('invitations').select('*').eq('institute_id', instituteId).eq('token', token).single();
        if (invErr || !inv) throw invErr ?? new Error('Invalid invitation token');
        await supabase.from('invitations').update({ status: 'accepted', accepted_by: userId, accepted_at: new Date().toISOString() }).eq('id', inv.id);
        const { data: mem, error: memErr } = await supabase.from('memberships').insert({
          institute_id: instituteId, user_id: userId, role: inv.role, status: 'active',
        }).select().single();
        if (memErr) throw memErr;
        return mapMembership(mem);
      } catch {
        return memoryFallback.invitations.accept(instituteId, token);
      }
    },
  };
}
