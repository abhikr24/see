import type { ExportJob, ID, RealtimeEvent, RealtimeStatus, RealtimeTopic } from '../../core/contracts/models';
import type { ExportRepo, ExportRequest, RealtimePort, RealtimeSubscription } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { memoryFallback, supabase } from './client';

export function exportRepo(): ExportRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<ExportJob>): Promise<Page<ExportJob>> {
      return memoryFallback.exports.list(instituteId, query);
    },
    async start(instituteId: ID, request: ExportRequest): Promise<ExportJob> {
      return memoryFallback.exports.start(instituteId, request);
    },
    async get(instituteId: ID, jobId: ID): Promise<ExportJob> {
      return memoryFallback.exports.get(instituteId, jobId);
    },
  };
}

export function realtimePort(): RealtimePort {
  return {
    async status(instituteId: ID): Promise<RealtimeStatus> {
      return 'connected';
    },
    async subscribe(instituteId: ID, topic: RealtimeTopic, onEvent: (event: RealtimeEvent) => void): Promise<RealtimeSubscription> {
      const channel = supabase.channel(`institute_${instituteId}_${topic}`)
        .on('postgres_changes', { event: '*', schema: 'public' }, (payload) => {
          onEvent({
            topic,
            change: payload.eventType === 'INSERT' ? 'created' : payload.eventType === 'DELETE' ? 'removed' : 'updated',
            id: (payload.new as any)?.id ?? (payload.old as any)?.id ?? '',
            at: new Date().toISOString(),
          });
        })
        .subscribe();
      return {
        topic,
        unsubscribe: async () => {
          await supabase.removeChannel(channel);
        },
      };
    },
  };
}
