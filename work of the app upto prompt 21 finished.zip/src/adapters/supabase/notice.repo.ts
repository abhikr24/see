import type { ID, NewEntity, Notice, Patch } from '../../core/contracts/models';
import type { NoticeRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapNotice } from './mappers';

export function noticeRepo(): NoticeRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Notice>): Promise<Page<Notice>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('notices').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.category) q = q.eq('category', query.where.category);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapNotice), count, offset, limit);
      } catch {
        return memoryFallback.notices.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Notice> {
      try {
        const { data, error } = await supabase.from('notices').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapNotice(data);
      } catch {
        return memoryFallback.notices.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<Notice, 'title'>): Promise<Notice> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const { data, error } = await supabase.from('notices').insert({
          institute_id: instituteId, title: input.title, body: input.body ?? '',
          batch_id: input.batchId ?? null, category: input.category ?? 'general',
          audience: input.audience ?? ['owner', 'admin', 'teacher', 'student', 'parent'],
          is_pinned: input.isPinned ?? false, published_at: input.publishedAt ?? null,
          expires_at: input.expiresAt ?? null, created_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapNotice(data);
      } catch {
        return memoryFallback.notices.create(instituteId, input);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<Notice>): Promise<Notice> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.title !== undefined) row.title = patch.title;
        if (patch.body !== undefined) row.body = patch.body;
        if (patch.category !== undefined) row.category = patch.category;
        if (patch.audience !== undefined) row.audience = patch.audience;
        if (patch.isPinned !== undefined) row.is_pinned = patch.isPinned;
        if (patch.publishedAt !== undefined) row.published_at = patch.publishedAt;
        if (patch.expiresAt !== undefined) row.expires_at = patch.expiresAt;
        const { data, error } = await supabase.from('notices').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapNotice(data);
      } catch {
        return memoryFallback.notices.update(instituteId, id, patch);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('notices').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.notices.remove(instituteId, id);
      }
    },

    async publish(instituteId: ID, id: ID): Promise<Notice> {
      return this.update(instituteId, id, { publishedAt: new Date().toISOString() });
    },

    async setPinned(instituteId: ID, id: ID, pinned: boolean): Promise<Notice> {
      return this.update(instituteId, id, { isPinned: pinned });
    },
  };
}
