import type { AppNotification, ID, NewEntity } from '../../core/contracts/models';
import type { NotificationRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapNotification } from './mappers';

export function notificationRepo(): NotificationRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<AppNotification>): Promise<Page<AppNotification>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('notifications').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.userId) q = q.eq('user_id', query.where.userId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapNotification), count, offset, limit);
      } catch {
        return memoryFallback.notifications.list(instituteId, query);
      }
    },

    async unreadCount(instituteId: ID): Promise<number> {
      try {
        const { count, error } = await supabase.from('notifications').select('*', { count: 'exact', head: true })
          .eq('institute_id', instituteId).is('read_at', null);
        if (error) throw error;
        return count ?? 0;
      } catch {
        return memoryFallback.notifications.unreadCount(instituteId);
      }
    },

    async markRead(instituteId: ID, id: ID): Promise<AppNotification> {
      try {
        const { data, error } = await supabase.from('notifications').update({
          read_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapNotification(data);
      } catch {
        return memoryFallback.notifications.markRead(instituteId, id);
      }
    },

    async markAllRead(instituteId: ID): Promise<number> {
      try {
        const { data, error } = await supabase.from('notifications').update({
          read_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).is('read_at', null).select();
        if (error) throw error;
        return data?.length ?? 0;
      } catch {
        return memoryFallback.notifications.markAllRead(instituteId);
      }
    },

    async send(instituteId: ID, input: NewEntity<AppNotification, 'userId' | 'title'>): Promise<AppNotification> {
      try {
        const { data, error } = await supabase.from('notifications').insert({
          institute_id: instituteId, user_id: input.userId, title: input.title,
          type: input.type ?? 'general', body: input.body ?? null, data: input.data ?? {},
          channel: input.channel ?? 'in_app', sent_at: new Date().toISOString(),
        }).select().single();
        if (error) throw error;
        return mapNotification(data);
      } catch {
        return memoryFallback.notifications.send(instituteId, input);
      }
    },
  };
}
