import { BackendError } from '../../core/contracts/errors';
import type { ID } from '../../core/contracts/models';
import { supabase } from './client';

/**
 * Active student count against the institute's current plan.
 * Throws AppError('CONFLICT', 'plan_limit') once the cap is reached.
 * A missing subscription or a null cap means unlimited.
 */
export async function assertRemoteStudentCap(instituteId: ID): Promise<void> {
  const { data: subs, error: subError } = await supabase
    .from('subscriptions')
    .select('plan_id,status')
    .eq('institute_id', instituteId)
    .in('status', ['trialing', 'active', 'past_due'])
    .limit(1);
  if (subError) throw subError;
  const planId = (subs?.[0] as { plan_id?: string } | undefined)?.plan_id;
  if (!planId) return;

  const { data: plan, error: planError } = await supabase
    .from('plans')
    .select('max_students')
    .eq('id', planId)
    .maybeSingle();
  if (planError) throw planError;
  const cap = (plan as { max_students?: number | null } | null)?.max_students;
  if (cap == null) return;

  const { count, error: countError } = await supabase
    .from('student_profiles')
    .select('id', { count: 'exact', head: true })
    .eq('institute_id', instituteId)
    .eq('status', 'active');
  if (countError) throw countError;
  const used = count ?? 0;
  if (used >= cap) {
    throw new BackendError('CONFLICT', 'plan_limit', { details: { reason: 'plan_limit', cap, used } });
  }
}
