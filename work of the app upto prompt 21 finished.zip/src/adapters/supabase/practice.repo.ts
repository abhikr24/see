import type { ID, PracticeQuestion, Quiz, QuizAttempt, Upsert } from '../../core/contracts/models';
import type { PracticeRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapPracticeQuestion, mapQuiz, mapQuizAttempt } from './mappers';

export function practiceRepo(): PracticeRepo {
  return {
    async listQuestions(instituteId: ID, query?: ListQuery<PracticeQuestion>): Promise<Page<PracticeQuestion>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('practice_questions').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.subjectId) q = q.eq('subject_id', query.where.subjectId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapPracticeQuestion), count, offset, limit);
      } catch {
        return memoryFallback.practice.listQuestions(instituteId, query);
      }
    },

    async saveQuestion(instituteId: ID, input: Upsert<PracticeQuestion, 'text'>): Promise<PracticeQuestion> {
      try {
        const row = {
          institute_id: instituteId, batch_id: input.batchId ?? null, subject_id: input.subjectId ?? null,
          topic: input.topic ?? null, difficulty: input.difficulty ?? 'medium',
          question_type: input.questionType ?? 'mcq', question_text: input.text,
          options: input.options ?? null, correct_answer: input.correctAnswer ?? null,
          explanation: input.explanation ?? null, marks: input.marks ?? 1,
          is_published: input.isPublished ?? true,
        };
        const op = input.id
          ? supabase.from('practice_questions').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('practice_questions').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapPracticeQuestion(data);
      } catch {
        return memoryFallback.practice.saveQuestion(instituteId, input);
      }
    },

    async removeQuestion(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('practice_questions').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.practice.removeQuestion(instituteId, id);
      }
    },

    async listQuizzes(instituteId: ID, query?: ListQuery<Quiz>): Promise<Page<Quiz>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('quizzes').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.batchId) q = q.eq('batch_id', query.where.batchId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapQuiz), count, offset, limit);
      } catch {
        return memoryFallback.practice.listQuizzes(instituteId, query);
      }
    },

    async saveQuiz(instituteId: ID, input: Upsert<Quiz, 'batchId' | 'title'>): Promise<Quiz> {
      try {
        const row = {
          institute_id: instituteId, batch_id: input.batchId, title: input.title,
          subject_id: input.subjectId ?? null, teacher_id: input.teacherId ?? null,
          description: input.description ?? null, question_ids: input.questionIds ?? [],
          duration_minutes: input.durationMinutes ?? null, total_marks: input.totalMarks ?? null,
          opens_at: input.opensAt ?? null, closes_at: input.closesAt ?? null, status: input.status ?? 'draft',
        };
        const op = input.id
          ? supabase.from('quizzes').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('quizzes').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapQuiz(data);
      } catch {
        return memoryFallback.practice.saveQuiz(instituteId, input);
      }
    },

    async listAttempts(instituteId: ID, filter?: { quizId?: ID; studentId?: ID }): Promise<QuizAttempt[]> {
      try {
        let q = supabase.from('quiz_attempts').select('*').eq('institute_id', instituteId);
        if (filter?.quizId) q = q.eq('quiz_id', filter.quizId);
        if (filter?.studentId) q = q.eq('student_id', filter.studentId);
        const { data, error } = await q;
        if (error) throw error;
        return (data ?? []).map(mapQuizAttempt);
      } catch {
        return memoryFallback.practice.listAttempts(instituteId, filter);
      }
    },

    async startAttempt(instituteId: ID, quizId: ID, studentId: ID): Promise<QuizAttempt> {
      try {
        const { data: quiz } = await supabase.from('quizzes').select('batch_id').eq('id', quizId).single();
        const batchId = quiz?.batch_id ?? '00000000-0000-4000-8000-000000000009';
        const { data, error } = await supabase.from('quiz_attempts').insert({
          institute_id: instituteId, quiz_id: quizId, batch_id: batchId, student_id: studentId,
          started_at: new Date().toISOString(), status: 'in_progress',
        }).select().single();
        if (error) throw error;
        return mapQuizAttempt(data);
      } catch {
        return memoryFallback.practice.startAttempt(instituteId, quizId, studentId);
      }
    },

    async submitAttempt(instituteId: ID, attemptId: ID, answers: Record<ID, string>): Promise<QuizAttempt> {
      try {
        const { data, error } = await supabase.from('quiz_attempts').update({
          answers, submitted_at: new Date().toISOString(), status: 'submitted',
        }).eq('institute_id', instituteId).eq('id', attemptId).select().single();
        if (error) throw error;
        return mapQuizAttempt(data);
      } catch {
        return memoryFallback.practice.submitAttempt(instituteId, attemptId, answers);
      }
    },
  };
}
