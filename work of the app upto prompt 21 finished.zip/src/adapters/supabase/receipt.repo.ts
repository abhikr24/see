import type { ID, Receipt } from '../../core/contracts/models';
import type { ReceiptRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapReceipt } from './mappers';

export function receiptRepo(): ReceiptRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<Receipt>): Promise<Page<Receipt>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('receipts').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.studentId) q = q.eq('student_id', query.where.studentId);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('issued_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapReceipt), count, offset, limit);
      } catch {
        return memoryFallback.receipts.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<Receipt> {
      try {
        const { data, error } = await supabase.from('receipts').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapReceipt(data);
      } catch {
        return memoryFallback.receipts.get(instituteId, id);
      }
    },

    async getForPayment(instituteId: ID, paymentId: ID): Promise<Receipt | null> {
      try {
        const { data, error } = await supabase.from('receipts').select('*').eq('institute_id', instituteId).eq('payment_id', paymentId).maybeSingle();
        if (error) throw error;
        return data ? mapReceipt(data) : null;
      } catch {
        return memoryFallback.receipts.getForPayment(instituteId, paymentId);
      }
    },

    async issue(instituteId: ID, paymentId: ID): Promise<Receipt> {
      try {
        const existing = await this.getForPayment(instituteId, paymentId);
        if (existing) return existing;
        const { data: pay } = await supabase.from('payments').select('*').eq('id', paymentId).single();
        const { data: user } = await supabase.auth.getUser();
        const receiptNo = `REC-${Date.now().toString().slice(-6)}`;
        const { data, error } = await supabase.from('receipts').insert({
          institute_id: instituteId, payment_id: paymentId, student_id: pay?.student_id ?? '00000000-0000-4000-8000-000000000014',
          receipt_no: receiptNo, amount: pay?.amount ?? 0, issued_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapReceipt(data);
      } catch {
        return memoryFallback.receipts.issue(instituteId, paymentId);
      }
    },
  };
}
