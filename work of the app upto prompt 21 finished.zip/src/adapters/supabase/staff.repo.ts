import type { ID, ISODate, NewEntity, Patch, StaffRecord, Teacher, Upsert, Workload } from '../../core/contracts/models';
import type { StaffRepo } from '../../core/contracts/ports';
import type { ListQuery, Page } from '../../core/contracts/query';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, memoryFallback, parseCursor, supabase, toPaginatedResult } from './client';
import { mapStaffRecord, mapTeacher, mapWorkload } from './mappers';

export function staffRepo(): StaffRepo {
  return {
    async list(instituteId: ID, query?: ListQuery<StaffRecord>): Promise<Page<StaffRecord>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('staff_records').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('created_at', { ascending: false });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapStaffRecord), count, offset, limit);
      } catch {
        return memoryFallback.staff.list(instituteId, query);
      }
    },

    async get(instituteId: ID, id: ID): Promise<StaffRecord> {
      try {
        const { data, error } = await supabase.from('staff_records').select('*').eq('institute_id', instituteId).eq('id', id).single();
        if (error) throw error;
        return mapStaffRecord(data);
      } catch {
        return memoryFallback.staff.get(instituteId, id);
      }
    },

    async create(instituteId: ID, input: NewEntity<StaffRecord>): Promise<StaffRecord> {
      try {
        const { data, error } = await supabase.from('staff_records').insert({
          institute_id: instituteId, user_id: input.userId ?? null, teacher_id: input.teacherId ?? null,
          employee_code: input.employeeCode ?? null, designation: input.designation ?? null,
          department: input.department ?? null, employment_type: input.employmentType ?? 'full_time',
          joined_on: input.joinedOn ?? null, salary_amount: input.salaryAmount ?? null,
          salary_period: input.salaryPeriod ?? 'monthly', phone: input.phone ?? null, email: input.email ?? null,
          emergency_contact: input.emergencyContact ?? null, bank_details: input.bankDetails ?? {},
          status: input.status ?? 'active',
        }).select().single();
        if (error) throw error;
        return mapStaffRecord(data);
      } catch {
        return memoryFallback.staff.create(instituteId, input);
      }
    },

    async update(instituteId: ID, id: ID, patch: Patch<StaffRecord>): Promise<StaffRecord> {
      try {
        const row: Record<string, unknown> = {};
        if (patch.employeeCode !== undefined) row.employee_code = patch.employeeCode;
        if (patch.designation !== undefined) row.designation = patch.designation;
        if (patch.department !== undefined) row.department = patch.department;
        if (patch.employmentType !== undefined) row.employment_type = patch.employmentType;
        if (patch.joinedOn !== undefined) row.joined_on = patch.joinedOn;
        if (patch.leftOn !== undefined) row.left_on = patch.leftOn;
        if (patch.salaryAmount !== undefined) row.salary_amount = patch.salaryAmount;
        if (patch.salaryPeriod !== undefined) row.salary_period = patch.salaryPeriod;
        if (patch.phone !== undefined) row.phone = patch.phone;
        if (patch.email !== undefined) row.email = patch.email;
        if (patch.emergencyContact !== undefined) row.emergency_contact = patch.emergencyContact;
        if (patch.bankDetails !== undefined) row.bank_details = patch.bankDetails;
        if (patch.status !== undefined) row.status = patch.status;
        const { data, error } = await supabase.from('staff_records').update(row).eq('institute_id', instituteId).eq('id', id).select().single();
        if (error) throw error;
        return mapStaffRecord(data);
      } catch {
        return memoryFallback.staff.update(instituteId, id, patch);
      }
    },

    async remove(instituteId: ID, id: ID): Promise<void> {
      try {
        const { error } = await supabase.from('staff_records').delete().eq('institute_id', instituteId).eq('id', id);
        if (error) throw error;
      } catch {
        await memoryFallback.staff.remove(instituteId, id);
      }
    },

    async listTeachers(instituteId: ID, query?: ListQuery<Teacher>): Promise<Page<Teacher>> {
      try {
        const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
        const offset = parseCursor(query?.cursor);
        let q = supabase.from('teacher_profiles').select('*', { count: 'exact' }).eq('institute_id', instituteId);
        if (query?.where?.status) q = q.eq('status', query.where.status);
        if (query?.search) q = q.ilike('full_name', `%${query.search}%`);
        const { data, count, error } = await q.range(offset, offset + limit - 1).order('full_name', { ascending: true });
        if (error) throw error;
        return toPaginatedResult((data ?? []).map(mapTeacher), count, offset, limit);
      } catch {
        return memoryFallback.staff.listTeachers(instituteId, query);
      }
    },

    async saveTeacher(instituteId: ID, input: Upsert<Teacher, 'fullName'>): Promise<Teacher> {
      try {
        const row = {
          institute_id: instituteId, full_name: input.fullName, user_id: input.userId ?? null,
          branch_id: input.branchId ?? null, specialization: input.specialization ?? null,
          qualification: input.qualification ?? null, experience_years: input.experienceYears ?? null,
          bio: input.bio ?? null, photo_url: input.photoUrl ?? null, status: input.status ?? 'active',
        };
        const op = input.id
          ? supabase.from('teacher_profiles').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('teacher_profiles').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapTeacher(data);
      } catch {
        return memoryFallback.staff.saveTeacher(instituteId, input);
      }
    },

    async listWorkloads(instituteId: ID, filter?: { teacherId?: ID; weekStart?: ISODate }): Promise<Workload[]> {
      try {
        let q = supabase.from('workloads').select('*').eq('institute_id', instituteId);
        if (filter?.teacherId) q = q.eq('teacher_id', filter.teacherId);
        if (filter?.weekStart) q = q.eq('week_start', filter.weekStart);
        const { data, error } = await q;
        if (error) throw error;
        return (data ?? []).map(mapWorkload);
      } catch {
        return memoryFallback.staff.listWorkloads(instituteId, filter);
      }
    },

    async saveWorkload(instituteId: ID, input: Upsert<Workload, 'teacherId' | 'weekStart'>): Promise<Workload> {
      try {
        const row = {
          institute_id: instituteId, teacher_id: input.teacherId, week_start: input.weekStart,
          periods_assigned: input.periodsAssigned ?? 0, periods_taken: input.periodsTaken ?? 0,
          hours_assigned: input.hoursAssigned ?? 0, hours_taken: input.hoursTaken ?? 0, notes: input.notes ?? null,
        };
        const op = input.id
          ? supabase.from('workloads').update(row).eq('institute_id', instituteId).eq('id', input.id).select().single()
          : supabase.from('workloads').insert(row).select().single();
        const { data, error } = await op;
        if (error) throw error;
        return mapWorkload(data);
      } catch {
        return memoryFallback.staff.saveWorkload(instituteId, input);
      }
    },
  };
}
