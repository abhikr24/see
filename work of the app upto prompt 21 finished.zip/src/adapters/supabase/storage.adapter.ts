import type { Attachment, AttachmentOwner, ID } from '../../core/contracts/models';
import type { StoragePort, UploadInput } from '../../core/contracts/ports';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { mapAttachment } from './mappers';

export function storageAdapter(): StoragePort {
  return {
    async upload(instituteId: ID, input: UploadInput): Promise<Attachment> {
      try {
        const { data: user } = await supabase.auth.getUser();
        const storagePath = `uploads/${instituteId}/${input.ownerType}/${input.ownerId}/${input.fileName}`;
        const { data, error } = await supabase.from('attachments').insert({
          institute_id: instituteId, entity_type: input.ownerType, entity_id: input.ownerId,
          batch_id: input.batchId ?? null, student_id: input.studentId ?? null,
          file_name: input.fileName, storage_path: storagePath, mime_type: input.mimeType ?? null,
          size_bytes: input.sizeBytes ?? null, uploaded_by: user?.user?.id ?? null,
        }).select().single();
        if (error) throw error;
        return mapAttachment(data);
      } catch {
        return memoryFallback.storage.upload(instituteId, input);
      }
    },

    async listAttachments(instituteId: ID, ownerType: AttachmentOwner, ownerId: ID): Promise<Attachment[]> {
      try {
        const { data, error } = await supabase.from('attachments').select('*')
          .eq('institute_id', instituteId).eq('entity_type', ownerType).eq('entity_id', ownerId);
        if (error) throw error;
        return (data ?? []).map(mapAttachment);
      } catch {
        return memoryFallback.storage.listAttachments(instituteId, ownerType, ownerId);
      }
    },

    async getUrl(instituteId: ID, storagePath: string, expiresInSeconds = 3600): Promise<string> {
      try {
        const { data } = await supabase.storage.from('attachments').createSignedUrl(storagePath, expiresInSeconds);
        return data?.signedUrl ?? `https://storage.guruflow.dev/${storagePath}`;
      } catch {
        return memoryFallback.storage.getUrl(instituteId, storagePath, expiresInSeconds);
      }
    },

    async remove(instituteId: ID, attachmentId: ID): Promise<void> {
      try {
        const { error } = await supabase.from('attachments').delete().eq('institute_id', instituteId).eq('id', attachmentId);
        if (error) throw error;
      } catch {
        await memoryFallback.storage.remove(instituteId, attachmentId);
      }
    },
  };
}
