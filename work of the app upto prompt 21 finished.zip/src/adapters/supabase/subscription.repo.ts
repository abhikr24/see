import type { BillingCycle, ID, Plan, Subscription, UsageRecord } from '../../core/contracts/models';
import type { SubscriptionRepo } from '../../core/contracts/ports';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import { mapPlan, mapSubscription, mapUsageRecord } from './mappers';

export function subscriptionRepo(): SubscriptionRepo {
  return {
    async getCurrent(instituteId: ID): Promise<Subscription | null> {
      try {
        const { data, error } = await supabase.from('subscriptions').select('*').eq('institute_id', instituteId).in('status', ['trialing', 'active', 'past_due']).maybeSingle();
        if (error) throw error;
        return data ? mapSubscription(data) : memoryFallback.subscriptions.getCurrent(instituteId);
      } catch {
        return memoryFallback.subscriptions.getCurrent(instituteId);
      }
    },

    async listPlans(instituteId: ID): Promise<Plan[]> {
      try {
        const { data, error } = await supabase.from('plans').select('*').eq('institute_id', instituteId);
        if (error) throw error;
        if (!data || data.length === 0) return memoryFallback.subscriptions.listPlans(instituteId);
        return data.map(mapPlan);
      } catch {
        return memoryFallback.subscriptions.listPlans(instituteId);
      }
    },

    async changePlan(instituteId: ID, planId: ID, billingCycle: BillingCycle): Promise<Subscription> {
      try {
        const { data, error } = await supabase.from('subscriptions').upsert({
          institute_id: instituteId, plan_id: planId, billing_cycle: billingCycle,
          status: 'active', current_period_start: new Date().toISOString(),
        }).select().single();
        if (error) throw error;
        return mapSubscription(data);
      } catch {
        return memoryFallback.subscriptions.changePlan(instituteId, planId, billingCycle);
      }
    },

    async cancel(instituteId: ID): Promise<Subscription> {
      try {
        const { data, error } = await supabase.from('subscriptions').update({
          status: 'cancelled', cancelled_at: new Date().toISOString(),
        }).eq('institute_id', instituteId).select().single();
        if (error) throw error;
        return mapSubscription(data);
      } catch {
        return memoryFallback.subscriptions.cancel(instituteId);
      }
    },

    async listUsage(instituteId: ID): Promise<UsageRecord[]> {
      try {
        const { data, error } = await supabase.from('usage_records').select('*').eq('institute_id', instituteId);
        if (error) throw error;
        return (data ?? []).map(mapUsageRecord);
      } catch {
        return memoryFallback.subscriptions.listUsage(instituteId);
      }
    },
  };
}
