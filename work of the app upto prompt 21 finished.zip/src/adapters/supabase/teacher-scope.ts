import { BackendError } from '../../core/contracts/errors';
import type { Batch, ID } from '../../core/contracts/models';
import type { AttendanceRepo, BatchRepo } from '../../core/contracts/ports';
import { DEFAULT_PAGE_LIMIT, handleSupabaseError, parseCursor, supabase, toPaginatedResult } from './client';
import { mapBatch, mapEnrollment } from './mappers';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

/** What a teacher caller is limited to. `teacherIds` are their own teacher-profile ids. */
export interface TeacherScope {
  teacherIds: ID[];
}

const notFound = () => new BackendError('NOT_FOUND', 'Batch not found');

/**
 * The caller's teacher scope, or null when no teacher limit applies (owner,
 * admin, student, parent). Read fresh on every call: a cached answer would keep
 * a reassigned teacher inside a batch that is no longer theirs.
 *
 * Without a configured project every read is served by the bundled reference
 * data, which has no signed-in person, so there is nothing to scope.
 */
export async function teacherScope(instituteId: ID): Promise<TeacherScope | null> {
  if (!live) return null;
  const { data: auth, error: authError } = await supabase.auth.getUser();
  if (authError) throw handleSupabaseError(authError);
  const userId = auth.user?.id;
  if (!userId) throw new BackendError('UNAUTHENTICATED', 'Sign in first.');

  const { data: membership, error } = await supabase
    .from('memberships')
    .select('role')
    .eq('institute_id', instituteId)
    .eq('user_id', userId)
    .eq('status', 'active')
    .maybeSingle();
  if (error) throw handleSupabaseError(error);
  if (membership?.role !== 'teacher') return null;

  const { data: profiles, error: profileError } = await supabase
    .from('teacher_profiles')
    .select('id')
    .eq('institute_id', instituteId)
    .eq('user_id', userId)
    .eq('status', 'active');
  if (profileError) throw handleSupabaseError(profileError);
  return { teacherIds: (profiles ?? []).map((row) => String(row.id)) };
}

/** The teacher's own batches: the assignment is `batches.teacher_id`, filtered in the query. */
export async function ownBatches(instituteId: ID, scope: TeacherScope): Promise<Batch[]> {
  if (scope.teacherIds.length === 0) return [];
  const { data, error } = await supabase
    .from('batches')
    .select('*')
    .eq('institute_id', instituteId)
    .in('teacher_id', scope.teacherIds)
    .order('name', { ascending: true });
  if (error) throw handleSupabaseError(error);
  return (data ?? []).map(mapBatch);
}

/** One batch, only if it is the teacher's own. Someone else's id is indistinguishable from a missing one. */
async function ownBatch(instituteId: ID, scope: TeacherScope, batchId: ID): Promise<Batch> {
  if (scope.teacherIds.length === 0) throw notFound();
  const { data, error } = await supabase
    .from('batches')
    .select('*')
    .eq('institute_id', instituteId)
    .eq('id', batchId)
    .in('teacher_id', scope.teacherIds)
    .maybeSingle();
  if (error) throw handleSupabaseError(error);
  if (!data) throw notFound();
  return mapBatch(data);
}

/** Throws `NOT_FOUND` when a teacher caller asks for a batch that is not theirs. */
export async function assertOwnBatch(instituteId: ID, batchId: ID): Promise<void> {
  const scope = await teacherScope(instituteId);
  if (scope) await ownBatch(instituteId, scope, batchId);
}

/**
 * BatchRepo behind the teacher rule. For any other caller every method is the
 * base repo's; for a teacher each read runs its own query with the assigned
 * teacher in the WHERE clause, so the rule never depends on a screen.
 */
export function scopedBatchRepo(base: BatchRepo): BatchRepo {
  return {
    ...base,
    async list(instituteId, query) {
      const scope = await teacherScope(instituteId);
      if (!scope) return base.list(instituteId, query);
      const limit = query?.limit ?? DEFAULT_PAGE_LIMIT;
      const offset = parseCursor(query?.cursor);
      if (scope.teacherIds.length === 0) return toPaginatedResult<Batch>([], 0, offset, limit);
      let q = supabase
        .from('batches')
        .select('*', { count: 'exact' })
        .eq('institute_id', instituteId)
        .in('teacher_id', scope.teacherIds);
      if (query?.where?.status) q = q.eq('status', query.where.status);
      if (query?.where?.academicYear) q = q.eq('academic_year', query.where.academicYear);
      if (query?.search) q = q.ilike('name', `%${query.search}%`);
      const { data, count, error } = await q.range(offset, offset + limit - 1).order('name', { ascending: true });
      if (error) throw handleSupabaseError(error);
      return toPaginatedResult((data ?? []).map(mapBatch), count, offset, limit);
    },
    async get(instituteId, id) {
      const scope = await teacherScope(instituteId);
      return scope ? ownBatch(instituteId, scope, id) : base.get(instituteId, id);
    },
    async listMine(instituteId) {
      const scope = await teacherScope(instituteId);
      return scope ? ownBatches(instituteId, scope) : base.listMine(instituteId);
    },
    async listSummaries(instituteId) {
      const scope = await teacherScope(instituteId);
      if (!scope) return base.listSummaries(instituteId);
      const own = new Set((await ownBatches(instituteId, scope)).map((batch) => batch.id));
      return (await base.listSummaries(instituteId)).filter((summary) => own.has(summary.id));
    },
    async listRoster(instituteId, batchId) {
      await assertOwnBatch(instituteId, batchId);
      return base.listRoster(instituteId, batchId);
    },
    async listEnrollments(instituteId, batchId) {
      const scope = await teacherScope(instituteId);
      if (!scope) return base.listEnrollments(instituteId, batchId);
      await ownBatch(instituteId, scope, batchId);
      const { data, error } = await supabase
        .from('batch_students')
        .select('*')
        .eq('institute_id', instituteId)
        .eq('batch_id', batchId)
        .order('roll_number', { ascending: true });
      if (error) throw handleSupabaseError(error);
      return (data ?? []).map(mapEnrollment);
    },
  };
}

/** AttendanceRepo behind the same rule: every batch-scoped call checks the batch first. */
export function scopedAttendanceRepo(base: AttendanceRepo): AttendanceRepo {
  return {
    ...base,
    async openRoll(instituteId, input) {
      await assertOwnBatch(instituteId, input.batchId);
      return base.openRoll(instituteId, input);
    },
    async saveSheet(instituteId, input) {
      await assertOwnBatch(instituteId, input.batchId);
      return base.saveSheet(instituteId, input);
    },
    async listSheets(instituteId, filter) {
      const scope = await teacherScope(instituteId);
      if (!scope) return base.listSheets(instituteId, filter);
      if (filter.batchId) await ownBatch(instituteId, scope, filter.batchId);
      const own = new Set((await ownBatches(instituteId, scope)).map((batch) => batch.id));
      return (await base.listSheets(instituteId, filter)).filter((sheet) => own.has(sheet.session.batchId));
    },
    async monthRegister(instituteId, input) {
      await assertOwnBatch(instituteId, input.batchId);
      return base.monthRegister(instituteId, input);
    },
    async registerDay(instituteId, input) {
      await assertOwnBatch(instituteId, input.batchId);
      return base.registerDay(instituteId, input);
    },
    async correctAttendance(instituteId, input) {
      await assertOwnBatch(instituteId, input.batchId);
      return base.correctAttendance(instituteId, input);
    },
  };
}
