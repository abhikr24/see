import { BackendError } from '../../core/contracts/errors';
import type { Batch, FallingStudent, ID, TeacherClass, TeacherHome } from '../../core/contracts/models';
import {
  buildTeacherClasses,
  buildTeacherHome,
  findFallingStudents,
  type TeacherRows,
} from '../../core/contracts/teacher';
import { handleSupabaseError, memoryFallback, supabase } from './client';
import {
  mapAssignment,
  mapAttendanceRecord,
  mapAttendanceSession,
  mapBatch,
  mapClassroom,
  mapEnrollment,
  mapExam,
  mapResult,
  mapStudent,
  mapSubject,
  mapSubmission,
  mapTimetable,
} from './mappers';
import { ownBatches, teacherScope, type TeacherScope } from './teacher-scope';

const live = Boolean(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY);

type Row = Record<string, unknown>;

/** `select *` on one table, tenant-scoped and limited to the given batches in the query itself. */
async function inBatches(table: string, instituteId: ID, batchIds: ID[], extra?: [string, string]): Promise<Row[]> {
  if (batchIds.length === 0) return [];
  let q = supabase.from(table).select('*').eq('institute_id', instituteId).in('batch_id', batchIds);
  if (extra) q = q.eq(extra[0], extra[1]);
  const { data, error } = await q;
  if (error) throw handleSupabaseError(error);
  return (data ?? []) as Row[];
}

async function whole(table: string, instituteId: ID): Promise<Row[]> {
  const { data, error } = await supabase.from(table).select('*').eq('institute_id', instituteId);
  if (error) throw handleSupabaseError(error);
  return (data ?? []) as Row[];
}

/** The rows the pure builders in core/contracts/teacher.ts need, for the given batches only. */
async function rowsOf(instituteId: ID, batches: Batch[]): Promise<TeacherRows> {
  const ids = batches.map((batch) => batch.id);
  const [periods, subjects, classrooms, enrollments, sessions, records, assignments, submissions] = await Promise.all([
    inBatches('timetables', instituteId, ids),
    whole('subjects', instituteId),
    whole('classrooms', instituteId),
    inBatches('batch_students', instituteId, ids, ['status', 'active']),
    inBatches('attendance_sessions', instituteId, ids),
    inBatches('attendance_records', instituteId, ids),
    inBatches('assignments', instituteId, ids),
    inBatches('submissions', instituteId, ids),
  ]);
  return {
    batches,
    periods: periods.map(mapTimetable),
    subjects: subjects.map(mapSubject),
    classrooms: classrooms.map(mapClassroom),
    enrollments: enrollments.map(mapEnrollment),
    sessions: sessions.map(mapAttendanceSession),
    records: records.map(mapAttendanceRecord),
    assignments: assignments.map(mapAssignment),
    submissions: submissions.map(mapSubmission),
  };
}

async function requireTeacher(instituteId: ID): Promise<TeacherScope> {
  const scope = await teacherScope(instituteId);
  if (!scope) throw new BackendError('FORBIDDEN', 'Only a teacher has classes of their own');
  return scope;
}

const clock = (at = new Date()): string =>
  `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;

/** BatchRepo.listMyClasses */
export async function listMyClasses(instituteId: ID): Promise<TeacherClass[]> {
  if (!live) return memoryFallback.batches.listMyClasses(instituteId);
  const scope = await requireTeacher(instituteId);
  return buildTeacherClasses(await rowsOf(instituteId, await ownBatches(instituteId, scope)));
}

/** AnalyticsRepo.teacherHome */
export async function teacherHome(instituteId: ID): Promise<TeacherHome> {
  if (!live) return memoryFallback.analytics.teacherHome(instituteId);
  const scope = await requireTeacher(instituteId);
  const [batches, settings] = await Promise.all([
    ownBatches(instituteId, scope),
    supabase.from('institute_settings').select('attendance_mode').eq('institute_id', instituteId).maybeSingle(),
  ]);
  if (settings.error) throw handleSupabaseError(settings.error);
  return buildTeacherHome({
    ...(await rowsOf(instituteId, batches)),
    today: new Date().toISOString().slice(0, 10),
    now: clock(),
    // A login normally has one teacher profile per institute (unique on institute_id, user_id).
    teacherId: scope.teacherIds[0] ?? null,
    perPeriod: settings.data?.attendance_mode === 'period',
  });
}

/** ProgressPort.listFallingStudents */
export async function listFallingStudents(instituteId: ID): Promise<FallingStudent[]> {
  if (!live) return memoryFallback.progress.listFallingStudents(instituteId);
  const scope = await teacherScope(instituteId);
  let batches: Batch[];
  if (scope) batches = await ownBatches(instituteId, scope);
  else {
    // Not a teacher: owners and admins see every batch, families see none.
    const { data: auth } = await supabase.auth.getUser();
    const { data: membership, error } = await supabase
      .from('memberships')
      .select('role')
      .eq('institute_id', instituteId)
      .eq('user_id', auth.user?.id ?? '')
      .eq('status', 'active')
      .maybeSingle();
    if (error) throw handleSupabaseError(error);
    if (membership?.role !== 'owner' && membership?.role !== 'admin') {
      throw new BackendError('FORBIDDEN', 'Student alerts are for teaching staff');
    }
    batches = (await whole('batches', instituteId)).map(mapBatch);
  }

  const ids = batches.map((batch) => batch.id);
  const [enrollments, sessions, records, exams, results] = await Promise.all([
    inBatches('batch_students', instituteId, ids, ['status', 'active']),
    inBatches('attendance_sessions', instituteId, ids),
    inBatches('attendance_records', instituteId, ids),
    inBatches('exams', instituteId, ids, ['status', 'published']),
    inBatches('results', instituteId, ids),
  ]);
  const studentIds = [...new Set(enrollments.map((row) => String(row.student_id)))];
  let students: Row[] = [];
  if (studentIds.length > 0) {
    const { data, error } = await supabase
      .from('student_profiles')
      .select('*')
      .eq('institute_id', instituteId)
      .in('id', studentIds);
    if (error) throw handleSupabaseError(error);
    students = (data ?? []) as Row[];
  }
  return findFallingStudents({
    batches,
    enrollments: enrollments.map(mapEnrollment),
    students: students.map(mapStudent),
    sessions: sessions.map(mapAttendanceSession),
    records: records.map(mapAttendanceRecord),
    exams: exams.map(mapExam),
    results: results.map(mapResult),
  });
}
