import type {
  AttendanceRecord,
  AttendanceSheet,
  AttendanceSummary,
  Batch,
  Classroom,
  ID,
  Subject,
  Timetable,
} from '../../core/contracts/models';
import type {
  AttendanceFilter,
  AttendanceRepo,
  BatchRepo,
  SubjectRepo,
  TimetableRepo,
} from '../../core/contracts/ports';
import { crud, emit, myStudentIds, requireUser, upsert, type Db } from './db';
import * as D from './defaults';
import { fail, nowIso, round1, todayIso } from './store';
import { batchSummaries, batchRoster } from './batch-summary';
import { validateBatch } from '../../core/contracts/batch-validation';
import { attendanceRegisterPorts } from './attendance-register';
import { attendanceRollPorts } from './attendance-roll';
import { teacherClasses } from './teacher';
import { batchesAssignedTo, callerTeacher, teacherBatchScope, visibleBatch } from './teacher-scope';

export function batchRepo(db: Db): BatchRepo {
  const base = crud<Batch, 'name' | 'academicYear'>(db.batches, D.batch);
  return {
    ...base,
    // A teacher caller only ever reads the batches they are the assigned teacher of.
    list: async (i, query) => {
      const scope = teacherBatchScope(db, i);
      return scope ? db.batches.page(i, query, {}, (batch) => scope.has(batch.id)) : base.list(i, query);
    },
    get: async (i, id) => visibleBatch(db, i, id),
    listSummaries: async (i) => {
      const scope = teacherBatchScope(db, i);
      const all = batchSummaries(db, i);
      return scope ? all.filter((batch) => scope.has(batch.id)) : all;
    },
    listRoster: async (i, id) => batchRoster(db, i, visibleBatch(db, i, id).id),
    listMyClasses: async (i) => teacherClasses(db, i),
    create: async (i, input) => {
      validateBatch(input);
      const batch = await base.create(i, input);
      for (const day of input.days ?? []) {
        db.timetables.insert(i, { ...D.timetable(), batchId: batch.id, dayOfWeek: day,
          subjectId: input.subjectId ?? null, teacherId: input.teacherId ?? null,
          startsAt: input.startsAt!, endsAt: input.endsAt! });
      }
      return batch;
    },
    remove: async (i, id) => { db.batches.update(i, id, { status: 'archived' }); },
    listMine: async (instituteId) => {
      const membership = db.memberships.find(instituteId, { userId: requireUser(db), status: 'active' });
      if (!membership) return [];
      const all = db.batches.all(instituteId);
      if (membership.role === 'owner' || membership.role === 'admin') return all;
      let batchIds: ID[];
      if (membership.role === 'teacher') {
        batchIds = batchesAssignedTo(db, instituteId, callerTeacher(db, instituteId)?.id ?? null).map((b) => b.id);
      } else {
        batchIds = myStudentIds(db, instituteId).flatMap((studentId) =>
          db.enrollments.all(instituteId, { studentId, status: 'active' }).map((e) => e.batchId),
        );
      }
      return all.filter((batch) => batchIds.includes(batch.id));
    },
    listEnrollments: async (instituteId, batchId) => {
      visibleBatch(db, instituteId, batchId);
      return db.enrollments.all(instituteId, { batchId });
    },
    enroll: async (instituteId, batchId, { studentId, rollNumber = null }) => {
      const batch = db.batches.get(instituteId, batchId);
      db.students.get(instituteId, studentId);
      const active = db.enrollments.all(instituteId, { batchId, status: 'active' });
      if (active.some((e) => e.studentId === studentId)) fail('CONFLICT', 'Student is already in this batch');
      if (rollNumber !== null && active.some((e) => e.rollNumber === rollNumber)) {
        fail('CONFLICT', 'That roll number is taken');
      }
      if (batch.capacity !== null && active.length >= batch.capacity) fail('CONFLICT', 'This batch is full');
      return db.enrollments.insert(instituteId, {
        batchId,
        studentId,
        rollNumber,
        joinedOn: todayIso(),
        leftOn: null,
        status: 'active',
      });
    },
    unenroll: async (instituteId, enrollmentId) =>
      db.enrollments.update(instituteId, enrollmentId, { status: 'left', leftOn: todayIso() }),
  };
}

export function subjectRepo(db: Db): SubjectRepo {
  const base = crud<Subject, 'name' | 'code'>(db.subjects, D.subject);
  return {
    ...base,
    create: async (instituteId, input) => {
      if (!input.name.trim()) fail('VALIDATION', 'Subject name is required');
      if (db.subjects.find(instituteId, { code: input.code })) fail('CONFLICT', 'A subject with this code exists');
      return base.create(instituteId, input);
    },
  };
}

export function timetableRepo(db: Db): TimetableRepo {
  const base = crud<Timetable, 'batchId' | 'dayOfWeek' | 'startsAt' | 'endsAt'>(db.timetables, D.timetable);
  return {
    ...base,
    create: async (instituteId, input) => {
      db.batches.get(instituteId, input.batchId);
      if (input.dayOfWeek < 0 || input.dayOfWeek > 6) fail('VALIDATION', 'dayOfWeek must be 0–6');
      if (input.endsAt <= input.startsAt) fail('VALIDATION', 'A period must end after it starts');
      return base.create(instituteId, input);
    },
    listForDay: async (instituteId, filter) =>
      db.timetables.all(instituteId, filter).sort((a, b) => a.startsAt.localeCompare(b.startsAt)),
    listClassrooms: async (instituteId) => db.classrooms.all(instituteId),
    saveClassroom: upsert<Classroom, 'name'>(db.classrooms, D.classroom),
    removeClassroom: async (instituteId, id) => db.classrooms.remove(instituteId, id),
  };
}

/** Attendance records for a filter, joined to their session for the date range. */
export function attendanceRecords(db: Db, instituteId: ID, filter: AttendanceFilter): AttendanceRecord[] {
  const { from, to, studentId, batchId } = filter;
  const dates = new Map(db.attendanceSessions.all(instituteId, { batchId }).map((s) => [s.id, s.date]));
  return db.attendanceRecords.all(instituteId, { studentId, batchId }).filter((record) => {
    const date = dates.get(record.sessionId);
    return date !== undefined && (!from || date >= from) && (!to || date <= to);
  });
}

export function summarize(records: AttendanceRecord[]): AttendanceSummary {
  const count = (status: AttendanceRecord['status']) => records.filter((r) => r.status === status).length;
  const present = count('present');
  const late = count('late');
  const total = records.length;
  return {
    total,
    present,
    late,
    absent: count('absent'),
    leave: count('leave'),
    percent: total ? round1(((present + late) / total) * 100) : 0,
  };
}

export function attendanceRepo(db: Db): AttendanceRepo {
  const sheet = (instituteId: ID, sessionId: ID): AttendanceSheet => ({
    session: db.attendanceSessions.get(instituteId, sessionId),
    records: db.attendanceRecords.all(instituteId, { sessionId }),
  });

  return {
    listSessions: async (instituteId, query) => db.attendanceSessions.page(instituteId, query),
    getSheet: async (instituteId, sessionId) => sheet(instituteId, sessionId),
    saveSheet: async (instituteId, input) => {
      const { batchId, date, period = 1, records } = input;
      visibleBatch(db, instituteId, batchId);
      if (date > todayIso()) fail('VALIDATION', 'Attendance cannot be marked for a future date');
      const enrolled = new Set(db.enrollments.all(instituteId, { batchId, status: 'active' }).map((e) => e.studentId));
      const stranger = records.find((r) => !enrolled.has(r.studentId));
      if (stranger) fail('VALIDATION', 'A student on this sheet is not enrolled in the batch');

      const markedBy = db.session.userId;
      const existing = db.attendanceSessions.find(instituteId, { batchId, date, period });
      if (existing?.status === 'locked') fail('FORBIDDEN', 'This roll call is locked');
      const details = {
        subjectId: input.subjectId ?? existing?.subjectId ?? null,
        teacherId: input.teacherId ?? existing?.teacherId ?? null,
        notes: input.notes ?? existing?.notes ?? null,
        status: 'submitted' as const,
        markedBy,
        markedAt: nowIso(),
      };
      const session = existing
        ? db.attendanceSessions.update(instituteId, existing.id, details)
        : db.attendanceSessions.insert(instituteId, { batchId, date, period, ...details });

      for (const { studentId, status, remark = null } of records) {
        const current = db.attendanceRecords.find(instituteId, { sessionId: session.id, studentId });
        if (current) db.attendanceRecords.update(instituteId, current.id, { status, remark, markedBy });
        else db.attendanceRecords.insert(instituteId, { sessionId: session.id, batchId, studentId, status, remark, markedBy });
      }
      emit(db, instituteId, 'attendance', existing ? 'updated' : 'created', session.id);
      return sheet(instituteId, session.id);
    },
    listRecords: async (instituteId, filter) => attendanceRecords(db, instituteId, filter),
    summary: async (instituteId, filter) => summarize(attendanceRecords(db, instituteId, filter)),
    ...attendanceRollPorts(db),
    ...attendanceRegisterPorts(db),
  };
}
