import { normalizePhone10 } from '../../core/contracts/admissions';
import { allocate, applyDiscounts, planCovering } from '../../core/contracts/fee-plan';
import type {
  ConvertLeadInput,
  ConvertLeadResult,
  FeeStructure,
  ID,
  StudentFee,
} from '../../core/contracts/models';
import { emit, type Db } from './db';
import * as D from './defaults';
import { enforceStudentPlanCap } from './people';
import { addDays, fail, round2, todayIso } from './store';

function nextRollForBatch(db: Db, instituteId: ID, batchId: ID): number {
  const rolls = db.enrollments
    .all(instituteId, { batchId, status: 'active' })
    .map((e) => e.rollNumber ?? 0);
  return (rolls.length ? Math.max(...rolls) : 0) + 1;
}

function resolveBatchFeePlan(
  db: Db,
  instituteId: ID,
  batchId: ID,
  feeStructureId: ID | null | undefined,
  monthlyFee: number | null | undefined,
  firstDueDate: string,
): FeeStructure | null {
  if (feeStructureId) {
    const chosen = db.feeStructures.get(instituteId, feeStructureId);
    if (!chosen.isActive) fail('VALIDATION', 'Selected fee plan is no longer active');
    return chosen;
  }
  const activePlan = planCovering(db.feeStructures.all(instituteId), batchId);
  if (activePlan) return activePlan;
  if (monthlyFee == null || !(monthlyFee > 0)) return null;

  const existing = db.feeStructures
    .all(instituteId)
    .find((s) => s.isActive && s.frequency === 'monthly' && s.batchId === batchId && s.totalAmount === round2(monthlyFee));
  if (existing) return existing;

  const batch = db.batches.get(instituteId, batchId);
  return db.feeStructures.insert(instituteId, {
    ...D.feeStructure(),
    name: `${batch.name} monthly`,
    academicYear: batch.academicYear,
    totalAmount: round2(monthlyFee),
    batchId,
    batchIds: [batchId],
    frequency: 'monthly',
    installmentCount: 1,
    schedule: [{ id: 'i1', label: 'Monthly fee', amount: round2(monthlyFee), dueDate: firstDueDate }],
    isActive: true,
  });
}

export function convertLeadTx(
  db: Db,
  instituteId: ID,
  input: ConvertLeadInput,
  onAudit: (leadId: ID, prevStage: ConvertLeadResult['lead']['stage']) => void,
): ConvertLeadResult {
  const lead = db.leads.get(instituteId, input.leadId);
  if (lead.stage === 'enrolled' || lead.convertedStudentId) fail('CONFLICT', 'This lead is already converted');
  if (lead.stage === 'lost') fail('CONFLICT', 'Reopen a lost lead before converting');

  const studentName = input.studentName.trim();
  if (studentName.length < 2) fail('VALIDATION', 'Student name must be at least 2 characters');
  const phone = normalizePhone10(input.phone);
  if (phone.length !== 10) fail('VALIDATION', 'Mobile number must be 10 digits');

  const batch = db.batches.get(instituteId, input.batchId);
  if (batch.status === 'archived') fail('VALIDATION', 'Cannot assign an archived batch');
  const activeEnrollments = db.enrollments.all(instituteId, { batchId: batch.id, status: 'active' });
  if (batch.capacity !== null && activeEnrollments.length >= batch.capacity) fail('CONFLICT', 'This batch is full');

  const rollNumber = input.rollNumber ?? nextRollForBatch(db, instituteId, batch.id);
  if (rollNumber < 1 || !Number.isInteger(rollNumber)) fail('VALIDATION', 'Enter a valid roll number');
  if (activeEnrollments.some((e) => e.rollNumber === rollNumber)) {
    fail('CONFLICT', 'That roll number is already used in this batch');
  }

  enforceStudentPlanCap(db, instituteId);

  const firstDue = input.firstDueDate ?? todayIso();
  const structure = resolveBatchFeePlan(db, instituteId, batch.id, input.feeStructureId, input.monthlyFee, firstDue);

  const student = db.students.insert(instituteId, {
    ...D.student(),
    fullName: studentName,
    phone,
    email: lead.email,
    schoolName: lead.schoolName,
    classGrade: batch.grade ?? lead.classInterested,
    branchId: lead.branchId,
    status: 'active',
    admittedOn: todayIso(),
  });

  const guardianName = input.guardianName?.trim() || lead.guardianName?.trim() || 'Parent';
  const guardianPhone = normalizePhone10(input.guardianPhone) || phone;
  const guardian = db.guardians.insert(instituteId, {
    ...D.guardian(),
    fullName: guardianName,
    relation: input.guardianRelation ?? 'guardian',
    phone: guardianPhone,
  });
  db.parentLinks.insert(instituteId, { studentId: student.id, guardianId: guardian.id, isPrimary: true });

  const enrollment = db.enrollments.insert(instituteId, {
    batchId: batch.id,
    studentId: student.id,
    rollNumber,
    joinedOn: todayIso(),
    leftOn: null,
    status: 'active',
  });

  let studentFee: StudentFee | null = null;
  if (structure) {
    const applied = applyDiscounts(structure.discounts ?? [], input.discountIds ?? [], structure.totalAmount);
    const netAmount = round2(structure.totalAmount - applied.amount);
    studentFee = db.studentFees.insert(instituteId, {
      studentId: student.id,
      feeStructureId: structure.id,
      academicYear: structure.academicYear,
      grossAmount: structure.totalAmount,
      discountAmount: applied.amount,
      discountReason: applied.reason,
      discountIds: applied.ids,
      netAmount,
      status: 'active',
    });

    const schedule =
      structure.schedule && structure.schedule.length > 0
        ? structure.schedule
        : [{ id: 'i1', label: structure.name, amount: netAmount, dueDate: addDays(firstDue, 0) }];
    const amounts = allocate(netAmount, schedule.map((x) => x.amount));
    schedule.forEach((row, idx) => {
      db.installments.insert(instituteId, {
        studentFeeId: studentFee!.id,
        studentId: student.id,
        termNo: idx + 1,
        label: row.label,
        amount: amounts[idx],
        dueDate: row.dueDate,
        paidAmount: 0,
        paidOn: null,
        status: 'upcoming',
      });
    });
  }

  const updatedLead = db.leads.update(instituteId, lead.id, {
    stage: 'enrolled',
    convertedStudentId: student.id,
    nextFollowupAt: null,
    nextFollowupNote: null,
    expectedFee: studentFee?.netAmount ?? lead.expectedFee,
  });

  onAudit(lead.id, lead.stage);
  if (studentFee) emit(db, instituteId, 'payments', 'updated', studentFee.id);

  return { lead: updatedLead, student, guardian, enrollment, studentFee };
}
