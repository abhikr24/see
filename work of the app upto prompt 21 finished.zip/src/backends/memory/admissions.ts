import {
  computeAdmissionsSummary,
  normalizePhone10,
  segmentForStage,
} from '../../core/contracts/admissions';
import type {
  AdmissionLead,
  ID,
  LeadAssigneeOption,
  LeadStage,
  LeadStageChange,
  Role,
} from '../../core/contracts/models';
import type { LeadRepo } from '../../core/contracts/ports';
import { convertLeadTx } from './admissions-convert';
import { crud, type Db } from './db';
import * as D from './defaults';
import { fail, merge, nowIso, todayIso } from './store';

function resolveActor(db: Db, instituteId: ID): { actorId: ID | null; actorRole: Role | null } {
  const userId = db.session.userId;
  if (userId) {
    const membership = db.memberships.find(instituteId, { userId, status: 'active' });
    if (!membership || (membership.role !== 'owner' && membership.role !== 'admin' && membership.role !== 'teacher')) {
      fail('FORBIDDEN', 'Only institute staff can manage admissions');
    }
    return { actorId: userId, actorRole: membership.role };
  }
  const inst = db.institutes.get(instituteId, instituteId);
  return { actorId: inst.ownerId, actorRole: 'owner' };
}

function profileName(db: Db, userId: ID | null): string | null {
  if (!userId) return null;
  return db.profiles.get(userId)?.fullName ?? null;
}

function recordStageAudit(
  db: Db,
  instituteId: ID,
  leadId: ID,
  fromStage: LeadStage | null,
  toStage: LeadStage,
  lostReason: string | null = null,
): void {
  const { actorId, actorRole } = resolveActor(db, instituteId);
  db.auditLogs.insert(instituteId, {
    actorId,
    actorRole,
    action: fromStage === null ? 'lead.created' : toStage === 'enrolled' ? 'lead.converted' : 'lead.stage_changed',
    targetType: 'admission_lead',
    targetId: leadId,
    before: fromStage ? { stage: fromStage } : null,
    after: { stage: toStage, lostReason },
    ipAddress: null,
    userAgent: null,
  });
}

export function admissionsLeadRepo(db: Db): LeadRepo {
  const base = crud<AdmissionLead, 'studentName'>(db.leads, D.lead);

  return {
    ...base,
    create: async (instituteId, input) => {
      resolveActor(db, instituteId);
      if (input.studentName.trim().length < 2) fail('VALIDATION', 'Name must be at least 2 characters');
      const phone = input.phone ? normalizePhone10(input.phone) : null;
      if (input.phone && phone?.length !== 10) fail('VALIDATION', 'Phone must be 10 digits');
      const created = await base.create(instituteId, { ...input, studentName: input.studentName.trim(), phone });
      recordStageAudit(db, instituteId, created.id, null, created.stage, created.lostReason);
      return created;
    },

    remove: async () => {
      fail('CONFLICT', 'Leads cannot be deleted; mark as lost with a reason');
    },

    pipeline: async (instituteId) => {
      db.institutes.get(instituteId, instituteId);
      const leads = db.leads.all(instituteId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      const followups = db.followups.all(instituteId);
      const byLead = new Map<ID, typeof followups>();
      for (const f of followups) {
        const list = byLead.get(f.leadId) ?? [];
        list.push(f);
        byLead.set(f.leadId, list);
      }

      const items = leads.map((lead) => {
        const list = (byLead.get(lead.id) ?? []).sort((a, b) => b.followupAt.localeCompare(a.followupAt));
        const latest = list[0] ?? null;
        return {
          lead,
          segment: segmentForStage(lead.stage),
          lastFollowupAt: latest?.followupAt ?? null,
          lastFollowupChannel: latest?.channel ?? null,
          assignedToName: profileName(db, lead.assignedTo),
        };
      });

      const assignees: LeadAssigneeOption[] = db.memberships
        .all(instituteId, { status: 'active' })
        .filter((m) => m.role === 'owner' || m.role === 'admin' || m.role === 'teacher')
        .map((m) => ({
          userId: m.userId,
          fullName: db.profiles.get(m.userId)?.fullName ?? 'Staff member',
          role: m.role,
        }));

      return {
        summary: computeAdmissionsSummary(leads, followups, todayIso()),
        items,
        assignees,
      };
    },

    detail: async (instituteId, leadId) => {
      const lead = db.leads.get(instituteId, leadId);
      const followups = db.followups
        .all(instituteId, { leadId })
        .sort((a, b) => b.followupAt.localeCompare(a.followupAt) || b.id.localeCompare(a.id))
        .map((followup) => ({ followup, doneByName: profileName(db, followup.doneBy) }));

      const stageChanges: LeadStageChange[] = db.auditLogs
        .all(instituteId, { targetType: 'admission_lead', targetId: leadId })
        .filter((log) => log.action === 'lead.created' || log.action === 'lead.stage_changed' || log.action === 'lead.converted')
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id))
        .map((log) => ({
          id: log.id,
          fromStage: (log.before?.stage as LeadStage | undefined) ?? null,
          toStage: (log.after?.stage as LeadStage | undefined) ?? lead.stage,
          lostReason: (log.after?.lostReason as string | null | undefined) ?? null,
          actorName: profileName(db, log.actorId),
          changedAt: log.createdAt,
        }));

      return {
        lead,
        segment: segmentForStage(lead.stage),
        assignedToName: profileName(db, lead.assignedTo),
        followups,
        stageChanges,
      };
    },

    moveStage: async (instituteId, id, stage, lostReason = null) => {
      resolveActor(db, instituteId);
      const lead = db.leads.get(instituteId, id);
      if (lead.stage === 'enrolled') fail('CONFLICT', 'A converted lead cannot be moved');
      if (stage === 'enrolled') fail('VALIDATION', 'Use convert to admit this lead');
      if (stage === 'lost' && !lostReason?.trim()) fail('VALIDATION', 'Please enter why this lead was lost');
      if (lead.stage === stage && (stage !== 'lost' || lead.lostReason === lostReason?.trim())) return lead;

      const reason = stage === 'lost' ? lostReason!.trim() : null;
      const updated = db.leads.update(instituteId, id, {
        stage,
        lostReason: reason,
        nextFollowupAt: stage === 'lost' ? null : lead.nextFollowupAt,
      });
      recordStageAudit(db, instituteId, id, lead.stage, stage, reason);
      return updated;
    },

    listFollowups: async (instituteId, leadId) => {
      db.leads.get(instituteId, leadId);
      return db.followups.all(instituteId, { leadId }).sort((a, b) => b.followupAt.localeCompare(a.followupAt));
    },

    addFollowup: async (instituteId, input) => {
      const { actorId } = resolveActor(db, instituteId);
      const lead = db.leads.get(instituteId, input.leadId);
      const followup = db.followups.insert(
        instituteId,
        merge({ ...D.followup(), doneBy: actorId, followupAt: nowIso() }, {
          leadId: input.leadId,
          channel: input.channel,
          summary: input.summary,
          outcome: input.outcome,
          followupAt: input.followupAt,
          nextFollowupAt: input.nextFollowupAt,
          doneBy: input.doneBy ?? actorId,
        }),
      );

      let nextStage = lead.stage;
      if (lead.stage === 'new') nextStage = 'contacted';
      else if (input.outcome === 'demo_booked' && lead.stage !== 'enrolled' && lead.stage !== 'lost') {
        nextStage = 'demo_scheduled';
      }

      db.leads.update(instituteId, lead.id, {
        nextFollowupAt: input.nextFollowupAt !== undefined ? input.nextFollowupAt : lead.nextFollowupAt,
        nextFollowupNote: input.nextFollowupNote !== undefined ? input.nextFollowupNote : lead.nextFollowupNote,
        stage: nextStage,
      });

      if (nextStage !== lead.stage) recordStageAudit(db, instituteId, lead.id, lead.stage, nextStage);
      return followup;
    },

    convert: async (instituteId, input) => {
      resolveActor(db, instituteId);
      return convertLeadTx(db, instituteId, input, (leadId, prevStage) =>
        recordStageAudit(db, instituteId, leadId, prevStage, 'enrolled'),
      );
    },
  };
}
