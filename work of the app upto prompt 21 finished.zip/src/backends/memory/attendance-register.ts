import {
  buildMonthRegister,
  buildRegisterDay,
  cleanReason,
  correctionAccess,
  inMonth,
  monthBounds,
  type RegisterStudent,
} from '../../core/contracts/attendance-register';
import type {
  AttendanceCorrection,
  AttendanceCorrectionEntry,
  AttendanceStatus,
  ID,
  Role,
} from '../../core/contracts/models';
import type { AttendanceRepo } from '../../core/contracts/ports';
import { emit, requireUser, type Db } from './db';
import { visibleBatch } from './teacher-scope';
import { fail, nowIso, todayIso } from './store';

type RegisterPorts = Pick<AttendanceRepo, 'monthRegister' | 'registerDay' | 'correctAttendance'>;

const STATUSES: readonly AttendanceStatus[] = ['present', 'absent', 'late', 'leave'];

function roleOf(db: Db, instituteId: ID, userId: ID | null): Role | null {
  if (!userId) return null;
  return db.memberships.find(instituteId, { userId, status: 'active' })?.role ?? null;
}

/** Everyone enrolled in the batch (any status) plus anyone who has a record in it. */
function studentsOf(db: Db, instituteId: ID, batchId: ID): RegisterStudent[] {
  const roll = new Map<ID, number | null>(db.enrollments.all(instituteId, { batchId }).map((e) => [e.studentId, e.rollNumber]));
  for (const record of db.attendanceRecords.all(instituteId, { batchId })) {
    if (!roll.has(record.studentId)) roll.set(record.studentId, null);
  }
  return [...roll].map(([studentId, rollNumber]) => ({
    studentId,
    rollNumber,
    fullName: db.students.get(instituteId, studentId).fullName,
  }));
}

function entryOf(db: Db, instituteId: ID, row: AttendanceCorrection): AttendanceCorrectionEntry {
  const record = db.attendanceRecords.get(instituteId, row.recordId);
  const session = db.attendanceSessions.get(instituteId, record.sessionId);
  const actor = row.requestedBy;
  return {
    ...row,
    date: session.date,
    period: session.period,
    studentName: db.students.get(instituteId, row.studentId).fullName,
    changedByName: actor ? (db.profiles.get(actor)?.fullName ?? null) : null,
    changedByRole: roleOf(db, instituteId, actor),
  };
}

/** The monthly register, the day sheet and the audited correction write. */
export function attendanceRegisterPorts(db: Db): RegisterPorts {
  return {
    monthRegister: async (instituteId, { batchId, month }) => {
      const batch = visibleBatch(db, instituteId, batchId);
      monthBounds(month);
      const sessions = db.attendanceSessions.all(instituteId, { batchId }).filter((s) => inMonth(s.date, month));
      const ids = new Set(sessions.map((s) => s.id));
      return buildMonthRegister({
        batchId,
        batchName: batch.name,
        month,
        today: todayIso(),
        students: studentsOf(db, instituteId, batchId),
        sessions,
        records: db.attendanceRecords.all(instituteId, { batchId }).filter((r) => ids.has(r.sessionId)),
        corrections: db.attendanceCorrections.all(instituteId, { batchId }),
      });
    },

    registerDay: async (instituteId, { batchId, date }) => {
      const batch = visibleBatch(db, instituteId, batchId);
      const sessions = db.attendanceSessions.all(instituteId, { batchId, date });
      const ids = new Set(sessions.map((s) => s.id));
      const records = db.attendanceRecords.all(instituteId, { batchId }).filter((r) => ids.has(r.sessionId));
      const recordIds = new Set(records.map((r) => r.id));
      const subjects = new Map(db.subjects.all(instituteId).map((s) => [s.id, s.name]));
      return buildRegisterDay({
        batchId,
        batchName: batch.name,
        date,
        today: todayIso(),
        role: roleOf(db, instituteId, db.session.userId),
        students: studentsOf(db, instituteId, batchId),
        sheets: sessions.map((session) => ({
          session,
          subjectName: session.subjectId ? (subjects.get(session.subjectId) ?? null) : null,
          records: records.filter((r) => r.sessionId === session.id),
        })),
        corrections: db.attendanceCorrections
          .all(instituteId, { batchId })
          .filter((row) => recordIds.has(row.recordId))
          .map((row) => entryOf(db, instituteId, row)),
      });
    },

    correctAttendance: async (instituteId, { batchId, date, changes, reason }) => {
      const actorId = requireUser(db);
      const role = roleOf(db, instituteId, actorId);
      visibleBatch(db, instituteId, batchId);
      const access = correctionAccess(role, date, todayIso());
      if (!access.canCorrect) {
        fail(access.block === 'future' ? 'VALIDATION' : 'FORBIDDEN', access.message ?? undefined);
      }
      const note = cleanReason(reason);

      // Validate every change before writing any, so a bad row never leaves a half-applied save.
      const wanted = new Map<ID, AttendanceStatus>(changes.map((c) => [c.recordId, c.status]));
      const plan = [...wanted].flatMap(([recordId, status]) => {
        if (!STATUSES.includes(status)) fail('VALIDATION', 'Unknown attendance status');
        const record = db.attendanceRecords.get(instituteId, recordId);
        const session = db.attendanceSessions.get(instituteId, record.sessionId);
        if (record.batchId !== batchId || session.date !== date) fail('VALIDATION', 'That record is not on this day');
        if (session.status === 'locked' && role !== 'owner') fail('FORBIDDEN', 'This roll call is locked. Ask the owner.');
        return record.status === status ? [] : [{ record, status }];
      });
      if (plan.length === 0) fail('VALIDATION', 'Nothing was changed');

      const at = nowIso();
      const written = plan.map(({ record, status }) => {
        const correction = db.attendanceCorrections.insert(instituteId, {
          recordId: record.id,
          batchId,
          studentId: record.studentId,
          requestedBy: actorId,
          currentStatus: record.status,
          requestedStatus: status,
          reason: note,
          status: 'approved',
          reviewedBy: actorId,
          reviewedAt: at,
          reviewNote: null,
        });
        db.attendanceRecords.update(instituteId, record.id, { status });
        db.auditLogs.insert(instituteId, {
          actorId,
          actorRole: role,
          action: 'attendance.corrected',
          targetType: 'attendance_record',
          targetId: record.id,
          before: { status: record.status },
          after: { status, reason: note, correctionId: correction.id, studentId: record.studentId, batchId, date },
          ipAddress: null,
          userAgent: null,
        });
        emit(db, instituteId, 'attendance', 'updated', record.sessionId);
        return correction;
      });
      return written.map((row) => entryOf(db, instituteId, row));
    },
  };
}
