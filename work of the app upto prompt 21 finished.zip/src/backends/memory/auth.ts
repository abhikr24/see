import * as SecureStore from 'expo-secure-store';

import type { AuthSession, ID, OtpChallenge, Profile } from '../../core/contracts/models';
import type { AuthPort, Credentials, InstituteScope } from '../../core/contracts/ports';
import type { Db, OtpEntry } from './db';
import * as D from './defaults';
import { defined, fail, nowIso } from './store';

export const MEMORY_PASSWORD = 'demo1234';
const OTP_EXPIRES_MS = 5 * 60 * 1000;
const SESSION_KEY = 'gf.session.userId';

function profileOf(db: Db, userId: ID): Profile {
  return db.profiles.get(userId) ?? fail('NOT_FOUND', 'Profile not found');
}

function findByEmail(db: Db, email: string): Profile | undefined {
  const wanted = email.trim().toLowerCase();
  return [...db.profiles.values()].find((p) => p.email?.toLowerCase() === wanted);
}

function findByPhone(db: Db, phone: string): Profile | undefined {
  const normalized = phone.replace(/\D/g, '').slice(-10);
  return [...db.profiles.values()].find((p) => (p.phone ?? '').replace(/\D/g, '').slice(-10) === normalized);
}

function findProfile(db: Db, identifier: string): Profile | undefined {
  const trimmed = identifier.trim();
  if (trimmed.includes('@')) return findByEmail(db, trimmed);
  if (/^\+?\d{7,15}$/.test(trimmed.replace(/[\s-]/g, ''))) return findByPhone(db, trimmed) ?? findByEmail(db, trimmed);
  return findByEmail(db, trimmed);
}

async function persistSession(userId: ID | null) {
  try {
    if (userId) await SecureStore.setItemAsync(SESSION_KEY, userId);
    else await SecureStore.deleteItemAsync(SESSION_KEY);
  } catch {}
}

async function restoreSession(db: Db): Promise<ID | null> {
  if (db.session.userId) return db.session.userId;
  try {
    const stored = await SecureStore.getItemAsync(SESSION_KEY);
    if (stored && db.profiles.has(stored)) {
      db.session.userId = stored;
      return stored;
    }
    // also allow seeded ids that may not be in profiles map yet? seed ensures they are
    if (stored) {
      // if profile missing but stored is plausible, still set to allow getSession to fail gracefully
      db.session.userId = stored;
      return stored;
    }
  } catch {}
  return null;
}

export function authPort(db: Db): AuthPort {
  const session = (instituteId: InstituteScope): AuthSession | null => {
    const userId = db.session.userId;
    if (!userId) return null;
    const profile = db.profiles.get(userId);
    if (!profile) return null;
    const membership = instituteId ? (db.memberships.find(instituteId, { userId }) ?? null) : null;
    return { user: { id: userId, email: profile.email, phone: profile.phone }, profile, membership, expiresAt: null };
  };

  return {
    getSession: async (instituteId) => {
      await restoreSession(db);
      return session(instituteId);
    },
    signIn: async (instituteId, { email, password }) => {
      const identifier = email;
      const profile = findProfile(db, identifier);
      if (!profile || password !== MEMORY_PASSWORD) fail('UNAUTHENTICATED', 'Wrong email or password');
      db.session.userId = profile.userId;
      await persistSession(profile.userId);
      return session(instituteId) as AuthSession;
    },
    signUp: async (instituteId, { email, password, fullName }) => {
      if (!email.includes('@')) fail('VALIDATION', 'Enter a valid email address');
      if (password.length < 8) fail('VALIDATION', 'Password must be at least 8 characters');
      if (!fullName.trim()) fail('VALIDATION', 'Name is required');
      if (findByEmail(db, email)) fail('CONFLICT', 'An account with this email already exists');
      const at = nowIso();
      const userId = db.nextId();
      db.profiles.set(userId, {
        ...D.profile(),
        id: db.nextId(),
        userId,
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        createdAt: at,
        updatedAt: at,
      });
      db.session.userId = userId;
      await persistSession(userId);
      return session(instituteId) as AuthSession;
    },
    signOut: async () => {
      db.session.userId = null;
      await persistSession(null);
    },
    requestPasswordReset: async (_instituteId, email) => {
      if (!email.includes('@')) fail('VALIDATION', 'Enter a valid email address');
    },
    getProfile: async (_instituteId, userId) => profileOf(db, userId),
    updateProfile: async (_instituteId, userId, patch) => {
      const current = profileOf(db, userId);
      const requester = await restoreSession(db);
      if (requester !== userId) {
        // allow if unauthenticated? but follow original guard
        const req = db.session.userId ?? fail('UNAUTHENTICATED');
        if (req !== userId) fail('FORBIDDEN', 'You can only edit your own profile');
      }
      const next: Profile = { ...current, ...defined(patch), userId, updatedAt: nowIso() };
      db.profiles.set(userId, next);
      return next;
    },

    requestOtp: async (_instituteId, { email, password }) => {
      const identifier = email;
      const profile = findProfile(db, identifier);
      if (!profile) fail('UNAUTHENTICATED', 'Wrong email or password');
      if (password !== MEMORY_PASSWORD) fail('UNAUTHENTICATED', 'Wrong email or password');
      const challengeId = db.nextId();
      const expiresAt = new Date(Date.now() + OTP_EXPIRES_MS).toISOString();
      const channel: OtpChallenge['channel'] = identifier.includes('@') ? 'email' : 'sms';
      const entry: OtpEntry = { challengeId, userId: profile.userId, code: '123456', expiresAt, channel, credentials: { email: identifier, password } };
      db.otpChallenges.set(challengeId, entry);
      // do NOT create session
      return { challengeId, expiresAt, channel };
    },

    verifyOtp: async (instituteId, { challengeId, code }) => {
      const entry = db.otpChallenges.get(challengeId);
      if (!entry) fail('NOT_FOUND', 'Code expired — request a new one');
      if (new Date(entry.expiresAt).getTime() < Date.now()) {
        db.otpChallenges.delete(challengeId);
        fail('VALIDATION', 'Code expired — request a new one');
      }
      const trimmed = code.trim();
      const isSixDigits = /^\d{6}$/.test(trimmed);
      if (!isSixDigits) fail('VALIDATION', 'Enter the 6-digit code');
      // In dev any 6-digit code works; we still accept any isSixDigits
      db.session.userId = entry.userId;
      await persistSession(entry.userId);
      db.otpChallenges.delete(challengeId);
      const sess = session(instituteId);
      if (!sess) fail('UNAUTHENTICATED', 'Could not create session');
      return sess as AuthSession;
    },

    resendOtp: async (_instituteId, challengeId) => {
      const entry = db.otpChallenges.get(challengeId);
      if (!entry) fail('NOT_FOUND', 'Challenge not found — request a new code');
      const expiresAt = new Date(Date.now() + OTP_EXPIRES_MS).toISOString();
      const updated: OtpEntry = { ...entry, expiresAt };
      db.otpChallenges.set(challengeId, updated);
      return { challengeId, expiresAt, channel: entry.channel };
    },

    signInWithGoogle: async (instituteId) => {
      // Dev stub: find existing google user or create one
      const googleEmail = 'google.user@example.com';
      let profile = findByEmail(db, googleEmail);
      if (!profile) {
        const at = nowIso();
        const userId = db.nextId();
        profile = {
          ...D.profile(),
          id: db.nextId(),
          userId,
          fullName: 'Google User',
          email: googleEmail,
          createdAt: at,
          updatedAt: at,
        };
        db.profiles.set(userId, profile);
      }
      db.session.userId = profile.userId;
      await persistSession(profile.userId);
      return session(instituteId) as AuthSession;
    },
  };
}
