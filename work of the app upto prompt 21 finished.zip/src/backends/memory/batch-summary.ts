import type { BatchSummary, BatchRosterRow, ID } from '../../core/contracts/models';
import type { Db } from './db';
import { round1 } from './store';
import { assignmentOf } from './teacher-scope';

export function batchSummaries(db: Db, instituteId: ID): BatchSummary[] {
  const counts = new Map<ID, number>();
  const tally = new Map<ID, { total: number; present: number }>();
  const dueStudents = new Set(db.installments.all(instituteId).filter((i) =>
    i.status !== 'waived' && i.amount > i.paidAmount && i.dueDate <= new Date().toISOString().slice(0, 10),
  ).map((i) => i.studentId));
  const dues = new Map<ID, number>();
  for (const e of db.enrollments.all(instituteId, { status: 'active' })) {
    counts.set(e.batchId, (counts.get(e.batchId) ?? 0) + 1);
    if (dueStudents.has(e.studentId)) dues.set(e.batchId, (dues.get(e.batchId) ?? 0) + 1);
  }
  for (const r of db.attendanceRecords.all(instituteId)) {
    const t = tally.get(r.batchId) ?? { total: 0, present: 0 };
    t.total++;
    if (r.status === 'present' || r.status === 'late') t.present++;
    tally.set(r.batchId, t);
  }
  return db.batches.all(instituteId).map((b) => {
    const periods = db.timetables.all(instituteId, { batchId: b.id });
    const { subjectId, teacherId, first } = assignmentOf(db, instituteId, b);
    const teacher = db.teachers.all(instituteId).find((t) => t.id === teacherId);
    const subject = db.subjects.all(instituteId).find((s) => s.id === subjectId);
    const t = tally.get(b.id);
    return { ...b, subjectId, teacherId,
      days: b.days ?? [...new Set(periods.map((p) => p.dayOfWeek))],
      startsAt: b.startsAt ?? first?.startsAt, endsAt: b.endsAt ?? first?.endsAt,
      subjectName: subject?.name ?? 'General', teacherName: teacher?.fullName ?? 'Unassigned',
      teacherPhoto: teacher?.photoUrl ?? null, studentCount: counts.get(b.id) ?? 0,
      attendanceTotal: t?.total ?? 0,
      attendancePct: t?.total ? round1(t.present / t.total * 100) : 0,
      pendingFees: dues.get(b.id) ?? 0,
    };
  });
}

export function batchRoster(db: Db, instituteId: ID, batchId: ID): BatchRosterRow[] {
  db.batches.get(instituteId, batchId);
  const tally = new Map<ID, { total: number; present: number }>();
  for (const r of db.attendanceRecords.all(instituteId, { batchId })) {
    const t = tally.get(r.studentId) ?? { total: 0, present: 0 };
    t.total++;
    if (r.status === 'present' || r.status === 'late') t.present++;
    tally.set(r.studentId, t);
  }
  return db.enrollments.all(instituteId, { batchId, status: 'active' }).map((e) => {
    const s = db.students.get(instituteId, e.studentId);
    const t = tally.get(s.id);
    return { studentId: s.id, fullName: s.fullName, photoUrl: s.photoUrl,
      rollNumber: e.rollNumber, attendanceTotal: t?.total ?? 0,
      attendancePct: t?.total ? round1(t.present / t.total * 100) : 0 };
  }).sort((a, b) => (a.rollNumber ?? 999) - (b.rollNumber ?? 999));
}
