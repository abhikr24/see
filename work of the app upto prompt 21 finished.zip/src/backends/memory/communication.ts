import type { ConversationMessage, Notice } from '../../core/contracts/models';
import type {
  DoubtRepo,
  MeetingRepo,
  NoticeRepo,
  NotificationRepo,
  RealtimePort,
} from '../../core/contracts/ports';
import { crud, emit, requireUser, type Db } from './db';
import * as D from './defaults';
import { fail, merge, nowIso } from './store';

export function noticeRepo(db: Db): NoticeRepo {
  const base = crud<Notice, 'title'>(db.notices, D.notice);
  return {
    ...base,
    create: async (instituteId, input) => {
      if (!input.title.trim()) fail('VALIDATION', 'Title is required');
      if (input.audience && input.audience.length === 0) fail('VALIDATION', 'Choose who should see this notice');
      return base.create(instituteId, { createdBy: db.session.userId, ...input });
    },
    publish: async (instituteId, id) => {
      const notice = db.notices.update(instituteId, id, { publishedAt: nowIso() });
      emit(db, instituteId, 'notices', 'updated', id);
      return notice;
    },
    setPinned: async (instituteId, id, pinned) => db.notices.update(instituteId, id, { isPinned: pinned }),
  };
}

export function notificationRepo(db: Db): NotificationRepo {
  const unread = (instituteId: string) =>
    db.notifications.all(instituteId, { userId: requireUser(db) }).filter((n) => n.readAt === null);
  return {
    list: async (instituteId, query) => db.notifications.page(instituteId, query, { userId: requireUser(db) }),
    unreadCount: async (instituteId) => unread(instituteId).length,
    markRead: async (instituteId, id) => {
      const notification = db.notifications.get(instituteId, id);
      // Someone else's notification is indistinguishable from one that does not exist.
      if (notification.userId !== requireUser(db)) fail('NOT_FOUND', 'Notification not found');
      return notification.readAt ? notification : db.notifications.update(instituteId, id, { readAt: nowIso() });
    },
    markAllRead: async (instituteId) => {
      const pending = unread(instituteId);
      pending.forEach((n) => db.notifications.update(instituteId, n.id, { readAt: nowIso() }));
      return pending.length;
    },
    send: async (instituteId, input) => {
      if (!db.memberships.find(instituteId, { userId: input.userId })) {
        fail('VALIDATION', 'That person is not a member of this institute');
      }
      const sent = db.notifications.insert(instituteId, merge(D.notification(), input));
      emit(db, instituteId, 'notifications', 'created', sent.id);
      return sent;
    },
  };
}

export function doubtRepo(db: Db): DoubtRepo {
  return {
    list: async (instituteId, query) => db.doubts.page(instituteId, query),
    get: async (instituteId, id) => db.doubts.get(instituteId, id),
    ask: async (instituteId, input) => {
      const { batchId, studentId } = input;
      if (!input.question.trim()) fail('VALIDATION', 'Type your question first');
      if (!db.enrollments.find(instituteId, { batchId, studentId, status: 'active' })) {
        fail('VALIDATION', 'Student is not enrolled in that batch');
      }
      const doubt = db.doubts.insert(instituteId, merge({ ...D.doubt(), askedBy: db.session.userId }, input));
      emit(db, instituteId, 'doubts', 'created', doubt.id);
      return doubt;
    },
    answer: async (instituteId, id, answer) => {
      if (!answer.trim()) fail('VALIDATION', 'The answer cannot be empty');
      const doubt = db.doubts.update(instituteId, id, {
        answer,
        answeredBy: db.session.userId,
        answeredAt: nowIso(),
        status: 'answered',
      });
      emit(db, instituteId, 'doubts', 'updated', id);
      return doubt;
    },
    setStatus: async (instituteId, id, status) => db.doubts.update(instituteId, id, { status }),
  };
}

export function meetingRepo(db: Db): MeetingRepo {
  return {
    list: async (instituteId, query) => db.meetings.page(instituteId, query),
    get: async (instituteId, id) => db.meetings.get(instituteId, id),
    request: async (instituteId, input) => {
      db.students.get(instituteId, input.studentId);
      db.teachers.get(instituteId, input.teacherId);
      return db.meetings.insert(instituteId, merge({ ...D.meeting(), requestedBy: db.session.userId }, input));
    },
    respond: async (instituteId, id, { status, scheduledAt, note = null }) => {
      const meeting = db.meetings.get(instituteId, id);
      if (meeting.status !== 'pending' && meeting.status !== 'accepted') {
        fail('CONFLICT', `This meeting is already ${meeting.status}`);
      }
      const when = scheduledAt ?? meeting.scheduledAt ?? meeting.preferredAt;
      if (status === 'accepted' && !when) fail('VALIDATION', 'Pick a time to accept this meeting');
      return db.meetings.update(instituteId, id, {
        status,
        scheduledAt: status === 'accepted' ? when : meeting.scheduledAt,
        responseNote: note,
        respondedAt: nowIso(),
      });
    },
    listConversations: async (instituteId, query) => {
      const userId = requireUser(db);
      const sort = query?.sort ?? { field: 'lastMessageAt' as const, direction: 'desc' as const };
      return db.conversations.page(instituteId, { ...query, sort }, {}, (c) => c.participantIds.includes(userId));
    },
    startConversation: async (instituteId, input) => {
      const userId = requireUser(db);
      const participantIds = [...new Set([userId, ...input.participantIds])];
      if (participantIds.length < 2) fail('VALIDATION', 'A conversation needs someone else in it');
      const outsider = participantIds.find((id) => !db.memberships.find(instituteId, { userId: id }));
      if (outsider) fail('VALIDATION', 'Everyone in a conversation must belong to this institute');
      return db.conversations.insert(instituteId, {
        ...merge(D.conversation(), input),
        participantIds,
        messages: [],
        createdBy: userId,
      });
    },
    sendMessage: async (instituteId, conversationId, body) => {
      const userId = requireUser(db);
      const conversation = db.conversations.get(instituteId, conversationId);
      if (!conversation.participantIds.includes(userId)) fail('FORBIDDEN', 'You are not part of this conversation');
      if (!body.trim()) fail('VALIDATION', 'Type a message first');
      const message: ConversationMessage = { id: db.nextId(), senderId: userId, body: body.trim(), sentAt: nowIso() };
      const updated = db.conversations.update(instituteId, conversationId, {
        messages: [...conversation.messages, message],
        lastMessagePreview: message.body.slice(0, 80),
        lastMessageAt: message.sentAt,
      });
      emit(db, instituteId, 'conversations', 'updated', conversationId);
      return updated;
    },
  };
}

/** In-process change feed: events are delivered synchronously to subscribers in this app only. */
export function realtimePort(db: Db): RealtimePort {
  return {
    status: async (instituteId) => {
      db.institutes.get(instituteId, instituteId);
      return 'connected';
    },
    subscribe: async (instituteId, topic, onEvent) => {
      db.institutes.get(instituteId, instituteId);
      const key = `${instituteId}:${topic}`;
      const listeners = db.listeners.get(key) ?? new Set();
      db.listeners.set(key, listeners);
      listeners.add(onEvent);
      return {
        topic,
        unsubscribe: async () => {
          listeners.delete(onEvent);
        },
      };
    },
  };
}
