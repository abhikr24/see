import type { DashboardBatch, DashboardTeacher, ID, OwnerDashboard, Timetable } from '../../core/contracts/models';
import { attendanceRecords, summarize } from './academics';
import type { Db } from './db';
import { isOverdue, remaining } from './finance';
import { progressPort } from './progress';
import { addDays, round2, sum, todayIso } from './store';

/** "This week" on the dashboard: the seven days ending today. */
const ALERT_WINDOW_DAYS = 7;

const clock = (at = new Date()): string =>
  `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;

/** Today's periods folded into one row per batch, ordered by first period. */
function batchesToday(db: Db, instituteId: ID, today: string): DashboardBatch[] {
  const names = new Map(db.batches.all(instituteId, { status: 'active' }).map((batch) => [batch.id, batch.name]));
  const dayOfWeek = new Date(`${today}T00:00:00Z`).getUTCDay();
  const inForce = (p: Timetable) => (!p.validFrom || p.validFrom <= today) && (!p.validTo || p.validTo >= today);
  const periods = db.timetables
    .all(instituteId, { dayOfWeek })
    .filter((p) => names.has(p.batchId) && inForce(p))
    .sort((a, b) => a.startsAt.localeCompare(b.startsAt));

  const rows = new Map<ID, DashboardBatch>();
  for (const period of periods) {
    const row = rows.get(period.batchId) ?? {
      batchId: period.batchId,
      name: names.get(period.batchId) ?? '',
      startsAt: period.startsAt,
      endsAt: period.endsAt,
      teachers: [] as DashboardTeacher[],
      studentCount: db.enrollments.all(instituteId, { batchId: period.batchId, status: 'active' }).length,
    };
    if (period.endsAt > row.endsAt) row.endsAt = period.endsAt;
    const teacher = period.teacherId ? db.teachers.find(instituteId, { id: period.teacherId }) : undefined;
    if (teacher && !row.teachers.some((t) => t.id === teacher.id)) {
      row.teachers.push({ id: teacher.id, fullName: teacher.fullName, photoUrl: teacher.photoUrl });
    }
    rows.set(period.batchId, row);
  }
  return [...rows.values()];
}

/**
 * AnalyticsRepo.dashboard. Each figure is read with the same helper its own
 * port uses (`summarize`, `isOverdue`, the feeCollection rule), so the
 * dashboard cannot disagree with the attendance, fees or approvals screens.
 *
 * A real backend raises risk alerts on a schedule; nothing does that here, so
 * the rules are re-evaluated through ProgressPort before the alerts are counted.
 */
export async function ownerDashboard(db: Db, instituteId: ID): Promise<OwnerDashboard> {
  db.institutes.get(instituteId, instituteId);
  const today = todayIso();

  const paidToday = db.payments
    .all(instituteId, { status: 'completed' })
    .filter((payment) => payment.paidAt.slice(0, 10) === today);
  const attendance = summarize(attendanceRecords(db, instituteId, { from: today, to: today }));
  const overdue = db.installments.all(instituteId).filter((x) => isOverdue(x, today));

  const weekStart = addDays(today, 1 - ALERT_WINDOW_DAYS);
  const alerts = await progressPort(db).computeAlerts(instituteId);
  const lowAttendance = alerts.filter(
    (alert) => alert.kind === 'low_attendance' && alert.status === 'open' && alert.detectedAt.slice(0, 10) >= weekStart,
  );

  const batches = batchesToday(db, instituteId, today);
  const now = clock();
  const current = batches.find((batch) => batch.endsAt > now) ?? batches[batches.length - 1];

  return {
    date: today,
    batchCount: db.batches.all(instituteId).filter((b) => b.status === 'active' || b.status === 'upcoming').length,
    collectedToday: round2(sum(paidToday.map((payment) => payment.amount))),
    attendancePercent: attendance.total ? attendance.percent : null,
    pendingApprovals: db.memberships.all(instituteId, { status: 'pending' }).length,
    overdueAmount: round2(sum(overdue.map(remaining))),
    overdueStudents: new Set(overdue.map((x) => x.studentId)).size,
    lowAttendanceAlerts: lowAttendance.length,
    batchesToday: batches,
    currentBatchId: current?.batchId ?? null,
  };
}
