/**
 * The reference backend's exam analysis.
 *
 * Reads the marks, the roster and the other exams of the batch, then hands
 * everything to the shared `buildExamAnalysis` — the same calculation the
 * Supabase adapter uses.
 */

import type { Exam, ExamAnalysis, ID, Mark } from '../../core/contracts/models';
import {
  buildExamAnalysis,
  round1,
  type AnalysisHistoryPoint,
  type AnalysisSubjectInput,
} from '../../core/contracts/exam-analysis';
import { batchRoster } from './batch-summary';
import { fail } from './store';
import type { Db } from './db';

function examDate(exam: Exam): string {
  return exam.startsOn ?? exam.createdAt.slice(0, 10);
}

/** Class average of the scored rows of one exam. */
function averageOf(rows: Mark[]): number | null {
  const scored = rows.filter((row) => !row.isAbsent && row.marksObtained !== null);
  if (!scored.length) return null;
  const total = scored.reduce((sum, row) => sum + (row.marksObtained ?? 0) / (row.maxMarks || 1) * 100, 0);
  return round1(total / scored.length);
}

export function examAnalysis(db: Db, instituteId: ID, examId: ID, publishedOnly: boolean): ExamAnalysis {
  const exam = db.exams.get(instituteId, examId);
  if (publishedOnly && exam.status !== 'published') fail('NOT_FOUND', 'Exam not found');

  const batch = db.batches.get(instituteId, exam.batchId);
  const roster = batchRoster(db, instituteId, exam.batchId);
  const marks = db.marks.all(instituteId, { examId });
  const subjectNames = new Map(db.subjects.all(instituteId).map((subject) => [subject.id, subject.name]));

  const batchExams = db.exams
    .all(instituteId, { batchId: exam.batchId })
    .filter((other) => (publishedOnly ? other.status === 'published' : true));

  const marksByExam = new Map<ID, Mark[]>();
  for (const other of batchExams) marksByExam.set(other.id, db.marks.all(instituteId, { examId: other.id }));

  const history: AnalysisHistoryPoint[] = [];
  for (const other of batchExams) {
    if (other.id === exam.id) continue;
    const averagePct = averageOf(marksByExam.get(other.id) ?? []);
    if (averagePct === null) continue;
    history.push({ examId: other.id, examName: other.name, averagePct, date: examDate(other) });
  }

  // The latest exam of the batch that has marks in a subject owns that
  // subject's class average.
  const latestBySubject = new Map<ID, Exam>();
  for (const other of [...batchExams].sort((a, b) => examDate(a).localeCompare(examDate(b)))) {
    for (const mark of marksByExam.get(other.id) ?? []) latestBySubject.set(mark.subjectId, other);
  }

  const subjectAverages: AnalysisSubjectInput[] = [];
  for (const [subjectId, owner] of latestBySubject) {
    const rows = (marksByExam.get(owner.id) ?? []).filter((mark) => mark.subjectId === subjectId);
    const scored = rows.filter((row) => !row.isAbsent && row.marksObtained !== null);
    const averagePct = averageOf(rows) ?? 0;
    subjectAverages.push({
      subjectId,
      subjectName: subjectNames.get(subjectId) ?? 'Subject',
      averagePct,
      students: scored.length,
      maxMarks: rows[0]?.maxMarks ?? 0,
    });
  }

  const subjectName =
    subjectNames.get(exam.subjectId ?? marks[0]?.subjectId ?? batch.subjectId ?? '') ?? 'General';

  return buildExamAnalysis({
    exam,
    subjectName,
    batchName: batch.name,
    marks,
    students: roster.map((row) => ({
      studentId: row.studentId,
      fullName: row.fullName,
      rollNumber: row.rollNumber,
      photoUrl: row.photoUrl,
    })),
    history,
    subjectAverages,
    passPercent: exam.passPercent,
  });
}
