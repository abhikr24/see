import {
  allocate,
  applyDiscounts,
  buildPlanView,
  buildStatement,
  feeHasMoney,
  firstProblem,
  liveFees,
  planCovering,
  rebalanceInstallments,
  validatePlan,
  type PlanSource,
} from '../../core/contracts/fee-plan';
import type { FeeStructure, ID, Installment, StudentFee } from '../../core/contracts/models';
import type { FeeRepo } from '../../core/contracts/ports';
import { emit, myStudentIds, requireUser, type Db } from './db';
import { withStatus } from './fee-status';
import { batchRoster } from './batch-summary';
import { fail, round2, todayIso } from './store';

type PlanPorts = Pick<FeeRepo, 'getPlan' | 'savePlan' | 'applyStudentDiscounts' | 'studentStatement'>;

/** The owner, or an admin who was given the fees permission. */
function mayManageFees(db: Db, instituteId: ID): boolean {
  const membership = db.memberships.find(instituteId, { userId: requireUser(db), status: 'active' });
  return membership?.role === 'owner' || (membership?.role === 'admin' && membership.permissions.includes('fees'));
}

function requireFees(db: Db, instituteId: ID): void {
  if (!mayManageFees(db, instituteId)) fail('FORBIDDEN', 'Only the owner can change fee plans');
}

/** A snapshot saved before fee plans existed has none of the plan fields; read them as empty. */
const normal = (s: FeeStructure): FeeStructure => ({
  ...s,
  version: s.version ?? 1,
  supersededById: s.supersededById ?? null,
  batchIds: s.batchIds ?? [],
  schedule: s.schedule ?? [],
  discounts: s.discounts ?? [],
});

export function planSource(db: Db, instituteId: ID): PlanSource {
  return {
    structures: db.feeStructures.all(instituteId).map(normal),
    studentFees: db.studentFees.all(instituteId),
    installments: db.installments.all(instituteId).map((x) => withStatus(x)),
    payments: db.payments.all(instituteId),
  };
}

/** Follows `supersededById` to the version that is live now. */
function liveVersion(structures: FeeStructure[], from: FeeStructure): FeeStructure {
  let cur = from;
  for (let guard = 0; cur.supersededById && guard < 50; guard++) {
    const next = structures.find((s) => s.id === cur.supersededById);
    if (!next) break;
    cur = next;
  }
  return cur;
}

/** Removes a student's unpaid instalments; any online checkout still open on them is closed. */
function dropInstallments(db: Db, instituteId: ID, studentFeeId: ID): void {
  for (const row of db.installments.all(instituteId, { studentFeeId })) {
    if (row.paidAmount > 0) fail('CONFLICT', 'An instalment with a payment cannot be removed');
    for (const order of db.orders.all(instituteId, { installmentId: row.id })) {
      if (order.status === 'created') db.orders.update(instituteId, order.id, { status: 'expired' });
    }
    db.installments.remove(instituteId, row.id);
  }
}

function writeInstallments(db: Db, instituteId: ID, fee: StudentFee, structure: FeeStructure): void {
  const amounts = allocate(fee.netAmount, structure.schedule.map((x) => x.amount));
  structure.schedule.forEach((row, i) => {
    db.installments.insert(instituteId, {
      studentFeeId: fee.id,
      studentId: fee.studentId,
      termNo: i + 1,
      label: row.label,
      amount: amounts[i],
      dueDate: row.dueDate,
      paidAmount: 0,
      paidOn: null,
      status: 'upcoming',
    });
  });
}

function feeBody(structure: FeeStructure, discountIds: string[]) {
  const applied = applyDiscounts(structure.discounts, discountIds, structure.totalAmount);
  return {
    grossAmount: structure.totalAmount,
    discountAmount: applied.amount,
    discountReason: applied.reason,
    discountIds: applied.ids,
    netAmount: round2(structure.totalAmount - applied.amount),
  };
}

export function feePlanMethods(db: Db): PlanPorts {
  return {
    getPlan: async (instituteId, batchId) => {
      requireFees(db, instituteId);
      const batch = db.batches.get(instituteId, batchId);
      const counts = new Map<ID, number>();
      for (const e of db.enrollments.all(instituteId, { status: 'active' })) {
        counts.set(e.batchId, (counts.get(e.batchId) ?? 0) + 1);
      }
      return buildPlanView(
        {
          batchId,
          batchName: batch.name,
          batches: db.batches
            .all(instituteId)
            .filter((b) => b.status !== 'archived')
            .map((b) => ({ id: b.id, name: b.name, studentCount: counts.get(b.id) ?? 0 })),
          roster: batchRoster(db, instituteId, batchId),
          feeAmount: batch.feeAmount ?? 0,
          feeFrequency: batch.feePlan ?? 'term',
          today: todayIso(),
        },
        planSource(db, instituteId),
      );
    },

    savePlan: async (instituteId, input) => {
      requireFees(db, instituteId);
      const problems = validatePlan(input);
      const message = firstProblem(problems);
      if (message) fail('VALIDATION', message);
      if (!input.batchIds.includes(input.batchId)) fail('VALIDATION', 'The plan must apply to the batch it was opened for');
      if (new Set(input.schedule.map((x) => x.id)).size !== input.schedule.length) fail('VALIDATION', 'Duplicate instalment');
      const batchNames = new Map(input.batchIds.map((id) => [id, db.batches.get(instituteId, id).name]));

      const src = planSource(db, instituteId);
      const existing = input.id ? normal(db.feeStructures.get(instituteId, input.id)) : planCovering(src.structures, input.batchId);
      if (existing && !existing.isActive) {
        fail('CONFLICT', `Version ${existing.version} of this plan was replaced. Reopen the plan to edit the latest one.`);
      }
      for (const batchId of input.batchIds) {
        const other = planCovering(src.structures, batchId);
        if (other && other.id !== existing?.id) {
          fail('CONFLICT', `${batchNames.get(batchId)} already uses "${other.name}". Open that plan instead.`);
        }
      }

      const hasPayments = Boolean(
        existing && liveFees(src).some((f) => f.feeStructureId === existing.id && feeHasMoney(f, src)),
      );
      const body = {
        batchId: input.batchId,
        name: input.name?.trim() || existing?.name || `${batchNames.get(input.batchId)} fees`,
        academicYear: existing?.academicYear ?? db.institutes.get(instituteId, instituteId).settings.academicYear ?? '2026-27',
        totalAmount: round2(input.totalAmount),
        installmentCount: input.schedule.length,
        frequency: input.frequency,
        components: [],
        lateFeePerDay: existing?.lateFeePerDay ?? 0,
        isActive: true,
        supersededById: null,
        batchIds: input.batchIds,
        schedule: input.schedule.map((x) => ({ ...x, label: x.label.trim(), amount: round2(x.amount) })),
        discounts: input.discounts.map((d) => ({ ...d, label: d.label.trim(), note: d.note.trim() })),
      };

      // Money on the plan means history: the old version stays, linked to its payments.
      let structure: FeeStructure;
      if (existing && hasPayments) {
        structure = db.feeStructures.insert(instituteId, { ...body, version: existing.version + 1 });
        db.feeStructures.update(instituteId, existing.id, { isActive: false, supersededById: structure.id });
      } else if (existing) {
        structure = db.feeStructures.update(instituteId, existing.id, body);
      } else {
        structure = db.feeStructures.insert(instituteId, { ...body, version: 1 });
      }

      const enrolled = new Set(
        db.enrollments.all(instituteId, { status: 'active' }).filter((e) => input.batchIds.includes(e.batchId)).map((e) => e.studentId),
      );
      let studentsUpdated = 0;
      let studentsKept = 0;
      for (const studentId of enrolled) {
        const own = liveFees(src, studentId)
          .filter((f) => f.academicYear === structure.academicYear)
          .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        if (own.some((f) => feeHasMoney(f, src))) {
          studentsKept++;
          continue;
        }
        const carry = own[0]?.discountIds ?? [];
        let reused: StudentFee | null = null;
        for (const fee of own) {
          dropInstallments(db, instituteId, fee.id);
          if (fee.feeStructureId === structure.id) reused = fee;
          else db.studentFees.update(instituteId, fee.id, { status: 'cancelled' });
        }
        const details = feeBody(structure, carry);
        const fee = reused
          ? db.studentFees.update(instituteId, reused.id, { ...details, status: 'active' })
          : db.studentFees.insert(instituteId, {
              studentId,
              feeStructureId: structure.id,
              academicYear: structure.academicYear,
              status: 'active',
              ...details,
            });
        writeInstallments(db, instituteId, fee, structure);
        studentsUpdated++;
      }

      db.auditLogs.insert(instituteId, {
        actorId: requireUser(db),
        actorRole: db.memberships.find(instituteId, { userId: requireUser(db), status: 'active' })?.role ?? null,
        action: 'fee_plan.saved',
        targetType: 'fee_structure',
        targetId: structure.id,
        before: existing ? { version: existing.version, totalAmount: existing.totalAmount } : null,
        after: { version: structure.version, totalAmount: structure.totalAmount, versioned: Boolean(existing && hasPayments) },
        ipAddress: null,
        userAgent: null,
      });
      emit(db, instituteId, 'payments', 'updated', structure.id);
      return {
        structure,
        versioned: Boolean(existing && hasPayments),
        previousId: existing && hasPayments ? existing.id : null,
        studentsUpdated,
        studentsKept,
      };
    },

    applyStudentDiscounts: async (instituteId, { studentId, discountIds }) => {
      requireFees(db, instituteId);
      db.students.get(instituteId, studentId);
      const src = planSource(db, instituteId);
      const fee = liveFees(src, studentId).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
      if (!fee) fail('NOT_FOUND', 'This student has no fee yet. Save the plan first.');
      const plan = liveVersion(src.structures, normal(db.feeStructures.get(instituteId, fee.feeStructureId)));
      const unknown = discountIds.filter((id) => !plan.discounts.some((d) => d.id === id));
      if (unknown.length > 0) fail('VALIDATION', 'That discount is not part of the saved plan');

      const applied = applyDiscounts(plan.discounts, discountIds, fee.grossAmount);
      const netAmount = round2(fee.grossAmount - applied.amount);
      const rows: Installment[] = db.installments.all(instituteId, { studentFeeId: fee.id });
      const next = rebalanceInstallments(rows, netAmount);
      if (!next.ok) fail('VALIDATION', next.reason);
      for (const row of rows) {
        const amount = next.amounts.get(row.id);
        if (amount !== undefined && amount !== row.amount) db.installments.update(instituteId, row.id, { amount });
      }
      // Only this student's fee changes. The batch plan, its total and every payment stay as they were.
      const saved = db.studentFees.update(instituteId, fee.id, {
        discountAmount: applied.amount,
        discountReason: applied.reason,
        discountIds: applied.ids,
        netAmount,
      });
      db.auditLogs.insert(instituteId, {
        actorId: requireUser(db),
        actorRole: db.memberships.find(instituteId, { userId: requireUser(db), status: 'active' })?.role ?? null,
        action: 'student_fee.discount_set',
        targetType: 'student_fee',
        targetId: fee.id,
        before: { discountAmount: fee.discountAmount, netAmount: fee.netAmount },
        after: { discountAmount: saved.discountAmount, netAmount: saved.netAmount, studentId },
        ipAddress: null,
        userAgent: null,
      });
      emit(db, instituteId, 'payments', 'updated', fee.id);
      return saved;
    },

    studentStatement: async (instituteId, studentId) => {
      if (!mayManageFees(db, instituteId) && !myStudentIds(db, instituteId).includes(studentId)) {
        fail('FORBIDDEN', 'You can only see your own fees');
      }
      db.students.get(instituteId, studentId);
      return buildStatement(studentId, planSource(db, instituteId));
    },
  };
}
