import type { Installment } from '../../core/contracts/models';
import { round2, todayIso } from './store';

export const remaining = (x: Installment): number => (x.status === 'waived' ? 0 : round2(x.amount - x.paidAmount));
export const isOverdue = (x: Installment, today = todayIso()): boolean => remaining(x) > 0 && x.dueDate < today;

/** Status is derived from the money and the date, so it never goes stale. */
export function withStatus(x: Installment, today = todayIso()): Installment {
  if (x.status === 'waived') return x;
  let status: Installment['status'] = 'upcoming';
  if (remaining(x) === 0) status = 'paid';
  else if (x.paidAmount > 0) status = 'partial';
  else if (x.dueDate < today) status = 'overdue';
  else if (x.dueDate === today) status = 'due';
  return { ...x, status };
}
