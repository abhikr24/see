import type { Entity, Profile } from '../../core/contracts/models';
import type { Db } from './db';
import { muteTableWrites, setTableWriteListener, type Table } from './store';

const KEY = 'gf.memory.snapshot.v1';

const TABLE_KEYS = [
  'institutes', 'branches', 'memberships', 'invitations', 'staff', 'teachers', 'workloads',
  'students', 'guardians', 'studentMemberships', 'parentLinks', 'batches', 'enrollments',
  'subjects', 'timetables', 'classrooms', 'attendanceSessions', 'attendanceRecords',
  'attendanceCorrections',
  'assignments', 'submissions', 'attachments', 'feedback', 'exams', 'examQuestions',
  'marks', 'results', 'materials', 'bookmarks', 'practiceQuestions', 'quizzes', 'quizAttempts',
  'studyTasks', 'studentGoals', 'feeStructures', 'studentFees', 'installments', 'payments',
  'receipts', 'refunds', 'orders', 'notices', 'notifications', 'conversations', 'doubts',
  'meetings', 'leads', 'followups', 'plans', 'subscriptions', 'usage', 'auditLogs',
  'exportJobs', 'snapshots', 'alerts',
] as const;

type TableKey = (typeof TABLE_KEYS)[number];

/** Tables added after v1 snapshots were first written; a snapshot without them restores as empty. */
const ADDED_LATER = new Set<string>(['attendanceCorrections']);

interface Snapshot {
  v: 1;
  seq: number;
  profiles: [string, Profile][];
  tables: Record<string, unknown[]>;
}

function tableOf(db: Db, key: TableKey): Table<Entity> {
  return db[key] as unknown as Table<Entity>;
}

export function capture(db: Db, stripPhotos = false): string {
  const tables: Record<string, unknown[]> = {};
  for (const key of TABLE_KEYS) {
    const rows = tableOf(db, key).dump();
    if (stripPhotos && key === 'students') {
      for (const row of rows) {
        const photo = (row as unknown as { photoUrl?: string | null }).photoUrl;
        if (typeof photo === 'string' && photo.startsWith('data:')) {
          (row as unknown as { photoUrl: string | null }).photoUrl = null;
        }
      }
    }
    tables[key] = rows;
  }
  const snap: Snapshot = {
    v: 1,
    seq: db.peekSeq(),
    profiles: [...db.profiles.entries()],
    tables,
  };
  return JSON.stringify(snap);
}

export function restore(db: Db, raw: string): boolean {
  let snap: Snapshot;
  try {
    snap = JSON.parse(raw) as Snapshot;
  } catch {
    return false;
  }
  if (snap.v !== 1 || !snap.tables || !Array.isArray(snap.profiles)) return false;
  try {
    muteTableWrites(() => {
      for (const key of TABLE_KEYS) {
        const rows = snap.tables[key];
        if (!Array.isArray(rows) && !ADDED_LATER.has(key)) throw new Error('incomplete snapshot');
        tableOf(db, key).hydrate(Array.isArray(rows) ? (rows as Entity[]) : []);
      }
      db.profiles.clear();
      for (const [id, profile] of snap.profiles) db.profiles.set(id, profile);
      db.setSeq(snap.seq ?? 0);
    });
    return true;
  } catch {
    return false;
  }
}

export function readLocal(): string | null {
  try {
    if (typeof localStorage === 'undefined') return null;
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function writeLocal(raw: string): void {
  try {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(KEY, raw);
  } catch {
    /* quota — caller may retry a slimmer snapshot */
  }
}

export function saveSnapshot(db: Db): void {
  const raw = capture(db);
  try {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(KEY, raw);
  } catch {
    writeLocal(capture(db, true));
  }
}

export function bindAutosave(db: Db): void {
  setTableWriteListener(() => saveSnapshot(db));
  if (typeof window !== 'undefined') {
    window.addEventListener('pagehide', () => saveSnapshot(db));
  }
}
