import type { ID, LeadFollowup, LeadSource, LeadStage } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { addDays } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INST = sid(1);
const OWNER = sid(2);
const TEACHER = sid(3);
const BRANCH = sid(8);

interface SeedLeadSpec {
  id: number;
  studentName: string;
  guardianName: string;
  phone: string;
  classInterested: string;
  subjectInterest: string;
  source: LeadSource;
  stage: LeadStage;
  assignedTo: ID;
  createdDaysAgo: number;
  nextActionOffsetDays: number | null;
  nextFollowupNote: string | null;
  lostReason: string | null;
  notes: string | null;
  followup?: { id: number; channel: LeadFollowup['channel']; summary: string; outcome: LeadFollowup['outcome']; hours: number; doneBy: ID };
}

/** Eight leads matching supabase/seed.sql (ids 71–78), one per pipeline stage. */
const LEADS: SeedLeadSpec[] = [
  {
    id: 71, studentName: 'Aryan Sinha', guardianName: 'Pankaj Sinha', phone: '9000000071',
    classInterested: '10', subjectInterest: 'Science', source: 'google', stage: 'new', assignedTo: OWNER,
    createdDaysAgo: 0, nextActionOffsetDays: 1, nextFollowupNote: 'Call parent to explain Class 10 batch timings',
    lostReason: null, notes: 'Enquired through Google search.',
  },
  {
    id: 72, studentName: 'Bhavya Kumari', guardianName: 'Ramesh Prasad', phone: '9000000072',
    classInterested: '9', subjectInterest: 'Mathematics', source: 'referral', stage: 'contacted', assignedTo: OWNER,
    createdDaysAgo: 3, nextActionOffsetDays: -1, nextFollowupNote: 'Follow up with father on evening slot preference',
    lostReason: null, notes: 'Spoke to the father; asked to call back in the evening.',
    followup: { id: 12072, channel: 'call', summary: 'Spoke to father Ramesh; interested in Maths foundation batch.', outcome: 'callback', hours: 2, doneBy: OWNER },
  },
  {
    id: 73, studentName: 'Chirag Anand', guardianName: 'Seema Anand', phone: '9000000073',
    classInterested: '10', subjectInterest: 'Science', source: 'walk_in', stage: 'interested', assignedTo: TEACHER,
    createdDaysAgo: 4, nextActionOffsetDays: 2, nextFollowupNote: 'Confirm Saturday Physics demo attendance',
    lostReason: null, notes: 'Wants the Science and Maths combination.',
    followup: { id: 12073, channel: 'visit', summary: 'Visited Boring Road centre with mother; liked Room 1 setup.', outcome: 'interested', hours: 1, doneBy: OWNER },
  },
  {
    id: 74, studentName: 'Divya Bharti', guardianName: 'Alok Bharti', phone: '9000000074',
    classInterested: '10', subjectInterest: 'Mathematics', source: 'instagram', stage: 'demo_scheduled', assignedTo: TEACHER,
    createdDaysAgo: 5, nextActionOffsetDays: 1, nextFollowupNote: 'Maths demo at 4:00 PM with Rohit Verma',
    lostReason: null, notes: 'Demo class booked for Maths.',
    followup: { id: 12074, channel: 'whatsapp', summary: 'Shared Class 10 timetable and booked demo class for tomorrow.', outcome: 'demo_booked', hours: 3, doneBy: OWNER },
  },
  {
    id: 75, studentName: 'Eshan Ali', guardianName: 'Shabnam Ali', phone: '9000000075',
    classInterested: '9', subjectInterest: 'Physics', source: 'other', stage: 'demo_attended', assignedTo: OWNER,
    createdDaysAgo: 6, nextActionOffsetDays: 1, nextFollowupNote: 'Share fee structure and admission form',
    lostReason: null, notes: 'Attended the Physics demo and liked it.',
    followup: { id: 12075, channel: 'visit', summary: 'Attended Physics trial session; positive feedback from student.', outcome: 'interested', hours: 4, doneBy: TEACHER },
  },
  {
    id: 76, studentName: 'Garima Singh', guardianName: 'Vinod Singh', phone: '9000000076',
    classInterested: '10', subjectInterest: 'Science', source: 'referral', stage: 'negotiation', assignedTo: OWNER,
    createdDaysAgo: 7, nextActionOffsetDays: 0, nextFollowupNote: 'Confirm sibling discount approval',
    lostReason: null, notes: 'Asked for a sibling discount.',
    followup: { id: 12076, channel: 'call', summary: 'Discussed Term 1 fee and sibling concession.', outcome: 'callback', hours: 2, doneBy: OWNER },
  },
  {
    id: 77, studentName: 'Himanshu Ranjan', guardianName: 'Nidhi Ranjan', phone: '9000000077',
    classInterested: '9', subjectInterest: 'Science', source: 'walk_in', stage: 'enrolled', assignedTo: OWNER,
    createdDaysAgo: 9, nextActionOffsetDays: null, nextFollowupNote: null,
    lostReason: null, notes: 'Admission form and Term 1 fee received.',
    followup: { id: 12077, channel: 'visit', summary: 'Completed enrolment formalities with mother.', outcome: 'enrolled', hours: 2, doneBy: OWNER },
  },
  {
    id: 78, studentName: 'Juhi Sahay', guardianName: 'Mukesh Sahay', phone: '9000000078',
    classInterested: '10', subjectInterest: 'Science', source: 'other', stage: 'lost', assignedTo: OWNER,
    createdDaysAgo: 10, nextActionOffsetDays: null, nextFollowupNote: null,
    lostReason: 'Joined an institute closer to home.', notes: null,
    followup: { id: 12078, channel: 'call', summary: 'Father informed they chose a centre closer to Kankarbagh.', outcome: 'not_interested', hours: 5, doneBy: OWNER },
  },
];

export function seedAdmissions(db: Db, today: string): void {
  for (const spec of LEADS) {
    const createdAt = `${addDays(today, -spec.createdDaysAgo)}T09:00:00.000Z`;
    const nextFollowupAt =
      spec.nextActionOffsetDays !== null ? `${addDays(today, spec.nextActionOffsetDays)}T12:00:00.000Z` : null;

    db.leads.put({
      ...D.lead(), id: sid(spec.id), instituteId: INST, branchId: BRANCH,
      studentName: spec.studentName, guardianName: spec.guardianName, phone: spec.phone,
      classInterested: spec.classInterested, subjectInterest: spec.subjectInterest,
      source: spec.source, stage: spec.stage, assignedTo: spec.assignedTo, expectedFee: 1500,
      nextFollowupAt, nextFollowupNote: spec.nextFollowupNote, lostReason: spec.lostReason,
      notes: spec.notes, createdAt, updatedAt: createdAt,
    });

    db.auditLogs.put({
      ...D.auditLog(), id: sid(13000 + spec.id), instituteId: INST,
      actorId: spec.assignedTo, actorRole: spec.assignedTo === OWNER ? 'owner' : 'teacher',
      action: 'lead.created', targetType: 'admission_lead', targetId: sid(spec.id),
      before: null, after: { stage: 'new' }, createdAt, updatedAt: createdAt,
    });

    if (spec.followup) {
      const followupAt = new Date(new Date(createdAt).getTime() + spec.followup.hours * 3600000).toISOString();
      db.followups.put({
        ...D.followup(), id: sid(spec.followup.id), instituteId: INST, leadId: sid(spec.id),
        channel: spec.followup.channel, summary: spec.followup.summary, outcome: spec.followup.outcome,
        followupAt, nextFollowupAt, doneBy: spec.followup.doneBy, createdAt: followupAt, updatedAt: followupAt,
      });

      if (spec.stage !== 'new') {
        db.auditLogs.put({
          ...D.auditLog(), id: sid(13100 + spec.id), instituteId: INST,
          actorId: spec.followup.doneBy, actorRole: spec.followup.doneBy === OWNER ? 'owner' : 'teacher',
          action: spec.stage === 'enrolled' ? 'lead.converted' : 'lead.stage_changed',
          targetType: 'admission_lead', targetId: sid(spec.id),
          before: { stage: 'new' }, after: { stage: spec.stage, lostReason: spec.lostReason },
          createdAt: followupAt, updatedAt: followupAt,
        });
      }
    }
  }
}
