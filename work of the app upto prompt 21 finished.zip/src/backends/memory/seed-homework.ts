import type { ID } from '../../core/contracts/models';
import type { Db } from './db';
import * as D from './defaults';
import { addDays, nowIso, todayIso } from './store';

const sid = (n: number): ID => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const INSTITUTE = sid(1);

/**
 * Homework for the two batches with a class teacher on the demo logins, so the
 * teacher home has something real to count. Ids: assignments 14001+,
 * submissions 14100+, feedback 14400+.
 *
 * `graded` students handed in and got marks back; `waiting` students handed in
 * and are waiting to be graded. Every student has handed in two of their
 * batch's three sets (67%), so no "homework not handed in" alert opens.
 */
interface HomeworkSpec {
  id: number;
  batch: number;
  teacher: number;
  subject: number;
  title: string;
  instructions: string;
  assignedDaysAgo: number;
  /** Negative = already due, 0 = due today. */
  dueInDays: number;
  maxMarks: number;
  graded: number[];
  waiting: number[];
}

const CLASS_10A = [14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25];
const CLASS_9A = [26, 27, 28, 29, 30, 31, 32, 33, 34, 35];

const HOMEWORK: HomeworkSpec[] = [
  // Class 10-A · Rohit Verma · Mathematics: 12 submissions waiting, 2 sets due today.
  {
    id: 14001, batch: 9, teacher: 3, subject: 44, title: 'Linear equations: Exercise 3.2',
    instructions: 'Questions 1 to 12. Show every step.', assignedDaysAgo: 9, dueInDays: -6, maxMarks: 20,
    graded: CLASS_10A, waiting: [],
  },
  {
    id: 14002, batch: 9, teacher: 3, subject: 44, title: 'Quadratic equations worksheet',
    instructions: 'Solve by factorisation first, then check with the formula.', assignedDaysAgo: 3, dueInDays: 0,
    maxMarks: 25, graded: [], waiting: CLASS_10A,
  },
  {
    id: 14003, batch: 9, teacher: 3, subject: 44, title: 'Trigonometry: Chapter 8 practice set',
    instructions: 'Odd-numbered questions only.', assignedDaysAgo: 1, dueInDays: 0, maxMarks: 20,
    graded: [], waiting: [],
  },
  // Class 9-A · Priya Nair · Physics: 6 submissions waiting, nothing due today.
  {
    id: 14011, batch: 10, teacher: 4, subject: 45, title: 'Motion: numericals set 1',
    instructions: 'Use SI units throughout.', assignedDaysAgo: 8, dueInDays: -4, maxMarks: 20,
    graded: CLASS_9A, waiting: [],
  },
  {
    id: 14012, batch: 10, teacher: 4, subject: 45, title: 'Force and laws of motion: worksheet',
    instructions: 'Draw a free-body diagram for each question.', assignedDaysAgo: 4, dueInDays: -1, maxMarks: 20,
    graded: CLASS_9A.slice(0, 4), waiting: CLASS_9A.slice(4),
  },
  {
    id: 14013, batch: 10, teacher: 4, subject: 45, title: 'Gravitation: reading notes',
    instructions: 'One page of notes on sections 10.1 to 10.3.', assignedDaysAgo: 0, dueInDays: 3, maxMarks: 10,
    graded: [], waiting: [],
  },
];

export function seedHomework(db: Db): void {
  const at = nowIso();
  const today = todayIso();
  const base = (n: number) => ({ id: sid(n), instituteId: INSTITUTE, createdAt: at, updatedAt: at });
  let row = 0;
  for (const spec of HOMEWORK) {
    const dueDate = addDays(today, spec.dueInDays);
    const assignmentId = sid(spec.id);
    db.assignments.put({
      ...D.assignment(), ...base(spec.id), batchId: sid(spec.batch), subjectId: sid(spec.subject),
      teacherId: sid(spec.teacher), title: spec.title, instructions: spec.instructions,
      assignedOn: addDays(today, -spec.assignedDaysAgo), dueAt: `${dueDate}T18:30:00.000Z`,
      maxMarks: spec.maxMarks, status: 'published', createdBy: sid(spec.teacher),
    });
    const handIn = (roll: number, graded: boolean) => {
      row += 1;
      // Handed in the day before it was due, so nothing here is late.
      const submittedAt = `${addDays(dueDate, -1)}T12:00:00.000Z`;
      db.submissions.put({
        ...base(14100 + row), assignmentId, batchId: sid(spec.batch), studentId: sid(roll),
        content: null, submittedAt, status: graded ? 'returned' : 'submitted',
      });
      if (!graded) return;
      const marksAwarded = Math.round(spec.maxMarks * (0.6 + ((roll * 7) % 9) / 24));
      db.feedback.put({
        ...base(14400 + row), submissionId: sid(14100 + row), batchId: sid(spec.batch), studentId: sid(roll),
        teacherId: sid(spec.teacher), marksAwarded, grade: null, comment: null,
        givenBy: sid(spec.teacher), givenAt: `${dueDate}T15:00:00.000Z`,
      });
    };
    spec.graded.forEach((roll) => handIn(roll, true));
    spec.waiting.forEach((roll) => handIn(roll, false));
  }
}

/**
 * Tops up a snapshot saved before homework and batch assignments were seeded:
 * the three seeded batches get their class teacher, and the homework rows are
 * added once. A snapshot that already has them is left alone.
 */
export function ensureHomework(db: Db): void {
  if (!db.institutes.everything().some((institute) => institute.id === INSTITUTE)) return;
  const classTeachers: [number, number][] = [[9, 3], [10, 4], [11, 5]];
  for (const [batch, teacher] of classTeachers) {
    const saved = db.batches.all(INSTITUTE, { id: sid(batch) })[0];
    const exists = db.teachers.all(INSTITUTE, { id: sid(teacher) }).length > 0;
    if (saved && exists && (saved.teacherId === undefined || saved.teacherId === null)) {
      db.batches.put({ ...saved, teacherId: sid(teacher) });
    }
  }
  const hasBatches = db.batches.all(INSTITUTE, { id: sid(9) }).length > 0 && db.batches.all(INSTITUTE, { id: sid(10) }).length > 0;
  if (hasBatches && db.assignments.all(INSTITUTE, { id: sid(14001) }).length === 0) seedHomework(db);
}
