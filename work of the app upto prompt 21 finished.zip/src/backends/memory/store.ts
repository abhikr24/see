import { BackendError, type ErrorCode } from '../../core/contracts/errors';
import type { Draft, Entity, ID, ISODate, ISODateTime } from '../../core/contracts/models';
import { pageSize, type ListQuery, type Page } from '../../core/contracts/query';

export const nowIso = (): ISODateTime => new Date().toISOString();
export const todayIso = (): ISODate => new Date().toISOString().slice(0, 10);

export function addDays(date: ISODate, days: number): ISODate {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export const sum = (values: number[]): number => values.reduce((a, b) => a + b, 0);
export const round1 = (value: number): number => Math.round(value * 10) / 10;
export const round2 = (value: number): number => Math.round(value * 100) / 100;

export function fail(code: ErrorCode, message?: string): never {
  throw new BackendError(code, message);
}

let writeListener: (() => void) | null = null;
let writesMuted = 0;

/** Fired after a row is stored or removed. Persistence hooks this; seed does not. */
export function setTableWriteListener(listener: (() => void) | null): void {
  writeListener = listener;
}

export function muteTableWrites(fn: () => void): void {
  writesMuted += 1;
  try {
    fn();
  } finally {
    writesMuted -= 1;
  }
}

function notifyWrite(): void {
  if (writesMuted === 0) writeListener?.();
}

/** `{ a: null, b: null }` for the given keys – keeps default objects short. */
export function nulls<K extends string>(...keys: K[]): Record<K, null> {
  const out = {} as Record<K, null>;
  for (const key of keys) out[key] = null;
  return out;
}

/** Drops keys whose value is `undefined`, so a partial input never erases a default. */
export function defined<T extends object>(value: T): Partial<T> {
  const out: Partial<T> = {};
  for (const key of Object.keys(value) as (keyof T)[]) {
    if (value[key] !== undefined) out[key] = value[key];
  }
  return out;
}

/** Defaults overlaid with the caller's input; an explicit `undefined` never erases a default. */
export function merge<A extends object, B extends object>(defaults: A, input: B): A & B {
  return { ...defaults, ...defined(input) } as A & B;
}

function matches<T>(row: T, where: Partial<T>): boolean {
  for (const key of Object.keys(where) as (keyof T)[]) {
    const wanted = where[key];
    if (wanted !== undefined && row[key] !== wanted) return false;
  }
  return true;
}

function compare(a: unknown, b: unknown): number {
  if (a === b) return 0;
  if (a === null || a === undefined) return 1; // nulls last
  if (b === null || b === undefined) return -1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  return String(a).localeCompare(String(b));
}

/**
 * One collection of records. Every read and write is scoped to an institute:
 * a row from another institute behaves exactly like a row that does not exist.
 */
export class Table<T extends Entity> {
  private readonly rows = new Map<ID, T>();
  private readonly label: string;
  private readonly nextId: () => ID;

  constructor(label: string, nextId: () => ID) {
    this.label = label;
    this.nextId = nextId;
  }

  /** An institute row is its own tenant. */
  private owner(row: T): ID {
    return (row as { instituteId?: ID }).instituteId ?? row.id;
  }

  /** Rows across all institutes. Only for lookups that are global by nature (join code). */
  everything(): T[] {
    return [...this.rows.values()].map((row) => ({ ...row }));
  }

  all(instituteId: ID, where: Partial<T> = {}): T[] {
    if (!instituteId) fail('VALIDATION', 'instituteId is required');
    return this.everything().filter((row) => this.owner(row) === instituteId && matches(row, where));
  }

  find(instituteId: ID, where: Partial<T>): T | undefined {
    return this.all(instituteId, where)[0];
  }

  /** `where` and `only` are the repo's own restrictions, applied on top of the caller's query. */
  page(instituteId: ID, query: ListQuery<T> = {}, where: Partial<T> = {}, only?: (row: T) => boolean): Page<T> {
    let items = this.all(instituteId, { ...query.where, ...where });
    if (only) items = items.filter(only);
    const search = query.search?.trim().toLowerCase();
    if (search) {
      items = items.filter((row) =>
        Object.values(row).some((value) => typeof value === 'string' && value.toLowerCase().includes(search)),
      );
    }
    if (query.sort) {
      const { field, direction } = query.sort;
      const sign = direction === 'desc' ? -1 : 1;
      items.sort((a, b) => sign * compare(a[field], b[field]));
    }
    const start = Math.max(0, Number(query.cursor ?? 0) || 0);
    const end = start + pageSize(query);
    return {
      items: items.slice(start, end),
      nextCursor: end < items.length ? String(end) : null,
      total: items.length,
    };
  }

  get(instituteId: ID, id: ID): T {
    if (!instituteId) fail('VALIDATION', 'instituteId is required');
    const row = this.rows.get(id);
    if (!row || this.owner(row) !== instituteId) fail('NOT_FOUND', `${this.label} not found`);
    return { ...row };
  }

  /** Stores a complete row as given. Used by the seed and for institutes. */
  put(row: T): T {
    this.rows.set(row.id, { ...row });
    notifyWrite();
    return { ...row };
  }

  dump(): T[] {
    return [...this.rows.values()].map((row) => ({ ...row }));
  }

  /** Replaces every row. Does not notify — used when restoring a snapshot. */
  hydrate(rows: T[]): void {
    this.rows.clear();
    for (const row of rows) this.rows.set(row.id, { ...row });
  }

  insert(instituteId: ID, data: Draft<T>): T {
    if (!instituteId) fail('VALIDATION', 'instituteId is required');
    const at = nowIso();
    return this.put({ ...data, id: this.nextId(), instituteId, createdAt: at, updatedAt: at } as unknown as T);
  }

  update(instituteId: ID, id: ID, patch: Partial<T>): T {
    const current = this.get(instituteId, id);
    const { id: _id, createdAt: _createdAt, ...changes } = defined(patch) as Partial<Entity>;
    return this.put({ ...current, ...changes, updatedAt: nowIso() } as T);
  }

  remove(instituteId: ID, id: ID): void {
    this.get(instituteId, id);
    this.rows.delete(id);
    notifyWrite();
  }
}
