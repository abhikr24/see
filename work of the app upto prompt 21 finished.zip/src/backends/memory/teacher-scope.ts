import type { Batch, ID, Teacher, Timetable } from '../../core/contracts/models';
import type { Db } from './db';
import { fail } from './store';

/**
 * Who a batch belongs to, and what a teacher may see.
 *
 * The one rule: a caller whose active membership is a teacher's sees only the
 * batches whose assigned teacher is their own teacher profile. Every batch
 * read and every batch-scoped attendance call in this backend asks here, so
 * another teacher's batch id is `NOT_FOUND` at the repo, whatever the UI does.
 */

/** A batch with the fields older rows leave blank filled from its first timetable period. */
export interface AssignedBatch {
  subjectId: ID | null;
  teacherId: ID | null;
  first: Timetable | undefined;
}

/**
 * The assigned teacher and subject of a batch. `teacherId` on the batch is the
 * assignment; a row saved before batches carried one falls back to its first
 * period, the same backfill migration 0009 applied to the live table.
 */
export function assignmentOf(db: Db, instituteId: ID, batch: Batch): AssignedBatch {
  const first = db.timetables.all(instituteId, { batchId: batch.id })[0];
  return {
    subjectId: batch.subjectId ?? first?.subjectId ?? null,
    teacherId: batch.teacherId ?? first?.teacherId ?? null,
    first,
  };
}

/** The caller's active membership role in this institute; null when signed out or not a member. */
export function callerRole(db: Db, instituteId: ID) {
  const userId = db.session.userId;
  if (!userId) return null;
  return db.memberships.find(instituteId, { userId, status: 'active' })?.role ?? null;
}

/** The teacher profile linked to the caller's login, if any. */
export function callerTeacher(db: Db, instituteId: ID): Teacher | null {
  const userId = db.session.userId;
  if (!userId) return null;
  return db.teachers.find(instituteId, { userId, status: 'active' }) ?? null;
}

/** Every batch the given teacher profile is the assigned teacher of. */
export function batchesAssignedTo(db: Db, instituteId: ID, teacherId: ID | null): Batch[] {
  if (!teacherId) return [];
  return db.batches.all(instituteId).filter((batch) => assignmentOf(db, instituteId, batch).teacherId === teacherId);
}

/**
 * The batch ids a teacher caller is limited to, or null when no teacher limit
 * applies (owner, admin, student, parent, or no session). A teacher login
 * without a teacher profile is limited to nothing.
 */
export function teacherBatchScope(db: Db, instituteId: ID): Set<ID> | null {
  if (callerRole(db, instituteId) !== 'teacher') return null;
  const teacher = callerTeacher(db, instituteId);
  return new Set(batchesAssignedTo(db, instituteId, teacher?.id ?? null).map((batch) => batch.id));
}

/** `db.batches.get` behind the teacher rule: someone else's batch does not exist for this caller. */
export function visibleBatch(db: Db, instituteId: ID, batchId: ID): Batch {
  const batch = db.batches.get(instituteId, batchId);
  const scope = teacherBatchScope(db, instituteId);
  if (scope && !scope.has(batch.id)) fail('NOT_FOUND', 'Batch not found');
  return batch;
}
