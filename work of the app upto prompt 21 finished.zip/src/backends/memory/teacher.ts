import type { Batch, FallingStudent, ID, TeacherClass, TeacherHome } from '../../core/contracts/models';
import {
  buildTeacherClasses,
  buildTeacherHome,
  findFallingStudents,
  type TeacherRows,
} from '../../core/contracts/teacher';
import { requireUser, type Db } from './db';
import { fail, todayIso } from './store';
import { assignmentOf, batchesAssignedTo, callerRole, callerTeacher } from './teacher-scope';

const clock = (at = new Date()): string =>
  `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;

/** The signed-in teacher's own batches, with the assignment fallback already applied. */
function ownBatches(db: Db, instituteId: ID): { teacherId: ID | null; batches: Batch[] } {
  requireUser(db);
  if (callerRole(db, instituteId) !== 'teacher') fail('FORBIDDEN', 'Only a teacher has classes of their own');
  const teacherId = callerTeacher(db, instituteId)?.id ?? null;
  const batches = batchesAssignedTo(db, instituteId, teacherId).map((batch) => {
    const { subjectId, teacherId: assigned } = assignmentOf(db, instituteId, batch);
    return { ...batch, subjectId, teacherId: assigned };
  });
  return { teacherId, batches };
}

/** Every row the builders need, read batch by batch so nothing outside the scope is ever loaded. */
function rowsOf(db: Db, instituteId: ID, batches: Batch[]): TeacherRows {
  const each = <T>(read: (batchId: ID) => T[]): T[] => batches.flatMap((batch) => read(batch.id));
  const assignments = each((batchId) => db.assignments.all(instituteId, { batchId }));
  return {
    batches,
    periods: each((batchId) => db.timetables.all(instituteId, { batchId })),
    subjects: db.subjects.all(instituteId),
    classrooms: db.classrooms.all(instituteId),
    enrollments: each((batchId) => db.enrollments.all(instituteId, { batchId, status: 'active' })),
    sessions: each((batchId) => db.attendanceSessions.all(instituteId, { batchId })),
    records: each((batchId) => db.attendanceRecords.all(instituteId, { batchId })),
    assignments,
    submissions: assignments.flatMap((a) => db.submissions.all(instituteId, { assignmentId: a.id })),
  };
}

/** BatchRepo.listMyClasses */
export function teacherClasses(db: Db, instituteId: ID): TeacherClass[] {
  const { batches } = ownBatches(db, instituteId);
  return buildTeacherClasses(rowsOf(db, instituteId, batches));
}

/** AnalyticsRepo.teacherHome */
export function teacherHome(db: Db, instituteId: ID): TeacherHome {
  const institute = db.institutes.get(instituteId, instituteId);
  const { teacherId, batches } = ownBatches(db, instituteId);
  return buildTeacherHome({
    ...rowsOf(db, instituteId, batches),
    today: todayIso(),
    now: clock(),
    teacherId,
    perPeriod: institute.settings.attendanceMode === 'period',
  });
}

/** ProgressPort.listFallingStudents */
export function fallingStudents(db: Db, instituteId: ID): FallingStudent[] {
  requireUser(db);
  const role = callerRole(db, instituteId);
  let batches: Batch[];
  if (role === 'teacher') batches = ownBatches(db, instituteId).batches;
  else if (role === 'owner' || role === 'admin') batches = db.batches.all(instituteId);
  else fail('FORBIDDEN', 'Student alerts are for teaching staff');

  const each = <T>(read: (batchId: ID) => T[]): T[] => batches.flatMap((batch) => read(batch.id));
  const enrollments = each((batchId) => db.enrollments.all(instituteId, { batchId, status: 'active' }));
  return findFallingStudents({
    batches,
    enrollments,
    students: [...new Set(enrollments.map((e) => e.studentId))].map((id) => db.students.get(instituteId, id)),
    sessions: each((batchId) => db.attendanceSessions.all(instituteId, { batchId })),
    records: each((batchId) => db.attendanceRecords.all(instituteId, { batchId })),
    exams: each((batchId) => db.exams.all(instituteId, { batchId, status: 'published' })),
    results: each((batchId) => db.results.all(instituteId, { batchId })),
  });
}
