import { BackendError } from '../core/contracts/errors';
import { PORTS, PORT_KEYS, type Backend } from '../core/contracts/ports';

/**
 * A backend where every method of every port rejects with NOT_IMPLEMENTED.
 *
 * Start a new adapter from this: spread it, then replace one port at a time
 * and watch /dev/contract-check turn green.
 *
 *   export const myBackend: Backend = { ...createStubBackend('mine'), students: myStudentRepo };
 */
export function createStubBackend(name = 'stub'): Backend {
  const port = (portName: string) =>
    new Proxy(
      {},
      {
        get: (_target, method) => async () => {
          throw new BackendError('NOT_IMPLEMENTED', `${portName}.${String(method)} is not implemented in "${name}"`);
        },
      },
    );
  const ports = Object.fromEntries(PORT_KEYS.map((key) => [key, port(PORTS[key])]));
  return { name, ...ports } as unknown as Backend;
}
