import React, { useRef, useEffect } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { Avatar, Text } from '@/components/ui';
import type { BatchRosterRow } from '@/core/contracts/models';
import { C, R } from '@/lib/theme';

interface DraftRow {
  marks: string;
  absent: boolean;
}

interface MarksRowProps {
  student: BatchRosterRow;
  draft: DraftRow;
  maxMarks: number;
  isActive: boolean;
  onFocus: () => void;
  onChange: (draft: DraftRow) => void;
  onSubmit: () => void;
  isLast: boolean;
}

export function MarksRow({
  student,
  draft,
  maxMarks,
  isActive,
  onFocus,
  onChange,
  onSubmit,
  isLast,
}: MarksRowProps) {
  const inputRef = useRef<TextInput>(null);

  useEffect(() => {
    if (isActive) {
      inputRef.current?.focus();
    }
  }, [isActive]);

  const parsed = Number(draft.marks);
  const isInvalid = !draft.absent && draft.marks.trim() !== '' && (Number.isNaN(parsed) || parsed < 0 || parsed > maxMarks);

  return (
    <Pressable
      onPress={onFocus}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        height: 56,
        borderBottomWidth: isLast ? 0 : 1,
        borderBottomColor: C.hairline,
        backgroundColor: isActive ? C.surface : 'transparent',
      }}
    >
      {isActive && (
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            top: -2,
            bottom: -2,
            left: -8,
            right: -8,
            borderWidth: 2,
            borderColor: C.primary,
            borderRadius: 8,
          }}
        />
      )}
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Avatar name={student.fullName} uri={student.photoUrl} size={36} />
        <View style={{ flex: 1 }}>
          <Text variant="body" weight={600} numberOfLines={1} style={{ fontSize: 15 }}>
            {student.fullName}
          </Text>
        </View>
      </View>

      <TextInput
        ref={inputRef}
        value={draft.absent ? 'AB' : draft.marks}
        onChangeText={(v) => {
          if (draft.absent) return;
          const cleaned = v.replace(/[^0-9]/g, '');
          onChange({ ...draft, marks: cleaned });
        }}
        onFocus={onFocus}
        onSubmitEditing={onSubmit}
        keyboardType="numeric"
        returnKeyType="next"
        editable={!draft.absent}
        style={{
          width: 72,
          height: 44,
          borderRadius: 12,
          backgroundColor: '#F5F6FA',
          textAlign: 'center',
          fontSize: 20,
          fontWeight: '600',
          fontVariant: ['tabular-nums'],
          color: draft.absent ? C.muted : C.ink,
          borderWidth: isInvalid ? 1 : 0,
          borderColor: isInvalid ? C.danger : 'transparent',
        }}
      />
    </Pressable>
  );
}
