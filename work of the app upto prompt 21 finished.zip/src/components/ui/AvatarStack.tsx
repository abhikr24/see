import React from 'react';
import { View } from 'react-native';
import { C, R, S } from '@/lib/theme';
import { Avatar } from './Bits';
import { Text } from './Text';

export interface AvatarStackUser {
  name: string;
  uri?: string | null;
}

export interface AvatarStackProps {
  users: readonly AvatarStackUser[];
  max?: number;
  totalCount?: number;
  size?: number;
  overlap?: number;
  label?: string;
  className?: string;
}

/**
 * AvatarStack — overlapping circles with a +N chip.
 */
export function AvatarStack({
  users,
  max = 4,
  totalCount,
  size = 36,
  overlap = 10,
  label,
  className,
}: AvatarStackProps) {
  const visible = users.slice(0, max);
  const total = totalCount !== undefined ? Math.max(totalCount, users.length) : users.length;
  const remaining = Math.max(0, total - visible.length);
  const outerSize = size + 4;

  return (
    <View
      className={className}
      style={{ flexDirection: 'row', alignItems: 'center', gap: S.sm }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        {visible.map((u, idx) => (
          <View
            key={`${u.name}-${idx}`}
            style={{
              width: outerSize,
              height: outerSize,
              borderRadius: outerSize / 2,
              backgroundColor: C.surface,
              alignItems: 'center',
              justifyContent: 'center',
              marginLeft: idx === 0 ? 0 : -overlap,
            }}
          >
            <Avatar name={u.name} uri={u.uri} size={size} />
          </View>
        ))}

        {remaining > 0 ? (
          <View
            style={{
              height: outerSize,
              minWidth: outerSize,
              paddingHorizontal: 8,
              borderRadius: R.chip,
              backgroundColor: C.primary,
              borderWidth: 2,
              borderColor: C.surface,
              alignItems: 'center',
              justifyContent: 'center',
              marginLeft: visible.length > 0 ? -overlap : 0,
            }}
          >
            <Text
              variant="label"
              weight={700}
              c={C.surface}
              tabular
              style={{ fontSize: Math.max(10, Math.round(size * 0.3)) }}
            >
              +{remaining}
            </Text>
          </View>
        ) : null}
      </View>

      {label ? (
        <Text variant="caption" c={C.secondary}>
          {label}
        </Text>
      ) : null}
    </View>
  );
}
