import React, { useState } from 'react';
import { View, type LayoutChangeEvent } from 'react-native';
import { BarChart as GiftedBarChart, type barDataItem } from 'react-native-gifted-charts';
import { C, R, S } from '@/lib/theme';
import { Text } from './Text';

export interface BarDatum {
  value: number;
  label: string;
  highlight?: boolean;
}

export interface BarChartProps {
  data: readonly BarDatum[];
  /** Index of the bar highlighted in saffron (defaults to the item with highlight:true or the max bar) */
  highlightIndex?: number;
  title?: string;
  subtitle?: string;
  headlineValue?: string;
  height?: number;
  barWidth?: number;
  baseTone?: 'primary' | 'soft';
  className?: string;
}

/**
 * BarChart — thin vertical bars, one highlighted in saffron.
 * Powered by react-native-gifted-charts (flat, no shadows, no 3D).
 */
export function BarChart({
  data,
  highlightIndex,
  title,
  subtitle,
  headlineValue,
  height = 136,
  barWidth = 14,
  baseTone = 'primary',
  className,
}: BarChartProps) {
  const [chartWidth, setChartWidth] = useState(280);

  const handleLayout = (e: LayoutChangeEvent) => {
    const nextWidth = Math.max(180, Math.floor(e.nativeEvent.layout.width - 36));
    if (Math.abs(nextWidth - chartWidth) > 4) {
      setChartWidth(nextWidth);
    }
  };

  const resolvedHighlightIndex = (() => {
    if (highlightIndex !== undefined) return highlightIndex;
    const explicit = data.findIndex((d) => d.highlight);
    if (explicit >= 0) return explicit;
    let maxIdx = 0;
    data.forEach((d, idx) => {
      if (d.value > (data[maxIdx]?.value ?? 0)) maxIdx = idx;
    });
    return maxIdx;
  })();

  const defaultBarColor = baseTone === 'soft' ? C.navySoft : C.primary;
  const count = Math.max(1, data.length);
  const spacing = Math.max(
    14,
    Math.floor((chartWidth - count * barWidth - 24) / Math.max(1, count)),
  );

  const barData: barDataItem[] = data.map((item, idx) => {
    const isSpotlight = idx === resolvedHighlightIndex;
    return {
      value: item.value,
      label: item.label,
      frontColor: isSpotlight ? C.accent : defaultBarColor,
      topLabelComponent: isSpotlight
        ? () => (
            <Text
              variant="label"
              weight={700}
              c={C.accent}
              tabular
              style={{ fontSize: 10, marginBottom: 3 }}
            >
              {item.value}
            </Text>
          )
        : undefined,
    };
  });

  return (
    <View
      className={className}
      onLayout={handleLayout}
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: 18,
        gap: S.sm,
      }}
    >
      {title || subtitle || headlineValue ? (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: S.sm,
          }}
        >
          <View style={{ flex: 1, gap: 2 }}>
            {title ? (
              <Text variant="label" c={C.muted}>
                {title}
              </Text>
            ) : null}
            {subtitle ? (
              <Text variant="caption" c={C.secondary}>
                {subtitle}
              </Text>
            ) : null}
          </View>
          {headlineValue ? (
            <Text variant="h2" weight={800} c={C.accent} tabular>
              {headlineValue}
            </Text>
          ) : null}
        </View>
      ) : null}

      <View style={{ paddingTop: S.sm, overflow: 'hidden' }}>
        <GiftedBarChart
          data={barData}
          width={chartWidth}
          height={height}
          barWidth={barWidth}
          spacing={spacing}
          initialSpacing={12}
          barBorderRadius={6}
          hideRules
          hideYAxisText
          yAxisThickness={0}
          xAxisThickness={0}
          isThreeD={false}
          isAnimated={false}
          xAxisLabelTextStyle={{
            color: C.muted,
            fontSize: 11,
            fontWeight: '600',
          }}
        />
      </View>
    </View>
  );
}
