import React from 'react';
import { ActivityIndicator, Pressable, type PressableProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R } from '@/lib/theme';
import { Text } from './Text';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends Omit<PressableProps, 'children'> {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  full?: boolean;
  className?: string;
}

const H: Record<ButtonSize, number> = { sm: 40, md: 48, lg: 56 };
const FS: Record<ButtonSize, number> = { sm: 13, md: 15, lg: 16 };

export function Button({
  title,
  variant = 'primary',
  size = 'lg',
  loading,
  icon,
  full = true,
  disabled,
  className,
  ...rest
}: ButtonProps) {
  const bg =
    variant === 'primary'
      ? C.primary
      : variant === 'danger'
        ? C.danger
        : variant === 'secondary'
          ? C.accentSoft
          : C.transparent;
  const border = variant === 'outline' ? C.hairline : C.transparent;
  const fg =
    variant === 'primary' || variant === 'danger'
      ? C.surface
      : variant === 'secondary'
        ? C.accent
        : C.primary;

  return (
    <Pressable
      {...rest}
      accessibilityRole="button"
      disabled={disabled || loading}
      className={className}
      style={({ pressed }) => [
        {
          height: H[size],
          borderRadius: R.btn,
          backgroundColor: bg,
          borderWidth: variant === 'outline' ? 1 : 0,
          borderColor: border,
          opacity: disabled ? 0.45 : pressed ? 0.9 : 1,
          alignSelf: full ? 'stretch' : 'flex-start',
          paddingHorizontal: full ? 20 : 18,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} size="small" />
      ) : icon ? (
        <Ionicons name={icon} size={FS[size] + 3} color={fg} />
      ) : null}
      <Text variant="body" weight={600} c={fg} style={{ fontSize: FS[size] }}>
        {title}
      </Text>
    </Pressable>
  );
}
