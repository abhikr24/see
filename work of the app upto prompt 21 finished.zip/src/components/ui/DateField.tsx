import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { Calendar, type DateData } from 'react-native-calendars';
import { Ionicons } from '@expo/vector-icons';
import { C, R, S } from '@/lib/theme';
import { dmyToISO, isoToDMY, todayISO } from '@/lib/format';
import { Button } from './Button';
import { Sheet } from './Sheet';
import { Text } from './Text';

export interface DateFieldProps {
  label?: string;
  /** Value in DD/MM/YYYY or YYYY-MM-DD */
  value?: string;
  onChange: (ddmmyyyy: string, isoDate: string) => void;
  placeholder?: string;
  error?: string;
  hint?: string;
  minDate?: string;
  maxDate?: string;
  disabled?: boolean;
  className?: string;
}

/**
 * DateField — DD/MM/YYYY picker with a calendar sheet.
 */
export function DateField({
  label,
  value,
  onChange,
  placeholder = 'DD/MM/YYYY',
  error,
  hint,
  minDate,
  maxDate,
  disabled = false,
  className,
}: DateFieldProps) {
  const [open, setOpen] = useState(false);

  const currentISO = useMemo(() => {
    if (!value) return todayISO();
    const iso = dmyToISO(value);
    return /^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso : todayISO();
  }, [value]);

  const [draftISO, setDraftISO] = useState(currentISO);

  const displayDMY = value ? isoToDMY(value) : '';

  const openSheet = () => {
    if (disabled) return;
    setDraftISO(currentISO);
    setOpen(true);
  };

  const confirmDate = (iso: string) => {
    const dmy = isoToDMY(iso);
    onChange(dmy, iso);
    setOpen(false);
  };

  return (
    <View className={className} style={{ gap: 6 }}>
      {label ? (
        <Text variant="label" c={C.secondary}>
          {label}
        </Text>
      ) : null}

      <Pressable
        accessibilityRole="button"
        accessibilityLabel={label ? `${label}, ${displayDMY || placeholder}` : placeholder}
        disabled={disabled}
        onPress={openSheet}
        style={({ pressed }) => ({
          height: 56,
          paddingHorizontal: 18,
          borderRadius: R.field,
          backgroundColor: C.surface,
          borderWidth: open ? 2 : 1,
          borderColor: error ? C.danger : open ? C.primary : C.hairline,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: S.sm,
          opacity: disabled ? 0.5 : pressed ? 0.9 : 1,
        })}
      >
        <Text
          variant="body"
          tabular
          c={displayDMY ? C.ink : C.muted}
          style={{ fontSize: 15 }}
        >
          {displayDMY || placeholder}
        </Text>
        <Ionicons name="calendar-outline" size={19} color={error ? C.danger : C.primary} />
      </Pressable>

      {error ? (
        <Text variant="caption" c={C.danger}>
          {error}
        </Text>
      ) : hint ? (
        <Text variant="caption" c={C.muted}>
          {hint}
        </Text>
      ) : null}

      <Sheet
        visible={open}
        onClose={() => setOpen(false)}
        title={label ?? 'Select date'}
        subtitle={`Selected: ${isoToDMY(draftISO)}`}
        snapPoints={['72%', '88%']}
      >
        <View
          style={{
            borderRadius: R.card,
            borderWidth: 1,
            borderColor: C.hairline,
            overflow: 'hidden',
            marginBottom: S.lg,
          }}
        >
          <Calendar
            current={draftISO}
            minDate={minDate ? dmyToISO(minDate) : undefined}
            maxDate={maxDate ? dmyToISO(maxDate) : undefined}
            onDayPress={(day: DateData) => setDraftISO(day.dateString)}
            markedDates={{
              [draftISO]: {
                selected: true,
                selectedColor: C.primary,
                selectedTextColor: C.surface,
              },
            }}
            theme={{
              backgroundColor: C.surface,
              calendarBackground: C.surface,
              textSectionTitleColor: C.muted,
              selectedDayBackgroundColor: C.primary,
              selectedDayTextColor: C.surface,
              todayTextColor: C.accent,
              dayTextColor: C.ink,
              textDisabledColor: C.muted,
              arrowColor: C.primary,
              monthTextColor: C.ink,
              textDayFontWeight: '600',
              textMonthFontWeight: '700',
              textDayHeaderFontWeight: '600',
            }}
          />
        </View>

        <View style={{ flexDirection: 'row', gap: S.sm }}>
          <View style={{ flex: 1 }}>
            <Button
              title="Today"
              variant="outline"
              size="md"
              onPress={() => {
                const t = todayISO();
                setDraftISO(t);
                confirmDate(t);
              }}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Button
              title={`Confirm ${isoToDMY(draftISO)}`}
              variant="primary"
              size="md"
              onPress={() => confirmDate(draftISO)}
            />
          </View>
        </View>
      </Sheet>
    </View>
  );
}
