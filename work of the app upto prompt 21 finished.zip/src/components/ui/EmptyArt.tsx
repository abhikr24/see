import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, TONE, type Tone } from '@/lib/theme';

export interface EmptyArtProps {
  icon?: keyof typeof Ionicons.glyphMap;
  tone?: Tone;
  size?: number;
  badgeIcon?: keyof typeof Ionicons.glyphMap;
  className?: string;
}

/** Soft tinted circle + icon, used by EmptyState and zero-data screens. */
export function EmptyArt({
  icon = 'file-tray-outline',
  tone = 'primary',
  size = 88,
  badgeIcon,
  className,
}: EmptyArtProps) {
  const palette = TONE[tone];
  const innerSize = Math.round(size * 0.72);
  const badgeSize = Math.round(size * 0.32);

  return (
    <View
      className={className}
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: palette.bg,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <View
        style={{
          width: innerSize,
          height: innerSize,
          borderRadius: innerSize / 2,
          backgroundColor: C.surface,
          borderWidth: 1,
          borderColor: C.hairline,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name={icon} size={Math.round(size * 0.4)} color={palette.fg} />
      </View>
      {badgeIcon ? (
        <View
          style={{
            position: 'absolute',
            right: 0,
            bottom: 0,
            width: badgeSize,
            height: badgeSize,
            borderRadius: badgeSize / 2,
            backgroundColor: palette.fg,
            borderWidth: 2,
            borderColor: C.surface,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name={badgeIcon} size={Math.round(badgeSize * 0.54)} color={C.surface} />
        </View>
      ) : null}
    </View>
  );
}
