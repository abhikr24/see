import React from 'react';
import { Pressable, View } from 'react-native';
import { C, R, S } from '@/lib/theme';
import { Text } from './Text';

export type HeatmapStatus = 'present' | 'late' | 'absent' | 'holiday' | 'none';

export interface HeatmapDay {
  day: number;
  status?: HeatmapStatus;
  /** Optional 0–4 activity/score intensity level */
  intensity?: 0 | 1 | 2 | 3 | 4;
}

export interface HeatmapLegendItem {
  label: string;
  color: string;
}

export interface HeatmapProps {
  monthLabel?: string;
  subtitle?: string;
  days: readonly HeatmapDay[];
  /** Weekday offset (0 = Mon ... 6 = Sun) before day 1 */
  startOffset?: number;
  variant?: 'attendance' | 'intensity';
  legend?: readonly HeatmapLegendItem[];
  onDayPress?: (day: HeatmapDay) => void;
  className?: string;
}

const WEEKDAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'] as const;

const ATTENDANCE_COLOR: Record<HeatmapStatus, { bg: string; fg: string }> = {
  present: { bg: C.teal, fg: C.surface },
  late: { bg: C.warning, fg: C.surface },
  absent: { bg: C.danger, fg: C.surface },
  holiday: { bg: C.navySoft, fg: C.primary },
  none: { bg: C.track, fg: C.muted },
};

const INTENSITY_COLOR: Record<0 | 1 | 2 | 3 | 4, { bg: string; fg: string }> = {
  0: { bg: C.track, fg: C.muted },
  1: { bg: C.navySoft, fg: C.primary },
  2: { bg: C.navyMid, fg: C.primary },
  3: { bg: C.primary, fg: C.surface },
  4: { bg: C.accent, fg: C.surface },
};

const DEFAULT_ATTENDANCE_LEGEND: readonly HeatmapLegendItem[] = [
  { label: 'Present', color: C.teal },
  { label: 'Late', color: C.warning },
  { label: 'Absent', color: C.danger },
  { label: 'Holiday', color: C.navySoft },
];

const DEFAULT_INTENSITY_LEGEND: readonly HeatmapLegendItem[] = [
  { label: 'Rest', color: C.track },
  { label: 'Light', color: C.navySoft },
  { label: 'Steady', color: C.navyMid },
  { label: 'High', color: C.primary },
  { label: 'Peak', color: C.accent },
];

/**
 * Heatmap — 7-column month grid of rounded squares, legend.
 */
export function Heatmap({
  monthLabel,
  subtitle,
  days,
  startOffset = 0,
  variant = 'attendance',
  legend,
  onDayPress,
  className,
}: HeatmapProps) {
  const safeOffset = Math.max(0, Math.min(6, startOffset));
  const cells: (HeatmapDay | null)[] = [
    ...Array.from({ length: safeOffset }, () => null),
    ...days,
  ];
  while (cells.length % 7 !== 0) {
    cells.push(null);
  }

  const weeks: (HeatmapDay | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) {
    weeks.push(cells.slice(i, i + 7));
  }

  const legendItems =
    legend ?? (variant === 'intensity' ? DEFAULT_INTENSITY_LEGEND : DEFAULT_ATTENDANCE_LEGEND);

  return (
    <View
      className={className}
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: 18,
        gap: S.md,
      }}
    >
      {monthLabel || subtitle ? (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          {monthLabel ? <Text variant="title">{monthLabel}</Text> : <View />}
          {subtitle ? (
            <Text variant="caption" c={C.secondary} tabular>
              {subtitle}
            </Text>
          ) : null}
        </View>
      ) : null}

      {/* 7-column weekday header */}
      <View style={{ flexDirection: 'row', gap: 6 }}>
        {WEEKDAYS.map((wd, i) => (
          <View key={`${wd}-${i}`} style={{ flex: 1, alignItems: 'center' }}>
            <Text variant="label" c={C.muted}>
              {wd}
            </Text>
          </View>
        ))}
      </View>

      {/* 7-column month grid of rounded squares */}
      <View style={{ gap: 6 }}>
        {weeks.map((week, wIdx) => (
          <View key={`week-${wIdx}`} style={{ flexDirection: 'row', gap: 6 }}>
            {week.map((cell, cIdx) => {
              if (!cell) {
                return (
                  <View
                    key={`empty-${wIdx}-${cIdx}`}
                    style={{
                      flex: 1,
                      height: 36,
                      borderRadius: R.cell,
                      backgroundColor: C.transparent,
                    }}
                  />
                );
              }

              const palette =
                variant === 'intensity'
                  ? INTENSITY_COLOR[cell.intensity ?? 0]
                  : ATTENDANCE_COLOR[cell.status ?? 'none'];

              const square = (
                <View
                  style={{
                    height: 36,
                    borderRadius: R.cell,
                    backgroundColor: palette.bg,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Text
                    variant="caption"
                    weight={700}
                    c={palette.fg}
                    tabular
                    style={{ fontSize: 12 }}
                  >
                    {cell.day}
                  </Text>
                </View>
              );

              if (!onDayPress) {
                return (
                  <View key={`day-${cell.day}`} style={{ flex: 1 }}>
                    {square}
                  </View>
                );
              }

              return (
                <Pressable
                  key={`day-${cell.day}`}
                  accessibilityRole="button"
                  onPress={() => onDayPress(cell)}
                  style={({ pressed }) => ({ flex: 1, opacity: pressed ? 0.8 : 1 })}
                >
                  {square}
                </Pressable>
              );
            })}
          </View>
        ))}
      </View>

      {/* Legend */}
      <View
        style={{
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignItems: 'center',
          gap: S.md,
          paddingTop: S.xs,
          borderTopWidth: 1,
          borderTopColor: C.hairline,
        }}
      >
        {legendItems.map((item) => (
          <View
            key={item.label}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}
          >
            <View
              style={{
                width: 12,
                height: 12,
                borderRadius: 4,
                backgroundColor: item.color,
              }}
            />
            <Text variant="caption" c={C.secondary} style={{ fontSize: 12 }}>
              {item.label}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}
