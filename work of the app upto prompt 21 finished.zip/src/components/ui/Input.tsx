import React, { useState } from 'react';
import { Pressable, TextInput, View, type TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R } from '@/lib/theme';
import { Text } from './Text';

export interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  hint?: string;
  icon?: keyof typeof Ionicons.glyphMap;
  secure?: boolean;
  className?: string;
}

export function Input({
  label,
  error,
  hint,
  icon,
  secure,
  className,
  style,
  ...rest
}: InputProps) {
  const [hidden, setHidden] = useState(!!secure);
  const [focused, setFocused] = useState(false);

  return (
    <View className={className} style={{ gap: 6 }}>
      {label ? (
        <Text variant="label" c={C.secondary}>
          {label}
        </Text>
      ) : null}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
          height: 56,
          paddingHorizontal: 18,
          borderRadius: R.field,
          backgroundColor: C.surface,
          borderWidth: focused ? 2 : 1,
          borderColor: error ? C.danger : focused ? C.primary : C.hairline,
        }}
      >
        {icon ? <Ionicons name={icon} size={19} color={C.muted} /> : null}
        <TextInput
          {...rest}
          secureTextEntry={hidden}
          onFocus={(e) => {
            setFocused(true);
            rest.onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            rest.onBlur?.(e);
          }}
          placeholderTextColor={C.muted}
          style={[{ flex: 1, fontSize: 15, color: C.ink, paddingVertical: 0 }, style]}
        />
        {secure ? (
          <Pressable onPress={() => setHidden((h) => !h)} hitSlop={12}>
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={19} color={C.muted} />
          </Pressable>
        ) : null}
      </View>
      {error ? (
        <Text variant="caption" c={C.danger}>
          {error}
        </Text>
      ) : hint ? (
        <Text variant="caption" c={C.muted}>
          {hint}
        </Text>
      ) : null}
    </View>
  );
}
