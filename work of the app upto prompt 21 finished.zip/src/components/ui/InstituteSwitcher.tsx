import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { C, R, S } from '@/lib/theme';
import { groupForRole, type InstituteMembership, useSessionStore } from '@/store/session';
import { Avatar } from './Bits';
import { Sheet } from './Sheet';
import { Text } from './Text';

const ROLE_LABEL: Record<string, string> = {
  owner: 'Owner',
  admin: 'Administrator',
  teacher: 'Teacher',
  student: 'Student',
  parent: 'Parent',
};

export interface InstituteSwitcherProps {
  visible: boolean;
  onClose: () => void;
}

/**
 * Bottom sheet listing every institute the signed-in person is active in,
 * with a dashed "Join another institute" row underneath. Picking a row sets
 * the active institute AND navigates to that membership's role group —
 * switching role and group together, never a stale mix of the two.
 */
export function InstituteSwitcher({ visible, onClose }: InstituteSwitcherProps) {
  const { institutes, activeInstituteId, switchInstitute } = useSessionStore();

  const handleSelect = (row: InstituteMembership) => {
    onClose();
    if (row.institute.id !== activeInstituteId) {
      switchInstitute(row.institute.id);
    }
    router.replace(groupForRole(row.membership.role) as never);
  };

  const handleJoinAnother = () => {
    onClose();
    router.push('/(auth)/join-by-code' as never);
  };

  return (
    <Sheet visible={visible} onClose={onClose} title="Switch institute" subtitle="Your active memberships">
      <View style={{ gap: 10 }}>
        {institutes.length === 0 ? (
          <Text variant="body" c={C.muted} style={{ textAlign: 'center', paddingVertical: S.lg }}>
            Loading your institutes…
          </Text>
        ) : (
          institutes.map((row) => {
            const active = row.institute.id === activeInstituteId;
            const line = [
              ROLE_LABEL[row.membership.role] ?? row.membership.role,
              [row.institute.city, row.institute.state].filter(Boolean).join(', '),
            ]
              .filter(Boolean)
              .join(' · ');

            return (
              <Pressable
                key={row.institute.id}
                accessibilityRole="button"
                accessibilityLabel={`Switch to ${row.institute.name}`}
                onPress={() => handleSelect(row)}
                style={({ pressed }) => ({
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 12,
                  padding: 12,
                  borderRadius: R.card,
                  borderWidth: 1,
                  borderColor: active ? C.primary : C.hairline,
                  backgroundColor: active ? C.navySoft : C.surface,
                  opacity: pressed ? 0.92 : 1,
                })}
              >
                <Avatar name={row.institute.name} uri={row.institute.logoUrl} size={48} />
                <View style={{ flex: 1, gap: 2 }}>
                  <Text variant="title" weight={700} numberOfLines={1}>
                    {row.institute.name}
                  </Text>
                  <Text variant="caption" c={C.secondary} numberOfLines={1}>
                    {line}
                  </Text>
                </View>
                {active ? (
                  <View
                    style={{
                      width: 26,
                      height: 26,
                      borderRadius: 13,
                      backgroundColor: C.primary,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Ionicons name="checkmark" size={16} color={C.surface} />
                  </View>
                ) : (
                  <Ionicons name="chevron-forward" size={18} color={C.muted} />
                )}
              </Pressable>
            );
          })
        )}

        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Join another institute"
          onPress={handleJoinAnother}
          style={({ pressed }) => ({
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            padding: 14,
            borderRadius: R.card,
            borderWidth: 1.5,
            borderStyle: 'dashed',
            borderColor: C.muted,
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <Ionicons name="add-circle-outline" size={18} color={C.secondary} />
          <Text variant="body" weight={600} c={C.secondary}>
            Join another institute
          </Text>
        </Pressable>

        <Text variant="caption" c={C.muted} style={{ textAlign: 'center', paddingHorizontal: S.md, marginTop: 2 }}>
          Your attendance and marks stay separate for each institute.
        </Text>
      </View>
    </Sheet>
  );
}
