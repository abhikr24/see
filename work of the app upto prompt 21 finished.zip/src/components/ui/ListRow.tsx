import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, LAYOUT, S } from '@/lib/theme';
import { Text } from './Text';

export interface ListRowProps {
  leading?: React.ReactNode;
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  chevron?: boolean;
  onPress?: () => void;
  divider?: boolean;
  disabled?: boolean;
  className?: string;
}

/**
 * ListRow — 44pt leading slot, title, subtitle, right slot, chevron.
 * Enforces the 68pt row rhythm from LAYOUT.row.
 */
export function ListRow({
  leading,
  title,
  subtitle,
  right,
  chevron,
  onPress,
  divider = false,
  disabled = false,
  className,
}: ListRowProps) {
  const showChevron = chevron ?? Boolean(onPress);

  const content = (
    <View
      className={className}
      style={{
        minHeight: LAYOUT.row,
        paddingVertical: S.md,
        paddingHorizontal: S.md,
        flexDirection: 'row',
        alignItems: 'center',
        gap: S.md,
        borderBottomWidth: divider ? 1 : 0,
        borderBottomColor: C.hairline,
      }}
    >
      {leading ? (
        <View
          style={{
            width: LAYOUT.hit,
            height: LAYOUT.hit,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {leading}
        </View>
      ) : null}

      <View style={{ flex: 1, gap: 2 }}>
        <Text variant="title" weight={700} numberOfLines={1} style={{ fontSize: 16 }}>
          {title}
        </Text>
        {subtitle ? (
          <Text variant="caption" c={C.secondary} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>

      {right ? (
        <View style={{ alignItems: 'flex-end', justifyContent: 'center' }}>{right}</View>
      ) : null}

      {showChevron ? (
        <Ionicons name="chevron-forward" size={18} color={C.muted} />
      ) : null}
    </View>
  );

  if (!onPress) return content;

  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
      })}
    >
      {content}
    </Pressable>
  );
}
