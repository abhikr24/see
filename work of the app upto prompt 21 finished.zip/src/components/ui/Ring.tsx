import React from 'react';
import { View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { C } from '@/lib/theme';
import { Text } from './Text';

export interface RingProps {
  value: number;
  size?: number;
  stroke?: number;
  tone?: string;
  label?: string;
  className?: string;
}

export function Ring({
  value,
  size = 120,
  stroke = 8,
  tone = C.teal,
  label,
  className,
}: RingProps) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value));
  return (
    <View
      className={className}
      style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}
    >
      <Svg
        width={size}
        height={size}
        style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}
      >
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={C.track}
          strokeWidth={stroke}
          fill="none"
        />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={tone}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={`${circ}`}
          strokeDashoffset={circ - (circ * v) / 100}
          strokeLinecap="round"
        />
      </Svg>
      <Text weight={800} tabular style={{ fontSize: size * 0.26 }}>
        {Math.round(v)}%
      </Text>
      {label ? (
        <Text variant="label" c={C.muted} style={{ marginTop: 2 }}>
          {label}
        </Text>
      ) : null}
    </View>
  );
}
