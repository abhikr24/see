import React from 'react';
import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, LAYOUT } from '@/lib/theme';
import { Text } from './Text';

export interface ScreenProps {
  title?: string;
  subtitle?: string;
  right?: React.ReactNode;
  scroll?: boolean;
  padded?: boolean;
  children: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
  /** False inside a shell that already consumed the top safe-area inset (e.g. a tab group header). */
  safeTop?: boolean;
  /** Extra bottom padding so content clears a floating tab bar. */
  tabBarInset?: number;
}

export function Screen({
  title,
  subtitle,
  right,
  scroll = true,
  padded = true,
  children,
  footer,
  className,
  safeTop = true,
  tabBarInset = 0,
}: ScreenProps) {
  const head = title ? (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        marginBottom: 16,
        gap: 12,
      }}
    >
      <View style={{ flex: 1 }}>
        <Text variant="h1">{title}</Text>
        {subtitle ? (
          <Text variant="caption" c={C.secondary} style={{ marginTop: 4 }}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right}
    </View>
  ) : null;

  const body = (
    <View className={className} style={{ flex: 1, paddingHorizontal: padded ? LAYOUT.margin : 0 }}>
      {head}
      {scroll ? (
        <ScrollView
          contentContainerStyle={{ paddingBottom: 40 + tabBarInset, gap: 16 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {children}
        </ScrollView>
      ) : (
        children
      )}
    </View>
  );

  const footerNode = footer ? (
    <View style={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 12 + tabBarInset, paddingTop: 8 }}>
      {footer}
    </View>
  ) : null;

  if (!safeTop) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        {body}
        {footerNode}
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
      {body}
      {footerNode}
    </SafeAreaView>
  );
}
