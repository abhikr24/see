import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R, S } from '@/lib/theme';

export interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  onDebouncedChange?: (debounced: string) => void;
  debounceMs?: number;
  placeholder?: string;
  loading?: boolean;
  compact?: boolean;
  className?: string;
}

/**
 * SearchBar — input with a clear button and debounce.
 */
export function SearchBar({
  value,
  onChangeText,
  onDebouncedChange,
  debounceMs = 250,
  placeholder = 'Search by name, roll or phone…',
  loading = false,
  compact = false,
  className,
}: SearchBarProps) {
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (!onDebouncedChange) return;
    const timer = setTimeout(() => {
      onDebouncedChange(value);
    }, debounceMs);
    return () => clearTimeout(timer);
  }, [value, debounceMs, onDebouncedChange]);

  const handleClear = () => {
    onChangeText('');
    onDebouncedChange?.('');
  };

  return (
    <View
      className={className}
      style={{
        height: compact ? 44 : 52,
        borderRadius: R.field,
        backgroundColor: C.surface,
        borderWidth: focused ? 2 : 1,
        borderColor: focused ? C.primary : C.hairline,
        paddingHorizontal: S.md,
        flexDirection: 'row',
        alignItems: 'center',
        gap: S.sm,
      }}
    >
      <Ionicons name="search-outline" size={18} color={focused ? C.primary : C.muted} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        placeholderTextColor={C.muted}
        returnKeyType="search"
        autoCapitalize="none"
        autoCorrect={false}
        style={{
          flex: 1,
          fontSize: 15,
          color: C.ink,
          paddingVertical: 0,
        }}
      />
      {loading ? (
        <ActivityIndicator size="small" color={C.primary} />
      ) : value.length > 0 ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Clear search"
          onPress={handleClear}
          hitSlop={12}
          style={{
            width: 26,
            height: 26,
            borderRadius: 13,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name="close-circle" size={18} color={C.muted} />
        </Pressable>
      ) : null}
    </View>
  );
}
