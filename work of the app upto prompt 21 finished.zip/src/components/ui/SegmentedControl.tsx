import React, { useEffect, useState } from 'react';
import { Pressable, View, type LayoutChangeEvent } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { C, R, S, SHADOW } from '@/lib/theme';
import { Text } from './Text';

export interface SegmentedOption<T extends string = string> {
  key: T;
  label: string;
  count?: number;
}

export interface SegmentedControlProps<T extends string = string> {
  options: readonly (SegmentedOption<T> | T)[];
  value: T;
  onChange: (value: T) => void;
  size?: 'sm' | 'md';
  className?: string;
}

/**
 * SegmentedControl — pill track, animated thumb, 2–4 options.
 */
export function SegmentedControl<T extends string = string>({
  options,
  value,
  onChange,
  size = 'md',
  className,
}: SegmentedControlProps<T>) {
  const normalized: SegmentedOption<T>[] = options.map((opt) =>
    typeof opt === 'string' ? { key: opt as T, label: opt } : opt,
  );

  const count = Math.max(2, Math.min(4, normalized.length));
  const items = normalized.slice(0, count);
  const activeIndex = Math.max(
    0,
    items.findIndex((item) => item.key === value),
  );

  const [trackWidth, setTrackWidth] = useState(0);
  const pad = 4;
  const segmentWidth = trackWidth > 0 ? (trackWidth - pad * 2) / items.length : 0;

  const translateX = useSharedValue(0);

  useEffect(() => {
    if (segmentWidth > 0) {
      translateX.value = withTiming(activeIndex * segmentWidth, { duration: 180 });
    }
  }, [activeIndex, segmentWidth, translateX]);

  const thumbStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  const handleLayout = (e: LayoutChangeEvent) => {
    const w = e.nativeEvent.layout.width;
    if (w > 0 && Math.abs(w - trackWidth) > 0.5) {
      setTrackWidth(w);
    }
  };

  const height = size === 'sm' ? 38 : 44;

  return (
    <View
      className={className}
      onLayout={handleLayout}
      style={{
        height,
        borderRadius: R.chip,
        backgroundColor: C.track,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: pad,
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      {segmentWidth > 0 ? (
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: 'absolute',
              left: pad,
              top: pad,
              bottom: pad,
              width: segmentWidth,
              borderRadius: R.chip,
              backgroundColor: C.surface,
              borderWidth: 1,
              borderColor: C.hairline,
              ...SHADOW,
            },
            thumbStyle,
          ]}
        />
      ) : null}

      {items.map((item) => {
        const active = item.key === value;
        return (
          <Pressable
            key={item.key}
            accessibilityRole="tab"
            accessibilityState={{ selected: active }}
            onPress={() => onChange(item.key)}
            style={{
              flex: 1,
              height: '100%',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              gap: S.xs,
              paddingHorizontal: S.sm,
            }}
          >
            <Text
              variant="caption"
              weight={active ? 700 : 600}
              c={active ? C.primary : C.secondary}
              numberOfLines={1}
              tabular
            >
              {item.label}
              {item.count !== undefined ? ` · ${item.count}` : ''}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
