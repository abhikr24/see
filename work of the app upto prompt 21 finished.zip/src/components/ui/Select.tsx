import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { Badge } from './Bits';
import { SearchBar } from './SearchBar';
import { Sheet } from './Sheet';
import { Text } from './Text';

export interface SelectOption {
  value: string;
  label: string;
  subtitle?: string;
  badge?: string;
}

export interface SelectProps {
  label?: string;
  options: readonly SelectOption[];
  value?: string;
  onChange: (value: string) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  searchable?: boolean;
  error?: string;
  hint?: string;
  disabled?: boolean;
  className?: string;
}

/**
 * Select — labelled dropdown with a searchable sheet.
 */
export function Select({
  label,
  options,
  value,
  onChange,
  placeholder = 'Choose an option',
  searchPlaceholder = 'Filter options…',
  searchable = true,
  error,
  hint,
  disabled = false,
  className,
}: SelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');

  const selected = useMemo(
    () => options.find((opt) => opt.value === value),
    [options, value],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter(
      (opt) =>
        opt.label.toLowerCase().includes(q) ||
        (opt.subtitle && opt.subtitle.toLowerCase().includes(q)) ||
        (opt.badge && opt.badge.toLowerCase().includes(q)),
    );
  }, [options, query]);

  const handleOpen = () => {
    if (disabled) return;
    setQuery('');
    setOpen(true);
  };

  return (
    <View className={className} style={{ gap: 6 }}>
      {label ? (
        <Text variant="label" c={C.secondary}>
          {label}
        </Text>
      ) : null}

      <Pressable
        accessibilityRole="button"
        disabled={disabled}
        onPress={handleOpen}
        style={({ pressed }) => ({
          height: 56,
          paddingHorizontal: 18,
          borderRadius: R.field,
          backgroundColor: C.surface,
          borderWidth: open ? 2 : 1,
          borderColor: error ? C.danger : open ? C.primary : C.hairline,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: S.sm,
          opacity: disabled ? 0.5 : pressed ? 0.9 : 1,
        })}
      >
        <View style={{ flex: 1 }}>
          <Text
            variant="body"
            c={selected ? C.ink : C.muted}
            numberOfLines={1}
            style={{ fontSize: 15 }}
          >
            {selected ? selected.label : placeholder}
          </Text>
        </View>
        {selected?.badge ? <Badge label={selected.badge} tone="primary" small /> : null}
        <Ionicons name="chevron-down-outline" size={18} color={C.secondary} />
      </Pressable>

      {error ? (
        <Text variant="caption" c={C.danger}>
          {error}
        </Text>
      ) : hint ? (
        <Text variant="caption" c={C.muted}>
          {hint}
        </Text>
      ) : null}

      <Sheet
        visible={open}
        onClose={() => setOpen(false)}
        title={label ?? 'Choose option'}
        snapPoints={['65%', '85%']}
      >
        <View style={{ gap: S.md }}>
          {searchable ? (
            <SearchBar
              value={query}
              onChangeText={setQuery}
              placeholder={searchPlaceholder}
              compact
            />
          ) : null}

          <ScrollView style={{ maxHeight: 320 }} keyboardShouldPersistTaps="handled">
            {filtered.length === 0 ? (
              <View style={{ paddingVertical: S.xxl, alignItems: 'center' }}>
                <Text variant="caption" c={C.muted}>
                  No matching options found.
                </Text>
              </View>
            ) : (
              filtered.map((opt, idx) => {
                const isSelected = opt.value === value;
                return (
                  <Pressable
                    key={opt.value}
                    accessibilityRole="button"
                    onPress={() => {
                      onChange(opt.value);
                      setOpen(false);
                    }}
                    style={({ pressed }) => ({
                      minHeight: LAYOUT.hit + 12,
                      paddingVertical: S.sm + 2,
                      paddingHorizontal: S.sm,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: S.md,
                      borderBottomWidth: idx < filtered.length - 1 ? 1 : 0,
                      borderBottomColor: C.hairline,
                      backgroundColor: isSelected ? C.navySoft : C.transparent,
                      borderRadius: isSelected ? R.field : 0,
                      opacity: pressed ? 0.85 : 1,
                    })}
                  >
                    <View style={{ flex: 1, gap: 2 }}>
                      <Text
                        variant="body"
                        weight={isSelected ? 700 : 600}
                        c={isSelected ? C.primary : C.ink}
                      >
                        {opt.label}
                      </Text>
                      {opt.subtitle ? (
                        <Text variant="caption" c={C.secondary}>
                          {opt.subtitle}
                        </Text>
                      ) : null}
                    </View>
                    {opt.badge ? (
                      <Badge label={opt.badge} tone={isSelected ? 'primary' : 'neutral'} small />
                    ) : null}
                    <Ionicons
                      name={isSelected ? 'checkmark-circle' : 'ellipse-outline'}
                      size={20}
                      color={isSelected ? C.primary : C.hairline}
                    />
                  </Pressable>
                );
              })
            )}
          </ScrollView>
        </View>
      </Sheet>
    </View>
  );
}
