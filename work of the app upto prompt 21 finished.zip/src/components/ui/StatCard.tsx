import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R, S, TONE } from '@/lib/theme';
import { Card } from './Card';
import { Text } from './Text';

export type StatTrend = 'up' | 'down' | 'warning' | 'neutral';

export interface StatCardProps {
  label: string;
  value: string | number;
  delta?: string;
  trend?: StatTrend;
  subtitle?: string;
  flat?: boolean;
  tint?: string;
  onPress?: () => void;
  className?: string;
}

const TREND_CONFIG: Record<
  StatTrend,
  { fg: string; bg: string; icon: keyof typeof Ionicons.glyphMap }
> = {
  up: { fg: TONE.teal.fg, bg: TONE.teal.bg, icon: 'trending-up-outline' },
  down: { fg: TONE.danger.fg, bg: TONE.danger.bg, icon: 'trending-down-outline' },
  warning: { fg: TONE.warning.fg, bg: TONE.warning.bg, icon: 'alert-circle-outline' },
  neutral: { fg: TONE.neutral.fg, bg: TONE.neutral.bg, icon: 'remove-outline' },
};

/**
 * StatCard — label + big tabular value + optional delta and trend colour.
 */
export function StatCard({
  label,
  value,
  delta,
  trend = 'neutral',
  subtitle,
  flat = true,
  tint,
  onPress,
  className,
}: StatCardProps) {
  const trendStyle = TREND_CONFIG[trend];

  return (
    <Card flat={flat} tint={tint} onPress={onPress} className={className}>
      <View style={{ gap: S.xs }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: S.sm,
          }}
        >
          <Text variant="label" c={C.muted} numberOfLines={1} style={{ flex: 1 }}>
            {label}
          </Text>
          {delta ? (
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 4,
                backgroundColor: trendStyle.bg,
                paddingHorizontal: 8,
                paddingVertical: 3,
                borderRadius: R.chip,
              }}
            >
              <Ionicons name={trendStyle.icon} size={12} color={trendStyle.fg} />
              <Text variant="label" weight={700} c={trendStyle.fg} tabular style={{ fontSize: 10 }}>
                {delta}
              </Text>
            </View>
          ) : null}
        </View>

        <Text variant="h1" weight={800} tabular style={{ fontSize: 30, marginTop: 2 }}>
          {value}
        </Text>

        {subtitle ? (
          <Text variant="caption" c={C.secondary} numberOfLines={1}>
            {subtitle}
          </Text>
        ) : null}
      </View>
    </Card>
  );
}
