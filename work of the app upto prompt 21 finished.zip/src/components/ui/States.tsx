import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { C, R, type Tone } from '@/lib/theme';
import { Text } from './Text';
import { Button } from './Button';
import { EmptyArt } from './EmptyArt';

export interface SkeletonProps {
  h?: number;
  w?: number | string;
  r?: number;
  className?: string;
}

export function Skeleton({ h = 16, w = '100%', r = 8, className }: SkeletonProps) {
  const opacity = useSharedValue(0.55);
  useEffect(() => {
    opacity.value = withRepeat(withTiming(1, { duration: 850 }), -1, true);
  }, [opacity]);
  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return (
    <Animated.View
      className={className}
      style={[{ height: h, width: w as number, borderRadius: r, backgroundColor: C.track }, animatedStyle]}
    />
  );
}

export interface ListSkeletonProps {
  rows?: number;
  h?: number;
  className?: string;
}

export function ListSkeleton({ rows = 5, h = 68, className }: ListSkeletonProps) {
  return (
    <View className={className} style={{ gap: 12 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <View
          key={i}
          style={{
            height: h,
            borderRadius: R.card,
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            padding: 14,
            flexDirection: 'row',
            gap: 12,
            alignItems: 'center',
          }}
        >
          <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: C.track }} />
          <View style={{ flex: 1, gap: 8 }}>
            <Skeleton h={12} w="55%" />
            <Skeleton h={10} w="35%" />
          </View>
        </View>
      ))}
    </View>
  );
}

export interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  tone?: Tone;
  title: string;
  text?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export function EmptyState({
  icon = 'file-tray-outline',
  tone = 'primary',
  title,
  text,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  return (
    <View
      className={className}
      style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}
    >
      <View style={{ marginBottom: 4 }}>
        <EmptyArt icon={icon} tone={tone} size={88} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      {text ? (
        <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 260 }}>
          {text}
        </Text>
      ) : null}
      {actionLabel && onAction ? (
        <View style={{ marginTop: 10 }}>
          <Button title={actionLabel} onPress={onAction} size="md" full={false} />
        </View>
      ) : null}
    </View>
  );
}

export interface ErrorStateProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorState({
  title = 'Could not load this',
  message,
  onRetry,
  className,
}: ErrorStateProps) {
  return (
    <View
      className={className}
      style={{ alignItems: 'center', paddingVertical: 36, paddingHorizontal: 24, gap: 10 }}
    >
      <View style={{ marginBottom: 4 }}>
        <EmptyArt icon="alert-circle-outline" tone="danger" size={88} />
      </View>
      <Text variant="h2" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      <Text variant="caption" c={C.secondary} style={{ textAlign: 'center', maxWidth: 260 }}>
        {message}
      </Text>
      {onRetry ? (
        <View style={{ marginTop: 10 }}>
          <Button title="Try again" onPress={onRetry} size="md" full={false} />
        </View>
      ) : null}
    </View>
  );
}
