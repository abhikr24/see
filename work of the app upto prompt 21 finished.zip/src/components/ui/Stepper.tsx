import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { formatIndianNumber } from '@/lib/format';
import { Text } from './Text';

export interface StepperProps {
  label?: string;
  value: number;
  onChange: (next: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  disabled?: boolean;
  className?: string;
}

/**
 * Stepper — −/+ numeric with min/max and a suffix (₹).
 */
export function Stepper({
  label,
  value,
  onChange,
  min = 0,
  max = 100000,
  step = 1,
  suffix = '₹',
  disabled = false,
  className,
}: StepperProps) {
  const canDec = !disabled && value - step >= min;
  const canInc = !disabled && value + step <= max;

  const dec = () => {
    if (canDec) onChange(Math.max(min, value - step));
  };

  const inc = () => {
    if (canInc) onChange(Math.min(max, value + step));
  };

  const formattedNumber = formatIndianNumber(value);
  const displayValue =
    suffix === '₹' ? `₹${formattedNumber}` : `${formattedNumber} ${suffix}`.trim();

  return (
    <View className={className} style={{ gap: 6 }}>
      {label ? (
        <Text variant="label" c={C.secondary}>
          {label}
        </Text>
      ) : null}

      <View
        style={{
          height: 54,
          borderRadius: R.field,
          backgroundColor: C.surface,
          borderWidth: 1,
          borderColor: C.hairline,
          paddingHorizontal: 6,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Decrease value"
          disabled={!canDec}
          onPress={dec}
          style={({ pressed }) => ({
            width: LAYOUT.hit,
            height: 42,
            borderRadius: 10,
            backgroundColor: canDec ? C.track : C.canvas,
            alignItems: 'center',
            justifyContent: 'center',
            opacity: !canDec ? 0.4 : pressed ? 0.8 : 1,
          })}
        >
          <Ionicons name="remove" size={20} color={canDec ? C.primary : C.muted} />
        </Pressable>

        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            paddingHorizontal: S.sm,
          }}
        >
          <Text variant="title" weight={800} tabular style={{ fontSize: 18 }}>
            {displayValue}
          </Text>
          <Text variant="label" c={C.muted} tabular style={{ fontSize: 9.5, marginTop: 1 }}>
            MIN {suffix === '₹' ? `₹${formatIndianNumber(min)}` : `${min}${suffix}`} · MAX{' '}
            {suffix === '₹' ? `₹${formatIndianNumber(max)}` : `${max}${suffix}`}
          </Text>
        </View>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Increase value"
          disabled={!canInc}
          onPress={inc}
          style={({ pressed }) => ({
            width: LAYOUT.hit,
            height: 42,
            borderRadius: 10,
            backgroundColor: canInc ? C.primary : C.canvas,
            alignItems: 'center',
            justifyContent: 'center',
            opacity: !canInc ? 0.4 : pressed ? 0.85 : 1,
          })}
        >
          <Ionicons name="add" size={20} color={canInc ? C.surface : C.muted} />
        </Pressable>
      </View>
    </View>
  );
}
