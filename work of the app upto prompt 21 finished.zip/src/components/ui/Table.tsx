import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { C, R, S } from '@/lib/theme';
import { Text } from './Text';

export interface TableColumn<Row = Record<string, unknown>> {
  key: string;
  title: string;
  /** Right-aligns header & cell and applies tabular-nums */
  numeric?: boolean;
  flex?: number;
  width?: number;
  render?: (row: Row, index: number) => React.ReactNode;
}

export interface TableProps<Row = Record<string, unknown>> {
  columns: readonly TableColumn<Row>[];
  data: readonly Row[];
  keyExtractor?: (row: Row, index: number) => string;
  maxHeight?: number;
  onRowPress?: (row: Row, index: number) => void;
  footerRow?: Record<string, string | number>;
  className?: string;
}

/**
 * Table — sticky header, hairline rows, right-aligned tabular numbers.
 */
export function Table<Row extends Record<string, unknown> = Record<string, unknown>>({
  columns,
  data,
  keyExtractor,
  maxHeight = 280,
  onRowPress,
  footerRow,
  className,
}: TableProps<Row>) {
  const header = (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: C.track,
        borderBottomWidth: 1,
        borderBottomColor: C.hairline,
        paddingHorizontal: S.md,
        paddingVertical: 11,
      }}
    >
      {columns.map((col) => (
        <View
          key={col.key}
          style={{
            flex: col.width ? undefined : (col.flex ?? 1),
            width: col.width,
            alignItems: col.numeric ? 'flex-end' : 'flex-start',
            paddingHorizontal: 4,
          }}
        >
          <Text variant="label" weight={700} c={C.secondary}>
            {col.title}
          </Text>
        </View>
      ))}
    </View>
  );

  const rows = data.map((row, rowIndex) => {
    const key = keyExtractor ? keyExtractor(row, rowIndex) : String(row.id ?? rowIndex);
    const isLast = rowIndex === data.length - 1 && !footerRow;

    const rowBody = (
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          minHeight: 50,
          paddingHorizontal: S.md,
          paddingVertical: 11,
          backgroundColor: C.surface,
          borderBottomWidth: isLast ? 0 : 1,
          borderBottomColor: C.hairline,
        }}
      >
        {columns.map((col) => {
          const rawValue = row[col.key];
          return (
            <View
              key={col.key}
              style={{
                flex: col.width ? undefined : (col.flex ?? 1),
                width: col.width,
                alignItems: col.numeric ? 'flex-end' : 'flex-start',
                paddingHorizontal: 4,
              }}
            >
              {col.render ? (
                col.render(row, rowIndex)
              ) : (
                <Text
                  variant="body"
                  weight={col.numeric ? 700 : 500}
                  c={C.ink}
                  tabular={col.numeric}
                  numberOfLines={1}
                  style={{
                    fontSize: 14,
                    textAlign: col.numeric ? 'right' : 'left',
                  }}
                >
                  {String(rawValue ?? '—')}
                </Text>
              )}
            </View>
          );
        })}
      </View>
    );

    if (!onRowPress) return <View key={key}>{rowBody}</View>;

    return (
      <Pressable
        key={key}
        accessibilityRole="button"
        onPress={() => onRowPress(row, rowIndex)}
        style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}
      >
        {rowBody}
      </Pressable>
    );
  });

  const footer = footerRow ? (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        minHeight: 46,
        paddingHorizontal: S.md,
        paddingVertical: 10,
        backgroundColor: C.canvas,
      }}
    >
      {columns.map((col) => (
        <View
          key={col.key}
          style={{
            flex: col.width ? undefined : (col.flex ?? 1),
            width: col.width,
            alignItems: col.numeric ? 'flex-end' : 'flex-start',
            paddingHorizontal: 4,
          }}
        >
          <Text
            variant="caption"
            weight={700}
            c={C.primary}
            tabular={col.numeric}
            style={{ textAlign: col.numeric ? 'right' : 'left' }}
          >
            {String(footerRow[col.key] ?? '')}
          </Text>
        </View>
      ))}
    </View>
  ) : null;

  return (
    <View
      className={className}
      style={{
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        backgroundColor: C.surface,
        overflow: 'hidden',
      }}
    >
      <ScrollView
        style={{ maxHeight }}
        stickyHeaderIndices={[0]}
        nestedScrollEnabled
        showsVerticalScrollIndicator={false}
      >
        {header}
        <View>{rows}</View>
        {footer}
      </ScrollView>
    </View>
  );
}
