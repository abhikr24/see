import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { C, R, S } from '@/lib/theme';
import { Text } from './Text';

export interface UnderlineTab {
  key: string;
  label: string;
  count?: number;
}

export interface TabsProps {
  tabs: readonly UnderlineTab[];
  activeKey: string;
  onChange: (key: string) => void;
  variant?: 'primary' | 'accent';
  scrollable?: boolean;
  className?: string;
}

/**
 * Tabs — underline tabs for detail screens.
 */
export function Tabs({
  tabs,
  activeKey,
  onChange,
  variant = 'primary',
  scrollable = false,
  className,
}: TabsProps) {
  const indicatorColor = variant === 'accent' ? C.accent : C.primary;

  const items = tabs.map((tab) => {
    const active = tab.key === activeKey;
    return (
      <Pressable
        key={tab.key}
        accessibilityRole="tab"
        accessibilityState={{ selected: active }}
        onPress={() => onChange(tab.key)}
        style={{
          flex: scrollable ? undefined : 1,
          paddingHorizontal: scrollable ? S.lg : S.sm,
          paddingTop: S.sm,
          paddingBottom: 11,
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
          gap: 6,
          borderBottomWidth: 2.5,
          borderBottomColor: active ? indicatorColor : C.transparent,
        }}
      >
        <Text
          variant="body"
          weight={active ? 700 : 600}
          c={active ? C.ink : C.secondary}
          style={{ fontSize: 14 }}
        >
          {tab.label}
        </Text>
        {tab.count !== undefined ? (
          <View
            style={{
              backgroundColor: active
                ? variant === 'accent'
                  ? C.accentSoft
                  : C.navySoft
                : C.track,
              paddingHorizontal: 7,
              paddingVertical: 2,
              borderRadius: R.chip,
            }}
          >
            <Text
              variant="label"
              weight={700}
              c={active ? indicatorColor : C.secondary}
              tabular
              style={{ fontSize: 10 }}
            >
              {tab.count}
            </Text>
          </View>
        ) : null}
      </Pressable>
    );
  });

  if (scrollable) {
    return (
      <View
        className={className}
        style={{
          borderBottomWidth: 1,
          borderBottomColor: C.hairline,
        }}
      >
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {items}
        </ScrollView>
      </View>
    );
  }

  return (
    <View
      className={className}
      style={{
        flexDirection: 'row',
        borderBottomWidth: 1,
        borderBottomColor: C.hairline,
      }}
    >
      {items}
    </View>
  );
}
