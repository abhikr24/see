import React from 'react';
import { Text as RNText, type TextProps as RNTextProps, type TextStyle } from 'react-native';
import { C, FONT_SIZE, FONT } from '@/lib/theme';

export type TextVariant = 'h1' | 'h2' | 'title' | 'body' | 'caption' | 'label';
export type TextWeight = 500 | 600 | 700 | 800;

const SIZE: Record<TextVariant, number> = FONT_SIZE;
const DEFAULT_WEIGHT: Record<TextVariant, TextWeight> = {
  h1: 800,
  h2: 700,
  title: 700,
  body: 500,
  caption: 500,
  label: 600,
};

export interface TextProps extends RNTextProps {
  variant?: TextVariant;
  weight?: TextWeight;
  c?: string;
  tabular?: boolean;
  className?: string;
}

export function Text({
  variant = 'body',
  weight,
  c,
  tabular,
  className,
  style,
  children,
  ...rest
}: TextProps) {
  return (
    <RNText
      {...rest}
      className={className}
      style={[
        {
          fontSize: SIZE[variant],
          fontFamily: variant === 'h1' || variant === 'h2' ? FONT.heading : FONT.body,
          fontWeight: String(weight ?? DEFAULT_WEIGHT[variant]) as TextStyle['fontWeight'],
          color: c ?? C.ink,
          ...(variant === 'label' ? { letterSpacing: 0.66, textTransform: 'uppercase' as const } : null),
          ...(tabular ? { fontVariant: ['tabular-nums'] as const } : null),
        },
        style,
      ]}
    >
      {children}
    </RNText>
  );
}
