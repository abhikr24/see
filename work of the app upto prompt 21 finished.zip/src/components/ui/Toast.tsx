import React, { useEffect } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R, S, SHADOW } from '@/lib/theme';
import { Text } from './Text';

export type ToastVariant = 'success' | 'error' | 'info';

export interface ToastProps {
  kind?: ToastVariant;
  message: string;
  subtitle?: string;
  visible?: boolean;
  onDismiss?: () => void;
  /** Auto-dismiss timer in ms. Pass 0 to disable auto-dismiss (for inline previews). */
  autoDismissMs?: number;
  bottomOffset?: number;
  floating?: boolean;
  className?: string;
}

const TOAST_STYLE: Record<
  ToastVariant,
  {
    accent: string;
    soft: string;
    icon: keyof typeof Ionicons.glyphMap;
  }
> = {
  success: {
    accent: C.success,
    soft: C.successSoft,
    icon: 'checkmark-circle',
  },
  error: {
    accent: C.danger,
    soft: C.dangerSoft,
    icon: 'alert-circle',
  },
  info: {
    accent: C.primary,
    soft: C.navySoft,
    icon: 'information-circle',
  },
};

/**
 * Toast — success / error / info, auto-dismiss, bottom offset.
 */
export function Toast({
  kind = 'info',
  message,
  subtitle,
  visible = true,
  onDismiss,
  autoDismissMs = 3200,
  bottomOffset = 24,
  floating = false,
  className,
}: ToastProps) {
  useEffect(() => {
    if (!visible || !onDismiss || autoDismissMs <= 0) return;
    const timer = setTimeout(() => {
      onDismiss();
    }, autoDismissMs);
    return () => clearTimeout(timer);
  }, [visible, onDismiss, autoDismissMs]);

  if (!visible) return null;

  const cfg = TOAST_STYLE[kind];

  const card = (
    <View
      accessibilityRole="alert"
      accessibilityLiveRegion="polite"
      className={className}
      style={{
        backgroundColor: C.surface,
        borderRadius: R.btn,
        borderWidth: 1,
        borderColor: C.hairline,
        borderLeftWidth: 4,
        borderLeftColor: cfg.accent,
        paddingVertical: 12,
        paddingHorizontal: 14,
        flexDirection: 'row',
        alignItems: 'center',
        gap: S.md,
        ...SHADOW,
      }}
    >
      <View
        style={{
          width: 34,
          height: 34,
          borderRadius: 17,
          backgroundColor: cfg.soft,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name={cfg.icon} size={20} color={cfg.accent} />
      </View>

      <View style={{ flex: 1, gap: 2 }}>
        <Text variant="body" weight={700} c={C.ink} style={{ fontSize: 14 }}>
          {message}
        </Text>
        {subtitle ? (
          <Text variant="caption" c={C.secondary} style={{ fontSize: 12 }}>
            {subtitle}
          </Text>
        ) : null}
      </View>

      {onDismiss ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Dismiss notification"
          onPress={onDismiss}
          hitSlop={10}
        >
          <Ionicons name="close" size={18} color={C.muted} />
        </Pressable>
      ) : null}
    </View>
  );

  if (!floating) return card;

  return (
    <View
      pointerEvents="box-none"
      style={{
        position: 'absolute',
        left: 20,
        right: 20,
        bottom: bottomOffset,
        zIndex: 50,
      }}
    >
      {card}
    </View>
  );
}
