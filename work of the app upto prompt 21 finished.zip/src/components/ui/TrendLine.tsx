import React, { useState } from 'react';
import { View, type LayoutChangeEvent } from 'react-native';
import { LineChart, type lineDataItem } from 'react-native-gifted-charts';
import { C, R, S } from '@/lib/theme';
import { Text } from './Text';

export interface TrendPoint {
  value: number;
  label?: string;
}

export interface TrendLineProps {
  data: readonly TrendPoint[];
  title?: string;
  subtitle?: string;
  headlineValue?: string;
  height?: number;
  color?: string;
  curved?: boolean;
  className?: string;
}

/**
 * TrendLine — thin line chart, no gridlines, last dot saffron.
 * Powered by react-native-gifted-charts (flat, no shadows, no 3D).
 */
export function TrendLine({
  data,
  title,
  subtitle,
  headlineValue,
  height = 132,
  color = C.primary,
  curved = true,
  className,
}: TrendLineProps) {
  const [chartWidth, setChartWidth] = useState(280);

  const handleLayout = (e: LayoutChangeEvent) => {
    const nextWidth = Math.max(180, Math.floor(e.nativeEvent.layout.width - 36));
    if (Math.abs(nextWidth - chartWidth) > 4) {
      setChartWidth(nextWidth);
    }
  };

  const count = Math.max(1, data.length);
  const spacing = count > 1 ? Math.max(28, Math.floor((chartWidth - 36) / (count - 1))) : 48;

  const chartData: lineDataItem[] = data.map((pt, idx) => {
    const isLast = idx === data.length - 1;
    return {
      value: pt.value,
      label: pt.label ?? '',
      hideDataPoint: !isLast,
      dataPointColor: isLast ? C.accent : color,
      dataPointRadius: isLast ? 6 : 3,
      customDataPoint: isLast
        ? () => (
            <View
              style={{
                width: 16,
                height: 16,
                borderRadius: 8,
                backgroundColor: C.accentSoft,
                alignItems: 'center',
                justifyContent: 'center',
                marginLeft: -4,
                marginTop: -4,
              }}
            >
              <View
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: C.accent,
                }}
              />
            </View>
          )
        : undefined,
    };
  });

  return (
    <View
      className={className}
      onLayout={handleLayout}
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: 18,
        gap: S.sm,
      }}
    >
      {title || subtitle || headlineValue ? (
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            gap: S.sm,
          }}
        >
          <View style={{ flex: 1, gap: 2 }}>
            {title ? (
              <Text variant="label" c={C.muted}>
                {title}
              </Text>
            ) : null}
            {subtitle ? (
              <Text variant="caption" c={C.secondary}>
                {subtitle}
              </Text>
            ) : null}
          </View>
          {headlineValue ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <View
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: C.accent,
                }}
              />
              <Text variant="h2" weight={800} tabular>
                {headlineValue}
              </Text>
            </View>
          ) : null}
        </View>
      ) : null}

      <View style={{ paddingTop: S.xs, overflow: 'hidden' }}>
        <LineChart
          data={chartData}
          width={chartWidth}
          height={height}
          spacing={spacing}
          initialSpacing={14}
          endSpacing={20}
          thickness={2.2}
          color={color}
          curved={curved}
          hideRules
          hideYAxisText
          yAxisThickness={0}
          xAxisThickness={0}
          xAxisLabelTextStyle={{
            color: C.muted,
            fontSize: 11,
            fontWeight: '600',
          }}
          isAnimated={false}
        />
      </View>
    </View>
  );
}
