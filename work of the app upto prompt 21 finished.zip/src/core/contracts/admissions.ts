/**
 * Admissions rules — pure, shared by the reference backend, the Supabase adapter,
 * the screens and the acceptance tests.
 */
import { dateShort, relTime, todayISO } from '../../lib/format';
import type { Tone } from '../../lib/theme';
import type {
  AdmissionLead,
  AdmissionsSummary,
  LeadFollowup,
  LeadSegment,
  LeadSource,
  LeadStage,
} from './models';

export const LEAD_SEGMENTS: readonly LeadSegment[] = [
  'new',
  'following_up',
  'demo_booked',
  'converted',
  'lost',
] as const;

export const SEGMENT_LABELS: Record<LeadSegment, string> = {
  new: 'New',
  following_up: 'Following up',
  demo_booked: 'Demo booked',
  converted: 'Converted',
  lost: 'Lost',
};

export function segmentForStage(stage: LeadStage): LeadSegment {
  switch (stage) {
    case 'new':
      return 'new';
    case 'contacted':
    case 'interested':
    case 'demo_attended':
    case 'negotiation':
      return 'following_up';
    case 'demo_scheduled':
      return 'demo_booked';
    case 'enrolled':
      return 'converted';
    case 'lost':
      return 'lost';
  }
}

export const STAGE_LABELS: Record<LeadStage, string> = {
  new: 'New',
  contacted: 'Contacted',
  interested: 'Interested',
  demo_scheduled: 'Demo booked',
  demo_attended: 'Demo done',
  negotiation: 'Negotiating',
  enrolled: 'Converted',
  lost: 'Lost',
};

export const STAGE_TONES: Record<LeadStage, Tone> = {
  new: 'primary',
  contacted: 'teal',
  interested: 'teal',
  demo_scheduled: 'accent',
  demo_attended: 'teal',
  negotiation: 'warning',
  enrolled: 'success',
  lost: 'neutral',
};

/** Open pipeline stages an owner can move an enquiry through before conversion or loss. */
export const OPEN_STAGES: readonly LeadStage[] = [
  'new',
  'contacted',
  'interested',
  'demo_scheduled',
  'demo_attended',
  'negotiation',
] as const;

export const SOURCE_LABELS: Record<LeadSource, string> = {
  walk_in: 'Walk-in',
  referral: 'Referral',
  instagram: 'Instagram',
  google: 'Google',
  website: 'Google',
  social: 'Instagram',
  phone: 'Phone',
  campaign: 'Campaign',
  other: 'Other',
};

export const CREATE_SOURCES: readonly { key: LeadSource; label: string }[] = [
  { key: 'walk_in', label: 'Walk-in' },
  { key: 'referral', label: 'Referral' },
  { key: 'instagram', label: 'Instagram' },
  { key: 'google', label: 'Google' },
  { key: 'other', label: 'Other' },
] as const;

export type FollowupChannelChoice = 'call' | 'visit' | 'whatsapp';

export const FOLLOWUP_CHANNELS: readonly { key: FollowupChannelChoice; label: string }[] = [
  { key: 'call', label: 'Call' },
  { key: 'visit', label: 'Visit' },
  { key: 'whatsapp', label: 'WhatsApp' },
] as const;

export const CHANNEL_VERBS: Record<LeadFollowup['channel'], string> = {
  call: 'called',
  visit: 'visited',
  whatsapp: 'WhatsApp',
  sms: 'messaged',
  email: 'emailed',
};

export const CHANNEL_LABELS: Record<LeadFollowup['channel'], string> = {
  call: 'Call',
  visit: 'Visit',
  whatsapp: 'WhatsApp',
  sms: 'SMS',
  email: 'Email',
};

export const OUTCOME_LABELS: Record<NonNullable<LeadFollowup['outcome']>, string> = {
  no_answer: 'No answer',
  interested: 'Interested',
  callback: 'Callback',
  demo_booked: 'Demo booked',
  not_interested: 'Not interested',
  enrolled: 'Enrolled',
};

/** Computes the three list summary strip metrics strictly from underlying leads & follow-ups. */
export function computeAdmissionsSummary(
  leads: readonly AdmissionLead[],
  followups: readonly LeadFollowup[],
  today = todayISO(),
): AdmissionsSummary {
  const monthPrefix = today.slice(0, 7);
  const thisMonthEnquiries = leads.filter((l) => l.createdAt.slice(0, 7) === monthPrefix).length;
  const totalLeads = leads.length;
  const convertedCount = leads.filter((l) => l.stage === 'enrolled').length;
  const conversionPercent = totalLeads > 0 ? Math.round((convertedCount / totalLeads) * 100) : 0;

  const firstByLead = new Map<string, number>();
  for (const f of followups) {
    const ms = new Date(f.followupAt).getTime();
    if (Number.isNaN(ms)) continue;
    const prev = firstByLead.get(f.leadId);
    if (prev === undefined || ms < prev) firstByLead.set(f.leadId, ms);
  }

  let sumMinutes = 0;
  let responded = 0;
  for (const lead of leads) {
    const firstMs = firstByLead.get(lead.id);
    if (firstMs === undefined) continue;
    const createdMs = new Date(lead.createdAt).getTime();
    if (Number.isNaN(createdMs)) continue;
    sumMinutes += Math.max(0, (firstMs - createdMs) / 60000);
    responded += 1;
  }

  return {
    thisMonthEnquiries,
    totalLeads,
    convertedCount,
    conversionPercent,
    avgResponseMinutes: responded > 0 ? Math.round(sumMinutes / responded) : null,
  };
}

export function formatAvgResponse(minutes: number | null): string {
  if (minutes === null) return '—';
  if (minutes < 60) return `${Math.max(1, Math.round(minutes))}m`;
  const hours = minutes / 60;
  if (hours < 24) return `${Math.round(hours)}h`;
  const days = Math.round(hours / 24);
  return `${days}d`;
}

export function isNextActionOverdue(
  nextFollowupAt: string | null | undefined,
  stage: LeadStage,
  today = todayISO(),
): boolean {
  if (!nextFollowupAt || stage === 'enrolled' || stage === 'lost') return false;
  return nextFollowupAt.slice(0, 10) < today;
}

export function shortActionDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  return dateShort(iso).replace(/\s\d{4}$/, '');
}

export function normalizePhone10(raw: string | null | undefined): string {
  if (!raw) return '';
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) return digits.slice(2);
  if (digits.length === 11 && digits.startsWith('0')) return digits.slice(1);
  return digits.slice(-10);
}

export function formatClassLabel(value: string | null | undefined): string {
  const v = value?.trim();
  if (!v) return '';
  return /^class\b/i.test(v) ? v : `Class ${v}`;
}

export function leadRowSubtitle(
  lead: Pick<AdmissionLead, 'classInterested' | 'subjectInterest' | 'createdAt'>,
  lastFollowupAt: string | null,
  lastChannel: LeadFollowup['channel'] | null,
): string {
  const parts: string[] = [];
  const cls = formatClassLabel(lead.classInterested);
  if (cls) parts.push(cls);
  if (lead.subjectInterest?.trim()) parts.push(lead.subjectInterest.trim());
  if (lastFollowupAt && lastChannel) {
    const verb = CHANNEL_VERBS[lastChannel] ?? 'followed up';
    parts.push(`${verb} ${relTime(lastFollowupAt)}`);
  } else {
    parts.push(`added ${relTime(lead.createdAt) || 'today'}`);
  }
  return parts.join(' · ');
}

export function leadWhatsAppUrl(phone: string | null | undefined, studentName: string): string | null {
  const digits = normalizePhone10(phone);
  if (digits.length !== 10) return null;
  const text = encodeURIComponent(`Hello, following up on ${studentName}'s admission enquiry.`);
  return `https://wa.me/91${digits}?text=${text}`;
}

export function leadCallUrl(phone: string | null | undefined): string | null {
  const digits = normalizePhone10(phone);
  if (digits.length !== 10) return null;
  return `tel:+91${digits}`;
}

export interface CreateEnquiryErrors {
  studentName?: string;
  phone?: string;
  classInterested?: string;
  nextFollowupDate?: string;
}

export function validateCreateEnquiry(input: {
  studentName: string;
  phone: string;
  classInterested: string;
  nextFollowupDate: string;
}): CreateEnquiryErrors {
  const errors: CreateEnquiryErrors = {};
  if (input.studentName.trim().length < 2) errors.studentName = 'Name must be at least 2 characters';
  if (normalizePhone10(input.phone).length !== 10) errors.phone = 'Enter a valid 10-digit mobile number';
  if (!input.classInterested.trim()) errors.classInterested = 'Choose or enter a class';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.nextFollowupDate)) errors.nextFollowupDate = 'Pick a follow-up date';
  return errors;
}

export interface ConvertLeadErrors {
  studentName?: string;
  phone?: string;
  batchId?: string;
  rollNumber?: string;
  monthlyFee?: string;
}

export function validateConvertLead(input: {
  studentName: string;
  phone: string;
  batchId: string;
  rollNumber: string;
  monthlyFee: string;
  hasBatchPlan: boolean;
}): ConvertLeadErrors {
  const errors: ConvertLeadErrors = {};
  if (input.studentName.trim().length < 2) errors.studentName = 'Name must be at least 2 characters';
  if (normalizePhone10(input.phone).length !== 10) errors.phone = 'Phone must be 10 digits';
  if (!input.batchId) errors.batchId = 'Choose a batch';
  if (input.rollNumber.trim()) {
    const n = Number(input.rollNumber);
    if (!/^\d+$/.test(input.rollNumber.trim()) || !Number.isInteger(n) || n < 1) {
      errors.rollNumber = 'Enter a valid roll number';
    }
  }
  if (!input.hasBatchPlan) {
    const fee = Number(input.monthlyFee);
    if (input.monthlyFee.trim() === '' || !Number.isFinite(fee) || fee < 0) {
      errors.monthlyFee = 'Enter a monthly fee';
    }
  }
  return errors;
}
