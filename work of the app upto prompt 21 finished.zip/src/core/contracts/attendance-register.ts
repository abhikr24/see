import { BackendError } from './errors';
import type {
  AttendanceCorrection,
  AttendanceCorrectionEntry,
  AttendanceRecord,
  AttendanceSession,
  AttendanceStatus,
  CorrectionAccess,
  ID,
  ISODate,
  MonthRegister,
  RegisterCell,
  RegisterDay,
  RegisterRow,
  RegisterStudentRow,
  RegisterSummary,
  RegisterTone,
  Role,
} from './models';

/**
 * Pure rules for the monthly register and its corrections. No React, no
 * backend: the memory adapter, the Supabase adapter and the tests all build
 * the register from raw rows with these functions, so a number on screen can
 * only ever be a number from the records.
 */

/** Corrections to a day older than this many days need the owner. */
export const OWNER_ONLY_AFTER_DAYS = 7;

/** A marked day turns red when at least this share of its records are absent … */
export const RED_ABSENT_SHARE = 0.15;
/** … or amber when at least this share are late. Otherwise it is teal. */
export const AMBER_LATE_SHARE = 0.15;
/** Teal strength by present share: ≥ 95% → 3, ≥ 85% → 2, below → 1. */
export const TEAL_TINT_STEPS: readonly [number, number] = [0.95, 0.85];

const MONTH = /^(\d{4})-(0[1-9]|1[0-2])$/;
const SEVERITY: Record<AttendanceStatus, number> = { present: 0, leave: 1, late: 2, absent: 3 };
const round1 = (value: number): number => Math.round(value * 10) / 10;
const share = (count: number, total: number): number => (total > 0 ? round1((count / total) * 100) : 0);

export function monthBounds(month: string): { from: ISODate; to: ISODate; days: number } {
  const match = MONTH.exec(month);
  if (!match) throw new BackendError('VALIDATION', 'Month must look like 2026-11');
  const year = Number(match[1]);
  const index = Number(match[2]) - 1;
  const days = new Date(Date.UTC(year, index + 1, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${String(days).padStart(2, '0')}`, days };
}

/** Whole days from `date` up to `today` (negative for a future date). */
export function daysBetween(date: ISODate, today: ISODate): number {
  return Math.round((Date.parse(`${today}T00:00:00Z`) - Date.parse(`${date}T00:00:00Z`)) / 86_400_000);
}

export const inMonth = (date: ISODate, month: string): boolean => date.startsWith(`${month}-`);

/** Colour of a marked day, from its own counts. */
export function dayTone(counts: { present: number; late: number; absent: number; total: number }): {
  tone: RegisterTone;
  tint: 1 | 2 | 3 | null;
} {
  const { present, late, absent, total } = counts;
  if (total > 0 && absent / total >= RED_ABSENT_SHARE) return { tone: 'absent', tint: null };
  if (total > 0 && late / total >= AMBER_LATE_SHARE) return { tone: 'late', tint: null };
  const presentShare = total > 0 ? present / total : 0;
  const tint = presentShare >= TEAL_TINT_STEPS[0] ? 3 : presentShare >= TEAL_TINT_STEPS[1] ? 2 : 1;
  return { tone: 'present', tint };
}

export function summarizeCounts(counts: {
  present: number;
  late: number;
  absent: number;
  leave: number;
  markedDays: number;
}): RegisterSummary {
  const total = counts.present + counts.late + counts.absent + counts.leave;
  return {
    total,
    ...counts,
    presentPercent: share(counts.present, total),
    latePercent: share(counts.late, total),
    absentPercent: share(counts.absent, total),
    attendedPercent: share(counts.present + counts.late, total),
  };
}

export interface RegisterStudent {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
}

export interface MonthSource {
  batchId: ID;
  batchName: string;
  month: string;
  today: ISODate;
  /** Everyone who is enrolled or has a record in the batch. */
  students: readonly RegisterStudent[];
  /** The batch's sessions; those outside `month` are ignored. */
  sessions: readonly Pick<AttendanceSession, 'id' | 'date'>[];
  records: readonly AttendanceRecord[];
  corrections: readonly Pick<AttendanceCorrection, 'recordId' | 'status'>[];
}

export function buildMonthRegister(source: MonthSource): MonthRegister {
  const { month, today } = source;
  const bounds = monthBounds(month);
  const dateOf = new Map(source.sessions.filter((s) => inMonth(s.date, month)).map((s) => [s.id, s.date]));
  const corrected = new Set(source.corrections.filter((c) => c.status === 'approved').map((c) => c.recordId));
  const records = source.records.filter((r) => dateOf.has(r.sessionId));

  const perDay = new Map<ISODate, RegisterCell>();
  const perStudent = new Map<ID, RegisterStudentRow>();
  for (const student of source.students) {
    perStudent.set(student.studentId, { ...student, cells: {}, present: 0, late: 0, absent: 0, leave: 0, percent: 0 });
  }
  const weekdayOf = (date: ISODate) => (new Date(`${date}T00:00:00Z`).getUTCDay() + 6) % 7;

  const days: RegisterCell[] = Array.from({ length: bounds.days }, (_, i) => {
    const date = `${month}-${String(i + 1).padStart(2, '0')}`;
    const cell: RegisterCell = {
      date,
      day: i + 1,
      weekday: weekdayOf(date),
      state: date > today ? 'future' : 'unmarked',
      tone: null,
      tint: null,
      present: 0,
      late: 0,
      absent: 0,
      leave: 0,
      total: 0,
      corrected: false,
      isToday: date === today,
    };
    perDay.set(date, cell);
    return cell;
  });

  for (const record of records) {
    const date = dateOf.get(record.sessionId) as ISODate;
    const cell = perDay.get(date) as RegisterCell;
    cell[record.status] += 1;
    cell.total += 1;
    if (corrected.has(record.id)) cell.corrected = true;

    const row = perStudent.get(record.studentId);
    if (row) {
      row[record.status] += 1;
      const held = row.cells[date];
      const wasCorrected = corrected.has(record.id);
      if (!held || SEVERITY[record.status] > SEVERITY[held.status]) {
        row.cells[date] = { status: record.status, corrected: wasCorrected || Boolean(held?.corrected) };
      } else if (wasCorrected) {
        held.corrected = true;
      }
    }
  }

  let markedDays = 0;
  for (const cell of days) {
    if (cell.total === 0) continue;
    cell.state = 'marked';
    markedDays += 1;
    Object.assign(cell, dayTone(cell));
  }

  const students = [...perStudent.values()]
    .map((row) => ({ ...row, percent: share(row.present + row.late, row.present + row.late + row.absent + row.leave) }))
    .sort((a, b) => (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999) || a.fullName.localeCompare(b.fullName));

  const count = (status: AttendanceStatus) => records.filter((r) => r.status === status).length;
  return {
    batchId: source.batchId,
    batchName: source.batchName,
    month,
    startOffset: days[0]?.weekday ?? 0,
    days,
    summary: summarizeCounts({
      present: count('present'),
      late: count('late'),
      absent: count('absent'),
      leave: count('leave'),
      markedDays,
    }),
    students,
  };
}

/** Who may correct which day. The one place the 7-day owner rule lives. */
export function correctionAccess(role: Role | null, date: ISODate, today: ISODate): CorrectionAccess {
  const ageDays = daysBetween(date, today);
  const verdict = (block: CorrectionAccess['block'], message: string | null): CorrectionAccess => ({
    canCorrect: block === null,
    block,
    ageDays,
    message,
  });
  if (ageDays < 0) return verdict('future', 'Attendance for a future date cannot be corrected.');
  if (role !== 'owner' && role !== 'admin' && role !== 'teacher') {
    return verdict('role', 'Sign in as a teacher or the owner to correct attendance.');
  }
  if (ageDays > OWNER_ONLY_AFTER_DAYS && role !== 'owner') {
    return verdict('owner_only', `Corrections older than ${OWNER_ONLY_AFTER_DAYS} days need the owner.`);
  }
  return verdict(null, null);
}

export interface DaySheetSource {
  session: Pick<AttendanceSession, 'id' | 'period' | 'status'>;
  subjectName: string | null;
  records: readonly AttendanceRecord[];
}

export interface DaySource {
  batchId: ID;
  batchName: string;
  date: ISODate;
  today: ISODate;
  role: Role | null;
  students: readonly RegisterStudent[];
  sheets: readonly DaySheetSource[];
  /** Corrections for this batch and date, already joined to names. */
  corrections: readonly AttendanceCorrectionEntry[];
}

export function buildRegisterDay(source: DaySource): RegisterDay {
  const students = new Map(source.students.map((s) => [s.studentId, s]));
  const approved = source.corrections
    .filter((c) => c.status === 'approved')
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
  // The first correction of a record holds the value it was marked with.
  const original = new Map<ID, AttendanceStatus>();
  for (const entry of [...approved].reverse()) {
    if (!original.has(entry.recordId)) original.set(entry.recordId, entry.currentStatus);
  }
  const sheets = [...source.sheets]
    .sort((a, b) => a.session.period - b.session.period)
    .map((sheet) => ({
      sessionId: sheet.session.id,
      period: sheet.session.period,
      subjectName: sheet.subjectName,
      locked: sheet.session.status === 'locked',
      rows: sheet.records
        .map<RegisterRow>((record) => {
          const student = students.get(record.studentId);
          return {
            recordId: record.id,
            studentId: record.studentId,
            fullName: student?.fullName ?? 'Student',
            rollNumber: student?.rollNumber ?? null,
            status: record.status,
            originalStatus: original.get(record.id) ?? null,
            corrected: original.has(record.id),
          };
        })
        .sort((a, b) => (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999) || a.fullName.localeCompare(b.fullName)),
    }));
  return {
    batchId: source.batchId,
    batchName: source.batchName,
    date: source.date,
    sheets,
    corrections: approved,
    access: correctionAccess(source.role, source.date, source.today),
  };
}

export const REASON_MIN = 3;
export const REASON_MAX = 300;

/** The reason as it will be stored, or a VALIDATION error. */
export function cleanReason(reason: string): string {
  const text = reason.replace(/\s+/g, ' ').trim();
  if (text.length < REASON_MIN) throw new BackendError('VALIDATION', 'Add a short note saying what changed.');
  if (text.length > REASON_MAX) throw new BackendError('VALIDATION', `Keep the note under ${REASON_MAX} characters.`);
  return text;
}
