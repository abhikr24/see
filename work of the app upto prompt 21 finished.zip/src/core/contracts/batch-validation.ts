import type { Batch, NewEntity } from './models';
import { BackendError } from './errors';

export function validateBatch(input: NewEntity<Batch, 'name' | 'academicYear'>): void {
  if (!input.name.trim()) throw new BackendError('VALIDATION', 'Enter a batch name.');
  if (input.days && (!input.days.length || input.days.some((d) => !Number.isInteger(d) || d < 0 || d > 6))) {
    throw new BackendError('VALIDATION', 'Choose at least one teaching day.');
  }
  if (input.startsAt || input.endsAt) {
    const valid = (v?: string | null) => !!v && /^([01]\d|2[0-3]):[0-5]\d$/.test(v);
    if (!valid(input.startsAt) || !valid(input.endsAt) || input.endsAt! <= input.startsAt!) {
      throw new BackendError('VALIDATION', 'End time must be after start time (24-hour HH:MM).');
    }
  }
  if (input.feeAmount !== undefined && (!Number.isFinite(input.feeAmount) || input.feeAmount < 0)) {
    throw new BackendError('VALIDATION', 'Fee amount must be zero or more.');
  }
  if (input.capacity !== undefined && input.capacity !== null && (!Number.isInteger(input.capacity) || input.capacity <= 0)) {
    throw new BackendError('VALIDATION', 'Capacity must be a positive whole number.');
  }
}
