/**
 * The only error type that crosses the backend boundary.
 * Adapters translate SDK / network / database failures into a BackendError;
 * the UI switches on `code` and never inspects backend-specific errors.
 */

export const ERROR_CODES = [
  'UNAUTHENTICATED', // no session, or the session expired
  'FORBIDDEN', // signed in, but not allowed to do this
  'NOT_FOUND', // no such record in this institute
  'CONFLICT', // duplicate, or the record changed underneath us
  'VALIDATION', // input rejected before or by the backend
  'RATE_LIMITED',
  'NETWORK', // offline / request never reached the backend
  'TIMEOUT',
  'UNAVAILABLE', // backend is up but cannot serve this right now
  'NOT_IMPLEMENTED', // the adapter does not support this method yet
  'UNKNOWN',
] as const;

export type ErrorCode = (typeof ERROR_CODES)[number];

const DEFAULT_MESSAGES: Record<ErrorCode, string> = {
  UNAUTHENTICATED: 'Please sign in again.',
  FORBIDDEN: 'You do not have permission to do that.',
  NOT_FOUND: 'That record could not be found.',
  CONFLICT: 'That conflicts with an existing record.',
  VALIDATION: 'Some of the details are not valid.',
  RATE_LIMITED: 'Too many requests. Try again shortly.',
  NETWORK: 'No connection. Check your internet and try again.',
  TIMEOUT: 'That took too long. Try again.',
  UNAVAILABLE: 'The service is unavailable right now.',
  NOT_IMPLEMENTED: 'This is not supported by the current backend.',
  UNKNOWN: 'Something went wrong.',
};

export interface BackendErrorOptions {
  /** The original SDK / network error, for logging only. */
  origin?: unknown;
  /** Field-level or backend-specific detail, safe to show in dev tools. */
  details?: Record<string, unknown>;
}

export class BackendError extends Error {
  readonly code: ErrorCode;
  readonly origin?: unknown;
  readonly details?: Record<string, unknown>;

  constructor(code: ErrorCode, message?: string, options: BackendErrorOptions = {}) {
    super(message ?? DEFAULT_MESSAGES[code]);
    Object.setPrototypeOf(this, BackendError.prototype);
    this.name = 'BackendError';
    this.code = code;
    this.origin = options.origin;
    this.details = options.details;
  }
}

export function isBackendError(value: unknown): value is BackendError {
  if (value instanceof BackendError) return true;
  if (typeof value !== 'object' || value === null) return false;
  const candidate = value as { name?: unknown; code?: unknown };
  return candidate.name === 'BackendError' && ERROR_CODES.includes(candidate.code as ErrorCode);
}

/** Wraps anything thrown into a BackendError. Untyped errors become UNKNOWN. */
export function toBackendError(value: unknown): BackendError {
  if (isBackendError(value)) return value;
  const message = value instanceof Error ? value.message : typeof value === 'string' ? value : undefined;
  return new BackendError('UNKNOWN', message, { origin: value });
}
