/**
 * The one place an exam analysis is calculated.
 *
 * Every backend adapter builds its `ExamAnalysis` with `buildExamAnalysis`,
 * so the owner's analysis screen and the student's own results screen always
 * read the same numbers. Nothing here touches a database or React.
 */

import type {
  Exam,
  ExamAnalysis,
  ExamAnalysisStudent,
  ExamScoreBucket,
  ExamSubjectAverage,
  ExamTrendPoint,
  ID,
  Mark,
} from './models';

/** How many bars the class-average mini chart shows. */
export const TREND_LENGTH = 6;
/** How many students the "Top 5" list shows. */
export const TOP_STUDENT_COUNT = 5;
/** How many subject bars the subject-wise section shows. */
export const SUBJECT_BAR_COUNT = 4;

/** The five buckets of the score histogram, as percentages. */
export const SCORE_BUCKETS: { label: string; from: number; to: number }[] = [
  { label: '0–35', from: 0, to: 35 },
  { label: '36–50', from: 36, to: 50 },
  { label: '51–70', from: 51, to: 70 },
  { label: '71–85', from: 71, to: 85 },
  { label: '86–100', from: 86, to: 100 },
];

const BUCKET_EDGES = [35, 50, 70, 85, 100];

export const round1 = (value: number): number => Math.round(value * 10) / 10;
export const round2 = (value: number): number => Math.round(value * 100) / 100;

/** A student as the analysis needs them. */
export interface AnalysisStudent {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
  photoUrl: string | null;
}

/** The class average of one other exam of the batch. */
export interface AnalysisHistoryPoint {
  examId: ID;
  examName: string;
  averagePct: number;
  date: string;
}

/** The class average of one subject of the batch, from the latest exam that has it. */
export interface AnalysisSubjectInput {
  subjectId: ID;
  subjectName: string;
  averagePct: number;
  students: number;
  maxMarks: number;
}

export interface AnalysisInput {
  exam: Exam;
  subjectName: string;
  batchName: string;
  /** Every mark row of this exam, one per student and subject. */
  marks: Mark[];
  /** The students of the batch. */
  students: AnalysisStudent[];
  /** Class average of the other exams of the batch. */
  history: AnalysisHistoryPoint[];
  /** Class average per subject of the batch, from the latest exam that has it. */
  subjectAverages: AnalysisSubjectInput[];
  passPercent: number;
}

/** The grade table used everywhere in the app. */
export function gradeForPercent(percent: number): string {
  if (percent >= 90) return 'A+';
  if (percent >= 80) return 'A';
  if (percent >= 70) return 'B';
  if (percent >= 60) return 'C';
  if (percent >= 50) return 'D';
  if (percent >= 33) return 'E';
  return 'F';
}

/**
 * Competition ranking: equal scores share a rank and the next rank skips.
 * 92, 92, 80 → 1, 1, 3.
 */
export function rankWithTies(scores: number[]): number[] {
  return scores.map((score) => scores.filter((other) => other > score).length + 1);
}

/** Counts the percentages into the five buckets. */
export function bucketPercentages(percentages: number[]): ExamScoreBucket[] {
  const counts = SCORE_BUCKETS.map(() => 0);
  for (const value of percentages) {
    const index = BUCKET_EDGES.findIndex((edge) => value <= edge);
    counts[index < 0 ? BUCKET_EDGES.length - 1 : index] += 1;
  }
  return SCORE_BUCKETS.map((bucket, index) => ({ ...bucket, count: counts[index] }));
}

/** One student's marks of this exam, totalled over their subjects. */
function studentTotals(marks: Mark[]): { obtained: number; max: number; absent: boolean } {
  const obtained = marks.reduce((total, mark) => total + (mark.marksObtained ?? 0), 0);
  const max = marks.reduce((total, mark) => total + mark.maxMarks, 0);
  return { obtained, max, absent: marks.every((mark) => mark.isAbsent) };
}

/** The class average of one subject inside this exam. */
function subjectAveragesFromMarks(marks: Mark[], subjectNames: Map<ID, string>): AnalysisSubjectInput[] {
  const bySubject = new Map<ID, Mark[]>();
  for (const mark of marks) {
    const list = bySubject.get(mark.subjectId) ?? [];
    list.push(mark);
    bySubject.set(mark.subjectId, list);
  }
  return [...bySubject.entries()].map(([subjectId, rows]) => {
    const scored = rows.filter((row) => !row.isAbsent && row.marksObtained !== null);
    const averagePct = scored.length
      ? round1(scored.reduce((total, row) => total + (row.marksObtained ?? 0) / (row.maxMarks || 1) * 100, 0) / scored.length)
      : 0;
    return {
      subjectId,
      subjectName: subjectNames.get(subjectId) ?? 'Subject',
      averagePct,
      students: scored.length,
      maxMarks: rows[0]?.maxMarks ?? 0,
    };
  });
}

/**
 * Builds the whole analysis: every student's line, the ranks (ties share a
 * rank), the class statistics, the subject averages, the distribution and
 * the class-average trend.
 */
export function buildExamAnalysis(input: AnalysisInput): ExamAnalysis {
  const { exam, marks, students, history, subjectAverages, passPercent } = input;

  const marksByStudent = new Map<ID, Mark[]>();
  for (const mark of marks) {
    if (mark.marksObtained === null && !mark.isAbsent) continue;
    const list = marksByStudent.get(mark.studentId) ?? [];
    list.push(mark);
    marksByStudent.set(mark.studentId, list);
  }

  const rows: ExamAnalysisStudent[] = [];
  for (const student of students) {
    const own = marksByStudent.get(student.studentId);
    if (!own || own.length === 0) continue;
    const { obtained, max, absent } = studentTotals(own);
    const percentage = max > 0 ? round2((obtained / max) * 100) : 0;
    rows.push({
      studentId: student.studentId,
      fullName: student.fullName,
      rollNumber: student.rollNumber,
      photoUrl: student.photoUrl,
      marksObtained: obtained,
      maxMarks: max,
      percentage,
      grade: absent ? null : gradeForPercent(percentage),
      rank: null,
      status: absent ? 'absent' : percentage >= passPercent ? 'pass' : 'fail',
    });
  }

  const scored = rows.filter((row) => row.status !== 'absent');
  const ranks = rankWithTies(scored.map((row) => row.marksObtained));
  scored.forEach((row, index) => {
    row.rank = ranks[index];
  });

  rows.sort(
    (a, b) =>
      (a.rank ?? Number.MAX_SAFE_INTEGER) - (b.rank ?? Number.MAX_SAFE_INTEGER) ||
      (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999) ||
      a.fullName.localeCompare(b.fullName),
  );

  const percentages = scored.map((row) => row.percentage);
  const averagePct = percentages.length ? round1(percentages.reduce((a, b) => a + b, 0) / percentages.length) : null;
  const passed = scored.filter((row) => row.status === 'pass').length;
  const passRatePct = scored.length ? round1((passed / scored.length) * 100) : null;

  const orderedTrend = [
    ...history,
    ...(averagePct === null
      ? []
      : [
          {
            examId: exam.id,
            examName: exam.name,
            averagePct,
            date: exam.startsOn ?? exam.createdAt.slice(0, 10),
          },
        ]),
  ].sort((a, b) => a.date.localeCompare(b.date) || a.examId.localeCompare(b.examId));
  const currentIndex = orderedTrend.findIndex((point) => point.examId === exam.id);
  const previous = currentIndex > 0 ? orderedTrend[currentIndex - 1] : null;
  const deltaPct = averagePct !== null && previous ? round1(averagePct - previous.averagePct) : null;

  const subjectNames = new Map<ID, string>();
  for (const average of subjectAverages) subjectNames.set(average.subjectId, average.subjectName);
  for (const mark of marks) if (!subjectNames.has(mark.subjectId)) subjectNames.set(mark.subjectId, 'Subject');

  const ownSubjects = subjectAveragesFromMarks(marks, subjectNames);
  const merged: ExamSubjectAverage[] = [...ownSubjects];
  for (const average of subjectAverages) {
    if (merged.some((row) => row.subjectId === average.subjectId)) continue;
    merged.push(average);
  }
  const orderedSubjects = [
    ...merged.filter((row) => ownSubjects.some((own) => own.subjectId === row.subjectId)),
    ...merged.filter((row) => !ownSubjects.some((own) => own.subjectId === row.subjectId)).sort((a, b) => b.averagePct - a.averagePct),
  ].slice(0, SUBJECT_BAR_COUNT);

  return {
    examId: exam.id,
    examName: exam.name,
    examDate: exam.startsOn,
    subjectName: input.subjectName,
    batchName: input.batchName,
    maxMarks: rows[0]?.maxMarks ?? exam.totalMarks ?? 100,
    passPercent,
    totalStudents: students.length,
    scoredCount: scored.length,
    absentCount: rows.length - scored.length,
    averagePct,
    highestMarks: scored.length ? Math.max(...scored.map((row) => row.marksObtained)) : null,
    lowestMarks: scored.length ? Math.min(...scored.map((row) => row.marksObtained)) : null,
    passRatePct,
    previousExamName: previous?.examName ?? null,
    previousAveragePct: previous?.averagePct ?? null,
    deltaPct,
    students: rows,
    topStudents: rows.slice(0, TOP_STUDENT_COUNT),
    subjectAverages: orderedSubjects,
    distribution: bucketPercentages(percentages),
    trend: orderedTrend.slice(-TREND_LENGTH).map((point) => ({
      examId: point.examId,
      examName: point.examName,
      averagePct: point.averagePct,
      isCurrent: point.examId === exam.id,
    })),
  };
}
