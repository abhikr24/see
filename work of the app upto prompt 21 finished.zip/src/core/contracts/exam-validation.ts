import { BackendError } from './errors';
import type { ISODate } from './models';

const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export const EXAM_MIN_NAME_LEN = 2;
export const EXAM_MIN_MARKS = 1;
export const EXAM_MAX_MARKS = 500;
export const EXAM_MAX_PAST_DAYS = 30;

export interface ExamValidationInput {
  name?: string | null;
  batchId?: string | null;
  subjectId?: string | null;
  startsOn?: ISODate | null;
  totalMarks?: number | null;
}

export interface ExamValidationErrors {
  name?: string;
  batchId?: string;
  subjectId?: string;
  startsOn?: string;
  totalMarks?: string;
}

function addDaysIso(iso: ISODate, days: number): ISODate {
  const dt = new Date(`${iso}T00:00:00Z`);
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

function isRealIsoDate(iso: string): boolean {
  if (!ISO_DATE_RE.test(iso)) return false;
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function getExamValidationErrors(
  input: ExamValidationInput,
  today: ISODate = new Date().toISOString().slice(0, 10),
  requireSubject = false,
): ExamValidationErrors {
  const errors: ExamValidationErrors = {};
  const name = (input.name ?? '').trim();
  if (name.length < EXAM_MIN_NAME_LEN) {
    errors.name = `Exam name must be at least ${EXAM_MIN_NAME_LEN} characters`;
  }
  if (!input.batchId) {
    errors.batchId = 'Choose a batch';
  }
  if (requireSubject && !input.subjectId) {
    errors.subjectId = 'Choose a subject';
  }
  const marks = input.totalMarks;
  if (marks === null || marks === undefined || !Number.isFinite(marks) || marks < EXAM_MIN_MARKS || marks > EXAM_MAX_MARKS) {
    errors.totalMarks = `Max marks must be between ${EXAM_MIN_MARKS} and ${EXAM_MAX_MARKS}`;
  }
  const date = input.startsOn ?? '';
  if (!date || !isRealIsoDate(date)) {
    errors.startsOn = 'Choose a valid exam date';
  } else {
    const earliest = addDaysIso(today, -EXAM_MAX_PAST_DAYS);
    if (date < earliest) {
      errors.startsOn = `Exam date cannot be more than ${EXAM_MAX_PAST_DAYS} days in the past`;
    }
  }
  return errors;
}

export function validateNewExam(
  input: ExamValidationInput,
  today: ISODate = new Date().toISOString().slice(0, 10),
): void {
  const errors = getExamValidationErrors(input, today, false);
  const first = errors.name ?? errors.batchId ?? errors.subjectId ?? errors.totalMarks ?? errors.startsOn;
  if (first) throw new BackendError('VALIDATION', first);
}
