import type { Batch, Enrollment, Guardian, ID, Installment, ParentLink, Payment, Receipt, Student, StudentFee } from './models';

/** All collection aggregates use integer paise. The legacy fee rows are rupees at the adapter boundary. */
export const paise = (rupees: number): number => Math.round(rupees * 100);
export const rupees = (value: number): number => value / 100;
export type FeeTotals = { expected: number; collected: number; pending: number; overdue: number; overdueCount: number };
export type DueRow = { id: ID; studentId: ID; studentFeeId: ID; name: string; photoUrl: string | null; phone: string | null; batch: string; term: string; dueDate: string; daysOverdue: number; amount: number; state: 'overdue' | 'pending' | 'cleared' };
export type RecentPayment = { id: ID; studentId: ID; name: string; photoUrl: string | null; term: string; method: string; date: string; amount: number; receiptId: ID | null };
export type BatchCollection = { id: ID; name: string; expected: number; collected: number };
export type FeeOverview = { totals: FeeTotals; dues: DueRow[]; batches: BatchCollection[]; recent: RecentPayment[] };
export type CollectionRows = { installments: Installment[]; students: Student[]; fees: StudentFee[]; batches: Batch[]; enrollments: Enrollment[]; guardians: Guardian[]; links: ParentLink[]; payments: Payment[]; receipts: Receipt[] };

export function collectionOverview(rows: CollectionRows, today = new Date().toISOString().slice(0, 10)): FeeOverview {
  const students = new Map(rows.students.map(x => [x.id, x]));
  const fees = new Map(rows.fees.map(x => [x.id, x]));
  const batchMap = new Map(rows.batches.map(x => [x.id, x]));
  const enrollment = new Map(rows.enrollments.filter(x => x.status === 'active').map(x => [x.studentId, x.batchId]));
  const guardian = new Map(rows.guardians.map(x => [x.id, x]));
  const parents = new Map(rows.links.filter(x => x.isPrimary).map(x => [x.studentId, guardian.get(x.guardianId)?.phone ?? null]));
  const dueRows: DueRow[] = [];
  const batchAmounts = new Map<ID, BatchCollection>();
  let expected = 0, collected = 0, pending = 0, overdue = 0, overdueCount = 0;
  for (const installment of rows.installments) {
    if (installment.status === 'waived' || fees.get(installment.studentFeeId)?.status === 'cancelled') continue;
    const amount = paise(installment.amount);
    const paid = paise(installment.paidAmount);
    const left = Math.max(0, amount - paid);
    const late = left > 0 && installment.dueDate < today;
    const daysOverdue = late ? Math.floor((Date.parse(`${today}T00:00:00Z`) - Date.parse(`${installment.dueDate}T00:00:00Z`)) / 86400000) : 0;
    expected += amount; collected += paid;
    if (late) { overdue += left; overdueCount++; }
    else pending += left;
    const student = students.get(installment.studentId);
    const batchId = enrollment.get(installment.studentId);
    if (batchId) {
      const current = batchAmounts.get(batchId) ?? { id: batchId, name: batchMap.get(batchId)?.name ?? 'Batch', expected: 0, collected: 0 };
      current.expected += amount; current.collected += paid;
      batchAmounts.set(batchId, current);
    }
    dueRows.push({ id: installment.id, studentId: installment.studentId, studentFeeId: installment.studentFeeId,
      name: student?.fullName ?? 'Student', photoUrl: student?.photoUrl ?? null, phone: parents.get(installment.studentId) ?? student?.phone ?? null,
      batch: batchId ? batchMap.get(batchId)?.name ?? 'Batch' : student?.classGrade ?? 'Student', term: installment.label,
      dueDate: installment.dueDate, daysOverdue, amount: left, state: left === 0 ? 'cleared' : late ? 'overdue' : 'pending' });
  }
  const totals = { expected, collected, pending, overdue, overdueCount };
  if (typeof __DEV__ !== 'undefined' && __DEV__ && collected + pending + overdue !== expected) throw new Error('Fee totals do not reconcile');
  const receipts = new Map(rows.receipts.map(x => [x.paymentId, x.id]));
  const installmentMap = new Map(rows.installments.map(x => [x.id, x]));
  const recent = rows.payments.filter(x => x.status === 'completed').sort((a,b) => b.paidAt.localeCompare(a.paidAt)).slice(0, 8).map(x => ({
    id: x.id, studentId: x.studentId, name: students.get(x.studentId)?.fullName ?? 'Student', photoUrl: students.get(x.studentId)?.photoUrl ?? null,
    term: x.installmentId ? installmentMap.get(x.installmentId)?.label ?? 'Fee' : 'Fee', method: x.method, date: x.paidAt,
    amount: paise(x.amount), receiptId: receipts.get(x.id) ?? null,
  }));
  return { totals, dues: dueRows.sort((a,b) => b.daysOverdue - a.daysOverdue || a.name.localeCompare(b.name)), batches: [...batchAmounts.values()], recent };
}
