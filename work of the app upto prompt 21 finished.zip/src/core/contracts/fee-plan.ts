/**
 * Fee-plan rules — pure, shared by the reference backend, the Supabase adapter,
 * the screen and the tests. No screen or adapter does fee arithmetic itself.
 */
import { inr } from '../../lib/format';
import type {
  FeePlanView,
  FeeStatement,
  FeeStructure,
  ID,
  ISODate,
  Installment,
  Money,
  Payment,
  PlanBatchOption,
  PlanDiscount,
  PlanFrequency,
  PlanInstallment,
  PlanStudentRow,
  StudentFee,
} from './models';

export const round2 = (n: number): number => Math.round(n * 100) / 100;
const paise = (n: number): number => Math.round(n * 100);
const sumOf = (values: number[]): number => round2(values.reduce((a, b) => a + b, 0));

/** How a plan frequency becomes a schedule. */
export const FREQUENCY_PRESETS: Record<PlanFrequency, { count: number; months: number; label: string }> = {
  monthly: { count: 12, months: 1, label: 'Monthly' },
  quarterly: { count: 4, months: 3, label: 'Quarterly' },
  term: { count: 3, months: 4, label: 'Term' },
};
export const FREQUENCY_OPTIONS: PlanFrequency[] = ['monthly', 'quarterly', 'term'];

const ISO = /^\d{4}-\d{2}-\d{2}$/;

export function addMonths(date: ISODate, months: number): ISODate {
  const [y, m, d] = date.split('-').map(Number);
  const target = new Date(Date.UTC(y, m - 1 + months, 1));
  const last = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  target.setUTCDate(Math.min(d, last));
  return target.toISOString().slice(0, 10);
}

/** Splits `total` over `weights` to the paisa; the last share absorbs the rounding. */
export function allocate(total: Money, weights: number[]): number[] {
  if (weights.length === 0) return [];
  const totalPaise = Math.max(0, paise(total));
  const weightSum = weights.reduce((a, b) => a + b, 0);
  const shares = weights.map((w) => (weightSum > 0 ? w / weightSum : 1 / weights.length));
  const out: number[] = [];
  let used = 0;
  shares.forEach((share, i) => {
    const part = i === shares.length - 1 ? totalPaise - used : Math.floor(totalPaise * share);
    used += part;
    out.push(part / 100);
  });
  return out;
}

/** A schedule for a frequency: equal amounts, one per period, from the first due date. */
export function buildSchedule(frequency: PlanFrequency, total: Money, firstDueDate: ISODate): PlanInstallment[] {
  const { count, months } = FREQUENCY_PRESETS[frequency];
  return allocate(total, new Array<number>(count).fill(1)).map((amount, i) => ({
    id: `i${i + 1}`,
    label: `Instalment ${i + 1}`,
    amount,
    dueDate: addMonths(firstDueDate, months * i),
  }));
}

export const scheduleTotal = (schedule: PlanInstallment[]): Money => sumOf(schedule.map((x) => x.amount));

/** What a discount row takes off `gross`. */
export const discountValue = (d: PlanDiscount, gross: Money): Money =>
  d.type === 'percent' ? round2((gross * d.amount) / 100) : round2(d.amount);

export interface AppliedDiscount {
  amount: Money;
  reason: string | null;
  ids: string[];
}

/** The rows a student has, summed and capped so a student never owes less than nothing. */
export function applyDiscounts(discounts: PlanDiscount[], ids: string[], gross: Money): AppliedDiscount {
  const rows = discounts.filter((d) => ids.includes(d.id));
  const amount = Math.min(gross, sumOf(rows.map((d) => discountValue(d, gross))));
  const reason = rows.map((d) => (d.note.trim() ? `${d.label} (${d.note.trim()})` : d.label)).join('; ');
  return { amount, reason: reason || null, ids: rows.map((d) => d.id) };
}

export interface PlanDraft {
  batchIds: ID[];
  totalAmount: Money;
  schedule: PlanInstallment[];
  discounts: PlanDiscount[];
}

export interface PlanProblems {
  ok: boolean;
  /** Plan total vs the sum of the instalments — the rule that blocks Save. */
  total: string | null;
  schedule: string | null;
  batches: string | null;
  rows: Record<string, string>;
  discounts: Record<string, string>;
  /** Live figures shown under the cards. */
  sum: Money;
  difference: Money;
}

/** Every rule that blocks a save. The same verdict the screen shows and the repo enforces. */
export function validatePlan(draft: PlanDraft): PlanProblems {
  const sum = scheduleTotal(draft.schedule);
  const difference = round2(draft.totalAmount - sum);
  const rows: Record<string, string> = {};
  let previous = '';
  for (const row of draft.schedule) {
    if (!row.label.trim()) rows[row.id] = 'Give this instalment a name';
    else if (!(row.amount > 0)) rows[row.id] = 'Enter an amount above ₹0';
    else if (!ISO.test(row.dueDate)) rows[row.id] = 'Pick a due date';
    else if (previous && row.dueDate < previous) rows[row.id] = 'Due before the instalment above it';
    if (ISO.test(row.dueDate)) previous = row.dueDate;
  }
  const discounts: Record<string, string> = {};
  for (const d of draft.discounts) {
    if (!d.label.trim()) discounts[d.id] = 'Give this discount a name';
    else if (!(d.amount > 0)) discounts[d.id] = 'Enter an amount above zero';
    else if (d.type === 'percent' && d.amount > 100) discounts[d.id] = 'A percentage cannot be above 100';
    else if (d.type === 'flat' && d.amount > draft.totalAmount) discounts[d.id] = 'More than the plan total';
  }
  const total = !(draft.totalAmount > 0)
    ? 'Enter the plan total'
    : paise(difference) !== 0
      ? difference > 0
        ? `Instalments add up to ${inr(sum)}, which is ${inr(difference)} short of the total`
        : `Instalments add up to ${inr(sum)}, which is ${inr(-difference)} over the total`
      : null;
  const schedule = draft.schedule.length === 0 ? 'Add at least one instalment' : null;
  const batches = draft.batchIds.length === 0 ? 'Choose at least one batch' : null;
  const ok = !total && !schedule && !batches && Object.keys(rows).length === 0 && Object.keys(discounts).length === 0;
  return { ok, total, schedule, batches, rows, discounts, sum, difference };
}

/** The first problem as a sentence, for the repo to throw. */
export function firstProblem(p: PlanProblems): string | null {
  return p.schedule ?? p.total ?? p.batches ?? Object.values(p.rows)[0] ?? Object.values(p.discounts)[0] ?? null;
}

export type Rebalance = { ok: true; amounts: Map<ID, Money> } | { ok: false; reason: string };

/**
 * Re-cuts a student's unpaid instalments so the fee adds up to `net`.
 * An instalment with money on it is never touched, so receipts stay true.
 */
export function rebalanceInstallments(
  rows: Pick<Installment, 'id' | 'amount' | 'paidAmount'>[],
  net: Money,
): Rebalance {
  const locked = rows.filter((r) => r.paidAmount > 0);
  const free = rows.filter((r) => r.paidAmount <= 0);
  const target = round2(net - sumOf(locked.map((r) => r.amount)));
  if (target < 0) return { ok: false, reason: 'That is more than what is still unpaid on this student' };
  if (free.length === 0 && paise(target) !== 0) {
    return { ok: false, reason: 'Every instalment already has a payment on it, so there is nothing to reduce' };
  }
  const amounts = new Map<ID, Money>(locked.map((r) => [r.id, r.amount]));
  allocate(target, free.map((r) => r.amount)).forEach((amount, i) => amounts.set(free[i].id, amount));
  return { ok: true, amounts };
}

// ---------------------------------------------------------------------------
// Reading: one pure builder per screen, so memory and Supabase agree.
// ---------------------------------------------------------------------------

export interface PlanSource {
  structures: FeeStructure[];
  studentFees: StudentFee[];
  installments: Installment[];
  payments: Payment[];
}

/** True once a student's fee has money on it, whether or not a payment row exists. */
export function feeHasMoney(fee: StudentFee, src: PlanSource): boolean {
  return (
    src.payments.some((p) => p.studentFeeId === fee.id && p.status !== 'failed') ||
    src.installments.some((x) => x.studentFeeId === fee.id && x.paidAmount > 0)
  );
}

export const liveFees = (src: PlanSource, studentId?: ID): StudentFee[] =>
  src.studentFees.filter((f) => f.status !== 'cancelled' && (!studentId || f.studentId === studentId));

/** The active plan that covers a batch. A structure with no schedule is a legacy row, not a plan. */
export function planCovering(structures: FeeStructure[], batchId: ID): FeeStructure | null {
  const covering = structures.filter(
    (s) => s.isActive && s.schedule.length > 0 && (s.batchIds.includes(batchId) || s.batchId === batchId),
  );
  return covering.sort((a, b) => b.version - a.version || b.createdAt.localeCompare(a.createdAt))[0] ?? null;
}

export interface PlanRosterRow {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
}

export interface PlanViewInput {
  batchId: ID;
  batchName: string;
  batches: { id: ID; name: string; studentCount: number }[];
  roster: PlanRosterRow[];
  feeAmount: Money;
  feeFrequency: PlanFrequency;
  today: ISODate;
}

export function buildPlanView(input: PlanViewInput, src: PlanSource): FeePlanView {
  const structure = planCovering(src.structures, input.batchId);
  const lineage: FeeStructure[] = [];
  for (let cur: FeeStructure | undefined = structure ?? undefined; cur; ) {
    lineage.push(cur);
    const at: ID = cur.id;
    cur = src.structures.find((s) => s.supersededById === at);
  }
  const lineageIds = new Set(lineage.map((s) => s.id));
  const fees = liveFees(src);
  const versions = lineage.map((s) => {
    const own = fees.filter((f) => f.feeStructureId === s.id);
    return {
      id: s.id,
      version: s.version,
      isActive: s.isActive,
      totalAmount: s.totalAmount,
      students: own.length,
      withPayments: own.filter((f) => feeHasMoney(f, src)).length,
      createdAt: s.createdAt,
    };
  });
  const batches: PlanBatchOption[] = input.batches.map((b) => {
    const other = planCovering(src.structures, b.id);
    const taken = other && other.id !== structure?.id ? { planId: other.id, planName: other.name } : null;
    return { batchId: b.id, name: b.name, studentCount: b.studentCount, takenBy: taken };
  });
  const students: PlanStudentRow[] = input.roster.map((r) => {
    const own = liveFees(src, r.studentId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const fee = own[0];
    const st = fee ? buildStatement(r.studentId, src) : null;
    return {
      studentId: r.studentId,
      fullName: r.fullName,
      rollNumber: r.rollNumber,
      discountIds: fee?.discountIds ?? [],
      gross: st?.gross ?? 0,
      discount: st?.discount ?? 0,
      net: st?.net ?? 0,
      due: st?.due ?? 0,
      onVersion: fee ? (src.structures.find((s) => s.id === fee.feeStructureId)?.version ?? null) : null,
      hasPayments: own.some((f) => feeHasMoney(f, src)),
      onPlan: fee ? lineageIds.has(fee.feeStructureId) : false,
    };
  });
  return {
    batchId: input.batchId,
    batchName: input.batchName,
    structure,
    versions,
    // Whether saving now must create a new version: only money on the current version counts.
    hasPayments: (versions.find((v) => v.isActive)?.withPayments ?? 0) > 0,
    batches,
    students,
    defaults: {
      frequency: input.feeFrequency,
      totalAmount: input.feeAmount,
      firstDueDate: input.today,
    },
  };
}

/** One student's total, scholarship, paid and due — all from their own fee rows. */
export function buildStatement(studentId: ID, src: PlanSource): FeeStatement | null {
  const fees = liveFees(src, studentId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (fees.length === 0) return null;
  const ids = new Set(fees.map((f) => f.id));
  const installments = src.installments
    .filter((x) => ids.has(x.studentFeeId))
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate) || a.termNo - b.termNo);
  const counted = installments.filter((x) => x.status !== 'waived');
  const structure = src.structures.find((s) => s.id === fees[0].feeStructureId);
  const labels = fees.flatMap((f) => (f.discountReason ? [f.discountReason] : []));
  return {
    studentId,
    planName: structure?.name ?? 'Fee plan',
    version: structure?.version ?? null,
    gross: sumOf(fees.map((f) => f.grossAmount)),
    discount: sumOf(fees.map((f) => f.discountAmount)),
    discountLabels: labels,
    net: sumOf(fees.map((f) => f.netAmount)),
    paid: sumOf(counted.map((x) => x.paidAmount)),
    due: sumOf(counted.map((x) => Math.max(0, x.amount - x.paidAmount))),
    installments,
  };
}
