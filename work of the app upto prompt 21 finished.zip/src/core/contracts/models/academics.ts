import type { ActiveStatus, ID, ISODate, ISODateTime, TenantEntity, TimeOfDay } from './common';

/** A class group, e.g. "Class 10-A". */
export interface Batch extends TenantEntity {
  branchId: ID | null;
  classroomId: ID | null;
  name: string;
  grade: string | null;
  section: string | null;
  academicYear: string;
  capacity: number | null;
  startsOn: ISODate | null;
  endsOn: ISODate | null;
  status: 'upcoming' | 'active' | 'completed' | 'archived';
  subjectId?: ID | null;
  teacherId?: ID | null;
  days?: number[];
  startsAt?: TimeOfDay | null;
  endsAt?: TimeOfDay | null;
  feePlan?: 'monthly' | 'quarterly' | 'term';
  feeAmount?: number;
}

export interface BatchSummary extends Batch {
  subjectName: string;
  teacherName: string;
  teacherPhoto: string | null;
  studentCount: number;
  attendanceTotal: number;
  attendancePct: number;
  pendingFees: number;
}

export interface BatchRosterRow {
  studentId: ID;
  fullName: string;
  photoUrl: string | null;
  rollNumber: number | null;
  attendancePct: number;
  attendanceTotal: number;
}

/** A student's place in a batch. */
export interface Enrollment extends TenantEntity {
  batchId: ID;
  studentId: ID;
  rollNumber: number | null;
  joinedOn: ISODate;
  leftOn: ISODate | null;
  status: 'active' | 'left' | 'transferred';
}

export interface Subject extends TenantEntity {
  name: string;
  code: string;
  color: string | null;
  description: string | null;
  isActive: boolean;
}

/** One weekly period for a batch. A batch's timetable is the list of these. */
export interface Timetable extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  classroomId: ID | null;
  /** 0 = Sunday … 6 = Saturday. */
  dayOfWeek: number;
  startsAt: TimeOfDay;
  endsAt: TimeOfDay;
  validFrom: ISODate | null;
  validTo: ISODate | null;
}

export interface Classroom extends TenantEntity {
  branchId: ID | null;
  name: string;
  capacity: number | null;
  floor: string | null;
  facilities: string[];
  status: ActiveStatus;
}

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'leave';

/** One roll call: a batch, a date and a period. */
export interface AttendanceSession extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  date: ISODate;
  period: number;
  status: 'open' | 'submitted' | 'locked';
  markedBy: ID | null;
  markedAt: ISODateTime | null;
  notes: string | null;
}

/** One student in one roll call. */
export interface AttendanceRecord extends TenantEntity {
  sessionId: ID;
  batchId: ID;
  studentId: ID;
  status: AttendanceStatus;
  remark: string | null;
  markedBy: ID | null;
}

export interface AttendanceSheet {
  session: AttendanceSession;
  records: AttendanceRecord[];
}

export interface AttendanceSummary {
  total: number;
  present: number;
  absent: number;
  late: number;
  leave: number;
  /** (present + late) / total × 100, one decimal. 0 when there are no records. */
  percent: number;
}

/** One student on a roll-call sheet, with the parent to call. */
export interface AttendanceRollStudent {
  studentId: ID;
  fullName: string;
  photoUrl: string | null;
  rollNumber: number | null;
  parentName: string | null;
  parentPhone: string | null;
}

/** Everything the Take Attendance screen needs, read in one call. */
export interface AttendanceRoll {
  batchId: ID;
  batchName: string;
  subjectId: ID | null;
  subjectName: string | null;
  date: ISODate;
  period: number;
  /** Active enrolments, ordered by roll number. */
  students: AttendanceRollStudent[];
  /** The sheet already saved for (batch, date, period), or null for a fresh one. */
  existing: AttendanceSheet | null;
  /** The institute's attendance-alert setting (`settings.features.attendanceAlerts`). */
  alertsEnabled: boolean;
}

/** What `notifyAbsentParents` did. */
export interface AbsenceAlertResult {
  /** Notification rows created now. */
  sent: number;
  /** Absences already notified for this sheet (re-saves never double-notify). */
  alreadySent: number;
  /** Absent students with no parent login to notify. */
  unreachable: number;
  /** True when the institute has attendance alerts switched off; nothing was sent. */
  disabled: boolean;
}
