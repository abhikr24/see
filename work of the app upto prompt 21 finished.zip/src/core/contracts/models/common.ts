/** Shared primitives for every domain model. Nothing here knows about storage. */

export type ID = string;
/** Calendar date, `YYYY-MM-DD`. */
export type ISODate = string;
/** Instant, ISO 8601 with offset. */
export type ISODateTime = string;
/** Wall-clock time, `HH:mm`. */
export type TimeOfDay = string;
/** Amount in the institute's currency, major units (rupees, not paise). */
export type Money = number;

export type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };

export interface Entity {
  id: ID;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}

/** Every record that belongs to one institute. */
export interface TenantEntity extends Entity {
  instituteId: ID;
}

export type Role = 'owner' | 'admin' | 'teacher' | 'student' | 'parent';
export type Gender = 'male' | 'female' | 'other';
export type ActiveStatus = 'active' | 'inactive';

/** A model without the fields the backend owns. */
export type Draft<T> = Omit<T, 'id' | 'instituteId' | 'createdAt' | 'updatedAt'>;

/** Input for creating a record: `Req` keys are mandatory, the backend defaults the rest. */
export type NewEntity<T, Req extends keyof Draft<T> = never> = Pick<Draft<T>, Req> & Partial<Draft<T>>;

/** Input for updating a record. */
export type Patch<T> = Partial<Draft<T>>;

/** Create when `id` is absent, update when present. */
export type Upsert<T, Req extends keyof Draft<T> = never> = NewEntity<T, Req> & { id?: ID };

export interface DateRange {
  from: ISODate;
  to: ISODate;
}
