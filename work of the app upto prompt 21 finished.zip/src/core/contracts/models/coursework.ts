import type { ID, ISODate, ISODateTime, TenantEntity } from './common';

/** Homework set for a batch. */
export interface Assignment extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  title: string;
  instructions: string | null;
  assignedOn: ISODate;
  dueAt: ISODateTime | null;
  maxMarks: number | null;
  submissionType: 'written' | 'upload' | 'online' | 'none';
  status: 'draft' | 'published' | 'closed';
  createdBy: ID | null;
}

/** A student's answer to an assignment. Marks live on Feedback. */
export interface Submission extends TenantEntity {
  assignmentId: ID;
  batchId: ID;
  studentId: ID;
  content: string | null;
  submittedAt: ISODateTime | null;
  status: 'pending' | 'submitted' | 'late' | 'returned';
}

export type AttachmentOwner =
  | 'assignment'
  | 'submission'
  | 'feedback'
  | 'material'
  | 'exam'
  | 'notice'
  | 'doubt'
  | 'conversation'
  | 'leave_request'
  | 'lead'
  | 'receipt'
  | 'student';

/** A stored file belonging to another record. */
export interface Attachment extends TenantEntity {
  ownerType: AttachmentOwner;
  ownerId: ID;
  batchId: ID | null;
  studentId: ID | null;
  fileName: string;
  /** Opaque location inside the backend's storage; resolve with StoragePort.getUrl. */
  storagePath: string;
  mimeType: string | null;
  sizeBytes: number | null;
  uploadedBy: ID | null;
}

/** A teacher's marks and comment on one submission. */
export interface Feedback extends TenantEntity {
  submissionId: ID;
  batchId: ID;
  studentId: ID;
  teacherId: ID | null;
  marksAwarded: number | null;
  grade: string | null;
  comment: string | null;
  givenBy: ID | null;
  givenAt: ISODateTime;
}

/** A dated test set for a batch. */
export interface Exam extends TenantEntity {
  batchId: ID;
  subjectId?: ID | null;
  name: string;
  examType: 'unit_test' | 'weekly_test' | 'mid_term' | 'final' | 'mock' | 'other';
  startsOn: ISODate | null;
  endsOn: ISODate | null;
  totalMarks: number | null;
  passPercent: number;
  status: 'draft' | 'scheduled' | 'ongoing' | 'completed' | 'published';
  publishedAt: ISODateTime | null;
  createdBy: ID | null;
}

export type QuestionType = 'mcq' | 'short' | 'long' | 'numerical';

export interface ExamQuestion extends TenantEntity {
  examId: ID;
  batchId: ID;
  subjectId: ID | null;
  questionNo: number;
  text: string;
  questionType: QuestionType;
  options: string[] | null;
  answerKey: string | null;
  maxMarks: number;
  topic: string | null;
}

/** One student, one subject, one exam. */
export interface Mark extends TenantEntity {
  examId: ID;
  batchId: ID;
  studentId: ID;
  subjectId: ID;
  /** null while not yet entered, or when the student was absent. */
  marksObtained: number | null;
  maxMarks: number;
  isAbsent: boolean;
  grade: string | null;
  remark: string | null;
  enteredBy: ID | null;
}

/** A student's overall outcome in one exam. */
export interface Result extends TenantEntity {
  examId: ID;
  batchId: ID;
  studentId: ID;
  totalObtained: number;
  totalMax: number;
  percentage: number;
  grade: string | null;
  rank: number | null;
  status: 'pass' | 'fail' | 'absent' | 'withheld';
  remarks: string | null;
}

/** One student's line in an exam analysis. */
export interface ExamAnalysisStudent {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
  photoUrl: string | null;
  marksObtained: number;
  maxMarks: number;
  percentage: number;
  grade: string | null;
  /** Equal marks share a rank — 1, 2, 2, 4. */
  rank: number | null;
  status: 'pass' | 'fail' | 'absent';
}

/** The class average for one subject of the batch. */
export interface ExamSubjectAverage {
  subjectId: ID;
  subjectName: string;
  averagePct: number;
  students: number;
  maxMarks: number;
}

/** One bucket of the score histogram. */
export interface ExamScoreBucket {
  label: string;
  from: number;
  to: number;
  count: number;
}

/** One bar of the class-average mini chart. */
export interface ExamTrendPoint {
  examId: ID;
  examName: string;
  averagePct: number;
  isCurrent: boolean;
}

/**
 * Everything the exam analysis shows, in one object.
 *
 * The owner's analysis screen and the student's own results screen read the
 * same object from the same repo method, so a number can never differ
 * between the two.
 */
export interface ExamAnalysis {
  examId: ID;
  examName: string;
  /** The day the exam was taken. */
  examDate: ISODate | null;
  subjectName: string;
  batchName: string;
  maxMarks: number;
  passPercent: number;
  /** Students of the batch. */
  totalStudents: number;
  /** Students with a score. */
  scoredCount: number;
  absentCount: number;
  /** Class average as a percentage. */
  averagePct: number | null;
  highestMarks: number | null;
  lowestMarks: number | null;
  /** Share of the scored students who passed. */
  passRatePct: number | null;
  previousExamName: string | null;
  previousAveragePct: number | null;
  /** Percentage points against the previous exam of the batch. */
  deltaPct: number | null;
  /** Every student, ranked. */
  students: ExamAnalysisStudent[];
  /** The first five of `students`. */
  topStudents: ExamAnalysisStudent[];
  subjectAverages: ExamSubjectAverage[];
  distribution: ExamScoreBucket[];
  /** Class average of the last exams of the batch, oldest first. */
  trend: ExamTrendPoint[];
}
