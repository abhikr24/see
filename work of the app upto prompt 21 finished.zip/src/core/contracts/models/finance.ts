import type { ID, ISODate, ISODateTime, Money, TenantEntity } from './common';

export interface FeeComponent {
  label: string;
  amount: Money;
}

/** One instalment of a plan. `id` is a stable key within the plan, not a database id. */
export interface PlanInstallment {
  id: string;
  label: string;
  amount: Money;
  dueDate: ISODate;
}

/** A named discount or scholarship offered by a plan. Assigned to students one by one. */
export interface PlanDiscount {
  id: string;
  label: string;
  type: 'percent' | 'flat';
  /** Percent (1–100) or rupees, depending on `type`. */
  amount: number;
  note: string;
}

/** A fee plan for a batch and academic year. */
export interface FeeStructure extends TenantEntity {
  batchId: ID | null;
  name: string;
  academicYear: string;
  totalAmount: Money;
  installmentCount: number;
  frequency: 'one_time' | 'monthly' | 'quarterly' | 'term' | 'yearly';
  components: FeeComponent[];
  lateFeePerDay: Money;
  /** False once a newer version replaced this one. */
  isActive: boolean;
  /** 1 for the first plan, +1 each time a plan with payments was changed. */
  version: number;
  /** The version that replaced this one. Null on the current version. */
  supersededById: ID | null;
  /** Every batch the plan applies to (includes `batchId`). */
  batchIds: ID[];
  /** The instalments students are billed on. Always adds up to `totalAmount`. */
  schedule: PlanInstallment[];
  /** Discount and scholarship rows. They reduce a student's due, never `totalAmount`. */
  discounts: PlanDiscount[];
}

/** What one student owes under one fee structure. */
export interface StudentFee extends TenantEntity {
  studentId: ID;
  feeStructureId: ID;
  academicYear: string;
  grossAmount: Money;
  discountAmount: Money;
  discountReason: string | null;
  /** The plan discount rows applied to this student: the individual override. */
  discountIds: string[];
  /** grossAmount − discountAmount. Computed by the backend. */
  netAmount: Money;
  status: 'active' | 'settled' | 'cancelled';
}

export type InstallmentStatus = 'upcoming' | 'due' | 'partial' | 'paid' | 'overdue' | 'waived';

export interface Installment extends TenantEntity {
  studentFeeId: ID;
  studentId: ID;
  termNo: number;
  label: string;
  amount: Money;
  dueDate: ISODate;
  paidAmount: Money;
  paidOn: ISODate | null;
  status: InstallmentStatus;
}

export type PaymentMethod = 'cash' | 'upi' | 'card' | 'bank_transfer' | 'cheque' | 'online';

/** Money received. */
export interface Payment extends TenantEntity {
  studentId: ID;
  studentFeeId: ID;
  installmentId: ID | null;
  amount: Money;
  method: PaymentMethod;
  referenceNo: string | null;
  paidAt: ISODateTime;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  receivedBy: ID | null;
  notes: string | null;
}

/** One per payment, numbered per institute. */
export interface Receipt extends TenantEntity {
  paymentId: ID;
  studentId: ID;
  receiptNo: string;
  amount: Money;
  issuedAt: ISODateTime;
  issuedBy: ID | null;
  /** Storage path of the rendered PDF; resolve with StoragePort.getUrl. */
  pdfPath: string | null;
}

export interface Refund extends TenantEntity {
  paymentId: ID;
  studentId: ID;
  amount: Money;
  reason: string | null;
  method: PaymentMethod | null;
  referenceNo: string | null;
  status: 'requested' | 'approved' | 'processed' | 'rejected';
  requestedBy: ID | null;
  approvedBy: ID | null;
  processedAt: ISODateTime | null;
}

/** Institute-wide fee position. */
export interface FeeSummary {
  billed: Money;
  collected: Money;
  outstanding: Money;
  overdue: Money;
  overdueInstallments: number;
}

/** An online checkout opened with the payment gateway. */
export interface PaymentOrder extends TenantEntity {
  studentId: ID;
  installmentId: ID;
  amount: Money;
  currency: string;
  provider: string;
  providerOrderId: string;
  /** Hosted checkout page, when the provider has one. */
  checkoutUrl: string | null;
  status: 'created' | 'paid' | 'failed' | 'expired';
  /** Set once the order is confirmed and a Payment exists. */
  paymentId: ID | null;
}

// ---------------------------------------------------------------------------
// Fee plans — what the plan screen reads and writes
// ---------------------------------------------------------------------------

export type PlanFrequency = Extract<FeeStructure['frequency'], 'monthly' | 'quarterly' | 'term'>;

/** What the owner submits. `id` is the version being edited; leave it out for a new plan. */
export interface SavePlanInput {
  id?: ID;
  /** The batch the screen was opened for. */
  batchId: ID;
  /** Every batch the plan applies to. Must include `batchId`. */
  batchIds: ID[];
  name?: string;
  frequency: PlanFrequency;
  totalAmount: Money;
  schedule: PlanInstallment[];
  discounts: PlanDiscount[];
}

export interface SavePlanResult {
  structure: FeeStructure;
  /** True when payments existed, so a new version was created instead of editing in place. */
  versioned: boolean;
  /** The version that was replaced, when `versioned`. */
  previousId: ID | null;
  /** Students who now owe the new plan. */
  studentsUpdated: number;
  /** Students who already paid on an older fee and keep it, so their receipts never change. */
  studentsKept: number;
}

export interface PlanBatchOption {
  batchId: ID;
  name: string;
  studentCount: number;
  /** Set when another plan already covers this batch. */
  takenBy: { planId: ID; planName: string } | null;
}

export interface PlanStudentRow {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
  discountIds: string[];
  gross: Money;
  discount: Money;
  net: Money;
  due: Money;
  /** Plan version this student is billed on. Null when they have no fee yet. */
  onVersion: number | null;
  /** True when money was already paid on the student's fee. */
  hasPayments: boolean;
  /** True when the student's fee belongs to this plan (any version). False for an older, separate fee. */
  onPlan: boolean;
}

export interface PlanVersionRow {
  id: ID;
  version: number;
  isActive: boolean;
  totalAmount: Money;
  students: number;
  /** Students on this version who have paid something. */
  withPayments: number;
  createdAt: ISODateTime;
}

export interface FeePlanView {
  batchId: ID;
  batchName: string;
  /** The current version for this batch, or null when none was saved yet. */
  structure: FeeStructure | null;
  versions: PlanVersionRow[];
  /** True when the current version has payments, so saving creates a new version. */
  hasPayments: boolean;
  batches: PlanBatchOption[];
  students: PlanStudentRow[];
  /** Starting values for a batch with no plan yet. */
  defaults: { frequency: PlanFrequency; totalAmount: Money; firstDueDate: ISODate };
}

/** What a student (or their parent) sees in the Fees tab. */
export interface FeeStatement {
  studentId: ID;
  planName: string;
  version: number | null;
  /** Total fee before any scholarship. */
  gross: Money;
  discount: Money;
  discountLabels: string[];
  /** gross − discount: the total this student owes. */
  net: Money;
  paid: Money;
  due: Money;
  installments: Installment[];
}
