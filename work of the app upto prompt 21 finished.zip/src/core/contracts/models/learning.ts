import type { ID, ISODate, ISODateTime, TenantEntity } from './common';

/** Notes, PDFs, videos and links. `batchId` null = whole institute. */
export interface Material extends TenantEntity {
  batchId: ID | null;
  subjectId: ID | null;
  teacherId: ID | null;
  title: string;
  description: string | null;
  materialType: 'notes' | 'pdf' | 'video' | 'link' | 'worksheet' | 'book';
  url: string | null;
  storagePath: string | null;
  topic: string | null;
  isPublished: boolean;
  uploadedBy: ID | null;
}

export type BookmarkTarget = 'material' | 'practice_question' | 'assignment' | 'notice' | 'doubt';

export interface Bookmark extends TenantEntity {
  userId: ID;
  targetType: BookmarkTarget;
  targetId: ID;
  note: string | null;
}

export type Difficulty = 'easy' | 'medium' | 'hard';

/** A question-bank item. */
export interface PracticeQuestion extends TenantEntity {
  batchId: ID | null;
  subjectId: ID | null;
  topic: string | null;
  difficulty: Difficulty;
  questionType: 'mcq' | 'true_false' | 'short';
  text: string;
  options: string[] | null;
  correctAnswer: string | null;
  explanation: string | null;
  marks: number;
  isPublished: boolean;
  createdBy: ID | null;
}

/** An ordered set of practice questions for a batch. */
export interface Quiz extends TenantEntity {
  batchId: ID;
  subjectId: ID | null;
  teacherId: ID | null;
  title: string;
  description: string | null;
  questionIds: ID[];
  durationMinutes: number | null;
  totalMarks: number | null;
  opensAt: ISODateTime | null;
  closesAt: ISODateTime | null;
  status: 'draft' | 'published' | 'closed';
  createdBy: ID | null;
}

export interface QuizAttempt extends TenantEntity {
  quizId: ID;
  batchId: ID;
  studentId: ID;
  attemptNo: number;
  startedAt: ISODateTime;
  submittedAt: ISODateTime | null;
  /** Question id → the student's answer. */
  answers: Record<ID, string>;
  score: number | null;
  maxScore: number | null;
  status: 'in_progress' | 'submitted' | 'graded';
}

/** A to-do item on a student's study plan. */
export interface StudyTask extends TenantEntity {
  studentId: ID;
  subjectId: ID | null;
  title: string;
  notes: string | null;
  dueOn: ISODate | null;
  priority: 'low' | 'medium' | 'high';
  status: 'todo' | 'in_progress' | 'done';
  completedAt: ISODateTime | null;
  source: 'self' | 'teacher' | 'system';
  assignedBy: ID | null;
}

export interface StudentGoal extends TenantEntity {
  studentId: ID;
  subjectId: ID | null;
  title: string;
  description: string | null;
  metric: 'attendance_percent' | 'exam_percent' | 'study_hours' | 'custom';
  targetValue: number | null;
  currentValue: number | null;
  startsOn: ISODate;
  targetDate: ISODate | null;
  status: 'active' | 'achieved' | 'missed' | 'abandoned';
  createdBy: ID | null;
}
