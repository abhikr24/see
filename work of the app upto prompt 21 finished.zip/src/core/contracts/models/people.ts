import type { ActiveStatus, Gender, ID, ISODate, Money, TenantEntity } from './common';

export type StudentStatus = 'active' | 'inactive' | 'alumni' | 'dropped';

export interface Student extends TenantEntity {
  branchId: ID | null;
  admissionNo: string | null;
  fullName: string;
  dateOfBirth: ISODate | null;
  gender: Gender | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  schoolName: string | null;
  classGrade: string | null;
  bloodGroup: string | null;
  photoUrl: string | null;
  admittedOn: ISODate;
  status: StudentStatus;
}

export interface Guardian extends TenantEntity {
  /** Set once the guardian has their own login. */
  membershipId: ID | null;
  fullName: string;
  relation: 'father' | 'mother' | 'guardian' | 'other';
  phone: string | null;
  email: string | null;
  occupation: string | null;
  address: string | null;
}

/** Connects a student record to that student's own login. */
export interface StudentMembership extends TenantEntity {
  studentId: ID;
  membershipId: ID;
  linkedBy: ID | null;
}

/** Connects a student to a guardian. */
export interface ParentLink extends TenantEntity {
  studentId: ID;
  guardianId: ID;
  isPrimary: boolean;
}

/** The public teacher card students can see. HR detail lives on StaffRecord. */
export interface Teacher extends TenantEntity {
  userId: ID | null;
  branchId: ID | null;
  fullName: string;
  specialization: string | null;
  qualification: string | null;
  experienceYears: number | null;
  bio: string | null;
  photoUrl: string | null;
  status: ActiveStatus;
}

export interface BankDetails {
  accountName: string;
  accountNumber: string;
  ifsc: string;
  bankName: string | null;
}

/** HR record. Visible to the owner, staff admins and the person themselves. */
export interface StaffRecord extends TenantEntity {
  userId: ID | null;
  teacherId: ID | null;
  employeeCode: string | null;
  designation: string | null;
  department: string | null;
  employmentType: 'full_time' | 'part_time' | 'contract' | 'visiting';
  joinedOn: ISODate | null;
  leftOn: ISODate | null;
  salaryAmount: Money | null;
  salaryPeriod: 'monthly' | 'hourly' | 'per_class';
  phone: string | null;
  email: string | null;
  emergencyContact: string | null;
  bankDetails: BankDetails | null;
  status: 'active' | 'on_leave' | 'resigned' | 'terminated';
}

/** One teacher's planned vs. delivered teaching for one week. */
export interface Workload extends TenantEntity {
  teacherId: ID;
  weekStart: ISODate;
  periodsAssigned: number;
  periodsTaken: number;
  hoursAssigned: number;
  hoursTaken: number;
  notes: string | null;
}
