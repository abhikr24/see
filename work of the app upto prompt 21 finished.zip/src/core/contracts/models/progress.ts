import type { ID, ISODateTime, Money, TenantEntity } from './common';
import type { AttendanceSummary, Enrollment } from './academics';
import type { Result } from './coursework';
import type { Installment } from './finance';
import type { StudentGoal, StudyTask } from './learning';
import type { Guardian, Student } from './people';

export type RiskLevel = 'none' | 'low' | 'medium' | 'high';

/** A student's computed position at one moment. Produced by ProgressPort, never typed in. */
export interface ProgressSnapshot extends TenantEntity {
  studentId: ID;
  /** The student's current batch, if enrolled. */
  batchId: ID | null;
  computedAt: ISODateTime;
  /** null = nothing recorded yet for that measure. */
  attendancePercent: number | null;
  examPercent: number | null;
  homeworkPercent: number | null;
  latestRank: number | null;
  feeDue: Money;
  overdueInstallments: number;
  openDoubts: number;
  riskLevel: RiskLevel;
}

export type RiskKind = 'low_attendance' | 'low_marks' | 'missing_homework' | 'fee_overdue';

/** A computed warning that a student needs attention. */
export interface RiskAlert extends TenantEntity {
  studentId: ID;
  batchId: ID | null;
  kind: RiskKind;
  severity: Exclude<RiskLevel, 'none'>;
  title: string;
  detail: string;
  /** The measured value that triggered the alert, and the limit it crossed. */
  metricValue: number;
  threshold: number;
  status: 'open' | 'acknowledged' | 'resolved';
  detectedAt: ISODateTime;
  resolvedAt: ISODateTime | null;
}

/** Everything about one student, assembled for the Student 360 screen. */
export interface Student360 {
  student: Student;
  enrollments: Enrollment[];
  guardians: Guardian[];
  snapshot: ProgressSnapshot;
  attendance: AttendanceSummary;
  results: Result[];
  installments: Installment[];
  alerts: RiskAlert[];
  goals: StudentGoal[];
  tasks: StudyTask[];
}
