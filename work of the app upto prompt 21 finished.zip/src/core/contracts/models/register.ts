import type { AttendanceStatus } from './academics';
import type { ID, ISODate, ISODateTime, Role, TenantEntity } from './common';

/** Monthly register, day sheet and attendance corrections. */

export type CorrectionStatus = 'pending' | 'approved' | 'rejected';

/**
 * One change to one attendance record. The record itself takes the new
 * status; this row keeps the status it had (`currentStatus`), the new one,
 * who made the change and the reason, so nothing is ever silently overwritten.
 */
export interface AttendanceCorrection extends TenantEntity {
  recordId: ID;
  batchId: ID;
  studentId: ID;
  requestedBy: ID | null;
  currentStatus: AttendanceStatus;
  requestedStatus: AttendanceStatus;
  reason: string | null;
  status: CorrectionStatus;
  reviewedBy: ID | null;
  reviewedAt: ISODateTime | null;
  reviewNote: string | null;
}

/** A correction with the names and date a person needs to read it. */
export interface AttendanceCorrectionEntry extends AttendanceCorrection {
  date: ISODate;
  period: number;
  studentName: string;
  changedByName: string | null;
  changedByRole: Role | null;
}

/** Colour family of a marked day: teal (present), amber (late) or red (absent). */
export type RegisterTone = 'present' | 'late' | 'absent';

/** One square of the month heatmap. */
export interface RegisterCell {
  date: ISODate;
  /** Day of the month, 1–31. */
  day: number;
  /** 0 = Monday … 6 = Sunday. */
  weekday: number;
  /** `future` after today; `unmarked` when no roll call was saved; otherwise `marked`. */
  state: 'future' | 'unmarked' | 'marked';
  tone: RegisterTone | null;
  /** Strength of the teal for a `present` day: 3 = strongest … 1 = lightest. */
  tint: 1 | 2 | 3 | null;
  present: number;
  late: number;
  absent: number;
  leave: number;
  total: number;
  /** True when any record on this day has an approved correction. */
  corrected: boolean;
  isToday: boolean;
}

/** Month totals. Percentages are shares of all records, one decimal. */
export interface RegisterSummary {
  total: number;
  present: number;
  late: number;
  absent: number;
  leave: number;
  markedDays: number;
  presentPercent: number;
  latePercent: number;
  absentPercent: number;
  /** (present + late) / total — the same figure `summary()` reports for a student. */
  attendedPercent: number;
}

export interface RegisterStudentRow {
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
  /** Status per date. With several periods in a day, the most severe one. */
  cells: Record<ISODate, { status: AttendanceStatus; corrected: boolean }>;
  present: number;
  late: number;
  absent: number;
  leave: number;
  percent: number;
}

export interface MonthRegister {
  batchId: ID;
  batchName: string;
  /** `YYYY-MM`. */
  month: string;
  /** Empty squares before day 1 in a Monday-first grid. */
  startOffset: number;
  days: RegisterCell[];
  summary: RegisterSummary;
  students: RegisterStudentRow[];
}

export interface RegisterRow {
  recordId: ID;
  studentId: ID;
  fullName: string;
  rollNumber: number | null;
  status: AttendanceStatus;
  /** The status first recorded, when this row has been corrected; otherwise null. */
  originalStatus: AttendanceStatus | null;
  corrected: boolean;
}

export interface RegisterSheet {
  sessionId: ID;
  period: number;
  subjectName: string | null;
  locked: boolean;
  rows: RegisterRow[];
}

/** Why a day can or cannot be corrected by the signed-in person. */
export type CorrectionBlock = 'future' | 'role' | 'owner_only';

export interface CorrectionAccess {
  canCorrect: boolean;
  block: CorrectionBlock | null;
  /** Whole days between the date and today. */
  ageDays: number;
  message: string | null;
}

/** One day of the register: every sheet, the access verdict and its correction history. */
export interface RegisterDay {
  batchId: ID;
  batchName: string;
  date: ISODate;
  sheets: RegisterSheet[];
  /** Newest first. */
  corrections: AttendanceCorrectionEntry[];
  access: CorrectionAccess;
}
