import type { ID, ISODate, TimeOfDay } from './common';

/** One of the signed-in teacher's own batches, as the My Classes card shows it. */
export interface TeacherClass {
  batchId: ID;
  name: string;
  subjectId: ID | null;
  subjectName: string | null;
  /** 0 = Sunday … 6 = Saturday, ascending. */
  days: number[];
  startsAt: TimeOfDay | null;
  endsAt: TimeOfDay | null;
  roomName: string | null;
  studentCount: number;
  /** (present + late) / records × 100, one decimal. null until a roll call is saved. */
  attendancePercent: number | null;
  /** Submissions handed in and not yet returned with marks. */
  pendingSubmissions: number;
}

/** One period the teacher takes today, in one of their own batches. */
export interface TeacherPeriod {
  /** The timetable row. */
  id: ID;
  batchId: ID;
  batchName: string;
  subjectId: ID | null;
  subjectName: string | null;
  roomName: string | null;
  startsAt: TimeOfDay;
  endsAt: TimeOfDay;
  studentCount: number;
  /** The roll-call period to open: 1 in daily mode, the period's ordinal for its batch in period mode. */
  period: number;
  /** A roll call is already saved for (batch, today, period). */
  attendanceMarked: boolean;
}

/** One homework set with submissions waiting to be graded. */
export interface TeacherPendingWork {
  assignmentId: ID;
  title: string;
  batchId: ID;
  batchName: string;
  count: number;
}

/** Everything the teacher's Home tab shows, read in one call. */
export interface TeacherHome {
  date: ISODate;
  /** The teacher's own active batches. 0 tells "nothing assigned yet" apart from a quiet day. */
  classCount: number;
  /** Today's periods, ordered by start time. */
  periods: TeacherPeriod[];
  /** Published homework in the teacher's batches that falls due today. */
  homeworkDue: number;
  submissionsToGrade: number;
  /** Where those submissions are, oldest due date first. */
  pending: TeacherPendingWork[];
  /** The batch in session now, else the next one today, else the first own batch. */
  currentBatchId: ID | null;
}

export type FallingKind = 'attendance' | 'marks';

/** One measure that dropped, with the two values compared. */
export interface FallingSignal {
  kind: FallingKind;
  /** Percent before, one decimal. */
  from: number;
  /** Percent now, one decimal. */
  to: number;
  /** `from − to`, in percentage points. */
  drop: number;
  /** One line, e.g. "Attendance fell from 93% to 86%". */
  reason: string;
  /** The counts behind the two percentages. */
  detail: string;
}

/** A student in one of the caller's batches whose attendance or marks are falling. */
export interface FallingStudent {
  studentId: ID;
  fullName: string;
  photoUrl: string | null;
  batchId: ID;
  batchName: string;
  rollNumber: number | null;
  /** Largest drop first. Never empty. */
  signals: FallingSignal[];
}
