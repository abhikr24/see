import type { ActiveStatus, Entity, Gender, ID, ISODate, ISODateTime, Money, Role, TenantEntity } from './common';

export interface InstituteSettings {
  academicYear: string | null;
  timezone: string;
  currency: string;
  locale: string;
  /** 0 = Sunday … 6 = Saturday. */
  workingDays: number[];
  attendanceMode: 'daily' | 'period';
  minAttendancePercent: number;
  passPercent: number;
  lateFeePerDay: Money;
  receiptPrefix: string | null;
  allowJoinRequests: boolean;
  features: Record<string, boolean>;
}

/** The tenant. `code` is the join code people type to find it. */
export interface Institute extends Entity {
  name: string;
  code: string;
  ownerId: ID;
  tagline: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  pincode: string | null;
  country: string;
  logoUrl: string | null;
  status: 'active' | 'suspended' | 'archived';
  settings: InstituteSettings;
}

export interface Branch extends TenantEntity {
  name: string;
  code: string;
  address: string | null;
  city: string | null;
  state: string | null;
  pincode: string | null;
  phone: string | null;
  isMain: boolean;
  status: ActiveStatus;
}

/** Powers an owner can delegate to an admin. */
export type Permission = 'institute' | 'members' | 'staff' | 'fees' | 'leads' | 'billing' | 'audit';
export type MembershipStatus = 'pending' | 'active' | 'suspended' | 'rejected';
/** Roles a person may ask for themselves. */
export type JoinRole = Extract<Role, 'teacher' | 'student' | 'parent'>;

/** A person's place in one institute. One per person per institute. */
export interface Membership extends TenantEntity {
  userId: ID;
  branchId: ID | null;
  role: Role;
  status: MembershipStatus;
  permissions: Permission[];
  requestNote: string | null;
  requestedAt: ISODateTime;
  decidedBy: ID | null;
  decidedAt: ISODateTime | null;
}

/** The signed-in person's own details. Not tied to an institute. */
export interface Profile extends Entity {
  userId: ID;
  fullName: string;
  email: string | null;
  phone: string | null;
  avatarUrl: string | null;
  gender: Gender | null;
  dateOfBirth: ISODate | null;
  city: string | null;
  state: string | null;
  bio: string | null;
}

export interface Invitation extends TenantEntity {
  email: string | null;
  phone: string | null;
  fullName: string | null;
  role: Exclude<Role, 'owner'>;
  status: 'pending' | 'accepted' | 'revoked' | 'expired';
  invitedBy: ID | null;
  expiresAt: ISODateTime;
  acceptedBy: ID | null;
  acceptedAt: ISODateTime | null;
}

export interface AuthUser {
  id: ID;
  email: string | null;
  phone: string | null;
}

export interface AuthSession {
  user: AuthUser;
  profile: Profile;
  /** Membership in the institute the session was read for; null if none or no institute given. */
  membership: Membership | null;
  expiresAt: ISODateTime | null;
}

export interface OtpChallenge {
  challengeId: string;
  expiresAt: string;
  channel: 'sms' | 'email';
}
