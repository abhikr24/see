import type {
  AbsenceAlertResult,
  AttendanceRecord,
  AttendanceRoll,
  AttendanceSession,
  AttendanceSheet,
  AttendanceStatus,
  AttendanceSummary,
  Batch,
  BatchSummary,
  BatchRosterRow,
  AttendanceCorrectionEntry,
  Classroom,
  Enrollment,
  ID,
  ISODate,
  MonthRegister,
  RegisterDay,
  Subject,
  TeacherClass,
  Timetable,
  Upsert,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo } from './common';

/**
 * Teacher scoping. When the caller's active membership is a teacher's, every
 * read here (`list`, `get`, `listSummaries`, `listRoster`, `listEnrollments`,
 * `listMine`, `listMyClasses`) covers only the batches that teacher is the
 * assigned teacher of. Another teacher's batch id behaves exactly like an id
 * that does not exist: `NOT_FOUND`. The rule lives in the adapter's query,
 * never in a screen.
 */
export interface BatchRepo extends CrudRepo<Batch, 'name' | 'academicYear'> {
  /** Aggregated by the backend, never by a card's student-fetch loop. */
  listSummaries(instituteId: ID): Promise<BatchSummary[]>;
  listRoster(instituteId: ID, batchId: ID): Promise<BatchRosterRow[]>;
  /**
   * Batches the caller is the assigned teacher of, studies in, or (as a parent)
   * has a child in. Owners and staff admins get all.
   */
  listMine(instituteId: ID): Promise<Batch[]>;
  /**
   * The signed-in teacher's own batches as cards: schedule, room, attendance
   * and submissions waiting to be graded. `FORBIDDEN` for a caller who is not a teacher.
   */
  listMyClasses(instituteId: ID): Promise<TeacherClass[]>;
  listEnrollments(instituteId: ID, batchId: ID): Promise<Enrollment[]>;
  enroll(instituteId: ID, batchId: ID, input: { studentId: ID; rollNumber?: number | null }): Promise<Enrollment>;
  /** Marks the enrolment as left; history is kept. */
  unenroll(instituteId: ID, enrollmentId: ID): Promise<Enrollment>;
}

export type SubjectRepo = CrudRepo<Subject, 'name' | 'code'>;

export interface TimetableRepo extends CrudRepo<Timetable, 'batchId' | 'dayOfWeek' | 'startsAt' | 'endsAt'> {
  /** Periods on one weekday, ordered by start time. */
  listForDay(instituteId: ID, filter: { dayOfWeek: number; batchId?: ID; teacherId?: ID }): Promise<Timetable[]>;
  listClassrooms(instituteId: ID): Promise<Classroom[]>;
  saveClassroom(instituteId: ID, input: Upsert<Classroom, 'name'>): Promise<Classroom>;
  removeClassroom(instituteId: ID, id: ID): Promise<void>;
}

export interface AttendanceSheetInput {
  batchId: ID;
  date: ISODate;
  /** Defaults to 1. */
  period?: number;
  subjectId?: ID | null;
  teacherId?: ID | null;
  notes?: string | null;
  records: { studentId: ID; status: AttendanceStatus; remark?: string | null }[];
}

export interface AttendanceFilter {
  studentId?: ID;
  batchId?: ID;
  from?: ISODate;
  to?: ISODate;
}

/** Batch-scoped methods follow the BatchRepo teacher rule: another teacher's batch is `NOT_FOUND`. */
export interface AttendanceRepo {
  listSessions(instituteId: ID, query?: ListQuery<AttendanceSession>): Promise<Page<AttendanceSession>>;
  getSheet(instituteId: ID, sessionId: ID): Promise<AttendanceSheet>;
  /** Creates or overwrites the roll call for (batch, date, period) in one call. */
  saveSheet(instituteId: ID, input: AttendanceSheetInput): Promise<AttendanceSheet>;
  listRecords(instituteId: ID, filter: AttendanceFilter): Promise<AttendanceRecord[]>;
  summary(instituteId: ID, filter: AttendanceFilter): Promise<AttendanceSummary>;
  /**
   * Roster + parents + the sheet already saved for (batch, date, period), in one read.
   * `subjectId` names the period when the caller knows it (e.g. from a timetable row).
   */
  openRoll(instituteId: ID, input: AttendanceRollInput): Promise<AttendanceRoll>;
  /** Every saved sheet on one date (optionally one batch), with its records. */
  listSheets(instituteId: ID, filter: { date: ISODate; batchId?: ID }): Promise<AttendanceSheet[]>;
  /**
   * One in-app notification per absent student's parent login, gated by the
   * institute's attendance-alert setting. Idempotent per (sheet, student, parent).
   */
  notifyAbsentParents(instituteId: ID, sessionId: ID): Promise<AbsenceAlertResult>;
  /**
   * One batch, one month: the heatmap cells, the three summary rows and the
   * per-student grid the CSV is written from. Every figure is computed here.
   */
  monthRegister(instituteId: ID, input: MonthRegisterInput): Promise<MonthRegister>;
  /** One day of the register: its sheets, who may correct it, and its correction history. */
  registerDay(instituteId: ID, input: { batchId: ID; date: ISODate }): Promise<RegisterDay>;
  /**
   * Changes attendance records after the fact. Each change keeps the old
   * status in an `attendance_corrections` row (who, what, why) and writes an
   * audit-log row; the original is never lost. Days older than 7 days need the
   * owner role. All-or-nothing.
   */
  correctAttendance(instituteId: ID, input: CorrectionInput): Promise<AttendanceCorrectionEntry[]>;
}

export interface MonthRegisterInput {
  batchId: ID;
  /** `YYYY-MM`. */
  month: string;
}

export interface CorrectionInput {
  batchId: ID;
  date: ISODate;
  changes: { recordId: ID; status: AttendanceStatus }[];
  /** A note about what changed. Required. */
  reason: string;
}

export interface AttendanceRollInput {
  batchId: ID;
  date: ISODate;
  period?: number;
  subjectId?: ID | null;
}
