import type { Draft, ID, NewEntity, Patch } from '../models';
import type { ListQuery, Page } from '../query';

/**
 * Rules every port follows:
 *  · every method is async and rejects only with a BackendError
 *  · the first argument is the institute the call is scoped to
 *  · a record from another institute is NOT_FOUND, never returned
 */

export interface ReadRepo<T extends object> {
  list(instituteId: ID, query?: ListQuery<T>): Promise<Page<T>>;
  get(instituteId: ID, id: ID): Promise<T>;
}

/** `Req` = the fields a caller must supply on create; the backend defaults the rest. */
export interface CrudRepo<T extends object, Req extends keyof Draft<T> = never> extends ReadRepo<T> {
  create(instituteId: ID, input: NewEntity<T, Req>): Promise<T>;
  update(instituteId: ID, id: ID, patch: Patch<T>): Promise<T>;
  remove(instituteId: ID, id: ID): Promise<void>;
}
