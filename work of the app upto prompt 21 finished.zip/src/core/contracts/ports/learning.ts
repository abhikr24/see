import type {
  Bookmark,
  FallingStudent,
  ID,
  Material,
  NewEntity,
  PracticeQuestion,
  ProgressSnapshot,
  Quiz,
  QuizAttempt,
  RiskAlert,
  Student360,
  StudentGoal,
  StudyTask,
  Upsert,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo } from './common';

export interface MaterialRepo extends CrudRepo<Material, 'title'> {
  listBookmarks(instituteId: ID, userId: ID): Promise<Bookmark[]>;
  addBookmark(instituteId: ID, input: NewEntity<Bookmark, 'userId' | 'targetType' | 'targetId'>): Promise<Bookmark>;
  removeBookmark(instituteId: ID, id: ID): Promise<void>;
}

export interface PracticeRepo {
  listQuestions(instituteId: ID, query?: ListQuery<PracticeQuestion>): Promise<Page<PracticeQuestion>>;
  saveQuestion(instituteId: ID, input: Upsert<PracticeQuestion, 'text'>): Promise<PracticeQuestion>;
  removeQuestion(instituteId: ID, id: ID): Promise<void>;
  listQuizzes(instituteId: ID, query?: ListQuery<Quiz>): Promise<Page<Quiz>>;
  saveQuiz(instituteId: ID, input: Upsert<Quiz, 'batchId' | 'title'>): Promise<Quiz>;
  listAttempts(instituteId: ID, filter?: { quizId?: ID; studentId?: ID }): Promise<QuizAttempt[]>;
  startAttempt(instituteId: ID, quizId: ID, studentId: ID): Promise<QuizAttempt>;
  /** Stores the answers and scores the attempt on the backend. */
  submitAttempt(instituteId: ID, attemptId: ID, answers: Record<ID, string>): Promise<QuizAttempt>;
}

/**
 * Student 360 and early-warning alerts. Everything here is derived from
 * attendance, marks, homework and fees – the UI never does this arithmetic.
 * Study tasks and goals live here too: they are the student's side of the plan.
 */
export interface ProgressPort {
  /** Recomputes the snapshot and returns the whole picture for one student. */
  getStudent360(instituteId: ID, studentId: ID): Promise<Student360>;
  computeSnapshot(instituteId: ID, studentId: ID): Promise<ProgressSnapshot>;
  /** Past snapshots, newest first. */
  listSnapshots(instituteId: ID, studentId: ID): Promise<ProgressSnapshot[]>;
  listAlerts(instituteId: ID, query?: ListQuery<RiskAlert>): Promise<Page<RiskAlert>>;
  /** Re-evaluates the risk rules; opens new alerts and resolves ones that no longer apply. */
  computeAlerts(instituteId: ID, filter?: { batchId?: ID; studentId?: ID }): Promise<RiskAlert[]>;
  setAlertStatus(instituteId: ID, alertId: ID, status: RiskAlert['status']): Promise<RiskAlert>;
  /**
   * Students whose attendance or marks are falling (rules: `FALLING_RULES` in
   * core/contracts/teacher.ts), biggest drop first. A teacher gets only the
   * students of the batches they are the assigned teacher of; an owner or
   * admin gets every batch; a student or parent is `FORBIDDEN`.
   */
  listFallingStudents(instituteId: ID): Promise<FallingStudent[]>;
  listTasks(instituteId: ID, studentId: ID): Promise<StudyTask[]>;
  saveTask(instituteId: ID, input: Upsert<StudyTask, 'studentId' | 'title'>): Promise<StudyTask>;
  removeTask(instituteId: ID, id: ID): Promise<void>;
  listGoals(instituteId: ID, studentId: ID): Promise<StudentGoal[]>;
  saveGoal(instituteId: ID, input: Upsert<StudentGoal, 'studentId' | 'title'>): Promise<StudentGoal>;
}
