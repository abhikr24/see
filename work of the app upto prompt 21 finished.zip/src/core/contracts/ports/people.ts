import type {
  Guardian,
  ID,
  ISODate,
  ParentLink,
  StaffRecord,
  Student,
  StudentMembership,
  Teacher,
  Upsert,
  Workload,
} from '../models';
import type { ListQuery, Page } from '../query';
import type { CrudRepo } from './common';

export interface StaffRepo extends CrudRepo<StaffRecord> {
  listTeachers(instituteId: ID, query?: ListQuery<Teacher>): Promise<Page<Teacher>>;
  saveTeacher(instituteId: ID, input: Upsert<Teacher, 'fullName'>): Promise<Teacher>;
  listWorkloads(instituteId: ID, filter?: { teacherId?: ID; weekStart?: ISODate }): Promise<Workload[]>;
  saveWorkload(instituteId: ID, input: Upsert<Workload, 'teacherId' | 'weekStart'>): Promise<Workload>;
}

export interface StudentRepo extends CrudRepo<Student, 'fullName'> {
  /** Students currently enrolled in the batch, by roll number. */
  listByBatch(instituteId: ID, batchId: ID): Promise<Student[]>;
  /** The caller's own student record (student) or their children (parent). */
  listMine(instituteId: ID): Promise<Student[]>;
  getLogin(instituteId: ID, studentId: ID): Promise<StudentMembership | null>;
  /** Attach a student-role membership to the student record. */
  linkLogin(instituteId: ID, studentId: ID, membershipId: ID): Promise<StudentMembership>;
  unlinkLogin(instituteId: ID, studentId: ID): Promise<void>;
}

export interface GuardianRepo extends CrudRepo<Guardian, 'fullName'> {
  listForStudent(instituteId: ID, studentId: ID): Promise<Guardian[]>;
  listLinks(instituteId: ID, filter?: { studentId?: ID; guardianId?: ID }): Promise<ParentLink[]>;
  link(instituteId: ID, input: { studentId: ID; guardianId: ID; isPrimary?: boolean }): Promise<ParentLink>;
  unlink(instituteId: ID, linkId: ID): Promise<void>;
}
