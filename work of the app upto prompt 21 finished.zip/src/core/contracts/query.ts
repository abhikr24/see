/**
 * Backend-neutral list query. Fields are model property names (camelCase),
 * never column names; each adapter maps them to its own storage.
 */

export type SortDirection = 'asc' | 'desc';

export interface ListQuery<T extends object = Record<string, unknown>> {
  /** Equality filters. Keys with an `undefined` value are ignored. */
  where?: Partial<T>;
  /** Free-text search over the model's text fields. */
  search?: string;
  sort?: { field: Extract<keyof T, string>; direction?: SortDirection };
  /** Page size. Adapters apply DEFAULT_PAGE_SIZE when omitted and cap at MAX_PAGE_SIZE. */
  limit?: number;
  /** Opaque cursor from the previous page's `nextCursor`. */
  cursor?: string | null;
}

export interface Page<T> {
  items: T[];
  /** null when there are no more pages. */
  nextCursor: string | null;
  /** Total matching rows, or null when the backend cannot count cheaply. */
  total: number | null;
}

export const DEFAULT_PAGE_SIZE = 50;
export const MAX_PAGE_SIZE = 200;

export function emptyPage<T>(): Page<T> {
  return { items: [], nextCursor: null, total: 0 };
}

export function pageSize(query?: { limit?: number }): number {
  const requested = query?.limit ?? DEFAULT_PAGE_SIZE;
  return Math.max(1, Math.min(MAX_PAGE_SIZE, Math.floor(requested)));
}
