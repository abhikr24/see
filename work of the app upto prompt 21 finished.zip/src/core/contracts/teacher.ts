import type {
  Assignment,
  AttendanceRecord,
  AttendanceSession,
  Batch,
  Classroom,
  Enrollment,
  Exam,
  FallingSignal,
  FallingStudent,
  ID,
  ISODate,
  Result,
  Student,
  Subject,
  Submission,
  TeacherClass,
  TeacherHome,
  TeacherPendingWork,
  TeacherPeriod,
  Timetable,
} from './models';

/**
 * The teacher's Home and My Classes figures, and the "falling" rules.
 *
 * Pure: both adapters load the rows of the teacher's OWN batches (the scoping
 * is theirs, in the query) and hand them here, so no screen and no adapter
 * counts, averages or words any of this twice.
 */

/** When a student counts as "falling". Change the numbers here, nowhere else. */
export const FALLING_RULES = {
  /** Roll calls in each of the two windows compared (latest N against the N before). */
  ATTENDANCE_WINDOW: 14,
  /** Fewer roll calls than this in either window is too little to call a trend. */
  ATTENDANCE_MIN_RECORDS: 5,
  /** Attendance must drop by at least this many percentage points between the windows. */
  ATTENDANCE_DROP: 5,
  /** The latest published exam must be at least this many points below the one before it. */
  MARKS_DROP: 10,
} as const;

/** Rows of the teacher's own batches. Everything is already tenant- and teacher-scoped. */
export interface TeacherRows {
  batches: Batch[];
  /** Every period of those batches, any weekday, any teacher. */
  periods: Timetable[];
  subjects: Subject[];
  classrooms: Classroom[];
  /** Active enrolments in those batches. */
  enrollments: Enrollment[];
  sessions: AttendanceSession[];
  records: AttendanceRecord[];
  assignments: Assignment[];
  submissions: Submission[];
}

export interface TeacherHomeInput extends TeacherRows {
  today: ISODate;
  /** Local wall-clock `HH:MM`, to pick the batch in session. */
  now: string;
  /** The teacher's own profile id; null when the login has no teacher profile. */
  teacherId: ID | null;
  /** `settings.attendanceMode === 'period'`. */
  perPeriod: boolean;
}

export interface FallingInput {
  batches: Batch[];
  enrollments: Enrollment[];
  students: Student[];
  sessions: AttendanceSession[];
  records: AttendanceRecord[];
  /** Published exams only. */
  exams: Exam[];
  results: Result[];
}

const round1 = (value: number): number => Math.round(value * 10) / 10;
const whole = (value: number): string => `${Math.round(value)}%`;
const attended = (record: AttendanceRecord): boolean => record.status === 'present' || record.status === 'late';
const isLive = (batch: Batch): boolean => batch.status === 'active' || batch.status === 'upcoming';
const byStart = (a: Timetable, b: Timetable): number =>
  a.dayOfWeek - b.dayOfWeek || a.startsAt.localeCompare(b.startsAt);

export const dayOfWeekOf = (date: ISODate): number => new Date(`${date}T00:00:00Z`).getUTCDay();

function lookups(rows: TeacherRows) {
  const subjects = new Map(rows.subjects.map((s) => [s.id, s.name]));
  const rooms = new Map(rows.classrooms.map((c) => [c.id, c.name]));
  const headcount = new Map<ID, number>();
  for (const e of rows.enrollments) headcount.set(e.batchId, (headcount.get(e.batchId) ?? 0) + 1);
  const periodsOf = (batchId: ID) => rows.periods.filter((p) => p.batchId === batchId).sort(byStart);
  return { subjects, rooms, headcount, periodsOf };
}

/** Handed in and not yet returned: what the teacher still has to grade, per assignment. */
function pendingWork(rows: TeacherRows): TeacherPendingWork[] {
  const batchNames = new Map(rows.batches.map((b) => [b.id, b.name]));
  return rows.assignments
    .filter((a) => a.status !== 'draft' && batchNames.has(a.batchId))
    .sort((a, b) => (a.dueAt ?? '9999').localeCompare(b.dueAt ?? '9999') || a.title.localeCompare(b.title))
    .map((a) => ({
      assignmentId: a.id,
      title: a.title,
      batchId: a.batchId,
      batchName: batchNames.get(a.batchId) ?? '',
      count: rows.submissions.filter(
        (s) => s.assignmentId === a.id && (s.status === 'submitted' || s.status === 'late'),
      ).length,
    }))
    .filter((work) => work.count > 0);
}

/** My Classes: one card per own batch that is running or about to. */
export function buildTeacherClasses(rows: TeacherRows): TeacherClass[] {
  const { subjects, rooms, headcount, periodsOf } = lookups(rows);
  const pending = pendingWork(rows);
  return rows.batches
    .filter(isLive)
    .sort((a, b) => a.name.localeCompare(b.name))
    .map((batch) => {
      const periods = periodsOf(batch.id);
      const first = periods[0];
      const subjectId = batch.subjectId ?? first?.subjectId ?? null;
      const roomId = batch.classroomId ?? first?.classroomId ?? null;
      const records = rows.records.filter((r) => r.batchId === batch.id);
      return {
        batchId: batch.id,
        name: batch.name,
        subjectId,
        subjectName: subjectId ? (subjects.get(subjectId) ?? null) : null,
        days: batch.days?.length
          ? [...batch.days].sort((a, b) => a - b)
          : [...new Set(periods.map((p) => p.dayOfWeek))].sort((a, b) => a - b),
        startsAt: batch.startsAt ?? first?.startsAt ?? null,
        endsAt: batch.endsAt ?? first?.endsAt ?? null,
        roomName: roomId ? (rooms.get(roomId) ?? null) : null,
        studentCount: headcount.get(batch.id) ?? 0,
        attendancePercent: records.length ? round1((records.filter(attended).length / records.length) * 100) : null,
        pendingSubmissions: pending.filter((w) => w.batchId === batch.id).reduce((n, w) => n + w.count, 0),
      };
    });
}

/** Home: today's own periods, the homework counts, and the batch to act on. */
export function buildTeacherHome(input: TeacherHomeInput): TeacherHome {
  const { today, now, teacherId, perPeriod } = input;
  const { subjects, rooms, headcount, periodsOf } = lookups(input);
  const live = input.batches.filter(isLive).sort((a, b) => a.name.localeCompare(b.name));
  const dayOfWeek = dayOfWeekOf(today);
  const inForce = (p: Timetable) => (!p.validFrom || p.validFrom <= today) && (!p.validTo || p.validTo >= today);

  const periods: TeacherPeriod[] = [];
  for (const batch of live.filter((b) => b.status === 'active')) {
    const todays = periodsOf(batch.id).filter((p) => p.dayOfWeek === dayOfWeek && inForce(p));
    todays.forEach((period, index) => {
      // A period another teacher takes in this batch is theirs, not a class of mine.
      if (period.teacherId !== null && period.teacherId !== teacherId) return;
      const ordinal = perPeriod ? index + 1 : 1;
      const subjectId = period.subjectId ?? batch.subjectId ?? null;
      const roomId = period.classroomId ?? batch.classroomId ?? null;
      periods.push({
        id: period.id,
        batchId: batch.id,
        batchName: batch.name,
        subjectId,
        subjectName: subjectId ? (subjects.get(subjectId) ?? null) : null,
        roomName: roomId ? (rooms.get(roomId) ?? null) : null,
        startsAt: period.startsAt,
        endsAt: period.endsAt,
        studentCount: headcount.get(batch.id) ?? 0,
        period: ordinal,
        attendanceMarked: input.sessions.some(
          (s) => s.batchId === batch.id && s.date === today && s.period === ordinal,
        ),
      });
    });
  }
  periods.sort((a, b) => a.startsAt.localeCompare(b.startsAt) || a.batchName.localeCompare(b.batchName));

  const liveIds = new Set(live.map((b) => b.id));
  const pending = pendingWork(input).filter((w) => liveIds.has(w.batchId));
  const current = periods.find((p) => p.endsAt > now) ?? periods[periods.length - 1];
  return {
    date: today,
    classCount: live.length,
    periods,
    homeworkDue: input.assignments.filter(
      (a) => a.status === 'published' && liveIds.has(a.batchId) && a.dueAt?.slice(0, 10) === today,
    ).length,
    submissionsToGrade: pending.reduce((n, w) => n + w.count, 0),
    pending,
    currentBatchId: current?.batchId ?? live[0]?.id ?? null,
  };
}

/** Latest window against the one before it, counted in roll calls so holidays do not skew it. */
function attendanceSignal(records: AttendanceRecord[], dates: Map<ID, string>): FallingSignal | null {
  const { ATTENDANCE_WINDOW: size, ATTENDANCE_MIN_RECORDS: min, ATTENDANCE_DROP: limit } = FALLING_RULES;
  const ordered = records
    .filter((r) => dates.has(r.sessionId))
    .sort((a, b) => (dates.get(b.sessionId) ?? '').localeCompare(dates.get(a.sessionId) ?? ''));
  const recent = ordered.slice(0, size);
  const before = ordered.slice(size, size * 2);
  if (recent.length < min || before.length < min) return null;
  const here = recent.filter(attended).length;
  const then = before.filter(attended).length;
  const to = round1((here / recent.length) * 100);
  const from = round1((then / before.length) * 100);
  if (from - to < limit) return null;
  return {
    kind: 'attendance',
    from,
    to,
    drop: round1(from - to),
    reason: `Attendance fell from ${whole(from)} to ${whole(to)}`,
    detail: `Present for ${here} of the last ${recent.length} classes, against ${then} of the ${before.length} before.`,
  };
}

/** The latest published result against the one before it. */
function marksSignal(results: Result[], exams: Map<ID, Exam>): FallingSignal | null {
  const when = (r: Result) => {
    const exam = exams.get(r.examId);
    return exam?.endsOn ?? exam?.startsOn ?? exam?.createdAt ?? '';
  };
  const [latest, previous] = results
    .filter((r) => exams.has(r.examId) && r.totalMax > 0)
    .sort((a, b) => when(b).localeCompare(when(a)));
  if (!latest || !previous) return null;
  const from = round1(previous.percentage);
  const to = round1(latest.percentage);
  if (from - to < FALLING_RULES.MARKS_DROP) return null;
  const name = (r: Result) => exams.get(r.examId)?.name ?? 'the exam';
  return {
    kind: 'marks',
    from,
    to,
    drop: round1(from - to),
    reason: `Marks fell from ${whole(from)} to ${whole(to)}`,
    detail:
      `Scored ${latest.totalObtained} of ${latest.totalMax} in ${name(latest)}, ` +
      `after ${previous.totalObtained} of ${previous.totalMax} in ${name(previous)}.`,
  };
}

/** Students of the given batches whose attendance or marks are falling. Biggest drop first. */
export function findFallingStudents(input: FallingInput): FallingStudent[] {
  const batches = new Map(input.batches.filter(isLive).map((b) => [b.id, b]));
  const students = new Map(input.students.map((s) => [s.id, s]));
  const dates = new Map(input.sessions.map((s) => [s.id, `${s.date}#${String(s.period).padStart(3, '0')}`]));
  const exams = new Map(input.exams.filter((e) => e.status === 'published').map((e) => [e.id, e]));

  const out: FallingStudent[] = [];
  for (const enrolment of input.enrollments) {
    const batch = batches.get(enrolment.batchId);
    const student = students.get(enrolment.studentId);
    if (!batch || !student || enrolment.status !== 'active') continue;
    const mine = <T extends { studentId: ID; batchId: ID }>(row: T) =>
      row.studentId === student.id && row.batchId === batch.id;
    const signals = [
      attendanceSignal(input.records.filter(mine), dates),
      marksSignal(input.results.filter(mine), exams),
    ]
      .filter((signal): signal is FallingSignal => signal !== null)
      .sort((a, b) => b.drop - a.drop);
    if (signals.length === 0) continue;
    out.push({
      studentId: student.id,
      fullName: student.fullName,
      photoUrl: student.photoUrl,
      batchId: batch.id,
      batchName: batch.name,
      rollNumber: enrolment.rollNumber,
      signals,
    });
  }
  return out.sort((a, b) => b.signals[0].drop - a.signals[0].drop || a.fullName.localeCompare(b.fullName));
}
