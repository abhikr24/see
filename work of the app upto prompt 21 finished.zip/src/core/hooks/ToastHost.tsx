import { useEffect, useRef, useState } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { C } from '../../lib/theme';
import { toast, type Toast, type ToastKind } from './toast';

const VISIBLE_MS = 2800;
const ERROR_VISIBLE_MS = 4500;

const COLORS: Record<ToastKind, string> = {
  success: C.success,
  error: C.danger,
  info: C.primary,
};

/** Shows the latest toast above everything else. Mounted once, by BackendProvider. */
export function ToastHost() {
  const insets = useSafeAreaInsets();
  const [current, setCurrent] = useState<Toast | null>(null);
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => toast.subscribe(setCurrent), []);

  useEffect(() => {
    if (!current) return;
    Animated.timing(opacity, { toValue: 1, duration: 160, useNativeDriver: true }).start();
    const timer = setTimeout(
      () => {
        Animated.timing(opacity, { toValue: 0, duration: 220, useNativeDriver: true }).start(({ finished }) => {
          if (finished) setCurrent((shown) => (shown?.id === current.id ? null : shown));
        });
      },
      current.kind === 'error' ? ERROR_VISIBLE_MS : VISIBLE_MS,
    );
    return () => clearTimeout(timer);
  }, [current, opacity]);

  if (!current) return null;

  return (
    <View pointerEvents="none" style={[styles.host, { bottom: insets.bottom + 24 }]}>
      <Animated.View
        accessibilityRole="alert"
        accessibilityLiveRegion="polite"
        style={[styles.toast, { backgroundColor: COLORS[current.kind], opacity }]}
      >
        <Text style={styles.text}>{current.message}</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  host: {
    position: 'absolute',
    left: 16,
    right: 16,
    alignItems: 'center',
  },
  toast: {
    maxWidth: 480,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    shadowColor: C.ink,
    shadowOpacity: 0.2,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  text: {
    color: C.surface,
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    textAlign: 'center',
  },
});
