import { toBackendError, type BackendError } from '../contracts/errors';

/**
 * A small query cache shared by every data hook. No React in here, so the
 * optimistic-update and rollback logic can be exercised without rendering.
 */

export interface QueryState<T = unknown> {
  /** undefined until the first successful load. */
  data: T | undefined;
  /** true while a request is in flight (also during a background refresh). */
  loading: boolean;
  error: BackendError | null;
}

export type CacheSnapshot = Map<string, QueryState>;
type Fetcher = () => Promise<unknown>;

const PENDING: QueryState = Object.freeze({ data: undefined, loading: true, error: null });
export const IDLE: QueryState = Object.freeze({ data: undefined, loading: false, error: null });

export function queryKey(backend: string, domain: string, instituteId: string | null, args: unknown = null): string {
  return `${queryScope(backend, domain, instituteId)}${JSON.stringify(args ?? null)}`;
}

/** Prefix shared by every key of one domain in one institute. */
export function queryScope(backend: string, domain: string, instituteId: string | null): string {
  return `${backend}|${domain}|${instituteId ?? '-'}|`;
}

class QueryCache {
  private readonly states = new Map<string, QueryState>();
  private readonly listeners = new Map<string, Set<() => void>>();
  private readonly fetchers = new Map<string, Fetcher>();
  private readonly inFlight = new Map<string, Promise<void>>();
  /** Latest request number per key; a response from an older request is dropped. */
  private readonly requests = new Map<string, number>();

  read(key: string): QueryState {
    return this.states.get(key) ?? PENDING;
  }

  subscribe(key: string, listener: () => void): () => void {
    const set = this.listeners.get(key) ?? new Set();
    this.listeners.set(key, set);
    set.add(listener);
    return () => {
      set.delete(listener);
    };
  }

  private write(key: string, state: QueryState): void {
    this.states.set(key, state);
    this.listeners.get(key)?.forEach((listener) => listener());
  }

  private supersede(key: string): number {
    const request = (this.requests.get(key) ?? 0) + 1;
    this.requests.set(key, request);
    this.inFlight.delete(key);
    return request;
  }

  /** Loads a key. Joins a request already in flight unless `force` is set. */
  fetch(key: string, fetcher: Fetcher, force = false): Promise<void> {
    this.fetchers.set(key, fetcher);
    const running = this.inFlight.get(key);
    if (running && !force) return running;

    const request = this.supersede(key);
    const isLatest = () => this.requests.get(key) === request;
    this.write(key, { data: this.states.get(key)?.data, loading: true, error: null });
    const work = Promise.resolve()
      .then(fetcher)
      .then(
        (data) => {
          if (isLatest()) this.write(key, { data, loading: false, error: null });
        },
        (cause) => {
          // Keep showing the last good data; the error sits beside it.
          if (isLatest()) this.write(key, { data: this.states.get(key)?.data, loading: false, error: toBackendError(cause) });
        },
      )
      .finally(() => {
        if (isLatest()) this.inFlight.delete(key);
      });
    this.inFlight.set(key, work);
    return work;
  }

  /**
   * Optimistic write. Does nothing if the key has not loaded yet. Any request
   * in flight is superseded so a stale response cannot undo the change.
   */
  update<T>(key: string, change: (current: T) => T): void {
    const state = this.states.get(key);
    if (!state || state.data === undefined) return;
    this.supersede(key);
    this.write(key, { data: change(state.data as T), loading: false, error: state.error });
  }

  /** Copies every state under the given scopes, to roll back to. */
  snapshot(scopes: string[]): CacheSnapshot {
    const copy: CacheSnapshot = new Map();
    for (const [key, state] of this.states) {
      if (scopes.some((scope) => key.startsWith(scope))) copy.set(key, state);
    }
    return copy;
  }

  /** Puts a snapshot back. A key that was mid-load when it was taken is loaded again. */
  restore(snapshot: CacheSnapshot): void {
    for (const [key, state] of snapshot) {
      if (this.states.get(key) === state) continue;
      const fetcher = this.fetchers.get(key);
      this.supersede(key);
      this.write(key, { ...state, loading: false });
      if (state.loading && fetcher) void this.fetch(key, fetcher, true);
    }
  }

  /** Marks everything under the scopes stale: mounted queries reload, the rest are forgotten. */
  invalidate(scopes: string[]): Promise<void> {
    const reloads: Promise<void>[] = [];
    for (const key of [...this.states.keys()]) {
      if (!scopes.some((scope) => key.startsWith(scope))) continue;
      const fetcher = this.fetchers.get(key);
      if (fetcher && (this.listeners.get(key)?.size ?? 0) > 0) reloads.push(this.fetch(key, fetcher, true));
      else this.states.delete(key);
    }
    return Promise.all(reloads).then(() => undefined);
  }

  /** Forgets everything without reloading. For tests. */
  clear(): void {
    for (const key of [...this.states.keys()]) this.supersede(key);
    this.states.clear();
    this.fetchers.clear();
    this.listeners.forEach((set) => set.forEach((listener) => listener()));
  }
}

export const queryCache = new QueryCache();
