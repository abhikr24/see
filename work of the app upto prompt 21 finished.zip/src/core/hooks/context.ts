import { createContext, useContext } from 'react';

import type { ID } from '../contracts/models';
import type { Backend } from '../contracts/ports';

export interface BackendContextValue {
  /** The backend every hook talks to. */
  backend: Backend;
  /** Every backend registered with the provider, for dev tools. */
  backends: Backend[];
  selectBackend: (name: string) => void;
  /** The institute every hook is scoped to. null until one is chosen. */
  instituteId: ID | null;
  setInstituteId: (instituteId: ID | null) => void;
}

export const BackendContext = createContext<BackendContextValue | null>(null);

export function useBackend(): BackendContextValue {
  const value = useContext(BackendContext);
  if (!value) throw new Error('useBackend must be used inside <BackendProvider>');
  return value;
}
