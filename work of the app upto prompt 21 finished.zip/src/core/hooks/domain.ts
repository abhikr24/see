import { useCallback } from 'react';

import { BackendError } from '../contracts/errors';
import type { Draft, ID, NewEntity, Patch, TenantEntity } from '../contracts/models';
import type { Backend, CrudRepo } from '../contracts/ports';
import type { ListQuery, Page } from '../contracts/query';
import { queryCache, queryKey, queryScope } from './cache';
import { useBackend } from './context';
import type { MutationOptions } from './mutation';
import { useMutation } from './useMutation';
import { useQuery, type QueryResult } from './useQuery';

/** Building blocks for the per-domain hooks. Feature code uses those, not these. */

type Messages<V, R> = Pick<MutationOptions<V, R>, 'success' | 'failure'>;

/** A query scoped to the current backend and institute. Off until an institute is chosen. */
export function useDomainQuery<T>(
  domain: string,
  args: unknown,
  fetch: (backend: Backend, instituteId: ID) => Promise<T>,
  enabled = true,
): QueryResult<T> {
  const { backend, instituteId } = useBackend();
  const key = instituteId && enabled ? queryKey(backend.name, domain, instituteId, args) : null;
  return useQuery(key, () => fetch(backend, instituteId as ID));
}

/** A write scoped to the current institute. `domains` are the caches it makes stale. */
export function useDomainMutation<V, R>(
  domains: string | string[],
  run: (backend: Backend, instituteId: ID, vars: V) => Promise<R>,
  messages: Messages<V, R> = {},
  optimistic?: (vars: V) => void,
) {
  const { backend, instituteId } = useBackend();
  return useMutation<V, R>({
    ...messages,
    optimistic,
    scopes: [domains].flat().map((domain) => queryScope(backend.name, domain, instituteId)),
    run: async (vars) => {
      if (!instituteId) throw new BackendError('VALIDATION', 'Choose an institute first.');
      return run(backend, instituteId, vars);
    },
  });
}

/** Returns a function that edits one cached list (a Page or a plain array) in place, optimistically. */
export function useListEditor<T>(domain: string, args: unknown) {
  const { backend, instituteId } = useBackend();
  const key = queryKey(backend.name, domain, instituteId, args);
  return useCallback(
    (change: (items: T[]) => T[]) =>
      queryCache.update<Page<T> | T[]>(key, (current) => {
        if (Array.isArray(current)) return change(current);
        const items = change(current.items);
        const total = current.total === null ? null : current.total + items.length - current.items.length;
        return { ...current, items, total };
      }),
    [key],
  );
}

export const patchItem =
  <T extends { id: ID }>(id: ID, patch: Partial<T>) =>
  (items: T[]): T[] =>
    items.map((item) => (item.id === id ? { ...item, ...patch } : item));

export const dropItem =
  <T extends { id: ID }>(id: ID) =>
  (items: T[]): T[] =>
    items.filter((item) => item.id !== id);

const TEMP_PREFIX = 'temp-';
let tempCounter = 0;

/** True for a row added optimistically that the backend has not confirmed yet. */
export const isOptimistic = (row: { id: ID }): boolean => row.id.startsWith(TEMP_PREFIX);

/** A stand-in row shown while a create is in flight. Fields the backend defaults are absent until it lands. */
export function placeholder<T>(input: object, instituteId: ID | null): T {
  const at = new Date().toISOString();
  return { ...input, id: `${TEMP_PREFIX}${++tempCounter}`, instituteId, createdAt: at, updatedAt: at } as T;
}

/**
 * List + create / update / remove for any CrudRepo, with optimistic list edits.
 * `label` is the singular noun used in toasts, e.g. "Student".
 */
export function useCrud<T extends TenantEntity, Req extends keyof Draft<T> = never>(
  domain: string,
  label: string,
  pick: (backend: Backend) => CrudRepo<T, Req>,
  query?: ListQuery<T>,
) {
  const { instituteId } = useBackend();
  const args = ['list', query ?? null];
  const noun = label.toLowerCase();
  const list = useDomainQuery<Page<T>>(domain, args, (b, i) => pick(b).list(i, query));
  const edit = useListEditor<T>(domain, args);

  const create = useDomainMutation<NewEntity<T, Req>, T>(
    domain,
    (b, i, input) => pick(b).create(i, input),
    { success: `${label} added`, failure: `Could not add the ${noun}` },
    (input) => edit((items) => [placeholder<T>(input, instituteId), ...items]),
  );
  const update = useDomainMutation<{ id: ID; patch: Patch<T> }, T>(
    domain,
    (b, i, { id, patch }) => pick(b).update(i, id, patch),
    { success: `${label} updated`, failure: `Could not update the ${noun}` },
    ({ id, patch }) => edit(patchItem<T>(id, patch as Partial<T>)),
  );
  const remove = useDomainMutation<ID, void>(
    domain,
    (b, i, id) => pick(b).remove(i, id),
    { success: `${label} removed`, failure: `Could not remove the ${noun}` },
    (id) => edit(dropItem<T>(id)),
  );

  return {
    ...list,
    create: create.mutate,
    update: update.mutate,
    remove: remove.mutate,
    saving: create.loading || update.loading || remove.loading,
  };
}
