import { toBackendError, type BackendError } from '../contracts/errors';
import { queryCache } from './cache';
import { toast } from './toast';

export interface MutationOptions<V, R> {
  run: (vars: V) => Promise<R>;
  /** Cache scopes this write affects: snapshotted before, reloaded after. */
  scopes: string[];
  /** Apply the expected result to the cache straight away. Undone automatically on failure. */
  optimistic?: (vars: V) => void;
  /** Toast on success. Omit or pass null for a silent mutation. */
  success?: string | ((result: R, vars: V) => string) | null;
  /** Lead-in for the error toast, e.g. "Could not save attendance". */
  failure?: string;
}

export type MutationResult<R> = { ok: true; data: R } | { ok: false; error: BackendError };

/**
 * The one path every write takes:
 *   snapshot → optimistic update → run → (toast + reload) | (roll back + error toast)
 * Never rejects: callers branch on `result.ok`.
 */
export async function runMutation<V, R>(options: MutationOptions<V, R>, vars: V): Promise<MutationResult<R>> {
  const snapshot = queryCache.snapshot(options.scopes);
  try {
    options.optimistic?.(vars);
    const data = await options.run(vars);
    const message = typeof options.success === 'function' ? options.success(data, vars) : options.success;
    if (message) toast.success(message);
    void queryCache.invalidate(options.scopes);
    return { ok: true, data };
  } catch (cause) {
    const error = toBackendError(cause);
    queryCache.restore(snapshot);
    toast.error(options.failure ? `${options.failure}. ${error.message}` : error.message);
    return { ok: false, error };
  }
}
