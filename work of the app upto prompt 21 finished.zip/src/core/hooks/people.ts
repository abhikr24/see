import type { Guardian, ID, ParentLink, StaffRecord, Student, Teacher, Upsert, Workload } from '../contracts/models';
import type { ListQuery } from '../contracts/query';
import { useCrud, useDomainMutation, useDomainQuery } from './domain';

/** StaffRepo · HR records. */
export function useStaff(query?: ListQuery<StaffRecord>) {
  return useCrud<StaffRecord>('staff', 'Staff record', (b) => b.staff, query);
}

/** StaffRepo · teacher cards and their weekly workload. */
export function useTeachers(query?: ListQuery<Teacher>) {
  const teachers = useDomainQuery('staff', ['teachers', query ?? null], (b, i) => b.staff.listTeachers(i, query));
  const save = useDomainMutation<Upsert<Teacher, 'fullName'>, Teacher>(
    'staff',
    (b, i, input) => b.staff.saveTeacher(i, input),
    { success: 'Teacher saved', failure: 'Could not save the teacher' },
  );
  const saveWorkload = useDomainMutation<Upsert<Workload, 'teacherId' | 'weekStart'>, Workload>(
    'staff',
    (b, i, input) => b.staff.saveWorkload(i, input),
    { success: 'Workload saved', failure: 'Could not save the workload' },
  );
  return {
    ...teachers,
    save: save.mutate,
    saveWorkload: saveWorkload.mutate,
    saving: save.loading || saveWorkload.loading,
  };
}

/** StudentRepo */
export function useStudents(query?: ListQuery<Student>) {
  return useCrud<Student, 'fullName'>('students', 'Student', (b) => b.students, query);
}

/** StudentRepo · the students in one batch, by roll number. Off while `batchId` is null. */
export function useBatchStudents(batchId: ID | null) {
  return useDomainQuery<Student[]>(
    'students',
    ['batch', batchId],
    (b, i) => b.students.listByBatch(i, batchId as ID),
    batchId !== null,
  );
}

/** StudentRepo · the signed-in student's own record, or a parent's children. */
export function useMyStudents() {
  return useDomainQuery<Student[]>('students', ['mine'], (b, i) => b.students.listMine(i));
}

/** GuardianRepo · guardians, and linking them to students. */
export function useGuardians(query?: ListQuery<Guardian>) {
  const guardians = useCrud<Guardian, 'fullName'>('guardians', 'Guardian', (b) => b.guardians, query);
  const link = useDomainMutation<{ studentId: ID; guardianId: ID; isPrimary?: boolean }, ParentLink>(
    ['guardians', 'progress'],
    (b, i, input) => b.guardians.link(i, input),
    { success: 'Guardian linked', failure: 'Could not link the guardian' },
  );
  const unlink = useDomainMutation<ID, void>(
    ['guardians', 'progress'],
    (b, i, linkId) => b.guardians.unlink(i, linkId),
    { success: 'Guardian unlinked', failure: 'Could not unlink the guardian' },
  );
  return {
    ...guardians,
    link: link.mutate,
    unlink: unlink.mutate,
    saving: guardians.saving || link.loading || unlink.loading,
  };
}

/** GuardianRepo · one student's guardians, primary first. Off while `studentId` is null. */
export function useStudentGuardians(studentId: ID | null) {
  return useDomainQuery<Guardian[]>(
    'guardians',
    ['student', studentId],
    (b, i) => b.guardians.listForStudent(i, studentId as ID),
    studentId !== null,
  );
}
