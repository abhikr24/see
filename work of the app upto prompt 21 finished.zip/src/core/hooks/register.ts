import type { ID, ISODate, MonthRegister, RegisterDay } from '../contracts/models';
import { useDomainQuery } from './domain';

/** Cache args of the month register, exported so a correction can mark its day optimistically. */
export const monthRegisterArgs = (batchId: ID, month: string) => ['month-register', batchId, month] as const;
export const registerDayArgs = (batchId: ID, date: ISODate) => ['register-day', batchId, date] as const;

/** AttendanceRepo · heatmap cells, summary rows and the per-student grid for one batch and month. */
export function useMonthRegister(batchId: ID | null, month: string) {
  return useDomainQuery<MonthRegister>(
    'attendance',
    monthRegisterArgs(batchId ?? '', month),
    (b, i) => b.attendance.monthRegister(i, { batchId: batchId as ID, month }),
    batchId !== null,
  );
}

/** AttendanceRepo · one day's sheets, who may correct it and its correction history. Off while `date` is null. */
export function useRegisterDay(batchId: ID | null, date: ISODate | null) {
  return useDomainQuery<RegisterDay>(
    'attendance',
    registerDayArgs(batchId ?? '', date ?? ''),
    (b, i) => b.attendance.registerDay(i, { batchId: batchId as ID, date: date as ISODate }),
    batchId !== null && date !== null,
  );
}
