/**
 * App-wide toast bus. Mutations report here; <ToastHost> (mounted once by
 * BackendProvider) shows them. Screens never show their own success/error toasts.
 */

export type ToastKind = 'success' | 'error' | 'info';

export interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
}

type Listener = (toast: Toast) => void;

const listeners = new Set<Listener>();
let nextId = 1;

function show(kind: ToastKind, message: string): Toast {
  const item: Toast = { id: nextId++, kind, message };
  listeners.forEach((listener) => listener(item));
  return item;
}

export const toast = {
  show,
  success: (message: string) => show('success', message),
  error: (message: string) => show('error', message),
  info: (message: string) => show('info', message),
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },
};
