import { useCallback, useEffect, useRef, useState } from 'react';

import type { BackendError } from '../contracts/errors';
import { runMutation, type MutationOptions, type MutationResult } from './mutation';

export interface Mutation<V, R> {
  /** Never rejects. Toasts and rollback are already handled; branch on `result.ok` if you need to. */
  mutate: (vars: V) => Promise<MutationResult<R>>;
  loading: boolean;
  error: BackendError | null;
}

export function useMutation<V, R>(options: MutationOptions<V, R>): Mutation<V, R> {
  const latest = useRef(options);
  latest.current = options;
  const mounted = useRef(true);
  const [state, setState] = useState<{ loading: boolean; error: BackendError | null }>({ loading: false, error: null });

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const mutate = useCallback(async (vars: V) => {
    setState({ loading: true, error: null });
    const result = await runMutation(latest.current, vars);
    if (mounted.current) setState({ loading: false, error: result.ok ? null : result.error });
    return result;
  }, []);

  return { mutate, loading: state.loading, error: state.error };
}
