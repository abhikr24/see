import { useCallback, useEffect, useRef, useSyncExternalStore } from 'react';

import type { BackendError } from '../contracts/errors';
import { IDLE, queryCache } from './cache';

export interface QueryResult<T> {
  data: T | undefined;
  loading: boolean;
  error: BackendError | null;
  refetch: () => Promise<void>;
}

const noop = () => {};
const unsubscribed = () => noop;

/**
 * Reads one cache key, loading it on mount and whenever the key changes.
 * Pass `null` as the key to switch the query off (e.g. no institute chosen yet).
 */
export function useQuery<T>(key: string | null, fetcher: () => Promise<T>): QueryResult<T> {
  const latest = useRef(fetcher);
  latest.current = fetcher;

  const subscribe = useCallback(
    (onChange: () => void) => (key ? queryCache.subscribe(key, onChange) : unsubscribed()),
    [key],
  );
  const read = useCallback(() => (key ? queryCache.read(key) : IDLE), [key]);
  const state = useSyncExternalStore(subscribe, read, read);

  useEffect(() => {
    if (key) void queryCache.fetch(key, () => latest.current());
  }, [key]);

  const refetch = useCallback(async () => {
    if (key) await queryCache.fetch(key, () => latest.current(), true);
  }, [key]);

  return { data: state.data as T | undefined, loading: state.loading, error: state.error, refetch };
}
