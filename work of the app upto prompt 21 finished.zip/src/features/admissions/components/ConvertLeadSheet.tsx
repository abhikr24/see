import React, { useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Button, Card, Chip, ErrorState, Input, ListSkeleton, Sheet, Text } from '@/components/ui';
import {
  normalizePhone10,
  validateConvertLead,
  type ConvertLeadErrors,
} from '@/core/contracts/admissions';
import type { AdmissionLead, ConvertLeadInput } from '@/core/contracts/models';
import { inr, todayISO } from '@/lib/format';
import { C, S } from '@/lib/theme';
import { findMatchingBatch, useConvertOptions } from '../hooks';

export interface ConvertLeadSheetProps {
  visible: boolean;
  lead: AdmissionLead;
  saving: boolean;
  onClose: () => void;
  onConvert: (input: ConvertLeadInput) => Promise<boolean>;
}

function ConvertLeadForm({
  lead,
  saving,
  onClose,
  onConvert,
}: Omit<ConvertLeadSheetProps, 'visible'>) {
  const optionsQuery = useConvertOptions(true);
  const options = useMemo(() => optionsQuery.data ?? [], [optionsQuery.data]);
  const defaultOption = useMemo(() => findMatchingBatch(options, lead), [options, lead]);

  const [studentName, setStudentName] = useState(lead.studentName);
  const [phone, setPhone] = useState(normalizePhone10(lead.phone));
  const [guardianName, setGuardianName] = useState(lead.guardianName ?? '');
  const [batchId, setBatchId] = useState('');
  const [rollNumber, setRollNumber] = useState<string | null>(null);
  const [monthlyFee, setMonthlyFee] = useState<string | null>(null);
  const [discountIds, setDiscountIds] = useState<string[]>([]);
  const [errors, setErrors] = useState<ConvertLeadErrors>({});

  const effectiveBatchId = batchId || defaultOption?.batch.id || '';
  const selected = useMemo(
    () => options.find((opt) => opt.batch.id === effectiveBatchId) ?? null,
    [options, effectiveBatchId],
  );
  const effectiveRoll = rollNumber ?? (selected ? String(selected.nextRoll) : '');
  const effectiveFee =
    monthlyFee ??
    (lead.expectedFee && lead.expectedFee > 0
      ? String(lead.expectedFee)
      : selected
        ? String(selected.suggestedMonthlyFee)
        : '');

  const chooseBatch = (id: string) => {
    setBatchId(id);
    setDiscountIds([]);
    setErrors((e) => ({ ...e, batchId: undefined, rollNumber: undefined }));
    const opt = options.find((x) => x.batch.id === id);
    if (opt) {
      setRollNumber(String(opt.nextRoll));
      if (!opt.activePlan) {
        setMonthlyFee(String(lead.expectedFee && lead.expectedFee > 0 ? lead.expectedFee : opt.suggestedMonthlyFee));
      }
    }
  };

  const toggleDiscount = (id: string) => {
    setDiscountIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));
  };

  const handleSubmit = async () => {
    const hasBatchPlan = Boolean(selected?.activePlan);
    const nextErrors = validateConvertLead({
      studentName,
      phone,
      batchId: effectiveBatchId,
      rollNumber: effectiveRoll,
      monthlyFee: effectiveFee,
      hasBatchPlan,
    });
    if (!nextErrors.rollNumber && selected && effectiveRoll.trim()) {
      const roll = Number(effectiveRoll.trim());
      if (selected.usedRolls.includes(roll)) {
        nextErrors.rollNumber = 'That roll is already used in this batch';
      }
    }
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const ok = await onConvert({
      leadId: lead.id,
      studentName: studentName.trim(),
      phone: normalizePhone10(phone),
      guardianName: guardianName.trim() || null,
      guardianPhone: normalizePhone10(phone),
      batchId: effectiveBatchId,
      rollNumber: effectiveRoll.trim() ? Number(effectiveRoll.trim()) : null,
      monthlyFee: hasBatchPlan ? null : Number(effectiveFee),
      feeStructureId: selected?.activePlan?.id ?? null,
      discountIds,
      firstDueDate: todayISO(),
    });
    if (ok) onClose();
  };

  if (optionsQuery.loading && options.length === 0) return <ListSkeleton rows={3} h={56} />;
  if (optionsQuery.error && options.length === 0) {
    return <ErrorState message={optionsQuery.error.message} onRetry={() => void optionsQuery.refetch()} />;
  }

  return (
    <ScrollView style={{ maxHeight: 480 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
      <View style={{ gap: S.md, paddingBottom: S.md }}>
        <Input
          label="Student name"
          value={studentName}
          onChangeText={setStudentName}
          error={errors.studentName}
          autoCapitalize="words"
        />
        <Input
          label="Mobile number"
          value={phone}
          onChangeText={(v) => setPhone(v.replace(/\D/g, '').slice(0, 10))}
          error={errors.phone}
          keyboardType="phone-pad"
          maxLength={10}
        />
        <Input
          label="Parent / guardian name"
          value={guardianName}
          onChangeText={setGuardianName}
          placeholder="Parent name"
          autoCapitalize="words"
        />

        <View style={{ gap: 6 }}>
          <Text variant="label" c={C.secondary}>
            Assign batch
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {options.map((opt) => (
              <Chip
                key={opt.batch.id}
                label={`${opt.batch.name} (${opt.activeCount})`}
                active={effectiveBatchId === opt.batch.id}
                onPress={() => chooseBatch(opt.batch.id)}
              />
            ))}
          </ScrollView>
          {errors.batchId ? (
            <Text variant="caption" c={C.danger}>
              {errors.batchId}
            </Text>
          ) : null}
        </View>

        <Input
          label="Roll number"
          value={effectiveRoll}
          onChangeText={(v) => setRollNumber(v.replace(/\D/g, ''))}
          error={errors.rollNumber}
          keyboardType="number-pad"
          maxLength={4}
        />

        {selected?.activePlan ? (
          <Card flat pad={14} style={{ backgroundColor: C.navySoft, gap: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Ionicons name="wallet-outline" size={18} color={C.primary} />
              <Text variant="caption" weight={700} c={C.primary} style={{ flex: 1 }}>
                {selected.activePlan.name} · {inr(selected.activePlan.totalAmount)}
              </Text>
            </View>
            <Text variant="caption" c={C.secondary}>
              {selected.activePlan.schedule.length} scheduled instalments will be assigned automatically.
            </Text>
            {selected.activePlan.discounts.length > 0 ? (
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 4 }}>
                {selected.activePlan.discounts.map((d) => (
                  <Chip
                    key={d.id}
                    label={`${d.label} (${d.type === 'percent' ? `${d.amount}%` : inr(d.amount)})`}
                    active={discountIds.includes(d.id)}
                    onPress={() => toggleDiscount(d.id)}
                  />
                ))}
              </View>
            ) : null}
          </Card>
        ) : (
          <Input
            label="Monthly fee (₹)"
            value={effectiveFee}
            onChangeText={(v) => setMonthlyFee(v.replace(/[^\d.]/g, ''))}
            error={errors.monthlyFee}
            keyboardType="decimal-pad"
            hint="Generates a monthly fee plan for this batch and student."
          />
        )}

        <View style={{ flexDirection: 'row', gap: S.sm, marginTop: S.xs }}>
          <View style={{ flex: 1 }}>
            <Button title="Cancel" variant="outline" onPress={onClose} disabled={saving} />
          </View>
          <View style={{ flex: 1 }}>
            <Button
              title="Admit student"
              variant="primary"
              loading={saving}
              onPress={() => void handleSubmit()}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

export function ConvertLeadSheet({
  visible,
  lead,
  saving,
  onClose,
  onConvert,
}: ConvertLeadSheetProps) {
  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Convert to student"
      subtitle="Creates the student, parent link, batch enrolment, and fee plan in one step."
      snapPoints={['84%', '94%']}
    >
      {visible ? (
        <ConvertLeadForm
          key={lead.id}
          lead={lead}
          saving={saving}
          onClose={onClose}
          onConvert={onConvert}
        />
      ) : null}
    </Sheet>
  );
}
