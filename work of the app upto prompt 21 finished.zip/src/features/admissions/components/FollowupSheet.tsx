import React, { useState } from 'react';
import { View } from 'react-native';
import { Button, Chip, DateField, Input, Sheet, Text } from '@/components/ui';
import {
  FOLLOWUP_CHANNELS,
  OUTCOME_LABELS,
  type FollowupChannelChoice,
} from '@/core/contracts/admissions';
import type { LeadFollowup } from '@/core/contracts/models';
import { todayISO } from '@/lib/format';
import { C, S } from '@/lib/theme';

const OUTCOMES: NonNullable<LeadFollowup['outcome']>[] = [
  'interested',
  'callback',
  'demo_booked',
  'no_answer',
];

export interface FollowupSheetProps {
  visible: boolean;
  leadName: string;
  saving: boolean;
  onClose: () => void;
  onSubmit: (payload: {
    channel: FollowupChannelChoice;
    outcome: LeadFollowup['outcome'];
    summary: string;
    nextFollowupAt: string | null;
    nextFollowupNote: string | null;
  }) => Promise<boolean>;
}

export function FollowupSheet({
  visible,
  leadName,
  saving,
  onClose,
  onSubmit,
}: FollowupSheetProps) {
  const [channel, setChannel] = useState<FollowupChannelChoice>('call');
  const [outcome, setOutcome] = useState<LeadFollowup['outcome']>('interested');
  const [summary, setSummary] = useState('');
  const [nextDate, setNextDate] = useState(todayISO());
  const [nextNote, setNextNote] = useState('');
  const [error, setError] = useState<string | null>(null);

  const reset = () => {
    setChannel('call');
    setOutcome('interested');
    setSummary('');
    setNextDate(todayISO());
    setNextNote('');
    setError(null);
  };

  const handleSave = async () => {
    if (!summary.trim()) {
      setError('Add a short note about this follow-up');
      return;
    }
    setError(null);
    const ok = await onSubmit({
      channel,
      outcome,
      summary: summary.trim(),
      nextFollowupAt: nextDate ? `${nextDate}T12:00:00.000Z` : null,
      nextFollowupNote: nextNote.trim() || null,
    });
    if (ok) {
      reset();
      onClose();
    }
  };

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Log follow-up"
      subtitle={`For ${leadName}`}
      snapPoints={['76%', '92%']}
    >
      <View style={{ gap: S.md }}>
        <View style={{ gap: 6 }}>
          <Text variant="label" c={C.secondary}>
            Type
          </Text>
          <View style={{ flexDirection: 'row', gap: S.sm }}>
            {FOLLOWUP_CHANNELS.map((c) => (
              <Chip
                key={c.key}
                label={c.label}
                active={channel === c.key}
                onPress={() => setChannel(c.key)}
              />
            ))}
          </View>
        </View>

        <View style={{ gap: 6 }}>
          <Text variant="label" c={C.secondary}>
            Outcome
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm }}>
            {OUTCOMES.map((key) => (
              <Chip
                key={key}
                label={OUTCOME_LABELS[key]}
                active={outcome === key}
                onPress={() => setOutcome(outcome === key ? null : key)}
              />
            ))}
          </View>
        </View>

        <Input
          label="Note"
          value={summary}
          onChangeText={(v) => {
            setSummary(v);
            if (error) setError(null);
          }}
          error={error ?? undefined}
          placeholder="Spoke with parent, shared batch timings…"
          multiline
        />

        <DateField
          label="Next follow-up date"
          value={nextDate}
          onChange={(_dmy, iso) => setNextDate(iso)}
        />

        <Input
          label="Next action note (optional)"
          value={nextNote}
          onChangeText={setNextNote}
          placeholder="e.g. Confirm Saturday demo attendance"
        />

        <View style={{ flexDirection: 'row', gap: S.sm, marginTop: S.xs }}>
          <View style={{ flex: 1 }}>
            <Button title="Cancel" variant="outline" onPress={onClose} disabled={saving} />
          </View>
          <View style={{ flex: 1 }}>
            <Button title="Save follow-up" loading={saving} onPress={() => void handleSave()} />
          </View>
        </View>
      </View>
    </Sheet>
  );
}
