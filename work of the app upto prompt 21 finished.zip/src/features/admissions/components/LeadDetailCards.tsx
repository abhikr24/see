import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Avatar, Badge, Button, Card, Chip, Text } from '@/components/ui';
import {
  OPEN_STAGES,
  SOURCE_LABELS,
  STAGE_LABELS,
  STAGE_TONES,
  formatClassLabel,
  isNextActionOverdue,
} from '@/core/contracts/admissions';
import type { AdmissionLead, LeadStage } from '@/core/contracts/models';
import { dateShort } from '@/lib/format';
import { C, R, S } from '@/lib/theme';

export function LeadHeaderCard({
  lead,
  assignedToName,
  onCall,
  onWhatsApp,
}: {
  lead: AdmissionLead;
  assignedToName: string | null;
  onCall: () => void;
  onWhatsApp: () => void;
}) {
  const metaParts = [
    formatClassLabel(lead.classInterested),
    lead.subjectInterest,
    assignedToName ? `Owner: ${assignedToName}` : null,
  ].filter(Boolean);

  return (
    <Card pad={18} style={{ gap: S.md }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <Avatar name={lead.studentName} size={54} />
        <View style={{ flex: 1, gap: 4 }}>
          <Text variant="h2" numberOfLines={2}>
            {lead.studentName}
          </Text>
          {metaParts.length > 0 ? (
            <Text variant="caption" c={C.secondary}>
              {metaParts.join(' · ')}
            </Text>
          ) : null}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 2 }}>
            <Badge label={STAGE_LABELS[lead.stage]} tone={STAGE_TONES[lead.stage]} small />
            <Badge label={SOURCE_LABELS[lead.source]} tone="neutral" small />
          </View>
        </View>
      </View>

      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingTop: S.md,
          borderTopWidth: 1,
          borderTopColor: C.hairline,
          gap: S.sm,
        }}
      >
        <View style={{ flex: 1 }}>
          <Text variant="label" c={C.muted}>
            Phone
          </Text>
          <Text variant="body" weight={700} tabular>
            {lead.phone || 'Not provided'}
          </Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Call lead"
          onPress={onCall}
          style={({ pressed }) => ({
            height: 40,
            paddingHorizontal: 14,
            borderRadius: R.btn,
            backgroundColor: C.navySoft,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Ionicons name="call-outline" size={16} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>
            Call
          </Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="WhatsApp lead"
          onPress={onWhatsApp}
          style={({ pressed }) => ({
            height: 40,
            paddingHorizontal: 14,
            borderRadius: R.btn,
            backgroundColor: C.tealSoft,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Ionicons name="logo-whatsapp" size={16} color={C.teal} />
          <Text variant="caption" weight={700} c={C.teal}>
            WhatsApp
          </Text>
        </Pressable>
      </View>
    </Card>
  );
}

export function LeadNextActionCard({
  lead,
  saving,
  onReopen,
}: {
  lead: AdmissionLead;
  saving: boolean;
  onReopen: () => void;
}) {
  if (lead.stage === 'enrolled') {
    return (
      <Card flat pad={16} style={{ backgroundColor: C.successSoft, borderWidth: 1, borderColor: C.success, gap: 10 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Ionicons name="checkmark-circle" size={20} color={C.success} />
          <Text variant="title" weight={700} c={C.success}>
            Converted to student
          </Text>
        </View>
        {lead.convertedStudentId ? (
          <Button
            title="View student profile"
            size="sm"
            variant="outline"
            onPress={() => router.push(`/(owner)/students/${lead.convertedStudentId}` as never)}
          />
        ) : null}
      </Card>
    );
  }

  if (lead.stage === 'lost') {
    return (
      <Card flat pad={16} style={{ backgroundColor: C.track, borderWidth: 1, borderColor: C.hairline, gap: 8 }}>
        <Text variant="label" c={C.secondary}>
          Archived · Lost reason
        </Text>
        <Text variant="body" c={C.ink}>
          {lead.lostReason || 'No reason recorded.'}
        </Text>
        <Button
          title="Reopen enquiry"
          size="sm"
          variant="outline"
          loading={saving}
          onPress={onReopen}
        />
      </Card>
    );
  }

  const overdue = isNextActionOverdue(lead.nextFollowupAt, lead.stage);

  return (
    <Card
      flat={overdue}
      pad={16}
      style={
        overdue
          ? { backgroundColor: C.warningSoft, borderWidth: 1, borderColor: C.warning, gap: 6 }
          : { gap: 6 }
      }
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons
            name={overdue ? 'alert-circle-outline' : 'calendar-outline'}
            size={17}
            color={overdue ? C.duesInk : C.primary}
          />
          <Text variant="label" weight={700} c={overdue ? C.duesInk : C.secondary}>
            Next action
          </Text>
        </View>
        {overdue ? (
          <Badge label="Overdue" tone="warning" small />
        ) : (
          <Text variant="caption" weight={700} c={C.primary} tabular>
            {lead.nextFollowupAt ? dateShort(lead.nextFollowupAt) : 'Not scheduled'}
          </Text>
        )}
      </View>
      {overdue && lead.nextFollowupAt ? (
        <Text variant="caption" weight={700} c={C.duesInk} tabular>
          Due {dateShort(lead.nextFollowupAt)}
        </Text>
      ) : null}
      <Text variant="body" c={C.ink}>
        {lead.nextFollowupNote || lead.notes || 'Follow up with parent on admission details.'}
      </Text>
    </Card>
  );
}

export function LeadStageStrip({
  current,
  onSelect,
}: {
  current: LeadStage;
  onSelect: (stage: LeadStage) => void;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Text variant="label" c={C.secondary}>
        Pipeline stage
      </Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {OPEN_STAGES.map((stage) => (
          <Chip
            key={stage}
            label={STAGE_LABELS[stage]}
            active={current === stage}
            onPress={() => {
              if (current !== stage) onSelect(stage);
            }}
          />
        ))}
      </ScrollView>
    </View>
  );
}
