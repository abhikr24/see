import React from 'react';
import { Pressable, View } from 'react-native';
import { Avatar, Badge, Text } from '@/components/ui';
import {
  STAGE_LABELS,
  STAGE_TONES,
  isNextActionOverdue,
  leadRowSubtitle,
  shortActionDate,
} from '@/core/contracts/admissions';
import type { LeadListItem } from '@/core/contracts/models';
import { C, LAYOUT, R } from '@/lib/theme';

export interface LeadRowProps {
  item: LeadListItem;
  onPress: () => void;
}

/** 72pt row: avatar/initials, name + class/subject/last-activity line, stage pill + next-action date. */
export function LeadRow({ item, onPress }: LeadRowProps) {
  const { lead, lastFollowupAt, lastFollowupChannel } = item;
  const subtitle = leadRowSubtitle(lead, lastFollowupAt, lastFollowupChannel);
  const stageLabel = STAGE_LABELS[lead.stage];
  const stageTone = STAGE_TONES[lead.stage];
  const overdue = isNextActionOverdue(lead.nextFollowupAt, lead.stage);
  const actionDate =
    lead.stage === 'enrolled'
      ? 'Admitted'
      : lead.stage === 'lost'
        ? 'Archived'
        : lead.nextFollowupAt
          ? shortActionDate(lead.nextFollowupAt)
          : 'No date';

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${lead.studentName}, ${subtitle}, ${stageLabel}`}
      onPress={onPress}
      style={({ pressed }) => ({
        height: 72,
        marginHorizontal: LAYOUT.margin,
        marginBottom: 8,
        paddingHorizontal: 12,
        borderRadius: R.btn,
        backgroundColor: C.surface,
        borderWidth: 1,
        borderColor: C.hairline,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        opacity: pressed ? 0.92 : 1,
      })}
    >
      <Avatar name={lead.studentName} size={46} />

      <View style={{ flex: 1, gap: 2 }}>
        <Text variant="title" weight={700} numberOfLines={1}>
          {lead.studentName}
        </Text>
        <Text variant="caption" c={C.secondary} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>

      <View style={{ alignItems: 'flex-end', gap: 4 }}>
        <Badge label={stageLabel} tone={stageTone} small />
        <Text
          variant="label"
          weight={overdue ? 700 : 600}
          c={overdue ? C.duesInk : C.muted}
          tabular
          style={{ textTransform: 'none', letterSpacing: 0 }}
        >
          {overdue ? `Overdue · ${actionDate}` : actionDate}
        </Text>
      </View>
    </Pressable>
  );
}
