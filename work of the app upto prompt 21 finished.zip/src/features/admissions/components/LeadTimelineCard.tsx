import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Button, Card, Text } from '@/components/ui';
import {
  CHANNEL_LABELS,
  OUTCOME_LABELS,
  STAGE_LABELS,
} from '@/core/contracts/admissions';
import type { LeadFollowup, LeadStageChange, LeadTimelineFollowup } from '@/core/contracts/models';
import { dateShort, timeShort } from '@/lib/format';
import { C, S } from '@/lib/theme';

const CHANNEL_ICON: Record<LeadFollowup['channel'], keyof typeof Ionicons.glyphMap> = {
  call: 'call-outline',
  visit: 'walk-outline',
  whatsapp: 'logo-whatsapp',
  sms: 'chatbubble-outline',
  email: 'mail-outline',
};

function formatDateTime(iso: string): string {
  const timePart = iso.length >= 16 ? timeShort(iso.slice(11, 16)) : '';
  return timePart ? `${dateShort(iso)} · ${timePart}` : dateShort(iso);
}

export function LeadTimelineCard({
  followups,
  canLog,
  onOpenLog,
}: {
  followups: LeadTimelineFollowup[];
  canLog: boolean;
  onOpenLog: () => void;
}) {
  return (
    <Card pad={16} style={{ gap: S.md }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Text variant="title">Timeline</Text>
        {canLog ? (
          <Button
            title="Log follow-up"
            icon="add"
            size="sm"
            full={false}
            onPress={onOpenLog}
          />
        ) : null}
      </View>

      {followups.length === 0 ? (
        <Text variant="caption" c={C.secondary}>
          No follow-ups logged yet. Tap &ldquo;Log follow-up&rdquo; after your first call or visit.
        </Text>
      ) : (
        <View style={{ gap: 12 }}>
          {followups.map(({ followup, doneByName }, idx) => (
            <View
              key={followup.id}
              style={{
                flexDirection: 'row',
                gap: 12,
                paddingTop: idx > 0 ? 12 : 0,
                borderTopWidth: idx > 0 ? 1 : 0,
                borderTopColor: C.hairline,
              }}
            >
              <View
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 17,
                  backgroundColor: followup.channel === 'whatsapp' ? C.tealSoft : C.navySoft,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Ionicons
                  name={CHANNEL_ICON[followup.channel]}
                  size={16}
                  color={followup.channel === 'whatsapp' ? C.teal : C.primary}
                />
              </View>
              <View style={{ flex: 1, gap: 3 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                  <Text variant="caption" weight={700} c={C.ink}>
                    {CHANNEL_LABELS[followup.channel]}
                  </Text>
                  <Text variant="label" c={C.muted} tabular style={{ textTransform: 'none', letterSpacing: 0 }}>
                    {formatDateTime(followup.followupAt)}
                  </Text>
                </View>
                {followup.summary ? (
                  <Text variant="body" c={C.ink}>
                    {followup.summary}
                  </Text>
                ) : null}
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                  {followup.outcome ? (
                    <Badge label={OUTCOME_LABELS[followup.outcome]} tone="primary" small />
                  ) : null}
                  <Text variant="caption" c={C.secondary}>
                    {doneByName ? `Logged by ${doneByName}` : 'Logged by staff'}
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      )}
    </Card>
  );
}

export function LeadStageHistoryCard({ stageChanges }: { stageChanges: LeadStageChange[] }) {
  if (stageChanges.length === 0) return null;
  return (
    <Card pad={16} style={{ gap: 10 }}>
      <Text variant="title">Stage history</Text>
      {stageChanges.map((ev, idx) => (
        <View
          key={ev.id}
          style={{
            paddingTop: idx > 0 ? 8 : 0,
            borderTopWidth: idx > 0 ? 1 : 0,
            borderTopColor: C.hairline,
            gap: 2,
          }}
        >
          <Text variant="caption" weight={700} c={C.ink}>
            {ev.fromStage
              ? `${STAGE_LABELS[ev.fromStage]} → ${STAGE_LABELS[ev.toStage]}`
              : `Enquiry created (${STAGE_LABELS[ev.toStage]})`}
          </Text>
          {ev.lostReason ? (
            <Text variant="caption" c={C.secondary}>
              Reason: {ev.lostReason}
            </Text>
          ) : null}
          <Text variant="label" c={C.muted} tabular style={{ textTransform: 'none', letterSpacing: 0 }}>
            {(ev.actorName ?? 'Staff')} · {formatDateTime(ev.changedAt)}
          </Text>
        </View>
      ))}
    </Card>
  );
}
