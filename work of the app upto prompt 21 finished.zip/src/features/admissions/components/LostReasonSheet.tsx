import React, { useState } from 'react';
import { View } from 'react-native';
import { Button, Chip, Input, Sheet, Text } from '@/components/ui';
import { C, S } from '@/lib/theme';

const QUICK_REASONS = [
  'Joined another institute',
  'Fee too high',
  'Batch timing mismatch',
  'Not reachable',
] as const;

export interface LostReasonSheetProps {
  visible: boolean;
  leadName: string;
  saving: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => Promise<boolean>;
}

export function LostReasonSheet({
  visible,
  leadName,
  saving,
  onClose,
  onConfirm,
}: LostReasonSheetProps) {
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleConfirm = async () => {
    const trimmed = reason.trim();
    if (trimmed.length < 3) {
      setError('Please enter why this enquiry was lost');
      return;
    }
    setError(null);
    const ok = await onConfirm(trimmed);
    if (ok) {
      setReason('');
      onClose();
    }
  };

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Archive as lost"
      subtitle={`${leadName} will be kept in Lost history — leads are never deleted.`}
      snapPoints={['58%', '78%']}
    >
      <View style={{ gap: S.md }}>
        <View style={{ gap: 6 }}>
          <Text variant="label" c={C.secondary}>
            Common reasons
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: S.sm }}>
            {QUICK_REASONS.map((item) => (
              <Chip
                key={item}
                label={item}
                active={reason === item}
                onPress={() => {
                  setReason(item);
                  setError(null);
                }}
              />
            ))}
          </View>
        </View>

        <Input
          label="Lost reason"
          value={reason}
          onChangeText={(v) => {
            setReason(v);
            if (error) setError(null);
          }}
          error={error ?? undefined}
          placeholder="Why did they not enrol?"
          multiline
        />

        <View style={{ flexDirection: 'row', gap: S.sm, marginTop: S.xs }}>
          <View style={{ flex: 1 }}>
            <Button title="Cancel" variant="outline" onPress={onClose} disabled={saving} />
          </View>
          <View style={{ flex: 1 }}>
            <Button
              title="Archive lead"
              variant="danger"
              loading={saving}
              onPress={() => void handleConfirm()}
            />
          </View>
        </View>
      </View>
    </Sheet>
  );
}
