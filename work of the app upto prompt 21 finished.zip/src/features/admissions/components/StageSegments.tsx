import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Text } from '@/components/ui';
import { LEAD_SEGMENTS, SEGMENT_LABELS } from '@/core/contracts/admissions';
import type { LeadSegment } from '@/core/contracts/models';
import { C, LAYOUT, R, S, SHADOW } from '@/lib/theme';

export interface StageSegmentsProps {
  value: LeadSegment;
  counts: Record<LeadSegment, number>;
  onChange: (segment: LeadSegment) => void;
}

/**
 * Five-stage segmented strip for Shape B admissions list:
 * New / Following up / Demo booked / Converted / Lost.
 */
export function StageSegments({ value, counts, onChange }: StageSegmentsProps) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin }}
    >
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: C.track,
          borderRadius: R.chip,
          borderWidth: 1,
          borderColor: C.hairline,
          padding: 4,
          gap: 4,
        }}
      >
        {LEAD_SEGMENTS.map((seg) => {
          const active = seg === value;
          const count = counts[seg] ?? 0;
          return (
            <Pressable
              key={seg}
              accessibilityRole="tab"
              accessibilityState={{ selected: active }}
              accessibilityLabel={`${SEGMENT_LABELS[seg]} (${count})`}
              onPress={() => onChange(seg)}
              style={[
                {
                  height: 36,
                  paddingHorizontal: S.md,
                  borderRadius: R.chip,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 6,
                },
                active
                  ? {
                      backgroundColor: C.surface,
                      borderWidth: 1,
                      borderColor: C.hairline,
                      ...SHADOW,
                    }
                  : null,
              ]}
            >
              <Text
                variant="caption"
                weight={active ? 700 : 600}
                c={active ? C.primary : C.secondary}
                tabular
              >
                {SEGMENT_LABELS[seg]}
              </Text>
              <View
                style={{
                  minWidth: 20,
                  height: 20,
                  paddingHorizontal: 6,
                  borderRadius: R.chip,
                  backgroundColor: active ? C.navySoft : C.surface,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Text variant="label" weight={700} c={active ? C.primary : C.secondary} tabular>
                  {count}
                </Text>
              </View>
            </Pressable>
          );
        })}
      </View>
    </ScrollView>
  );
}
