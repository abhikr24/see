import React from 'react';
import { View } from 'react-native';
import { Text } from '@/components/ui';
import { formatAvgResponse } from '@/core/contracts/admissions';
import type { AdmissionsSummary } from '@/core/contracts/models';
import { C, LAYOUT, R, S } from '@/lib/theme';

export interface SummaryStripProps {
  summary: AdmissionsSummary | null;
}

export function SummaryStrip({ summary }: SummaryStripProps) {
  const enquiries = summary ? String(summary.thisMonthEnquiries) : '—';
  const conversion = summary ? `${summary.conversionPercent}%` : '—';
  const response = summary ? formatAvgResponse(summary.avgResponseMinutes) : '—';

  const cells = [
    { key: 'enquiries', value: enquiries, label: 'This month', accent: false },
    { key: 'conversion', value: conversion, label: 'Conversion', accent: true },
    { key: 'response', value: response, label: 'Avg response', accent: false },
  ] as const;

  return (
    <View
      style={{
        marginHorizontal: LAYOUT.margin,
        flexDirection: 'row',
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        paddingVertical: S.md + 2,
      }}
    >
      {cells.map((cell, index) => (
        <View
          key={cell.key}
          style={{
            flex: 1,
            alignItems: 'center',
            gap: 2,
            borderLeftWidth: index > 0 ? 1 : 0,
            borderLeftColor: C.hairline,
            paddingHorizontal: S.sm,
          }}
        >
          <Text
            variant="h2"
            weight={800}
            c={cell.accent ? C.teal : C.ink}
            tabular
            accessibilityLabel={`${cell.label}: ${cell.value}`}
          >
            {cell.value}
          </Text>
          <Text variant="label" c={C.secondary} numberOfLines={1} style={{ textTransform: 'none', letterSpacing: 0 }}>
            {cell.label}
          </Text>
        </View>
      ))}
    </View>
  );
}
