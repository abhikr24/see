import { useCallback, useMemo, useState } from 'react';
import {
  LEAD_SEGMENTS,
  normalizePhone10,
  segmentForStage,
} from '@/core/contracts/admissions';
import { planCovering } from '@/core/contracts/fee-plan';
import {
  useAdmissionsPipeline,
  useBackend,
  useLeadDetail,
  useLeads,
  useSubjects,
} from '@/core/backend';
import { useDomainQuery } from '@/core/hooks/domain';
import type {
  AdmissionLead,
  Batch,
  ConvertLeadInput,
  ConvertLeadResult,
  Enrollment,
  FeeStructure,
  ID,
  LeadListItem,
  LeadSegment,
} from '@/core/contracts/models';
import { rosterCache } from '@/features/students/cache';
import { suggestMonthlyFee } from '@/features/students/types';

export interface ConvertBatchOption {
  batch: Batch;
  activeCount: number;
  usedRolls: number[];
  nextRoll: number;
  activePlan: FeeStructure | null;
  suggestedMonthlyFee: number;
}

export function useAdmissionsWorkspace() {
  const pipeline = useAdmissionsPipeline();
  const [segment, setSegment] = useState<LeadSegment>('new');
  const [refreshing, setRefreshing] = useState(false);

  const items = useMemo(() => pipeline.data?.items ?? [], [pipeline.data?.items]);

  const counts = useMemo(() => {
    const map: Record<LeadSegment, number> = {
      new: 0,
      following_up: 0,
      demo_booked: 0,
      converted: 0,
      lost: 0,
    };
    for (const item of items) {
      map[item.segment] = (map[item.segment] ?? 0) + 1;
    }
    return map;
  }, [items]);

  const filtered = useMemo<LeadListItem[]>(
    () => items.filter((item) => item.segment === segment),
    [items, segment],
  );

  const openCount = useMemo(
    () => items.filter((item) => item.lead.stage !== 'enrolled' && item.lead.stage !== 'lost').length,
    [items],
  );

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await pipeline.refetch();
    } finally {
      setRefreshing(false);
    }
  }, [pipeline]);

  return {
    summary: pipeline.data?.summary ?? null,
    items: filtered,
    allCount: items.length,
    openCount,
    counts,
    segments: LEAD_SEGMENTS,
    segment,
    setSegment,
    loading: pipeline.loading && !pipeline.data,
    error: pipeline.error?.message ?? null,
    refreshing,
    refresh,
  };
}

export function useCreateEnquiryOptions() {
  const pipeline = useAdmissionsPipeline();
  const subjects = useSubjects({ limit: 50 });
  const leads = useLeads();

  const subjectSuggestions = useMemo(() => {
    const names = (subjects.data?.items ?? []).map((s) => s.name);
    return [...new Set(['Science', ...names])];
  }, [subjects.data?.items]);

  return {
    assignees: pipeline.data?.assignees ?? [],
    subjectSuggestions,
    create: leads.create,
    saving: leads.saving,
  };
}

export function useConvertOptions(enabled: boolean) {
  return useDomainQuery<ConvertBatchOption[]>(
    'batches',
    ['convert-options'],
    async (b, i) => {
      const [batchPage, structuresPage] = await Promise.all([
        b.batches.list(i, { limit: 100 }),
        b.fees.listStructures(i, { limit: 100 }),
      ]);
      const batches = batchPage.items.filter((x) => x.status !== 'archived');
      const enrollmentsByBatch = await Promise.all(
        batches.map((batch) => b.batches.listEnrollments(i, batch.id)),
      );
      return batches.map((batch, idx): ConvertBatchOption => {
        const active: Enrollment[] = enrollmentsByBatch[idx].filter((e) => e.status === 'active');
        const usedRolls = active
          .map((e) => e.rollNumber)
          .filter((r): r is number => r !== null);
        const nextRoll = (usedRolls.length ? Math.max(...usedRolls) : 0) + 1;
        const activePlan = planCovering(structuresPage.items, batch.id);
        const suggested =
          activePlan?.totalAmount ??
          (batch.feeAmount && batch.feeAmount > 0
            ? batch.feeAmount
            : suggestMonthlyFee(batch.id, rosterCache.rows ?? []));
        return {
          batch,
          activeCount: active.length,
          usedRolls,
          nextRoll,
          activePlan,
          suggestedMonthlyFee: suggested,
        };
      });
    },
    enabled,
  );
}

export function useAdmissionDetail(leadId: ID | null) {
  const detail = useLeadDetail(leadId);
  const { moveStage, addFollowup, convert, saving } = useLeads();
  const { backend, instituteId } = useBackend();
  const [refreshing, setRefreshing] = useState(false);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await detail.refetch();
    } finally {
      setRefreshing(false);
    }
  }, [detail]);

  const convertLead = useCallback(
    async (input: ConvertLeadInput): Promise<ConvertLeadResult | null> => {
      const result = await convert(input);
      if (!result.ok) return null;
      if (rosterCache.rows != null && instituteId) {
        try {
          const batch = await backend.batches.get(instituteId, input.batchId);
          const fee = result.data.studentFee?.netAmount ?? input.monthlyFee ?? 0;
          rosterCache.prepend({
            id: result.data.student.id,
            fullName: result.data.student.fullName,
            photoUrl: result.data.student.photoUrl,
            batchId: batch.id,
            batchName: batch.name,
            roll: result.data.enrollment.rollNumber,
            monthlyFee: fee,
            due: fee,
            absentToday: false,
            attendancePercent: null,
            parentName: result.data.guardian.fullName,
            parentPhone: result.data.guardian.phone ?? normalizePhone10(input.phone),
          });
        } catch {
          // StudentListScreen also refreshes from the repo on mount.
        }
      }
      await detail.refetch();
      return result.data;
    },
    [backend, convert, detail, instituteId],
  );

  return {
    data: detail.data,
    loading: detail.loading && !detail.data,
    error: detail.error?.message ?? null,
    refreshing,
    refresh,
    moveStage,
    addFollowup,
    convertLead,
    saving,
  };
}

export function findMatchingBatch(
  options: readonly ConvertBatchOption[],
  lead: Pick<AdmissionLead, 'classInterested'>,
): ConvertBatchOption | undefined {
  const cls = lead.classInterested?.trim().toLowerCase();
  if (!cls) return options[0];
  return (
    options.find((opt) => (opt.batch.grade ?? '').toLowerCase() === cls) ??
    options.find((opt) => opt.batch.name.toLowerCase().includes(cls)) ??
    options[0]
  );
}

export { segmentForStage };
