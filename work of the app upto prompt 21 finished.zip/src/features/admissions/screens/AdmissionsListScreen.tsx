import React from 'react';
import { FlatList, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import { SEGMENT_LABELS } from '@/core/contracts/admissions';
import { C, LAYOUT, R, S, SHADOW } from '@/lib/theme';
import { LeadRow } from '../components/LeadRow';
import { StageSegments } from '../components/StageSegments';
import { SummaryStrip } from '../components/SummaryStrip';
import { useAdmissionsWorkspace } from '../hooks';

const TAB_BAR_INSET = 148;

export function AdmissionsListScreen() {
  const {
    summary,
    items,
    allCount,
    openCount,
    counts,
    segment,
    setSegment,
    loading,
    error,
    refreshing,
    refresh,
  } = useAdmissionsWorkspace();

  const openNew = () => router.push('/(owner)/admissions/new' as never);

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        data={loading ? [] : items}
        keyExtractor={(item) => item.lead.id}
        renderItem={({ item }) => (
          <LeadRow
            item={item}
            onPress={() => router.push(`/(owner)/admissions/${item.lead.id}` as never)}
          />
        )}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => void refresh()}
            tintColor={C.primary}
          />
        }
        contentContainerStyle={{ paddingTop: 10, paddingBottom: TAB_BAR_INSET, flexGrow: 1 }}
        ListHeaderComponent={
          <View style={{ gap: S.md + 2, marginBottom: S.md }}>
            <View style={{ paddingHorizontal: LAYOUT.margin, gap: 2 }}>
              <Text variant="h2">Admissions</Text>
              <Text variant="caption" c={C.secondary} tabular>
                {openCount} {openCount === 1 ? 'open enquiry' : 'open enquiries'}
              </Text>
            </View>

            <SummaryStrip summary={summary} />

            <StageSegments value={segment} counts={counts} onChange={setSegment} />
          </View>
        }
        ListEmptyComponent={
          loading ? (
            <View style={{ paddingHorizontal: LAYOUT.margin }}>
              <ListSkeleton rows={5} h={72} />
            </View>
          ) : error && allCount === 0 ? (
            <ErrorState message={error} onRetry={() => void refresh()} />
          ) : (
            <EmptyState
              icon="funnel-outline"
              title={
                allCount === 0
                  ? 'Add your first enquiry'
                  : `No ${SEGMENT_LABELS[segment].toLowerCase()} enquiries`
              }
              text={
                segment === 'new'
                  ? 'Walk-ins, referrals and social enquiries start here.'
                  : 'Leads move into this stage as you follow up or book demos.'
              }
              actionLabel={segment === 'new' ? 'New enquiry' : undefined}
              onAction={segment === 'new' ? openNew : undefined}
            />
          )
        }
        showsVerticalScrollIndicator={false}
      />

      <Pressable
        accessibilityRole="button"
        accessibilityLabel="New enquiry"
        onPress={openNew}
        style={({ pressed }) => ({
          position: 'absolute',
          right: LAYOUT.margin,
          bottom: 108,
          height: 52,
          paddingHorizontal: 18,
          borderRadius: R.chip,
          backgroundColor: C.accent,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
          opacity: pressed ? 0.9 : 1,
          ...SHADOW,
        })}
      >
        <Ionicons name="add" size={22} color={C.surface} />
        <Text variant="body" weight={700} c={C.surface}>
          New enquiry
        </Text>
      </Pressable>
    </View>
  );
}
