import React, { useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, Chip, DateField, Input, Select, Text } from '@/components/ui';
import {
  CREATE_SOURCES,
  normalizePhone10,
  validateCreateEnquiry,
  type CreateEnquiryErrors,
} from '@/core/contracts/admissions';
import type { LeadSource } from '@/core/contracts/models';
import { todayISO } from '@/lib/format';
import { C, LAYOUT, S } from '@/lib/theme';
import { useSessionStore } from '@/store/session';
import { useCreateEnquiryOptions } from '../hooks';

const CLASS_CHIPS = ['8', '9', '10', '11', '12'] as const;

function tomorrowISO(): string {
  const d = new Date(`${todayISO()}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

export function CreateEnquiryScreen() {
  const { user } = useSessionStore();
  const { assignees, subjectSuggestions, create, saving } = useCreateEnquiryOptions();

  const [studentName, setStudentName] = useState('');
  const [phone, setPhone] = useState('');
  const [classInterested, setClassInterested] = useState('10');
  const [subjectInterest, setSubjectInterest] = useState('Science');
  const [source, setSource] = useState<LeadSource>('walk_in');
  const [assignedTo, setAssignedTo] = useState(user?.userId ?? '');
  const [nextFollowupDate, setNextFollowupDate] = useState(tomorrowISO);
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<CreateEnquiryErrors>({});

  const effectiveAssignedTo = assignedTo || user?.userId || assignees[0]?.userId || '';

  const assigneeOptions = useMemo(
    () => assignees.map((a) => ({ value: a.userId, label: a.fullName, badge: a.role })),
    [assignees],
  );

  const handleSave = async () => {
    const nextErrors = validateCreateEnquiry({
      studentName,
      phone,
      classInterested,
      nextFollowupDate,
    });
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const result = await create({
      studentName: studentName.trim(),
      phone: normalizePhone10(phone),
      classInterested: classInterested.trim(),
      subjectInterest: subjectInterest.trim() || null,
      source,
      stage: 'new',
      assignedTo: effectiveAssignedTo || null,
      nextFollowupAt: `${nextFollowupDate}T12:00:00.000Z`,
      nextFollowupNote: notes.trim() || null,
      notes: notes.trim() || null,
    });

    if (result.ok) {
      router.back();
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 10, paddingBottom: 6 }}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Back to admissions"
            onPress={() => router.back()}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
          >
            <Ionicons name="chevron-back" size={20} color={C.primary} />
            <Text variant="caption" weight={700} c={C.primary}>
              Admissions
            </Text>
          </Pressable>
        </View>

        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 24, gap: S.md + 2 }}
          showsVerticalScrollIndicator={false}
        >
          <Text variant="h2">New enquiry</Text>

          <Input
            label="Student name"
            value={studentName}
            onChangeText={(v) => {
              setStudentName(v);
              if (errors.studentName) setErrors((e) => ({ ...e, studentName: undefined }));
            }}
            error={errors.studentName}
            placeholder="e.g. Rohan Verma"
            autoCapitalize="words"
            returnKeyType="next"
          />

          <Input
            label="Phone"
            value={phone}
            onChangeText={(v) => {
              setPhone(v.replace(/\D/g, '').slice(0, 10));
              if (errors.phone) setErrors((e) => ({ ...e, phone: undefined }));
            }}
            error={errors.phone}
            placeholder="10-digit mobile"
            keyboardType="phone-pad"
            maxLength={10}
          />

          <View style={{ gap: 8 }}>
            <Text variant="label" c={C.secondary}>
              Class
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
              {CLASS_CHIPS.map((cls) => (
                <Chip
                  key={cls}
                  label={`Class ${cls}`}
                  active={classInterested === cls}
                  onPress={() => {
                    setClassInterested(cls);
                    if (errors.classInterested) setErrors((e) => ({ ...e, classInterested: undefined }));
                  }}
                />
              ))}
            </ScrollView>
            {errors.classInterested ? (
              <Text variant="caption" c={C.danger}>
                {errors.classInterested}
              </Text>
            ) : null}
          </View>

          <View style={{ gap: 8 }}>
            <Input
              label="Subject interest"
              value={subjectInterest}
              onChangeText={setSubjectInterest}
              placeholder="e.g. Science, Mathematics"
            />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
              {subjectSuggestions.map((subj) => (
                <Chip
                  key={subj}
                  label={subj}
                  active={subjectInterest === subj}
                  onPress={() => setSubjectInterest(subj)}
                />
              ))}
            </ScrollView>
          </View>

          <View style={{ gap: 8 }}>
            <Text variant="label" c={C.secondary}>
              Source
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {CREATE_SOURCES.map((opt) => (
                <Chip
                  key={opt.key}
                  label={opt.label}
                  active={source === opt.key}
                  onPress={() => setSource(opt.key)}
                />
              ))}
            </View>
          </View>

          <Select
            label="Assigned to"
            options={assigneeOptions}
            value={effectiveAssignedTo}
            onChange={setAssignedTo}
            placeholder="Choose staff member"
            searchable={assigneeOptions.length > 6}
          />

          <DateField
            label="First follow-up date"
            value={nextFollowupDate}
            onChange={(_dmy, iso) => {
              setNextFollowupDate(iso);
              if (errors.nextFollowupDate) setErrors((e) => ({ ...e, nextFollowupDate: undefined }));
            }}
            error={errors.nextFollowupDate}
          />

          <Input
            label="Note (optional)"
            value={notes}
            onChangeText={setNotes}
            placeholder="Morning or evening batch preference…"
            multiline
          />
        </ScrollView>

        <View
          style={{
            paddingHorizontal: LAYOUT.margin,
            paddingTop: 10,
            paddingBottom: 14,
            backgroundColor: C.surface,
            borderTopWidth: 1,
            borderTopColor: C.hairline,
          }}
        >
          <Button
            title="Save enquiry"
            variant="primary"
            loading={saving}
            onPress={() => void handleSave()}
          />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
