import React, { useState } from 'react';
import { Linking, Pressable, RefreshControl, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button, ErrorState, ListSkeleton, Text } from '@/components/ui';
import { toast } from '@/core/backend';
import { leadCallUrl, leadWhatsAppUrl } from '@/core/contracts/admissions';
import { C, LAYOUT, S } from '@/lib/theme';
import { ConvertLeadSheet } from '../components/ConvertLeadSheet';
import { FollowupSheet } from '../components/FollowupSheet';
import {
  LeadHeaderCard,
  LeadNextActionCard,
  LeadStageStrip,
} from '../components/LeadDetailCards';
import { LeadStageHistoryCard, LeadTimelineCard } from '../components/LeadTimelineCard';
import { LostReasonSheet } from '../components/LostReasonSheet';
import { useAdmissionDetail } from '../hooks';

export function LeadDetailScreen({ id }: { id: string }) {
  const leadId = id || null;
  const {
    data,
    loading,
    error,
    refreshing,
    refresh,
    moveStage,
    addFollowup,
    convertLead,
    saving,
  } = useAdmissionDetail(leadId);

  const [followupOpen, setFollowupOpen] = useState(false);
  const [lostOpen, setLostOpen] = useState(false);
  const [convertOpen, setConvertOpen] = useState(false);

  const openExternal = async (url: string | null, fallbackMsg: string) => {
    if (!url) {
      toast.info('No valid mobile number on this enquiry');
      return;
    }
    const allowed = await Linking.canOpenURL(url).catch(() => false);
    if (!allowed) {
      toast.error(fallbackMsg);
      return;
    }
    await Linking.openURL(url);
  };

  if (!leadId) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
        <ErrorState title="Enquiry not found" message="No enquiry id was provided." />
      </SafeAreaView>
    );
  }

  if (loading && !data) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin }} edges={['top']}>
        <ListSkeleton rows={4} h={96} />
      </SafeAreaView>
    );
  }

  if (error && !data) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
        <ErrorState message={error} onRetry={() => void refresh()} />
      </SafeAreaView>
    );
  }

  if (!data) return null;

  const { lead, assignedToName, followups, stageChanges } = data;
  const isOpen = lead.stage !== 'enrolled' && lead.stage !== 'lost';

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View
        style={{
          paddingHorizontal: LAYOUT.margin,
          paddingVertical: 10,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back to admissions"
          onPress={() => router.back()}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}
        >
          <Ionicons name="chevron-back" size={20} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>
            Admissions
          </Text>
        </Pressable>
        {isOpen ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Mark as lost"
            onPress={() => setLostOpen(true)}
            hitSlop={8}
          >
            <Text variant="caption" weight={700} c={C.danger}>
              Mark lost
            </Text>
          </Pressable>
        ) : null}
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 28, gap: S.md + 2 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void refresh()} tintColor={C.primary} />}
        showsVerticalScrollIndicator={false}
      >
        <LeadHeaderCard
          lead={lead}
          assignedToName={assignedToName}
          onCall={() => void openExternal(leadCallUrl(lead.phone), 'Could not open phone dialer')}
          onWhatsApp={() => void openExternal(leadWhatsAppUrl(lead.phone, lead.studentName), 'Could not open WhatsApp')}
        />

        <LeadNextActionCard
          lead={lead}
          saving={saving}
          onReopen={() => void moveStage({ id: lead.id, stage: 'contacted', lostReason: null })}
        />

        {isOpen ? (
          <LeadStageStrip
            current={lead.stage}
            onSelect={(stage) => void moveStage({ id: lead.id, stage })}
          />
        ) : null}

        <LeadTimelineCard
          followups={followups}
          canLog={isOpen}
          onOpenLog={() => setFollowupOpen(true)}
        />

        <LeadStageHistoryCard stageChanges={stageChanges} />
      </ScrollView>

      {isOpen ? (
        <View
          style={{
            paddingHorizontal: LAYOUT.margin,
            paddingTop: 10,
            paddingBottom: 14,
            backgroundColor: C.surface,
            borderTopWidth: 1,
            borderTopColor: C.hairline,
          }}
        >
          <Button
            title="Convert to student"
            variant="primary"
            icon="person-add-outline"
            onPress={() => setConvertOpen(true)}
          />
        </View>
      ) : null}

      <FollowupSheet
        visible={followupOpen}
        leadName={lead.studentName}
        saving={saving}
        onClose={() => setFollowupOpen(false)}
        onSubmit={async (payload) => {
          const res = await addFollowup({ leadId: lead.id, ...payload });
          if (res.ok) await refresh();
          return res.ok;
        }}
      />

      <LostReasonSheet
        visible={lostOpen}
        leadName={lead.studentName}
        saving={saving}
        onClose={() => setLostOpen(false)}
        onConfirm={async (reason) => {
          const res = await moveStage({ id: lead.id, stage: 'lost', lostReason: reason });
          if (res.ok) await refresh();
          return res.ok;
        }}
      />

      <ConvertLeadSheet
        visible={convertOpen}
        lead={lead}
        saving={saving}
        onClose={() => setConvertOpen(false)}
        onConvert={async (input) => (await convertLead(input)) !== null}
      />
    </SafeAreaView>
  );
}
