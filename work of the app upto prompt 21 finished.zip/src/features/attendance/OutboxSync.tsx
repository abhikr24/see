import { useEffect, useRef } from 'react';
import NetInfo from '@react-native-community/netinfo';

import { toBackendError } from '@/core/contracts/errors';
import { useBackend } from '@/core/hooks/context';
import { toast } from '@/core/hooks/toast';
import { commitSheet, invalidateAttendance } from './commit';
import { attendanceOutbox } from './outbox';

const RETRY_MS = 30_000;
const TRANSIENT = new Set(['NETWORK', 'TIMEOUT', 'UNAVAILABLE']);

/**
 * Mounted once at the root. Flushes queued roll calls whenever the device is
 * (or comes back) online: on launch, on reconnect, when something is queued,
 * and every 30 s while the queue is not empty. Renders nothing.
 */
export function AttendanceOutboxSync() {
  const { backend } = useBackend();
  const busy = useRef(false);
  const online = useRef(true);

  useEffect(() => {
    let alive = true;

    const flush = async () => {
      if (busy.current || !online.current) return;
      await attendanceOutbox.load();
      const pending = attendanceOutbox.list().filter((item) => item.backendName === backend.name);
      if (pending.length === 0) return;
      busy.current = true;
      let synced = 0;
      try {
        for (const item of pending) {
          if (!alive || !online.current) break;
          try {
            await commitSheet(backend, item.instituteId, item.input);
            attendanceOutbox.remove(item.key, item.queuedAt);
            attendanceOutbox.markSynced();
            void invalidateAttendance(backend.name, item.instituteId);
            synced += 1;
          } catch (cause) {
            const error = toBackendError(cause);
            if (TRANSIENT.has(error.code)) break;
            attendanceOutbox.remove(item.key, item.queuedAt);
            toast.error(`A queued attendance sheet could not be saved. ${error.message}`);
          }
        }
      } finally {
        busy.current = false;
      }
      if (synced > 0) {
        toast.success(synced === 1 ? 'Queued attendance synced' : `${synced} queued attendance sheets synced`);
      }
    };

    const unsubscribeNet = NetInfo.addEventListener((state) => {
      const next = state.isConnected !== false && state.isInternetReachable !== false;
      const cameBack = next && !online.current;
      online.current = next;
      if (cameBack) void flush();
    });
    const unsubscribeQueue = attendanceOutbox.subscribe(() => {
      if (online.current && !busy.current) void flush();
    });
    const timer = setInterval(() => void flush(), RETRY_MS);
    void NetInfo.fetch().then((state) => {
      online.current = state.isConnected !== false && state.isInternetReachable !== false;
      void flush();
    });

    return () => {
      alive = false;
      unsubscribeNet();
      unsubscribeQueue();
      clearInterval(timer);
    };
  }, [backend]);

  return null;
}
