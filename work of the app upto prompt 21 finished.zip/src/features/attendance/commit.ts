import type { AbsenceAlertResult, AttendanceSheet, ID } from '@/core/contracts/models';
import type { AttendanceSheetInput, Backend } from '@/core/contracts/ports';
import { queryCache, queryScope } from '@/core/hooks/cache';

export interface CommitResult {
  sheet: AttendanceSheet;
  /** null when the alert step itself failed — the attendance is still saved. */
  alerts: AbsenceAlertResult | null;
}

/** Every cache a saved roll call can change: timetable tab, student 360, dashboard, batch cards. */
export const ATTENDANCE_DOMAINS = ['attendance', 'progress', 'analytics', 'batches'] as const;

export const attendanceScopes = (backendName: string, instituteId: ID | null): string[] =>
  ATTENDANCE_DOMAINS.map((domain) => queryScope(backendName, domain, instituteId));

/**
 * The one write path for a roll call, used by the live save and the offline flush:
 * one batched upsert of the whole sheet, then the absence alerts for parents.
 * Alerts never undo a save that already landed.
 */
export async function commitSheet(backend: Backend, instituteId: ID, input: AttendanceSheetInput): Promise<CommitResult> {
  const sheet = await backend.attendance.saveSheet(instituteId, input);
  let alerts: AbsenceAlertResult | null = null;
  try {
    alerts = await backend.attendance.notifyAbsentParents(instituteId, sheet.session.id);
  } catch {
    alerts = null;
  }
  return { sheet, alerts };
}

export function savedMessage(result: CommitResult, update: boolean): string {
  const head = update ? 'Attendance updated' : 'Attendance saved';
  const alerts = result.alerts;
  if (!alerts) return `${head}. Parent alerts could not be sent`;
  if (alerts.disabled || alerts.sent === 0) return head;
  return `${head} · ${alerts.sent} parent${alerts.sent === 1 ? '' : 's'} notified`;
}

export function invalidateAttendance(backendName: string, instituteId: ID): Promise<void> {
  return queryCache.invalidate(attendanceScopes(backendName, instituteId));
}
