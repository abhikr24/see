import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import type { AttendanceCorrectionEntry } from '@/core/contracts/models';
import { C } from '@/lib/theme';
import { agoLabel } from '../model';
import { STATUS_WORD } from '../register-model';

const ROLE_WORD = { owner: 'Owner', admin: 'Admin', teacher: 'Teacher', student: 'Student', parent: 'Parent' } as const;

/** Earlier corrections to this day, newest first: who changed what, and the note they left. */
export function CorrectionHistory({ entries }: { entries: readonly AttendanceCorrectionEntry[] }) {
  if (entries.length === 0) return null;
  return (
    <View style={{ gap: 10, paddingTop: 8 }}>
      <Text variant="label" c={C.muted} style={{ letterSpacing: 0.6 }}>
        EARLIER CORRECTIONS
      </Text>
      {entries.map((entry) => (
        <View
          key={entry.id}
          style={{ gap: 4, padding: 12, borderRadius: 14, backgroundColor: C.canvas, borderWidth: 1, borderColor: C.hairline }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Ionicons name="pencil" size={12} color={C.primary} />
            <Text weight={600} style={{ fontSize: 13.5, flex: 1 }} numberOfLines={1}>
              {entry.studentName}: {STATUS_WORD[entry.currentStatus]} → {STATUS_WORD[entry.requestedStatus]}
            </Text>
          </View>
          {entry.reason ? (
            <Text c={C.ink} style={{ fontSize: 13 }}>
              “{entry.reason}”
            </Text>
          ) : null}
          <Text c={C.secondary} style={{ fontSize: 12 }}>
            {entry.changedByName ?? 'Someone'}
            {entry.changedByRole ? ` (${ROLE_WORD[entry.changedByRole]})` : ''} · {agoLabel(entry.createdAt)}
          </Text>
        </View>
      ))}
    </View>
  );
}
