import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import type { AttendanceStatus, RegisterRow } from '@/core/contracts/models';
import { C } from '@/lib/theme';
import { STATUS_WORD } from '../register-model';

const PILLS: { status: AttendanceStatus; letter: string; fill: string; ink: string }[] = [
  { status: 'present', letter: 'P', fill: C.teal, ink: C.surface },
  { status: 'late', letter: 'L', fill: C.warning, ink: C.ink },
  { status: 'absent', letter: 'A', fill: C.danger, ink: C.surface },
  { status: 'leave', letter: 'LV', fill: C.primary, ink: C.surface },
];

export interface CorrectionRowProps {
  row: RegisterRow;
  /** The status picked in this sheet, if it differs from the saved one. */
  picked: AttendanceStatus | undefined;
  editable: boolean;
  onPick: (status: AttendanceStatus) => void;
}

/** One student: roll, name, what it was before, and a P / L / A control. */
export const CorrectionRow = React.memo(function CorrectionRow({ row, picked, editable, onPick }: CorrectionRowProps) {
  const shown = picked ?? row.status;
  const pills = PILLS.filter((p) => p.status !== 'leave' || row.status === 'leave' || row.originalStatus === 'leave');
  const was = picked ? row.status : row.originalStatus;
  return (
    <View
      style={{
        minHeight: 56,
        paddingVertical: 8,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        borderBottomWidth: 1,
        borderBottomColor: C.hairline,
      }}
    >
      <Text c={C.muted} tabular weight={600} style={{ width: 24, fontSize: 13 }}>
        {row.rollNumber ?? '–'}
      </Text>
      <View style={{ flex: 1, gap: 2 }}>
        <Text weight={600} numberOfLines={1} style={{ fontSize: 15 }}>
          {row.fullName}
        </Text>
        {was ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Ionicons name="pencil" size={10} color={picked ? C.accent : C.secondary} />
            <Text c={C.secondary} style={{ fontSize: 12 }}>
              {picked ? 'Was' : 'Originally'} {STATUS_WORD[was].toLowerCase()}
            </Text>
          </View>
        ) : null}
      </View>
      <View style={{ flexDirection: 'row', gap: 6 }}>
        {pills.map((pill) => {
          const selected = shown === pill.status;
          return (
            <Pressable
              key={pill.status}
              accessibilityRole="button"
              accessibilityLabel={`${row.fullName}: ${STATUS_WORD[pill.status]}`}
              accessibilityState={{ selected, disabled: !editable }}
              disabled={!editable}
              onPress={() => onPick(pill.status)}
              style={({ pressed }) => ({
                minWidth: 40,
                height: 36,
                paddingHorizontal: 6,
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: selected ? pill.fill : pressed ? C.track : C.canvas,
                opacity: !editable && !selected ? 0.5 : 1,
              })}
            >
              <Text weight={700} c={selected ? pill.ink : C.secondary} style={{ fontSize: 13 }}>
                {pill.letter}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
});
