import React from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import type { ISODate } from '@/core/contracts/models';
import { C, LAYOUT, R } from '@/lib/theme';
import { addDaysIso, dateChipLabel, todayIso } from '../model';

const DAYS_BACK = 14;

export interface DateSheetProps {
  visible: boolean;
  value: ISODate;
  /** Unsaved marks would be dropped by switching. */
  dirty: boolean;
  onPick: (date: ISODate) => void;
  onClose: () => void;
}

/** Pick the roll-call date: today and the previous two weeks. Never a future day. */
export function DateSheet({ visible, value, dirty, onPick, onClose }: DateSheetProps) {
  if (!visible) return null;
  const today = todayIso();
  const dates = Array.from({ length: DAYS_BACK }, (_, i) => addDaysIso(today, -i));
  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <Pressable accessibilityLabel="Close" onPress={onClose} style={{ flex: 1, backgroundColor: C.scrim }} />
      <View style={{ backgroundColor: C.surface, borderTopLeftRadius: R.sheet, borderTopRightRadius: R.sheet, maxHeight: '70%' }}>
        <SafeAreaView edges={['bottom']}>
          <View style={{ alignItems: 'center', paddingTop: 10 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: C.hairline }} />
          </View>
          <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, paddingBottom: 8 }}>
            <Text variant="title">Attendance date</Text>
            <Text c={dirty ? C.warning : C.secondary} style={{ fontSize: 13, marginTop: 2 }}>
              {dirty ? 'Unsaved marks on this date will be discarded.' : 'A saved date opens in edit mode.'}
            </Text>
          </View>
          <ScrollView contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 16, gap: 8 }}>
            {dates.map((date) => {
              const selected = date === value;
              return (
                <Pressable
                  key={date}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  onPress={() => onPick(date)}
                  style={({ pressed }) => ({
                    height: 48,
                    borderRadius: R.field,
                    paddingHorizontal: 14,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    backgroundColor: selected ? C.primary : pressed ? C.track : C.canvas,
                  })}
                >
                  <Text weight={600} c={selected ? C.surface : C.ink}>
                    {dateChipLabel(date, today)}
                  </Text>
                  {selected ? <Ionicons name="checkmark" size={18} color={C.surface} /> : null}
                </Pressable>
              );
            })}
          </ScrollView>
        </SafeAreaView>
      </View>
    </Modal>
  );
}
