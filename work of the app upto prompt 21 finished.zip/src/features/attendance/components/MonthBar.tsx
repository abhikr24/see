import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C } from '@/lib/theme';
import { monthLabel } from '../register-model';

function Chevron({ name, label, disabled, onPress }: { name: 'chevron-back' | 'chevron-forward'; label: string; disabled?: boolean; onPress: () => void }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      hitSlop={6}
      style={({ pressed }) => ({
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: pressed ? C.track : C.transparent,
        opacity: disabled ? 0.35 : 1,
      })}
    >
      <Ionicons name={name} size={22} color={C.ink} />
    </Pressable>
  );
}

const LEGEND = [
  { label: 'Present', color: C.teal },
  { label: 'Late', color: C.warning },
  { label: 'Absent', color: C.danger },
] as const;

export interface MonthBarProps {
  month: string;
  canGoNext: boolean;
  onPrevious: () => void;
  onNext: () => void;
}

/** Month selector with chevrons, and the three-dot legend beneath it. */
export function MonthBar({ month, canGoNext, onPrevious, onNext }: MonthBarProps) {
  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Chevron name="chevron-back" label="Previous month" onPress={onPrevious} />
        <Text variant="title" accessibilityRole="header" tabular>
          {monthLabel(month)}
        </Text>
        <Chevron name="chevron-forward" label="Next month" disabled={!canGoNext} onPress={onNext} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 16 }}>
        {LEGEND.map((item) => (
          <View key={item.label} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: item.color }} />
            <Text variant="caption" c={C.secondary} style={{ fontSize: 12 }}>
              {item.label}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}
