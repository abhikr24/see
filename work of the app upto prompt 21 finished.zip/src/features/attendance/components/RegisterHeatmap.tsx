import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import type { MonthRegister, RegisterCell } from '@/core/contracts/models';
import { C, R } from '@/lib/theme';
import { WEEKDAY_INITIALS, cellLabel } from '../register-model';

export const SQUARE = 28;
const GAP = 6;

interface Paint {
  fill: string;
  ink: string;
  outline: string | null;
}

/** One place that turns a cell's state, tone and tint into a colour. */
export function paintOf(cell: RegisterCell): Paint {
  if (cell.state === 'future') return { fill: C.track, ink: C.muted, outline: null };
  if (cell.state === 'unmarked') return { fill: C.transparent, ink: C.muted, outline: C.hairline };
  if (cell.tone === 'absent') return { fill: C.danger, ink: C.surface, outline: null };
  if (cell.tone === 'late') return { fill: C.warning, ink: C.ink, outline: null };
  if (cell.tint === 3) return { fill: C.teal, ink: C.surface, outline: null };
  return { fill: cell.tint === 2 ? C.tealMid : C.tealLight, ink: C.ink, outline: null };
}

function Square({ cell, onPress }: { cell: RegisterCell; onPress: (cell: RegisterCell) => void }) {
  const paint = paintOf(cell);
  const inert = cell.state === 'future';
  return (
    <Pressable
      accessibilityRole={inert ? 'text' : 'button'}
      accessibilityLabel={cellLabel(cell)}
      disabled={inert}
      onPress={() => onPress(cell)}
      style={({ pressed }) => ({ flex: 1, height: 36, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.7 : 1 })}
    >
      <View
        style={{
          width: SQUARE,
          height: SQUARE,
          borderRadius: R.cell,
          backgroundColor: paint.fill,
          alignItems: 'center',
          justifyContent: 'center',
          borderWidth: cell.isToday ? 2 : paint.outline ? 1 : 0,
          borderColor: cell.isToday ? C.primary : (paint.outline ?? C.transparent),
        }}
      >
        <Text weight={700} c={paint.ink} tabular style={{ fontSize: 11 }}>
          {cell.day}
        </Text>
        {cell.corrected ? (
          <View
            accessibilityLabel="Corrected"
            style={{
              position: 'absolute',
              top: -6,
              right: -6,
              width: 16,
              height: 16,
              borderRadius: 8,
              backgroundColor: C.primary,
              borderWidth: 1.5,
              borderColor: C.surface,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="pencil" size={8} color={C.surface} />
          </View>
        ) : null}
      </View>
    </Pressable>
  );
}

export interface RegisterHeatmapProps {
  register: MonthRegister;
  onDayPress: (cell: RegisterCell) => void;
}

/** Weekday initials above a 7-column grid of 28pt squares. Colours come from the repo's cells, nowhere else. */
export function RegisterHeatmap({ register, onDayPress }: RegisterHeatmapProps) {
  const cells: (RegisterCell | null)[] = [...Array.from({ length: register.startOffset }, () => null), ...register.days];
  while (cells.length % 7 !== 0) cells.push(null);
  const weeks = Array.from({ length: cells.length / 7 }, (_, w) => cells.slice(w * 7, w * 7 + 7));
  return (
    <View style={{ gap: GAP }}>
      <View style={{ flexDirection: 'row', gap: GAP }}>
        {WEEKDAY_INITIALS.map((initial, i) => (
          <View key={i} style={{ flex: 1, alignItems: 'center' }}>
            <Text variant="label" c={C.muted}>
              {initial}
            </Text>
          </View>
        ))}
      </View>
      {weeks.map((week, w) => (
        <View key={w} style={{ flexDirection: 'row', gap: GAP }}>
          {week.map((cell, c) =>
            cell ? <Square key={cell.date} cell={cell} onPress={onDayPress} /> : <View key={`gap-${w}-${c}`} style={{ flex: 1, height: 36 }} />,
          )}
        </View>
      ))}
    </View>
  );
}
