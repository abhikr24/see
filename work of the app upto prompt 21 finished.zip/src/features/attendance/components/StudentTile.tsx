import React, { memo } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, Text } from '@/components/ui';
import type { AttendanceRollStudent, AttendanceStatus, ID } from '@/core/contracts/models';
import { C } from '@/lib/theme';

export const TILE_HEIGHT = 108;
export const TILE_GAP = 10;
const AVATAR = 44;
const BADGE = 18;

const LOOK: Record<AttendanceStatus, { color: string; icon: keyof typeof Ionicons.glyphMap; label: string }> = {
  present: { color: C.teal, icon: 'checkmark', label: 'present' },
  absent: { color: C.danger, icon: 'close', label: 'absent' },
  late: { color: C.warning, icon: 'time', label: 'late' },
  leave: { color: C.danger, icon: 'close', label: 'on leave' },
};

export interface StudentTileProps {
  student: AttendanceRollStudent;
  status: AttendanceStatus;
  width: number;
  onPress: (studentId: ID) => void;
  onLongPress: (studentId: ID) => void;
}

/**
 * One 108pt roll-call tile: photo with a status badge, one-line name, roll
 * number, and a 4pt status strip along the bottom. Absent dims the photo to
 * 60% and paints the strip red; late paints it amber. Memoised on its status
 * so a tap repaints one tile, not the grid.
 */
function Tile({ student, status, width, onPress, onLongPress }: StudentTileProps) {
  const look = LOOK[status];
  const dim = status === 'absent' || status === 'leave';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${student.fullName}, roll ${student.rollNumber ?? 'not set'}, ${look.label}`}
      accessibilityHint="Tap to change. Long press for more."
      onPress={() => onPress(student.studentId)}
      onLongPress={() => onLongPress(student.studentId)}
      delayLongPress={380}
      style={({ pressed }) => ({
        width,
        height: TILE_HEIGHT,
        borderRadius: 16,
        backgroundColor: C.surface,
        borderWidth: 1,
        borderColor: C.hairline,
        overflow: 'hidden',
        alignItems: 'center',
        paddingTop: 12,
        paddingHorizontal: 8,
        transform: [{ scale: pressed ? 0.96 : 1 }],
      })}
    >
      <View style={{ width: AVATAR, height: AVATAR }}>
        <View style={{ opacity: dim ? 0.6 : 1 }}>
          <Avatar name={student.fullName} uri={student.photoUrl} size={AVATAR} />
        </View>
        <View
          style={{
            position: 'absolute',
            right: -4,
            bottom: -2,
            width: BADGE,
            height: BADGE,
            borderRadius: BADGE / 2,
            backgroundColor: look.color,
            borderWidth: 2,
            borderColor: C.surface,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name={look.icon} size={10} color={C.surface} />
        </View>
      </View>
      <Text
        weight={600}
        numberOfLines={1}
        ellipsizeMode="tail"
        c={dim ? C.secondary : C.ink}
        style={{ fontSize: 13, marginTop: 8, maxWidth: '100%' }}
      >
        {student.fullName}
      </Text>
      <Text tabular c={C.muted} style={{ fontSize: 11, marginTop: 1 }}>
        {student.rollNumber != null ? `Roll ${student.rollNumber}` : 'No roll'}
      </Text>
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 4, backgroundColor: look.color }} />
    </Pressable>
  );
}

export const StudentTile = memo(Tile);
