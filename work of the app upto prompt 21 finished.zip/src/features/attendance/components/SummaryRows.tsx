import React from 'react';
import { View } from 'react-native';

import { Text } from '@/components/ui';
import type { RegisterSummary } from '@/core/contracts/models';
import { pct } from '@/lib/format';
import { C } from '@/lib/theme';

/** Three rows — label, thin bar, right-aligned tabular %. Every figure is a field of the repo's summary. */
export function SummaryRows({ summary }: { summary: RegisterSummary }) {
  const rows = [
    { label: 'Present', value: summary.presentPercent, color: C.teal },
    { label: 'Late', value: summary.latePercent, color: C.warning },
    { label: 'Absent', value: summary.absentPercent, color: C.danger },
  ] as const;
  return (
    <View style={{ gap: 14 }}>
      {rows.map((row) => (
        <View
          key={row.label}
          accessible
          accessibilityLabel={`${row.label} ${pct(row.value)}`}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}
        >
          <Text weight={600} c={C.ink} style={{ width: 60, fontSize: 14 }}>
            {row.label}
          </Text>
          <View style={{ flex: 1, height: 6, borderRadius: 3, backgroundColor: C.track, overflow: 'hidden' }}>
            <View style={{ width: `${Math.min(100, Math.max(0, row.value))}%`, height: 6, borderRadius: 3, backgroundColor: row.color }} />
          </View>
          <Text weight={700} c={C.ink} tabular style={{ width: 44, textAlign: 'right', fontSize: 14 }}>
            {pct(row.value)}
          </Text>
        </View>
      ))}
    </View>
  );
}
