import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';

export interface SyncBannerProps {
  online: boolean;
  queued: boolean;
  lastSynced: string;
}

/** The calm offline line. Grey, not red: nothing is lost, it is just waiting. */
export function SyncBanner({ online, queued, lastSynced }: SyncBannerProps) {
  if (online && !queued) return null;
  const title = !online
    ? queued
      ? 'Saved on this phone · will sync when you are online'
      : 'You are offline · saving will queue on this phone'
    : 'Syncing saved attendance…';
  return (
    <View
      accessibilityRole="summary"
      style={{
        marginHorizontal: LAYOUT.margin,
        marginTop: 10,
        paddingHorizontal: 14,
        paddingVertical: 10,
        borderRadius: R.field,
        backgroundColor: C.track,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
      }}
    >
      <Ionicons name={online ? 'sync-outline' : 'cloud-offline-outline'} size={18} color={C.secondary} />
      <View style={{ flex: 1 }}>
        <Text weight={600} c={C.ink} style={{ fontSize: 13 }}>
          {title}
        </Text>
        <Text c={C.secondary} style={{ fontSize: 12 }}>
          Last synced {lastSynced}
        </Text>
      </View>
    </View>
  );
}

export interface FailureBarProps {
  message: string;
  onRetry: () => void;
  onDismiss: () => void;
}

/** Save failed: the marks stay on screen, retry is one tap. */
export function FailureBar({ message, onRetry, onDismiss }: FailureBarProps) {
  return (
    <View
      accessibilityRole="alert"
      style={{
        marginHorizontal: LAYOUT.margin,
        marginTop: 10,
        paddingLeft: 14,
        paddingRight: 8,
        paddingVertical: 8,
        borderRadius: R.field,
        backgroundColor: C.dangerSoft,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
      }}
    >
      <Ionicons name="alert-circle" size={18} color={C.danger} />
      <View style={{ flex: 1 }}>
        <Text weight={600} c={C.ink} style={{ fontSize: 13 }}>
          Not saved — your marks are still here
        </Text>
        <Text c={C.secondary} numberOfLines={2} style={{ fontSize: 12 }}>
          {message}
        </Text>
      </View>
      <Pressable
        accessibilityRole="button"
        onPress={onRetry}
        style={({ pressed }) => ({
          paddingHorizontal: 14,
          height: 36,
          borderRadius: R.chip,
          backgroundColor: C.primary,
          justifyContent: 'center',
          opacity: pressed ? 0.85 : 1,
        })}
      >
        <Text weight={700} c={C.surface} style={{ fontSize: 13 }}>
          Retry
        </Text>
      </Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel="Dismiss" onPress={onDismiss} hitSlop={8}>
        <Ionicons name="close" size={18} color={C.muted} />
      </Pressable>
    </View>
  );
}
