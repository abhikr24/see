import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';

export interface TakeHeaderProps {
  title: string;
  dateLabel: string;
  editing: boolean;
  onBack: () => void;
  onDate: () => void;
  /** Opens the monthly register for this batch. Omit to hide the button. */
  onRegister?: () => void;
}

/** Compact header: back, "Class 10-A · Mathematics", date chip, and the edit-mode pill. */
export function TakeHeader({ title, dateLabel, editing, onBack, onDate, onRegister }: TakeHeaderProps) {
  return (
    <View style={{ paddingHorizontal: LAYOUT.margin - 8, paddingTop: 4, paddingBottom: 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back"
          onPress={onBack}
          hitSlop={6}
          style={({ pressed }) => ({
            width: 40,
            height: 40,
            borderRadius: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: pressed ? C.track : C.transparent,
          })}
        >
          <Ionicons name="chevron-back" size={22} color={C.ink} />
        </Pressable>
        <Text variant="title" numberOfLines={1} style={{ flex: 1, fontSize: 16 }}>
          {title}
        </Text>
        {onRegister ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Open the monthly register"
            onPress={onRegister}
            hitSlop={6}
            style={({ pressed }) => ({
              width: 32,
              height: 32,
              borderRadius: 16,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: pressed ? C.navySoft : C.surface,
              borderWidth: 1,
              borderColor: C.hairline,
            })}
          >
            <Ionicons name="grid-outline" size={15} color={C.primary} />
          </Pressable>
        ) : null}
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Date ${dateLabel}. Change date`}
          onPress={onDate}
          style={({ pressed }) => ({
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
            paddingHorizontal: 12,
            height: 32,
            borderRadius: R.chip,
            backgroundColor: pressed ? C.navySoft : C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
          })}
        >
          <Ionicons name="calendar-outline" size={14} color={C.primary} />
          <Text weight={600} c={C.primary} style={{ fontSize: 13 }}>
            {dateLabel}
          </Text>
          <Ionicons name="chevron-down" size={12} color={C.primary} />
        </Pressable>
      </View>
      {editing ? (
        <View
          style={{
            marginLeft: 44,
            marginTop: 2,
            alignSelf: 'flex-start',
            flexDirection: 'row',
            alignItems: 'center',
            gap: 5,
            paddingHorizontal: 10,
            paddingVertical: 3,
            borderRadius: R.chip,
            backgroundColor: C.navySoft,
          }}
        >
          <Ionicons name="create-outline" size={12} color={C.primary} />
          <Text weight={600} c={C.primary} style={{ fontSize: 11.5 }}>
            Editing saved sheet
          </Text>
        </View>
      ) : null}
    </View>
  );
}
