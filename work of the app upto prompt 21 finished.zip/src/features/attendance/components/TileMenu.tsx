import React from 'react';
import { Linking, Modal, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, Text } from '@/components/ui';
import type { AttendanceRollStudent, AttendanceStatus } from '@/core/contracts/models';
import { C, R, SHADOW } from '@/lib/theme';

const WORD: Record<AttendanceStatus, string> = { present: 'Present', absent: 'Absent', late: 'Late', leave: 'On leave' };

export interface TileMenuProps {
  student: AttendanceRollStudent | null;
  status: AttendanceStatus;
  /** Students after this one in roll order. */
  afterCount: number;
  onMarkAfter: (status: AttendanceStatus) => void;
  onClose: () => void;
}

function Row({
  icon,
  title,
  detail,
  disabled,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  detail: string;
  disabled?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 16,
        height: 60,
        backgroundColor: pressed ? C.track : C.surface,
        opacity: disabled ? 0.45 : 1,
      })}
    >
      <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name={icon} size={18} color={C.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text weight={600} style={{ fontSize: 15 }}>
          {title}
        </Text>
        <Text c={C.secondary} numberOfLines={1} style={{ fontSize: 12.5 }}>
          {detail}
        </Text>
      </View>
    </Pressable>
  );
}

/** Long-press menu: call the parent, or carry this tile's status to everyone after it. */
export function TileMenu({ student, status, afterCount, onMarkAfter, onClose }: TileMenuProps) {
  if (!student) return null;
  const phone = student.parentPhone?.replace(/[^\d+]/g, '') ?? '';
  const callable = phone.length >= 10;
  const carry: AttendanceStatus = status === 'leave' ? 'absent' : status;

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        accessibilityLabel="Close menu"
        onPress={onClose}
        style={{ flex: 1, backgroundColor: C.scrim, justifyContent: 'center', padding: 28 }}
      >
        <Pressable
          onPress={() => undefined}
          style={{ backgroundColor: C.surface, borderRadius: R.card, overflow: 'hidden', maxWidth: 380, width: '100%', alignSelf: 'center', ...SHADOW }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 16, borderBottomWidth: 1, borderBottomColor: C.hairline }}>
            <Avatar name={student.fullName} uri={student.photoUrl} size={40} />
            <View style={{ flex: 1 }}>
              <Text variant="title" numberOfLines={1}>
                {student.fullName}
              </Text>
              <Text c={C.secondary} style={{ fontSize: 12.5 }}>
                {student.rollNumber != null ? `Roll ${student.rollNumber} · ` : ''}
                {WORD[status]}
              </Text>
            </View>
          </View>
          <Row
            icon="call-outline"
            title="Call parent"
            detail={callable ? `${student.parentName ?? 'Parent'} · ${student.parentPhone}` : 'No parent number on file'}
            disabled={!callable}
            onPress={() => {
              onClose();
              void Linking.openURL(`tel:${phone}`).catch(() => undefined);
            }}
          />
          <View style={{ height: 1, backgroundColor: C.hairline, marginLeft: 64 }} />
          <Row
            icon="play-skip-forward-outline"
            title="Mark all after this"
            detail={
              afterCount > 0
                ? `Set ${afterCount} student${afterCount === 1 ? '' : 's'} after this to ${WORD[carry]}`
                : 'This is the last student'
            }
            disabled={afterCount === 0}
            onPress={() => {
              onMarkAfter(carry);
              onClose();
            }}
          />
        </Pressable>
      </Pressable>
    </Modal>
  );
}
