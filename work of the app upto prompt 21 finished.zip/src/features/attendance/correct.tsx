import React, { useCallback, useMemo } from 'react';
import { FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, View, useWindowDimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button, EmptyState, ErrorState, Input, Skeleton, Text } from '@/components/ui';
import { REASON_MAX, REASON_MIN } from '@/core/contracts/attendance-register';
import type { ID, ISODate, RegisterDay, RegisterRow } from '@/core/contracts/models';
import { useRegisterDay } from '@/core/hooks/register';
import { C, LAYOUT, R } from '@/lib/theme';
import { CorrectionHistory } from './components/CorrectionHistory';
import { CorrectionRow } from './components/CorrectionRow';
import { useCorrectAttendance, useCorrectionDraft } from './hooks/useCorrection';
import { dayLabel } from './register-model';

/** Neutral starting points for the note. They describe what happened to the record, never who is at fault. */
const NOTE_IDEAS = ['Joined after roll call', 'Entered against the wrong student', 'Leave confirmed by the parent', 'Saved before the roll finished'];

type Item = { key: string; kind: 'sheet'; title: string } | { key: string; kind: 'row'; row: RegisterRow };

const itemsOf = (day: RegisterDay): Item[] =>
  day.sheets.flatMap<Item>((sheet) => [
    ...(day.sheets.length > 1
      ? [{ key: `h-${sheet.sessionId}`, kind: 'sheet' as const, title: `Period ${sheet.period}${sheet.subjectName ? ` · ${sheet.subjectName}` : ''}` }]
      : []),
    ...sheet.rows.map((row) => ({ key: row.recordId, kind: 'row' as const, row })),
  ]);

export interface CorrectionSheetProps {
  batchId: ID;
  date: ISODate | null;
  onClose: () => void;
  onTakeAttendance: (date: ISODate) => void;
}

/** Bottom sheet for a past day. Mounted only while open, so every opening starts from a clean draft. */
export function CorrectionSheet({ batchId, date, onClose, onTakeAttendance }: CorrectionSheetProps) {
  if (!date) return null;
  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <Pressable accessibilityLabel="Close" onPress={onClose} style={{ flex: 1, backgroundColor: C.scrim }} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <SheetBody batchId={batchId} date={date} onClose={onClose} onTakeAttendance={onTakeAttendance} />
      </KeyboardAvoidingView>
    </Modal>
  );
}

function SheetBody({ batchId, date, onClose, onTakeAttendance }: Required<CorrectionSheetProps> & { date: ISODate }) {
  const { height } = useWindowDimensions();
  const dayQuery = useRegisterDay(batchId, date);
  const day = dayQuery.data?.date === date ? dayQuery.data : undefined;
  const draft = useCorrectionDraft(day);
  const { save, saving } = useCorrectAttendance();
  const editable = Boolean(day?.access.canCorrect) && !saving;
  const note = draft.reason.trim();
  const ready = editable && draft.changes.length > 0 && note.length >= REASON_MIN;
  const items = useMemo(() => (day ? itemsOf(day) : []), [day]);

  const submit = useCallback(async () => {
    const result = await save({ batchId, date, reason: draft.reason, changes: draft.changes });
    if (result.ok) onClose();
  }, [save, batchId, date, draft.reason, draft.changes, onClose]);

  const footer = day ? (
    <View style={{ gap: 12, paddingTop: 16 }}>
      <Input
        label="Note"
        value={draft.reason}
        onChangeText={draft.setReason}
        placeholder="What changed? e.g. Joined after roll call"
        hint="A note about what changed, not who is to blame. It is kept with the correction."
        maxLength={REASON_MAX}
        multiline
        editable={editable}
        returnKeyType="done"
        blurOnSubmit
      />
      {editable ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {NOTE_IDEAS.map((idea) => (
            <Pressable
              key={idea}
              accessibilityRole="button"
              onPress={() => draft.setReason(idea)}
              style={({ pressed }) => ({
                paddingHorizontal: 12,
                height: 32,
                borderRadius: R.chip,
                justifyContent: 'center',
                backgroundColor: pressed || note === idea ? C.navySoft : C.canvas,
                borderWidth: 1,
                borderColor: C.hairline,
              })}
            >
              <Text c={C.primary} weight={600} style={{ fontSize: 12 }}>
                {idea}
              </Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      <CorrectionHistory entries={day.corrections} />
    </View>
  ) : null;

  return (
    <View style={{ height: Math.round(height * 0.88), backgroundColor: C.surface, borderTopLeftRadius: R.sheet, borderTopRightRadius: R.sheet, overflow: 'hidden' }}>
      <View style={{ alignItems: 'center', paddingTop: 10 }}>
        <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: C.hairline }} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: LAYOUT.margin, paddingTop: 10, paddingBottom: 8, gap: 12 }}>
        <View style={{ flex: 1 }}>
          <Text variant="h2" accessibilityRole="header">
            {dayLabel(date)}
          </Text>
          <Text c={C.secondary} style={{ fontSize: 13 }}>
            {day?.batchName ?? 'Attendance'} · P present · L late · A absent
          </Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Close"
          onPress={onClose}
          hitSlop={8}
          style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}
        >
          <Ionicons name="close" size={20} color={C.ink} />
        </Pressable>
      </View>

      {dayQuery.error && !day ? (
        <ErrorState title="Could not open this day" message={dayQuery.error.message} onRetry={() => void dayQuery.refetch()} />
      ) : !day ? (
        <View style={{ paddingHorizontal: LAYOUT.margin, gap: 10, paddingTop: 8 }}>
          {Array.from({ length: 6 }, (_, i) => (
            <Skeleton key={i} h={48} r={12} />
          ))}
        </View>
      ) : day.sheets.length === 0 ? (
        <EmptyState
          icon="calendar-clear-outline"
          title="No roll call saved for this day"
          text="There is nothing to correct yet. You can take attendance for this date instead."
          actionLabel="Take attendance for this day"
          onAction={() => {
            onClose();
            onTakeAttendance(date);
          }}
        />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.key}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 12 }}
          ListHeaderComponent={
            day.access.message ? (
              <View style={{ flexDirection: 'row', gap: 10, padding: 12, borderRadius: 14, backgroundColor: C.warningSoft, marginBottom: 8 }}>
                <Ionicons name="lock-closed-outline" size={16} color={C.duesInk} />
                <Text c={C.duesInk} weight={600} style={{ flex: 1, fontSize: 13 }}>
                  {day.access.message} You can read this day but not change it.
                </Text>
              </View>
            ) : null
          }
          renderItem={({ item }) =>
            item.kind === 'sheet' ? (
              <Text variant="label" c={C.muted} style={{ paddingTop: 14, paddingBottom: 4, letterSpacing: 0.6 }}>
                {item.title.toUpperCase()}
              </Text>
            ) : (
              <CorrectionRow
                row={item.row}
                picked={draft.edits[item.row.recordId] !== item.row.status ? draft.edits[item.row.recordId] : undefined}
                editable={editable}
                onPick={(status) => draft.setStatus(item.row.recordId, item.row.status, status)}
              />
            )
          }
          ListFooterComponent={footer}
        />
      )}

      {day && day.sheets.length > 0 ? (
        <SafeAreaView edges={['bottom']} style={{ borderTopWidth: 1, borderTopColor: C.hairline, backgroundColor: C.surface }}>
          <View style={{ padding: LAYOUT.margin, paddingTop: 12 }}>
            <Button
              title={draft.changes.length > 0 ? `Save correction · ${draft.changes.length} ${draft.changes.length === 1 ? 'change' : 'changes'}` : 'Save correction'}
              icon="checkmark"
              loading={saving}
              disabled={!ready}
              onPress={() => void submit()}
            />
          </View>
        </SafeAreaView>
      ) : null}
    </View>
  );
}
