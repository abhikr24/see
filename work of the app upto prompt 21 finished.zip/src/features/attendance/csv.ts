import type { AttendanceStatus, MonthRegister } from '@/core/contracts/models';
import { monthLabel } from './register-model';

/**
 * The monthly sheet as CSV that opens cleanly in Excel and Google Sheets:
 * UTF-8 with a byte-order mark (so Excel reads names correctly), CRLF line
 * endings, every field quoted when it needs to be, percentages as plain
 * numbers, and text that could be read as a formula neutralised.
 *
 * Layout: Roll, Student, one column per day a roll call was saved, then the
 * student's own counts and percentage. A last row counts everyone who attended
 * each day. A `*` after a letter marks a status that was corrected later.
 * Every number is copied from the register; nothing is recomputed here.
 */

export const CSV_MIME = 'text/csv';
const BOM = '\uFEFF';
const EOL = '\r\n';
const LETTER: Record<AttendanceStatus, string> = { present: 'P', late: 'L', absent: 'A', leave: 'LV' };
const FORMULA_START = /^[=+\-@\t\r]/;

export function csvField(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return '';
  let text = String(value);
  if (typeof value === 'string' && FORMULA_START.test(text)) text = `'${text}`;
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function registerCsv(register: MonthRegister): string {
  const days = register.days.filter((d) => d.state === 'marked');
  const header = ['Roll', 'Student', ...days.map((d) => d.date), 'Present', 'Late', 'Absent', 'Leave', 'Attendance %'];
  const rows: (string | number | null)[][] = register.students.map((student) => [
    student.rollNumber,
    student.fullName,
    ...days.map((d) => {
      const cell = student.cells[d.date];
      return cell ? `${LETTER[cell.status]}${cell.corrected ? '*' : ''}` : '';
    }),
    student.present,
    student.late,
    student.absent,
    student.leave,
    student.percent,
  ]);
  const s = register.summary;
  rows.push([
    null,
    'Attended (present + late)',
    ...days.map((d) => d.present + d.late),
    s.present,
    s.late,
    s.absent,
    s.leave,
    s.attendedPercent,
  ]);
  const lines = [header, ...rows].map((row) => row.map(csvField).join(','));
  lines.push('', csvField(`${register.batchName} · ${monthLabel(register.month)} · * = corrected after it was first marked`));
  return BOM + lines.join(EOL) + EOL;
}

export function csvFilename(register: MonthRegister): string {
  const slug = register.batchName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return `attendance-${slug || 'batch'}-${register.month}.csv`;
}
