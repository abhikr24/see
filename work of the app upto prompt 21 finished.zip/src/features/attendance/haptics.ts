import { Platform } from 'react-native';
import * as Haptics from 'expo-haptics';

/** Light tick on every tile tap. Silent where the platform has no haptics engine. */
export function tapHaptic(): void {
  if (Platform.OS === 'web') return;
  void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined);
}

export function successHaptic(): void {
  if (Platform.OS === 'web') return;
  void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
}
