import { useCallback, useMemo, useState } from 'react';

import type { AttendanceCorrectionEntry, AttendanceStatus, ID, ISODate, MonthRegister, RegisterDay } from '@/core/contracts/models';
import { queryCache, queryKey } from '@/core/hooks/cache';
import { useBackend } from '@/core/hooks/context';
import { useDomainMutation } from '@/core/hooks/domain';
import { monthRegisterArgs, registerDayArgs } from '@/core/hooks/register';
import { ATTENDANCE_DOMAINS } from '../commit';

export type Edits = Record<ID, AttendanceStatus>;

export interface CorrectionVars {
  batchId: ID;
  date: ISODate;
  reason: string;
  changes: { recordId: ID; status: AttendanceStatus }[];
}

/**
 * The correction write. Optimistic: the day shows its pencil and the new
 * statuses at once; the repo then answers and every attendance cache reloads
 * (register, student percentage, dashboard). A failure rolls the lot back.
 */
export function useCorrectAttendance() {
  const { backend, instituteId } = useBackend();
  const mutation = useDomainMutation<CorrectionVars, AttendanceCorrectionEntry[]>(
    [...ATTENDANCE_DOMAINS],
    (b, i, vars) => b.attendance.correctAttendance(i, vars),
    {
      success: (rows) => `Correction saved · ${rows.length} ${rows.length === 1 ? 'change' : 'changes'} recorded`,
      failure: 'Could not save the correction',
    },
    ({ batchId, date, changes }) => {
      const wanted = new Map(changes.map((c) => [c.recordId, c.status]));
      queryCache.update<MonthRegister>(
        queryKey(backend.name, 'attendance', instituteId, monthRegisterArgs(batchId, date.slice(0, 7))),
        (register) => ({ ...register, days: register.days.map((d) => (d.date === date ? { ...d, corrected: true } : d)) }),
      );
      queryCache.update<RegisterDay>(
        queryKey(backend.name, 'attendance', instituteId, registerDayArgs(batchId, date)),
        (day) => ({
          ...day,
          sheets: day.sheets.map((sheet) => ({
            ...sheet,
            rows: sheet.rows.map((row) => {
              const status = wanted.get(row.recordId);
              if (!status || status === row.status) return row;
              return { ...row, status, corrected: true, originalStatus: row.originalStatus ?? row.status };
            }),
          })),
        }),
      );
    },
  );
  return { save: mutation.mutate, saving: mutation.loading };
}

/** Local edits for the correction sheet: what the person has changed so far, plus their note. */
export function useCorrectionDraft(day: RegisterDay | undefined) {
  const [edits, setEdits] = useState<Edits>({});
  const [reason, setReason] = useState('');

  const changes = useMemo(() => {
    const rows = day?.sheets.flatMap((s) => s.rows) ?? [];
    return rows.flatMap((row) => (edits[row.recordId] && edits[row.recordId] !== row.status ? [{ recordId: row.recordId, status: edits[row.recordId] }] : []));
  }, [day, edits]);

  const setStatus = useCallback((recordId: ID, current: AttendanceStatus, status: AttendanceStatus) => {
    setEdits((prev) => {
      const next = { ...prev };
      if (status === current) delete next[recordId];
      else next[recordId] = status;
      return next;
    });
  }, []);

  return { edits, reason, setReason, setStatus, changes };
}
