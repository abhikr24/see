import { useEffect, useState } from 'react';
import NetInfo, { type NetInfoState } from '@react-native-community/netinfo';

const isOnline = (state: NetInfoState): boolean =>
  state.isConnected !== false && state.isInternetReachable !== false;

/** true while the device has a connection. Optimistic (true) until the first reading. */
export function useOnline(): boolean {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    void NetInfo.fetch().then((state) => setOnline(isOnline(state)));
    return NetInfo.addEventListener((state) => setOnline(isOnline(state)));
  }, []);
  return online;
}

/** One-off reading at the moment of saving. */
export async function checkOnline(): Promise<boolean> {
  try {
    return isOnline(await NetInfo.fetch());
  } catch {
    return true;
  }
}
