import { useEffect, useSyncExternalStore } from 'react';

import { attendanceOutbox, type OutboxItem } from '../outbox';

interface OutboxView {
  items: readonly OutboxItem[];
  lastSyncedAt: string | null;
}

let cached: OutboxView = { items: attendanceOutbox.list(), lastSyncedAt: attendanceOutbox.lastSyncedAt() };

function read(): OutboxView {
  const items = attendanceOutbox.list();
  const lastSyncedAt = attendanceOutbox.lastSyncedAt();
  if (items !== cached.items || lastSyncedAt !== cached.lastSyncedAt) cached = { items, lastSyncedAt };
  return cached;
}

const subscribe = (listener: () => void) => attendanceOutbox.subscribe(listener);

/** The offline queue and the last successful sync, live. */
export function useOutbox(): OutboxView {
  useEffect(() => {
    void attendanceOutbox.load();
  }, []);
  return useSyncExternalStore(subscribe, read, read);
}
