import { useCallback, useMemo, useState } from 'react';

import type { BatchSummary, ID, ISODate, RegisterCell } from '@/core/contracts/models';
import { useDomainQuery } from '@/core/hooks/domain';
import { useMonthRegister } from '@/core/hooks/register';
import { toast } from '@/core/hooks/toast';
import { toBackendError } from '@/core/contracts/errors';
import { registerCsv, csvFilename } from '../csv';
import { deliverCsv } from '../export';
import { todayIso } from '../model';
import { currentMonth, shiftMonth } from '../register-model';

export interface RegisterParams {
  batchId?: ID;
  month?: string;
}

const MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;

/**
 * State for the register screen: which batch and month, the repo's month
 * register, which day's correction sheet is open, and the CSV download.
 * It chooses and navigates; every number comes from the repo.
 */
export function useRegister(params: RegisterParams) {
  const today = todayIso();
  const now = currentMonth(today);
  const batches = useDomainQuery<BatchSummary[]>('batches', ['summaries'], (b, i) => b.batches.listSummaries(i));
  const active = useMemo(() => (batches.data ?? []).filter((b) => b.status === 'active' || b.status === 'upcoming'), [batches.data]);

  const [picked, setPicked] = useState<ID | null>(params.batchId ?? null);
  const batchId = picked ?? active[0]?.id ?? null;
  const [month, setMonth] = useState(params.month && MONTH.test(params.month) && params.month <= now ? params.month : now);
  const register = useMonthRegister(batchId, month);
  const data = register.data && register.data.batchId === batchId && register.data.month === month ? register.data : null;

  const [openDate, setOpenDate] = useState<ISODate | null>(null);
  const [exporting, setExporting] = useState(false);

  const open = useCallback((cell: RegisterCell) => {
    if (cell.state !== 'future') setOpenDate(cell.date);
  }, []);

  const download = useCallback(async () => {
    if (!data || exporting) return;
    setExporting(true);
    try {
      const name = csvFilename(data);
      const outcome = await deliverCsv(name, registerCsv(data));
      toast.success(outcome === 'downloaded' ? `Downloaded ${name}` : outcome === 'saved' ? `Saved ${name}` : 'Sheet ready to share');
    } catch (cause) {
      toast.error(`Could not create the sheet. ${toBackendError(cause).message}`);
    } finally {
      setExporting(false);
    }
  }, [data, exporting]);

  return {
    today,
    batches: active,
    batchesLoading: batches.loading && !batches.data,
    batchesError: batches.error && !batches.data ? batches.error : null,
    batchId,
    selectBatch: setPicked,
    month,
    canGoNext: month < now,
    previousMonth: () => setMonth((m) => shiftMonth(m, -1)),
    nextMonth: () => setMonth((m) => (m < now ? shiftMonth(m, 1) : m)),
    register: data,
    loading: register.loading && !data,
    refreshing: register.loading && Boolean(data),
    error: register.error && !data ? register.error : null,
    refetch: () => Promise.all([register.refetch(), batches.refetch()]).then(() => undefined),
    openDate,
    openDay: open,
    closeDay: () => setOpenDate(null),
    download,
    exporting,
  };
}
