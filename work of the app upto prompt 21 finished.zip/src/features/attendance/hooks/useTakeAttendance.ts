import { useCallback, useMemo, useReducer } from 'react';

import type { AttendanceRoll, AttendanceSheet, AttendanceStatus, ID, ISODate } from '@/core/contracts/models';
import { useAttendanceRoll, daySheetsArgs } from '@/core/hooks/academics';
import { queryCache, queryKey } from '@/core/hooks/cache';
import { useBackend } from '@/core/hooks/context';
import { runMutation } from '@/core/hooks/mutation';
import { toast } from '@/core/hooks/toast';
import { attendanceScopes, commitSheet, savedMessage, type CommitResult } from '../commit';
import { successHaptic, tapHaptic } from '../haptics';
import {
  NEXT,
  changedCount,
  countMarks,
  expectedSheet,
  markAll,
  markAllAfter,
  marksFrom,
  rollKey,
  sheetInput,
  upsertDaySheet,
  type Marks,
} from '../model';
import { attendanceOutbox } from '../outbox';
import { checkOnline } from './useOnline';
import { useOutbox } from './useOutbox';

export type SavePhase = 'idle' | 'saving' | 'saved' | 'queued' | 'failed';

export interface TakeParams {
  batchId: ID;
  date: ISODate;
  period: number;
  subjectId: ID | null;
}

const TRANSIENT = new Set(['NETWORK', 'TIMEOUT', 'UNAVAILABLE']);

interface SheetState {
  marks: Marks;
  /** Last saved (or optimistically saved) marks; null for a sheet never saved. */
  baseline: Marks | null;
  touched: boolean;
  phase: SavePhase;
  failure: string | null;
}

type Action =
  | { type: 'edit'; change: (current: Marks) => Marks }
  | { type: 'optimistic'; baseline: Marks }
  | { type: 'phase'; phase: SavePhase }
  | { type: 'saved' }
  | { type: 'failed'; baseline: Marks | null; message: string }
  | { type: 'dismiss' };

const INITIAL: SheetState = { marks: {}, baseline: null, touched: false, phase: 'idle', failure: null };

function reduce(state: SheetState, action: Action): SheetState {
  switch (action.type) {
    case 'edit':
      return { ...state, marks: action.change(state.marks), touched: true };
    case 'optimistic':
      return { ...state, baseline: action.baseline, failure: null };
    case 'phase':
      return { ...state, phase: action.phase };
    case 'saved':
      return { ...state, phase: 'saved', touched: false };
    case 'failed':
      return { ...state, baseline: action.baseline, phase: 'failed', failure: action.message };
    case 'dismiss':
      return { ...state, failure: null };
  }
}

/**
 * Take Attendance state: one roll read, local marks, and the save path —
 * optimistic → one batched upsert → parent alerts, or roll back and offer retry,
 * or (offline) queue in AsyncStorage for the root flusher.
 */
export function useRollQuery(params: TakeParams) {
  const { instituteId } = useBackend();
  const input = useMemo(
    () => ({ batchId: params.batchId, date: params.date, period: params.period, subjectId: params.subjectId }),
    [params.batchId, params.date, params.period, params.subjectId],
  );
  const roll = useAttendanceRoll(input);
  const key = instituteId ? rollKey(instituteId, params.batchId, params.date, params.period) : '';
  return { roll, key };
}

/** Seeds local marks: a queued, unsynced version wins over the saved one. */
function initialState(roll: AttendanceRoll, key: string): SheetState {
  const pending = attendanceOutbox.get(key);
  if (pending) {
    const fromQueue: Marks = {};
    pending.input.records.forEach((r) => (fromQueue[r.studentId] = r.status));
    const merged = { ...marksFrom(roll.students, null), ...fromQueue };
    return { ...INITIAL, marks: merged, baseline: merged, phase: 'queued' };
  }
  const saved = roll.existing ? marksFrom(roll.students, roll.existing) : null;
  return { ...INITIAL, marks: saved ?? marksFrom(roll.students, null), baseline: saved };
}

/**
 * Mount once per sheet (`key={rollKey}`): marks are seeded from the roll at
 * mount and a background refetch never resets them.
 */
export function useTakeAttendance(roll: AttendanceRoll, key: string) {
  const { backend, instituteId } = useBackend();
  const outbox = useOutbox();
  const queued = outbox.items.find((item) => item.key === key) ?? null;
  const [state, dispatch] = useReducer(reduce, undefined, () => initialState(roll, key));
  const { marks, baseline, touched, phase, failure } = state;

  const students = roll.students;
  const counts = useMemo(() => countMarks(students, marks), [students, marks]);
  const editing = baseline !== null;
  const dirty = baseline ? changedCount(marks, baseline) > 0 : touched;

  const cycle = useCallback((studentId: ID) => {
    tapHaptic();
    dispatch({ type: 'edit', change: (current) => ({ ...current, [studentId]: NEXT[current[studentId] ?? 'present'] }) });
  }, []);

  const markAllPresent = useCallback(() => {
    tapHaptic();
    dispatch({ type: 'edit', change: () => markAll(students, 'present') });
  }, [students]);

  const applyAfter = useCallback(
    (studentId: ID, status: AttendanceStatus) => {
      tapHaptic();
      dispatch({ type: 'edit', change: (current) => markAllAfter(students, current, studentId, status).marks });
    },
    [students],
  );

  const daySheetsKey = queryKey(backend.name, 'attendance', instituteId, daySheetsArgs(roll.date));
  const showEverywhere = useCallback(
    (sheet: AttendanceSheet) => queryCache.update<AttendanceSheet[]>(daySheetsKey, (list) => upsertDaySheet(list, sheet)),
    [daySheetsKey],
  );

  const save = useCallback(async () => {
    const data = roll;
    if (!instituteId || phase === 'saving') return;
    const snapshotMarks = { ...marks };
    const previousBaseline = baseline;
    const payload = sheetInput(data, snapshotMarks);
    const wasEditing = editing;
    const queue = () => {
      attendanceOutbox.enqueue({
        key,
        backendName: backend.name,
        instituteId,
        input: payload,
        queuedAt: new Date().toISOString(),
      });
      showEverywhere(expectedSheet(data, snapshotMarks, instituteId));
      dispatch({ type: 'phase', phase: 'queued' });
      toast.info('Saved on this phone. It will sync when you are back online');
    };

    // Optimistic: the sheet reads as saved straight away.
    dispatch({ type: 'optimistic', baseline: snapshotMarks });
    if (!(await checkOnline())) {
      queue();
      return;
    }
    dispatch({ type: 'phase', phase: 'saving' });
    const result = await runMutation<void, CommitResult>(
      {
        scopes: attendanceScopes(backend.name, instituteId),
        optimistic: () => showEverywhere(expectedSheet(data, snapshotMarks, instituteId)),
        run: () => commitSheet(backend, instituteId, payload),
        success: (res) => savedMessage(res, wasEditing),
        failure: wasEditing ? 'Could not update attendance' : 'Could not save attendance',
      },
      undefined,
    );
    if (result.ok) {
      attendanceOutbox.remove(key);
      attendanceOutbox.markSynced();
      successHaptic();
      dispatch({ type: 'saved' });
      return;
    }
    if (TRANSIENT.has(result.error.code)) {
      queue();
      return;
    }
    // Roll back the "saved" look; keep every mark on screen for the retry.
    dispatch({ type: 'failed', baseline: previousBaseline, message: result.error.message });
  }, [roll, instituteId, phase, marks, baseline, editing, key, backend, showEverywhere]);

  return {
    marks,
    counts,
    editing,
    dirty,
    // A queued sheet that the root flusher has synced reads as saved.
    phase: phase === 'queued' && !queued ? ('saved' as const) : phase,
    failure,
    queued,
    lastSyncedAt: outbox.lastSyncedAt,
    cycle,
    markAllPresent,
    applyAfter,
    save,
    dismissFailure: () => dispatch({ type: 'dismiss' }),
  };
}
