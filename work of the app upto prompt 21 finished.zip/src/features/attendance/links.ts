import type { ID, ISODate } from '@/core/contracts/models';

export interface TakeAttendanceTarget {
  batchId: ID;
  date: ISODate;
  period?: number;
  subjectId?: ID | null;
}

/** The Take Attendance route with its batch, date, period and subject prefilled. */
export function takeAttendanceHref({ batchId, date, period = 1, subjectId }: TakeAttendanceTarget) {
  const params: Record<string, string> = { batchId, date, period: String(period) };
  if (subjectId) params.subjectId = subjectId;
  return { pathname: '/(owner)/attendance/[batchId]', params } as const;
}

/** The monthly register for a batch, optionally opened on a month (`YYYY-MM`). */
export function registerHref(batchId: ID, month?: string) {
  const params: Record<string, string> = { batchId };
  if (month) params.month = month;
  return { pathname: '/(owner)/attendance/register', params } as const;
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/** The raw query a Take Attendance route receives. Every role's route parses it with `takeParamsFromRoute`. */
export type TakeRouteParams = {
  batchId?: string;
  date?: string;
  period?: string;
  subjectId?: string;
};

/**
 * Route params → the screen's params. A missing, malformed or future date
 * becomes today (attendance is never marked ahead); the period is at least 1.
 */
export function takeParamsFromRoute(params: TakeRouteParams, today: ISODate) {
  const date = params.date && ISO_DATE.test(params.date) && params.date <= today ? params.date : today;
  const period = Math.max(1, Number.parseInt(params.period ?? '1', 10) || 1);
  return { batchId: String(params.batchId), date, period, subjectId: params.subjectId ? String(params.subjectId) : null };
}

/** Where the Take Attendance screen sends the person. Each role's route passes its own. */
export interface TakeNav {
  /** Where "back" lands when there is no history to go back to. */
  home: string;
  /** Opens the monthly register. null hides the register button. */
  register: ((batchId: ID, month?: string) => unknown) | null;
  /** The empty roster's "Add a student" destination. null hides the action. */
  addStudent: string | null;
}

export const OWNER_TAKE_NAV: TakeNav = { home: '/(owner)', register: registerHref, addStudent: '/(owner)/students/new' };
