import type {
  AttendanceRoll,
  AttendanceRollStudent,
  AttendanceSheet,
  AttendanceStatus,
  ID,
  ISODate,
} from '@/core/contracts/models';
import type { AttendanceSheetInput } from '@/core/contracts/ports';

/**
 * Pure roll-call logic. No React, no backend — the screen and the tests share it.
 */

export type Marks = Record<ID, AttendanceStatus>;

/** One tap: present → absent → late → present. Leave (set elsewhere) re-enters at present. */
export const NEXT: Record<AttendanceStatus, AttendanceStatus> = {
  present: 'absent',
  absent: 'late',
  late: 'present',
  leave: 'present',
};

export interface Counts {
  present: number;
  late: number;
  absent: number;
  total: number;
}

export const todayIso = (): ISODate => new Date().toISOString().slice(0, 10);

export function addDaysIso(date: ISODate, days: number): ISODate {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** The most recent date (today or earlier) that falls on `dayOfWeek` — attendance is never marked ahead. */
export function latestDateForWeekday(dayOfWeek: number, today: ISODate = todayIso()): ISODate {
  const current = new Date(`${today}T00:00:00Z`).getUTCDay();
  return addDaysIso(today, -((current - dayOfWeek + 7) % 7));
}

const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "Today", "Yesterday" or "Mon, 9 Nov". */
export function dateChipLabel(date: ISODate, today: ISODate = todayIso()): string {
  if (date === today) return 'Today';
  if (date === addDaysIso(today, -1)) return 'Yesterday';
  const d = new Date(`${date}T00:00:00Z`);
  return `${DOW[d.getUTCDay()]}, ${d.getUTCDate()} ${MON[d.getUTCMonth()]}`;
}

/** "just now", "4 min ago", "2 h ago", "3 days ago". */
export function agoLabel(iso: string | null, now: number = Date.now()): string {
  if (!iso) return 'never';
  const minutes = Math.max(0, Math.floor((now - new Date(iso).getTime()) / 60000));
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

/** Saved statuses for a sheet; everyone without a record starts present. */
export function marksFrom(students: readonly AttendanceRollStudent[], sheet: AttendanceSheet | null): Marks {
  const saved = new Map(sheet?.records.map((r) => [r.studentId, r.status]) ?? []);
  const marks: Marks = {};
  for (const s of students) marks[s.studentId] = saved.get(s.studentId) ?? 'present';
  return marks;
}

export function countMarks(students: readonly AttendanceRollStudent[], marks: Marks): Counts {
  const counts: Counts = { present: 0, late: 0, absent: 0, total: students.length };
  for (const s of students) {
    const status = marks[s.studentId] ?? 'present';
    if (status === 'present') counts.present += 1;
    else if (status === 'late') counts.late += 1;
    else counts.absent += 1;
  }
  return counts;
}

/** How many students differ from the saved baseline. */
export function changedCount(marks: Marks, baseline: Marks): number {
  return Object.keys(marks).filter((id) => marks[id] !== baseline[id]).length;
}

export function markAll(students: readonly AttendanceRollStudent[], status: AttendanceStatus): Marks {
  const marks: Marks = {};
  for (const s of students) marks[s.studentId] = status;
  return marks;
}

/** Applies `status` to every student after `fromId` in roll order. Returns how many changed. */
export function markAllAfter(
  students: readonly AttendanceRollStudent[],
  marks: Marks,
  fromId: ID,
  status: AttendanceStatus,
): { marks: Marks; changed: number } {
  const start = students.findIndex((s) => s.studentId === fromId);
  if (start < 0) return { marks, changed: 0 };
  const next = { ...marks };
  let changed = 0;
  for (const s of students.slice(start + 1)) {
    if (next[s.studentId] !== status) changed += 1;
    next[s.studentId] = status;
  }
  return { marks: next, changed };
}

export function sheetInput(roll: AttendanceRoll, marks: Marks): AttendanceSheetInput {
  return {
    batchId: roll.batchId,
    date: roll.date,
    period: roll.period,
    subjectId: roll.subjectId,
    records: roll.students.map((s) => ({ studentId: s.studentId, status: marks[s.studentId] ?? 'present' })),
  };
}

/** The sheet a save is expected to produce — shown in other screens before the server answers. */
export function expectedSheet(
  roll: AttendanceRoll,
  marks: Marks,
  instituteId: ID,
  markedBy: ID | null = null,
): AttendanceSheet {
  const at = new Date().toISOString();
  const sessionId = roll.existing?.session.id ?? `temp-sheet-${roll.batchId}-${roll.date}-${roll.period}`;
  return {
    session: {
      id: sessionId,
      instituteId,
      createdAt: roll.existing?.session.createdAt ?? at,
      updatedAt: at,
      batchId: roll.batchId,
      subjectId: roll.subjectId,
      teacherId: roll.existing?.session.teacherId ?? null,
      date: roll.date,
      period: roll.period,
      status: 'submitted',
      markedBy,
      markedAt: at,
      notes: roll.existing?.session.notes ?? null,
    },
    records: roll.students.map((s, i) => ({
      id: `${sessionId}-r${i}`,
      instituteId,
      createdAt: at,
      updatedAt: at,
      sessionId,
      batchId: roll.batchId,
      studentId: s.studentId,
      status: marks[s.studentId] ?? 'present',
      remark: null,
      markedBy,
    })),
  };
}

/** Replaces (or adds) the sheet for the same batch + period in a day's list. */
export function upsertDaySheet(list: readonly AttendanceSheet[], sheet: AttendanceSheet): AttendanceSheet[] {
  const rest = list.filter(
    (s) => !(s.session.batchId === sheet.session.batchId && s.session.period === sheet.session.period),
  );
  return [...rest, sheet];
}

/** Stable key of one roll call, used by the offline queue. */
export const rollKey = (instituteId: ID, batchId: ID, date: ISODate, period: number): string =>
  `${instituteId}|${batchId}|${date}|${period}`;
