import AsyncStorage from '@react-native-async-storage/async-storage';

import type { ID } from '@/core/contracts/models';
import type { AttendanceSheetInput } from '@/core/contracts/ports';

/**
 * The offline queue for roll calls. One entry per (institute, batch, date, period):
 * a newer save of the same sheet replaces the older one. Persisted in AsyncStorage
 * so a queued sheet survives an app kill; mirrored in memory so screens update instantly.
 */

export interface OutboxItem {
  key: string;
  backendName: string;
  instituteId: ID;
  input: AttendanceSheetInput;
  queuedAt: string;
}

const QUEUE_KEY = 'gf.attendance.outbox.v1';
const SYNC_KEY = 'gf.attendance.lastSync.v1';

type Listener = () => void;

class AttendanceOutbox {
  private items: OutboxItem[] = [];
  private lastSync: string | null = null;
  private loaded: Promise<void> | null = null;
  private readonly listeners = new Set<Listener>();

  load(): Promise<void> {
    if (!this.loaded) {
      this.loaded = Promise.all([AsyncStorage.getItem(QUEUE_KEY), AsyncStorage.getItem(SYNC_KEY)])
        .then(([queue, sync]) => {
          const parsed: unknown = queue ? JSON.parse(queue) : [];
          // Merge with anything queued before the read finished.
          const stored = Array.isArray(parsed) ? (parsed as OutboxItem[]) : [];
          const keys = new Set(this.items.map((item) => item.key));
          this.items = [...stored.filter((item) => !keys.has(item.key)), ...this.items];
          this.lastSync = this.lastSync ?? sync;
          this.emit();
        })
        .catch(() => undefined);
    }
    return this.loaded;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(): void {
    this.listeners.forEach((listener) => listener());
  }

  private persist(): void {
    void AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(this.items)).catch(() => undefined);
  }

  list(): readonly OutboxItem[] {
    return this.items;
  }

  get(key: string): OutboxItem | undefined {
    return this.items.find((item) => item.key === key);
  }

  lastSyncedAt(): string | null {
    return this.lastSync;
  }

  enqueue(item: OutboxItem): void {
    this.items = [...this.items.filter((row) => row.key !== item.key), item];
    this.persist();
    this.emit();
  }

  /** Drops an entry, but only if it is still the version that was flushed. */
  remove(key: string, queuedAt?: string): void {
    const before = this.items.length;
    this.items = this.items.filter((row) => !(row.key === key && (!queuedAt || row.queuedAt === queuedAt)));
    if (this.items.length !== before) {
      this.persist();
      this.emit();
    }
  }

  markSynced(at: string = new Date().toISOString()): void {
    this.lastSync = at;
    void AsyncStorage.setItem(SYNC_KEY, at).catch(() => undefined);
    this.emit();
  }
}

export const attendanceOutbox = new AttendanceOutbox();
