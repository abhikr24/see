import type { ISODate, RegisterCell } from '@/core/contracts/models';
import { MONTH_NAMES } from './months';

/** Pure helpers for the register screen: month navigation and wording. No data is computed here. */

export const currentMonth = (today: ISODate): string => today.slice(0, 7);

export function shiftMonth(month: string, by: number): string {
  const [year, index] = month.split('-').map(Number);
  const d = new Date(Date.UTC(year, index - 1 + by, 1));
  return d.toISOString().slice(0, 7);
}

/** "November 2026". */
export function monthLabel(month: string): string {
  const [year, index] = month.split('-').map(Number);
  return `${MONTH_NAMES[index - 1]} ${year}`;
}

/** "Fri, 13 Nov". */
export function dayLabel(date: ISODate): string {
  const d = new Date(`${date}T00:00:00Z`);
  const dow = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getUTCDay()];
  return `${dow}, ${d.getUTCDate()} ${MONTH_NAMES[d.getUTCMonth()].slice(0, 3)}`;
}

export const WEEKDAY_INITIALS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'] as const;

export const STATUS_WORD = { present: 'Present', late: 'Late', absent: 'Absent', leave: 'On leave' } as const;

/** A spoken description of one square, e.g. "13 Nov: 11 present, 1 absent. Corrected." */
export function cellLabel(cell: RegisterCell): string {
  const when = dayLabel(cell.date);
  if (cell.state === 'future') return `${when}: upcoming`;
  if (cell.state === 'unmarked') return `${when}: no roll call saved`;
  const parts = [`${cell.present} present`, `${cell.late} late`, `${cell.absent} absent`];
  return `${when}: ${parts.join(', ')}.${cell.corrected ? ' Corrected.' : ''}`;
}

