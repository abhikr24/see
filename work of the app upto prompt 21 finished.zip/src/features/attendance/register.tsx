import React from 'react';
import { Pressable, RefreshControl, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button, Chip, EmptyState, ErrorState, Skeleton, Text } from '@/components/ui';
import type { ISODate, RegisterCell } from '@/core/contracts/models';
import { C, LAYOUT, R } from '@/lib/theme';
import { CorrectionSheet } from './correct';
import { MonthBar } from './components/MonthBar';
import { RegisterHeatmap } from './components/RegisterHeatmap';
import { SummaryRows } from './components/SummaryRows';
import { useRegister, type RegisterParams } from './hooks/useRegister';
import { takeAttendanceHref } from './links';
import { monthLabel } from './register-model';

const MAX_CONTENT = 560;

/**
 * Attendance register — one batch, one month. A heatmap of the month, three
 * summary rows and the CSV download. Tapping a past day opens its correction
 * sheet; today opens Take attendance; days to come do nothing.
 */
export function AttendanceRegisterScreen(params: RegisterParams) {
  const reg = useRegister(params);
  const batch = reg.batches.find((b) => b.id === reg.batchId);
  const takeFor = (date: ISODate) => {
    if (reg.batchId) router.push(takeAttendanceHref({ batchId: reg.batchId, date }) as never);
  };
  const pressDay = (cell: RegisterCell) => {
    if (cell.isToday) takeFor(cell.date);
    else reg.openDay(cell);
  };
  const leave = () => (router.canGoBack() ? router.back() : router.replace('/(owner)/attendance' as never));

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_CONTENT, alignSelf: 'center' }}>
        <SafeAreaView edges={['top']}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: LAYOUT.margin - 8, paddingBottom: 6 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={leave}
              hitSlop={6}
              style={({ pressed }) => ({ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: pressed ? C.track : C.transparent })}
            >
              <Ionicons name="chevron-back" size={22} color={C.ink} />
            </Pressable>
            <View style={{ flex: 1 }}>
              <Text variant="h2" numberOfLines={1} accessibilityRole="header">
                {reg.register?.batchName ?? batch?.name ?? 'Register'}
              </Text>
              <Text variant="caption" c={C.secondary}>
                Attendance register
              </Text>
            </View>
          </View>
        </SafeAreaView>

        {reg.batchesError ? (
          <ErrorState title="Could not load batches" message={reg.batchesError.message} onRetry={() => void reg.refetch()} />
        ) : !reg.batchesLoading && reg.batches.length === 0 ? (
          <EmptyState
            icon="albums-outline"
            title="No batches yet"
            text="Create a batch and take attendance, then its register appears here."
            actionLabel="Create a batch"
            onAction={() => router.push('/(owner)/batches/new' as never)}
          />
        ) : (
          <ScrollView
            contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 48, gap: 16 }}
            refreshControl={<RefreshControl refreshing={reg.refreshing} onRefresh={() => void reg.refetch()} tintColor={C.primary} />}
          >
            {reg.batches.length > 1 ? (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                {reg.batches.map((b) => (
                  <Chip key={b.id} label={b.name} active={b.id === reg.batchId} onPress={() => reg.selectBatch(b.id)} />
                ))}
              </ScrollView>
            ) : null}

            <View style={{ backgroundColor: C.surface, borderRadius: R.card, borderWidth: 1, borderColor: C.hairline, padding: LAYOUT.cardPad, gap: 14 }}>
              <MonthBar month={reg.month} canGoNext={reg.canGoNext} onPrevious={reg.previousMonth} onNext={reg.nextMonth} />
              {reg.error ? (
                <ErrorState title="Could not load this month" message={reg.error.message} onRetry={() => void reg.refetch()} />
              ) : reg.register ? (
                <RegisterHeatmap register={reg.register} onDayPress={pressDay} />
              ) : (
                <View style={{ gap: 6 }}>
                  {Array.from({ length: 6 }, (_, i) => (
                    <Skeleton key={i} h={36} r={R.cell} />
                  ))}
                </View>
              )}
            </View>

            {reg.register && reg.register.summary.markedDays === 0 ? (
              <View style={{ backgroundColor: C.surface, borderRadius: R.card, borderWidth: 1, borderColor: C.hairline }}>
                <EmptyState
                  icon="calendar-outline"
                  title={`No attendance saved in ${monthLabel(reg.month)}`}
                  text="Days appear on the calendar as soon as a roll call is saved."
                  actionLabel="Take attendance"
                  onAction={() => takeFor(reg.today)}
                />
              </View>
            ) : reg.register ? (
              <>
                <View style={{ backgroundColor: C.surface, borderRadius: R.card, borderWidth: 1, borderColor: C.hairline, padding: LAYOUT.cardPad }}>
                  <SummaryRows summary={reg.register.summary} />
                </View>
                <Button
                  title="Download monthly sheet"
                  icon="download-outline"
                  loading={reg.exporting}
                  onPress={() => void reg.download()}
                />
                <Text variant="caption" c={C.muted} style={{ textAlign: 'center' }}>
                  CSV · opens in Excel and Google Sheets
                </Text>
              </>
            ) : null}
          </ScrollView>
        )}
      </View>

      {reg.batchId ? (
        <CorrectionSheet batchId={reg.batchId} date={reg.openDate} onClose={reg.closeDay} onTakeAttendance={takeFor} />
      ) : null}
    </View>
  );
}
