import React, { useCallback, useState } from 'react';
import { FlatList, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ConfirmDialog, EmptyState, ErrorState, Skeleton } from '@/components/ui';
import type { AttendanceRoll, AttendanceRollStudent, ID, ISODate } from '@/core/contracts/models';
import { C, LAYOUT } from '@/lib/theme';
import { DateSheet } from './components/DateSheet';
import { SaveFooter } from './components/SaveFooter';
import { StudentTile, TILE_GAP, TILE_HEIGHT } from './components/StudentTile';
import { SummaryStrip } from './components/SummaryStrip';
import { FailureBar, SyncBanner } from './components/SyncBanner';
import { TakeHeader } from './components/TakeHeader';
import { TileMenu } from './components/TileMenu';
import { useOnline } from './hooks/useOnline';
import { useRollQuery, useTakeAttendance, type TakeParams } from './hooks/useTakeAttendance';
import { OWNER_TAKE_NAV, type TakeNav } from './links';
import { agoLabel, dateChipLabel } from './model';

const COLUMNS = 3;
const MAX_CONTENT = 560;

/**
 * Take Attendance — shape D, no chrome. Header, summary strip, a 3-column grid
 * of 108pt tiles, sticky save. Tap cycles a tile; long-press opens its menu.
 * This shell loads the roll; `RollSheet` (mounted once per sheet) holds the marks.
 */
export function TakeAttendanceScreen({ nav = OWNER_TAKE_NAV, ...params }: TakeParams & { nav?: TakeNav }) {
  const { roll, key } = useRollQuery(params);
  const { width } = useWindowDimensions();
  const leave = () => exitTo(nav.home);
  const register = nav.register;
  const tileWidth = tileWidthFor(width);
  const data = roll.data && roll.data.date === params.date && roll.data.batchId === params.batchId ? roll.data : null;

  if (data && key) {
    return (
      <RollSheet
        key={key}
        rollKey={key}
        roll={data}
        tileWidth={tileWidth}
        nav={nav}
        refreshing={roll.loading}
        onRefresh={() => void roll.refetch()}
      />
    );
  }
  // A batch this person cannot see is the same as one that does not exist: no retry, just a way out.
  const missing = roll.error?.code === 'NOT_FOUND';
  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_CONTENT, alignSelf: 'center' }}>
        <SafeAreaView edges={['top']}>
          <TakeHeader
            title="Take attendance"
            dateLabel={dateChipLabel(params.date)}
            editing={false}
            onBack={leave}
            onDate={leave}
            onRegister={register && !missing ? () => router.push(register(params.batchId) as never) : undefined}
          />
        </SafeAreaView>
        {missing ? (
          <EmptyState
            icon="search-outline"
            title="Class not found"
            text="This class is not on your list, or it no longer exists."
            actionLabel="Go back"
            onAction={leave}
          />
        ) : roll.error ? (
          <ErrorState title="Could not open the register" message={roll.error.message} onRetry={() => void roll.refetch()} />
        ) : (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: TILE_GAP, padding: LAYOUT.margin }}>
            {Array.from({ length: 12 }, (_, i) => (
              <Skeleton key={i} w={tileWidth} h={TILE_HEIGHT} r={16} />
            ))}
          </View>
        )}
      </View>
    </View>
  );
}

function tileWidthFor(width: number): number {
  const content = Math.min(width, MAX_CONTENT);
  return Math.floor((content - LAYOUT.margin * 2 - TILE_GAP * (COLUMNS - 1)) / COLUMNS);
}

function exitTo(home: string) {
  if (router.canGoBack()) router.back();
  else router.replace(home as never);
}

interface RollSheetProps {
  rollKey: string;
  roll: AttendanceRoll;
  tileWidth: number;
  nav: TakeNav;
  refreshing: boolean;
  onRefresh: () => void;
}

function RollSheet({ rollKey, roll, tileWidth, nav, refreshing, onRefresh }: RollSheetProps) {
  const take = useTakeAttendance(roll, rollKey);
  const online = useOnline();
  const [menuId, setMenuId] = useState<ID | null>(null);
  const [datesOpen, setDatesOpen] = useState(false);
  /** Where to go once the person confirms dropping unsaved marks. */
  const [leaveTo, setLeaveTo] = useState<(() => void) | null>(null);

  const students = roll.students;
  const title = [roll.batchName, roll.subjectName].filter(Boolean).join(' · ');
  const goTo = (go: () => void) => (take.dirty ? setLeaveTo(() => go) : go());
  const onBack = () => goTo(() => exitTo(nav.home));
  const register = nav.register;
  const openRegister = register
    ? () => goTo(() => router.push(register(roll.batchId, roll.date.slice(0, 7)) as never))
    : undefined;
  const addStudent = nav.addStudent;
  const pickDate = (date: ISODate) => {
    setDatesOpen(false);
    if (date !== roll.date) router.setParams({ date });
  };

  const openMenu = useCallback((id: ID) => setMenuId(id), []);
  const menuStudent = students.find((s) => s.studentId === menuId) ?? null;
  const afterCount = menuStudent ? students.length - 1 - students.indexOf(menuStudent) : 0;

  const renderTile = useCallback(
    ({ item }: { item: AttendanceRollStudent }) => (
      <StudentTile
        student={item}
        status={take.marks[item.studentId] ?? 'present'}
        width={tileWidth}
        onPress={take.cycle}
        onLongPress={openMenu}
      />
    ),
    [take.marks, take.cycle, tileWidth, openMenu],
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ flex: 1, width: '100%', maxWidth: MAX_CONTENT, alignSelf: 'center' }}>
        <SafeAreaView edges={['top']} style={{ backgroundColor: C.canvas }}>
          <TakeHeader
            title={title}
            dateLabel={dateChipLabel(roll.date)}
            editing={take.editing}
            onBack={onBack}
            onDate={() => setDatesOpen(true)}
            onRegister={openRegister}
          />
        </SafeAreaView>
        <SummaryStrip counts={take.counts} onMarkAllPresent={take.markAllPresent} />
        <SyncBanner online={online} queued={take.queued !== null} lastSynced={agoLabel(take.lastSyncedAt)} />
        {take.failure ? (
          <FailureBar message={take.failure} onRetry={() => void take.save()} onDismiss={take.dismissFailure} />
        ) : null}
        <FlatList
          style={{ flex: 1 }}
          data={students}
          key={`grid-${COLUMNS}`}
          numColumns={COLUMNS}
          keyExtractor={(s) => s.studentId}
          renderItem={renderTile}
          extraData={take.marks}
          columnWrapperStyle={{ gap: TILE_GAP }}
          contentContainerStyle={{ padding: LAYOUT.margin, gap: TILE_GAP, paddingBottom: 32 }}
          initialNumToRender={24}
          refreshing={refreshing && !take.dirty}
          onRefresh={take.dirty ? undefined : onRefresh}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <EmptyState
              icon="people-outline"
              title="No students in this batch"
              text={
                addStudent
                  ? 'Admit students to this batch and they will appear here for roll call.'
                  : 'Students appear here for roll call once the institute admits them to this batch.'
              }
              actionLabel={addStudent ? 'Add a student' : undefined}
              onAction={addStudent ? () => router.push(addStudent as never) : undefined}
            />
          }
        />
        <SaveFooter
          counts={take.counts}
          editing={take.editing}
          dirty={take.dirty}
          phase={take.phase}
          onSave={() => void take.save()}
        />
      </View>

      <TileMenu
        student={menuStudent}
        status={menuStudent ? take.marks[menuStudent.studentId] ?? 'present' : 'present'}
        afterCount={afterCount}
        onMarkAfter={(status) => menuStudent && take.applyAfter(menuStudent.studentId, status)}
        onClose={() => setMenuId(null)}
      />
      <DateSheet
        visible={datesOpen}
        value={roll.date}
        dirty={take.dirty}
        onPick={pickDate}
        onClose={() => setDatesOpen(false)}
      />
      <ConfirmDialog
        visible={leaveTo !== null}
        title="Discard these marks?"
        description="You have changes that are not saved. Leaving now drops them."
        confirmLabel="Discard"
        cancelLabel="Keep marking"
        onConfirm={() => {
          const go = leaveTo;
          setLeaveTo(null);
          go?.();
        }}
        onCancel={() => setLeaveTo(null)}
      />
    </View>
  );
}
