import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { C, R } from '@/lib/theme';
import { Text } from '@/components/ui';

export interface DemoAccount {
  role: 'owner' | 'teacher' | 'student' | 'parent';
  label: string;
  identifier: string;
  icon: keyof typeof Ionicons.glyphMap;
}

const DEMOS: DemoAccount[] = [
  { role: 'owner', label: 'Owner', identifier: 'owner@sunrise.test', icon: 'business-outline' },
  { role: 'teacher', label: 'Teacher', identifier: 'rohit@sunrise.test', icon: 'school-outline' },
  { role: 'student', label: 'Student', identifier: 'aarav@sunrise.test', icon: 'people-outline' },
  { role: 'parent', label: 'Parent', identifier: 'parent@sunrise.test', icon: 'heart-outline' },
];

export function DemoPills({ onPick }: { onPick: (acc: DemoAccount) => void }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
      {DEMOS.map((d) => (
        <Pressable
          key={d.role}
          onPress={() => onPick(d)}
          style={({ pressed }) => ({
            width: '48%',
            height: 56,
            borderRadius: R.field,
            borderWidth: 1,
            borderColor: C.hairline,
            backgroundColor: C.surface,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
            paddingHorizontal: 14,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: C.track, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={d.icon} size={16} color={C.secondary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text variant="caption" weight={700} c={C.ink}>
              {d.label}
            </Text>
            <Text variant="label" c={C.muted} style={{ fontSize: 10 }}>
              demo1234
            </Text>
          </View>
        </Pressable>
      ))}
    </View>
  );
}
