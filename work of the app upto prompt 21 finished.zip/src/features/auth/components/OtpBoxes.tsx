import React, { useEffect, useRef, useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { C, R } from '@/lib/theme';
import { Text } from '@/components/ui';

interface Props {
  value: string;
  onChange: (next: string) => void;
  error?: string | null;
}

export function OtpBoxes({ value, onChange, error }: Props) {
  const inputs = useRef<Array<TextInput | null>>([]);
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);

  const digits = value.padEnd(6, '').slice(0, 6).split('');
  const handleChangeAt = (index: number, text: string) => {
    const clean = text.replace(/\D/g, '').slice(0, 6);
    if (clean.length > 1) {
      // paste fills all
      const next = clean.slice(0, 6);
      onChange(next);
      const last = Math.min(5, next.length - 1);
      inputs.current[last]?.focus();
      return;
    }
    const ch = clean.slice(-1);
    const arr = value.padEnd(6, ' ').split('');
    arr[index] = ch || '';
    let next = arr.join('').replace(/ /g, '');
    // auto-advance
    if (ch && index < 5) {
      inputs.current[index + 1]?.focus();
    }
    // if deleted, stay
    onChange(next.slice(0, 6));
  };

  const handleKeyPress = (index: number, key: string) => {
    if (key === 'Backspace' && !digits[index] && index > 0) {
      inputs.current[index - 1]?.focus();
      const arr = value.split('');
      arr.splice(index - 1, 1);
      onChange(arr.join('').slice(0, 6));
    }
  };

  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', gap: 8, justifyContent: 'center' }}>
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const filled = !!digits[i]?.trim();
          const isFocused = focusedIndex === i;
          return (
            <View
              key={i}
              style={{
                width: 48,
                height: 56,
                borderRadius: R.field,
                borderWidth: isFocused ? 2 : 1,
                borderColor: error ? C.danger : isFocused ? C.primary : C.hairline,
                backgroundColor: C.surface,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <TextInput
                ref={(r) => {
                  inputs.current[i] = r;
                }}
                value={digits[i]?.trim() ?? ''}
                onChangeText={(t) => handleChangeAt(i, t)}
                onKeyPress={(e) => handleKeyPress(i, e.nativeEvent.key)}
                onFocus={() => setFocusedIndex(i)}
                onBlur={() => setFocusedIndex(null)}
                keyboardType="number-pad"
                textContentType="oneTimeCode"
                maxLength={6}
                selectTextOnFocus
                style={{ fontSize: 20, fontWeight: '700', color: C.ink, textAlign: 'center', width: 48, height: 56 }}
              />
            </View>
          );
        })}
      </View>
      {error ? (
        <Text variant="caption" c={C.danger} style={{ textAlign: 'center' }}>
          {error}
        </Text>
      ) : null}
    </View>
  );
}
