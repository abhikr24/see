import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { C, LAYOUT, R } from '@/lib/theme';
import { Button, Input, Text } from '@/components/ui';
import { copy } from '@/lib/copy';
import { DemoPills } from '../components/DemoPills';
import { useAuth } from '../hooks/useAuth';

export function LoginScreen() {
  const router = useRouter();
  const { requestOtp, signInWithGoogle, loading, fieldError } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [idError, setIdError] = useState<string | null>(null);
  const [pwError, setPwError] = useState<string | null>(null);

  const validate = () => {
    let ok = true;
    if (!identifier.trim()) {
      setIdError(copy.auth.login.errors.identifier);
      ok = false;
    } else setIdError(null);
    if (!password) {
      setPwError(copy.auth.login.errors.password);
      ok = false;
    } else setPwError(null);
    return ok;
  };

  const handleSignIn = async () => {
    setIdError(null);
    setPwError(null);
    if (!validate()) return;
    const challenge = await requestOtp(identifier, password);
    if (challenge) {
      router.push({ pathname: '/(auth)/otp' as never, params: { challengeId: challenge.challengeId, identifier } } as never);
    } else {
      // inline error under password, keep form
      setPwError(copy.auth.login.errors.invalid);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ flex: 1, padding: LAYOUT.margin, gap: 16 }}>
        <View style={{ gap: 6 }}>
          <Text variant="h1">{copy.auth.login.title}</Text>
          <Text variant="body" c={C.secondary}>
            {copy.auth.login.subtitle}
          </Text>
        </View>

        <View style={{ gap: 14 }}>
          <Input
            label={copy.auth.login.identifierLabel}
            placeholder={copy.auth.login.identifierPlaceholder}
            value={identifier}
            onChangeText={(t) => {
              setIdentifier(t);
              if (idError) setIdError(null);
              if (fieldError) setPwError(null);
            }}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
            returnKeyType="next"
            error={idError ?? undefined}
          />
          <Input
            label={copy.auth.login.passwordLabel}
            placeholder={copy.auth.login.passwordPlaceholder}
            value={password}
            onChangeText={(t) => {
              setPassword(t);
              if (pwError) setPwError(null);
            }}
            secure
            error={pwError ?? (fieldError ? fieldError : undefined)}
          />
          <View style={{ alignItems: 'flex-end' }}>
            <Pressable hitSlop={8}>
              <Text variant="label" c={C.primary} weight={600}>
                {copy.auth.login.forgot}
              </Text>
            </Pressable>
          </View>
          <Button title={copy.auth.login.signIn} onPress={handleSignIn} loading={loading} />
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 4 }}>
          <View style={{ flex: 1, height: 1, backgroundColor: C.hairline }} />
          <Text variant="label" c={C.muted}>
            {copy.auth.login.divider}
          </Text>
          <View style={{ flex: 1, height: 1, backgroundColor: C.hairline }} />
        </View>

        <Pressable
          onPress={signInWithGoogle}
          style={{
            height: 56,
            borderRadius: R.btn,
            borderWidth: 1,
            borderColor: C.hairline,
            backgroundColor: C.surface,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 10,
          }}
        >
          <Ionicons name="logo-google" size={18} color={C.ink} />
          <Text variant="body" weight={600}>
            {copy.auth.login.google}
          </Text>
        </Pressable>

        <View style={{ gap: 10, marginTop: 4 }}>
          <Text variant="label" c={C.secondary}>
            {copy.auth.login.demoTitle}
          </Text>
          <DemoPills
            onPick={(acc) => {
              setIdentifier(acc.identifier);
              setPassword('demo1234');
              setIdError(null);
              setPwError(null);
            }}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}
