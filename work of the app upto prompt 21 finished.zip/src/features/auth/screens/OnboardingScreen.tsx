import React, { useState } from 'react';
import { View, Pressable, Dimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { C, LAYOUT, R } from '@/lib/theme';
import { Button, Text } from '@/components/ui';
import { copy } from '@/lib/copy';

const { width } = Dimensions.get('window');

export function OnboardingScreen() {
  const router = useRouter();
  const [index, setIndex] = useState(0);
  const slides = copy.auth.onboarding.slides;
  const last = index === slides.length - 1;

  const markSeen = async () => {
    try {
      await AsyncStorage.setItem('gf.onboarding.seen', '1');
    } catch {}
  };

  const goNext = async () => {
    if (last) {
      await markSeen();
      router.replace('/(auth)/login' as never);
    } else setIndex((i) => i + 1);
  };

  const skip = async () => {
    await markSeen();
    router.replace('/(auth)/login' as never);
  };

  const icons: (keyof typeof Ionicons.glyphMap)[] = ['layers-outline', 'people-outline', 'eye-outline'];

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, padding: LAYOUT.margin, paddingTop: 32 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
        <Pressable onPress={skip} hitSlop={12} style={{ paddingHorizontal: 12, paddingVertical: 8 }}>
          <Text variant="label" c={C.muted} weight={600}>
            {copy.auth.onboarding.skip}
          </Text>
        </Pressable>
      </View>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 20 }}>
        <View style={{ width: width * 0.72, height: width * 0.56, borderRadius: 24, backgroundColor: C.surface, borderWidth: 1, borderColor: C.hairline, alignItems: 'center', justifyContent: 'center', gap: 12 }}>
          <View style={{ width: 64, height: 64, borderRadius: 20, backgroundColor: C.navySoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name={icons[index] as string as keyof typeof Ionicons.glyphMap} size={28} color={C.primary} />
          </View>
          <View style={{ width: 120, height: 8, borderRadius: 4, backgroundColor: C.track }} />
          <View style={{ width: 80, height: 8, borderRadius: 4, backgroundColor: C.track }} />
        </View>
        <View style={{ gap: 8, alignItems: 'center', paddingHorizontal: 16 }}>
          <Text variant="h1" style={{ textAlign: 'center' }}>
            {slides[index].title}
          </Text>
          <Text variant="body" c={C.secondary} style={{ textAlign: 'center' }}>
            {slides[index].body}
          </Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
          {slides.map((_, i) => (
            <View
              key={i}
              style={{
                width: i === index ? 22 : 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: i === index ? C.primary : C.hairline,
              }}
            />
          ))}
        </View>
      </View>
      <View style={{ gap: 12 }}>
        <Button title={last ? copy.auth.onboarding.start : copy.auth.onboarding.next} onPress={goNext} />
      </View>
    </View>
  );
}
