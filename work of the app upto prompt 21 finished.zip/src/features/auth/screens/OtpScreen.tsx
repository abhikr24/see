import React, { useEffect, useState } from 'react';
import { View, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { C, LAYOUT } from '@/lib/theme';
import { Button, Text } from '@/components/ui';
import { copy } from '@/lib/copy';
import { OtpBoxes } from '../components/OtpBoxes';
import { useBackend } from '@/core/backend';
import { resolveAuthenticatedDestination } from '@/store/session';
import { useOtp } from '../hooks/useAuth';

export function OtpScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ challengeId: string; identifier: string }>();
  const challengeId = (params.challengeId as string) ?? '';
  const identifier = (params.identifier as string) ?? '';
  const [code, setCode] = useState('');
  const { backend } = useBackend();
  const { verify, resend, loading, error, setError, resendIn, setResendIn } = useOtp(challengeId);

  useEffect(() => {
    if (!challengeId) router.replace('/(auth)/login' as never);
  }, [challengeId, router]);

  useEffect(() => {
    const t = setInterval(() => setResendIn((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [setResendIn]);

  const handleVerify = async () => {
    const ok = await verify(code);
    // Caches are already invalidated. Go to the membership's home, not
    // choose-a-role, and not `/` (that href collides with the auth stack).
    if (ok) router.replace((await resolveAuthenticatedDestination(backend, null)) as never);
    else setCode('');
  };

  const handleResend = async () => {
    if (resendIn > 0) return;
    await resend();
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ flex: 1, padding: LAYOUT.margin, gap: 20 }}>
        <View style={{ gap: 6 }}>
          <Text variant="h1">{copy.auth.otp.title}</Text>
          <Text variant="body" c={C.secondary}>
            {copy.auth.otp.subtitle} {identifier ? `(${identifier})` : ''}
          </Text>
        </View>

        <OtpBoxes value={code} onChange={(v) => { setCode(v); if (error) setError(null); }} error={error} />
        <Text variant="label" c={C.muted} style={{ textAlign: 'center' }}>
          {copy.auth.otp.hint}
        </Text>

        <Button title={copy.auth.otp.verify} onPress={handleVerify} loading={loading} />

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Pressable onPress={() => router.replace('/(auth)/login' as never)} hitSlop={8}>
            <Text variant="label" c={C.primary} weight={600}>
              {copy.auth.otp.change}
            </Text>
          </Pressable>
          <Pressable onPress={handleResend} disabled={resendIn > 0} hitSlop={8} style={{ opacity: resendIn > 0 ? 0.5 : 1 }}>
            <Text variant="label" c={resendIn > 0 ? C.muted : C.primary} weight={600}>
              {resendIn > 0 ? `${copy.auth.otp.resend} (${resendIn}s)` : copy.auth.otp.resend}
            </Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}
