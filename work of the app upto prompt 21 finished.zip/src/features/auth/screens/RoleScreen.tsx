import React, { useState } from 'react';
import { View, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { C, LAYOUT, R } from '@/lib/theme';
import { Button, Text } from '@/components/ui';
import { copy } from '@/lib/copy';

type RoleKey = 'owner' | 'teacher' | 'student' | 'parent';

const ROLES: { key: RoleKey; icon: keyof typeof Ionicons.glyphMap }[] = [
  { key: 'owner', icon: 'business-outline' },
  { key: 'teacher', icon: 'school-outline' },
  { key: 'student', icon: 'people-outline' },
  { key: 'parent', icon: 'heart-outline' },
];

export function RoleScreen() {
  const router = useRouter();
  const [selected, setSelected] = useState<RoleKey>('student');

  const onContinue = () => {
    if (selected === 'owner') router.replace('/(auth)/create-institute' as never);
    else router.replace('/(auth)/join-by-code' as never);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ flex: 1, padding: LAYOUT.margin, gap: 16 }}>
        <View style={{ gap: 6 }}>
          <Text variant="h1">{copy.auth.role.title}</Text>
          <Text variant="body" c={C.secondary}>
            {copy.auth.role.subtitle}
          </Text>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
          {ROLES.map((r) => {
            const isSelected = selected === r.key;
            return (
              <Pressable
                key={r.key}
                onPress={() => setSelected(r.key)}
                style={{
                  width: '47%',
                  height: 96,
                  borderRadius: R.card,
                  borderWidth: isSelected ? 2 : 1,
                  borderColor: isSelected ? C.primary : C.hairline,
                  backgroundColor: C.surface,
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 8,
                }}
              >
                {isSelected ? (
                  <View style={{ position: 'absolute', top: 8, right: 8, width: 20, height: 20, borderRadius: 10, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' }}>
                    <Ionicons name="checkmark" size={12} color={C.surface} />
                  </View>
                ) : null}
                <Ionicons name={r.icon} size={22} color={isSelected ? C.primary : C.secondary} />
                <Text variant="title" c={isSelected ? C.primary : C.ink}>
                  {copy.auth.role.roles[r.key].label}
                </Text>
                <Text variant="label" c={C.muted} style={{ fontSize: 10 }}>
                  {copy.auth.role.roles[r.key].desc}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <View style={{ flex: 1 }} />
        <Button title={copy.auth.role.continue} onPress={onContinue} />
      </View>
    </SafeAreaView>
  );
}
