import React from 'react';
import { Pressable, View } from 'react-native';
import type { BatchSummary } from '@/core/contracts/models';
import { pct } from '@/lib/format';
import { C } from '@/lib/theme';
import { Icon, Person, Text, panel, row, schedule, time } from './ui';

const tones = [
  { bg: C.navySoft, fg: C.navyBright, icon: 'calculator-outline' as const },
  { bg: C.tealSoft, fg: C.teal, icon: 'flask-outline' as const },
  { bg: C.accentSoft, fg: C.accent, icon: 'planet-outline' as const },
];

export function BatchCard({
  batch: b,
  index,
  onPress,
}: {
  batch: BatchSummary;
  index: number;
  onPress: () => void;
}) {
  const tone = tones[index % tones.length];
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open ${b.name}`}
      onPress={onPress}
      style={({ pressed }) => ({
        ...panel,
        flex: 1,
        padding: 23,
        borderColor: pressed ? C.navyMid : C.hairline,
        transform: [{ translateY: pressed ? -2 : 0 }],
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <View style={{ ...row, gap: 13, marginBottom: 20 }}>
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: 13,
            backgroundColor: tone.bg,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name={tone.icon} size={23} color={tone.fg} />
        </View>
        <View style={{ flex: 1 }}>
          <Text variant="title" weight={700}>
            {b.name}
          </Text>
          <Text variant="caption" c={C.secondary} numberOfLines={1} style={{ marginTop: 6, fontSize: 12 }}>
            {b.subjectName} · {schedule(b.days)}
          </Text>
        </View>
        <Icon name="arrow-forward" size={17} color={C.muted} />
      </View>

      <View style={{ ...row, gap: 9, marginBottom: 15 }}>
        <Person name={b.teacherName} uri={b.teacherPhoto} size={26} />
        <Text variant="caption" style={{ fontSize: 12 }} c={C.secondary}>
          {b.teacherName}
        </Text>
        <View style={{ width: 3, height: 3, borderRadius: 2, backgroundColor: C.muted }} />
        <Text style={{ fontSize: 11 }} c={C.muted}>
          Teacher
        </Text>
      </View>

      <View style={{ ...row, gap: 8, marginBottom: 22 }}>
        <Icon name="time-outline" size={15} color={C.muted} />
        <Text style={{ fontSize: 12 }} c={C.secondary}>
          {time(b.startsAt)} – {time(b.endsAt)}
        </Text>
      </View>

      <View style={{ ...row, justifyContent: 'space-between', marginBottom: 10 }}>
        <Text variant="caption" style={{ fontSize: 11 }} c={C.secondary}>
          Overall attendance
        </Text>
        <Text
          tabular
          variant="caption"
          weight={700}
          c={b.attendancePct >= 75 ? C.teal : b.attendancePct > 0 ? C.danger : C.muted}
        >
          {b.attendanceTotal ? pct(b.attendancePct) : '—'}
        </Text>
      </View>
      <View style={{ height: 5, backgroundColor: C.track, borderRadius: 5, overflow: 'hidden' }}>
        <View
          style={{ width: `${b.attendancePct}%`, height: '100%', backgroundColor: C.teal, borderRadius: 5 }}
        />
      </View>

      <View
        style={{
          ...row,
          borderTopWidth: 1,
          borderTopColor: C.hairline,
          marginTop: 23,
          paddingTop: 16,
          justifyContent: 'space-between',
        }}
      >
        <View style={{ ...row, gap: 7 }}>
          <Icon name="people-outline" size={16} color={C.muted} />
          <Text variant="caption" c={C.secondary} style={{ fontSize: 12 }}>
            <Text tabular weight={700} style={{ fontSize: 12 }} c={C.secondary}>
              {b.studentCount}
            </Text>{' '}
            students
          </Text>
        </View>
        {b.pendingFees > 0 ? (
          <View
            style={{
              ...row,
              gap: 5,
              paddingVertical: 5,
              paddingHorizontal: 8,
              borderRadius: 6,
              backgroundColor: C.warningSoft,
            }}
          >
            <View style={{ width: 4, height: 4, backgroundColor: C.warning, borderRadius: 3 }} />
            <Text style={{ fontSize: 10 }} c={C.duesInk}>
              {b.pendingFees} fees pending
            </Text>
          </View>
        ) : (
          <Text style={{ fontSize: 10 }} c={C.teal}>
            No pending dues
          </Text>
        )}
      </View>
    </Pressable>
  );
}
