import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, View } from 'react-native';
import { C } from '@/lib/theme';
import { Action, Field, Icon, Person, State, Text, panel, row } from './ui';
import { useBatchDetail } from './useBatchWorkspace';

export type BatchDialog = 'attendance' | 'homework' | 'material' | 'archive' | null;

type Detail = ReturnType<typeof useBatchDetail>;

export function BatchDetailDialogs({
  dialog,
  close,
  detail: d,
  archive,
  archiving,
}: {
  dialog: BatchDialog;
  close: () => void;
  detail: Detail;
  archive: () => void;
  archiving: boolean;
}) {
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');

  const publish = async () => {
    if (dialog !== 'homework' && dialog !== 'material') return;
    const result = await d.publish.mutate({ type: dialog, title, text });
    if (result.ok) close();
  };

  const save = async () => {
    const result = await d.save.mutate();
    if (result.ok) close();
  };

  const heading =
    dialog === 'attendance'
      ? 'Take attendance'
      : dialog === 'archive'
        ? 'Archive this batch?'
        : dialog === 'homework'
          ? 'Assign homework'
          : 'Share material';

  return (
    <Modal visible={!!dialog} transparent animationType="fade" onRequestClose={close}>
      <KeyboardAvoidingView
        style={{ flex: 1, backgroundColor: C.scrim, justifyContent: 'center', padding: 20 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <Pressable
          accessibilityLabel="Close dialog"
          onPress={close}
          style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}
        />
        <View
          style={{
            ...panel,
            padding: 24,
            maxWidth: 600,
            width: '100%',
            alignSelf: 'center',
            maxHeight: '88%',
            gap: 20,
          }}
        >
          <View style={{ ...row, justifyContent: 'space-between' }}>
            <Text variant="h2">{heading}</Text>
            <Pressable accessibilityLabel="Close dialog" onPress={close}>
              <Icon name="close" />
            </Pressable>
          </View>

          {dialog === 'attendance' ? (
            <>
              <Text variant="caption" c={C.secondary}>
                {new Date().toLocaleDateString('en-IN', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}{' '}
                · Period 1
              </Text>
              <State
                loading={d.prepareQuery.loading && !d.prepareQuery.data}
                error={d.prepareQuery.error?.message}
                retry={() => void d.prepareQuery.refetch()}
              />
              <FlatList
                data={d.roster.data ?? []}
                keyExtractor={(r) => r.studentId}
                style={{ flexShrink: 1 }}
                renderItem={({ item }) => (
                  <View
                    style={{
                      ...row,
                      gap: 10,
                      paddingVertical: 13,
                      borderBottomWidth: 1,
                      borderBottomColor: C.hairline,
                    }}
                  >
                    <Person name={item.fullName} size={29} />
                    <Text variant="caption" style={{ flex: 1, fontSize: 11 }} weight={600}>
                      {item.fullName}
                    </Text>
                    <View style={{ ...row, gap: 4 }}>
                      {(['present', 'absent', 'late', 'leave'] as const).map((s) => (
                        <Pressable
                          key={s}
                          accessibilityLabel={`${item.fullName}: ${s}`}
                          onPress={() => d.setMarks((m) => ({ ...m, [item.studentId]: s }))}
                          style={{
                            width: 30,
                            height: 31,
                            alignItems: 'center',
                            justifyContent: 'center',
                            borderRadius: 7,
                            backgroundColor:
                              (d.marks[item.studentId] ?? 'present') === s
                                ? s === 'absent'
                                  ? C.danger
                                  : C.primary
                                : C.track,
                          }}
                        >
                          <Text
                            style={{ fontSize: 10 }}
                            weight={700}
                            c={(d.marks[item.studentId] ?? 'present') === s ? C.surface : C.secondary}
                          >
                            {s === 'leave' ? 'LV' : s.slice(0, 1).toUpperCase()}
                          </Text>
                        </Pressable>
                      ))}
                    </View>
                  </View>
                )}
              />
              <Text style={{ fontSize: 10 }} c={C.muted}>
                P Present · A Absent · L Late · LV Leave
              </Text>
              <Action
                label={d.save.loading ? 'Saving…' : 'Save attendance'}
                disabled={
                  d.save.loading ||
                  d.prepareQuery.loading ||
                  !!d.prepareQuery.error ||
                  !d.roster.data?.length
                }
                icon="checkmark"
                onPress={() => void save()}
              />
            </>
          ) : dialog === 'archive' ? (
            <>
              <Text variant="caption" c={C.secondary} style={{ lineHeight: 22 }}>
                It will be hidden from active batches and new student enrolment. Students, attendance and
                all learning history stay exactly where they are.
              </Text>
              <Action
                label={archiving ? 'Archiving…' : 'Archive batch'}
                disabled={archiving}
                icon="archive-outline"
                onPress={archive}
              />
              <Action label="Keep this batch" soft onPress={close} />
            </>
          ) : (
            <>
              <Text variant="caption" c={C.secondary}>
                Published to all students in this batch.
              </Text>
              <Field
                label="Title"
                value={title}
                onChangeText={setTitle}
                placeholder={dialog === 'homework' ? 'e.g. Practice exercise 4.2' : 'e.g. Revision notes'}
                autoFocus
              />
              <Field
                label={dialog === 'homework' ? 'Instructions' : 'Material notes'}
                value={text}
                onChangeText={setText}
                placeholder="What should your students know?"
                multiline
                returnKeyType="default"
                style={{ minHeight: 120, textAlignVertical: 'top', flex: 0 }}
              />
              <Action
                label={
                  d.publish.loading
                    ? 'Publishing…'
                    : dialog === 'homework'
                      ? 'Assign homework'
                      : 'Share material'
                }
                disabled={!title.trim() || d.publish.loading}
                icon="paper-plane-outline"
                onPress={() => void publish()}
              />
            </>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
