import React from 'react';
import { View, useWindowDimensions } from 'react-native';
import type { BatchSummary } from '@/core/contracts/models';
import { pct } from '@/lib/format';
import { C } from '@/lib/theme';
import { Icon, Text, row } from './ui';

export function BatchHero({ batches }: { batches: BatchSummary[] }) {
  const wide = useWindowDimensions().width > 700;
  const students = batches.reduce((s, b) => s + b.studentCount, 0);
  const records = batches.reduce((s, b) => s + b.attendanceTotal, 0);
  const avg = records ? Math.round(batches.reduce((s, b) => s + b.attendancePct * b.attendanceTotal, 0) / records) : 0;

  const stats = [
    { n: batches.length, label: 'Active batches', icon: 'albums-outline' as const },
    { n: students, label: 'Students enrolled', icon: 'people-outline' as const },
    { n: pct(avg), label: 'Avg. attendance', icon: 'trending-up-outline' as const },
  ];

  return (
    <View
      style={{
        backgroundColor: C.primary,
        borderRadius: 20,
        padding: wide ? 28 : 22,
        overflow: 'hidden',
        marginBottom: 30,
      }}
    >
      <View
        style={{
          position: 'absolute',
          width: 290,
          height: 290,
          borderRadius: 160,
          borderWidth: 1,
          borderColor: C.heroLine,
          right: -47,
          top: -125,
        }}
      />
      <View
        style={{
          position: 'absolute',
          width: 370,
          height: 370,
          borderRadius: 200,
          borderWidth: 1,
          borderColor: C.heroLine,
          right: -88,
          top: -166,
        }}
      />
      <View style={{ ...row, gap: 7, marginBottom: 22 }}>
        <View style={{ width: 6, height: 6, borderRadius: 4, backgroundColor: C.accent }} />
        <Text variant="label" style={{ fontSize: 10, letterSpacing: 1.8 }} c={C.navyPale}>
          THE BIG PICTURE
        </Text>
      </View>

      <View style={{ ...row }}>
        {stats.map((item, i) => (
          <View
            key={item.label}
            style={{
              flex: 1,
              paddingLeft: i ? (wide ? 32 : 18) : 0,
              borderLeftWidth: i ? 1 : 0,
              borderLeftColor: C.heroLine,
            }}
          >
            <Text
              tabular
              c={C.surface}
              style={{ fontFamily: 'Heading', fontSize: wide ? 37 : 29, letterSpacing: -1.5 }}
              weight={700}
            >
              {item.n}
            </Text>
            <View style={{ ...row, gap: 7, marginTop: 9 }}>
              <Icon name={item.icon} size={13} color={C.navyPale} />
              <Text style={{ fontSize: wide ? 11 : 9 }} c={C.navyPale}>
                {item.label}
              </Text>
            </View>
          </View>
        ))}
        {wide && (
          <View style={{ width: 170, paddingLeft: 32, alignItems: 'flex-end', gap: 9 }}>
            <View
              style={{
                backgroundColor: C.heroGlass,
                padding: 12,
                borderRadius: 13,
                transform: [{ rotate: '-9deg' }],
              }}
            >
              <Icon name="library-outline" size={30} color={C.navyPale} />
            </View>
            <Text style={{ fontSize: 10 }} c={C.navyPale}>
              Small groups. Big futures.
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}
