import React from 'react';
import { Redirect } from 'expo-router';
import { useRouteResolution } from '@/store/session';
import { ShellLoading } from '@/features/shell/ShellLoading';
import { BatchShell } from './BatchShell';
export function BatchOwnerGate() {
  const r = useRouteResolution();
  if (r.status === 'loading') return <ShellLoading/>;
  if (r.status !== 'ready' || r.group !== '/(owner)') return <Redirect href={r.destination as never}/>;
  return <BatchShell/>;
}
