import React from 'react';

import { RoleTabShell } from '@/features/shell/RoleTabShell';

/**
 * The batches group used to ship its own app shell: a SafeAreaView header
 * with the institute identity and the owner avatar, plus a six-item nav bar
 * (Overview, Students, Batches, Attendance, Fees & payments, Notices).
 * That was a second shell, which is why the batches screens looked like a
 * different app from every other screen.
 *
 * There is exactly one shell now. RoleTabShell renders the shared header and
 * the floating pill tab bar, and the tab list comes from `src/lib/nav.ts` —
 * never from a feature folder. The batches module keeps its own content only:
 * the title, the "big picture" card and the batch cards.
 */
export function BatchShell() {
  return <RoleTabShell role="owner" />;
}
