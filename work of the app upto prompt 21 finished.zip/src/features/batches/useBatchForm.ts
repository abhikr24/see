import { useState } from 'react';
import { router } from 'expo-router';
import { validateBatch } from '@/core/contracts/batch-validation';
import { toBackendError } from '@/core/contracts/errors';
import type { Batch, NewEntity } from '@/core/contracts/models';
import { useBatchOptions, useBatchWorkspace } from './useBatchWorkspace';

/** The real owner route for the batches group. */
const BATCHES_ROUTE = '/(owner)/batches';

export function useBatchForm() {
  const { create } = useBatchWorkspace();
  const options = useBatchOptions();
  const [draft, setDraft] = useState({ name: '', subjectId: '', teacherId: '', days: [1,3,5], startsAt: '16:00', endsAt: '17:00', feePlan: 'monthly' as 'monthly' | 'quarterly' | 'term', amount: '', capacity: '' });
  const [error, setError] = useState<string | null>(null);
  const patch = (p: Partial<typeof draft>) => { setDraft((d) => ({ ...d, ...p })); setError(null); };
  const submit = async () => {
    const input: NewEntity<Batch, 'name' | 'academicYear'> = { name: draft.name.trim(), subjectId: draft.subjectId,
      teacherId: draft.teacherId, days: draft.days, startsAt: draft.startsAt, endsAt: draft.endsAt,
      feePlan: draft.feePlan, feeAmount: draft.amount.trim() ? Number(draft.amount) : 0,
      capacity: draft.capacity.trim() ? Number(draft.capacity) : null, academicYear: '2026-27', status: 'active' };
    try {
      validateBatch(input);
      if (!input.subjectId) throw new Error('Choose a subject.');
      if (!input.teacherId) throw new Error('Choose a teacher.');
    } catch (e) { setError(e instanceof Error ? e.message : toBackendError(e).message); return; }
    const result = await create.mutate(input);
    if (result.ok) router.replace(BATCHES_ROUTE as never);
    else setError(result.error.message);
  };
  return { draft, patch, submit, options, error, saving: create.loading };
}
