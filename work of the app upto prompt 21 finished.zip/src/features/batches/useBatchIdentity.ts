import { useDomainQuery } from '@/core/hooks/domain';
export function useBatchIdentity() {
  return useDomainQuery('batches', ['identity'], async (b, i) => {
    const institute = await b.institutes.get(i);
    const owner = await b.auth.getProfile(i, institute.ownerId);
    return { institute, owner };
  });
}
