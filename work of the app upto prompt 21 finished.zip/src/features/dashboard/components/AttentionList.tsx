import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, R, TONE } from '@/lib/theme';
import type { DashboardLink } from '../links';
import type { AttentionView } from '../hooks/useDashboard';

const BAR = 4;

export interface AttentionListProps {
  items: AttentionView[];
  onOpen: (link: DashboardLink) => void;
}

function AttentionCard({ item, onOpen }: { item: AttentionView; onOpen: (link: DashboardLink) => void }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={item.title}
      onPress={() => onOpen(item.link)}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'stretch',
        backgroundColor: C.surface,
        borderRadius: R.btn,
        borderWidth: 1,
        borderColor: C.hairline,
        overflow: 'hidden',
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <View style={{ width: BAR, backgroundColor: TONE[item.tone].fg }} />
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 16, paddingHorizontal: 14 }}>
        <Text variant="body" weight={600} tabular style={{ flex: 1 }}>
          {item.title}
        </Text>
        <Ionicons name="chevron-forward" size={18} color={C.muted} />
      </View>
    </Pressable>
  );
}

/** Cards with a left accent bar. With nothing to flag it says so in one quiet line instead of showing zeros. */
export function AttentionList({ items, onOpen }: AttentionListProps) {
  if (items.length === 0) {
    return (
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
          paddingVertical: 14,
          paddingHorizontal: 16,
          borderRadius: R.btn,
          borderWidth: 1,
          borderColor: C.hairline,
          backgroundColor: C.surface,
        }}
      >
        <Ionicons name="checkmark-circle" size={20} color={C.success} />
        <Text variant="body" c={C.secondary} style={{ flex: 1 }}>
          All clear. Nothing needs your attention right now.
        </Text>
      </View>
    );
  }
  return (
    <View style={{ gap: 10 }}>
      {items.map((item) => (
        <AttentionCard key={item.key} item={item} onOpen={onOpen} />
      ))}
    </View>
  );
}
