import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { AvatarStack, Text } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';
import type { BatchRowView } from '../hooks/useDashboard';

const CHIP_WIDTH = 76;

/** Rounds only the outer corners so consecutive rows read as one card split by hairlines. */
function edges(first: boolean, last: boolean) {
  return {
    borderTopLeftRadius: first ? R.card : 0,
    borderTopRightRadius: first ? R.card : 0,
    borderBottomLeftRadius: last ? R.card : 0,
    borderBottomRightRadius: last ? R.card : 0,
    borderTopWidth: 1,
    borderBottomWidth: last ? 1 : 0,
  };
}

export interface BatchRowProps {
  row: BatchRowView;
  first: boolean;
  last: boolean;
}

/** Time chip · batch name and student count · the teachers taking it today. */
export function BatchRow({ row, first, last }: BatchRowProps) {
  return (
    <View
      style={{
        minHeight: LAYOUT.row,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 14,
        paddingVertical: 12,
        backgroundColor: C.surface,
        borderColor: C.hairline,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        ...edges(first, last),
      }}
    >
      <View
        style={{
          width: CHIP_WIDTH,
          paddingVertical: 7,
          borderRadius: R.chip,
          backgroundColor: C.navySoft,
          alignItems: 'center',
        }}
      >
        <Text c={C.primary} weight={700} tabular numberOfLines={1} style={{ fontSize: 12 }}>
          {row.time}
        </Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text variant="body" weight={700} numberOfLines={1}>
          {row.name}
        </Text>
        <Text variant="caption" c={C.secondary} tabular numberOfLines={1} style={{ marginTop: 2 }}>
          {row.students}
        </Text>
      </View>
      {row.teachers.length > 0 ? <AvatarStack users={row.teachers} max={3} size={28} overlap={8} /> : null}
    </View>
  );
}

/** The institute has batches, but none is on the timetable for today. */
export function NoClassesToday() {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        paddingVertical: 16,
        paddingHorizontal: 16,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        backgroundColor: C.surface,
      }}
    >
      <Ionicons name="calendar-clear-outline" size={20} color={C.muted} />
      <Text variant="body" c={C.secondary} style={{ flex: 1 }}>
        No classes on the timetable today.
      </Text>
    </View>
  );
}
