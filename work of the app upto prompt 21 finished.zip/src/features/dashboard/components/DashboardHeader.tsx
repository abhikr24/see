import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Card, EmptyState, ErrorState, Text } from '@/components/ui';
import { C, R, S } from '@/lib/theme';
import type { DashboardView } from '../hooks/useDashboard';
import { dashboardLinks, type DashboardLink } from '../links';
import { AttentionList } from './AttentionList';
import { DashboardHero } from './DashboardHero';
import { DashboardSkeleton } from './DashboardSkeleton';
import { QuickActions } from './QuickActions';

export interface DashboardHeaderProps {
  view: DashboardView;
  onOpen: (link: DashboardLink) => void;
}

function Section({
  title,
  action,
  children,
}: {
  title: string;
  action?: { label: string; onPress: () => void };
  children?: React.ReactNode;
}) {
  return (
    <View style={{ gap: S.md }}>
      {action ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Text variant="title">{title}</Text>
          <Pressable
            accessibilityRole="link"
            onPress={action.onPress}
            hitSlop={8}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 2 }}
          >
            <Text variant="caption" weight={600} c={C.primary}>
              {action.label}
            </Text>
            <Ionicons name="chevron-forward" size={14} color={C.primary} />
          </Pressable>
        </View>
      ) : (
        <Text variant="title">{title}</Text>
      )}
      {children}
    </View>
  );
}

/** Shown above stale numbers when a refresh failed, so they are never mistaken for current. */
function StaleNotice({ message }: { message: string }) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        paddingVertical: 12,
        paddingHorizontal: 14,
        borderRadius: R.btn,
        backgroundColor: C.dangerSoft,
      }}
    >
      <Ionicons name="cloud-offline-outline" size={18} color={C.danger} />
      <Text variant="caption" c={C.danger} weight={600} style={{ flex: 1 }}>
        Could not refresh. These are the last numbers we loaded. {message}
      </Text>
    </View>
  );
}

/**
 * Everything above the batch rows. One of four shapes, chosen by `view.status`:
 * skeleton, error with retry, the brand-new-institute empty state, or the dashboard.
 */
export function DashboardHeader({ view, onOpen }: DashboardHeaderProps) {
  if (view.status === 'loading') return <DashboardSkeleton />;

  if (view.status === 'error') {
    return (
      <Card flat>
        <ErrorState
          title="Could not load your dashboard"
          message={view.errorMessage ?? 'Something went wrong.'}
          onRetry={() => void view.refresh()}
        />
      </Card>
    );
  }

  if (view.status === 'empty') {
    return (
      <View style={{ gap: S.xxl }}>
        <DashboardHero hero={view.hero} onOpen={onOpen} />
        {view.attention.length > 0 ? (
          <Section title="Needs your attention">
            <AttentionList items={view.attention} onOpen={onOpen} />
          </Section>
        ) : null}
        <Card flat>
          <EmptyState
            icon="albums-outline"
            title="No batches yet"
            text="Create your first batch and today's collection, attendance and classes will show up here."
            actionLabel="Create a batch"
            onAction={() => onOpen(dashboardLinks.createBatch())}
          />
        </Card>
      </View>
    );
  }

  return (
    <View style={{ gap: S.xxl, paddingBottom: S.md }}>
      <DashboardHero hero={view.hero} stats={view.stats} onOpen={onOpen} />
      {view.errorMessage ? <StaleNotice message={view.errorMessage} /> : null}
      <Section title="Quick actions">
        <QuickActions actions={view.quickActions} onOpen={onOpen} />
      </Section>
      <Section title="Needs your attention">
        <AttentionList items={view.attention} onOpen={onOpen} />
      </Section>
      <Section
        title="Today's batches"
        action={{ label: 'Timetable', onPress: () => onOpen(dashboardLinks.openTimetable()) }}
      />
    </View>
  );
}
