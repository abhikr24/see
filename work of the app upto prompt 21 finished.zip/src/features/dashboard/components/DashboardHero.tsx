import React from 'react';
import { Pressable, View } from 'react-native';

import { Avatar, GradientHeader, OverlapCard, Text } from '@/components/ui';
import { C } from '@/lib/theme';
import type { DashboardLink } from '../links';
import type { HeroView, StatView } from '../hooks/useDashboard';

const HERO_RADIUS = 24;
const HERO_PAD = 20;
/** How far the stat card rides up over the hero (OverlapCard's own negative margin). */
const OVERLAP = 22;

export interface DashboardHeroProps {
  hero: HeroView;
  /** Omit to show the hero on its own (brand-new institute). */
  stats?: StatView[];
  onOpen: (link: DashboardLink) => void;
}

function Stat({ stat, onOpen }: { stat: StatView; onOpen: (link: DashboardLink) => void }) {
  const body = (
    <>
      <Text
        weight={800}
        tabular
        numberOfLines={1}
        adjustsFontSizeToFit
        minimumFontScale={0.7}
        style={{ fontSize: stat.value.length > 7 ? 18 : 22, lineHeight: 28 }}
      >
        {stat.value}
      </Text>
      <Text variant="label" c={C.muted} numberOfLines={2} style={{ textAlign: 'center', marginTop: 4 }}>
        {stat.label}
      </Text>
    </>
  );
  const frame = { flex: 1, alignItems: 'center' as const, paddingHorizontal: 6 };
  const link = stat.link;
  if (!link) return <View style={frame}>{body}</View>;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${stat.value} ${stat.label}`}
      onPress={() => onOpen(link)}
      style={({ pressed }) => ({ ...frame, opacity: pressed ? 0.6 : 1 })}
    >
      {body}
    </Pressable>
  );
}

/** Navy hero with the three headline numbers on a white card overlapping its bottom edge. */
export function DashboardHero({ hero, stats, onOpen }: DashboardHeroProps) {
  return (
    <View>
      <GradientHeader
        style={{
          borderRadius: HERO_RADIUS,
          padding: HERO_PAD,
          paddingBottom: stats ? HERO_PAD + OVERLAP : HERO_PAD,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12 }}>
          <View style={{ flex: 1 }}>
            <Text variant="caption" c={C.surface} numberOfLines={1} style={{ opacity: 0.7 }}>
              {hero.institute}
            </Text>
            <Text c={C.surface} weight={800} numberOfLines={2} style={{ fontSize: 24, lineHeight: 30, marginTop: 4 }}>
              {hero.greeting}
            </Text>
            <Text variant="caption" c={C.surface} numberOfLines={1} style={{ opacity: 0.6, marginTop: 6 }}>
              {hero.meta}
            </Text>
          </View>
          <Avatar name={hero.userName} uri={hero.avatarUrl} size={40} />
        </View>
      </GradientHeader>

      {stats ? (
        <OverlapCard style={{ paddingHorizontal: 6, paddingVertical: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'stretch' }}>
            {stats.map((stat, index) => (
              <React.Fragment key={stat.key}>
                {index > 0 ? <View style={{ width: 1, backgroundColor: C.hairline }} /> : null}
                <Stat stat={stat} onOpen={onOpen} />
              </React.Fragment>
            ))}
          </View>
        </OverlapCard>
      ) : null}
    </View>
  );
}
