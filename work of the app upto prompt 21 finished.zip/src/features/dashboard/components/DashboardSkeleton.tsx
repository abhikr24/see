import React from 'react';
import { View } from 'react-native';

import { ListSkeleton, Skeleton } from '@/components/ui';
import { C, R, S } from '@/lib/theme';

/** First-load placeholder, laid out like the real screen so nothing jumps when the numbers land. */
export function DashboardSkeleton() {
  return (
    <View accessibilityLabel="Loading dashboard" style={{ gap: S.xxl }}>
      <View>
        <Skeleton h={148} r={24} />
        <View
          style={{
            flexDirection: 'row',
            marginTop: -22,
            marginHorizontal: 12,
            paddingVertical: 16,
            borderRadius: R.card,
            borderWidth: 1,
            borderColor: C.hairline,
            backgroundColor: C.surface,
          }}
        >
          {[0, 1, 2].map((column) => (
            <View key={column} style={{ flex: 1, alignItems: 'center', gap: 10 }}>
              <Skeleton h={22} w={64} />
              <Skeleton h={10} w={72} />
            </View>
          ))}
        </View>
      </View>

      <View style={{ gap: S.md }}>
        <Skeleton h={16} w={120} />
        <View style={{ flexDirection: 'row' }}>
          {[0, 1, 2, 3].map((square) => (
            <View key={square} style={{ flex: 1, alignItems: 'center', gap: 8 }}>
              <Skeleton h={56} w={56} r={R.btn} />
              <Skeleton h={10} w={48} />
            </View>
          ))}
        </View>
      </View>

      <View style={{ gap: S.md }}>
        <Skeleton h={16} w={170} />
        <Skeleton h={54} r={R.btn} />
        <Skeleton h={54} r={R.btn} />
      </View>

      <View style={{ gap: S.md }}>
        <Skeleton h={16} w={140} />
        <ListSkeleton rows={3} />
      </View>
    </View>
  );
}
