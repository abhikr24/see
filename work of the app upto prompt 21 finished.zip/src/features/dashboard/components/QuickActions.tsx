import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import type { DashboardLink } from '../links';
import type { QuickActionView } from '../hooks/useDashboard';

const SQUARE = 56;

export interface QuickActionsProps {
  actions: QuickActionView[];
  onOpen: (link: DashboardLink) => void;
}

/** Four tinted squares. Navy only: these are structure, not data, so no state colours. */
export function QuickActions({ actions, onOpen }: QuickActionsProps) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
      {actions.map((action) => (
        <Pressable
          key={action.key}
          accessibilityRole="button"
          accessibilityLabel={action.label}
          onPress={() => onOpen(action.link)}
          style={({ pressed }) => ({ flex: 1, alignItems: 'center', gap: 8, opacity: pressed ? 0.7 : 1 })}
        >
          <View
            style={{
              width: SQUARE,
              height: SQUARE,
              borderRadius: R.btn,
              backgroundColor: C.navySoft,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name={action.icon} size={24} color={C.primary} />
          </View>
          <Text
            c={C.secondary}
            weight={600}
            numberOfLines={2}
            style={{ fontSize: 12, lineHeight: 16, textAlign: 'center', paddingHorizontal: 4 }}
          >
            {action.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
