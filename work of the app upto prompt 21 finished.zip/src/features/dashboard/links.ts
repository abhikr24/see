import type { ID } from '@/core/contracts/models';

/** A route plus its query params, in the shape `router.push` takes. */
export interface DashboardLink {
  pathname: string;
  params?: Record<string, string>;
}

const link = (pathname: string, params: Record<string, string> = {}, batchId?: ID | null): DashboardLink => ({
  pathname,
  params: batchId ? { ...params, batchId } : params,
});

/**
 * Every place the dashboard can send the owner, in one table. The receiving
 * screen reads `batchId` (and `action` / `filter`) with `useLocalSearchParams`.
 * Re-pointing a shortcut when its real screen lands is a one-line change here.
 */
export const dashboardLinks = {
  takeAttendance: (batchId: ID | null) => link('/(owner)/attendance', {}, batchId),
  addStudent: (batchId: ID | null) => link('/(owner)/students/new', {}, batchId),
  collectFee: (batchId: ID | null) => link('/(owner)/fees', { action: 'collect' }, batchId),
  sendNotice: (batchId: ID | null) => link('/(owner)/notices', { action: 'compose' }, batchId),
  approvals: () => link('/(owner)/approvals'),
  openTimetable: () => link('/(owner)/timetable'),
  overdueFees: () => link('/(owner)/fees', { filter: 'overdue' }),
  lowAttendance: () => link('/(owner)/students', { filter: 'low-attendance' }),
  createBatch: () => link('/(owner)/batches', { action: 'add' }),
} as const;
