import React, { useCallback } from 'react';
import { FlatList, RefreshControl } from 'react-native';
import { router } from 'expo-router';

import { C, LAYOUT } from '@/lib/theme';
import { BatchRow, NoClassesToday } from '../components/BatchRow';
import { DashboardHeader } from '../components/DashboardHeader';
import { useDashboard, type BatchRowView } from '../hooks/useDashboard';
import type { DashboardLink } from '../links';

/** Clears the floating tab bar the owner shell draws over the bottom of every tab. */
const TAB_BAR_INSET = 136;

/**
 * Owner home: what was collected, who is absent, what needs attention, what is
 * on today. Layout only – the numbers, wording and destinations all come from
 * `useDashboard`.
 */
export function OwnerDashboardScreen() {
  const view = useDashboard();
  const ready = view.status === 'ready';
  const rows = ready ? view.batches : [];

  const open = useCallback((link: DashboardLink) => router.push(link as never), []);

  return (
    <FlatList<BatchRowView>
      style={{ flex: 1, backgroundColor: C.canvas }}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: TAB_BAR_INSET }}
      data={rows}
      keyExtractor={(row) => row.key}
      renderItem={({ item, index }) => <BatchRow row={item} first={index === 0} last={index === rows.length - 1} />}
      ListHeaderComponent={<DashboardHeader view={view} onOpen={open} />}
      ListEmptyComponent={ready ? <NoClassesToday /> : null}
      refreshControl={
        <RefreshControl
          refreshing={view.refreshing}
          onRefresh={() => void view.refresh()}
          tintColor={C.primary}
          colors={[C.primary]}
        />
      }
      showsVerticalScrollIndicator={false}
    />
  );
}
