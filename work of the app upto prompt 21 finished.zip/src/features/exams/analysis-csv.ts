/**
 * The analysis export.
 *
 * Every value is copied from the `ExamAnalysis` the screen is showing, so the
 * file and the screen can never disagree.
 */

import type { ExamAnalysis } from '@/core/contracts/models';
import { csvField } from './csv';

const EOL = '\r\n';
const BOM = '\uFEFF';

function line(cells: (string | number | null | undefined)[]): string {
  return cells.map(csvField).join(',');
}

/** The whole analysis as CSV: summary, every student, subjects, distribution. */
export function buildAnalysisCsv(analysis: ExamAnalysis): string {
  const lines: string[] = [];

  lines.push(line([`Exam analysis · ${analysis.examName}`]));
  lines.push(line(['Exam', analysis.examName]));
  lines.push(line(['Subject', analysis.subjectName]));
  lines.push(line(['Batch', analysis.batchName]));
  lines.push(line(['Max marks', analysis.maxMarks]));
  lines.push(line(['Pass mark', `${analysis.passPercent}%`]));
  lines.push(line(['Students', analysis.totalStudents]));
  lines.push(line(['Scored', analysis.scoredCount]));
  lines.push(line(['Absent', analysis.absentCount]));
  lines.push(line(['Class average', analysis.averagePct === null ? '' : `${analysis.averagePct.toFixed(1)}%`]));
  lines.push(line(['Highest', analysis.highestMarks === null ? '' : `${analysis.highestMarks} of ${analysis.maxMarks}`]));
  lines.push(line(['Lowest', analysis.lowestMarks === null ? '' : `${analysis.lowestMarks} of ${analysis.maxMarks}`]));
  lines.push(
    line([
      'Pass rate',
      analysis.passRatePct === null ? '' : `${analysis.passRatePct.toFixed(1)}%`,
    ]),
  );
  lines.push(line(['Previous exam', analysis.previousExamName ?? '']));
  lines.push(
    line([
      'Previous average',
      analysis.previousAveragePct === null ? '' : `${analysis.previousAveragePct.toFixed(1)}%`,
    ]),
  );
  lines.push(line(['Change vs previous', analysis.deltaPct === null ? '' : `${analysis.deltaPct.toFixed(1)} pts`]));

  lines.push('');
  lines.push(line(['Rank', 'Roll', 'Student', 'Marks', 'Max Marks', 'Percentage', 'Grade', 'Status']));
  for (const student of analysis.students) {
    lines.push(
      line([
        student.rank ?? '',
        student.rollNumber ?? '',
        student.fullName,
        student.marksObtained,
        student.maxMarks,
        `${student.percentage.toFixed(1)}%`,
        student.grade ?? '',
        student.status === 'absent' ? 'Absent' : student.status === 'pass' ? 'Pass' : 'Fail',
      ]),
    );
  }

  lines.push('');
  lines.push(line(['Subject-wise average']));
  lines.push(line(['Subject', 'Average %', 'Students', 'Max marks']));
  for (const subject of analysis.subjectAverages) {
    lines.push(line([subject.subjectName, subject.averagePct.toFixed(1), subject.students, subject.maxMarks]));
  }

  lines.push('');
  lines.push(line(['Distribution']));
  lines.push(line(['Score band', 'Students']));
  for (const bucket of analysis.distribution) {
    lines.push(line([bucket.label, bucket.count]));
  }

  lines.push('');
  lines.push(line(['Exam trend']));
  lines.push(line(['Exam', 'Class average %']));
  for (const point of analysis.trend) {
    lines.push(line([point.examName, point.averagePct.toFixed(1)]));
  }

  return BOM + lines.join(EOL) + EOL;
}

export function analysisCsvFilename(analysis: ExamAnalysis): string {
  const slug = analysis.examName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return `analysis-${slug || 'exam'}.csv`;
}
