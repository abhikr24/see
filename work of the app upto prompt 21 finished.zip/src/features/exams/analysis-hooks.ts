import { useDomainQuery } from '@/core/hooks/domain';
import type { ExamAnalysis, Exam, ID } from '@/core/contracts/models';

/**
 * The whole analysis of one exam, in one call and one loading state.
 *
 * The owner's analysis screen and the student's own results screen both read
 * this hook, so both show the same numbers for the same exam.
 */
export function useExamAnalysis(examId: ID | null) {
  return useDomainQuery<ExamAnalysis>(
    'results',
    ['analysis', examId],
    async (backend, instituteId) => backend.results.analysis(instituteId, examId as ID),
    Boolean(examId),
  );
}

export interface StudentExamRow {
  examId: ID;
  name: string;
  date: string | null;
  studentId: ID;
  studentName: string;
  marksObtained: number;
  maxMarks: number;
  percentage: number;
  rank: number | null;
  status: string;
}

/**
 * The exams the signed-in student (or a parent's children) has a result for.
 * Only published results are visible to a student, so nothing leaks here.
 */
export function useStudentExamList() {
  return useDomainQuery<StudentExamRow[]>(
    'results',
    ['student-list'],
    async (backend, instituteId) => {
      const [mine, exams] = await Promise.all([
        backend.students.listMine(instituteId),
        backend.exams.list(instituteId, { limit: 200 }),
      ]);
      const examsById = new Map(exams.items.map((exam) => [exam.id, exam]));
      const rows: StudentExamRow[] = [];
      for (const student of mine) {
        const results = await backend.results.listForStudent(instituteId, student.id);
        for (const result of results) {
          const exam: Exam | undefined = examsById.get(result.examId);
          rows.push({
            examId: result.examId,
            name: exam?.name ?? 'Exam',
            date: exam?.startsOn ?? null,
            studentId: student.id,
            studentName: student.fullName,
            marksObtained: result.totalObtained,
            maxMarks: result.totalMax,
            percentage: result.percentage,
            rank: result.rank,
            status: result.status,
          });
        }
      }
      return rows.sort(
        (a, b) =>
          (b.date ?? '').localeCompare(a.date ?? '') || a.studentName.localeCompare(b.studentName),
      );
    },
  );
}
