/**
 * Words and shapes for the exam analysis screen.
 *
 * Every number on screen comes from the repo; this file only turns those
 * numbers into text and into bar widths.
 */

import type { ExamAnalysis } from '@/core/contracts/models';
import { C } from '@/lib/theme';

export type DeltaTone = 'teal' | 'danger' | 'neutral';

/** "Unit Test 3" → "Unit 3", "Half Yearly Examination" → "Half". */
export function shortExamLabel(name: string): string {
  const words = name.trim().split(/\s+/).filter(Boolean);
  const first = words[0] ?? 'Exam';
  const number = words.slice(1).find((word) => /^\d+$/.test(word));
  const label = number ? `${first} ${number}` : first;
  return label.length > 8 ? `${label.slice(0, 7)}…` : label;
}

/** One decimal place, or a dash when there is no figure at all. */
export function percentLabel(value: number | null | undefined): string {
  if (value === null || value === undefined) return '—';
  return `${value.toFixed(1)}%`;
}

/** "284 of 320" */
export function scoreLabel(marks: number | null, max: number): string {
  if (marks === null) return '—';
  return `${marks} of ${max}`;
}

export interface DeltaView {
  label: string;
  tone: DeltaTone;
  color: string;
  icon: 'trending-up' | 'trending-down' | 'remove';
}

/** The change against the previous exam of the batch. */
export function deltaView(analysis: ExamAnalysis): DeltaView {
  const previous = analysis.previousExamName;
  if (analysis.deltaPct === null || !previous) {
    return {
      label: previous ? `Same as ${previous}` : 'No earlier exam to compare',
      tone: 'neutral',
      color: C.secondary,
      icon: 'remove',
    };
  }
  const value = analysis.deltaPct;
  const points = `${value > 0 ? '+' : ''}${value.toFixed(1)} pts vs ${previous}`;
  return value > 0
    ? { label: points, tone: 'teal', color: C.teal, icon: 'trending-up' }
    : value < 0
      ? { label: points, tone: 'danger', color: C.danger, icon: 'trending-down' }
      : { label: `Level with ${previous}`, tone: 'neutral', color: C.secondary, icon: 'remove' };
}

/** Bar width as a share of the track. Never zero, never over the track. */
export function barWidth(pct: number): `${number}%` {
  return `${Math.max(2, Math.min(100, Math.round(pct)))}%`;
}

/** Height of one histogram column, in points, against the tallest column. */
export function bucketHeight(count: number, max: number, track: number): number {
  if (max <= 0) return 4;
  return Math.max(4, Math.round((count / max) * track));
}
