/**
 * The analysis sections.
 *
 * Pure presentation: every number arrives in the `ExamAnalysis` the repo
 * returned. The owner's analysis screen and the student's own results screen
 * render these same sections, so the two can never disagree.
 */

import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, Card, StatCard, Text } from '@/components/ui';
import type { ExamAnalysis, ExamTrendPoint } from '@/core/contracts/models';
import { C, R } from '@/lib/theme';
import { barWidth, bucketHeight, deltaView, percentLabel, shortExamLabel } from './analysis-model';

const BAR_TRACK = 46;
const HISTOGRAM_TRACK = 56;

/** Six thin bars, one per exam. The tallest bar is the saffron spotlight. */
function TrendBars({ points }: { points: ExamTrendPoint[] }) {
  const max = Math.max(...points.map((point) => point.averagePct), 1);
  const tallest = points.findIndex((point) => point.averagePct === max);
  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, height: BAR_TRACK }}>
        {points.map((point, index) => (
          <View key={point.examId} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end' }}>
            <View
              style={{
                width: '100%',
                maxWidth: 24,
                height: Math.max(4, Math.round((point.averagePct / max) * BAR_TRACK)),
                borderRadius: 5,
                backgroundColor: index === tallest ? C.accent : C.primary,
              }}
            />
          </View>
        ))}
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {points.map((point) => (
          <Text
            key={point.examId}
            variant="label"
            c={point.isCurrent ? C.primary : C.muted}
            numberOfLines={1}
            tabular
            style={{ flex: 1, fontSize: 9, textAlign: 'center' }}
          >
            {shortExamLabel(point.examName)}
          </Text>
        ))}
      </View>
    </View>
  );
}

/** The class average, the change against the previous exam and the trend. */
export function AnalysisHero({ analysis }: { analysis: ExamAnalysis }) {
  const delta = deltaView(analysis);
  return (
    <Card flat pad={18} style={{ gap: 14 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
        <Text variant="label" c={C.muted}>
          Class average
        </Text>
        <Text variant="caption" c={C.muted} tabular>
          {analysis.scoredCount} of {analysis.totalStudents} scored
        </Text>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 12, flexWrap: 'wrap' }}>
        <Text variant="h2" weight={800} tabular style={{ fontSize: 22, lineHeight: 26 }}>
          {percentLabel(analysis.averagePct)}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingBottom: 3 }}>
          <Ionicons name={delta.icon} size={14} color={delta.color} />
          <Text variant="caption" weight={600} c={delta.color} tabular>
            {delta.label}
          </Text>
        </View>
      </View>

      <TrendBars points={analysis.trend} />
    </Card>
  );
}

/** Highest, lowest and pass rate. */
export function AnalysisStatCards({ analysis }: { analysis: ExamAnalysis }) {
  const passed = analysis.students.filter((student) => student.status === 'pass').length;
  return (
    <View style={{ flexDirection: 'row', gap: 10 }}>
      <View style={{ flex: 1 }}>
        <StatCard
          label="Highest"
          value={analysis.highestMarks === null ? '—' : analysis.highestMarks}
          subtitle={`of ${analysis.maxMarks}`}
        />
      </View>
      <View style={{ flex: 1 }}>
        <StatCard
          label="Lowest"
          value={analysis.lowestMarks === null ? '—' : analysis.lowestMarks}
          subtitle={`of ${analysis.maxMarks}`}
        />
      </View>
      <View style={{ flex: 1 }}>
        <StatCard
          label="Pass rate"
          value={analysis.passRatePct === null ? '—' : `${analysis.passRatePct.toFixed(0)}%`}
          subtitle={`${passed} of ${analysis.scoredCount} passed`}
        />
      </View>
    </View>
  );
}

function RankBadge({ rank, first }: { rank: number; first: boolean }) {
  return (
    <View
      style={{
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: first ? C.accent : C.navySoft,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text variant="label" weight={700} c={first ? C.surface : C.secondary} tabular style={{ fontSize: 11 }}>
        {rank}
      </Text>
    </View>
  );
}

/** The five best students of the exam. */
export function TopStudentsCard({
  analysis,
  highlightStudentId,
}: {
  analysis: ExamAnalysis;
  highlightStudentId?: string | null;
}) {
  return (
    <Card flat pad={16} style={{ gap: 4 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Text variant="title" weight={700}>
          Top 5 students
        </Text>
        <Text variant="caption" c={C.muted} tabular>
          {analysis.scoredCount} scored
        </Text>
      </View>

      {analysis.topStudents.length === 0 ? (
        <Text variant="caption" c={C.secondary}>
          No marks have been entered yet.
        </Text>
      ) : (
        analysis.topStudents.map((student, index) => (
          <View key={student.studentId}>
            {index > 0 ? (
              <View style={{ height: 1, backgroundColor: C.hairline, marginVertical: 8 }} />
            ) : null}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <RankBadge rank={student.rank ?? index + 1} first={student.rank === 1} />
              <Avatar name={student.fullName} uri={student.photoUrl} size={34} />
              <View style={{ flex: 1 }}>
                <Text variant="body" weight={600} numberOfLines={1}>
                  {student.fullName}
                  {student.studentId === highlightStudentId ? ' · You' : ''}
                </Text>
                <Text variant="caption" c={C.muted} tabular>
                  Roll {student.rollNumber ?? '—'}
                  {student.grade ? ` · Grade ${student.grade}` : ''}
                </Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text variant="body" weight={800} tabular>
                  {student.marksObtained}/{student.maxMarks}
                </Text>
                <Text variant="caption" c={C.muted} tabular>
                  {student.percentage.toFixed(1)}%
                </Text>
              </View>
            </View>
          </View>
        ))
      )}
    </Card>
  );
}

/** One horizontal bar per subject, on a soft track. */
export function SubjectAverageCard({ analysis }: { analysis: ExamAnalysis }) {
  return (
    <Card flat pad={16} style={{ gap: 14 }}>
      <View style={{ gap: 2 }}>
        <Text variant="title" weight={700}>
          Subject-wise average
        </Text>
        <Text variant="caption" c={C.muted}>
          Class average in each subject of this batch
        </Text>
      </View>

      {analysis.subjectAverages.length === 0 ? (
        <Text variant="caption" c={C.secondary}>
          No subject marks yet.
        </Text>
      ) : (
        analysis.subjectAverages.map((subject) => (
          <View key={subject.subjectId} style={{ gap: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
              <Text variant="body" weight={600} numberOfLines={1} style={{ flex: 1 }}>
                {subject.subjectName}
              </Text>
              <Text variant="body" weight={700} tabular>
                {subject.averagePct.toFixed(1)}%
              </Text>
            </View>
            <View style={{ height: 10, borderRadius: 5, backgroundColor: C.track, overflow: 'hidden' }}>
              <View
                style={{
                  width: barWidth(subject.averagePct),
                  height: '100%',
                  borderRadius: R.chip,
                  backgroundColor: C.primary,
                }}
              />
            </View>
          </View>
        ))
      )}
    </Card>
  );
}

/** The five score bands, with the number of students in each. */
export function DistributionCard({ analysis }: { analysis: ExamAnalysis }) {
  const max = Math.max(...analysis.distribution.map((bucket) => bucket.count), 0);
  return (
    <Card flat pad={16} style={{ gap: 12 }}>
      <View style={{ gap: 2 }}>
        <Text variant="title" weight={700}>
          Distribution
        </Text>
        <Text variant="caption" c={C.muted}>
          Students in each score band
        </Text>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8 }}>
        {analysis.distribution.map((bucket) => (
          <View key={bucket.label} style={{ flex: 1, alignItems: 'center', gap: 6 }}>
            <View style={{ height: 16, justifyContent: 'center' }}>
              <Text variant="label" weight={700} c={C.secondary} tabular>
                {bucket.count}
              </Text>
            </View>
            <View style={{ width: '100%', height: HISTOGRAM_TRACK, justifyContent: 'flex-end' }}>
              <View
                style={{
                  width: '100%',
                  height: bucketHeight(bucket.count, max, HISTOGRAM_TRACK),
                  borderRadius: 6,
                  backgroundColor: C.primary,
                }}
              />
            </View>
            <Text variant="label" c={C.muted} tabular style={{ fontSize: 9 }} numberOfLines={1}>
              {bucket.label}
            </Text>
          </View>
        ))}
      </View>
    </Card>
  );
}

/** Every section of the analysis, in the order the screen shows them. */
export function AnalysisSections({
  analysis,
  highlightStudentId,
}: {
  analysis: ExamAnalysis;
  highlightStudentId?: string | null;
}) {
  return (
    <View style={{ gap: 14 }}>
      <AnalysisHero analysis={analysis} />
      <AnalysisStatCards analysis={analysis} />
      <TopStudentsCard analysis={analysis} highlightStudentId={highlightStudentId} />
      <SubjectAverageCard analysis={analysis} />
      <DistributionCard analysis={analysis} />
    </View>
  );
}
