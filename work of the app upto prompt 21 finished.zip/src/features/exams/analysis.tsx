/**
 * The owner's exam analysis.
 *
 * One call — `ResultRepo.analysis` — and one loading state. Every figure on
 * screen comes from that one object, and the export writes the same object
 * to a CSV.
 */

import React, { useState } from 'react';
import { Pressable, RefreshControl, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';

import { Button, EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import { toast } from '@/core/backend';
import { dateShort } from '@/lib/format';
import { C, LAYOUT } from '@/lib/theme';
import { analysisCsvFilename, buildAnalysisCsv } from './analysis-csv';
import { useExamAnalysis } from './analysis-hooks';
import { AnalysisSections } from './analysis-view';
import { deliverExamCsv } from './export';

const TAB_BAR_INSET = 136;

export function ExamAnalysisScreen() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const examId = typeof id === 'string' && id.length > 0 ? id : null;
  const { data, loading, error, refetch } = useExamAnalysis(examId);
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    if (!data) return;
    setExporting(true);
    try {
      const outcome = await deliverExamCsv(analysisCsvFilename(data), buildAnalysisCsv(data));
      toast.success(outcome === 'downloaded' ? 'Analysis downloaded' : 'Analysis ready');
    } catch {
      toast.error('Could not export the analysis');
    } finally {
      setExporting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={loading && Boolean(data)}
            onRefresh={() => void refetch()}
            tintColor={C.primary}
          />
        }
        contentContainerStyle={{
          padding: LAYOUT.margin,
          paddingBottom: TAB_BAR_INSET,
          gap: 16,
          flexGrow: 1,
        }}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back to the exam"
          onPress={() => router.back()}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
        >
          <Ionicons name="chevron-back" size={20} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>
            Exam
          </Text>
        </Pressable>

        {loading && !data ? (
          <ListSkeleton rows={4} h={96} />
        ) : error && !data ? (
          <ErrorState message={error.message} onRetry={() => void refetch()} />
        ) : data ? (
          <>
            <View style={{ gap: 4 }}>
              <Text variant="h2" weight={800}>
                {data.examName}
              </Text>
              <Text variant="caption" c={C.secondary} tabular>
                {data.subjectName} · {data.batchName} · {dateShort(data.examDate)} · {data.maxMarks} marks
              </Text>
            </View>

            {data.scoredCount === 0 ? (
              <EmptyState
                icon="analytics-outline"
                title="No marks yet"
                text="Enter the marks for this exam and the analysis will fill in here."
                actionLabel="Enter marks"
                onAction={() => router.push(`/(owner)/exams/${data.examId}/marks` as never)}
              />
            ) : (
              <>
                <AnalysisSections analysis={data} />
                <Button
                  title="Export CSV"
                  icon="download-outline"
                  variant="outline"
                  size="md"
                  loading={exporting}
                  onPress={() => void handleExport()}
                />
              </>
            )}
          </>
        ) : null}
      </ScrollView>
    </View>
  );
}
