import type { Exam } from '@/core/contracts/models';

export const CSV_MIME = 'text/csv';
const BOM = '\uFEFF';
const EOL = '\r\n';
const FORMULA_START = /^[=+\-@\t\r]/;

export interface ExamCsvRow {
  rollNumber: number | null;
  fullName: string;
  status: 'Scored' | 'Absent' | 'Pending';
  marksObtained: number | null;
  maxMarks: number;
  percentage: number | null;
  grade: string | null;
}

export function csvField(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return '';
  let text = String(value);
  if (typeof value === 'string' && FORMULA_START.test(text)) text = `'${text}`;
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function buildExamCsv(
  exam: Exam,
  subjectName: string,
  batchName: string,
  rows: ExamCsvRow[],
): string {
  const header = ['Roll', 'Student', 'Status', 'Marks Obtained', 'Max Marks', 'Percentage', 'Grade'];
  const dataRows = rows.map((row) => [
    row.rollNumber,
    row.fullName,
    row.status,
    row.marksObtained,
    row.maxMarks,
    row.percentage !== null ? `${row.percentage}%` : '',
    row.grade ?? '',
  ]);
  const lines = [header, ...dataRows].map((r) => r.map(csvField).join(','));
  lines.push(
    '',
    csvField(`${exam.name} · ${subjectName} · ${batchName} · ${exam.startsOn ?? 'No date'} · ${exam.status}`),
  );
  return BOM + lines.join(EOL) + EOL;
}

export function examCsvFilename(exam: Exam): string {
  const slug = exam.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  const date = exam.startsOn ?? 'exam';
  return `exam-${slug || 'results'}-${date}.csv`;
}
