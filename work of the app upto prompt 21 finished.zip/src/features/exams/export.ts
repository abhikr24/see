import { Platform } from 'react-native';
import { CSV_MIME } from './csv';

export type ExportOutcome = 'shared' | 'downloaded' | 'saved';

interface WebAnchor {
  href: string;
  download: string;
  style: { display: string };
  click(): void;
  remove(): void;
}
interface WebGlobals {
  document: { createElement(tag: 'a'): WebAnchor; body: { appendChild(node: WebAnchor): void } };
  URL: { createObjectURL(blob: unknown): string; revokeObjectURL(url: string): void };
  Blob: new (parts: string[], options: { type: string }) => unknown;
}

export async function deliverExamCsv(filename: string, text: string): Promise<ExportOutcome> {
  if (Platform.OS === 'web') {
    const web = globalThis as unknown as WebGlobals;
    const url = web.URL.createObjectURL(new web.Blob([text], { type: `${CSV_MIME};charset=utf-8` }));
    const anchor = web.document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = 'none';
    web.document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => web.URL.revokeObjectURL(url), 10_000);
    return 'downloaded';
  }
  const [{ File, Paths }, Sharing] = await Promise.all([import('expo-file-system'), import('expo-sharing')]);
  const file = new File(Paths.cache, filename);
  file.create({ overwrite: true });
  file.write(text);
  if (!(await Sharing.isAvailableAsync())) return 'saved';
  await Sharing.shareAsync(file.uri, {
    mimeType: CSV_MIME,
    UTI: 'public.comma-separated-values-text',
    dialogTitle: 'Exam results CSV',
  });
  return 'shared';
}
