import { useMemo } from 'react';
import type { BatchRosterRow, BatchSummary, Exam, ID, Mark, Result, Subject } from '@/core/contracts/models';
import { validateNewExam } from '@/core/contracts/exam-validation';
import type { MarkEntry } from '@/core/contracts/ports';
import { useDomainMutation, useDomainQuery } from '@/core/hooks/domain';
import { computeExamStats, resolveExamSubject, todayIso, type ExamStats } from './model';

export interface ExamCardView {
  exam: Exam;
  batch: BatchSummary | undefined;
  batchName: string;
  subjectName: string;
  studentCount: number;
  stats: ExamStats;
}

export interface ExamsWorkspaceData {
  items: ExamCardView[];
}

export function useExamsWorkspace() {
  return useDomainQuery<ExamsWorkspaceData>('exams', ['workspace'], async (b, i) => {
    const [examPage, batchSummaries, subjectPage, markPage] = await Promise.all([
      b.exams.list(i, { limit: 200 }),
      b.batches.listSummaries(i),
      b.subjects.list(i, { limit: 100 }),
      b.marks.list(i, { limit: 500 }),
    ]);

    const batchMap = new Map(batchSummaries.map((batch) => [batch.id, batch]));
    const marksByExam = new Map<ID, Mark[]>();
    for (const mark of markPage.items) {
      const list = marksByExam.get(mark.examId) ?? [];
      list.push(mark);
      marksByExam.set(mark.examId, list);
    }

    const items: ExamCardView[] = examPage.items.map((exam) => {
      const batch = batchMap.get(exam.batchId);
      const examMarks = marksByExam.get(exam.id) ?? [];
      const { subjectName } = resolveExamSubject(exam, examMarks, batch, subjectPage.items);
      const studentCount = batch?.studentCount ?? 0;
      const stats = computeExamStats(exam, examMarks, studentCount);
      return {
        exam,
        batch,
        batchName: batch?.name ?? 'Batch',
        subjectName,
        studentCount,
        stats,
      };
    });

    return { items };
  });
}

export interface CreateExamOptions {
  batches: BatchSummary[];
  subjects: Subject[];
}

export interface CreateExamInput {
  name: string;
  subjectId: ID;
  batchId: ID;
  startsOn: string;
  totalMarks: number;
  enterMode: 'now' | 'later';
}

export function useCreateExam() {
  const options = useDomainQuery<CreateExamOptions>('exams', ['create-options'], async (b, i) => {
    const [batchSummaries, subjectPage] = await Promise.all([
      b.batches.listSummaries(i),
      b.subjects.list(i, { limit: 100 }),
    ]);
    return {
      batches: batchSummaries.filter((batch) => batch.status !== 'archived'),
      subjects: subjectPage.items.filter((s) => s.isActive),
    };
  });

  const submit = useDomainMutation<CreateExamInput, Exam>(
    ['exams', 'progress'],
    async (b, i, input) => {
      validateNewExam(
        {
          name: input.name,
          batchId: input.batchId,
          subjectId: input.subjectId,
          startsOn: input.startsOn,
          totalMarks: input.totalMarks,
        },
        todayIso(),
      );

      const exam = await b.exams.create(i, {
        name: input.name.trim(),
        batchId: input.batchId,
        subjectId: input.subjectId,
        startsOn: input.startsOn,
        totalMarks: input.totalMarks,
        status: 'scheduled',
      });

      if (input.enterMode === 'later') {
        const roster = await b.batches.listRoster(i, input.batchId);
        await Promise.all(
          roster.map((student) =>
            b.progress.saveTask(i, {
              studentId: student.studentId,
              subjectId: input.subjectId,
              title: `Prepare for ${exam.name}`,
              notes: `Exam on ${input.startsOn}. Marks entry reminder.`,
              dueOn: input.startsOn,
              priority: 'medium',
              source: 'teacher',
              status: 'todo',
            }),
          ),
        );
      }

      return exam;
    },
    {
      success: (_, vars) =>
        vars.enterMode === 'later' ? 'Exam created · Reminder added' : 'Exam created',
      failure: 'Could not create the exam',
    },
  );

  return { options, submit };
}

export interface ExamDetailData {
  exam: Exam;
  batchName: string;
  subjectId: ID | null;
  subjectName: string;
  roster: BatchRosterRow[];
  marks: Mark[];
  results: Result[];
}

export function useExamDetail(examId: ID | null) {
  const query = useDomainQuery<ExamDetailData>(
    'exams',
    ['detail', examId],
    async (b, i) => {
      const id = examId as ID;
      const exam = await b.exams.get(i, id);
      const [batchSummaries, roster, subjectPage, markPage, resultPage] = await Promise.all([
        b.batches.listSummaries(i),
        b.batches.listRoster(i, exam.batchId),
        b.subjects.list(i, { limit: 100 }),
        b.marks.list(i, { where: { examId: id }, limit: 300 }),
        b.results.list(i, { where: { examId: id }, limit: 300 }),
      ]);
      const batch = batchSummaries.find((x) => x.id === exam.batchId);
      const { subjectId, subjectName } = resolveExamSubject(exam, markPage.items, batch, subjectPage.items);
      return {
        exam,
        batchName: batch?.name ?? 'Batch',
        subjectId,
        subjectName,
        roster: [...roster].sort((a, b) => (a.rollNumber ?? 9999) - (b.rollNumber ?? 9999) || a.fullName.localeCompare(b.fullName)),
        marks: markPage.items,
        results: resultPage.items,
      };
    },
    Boolean(examId),
  );

  const saveMarks = useDomainMutation<MarkEntry[], Mark[]>(
    ['exams', 'marks', 'results'],
    async (b, i, entries) => {
      const id = examId as ID;
      const saved = await b.marks.saveMany(i, id, entries);
      await b.results.compute(i, id);
      return saved;
    },
    {
      success: (saved) => `${saved.length} marks saved`,
      failure: 'Could not save marks',
    },
  );

  const publish = useDomainMutation<void, Exam>(
    ['exams', 'marks', 'results', 'notifications', 'progress'],
    async (b, i) => b.exams.publish(i, examId as ID),
    {
      success: 'Results published · Students & parents notified',
      failure: 'Could not publish results',
    },
  );

  const stats = useMemo(() => {
    if (!query.data) return null;
    return computeExamStats(query.data.exam, query.data.marks, query.data.roster.length);
  }, [query.data]);

  return { ...query, stats, saveMarks, publish };
}
