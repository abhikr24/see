import React, { useMemo, useState } from 'react';
import { FlatList, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import {
  Badge,
  Button,
  Card,
  EmptyState,
  ErrorState,
  ListSkeleton,
  ProgressBar,
  SegmentedControl,
  Text,
} from '@/components/ui';
import { dateShort } from '@/lib/format';
import { subjectTint } from '@/lib/subject-tint';
import { C, LAYOUT, R } from '@/lib/theme';
import { useExamsWorkspace, type ExamCardView } from './hooks';
import { filterExams, pluralStudents, type ExamFilterTab } from './model';

const TAB_BAR_INSET = 136;

const FILTER_OPTIONS: { key: ExamFilterTab; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'upcoming', label: 'Upcoming' },
  { key: 'completed', label: 'Completed' },
];

function ExamCard({ item, onPress }: { item: ExamCardView; onPress: () => void }) {
  const tint = subjectTint(item.subjectName);
  const { exam, subjectName, batchName, studentCount, stats } = item;

  return (
    <Card onPress={onPress} pad={16}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <View
          style={{
            width: 46,
            height: 46,
            borderRadius: R.field,
            backgroundColor: tint.bg,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name={tint.icon} size={22} color={tint.fg} />
        </View>

        <View style={{ flex: 1, gap: 6 }}>
          <Text variant="title" weight={700} numberOfLines={1}>
            {exam.name}
          </Text>
          <Text variant="caption" c={C.secondary} numberOfLines={1} tabular>
            {subjectName} · {batchName} · {pluralStudents(studentCount)}
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 2 }}>
            <Badge label={exam.startsOn ? dateShort(exam.startsOn) : 'No date'} tone="primary" small />
            <Badge label={stats.marksState.label} tone={stats.marksState.tone} small />
          </View>
        </View>

        <Ionicons name="chevron-forward" size={18} color={C.muted} />
      </View>

      {stats.partlyEntered ? (
        <View style={{ marginTop: 12, gap: 6 }}>
          <ProgressBar value={stats.enteredPct} tone="accent" height={4} />
          <Text variant="caption" weight={600} c={C.accent} tabular>
            {stats.entered} of {stats.totalStudents} entered
          </Text>
        </View>
      ) : null}
    </Card>
  );
}

export function ExamsListScreen() {
  const { data, loading, error, refetch } = useExamsWorkspace();
  const [tab, setTab] = useState<ExamFilterTab>('all');

  const items = useMemo(() => data?.items ?? [], [data?.items]);
  const visible = useMemo(() => {
    const filteredIds = new Set(
      filterExams(
        items.map((x) => x.exam),
        tab,
      ).map((e) => e.id),
    );
    const byId = new Map(items.map((x) => [x.exam.id, x]));
    return filterExams(
      items.map((x) => x.exam),
      tab,
    )
      .filter((e) => filteredIds.has(e.id))
      .map((e) => byId.get(e.id)!);
  }, [items, tab]);

  const openCreate = () => router.push('/(owner)/exams/new' as never);

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <FlatList
        data={loading && !data ? [] : visible}
        keyExtractor={(item) => item.exam.id}
        renderItem={({ item }) => (
          <ExamCard
            item={item}
            onPress={() => router.push(`/(owner)/exams/${item.exam.id}` as never)}
          />
        )}
        refreshControl={
          <RefreshControl
            refreshing={loading && Boolean(data)}
            onRefresh={() => void refetch()}
            tintColor={C.primary}
          />
        }
        contentContainerStyle={{
          paddingHorizontal: LAYOUT.margin,
          paddingTop: 12,
          paddingBottom: TAB_BAR_INSET,
          gap: 12,
          flexGrow: 1,
        }}
        ListHeaderComponent={
          <View style={{ gap: 16, marginBottom: 4 }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 12,
              }}
            >
              <View style={{ flex: 1 }}>
                <Text variant="h2">Exams</Text>
                <Text variant="caption" c={C.secondary}>
                  Schedule tests, enter marks, and publish results.
                </Text>
              </View>
              <Button
                title="Create"
                icon="add"
                size="sm"
                full={false}
                onPress={openCreate}
              />
            </View>

            <SegmentedControl
              options={FILTER_OPTIONS}
              value={tab}
              onChange={setTab}
            />
          </View>
        }
        ListEmptyComponent={
          loading && !data ? (
            <ListSkeleton rows={4} h={96} />
          ) : error && !data ? (
            <ErrorState message={error.message} onRetry={() => void refetch()} />
          ) : (
            <EmptyState
              icon="document-text-outline"
              title={tab === 'all' ? 'No exams yet' : `No ${tab} exams`}
              text="Create an exam to schedule a test and track student marks."
              actionLabel="Create exam"
              onAction={openCreate}
            />
          )
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
