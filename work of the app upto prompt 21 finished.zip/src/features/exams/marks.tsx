import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useNavigation } from 'expo-router';
import { Button, ListSkeleton, ProgressBar, Text } from '@/components/ui';
import type { ID } from '@/core/contracts/models';
import type { MarkEntry } from '@/core/contracts/ports';
import { C, LAYOUT, R } from '@/lib/theme';
import { useExamDetail } from './hooks';
import { MarksRow } from '@/components/MarksRow';

interface DraftRow {
  marks: string;
  absent: boolean;
}

export function MarksScreen() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const examId = typeof id === 'string' && id.length > 0 ? id : null;
  const detail = useExamDetail(examId);

  const [draft, setDraft] = useState<Record<ID, DraftRow>>({});
  const [activeRowId, setActiveRowId] = useState<ID | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const listRef = useRef<FlatList>(null);

  const data = detail.data;
  const maxMarks = data?.exam.totalMarks ?? data?.marks[0]?.maxMarks ?? 100;
  const roster = data?.roster ?? [];

  useEffect(() => {
    if (data && Object.keys(draft).length === 0 && !hasUnsavedChanges) {
      const byStudent = new Map(data.marks.map((m) => [m.studentId, m]));
      const initial: Record<ID, DraftRow> = {};
      for (const student of data.roster) {
        const row = byStudent.get(student.studentId);
        initial[student.studentId] = {
          marks: row && !row.isAbsent && row.marksObtained !== null ? String(row.marksObtained) : '',
          absent: row?.isAbsent ?? false,
        };
      }
      setDraft(initial);
    }
  }, [data]);

  const enteredCount = useMemo(() => {
    return Object.values(draft).filter((r) => r.absent || r.marks.trim() !== '').length;
  }, [draft]);

  const handleUpdate = (studentId: ID, row: DraftRow) => {
    setDraft((prev) => ({ ...prev, [studentId]: row }));
    setHasUnsavedChanges(true);
  };

  const handleNext = (currentIndex: number) => {
    const nextStudent = roster[currentIndex + 1];
    if (nextStudent) {
      setActiveRowId(nextStudent.studentId);
      listRef.current?.scrollToIndex({ index: currentIndex + 1, viewPosition: 0.5, animated: true });
    }
  };

  const handleSave = async () => {
    if (!data?.subjectId) return;

    const entries: MarkEntry[] = [];
    for (const student of roster) {
      const row = draft[student.studentId] ?? { marks: '', absent: false };
      if (row.absent) {
        entries.push({
          studentId: student.studentId,
          subjectId: data.subjectId,
          marksObtained: null,
          maxMarks,
          isAbsent: true,
        });
        continue;
      }
      const trimmed = row.marks.trim();
      if (!trimmed) continue;
      const parsed = Number(trimmed);
      if (!Number.isFinite(parsed) || parsed < 0 || parsed > maxMarks) {
        return; // Validation should happen inline, but just in case
      }
      entries.push({
        studentId: student.studentId,
        subjectId: data.subjectId,
        marksObtained: parsed,
        maxMarks,
        isAbsent: false,
      });
    }

    if (entries.length === 0) return;
    const result = await detail.saveMarks.mutate(entries);
    if (result.ok) {
      setHasUnsavedChanges(false);
      router.back();
    }
  };

  const navigation = useNavigation();

  useEffect(() => {
    const unsubscribe = navigation.addListener('beforeRemove', (e: any) => {
      if (!hasUnsavedChanges) return;
      e.preventDefault();
      Alert.alert(
        'Discard changes?',
        'You have unsaved marks. Are you sure you want to leave?',
        [
          { text: 'Cancel', style: 'cancel', onPress: () => {} },
          {
            text: 'Discard',
            style: 'destructive',
            onPress: () => navigation.dispatch(e.data.action),
          },
        ]
      );
    });
    return unsubscribe;
  }, [navigation, hasUnsavedChanges]);

  const handleBack = () => {
    router.back();
  };

  const handleMarkRemainingAbsent = () => {
    setDraft((prev) => {
      const next = { ...prev };
      let changed = false;
      for (const student of roster) {
        const row = next[student.studentId] ?? { marks: '', absent: false };
        if (!row.absent && row.marks.trim() === '') {
          next[student.studentId] = { marks: '', absent: true };
          changed = true;
        }
      }
      if (changed) setHasUnsavedChanges(true);
      return next;
    });
  };

  if (detail.loading && !data) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }}>
        <View style={{ flex: 1, padding: LAYOUT.margin }}>
          <ListSkeleton rows={6} h={56} />
        </View>
      </SafeAreaView>
    );
  }

  if (!data) return null;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }}>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingHorizontal: LAYOUT.margin,
          paddingTop: 12,
          paddingBottom: 16,
          backgroundColor: C.surface,
          borderBottomWidth: 1,
          borderBottomColor: C.hairline,
        }}
      >
        <Pressable onPress={handleBack} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }} hitSlop={10}>
          <Ionicons name="chevron-back" size={24} color={C.primary} />
          <Text variant="body" weight={600} c={C.primary} numberOfLines={1} style={{ maxWidth: 180 }}>
            {data.exam.name} · {data.subjectName}
          </Text>
        </Pressable>
        <Button
          title="Save"
          size="sm"
          onPress={() => void handleSave()}
          loading={detail.saveMarks.loading}
          disabled={!hasUnsavedChanges && enteredCount === 0}
        />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ padding: LAYOUT.margin, gap: 12 }}>
          <View style={{ backgroundColor: C.surface, borderRadius: R.card, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View>
              <Text variant="body" weight={600}>{data.batchName} · Max marks {maxMarks} · {roster.length} students</Text>
            </View>
            <Ionicons name="pencil-outline" size={20} color={C.secondary} />
          </View>

          {roster.length > 0 && (
            <View style={{ gap: 6 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flex: 1, marginRight: 12 }}>
                <ProgressBar value={enteredCount / roster.length} tone="accent" height={6} />
              </View>
                <Text variant="caption" weight={600} c={C.secondary} tabular>{enteredCount} of {roster.length} entered</Text>
              </View>
            </View>
          )}
        </View>

        <View style={{ flexDirection: 'row', paddingHorizontal: LAYOUT.margin, paddingBottom: 8 }}>
          <Text variant="label" c={C.muted} style={{ flex: 1, fontSize: 11, textTransform: 'uppercase' }}>STUDENT</Text>
          <Text variant="label" c={C.muted} style={{ width: 72, textAlign: 'center', fontSize: 11, textTransform: 'uppercase' }}>MARKS</Text>
        </View>

        <FlatList
          ref={listRef}
          data={roster}
          keyExtractor={(item) => item.studentId}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: 40 }}
          onScrollToIndexFailed={(info) => {
            setTimeout(() => {
              listRef.current?.scrollToIndex({ index: info.index, animated: true });
            }, 50);
          }}
          renderItem={({ item, index }) => (
            <MarksRow
              student={item}
              draft={draft[item.studentId] ?? { marks: '', absent: false }}
              maxMarks={maxMarks}
              isActive={activeRowId === item.studentId}
              onFocus={() => setActiveRowId(item.studentId)}
              onChange={(updated) => handleUpdate(item.studentId, updated)}
              onSubmit={() => handleNext(index)}
              isLast={index === roster.length - 1}
            />
          )}
          ListFooterComponent={
            roster.length > 0 && enteredCount < roster.length ? (
              <Pressable
                onPress={handleMarkRemainingAbsent}
                style={{
                  marginTop: 16,
                  paddingVertical: 12,
                  alignItems: 'center',
                }}
              >
                <Text variant="body" weight={600} c={C.primary}>Mark remaining as absent</Text>
              </Pressable>
            ) : null
          }
        />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
