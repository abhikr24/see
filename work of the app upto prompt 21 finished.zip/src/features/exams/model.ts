import { getExamValidationErrors, validateNewExam, EXAM_MAX_PAST_DAYS } from '@/core/contracts/exam-validation';
import type { BatchSummary, Exam, ID, Mark, Subject } from '@/core/contracts/models';

export { getExamValidationErrors, validateNewExam, EXAM_MAX_PAST_DAYS };

export type ExamFilterTab = 'all' | 'upcoming' | 'completed';

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDaysIso(iso: string, days: number): string {
  const dt = new Date(`${iso}T00:00:00Z`);
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

export function examPhase(exam: Exam, today: string = todayIso()): 'upcoming' | 'completed' {
  if (exam.status === 'published' || exam.status === 'completed') return 'completed';
  if (exam.startsOn && exam.startsOn < today) return 'completed';
  return 'upcoming';
}

export function filterExams(exams: Exam[], tab: ExamFilterTab, today: string = todayIso()): Exam[] {
  const list = tab === 'all' ? exams : exams.filter((e) => examPhase(e, today) === tab);
  return [...list].sort((a, b) => {
    const ad = a.startsOn ?? a.createdAt.slice(0, 10);
    const bd = b.startsOn ?? b.createdAt.slice(0, 10);
    return bd.localeCompare(ad) || b.createdAt.localeCompare(a.createdAt);
  });
}

export function resolveExamSubject(
  exam: Exam,
  examMarks: Mark[],
  batch: BatchSummary | undefined,
  subjects: Subject[],
): { subjectId: ID | null; subjectName: string } {
  const byId = new Map(subjects.map((s) => [s.id, s]));
  const id = exam.subjectId ?? examMarks[0]?.subjectId ?? batch?.subjectId ?? subjects[0]?.id ?? null;
  if (id && byId.has(id)) {
    return { subjectId: id, subjectName: byId.get(id)!.name };
  }
  return { subjectId: id, subjectName: batch?.subjectName && batch.subjectName !== '—' ? batch.subjectName : 'General' };
}

export interface ExamStats {
  entered: number;
  totalStudents: number;
  partlyEntered: boolean;
  enteredPct: number;
  averagePct: number | null;
  highestMarks: number | null;
  marksState: { label: string; tone: 'teal' | 'warning' };
}

export function computeExamStats(exam: Exam, examMarks: Mark[], totalStudents: number): ExamStats {
  const enteredRows = examMarks.filter((m) => m.marksObtained !== null || m.isAbsent);
  const entered = new Set(enteredRows.map((m) => m.studentId)).size;
  const maxMarks = exam.totalMarks ?? examMarks[0]?.maxMarks ?? 100;

  const scored = enteredRows.filter((m) => !m.isAbsent && m.marksObtained !== null);
  let averagePct: number | null = null;
  let highestMarks: number | null = null;
  if (scored.length > 0) {
    const pctSum = scored.reduce((acc, m) => acc + ((m.marksObtained ?? 0) / (m.maxMarks || maxMarks || 100)) * 100, 0);
    averagePct = Math.round(pctSum / scored.length);
    highestMarks = Math.max(...scored.map((m) => m.marksObtained ?? 0));
  }

  const partlyEntered = entered > 0 && totalStudents > 0 && entered < totalStudents;
  const enteredPct = totalStudents > 0 ? Math.min(100, Math.round((entered / totalStudents) * 100)) : 0;

  let marksState: { label: string; tone: 'teal' | 'warning' };
  if (exam.status === 'published') {
    marksState = { label: 'Published', tone: 'teal' };
  } else if (totalStudents > 0 && entered >= totalStudents) {
    marksState = { label: 'Marks entered', tone: 'teal' };
  } else if (entered > 0) {
    marksState = { label: `${entered}/${totalStudents} entered`, tone: 'warning' };
  } else {
    marksState = { label: 'Marks pending', tone: 'warning' };
  }

  return {
    entered,
    totalStudents,
    partlyEntered,
    enteredPct,
    averagePct,
    highestMarks,
    marksState,
  };
}

export function pluralStudents(count: number): string {
  return `${count} ${count === 1 ? 'student' : 'students'}`;
}
