import React, { useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Button, Card, DateField, ErrorState, Input, ListSkeleton, Select, Text } from '@/components/ui';
import type { ExamValidationErrors } from '@/core/contracts/exam-validation';
import { C, LAYOUT, R } from '@/lib/theme';
import { useCreateExam } from './hooks';
import { addDaysIso, EXAM_MAX_PAST_DAYS, getExamValidationErrors, pluralStudents, todayIso } from './model';

const TAB_BAR_INSET = 136;

const ENTER_CHOICES = [
  { key: 'now', title: 'Now', sub: 'Opens marks entry', icon: 'create-outline' },
  { key: 'later', title: 'Later, remind me', sub: 'Creates a study task reminder', icon: 'alarm-outline' },
] as const;

export function ExamCreateScreen() {
  const { options, submit } = useCreateExam();
  const batches = useMemo(() => options.data?.batches ?? [], [options.data]);
  const subjects = useMemo(() => options.data?.subjects ?? [], [options.data]);

  const [name, setName] = useState('');
  const [subjectId, setSubjectId] = useState('');
  const [batchId, setBatchId] = useState('');
  const [startsOn, setStartsOn] = useState(todayIso);
  const [maxMarksText, setMaxMarksText] = useState('100');
  const [enterMode, setEnterMode] = useState<'now' | 'later'>('now');
  const [errors, setErrors] = useState<ExamValidationErrors>({});

  const effectiveBatchId = batchId || batches[0]?.id || '';
  const effectiveSubjectId =
    subjectId || batches.find((b) => b.id === effectiveBatchId)?.subjectId || subjects[0]?.id || '';

  const minDate = useMemo(() => addDaysIso(todayIso(), -EXAM_MAX_PAST_DAYS), []);
  const subjectOptions = useMemo(() => subjects.map((s) => ({ value: s.id, label: s.name, badge: s.code })), [subjects]);
  const batchOptions = useMemo(
    () => batches.map((b) => ({
      value: b.id,
      label: b.name,
      subtitle: `${b.subjectName} · ${pluralStudents(b.studentCount)}`,
      badge: String(b.studentCount),
    })),
    [batches],
  );

  const handleBatchChange = (id: string) => {
    setBatchId(id);
    setErrors((e) => ({ ...e, batchId: undefined }));
    const batch = batches.find((b) => b.id === id);
    if (batch?.subjectId) setSubjectId(batch.subjectId);
  };

  const handleSubmit = async () => {
    const parsedMarks = Number(maxMarksText);
    const nextErrors = getExamValidationErrors(
      {
        name,
        batchId: effectiveBatchId,
        subjectId: effectiveSubjectId,
        startsOn,
        totalMarks: maxMarksText.trim() === '' ? null : parsedMarks,
      },
      todayIso(),
      true,
    );
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    const result = await submit.mutate({
      name: name.trim(),
      subjectId: effectiveSubjectId,
      batchId: effectiveBatchId,
      startsOn,
      totalMarks: parsedMarks,
      enterMode,
    });
    if (!result.ok) return;

    if (enterMode === 'now') {
      router.replace(`/(owner)/exams/${result.data.id}/marks` as never);
    } else {
      router.replace('/(owner)/exams' as never);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.canvas }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: TAB_BAR_INSET, gap: 16 }}
        showsVerticalScrollIndicator={false}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Back to exams"
          onPress={() => router.back()}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
        >
          <Ionicons name="chevron-back" size={20} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>Exams</Text>
        </Pressable>

        <View>
          <Text variant="h2">Create exam</Text>
          <Text variant="caption" c={C.secondary}>Set up an assessment for a batch and choose when to enter marks.</Text>
        </View>

        {options.loading && !options.data ? (
          <ListSkeleton rows={4} h={64} />
        ) : options.error && !options.data ? (
          <ErrorState message={options.error.message} onRetry={() => void options.refetch()} />
        ) : (
          <>
            <Input
              label="Exam name"
              value={name}
              onChangeText={(v) => { setName(v); setErrors((e) => ({ ...e, name: undefined })); }}
              placeholder="e.g. Unit Test 4"
              error={errors.name}
              returnKeyType="next"
            />
            <Select
              label="Subject"
              options={subjectOptions}
              value={effectiveSubjectId}
              onChange={(v) => { setSubjectId(v); setErrors((e) => ({ ...e, subjectId: undefined })); }}
              placeholder="Choose subject"
              error={errors.subjectId}
            />
            <Select
              label="Batch"
              options={batchOptions}
              value={effectiveBatchId}
              onChange={handleBatchChange}
              placeholder="Choose batch"
              error={errors.batchId}
            />
            <DateField
              label="Date"
              value={startsOn}
              minDate={minDate}
              onChange={(_, iso) => { setStartsOn(iso); setErrors((e) => ({ ...e, startsOn: undefined })); }}
              error={errors.startsOn}
              hint="Up to 30 days in the past or any upcoming date."
            />

            <View style={{ gap: 6 }}>
              <Text variant="label" c={C.secondary}>Max marks</Text>
              <View
                style={{
                  backgroundColor: C.surface,
                  borderRadius: R.card,
                  borderWidth: 1,
                  borderColor: errors.totalMarks ? C.danger : C.hairline,
                  paddingHorizontal: 18,
                  paddingVertical: 14,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}
              >
                <TextInput
                  accessibilityLabel="Max marks"
                  value={maxMarksText}
                  onChangeText={(v) => { setMaxMarksText(v.replace(/[^0-9]/g, '')); setErrors((e) => ({ ...e, totalMarks: undefined })); }}
                  keyboardType="number-pad"
                  placeholder="100"
                  placeholderTextColor={C.muted}
                  style={{ flex: 1, fontSize: 32, fontWeight: '800', fontVariant: ['tabular-nums'], color: C.ink, paddingVertical: 0 }}
                />
                <Text variant="caption" weight={600} c={C.muted}>marks (1–500)</Text>
              </View>
              {errors.totalMarks ? <Text variant="caption" c={C.danger}>{errors.totalMarks}</Text> : null}
            </View>

            <View style={{ gap: 8 }}>
              <Text variant="label" c={C.secondary}>Enter marks</Text>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                {ENTER_CHOICES.map((choice) => {
                  const active = enterMode === choice.key;
                  return (
                    <Pressable
                      key={choice.key}
                      accessibilityRole="radio"
                      accessibilityState={{ selected: active }}
                      onPress={() => setEnterMode(choice.key)}
                      style={{
                        flex: 1,
                        padding: 14,
                        borderRadius: R.btn,
                        backgroundColor: active ? C.navySoft : C.surface,
                        borderWidth: active ? 2 : 1,
                        borderColor: active ? C.primary : C.hairline,
                        gap: 6,
                      }}
                    >
                      <Ionicons name={choice.icon} size={20} color={active ? C.primary : C.secondary} />
                      <Text variant="body" weight={700} c={active ? C.primary : C.ink}>{choice.title}</Text>
                      <Text variant="caption" c={C.secondary}>{choice.sub}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>

            <Card flat tint={C.navySoft} pad={14}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <Ionicons name="information-circle-outline" size={20} color={C.primary} />
                <Text variant="caption" weight={600} c={C.primary} style={{ flex: 1 }}>
                  Students and parents will be notified when results are published.
                </Text>
              </View>
            </Card>

            <Button
              title={enterMode === 'now' ? 'Create & enter marks' : 'Create exam'}
              onPress={() => void handleSubmit()}
              loading={submit.loading}
            />
          </>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
