/**
 * The student's own results.
 *
 * It reads the same `ResultRepo.analysis` the owner's analysis screen reads,
 * so the class average, the highest, the lowest, the pass rate, the ranks and
 * the subject averages are the same numbers on both screens.
 */

import React, { useMemo, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, View } from 'react-native';

import { Card, EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import type { ID } from '@/core/contracts/models';
import { dateShort } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { useExamAnalysis, useStudentExamList, type StudentExamRow } from './analysis-hooks';
import { AnalysisSections } from './analysis-view';

const TAB_BAR_INSET = 136;

function ExamPicker({
  rows,
  selectedId,
  onSelect,
}: {
  rows: StudentExamRow[];
  selectedId: ID | null;
  onSelect: (examId: ID) => void;
}) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ gap: 8, paddingRight: LAYOUT.margin }}
    >
      {rows.map((row) => {
        const active = row.examId === selectedId;
        return (
          <Pressable
            key={`${row.examId}-${row.studentId}`}
            onPress={() => onSelect(row.examId)}
            style={({ pressed }) => ({
              paddingHorizontal: 14,
              paddingVertical: 10,
              borderRadius: R.field,
              backgroundColor: active ? C.primary : C.surface,
              borderWidth: 1,
              borderColor: active ? C.primary : C.hairline,
              opacity: pressed ? 0.9 : 1,
              gap: 2,
            })}
          >
            <Text variant="caption" weight={700} c={active ? C.surface : C.ink} numberOfLines={1}>
              {row.name}
            </Text>
            <Text variant="label" c={active ? C.navyPale : C.muted} tabular>
              {row.percentage.toFixed(1)}% · {dateShort(row.date)}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

/** The student's own line: marks, rank and the class average beside it. */
function YourResultCard({
  row,
  rank,
  scoredCount,
  averagePct,
}: {
  row: StudentExamRow;
  rank: number | null;
  scoredCount: number;
  averagePct: number | null;
}) {
  return (
    <Card flat pad={16} style={{ gap: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Text variant="label" c={C.muted}>
          Your result
        </Text>
        <Text variant="caption" c={C.muted} tabular>
          {row.studentName}
        </Text>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10 }}>
        <Text variant="title" weight={800} tabular style={{ fontSize: 20 }}>
          {row.marksObtained}/{row.maxMarks}
        </Text>
        <Text variant="caption" c={C.secondary} tabular style={{ paddingBottom: 2 }}>
          {row.percentage.toFixed(1)}%
        </Text>
      </View>

      <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
        <View style={{ backgroundColor: C.navySoft, paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.chip }}>
          <Text variant="label" weight={700} c={C.primary} tabular>
            Rank {rank ?? '—'} of {scoredCount}
          </Text>
        </View>
        <View style={{ backgroundColor: C.tealSoft, paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.chip }}>
          <Text variant="label" weight={700} c={C.teal} tabular>
            Class average {averagePct === null ? '—' : `${averagePct.toFixed(1)}%`}
          </Text>
        </View>
      </View>
    </Card>
  );
}

export function StudentResultsScreen() {
  const list = useStudentExamList();
  const [selectedId, setSelectedId] = useState<ID | null>(null);

  const rows = useMemo(() => list.data ?? [], [list.data]);
  const exams = useMemo(() => {
    const seen = new Set<ID>();
    return rows.filter((row) => (seen.has(row.examId) ? false : (seen.add(row.examId), true)));
  }, [rows]);
  const activeId = selectedId ?? exams[0]?.examId ?? null;
  const analysis = useExamAnalysis(activeId);

  const myRow = rows.find((row) => row.examId === activeId) ?? null;
  const myAnalysisRow = analysis.data?.students.find((row) => row.studentId === myRow?.studentId) ?? null;

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={list.loading && Boolean(list.data)}
            onRefresh={() => void list.refetch()}
            tintColor={C.primary}
          />
        }
        contentContainerStyle={{
          padding: LAYOUT.margin,
          paddingBottom: TAB_BAR_INSET,
          gap: 16,
          flexGrow: 1,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ gap: 4 }}>
          <Text variant="h2" weight={800}>
            Results
          </Text>
          <Text variant="caption" c={C.secondary}>
            Your marks and how the class did in the same exam.
          </Text>
        </View>

        {list.loading && !list.data ? (
          <ListSkeleton rows={3} h={80} />
        ) : list.error && !list.data ? (
          <ErrorState message={list.error.message} onRetry={() => void list.refetch()} />
        ) : rows.length === 0 ? (
          <EmptyState
            icon="ribbon-outline"
            title="No results yet"
            text="Results appear here once your institute publishes an exam."
          />
        ) : (
          <>
            <ExamPicker rows={exams} selectedId={activeId} onSelect={setSelectedId} />

            {analysis.loading && !analysis.data ? (
              <ListSkeleton rows={4} h={96} />
            ) : analysis.error && !analysis.data ? (
              <ErrorState message={analysis.error.message} onRetry={() => void analysis.refetch()} />
            ) : analysis.data ? (
              <>
                {myRow ? (
                  <YourResultCard
                    row={myRow}
                    rank={myAnalysisRow?.rank ?? myRow.rank}
                    scoredCount={analysis.data.scoredCount}
                    averagePct={analysis.data.averagePct}
                  />
                ) : null}
                <AnalysisSections analysis={analysis.data} highlightStudentId={myRow?.studentId} />
              </>
            ) : null}
          </>
        )}
      </ScrollView>
    </View>
  );
}
