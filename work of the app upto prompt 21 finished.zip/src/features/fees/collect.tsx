import React, { useEffect, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Text, Button } from '@/components/ui';
import { usePayments, useReceipts, toast } from '@/core/backend';
import { C } from '@/lib/theme';
import { useFeeOverview } from './collection-hooks';
import { Avatar, PageHeader, State, card, money } from './ui';
import type { DueRow } from '@/core/contracts/fee-collection';

export default function CollectScreen() {
  const { installmentId } = useLocalSearchParams<{ installmentId?: string }>();
  const { data, loading, error, refetch } = useFeeOverview();
  const { record, saving } = usePayments();
  const { issue } = useReceipts();
  const [selected, setSelected] = useState<DueRow | null>(null);
  const [search, setSearch] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'upi' | 'cash' | 'card'>('upi');
  const [reference, setReference] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const choose = (row: DueRow) => { setSelected(row); setAmount((row.amount / 100).toFixed(2).replace(/\.00$/, '')); };
  useEffect(() => { if (data && installmentId && !selected) { const found = data.dues.find(x => x.id === installmentId); if (found) queueMicrotask(() => choose(found)); } }, [data, installmentId, selected]);
  const value = Math.round(Number(amount) * 100);
  const validDate = /^\d{4}-\d{2}-\d{2}$/.test(date) && !isNaN(Date.parse(date)) && date <= new Date().toISOString().slice(0, 10);
  const canSave = selected && Number.isSafeInteger(value) && value > 0 && value <= selected.amount && (method !== 'upi' || Boolean(reference.trim())) && validDate;
  const save = async () => {
    if (!selected || !canSave || saving) return;
    const result = await record({ studentId: selected.studentId, studentFeeId: selected.studentFeeId, installmentId: selected.id, amount: value / 100, method, referenceNo: method === 'cash' ? null : reference.trim() || null, paidAt: `${date}T12:00:00.000Z`, status: 'completed' });
    if (!result.ok) return;
    const receipt = await issue(result.data.id);
    if (receipt.ok) router.replace({ pathname: '/(owner)/fees/receipt', params: { id: receipt.data.id } } as never);
    else toast.error('Payment saved. Open Recent payments to retrieve the receipt.');
  };
  return <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}><PageHeader title="Collect fee" back />
    <State loading={loading && !data} error={error} retry={refetch} label="No open dues" empty={Boolean(data && !data.dues.some(x => x.amount > 0))}/>
    {data && <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
      {!selected ? <View style={{ flex: 1, paddingHorizontal: 20 }}><TextInput placeholder="Search student" value={search} onChangeText={setSearch} style={[card, { fontSize: 16, marginBottom: 10, color: C.ink }]} placeholderTextColor={C.muted}/><FlatList data={data.dues.filter(x => x.amount > 0 && x.name.toLowerCase().includes(search.toLowerCase()))} keyExtractor={x => x.id} renderItem={({ item }) => <Pressable onPress={() => choose(item)} style={{ flexDirection: 'row', gap: 12, alignItems: 'center', padding: 16, borderBottomWidth: 1, borderColor: C.hairline }}><Avatar name={item.name} photo={item.photoUrl}/><View style={{ flex: 1 }}><Text weight={700}>{item.name}</Text><Text variant="caption" c={C.secondary}>{item.batch} · {item.term}</Text></View><Text c={C.danger} tabular weight={700}>{money(item.amount)}</Text></Pressable>} ListEmptyComponent={<State loading={false} retry={refetch} empty label="No matching students"/>}/></View> :
      <FlatList data={[selected]} keyExtractor={x => x.id} contentContainerStyle={{ padding: 20, paddingBottom: 42 }} renderItem={() => <View style={{ gap: 21 }}>
        <Pressable onPress={() => setSelected(null)} style={[card, { flexDirection: 'row', alignItems: 'center', gap: 12 }]}><Avatar name={selected.name} photo={selected.photoUrl}/><View style={{ flex: 1 }}><Text weight={700}>{selected.name}</Text><Text variant="caption" c={C.secondary}>{selected.batch} · {selected.term}</Text></View><Text variant="caption" c={C.danger} style={{ backgroundColor: C.dangerSoft, padding: 8, borderRadius: 20 }}>Due {money(selected.amount)}</Text></Pressable>
        <View><Text variant="label" c={C.secondary}>AMOUNT TO COLLECT</Text><View style={{ flexDirection: 'row', alignItems: 'center', borderBottomWidth: 2, borderColor: C.primary, paddingVertical: 8 }}><Text style={{ fontSize: 42, fontWeight: '800' }}>₹</Text><TextInput accessibilityLabel="Amount in rupees" keyboardType="decimal-pad" value={amount} onChangeText={setAmount} selectTextOnFocus style={{ fontSize: 42, fontWeight: '800', color: C.ink, flex: 1, fontVariant: ['tabular-nums'] }}/></View>{value > selected.amount && <Text variant="caption" c={C.danger}>Amount exceeds the due balance</Text>}</View>
        <View><Text variant="label" c={C.secondary}>PAYMENT METHOD</Text><View style={{ flexDirection: 'row', gap: 9, marginTop: 11 }}>{(['upi', 'cash', 'card'] as const).map(x => <Pressable key={x} onPress={() => setMethod(x)} style={{ flex: 1, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: method === x ? C.primary : C.hairline, backgroundColor: method === x ? C.navySoft : C.surface, borderRadius: 30 }}><Text weight={700} c={method === x ? C.primary : C.secondary}>{x.toUpperCase()}</Text></Pressable>)}</View></View>
        {method !== 'cash' && <View><Text variant="label" c={C.secondary}>{method === 'upi' ? 'UTR REFERENCE *' : 'CARD REFERENCE'}</Text><TextInput value={reference} onChangeText={setReference} placeholder="Enter transaction reference" placeholderTextColor={C.muted} autoCapitalize="characters" style={[card, { marginTop: 10, color: C.ink, fontSize: 16 }]} /></View>}
        <View><Text variant="label" c={C.secondary}>DATE · YYYY-MM-DD</Text><TextInput value={date} onChangeText={setDate} keyboardType="numbers-and-punctuation" style={[card, { marginTop: 10, color: C.ink, fontSize: 16 }]} />{!validDate && <Text variant="caption" c={C.danger}>Enter a valid date, not in the future</Text>}</View>
        <View style={[card, { borderTopWidth: 2, borderStyle: 'dashed', gap: 9 }]}><Text variant="label" c={C.secondary}>LIVE RECEIPT PREVIEW</Text><Text variant="h2" tabular>{money(Number.isFinite(value) ? value : 0)}</Text><Text variant="caption" c={C.secondary}>{selected.name} · {selected.term} · {method.toUpperCase()}</Text><Text variant="caption" c={C.secondary}>{date} · {reference || 'Reference not provided'}</Text></View>
        <Button title={`Confirm ${money(Number.isFinite(value) ? value : 0)}`} onPress={save} disabled={!canSave} loading={saving}/>
      </View>} />}
    </KeyboardAvoidingView>}
  </SafeAreaView>;
}
