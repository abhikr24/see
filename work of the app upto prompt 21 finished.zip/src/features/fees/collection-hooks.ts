import { useDomainQuery } from '@/core/hooks/domain';
import type { FeeOverview } from '@/core/contracts/fee-collection';
import type { ReceiptDocument } from './receipt-document';
import { dateShort } from '@/lib/format';
export function useFeeOverview() {
  return useDomainQuery<FeeOverview>('fees', ['collection-overview'], (backend, instituteId) => backend.fees.totals(instituteId));
}
export function useReceiptDetail(id: string) {
  return useDomainQuery<{ document: ReceiptDocument; phone: string | null }>('receipts', ['detail', id], async (backend, instituteId) => {
    const receipt = await backend.receipts.get(instituteId, id);
    const [payment, institute, overview] = await Promise.all([
      backend.payments.get(instituteId, receipt.paymentId), backend.institutes.get(instituteId), backend.fees.totals(instituteId),
    ]);
    const row = overview.dues.find(x => x.id === payment.installmentId);
    return { document: { institute, receiptNo: receipt.receiptNo, amount: receipt.amount,
      student: row?.name ?? 'Student', term: row?.term ?? 'Fee', date: dateShort(payment.paidAt), method: payment.method }, phone: row?.phone ?? null };
  }, Boolean(id));
}
