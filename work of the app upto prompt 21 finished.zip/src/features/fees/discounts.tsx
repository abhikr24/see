import React from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Avatar, Card, SegmentedControl, Text } from '@/components/ui';
import { discountValue } from '@/core/contracts/fee-plan';
import type { PlanDiscount, PlanStudentRow } from '@/core/contracts/models';
import { inr } from '@/lib/format';
import { C, R } from '@/lib/theme';
import { AmountInput } from './fields';
import { NO_OUTLINE } from './web';
import { BottomPanel } from './panel';
import { AddRow } from './structures';
import type { DiscountDraft, PlanAction } from './plan-model';
import { parseMoney } from './plan-model';

type Dispatch = (action: PlanAction) => void;

const sameRow = (a: DiscountDraft, b: PlanDiscount): boolean =>
  a.label.trim() === b.label && a.type === b.type && parseMoney(a.amount) === b.amount && a.note.trim() === b.note;

/** One discount / scholarship: label, type, amount, note, and who has it. */
export function DiscountRow({
  row,
  error,
  saved,
  assigned,
  onAssign,
  dispatch,
}: {
  row: DiscountDraft;
  error?: string;
  /** The saved version of this row, if the plan already has it. */
  saved?: PlanDiscount;
  assigned: number;
  onAssign: () => void;
  dispatch: Dispatch;
}) {
  const patch = (p: Partial<DiscountDraft>) => dispatch({ type: 'discount', id: row.id, patch: p });
  const canAssign = Boolean(saved) && saved !== undefined && sameRow(row, saved);
  return (
    <Card pad={14} style={{ gap: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <TextInput
          accessibilityLabel="Discount name"
          value={row.label}
          onChangeText={(label) => patch({ label })}
          placeholder="e.g. Merit scholarship"
          placeholderTextColor={C.muted}
          style={[{ flex: 1, minWidth: 0, fontSize: 17, fontWeight: '700', color: C.ink, paddingVertical: 2 }, NO_OUTLINE]}
        />
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Remove ${row.label || 'discount'}`}
          hitSlop={10}
          onPress={() => dispatch({ type: 'removeDiscount', id: row.id })}
        >
          <Ionicons name="close-circle" size={20} color={C.muted} />
        </Pressable>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <View style={{ flex: 1 }}>
          <SegmentedControl<PlanDiscount['type']>
            size="sm"
            options={[
              { key: 'percent', label: 'Percent' },
              { key: 'flat', label: 'Flat ₹' },
            ]}
            value={row.type}
            onChange={(type) => patch({ type })}
          />
        </View>
        <AmountInput
          label={`${row.label || 'Discount'} amount`}
          value={row.amount}
          onChange={(amount) => patch({ amount })}
          prefix={row.type === 'percent' ? '%' : '₹'}
          error={Boolean(error)}
          width={104}
          height={48}
        />
      </View>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
          height: 44,
          paddingHorizontal: 12,
          borderRadius: R.field,
          backgroundColor: C.canvas,
          borderWidth: 1,
          borderColor: C.hairline,
        }}
      >
        <Ionicons name="create-outline" size={16} color={C.muted} />
        <TextInput
          accessibilityLabel="Note"
          value={row.note}
          onChangeText={(note) => patch({ note })}
          placeholder="Note (optional), e.g. Topper of Class 9"
          placeholderTextColor={C.muted}
          style={[{ flex: 1, minWidth: 0, fontSize: 13, color: C.ink, paddingVertical: 0 }, NO_OUTLINE]}
        />
      </View>
      {error ? (
        <Text variant="caption" c={C.danger}>
          {error}
        </Text>
      ) : null}
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ disabled: !canAssign }}
        disabled={!canAssign}
        onPress={onAssign}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 8, opacity: canAssign ? 1 : 0.55 }}
      >
        <Ionicons name="people-outline" size={18} color={C.primary} />
        <Text variant="caption" weight={700} c={C.primary}>
          {canAssign ? 'Choose students' : 'Save the plan to choose students'}
        </Text>
        {canAssign && assigned > 0 ? (
          <Text variant="caption" c={C.secondary}>
            · {assigned} student{assigned === 1 ? '' : 's'}
          </Text>
        ) : null}
      </Pressable>
    </Card>
  );
}

/** Who has this discount, with a switch per student. Each tap saves that student's override. */
export function AssignSheet({
  discount,
  students,
  busyId,
  onClose,
  onToggle,
}: {
  discount: PlanDiscount | null;
  students: PlanStudentRow[];
  busyId: string | null;
  onClose: () => void;
  onToggle: (student: PlanStudentRow, next: string[]) => void;
}) {
  return (
    <BottomPanel
      visible={discount !== null}
      title={discount?.label || 'Discount'}
      subtitle="Lowers only the chosen student's due. The batch plan total does not change."
      onClose={onClose}
    >
      {discount
        ? students.map((s) => {
            const on = s.discountIds.includes(discount.id);
            const hasFee = s.onPlan;
            const off = discountValue(discount, s.gross);
            return (
              <Pressable
                key={s.studentId}
                accessibilityRole="switch"
                accessibilityState={{ checked: on, disabled: !hasFee || busyId !== null }}
                accessibilityLabel={`${s.fullName}, ${on ? 'has' : 'does not have'} ${discount.label}`}
                disabled={!hasFee || busyId !== null}
                onPress={() =>
                  onToggle(s, on ? s.discountIds.filter((id) => id !== discount.id) : [...s.discountIds, discount.id])
                }
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 12,
                  minHeight: 64,
                  padding: 12,
                  borderRadius: R.btn,
                  borderWidth: on ? 2 : 1,
                  borderColor: on ? C.teal : C.hairline,
                  backgroundColor: on ? C.tealSoft : C.surface,
                  opacity: hasFee ? 1 : 0.5,
                }}
              >
                <Avatar name={s.fullName} size={40} />
                <View style={{ flex: 1, gap: 2 }}>
                  <Text variant="body" weight={600}>
                    {s.fullName}
                  </Text>
                  <Text variant="caption" c={C.secondary} tabular>
                    {hasFee
                      ? `Roll ${s.rollNumber ?? '—'} · owes ${inr(s.net)}${on ? '' : ` → ${inr(Math.max(0, s.net - off))}`}`
                      : s.onVersion === null
                        ? 'No fee yet'
                        : 'Paid on an older fee, not on this plan'}
                  </Text>
                </View>
                <Ionicons
                  name={busyId === s.studentId ? 'time-outline' : on ? 'checkmark-circle' : 'ellipse-outline'}
                  size={24}
                  color={on ? C.teal : C.muted}
                />
              </Pressable>
            );
          })
        : null}
    </BottomPanel>
  );
}

/** The discount block of the form: rows, the add row and the helper line. */
export function DiscountSection({
  rows,
  errors,
  saved,
  students,
  dispatch,
  onAssign,
}: {
  rows: DiscountDraft[];
  errors: Record<string, string>;
  saved: PlanDiscount[];
  students: PlanStudentRow[];
  dispatch: Dispatch;
  onAssign: (id: string) => void;
}) {
  return (
    <View style={{ gap: 12 }}>
      {rows.length === 0 ? (
        <Text variant="caption" c={C.secondary}>
          Add a discount or scholarship, then choose which students get it.
        </Text>
      ) : null}
      {rows.map((row) => (
        <DiscountRow
          key={row.id}
          row={row}
          error={errors[row.id]}
          saved={saved.find((d) => d.id === row.id)}
          assigned={students.filter((s) => s.discountIds.includes(row.id)).length}
          onAssign={() => onAssign(row.id)}
          dispatch={dispatch}
        />
      ))}
      <AddRow
        label="Add discount or scholarship"
        onPress={() => dispatch({ type: 'addDiscount' })}
      />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Ionicons name="flash-outline" size={16} color={C.teal} />
        <Text variant="caption" c={C.secondary}>
          Students see this instantly in their Fees tab.
        </Text>
      </View>
    </View>
  );
}
