import React, { useState } from 'react';
import { FlatList, Linking, Pressable, View } from 'react-native';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Text } from '@/components/ui';
import { toast } from '@/core/backend';
import { C } from '@/lib/theme';
import { useFeeOverview } from './collection-hooks';
import { Avatar, PageHeader, State, money } from './ui';
import type { DueRow } from '@/core/contracts/fee-collection';

async function remind(row: DueRow) {
  if (!row.phone) { toast.error(`No parent phone for ${row.name}`); return false; }
  const text = `Hello, this is a reminder that ${row.term} for ${row.name} at ${row.batch} has ${money(row.amount)} outstanding. Please contact the institute to pay. Thank you.`;
  const url = `https://wa.me/${row.phone.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
  if (!(await Linking.canOpenURL(url))) { toast.error('WhatsApp link could not be opened'); return false; }
  await Linking.openURL(url); return true;
}
export default function DuesScreen() {
  const { data, loading, error, refetch } = useFeeOverview();
  const [tab, setTab] = useState<DueRow['state']>('overdue');
  const [reminding, setReminding] = useState(false);
  const rows = data?.dues.filter(x => x.state === tab) ?? [];
  const bulk = async () => {
    if (reminding) return;
    const targets = data?.dues.filter(x => x.state === 'overdue' && x.phone) ?? [];
    if (!targets.length) { toast.error('No parent numbers available'); return; }
    setReminding(true);
    for (let i = 0; i < targets.length; i++) {
      toast.success(`Opening reminder ${i + 1} of ${targets.length}`);
      try { await remind(targets[i]); } catch { toast.error(`Could not open ${targets[i].name}`); }
    }
    setReminding(false); toast.success('Reminders opened');
  };
  return <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
    <PageHeader title="Dues" back />
    <State loading={loading && !data} error={error} retry={refetch} label="No fee records yet" empty={Boolean(data && !data.dues.length)}/>
    {data && <FlatList data={rows} keyExtractor={x => x.id} refreshing={loading} onRefresh={refetch} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}
      ListHeaderComponent={<View>
        <View style={{ backgroundColor: C.primary, borderRadius: 20, padding: 20, flexDirection: 'row', alignItems: 'center', gap: 12 }}><View style={{ flex: 1 }}><Text variant="caption" c={C.navyPale}>{data.totals.overdueCount} OVERDUE</Text><Text c={C.surface} style={{ fontSize: 27, fontWeight: '800', fontVariant: ['tabular-nums'] }}>{money(data.totals.overdue)}</Text></View><Pressable disabled={reminding} onPress={bulk} style={{ backgroundColor: C.surface, padding: 10, borderRadius: 12 }}><Text variant="caption" weight={700} c={C.primary}>{reminding ? 'Opening…' : 'Remind all'}</Text></Pressable></View>
        <View style={{ flexDirection: 'row', backgroundColor: C.track, borderRadius: 14, padding: 4, marginTop: 22, marginBottom: 10 }}>{(['overdue', 'pending', 'cleared'] as const).map(x => <Pressable key={x} onPress={() => setTab(x)} style={{ flex: 1, padding: 12, alignItems: 'center', backgroundColor: tab === x ? C.surface : C.transparent, borderRadius: 11 }}><Text variant="caption" weight={700} c={tab === x ? C.primary : C.secondary}>{x[0].toUpperCase()+x.slice(1)}</Text></Pressable>)}</View>
      </View>}
      ListEmptyComponent={<State loading={false} retry={refetch} empty label={`No ${tab} dues`} />}
      renderItem={({ item }) => <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 15, borderBottomWidth: 1, borderColor: C.hairline }}><Avatar name={item.name} photo={item.photoUrl}/><Pressable onPress={() => router.push({ pathname: '/(owner)/students/[id]', params: { id: item.studentId } } as never)} style={{ flex: 1 }}><Text weight={700}>{item.name}</Text><Text variant="caption" c={C.secondary} numberOfLines={2}>{item.batch} · {item.term}{item.daysOverdue ? ` · ${item.daysOverdue} days overdue` : ''}</Text></Pressable><View style={{ alignItems: 'flex-end', gap: 5 }}><Text c={item.state === 'overdue' ? C.danger : C.primary} weight={700} tabular>{money(item.amount)}</Text>{item.state !== 'cleared' && <Pressable onPress={() => { void remind(item); }}><Text variant="caption" c={C.accent} weight={700}>Remind</Text></Pressable>}</View></View>}
    />}
  </SafeAreaView>;
}
