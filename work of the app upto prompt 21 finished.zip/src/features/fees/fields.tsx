import React, { useState } from 'react';
import { TextInput, View } from 'react-native';
import { Calendar, type DateData } from 'react-native-calendars';
import { Button, Sheet, Text } from '@/components/ui';
import { dateShort } from '@/lib/format';
import { C, R } from '@/lib/theme';
import { NO_OUTLINE } from './web';

/** A 56pt-tall money field with a rupee sign. Used for every amount on the screen. */
export function AmountInput({
  value,
  onChange,
  label,
  error,
  prefix = '₹',
  width = 108,
  height = 56,
}: {
  value: string;
  onChange: (text: string) => void;
  label: string;
  error?: boolean;
  prefix?: string;
  width?: number;
  height?: number;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View
      style={{
        width,
        height,
        borderRadius: R.field,
        backgroundColor: C.surface,
        borderWidth: focused ? 2 : 1,
        borderColor: error ? C.danger : focused ? C.primary : C.hairline,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        gap: 2,
      }}
    >
      <Text variant="caption" weight={600} c={C.muted}>
        {prefix}
      </Text>
      <TextInput
        accessibilityLabel={label}
        value={value}
        onChangeText={onChange}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        keyboardType="decimal-pad"
        placeholder="0"
        placeholderTextColor={C.muted}
        selectTextOnFocus
        returnKeyType="done"
        style={[{
          flex: 1,
          minWidth: 0,
          textAlign: 'right',
          fontSize: 17,
          fontWeight: '700',
          color: C.ink,
          fontVariant: ['tabular-nums'],
          paddingVertical: 0,
        }, NO_OUTLINE]}
      />
    </View>
  );
}

/** Calendar in a bottom sheet, opened by the calendar icon on an instalment. */
export function DatePickerSheet({
  visible,
  value,
  title,
  onPick,
  onClose,
}: {
  visible: boolean;
  value: string;
  title: string;
  onPick: (iso: string) => void;
  onClose: () => void;
}) {
  return (
    <Sheet visible={visible} onClose={onClose} title={title} snapPoints={['72%', '88%']}>
      <DateBody value={value} onPick={onPick} />
    </Sheet>
  );
}

/** Mounted only while the sheet is open, so every opening starts from the instalment's own date. */
function DateBody({ value, onPick }: { value: string; onPick: (iso: string) => void }) {
  const [draft, setDraft] = useState(value);
  return (
    <>
      <Text variant="caption" c={C.secondary} style={{ marginBottom: 12 }}>
        Selected: {dateShort(draft)}
      </Text>
      <View style={{ borderRadius: R.card, borderWidth: 1, borderColor: C.hairline, overflow: 'hidden', marginBottom: 16 }}>
        <Calendar
          current={draft}
          onDayPress={(day: DateData) => setDraft(day.dateString)}
          markedDates={{ [draft]: { selected: true, selectedColor: C.primary, selectedTextColor: C.surface } }}
          theme={{
            backgroundColor: C.surface,
            calendarBackground: C.surface,
            textSectionTitleColor: C.muted,
            selectedDayBackgroundColor: C.primary,
            selectedDayTextColor: C.surface,
            todayTextColor: C.accent,
            dayTextColor: C.ink,
            arrowColor: C.primary,
            monthTextColor: C.ink,
            textDayFontWeight: '600',
            textMonthFontWeight: '700',
          }}
        />
      </View>
      <Button title={`Set due date · ${dateShort(draft)}`} onPress={() => onPick(draft)} />
    </>
  );
}
