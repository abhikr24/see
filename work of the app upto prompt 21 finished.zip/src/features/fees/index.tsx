import React, { useState } from 'react';
import { FlatList, Modal, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Text, Button } from '@/components/ui';
import { usePayments } from '@/core/backend';
import { dateShort } from '@/lib/format';
import { C } from '@/lib/theme';
import { useFeeOverview } from './collection-hooks';
import { Avatar, PageHeader, State, card, money } from './ui';

export default function FeesDashboard() {
  const { data, loading, error, refetch } = useFeeOverview();
  const { reject } = usePayments();
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);
  const t = data?.totals;
  return <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}>
    <PageHeader title="Fees & collections" />
    <State loading={loading && !data} error={error} retry={refetch} empty={Boolean(data && !t?.expected)} label="No fees assigned yet. Create a fee plan from a batch." />
    {data && t && t.expected > 0 && <FlatList data={data.recent} keyExtractor={x => x.id} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 110 }} refreshing={loading} onRefresh={refetch}
      ListHeaderComponent={<View>
        <View style={{ backgroundColor: C.primary, borderRadius: 24, padding: 24, paddingBottom: 45, gap: 7 }}>
          <Text variant="caption" c={C.navyPale}>COLLECTED THIS TERM</Text>
          <Text c={C.surface} tabular style={{ fontSize: 38, fontWeight: '800' }}>{money(t.collected)}</Text>
          <Text variant="caption" c={C.navyPale}>of {money(t.expected)} expected</Text>
          <View style={{ height: 6, backgroundColor: C.heroGlass, borderRadius: 6, marginTop: 16, overflow: 'hidden' }}><View style={{ width: `${Math.min(100, t.collected / t.expected * 100)}%`, height: 6, backgroundColor: C.accent }} /></View>
        </View>
        <View style={{ flexDirection: 'row', gap: 12, marginHorizontal: 12, marginTop: -27 }}>
          {([{ label: 'Pending', value: t.pending, color: C.warning, icon: 'time-outline' }, { label: 'Overdue', value: t.overdue, color: C.danger, icon: 'alert-circle-outline' }] as const).map(x =>
            <Pressable key={x.label} onPress={() => router.push('/(owner)/fees/dues' as never)} style={[card, { flex: 1, padding: 15, gap: 5 }]}>
              <Ionicons name={x.icon} size={20} color={x.color}/><Text variant="caption" c={C.secondary}>{x.label}</Text><Text variant="title" tabular c={x.color}>{money(x.value)}</Text>
            </Pressable>)}
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 31, marginBottom: 14 }}><Text variant="title">By batch</Text><Pressable onPress={() => router.push('/(owner)/fees/dues' as never)}><Text variant="caption" c={C.accent} weight={700}>View dues →</Text></Pressable></View>
        <View style={[card, { gap: 18 }]}>{data.batches.map(b => <View key={b.id} style={{ gap: 7 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text weight={700}>{b.name}</Text><Text tabular weight={700}>{money(b.collected)}</Text></View><View style={{ height: 5, backgroundColor: C.track, borderRadius: 4 }}><View style={{ width: `${b.expected ? b.collected / b.expected * 100 : 0}%`, backgroundColor: C.primary, height: 5, borderRadius: 4 }} /></View></View>)}</View>
        <Text variant="title" style={{ marginTop: 30, marginBottom: 13 }}>Recent payments</Text>
      </View>}
      ListEmptyComponent={<Text c={C.secondary} style={{ padding: 20, textAlign: 'center' }}>No payments yet</Text>}
      renderItem={({ item }) => <Pressable onLongPress={() => setSelectedPayment(item.id)} onPress={() => item.receiptId && router.push({ pathname: '/(owner)/fees/receipt', params: { id: item.receiptId } } as never)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 13, borderBottomWidth: 1, borderColor: C.hairline, gap: 11 }}>
        <Avatar name={item.name} photo={item.photoUrl}/><View style={{ flex: 1 }}><Text weight={700}>{item.name}</Text><Text variant="caption" c={C.secondary}>{item.term} · {item.method.toUpperCase()} · {dateShort(item.date)}</Text></View><Text weight={700} c={C.teal} tabular>+{money(item.amount)}</Text><Ionicons name="receipt-outline" size={19} color={C.secondary}/>
      </Pressable>} />}
    <Modal visible={Boolean(selectedPayment)} transparent animationType="fade" onRequestClose={() => setSelectedPayment(null)}><View style={{ flex: 1, backgroundColor: C.scrim, justifyContent: 'center', padding: 24 }}><View style={[card, { gap: 14 }]}><Text variant="title">Reject this payment?</Text><Text c={C.secondary}>Its amount will return to the student&apos;s dues. The issued receipt number remains in history.</Text><Button title="Reject payment" variant="danger" onPress={async () => { if (selectedPayment) await reject(selectedPayment); setSelectedPayment(null); }}/><Button title="Keep payment" variant="outline" onPress={() => setSelectedPayment(null)}/></View></View></Modal>
    <Pressable accessibilityLabel="Collect fee" onPress={() => router.push('/(owner)/fees/collect' as never)} style={{ position: 'absolute', bottom: 26, right: 22, width: 62, height: 62, borderRadius: 31, backgroundColor: C.accent, justifyContent: 'center', alignItems: 'center', elevation: 5 }}><Text c={C.surface} style={{ fontSize: 30, fontWeight: '800' }}>₹</Text></Pressable>
  </SafeAreaView>;
}
