import React from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Text } from '@/components/ui';
import { C, R } from '@/lib/theme';

/** A bottom panel that scrolls. The shared Sheet does not, and a class list can be long. */
export function BottomPanel({
  visible,
  title,
  subtitle,
  onClose,
  children,
}: {
  visible: boolean;
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: C.scrim }}>
        <Pressable accessibilityLabel="Close" style={{ flex: 1 }} onPress={onClose} />
        <View
          style={{
            backgroundColor: C.surface,
            borderTopLeftRadius: R.sheet,
            borderTopRightRadius: R.sheet,
            maxHeight: '78%',
            width: '100%',
            maxWidth: 640,
            alignSelf: 'center',
            paddingTop: 20,
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 14, gap: 12, flexShrink: 0, borderBottomWidth: 1, borderBottomColor: C.hairline }}>
            <View style={{ flex: 1 }}>
              <Text variant="h2">{title}</Text>
              {subtitle ? (
                <Text variant="caption" c={C.secondary}>
                  {subtitle}
                </Text>
              ) : null}
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Close"
              onPress={onClose}
              hitSlop={12}
              style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: C.track, alignItems: 'center', justifyContent: 'center' }}
            >
              <Ionicons name="close" size={18} color={C.secondary} />
            </Pressable>
          </View>
          <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 32, gap: 10 }} keyboardShouldPersistTaps="handled">
            {children}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}
