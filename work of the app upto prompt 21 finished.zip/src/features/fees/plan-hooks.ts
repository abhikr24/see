import { useMemo, useReducer, useState } from 'react';
import type { ID, SavePlanResult } from '@/core/contracts/models';
import { useApplyDiscounts, useFeePlan, useSaveFeePlan } from '@/core/hooks/finance';
import {
  draftFromView,
  isDirty,
  planReducer,
  problemsOf,
  toInput,
  type PlanFormState,
} from './plan-model';

const EMPTY: PlanFormState = { frequency: 'term', total: '', rows: [], discounts: [], batchIds: [] };

/** One hook for the whole plan screen: the read, the form state, the verdict and the save. */
export function usePlanForm(batchId: ID) {
  const query = useFeePlan(batchId);
  const { save, saving } = useSaveFeePlan();
  const { apply, applying } = useApplyDiscounts();
  const view = query.data;
  const [state, dispatch] = useReducer(planReducer, EMPTY);
  const [hydrated, setHydrated] = useState<string | null>(null);

  // The form starts from the saved plan, and starts over only when a save replaces it.
  const key = view ? `${view.structure?.id ?? 'new'}:${view.structure?.updatedAt ?? ''}` : null;
  if (view && key && key !== hydrated) {
    setHydrated(key);
    dispatch({ type: 'reset', state: draftFromView(view) });
  }

  const ready = Boolean(view) && hydrated === key;
  const problems = useMemo(() => problemsOf(state), [state]);
  const dirty = view ? isDirty(state, view) : false;
  const nextVersion = view?.structure && view.hasPayments ? view.structure.version + 1 : null;

  return {
    query,
    view,
    state,
    dispatch,
    ready,
    problems,
    dirty,
    saving,
    applying,
    apply,
    /** Set when saving will create a new version instead of editing in place. */
    nextVersion,
    canSave: ready && dirty && problems.ok && !saving,
    submit: async (): Promise<SavePlanResult | null> => {
      if (!view || !problems.ok) return null;
      const result = await save(toInput(state, view));
      return result.ok ? result.data : null;
    },
  };
}
