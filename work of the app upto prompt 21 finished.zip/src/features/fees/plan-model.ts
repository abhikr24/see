/** Pure state for the fee-plan form: no React, no backend. The screen only renders it. */
import {
  FREQUENCY_PRESETS,
  addMonths,
  allocate,
  buildSchedule,
  validatePlan,
  type PlanProblems,
} from '@/core/contracts/fee-plan';
import type { FeePlanView, ID, PlanDiscount, PlanFrequency, SavePlanInput } from '@/core/contracts/models';

export interface RowDraft {
  id: string;
  label: string;
  /** What is typed, so "4,5" or "10." never gets rewritten under the cursor. */
  amount: string;
  dueDate: string;
}

export interface DiscountDraft {
  id: string;
  label: string;
  type: PlanDiscount['type'];
  amount: string;
  note: string;
}

export interface PlanFormState {
  frequency: PlanFrequency;
  total: string;
  rows: RowDraft[];
  discounts: DiscountDraft[];
  batchIds: ID[];
}

export type PlanAction =
  | { type: 'reset'; state: PlanFormState }
  | { type: 'frequency'; frequency: PlanFrequency }
  | { type: 'total'; text: string }
  | { type: 'splitEvenly' }
  | { type: 'row'; id: string; patch: Partial<RowDraft> }
  | { type: 'addRow' }
  | { type: 'removeRow'; id: string }
  | { type: 'toggleBatch'; batchId: ID }
  | { type: 'discount'; id: string; patch: Partial<DiscountDraft> }
  | { type: 'addDiscount' }
  | { type: 'removeDiscount'; id: string };

/** Typed text to rupees. Digits and one decimal point; anything else is ignored. */
export function parseMoney(text: string): number {
  const n = Number(text.replace(/[^0-9.]/g, ''));
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
}

export const cleanMoney = (text: string): string => {
  const [whole = '', ...rest] = text.replace(/[^0-9.]/g, '').split('.');
  return rest.length ? `${whole}.${rest.join('').slice(0, 2)}` : whole;
};

const moneyText = (n: number): string => (n > 0 ? String(n) : '');

export function draftFromView(view: FeePlanView): PlanFormState {
  const s = view.structure;
  if (s) {
    return {
      frequency: (['monthly', 'quarterly', 'term'] as const).find((f) => f === s.frequency) ?? 'term',
      total: moneyText(s.totalAmount),
      rows: s.schedule.map((x) => ({ id: x.id, label: x.label, amount: moneyText(x.amount), dueDate: x.dueDate })),
      discounts: s.discounts.map((d) => ({ ...d, amount: moneyText(d.amount) })),
      batchIds: s.batchIds.length ? s.batchIds : [view.batchId],
    };
  }
  const { frequency, totalAmount, firstDueDate } = view.defaults;
  return {
    frequency,
    total: moneyText(totalAmount),
    rows: buildSchedule(frequency, totalAmount, firstDueDate).map((x) => ({
      id: x.id,
      label: x.label,
      amount: moneyText(x.amount),
      dueDate: x.dueDate,
    })),
    discounts: [],
    batchIds: [view.batchId],
  };
}

const rowSum = (rows: RowDraft[]): number => Math.round(rows.reduce((a, r) => a + parseMoney(r.amount), 0) * 100) / 100;
const freshId = (prefix: string, ids: string[]): string => {
  let n = ids.length + 1;
  while (ids.includes(`${prefix}${n}`)) n += 1;
  return `${prefix}${n}`;
};

const retitle = (rows: RowDraft[]): RowDraft[] =>
  rows.map((r, i) => (/^Instalment \d+$/.test(r.label) ? { ...r, label: `Instalment ${i + 1}` } : r));

export function planReducer(state: PlanFormState, action: PlanAction): PlanFormState {
  switch (action.type) {
    case 'reset':
      return action.state;
    case 'frequency': {
      const first = state.rows[0]?.dueDate || new Date().toISOString().slice(0, 10);
      const rows = buildSchedule(action.frequency, parseMoney(state.total), first).map((x) => ({
        id: x.id,
        label: x.label,
        amount: moneyText(x.amount),
        dueDate: x.dueDate,
      }));
      return { ...state, frequency: action.frequency, rows };
    }
    case 'total': {
      const text = cleanMoney(action.text);
      // While the instalments add up to the old total they follow the new one; once edited by hand they stay put.
      const inSync = rowSum(state.rows) === parseMoney(state.total) && state.rows.length > 0;
      if (!inSync) return { ...state, total: text };
      const shares = allocate(parseMoney(text), state.rows.map((r) => parseMoney(r.amount)));
      return { ...state, total: text, rows: state.rows.map((r, i) => ({ ...r, amount: moneyText(shares[i]) })) };
    }
    case 'splitEvenly': {
      const shares = allocate(parseMoney(state.total), state.rows.map(() => 1));
      return { ...state, rows: state.rows.map((r, i) => ({ ...r, amount: moneyText(shares[i]) })) };
    }
    case 'row':
      return {
        ...state,
        rows: state.rows.map((r) =>
          r.id === action.id
            ? { ...r, ...action.patch, amount: action.patch.amount === undefined ? r.amount : cleanMoney(action.patch.amount) }
            : r,
        ),
      };
    case 'addRow': {
      const last = state.rows[state.rows.length - 1];
      const gap = Math.max(1, FREQUENCY_PRESETS[state.frequency].months);
      const missing = Math.round((parseMoney(state.total) - rowSum(state.rows)) * 100) / 100;
      const row: RowDraft = {
        id: freshId('i', state.rows.map((r) => r.id)),
        label: `Instalment ${state.rows.length + 1}`,
        amount: moneyText(missing),
        dueDate: addMonths(last?.dueDate || new Date().toISOString().slice(0, 10), gap),
      };
      return { ...state, rows: [...state.rows, row] };
    }
    case 'removeRow':
      return { ...state, rows: retitle(state.rows.filter((r) => r.id !== action.id)) };
    case 'toggleBatch': {
      const has = state.batchIds.includes(action.batchId);
      return { ...state, batchIds: has ? state.batchIds.filter((b) => b !== action.batchId) : [...state.batchIds, action.batchId] };
    }
    case 'discount':
      return {
        ...state,
        discounts: state.discounts.map((d) =>
          d.id === action.id
            ? { ...d, ...action.patch, amount: action.patch.amount === undefined ? d.amount : cleanMoney(action.patch.amount) }
            : d,
        ),
      };
    case 'addDiscount':
      return {
        ...state,
        discounts: [
          ...state.discounts,
          { id: freshId('d', state.discounts.map((d) => d.id)), label: '', type: 'percent', amount: '', note: '' },
        ],
      };
    case 'removeDiscount':
      return { ...state, discounts: state.discounts.filter((d) => d.id !== action.id) };
  }
}

const scheduleOf = (state: PlanFormState) =>
  state.rows.map((r) => ({ id: r.id, label: r.label, amount: parseMoney(r.amount), dueDate: r.dueDate }));
const discountsOf = (state: PlanFormState): PlanDiscount[] =>
  state.discounts.map((d) => ({ id: d.id, label: d.label, type: d.type, amount: parseMoney(d.amount), note: d.note }));

/** The submission for a form state. The batch the screen was opened for always stays selected. */
export function toInput(state: PlanFormState, view: FeePlanView): SavePlanInput {
  return {
    id: view.structure?.id,
    batchId: view.batchId,
    batchIds: state.batchIds.includes(view.batchId) ? state.batchIds : [view.batchId, ...state.batchIds],
    name: view.structure?.name,
    frequency: state.frequency,
    totalAmount: parseMoney(state.total),
    schedule: scheduleOf(state),
    discounts: discountsOf(state),
  };
}

/** The same rules the repo enforces, run on every keystroke. */
export const problemsOf = (state: PlanFormState): PlanProblems =>
  validatePlan({
    batchIds: state.batchIds,
    totalAmount: parseMoney(state.total),
    schedule: scheduleOf(state),
    discounts: discountsOf(state),
  });

/** A plan that was never saved can always be saved; a saved one only when something changed. */
export const isDirty = (state: PlanFormState, view: FeePlanView): boolean =>
  !view.structure || JSON.stringify(toInput(state, view)) !== JSON.stringify(toInput(draftFromView(view), view));
