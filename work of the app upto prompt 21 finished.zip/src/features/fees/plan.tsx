import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, RefreshControl, ScrollView, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Badge, Button, Card, ErrorState, Skeleton, Text } from '@/components/ui';
import type { FeePlanView, PlanStudentRow } from '@/core/contracts/models';
import { FREQUENCY_PRESETS } from '@/core/contracts/fee-plan';
import { inr } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import { AssignSheet, DiscountSection } from './discounts';
import { BottomPanel } from './panel';
import { NO_OUTLINE } from './web';
import { usePlanForm } from './plan-hooks';
import { AddRow, AppliesTo, FrequencyTabs, InstallmentCard, TotalsLine } from './structures';

const BATCHES = '/(owner)/batches';

function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <View style={{ gap: 12 }}>
      <View style={{ gap: 2 }}>
        <Text variant="label" c={C.secondary}>
          {title}
        </Text>
        {hint ? (
          <Text variant="caption" c={C.muted}>
            {hint}
          </Text>
        ) : null}
      </View>
      {children}
    </View>
  );
}

function PlanSkeleton() {
  return (
    <View style={{ gap: 16 }}>
      <Skeleton h={112} r={R.card} />
      <Skeleton h={44} r={R.chip} />
      {[0, 1, 2].map((n) => (
        <Skeleton key={n} h={84} r={R.card} />
      ))}
    </View>
  );
}

function VersionHistory({ view }: { view: FeePlanView }) {
  if (view.versions.length < 2) return null;
  return (
    <Section title="Versions" hint="Older versions stay linked to the payments made on them.">
      <Card pad={0} flat>
        {view.versions.map((v, i) => (
          <View
            key={v.id}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              gap: 12,
              padding: LAYOUT.cardPad,
              borderTopWidth: i === 0 ? 0 : 1,
              borderTopColor: C.hairline,
            }}
          >
            <View style={{ flex: 1, gap: 2 }}>
              <Text variant="body" weight={700}>
                Version {v.version}
              </Text>
              <Text variant="caption" c={C.secondary} tabular>
                {inr(v.totalAmount)} · {v.students} student{v.students === 1 ? '' : 's'}
                {v.withPayments ? ` · ${v.withPayments} with payments` : ''}
              </Text>
            </View>
            <Badge label={v.isActive ? 'Current' : 'Kept'} tone={v.isActive ? 'teal' : 'neutral'} />
          </View>
        ))}
      </Card>
    </Section>
  );
}

export function FeePlanScreen() {
  const { batchId } = useLocalSearchParams<{ batchId: string }>();
  const insets = useSafeAreaInsets();
  const form = usePlanForm(batchId);
  const { view, state, dispatch, problems } = form;
  const [assignId, setAssignId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  /** The version the open confirmation will create, kept so the text does not change while it closes. */
  const [confirming, setConfirming] = useState<number | null>(null);

  const goBack = () => (router.canGoBack() ? router.back() : router.replace(BATCHES as never));
  const assigning = assignId ? (view?.structure?.discounts.find((d) => d.id === assignId) ?? null) : null;

  const save = async () => {
    setConfirming(null);
    await form.submit();
  };
  const toggle = async (student: PlanStudentRow, next: string[]) => {
    setBusyId(student.studentId);
    await form.apply({ studentId: student.studentId, discountIds: next });
    setBusyId(null);
  };

  const reason = !form.dirty
    ? 'No changes to save'
    : (problems.schedule ?? problems.total ?? problems.batches ?? Object.values(problems.rows)[0] ?? Object.values(problems.discounts)[0] ?? null);
  const nextVersion = form.nextVersion;

  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: C.canvas }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={form.query.loading && Boolean(view)} onRefresh={() => void form.query.refetch()} />}
          contentContainerStyle={{
            padding: LAYOUT.margin,
            paddingBottom: 200,
            gap: 24,
            width: '100%',
            maxWidth: 640,
            alignSelf: 'center',
          }}
        >
          <View style={{ gap: 14 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Back"
              onPress={goBack}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}
            >
              <Ionicons name="chevron-back" size={20} color={C.primary} />
              <Text variant="caption" weight={700} c={C.primary}>
                {view?.batchName ?? 'Batch'}
              </Text>
            </Pressable>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
              <Text variant="h2" weight={800}>
                Fee plan
              </Text>
              {view?.structure ? (
                <Badge label={`Version ${view.structure.version}`} tone="primary" />
              ) : view ? (
                <Badge label="New plan" tone="accent" />
              ) : null}
            </View>
          </View>

          {form.query.error && !view ? (
            <ErrorState message={form.query.error.message} onRetry={() => void form.query.refetch()} />
          ) : !view || !form.ready ? (
            <PlanSkeleton />
          ) : (
            <>
              <Card style={{ gap: 6 }}>
                <Text variant="label" c={C.secondary}>
                  Plan total
                </Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  <Text style={{ fontSize: 34, fontWeight: '800', color: C.muted }}>₹</Text>
                  <TextInput
                    accessibilityLabel="Plan total"
                    value={state.total}
                    onChangeText={(text) => dispatch({ type: 'total', text })}
                    keyboardType="decimal-pad"
                    placeholder="0"
                    placeholderTextColor={C.muted}
                    returnKeyType="done"
                    style={[{
                      flex: 1,
                      minWidth: 0,
                      fontSize: 34,
                      fontWeight: '800',
                      color: C.ink,
                      fontVariant: ['tabular-nums'],
                      paddingVertical: 0,
                    }, NO_OUTLINE]}
                  />
                </View>
                <Text variant="caption" c={C.secondary}>
                  {view.batchName} · {view.students.length} student{view.students.length === 1 ? '' : 's'} ·{' '}
                  {FREQUENCY_PRESETS[state.frequency].label.toLowerCase()} plan
                </Text>
              </Card>

              <FrequencyTabs value={state.frequency} dispatch={dispatch} />

              {nextVersion ? (
                <Card flat pad={14} style={{ borderLeftWidth: 4, borderLeftColor: C.warning }}>
                  <Text variant="caption" weight={600}>
                    Payments exist on this plan.
                  </Text>
                  <Text variant="caption" c={C.secondary}>
                    Saving creates version {nextVersion}. Students who already paid stay on version {nextVersion - 1}, so their receipts never change.
                  </Text>
                </Card>
              ) : null}

              <Section title="Instalments">
                {state.rows.map((row, index) => (
                  <InstallmentCard
                    key={row.id}
                    row={row}
                    index={index}
                    error={problems.rows[row.id]}
                    removable={state.rows.length > 1}
                    dispatch={dispatch}
                  />
                ))}
                <AddRow label="Add instalment" onPress={() => dispatch({ type: 'addRow' })} />
                {problems.schedule ? (
                  <Text variant="caption" c={C.danger}>
                    {problems.schedule}
                  </Text>
                ) : (
                  <TotalsLine problems={problems} total={state.total} dispatch={dispatch} />
                )}
              </Section>

              <Section title="Applies to" hint="Pick every batch that pays this plan.">
                <AppliesTo options={view.batches} selected={state.batchIds} lockedId={view.batchId} dispatch={dispatch} />
              </Section>

              <Section title="Discounts and scholarships">
                <DiscountSection
                  rows={state.discounts}
                  errors={problems.discounts}
                  saved={view.structure?.discounts ?? []}
                  students={view.students}
                  dispatch={dispatch}
                  onAssign={setAssignId}
                />
              </Section>

              <VersionHistory view={view} />
            </>
          )}
        </ScrollView>

        <View
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: C.surface,
            borderTopWidth: 1,
            borderTopColor: C.hairline,
            paddingHorizontal: LAYOUT.margin,
            paddingTop: 12,
            paddingBottom: Math.max(insets.bottom, 12),
            alignItems: 'center',
          }}
        >
          <View style={{ width: '100%', maxWidth: 640, gap: 8 }}>
            {view && form.ready && reason && form.dirty ? (
              <Text variant="caption" c={C.danger} numberOfLines={2}>
                {reason}
              </Text>
            ) : null}
            <Button
              title={nextVersion ? `Save as version ${nextVersion}` : 'Save plan'}
              disabled={!form.canSave}
              loading={form.saving}
              onPress={() => (nextVersion ? setConfirming(nextVersion) : void save())}
            />
          </View>
        </View>
      </KeyboardAvoidingView>

      <AssignSheet
        discount={assigning}
        students={view?.students ?? []}
        busyId={busyId}
        onClose={() => setAssignId(null)}
        onToggle={(student, next) => void toggle(student, next)}
      />
      <BottomPanel
        visible={confirming !== null}
        title={`Save as version ${confirming ?? ''}`}
        subtitle="Payments are already recorded on this plan."
        onClose={() => setConfirming(null)}
      >
        <Text variant="body" c={C.secondary}>
          Version {confirming ? confirming - 1 : ''} is kept exactly as it is, linked to the payments and receipts already issued. Students who have
          not paid move to the new plan; students who have paid keep the fee they paid on.
        </Text>
        <Button title={`Save version ${confirming ?? ''}`} onPress={() => void save()} loading={form.saving} />
        <Button title="Keep editing" variant="outline" onPress={() => setConfirming(null)} />
      </BottomPanel>
    </SafeAreaView>
  );
}
