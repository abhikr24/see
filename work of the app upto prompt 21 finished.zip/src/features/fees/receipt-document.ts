import type { Institute } from '@/core/contracts/models';
import { inr } from '@/lib/format';
export type ReceiptDocument = { institute: Pick<Institute, 'name' | 'city' | 'state'>; receiptNo: string; amount: number; student: string; term: string; date: string; method: string };
const escape = (text: string) => text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
export function receiptHtml(doc: ReceiptDocument): string {
  const rows = [['Student', doc.student], ['Term', doc.term], ['Receipt no', doc.receiptNo], ['Date', doc.date], ['Method', doc.method.toUpperCase()]];
  return `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;color:#101B4C;padding:48px}main{border:1px dashed #94A0BC;border-radius:18px;padding:36px;max-width:530px;margin:auto}h1{font-size:22px;margin-bottom:3px}.city{color:#5A6684;margin:0 0 30px}.tag{letter-spacing:3px;color:#5A6684;font-size:12px}.amount{font-size:42px;font-weight:800;margin:8px 0 28px}.row{border-top:1px solid #E7EBF5;padding:14px 0;display:flex;justify-content:space-between}.row span{color:#5A6684}</style></head><body><main><h1>${escape(doc.institute.name)}</h1><p class="city">${escape([doc.institute.city, doc.institute.state].filter(Boolean).join(', '))}</p><div class="tag">RECEIPT</div><div class="amount">${escape(inr(doc.amount))}</div>${rows.map(([k,v]) => `<div class="row"><span>${escape(k)}</span><b>${escape(v)}</b></div>`).join('')}</main></body></html>`;
}
