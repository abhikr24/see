import React, { useState } from 'react';
import { Linking, Platform, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Text, Button } from '@/components/ui';
import { toast } from '@/core/backend';
import { C } from '@/lib/theme';
import { useReceiptDetail } from './collection-hooks';
import { PageHeader, State, card } from './ui';
import { receiptHtml } from './receipt-document';
import { inr } from '@/lib/format';

export default function ReceiptScreen() {
  const { id = '' } = useLocalSearchParams<{ id: string }>();
  const { data, loading, error, refetch } = useReceiptDetail(id);
  const [busy, setBusy] = useState(false);
  const download = async () => {
    if (!data || busy) return;
    setBusy(true);
    try {
      const html = receiptHtml(data.document);
      if (Platform.OS === 'web') await Print.printAsync({ html });
      else { const file = await Print.printToFileAsync({ html }); await Sharing.shareAsync(file.uri, { mimeType: 'application/pdf', UTI: '.pdf' }); }
    } catch { toast.error('Could not create PDF. Please try again.'); }
    finally { setBusy(false); }
  };
  const share = async () => {
    if (!data) return;
    if (!data.phone) { toast.error('Parent phone number not available'); return; }
    const d = data.document;
    const message = `Payment received by ${d.institute.name}, ${d.institute.city ?? ''}: ${inr(d.amount)} for ${d.student} (${d.term}). Receipt ${d.receiptNo}. Thank you!`;
    const url = `https://wa.me/${data.phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    try { await Linking.openURL(url); } catch { toast.error('Could not open WhatsApp'); }
  };
  const d = data?.document;
  return <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top']}><PageHeader title="Payment receipt" back />
    <State loading={loading && !data} error={error} retry={refetch} label="Receipt not found" empty={!loading && !error && !data}/>
    {d && <View style={{ padding: 20, flex: 1, gap: 20 }}><View style={{ alignItems: 'center', gap: 8, marginBottom: 6 }}><View style={{ backgroundColor: C.successSoft, borderRadius: 35, padding: 15 }}><Ionicons name="checkmark-circle" size={42} color={C.success}/></View><Text variant="h2">Payment successful</Text><Text variant="caption" c={C.secondary}>A receipt has been issued</Text></View>
      <View style={[card, { borderStyle: 'dashed', padding: 23, gap: 12 }]}><Text variant="title" style={{ textAlign: 'center' }}>{d.institute.name}</Text><Text variant="caption" c={C.secondary} style={{ textAlign: 'center' }}>{[d.institute.city,d.institute.state].filter(Boolean).join(', ')}</Text><View style={{ height: 1, backgroundColor: C.hairline, marginVertical: 8 }}/><Text variant="label" c={C.secondary} style={{ textAlign: 'center' }}>RECEIPT</Text><Text tabular style={{ fontSize: 34, fontWeight: '800', textAlign: 'center' }}>{inr(d.amount)}</Text>{([['Student',d.student],['Term',d.term],['Receipt no',d.receiptNo],['Date',d.date],['Method',d.method.toUpperCase()]] as const).map(([label,value]) => <View key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderColor: C.hairline, paddingTop: 10 }}><Text variant="caption" c={C.secondary}>{label}</Text><Text variant="caption" weight={700}>{value}</Text></View>)}</View>
      <Button title="Download PDF" icon="download-outline" onPress={download} loading={busy}/><Button title="Send receipt to parent on WhatsApp" variant="outline" icon="logo-whatsapp" onPress={share}/>
    </View>}
  </SafeAreaView>;
}
