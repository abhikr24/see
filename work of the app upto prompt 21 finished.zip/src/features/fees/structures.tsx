import React, { useState } from 'react';
import { Pressable, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, SegmentedControl, Text } from '@/components/ui';
import { FREQUENCY_OPTIONS, FREQUENCY_PRESETS, type PlanProblems } from '@/core/contracts/fee-plan';
import type { PlanBatchOption, PlanFrequency } from '@/core/contracts/models';
import { dateShort, inr } from '@/lib/format';
import { C, R } from '@/lib/theme';
import { AmountInput, DatePickerSheet } from './fields';
import { NO_OUTLINE } from './web';
import type { PlanAction, RowDraft } from './plan-model';
import { parseMoney } from './plan-model';

type Dispatch = (action: PlanAction) => void;

/** Monthly / Quarterly / Term. */
export function FrequencyTabs({ value, dispatch }: { value: PlanFrequency; dispatch: Dispatch }) {
  return (
    <SegmentedControl<PlanFrequency>
      options={FREQUENCY_OPTIONS.map((key) => ({ key, label: FREQUENCY_PRESETS[key].label }))}
      value={value}
      onChange={(frequency) => dispatch({ type: 'frequency', frequency })}
    />
  );
}

/** One instalment: step badge, name, due date with calendar, amount. */
export function InstallmentCard({
  row,
  index,
  error,
  removable,
  dispatch,
}: {
  row: RowDraft;
  index: number;
  error?: string;
  removable: boolean;
  dispatch: Dispatch;
}) {
  const [picking, setPicking] = useState(false);
  return (
    <Card pad={14}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View
          style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' }}
        >
          <Text variant="caption" weight={700} c={C.surface} tabular>
            {index + 1}
          </Text>
        </View>
        <View style={{ flex: 1, minWidth: 0, gap: 2 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <TextInput
              accessibilityLabel={`Instalment ${index + 1} name`}
              value={row.label}
              onChangeText={(label) => dispatch({ type: 'row', id: row.id, patch: { label } })}
              placeholder="Instalment name"
              placeholderTextColor={C.muted}
              style={[{ flex: 1, minWidth: 0, fontSize: 17, fontWeight: '700', color: C.ink, paddingVertical: 2 }, NO_OUTLINE]}
            />
            {removable ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Remove ${row.label || `instalment ${index + 1}`}`}
                hitSlop={10}
                onPress={() => dispatch({ type: 'removeRow', id: row.id })}
              >
                <Ionicons name="close-circle" size={20} color={C.muted} />
              </Pressable>
            ) : null}
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Due date, ${dateShort(row.dueDate)}. Change`}
            onPress={() => setPicking(true)}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', paddingVertical: 2 }}
          >
            <Text variant="caption" c={C.secondary}>
              Due {dateShort(row.dueDate)}
            </Text>
            <Ionicons name="calendar-outline" size={16} color={C.primary} />
          </Pressable>
        </View>
        <AmountInput
          label={`Instalment ${index + 1} amount`}
          value={row.amount}
          onChange={(amount) => dispatch({ type: 'row', id: row.id, patch: { amount } })}
          error={Boolean(error)}
        />
      </View>
      {error ? (
        <Text variant="caption" c={C.danger} style={{ marginTop: 8 }}>
          {error}
        </Text>
      ) : null}
      <DatePickerSheet
        visible={picking}
        value={row.dueDate}
        title={row.label || `Instalment ${index + 1}`}
        onClose={() => setPicking(false)}
        onPick={(dueDate) => {
          dispatch({ type: 'row', id: row.id, patch: { dueDate } });
          setPicking(false);
        }}
      />
    </Card>
  );
}

/** Dashed "+ Add …" row, shared by instalments and discounts. */
export function AddRow({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => ({
        height: 56,
        borderRadius: R.card,
        borderWidth: 1.5,
        borderStyle: 'dashed',
        borderColor: C.cardDash,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        opacity: pressed ? 0.7 : 1,
      })}
    >
      <Ionicons name="add" size={20} color={C.primary} />
      <Text variant="body" weight={700} c={C.primary}>
        {label}
      </Text>
    </Pressable>
  );
}

/** The live total under the cards. Red while it disagrees with the plan total. */
export function TotalsLine({
  problems,
  total,
  dispatch,
}: {
  problems: PlanProblems;
  total: string;
  dispatch: Dispatch;
}) {
  const planTotal = parseMoney(total);
  const matches = planTotal > 0 && problems.total === null;
  const gap = problems.difference;
  const tone = matches ? C.teal : C.danger;
  return (
    <View
      accessibilityLiveRegion="polite"
      style={{
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: matches ? C.hairline : C.danger,
        backgroundColor: matches ? C.surface : C.dangerSoft,
        padding: 16,
        gap: 10,
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <View style={{ gap: 2 }}>
          <Text variant="caption" c={C.secondary}>
            Instalments add up to
          </Text>
          <Text variant="h2" weight={800} tabular c={tone}>
            {inr(problems.sum)}
          </Text>
        </View>
        <View style={{ alignItems: 'flex-end', gap: 2 }}>
          <Text variant="caption" c={C.secondary}>
            Plan total
          </Text>
          <Text variant="title" tabular>
            {inr(planTotal)}
          </Text>
        </View>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Ionicons name={matches ? 'checkmark-circle' : 'alert-circle'} size={18} color={tone} />
        <Text variant="caption" weight={600} c={tone} style={{ flex: 1 }}>
          {matches
            ? 'Matches the plan total'
            : planTotal <= 0
              ? 'Enter the plan total above'
              : gap > 0
                ? `${inr(gap)} short of the total. Saving is blocked`
                : `${inr(-gap)} over the total. Saving is blocked`}
        </Text>
        {!matches && planTotal > 0 ? (
          <Pressable accessibilityRole="button" onPress={() => dispatch({ type: 'splitEvenly' })} hitSlop={8}>
            <Text variant="caption" weight={700} c={C.primary}>
              Split evenly
            </Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

/** Multi-select batch chips. The batch the screen was opened for is always on. */
export function AppliesTo({
  options,
  selected,
  lockedId,
  dispatch,
}: {
  options: PlanBatchOption[];
  selected: string[];
  lockedId: string;
  dispatch: Dispatch;
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {options.map((b) => {
        const active = selected.includes(b.batchId);
        const taken = Boolean(b.takenBy) && !active;
        const locked = b.batchId === lockedId;
        return (
          <Pressable
            key={b.batchId}
            accessibilityRole="checkbox"
            accessibilityState={{ checked: active, disabled: taken || locked }}
            accessibilityLabel={taken ? `${b.name}, already on ${b.takenBy?.planName}` : b.name}
            disabled={taken || locked}
            onPress={() => dispatch({ type: 'toggleBatch', batchId: b.batchId })}
            style={{
              height: 36,
              paddingHorizontal: 14,
              borderRadius: R.chip,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 6,
              backgroundColor: active ? C.primary : C.surface,
              borderWidth: 1,
              borderColor: active ? C.primary : C.hairline,
              opacity: taken ? 0.5 : 1,
            }}
          >
            {active ? <Ionicons name={locked ? 'lock-closed' : 'checkmark'} size={14} color={C.surface} /> : null}
            <Text variant="caption" weight={600} c={active ? C.surface : C.secondary} tabular>
              {b.name} · {taken ? 'has a plan' : b.studentCount}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
