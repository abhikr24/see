import React from 'react';
import { Pressable, View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Text, Button, Skeleton } from '@/components/ui';
import { initials, inr } from '@/lib/format';
import { C, R } from '@/lib/theme';

export const money = (value: number) => inr(value / 100);
export function Avatar({ name, photo }: { name: string; photo?: string | null }) {
  return <View style={{ width: 42, height: 42, borderRadius: 21, backgroundColor: C.navySoft, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' }}>
    {photo ? <Image source={{ uri: photo }} style={{ width: 42, height: 42 }} /> : <Text variant="caption" weight={800} c={C.primary}>{initials(name)}</Text>}
  </View>;
}
export function PageHeader({ title, back = false }: { title: string; back?: boolean }) {
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingVertical: 16 }}>
    {back && <Pressable accessibilityLabel="Go back" onPress={() => router.back()} style={{ padding: 8 }}><Ionicons name="arrow-back" size={22} color={C.primary} /></Pressable>}
    <Text variant="h2">{title}</Text>
  </View>;
}
export function State({ loading, error, retry, empty, label }: { loading: boolean; error?: { message: string } | null; retry: () => void; empty?: boolean; label: string }) {
  if (loading) return <View style={{ padding: 20, gap: 16 }}><Skeleton h={170} r={R.card}/><Skeleton h={100} r={R.card}/><Skeleton h={100} r={R.card}/></View>;
  if (error) return <View style={{ padding: 20, alignItems: 'center', gap: 16 }}><Text c={C.danger}>{error.message}</Text><Button title="Try again" onPress={retry}/></View>;
  if (empty) return <View style={{ padding: 36, alignItems: 'center', gap: 12 }}><Ionicons name="wallet-outline" size={38} color={C.muted}/><Text c={C.secondary}>{label}</Text></View>;
  return null;
}
export const card = { backgroundColor: C.surface, borderRadius: R.card, borderWidth: 1, borderColor: C.hairline, padding: 18 } as const;
