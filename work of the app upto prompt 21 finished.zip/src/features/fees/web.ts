import { Platform, type TextStyle } from 'react-native';

/** The field draws its own focus border, so the browser's default outline is switched off on web. */
export const NO_OUTLINE: TextStyle = Platform.select({
  web: { outlineWidth: 0 },
  default: {},
}) as TextStyle;
