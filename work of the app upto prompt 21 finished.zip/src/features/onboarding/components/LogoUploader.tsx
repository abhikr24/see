import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { C, R } from '@/lib/theme';
import { Text } from '@/components/ui';

export interface LogoUploaderProps {
  uri: string | null;
  onPick: () => void;
  uploading?: boolean;
}

/**
 * 88pt dashed logo uploader. Taps simulate a StoragePort upload.
 */
export function LogoUploader({ uri, onPick, uploading }: LogoUploaderProps) {
  return (
    <View style={{ alignItems: 'center', gap: 8 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Upload institute logo"
        onPress={onPick}
        style={{
          width: 88,
          height: 88,
          borderRadius: R.card,
          borderWidth: 2,
          borderColor: C.hairline,
          borderStyle: 'dashed',
          backgroundColor: C.surface,
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
        }}
      >
        {uri ? (
          <Image source={{ uri }} style={{ width: 88, height: 88, borderRadius: R.card }} contentFit="cover" />
        ) : (
          <View style={{ alignItems: 'center', gap: 4 }}>
            <View
              style={{
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: C.track,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Ionicons name="camera-outline" size={18} color={C.secondary} />
            </View>
            <Text variant="label" c={C.muted} style={{ fontSize: 10 }}>
              LOGO
            </Text>
          </View>
        )}
        {uploading ? (
          <View
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: C.scrim,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="cloud-upload-outline" size={20} color={C.surface} />
          </View>
        ) : null}
      </Pressable>
      <Text variant="caption" c={C.muted}>
        Tap to upload logo
      </Text>
    </View>
  );
}
