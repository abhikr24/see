import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useBackend } from '@/core/backend';
import type { Institute } from '@/core/contracts/models';

/**
 * Join by code search: accepts name or exact code, debounce 300ms.
 * Uses InstituteRepo.search (fallback to findByCode).
 */
export function useJoinSearch() {
  const { backend } = useBackend();
  const [query, setQuery] = useState('');
  const [debounced, setDebounced] = useState('');
  const [results, setResults] = useState<Institute[]>([]);
  const [loading, setLoading] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // debounce 300ms
  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setDebounced(query.trim()), 300);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [query]);

  const search = useCallback(
    async (q: string) => {
      if (!q || q.length < 1) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        // Try search first, fallback to findByCode for exact
        let institutes: Institute[] = [];
        try {
          institutes = await backend.institutes.search(null, q);
        } catch {}
        if (institutes.length === 0 && q.includes('-')) {
          try {
            const exact = await backend.institutes.findByCode(null, q);
            if (exact) institutes = [exact];
          } catch {}
        }
        setResults(institutes);
      } finally {
        setLoading(false);
      }
    },
    [backend],
  );

  useEffect(() => {
    void search(debounced);
  }, [debounced, search]);

  const joined = useMemo(() => results, [results]);

  return { query, setQuery, debounced, results: joined, loading, search };
}

/** Join request mutation (never lets client pick owner) */
export function useJoinRequest() {
  const { backend, setInstituteId } = useBackend();
  const [joiningId, setJoiningId] = useState<string | null>(null);

  const request = useCallback(
    async (instituteId: string, note?: string | null) => {
      setJoiningId(instituteId);
      try {
        // Default role is student (non-technical owner never types details himself)
        const membership = await backend.memberships.requestToJoin(instituteId, { role: 'student', note: note ?? null });
        setInstituteId(instituteId);
        return membership;
      } finally {
        setJoiningId(null);
      }
    },
    [backend, setInstituteId],
  );

  return { request, joiningId };
}
