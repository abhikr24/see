import { useCallback, useState } from 'react';
import { useBackend } from '@/core/backend';
import type { Institute } from '@/core/contracts/models';
import { toast } from '@/core/hooks/toast';

export type InstituteType = 'Coaching' | 'School' | 'Tuition';

export interface RegisterInput {
  name: string;
  type: InstituteType;
  address: string;
  city: string;
  state: string;
  board: string;
  academicSession: string;
  ownerName: string;
  logoUri: string | null;
}

const BOARDS = ['CBSE', 'ICSE', 'State Board', 'Other'] as const;

/**
 * One server-side action creates:
 * institute → owner membership → default settings → three empty fee terms → audit record.
 * Owner assignment is server-side; client never sends role.
 */
export function useRegisterInstitute() {
  const { backend, setInstituteId } = useBackend();
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState<Institute | null>(null);

  const register = useCallback(
    async (input: RegisterInput): Promise<Institute | null> => {
      if (!input.name.trim()) {
        toast.error('Institute name is required');
        return null;
      }
      if (!input.city.trim()) {
        toast.error('City is required');
        return null;
      }
      if (!input.ownerName.trim()) {
        toast.error('Owner name is required');
        return null;
      }
      setLoading(true);
      try {
        // Update profile name first (if differs)
        try {
          const session = await backend.auth.getSession(null);
          if (session && session.profile.fullName !== input.ownerName.trim()) {
            await backend.auth.updateProfile(null, session.user.id, { fullName: input.ownerName.trim() });
          }
        } catch {}
        // Build settings with academic session, board, type
        const academicYear = input.academicSession || '2026-27';
        const settings: Record<string, unknown> = {
          academicYear,
          features: {
            instituteType: input.type,
            board: input.board,
          },
        };
        // Generate code server-side: pass empty to let backend derive SUNRISE-PAT etc.
        // We still pass a hint code derived from name+city so UI can show pip but server validates.
        const codeHint = ''; // let server generate
        const institute = await backend.institutes.create(null, {
          name: input.name.trim(),
          code: codeHint,
          address: input.address.trim() || null,
          city: input.city.trim(),
          state: input.state.trim() || 'Bihar',
          tagline: input.type,
          settings: settings as unknown as Institute['settings'],
        } as unknown as Parameters<typeof backend.institutes.create>[1]);
        // Upload logo now that we have an institute id (StoragePort)
        if (input.logoUri) {
          try {
            await backend.storage.upload(institute.id, {
              ownerType: 'notice',
              ownerId: institute.id,
              fileName: 'logo.png',
              uri: input.logoUri,
              mimeType: 'image/png',
            });
            // Optionally update logoUrl
            try {
              const url = await backend.storage.getUrl(institute.id, `${institute.id}/notice/${institute.id}/logo.png`);
              await backend.institutes.update(institute.id, { logoUrl: url } as unknown as Partial<Institute>);
              institute.logoUrl = url;
            } catch {}
          } catch {}
        }
        setCreated(institute);
        setInstituteId(institute.id);
        toast.success(`${institute.name} is ready`);
        return institute;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : 'Could not create institute';
        toast.error(msg);
        return null;
      } finally {
        setLoading(false);
      }
    },
    [backend, setInstituteId],
  );

  return { register, loading, created, setCreated };
}

export const BOARD_OPTIONS = BOARDS.map((b) => ({ label: b, value: b }));
export const SESSION_OPTIONS = [
  { label: '2025-26', value: '2025-26' },
  { label: '2026-27', value: '2026-27' },
  { label: '2027-28', value: '2027-28' },
];
