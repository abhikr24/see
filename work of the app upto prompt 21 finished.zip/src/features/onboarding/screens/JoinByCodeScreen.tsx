import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, View, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, R, S, LAYOUT } from '@/lib/theme';
import { Button, Card, SearchBar, Sheet, Text } from '@/components/ui';
import { Image } from 'expo-image';
import { useJoinSearch, useJoinRequest } from '../hooks/useJoinSearch';
import { useBackend } from '@/core/backend';
import { useRouter } from 'expo-router';
import { toast } from '@/core/hooks/toast';

export function JoinByCodeScreen() {
  const { query, setQuery, results, loading } = useJoinSearch();
  const { request, joiningId } = useJoinRequest();
  const router = useRouter();
  const { setInstituteId } = useBackend();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);

  const selected = useMemo(() => results.find((r) => r.id === selectedId) ?? null, [results, selectedId]);

  const handleJoinPress = (id: string) => {
    setSelectedId(id);
    setSheetOpen(true);
  };

  const handleConfirm = async () => {
    if (!selected) return;
    try {
      await request(selected.id);
      setSheetOpen(false);
      toast.success('Request sent — waiting for approval');
      router.replace('/(pending)' as never);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Could not send request';
      toast.error(msg);
    }
  };

  const renderCard = ({ item }: { item: (typeof results)[number] }) => {
    const typeLabel = ((item as unknown as { tagline?: string }).tagline as string) ?? 'Coaching';
    const subtitle = `${typeLabel} · ${item.city ?? 'Patna'}, ${item.state ?? 'Bihar'} · 240 students`;
    const verified = item.status === 'active';
    const isJoining = joiningId === item.id;
    return (
      <Card pad={16}>
        <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <View
            style={{
              width: 48,
              height: 48,
              borderRadius: 12,
              backgroundColor: C.track,
              alignItems: 'center',
              justifyContent: 'center',
              overflow: 'hidden',
            }}
          >
            {item.logoUrl ? (
              <Image source={{ uri: item.logoUrl }} style={{ width: 48, height: 48 }} contentFit="cover" />
            ) : (
              <Text variant="title" c={C.primary}>
                {item.name.slice(0, 2).toUpperCase()}
              </Text>
            )}
          </View>
          <View style={{ flex: 1, gap: 4 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text variant="title" numberOfLines={1} style={{ flex: 1 }}>
                {item.name}
              </Text>
              {verified ? (
                <View
                  style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.successSoft, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999 }}
                >
                  <Ionicons name="checkmark-circle" size={12} color={C.success} />
                  <Text variant="label" c={C.success} style={{ fontSize: 10 }}>
                    Verified
                  </Text>
                </View>
              ) : null}
            </View>
            <Text variant="caption" c={C.secondary} numberOfLines={1}>
              {subtitle}
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 }}>
              <Ionicons name="key-outline" size={12} color={C.muted} />
              <Text variant="label" c={C.muted} style={{ fontSize: 11 }}>
                {item.code}
              </Text>
              <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: C.hairline }} />
              <Text variant="caption" c={C.muted}>
                {item.settings?.academicYear ?? '2026-27'}
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginTop: 14 }}>
          <Button
            title={isJoining ? 'Requesting...' : 'Join'}
            size="sm"
            loading={isJoining}
            onPress={() => handleJoinPress(item.id)}
            icon="enter-outline"
          />
        </View>
      </Card>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 12, gap: 12 }}>
        <View style={{ gap: 4 }}>
          <Text variant="h1">Join an institute</Text>
          <Text variant="body" c={C.secondary}>
            Search by name or enter the exact code your institute shared.
          </Text>
        </View>
        <View>
          <SearchBar
            value={query}
            onChangeText={setQuery}
            placeholder="Search name or code e.g. SUNRISE-PAT"
            debounceMs={300}
            loading={loading}
          />
          <Text variant="caption" c={C.muted} style={{ marginTop: 8 }}>
            56pt search · debounce 300ms · try "Sunrise" or "SUNRISE-PAT"
          </Text>
        </View>
      </View>

      <View style={{ flex: 1, marginTop: 12 }}>
        {loading && results.length === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 }}>
            <ActivityIndicator color={C.primary} />
            <Text variant="caption" c={C.muted}>
              Searching...
            </Text>
          </View>
        ) : results.length === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: LAYOUT.margin, gap: 12 }}>
            <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: C.track, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="search-outline" size={28} color={C.muted} />
            </View>
            <Text variant="title" style={{ textAlign: 'center' }}>
              {query ? 'No institutes found' : 'Find your institute'}
            </Text>
            <Text variant="body" c={C.secondary} style={{ textAlign: 'center' }}>
              {query ? `No match for "${query}". Check the code or try a name.` : 'Ask your institute owner for the code like SUNRISE-PAT, or search by name.'}
            </Text>
            {!query ? (
              <Card flat tint={C.surface} pad={12} style={{ marginTop: 8, borderStyle: 'dashed' }}>
                <Text variant="caption" c={C.secondary} style={{ textAlign: 'center' }}>
                  Demo: try SUNRISE-PAT (Sunrise Coaching Classes, Patna · 240 students)
                </Text>
              </Card>
            ) : null}
          </View>
        ) : (
          <FlatList
            data={results}
            keyExtractor={(item) => item.id}
            renderItem={renderCard}
            contentContainerStyle={{ padding: LAYOUT.margin, gap: 12, paddingBottom: 32 }}
            keyboardShouldPersistTaps="handled"
          />
        )}
      </View>

      {/* Confirmation sheet */}
      <Sheet visible={sheetOpen} onClose={() => setSheetOpen(false)} title="Confirm request" snapPoints={["50%"]}>
        {selected ? (
          <View style={{ gap: 16, padding: 16 }}>
            <View style={{ alignItems: 'center', gap: 8, paddingVertical: 8 }}>
              <View style={{ width: 56, height: 56, borderRadius: 16, backgroundColor: C.track, alignItems: 'center', justifyContent: 'center' }}>
                <Text variant="h2" c={C.primary}>
                  {selected.name.slice(0, 2).toUpperCase()}
                </Text>
              </View>
              <Text variant="h2" style={{ textAlign: 'center' }}>
                Join {selected.name}?
              </Text>
              <Text variant="body" c={C.secondary} style={{ textAlign: 'center' }}>
                You’ll send a join request to {selected.code}. The owner will approve you — then you’ll land on your home automatically.
              </Text>
              <Card flat tint={C.track} pad={12} style={{ alignSelf: 'stretch', marginTop: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Ionicons name="information-circle-outline" size={16} color={C.secondary} />
                  <Text variant="caption" c={C.secondary}>
                    Role: Student (managed server-side). Owners are assigned automatically.
                  </Text>
                </View>
              </Card>
            </View>
            <View style={{ gap: 10 }}>
              <Button title="Confirm & send request" onPress={handleConfirm} loading={!!joiningId} icon="checkmark-circle-outline" />
              <Button title="Cancel" variant="ghost" onPress={() => setSheetOpen(false)} />
            </View>
          </View>
        ) : null}
      </Sheet>
    </SafeAreaView>
  );
}
