import React, { useState } from 'react';
import { Pressable, ScrollView, View, Platform, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { C, R, S, LAYOUT } from '@/lib/theme';
import { Button, Card, Input, SegmentedControl, Select, Text } from '@/components/ui';
import { LogoUploader } from '../components/LogoUploader';
import { BOARD_OPTIONS, SESSION_OPTIONS, useRegisterInstitute, type InstituteType } from '../hooks/useRegisterInstitute';

const INSTITUTE_TYPES: InstituteType[] = ['Coaching', 'School', 'Tuition'];

export function RegisterInstituteScreen() {
  const router = useRouter();
  const { register, loading, created } = useRegisterInstitute();
  const [logoUri, setLogoUri] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [type, setType] = useState<InstituteType>('Coaching');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Patna');
  const [stateVal, setStateVal] = useState('Bihar');
  const [board, setBoard] = useState('CBSE');
  const [session, setSession] = useState('2026-27');
  const [ownerName, setOwnerName] = useState('');
  const [showCode, setShowCode] = useState(false);

  const handlePickLogo = () => {
    // Simulate picker: toggle dummy uri
    if (logoUri) setLogoUri(null);
    else setLogoUri('https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=200');
  };

  const handleSubmit = async () => {
    const inst = await register({ name, type, address, city, state: stateVal, board, academicSession: session, ownerName, logoUri });
    if (inst) setShowCode(true);
  };

  const handleCopy = async () => {
    if (!created) return;
    const text = created.code;
    try {
      if (Platform.OS === 'web' && navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        Alert.alert('Copied', `${text} copied to clipboard`);
      } else {
        // fallback toast via Alert
        Alert.alert('Institute code', text);
      }
    } catch {
      Alert.alert('Institute code', text);
    }
  };

  if (created && showCode) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
        <ScrollView contentContainerStyle={{ padding: LAYOUT.margin, gap: 16, flexGrow: 1 }} showsVerticalScrollIndicator={false}>
          <View style={{ alignItems: 'center', marginTop: 24, gap: 8 }}>
            <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: C.successSoft, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="checkmark" size={32} color={C.success} />
            </View>
            <Text variant="h1" style={{ textAlign: 'center' }}>
              {created.name} is ready!
            </Text>
            <Text variant="body" c={C.secondary} style={{ textAlign: 'center' }}>
              Your institute has been created with default settings and 3 fee terms.
            </Text>
          </View>

          {/* Navy card with code */}
          <Card pad={20} style={{ backgroundColor: C.primary, borderColor: C.primary }}>
            <View style={{ gap: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Ionicons name="key-outline" size={18} color={C.surface} />
                  <Text variant="label" c={C.navyMid}>
                    YOUR INSTITUTE CODE
                  </Text>
                </View>
                <View style={{ backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 999 }}>
                  <Text variant="label" c={C.surface} style={{ fontSize: 10 }}>
                    ACTIVE
                  </Text>
                </View>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
                <Text variant="h1" c={C.surface} style={{ fontFamily: 'monospace', letterSpacing: 1.2, flex: 1 }}>
                  {created.code}
                </Text>
                <Pressable
                  onPress={handleCopy}
                  accessibilityRole="button"
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 12,
                    backgroundColor: C.surface,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Ionicons name="copy-outline" size={18} color={C.primary} />
                </Pressable>
              </View>
              <View style={{ height: 1, backgroundColor: 'rgba(255,255,255,0.15)' }} />
              <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-start' }}>
                <Ionicons name="share-social-outline" size={16} color={C.navyMid} style={{ marginTop: 2 }} />
                <Text variant="caption" c={C.surface} style={{ flex: 1, opacity: 0.9 }}>
                  Share this code so students and parents can find you.
                </Text>
              </View>
            </View>
          </Card>

          <View style={{ gap: 12, marginTop: 8 }}>
            <Button title="Go to dashboard" onPress={() => router.replace('/(owner)' as never)} icon="arrow-forward" />
            <Button title="Copy code & share" variant="outline" onPress={handleCopy} icon="share-outline" />
          </View>

          <Card flat pad={14} tint={C.navySoft} style={{ borderColor: C.hairline }}>
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}>
              <Ionicons name="information-circle-outline" size={18} color={C.primary} />
              <Text variant="caption" c={C.secondary} style={{ flex: 1 }}>
                Students will search your institute by name or code. You’ll approve them in the Approvals queue — no typing needed.
              </Text>
            </View>
          </Card>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <ScrollView
        contentContainerStyle={{ padding: LAYOUT.margin, gap: 16, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={{ gap: 6 }}>
          <Text variant="h1">Register your institute</Text>
          <Text variant="body" c={C.secondary}>
            Get set up in under 3 minutes. No student data needed.
          </Text>
        </View>

        <Card>
          <View style={{ gap: 18 }}>
            <View style={{ alignItems: 'center', paddingVertical: 4 }}>
              <LogoUploader uri={logoUri} onPick={handlePickLogo} />
            </View>

            <View style={{ gap: 4 }}>
              <Text variant="label" c={C.secondary}>
                Institute name *
              </Text>
              <Input placeholder="e.g. Sunrise Coaching Classes" value={name} onChangeText={setName} returnKeyType="next" />
            </View>

            <View style={{ gap: 8 }}>
              <Text variant="label" c={C.secondary}>
                Institute type
              </Text>
              <SegmentedControl options={INSTITUTE_TYPES} value={type} onChange={setType} />
            </View>

            <View style={{ gap: 4 }}>
              <Text variant="label" c={C.secondary}>
                Address
              </Text>
              <Input placeholder="Street, locality" value={address} onChangeText={setAddress} />
            </View>

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <View style={{ flex: 1, gap: 4 }}>
                <Text variant="label" c={C.secondary}>
                  City *
                </Text>
                <Input placeholder="Patna" value={city} onChangeText={setCity} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text variant="label" c={C.secondary}>
                  State
                </Text>
                <Input placeholder="Bihar" value={stateVal} onChangeText={setStateVal} />
              </View>
            </View>

            <View style={{ flexDirection: 'row', gap: 12 }}>
              <View style={{ flex: 1 }}>
                <Select
                  label="Board"
                  placeholder="Select board"
                  value={board}
                  options={BOARD_OPTIONS.map((o) => ({ label: o.label, value: o.value }))}
                  onChange={(v) => setBoard(v as string)}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Select
                  label="Academic session"
                  placeholder="2026-27"
                  value={session}
                  options={SESSION_OPTIONS.map((o) => ({ label: o.label, value: o.value }))}
                  onChange={(v) => setSession(v as string)}
                />
              </View>
            </View>

            <View style={{ gap: 4 }}>
              <Text variant="label" c={C.secondary}>
                Your name (owner) *
              </Text>
              <Input placeholder="Rahul Sharma" value={ownerName} onChangeText={setOwnerName} />
            </View>
          </View>
        </Card>

        <Card flat tint={C.warningSoft} pad={14} style={{ borderColor: '#FDE68A' }}>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: C.surface, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="shield-checkmark" size={16} color={C.warning} />
            </View>
            <View style={{ flex: 1, gap: 4 }}>
              <Text variant="caption" weight={700} c={C.ink}>
                One tap creates everything
              </Text>
              <Text variant="caption" c={C.secondary}>
                We’ll create your institute, owner membership, default settings, 3 fee terms & audit record — no extra steps.
              </Text>
            </View>
          </View>
        </Card>

        <Button title={loading ? 'Creating institute...' : 'Create institute'} loading={loading} onPress={handleSubmit} icon="rocket-outline" />
        <Text variant="caption" c={C.muted} style={{ textAlign: 'center' }}>
          Code like SUNRISE-PAT is generated automatically
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
