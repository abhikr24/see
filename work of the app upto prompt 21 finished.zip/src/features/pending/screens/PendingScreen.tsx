import React from 'react';
import { View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { C, LAYOUT, R } from '@/lib/theme';
import { Button, Card, Text } from '@/components/ui';
import { usePending } from '../hooks/usePending';

export function PendingScreen() {
  const { membership, institute, loading, cancelling, cancel } = usePending();

  if (loading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}>
        <Text c={C.muted}>Loading your request…</Text>
      </SafeAreaView>
    );
  }

  if (!membership) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center', padding: LAYOUT.margin }}>
        <Card>
          <Text variant="title">No pending request</Text>
          <Text variant="body" c={C.secondary} style={{ marginTop: 8 }}>
            You don’t have a pending join request. Search for an institute to join.
          </Text>
        </Card>
      </SafeAreaView>
    );
  }

  const requestedAt = new Date(membership.requestedAt);
  const isPending = membership.status === 'pending';

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.canvas }} edges={['top', 'bottom']}>
      <View style={{ flex: 1, padding: LAYOUT.margin, gap: 16 }}>
        <View style={{ gap: 6 }}>
          <Text variant="h1">Membership pending</Text>
          <Text variant="body" c={C.secondary}>
            You’re in the waiting room. We’ll move you automatically when approved — no restart needed.
          </Text>
        </View>

        {/* Institute card */}
        <Card pad={16}>
          <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
            <View style={{ width: 56, height: 56, borderRadius: 14, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' }}>
              <Text variant="h2" c={C.surface}>
                {(institute?.name ?? 'IN').slice(0, 2).toUpperCase()}
              </Text>
            </View>
            <View style={{ flex: 1, gap: 4 }}>
              <Text variant="title" numberOfLines={1}>
                {institute?.name ?? 'Institute'}
              </Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Ionicons name="key-outline" size={12} color={C.muted} />
                <Text variant="label" c={C.muted}>
                  {institute?.code ?? membership.instituteId.slice(0, 8)}
                </Text>
                <View style={{ backgroundColor: C.track, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 999 }}>
                  <Text variant="label" c={C.secondary} style={{ fontSize: 10 }}>
                    {(institute?.tagline as string) ?? membership.role}
                  </Text>
                </View>
              </View>
              <Text variant="caption" c={C.secondary}>
                {institute?.city ?? ''}{institute?.state ? `, ${institute.state}` : ''} · {institute?.address ?? ''}
              </Text>
            </View>
          </View>
          <View style={{ height: 1, backgroundColor: C.hairline, marginVertical: 14 }} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ gap: 2 }}>
              <Text variant="label" c={C.muted}>
                REQUESTED
              </Text>
              <Text variant="caption" c={C.ink}>
                {requestedAt.toLocaleString()}
              </Text>
            </View>
            <View style={{ alignItems: 'flex-end', gap: 2 }}>
              <Text variant="label" c={C.muted}>
                ROLE
              </Text>
              <View style={{ backgroundColor: C.navySoft, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 }}>
                <Text variant="caption" c={C.primary} weight={700}>
                  {membership.role.toUpperCase()}
                </Text>
              </View>
            </View>
          </View>
        </Card>

        {/* Amber waiting row */}
        {isPending ? (
          <Card pad={14} style={{ backgroundColor: C.warningSoft, borderColor: '#FDE68A' }}>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: C.surface, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="time-outline" size={18} color={C.warning} />
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <Text variant="body" weight={700} c={C.ink}>
                  Waiting for approval
                </Text>
                <Text variant="caption" c={C.secondary}>
                  The owner will review your request. You’ll be moved to your home automatically.
                </Text>
              </View>
              <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.warning }} />
            </View>
          </Card>
        ) : (
          <Card pad={14} style={{ backgroundColor: C.successSoft, borderColor: '#BBF7D0' }}>
            <View style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
              <Ionicons name="checkmark-circle" size={20} color={C.success} />
              <Text variant="body" c={C.success} weight={600}>
                {membership.status === 'active' ? 'Approved — redirecting…' : `Status: ${membership.status}`}
              </Text>
            </View>
          </Card>
        )}

        {/* Live indicator */}
        <Card flat tint={C.surface} pad={12} style={{ borderStyle: 'dashed' }}>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.success }} />
            <Text variant="caption" c={C.secondary}>
              Live — approval flips this screen without a restart (RealtimePort)
            </Text>
          </View>
        </Card>

        <View style={{ flex: 1 }} />

        {isPending ? (
          <View style={{ gap: 12 }}>
            <Button title="Cancel request" variant="outline" onPress={cancel} loading={cancelling} icon="close-circle-outline" />
            <Text variant="caption" c={C.muted} style={{ textAlign: 'center' }}>
              Cancels and removes the pending membership. You can join again later.
            </Text>
          </View>
        ) : null}
      </View>
    </SafeAreaView>
  );
}
