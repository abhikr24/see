import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import { C } from '@/lib/theme';
import { isDevAuthBypassEnabled } from '@/store/session';

/**
 * Amber strip shown at the very top of the app while the dev-only auth
 * bypass is active, so a bypassed build can never be mistaken for a real
 * signed-in one in a screenshot or a shared preview. Renders nothing when
 * the bypass is off (always the case in production: `__DEV__` is false).
 */
export function DevAuthBypassBanner() {
  if (__DEV__ && process.env.EXPO_PUBLIC_DEV_AUTH) {
    if (!isDevAuthBypassEnabled()) return null;
  } else {
    return null;
  }

  return (
    <SafeAreaView edges={['top']} style={{ backgroundColor: C.warning }}>
      <View
        accessibilityRole="alert"
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 8,
          paddingHorizontal: 16,
          paddingVertical: 8,
          backgroundColor: C.warning,
        }}
      >
        <Ionicons name="warning-outline" size={16} color={C.ink} />
        <Text variant="label" weight={800} c={C.ink} numberOfLines={1}>
          DEV BYPASS — auth disabled
        </Text>
      </View>
    </SafeAreaView>
  );
}
