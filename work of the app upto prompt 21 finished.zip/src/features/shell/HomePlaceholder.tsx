import React from 'react';
import { Card, Screen, Text } from '@/components/ui';
import { useInstitute } from '@/core/backend';
import { C, S } from '@/lib/theme';
import { useSessionStore } from '@/store/session';

export interface HomePlaceholderProps {
  prompt: string;
  title: string;
  description: string;
  /** Role-specific extra content, e.g. a link to a feature that already exists. */
  extra?: React.ReactNode;
}

function firstName(name?: string | null): string {
  const first = name?.trim().split(/\s+/)[0];
  return first && first.length > 0 ? first : 'there';
}

function greeting(hour: number): string {
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

/**
 * The Home tab before the real dashboard exists: a greeting, the active
 * institute's name, and a card naming the prompt that will build this
 * screen for real. Deleted the moment that prompt lands.
 */
export function HomePlaceholder({ prompt, title, description, extra }: HomePlaceholderProps) {
  const { user } = useSessionStore();
  const institute = useInstitute();

  return (
    <Screen
      title={`${greeting(new Date().getHours())}, ${firstName(user?.fullName)}`}
      subtitle={institute.data?.name ?? 'Loading institute…'}
      safeTop={false}
      tabBarInset={96}
    >
      <Card flat>
        <Text variant="label" c={C.accent}>
          {prompt}
        </Text>
        <Text variant="title" style={{ marginTop: S.xs }}>
          {title}
        </Text>
        <Text variant="body" c={C.secondary} style={{ marginTop: S.xs }}>
          {description}
        </Text>
      </Card>
      {extra}
    </Screen>
  );
}
