import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Redirect, router, Slot, useSegments } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';

import { useInstitute } from '@/core/backend';
import type { Role } from '@/core/contracts/models';
import { Avatar, InstituteSwitcher, TabBar, Text } from '@/components/ui';
import { TABS } from '@/lib/nav';
import { C, LAYOUT, R } from '@/lib/theme';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { groupForRole, useRouteResolution } from '@/store/session';
import { ShellLoading } from './ShellLoading';

export interface RoleTabShellProps {
  /** The role this shell is built for. owner's shell also serves admin memberships. */
  role: Exclude<Role, 'admin'>;
}

/**
 * The tab shell every role group mounts from its `_layout.tsx`:
 *   - guards the group so only the matching, active role can see it,
 *   - a slim header that opens the institute switcher from anywhere,
 *   - the matched tab screen in the middle (expo-router `Slot`),
 *   - the floating pill tab bar, built only from `TABS` in `src/lib/nav.ts`.
 */
export function RoleTabShell({ role }: RoleTabShellProps) {
  const expectedGroup = groupForRole(role);
  const { status, group, destination } = useRouteResolution();
  const { signOut, loading: signingOut } = useAuth();
  const segments = useSegments();
  const institute = useInstitute();
  const [switcherOpen, setSwitcherOpen] = useState(false);

  if (status === 'loading' || destination.length === 0) return <ShellLoading />;
  if (status !== 'ready' || group !== expectedGroup) {
    return <Redirect href={destination as never} />;
  }

  const tabs = TABS[role];
  // Segments look like ['(owner)'] for the home tab or ['(owner)', 'students'] for others.
  const segmentList = segments as readonly string[];
  const selectedKey = segmentList[1] ?? 'home';

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <SafeAreaView edges={['top']} style={{ backgroundColor: C.canvas }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Switch institute"
          onPress={() => setSwitcherOpen(true)}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
            marginLeft: LAYOUT.margin,
            marginTop: 8,
            paddingVertical: 8,
            paddingHorizontal: 10,
            borderRadius: R.btn,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Avatar name={institute.data?.name ?? '…'} uri={institute.data?.logoUrl} size={34} />
          <View style={{ flex: 1 }}>
            <Text variant="label" c={C.muted}>
              Institute
            </Text>
            <Text variant="title" weight={700} numberOfLines={1}>
              {institute.data?.name ?? 'Loading…'}
            </Text>
          </View>
          <Ionicons name="chevron-expand-outline" size={18} color={C.muted} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Sign out"
          onPress={() => void signOut()}
          disabled={signingOut}
          hitSlop={8}
          style={{ marginRight: LAYOUT.margin, marginTop: 8, paddingVertical: 8, paddingLeft: 8, opacity: signingOut ? 0.5 : 1 }}
        >
          <Text variant="label" c={C.secondary} weight={600}>
            Sign out
          </Text>
        </Pressable>
        </View>
      </SafeAreaView>

      <View style={{ flex: 1 }}>
        <Slot />
      </View>

      <View pointerEvents="box-none" style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        <SafeAreaView edges={['bottom']}>
          <View style={{ paddingHorizontal: 12, paddingBottom: 6 }}>
            <TabBar
              tabs={tabs}
              selectedKey={selectedKey}
              onSelect={(key) => {
                const tab = tabs.find((t) => t.key === key);
                if (tab) router.replace(tab.route as never);
              }}
            />
          </View>
        </SafeAreaView>
      </View>

      <InstituteSwitcher visible={switcherOpen} onClose={() => setSwitcherOpen(false)} />
    </View>
  );
}
