import React from 'react';
import { ActivityIndicator, View } from 'react-native';

import { C } from '@/lib/theme';

/** Shown for the instant between "app opened" and "we know where you belong". */
export function ShellLoading() {
  return (
    <View style={{ flex: 1, backgroundColor: C.canvas, alignItems: 'center', justifyContent: 'center' }}>
      <ActivityIndicator color={C.primary} />
    </View>
  );
}
