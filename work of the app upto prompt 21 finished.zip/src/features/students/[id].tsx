import React, { useCallback, useEffect, useState } from 'react';
import { Linking, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ErrorState, SegmentedControl, Text } from '@/components/ui';
import { toast } from '@/core/backend';
import { C, LAYOUT, R } from '@/lib/theme';
import { ProfileHero } from './components/ProfileHero';
import { useStudentAttendance } from './hooks/useStudentAttendance';
import { useStudentFees } from './hooks/useStudentFees';
import { useStudentHeader } from './hooks/useStudentHeader';
import { useStudentMarks } from './hooks/useStudentMarks';
import { useStudentOverview } from './hooks/useStudentOverview';
import { PROFILE_TABS, type ProfileTab } from './profile';
import { AttendanceTab } from './tabs/Attendance';
import { FeesTab } from './tabs/Fees';
import { MarksTab } from './tabs/Marks';
import { OverviewTab } from './tabs/Overview';

/** Clears the floating owner tab bar. */
const TAB_BAR_INSET = 100;

/**
 * Student 360 — one connected record, readable in ten seconds.
 * Each tab has its own hook, enabled the first time it is focused.
 */
export function StudentProfileScreen({ id }: { id: string }) {
  const studentId = id || null;
  const [tab, setTab] = useState<ProfileTab>('overview');
  const [seen, setSeen] = useState<Record<ProfileTab, boolean>>({
    overview: true,
    attendance: false,
    marks: false,
    fees: false,
  });

  useEffect(() => {
    setSeen((current) => (current[tab] ? current : { ...current, [tab]: true }));
  }, [tab]);

  const header = useStudentHeader(studentId);
  const overview = useStudentOverview(studentId, seen.overview);
  const attendance = useStudentAttendance(studentId, seen.attendance);
  const marks = useStudentMarks(studentId, seen.marks);
  const fees = useStudentFees(studentId, seen.fees);

  const messageParent = useCallback(async () => {
    const url = header.data?.whatsappUrl;
    if (!url) {
      toast.info('No parent mobile on file');
      return;
    }
    const allowed = await Linking.canOpenURL(url);
    if (!allowed) {
      toast.error('Could not open WhatsApp');
      return;
    }
    await Linking.openURL(url);
  }, [header.data?.whatsappUrl]);

  const intervene = useCallback(
    (alertId: string) => {
      const risk = overview.data?.risks.find((item) => item.id === alertId);
      if (risk) void overview.createIntervention({ alert: risk });
    },
    [overview],
  );

  if (!studentId) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState title="Student not found" message="This profile has no id." />
      </View>
    );
  }

  if (header.error && !header.data) {
    return (
      <View style={{ flex: 1, backgroundColor: C.canvas }}>
        <ErrorState message={header.error.message} onRetry={() => void header.refetch()} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <ScrollView
        stickyHeaderIndices={[1]}
        contentContainerStyle={{ paddingBottom: 16 }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <ProfileHero view={header.data} loading={header.loading} />
        <View style={{ backgroundColor: C.canvas, paddingHorizontal: LAYOUT.margin, paddingTop: 16, paddingBottom: 12 }}>
          <SegmentedControl options={PROFILE_TABS} value={tab} onChange={setTab} />
        </View>
        <View style={{ paddingHorizontal: LAYOUT.margin }}>
          {tab === 'overview' ? (
            <OverviewTab
              data={overview.data}
              loading={overview.loading}
              error={overview.error?.message ?? null}
              onRetry={() => void overview.refetch()}
              onIntervene={intervene}
              creating={overview.creating}
            />
          ) : null}
          {tab === 'attendance' ? (
            <AttendanceTab
              data={attendance.data}
              loading={attendance.loading}
              error={attendance.error?.message ?? null}
              onRetry={() => void attendance.refetch()}
            />
          ) : null}
          {tab === 'marks' ? (
            <MarksTab
              data={marks.data}
              loading={marks.loading}
              error={marks.error?.message ?? null}
              onRetry={() => void marks.refetch()}
            />
          ) : null}
          {tab === 'fees' ? (
            <FeesTab
              data={fees.data}
              loading={fees.loading}
              error={fees.error?.message ?? null}
              onRetry={() => void fees.refetch()}
            />
          ) : null}
        </View>
      </ScrollView>

      <View
        style={{
          paddingHorizontal: LAYOUT.margin,
          paddingTop: 8,
          paddingBottom: TAB_BAR_INSET,
          backgroundColor: C.canvas,
          borderTopWidth: 1,
          borderTopColor: C.hairline,
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Message parent"
          onPress={() => void messageParent()}
          style={({ pressed }) => ({
            height: 56,
            borderRadius: R.btn,
            borderWidth: 1,
            borderColor: C.primary,
            backgroundColor: C.transparent,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Ionicons name="logo-whatsapp" size={20} color={C.primary} />
          <Text variant="body" weight={600} c={C.primary} style={{ fontSize: 16 }}>
            Message parent
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

export { StudentProfileScreen as StudentDetailScreen };
