import type { Backend } from '@/core/contracts/ports';
import type { FeeStructure, ID } from '@/core/contracts/models';
import { toBackendError } from '@/core/contracts/errors';
import { todayISO } from '@/lib/format';
import type { AdmitDraft, StudentRow } from './types';

async function rollback(backend: Backend, instituteId: ID, studentId: ID): Promise<void> {
  const batches = await backend.batches.list(instituteId, { limit: 100 });
  for (const batch of batches.items) {
    const enrollments = await backend.batches.listEnrollments(instituteId, batch.id);
    for (const enrollment of enrollments) {
      if (enrollment.studentId === studentId && enrollment.status === 'active') {
        await backend.batches.unenroll(instituteId, enrollment.id).catch(() => undefined);
      }
    }
  }
  await backend.students.remove(instituteId, studentId).catch(() => undefined);
}

async function ensureMonthly(backend: Backend, instituteId: ID, batchId: ID, amount: number): Promise<FeeStructure> {
  const page = await backend.fees.listStructures(instituteId, { limit: 100 });
  const found = page.items.find(
    (structure) =>
      structure.isActive && structure.frequency === 'monthly' && structure.batchId === batchId && structure.totalAmount === amount,
  );
  if (found) return found;
  const batch = await backend.batches.get(instituteId, batchId);
  return backend.fees.saveStructure(instituteId, {
    name: `${batch.name} monthly`,
    academicYear: batch.academicYear,
    totalAmount: amount,
    batchId,
    frequency: 'monthly',
    installmentCount: 1,
    components: [],
    lateFeePerDay: 0,
    isActive: true,
  });
}

/** Creates the student, enrolment, parent and monthly fee. Rolls back the student if a later step fails. */
export async function admitStudent(backend: Backend, instituteId: ID, draft: AdmitDraft): Promise<StudentRow> {
  const batchId = draft.batchId as ID;
  const roll = Number(draft.roll);
  const monthlyFee = Number(draft.monthlyFee);
  const fullName = draft.fullName.trim();
  const parentName = draft.parentName.trim();
  let created = false;
  let studentId = '';
  try {
    const student = await backend.students.create(instituteId, {
      fullName,
      phone: draft.parentPhone,
      photoUrl: draft.photoUri,
      status: 'active',
    });
    created = true;
    studentId = student.id;
    await backend.batches.enroll(instituteId, batchId, { studentId, rollNumber: roll });
    const guardian = await backend.guardians.create(instituteId, {
      fullName: parentName.length >= 2 ? parentName : 'Parent',
      relation: 'guardian',
      phone: draft.parentPhone,
    });
    await backend.guardians.link(instituteId, { studentId, guardianId: guardian.id, isPrimary: true });
    const structure = await ensureMonthly(backend, instituteId, batchId, monthlyFee);
    await backend.fees.assign(instituteId, {
      studentId,
      feeStructureId: structure.id,
      firstDueDate: todayISO(),
    });
    if (draft.photoUri) {
      await backend.storage
        .upload(instituteId, {
          ownerType: 'student',
          ownerId: studentId,
          studentId,
          fileName: 'photo.jpg',
          uri: draft.photoUri,
          mimeType: 'image/jpeg',
        })
        .catch(() => undefined);
    }
    const batch = await backend.batches.get(instituteId, batchId);
    return {
      id: studentId,
      fullName,
      photoUrl: draft.photoUri,
      batchId,
      batchName: batch.name,
      roll,
      monthlyFee,
      due: monthlyFee > 0 ? monthlyFee : 0,
      absentToday: false,
      attendancePercent: null,
      parentName: parentName.length >= 2 ? parentName : null,
      parentPhone: draft.parentPhone,
    };
  } catch (cause) {
    if (created) await rollback(backend, instituteId, studentId);
    throw toBackendError(cause);
  }
}
