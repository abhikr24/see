import type { Batch } from '@/core/contracts/models';
import type { StudentRow } from './types';

type Listener = () => void;

class RosterCache {
  rows: StudentRow[] | null = null;
  batches: Batch[] = [];
  private readonly listeners = new Set<Listener>();

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(): void {
    this.listeners.forEach((listener) => listener());
  }

  write(rows: StudentRow[], batches: Batch[]): void {
    this.rows = rows;
    this.batches = batches;
    this.emit();
  }

  prepend(row: StudentRow): void {
    this.rows = [row, ...(this.rows ?? []).filter((item) => item.id !== row.id)];
    this.emit();
  }
}

export const rosterCache = new RosterCache();
