import React from 'react';
import { Pressable, View } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { C } from '@/lib/theme';
import { Text } from '@/components/ui';

const PHOTO = 120;
const SIZE = 144;
const STROKE = 6;

export function PhotoRing({
  uri,
  filled,
  total = 5,
  onLibrary,
  onCamera,
}: {
  uri: string | null;
  filled: number;
  total?: number;
  onLibrary: () => void;
  onCamera: () => void;
}) {
  const r = (SIZE - STROKE) / 2;
  const circ = 2 * Math.PI * r;
  const value = Math.max(0, Math.min(1, filled / total));
  return (
    <View style={{ alignItems: 'center', gap: 8 }}>
      <View style={{ width: SIZE, height: SIZE, alignItems: 'center', justifyContent: 'center' }}>
        <Svg width={SIZE} height={SIZE} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
          <Circle cx={SIZE / 2} cy={SIZE / 2} r={r} stroke={C.track} strokeWidth={STROKE} fill="none" />
          <Circle
            cx={SIZE / 2}
            cy={SIZE / 2}
            r={r}
            stroke={filled === total ? C.teal : C.primary}
            strokeWidth={STROKE}
            fill="none"
            strokeDasharray={`${circ}`}
            strokeDashoffset={circ - circ * value}
            strokeLinecap="round"
          />
        </Svg>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={uri ? 'Change photo from library' : 'Add photo from library'}
          onPress={onLibrary}
          style={{
            width: PHOTO,
            height: PHOTO,
            borderRadius: PHOTO / 2,
            backgroundColor: C.navySoft,
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
          }}
        >
          {uri ? (
            <Image source={{ uri }} style={{ width: PHOTO, height: PHOTO }} contentFit="cover" accessibilityLabel="Student photo" />
          ) : (
            <Ionicons name="person" size={42} color={C.primary} />
          )}
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Take a photo"
          onPress={onCamera}
          style={{
            position: 'absolute',
            right: 4,
            bottom: 4,
            width: 36,
            height: 36,
            borderRadius: 18,
            backgroundColor: C.accent,
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 2,
            borderColor: C.surface,
          }}
        >
          <Ionicons name="camera" size={18} color={C.surface} />
        </Pressable>
      </View>
      <Text variant="caption" c={C.secondary} tabular>
        {filled} of {total} fields
      </Text>
    </View>
  );
}
