import React from 'react';
import { Pressable, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Avatar, Skeleton, Text } from '@/components/ui';
import { C, GRADIENT, LAYOUT, R } from '@/lib/theme';
import type { HeaderChip, StudentHeaderView } from '../hooks/useStudentHeader';

function Chip({ label }: { label: string }) {
  return (
    <View
      style={{
        backgroundColor: C.surface,
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: R.chip,
      }}
    >
      <Text variant="label" weight={700} c={C.primary} tabular style={{ textTransform: 'none', letterSpacing: 0 }}>
        {label}
      </Text>
    </View>
  );
}

export function ProfileHero({ view, loading }: { view: StudentHeaderView | undefined; loading: boolean }) {
  return (
    <LinearGradient
      colors={[GRADIENT[0], GRADIENT[1]]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 4, paddingBottom: 22 }}
    >
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Back to students"
        onPress={() => router.back()}
        hitSlop={8}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start', minHeight: 44 }}
      >
        <Ionicons name="chevron-back" size={20} color={C.surface} />
        <Text variant="caption" weight={700} c={C.surface}>
          Students
        </Text>
      </Pressable>

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 8 }}>
        {loading && !view ? (
          <View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: C.navySoft }} />
        ) : (
          <Avatar name={view?.name ?? 'Student'} uri={view?.photoUrl} size={72} />
        )}
        <View style={{ flex: 1, gap: 4 }}>
          {loading && !view ? (
            <>
              <Skeleton h={22} w="70%" r={8} />
              <Skeleton h={13} w="90%" r={6} />
            </>
          ) : (
            <>
              <Text weight={800} c={C.surface} numberOfLines={2} style={{ fontSize: 22, lineHeight: 28 }}>
                {view?.name ?? 'Student'}
              </Text>
              <Text variant="caption" c={C.surface} numberOfLines={2} style={{ opacity: 0.7 }}>
                {view?.meta ?? ''}
              </Text>
            </>
          )}
        </View>
      </View>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 16 }}>
        {(view?.chips ?? placeholderChips()).map((chip) => (
          <Chip key={chip.key} label={chip.label} />
        ))}
      </View>
    </LinearGradient>
  );
}

function placeholderChips(): HeaderChip[] {
  return [
    { key: 'attendance', label: '\u2014' },
    { key: 'average', label: '\u2014' },
    { key: 'fees', label: '\u2014' },
  ];
}
