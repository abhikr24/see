import React from 'react';
import { View } from 'react-native';
import { Button, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import type { RiskView } from '../hooks/useStudentOverview';

export function RiskCard({
  risk,
  onCreate,
  creating,
}: {
  risk: RiskView;
  onCreate: () => void;
  creating: boolean;
}) {
  return (
    <View
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        overflow: 'hidden',
        flexDirection: 'row',
      }}
    >
      <View style={{ width: 4, backgroundColor: C.warning }} />
      <View style={{ flex: 1, padding: 18, gap: 12 }}>
        <Text variant="label" c={C.warning}>
          Risk
        </Text>
        <Text variant="body" weight={600}>
          {risk.copy}
        </Text>
        <Button
          title="Create intervention"
          size="md"
          variant="primary"
          loading={creating}
          onPress={onCreate}
        />
      </View>
    </View>
  );
}
