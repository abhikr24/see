import React, { useState } from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Chip, SearchBar, Text } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';
import { summaryLine, type ChipKey, type SortKey } from '../types';

const SORTS: { key: SortKey; label: string }[] = [
  { key: 'name', label: 'Name' },
  { key: 'roll', label: 'Roll' },
  { key: 'dues', label: 'Dues' },
  { key: 'attendance', label: 'Attendance' },
];

export function StudentListHeader({
  total,
  chipCounts,
  chip,
  onChip,
  sort,
  onSort,
  search,
  onSearch,
  shown,
  shownDues,
  onAdd,
}: {
  total: number;
  chipCounts: { overdue: number; batches: { id: string; name: string; count: number }[] };
  chip: ChipKey;
  onChip: (chip: ChipKey) => void;
  sort: SortKey;
  onSort: (sort: SortKey) => void;
  search: string;
  onSearch: (value: string) => void;
  shown: number;
  shownDues: number;
  onAdd: () => void;
}) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const sortLabel = SORTS.find((item) => item.key === sort)?.label ?? 'Name';

  return (
    <View style={{ backgroundColor: C.surface, paddingTop: 4, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: C.hairline }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: LAYOUT.margin, gap: 10 }}>
        <Text variant="h1" style={{ flex: 1 }}>
          Students
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={searchOpen ? 'Close search' : 'Search students'}
          onPress={() => {
            setSearchOpen((open) => {
              if (open) onSearch('');
              return !open;
            });
          }}
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: searchOpen ? C.primary : C.surface,
            borderWidth: 1,
            borderColor: searchOpen ? C.primary : C.hairline,
          }}
        >
          <Ionicons name="search" size={18} color={searchOpen ? C.surface : C.primary} />
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Add student"
          onPress={onAdd}
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: C.primary,
          }}
        >
          <Ionicons name="add" size={22} color={C.surface} />
        </Pressable>
      </View>
      {searchOpen ? (
        <View style={{ paddingHorizontal: LAYOUT.margin, marginTop: 12 }}>
          <SearchBar value={search} onChangeText={onSearch} placeholder="Search name, roll or phone" />
        </View>
      ) : null}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, gap: 8, paddingTop: 14 }}
      >
        <Chip label="All" count={total} active={chip === 'all'} onPress={() => onChip('all')} />
        {chipCounts.batches.map((batch) => (
          <Chip
            key={batch.id}
            label={batch.name}
            count={batch.count}
            active={chip === `batch:${batch.id}`}
            onPress={() => onChip(`batch:${batch.id}`)}
          />
        ))}
        <Chip label="Overdue" count={chipCounts.overdue} active={chip === 'overdue'} onPress={() => onChip('overdue')} />
      </ScrollView>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: LAYOUT.margin, marginTop: 12 }}>
        <Text variant="caption" c={C.secondary} tabular>
          {summaryLine(shown, shownDues)}
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Sort by ${sortLabel}`}
          onPress={() => setSortOpen(true)}
          style={{ flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 32 }}
        >
          <Text variant="caption" weight={700} c={C.primary}>
            {sortLabel}
          </Text>
          <Ionicons name="chevron-down" size={14} color={C.primary} />
        </Pressable>
      </View>
      <Modal visible={sortOpen} transparent animationType="fade" onRequestClose={() => setSortOpen(false)}>
        <Pressable accessibilityLabel="Close sort menu" style={{ flex: 1, backgroundColor: C.scrim }} onPress={() => setSortOpen(false)}>
          <View style={{ marginTop: 180, marginHorizontal: 48, backgroundColor: C.surface, borderRadius: R.card, paddingVertical: 8 }}>
            {SORTS.map((item) => {
              const selected = item.key === sort;
              return (
                <Pressable
                  key={item.key}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  onPress={() => {
                    onSort(item.key);
                    setSortOpen(false);
                  }}
                  style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18, paddingVertical: 14 }}
                >
                  <Text variant="body" weight={selected ? 700 : 500} c={selected ? C.primary : C.ink}>
                    {item.label}
                  </Text>
                  {selected ? <Ionicons name="checkmark" size={18} color={C.primary} /> : null}
                </Pressable>
              );
            })}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}
