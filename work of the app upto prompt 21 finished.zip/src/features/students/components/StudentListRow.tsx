import React from 'react';
import { Pressable, View } from 'react-native';
import { Avatar, Text } from '@/components/ui';
import { C, LAYOUT, R } from '@/lib/theme';
import { dueLabel, rowSubtitle, type StudentRow } from '../types';

export function StudentListRow({ row, onPress }: { row: StudentRow; onPress: () => void }) {
  const due = row.due > 0;
  const subtitle = rowSubtitle(row);
  const pill = dueLabel(row.due);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${row.fullName}, ${subtitle}, ${pill}${row.absentToday ? ', absent today' : ''}`}
      onPress={onPress}
      style={({ pressed }) => ({
        height: 72,
        marginHorizontal: LAYOUT.margin,
        marginBottom: 8,
        paddingHorizontal: 12,
        borderRadius: R.btn,
        backgroundColor: C.surface,
        borderWidth: 1,
        borderColor: C.hairline,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        opacity: pressed ? 0.92 : 1,
      })}
    >
      <Avatar name={row.fullName} uri={row.photoUrl} size={48} />
      <View style={{ flex: 1, gap: 2 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Text variant="title" weight={700} numberOfLines={1} style={{ flexShrink: 1 }}>
            {row.fullName}
          </Text>
          {row.absentToday ? (
            <View
              accessibilityLabel="Absent today"
              style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: C.warning }}
            />
          ) : null}
        </View>
        <Text variant="caption" c={C.secondary} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
      <View
        style={{
          backgroundColor: due ? C.dangerSoft : C.tealSoft,
          paddingHorizontal: 10,
          paddingVertical: 5,
          borderRadius: R.chip,
        }}
      >
        <Text variant="label" weight={700} c={due ? C.danger : C.teal} tabular style={{ textTransform: 'none', letterSpacing: 0 }}>
          {pill}
        </Text>
      </View>
    </Pressable>
  );
}
