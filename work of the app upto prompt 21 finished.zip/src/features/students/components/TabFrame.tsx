import React from 'react';
import { View } from 'react-native';
import { Card, EmptyState, ErrorState, Skeleton } from '@/components/ui';
import { TAB_BODY_MIN } from '../profile';

export function TabSkeleton() {
  return (
    <View style={{ gap: 14 }}>
      <Card>
        <View style={{ flexDirection: 'row', gap: 16, alignItems: 'center' }}>
          <Skeleton h={88} w={88} r={44} />
          <View style={{ flex: 1, gap: 10 }}>
            <Skeleton h={12} w="40%" />
            <Skeleton h={12} w="70%" />
            <Skeleton h={12} w="55%" />
          </View>
        </View>
      </Card>
      <Card>
        <View style={{ gap: 12 }}>
          <Skeleton h={12} w="35%" />
          <Skeleton h={10} w="100%" />
          <Skeleton h={10} w="100%" />
          <Skeleton h={10} w="80%" />
        </View>
      </Card>
      <Card>
        <View style={{ gap: 12 }}>
          <Skeleton h={12} w="30%" />
          <Skeleton h={14} w="60%" />
          <Skeleton h={12} w="45%" />
        </View>
      </Card>
    </View>
  );
}

export function TabFrame({
  loading,
  error,
  onRetry,
  empty,
  emptyIcon,
  emptyTitle,
  emptyText,
  children,
}: {
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  empty: boolean;
  emptyIcon?: React.ComponentProps<typeof EmptyState>['icon'];
  emptyTitle: string;
  emptyText: string;
  children: React.ReactNode;
}) {
  return (
    <View style={{ minHeight: TAB_BODY_MIN }}>
      {loading ? (
        <TabSkeleton />
      ) : error ? (
        <ErrorState message={error} onRetry={onRetry} />
      ) : empty ? (
        <EmptyState icon={emptyIcon} title={emptyTitle} text={emptyText} />
      ) : (
        children
      )}
    </View>
  );
}
