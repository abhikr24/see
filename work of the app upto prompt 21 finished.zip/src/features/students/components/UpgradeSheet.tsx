import React from 'react';
import { View } from 'react-native';
import { useSubscription } from '@/core/backend';
import { Button, Sheet, Text } from '@/components/ui';
import { inr } from '@/lib/format';
import { C, R } from '@/lib/theme';

function ordinal(n: number): string {
  const mod100 = n % 100;
  const mod10 = n % 10;
  const suffix = mod100 >= 11 && mod100 <= 13 ? 'th' : mod10 === 1 ? 'st' : mod10 === 2 ? 'nd' : mod10 === 3 ? 'rd' : 'th';
  return `${n}${suffix}`;
}

export function UpgradeSheet({
  visible,
  cap,
  used,
  onClose,
}: {
  visible: boolean;
  cap: number | null;
  used: number | null;
  onClose: () => void;
}) {
  const billing = useSubscription();
  const plans = (billing.data?.plans ?? []).filter((plan) => {
    if (!plan.isActive) return false;
    if (cap == null) return true;
    return plan.maxStudents == null || plan.maxStudents > cap;
  });
  const next = plans[0];
  const blocked = cap != null ? ordinal((used ?? cap) + 1) : null;
  const message =
    cap != null
      ? `Adding the ${blocked} student is blocked. This plan allows ${cap} students and all ${used ?? cap} are already on the roll.`
      : 'This institute has reached its student limit. Upgrade the plan to add another student.';

  return (
    <Sheet visible={visible} onClose={onClose} title="Student limit reached" subtitle={message}>
      {cap != null ? (
        <View style={{ marginBottom: 16 }}>
          <Text variant="title" weight={800} tabular>
            {used ?? cap} of {cap}
          </Text>
          <Text variant="caption" c={C.secondary} style={{ marginTop: 2 }}>
            students used
          </Text>
          <View style={{ height: 8, borderRadius: 4, backgroundColor: C.track, marginTop: 10, overflow: 'hidden' }}>
            <View style={{ width: '100%', height: 8, backgroundColor: C.warning }} />
          </View>
        </View>
      ) : null}
      {next ? (
        <View
          style={{
            borderWidth: 1,
            borderColor: C.hairline,
            borderRadius: R.card,
            padding: 16,
            marginBottom: 16,
            gap: 4,
          }}
        >
          <Text variant="title" weight={700}>
            {next.name}
          </Text>
          <Text variant="caption" c={C.secondary}>
            {next.maxStudents == null ? 'Unlimited students' : `Up to ${next.maxStudents} students`} · {inr(next.priceMonthly)} / month
          </Text>
          <View style={{ marginTop: 10 }}>
            <Button
              title={`Upgrade to ${next.name}`}
              loading={billing.saving}
              onPress={() => {
                void billing.changePlan({ planId: next.id, billingCycle: 'monthly' }).then((result) => {
                  if (result.ok) onClose();
                });
              }}
            />
          </View>
        </View>
      ) : (
        <Text variant="caption" c={C.secondary} style={{ marginBottom: 12 }}>
          You're already on the largest plan. Remove a student or contact support to raise the cap.
        </Text>
      )}
      <Button title="Not now" variant="outline" onPress={onClose} />
    </Sheet>
  );
}
