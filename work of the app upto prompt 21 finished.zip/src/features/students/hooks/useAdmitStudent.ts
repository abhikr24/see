import { useCallback, useState } from 'react';

import { toast, useBackend } from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import { admitStudent } from '../admit';
import { rosterCache } from '../cache';
import { isPlanLimit, planCapOf, validateDraft, type AdmitDraft, type AdmitErrors } from '../types';

export function useAdmitStudent() {
  const { backend, instituteId } = useBackend();
  const [saving, setSaving] = useState(false);
  const [limit, setLimit] = useState<{ cap: number | null; used: number | null } | null>(null);

  const admit = useCallback(
    async (draft: AdmitDraft, mode: 'close' | 'next'): Promise<{ ok: boolean; errors: AdmitErrors }> => {
      const errors = validateDraft(draft, rosterCache.rows ?? []);
      if (Object.keys(errors).length) return { ok: false, errors };
      if (!instituteId) return { ok: false, errors: { fullName: 'Choose an institute first' } };
      setSaving(true);
      try {
        const row = await admitStudent(backend, instituteId, draft);
        rosterCache.prepend(row);
        toast.success(mode === 'next' ? 'Student added \u2014 add the next one' : 'Student added');
        return { ok: true, errors: {} };
      } catch (cause) {
        const error = toBackendError(cause);
        if (isPlanLimit(error)) {
          setLimit(planCapOf(error.details));
          return { ok: false, errors: {} };
        }
        if (error.message.toLowerCase().includes('roll')) {
          return { ok: false, errors: { roll: 'That roll is already used in this batch' } };
        }
        toast.error(error.message);
        return { ok: false, errors: {} };
      } finally {
        setSaving(false);
      }
    },
    [backend, instituteId],
  );

  return { admit, saving, limit, dismissLimit: () => setLimit(null) };
}
