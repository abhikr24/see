import type { HeatmapDay } from '@/components/ui';
import { useDomainQuery } from '@/core/hooks/domain';
import type { AttendanceSummary, ID } from '@/core/contracts/models';
import { pct } from '@/lib/format';
import {
  heatmapDays,
  joinSessions,
  monthKey,
  monthLabel,
  monthRange,
  monthStartOffset,
  recordStatus,
} from '../profile';

export interface MonthBlock {
  key: string;
  label: string;
  percentLabel: string;
  percent: number;
  present: number;
  absent: number;
  late: number;
  total: number;
  days: HeatmapDay[];
  startOffset: number;
}

export interface AttendanceTabView {
  overall: AttendanceSummary | null;
  overallLabel: string;
  months: MonthBlock[];
}

/**
 * Attendance tab. Off until focused. Overall percent is AttendanceRepo.summary
 * with the same filter as the header chip.
 */
export function useStudentAttendance(studentId: ID | null, enabled: boolean) {
  return useDomainQuery<AttendanceTabView>(
    'attendance',
    ['student-tab', studentId],
    async (b, i) => {
      const id = studentId as ID;
      const [overall, records, snapshot] = await Promise.all([
        b.attendance.summary(i, { studentId: id }),
        b.attendance.listRecords(i, { studentId: id }),
        b.progress.computeSnapshot(i, id),
      ]);
      if (overall.total === 0) {
        return { overall: null, overallLabel: '\u2014', months: [] };
      }
      const sessions = snapshot.batchId
        ? (
            await b.attendance.listSessions(i, {
              where: { batchId: snapshot.batchId },
              limit: 200,
              sort: { field: 'date', direction: 'desc' },
            })
          ).items
        : [];
      const joined = joinSessions(records, sessions);
      const keys = [...new Set(joined.map((row) => monthKey(row.date)))].sort().reverse();
      const months: MonthBlock[] = [];
      for (const key of keys) {
        const range = monthRange(key);
        const summary = await b.attendance.summary(i, { studentId: id, from: range.from, to: range.to });
        const byDay = new Map<number, ReturnType<typeof recordStatus>>();
        for (const row of joined) {
          if (monthKey(row.date) !== key) continue;
          byDay.set(Number(row.date.slice(8, 10)), recordStatus(row.status));
        }
        months.push({
          key,
          label: monthLabel(key),
          percentLabel: pct(summary.percent),
          percent: summary.percent,
          present: summary.present,
          absent: summary.absent,
          late: summary.late,
          total: summary.total,
          days: heatmapDays(key, byDay),
          startOffset: monthStartOffset(key),
        });
      }
      return { overall, overallLabel: pct(overall.percent), months };
    },
    enabled && studentId !== null,
  );
}
