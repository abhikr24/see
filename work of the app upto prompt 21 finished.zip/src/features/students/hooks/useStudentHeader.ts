import { useDomainQuery } from '@/core/hooks/domain';
import type { AttendanceSummary, Guardian, ID, ProgressSnapshot, Student } from '@/core/contracts/models';
import {
  attendanceChip,
  averageChip,
  feeChip,
  metaLine,
  parentPhone,
  parentWhatsAppUrl,
} from '../profile';

export interface HeaderChip {
  key: string;
  label: string;
}

export interface StudentHeaderView {
  id: ID;
  name: string;
  photoUrl: string | null;
  meta: string;
  chips: HeaderChip[];
  whatsappUrl: string | null;
  attendancePercent: number | null;
}

function toView(
  student: Student,
  snapshot: ProgressSnapshot,
  attendance: AttendanceSummary,
  batchName: string | null,
  roll: number | null,
  joinedOn: string | null,
  guardians: Guardian[],
): StudentHeaderView {
  return {
    id: student.id,
    name: student.fullName,
    photoUrl: student.photoUrl,
    meta: metaLine(batchName, roll, joinedOn),
    chips: [
      { key: 'attendance', label: attendanceChip(attendance) },
      { key: 'average', label: averageChip(snapshot.examPercent) },
      { key: 'fees', label: feeChip(snapshot.feeDue) },
    ],
    whatsappUrl: parentWhatsAppUrl(parentPhone(guardians, student.phone), student.fullName),
    attendancePercent: attendance.total === 0 ? null : attendance.percent,
  };
}

/**
 * Always-on header for the student 360. Attendance chip is `AttendanceRepo.summary`,
 * the same call the Attendance tab uses, so the two figures cannot drift.
 */
export function useStudentHeader(studentId: ID | null) {
  return useDomainQuery<StudentHeaderView>(
    'progress',
    ['student-header', studentId],
    async (b, i) => {
      const id = studentId as ID;
      const [student, snapshot, attendance, guardians] = await Promise.all([
        b.students.get(i, id),
        b.progress.computeSnapshot(i, id),
        b.attendance.summary(i, { studentId: id }),
        b.guardians.listForStudent(i, id),
      ]);
      let batchName: string | null = student.classGrade;
      let roll: number | null = null;
      let joinedOn: string | null = student.admittedOn;
      if (snapshot.batchId) {
        const [batch, enrolled] = await Promise.all([
          b.batches.get(i, snapshot.batchId),
          b.batches.listEnrollments(i, snapshot.batchId),
        ]);
        batchName = batch.name;
        const mine = enrolled.find((row) => row.studentId === id && row.status === 'active');
        roll = mine?.rollNumber ?? null;
        joinedOn = mine?.joinedOn ?? joinedOn;
      }
      return toView(student, snapshot, attendance, batchName, roll, joinedOn, guardians);
    },
    studentId !== null,
  );
}
