import type { TrendPoint } from '@/components/ui';
import { useDomainQuery } from '@/core/hooks/domain';
import type { ID } from '@/core/contracts/models';
import { pct } from '@/lib/format';

export interface ExamRow {
  id: ID;
  name: string;
  score: string;
  percentLabel: string;
  percent: number;
}

export interface MarksTabView {
  exams: ExamRow[];
  trend: TrendPoint[];
  headline: string | null;
}

/** Marks tab. Off until focused. Scores and averages come from ResultRepo. */
export function useStudentMarks(studentId: ID | null, enabled: boolean) {
  return useDomainQuery<MarksTabView>(
    'results',
    ['student-tab', studentId],
    async (b, i) => {
      const id = studentId as ID;
      const [results, examPage, snapshot] = await Promise.all([
        b.results.listForStudent(i, id),
        b.exams.list(i, { limit: 100 }),
        b.progress.computeSnapshot(i, id),
      ]);
      if (!results.length) {
        return { exams: [], trend: [], headline: null };
      }
      const examsById = new Map(examPage.items.map((exam) => [exam.id, exam]));
      const chronological = [...results].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      const exams: ExamRow[] = chronological.map((row) => ({
        id: row.id,
        name: examsById.get(row.examId)?.name ?? 'Exam',
        score: `${row.totalObtained}/${row.totalMax}`,
        percentLabel: pct(row.percentage),
        percent: row.percentage,
      }));
      const trend: TrendPoint[] = chronological.map((row) => ({
        value: row.percentage,
        label: (examsById.get(row.examId)?.name ?? 'Exam').replace('Unit Test ', 'UT'),
      }));
      const headline =
        snapshot.examPercent == null ? pct(chronological[chronological.length - 1]?.percentage) : pct(snapshot.examPercent);
      return { exams: [...exams].reverse(), trend, headline };
    },
    enabled && studentId !== null,
  );
}
