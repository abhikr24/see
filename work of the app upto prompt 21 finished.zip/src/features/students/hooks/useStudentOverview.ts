import { useDomainMutation, useDomainQuery } from '@/core/hooks/domain';
import type { ID, RiskAlert } from '@/core/contracts/models';
import {
  factualAlert,
  paidOnLabel,
  pickFeeStatus,
  termTitle,
  thisMonthBounds,
} from '../profile';

export interface MonthCounts {
  percent: number;
  present: number;
  absent: number;
  late: number;
  total: number;
}

export interface RecentMarkRow {
  id: ID;
  subject: string;
  obtained: string;
  bar: number;
}

export interface FeeStatusView {
  title: string;
  paidLabel: string;
  paid: boolean;
  hasReceipt: boolean;
}

export interface RiskView {
  id: ID;
  copy: string;
}

export interface OverviewView {
  month: MonthCounts | null;
  marks: RecentMarkRow[];
  fee: FeeStatusView | null;
  risks: RiskView[];
}

function barOf(obtained: number | null, max: number): number {
  if (obtained == null || max <= 0) return 0;
  return Math.round((obtained / max) * 1000) / 10;
}

/** Overview tab. Off until the tab is focused. Numbers come from the repos. */
export function useStudentOverview(studentId: ID | null, enabled: boolean) {
  const view = useDomainQuery<OverviewView>(
    'progress',
    ['student-overview', studentId],
    async (b, i) => {
      const id = studentId as ID;
      const monthRange = thisMonthBounds();
      const [month, picture, markPage, subjectPage, receiptPage] = await Promise.all([
        b.attendance.summary(i, { studentId: id, from: monthRange.from, to: monthRange.to }),
        b.progress.getStudent360(i, id),
        b.marks.list(i, { where: { studentId: id }, limit: 200 }),
        b.subjects.list(i, { limit: 100 }),
        b.receipts.list(i, { where: { studentId: id }, limit: 50 }),
      ]);
      const subjects = new Map(subjectPage.items.map((row) => [row.id, row.name]));
      const marks: RecentMarkRow[] = markPage.items
        .filter((row) => row.marksObtained != null && !row.isAbsent)
        .slice(0, 3)
        .map((row) => ({
          id: row.id,
          subject: subjects.get(row.subjectId) ?? 'Subject',
          obtained: `${row.marksObtained}/${row.maxMarks}`,
          bar: barOf(row.marksObtained, row.maxMarks),
        }));
      const installment = pickFeeStatus(picture.installments);
      const fee: FeeStatusView | null = installment
        ? {
            title: termTitle(installment),
            paidLabel: paidOnLabel(installment.paidOn, installment.status),
            paid: installment.status === 'paid',
            hasReceipt: receiptPage.items.length > 0 && Boolean(installment.paidOn),
          }
        : null;
      const open = picture.alerts.filter((alert) => alert.status === 'open');
      return {
        month: month.total === 0 ? null : {
          percent: month.percent,
          present: month.present,
          absent: month.absent,
          late: month.late,
          total: month.total,
        },
        marks,
        fee,
        risks: open.map((alert) => ({ id: alert.id, copy: factualAlert(alert) })),
      };
    },
    enabled && studentId !== null,
  );

  const intervene = useDomainMutation<{ alert: RiskView }, RiskAlert>(
    'progress',
    async (b, i, { alert }) => {
      await b.progress.saveTask(i, {
        studentId: studentId as ID,
        title: `Follow up: ${alert.copy}`,
        notes: alert.copy,
        source: 'teacher',
        priority: 'medium',
        status: 'todo',
      });
      return b.progress.setAlertStatus(i, alert.id, 'acknowledged');
    },
    { success: 'Intervention created', failure: 'Could not create the intervention' },
  );

  return { ...view, createIntervention: intervene.mutate, creating: intervene.loading };
}
