import { useCallback, useEffect, useState } from 'react';

import { useBackend } from '@/core/backend';
import { toBackendError } from '@/core/contracts/errors';
import type { Batch } from '@/core/contracts/models';
import { rosterCache } from '../cache';
import { loadRoster } from '../loadRoster';
import type { StudentRow } from '../types';

export function useStudentRoster() {
  const { backend, instituteId } = useBackend();
  const [rows, setRows] = useState<StudentRow[] | null>(rosterCache.rows);
  const [batches, setBatches] = useState<Batch[]>(rosterCache.batches);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(rosterCache.rows == null);
  const [refreshing, setRefreshing] = useState(false);

  const refresh = useCallback(async () => {
    if (!instituteId) return;
    const hadRows = rosterCache.rows != null;
    if (hadRows) setRefreshing(true);
    else setLoading(true);
    try {
      const data = await loadRoster(backend, instituteId);
      const pending = (rosterCache.rows ?? []).filter((row) => !data.rows.some((loaded) => loaded.id === row.id));
      const next = pending.length ? [...pending, ...data.rows] : data.rows;
      rosterCache.write(next, data.batches);
      setError(null);
    } catch (cause) {
      setError(toBackendError(cause).message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [backend, instituteId]);

  useEffect(() => {
    return rosterCache.subscribe(() => {
      setRows(rosterCache.rows);
      setBatches(rosterCache.batches);
    });
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  return {
    rows,
    batches,
    error,
    loading: loading && rows == null,
    refreshing,
    refresh,
  };
}
