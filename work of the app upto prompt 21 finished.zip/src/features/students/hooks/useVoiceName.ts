import { useCallback, useRef, useState } from 'react';

interface SpeechAlt {
  transcript: string;
}
interface SpeechEvent {
  results: ArrayLike<ArrayLike<SpeechAlt>>;
}
interface SpeechRec {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((event: SpeechEvent) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

type SpeechCtor = new () => SpeechRec;

function speechCtor(): SpeechCtor | null {
  const host = globalThis as unknown as {
    SpeechRecognition?: SpeechCtor;
    webkitSpeechRecognition?: SpeechCtor;
  };
  return host.SpeechRecognition ?? host.webkitSpeechRecognition ?? null;
}

/** Fills a name from speech. If recognition is missing, the caller keeps the typed field and shows `hint`. */
export function useVoiceName(onName: (name: string) => void) {
  const [listening, setListening] = useState(false);
  const [hint, setHint] = useState<string | null>(null);
  const recRef = useRef<SpeechRec | null>(null);
  const onNameRef = useRef(onName);
  onNameRef.current = onName;

  const start = useCallback(() => {
    const Ctor = speechCtor();
    if (!Ctor) {
      setHint('Voice input isn\u2019t available on this device \u2014 type the name.');
      setListening(false);
      return;
    }
    if (recRef.current) {
      recRef.current.stop();
      recRef.current = null;
      setListening(false);
      return;
    }
    const rec = new Ctor();
    rec.lang = 'en-IN';
    rec.interimResults = false;
    rec.continuous = false;
    rec.onresult = (event) => {
      const text = event.results[0]?.[0]?.transcript?.trim();
      if (text) onNameRef.current(text);
    };
    rec.onerror = () => {
      setHint('Couldn\u2019t hear a name \u2014 type it instead.');
      setListening(false);
      recRef.current = null;
    };
    rec.onend = () => {
      setListening(false);
      recRef.current = null;
    };
    recRef.current = rec;
    setHint(null);
    setListening(true);
    try {
      rec.start();
    } catch {
      setListening(false);
      recRef.current = null;
      setHint('Voice input isn\u2019t available \u2014 type the name.');
    }
  }, []);

  return { listening, hint, supported: speechCtor() != null, start };
}
