import type { Backend } from '@/core/contracts/ports';
import type {
  AttendanceRecord,
  Batch,
  Enrollment,
  FeeStructure,
  Guardian,
  ID,
  Installment,
  ParentLink,
  Student,
  StudentFee,
} from '@/core/contracts/models';
import type { Page } from '@/core/contracts/query';
import { todayISO } from '@/lib/format';
import type { StudentRow } from './types';

async function everyPage<T>(fetch: (cursor: string | null) => Promise<Page<T>>): Promise<T[]> {
  const items: T[] = [];
  let cursor: string | null = null;
  for (let page = 0; page < 20; page += 1) {
    const result = await fetch(cursor);
    items.push(...result.items);
    if (!result.nextCursor) break;
    cursor = result.nextCursor;
  }
  return items;
}

function owed(installment: Installment, today: string): number {
  if (installment.status === 'waived') return 0;
  const remaining = Math.max(0, installment.amount - installment.paidAmount);
  if (remaining <= 0) return 0;
  return installment.dueDate <= today ? remaining : 0;
}

function monthlyOf(studentId: ID, fees: StudentFee[], structures: FeeStructure[]): number {
  const mine = fees.filter((fee) => fee.studentId === studentId && fee.status !== 'cancelled');
  for (const fee of mine) {
    const structure = structures.find((item) => item.id === fee.feeStructureId);
    if (structure?.frequency === 'monthly') return fee.netAmount;
  }
  const fee = mine[0];
  if (!fee) return 0;
  return Math.round(fee.netAmount / 12);
}

function attendanceOf(records: AttendanceRecord[]): Map<ID, number> {
  const tally = new Map<ID, { present: number; total: number }>();
  for (const record of records) {
    const cur = tally.get(record.studentId) ?? { present: 0, total: 0 };
    cur.total += 1;
    if (record.status === 'present' || record.status === 'late') cur.present += 1;
    tally.set(record.studentId, cur);
  }
  const percent = new Map<ID, number>();
  for (const [id, cur] of tally) {
    percent.set(id, cur.total ? Math.round((cur.present / cur.total) * 1000) / 10 : 0);
  }
  return percent;
}

function parentsOf(links: ParentLink[], guardians: Guardian[]): Map<ID, { name: string; phone: string | null }> {
  const byId = new Map(guardians.map((guardian) => [guardian.id, guardian]));
  const out = new Map<ID, { name: string; phone: string | null }>();
  const ordered = [...links].sort((a, b) => Number(b.isPrimary) - Number(a.isPrimary));
  for (const link of ordered) {
    if (out.has(link.studentId)) continue;
    const guardian = byId.get(link.guardianId);
    if (guardian) out.set(link.studentId, { name: guardian.fullName, phone: guardian.phone });
  }
  return out;
}

function activeEnrollment(enrollments: Enrollment[]): Map<ID, Enrollment> {
  const out = new Map<ID, Enrollment>();
  for (const enrollment of enrollments) {
    if (enrollment.status !== 'active') continue;
    if (!out.has(enrollment.studentId)) out.set(enrollment.studentId, enrollment);
  }
  return out;
}

export async function loadRoster(backend: Backend, instituteId: ID): Promise<{ rows: StudentRow[]; batches: Batch[] }> {
  const today = todayISO();
  const [students, batches, structures, studentFees, guardians, links, installments, todayRecords, allRecords] =
    await Promise.all([
      everyPage((cursor) => backend.students.list(instituteId, { limit: 200, cursor, where: { status: 'active' } })),
      everyPage((cursor) => backend.batches.list(instituteId, { limit: 100, cursor })),
      everyPage((cursor) => backend.fees.listStructures(instituteId, { limit: 100, cursor })),
      everyPage((cursor) => backend.fees.listStudentFees(instituteId, { limit: 200, cursor })),
      everyPage((cursor) => backend.guardians.list(instituteId, { limit: 200, cursor })),
      backend.guardians.listLinks(instituteId),
      backend.fees.listInstallments(instituteId),
      backend.attendance.listRecords(instituteId, { from: today, to: today }),
      backend.attendance.listRecords(instituteId, {}),
    ]);

  const enrollments = (
    await Promise.all(batches.map((batch) => backend.batches.listEnrollments(instituteId, batch.id)))
  ).flat();
  const batchName = new Map(batches.map((batch) => [batch.id, batch.name]));
  const enrolled = activeEnrollment(enrollments);
  const parents = parentsOf(links, guardians);
  const attendance = attendanceOf(allRecords);
  const absent = new Set(todayRecords.filter((record) => record.status === 'absent').map((record) => record.studentId));
  const dueByStudent = new Map<ID, number>();
  for (const installment of installments) {
    const amount = owed(installment, today);
    if (!amount) continue;
    dueByStudent.set(installment.studentId, (dueByStudent.get(installment.studentId) ?? 0) + amount);
  }

  const rows = students.map((student) => toRow(student, enrolled, batchName, parents, attendance, absent, dueByStudent, studentFees, structures));
  return { rows, batches: batches.filter((batch) => batch.status !== 'archived') };
}

function toRow(
  student: Student,
  enrolled: Map<ID, Enrollment>,
  batchName: Map<ID, string>,
  parents: Map<ID, { name: string; phone: string | null }>,
  attendance: Map<ID, number>,
  absent: Set<ID>,
  dueByStudent: Map<ID, number>,
  fees: StudentFee[],
  structures: FeeStructure[],
): StudentRow {
  const enrollment = enrolled.get(student.id);
  const parent = parents.get(student.id);
  return {
    id: student.id,
    fullName: student.fullName,
    photoUrl: student.photoUrl,
    batchId: enrollment?.batchId ?? null,
    batchName: enrollment ? (batchName.get(enrollment.batchId) ?? 'Batch') : 'No batch',
    roll: enrollment?.rollNumber ?? null,
    monthlyFee: monthlyOf(student.id, fees, structures),
    due: Math.round(dueByStudent.get(student.id) ?? 0),
    absentToday: absent.has(student.id),
    attendancePercent: attendance.get(student.id) ?? null,
    parentName: parent?.name ?? null,
    parentPhone: parent?.phone ?? student.phone,
  };
}
