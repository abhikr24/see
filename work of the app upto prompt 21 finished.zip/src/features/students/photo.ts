import { Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

function asDataUrl(base64: string | null | undefined, uri: string): string {
  if (base64) return `data:image/jpeg;base64,${base64}`;
  return uri;
}

/** Camera first when asked; library if the camera is unavailable. Returns a displayable URI or null. */
export async function pickStudentPhoto(source: 'camera' | 'library'): Promise<string | null> {
  try {
    if (source === 'camera') {
      const camera = await ImagePicker.requestCameraPermissionsAsync();
      if (!camera.granted) source = 'library';
    }
    if (source === 'library' && Platform.OS !== 'web') {
      const library = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!library.granted) return null;
    }
    const launch = source === 'camera' ? ImagePicker.launchCameraAsync : ImagePicker.launchImageLibraryAsync;
    const result = await launch({
      mediaTypes: 'images',
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.55,
      base64: true,
    });
    if (result.canceled || !result.assets[0]) return null;
    return asDataUrl(result.assets[0].base64, result.assets[0].uri);
  } catch {
    if (source === 'camera') return pickStudentPhoto('library');
    return null;
  }
}
