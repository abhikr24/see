import type { HeatmapDay, HeatmapStatus } from '@/components/ui';
import type {
  AttendanceRecord,
  AttendanceSession,
  AttendanceSummary,
  Guardian,
  Installment,
  InstallmentStatus,
  RiskAlert,
} from '@/core/contracts/models';
import { dateShort, inr, pct, todayISO } from '@/lib/format';

export type ProfileTab = 'overview' | 'attendance' | 'marks' | 'fees';

export const PROFILE_TABS: { key: ProfileTab; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'attendance', label: 'Attendance' },
  { key: 'marks', label: 'Marks' },
  { key: 'fees', label: 'Fees' },
];

/** Shared body height so swapping tabs never shoves the footer. */
export const TAB_BODY_MIN = 480;

export function joinedLine(iso: string | null | undefined): string {
  if (!iso) return 'Joined \u2014';
  const dt = new Date(`${iso.slice(0, 10)}T00:00:00`);
  if (isNaN(dt.getTime())) return 'Joined \u2014';
  return `Joined ${dt.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}`;
}

export function metaLine(batchName: string | null, roll: number | null, joinedOn: string | null): string {
  const batch = batchName || 'No batch';
  const rollText = roll == null ? 'Roll \u2014' : `Roll ${roll}`;
  return `${batch} \u00b7 ${rollText} \u00b7 ${joinedLine(joinedOn)}`;
}

/** `\u2014` when nothing is recorded, never a zero. */
export function attendanceChip(summary: AttendanceSummary): string {
  return summary.total === 0 ? '\u2014' : pct(summary.percent);
}

export function averageChip(examPercent: number | null): string {
  return examPercent == null ? '\u2014' : pct(examPercent);
}

export function feeChip(feeDue: number): string {
  return feeDue > 0 ? inr(feeDue) : 'Paid';
}

/** Plain-words restatement of the rule that fired. Never a judgement. */
export function factualAlert(alert: RiskAlert): string {
  switch (alert.kind) {
    case 'low_attendance':
      return `Attendance fell below ${alert.threshold}% in the last 30 days`;
    case 'low_marks':
      return `Exam average is ${alert.metricValue}% against a watch threshold of ${alert.threshold}%`;
    case 'missing_homework':
      return `Homework handed in is ${alert.metricValue}%, below ${alert.threshold}%`;
    case 'fee_overdue':
      return `${inr(alert.metricValue)} outstanding on overdue instalments`;
    default:
      return alert.detail;
  }
}

export function thisMonthBounds(today = todayISO()): { from: string; to: string } {
  return { from: `${today.slice(0, 7)}-01`, to: today };
}

export function monthKey(iso: string): string {
  return iso.slice(0, 7);
}

export function monthLabel(ym: string): string {
  const [year, month] = ym.split('-').map(Number);
  return new Date(year, month - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
}

/** Heatmap weekday offset: 0 = Monday. */
export function monthStartOffset(ym: string): number {
  const [year, month] = ym.split('-').map(Number);
  return (new Date(year, month - 1, 1).getDay() + 6) % 7;
}

export function daysInMonth(ym: string): number {
  const [year, month] = ym.split('-').map(Number);
  return new Date(year, month, 0).getDate();
}

export function monthRange(ym: string): { from: string; to: string } {
  const last = String(daysInMonth(ym)).padStart(2, '0');
  return { from: `${ym}-01`, to: `${ym}-${last}` };
}

export function heatmapDays(ym: string, byDay: Map<number, HeatmapStatus>): HeatmapDay[] {
  const last = daysInMonth(ym);
  const days: HeatmapDay[] = [];
  for (let day = 1; day <= last; day += 1) {
    days.push({ day, status: byDay.get(day) ?? 'none' });
  }
  return days;
}

export function recordStatus(status: AttendanceRecord['status']): HeatmapStatus {
  if (status === 'present') return 'present';
  if (status === 'late') return 'late';
  if (status === 'absent') return 'absent';
  return 'holiday';
}

export function parentPhone(guardians: Guardian[], fallback: string | null): string | null {
  const primary = guardians[0]?.phone ?? null;
  return primary || fallback;
}

export function parentWhatsAppUrl(phone: string | null | undefined, studentName: string): string | null {
  if (!phone) return null;
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 10) return null;
  const e164 = digits.length === 10 ? `91${digits}` : digits.replace(/^0+/, '');
  const text = encodeURIComponent(`Hello, this is regarding ${studentName}.`);
  return `https://wa.me/${e164}?text=${text}`;
}

export function pickFeeStatus(installments: Installment[]): Installment | null {
  if (!installments.length) return null;
  const order: InstallmentStatus[] = ['overdue', 'partial', 'due', 'paid', 'upcoming', 'waived'];
  for (const status of order) {
    const match = installments.find((row) => row.status === status);
    if (match) return match;
  }
  return installments[0] ?? null;
}

export function paidOnLabel(paidOn: string | null, status: InstallmentStatus): string {
  if (status === 'paid' && paidOn) {
    const short = dateShort(paidOn);
    const withoutYear = short.replace(/\s\d{4}$/, '');
    return `Paid on ${withoutYear}`;
  }
  if (status === 'overdue') return 'Overdue';
  if (status === 'partial') return 'Part paid';
  if (status === 'waived') return 'Waived';
  if (status === 'upcoming') return 'Upcoming';
  return 'Due';
}

export function termTitle(installment: Installment): string {
  return `${installment.label.replace(/\sfee$/i, '')} \u00b7 ${inr(installment.amount)}`;
}

export function joinSessions(
  records: AttendanceRecord[],
  sessions: AttendanceSession[],
): { date: string; status: AttendanceRecord['status'] }[] {
  const dates = new Map(sessions.map((session) => [session.id, session.date]));
  const rows: { date: string; status: AttendanceRecord['status'] }[] = [];
  for (const record of records) {
    const date = dates.get(record.sessionId);
    if (date) rows.push({ date, status: record.status });
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date));
}
