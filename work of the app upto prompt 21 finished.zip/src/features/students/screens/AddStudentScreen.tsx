import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Button, Chip, Input, Text } from '@/components/ui';
import { C, LAYOUT } from '@/lib/theme';
import { PhotoRing } from '../components/PhotoRing';
import { UpgradeSheet } from '../components/UpgradeSheet';
import { useAdmitStudent } from '../hooks/useAdmitStudent';
import { useStudentRoster } from '../hooks/useStudentRoster';
import { useVoiceName } from '../hooks/useVoiceName';
import { pickStudentPhoto } from '../photo';
import {
  EMPTY_DRAFT,
  ringFilled,
  suggestMonthlyFee,
  type AdmitDraft,
  type AdmitErrors,
} from '../types';

export function AddStudentScreen({ initialBatchId }: { initialBatchId?: string | null }) {
  const { rows, batches } = useStudentRoster();
  const { admit, saving, limit, dismissLimit } = useAdmitStudent();
  const [draft, setDraft] = useState<AdmitDraft>(EMPTY_DRAFT);
  const [errors, setErrors] = useState<AdmitErrors>({});
  const [photoHint, setPhotoHint] = useState<string | null>(null);
  const voice = useVoiceName((fullName) => setDraft((current) => ({ ...current, fullName })));

  useEffect(() => {
    if (draft.batchId || !initialBatchId) return;
    if (!batches.some((batch) => batch.id === initialBatchId)) return;
    setDraft((current) => ({
      ...current,
      batchId: initialBatchId,
      monthlyFee: String(suggestMonthlyFee(initialBatchId, rows ?? [])),
    }));
  }, [initialBatchId, batches, rows, draft.batchId]);

  const patch = (partial: Partial<AdmitDraft>) => setDraft((current) => ({ ...current, ...partial }));

  const chooseBatch = (batchId: string) => {
    patch({
      batchId,
      monthlyFee: draft.monthlyFee && draft.batchId === batchId ? draft.monthlyFee : String(suggestMonthlyFee(batchId, rows ?? [])),
    });
  };

  const takePhoto = async (source: 'camera' | 'library') => {
    const uri = await pickStudentPhoto(source);
    if (!uri) {
      setPhotoHint(source === 'camera' ? 'Camera is unavailable \u2014 pick a photo from the library, or skip it.' : 'Could not open the photo library.');
      return;
    }
    setPhotoHint(null);
    patch({ photoUri: uri });
  };

  const save = async (next: boolean) => {
    const result = await admit(draft, next ? 'next' : 'close');
    setErrors(result.errors);
    if (!result.ok) return;
    if (next) {
      setDraft((current) => ({ ...current, fullName: '', roll: '', photoUri: null }));
      setPhotoHint(null);
      return;
    }
    router.back();
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.canvas }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: LAYOUT.margin, paddingBottom: 24, gap: 14 }}>
        <Pressable accessibilityRole="button" accessibilityLabel="Back to students" onPress={() => router.back()} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, alignSelf: 'flex-start' }}>
          <Ionicons name="chevron-back" size={20} color={C.primary} />
          <Text variant="caption" weight={700} c={C.primary}>
            Students
          </Text>
        </Pressable>
        <Text variant="h2">Add student</Text>
        <PhotoRing uri={draft.photoUri} filled={ringFilled(draft)} onLibrary={() => void takePhoto('library')} onCamera={() => void takePhoto('camera')} />
        {photoHint ? (
          <Text variant="caption" c={C.secondary} style={{ textAlign: 'center' }}>
            {photoHint}
          </Text>
        ) : null}
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 8 }}>
          <View style={{ flex: 1 }}>
            <Input
              label="Full name"
              value={draft.fullName}
              onChangeText={(fullName) => patch({ fullName })}
              error={errors.fullName}
              placeholder="Aarav Sharma"
              autoCapitalize="words"
              returnKeyType="next"
            />
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={voice.listening ? 'Stop voice input' : 'Fill name by voice'}
            onPress={voice.start}
            style={{
              marginTop: 22,
              width: 56,
              height: 56,
              borderRadius: 28,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: voice.listening ? C.accent : C.navySoft,
            }}
          >
            <Ionicons name={voice.listening ? 'mic' : 'mic-outline'} size={22} color={voice.listening ? C.surface : C.primary} />
          </Pressable>
        </View>
        {voice.hint ? (
          <Text variant="caption" c={C.secondary}>
            {voice.hint}
          </Text>
        ) : null}
        <View style={{ gap: 8 }}>
          <Text variant="label" c={C.secondary}>
            Batch
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {batches.map((batch) => (
              <Chip key={batch.id} label={batch.name} active={draft.batchId === batch.id} onPress={() => chooseBatch(batch.id)} />
            ))}
          </ScrollView>
          {errors.batchId ? (
            <Text variant="caption" c={C.danger}>
              {errors.batchId}
            </Text>
          ) : null}
        </View>
        <Input
          label="Roll number"
          value={draft.roll}
          onChangeText={(roll) => patch({ roll: roll.replace(/\D/g, '') })}
          error={errors.roll}
          keyboardType="number-pad"
          placeholder="14"
          maxLength={4}
        />
        <Input
          label="Parent name"
          value={draft.parentName}
          onChangeText={(parentName) => patch({ parentName })}
          placeholder="Optional"
          autoCapitalize="words"
        />
        <Input
          label="Parent mobile"
          value={draft.parentPhone}
          onChangeText={(parentPhone) => patch({ parentPhone: parentPhone.replace(/\D/g, '').slice(0, 10) })}
          error={errors.parentPhone}
          keyboardType="phone-pad"
          placeholder="10-digit mobile"
          maxLength={10}
        />
        <Input
          label="Monthly fee"
          value={draft.monthlyFee}
          onChangeText={(monthlyFee) => patch({ monthlyFee: monthlyFee.replace(/[^\d.]/g, '') })}
          error={errors.monthlyFee}
          keyboardType="decimal-pad"
          placeholder="1500"
          hint="Prefilled from the batch. You can change it."
        />
      </ScrollView>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 10, paddingBottom: 96, gap: 8, backgroundColor: C.surface, borderTopWidth: 1, borderTopColor: C.hairline }}>
        <Button title="Save student" loading={saving} onPress={() => void save(false)} />
        <Button title="Save & next" variant="outline" disabled={saving} onPress={() => void save(true)} />
      </View>
      <UpgradeSheet visible={limit != null} cap={limit?.cap ?? null} used={limit?.used ?? null} onClose={dismissLimit} />
    </KeyboardAvoidingView>
  );
}
