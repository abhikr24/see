export { StudentProfileScreen as StudentDetailScreen } from '../[id]';
