import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { EmptyState, ErrorState, ListSkeleton } from '@/components/ui';
import { C, LAYOUT, SHADOW } from '@/lib/theme';
import { StudentListHeader } from '../components/StudentListHeader';
import { StudentListRow } from '../components/StudentListRow';
import { useStudentRoster } from '../hooks/useStudentRoster';
import {
  PAGE_SIZE,
  applyRoster,
  duesCount,
  type ChipKey,
  type SortKey,
  type StudentRow,
} from '../types';

function openAdd(batchId?: string | null) {
  router.push({
    pathname: '/(owner)/students/new',
    params: batchId ? { batchId } : {},
  });
}

export function StudentListScreen() {
  const params = useLocalSearchParams<{ action?: string; batchId?: string }>();
  const { rows, batches, error, loading, refreshing, refresh } = useStudentRoster();
  const [chip, setChip] = useState<ChipKey>('all');
  const [sort, setSort] = useState<SortKey>('name');
  const [search, setSearch] = useState('');
  const [pages, setPages] = useState(1);
  const [paging, setPaging] = useState(false);
  const redirected = useRef(false);

  useEffect(() => {
    if (redirected.current || params.action !== 'add') return;
    redirected.current = true;
    openAdd(typeof params.batchId === 'string' ? params.batchId : null);
  }, [params.action, params.batchId]);

  useEffect(() => {
    setPages(1);
  }, [chip, sort, search]);

  const all = rows ?? [];
  const chipBatches = useMemo(
    () =>
      batches.map((batch) => ({
        id: batch.id,
        name: batch.name,
        count: all.filter((row) => row.batchId === batch.id).length,
      })),
    [batches, all],
  );
  const filtered = useMemo(() => applyRoster(all, chip, search, sort), [all, chip, search, sort]);
  const visible = filtered.slice(0, pages * PAGE_SIZE);
  const hasMore = visible.length < filtered.length;
  const selectedBatch = chip.startsWith('batch:') ? chip.slice('batch:'.length) : null;

  const loadMore = () => {
    if (!hasMore || paging) return;
    setPaging(true);
    setTimeout(() => {
      setPages((page) => page + 1);
      setPaging(false);
    }, 180);
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <StudentListHeader
        total={all.length}
        chipCounts={{ overdue: duesCount(all), batches: chipBatches }}
        chip={chip}
        onChip={setChip}
        sort={sort}
        onSort={setSort}
        search={search}
        onSearch={setSearch}
        shown={filtered.length}
        shownDues={duesCount(filtered)}
        onAdd={() => openAdd(selectedBatch)}
      />
      <FlatList
        data={loading ? [] : visible}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <StudentListRow row={item} onPress={() => router.push(`/(owner)/students/${item.id}`)} />
        )}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void refresh()} tintColor={C.primary} />}
        onEndReached={loadMore}
        onEndReachedThreshold={0.4}
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 140, flexGrow: 1 }}
        ListEmptyComponent={
          loading ? (
            <View style={{ paddingHorizontal: LAYOUT.margin }}>
              <ListSkeleton rows={6} h={72} />
            </View>
          ) : error && all.length === 0 ? (
            <ErrorState message={error} onRetry={() => void refresh()} />
          ) : (
            <EmptyState
              icon="people-outline"
              title={all.length === 0 ? 'Add your first student' : 'No students match'}
              text={
                all.length === 0
                  ? 'Admissions land here. A photo is optional \u2014 initials show until you add one.'
                  : 'Try another batch, or clear the search.'
              }
              actionLabel={all.length === 0 ? 'Add student' : undefined}
              onAction={all.length === 0 ? () => openAdd(selectedBatch) : undefined}
            />
          )
        }
        ListFooterComponent={
          hasMore || paging ? (
            <ActivityIndicator color={C.primary} style={{ marginVertical: 16 }} />
          ) : (
            <View style={{ height: 8 }} />
          )
        }
      />
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Add student"
        onPress={() => openAdd(selectedBatch)}
        style={{
          position: 'absolute',
          right: LAYOUT.margin,
          bottom: 108,
          width: 56,
          height: 56,
          borderRadius: 28,
          backgroundColor: C.accent,
          alignItems: 'center',
          justifyContent: 'center',
          ...SHADOW,
        }}
      >
        <Ionicons name="add" size={28} color={C.surface} />
      </Pressable>
    </View>
  );
}

export type { StudentRow };
