import React from 'react';
import { View } from 'react-native';
import { Card, Heatmap, Text } from '@/components/ui';
import { C } from '@/lib/theme';
import { TabFrame } from '../components/TabFrame';
import type { AttendanceTabView } from '../hooks/useStudentAttendance';

export function AttendanceTab({
  data,
  loading,
  error,
  onRetry,
}: {
  data: AttendanceTabView | undefined;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}) {
  return (
    <TabFrame
      loading={loading && !data}
      error={error}
      onRetry={onRetry}
      empty={Boolean(data) && data?.months.length === 0}
      emptyIcon="calendar-outline"
      emptyTitle="No attendance yet"
      emptyText="Once a roll call is marked, the month list and heatmap will show here."
    >
      <View style={{ gap: 14 }}>
        {data?.months.map((month) => (
          <View key={month.key} style={{ gap: 10 }}>
            <Card>
              <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' }}>
                <Text variant="title">{month.label}</Text>
                <Text variant="h2" weight={800} tabular c={C.teal}>
                  {month.percentLabel}
                </Text>
              </View>
              <Text variant="caption" c={C.secondary} style={{ marginTop: 6 }}>
                Present {month.present} \u00b7 Absent {month.absent} \u00b7 Late {month.late}
              </Text>
            </Card>
            <Heatmap
              monthLabel={month.label}
              subtitle={month.percentLabel}
              days={month.days}
              startOffset={month.startOffset}
              variant="attendance"
            />
          </View>
        ))}
      </View>
    </TabFrame>
  );
}
