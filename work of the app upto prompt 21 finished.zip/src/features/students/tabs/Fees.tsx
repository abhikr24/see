import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Badge, Card, Text } from '@/components/ui';
import { C, TONE } from '@/lib/theme';
import { TabFrame } from '../components/TabFrame';
import type { FeesTabView, StatementView, TermRow } from '../hooks/useStudentFees';

function TermCard({ term }: { term: TermRow }) {
  const tone = TONE[term.tone];
  return (
    <Card>
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
        <View style={{ flex: 1, gap: 4 }}>
          <Text variant="title">{term.title}</Text>
          <Text variant="caption" c={C.secondary}>
            Due {term.due}
          </Text>
        </View>
        <View style={{ alignItems: 'flex-end', gap: 6 }}>
          <Text variant="h2" weight={800} tabular>
            {term.amount}
          </Text>
          <Badge label={term.statusLabel} tone={term.tone} />
        </View>
      </View>
      <Text variant="caption" weight={600} c={tone.fg} style={{ marginTop: 12 }}>
        {term.paidLabel}
      </Text>
      {term.receipts.length ? (
        <View style={{ marginTop: 14, gap: 8, borderTopWidth: 1, borderTopColor: C.hairline, paddingTop: 12 }}>
          {term.receipts.map((receipt) => (
            <View key={receipt.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <Ionicons name="receipt-outline" size={18} color={C.teal} />
              <View style={{ flex: 1 }}>
                <Text variant="caption" weight={700}>
                  {receipt.number}
                </Text>
                <Text variant="label" c={C.muted} style={{ textTransform: 'none', letterSpacing: 0 }}>
                  {receipt.issued}
                </Text>
              </View>
              <Text variant="caption" weight={700} tabular>
                {receipt.amount}
              </Text>
            </View>
          ))}
        </View>
      ) : term.status === 'paid' ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12 }}>
          <Ionicons name="receipt-outline" size={18} color={C.teal} />
          <Text variant="caption" c={C.secondary}>
            Paid \u2014 receipt not issued
          </Text>
        </View>
      ) : null}
    </Card>
  );
}

/** Total owed (after any scholarship) is the biggest thing on the tab. */
function StatementCard({ statement }: { statement: StatementView }) {
  return (
    <Card>
      <Text variant="label" c={C.secondary}>
        Total fee
      </Text>
      <Text variant="h1" tabular style={{ marginTop: 4 }}>
        {statement.net}
      </Text>
      {statement.discount ? (
        <View style={{ marginTop: 6, gap: 2 }}>
          <Text variant="caption" weight={600} c={C.teal} tabular>
            {statement.gross} plan fee − {statement.discount} scholarship
          </Text>
          {statement.discountNote ? (
            <Text variant="caption" c={C.secondary}>
              {statement.discountNote}
            </Text>
          ) : null}
        </View>
      ) : (
        <Text variant="caption" c={C.secondary} style={{ marginTop: 6 }}>
          {statement.plan}
        </Text>
      )}
      <View style={{ flexDirection: 'row', marginTop: 14, borderTopWidth: 1, borderTopColor: C.hairline, paddingTop: 12 }}>
        <View style={{ flex: 1 }}>
          <Text variant="caption" c={C.secondary}>
            Paid
          </Text>
          <Text variant="title" tabular c={C.teal}>
            {statement.paid}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text variant="caption" c={C.secondary}>
            Still to pay
          </Text>
          <Text variant="title" tabular>
            {statement.due}
          </Text>
        </View>
      </View>
    </Card>
  );
}

export function FeesTab({
  data,
  loading,
  error,
  onRetry,
}: {
  data: FeesTabView | undefined;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}) {
  return (
    <TabFrame
      loading={loading && !data}
      error={error}
      onRetry={onRetry}
      empty={Boolean(data) && data?.terms.length === 0}
      emptyIcon="wallet-outline"
      emptyTitle="No fees assigned"
      emptyText="Terms and receipts will show here once a fee plan is assigned."
    >
      <View style={{ gap: 12 }}>
        {data?.statement ? <StatementCard statement={data.statement} /> : null}
        {data?.terms.map((term) => <TermCard key={term.id} term={term} />)}
      </View>
    </TabFrame>
  );
}
