import React from 'react';
import { View } from 'react-native';
import { Card, ProgressBar, Text, TrendLine } from '@/components/ui';
import { C } from '@/lib/theme';
import { TabFrame } from '../components/TabFrame';
import type { MarksTabView } from '../hooks/useStudentMarks';

export function MarksTab({
  data,
  loading,
  error,
  onRetry,
}: {
  data: MarksTabView | undefined;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}) {
  return (
    <TabFrame
      loading={loading && !data}
      error={error}
      onRetry={onRetry}
      empty={Boolean(data) && data?.exams.length === 0}
      emptyIcon="document-text-outline"
      emptyTitle="No marks yet"
      emptyText="Published exam scores will show as a list and a trend."
    >
      <View style={{ gap: 14 }}>
        {data?.trend.length ? (
          <TrendLine
            data={data.trend}
            title="Score trend"
            subtitle="From ResultRepo, newest on the right"
            headlineValue={data.headline ?? undefined}
            color={C.primary}
          />
        ) : null}
        {data?.exams.map((exam) => (
          <Card key={exam.id}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
              <Text variant="title" numberOfLines={1} style={{ flex: 1 }}>
                {exam.name}
              </Text>
              <Text variant="title" weight={800} tabular>
                {exam.score}
              </Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 8, marginBottom: 10 }}>
              <Text variant="caption" c={C.secondary}>
                Score
              </Text>
              <Text variant="caption" weight={700} c={C.primary} tabular>
                {exam.percentLabel}
              </Text>
            </View>
            <ProgressBar value={exam.percent} tone="primary" height={6} />
          </Card>
        ))}
      </View>
    </TabFrame>
  );
}
