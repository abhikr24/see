import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Card, ProgressBar, Ring, Text } from '@/components/ui';
import { C } from '@/lib/theme';
import { RiskCard } from '../components/RiskCard';
import { TabFrame } from '../components/TabFrame';
import type { OverviewView } from '../hooks/useStudentOverview';

function Count({ label, value }: { label: string; value: number }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' }}>
      <Text variant="caption" c={C.secondary}>
        {label}
      </Text>
      <Text variant="title" weight={800} tabular>
        {value}
      </Text>
    </View>
  );
}

export function OverviewTab({
  data,
  loading,
  error,
  onRetry,
  onIntervene,
  creating,
}: {
  data: OverviewView | undefined;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onIntervene: (id: string) => void;
  creating: boolean;
}) {
  const empty = Boolean(data) && !data?.month && data?.marks.length === 0 && !data.fee && data.risks.length === 0;
  return (
    <TabFrame
      loading={loading && !data}
      error={error}
      onRetry={onRetry}
      empty={empty}
      emptyIcon="person-outline"
      emptyTitle="Nothing recorded yet"
      emptyText="Attendance, marks and fees for this student will land here."
    >
      <View style={{ gap: 14 }}>
        {data?.month ? (
          <Card>
            <Text variant="label" c={C.muted} style={{ marginBottom: 14 }}>
              This month
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 20 }}>
              <Ring value={data.month.percent} size={96} stroke={8} tone={C.teal} />
              <View style={{ flex: 1, gap: 8 }}>
                <Count label="Present" value={data.month.present} />
                <Count label="Absent" value={data.month.absent} />
                <Count label="Late" value={data.month.late} />
              </View>
            </View>
          </Card>
        ) : (
          <Card flat>
            <Text variant="label" c={C.muted} style={{ marginBottom: 8 }}>
              This month
            </Text>
            <Text variant="caption" c={C.secondary}>
              No attendance recorded this month.
            </Text>
          </Card>
        )}

        <Card>
          <Text variant="label" c={C.muted} style={{ marginBottom: 14 }}>
            Recent marks
          </Text>
          {data?.marks.length ? (
            <View style={{ gap: 14 }}>
              {data.marks.map((row) => (
                <View key={row.id} style={{ gap: 6 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <Text variant="body" weight={600} numberOfLines={1} style={{ flex: 1, marginRight: 12 }}>
                      {row.subject}
                    </Text>
                    <Text variant="title" weight={800} tabular>
                      {row.obtained}
                    </Text>
                  </View>
                  <ProgressBar value={row.bar} tone="primary" height={6} />
                </View>
              ))}
            </View>
          ) : (
            <Text variant="caption" c={C.secondary}>
              No marks recorded yet.
            </Text>
          )}
        </Card>

        <Card>
          <Text variant="label" c={C.muted} style={{ marginBottom: 14 }}>
            Fee status
          </Text>
          {data?.fee ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ flex: 1, gap: 4 }}>
                <Text variant="title" weight={700}>
                  {data.fee.title}
                </Text>
                <Text variant="caption" weight={600} c={data.fee.paid ? C.teal : C.danger}>
                  {data.fee.paidLabel}
                </Text>
              </View>
              {data.fee.paid || data.fee.hasReceipt ? (
                <Ionicons name="receipt-outline" size={22} color={C.teal} />
              ) : null}
            </View>
          ) : (
            <Text variant="caption" c={C.secondary}>
              No fee plan assigned.
            </Text>
          )}
        </Card>

        {data?.risks.map((risk) => (
          <RiskCard key={risk.id} risk={risk} creating={creating} onCreate={() => onIntervene(risk.id)} />
        ))}
      </View>
    </TabFrame>
  );
}
